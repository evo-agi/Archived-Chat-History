# Repair of the SPIRE agent helper after re-audit 04 (INF-14, PR #34)

**Verdict: REPAIRED. Both re-audit findings (R34-1 and R34-2, Low) are fixed, each with tests, and trunk_dev `400ff7f` is merged in. Draft PR [#34](https://github.com/evo-agi/Execution-Substrate/pull/34) is now at `9993c62`. Ready for the narrow re-audit. Scripts, tests and docs only.**

```text
REPAIR REPORT
Objective:        fix re-audit 04 findings R34-1 and R34-2 in PR #34, starting from the auditor's tested
                  diff after reviewing it; update with trunk_dev 400ff7f
Repository:       evo-agi/Execution-Substrate
Base ref and SHA: origin/trunk_dev 400ff7faa0f124b10dbb607fbad009e346bac4df (trunk_dev moved to 0aa4a2b,
                  #33, just before the push; no shared path, trial merge clean; section 3)
Topic branch:     claude/project-thread-wg7jh5
Re-audited head:  26c7cf8012741b2a8e94cdd690061cd959899ce7
Topic head SHA:   9993c62e9faf6e6ecb87f4ce326a93d352a117ec
                  (= 26c7cf8 + merge 690db9a of 400ff7f + repair commit 9993c62)
Tree SHA:         24951907803a3002778619aad2a9374237f593f6
v2 manifest:      manifest_sha256 872f41db4343d16060a03220d120aee1a808686e26e62a9205478a066d303890
                  textual_diff_sha256 bdd63d91404cfa9964d2368d43f0993dff68cd549af96b400e3c057600272e12
                  5 files (the same 5 paths), upstream origin/trunk_dev, HEAD at 400ff7f when taken,
                  tool sha256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca verified
Final status:     clean (git status --porcelain empty after the commit)
CI:               "build, vet and test" success on 9993c62 (run 45283590343, 22:51Z to 23:20Z)
Effect status:    TOPIC_BRANCH_PUSHED | DRAFT_PR_UPDATED | MERGE_NOT_PERFORMED |
                  RE_AUDIT_NOT_PERFORMED | RED_TEAM_NOT_PERFORMED | BOX_RUN_NOT_PERFORMED
```

## 0. In plain words

The re-audit found two small things. First, `status` and `pin` could still be fooled into saying "pinned, confirmed by SPIRE" by three deliberately odd ways of writing `agent.conf`, in which SPIRE would actually trust a different bundle file. The helper now refuses any file that uses those writing tricks at all: a quoted key anywhere, or any non-ASCII character. Second, three of the four safety mechanisms I had called untestable can in fact be tested, and now are: a stop signal while recover cleans up, a second stop signal while pin rolls back, and a group-membership rule. Only split-second windows inside the helper remain untested. Nothing ran on the box.

## 1. Findings and fixes

| Finding | Fix | Tests |
|---|---|---|
| **R34-1** (Low) `status`/`pin` call three odd spellings "pinned, confirmed by SPIRE" while SPIRE loads another bundle | From the auditor's diff, unchanged: `analyze_agent_config` refuses any non-ASCII character (HCL folds U+017F to `s`; Python's `lower()` does not) and any quoted key anywhere on a line (`"\s*=`; HCL decodes escapes in quoted keys wherever they stand). With these, a second spelling of `trust_bundle_path` can only differ in ASCII letter case, which the case-insensitive count already refuses. I also updated the `spire_confirms_pinned` docstring to name these preconditions, and the docs list of refused shapes ("a quoted key anywhere, a non-ASCII character"). | Three `ConfigAnalysis` cases from the diff: a second one-line `agent` block with an escaped key, an escaped key after a comma, and a long-s key. Each must be `unrecognized` (killed: R1, R2, N13). |
| **R34-2** (Low) N17, N19, N18 are testable | Tests only. (a) Recover, from the diff: a 2 s attestation timeout and a shim agent that lingers on SIGTERM; the test signals the helper while its cleanup waits for that agent; the cleanup must still remove the scratch directory and roll back (kills N17 and N17b). (b) Pin, **written here** (section 2): the fake systemctl holds each restart after its stop; the first SIGTERM lands in pin's restart and the second in the rollback's restart; the rollback must finish, with the original config back and the agent and `es.service` running under the old identity (kills N19). (c) From the diff: a `--group-members` driver mode and a unit test that the test account counts as a member of its own primary group (kills N18). | as described |

## 2. Review of the auditor's diff

The diff applied cleanly to the merged tree. The resulting `.py` was byte-equal to the auditor's tested file (`6c425fec…df17`) before my docstring change. I agree with both refusals. A string followed by `=` is always a key in HCL native syntax, and the box template uses neither shape, so nothing honest is refused. The recover and group tests read correctly.

**One gap in the diff.** Re-audit sections 3 and 7 list "the fake systemctl hold marker and the two-SIGTERM pin step", and the auditor's results show N19 killed at pin-test line 1263. But `proposed-fix.diff` holds no hunk for either. The test file it produces (`2acec82f…`) is not the tested `d709ae38…36dc`. So I wrote the N19 test myself, from the re-audit's description:

- The fake systemctl's `restart` stops the unit. If `hold-restart` exists in its state directory, it adds a line to `held-restarts` and waits until the marker is gone before it starts the unit again.
- In the pin test, after the SIGTERM-during-validate step: SIGTERM when `held-restarts` reaches 1 (pin's own restart; the helper's `subprocess.run` kills the held systemctl, so the agent and `es.service` are down). Then SIGTERM again when it reaches 2 (the rollback's restart). Wait 0.5 s, then release.
- The report must be `failed` with "rolled back: stopped by SIGTERM" and not "rollback failed". `agent.conf` must equal the original, both units must run, and the agent ID must be unchanged.

With N19 (the handler keeps handling further signals), the second SIGTERM cuts the rollback short: "pin failed (…) and the rollback failed too", and the agent stays down. Killed.

## 3. Merge of trunk_dev 400ff7f

`690db9a` merges `400ff7f` (#29 and #36, after `76c030f`) into `26c7cf8`. Its tree `0467d411…` is the same as `git merge-tree --write-tree 26c7cf8 400ff7f` and the auditor's trial merge. Only `PLANS.md` is touched by both sides, and git merged it on its own. The range `400ff7f..9993c62` touches exactly the five manifest paths.

PR #39 (open, draft) moves the root's Remote Alpha script tests into `scripts/`. If it lands first, `remote_alpha_spire_agent_test.go` moves with it and resolves repository paths through `internal/testutil`. That move needs a narrow re-check (manifest, helper tests as root and as `ci`, #39's path guard), as re-audit section 6 says. Nothing in this PR depends on the order.

**trunk_dev moved again.** Just before the push, `trunk_dev` advanced to `0aa4a2b` (#33, `es/config` tests only). It shares no path with this PR, and `git merge-tree --write-tree 9993c62 0aa4a2b` is clean, with exactly the five manifest paths differing from `0aa4a2b` (`05-evidence/trial-merge-0aa4a2b.txt`). I did not merge it: the brief named `400ff7f`, and ES requires an up-to-date branch at merge anyway, so the update belongs to the merge gate.

## 4. Tests

All 8 helper tests (the 7 before, plus `GroupMembersCountPrimaryGroup`) pass as root on the committed head `9993c62` (`05-evidence/helper-tests-root-9993c62.log`: pin 41 s, recover 60 s). They also pass as user `ci` within the full root package (section 6). gofmt, `go vet`, pyflakes and `bash -n` are clean (`lint-9993c62.txt`).

## 5. Mutation checks

48 mutants: the 43 from round 3 with N13 re-anchored to the new quoted-key rule, plus R1, R2, N17b from the re-audit, plus N17c and N17d (each removes one of the other two signal holds). Each was run on a fresh copy of the working tree holding the final `.py` and test file (`05-evidence/mutations/`).

| Result | Mutants |
|---|---|
| **45 killed** | M01-M10; A02, A03, A05-A11; N01-N15 (N13 re-anchored), N04b, N21, N22, N24, N25; **N17, N17b, N18, N19** (survivors last round, now killed by the R34-2 tests); **R1, R2** (R34-1) |
| **3 survive, predicted** | N23 (no hold around `Popen`; the auditor accepts it). N17c: no hold in `restore_config`, where the window is one `atomic_write` and a read-back. N17d: no hold in `rollback_data_dir`, where the window is two `rename` calls. Neither can be held open from outside without a hook in the helper. Like N23, each is a few lines that read correctly. |

## 6. Validation

| Check | Result |
|---|---|
| Helper tests as root, head `9993c62` | 8/8 pass (pin 41 s, recover 60 s) |
| Full root package as user `ci` (uid 1500, gid 1600, `env -i`), head `9993c62` vs base `400ff7f` | head 2309 verdicts (2065 pass, 244 fail), base 2266 (2022 pass, 244 fail). **0 failing only on head, 0 skips on either side.** The 43 tests and subtests only on head are the helper's, all pass. The 244 failing on both (30 top-level tests: TLS-status, operator and grammar-diagnostic fixtures) are the same 244, name for name, as in last round's run on `26c7cf8`; they fail on the base too and come from this container. Run directories' trees equal the commits' trees (section 7). |
| gofmt, `go vet .`, pyflakes, `bash -n` | clean |
| Mutants | 45/48 killed, 3 predicted survivors (section 5) |
| Manifest v2 | two byte-identical runs; every committed blob matches (section 7) |
| GitHub CI ("build, vet and test") on `9993c62` | success ([run 45283590343](https://github.com/evo-agi/Execution-Substrate/actions/runs/45283590343/job/138074040852), 22:51Z to 23:20Z) |
| Box | not touched |

## 7. Provenance

- Recipe `governed-execution.audit-patch-manifest.v2`, SHA-256 `c08597e2…a3ca`, verified before each run.
- Taken with HEAD reset (`--mixed`) to `400ff7f`, the branch checked out, upstream pinned to `origin/trunk_dev`, nothing staged, and the final bytes in the working tree. Run twice into a fresh 0700 directory outside the repository: byte-identical. HEAD then went back to the merge commit, and the three changed files were committed.
- After the commit: `git diff --name-only 400ff7f 9993c62` equals the manifest's 5 paths, and every committed blob matches the manifest's SHA-256, size and mode (`05-evidence/manifest-v2-checks.txt`).
- O-R1 (the root-package runs could not be tied to the commits): the run directories are now committed with `git add -f -A`, so files that `.gitignore` excludes but the repository tracks (two `.examples/**/dist/*.tar.gz`) are included. Their tree hashes equal the commits' trees: head `2495190…` = `9993c62^{tree}`, base `c6415fd…` = `400ff7f^{tree}`. Last time the plain `git add -A` dropped those two files from the throwaway commits, which is why the tree did not match. The files were present in the run directories both times.

## 8. Still open (unchanged unless stated)

- N23, N17c, N17d: windows a few system calls wide, protected by construction and review.
- O-R2: the redact-before-cut reads the first 1 MiB of `attest.log`. That is harmless at under 60 s of agent log, so I left it.
- O-R3 / audit 02 items: the `mkstemp` window in `atomic_write`; no rollback after a successful attestation; `validate` makes a broken binary show as attention; A04, A12, O34-8 to O34-10.
- For the red-team (re-audit section 9): more HCL spellings against `status` and `pin`. Also, whether `-trustBundle` in the agent unit's `ExecStart` should replace parsing `agent.conf`, which is a box unit change outside this PR. And signals at the points the new tests hold.

## 9. Evidence

`/mnt/project-files/reports/Execution-Substrate/spire-bundle/05-evidence/` (checksums in `SHA256SUMS.txt`):

- `manifest-v2-9993c62.json`, `manifest-v2-checks.txt`, `range-paths-400ff7f..9993c62.txt`
- `helper-tests-root-9993c62.log`, `environment.txt`
- `root-package-head-9993c62-ci.json.gz`, `root-package-base-400ff7f-ci.json.gz`, their `.env.txt` (with the run directories' tree hashes), `root-package-compare-head-vs-base.txt`
- `mutations/`: `mutations.py.txt`, `results-final-9993c62.txt`, `logs-final/` (test-fixture token UUIDs replaced with `<test-uuid>`)
- `auditor-diff-review.txt`: diff sha256, apply check, resulting file hashes, and the missing N19 hunk
- `writer-changes-over-auditor-diff.diff`: exactly what I added on top of the auditor's diff (4 hunks)
- `trial-merge-0aa4a2b.txt`, `lint-9993c62.txt`, `compare_json.py.txt`, `run-root-pkg.sh.txt`, `mutations/run2.sh.txt`
