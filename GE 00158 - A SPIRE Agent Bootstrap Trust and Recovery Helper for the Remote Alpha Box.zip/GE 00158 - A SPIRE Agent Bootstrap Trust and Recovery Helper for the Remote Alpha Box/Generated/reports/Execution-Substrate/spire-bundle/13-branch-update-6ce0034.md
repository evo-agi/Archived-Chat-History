# INF-14 / ES PR #34: branch update to trunk_dev 6ce0034 (report 13)

Writer report, 2026-11-24 ~02:05Z. Scripts-only PR. No box access, no secrets.

## What changed

CI on 17afef1 passed (run 45304849290, 01:24Z to 01:56Z), and the delta check
(12-delta-check.md) accepted that head. By then trunk_dev had moved from 523648c
to 6ce0034 (#42, es/app tests only), so the PR was behind again and could not
merge under the "up-to-date branch" rule. I merged trunk_dev into the branch.

| | |
|---|---|
| New head | 7e6afdebdce363ec97c4b66026b8a55109e50d68 (parents 17afef1, 6ce0034) |
| Tree | ee6b3306223050fe8048801f3c3da9c9eb2e9a2c = `git merge-tree --write-tree 17afef1 6ce0034` (no conflicts, no hand edits) |
| Base | 6ce00347c6d3d90d8d11649e925927f539437f74 |
| Manifest v2 | 00b287b3fd758615b14500ae1a78d60039c04cfad13e941fe560478edb40c485 (two runs identical; tool sha c08597e2…a3ca checked before each run) |

## Why nothing in the PR changed

- PR patch byte-identical across all three syncs: `git diff 4c991ba bd998e2`,
  `git diff 523648c 17afef1` and `git diff 6ce0034 7e6afde` all hash to
  cbf9c2d5…1eb4.
- The new manifest's file entries equal those of 7b817443 (17afef1) and
  05ed7f49 (bd998e2); only the `head` field, which records the base commit the
  manifest was taken against, differs.
- #42 touched only es/app/operator_scripts_integration_test.go,
  es/app/submit_integration_test.go and es/app/test_ports_test.go, none of
  which is a PR path.
- The five PR blobs at 7e6afde are unchanged (list in 13-evidence/checks.txt).

So 12-delta-check.md applies to 7e6afde; a provenance re-check needs only to
confirm the clean merge-tree and the identical patch.

## Evidence

13-evidence/: manifest-v2-7e6afde.json, checks.txt, SHA256SUMS.txt.

## Next

CI on 7e6afde (about 32 minutes), provenance re-check, then the merge gate.
If trunk_dev moves again before the merge, the same sync repeats. The box run
waits for David's go.
