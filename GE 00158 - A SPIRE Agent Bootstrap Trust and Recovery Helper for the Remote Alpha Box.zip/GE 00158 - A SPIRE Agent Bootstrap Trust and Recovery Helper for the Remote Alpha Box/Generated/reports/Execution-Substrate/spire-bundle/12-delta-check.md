# Delta check of PR #34 at bd998e2 and 17afef1 (INF-14, sync with #37, #39 and #43)

**Verdict: ACCEPT for both heads.** At `bd998e2` the only change from the accepted `9993c62` is the test file's move into `scripts/`: a package rename and `Dir` set to the repository root on all 14 commands, with no test logic changed. CI passed there. `17afef1` is `bd998e2` plus git's own merge of `523648c` (#43, README only), with an identical patch and manifest `7b817443…e489`. Its CI was still running at 01:28Z, and the gate must see it pass.

```text
00:50-01:28Z 2026-11-24, audit clone, read-only, nothing pushed
head bd998e23…  = 9993c62 (accepted) + merge 188a859 (725c97a, checked in 09) + merge 270a881 (4c991ba) + move bd998e2
270a881 tree d9aada0d… = git merge-tree --write-tree 188a859 4c991ba (git's own merge); 4c991ba is an ancestor
bd998e2 vs 270a881: one rename, remote_alpha_spire_agent_test.go -> scripts/ (R098), nothing else
4 other PR blobs at bd998e2 = at 9993c62 (docs, PLANS.md, the .py, the .sh)
test file 542af77b -> b6731cc8, read line by line (12-evidence/test-file-9993c62-vs-bd998e2.diff):
  package executionsubstrate_test -> scripts_test; 14 exec.Command calls, 14 "X.Dir = executionSubstrateRepoRoot";
  5 inline calls split into var + Dir + the same call; no other line changed, no assertion, wait or value touched
  executionSubstrateRepoRoot = testutil.Root (absolute, from #39); mustRead resolves against it;
  every other path in the file is already absolute (temp dirs, CI's $RUNNER_TEMP tarball, Root joins)
v2 (recipe c08597e2…a3ca, HEAD reset to 4c991ba, upstream origin/trunk_dev), two runs in a fresh 0700 dir:
  manifest_sha256 05ed7f49d394775f43710324884d5ed44d24a4e4f6079ff4ed6332835f439caa, 5 files
  textual_diff_sha256 bdd63d91…2e12 (unchanged: it covers the 2 tracked files; the moved test file is untracked)
  runs byte-identical, and byte-equal to 10-evidence/manifest-v2-bd998e2.json
go test -count=1 -run '^TestRemoteAlphaSPIREAgent' ./scripts as root, Go 1.26.5, pinned SPIRE tarball:
  8/8 PASS, 43 PASS lines (same as 06), 0 skips, 67.4 s; ./internal/testutil (#39 layout checks) ok
CI on bd998e2: run 45299459683, job 138128162557 "build, vet and test": success, 00:43Z to 01:22Z
17afef1 = bd998e2 + merge of 523648c (#43, README.md only; parent 4c991ba):
  tree 72cd6531… = git merge-tree --write-tree bd998e2 523648c; git diff 4c991ba bd998e2 = git diff 523648c 17afef1
  5 PR blobs at 17afef1 = at bd998e2; v2 against 523648c, two runs byte-identical and equal to
  11-evidence/manifest-v2-17afef1.json: manifest_sha256 7b8174430d88487c0494dd59a091c7316f42542476c33e85a1c39b8969d6e489,
  differing from 05ed7f49 only in "head"
  CI on 17afef1: run 45304849290 in progress at 01:28Z (started 01:24Z)
closing ls-remote 01:27Z: branch 17afef11…, trunk_dev 523648cc… (unchanged since the checks)
```
