# Branch update of PR #34 to trunk_dev 725c97a (INF-14), for the provenance-only re-check

**Result: the audited patch is unchanged. Head `188a859` is `9993c62` (ACCEPT in re-audit 06 and red-team 07) plus git's own merge of `trunk_dev` `725c97a`. The 5 files are byte-identical to the audited ones and the patch against the new base is byte-identical to the audited patch. Ready for the provenance-only re-check, then the merge gate.**

```text
BRANCH UPDATE REPORT
Repository:        evo-agi/Execution-Substrate
Accepted target:   base 400ff7faa0f124b10dbb607fbad009e346bac4df, head 9993c62e9faf6e6ecb87f4ce326a93d352a117ec,
                   manifest_sha256 872f41db4343d16060a03220d120aee1a808686e26e62a9205478a066d303890
                   (06-re-audit.md ACCEPT, 07-redteam.md ACCEPT, no findings)
New base:          origin/trunk_dev 725c97a9663df060e49270fce3bc8c904a88986e (#33 0aa4a2b, #41 725c97a)
New head:          188a859fabab9d2a0168de0f1240cebdb3f7ff5c = merge of 725c97a into 9993c62
Tree:              169490741a81da13cea36f3a100ae9ce99603aae (= git merge-tree --write-tree 9993c62 725c97a)
v2 manifest:       manifest_sha256 a36d3ec35972e31c2eb1e0d035db4abecac629c4f1cc1125cb2204fbc2c93489
                   textual_diff_sha256 bdd63d91404cfa9964d2368d43f0993dff68cd549af96b400e3c057600272e12 (unchanged)
                   5 files; files list identical to 872f41db; only the "head" field differs
                   tool sha256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca verified
Final status:      clean; upstream re-pinned to origin/trunk_dev after the push
Effect status:     TOPIC_BRANCH_PUSHED | MERGE_NOT_PERFORMED | BOX_RUN_NOT_PERFORMED
```

## What changed

- `trunk_dev` moved from `400ff7f` to `725c97a` with #33 and #41. Together they change 4 test files under `es/config/` and `internal/contracts/runtimeconfig/v1/`. None of them is one of this PR's 5 paths.
- `188a859` merges `725c97a` into `9993c62`. Its tree equals `git merge-tree --write-tree 9993c62 725c97a`, so there are no hand edits. There were no conflicts.
- PR #39 has not landed, so `remote_alpha_spire_agent_test.go` stays at the root.

## Checks

| Check | Result |
|---|---|
| `git range-diff 400ff7f..9993c62 725c97a..188a859` | all 4 commits `=` (unchanged) |
| `git diff 400ff7f 9993c62` vs `git diff 725c97a 188a859` | byte-identical |
| Manifest v2, two runs into a fresh 0700 directory | byte-identical; `textual_diff_sha256` unchanged; files list identical to the audited manifest |
| Committed blobs at `188a859` vs the manifest | all 5 match sha256, size and mode |
| Helper tests as root on `188a859` | 8/8 pass (pin 39 s, recover 57 s) |
| `go vet .` | clean |
| GitHub CI on `188a859` | running at push time; result to follow in the merge report |
| Box | not touched |

## Evidence

`/mnt/project-files/reports/Execution-Substrate/spire-bundle/08-evidence/` (checksums in `SHA256SUMS.txt`): `manifest-v2-188a859.json`, `manifest-v2-checks.txt`, `range-diff-400ff7f..9993c62-vs-725c97a..188a859.txt`, `helper-tests-root-188a859.log`.
