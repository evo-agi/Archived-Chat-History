# Narrow red-team of the SPIRE agent bootstrap and recovery helper (INF-14, PR #34)

**Verdict: ACCEPT. No finding. I could not make `status`, `pin` or `recover` report a false "pinned", let an agent attest unpinned or against a different bundle, or leave the box unrecoverable or with an orphaned agent, within the threat model (an attacker who is not already root or the `spire` account).** The two prior findings (R34-1, R34-2) hold closed on the real binary. The residual survivors accepted in re-audit 06 are inherent few-syscall windows that only turn a failed run into a differently-worded failed run; I agree with accepting them. Four items are observations and box checks, no change required.

```text
NARROW RED-TEAM REPORT
Repository:        evo-agi/Execution-Substrate
Target:            base trunk_dev 400ff7faa0f124b10dbb607fbad009e346bac4df
                   topic claude/project-thread-wg7jh5 at 9993c62e9faf6e6ecb87f4ce326a93d352a117ec
                   tree 24951907803a3002778619aad2a9374237f593f6
                   recipe governed-execution.audit-patch-manifest.v2, source sha256
                   c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified)
                   manifest_sha256 872f41db4343d16060a03220d120aee1a808686e26e62a9205478a066d303890, 5 paths
Prior reports:     01-implementation, 02-audit (BLOCK, fixed), 04-re-audit (BLOCK, fixed),
                   05-repair, 06-re-audit (ACCEPT). This is the narrow red-team they each recommend.
Posture:           separate from writer and auditor; read-only on the repo; nothing pushed; no PR comment;
                   nothing run on the Linux box. Real SPIRE 1.14.4 and all probes ran in one cloud container.
Provenance:        REPRODUCED. Two v2 runs into a fresh 0700 directory, byte-identical, and byte-equal to
                   05-evidence/manifest-v2-9993c62.json. Closing run equal to the opening one (section 6).
Final verdict:     ACCEPT (no finding; 4 observations)
```

## 0. In plain words

The helper's one job is trust: make sure the box's SPIRE agent only ever bootstraps against the real server's CA bundle, and bring the agent back if its certificate expired, without the token ever leaking. I tried to defeat each of those.

- **I could not get a false "pinned".** I wrote `agent.conf` files in every odd way I and the earlier audits could think of, so that SPIRE would actually load a *different* bundle file than the one the helper names. On the real `spire-agent` binary, every such file is refused by the helper's own reading of the config (it reports "unrecognized", not "pinned"). I confirmed with SPIRE itself which bundle file it loads for each one.
- **I could not make `recover` attest insecurely.** `recover` always puts `-trustBundle` on the agent's command line, and I confirmed that real SPIRE then refuses to start at all if the config still reads as "trust anyone". So even a config that somehow slipped past the helper's reading could not attest unverified.
- **The file handling, the token redaction, the malformed-input handling and the lock all fail closed.** Symlinks, named pipes and oversized files are refused; a join token never survives into any printed report even when SPIRE's own log quotes it.

What is left is what re-audit 06 already accepted: a few places inside the helper where a stop signal arriving in a window a few instructions wide would turn one kind of failed run into another kind of failed run. None of these is a way in for an attacker, and none produces a wrong trust decision. I agree with leaving them.

## 1. Threat model

The helper runs as root on the box. The adversary I took seriously is **anyone who is not already root or the `spire` service account**: a workload, a logged-in operator without sudo, a compromised unprivileged process. An attacker who is already root, or who already controls the `spire` account (which owns the agent's data directory and answers the admin socket), by definition already owns the workload identity this helper protects; INF-14 and audit 02 both treat that as out of scope, and I kept to that. Within the in-scope model the attacker's levers are: the contents of files the helper reads, the output of commands it runs, and signals it can send.

The three goals from the brief, mapped to the code:
1. **False "pinned"** — `analyze_agent_config` plus `spire_confirms_pinned` in `status` and `pin`.
2. **Attest unpinned or against a different bundle** — `recover` → `Pinning.inspect`/`apply_config` → `attest_once` (the `-trustBundle` run).
3. **Unrecoverable box or orphaned agent** — `recover`'s swap, `attest_once`'s cleanup, `rollback_data_dir`, and the signal handling around them.

## 2. Method and setup

- Reproduced the manifest at `9993c62` (section 6): byte-identical to the writer's and the auditor's.
- Downloaded the pinned SPIRE release `spire-1.14.4-linux-amd64-musl.tar.gz`; its sha256 is `4482db43…bcbf5`, equal to `scripts/internal/spire_release.sha256`. The extracted `spire-agent` binary is sha256 `e23f49a4164f9a742794e28e746684a2de072c1d5abf7ff4fed2a97b032a81e3`, the same binary the box runs and the earlier auditor used.
- Ran the committed test suite as root on the exact `9993c62` bytes: **8/8 pass** (`tests/helper-tests-root-9993c62.log`, 59.6 s). This is an independent reproduction of the writer's and auditor's root runs.
- Probed the three goals directly against the real binary and against the helper's own functions (imported from the committed `.py`). Harnesses and raw output are in `07-redteam-evidence/probes/`.

Not run (relied on 05/06, which ran them, plus CI run 45283590343 green): the full root package as the unprivileged `ci` user, and anything on the box. My independent work was the root suite plus the targeted probes below.

## 3. What I attacked, and what held

### 3.1 False "pinned" — HELD CLOSED

I built `agent.conf` variants that try to make the helper classify the file as `pinned` (naming the real bundle) while HCL, SPIRE's own parser, loads a *decoy* bundle. The decoy path points at a nonexistent file, so when SPIRE reads it, `spire-agent run` names it in its log; that is the oracle for "which file did SPIRE actually load" (`probes/hcl-aliasing-and-recover-oracle-9993c62.out`).

| Variant | Scan (`analyze_agent_config`) | `validate` plain / `-trustBundle` | Bundle SPIRE actually loads |
|---|---|---|---|
| honest pinned (control) | **pinned** | 0 / 0 | the real bundle |
| second one-line `agent { trust_bundle_path = decoy }` | unrecognized (key outside a plain line) | 0 / 0 | **decoy** |
| long-s `truſt_bundle_path = decoy` (U+017F) | unrecognized (non-ASCII) | 0 / 0 | **decoy** |
| `"trust_bundle_path" = decoy` (quoted key) | unrecognized (a quoted key) | 0 / 0 | **decoy** |
| decoy after a nested block's `}` | unrecognized (value mismatch) | 1 / 1 | — (SPIRE also rejects) |
| commented `# trust_bundle_path = decoy` | unrecognized (count) | 0 / 0 | the real bundle |
| heredoc swallow (original A34-1) | unrecognized (a heredoc) | 0 / **1** | — |
| `insecure_bootstrap = true` | insecure (correct) | 0 / **1** | — |

The key result: **in every case where SPIRE would load the decoy, the scan returns `unrecognized`**, so `status` and `pin` report "attention", never "pinned". There is no spelling that is `pinned` to the scan and a different bundle to SPIRE.

Worth recording precisely, because it tells the writer where the defense really lives: the three decoy-loading variants **pass both `validate` calls** (rc 0/0) even though SPIRE loads the decoy. So `spire_confirms_pinned` does **not** catch an aliased bundle path on its own — `validate` does not open the bundle file. The guard that stops these is the **scan's** refusal of non-ASCII characters, quoted keys, and any textual occurrence of a bootstrap key that is not one clean in-block line (the `text.lower().count(...)` check). `spire_confirms_pinned` is reached only after the scan has already said `pinned`, and its job is the other half: rejecting a config SPIRE reads as *insecure* (heredoc swallow, `insecure_bootstrap`) — which it does, via the `-trustBundle` run returning rc 1. The two mechanisms together are complete; neither alone is. The code's structure already reflects this, so no change is needed, but the `spire_confirms_pinned` docstring's "a config that passes both is read by SPIRE with the one trust_bundle_path line the scan saw" is only true *given* the scan's prior refusals — it is not a property of `validate` by itself.

I could not find a new aliasing channel beyond the three the earlier audits found. Reasoning: after the hardening, scan=`pinned` requires exactly one clean in-block `trust_bundle_path` line with the byte-exact value and **zero** other textual occurrences of any bootstrap key (the count check), with no non-ASCII and no quoted key. Any second source HCL could honor leaves a textual trace the count catches, or needs Unicode folding or an escaped key, both refused. The only residual key spelling is ASCII letter-case, which the case-insensitive count also catches.

### 3.2 Attest unpinned or against a different bundle — HELD CLOSED

`recover` runs the attesting agent with `-trustBundle <bundle> -trustBundleFormat pem` (`attest_once`, line 1372-1374). I confirmed on the real binary that `spire-agent run` with `-trustBundle` **refuses to start** if its own reading of `agent.conf` is insecure: `only one of insecure_bootstrap or trust_bundle_path can be specified, not both` (same probe file). So even a config that passed the scan as `pinned` but that SPIRE read as insecure could not attest. And `recover` reaches `attest_once` only after `Pinning.inspect()` has already refused any `unrecognized` config and `apply_config()` has put the file into the pinned state. The bundle the `-trustBundle` flag names is the one `apply_bundle()` just wrote from `export_server_bundle` (read as `spire` over the validated admin socket), so the attesting agent trusts the real server's current CA set. Two independent guards, both confirmed.

### 3.3 Unrecoverable box or orphaned agent — HELD CLOSED

- **File handling** (`probes/file-safety-9993c62.out`): `read_regular_file` refuses a final-component symlink (`O_NOFOLLOW` → ELOOP), a FIFO (`O_NONBLOCK`, then "not a regular file" — no hang), and an oversized file. An intermediate *directory* symlink is followed (`O_NOFOLLOW` guards only the final component), but every parent directory the helper reads under (`/etc/spire/agent`, `/var/lib/spire/agent`) is root- or `spire`-owned, so swapping one is out of the in-scope model.
- **Malformed command output** (`probes/parser-and-redaction-9993c62.out`): the PEM parser refuses empty, non-PEM, private-key blocks, CRLF, bad base64 and trailing text; `server_json` turns non-JSON into a typed `CommandError`. All fail closed.
- **Token custody and redaction**: redacting the document tree (not serialized JSON) removes a registered token and rewrites a `join_token/<id>` agent ID to `join_token/<redacted>` while keeping the JSON valid — the A34-2 class stays fixed, including SPIRE's `spiffe_id="…"` log shape.
- **Lock**: `take_lock` opens `O_NOFOLLOW`, checks owner == euid and a regular file, then `flock(LOCK_EX|LOCK_NB)`; a second run is refused. In `/run`, which is root-owned.
- **Signals**: `recover` and `pin` install handlers that raise `Interrupted` and then ignore further stop signals, and wrap each cleanup/rollback in `signals_deferred()`. The surviving mutants N17c, N17d, N23 and N17e (accepted in 06) are windows a few system calls wide (one `atomic_write`, two `rename`s, an `rmtree`, the fork-to-`Popen` gap) that wait on no other process, so no external signal timing can hold them open; and a stop signal that did land there would only change one failed-run message into another, with the on-disk rollback still driven by `rollback_data_dir` reading actual state. I reproduced none as a security effect and accept all four.

## 4. Observations (no change required)

- **O-RT1 (box item).** The security of a normal boot rests on the systemd unit running `spire-agent run -config agent.conf` **without** `-trustBundle` (only `recover`'s one-shot run adds it). So at boot the trust decision is made by `agent.conf` alone, which is exactly what the scan plus plain `validate` protect. A sturdier design, noted by audit 02/04 and which I endorse as the coordinator's call, is to put `-trustBundle` in the agent unit's `ExecStart` so no boot ever depends on parsing `agent.conf`. That is a box unit change, outside this scripts-only PR.
- **O-RT2 (box item).** `spire-agent` has an `-expandEnv` flag. The helper never passes it, so `${VAR}` in `agent.conf` is not expanded by anything the helper runs, and the scan's byte-exact value check would in any case refuse a `trust_bundle_path` value containing `$`. If the box's unit enables `-expandEnv`, the box run should confirm the real `agent.conf`'s bundle path is a literal. Not reachable in-scope.
- **O-RT3.** SIGKILL to the helper during `attest_once` is uncatchable and would leave the attesting agent (its own session) running and the token file on disk (0600 `spire`, single-use, 120 s). This is inherent to any process and already noted; the exposure is bounded and not to an unprivileged user.
- **O-RT4.** `--evict-old-agent` deletes only entries whose parent is the *old agent ID*, not the alias, so the box's workload entries (parented to the alias) survive; the evict-exactness test pins this. The flag still needs the operator's explicit go, per the contract.

## 5. Recommendation

- **Merge is not blocked by the red-team.** No finding. The scripts-only merge gate (audit + this red-team + an up-to-date-branch check) is satisfied on the red-team side.
- At the merge gate, bring in the current `trunk_dev` (`725c97a` at the close; its trial merge is clean and shares no path, per 06 §5) and do the provenance-only re-check on the new head.
- If PR #39 lands first, move `remote_alpha_spire_agent_test.go` with it and do the narrow path re-check from 04 §6.
- Carry O-RT1 and O-RT2 into the box-run brief.

## 6. Closing provenance

At 23:53Z, after the suite and all probes:

```text
tool sha256           c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified)
git ls-remote origin: claude/project-thread-wg7jh5 = 9993c62e…  (unchanged)
                      trunk_dev = 725c97a9…  (moved by #33/#41; 06 §5, trial merge clean)
working clone         HEAD 9993c62e…, git status --porcelain empty
python3 -I v2 (fresh 0700 dir, umask 022): manifest_sha256 872f41db…3890,
                      textual_diff_sha256 bdd63d91…2e12, 5 files; close == open, byte-identical,
                      and byte-equal to 05-evidence/manifest-v2-9993c62.json
```

Copies: `07-redteam-evidence/provenance/manifest-v2-open.json`, `manifest-v2-close.json`.

## 7. Confidence

- Provenance: high (reproduced, open == close, equal to the writer's).
- False "pinned" and attest-unpinned closed: high — tested against the real binary with a bundle-load oracle, and the reasoning covers the remaining spelling space.
- Unrecoverable/orphaned closed within scope: high for the file, parser, redaction and lock paths; medium only on the box-specific pieces (systemd, setpriv, boot), which are unchanged since 06 and are box items.
- That I found every break: medium-high. Three prior adversarial passes plus this one converge, and the design confines each goal to a small, tested surface.

## 8. Effect status

Red-team only: no repair commit, push, PR comment, merge or box action by this thread. The one change outside the repo is this report and `07-redteam-evidence/`. Real SPIRE and all probes ran in this container; the test CA files were generated here and are not in the evidence. No token, key, box data or personal data is in the evidence (scanned). Scratch trees were left in the container only; the manifest clone is clean.

## 9. Evidence

`/mnt/project-files/reports/Execution-Substrate/spire-bundle/07-redteam-evidence/` (`SHA256SUMS.txt` lists every file):

| Path | Content |
|---|---|
| `environment.txt` | container, kernel, Python, Go, SPIRE tarball and binary sha256 |
| `tests/helper-tests-root-9993c62.log` | the committed suite, 8/8 as root |
| `probes/hcl-aliasing-and-recover-oracle-9993c62.out` | §3.1 and §3.2: scan, both validates, and the bundle-load oracle per variant |
| `probes/file-safety-9993c62.out` | §3.3 symlink / FIFO / oversize / intermediate-symlink |
| `probes/parser-and-redaction-9993c62.out` | §3.3 PEM refusals and the redaction tree |
| `probes/classify.py`, `filesafe.py`, `robustness.py`, `oracle.sh`, `variants/` | the harnesses and the exact config variants, as run |
| `provenance/manifest-v2-open.json`, `manifest-v2-close.json` | the two reproduced manifests |
