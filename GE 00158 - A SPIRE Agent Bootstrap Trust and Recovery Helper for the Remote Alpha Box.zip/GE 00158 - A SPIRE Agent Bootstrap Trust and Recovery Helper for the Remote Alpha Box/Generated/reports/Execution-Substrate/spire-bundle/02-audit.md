# Independent audit of the SPIRE agent helper (INF-14, PR #34)

**Verdict: REPAIR NEEDED (protocol verdict `BLOCK`). No high or critical finding, and no way for an unprivileged process to get the token or make `recover` trust a rogue server. But the PR's central security claim for `recover` ("pins first, so it never bootstraps with `insecure_bootstrap`") rests on a line scan that SPIRE's own config parser can disagree with, and no test pins it. Two failure paths also lose the report or skip the rollback. A tested fix diff is attached: with it, 7/7 tests pass as root and as an unprivileged user, and 9 of the 11 mutants that survived on the PR are killed (the other two are observations).**

```text
INDEPENDENT AUDIT REPORT
Repository:        evo-agi/Execution-Substrate
Audit target:      base trunk_dev 8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce
                   topic claude/project-thread-wg7jh5 at 09279115ef4ae736777174e9d3293a9741571701
                   tree afddc143f459bdb84213c0c1249886c75300c515
                   recipe governed-execution.audit-patch-manifest.v2, source sha256
                   c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified)
                   manifest_sha256 2632287f9e61b11facbc0ecf9742015bcb2f29ce37e3855756eac1299527d790, 5 paths
Writer report:     reports/Execution-Substrate/spire-bundle/01-implementation.md, sha256 d5ee56a1…4122 at
                   the start (verified). The writer edited it at 20:03:38Z (now bdb58c9e…5f4d), which
                   matches recording the CI result (completed 20:02:51Z). Its manifest values are unchanged.
Audit posture:     read-only on the repo; no subagents; nothing pushed; no PR comment; nothing run on the
                   Linux box. Tests, mutants and probes ran on copies outside the audit clone.
Provenance:        REPRODUCED. Two v2 runs to fresh paths in a 0700 directory, byte-identical, equal to
                   the reported canonical manifest. Closing run equal to the opening one (section 9).
Final verdict:     BLOCK (repair needed: 1 medium, 3 low findings; fix diff tested)
```

## 0. In plain words

The helper does what it says in every case a person would set up. I checked the parts that matter most for security directly against real SPIRE 1.14.4:

- **The token stays private.** It is never on a command line, in the environment or in the output. SPIRE itself writes the token into its log only after the token has been used (I checked an expired token and a server that was down: neither run logged it).
- **Pinning fails closed.** I swapped an impostor SPIRE server in on the real server's port *in the middle of a real `recover` run*, after the helper had read the bundle and made the token. The agent refused the impostor ("certificate signed by unknown authority"), the impostor got no agent, and the helper put the old data back.

What needs fixing before merge:

1. **(Medium)** Whether `recover` attests with a pinned config depends on the helper's own reading of `agent.conf`, line by line. SPIRE reads the file with a real HCL parser. That parser ignores case in key names and accepts quoted and escaped keys and multi-line strings. I built an `agent.conf` that the helper calls "pinned" while SPIRE reads it as `insecure_bootstrap = true` and accepts it. By my reading of the code, `status` says "ok" on that file and `recover` would bootstrap without verifying the server. Only root can write that file, and nobody would write it by accident, so this is not a practical attack. But it is the one property this PR exists for, and no test pins it: a version of `recover` that attests first and pins afterwards passes every test. The fix is one change to the attesting command (`-trustBundle <file>`), which makes SPIRE itself refuse to start unless it really is pinned, plus three tests.
2. **(Low)** If a failure message contains SPIRE's own log line naming the new agent (`spiffe_id="…"`), the helper crashes while printing its report. The operator then sees a Python traceback instead of what happened and what was rolled back.
3. **(Low)** An SSH drop or Ctrl-C during the 1 to 60 seconds of attestation skips the cleanup. On SIGTERM or a hangup, the token file stays on disk (readable only by root and `spire`), a stray agent keeps running outside systemd, and the old data directory is not put back.
4. **(Low)** Several checks have no test: the admin-socket ownership check that the whole bundle trust rests on, the token lifetime, running as `spire`, the private directory's mode, one refusal, and `--evict-old-agent` deleting more than it should. That last one would silently delete ES's workload entry on the box.

I recommend a narrow red-team after the repair (section 7).

## 1. Provenance reproduction

```bash
V2=/mnt/project-files/operating-protocol/tools/governed_execution_audit_patch_manifest_v2.py
sha256sum "$V2"   # c08597e2…a3ca, equal to the pin in the project instructions
umask 022; git clone /home/user/Execution-Substrate /opt/audit/es; cd /opt/audit/es
git remote set-url origin https://github.com/evo-agi/Execution-Substrate
git fetch -q origin "+refs/heads/trunk_dev:refs/remotes/origin/trunk_dev" \
  "+refs/heads/claude/project-thread-wg7jh5:refs/remotes/origin/claude/project-thread-wg7jh5"
test "$(git rev-parse origin/claude/project-thread-wg7jh5)" = 09279115…    # tip-ok
test "$(git rev-parse origin/trunk_dev)" = 8ba1edb8…                       # trunk_dev has not moved
git merge-base --is-ancestor 8ba1edb8… 09279115…                           # ancestor-ok
git checkout -q -f -B claude/project-thread-wg7jh5 09279115…; test -z "$(git status --porcelain)"
git rev-parse HEAD^{tree}   # afddc143f459bdb84213c0c1249886c75300c515
git reset -q --mixed 8ba1edb8…; git branch -q --set-upstream-to=origin/trunk_dev
python3 -I "$V2" /opt/audit/manifest-open/1.json; python3 -I "$V2" /opt/audit/manifest-open/2.json
cmp …/1.json …/2.json        # identical
```

Result: `manifest_sha256 2632287f9e61b11facbc0ecf9742015bcb2f29ce37e3855756eac1299527d790`, `textual_diff_sha256 91658c83…b7740`, 5 files, byte-equal to the canonical manifest in 01-implementation.md section 9. No mode differences. Copies: `02-audit-evidence/manifest/open-{1,2}.json`.

The PR head on GitHub is `0927911` (base `8ba1edb`, draft, 2 commits).

**Base moved during the audit.** trunk_dev advanced to `76c030f` (PR #27) at about 20:15Z. The audit target stays `0927911` on `8ba1edb`. In a separate scratch clone, `git merge-tree --write-tree 76c030f 0927911` is clean (tree `3318a16e…`). The only path both sides change is `PLANS.md`. The helper's `.py` and test file are byte-identical in the merged tree, so the fix diff applies there unchanged. I did not run tests on the merge. The writer reports doing so (`01-evidence/trial-merge-76c030f.txt`). After the base merge, the new head needs the provenance-only re-check (provenance doc section 5.4).

## 2. Coverage

Read in full: `scripts/internal/remote_alpha_spire_agent.py` (1,395 lines), `scripts/remote_alpha_spire_agent.sh`, `remote_alpha_spire_agent_test.go` (1,693 lines), the new docs section in `.docs/system_overview/remote_supported_host_alpha.md` and the `PLANS.md` bullet. Also read: Addendum B and INF-14 of `reports/infra-security-audit.md`, the writer report and its evidence list, `.github/workflows/go.yml`, `scripts/72_supported_local_setup.sh` (the agent.conf template the tests copy), the SPIRE lines of the box inventory output (only to check the data and key directory layout; nothing copied from it), and `project-context/runbooks.md`.

Not inspected: the rest of the root package's tests (covered by the whole-package comparison in section 6 and by CI), and the real box (out of scope: no box access in this audit).

## 3. Findings

### A34-1. `recover`'s "never bootstraps insecurely" is enforced only by a line scan that SPIRE's parser can disagree with, and no test pins it. Medium. Security risk (defense in depth) and test gap. Patch defect.

**Contract:** docs section, "It first runs the same three pinning steps, so it never bootstraps with `insecure_bootstrap`"; writer report 2.3; Addendum B.3 step 3.

**Evidence, part 1: SPIRE reads keys that the scan does not see** (real `spire-agent validate`, SPIRE 1.14.4, binary sha256 `e23f49a4…81e3`, the same as the box's):

| `agent` block holds | SPIRE 1.14.4 | `analyze_agent_config` at 0927911 |
|---|---|---|
| `Insecure_Bootstrap = true` only | valid, insecure | unrecognized (refused) |
| `trust_bundle_path = "…"` and `Insecure_Bootstrap = true` | invalid: "only one of insecure_bootstrap or trust_bundle_path" | **pinned** |
| `"insecure_bootstrap" = true` and `trust_bundle_path` | invalid: "only one of …" | **pinned** |
| `admin_socket_path = <<EOT` / `    trust_bundle_path = "…"` / `EOT` / `Insecure_Bootstrap = true` | **valid**: the heredoc swallows the `trust_bundle_path` line and SPIRE reads `insecure_bootstrap = true` | **pinned** |

The last row is the dangerous one (probe `probes/hcl-key-aliasing.py.txt`, output `hcl-key-aliasing-0927911.out`). A `join_token = <<EOT` heredoc would not do: SPIRE refuses it next to `-joinTokenFile` ("only one of join_token or join_token_file"). By code reading, `status` reports `bootstrap: ok`. `Pinning.inspect()` accepts the file, `apply_config()` leaves it alone, and `attest_once` runs `spire-agent run -config agent.conf -joinTokenFile …` on a config that SPIRE reads as `insecure_bootstrap = true` with no trust bundle. Inference: that run bootstraps without verifying the server. I validated the config with `spire-agent validate` but did not run an agent on it against a server. The scan is at `scripts/internal/remote_alpha_spire_agent.py:620-671`. It counts keys case-sensitively (`text.count(key)`, line 654) and does not know heredocs or quoted keys.

**Evidence, part 2: the ordering is not tested.** Mutant A01 moves the three pinning steps in `mode_recover` from before `stop` to after `attest_once` (so the agent attests with the original insecure `agent.conf`, and is pinned only afterwards). It **survives** `TestRemoteAlphaSPIREAgentRecoverAgainstRealSPIRE`. The test checks only the end state ("trust_bundle_path" present, one backup). The writer's impostor proof (`PinAgainstRealSPIRE`) bootstraps from the pinned file directly, never through `recover`.

**Impact.** Exploitation needs an `agent.conf` written by root in a deliberately odd form, *and* a rogue server holding the server port at the moment of attestation (while `recover`'s preflight required the real server to be active). With honest configs, `recover` refuses an impostor: probe P5 swapped an impostor in on the server's port *during* a real `recover` run, after the bundle export and token generation. The agent logged "x509: certificate signed by unknown authority", the impostor's `agent list` stayed empty, the helper reported `failed` and put the old data directory back (`02-audit-evidence/probes/probe-p5-impostor-mid-recover-0927911.log`). So the medium rating is for the missing enforcement and test of the PR's main security property, not for a practical attack.

**Required correction** (in the tested diff, section 8):
1. `attest_once` passes `-trustBundle <bundle_path> -trustBundleFormat pem` to `spire-agent run`. Shown on SPIRE 1.14.4: with an `agent.conf` that SPIRE reads as insecure, the run refuses to start ("only one of insecure_bootstrap or trust_bundle_path can be specified, not both"). With the pinned `agent.conf` and the same path, it starts normally. So SPIRE itself enforces the pin, whatever the scan thinks.
2. `analyze_agent_config` refuses heredocs (`<<`) and quoted keys, and counts key names case-insensitively. Then `status` stops calling those files pinned.
3. Tests: the agent shim records, for each attesting run, whether the config text still names `insecure_bootstrap` and the trust bundle arguments. The recover test requires every attesting run to show `-trustBundle <bundle> -trustBundleFormat pem` and no `insecure_bootstrap`. Three new `ConfigAnalysis` cases: case variant, escaped quoted key, heredoc. On the PR code, the three cases fail ("state pinned, want unrecognized"). A01 is killed on the fixed code.

**Uncertainty:** none on the parser facts (tested). Guess: HCL v1 accepts further spellings I did not try. The `-trustBundle` change covers them all, because SPIRE judges its own parse.

### A34-2. The report renderer crashes when a message holds a quoted join-token agent ID. Low. Bug. Patch defect.

**Evidence.** `Report.document()` (line 187) runs the redaction regex over the *serialized* JSON: `json.loads(self.redact(json.dumps(doc)))`. The regex `(spire/agent/join_token/)[^\s\"'/,;)\]}]+` (line 140) stops at `"` but not at `\`. So in `…join_token/<id>\"…`, it swallows the backslash that escapes the quote, and `json.loads` fails. SPIRE 1.14.4 writes exactly that shape: `level=info msg="Node attestation was successful" … spiffe_id="spiffe://execution.internal/spire/agent/join_token/TOKEN"` (`probes/probe-run3-log-format.log`, token replaced). `attest_once` puts the agent log tail into the failure message (line 1291). So a recover attempt where the agent attests and then exits (for example, it cannot create its socket) ends in `json.decoder.JSONDecodeError`. The operator gets a traceback and no report, in both `--json` and text mode, and does not see that the rollback happened.

Reproduced two ways: a direct `Report` call (both with the token registered and without), and end to end. With the shim's crash line changed to print that SPIRE log line, the PR's own recover test fails with "printed no JSON report" and a `JSONDecodeError` traceback (`proposed-fix/pr-code-new-tests-root.log`). No token leaks: the traceback holds no values.

**Correction:** redact each string in the document tree, not the serialized JSON (`_redact_tree`). Test: the crash shim prints the SPIRE line with a fake agent ID; the crashed report must parse and hold `join_token/<redacted>` and not the fake ID.

### A34-3. Stop signals and OS errors during attestation skip the cleanup and the documented rollback. Low. Bug (secret-handling hygiene and robustness). Patch defect.

**Contract:** docs: the token is "never … logged by the helper"; "If the attestation fails, it moves the new data directory aside …, puts the old one back and leaves both units stopped." Writer report 4: "the directory is removed in a `finally`".

**Evidence** (probes on the PR's fixture, `probes/probe-run1-signals-oserror.log`, `probe-run2-oserror-tokenlog.log`):
- **SIGTERM** while the token file exists. Python's default action ends the process without running `finally`. Afterwards: `join-token` and `attest.log` still in `scratch/es-spire-agent-recover.*/`; the attesting `spire-agent` (its own session) **still running** outside systemd, free to attest with the token; the old data directory still under `agent.recover-*`; no report. SIGHUP (an SSH drop under sudo) has the same default action. Inference: same result; not run separately.
- **SIGINT** (Ctrl-C). `finally` runs (token file gone, agent stopped), but `KeyboardInterrupt` is not caught by `except (CommandError, Failure)` (line 1219): no rollback, and a traceback instead of a report.
- **OSError** inside the swap or attestation (probe: scratch parent missing, standing in for `mkdtemp` failing with ENOSPC on a full `/run`). The result is `failed`, but no rollback: the new empty data directory stays and the old one stays under `agent.recover-*`. The same applies to an OSError in `os.mkdir`, `os.chown` or `os.chmod` right after the rename (lines 1212-1214).

**Impact.** The token file is `0600 spire` in a `0700 spire` directory on tmpfs, and the token is single-use with 120 s life. So nothing reaches an unprivileged user. But the operator is left with an unmanaged agent, an un-rolled-back data directory and no report, during an outage.

**Correction:** SIGHUP, SIGINT and SIGTERM handlers raise `Interrupted`, a `Failure` subclass, and ignore further stop signals so cleanup can finish. The attest window catches `OSError` too. `rollback_data_dir` tolerates a missing new directory. Test: a SIGTERM step in the recover test, once the token file appears. It requires a `failed` report naming SIGTERM, no scratch entries, no surviving attesting agent, and the old data directory back. The mutant that removes the handlers (F02) is killed.

### A34-4. Security-relevant guards and refusals without a test. Low. Test gap. Patch defect.

My mutants on 0927911 (each one changes one line; results in `mutants/results-auditor-mutants-on-0927911.txt`):

| Mutant | Change | On 0927911 | With the fix diff |
|---|---|---|---|
| A01 | recover pins after attesting | survived | killed (SPIRE refuses; A34-1) |
| A02 | no check of the admin socket directory's owner and mode | survived | killed |
| A03 | no check of the admin socket's owner and mode | survived | killed |
| A04 | recover ignores a live server record for an expired local SVID | survived | survives (see below) |
| A05 | recover ignores "no entry under the alias" | survived | killed |
| A06 | token `-ttl 3600` instead of 120 | survived | killed |
| A07 | `token generate` not run as `spire` | survived | killed |
| A08 | attesting agent not run as `spire` | survived | killed (A08f, the same change on the fixed argv) |
| A09 | pin's restart-failure rollback skips the config restore | killed | not rerun (unchanged code) |
| A10 | private token directory 0755 | survived | killed |
| A11 | `--evict-old-agent` also deletes entries under the alias (the workload entry) | survived | killed |
| A12 | no lock | survived | survives (see below) |

A02 and A03 matter most: the bundle is trusted only because the admin socket can be answered by root or `spire` alone. A11 is an irreversible deletion on the SPIRE server: it would remove ES's workload entry, and the final `status` (`ok`) does not notice, because `status` does not fetch a workload SVID.

**Correction:** test additions in the diff:
- pin test: a world-writable socket directory and a 0666 socket are refused by `pin` and flagged by `status`, with nothing changed;
- recover test: refusal with no entry under the alias; `token generate` and the attesting run go through `setpriv`, with `-ttl 120`; private directory 0700;
- evict step: entry count unchanged (one alias added, one removed), and the workload entry still there.

A04 needs a server record that is live for an expired local SVID, which is hard to build in this fixture. The code (line 1159) reads correctly; I leave it as an observation. A12 is a single `flock` and is not worth a concurrency test.

### Observations (no change required)

- **O34-5.** `--evict-old-agent` runs `spire-server agent evict -spiffeID <old agent ID>`, so the old agent's *spent* token is briefly on a command line. It is harmless (single use, and SPIRE logs it anyway). The docs' "never … on any command line" is about the new token; the writer may want to say so.
- **O34-6.** The attest log tail is cut at 1,500 bytes and then redacted, so a token split at the cut would not match. SPIRE 1.14.4 logs a token only after it is spent (probe P4: an expired unused token and a server that is down log no token), so this is harmless.
- **O34-7.** `check_server_socket` reads the `spire` group's members from `gr_mem`, which omits users whose *primary* group is `spire`. It matters only if the socket directory is group-writable. The box's directory mode is Unknown (the inventory lists the socket, not its directory).
- **O34-8.** `status` checks that a boot rule exists for each runtime directory, not that it has the right owner and mode. It also does not judge whether the bundle file or `/etc/spire/agent` is writable by others. A bundle file that matches stays as it is, mode included. Not exploitable without root write access to `/etc/spire/agent`. Box mode Unknown.
- **O34-9.** The box's real `agent.conf` bytes are not in the inventory output I could read. The tests copy `scripts/72_supported_local_setup.sh`'s template. So the report's "the box's exact file" (ConfigAnalysis) could not be checked from the evidence. If the box file differs, `pin` refuses, which is safe. The box run settles it.
- **O34-10.** Nothing stops another actor from starting `es.service` during `recover`, which would pull up `spire-agent.service` on the empty data directory beside the attesting agent. It is unlikely within the seconds-long window, and the start fails without a token.

## 4. Deviations from Addendum B

| # | Judgment |
|---|---|
| D1 `-joinTokenFile` instead of a temporary config copy | **Accept.** The flag exists in the 1.14.4 binary (`spire-agent run -h`: "Path to a file containing an optional join token"). The exposure is the same (a 0600 file readable by `spire` and root), and it avoids a second hand-parsed config. With A34-1's fix, the attesting command line also carries `-trustBundle`, which is not secret. |
| D2 `-ttl 120` instead of 300 | **Accept.** It is above the 60 s attestation timeout plus generation latency, and halves the window for a leaked token. It was not pinned by a test (A06); the fix adds that. |
| D3 local `agent-data.json` first | **Accept.** The record-lag reasoning is sound, and the test fixture's `expireAgent` copes with it. I did not test the lag independently. |
| D4 15 s and 60 s test lifetimes | **Accept.** |
| D5 runbook deferred to the box run | **Accept, with a condition.** The runbook norm triggers when the procedure first works or fails *on the box*, which has not happened. The operator rule is already in the repo contract and pinned by `HelperIsDocumented`. Condition: the box-run brief must name the runbook entry as a deliverable of that run. |
| D6 dependents started after a failed start, pin rollback | **Accept.** The writer's finding; covered by M07 and A09. |
| D7 sandbox check of the tmpfiles rule | **Accept.** |

## 5. What I checked and found sound

- Token custody in `attest_once`: UUID-validated, registered for redaction at once, `O_CREAT|O_EXCL|O_NOFOLLOW`, `fchown spire`, `fchmod 0600`, deleted when the identity appears, directory removed in `finally`. No token in argv or the environment. `umask 077` before any file is created. The log file is root 0600 inside the private directory. Writer mutants M02 and M09 are killed.
- Bundle export: only over the admin socket as `spire`. Strict PEM parsing; CA certificates for the trust domain only; at least one unexpired; no repeats (M06, M10 killed; 12 cases).
- `agent.conf` edit: one line replaced, original owner and mode kept, exclusive backup, re-read before writing, `validate` as `spire`, restore on failure (M01, M08, A09 killed). The scan's weakness is A34-1.
- Rogue server: refused mid-`recover` (P5) and on a fresh pinned bootstrap (the writer's test).
- Layout: no environment read; wrapper `python3 -I -B`; fixed command `PATH`; `cwd=/`; stdin closed; timeouts on every command.
- The key directory is the data directory on the box (inventory: `/var/lib/spire/agent/keys.json`), so moving the data directory aside keeps the old key with the old SVID.

## 6. Validation assessment

| Command | Bytes | Result |
|---|---|---|
| `go test -count=1 -v -run '^TestRemoteAlphaSPIREAgent' .` as root, `env -i`, Go 1.26.5, Python 3.13.18, SPIRE tarball sha256 `4482db43…bcbf5` (pinned) | 0927911 | 7/7 PASS, 35 tests and subtests, 56.1 s (`tests/helper-tests-root-0927911.log`) |
| the same as an unprivileged user (uid 1500, gid 1600, no sudo), `runuser … env -i` | 0927911 | 7/7 PASS, 55.6 s (`tests/helper-tests-ci-uid1500-0927911.log`) |
| the writer's 10 mutants, re-expressed from `01-evidence/mutations/mutations.py.txt` | 0927911 | 10/10 killed (`mutants/results-writer-mutants-on-0927911-and-auditor-mutants-on-fix.txt`; its second half is an earlier fix-tree batch, superseded by the final one below) |
| auditor mutants A01–A12 | 0927911 | 1 killed, 11 survived (table in A34-4) |
| probes P1–P5 (`probes/`) | 0927911 | as reported in A34-1 to A34-3 |
| fixed code and new tests, root and unprivileged, final bytes | 0927911 + `proposed-fix.diff` | 7/7 PASS both, 38 tests and subtests, 57.3 s and 52.5 s (`proposed-fix/fixed-code-new-tests-*.log`) |
| PR code and new tests | 0927911 + test half of the diff | fails as expected: 3 ConfigAnalysis cases ("state pinned, want unrecognized"), recover "printed no JSON report" with a `JSONDecodeError` (`proposed-fix/pr-code-new-tests-root.log`) |
| my mutants against the fixed code and final tests: A01, A02, A03, A05, A06, A07, A08f, A10, A11, plus F01 (no `-trustBundle` on the attesting run), F02 (no signal handlers), F03 (regex redaction over the JSON again) | fix tree | 12/12 killed (`mutants/results-auditor-mutants-on-fix-final.txt`). A04 and A12 not rerun (observations), A09 not rerun (code unchanged, killed on 0927911) |
| whole root package, unprivileged, head vs base 8ba1edb | 0927911 / 8ba1edb | head 2056 pass / 235 fail / 0 skip, base 2021 / 235 / 0. Failing only on head: none. The 35 new tests and subtests all pass. The 235 shared failures are host-facility tests that fail the same way on base in this container (`root-package/compare.txt`) |
| GitHub Actions "build, vet and test", run 45250138980 | 0927911 | success: the job (137957431069) and every step passed, completed 20:02:51Z |

Not run: anything on the box (real systemd `Requires=`, real `setpriv`, boot-time directory creation, the box's own `agent.conf`); a separate SIGHUP probe (inferred from SIGTERM); macOS.

## 7. Red-team

**Recommendation: a narrow red-team after the repair, not before.** Reasons:
- The helper is a root tool that rewrites the trust anchor of the box's workload identity and handles a credential. This audit found that the part people trust most (the config reading) can be fooled, so the adversarial surface is real, even though today it needs root.
- My probes covered the obvious attacks: an impostor mid-run, signals, OS errors, and SPIRE's token logging. A red-team should add what I did not try: TOCTOU on the admin socket path (swapping `/run/spire/server/private` between the check and `setpriv`'s connect, as `spire`); symlink and FIFO tricks on `agent-data.json`, the bundle file and the backups; malformed `spire-server` JSON and PEM output; concurrent runs with the lock file replaced; and a hostile `spire` account racing the token file and the private directory.
- Against: every attack I found needs root or `spire`, who already own the agent; INF-14 itself was rated "Red-team: no" before Addendum B. If the coordinator judges the scope rule as "scripts-only, so no red-team", the attached tests already pin the findings that held. I would still prefer the narrow pass, because this PR is the recovery path for ES's identity.

## 8. Proposed fix (tested)

`02-audit-evidence/proposed-fix/proposed-fix.diff` (sha256 `fb7b9cd3a21b8a2212c05ce8fe26f3fdd8bdd1daae8b5d6c848054ec80b2f8d1`) applies cleanly to 0927911 (`git apply --check` on a fresh `git archive` of 0927911; the result is byte-equal to the tested tree: `.py` sha256 `63b3b282…0690`, test file `3e179a3d…878f`) and changes only `scripts/internal/remote_alpha_spire_agent.py` and `remote_alpha_spire_agent_test.go`:

- Python: `_redact_tree` (A34-2); `Interrupted` and the stop-signal handlers (A34-3); `-trustBundle <bundle> -trustBundleFormat pem` on the attesting run (A34-1); the classifier refuses heredocs and quoted keys and counts keys case-insensitively (A34-1); OSError caught in the swap and attest window, and a tolerant rollback (A34-3).
- Tests: shim records (config names `insecure_bootstrap`, token directory mode, SPIRE-style crash line); admin socket refusals in the pin test; refusal with no entry under the alias, a SIGTERM step, attesting-run, setpriv and TTL assertions, and evict exactness in the recover test; three `ConfigAnalysis` cases.
- The docs section needs one sentence each for the `-trustBundle` argument and the signal behaviour. That is left to the writer; it is not in the diff.

## 9. Closing provenance

At 20:17Z, after all tests, mutants and probes, and after removing the scratch trees:

```text
git ls-remote origin: claude/project-thread-wg7jh5 = 09279115…  (unchanged)
                      trunk_dev = 76c030fa…  (moved by PR #27; see section 1)
audit clone:          HEAD 8ba1edb8…, upstream origin/trunk_dev = 8ba1edb8…, branch claude/project-thread-wg7jh5
recipe sha256         c08597e2…a3ca (unchanged)
python3 -I v2 /opt/audit/manifest-close/1.json   (fresh 0700 directory, umask 022)
manifest_sha256       2632287f9e61b11facbc0ecf9742015bcb2f29ce37e3855756eac1299527d790
textual_diff_sha256   91658c83b79a488114b6d0104f2de7b8fdc6b09f02bb5fa31887c9a91cd7b740, 5 files
cmp close-1.json open-1.json: byte-identical
```

Copy: `02-audit-evidence/manifest/close-1.json`.

## 10. Confidence

- Provenance: high (reproduced, opening equals closing).
- Validation: high for the helper against real SPIRE in a container; the box-only behaviour (systemd, setpriv, boot) is unvalidated, as the writer says.
- Implementation: the code is careful and mostly correct. Medium confidence that the security claim holds as written, until A34-1 is repaired; high after the tested fix.

## 11. Effect status

Audit only: no repair commit, push, PR comment, merge or box action by this thread. All audit artifacts are under `02-audit-evidence/` (SHA256SUMS.txt). Scratch copies in this container were removed before the closing manifest.
