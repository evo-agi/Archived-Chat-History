# Narrow re-audit of the SPIRE agent helper repair (INF-14, PR #34)

> **Correction (added in re-audit 06, 2026-11-23).** `04-re-audit-evidence/proposed-fix/proposed-fix.diff` lacks the N19 test: the fake systemctl hold marker and the two-SIGTERM pin step. I generated the diff before adding that step and did not regenerate it. So section 7's claim is wrong: applied to `26c7cf8`, the diff gives test file `2acec82f…`, not the tested `d709ae38…36dc`. The test logs and the N19 result in this report do come from the full tested file. The missing hunk is `06-re-audit-evidence/compare/missing-n19-hunk-from-04.diff`. The writer wrote the step independently for `9993c62` (05-repair.md section 2).

**Verdict: REPAIR NEEDED (protocol verdict `BLOCK`), two small findings, both Low. The four audit 02 findings are fixed as reported. `recover` now cannot attest unpinned, because SPIRE itself refuses. But the new "SPIRE confirms it is pinned" check in `status` and `pin` can still be fooled by three `agent.conf` spellings: SPIRE trusts a different bundle file while `status` says `ok`. Separately, two of the four surviving mutants can be pinned by tests after all, and a third with a small unit test. A tested fix diff is attached. With it, all helper tests pass as root and as an unprivileged user, and only one mutant survives (N23), which I accept.**

```text
NARROW RE-AUDIT REPORT
Repository:        evo-agi/Execution-Substrate
Audit target:      base trunk_dev 76c030fa7872dd22dda731591878ef284c01bd9b
                   topic claude/project-thread-wg7jh5 at 26c7cf8012741b2a8e94cdd690061cd959899ce7
                   tree e4dd6306e8b66987e5fcbdd86f302879f7dc03eb
                   = 0927911 (audited in 02) + merge 9eef1ed of 76c030f + repair commit 26c7cf8
                   recipe governed-execution.audit-patch-manifest.v2, source sha256
                   c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified)
                   manifest_sha256 e1bc6de6b43ca8986119ec0f41edd902e45b47837c811781f76846e025b58a51, 5 paths
Writer report:     reports/Execution-Substrate/spire-bundle/03-repair.md, sha256 4004e5d2…66f6
Scope:             A34-1..A34-4 and O34-5..O34-7 from 02-audit.md; the 4 surviving mutants
Audit posture:     read-only on the repo; no subagents; nothing pushed; no PR comment; nothing run on the
                   Linux box. Tests, mutants and probes ran on copies outside the audit clone.
Provenance:        REPRODUCED. Two v2 runs into a fresh 0700 directory, byte-identical, and byte-equal to
                   03-evidence/manifest-v2-26c7cf8.json. Closing run equal to the opening one (section 8).
Final verdict:     BLOCK (repair needed: 2 low findings; fix diff tested)
```

## 0. In plain words

The repair is careful, and most of it holds up:

- **`recover` is now safe however `agent.conf` is spelled.** The attesting run carries `-trustBundle` on its command line. SPIRE then refuses to start if it reads `insecure_bootstrap`. If the file names another bundle path, the command-line one wins. I checked this on real SPIRE 1.14.4 with every odd spelling I found.
- **The report crash, signal handling, rollback and test gaps from audit 02 are fixed**, each with a test. The writer's 43 mutants give exactly the result reported: 39 caught, 4 survivors.

What still needs a small fix:

1. **(Low)** `status` and `pin` now ask SPIRE to confirm "pinned". I found three spellings where the helper and SPIRE's two checks all pass, yet SPIRE trusts a **different bundle file** from the one `status` names:
   - a second one-line `agent { … }` block with an escaped key;
   - an escaped key after a comma on a later line;
   - the key spelled with a look-alike letter that SPIRE's parser treats as `s`.

   On such a file `status` prints `ok … confirmed by spire-agent validate`. The agent would trust the other file the next time it starts from scratch under systemd. Only root can write the file, so this is not a practical attack. But it is exactly the false "ok" this check was added to prevent. Part of the hole came from the classifier rule in my own audit 02 diff, which only caught quoted keys at the start of a line. The fix is two more refusals in the scan: any quoted key, and any non-ASCII character. Three test cases go with it.
2. **(Low)** The writer called three of the four surviving mutants untestable timing windows. Two of those windows last seconds, not a few instructions, and a test can hold them open:
   - N17: the helper waits up to 15 s for the attesting agent to exit during cleanup;
   - N19: a second signal can arrive while pin's rollback restarts the agent.

   I wrote and ran both tests. A third survivor, N18, is caught by a ten-line unit test. N23 really cannot be reached from outside the helper, and I accept it.

## 1. Provenance reproduction

```bash
V2=/mnt/project-files/operating-protocol/tools/governed_execution_audit_patch_manifest_v2.py
sha256sum "$V2"   # c08597e2…a3ca
umask 022; git clone --no-checkout /opt/audit/es /opt/audit/es3; cd /opt/audit/es3   # objects only
git remote set-url origin https://github.com/evo-agi/Execution-Substrate
git fetch -q origin "+refs/heads/trunk_dev:refs/remotes/origin/trunk_dev" \
  "+refs/heads/claude/project-thread-wg7jh5:refs/remotes/origin/claude/project-thread-wg7jh5"
git rev-parse origin/claude/project-thread-wg7jh5          # 26c7cf80…  (tip-ok)
git merge-base --is-ancestor 76c030fa… 26c7cf80…            # ancestor-ok
git merge-base --is-ancestor 09279115… 26c7cf80…            # the audited head is inside
git checkout -q -f -B claude/project-thread-wg7jh5 26c7cf80…; test -z "$(git status --porcelain)"
git rev-parse HEAD^{tree}                                    # e4dd6306…
git rev-parse 9eef1ed^{tree}; git merge-tree --write-tree 09279115… 76c030fa…   # both 3318a16e…: git's own merge
git diff --name-only 76c030fa… 26c7cf80…                     # the same 5 paths as before
git reset -q --mixed 76c030fa…; git branch -q --set-upstream-to=origin/trunk_dev
python3 -I "$V2" /opt/audit/manifest3/1.json; python3 -I "$V2" /opt/audit/manifest3/2.json   # 0700 directory
cmp 1.json 2.json; cmp 1.json …/03-evidence/manifest-v2-26c7cf8.json                         # identical
```

Result: `manifest_sha256 e1bc6de6…8a51`, `textual_diff_sha256 ca6c9e0b…df24`, 5 files. The merge commit `9eef1ed` has exactly the tree of git's automatic merge, so the merge carries no hand edits. The recipe records only the upstream's name, so the later movement of `origin/trunk_dev` does not affect the manifest.

## 2. Scope check

| Item | Result | How I checked |
|---|---|---|
| A34-1 `recover` attests pinned | **Fixed.** Every attesting run carries `-trustBundle <bundle> -trustBundleFormat pem`. SPIRE refuses an insecure reading, and the command-line bundle overrides any `trust_bundle_path` in the file. | Code; writer's N01/N04/N04b killed (reproduced); my oracle runs with two of the spellings below plus `-trustBundle` load the pinned bundle (`probes/spire-run-bundle-oracle.log`) |
| A34-1 scan hardening | **Partly.** Heredocs, line-start quoted keys and ASCII case variants are refused. Quoted keys elsewhere on a line and non-ASCII look-alikes are not: **R34-1** | `probes/hcl-path-aliasing-26c7cf8.out`, `hcl-unicode-fold-26c7cf8.out` |
| A34-1 `status`/`pin` confirmation (writer's addition) | **Sound for insecure readings, not for the bundle path:** R34-1 | as above, plus `validate-new-cases.out` |
| A34-2 report crash | **Fixed** (`_redact_tree`) | N03 killed (reproduced); code |
| A34-3 signals and OS errors | **Fixed.** Handlers, held signals during cleanup and rollback, OS errors caught, rollback from disk state, the agent started with the normal mask. Two of its guards have no test: **R34-2** | N02, N06, N08, N09, N22 killed (reproduced); code; my N17/N19 tests |
| A34-4 guards without a test | **Fixed** | A02, A03, A05–A11 killed (reproduced) |
| O34-5 evict argv | **Done.** The docs say the evict command names the old, spent token. | docs diff |
| O34-6 redact before cut | **Done**, and pinned by the crash shim printing the real token (N21 killed) | code; reproduced |
| O34-7 primary-group members | **Done**, plus a walk of every directory up to `/run` (N10 killed). `group_members` itself has no test (N18): **R34-2** | code; my unit test |

## 3. Findings

### R34-1. `status` and `pin` can call a file "pinned, confirmed by SPIRE" while SPIRE trusts another bundle file. Low. Security risk (defense in depth) and contract. Patch defect.

**Contract.** `spire_confirms_pinned` docstring (`remote_alpha_spire_agent.py:757`): "a config that passes both is read by SPIRE with the one trust_bundle_path line the scan saw". The `status` check text: `trust_bundle_path = "<bundle>" in agent.conf (…), confirmed by spire-agent validate, plain and with -trustBundle`. Writer report section 2.1: the two checks close the gap for `status` and `pin`.

**Evidence** (real SPIRE 1.14.4, binary sha256 `e23f49a4…81e3`; each case is the honest pinned file plus one addition):

| Addition | Scan at 26c7cf8 | `validate` plain / with `-trustBundle` | Bundle SPIRE loads (`spire-agent run`) |
|---|---|---|---|
| `agent { "trust_bundle_path" = "<other>" }` after the file | pinned | valid / valid | **`<other>`** |
| `log_level = "INFO", "trust_bundle_path" = "<other>"` as a later line in the block | pinned | valid / valid | **`<other>`** |
| `truſt_bundle_path = "<other>"` (U+017F, long s) as a later line in the block | pinned | valid / valid | **`<other>`** |
| the second or third, with `-trustBundle <bundle>` on the run (as `recover` does) | – | – | `<bundle>` (safe) |

Sources: `probes/hcl-path-aliasing-26c7cf8.out`, `probes/hcl-unicode-fold-26c7cf8.out`, `probes/spire-run-bundle-oracle.log`, and `probes/validate-new-cases.out` (the exact test shapes below, built from the box template). `<other>` is a missing file, so SPIRE names it when it tries to load it. With the honest file, the same run gets as far as generating a keypair.

Why the checks miss these:
- HCL v1 decodes each later `agent` block into the same struct, and a later key wins. `validate` does not open the bundle file, so both runs pass.
- The scan refuses quoted keys only at the start of a line (`^\s*"…"\s*=`). That rule came from my audit 02 diff, and the writer kept it. Its case-insensitive count uses Python's `lower()`.
- HCL matches keys with Go's `strings.EqualFold`, which folds U+017F to `s`. Python's `lower()` leaves it alone. The same trick turns `inſecure_bootstrap = true` into `insecure_bootstrap`, but both `validate` runs refuse that one (`hcl-unicode-fold-26c7cf8.out`), so only the bundle path is open.

**Impact.** `status` reports `bootstrap: ok` and `pin` reports "nothing to change", naming the right bundle. Meanwhile any fresh bootstrap of the systemd agent, for example after its data directory is lost, would trust the other file. `recover` is not affected. Writing `agent.conf` needs root, and no tool writes these shapes by accident. So this is a false "ok" rather than a practical attack. I rate it Low because the writer explicitly set out to close this gap in `status` and `pin`, and the report says it is closed.

**Correction** (in the tested diff, section 7):
- `analyze_agent_config` refuses any non-ASCII character and any quoted key anywhere (`"\s*=`). In HCL native syntax, a string followed by `=` is always a key. The JSON form `"key":` is a parse error in HCL native syntax (checked: "illegal char"). The box template and every existing test case contain neither.
- After these refusals, an ASCII key can only alias through letter case, which the existing count catches. The docstring's claim then holds.
- Three `ConfigAnalysis` cases (`pinned_plus_second_block_escaped_path`, `pinned_plus_same_line_escaped_path`, `pinned_plus_long_s_path`) fail on the PR's code ("state pinned, want unrecognized") and pass on the fix. Mutants R1 (line-start rule back) and R2 (non-ASCII allowed) are killed.

**Uncertainty.** Guess: HCL v1 may have further aliasing channels I did not find. Inference: with these refusals, the remaining channels would need an ASCII identifier that `EqualFold` matches but `lower()` misses, and there is none. A sturdier design would put `-trustBundle` in the agent unit's `ExecStart`, so that no normal bootstrap depends on parsing `agent.conf` at all. That is a box unit change outside this PR; I list it for the red-team.

### R34-2. Three of the four "untestable" surviving mutants can be pinned by tests. Low. Test gap. Patch defect.

The writer's section 5 says N17, N19 and N23 "matter only if a signal lands inside a window a few instructions wide", and that N18 needs system accounts the fixture cannot create. My judgment, mutant by mutant:

| Mutant | Writer | My judgment | Evidence |
|---|---|---|---|
| N17 `signals_deferred` is a no-op | untestable | **Testable, required.** In `attest_once`'s cleanup the helper waits up to 15 s for the attesting agent to exit. New recover step: a 2 s attestation timeout, and a shim agent that takes its time on SIGTERM. The test signals the helper during that wait. With N17 the cleanup is cut short and the scratch directory, token file included, stays behind. | N17 and N17b (hold removed from that cleanup only) killed: "a SIGTERM during cleanup cut it short: scratch entries left" |
| N19 the handler keeps handling further signals | untestable | **Testable, required.** Pin's rollback restarts the agent again, with no held signals, for as long as `systemctl restart` takes. Only the handler's switch to ignore protects it. New pin step: the fake systemctl holds each restart after its stop. The first SIGTERM lands in pin's restart, the second in the rollback's. With N19 the rollback is cut short and the agent and `es.service` stay down. | N19 killed: "two SIGTERMs during pin's restart and its rollback did not end in a finished rollback" |
| N18 `group_members` lists only `gr_mem` | untestable | **Testable, recommended.** The test account's own primary group is a group the account is usually not listed in. A ten-line driver-mode unit test asserts the account counts as a member. | N18 killed: "members of root [] leave out root, whose primary group it is" |
| N23 no hold around `Popen` | untestable | **Accept.** The window is between the fork and `Popen` returning, inside the parent. Holding it from outside would need a change to the helper's own `preexec_fn`. The code is four lines and reads correctly. | survives, as expected |

**Correction:** the three tests above, in the tested diff (shim linger marker, fake systemctl hold marker, one recover step, one pin step, one unit test, and run counts 3 → 4). The pin test takes 12 to 16 s longer, and the recover test about 5 s.

### Observations (no change required)

- **O-R1.** The root-package `.env.txt` files in `03-evidence` name HEAD commits `5fb701a6…` and `4c52bda1…`, which are not in the repository. So those runs cannot be tied to the bytes of `26c7cf8` and `76c030f`. Inference: they ran in local copies with their own commits. I recomputed the comparison from the JSON: head 2058 pass / 244 fail / 0 skip, base 2019 / 244 / 0, failing only on head: none, 39 new tests and subtests all pass. CI on `26c7cf8` (below) covers the whole package independently. Next time, record the tree hash of the run directory.
- **O-R2.** The redact-before-cut reads only the first 1 MiB of `attest.log` (`fh.read(1 << 20)`), so on a longer log the "tail" is the end of the first MiB. This is harmless: an attempt lasts at most 60 s, far below 1 MiB of agent log.
- **O-R3.** The writer's own section 8 items stand: the `mkstemp` window in `atomic_write`, no rollback after a successful attestation, `validate` making a broken binary show as attention, and A04, A12, O34-8 to O34-10 from audit 02. I agree with each.

## 4. Mutants

| Set | Bytes | Result |
|---|---|---|
| The writer's 43 (`03-evidence/mutations/mutations.py.txt`), my runner, each on a fresh copy | 26c7cf8 | **39 killed, 4 survived (N17, N18, N19, N23)**, matching 03-repair section 5 (`mutants/results-writer-43-on-26c7cf8.txt`) |
| Mine against the fix: R1, R2, N17, N17b, N18, N19, N23 | 26c7cf8 + `proposed-fix.diff` | **6 of 7 killed** (R1, R2, N17, N17b, N18, N19); N23 survives as judged in R34-2 (`mutants/results-auditor-mutants-on-fix-final.txt`, against the final test bytes) |

## 5. Validation

| Command | Bytes | Result |
|---|---|---|
| `go test -count=1 -v -run '^TestRemoteAlphaSPIREAgent' .` as root, `env -i`, Go 1.26.5, SPIRE tarball pinned | 26c7cf8 | 7/7 PASS, 56.3 s (`tests/helper-tests-root-26c7cf8.log`) |
| the same as an unprivileged user (uid 1500, no sudo) | 26c7cf8 | 7/7 PASS, 54.9 s (`tests/helper-tests-ci-uid1500-26c7cf8.log`) |
| fixed code and new tests, root and unprivileged | 26c7cf8 + diff | 8/8 PASS both (the 7 tests plus the group test), 43 tests and subtests, 63.5 s and 62.9 s (`proposed-fix/fixed-code-new-tests-*.log`) |
| PR code and new tests | 26c7cf8 + test half of the diff | fails as expected and only there: the 3 new `ConfigAnalysis` cases ("state pinned, want unrecognized"); the new N17, N19 and group steps pass on the PR's code (`proposed-fix/pr-code-new-tests-root.log`) |
| GitHub Actions "build, vet and test", run 45269706153, job 138025924864 | 26c7cf8 | success, 21:26:41Z to 21:56:16Z |
| root package comparison | writer's JSON | recomputed: 0 failing only on head (O-R1) |
| trial merge onto current trunk_dev `400ff7f` (#29 and #36 landed after `76c030f`) | merge tree `0467d411…` | clean, only `PLANS.md` on both sides; `go vet .` ok; helper tests 7/7 PASS as root (`proposed-fix/trial-merge-400ff7f.txt`, `merged-400ff7f-helper-tests-root.log`) |

Not run: anything on the box, macOS, the writer's earlier mutant rounds.

## 6. Branch sync before merge

- trunk_dev is now `400ff7f`. `git merge-tree` with `26c7cf8` is clean, and only `PLANS.md` is touched by both sides. The merged tree vets and compiles, and its helper tests pass (section 5).
- PR #39 (open, draft) moves the root's Remote Alpha script tests into `scripts/`, and says #34's new root test file must move with them. If #39 lands first, `remote_alpha_spire_agent_test.go` moves to `scripts/` and must resolve repository paths against the root through `internal/testutil`: the helper module, the setup script and the driver. That move needs a narrow re-check: a new manifest, the helper tests as root and as `ci`, and #39's path guard. It does not need a full audit. If #34 lands first, #39 takes the file along.

## 7. Proposed fix (tested)

`04-re-audit-evidence/proposed-fix/proposed-fix.diff` (sha256 `304764073d64a5d65d34cae368a18a0c10421ab9121ed74ad9288e6d59a1a3d3`; resulting `.py` `6c425fec…df17`, test file `d709ae38…36dc`) applies cleanly to `26c7cf8` (`git apply --check` on a fresh `git archive`). The result is byte-equal to the tested tree. It changes only `scripts/internal/remote_alpha_spire_agent.py` (the two refusals and the docstring) and `remote_alpha_spire_agent_test.go`:
- the three `ConfigAnalysis` cases;
- the shim linger marker and the SIGTERM-during-cleanup recover step;
- the fake systemctl hold marker and the two-SIGTERM pin step;
- the `--group-members` driver mode and its test;
- the run counts 3 → 4.

The docs need one word: in the list of refused shapes, "a quoted key" becomes "a quoted key anywhere, a non-ASCII character". I leave that to the writer.

## 8. Closing provenance

At 22:25Z, after all tests, mutants and probes, and after removing the scratch trees:

```text
git ls-remote origin: claude/project-thread-wg7jh5 = 26c7cf80…  (unchanged)
                      trunk_dev = 400ff7fa…  (moved by #29 and #36; section 6)
audit clone:          HEAD 76c030fa…, upstream name origin/trunk_dev, branch claude/project-thread-wg7jh5
recipe sha256         c08597e2…a3ca (unchanged)
python3 -I v2 /opt/audit/manifest3-close/1.json   (fresh 0700 directory, umask 022)
manifest_sha256       e1bc6de6b43ca8986119ec0f41edd902e45b47837c811781f76846e025b58a51
textual_diff_sha256   ca6c9e0baa67f0cb325dc89462fed45e743f107f50a3116f9260fef8cfb0df24, 5 files
cmp close-1.json open-1.json: byte-identical
```

Copy: `04-re-audit-evidence/manifest/close-1.json`.

## 9. Red-team

Still recommended: a narrow pass after this repair, as in audit 02. Add to the audit 02 list:
- more HCL spellings against `status` and `pin` on the real binaries;
- whether `-trustBundle` in the agent unit's `ExecStart` should replace parsing `agent.conf`;
- signals at the points these tests now hold (cleanup waits, pin's rollback restart).

## 10. Effect status

Audit only: no repair commit, push, PR comment, merge or box action by this thread. Evidence is under `04-re-audit-evidence/` (`SHA256SUMS.txt`). Scratch trees in this container were removed before the closing manifest.
