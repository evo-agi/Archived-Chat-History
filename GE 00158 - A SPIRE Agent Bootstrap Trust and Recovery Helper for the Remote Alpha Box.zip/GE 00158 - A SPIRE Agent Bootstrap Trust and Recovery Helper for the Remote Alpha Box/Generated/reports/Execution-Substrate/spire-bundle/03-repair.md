# Repair of the SPIRE agent helper after audit 02 (INF-14, PR #34)

**Verdict: REPAIRED. All four audit findings (A34-1 Medium; A34-2, A34-3, A34-4 Low) are fixed in-PR, each with a test that fails without the fix, and trunk_dev `76c030f` is merged in. Draft PR [#34](https://github.com/evo-agi/Execution-Substrate/pull/34) is now at `26c7cf8`. Ready for the narrow re-audit and the narrow red-team. Scripts, tests and docs only, so after those it needs the merge gate, not David's review.**

```text
REPAIR REPORT
Objective:        fix audit 02 findings A34-1..A34-4 in PR #34, starting from the auditor's tested
                  diff after reviewing it; update with trunk_dev 76c030f
Repository:       evo-agi/Execution-Substrate
Base ref and SHA: origin/trunk_dev 76c030fa7872dd22dda731591878ef284c01bd9b (unchanged at push time)
Topic branch:     claude/project-thread-wg7jh5
Audited head:     09279115ef4ae736777174e9d3293a9741571701
Topic head SHA:   26c7cf8012741b2a8e94cdd690061cd959899ce7
                  (= 0927911 + merge 9eef1ed of 76c030f + repair commit 26c7cf8)
Tree SHA:         e4dd6306e8b66987e5fcbdd86f302879f7dc03eb
v2 manifest:      manifest_sha256 e1bc6de6b43ca8986119ec0f41edd902e45b47837c811781f76846e025b58a51
                  textual_diff_sha256 ca6c9e0baa67f0cb325dc89462fed45e743f107f50a3116f9260fef8cfb0df24
                  5 files (the same 5 paths as before), upstream origin/trunk_dev, HEAD at 76c030f
                  when taken, tool sha256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca
                  verified before each run
Final status:     clean (git status --porcelain empty after the commit)
Effect status:    TOPIC_BRANCH_PUSHED | DRAFT_PR_UPDATED | MERGE_NOT_PERFORMED |
                  RE_AUDIT_NOT_PERFORMED | RED_TEAM_NOT_PERFORMED | BOX_RUN_NOT_PERFORMED
```

## 0. In plain words

The auditor found one real weakness and three smaller bugs. The weakness: `recover` relied on the helper's own reading of `agent.conf` to know the agent was pinned before it attested, and SPIRE's config parser accepts a few odd spellings that reading did not see. Now SPIRE enforces it itself: the attesting run is told on its command line which bundle to trust, and SPIRE refuses to start at all if it still reads "trust anyone" in the file. `status`, `pin` and `recover` also ask SPIRE before they call a file pinned. The smaller bugs: the report could crash on one shape of SPIRE log line; Ctrl-C, an SSH drop or a kill in the middle of a run could leave a token file, a stray agent and a half-swapped data directory behind; and some safety checks had no test. All are fixed. 39 of 43 deliberate code breakages are caught by the tests; the 4 that are not are split-second timing windows or a box account shape the test fixture cannot create, explained in section 5. Nothing ran on the box.

## 1. Findings and fixes

| Finding | Fix | Test that fails without it |
|---|---|---|
| **A34-1** (Medium) recover's pin-before-attest rests on a line scan SPIRE can disagree with; ordering untested | (a) The attesting run is `spire-agent run -config agent.conf -trustBundle /etc/spire/agent/bootstrap-bundle.pem -trustBundleFormat pem -joinTokenFile <file>`; SPIRE refuses to start while its own reading has `insecure_bootstrap`. (b) The scan refuses heredocs (`<<`) and quoted keys and counts key names case-insensitively. (c) Beyond the diff: `spire_confirms_pinned` (`remote_alpha_spire_agent.py:757`) runs `spire-agent validate` as `spire` twice, plain and with `-trustBundle`. `status` reports `ok` only if both pass (else `attention`); `pin` and `recover` refuse a file the scan calls pinned but SPIRE does not confirm; `pin` checks its own edit the same way and restores the original if SPIRE refuses. | Recover test: the shim logs every attesting run's argv, whether the config still names `insecure_bootstrap`, and its blocked signals; all three runs must show `-trustBundle <bundle> -trustBundleFormat pem` and a clean config (N01, N04, N04b). Four new `ConfigAnalysis` cases (letter case, escaped quoted key, heredoc hiding a key, heredoc swallowing the path line) (N11-N13). Pin test: SPIRE confirms the pinned file and refuses an insecure copy, a heredoc-hidden insecure copy and a heredoc-swallowed path copy, each for the expected reason (N05, N24, N25); a file the scan calls pinned but SPIRE refuses is flagged by `status` and refused by `pin`, with the agent untouched (N14, N15). |
| **A34-2** (Low) report crashes on a quoted agent ID | `Report.document` redacts each string in the tree (`_redact_tree`, line 217), as in the diff. | The crash shim prints SPIRE's real `Node attestation was successful ... spiffe_id="spiffe://.../join_token/<fake id>"` line; the failure report must parse and hold `join_token/<redacted>`, not the fake ID (N03). |
| **A34-3** (Low) stop signals and OS errors skip cleanup and rollback | As in the diff: SIGHUP, SIGINT and SIGTERM raise `Interrupted` (a `Failure`) and ignore further stop signals; recover's swap and attestation catch `OSError`. Beyond the diff, see section 2. | Recover test: SIGTERM while the shim holds the attesting run gives a `failed` report naming SIGTERM, no scratch entries, no surviving attesting process, and the old data directory back; an OS error during the swap (scratch parent missing, standing in for a full `/run`) rolls back (N02, N08, N09). Pin test (new): SIGTERM while the shim holds `validate` on the edited file restores `agent.conf`, leaves the agent and `es.service` running with the same PIDs, and leaves no `validate` process behind (N02, N06). |
| **A34-4** (Low) guards without a test | The auditor's test additions, reviewed and kept: socket directory and socket mode refusals (pin and status), no-workload-entry refusal, token generation and attesting run as `spire` through `setpriv` with `-ttl 120`, private directory `0700`, evict deletes only the replaced agent's alias entry. | A02, A03, A05-A11 in section 5, all killed. |

## 2. Where I went beyond the auditor's diff, and why

I applied the diff and reviewed it line by line. It was sound and nothing in it was dropped; these are additions.

1. **SPIRE confirms "pinned" in `status`, `pin` and `recover`**, plain and with `-trustBundle`. The diff made `recover` safe through SPIRE, but `status` would still say `bootstrap: ok` and `pin` would still say "nothing to change" for a file the scan misreads. The two validate runs answer different questions. With `-trustBundle`, SPIRE refuses a file it reads as insecure. Plain, SPIRE refuses a file in which it sees no trust bundle at all. Probed on SPIRE 1.14.4 (`03-evidence/spire-1.14.4-validate-probe.log`): an insecure file passes plain and fails with `-trustBundle`; a file whose `trust_bundle_path` line sits inside a `join_token = <<EOT` heredoc fails plain ("trust_bundle_path or trust_bundle_url must be configured") and *passes* with `-trustBundle`. So the `-trustBundle` check alone would have confirmed that file as pinned. The first mutation round showed this gap (section 5) and the plain run closes it.
2. **Stop signals are held during cleanup and rollback** (`signals_deferred`, line 149, using `pthread_sigmask`). The diff ignores *further* signals once the first arrives, but a *first* signal during a rollback that an ordinary failure started would still cut it short. Now `attest_once`'s cleanup, `restore_config`, `rollback_data_dir` and the tmpfiles sandbox removal hold stop signals and take them when they finish.
3. **The attesting agent starts while stop signals are held, and with the normal mask** (`preexec_fn` at line 1370 restores it in the child). Otherwise a signal while `Popen` waits for the exec would leave a running attesting agent with no handle to stop it. The shim records the child's blocked signals, and the test requires none (N22).
4. **`pin` restores `agent.conf` on any interruption** between its edit and SPIRE's verdict (`except BaseException` in `apply_config`), not only when validate refuses.
5. **The data directory rollback works from what is on disk** (`rollback_data_dir(..., had_data_dir)`, line 1414). The backup name was checked to be free, so if the backup exists, the rename happened. The diff kept a `moved` flag and the rename outside the `try`, so a signal between the rename and the flag would have skipped the rollback. Now the rename, `mkdir`, `chown`, `chmod` and attestation sit in one `try`.
6. **`main` survives a signal that lands inside its own error handlers** (outer `except Interrupted`, line 1499). It sets stop signals to ignore before it releases the lock, and still prints the report.
7. **Observations folded in.** O34-5: the docs now say the evict command names the old, spent token and that the new token never appears on a command line. O34-6: the agent log tail is redacted before it is cut, and the crash shim now prints the real token where a cut-first tail would keep half of it (N21). O34-7: `group_members` counts accounts whose primary group is `spire`. The socket check also walks every directory from the socket's own up to the runtime root (`/run`), and refuses a socket outside it (N10).
8. **Test hygiene.** The shim holds any attesting run, with the token in a file or on the command line, and the SIGTERM step waits on attesting runs rather than token files. So the token-in-argv mutant (M02) is killed by the token-leak check itself, not by a timeout. A stale comment ("Two runs had a join token file") now says three.

## 3. Merge of trunk_dev 76c030f

`9eef1ed` merges `76c030f` (PR #27) into the audited head `0927911`. It is git's automatic result with no hand edits: `git merge-tree --write-tree 0927911 76c030f` gives tree `3318a16e…`, which is the merge commit's tree. #27 adds 29 lines to `PLANS.md` elsewhere in the file and touches no helper file. The repair commit `26c7cf8` sits on top. The range `76c030f..26c7cf8` touches exactly the five manifest paths.

## 4. Tests

Changes to `remote_alpha_spire_agent_test.go` against `0927911` (+343 lines):

- **Shims:** the agent shim logs, for each run with a join token, the token file's mode, owner and directory mode, whether the config still names `insecure_bootstrap`, and which stop signals arrived blocked. Two hold markers stop an attesting run or a `validate` at its start, so the test can signal the helper there. The crash marker prints the real token, then SPIRE's quoted-ID success line.
- **Pin test:** socket refusals (a world-writable socket directory, a world-writable grandparent directory, a 0666 socket: `status` flags each one and `pin` refuses with nothing changed); SIGTERM during `validate` of the edited file; SPIRE's confirmation on four files; a file the scan calls pinned that SPIRE refuses.
- **Recover test:** refusal with no entry under the alias (the entry is recreated afterwards); the crash report (parses, redacted, no token fragment); an OS error during the swap; SIGTERM during attestation; argument, account, TTL, mode and signal-mask checks on all three attesting runs; evict exactness (entry count unchanged, workload entry still there).
- **ConfigAnalysis:** 20 cases (4 new). **Docs test:** also requires the `-trustBundle ... -joinTokenFile <file>` command and the stop-signal sentence.

All 7 helper tests pass as root on the final bytes (`03-evidence/helper-tests-root-26c7cf8.log`: pin 28 s, recover 56 s). gofmt, `go vet`, pyflakes and `bash -n` are clean.

## 5. Mutation checks on the repaired code

43 mutants, each applied to a fresh copy of the final working tree and run against the test that should catch it (`03-evidence/mutations/`: definitions, runner, per-mutant logs, results).

| Group | Mutants | Result |
|---|---|---|
| Original M01-M10 (anchors updated where the repair moved code) | config not edited, token in argv, redaction off, recover while valid, no rollback, no CA check, dependents not started, no restore on refusal, token file 0644, no expiry check | 10 killed. M01 is now caught earlier, by SPIRE refusing the unedited file. M02 is caught by the token-leak check. |
| Auditor's A02, A03, A05-A11 | socket directory, socket mode, no-entry refusal, TTL 3600, token generate not as `spire`, attesting run not as `spire`, pin rollback skips restore, private directory 0755, evict deletes alias children | 9 killed |
| A34-1 | N01 no `-trustBundle` on the attesting run; N04 pins after attesting; N04b both; N05 SPIRE check always true; N07 no check after the edit; N11 heredoc allowed; N12 case-sensitive count; N13 quoted key allowed; N14 status check forced; N15 inspect check forced; N24 no plain validate; N25 no `-trustBundle` validate | 12 killed. N04 is caught by SPIRE itself refusing to start, which is the ordering guarantee working. |
| A34-2, O34-6 | N03 regex over serialized JSON; N21 cut before redact | 2 killed |
| A34-3 | N02 no signal handlers; N06 no restore on interruption; N08 rollback ignores the backup; N09 OS error skips the rollback; N22 attesting agent inherits the blocked mask | 5 killed |
| Socket chain | N10 parent directory only | killed |
| **Survivors, predicted** | N17 `signals_deferred` is a no-op; N19 the handler keeps handling further signals; N23 no signal hold around `Popen`; N18 `group_members` ignores primary groups | 4 survive |

N17, N19 and N23 matter only if a signal lands inside a window a few instructions wide (during a cleanup, a second signal, or the exec). The tests send one SIGTERM at a held point and cannot hit those windows reliably. N18 needs an account whose primary group is `spire` and a group-writable socket directory, which the fixture cannot create without adding system accounts. These four are protected by construction and by review.

**Earlier rounds** (`mutations/earlier-rounds/`, on commits that were amended and never pushed). Round 1 (41 mutants on `6af6212`) had one unexpected survivor: N11. Its heredoc test case was also caught by the case-insensitive count, so nothing pinned the heredoc rule itself. Probing why led to the plain-validate addition, a heredoc case only that rule catches, and N24/N25. Round 2 (on `035530e`) killed everything expected. It also showed that N21 (cut before redact) could be pinned after all, which led to the crash-shim token test. Round 3 is the table above.

## 6. Validation

| Check | Result |
|---|---|
| SPIRE helper tests as root, final bytes | 7 of 7 pass (`helper-tests-root-26c7cf8.log`) |
| Full root package as user `ci` (uid 1500), head `26c7cf8` vs base `76c030f`, same container, run one after the other | head 2058 pass / 244 fail / 0 skip; base 2019 / 244 / 0. Failing only on head: 0. Skipped only on head: 0. All 39 new tests and subtests pass. The 244 shared failures are the known host-only failures of cloud containers (`root-package-compare-head-vs-base.txt`) |
| gofmt, `go vet`, pyflakes, `bash -n` | clean |
| Mutants | 39 of 43 killed, 4 predicted survivors (section 5) |
| GitHub CI on `26c7cf8` | check "build, vet and test" success, run 45269706153 (21:26-21:56Z) |
| Box | not touched |

## 7. Provenance

- Recipe `governed-execution.audit-patch-manifest.v2`, `/mnt/project-files/operating-protocol/tools/governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2…a3ca`, verified before each run. It is the same file as the `claude-conversion/tools` copy, which the folder rename left in place.
- Taken with HEAD reset (`--mixed`) to `76c030f`, the branch checked out, upstream pinned to `origin/trunk_dev`, nothing staged, and the final bytes in the working tree. Run twice into a fresh 0700 directory outside the repository: byte-identical. HEAD then went back to the tip, and the three changed files were committed.
- After the commit: `git diff --name-only 76c030f 26c7cf8` equals the manifest's 5 paths, and every committed blob matches the manifest's SHA-256, size and mode (`03-evidence/manifest-v2-checks.txt`).
- `textual_diff_sha256` covers tracked files only (the docs file and `PLANS.md`). The two new files and the test are `untracked` entries, with full-content hashes in the file list.
- Superseded manifests for the two amended, unpushed commits are kept as `superseded-manifest-v2-6af6212.json` and `superseded-manifest-v2-035530e.json`.

## 8. Still not proven, and suggestions for the re-audit and red-team

- **Timing windows** (N17, N19, N23 above) are covered by construction and review, not by tests.
- **A signal between `mkstemp` and the `try` in `atomic_write`** could leave a `.agent.conf.*.tmp` file (root, 0600) in `/etc/spire/agent`. Harmless; not handled.
- **A stop signal after a successful attestation** (while the unit starts and is verified) is reported as `failed` and not rolled back, as the docs say: the old identity has expired, so going back would not help. A stop signal during `pin`'s restart takes the existing restart-failure rollback (restore and restart again).
- **`status` and `pin` now call `spire-agent validate`** for the pinned check, so a broken `spire-agent` binary shows as `bootstrap: attention` or `fail` instead of `ok`. That is intended.
- **Left as observations from audit 02:** A04 (a live server record for an expired local SVID; hard to build in the fixture), A12 (no lock test), O34-8 (`status` does not check boot-rule owner and mode, or whether the bundle file is writable by others), O34-9 (the box's real `agent.conf` bytes are only known at the box run; `pin` refuses anything it does not recognize), O34-10 (another actor starting `es.service` during `recover`).
- **Red-team suggestions:** more HCL spellings against `status`, `pin` and `recover` on the real binaries (the two SPIRE checks should catch whatever the scan misses); signals at other points (pin restart, recover unit start); a hostile socket directory chain; log lines shaped to defeat redaction.

## 9. Evidence

`/mnt/project-files/reports/Execution-Substrate/spire-bundle/03-evidence/` (checksums in `SHA256SUMS.txt`):

- `manifest-v2-26c7cf8.json`, `manifest-v2-checks.txt`, `range-paths-76c030f..26c7cf8.txt`; superseded manifests for the amended commits
- `helper-tests-root-26c7cf8.log`, `environment.txt`
- `root-package-head-26c7cf8-ci.json.gz`, `root-package-base-76c030f-ci.json.gz`, their `.env.txt`, `root-package-compare-head-vs-base.txt`, `compare_json.py.txt`, `run-root-pkg.sh.txt`
- `spire-1.14.4-validate-probe.log`: plain and `-trustBundle` validate on pinned, insecure, neither, heredoc-hidden insecure and heredoc-swallowed path files (binary sha256 `e23f49a4…81e3`, as on the box)
- `mutations/`: `mutations.py.txt`, `run2.sh.txt`, `results-final-26c7cf8.txt`, `logs-final/` (one log per mutant; test-fixture token UUIDs replaced with `<test-uuid>`), `earlier-rounds/`
