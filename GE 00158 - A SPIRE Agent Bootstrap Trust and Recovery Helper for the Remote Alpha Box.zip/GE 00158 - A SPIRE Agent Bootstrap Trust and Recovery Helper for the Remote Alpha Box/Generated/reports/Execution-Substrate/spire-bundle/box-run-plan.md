# SPIRE agent box run plan: pin the bootstrap trust bundle (INF-14, after PR #34)

Prepared 2026-11-24 by the writer thread "Make SPIRE agent recoverable on the box". **Status: ready. PR #34 merged into trunk_dev on 2026-11-24 as 5b82a6eea55e66faddadf7ebcf59393bfa129ba2 (step A2 uses it); the run waits for David's go.** It needs David's "go ahead" in this thread, because it changes the box. One Remote Control session on David's Mac runs it. Re-audit 06 and red-team 07 accepted the helper. This plan includes the red-team's four box notes (07-redteam.md section 4).

**In plain words.** The box's SPIRE agent currently trusts whatever server answers when it bootstraps from scratch. This run makes it trust only the real server's certificate authority. The Mac session copies the helper from the merged `trunk_dev` into one new folder on the box and runs `status`, then `pin` (plan only), then `pin --apply`, then `status` again, and finally `pin --apply` once more to show it changes nothing the second time. `pin --apply` writes the server's CA bundle to a file, may add one boot-time rule for SPIRE's `/run` directories, and replaces one line of `agent.conf`, keeping a backup. It then restarts the agent once, which restarts ES. ES is down for a few seconds, and nothing else changes. The helper checks that the agent keeps its identity and that ES comes back, and puts the old config back if either fails. About 15 minutes in total.

## What it settles

1. On the box itself, `agent.conf` reads as pinned and SPIRE's own parser confirms it, both plain and with `-trustBundle`. A fresh bootstrap can no longer attest to an impostor server.
2. Real systemd `Requires=` propagation (a restart of `spire-agent` restarts `es.service`) and the real `setpriv` drop to `spire`, which CI only fakes (01-implementation section 10).
3. The box's actual runtime-directory owners and modes, and whether a boot-time rule recreates them. If no rule does, `pin` writes `/etc/tmpfiles.d/spire.conf`. The next reboot (the libc6 reboot, Addendum A.6) then proves the agent comes back from its cache.
4. Two red-team box checks, below.

## The red-team's box notes (07-redteam.md section 4)

| Note | What this run does |
|---|---|
| **O-RT1** At boot, the trust decision rests on `agent.conf` alone, because the unit runs `spire-agent run -config agent.conf` without `-trustBundle`. | Step B2 records whether the unit's `ExecStart` has `-trustBundle`. After the run, `status` must show SPIRE confirming the pinned file. Adding `-trustBundle` to the unit's `ExecStart` is the sturdier design that audits 02 and 04 and the red-team endorse. It is a box unit change outside PR #34 and is **not** part of this run. It is a later decision for the coordinator, and for David if the coordinator brings it to him. |
| **O-RT2** If the unit enables `-expandEnv`, the bundle path in `agent.conf` must be a literal. | Step B2 counts `-expandEnv` in the unit. Step B9 prints the `trust_bundle_path` line after the run. It must read exactly `trust_bundle_path = "/etc/spire/agent/bootstrap-bundle.pem"`, with no `$`. |
| **O-RT3** A SIGKILL to the helper cannot be caught, so it skips the helper's cleanup. | The brief says: never `kill -9` the helper. To abort, end the ssh command. The helper gets SIGHUP and rolls back, and a status run afterwards shows the state. (The worst case in the note, a leftover token file, belongs to `recover`, which this run does not use.) |
| **O-RT4** `--evict-old-agent` deletes server records and needs the operator's explicit go. | Not used. `recover` is not run either: the agent is healthy, and `recover` runs on the box only after a real expiry (Addendum B.4). |

## Effects on the box

- New: `/etc/spire/agent/bootstrap-bundle.pem` (`root:root 0644`), `/etc/spire/agent/agent.conf.bak-<UTC timestamp>`, and possibly `/etc/tmpfiles.d/spire.conf`.
- Changed: one line of `/etc/spire/agent/agent.conf` (`insecure_bootstrap = true` becomes `trust_bundle_path = "/etc/spire/agent/bootstrap-bundle.pem"`).
- One restart of `spire-agent.service`, which restarts `es.service` through `Requires=`.
- One temporary folder under `/tmp`, removed at the end. Nothing else: no Vault, Nomad, Docker or network change.

## Stop conditions

- `status` in B5 shows the agent's own SVID as expired or failing, or a server that is not active: do not pin. Report it. Recovery is a separate step with its own go.
- `pin` in B6 refuses: do not run `--apply`. Report it.
- `pin --apply` in B7 fails: the helper has restored the config. Run B8 and report. If its message says "rollback failed", use the fallback in B7.

## After the run (this thread)

- A History line in the runbook "Governed Execution Remote Alpha Claude Access" (Archived-Runbooks), because the run changes the box.
- The runbook entry for the procedure, deferred until now (01-implementation D5): "If the box or `spire-server` has been off for more than a day, run `recover` before expecting ES to work", with the commands this run used.
- Memory and the infra audit's INF-14 row: pinned on the box, with the date.

## Fit with the other box runs (Addendum B.5)

SPIRE goes first in the order SPIRE, Nomad lock, firewall, and can also run alone. All three restart `es.service`, so they run one after another, never at the same time. The firewall needs only its normal loopback accept for SPIRE (agent to server on `127.0.0.1:8081`, workloads through the Unix socket).

---

## Instructions for the Mac session (paste as is)

Run a check and one change on the Remote Alpha box (ssh alias [test box name withheld]), and report the complete output. Execution-Substrate PR 34 added a helper that pins the box's SPIRE agent to the real SPIRE server's CA bundle. You copy that helper from the merged trunk_dev to the box and run it there.

Rules on the Mac:
- Create exactly one new folder: T=$(mktemp -d /Users/ds/Repositories/Playground/es-spire-pin.XXXXXX) and print it.
- Keep /Users/ds/Repositories/Playground as your working directory for the whole run. Never cd into "$T" or below it. Use git -C "$T/es".
- Do not change, stage, commit or delete anything in any existing folder. You may read the origin URL of the existing clone with: git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin. Run no other command in that folder.
- Do not run sudo on the Mac. No git push. No installs and no downloads other than the git clone.
- Shell variables may not survive from one of your commands to the next. After you print T (and later D), use their literal values wherever the steps say "$T" or "$D".

Rules on the box:
- Reach it only with: ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] '<command>'. Below this is written BOX '<command>'. BOX is shorthand, so type the full ssh command each time. Do not open an interactive shell.
- Use sudo on the box only in the exact commands below. Do not start, stop, restart or reconfigure any service yourself, except in the fallback of step B7. Do not install anything or reboot. Do not touch Vault, Nomad or Docker.
- Never print /etc/spire/agent/agent.conf in full, /var/lib/spire/agent/agent-data.json or any join token. The helper redacts these itself. Report its output as it is.
- Never kill -9 the helper. If a step hangs for more than 5 minutes, end that ssh command (the helper then gets SIGHUP and rolls back), run step B8, and report.
- Do not use --evict-old-agent and do not run recover.
- If an ssh command fails with "No route to host" or a timeout, run: route -n get [home network address withheld]; ping -c 2 [home network address withheld]; nc -vz -w 5 [home network address withheld] 22. Then wait five minutes and try the same command once more. If it still fails, stop, do step B10 if a box folder was created, do part C, and report the diagnostics.

Part A, on the Mac:
A1. git clone "$(git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin)" "$T/es"
A2. git -C "$T/es" checkout --detach 5b82a6eea55e66faddadf7ebcf59393bfa129ba2
    Print git -C "$T/es" rev-parse HEAD and git -C "$T/es" log -1 --format=%s (expected 5b82a6eea55e66faddadf7ebcf59393bfa129ba2 and "Add a SPIRE agent bootstrap trust and recovery helper for the Remote Alpha box (#34)"). If the checkout fails or either differs, stop, do part C and report.
A3. shasum -a 256 "$T/es/scripts/remote_alpha_spire_agent.sh" "$T/es/scripts/internal/remote_alpha_spire_agent.py"
    Expected 3da361743428cdab50cd2352aa38074e1b0424ace2afbd7ddfb2d56bd669531c and e7a8ac816dfdaad165bfaee6b82ac1a98c6bce50d5cc761c7eaee653229345e5. If either differs, stop, do part C and report.

Part B, on the box:
B1. Baseline, read only:
      BOX 'hostname; uname -r; /usr/bin/python3 --version; id -un; sudo -n true && echo "sudo -n: ok"; systemctl is-active spire-server spire-agent es; systemctl show -p ActiveEnterTimestamp spire-agent.service es.service; date -u'
B2. The agent unit's flags, read only (red-team O-RT1 and O-RT2):
      BOX 'for f in -trustBundle -expandEnv -joinToken; do printf "%s lines in the spire-agent unit: %s\n" "$f" "$(systemctl cat spire-agent.service | grep -c -- "$f")"; done; systemctl cat spire-agent.service | grep -E "^ExecStart=" | sed -E "s/(-joinToken(File)?)([ =]+)[^ ]+/\1\3<redacted>/g"'
B3. The bootstrap lines of agent.conf and the files around it, read only:
      BOX 'sudo -n grep -n -E "^[[:space:]]*(insecure_bootstrap|trust_bundle_path|trust_bundle_url|trust_bundle_format)[[:space:]]*=" /etc/spire/agent/agent.conf; sudo -n sha256sum /etc/spire/agent/agent.conf; sudo -n ls -ln /etc/spire/agent/; ls -ln /etc/tmpfiles.d/ | grep -i spire || echo "no spire file in /etc/tmpfiles.d"'
B4. Stage the helper. Create the box folder and print it:
      D=$(ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] 'mktemp -d /tmp/spire-pin.XXXXXX'); printf '%s\n' "$D"
    It must match ^/tmp/spire-pin\.[A-Za-z0-9]{6}$. If not, stop part B and report.
      BOX "mkdir '$D/internal'"
      ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] "cat > '$D/remote_alpha_spire_agent.sh'" < "$T/es/scripts/remote_alpha_spire_agent.sh"
      ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] "cat > '$D/internal/remote_alpha_spire_agent.py'" < "$T/es/scripts/internal/remote_alpha_spire_agent.py"
      BOX "chmod 0755 '$D/remote_alpha_spire_agent.sh' && sudo -n chown -R root:root '$D' && sudo -n sha256sum '$D/remote_alpha_spire_agent.sh' '$D/internal/remote_alpha_spire_agent.py'"
    Expected the two sums from A3. If either differs, go to B10.
B5. Status before, read only:
      BOX "sudo -n '$D/remote_alpha_spire_agent.sh' status"; echo "exit $?"
    Expected: exit 1, result "attention". The three units are active, "agent identity" is ok with hours left, "bootstrap" is attention (insecure_bootstrap = true), and "bundle file" is info. "reboot readiness" may be attention. If "agent identity" is a failure or the server is not active, stop here, go to B10 and report (stop condition).
B6. Pin plan, changes nothing:
      BOX "sudo -n '$D/remote_alpha_spire_agent.sh' pin"; echo "exit $?"
    Expected: exit 0, result "planned", "no changes made; rerun with --apply". The plan writes the bundle file, edits agent.conf, restarts the agent and perhaps writes /etc/tmpfiles.d/spire.conf. If it refuses (exit 1), go to B10 and report.
B7. Pin, the one change of this run (about 1 to 2 minutes; ES restarts once):
      BOX "sudo -n '$D/remote_alpha_spire_agent.sh' pin --apply"; echo "exit $?"
    Expected: exit 0, result "ok". The checks report the same agent ID as before, a live server record, a workload SVID and es.service active.
    If it fails, the helper has already restored the original agent.conf: go to B8. Only if its message says "rollback failed", run this fallback, then go to B8:
      BOX 'b=$(sudo -n sh -c "ls -1t /etc/spire/agent/agent.conf.bak-* | head -1"); printf "restoring from %s\n" "$b"; sudo -n cp --preserve=mode,ownership "$b" /etc/spire/agent/agent.conf && sudo -n systemctl restart spire-agent.service && sudo -n systemctl start es.service; systemctl is-active spire-agent es'
B8. Status after, read only:
      BOX "sudo -n '$D/remote_alpha_spire_agent.sh' status"; echo "exit $?"
    Expected after a successful B7: exit 0, result "ok". "bootstrap" is pinned and confirmed by SPIRE, "bundle file" matches the server bundle, "reboot readiness" is ok, and the agent fingerprint is the same as in B5.
B9. Second pin, and the state after (red-team O-RT2):
      BOX 'systemctl show -p ActiveEnterTimestamp spire-agent.service es.service'
      BOX "sudo -n '$D/remote_alpha_spire_agent.sh' pin --apply"; echo "exit $?"
      BOX 'systemctl show -p ActiveEnterTimestamp spire-agent.service es.service; systemctl is-active spire-server spire-agent es; sudo -n grep -n -E "^[[:space:]]*(insecure_bootstrap|trust_bundle_path|trust_bundle_url|trust_bundle_format)[[:space:]]*=" /etc/spire/agent/agent.conf; sudo -n sha256sum /etc/spire/agent/agent.conf /etc/spire/agent/bootstrap-bundle.pem; sudo -n ls -ln /etc/spire/agent/; if [ -e /etc/tmpfiles.d/spire.conf ]; then ls -ln /etc/tmpfiles.d/spire.conf; cat /etc/tmpfiles.d/spire.conf; else echo "no /etc/tmpfiles.d/spire.conf"; fi'
    Expected: the second pin gives exit 0 and "nothing to change". Both ActiveEnterTimestamp values are unchanged by it. The only bootstrap line is: trust_bundle_path = "/etc/spire/agent/bootstrap-bundle.pem" (no "$" in it).
B10. Remove the box folder:
      BOX "case '$D' in /tmp/spire-pin.??????) sudo -n rm -rf -- '$D' && echo removed;; *) echo refusing;; esac; ls -d /tmp/spire-pin.* 2>/dev/null || echo 'no spire-pin folder left'"

Part C, on the Mac:
C1. Remove "$T": rm -rf "$T" (only that folder). Then: ls -d "$T" 2>/dev/null || echo "removed"; ls -d /Users/ds/Repositories/Playground

Report, for every step: the command, its complete output and its exit status. At the end list which expectations did not hold.
