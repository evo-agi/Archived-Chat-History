# Provenance-only check of PR #34 at 188a859 (INF-14)

**Verdict: ACCEPT (provenance only).** `188a859` is the accepted `9993c62` plus git's own merge of trunk_dev `725c97a`, with an unchanged patch. My v2 manifest reproduces the writer's `a36d3ec3…3489` byte for byte. trunk_dev has since moved again, to `42db339` (#37). That merge is also clean, and #37's new contract tests pass on it. The branch must take it before the merge gate, and the result needs one more provenance-only check like this one.

```text
00:04-00:06Z 2026-11-24, audit clone, read-only, nothing pushed
head 188a859f…  parents 9993c62e… (accepted: 06 ACCEPT, 07 red-team ACCEPT) + 725c97a9…
tree 16949074… = git merge-tree --write-tree 9993c62 725c97a, so no hand edits
git diff 400ff7f 9993c62 vs git diff 725c97a 188a859: byte-identical; range-diff all 4 commits "="
5 PR blobs at 188a859 = at 9993c62; the merge brings in only trunk_dev's own paths
v2 (recipe c08597e2…a3ca, HEAD reset to 725c97a, upstream origin/trunk_dev), two runs in a fresh 0700 dir:
  manifest_sha256 a36d3ec35972e31c2eb1e0d035db4abecac629c4f1cc1125cb2204fbc2c93489
  textual_diff_sha256 bdd63d91…2e12 (unchanged); file list = 872f41db; only "head" differs
  runs byte-identical, and byte-equal to 08-evidence/manifest-v2-188a859.json
CI on 188a859: run 45293900583 in progress at 00:06Z (the gate must see it pass)
trunk_dev now 42db3392… (#37 runbook renames + runbook_paths_contract_test.go):
  trial merge tree 6fef29ca… clean, no shared path; on it, TestMarkdownRelativeLinksResolve,
  TestRunbookPathMentionsExist and TestMarkdownLinkTargetsReadsEveryLinkForm PASS
```
