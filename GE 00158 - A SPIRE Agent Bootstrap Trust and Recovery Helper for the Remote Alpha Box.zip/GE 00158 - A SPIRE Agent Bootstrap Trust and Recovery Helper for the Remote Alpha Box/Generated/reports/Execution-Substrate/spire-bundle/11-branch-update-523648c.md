# INF-14 / ES PR #34: branch update to trunk_dev 523648c (report 11)

Writer report, 2026-11-24. Scripts-only PR. No box access, no secrets.

## What changed

trunk_dev moved from 4c991ba (#39) to 523648c (#43, README.md only) after the
move commit bd998e2 was pushed, so the PR was behind and could not merge under
the "up-to-date branch" rule. I merged trunk_dev into the PR branch.

| | |
|---|---|
| New head | 17afef11509933058eec48db5ec810ad0cc515b8 (parents bd998e2, 523648c) |
| Tree | 72cd6531385ef882acb7441724be9414f37587b9 = `git merge-tree --write-tree bd998e2 523648c` (no hand edits, no conflicts) |
| Base | 523648cc9880c63d7e6592c2ae0754582d32f169 |
| Manifest v2 | 7b8174430d88487c0494dd59a091c7316f42542476c33e85a1c39b8969d6e489 (two runs identical; tool sha c08597e2…a3ca verified before the runs) |

## Why the delta check of bd998e2 still covers this head

- The PR patch is byte-identical: `git diff 4c991ba bd998e2` and
  `git diff 523648c 17afef1` both hash to cbf9c2d5…1eb4.
- Manifest 7b817443 differs from 05ed7f49 (bd998e2) only in the `head` field;
  every file entry is the same.
- #43 touched README.md only, which is not a PR path.
- The five PR blobs at 17afef1 are the same as at bd998e2 (list in
  11-evidence/checks.txt). Four are byte-identical to the accepted 9993c62;
  the test file is the moved file from report 10 (b6731cc8…a717).

So the delta check asked for at bd998e2 (move commit plus the #39 merge) applies
unchanged to 17afef1; the only new thing to confirm is that the tree is the
clean merge-tree, which checks.txt shows.

## Evidence

11-evidence/: manifest-v2-17afef1.json, checks.txt, SHA256SUMS.txt.

## Next

CI on 17afef1, the delta check, then the merge gate (squash into trunk_dev,
post-merge byte check). The box run waits for David's go in the writer thread.
