# SPIRE agent bootstrap trust and recovery helper (INF-14, PR #34)

**Verdict: IMPLEMENTED, scripts, tests and docs only. Draft PR [#34](https://github.com/evo-agi/Execution-Substrate/pull/34) at `0927911`. Needs a fresh independent audit. Under the merge policy (tests, docs, scripts) it needs audit plus the merge gate, not David's review. Red-team: the coordinator's call (Addendum B leaves it open).**

```text
IMPLEMENTATION REPORT
Objective:        one operator helper for the Remote Alpha SPIRE agent with status, pin and recover
                  modes (Addendum B §9 of the infra security audit), tested in CI against real
                  SPIRE 1.14.4 including refusal of an impostor server
Repository:       evo-agi/Execution-Substrate
Base ref and SHA: origin/trunk_dev 8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce
                  (work started on 036d507; moved onto 8ba1edb after PR #26 landed, which touches
                  only es/admission tests: no overlap, no conflict)
Topic branch:     claude/project-thread-wg7jh5
Topic head SHA:   09279115ef4ae736777174e9d3293a9741571701 (2 commits on 8ba1edb)
Tree SHA:         afddc143f459bdb84213c0c1249886c75300c515
v2 manifest:      manifest_sha256 2632287f9e61b11facbc0ecf9742015bcb2f29ce37e3855756eac1299527d790
                  textual_diff_sha256 91658c83b79a488114b6d0104f2de7b8fdc6b09f02bb5fa31887c9a91cd7b740
                  5 files, upstream origin/trunk_dev, HEAD at 8ba1edb when taken,
                  tool sha256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca verified
Final status:     clean (git status --porcelain empty after the commit)
Effect status:    TOPIC_BRANCH_PUSHED | DRAFT_PR_OPENED https://github.com/evo-agi/Execution-Substrate/pull/34 |
                  MERGE_NOT_PERFORMED | INDEPENDENT_AUDIT_NOT_PERFORMED | BOX_RUN_NOT_PERFORMED
```

## 0. In plain words

The box's SPIRE agent proves who it is with a one-time join token, and it accepts whatever server answers on its server address the first time it starts (`insecure_bootstrap = true`). While it runs, it renews its own certificate every day, so nothing breaks on a fixed date. But if the box or the SPIRE server is off for longer than the certificate has left (one to two days), the agent can never get back in by itself, and ES stays down with it. Today the only way back is to redo the first start by hand, trusting whatever answers.

This PR adds one script that fixes both halves. `pin` writes down which server the agent should trust (the server's CA certificates, read over its private admin socket) and switches the agent from "trust anyone" to "trust only that", without re-registering it. `recover` brings back an agent whose certificate expired: it pins first, then registers a fresh agent with a new single-use token that never appears on a command line, in a log or in output. `status` tells the operator, read-only, whether any of this is needed. The tests run the script against the real SPIRE 1.14.4 binaries the box uses and show that a pinned agent refuses an impostor server, while the box's current configuration happily joins it.

Nothing ran on the box. The single box run (`status`, `pin`, `status`) is scheduled separately, first in the order SPIRE, Nomad lock, firewall.

## 1. Facts the design rests on

From Addendum B (tested on SPIRE 1.14.4, box binaries hash-identical) and the box inventory, re-checked in this PR's tests where they matter:

| Fact | Source | Used for |
|---|---|---|
| Agent attests with `join_token`; cannot re-attest | box agent.conf; inventory "Can re-attest: false" | recover needs a new token and a fresh data directory |
| Agent SVID life = server `default_x509_svid_ttl` (48h on the box), renewed at about half-life while running | Addendum B E3; tests (15 s / 60 s lifetimes) | status attention threshold 12h; operator rule "off for more than a day" |
| `insecure_bootstrap` and `trust_bundle_path` are mutually exclusive; the bundle file is read only at a fresh bootstrap, cached agent data wins on restart | Addendum B E4/E5; pin test (same agent ID after pin + restart) | pin needs no re-attestation; recover re-exports the bundle before bootstrapping |
| Pinned fresh agent refuses an impostor ("certificate signed by unknown authority"); insecure one attests to it | Addendum B E6; pin test reproduces both | the security proof |
| Admin socket `/run/spire/server/private/api.sock` is `spire:spire 0600` | box inventory | bundle export and token generation as `spire` over the socket, never TCP 8081 |
| `es.service` has `Requires=spire-agent.service`, which has `Requires=spire-server.service` | box units | agent restart restarts ES; helper brings ES back and checks it |
| SPIRE runtime dirs under `/run` (root-only parent); no evidence of a boot rule | inventory (tmpfiles.d not captured: Unknown) | status reports boot readiness; pin adds `/etc/tmpfiles.d/spire.conf` only if needed |
| SPIRE records a renewed SVID's expiry on the server only when the agent first presents it | found while testing (section 6) | pin uses the healthcheck, not the server record, as its precondition; verification waits for a live record |
| `spire-agent run -joinTokenFile <file>` exists in 1.14.4 | real-binary tests | token passed by file, not by a temporary config copy (deviation D1) |

## 2. What the helper does

Files: `scripts/remote_alpha_spire_agent.sh` (13-line wrapper: `exec /usr/bin/python3 -I -B scripts/internal/remote_alpha_spire_agent.py "$@"`) and `scripts/internal/remote_alpha_spire_agent.py` (about 1,400 lines, standard library only). Every path, account, unit, binary and timeout is a field of a frozen `Layout` dataclass whose defaults are the box values; the entry point uses `Layout()` unchanged and reads no environment variable and no path option. Tests import the module and pass their own `Layout`. Commands run with `env={PATH: fixed, LC_ALL: C}`, `cwd=/`, stdin closed, a timeout, and as `spire` through `setpriv --reuid=spire --regid=spire --init-groups --reset-env --` when they talk to SPIRE. `umask 077`; `pin` and `recover` take an exclusive `flock` on `/run/execution-substrate-remote-alpha-spire-agent.lock`. Must run as root (exit 2 otherwise). Exit codes: 0 ok / plan / status with nothing to act on; 1 refused / failed / status needing attention; 2 usage or not root. Output is text or `--json` (schema `execution-substrate.remote-alpha.spire-agent.v1`), always passed through the redactor (section 4).

### 2.1 status (read-only)

Checks, each `ok` / `info` / `attention` / `fail`:

- `server`: `spire-server.service` active, and the admin socket's owner and mode.
- `agent identity`: read from `/var/lib/spire/agent/agent-data.json` (opened `O_NOFOLLOW|O_NONBLOCK`, size-capped, parsed with `openssl x509`): agent ID (redacted) plus a `sha256:` fingerprint, expiry and hours left. Under 12h is `attention`, expired is `fail` ("run recover"), unattested or unreadable is `fail`.
- `server agent record`: the server's record of that agent ID (`agent list -output json` over the socket): missing, banned, live, or trailing the local SVID (`attention` with the record-lag explanation).
- `other agent records`: count of other records and how many expired (stale records from earlier bootstraps).
- `bootstrap`: `insecure_bootstrap` (attention, "run pin"), `trust_bundle_path` to the expected file (ok), or unrecognized.
- `bundle file`: matches the server's current bundle, differs (info: read only at a fresh bootstrap; recover re-exports first), absent while agent.conf names it (attention), unparseable.
- `boot directories`: each runtime directory covered by a tmpfiles.d line (as `systemd-tmpfiles --cat-config` merges them) or a unit's `RuntimeDirectory=`.
- `agent health`: `spire-agent healthcheck` as `spire`.

### 2.2 pin [--apply]

Preconditions (refusal, nothing changed): server active; agent unit active; local SVID valid; the server has an unbanned record for it; healthcheck passes. Then `Pinning.inspect()` computes the three changes; without `--apply` it prints them and stops. With `--apply`, in this order:

1. **Bundle.** `spire-server bundle show -socketPath <admin socket> -format pem` as `spire`. Strict PEM parse (only CERTIFICATE blocks and whitespace, no CR, valid base64). Every certificate must be a CA (`CA:TRUE`) whose URI SANs are exactly `[spiffe://execution.internal]`; at least one unexpired; no repeats. Written atomically (same-directory temp file, final owner and mode before rename, fsync file and directory) to `/etc/spire/agent/bootstrap-bundle.pem`, `root:root 0644`, unless the file already holds exactly that set. Re-read and compared after writing.
2. **Boot rule.** For each runtime directory with no boot rule, one `d <path> <mode> <user> <group> -` line copying its current owner and mode. Before writing, the box's own `systemd-tmpfiles --root=<sandbox> --create <candidate>` must create exactly those directories with those owners and modes under an empty sandbox (owners resolved from a copy of `/etc/passwd` and `/etc/group`). Written to `/etc/tmpfiles.d/spire.conf` (exclusive create); refused if that file exists but does not cover the directories.
3. **agent.conf.** `analyze_agent_config` accepts exactly one shape for an edit: one `agent {` block, exactly one `insecure_bootstrap = true` line inside it, and no `trust_bundle_path`, `trust_bundle_url`, `trust_bundle_format` or `trust_bundle_unix_socket` anywhere; no CR, no block comment, and no key named outside such a line. The one line is replaced (indentation kept) by `trust_bundle_path = "/etc/spire/agent/bootstrap-bundle.pem"`; the result must classify as pinned. The original bytes, owner and mode go to `agent.conf.bak-<UTC stamp>` (exclusive create); the edit is written atomically with the original owner and mode, after re-checking the file did not change during the run. `spire-agent validate -config` as `spire`; on failure the backup is restored and the run fails.
4. **Restart only if agent.conf changed.** `systemctl restart spire-agent.service` (ES restarts through `Requires=`). Then, within fixed timeouts: healthy agent; the same agent ID as before with a valid SVID (no re-attestation); a live, unbanned server record for it; a workload SVID for `spiffe://execution.internal/workload` (`spire-agent api fetch x509` as root, the box's workload entry); every dependent unit that was active before is active again (started if Requires= left it stopped). On any failure: restore the original agent.conf, restart, run the same verification, and report "pin failed and was rolled back" (or that the rollback also failed). The bundle file and tmpfiles rule stay: both are inert or correct on their own.

A second `pin --apply` changes nothing. `pin` never generates a join token.

### 2.3 recover [--apply] [--evict-old-agent]

Refuses (nothing changed) when: the server is not active; the local SVID is valid; the local state is unreadable; the server still records a live, unbanned SVID for the expired local ID (inconsistent: inspect by hand); no registration entry has `spiffe://execution.internal/spire-agent` as parent (a new agent would serve nothing); the data path is not a directory; the backup name already exists. Then the same `Pinning.inspect()` (so a hand-edited agent.conf is refused here too). With `--apply`:

1. The three pinning steps (bundle re-exported now, so a CA rotation since the last pin cannot make the bootstrap fail or trust a stale set).
2. Stop `spire-agent.service` (ES stops with it), wait until inactive.
3. Rename `/var/lib/spire/agent` to `/var/lib/spire/agent.recover-<UTC stamp>` (kept) and create an empty directory with the old owner and mode (`spire:spire 0750` if there was none).
4. `attest_once`: a private directory under `/run` (`mkdtemp`, then chown `spire`, mode 0700); `spire-server token generate -spiffeID spiffe://execution.internal/spire-agent -ttl 120 -output json` as `spire`; the value must be a UUID; it is added to the redactor's secrets list at once; written to `join-token` in that directory with `O_CREAT|O_EXCL|O_NOFOLLOW`, `fchown spire`, `fchmod 0600`. Then `setpriv ... spire-agent run -config /etc/spire/agent/agent.conf -joinTokenFile <file>` in its own session, output to a log file in the private directory. It waits up to 60 s for a new, valid agent identity different from the old one, deletes the token file immediately, checks the server lists the new agent, stops the process (SIGTERM, then SIGKILL after 15 s) and removes the private directory (with a warning in the report if it cannot). If the process exits or no new identity appears within the timeout, or the server does not list it: failure (the redacted tail of the agent's log goes into the message), then the data directory rollback (step 5).
5. Rollback on attestation failure: move the new directory to `/var/lib/spire/agent.failed-<stamp>`, move the backup back, leave both units stopped, and say the token expires 120 s after generation.
6. Start `spire-agent.service`, then the section 2.2 verification with the new ID, starting `es.service` regardless of its earlier state.
7. With `--evict-old-agent` only: `agent evict` for exactly the replaced ID (if still listed) and `entry delete` for the entries whose parent is that ID. Without it, the report says the expired record and alias stay.

## 3. Deviations from Addendum B

| # | Addendum B | This PR | Why |
|---|---|---|---|
| D1 | Token through a temporary spire-owned 0600 copy of agent.conf with `join_token` | `-joinTokenFile` pointing at a 0600 spire-owned file in a private 0700 tmpfs directory | Same exposure (a 0600 file readable by spire and root), without writing and deleting a second config that would need the same strict parsing. Proven against the real 1.14.4 agent binary. |
| D2 | Token `-ttl 300` | `-ttl 120` | Attestation takes seconds; 120 s halves the window in which a leaked token is usable while staying well above the 60 s attestation timeout. |
| D3 | status reads expiry from `agent list` | Local `agent-data.json` first, server record second | The server record trails a renewed SVID until the agent presents it (section 6), so the local file is the truth for "will the agent keep working"; the record is still reported. |
| D4 | Test lifetimes 2 min | 15 s (recover) and 60 s (pin) | Shorter runs; 60 s for pin because its impostor episode keeps the agent stopped longer than 15 s. |
| D5 | Runbook entry in the same PR | Deferred to the box run | Runbook norm: written when a procedure first runs on the box. The contract section already carries the operator rule. |
| D6 | (not in the plan) | Dependents are restarted when Requires= leaves them stopped; pin rolls back a failed restart | A failed agent start leaves ES stopped, and a plain agent start does not start it. |
| D7 | (not in the plan) | Sandbox check of the tmpfiles rule with the box's own `systemd-tmpfiles` | The rule's effect is otherwise first seen at the next reboot. |

## 4. Secret handling

- The join token is in this process's memory, in the 0600 file, and in the `spire-agent run` process that reads the file. It is never in argv, an environment variable or output. The file is deleted as soon as the new identity appears, and the directory is removed in a `finally`.
- SPIRE names a join-token agent `spiffe://<td>/spire/agent/join_token/<token>`. So once spent, the token is part of the agent ID, which appears in SPIRE's own logs and `agent list`. That is inherent to `join_token` and is why the inventory's agent ID must stay out of repos (already a project rule). The helper prints every agent ID with the token part replaced by `<redacted>` (regex on the `spire/agent/join_token/` prefix) plus a `sha256:` fingerprint for comparisons, and replaces any registered secret string anywhere in the report.
- The bundle file holds public CA certificates only (`0644`). No private key is read or written.

## 5. Tests

`remote_alpha_spire_agent_test.go`, root package, 7 tests, 35 tests and subtests with verdicts. The two flow tests run in parallel, about 55 s together.

**Fixture.** A per-test root under a short `os.MkdirTemp` path; the real `spire-server` and `spire-agent` from the release tarball named by `SUPPORTED_LOCAL_TEST_SPIRE_TARBALL` (CI already sets it), checked against `scripts/internal/spire_release.sha256` before extraction. Server and agent configurations follow the box's shape (join_token node attestor, disk key managers, sqlite datastore, admin socket, trust domain `execution.internal`; agent with `insecure_bootstrap = true` and the unix workload attestor), with `ca_ttl = "1h"` and the test SVID lifetime. `bootstrapLikeTheBox` attests the agent with a join token and creates the box's workload entry under the `spire-agent` alias. A fake `systemctl` (Python) keeps pid files, follows the box's `Requires=` chain (start pulls required units up, stop takes dependents down, restart restarts active dependents), waits for sockets and sets 0600, and can fail the next start of a unit once. A fake `setpriv` checks its exact arguments, logs them and execs the command as the test user. Shims in front of the real binaries log argv and the token file's mode and owner, and can inject a `validate` failure or an attestation crash. A `/proc` watcher records every command line while the flow runs.

| Test | What it proves |
|---|---|
| `PinAgainstRealSPIRE` (60 s SVID) | status on the box shape is `attention`; `pin` without `--apply` changes nothing; injected validate failure restores agent.conf byte-for-byte; injected restart failure rolls back, restarts, and ES is active again; real `pin --apply`: diff is exactly the one line, backup holds the original, bundle equals the server bundle, the tmpfiles rule applied by real `systemd-tmpfiles --create` under an empty root creates the directories with the rule's owners and modes, the agent ID is unchanged, ES restarted; second `pin --apply` is a no-op; **impostor: server stopped, impostor on its port; fresh bootstrap with the pinned conf is refused with "certificate signed by unknown authority" and stores no identity; the same with the original conf attests (control)**; the real server comes back and the agent restarts from cache with the same ID. |
| `RecoverAgainstRealSPIRE` (15 s SVID) | recover refuses a valid SVID; after a real expiry, an injected attestation crash puts the old data directory back and leaves units stopped; real `recover --apply` gives a new valid identity under the alias, ES active; the token is in no output, no logged command line (shims, fake setpriv, fake systemctl) and no `/proc/*/cmdline`; both token files were 0600, owned by the SPIRE account, under the scratch parent, and nothing is left there; old directory kept byte-for-byte; config pinned; without `--evict-old-agent` the expired record and alias stay; a second expiry recovered with `--evict-old-agent` removes exactly that agent's record and alias entry. |
| `BundleExportChecks` | 12 cases on the export checks with openssl for real: one current CA; expired plus current; leaf; other trust domain; workload URI; current plus leaf; only expired; trailing text; private key block; CRLF; empty; repeated. |
| `ConfigAnalysis` | 16 agent.conf shapes, including the box's exact file, commented key, one-line block, two blocks, key outside the block, CRLF, block comment, url, spiffe format, both keys, other bundle path. |
| `LayoutPinsBoxValues` | every `Layout` default equals the box value; the Python source names no `os.environ`, `getenv`, `putenv` or `environb`; the entry point runs `main` with `Layout()`; the wrapper execs `/usr/bin/python3 -I -B` on the core. |
| `UsageAndRootRefusal` | a caller that is not the required UID gets exit 2, "must run as root" and no output; `status --apply`, `pin --evict-old-agent`, an unknown mode and no mode exit 2; the wrapper's `--help` works. |
| `HelperIsDocumented` | PLANS names the helper; the docs section, the commands, the schema, both file paths and the operator rule are present. |

**Mutation checks** (`01-evidence/mutations-*`), each applied to a copy and run against the matching test:

| Mutant | Change | Killed by |
|---|---|---|
| M01 | pin writes the original agent.conf bytes back instead of the edit | `PinAgainstRealSPIRE`: "pin changed more or less than the insecure_bootstrap line" |
| M02 | token passed as `-joinToken <token>` instead of `-joinTokenFile` | `RecoverAgainstRealSPIRE`: "the join token appeared in a logged command line" |
| M03 | redaction turned off | `PinAgainstRealSPIRE`: "status agent identity is not ok and redacted" |
| M04 | recover's valid-SVID refusal removed | `RecoverAgainstRealSPIRE`: "recover on a healthy agent was not refused for its valid SVID" |
| M05 | data directory rollback is a no-op | `RecoverAgainstRealSPIRE`: old agent-data.json not back after the injected crash |
| M06 | CA / trust-domain check on the exported bundle removed | `BundleExportChecks`: leaf, other trust domain, workload URI, current plus leaf accepted |
| M07 | dependents not started after an agent (re)start | `PinAgainstRealSPIRE` (restart-failure rollback) and `RecoverAgainstRealSPIRE` |
| M08 | no restore after a validate failure | `PinAgainstRealSPIRE`: "agent.conf was not restored after the validate failure" |
| M09 | token file mode 0644 | `RecoverAgainstRealSPIRE`: "join token file was not a 0600 file of the SPIRE account" |
| M10 | "at least one unexpired CA" check removed | `BundleExportChecks/only_expired_ca` |

All ten ran on the dbb6a02 bytes (`mutations/results-dbb6a02.txt`, one log each). A first run on earlier test bytes killed M02 only incidentally (the attestation-crash injection keyed on `-joinTokenFile`, so the mutant failed before the token checks ran). I changed the injection to fire on `-joinToken` too, and M02 is now killed by the token-leak check itself (`mutations/results-first-run-pre-shim-fix.txt`, `M02-after-shim-fix-first-rerun.log`).

## 6. Found while testing

- **SPIRE record promotion lag.** After a renewal, `agent list` keeps the old expiry until the agent presents the new SVID on its next sync. An early version required "server record not expired" before pinning and refused a healthy agent; now pin requires the healthcheck, status reports a trailing record as `attention` with the explanation, and post-start verification waits for a live record.
- **Requires= does not bring ES back after a failed start.** Covered by D6 and the restart-failure test.

## 7. Validation

| Command | Bytes | Result |
|---|---|---|
| `go test -count=1 -v -run '^TestRemoteAlphaSPIREAgent' .` as root, Python 3.13.18 | 0927911 on 8ba1edb | 7/7 PASS, 49.1 s (`helper-tests-root-0927911.log`) |
| `go test -count=1 -json .` (whole root package) as unprivileged `ci` (uid 1500, no sudo), Python 3.12.3, head copy vs base 036d507 | head copy byte-identical to dbb6a02 for all 5 paths (root package files are identical between 036d507 and 8ba1edb) | head 2056 pass / 235 fail / 0 skip, base 2021 / 235 / 0; **failing only on head: 0**; 35 tests only on head, all pass (`root-package-compare-head-vs-base.txt`). The 235 shared failures (other Remote Alpha operator and TLS-status tests that need host facilities this container lacks) are the same set on base. |
| Mutation runs | dbb6a02 (0927911 differs by one comment) | 10/10 killed |
| `go vet .`, `gofmt -l` on the test file, `bash -n` on the wrapper, pyflakes on the Python | 0927911 | clean |
| GitHub Actions "build, vet and test" on the PR | 0927911 | **success** (run 45250138980, job 137957431069, 19:33:37Z to 20:02:51Z); the gate fails on any unlisted skip, so the new tests ran |

## 8. Files touched

| Path | Kind | Summary |
|---|---|---|
| `scripts/remote_alpha_spire_agent.sh` | new, 0755 | wrapper |
| `scripts/internal/remote_alpha_spire_agent.py` | new | helper core |
| `remote_alpha_spire_agent_test.go` | new | tests (section 5) |
| `.docs/system_overview/remote_supported_host_alpha.md` | modified | new section "Remote SPIRE Agent Bootstrap Trust And Recovery Helper" (Bounded slice rule) before "Non-Goals" |
| `PLANS.md` | modified | one bullet naming the helper |

Dependencies changed: none (standard library only; Go test uses only the standard library). CI workflow and gate files: untouched. Authority widening: none in the repo; on the box the helper is a root tool that edits `agent.conf`, writes two files and restarts SPIRE and ES, only with `--apply` and only when run by the operator. Cross-repo impact: none. Artifact hygiene: no `__pycache__` (`-B` everywhere), no stray files; `git status --porcelain` empty after the commit.

## 9. Provenance

- Recipe: `governed-execution.audit-patch-manifest.v2`, source `/mnt/project-files/claude-conversion/tools/governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before each run).
- Taken with HEAD reset (`--mixed`) to `8ba1edb`, the 0927911 bytes in the working tree, nothing staged, branch `claude/project-thread-wg7jh5` checked out, upstream pinned to `origin/trunk_dev`; two runs to absent paths in a fresh 0700 directory outside the repo, byte-identical.
- `manifest_sha256` `2632287f9e61b11facbc0ecf9742015bcb2f29ce37e3855756eac1299527d790`, `textual_diff_sha256` `91658c83b79a488114b6d0104f2de7b8fdc6b09f02bb5fa31887c9a91cd7b740` (covers the two tracked files only; untracked new files are in the manifest, not the diff hash), 5 files.
- After `git reset --mixed` back to the tip: `git diff --name-only 8ba1edb 0927911` equals the manifest path set, and every committed blob matches the manifest SHA-256 and size; git modes 100644/100755 match 0644/0755. `git status --porcelain` empty.
- History: the first commit `dbb6a02` was taken the same way (single commit, manifest `74602a08e6759207026fc512eb2d2a0233abd7cb40d7ee467e7bdfb2fe4628a0`, staged set equal to it). The second commit `0927911` changes only the test file's header comment (which said 15 s for both flow tests). The full-range manifest above supersedes the first; both are in the evidence folder.
- Complete canonical manifest (exact bytes, one line plus newline):

```json
{"branch":"claude/project-thread-wg7jh5","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/remote_supported_host_alpha.md","sha256":"78f75d98095988deb56f6873084497e06e9d4bff79e25b23f0c0fe3567f28c6b","size":348834},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"fcfed704f11b2774c518a3d16883a0262773828e65a76001f943f6e16201ad62","size":315532},{"file_type":"regular","kind":"untracked","mode":"0644","path":"remote_alpha_spire_agent_test.go","sha256":"a3f8dcdb3cbdbed36b6f7eb570aa4fd3b31978a8a0487813a2537721a37f8e77","size":64763},{"file_type":"regular","kind":"untracked","mode":"0644","path":"scripts/internal/remote_alpha_spire_agent.py","sha256":"5541848babdf644723bf859bfcf6d2fca814d3e821b864c1cf43646347af5642","size":63595},{"file_type":"regular","kind":"untracked","mode":"0755","path":"scripts/remote_alpha_spire_agent.sh","sha256":"3da361743428cdab50cd2352aa38074e1b0424ace2afbd7ddfb2d56bd669531c","size":730}],"head":"8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"91658c83b79a488114b6d0104f2de7b8fdc6b09f02bb5fa31887c9a91cd7b740","upstream":"origin/trunk_dev"}
```

## 10. Assumptions, seams and non-claims

- **Not proved here, only by the box run:** real systemd `Requires=` propagation, real `setpriv` privilege drop, the tmpfiles rule surviving a reboot, and the box's actual runtime-directory owners and modes. The box run is `status`, `pin`, `status` (Addendum B.4); `recover` runs on the box only after a real expiry.
- **After a successful attestation, recover does not roll back** if the unit start or verification fails: the old identity is expired, so putting it back would not help. The report says what failed and the new data directory stays.
- **A failed pin keeps the bundle file and the tmpfiles rule**: the bundle is inert while agent.conf is insecure, and the rule matches the directories as they are.
- **Hand-edited agent.conf shapes are refused**, not edited. If the box file differs from the inventory copy (one `insecure_bootstrap = true` line in the `agent` block), pin refuses and says why.
- **Lock is advisory**: it serialises two helper runs, not a human editing agent.conf at the same moment (the pre-write re-read narrows that window).
- `status` exit 1 on `attention` is by design so a script can alert on it.
- Long-term (not this PR): a re-attestable node attestor, expiry alerting from the Maintenance Agent, SPIRE-issued service certificates, the box's SPIRE config in a repository (INF-03).

## 11. Confidence

- Provenance: high (two identical v2 runs, staged set equals manifest, single clean commit pushed).
- Validation: high for the helper logic against real SPIRE; medium for systemd and setpriv behaviour until the box run.
- Implementation: high; the riskiest surfaces for an audit are the in-place agent.conf edit and rollback paths, token custody in `attest_once`, and the bundle checks.

## 12. Evidence

`01-evidence/` (SHA256SUMS.txt lists every file): environment, manifest and staged-set check, root-run helper log, root-package head and base JSON (gzip) with the comparison and the scripts that produced it, mutation definitions, harness, results and logs, and sample helper reports captured from a test run (agent IDs redacted by the helper; test data only, no box data). `mutations/M03-redaction-off.log` shows unredacted agent IDs on purpose (that mutant turns redaction off); they come from a throwaway test server that no longer exists, and their tokens were spent at bootstrap.
