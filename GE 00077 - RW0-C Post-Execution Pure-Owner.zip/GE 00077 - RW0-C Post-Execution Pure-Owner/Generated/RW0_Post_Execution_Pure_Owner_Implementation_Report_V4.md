# RW0 Post-Execution Pure-Owner Implementation — V4 Paging-Causality Repair Report

Date: 2026-10-06  
Repository: Governed Execution Coordinator  
Baseline: `trunk_dev` at `a3ff0b7f4f0c2378c2962e24612d605489b51638`

## 1. Outcome

The bounded V4 test-only repair is complete. All eight accepted paging malformed controls, `malformed.V3G020` through `malformed.V3G027`, now execute the real production action exactly three times in the required baseline/hostile/restoration sequence. Each baseline and restoration is accepted exactly; each hostile transcript reaches `rw0_c_decision_membership_closure` and raises the exact private production contract-violation type. The accepted V11 contract classification remains `basis_conflict`; the concrete first-failure reasons observed from production are recorded below.

The permanent regression coverage combines runtime action/transcript tracing with an AST reachability and anti-shortcut guard. The complete focused validation and formal V02–V06 external-clone sequence passed. This is implementation and provenance evidence only. It is not an independent audit, commit authorization, runtime authorization, durable decision, or permission to widen the accepted boundary.

Primary success token:

`RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIRED_V4_VALIDATED_PROVENANCE_READY_FOR_REAUDIT`

## 2. Fixed and retained inputs

The three direct T40 inputs were verified before repository inspection.

| Input | Bytes | Logical lines | Final LF | SHA-256 | Posture |
| --- | ---: | ---: | --- | --- | --- |
| `RW0_Post_Execution_Pure_Owner_Implementation_V3_Independent_Reaudit_Report.md` | 22,312 | 391 | absent | `8499349aa53b20657fee43259bb1b84465d57f87c8e364bba5481a15239cbba2` | primary verdict `BLOCK` |
| `RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V3.json` | 4,377 | 1 | present | `92331f2082200e62889a27109958fc1b35d7949146b28ac28ee512d157840262` | canonical compact sorted-key JSON |
| `RW0_Post_Execution_Pure_Owner_Implementation_Report_V3.md` | 67,937 | 416 | present | `2875839c7f22f71754ed9565be042c80a8132f88df760cd86e73830c25451155` | historical V3 evidence only |

The retained governing files supplied to the implementation conversation were verified only at their established fixed filenames and locations. No substitute search or fetch was performed. Their exact SHA-256 receipts were:

- original implementation prompt: `2ff652b1aabb65bdb9507a6d6954c139b799f4520591ecc0726b29e5d2888650`;
- V2 repair prompt: `394018c64671b4aeaef6e7b5b5feb9c7e9ee8c4d08425046304eb40cba12b3b0`;
- V3 repair prompt: `bd5eb07c918c890fd35cef628c5cc108d88a8acdebb5a29473b4f4db389851e1`;
- accepted V11 JSONL: `e26a739dc303a555aa951e23ccd84b3583377319a82b5fcd78f99397da894afe`;
- accepted V11 audit: `b5b3c1e9a426a6ce25c5a5bbb622d4a4838459750ebbe457fb9e6f9816f82548`;
- boundary freeze: `02b932abdfdb0085886000c19cdbcc4e9e72ebb951a5030056a621e181d33d55`;
- boundary manifest: `927646d30430d5b6b3acacdc2f4b752721c3ed7ae62673962542120cfce0c386`;
- review overlay: `ba8202629aebd895c7a4bae7ad147a2d68e9d368e27ede80a965b46809b32f92`;
- recipe source: `db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`;
- V2 provenance manifest: `7ada36bd287de85823926090e07e8e33ca1fe038963984c8eed0f423329f1284`;
- V2 implementation report: `ace2c92c66eea311820702cf844a8f802a8a78c82c4c208e37bc42133094e878`;
- V2 independent re-audit: `665d1644070b290a7818660bab21608aeae3a09b7b13df9a1fde93a567931120`;
- V3 opening evidence: `f53fe00b945683270d56b0ee329d98e5c6ad9ec92dd669e47f555d6174108374`;
- V3 provenance manifest and report: the direct-input receipts above.

## 3. Exact opening gate

The pre-edit gate reproduced exactly:

- physical repository root: `/Users/ds/Repositories/Governed Execution Coordinator`;
- branch `trunk_dev`;
- HEAD `a3ff0b7f4f0c2378c2962e24612d605489b51638`;
- tree `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0`;
- sole parent `047563de5a443b0f8323401c92979ae2e444d2ed`;
- subject `feat: implement RW0-C1 durable evidence (#7)`;
- upstream `origin/trunk_dev`, using only the existing local remote-tracking ref;
- divergence `0/0`;
- one worktree;
- zero staged and zero unmerged paths;
- exactly 20 V3 candidate paths: 10 tracked modifications and 10 untracked regular files, all mode `0644`;
- no path outside the V3 manifest differed from HEAD.

The exact `governed-execution.audit-patch-manifest.v1` recipe source was 3,945 bytes, 166 logical lines, final LF present, SHA-256 `db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`. Two serial pre-edit runs were byte-identical to the attached V3 manifest: 20 files, manifest SHA-256 `92331f2082200e62889a27109958fc1b35d7949146b28ac28ee512d157840262`, tracked textual-diff SHA-256 `897e95f470b55690abb2c25bd2b1d0b760ad9e6b0b3541f4ad4f5012cd0f022f`.

The safe opening ignored-cache inventory reproduced byte-for-byte: one root `src/ge_nwp_coordinator/__pycache__`, 37 regular ignored members, aggregate `dbaa5d1ff000e2c00e9b64d5b1e591ac8374e1b9bd9f3a6c5c0c17b3742c8f90`.

`RW0_Post_Execution_Pure_Owner_Implementation_Repair_Opening_Evidence_V4.json` was written outside the repository before the source edit. It is canonical compact sorted-key JSON with final LF, 9,738 bytes, one logical line, mode `0644`, and SHA-256 `2fe83ebeeab9eac746389c3a7e0e31192b3b7164259b1f6c053e90f22bef6a4c`. It is safe evidence only and confers no authority.

## 4. Authorized mutation and V3-to-V4 transition

Only `tests/test_post_execution_pure_owner_vectors.py` changed from V3 to V4.

| Version | Kind | Mode | Bytes | SHA-256 |
| --- | --- | --- | ---: | --- |
| V3 | untracked | `0644` | 88,897 | `ead971979a09c0d2e3d1629668c0647b5beaaa5e3dad59f6948f0aa427af1ca8` |
| V4 | untracked | `0644` | 97,266 | `3a2941defa76d73c4675aab7a16d78b65cc4f1a764bff333dbd38d127f116fc8` |

The repair:

1. removes the unconditional pre-hostile return;
2. constructs a sealed positive V25 value whose entries exactly match each finite accepted transcript;
3. invokes the real production closure action for the accepted baseline;
4. creates an immutable transcript differing at the accepted hostile paging predicate and only its mechanically required paging coordinates;
5. invokes the real production action and captures the exact `_PostExecutionContractViolation.reason`;
6. reconstructs the positive transcript, invokes production a third time, and checks typed output identity, canonical mapping digest, transcript digest, and shared V25/V26 fixture bytes;
7. adds a runtime guard that wraps—but does not replace or bypass—the production action and freezes three calls with positive/hostile/positive transcript-digest order for every affected ID;
8. extends the AST guard to require a single final variable return after three syntactic production calls and the real rejection capture, while forbidding an early return, constant `basis_conflict` return, `expected_rejection` access, or test-authored raise inside the helper.

The accepted V11 field is a failure-or-contract classification. The V4 test does not use a record-ID-to-production-reason mapping. Causal evidence comes from the exact production exception and its concrete reason; the independently fixed record still requires the high-level `basis_conflict` classification.

No production source, documentation, migration, runtime, public surface, durable-state path, or supporting repository changed. Existing `.docs/` status language remains truthful because the repair changes test evidence only; the explicit one-file ceiling prohibited a documentation edit.

## 5. Eight-control causality evidence

| Malformed ID | Positive fixture | Exact mutation | Hostile transcript distinction | Production action | Baseline calls | Hostile calls | Restoration calls | Actual first failure | Positive restoration result |
| --- | --- | --- | --- | --- | ---: | ---: | ---: | --- | --- |
| `malformed.V3G020.membership-page-duplicate` | sealed V25 over the eight frozen V26 entries; one terminal `epoch.1` page | replace row 1 with row 0 | same page/epoch/cursor/length/tail; only the second member becomes an exact duplicate | `rw0_c_decision_membership_closure` | 1 | 1 | 1 | V11 class `basis_conflict`; production reason `duplicate_entry` | PASS; baseline/restored transcript digests and typed output match; shared fixtures unchanged |
| `malformed.V3G021.membership-cursor-nonmonotonic` | sealed V25 over 258 accepted synthetic entries; accepted two-page overlap transcript | replace page-2 cursor with `(0,"0")` | page 1 identical; page-2 epoch/rows/terminal marker identical; cursor alone regresses | `rw0_c_decision_membership_closure` | 1 | 1 | 1 | V11 class `basis_conflict`; production reason `relation_mismatch` | PASS; exact positive transcript and candidate restored |
| `malformed.V3G022.membership-page-reordered` | sealed V25 over the eight frozen V26 entries; one terminal `epoch.1` page | swap the first two page members | same page/epoch/cursor/length/tail; first adjacent pair alone violates ordering | `rw0_c_decision_membership_closure` | 1 | 1 | 1 | V11 class `basis_conflict`; production reason `relation_mismatch` | PASS; baseline/restored transcript digests and typed output match; shared fixtures unchanged |
| `malformed.V3G023.membership-cursor-no-progress` | sealed V25 over 258 accepted synthetic entries; accepted two-page overlap transcript | replace page-1 `next_cursor` with page-1 input cursor | page-1 epoch/cursor/rows and all page-2 coordinates remain positive; continuation cursor alone makes no progress | `rw0_c_decision_membership_closure` | 1 | 1 | 1 | V11 class `basis_conflict`; production reason `relation_mismatch` | PASS; exact positive transcript and candidate restored |
| `malformed.V3G024.membership-overflow` | sealed V25 over exactly 65,536 accepted synthetic entries; 256-page accepted `epoch.overflow` transcript | expose the explicit 65,537th sentinel | first 255 pages identical; terminal page gains only the overflow sentinel plus the mechanically required next cursor/overlap terminal page | `rw0_c_decision_membership_closure` | 1 | 1 | 1 | V11 class `basis_conflict`; production reason `invalid_cardinality` | PASS; 65,536-entry positive transcript accepts before and after hostile probe |
| `malformed.V3G025.membership-premature-termination` | sealed V25 over 258 accepted synthetic entries; accepted two-page overlap transcript | terminate after the first lookahead page | first page is the exact positive page with a continuation; only the required terminal continuation page is omitted | `rw0_c_decision_membership_closure` | 1 | 1 | 1 | V11 class `basis_conflict`; production reason `relation_mismatch` | PASS; omitted page restored byte/value-exactly and positive closure accepts |
| `malformed.V3G026.membership-continuation-substitution` | sealed V25 over 258 accepted synthetic entries; accepted two-page overlap transcript | replace page-2 cursor reference with `foreign-membership.1` | page 1 identical; page-2 epoch/rows/terminal marker identical; continuation cursor alone is foreign | `rw0_c_decision_membership_closure` | 1 | 1 | 1 | V11 class `basis_conflict`; production reason `relation_mismatch` | PASS; exact positive transcript and candidate restored |
| `malformed.V3G027.membership-capability-epoch-change` | sealed V25 over 258 accepted synthetic entries; accepted two-page overlap transcript | replace page-2 epoch `epoch.1` with `epoch.2` | page 1 identical; page-2 cursor/rows/terminal marker identical; capability epoch alone changes | `rw0_c_decision_membership_closure` | 1 | 1 | 1 | V11 class `basis_conflict`; production reason `relation_mismatch` | PASS; exact positive transcript and candidate restored |

Every control therefore has exactly three real production calls. No fixture construction, registry lookup, hard-coded label, mock result, synthetic envelope-only mutation, or test-authored semantic exception receives causal credit.

## 6. Focused validation

Every focused command used `PYTHONDONTWRITEBYTECODE=1` and disabled the pytest cache.

### F01 — eight V3G020–V3G027 nodes

```text
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q 'tests/test_post_execution_pure_owner_vectors.py::test_each_of_93_malformed_controls_executes_its_causal_mutation[malformed.V3G020.membership-page-duplicate]' 'tests/test_post_execution_pure_owner_vectors.py::test_each_of_93_malformed_controls_executes_its_causal_mutation[malformed.V3G021.membership-cursor-nonmonotonic]' 'tests/test_post_execution_pure_owner_vectors.py::test_each_of_93_malformed_controls_executes_its_causal_mutation[malformed.V3G022.membership-page-reordered]' 'tests/test_post_execution_pure_owner_vectors.py::test_each_of_93_malformed_controls_executes_its_causal_mutation[malformed.V3G023.membership-cursor-no-progress]' 'tests/test_post_execution_pure_owner_vectors.py::test_each_of_93_malformed_controls_executes_its_causal_mutation[malformed.V3G024.membership-overflow]' 'tests/test_post_execution_pure_owner_vectors.py::test_each_of_93_malformed_controls_executes_its_causal_mutation[malformed.V3G025.membership-premature-termination]' 'tests/test_post_execution_pure_owner_vectors.py::test_each_of_93_malformed_controls_executes_its_causal_mutation[malformed.V3G026.membership-continuation-substitution]' 'tests/test_post_execution_pure_owner_vectors.py::test_each_of_93_malformed_controls_executes_its_causal_mutation[malformed.V3G027.membership-capability-epoch-change]'
```

Result: `8 passed in 26.26s`.

### F02 — runtime reachability/action-count guard

```text
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_post_execution_pure_owner_vectors.py::test_v4_membership_paging_actions_are_reachable_and_exactly_counted
```

Result: `1 passed in 27.47s`.

### F03 — complete 93-control registry

```text
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_post_execution_pure_owner_vectors.py::test_each_of_93_malformed_controls_executes_its_causal_mutation
```

Result: `93 passed in 27.61s`.

### F04 — no synthetic self-raise / no constant classification / AST reachability guard

```text
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_post_execution_pure_owner_vectors.py::test_malformed_causality_path_has_no_test_authored_semantic_self_raise
```

Result: `1 passed in 0.26s`.

### F05 — complete vector module

```text
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_post_execution_pure_owner_vectors.py
```

Result: `235 passed in 83.03s`.

### F06 — adjacent accepted V25 closure tests

```text
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_post_execution_pure_owner_relations.py::test_v25_resigned_incomplete_subset_rejects_against_complete_transcript tests/test_post_execution_pure_owner_relations.py::test_v25_finite_page_transcript_controls_reject_at_the_causal_layer tests/test_post_execution_pure_owner_relations.py::test_v25_explicit_65537th_entry_overflow_probe_rejects tests/test_post_execution_pure_owner_relations.py::test_membership_closure_is_bounded_sorted_and_duplicate_free
```

Result: `9 passed in 12.54s`.

An additional no-bytecode diagnostic invoked the repaired helper directly to record the eight concrete production reasons shown in the causality table. It was not counted as validation credit.

No pytest command failed during development. One exploratory Python import was initially issued without `PYTHONDONTWRITEBYTECODE=1`; it failed before module resolution and created exactly one new ignored file, `tests/__pycache__/test_post_execution_pure_owner_values.cpython-313.pyc`. The V4 opening inventory proved that root and member were validation-created rather than pre-existing. Only that exact file and its empty directory were removed immediately. No pre-existing cache member was deleted or rewritten, and an immediate full inventory comparison restored the exact 37-member opening aggregate before implementation continued. All credited test commands used the required no-bytecode posture.

## 7. Formal external-clone validation

The formal validation root was a private mode-`0700` temporary directory outside the live repository. Clone-time umask was `022`. The clone used the exact local committed HEAD with the equivalent of:

```text
git clone --no-local --single-branch --no-tags --branch trunk_dev --depth 1 '/Users/ds/Repositories/Governed Execution Coordinator' '<private-validation-root>/repo'
```

No fetch or remote contact occurred. Exactly the 20 saved V4 manifest paths were overlaid. Every overlay path was verified as a regular mode-`0644` file with the exact saved size and SHA-256. Two pre-test recipe runs were byte-identical to the saved V4 manifest, SHA-256 `30beb0acef46bb78eab79629dffadcb6ef40de41fa9fe7e828e30ec76626f3eb`.

Formal commands ran serially without concurrent edit or cleanup.

### V02

```text
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_post_execution_pure_owner_values.py tests/test_post_execution_pure_owner_vectors.py tests/test_post_execution_pure_owner_relations.py tests/test_post_execution_pure_owner_boundaries.py tests/test_c2a_nonimplementation.py tests/test_runtime_non_authority.py tests/test_rw0_b1_boundaries.py
```

Result: `1177 passed in 106.10s`.

### V03

```text
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_rw0_b1_phase_values.py tests/test_rw0_b1_vectors.py tests/test_rw0_b1_relations.py tests/test_worker_execution_semantic_values.py tests/test_worker_execution_semantic_vectors.py tests/test_worker_execution_semantic_relations.py tests/test_worker_execution_semantic_boundaries.py tests/test_finite_backlog.py tests/test_global_stop.py
```

Result: `472 passed in 11.15s`.

### V04

```text
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_section41_cognitive_proposal_row_values.py tests/test_section41_cognitive_proposal_semantic_values.py tests/test_section41_pre_execution_plan_disposition_contracts.py tests/test_section41_pre_execution_plan_disposition_recovery.py tests/test_section41_private_atomic_pre_execution_plan_disposition.py tests/test_section41_private_pre_execution_plan_disposition_delegation.py tests/test_rw0_c1_mutation_contracts.py tests/test_rw0_c1_private_atomic_persistence.py tests/test_rw0_c1_private_readers.py tests/test_rw0_c1_reader_contracts.py tests/test_rw0_c1_recovery.py tests/test_rw0_c1_row_values.py tests/test_rw0_c1_semantic_values.py tests/test_rw0_c1_writer_session_delegation.py tests/test_remote_worker_pre_execution_planning_contract.py::test_f1_post_execution_common_proposal_needs_no_preexecution_context_row tests/test_remote_worker_pre_execution_planning_contract.py::test_s41_post_execution_evidence_is_exactly_zero_or_complete tests/test_remote_worker_pre_execution_planning_contract.py::test_s41_post_execution_evidence_rejects_every_noncanonical_member tests/test_remote_worker_pre_execution_planning_contract.py::test_repaired_nine_table_ddl_and_both_golden_families_are_representable tests/test_remote_worker_pre_execution_planning_contract.py::test_migration_0003_owner_freezes_exact_representability_without_0002_rebuild
```

Result: `300 passed in 241.64s`.

### V05

```text
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_sqlite_b1_migrations.py tests/test_sqlite_c2b1_migration_framework.py tests/test_sqlite_c2b2_migration_0002.py tests/test_sqlite_section41_migration_0003.py tests/test_sqlite_rw0_c1_migration_0004.py tests/test_autonomous_software_development_operating_model.py tests/test_architecture_contracts.py tests/test_rw0_remote_contact_phase_entry_contract.py tests/test_software_development_progression_boundary.py tests/test_rw0_b2_wire_boundaries.py tests/test_rw0_b2_capability_boundaries.py
```

Result: `529 passed in 20.84s`.

### V06

```text
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q
```

Result: `6184 passed, 3 warnings in 1537.94s (0:25:37)`.

The three warnings were Python 3.13 fork deprecation warnings in existing B2c writer-session tests; they were non-failing and unrelated to the V4 test-only change.

Post-test `git diff --check` passed with no output. Status remained exactly 10 tracked modifications plus 10 untracked files, zero staged and zero unmerged paths. The scan found no cache directory, bytecode, pytest cache, database/journal/WAL/SHM, lock, build/dist/egg-info, archive, OS metadata, symlink, executable, or unsupported type outside `.git`. Every overlaid candidate file remained exact. Two post-test recipe runs were byte-identical to each other and to the saved V4 manifest. The temporary validation root was then removed; no live repository cache was touched by formal validation.

## 8. Final V4 provenance

Final live-repository checks reproduced:

- exactly 20 candidate paths;
- 10 tracked modifications and 10 untracked regular files;
- all mode `0644`;
- zero staged and zero unmerged paths;
- exactly one V3-to-V4 changed path: `tests/test_post_execution_pure_owner_vectors.py`;
- the other 19 candidate paths byte-identical to V3;
- no path outside the 20-path candidate differing from HEAD;
- tracked textual-diff SHA-256 unchanged at `897e95f470b55690abb2c25bd2b1d0b760ad9e6b0b3541f4ad4f5012cd0f022f`;
- two final serial live recipe runs byte-identical to the saved V4 manifest;
- final live ignored cache byte-identical to opening evidence: one root, 37 exact members, aggregate `dbaa5d1ff000e2c00e9b64d5b1e591ac8374e1b9bd9f3a6c5c0c17b3742c8f90`.

The canonical V4 provenance manifest is the exact recipe output: 4,377 bytes, one logical line, final LF present, mode `0644`, SHA-256 `30beb0acef46bb78eab79629dffadcb6ef40de41fa9fe7e828e30ec76626f3eb`.

### Exact final candidate inventory

| Path | Kind | Mode | Bytes | SHA-256 |
| --- | --- | --- | ---: | --- |
| `.docs/architecture.md` | tracked_modified | `0644` | 41,677 | `43781644500ee7c6f9a104cc8674f18c3fd0de1dd6d078aaee478bea42ee1042` |
| `.docs/autonomous-software-development-operating-model.md` | tracked_modified | `0644` | 36,742 | `fa0248a56cb7c68226c28e318dfa4fcbaabcce04f3c539e90b88a5393e41ee51` |
| `.docs/c2a1-pure-semantic-values.md` | tracked_modified | `0644` | 17,603 | `6912f254da3a1bed17058dfed24710c58ffafdc8c61f663d38435fe30acd2729` |
| `.docs/c2b-durable-development-state.md` | tracked_modified | `0644` | 1,885,990 | `51df62dfd5b2477860be137d4e045f4379058e69ef3106781dcc03ff5c160c14` |
| `.docs/rw0-b1-pure-phase-values.md` | tracked_modified | `0644` | 31,818 | `7dbe48979693919cb040f7848026d7759641d4d9b1e2bba340ad0ff2972d140a` |
| `.docs/rw0-c1-durable-evidence.md` | tracked_modified | `0644` | 13,727 | `2548de75a2050f0989e03e44c167117c2748becffa0af52414c08e5926b856cc` |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | tracked_modified | `0644` | 55,046 | `95b921669b21f478f23b9b855094e7a16a8c5a86b778b80781f2be380cd4ab23` |
| `src/ge_nwp_coordinator/_finite_backlog_risk_source_adapter.py` | untracked | `0644` | 8,319 | `781990f5f8c43d548784f205ac4a64dd03c9613ec70d23d70a8f0c53a8025472` |
| `src/ge_nwp_coordinator/_post_execution_evidence_values.py` | untracked | `0644` | 324,147 | `a736fb6c0f5e8377cafe685d4bfaf6c992e5de50570880299b0592e36be84c22` |
| `src/ge_nwp_coordinator/_post_execution_policy_values.py` | untracked | `0644` | 73,389 | `d2eda86e5702ffe971e4ca4a3cbc8332e18c72afe941e1c353255cb47513f018` |
| `src/ge_nwp_coordinator/_rw0_c_decision_input_values.py` | untracked | `0644` | 99,862 | `cc4d3043450988512c00e4d062a16461dee1f574328b5ca4b8c4832fe4b19f7f` |
| `src/ge_nwp_coordinator/_section41_post_execution_proposal_family_projection.py` | untracked | `0644` | 41,142 | `8cc8f0650d69536224deda38a104b676b2407bc7aee3caac1a6fcdd335bc2659` |
| `src/ge_nwp_coordinator/_section41_post_execution_role_resolution.py` | untracked | `0644` | 26,118 | `397971b478a3714eb87abdee02af10fe3cfc2fec76eed0db2c49f720ed3f46c0` |
| `tests/test_c2a_nonimplementation.py` | tracked_modified | `0644` | 29,494 | `c023e01ebf3518b3eb5ecc26260a2a4dc7f6304362b5822c0dfb01652a9d679b` |
| `tests/test_post_execution_pure_owner_boundaries.py` | untracked | `0644` | 17,442 | `99f942f8306f5559f8fbf69055e45db0494c3109d7e6b395d8cd21c777933da4` |
| `tests/test_post_execution_pure_owner_relations.py` | untracked | `0644` | 79,722 | `d7df4277069d60f38a06c9cd35517f01a26b6d487bcf8a3899cd47545beffa0d` |
| `tests/test_post_execution_pure_owner_values.py` | untracked | `0644` | 519,239 | `8539edc46783a3a53e38bcdac640406c7e63aa431028916e68d1119a1beaf0d1` |
| `tests/test_post_execution_pure_owner_vectors.py` | untracked | `0644` | 97,266 | `3a2941defa76d73c4675aab7a16d78b65cc4f1a764bff333dbd38d127f116fc8` |
| `tests/test_runtime_non_authority.py` | tracked_modified | `0644` | 46,396 | `1a9a271304cdcf64193b2c8fe59d26c15ebda371c38cb9c36f31df6b71a7e8b5` |
| `tests/test_rw0_b1_boundaries.py` | tracked_modified | `0644` | 36,260 | `594fd38b8134056042015dbaa5caddecdc3619810fc2123a7d4e53ae38043933` |

## 9. Assumptions and observation limits

- The fixed V11 package and accepted audit remain proposed-contract authority at their verified hashes; they were not regenerated or altered.
- Git divergence used only the existing local `origin/trunk_dev` remote-tracking ref. No fetch or network operation occurred.
- The exact private production exception reason is reported separately from the accepted V11 high-level `basis_conflict` classification; no per-record reason lookup is used by the repaired helper.
- The report preserves V3 as historical blocked evidence and supersedes only its false paging-causality claim.
- No required observation was skipped or unavailable. No independent re-audit was performed; a fresh independent reviewer must evaluate the V4 candidate.
- The report cannot embed its own final byte length and SHA-256 without recursive instability. The client closeout reports its final external receipt after this file is complete.

## 10. Required non-actions

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
MIGRATION_0005_NOT_CREATED
SQLITE_RUNTIME_NOT_WIDENED
PUBLIC_EXPORT_NOT_CREATED
PRODUCTION_CALLER_NOT_CREATED
DURABLE_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
SUBAGENTS_NOT_SPAWNED
```

## 11. Handoff posture

The V4 candidate is repaired, validated, provenance-bound, and ready for a fresh independent read-only re-audit. It is not independently accepted, staged, committed, pushed, or PR-ready by this report alone.
