# RW0 Post-Execution Pure-Owner Implementation Repair V3 Report

Date: 2026-10-05 (America/New_York)

Engagement: workspace-write repair; parent-only repository writer; no independent audit.

## 1. Primary verdict

The V2 candidate was correctly blocked by the fresh independent re-audit. The five reported findings were repaired within the frozen six-module, private, pure, no-I/O, migration-free architecture and the exact twenty-path ceiling. The final V3 candidate passed the prescribed focused tests and the complete V02-V06 external-clone validation sequence. This verdict means only that the repaired implementation is provenance-bound and ready for a new independent read-only audit; it is not commit or runtime authorization.

`RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIRED_V3_VALIDATED_PROVENANCE_READY_FOR_REAUDIT`

## 2. Fixed inputs and exact V2 starting provenance

The three direct repair inputs were received and verified before repository edits:

| Input | Bytes | Logical lines | Final LF | SHA-256 | Posture |
|---|---:|---:|---|---|---|
| `RW0_Post_Execution_Pure_Owner_Implementation_V2_Independent_Reaudit_Report.md` | 28,054 | 497 | absent | `665d1644070b290a7818660bab21608aeae3a09b7b13df9a1fde93a567931120` | blocking audit evidence; verdict BLOCK |
| `RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V2.json` | 4,377 | 1 | present | `7ada36bd287de85823926090e07e8e33ca1fe038963984c8eed0f423329f1284` | canonical compact sorted-key JSON |
| `RW0_Post_Execution_Pure_Owner_Implementation_Report_V2.md` | 21,217 | 427 | present | `ace2c92c66eea311820702cf844a8f802a8a78c82c4c208e37bc42133094e878` | historical blocked-candidate report only |

The previously supplied governing inputs were also verified at their fixed bytes: original implementation prompt `2ff652b1aabb65bdb9507a6d6954c139b799f4520591ecc0726b29e5d2888650`; V2 repair prompt `394018c64671b4aeaef6e7b5b5feb9c7e9ee8c4d08425046304eb40cba12b3b0`; boundary freeze `02b932abdfdb0085886000c19cdbcc4e9e72ebb951a5030056a621e181d33d55`; boundary manifest `927646d30430d5b6b3acacdc2f4b752721c3ed7ae62673962542120cfce0c386`; review overlay `ba8202629aebd895c7a4bae7ad147a2d68e9d368e27ede80a965b46809b32f92`; accepted V11 JSONL `e26a739dc303a555aa951e23ccd84b3583377319a82b5fcd78f99397da894afe`; accepted V11 audit `b5b3c1e9a426a6ce25c5a5bbb622d4a4838459750ebbe457fb9e6f9816f82548`; V2 opening evidence `adbe22edebc6e8e7beac735ad36cf1a9fb8535ba1c9312e8534f645ca87ec786`; and provenance recipe `db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc` (3,945 bytes, 166 logical lines, final LF present).

The pre-edit repository gate was exact: repository `/Users/ds/Repositories/Governed Execution Coordinator`; branch `trunk_dev`; HEAD `a3ff0b7f4f0c2378c2962e24612d605489b51638`; tree `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0`; sole parent `047563de5a443b0f8323401c92979ae2e444d2ed`; subject `feat: implement RW0-C1 durable evidence (#7)`; upstream `origin/trunk_dev`; divergence `0/0`; one worktree; zero staged paths; zero unmerged paths. The prescribed recipe ran twice serially and both canonical outputs were byte-identical to the V2 manifest: 20 files and tracked textual diff SHA-256 `897e95f470b55690abb2c25bd2b1d0b760ad9e6b0b3541f4ad4f5012cd0f022f`.

## 3. V3 opening evidence

`RW0_Post_Execution_Pure_Owner_Implementation_Repair_Opening_Evidence_V3.json` is canonical compact sorted-key JSON with final LF, 9,738 bytes, one logical line, and SHA-256 `f53fe00b945683270d56b0ee329d98e5c6ad9ec92dd669e47f555d6174108374`. It binds the V2 manifest and recipe, repository identity, zero staged/unmerged posture, and the safe repository-relative 37-member ignored bytecode inventory. Its cache aggregate is `dbaa5d1ff000e2c00e9b64d5b1e591ac8374e1b9bd9f3a6c5c0c17b3742c8f90`. It is evidence only and confers no authority.

## 4. Finding dispositions

| Finding | Severity | V3 disposition |
|---|---|---|
| `RW0-AUD-V2-001` | High | CLOSED in candidate: V22 now reconstructs and binds all 12 locator/row pairs, all cross-row owner equalities, the evidence-set identity, common evidence time, 12 operands, semantic relation, relation set, admission graph, membership, and chronology before projection identity. The fully resealed source/proposal model-contract mismatch makes the protected current matcher return false and V22 reject with `relation_mismatch`. |
| `RW0-AUD-V2-002` | High | CLOSED in candidate: all opening 52 metadata-dispatched malformed controls now mutate real owner, constructor, action, paging, AST/source/path inventory, equality, or preserved-seam representations. No malformed semantic control receives credit from a test-authored self-raise or a hard-coded metadata reason generator. All 93 execute causally. |
| `RW0-AUD-V2-003` | Medium | CLOSED in candidate: V03/V11 enforce the complete nine-role direct-C1/profile/binding/support branch grammar, and V11 validates carried canonical owners plus exact refs/digests. A 153-case exhaustive role/dimension matrix and the three mandatory hostile probes are permanent. |
| `RW0-AUD-V2-004` | Medium | CLOSED in candidate: V24 grammar and action require exactly `rw0-c-proposal-evidence-currentness.v1` / `88b347a069c92a5804ba53dad4f39a9d7ba6a36413fa38812f81e964a8902e9b`. A fully resealed fabricated pair across all nine roles rejects with `invalid_profile_pair`. |
| `RW0-AUD-V2-005` | Medium | CLOSED in candidate: the seven status paragraphs are unchanged from V2, but their bounded implementation claim is now supported by the repaired implementation and tests. The V2 report remains unchanged historical evidence and is not relied upon as a V3 correctness claim. |

## 5. Exact final twenty-path inventory

There are exactly 20 candidate paths: 10 tracked modifications and 10 untracked regular files, all mode `0644`; zero extra, missing, renamed, deleted, staged, or unmerged paths.

| Path | Kind | Bytes | SHA-256 |
|---|---|---:|---|
| `.docs/architecture.md` | `tracked_modified` | 41,677 | `43781644500ee7c6f9a104cc8674f18c3fd0de1dd6d078aaee478bea42ee1042` |
| `.docs/autonomous-software-development-operating-model.md` | `tracked_modified` | 36,742 | `fa0248a56cb7c68226c28e318dfa4fcbaabcce04f3c539e90b88a5393e41ee51` |
| `.docs/c2a1-pure-semantic-values.md` | `tracked_modified` | 17,603 | `6912f254da3a1bed17058dfed24710c58ffafdc8c61f663d38435fe30acd2729` |
| `.docs/c2b-durable-development-state.md` | `tracked_modified` | 1,885,990 | `51df62dfd5b2477860be137d4e045f4379058e69ef3106781dcc03ff5c160c14` |
| `.docs/rw0-b1-pure-phase-values.md` | `tracked_modified` | 31,818 | `7dbe48979693919cb040f7848026d7759641d4d9b1e2bba340ad0ff2972d140a` |
| `.docs/rw0-c1-durable-evidence.md` | `tracked_modified` | 13,727 | `2548de75a2050f0989e03e44c167117c2748becffa0af52414c08e5926b856cc` |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | `tracked_modified` | 55,046 | `95b921669b21f478f23b9b855094e7a16a8c5a86b778b80781f2be380cd4ab23` |
| `src/ge_nwp_coordinator/_finite_backlog_risk_source_adapter.py` | `untracked` | 8,319 | `781990f5f8c43d548784f205ac4a64dd03c9613ec70d23d70a8f0c53a8025472` |
| `src/ge_nwp_coordinator/_post_execution_evidence_values.py` | `untracked` | 324,147 | `a736fb6c0f5e8377cafe685d4bfaf6c992e5de50570880299b0592e36be84c22` |
| `src/ge_nwp_coordinator/_post_execution_policy_values.py` | `untracked` | 73,389 | `d2eda86e5702ffe971e4ca4a3cbc8332e18c72afe941e1c353255cb47513f018` |
| `src/ge_nwp_coordinator/_rw0_c_decision_input_values.py` | `untracked` | 99,862 | `cc4d3043450988512c00e4d062a16461dee1f574328b5ca4b8c4832fe4b19f7f` |
| `src/ge_nwp_coordinator/_section41_post_execution_proposal_family_projection.py` | `untracked` | 41,142 | `8cc8f0650d69536224deda38a104b676b2407bc7aee3caac1a6fcdd335bc2659` |
| `src/ge_nwp_coordinator/_section41_post_execution_role_resolution.py` | `untracked` | 26,118 | `397971b478a3714eb87abdee02af10fe3cfc2fec76eed0db2c49f720ed3f46c0` |
| `tests/test_c2a_nonimplementation.py` | `tracked_modified` | 29,494 | `c023e01ebf3518b3eb5ecc26260a2a4dc7f6304362b5822c0dfb01652a9d679b` |
| `tests/test_post_execution_pure_owner_boundaries.py` | `untracked` | 17,442 | `99f942f8306f5559f8fbf69055e45db0494c3109d7e6b395d8cd21c777933da4` |
| `tests/test_post_execution_pure_owner_relations.py` | `untracked` | 79,722 | `d7df4277069d60f38a06c9cd35517f01a26b6d487bcf8a3899cd47545beffa0d` |
| `tests/test_post_execution_pure_owner_values.py` | `untracked` | 519,239 | `8539edc46783a3a53e38bcdac640406c7e63aa431028916e68d1119a1beaf0d1` |
| `tests/test_post_execution_pure_owner_vectors.py` | `untracked` | 88,897 | `ead971979a09c0d2e3d1629668c0647b5beaaa5e3dad59f6948f0aa427af1ca8` |
| `tests/test_runtime_non_authority.py` | `tracked_modified` | 46,396 | `1a9a271304cdcf64193b2c8fe59d26c15ebda371c38cb9c36f31df6b71a7e8b5` |
| `tests/test_rw0_b1_boundaries.py` | `tracked_modified` | 36,260 | `594fd38b8134056042015dbaa5caddecdc3619810fc2123a7d4e53ae38043933` |

## 6. V2-to-V3 byte disposition

Only five of the twenty candidate files changed from V2 to V3. Fifteen remained byte-identical, including all seven authorized documents. The tracked textual diff digest stayed unchanged because all V3 repair edits were confined to previously untracked source/test files.

| Path | V2 bytes / SHA-256 | V3 bytes / SHA-256 | Disposition |
|---|---|---|---|
| `.docs/architecture.md` | 41,677 / `43781644500ee7c6f9a104cc8674f18c3fd0de1dd6d078aaee478bea42ee1042` | 41,677 / `43781644500ee7c6f9a104cc8674f18c3fd0de1dd6d078aaee478bea42ee1042` | byte-identical |
| `.docs/autonomous-software-development-operating-model.md` | 36,742 / `fa0248a56cb7c68226c28e318dfa4fcbaabcce04f3c539e90b88a5393e41ee51` | 36,742 / `fa0248a56cb7c68226c28e318dfa4fcbaabcce04f3c539e90b88a5393e41ee51` | byte-identical |
| `.docs/c2a1-pure-semantic-values.md` | 17,603 / `6912f254da3a1bed17058dfed24710c58ffafdc8c61f663d38435fe30acd2729` | 17,603 / `6912f254da3a1bed17058dfed24710c58ffafdc8c61f663d38435fe30acd2729` | byte-identical |
| `.docs/c2b-durable-development-state.md` | 1,885,990 / `51df62dfd5b2477860be137d4e045f4379058e69ef3106781dcc03ff5c160c14` | 1,885,990 / `51df62dfd5b2477860be137d4e045f4379058e69ef3106781dcc03ff5c160c14` | byte-identical |
| `.docs/rw0-b1-pure-phase-values.md` | 31,818 / `7dbe48979693919cb040f7848026d7759641d4d9b1e2bba340ad0ff2972d140a` | 31,818 / `7dbe48979693919cb040f7848026d7759641d4d9b1e2bba340ad0ff2972d140a` | byte-identical |
| `.docs/rw0-c1-durable-evidence.md` | 13,727 / `2548de75a2050f0989e03e44c167117c2748becffa0af52414c08e5926b856cc` | 13,727 / `2548de75a2050f0989e03e44c167117c2748becffa0af52414c08e5926b856cc` | byte-identical |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | 55,046 / `95b921669b21f478f23b9b855094e7a16a8c5a86b778b80781f2be380cd4ab23` | 55,046 / `95b921669b21f478f23b9b855094e7a16a8c5a86b778b80781f2be380cd4ab23` | byte-identical |
| `src/ge_nwp_coordinator/_finite_backlog_risk_source_adapter.py` | 8,319 / `781990f5f8c43d548784f205ac4a64dd03c9613ec70d23d70a8f0c53a8025472` | 8,319 / `781990f5f8c43d548784f205ac4a64dd03c9613ec70d23d70a8f0c53a8025472` | byte-identical |
| `src/ge_nwp_coordinator/_post_execution_evidence_values.py` | 304,190 / `6e8ca36e49b3a8ede008216ce9cdd6b6c5a3a198b7f8a20b52c9dd7848d6a9ad` | 324,147 / `a736fb6c0f5e8377cafe685d4bfaf6c992e5de50570880299b0592e36be84c22` | CHANGED |
| `src/ge_nwp_coordinator/_post_execution_policy_values.py` | 73,389 / `d2eda86e5702ffe971e4ca4a3cbc8332e18c72afe941e1c353255cb47513f018` | 73,389 / `d2eda86e5702ffe971e4ca4a3cbc8332e18c72afe941e1c353255cb47513f018` | byte-identical |
| `src/ge_nwp_coordinator/_rw0_c_decision_input_values.py` | 99,862 / `cc4d3043450988512c00e4d062a16461dee1f574328b5ca4b8c4832fe4b19f7f` | 99,862 / `cc4d3043450988512c00e4d062a16461dee1f574328b5ca4b8c4832fe4b19f7f` | byte-identical |
| `src/ge_nwp_coordinator/_section41_post_execution_proposal_family_projection.py` | 29,311 / `57d6199456d8dac2ba6282f40a95fdeb8513c92f08056ad7166b5c3df062920e` | 41,142 / `8cc8f0650d69536224deda38a104b676b2407bc7aee3caac1a6fcdd335bc2659` | CHANGED |
| `src/ge_nwp_coordinator/_section41_post_execution_role_resolution.py` | 25,590 / `bcae1e8154c304f977373ee1e2e3954481ca71935c2c7ff5f924a7e1ae3e4941` | 26,118 / `397971b478a3714eb87abdee02af10fe3cfc2fec76eed0db2c49f720ed3f46c0` | CHANGED |
| `tests/test_c2a_nonimplementation.py` | 29,494 / `c023e01ebf3518b3eb5ecc26260a2a4dc7f6304362b5822c0dfb01652a9d679b` | 29,494 / `c023e01ebf3518b3eb5ecc26260a2a4dc7f6304362b5822c0dfb01652a9d679b` | byte-identical |
| `tests/test_post_execution_pure_owner_boundaries.py` | 17,442 / `99f942f8306f5559f8fbf69055e45db0494c3109d7e6b395d8cd21c777933da4` | 17,442 / `99f942f8306f5559f8fbf69055e45db0494c3109d7e6b395d8cd21c777933da4` | byte-identical |
| `tests/test_post_execution_pure_owner_relations.py` | 63,469 / `c751333c612cf51a23a7cc6fb92443a45a1bbcc3b24ab0fab37b8b0e7e2f4a01` | 79,722 / `d7df4277069d60f38a06c9cd35517f01a26b6d487bcf8a3899cd47545beffa0d` | CHANGED |
| `tests/test_post_execution_pure_owner_values.py` | 519,239 / `8539edc46783a3a53e38bcdac640406c7e63aa431028916e68d1119a1beaf0d1` | 519,239 / `8539edc46783a3a53e38bcdac640406c7e63aa431028916e68d1119a1beaf0d1` | byte-identical |
| `tests/test_post_execution_pure_owner_vectors.py` | 61,554 / `eb414a5d3f1e9c1fde8286a040fde2e1b17ef0e34a544244548d82e365cd6a37` | 88,897 / `ead971979a09c0d2e3d1629668c0647b5beaaa5e3dad59f6948f0aa427af1ca8` | CHANGED |
| `tests/test_runtime_non_authority.py` | 46,396 / `1a9a271304cdcf64193b2c8fe59d26c15ebda371c38cb9c36f31df6b71a7e8b5` | 46,396 / `1a9a271304cdcf64193b2c8fe59d26c15ebda371c38cb9c36f31df6b71a7e8b5` | byte-identical |
| `tests/test_rw0_b1_boundaries.py` | 36,260 / `594fd38b8134056042015dbaa5caddecdc3619810fc2123a7d4e53ae38043933` | 36,260 / `594fd38b8134056042015dbaa5caddecdc3619810fc2123a7d4e53ae38043933` | byte-identical |

## 7. V03/V11 complete nine-role enforcement

The frozen V03 profile remains `post-execution-semantic-review-input.v2` / `d4693a9cd9beb9d58edf2e492176182b69b5ed2fa8da34419709e2392333e54e`; V11 remains `post-execution-evidence-supply.v2` / `59a4a741fb394767f341dc57c514bb3e022737196905c7bed1f05295376d3a02`.

The implementation now closes all nine ranks (5-13) over exact role, ordinal, typed schema, source posture, model-input posture, direct-C1 null/non-null branch, source-profile schema/pair branch, source-binding schema/owner branch, and V11 support count/presence branch. V11 additionally reconstructs the supplied typed owner, fixed or generated profile, source binding (rank-6 current relation; rank-7/8 worker observations; rank-9 policy attestation; rank-10 generated risk binding; rank-12 global stop; rank-13 effect fence), support set, and support values and then checks every dependent coordinate for exact equality.

Permanent results:

- V03 rank-5 well-formed non-null profile pair: rejected before parent identity with `invalid_profile_pair`.
- V03 rank-6 erased direct-C1 coordinates: rejected with `source_owner_mismatch`.
- V11 rank-6 distinct well-formed profile pair: rejected with `invalid_profile_pair`.
- Exhaustive matrix: 153 role/dimension cases across every role and every applicable branch; all rejected and restored to accepted positives.

## 8. V22 current-matcher equivalence

The exact V22 pair remains `section41-post-execution-proposal-family-projection.v2` / `76b0fdedd0fbbd3c6400be3f8e22eacdf585eb28280d12f38834d513b8cdb411`.

The accepted 12-row current owner family reconstructs and returns true through protected `_section41_owner_family_matches`; the independent V22 projection action accepts the corresponding candidate. V22 now independently recomputes the private-reader tuple equality, locator-to-row binding, source/artifact/proposal/evidence self-identities, all cross-row model/config/context/lineage/artifact/projection/evidence equalities, common nine-row `evidence_bound_at`, evidence-set digest, rank-15 wrapper, 12 exact owner operands, relation reference/digest/operand-set digest, relation-set digest, admission-graph digest, membership digest, and full chronology.

The hostile counterexample changes only the proposal model-contract pair, recomputes the proposal digest and every downstream locator, owner graph, rank-15 value, operand, relation, relation set, admission graph, membership, and V22 identity. The protected matcher returns false. V22 rejects before projection identity with `relation_mismatch`, the existing vocabulary selected for a cross-row equality failure. Restoring the pair recovers the exact accepted matcher and projection. The hostile case runs both in the ordinary relation suite and `V3_CAUSAL_ASSURANCE_ACTIONS` in the malformed/assurance registry.

## 9. V24 exact decision-currentness pair

The V24 pair remains `section41-post-execution-role-resolution.v3` / `008a8468c608d9db41fe28f19bc582cc9598f58c9b3009e2d79322fd6c22cebc`. Every one of the nine role relations must also carry exactly `rw0-c-proposal-evidence-currentness.v1` / `88b347a069c92a5804ba53dad4f39a9d7ba6a36413fa38812f81e964a8902e9b`, plus exact projection, context, role, typed owner, source profile/binding, direct-C1, evidence-row, and resupply coordinates.

The hostile family substitutes `rw0-c-proposal-evidence-currentness.fabricated` / 64 lowercase `f` characters in all nine roles and recomputes every affected relation ref/digest. V24 grammar and the complete-family action both reject before final relation acceptance with `invalid_profile_pair`. The restored family resolves all nine roles byte-exactly.

## 10. Complete malformed-control causality

The opening V2 implementation routed exactly these 52 malformed IDs through the synthetic metadata dispatcher:

1. `malformed.V3G001.host-module-substitution`
2. `malformed.V3G002.host-artifact-profile-field-substitution`
3. `malformed.V3G003.host-protocol-profile-field-substitution`
4. `malformed.V3G004.global-stop-owner-module-substitution`
5. `malformed.V3G005.global-stop-domain-digest-substitution`
6. `malformed.V3G006.evidence-set-owner-module-substitution`
7. `malformed.V3G007.validation-requirement-owner-module-substitution`
8. `malformed.V3G008.review-requirement-owner-module-substitution`
9. `malformed.V3G009.evidence-row-locator-substitution`
10. `malformed.V3G010.non-temporal-relation-timestamp`
11. `malformed.V3G011.temporal-relation-null-timestamp`
12. `malformed.V3G012.rank12-cascade-stale`
13. `malformed.V3G013.v40-nested-schema-id-absent`
14. `malformed.V3G014.v40-nested-field-reorder`
15. `malformed.V3G015.v40-nested-type-mismatch`
16. `malformed.V3G016.exact-resupply-absent`
17. `malformed.V3G017.exact-resupply-bytes-mismatch`
18. `malformed.V3G018.candidate-manifest-absent`
19. `malformed.V3G019.candidate-manifest-phase-substitution`
20. `malformed.V3G020.membership-page-duplicate`
21. `malformed.V3G021.membership-cursor-nonmonotonic`
22. `malformed.V3G022.membership-page-reordered`
23. `malformed.V3G023.membership-cursor-no-progress`
24. `malformed.V3G024.membership-overflow`
25. `malformed.V3G025.membership-premature-termination`
26. `malformed.V3G026.membership-continuation-substitution`
27. `malformed.V3G027.membership-capability-epoch-change`
28. `malformed.V3G028.snapshot-rank1-membership-substitution`
29. `malformed.V3G029.snapshot-rank15-membership-substitution`
30. `malformed.V3G030.snapshot-external-source-substitution`
31. `malformed.V3G031.snapshot-phase-k8-mismatch`
32. `malformed.V3G032.snapshot-required-row-missing`
33. `malformed.V3G033.snapshot-current-row-malformed`
34. `malformed.V3G034.snapshot-unrelated-state-invariance`
35. `malformed.V3G035.package-root-export-widening`
36. `malformed.V3G036.state-store-method-widening`
37. `malformed.V3G037.writer-session-method-widening`
38. `malformed.V3G038.migration-sql-widening`
39. `malformed.V3G039.production-caller-widening`
40. `malformed.V3G040.direct-sqlite-authority-widening`
41. `malformed.V3G041.io-authority-widening`
42. `malformed.V3G042.reserved-v35-v37-import`
43. `malformed.V3G043.forecast-reintroduced-current`
44. `malformed.V3G044.opaque-digest-recovery-completeness`
45. `malformed.V4I001.contradictory-duplicate-host-identity-field`
46. `malformed.V4I002.host-profile-substitution`
47. `malformed.V4I003.host-relation-name-substitution`
48. `malformed.V4I004.v26-entry-schema-id-omission`
49. `malformed.V5C001.variable-list-fixed-cardinality-reintroduction`
50. `malformed.V5C002.standing-policy-support-inventory-substitution`
51. `malformed.V5C003.currentness-risk-component-collapse`
52. `malformed.V5C004.snapshot-risk-source-collapse`

V3 removes `_metadata_first_failure`, prevents `_execute_metadata_mutation` from reading `expected_rejection`, and statically proves that `_FrozenVectorViolation` is raised only by the artifact parser's duplicate-key/nonfinite-number assurance helper, never by a malformed semantic execution path. The sole remaining test-authored rank-14 semantic raise was replaced by a concrete relation-spec equality checker. The result is 93/93 causal executions and zero synthetic self-raises receiving semantic credit.

### 93-row causality ledger

| # | Malformed record ID | Positive/base fixture | Exact causal mutation | Real function/checker invoked | Identity posture | Observed first class | Restoration |
|---:|---|---|---|---|---|---|---|
| 1 | malformed.V3G001.host-module-substitution | source-owner.host-qualification | replace /owner_module: "ge_nwp_coordinator._rw0_phase_entry_semantic_values" -> "ge_nwp_coordinator._rw0_semantic_values" | _source_owner_metadata_failure + current owner constructor | not applicable; owner/allocation equality | source_owner_module_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 2 | malformed.V3G002.host-artifact-profile-field-substitution | source-owner.host-qualification | replace /ordered_fields/required_worker_artifact_ref: "required_worker_artifact_ref" -> "required_worker_artifact_profile_ref" | _source_owner_metadata_failure + current owner constructor | not applicable; owner/allocation equality | unknown_field | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 3 | malformed.V3G003.host-protocol-profile-field-substitution | source-owner.host-qualification | replace /ordered_fields/required_worker_protocol_ref: "required_worker_protocol_ref" -> "required_worker_protocol_profile_ref" | _source_owner_metadata_failure + current owner constructor | not applicable; owner/allocation equality | unknown_field | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 4 | malformed.V3G004.global-stop-owner-module-substitution | source-owner.global-stop | replace /owner_module: "ge_nwp_coordinator.global_stop" -> "ge_nwp_coordinator.transition_contracts" | _source_owner_metadata_failure + current owner constructor | not applicable; owner/allocation equality | source_owner_module_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 5 | malformed.V3G005.global-stop-domain-digest-substitution | source-owner.global-stop | replace /identity_and_digest/digest_posture: "raw_sha256_of_canonical_owner_mapping" -> "domain_separated_identity" | _source_owner_metadata_failure + current owner constructor | not applicable; owner/allocation equality | digest_posture_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 6 | malformed.V3G006.evidence-set-owner-module-substitution | source-owner.migration0003-evidence-set | replace /owner_module: "ge_nwp_coordinator._sqlite_rw0_c1" -> "ge_nwp_coordinator._cognitive_proposal_semantic_values" | _source_owner_metadata_failure + current owner constructor | not applicable; owner/allocation equality | source_owner_module_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 7 | malformed.V3G007.validation-requirement-owner-module-substitution | source-owner.validation-requirement | replace /owner_module: "ge_nwp_coordinator._development_author_effect_establishment_contracts" -> "ge_nwp_coordinator._development_row_values" | _source_owner_metadata_failure + current owner constructor | not applicable; owner/allocation equality | source_owner_module_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 8 | malformed.V3G008.review-requirement-owner-module-substitution | source-owner.review-requirement | replace /owner_module: "ge_nwp_coordinator._development_author_effect_establishment_contracts" -> "ge_nwp_coordinator._development_row_values" | _source_owner_metadata_failure + current owner constructor | not applicable; owner/allocation equality | source_owner_module_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 9 | malformed.V3G009.evidence-row-locator-substitution | source-owner.migration0003-evidence-row | replace /identity_and_digest/locator_fields: ["proposal_ref","evidence_role","ordinal"] -> ["evidence_ref"] | _source_owner_metadata_failure + current owner constructor | not applicable; owner/allocation equality | row_locator_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 10 | malformed.V3G010.non-temporal-relation-timestamp | golden.owner.author-rank12.000.relation | replace /evaluated_at: null -> "2026-09-30T11:59:47Z" | rw0_c1_row_value_from_tuple(rw0_relation_bindings) | intentionally stale where structural precedence requires; no unrelated reseal | relation_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 11 | malformed.V3G011.temporal-relation-null-timestamp | source-owner.rank12-review-relation | replace /temporal_control/evaluated_at: "owner_operation_timestamp" -> null | evaluate_post_execution_reviewer_separation | intentionally stale where structural precedence requires; no unrelated reseal | relation_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 12 | malformed.V3G012.rank12-cascade-stale | golden.owner.author-rank12.000.membership | replace /relation_set_digest: "recomputed_current_relation_set_digest" -> "3e5939d365d889413e1200b31674c55e32edf97b9f2467a914c5e271d29967f2" | rw0_c1_row_value_from_tuple(rw0_evidence_memberships) | intentionally stale where structural precedence requires; no unrelated reseal | cascade_identity_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 13 | malformed.V3G013.v40-nested-schema-id-absent | behavior-profile.post-execution-reviewer-separation-evaluation.v1 | remove /nested_values/PostExecutionReviewerSeparationAuthorObservationLocatorV1/fields/0: "schema_id_field_declaration" -> "field_absent" | PostExecutionReviewerSeparationEvaluationV1.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | nested_contract_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 14 | malformed.V3G014.v40-nested-field-reorder | behavior-profile.post-execution-reviewer-separation-evaluation.v1 | replace /nested_values/PostExecutionReviewerSeparationAuthorObservationLocatorV1/fields/order: "schema_id_then_ordinal" -> "ordinal_then_schema_id" | PostExecutionReviewerSeparationEvaluationV1.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | nested_contract_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 15 | malformed.V3G015.v40-nested-type-mismatch | behavior-profile.post-execution-reviewer-separation-evaluation.v1 | replace /nested_values/PostExecutionReviewerSeparationAuthorObservationLocatorV1/fields/1/type: "exact_builtin_int" -> "exact_builtin_str" | PostExecutionReviewerSeparationEvaluationV1.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | nested_contract_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 16 | malformed.V3G016.exact-resupply-absent | behavior-profile.section41-post-execution-role-resolution.v3 | replace /resupply/exact_present: true -> false | section41_post_execution_role_resolution | not applicable; parent/context equality check | no_decision | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 17 | malformed.V3G017.exact-resupply-bytes-mismatch | golden.V10.full-evidence-supply | replace /canonical_bytes_sha256: "exact_supply_bytes_sha256" -> "substituted_supply_bytes_sha256" | validate_post_execution_evidence_supply | regenerated only for affected V10/V07 parent identity | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 18 | malformed.V3G018.candidate-manifest-absent | golden.V07.primary | replace /entries/0: "exact_candidate_manifest_entry" -> null | PostExecutionPrivateInputManifestV2.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | no_decision | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 19 | malformed.V3G019.candidate-manifest-phase-substitution | golden.V07.primary | replace /proposal_phase: "post_execution_semantic_review" -> "pre_execution_planning" | validate_post_execution_model_input_binding | regenerated only for affected V10/V07 parent identity | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 20 | malformed.V3G020.membership-page-duplicate | behavior-profile.rw0-c-decision-membership-closure.v1 | replace /paging/duplicate_entry: false -> true | rw0_c_decision_membership_closure | not applicable; transcript mutated, V25 expectation unchanged | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 21 | malformed.V3G021.membership-cursor-nonmonotonic | behavior-profile.rw0-c-decision-membership-closure.v1 | replace /paging/next_cursor: "strictly_greater" -> "less_than_previous" | rw0_c_decision_membership_closure | not applicable; transcript mutated, V25 expectation unchanged | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 22 | malformed.V3G022.membership-page-reordered | behavior-profile.rw0-c-decision-membership-closure.v1 | replace /paging/page_order: "ascending" -> "reversed" | rw0_c_decision_membership_closure | not applicable; transcript mutated, V25 expectation unchanged | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 23 | malformed.V3G023.membership-cursor-no-progress | behavior-profile.rw0-c-decision-membership-closure.v1 | replace /paging/next_cursor: "advanced_cursor" -> "same_cursor" | rw0_c_decision_membership_closure | not applicable; transcript mutated, V25 expectation unchanged | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 24 | malformed.V3G024.membership-overflow | behavior-profile.rw0-c-decision-membership-closure.v1 | replace /paging/observed_entry_count: 65536 -> 65537 | rw0_c_decision_membership_closure | not applicable; transcript mutated, V25 expectation unchanged | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 25 | malformed.V3G025.membership-premature-termination | behavior-profile.rw0-c-decision-membership-closure.v1 | replace /paging/terminated: false -> true | rw0_c_decision_membership_closure | not applicable; transcript mutated, V25 expectation unchanged | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 26 | malformed.V3G026.membership-continuation-substitution | behavior-profile.rw0-c-decision-membership-closure.v1 | replace /paging/continuation_cursor: "prior_returned_cursor" -> "foreign_cursor" | rw0_c_decision_membership_closure | not applicable; transcript mutated, V25 expectation unchanged | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 27 | malformed.V3G027.membership-capability-epoch-change | behavior-profile.rw0-c-decision-membership-closure.v1 | replace /paging/capability_epoch: "initial_epoch" -> "replacement_epoch" | rw0_c_decision_membership_closure | not applicable; transcript mutated, V25 expectation unchanged | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 28 | malformed.V3G028.snapshot-rank1-membership-substitution | golden.V27.primary | replace /selected_authority_membership_ref: "c1-authority-membership-golden.0001" -> "foreign-rank1-membership.0001" | rw0_c_decision_current_snapshot | regenerated V27 ref/digest; semantic predicate remains first | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 29 | malformed.V3G029.snapshot-rank15-membership-substitution | golden.V27.primary | replace /selected_section41_membership_ref: "c1-section41-membership-golden.0001" -> "foreign-rank15-membership.0001" | rw0_c_decision_current_snapshot | regenerated V27 ref/digest; semantic predicate remains first | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 30 | malformed.V3G030.snapshot-external-source-substitution | golden.V27.primary | replace /external_current_sources/0/source_digest: "current_source_digest" -> "foreign_source_digest" | rw0_c_decision_current_snapshot | regenerated V27 ref/digest; semantic predicate remains first | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 31 | malformed.V3G031.snapshot-phase-k8-mismatch | golden.V27.primary | replace /phase_basis_digest: "2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a" -> "2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b" | rw0_c_decision_current_snapshot | regenerated V27 ref/digest; semantic predicate remains first | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 32 | malformed.V3G032.snapshot-required-row-missing | golden.V27.primary | replace /work_item_revision_ref: "work-item-revision-golden.0001" -> null | rw0_c_decision_current_snapshot | intentionally stale where structural precedence requires; no unrelated reseal | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 33 | malformed.V3G033.snapshot-current-row-malformed | golden.V27.primary | replace /attempt_fence_digest: "0c16e39a65d024b6e021ae98fb0eee8202d6c47bfaf67bd08be1c8c49d1e2343" -> "0d16e39a65d024b6e021ae98fb0eee8202d6c47bfaf67bd08be1c8c49d1e2343" | rw0_c_decision_current_snapshot | regenerated V27 ref/digest; semantic predicate remains first | basis_conflict | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 34 | malformed.V3G034.snapshot-unrelated-state-invariance | behavior-profile.rw0-c-decision-current-snapshot.v1 | replace /audit_fixture/unrelated_extra_row_present: false -> true | rw0_c_decision_current_snapshot | not applicable; unrelated state only | bounded_snapshot_unchanged | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 35 | malformed.V3G035.package-root-export-widening | module-allocation.V40 | replace /package_root_export: false -> true | package-root AST export boundary checker | not applicable; concrete boundary inventory | implementation_boundary_violation | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 36 | malformed.V3G036.state-store-method-widening | remaining-seam.S001 | replace /public_state_store_method: false -> true | StateStore/WriterSession AST method boundary checker | not applicable; concrete boundary inventory | implementation_boundary_violation | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 37 | malformed.V3G037.writer-session-method-widening | remaining-seam.S001 | replace /public_writer_session_method: false -> true | StateStore/WriterSession AST method boundary checker | not applicable; concrete boundary inventory | implementation_boundary_violation | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 38 | malformed.V3G038.migration-sql-widening | remaining-seam.S001 | replace /migration_or_sql_resource_added: false -> true | migration path-inventory boundary checker | not applicable; concrete boundary inventory | implementation_boundary_violation | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 39 | malformed.V3G039.production-caller-widening | import-edge.current-production-runtime.post-execution-evidence-values-py | replace /allowed: false -> true | production import-edge AST boundary checker | not applicable; concrete boundary inventory | implementation_boundary_violation | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 40 | malformed.V3G040.direct-sqlite-authority-widening | module-allocation.V40 | replace /direct_sqlite_connection_authority: false -> true | semantic-module import/authority AST boundary checker | not applicable; concrete boundary inventory | implementation_boundary_violation | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 41 | malformed.V3G041.io-authority-widening | value-schema.V40.postexecutionreviewerseparationevaluationv1 | replace /local_semantic_action: "pure validation/reconstruction/evaluation only; no I/O or durable authority" -> "filesystem_read" | semantic-module import/authority AST boundary checker | not applicable; concrete boundary inventory | implementation_boundary_violation | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 42 | malformed.V3G042.reserved-v35-v37-import | remaining-seam.S002 | replace /current_imports/V35-V37: false -> true | runtime V-number allocation boundary checker | not applicable; concrete boundary inventory | future_owner_not_frozen | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 43 | malformed.V3G043.forecast-reintroduced-current | remaining-seam.S002 | replace /current_normative_v35_v37: false -> true | runtime V-number allocation boundary checker | not applicable; concrete boundary inventory | future_owner_not_frozen | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 44 | malformed.V3G044.opaque-digest-recovery-completeness | remaining-seam.S002 | replace /insufficiency_rule: "opaque_aggregate_digests_alone_are_insufficient" -> "opaque_digest_only_is_complete" | future-recovery retained-value seam checker | not applicable; concrete boundary inventory | future_recovery_incomplete | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 45 | malformed.attempt-fence-expiry-substitution | V33 | snapshot evaluation after attempt expiry | evaluate_rw0_c_decision_time_source_effect_ceiling_branches | regenerated in frozen hostile payload | expired_fence_denial | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 46 | malformed.candidate-git-sha256 | V04 | base_git_object_format widened | V04.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | current_sha1_domain_rejection | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 47 | malformed.candidate-git-wrong-oid-width | V04 | base_git_oid widened | V04.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | current_40_hex_oid_rejection | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 48 | malformed.effect-fence-expiry-substitution | V21 | effect fence expiry substituted | evaluate_post_execution_source_effect_ceiling | regenerated in frozen hostile payload | expired_effect_fence_denial | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 49 | malformed.finite-backlog-adapter-substitution | V19 | generic source profile substituted by adapter schema | finite_backlog_risk_source_projection | intentionally stale where structural precedence requires; no unrelated reseal | adapter_generic_interface_mismatch | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 50 | malformed.global-stop-branch-mismatch | golden.V32.active-stop | candidate_acceptance governed result deny -> permit with matrix ref and digest recomputed | evaluate_rw0_c_decision_time_global_stop_branches | regenerated in frozen hostile payload | stop_branch_matrix_conflict | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 51 | malformed.policy-source-substitution | V17 | policy source digest substituted | validate_post_execution_standing_policy_matrix_relation | intentionally stale where structural precedence requires; no unrelated reseal | policy_source_identity_mismatch | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 52 | malformed.profile-value-mismatch | V15 | profile digest substituted | V15.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | profile_value_mismatch | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 53 | malformed.requirement-embedded-digest-substitution | V38 | safe_evidence_digest replaced with requirement_digest | V38.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | requirement_safe_identity_mismatch | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 54 | malformed.review-observation-kind | WorkerObservationV1 | current C2A matrix substitution | WorkerObservationV1.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | current_observation_matrix_rejection | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 55 | malformed.review-source-kind | WorkerObservationV1 | current C2A matrix substitution | WorkerObservationV1.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | current_observation_matrix_rejection | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 56 | malformed.review-source-outcome | WorkerObservationV1 | current C2A matrix substitution | WorkerObservationV1.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | current_observation_matrix_rejection | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 57 | malformed.risk-source-substitution | V18 | risk binding digest substituted | validate_post_execution_risk_lane_matrix_relation | intentionally stale where structural precedence requires; no unrelated reseal | risk_source_identity_mismatch | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 58 | malformed.stale-superseded-identity | V40 | old V40 schema/ref/digest supplied | evaluate_post_execution_reviewer_separation | intentionally stale where structural precedence requires; no unrelated reseal | stale_superseded_identity | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 59 | malformed.unsupported-identity-authentication-claim | V40 | unsupported human/provider/account field added | evaluate_post_execution_reviewer_separation | intentionally stale where structural precedence requires; no unrelated reseal | unknown_field_and_unsupported_claim | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 60 | malformed.v40-author-evidence-absent | V40 | operational-separation substitution | evaluate_post_execution_reviewer_separation | regenerated in frozen hostile payload | unknown/author_source_evidence_absent | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 61 | malformed.v40-author-invocation-conflict | V40 | operational-separation substitution | evaluate_post_execution_reviewer_separation | regenerated in frozen hostile payload | conflict/author_source_evidence_conflict | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 62 | malformed.v40-candidate-lineage | V40 | operational-separation substitution | evaluate_post_execution_reviewer_separation | regenerated in frozen hostile payload | conflict/cross_lineage_conflict | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 63 | malformed.v40-capsule-lineage | V40 | operational-separation substitution | evaluate_post_execution_reviewer_separation | regenerated in frozen hostile payload | conflict/cross_lineage_conflict | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 64 | malformed.v40-delivery-reuse | V40 | operational-separation substitution | evaluate_post_execution_reviewer_separation | regenerated in frozen hostile payload | not_separate/review_delivery_identity_reused | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 65 | malformed.v40-effect-reuse | V40 | operational-separation substitution | evaluate_post_execution_reviewer_separation | regenerated in frozen hostile payload | not_separate/review_effect_identity_reused | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 66 | malformed.v40-invocation-reuse | V40 | operational-separation substitution | evaluate_post_execution_reviewer_separation | regenerated in frozen hostile payload | not_separate/review_source_invocation_reused | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 67 | malformed.v40-phase-lineage | V40 | operational-separation substitution | evaluate_post_execution_reviewer_separation | regenerated in frozen hostile payload | conflict/same_phase_closure_conflict | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 68 | malformed.v40-wrong-review-role | V40 | operational-separation substitution | evaluate_post_execution_reviewer_separation | regenerated in frozen hostile payload | conflict/source_role_conflict | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 69 | malformed.validation-observation-kind | WorkerObservationV1 | current C2A matrix substitution | WorkerObservationV1.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | current_observation_matrix_rejection | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 70 | malformed.validation-source-kind | WorkerObservationV1 | current C2A matrix substitution | WorkerObservationV1.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | current_observation_matrix_rejection | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 71 | malformed.validation-source-outcome | WorkerObservationV1 | current C2A matrix substitution | WorkerObservationV1.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | current_observation_matrix_rejection | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 72 | malformed.wrong-context-namespace | V02 | input_context_ref prefix replaced | V02.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | schema_or_reference_mismatch | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 73 | malformed.wrong-rank14-relation-identity | rank14 | relation schema substituted | _rank14_relation_spec_failure | intentionally stale where structural precedence requires; no unrelated reseal | current_relation_spec_mismatch | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 74 | malformed.wrong-role-digest | V03 | typed_value_digest substituted | construct_post_execution_semantic_review_input | not applicable; parent/context equality check | role_digest_mismatch | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 75 | malformed.wrong-role-ref | V03 | typed_value_ref substituted | construct_post_execution_semantic_review_input | not applicable; parent/context equality check | role_ref_mismatch | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 76 | malformed.wrong-role-schema | V03 | typed_schema_id substituted | construct_post_execution_semantic_review_input | not applicable; parent/context equality check | role_schema_mismatch | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 77 | malformed.wrong-work-spec-pair | V38 | requirement WorkSpec digest substituted | V38.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | work_spec_pair_mismatch | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 78 | malformed.V4I001.contradictory-duplicate-host-identity-field | source-owner.host-qualification | add /qualification_digest: "absent" -> "fb18bf1d97830fa0ff602f90d59cf0f718f3df53754c3f28e27d7f40d7b62681" | _source_owner_metadata_failure + current owner constructor | not applicable; owner/allocation equality | source_owner_duplicate_identity_field | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 79 | malformed.V4I002.host-profile-substitution | source-owner.host-qualification | replace /relation_and_profile/profile: null -> "rw0-wire-nwpf-v1" | _source_owner_metadata_failure + current owner constructor | not applicable; owner/allocation equality | source_owner_profile_signature_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 80 | malformed.V4I003.host-relation-name-substitution | source-owner.host-qualification | replace /relation_and_profile/relation: "validate_host_qualification" -> "rank-6 host qualification relation" | _source_owner_metadata_failure + current owner constructor | not applicable; owner/allocation equality | source_owner_relation_signature_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 81 | malformed.V4I004.v26-entry-schema-id-omission | behavior-profile.rw0-c-decision-membership-closure.v1 | remove /entry_fields/0: "schema_id" -> "absent" | RW0CDecisionMembershipClosureEntryV1.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | nested_profile_field_order_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 82 | malformed.V5C001.variable-list-fixed-cardinality-reintroduction | value-schema.V11.postexecutionrolesupplyv2 | add /ordered_fields/support_canonical_values/cardinality: "absent" -> 0 | V11 variable-list allocation checker | not applicable; owner/allocation equality | variable_list_contract_contradiction | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 83 | malformed.V5C002.standing-policy-support-inventory-substitution | behavior-profile.post-execution-standing-policy-matrix.v1 | replace /support_roles: [["policy_source",1],["policy_profile",2],["authority_observation_and_parent_grant",3],["source_effect_fence",4]] -> [["policy_source",1],["policy_profile",2],["parent_grant",3],["authority_observation",4],["source_effect_intent",5]] | PostExecutionEvidenceSupplyV2.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | support_inventory_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 84 | malformed.V5C003.currentness-risk-component-collapse | behavior-profile.rw0-c-proposal-evidence-currentness.v1 | replace /components: ["validation","review","policy","risk_profile","risk_binding"] -> ["validation","review","policy","risk"] | RW0CProposalEvidenceCurrentnessV1.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | currentness_component_contract_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 85 | malformed.V5C004.snapshot-risk-source-collapse | behavior-profile.rw0-c-decision-current-snapshot.v1 | replace /resupplied_owner_sources: ["validation","review","policy","risk_profile","risk_binding"] -> ["validation","review","policy","risk_source_profile_and_binding"] | RW0CDecisionCurrentSnapshotV1.from_mapping | intentionally stale where structural precedence requires; no unrelated reseal | snapshot_source_contract_mismatch | PASS: accepted positive reconstructed/re-run after isolated mutation |
| 86 | malformed.V5L003.underflow-rejection | package-wide-list-contract-guard | finite one-predicate underflow vector family | each affected production value .from_mapping constructor | intentionally stale; list grammar precedes parent identity | reject_underflow | PASS: canonical base bytes asserted unchanged per case |
| 87 | malformed.V5L004.overflow-rejection | package-wide-list-contract-guard | finite one-predicate overflow vector family | each affected production value .from_mapping constructor | intentionally stale; list grammar precedes parent identity | reject_overflow | PASS: canonical base bytes asserted unchanged per case |
| 88 | malformed.V5L005.reorder-rejection | package-wide-list-contract-guard | finite one-predicate reorder vector family | each affected production value .from_mapping constructor | intentionally stale; list grammar precedes parent identity | reject_reorder | PASS: canonical base bytes asserted unchanged per case |
| 89 | malformed.V5L006.duplicate-rejection | package-wide-list-contract-guard | finite one-predicate duplicate vector family | each affected production value .from_mapping constructor | intentionally stale; list grammar precedes parent identity | reject_duplicate | PASS: canonical base bytes asserted unchanged per case |
| 90 | malformed.V6R001.rank15-current-owner-cascade-stale | record-local listed bases | apply exactly one listed predicate at a time | rank-15 value/row constructor + V22 projection action | intentionally stale as named; earlier causal check proven | rank15_current_owner_cascade_mismatch | PASS: mutation applied to deepcopy; frozen positive remained unchanged |
| 91 | malformed.V8R001.migration0003-evidence-row-self-digest-stale | record-local listed bases | apply exactly one stale evidence_binding_digest at a time | DevelopmentModelProposalEvidenceBindingRowValue constructor | intentionally stale as named; earlier causal check proven | migration0003_evidence_row_self_digest_mismatch | PASS: owner row restored and canonical bytes asserted exact |
| 92 | malformed.V9R001.v16-parent-bound-extra-field-rejection | golden.V32.active-stop | exact frozen subcase(s) listed by the record | V32 parent constructor with V16 child dispatch | intentionally stale as named; earlier causal check proven | unknown_field_before_canonicalization | PASS: added key removed; stored raw SHA-256 matched |
| 93 | malformed.V11R001.v16-dispatched-reason-stale | record-local listed bases | apply exactly one concrete stale V10 reason to /reason at a time | V17/V18/V31/V32/V33 parent constructors with V16 child dispatch | intentionally stale as named; earlier causal check proven | dispatched_parent_reason_validation_before_parent_identity | PASS: restored child raw SHA-256 matched |

## 11. Preserved accepted behavior and boundaries

The repair retained V25's exact 256/257 transcript behavior, monotonic cursors, one capability epoch, 65,536 maximum, and explicit 65,537 rejection; V27/V29's five distinct currentness sources; V31/V32/V33 source-bound precedence; V34 recommendation consistency; and active-stop `deny/deny/deny/permit/permit`. Common exact built-in grammar, V9R001/V11R001 precedence, the runtime bytecode inventory guard and seven negative controls, 16 allowed and 15 forbidden import responsibilities, the six-module/no-production-caller/no-I/O boundary, privacy exclusions, and capsule-safe projection all passed.

No package-root export, StateStore/WriterSession method, migration/SQL resource, SQLite authority, production caller, I/O import, reserved V35-V37 allocation, or opaque-digest recovery completeness claim was introduced. Current C1 source, row, reader, matcher, and fifteen-kind inventory remain unchanged.

## 12. Documentation reconciliation

All seven authorized `.docs` paths were inspected after code and tests became truthful. They remained byte-identical to V2 because each paragraph already describes only the bounded private-pure tranche and explicitly denies production callers, runtime/I/O, durable decision writing, migration/SQLite widening, public export, authority/custody, C2B progression, terminal state, RW0-D/E, and Execution Substrate work.

| Document | Bytes | SHA-256 | V2-to-V3 | Truthful bounded status |
|---|---:|---|---|---|
| `.docs/architecture.md` | 41,677 | `43781644500ee7c6f9a104cc8674f18c3fd0de1dd6d078aaee478bea42ee1042` | byte-identical | Yes; private pure/no-I/O implementation with all listed nonclaims preserved |
| `.docs/autonomous-software-development-operating-model.md` | 36,742 | `fa0248a56cb7c68226c28e318dfa4fcbaabcce04f3c539e90b88a5393e41ee51` | byte-identical | Yes; private pure/no-I/O implementation with all listed nonclaims preserved |
| `.docs/c2a1-pure-semantic-values.md` | 17,603 | `6912f254da3a1bed17058dfed24710c58ffafdc8c61f663d38435fe30acd2729` | byte-identical | Yes; private pure/no-I/O implementation with all listed nonclaims preserved |
| `.docs/c2b-durable-development-state.md` | 1,885,990 | `51df62dfd5b2477860be137d4e045f4379058e69ef3106781dcc03ff5c160c14` | byte-identical | Yes; private pure/no-I/O implementation with all listed nonclaims preserved |
| `.docs/rw0-b1-pure-phase-values.md` | 31,818 | `7dbe48979693919cb040f7848026d7759641d4d9b1e2bba340ad0ff2972d140a` | byte-identical | Yes; private pure/no-I/O implementation with all listed nonclaims preserved |
| `.docs/rw0-c1-durable-evidence.md` | 13,727 | `2548de75a2050f0989e03e44c167117c2748becffa0af52414c08e5926b856cc` | byte-identical | Yes; private pure/no-I/O implementation with all listed nonclaims preserved |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | 55,046 | `95b921669b21f478f23b9b855094e7a16a8c5a86b778b80781f2be380cd4ab23` | byte-identical | Yes; private pure/no-I/O implementation with all listed nonclaims preserved |

The protected prefixes, Sections 1-41, H2 order, C1 fifteen-kind ownership, B1 registry/sole-consumer claims, and explicit nonclaims were preserved.

## 13. Focused and development validation

Final-candidate focused commands ran with `PYTHONDONTWRITEBYTECODE=1` and pytest cache disabled:

| Command scope | Result | Candidate binding |
|---|---|---|
| `python3 -m pytest -p no:cacheprovider -q tests/test_post_execution_pure_owner_relations.py` | 290 passed in 16.03s | final V3 manifest `92331f2082200e62889a27109958fc1b35d7949146b28ac28ee512d157840262` |
| `python3 -m pytest -p no:cacheprovider -q tests/test_post_execution_pure_owner_vectors.py` | 234 passed in 2.57s | same final bytes |
| Seven-file tranche/guard focus (the V02 file list) | 1,176 passed in 21.18s | same final bytes |
| 93 malformed registry plus no-self-raise and V22 assurance focus | 95 passed in 1.32s | same final bytes |
| 153 exhaustive V03/V11 cases plus mandatory V03/V11/V24 hostile focus | 157 passed in 2.97s | same final bytes |
| V22/rank-15 focused relation tests | 8 passed in 0.15s | same final bytes |

Intermediate diagnostics were not counted as validation credit. The first 93-control run stopped at V3G004 because the new global-stop checker compared ordered fields to a frozenset iteration; it was bounded to dataclass field order. The rerun then stopped at V3G030 because the frozen descriptor says `external_current_sources` while the actual V27 owner field is `external_sources`; the real-field mutation was corrected. The next rerun stopped at V5C004 for the same actual-field-name issue; it was corrected, after which all 93 passed. The first no-self-raise guard matched its own sentinel string; the check was changed to AST function-name inspection and its rerun passed. These were superseded, non-provenance-bound development states; the final passing commands and every formal command below ran against the exact saved V3 manifest bytes.

## 14. Formal V02-V06 external-clone validation

The clone used a mode-0700 private root, clone-time umask 022, and `git clone --no-local --single-branch --no-tags --branch trunk_dev --depth 1` from the exact local committed HEAD. Exactly the twenty manifest files were overlaid and verified by type, mode, size, and SHA-256 before tests. Commands ran serially with no concurrent edit or cleanup.

### V02

`env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_post_execution_pure_owner_values.py tests/test_post_execution_pure_owner_vectors.py tests/test_post_execution_pure_owner_relations.py tests/test_post_execution_pure_owner_boundaries.py tests/test_c2a_nonimplementation.py tests/test_runtime_non_authority.py tests/test_rw0_b1_boundaries.py`

Result: 1,176 passed in 21.48s.

### V03

`env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_rw0_b1_phase_values.py tests/test_rw0_b1_vectors.py tests/test_rw0_b1_relations.py tests/test_worker_execution_semantic_values.py tests/test_worker_execution_semantic_vectors.py tests/test_worker_execution_semantic_relations.py tests/test_worker_execution_semantic_boundaries.py tests/test_finite_backlog.py tests/test_global_stop.py`

Result: 472 passed in 11.15s.

### V04

`env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_section41_cognitive_proposal_row_values.py tests/test_section41_cognitive_proposal_semantic_values.py tests/test_section41_pre_execution_plan_disposition_contracts.py tests/test_section41_pre_execution_plan_disposition_recovery.py tests/test_section41_private_atomic_pre_execution_plan_disposition.py tests/test_section41_private_pre_execution_plan_disposition_delegation.py tests/test_rw0_c1_mutation_contracts.py tests/test_rw0_c1_private_atomic_persistence.py tests/test_rw0_c1_private_readers.py tests/test_rw0_c1_reader_contracts.py tests/test_rw0_c1_recovery.py tests/test_rw0_c1_row_values.py tests/test_rw0_c1_semantic_values.py tests/test_rw0_c1_writer_session_delegation.py tests/test_remote_worker_pre_execution_planning_contract.py::test_f1_post_execution_common_proposal_needs_no_preexecution_context_row tests/test_remote_worker_pre_execution_planning_contract.py::test_s41_post_execution_evidence_is_exactly_zero_or_complete tests/test_remote_worker_pre_execution_planning_contract.py::test_s41_post_execution_evidence_rejects_every_noncanonical_member tests/test_remote_worker_pre_execution_planning_contract.py::test_repaired_nine_table_ddl_and_both_golden_families_are_representable tests/test_remote_worker_pre_execution_planning_contract.py::test_migration_0003_owner_freezes_exact_representability_without_0002_rebuild`

Result: 300 passed in 241.77s.

### V05

`env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_sqlite_b1_migrations.py tests/test_sqlite_c2b1_migration_framework.py tests/test_sqlite_c2b2_migration_0002.py tests/test_sqlite_section41_migration_0003.py tests/test_sqlite_rw0_c1_migration_0004.py tests/test_autonomous_software_development_operating_model.py tests/test_architecture_contracts.py tests/test_rw0_remote_contact_phase_entry_contract.py tests/test_software_development_progression_boundary.py tests/test_rw0_b2_wire_boundaries.py tests/test_rw0_b2_capability_boundaries.py`

Result: 529 passed in 21.16s.

### V06

`env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q`

Result: 6,183 passed in 1,486.92s (24:46), with three Python 3.13 deprecation warnings about `fork()` from a multithreaded process and no test failure.

## 15. Clone provenance, hygiene, and cleanup

Clone-start and clone-end recipe outputs were each reproduced twice and were byte-identical to the live saved V3 manifest: recipe ID `governed-execution.audit-patch-manifest.v1`; 20 files; manifest SHA-256 `92331f2082200e62889a27109958fc1b35d7949146b28ac28ee512d157840262`; tracked textual diff SHA-256 `897e95f470b55690abb2c25bd2b1d0b760ad9e6b0b3541f4ad4f5012cd0f022f`.

After V06: `git diff --check` passed; status was exactly 10 tracked modifications plus 10 untracked files; staged and unmerged counts were zero; scans found zero `__pycache__`, `.pytest_cache`, `.pyc`, `.pyo`, SQLite database/journal/WAL/SHM, lock, build, egg-info, archive, OS metadata, symlink, or unsupported-type artifacts.

The validation root and the V3-created cache-cleanup quarantine were removed from their working `/tmp` locations using `/usr/bin/trash`. They are recoverable system-Trash residue. macOS denied direct enumeration of `/Users/ds/.Trash`; the original working locations were independently verified absent.

## 16. Live opening/final cache equality

The final live ignored cache inventory is exactly the opening inventory: 37 regular `.pyc` members under the one pre-existing `src/ge_nwp_coordinator/__pycache__` root, with no addition, deletion, content change, mode change, `.pytest_cache`, or test cache. Both normalized aggregates are `dbaa5d1ff000e2c00e9b64d5b1e591ac8374e1b9bd9f3a6c5c0c17b3742c8f90`.

## 17. Final V3 provenance

`RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V3.json` is canonical compact sorted-key JSON with final LF, 4,377 bytes, one logical line, and SHA-256 `92331f2082200e62889a27109958fc1b35d7949146b28ac28ee512d157840262`. It records recipe ID `governed-execution.audit-patch-manifest.v1`, recipe source SHA-256 `db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`, branch `trunk_dev`, HEAD `a3ff0b7f4f0c2378c2962e24612d605489b51638`, upstream `origin/trunk_dev`, 20 files, and tracked textual diff SHA-256 `897e95f470b55690abb2c25bd2b1d0b760ad9e6b0b3541f4ad4f5012cd0f022f`.

Final live identity was rechecked after clone cleanup: tree `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0`; parent `047563de5a443b0f8323401c92979ae2e444d2ed`; subject unchanged; divergence `0/0`; one worktree; exact 20 paths; zero staged/unmerged. Two final live recipe executions were byte-identical to the saved V3 manifest.

## 18. V3 report identity posture

This file is `RW0_Post_Execution_Pure_Owner_Implementation_Report_V3.md`. Its final byte size, logical-line count, final-newline posture, and SHA-256 are intentionally measured after writing and reported in the client closeout; the report cannot self-bind its own digest without recursive instability. It is implementation/process evidence, not an independent audit or authority artifact.

## 19. Assumptions, remaining seams, and inspection limits

- Assumption: the fixed accepted V11 package and boundary artifacts remain governing inputs exactly at their verified hashes; they were not regenerated or reopened.
- No required validation was skipped or unavailable. The only unavailable observation was direct enumeration of system Trash after successful recoverable cleanup; both former working locations were absent.
- Supporting repositories were neither inspected nor modified. No network, remote, dependency installation, migration, live service, provider/model, or Execution Substrate action was used.
- Remaining seams are unchanged and explicit: no production caller; no runtime or I/O; no durable post-execution decision; no public export; no migration/SQLite widening; no external authority/authenticity/custody; no C2B progression decision write; no terminal outcome; no RW0-D/E; no Execution Substrate behavior; and future decision command/result/receipt/recovery ownership remains unfrozen.
- Inspection was bounded to the fixed inputs, the exact Coordinator repository candidate, the protected current-owner paths exercised by tests, and the private external validation clone.

## 20. Explicit non-actions

`INDEPENDENT_AUDIT_NOT_PERFORMED`

`MIGRATION_0005_NOT_CREATED`

`SQLITE_RUNTIME_NOT_WIDENED`

`PUBLIC_EXPORT_NOT_CREATED`

`PRODUCTION_CALLER_NOT_CREATED`

`DURABLE_DECISION_NOT_IMPLEMENTED`

`C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED`

`RW0_C_TERMINAL_NOT_IMPLEMENTED`

`RW0_D_NOT_IMPLEMENTED`

`RW0_E_NOT_IMPLEMENTED`

`EXECUTION_SUBSTRATE_NOT_MODIFIED`

`STAGING_NOT_PERFORMED`

`COMMIT_NOT_PERFORMED`

`PUSH_NOT_PERFORMED`

`PR_NOT_CREATED`

`REMOTE_CONTACT_NOT_PERFORMED`

`SUPPORTING_REPOSITORIES_NOT_INSPECTED`

`SUPPORTING_REPOSITORIES_NOT_MODIFIED`
