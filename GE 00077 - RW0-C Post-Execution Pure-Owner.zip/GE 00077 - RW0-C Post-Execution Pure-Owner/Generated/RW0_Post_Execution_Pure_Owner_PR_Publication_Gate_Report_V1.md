# RW0 Post-Execution Pure-Owner PR Publication Gate Report V1

## Disposition

The exact immutable commit was published to the authorized remote topic branch, and one exact open pull request was created and verified against `trunk_dev`.

`RW0_POST_EXECUTION_PURE_OWNER_PR_CREATED_AND_VERIFIED`

## Published coordinates

| Field | Value |
|---|---|
| Repository | `evo-agi/Governed-Execution-Coordinator` |
| Local branch | `trunk_dev` |
| Commit | `ac09623763e71ff822f80a6ca98bed3e47f8e1ee` |
| Commit tree | `9e69d4a517b482704c159958abc2f90ed3cdcfd8` |
| Sole parent | `a3ff0b7f4f0c2378c2962e24612d605489b51638` |
| Remote topic branch | `codex/rw0-c-post-execution-pure-owners-v1` |
| Remote topic OID | `ac09623763e71ff822f80a6ca98bed3e47f8e1ee` |
| PR | [#8](https://github.com/evo-agi/Governed-Execution-Coordinator/pull/8) |
| PR base | `trunk_dev` |
| PR head | `codex/rw0-c-post-execution-pure-owners-v1` |
| PR state | `OPEN`, non-draft |
| Merged | `false` |
| Auto-merge enabled | `false` |

## Fixed-input verification

The two client-supplied publication inputs were resolved only from their supplied attachment paths.

| Input | Bytes | Logical lines | SHA-256 | Result |
|---|---:|---:|---|---|
| `RW0_Post_Execution_Pure_Owner_Commit_Gate_Report_V1.md` | 13,427 | 230 | `062327a7964fb1a783f5ea6e8931c909c9740aa404a10f9488400c207a6aae19` | exact; final LF present |
| `RW0_Post_Execution_Pure_Owner_Committed_Blob_Receipt_V1.json` | 16,104 | 1 | `e2e633f04d2cbe922c207b9be4851b3cd1817da21ad4aae69a0c0c74733ec5f5` | exact; canonical compact sorted-key JSON; no duplicate keys; final LF present |

The committed-blob receipt bound:

- schema `governed-execution.rw0-post-execution-pure-owner-committed-blob-receipt.v1`;
- prior outcome `RW0_POST_EXECUTION_PURE_OWNER_COMMITTED_PUSH_NOT_COMPLETED`;
- the exact commit, tree, parent, subject, and body hash;
- exactly 20 unique paths;
- staged and committed blob OID equality for every path;
- mode `100644` for every path;
- final clean local posture;
- prior direct-push failure class `remote_rejected_repository_rule_requires_pull_request`.

## Gate A — local immutable-commit verification

Before remote contact:

- physical repository root and branch were exact;
- HEAD was `ac09623763e71ff822f80a6ca98bed3e47f8e1ee`;
- tree was `9e69d4a517b482704c159958abc2f90ed3cdcfd8`;
- the commit had exactly one parent, `a3ff0b7f4f0c2378c2962e24612d605489b51638`;
- subject was exactly `feat: implement RW0-C post-execution pure owners`;
- exact UTF-8 body bytes with final LF hashed to `5ac63b2d0ce6b2e70479568d4059f5bd36ca850efb2acfb0e05f8bea9c35b286`;
- all 20 committed paths, classifications, modes, blob OIDs, byte sizes, and SHA-256 values independently matched the receipt;
- the worktree, index, untracked set, and unmerged set were clean;
- exactly one worktree existed;
- no merge, rebase, cherry-pick, revert, bisect, sequencer, or index-lock state was active;
- no local topic branch existed;
- the ignored cache remained one root and 37 members with aggregate `dbaa5d1ff000e2c00e9b64d5b1e591ac8374e1b9bd9f3a6c5c0c17b3742c8f90`.

Implementation tests were not rerun because the immutable committed bytes had already passed their audit and staged-byte validation.

## Gate B — remote observation

The configured `origin` was verified as the expected GitHub repository without printing credentials or sensitive URL components.

The initial narrow remote observation found:

- `refs/heads/trunk_dev` at `a3ff0b7f4f0c2378c2962e24612d605489b51638`;
- `refs/heads/codex/rw0-c-post-execution-pure-owners-v1` absent.

The remote base exactly equaled the commit parent. Base drift was `false`.

## Gate C — topic-branch publication

Exactly one plain, non-force push published:

`ac09623763e71ff822f80a6ca98bed3e47f8e1ee:refs/heads/codex/rw0-c-post-execution-pure-owners-v1`

A fresh narrow observation verified:

- topic branch OID exactly `ac09623763e71ff822f80a6ca98bed3e47f8e1ee`;
- `trunk_dev` remained exactly `a3ff0b7f4f0c2378c2962e24612d605489b51638`.

`REMOTE_TOPIC_BRANCH_CREATED`

## Gate D — pull-request creation

An authenticated all-state query found no pre-existing PR for the exact topic branch.

One normal, non-draft PR was created with:

- title: `feat: implement RW0-C post-execution pure owners`;
- base: `trunk_dev`;
- head: `codex/rw0-c-post-execution-pure-owners-v1`;
- body supplied through an exact temporary body file outside the repository;
- no labels, reviewers, assignees, milestone, project, auto-merge, or merge-queue action requested.

The exact PR body was 1,403 bytes with SHA-256 `b4adf6c05abfddfcfce6cd833b492eae6819c1fcda7a7e819bb2e892f62fef99`.

`PR_CREATED`

## Gate E — remote and PR verification

Authenticated read-only verification established:

| Property | Observation |
|---|---|
| PR number | `8` |
| URL | [https://github.com/evo-agi/Governed-Execution-Coordinator/pull/8](https://github.com/evo-agi/Governed-Execution-Coordinator/pull/8) |
| State | `OPEN` |
| Draft | `false` |
| Title | exact |
| Base | `trunk_dev` |
| Base OID | `a3ff0b7f4f0c2378c2962e24612d605489b51638` |
| Head | `codex/rw0-c-post-execution-pure-owners-v1` |
| Head OID | `ac09623763e71ff822f80a6ca98bed3e47f8e1ee` |
| Body | exact |
| Merged | `false` |
| Auto-merge | disabled |

The body contained the exact commit, tree, implementation-audit token, full-suite validation count, and explicit non-claims.

Immediate remote projection at verification time:

- mergeability: `MERGEABLE`;
- merge-state status: `CLEAN`;
- reported check-rollup entries: `0`;
- base drift: `false`.

This is a transient remote projection only. It is not acceptance truth, merge authority, or a guarantee that later base-branch state remains compatible. The gate did not wait indefinitely for CI and did not merge.

## Gate F — final local verification

After all remote operations:

- local HEAD remained `ac09623763e71ff822f80a6ca98bed3e47f8e1ee`;
- local tree remained `9e69d4a517b482704c159958abc2f90ed3cdcfd8`;
- the checked-out branch remained `trunk_dev`;
- staged, unstaged, untracked, and unmerged path counts remained zero;
- no Git operation or lock was active;
- no local topic branch was created;
- cache posture remained one root, 37 members, aggregate `dbaa5d1ff000e2c00e9b64d5b1e591ac8374e1b9bd9f3a6c5c0c17b3742c8f90`.

No repository byte or commit changed during this gate.

## Canonical PR receipt

`RW0_Post_Execution_Pure_Owner_PR_Receipt_V1.json`

- schema: `governed-execution.rw0-post-execution-pure-owner-pr-receipt.v1`
- bytes: 3,812
- logical lines: 1
- final LF: present
- canonical compact sorted-key UTF-8 JSON: verified
- duplicate keys: none
- SHA-256: `1aa6f9b3c858fa76d32bcab026760fc9d8998532f3e336b24d4fe5922760d4a8`

## Recoverable cleanup residue

The exact temporary PR body was moved from its working location into the user's Trash as:

`rw0-post-execution-pure-owner-pr-body-ac096237-pr8.md`

It remains recoverable. No pre-existing Trash or cache material was changed.

## Inspection limitations

- Remote refs were observed narrowly without fetching tags or changing local history.
- PR mergeability, merge-state, and check rollup are transient GitHub projections and may change after this report.
- Zero checks were reported at the immediate verification point; the gate did not wait for later CI registration or completion.
- No supporting repository was inspected or modified.

## Required non-actions

```text
CANDIDATE_BYTES_NOT_CHANGED
NEW_COMMIT_NOT_CREATED
COMMIT_NOT_AMENDED
REBASE_NOT_PERFORMED
MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
FORCE_PUSH_NOT_PERFORMED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
MIGRATIONS_NOT_RUN
RUNTIME_NOT_ACTIVATED
PUBLIC_EXPORT_NOT_CREATED
PRODUCTION_CALLER_NOT_CREATED
DURABLE_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
SUBAGENTS_NOT_SPAWNED
REMOTE_TOPIC_BRANCH_CREATED
PR_CREATED
```

## Final outcome

The exact remote topic branch points to the exact immutable commit, and PR #8 is open, non-draft, unmerged, and verified with the exact base, head, title, body, and head OID.

`RW0_POST_EXECUTION_PURE_OWNER_PR_CREATED_AND_VERIFIED`
