# Disposition

**Accept the independent audit’s `BLOCK` verdict.**

V10 is mechanically and cryptographically sound, and its V9→V10 envelope repair is exact. The remaining failures are bounded package-contract defects:

1. **Thirty-four V16 children use reasons outside their dispatched parent profile.**
2. **Three malformed controls therefore start from invalid positive bases.**
3. **The rank-15 admission graph and membership omit one required preimage coordinate: `admitted_by_mutation_ref`.**

These do not reopen the authority split, five-field V16 decision, global-stop behavior, module decomposition, or migration-free implementation target. V10 is simply not ready for implementation-boundary freeze. :chatgpt-content-reference{index="0"}

## Finding 1: the 34 reason failures reproduce

The audit’s exact breakdown is correct:

| Dispatch | V10 reason | Required reason | Invalid children |
|---|---|---|---:|
| V18 halt-only | `halt_only_risk_lane_not_applicable` | `halt_only_risk_not_applicable` | 10 |
| V31 governed | `current_evidence_permits` | `authority_verified_current` | 3 |
| V31 halt-only | `halt_only_checked` | `halt_only_authority_not_applicable` | 2 |
| V32 clear governed | `current_evidence_permits` | `global_stop_clear` | 3 |
| V32 halt-only | `halt_only_checked` | `halt_only_stop_checked` | 6 |
| V33 governed | `current_evidence_permits` | `source_effect_within_current_ceilings` | 6 |
| V33 halt-only | `halt_only_checked` | `halt_only_ceiling_not_applicable` | 4 |

That is exactly:

```text
V18: 10
V31:  5
V32:  9
V33: 10
Total: 34
```

The twelve affected records also match the audit. :chatgpt-content-reference{index="1"}

A global string replacement would be wrong. The same `halt_only_risk_lane_not_applicable` literal also appears in V41/V42 branch assertions, which use distinct schemas and were not classified as invalid V16 children. The repair must first identify the nested schema and consuming profile.

The corrected standalone V18 primary has this deterministic direct identity before downstream propagation:

```text
matrix_ref:
risk-lane-matrix-golden.0001

matrix_digest:
7c81d7280e2c6fc4f0cde40d0dcd07edaf0d7e7c47bf90f6d001005acdccaa60

canonical bytes:
2,971

raw canonical SHA-256:
ecc1e9d935b424c7281f6b3134ce0bc9bb8e6705477206b1d604fce687ed4874
```

The V18 correction is upstream of the model-input, proposal, migration-0003 row, rank-15, closure, snapshot, and decision-input chains. Consequently, the final V11 V31–V34 identities must be mechanically regenerated on the final repaired basis rather than patched using V10’s parent coordinates.

## Finding 2: causal assurance must be rebuilt

The three named malformed records currently carry invalid nested reasons:

```text
malformed.risk-source-substitution
malformed.attempt-fence-expiry-substitution
malformed.global-stop-branch-mismatch
```

Although their refs, digests, and restoration operations reproduce mechanically, their bases fail nested reason validation before reaching the intended mutation. The auditor therefore correctly withheld causal credit from those vectors and from A062/V7G001. :chatgpt-content-reference{index="2"}

V11 must:

- rebuild each vector from its final semantically valid positive;
- preserve only the intended source, expiry, or result mutation;
- update A062’s now-false claim that V18 remained byte-exact;
- strengthen V7G001 with the exact active-stop reason vocabulary;
- add a seven-case stale-reason assurance/malformed pair so this class of defect cannot recur silently.

## Finding 3: the missing rank-15 preimage is exactly recoverable

Current source requires `admitted_by_mutation_ref` in both the admission-graph and membership preimages:

```text
src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py:1023-1032
src/ge_nwp_coordinator/_sqlite_rw0_c1.py:3157-3203
```

V10 contains ten instances of that field for rank-12/13 controls, but none for rank 15. The auditor could observe the final graph and membership digests but could not independently reproduce them. :chatgpt-content-reference{index="3"}

I reconstructed the complete V10 preimages and recovered the omitted value:

```text
admitted_by_mutation_ref:
c1-admit-section41-golden.0001
```

It reproduces both published V10 identities independently:

| Control | Canonical bytes | Raw SHA-256 | Domain-separated digest |
|---|---:|---|---|
| Rank-15 admission graph | 1,100 | `07eab636c2896c49c06dd24cd0bc934d55b9e93aa60412ae243623769cf6546d` | `484291049fe80389eef3a856024fc26f70a59a05c3a34048eaeafbc37b5ec7e4` |
| Rank-15 membership | 862 | `eaab9f49c0abe3dbdcd2e998401160f9c4612aa9e6f88f78c0ddf0a719edceb7` | `5a0e664074e92aa69360513fd022824a6a247db1f18dd92cc141679047620b6f` |

This avoids inventing a new synthetic identity or unnecessarily changing V10’s historical graph. V11 should preserve the recovered mutation ref but regenerate the graph and membership around the final repaired reason/proposal/rank-15 chain.

The prompt adds:

```text
golden.owner.rank15.graph
golden.owner.rank15.membership
assurance.A063
```

It also extends V6R001 with an exact one-field mutation of the admission mutation ref, so hidden-preimage substitution becomes causally covered.

# V11 repair handoff

Use a **package-generation/repair Codex conversation**, not the independent-audit conversation.

Attach only the following prompt and exact V10 fixed input. The findings, current-source formulas, reason map, recovered mutation ref, assurance treatment, and stop conditions are embedded in the prompt.

### Repair prompt

:chatgpt-content-reference{index="6"}[Download the V11 reason-vocabulary and rank-15-preimage repair prompt](sandbox:/mnt/data/Coordinator_RW0_Canonical_Package_V11_Reason_Vocabulary_and_Rank15_Preimage_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_Canonical_Package_V11_Reason_Vocabulary_and_Rank15_Preimage_Repair_Prompt.txt

Size:
35,027 bytes

SHA-256:
ae0facd3def14ce1f69cb72060ff8e27645d312f24ae50a359cbd18d9047c115

Logical lines:
1,135

Final newline:
absent
```

### Sole fixed input

:chatgpt-content-reference{index="7"}[Download the exact V10 package](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Audit_Package_V10.jsonl)

```text
Filename:
RW0_Post_Execution_Canonical_Audit_Package_V10.jsonl

Size:
2,613,816 bytes

SHA-256:
1f3c08d3a721f4d9bc75d89f9a0ce604bbc344c0f3cd8b3be51218dd17c1430c

Logical records:
1,681

Final newline:
absent

Content aggregate:
9302da29abad2bbdd78dcae33b1d499236d046cb195184caf8248b60e0b63895
```

The prompt deliberately does **not** freeze a final record count or hand-written complete changed-record set. The V18 repair is upstream of much of the package, so Codex must derive the full dependency closure, semantic supersessions, and record-payload supersessions mechanically.

It does freeze exactly five new substantive IDs:

```text
golden.owner.rank15.graph
golden.owner.rank15.membership
assurance.A063
assurance.V11R001.v16-dispatched-reason-stale
malformed.V11R001.v16-dispatched-reason-stale
```

The required success token is:

```text
RW0_POST_EXECUTION_CANONICAL_PACKAGE_V11_REASON_AND_RANK15_PREIMAGE_REPAIRED_READY_FOR_INDEPENDENT_AUDIT
```

A successful V11 result authorizes only another fresh, parent-only, local, read-only independent audit. It does not authorize implementation-boundary freeze, repository implementation, migration `0005`, durable mutation, C2B progression writing, terminal work, RW0-D/E, or Execution Substrate changes. The auditor imposed the same continuation boundary. :chatgpt-content-reference{index="4"}

**Inspection limit:** I reproduced the V10 package identity, all 34 reason failures, the exact rank-15 source formulas, and both missing-preimage digest equations. I did not run repository tests, migrations, a persistent database, or product runtime behavior.

**Sources:** V10 independent-audit report; exact V10 package; uploaded Coordinator snapshot at `a3ff0b7f4f0c2378c2962e24612d605489b51638`. The audit’s severity-ranked corrections are at lines 208–245. :chatgpt-content-reference{index="5"}

**Confidence:** 0.995 that `BLOCK` is correct; 0.995 on the 34 reason failures; 0.999 on recovery of `c1-admit-section41-golden.0001`; 0.98 that the V11 prompt defines the narrowest sufficient repair boundary.
