PROMPT_ID

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V6_RANK15_AND_SUPERSESSION_REPAIR_V1

TITLE

Coordinator RW0 — repair package V5 rank-15 current-owner grounding and
supersession leakage, regenerate the complete dependent identity cascade, and
deliver canonical package V6 for a fresh independent audit

ENGAGEMENT TYPE

Parent-only, local, repository-read-only canonical-package repair.

Use a package-generation/repair conversation, not the independent-audit
conversation that reported the findings. Preserve auditor/repairer separation.

Do not delegate to subagents or internal audit agents.

Do not edit repository files, format repository files, stage, commit, push,
create a branch or PR, merge, tag, release, deploy, fetch, contact a remote or
live system, install dependencies, execute repository tests, run migrations,
open or mutate an operator database, invoke a product worker/model, or
inspect/modify supporting repositories.

You MAY create files only in one fresh private external temporary root for
bounded source inspection and package reconstruction. Remove disposable
intermediates before closeout.

Return the revised package through the client-visible attachment mechanism.
A private filesystem path is not a deliverable.

Do not issue an implementation prompt.

ATTACHMENT RECEIPT CONTRACT

The sole fixed contract input is the client-uploaded attachment named:

RW0_Post_Execution_Canonical_Audit_Package_V5.jsonl

Do not require, request, or assume a second copy in `/Users/ds/Downloads/` or
any other predetermined path. A runtime materialization path may be used as an
implementation detail, but path presence is not part of the fixed-input
contract.

Before substantive work, visibly report an attachment receipt containing:

- observed filename;
- accessible runtime path, if the client exposes one;
- byte size;
- SHA-256;
- logical record count;
- final-newline posture.

If the client attachment is not accessible, stop immediately and return:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V6_FIXED_INPUT_ATTACHMENT_UNAVAILABLE

Do not search for or silently substitute a same-named local file. Do not treat
attachment transport failure as a semantic or source-owner finding.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V6_BASELINE_MISMATCH

FIXED INPUT IDENTITY

Require the attached V5 package to have exactly:

filename:
RW0_Post_Execution_Canonical_Audit_Package_V5.jsonl

size:
2409171 bytes

SHA-256:
92e3d5c9d1da29c225c5ffafc4b69d408a1780cee12d0488e7ff8d507c651d44

logical records:
1489

final newline:
absent

content aggregate:
3267e8652d5f512379a9df3df466dbc31a5966273ea5315e8bfa79d9b242814a

first record:
package.manifest.v1

last content record:
remaining-seam.S008

final record:
package.closeout.v1

record-type counts:

package_manifest: 1
source_owner_binding: 23
value_schema: 44
behavior_profile: 28
golden_value: 196
malformed_vector: 89
module_allocation: 44
import_edge: 31
equality_matrix: 36
assurance_case: 116
supersession_entry: 872
remaining_seam: 8
package_closeout: 1

If any fixed-input property differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V6_FIXED_INPUT_MISMATCH

DISPOSITION OF THE INDEPENDENT AUDIT

Treat the audit result as a bounded package/contract block, not a foundational
architecture rejection.

The two findings are definitive and must be repaired. They do not authorize or
require any repository owner change, migration, implementation, public API,
writer, latch, terminal, D/E, provider, worker, transport, or Execution
Substrate work.

PRESERVED CONTRACTS

Preserve every V5 contract that the independent audit accepted, including:

- exact canonical JSONL mechanics and the closed record-type envelope;
- all source-owner bindings outside the rank-15 cascade;
- all 44 value schemas and 28 behavior profiles except transitively changed
  identities required by this repair;
- profile-bounded list cardinalities and support inventories;
- the distinct validation, review, policy, risk_profile, and risk_binding
  currentness components;
- the two-context temporal model and monotonic construction chronology;
- exact nine-role model-input, Section 41, and resupply equality structure;
- transient/private candidate-capsule handling and safe projection privacy;
- V40 operational reviewer separation without human/provider/account/principal
  identity claims;
- owner-authored standing-policy and risk attestations;
- generic risk semantics separated from the versioned FiniteBacklog adapter;
- exactly fifteen current C1 evidence kinds and no C1 completeness authority;
- explicit deferral and current absence of V35-V37 committed-recovery values;
- the migration-free pure-owner implementation decomposition as a proposed
  boundary only;
- no implementation authorization.

Do not change semantics merely to preserve an existing V5 hash or identity.

FINDING V5-AUDIT-001 — RANK-15 CURRENT-OWNER CASCADE IS NOT GROUNDED TO SOURCE

The package contains the exact twelve current owner locators in:

source-owner.migration0003-owner-family-graph

Those locators construct as current:

RW0C1OwnerRowLocatorV1

Under the current merged source, applying:

section41_owner_family_graph_digest

from:

src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py

must produce:

cabeddccdfd5dbd45fa6f7192e73e17c3f5b84c536c9cad00708cc45d09868bd

V5 instead carries this incorrect current graph digest in the rank-15 value:

0fa51721ee8fec6c0a74d9b44fd87de8d7e43875bd818b7058022765db798fbc

The current wrapper class is:

RW0C1Section41PostExecutionProposalFamilyMemberV1

from:

src/ge_nwp_coordinator/_rw0_c1_semantic_values.py

Using the V5 semantic fields and V5's incorrect graph, the current constructor
computes:

acec2eaf6c1c5267d3cd3b2e9fb8bef5edbfe763fb4041f8ce263b6f39ade536

V5 supplies a different and invalid wrapper digest:

a8133acc5229edf3cfd80f5b3dab5dfc972d2b517a12e12a8486d4ecc5e72c64

Using the exact current owner graph, the current constructor computes the
correct wrapper digest:

ddb30a465fb79f12dc632ae1298e749c4500fd6dda5c52cbaab2b26f79441dbf

Construct the twelve exact current owner operands in locator order using the
current owner schemas and RW0C1OperandIdentity grammar. With the current
relation reference and phase basis, the correct operand-set digest is:

625f377bb200912c8332d1f7dd5692db08cfe7ff5bad79fd677e3d75e7b88bd8

V5 instead carries:

09ae64f5313d00c7cbdbfaebd432556b53d0c5e31e3e31d2c68bfebddd340d81

Using the current rank-15 RW0C1RelationSpecification and the corrected wrapper
and operand set, the correct relation digest is:

63cb63c7b1544350f5a0fc6b185cc35579ae344d969026f5ce4c5ae81df0d418

V5 instead carries:

5692411f6167c68c3ce7a157eae40ff75471ad7edd6dc96eec1323288e976794

The current relation reference is not the defect. Preserve it if independent
reconstruction confirms it.

REQUIRED RANK-15 REPAIR

1. Parse the exact twelve locators from
   `source-owner.migration0003-owner-family-graph`.
2. Construct current `RW0C1OwnerRowLocatorV1` values from those exact fields.
3. Compute the graph through the current owning function. Do not hard-code a
   replacement without reproducing it from source.
4. Construct the current rank-15 wrapper through the current owning class. A
   supplied value digest must be accepted by that constructor; preferably
   derive it with the digest field omitted and then verify exact equality.
5. Construct all twelve owner operands through the current operand grammar and
   owner-schema mapping, in exact ordinal/role order.
6. Compute the operand-set and relation digests through current owning
   functions and the current rank-15 relation specification.
7. Recompute the relation-row digest, relation-set digest, scope binding,
   admission graph, membership, and every downstream identity from corrected
   semantic inputs. Do not patch only the four printed digests.
8. Rebuild every directly or transitively affected current record, including
   at minimum:

   - source-owner.rank15-section41-value
   - source-owner.rank15-section41-relation
   - golden.owner.rank15.value
   - golden.owner.rank15.relation
   - golden.V22.primary
   - all nine golden.V24.role-resolution.* records
   - golden.V25.primary
   - golden.V26.closure-entry.007
   - golden.V27.primary
   - every closure, snapshot, currentness, generated reference, equality,
     assurance, malformed-vector, module/profile binding, or other current
     consumer reached by the identity dependency graph

9. Regenerate all changed payload hashes, domain digests, generated refs,
   supersession entries, manifest lists, content aggregate, closeout, and
   whole-file identity.
10. Preserve historical supersession chains. Append exact V5-to-V6
    supersessions for every replaced V5 current identity rather than erasing
    prior repair history.

CURRENT-SOURCE CROSS-RECORD GUARD

Before success, independently prove all of the following from current source
and V6 package bytes:

- the twelve locator mappings equal the source-owner control record;
- the graph digest equals the rank-15 wrapper's owner_family_graph_digest;
- the current wrapper constructor accepts its supplied value_digest;
- the twelve constructed operands reproduce the stored operand_set_digest;
- the current relation function reproduces the stored relation_digest;
- the stored relation row, relation set, scope/admission graphs, membership,
  V22/V24/V25/V26/V27 chain, and currentness consumers bind the corrected
  identities;
- the current runtime exact-family matcher would not reject the corrected
  graph on this ground.

Add or adapt finite assurance and a dedicated malformed vector so that a stale
or substituted graph/value/operand/relation input fails causally. The assurance
must be ordinary package test evidence, not a self-authorizing audit claim.

FINDING V5-AUDIT-002 — SUPERSEDED IDENTITY LEAKS INTO AN ASSURANCE RECORD

The superseded identity:

3e5939d365d889413e1200b31674c55e32edf97b9f2467a914c5e271d29967f2

is legitimately retained in:

- malformed.V3G012.rank12-cascade-stale
- supersession.v3.identity.828f3470fb414694658f

It must not also survive literally in:

assurance.V3G012.rank12-cascade-stale

The assurance record currently repeats it in:

/exact_one_predicate_mutation/to

REQUIRED SUPERSESSION REPAIR

Replace the assurance record's concrete stale digest with a non-identity
symbolic mutation target, following the already accepted V4I001 pattern where
the assurance record is symbolic and the paired malformed vector carries the
concrete bytes.

The dedicated malformed vector must remain the only non-ledger record that
contains the concrete stale identity.

Recompute the assurance payload hash and every dependent package identity.

PACKAGE-WIDE SUPERSESSION GUARD

For every supersession entry with a 64-lowercase-hex old_identity:

- scan every embedded payload;
- permit that exact old identity only in supersession_entry records and its
  dedicated malformed_vector record;
- reject it in assurance_case, golden_value, value_schema, behavior_profile,
  source_owner_binding, module_allocation, import_edge, equality_matrix,
  remaining_seam, manifest, closeout, or any other current truth;
- report the complete scan count and zero violations.

This guard must detect the V5 leakage before repair and pass after repair.

REVISED DELIVERABLE

Attach exactly:

RW0_Post_Execution_Canonical_Audit_Package_V6.jsonl

Use the same canonical JSONL envelope and closed record-type ordering.

No V5 current identity replaced by this repair may survive in V6 current truth
outside supersession or a dedicated malformed vector.

MECHANICAL AND SEMANTIC VERIFICATION

Before success:

1. Repeat every V5 package mechanic check with duplicate-key rejection.
2. Reproduce every outer and embedded canonical JSON encoding.
3. Reproduce every payload length, raw hash, and domain-separated digest.
4. Reproduce dense indexes, unique IDs, record ordering, manifest, aggregate,
   closeout, and whole-file SHA-256 with two independent readers/hash tools.
5. Recheck all preserved V1-V5 repairs and accepted contracts.
6. Execute the current-source rank-15 cross-record guard above.
7. Execute the package-wide supersession guard above.
8. Validate all current goldens against their schemas and profiles.
9. Validate all current generated refs and self-digests.
10. Confirm V35-V37 remain absent from current schemas, goldens, allocations,
    and implementation scope.
11. Recheck repository baseline, worktree count, and cleanliness.
12. Confirm no repository file or Git state changed.

INLINE REPORT

Print a concise but complete report containing:

- attachment receipt for V5;
- baseline verification;
- disposition of V5-AUDIT-001 and V5-AUDIT-002;
- independently reproduced corrected graph, wrapper, operand-set, and relation
  digests;
- exact filename, size, SHA-256, logical records, final-newline posture,
  per-type counts, and content aggregate for V6;
- changed, new, and retired record IDs;
- exact V5-to-V6 supersession entries added;
- assurance and malformed-vector changes;
- rank-15 cross-record guard result;
- supersession scan population and zero-violation result;
- confirmation that all preserved contracts remain intact;
- confirmation that V6 is visibly attached;
- confirmation that no predetermined Downloads path was required;
- confirmation that no private path is offered as the deliverable;
- success token.

SUCCESS TOKEN

Return exactly:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V6_REPAIRED_READY_FOR_INDEPENDENT_AUDIT

only if:

- both findings are closed;
- all direct and transitive rank-15 identities are regenerated from current
  source;
- the supersession scan has zero forbidden occurrences;
- every package and source-grounding verification passes;
- V6 is visibly attached;
- repository state remains unchanged;
- no implementation prompt is issued.

Otherwise return:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V6_REPAIR_BLOCKED

and classify the blocker as exactly one of:

- fixed-input mismatch;
- fixed-input attachment unavailable;
- baseline mismatch;
- current-source reconstruction failure;
- transitive regeneration failure;
- semantic contradiction;
- supersession leakage;
- canonical verification failure;
- attachment mechanism unavailable.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
