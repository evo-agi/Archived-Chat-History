Objective

Repair the exact provenance-bound RW0 post-execution pure-owner V2 implementation candidate after the fresh independent re-audit returned BLOCK.

Repository

/Users/ds/Repositories/Governed Execution Coordinator

Engagement posture

This is a workspace-write REPAIR engagement in the existing implementation conversation.

- The parent is the sole repository writer.
- Do not spawn subagents.
- Do not perform or claim an independent audit.
- Do not stage, commit, push, create a PR, publish, contact a remote, install dependencies, run migrations, invoke live services, or inspect/modify supporting repositories.
- Preserve the exact accepted six-module, private, pure, no-I/O, migration-free architecture and the exact twenty-path repository ceiling.
- Repair implementation and permanent tests only within that frozen boundary; do not reopen or regenerate the accepted V11 owner-contract package.
- Treat the V2 re-audit report as blocking evidence to correct, not as permission to widen scope.

Required final success token

RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIRED_V3_VALIDATED_PROVENANCE_READY_FOR_REAUDIT

Required blocking token

RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIR_V3_BLOCKED

Required provenance-mismatch token

RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIR_V3_PROVENANCE_MISMATCH

Exact fixed repair inputs

1. RW0_Post_Execution_Pure_Owner_Implementation_V2_Independent_Reaudit_Report.md
   - size: 28,054 bytes
   - SHA-256: 665d1644070b290a7818660bab21608aeae3a09b7b13df9a1fde93a567931120
   - logical lines: 497
   - final newline: absent
   - primary verdict: BLOCK

2. RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V2.json
   - size: 4,377 bytes
   - SHA-256: 7ada36bd287de85823926090e07e8e33ca1fe038963984c8eed0f423329f1284
   - canonical compact sorted-key JSON
   - final newline: present
   - recipe ID: governed-execution.audit-patch-manifest.v1
   - baseline HEAD: a3ff0b7f4f0c2378c2962e24612d605489b51638
   - file count: 20
   - tracked textual diff SHA-256: 897e95f470b55690abb2c25bd2b1d0b760ad9e6b0b3541f4ad4f5012cd0f022f

3. RW0_Post_Execution_Pure_Owner_Implementation_Report_V2.md
   - size: 21,217 bytes
   - SHA-256: ace2c92c66eea311820702cf844a8f802a8a78c82c4c208e37bc42133094e878
   - logical lines: 427
   - final newline: present
   - historical implementation report only; its claims of complete V22/V24 grounding, exact V03/V11 profile grammar, complete malformed-vector causality, and full finding closure were rejected by the re-audit

Previously supplied governing inputs remain fixed and must already be available in this implementation conversation:

- Coordinator_RW0_Post_Execution_Pure_Owner_Implementation_Prompt.txt
  SHA-256 2ff652b1aabb65bdb9507a6d6954c139b799f4520591ecc0726b29e5d2888650
- Coordinator_RW0_Post_Execution_Pure_Owner_Implementation_Repair_Prompt_V2.txt
  SHA-256 394018c64671b4aeaef6e7b5b5feb9c7e9ee8c4d08425046304eb40cba12b3b0
- RW0_Post_Execution_Pure_Owner_Implementation_Boundary_Freeze_V1.md
  SHA-256 02b932abdfdb0085886000c19cdbcc4e9e72ebb951a5030056a621e181d33d55
- RW0_Post_Execution_Pure_Owner_Implementation_Boundary_Manifest_V1.json
  SHA-256 927646d30430d5b6b3acacdc2f4b752721c3ed7ae62673962542120cfce0c386
- RW0_Post_Execution_Pure_Owner_Implementation_Boundary_Review_Overlay_V1.json
  SHA-256 ba8202629aebd895c7a4bae7ad147a2d68e9d368e27ede80a965b46809b32f92
- RW0_Post_Execution_Canonical_Audit_Package_V11.jsonl
  SHA-256 e26a739dc303a555aa951e23ccd84b3583377319a82b5fcd78f99397da894afe
- RW0_Post_Execution_Canonical_Audit_Package_V11_Independent_Audit_Report.txt
  SHA-256 b5b3c1e9a426a6ce25c5a5bbb622d4a4838459750ebbe457fb9e6f9816f82548
- governed_execution_audit_patch_manifest_v1.py
  size 3,945 bytes
  SHA-256 db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
  recipe ID governed-execution.audit-patch-manifest.v1
- RW0_Post_Execution_Pure_Owner_Implementation_Repair_Opening_Evidence_V2.json
  size 9,738 bytes
  SHA-256 adbe22edebc6e8e7beac735ad36cf1a9fb8535ba1c9312e8534f645ca87ec786
  final newline present

If any required input is unavailable or differs, stop. Do not search for or substitute a same-named file.

Authority and seam classification

Current merged authority

- The fixed Coordinator repository at HEAD a3ff0b7f4f0c2378c2962e24612d605489b51638 remains current merged truth.
- Existing current owners, migration 0003, the private C1 readers and matcher, migrations 0001-0004, public surfaces, StateStore, WriterSession, and the fifteen-kind C1 inventory remain protected and unchanged.

Accepted proposed contract

- The exact V11 package and accepted audit define the proposed private pure-owner semantics.
- The freeze, machine manifest, and review overlay define the six-module allocation, allowed import graph, touched paths, validation obligations, and non-authorizations.

V2 patch findings to repair

- RW0-AUD-V2-001, High: V22 accepts an internally inconsistent but re-signed Section 41 owner family that the current exact-family matcher rejects.
- RW0-AUD-V2-002, High: 52 of 93 malformed controls are synthetic metadata-envelope self-raises rather than causal executions of production constructors/actions/boundaries/equalities/seams.
- RW0-AUD-V2-003, Medium: V03/V11 omit complete role-specific source-profile, source-binding, and direct-C1 branch grammar.
- RW0-AUD-V2-004, Medium: V24 does not bind the exact decision-currentness profile pair.
- RW0-AUD-V2-005, Medium: the seven docs and V2 report overstate implementation closure.

Already closed and not to regress

- Exact V2 provenance and twenty-path boundary.
- Common exact built-in grammar: mapping order, exact list type, bool rejection, safe-reference bounds, digest widths, timestamps, and V16 precedence.
- Runtime bytecode inventory guard and its seven negative controls.
- Opening-evidence process posture.
- V25-V34 behavior except where its V22/V24 upstream basis is invalid.
- Six-module import graph, no production caller, no I/O, no migration, no public/runtime/durable-state widening.
- Security, privacy, capsule-safe projection, and artifact hygiene.

No architecture reset

- The six-module allocation remains accepted.
- The twenty-path repository ceiling remains accepted.
- The private/no-I/O/migration-free/non-public boundary remains accepted.
- No new V-number, schema, behavior profile, module, migration, durable owner, public caller, runtime path, or authority surface is authorized.

Pre-edit receipt and exact V2 starting-candidate gate

Before any repository edit:

1. Print an attachment receipt for the three fixed repair inputs, including observed client-exposed path, size, SHA-256, logical units, and final-newline posture.
2. Verify the exact provenance recipe source bytes and SHA-256.
3. Verify repository root exactly:
   /Users/ds/Repositories/Governed Execution Coordinator
4. Verify:
   - branch trunk_dev
   - HEAD a3ff0b7f4f0c2378c2962e24612d605489b51638
   - tree d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0
   - sole parent 047563de5a443b0f8323401c92979ae2e444d2ed
   - subject feat: implement RW0-C1 durable evidence (#7)
   - upstream origin/trunk_dev
   - ahead/behind 0/0
   - one worktree
   - no staged or unmerged path
5. Run the exact provenance recipe twice serially against the live working tree.
6. Require both outputs to be byte-identical to each other and to the fixed V2 provenance manifest in every field:
   - repository identity
   - exact twenty paths
   - tracked/untracked classification
   - regular-file type
   - mode
   - size
   - per-file SHA-256
   - textual diff SHA-256
   - canonical manifest bytes and SHA-256
7. Stop with RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIR_V3_PROVENANCE_MISMATCH on any discrepancy. Do not inspect or repair correctness after a mismatch.
8. Before edits, create a safe client-visible opening evidence artifact outside the repository:
   RW0_Post_Execution_Pure_Owner_Implementation_Repair_Opening_Evidence_V3.json

The V3 opening evidence must be canonical compact sorted-key JSON with final LF, contain no absolute operator paths or secrets, and bind:

- exact V2 provenance manifest filename, size, SHA-256, textual diff digest, and file count
- branch, HEAD, tree, parent, subject, upstream, divergence, and worktree count
- zero staged/unmerged posture
- exact provenance recipe receipt
- safe repository-relative inventory of every pre-existing ignored cache/bytecode member: path, type, mode, size, SHA-256
- normalized cache-inventory aggregate
- explicit evidence-only/non-authority statement

Expose the V3 opening evidence as a client-visible attachment at closeout. Do not store it in the repository.

Exact repository touched-path ceiling

No repository path may be created, deleted, renamed, or modified outside these twenty paths.

Source modules

1. src/ge_nwp_coordinator/_post_execution_evidence_values.py
2. src/ge_nwp_coordinator/_post_execution_policy_values.py
3. src/ge_nwp_coordinator/_finite_backlog_risk_source_adapter.py
4. src/ge_nwp_coordinator/_section41_post_execution_proposal_family_projection.py
5. src/ge_nwp_coordinator/_section41_post_execution_role_resolution.py
6. src/ge_nwp_coordinator/_rw0_c_decision_input_values.py

Tranche tests

7. tests/test_post_execution_pure_owner_values.py
8. tests/test_post_execution_pure_owner_vectors.py
9. tests/test_post_execution_pure_owner_relations.py
10. tests/test_post_execution_pure_owner_boundaries.py

Existing guard tests

11. tests/test_c2a_nonimplementation.py
12. tests/test_runtime_non_authority.py
13. tests/test_rw0_b1_boundaries.py

Governing/status documentation

14. .docs/autonomous-software-development-operating-model.md
15. .docs/c2b-durable-development-state.md
16. .docs/rw0-b1-pure-phase-values.md
17. .docs/rw0-remote-worker-contact-phase-entry.md
18. .docs/architecture.md
19. .docs/c2a1-pure-semantic-values.md
20. .docs/rw0-c1-durable-evidence.md

Stop if repair requires any twenty-first repository path.

Protected surfaces

Do not modify or regenerate:

- any migration or migration catalog
- any SQLite reader, writer, row owner, transaction/controller, recovery, or capability implementation
- src/ge_nwp_coordinator/__init__.py
- StateStore or WriterSession surfaces
- current C1 source, row, reader, matcher, and fifteen-kind inventory
- package-root exports
- CLI, service, scheduler, queue, daemon, worker, provider/model, process, filesystem, network, environment, or clock behavior
- supporting repositories
- accepted V11 package/audit, freeze artifacts, review overlay, prior implementation/audit evidence, or provenance recipe

No new dependency may be installed.

Repair strategy and mandatory order

Repair in dependency order. Do not weaken accepted schemas, profile pairs, owner equalities, error precedence, finite inventory, or test obligations merely to obtain a pass.

Part A — Complete the exact V03/V11 nine-role branch table

Governing profile pairs remain exact:

- V03 PostExecutionSemanticReviewRoleEntryV2:
  post-execution-semantic-review-input.v2
  d4693a9cd9beb9d58edf2e492176182b69b5ed2fa8da34419709e2392333e54e
- V11 PostExecutionRoleSupplyV2:
  post-execution-evidence-supply.v2
  59a4a741fb394767f341dc57c514bb3e022737196905c7bed1f05295376d3a02

For both V03 and V11, encode and enforce the complete closed role table before parent identity acceptance:

- rank 5 candidate_capsule, ordinal 0
  - typed schema: governed-execution.nwp-candidate-capsule-manifest.v1
  - source posture: transient_private_resupply
  - model-input posture: private_exact_canonical_value
  - direct C1: all null
  - source profile: all null
  - source binding: all null
- rank 6 worker_result, ordinal 0
  - typed schema: governed-execution.nwp-rw0-c1-wire-process-result-classification-binding.v1
  - source posture: c1_admitted_exact_value
  - model-input posture: nonprivate_exact_canonical_value
  - direct C1 kind/rank: wire_process_result_classification_binding / 14, with exact current membership pair
  - source profile pair: rw0-wire-nwpf-v1 / 470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
  - source binding schema: governed-execution.nwp-rw0-c1-relation-binding.v1, with exact accepted current relation pair
- rank 7 validation_result, ordinal 0
  - typed schema: governed-execution.nwp-validation-disposition.v1
  - source posture: transient_owner_resupply
  - model-input posture: nonprivate_exact_canonical_value
  - direct C1: all null
  - source profile: exact validation-disposition.v1 pair
  - source binding: exact governed-execution.nwp-worker-observation.v1 validator/validation_completed triple
- rank 8 independent_review, ordinal 0
  - typed schema: governed-execution.nwp-independent-review-disposition.v1
  - source posture: transient_owner_resupply
  - model-input posture: nonprivate_exact_canonical_value
  - direct C1: all null
  - source profile: exact independent-review-disposition.v1 pair
  - source binding: exact governed-execution.nwp-worker-observation.v1 independent_reviewer/independent_review_completed triple
- rank 9 standing_policy, ordinal 0
  - typed schema: governed-execution.nwp-post-execution-standing-policy-branch-matrix.v1
  - source posture: transient_owner_resupply
  - model-input posture: nonprivate_exact_canonical_value
  - direct C1: all null
  - source profile: exact post-execution-standing-policy-matrix.v1 pair
  - source binding schema: governed-execution.nwp-post-execution-standing-policy-source-attestation.v1, with exact accepted source pair
- rank 10 risk_lane, ordinal 0
  - typed schema: governed-execution.nwp-post-execution-risk-lane-branch-matrix.v1
  - source posture: transient_owner_resupply
  - model-input posture: nonprivate_exact_canonical_value
  - direct C1: all null
  - source profile: exact generic risk-source profile pair
  - source binding schema: governed-execution.nwp-post-execution-risk-source-binding.v1, with exact accepted binding pair
- rank 11 authority_currentness_attestation, ordinal 0
  - typed schema: governed-execution.nwp-rw0-authority-verification-observation.v1
  - source posture: c1_admitted_exact_value
  - model-input posture: nonprivate_exact_canonical_value
  - direct C1 kind/rank: authority_verification_observation / 1, with exact current membership pair
  - source profile: all null
  - source binding: all null
- rank 12 global_stop, ordinal 0
  - typed schema: governed-execution.nwp-post-execution-global-stop-snapshot.v1
  - source posture: transient_owner_resupply
  - model-input posture: nonprivate_exact_canonical_value
  - direct C1: all null
  - source profile: exact post-execution-global-stop.v1 pair
  - source binding schema: governed-execution.nwp-global-stop.v1, with exact supplied stop-state pair
- rank 13 effect_ceiling, ordinal 0
  - typed schema: governed-execution.nwp-post-execution-source-effect-ceiling-evidence.v1
  - source posture: transient_owner_resupply
  - model-input posture: nonprivate_exact_canonical_value
  - direct C1: all null
  - source profile: exact post-execution-source-effect-ceiling.v1 pair
  - source binding schema: governed-execution.nwp-effect-fence.v1, with exact supplied fence pair

V11 additionally must enforce, by role:

- exact typed canonical value and typed ref/digest equality
- exact source-profile canonical value when non-null, with all three profile coordinates jointly null or jointly exact
- exact source-binding canonical value when non-null, with all four binding coordinates jointly null or jointly exact
- exact support-set and support-value presence, identity, cardinality, and equality where the role profile requires support; all support fields jointly null/zero where it does not
- no mixed null/non-null branch coordinates

Do not freeze only symbolic labels such as wire_profile_pair. Validate the exact accepted pair and owner/value relation represented by the V11 goldens and current owners. 'Exact' does not mean hard-code a golden ref where the contract permits an owner-supplied or generated ref; it means reconstruct the supplied typed owner, verify its ref/digest, and require every dependent coordinate to equal that owner. Hard-code only profile/schema constants that the accepted contract makes literal.

Permanent V3 hostile controls must include, at minimum:

1. V03 rank-5 candidate capsule with a non-null, well-formed source-profile pair -> reject before parent identity, expected first class invalid_profile_pair.
2. V03 rank-6 worker result with all direct-C1 coordinates erased -> reject before parent identity, expected first class source_owner_mismatch.
3. V11 rank-6 worker result with a distinct well-formed source-profile pair and resealed parent -> reject before parent identity, expected first class invalid_profile_pair.

Add exhaustive parameterized one-branch mutations across all nine roles for role/rank/ordinal, typed schema, source posture, model-input posture, direct-C1 branch, source-profile branch, source-binding branch, and V11 support branch. Every case must invoke the actual production constructor/action and prove byte-exact restoration to its accepted positive.

Part B — Make V22 matcher-equivalent to the complete current Section 41 owner family

Keep the accepted V22 profile pair exact:

- section41-post-execution-proposal-family-projection.v2
- 76b0fdedd0fbbd3c6400be3f8e22eacdf585eb28280d12f38834d513b8cdb411

V22 must accept only after pure reconstruction proves the same family coherence required by the protected current exact-family matcher. Do not import a new runtime/SQLite owner or widen the frozen semantic import graph. Reproduce the required pure equalities from the supplied typed current-owner values and compare the result against the protected matcher in permanent tests.

Before projection identity acceptance, enforce all of the following:

1. Exact source, artifact, proposal, and nine physical evidence-row constructors/self-digests.
2. Exact private-reader tuple shape, ordering, roles, ranks, ordinals, locators, and zero-or-nine posture.
3. Exact source/artifact/proposal/evidence locator-to-row binding; a locator must not merely be well formed.
4. Exact chronology:
   - input_context_constructed_at <= source_invocation_started_at
   - source_invocation_started_at <= source_invocation_completed_at
   - source_invocation_completed_at <= artifact_validated_at
   - artifact_validated_at <= evidence_bound_at
   - evidence_bound_at <= proposal_created_at
   - projection_evaluated_at = proposal_created_at
5. Exact cross-row equalities:
   - source and proposal model-contract pair
   - source and proposal model-configuration pair
   - source and proposal input-context schema/ref/digest
   - input-context nested lineage schema/ref/digest
   - source, artifact, and proposal artifact schema/ref/digest
   - artifact and proposal safe-projection schema/digest
   - proposal source-invocation ref/digest
   - proposal and rows evidence-set ref/digest
   - rows and T1 input-role schema/ref/digest
   - common evidence_bound_at across all nine rows
6. Exact evidence-set identity and twelve owner locators.
7. Exact owner-family graph, rank-15 wrapper, operand set, semantic relation, relation row, relation set, admission graph, membership, and admitted_by_mutation_ref.
8. Exact current source-owner identity policy for each role, including source profiles and source bindings.
9. Existing exact-family matcher equivalence: every accepted V22 family must make the protected current matcher return true when presented with the corresponding current-owner family; every family that makes the current matcher false must be rejected by V22.
10. Projection output must be independently derived; a caller-supplied projection remains only an expected-output assertion.

Permanent V3 hostile counterexample:

- Start from the accepted positive current family.
- Replace only the proposal model-contract identity with a distinct well-formed pair while preserving the source invocation model-contract identity.
- Recompute the proposal self-digest, all dependent locators, evidence-set/owner-family/rank-15/relation/admission/membership identities, and the candidate V22 projection identity so that every local hash remains internally consistent.
- Prove the protected current exact-family matcher returns false.
- Require V22 to reject before projection ref/digest acceptance. Classify the first failure using the existing accepted local vocabulary: relation_mismatch for a cross-row equality failure unless the already-implemented/frozen V22 owner-mismatch mapping unambiguously requires source_owner_mismatch. Do not invent a new reason or broaden the vocabulary; record and justify the exact chosen token in the V3 report.
- Restore the exact accepted pair and prove the positive family and projection recover byte-exactly.

Also retain the existing artifact-before-source chronology negative and all current rank-15 positive/negative controls.

Part C — Bind V24 to exact role semantics and decision-currentness profile

Keep the accepted V24 profile pair exact:

- section41-post-execution-role-resolution.v3
- 008a8468c608d9db41fe28f19bc582cc9598f58c9b3009e2d79322fd6c22cebc

The exact required decision-currentness profile pair is:

- rw0-c-proposal-evidence-currentness.v1
- 88b347a069c92a5804ba53dad4f39a9d7ba6a36413fa38812f81e964a8902e9b

For every one of the nine V24 role resolutions:

- enforce the complete V03/V11 role branch table
- enforce exact projection profile/ref/digest and input-context profile/ref/digest
- enforce exact role/rank/ordinal, typed schema/ref/digest, model projection coordinates, source profile/binding coordinates, direct-C1 coordinates, evidence locator, evidence-row digest, relation source coordinates, and exact resupply equality
- require decision_currentness_profile_ref and decision_currentness_profile_digest to equal the frozen pair above
- require the complete nine-role family before resolving exactly one requested role
- derive the output relation; do not trust a supplied relation as authority

Permanent V3 hostile counterexample:

- Start from the complete accepted nine-role family.
- Replace and reseal the decision-currentness pair in every role with:
  - rw0-c-proposal-evidence-currentness.fabricated
  - ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
- Recompute all affected V24 relation refs/digests so the family is internally hash-consistent.
- Require the V24 value grammar and action to reject before final relation identity with invalid_profile_pair.
- Restore the exact frozen pair and prove all nine positives recover byte-exactly.

Preserve the existing rank-5 role-substitution negative and exact resupply/privacy constraints.

Part D — Replace synthetic malformed metadata self-raises with causal executable controls

At the opening V2 candidate, enumerate the exact 52 malformed record IDs that dispatch through _execute_metadata_mutation. Include that complete opening inventory in the V3 report.

The repaired permanent tests must satisfy all of the following:

1. No malformed control may pass by mutating only a synthetic predicate_value envelope and then raising _FrozenVectorViolation or another test-authored exception directly.
2. Remove the hard-coded expected-reason lookup as a mechanism that creates the failure being asserted.
3. Every one of the 93 malformed record IDs must map to an actual executable responsibility:
   - production value constructor/from_mapping validation
   - production pure action/evaluator
   - current-owner constructor/reader/matcher reconstruction
   - concrete equality check over typed positive/negative values
   - import/path/public/runtime boundary scanner
   - finite paging/closure/currentness behavior
   - explicit preserved-seam absence/non-authorization assertion
4. Apply the record’s exact one-predicate mutation to the real test-local base record or actual boundary representation.
5. Where the accepted control is re-signed, recompute only the identities required to keep unrelated integrity checks valid, so the intended semantic predicate is the first failure.
6. Where the accepted control intentionally preserves stale identity, do not regenerate it.
7. Invoke the actual production or protected current-owner path and capture its real first rejection.
8. Assert the exact accepted failure class from that execution; do not generate the reason inside the test harness.
9. Restore the mutated predicate and require byte-exact restoration when the accepted assurance says restoration is exact.
10. For source/module/import/non-widening controls, mutate a concrete test-local module graph, AST/source inventory, path inventory, or owner binding and run the actual boundary checker; do not treat metadata comparison alone as causal execution.
11. For remaining seams, assert the exact absence/future/non-authorizing contract against concrete source/path/allocation inventories.
12. Preserve test independence: repository tests must not load V11, audit reports, freeze/manifest/overlay files, implementation reports, opening evidence, or provenance manifests at runtime.

The V3 report must include a complete 93-row causality ledger with, for each malformed record ID:

- positive/base fixture ID
- exact one-predicate mutation
- real constructor/action/boundary/equality/seam function invoked
- whether identities are regenerated or intentionally stale
- observed first failure class
- restoration result

A count-only statement is insufficient.

Add permanent regressions for all newly discovered V2 hostile cases:

- V03 rank-5 non-null source profile
- V03 rank-6 erased direct C1
- V11 rank-6 wrong source profile
- V22 source/proposal model-contract mismatch with fully recomputed downstream identities and current matcher false
- V24 complete-family fabricated decision-currentness pair

The V22 negative must be present in both the ordinary relation/source-grounding suite and the malformed/assurance causality registry so a future synthetic registry cannot hide it.

Part E — Preserve already accepted V2 behavior

Do not regress:

- V25 exact 256/257 transcript, cursor progress, one capability epoch, 65,536 maximum, and 65,537 rejection
- V27/V29 five-source currentness and exact mapping
- V31/V32/V33 source-bound precedence
- V34 recommendation consistency
- active-stop deny/deny/deny/permit/permit behavior
- common exact grammar and V9R001/V11R001 precedence
- runtime bytecode guard
- 16 allowed and 15 forbidden import responsibilities
- six-module/no-caller/no-I/O boundary
- security/privacy and safe capsule projection
- exact 20-path and protected-path ceilings

Part F — Reconcile documentation only after code and tests are truthful

Inspect all seven authorized docs after Parts A-E pass.

- Preserve protected prefixes, Sections 1-41, H2 order, C1 fifteen-kind ownership, B1 registry/sole-consumer claims, and all explicit nonclaims.
- If the existing “implemented private-pure tranche” wording becomes fully true after the repair, it may remain byte-identical, but the V3 report must explain why each audited overclaim is now supported.
- Otherwise, edit only the bounded successor/status statements necessary to match actual implementation.
- Do not edit historical V1/V2 external reports; they remain evidence of blocked candidates.
- Do not claim runtime, durable decision, completeness authority, external authenticity, permission, migration, public export, production caller, C2B progression, terminal, RW0-D/E, or Execution Substrate behavior.

Part G — V3 report and process evidence

Produce a successor implementation report outside the repository:

RW0_Post_Execution_Pure_Owner_Implementation_Report_V3.md

It must:

- state that V2 was correctly blocked by the independent re-audit
- record exact receipts for the V2 audit report, V2 manifest, and V2 report
- bind the exact V2 starting provenance before edits
- identify the V3 opening-evidence artifact
- disposition RW0-AUD-V2-001 through RW0-AUD-V2-005 separately
- preserve and report the already closed V2 surfaces
- include the complete opening set of 52 synthetic malformed controls and the final 93-row causality ledger
- include every targeted/development/formal command, any failure, bounded repair, rerun, and exact candidate bytes against which it ran
- state whether each of the seven docs changed or remained byte-identical and why its status claim is truthful
- report exact V2-to-V3 per-file byte changes
- avoid claiming independent audit or commit authorization
- list assumptions, remaining seams, skipped/unavailable evidence, and uninspected surfaces

Required V3 deliverables outside the repository

1. RW0_Post_Execution_Pure_Owner_Implementation_Repair_Opening_Evidence_V3.json
2. RW0_Post_Execution_Pure_Owner_Implementation_Report_V3.md
3. RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V3.json

Expose all three through client-visible attachments. A private path is not a substitute.

Development and validation posture

During repair:

- Bounded targeted tests may run as needed with PYTHONDONTWRITEBYTECODE=1 and pytest cache disabled.
- Do not alter, move, delete, or rewrite the opening live cache inventory.
- Remove only artifacts created by V3 and proven absent from V3 opening evidence.
- Do not run independent audit probes in lieu of permanent repository tests; every corrected hostile case must be permanent.

Before formal validation, require focused permanent-test runs covering:

- exhaustive V03/V11 role-branch mutations
- V22 current-matcher-equivalence positive and hostile model-contract mismatch
- V24 exact currentness-pair positive and fabricated-pair negative
- all 93 malformed controls through actual executable paths
- zero use of a synthetic self-raise path for semantic credit

Formal final validation must use a private external local clone so the live repository remains byte-stable and its opening ignored cache is untouched.

External validation-clone requirements

1. Create a private mode-0700 root outside the repository.
2. Use clone-time umask 022 inside that root.
3. Construct a local --no-local, single-branch, no-tags clone from the exact committed HEAD only, without fetch or network contact and without hard-link ambiguity.
4. Overlay exactly the live candidate’s twenty manifest-bound files.
5. Verify every overlaid file’s type, mode, size, and SHA-256.
6. Run the exact provenance recipe twice in the clone and require equality to the final live V3 manifest before tests.
7. Run V02-V06 serially, with no concurrent edit or cleanup:

V02 targeted tranche and guard tests

env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_post_execution_pure_owner_values.py tests/test_post_execution_pure_owner_vectors.py tests/test_post_execution_pure_owner_relations.py tests/test_post_execution_pure_owner_boundaries.py tests/test_c2a_nonimplementation.py tests/test_runtime_non_authority.py tests/test_rw0_b1_boundaries.py

V03 current pure dependencies

env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_rw0_b1_phase_values.py tests/test_rw0_b1_vectors.py tests/test_rw0_b1_relations.py tests/test_worker_execution_semantic_values.py tests/test_worker_execution_semantic_vectors.py tests/test_worker_execution_semantic_relations.py tests/test_worker_execution_semantic_boundaries.py tests/test_finite_backlog.py tests/test_global_stop.py

V04 Section 41/C1 regression

env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_section41_cognitive_proposal_row_values.py tests/test_section41_cognitive_proposal_semantic_values.py tests/test_section41_pre_execution_plan_disposition_contracts.py tests/test_section41_pre_execution_plan_disposition_recovery.py tests/test_section41_private_atomic_pre_execution_plan_disposition.py tests/test_section41_private_pre_execution_plan_disposition_delegation.py tests/test_rw0_c1_mutation_contracts.py tests/test_rw0_c1_private_atomic_persistence.py tests/test_rw0_c1_private_readers.py tests/test_rw0_c1_reader_contracts.py tests/test_rw0_c1_recovery.py tests/test_rw0_c1_row_values.py tests/test_rw0_c1_semantic_values.py tests/test_rw0_c1_writer_session_delegation.py tests/test_remote_worker_pre_execution_planning_contract.py::test_f1_post_execution_common_proposal_needs_no_preexecution_context_row tests/test_remote_worker_pre_execution_planning_contract.py::test_s41_post_execution_evidence_is_exactly_zero_or_complete tests/test_remote_worker_pre_execution_planning_contract.py::test_s41_post_execution_evidence_rejects_every_noncanonical_member tests/test_remote_worker_pre_execution_planning_contract.py::test_repaired_nine_table_ddl_and_both_golden_families_are_representable tests/test_remote_worker_pre_execution_planning_contract.py::test_migration_0003_owner_freezes_exact_representability_without_0002_rebuild

V05 catalog/docs/public boundaries

env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_sqlite_b1_migrations.py tests/test_sqlite_c2b1_migration_framework.py tests/test_sqlite_c2b2_migration_0002.py tests/test_sqlite_section41_migration_0003.py tests/test_sqlite_rw0_c1_migration_0004.py tests/test_autonomous_software_development_operating_model.py tests/test_architecture_contracts.py tests/test_rw0_remote_contact_phase_entry_contract.py tests/test_software_development_progression_boundary.py tests/test_rw0_b2_wire_boundaries.py tests/test_rw0_b2_capability_boundaries.py

V06 full repository

env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q

8. After V06 run:
   - git diff --check
   - exact changed/untracked/staged/unmerged/status inventory
   - artifact scan for __pycache__, .pytest_cache, .pyc, .pyo, SQLite DB/journal/WAL/SHM, locks, build output, egg-info, archives, OS metadata, symlinks, or unsupported types
   - the exact provenance recipe twice
9. Require post-validation clone provenance to equal the final live V3 manifest exactly.
10. Remove the external validation root from its working location. If policy requires moving it to system Trash instead of irreversible deletion, report the recoverable residue truthfully and do not claim host deletion.

Live final provenance and hygiene

After code, tests, docs, and clone validation are final:

1. Verify the live repository still has exactly the same twenty paths and no staged/unmerged path.
2. Verify every protected/unlisted path remains unchanged.
3. Verify the live ignored-cache inventory equals V3 opening evidence byte-for-byte and has no addition, deletion, or change.
4. Run the exact provenance recipe twice serially in the live repository.
5. Require byte-identical outputs.
6. Save the canonical output as:
   RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V3.json
7. Record:
   - recipe ID and source SHA-256
   - new tracked textual diff SHA-256
   - new canonical manifest SHA-256 and size
   - exact file count
   - exact branch/HEAD/upstream
8. Expose the V3 manifest as a client-visible attachment.
9. Do not stage, commit, push, publish, or audit.

Stop conditions

Stop with RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIR_V3_BLOCKED rather than widening if:

- starting provenance does not match V2
- an input differs or is unavailable
- a twenty-first repository path is required
- a seventh source module is required
- a new V-number/schema/profile/accepted semantic choice is required
- matcher-equivalent V22 behavior cannot be implemented without importing or modifying a protected runtime/SQLite owner
- any malformed control cannot be made causal without changing its accepted meaning
- a migration, SQLite/current-owner edit, public export, production caller, runtime I/O, durable write, or cross-repository effect is required
- the accepted six-module import graph must widen or reverse
- an accepted V11 responsibility contradicts another accepted responsibility
- external-clone validation cannot bind the exact live candidate bytes
- any high- or medium-severity correctness, authority, test, documentation, security, privacy, or artifact uncertainty remains
- final provenance is unstable

Required final response structure

1. Primary verdict and exact token.
2. Fixed-input and exact V2 starting-provenance receipt.
3. V3 opening evidence identity and attachment link.
4. Exact repair disposition for RW0-AUD-V2-001 through RW0-AUD-V2-005.
5. Exact twenty-path final inventory and zero extra/missing paths.
6. V2-to-V3 changed/unchanged file inventory with sizes and SHA-256 values.
7. V03/V11 complete role-branch enforcement summary and hostile-case results.
8. V22 current-matcher-equivalence summary, positive current family, hostile inconsistent family, and first failure class.
9. V24 exact decision-currentness-pair summary and fabricated-pair negative.
10. Complete malformed-control causality summary:
    - opening synthetic count and exact ID list
    - final 93-row ledger
    - zero synthetic self-raises receiving semantic credit
11. Preserved V25-V34, runtime guard, import, privacy, and no-authority results.
12. Documentation reconciliation by all seven paths.
13. Focused permanent-test results.
14. Exact V02-V06 commands and results from the external clone.
15. Clone start/end provenance equality, artifact scan, and cleanup classification.
16. Live opening/final cache equality.
17. Final V3 provenance identity and attachment link.
18. V3 implementation report identity and attachment link.
19. Assumptions, unresolved seams, skipped validation, and inspection limits.
20. Explicit non-actions.

Required non-actions in the final response

INDEPENDENT_AUDIT_NOT_PERFORMED
MIGRATION_0005_NOT_CREATED
SQLITE_RUNTIME_NOT_WIDENED
PUBLIC_EXPORT_NOT_CREATED
PRODUCTION_CALLER_NOT_CREATED
DURABLE_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
SUPPORTING_REPOSITORIES_NOT_MODIFIED

Success means only that a new exact V3 repair candidate is validated and provenance-bound for another fresh independent read-only audit. It does not authorize a commit gate or any runtime/durable/publication effect.
