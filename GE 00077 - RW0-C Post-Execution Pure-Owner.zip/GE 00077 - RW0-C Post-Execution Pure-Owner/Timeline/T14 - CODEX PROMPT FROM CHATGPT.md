COORDINATOR RW0 POST-EXECUTION CANONICAL PACKAGE V10
CONTENT-AGGREGATE REPAIR

ROLE

You are the package-generation and repair owner for one narrow deterministic
repair. You are not the independent auditor and you are not authorized to
implement repository behavior.

OBJECTIVE

Produce one new immutable package:

RW0_Post_Execution_Canonical_Audit_Package_V10.jsonl

from the attached V9 fixed input.

V9's semantic V16 repair is outside this repair scope and must remain byte-for-
byte unchanged. The sole defect to repair is package-envelope reconciliation:
V9's manifest and closeout both claim a content aggregate that does not equal
the aggregate computed from V9's own ordered content record IDs and payload
hashes.

This is a package-mechanics repair only. It is not an architecture reset,
semantic refreeze, implementation tranche, migration, or authority change.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch or remote contact is authorized.

If any baseline property differs, stop with:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V10_BASELINE_MISMATCH

POSTURE AND AUTHORITY

This engagement may:

- inspect the repository read-only to verify the fixed baseline;
- read the attached V9 package;
- create disposable scripts and output under a fresh private temporary root
  outside the repository;
- generate and attach one V10 JSONL package;
- run deterministic package-verification tools against V9 and V10.

This engagement may not:

- edit, create, delete, format, or clean any repository path;
- run repository tests;
- run migrations;
- access or mutate a live database;
- install dependencies;
- fetch or contact remotes;
- invoke a repository worker, runtime model, provider, or external service;
- stage, commit, push, create a pull request, merge, or deploy;
- implement post-execution owners, decisions, progression, terminal behavior,
  RW0-D/E, or Execution Substrate behavior;
- repair or reinterpret any substantive V9 content record;
- introduce, retire, reorder, or reindex any content record;
- add any supersession entry.

Use one parent process. Do not delegate this narrow repair.

FIXED INPUT ATTACHMENT

The sole fixed input is the attachment named:

RW0_Post_Execution_Canonical_Audit_Package_V9.jsonl

Do not search the filesystem for a same-named substitute. Do not require a
predetermined Downloads path. Use the client-exposed attachment path supplied
by the current session.

Before substantive work, print an attachment receipt containing:

- observed filename;
- client-exposed runtime path;
- size;
- SHA-256;
- logical record count;
- final-newline posture.

Require exactly:

filename:
RW0_Post_Execution_Canonical_Audit_Package_V9.jsonl

size:
2613829 bytes

whole-file SHA-256:
38c4df3af439a0bae68879ce19a09f8c53db35ea53fb43f1d508c9854b488366

logical records:
1681

final newline:
absent

first record:
package.manifest.v1

last content record:
remaining-seam.S008

final record:
package.closeout.v1

claimed V9 content aggregate in both envelope records:
9dcb2128867325391ba7cff81bd29dbb1e2ecbd4be79dbded620bce515db7eac

per-type counts:

package_manifest: 1
source_owner_binding: 23
value_schema: 44
behavior_profile: 28
golden_value: 199
malformed_vector: 92
module_allocation: 44
import_edge: 31
equality_matrix: 36
assurance_case: 124
supersession_entry: 1050
remaining_seam: 8
package_closeout: 1

If the attachment is unavailable, stop with:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V10_FIXED_INPUT_ATTACHMENT_UNAVAILABLE

If any fixed-input identity property differs, stop with:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V10_FIXED_INPUT_MISMATCH

DEFECT TO REPRODUCE BEFORE REPAIR

Parse V9 with duplicate-key rejection.

Let the ordered content records be all records after package.manifest.v1 and
before package.closeout.v1, in record_index order. For V9 this is exactly
1,679 records with record indexes 1 through 1,679.

Construct the aggregate preimage exactly as:

UTF-8(record_id)
+ one TAB byte 0x09
+ ASCII(payload_raw_sha256)

for each ordered content record, joined by one LF byte 0x0A, with no trailing
LF after the final entry.

Equivalently:

b"\n".join(
    record["record_id"].encode("utf-8")
    + b"\t"
    + record["payload_raw_sha256"].encode("ascii")
    for record in ordered_content_records
)

The exact V9 aggregate preimage must be:

byte length:
180486

SHA-256:
9302da29abad2bbdd78dcae33b1d499236d046cb195184caf8248b60e0b63895

This does not equal V9's claimed value:

9dcb2128867325391ba7cff81bd29dbb1e2ecbd4be79dbded620bce515db7eac

Reproduce the corrected aggregate with two independent implementations before
writing V10. At least one implementation must derive the preimage directly
from parsed records rather than trusting manifest arrays.

If the mismatch cannot be reproduced exactly, stop with:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V10_AGGREGATE_REPRODUCTION_BLOCKED

AUTHORITATIVE V10 REPAIR

Create V10 as a new file. Do not overwrite or rename V9.

V10 must contain exactly 1,681 records in exactly the V9 order.

The 1,679 content records must be preserved as exact outer-line bytes:

- V9 logical lines 2 through 1,680;
- record indexes 1 through 1,679;
- first content record through remaining-seam.S008.

Require byte equality of the complete ordered content-line array:

v9_lines[1:-1] == v10_lines[1:-1]

where each array element is the exact line bytes without its LF separator.

For an additional frozen guard, the newline-joined content-line block, with no
trailing newline, must remain:

byte length:
2417707

SHA-256:
cface622f16e145e0a239add7aebe0325916aec0d91a61b19f72bf5613b8683d

No content payload, outer envelope, record index, record ID, payload hash,
domain digest, record type, or ordering may change.

Exactly two records may have changed complete outer-line bytes:

1. package.manifest.v1 at record_index 0
2. package.closeout.v1 at record_index 1680

No substantive record changes are permitted.

V10 MANIFEST

Regenerate package.manifest.v1 canonically.

Set exactly:

accepted_decisions_id:
RW0_POST_EXECUTION_CANONICAL_PACKAGE_V10_CONTENT_AGGREGATE_REPAIR_V1

baseline_commit:
a3ff0b7f4f0c2378c2962e24612d605489b51638

baseline_tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

fixed_input_sha256:
38c4df3af439a0bae68879ce19a09f8c53db35ea53fb43f1d508c9854b488366

content_aggregate_sha256:
9302da29abad2bbdd78dcae33b1d499236d046cb195184caf8248b60e0b63895

package_schema_id:
governed-execution.nwp-post-execution-canonical-audit-package.v1

package_version:
1

whole_file_hash_location:
external_inline_report

created_at:
a truthful whole-second UTC timestamp in YYYY-MM-DDThh:mm:ssZ form

Preserve exactly from V9:

- ordered_record_ids;
- ordered_payload_hashes;
- record_type_counts.

The ordered arrays must also independently equal the actual V10 content record
IDs and payload hashes.

Regenerate the manifest outer line using the existing exact canonical JSONL
grammar:

- UTF-8;
- no BOM;
- exact eight-field outer mapping;
- compact sorted-key JSON;
- ensure_ascii=false;
- allow_nan=false;
- no Unicode normalization;
- duplicate keys rejected;
- exact payload byte length;
- exact payload raw SHA-256;
- null digest_domain and domain_digest;
- record_id package.manifest.v1;
- record_index 0;
- record_type package_manifest.

V10 CLOSEOUT

Regenerate package.closeout.v1 canonically.

Preserve every V9 closeout field except replace:

content_aggregate_sha256:
9302da29abad2bbdd78dcae33b1d499236d046cb195184caf8248b60e0b63895

The closeout must continue to state exactly:

package_schema_id:
governed-execution.nwp-post-execution-canonical-audit-package.v1

package_version:
1

record_count:
1681

first_record_id:
package.manifest.v1

last_content_record_id:
remaining-seam.S008

record_type_counts:
the exact unchanged V9 counts listed above

Regenerate the closeout outer line with the same canonical rules, record ID
package.closeout.v1, record index 1680, and record type package_closeout.

NO SUPERSESSION OR SEMANTIC DELTA

Do not add semantic-identity or record-payload supersession records.

Reason:

- all 1,679 content records are unchanged;
- package manifest and closeout are package-envelope records;
- prior package lineage intentionally does not issue record-payload
  supersessions for manifest or closeout regeneration.

Report:

- changed content record IDs: none;
- new record IDs: none;
- retired record IDs: none;
- changed envelope record IDs:
  package.manifest.v1
  package.closeout.v1.

Do not claim a semantic, owner, profile, schema, golden, malformed, assurance,
allocation, import, equality, seam, or supersession change.

PACKAGE MECHANICS VERIFICATION

Before success, verify V10 independently for all of the following:

1. Exact fixed-input V9 identity.
2. UTF-8 with no BOM, no blank lines, and no final newline.
3. Duplicate-key rejection for every outer and embedded JSON mapping.
4. Exact eight-field outer grammar and existing key order.
5. Canonical compact sorted-key outer JSON.
6. Canonical compact sorted-key payload_json.
7. Exact payload byte lengths.
8. Exact payload_raw_sha256 values.
9. Every non-null domain-separated digest.
10. Dense record indexes 0 through 1,680.
11. Unique record IDs.
12. Closed record-type block order.
13. Exact per-type counts.
14. Manifest ordered IDs equal actual content IDs.
15. Manifest ordered payload hashes equal actual content payload hashes.
16. Exact byte equality of all 1,679 V9/V10 content lines.
17. Exact content-line block hash:
    cface622f16e145e0a239add7aebe0325916aec0d91a61b19f72bf5613b8683d
18. Correct aggregate preimage length 180,486 bytes.
19. Correct aggregate under two independent implementations:
    9302da29abad2bbdd78dcae33b1d499236d046cb195184caf8248b60e0b63895
20. Manifest/closeout aggregate equality.
21. Closeout record count, first ID, last content ID, and type counts.
22. Exactly two changed complete outer lines versus V9.
23. No added, retired, reordered, or reindexed record.
24. No content payload drift.
25. Whole-file SHA-256 reproduced by at least two independent hash tools.
26. Repository baseline and cleanliness unchanged at closeout.

Do not use V9's manifest or closeout claim as proof of the aggregate. Derive the
aggregate from actual V10 content records.

DELIVERABLE AND ARTIFACT HYGIENE

Use a fresh private temporary root outside the repository:

- root mode 0700;
- V10 deliverable mode 0600.

Remove disposable scripts and intermediates created by this engagement. Leave
only the V10 deliverable in the temporary root when practical.

Expose the exact V10 file through a client-visible attachment link named:

RW0_Post_Execution_Canonical_Audit_Package_V10.jsonl

A plain private filesystem path is not a substitute deliverable.

Do not require or assume a predetermined Downloads path for output delivery.

REPORT

Return a concise but complete verification report containing:

- V9 attachment receipt;
- repository baseline verification;
- explicit classification as a package-envelope/canonical-verification repair,
  not an architecture or semantic repair;
- the claimed V9 aggregate;
- the independently reproduced correct aggregate;
- the exact aggregate algorithm and preimage byte length;
- confirmation that all 1,679 content lines are byte-identical;
- content-line block byte length and SHA-256;
- confirmation that only manifest and closeout outer lines changed;
- exact V10 filename;
- V10 file size;
- V10 whole-file SHA-256;
- V10 logical record count;
- final-newline posture;
- corrected content aggregate;
- per-type counts;
- changed/new/retired inventory;
- confirmation that no supersession entry was added;
- canonical verification results;
- two independent aggregate results;
- two independent whole-file hash results;
- client-visible attachment confirmation;
- confirmation that the repository remained unchanged;
- all required non-action statements;
- success token.

SUCCESS TOKEN

Return exactly:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V10_CONTENT_AGGREGATE_REPAIRED_READY_FOR_INDEPENDENT_AUDIT

only if every fixed-input, content-preservation, aggregate, canonical,
attachment, and no-mutation requirement passes.

Otherwise return:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V10_AGGREGATE_REPAIR_BLOCKED

and classify the blocker as exactly one of:

- fixed-input attachment unavailable;
- fixed-input mismatch;
- baseline mismatch;
- aggregate reproduction mismatch;
- content-line drift;
- manifest reconstruction failure;
- closeout reconstruction failure;
- canonical verification failure;
- whole-file verification failure;
- attachment mechanism unavailable.

REQUIRED NON-ACTION STATEMENTS

End the report with all applicable exact statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED

CONTINUATION BOUNDARY

A successful V10 repair authorizes only a fresh read-only independent audit of
the exact V10 bytes, with V8/V9 lineage available for comparison as needed.

It does not authorize:

- implementation-boundary freeze;
- repository implementation;
- migration 0005;
- durable mutation;
- C2B progression writing;
- terminal behavior;
- RW0-D or RW0-E;
- Execution Substrate work;
- staging, commit, push, publication, merge, or deployment.
