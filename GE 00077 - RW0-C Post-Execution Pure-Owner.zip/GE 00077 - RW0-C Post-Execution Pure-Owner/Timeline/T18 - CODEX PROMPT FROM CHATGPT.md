PROMPT_ID

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V11_REASON_VOCABULARY_AND_RANK15_PREIMAGE_REPAIR_V1

TITLE

Coordinator RW0 — repair the dispatched V16 reason vocabularies, rebuild the
three affected causal malformed controls, make the complete rank-15 admission
graph and membership preimages explicit, regenerate the exact dependency
closure, and deliver canonical package V11 for a fresh independent audit

ENGAGEMENT TYPE

Parent-only, local, repository-read-only canonical-package contract repair.

Use a package-generation/repair conversation, not the independent-audit
conversation that reported RW0-V10-001 through RW0-V10-003. Preserve
auditor/repairer separation.

Do not delegate to subagents or internal audit agents.

Do not edit repository files, format repository files, stage, commit, push,
create a branch or pull request, merge, tag, release, deploy, fetch, contact a
remote or live system, install dependencies, execute repository tests, run
migrations, open or mutate an operator database, invoke a product worker or
model, or inspect supporting repositories.

Scope all repository guidance discovery and source inspection to exactly:

/Users/ds/Repositories/Governed Execution Coordinator/

Do not enumerate parent-directory or sibling-repository guidance paths.

You MAY create files only in one fresh private external temporary root for
bounded source inspection and package reconstruction. Use mode 0700 for that
root and mode 0600 for the deliverable. Set PYTHONDONTWRITEBYTECODE=1 for
bounded pure-source or package-constructor use. Remove disposable
intermediates before closeout.

You MAY invoke current pure/private constructors and package reconstruction
functions against in-memory values from the fixed package. Do not create a
persistent product database or run the repository test suite.

Return the revised package through the client-visible attachment mechanism.
A private filesystem path is not a deliverable.

Do not issue an implementation prompt.

OBJECTIVE

Produce one new immutable package:

RW0_Post_Execution_Canonical_Audit_Package_V11.jsonl

from the attached V10 fixed input.

V11 has exactly two repair objectives:

1. Replace 34 invalid V16 `reason` values in 12 V10 records with the exact
   reason vocabularies already frozen by their dispatched V18, V31, V32, or
   V33 parent profiles; rebuild the three affected malformed controls from
   semantically valid positive bases; and regenerate every transitive identity,
   current value, assurance, supersession, manifest, and closeout affected by
   those changes.

2. Make the complete current-source rank-15 admission-graph and membership
   preimages explicit, including the exact
   `admitted_by_mutation_ref = c1-admit-section41-golden.0001`; regenerate the
   final V11 graph and membership after objective 1's transitive cascade; and
   add finite assurance that those final preimages reproduce the final
   admission-graph and membership digests.

This is a package-contract and audit-completeness repair. It is not an
architecture reset, repository implementation tranche, migration, durable
mutation, authority change, or publication effect.

ATTACHMENT RECEIPT CONTRACT

The sole fixed contract input is the client-uploaded attachment named:

RW0_Post_Execution_Canonical_Audit_Package_V10.jsonl

Do not require, request, or assume a second copy in `/Users/ds/Downloads/` or
any other predetermined path. A runtime materialization path may be used as an
implementation detail, but path presence is not part of the fixed-input
contract.

Before substantive work, visibly report an attachment receipt containing:

- observed filename;
- accessible runtime path, if the client exposes one;
- byte size;
- SHA-256;
- logical record count;
- final-newline posture.

If the client attachment is not accessible, stop immediately and return:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V11_FIXED_INPUT_ATTACHMENT_UNAVAILABLE

Do not search for or silently substitute a same-named local file. Do not treat
attachment transport failure as a semantic finding.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V11_BASELINE_MISMATCH

FIXED INPUT IDENTITY

Require the attached V10 package to have exactly:

filename:
RW0_Post_Execution_Canonical_Audit_Package_V10.jsonl

size:
2613816 bytes

SHA-256:
1f3c08d3a721f4d9bc75d89f9a0ce604bbc344c0f3cd8b3be51218dd17c1430c

logical records:
1681

final newline:
absent

content aggregate:
9302da29abad2bbdd78dcae33b1d499236d046cb195184caf8248b60e0b63895

first record:
package.manifest.v1

last content record:
remaining-seam.S008

final record:
package.closeout.v1

record-type counts:

package_manifest: 1
source_owner_binding: 23
value_schema: 44
behavior_profile: 28
golden_value: 199
malformed_vector: 92
module_allocation: 44
import_edge: 31
equality_matrix: 36
assurance_case: 124
supersession_entry: 1050
remaining_seam: 8
package_closeout: 1

If any fixed-input property differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V11_FIXED_INPUT_MISMATCH

DISPOSITION OF THE V10 INDEPENDENT AUDIT

Treat the V10 audit result as BLOCK, not REJECT and not
AUDIT_PROVENANCE_MISMATCH.

The audit independently reproduced:

- the exact repository baseline;
- V8, V9, and V10 attachment identities;
- strict package mechanics;
- the V8-to-V9 semantic transition;
- V9's expected historical aggregate defect;
- V10's envelope-only aggregate repair;
- current-source migration-0003 row grounding;
- the private zero-or-nine family reader;
- the rank-15 owner-family, wrapper, operand, and relation chain;
- authority, privacy, global-stop, compatibility, module-graph, and
  migration-free boundaries;
- zero forbidden supersession leakage.

No foundational ownership, authority, or decomposition failure was found.

The audit reported three bounded successor-package findings:

RW0-V10-001 — High contract defect:
34 V16 children in 12 records use reason values outside the exact closed
vocabularies of the dispatched V18, V31, V32, or V33 parent profile.

RW0-V10-002 — Medium package/assurance defect:
three malformed controls start from semantically invalid positive bases, so
their named one-predicate mutations do not receive causal credit; A062 and
V7G001 overstate assurance until the bases are repaired.

RW0-V10-003 — Medium audit-completeness defect:
the package supplies rank-15 admission-graph and membership digests but omits
the `admitted_by_mutation_ref` required by both current-source preimages.

A process-only audit observation noted that one guidance-discovery command
enumerated sibling-repository pathnames. No sibling content was read or used.
This repair prevents recurrence by scoping all guidance discovery to the exact
Coordinator root. It does not alter the substantive findings.

SEAM CLASSIFICATION

Current implemented contract:

- Migration 0003 owns the exact nine post-execution evidence rows.
- The current private reader admits exactly zero or nine rows in canonical
  order.
- Current C1 owns evidence admission/replay/recovery, not completeness,
  post-execution branch selection, or execution authority.
- Current admission-graph construction and membership digesting include
  `admitted_by_mutation_ref` as an exact preimage field.
- Current repository code stops before a post-execution decision runtime.

Strategic package target:

- V16 remains the exact five-field parent-bound nested value frozen in V9.
- V18, V31, V32, and V33 parent profiles close each child's reason vocabulary.
- The proposed post-execution modules remain private, pure, no-I/O,
  migration-free, unexported, and without production callers.
- Complete rank-15 admission-graph and membership preimages are finite audit
  evidence, not new runtime authority.

Package defects:

- V10 carries stale or generic reason tokens in exact V16 children.
- V10 carries downstream graph and membership digests without the complete
  auditable rank-15 preimages.

Evidence/projection:

- JSONL records, goldens, malformed vectors, assurance cases, supersession
  entries, manifests, closeouts, and generation reports are evidence only.
  They are not Coordinator durable truth, execution permission, or
  implementation authority.

PRESERVED CONTRACTS

Preserve every V10 contract not transitively changed by this exact repair,
including:

- strict canonical JSONL mechanics and the closed record-type envelope;
- the V9 exact five-field parent-bound V16 shape;
- encoded `schema_id`, `source_ref`, and `source_digest` rejection in V16;
- parent-only source binding for V17, V18, V31, V32, and V33;
- V7 active-global-stop precedence and the exact active outcome split:
  deny, deny, deny, permit, permit;
- source-grounded migration-0003 nine-row construction and zero-or-nine reader;
- truthful migration-0003 row/reader/semantic-owner split;
- exact Section 41 role/rank/ordinal/composite-locator structure;
- corrected current owner-family, rank-15 wrapper, relation, and membership
  construction, regenerated on the repaired V11 basis;
- two-context temporal and model-input separation;
- transient/private candidate-capsule handling and exact resupply;
- closure paging and no C1 completeness authority;
- five distinct decision-currentness components;
- V40 operational separation without person/provider/account/principal claims;
- owner-authored policy and risk attestations;
- generic risk semantics isolated from the FiniteBacklog compatibility adapter;
- exactly fifteen current C1 evidence kinds;
- V35-V37 and V45 absence and future-only recovery seams;
- unsupported/fail-closed current executable authorization;
- no repository implementation authorization.

Do not preserve stale reason literals merely to minimize the delta. Do not
change the valid V41/V42 branch-assertion vocabulary merely because the same
string appears there.

FINDING 1 — EXACT V16 REASON-VOCABULARY REPAIR

V10 contains 94 intended V16 cases:

- 70 golden occurrences;
- 21 ordinary malformed-control occurrences;
- three dedicated V9R001 one-extra-field negatives.

All 91 ordinary occurrences have the exact five encoded V16 fields. The three
V9R001 negatives add exactly one forbidden field each.

Reproduce the V10 reason audit before repair. It must find exactly 34 invalid
ordinary V16 children across exactly the 12 record IDs listed below.

Do not count the 50 V41/V42 branch assertions as ordinary V16 children. They
use distinct enclosing schemas and remain governed by their own contracts.

V18 dispatched reason repair

Exact profile:

profile_ref:
post-execution-risk-lane-matrix.v1

profile_digest:
436ba40a1386d2843bc890767920a7c1cebae96e8c7fa0ed86ef16022c46e502

Replace only in exact V16 children dispatched by V18:

halt_only_risk_lane_not_applicable
->
halt_only_risk_not_applicable

The governed positive reason remains:

risk_lane_permits

V10 invalid occurrence count:
10

Affected V10 records:

- golden.V10.full-evidence-supply
- golden.V11.role-supply.10.risk_lane
- golden.V16.risk.entry.003
- golden.V16.risk.entry.004
- golden.V18.primary
- malformed.risk-source-substitution

Do not replace the same old literal inside V41/V42 values or assertions. Those
are not V16 children and the audit found them valid under their own schemas.

After the direct V18 repair, before downstream propagation, the corrected
standalone V18 primary must have:

matrix_ref:
risk-lane-matrix-golden.0001

matrix_digest:
7c81d7280e2c6fc4f0cde40d0dcd07edaf0d7e7c47bf90f6d001005acdccaa60

canonical byte length:
2971

raw canonical SHA-256:
ecc1e9d935b424c7281f6b3134ce0bc9bb8e6705477206b1d604fce687ed4874

The two standalone corrected halt-only children must have raw canonical
SHA-256 values:

golden.V16.risk.entry.003:
498d49d0727b3d23238dffbf2db02ba3e1e1ea6db84f1037fedb70c95d39ade6

golden.V16.risk.entry.004:
f8180f03018860ba347dfa33e32d273b3b592a662b830cc9cdcb6c600bf82514

V31 dispatched reason repair

Exact profile:

profile_ref:
rw0-c-decision-time-authority-branch.v1

profile_digest:
07384a871dd87a8387c97bb1cd60e6cc8207333428e04e7766044ec8567677dc

Replace in exact V31-dispatched V16 children:

current_evidence_permits
->
authority_verified_current

halt_only_checked
->
halt_only_authority_not_applicable

V10 invalid occurrence count:
5

Affected V10 record:

- golden.V31.primary

V32 dispatched reason repair

Exact profile:

profile_ref:
rw0-c-decision-time-global-stop-branch.v1

profile_digest:
6139df3c64d3736e6938605bc6abef22c258e4841ffe8b641d7a70490f6a5e47

For clear-stop governed permits, replace:

current_evidence_permits
->
global_stop_clear

For halt-only permits under both clear and active stop, replace:

halt_only_checked
->
halt_only_stop_checked

Retain for active-stop governed denials:

global_stop_active

Retain `global_stop_active` in the malformed candidate-acceptance entry whose
only intended semantic mutation is result `deny -> permit`.

V10 invalid occurrence count:
9

Affected V10 records:

- golden.V32.primary
- golden.V32.active-stop
- malformed.global-stop-branch-mismatch

V33 dispatched reason repair

Exact profile:

profile_ref:
rw0-c-decision-time-source-effect-ceiling-branch.v1

profile_digest:
41a6233d964b084cc582bfbaca6ef34e57601996a0d0fc59c77024427af700d2

Replace in exact V33-dispatched V16 children:

current_evidence_permits
->
source_effect_within_current_ceilings

halt_only_checked
->
halt_only_ceiling_not_applicable

V10 invalid occurrence count:
10

Affected V10 records:

- golden.V33.primary
- malformed.attempt-fence-expiry-substitution

Exact total:

V18: 10
V31: 5
V32: 9
V33: 10
total: 34

If the pre-repair count, affected set, or dispatched profile differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V11_REASON_REPRODUCTION_BLOCKED

Do not perform a global string replacement. Apply each correction only after
identifying the exact child schema and dispatched consuming-parent profile.

FINDING 2 — REBUILD CAUSAL MALFORMED CONTROLS AND ASSURANCE

Repair positive controls first. Then rebuild these exact malformed records from
their final semantically valid V11 positive bases:

1. malformed.risk-source-substitution

- Base: final V11 V18 positive.
- Preserve one intended mutation only:
  `source_binding_digest` is substituted.
- Every nested child must use the exact final V18 reason vocabulary.
- First failure must be the named risk-source identity mismatch, not a child
  reason mismatch.

2. malformed.attempt-fence-expiry-substitution

- Base: final V11 V33 positive.
- Preserve one intended mutation only:
  evaluation occurs after the attempt-fence expiry.
- Every nested child must use the exact final V33 reason vocabulary.
- First failure must be the named expired-fence denial, not a child reason
  mismatch.

3. malformed.global-stop-branch-mismatch

- Base: final V11 active-stop V32 positive.
- Preserve one intended semantic mutation only:
  `candidate_acceptance.result` changes from `deny` to `permit`.
- Retain `candidate_acceptance.reason = global_stop_active`.
- All halt-only entries use `halt_only_stop_checked`.
- Recompute the malformed matrix ref and digest over that exact one-result
  mutation.
- Restoring `candidate_acceptance.result = deny` and regenerating identity must
  reconstruct the final V11 active-stop positive exactly.
- First failure must be `stop_branch_matrix_conflict`.

Update assurance.A062 so it no longer claims that the V18 positive is
byte-exact to V8 or V10. It must:

- enumerate the exact five dispatched profile pairs;
- state the exact positive reason vocabulary for V17, V18, V31, V32 clear,
  V32 active, and V33;
- require every pre-existing ordinary V16 child to pass field, type, branch,
  applicability, effect-class, result, and reason validation before parent
  ref/digest reconstruction;
- preserve the three V9R001 one-extra-field negatives;
- require zero other forbidden-field or invalid-reason occurrences.

Update assurance.V7G001.global-stop-active-applicability-split so its recursive
positive precondition states exactly:

- governed active-stop entries: result deny, reason global_stop_active;
- halt-only active-stop entries: result permit, reason
  halt_only_stop_checked;
- all five entries validate under the exact V32 profile before the one-result
  mutation receives causal credit.

Add exactly these two new reason-assurance records:

assurance.V11R001.v16-dispatched-reason-stale
malformed.V11R001.v16-dispatched-reason-stale

The assurance record must use symbolic stale targets and require seven
one-at-a-time cases:

1. V18 halt-only:
   halt_only_risk_not_applicable
   -> distinct_stale_v18_halt_only_reason

2. V31 governed:
   authority_verified_current
   -> distinct_stale_v31_governed_reason

3. V31 halt-only:
   halt_only_authority_not_applicable
   -> distinct_stale_v31_halt_only_reason

4. V32 clear governed:
   global_stop_clear
   -> distinct_stale_v32_clear_governed_reason

5. V32 halt-only:
   halt_only_stop_checked
   -> distinct_stale_v32_halt_only_reason

6. V33 governed:
   source_effect_within_current_ceilings
   -> distinct_stale_v33_governed_reason

7. V33 halt-only:
   halt_only_ceiling_not_applicable
   -> distinct_stale_v33_halt_only_reason

The paired malformed record must carry the concrete stale V10 tokens
one-at-a-time:

- halt_only_risk_lane_not_applicable;
- current_evidence_permits;
- halt_only_checked.

Each case must begin from an otherwise exact final V11 positive child, alter
only `/reason`, and expect rejection at dispatched-parent reason validation
before parent ref/digest acceptance. Removing the one stale reason and
restoring the exact final reason must recover the positive child byte-exactly.

FINDING 3 — COMPLETE RANK-15 ADMISSION PREIMAGES

Current source requires `admitted_by_mutation_ref` in both exact preimages.

Current membership field order is exactly:

1. schema_id
2. membership_ref
3. phase_basis_ref
4. phase_basis_digest
5. kind_rank
6. value_ref
7. value_digest
8. value_schema_id
9. scope_binding_digest
10. relation_set_digest
11. admitted_by_mutation_ref
12. admitted_at
13. admission_graph_digest

Current admission-graph semantic field order is exactly:

1. schema_id
2. phase_basis_ref
3. phase_basis_digest
4. membership_ref
5. kind_rank
6. value_ref
7. value_digest
8. value_schema_id
9. scope_binding_digest
10. relation_set_digest
11. relations
12. admitted_by_mutation_ref
13. admitted_at

The `relations` array is in relation-rank order and each element contains:

- relation_rank;
- relation_ref;
- relation_digest;
- operand_set_digest;
- evaluated_at.

V10 HISTORICAL PREIMAGE RECOVERY GATE

Before changing substantive values, independently reconstruct the V10 rank-15
graph and membership using the V10 package's exact existing rank-15 values.

The exact missing V10 field is:

admitted_by_mutation_ref:
c1-admit-section41-golden.0001

On the exact V10 basis, this value must reproduce:

V10 admission graph digest:
484291049fe80389eef3a856024fc26f70a59a05c3a34048eaeafbc37b5ec7e4

V10 graph canonical byte length:
1100

V10 graph raw canonical SHA-256:
07eab636c2896c49c06dd24cd0bc934d55b9e93aa60412ae243623769cf6546d

V10 membership digest:
5a0e664074e92aa69360513fd022824a6a247db1f18dd92cc141679047620b6f

V10 membership canonical byte length:
862

V10 membership raw canonical SHA-256:
eaab9f49c0abe3dbdcd2e998401160f9c4612aa9e6f88f78c0ddf0a719edceb7

The V10 historical graph must use:

membership_ref:
c1-section41-membership-golden.0001

kind_rank:
15

value_ref:
section41-member-golden.0001

value_digest:
70dab00e12c79a58cf3a119a00dc1ad7c24efc008540fc5b4d46f88cd46e453c

value_schema_id:
governed-execution.nwp-rw0-c1-section41-post-execution-proposal-family-member.v1

scope_binding_digest:
08ace396f61397e1c262258396e9015472bbbb91fbfc842107e137125c6d391e

relation_set_digest:
d352f938938082da34bd4684c4485edb15c3584ed7d4acdbf47c3adbcc77a881

relation_ref:
rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc

relation_digest:
fc41b099330b711a66dc01329f29aeb6d9c4650c684f4a16dbdc9f433c4ea235

operand_set_digest:
6a43b8cf16a2b91d69b568b7656401c60b1cf5f1a9440a230a867e9c75983c42

evaluated_at:
null

admitted_at:
2026-09-30T12:00:01Z

The exact mutation ref is therefore recovered from two independent current
digest equations: the graph digest and the membership digest.

If the V10 historical recovery does not reproduce both exact digests and both
raw canonical hashes, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V11_RANK15_PREIMAGE_RECOVERY_BLOCKED

Do not copy the V10 graph or membership as final V11 values after reason
repair. The reason correction changes upstream evidence, proposal, owner
family, rank-15 value/relation, closure, snapshot, and decision-input
identities. Preserve only the exact mutation ref and current field grammar,
then regenerate the complete final V11 chain mechanically.

FINAL V11 RANK-15 CONTROLS

Add exactly these two new golden record IDs:

golden.owner.rank15.graph
golden.owner.rank15.membership

`golden.owner.rank15.graph` must contain the complete final V11 canonical
admission-graph identity, excluding no semantic field and including:

admitted_by_mutation_ref:
c1-admit-section41-golden.0001

Its domain-separated digest must equal the final V11 rank-15
`admission_graph_digest`.

`golden.owner.rank15.membership` must contain the complete final V11 canonical
membership identity, including the same mutation ref and the final V11
admission-graph digest.

Its domain-separated digest must equal the final V11 rank-15
`membership_digest`.

The final V11 controls must reconcile exactly with:

- golden.owner.rank15.value;
- golden.owner.rank15.relation;
- the rank-15 closure entry in golden.V25.primary;
- the final relation row subject membership;
- the final relation set;
- final Section 41 projection and role resolutions;
- final closure, current snapshots, currentness, and decision inputs;
- source-owner.rank15-section41-value;
- source-owner.rank15-section41-relation.

Add exactly one new positive assurance record:

assurance.A063

A063 must require, in order:

1. the final V11 rank-15 value and relation controls reconstruct;
2. `golden.owner.rank15.graph` has the exact current-source field set and field
   semantics;
3. the graph domain digest reproduces the final V11 admission-graph digest;
4. `golden.owner.rank15.membership` has the exact current-source field set and
   field order;
5. the membership domain digest reproduces the final V11 membership digest;
6. both controls contain exactly
   `c1-admit-section41-golden.0001`;
7. the final V25 rank-15 closure entry carries those exact digests;
8. the final rank-15 relation row binds that exact membership digest;
9. only then may downstream closure, snapshot, currentness, and decision-input
   identities receive semantic credit.

Extend these existing paired records:

assurance.V6R001.rank15-current-owner-cascade-stale
malformed.V6R001.rank15-current-owner-cascade-stale

Preserve their four existing graph/wrapper/operand/relation mutation cases.
Add a fifth exact one-predicate mutation for the rank-15 mutation ref.

The assurance uses a symbolic target:

c1-admit-section41-golden.0001
->
distinct_stale_rank15_admitted_by_mutation_ref

The malformed record uses one concrete safe stale value:

c1-admit-section41-golden.0001
->
c1-admit-section41-stale.golden.0001

The malformed base records must include the final V11 graph and membership
goldens. Applying that substitution to exactly one preimage at a time while
holding the expected positive digest must produce, respectively:

- admission_graph_digest_mismatch; or
- membership_digest_mismatch.

Restoring the exact mutation ref must recover the final positive graph or
membership byte-exactly.

Do not treat the mutation ref as execution permission or external authority.
It is an exact retained admission-event identity coordinate in the current C1
digest preimage.

TRANSITIVE REGENERATION ORDER

Do not patch downstream hashes manually.

Regenerate from the earliest corrected semantic values in dependency order.

At minimum, mechanically traverse and regenerate any affected:

- V16 standalone children;
- V18 risk matrix;
- role-supply and full-evidence-supply values;
- model-input contexts, bindings, manifests, and projections;
- migration-0003 physical row values and row self-digests;
- evidence-set and proposal identities;
- owner-family graph and rank-15 wrapper;
- relation operands, operand set, relation, relation row, and relation set;
- final rank-15 admission graph and membership;
- Section 41 projection entries and role resolutions;
- closure entries and closure identity;
- clear and active current snapshots;
- proposal currentness;
- V31 authority matrix;
- V32 clear and active stop matrices;
- V33 ceiling matrix;
- V34 recommendation consistency;
- equality matrices;
- affected malformed controls;
- affected assurance records;
- source-owner controls if their current identity statements or finite control
  references change;
- semantic supersession entries;
- record-payload supersession entries;
- manifest and closeout.

The reason repair to V18 is upstream of the proposal/evidence/rank-15 chain.
Therefore final V11 V31, V32, and V33 refs and digests must be generated on the
final repaired snapshot/proposal basis. Do not freeze or preserve any
intermediate reason-only identity computed on the V10 parent basis.

Derive the complete changed-record set mechanically. Do not rely on the
12-record direct-defect list as the complete transitive delta.

NEW SUBSTANTIVE RECORD IDS

Add exactly these five substantive record IDs:

golden.owner.rank15.graph
golden.owner.rank15.membership
assurance.A063
assurance.V11R001.v16-dispatched-reason-stale
malformed.V11R001.v16-dispatched-reason-stale

Do not retire any V10 record ID.

Do not introduce another value schema, behavior profile, module allocation,
import edge, migration, public export, production caller, or durable owner.

All other new IDs must be required supersession entries derived from the exact
V10-to-V11 delta.

SUPERSESSION REQUIREMENTS

For every changed existing substantive record, add exactly one
record-payload supersession entry binding:

- the exact V10 payload_raw_sha256;
- the exact final V11 payload_raw_sha256;
- the exact record ID;
- a truthful V11 repair reason.

Do not create record-payload supersessions for:

- package.manifest.v1;
- package.closeout.v1;
- newly added records.

For every current semantic identity replaced by the repair, add exactly one
semantic supersession entry binding the exact old identity to the exact final
V11 identity.

This includes all transitive semantic identity changes, not only the directly
visible V18/V31/V32/V33 matrix identities.

Do not create a semantic supersession when:

- no semantic identity changed;
- a record is merely newly added;
- only manifest or closeout envelope bytes changed.

Each supersession record ID suffix must equal the first 20 lowercase
hexadecimal characters of that supersession record's own payload_raw_sha256.

Reject duplicate exact supersession pairs.

Run a package-wide typed supersession scan over every hexadecimal old identity.
Permitted residual occurrences are limited to dedicated malformed evidence and
the supersession ledger. Zero superseded identities may remain in current
schemas, profiles, goldens, source-owner truth, allocations, equality
matrices, positive assurances, seams, manifest claims, or closeout truth.

The non-hex stale reason strings and stale mutation ref used in dedicated
malformed vectors must not leak into positive controls.

UNCHANGED-PAYLOAD GUARD

Every retained V10 payload outside the mechanically derived changed set must
remain byte-identical as `payload_json`.

Index-only outer-envelope movement caused by inserted records is legitimate and
is not a substantive payload change.

Do not claim complete outer-line equality for records whose dense
`record_index` changes.

Before finalizing:

1. compute the exact retained-ID payload delta;
2. prove each changed retained payload is transitively required by this repair;
3. prove all other retained payloads are byte-identical;
4. list the complete changed retained set;
5. list the complete new substantive set;
6. list all semantic and record-payload supersessions;
7. report no retired IDs.

PACKAGE MECHANICS

V11 must preserve:

- strict UTF-8;
- no BOM;
- no blank lines;
- no final newline;
- duplicate-key rejection for outer and embedded JSON;
- exact eight-key outer record grammar;
- compact sorted-key canonical outer JSON;
- compact sorted-key canonical payload JSON;
- exact payload byte lengths;
- exact payload_raw_sha256 values;
- every non-null domain-separated digest;
- dense indexes;
- unique IDs;
- closed record-type ordering;
- manifest ordered ID and payload-hash arrays;
- exact per-type counts;
- independently reconstructed content aggregate;
- exact closeout reconciliation.

Compute the content aggregate as SHA-256 over content-record entries in
record-index order:

UTF-8(record_id)
+ TAB
+ ASCII(payload_raw_sha256)

joined by LF with no trailing LF.

Reproduce the final whole-file hash with at least two independent
implementations and one standard local hash tool.

FINAL SEMANTIC VALIDATION

Before declaring success, require all of the following:

1. All pre-existing 91 ordinary V16 instances validate recursively against
   their exact dispatched profile, including exact reason vocabulary.

2. The three pre-existing V9R001 extra-field cases fail only for their exact
   added field and restore byte-exactly.

3. The seven V11R001 stale-reason cases fail only for the exact reason
   substitution and restore byte-exactly.

4. Zero ordinary V16 instance carries:
   - halt_only_risk_lane_not_applicable under V18;
   - current_evidence_permits under V31, V32, or V33;
   - halt_only_checked under V31, V32, or V33.

5. Valid V41/V42 assertions remain unchanged unless a true transitive identity
   dependency requires change; their independent schemas must not be
   reclassified as V16.

6. The three repaired malformed controls begin from semantically valid final
   positive bases and fail first for their named one-predicate mutation.

7. Active V32 remains exactly:
   deny, deny, deny, permit, permit
   with reasons:
   global_stop_active, global_stop_active, global_stop_active,
   halt_only_stop_checked, halt_only_stop_checked.

8. The final rank-15 graph and membership preimages contain
   `c1-admit-section41-golden.0001` and independently reproduce their final
   digests.

9. The current private reader accepts the complete final nine-row family and
   the current exact-family matcher returns true.

10. Exactly fifteen current C1 evidence kinds remain.

11. V35-V37 and V45 remain absent from current schemas, goldens, allocations,
    imports, and implementation scope.

12. The module-allocation bijection and import graph remain closed and acyclic.

13. Generic risk remains isolated from FiniteBacklog-specific ownership except
    through the explicit compatibility adapter.

14. Zero forbidden supersession leakage remains.

15. No repository path changed.

If any condition cannot be satisfied exactly, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V11_REPAIR_BLOCKED

MANIFEST AND CLOSEOUT

Regenerate package.manifest.v1 and package.closeout.v1 mechanically from the
final V11 records.

Set:

accepted_decisions_id:
RW0_POST_EXECUTION_CANONICAL_PACKAGE_V11_REASON_VOCABULARY_AND_RANK15_PREIMAGE_REPAIR_V1

fixed_input_sha256:
1f3c08d3a721f4d9bc75d89f9a0ce604bbc344c0f3cd8b3be51218dd17c1430c

Use one fixed whole-second UTC `created_at` chosen once for V11 generation.

Do not hand-copy a content aggregate. Derive it independently from final
content records, bind the same value in manifest and closeout, and verify it
with a second implementation.

DELIVERABLE

Deliver exactly one new client-visible file:

RW0_Post_Execution_Canonical_Audit_Package_V11.jsonl

Do not overwrite V10.

The final response must visibly attach the V11 file by filename. A private path
alone is not a deliverable.

VERIFICATION REPORT

Report at least:

1. V10 attachment receipt.
2. Exact repository baseline and final clean posture.
3. Reproduction of the 34 invalid reason occurrences and exact 12-record set.
4. Exact reason replacement counts by dispatched profile.
5. V10 historical rank-15 preimage recovery, including:
   - exact mutation ref;
   - graph raw hash and domain digest;
   - membership raw hash and domain digest.
6. Final V11 rank-15 graph and membership controls and their final digests.
7. Complete changed retained-record inventory.
8. Complete five-record new substantive inventory.
9. Complete semantic supersession inventory.
10. Complete record-payload supersession inventory.
11. Retired record IDs, which must be none.
12. V11 filename, size, SHA-256, record count, final-newline posture, content
    aggregate, and per-type counts.
13. V16 recursive validation totals and stale-reason negative results.
14. Three repaired causal malformed-vector results.
15. Supersession leakage scan totals and zero forbidden occurrences.
16. Unchanged-payload guard result.
17. Whole-file hash reproduction methods.
18. Exact skipped/non-authorized actions.
19. Any unresolved uncertainty.

NON-AUTHORIZATIONS

A successful V11 package authorizes only a fresh parent-only, local,
repository-read-only independent audit.

It does not authorize:

- implementation-boundary freeze;
- repository implementation;
- migration 0005;
- persistent database creation or mutation;
- post-execution evidence owners;
- RW0-C decision execution;
- C2B progression writing;
- RW0-C terminal behavior;
- RW0-D or RW0-E;
- Execution Substrate changes;
- supporting-repository changes;
- worker or model invocation;
- staging;
- commit;
- push;
- pull request;
- merge;
- publication;
- deployment.

FINAL SUCCESS TOKEN

Only after the V11 attachment is visibly exposed and every required check
passes, return exactly:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V11_REASON_AND_RANK15_PREIMAGE_REPAIRED_READY_FOR_INDEPENDENT_AUDIT

Also print these exact non-action statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
