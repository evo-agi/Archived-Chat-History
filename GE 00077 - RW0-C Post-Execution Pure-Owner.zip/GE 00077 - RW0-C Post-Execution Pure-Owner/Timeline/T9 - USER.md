Here is Codex's response:

Completed. The repaired package is available as the client-visible artifact:

[RW0_Post_Execution_Canonical_Audit_Package_V8.jsonl](/tmp/rw0-v8-repair.Icn0xq/RW0_Post_Execution_Canonical_Audit_Package_V8.jsonl)

No raw private output path is offered as the deliverable, and no predetermined Downloads path was required for output delivery.

## V7 attachment receipt

- Filename: `RW0_Post_Execution_Canonical_Audit_Package_V7.jsonl`
- Client-exposed runtime materialization: `/Users/ds/Downloads/RW0_Post_Execution_Canonical_Audit_Package_V7.jsonl`
- Size: `2,484,322` bytes
- SHA-256: `6d3e7fd550598306c484180ab1e81e01d67649597ee5b4e8f8ac3446c7840009`
- Logical records: `1,559`
- Final newline: absent
- Content aggregate: `74095ab24c91b8f8808fc4d0ffcf723a4d14ae5ffc8610076d2fed3a9de8d084`

The client-exposed path was used directly; no filesystem search or same-named substitution occurred.

## Baseline verification

- Branch: `trunk_dev`
- HEAD: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- Tree: `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0`
- Sole parent: `047563de5a443b0f8323401c92979ae2e444d2ed`
- Subject: `feat: implement RW0-C1 durable evidence (#7)`
- Upstream: `origin/trunk_dev`
- Ahead/behind: `0/0`
- Worktrees: `1`
- Worktree/index/untracked/unmerged: clean
- Fetch: not performed

The same baseline and cleanliness were confirmed after package generation and cleanup.

## Finding disposition

- `RW0-V7-001`: closed. All nine physical rows were reconstructed from the current owner; six stale self-digests were corrected.
- `RW0-V7-002`: closed. Post-execution evidence-set semantic ownership now names `_sqlite_rw0_c1`, while separately identifying the row and reader owners.
- `RW0-V7-003`: closed. Current-constructor, current-reader, exact-family, and ordered mutation assurances are now explicit.

The prior result remains a repairable `BLOCK`, not an architectural rejection.

### Nine row digests

| Role | Result | Current digest |
|---|---|---|
| `candidate_capsule` | unchanged | `e1d8c9fb13ec6719b04cd1687620565ee00e55ea1f3e3965b998aad5011b820a` |
| `worker_result` | unchanged | `0d4bcad233a3265992c6ff85b6655fca7cfef6e3ea871f27294768601b3f612c` |
| `authority_currentness_attestation` | unchanged | `695445d763c4156b3c8fc5b4a619a3962983440c9809ad1b4e67f41b410964d0` |
| `validation_result` | corrected | `4fc6b571441d96297be155d5049fadf3b161b033527af5431803a208c48d2fbf` |
| `independent_review` | corrected | `befffaa9e5041cb6d9e01e19ea54c8d4f7d8a579783cda1e1caf05705738c01f` |
| `standing_policy` | corrected | `72963e1fd447191fd5740b41dc4e8e6d44747ec11efcd702223c60e8fac2c948` |
| `risk_lane` | corrected | `fa37991e2e86050a64aa07fd42c521b6ec6c842aaee56822adb2e013f793dc59` |
| `global_stop` | corrected | `8243f099ada6220771d006db22cd48cf6deae9d950351e5f892956db28798d79` |
| `effect_ceiling` | corrected | `dad94ec67abc7c0b94ef73aa1b86b95b3dd65cf4282cf8955a9536ebe0a97536` |

Every exact built-in mapping and tuple passed, in order:

1. Current physical row constructor.
2. `computed_digest()` equality.
3. Current private-reader tuple reconstruction.
4. Exact nine-row canonical role/rank/order family.
5. Complete 12-locator owner-family reconstruction.
6. Rank-15 wrapper constructor.
7. `_section41_owner_family_matches`, which returned `true`.

### Corrected cascade anchors

- Evidence set: `213b55b3a75121cadeab28e05ce7dda0525ac447464d8bbfcd82515b8e15b54d`
- Proposal: `acda782cef72c31e0f9e3923659de53f969b6f26c746ae03150ac9762d6d079f`
- Owner-family graph: `08ace396f61397e1c262258396e9015472bbbb91fbfc842107e137125c6d391e`
- Rank-15 wrapper: `70dab00e12c79a58cf3a119a00dc1ad7c24efc008540fc5b4d46f88cd46e453c`
- Rank-15 operand set: `6a43b8cf16a2b91d69b568b7656401c60b1cf5f1a9440a230a867e9c75983c42`
- Relation: `fc41b099330b711a66dc01329f29aeb6d9c4650c684f4a16dbdc9f433c4ea235`
- Relation row: `fe561bb46937e51b68c0b271540214fc69c923694b0136d22c03f57d2366f3e5`
- Relation set: `d352f938938082da34bd4684c4485edb15c3584ed7d4acdbf47c3adbcc77a881`
- Admission graph: `484291049fe80389eef3a856024fc26f70a59a05c3a34048eaeafbc37b5ec7e4`
- Membership: `5a0e664074e92aa69360513fd022824a6a247db1f18dd92cc141679047620b6f`

### Source-owner split

`source-owner.migration0003-evidence-set` now records:

- Physical row owner: `ge_nwp_coordinator._cognitive_proposal_row_values`
- Bounded 0-or-9 family reader: `ge_nwp_coordinator._sqlite_rw0_c1_readers`
- Post-execution semantic reconstruction: `ge_nwp_coordinator._sqlite_rw0_c1._section41_owner_family_matches`
- `owner_module`: `ge_nwp_coordinator._sqlite_rw0_c1`
- Owner table: `development_model_proposal_evidence_bindings`
- Digest domain remains `governed-execution.nwp-model-proposal-evidence-set.v1.identity`

It explicitly states that digest-domain provenance is not semantic ownership.

### Assurance treatment

- `assurance.A047` now requires all nine constructors, all nine private readers, and the complete 12-locator exact-family matcher before equality is claimed.
- `assurance.A060` adds the nine-row constructor/reader positive control.
- `assurance.A061` adds the complete current private-reader/exact-family positive control.
- `assurance.V6R001.rank15-current-owner-cascade-stale` now enforces the required seven-step positive-control ordering before symbolic mutation.
- `assurance.V8R001...` contains six symbolic row-digest mutations only.
- `malformed.V8R001...` contains the six concrete V7 stale digests, one-at-a-time causality, `physical_family_row_digest_mismatch`, and `database_integrity_failure`.
- `assurance.V3G006...` now uses `_sqlite_rw0_c1` as its literal positive control.
- `malformed.V3G006...` uses `_cognitive_proposal_semantic_values` only as the rejected substitution and has the corrected base payload SHA.

## V8 package identity

- Filename: `RW0_Post_Execution_Canonical_Audit_Package_V8.jsonl`
- Size: `2,587,718` bytes
- Whole-file SHA-256: `91eb1bbfd3d741e294117f6a8e548a797cc547d132404adb187c04027a0a3fc7`
- Logical records: `1,660`
- Final newline: absent
- Content aggregate: `771f654a896e8fdc7d8147bb7e3c3fc4b9c7ecab83b8fa76dc5248ca0cc32750`

Independent `shasum` and OpenSSL SHA-256 results agreed.

| Record type | Count |
|---|---:|
| `package_manifest` | 1 |
| `source_owner_binding` | 23 |
| `value_schema` | 44 |
| `behavior_profile` | 28 |
| `golden_value` | 199 |
| `malformed_vector` | 91 |
| `module_allocation` | 44 |
| `import_edge` | 31 |
| `equality_matrix` | 36 |
| `assurance_case` | 122 |
| `supersession_entry` | 1,032 |
| `remaining_seam` | 8 |
| `package_closeout` | 1 |

## Record inventory

Changed existing substantive payload IDs: 55.

```text
assurance.A047
assurance.V3G006.evidence-set-owner-module-substitution
assurance.V6R001.rank15-current-owner-cascade-stale
golden.V09.model-input-binding
golden.V22.primary
golden.V23.projection-evidence.002
golden.V23.projection-evidence.003
golden.V23.projection-evidence.004
golden.V23.projection-evidence.005
golden.V23.projection-evidence.007
golden.V23.projection-evidence.008
golden.V24.role-resolution.05.candidate_capsule
golden.V24.role-resolution.06.worker_result
golden.V24.role-resolution.07.validation_result
golden.V24.role-resolution.08.independent_review
golden.V24.role-resolution.09.standing_policy
golden.V24.role-resolution.10.risk_lane
golden.V24.role-resolution.11.authority_currentness_attestation
golden.V24.role-resolution.12.global_stop
golden.V24.role-resolution.13.effect_ceiling
golden.V25.primary
golden.V26.closure-entry.007
golden.V27.active-stop-control
golden.V27.primary
golden.V29.primary
golden.V31.primary
golden.V32.active-stop
golden.V32.primary
golden.V33.primary
golden.V34.primary
golden.owner.evidence-set
golden.owner.owner-family-graph
golden.owner.proposal
golden.owner.proposal-evidence-row.07.validation_result
golden.owner.proposal-evidence-row.08.independent_review
golden.owner.proposal-evidence-row.09.standing_policy
golden.owner.proposal-evidence-row.10.risk_lane
golden.owner.proposal-evidence-row.12.global_stop
golden.owner.proposal-evidence-row.13.effect_ceiling
golden.owner.rank15.relation
golden.owner.rank15.value
malformed.V3G006.evidence-set-owner-module-substitution
malformed.V3G028.snapshot-rank1-membership-substitution
malformed.V3G029.snapshot-rank15-membership-substitution
malformed.V3G030.snapshot-external-source-substitution
malformed.V3G031.snapshot-phase-k8-mismatch
malformed.V3G032.snapshot-required-row-missing
malformed.V3G033.snapshot-current-row-malformed
malformed.attempt-fence-expiry-substitution
malformed.global-stop-branch-mismatch
source-owner.migration0003-evidence-set
source-owner.migration0003-owner-family-graph
source-owner.migration0003-proposal
source-owner.rank15-section41-relation
source-owner.rank15-section41-value
```

`package.manifest.v1` and `package.closeout.v1` were mechanically regenerated and intentionally receive no record-payload supersession. Every other retained V7 `payload_json` is byte-identical; index-only movement is not classified as payload change.

New record IDs: 101 total:

```text
assurance.A060
assurance.A061
assurance.V8R001.migration0003-evidence-row-self-digest-stale
malformed.V8R001.migration0003-evidence-row-self-digest-stale
```

The remaining 97 new IDs are the 42 `supersession.v8.identity.*` and 55 `supersession.v8.record.*` IDs listed completely below.

Retired record IDs: none.

## Semantic supersession inventory

Format: `ledger ID | semantic target | old identity -> replacement identity`.

```text
supersession.v8.identity.0de6417f21fbce0dd333 | value:governed-execution.nwp-model-proposal-envelope.v1:post-proposal-golden.0001 | ba1d2626d1a7bdc6daa4ec9a956a29145da9ba907dab10c968e0445b4e0235a0 -> acda782cef72c31e0f9e3923659de53f969b6f26c746ae03150ac9762d6d079f
supersession.v8.identity.6dd3795bb25a88e830fb | value:governed-execution.nwp-model-proposal-evidence-binding.v1:post-proposal-golden.0001.effect_ceiling.0 | 22e4c05af2b956e1cc3737a7c19ede27c825036fea612506fd216964c34b0bce -> dad94ec67abc7c0b94ef73aa1b86b95b3dd65cf4282cf8955a9536ebe0a97536
supersession.v8.identity.ff06d6ba99b729a6814b | value:governed-execution.nwp-model-proposal-evidence-binding.v1:post-proposal-golden.0001.global_stop.0 | d826cbec8e4e347c5cc90f96dce7377e98970b63eef6d628471fca15824b5005 -> 8243f099ada6220771d006db22cd48cf6deae9d950351e5f892956db28798d79
supersession.v8.identity.ffe9e26a95e5aede96d3 | value:governed-execution.nwp-model-proposal-evidence-binding.v1:post-proposal-golden.0001.independent_review.0 | 915f0c00f9117f2fbb3137249bcd8753c92653ef913dacbb16200224b335ca3e -> befffaa9e5041cb6d9e01e19ea54c8d4f7d8a579783cda1e1caf05705738c01f
supersession.v8.identity.f25022b78edae802c561 | value:governed-execution.nwp-model-proposal-evidence-binding.v1:post-proposal-golden.0001.risk_lane.0 | d6623dda0698a01d4b3406b40aacc543db92630a98dac110a2fe59a1d8f9748a -> fa37991e2e86050a64aa07fd42c521b6ec6c842aaee56822adb2e013f793dc59
supersession.v8.identity.d4da3035391f10e25996 | value:governed-execution.nwp-model-proposal-evidence-binding.v1:post-proposal-golden.0001.standing_policy.0 | a4c4131e23dd395fa792bb0afa6816741637c43826663f102b21f4a1f057a95c -> 72963e1fd447191fd5740b41dc4e8e6d44747ec11efcd702223c60e8fac2c948
supersession.v8.identity.426f44f8ef03165752e7 | value:governed-execution.nwp-model-proposal-evidence-binding.v1:post-proposal-golden.0001.validation_result.0 | ba78bf89b4e73c16482ac94f16b01b1b8374a2d0ae7af3426260bdfb4d6edfca -> 4fc6b571441d96297be155d5049fadf3b161b033527af5431803a208c48d2fbf
supersession.v8.identity.5253111566d1c56934de | value:governed-execution.nwp-model-proposal-evidence-set.v1:post-evidence-set-golden.0001 | 3b7b66c48d6b48122a1e09cbf66e1071d8948ff77a7993efadb1714aa6b01633 -> 213b55b3a75121cadeab28e05ce7dda0525ac447464d8bbfcd82515b8e15b54d
supersession.v8.identity.560d7c9b0ce6b7aa1734 | value:governed-execution.nwp-post-execution-model-input-binding.v2:post-model-input-binding-v2.f9e952ceac1296d6cff58fd026fe748087104bc195c1bb6f8ea715b9b54978a0 | ef66b0524ae7ebc7bc20632609bdf321dba4dca1c54adeab22153b8b55bd69f3 -> 52461b72f456d3a62316fa876395d4b7acde163a4e2dd85e7157284e04780d26
supersession.v8.identity.1e8a56899ccbcfd74e02 | value:governed-execution.nwp-rw0-c-decision-current-snapshot.v1:rw0-c-current-snapshot.5318fe94a5654f9626e3bbd9fda42b8736b914d690b1e270b0f54fce012988af | bb95ff499c4ef25616c28fa37a746678a951fb2b430315bff2143f589499ba7b -> 16a18f7f9d69bc37bfda7d3fdba7ea875e4f8b316e790d4e1db63b03b9d974a6
supersession.v8.identity.28c12f9ef4d8c03c4699 | value:governed-execution.nwp-rw0-c-decision-current-snapshot.v1:rw0-c-current-snapshot.cd16d38a0ac8d7abfe8fa49488b84d06044b4f23441d725f550f6d553adbb068 | d4eeef74c01ab30f6b2746fe222a54e7fded87872502d03caa4e9ab16ae907a0 -> 64cc66c721853c2f7ab0e9afad1c75c6eb80451717f21c65062ae57c152cc3ae
supersession.v8.identity.86dc2ceb6d5a436fd11d | value:governed-execution.nwp-rw0-c-decision-membership-closure.v1:rw0-c-membership-closure.75f769059dc080880469cbf6e6d55c6fc42cb558ba6e376fb3ebe17250c13943 | b55c170b3dd54231e5cec39d2696bc248cb1f9b5e24d223b745c5f3d3902c442 -> 501f6ef33d1b2f07587f207ae4ffd223745b609b36882798da92f762c4be4999
supersession.v8.identity.fe84de9ad311300ef8d3 | value:governed-execution.nwp-rw0-c-decision-time-authority-branch-matrix.v1:rw0-c-authority-matrix.43688fd29a4f8e82eaf96a9c5d5f051953e77876a99be7dac38ef64cb2d6f4cd | 3370d1211cbf49ad8551621599a07e657bea855d0e07871f03006e2cdba736ae -> 7c06c3f0014dc42a76fde758cc2d18b033b384c910af20d136b25cbc6a0c784c
supersession.v8.identity.5dae558d9d00ed9d41df | value:governed-execution.nwp-rw0-c-decision-time-global-stop-branch-matrix.v1:rw0-c-global-stop-matrix.765a8f001b742856925c6ba9ed90bd2dafd12dd3399cdc10d704404949b843b9 | e8b2af5a16ae67d027404d1fa96cc48cc78cf115b2ddecfde8891d4c3abeca67 -> ad2c7cc9657f2f0030d0ffe0beb7177d287217170b0734d8a125d5943624bbfb
supersession.v8.identity.50408ffae7774b5b85b9 | value:governed-execution.nwp-rw0-c-decision-time-global-stop-branch-matrix.v1:rw0-c-global-stop-matrix.94abe7bedbd63b72e620b7accaf11162f6c46076f7ff6b80e7477157fb586150 | 1a2e960d02fbe5500a65d14165296adb43ce41a25f229a4374c32538f9b0f7c7 -> dac20f7cfdb6af63fa78722efdd02e563b7e340d054aa16ce7b5b53d1a603823
supersession.v8.identity.e0ef3d6249644a527cd6 | value:governed-execution.nwp-rw0-c-decision-time-source-effect-ceiling-branch-matrix.v1:rw0-c-ceiling-matrix.84158b48657b7556f38e472ac0b4653ddf331d8fd4d87855c7a98d0dae716fda | 58095bc66ae417bd466488665778c508fed88d9dfeb3e48f2cda81d539204c70 -> cb1e2419be09ddd002375dd654c1291693fe3bad998d84ae44291a61a749ac88
supersession.v8.identity.d0342d795feb4cc17d78 | value:governed-execution.nwp-rw0-c-proposal-evidence-currentness.v1:rw0-c-proposal-currentness.3d4f47603975107e790d314ea9a92166f65e1858c3dcbf57cd896a6c299e14c2 | 3a12148478f12386be2f5a56a4c8d1a2b73dbb8f1a86377eebac01b0e1e44917 -> 87d33d2cab8f53a51226758e2d7403a92a67f115392f6ec350ff4cb549e4fdff
supersession.v8.identity.0b1d9075aac25aab84e5 | value:governed-execution.nwp-rw0-c-recommendation-consistency-evaluation.v1:rw0-c-recommendation-consistency.b8e7e891636e438d918eb7bd9dff51a377c76bc24370126ad2b06195c4460a98 | 5a1b06548cb054ca9aa6bbdc5e1feeed8e4a005f4b93a54887edac59040c2b5e -> 77f653f75af24c423060135ad169cc48c5d9c4e3c6d2fa508ca1a3c4a682a6ec
supersession.v8.identity.22b6f16b10377f28f18e | value:governed-execution.nwp-rw0-c1-evidence-admission-graph.v1:c1-section41-membership-golden.0001 | 76d23e2e5cb3c76da7a87fd5afd5e180535a909907d631f6d1e3aa021e9ca4ce -> 484291049fe80389eef3a856024fc26f70a59a05c3a34048eaeafbc37b5ec7e4
supersession.v8.identity.ca5b43547ca2d4d7ce83 | value:governed-execution.nwp-rw0-c1-evidence-membership.v1:c1-section41-membership-golden.0001 | f55a4d11062704095a7555282df09882a8c0b8a563010e42a1fc36bfa962c5b8 -> 5a0e664074e92aa69360513fd022824a6a247db1f18dd92cc141679047620b6f
supersession.v8.identity.6223f2ba424a67c93579 | value:governed-execution.nwp-rw0-c1-relation-binding.v1:rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc | aad30741df200e662c014b136429b2bd607ee74bc6d3ab4c8c385e7a86824f5e -> fe561bb46937e51b68c0b271540214fc69c923694b0136d22c03f57d2366f3e5
supersession.v8.identity.4006c3b343ba5f250927 | value:governed-execution.nwp-rw0-c1-relation-operand-set.v1:rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc | 625f377bb200912c8332d1f7dd5692db08cfe7ff5bad79fd677e3d75e7b88bd8 -> 6a43b8cf16a2b91d69b568b7656401c60b1cf5f1a9440a230a867e9c75983c42
supersession.v8.identity.8192d56cba06299e59fd | value:governed-execution.nwp-rw0-c1-relation-set.v1:c1-section41-membership-golden.0001 | 18eea8978f058e7bf70f885f2e6e1cf0521d0a1eab5187ba249e3877c6e59393 -> d352f938938082da34bd4684c4485edb15c3584ed7d4acdbf47c3adbcc77a881
supersession.v8.identity.613fcd32a6814aaa97de | value:governed-execution.nwp-rw0-c1-section41-owner-family-graph.v1:owner-family-graph | cabeddccdfd5dbd45fa6f7192e73e17c3f5b84c536c9cad00708cc45d09868bd -> 08ace396f61397e1c262258396e9015472bbbb91fbfc842107e137125c6d391e
supersession.v8.identity.2e7e22f17963a14e0988 | value:governed-execution.nwp-rw0-c1-section41-post-execution-proposal-family-member.v1:section41-member-golden.0001 | ddb30a465fb79f12dc632ae1298e749c4500fd6dda5c52cbaab2b26f79441dbf -> 70dab00e12c79a58cf3a119a00dc1ad7c24efc008540fc5b4d46f88cd46e453c
supersession.v8.identity.00d2b8ed6b1c1f40ed96 | value:governed-execution.nwp-rw0-c1-section41-post-execution-proposal-family-relation.v1:rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc | 63cb63c7b1544350f5a0fc6b185cc35579ae344d969026f5ce4c5ae81df0d418 -> fc41b099330b711a66dc01329f29aeb6d9c4650c684f4a16dbdc9f433c4ea235
supersession.v8.identity.44e10a0706ba39465e89 | value:governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2:4846cba5d907899c14f1be0cee930bb0e233a89bad90533be6d06e59792cc554 | 4846cba5d907899c14f1be0cee930bb0e233a89bad90533be6d06e59792cc554 -> 4f3edc4737675bef15ae840bf78bf25b48fec61337e9b61755172ac502fd5b58
supersession.v8.identity.5a60e2a12a9f02be0d85 | value:governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2:60d8ea1b1e0fe7323d98fdd94e3313701c8653190ab906de7f470791f21042bf | 60d8ea1b1e0fe7323d98fdd94e3313701c8653190ab906de7f470791f21042bf -> 48673625531b9a40a52380415f0de0276b36833899be768d85bd6d663c4185f8
supersession.v8.identity.4bb6ee2191d601245884 | value:governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2:6e05195aee638103165fd3f8b20813b2bce99b87aefaf512d1f1cf67d477a82a | 6e05195aee638103165fd3f8b20813b2bce99b87aefaf512d1f1cf67d477a82a -> 8f788086365f87c8c6d027bcb4266031d88fce9f368ff8d34a5152f9116d6e17
supersession.v8.identity.430d2e8e8fc700bfd69b | value:governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2:af7fc6a489fd11252d0073a7d7624a00dfbf63f96d88528b63931f8f38dc5419 | af7fc6a489fd11252d0073a7d7624a00dfbf63f96d88528b63931f8f38dc5419 -> 68ce9c5579595a1013fc0eacc382db63b84143422eb13e942f9488e8b8c67d4c
supersession.v8.identity.59fc2ef302cb412bc7e5 | value:governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2:e3b605ae70c666e01ec288502be60cfd336271c6e67534b06dc2241346c60972 | e3b605ae70c666e01ec288502be60cfd336271c6e67534b06dc2241346c60972 -> e1c3fda055d4e77798af1f49c445aae8180c89241686e5b58b29567429772265
supersession.v8.identity.772b023856c798535ecb | value:governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2:ff49533d34a43b428870a86faf95de3b8226dcc33402b5b58ab9026738757438 | ff49533d34a43b428870a86faf95de3b8226dcc33402b5b58ab9026738757438 -> 296c024c7f46a30a364c435e8d882ed307abadf984359bf616ea535c2a9348ec
supersession.v8.identity.9d60a2a89fa2c0776e99 | value:governed-execution.nwp-section41-post-execution-proposal-family-projection.v2:section41-post-projection-v2.811f7717686c08611c6ae79e12798f8c3356dcfba88afa721dd65f3aa86c0ff1 | 906e665d78aa0d138292d6da5953cd2ee8c8b91d764f84e506fb3a718f75f02a -> 53811aabe4f11de3b46ce6c468e9ee397aad6ade828cedeeb8c959c7295bbff2
supersession.v8.identity.ebb2ca9a298b7d90f570 | role-resolution section41-role-relation-v3.002d6eab86d4c3cfcd493957bfeee99fcf446490bd20e82ea653e09f39d68be1 | c13dabad6169c25a3be4899eed1230400ae94f58b63a2a8855912f77703a17ec -> 23fdd36085218fd4a00089f05d8f7a36e87f4a71abeef4fe1a7da9b32f13894c
supersession.v8.identity.55fea7f53bd29fad3e09 | role-resolution section41-role-relation-v3.15ff2163388168f96cda6dba6f5b6669e317f4963697cee318840a1e5630e87f | 35a1d86f0cbb439cc4c07351e1157621b587b9f0f70f4ab94372bcd4b97ba192 -> deeb5398695f456f9a88fd8713a3808723b21855872499f41cf9e6cedb4db84e
supersession.v8.identity.53babeeb91620fd82a59 | role-resolution section41-role-relation-v3.5cf642bfaaefeff36e2393022af99e106c80cfc96fa0ee570c0356a9397e875a | 2d5826e9e786ff925c5dc25923ff8a65a1c32343db23e1fd7728ef7ee1c6cb70 -> 2352a98b805aa38ca27908b536662a5abefdb73bcdbc02c0497a55652337b491
supersession.v8.identity.2bbd00cf9aa89a265280 | role-resolution section41-role-relation-v3.7069bc824eae5124b00b567418f39d6871ba815460b7ab30b4170763115d7c73 | 3bf17ff2899b31e604498dde93cc91433a443dc4ceeb63597ea447dfce49f33d -> b248138e7b62aaec950e952139239ce939927f106704f56128819b6a72a96956
supersession.v8.identity.0c9ca25cafb9eda94683 | role-resolution section41-role-relation-v3.7fd1a947867ecec534c821e1e63a03bcb643439b80ce9c064b9477ec6a73142e | 09407f4aa69f475f85aaacd2695e5d237cddf6f4de766a5a7239edaf2367a798 -> c7bc917ebb8e5495034181124dc501a8f18b3da816fa0452d701ac1ee89ea18d
supersession.v8.identity.af9e84d3af3b51897da1 | role-resolution section41-role-relation-v3.a716795d5f16bf386f3e447aa59f8c5dba730f57b5c32bfa23bc4ca3496656dd | 807cdf833cae849e295cab9ed23dfc86822ffe6e3d74063437f8a0275d203f07 -> 2e80c881bb6383eeab68d47b00c92c810adbeb145fc7a071f552343ebfbc438d
supersession.v8.identity.f4a0fab59674204df839 | role-resolution section41-role-relation-v3.ad2356f621b65a98f5aef99425a7cf9fad04a9ca1f5cf3add021e82213aa51c6 | c2608f4bd1281ede1c7aa029ceac4844f7da7c05b6acb118fb76d8d1d15e92da -> a6c5fba2b3572683f63dbd6a9538502d9c60f462e210142214eb28cef6563779
supersession.v8.identity.3fc393dcb212c9f7b6bd | role-resolution section41-role-relation-v3.e80f1b1d426c17359b1a96b52f9e172e28d8b1f8e87b8482523d35628c272656 | 334be3fc519017a64e68e4a9b1e771a9776fa2318f174d64befb46388c618222 -> 8e01c96f87bfe23765657431a1ef2f8593adf63a5bed063f95381c05604214c6
supersession.v8.identity.005cf33239561978d30d | role-resolution section41-role-relation-v3.ec07d909539b37c9caa35ca8602293ada92c7a601260376773b5003ecfa19422 | d18f0a13ec51c19473a890fc74554a5c528d7fe35f648d0b3122111d732d2808 -> 861db4e0e9b49af1e922fec259d22aad0e5a743eed3fc61d0addc275affb735c
```

Semantic supersession count: `42`.

## Record-payload supersession inventory

Format: `ledger ID | record ID | V7 payload SHA -> V8 payload SHA`.

```text
supersession.v8.record.b2ec75f276e7ea1e4549 | assurance.A047 | c3bb5502e9e83795a1f87d3453836cec04ff7dd809ba74519d0b3f7bdfad77d4 -> aee381f90f3b5165b99bc0f22fc9b38c4242bc540d02711d8176c3772822334b
supersession.v8.record.a446ec880d3860263a76 | assurance.V3G006.evidence-set-owner-module-substitution | a650ff4e8a89350e9cab7542670aa451ac40a68d96693d1912763d2e0ce688d7 -> 537a38ef23632b5c9af6d558b116afa510ad8a5b0c18cba199fd966abd6a63b9
supersession.v8.record.47e30c3ac4689e07087d | assurance.V6R001.rank15-current-owner-cascade-stale | 9d763441a61183afd0343ab41e293e1076d9c2a8f93f266baff3daefe36fc8ac -> d173ed0767a4504cafe24cbe73a1ca88e48bf79e93f155715795e2d02c7ce1ff
supersession.v8.record.e35d3ab17b474dc26c08 | golden.V09.model-input-binding | f6fa9a2ca126decd46afb9cb28c39260664045805d94cae22e9cef28e9032e05 -> 05fd835e6a6c9354c882fa3f2c72f60176dc200b09086b2407a607039e7ceda9
supersession.v8.record.dcbbf8b1f78f20e7685e | golden.V22.primary | 743939c44cf1767895ffa5f53879c0c914cd223ff361cf45429d5bf66ad65c01 -> c2dec4155f84e52dd88e64f7ec664eb19667da3c49ab61aeae42c0fa9688c652
supersession.v8.record.31f01237612baba5f78d | golden.V23.projection-evidence.002 | 920a751a78ab3a2103b4df28cadf53771241c4a0739d5a174438a410e4677be9 -> c503c1d3879f3f276b26c49190eff327f593e27cb05a9e44aadaf414ac86b4a3
supersession.v8.record.f014cdb1aa9eb445291e | golden.V23.projection-evidence.003 | 0d6705750f314a3946f876dc0765aed025c462239b2cb8adc996672902cace79 -> dfab3e29bb089c5b4763796c8957fc381423dca7494d40f0f71c58b03cb346ba
supersession.v8.record.d78542193fc4abd8585f | golden.V23.projection-evidence.004 | c412a71ad73e9fc51046b067538407f7f68f4c58bc3ac1f48ae06a447401cba7 -> 6215d2f80e299ea89d78c3fa7ed8ef939d18b8f00286ec5584d68a9f32511ed4
supersession.v8.record.305fb170ff7e985a44e7 | golden.V23.projection-evidence.005 | 65e8136dd08ab530f902e180f7939dd810aa06d55cef9211615daa6efb6d6a1d -> f00f4c1c4ce98a890148b88aa658909bfe3acc5080218cd7ad42db54be8ffc74
supersession.v8.record.86f0dbfa7e57d446eaa0 | golden.V23.projection-evidence.007 | 679d0f52df307366202f726078c545364ceea0a93d3c5f296acf504929b6ba82 -> 48b83626fdedc3c8d2c677c3efe6d60eaf8f2576e66771dff606c5c9f9ebcd0f
supersession.v8.record.61ba064a71caa20537f1 | golden.V23.projection-evidence.008 | 57c0ae1cb95ec12ca3a50866347dbf0891f01b57edc257c99d743fb0e9057796 -> 09a6e0989fbdca6dce42f46ce13f845f1779a65777012ec92dafae97975a3d2f
supersession.v8.record.e8c4251075638c897a7f | golden.V24.role-resolution.05.candidate_capsule | 6a0da2bc0dbdb810a537ad77a043ab98c5857f4742c16483ca99bbc72de55efa -> 0ed4f66d16706ae47c8437585b7a2901de8b3c6e243bb95a78997479e707bc3b
supersession.v8.record.ade8f46e5fd8fdd2c9f4 | golden.V24.role-resolution.06.worker_result | 8b7bc36fda7cbc15750867ef779e3631f32899d9f34989caefde1f8882a48095 -> 5aba5d1a250d13e6c17c86899f802e73afc9a7623369ba6475ba3f72cd948c98
supersession.v8.record.482ecf6096b30729d39b | golden.V24.role-resolution.07.validation_result | af34bc82a44d16ba7796b7d47f1cbdeef6ce0a4ac36b8a2751739929a8b4617f -> 48e632026247193f273a32498436bda02ce2f6893d505b4b5ad696f58eec4777
supersession.v8.record.e317997229057be4fbf9 | golden.V24.role-resolution.08.independent_review | 980e416ec380d6b982270e496bca40aa05cbc6872114f8b68e63530bf4042cd2 -> 8dcfb21856225b2bc6d8e0a8825ef00a965211a57e23b6db9507aaa2b6252781
supersession.v8.record.ad085f9352a0ba1fe798 | golden.V24.role-resolution.09.standing_policy | b831a24153d1b04fd9319530c15e484e378e5a57d17b1d837e96481de317195f -> 86e220687ff258b69e53cba608e71deac03471a278b6746bd3565d9808ef734d
supersession.v8.record.b3fa05a74ff396fc4349 | golden.V24.role-resolution.10.risk_lane | cb67269270556516604fc4b2e5588c74c7f7f067944531c5a45446888d38d107 -> f2c6884c03caf367108bafe9b665365513446e65d39802ec63eae08817330133
supersession.v8.record.b29ae196fbe880f16813 | golden.V24.role-resolution.11.authority_currentness_attestation | 084603f23aa6d85f4e2a33e566ccb32b4fd3fb3b0765b5e010e5b6cf2ab7599c -> 95dc5c546544b7e679ac319c276a36c2e799eb599f2e788fcdf13db03843e57f
supersession.v8.record.d62c32aa65d2e7edad7a | golden.V24.role-resolution.12.global_stop | f0c5fcc6360b87298fd823324922bf24659bae161e236430801fca34014122b3 -> 8891d54826e8fe1d15eae7e60ab1d3b706794f16b870b06f41f131a34f7dc177
supersession.v8.record.d04165cd76c910765f38 | golden.V24.role-resolution.13.effect_ceiling | 8f14dd16ae270664c777c06edefb61a10bcc954c51d9f42e714c310315e3b385 -> 49de3459baeb1cb334afa2b88c5eb1090ef5b94a562fb458fa1dcb3b722b874d
supersession.v8.record.4f2ab801a7305e53728f | golden.V25.primary | 9fc1b38a08b01da7e10ed2c947e8d7798a35d97e4f7ffd4c3d5b7b18516cce7d -> c3cdad3848e813109ac3898f382d7691840e0e3cb9fac97d31c168145181589d
supersession.v8.record.4306604df2cae6d2d4e8 | golden.V26.closure-entry.007 | 3347cd6c91abc0a66a7e9ff451b05e5ea809753123ee4f2c9c477d2eb3fc6499 -> 12d5bd97dd3b5da842308ba37c108eb9bd5e2dce73f36f57b7c64823b4bd2302
supersession.v8.record.90df73495fa47d020efb | golden.V27.active-stop-control | 28125856ac11c0824a2b4def8e9f2568db6cca51b506a6587686e496d62520d0 -> d94a59ed00348c27c61860b841d00015eeaf0f1512750741dd480d9d62e0ba03
supersession.v8.record.2fe38177f1fe430a3e3b | golden.V27.primary | a8f62c91debf66faf92b8de46176bba5a2e0418c81240526da31b1d60915f4df -> a6b8ef18013f3e635fc05a10958097bd439bb1b2bfe2f70da6ed5eb6d8647e8e
supersession.v8.record.a8d45c46db4846d7ac0b | golden.V29.primary | 1ffb7e2e3cc9b1669d6646d708bf617dd67260cc71314c6d5c5e1d94570cc0f4 -> 2144a6623c8a1782353444a07b773a44a796a552d623c6e1f2b3c85fd272a9c4
supersession.v8.record.314f37fc959c9d8a1482 | golden.V31.primary | a2b600dd754a822d5699dfd36d0526d191228755ae4556fa66f96d58e3bdaed0 -> fa3c94c05b94dc8216d7ab3be8d06e84f649f36ac2c90db98014bb9ab1562610
supersession.v8.record.bb6a07df1e8079f8c354 | golden.V32.active-stop | f6af3f51c11b2ea204ea7483b946d7f3189c6a82d162dddd320d9775df62f656 -> e4e8bf3560d8b9177511417572833cf4c7e31adfac64eefde0e19f111a51acfd
supersession.v8.record.9aab450a92e72f417671 | golden.V32.primary | b226f91d8e90d6ed7de9ba92595d444e74866d9d333e50ef0d5d0036841c39e7 -> 73e98a4a9e4e655364a616ab858d6f82b87a5f1da85cc2d3ca89cec5d80dcb9d
supersession.v8.record.f303135a5383c240a474 | golden.V33.primary | 8416fb7c82188dad912055e8a02fc55c26213e3b2f1c22ec44347e268c85311b -> 3aa8ee28202b9fa006fdd1bd2be9dc6ecd2b5aa51f8b1b5310712d18164a58e1
supersession.v8.record.5738058077830e982d71 | golden.V34.primary | cef96d0634a1c0db8073db3f9cac92bf94842fb7cf5ab8333dc07a1b71964778 -> c4cd0ba21f90947d11b85d8145e614640b1db3bd8ae26df9b0dc7e896947efa4
supersession.v8.record.f224d0cf096560d89793 | golden.owner.evidence-set | 3d237a985f13270875952e3a9a8aa189005743db5f4907e3a47e722dc4419d7f -> 4188871fa3cdb009ccc812dffeb9403592b3cb77b4b956436ae54bbfee863bfe
supersession.v8.record.07333bdb0e7cb96839fd | golden.owner.owner-family-graph | 47b4fd962e8e6b05e2e5e2dca1e8b366fd639d02d91575b346aebbf5f14a29df -> 951460086d5c208d6dc9250aaa594d9c45e4c77c1625222901087ef283534d5d
supersession.v8.record.e2f4ab4252294846461e | golden.owner.proposal | 1776fa366855dc7577375bcff74267a957fd47f7e3c805d21ee6bb0542d0640b -> 631e6c2edc58178cf6334c4cad4ae4eb6674670fe1223d88f9d62b667adb89d0
supersession.v8.record.2fc5481cea70622e9f98 | golden.owner.proposal-evidence-row.07.validation_result | 314d6846495f241da35c5e0167124b0dae4734d2fd98e4b10285d0fdf8459b9a -> ee099f837db91a438b04624aa28661f2406cb312ee8e3dcbc8ccd83e5f510e66
supersession.v8.record.a572d992fef936d40ccc | golden.owner.proposal-evidence-row.08.independent_review | 616705ca8ed91cae53e2d0e951935dd2e0c91dda8b965753bf89bf54889847a4 -> 9826e9c9239d092d7da384432936221719034ebd86ff6767295587095f5eed90
supersession.v8.record.31e64e34efca1ce64709 | golden.owner.proposal-evidence-row.09.standing_policy | b715f933574bd2cfeb9ac5693a391f86476380d0f0074564bd78f43a685ee3a5 -> 6b1ab3032130ef2bd38bc02894524243d66b575ffddf94e4b654b21836ba626c
supersession.v8.record.7a5084a0d896206a0e1e | golden.owner.proposal-evidence-row.10.risk_lane | 82f39a56b0a5927969d50e6565fc1d5be77f1dc9d1714789e8db51b735c82acf -> eb446c6b4b3494156d409bf306e7a5eee41730c4a30c2652296f2abc6e199031
supersession.v8.record.6653a5f64f91d54c5873 | golden.owner.proposal-evidence-row.12.global_stop | 06d5ee7f43e33182b72cfb61f5f734f6d4a4a4c75c288292b1468791cf84b285 -> 15ddd91dcd75400b548c78d6681dcf8878379b11d02b563fc95cf37d96906458
supersession.v8.record.e583ca82f4d1b31081fd | golden.owner.proposal-evidence-row.13.effect_ceiling | 4658975f5823efb9c87581af829523013bcd6e1bdfdf2b8d57ad51cbbbcc6f23 -> 0bb0dabd1c28735daa4de1fce683ae02122a170ee800920f9cd7552343a279a0
supersession.v8.record.d175a0dc29c968e7ab47 | golden.owner.rank15.relation | 67a044c165c116a0fbc5a4a004631876a81f7219740c43f840cbc3d04b0f219a -> d1babf4cc7ec20e5b647c8314d7cab447b28b461c448be75fce9fd7d2ef5ea33
supersession.v8.record.028ce3fd85ce8c5ea6c9 | golden.owner.rank15.value | 03e80995170e4131d1fcb37dd7a0257191960dd479192f5cf332f8476617a0da -> 84121db0a6ab81c15211249c0fb5eb666b72d48906a0bf4318d95fbe4e2c7488
supersession.v8.record.3a0e3d2fd8998ee7fc5d | malformed.V3G006.evidence-set-owner-module-substitution | ff039717c852a61b87f89e7cc3b0737b28be4d96e7cf12911e8a2c99eabe90f0 -> 803616fbe2b6b35aab92c45a4b7c9f51b28a5cd1538f75e1347cfe0b90b48efc
supersession.v8.record.cc69022c10d13f2f615f | malformed.V3G028.snapshot-rank1-membership-substitution | 3a66f4197f34fe41c8ef8e3f429873dfb8ebaf5bc67dce607809c39bb975032f -> 4e68fa9f3bff9f4e5d5994727f6155027095f3029c59c105c203f6bd5ca4f699
supersession.v8.record.714c42aac428ff869100 | malformed.V3G029.snapshot-rank15-membership-substitution | 4aaaff5691ad863dd06df91643be34d1a38e7285b88873b227c1df0bd6b8ca59 -> db0d812e856e09c5480f4e2de1c529c74e6a501175d0547e5ca47eeb08e0e3ce
supersession.v8.record.92d458d15dbc63e7794d | malformed.V3G030.snapshot-external-source-substitution | 10e4ba1995a2a909b4584084a7a2fcb12bb4e58433c5f18b56916f1cf7be8104 -> 39a4f6d99499b57ddedfbb17cbcb6e2f673130f9802487a4908e601432261da5
supersession.v8.record.f021d9f81832c5153f89 | malformed.V3G031.snapshot-phase-k8-mismatch | 61c12ea2cd8879b7f7b79ad392adc1d6517bec0fc5bf4ca7f37fc54b3bee155d -> f282667da7cc7b496eeb82c51963219a8b5dd1dfb327bc1d8af3bdb6b539bf11
supersession.v8.record.dfd410f0a4053c37bba1 | malformed.V3G032.snapshot-required-row-missing | 23a3155243ca7853b3a7a7c97c898e49a0bad3bd750235617e95df4c52d9b2f9 -> 2e63ee4751982b896163ec6052f243cecc0802acce89eab7fa4c2bb5fc82c2f3
supersession.v8.record.837e0eda029d1df3047d | malformed.V3G033.snapshot-current-row-malformed | ae44b3570052d24d7ac71f8c93c87a5d9957babb07392beee76a5d2806769410 -> 3cee4a7d5b2dac8b2dfe216da0febc7c335635fd447e282afc85f1406ad439f8
supersession.v8.record.a550aa4de0a035cafbe5 | malformed.attempt-fence-expiry-substitution | 66c8a989c16f95c6c1190f69a7af2ec1ea42adec9d9ad008e215fdc67eef15bb -> 388b665c0e3a88467251fdcce1d672f601f2553756b320f80974ebdef827d2a9
supersession.v8.record.21cd18845871d0a12606 | malformed.global-stop-branch-mismatch | af1e62ffe65e69d8a994e9c65bec0b7f9f58aa62f2dfd04fcfd1b37ea67235e3 -> 24709816fde67dd66fcc0446dd5973926b5b5c681cfcdf873cf132fb1f2a85f3
supersession.v8.record.74157d91298a7856d2d5 | source-owner.migration0003-evidence-set | fc6e54559645afb53ce6c446340a9425189e55a6fa6462b35dfab2dc07e40c0b -> d2f87b8c38e9aa3a6c1c3a99f6d8b23cb7468b83812491e3b72341fc59abe2c3
supersession.v8.record.decaf297afc41bc41d38 | source-owner.migration0003-owner-family-graph | 69481d6b1f5195b14c81ce9810dcdafb5984f0696f900c1d86b965e3f014a202 -> a2d6ab4d5932034c79a42c9d1d61e0c5a01f9a887e0f6ac87b65730f3f13aa2d
supersession.v8.record.fea4dd9f8fbe157b4a03 | source-owner.migration0003-proposal | 6c184abd6dbe68a29db636e5562dcd239880811f48c7398c5f4f17494c7ff17f -> 660177a4c15f25bab40f21025a1c011e558323b9fa7ad96cad6e03e6ce15682a
supersession.v8.record.377c29b783dfce48beb7 | source-owner.rank15-section41-relation | 9617316b7649848b5543ea4a4bce18a450a00e370021bb68435b7bcea8b0f345 -> f99174a499c31d603958bc53d7960fb818697d54f2cf6353da8197776386254a
supersession.v8.record.fb8de0f4543a4bc5d532 | source-owner.rank15-section41-value | e2bfc3177331de57f782b9e12b90306ec68f120505eed78bff8d5ff2ed11405e -> ee58149ab6f01ba1bb23389245f48d63fcc800ffadf88f4871b019b56c810f73
```

Record-payload supersession count: `55`.

## Verification and preservation results

- Duplicate-key rejection and canonical outer/embedded JSON verification: passed.
- Dense indexes, unique IDs, closed ordering, payload lengths, raw hashes, domain digests, aggregate, manifest, closeout, and whole-file hash: passed.
- Schema/profile validation: `312` current schema-value instances validated.
- Unchanged-payload guard: passed.
- Transitive identity regeneration: passed.
- Package-wide supersession scan:
  - Population: `1,660`
  - Unique superseded identities scanned: `839`
  - Permitted malformed-only occurrences: `13`
  - Forbidden occurrences: `0`
- Six stale row-digest scan: zero violations; non-ledger occurrences exist only in `malformed.V8R001...`.
- Wrong-owner-module scan: the sole current non-ledger occurrence is `malformed.V3G006...`.
- Duplicate exact semantic supersession pairs: none.
- Exactly fifteen C1 evidence kinds remain.
- V35–V37 remain absent from current schemas, goldens, allocations, and implementation scope.
- The V7 global-stop precedence repair, active owner, active snapshot, clear/active V32 controls, and causal active-stop malformed vector remain valid on the regenerated basis.
- All other preserved V1–V7 repairs and accepted contracts remain intact.
- Temporary root mode: `0700`; deliverable mode: `0600`.
- Disposable scripts removed; the temporary root contains only the V8 artifact.
- V8 is visibly attached through the client-facing filename link above.

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
```

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V8_MIGRATION0003_FAMILY_REPAIRED_READY_FOR_INDEPENDENT_AUDIT
