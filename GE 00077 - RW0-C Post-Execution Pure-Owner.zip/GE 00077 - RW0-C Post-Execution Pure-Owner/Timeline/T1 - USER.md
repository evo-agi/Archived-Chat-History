Here is Codex's response:

Completed and independently verified.

[Download RW0_Post_Execution_Canonical_Audit_Package_V6.jsonl](/tmp/rw0-v6-repair.OhtkzP/RW0_Post_Execution_Canonical_Audit_Package_V6.jsonl)

The link above is the client-visible attachment; no private reconstruction path is offered as the deliverable.

### Input receipt and baseline

V5 attachment receipt:

- Filename: `RW0_Post_Execution_Canonical_Audit_Package_V5.jsonl`
- Client-exposed runtime path: `/Users/ds/Downloads/RW0_Post_Execution_Canonical_Audit_Package_V5.jsonl`
- Size: `2,409,171` bytes
- SHA-256: `92e3d5c9d1da29c225c5ffafc4b69d408a1780cee12d0488e7ff8d507c651d44`
- Logical records: `1,489`
- Final newline: absent
- Content aggregate: `3267e8652d5f512379a9df3df466dbc31a5966273ea5315e8bfa79d9b242814a`
- Record boundaries and all per-type counts matched the fixed-input contract.

The runtime path came from the client attachment context; no predetermined Downloads location was required, searched, or substituted.

Repository baseline passed initially and at closeout:

- Branch: `trunk_dev`
- HEAD: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- Tree: `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0`
- Sole parent: `047563de5a443b0f8323401c92979ae2e444d2ed`
- Subject: `feat: implement RW0-C1 durable evidence (#7)`
- Upstream: `origin/trunk_dev`
- Ahead/behind: `0/0`
- Worktrees: `1`
- Worktree/index/untracked/unmerged: clean

### Finding dispositions

- `V5-AUDIT-001`: closed. The complete direct and transitive rank-15 identity cascade was regenerated from current source.
- `V5-AUDIT-002`: closed. `assurance.V3G012.rank12-cascade-stale` now uses symbolic target `distinct_stale_relation_set_digest`. The concrete stale identity remains only in `malformed.V3G012.rank12-cascade-stale` and its supersession ledger entry.

Independently reproduced current-source rank-15 anchors:

| Anchor | Correct digest |
|---|---|
| Owner-family graph | `cabeddccdfd5dbd45fa6f7192e73e17c3f5b84c536c9cad00708cc45d09868bd` |
| Wrapper | `ddb30a465fb79f12dc632ae1298e749c4500fd6dda5c52cbaab2b26f79441dbf` |
| Operand set | `625f377bb200912c8332d1f7dd5692db08cfe7ff5bad79fd677e3d75e7b88bd8` |
| Relation | `63cb63c7b1544350f5a0fc6b185cc35579ae344d969026f5ce4c5ae81df0d418` |

The relation reference remains:

`rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc`

Downstream source-derived anchors include relation row `aad30741…24f5e`, relation set `18eea897…e59393`, admission graph `76d23e2e…ca4ce`, and membership `f55a4d11…2c5b8`.

### V6 package identity

- Filename: `RW0_Post_Execution_Canonical_Audit_Package_V6.jsonl`
- Size: `2,466,932` bytes
- SHA-256: `ebae5f77865f22adec3a5fdc45ed94d928c89d783eb11185a85405643cdef881`
- Logical records: `1,547`
- Final newline: absent
- Content aggregate: `be7960057fc4bc3e7a8f1ebba601b93f760b0abd8542dcfe10b4145b5b130759`

| Record type | Count |
|---|---:|
| `package_manifest` | 1 |
| `source_owner_binding` | 23 |
| `value_schema` | 44 |
| `behavior_profile` | 28 |
| `golden_value` | 196 |
| `malformed_vector` | 90 |
| `module_allocation` | 44 |
| `import_edge` | 31 |
| `equality_matrix` | 36 |
| `assurance_case` | 117 |
| `supersession_entry` | 928 |
| `remaining_seam` | 8 |
| `package_closeout` | 1 |

### Record delta

Changed existing record IDs: 31

```text
assurance.V3G012.rank12-cascade-stale
golden.V22.primary
golden.V24.role-resolution.05.candidate_capsule
golden.V24.role-resolution.06.worker_result
golden.V24.role-resolution.07.validation_result
golden.V24.role-resolution.08.independent_review
golden.V24.role-resolution.09.standing_policy
golden.V24.role-resolution.10.risk_lane
golden.V24.role-resolution.11.authority_currentness_attestation
golden.V24.role-resolution.12.global_stop
golden.V24.role-resolution.13.effect_ceiling
golden.V25.primary
golden.V26.closure-entry.007
golden.V27.primary
golden.V29.primary
golden.V31.primary
golden.V32.primary
golden.V33.primary
golden.V34.primary
golden.owner.rank15.relation
golden.owner.rank15.value
malformed.V3G028.snapshot-rank1-membership-substitution
malformed.V3G029.snapshot-rank15-membership-substitution
malformed.V3G030.snapshot-external-source-substitution
malformed.V3G031.snapshot-phase-k8-mismatch
malformed.V3G032.snapshot-required-row-missing
malformed.V3G033.snapshot-current-row-malformed
malformed.attempt-fence-expiry-substitution
malformed.global-stop-branch-mismatch
source-owner.rank15-section41-relation
source-owner.rank15-section41-value
```

New record IDs: 58—the following two evidence records plus all 56 supersession-entry IDs in the ledger below.

```text
assurance.V6R001.rank15-current-owner-cascade-stale
malformed.V6R001.rank15-current-owner-cascade-stale
```

Retired record IDs: none.

The new assurance uses four symbolic mutation targets. Its paired malformed vector carries the concrete stale V5 graph, wrapper, operand-set, and relation identities and expects `rank15_current_owner_cascade_mismatch`.

<details>
<summary>Exact 25 semantic-identity supersessions</summary>

Format: `entry | superseded record | old-ref@old-identity → replacement-ref@replacement-identity`

```text
supersession.v6.identity.05244f51fb83e38ab01a | value:governed-execution.nwp-rw0-c1-relation-set.v1:c1-section41-membership-golden.0001 | c1-section41-membership-golden.0001@f0735704326de49ff6ebf37beec3d2a4bd012b4be9e8815ea47d81cb3bc278f4 → c1-section41-membership-golden.0001@18eea8978f058e7bf70f885f2e6e1cf0521d0a1eab5187ba249e3877c6e59393
supersession.v6.identity.075f790ec2ae24af3e10 | value:governed-execution.nwp-rw0-c1-evidence-admission-graph.v1:c1-section41-membership-golden.0001 | c1-section41-membership-golden.0001@5a4793f2aa6d5ac1b26c1e7fe7b2f266dfab766cb0a85b77048a495045c12b16 → c1-section41-membership-golden.0001@76d23e2e5cb3c76da7a87fd5afd5e180535a909907d631f6d1e3aa021e9ca4ce
supersession.v6.identity.07d9e4c38affcfede000 | value:governed-execution.nwp-rw0-c-proposal-evidence-currentness.v1:rw0-c-proposal-currentness.c17086130971486f54df03b96a126518970e778efa7a3e23af42d0c4dc280bbc | rw0-c-proposal-currentness.c17086130971486f54df03b96a126518970e778efa7a3e23af42d0c4dc280bbc@03a103287723dc598e2c1311a87cffbea625b51202532ef8be9d5f4d3c0eaa94 → rw0-c-proposal-currentness.3d4f47603975107e790d314ea9a92166f65e1858c3dcbf57cd896a6c299e14c2@3a12148478f12386be2f5a56a4c8d1a2b73dbb8f1a86377eebac01b0e1e44917
supersession.v6.identity.0ae1332d0b30ce869f72 | value:governed-execution.nwp-rw0-c1-section41-owner-family-graph.v1:owner-family-graph | owner-family-graph@0fa51721ee8fec6c0a74d9b44fd87de8d7e43875bd818b7058022765db798fbc → owner-family-graph@cabeddccdfd5dbd45fa6f7192e73e17c3f5b84c536c9cad00708cc45d09868bd
supersession.v6.identity.0f264bfa890c29e15140 | value:governed-execution.nwp-section41-post-execution-role-resolution.v3:section41-role-relation-v3.870c1b30e5bff79a4b5130fd37dc25e9f032bf8a47f5c5480243aada39437f9d | section41-role-relation-v3.870c1b30e5bff79a4b5130fd37dc25e9f032bf8a47f5c5480243aada39437f9d@460c56af2d1964888e5b06834cf24ee16d16ac9e8101fa182001d5de54326661 → section41-role-relation-v3.5cf642bfaaefeff36e2393022af99e106c80cfc96fa0ee570c0356a9397e875a@2d5826e9e786ff925c5dc25923ff8a65a1c32343db23e1fd7728ef7ee1c6cb70
supersession.v6.identity.17e35fccd385da1ebcc6 | value:governed-execution.nwp-section41-post-execution-role-resolution.v3:section41-role-relation-v3.b2b2f3b1290e973707e6d1580d8785be223abda9ee2cbe283531f0b638432b2d | section41-role-relation-v3.b2b2f3b1290e973707e6d1580d8785be223abda9ee2cbe283531f0b638432b2d@3c1092ec13f33d046653815e43ffc014c43c52bfb6f524b73c6a02cc29ca3a1e → section41-role-relation-v3.ec07d909539b37c9caa35ca8602293ada92c7a601260376773b5003ecfa19422@d18f0a13ec51c19473a890fc74554a5c528d7fe35f648d0b3122111d732d2808
supersession.v6.identity.250c9084fc0654a62044 | value:governed-execution.nwp-section41-post-execution-proposal-family-projection.v2:section41-post-projection-v2.e67900555f557a6767f85072bf07663a4ec90f02523279e08f0abe328607c2f6 | section41-post-projection-v2.e67900555f557a6767f85072bf07663a4ec90f02523279e08f0abe328607c2f6@a88ebc56822e21344beb4404a7e28642ac65a40ee2d1cc2826d4ea95a709e7c5 → section41-post-projection-v2.811f7717686c08611c6ae79e12798f8c3356dcfba88afa721dd65f3aa86c0ff1@906e665d78aa0d138292d6da5953cd2ee8c8b91d764f84e506fb3a718f75f02a
supersession.v6.identity.312e8ac75ecb79e52a6c | value:governed-execution.nwp-rw0-c-decision-time-authority-branch-matrix.v1:rw0-c-authority-matrix.e857fc8b2ad7d40f353470ba92c72782689c94687e7a7138f9cea1d14663e6e0 | rw0-c-authority-matrix.e857fc8b2ad7d40f353470ba92c72782689c94687e7a7138f9cea1d14663e6e0@edb9be82afed2d37b44c6880a9c31e5678d2032189ac3e8813c127197618ce3c → rw0-c-authority-matrix.43688fd29a4f8e82eaf96a9c5d5f051953e77876a99be7dac38ef64cb2d6f4cd@3370d1211cbf49ad8551621599a07e657bea855d0e07871f03006e2cdba736ae
supersession.v6.identity.33ff71e13a85a7433914 | value:governed-execution.nwp-rw0-c1-relation-binding.v1:rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc | rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc@e276138337a3e44a2ba2aab83e4fc40a95f320977fd57b00978b16c8f3ed3d96 → rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc@aad30741df200e662c014b136429b2bd607ee74bc6d3ab4c8c385e7a86824f5e
supersession.v6.identity.3790960eacc8f057f535 | value:governed-execution.nwp-rw0-c1-section41-post-execution-proposal-family-relation.v1:rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc | rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc@5692411f6167c68c3ce7a157eae40ff75471ad7edd6dc96eec1323288e976794 → rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc@63cb63c7b1544350f5a0fc6b185cc35579ae344d969026f5ce4c5ae81df0d418
supersession.v6.identity.382fcdff17bb51d5730d | value:governed-execution.nwp-rw0-c1-relation-operand-set.v1:rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc | rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc@09ae64f5313d00c7cbdbfaebd432556b53d0c5e31e3e31d2c68bfebddd340d81 → rw0-c1-relation.6f622bd1797bdd4804ad300269113f0322f8147b2fac4796e6d7c42b363639dc@625f377bb200912c8332d1f7dd5692db08cfe7ff5bad79fd677e3d75e7b88bd8
supersession.v6.identity.39682ad9c0689d1ab9a6 | value:governed-execution.nwp-section41-post-execution-role-resolution.v3:section41-role-relation-v3.d740a8a7ef24d226ece23406b0ef682963a6a71fd6849d5bff1fb6d0aa2a8881 | section41-role-relation-v3.d740a8a7ef24d226ece23406b0ef682963a6a71fd6849d5bff1fb6d0aa2a8881@32f969583e6c8a14691170326c885d83ec8e7a2cb3f31101c9dab4ec8efb0a2a → section41-role-relation-v3.7069bc824eae5124b00b567418f39d6871ba815460b7ab30b4170763115d7c73@3bf17ff2899b31e604498dde93cc91433a443dc4ceeb63597ea447dfce49f33d
supersession.v6.identity.3e98e8f331858bf846a8 | value:governed-execution.nwp-rw0-c-recommendation-consistency-evaluation.v1:rw0-c-recommendation-consistency.caad7cf2495f6f7632f6c1c8e2a07b2a4ca0174853ea82f903cd9c365efb8722 | rw0-c-recommendation-consistency.caad7cf2495f6f7632f6c1c8e2a07b2a4ca0174853ea82f903cd9c365efb8722@77d3c5a8a475ab4ef8109475a7ba2cb282ff596a1afd7ed895b0cf7c6932f672 → rw0-c-recommendation-consistency.b8e7e891636e438d918eb7bd9dff51a377c76bc24370126ad2b06195c4460a98@5a1b06548cb054ca9aa6bbdc5e1feeed8e4a005f4b93a54887edac59040c2b5e
supersession.v6.identity.5f94b0a7dca9b20468b7 | value:governed-execution.nwp-rw0-c-decision-current-snapshot.v1:rw0-c-current-snapshot.cbab4fd06f5caed9425002b3e6d40485d96c582a71bc6e72ddb3a142055f559a | rw0-c-current-snapshot.cbab4fd06f5caed9425002b3e6d40485d96c582a71bc6e72ddb3a142055f559a@98de72b9588783d5e341771b8fdda9d82bf874c2a75e89ba24b61bf4fad1599f → rw0-c-current-snapshot.cd16d38a0ac8d7abfe8fa49488b84d06044b4f23441d725f550f6d553adbb068@d4eeef74c01ab30f6b2746fe222a54e7fded87872502d03caa4e9ab16ae907a0
supersession.v6.identity.72f65ae9e193f1810d29 | value:governed-execution.nwp-section41-post-execution-role-resolution.v3:section41-role-relation-v3.4917a25d16ee164aa9c651ad2ba5a7e4b21ab4192383937c693eab4b8b1245b8 | section41-role-relation-v3.4917a25d16ee164aa9c651ad2ba5a7e4b21ab4192383937c693eab4b8b1245b8@17097c4a6abb7582c7a99dad1a0cbd2fd39445f3ce44f18fe7b36bce54e60fc7 → section41-role-relation-v3.ad2356f621b65a98f5aef99425a7cf9fad04a9ca1f5cf3add021e82213aa51c6@c2608f4bd1281ede1c7aa029ceac4844f7da7c05b6acb118fb76d8d1d15e92da
supersession.v6.identity.a580dfdce43e41425e36 | value:governed-execution.nwp-section41-post-execution-role-resolution.v3:section41-role-relation-v3.3d62a209371e0e8fd47e16354f61880cd322242266c2a376be9a5cdbee593747 | section41-role-relation-v3.3d62a209371e0e8fd47e16354f61880cd322242266c2a376be9a5cdbee593747@2c144a574a77145b3e623479d68e413b29792a6959413790c89bf3ab06b48fc8 → section41-role-relation-v3.e80f1b1d426c17359b1a96b52f9e172e28d8b1f8e87b8482523d35628c272656@334be3fc519017a64e68e4a9b1e771a9776fa2318f174d64befb46388c618222
supersession.v6.identity.abe29f802d7ae658778b | value:governed-execution.nwp-section41-post-execution-role-resolution.v3:section41-role-relation-v3.b969345af7cce18482655aa1175cd70bc2f4eaaa66cddac6834e3509d5e6289b | section41-role-relation-v3.b969345af7cce18482655aa1175cd70bc2f4eaaa66cddac6834e3509d5e6289b@649ab6b1eaf6fe55b1980a4136ecd5124da361be13ef686b07c2fdbbc5a242db → section41-role-relation-v3.002d6eab86d4c3cfcd493957bfeee99fcf446490bd20e82ea653e09f39d68be1@c13dabad6169c25a3be4899eed1230400ae94f58b63a2a8855912f77703a17ec
supersession.v6.identity.b3c02ad8a3bddbda45de | value:governed-execution.nwp-section41-post-execution-role-resolution.v3:section41-role-relation-v3.d7b7f41ecb85933d84fc54cfddc22cf57e1c77ff5aee2b2b8dfc27fcecfe6cb6 | section41-role-relation-v3.d7b7f41ecb85933d84fc54cfddc22cf57e1c77ff5aee2b2b8dfc27fcecfe6cb6@0434cf59880d409aaadacdbc809e8172e038175f9aa45e351096602e25b5e846 → section41-role-relation-v3.7fd1a947867ecec534c821e1e63a03bcb643439b80ce9c064b9477ec6a73142e@09407f4aa69f475f85aaacd2695e5d237cddf6f4de766a5a7239edaf2367a798
supersession.v6.identity.bfb0fb7ef3dbec388c20 | value:governed-execution.nwp-section41-post-execution-role-resolution.v3:section41-role-relation-v3.1b12ed99eca0315febaa2f87c39de56a109bc89951070e99258ab455e8a846d7 | section41-role-relation-v3.1b12ed99eca0315febaa2f87c39de56a109bc89951070e99258ab455e8a846d7@eff1a433718b89f973395cd8ed310c97d8d4ef06bb72a72eb72b4a857c78854f → section41-role-relation-v3.15ff2163388168f96cda6dba6f5b6669e317f4963697cee318840a1e5630e87f@35a1d86f0cbb439cc4c07351e1157621b587b9f0f70f4ab94372bcd4b97ba192
supersession.v6.identity.cd379d4e8bbbca25664a | value:governed-execution.nwp-section41-post-execution-role-resolution.v3:section41-role-relation-v3.581fe881dfffb64ded0916672fc4191ca4bbf0d550a4c640f63d4a03d1bb4267 | section41-role-relation-v3.581fe881dfffb64ded0916672fc4191ca4bbf0d550a4c640f63d4a03d1bb4267@d328ba6b9b5fb52b97d13c7eedffb9c2e49ddc077586e6b2d5b1ec3438fc315f → section41-role-relation-v3.a716795d5f16bf386f3e447aa59f8c5dba730f57b5c32bfa23bc4ca3496656dd@807cdf833cae849e295cab9ed23dfc86822ffe6e3d74063437f8a0275d203f07
supersession.v6.identity.d2dc8a760a63739ae7bc | value:governed-execution.nwp-rw0-c-decision-time-source-effect-ceiling-branch-matrix.v1:rw0-c-ceiling-matrix.4b49111cf85bd3fbedbf2ce9ac8dae578b462b1c2773a672fa066c8b77cfe480 | rw0-c-ceiling-matrix.4b49111cf85bd3fbedbf2ce9ac8dae578b462b1c2773a672fa066c8b77cfe480@1346129cca0f6714a777988e154d6ae450e9fabbef696e4ffa3a6c9199c7d63a → rw0-c-ceiling-matrix.84158b48657b7556f38e472ac0b4653ddf331d8fd4d87855c7a98d0dae716fda@58095bc66ae417bd466488665778c508fed88d9dfeb3e48f2cda81d539204c70
supersession.v6.identity.db415ced3437dbb24614 | value:governed-execution.nwp-rw0-c1-evidence-membership.v1:c1-section41-membership-golden.0001 | c1-section41-membership-golden.0001@4ac43686ac4a6d7d95298b365fd1343a04e346c105f1fb5887f525dfd0b87da4 → c1-section41-membership-golden.0001@f55a4d11062704095a7555282df09882a8c0b8a563010e42a1fc36bfa962c5b8
supersession.v6.identity.dc2b38bb2ceed2fd7de2 | value:governed-execution.nwp-rw0-c1-section41-post-execution-proposal-family-member.v1:section41-member-golden.0001 | section41-member-golden.0001@a8133acc5229edf3cfd80f5b3dab5dfc972d2b517a12e12a8486d4ecc5e72c64 → section41-member-golden.0001@ddb30a465fb79f12dc632ae1298e749c4500fd6dda5c52cbaab2b26f79441dbf
supersession.v6.identity.e9a7219984649f1b9181 | value:governed-execution.nwp-rw0-c-decision-time-global-stop-branch-matrix.v1:rw0-c-global-stop-matrix.4f60501c89c335c2de6024ca0f34db7199f3c2416f76f29240e40cd5f0839f9f | rw0-c-global-stop-matrix.4f60501c89c335c2de6024ca0f34db7199f3c2416f76f29240e40cd5f0839f9f@92a168ba6f48595ba1bf2e4278e60686cdd260b623e8f63d52a4e401f62da695 → rw0-c-global-stop-matrix.4790e9464729d911afb2c2e5f7831dc5abd96fc60cdd57ba823644e78dcbaf65@9e3f6d1c4d0d76415a43479a0bc2faeb0ce8c2721554c4c08e96727b9728c433
supersession.v6.identity.ffb3f25a3eff1c9e2706 | value:governed-execution.nwp-rw0-c-decision-membership-closure.v1:rw0-c-membership-closure.c3cb80e3bf357b3f0bfe819f4732d2e0f657d6d2d2c0d2d7027f946729144105 | rw0-c-membership-closure.c3cb80e3bf357b3f0bfe819f4732d2e0f657d6d2d2c0d2d7027f946729144105@5fe511fdd6f387a43354ae6a024ec2a0580e3b85cab1784a0c792cbde3fa8c36 → rw0-c-membership-closure.75f769059dc080880469cbf6e6d55c6fc42cb558ba6e376fb3ebe17250c13943@b55c170b3dd54231e5cec39d2696bc248cb1f9b5e24d223b745c5f3d3902c442
```

All 25 use reason: `V6 rank-15 current-owner grounding repair replaced this current identity`.

</details>

<details>
<summary>Exact 31 record-payload supersessions</summary>

Format: `entry | superseded record | old-identity → replacement-identity`

```text
supersession.v6.record.041a67ca6bc89075b7f2 | golden.V24.role-resolution.08.independent_review | 8f8724f805ce90e2c5b01ac51aa4a061d060649e3889695b885b3ecf8f666111 → 980e416ec380d6b982270e496bca40aa05cbc6872114f8b68e63530bf4042cd2
supersession.v6.record.09d26caaa6bf1d1906ac | malformed.attempt-fence-expiry-substitution | 4f75208cb92265b94b931916f77013a25f8c1e67036e1cc099615957c39d06e3 → 66c8a989c16f95c6c1190f69a7af2ec1ea42adec9d9ad008e215fdc67eef15bb
supersession.v6.record.0f85b470e17279bfc411 | golden.V24.role-resolution.12.global_stop | 3c79b35053811e2e8028045829c54d7b87f651fdb60e04c971282986f45d6de0 → f0c5fcc6360b87298fd823324922bf24659bae161e236430801fca34014122b3
supersession.v6.record.16af18f09ec67f6ff34c | malformed.V3G032.snapshot-required-row-missing | 73958b75ff3de8ade58e5fa8d133679b9f32bb4c2d1c001bf3a03f9f89e33a0f → 23a3155243ca7853b3a7a7c97c898e49a0bad3bd750235617e95df4c52d9b2f9
supersession.v6.record.2351ada01b8d5ebe3536 | golden.V29.primary | b303603bb612312ea9a2747c95f90b70095c105c5766df2e5036ecfdaa1d4aa6 → 1ffb7e2e3cc9b1669d6646d708bf617dd67260cc71314c6d5c5e1d94570cc0f4
supersession.v6.record.32841058f594647d0a1d | malformed.V3G030.snapshot-external-source-substitution | a9e908c0e06b538d8ac0f41f24f391226fdb89ccdbee43103c32d982c8131ae6 → 10e4ba1995a2a909b4584084a7a2fcb12bb4e58433c5f18b56916f1cf7be8104
supersession.v6.record.4a3e3ffd301c4b7caffd | golden.V24.role-resolution.07.validation_result | 393a5231c9e1cd956e5162003c7276eb0cdbcd21ffaf6d5c2e565a8fa7bf6ec0 → af34bc82a44d16ba7796b7d47f1cbdeef6ce0a4ac36b8a2751739929a8b4617f
supersession.v6.record.56fd92d4e24a22483bb3 | golden.V25.primary | bb2e1a636c160274face5c3991c90bb6d2da3cc2f5528f859c0bb8980a292d2d → 9fc1b38a08b01da7e10ed2c947e8d7798a35d97e4f7ffd4c3d5b7b18516cce7d
supersession.v6.record.5d631ab75bdd775fab7e | malformed.V3G033.snapshot-current-row-malformed | 5415684bc0929bd1518e19970ddaf83ae77d8554c27e63e64a06c71e4c6495f6 → ae44b3570052d24d7ac71f8c93c87a5d9957babb07392beee76a5d2806769410
supersession.v6.record.5e2cd8404359ed83d187 | assurance.V3G012.rank12-cascade-stale | ca8ce1db2e750a90eca1d318f6a19d28fa9bebf033a1a7a1e61d0804c629c838 → 560c51df0c33074ab1759fe6f723c274202bc3b1093a02fc8135e6a8ed614bb9
supersession.v6.record.6432ddcee35fb094ae22 | source-owner.rank15-section41-relation | 18dc8d109fe653788d6fc93113a694e1b6a076b6a66b25b69ac32c53c492458d → 9617316b7649848b5543ea4a4bce18a450a00e370021bb68435b7bcea8b0f345
supersession.v6.record.6e8a37ce04f518cd5557 | golden.V24.role-resolution.13.effect_ceiling | 316e88ee4e8166f2a0c37cd45434f7a3ddbcf4873971bd631bdb9a5fd38dc5c6 → 8f14dd16ae270664c777c06edefb61a10bcc954c51d9f42e714c310315e3b385
supersession.v6.record.76391c13f2eebafeb42d | golden.V34.primary | a2b7e8466aaead8c72af29fb5f054c3ca0851a150c3d040ae7b0a808852e153d → cef96d0634a1c0db8073db3f9cac92bf94842fb7cf5ab8333dc07a1b71964778
supersession.v6.record.7db2357008a0f54f1e37 | golden.V24.role-resolution.05.candidate_capsule | a7316fe14d1e45802497d81c660a52a8e0c010271dad66c37d4b1679a133561b → 6a0da2bc0dbdb810a537ad77a043ab98c5857f4742c16483ca99bbc72de55efa
supersession.v6.record.7fa73a0357c87eee7f97 | golden.V31.primary | 23185fa8f4322b3fc08c7bafbf6cacd21951748977aa2ebfec0ef99b7252bbea → a2b600dd754a822d5699dfd36d0526d191228755ae4556fa66f96d58e3bdaed0
supersession.v6.record.8215e20a80473c798c70 | malformed.V3G031.snapshot-phase-k8-mismatch | 77e419cc759abdecc8073cc6d33f6c7886216ef5e3340b378f68dfc9227b532b → 61c12ea2cd8879b7f7b79ad392adc1d6517bec0fc5bf4ca7f37fc54b3bee155d
supersession.v6.record.91ca07f20f21ae4ba820 | golden.V24.role-resolution.10.risk_lane | e06562e95c618f4a0593ef2cc8e9557a5f2cf4ff3da90769812e1fda01a37c38 → cb67269270556516604fc4b2e5588c74c7f7f067944531c5a45446888d38d107
supersession.v6.record.97d70ce91b8709303e3a | source-owner.rank15-section41-value | 99a89344a2bf2a49f51d4866d5db15945b117606445612e21a6859d3c14b97c9 → e2bfc3177331de57f782b9e12b90306ec68f120505eed78bff8d5ff2ed11405e
supersession.v6.record.a2f770bc252aff0f1632 | golden.owner.rank15.relation | 3f9cb40cac1ffe86f39fab2688c931d75b743c50805e68f41d76446a444d491a → 67a044c165c116a0fbc5a4a004631876a81f7219740c43f840cbc3d04b0f219a
supersession.v6.record.a83d649f8af61066fa03 | malformed.V3G029.snapshot-rank15-membership-substitution | d702196edc2eef461c45adcc4c65b2e841d5e940dd01757369654cb9a9f414af → 4aaaff5691ad863dd06df91643be34d1a38e7285b88873b227c1df0bd6b8ca59
supersession.v6.record.ab92b4a3b137fccf9456 | golden.V32.primary | 56c542826dd8589eea1d41a7e75338707ae7d4c36f5a420fa97a2034093b0c2f → 2543e24fd50cb2a57e8517c8c398dff5f5c2e1120be7cfef6b458c5bdb1f833d
supersession.v6.record.b8c35b7934f71bdc339e | golden.V27.primary | fbb71e5d566b68afda3951051993e4fa96e30b3515f5df8a05ae8b7d361cec58 → a8f62c91debf66faf92b8de46176bba5a2e0418c81240526da31b1d60915f4df
supersession.v6.record.cb85b9b0f4f930000cc3 | malformed.V3G028.snapshot-rank1-membership-substitution | 64cd2dd4e2b322f97fc4becf79b985592b4dedcdeacea18df2ec6f0a51baa67a → 3a66f4197f34fe41c8ef8e3f429873dfb8ebaf5bc67dce607809c39bb975032f
supersession.v6.record.d606ef329fc5f2969a06 | golden.V24.role-resolution.09.standing_policy | ce250ea56c737d61dbac8ee82627215dd8904d75907780636487d976a156a3bb → b831a24153d1b04fd9319530c15e484e378e5a57d17b1d837e96481de317195f
supersession.v6.record.f43e164340d5abd6092c | golden.V26.closure-entry.007 | a5065334d7f8cdf01169877e0fe30360937604b3b94e86d845ca25eedba6b03f → 3347cd6c91abc0a66a7e9ff451b05e5ea809753123ee4f2c9c477d2eb3fc6499
supersession.v6.record.f5c1463bbad1f959b4e3 | golden.V24.role-resolution.06.worker_result | f8ca75a0b7aac3e6d158d227cdd1d7d92a1f62c798b9fab5d615927009bba56b → 8b7bc36fda7cbc15750867ef779e3631f32899d9f34989caefde1f8882a48095
supersession.v6.record.f63351f638d76b8ad2de | golden.owner.rank15.value | a2cedc04e3b0a3c42042d7052a074403a7231934814e4f997109b42271b71fa9 → 03e80995170e4131d1fcb37dd7a0257191960dd479192f5cf332f8476617a0da
supersession.v6.record.f8826c7b8e472b7b7b74 | golden.V33.primary | f16466f9ff7ce7fbe0568eb0d02bb738f239a6b826afc3015dc568aeffe14317 → 8416fb7c82188dad912055e8a02fc55c26213e3b2f1c22ec44347e268c85311b
supersession.v6.record.f94fa0e2473903d3f003 | golden.V24.role-resolution.11.authority_currentness_attestation | edadb50b4d2112126bc9d79ea56819c089306e7e5a6697b914c971a05cfaa943 → 084603f23aa6d85f4e2a33e566ccb32b4fd3fb3b0765b5e010e5b6cf2ab7599c
supersession.v6.record.fadb59397bc9bdd83114 | malformed.global-stop-branch-mismatch | ed8ee0f2cecaa40b6693dfc6c1d887d7a59933817324831b25a67050981aa7ce → bdf4333325d6492d092b2baad7f8ed568ce26a4cf5744d4103fac6db1d7c95ff
supersession.v6.record.fef57f1af54817484554 | golden.V22.primary | faa3b633be26a256686cb26f4b9fa898b2f05e6a48156a6a68c4f1ea6b7c8f9f → 743939c44cf1767895ffa5f53879c0c914cd223ff361cf45429d5bf66ad65c01
```

All 31 use reason: `V6 rank-15 grounding and supersession-leakage repair replaced this current record payload`.

</details>

### Verification results

- The twelve package locators exactly matched the source-owner control record.
- Current source reproduced the graph, wrapper, twelve operands, operand set, relation, relation row/set, admission graph, membership, V22/V24/V25/V26/V27 chain, and currentness consumers.
- The wrapper constructor accepted the supplied corrected digest.
- The current runtime exact-family matcher accepted the complete corrected 12-row family.
- V5 supersession scan: 771 hexadecimal entries, 679 unique identities, exactly one forbidden occurrence detected.
- V6 supersession scan: 827 hexadecimal entries, 735 unique identities, 1,547 records scanned, 7 permitted dedicated-malformed occurrences, zero violations.
- Canonical verification covered 113 schema shapes, 41 generated references, 54 self-digests, and 50 profile pairs.
- Duplicate-key rejection, canonical outer/embedded JSON, lengths, hashes, domain digests, dense indexes, ordering, manifest, aggregate, and closeout all passed.
- Whole-file identity was independently reproduced with a separate Ruby duplicate-rejecting reader, `shasum`, and OpenSSL.
- Historical records outside the intentional changed set remain byte-exact.
- All 44 value schemas, 28 behavior profiles, and 44 module allocations remain intact.
- V35–V37 remain absent from current schemas, goldens, allocations, and implementation scope.
- All preserved V1–V5 contracts remain intact.
- Disposable reconstruction intermediates were removed; only the attached V6 package remains in the temporary root.

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
```

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V6_REPAIRED_READY_FOR_INDEPENDENT_AUDIT
