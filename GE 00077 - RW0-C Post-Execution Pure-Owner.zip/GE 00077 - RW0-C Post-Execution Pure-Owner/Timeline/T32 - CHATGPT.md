# Disposition

**Accept the independent audit’s `BLOCK` verdict. Do not stage or commit this candidate.**

This is not a provenance failure and not an architectural rejection. The auditor reproduced the exact 20-path candidate, matched its provenance manifest before and after inspection, and independently reran the complete suite in an external clone: **5,324 tests passed with the same three pre-existing warnings**. The failure is that the implementation does not actually enforce significant parts of the accepted semantics, and the new tests do not expose that gap. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

## What the audit established

The structural boundary remains sound:

- exactly six new private source modules;
- exactly twenty changed or untracked paths;
- no migration `0005`;
- no SQLite, public API, `StateStore`, `WriterSession`, runtime, production-caller, or cross-repository widening;
- no filesystem, process, network, environment, model, worker, or persistence operations;
- the accepted import graph remains private and acyclic. :chatgpt-content-reference{index="2"}

The repair therefore stays inside the existing tranche. We do **not** need another owner-contract package, another freeze, a seventh module, or a revised authority split.

## Why the implementation is blocked

### 1. The “evaluators” trust caller-authored conclusions

The most important defect is that several public-within-private action functions effectively validate and rehydrate a caller-supplied output rather than derive the result from authoritative inputs and the frozen profile.

The auditor independently re-signed ten contract-invalid values, and all ten were accepted:

1. A reordered mapping despite an exact declared field order.
2. A tuple where the schema requires an exact built-in list.
3. A 97-byte safe reference where the applicable limit is 96.
4. A non-enum V41 allowed-branch member.
5. A V22 artifact timestamp earlier than source completion.
6. A V24 rank-5 role changed from `candidate_capsule` to `worker_result`.
7. An incomplete one-entry V25 subset presented as complete closure.
8. An active V32 stop paired with clear/permit governed entries.
9. A V40 reviewer invocation reused while claiming operational separation.
10. A failed source observation presented as validation-passed. :chatgpt-content-reference{index="3"}

This is a real fail-open contract problem. There is no present production caller, so it has not created current runtime authority, but later integration would treat self-consistent false conclusions as valid evidence or decision inputs.

### 2. Section 41 and RW0-C actions are not grounded deeply enough

V22 and V24 presently reconstruct supplied mappings instead of establishing the current nine-row family, exact owner graph, role/rank/ordinal relations, profiles, locators, resupply, chronology, and owner-family equality. The V24 action does not even invoke the existing limited exact-nine helper. :chatgpt-content-reference{index="4"}

The RW0-C decision-input implementation is similarly incomplete:

- V25 does not implement the frozen paging, cursor-progress, capability-epoch, 65,536 maximum, or 65,537 overflow semantics.
- Its public action does not call its limited helper.
- V27 and V29 retain shaped components without establishing the required source equalities and currentness.
- V31–V33 accept globally legal result/reason pairs without deriving them from the bound source state.
- V34 checks recommendation-to-branch correspondence without checking the full authoritative input relation. :chatgpt-content-reference{index="5"}

The repair prompt preserves the no-I/O boundary: V25 must evaluate a private finite page transcript inside the existing module, not add a database reader, migration, or durable owner.

### 3. The permanent test corpus is mostly inventory, not execution

The implementation report claimed coverage of 201 goldens, 93 malformed controls, 126 assurances, and 36 equalities. The auditor found that most of these are merely literal ID inventories:

- none of the 36 equality IDs appears in the four new test files;
- none of the eight seam IDs appears there;
- 24 of the 27 action functions are never called;
- rank-15 tests compare hard-coded dictionaries rather than reconstructing the current family;
- the V32 test constructs an expected value and immediately rehydrates the same value;
- scalar exactness stops after the first integer field per class;
- import tests do not reject every extra edge;
- production-caller scanning covers only three of six modules. :chatgpt-content-reference{index="6"}

The repaired tests must map every accepted record ID to an actual executable responsibility: positive construction, causal one-predicate rejection, current-owner grounding, equality, import boundary, or preserved seam. Merely listing IDs will no longer count.

### 4. The runtime inventory guard is too permissive

The modified guard ignores any regular `.pyc` or `.pyo` beneath any directory named `__pycache__`. That allows unexpected or orphaned executable bytecode to evade the closed production inventory. Its current negative test covers an unexpected `.py`, not unexpected bytecode. :chatgpt-content-reference{index="7"}

The repair must limit the exception to the exact expected cache location and source-corresponding filenames, with negative controls for unexpected location, nesting, filename, type, orphaned source, and bytecode-only paths.

### 5. Documentation and the V1 report overclaim completion

The seven documentation changes remain path-bounded and retain the important negative claims. But some new status text says the evaluators and helpers are implemented when the accepted semantics are not. The V1 implementation report likewise overstates exact grammar, source grounding, profile semantics, and finite test coverage. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

The historical V1 report should remain unchanged as evidence. The repair must issue a corrected V2 implementation report and update the seven documents only after the code and tests truthfully support the resulting status.

# Exact repair boundary

Resume the **same workspace-write implementation conversation**. The parent remains the sole writer; do not use subagents.

The repair is restricted to the original twenty paths and must:

1. Implement complete frozen profile and evaluator semantics inside the existing six modules.
2. Enforce exact built-in types, mapping order, profile-specific bounds, enum membership, list ordering, nullability, cardinality, and cross-value relations.
3. Ground V22/V24 in the complete current Section 41 family.
4. Implement the complete pure V25–V34 semantics without adding I/O or durable state.
5. Replace inventory-only tests with executable coverage of the entire accepted finite corpus.
6. Tighten the authorized runtime inventory guard.
7. Reconcile the same seven documents.
8. Generate new validation, provenance, and implementation-report artifacts for a fresh audit.

This is exactly the successor boundary ordered by the auditor. No new path, migration, public export, runtime behavior, production caller, durable decision, terminal, or cross-repository effect is permitted. :chatgpt-content-reference{index="10"}

The repair prompt also requires:

- exact reproduction of the current V1 provenance before editing;
- a safe client-visible opening cache/provenance record, closing the low-severity historical-evidence gap;
- formal validation in a private external local clone so the live repository’s pre-existing cache is never moved or rewritten;
- V02–V06 serial validation against the final exact candidate;
- two byte-identical final provenance runs;
- a new independent audit after any byte change.

# Repair handoff

Attach exactly these four files to the existing implementation conversation.

### 1. Repair prompt

:chatgpt-content-reference{index="12"}[Download the V2 implementation-repair prompt](sandbox:/mnt/data/Coordinator_RW0_Post_Execution_Pure_Owner_Implementation_Repair_Prompt_V2.txt)

```text
Filename:
Coordinator_RW0_Post_Execution_Pure_Owner_Implementation_Repair_Prompt_V2.txt

Size:
32,251 bytes

SHA-256:
394018c64671b4aeaef6e7b5b5feb9c7e9ee8c4d08425046304eb40cba12b3b0

Logical lines:
596

Final newline:
present
```

### 2. Exact independent-audit report

:chatgpt-content-reference{index="13"}[Download the named independent-audit report](sandbox:/mnt/data/RW0_Post_Execution_Pure_Owner_Implementation_Independent_Audit_Report_V1.md)

```text
Size:
29,347 bytes

SHA-256:
178c49932c838ecc4a5e1b03143503fd281ad42e548db40ac6364ebabd5ef21c

Logical lines:
421

Final newline:
absent

Verdict:
BLOCK
```

### 3. Exact blocked-candidate provenance

:chatgpt-content-reference{index="14"}[Download the V1 provenance manifest](sandbox:/mnt/data/RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V1.json)

```text
Size:
4,376 bytes

SHA-256:
c4d207c8a7ec35ba518bf3739a7069148a368477ec30198a12845c5ba5357bc1

File count:
20

Tracked textual diff SHA-256:
e17b5828848c62eebf3c9aece79b5bed89753f620e5ba3134a3561da227af071
```

### 4. Historical V1 implementation report

:chatgpt-content-reference{index="15"}[Download the V1 implementation report](sandbox:/mnt/data/RW0_Post_Execution_Pure_Owner_Implementation_Report_V1.md)

```text
Size:
19,966 bytes

SHA-256:
c6cf934721db83ddb67ff105d52c12f6fecea0b85eabf47d38f8828378c87433
```

Do not reattach the original V11, freeze, overlay, implementation-prompt, or provenance-recipe files when continuing in the same implementation conversation; the repair prompt requires Codex to stop rather than search or substitute them if that conversation no longer retains their exact bytes.

The required repair success token is:

```text
RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIRED_VALIDATED_PROVENANCE_READY_FOR_REAUDIT
```

A successful repair still authorizes only a **new read-only independent audit**. It does not authorize staging, commit, push, PR creation, publication, migration, runtime activation, C2B progression, terminal work, RW0-D/E, or Execution Substrate changes.

**Sources:** Independent implementation audit and the exact provenance-bound V1 implementation report. :chatgpt-content-reference{index="11"}

**Confidence:** 0.999 that `BLOCK` is correct; 0.995 that the six-module and twenty-path boundary remains valid; 0.99 that the supplied repair prompt covers every high- and medium-severity finding without reopening the accepted architecture.
