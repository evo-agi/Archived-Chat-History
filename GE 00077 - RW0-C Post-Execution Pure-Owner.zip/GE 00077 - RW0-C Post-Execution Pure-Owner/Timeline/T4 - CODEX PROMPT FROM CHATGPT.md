PROMPT_ID

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V7_GLOBAL_STOP_SEMANTICS_AND_CAUSAL_ASSURANCE_REPAIR_V1

TITLE

Coordinator RW0 — repair the V6 decision-time global-stop applicability defect
and noncausal assurance vector, add exact active-stop finite controls, preserve
all accepted owner contracts, and deliver canonical package V7 for a fresh
independent audit

ENGAGEMENT TYPE

Parent-only, local, repository-read-only canonical-package repair.

Use a package-generation/repair conversation, not the independent-audit
conversation that reported the findings. Preserve auditor/repairer separation.

Do not delegate to subagents or internal audit agents.

Do not edit repository files, format repository files, stage, commit, push,
create a branch or PR, merge, tag, release, deploy, fetch, contact a remote or
live system, install dependencies, execute repository tests, run migrations,
open or mutate an operator database, invoke a product worker/model, or
inspect/modify supporting repositories.

You MAY create files only in one fresh private external temporary root for
bounded source inspection and package reconstruction. Use mode 0700 for the
root. Set PYTHONDONTWRITEBYTECODE=1 for any bounded pure-source constructor
use. Remove disposable intermediates before closeout.

Return the revised package through the client-visible attachment mechanism.
A private filesystem path is not a deliverable.

Do not issue an implementation prompt.

ATTACHMENT RECEIPT CONTRACT

The sole fixed contract input is the client-uploaded attachment named:

RW0_Post_Execution_Canonical_Audit_Package_V6.jsonl

Do not require, request, or assume a second copy in `/Users/ds/Downloads/` or
any other predetermined path. A runtime materialization path may be used as an
implementation detail, but path presence is not part of the fixed-input
contract.

Before substantive work, visibly report an attachment receipt containing:

- observed filename;
- accessible runtime path, if the client exposes one;
- byte size;
- SHA-256;
- logical record count;
- final-newline posture.

If the client attachment is not accessible, stop immediately and return:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V7_FIXED_INPUT_ATTACHMENT_UNAVAILABLE

Do not search for or silently substitute a same-named local file. Do not treat
attachment transport failure as a semantic or source-owner finding.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V7_BASELINE_MISMATCH

FIXED INPUT IDENTITY

Require the attached V6 package to have exactly:

filename:
RW0_Post_Execution_Canonical_Audit_Package_V6.jsonl

size:
2466932 bytes

SHA-256:
ebae5f77865f22adec3a5fdc45ed94d928c89d783eb11185a85405643cdef881

logical records:
1547

final newline:
absent

content aggregate:
be7960057fc4bc3e7a8f1ebba601b93f760b0abd8542dcfe10b4145b5b130759

first record:
package.manifest.v1

last content record:
remaining-seam.S008

final record:
package.closeout.v1

record-type counts:

package_manifest: 1
source_owner_binding: 23
value_schema: 44
behavior_profile: 28
golden_value: 196
malformed_vector: 90
module_allocation: 44
import_edge: 31
equality_matrix: 36
assurance_case: 117
supersession_entry: 928
remaining_seam: 8
package_closeout: 1

If any fixed-input property differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V7_FIXED_INPUT_MISMATCH

DISPOSITION OF THE INDEPENDENT AUDIT

Treat the audit result as BLOCK, not REJECT.

V6 is cryptographically and structurally coherent. Its authority decomposition,
source grounding, rank-15 repair, supersession hygiene, temporal model, privacy,
Section 41 bindings, currentness split, compatibility treatment, and proposed
migration-free pure-owner decomposition remain accepted for this repair.

The block is confined to:

1. one High-severity package contract defect in the V32 decision-time
   global-stop profile; and
2. one Medium-severity noncausal assurance/malformed-vector defect.

The repair does not authorize or require any repository owner change,
architecture reset, migration, implementation, public API, durable writer,
production caller, latch, terminal, D/E, provider, worker, transport, Bridge,
Control Plane, Infrastructure Manager, or Execution Substrate work.

SEAM CLASSIFICATION

Current owning contract / invariant:

- `.docs/autonomous-software-development-operating-model.md:467-473`
  states that an active coding global stop blocks productive initialization,
  effects, acceptance, repair, productive replan, publication and Git
  eligibility, while permitting terminal reject/block decisions and other
  risk-reducing halt/cancel work.
- `.docs/c2b-durable-development-state.md:503-539` gives the exact Coding
  Global-Stop Matrix: active stop blocks accept, repair and productive replan,
  while `record terminal reject` and `record block` remain permitted.
- `src/ge_nwp_coordinator/global_stop.py` owns `GlobalStopState`, exact field
  validation, active/clear status, derived stop ref, and raw canonical digest
  semantics represented by `source-owner.global-stop`.

Proposed pure-owner contract:

- `behavior-profile.post-execution-global-stop.v1` already encodes the correct
  four-way state/applicability table.
- `behavior-profile.rw0-c-decision-time-global-stop-branch.v1`, V32, its
  goldens, and its finite assurance must preserve that table at decision time.

Implementation detail / artifact:

- JSONL records, synthetic goldens, malformed vectors, assurance records,
  supersession entries, manifest and closeout are audit-package evidence. They
  do not become Coordinator durable truth or implementation authority.

No reopened authority seam is created by this repair.

PRESERVED CONTRACTS

Preserve every V6 contract the independent audit accepted, including:

- exact canonical JSONL mechanics and the closed record-type envelope;
- all 23 current source-owner bindings and current-source rank-15 anchors;
- the repaired rank-15 graph, wrapper, operand-set, relation, row/set/graph,
  membership, V22/V24/V25/V26/V27 and currentness chain;
- the package-wide zero-forbidden-occurrence supersession posture;
- all value schemas and behavior profiles except the exact V32/profile changes
  required here;
- profile-bounded list cardinalities and support inventories;
- distinct validation, review, policy, risk_profile and risk_binding
  currentness components;
- the two-context temporal model and monotonic construction chronology;
- exact nine-role model-input, Section 41 and resupply equality structure;
- transient/private candidate-capsule handling and safe projection privacy;
- V40 operational reviewer separation without human/provider/account/principal
  identity claims;
- owner-authored standing-policy and risk attestations;
- generic risk semantics separated from the versioned FiniteBacklog adapter;
- exactly fifteen current C1 evidence kinds and no C1 completeness authority;
- explicit deferral and current absence of V35-V37 committed-recovery values;
- current executable authorization remaining unsupported and fail-closed;
- the migration-free pure-owner implementation decomposition as a proposed
  boundary only;
- no implementation authorization.

Do not change unrelated semantics merely to preserve or replace a hash.

FINDING V6-AUDIT-001 — V32 ACTIVE STOP DENIES HALT-ONLY BRANCHES

The current V6 record:

behavior-profile.rw0-c-decision-time-global-stop-branch.v1

contains this effective precedence:

1. snapshot_or_stop_identity_mismatch -> conflict
2. profile_mismatch -> conflict
3. global_stop_active -> deny
4. global_stop_unknown -> unknown
5. halt_only -> permit
6. otherwise -> permit

Because `global_stop_active` precedes `halt_only`, a known active stop denies all
five branches, including:

- program_terminal_reject
- post_execution_program_block

That contradicts the current owning C2B contract and the package's own correct
proposal-time profile:

behavior-profile.post-execution-global-stop.v1

The existing clear-stop `golden.V32.primary` does not exercise the conflict.

AUTHORITATIVE DECISION-TIME TRUTH TABLE

After exact identity and profile checks:

- global-stop state unknown -> unknown for every branch;
- known clear + governed -> permit;
- known clear + halt_only -> permit;
- known active + governed -> deny;
- known active + halt_only -> permit.

`permit` remains only one local input to a later Coordinator decision. It is not
execution authority, acceptance authority, publication authority, Git
eligibility, or external effect permission.

REQUIRED V32 PROFILE REPAIR

Refreeze the exact decision-time precedence as:

1. snapshot_or_stop_identity_mismatch -> conflict
2. profile_mismatch -> conflict
3. global_stop_unknown -> unknown
4. halt_only -> permit -> halt_only_stop_checked
5. global_stop_active -> deny -> global_stop_active
6. otherwise -> permit -> global_stop_clear

This order is normative for V7. Do not encode an unconditional active-stop deny
before halt-only applicability. Do not permit halt-only when the stop state is
unknown or the identities/profiles conflict.

Update both:

- behavior-profile.rw0-c-decision-time-global-stop-branch.v1
- value-schema.V32.rw0cdecisiontimeglobalstopbranchmatrixv1

The value schema's `grouped_branch_rules` must exactly match the governing
profile precedence and its `governing_profile_pair.profile_digest` must equal
the newly reconstructed profile domain digest. Set
`source_of_canonical_bytes` exactly to:

complete synthetic clear and active golden values in this package plus literal owner/profile inventory

Independent reconstruction must produce these exact repaired profile/schema
anchors; they are verification targets, not permission to patch hashes:

- behavior-profile canonical payload length: 1024 bytes;
- behavior-profile payload raw SHA-256:
  `73a01e5ac25843a5e06091569d811d5a4bead66bcb4118b4e73662a3f4909803`;
- behavior-profile domain digest:
  `6139df3c64d3736e6938605bc6abef22c258e4841ffe8b641d7a70490f6a5e47`;
- V32 value-schema canonical payload length: 3764 bytes;
- V32 value-schema payload raw SHA-256:
  `2b0414db90a155593a9cdc909a9d6cb69de4d84aca70bfddec09d21b53dca7ce`.

Preserve:

- the five canonical branches and their applicability/effect-class mapping;
- result vocabulary permit/deny/unknown/conflict;
- entry count 5;
- generated matrix ref and self-excluding matrix digest rules;
- no-I/O, pure-validation/evaluation posture;
- no claim that permit is complete or executable authority.

CLEAR-STOP CONTROL

Preserve `golden.V32.primary` as the clear-stop current-scenario control.

Its five branch outcomes remain permits. Recompute only what the new governing
profile identity and canonical value rules transitively require, including its
profile digest, generated matrix ref, matrix digest and record payload hash.

Independent reconstruction must produce exactly:

- canonical value length: 2505 bytes;
- raw SHA-256:
  `b226f91d8e90d6ed7de9ba92595d444e74866d9d333e50ef0d5d0036841c39e7`;
- matrix ref:
  `rw0-c-global-stop-matrix.765a8f001b742856925c6ba9ed90bd2dafd12dd3399cdc10d704404949b843b9`;
- matrix digest:
  `e8b2af5a16ae67d027404d1fa96cc48cc78cf115b2ddecfde8891d4c3abeca67`.

Do not change the current clear source-owner fixture, `golden.V27.primary`, the
current Section 41/model-input chain, or currentness consumers merely to create
an active-stop test.

ACTIVE-STOP FINITE CONTROL

Add a bounded synthetic active-stop control family. It is assurance evidence,
not current scenario truth.

Add exactly these new golden record IDs:

- golden.owner.global-stop.active
- golden.V27.active-stop-control
- golden.V32.active-stop

1. `golden.owner.global-stop.active`

Construct one complete active `GlobalStopState` through the current owning
source grammar using exactly this canonical mapping:

```json
{"active":true,"issued_at":"2026-09-30T12:00:01Z","issuer_ref":"issuer-golden.0001","operator_decision_ref":"operator-decision-golden.0001","reason_class":"safety_stop","schema_id":"governed-execution.nwp-global-stop.v1","stop_id":"global-stop-active-golden.0001","version":8}
```

The mapping has only the eight current owner fields. Validate it through the
current `GlobalStopState` constructor; do not treat the literal as a substitute
for source validation.

Independent reconstruction must produce exactly:

- canonical value length: 276 bytes;
- derived stop ref: `global-stop-active-golden.0001`;
- raw canonical SHA-256:
  `52e9910ccd71209c823489e36599dca8afd8a6c7d29f7c61d01e3748662b4b02`.

Report the exact active owner canonical value, derived stop ref and raw digest
in the inline report. The values are synthetic contract fixtures and must not
claim a real operator, credential, account, principal or live stop.

2. `golden.V27.active-stop-control`

Construct an alternate finite V27 decision-current snapshot by starting from
`golden.V27.primary`, replacing only `global_stop_ref` and
`global_stop_digest` with the exact active owner control coordinates, and
recomputing the generated snapshot ref and snapshot digest through the V27
schema/profile rules.

All other V27 semantic fields must remain equal to `golden.V27.primary`.

Independent reconstruction must produce exactly:

- canonical value length: 4437 bytes;
- raw SHA-256:
  `28125856ac11c0824a2b4def8e9f2568db6cca51b506a6587686e496d62520d0`;
- snapshot ref:
  `rw0-c-current-snapshot.5318fe94a5654f9626e3bbd9fda42b8736b914d690b1e270b0f54fce012988af`;
- snapshot digest:
  `bb95ff499c4ef25616c28fa37a746678a951fb2b430315bff2143f589499ba7b`.

This record does not replace `golden.V27.primary`, does not become the current
snapshot, and must not propagate into the current model-input, Section 41,
closure, currentness or implementation-boundary chain.

3. `golden.V32.active-stop`

Construct a complete V32 matrix using:

- the new V32 profile ref and digest;
- `golden.V27.active-stop-control` snapshot ref and digest;
- `golden.owner.global-stop.active` stop ref and raw digest;
- the canonical five branches in existing order;
- the existing evaluated-at posture unless a change is required for temporal
  validity.

Its exact outcomes must be:

- candidate_acceptance / governed -> deny;
- candidate_repair / governed -> deny;
- attempt_selecting_replan / governed -> deny;
- program_terminal_reject / halt_only -> permit;
- post_execution_program_block / halt_only -> permit.

Governed active-stop entries must carry a reason that exactly denotes
`global_stop_active`. Halt-only entries must preserve the current V32 entry reason
`halt_only_checked`; the profile precedence marker remains
`halt_only_stop_checked`. Source ref/digest coordinates must equal the
active owner control.

Generate and verify the exact V32 matrix ref and self-excluding matrix digest.

Independent reconstruction must produce exactly:

- canonical value length: 2559 bytes;
- raw SHA-256:
  `f6af3f51c11b2ea204ea7483b946d7f3189c6a82d162dddd320d9775df62f656`;
- matrix ref:
  `rw0-c-global-stop-matrix.94abe7bedbd63b72e620b7accaf11162f6c46076f7ff6b80e7477157fb586150`;
- matrix digest:
  `1a2e960d02fbe5500a65d14165296adb43ce41a25f229a4374c32538f9b0f7c7`.

ACTIVE CONTROL NON-WIDENING GUARD

Before success, prove:

- the active owner fixture is accepted by current `GlobalStopState` semantics;
- its raw canonical digest reproduces exactly;
- the active V27 snapshot reproduces its generated ref and digest;
- the active V32 snapshot/stop identities match exactly;
- the active V32 matrix reproduces its generated ref and digest;
- exactly three governed entries deny;
- exactly two halt-only entries permit;
- no current-scenario record outside this finite control family changes because
  the synthetic active stop exists;
- no new module allocation, import edge, public export, migration, writer,
  database method, runtime caller or durable state is introduced.

FINDING V6-AUDIT-002 — MALFORMED VECTOR IS IDENTICAL TO THE VALID GOLDEN

The nested `mutated_canonical_value` in:

malformed.global-stop-branch-mismatch

is byte-for-byte equal to `golden.V32.primary` in V6. Both canonicalize to 2505
bytes and raw SHA-256:

2543e24fd50cb2a57e8517c8c398dff5f5c2e1120be7cfef6b458c5bdb1f833d

It therefore cannot causally demonstrate an active-stop governed-branch
mismatch.

`assurance.A055` also says only `global stop active -> deny`, incorrectly
collapsing governed and halt-only applicability.

REQUIRED CAUSAL ASSURANCE REPAIR

A. Repair the existing simple assurance.

Change `assurance.A055` to state exactly:

case:
global stop active with governed branch

expected:
deny

Preserve its permanent-scope and ordinary finite-test posture.

B. Add one new simple positive assurance:

record ID:
assurance.A059

assurance_id:
A059

case:
global stop active with halt-only branch

expected:
permit

permanent_scope:
contract vector only; no execution or external authority

test_ownership:
ordinary_finite_semantic_and_canonical_vector_test

C. Add one detailed causal assurance:

record ID:
assurance.V7G001.global-stop-active-applicability-split

It must contain at least:

- assurance_id `V7G001`;
- a claim that a known active stop denies governed productive branches and
  permits halt-only terminal reject/block branches;
- `golden.V32.active-stop` as the positive control;
- the exact active owner and active snapshot control record IDs;
- one exact-one-predicate mutation targeting the result of a governed entry;
- the paired malformed record ID;
- expected failure `stop_branch_matrix_conflict`;
- independent-audit responsibility to reconstruct the active owner, active
  snapshot, active V32 matrix and one semantic result mutation;
- permanent finite-test responsibility;
- no execution or external authority claim.

Use symbolic mutation targets in the assurance record. Do not embed a
superseded or arbitrary concrete identity there.

D. Repair the existing malformed vector.

Keep the record ID:

malformed.global-stop-branch-mismatch

Use `golden.V32.active-stop` as its valid semantic base.

Change exactly the `candidate_acceptance` governed branch result from `deny`
to `permit` while holding constant:

- active owner stop ref and raw digest;
- active V27 snapshot ref and digest;
- V32 profile ref and new profile digest;
- branch, applicability and governed-effect-class mapping;
- all other entry results and source coordinates;
- evaluated-at value.

After the one semantic mutation, recompute the mutated matrix ref and matrix
digest from the mutated canonical value. The vector must remain structurally
canonical and self-consistent so rejection is caused by the governed
active-stop branch semantics, not by a stale ref, stale digest, wrong profile,
snapshot/stop mismatch, malformed owner value, unknown field or unrelated
identity failure.

Expected rejection remains:

stop_branch_matrix_conflict

Independent reconstruction of the nested mutated canonical value must produce
exactly:

- canonical value length: 2561 bytes;
- raw SHA-256:
  `285813c9a2010dc01ceddb7c714f91fea27e1021099b4cfa0830f01b27656507`;
- matrix ref:
  `rw0-c-global-stop-matrix.8c19cb82d06a64c8802ea0fe2bf63b1b831cd56bfd0fe4210778fbd2fba7c368`;
- matrix digest:
  `9bf7ea9be55cd2931da8a8f9dc09cfb956f895f0b6ff1a78acafd89e92d0945f`.

The malformed value must not be byte-equal to either V32 golden.

CAUSAL VECTOR GUARD

Before success, independently prove:

- `golden.V32.active-stop` is valid under the repaired profile;
- the malformed vector and active golden share the same valid active owner,
  active snapshot and profile coordinates;
- exactly one semantic predicate result differs before derived matrix identity
  recomputation;
- the malformed matrix ref and digest correctly reproduce its own mutated
  bytes;
- semantic evaluation still rejects it as `stop_branch_matrix_conflict`;
- replacing the malformed governed result with the required deny result makes
  the value exactly valid again;
- the malformed vector is not rejected first for identity, digest, grammar,
  owner or temporal reasons.

IDENTITY AND SUPERSESSION REGENERATION

Do not patch outer hashes only.

At minimum, rebuild these changed existing substantive records from semantic
inputs:

- behavior-profile.rw0-c-decision-time-global-stop-branch.v1
- value-schema.V32.rw0cdecisiontimeglobalstopbranchmatrixv1
- golden.V32.primary
- malformed.global-stop-branch-mismatch
- assurance.A055

Add the five new substantive records required above:

- golden.owner.global-stop.active
- golden.V27.active-stop-control
- golden.V32.active-stop
- assurance.A059
- assurance.V7G001.global-stop-active-applicability-split

Append exactly five V6-to-V7 record-payload supersession entries, one for
each changed existing substantive record above. Do not add record-payload
supersessions for new records, the manifest, or the closeout.

Append exactly two semantic-identity supersessions:

- the old V6 decision-time global-stop profile digest to the new V7 profile
  digest;
- the old V6 clear `golden.V32.primary` matrix ref/digest to the new V7 clear
  matrix ref/digest.

No other current semantic identity should change under this bounded repair. If
one does, stop with transitive regeneration failure rather than widening the
package. Do not rewrite or delete any historical V1-V6 supersession record.

The old V6 profile digest is:

048759ce73b3f1aba6c5e8e8fd5c16201e6d131887f8a192f981c699379637c5

The required V7 profile digest is:

6139df3c64d3736e6938605bc6abef22c258e4841ffe8b641d7a70490f6a5e47

The old V6 clear V32 matrix ref is:

rw0-c-global-stop-matrix.4790e9464729d911afb2c2e5f7831dc5abd96fc60cdd57ba823644e78dcbaf65

The old V6 clear V32 matrix digest is:

9e3f6d1c4d0d76415a43479a0bc2faeb0ce8c2721554c4c08e96727b9728c433

Regenerate:

- changed payload hashes;
- behavior-profile domain digest;
- generated refs and self-digests;
- all new supersession entries;
- dense indexes;
- manifest record and hash arrays;
- content aggregate;
- closeout;
- whole-file identity.

UNCHANGED-PAYLOAD GUARD

For every V6 record ID retained in V7 and not in the exact changed substantive
set, require byte-identical `payload_json`.

Outer JSONL lines may change only where dense `record_index` movement or
manifest/closeout regeneration requires it. Do not describe index-only outer
changes as semantic payload changes.

PACKAGE-WIDE SUPERSESSION GUARD

Repeat and preserve the V6 typed supersession-leakage guard.

For every supersession entry with a 64-lowercase-hex `old_identity`:

- scan every embedded payload;
- permit that exact old identity only in supersession_entry records and a
  dedicated malformed_vector when the identity is the deliberate rejected
  input for that vector;
- reject it in assurance_case, current golden_value, value_schema,
  behavior_profile, source_owner_binding, module_allocation, import_edge,
  equality_matrix, remaining_seam, manifest, closeout or any other current
  truth;
- report the scan population, unique old identities, permitted malformed-only
  occurrences and zero forbidden occurrences.

The old V6 profile and clear-matrix identities introduced into the V7 ledger
must not remain in V7 current profile/schema/golden truth.

REVISED DELIVERABLE

Attach exactly:

RW0_Post_Execution_Canonical_Audit_Package_V7.jsonl

Use the same canonical JSONL envelope and closed record-type ordering. Require
exactly 1559 logical records with these per-type counts:

package_manifest: 1
source_owner_binding: 23
value_schema: 44
behavior_profile: 28
golden_value: 199
malformed_vector: 90
module_allocation: 44
import_edge: 31
equality_matrix: 36
assurance_case: 119
supersession_entry: 935
remaining_seam: 8
package_closeout: 1

Relative to V6 require exactly:

- five changed existing substantive records;
- five new substantive records;
- seven new supersession records;
- zero retired record IDs;
- no other semantic payload changes.

Do not overwrite, rename or present V6 as the repaired deliverable.

MECHANICAL AND SEMANTIC VERIFICATION

Before success:

1. Repeat every V6 package mechanic check with duplicate-key rejection.
2. Reproduce every outer and embedded canonical JSON encoding.
3. Reproduce every payload length, raw hash and domain-separated digest.
4. Reproduce dense indexes, unique IDs, record ordering, manifest, aggregate,
   closeout and whole-file SHA-256 with two independent readers/hash tools.
5. Verify the exact V6-to-V7 changed/new/retired record inventory.
6. Run the unchanged-payload guard.
7. Run the repaired V32 truth-table and active-control guards.
8. Run the causal malformed-vector guard.
9. Run the package-wide supersession guard with zero forbidden occurrences.
10. Recheck all preserved V1-V6 repairs and accepted contracts.
11. Recheck current-source rank-15 anchors and the runtime exact-family matcher
    posture without changing them.
12. Validate all current goldens against their schemas and profiles.
13. Validate all generated refs and self-digests, including both V32 goldens and
    the mutated self-consistent malformed matrix.
14. Confirm the active owner fixture is synthetic assurance evidence only and
    did not replace the current clear source-owner or V27 scenario.
15. Confirm V35-V37 remain absent from current schemas, current goldens,
    allocations and implementation scope. The new finite active controls do not
    count as V35-V37 or committed-recovery implementation.
16. Recheck repository baseline, worktree count and cleanliness.
17. Confirm no repository file or Git state changed.

INLINE REPORT

Print a concise but complete report containing:

- attachment receipt for V6;
- baseline verification;
- disposition of V6-AUDIT-001 and V6-AUDIT-002;
- exact repaired decision-time precedence;
- exact new profile digest;
- active owner fixture canonical value, derived stop ref and raw digest;
- active V27 snapshot ref and digest;
- clear and active V32 matrix refs/digests and exact five-entry outcomes;
- causal malformed mutation and proof that its own ref/digest reproduce;
- exact filename, size, SHA-256, logical records, final-newline posture,
  per-type counts and content aggregate for V7;
- changed, new and retired record IDs;
- exact V6-to-V7 semantic and record-payload supersession entries added;
- unchanged-payload result;
- package-wide supersession scan population and zero-violation result;
- confirmation that all preserved contracts remain intact;
- confirmation that V7 is visibly attached;
- confirmation that no predetermined Downloads path was required;
- confirmation that no private path is offered as the deliverable;
- success token.

SUCCESS TOKEN

Return exactly:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V7_GLOBAL_STOP_REPAIRED_READY_FOR_INDEPENDENT_AUDIT

only if:

- both audit findings are closed;
- the V32 profile implements the exact authoritative truth table;
- the active-stop positive control has three governed denies and two halt-only
  permits on a valid active owner and matching active snapshot basis;
- the malformed vector is causally distinct, self-consistent and rejected for
  branch semantics;
- every direct and transitive identity is regenerated;
- unchanged payloads remain byte-exact;
- the supersession scan has zero forbidden occurrences;
- every package and source-grounding verification passes;
- V7 is visibly attached;
- repository state remains unchanged;
- no implementation prompt is issued.

Otherwise return:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V7_REPAIR_BLOCKED

and classify the blocker as exactly one of:

- fixed-input mismatch;
- fixed-input attachment unavailable;
- baseline mismatch;
- current-source reconstruction failure;
- active-control construction failure;
- semantic contradiction;
- causal-vector failure;
- transitive regeneration failure;
- supersession leakage;
- unchanged-payload drift;
- canonical verification failure;
- attachment mechanism unavailable.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
