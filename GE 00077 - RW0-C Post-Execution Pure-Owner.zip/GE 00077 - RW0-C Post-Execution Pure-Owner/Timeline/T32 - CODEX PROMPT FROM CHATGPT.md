Objective

Repair the exact provenance-bound RW0 post-execution pure-owner implementation candidate after the independent audit returned BLOCK.

Repository

/Users/ds/Repositories/Governed Execution Coordinator

Engagement posture

This is a workspace-write REPAIR engagement in the existing implementation conversation.

- The parent is the sole repository writer.
- Do not spawn subagents.
- Do not perform or claim an independent audit.
- Do not stage, commit, push, create a PR, publish, contact a remote, install dependencies, run migrations, invoke live services, or inspect/modify supporting repositories.
- Preserve the exact accepted six-module, private, pure, no-I/O, migration-free architecture and the exact twenty-path repository ceiling.
- Repair the implementation and permanent tests; do not reopen or regenerate the accepted V11 owner-contract package.
- Treat the audit report as blocking evidence to correct, not as permission to widen scope.

Required final success token

RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIRED_VALIDATED_PROVENANCE_READY_FOR_REAUDIT

Required blocking token

RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIR_BLOCKED

Required provenance-mismatch token

RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIR_PROVENANCE_MISMATCH

Exact fixed repair inputs

1. RW0_Post_Execution_Pure_Owner_Implementation_Independent_Audit_Report_V1.md
   - size: 29,347 bytes
   - SHA-256: 178c49932c838ecc4a5e1b03143503fd281ad42e548db40ac6364ebabd5ef21c
   - logical lines: 421
   - final newline: absent
   - primary verdict: BLOCK

2. RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V1.json
   - size: 4,376 bytes
   - SHA-256: c4d207c8a7ec35ba518bf3739a7069148a368477ec30198a12845c5ba5357bc1
   - canonical compact sorted-key JSON
   - final newline: present
   - recipe ID: governed-execution.audit-patch-manifest.v1
   - baseline HEAD: a3ff0b7f4f0c2378c2962e24612d605489b51638
   - file count: 20
   - tracked textual diff SHA-256: e17b5828848c62eebf3c9aece79b5bed89753f620e5ba3134a3561da227af071

3. RW0_Post_Execution_Pure_Owner_Implementation_Report_V1.md
   - size: 19,966 bytes
   - SHA-256: c6cf934721db83ddb67ff105d52c12f6fecea0b85eabf47d38f8828378c87433
   - logical lines: 372
   - final newline: present
   - historical implementation report only; its semantic-completeness and test-coverage claims were rejected by the audit

Previously supplied governing inputs remain fixed and must already be available in this implementation conversation:

- Coordinator_RW0_Post_Execution_Pure_Owner_Implementation_Prompt.txt
  SHA-256 2ff652b1aabb65bdb9507a6d6954c139b799f4520591ecc0726b29e5d2888650
- RW0_Post_Execution_Pure_Owner_Implementation_Boundary_Freeze_V1.md
  SHA-256 02b932abdfdb0085886000c19cdbcc4e9e72ebb951a5030056a621e181d33d55
- RW0_Post_Execution_Pure_Owner_Implementation_Boundary_Manifest_V1.json
  SHA-256 927646d30430d5b6b3acacdc2f4b752721c3ed7ae62673962542120cfce0c386
- RW0_Post_Execution_Pure_Owner_Implementation_Boundary_Review_Overlay_V1.json
  SHA-256 ba8202629aebd895c7a4bae7ad147a2d68e9d368e27ede80a965b46809b32f92
- RW0_Post_Execution_Canonical_Audit_Package_V11.jsonl
  SHA-256 e26a739dc303a555aa951e23ccd84b3583377319a82b5fcd78f99397da894afe
- RW0_Post_Execution_Canonical_Audit_Package_V11_Independent_Audit_Report.txt
  SHA-256 b5b3c1e9a426a6ce25c5a5bbb622d4a4838459750ebbe457fb9e6f9816f82548
- governed_execution_audit_patch_manifest_v1.py
  size 3,945 bytes
  SHA-256 db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
  recipe ID governed-execution.audit-patch-manifest.v1

If any required input is unavailable or differs, stop. Do not search for or substitute a same-named file.

Authority and seam classification

Current merged authority

- The fixed Coordinator repository at HEAD a3ff0b7f4f0c2378c2962e24612d605489b51638 remains current merged truth.
- Existing current owners, migration 0003, the private C1 readers/matcher, migrations 0001-0004, public surfaces, StateStore, WriterSession, and the fifteen-kind C1 inventory remain protected and unchanged.

Accepted proposed contract

- The exact V11 package and its accepted audit define the proposed private pure-owner semantics.
- The freeze and boundary manifest define implementation allocation, import graph, touched paths, validation, and non-authorizations.

Repairable patch defects

- RW0-AUD-001: evaluators trust caller-authored conclusions instead of deriving them from authoritative typed inputs and frozen profile/equality rules.
- RW0-AUD-002: permanent tests inventory accepted records but do not execute their responsibilities.
- RW0-AUD-003: exact closed grammar is under-enforced.
- RW0-AUD-004: the runtime inventory guard exempts arbitrary bytecode too broadly.
- RW0-AUD-005: documentation and the V1 report overstate implementation completeness.
- RW0-AUD-006: opening implementation/cache evidence was not retained in independently reviewable safe form.

No architecture reset

- The six-module allocation remains accepted.
- The twenty-path repository ceiling remains accepted.
- The private/no-I/O/migration-free/non-public boundary remains accepted.
- No new value schema, V-number, behavior profile, module, migration, durable owner, public caller, runtime path, or authority surface is authorized.

Pre-edit receipt and exact starting-candidate gate

Before any repository edit:

1. Print an attachment receipt for the three fixed repair inputs, including observed client-exposed path, size, SHA-256, logical units, and final-newline posture.
2. Verify the exact provenance recipe source bytes and SHA-256.
3. Verify repository root exactly:
   /Users/ds/Repositories/Governed Execution Coordinator
4. Verify:
   - branch trunk_dev
   - HEAD a3ff0b7f4f0c2378c2962e24612d605489b51638
   - tree d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0
   - sole parent 047563de5a443b0f8323401c92979ae2e444d2ed
   - subject feat: implement RW0-C1 durable evidence (#7)
   - upstream origin/trunk_dev
   - ahead/behind 0/0
   - one worktree
   - no staged or unmerged path
5. Run the exact provenance recipe twice serially against the live working tree.
6. Require both outputs to be byte-identical to each other and to the fixed V1 provenance manifest in every field:
   - repository identity
   - exact twenty paths
   - tracked/untracked classification
   - regular-file type
   - mode
   - size
   - per-file SHA-256
   - textual diff SHA-256
   - canonical manifest bytes and SHA-256
7. Stop with RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIR_PROVENANCE_MISMATCH on any discrepancy. Do not inspect or repair correctness after a mismatch.
8. Record a safe opening repair evidence artifact outside the repository before edits:
   RW0_Post_Execution_Pure_Owner_Implementation_Repair_Opening_Evidence_V2.json

The opening evidence must be canonical compact sorted-key JSON, contain no absolute operator paths or secrets, and include:

- branch, HEAD, tree, parent, subject, upstream, divergence, worktree count
- exact V1 provenance manifest filename, size, SHA-256, textual diff digest, and file count
- exact staged/unmerged posture
- safe repo-relative inventory of pre-existing ignored cache/bytecode members: path, type, mode, size, SHA-256
- normalized cache-inventory aggregate
- explicit statement that it is evidence only and not runtime or repository authority

Expose this opening evidence as a client-visible attachment at closeout. Do not store it in the repository.

Exact repository touched-path ceiling

No repository path may be created, deleted, renamed, or modified outside these twenty paths.

New/private source modules already present in the candidate

1. src/ge_nwp_coordinator/_post_execution_evidence_values.py
2. src/ge_nwp_coordinator/_post_execution_policy_values.py
3. src/ge_nwp_coordinator/_finite_backlog_risk_source_adapter.py
4. src/ge_nwp_coordinator/_section41_post_execution_proposal_family_projection.py
5. src/ge_nwp_coordinator/_section41_post_execution_role_resolution.py
6. src/ge_nwp_coordinator/_rw0_c_decision_input_values.py

New tranche tests already present in the candidate

7. tests/test_post_execution_pure_owner_values.py
8. tests/test_post_execution_pure_owner_vectors.py
9. tests/test_post_execution_pure_owner_relations.py
10. tests/test_post_execution_pure_owner_boundaries.py

Existing guard tests

11. tests/test_c2a_nonimplementation.py
12. tests/test_runtime_non_authority.py
13. tests/test_rw0_b1_boundaries.py

Governing/status documentation

14. .docs/autonomous-software-development-operating-model.md
15. .docs/c2b-durable-development-state.md
16. .docs/rw0-b1-pure-phase-values.md
17. .docs/rw0-remote-worker-contact-phase-entry.md
18. .docs/architecture.md
19. .docs/c2a1-pure-semantic-values.md
20. .docs/rw0-c1-durable-evidence.md

Stop if repair requires any twenty-first repository path.

Protected surfaces

Do not modify or regenerate:

- any migration or migration catalog
- any SQLite reader, writer, row owner, transaction/controller, recovery, or capability implementation
- src/ge_nwp_coordinator/__init__.py
- StateStore or WriterSession surfaces
- current C1 source, row, reader, matcher, and fifteen-kind inventory
- package-root exports
- CLI, service, scheduler, queue, daemon, worker, provider/model, process, filesystem, network, environment, or clock behavior
- supporting repositories
- accepted V11 package/audit, freeze artifacts, review overlay, or provenance recipe

No new dependency may be installed.

Repair strategy

Repair in dependency order. Do not paper over findings by deleting action symbols, weakening profiles, reducing the accepted corpus, broadening error vocabularies, or changing expected values.

Part A — Exact closed grammar for all 44 allocations

Implement one fail-closed local validation foundation inside the existing six-module graph, without introducing a seventh module.

For every accepted value and nested value:

1. Require the exact built-in outer type.
   - dict means type(value) is dict, not Mapping or subclass.
   - list means type(value) is list; tuple must reject.
   - int rejects bool.
   - nullable branches accept only the exact allowed type or exact None.
2. Require exact key presence and exact declared key iteration order, not set equality.
3. Reject unknown or missing fields before canonicalization, generated-reference comparison, or self-digest comparison.
4. Enforce literal schema/profile constants before dependent relations.
5. Enforce every field-specific and profile-specific string/ref byte bound.
   - Do not use one global 128-byte ceiling where the accepted contract requires 96.
   - The audit’s 97-byte safe-reference probe must reject.
6. Enforce exact lowercase-hex widths, UTC whole-second timestamps, Git object-format/OID rules, enum membership, nullability, integer bounds, list cardinality, duplicate rejection, and canonical ordering.
7. Enforce list member grammar and closed vocabularies, not merely arbitrary strings.
8. Enforce generated reference and self-digest only after all grammar, nested, and cross-value relations pass.
9. Preserve V16 as exactly five parent-bound encoded fields.
10. Preserve the accepted private exception type and accepted local reason vocabulary. Do not add public or durable error truth.

The following audit probes must be permanent causal failures:

- reordered outer mapping
- tuple supplied for exact_builtin_list
- 97-byte safe ref where the accepted maximum is 96
- non-enum V41 allowed_branches member

Each must fail at the earliest accepted validation layer and before identity acceptance.

Part B — Derive evaluator/action outputs; never trust caller-authored conclusions

All 27 frozen action functions must be real pure evaluators or exact reconstruction actions.

General rule

- Authoritative typed inputs and frozen profile payloads determine the output.
- A caller-supplied candidate result may be accepted only as an expected-output assertion that is compared byte-for-byte against an independently derived result.
- A self-consistent re-signed false conclusion must reject.
- from_mapping or constructor rehydration is not an evaluator.
- Preserve existing action names, private module locations, value schemas, profile refs/digests, and output identities.
- Private helper signatures may be refactored within the six modules only to represent already-frozen typed inputs and finite page transcripts. They may not introduce new accepted semantics or runtime I/O.

Evidence/profile actions

Implement complete frozen cross-field/source/profile/chronology/equality behavior for V01-V15, V20-V21, V38-V40 and nested values, including:

- V14 validation disposition: derive result/reason from exact validation requirement, source observation kind/outcome, source/result sets, chronology, and profile. A failed source observation must not be accepted as validation-passed.
- V15 independent review disposition: equivalent exact review source, outcome, result-set, chronology, requirement, and profile checks.
- V20 stop evidence and V21 source-effect ceiling: enforce exact owner/source/fence/currentness relations and expiry semantics.
- V38/V39 result sets: enforce source/result equality, cardinality, ordering, and evidence identities.
- V40 operational reviewer separation: derive only from exact author/reviewer role, invocation, effect, delivery, observation locator, candidate/capsule/phase lineage, and profile; reused reviewer invocation must not be accepted as separate.
- Preserve V40’s explicit non-authentication boundary.

Policy/risk actions

Implement exact parent-owned V16 dispatch and complete V17/V18/V41/V42/V43/V44 profile/source/binding semantics.

- V16 reason/result/applicability/effect-class dispatch must come from the consuming parent profile.
- V17/V18 branch entries must be derived from exact policy/risk owner inputs and source bindings.
- V41/V42 allowed branch/risk/effect lists must enforce exact enums, order, source relations, and attestation semantics.
- The generic risk layer must remain independent from FiniteBacklog.
- The V19 adapter remains one-way and confers no progression authority or identifier equality.

Part C — Ground Section 41 projection and resolution in current owners

V22 and V24 must no longer rehydrate a supplied mapping as proof.

V22 projection must derive from and verify:

- exact current source invocation
- exact artifact binding and chronology
- exact proposal and evidence-set identities
- all nine current migration-0003 physical rows reconstructed through current row owners
- exact private-reader tuples
- exact zero-or-nine posture
- exact twelve-locator owner-family graph
- accepted rank-15 wrapper, relation, admission graph, membership, and admitted_by_mutation_ref
- exact role/rank/ordinal/profile/source/evidence locators
- exact resupply and privacy rules

V24 resolution must:

- call the complete exact-family helper rather than bypass it
- require all nine canonical roles, ranks 5-13, ordinal zero, exact ordering, exact profiles, exact locators, exact typed values, and exact projection coordinates
- resolve exactly one requested role from the accepted family
- reject role substitution, ordinal substitution, wrong profile, wrong locator, incomplete family, duplicate family, or mismatched resupply

The audit’s V22 artifact-before-source chronology probe and V24 rank-5 role substitution probe must reject before output identity acceptance.

Part D — Implement complete pure RW0-C decision-input semantics

Remain pure and no-I/O. Do not add a reader or durable owner.

V25/V26 membership closure

Implement the already-frozen finite page-transcript semantics through private pure inputs/helpers inside _rw0_c_decision_input_values.py:

- page size 256
- LIMIT 257 semantics
- strict cursor monotonic progress
- no duplicate or reordered membership
- one capability epoch across the transcript
- maximum 65,536 accepted entries
- explicit 65,537th-entry overflow probe
- premature termination, no-progress cursor, continuation substitution, epoch change, and overflow rejection
- complete closure equality, selected membership inclusion, and exact digest/ref reconstruction

The public-within-private action must invoke this logic. An incomplete one-entry subset must not be accepted as a complete closure.

Do not introduce a new persisted schema. A private finite page transcript or callback-free page sequence is an implementation detail only if it exactly represents the frozen profile. Stop if faithful implementation requires a new accepted semantic choice.

V27/V28/V29/V30

- Derive the exact current snapshot from the documented owner rows, closure, selected authority/rank-15 memberships, external coordinates, and exactly five separately resupplied sources.
- Enforce all required source equalities and exclusions.
- Keep validation, review, policy, risk profile, and risk binding currentness distinct.
- Map conflict to basis_conflict, stale/unknown to no_decision, and only fully current to continuation exactly as frozen.

V31/V32/V33

- Derive each five-branch matrix from the exact parent snapshot/source/profile.
- Apply exact source-bound precedence; do not accept a globally valid result/reason pair detached from the source state.
- V31 must bind exact closure, selected authority membership, proposal, and authority profile.
- V32 precedence remains:
  1. snapshot/stop identity mismatch -> conflict
  2. profile mismatch -> conflict
  3. global stop unknown -> unknown
  4. halt-only -> permit / halt_only_stop_checked
  5. active stop -> deny / global_stop_active
  6. otherwise -> permit / global_stop_clear
- An active-stop parent paired with clear/permit governed entries must reject.
- V33 must bind the exact source-effect ceiling and precedence, including expiry and halt-only behavior.

V34

- Derive recommendation consistency from the complete authoritative V31/V32/V33 input relation and model recommendation.
- Do not validate only branch-name correspondence.
- Model output remains evidence, not authority.

Part E — Replace inventory-only tests with executable finite responsibility coverage

The permanent repository tests must not load the external V11 package, audit report, freeze, repair audit, or implementation reports at runtime.

They may use test-owned literals and independent test-local reconstruction authored from the accepted contracts, but they must not merely inventory IDs or import implementation expected constants.

Build an executable coverage registry or equivalent in the existing four new test files such that every accepted responsibility is invoked and checked:

- 201 golden records
- 93 malformed controls
- 126 assurance cases
- 36 equality matrices
- 31 import edges
- 8 remaining seams
- all 44 allocations
- all 28 profiles/evaluators
- all 27 action functions

Requirements

1. Every record ID maps to at least one concrete executable positive, causal negative, source-grounding, equality, boundary, or explicitly deferred-seam assertion.
2. A count/prefix/ID-membership assertion alone is insufficient.
3. Every malformed control performs its exact one-predicate mutation, asserts the first accepted failure class, and restores byte-exactly where the contract requires.
4. Every assurance case names and executes its positive or negative responsibility.
5. Every equality ID is exercised across its exact boundary; none may be absent from the tests.
6. Every seam ID is asserted as preserved, absent, and non-authorizing according to its frozen meaning.
7. All 31 import edges are checked, and every extra edge is rejected. Include the seven reserved/runtime forbidden responsibilities that have no source module.
8. Production-caller scanning must cover all six modules, not three.
9. Rank-15 tests must independently reconstruct the current nine-row family, twelve-locator graph, wrapper, relation, admission graph, membership, mutation ref, and matcher result. Hard-coded dictionary equality alone is insufficient.
10. V32 tests must derive active and clear expected matrices independently from the profile/source state; do not construct an expected vector and immediately rehydrate the same vector.
11. Scalar exactness must test every scalar field and branch, not stop after the first integer field per class.
12. Add explicit regression tests for all ten audit probes:
    - reordered mapping
    - tuple as list
    - 97-byte ref
    - invalid V41 enum member
    - invalid V22 chronology
    - V24 role substitution
    - incomplete V25 closure
    - active-stop/clear-result mismatch
    - V40 invocation reuse
    - failed observation marked passed
13. Add focused tests demonstrating that independently re-signing any of those invalid values still rejects before final identity acceptance.
14. Do not weaken or delete existing passing protections to obtain a pass.

Part F — Tighten the runtime inventory bytecode exception

Modify only tests/test_runtime_non_authority.py within its authorized guard responsibility.

The guard may ignore pre-existing bytecode only when all of the following hold:

- the cache directory is the exact authorized source cache location
- the cache member is a regular file, not a symlink or other type
- the member is directly under that cache directory, not nested
- the filename follows the accepted interpreter cache naming form
- it corresponds to an existing authorized .py source file in the closed production inventory
- it is not orphaned, unexpectedly named, or located elsewhere

Do not exempt arbitrary .pyc/.pyo files merely because an ancestor is named __pycache__.

Add negative controls for:

- bytecode in an unexpected location
- nested cache directory
- unexpected bytecode name
- .pyo posture if not source-corresponding
- orphaned bytecode with no source
- symlink/non-regular bytecode member
- bytecode-only production path

Do not delete or rewrite pre-existing ignored cache entries.

Part G — Reconcile documentation only after code and tests are truthful

Update the same seven documentation paths after the repaired semantics and tests pass.

- Preserve all historical/protected prefixes, H2 ordering, current C1 authority, and negative claims.
- State implemented-private-pure only for semantics actually implemented and tested.
- Do not claim runtime, durable decision, completeness, external authenticity, permission, migration, public export, production caller, C2B progression, terminal, RW0-D/E, or Execution Substrate behavior.
- Remove or correct the specific overclaims identified by the audit in .docs/architecture.md and .docs/c2b-durable-development-state.md.
- Do not rewrite accepted architecture or authority contracts.

Part H — Correct report/process evidence

Do not edit the historical V1 implementation report. Produce a successor report:

RW0_Post_Execution_Pure_Owner_Implementation_Report_V2.md

The V2 report must:

- state that V1 was blocked by the independent audit
- list every audit finding and its exact repair disposition
- distinguish structural boundary success from repaired semantic correctness
- include the exact opening V1 provenance receipt
- include the client-visible opening repair evidence artifact receipt
- label V00 accurately; do not call final-candidate status a pre-implementation baseline
- report every validation command, initial failure, bounded repair, rerun, result, and bytes against which it ran
- avoid claiming independent audit
- state all non-authorizations
- list assumptions, uninspected surfaces, and remaining seams

Required repair deliverables outside the repository

1. RW0_Post_Execution_Pure_Owner_Implementation_Repair_Opening_Evidence_V2.json
2. RW0_Post_Execution_Pure_Owner_Implementation_Report_V2.md
3. RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V2.json

Expose all three through client-visible attachments. A private path is not a substitute.

Development and validation posture

During repair

- Bounded targeted tests may run as needed with PYTHONDONTWRITEBYTECODE=1 and pytest cache disabled.
- Do not alter, move, delete, or rewrite the pre-existing live cache inventory.
- Remove only artifacts created by this repair and proven absent from the opening evidence.

Formal final validation must use a private external local clone so the live repository remains byte-stable and its pre-existing ignored cache is untouched.

External validation-clone requirements

1. Create a private mode-0700 root outside the repository, preferably under /private/tmp.
2. Use clone-time umask 022 inside that private root so committed files retain expected 0644 modes.
3. Construct a local-path clone from the exact committed HEAD only, without fetch or network contact and without hard-link ambiguity.
4. Overlay exactly the live candidate’s twenty manifest-bound files.
5. Verify every overlaid file’s type, mode, size, and SHA-256.
6. Run the exact provenance recipe twice in the clone and require equality to the final live V2 manifest before tests.
7. Run formal V02-V06 serially in the clone, with no concurrent edit or cleanup:

V02 targeted tranche and guard tests

env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_post_execution_pure_owner_values.py tests/test_post_execution_pure_owner_vectors.py tests/test_post_execution_pure_owner_relations.py tests/test_post_execution_pure_owner_boundaries.py tests/test_c2a_nonimplementation.py tests/test_runtime_non_authority.py tests/test_rw0_b1_boundaries.py

V03 current pure dependencies

env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_rw0_b1_phase_values.py tests/test_rw0_b1_vectors.py tests/test_rw0_b1_relations.py tests/test_worker_execution_semantic_values.py tests/test_worker_execution_semantic_vectors.py tests/test_worker_execution_semantic_relations.py tests/test_worker_execution_semantic_boundaries.py tests/test_finite_backlog.py tests/test_global_stop.py

V04 Section 41/C1 regression

env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_section41_cognitive_proposal_row_values.py tests/test_section41_cognitive_proposal_semantic_values.py tests/test_section41_pre_execution_plan_disposition_contracts.py tests/test_section41_pre_execution_plan_disposition_recovery.py tests/test_section41_private_atomic_pre_execution_plan_disposition.py tests/test_section41_private_pre_execution_plan_disposition_delegation.py tests/test_rw0_c1_mutation_contracts.py tests/test_rw0_c1_private_atomic_persistence.py tests/test_rw0_c1_private_readers.py tests/test_rw0_c1_reader_contracts.py tests/test_rw0_c1_recovery.py tests/test_rw0_c1_row_values.py tests/test_rw0_c1_semantic_values.py tests/test_rw0_c1_writer_session_delegation.py tests/test_remote_worker_pre_execution_planning_contract.py::test_f1_post_execution_common_proposal_needs_no_preexecution_context_row tests/test_remote_worker_pre_execution_planning_contract.py::test_s41_post_execution_evidence_is_exactly_zero_or_complete tests/test_remote_worker_pre_execution_planning_contract.py::test_s41_post_execution_evidence_rejects_every_noncanonical_member tests/test_remote_worker_pre_execution_planning_contract.py::test_repaired_nine_table_ddl_and_both_golden_families_are_representable tests/test_remote_worker_pre_execution_planning_contract.py::test_migration_0003_owner_freezes_exact_representability_without_0002_rebuild

V05 catalog/docs/public boundaries

env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_sqlite_b1_migrations.py tests/test_sqlite_c2b1_migration_framework.py tests/test_sqlite_c2b2_migration_0002.py tests/test_sqlite_section41_migration_0003.py tests/test_sqlite_rw0_c1_migration_0004.py tests/test_autonomous_software_development_operating_model.py tests/test_architecture_contracts.py tests/test_rw0_remote_contact_phase_entry_contract.py tests/test_software_development_progression_boundary.py tests/test_rw0_b2_wire_boundaries.py tests/test_rw0_b2_capability_boundaries.py

V06 full repository

env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q

8. Then run in the clone:

- git diff --check
- exact changed/untracked/staged/unmerged/status inventory
- artifact scan for __pycache__, .pytest_cache, .pyc, .pyo, SQLite DB/journal/WAL/SHM, lock, build, egg-info, tarball, OS metadata, symlink, or unsupported type
- provenance recipe twice again

9. Require post-validation provenance to equal the final live V2 manifest exactly.
10. Remove the entire external validation root at closeout.

Live final provenance and hygiene

After code, tests, docs, and external-clone validation are final:

1. Verify the live repository still has exactly the same twenty paths and no staged/unmerged path.
2. Verify every protected/unlisted path remains unchanged.
3. Verify the live pre-existing cache inventory equals the opening evidence byte-for-byte and has no addition, deletion, or change.
4. Run the exact provenance recipe twice serially in the live repository.
5. Require byte-identical outputs.
6. Save the canonical output as:
   RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V2.json
7. Record:
   - recipe ID and source SHA-256
   - new tracked textual diff SHA-256
   - new canonical manifest SHA-256 and size
   - exact file count
   - exact branch/HEAD/upstream
8. Expose the manifest as a client-visible attachment.
9. Do not stage, commit, push, or audit.

Stop conditions

Stop with RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIR_BLOCKED rather than widening if:

- starting provenance does not match V1
- an input differs or is unavailable
- a twenty-first repository path is required
- a seventh source module is required
- a new V-number/schema/profile/accepted semantic choice is required
- a migration, SQLite/current-owner edit, public export, production caller, runtime I/O, durable write, or cross-repository effect is required
- the accepted six-module import graph must widen or reverse
- an accepted V11 responsibility cannot be implemented without contradicting another accepted responsibility
- external-clone validation cannot bind the exact live candidate bytes
- any high- or medium-severity correctness, authority, test, documentation, security, privacy, or artifact uncertainty remains
- final provenance is unstable

Required final response structure

1. Primary verdict and exact token.
2. Fixed-input and starting-provenance receipt.
3. Opening evidence artifact identity and attachment link.
4. Exact repair disposition for RW0-AUD-001 through RW0-AUD-006.
5. Exact twenty-path final inventory and confirmation of zero extra/missing paths.
6. Source semantics summary by six-module owner.
7. Executable finite-coverage summary:
   - 201 goldens
   - 93 malformed controls
   - 126 assurances
   - 36 equalities
   - 31 import edges
   - 8 seams
   - 27 actions
   Include actual executed-case counts and explain any many-to-one test parametrization without treating ID inventory as execution.
8. Mandatory ten-probe results and first failure classifications.
9. Runtime-bytecode guard results.
10. Documentation reconciliation.
11. Exact V02-V06 commands and results from the external clone.
12. External-clone start/end provenance equality and artifact cleanup.
13. Live opening/final cache equality.
14. Final V2 provenance identity and attachment link.
15. V2 implementation report identity and attachment link.
16. Assumptions, unresolved seams, skipped validation, and inspection limits.
17. Explicit non-actions.

Required non-actions in the final response

INDEPENDENT_AUDIT_NOT_PERFORMED
MIGRATION_0005_NOT_CREATED
SQLITE_RUNTIME_NOT_WIDENED
PUBLIC_EXPORT_NOT_CREATED
PRODUCTION_CALLER_NOT_CREATED
DURABLE_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
SUPPORTING_REPOSITORIES_NOT_MODIFIED

Success means only that a new exact repair candidate is validated and provenance-bound for a fresh independent audit. It does not authorize a commit gate or any runtime/durable effect.
