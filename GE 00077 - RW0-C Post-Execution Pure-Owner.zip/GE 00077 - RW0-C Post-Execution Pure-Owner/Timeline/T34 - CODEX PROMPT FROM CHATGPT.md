Objective

Independently re-audit the exact repaired RW0 post-execution pure-owner implementation candidate in the Governed Execution Coordinator repository.

The V1 candidate was independently audited and correctly BLOCKED. The V2 implementation conversation reports bounded repairs, formal validation, and new exact provenance. This engagement must verify those claims against the exact live candidate. Do not repair the candidate.

Repository

/Users/ds/Repositories/Governed Execution Coordinator

Audit posture

- Fresh parent-only, local, read-only Codex conversation.
- Do not spawn subagents.
- Do not contact remotes or networks.
- Do not install dependencies.
- Do not open or mutate a persistent database.
- Do not invoke a worker, provider, product model, Bridge, Execution Substrate, or supporting repository.
- Do not inspect sibling repositories.
- Temporary audit files and a private validation clone may be created only outside the repository.
- Do not remove, relocate, rewrite, normalize, import, or otherwise alter any live-repository tracked file, untracked candidate file, ignored cache, or other artifact.
- The audit does not edit, format, clean, stage, commit, push, publish, or repair.
- Stop before correctness inspection with AUDIT_PROVENANCE_MISMATCH if the live candidate does not match the exact V2 provenance target.

Authority and evidence classification

- Current merged repository docs, source, tests, and migrations at the fixed baseline remain current repository truth.
- The accepted V11 package and V11 package audit are accepted proposed owner-contract evidence, not durable Coordinator authority or runtime truth.
- The freeze report and machine boundary, interpreted only through the exact review overlay, define the accepted six-module and twenty-path implementation boundary.
- The original implementation prompt and V2 repair prompt define mutation authorization history; they do not override owning repository contracts.
- The V1 independent audit is blocking evidence describing defects in the V1 bytes.
- The V1 report and V1 provenance manifest are historical evidence identifying the exact blocked starting candidate.
- The V2 report, opening evidence, and V2 provenance manifest are implementation-conversation evidence and must not be trusted before independent reproduction.
- Git owns object/ref truth. Exact working-tree bytes plus the fixed provenance recipe define the re-audit target.
- Validation output is evidence, not correctness or authority.

Exact fixed inputs

Resolve every attachment only through the client-exposed attachment context. Do not search the filesystem for substitutes and do not use a same-named file that was not supplied as an attachment.

1. RW0_Post_Execution_Pure_Owner_Implementation_Report_V2.md
   - 21,217 bytes
   - SHA-256 ace2c92c66eea311820702cf844a8f802a8a78c82c4c208e37bc42133094e878
   - 427 logical lines
   - final newline present
   - implementation verdict only; not independent acceptance

2. RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V2.json
   - 4,377 bytes
   - SHA-256 7ada36bd287de85823926090e07e8e33ca1fe038963984c8eed0f423329f1284
   - one logical line
   - final newline present
   - canonical compact sorted-key JSON
   - recipe ID governed-execution.audit-patch-manifest.v1
   - baseline HEAD a3ff0b7f4f0c2378c2962e24612d605489b51638
   - file count 20
   - textual diff SHA-256 897e95f470b55690abb2c25bd2b1d0b760ad9e6b0b3541f4ad4f5012cd0f022f

3. RW0_Post_Execution_Pure_Owner_Implementation_Repair_Opening_Evidence_V2.json
   - 9,738 bytes
   - SHA-256 adbe22edebc6e8e7beac735ad36cf1a9fb8535ba1c9312e8534f645ca87ec786
   - canonical compact sorted-key JSON
   - final newline present
   - reported source mode 0600
   - safe evidence only; no absolute operator paths or secrets

4. RW0_Post_Execution_Pure_Owner_Implementation_Independent_Audit_Report_V1.md
   - 29,347 bytes
   - SHA-256 178c49932c838ecc4a5e1b03143503fd281ad42e548db40ac6364ebabd5ef21c
   - 421 logical lines
   - final newline absent
   - verdict BLOCK

5. RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V1.json
   - 4,376 bytes
   - SHA-256 c4d207c8a7ec35ba518bf3739a7069148a368477ec30198a12845c5ba5357bc1
   - one logical line
   - final newline present
   - canonical compact sorted-key JSON
   - textual diff SHA-256 e17b5828848c62eebf3c9aece79b5bed89753f620e5ba3134a3561da227af071

6. RW0_Post_Execution_Pure_Owner_Implementation_Report_V1.md
   - 19,966 bytes
   - SHA-256 c6cf934721db83ddb67ff105d52c12f6fecea0b85eabf47d38f8828378c87433
   - 372 logical lines
   - final newline present
   - historical blocked implementation report only

7. Coordinator_RW0_Post_Execution_Pure_Owner_Implementation_Repair_Prompt_V2.txt
   - 32,251 bytes
   - SHA-256 394018c64671b4aeaef6e7b5b5feb9c7e9ee8c4d08425046304eb40cba12b3b0
   - 596 logical lines
   - final newline present

8. governed_execution_audit_patch_manifest_v1.py
   - recipe ID governed-execution.audit-patch-manifest.v1
   - 3,945 bytes
   - SHA-256 db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
   - 166 logical lines
   - final newline present

9. RW0_Post_Execution_Pure_Owner_Implementation_Boundary_Freeze_V1.md
   - 179,000 bytes
   - SHA-256 02b932abdfdb0085886000c19cdbcc4e9e72ebb951a5030056a621e181d33d55
   - 415 logical lines
   - final newline present

10. RW0_Post_Execution_Pure_Owner_Implementation_Boundary_Manifest_V1.json
    - 484,768 bytes
    - SHA-256 927646d30430d5b6b3acacdc2f4b752721c3ed7ae62673962542120cfce0c386
    - one logical line
    - final newline absent
    - canonical compact sorted-key JSON

11. RW0_Post_Execution_Pure_Owner_Implementation_Boundary_Review_Overlay_V1.json
    - 2,005 bytes
    - SHA-256 ba8202629aebd895c7a4bae7ad147a2d68e9d368e27ede80a965b46809b32f92
    - one logical line
    - final newline absent
    - verdict FREEZE_ACCEPTED_WITH_EXACT_REFERENCE_CORRECTION

12. RW0_Post_Execution_Canonical_Audit_Package_V11.jsonl
    - 2,719,907 bytes
    - SHA-256 e26a739dc303a555aa951e23ccd84b3583377319a82b5fcd78f99397da894afe
    - 1,780 logical records
    - final newline absent
    - content aggregate 476fa5f4e06e0d4cb6e7fdd02ca02fb4a9531c19f0348dd88ac09a9fe9db3e36

13. RW0_Post_Execution_Canonical_Audit_Package_V11_Independent_Audit_Report.txt
    - 29,815 bytes
    - SHA-256 b5b3c1e9a426a6ce25c5a5bbb622d4a4838459750ebbe457fb9e6f9816f82548
    - 369 logical lines
    - final newline absent
    - verdict ACCEPT

14. Coordinator_RW0_Post_Execution_Pure_Owner_Implementation_Prompt.txt
    - 26,824 bytes
    - SHA-256 2ff652b1aabb65bdb9507a6d6954c139b799f4520591ecc0726b29e5d2888650
    - 581 logical lines
    - final newline present

Attachment receipt gate

Before substantive work:

- print observed client-exposed path, filename, size, SHA-256, logical-unit count, and final-newline posture for all fourteen attachments;
- recursively reject duplicate JSON keys in the four JSON artifacts and in every V11 JSONL outer/payload object;
- require exact canonical encoding where specified;
- verify the exact provenance recipe bytes, not only its hash;
- require all attachment receipts to match;
- stop with AUDIT_PROVENANCE_MISMATCH if any fixed input is missing, differs, or was substituted.

Exact overlay treatment

The freeze artifacts remain immutable historical evidence. Apply only these two interpretive corrections:

- malformed.V9R001.model-input-binding-unknown-extra-field
  -> malformed.V9R001.v16-parent-bound-extra-field-rejection

- assurance.V9R001.model-input-binding-unknown-extra-field
  -> assurance.V9R001.v16-parent-bound-extra-field-rejection

Require the accepted V11 package to contain both replacement IDs. Do not edit or regenerate either freeze artifact and do not infer any third correction.

Expected live repository baseline

- physical root exactly /Users/ds/Repositories/Governed Execution Coordinator
- branch trunk_dev
- HEAD a3ff0b7f4f0c2378c2962e24612d605489b51638
- HEAD tree d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0
- sole parent 047563de5a443b0f8323401c92979ae2e444d2ed
- subject feat: implement RW0-C1 durable evidence (#7)
- upstream origin/trunk_dev
- ahead/behind 0/0
- exactly one worktree
- no staged or unmerged path
- exactly the V2 manifest's twenty-path unstaged candidate and no other tracked modification, deletion, rename, or untracked path

Expected V2 canonical patch identity

- recipe ID governed-execution.audit-patch-manifest.v1
- branch trunk_dev
- HEAD a3ff0b7f4f0c2378c2962e24612d605489b51638
- upstream origin/trunk_dev
- file count 20
- ten tracked_modified and ten untracked regular files
- every file mode 0644
- textual diff SHA-256 897e95f470b55690abb2c25bd2b1d0b760ad9e6b0b3541f4ad4f5012cd0f022f
- canonical manifest size 4,377 bytes
- canonical manifest SHA-256 7ada36bd287de85823926090e07e8e33ca1fe038963984c8eed0f423329f1284

Live provenance gate

1. Verify exact recipe source bytes and SHA-256.
2. From the live repository root, run the exact recipe twice serially with no intervening command that may change repository bytes.
3. Require the two canonical outputs to be byte-identical.
4. Compare those bytes byte-for-byte with the attached V2 provenance manifest.
5. Independently compare branch, HEAD, upstream, exact path set, classification, file type, mode, size, per-file SHA-256, textual diff digest, canonical size, and canonical SHA-256.
6. Verify the index is clean and no path is staged or unmerged.
7. Verify tree, parent, subject, divergence, and worktree count separately because the v1 recipe does not encode them.
8. On any mismatch, return AUDIT_PROVENANCE_MISMATCH immediately and do not inspect implementation correctness.

V1-to-V2 repair-transition audit

Require the V1 and V2 manifests to have the same exact twenty paths, classifications, modes, branch, HEAD, and upstream.

Independently confirm that exactly eleven per-file manifest entries changed between V1 and V2:

- src/ge_nwp_coordinator/_post_execution_evidence_values.py
- src/ge_nwp_coordinator/_post_execution_policy_values.py
- src/ge_nwp_coordinator/_rw0_c_decision_input_values.py
- src/ge_nwp_coordinator/_section41_post_execution_proposal_family_projection.py
- src/ge_nwp_coordinator/_section41_post_execution_role_resolution.py
- tests/test_post_execution_pure_owner_values.py
- tests/test_post_execution_pure_owner_vectors.py
- tests/test_post_execution_pure_owner_relations.py
- tests/test_post_execution_pure_owner_boundaries.py
- tests/test_c2a_nonimplementation.py
- tests/test_runtime_non_authority.py

Require these nine manifest entries to remain byte-identical between V1 and V2:

- src/ge_nwp_coordinator/_finite_backlog_risk_source_adapter.py
- tests/test_rw0_b1_boundaries.py
- .docs/autonomous-software-development-operating-model.md
- .docs/c2b-durable-development-state.md
- .docs/rw0-b1-pure-phase-values.md
- .docs/rw0-remote-worker-contact-phase-entry.md
- .docs/architecture.md
- .docs/c2a1-pure-semantic-values.md
- .docs/rw0-c1-durable-evidence.md

The unchanged documentation does not receive semantic credit merely because code changed. Independently determine whether its existing implemented-private-pure status statements became truthful after V2, or whether documentation still overclaims.

Opening-evidence audit

- Verify the opening-evidence JSON exact bytes, canonical encoding, final newline, and hash.
- Reject duplicate keys.
- Verify it contains no absolute operator path, secret, environment value, credential, endpoint, raw log, prompt, database content, or private code bytes.
- Verify it binds the exact V1 manifest receipt, starting Git identity, staged/unmerged posture, and safe repository-relative ignored-cache inventory.
- Verify its normalized cache aggregate and each member's type/mode/path/size/SHA-256 are internally coherent.
- At live closeout, compare the current ignored-cache inventory to this opening evidence without printing file contents.
- Treat historical V1 opening evidence as unavailable; do not infer it from V2.

Exact candidate paths

New source:

- src/ge_nwp_coordinator/_post_execution_evidence_values.py
- src/ge_nwp_coordinator/_post_execution_policy_values.py
- src/ge_nwp_coordinator/_finite_backlog_risk_source_adapter.py
- src/ge_nwp_coordinator/_section41_post_execution_proposal_family_projection.py
- src/ge_nwp_coordinator/_section41_post_execution_role_resolution.py
- src/ge_nwp_coordinator/_rw0_c_decision_input_values.py

New tests:

- tests/test_post_execution_pure_owner_values.py
- tests/test_post_execution_pure_owner_vectors.py
- tests/test_post_execution_pure_owner_relations.py
- tests/test_post_execution_pure_owner_boundaries.py

Modified guard tests:

- tests/test_c2a_nonimplementation.py
- tests/test_runtime_non_authority.py
- tests/test_rw0_b1_boundaries.py

Modified governing/status docs:

- .docs/autonomous-software-development-operating-model.md
- .docs/c2b-durable-development-state.md
- .docs/rw0-b1-pure-phase-values.md
- .docs/rw0-remote-worker-contact-phase-entry.md
- .docs/architecture.md
- .docs/c2a1-pure-semantic-values.md
- .docs/rw0-c1-durable-evidence.md

No path outside this set may differ from HEAD or exist as an untracked candidate.

Independent validation without mutating the live repository

Do not run the test suite in the live repository and do not move, remove, or rewrite its pre-existing cache.

After the live provenance gate passes:

1. Create a private external audit root under /private/tmp or /tmp, mode 0700.
2. Use clone-time umask 022.
3. Construct a local --no-local single-branch clone from exact committed HEAD only. Do not fetch or contact any remote.
4. Overlay exactly the twenty V2 manifest files from the live worktree into the clone, preserving regular-file bytes and mode 0644.
5. Verify every copied file's type, mode, size, and SHA-256 against the attached V2 manifest.
6. Require no extra changed or untracked path in the clone.
7. Run the exact provenance recipe twice before tests and require canonical equality to the V2 attachment.
8. Run V02 through V06 serially, exactly as recorded in the V2 report, with PYTHONDONTWRITEBYTECODE=1 and pytest cache disabled.
9. Independently require these results or stricter passing supersets:
   - V02: 1,016 passed
   - V03: 472 passed
   - V04: 300 passed
   - V05: 529 passed
   - V06: 6,023 passed with only the three identified pre-existing Python 3.13 fork deprecation warnings
10. Run git diff --check, exact status/staged/unmerged checks, and a complete artifact scan after validation.
11. Require no cache, bytecode, database, journal, WAL, SHM, lock, build output, egg-info, archive, symlink, OS metadata, or unsupported file type outside .git in the validation clone.
12. Run the provenance recipe twice after tests and require all four clone manifests and both final live manifests to equal the V2 attachment byte-for-byte.
13. Remove the external audit root at closeout, preserving only safe facts in the audit report.

If local clone construction or full validation cannot be performed without network contact, dependency installation, live-repository mutation, or an unlisted effect, return BLOCK with the exact audit-environment limitation. Do not weaken the audit or trust the V2 report silently.

Required audit program

A. Boundary and protected-surface audit

- Require the exact twenty paths in all boundary arrays and the V2 manifest.
- Require six and only six new source modules, four and only four new tests, exactly three authorized guard-test modifications, and exactly seven documentation paths.
- Verify all 71 protected paths and both unchanged artifact paths remain equal to HEAD or absent exactly as frozen.
- Verify src/ge_nwp_coordinator/sqlite_state.py remains absent.
- Verify migrations remain exactly 0001 through 0004.
- Verify no migration 0005, catalog/application-generation change, public API, package-root export, StateStore or WriterSession method, SQLite owner/reader/writer/query/capability/transaction/controller/bootstrap change, production caller, CLI, service, scheduler, queue, daemon, or cross-repository effect.

B. Exact module and import audit

For every new module:

- require __all__ = ();
- require private-only posture and no package-root export;
- require no current production caller;
- require pure/no-I/O behavior;
- require no filesystem, process, subprocess, network, environment, clock-now, provider/model, worker-runtime, SQLite, or persistence behavior;
- verify exact allowed standard-library and semantic imports;
- verify all 16 allowed edges, all 15 forbidden-edge responsibilities, no reverse current-owner/runtime import, and acyclic graph;
- require generic policy not to import the adapter;
- require the adapter not to import backlog.py, assert development/backlog identifier equality, or claim progression authority.

C. Closure of RW0-AUD-003: exact grammar

Independently inspect all 44 allocations and nested values.

Require:

- exact built-in outer and nested types;
- declared mapping iteration order, not only key-set equality;
- exact list type, not tuple or subclass acceptance;
- bool rejection for integer fields;
- exact keys, nullability, profile-specific bounds, 96-byte safe-ref limits where frozen, lowercase digest widths, whole-second UTC timestamps, and Git format/OID compatibility;
- exact enum membership and canonical ordering;
- list cardinality, uniqueness, equality, and ordering rules;
- unknown/missing/type/profile/relation failures before generated-ref or self-digest comparison;
- compact sorted-key UTF-8 canonical JSON, ensure_ascii=false, allow_nan=false, no Unicode normalization;
- frozen slots dataclasses, repr=False, content-free exceptions, and closed copy/deepcopy/pickle/subclass behavior;
- V16 exactly five parent-bound fields;
- V9R001 and V11R001 precedence and restoration.

Reproduce these hostile probes independently, including re-signing when identity fields can be regenerated:

1. reordered outer mapping -> invalid_mapping
2. tuple for exact list -> invalid_field_type
3. 97-byte safe ref -> invalid_reference
4. non-enum V41 allowed branch -> invalid_field_value

D. Closure of RW0-AUD-001: authoritative action/evaluator semantics

Do not accept constructors that merely rehydrate caller-authored conclusions.

For all 27 action functions:

- identify authoritative typed inputs and frozen profile/equality rules;
- require the action to derive or reconstruct the output;
- treat caller-supplied expected output only as an assertion to reproduce;
- require mismatch to fail before acceptance;
- verify source identity, chronology, owner-family, currentness, precedence, and equality constraints.

Independently reproduce at least these re-signed invalid probes and require the named first failure:

5. V22 artifact completion before source completion -> relation_mismatch
6. V24 rank-5 role candidate_capsule -> worker_result -> source_owner_mismatch
7. V25 incomplete one-entry closure against complete transcript -> source_owner_mismatch
8. V32 clear/permit governed result against active-stop owner -> evaluation_contract_mismatch
9. V40 reused reviewer invocation claiming separation -> evaluation_contract_mismatch
10. V14 failed source observation claiming validation passed -> evaluation_contract_mismatch
11. V10 typed resupply substitution that remains structurally valid -> relation_mismatch at independent-owner equality

E. Current-owner, Section 41, and rank-15 grounding

- Reconstruct all nine migration-0003 physical evidence rows and self-digests through current owners.
- Reconstruct exact private-reader tuples and zero-or-nine ordering.
- Rebuild evidence set, proposal, twelve-locator owner-family graph, rank-15 wrapper, operand set, semantic relation, relation row, relation set, admission graph, and membership.
- Require admitted_by_mutation_ref in graph and membership preimages.
- Execute or directly invoke the current exact-family matcher in the external clone without a persistent database if the current pure test harness supports it.
- Verify V22/V23 and all nine V24 role resolutions use exact role/rank/ordinal/profile/locator/value/resupply equality and chronology.
- Verify no current owner, migration, reader, row, or durable C1 surface was modified.

F. RW0-C decision-input semantics

Independently inspect V25 through V34:

- V25 finite page transcript: page size 256, LIMIT 257 semantics represented in the pure transcript contract, strict cursor progress, one capability epoch, maximum 65,536, and 65,537 overflow probe;
- complete closure and selected rank-15 membership;
- clear and active V27 snapshots;
- five distinct resupplied currentness sources and exact V29 mapping;
- V31 authority basis and selected-authority lineage;
- V32 identity/profile/unknown/halt-only/active/clear precedence;
- V33 source-effect-ceiling basis and decision-time expiry;
- V34 recommendation consistency over the full authoritative input relation;
- model recommendation remains evidence, never durable decision or effect authority;
- no committed decision, result, receipt, recovery selector, latch, progression write, terminal, or runtime owner.

G. Closure of RW0-AUD-002: executable finite-test adequacy

Inspect all four new tests and all three modified guards.

Require concrete executable responsibility coverage for:

- 201 goldens: 155 proposed plus 46 current-owner records;
- 93 malformed controls;
- 126 assurances;
- 36 equality matrices;
- 31 import edges;
- 8 remaining seams;
- 44 allocations;
- 28 profile/evaluator pairs;
- all 27 action functions.

For every registry item, require a record-specific reconstruction, one-predicate mutation, equality, boundary, action, or seam assertion. Count-only, prefix-only, and inert ID inventories do not count.

Require:

- no runtime/test dependency on external V11, audits, freeze, reports, manifests, or overlay;
- test-local independent expected bytes/digests, not implementation-owned expected constants;
- all scalar fields checked, not only the first integer field;
- all allowed and forbidden import responsibilities checked, including reserved/runtime source=None cases;
- production-caller scanning over all six modules;
- complete rank-15 reconstruction rather than hard-coded dictionary comparison;
- active-stop tests that derive source-bound behavior rather than rehydrate their own expected vector;
- each malformed vector begins from a valid positive and reaches the claimed first failure;
- V9R001, V11R001, and the mandatory eleven probes are permanent and causal.

H. Closure of RW0-AUD-004: runtime-bytecode guard

Independently inspect tests/test_runtime_non_authority.py.

Require bytecode exemption only when all are true:

- exact authorized source cache location;
- direct child, no nested cache;
- regular file, no symlink or special type;
- exact interpreter cache naming convention;
- corresponding source exists in the closed production inventory;
- no orphaned .pyc or .pyo;
- no bytecode-only production path.

Execute negative controls for unexpected location, nested cache, unexpected filename, orphaned .pyo, orphaned .pyc, symlink/non-regular bytecode, and bytecode-only production path. Verify module-scope __name__ handling is not a broad bypass.

I. Documentation and report accuracy

- Independently determine whether the unchanged seven documentation payloads are now truthful because the implementation caught up with them.
- Preserve all negative claims: no production caller, runtime/I/O, durable decision, migration/SQLite widening, public export, external authority/custody, C2B progression, terminal, RW0-D/E, or Execution Substrate behavior.
- Verify .docs/c2b-durable-development-state.md protected prefix/Section 1-41 posture, remote-contact H2 ordering, RW0-B1 registry/sole-consumer contract, C1 fifteen-kind ownership, and bounded architecture/C2A cross-references.
- Reconcile every material V2 report claim with source, tests, manifest, and independently rerun validation.
- Verify V00 is truly an opening repair gate, not final-candidate chronology mislabeled as pre-implementation.
- Verify V1 remains historical and unmodified.
- Verify the report truthfully records the ten repair-created bytecode artifacts, their bounded removal, and the inability to reconstruct their common creation process.
- Verify no required validation was skipped and all non-authorizations are true.

J. Security, privacy, and artifact audit

- Scan candidate bytes for secrets, credentials, environment values, private endpoints, raw logs, prompts, SQLite contents, TLS/SPIFFE/Vault/WebAuthn/API-key material, or sensitive absolute paths.
- Verify candidate-capsule entries, paths, operations, modes, bodies, byte lengths, and custody do not enter durable/public values.
- Verify all twenty candidate paths are regular mode-0644 files.
- Verify no executable, symlink, database, journal, WAL, SHM, lock, cache, build output, egg-info, archive, or OS metadata is part of the candidate.
- Verify the external audit clone retains no artifact and the live ignored-cache inventory remains byte-identical to the opening evidence.

K. Provenance and closeout

- Require exact V2 manifest reproduction in the live repository at audit start.
- Require exact V2 manifest reproduction in the external clone before and after tests.
- Remove only audit-created external artifacts.
- Rerun the exact recipe twice in the live repository at closeout.
- Require final live canonical bytes to remain byte-identical to the attached V2 manifest.
- Require no staged path and no new tracked/untracked candidate path.
- Return AUDIT_PROVENANCE_MISMATCH if the live candidate changes at any point.

Protected strategic boundaries

The candidate must not implement or claim:

- migration 0005;
- SQLite or durable-state widening;
- public/package-root exports;
- StateStore or WriterSession widening;
- production caller or automatic progression;
- filesystem/process/network/environment/clock behavior;
- provider/model/worker invocation;
- Bridge handoff;
- external policy/risk/validation/review custody or authenticity;
- V40 identity authentication beyond operational separation;
- committed RW0-C decision/result/receipt/recovery;
- C2B progression write, neutral authorization basis, latch, or terminal;
- RW0-C terminal, RW0-D/E, cancellation, publication, Git effect, or Execution Substrate work;
- V35, V36, V37, or V45.

Severity and classification

For every finding, provide:

- ID
- type
- severity: critical, high, medium, low, observation
- classification: contract/authority drift, security/privacy risk, correctness bug, test defect, documentation defect, artifact/provenance defect, process-only governance, audit-environment issue, or pre-existing issue
- current contract or accepted target
- exact repo-relative path and line
- evidence
- impact
- required correction
- uncertainty
- patch defect versus pre-existing issue

Do not convert a process/report issue into a code defect. Do not excuse a code/test/authority defect as wording. Do not treat provenance equality or a passing suite as proof of semantic correctness.

Verdicts

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Use:

- AUDIT_PROVENANCE_MISMATCH when live repository identity, recipe bytes, path set, file bytes, per-file metadata, diff digest, or canonical manifest differs from the V2 target. Stop before correctness judgment.
- BLOCK for correctable implementation, test, documentation, validation, security, artifact, process-evidence, or audit-completeness defects inside the accepted boundary.
- REJECT only for a foundational authority or decomposition failure requiring the accepted six-module/twenty-path boundary to be reopened.
- ACCEPT only when provenance, all six prior finding closures, source semantics, executable finite tests, documentation, validation, security/privacy, artifact hygiene, and strategic boundaries pass with no unresolved critical, high, or medium patch defect.

Required audit report

Return one complete report containing:

1. Primary verdict.
2. Exact fourteen-attachment receipts.
3. V1-to-V2 transition reconciliation.
4. Opening-evidence audit.
5. Initial live V2 provenance reproduction.
6. External validation-clone construction and provenance reproduction.
7. Independent V02-V06 commands and results.
8. Exact twenty-path and protected-path assessment.
9. Six-module/import audit.
10. Value/profile/canonicalization audit.
11. Current-owner/Section 41/rank-15 audit.
12. RW0-C decision-input audit.
13. Executable finite-test and malformed/assurance adequacy audit.
14. Runtime-bytecode guard audit.
15. Documentation audit.
16. Security/privacy/artifact audit.
17. V2 implementation-report accuracy assessment.
18. Severity-ranked findings.
19. Inspection limits and separate confidence for provenance, validation, and implementation.
20. Exact next boundary.
21. Final live provenance reproduction.
22. Explicit non-actions.

On ACCEPT, end with exactly:

RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_ACCEPTED_READY_FOR_COMMIT_GATE

On BLOCK or REJECT, do not emit that token. State the exact bounded repair or architecture-reset boundary.

Required non-actions

REPOSITORY_MUTATION_NOT_PERFORMED
LIVE_REPOSITORY_TEST_ARTIFACT_NOT_CREATED
REPAIR_NOT_PERFORMED
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
