# Disposition

**Do not send V9 to independent audit. Return it for one narrow package-envelope repair.**

The V16 parent-bound-entry correction appears coherent, but V9 fails a deterministic package invariant: its manifest and closeout claim the same content aggregate, yet that aggregate does not reproduce from the package’s own ordered content records.

This is a **blocking package-integrity defect**, not a semantic or architectural rejection.

## Exact failure

Codex reported that aggregate, manifest, and closeout verification passed, and identified the V9 aggregate as:

```text
9dcb2128867325391ba7cff81bd29dbb1e2ecbd4be79dbded620bce515db7eac
```

:chatgpt-content-reference{index="0"}

That value is embedded consistently in both envelope records:

- `package.manifest.v1` claims `9dcb2128…db7eac`. :chatgpt-content-reference{index="1"}
- `package.closeout.v1` claims the same value. :chatgpt-content-reference{index="2"}

However, using the package’s established aggregate construction:

```text
SHA-256(
  record_id + TAB + payload_raw_sha256
  for every content record in record-index order,
  joined by LF with no trailing LF
)
```

I independently obtained:

| Property | Result |
|---|---|
| Ordered content records | `1,679` |
| Aggregate preimage size | `180,486` bytes |
| Claimed aggregate | `9dcb2128867325391ba7cff81bd29dbb1e2ecbd4be79dbded620bce515db7eac` |
| Correct aggregate | `9302da29abad2bbdd78dcae33b1d499236d046cb195184caf8248b60e0b63895` |
| Match | **No** |

I reproduced the same algorithm against V8, where it exactly yields V8’s recorded aggregate. The V9 failure is therefore not an ambiguity about the reduction algorithm.

The whole-file SHA-256 remains valid:

```text
38c4df3af439a0bae68879ce19a09f8c53db35ea53fb43f1d508c9854b488366
```

That hash merely identifies the erroneous V9 bytes; it does not make the embedded aggregate claim correct.

## What otherwise reconciles

I found no reason to reopen the V16 owner-contract decision:

- V16 now has exactly the five frozen fields: `branch`, `applicability`, `governed_effect_class`, `result`, and `reason`.
- `schema_id`, `source_ref`, `source_digest`, standalone references, and standalone self-digests are excluded.
- No sourced-entry schema, V45, new module, allocation, or import edge was introduced.
- Dispatch covers exactly V17, V18, V31, V32, and V33.
- Parent-level source binding is explicitly described for all five consumers. :chatgpt-content-reference{index="3"}
- The four corrected V31–V33 matrix anchors reproduce.
- The active-stop outcomes remain three governed denials followed by two halt-only permits.
- The existing attempt-fence and global-stop malformed controls remain causal.
- A062 and V9R001 provide the intended positive-dispatch and one-extra-field rejection assurance.
- The reported recursive inventory of 94 V16 instances—91 valid five-field mappings plus three deliberate one-extra-field negatives—reconciles. :chatgpt-content-reference{index="4"}

The V8→V9 transition also reconciles:

```text
21 new records
0 retired records
14 changed substantive records
2 changed package-envelope records
1,644 unchanged shared payloads
```

The 21 additions comprise:

```text
3 new substantive records
4 semantic supersessions
14 record-payload supersessions
```

All 14 record-payload supersessions bind the exact V8 and V9 substantive payload hashes. I found no need for another semantic regeneration.

## Narrow repair boundary

V10 should preserve **all 1,679 content records as complete byte-identical outer JSONL lines**. Only these two records may change:

```text
package.manifest.v1
package.closeout.v1
```

Required V10 treatment:

```text
correct aggregate:
9302da29abad2bbdd78dcae33b1d499236d046cb195184caf8248b60e0b63895

logical records:
1681

new record IDs:
none

retired record IDs:
none

changed substantive records:
none

new supersession entries:
none
```

The content-line block itself has this frozen identity when joined by LF without a trailing LF:

```text
size:
2,417,707 bytes

SHA-256:
cface622f16e145e0a239add7aebe0325916aec0d91a61b19f72bf5613b8683d
```

Because the substantive package truth is unchanged, V10 should not introduce semantic or record-payload supersessions. Manifest and closeout have consistently been treated as regenerated envelope records rather than supersession-ledger subjects.

# V10 repair handoff

Use a **package-repair Codex conversation**, not an independent-audit conversation. The V9 generation conversation is suitable. Attach exactly the prompt and V9 fixed input below; the repair report itself is not needed.

### Repair prompt

:chatgpt-content-reference{index="6"}[Download the V10 content-aggregate repair prompt](sandbox:/mnt/data/Coordinator_RW0_Canonical_Package_V10_Content_Aggregate_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_Canonical_Package_V10_Content_Aggregate_Repair_Prompt.txt

Size:
13,992 bytes

SHA-256:
205217ec08ee217cb10754bbaf1f5a6b099b623b1a4e98a858c58205b251fa04

Logical lines:
516

Final newline:
absent
```

### Sole fixed input

:chatgpt-content-reference{index="7"}[Download the exact V9 package](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Audit_Package_V9.jsonl)

```text
Filename:
RW0_Post_Execution_Canonical_Audit_Package_V9.jsonl

Size:
2,613,829 bytes

SHA-256:
38c4df3af439a0bae68879ce19a09f8c53db35ea53fb43f1d508c9854b488366

Logical records:
1,681

Final newline:
absent
```

The expected deliverable is:

```text
RW0_Post_Execution_Canonical_Audit_Package_V10.jsonl
```

The required success token is:

```text
RW0_POST_EXECUTION_CANONICAL_PACKAGE_V10_CONTENT_AGGREGATE_REPAIRED_READY_FOR_INDEPENDENT_AUDIT
```

After V10 returns, its content-byte preservation and aggregate should be checked before preparing the fresh independent audit. A successful repair still does not authorize implementation-boundary freeze, repository implementation, migration `0005`, durable mutation, C2B progression writing, terminal work, RW0-D/E, or Execution Substrate work. Codex likewise reports that none of those effects occurred during V9 generation. :chatgpt-content-reference{index="5"}

**Inspection limit:** I verified V9 package mechanics, the aggregate defect, the V8→V9 transition, the V16 field/dispatch repair, generated matrix anchors, and assurance structure. I did not run repository tests, migrations, live databases, or the eventual full semantic acceptance audit.

**Sources:** Codex V9 repair report; exact V8 and V9 package bytes; uploaded Coordinator snapshot at `a3ff0b7f4f0c2378c2962e24612d605489b51638`.

**Confidence:** 0.999 that V9’s content aggregate is incorrect; 0.99 that the V16 repair is internally coherent; 0.995 that the two-envelope-record V10 repair is the narrowest sufficient next step.
