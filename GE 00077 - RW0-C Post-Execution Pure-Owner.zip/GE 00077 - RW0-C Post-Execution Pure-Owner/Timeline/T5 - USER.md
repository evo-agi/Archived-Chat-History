Here is Codex's response:

[Download the attached \`RW0_Post_Execution_Canonical_Audit_Package_V7.jsonl\`](/tmp/rw0-v7-repair.MUve7d/RW0_Post_Execution_Canonical_Audit_Package_V7.jsonl)

### Verification report

V6 attachment receipt:

- Observed filename: `RW0_Post_Execution_Canonical_Audit_Package_V6.jsonl`
- Client-exposed runtime path: `/Users/ds/Downloads/RW0_Post_Execution_Canonical_Audit_Package_V6.jsonl`
- Size: 2,466,932 bytes
- SHA-256: `ebae5f77865f22adec3a5fdc45ed94d928c89d783eb11185a85405643cdef881`
- Logical records: 1,547
- Final newline: absent
- No second or predetermined Downloads copy was requested or assumed.

Repository baseline passed exactly: `trunk_dev`, HEAD `a3ff0b7f4f0c2378c2962e24612d605489b51638`, tree `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0`, sole parent `047563de5a443b0f8323401c92979ae2e444d2ed`, subject `feat: implement RW0-C1 durable evidence (#7)`, upstream `origin/trunk_dev`, ahead/behind `0/0`, one worktree, clean status.

Both audit findings are closed:

- `V6-AUDIT-001`: repaired the decision-time V32 precedence to:
  1. identity mismatch → conflict
  2. profile mismatch → conflict
  3. global-stop unknown → unknown
  4. halt-only → permit / `halt_only_stop_checked`
  5. active stop → deny / `global_stop_active`
  6. otherwise → permit / `global_stop_clear`
- New profile digest: `6139df3c64d3736e6938605bc6abef22c258e4841ffe8b641d7a70490f6a5e47`
- `V6-AUDIT-002`: repaired A055, added A059 and V7G001, and replaced the noncausal malformed vector with one exact governed-result mutation.

Active owner control:
```
{"active":true,"issued_at":"2026-09-30T12:00:01Z","issuer_ref":"issuer-golden.0001","operator_decision_ref":"operator-decision-golden.0001","reason_class":"safety_stop","schema_id":"governed-execution.nwp-global-stop.v1","stop_id":"global-stop-active-golden.0001","version":8}
```

- Derived stop ref: `global-stop-active-golden.0001`
- Raw digest: `52e9910ccd71209c823489e36599dca8afd8a6c7d29f7c61d01e3748662b4b02`
- Accepted by the current `GlobalStopState` constructor.
- Synthetic assurance evidence only; it did not replace the current clear fixture.

Active V27:

- Snapshot ref: `rw0-c-current-snapshot.5318fe94a5654f9626e3bbd9fda42b8736b914d690b1e270b0f54fce012988af`
- Snapshot digest: `bb95ff499c4ef25616c28fa37a746678a951fb2b430315bff2143f589499ba7b`

V32 controls:

- Clear matrix: `rw0-c-global-stop-matrix.765a8f001b742856925c6ba9ed90bd2dafd12dd3399cdc10d704404949b843b9`
- Clear digest: `e8b2af5a16ae67d027404d1fa96cc48cc78cf115b2ddecfde8891d4c3abeca67`
- Clear outcomes: `permit, permit, permit, permit, permit`
- Active matrix: `rw0-c-global-stop-matrix.94abe7bedbd63b72e620b7accaf11162f6c46076f7ff6b80e7477157fb586150`
- Active digest: `1a2e960d02fbe5500a65d14165296adb43ce41a25f229a4374c32538f9b0f7c7`
- Active outcomes: `deny, deny, deny, permit, permit`

The malformed vector changes only `candidate_acceptance.result` from `deny` to `permit`. Its independently reproduced matrix ref is `rw0-c-global-stop-matrix.8c19cb82d06a64c8802ea0fe2bf63b1b831cd56bfd0fe4210778fbd2fba7c368`, digest is `9bf7ea9be55cd2931da8a8f9dc09cfb956f895f0b6ff1a78acafd89e92d0945f`, and raw canonical SHA-256 is `285813c9a2010dc01ceddb7c714f91fea27e1021099b4cfa0830f01b27656507`. Restoring the required deny result and regenerating identity exactly reconstructs the active golden; rejection is `stop_branch_matrix_conflict`.

### V7 identity

- Filename: `RW0_Post_Execution_Canonical_Audit_Package_V7.jsonl`
- Size: 2,484,322 bytes
- SHA-256: `6d3e7fd550598306c484180ab1e81e01d67649597ee5b4e8f8ac3446c7840009`
- Logical records: 1,559
- Final newline: absent
- Content aggregate: `74095ab24c91b8f8808fc4d0ffcf723a4d14ae5ffc8610076d2fed3a9de8d084`
```
package_manifest: 1
source_owner_binding: 23
value_schema: 44
behavior_profile: 28
golden_value: 199
malformed_vector: 90
module_allocation: 44
import_edge: 31
equality_matrix: 36
assurance_case: 119
supersession_entry: 935
remaining_seam: 8
package_closeout: 1
```

Changed existing records:

- `behavior-profile.rw0-c-decision-time-global-stop-branch.v1`
- `value-schema.V32.rw0cdecisiontimeglobalstopbranchmatrixv1`
- `golden.V32.primary`
- `malformed.global-stop-branch-mismatch`
- `assurance.A055`

New substantive records:

- `golden.owner.global-stop.active`
- `golden.V27.active-stop-control`
- `golden.V32.active-stop`
- `assurance.A059`
- `assurance.V7G001.global-stop-active-applicability-split`

Retired record IDs: none.

New semantic supersessions:

- Profile: `048759ce73b3f1aba6c5e8e8fd5c16201e6d131887f8a192f981c699379637c5` → `6139df3c64d3736e6938605bc6abef22c258e4841ffe8b641d7a70490f6a5e47`
- Clear V32: `rw0-c-global-stop-matrix.4790e9464729d911afb2c2e5f7831dc5abd96fc60cdd57ba823644e78dcbaf65` / `9e3f6d1c4d0d76415a43479a0bc2faeb0ce8c2721554c4c08e96727b9728c433` → `rw0-c-global-stop-matrix.765a8f001b742856925c6ba9ed90bd2dafd12dd3399cdc10d704404949b843b9` / `e8b2af5a16ae67d027404d1fa96cc48cc78cf115b2ddecfde8891d4c3abeca67`

Five record-payload supersessions were added for the exact changed set. The supersession scan covered 834 ledger entries and 742 unique old identities, with seven permitted malformed-only occurrences and zero forbidden occurrences.

All retained, non-changed V6 payloads remained byte-exact. Canonical encoding, duplicate-key rejection, dense indexes, ordering, manifest arrays, aggregate, closeout, generated identities, all 199 golden categories, and whole-file identity passed. Python, OpenSSL, and `shasum` reproduced the same file hash.

Preserved source-owner, module-allocation, import-edge, equality, currentness, temporal, privacy, and authority contracts remain intact. Rank-15 reproduced owner-family graph `cabeddccdfd5dbd45fa6f7192e73e17c3f5b84c536c9cad00708cc45d09868bd`, value digest `ddb30a465fb79f12dc632ae1298e749c4500fd6dda5c52cbaab2b26f79441dbf`, and runtime exact-family matcher result `true`. Exactly fifteen C1 evidence kinds remain; V35–V37 remain absent.

The V7 file is exposed through the client-visible attachment link above. No plain private path is offered as a substitute deliverable.
```
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
```

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V7_GLOBAL_STOP_REPAIRED_READY_FOR_INDEPENDENT_AUDIT
