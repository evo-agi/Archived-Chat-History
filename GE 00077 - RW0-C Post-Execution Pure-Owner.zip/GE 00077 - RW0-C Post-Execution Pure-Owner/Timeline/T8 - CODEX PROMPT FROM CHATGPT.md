PROMPT_ID

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V8_MIGRATION0003_POST_EXECUTION_FAMILY_SOURCE_GROUNDING_AND_ASSURANCE_REPAIR_V1

TITLE

Coordinator RW0 — rebuild the migration-0003 post-execution evidence family
from the exact current row owners, correct evidence-set semantic-owner
attribution, close the missing current-reader positive assurance, preserve the
accepted V7 global-stop repair, and deliver canonical package V8 for a fresh
independent audit

ENGAGEMENT TYPE

Parent-only, local, repository-read-only canonical-package repair.

Use a package-generation/repair conversation, not the independent-audit
conversation that reported the V7 findings. Preserve auditor/repairer
separation.

Do not delegate to subagents or internal audit agents.

Do not edit repository files, format repository files, stage, commit, push,
create a branch or PR, merge, tag, release, deploy, fetch, contact a remote or
live system, install dependencies, execute repository tests, run migrations,
open or mutate an operator database, invoke a product worker/model, or inspect
or modify supporting repositories.

You MAY create files only in one fresh private external temporary root for
bounded source inspection and package reconstruction. Use mode 0700 for that
root. Set PYTHONDONTWRITEBYTECODE=1 for bounded pure-source constructor use.
Remove disposable intermediates before closeout.

You MAY invoke current pure/private constructors and matcher functions against
in-memory values from the fixed package. Do not create a persistent product
database or run the repository test suite.

Return the revised package through the client-visible attachment mechanism.
A private filesystem path is not a deliverable.

Do not issue an implementation prompt.

ATTACHMENT RECEIPT CONTRACT

The sole fixed contract input is the client-uploaded attachment named:

RW0_Post_Execution_Canonical_Audit_Package_V7.jsonl

Do not require, request, or assume a second copy in `/Users/ds/Downloads/` or
any other predetermined path. A runtime materialization path may be used as an
implementation detail, but path presence is not part of the fixed-input
contract.

Before substantive work, visibly report an attachment receipt containing:

- observed filename;
- accessible runtime path, if the client exposes one;
- byte size;
- SHA-256;
- logical record count;
- final-newline posture.

If the client attachment is not accessible, stop immediately and return:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V8_FIXED_INPUT_ATTACHMENT_UNAVAILABLE

Do not search for or silently substitute a same-named local file. Do not treat
attachment transport failure as a semantic or source-owner finding.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V8_BASELINE_MISMATCH

FIXED INPUT IDENTITY

Require the attached V7 package to have exactly:

filename:
RW0_Post_Execution_Canonical_Audit_Package_V7.jsonl

size:
2484322 bytes

SHA-256:
6d3e7fd550598306c484180ab1e81e01d67649597ee5b4e8f8ac3446c7840009

logical records:
1559

final newline:
absent

content aggregate:
74095ab24c91b8f8808fc4d0ffcf723a4d14ae5ffc8610076d2fed3a9de8d084

first record:
package.manifest.v1

last content record:
remaining-seam.S008

final record:
package.closeout.v1

record-type counts:

package_manifest: 1
source_owner_binding: 23
value_schema: 44
behavior_profile: 28
golden_value: 199
malformed_vector: 90
module_allocation: 44
import_edge: 31
equality_matrix: 36
assurance_case: 119
supersession_entry: 935
remaining_seam: 8
package_closeout: 1

If any fixed-input property differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V8_FIXED_INPUT_MISMATCH

DISPOSITION OF THE V7 INDEPENDENT AUDIT

Treat the result as BLOCK, not REJECT.

The V7 package mechanics are valid. The V7 decision-time global-stop repair is
correct and its causal active-stop assurance is accepted. No foundational
authority or module-decomposition failure was found.

The block is confined to three correctable package/source-grounding defects:

1. High — six of the nine migration-0003 post-execution evidence rows carry
   stale self-digests and are rejected by the current row constructor and
   private reader before the rank-15 exact-family matcher can run.
2. Medium — `source-owner.migration0003-evidence-set` incorrectly names the
   pre-execution `ModelProposalEvidenceSetV1` module as the semantic owner of
   the post-execution evidence-set reconstruction.
3. Medium — the finite assurance claims current-owner acceptance without first
   proving all nine current row constructors and the complete current-reader
   family positive control.

This repair does not authorize or require a repository owner change,
architecture reset, migration, implementation, public API, durable writer,
production caller, latch, terminal, RW0-D/E, provider, worker, transport,
Bridge, Control Plane, Infrastructure Manager, or Execution Substrate work.

PRIOR-AUDIT CONTRADICTION TO RESOLVE

Do not rely on the earlier V6 audit statement that the rank-15 exact-family
matcher accepted the family. That earlier check did not establish that the
nine physical evidence rows were first accepted by the exact current row
constructor and private reader.

The V8 verification order is mandatory:

1. reconstruct each physical evidence row under the current row owner;
2. reconstruct each row through the private reader tuple boundary;
3. prove the exact zero-or-nine family, order, locators, and evidence-set
   digest;
4. only then run the owner-family graph, rank-15 wrapper, relation, membership,
   closure, snapshot, currentness, and decision-input checks.

Do not bypass a failed current row boundary by fabricating already-accepted
snapshots.

SEAM CLASSIFICATION

Current contract / invariant:

- `src/ge_nwp_coordinator/_cognitive_proposal_row_values.py` owns the exact
  physical migration-0003 row shape and self-digest. `computed_digest()` uses
  `<schema_id>.identity`, excludes the table digest field, and the current
  constructor rejects any mismatch as `physical_family_row_digest_mismatch`.
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py` reconstructs each
  post-execution evidence row at the private tuple boundary, independently
  verifies `evidence_binding_digest`, and admits only an exact 0-or-9 bounded
  family.
- `src/ge_nwp_coordinator/_sqlite_rw0_c1.py` reconstructs the post-execution
  evidence-set identity inside `_section41_owner_family_matches`, compares its
  digest to the rank-15 wrapper, and only then accepts the exact current family.
- `.docs/rw0-c1-durable-evidence.md` requires all nine row self-digests, exact
  role/rank/order/required flags, exclusion of extra rows, and reconstruction
  of the evidence-set digest.

Package defect, not repository authority change:

- The package copied six stale self-digests.
- The package attributed the post-execution evidence set to a nearby
  pre-execution semantic class because both use the same digest domain.
- Digest-domain provenance is not semantic ownership.

Proposed package assurance:

- V8 must make current row-constructor acceptance and current private-reader
  acceptance explicit finite positive controls.
- V8 must retain the prior symbolic-versus-concrete malformed-vector hygiene.

Implementation detail / evidence:

- JSONL records, goldens, malformed vectors, assurance records, supersession
  entries, manifest, closeout, and reports are evidence/projection. They do not
  become Coordinator durable truth or implementation authority.

PRESERVED CONTRACTS

Preserve every V7 contract not transitively changed by the exact source repair,
including:

- exact canonical JSONL mechanics and the closed record-type envelope;
- the repaired V7 decision-time global-stop precedence;
- the valid active owner, active V27 snapshot, clear/active V32 controls, and
  causal one-result malformed vector;
- package-wide zero-forbidden-occurrence supersession posture;
- all value-schema and behavior-profile semantics not dependent on the repaired
  migration-0003 family;
- profile-bounded list cardinalities and support inventories;
- distinct validation, review, policy, risk_profile, and risk_binding
  currentness components;
- the two-context temporal model and monotonic construction chronology;
- exact nine-role model-input, Section 41, and resupply structure;
- transient/private candidate-capsule handling and safe-projection privacy;
- V40 operational reviewer separation without human/provider/account/principal
  identity claims;
- owner-authored standing-policy and risk attestations;
- generic risk semantics separated from the versioned FiniteBacklog adapter;
- exactly fifteen current C1 evidence kinds and no C1 completeness authority;
- explicit deferral and current absence of V35-V37 committed-recovery values;
- current executable authorization remaining unsupported and fail-closed;
- the migration-free private pure-owner implementation decomposition as a
  proposed boundary only;
- no implementation authorization.

Do not preserve a stale hash merely to minimize the delta. Do not alter
unrelated semantics merely because a downstream identity changes.

FINDING RW0-V7-001 — SIX PHYSICAL EVIDENCE-ROW SELF-DIGESTS ARE STALE

The current owner digest rule is:

SHA-256(
  UTF8(schema_id + ".identity")
  || 0x00
  || canonical_json(row mapping excluding evidence_binding_digest)
)

Reconstruct all nine exact package rows from the current row owner. Do not
trust any supplied row digest until reproduced.

The following three V7 rows are already exact and must remain semantically and
byte-identical unless outer indexing changes:

candidate_capsule:
e1d8c9fb13ec6719b04cd1687620565ee00e55ea1f3e3965b998aad5011b820a

worker_result:
0d4bcad233a3265992c6ff85b6655fca7cfef6e3ea871f27294768601b3f612c

authority_currentness_attestation:
695445d763c4156b3c8fc5b4a619a3962983440c9809ad1b4e67f41b410964d0

The following six V7 row self-digests are stale and must be replaced exactly:

validation_result

V7 stale:
ba78bf89b4e73c16482ac94f16b01b1b8374a2d0ae7af3426260bdfb4d6edfca

required current:
4fc6b571441d96297be155d5049fadf3b161b033527af5431803a208c48d2fbf

independent_review

V7 stale:
915f0c00f9117f2fbb3137249bcd8753c92653ef913dacbb16200224b335ca3e

required current:
befffaa9e5041cb6d9e01e19ea54c8d4f7d8a579783cda1e1caf05705738c01f

standing_policy

V7 stale:
a4c4131e23dd395fa792bb0afa6816741637c43826663f102b21f4a1f057a95c

required current:
72963e1fd447191fd5740b41dc4e8e6d44747ec11efcd702223c60e8fac2c948

risk_lane

V7 stale:
d6623dda0698a01d4b3406b40aacc543db92630a98dac110a2fe59a1d8f9748a

required current:
fa37991e2e86050a64aa07fd42c521b6ec6c842aaee56822adb2e013f793dc59

global_stop

V7 stale:
d826cbec8e4e347c5cc90f96dce7377e98970b63eef6d628471fca15824b5005

required current:
8243f099ada6220771d006db22cd48cf6deae9d950351e5f892956db28798d79

effect_ceiling

V7 stale:
22e4c05af2b956e1cc3737a7c19ede27c825036fea612506fd216964c34b0bce

required current:
dad94ec67abc7c0b94ef73aa1b86b95b3dd65cf4282cf8955a9536ebe0a97536

Mandatory direct record corrections include:

- golden.owner.proposal-evidence-row.07.validation_result
- golden.owner.proposal-evidence-row.08.independent_review
- golden.owner.proposal-evidence-row.09.standing_policy
- golden.owner.proposal-evidence-row.10.risk_lane
- golden.owner.proposal-evidence-row.12.global_stop
- golden.owner.proposal-evidence-row.13.effect_ceiling

For every one of the nine row mappings require:

- exact built-in mapping and field order;
- current schema literal;
- exact proposal/evidence-set/role/rank/ordinal/required coordinates;
- current constructor acceptance;
- exact `computed_digest()` equality;
- current private-reader tuple-boundary acceptance;
- no normalization or inferred field substitution.

DIRECT SOURCE-DERIVED CASCADE ANCHORS

After substituting the six corrected row digests, independently reconstruct the
following exact anchors:

Evidence-set digest

V7 stale:
3b7b66c48d6b48122a1e09cbf66e1071d8948ff77a7993efadb1714aa6b01633

required current:
213b55b3a75121cadeab28e05ce7dda0525ac447464d8bbfcd82515b8e15b54d

Proposal digest

V7 stale:
ba1d2626d1a7bdc6daa4ec9a956a29145da9ba907dab10c968e0445b4e0235a0

required current:
acda782cef72c31e0f9e3923659de53f969b6f26c746ae03150ac9762d6d079f

Owner-family graph digest

V7 stale:
cabeddccdfd5dbd45fa6f7192e73e17c3f5b84c536c9cad00708cc45d09868bd

required current:
08ace396f61397e1c262258396e9015472bbbb91fbfc842107e137125c6d391e

Rank-15 wrapper value digest

V7 stale:
ddb30a465fb79f12dc632ae1298e749c4500fd6dda5c52cbaab2b26f79441dbf

required current:
70dab00e12c79a58cf3a119a00dc1ad7c24efc008540fc5b4d46f88cd46e453c

These four anchors are necessary, not sufficient. Do not stop at them.

TRANSITIVE REGENERATION OBLIGATION

Regenerate the complete dependency closure from semantic inputs. At minimum
this includes every affected current record in these families:

- migration-0003 evidence-set, proposal, and owner-family source bindings;
- rank-15 value and relation source bindings;
- owner goldens for evidence set, proposal, graph, rank-15 value, and rank-15
  relation;
- model input binding V09;
- Section 41 projection V22;
- the affected V23 projection-evidence entries;
- all nine V24 role-resolution records, because proposal/evidence-set/rank-15
  membership coordinates are shared even where a row digest itself was already
  correct;
- membership closure V25 and the rank-15 V26 closure entry;
- clear and active V27 snapshots;
- V29 currentness and every decision-time value transitively bound to the
  changed snapshot/currentness/proposal identities, including the repaired V32
  clear/active controls and their causal malformed vector when their basis
  identities move;
- V31, V33, V34, and any other current downstream value whose exact source,
  snapshot, membership, relation, proposal, or currentness identity changes;
- affected malformed vectors and assurance records;
- source-owner canonical controls and identity summaries;
- semantic-identity supersessions;
- record-payload supersessions;
- manifest and closeout.

Derive this set mechanically. Do not freeze an incomplete hand-written record
count or record list.

Historical supersession entries are history. Do not rewrite them merely because
they contain an identity that is now superseded again.

FINDING RW0-V7-002 — EVIDENCE-SET SEMANTIC OWNER IS MISATTRIBUTED

The V7 record:

source-owner.migration0003-evidence-set

incorrectly names:

ge_nwp_coordinator._cognitive_proposal_semantic_values

That module's `ModelProposalEvidenceSetV1` is pre-execution-only: it requires
`proposal_phase == "pre_execution_plan"` and 14-or-15 pre-execution bindings.

The current post-execution evidence-set digest is reconstructed inside:

ge_nwp_coordinator._sqlite_rw0_c1._section41_owner_family_matches

using the exact nine current reader snapshots and the domain:

governed-execution.nwp-model-proposal-evidence-set.v1.identity

The row shape and self-digests remain separately owned by:

ge_nwp_coordinator._cognitive_proposal_row_values

The bounded 0-or-9 family read remains separately owned by:

ge_nwp_coordinator._sqlite_rw0_c1_readers

Correct `source-owner.migration0003-evidence-set` so that it truthfully
distinguishes:

- digest-domain provenance;
- physical row ownership;
- bounded family-reader ownership;
- post-execution semantic evidence-set reconstruction ownership.

Required semantic posture:

- `owner_module` must identify
  `ge_nwp_coordinator._sqlite_rw0_c1`;
- `owner_tables` remains
  `development_model_proposal_evidence_bindings`;
- the digest domain remains
  `governed-execution.nwp-model-proposal-evidence-set.v1.identity`;
- `current_posture` and `relation_and_profile.relation` must explicitly state
  that the post-execution evidence-set identity is reconstructed in the C1
  exact-family matcher from current private-reader rows;
- the record must not claim that `ModelProposalEvidenceSetV1` owns the
  post-execution set;
- the record must not imply that the digest domain itself grants semantic
  ownership.

If the existing source-owner record schema cannot express this split
truthfully, stop with:

owner-attribution-schema-insufficiency

Do not invent a repository owner or widen source.

Update both:

- assurance.V3G006.evidence-set-owner-module-substitution
- malformed.V3G006.evidence-set-owner-module-substitution

The corrected assurance literal must use:

ge_nwp_coordinator._sqlite_rw0_c1

The malformed vector should use the V7 wrong owner module as the exact rejected
substitution:

ge_nwp_coordinator._cognitive_proposal_semantic_values

Recompute its `base_payload_sha256` against the corrected source-owner record.
Keep the mutation causal and limited to `/owner_module`.

FINDING RW0-V7-003 — CURRENT-OWNER POSITIVE ASSURANCE IS MISSING

Repair finite assurance in three layers.

A. Update the existing equality assurance.

Update:

assurance.A047

so its acceptance claim is explicitly conditional on:

- all nine exact post-execution evidence rows being accepted by the current row
  constructor;
- all nine tuples being accepted by the current private row reader;
- the complete 12-locator family being accepted by the current exact-family
  matcher;
- only then proving T1/model/Section 41/resupply equality.

Do not leave A047 as a package-internal equality claim detached from current
source acceptance.

B. Add two ordinary finite positive assurances.

Add:

assurance.A060

Required case:

all nine migration-0003 post-execution evidence rows reconstruct with exact
current self-digests

Required expected result:

accept

Required test ownership:

ordinary_finite_current_row_constructor_and_reader_vector_test

Add:

assurance.A061

Required case:

complete 12-locator Section 41 post-execution family passes the current private
reader and exact-family matcher

Required expected result:

accept

Required test ownership:

ordinary_finite_current_private_reader_and_exact_family_vector_test

Both remain contract vectors only. They confer no execution or external
authority.

C. Strengthen V6R001's positive-control precondition.

Update:

assurance.V6R001.rank15-current-owner-cascade-stale

Its literal control and independent-audit responsibility must require, in
order:

1. all nine current row constructors pass;
2. all nine private-reader row snapshots pass;
3. the evidence-set digest reproduces;
4. the 12-locator owner-family graph reproduces;
5. the rank-15 wrapper reproduces and is accepted;
6. the current exact-family matcher returns true;
7. only then may the symbolic graph/wrapper/operand-set/relation mutation be
   applied.

Keep concrete stale identities out of the assurance record.

D. Add a causal stale-row malformed control.

Add:

assurance.V8R001.migration0003-evidence-row-self-digest-stale

and:

malformed.V8R001.migration0003-evidence-row-self-digest-stale

The assurance record must use six symbolic exact-one-predicate mutations, one
for each corrected role:

- validation_result
- independent_review
- standing_policy
- risk_lane
- global_stop
- effect_ceiling

The malformed vector must retain the six concrete V7 stale row digests listed
above and apply exactly one stale digest at a time to an otherwise exact current
row/family.

Required causal behavior:

- the pure row constructor rejects the selected row as
  `physical_family_row_digest_mismatch`;
- the private reader rejects the corresponding tuple as
  `database_integrity_failure`;
- no graph/wrapper/relation mutation is evaluated first;
- restoring the corrected row digest reconstructs the positive row and complete
  family exactly.

Use an overall expected classification such as:

migration0003_evidence_row_self_digest_mismatch

but report the exact current pure-owner and reader failure classes separately.

The concrete stale row digests may appear only in:

- this dedicated malformed vector; and
- supersession ledger entries.

They must not remain in current goldens, source-owner controls, schemas,
profiles, equality matrices, assurance records, remaining seams, manifest
truth, closeout truth, or other current records.

IDENTITY AND SUPERSESSION REGENERATION

Do not patch outer hashes only.

For every changed existing substantive record, append exactly one V7-to-V8
record-payload supersession entry binding:

- the exact V7 payload raw SHA-256;
- the exact V8 payload raw SHA-256;
- the superseded record ID;
- a reason specific to the V8 migration-0003 family source-grounding repair.

Do not add record-payload supersessions for:

- new V8 records;
- the package manifest;
- the package closeout.

Append semantic-identity supersessions for every current semantic identity that
changes. This includes at least:

- the six evidence-binding row digests;
- evidence-set digest;
- proposal digest;
- owner-family graph digest;
- rank-15 wrapper value digest;
- every changed operand-set, relation, relation-row, relation-set,
  admission-graph, membership, closure, snapshot, currentness, generated ref,
  and decision-input identity in the exact transitive closure.

Do not assume the downstream set is identical to V6's earlier rank-15 repair.
The row-level correction changes the source proposal/evidence family itself.

Do not rewrite or delete historical V1-V7 supersession entries.

Reject duplicate exact semantic supersession pairs. Preserve chain history when
an identity has now been superseded more than once.

UNCHANGED-PAYLOAD GUARD

Derive the exact changed-existing record set before writing V8.

For every V7 record ID retained in V8 and not in that derived set, require
byte-identical `payload_json`.

Outer JSONL lines may change only where dense `record_index` movement or
manifest/closeout regeneration requires it. Do not describe index-only outer
changes as semantic payload changes.

No record ID may be retired.

PACKAGE-WIDE SUPERSESSION AND STALE-IDENTITY GUARD

For every supersession entry with a 64-lowercase-hex `old_identity`:

- scan every embedded payload;
- permit that exact old identity only in supersession entries and a dedicated
  malformed vector when it is the deliberate rejected input;
- reject it in current assurance, golden, schema, profile, source-owner,
  allocation, import, equality, seam, manifest, closeout, or any other current
  truth;
- report scan population, unique old identities, permitted malformed-only
  occurrences, and zero forbidden occurrences.

Apply a separate exact scan for the six stale V7 row digests. Their only
permitted non-ledger occurrences are in
`malformed.V8R001.migration0003-evidence-row-self-digest-stale`.

Apply a separate exact scan for the V7 wrong evidence-set owner module literal.
Its only permitted current-package occurrence outside the historical ledger is
the dedicated `malformed.V3G006.evidence-set-owner-module-substitution`
negative control.

CURRENT-SOURCE POSITIVE-CONTROL GUARD

Before success, independently prove in this order:

1. all nine row mappings reproduce exact current self-digests;
2. three row digests remain unchanged and six equal the required corrected
   values;
3. all nine mappings are accepted by the current pure row constructor;
4. all nine tuples are accepted by the current private reader row constructor;
5. the bounded family is exactly nine rows in canonical role/rank/order;
6. the evidence-set digest equals
   `213b55b3a75121cadeab28e05ce7dda0525ac447464d8bbfcd82515b8e15b54d`;
7. proposal digest equals
   `acda782cef72c31e0f9e3923659de53f969b6f26c746ae03150ac9762d6d079f`;
8. owner-family graph digest equals
   `08ace396f61397e1c262258396e9015472bbbb91fbfc842107e137125c6d391e`;
9. rank-15 wrapper value digest equals
   `70dab00e12c79a58cf3a119a00dc1ad7c24efc008540fc5b4d46f88cd46e453c`;
10. the wrapper constructor accepts the supplied digest;
11. `_section41_owner_family_matches` returns true for the exact current
    locators and reader snapshots;
12. all relation, membership, closure, snapshot, currentness, Section 41,
    resupply, and decision-input identities regenerate from those accepted
    source values;
13. the V7 global-stop repaired truth table and causal active-stop vector remain
    valid on the regenerated snapshot basis.

Do not report exact-family acceptance if any earlier step failed.

REVISED DELIVERABLE

Attach exactly:

RW0_Post_Execution_Canonical_Audit_Package_V8.jsonl

Use the same canonical JSONL envelope and closed record-type ordering.

Do not freeze a final record count in advance. The exact count must be the
mechanical consequence of:

- the complete derived changed-existing payload set;
- the three new assurance records A060, A061, and V8R001;
- the one new malformed vector V8R001;
- complete record-payload supersessions;
- complete semantic-identity supersessions;
- zero retired record IDs.

Report the final exact:

- file size;
- whole-file SHA-256;
- logical record count;
- final-newline posture;
- content aggregate;
- per-type counts;
- changed existing record IDs;
- new record IDs;
- retired record IDs, which must be none;
- semantic supersession inventory;
- record-payload supersession inventory.

Do not overwrite, rename, or present V7 as the repaired deliverable.

MECHANICAL AND SEMANTIC VERIFICATION

Before success:

1. Repeat every V7 package mechanic check with duplicate-key rejection.
2. Reproduce every outer and embedded canonical JSON encoding.
3. Reproduce every payload length, raw hash, and domain-separated digest.
4. Reproduce dense indexes, unique IDs, closed record ordering, manifest,
   aggregate, closeout, and whole-file SHA-256 with two independent readers or
   hash tools.
5. Verify the exact V7-to-V8 changed/new/retired record inventory.
6. Run the unchanged-payload guard.
7. Run the nine-row current-constructor/private-reader positive-control guard.
8. Run the exact current family matcher positive-control guard.
9. Run the V8 stale-row causal malformed-vector guard.
10. Reconstruct the corrected evidence-set owner attribution from current
    source and run the repaired V3G006 owner-module substitution vector.
11. Run the complete transitive identity regeneration check.
12. Run the package-wide supersession and stale-identity guards with zero
    forbidden occurrences.
13. Recheck the V7 global-stop repair, active owner, active snapshot, clear and
    active V32 controls, and causal malformed result mutation.
14. Recheck all preserved V1-V7 repairs and accepted contracts.
15. Validate all current goldens against their schemas and profiles.
16. Validate all generated refs and self-digests.
17. Confirm exactly fifteen C1 evidence kinds remain.
18. Confirm V35-V37 remain absent from current schemas, current goldens,
    allocations, and implementation scope.
19. Recheck repository baseline, worktree count, and cleanliness.
20. Confirm no repository file or Git state changed.

INLINE REPORT

Print a concise but complete report containing:

- V7 attachment receipt;
- baseline verification;
- disposition of RW0-V7-001, RW0-V7-002, and RW0-V7-003;
- the exact nine row digest result, clearly separating three unchanged and six
  corrected rows;
- exact corrected evidence-set, proposal, owner-graph, and rank-15 wrapper
  anchors;
- proof that current row constructors and private-reader row boundaries accept
  all nine rows;
- proof that the exact current family matcher returns true;
- corrected evidence-set source-owner attribution and the precise split among
  row owner, family reader, and post-execution semantic reconstruction;
- A047, A060, A061, V6R001, V8R001, and V3G006 assurance/malformed treatment;
- exact filename, size, SHA-256, logical records, final-newline posture,
  per-type counts, and content aggregate for V8;
- complete changed/new/retired record inventory;
- complete semantic and record-payload supersession inventories;
- unchanged-payload result;
- package-wide supersession scan population and zero-violation result;
- six-stale-row-digest scan result;
- wrong-owner-module-literal scan result;
- confirmation that the V7 global-stop repair and all other preserved contracts
  remain intact;
- confirmation that V8 is visibly attached;
- confirmation that no predetermined Downloads path was required;
- confirmation that no private path is offered as the deliverable;
- success token.

SUCCESS TOKEN

Return exactly:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V8_MIGRATION0003_FAMILY_REPAIRED_READY_FOR_INDEPENDENT_AUDIT

only if:

- all three V7 findings are closed;
- all nine current row constructors and reader row boundaries pass;
- the exact current family matcher passes;
- all direct and transitive identities are regenerated;
- evidence-set owner attribution is truthful and source-grounded;
- positive assurance precedes mutation assurance;
- stale row-digest and owner-module malformed vectors are causal;
- unchanged payloads remain byte-exact;
- the supersession and stale-identity scans have zero forbidden occurrences;
- every package and source-grounding verification passes;
- V8 is visibly attached;
- repository state remains unchanged;
- no implementation prompt is issued.

Otherwise return:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V8_REPAIR_BLOCKED

and classify the blocker as exactly one of:

- fixed-input mismatch;
- fixed-input attachment unavailable;
- baseline mismatch;
- current-row-constructor reconstruction failure;
- private-reader reconstruction failure;
- current-family matcher failure;
- owner-attribution-schema-insufficiency;
- semantic contradiction;
- causal-vector failure;
- transitive regeneration failure;
- supersession leakage;
- stale-identity leakage;
- unchanged-payload drift;
- canonical verification failure;
- attachment mechanism unavailable.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
