Here is Codex's response:

[RW0_Post_Execution_Canonical_Audit_Package_V11.jsonl](/Users/ds/Downloads/rw0-v11-repair.lNhDXr/RW0_Post_Execution_Canonical_Audit_Package_V11.jsonl)

V11 was generated, independently re-opened, validated, and exposed above as the sole deliverable.

### Input and baseline

- V10 receipt: 2,613,816 bytes; SHA-256 `1f3c08d3a721f4d9bc75d89f9a0ce604bbc344c0f3cd8b3be51218dd17c1430c`; 1,681 records; no final newline; content aggregate `9302da29abad2bbdd78dcae33b1d499236d046cb195184caf8248b60e0b63895`.
- Repository: `trunk_dev` at `a3ff0b7f4f0c2378c2962e24612d605489b51638`.
- Tree: `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0`.
- Sole parent: `047563de5a443b0f8323401c92979ae2e444d2ed`.
- Subject: `feat: implement RW0-C1 durable evidence (#7)`.
- Upstream: `origin/trunk_dev`, ahead/behind `0/0`.
- One worktree; final index, working tree, untracked, and unmerged posture clean.

### Reason and rank-15 verification

The V10 defect reproduced exactly: 34 invalid reasons across the required 12 records.

- V18: 10
- V31: 5
- V32: 9
- V33: 10

Affected records:

`golden.V10.full-evidence-supply`, `golden.V11.role-supply.10.risk_lane`, `golden.V16.risk.entry.003`, `golden.V16.risk.entry.004`, `golden.V18.primary`, `golden.V31.primary`, `golden.V32.primary`, `golden.V32.active-stop`, `golden.V33.primary`, `malformed.risk-source-substitution`, `malformed.attempt-fence-expiry-substitution`, `malformed.global-stop-branch-mismatch`.

Historical V10 recovery independently reproduced using `c1-admit-section41-golden.0001`:

- Graph: 1,100 bytes; raw SHA-256 `07eab636c2896c49c06dd24cd0bc934d55b9e93aa60412ae243623769cf6546d`; domain digest `484291049fe80389eef3a856024fc26f70a59a05c3a34048eaeafbc37b5ec7e4`.
- Membership: 862 bytes; raw SHA-256 `eaab9f49c0abe3dbdcd2e998401160f9c4612aa9e6f88f78c0ddf0a719edceb7`; domain digest `5a0e664074e92aa69360513fd022824a6a247db1f18dd92cc141679047620b6f`.

Final V11 controls:

- Graph: 1,100 bytes; raw SHA-256 `ea8125cd0b2ea7766e4c3af736486c595275c19a2af6dd135a83817ec0bb6dd2`; domain digest `dfe87f72d542d9cf1e1f2a2a142086c4dd9fbdd6dfc2f7dde54b8b433ae9a094`.
- Membership: 862 bytes; raw SHA-256 `94d7da219bfe4d9aad8b3af4a604d90d4a460f5f9a5f1ca791f0f96f02d8bf5d`; domain digest `3b3ff592eaf75cbee3ae98e78b55686e1771069d34ef46db3c37bc1ed6e4d817`.

The current private reader accepted all nine rows, and the current exact-family matcher returned true.

### Delta inventories

The five new substantive records are:

- `golden.owner.rank15.graph`
- `golden.owner.rank15.membership`
- `assurance.A063`
- `assurance.V11R001.v16-dispatched-reason-stale`
- `malformed.V11R001.v16-dispatched-reason-stale`

The following 57 records are the complete changed-retained inventory and the complete record-payload supersession target inventory:
```
source-owner.migration0003-evidence-set
source-owner.migration0003-owner-family-graph
source-owner.migration0003-proposal
source-owner.migration0003-source-invocation
source-owner.rank15-section41-relation
source-owner.rank15-section41-value
golden.owner.rank15.value
golden.owner.rank15.relation
golden.V18.primary
golden.V16.risk.entry.003
golden.V16.risk.entry.004
golden.V03.role-entry.10.risk_lane
golden.V05.primary
golden.V06.projection-entry.005
golden.V02.T1-input-context
golden.V09.model-input-binding
golden.V10.full-evidence-supply
golden.V11.role-supply.10.risk_lane
golden.owner.source-invocation
golden.owner.proposal-evidence-row.10.risk_lane
golden.owner.evidence-set
golden.owner.proposal
golden.owner.owner-family-graph
golden.V22.primary
golden.V23.projection-evidence.005
golden.V24.role-resolution.05.candidate_capsule
golden.V24.role-resolution.06.worker_result
golden.V24.role-resolution.07.validation_result
golden.V24.role-resolution.08.independent_review
golden.V24.role-resolution.09.standing_policy
golden.V24.role-resolution.10.risk_lane
golden.V24.role-resolution.11.authority_currentness_attestation
golden.V24.role-resolution.12.global_stop
golden.V24.role-resolution.13.effect_ceiling
golden.V25.primary
golden.V27.primary
golden.V27.active-stop-control
golden.V29.primary
golden.V31.primary
golden.V32.primary
golden.V32.active-stop
golden.V33.primary
golden.V34.primary
golden.V26.closure-entry.007
malformed.attempt-fence-expiry-substitution
malformed.global-stop-branch-mismatch
malformed.risk-source-substitution
malformed.wrong-context-namespace
malformed.V6R001.rank15-current-owner-cascade-stale
malformed.V8R001.migration0003-evidence-row-self-digest-stale
equality.10.exact_resupply.risk_lane
equality.10.model_input.risk_lane
equality.10.section41_projection.risk_lane
equality.10.t1_context.risk_lane
assurance.A062
assurance.V6R001.rank15-current-owner-cascade-stale
assurance.V7G001.global-stop-active-applicability-split
```

Exactly 37 semantic supersessions cover:

- Nine upstream/current-source identities: source invocation, risk evidence-binding row, evidence set, proposal, V02 context, V05 projection, V09 binding, V10 evidence supply, and V18 risk matrix.
- Eight rank-15 identities: owner-family graph, wrapper value, operand set, semantic relation, relation row, relation set, admission graph, and membership.
- Twenty downstream identities: V22, V23 risk projection entry, all nine V24 roles 05–13, V25, both V27 snapshots, V29, V31, both V32 matrices, V33, and V34.

Each of the 37 semantic and 57 record supersession entries binds its exact old and replacement identity; every new supersession ID suffix was verified against the first 20 characters of its own payload hash. Retired IDs: none.

The unchanged-payload guard found 1,622 retained content payloads byte-identical. The 57 changed payloads each have exactly one record supersession.

### Final package identity

- Size: 2,719,907 bytes
- SHA-256: `e26a739dc303a555aa951e23ccd84b3583377319a82b5fcd78f99397da894afe`
- Records: 1,780
- Final newline: absent
- Content aggregate: `476fa5f4e06e0d4cb6e7fdd02ca02fb4a9531c19f0348dd88ac09a9fe9db3e36`
- Types: assurance 126; behavior profile 28; equality 36; golden 201; import edge 31; malformed 93; module allocation 44; manifest 1; closeout 1; remaining seam 8; source owner 23; supersession 1,144; value schema 44.

Whole-file hash reproduction agreed across Python one-shot hashing, Python chunked hashing, `shasum -a 256`, and `openssl dgst -sha256`.

Additional checks passed:

- All 91 pre-existing ordinary V16 instances were recursively accounted for; 90 are exact positives and the one intended result mutation reaches only `stop_branch_matrix_conflict`.
- All three V9R001 added-field negatives and seven V11R001 stale-reason negatives restore byte-exactly.
- The repaired malformed vectors reach only `risk_source_identity_mismatch`, `expired_fence_denial`, and `stop_branch_matrix_conflict`.
- All 50 V41/V42 assertions remain unchanged.
- Ninety-four unique superseded hexadecimal identities were scanned; forbidden residual occurrences: zero.
- Exactly 15 current C1 evidence kinds remain.
- The 44-allocation bijection and 31-edge import graph remain closed and acyclic.
- V35–V37 and V45 remain absent; generic risk isolation remains intact.
- Unresolved uncertainty: none.
```
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
```

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V11_REASON_AND_RANK15_PREIMAGE_REPAIRED_READY_FOR_INDEPENDENT_AUDIT
