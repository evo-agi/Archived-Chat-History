RW0 POST-EXECUTION PURE-OWNER IMPLEMENTATION — V4 PAGING-CAUSALITY REPAIR

ENGAGEMENT POSTURE

You are resuming the existing workspace-write Governed Execution Coordinator implementation conversation after the V3 independent re-audit returned BLOCK.

Repository root:
/Users/ds/Repositories/Governed Execution Coordinator

The parent conversation is the sole repository writer. Do not spawn subagents. Do not delegate mutation, validation, or synthesis. Do not perform an independent audit. Do not stage, commit, push, create a PR, contact a remote, or inspect or modify a supporting repository.

OBJECTIVE

Repair the sole remaining V3 candidate defect: eight accepted membership-closure paging malformed controls (V3G020–V3G027) currently pass without executing their hostile transcript because tests/test_post_execution_pure_owner_vectors.py returns unconditionally before the hostile construction and production invocation.

The target is one exact test-file repair that:

1. makes all eight controls causally execute their accepted positive transcript, exact one-predicate hostile transcript, and restored positive transcript;
2. observes the real production first-failure class from rw0_c_decision_membership_closure rather than returning, raising, or looking up a test-authored class;
3. adds a permanent reachability/action-count guard that would fail if the hostile branch becomes unreachable again;
4. preserves every accepted production-source, documentation, authority, import, privacy, migration, runtime, and path boundary;
5. reruns the complete prescribed validation and produces new opening evidence, provenance, and implementation report for a fresh independent re-audit.

This prompt does not authorize a source repair. Independent direct V25 inspection found no production paging defect. If genuine causal execution reveals a production defect, stop and report it without modifying production source.

DIRECT FIXED INPUTS

Before any repository command or edit, verify these exact direct inputs:

1. RW0_Post_Execution_Pure_Owner_Implementation_V3_Independent_Reaudit_Report.md
   - 22,312 bytes
   - 391 logical lines
   - final newline absent
   - SHA-256 8499349aa53b20657fee43259bb1b84465d57f87c8e364bba5481a15239cbba2
   - primary verdict BLOCK

2. RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V3.json
   - 4,377 bytes
   - one logical line
   - final newline present
   - SHA-256 92331f2082200e62889a27109958fc1b35d7949146b28ac28ee512d157840262
   - canonical compact sorted-key JSON

3. RW0_Post_Execution_Pure_Owner_Implementation_Report_V3.md
   - 67,937 bytes
   - 416 logical lines
   - final newline present
   - SHA-256 2875839c7f22f71754ed9565be042c80a8132f88df760cd86e73830c25451155
   - historical V3 implementation evidence only

If any direct input differs, stop before repository inspection with:

RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_V4_INPUT_MISMATCH

RETAINED GOVERNING INPUTS

The existing implementation conversation must still retain the exact previously supplied governing inputs, including:

- original implementation authorization;
- V2 and V3 repair prompts;
- accepted V11 canonical package and its accepted audit;
- implementation-boundary freeze and machine manifest;
- review overlay;
- governed-execution.audit-patch-manifest.v1 recipe source;
- V3 opening evidence;
- prior V1/V2 implementation and audit evidence required for provenance continuity.

Verify retained inputs only by their already established exact filenames and hashes. Do not search the filesystem for substitutes, infer missing bytes, fetch anything, or use a same-named file from another location. If a required retained input is unavailable or differs, stop with:

RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_V4_RETAINED_INPUT_UNAVAILABLE

AUTHORITY AND SEAM CLASSIFICATION

Current merged authority:
- branch/HEAD/current repository contracts and protected source owners at the fixed baseline;
- Git object/ref truth;
- current C1 and migration-0003 owners.

Accepted proposed contract:
- the accepted V11 package and audit;
- exact 44 values, 28 profiles/evaluators, 201 goldens, 93 malformed controls, 126 assurances, 36 equalities, 31 import edges, 44 allocations, and eight seams.

Frozen implementation boundary:
- six private pure source modules;
- four new finite-test modules;
- three existing guard-test updates;
- seven bounded documentation updates;
- exact twenty-path ceiling;
- no runtime, I/O, migration, public export, durable decision, production caller, terminal, RW0-D/E, or Execution Substrate effect.

V3 audit result:
- production semantics, V03/V11 grammar, V22 matcher equivalence, V24 currentness binding, V25–V34 behavior, runtime bytecode guard, security/privacy, imports, docs, and provenance passed;
- one High-severity test-evidence defect remains;
- one Medium report overclaim follows from that defect;
- no architecture reset or production-source repair is currently indicated.

EXACT OPENING GATE

Before editing:

1. Verify physical root exactly:
   /Users/ds/Repositories/Governed Execution Coordinator
2. Verify:
   - branch: trunk_dev
   - HEAD: a3ff0b7f4f0c2378c2962e24612d605489b51638
   - tree: d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0
   - sole parent: 047563de5a443b0f8323401c92979ae2e444d2ed
   - subject: feat: implement RW0-C1 durable evidence (#7)
   - upstream: origin/trunk_dev
   - divergence: 0/0 using the existing local remote-tracking ref only
   - exactly one worktree
   - zero staged paths
   - zero unmerged paths
3. Verify status is exactly the twenty V3 candidate paths: ten tracked modifications and ten untracked regular mode-0644 files.
4. Verify no path outside the V3 manifest differs from HEAD.
5. Verify the exact provenance recipe source:
   - recipe ID governed-execution.audit-patch-manifest.v1
   - 3,945 bytes
   - 166 logical lines
   - final newline present
   - SHA-256 db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
6. Run the exact recipe twice serially before editing. Both outputs must be byte-identical to the attached V3 manifest:
   - 20 files
   - manifest SHA-256 92331f2082200e62889a27109958fc1b35d7949146b28ac28ee512d157840262
   - tracked textual-diff SHA-256 897e95f470b55690abb2c25bd2b1d0b760ad9e6b0b3541f4ad4f5012cd0f022f
7. Reproduce the V3 safe ignored-cache inventory without exposing source bytes, absolute operator paths, secrets, or credentials:
   - one root: src/ge_nwp_coordinator/__pycache__
   - 37 regular ignored members
   - aggregate dbaa5d1ff000e2c00e9b64d5b1e591ac8374e1b9bd9f3a6c5c0c17b3742c8f90
8. Before editing, write and expose outside the repository:
   RW0_Post_Execution_Pure_Owner_Implementation_Repair_Opening_Evidence_V4.json
   It must be canonical compact sorted-key JSON with final LF and contain only safe repository-relative evidence. It must bind the V3 manifest, recipe, repository identity, staged/unmerged posture, and safe opening cache inventory. It is evidence only and confers no authority.

Any opening mismatch requires:

RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_V4_PROVENANCE_MISMATCH

EXACT MUTATION AUTHORITY

The only repository path authorized to change is:

tests/test_post_execution_pure_owner_vectors.py

All other nineteen V3 candidate files must remain byte-identical to the V3 manifest. Every path outside the twenty-path candidate must remain equal to HEAD.

Do not edit:
- any production source module;
- any documentation file;
- any other test file;
- any protected current-owner file;
- any migration, schema, catalog, generated application surface, public API, package export, StateStore, WriterSession, SQLite reader/writer, runtime, CLI, service, worker, provider, or supporting repository.

If the causal paging runs expose a production defect, do not widen this repair. Stop with:

RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_V4_PRODUCTION_DEFECT_DISCOVERED

and report the exact hostile input, observed production behavior, expected contract behavior, likely owning source path, and why the one-file test repair cannot close it.

AUDIT FINDING TO REPAIR

The V3 independent re-audit found an unconditional early return in the paging malformed-control helper near tests/test_post_execution_pure_owner_vectors.py:845. Lines after the return, including hostile transcript construction and production invocation, are unreachable.

Affected accepted malformed IDs:

1. malformed.V3G020.membership-page-duplicate
2. malformed.V3G021.membership-cursor-nonmonotonic
3. malformed.V3G022.membership-page-reordered
4. malformed.V3G023.membership-cursor-no-progress
5. malformed.V3G024.membership-overflow
6. malformed.V3G025.membership-premature-termination
7. malformed.V3G026.membership-continuation-substitution
8. malformed.V3G027.membership-capability-epoch-change

Observed false-green behavior:
- each case invoked rw0_c_decision_membership_closure exactly once;
- the invocation used the same accepted one-page/eight-row epoch.1 transcript;
- the helper returned constant basis_conflict before applying any hostile mutation;
- nominal 93-control suite passed, but only 85 controls were causally exercised.

REQUIRED IMPLEMENTATION

Repair the existing paging malformed-control dispatch so each of the eight IDs performs all of the following against real production behavior:

A. Positive baseline
- Construct the accepted positive finite paging transcript from the existing test-local accepted fixtures.
- Invoke rw0_c_decision_membership_closure with the exact accepted inputs.
- Require the accepted output to match the frozen positive expectation.
- Capture immutable/canonical baseline evidence needed to prove later restoration.

B. Exact one-predicate hostile transcript
- Deep-copy or reconstruct the accepted transcript without mutating the shared positive fixture.
- Apply exactly the accepted hostile predicate for the current ID:
  - V3G020: duplicate membership entry/page member.
  - V3G021: non-monotonic cursor progression.
  - V3G022: page/member ordering violation.
  - V3G023: no-progress continuation cursor.
  - V3G024: overflow beyond the 65,536 maximum / explicit 65,537th-entry condition.
  - V3G025: premature terminal page/termination while continuation is required.
  - V3G026: foreign/substituted continuation cursor.
  - V3G027: capability epoch changes across the transcript.
- Assert the hostile transcript differs from the positive transcript at the intended predicate and nowhere else, except mechanically dependent test-local coordinates required to form the transcript.
- Invoke rw0_c_decision_membership_closure with the hostile transcript.
- Capture the real production rejection.
- Require the actual first failure class to be basis_conflict, consistent with the accepted V11 malformed control.
- Do not return a constant class, consult a record-ID-to-reason lookup as semantic evidence, or raise a test-authored semantic exception.

C. Positive restoration
- Restore or reconstruct the exact accepted transcript.
- Invoke rw0_c_decision_membership_closure again.
- Require the accepted output and canonical/restoration evidence to match the original positive byte-for-byte where the existing fixtures expose bytes, or exact mapping/value equality where they expose immutable typed values.
- Prove the shared positive fixture remained unchanged.

D. Permanent reachability/action-count guard
- Add a permanent test that fails if the hostile branch becomes unreachable.
- Instrument the production action at the test boundary without bypassing it.
- For each of the eight malformed IDs, require exactly three production action invocations in the baseline/hostile/restored sequence, unless the current fixture architecture demonstrably requires a higher fixed count; if so, freeze and explain the exact count per ID in the report.
- Require one invocation to carry a transcript distinct from the accepted positive at the exact hostile predicate.
- Reject an early return, constant classification, synthetic envelope-only mutation, hard-coded self-raise, or a path that never invokes the hostile action.
- Prefer a runtime call/transcript assertion plus a focused AST reachability guard. Do not rely on textual grep alone.

E. Causality/report truth
- Update only the test code. Do not edit the historical V3 implementation report.
- The new V4 implementation report must supersede the V3 causality overclaim and include an exact eight-row table:
  malformed ID; positive fixture; exact mutation; hostile transcript distinction; production action; baseline call count; hostile call count; restoration call count; actual first failure; positive restoration result.

NON-GOALS AND FORBIDDEN SHORTCUTS

Do not:
- change accepted V11 contract semantics;
- change basis_conflict vocabulary or precedence;
- weaken V25 membership closure behavior;
- replace real production invocation with a mock result;
- count fixture construction, registry membership, a report ledger, or a hard-coded expected label as causal execution;
- skip overflow because it is expensive; use the existing bounded finite test mechanism and accepted 65,537 sentinel contract;
- add a new test or source path;
- modify the provenance recipe;
- delete or rewrite the pre-existing ignored cache;
- create repository-local reports, manifests, databases, archives, logs, or build outputs;
- claim independent audit or commit readiness.

FOCUSED VALIDATION

Run focused validation first, with PYTHONDONTWRITEBYTECODE=1 and pytest cache disabled.

At minimum, run and report exact commands/results for:

1. The eight V3G020–V3G027 cases alone.
2. The permanent reachability/action-count guard alone.
3. The complete 93-malformed-control registry.
4. The no-synthetic-self-raise/no-constant-classification guard.
5. The complete tests/test_post_execution_pure_owner_vectors.py module.
6. Any directly adjacent accepted paging/closure positive tests needed to prove restoration and V25 preservation.

The report must identify exact pytest node IDs or selection expressions used. Development failures may be repaired only within the one authorized test file and must be recorded honestly. Intermediate states receive no validation or provenance credit.

FORMAL EXTERNAL-CLONE VALIDATION

After the one-file repair is complete and stable:

1. Do not run formal validation in a way that mutates the live repository or its pre-existing ignored cache.
2. Create a private external local audit/validation root, mode 0700, with clone-time umask 022.
3. Clone from the exact committed HEAD using a local --no-local, single-branch, no-tags clone; do not fetch or contact a remote.
4. Overlay exactly the twenty final candidate files.
5. Verify every overlaid path type, mode, size, and SHA-256 against the saved final V4 manifest candidate.
6. Run the provenance recipe twice before tests and require identical output.
7. Run V02–V06 serially with no concurrent edit or cleanup:

V02:
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_post_execution_pure_owner_values.py tests/test_post_execution_pure_owner_vectors.py tests/test_post_execution_pure_owner_relations.py tests/test_post_execution_pure_owner_boundaries.py tests/test_c2a_nonimplementation.py tests/test_runtime_non_authority.py tests/test_rw0_b1_boundaries.py

V03:
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_rw0_b1_phase_values.py tests/test_rw0_b1_vectors.py tests/test_rw0_b1_relations.py tests/test_worker_execution_semantic_values.py tests/test_worker_execution_semantic_vectors.py tests/test_worker_execution_semantic_relations.py tests/test_worker_execution_semantic_boundaries.py tests/test_finite_backlog.py tests/test_global_stop.py

V04:
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_section41_cognitive_proposal_row_values.py tests/test_section41_cognitive_proposal_semantic_values.py tests/test_section41_pre_execution_plan_disposition_contracts.py tests/test_section41_pre_execution_plan_disposition_recovery.py tests/test_section41_private_atomic_pre_execution_plan_disposition.py tests/test_section41_private_pre_execution_plan_disposition_delegation.py tests/test_rw0_c1_mutation_contracts.py tests/test_rw0_c1_private_atomic_persistence.py tests/test_rw0_c1_private_readers.py tests/test_rw0_c1_reader_contracts.py tests/test_rw0_c1_recovery.py tests/test_rw0_c1_row_values.py tests/test_rw0_c1_semantic_values.py tests/test_rw0_c1_writer_session_delegation.py tests/test_remote_worker_pre_execution_planning_contract.py::test_f1_post_execution_common_proposal_needs_no_preexecution_context_row tests/test_remote_worker_pre_execution_planning_contract.py::test_s41_post_execution_evidence_is_exactly_zero_or_complete tests/test_remote_worker_pre_execution_planning_contract.py::test_s41_post_execution_evidence_rejects_every_noncanonical_member tests/test_remote_worker_pre_execution_planning_contract.py::test_repaired_nine_table_ddl_and_both_golden_families_are_representable tests/test_remote_worker_pre_execution_planning_contract.py::test_migration_0003_owner_freezes_exact_representability_without_0002_rebuild

V05:
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q tests/test_sqlite_b1_migrations.py tests/test_sqlite_c2b1_migration_framework.py tests/test_sqlite_c2b2_migration_0002.py tests/test_sqlite_section41_migration_0003.py tests/test_sqlite_rw0_c1_migration_0004.py tests/test_autonomous_software_development_operating_model.py tests/test_architecture_contracts.py tests/test_rw0_remote_contact_phase_entry_contract.py tests/test_software_development_progression_boundary.py tests/test_rw0_b2_wire_boundaries.py tests/test_rw0_b2_capability_boundaries.py

V06:
env PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -p no:cacheprovider -q

8. After tests, run:
   - git diff --check
   - exact status/staged/unmerged checks
   - artifact scans for cache, bytecode, pytest cache, DB/journal/WAL/SHM, locks, build/dist/egg-info, archives, OS metadata, symlinks, executables, and unsupported types
9. Run the provenance recipe twice after tests and require byte-identical output matching the saved final V4 manifest.
10. Remove only validation-created external artifacts from their working locations using the established safe cleanup posture. Do not alter the live repository cache.

FINAL PROVENANCE REQUIREMENTS

After all focused and formal validation:

1. Verify the final candidate still contains exactly twenty paths:
   - ten tracked modifications;
   - ten untracked regular files;
   - all mode 0644;
   - zero staged and zero unmerged paths.
2. Verify exactly one candidate file differs from the V3 manifest:
   tests/test_post_execution_pure_owner_vectors.py
3. Verify the other nineteen candidate files are byte-identical to V3.
4. Verify every path outside the candidate remains equal to HEAD.
5. The tracked textual-diff SHA-256 must remain:
   897e95f470b55690abb2c25bd2b1d0b760ad9e6b0b3541f4ad4f5012cd0f022f
   because the sole V4 repository edit is to the previously untracked vector test. Do not use this tracked-only digest as a substitute for the canonical manifest.
6. Run the exact recipe twice serially in the live repository and require byte-identical output.
7. Reproduce final live cache equality to the V4 opening evidence: one root, 37 members, exact per-member metadata/hashes, aggregate dbaa5d1ff000e2c00e9b64d5b1e591ac8374e1b9bd9f3a6c5c0c17b3742c8f90.
8. Expose outside the repository:
   - RW0_Post_Execution_Pure_Owner_Implementation_Repair_Opening_Evidence_V4.json
   - RW0_Post_Execution_Pure_Owner_Implementation_Provenance_Manifest_V4.json
   - RW0_Post_Execution_Pure_Owner_Implementation_Report_V4.md
9. The V4 provenance manifest must be the exact canonical recipe output, not a hand-authored summary.
10. The V4 report must record artifact identities, exact path transition, focused and formal commands/results, eight-row causality evidence, opening/final cache equality, assumptions, skipped/unavailable observations, and all non-authorizations.

STOP CONDITIONS

Stop without widening if:
- any fixed or retained input differs;
- starting V3 provenance does not reproduce;
- any path other than tests/test_post_execution_pure_owner_vectors.py needs modification;
- any of the eight hostile transcripts is accepted or fails with a class other than the accepted first failure, indicating a production-contract defect;
- the positive or restored transcript does not pass exactly;
- shared positive fixtures are mutated;
- the action-count/reachability guard cannot be made deterministic without production changes;
- any V02–V06 command fails on final bytes;
- final provenance is unstable or does not contain exactly the frozen twenty paths;
- the live cache differs from opening evidence;
- any migration, public/runtime, durable-state, authority, production-caller, or supporting-repository widening appears.

Use the blocking token:

RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_V4_REPAIR_BLOCKED

DELIVERABLE AND SUCCESS TOKEN

On success, visibly attach the three V4 artifacts and report their exact size, SHA-256, logical-unit count, final-newline posture, and safe file mode where observable.

Return exactly this primary success token:

RW0_POST_EXECUTION_PURE_OWNER_IMPLEMENTATION_REPAIRED_V4_VALIDATED_PROVENANCE_READY_FOR_REAUDIT

REQUIRED NON-ACTIONS

Report explicitly:

INDEPENDENT_AUDIT_NOT_PERFORMED
MIGRATION_0005_NOT_CREATED
SQLITE_RUNTIME_NOT_WIDENED
PUBLIC_EXPORT_NOT_CREATED
PRODUCTION_CALLER_NOT_CREATED
DURABLE_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
SUBAGENTS_NOT_SPAWNED
