# Disposition

**Accept the independent audit’s `BLOCK` verdict.**

The audit confirms the V16 contradiction identified in the pre-audit. V8 remains mechanically sound, and the migration-0003 repair remains accepted, but the package cannot both enforce V16’s five-field closed schema and accept twenty positive eight-field instances. This is a correctable contract defect, not an architectural rejection. :chatgpt-content-reference{index="0"}

The previously repaired surfaces remain intact:

- exact V7→V8 package mechanics and supersession closure;
- all nine migration-0003 rows passing current construction and private-reader reconstruction;
- the zero-or-nine family and rank-15 cascade;
- the corrected evidence-set owner split;
- V8R001 causality;
- the V7 active-global-stop semantics. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

No authority split, module decomposition, C1 boundary, migration posture, or global-stop contract needs to be reopened.

## The exact defect

`DecisionBranchEvaluationEntryV1` declares only:

```text
branch
applicability
governed_effect_class
result
reason
```

and rejects unknown fields before canonicalization. Yet each entry in these four positive matrices additionally encodes `schema_id`, `source_ref`, and `source_digest`:

```text
golden.V31.primary
golden.V32.primary
golden.V32.active-stop
golden.V33.primary
```

That produces exactly twenty invalid positive instances. The audit found no eight-field sourced-entry schema, specialization rule, parent-envelope composition, profile, equality contract, or module allocation that could legalize them. :chatgpt-content-reference{index="3"}

The defect also invalidates finite-assurance claims: A001 says unknown fields are rejected, while the current positive controls require the same fields to be accepted. V7G001’s global-stop mutation remains mechanically meaningful, but its positive entries are not legal V16 values until this is repaired. :chatgpt-content-reference{index="4"}

# Owner-contract decision

The repair should choose the audit’s **first option**:

> **V16 remains an exact five-field, parent-bound value. Source identity belongs to the parent matrix.**

The alternative—introducing a new closed eight-field sourced-entry schema—is rejected.

This is not an arbitrary simplification. The earlier frozen target in the uploaded tranche history already made the choice:

- `GE 00073 - RW0-C2/Timeline/T39 - USER.md:797-798` defines `DecisionBranchEvaluationEntryV1` as precisely the five fields above.
- `GE 00073 - RW0-C2/Timeline/T41 - USER.md:501` classifies V16 as parent-only under the consuming matrix profile.
- `GE 00073 - RW0-C2/Timeline/T41 - USER.md:534-543` dispatches V16 through V17, V18, V31, V32, and V33.

The five-field model is also the narrower and safer design:

- V17 and V18 already contain valid five-field V16 entries.
- Repeating the same source identity in every child is redundant and creates another substitution/drift surface.
- A parent-bound child has no independent source identity, reference, or digest to protect.
- A new eight-field type would unnecessarily widen the value inventory, module graph, allocation surface, implementation, and assurance corpus.

## Required parent binding

The corrected contract uses these parent-level source bindings:

| Parent | Source binding |
|---|---|
| V17 policy matrix | Policy-source and related policy coordinates on V17 |
| V18 risk matrix | Risk policy, source profile, and source-binding coordinates on V18 |
| V31 authority matrix | Exact snapshot, selected-authority membership/closure lineage, proposal pair, and authority profile |
| V32 stop matrix | Parent `global_stop_ref` and `global_stop_digest` |
| V33 ceiling matrix | Parent `source_effect_ceiling_ref` and `source_effect_ceiling_digest` |

V31 receives a specific stop condition: Codex must prove that its existing parent lineage uniquely binds the authority basis. It must stop rather than restore child source fields or invent a parent widening if that proof fails.

## Additional V16 correction

V16 currently copies the standing-policy profile as though that were its sole governing profile. That is also inconsistent with a parent-dispatched value.

V9 must replace that posture with a closed dispatch inventory covering exactly the current profiles for V17, V18, V31, V32, and V33. V16 should contain structural field rules only; each consuming parent profile owns its branch, result, reason, and precedence vocabulary.

# Frozen reconstruction anchors

After removing the three illegal fields and preserving the current V8 parent shapes, the following values independently reproduce:

| Record | Corrected reference | Corrected digest |
|---|---|---|
| V31 authority | `rw0-c-authority-matrix.35e624694714100efc06aa11387b57a4bffd67b753e7723c5d5c0641e6933e10` | `51b050e137ca5629b9b6aea8c49501b9ed97fff7e0c9dafaec1ff0ea3bffa7bb` |
| V32 clear | `rw0-c-global-stop-matrix.4cb528a19a5f970cbca71f309b84b5a56c1cfbb55e95a6269ea4c3f288a0563b` | `907c53e336eea996093c1c3aaac9ced66655184ab6eee26fa293d60b5ed7dab2` |
| V32 active | `rw0-c-global-stop-matrix.e6dd3829e5c63c47d9fd8aee8b2c1820550d917f9b969c153765f49e84fefd4d` | `1787c27d06f6e4f3e8f1be8e41255f0ddc04eb322f9def4196612738400b68af` |
| V33 ceiling | `rw0-c-ceiling-matrix.8b38ed0977df2928c7023fdedb8eb8951447d6e3818c707d49845ca558f52697` | `9ba46b4ce3e4e7294d9d638490b54a86415f47dc3841d52c2bd1525a92fb50be` |

The two affected malformed matrices also receive exact corrected five-field bases while preserving their intended semantic mutations:

- attempt-fence expiry remains an expiry-only negative control;
- active-stop mismatch still changes only `candidate_acceptance.result` from `deny` to `permit`.

## New finite assurance

V9 requires:

```text
assurance.A062
```

to prove recursive five-field V16 validation across V17, V18, V31, V32 clear, V32 active, and V33.

It also adds:

```text
assurance.V9R001.v16-parent-bound-extra-field-rejection
malformed.V9R001.v16-parent-bound-extra-field-rejection
```

The malformed record contains three one-at-a-time cases:

```text
add schema_id
add source_ref
add source_digest
```

Each must fail at recursive V16 validation **before** parent ref/digest comparison and restore exactly to the five-field positive entry when the one extra key is removed.

# V9 repair handoff

Use a **package-generation/repair Codex conversation**, not the V8 audit conversation.

Attach exactly the prompt and V8 package below. The audit finding and the owning-contract decision are embedded in the prompt.

### Repair prompt

:chatgpt-content-reference{index="7"}[Download the V9 V16 parent-bound-entry repair prompt](sandbox:/mnt/data/Coordinator_RW0_Canonical_Package_V9_V16_Parent_Bound_Entry_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_Canonical_Package_V9_V16_Parent_Bound_Entry_Repair_Prompt.txt

Size:
32,637 bytes

SHA-256:
1dfdb472f06f15239f9ee76a113c214a76cb923666baa227b190577651adc384

Logical lines:
929

Final newline:
absent
```

### Sole fixed input

:chatgpt-content-reference{index="8"}[Download the exact V8 package](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Audit_Package_V8.jsonl)

```text
Filename:
RW0_Post_Execution_Canonical_Audit_Package_V8.jsonl

Size:
2,587,718 bytes

SHA-256:
91eb1bbfd3d741e294117f6a8e548a797cc547d132404adb187c04027a0a3fc7

Logical records:
1,660

Final newline:
absent

Content aggregate:
771f654a896e8fdc7d8147bb7e3c3fc4b9c7ecab83b8fa76dc5248ca0cc32750
```

The expected deliverable is:

```text
RW0_Post_Execution_Canonical_Audit_Package_V9.jsonl
```

The required success token is:

```text
RW0_POST_EXECUTION_CANONICAL_PACKAGE_V9_V16_PARENT_BOUND_ENTRY_REPAIRED_READY_FOR_INDEPENDENT_AUDIT
```

The prompt deliberately does not freeze the final record count or a complete hand-written changed-record inventory. Codex must derive the transitive set mechanically, add complete semantic and record-payload supersessions, and preserve every unrelated V8 payload byte-for-byte.

A successful V9 repair authorizes only another **fresh read-only independent audit**. The V8 auditor likewise confined the next boundary to owner-contract correction, complete regeneration, and re-audit; it did not authorize implementation. :chatgpt-content-reference{index="5"}

No repository implementation, migration `0005`, durable mutation, C2B progression writer, terminal, RW0-D/E, or Execution Substrate work is authorized. The V8 audit also confirms that none of those effects occurred during its inspection. :chatgpt-content-reference{index="6"}

**Sources:** V8 independent-audit report; exact V8 package; uploaded Coordinator snapshot; uploaded RW0-C2 tranche history at `Timeline/T39 - USER.md` and `Timeline/T41 - USER.md`.

**Confidence:** 0.995 that `BLOCK` is correct; 0.99 that the five-field parent-bound model is the previously frozen owning target; 0.99 on the four reconstructed positive anchors; 0.98 that the V9 prompt defines the narrowest sufficient repair.
