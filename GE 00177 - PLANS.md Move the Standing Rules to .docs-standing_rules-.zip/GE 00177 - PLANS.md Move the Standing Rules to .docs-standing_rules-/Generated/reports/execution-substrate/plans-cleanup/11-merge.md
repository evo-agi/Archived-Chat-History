# ES PLANS.md cleanup: merge note 11 (step 2)

Status: merged. Written 2026-11-25 by the writer thread.

## Merge

- PR: https://github.com/evo-agi/Execution-Substrate/pull/56, squash-merged into `trunk_dev` at about 01:48Z.
- Merge commit: `2ca76cd021bdb5e4aa7221a56400690120ca30c8`, parent `fd0529a206cf079b979129b6f533ea73dae9be17`.
- The merged tree `342aeda91924ecea881c4218b0a6200c912094df` equals the audited head's tree (`cf355c32e3b051d356016edb659e19d4c37be484`). The diff from `fd0529a` touches exactly the 23 manifest paths.
- `trunk_dev` is now `2ca76cd`.

## Merge gate (provenance §5.4)

- **Audit.** Re-audit 10 gave ACCEPT at `cf355c3` with no findings (`10-audit.md`, SHA-256 `f3c41811d96b01f80c42db75ad63cfea1a5f7e43d7281aa128981c2f0b80c470`). The v2 manifest canonical is `53ca4c367e64f56cdb715abac3eccb917dabc81578a3cdc64dae98119ffb1000` against `fd0529a`.
- **Head unchanged.** `git ls-remote` showed `claude/project-thread-kumrhu` = `cf355c3` just before the merge, and the merge call pinned `expectedHeadSha`.
- **Base unchanged.** `trunk_dev` = `fd0529a` just before the merge. That is the audit's base, so the branch was up to date.
- **CI.** "build, vet and test" was green on `cf355c3` (run 45518046151).
- **Policy.** This is a docs/tests-only PR, which merges without David after audit and gate. The coordinator confirmed this at 01:45Z.
- **Post-merge bytes.** The tree identity above confirms them.

## Codex review

Marking the PR ready started a Codex code review on `cf355c3`. It failed at 01:46:30Z with "Codex usage limits have been reached for code reviews", so no Codex review ran on this PR. Its status block lists `has_any_findings: true` beside `status: failed`, but no finding was posted. The audit and CI are the gate, and neither depends on Codex.

## History

- Audit 08 gave BLOCK on A08-1: 15 moved rule paragraphs had no test. Report 09 repaired it, and re-audit 10 gave ACCEPT.
- `trunk_dev` moved to `fd0529a` (#57) during the repair. It was merged into the branch with a plain merge, and audit 10 checked that merge.

## Follow-ups (for the coordinator)

- **A08-2.** Name the two rule files in `PLANS.md`'s opening note. Per the coordinator, this goes into the docs cleanup backlog.
- **Two more standing-rule sections in `PLANS.md`.** "Current paired-root custody and acceptance scope" and "Remote Alpha access contract v1 — Tranche A" are standing rules that are still there.
- **Part 2b, branch `9slgp8`.** It has to re-apply its `PLANS.md` edits in place. Its Nomad Status hunk now lives in the SHA-pinned record. The part 2b thread was told the new trunk SHA.
- **Branch `qhn13c`.** It adds one bullet that stays in `PLANS.md`.
- **Codex.** It is out of review credits for this repo.
