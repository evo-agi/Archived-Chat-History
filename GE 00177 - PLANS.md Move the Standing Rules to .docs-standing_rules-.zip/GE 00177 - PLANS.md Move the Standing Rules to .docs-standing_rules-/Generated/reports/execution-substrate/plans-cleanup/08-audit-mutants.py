"""Audit 08 targeted mutants for ES PR #56 (head 3c4130f). Run as ci in a clean clone.
Each edits files, git-adds, runs the root package (all tests), resets."""
import subprocess, sys, os
WT = sys.argv[1]
def sh(*a): return subprocess.run(a, cwd=WT, capture_output=True, text=True)
def rd(p): return open(os.path.join(WT, p), encoding="utf-8").read()
def wr(p, s):
    os.makedirs(os.path.dirname(os.path.join(WT, p)) or WT, exist_ok=True)
    open(os.path.join(WT, p), "w", encoding="utf-8").write(s)
def rep(p, old, new):
    s = rd(p); assert s.count(old) == 1, (p, old[:60], s.count(old)); wr(p, s.replace(old, new))
def first_line_with(p, needle):
    ls = [l for l in rd(p).splitlines(True) if needle in l]; assert ls, (p, needle); return ls[0]
def drop_line(p, needle): rep(p, first_line_with(p, needle), "")
A = ".docs/standing_rules/execution_admission_and_custody.md"
R = ".docs/standing_rules/remote_alpha_operator_routes.md"
PA = "## Current Planning Objective\n"
RH = "### Remote Alpha Vault workload-auth bootstrap routes (P0o to P0q)\n"
AH = "### R6J-R9.28/Stage-A — inert outside-observer structural contract\n"
R6J = "**2026-11-13 Review-22 development-source disposition:**\n"
def before(p, anchor, text): rep(p, anchor, text + anchor)
def append(p, text): wr(p, rd(p) + text)
M = [
 ("G01 A05-2 fence trick hides ## Status in PLANS.md", "fail", lambda: before("PLANS.md", "## Primary Program Orientation\n", "```\n~~~\n```\n## Status\n\n")),
 ("G02 A05-2 fence trick in admission rules", "fail", lambda: before(A, AH, "```\n~~~\n```\n## Status\n\n")),
 ("G03 status heading in route rules", "fail", lambda: before(R, RH, "## Status Update\n\n")),
 ("G04 dated heading in admission rules", "fail", lambda: append(A, "\n### Follow-up (2026-11-25)\n\nText.\n")),
 ("G05 line opening with a date in route rules", "fail", lambda: append(R, "\n2026-11-25: P0v changed.\n")),
 ("G06 R6J line duplicated in admission rules", "fail", lambda: append(A, "\n" + R6J)),
 ("G07 R6J line copied into PLANS.md", "fail", lambda: before("PLANS.md", "## Primary Program Orientation\n", R6J + "\n")),
 ("G08 R6J line removed from admission rules", "fail", lambda: rep(A, R6J, "")),
 ("G09 PLANS.md +5,000 bytes", "fail", lambda: append("PLANS.md", ("y" * 49 + "\n") * 100)),
 ("G10 PLANS.md +4,900 bytes (control)", "pass", lambda: append("PLANS.md", ("y" * 48 + "\n") * 100)),
 ("G11 third file in standing_rules (git-added)", "fail", lambda: wr(".docs/standing_rules/extra.md", "# Extra\n\nText.\n")),
 ("G12 AGENTS rank rule: second -> third", "fail", lambda: rep("AGENTS.md", "second in the list above", "third in the list above")),
 ("G13 AGENTS authority line 2 changed", "fail", lambda: rep("AGENTS.md", "2. `PLANS.md` for allowed redesign work", "2. `PLANS.md` and `.docs/standing_rules/` for allowed redesign work")),
 ("G14 AGENTS section 5 consult line removed", "fail", lambda: drop_line("AGENTS.md", "consult the `.docs/standing_rules/` file")),
 ("G15 AGENTS section 9 update line removed", "fail", lambda: drop_line("AGENTS.md", "update the `.docs/standing_rules/` file in place")),
 ("G16 PLANS.md route pointer link removed", "fail", lambda: rep("PLANS.md", "[`.docs/standing_rules/remote_alpha_operator_routes.md`](.docs/standing_rules/remote_alpha_operator_routes.md)", "`.docs/standing_rules/remote_alpha_operator_routes.md`")),
 ("G17 PLANS.md admission pointer authority sentence removed", "fail", lambda: rep("PLANS.md", "reliable-submit tranche status, are in\n[`.docs/standing_rules/execution_admission_and_custody.md`](.docs/standing_rules/execution_admission_and_custody.md).\nThey keep this file's authority (`AGENTS.md` section 3).\n", "reliable-submit tranche status, are in\n[`.docs/standing_rules/execution_admission_and_custody.md`](.docs/standing_rules/execution_admission_and_custody.md).\n")),
 ("G18 route rules header authority sentence weakened", "fail", lambda: rep(R, "with `PLANS.md`, second, and only their\nlocation changed.", "below `PLANS.md`, and only their\nlocation changed.")),
 ("G19 contracts.md owner pointer removed", "fail", lambda: rep(".docs/execution_lifecycle/contracts.md", "`.docs/standing_rules/execution_admission_and_custody.md`; `AGENTS.md` section\n3 ranks that file with `PLANS.md`.", "`.docs/standing_rules/execution_admission_and_custody.md`.")),
 ("G20 remote_supported_host_alpha owner pointer removed", "fail", lambda: rep(".docs/system_overview/remote_supported_host_alpha.md", "`.docs/standing_rules/remote_alpha_operator_routes.md`; `AGENTS.md` section 3\nranks that file with `PLANS.md`.", "`.docs/standing_rules/remote_alpha_operator_routes.md`.")),
 ("G21 README link to admission rules removed", "fail", lambda: rep("README.md", "[the Workstream C admission and custody rules](.docs/standing_rules/execution_admission_and_custody.md)", "the Workstream C admission and custody rules")),
 ("G22 moved R6J heading copied back into PLANS.md", "fail", lambda: before("PLANS.md", "## Primary Program Orientation\n", AH + "\nText.\n\n")),
 ("G23 fourth section heading in route rules", "fail", lambda: append(R, "\n### Remote Alpha extra routes\n\nText.\n")),
 ("G24 line citation of a rule file in a doc", "fail", lambda: append(".docs/mvp.md", "\nSee standing_rules/remote_alpha_operator_routes.md:12.\n")),
 ("G25 refused Tranche B gate phrase in route rules", "fail", lambda: append(R, "\nThe operator compatibility is a Tranche B prerequisite.\n")),
 ("G26 refused final-audit phrase in admission rules", "fail", lambda: append(A, "\nNote: the running-deployment observation is complete.\n")),
 ("G27 refused stale target relationship in admission rules", "fail", lambda: append(A, "\nThe route without CP is only a bounded coding-work proof candidate.\n")),
 ("G28 R6J line indented copy in admission rules", "fail", lambda: append(A, "\n   " + R6J)),
 ("L1 limit: 'On <date>,' line in admission rules", "limit", lambda: append(A, "\nOn 2026-11-25, PR #57 changed custody.\n")),
 ("L2 limit: unclosed fence hides later headings in route rules", "limit", lambda: append(R, "\n```\n## Status\n")),
]
assert sh("git", "status", "--porcelain").stdout == "", "not clean"
bad = 0
for name, want, fn in M:
    fn(); sh("git", "add", "-A")
    r = sh("go", "test", "-count=1", ".")
    failed = sorted({l.split()[2] for l in r.stdout.splitlines() if l.startswith("--- FAIL")})
    got = "pass" if r.returncode == 0 else "fail"
    ok = want == "limit" or got == want
    bad += not ok
    print(f"{'OK ' if ok else 'BAD'} {name}: want {want}, got {got} {failed}", flush=True)
    sh("git", "reset", "-q", "--hard", "HEAD"); sh("git", "clean", "-qfdx")
    assert sh("git", "status", "--porcelain").stdout == ""
r = sh("go", "test", "-count=1", ".")
print("clean rerun:", "pass" if r.returncode == 0 else "FAIL", "| unexpected:", bad)
