# ES PR #56 (PLANS.md step 2, standing rules): independent re-audit 10

Written 2026-11-25 by a read-only audit thread. This thread wrote no part of PR #56 and had not audited it before. Audit 08 was done by another thread. This thread did audit PR #55 earlier, in reports 02 and 04. Nothing was pushed, committed, commented on or merged.

**Verdict: ACCEPT.** A08-1 is closed: my own run of audit 08's deletion sweep catches all 134 moved paragraphs on the exact tip, and its output is byte-identical to the writer's. The repair changes one test file only. The merge of #57 is a plain merge that brought in exactly #57 and touched no moved text. The move is still byte-for-byte. Base and head give identical per-test results, and CI on the exact tip is green. No new blocking finding.

## INDEPENDENT AUDIT REPORT

**Repository / audit target**

- `evo-agi/Execution-Substrate`, draft PR #56, branch `claude/project-thread-kumrhu`.
- Topic commit `cf355c32e3b051d356016edb659e19d4c37be484`, tree `342aeda91924ecea881c4218b0a6200c912094df`. Since `8129b82` the branch has three commits:
  - `3c4130f`, the patch audit 08 audited;
  - `340f240`, the A08-1 repair;
  - `cf355c3`, a merge of `fd0529a`.
- Base `trunk_dev` `fd0529a206cf079b979129b6f533ea73dae9be17`, which is #57 on top of `8129b82`. At closeout, `git ls-remote` showed neither the base nor the PR branch had moved.
- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified with `sha256sum -c`).
- Canonical manifest SHA-256 `53ca4c367e64f56cdb715abac3eccb917dabc81578a3cdc64dae98119ffb1000`, textual diff SHA-256 `196ec2a80f3a0b4030ca85414f0755a92f781ed780d1160840fe2117dd983834`. 23 paths: 21 modified and 2 added (the two `.docs/standing_rules/` files). Saved as `10-audit-manifest.json`.

**Audit posture.** Read-only. Parent only, no subagents. I worked in fresh clones under `/opt/audit56`. Tests ran as a new unprivileged user `ci` under `env -i`, with the go.mod toolchain go1.26.5 copied to `/opt`, `GOTOOLCHAIN=local`, `GOFLAGS=-mod=readonly`, `GOPROXY=off`, `umask 022`, and signals reset to defaults.

Shared-folder writes:
- this report;
- `10-audit-manifest.json`;
- `10-audit-sweep-results.jsonl`;
- `10-audit-scripts-failures.json`.

**Provenance reproduction.** I followed §5.3 in a fresh clone: tip check, ancestry check, clean status including ignored files, `reset --mixed` to `fd0529a`, upstream `origin/trunk_dev`, then v2 twice into a fresh 0700 directory. `cmp` showed the runs identical. The output is byte-identical to the writer's `09-expected-manifest.json`. A closing run equals the opening one. No mode-bit differences.

**Coverage.**
- Reports 07, 08 and 09.
- `08-audit-sweep.py` (SHA-256 `a972036c…e582`, matches report 09), read before running it.
- The repair diff `3c4130f..340f240`.
- The merge `cf355c3` and #57's diff `8129b82..fd0529a`.
- The AGENTS.md and README changes, and both rule-file headers.
- Not re-inspected: the per-test repointing in the ~50 root and 5 `scripts/` tests that audit 08 reviewed at the literal level. Those bytes are unchanged, and the sweep below re-measures their effect.

## Checks the coordinator asked for

### 1. The move is still verbatim after the merge

- At `cf355c3`, these blobs equal `3c4130f`'s:
  - `PLANS.md`;
  - both rule files;
  - the record;
  - `AGENTS.md`;
  - `README.md`.
- #57 did not touch `PLANS.md`: `fd0529a:PLANS.md` equals `8129b82:PLANS.md`.
- I re-derived the files straight from git, independently of audit 08 and of the split script:
  - `execution_admission_and_custody.md` is a 20-line header followed by exactly `8129b82:PLANS.md` lines 1272–2125;
  - `remote_alpha_operator_routes.md` is a 17-line header followed by exactly lines 2461–4065;
  - the new `PLANS.md` is base lines 1–1271, then an 8-line pointer section, then 2127–2460, then an 8-line pointer section, then 4067–end.

### 2. The repair changes tests only

- `git diff --stat 3c4130f 340f240` shows only `plans_docs_contract_test.go`, with 81 insertions. It adds `TestStandingRulesPinEachOtherwiseUncheckedRule`, 15 rows with 1 to 3 phrases each, and each phrase must occur exactly once in its compacted file.
- I read every phrase. Each is a normative clause of its paragraph: a scope limit, a "must not" list, an authority bound or a refusal rule. None is a generic word.
- One limit is by design: the test catches deleting or duplicating a pinned phrase, not rewording a different clause of the same paragraph. The test's comment tells future rule edits to update the phrases.

### 3. The merge brought in nothing unexpected

- `cf355c3`'s parents are `340f240` and `fd0529a`. `git merge-tree --write-tree 340f240 fd0529a` gives `342aeda9…`, exactly the merge commit's tree. So the merge holds no hand edits and resolved no conflicts.
- Within PR #56's own diff, the changed lines of `git diff 8129b82 340f240` equal those of `git diff fd0529a cf355c3`, file by file (23 files each, 0 differences). The patch is unchanged by the merge.
- #57's diff covers 20 files: 4 docs, `.examples/config/nomad.hcl`, the bring-up runbook, 4 scripts, and es/app and scripts tests. It touches none of these:
  - `PLANS.md`, `AGENTS.md` or `README.md`;
  - the rule files or the record.

  None of its added lines names `PLANS.md`, `standing_rules`, P0i–P0v or R6J, so it adds no cross-reference that the move would leave stale. go.mod and go.sum are unchanged. #57 was audited and merged on its own track, and its content is outside this audit.

### 4. The 134 of 134 sweep, rerun by me

- I ran `08-audit-sweep.py` unmodified in head mode on a clean `cf355c3` checkout, as `ci`, from 01:35Z to 01:42Z. It caught **134 of 134** paragraphs: 43 in the admission file and 91 in the routes file. The clean rerun afterwards passed (`root=0 scripts=0`).
- 15 paragraphs fail only `TestStandingRulesPinEachOtherwiseUncheckedRule`. They are exactly the 15 that audit 08 recorded as uncaught on head (set equality against `08-audit-sweep-results.json`).
- No paragraph that audit 08 found caught lost or gained a failing test.
- My output file is **byte-identical** to the writer's `09-sweep-results.jsonl` (both SHA-256 `32f4562a…cc`): 134 of 134 paragraphs, with the same failing-test set for each.

### 5. `./scripts` failures, base against head

Packages run: `go test -count=1 -timeout 45m -json . ./internal/testutil ./internal/testtmpdir ./scripts`, the four packages whose tests read changed files (grep at `cf355c3` finds no other test package that reads `PLANS.md`, `standing_rules` or the record).

| Package | Base `fd0529a` | Head `cf355c3` |
|---|---|---|
| `.` | ok, 173 pass | ok, 175 pass (+`TestStandingRulesKeepPlansAuthority`, +`TestStandingRulesPinEachOtherwiseUncheckedRule`) |
| `./internal/testutil` | ok, 6 | ok, 6 |
| `./internal/testtmpdir` | ok, 5 | ok, 5 |
| `./scripts` | FAIL: 435 pass, 15 skip, 10 fail | FAIL: 435 pass, 15 skip, 10 fail |

- Over 2,947 base results, including subtests, the head has 0 verdict changes, 0 tests missing and 2 added.
- **The failing set is the same 10 tests on base and head** (listed in `10-audit-scripts-failures.json`). By their first error lines:
  - one needs macOS `/private/tmp`;
  - one finds the root-owned failure witness incomplete;
  - three do not reach the TLS-status staged-leaf boundary;
  - three fail inside the P0t Python bootstrap composition;
  - two need a test user with a supplementary group (the remote_alpha_upgrade_es tests).

  Inference: all 10 fail because of the container. The /private/tmp and supplementary-group failures are certain, and all 10 match on base and head and pass on CI.
- **The 30-versus-31 question.** My container fails 10, not 30 or 31: it has `ssh`, `uuidgen` and `acl` installed and a working Python path, so most of the earlier environment failures pass here. Audit 08 counted 30 at `8129b82` and the writer counted 31 at `fd0529a`, each in their own container. In both of those runs, as in mine, base and head match. Which test makes the one extra failure is **Unknown**, because audit 08 published counts, not names. My guess was #57's edit to `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`, but both upgrade tests also fail on `8129b82` in my container for the same supplementary-group reason, so I could not confirm it. The difference has no bearing on this PR: no run shows a base/head difference.

### 6. CI

- Run 45518046151, job 138882607365, check "build, vet and test", event `pull_request`, `head_sha` `cf355c32e3b051d356016edb659e19d4c37be484`. **Conclusion: success**, 00:26:23Z to 01:21:36Z (read through the GitHub API).
- Every step succeeded:
  - Build;
  - Vet, and Vet for macOS;
  - Check the test gate;
  - Test, 00:31:12Z to 01:03:39Z;
  - Listed tests still fail;
  - Listed tests pass as root.
- The base equals the head's second parent, so CI's merge commit has the head's tree. The PR is `mergeable_state: clean`.

### Build, vet and format

On the head as `ci`: `go vet . ./scripts` and `GOOS=darwin GOARCH=arm64 go vet . ./scripts` are clean. `gofmt -l` on the changed Go test files prints nothing.

## My own view of the patch

- **Authority.** I read the AGENTS.md §3 bullet, the §5 and §9 lines, both headers and the README line.
  - The rule files keep rank 2 through the "Additional rules" bullet. The numbered lines 1–5 are unchanged.
  - The folder sits outside the rank-3 and rank-4 globs, so nothing claims it at a lower rank.
  - This implements the coordinator's decision as written. The bullet and headers are pinned by `TestStandingRulesKeepPlansAuthority`, as audit 08 showed with mutants.
- **Read path.** §5 now tells agents to consult the rule file for the surface they change. `PLANS.md` keeps a pointer section where each block stood, and the owning contracts point at their file.
- **A08-2 stays open** (observation, optional): `PLANS.md`'s opening note lists the record but not `.docs/standing_rules/`. I agree with audit 08 that this is not needed for correctness. The coordinator limited the repair to tests, so it is the coordinator's call.

## Findings

No patch defects. These are observations only, with no correction required:

- **A10-1, test design (observation).** The new pins catch the deletion or duplication of a pinned clause, not a reword of another clause in the same paragraph. The rule files are rank-2 text edited by PR, so later rule edits will change these pins with them, as the test comment says.
- **A10-2, evidence gap (observation).** Audit 08 published `./scripts` failure counts but not names, so the 30-versus-31 difference cannot be attributed (see check 5). Recommendation for later audits: publish the failing-test names (as `10-audit-scripts-failures.json` does) so counts can be compared across containers.
- **Carried over, unchanged and pre-existing:**
  - A08-2, the opening note;
  - A08-3;
  - A05-3 and A05-4;
  - the two standing-rule sections still in `PLANS.md`;
  - the merge conflicts on branches `9slgp8` and `qhn13c`, with the resolution in the PR description.

## Validation assessment

- Re-run locally: the four affected packages on base and head, vet (linux and darwin/arm64), gofmt, and the full deletion sweep.
- Not re-run locally:
  - the other packages, which read no changed file;
  - root-only steps;
  - Nomad, Vault and SPIRE integration.

  CI ran all of these on the exact tip and passed.

## Sensitive-material handling

None read or written. The `ci` user was given a copy of the module cache, and no credentials.

## Remaining uncertainty

- The identity of the 31st `./scripts` failure in the writer's container (Unknown; it does not affect the verdict).

## Confidence

- Provenance: high.
- Validation: high (local base/head parity plus CI on the exact tip).
- Implementation: high for the move and the repair.

## Effect status

No repair, commit, push, PR comment or merge was performed.

**Final verdict: ACCEPT**
