"""Audit 08 paragraph-deletion sweep for ES PR #56. For each paragraph of the two
standing-rule files (head) or the same lines in PLANS.md (base), delete it, run the
root package and the scripts docs tests that read the moved text, and record whether
any test fails. Usage: python3 -I sweep56.py <clone> <base|head> <out.jsonl>"""
import json, os, subprocess, sys
WT, SIDE, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
SCRIPTS_RUN = "^(TestRemoteAlphaESServiceTLSStatusChildNamespaceDocumentsContract|TestRemoteAlphaESServiceTLSStatusProcessIdentityDocumentsContract|TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantDocumentsContract|TestRemoteAlphaOperatorP0qBootstrapExecutionContractIsImplementedNarrowly|TestRemoteAlphaESServiceTLSStatusFailureWitnessDocumentsContract)$"
HEAD_FILES = [(".docs/standing_rules/execution_admission_and_custody.md", 20, 1272),
              (".docs/standing_rules/remote_alpha_operator_routes.md", 17, 2461)]
def sh(*a): return subprocess.run(a, cwd=WT, capture_output=True, text=True)
def paras(path, hdr):
    L = open(os.path.join(WT, path)).read().split("\n")[:-1]
    out, cur = [], None
    for i, l in enumerate(L[hdr:], hdr + 1):
        if l.strip():
            cur = [i, i] if cur is None else [cur[0], i]
        elif cur: out.append(cur); cur = None
    if cur: out.append(cur)
    return out
assert sh("git", "status", "--porcelain").stdout == ""
# paragraph list always from head layout: read rule files from git object of head commit
items = []
for path, hdr, base_start in HEAD_FILES:
    if SIDE == "head":
        for a, b in paras(path, hdr): items.append((path, a, b, path, a, b))
    else:
        txt = sh("git", "show", "3c4130f:" + path).stdout
        tmp = os.path.join("/tmp", "sweep_" + os.path.basename(path)); open(tmp, "w").write(txt)
        L = txt.split("\n")[:-1]; cur = None; ps = []
        for i, l in enumerate(L[hdr:], hdr + 1):
            if l.strip(): cur = [i, i] if cur is None else [cur[0], i]
            elif cur: ps.append(cur); cur = None
        if cur: ps.append(cur)
        for a, b in ps: items.append((path, a, b, "PLANS.md", base_start + (a - hdr - 1), base_start + (b - hdr - 1)))
with open(OUT, "w") as out:
    for path, a, b, tgt, ta, tb in items:
        full = os.path.join(WT, tgt)
        L = open(full).read().split("\n")
        first = L[ta - 1]
        L2 = L[:ta - 1] + L[tb:]
        open(full, "w").write("\n".join(L2))
        sh("git", "add", "-A")
        r1 = sh("go", "test", "-count=1", ".")
        r2 = sh("go", "test", "-count=1", "-run", SCRIPTS_RUN, "./scripts")
        fails = sorted({l.split()[2] for l in (r1.stdout + r2.stdout).splitlines() if l.startswith("--- FAIL")})
        rec = {"file": path, "lines": [a, b], "target": tgt, "target_lines": [ta, tb], "first": first[:90],
               "caught": r1.returncode != 0 or r2.returncode != 0, "fails": fails}
        out.write(json.dumps(rec) + "\n"); out.flush()
        sh("git", "reset", "-q", "--hard", "HEAD"); sh("git", "clean", "-qfdx")
        assert sh("git", "status", "--porcelain").stdout == ""
r1 = sh("go", "test", "-count=1", "."); r2 = sh("go", "test", "-count=1", "-run", SCRIPTS_RUN, "./scripts")
open(OUT + ".done", "w").write(f"clean rerun root={r1.returncode} scripts={r2.returncode}\n")
