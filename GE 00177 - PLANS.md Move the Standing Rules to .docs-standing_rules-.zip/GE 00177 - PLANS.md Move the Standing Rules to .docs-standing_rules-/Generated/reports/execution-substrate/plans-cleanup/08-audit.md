# ES PR #56 (PLANS.md step 2, standing rules): independent audit 08

Written 2026-11-24 by a read-only audit thread. It wrote no part of PR #56; it audited PR #55 earlier (report 05). Nothing was pushed, committed, commented on or merged.

**Verdict: BLOCK, for one Low finding that already existed before this PR. The repair is mechanical and confined to tests.**

The patch's own bytes are correct:

- The two moves are byte-for-byte copies.
- The authority level is unchanged, and the read path is clear.
- Every test that pinned a moved rule now reads its new home. A deletion sweep over all 134 moved paragraphs shows coverage identical to base, paragraph for paragraph.
- The new fence logic closes A05-2.
- Base and head give identical per-test results, and CI is green.

The coordinator's question was whether the uncaught M3/M5 gap should close in this PR. I recommend yes, and I recommend closing it whole. M3 and M5 are 2 of **15** moved rule paragraphs that no test catches when they are deleted, on base and head alike (A08-1). The project fixes Low items in the PR, and leaving them for a later PR would rely on a follow-up that nothing enforces. The repair is one assertion per paragraph, after which the attached sweep must report every paragraph caught.

## INDEPENDENT AUDIT REPORT

**Repository / audit target**

- `evo-agi/Execution-Substrate`, draft PR #56, branch `claude/project-thread-kumrhu`.
- Topic commit `3c4130f307755b006cc379fde4215f255d33502e`, tree `0274d4a322c863eb3bf0c03b925ab174bba886d8`. It is one commit on the base.
- Base `trunk_dev` `8129b82d79b5700049621b6d4e95b6bf37ada7ac` (the #55 merge). At closeout, both `origin/trunk_dev` and the PR branch were unchanged.
- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified).
- Canonical manifest SHA-256 `4923dd5fb8571ac9e386c33820da4918f75b93f8d0ee6332dc26b07e0b15c447`, textual diff SHA-256 `56f7579bdeb90ef449c30eddaf1199ed006feb9b0dc408c19071ce740b45ba8b`, 23 paths (21 modified, 2 added).

**Audit posture**

- Read-only. Parent only, no subagents.
- Work ran in fresh clones under `/opt/audit`. Tests ran as an unprivileged `ci` user with Go 1.26.5, `GOTOOLCHAIN=local`, `GOFLAGS=-mod=readonly`, and no ignored signals.
- Shared-folder writes: this report, `08-audit-manifest.json`, `08-audit-mutants.py`, `08-audit-sweep.py` and `08-audit-sweep-results.json`.

**Provenance reproduction**

- I followed provenance §5.3 in a fresh clone: tip check, ancestry check, clean status including ignored files, `reset --mixed` to the base, upstream `origin/trunk_dev`, then v2 twice into a fresh 0700 directory.
- The two runs are identical (`cmp`), and byte-identical to the writer's `07-expected-manifest.json`.
- A closing run of the whole sequence equals the opening one. There were no mode-bit differences.

**Coverage**

- The full diff of all 23 files.
- `split_plans_2.py` (SHA-256 `64aaa125…4abd`, matches report 07), read before running it.
- Docs: AGENTS.md §3, §5 and §9; the README; both rule-file headers; both `PLANS.md` pointer sections; the two owning-contract pointers; the seven repointed cross-references; the testdata README.
- Tests: all Go test changes, including a literal-level check that no content phrase left the tests.
- Not inspected: product code (none changed).

## What I checked, and the result

### 1. The move is verbatim

- **The script reproduces the PR.** Run with `python3 -I` on 8129b82's `PLANS.md` (SHA-256 `937817d4…4dbc`), `split_plans_2.py` writes three files byte-identical (`cmp`) to the PR's:
  - `PLANS.md`: 145,045 bytes, `02b930ee…aae7`;
  - `execution_admission_and_custody.md`: 60,893 bytes, `24e091aa…da76`;
  - `remote_alpha_operator_routes.md`: 109,340 bytes, `71774781…3ae1`.
- **An independent check agrees.** I checked straight from git, without the script's own assertions:
  - The admission file ends with 8129b82 `PLANS.md` lines 1272–2125 exactly, after a 20-line header.
  - The routes file ends with lines 2461–4065 exactly, after a 17-line header.
  - The new `PLANS.md` equals base lines 1–1271, then the admission pointer, then 2127–2460, then the routes pointer, then 4067–4170.
- **Nothing else changed in the moved text.** The moved blocks contain no links, so none needed rebasing. The dated paragraphs, including the pinned R6J line, sit inside the moved admission file, as the coordinator required.

### 2. Authority level unchanged, read path clear

**Rank**

- AGENTS.md §3 numbered lines 1–5 are unchanged, and a new test pins line 2.
- A new "Additional rules" bullet gives `.docs/standing_rules/` the rank of `PLANS.md`, second, says only the location changed, and applies the rules above to them as to `PLANS.md`.
- The folder sits outside the rank-3 and rank-4 globs, so no numbered line claims it at a lower rank.
- No text in the tree ranks the files differently.

**Read path**

- AGENTS.md §5 now says to "consult the `.docs/standing_rules/` file that holds the rules of the surface you change", and §9 says to edit those files in place without dated entries.
- `PLANS.md` keeps a pointer section exactly where each block stood, naming the file, linking it and stating its authority.
- Each owning contract opens its section with a pointer (`contracts.md` §1, and remote_supported_host_alpha.md "Future ES-Owned Remote Alpha Operator Facade").
- The README lists both files. Each file header states its source, rank and editing rules.

**Cross-references**

- A scan of every tracked Markdown file found one line naming `PLANS.md` near an identifier that now lives only in a rule file: `outside_observer_protocol.md:6`. It refers to the reopened seams, which stayed in `PLANS.md`, so it is correct.
- The seven repointed cross-references name the file that now holds their text.

**One optional improvement (A08-2).** The opening note of `PLANS.md` still lists where the dated record went, but it does not mention `.docs/standing_rules/`.

### 3. The tests follow the rules and fail on deletion

**No phrase dropped.** I compared the string literals removed from and added to the Go tests. Every content phrase removed from one assertion was re-added in another. Only labels, paths, section markers, messages and the old fence regular expression left the tests.

Two section-marker changes:

- One section now ends at the end of the admission file, using `""`, which `testutil.Section` reads as end of document. Before, it ended at a paragraph in "Current paired-root custody and acceptance scope", which stayed in `PLANS.md`. The new section is a subset of the old one and still holds every asserted phrase.
- The other section now ends at "Tranche B1, …", the next paragraph in the admission file.

**Paragraph-deletion sweep (`08-audit-sweep.py`).** The sweep covers all 134 paragraphs of the two rule files: 43 in the admission file, including its one heading, and 91 in the routes file, including its three headings. On head, it deletes each paragraph from the rule file. On base, it deletes the same lines from 8129b82's `PLANS.md`. Each time it runs the whole root package plus the 5 `./scripts` docs tests that read the moved text, then resets.

| | Caught | Not caught |
|---|---|---|
| Base 8129b82 (`PLANS.md`) | 116 | 18 |
| Head 3c4130f (rule files) | 119 | 15 |

- **Every rule paragraph has the same result on base and head.**
- The only differences are the three route headings. Deleting them was not caught on base. On head, the section count in `TestStandingRulesKeepPlansAuthority` catches it.
- So no rule lost coverage in the move, and the 15 uncaught paragraphs were already uncaught before it (A08-1).
- The writer's caught mutants M1, M2, M4, M6 and M7 are among the caught paragraphs. M3 (B2 "Submit registration …") and M5 (Stage A opening) are among the 15.

**The R6J exception moved with its line and is narrow.** These mutants fail the status-entry guard:

- the line copied into `PLANS.md` (G07);
- a duplicate in the admission file (G06);
- an indented duplicate (G28);
- the line removed (G08).

Removing the line also fails `TestFoundationAcceptanceBoundaryDocumentation`, which uses it as a boundary.

### 4. Guards and layout (mutation test, `08-audit-mutants.py`)

All 28 targeted mutants fail the intended test in a clean ci-owned clone, reset after each:

| Mutants | Fails |
|---|---|
| G01 the exact A05-2 fence trick in `PLANS.md`; G02 the same in the admission file | NoDatedStatusEntries (A05-2 closed) |
| G03 status heading in the routes file; G04 dated heading in the admission file; G05 line opening with a date in the routes file | NoDatedStatusEntries |
| G06, G07, G08, G28 (the R6J line) | NoDatedStatusEntries (G08 also FoundationAcceptanceBoundaryDocumentation) |
| G09 +5,000 bytes on `PLANS.md` | StaysWithinItsSizeCap. The control G10, +4,900 bytes, passes, since the cap of 150,000 leaves 4,955 bytes |
| G11 a third file in the folder; G12 AGENTS.md "second" changed to "third"; G14 the §5 line removed; G15 the §9 line removed | StandingRulesKeepPlansAuthority |
| G13 AGENTS.md line 2 changed | StandingRulesKeepPlansAuthority plus 7 existing hierarchy-copy tests |
| G16 `PLANS.md` pointer link removed; G17 a pointer's authority sentence removed; G18 a header's authority sentence weakened | StandingRulesKeepPlansAuthority |
| G19, G20 owning-contract pointers removed; G21 README link removed | StandingRulesKeepPlansAuthority |
| G22 the R6J heading copied back into `PLANS.md`; G23 a fourth section in the routes file | StandingRulesKeepPlansAuthority |
| G24 a line citation of a rule file | IsCitedBySectionNotLine |
| G25, G26, G27 refused phrases added to the rule files (Tranche B gate, final-audit claim, stale target relationship) | the widened negative checks (RetireAllSelectedEvidenceCompatibility, FinalAuditRepairContract, HybridIntegrationArchitectureADRDocsContract) |

The two limit probes behave as expected:

- L1, "On 2026-11-25, …": a known scope limit (A04-1).
- L2, an unclosed fence before a heading: CommonMark treats the rest of the document as code, so passing is correct.

The fence code reads a fence closing exactly as CommonMark does: same character, at least as long as the opener, nothing after it. It also refuses backtick openers whose info string holds a backtick. The eight new self-test cases cover this.

### 5. Tests on the exact head

I ran clean checkouts of 8129b82 and 3c4130f as user `ci`, with `go test -count=1 -timeout 45m -json . ./internal/testutil ./internal/testtmpdir ./scripts`. These are the four packages whose tests read changed files. Elsewhere, es/admission and es/app only name the changed docs in comments.

| Package | Base (top-level tests) | Head (top-level tests) |
|---|---|---|
| `.` | ok: 173 pass | ok: 174 pass. The extra test is `TestStandingRulesKeepPlansAuthority` |
| `./internal/testutil` | ok: 6 | ok: 6 |
| `./internal/testtmpdir` | ok: 5 | ok: 5 |
| `./scripts` | FAIL: 415 pass, 15 skip, 30 fail | FAIL: 415 pass, 15 skip, 30 fail |

- **Per-test comparison.** Over 2,944 base results, including subtests, the head has 0 verdict changes, 0 tests missing and 1 test added.
- **The local `./scripts` failures match base.** The 30 failing tests are the same set on base and head, and the 10 `./scripts` docs tests pass on both.
  - The writer reported 38 failures because they ran as root. As non-root, 8 of those pass on both trees, since they expect a non-root owner, so my run covers more.
  - Inference: the 30 fail because of container limits. None is on CI's environment-only list.
- **Build and vet.** `go build ./...`, `go vet ./...` and `GOOS=darwin GOARCH=arm64 go vet ./...` are clean on the head, and `gofmt -l` on the changed Go files prints nothing.
- **CI.** Run 45499148423 ([link](https://github.com/evo-agi/Execution-Substrate/actions/runs/45499148423)), event `pull_request`, `head_sha` `3c4130f307755b006cc379fde4215f255d33502e`, conclusion `success`, 22:15:09Z to 22:58:16Z, read through the GitHub API. Base and trunk_dev are the same commit, so the merge commit CI tested has the head's tree.

## Findings

```text
AUDIT FINDING
ID / Type / Severity: A08-1 / test gap / low
Current contract or strategic target: the coordinator's condition for this step, "the tests follow the rules and still fail when a rule is removed"; AGENTS.md §3 now gives these files PLANS.md's rank.
Path and line / Evidence: deleting any one of these 15 paragraphs fails no test, at 3c4130f and, for the same lines in PLANS.md, at 8129b82 (08-audit-sweep-results.json):
  execution_admission_and_custody.md (lines at 3c4130f):
    23-29    "The independently accepted R9.28 owner is bounded artifact-design evidence" (M5)
    132-142  "**Current invariant:** real artifact, capability, target, runtime-profile, …"
    391-406  "**Review-09 PROOF-EVIDENCE-01 bounded proof-artifact refinement:** …"
    742-749  "Submit registration, projected-allocation list, and allocation-detail JSON use …" (M3)
    751-769  "`preparedAdmission` carries the private formatter marker as its first anonymous …"
  remote_alpha_operator_routes.md:
    607-616  "P0q bootstrap configures expected Vault objects only. …"
    673-688  "`Bounded slice rule` failure-visibility refinement within this reopened seam: …"
    906-919  "`Bounded slice rule`: the root-run Python collector has only two immutable, …"
    921-933  "`Bounded slice rule` audit repair: a related configuration used for a fixed …"
    984-989  "The protected status contract is …"
    1246-1252 "Legacy `/var/tmp/execution-substrate-remote-alpha/*tls*summary*.json`, old …"
    1267-1283 "`Temporary compatibility edge`: the new Mac facade form accepts only the …"
    1470-1480 "P0u summaries are evidence/projection only. …"
    1506-1510 "P0u remains bounded ES Remote Alpha proof/support workflow glue only. …"
    1617-1622 "Bridge/MA/CP/IM consumers must not wrap missing ES prerequisites into ES status …"
  A rough 8-word-window search found most of these restated in no owning doc.
Impact: rank-2 rules can be deleted, for example in a broad edit of a section, and no test notices. The move does not change this, but the move is where the files' rank and the claim that "tests follow the rules" are being set.
Required correction (repair scope; docs and tests only; no rule text changes):
  - Pin each of the 15 paragraphs with at least one phrase unique to it, asserted on its rule file. Use either the existing test for that surface or a table-driven test.
  - Then rerun 08-audit-sweep.py on the repaired head. Every paragraph must be caught, the per-test results must otherwise match, and the manifest must be retaken.
  - Closing only M3 and M5 would leave 13 identical gaps, so it is not recommended.
Uncertainty: low (each case reproduced on both trees). Whether some owning contract states a rule in different words was not checked; that would not change the fix.
Patch defect or pre-existing issue: pre-existing, identical on base. Blocking only because the project fixes Low items in the PR, and because a follow-up PR has no machine-enforced trigger.
```

```text
AUDIT FINDING
ID / Type / Severity: A08-2 / doc gap (read path) / observation
Path and line / Evidence: PLANS.md's opening note ("This file holds the current plan … every change starts by reading it", then "How this file is kept") names where the dated record went, but not `.docs/standing_rules/`. The read path is still clear: AGENTS.md §5, the in-place pointer sections, the owning-contract pointers and the README.
Required correction: none. Optional while repairing A08-1: one sentence in the note naming the two rule files and their rank, pinned in TestPlansOpensWithTheCurrentPlan.
Patch defect or pre-existing issue: patch (an omission), not misleading.
```

```text
AUDIT FINDING
ID / Type / Severity: A08-3 / doc note / observation
Path and line / Evidence: 11 docs copy AGENTS.md hierarchy line 2 ("`PLANS.md` for allowed redesign work, …") verbatim, under test. They do not mention `.docs/standing_rules/`. The AGENTS.md "Additional rules" bullet governs, and AGENTS.md is rank 1.
Required correction: none. Changing the copies would break the copy test for no gain.
Patch defect or pre-existing issue: consequence of the chosen design, not a defect.
```

**Merge-gate notes**

- **Branch `claude/project-thread-9slgp8` (Nomad part 2b, at 3ef8a75).** It edits `PLANS.md` in the pre-#55 layout: one hunk is in the Nomad Status entry, which is now in the SHA-pinned record, and one is in a current list. Its edits have to be re-applied in place. The cap leaves 4,955 bytes of headroom.
- **Branch `claude/project-thread-qhn13c`.** It adds one bullet, which stays in `PLANS.md`.
- **Other branches.** Any branch that edits the P0i–P0v or R6J text must re-apply its edit in the rule file.

## Validation assessment

- **Re-run:** both provenance runs, the split script, my own byte check, 28 targeted mutants plus 2 limit probes, the 268-run deletion sweep, the package runs above, build, vet and gofmt.
- **Not re-run locally:** packages whose tests read no changed file, and the root-only `./scripts` step. CI ran all of these on 3c4130f.

## Sensitive-material handling

None read or written.

## Remaining uncertainty and stop conditions

- Whether owning contracts restate the 15 uncaught rules in other words. This does not affect A08-1's fix.
- No stop condition was hit.

## Confidence

- Provenance: high.
- Validation: high, from identical base and head results plus green CI.
- Implementation of the move: high.
- Rule-deletion coverage: complete for every rule tested before the move, with 15 known paragraphs open (A08-1).

## Effect status

No repair, commit, push, PR comment or merge was performed.

## Report delivery

`/mnt/project-files/reports/execution-substrate/plans-cleanup/08-audit.md`. Its SHA-256 is given in the thread reply.

**Final verdict: BLOCK** (one Low, pre-existing, mechanical test-only repair; the move itself is accepted as correct)
