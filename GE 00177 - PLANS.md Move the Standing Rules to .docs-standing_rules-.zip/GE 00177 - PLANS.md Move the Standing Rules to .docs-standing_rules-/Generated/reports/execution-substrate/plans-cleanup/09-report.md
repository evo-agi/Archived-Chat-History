# ES PLANS.md cleanup: thread report 09 (repair of audit 08)

Status: repaired and pushed. Waiting for a fresh audit. Written 2026-11-25 by the writer thread. This report replaces report 07 as the current report. Everything in report 07 still holds except where this report says otherwise.

## Target

- Repo: `evo-agi/Execution-Substrate`, draft PR #56 (https://github.com/evo-agi/Execution-Substrate/pull/56), branch `claude/project-thread-kumrhu`.
- Base: `trunk_dev` `fd0529a206cf079b979129b6f533ea73dae9be17`. `trunk_dev` moved during the repair: #57 (Nomad host network) merged on top of `8129b82`.
- Tip: `cf355c32e3b051d356016edb659e19d4c37be484`, tree `342aeda91924ecea881c4218b0a6200c912094df`. The branch holds three commits on `8129b82`:
  - `3c4130f`, the patch audit 08 audited;
  - `340f240`, this repair;
  - `cf355c3`, a merge of `fd0529a` into the branch. It is a plain merge, with no rebase and no conflicts.
- Expected v2 manifest against `fd0529a` (`09-expected-manifest.json`, beside this report):
  - canonical SHA-256 `53ca4c367e64f56cdb715abac3eccb917dabc81578a3cdc64dae98119ffb1000`;
  - textual diff SHA-256 `196ec2a80f3a0b4030ca85414f0755a92f781ed780d1160840fe2117dd983834`;
  - 23 files, the same paths as in 07.

  It was taken exactly as provenance §5.3 describes, in a fresh clone: recipe hash verified, tip and ancestry checked, `reset --mixed` to the base, upstream `origin/trunk_dev`, two runs, `cmp` identical.
- **What changed since the 07 manifest.** Four entries differ:
  - `plans_docs_contract_test.go`, which is this repair;
  - three docs that #57 also edited: `supported_local_cp_consumer_runbook.md`, `remote_supported_host_alpha.md` and `supported_linux_host_qualification.md`. Their bytes now include #57's lines.
- **The patch itself is unchanged.** The changed lines of `git diff 8129b82 340f240` equal those of `git diff fd0529a cf355c3`, file by file. #57 did not touch `PLANS.md` or the rule files, so `split_plans_2.py` still reproduces all three byte for byte. A manifest of `340f240` against `8129b82`, taken before the merge, is `834dd7ba…1dd8`.

## Repair

| Finding | Repair |
|---|---|
| **A08-1** (blocking, Low, pre-existing) | Fixed. See below. |
| **A08-2** (observation, optional) | Not done. The coordinator's instruction was "Change tests only", and A08-2 would change `PLANS.md`'s opening note. The read path stays clear, as audit 08 found. |
| **A08-3** (observation) | No change, as the audit recommends. |

**A08-1.** The new test `TestStandingRulesPinEachOtherwiseUncheckedRule` is in `plans_docs_contract_test.go`, after `TestStandingRulesKeepPlansAuthority`. It has one row for each of the 15 paragraphs audit 08 listed. Each row names the rule and pins one to three phrases that state it, mostly the normative clause.

- Each phrase must occur exactly once in its compacted file. So deleting the paragraph fails the test, and so does duplicating a pinned phrase.
- The first draft pinned "The workload-auth check remains a separate post-bootstrap command." for P0q. The exactly-once check refused it, because the sentence occurs twice. It was replaced with the longer claim-limit sentence that ends with it, which occurs once.
- The rule text is unchanged. Only this one Go file changed.

The rows, by audit 08's line numbers at `3c4130f` (unchanged at `340f240`):

| File | Lines | Row name |
|---|---|---|
| admission | 23–29 | Stage A slice scope (M5) |
| admission | 132–142 | B1 current invariant |
| admission | 391–406 | Review-09 proof-artifact collection |
| admission | 742–749 | B2 provider response limits (M3) |
| admission | 751–769 | B2 preparedAdmission redaction and assurance |
| routes | 607–616 | P0q bootstrap effects |
| routes | 673–688 | P0s/P0t failure witness |
| routes | 906–919 | P0s/P0t collector scope tables |
| routes | 921–933 | P0s/P0t related configuration states |
| routes | 984–989 | P0s/P0t protected status directories |
| routes | 1246–1252 | P0s/P0t legacy summaries |
| routes | 1267–1283 | P0t diagnostic Mac facade |
| routes | 1470–1480 | P0u summary contents |
| routes | 1506–1510 | P0u authority bounds |
| routes | 1617–1622 | P0v cross-repo consumers |

## Deletion sweep

- **Audit 08's own script.** `08-audit-sweep.py` (SHA-256 `a972036c7bbfe363718c5df1a797fbc42990d4c7936f7762d29442908ba1e582`, run unmodified) on `340f240`, as an unprivileged user `ci` under `env -i`. All 134 paragraphs are caught: 43 in the admission file and 91 in the routes file. Each of the 15 is caught by `TestStandingRulesPinEachOtherwiseUncheckedRule`. Every paragraph that audit 08 found caught still fails each test that audit 08 recorded for it. The clean rerun afterwards passed (`root=0 scripts=0`). The results are in `09-sweep-results.jsonl` beside this report (SHA-256 `32f4562a2b570d27c48b13f82085ab5a175bf1dda6582595b135b805e42049cc`).
- **A faster equivalent first.** Before that, I iterated with an equivalent sweep. It used the same paragraph list and the same tests, but ran test binaries compiled once from the worktree. That works because the docs tests read the files at run time. Result: 134 of 134 paragraphs caught. Each of the 15 is caught by `TestStandingRulesPinEachOtherwiseUncheckedRule`. No paragraph that audit 08 found caught lost any of the failing tests audit 08 recorded for it. The clean rerun afterwards passed.
- **On the merged tip.** The merge changed no rule file and no test that reads one. I still re-ran the fast sweep on `cf355c3`. It caught 134 of 134, and every paragraph's failing tests are the same as in the audit-script run on `340f240`.

## Validation

Runs were on committed bytes in the cloud container with Go 1.26.5. Each run was made as an unprivileged user `ci` under `env -i`, with `go test -count=1 -json . ./internal/testutil ./internal/testtmpdir ./scripts`.

**Merged tip against the new base.** Base `fd0529a`, head `cf355c3`:

| Package | Base | Head |
|---|---|---|
| `.` | 173 top-level tests pass | 175 pass |
| `./internal/testutil` | ok | ok |
| `./internal/testtmpdir` | ok | ok |
| `./scripts` | 414 pass, 15 skip, 31 fail | 414 pass, 15 skip, 31 fail |

- The two added root tests are `TestStandingRulesKeepPlansAuthority` and `TestStandingRulesPinEachOtherwiseUncheckedRule`.
- Over 2,947 base results, including subtests, there are 0 verdict changes, 0 missing and 2 added.

**Repair alone, before the merge.** The same comparison, base `8129b82` against head `340f240`, gave the same counts: 0 verdict changes, 0 missing, and 2 added root tests.

**The 31 `./scripts` failures:**

- Audit 08 counted 30. One more fails here, on every tree alike. I can't tell which one without audit 08's list.
- Report 07's figure of 38 came from running as root, as audit 08 noted.
- A first `ci` run before the merge used `su` with a narrow PATH that left out `/usr/local/bin/python3`. It gave 111 failures, also identical on base and head. The `env -i` runs above replace it.

**Vet and format.** On the merged tip, `go vet . ./scripts` is clean. On `340f240`, `GOOS=darwin GOARCH=arm64 go vet .` is clean, and only test files changed after that. `gofmt -l plans_docs_contract_test.go` prints nothing.

**CI.** "build, vet and test" on `cf355c3` passed: run 45518046151, 00:26:23Z to 01:21:36Z. Every step succeeded, including "Listed tests still fail" and "Listed tests pass as root". The run on `340f240` (45514728545) was cancelled when the merge was pushed, because the workflow keeps one run per branch.

## Open items

These are unchanged from report 07:

- **Standing rules still in `PLANS.md`.** "Current paired-root custody and acceptance scope" and "Remote Alpha access contract v1 — Tranche A" are still there, out of scope.
- **Audit 05 observations.** A05-3 and A05-4 are pre-existing and still open.
- **Branch conflicts.** Branches 9slgp8 and qhn13c will conflict, with the resolution given in the PR description. Audit 08's merge-gate notes add that part 2b's Nomad Status hunk now lives in the SHA-pinned record and has to be re-applied in place.
- **Naming.** The new names are still easy to change.

New in this report:

- **A08-2 not done.** One sentence in `PLANS.md`'s opening note naming the two rule files would close it. It needs a docs change, so it waits for the coordinator's word.

## Confidence

- Provenance: high. The double manifest run matches, and the doc bytes are unchanged from 07.
- Rule-deletion coverage: complete for the 134 moved paragraphs, as measured by audit 08's sweep.
- Validation: high for the packages run. CI covers the rest.
