# ES PLANS.md cleanup: thread report 07 (step 2, standing rules)

Status: draft PR open and waiting for a fresh audit. Written 2026-11-24 by the writer thread.

## Target

- Repo: `evo-agi/Execution-Substrate`, draft PR #56 (https://github.com/evo-agi/Execution-Substrate/pull/56), branch `claude/project-thread-kumrhu`.
- Base: `trunk_dev` `8129b82d79b5700049621b6d4e95b6bf37ada7ac` (the #55 merge).
- Tip: `3c4130f307755b006cc379fde4215f255d33502e`, tree `0274d4a322c863eb3bf0c03b925ab174bba886d8`. It is one commit on the base.
- Expected v2 manifest (`07-expected-manifest.json`, beside this report):
  - canonical SHA-256 `4923dd5fb8571ac9e386c33820da4918f75b93f8d0ee6332dc26b07e0b15c447`;
  - textual diff SHA-256 `56f7579bdeb90ef449c30eddaf1199ed006feb9b0dc408c19071ce740b45ba8b`;
  - 23 files.

  It was taken in a fresh clone exactly as provenance §5.3 describes: recipe hash verified, `reset --mixed` to the base, upstream `origin/trunk_dev`, two runs, `cmp` identical.
- Split script: `split_plans_2.py` (beside this report, SHA-256 `64aaa12500ee96e9f1ed127bbd2713f6cc5e55b5a7bb551b41d5e2c7ee704abd`).
  - It refuses any `PLANS.md` other than 8129b82's (SHA-256 `937817d4…4dbc`).
  - It asserts every boundary line, and that each block holds exactly its own headings and no link.
  - It runs a multiset check over every non-blank line, and checks that each moved block is a contiguous, byte-identical copy that no longer appears in `PLANS.md`.
  - Run on 8129b82's `PLANS.md`, it reproduces the tip's `PLANS.md` and both rule files byte for byte (checked).

## Brief and decision

The coordinator's decision for this step (21:41Z) was:

1. Move the P0i–P0v route rules verbatim into their owning contract, at the same authority level.
2. Append the R6J review history to the closed record.
3. Fold in the A05-2 fence guard and lower the cap.

Item 2's premise did not hold. Reading the whole section (8129b82 lines 1272–2125, 59,827 bytes) showed that it is the standing Workstream C admission and custody rule set, not history:

- 10 labeled rules;
- the static-script, sparse, material and custody limits;
- B1, B2 and Tranche A;
- the recent startup-probe rules NESTED-STAGING-OWNER-PROBE-01 and STARTUP-PROBE-USE-AGREEMENT-01.

Only about 6 to 10 KB is dated evidence, and that carries current limits too. I recommended treating it like P0i–P0v. The coordinator agreed (21:43Z), with four conditions:

- a verbatim move, asserted by the script;
- the tests follow the rules and still fail when a rule is removed;
- the AGENTS.md rank rule is pinned by a test;
- the dated paragraphs stay inside the moved file.

All four are met (see below). The record is unchanged and its SHA pin still holds.

## What moved

| From 8129b82 `PLANS.md` | To | Bytes |
|---|---|---|
| lines 1272–2125, "R6J-R9.28/Stage-A — inert outside-observer structural contract" (under "Cross-Repo Hybrid Integration ADR Pointer") | `.docs/standing_rules/execution_admission_and_custody.md` | 60,893 (header included) |
| lines 2461–4065, the three P0i–P0m, P0o–P0q and P0s–P0v sections (under "Highest-Priority Backlog Entry") | `.docs/standing_rules/remote_alpha_operator_routes.md` | 109,340 (header included) |

`PLANS.md` went from 312,592 to 145,045 bytes (4,170 to 1,725 lines).

Each rule file opens with a header. It names the source section and commit, says the text moved unreworded, and states the rank. It also says to edit in place without dated entries and to cite by heading. The admission file's header adds that some paragraphs still carry their review names and dates, unreworded.

`PLANS.md` keeps a short pointer section in place of each block:

- "### Workstream C admission and custody rules";
- "### Remote Alpha operator facade route rules (P0i to P0v)".

Each pointer is a heading plus a link and one sentence saying the file keeps this file's authority. The P0 pointer has its own heading so that it does not sit under the "Historical P0g" heading.

## Authority

The level is unchanged; only the location changed.

- **AGENTS.md section 3** gains one "Additional rules" bullet: the files in `.docs/standing_rules/` hold standing rules that moved unreworded out of `PLANS.md`; they keep `PLANS.md`'s authority, second in the list above; only their location changed; and the rules above apply to them as they apply to `PLANS.md`.
- **Numbered lines 1 to 5** are unchanged, because 11 docs copy them verbatim and a test enforces the copies. A new test also pins line 2.
- **Read obligation.** The rules are no longer in the file every change reads first. To compensate, AGENTS.md section 5 adds "consult the `.docs/standing_rules/` file that holds the rules of the surface you change". Section 9 adds "update the `.docs/standing_rules/` file in place when a standing rule it holds changed, also without a dated status entry". Flagged for the auditor: this is a change of read path, not of rank.
- **File location.** The files sit in their own folder, outside `.docs/system_overview/*` (rank 3) and `.docs/execution_lifecycle/*` (rank 4). That way no glob in the numbered list claims them at a lower rank.

## Pointers and cross-references

- The owning contracts now point at their file:
  - `.docs/execution_lifecycle/contracts.md` §1;
  - `.docs/system_overview/remote_supported_host_alpha.md`, at the top of "Future ES-Owned Remote Alpha Operator Facade".

  Each says that `AGENTS.md` section 3 ranks the file with `PLANS.md` and that the doc holds the detailed contract.
- README "Supporting references" lists both files.
- Seven cross-references named `PLANS.md` for text that moved. Each now names `.docs/standing_rules/execution_admission_and_custody.md`:
  - contracts.md, "Development-source foundation and acceptance boundaries" (the 2026-11-13 disposition);
  - implementation.md §1 (development evidence and rollout boundaries);
  - es_execution_admission_model.md (development-source and local-preservation distinction);
  - supported_local_cp_consumer_runbook.md §2;
  - capability_probing.md, in two places (the disposition, and the "source and evidence limits");
  - supported_linux_host_qualification.md (the acceptance and local-commit split).
- `testdata/remote_alpha_es_tls_status/README.md` now names the route rules file for the six coupled P0t verification alternatives.
- Left as they were, because the text they mean stayed in `PLANS.md`:
  - remote_supported_host_alpha.md "Current Remote Alpha root-custody observation gate" ("under `PLANS.md`"), since "Current paired-root custody and acceptance scope" stayed;
  - contracts.md's "See `PLANS.md` under 'Current paired-root custody and acceptance scope'";
  - outside_observer_protocol.md §1 ("reopened … seams in `PLANS.md`"), since the seam list stayed in the ADR pointer.
- **ADR pointer.** The brief said "PLANS.md and the ADR keep one-line pointers". The ADR file (`.docs/system_overview/hybrid_integration_architecture_adr.md`) never named the R6J text, so the pointer went into `PLANS.md`'s "Cross-Repo Hybrid Integration ADR Pointer" section, where the text stood. Flagged in case the ADR file itself was meant.

## Tests

- **Following the rules.** Every test that pinned moved text now reads the file that holds it. That is about 50 root tests and 5 in `scripts/`.
  - Mixed checks were split into one assertion per file, by a tool that classifies each phrase by where it occurs.
  - A phrase found in both places stays asserted in both. No assertion was dropped.
  - Seven Remote Alpha tests (P0i, P0j, P0o, P0p, P0q, P0u, P0v) were left with a one-phrase PLANS.md assertion of a generic word ("CP proof", "role `service_execution`", and so on). The real match was the moved rule. Each such phrase is still asserted on the rule file, and the PLANS.md copy of the assertion was removed.
  - Sections whose markers moved now read the rule file. For example, the "Acceptance boundaries" section now ends at "Tranche B1, …", the next paragraph in its file, and holds all its phrases.
- **Negative checks.** Five checks refused phrases in `PLANS.md` text that included moved rules. Each now also reads the rule files: final-audit claims, the Tranche B gate, Bridge handoff agreement, and stale target relationships (two checks). Whole-root cleanup vocabulary reads PLANS.md plus the admission rules. One check I first widened ("cross-reference overlay independence") reads a `PLANS.md` section that did not move, so it was restored to its original scope.
- **Guards** (`plans_docs_contract_test.go`):
  - **Fence guard (A05-2).** A fence closes only on a line of the same character, at least as long as the opening run, with nothing after it. A backtick fence whose info string holds a backtick is not a fence, and an unclosed fence runs to the end. Eight new self-test cases cover this. The old logic fails five of them, including the exact A05-2 case "````/```/````/## Status".
  - **Status-entry guard.** It now reads `PLANS.md` and both rule files. The one pinned dated line ("**2026-11-13 Review-22 development-source disposition:**") moved with its file, and the exception list is now keyed by file.
  - **Line-citation guard.** It also refuses line citations of `standing_rules/*.md`, with three new self-test cases.
  - **Size cap.** It drops from 320,000 to 150,000 bytes, leaving 4,955 bytes of headroom.
  - **Layout test.** The new `TestStandingRulesKeepPlansAuthority` pins:
    - the AGENTS.md rule, and AGENTS.md sections 5 and 9;
    - that authority line 2 is unchanged;
    - each header;
    - each `PLANS.md` pointer section and its link;
    - each owning-contract pointer;
    - the README links;
    - that the folder holds exactly the two files;
    - that each file has exactly the sections that moved (1 and 3);
    - that no heading sits in both a rule file and `PLANS.md`.

## Validation

All runs were on the committed tree at `3c4130f` (git status clean), in the cloud container with Go 1.26.5.

- `go test -count=1 .`: ok. `./internal/testutil`: ok. `./internal/testtmpdir` (reads capability_probing.md): ok.
- `go test -count=1 ./scripts -run '<the 9 docs tests that read PLANS.md>'`: ok.
- `go vet . ./scripts` and `GOOS=darwin GOARCH=arm64 go vet . ./scripts`: clean. `gofmt -l` on the changed Go files: clean.
- Full `./scripts`, run alone: 38 of the 460 top-level tests fail, and the rest pass or skip themselves. The 38 are the same 38, by name, when run on base `8129b82`. All 38 are runtime tests, and they fail here because of the container, not this diff: the firewall real-kernel tests need `ip`; the TLS status, P0t/P0v facade, recovery-session and Vault service-user migration tests need `ssh`, `scp` and a fixed Python path, or expect a non-root owner (the run is as root). This PR changes no script and no runtime test.
- CI "build, vet and test" on `3c4130f`: success (run 45499148423, 22:15:13Z to 22:58:15Z), including the "Listed tests still fail" and "Listed tests pass as root" steps. The PR is mergeable (clean).

Mutants ran in a separate worktree, reset after each. Each was caught by the intended test:

- **Rule removed from a rule file** (M1, M2, M4, M6, M7):
  - the Review-06 mount rule;
  - the "Bounded material and custody rules" paragraph;
  - the Tranche A list;
  - the P0k slice paragraph;
  - the P0v slice paragraph.
- **Guards** (M8–M11, M19):
  - a dated line in the admission rules;
  - a status heading in the route rules;
  - the A05-2 hidden heading in `PLANS.md`;
  - +6,000 bytes on `PLANS.md`;
  - the pinned dated line removed (the stale-exception check fired).
- **Layout** (M12, M13, M15, M18, M20):
  - the AGENTS.md rank rule reworded;
  - a third file in the folder;
  - a moved heading added back to `PLANS.md`;
  - the contracts pointer broken;
  - a header's authority sentence removed.
- **Citation** (M14): a line citation of a rule file.
- **Negative checks** (M16, M17): a refused Tranche B gate phrase added to the admission rules, and a refused "commit-ready" phrase added to the route rules.

Two removals are not caught: the B2 "Submit registration …" paragraph and the Stage A opening paragraph. The same removals from 8129b82's `PLANS.md` are not caught by the root tests either. These are coverage gaps that already existed, not losses from the move.

## Open items

- **Standing rules still in `PLANS.md`.** "Current paired-root custody and acceptance scope" (about 15.6 KB, under the ADR pointer) and "Remote Alpha access contract v1 — Tranche A" (about 6.5 KB) are standing rules too. They were outside this step's scope.
- **Audit 05 observations.** A05-1 is moot now that this PR moves rules rather than history. A05-3 (the P0o record assertion that is frozen true) and A05-4 (the plan tables in reliable_submit_operational_handoff.md and reliable_submit_persistence_and_concurrency.md that list `PLANS.md` for source status) are unchanged and pre-existing. A05-4's tables now also have a rule file that could be named.
- **Branch conflicts.** Branches 9slgp8 (part 2b) and qhn13c will conflict on `PLANS.md`. The PR description says how to resolve them, and the part 2b thread was told about #55's layout earlier.
- **Naming.** The folder name `standing_rules`, both file names and the two pointer headings are new names and easy to change.

Confidence:

- Provenance: high (script reproduction plus the double manifest run).
- Repointing completeness: high for positive checks, because every phrase that existed only in the moved text failed and was fixed. Medium-high for negative checks, which were found by a scan for checks on PLANS-derived text and by a scan for sections that spanned a moved block.
- Validation: high for the packages run; CI is the check for the rest.
