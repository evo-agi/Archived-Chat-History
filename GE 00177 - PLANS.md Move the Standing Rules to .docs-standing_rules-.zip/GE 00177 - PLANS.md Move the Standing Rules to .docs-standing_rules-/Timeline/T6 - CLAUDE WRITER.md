Step 2 of the PLANS.md cleanup is up as [draft PR #56](https://github.com/evo-agi/Execution-Substrate/pull/56), and CI is green. It's now waiting for a fresh audit.

PLANS.md went from 312,592 bytes to 145,045. Two blocks of standing rules moved word for word into `.docs/standing_rules/`:
- the Workstream C admission and custody rules;
- the Remote Alpha route rules P0i to P0v.

A new AGENTS.md rule gives that folder the same authority as PLANS.md, and a test pins that rule. About 55 tests now read the new files. I deleted 20 rules one at a time as a check, and the tests caught 18 of them. The 2 they missed also go uncaught on trunk_dev today.

The fence-guard fix from the last audit is included, and the size cap is down to 150,000 bytes. Details are in [07-report.md](/mnt/project-files/reports/execution-substrate/plans-cleanup/07-report.md).

STATUS: PR #56 draft, CI green, waiting for a fresh audit, then the merge gate.
