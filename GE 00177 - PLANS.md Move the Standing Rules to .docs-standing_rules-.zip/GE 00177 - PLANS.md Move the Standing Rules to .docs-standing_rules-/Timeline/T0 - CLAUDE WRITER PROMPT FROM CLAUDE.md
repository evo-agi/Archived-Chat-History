Coordinator decision for the next PLANS.md step: plans should hold intent and order, not standing rules.
(1) The P0i–P0v route rules (~100 KB) move verbatim into the owning contract doc for those routes. Use the Remote Alpha doc if it already owns them, or a new .docs file it references, and add a test that pins the new location. PLANS.md keeps a short pointer and the decision rules only. AGENTS.md's authority list must name the new owner, so the authority level stays the same and only its location changes; state that explicitly.
(2) The ADR pointer's R6J review history (~60 KB) is history: append it to the closed record, re-pinning its SHA. PLANS.md and the ADR keep one-line pointers.
(3) Fold in the A05-2 fence guard and lower the size cap to just above the new size.
Same gate as before: writer's report, then a fresh read-only audit, then the merge gate. Opus only.
