Sounds good. It's in the backlog as approved and not urgent, to start after PR 56 merges.

STATUS: WORKING (audits of PR 56 and the Wi-Fi fix, PR 57)
