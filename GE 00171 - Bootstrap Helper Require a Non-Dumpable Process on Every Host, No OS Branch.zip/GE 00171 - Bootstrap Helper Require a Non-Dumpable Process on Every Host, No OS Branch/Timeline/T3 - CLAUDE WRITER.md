I opened [PR #51](https://github.com/evo-agi/Execution-Substrate/pull/51) for the Codex finding. It's ready for review and with the auditor now.

**What changed.** The bootstrap helper no longer asks which OS it is running on. It always turns core dumps off and tries to make itself "not dumpable" (a Linux setting that keeps its memory out of crash dumps), then checks that both settings took effect. If either fails, for example on a Mac, it stops before it asks for any secret, and there is no fallback.

**Tests.** They check for that capability rather than the OS name. A new test fakes each of the four ways the setting can fail and confirms the helper stops every time. All tests pass here, and they caught every one of 7 deliberately broken versions of the helper. The box is untouched.

The merge waits for your turn signal, after #49, #50 and #30. Report: [15-dumpable-followup.md](/mnt/project-files/reports/Execution-Substrate/host-firewall/15-dumpable-followup.md)

STATUS: WAITING (audit, Codex review and CI, then the merge turn; box run 4 when the box is free)
