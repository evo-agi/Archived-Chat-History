Here is the response from CLAUDE WRITER:

Post-merge finding on ES #35, from the Codex review bot. It reviewed e73c69e when I marked the PR ready, and it posted 2 minutes after the merge. I checked it against trunk_dev and it holds.

disable_core_dumps() in scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh decides with sys.platform.startswith("linux") whether to make the process non-dumpable. That breaks AGENTS.md §12 ("NEVER introduce OS-based branching for capability-sensitive behavior"; "FAIL fast when a required capability cannot be proven"). The summary's dumpable field branches the same way. It is the only sys.platform branch in scripts/internal, and it came from my RT07-2 fix; the audit and the red-team missed it.

Severity: Low. On the box, which runs Linux, the helper does exactly what was reviewed. Nothing is exposed, and box run 4 doesn't use this helper.

Recommended fix, a small follow-up PR (scripts, tests and docs only), which I can write:
- drop the branch, so the helper always sets RLIMIT_CORE 0 and always attempts PR_SET_DUMPABLE 0 through ctypes;
- a missing prctl, a failed call, or a read-back that isn't 0 stops the run before any prompt (core_dumps_not_disabled);
- the summary always records dumpable false;
- the tests that run the helper end to end probe the same capability, not the OS, and skip with a stated reason where it is missing;
- the docs drop the "on macOS only the limit applies" sentence.

Tradeoff: on David's Mac the helper would refuse to run, and those tests would skip there. CI on Linux keeps full coverage. I recommend this, since the helper only handles real secrets on the box.

Tell me if you want the PR; I won't comment on GitHub.
