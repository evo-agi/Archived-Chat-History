# 15: Follow-up PR #51, the core dump check without an OS branch (Codex P1 on #35)

Writer: the PR #35 writer thread. Date: 2026-11-24, about 09:25Z.
For the auditor: a full audit of PR #51, head `669c796185460eda099a276d598db1e04d6cb19d`, base trunk_dev `f058d8a1f4c8e51c0a000b94ff2b9aa3f244dfe2`.

## Plain summary (for relaying)

- **What.** The bootstrap helper no longer asks which operating system it runs on. It always sets the core file limit to 0 and always tries to make itself not dumpable with prctl, and reads both back.
- **Where that fails** (no prctl, as on macOS, or prctl fails or does not hold), the helper stops before it reads any secret. There is no fallback.
- **Tests.**
  - On a host without prctl, tests that run the helper end to end skip with the reason. The probe tests the capability itself, not the OS name.
  - A new test injects each of the four ways prctl can fail and requires the refusal.
  - A source pin forbids OS-name checks in the helper.
- **Results.** All pass here. 7 of 7 mutants are killed.
- **Scope.** Scripts, tests and docs only. The box is untouched.
- **Status.** PR #51 is open and ready for review, so Codex reviews it before merge. The merge waits for the coordinator's turn signal (queue: #49, #50, #30, then #51).

## 1. Target

| Item | Value |
|---|---|
| PR | https://github.com/evo-agi/Execution-Substrate/pull/51 (ready for review) |
| Head | `669c796185460eda099a276d598db1e04d6cb19d`, one commit on `claude/project-thread-vmre16` |
| Base | trunk_dev `f058d8a1f4c8e51c0a000b94ff2b9aa3f244dfe2` (#35 squash) |
| Recipe | v2, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Manifest SHA-256 | `afa30eae6d7ca3a09cad98101f4597f7f65df2d2f4da44aef86a66091e8f91b0`, taken twice with identical output. Method as before: fresh clone of the pushed head, reset to the base, upstream `origin/trunk_dev` |
| textual_diff_sha256 | `a39e28c5f07ce65cc34d99af3ecf2efbdd65e7b07713ab52a8df845cd6809a45` |
| Diff | `15-dumpable-followup-evidence/pr51.diff`, SHA-256 `4bf2aa85…666b`. 4 files, +247 −23 |

## 2. The finding and the approved fix

**The finding.** At #35, `disable_core_dumps()` ran `prctl(PR_SET_DUMPABLE, 0)` only under `if sys.platform.startswith("linux")`. On any other host it skipped that step, and the summary recorded `dumpable=not linux` as a pass. AGENTS.md section 12 says:

- NEVER introduce OS-based branching for capability-sensitive behavior;
- validate the capability by behavior;
- FAIL fast without fallback.

**The approved fix** (coordinator, 09:01Z): "a capability probe, fail fast, no OS branch."

## 3. Changes

`scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh`:

- New exception `ProcessStillDumpable`.
- `disable_core_dumps()` sets `RLIMIT_CORE` 0 and reads it back, as before. It then always:
  - looks up `ctypes.CDLL(None, use_errno=True).prctl`; an `OSError` or `AttributeError` there becomes `ProcessStillDumpable`;
  - calls `PR_SET_DUMPABLE` 0; a non-zero result becomes `ProcessStillDumpable`;
  - calls `PR_GET_DUMPABLE`; a non-zero result becomes `ProcessStillDumpable`.
- `main()` maps `ProcessStillDumpable` to phase `disable_core_dumps`, failure class `core_dumps_not_disabled`, message class `process_still_dumpable` (new). Other `OSError`, `ValueError` and `AttributeError` keep `core_dump_limit_failed`. The summary records `dumpable=False`.
- The help text says "core file limit 0, and not dumpable through prctl", and that a host where either cannot be done is refused.
- The docstring says why there is no OS check and no fallback.

`.docs/system_overview/remote_supported_host_alpha.md`: the bullet drops "on Linux" and documents the refusal, its class and message class, and that there is no fallback.

`scripts/remote_alpha_vault_workload_auth_bootstrap_test.go` and `…_real_vault_test.go`:

- **`requireBootstrapNotDumpableCapability(t)`.** It runs the same ctypes calls in `python3 -I -c`, cached once per test binary, and calls `t.Skipf` with the reason when they fail. It is called:
  - by `runRemoteAlphaBootstrapHelperWithPTYInput`, so by every terminal run;
  - by the three runs without a terminal that reach the core dump step (config load failure, prompt unavailable, unexpected exception);
  - by the two real-Vault tests, before Vault starts.
- **`runRemoteAlphaBootstrapHelperWithPTYInputOnAnyHost`.** The same runner without the probe, for the refusal test.
- **New `TestRemoteAlphaVaultWorkloadAuthBootstrapRefusesWhenTheProcessStaysDumpable`.** A `sitecustomize.py` on `PYTHONPATH` replaces `ctypes.CDLL` in the helper's python3, and `ES_TEST_PRCTL` picks the mode:
  - `no_c_library`: the constructor raises `OSError`;
  - `no_prctl`: `AttributeError`;
  - `set_fails`: set returns −1, get returns 0;
  - `still_dumpable`: set returns 0, get returns 1.

  Each of these four subtests requires:
  - exit 1;
  - the printed `failure_phase=disable_core_dumps failure_class=core_dumps_not_disabled`;
  - no prompt text, no secret and no traceback in the output;
  - zero Vault requests, and no SPIRE server log (the command never ran);
  - the failure summary: secret prompts and Vault operations not started, `failure_message_class=process_still_dumpable`, and the step not recorded as completed.

  A fifth subtest, `unchanged`, loads the module with no mode, runs to the end and passes `assertBootstrapCoreDumpsOff`. This proves the module alone does not stop the run. It uses the probed runner.
- **New `TestRemoteAlphaVaultWorkloadAuthBootstrapDoesNotBranchOnTheOperatingSystem`.** Neither helper file may contain `sys.platform`, `platform.system`, `platform.platform`, `import platform`, `os.uname`, `uname`, `OSTYPE`, `darwin` or `Darwin`.
- **`assertBootstrapCoreDumpsOff`.** It also requires `dumpable: false`. Its comment no longer says "on Linux"; the `/proc` check was already conditional on the file existing.
- **Pins.** The help and docs pins are updated, and one new docs pin covers the refusal sentence.

## 4. Validation

Every run had SIGINT at its default (`sigreset.py`). Logs are in `15-dumpable-followup-evidence/validation/`.

| Run | Result |
|---|---|
| `TestRemoteAlphaVaultWorkloadAuthBootstrap` (real Vault 2.2.2 included), root | 87 pass, 0 fail, 2 skip (existing non-root-only tests) |
| The same, unprivileged (uid 65534) | 89 pass, 0 fail, 0 skip |
| The same on a simulated host without prctl (`macsim-python3-wrapper.sh` puts the no_prctl module into every python3, the probe's included) | 24 pass, 0 fail, 58 skip at the head 669c796 (`macsim-head.log`). The 4 refusal subtests pass; `unchanged` and the end-to-end runs skip with the reason, both real-Vault tests before Vault starts. Corrected after audit 16 (O16-1): the first figure, 25 / 64 in `macsim.log`, came from a tree before the real-Vault probes moved ahead of Vault's start |
| Root package (docs tests), root | 604 pass, 0 fail |
| `scripts` tests matching `TestRemoteAlphaVaultWorkloadAuth\|TestRemoteAlphaOperator\|Doc`, root and unprivileged | 166 and 164 failures. The failing set is identical to trunk_dev `f058d8a` in the same container (`root-fails.txt` vs `base-root-fails.txt`, and likewise unprivileged). These are host problems: en_US.UTF-8 locale missing, fake sudo as root, TLS-status operator tests. None runs the Python helper |
| `gofmt -l scripts/`, `go vet ./scripts/` | clean |

Mutants, at 669c796, run against the refusal test, the no-OS pin, the fake-Vault run, the help pin and the docs pin. The runner is `mutants-runner.py` and the results are in `mutants.txt`. The script was restored and its checksum checked.

| Mutant | Result | Failing tests |
|---|---|---|
| M1 the `sys.platform` branch put back | killed | `DoesNotBranchOnTheOperatingSystem` |
| M2 a missing prctl returns (falls back to running) | killed | `no_c_library`, `no_prctl` |
| M3 the `PR_SET_DUMPABLE` result not checked | killed | `set_fails` |
| M4 the read-back not checked | killed | `still_dumpable` |
| M5 lookup failure not mapped to `ProcessStillDumpable` | killed | `no_c_library`, `no_prctl` (message class) |
| M6 the summary records `dumpable: true` | killed | `FakeVaultWrites…`, `unchanged` |
| M7 `main()` continues after `ProcessStillDumpable` | killed | all four refusal subtests |

**CI.** On the GitHub runner (Linux) the probe passes, so nothing new skips and `.github/ci/environment-only-tests.txt` needs no change. CI on 669c796 runs on the push. I report it in the thread only if it fails.

## 5. Effects

- One commit pushed to `claude/project-thread-vmre16`. That branch was recreated from trunk_dev `f058d8a` after #35 merged and its old head branch was deleted automatically.
- PR #51 opened as ready for review, and the thread watches its activity.
- No PR comment and no merge. The box was not contacted.
- Box run 4 still waits for the coordinator's box turn. It deploys trunk_dev's firewall files, which this PR does not touch.
