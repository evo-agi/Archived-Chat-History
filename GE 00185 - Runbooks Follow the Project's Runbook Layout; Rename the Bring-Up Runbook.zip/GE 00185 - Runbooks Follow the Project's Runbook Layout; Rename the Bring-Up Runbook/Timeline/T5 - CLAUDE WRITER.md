All three draft PRs are open and ready for audit: [ES #65](https://github.com/evo-agi/Execution-Substrate/pull/65), [IM #3](https://github.com/evo-agi/Infrastructure-Manager/pull/3) and [AR #13](https://github.com/evo-agi/Archived-Runbooks/pull/13).

- **What changed:** all five ES runbooks now use the Archived-Runbooks layout, the bring-up included. The bring-up is renamed to `Governed Execution ES System Bring-Up.md`. IM needed a one-line change because it checks for that file. The drift check now covers every folder under `.runbooks/`. Hashes and validation are in the report.
- **Merge order:** ES, then IM, then I refresh AR's copies from the ES merge commit.
- **For the coordinator:** `runbooks.md` still says the bring-up keeps its old name.

STATUS: WAITING (CI on ES #65, results by about 5 PM ET, then the audits)
