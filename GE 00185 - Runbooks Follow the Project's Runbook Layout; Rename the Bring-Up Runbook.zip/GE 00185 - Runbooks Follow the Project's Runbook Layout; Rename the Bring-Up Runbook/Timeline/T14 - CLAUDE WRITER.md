CI on ES #65's new head `70dc204` passed on Linux and macOS, and the PR merges cleanly onto `trunk_dev`. AR #13's regression tests also passed in CI. Its compare step still fails, as planned, until ES #65 merges. I've added both results to the repair report.

STATUS: WAITING (delta audit of ES #65 and AR #13)
