Both audit findings are fixed and pushed, ready for the delta audit.

- **ES #65** is now at `70dc204`, with manifest `dc37b73d…011d`. The bring-up now links the Control Plane consumer runbook directly where it used to say "linked above". I also moved the retained-staging note to Notes in two runbooks, which was the audit's optional O1.
- **AR #13** is now at `795a00f`, with manifest `742cff00…0ccf`. The drift check now looks at every file under `.runbooks/`. 21 new regression tests run in CI, and 5 of them fail against the old check.

IM #3 is unchanged. The merge order stays the same.

STATUS: WAITING (delta audit of ES #65 and AR #13)
