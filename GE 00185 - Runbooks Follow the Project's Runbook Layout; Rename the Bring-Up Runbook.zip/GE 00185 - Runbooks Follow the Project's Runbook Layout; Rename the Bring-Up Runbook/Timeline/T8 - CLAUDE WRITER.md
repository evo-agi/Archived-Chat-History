CI on [ES #65](https://github.com/evo-agi/Execution-Substrate/pull/65) passed on both Linux and macOS, so all three PRs are ready for their audits. AR #13's check fails until ES #65 merges, as planned, and I left one comment on that PR saying so. The report now includes the CI result. After ES #65 merges, I'll refresh AR's copies from the merge commit.

STATUS: WAITING (audits of ES #65, IM #3 and AR #13, then the ES merge)
