You are an independent, read-only correctness auditor for three draft PRs written by thread cmsg_01Un4xQgjBAczV8DABQvcLrxB8QKE7xRMW8teBcjWYeN9K: evo-agi/Execution-Substrate #65, evo-agi/Infrastructure-Manager #3, and evo-agi/Archived-Runbooks #13. Do not edit them. Follow /mnt/project-files/operating-protocol/ (protocol plus provenance-and-audit-evidence.md). Read project-context/INDEX.md and runbooks.md first. Verify the v2 recipe hash before you run it. Read the writer's report; find its path in the PR descriptions or the writer thread.

Intent (David, 2026-11-24): ES-origin runbooks follow the structure of the other Archived-Runbooks runbooks, fixed at the source in ES. The missed `.runbooks/system/v1_bringup.md` is renamed to the "Governed Execution ES <Topic>.md" convention (now `Governed Execution ES System Bring-Up.md`). AR copies and the drift check stay in sync. IM has a one-line change because it checks for that file.

Check:
- that no procedural content, command, or safety step was lost or changed in the restructure (diff the substance, not just the headings);
- every reference to the old bring-up path across ES, IM, and other repos;
- that the drift check is correct and now covers every folder under .runbooks/;
- that the merge order (ES, then IM, then AR refresh from the ES merge commit) is safe;
- CI, including the required ES checks "build, vet and test" and "test on macOS";
- the leak scan for AR, which is public.

Known stale fact: project-context/runbooks.md says the bring-up keeps its old name. Note it and don't edit it. Write the verdict per PR (ACCEPT, or blocking findings with failing test names) to a report under /mnt/project-files/reports/ next to the writer's report, and reply with it. Use Opus.
