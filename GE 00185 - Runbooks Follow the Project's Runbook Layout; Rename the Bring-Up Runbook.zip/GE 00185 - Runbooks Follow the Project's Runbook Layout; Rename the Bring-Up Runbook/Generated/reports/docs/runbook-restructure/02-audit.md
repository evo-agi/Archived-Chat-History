# Runbook restructure: independent audit 02 (ES #65, IM #3, AR #13)

Auditor: fresh read-only audit thread "Audit the ES runbook restructure" (cmsg_01Un4xQgjBAczV8DABQvcLrxHYM5N1KbjCTUQcWH7LJWqn), started by the coordinator 2026-11-25 20:59Z. Model: Opus. The writer thread (cmsg_01Un4xQgjBAczV8DABQvcLrxB8QKE7xRMW8teBcjWYeN9K) was not consulted; inputs were its report `01-implementation.md` (SHA-256 `cd8dd5dd8121b2db8f158be2d4056d1d32263b692b183ba30460fbdff84991f1`), the three PRs and the repos.

## Verdicts

| PR | Audited commit | Verdict | Why |
|---|---|---|---|
| [ES #65](https://github.com/evo-agi/Execution-Substrate/pull/65) | `f7bac1a872048b975645d136b27dc2e2efc5f171` | **BLOCK** | A02-1 (Low): the restructure moved a link below the sentence that calls it "linked above". One-sentence fix. No command or safety step was lost. |
| [IM #3](https://github.com/evo-agi/Infrastructure-Manager/pull/3) | `e728e023301cdd4ca1dff389fc416d4bafedebd6` | **ACCEPT** | One string, correct; merge only after ES #65 lands. |
| [AR #13](https://github.com/evo-agi/Archived-Runbooks/pull/13) | `30c1196afdbe11791a2e185c7de2df81fee21d61` | **BLOCK** | A02-2 (Low): the drift check's new "named outside the convention" rule never sees a name that does not end in lowercase `.md`. Also carries A02-1 in its bring-up copy, and must be refreshed from the ES merge commit anyway (new bytes, so a delta check before merge). |

Failing test names for the blocking findings: none. No test in either repo covers them (A02-1 is a prose cross-reference; AR has no tests for its check, and the writer's `probe_check.py` stubs `read_es`, so it cannot see A02-2). The probes that show them are in `02-audit-evidence/`.

**Effect status:** nothing pushed, no PR comment or review, nothing merged, no repo or project-file edits other than this report and its evidence folder. Repair, commit, push, PR changes and merge: not performed.

## Target identity and provenance

Recipe: `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified with `sha256sum -c` before use (copy at `/opt/audit/v2.py` in the audit container).

| Repo | Base | Tip | Tree | manifest_sha256 | textual_diff_sha256 | Files |
|---|---|---|---|---|---|---|
| Execution-Substrate | `trunk_dev` `ae9aa65322954be16d5d3e354dd0aeec5d87723d` | `f7bac1a8…f171` | `0c20431115a40dec2ae99e28c178fabbf63c826a` | `e25db7ea46794fd01b4efe77befe95ca557aedf736449de0b0ca4c989dce8576` | `7f3014bb36b39c37f5a9feffffff5bd168fdc6340397607093959b26d89d93d6` | 18 |
| Infrastructure-Manager | `trunk_dev` `b2ca78f8d8aae00fdd732966202be6087a6797fe` | `e728e023…bd6` | `5b1739ccbd5ec36adf21b2e7e7333dc8ef4e3986` | `e081127b71b3c210cbf489e16353bf6aa80bed0d0f71257ad8306ae18899c308` | `f9537c89d5ffa96091952cd609c1e3cd7b5dc8dee5a7566e894473240496fa61` | 1 |
| Archived-Runbooks | `main` `44aa21a3be15ed1a5b6bd38680596feb2c21e1ba` | `30c1196a…1d61` | `eed8cf42299f7a4a4ff0eae1c0a39911569d3662` | `da43ccc3a5e7a8af73d534b7c3cb15e0fe59042dac83ea4b00367bec3e30abdb` | `85a440d5ca2897ff82def0901fb2cf7788a334fccc2ff280a4cc007e31926c29` | 8 |

Reproduction (script `02-audit-evidence/repro_manifest.sh`, provenance §5.3): fresh clones under `umask 022`; pushed tip equals the reported tip; base is an ancestor; clean checkout of the tip; `git reset --mixed BASE`; upstream pinned to `origin/trunk_dev` (ES, IM) or `origin/main` (AR); v2 run twice to two absent paths in a fresh `0700` directory; `cmp` identical. All three canonical manifests are **byte-identical** to the writer's files in `manifests/` (no mode-bit differences). PR heads on GitHub equal the audited tips. The bases had not moved at 21:05Z (ES `trunk_dev` ae9aa65, IM `trunk_dev` b2ca78f, AR `main` 44aa21a). Closing manifests: see "Closeout" at the end.

## Coverage

- **Substance of all five runbooks** (base text against tip text): every fenced code block compared as a multiset, every code line, and every original prose line checked for verbatim presence, then each non-verbatim line read in a word diff (`02-audit-evidence/substance_compare.py`, results in `substance_compare_results.txt`). Every relative-position phrase ("above", "below", "earlier", "step N") in the five files checked against the new order.
- **"Expect" lines** checked against the scripts that print them: `20_publish.sh:50,58,70`, `30_prepare.sh:50,58,61`, `40_submit.sh:50,58,62-69,71`, `50_lifecycle.sh:11,60-63,93-96,164`, `60_execute_loop.sh:595,614,648,668,831`, `01_bringup.sh:350-366,379`, `73_supported_local_proof.sh:252`, `scripts/internal/operator_failures.sh:398-407`, ES `PrepareResult` in `es/admission/types.go:48-50`.
- **History entries** checked against `git log --follow` at ae9aa65 for each file (dates and PR numbers match: #1, #8, #18, #19, #20, #31, #37, #38, #57, #60).
- **Test Evidence**: every test it names exists (`es/app/runtime_identity_vault_flow_test.go`, `supported_local_proof_validation_test.go`, `execution_loop_integration_test.go`, `operator_scripts_integration_test.go`) and none is in `.github/ci/environment-only-tests.txt`. Whether each ran rather than skipped on the runner: see CI below.
- **References to the old path** `v1_bringup` in: ES tip (working tree, all files), IM all remote branches, AR tip, and every remote branch of Maintenance-Agent, Coordinator, Bridge-Core, OpenAI-Bridge and Archived-Chat-History (text files; zips not opened). Also project files under `project-context/`, `operating-protocol/`, `strategy/`, `test-hardware-linux-1/`, `maintenance-agent/`. Also anchors or names of the old sections (`#5-operator-…`, "Operator Troubleshooting Matrix", "Primary Bring-up Path", …) anywhere in ES.
- **Every consumer of the renamed path in ES**: `OPERATOR_TROUBLESHOOTING_RUNBOOK` (`operator_failures.sh:5,124,133`; `70_diagnostics.sh:499,594,627`) and how a path with spaces reaches its readers (JSON through Python argv in `60_execute_loop.sh` and `70_diagnostics.sh`; `key=value` lines in `summary.txt`; `71_diagnostics_summary.sh` reads JSON). No reader splits on spaces. No other repo parses the line.
- **Drift check**: full read of the new script and its diff; run for real against ES tip and `trunk_dev`; 10 probes through the real `read_es` (local ES repo with one mutation per branch, `ES_URL` pointed at it).
- **Merge order**: trial merges of ES #65 with the other open ES PRs (#63 head `2552432`, #64 head `aecb180`, and both), and the IM window.
- **CI** for ES #65, AR #13 (IM has no CI).
- **Leak scan** of the added lines of all three diffs.
- Not inspected: GitHub's rendering of the pages (only a local link and anchor check); none of the runbooks was run end to end; the box was not used.

## Findings

### A02-1 (Low, test/doc gap; patch defect): "linked above" now points at nothing above

- **Contract**: the restructure must not change procedural content; a moved paragraph must keep its references true.
- **Path and line**: ES `.runbooks/system/Governed Execution ES System Bring-Up.md:227` (AR copy `Governed Execution ES System Bring-Up.md:231`): "For CP consumer-specific diagnosis, do not infer extra ES ownership from this helper. Use the canonical ES-side CP consumer runbook linked above."
- **Evidence**: at base, the link to `supported_local_cp_consumer_runbook.md` was in "1. Objective" (`v1_bringup.md:32`), above the sentence (`:242`). The restructure moved it to Notes (`:528` in ES, `:532` in AR), about 300 lines below. Nothing above line 227 links that runbook any more. The writer's line check passes this because the sentence itself is verbatim.
- **Impact**: an operator diagnosing a Control Plane consumer issue is sent to a link that is not where the runbook says. No command or safety step lost.
- **Required correction**: one sentence, for example "Use the canonical ES-side CP consumer runbook linked under Notes.", or link it inline there. Then refresh the AR copy. No new test asked for.
- **Uncertainty**: none.

### A02-2 (Low, bug in a new check rule; patch defect): the convention rule never sees names not ending in `.md`

- **Contract**: the new docstring of `.github/scripts/check_es_runbook_copies.py` says the check fails when "an ES runbook under .runbooks/ is named outside the convention". The PR's goal is that the check covers everything under `.runbooks/`.
- **Path and line**: AR `.github/scripts/check_es_runbook_copies.py` `read_es`, the `if name.endswith(".md"):` filter, feeding the convention loop in `main`.
- **Evidence** (probes through the real `read_es`, `02-audit-evidence/drift_probe_results.txt`): ES with `.runbooks/system/Governed Execution ES Upper.MD` added (P9) gives exit 0, 0 problems, and no copy is asked for. ES with `.runbooks/system/notes.txt` added (P8) gives exit 0. Any runbook saved as `.MD`, `.markdown` or without an extension is invisible to both the copy rule and the convention rule.
- **Impact**: a future ES runbook can escape both the copy requirement and the naming rule, silently. Likelihood is low; the gap is in the rule this PR adds.
- **Required correction**: let the convention rule see every path under `.runbooks/` (list them all; any path not matching `Governed Execution ES *.md` fails, so a non-runbook file fails closed until someone decides). Add a probe case for it through `read_es`, or with the stub fed the full listing.
- **Uncertainty**: whether non-`.md` files should be allowed under ES `.runbooks/` is a policy choice; failing closed is the safe default.

### Observations (no change required unless the writer wants them in the same repair round)

- **O1, retained-staging note placement.** In the Reference and Static Script runbooks the paragraph "Inspect retained staging whenever exclusive run-root creation may have occurred. Every post-claim failure and every accepted run retains its root, including … terminal success." is now under "### 7. If a helper fails" (`…Reference Workload.md:319`, `…Static Script Workload.md:271`). Its text is unchanged and it moved together with the failure guidance it sat next to at base, but the new heading reads as if it applies only on failure, while the text says success retains the root too. Optional: move it to Notes.
- **O2, a dropped header line.** "Compatible System Version: `Execution Substrate current working tree`" (Static Script and bring-up headers) is gone with no History line. It named no version, so nothing is lost; the writer's report excludes header lines from its line check.
- **O3, commands de-duplicated or reformatted.** Vault Login had `".examples/runtime_identity_vault_login/package.sh"` twice (sections 2 and 8); it is now once (step 5). Static Script's `".examples/control_plane_static_script/run.sh"` changed from a code block to inline code (What is it? and Notes). No command was removed or changed.
- **O4, CPU override after `up`.** The `export NOMAD_CLIENT_CPU_TOTAL_COMPUTE="2000"` block now follows the full-profile `up` command instead of preceding it in the prerequisites. Checked: on such a host `up` fails with "rerun only with explicit NOMAD_CLIENT_CPU_TOTAL_COMPUTE as a bounded troubleshooting override" (`scripts/internal/bringup.sh:416`), so the new order matches the script's own guidance. No finding.
- **O5, new anchor untested.** `(#what-do-the-failures-mean)` (bring-up line 30) is the anchor GitHub makes for "## What do the failures mean?", but no test checks in-page anchors (mutant M6 below survived). Fine today.
- **O6, pre-existing: nothing ties IM to ES.** IM's `EXECUTION_SUBSTRATE_REQUIRED_FILES` is checked against a real ES checkout by nothing (IM has no CI; `tests/test_config.py` builds a fake tree from the list itself). This rename is exactly the event that would break IM `up` silently. Not this PR's defect; a backlog candidate for the coordinator, since project policy wants a machine-enforced trigger.
- **O7, stale facts in the brief and project files.** (a) Archived-Runbooks is **private**, not public: GitHub search API `repo:evo-agi/Archived-Runbooks` reports `"visibility":"private"` (21:05Z). The leak scan was done anyway. (b) `project-context/runbooks.md:12` still says the bring-up "stays in ES under its name" (known; not edited). (c) `project-context/backlog.md:8` still lists this work as open. Both are the coordinator's to update after the merges.

## What I verified as correct

- **No procedural content lost.** All five runbooks: every code block of the base is present in the tip (as a multiset, except the O3 duplicate), no code line added or removed, and every non-verbatim prose line is either a heading, a header line, a link target of the renamed file, a sentence merged with a new "Expect …" or "This runbook …" opening, or a moved position reference correctly rewritten ("you start below" → "in step 3"; "the canonical wrapper above" → "in step 1"; "the operator helper wrappers below" → "above"). The one position reference not rewritten is A02-1. The bring-up's troubleshooting matrix, staging guidance and every rule the docs tests pin are byte-identical in their new section.
- **The three content fixes are right.** (1) `01_bringup.sh:350-366` prints profile, readiness, state dir and `next:` lines after `bring-up complete`. (2) `73_supported_local_proof.sh:947,957` runs `scripts/60_execute_loop.sh`, and `01_bringup.sh:362` suggests it after a full-profile `up`. (3) Local Validation step 3's `vault` commands run in the second terminal and need `VAULT_ADDR`/`VAULT_TOKEN`, which step 1 exported only in the Vault terminal.
- **Every "Expect …" line matches the script output** listed under Coverage (the static-script workload description matches its entrypoint: `START-BANNER`, three `HEARTBEAT:` lines, a JSON line with the digest).
- **Rename is complete.** The only `v1_bringup` strings left in ES are the two History lines. Outside ES: IM `config.py:30` on `trunk_dev` (fixed by IM #3; also on IM `main` and `trunk_dev_secondary`, which follow milestone merges), and the two project files in O7. None in MA, Coordinator, Bridge-Core, OpenAI-Bridge, Archived-Chat-History (text files) or the other AR files.
- **The quoted path is safe for every reader** (see Coverage); the JSON summary encodes the quotes through Python.
- **IM #3**: `_missing_required(<ES tip>, EXECUTION_SUBSTRATE_REQUIRED_FILES)` returns `[]`; against ES base it returns exactly the new path. The function joins with `pathlib`, so spaces are fine.
- **Drift check, the parts that work** (probes through the real `read_es`): baseline 0 problems; a conventional runbook in `.runbooks/system/` without a copy (P2) and two folders deep (P3) are caught; `.runbooks/README.md` is refused as outside the convention (P4); the same name in two folders (P5); renaming the bring-up back to `v1_bringup.md` gives the convention error plus the orphan copy (P6); one byte changed (P7); a runbook moved to a new folder makes the copy's note name the wrong path (P10). Links turn back relative to each file's own folder (the `.runbooks/system/` copy passes, with `../../.docs/…` and `../execution/…` links). Against real ES: tip f7bac1a 5 runbooks, 5 copies, 0 problems; `trunk_dev` ae9aa65 6 problems, exactly those the writer reports.
- **AR copies and README**: 66 links in README plus the five copies, 0 problems (relative links exist in AR; ES `trunk_dev` links exist in the ES tip tree; commit links resolve; in-page anchors match headings). The dropped note sentence ("It keeps ES's own layout …") was no longer true and is not read by the check. The README moves the bring-up from "Runbooks in other repositories" to the ES table and every top-level runbook is still listed.
- **Leak scan** of added lines (ES 455, IM 1, AR 895): only loopback addresses and the documented `*.internal` names; no LAN address, home path, account name, e-mail, phone number, token or key material.

## Validation

All runs in this audit container (Linux amd64, Go 1.26.5 toolchain per `go.mod`, as root, proxy variables unset for `es/app` and `./scripts`), on worktrees of the exact commits.

| What | Base ae9aa65 | Tip f7bac1a | Notes |
|---|---|---|---|
| `go test . -count=1` (root) | 175 pass, 0 fail | 175 pass, 0 fail | incl. `TestRunbookPathMentionsExist`, `TestMarkdownRelativeLinksResolve`, `TestTrancheAFilesystemAndResourceCustodyDocsContract`, `TestRetainedResultAuditF2CurrentClaimedRootRetentionDocs`, `TestStartupProbeUseAgreementDocsContract`, `TestNestedStagingOwnerProbeDocsContract`, `TestARSStorageCheckDocsContract`, `TestCallerAllowlistPrefixRuleIsDocumentedOnce`, `TestTrackedGeneratedArtifactHygiene` |
| `go test ./es/app -run` the 8 runbook-path tests | 6 pass, 2 skip | 6 pass, 2 skip | pass: `TestBringupRunbookTroubleshootingMatrixListsCurrentFailureCategories`, `TestLinuxSetupScriptDocumentsSupportedProfileGuardrails`, `TestPublishScriptCategorizesAuthorizationFailure`, `TestPrepareScriptCategorizesRuntimeConfigFailure`, `TestSubmitScriptCategorizesSubstrateFailure`, `TestDiagnosticsScriptRuntimeConfigCategoryBundleAcceptsSurfacedFailureLabel`; skip here (need Nomad/Docker): `TestLifecycleScriptCategorizesExecutionFailure`, `TestExecuteLoopScriptFailureSummary` (CI runs them) |
| `go test ./scripts` (whole package) | 412 pass, 38 fail, 12 skip | 412 pass, 38 fail, 12 skip | the same 38 failing names on both sides, all `TestRemoteAlpha…` tests that need `ssh`, `ip`, a real kernel firewall or a non-root owner in this container (list in `02-audit-evidence/scripts-failing-names.txt`) |
| Root package on trial merges | | | #65+#64 176 pass 0 fail (incl. #64's `TestAuthorityOrderIsStatedOnlyInAgents`); #65+#63 175/0; #65+#64+#63 176/0. All three merges are git's own clean merges (#64 shares `README.md` and `docs_contract_test.go`, no conflict) |
| IM `PYTHONPATH=src python3 -m unittest discover -s tests` | | 197 OK | |
| AR check vs ES tip / `trunk_dev` | | 0 / 6 problems | as the writer reports |
| AR drift probes P2-P10 | | 8 caught, P8 and P9 not | A02-2 |
| AR link check | | 66 links, 0 problems | |

**Mutants on ES tip** (root package plus two `es/app` tests, each from a clean tree, `git add -A` before running): M1 `operator_failures.sh` back to `v1_bringup.md` → `TestRunbookPathMentionsExist`, `TestPublishScriptCategorizesAuthorizationFailure`; M2 `70_diagnostics.sh` usage → `TestRunbookPathMentionsExist`; M3 `70_linux_setup.sh` → `TestRunbookPathMentionsExist`; M4 README link → `TestMarkdownRelativeLinksResolve`, `TestRunbookPathMentionsExist`; M5 the new matrix sentence deleted → `TestBringupRunbookTroubleshootingMatrixListsCurrentFailureCategories`; M6 in-page anchor misspelled → survives (O5).

**CI on ES #65** (head f7bac1a): both required checks **green**. "build, vet and test" run 45699284315 (completed 21:40:20Z): build, vet, vet for macOS, gate self-check (145 OK), then "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed", the listed tests still fail, and "tests as root passed: 9 of execution-substrate/scripts". The 14 self-skips are 9 in `scripts`, 2 in `reliablesubmit`, 3 in `es/admission`; **none in `es/app`**, and the `es/app` run skipped only its three listed entries, none of them a test that the runbooks' Test Evidence names. So every Test Evidence test ran and passed on the runner (`es/app` PASS, 464.8 s; root package PASS). This confirms the writer's inference. "test on macOS" run 45699284313 completed green at 21:23:42Z. Gate lines saved in `02-audit-evidence/ci-45699284315-gate-lines.txt`.

**CI on AR #13**: `compare` (run 45699536853) fails, by design, until ES #65 is on `trunk_dev`. IM has no CI.

## Merge order

The writer's order is safe: **ES #65, then IM #3, then refresh AR #13 from the ES merge commit, re-run its check, merge AR #13.**

- IM must follow ES: IM `up` refuses unless the named file exists (`cli.py:133`, `config.py:132-135`). Between the two merges IM `trunk_dev` names a file ES `trunk_dev` no longer has. Inference (not checked on the Mac): no live use is harmed, because `up` also needs the retired Control Plane checkout. Merging IM first would break it against today's ES instead, so ES first is right.
- AR must follow ES: AR's check reads ES `trunk_dev`. From the ES merge until AR #13 merges, AR's daily run (cron `17 10 * * *`, 10:17Z) and push runs fail and e-mail David (intended). Finishing AR the same UTC day keeps that to no scheduled failure.
- The refresh is required, not optional: the copies' notes name `f7bac1a`, a branch commit that the merged-branch auto-delete will orphan. Refreshing changes AR #13's bytes, so it needs a provenance delta check before merge (this ACCEPT/BLOCK binds `30c1196` only).
- Other open ES PRs: #65 merges cleanly with #64 and #63 and the root package passes on each merge; whichever lands first, the other needs only the sync-only check of the merge queue rule.
- With A02-1 and A02-2 open, the order becomes: repair ES #65 and AR #13 (one round), fresh delta audit, then the order above. IM #3 is unaffected.

## Confidence

| | ES #65 | IM #3 | AR #13 |
|---|---|---|---|
| Provenance | 1.0 (reproduced byte for byte) | 1.0 | 1.0 |
| Validation | 0.9 (root, targeted es/app and mutants rerun here; CI covers the Nomad/Docker tests) | 0.95 | 0.9 (real-git probes; no CI pass possible before ES merges) |
| Implementation | 0.9 (one stale reference found after a full substance diff) | 0.97 | 0.85 (A02-2) |

## Closeout

At 21:43Z: all audit worktrees (base, tip, the three trial merges, IM tip) removed and pruned; the probe repo and scratch live outside the repo clones. Upstreams re-pinned, v2 run again in each audit clone: the closing canonical manifests of ES, IM and AR are **byte-identical** to the opening ones. No ignored or untracked leftovers in any clone. The trial-merge commits exist only as unreferenced objects in the audit clone's object store, never pushed.

Sensitive material: none read or copied. The scans looked only at added diff lines.

## Evidence

`02-audit-evidence/` next to this file: `repro_manifest.sh`, `manifest-es.json`, `manifest-im.json`, `manifest-ar.json` (canonical lines, identical to `manifests/`), `substance_compare.py` and `substance_compare_results.txt`, `drift_probe_build.sh`, `drift_probe_runner.py`, `drift_probe_results.txt`, `ar_linkcheck.py`.
