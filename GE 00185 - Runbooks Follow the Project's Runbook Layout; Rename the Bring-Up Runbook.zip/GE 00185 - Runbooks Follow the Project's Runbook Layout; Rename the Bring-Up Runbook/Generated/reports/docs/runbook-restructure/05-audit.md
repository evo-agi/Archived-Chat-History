# Runbook restructure: independent delta audit 05 (AR #13 refresh)

Auditor: fresh read-only audit thread "Check the refreshed AR runbook copies" (cmsg_01Un4xQgjBAczV8DABQvcLrxCeGxQUhpJGQ56WWjzK7agr), started by the coordinator 2026-11-25 23:04Z. Model: Opus. This thread did not write or audit any earlier round. Inputs: the coordinator's brief, `04-audit.md`, the writer's `05-merges-and-refresh.md` and `manifests-r3/`, AR PR #13, and the ES and AR repos. The writer thread was not consulted. No subagents were used. Evidence is in `05-audit-evidence/` next to this file.

## Verdict

| PR | Audited commit | Verdict |
|---|---|---|
| [AR #13](https://github.com/evo-agi/Archived-Runbooks/pull/13) | `6a6f5c7b8772b423cc810416c029496dc7001bec` | **ACCEPT** |

All five points in the brief check out:

1. **Diff.** `795a00f..6a6f5c7` is one fast-forward commit that changes 6 files. Each of the five copies changes in exactly one line, and only by the commit in the "Copied word for word on" line (`70dc204` became `389ecf6`, with that commit's link). The test file gains 4 cases and one changed case. The check, the workflow and the README did not change.
2. **Copies.** All five copies are byte-identical to their ES files at `389ecf6`, apart from the note and the links made absolute. I checked this with my own comparator, which does not reuse the check's code, and with the check itself.
3. **CI.** The drift check passes in CI: run 45718294101 on 6a6f5c7 is green. All 25 tests passed, and the compare step reported 0 problems against ES `trunk_dev` (389ecf6).
4. **Tests and mutants.** The 25 tests pass here. All 12 of audit 04's mutants are now killed (9 of 12 with the 795a00f tests). The O04-2 fix also holds on a case-insensitive file system, which I could run here.
5. **Leak scan.** The 52 added lines contain nothing sensitive.

There are no blocking findings, so no failing test names to publish. Two observations below need no change.

**Merge gate note.** This ACCEPT binds `6a6f5c7` only. At 23:12Z the PR head was still 6a6f5c7, base `main` was still 44aa21a, and ES `trunk_dev` was still 389ecf6. GitHub's merge ref `86cedab` has the same tree as the tip (`b5ab089c…`), because `main` is an ancestor of the tip. The two open ES PRs, #64 (`dd30aca`) and #63 (`3919944`), do not touch `.runbooks/`. So merging either of them before AR #13 will not make the copies drift.

**Effect status:** nothing was pushed, commented, reviewed or merged, and no repos were edited. The only project files written are this report and `05-audit-evidence/`. Repair, commit, push, PR changes and merge: not performed. One change to the audit container only: I installed `ciopfs` (Ubuntu package) for the case-insensitive file system run. Its mount was removed afterwards.

## Target identity and provenance

The recipe is `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`. I checked it with `sha256sum -c` at 23:05Z on the project file, and again on the copy I ran, at the opening and at the closing manifest.

| Repo | Base | Tip | Tree | manifest_sha256 | textual_diff_sha256 | Files |
|---|---|---|---|---|---|---|
| Archived-Runbooks | `main` `44aa21a3be15ed1a5b6bd38680596feb2c21e1ba` | `6a6f5c7b8772b423cc810416c029496dc7001bec` (branch `claude/project-thread-0z4rtn`) | `b5ab089c929c968b084587e1a3a8134e20806038` | `9d1f71491cd24b6986b8c5ff6e21a691aaa886d16e74479e0cd80890ce1d10f4` | `d1b3503814d64a243f116842f151fdb72cac513cf5c9c2fdb6d64431459d3842` | 9 |

**Reproduction** (`05-audit-evidence/repro_manifest.sh`, provenance §5.3):
- a fresh clone under `umask 022`;
- the pushed tip equals the reported tip, and the base is an ancestor of it;
- a clean checkout of the tip, with `git status --porcelain --ignored` empty;
- `git reset --mixed` to the base, and the upstream pinned to `origin/main`;
- v2 run twice to two absent paths in a `0700` folder, and the two outputs are identical under `cmp`.

The canonical manifest is **byte-identical** to the writer's `manifests-r3/Archived-Runbooks.json` (SHA-256 of that file `9d1f7149…10f4`), with no mode differences. 795a00f is an ancestor of 6a6f5c7.

Against audit 04's manifest (`04-audit-evidence/manifest-ar.json`), exactly 6 entries changed: the test file and the five copies. The check, the workflow and README.md are unchanged by SHA-256. Provenance covers the full base-to-tip range. The review covers the delta, as the brief asks. Audit 04 reviewed everything up to 795a00f.

## Coverage

- **The delta, read in full.** The test file was re-read whole, not only its diff, together with the whole check, so I could reason about each new case against the code. Word diff of the five copies.
- **Copies against ES 389ecf6.** ES side:
  - `trunk_dev` is 389ecf6 (the #65 squash merge, parent ae9aa65). Its tree `edc3f23b…` equals 70dc204's tree, so no runbook text could change between the two.
  - `.runbooks/` at 389ecf6 holds exactly 5 files.
- **Independent comparator** (`copy_compare.py`, written for this audit). It works forward from ES: it makes each relative link absolute and compares every body line, text outside links included. It also checks:
  - line 3 links the ES path on `trunk_dev`;
  - the "Copied" line names `389ecf6` with the correct path;
  - there are no carriage returns;
  - no reference-style or HTML links are left unconverted.

  I first showed that it catches a one-character text change, a link into the wrong folder, and an added trailing newline.
- **The real check, run here against GitHub ES:** at `trunk_dev`, `389ecf6` and `70dc204`, and at `ae9aa65` as a negative control.
- **The CI run on 6a6f5c7:** the job log was read (`get_job_logs`).
- **Tests.**
  - The 25 tests here.
  - Audit 04's 12 mutants, plus 4 new ones (M13–M16), against the 6a6f5c7 tests and against the 795a00f tests.
  - Both test files run on a case-insensitive file system that keeps letter case (ciopfs, FUSE).
- **The link check** (audit 02's `ar_linkcheck.py`) against ES 389ecf6.
- **The leak scan** and `git diff --check` of the delta.
- **The open ES PRs** were checked for changes under `.runbooks/`.
- **Not inspected:**
  - GitHub's rendering;
  - a real Mac (APFS), since the case-insensitive run used ciopfs on Linux;
  - Python 3.10–3.12, since I used Python 3.13.18 here and the runner used its own Python 3;
  - the ES and IM merges themselves, beyond the tree equality above. They are outside this brief.

## Findings

None blocking.

### Audit 04's observations

- **O04-1: closed.**
  - **M9** (links relative to a fixed `.runbooks/execution`) now fails 12 tests. Before, it failed none. The fixture's system-folder runbook now links `../execution/…Alpha.md`. The check turns the absolute link back with `relpath(target, es_dir)`, and with a fixed `es_dir` that gives `…Alpha.md` instead of `../execution/…Alpha.md`.
  - **M11** (`strip()`) is killed by `test_es_trailing_newline_only_fails` and `test_copy_trailing_newline_only_fails`.
- **O04-2: closed, and now verified.** I ran it on a case-insensitive file system that keeps letter case (ciopfs; writing `foo.MD` overwrote `Foo.md` and the listing kept `Foo.md`, as on APFS):
  - The **795a00f** `test_copy_named_with_wrong_case_fails` **fails** there. The `.MD` write reused the `.md` file, and the check exited 0. This confirms audit 04's inference.
  - The **6a6f5c7** version passes there, with all 25 of 25 passing.

  This was on Linux FUSE, not on a Mac (`case_insensitive_fs_runs.txt`).
- **O04-3: closed, though no change was required.** `test_names_match_case_sensitively_on_every_platform` patches `os.path.normcase` to lowercase. `fnmatch.fnmatch` looks that function up at call time, so M3 now fails the test, and `fnmatchcase` never calls it. The patch is undone when the `with` block ends.

### Observations (no change required)

- **O05-1, test strength: two new mutants that I made survive.** The code is correct today. This is not a request for another round.
  - **M14** (`actual.lstrip() == expected.lstrip()`): no test changes only leading whitespace in an ES file. It matters only if an ES runbook gained leading blank lines or spaces. A copy itself cannot start that way, because its title must be line 1.
  - **M16** (the copy-side wrong-case rule narrowed to names ending `.MD`): the only test for that rule uses `.MD`. Audit 04's probes showed that the real rule also catches `.Md` and a lowercase prefix.

  The test file's docstring claims only what the tests do catch, so nothing it says is wrong.
- **O05-2, pre-existing design: the check does not verify the "Copied word for word on … commit" line.** The real check reports 0 problems against `70dc204` as well as against `389ecf6`. A copy whose note still named the old commit would therefore pass, as long as its text equals ES `trunk_dev`. The note is informational, and the check guarantees the text, which is what matters. In this PR, my comparator confirmed that every note names `389ecf6` with the right path. I record it so nobody reads the check as covering that line.

## What I verified as correct

- **The copies' delta:** the word diff of `795a00f..6a6f5c7` over `*.md` has exactly 10 changed words. In each of the five files, the old `` [`70dc204`](…/blob/70dc204a…/<path>) `` became `` [`389ecf6`](…/blob/389ecf66…/<path>) ``, with the same path. No other byte changed.
- **Copies against ES 389ecf6** (`copy_compare_389ecf6.txt`): 5 of 5 OK. Body line counts are 388, 336, 205, 305 and 545, with 1, 8, 5, 3 and 10 links. All relative links (26) were made absolute as their own folder requires, and the bring-up's one anchor link (`#what-do-the-failures-mean`) was left alone. Control run against 70dc204: each file fails only on the "Copied" line.
- **The real check** (`real_check_runs.txt`): against `trunk_dev` and `389ecf6`, "5 runbooks among 5 files under .runbooks/, 5 copies here, 0 problem(s)", exit 0. Against `70dc204`, also 0 problems (see O05-2). Against `ae9aa65`, 6 problems and exit 1, as audit 04 saw.
- **CI** (`ci-45718294101-lines.txt`): run 45718294101 (event `pull_request`, head 6a6f5c7), job `compare` 139569886588, 23:03:19–29Z, conclusion **success**.
  - It checked out `pull/13/merge` = `86cedab`, whose tree equals the tip's.
  - "Test the check itself": "Ran 25 tests … OK". All 25 names are listed, and the 4 new ones are among them.
  - "Compare each copy…": five `OK` lines, then "Execution-Substrate trunk_dev (389ecf6): 5 runbooks among 5 files under .runbooks/, 5 copies here, 0 problem(s)". This is the first run on AR #13 in which the compare step passes.
- **The new tests, read against the check:**
  - `test_links_turn_back_relative_to_each_runbook_folder`: the fixture copy holds the absolute `.runbooks/execution/…` link, the base passes, and the same link pointed into `.runbooks/system/` fails with one error.
  - The two trailing-newline cases: in ES, the actual text has one more `\n`; in the copy, the expected text keeps the extra `\n`, because `"\n".join` preserves it. Each gives one "differs" error.
  - The changed wrong-case case: `ar_dir` removes the `.md` copy before it writes `.MD`, because dicts keep insertion order. It asserts that the `.MD` name is listed and expects two errors: the wrong-case name, and the missing copy. `glob("*.md")` matches names case-sensitively, so `.MD` is never taken for a copy. That is observed on Linux, including on the case-insensitive file system. For macOS it is an inference: CPython's `posixpath.normcase` does not change letter case there.
- **Tests here:** 25 of 25 pass at 6a6f5c7 (`python3 -I -B`, `ar_tests_6a6f5c7.txt`). The clone held only the patch's 9 paths afterwards, with `--ignored` included.
- **Mutants** (`check_mutants.py`; M1–M12 are audit 04's, unchanged, and M13–M16 are mine):

  | Tests at | Killed | Survived |
  |---|---|---|
  | 6a6f5c7 (`check_mutants_results_6a6f5c7.txt`) | M1–M13 and M15, with each failing test named | M14 and M16 (O05-1) |
  | 795a00f (`check_mutants_results_795a00f_tests.txt`) | 10 of 16 | M3, M9, M11, M13, M14 and M16 |

  So the new tests kill exactly M3, M9, M11 and M13. The check itself is byte-identical at both commits.
- **Links** (`ar_linkcheck_6a6f5c7.txt`): 68 links in README.md and the five copies, 0 problems. This covers the new `389ecf6` commit links, each of which resolves to a blob at that commit.
- **Leak scan:** I searched the 52 added lines for IPv4 addresses, home paths, email addresses, `ghp_`, `github_pat_`, `sk-` and `AKIA` prefixes, private-key headers, the words token, password, secret and API key, the box account and owner names, and `192.168.` and `10.0.`. There were no hits. The fixture address `check-test@example.invalid` was already there at 795a00f and is not among the added lines. `git diff --check` is clean.

## Validation

All runs in this audit container: Linux amd64, Python 3.13.18, git 2.43.0, as root, on a fresh clone of the exact commit.

| What | Result |
|---|---|
| v2 manifest (opening, closing) | `9d1f7149…10f4`, identical to the writer's, both times |
| AR tests at 6a6f5c7 | 25/25 OK |
| AR tests at 6a6f5c7 on a case-insensitive file system (ciopfs) | 25/25 OK |
| AR tests at 795a00f on the same file system | 20/21: `test_copy_named_with_wrong_case_fails` fails (O04-2 confirmed) |
| Mutants M1–M16 with the 6a6f5c7 tests | 14 killed, M14 and M16 survive |
| Mutants M1–M16 with the 795a00f tests | 10 killed |
| Own comparator against ES 389ecf6 | 5/5 OK; its self-tests (text, link and trailing newline) all caught |
| Real check against GitHub ES `trunk_dev` / 389ecf6 / 70dc204 / ae9aa65 | 0 / 0 / 0 / 6 problems |
| Link check | 68 links, 0 problems |
| CI run 45718294101 | success (25 tests OK, compare 0 problems) |

Not run: a real Mac, and Python 3.10–3.12.

## Writer's claims (`05-merges-and-refresh.md`, PR body) checked

| Claim | Result |
|---|---|
| One fast-forward commit on 795a00f | Confirmed |
| Each copy changed in exactly one line | Confirmed |
| The two ES commits have the same tree | Confirmed |
| Manifest `9d1f7149…10f4`, 9 files, taken with HEAD at the base | Confirmed (reproduced byte for byte) |
| 25 of 25 pass | Confirmed |
| 12 of 12 mutants killed, 9 of 12 at 795a00f | Confirmed |
| M9 now fails 12 tests | Confirmed |
| 0 problems against `trunk_dev` 389ecf6 | Confirmed, here and in CI |
| 68 links, 0 problems | Confirmed |
| Leak scan clean | Confirmed |
| O04-2 holds on APFS, marked as an inference | Now verified on a case-insensitive file system that keeps letter case, though not on APFS itself |

The writer's statement that the daily check on `main` fails until AR #13 merges (cron 10:17Z) is plausible but was not re-run. Inference: `main` still holds the copies naming `70dc204`, and its older check lists only `.runbooks/execution/*.md`, so it would see the bring-up changes as drift.

## Remaining uncertainty

- The real APFS behaviour and Python 3.10–3.12 were not run here. The tests use no feature newer than 3.10 that I could see (`str | None` hints sit in the check, which CI and audit 04 already ran).
- If an ES PR that changes `.runbooks/` merges before AR #13, the compare step fails until the copies are refreshed again. Neither open ES PR does that today.

## Confidence

| | AR #13 |
|---|---|
| Provenance | 1.0 (reproduced byte for byte, opening equals closing) |
| Validation | 0.97 (tests, mutants, real check, own comparator and link check run here; CI green on the exact head; no real Mac) |
| Implementation | 0.97 (two surviving mutants of my own, O05-1; the code is correct) |

## Closeout

At 23:12Z:
- The audit clone holds only the patch's 9 paths, with `--ignored` included and no audit files in it.
- The upstream was re-pinned to `origin/main`, and the recipe hash was checked again.
- v2 was run twice. The closing manifest is **byte-identical** to the opening one.
- The mutant folders, the ciopfs mount and its backing folder were removed.
- PR head (6a6f5c7), AR `main` (44aa21a) and ES `trunk_dev` (389ecf6) were checked again just before publishing.

Sensitive material: none read or copied.

## Evidence

`05-audit-evidence/`:
- `repro_manifest.sh` and `manifest-ar.json` (canonical);
- `copy_compare.py`, `copy_compare_389ecf6.txt` and `copy_compare_70dc204_control.txt`;
- `real_check_runs.txt` (filtered to the summary and error lines);
- `ci-45718294101-lines.txt`;
- `ar_tests_6a6f5c7.txt`;
- `check_mutants.py`, `check_mutants_results_6a6f5c7.txt` and `check_mutants_results_795a00f_tests.txt`;
- `case_insensitive_fs_runs.txt`;
- `ar_linkcheck_6a6f5c7.txt`.

Report delivery: `/mnt/project-files/reports/docs/runbook-restructure/05-audit.md`. Its SHA-256 is given in the reply that delivers it, because this file cannot hold its own hash.

**Final verdict: ACCEPT** (AR #13 at `6a6f5c7b8772b423cc810416c029496dc7001bec`).
