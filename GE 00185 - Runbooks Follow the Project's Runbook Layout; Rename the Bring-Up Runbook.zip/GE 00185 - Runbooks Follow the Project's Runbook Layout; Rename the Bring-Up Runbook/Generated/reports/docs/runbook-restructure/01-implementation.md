# Runbook restructure: implementation report

Thread: "Restructure ES runbooks to house style" (cmsg_01Un4xQgjBAczV8DABQvcLrxB8QKE7xRMW8teBcjWYeN9K). Written 2026-11-25 ~21:00Z. Writer model: Opus.

## Objective and source of the ask

- David 2026-11-24 00:16Z (backlog.md, "Runbook structure"): the four `Governed Execution ES <Topic>.md` runbooks in ES should follow the structure of the other Archived-Runbooks runbooks. Fix them at the source, then the AR copies and the drift check follow.
- David 2026-11-24 01:32Z (backlog.md): fold in `.runbooks/system/v1_bringup.md`, which #37 missed. Rename it to the convention, and add it to the AR copies and the drift check.
- Reading taken: the bring-up gets the same layout treatment, not only the rename, because it becomes an AR copy and David's principle covers all ES-origin runbooks.

**Conflict to fix in a topic file (the coordinator is the writer):** `project-context/runbooks.md` still says "ES `.runbooks/system/v1_bringup.md` stays in ES under its name (ES tests, scripts and IM read that path)". David's 01:32Z decision supersedes it. Once these PRs merge, the line should say the bring-up is `.runbooks/system/Governed Execution ES System Bring-Up.md` and is copied to AR like the others.

## PRs (all draft)

| Repo | PR | Base | Topic branch | TIP | Tree | Files |
|---|---|---|---|---|---|---|
| Execution-Substrate | [#65](https://github.com/evo-agi/Execution-Substrate/pull/65) | `trunk_dev` ae9aa65322954be16d5d3e354dd0aeec5d87723d | claude/project-thread-0z4rtn | f7bac1a872048b975645d136b27dc2e2efc5f171 | 0c20431115a40dec2ae99e28c178fabbf63c826a | 18 (17 changed, the rename counts twice) |
| Infrastructure-Manager | [#3](https://github.com/evo-agi/Infrastructure-Manager/pull/3) | `trunk_dev` b2ca78f8d8aae00fdd732966202be6087a6797fe | claude/project-thread-0z4rtn | e728e023301cdd4ca1dff389fc416d4bafedebd6 | 5b1739ccbd5ec36adf21b2e7e7333dc8ef4e3986 | 1 |
| Archived-Runbooks | [#13](https://github.com/evo-agi/Archived-Runbooks/pull/13) | `main` 44aa21a3be15ed1a5b6bd38680596feb2c21e1ba | claude/project-thread-0z4rtn | 30c1196afdbe11791a2e185c7de2df81fee21d61 | eed8cf42299f7a4a4ff0eae1c0a39911569d3662 | 8 |

**PR classes.** I don't set the classes; they are for the coordinator to confirm.
- ES #65: docs, scripts and tests only.
- AR #13: docs and CI.
- IM #3: changes one string in `src/infra_manager/config.py`, which is product code. By the merge policy it needs a fresh audit and the gate, but no David. Inference: no red-team, because it is a trivial path constant and not a major PR.

**Merge order:**
1. ES #65.
2. IM #3.
3. Refresh AR #13's copies from the ES merge commit, re-run its check, then merge AR #13.

Between ES and AR merging, AR's daily drift check fails. AR #13's own PR check fails until ES #65 merges, by design.

## Provenance (v2 recipe, SHA-256 c08597e2…a3ca verified before the run)

Each manifest was taken twice and the two were identical. Method: from TIP, `git reset --mixed BASE`, upstream pinned to the base branch (origin/trunk_dev for ES and IM, origin/main for AR), then reset back to TIP. The tree was clean afterwards.

| Repo | textual_diff_sha256 | manifest_sha256 | file_count |
|---|---|---|---|
| ES | 7f3014bb36b39c37f5a9feffffff5bd168fdc6340397607093959b26d89d93d6 | e25db7ea46794fd01b4efe77befe95ca557aedf736449de0b0ca4c989dce8576 | 18 |
| IM | f9537c89d5ffa96091952cd609c1e3cd7b5dc8dee5a7566e894473240496fa61 | e081127b71b3c210cbf489e16353bf6aa80bed0d0f71257ad8306ae18899c308 | 1 |
| AR | 85a440d5ca2897ff82def0901fb2cf7788a334fccc2ff280a4cc007e31926c29 | da43ccc3a5e7a8af73d534b7c3cb15e0fe59042dac83ea4b00367bec3e30abdb | 8 |

The canonical manifests are in `manifests/` next to this file. Deviation from the runbook: the manifest was taken after the single commit, by resetting to BASE, rather than before committing. The tree content is the same either way.

## What changed

**ES #65**
- Layout: all five runbooks now use What is it? / What do I need? / How to use it? (numbered `###` steps with "Expect …" after commands) / Notes or What do the failures mean? / Test Evidence / History. Extra question sections follow AR's habit ("What does it prove?" in Vault Login, "What do the failures mean?" in Local Validation and the bring-up).
- The `Version` / `Last Updated` header lines became the first History entry. The other History entries come from `git log --follow` with PR numbers.
- The bring-up was composed by script (`compose_bringup.py` here) from verbatim line ranges of the original.
- Line check, original against new, all five files: every original line is present, except:
  - headings and header lines;
  - link targets of the renamed file;
  - sentences merged with a new "Expect" sentence (listed in the thread's working notes; examples: "Package it with:", "Run command examples from the repository root…", which became part of a longer line).
- Rename: `.runbooks/system/v1_bringup.md` becomes `.runbooks/system/Governed Execution ES System Bring-Up.md`. These files changed only the path:
  - `scripts/internal/operator_failures.sh` (the message now also quotes the path);
  - `scripts/70_diagnostics.sh` (usage text);
  - `scripts/70_linux_setup.sh` ("Next steps", quoted);
  - README;
  - four `.docs` files;
  - `docs_contract_test.go`, `caller_authentication_docs_contract_test.go`, `es/app/execution_loop_integration_test.go`, `es/app/operator_scripts_integration_test.go`.
- One test pin changed meaning: `## 5. Operator Troubleshooting Matrix` is now `## What do the failures mean?` plus the sentence "This is the operator troubleshooting matrix that the operator-facing scripts point to."
- Content fixes:
  1. Bring-up: "Successful output ends with `bring-up complete`" is false (`01_bringup.sh` lines 349-366 print profile, readiness, state dir and next lines after it). Now "includes … followed by …".
  2. Bring-up step 6: "That helper drives:" followed a paragraph about the 73 wrapper, but lists `60_execute_loop.sh` actions. The wrapper calls `60_execute_loop.sh` (`73_supported_local_proof.sh` lines 947 and 957), and the new sentence names it.
  3. Local Validation: the `vault` commands of step 3 run in the second terminal, but `VAULT_ADDR`/`VAULT_TOKEN` were exported only in the first. Step 2 now says to set them there.

**IM #3:** `EXECUTION_SUBSTRATE_REQUIRED_FILES` names the new path.

**AR #13**
- Five copies, regenerated by `make_copy.py` here, which asserts that each link turns back exactly. The bring-up copy is new.
- Note sentence dropped: "It keeps ES's own layout rather than this repository's, so that it stays a copy." The parts the check reads are unchanged.
- `check_es_runbook_copies.py`:
  - reads every `.md` under ES `.runbooks/` with `ls-tree -r`;
  - matches copies by basename;
  - turns links back relative to each ES file's own folder;
  - new failures: a name outside `Governed Execution ES <Topic>.md`, and two ES runbooks sharing a basename.
- Workflow comment and README updated: the bring-up row moves from "Runbooks in other repositories" to the ES table.

## Validation (cloud container; exact bytes = the TIPs above)

ES:
- `go test . -count=1` passes (whole root package), including:
  - `TestRunbookPathMentionsExist`
  - `TestMarkdownRelativeLinksResolve`
  - `TestTrancheAFilesystemAndResourceCustodyDocsContract`
  - `TestRetainedResultAuditF2CurrentClaimedRootRetentionDocs`
  - `TestARSStorageCheckDocsContract`
  - `TestCallerAuthenticationContractIsDocumentedOnce`
- `go test ./es/app -run 'TestBringupRunbookTroubleshootingMatrixListsCurrentFailureCategories|TestLinuxSetupScriptDocumentsSupportedProfileGuardrails'` passes.
- `go test ./scripts -run 'TestScriptsStartPythonInIsolatedMode|TestScriptsPythonIsolatedModeDocs|TestScriptsPythonIsolatedModeCheckFindsEachForm|TestRootScriptByNameOwnershipChangesStayCounted'` passes.
- `go vet . ./es/app` is clean. `bash -n` passes on the 3 scripts.
- These four tests run the operator scripts and check that the new path is in their failure output:
  - `TestPublishScriptCategorizesAuthorizationFailure`
  - `TestPrepareScriptCategorizesRuntimeConfigFailure`
  - `TestSubmitScriptCategorizesSubstrateFailure`
  - `TestDiagnosticsScriptRuntimeConfigCategoryBundleAcceptsSurfacedFailureLabel`

  All four pass when run without the container's proxy variables (`env -u HTTPS_PROXY -u HTTP_PROXY -u https_proxy -u http_proxy -u ALL_PROXY -u all_proxy go test ./es/app -run …`). With those variables set, curl sent the test's local HTTPS calls to the proxy, which gave "Connection reset by peer"; that failure is the same on unchanged trunk_dev ae9aa65. Also failing locally and unrelated (no ssh/scp): `TestRemoteAlphaOperatorP0vFacadeExecsOnlyFixedPythonRuntime`.
- CI on #65 at f7bac1a passed: "build, vet and test" (run 45699284315, finished 21:40Z) and "test on macOS" (run 45699284313, finished 21:23Z). The Linux job's 17 listed environment-only tests still fail as listed, the gate's expected outcome, and its 9 root tests in `scripts` passed.

IM:
- `PYTHONPATH=src python3 -m unittest discover -s tests`: 197 OK, before and after.
- `_missing_required(<ES at f7bac1a>, EXECUTION_SUBSTRATE_REQUIRED_FILES, …)` returns `[]`.

AR:
- Drift check against ES branch `claude/project-thread-0z4rtn` (f7bac1a): 5 runbooks, 5 copies, 0 problems.
- Against `trunk_dev` (ae9aa65): 6 problems, as expected before the merge.
- `probe_check.py` here: 14 of 14 cases as expected (one passing case, 13 failing ones).
- Link check of README plus the copies: 66 links, 0 problems.
- Leak scans of all three diffs: nothing found.

## Assumptions, guesses, non-claims

- The "Expect" lines are read from script code, and for `vault`/`openssl`, from the tools' usual output. **None of the five runbooks was run end to end for this change**, and each runbook's Test Evidence says so.
- Test Evidence in ES names CI tests. That they run and pass in the "build, vet and test" job is an inference: the CI gate fails on unlisted skips, and none of them is in `.github/ci/environment-only-tests.txt`. The PR's CI run is green (see Validation), which fits it; the job log shows only failures and the listed tests, so the individual PASS lines were not seen.
- Inference: IM's `up` already cannot pass without the retired Control Plane checkout, so the window between the ES and IM merges harms no live use.
- Not done: GitHub's rendering of the pages was not looked at; the box was not used.

## Follow-ups for the coordinator

- After ES #65 merges:
  - refresh AR #13's copies from the merge commit (one command with `make_copy.py`);
  - re-run its check;
  - fix `project-context/runbooks.md` (see above).
- Optional, for real Test Evidence: a box run of the static-script runbook as written, on the coordinator's box schedule.
