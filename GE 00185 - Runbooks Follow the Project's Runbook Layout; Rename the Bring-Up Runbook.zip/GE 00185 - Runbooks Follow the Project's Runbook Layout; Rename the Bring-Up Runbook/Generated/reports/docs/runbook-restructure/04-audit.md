# Runbook restructure: independent delta audit (ES #65, AR #13)

Auditor: fresh read-only audit thread "Recheck the runbook restructure fixes" (cmsg_01Un4xQgjBAczV8DABQvcLrxCKnSDPXyY3XLeWwPAFGfyC), started by the coordinator 2026-11-25 21:52Z. Model: Opus. This thread did not write or audit any earlier round. The coordinator's brief called this "audit 03" and asked for `03-audit.md`; the writer's `03-repair.md` already holds number 03 in this folder, so this report is `04-audit.md` (evidence in `04-audit-evidence/`). Inputs: the brief, `02-audit.md` (SHA-256 `9a658de2…8266` per project memory, not re-hashed), the writer's `03-repair.md`, the two PRs and the repos. The writer thread was not consulted.

## Verdicts

| PR | Audited commit | Verdict | Why |
|---|---|---|---|
| [ES #65](https://github.com/evo-agi/Execution-Substrate/pull/65) | `70dc204a80723f597e50318bcae59da0a59b0f8d` | **ACCEPT** | A02-1 closed (the sentence now links the CP consumer runbook itself, and a broken link fails `TestMarkdownRelativeLinksResolve`). O1 moved word for word. Nothing else changed. Both required checks green on 70dc204: "build, vet and test" and "test on macOS". |
| [AR #13](https://github.com/evo-agi/Archived-Runbooks/pull/13) | `795a00f423124b6cf5fed47aac45eed1a7dd3149` | **ACCEPT** | A02-2 closed: every path under ES `.runbooks/` is listed and judged by exact name. The 21 new tests pass here and on the runner, 5 of them fail on the old check, and all 27 probes behave as intended (the 2 that pass are meant to). Copies equal ES 70dc204. The compare step fails by design until ES #65 is on `trunk_dev`. |

Failing test names for blocking findings: none (no blocking findings). IM #3 is out of scope; its head is still `e728e02` (checked 22:04Z), so audit 02's ACCEPT still binds it.

**Merge gate note for AR #13:** this ACCEPT binds `795a00f` only. The planned refresh from the ES merge commit creates new bytes, so AR #13 needs a provenance delta check (manifest, diff limited to the "Copied word for word on" lines unless ES `trunk_dev` changed those files, the compare step green) before it merges. The two optional test additions under O04-1 fit in that same round.

**Effect status:** nothing pushed, no PR comment or review, nothing merged, no repo edits, no project-file edits other than this report and `04-audit-evidence/`. Repair, commit, push, PR changes and merge: not performed.

## Target identity and provenance

Recipe: `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` at 21:53Z on both the project file and the copy run (`/opt/audit/v2.py`).

| Repo | Base | Tip | Tree | manifest_sha256 | textual_diff_sha256 | Files |
|---|---|---|---|---|---|---|
| Execution-Substrate | `trunk_dev` `ae9aa65322954be16d5d3e354dd0aeec5d87723d` | `70dc204a…f49bc36` | `edc3f23b890e5dd523dcb4eadd0006d261f7cb86` | `dc37b73d927cb43b265075b7dfcb3147f7fc1b55d1e5464ca939d378e9e3011d` | `1d2c8d9c473fe329dd9a21728e99f3d9d03ab21b7cdbc33456250372f6eda34b` | 18 |
| Archived-Runbooks | `main` `44aa21a3be15ed1a5b6bd38680596feb2c21e1ba` | `795a00f4…dd3149` | `7535c50212064825c0851c72dea3ef92e066ba28` | `742cff00b41abdb3f1bc905672f01f6a0169ac89ab339d18caaee2cb47a40ccf` | `cac367494d68a866bf536f382c547767ba479a9a2a34e12f70314acc5bb60a08` | 9 |

Reproduction (`04-audit-evidence/repro_manifest.sh`, the audit 02 script, provenance §5.3): fresh clones under `umask 022`; pushed tip equals the reported tip; base is an ancestor; clean checkout of the tip; `git reset --mixed BASE`; upstream pinned to `origin/trunk_dev` (ES) or `origin/main` (AR); v2 run twice to two absent paths in a `0700` folder; `cmp` identical. Both canonical manifests are **byte-identical** to the writer's `manifests-r2/` files (no mode-bit differences). PR heads on GitHub equal the audited tips; bases unmoved (ES `trunk_dev` ae9aa65, AR `main` 44aa21a). Against audit 02's manifests, exactly these entries changed: ES 3 (the reference and static-script workload runbooks and the bring-up), AR all 9 (8 changed, plus the new test file). The full base-to-tip range is covered by provenance; review focused on the delta `f7bac1a..70dc204` (3 files, +14 −13) and `30c1196..795a00f` (9 files, +362 −40), as the brief asked.

## Coverage

- Both deltas read in full: the ES runbook edits; the AR check (whole file re-read, not only its diff), the new test file, the workflow, the five copies and the README paragraph.
- A02-1 and O1: before/after substance comparison of all five runbooks with audit 02's `substance_compare.py`, f7bac1a against 70dc204; the moved paragraph compared byte for byte; position words ("above", "below", "earlier", "step N") in the three changed files checked against the new order.
- A02-2: the 21 new tests run at 795a00f and against the old check; audit 02's probes re-run through the real `read_es` (local ES repo, `ES_URL=file://…`) plus 18 new probes; 12 mutants of the check run against its tests; the real check run against GitHub ES (PR branch, `70dc204`, `trunk_dev`).
- ES: root package at the tip; 8 targeted `es/app` tests; one link mutant; trial merges with the other open ES PRs, repeated after both moved (#64 `a0dc3c9` then `61db96c`, #63 `306c062` then `3919944`).
- AR link check (audit 02's `ar_linkcheck.py`) against ES 70dc204.
- CI on both PRs. Leak scan and `git diff --check` of both deltas.
- Not inspected: GitHub's rendering; no runbook run end to end; the box not used; the check's tests not run on macOS or under Python 3.10–3.12 here (Python 3.13 here; the runner's ubuntu-24.04 Python passed them).

## Findings

None blocking. Audit 02's findings:

- **A02-1: closed.** `…System Bring-Up.md:227` now reads "Use the canonical ES-side CP consumer runbook, [supported_local_cp_consumer_runbook.md](../../.docs/supported_local_cp_consumer_runbook.md)." The target exists; the line is under "### 4. Bring up the stack", which is what the History entry says ("step 4's pointer"). Mutant: changing the link to `../.docs/…` fails `TestMarkdownRelativeLinksResolve`. The AR copy (`…System Bring-Up.md:231`) carries the same sentence with the link made absolute to ES `trunk_dev`, and the check says it equals ES 70dc204.
- **A02-2: closed.** `read_es` lists `ls-tree -r -z --name-only FETCH_HEAD .runbooks/` and `main` fails every listed path whose file name is not exactly `Governed Execution ES <Topic>.md` (`fnmatchcase`). Probes P8 (`notes.txt`) and P9 (`Governed Execution ES Upper.MD`), exit 0 at 30c1196, now fail with exit 1 and one error each. The new tests `test_uppercase_md_runbook_fails` and `test_non_runbook_file_fails` pin them.
- **O1 (optional in audit 02): done, no content lost.** In both workload runbooks the four-line paragraph is now the first bullet under "## Notes" (reference `:321`, static script `:273`). Its text equals the base text with each line break followed by two spaces of indent, byte for byte; it appears once in each file. The reference runbook gained a "## Notes" heading between step 7 and Test Evidence, and its History layout list now names Notes. The substance comparison differs from f7bac1a's in exactly three lines: the two bullet-prefixed first lines and the corrected A02-1 sentence; code blocks unchanged in all five runbooks.

### Observations (no change required)

- **O04-1, test strength: two mutants survive the new tests.** M9 (links turned back relative to a fixed `.runbooks/execution` instead of each ES file's own folder) and M11 (`actual.strip() == expected.strip()`) pass all 21 tests. M9 is not silent in practice: the real compare against ES 70dc204 fails on the bring-up copy, whose links to `../execution/…` would come out wrong. M11 would let drift in leading or trailing whitespace alone pass. The code is right today; only the test file's line "The cases cover every rule in the check's docstring" is a little broad. If the writer wants it, two cases close both, and they fit in the refresh round AR #13 needs anyway: a system-folder runbook that links to an execution-folder runbook, and a change of only a trailing newline.
- **O04-2, Inference (not run on a Mac): one test assumes a case-sensitive file system.** `test_copy_named_with_wrong_case_fails` writes `…Alpha.MD` next to `…Alpha.md`. On a case-insensitive file system (default macOS APFS) that reuses the existing file, so no wrong-case name exists and the test would fail. CI runs only on ubuntu-24.04, so no effect there; the docstring says only git and Python are needed. Confirm on a Mac, or skip that case when the temp folder is case-insensitive.
- **O04-3, M3 (`fnmatch` for `fnmatchcase`) survives**, because on Linux both are case-sensitive; the change to `fnmatchcase` matters only on Windows. Nothing to do.
- **O04-4, fail-closed edges.** A convention-named symlink (p11) or gitlink (p20) under `.runbooks/` is treated as a runbook and asks for a copy; `.runbooks` itself as a symlink (p22) gives "no runbooks"; a mode-only change (p19) passes, as copies compare bytes, not modes. On the AR side, a stray `Governed Execution ES Extra.markdown` (a2) passes: the copy-name rule catches only letter-case variants of `*.md`. No drift can hide that way, because the ES-side rule still requires the exactly named copy (a4).
- Audit 02's O6 (nothing checks IM's required-file list against ES) and O7 (stale project facts; Archived-Runbooks is private) still stand; both are the coordinator's.

## What I verified as correct

- **ES delta**: only the A02-1 sentence, the O1 move and three History entries (each says what moved and why; "Two sentences" became "Three"). `git diff --check` clean.
- **AR check**: the listing sees every blob, symlink and gitlink under `.runbooks/` at any depth, with names unquoted (`-z`); only convention-named files are read; the duplicate-name and missing-copy rules use only convention-named files, because everything else already fails; the new copy-side rule fails a top-level file whose name matches the convention only when letter case is ignored. Docstring, workflow comment and README paragraph say the same thing as the code.
- **Tests**: 21 of 21 pass at 795a00f (`python3 -I -B`, no files left behind, tree clean, `--ignored` included). Against the 30c1196 check, exactly 5 fail: `test_copy_named_with_wrong_case_fails`, `test_exact_copies_pass` (only its summary-line assertion), `test_non_runbook_file_fails`, `test_runbook_without_extension_fails`, `test_uppercase_md_runbook_fails`, as the writer reports. They use a real `git fetch --filter=blob:none` from a local repo, so they exercise `read_es` itself, which audit 02's stubbed probe could not.
- **Mutants** (`check_mutants_results.txt`): 9 of 12 are killed, each by the tests named for its rule (listing only `.md`; convention rule removed; copy-side rule removed; duplicate rule removed; CR rule removed; no `-r`; missing-copy rule removed; note-path rule removed; copy-without-ES-file rule removed). Survivors: O04-1 and O04-3.
- **Probes** (`drift_probe_results_795a00f.txt`; ES base 70dc204, AR files from 795a00f): audit 02's P2–P10 all exit 1 with the expected error, P8 and P9 included. The new probes all fail closed except p19 and a2, which are meant to pass: convention-named symlink, non-convention symlink, `.gitkeep`, a folder named `Governed Execution ES Dir.md/` holding `x.txt`, a trailing space, `.Md` on the real bring-up (2 errors), a lowercase prefix, `.md.bak`, two gitlinks, `.runbooks` as a symlink, an empty topic, `.MD` on both sides (2 errors), a lowercase duplicate copy, a symlinked copy, a copy renamed `.MD`. The same probes against the 30c1196 check: P8, P9, p12, p13, p14, p15, p18, p21 and p23 pass silently (`drift_probe_results_old_check_30c1196.txt`).
- **Real check against GitHub ES** (`real_check_runs.txt`): PR branch and `70dc204`: 5 runbooks among 5 files, 5 copies, 0 problems, exit 0. `trunk_dev` `ae9aa65`: 6 problems, exit 1, the same 6 the writer and the runner report.
- **AR links**: 68 links in README plus the five copies, 0 problems (two more than audit 02: the new inline link and the README link to the test file).
- **Leak scan** of added lines (ES 14, AR 362): only `check-test@example.invalid` in the tests; "David" in the README paragraph was already there at 30c1196. No address, home path, account name, token or key.

## Validation

All runs in this audit container (Linux amd64; Go 1.26.5 toolchain fetched per `go.mod`; Python 3.13.18; git 2.43.0; as root), on worktrees of the exact commits.

| What | Result |
|---|---|
| ES `go test . -count=1` at 70dc204 | package ok, 175 pass, 0 fail, incl. `TestMarkdownRelativeLinksResolve`, `TestRunbookPathMentionsExist`, `TestRetainedResultAuditF2CurrentClaimedRootRetentionDocs`, `TestTrancheAFilesystemAndResourceCustodyDocsContract` |
| ES `go test ./es/app` 8 runbook-path tests, proxy variables unset | 6 pass (`TestBringupRunbookTroubleshootingMatrixListsCurrentFailureCategories`, `TestLinuxSetupScriptDocumentsSupportedProfileGuardrails`, `TestPublishScriptCategorizesAuthorizationFailure`, `TestPrepareScriptCategorizesRuntimeConfigFailure`, `TestSubmitScriptCategorizesSubstrateFailure`, `TestDiagnosticsScriptRuntimeConfigCategoryBundleAcceptsSurfacedFailureLabel`); 2 skip here, need Nomad/Docker (`TestLifecycleScriptCategorizesExecutionFailure`, `TestExecuteLoopScriptFailureSummary`) |
| ES link mutant (bring-up link to `../.docs/…`) | `TestMarkdownRelativeLinksResolve` fails |
| ES root package on trial merges (git's own clean merges) | first at 22:01Z with 70dc204+#64 `a0dc3c9`: 176 pass, 0 fail (incl. #64's `TestAuthorityOrderIsStatedOnlyInAgents`); +#63 `306c062`: 175/0; +both: 176/0. Both heads moved before publishing, so again at 22:56Z with #64 `61db96c` and #63 `3919944` (both still on base ae9aa65): 176/0, 175/0, 176/0 |
| AR tests at 795a00f | 21/21 OK |
| AR new tests against the 30c1196 check | 5 fail (names above) |
| AR mutants | 9 of 12 killed (O04-1, O04-3) |
| AR probes | 28 runs, all as intended |
| AR real check vs ES | 0 problems vs PR branch and 70dc204; 6 vs `trunk_dev` |
| AR link check | 68 links, 0 problems |

Not re-run: the full `./scripts` and `./es/app` packages (the delta touches only Markdown; audit 02 ran `./scripts` on f7bac1a, and CI runs both).

**CI on ES #65 (head 70dc204):** both required checks **green**. "build, vet and test" (run 45707815245, job 139534185359, completed 22:34:56Z): build, vet, vet for macOS, gate self-check ("Ran 145 tests", OK), then "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed"; the 14 self-skips are 9 in `scripts`, 2 in `reliablesubmit` and 3 in `es/admission`, **none in `es/app`**, and the gate says `es/app` "go test skipped exactly the listed tests of this package (3), each once". So every `es/app` test the runbooks' Test Evidence names ran and passed on the runner; root package `execution-substrate` ok. "all 17 listed tests still fail on this host"; "tests as root passed: 9 of execution-substrate/scripts". Same shape as audit 02's run on f7bac1a. "test on macOS" (run 45707815344, job 139534186143) completed green at 22:14:41Z. Gate lines in `04-audit-evidence/ci-45707815245-gate-lines.txt`.

**CI on AR #13 (head 795a00f):** run 45707895979, job `compare`: step "Test the check itself" **success** (21:50:05–06Z); step "Compare each copy…" failure with "Execution-Substrate trunk_dev (ae9aa65): 4 runbooks among 5 files under .runbooks/, 5 copies here, 6 problem(s)", by design until ES #65 merges.

## Merge order

Unchanged from audit 02: **ES #65, then IM #3, then refresh AR #13's copies from the ES merge commit, delta check, merge AR #13.** ES #65 still merges cleanly with #64 (`61db96c`) and #63 (`3919944`) at their heads as of 22:56Z, and the root package passes on each merge, so whichever lands first, the next needs only the sync-only check.

## Confidence

| | ES #65 | AR #13 |
|---|---|---|
| Provenance | 1.0 (reproduced byte for byte) | 1.0 |
| Validation | 0.95 (root, targeted `es/app`, link mutant and trial merges run here; CI ran the Nomad/Docker tests and showed no `es/app` self-skips) | 0.95 (tests, probes and real check run here; runner ran the tests; compare cannot pass before ES merges) |
| Implementation | 0.97 | 0.95 (two surviving mutants, O04-1) |

## Closeout

At 22:05Z, and again at 22:57Z after the second set of trial merges: all audit worktrees (ES base, f7bac1a, tip, link mutant, six trial merges; AR 30c1196 and tip) removed and pruned. Just before publishing (22:56Z) the PR heads still equal the audited commits and the bases have not moved (ES `trunk_dev` ae9aa65, AR `main` 44aa21a). The probe repo, mutant copies and scratch live outside the clones. Upstreams re-pinned, v2 run twice again in each audit clone: the closing canonical manifests of ES and AR are **byte-identical** to the opening ones. No ignored or untracked files in either clone other than the patch's own. The trial-merge commits exist only as unreferenced objects in the audit clone, never pushed.

Sensitive material: none read or copied. The leak scan looked only at added diff lines.

## Evidence

`04-audit-evidence/` next to this file: `repro_manifest.sh`, `manifest-es.json`, `manifest-ar.json` (canonical, identical to `manifests-r2/`), `substance_compare_results_70dc204.txt`, `ar_tests_795a00f.txt`, `ar_tests_new_tests_on_old_check_30c1196.txt`, `check_mutants.py`, `check_mutants_results.txt`, `ci-45707815245-gate-lines.txt`, `drift_probe_build.sh`, `drift_probe_runner.py`, `drift_probe_run_all.sh`, `drift_probe_results_795a00f.txt`, `drift_probe_results_old_check_30c1196.txt`, `real_check_runs.txt`.
