# Runbook restructure: repair after audit 02

Thread: "Restructure ES runbooks to house style" (cmsg_01Un4xQgjBAczV8DABQvcLrxB8QKE7xRMW8teBcjWYeN9K). Written 2026-11-25 ~21:55Z. Writer model: Opus. Answers `02-audit.md` (A02-1 and A02-2, both Low) as the coordinator relayed them at 21:44Z.

## New heads (one commit added on each branch; no rebase, no force-push)

| Repo | PR | Base (unchanged) | Previous head | New head | Tree | manifest_sha256 | textual_diff_sha256 | Files |
|---|---|---|---|---|---|---|---|---|
| Execution-Substrate | [#65](https://github.com/evo-agi/Execution-Substrate/pull/65) | `trunk_dev` ae9aa65322954be16d5d3e354dd0aeec5d87723d | f7bac1a | **70dc204a80723f597e50318bcae59da0a59b0f8d** | edc3f23b890e5dd523dcb4eadd0006d261f7cb86 | dc37b73d927cb43b265075b7dfcb3147f7fc1b55d1e5464ca939d378e9e3011d | 1d2c8d9c473fe329dd9a21728e99f3d9d03ab21b7cdbc33456250372f6eda34b | 18 |
| Archived-Runbooks | [#13](https://github.com/evo-agi/Archived-Runbooks/pull/13) | `main` 44aa21a3be15ed1a5b6bd38680596feb2c21e1ba | 30c1196 | **795a00f423124b6cf5fed47aac45eed1a7dd3149** | 7535c50212064825c0851c72dea3ef92e066ba28 | 742cff00b41abdb3f1bc905672f01f6a0169ac89ab339d18caaee2cb47a40ccf | cac367494d68a866bf536f382c547767ba479a9a2a34e12f70314acc5bb60a08 | 9 |
| Infrastructure-Manager | [#3](https://github.com/evo-agi/Infrastructure-Manager/pull/3) | unchanged | e728e02 | e728e02 (no change; audit 02 ACCEPT stands) | | | | |

Manifests: recipe v2, SHA-256 c08597e2…a3ca checked with `sha256sum -c` before the run. Method as in `01-implementation.md`: from the new head, `git reset --mixed BASE`, upstream pinned to `origin/trunk_dev` or `origin/main`, two runs to fresh paths in a `0700` folder, `cmp` identical, then reset back to the head (tree clean). Canonical files: `manifests-r2/` next to this file. The first-round manifests in `manifests/` are kept.

The delta to audit is `f7bac1a..70dc204` (3 files) and `30c1196..795a00f` (9 files).

## A02-1 (ES and the AR copy)

- Bring-up step 4, the sentence "Use the canonical ES-side CP consumer runbook linked above." now reads "Use the canonical ES-side CP consumer runbook, [supported_local_cp_consumer_runbook.md](../../.docs/supported_local_cp_consumer_runbook.md)." I linked it inline rather than writing "under Notes", so the reader doesn't have to jump. The Notes bullet stays.
- The bring-up's History entry for the restructure now says three sentences were corrected, and names this one.
- No test pins the sentence. `TestMarkdownRelativeLinksResolve` checks the new link.

## Observation O1, fixed in the same round

The auditor marked it optional. I fixed it because it is a Low readability issue in the same files, and the project rule is to fix Low nits in the PR.

- In the static-script and reference workload runbooks, the paragraph "Inspect retained staging whenever exclusive run-root creation may have occurred. …" moved from "### 7. If a helper fails" to Notes, as one bullet. Its four lines are unchanged apart from the bullet marker and the indentation.
- The reference runbook had no Notes section, so it gains one, and its History layout list now includes Notes.
- Each runbook's restructure History entry says why it moved: the note applies after a success too.
- No test pins the paragraph (searched `*_test.go` for its sentences).

Observations O2 to O5 need no change. **O6** (nothing checks IM's `EXECUTION_SUBSTRATE_REQUIRED_FILES` against a real ES checkout) is a backlog candidate for the coordinator. It is outside these PRs. **O7** is the coordinator's to update (`runbooks.md:12`, `backlog.md:8`, and the brief's word "public" for Archived-Runbooks, which is private).

## A02-2 (AR drift check)

`.github/scripts/check_es_runbook_copies.py`:

- `read_es` now lists every entry under ES `.runbooks/` (`ls-tree -r`), whatever its name or type. It returns `(commit, all paths, {path: text})` and reads only the paths whose file name follows the convention.
- In `main`, every listed path whose file name is not exactly `Governed Execution ES <Topic>.md` fails. The message says that letter case and `.md` count, and says to rename the file in ES or move it out of `.runbooks/`. So `.MD`, `.markdown`, a name without an extension, `notes.txt` and `.runbooks/README.md` all fail closed, as the audit asked.
- Names are matched with `fnmatch.fnmatchcase`, not `fnmatch.fnmatch`, so the result is the same on every platform. Before, `fnmatch` was case-insensitive on Windows.
- Same idea on the copy side: a top-level file here whose name matches the convention only when case is ignored (for example `Governed Execution ES Alpha.MD`) fails with "is named like a copy but not exactly …". Before, it was ignored.
- The missing-copy and duplicate-name rules now take only convention-named ES files, since every other name already fails.
- The summary line now reads "N runbooks among M files under .runbooks/".
- The docstring, the workflow's header comment and the README paragraph say the same.

### Regression tests

New `.github/scripts/test_check_es_runbook_copies.py` (unittest, git and Python only, no network):

- It builds a local stand-in ES repo (with `uploadpack.allowFilter` on, so the real shallow, blob-filtered fetch and lazy `git show` run as against GitHub), one branch per case. It runs the check's own `main()` with `ES_URL` pointed at it, in a folder of copies made the way `make_copy.py` makes them.
- 21 cases:
  - one passing case;
  - the audit's probes: `Governed Execution ES Upper.MD` and `notes.txt`, plus a runbook without an extension and `.runbooks/README.md`;
  - the other ES-side rules: new runbook without a copy, one two folders deep, the same name in two folders, a rename outside the convention (two errors), one byte changed, a runbook moved to a new folder, no runbooks, an unreadable ref (exit 2);
  - the copy-side rules: a copy named with the wrong case, a carriage return, a note without "wins", a note without the copied line, a removed note, a note naming another file, a copy with no ES file, a missing copy.
- The workflow runs it as a new step, "Test the check itself", in the same `compare` job, before the compare step. It runs whenever the check does, and it gates through the same check run.

## Validation

- AR tests on 795a00f: 21 of 21 pass (`python3 -I -B .github/scripts/test_check_es_runbook_copies.py`, Python 3.13 here; the runner's ubuntu-24.04 Python 3.12 meets the 3.10 minimum).
- The same tests against the previous check (`30c1196`), to show they catch A02-2: 5 fail.
  - `test_uppercase_md_runbook_fails` and `test_non_runbook_file_fails` (the audit's probes: exit 0, no error);
  - `test_runbook_without_extension_fails`;
  - `test_copy_named_with_wrong_case_fails`;
  - `test_exact_copies_pass` (only its summary-line text differs).
- AR drift check against ES branch `claude/project-thread-0z4rtn` (70dc204): 5 runbooks among 5 files, 5 copies, 0 problems, exit 0. Against `trunk_dev` (ae9aa65): 6 problems, exit 1, as before the merge.
- Link check (the auditor's `02-audit-evidence/ar_linkcheck.py`, ES at 70dc204): 68 links in README plus the five copies, 0 problems. That is two more than before: the new inline link in the bring-up copy, and the README link to the test file.
- ES on 70dc204:
  - `go test . -count=1`: ok (root package, including `TestMarkdownRelativeLinksResolve` and `TestRunbookPathMentionsExist`);
  - `go test ./es/app -run 'TestBringupRunbookTroubleshootingMatrixListsCurrentFailureCategories|TestLinuxSetupScriptDocumentsSupportedProfileGuardrails|TestPublishScriptCategorizesAuthorizationFailure'`, proxy variables unset: ok.
- Workflow YAML parses (`yaml.safe_load`).
- Leak scan of the added lines of both deltas: nothing. The only hit was "David" in the README paragraph, which was already there and follows that README's own convention, in a private repository.
- AR CI on 795a00f (run 45707895979): the new step "Test the check itself" passed on the runner, since the compare step after it ran. The compare step failed with the expected 6 problems against ES `trunk_dev` ae9aa65, as the PR body and its comment say.
- ES CI on 70dc204: "build, vet and test" (run 45707815245, finished 22:34:56Z) and "test on macOS" (run 45707815344, finished 22:14:41Z) both green. The PR is mergeable (clean), and its base is still ae9aa65.

## Not done, and non-claims

- None of the runbooks was run end to end. GitHub's rendering was not looked at. The box was not used.
- The AR copies now name ES commit 70dc204, a branch commit. As planned, they get refreshed again from the ES merge commit before AR #13 merges. That refresh only changes the "Copied word for word on" line, unless ES `trunk_dev` changes those files in the meantime.
