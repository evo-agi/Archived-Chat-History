# Runbook restructure: ES and IM merges, AR refresh

Thread: "Restructure ES runbooks to house style" (cmsg_01Un4xQgjBAczV8DABQvcLrxB8QKE7xRMW8teBcjWYeN9K). Written 2026-11-25 ~23:15Z. Writer model: Opus. Answers the coordinator's relay of 22:58Z, which followed delta audit 04 (`04-audit.md`: ACCEPT for ES #65 at 70dc204 and AR #13 at 795a00f; IM #3 accepted in audit 02).

## Merges

| PR | Class and authority | Gate checks | Merge | Post-merge bytes |
|---|---|---|---|---|
| [ES #65](https://github.com/evo-agi/Execution-Substrate/pull/65) | docs, scripts and tests only; the project instructions let these merge without David once the audit and the gate pass | ACCEPT in `04-audit.md`. Head 70dc204 equals the audited commit. Base `trunk_dev` still ae9aa65, so the branch was up to date and needed no update. "build, vet and test" and "test on macOS" both green on 70dc204. Merged with `expectedHeadSha` 70dc204. | squash (the repo's usual style), **`389ecf66bd8828fafc9591111f14628cb86ce7fb`**, parent ae9aa65 | Merge tree `edc3f23b…` equals the audited tree, and the diff between 70dc204 and 389ecf6 is empty. All 18 manifest paths (`manifests-r2/Execution-Substrate.json`) match by SHA-256 and mode, and `v1_bringup.md` is absent. |
| [IM #3](https://github.com/evo-agi/Infrastructure-Manager/pull/3) | one string in `src/infra_manager/config.py`, product code. Merged under the standing rule for product PRs after David's first three: fresh correctness audit (audit 02, ACCEPT) plus the merge gate. No red-team: a one-line path constant is not a major PR under the red-team scope. | Head e728e02 equals the audited commit. Base `trunk_dev` still b2ca78f. IM has no CI. Before the merge, `_missing_required(<ES at 389ecf6>, EXECUTION_SUBSTRATE_REQUIRED_FILES, …)` returned `[]`. Merged with `expectedHeadSha` e728e02. | squash, **`9623f5c59d4290ff0e07d9ffd46b2f20e0c246aa`**, parent b2ca78f | Merge tree `5b1739cc…` equals the audited tree, and the diff is empty. `config.py` SHA-256 `9710575b…7337` equals the manifest. |

Both PRs were drafts and were marked ready just before their merge. Both source branches are left to the repos' auto-delete of merged branches.

## AR #13: refresh and test additions

New head **`6a6f5c7b8772b423cc810416c029496dc7001bec`** (tree `b5ab089c929c968b084587e1a3a8134e20806038`). Base `main` is still 44aa21a. It is one fast-forward commit on top of 795a00f.

| | |
|---|---|
| manifest_sha256 | `9d1f71491cd24b6986b8c5ff6e21a691aaa886d16e74479e0cd80890ce1d10f4` |
| textual_diff_sha256 | `d1b3503814d64a243f116842f151fdb72cac513cf5c9c2fdb6d64431459d3842` |
| files | 9 (the committed tree matches the manifest path for path) |
| canonical file | `manifests-r3/Archived-Runbooks.json` |

The manifest was taken as provenance §5.5 says: recipe hash checked first, then HEAD reset to the base with `--mixed`, upstream pinned to `origin/main`, two identical runs, and reset back before the commit. This round follows §5.5 exactly, unlike round 1, which took the manifest after the commit.

Delta `795a00f..6a6f5c7`, 6 files:

- **Copies:** the five copies are refreshed from ES `trunk_dev` 389ecf6 with `make_copy.py`. Each copy changed in exactly one line, the "Copied word for word on" line (`70dc204` → `389ecf6`, with that commit's link). The two ES commits have the same tree, so nothing else could change.
- **Tests** (`.github/scripts/test_check_es_runbook_copies.py`, 21 → 25 cases):
  - **O04-1, M9** (links turned back relative to a fixed folder): the fixture's system-folder runbook now links to the execution-folder runbook. New `test_links_turn_back_relative_to_each_runbook_folder` checks that the copy holds the absolute `.runbooks/execution/…` link and passes. It also checks that the same link pointing into the wrong folder fails. M9 now fails 12 tests.
  - **O04-1, M11** (comparison with whitespace stripped): new `test_es_trailing_newline_only_fails` and `test_copy_trailing_newline_only_fails`. M11 now fails both.
  - **O04-3, M3** (`fnmatch` instead of `fnmatchcase`): new `test_names_match_case_sensitively_on_every_platform` patches `os.path.normcase` to lowercase, as on Windows. M3 now fails it. The audit said nothing needed to be done here; it took one small test.
  - **O04-2** (a case-insensitive file system): `test_copy_named_with_wrong_case_fails` now removes the correct copy before writing the `.MD` one, checks that the `.MD` name is listed, and expects two errors: "named like a copy" and the missing copy. **Inference, not run on a Mac:** on APFS the `.MD` file is now a new entry, not the old file, so the test holds there too.
  - The docstring says what audit 04 found and that the cases run on both kinds of file system.

## Validation

- Tests: 25 of 25 pass (`python3 -I -B`, Python 3.13).
- Audit 04's 12 mutants (`04-audit-evidence/check_mutants.py`, with its two hard-coded paths made arguments): **12 of 12 killed**. At 795a00f, 9 of 12 were killed.
- Drift check against ES `trunk_dev` (389ecf6): 5 runbooks among 5 files under `.runbooks/`, 5 copies, **0 problems**, exit 0.
- Link check (`02-audit-evidence/ar_linkcheck.py`, ES at 389ecf6): 68 links, 0 problems.
- `git diff --check`: clean. Leak scan of the added lines: nothing.
- AR CI on 6a6f5c7: `compare` (run 45718294101, finished 23:03:29Z) passed. Both steps are green: the 25 tests, then the compare against ES `trunk_dev`. This is the first green run of this check on AR #13.
- Codex reviewed ES #65 at 70dc204 when it was marked ready, a few seconds before the merge. The review completed at 23:01Z with no findings (`has_any_findings: false`).

## Next

- AR #13 needs a delta check of `795a00f..6a6f5c7` before it merges (audit 04: "this ACCEPT binds `795a00f` only"). It stays a draft until then.
- Until AR #13 merges, AR's daily check on `main` fails (cron 10:17Z), because `main` still has the old copies. Merging before 10:17Z avoids any scheduled failure.
- The coordinator's items still stand:
  - O6: nothing checks IM's required files against ES; backlog candidate.
  - O7: update `project-context/runbooks.md:12` and `backlog.md:8`, and the "public" wording for Archived-Runbooks, which is private.
  - Record the ES and IM merges in `state.md`.

## AR #13 merge (added 2026-11-25 ~23:20Z)

Audit 05 (`05-audit.md`) is ACCEPT for AR #13 at 6a6f5c7. The coordinator asked for the merge at 23:15Z.

**Authority.** The project instructions let threads add or update runbooks on Archived-Runbooks `main` after a leak scan, a link check and a note on what was run. The check script, its tests and the workflow in this PR exist only to keep those runbook copies honest. The daily check itself came in through AR #4.

**Gate.**
- The PR head, 6a6f5c7, equals the audited commit.
- Base `main` was still 44aa21a, so `main` is an ancestor of the head and the branch needed no update.
- ES `trunk_dev` was still 389ecf6.
- `compare` (run 45718294101) was green on 6a6f5c7.
- The PR was marked ready, then squash-merged with `expectedHeadSha` 6a6f5c7.

**Merge:** **`a20bcd8e06bf8252fad5a49af47301ecab793bf7`**, parent 44aa21a.

**Post-merge bytes:**
- The merge tree `b5ab089c…` equals the audited tree, and the diff from 6a6f5c7 is empty.
- All 9 manifest paths (`manifests-r3/Archived-Runbooks.json`) match by SHA-256 and mode.
- The workflow's push run on `main` (run 45720133542, 23:17Z) is green: 25 tests passed, and the compare against ES `trunk_dev` found 0 problems. So the daily check on `main` is green again, and no scheduled run failed in between.

**Leftover branches.** These cloud sessions cannot delete remote branches: the git proxy refuses, as `claude-limitations.md` records. The topic branch `claude/project-thread-0z4rtn` is still on Archived-Runbooks (6a6f5c7) and Infrastructure-Manager (e728e02), and David needs to delete it in the GitHub UI. ES's was deleted automatically.

**"Remote Alpha Claude Access" History line:** not needed. The runbook procedure asks for one only when a session changes the test box, and this thread never used the box.
