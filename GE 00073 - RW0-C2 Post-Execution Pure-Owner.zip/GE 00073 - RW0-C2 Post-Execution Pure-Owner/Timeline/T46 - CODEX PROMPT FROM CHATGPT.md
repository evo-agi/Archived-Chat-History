PROMPT_ID

RW0_POST_EXECUTION_V40_REVIEWER_SEPARATION_RECONCILIATION_V1

TITLE

Coordinator RW0 — replace the unsupported reviewer-identity attestation with a
pure operational reviewer-separation evaluation, then complete the canonical
post-execution audit package

ENGAGEMENT TYPE

Parent-only, local, read-only contract reconciliation.

Do not delegate to subagents or internal audit agents.

Do not edit repository files, generate repository artifacts, format, stage,
commit, push, create a branch or PR, merge, tag, release, deploy, fetch,
contact a remote/live system, install dependencies, execute tests, run
migrations, open or mutate an operator database, invoke a product worker/model,
or inspect/modify supporting repositories.

Do not issue an implementation prompt.

Print the complete substantive report inline. This engagement completes a
contract-audit package only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_POST_EXECUTION_V40_RECONCILIATION_BASELINE_MISMATCH

FIXED INPUT REPORT

Treat the immediately preceding Codex response as fixed input.

If supplied as a file, use:

RW0_Post_Execution_Canonical_Audit_Package_V40_Owner_Block_Report.txt

Expected identity:

size:
22406 bytes

SHA-256:
af818be672c7d21f1cb69c2453ce1f78284e6c245658fab2fb43760a7319935a

logical lines:
405

final newline:
absent

opening:
# Baseline and fixed input

closing token:
RW0_POST_EXECUTION_CANONICAL_AUDIT_PACKAGE_BLOCKED

If the fixed input differs, stop:

RW0_POST_EXECUTION_V40_RECONCILIATION_FIXED_INPUT_MISMATCH

ENGINEERING DECISION

The fixed report correctly refused to invent an undocumented external
reviewer-identity authority. Its proposed next step, however, assumes that the
accepted first-slice contract requires authenticated person, provider, account,
or principal separation.

That is not the frozen target.

The accepted target requires:

- a distinct review role;
- a distinct governed review invocation;
- a distinct review effect and delivery;
- exact candidate/capsule binding;
- read-only review posture;
- no author-effect authority;
- no Coordinator writer authority.

It does not currently require proof that the reviewer is a different human,
model family, provider, account, or cryptographic principal.

Therefore:

1. Do not designate a new external identity-governance owner.
2. Withdraw `ReviewerIndependenceAttestationV1` as an owner-authored identity
   attestation.
3. Preserve the V40 ordinal, but replace it with the pure derived value:

   `PostExecutionReviewerSeparationEvaluationV1`

4. Use the literal schema:

   `governed-execution.nwp-post-execution-reviewer-separation-evaluation.v1`

5. The local semantic owner is the proposed post-execution evidence owner
   contract in `_post_execution_evidence_values.py`.
6. The value is derived only from exact current C2A/C1 facts. It authenticates
   no source and asserts no human/provider/account identity.
7. A future stronger policy may require an owner-authored identity or provider
   separation attestation. That would be a separate versioned input and is not
   part of this tranche.

CURRENT SOURCE BASIS TO VERIFY

Ground this decision against the exact current baseline.

At minimum inspect and cite:

- `.docs/authority-boundaries.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/c2a-first-slice-semantic-protocol-contract.md`
- `.docs/worker-execution-boundary.md`
- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_c1_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py`
- `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py`
- the exact current C1 rank-12, rank-13, and rank-14 row/readback contracts

Verify rather than assume that:

- current `WorkerObservationV1` contains `source_kind`, `source_ref`, and
  `source_invocation_ref`;
- author worker observations are reconstructible through the exact rank-13
  worker-result binding and its rank-12 memberships;
- the review observation is reconstructible as a rank-12
  `independent_review_completed` observation;
- author and review effect/delivery/fence identities are reconstructible;
- the current owner relations bind both observation graphs to the same
  program/work/attempt/candidate/capsule lineage.

If any of those exact facts is unavailable, return the blocked token and name
the precise mechanical gap. Do not replace it with a new identity authority.

PRESERVED DECISIONS

Preserve all decisions already closed by the preceding source-owner
reconciliation:

1. The accepted two-context design.
2. Migration-0003 continues to use the T1 input-context seam.
3. Section 41 projection V2 and role-resolution V3 remain selected.
4. C1 remains exactly 15 kinds.
5. Current C2A/B1/B2/C1 meanings remain unchanged.
6. Validation and review bind current `WorkerObservationV1`.
7. Rank 14 uses the current generic C1 relation-binding row.
8. Candidate safe projection remains `sha1` only and excludes private entries.
9. Policy and risk remain owner-authored supplied attestations.
10. FiniteBacklog remains an adapter behind the generic risk interface.
11. V35–V37 remain forecast-only.
12. No migration, persistence, public API, runtime, branch-truth,
    progression-write, latch, terminal, D/E, or ES behavior is authorized.
13. Requirement evidence is bound through `requirement_ref` plus
    `safe_evidence_digest`; the embedded `requirement_digest` is not the value
    self-digest.

V40 SEMANTIC CONTRACT

Freeze one minimal total operational-separation contract.

Required inputs must include, by exact ref/digest and canonical value:

- the independent-review `WorkerObservationV1`;
- the exact C1 membership for that observation;
- one exact rank-13 `RW0C1WireWorkerResultBindingV1`;
- the exact rank-12 worker observations referenced by that rank-13 binding;
- the exact author command, author delivery, attempt fence, and author effect
  fence;
- the exact review delivery and review effect fence;
- the exact candidate/capsule lineage or privacy-safe capsule projection
  already accepted by the package;
- all same-phase membership and relation rows needed to prove those operands.

The evaluator must establish:

- review observation source kind is `independent_reviewer`;
- author worker observations use source kind `worker`;
- the author worker-result sequence is exact and internally coherent;
- the author observations resolve to exactly one author
  `source_invocation_ref`;
- the review `source_invocation_ref` differs from that author invocation;
- author effect class is `author_candidate`;
- review effect class is `review_candidate`;
- review effect intent/fence/delivery are distinct from author
  effect intent/fence/delivery;
- program, program version, accepted intent, work, work revision, semantic
  attempt, candidate, command basis, attempt fence, capsule manifest ref, and
  portable capsule digest agree wherever the current owner contracts require
  agreement;
- review observation is validated through the exact current
  `validate_observation_relation(...)`;
- exact current C1 membership/relation reconstruction succeeds.

Do not treat inequality of `source_ref` alone as proof of identity separation.
Do not claim different human, provider, model, account, credential, process,
host, or cryptographic principal.

The closed result vocabulary should be the smallest total set supported by the
current graph:

status:
- `separate`
- `not_separate`
- `unknown`
- `conflict`

At minimum distinguish:

- one exact distinct role/invocation/effect/delivery graph -> `separate`;
- reused author/reviewer invocation or overlapping author/review effect or
  delivery identity -> `not_separate`;
- absent author source evidence or no exact reconstructible author invocation
  -> `unknown`;
- contradictory author observations, multiple author invocation identities,
  cross-lineage substitution, or malformed same-phase closure -> `conflict`.

Freeze the exact finite reason vocabulary and precedence after inspecting the
current owners. Do not introduce broader identity semantics than the facts can
support.

The value must include enough exact lineage, source, membership, relation, and
evaluation-time identities for deterministic replay and future package
resupply. It remains pure, no-I/O, non-authoritative, and migration-free.

V15 REVIEW DISPOSITION INTEGRATION

Regenerate the independent-review disposition contract around V40:

- `separate` permits the existing source-outcome mapping.
- `unknown` permits only the existing unknown/no-decision posture.
- `not_separate` maps to `basis_conflict` with the finite reason
  `review_not_independent` or a more exact renamed operational-separation
  reason.
- `conflict` maps to `basis_conflict` with the finite reason
  `reviewer_separation_conflict`.

Do not preserve field names or reasons that falsely imply authenticated
person/principal identity. Rename them where required and regenerate all
dependent identities.

NONCLAIMS

State explicitly that V40 proves only semantic-graph separation of governed
invocations/effects/deliveries.

It does not prove:

- distinct human identity;
- distinct model or provider;
- distinct account, credential, host, process, or organization;
- source authenticity;
- external authority;
- review quality;
- semantic acceptance;
- permission or execution authority.

COMPLETE CANONICAL PACKAGE

After freezing V40, complete the package previously requested.

Print complete literal canonical grammars for V38–V44, including exact ordered
field names, types, nullability, enums, generated-ref preimages, digest domains,
self-exclusions, relation rules, and malformed/substitution vectors.

Print complete compact canonical JSON, byte lengths, raw SHA-256, digest
domains, and domain-separated digests for every changed/current profile needed
to reproduce the package, including all profiles governing V38–V44.

Print complete canonical golden JSON for:

- V38–V44;
- corrected validation and review dispositions;
- all six support sets;
- policy and risk matrices;
- global-stop snapshot and ceiling evidence;
- rank-14 typed value and generic relation row;
- candidate safe projection;
- model-input safe projection;
- private input manifest;
- T1 input context;
- model-input binding;
- full nine-role evidence supply;
- source invocation;
- proposal evidence rows;
- evidence set;
- proposal;
- owner-family graph input;
- Section 41 projection V2;
- rank-15 typed value;
- all nine role-resolution V3 values.

Do not require the future auditor to infer canonical bytes from a summary or
trust an unattached local file.

VALUE-TO-MODULE ALLOCATION

Reissue a literal V01–V44 owner-module ledger.

V40 is locally owned by `_post_execution_evidence_values.py` as a pure derived
evaluation. It is not externally authored and is not an identity
authentication owner.

Preserve:

- C2A/B1/B2/C1 import none of the new modules;
- new modules may privately import exact current C2A/C1 values;
- generic risk does not import FiniteBacklog-specific code;
- the FiniteBacklog adapter imports generic target values only;
- no package-root export or production caller.

MECHANICAL REPRODUCTION

Mechanically reproduce all generated refs, self-digests, support sets, profile
digests, source-binding digests, evidence-binding digests, T1 identities,
proposal-family identities, Section 41 projection, rank-15 value, and all role
resolutions.

Use at least two independent local SHA-256 implementations.

Print a complete supersession ledger. No stale V40 or dependent identity from
the fixed report may survive outside that ledger.

Do not claim the SHA-256 of the complete response inside the same response.
The caller will bind the attachment afterward.

ASSURANCE COMPLETION

Retain the prior finite assurance cases and add ordinary tests and external
mutants for:

1. Reviewer observation source kind is not `independent_reviewer`.
2. Author observation source kind is not `worker`.
3. Review source invocation equals the author source invocation.
4. Author rank-13 observations contain two different source invocations.
5. Review effect intent/fence/delivery equals the author effect/delivery.
6. Review effect class is not `review_candidate`.
7. Author effect class is not `author_candidate`.
8. Candidate, capsule, attempt, command, or program/work lineage substitution.
9. Missing rank-13 author source evidence -> `unknown`, not fabricated
   `separate`.
10. Contradictory author source evidence -> `conflict`.
11. A value/profile claims distinct person/provider/account identity.
12. A future stronger identity attestation is silently treated as current V40.
13. Requirement `requirement_digest` substituted for `safe_evidence_digest`.
14. C2A imports any new post-execution module.
15. Generic risk imports FiniteBacklog-specific code.
16. Stale fixed-input V40 identities survive outside the supersession ledger.

Permanent repository tests remain ordinary finite semantic/canonical tests.
Independent audit owns external mutation, patch provenance, and cross-owner
authority review.

STOP CONDITIONS

Return the blocked token only if exact current C1/C2A facts cannot prove
operational role/invocation/effect/delivery separation as defined above.

Do not block merely because current facts cannot authenticate a human,
provider, model, account, host, or cryptographic principal; those claims are
explicitly outside V40.

Also stop if completion requires:

- changing current C2A/B1/B2/C1 semantics;
- changing migration-0003 or C1 durable-row meanings;
- source authentication or external I/O;
- a sixteenth C1 kind;
- persisting capsule entries/private bodies;
- FiniteBacklog in generic target semantics;
- model recommendation authority;
- migration/public/runtime changes;
- branch truth, C2B progression, latch, terminal, D/E, or ES semantics.

RETURN FORMAT

# Baseline and fixed input
# Preserved decisions
# Current operational-separation source graph
# Complete V38–V44 canonical grammars
# Complete disposition and source-graph relations
# Complete profile canonical JSON package
# Complete golden canonical value package
# Value-to-owner-module and import DAG
# Mechanical reproduction and supersession ledger
# T1/Section41/resupply equality matrix
# Finite assurance matrix
# Remaining seams and stop conditions
# Recommended next step
# Confidence

SUCCESS TOKEN

Return exactly:

RW0_POST_EXECUTION_CANONICAL_AUDIT_PACKAGE_COMPLETE_READY_FOR_INDEPENDENT_AUDIT

only if:

- V40 is an exact pure operational reviewer-separation evaluation;
- no unsupported identity-authentication claim remains;
- V38–V44 have complete literal canonical schemas;
- requirement evidence uses the exact current owner identity;
- every changed profile is printed in complete canonical JSON;
- every required golden value is printed in complete canonical JSON;
- all refs/digests mechanically reproduce;
- module allocation is exact;
- no stale identity survives outside the supersession ledger;
- the response is self-contained;
- no implementation prompt is issued.

Otherwise return:

RW0_POST_EXECUTION_CANONICAL_AUDIT_PACKAGE_BLOCKED

and identify the exact missing current fact or owner relation.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
