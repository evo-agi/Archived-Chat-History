Here is Codex's response:

# Baseline and inspection boundary

[current merged implementation] The required local baseline matches exactly:

| Item | Observed |
| --- | --- |
| Branch | `trunk_dev` |
| HEAD | `a3ff0b7f4f0c2378c2962e24612d605489b51638` |
| Tree | `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0` |
| Sole parent | `047563de5a443b0f8323401c92979ae2e444d2ed` |
| Subject | `feat: implement RW0-C1 durable evidence (#7)` |
| Upstream | `origin/trunk_dev` |
| Ahead/behind | `0/0` |
| Worktrees | `1` |
| Worktree/index/untracked/unmerged | clean |

[current merged implementation] Inspection was confined to local Git metadata and `/Users/ds/Repositories/Governed Execution Coordinator`. No fetch, remote contact, supporting-repository inspection, test execution, migration execution, worker invocation, or model invocation occurred.

[current owning contract] The repository’s `.docs/` directory was treated as authoritative. Current implementation, compatibility edges, accepted future semantics, and the proposed C freeze below remain distinct.

# Reconciliation of the phase-level report

[proposed frozen C contract] The two-part decomposition remains correct, using the collision-free names `RW0-C-Decision` and `RW0-C-Terminal`.

[proposed frozen C contract] The corrections resolve as follows:

- One C1 phase admits at most one RW0-C decision closure and one bound C2B decision.
- Replay requires the same mutation identity and canonical command digest.
- Any different decision, closure, or mutation for that phase conflicts.
- A terminal closure never replaces or supersedes the decision closure.
- Active-cancellation terminal `block` never creates a second C2B block decision.
- `pre_effect_cancel_basis_unusable` requires an exact committed, recoverable `cancel / effect_cancellation` decision.
- `cancellation_rejected` cannot support terminal `cancel` under current owners.
- The acceptance latch is scoped to one authoritative Coordinator state-root database.
- Fresh decisions resupply required private operands; replay and recovery do not.
- All six decision branches are representable with unchanged C2B decision grammar.
- Terminal persistence is not freezeable until D/ES supplies missing owner facts.

[compatibility edge] The C2B target reserved `development_first_slice_latch` and historically placed it in a never-landed `0003_development_observation_and_progression_state`. The merged repository now uses 0003 for Section 41 and 0004 for C1. The latch’s semantic/table identity is retained, but its physical introduction moves to migration 0005.

[proposed frozen C contract] RW0-specific closure/member/binding tables replace the need for an unscoped generic decision-evidence payload. They do not add or reinterpret any C2B decision kind, variant, field, result, or receipt meaning.

[reopened target seam] Process-group reconciliation, descendant reconciliation, authenticated custody closure, and source-native delivery/reconciliation receipts have no exact current owner value plus durable reader. That blocks migration 0006, not migration 0005.

# Final decomposition decision

[proposed frozen C contract] `RW0-C-Decision` is contract-freeze-ready as one independently useful migration-0005 capability.

[reopened target seam] `RW0-C-Terminal` semantic invariants can be frozen, but its physical schema and migration 0006 cannot be frozen before a D/ES owner contract.

[proposed frozen C contract] No C1, B1, Wire, Capability, C2A, C2B, Section 41, transition, global-stop, writer, or public-surface semantic change is required for RW0-C-Decision.

# RW0-C-Decision observable capability

[proposed frozen C contract] One guarded private mutation atomically commits:

1. One immutable RW0-C decision-basis closure for one exact C1 phase.
2. One existing C2B decision row.
3. Its exact C2B state/version/head changes, when applicable.
4. The existing C2B result projection and nested `development_mutation_receipts` row.
5. One outer RW0-C binding/result.
6. One outer RW0-C receipt.
7. The one-way latch postimage only for productive direct-local `accept / candidate_acceptance`.

[proposed frozen C contract] The closure is durable decision basis and branch-completeness evidence. It is not terminal outcome, executable authorization, source authentication, custody, contact permission, worker state, Git authority, publication authority, or successor-launch authority.

[proposed frozen C contract] Until a distinct RW0-C-Terminal fact commits, the run remains nonterminal and no successor, Git, publication, or new external effect may be inferred from the decision alone.

# Exact branch-profile matrix

[proposed frozen C contract] Every closure contains the complete C1 membership snapshot for its phase, up to the hard maximum of 256 members. The existing `LIMIT 257` C1 page contract supplies 256 rows plus one overflow witness. Overflow fails with `decision_evidence_over_limit`.

[proposed frozen C contract] Member roles are the existing fifteen C1 kind names and ranks. Each member is marked `decision_relevant` or `context_only`. Relevance never changes the underlying C1 membership.

[proposed frozen C contract] These branch sets are used:

- `G`: one unambiguous current decision-relevant chain across ranks 1–9: authority observation, subordinate proposal, WorkSpec custody, retrieval event, host readiness, host qualification, capability declaration, capability observation, and capability qualification.
- `X`: the exact reached rank-12 C2A observations, one coherent rank-13 worker-result binding, and one rank-14 process/result classification.
- `S(r)`: exactly one rank-15 family with nine Section 41 evidence bindings and recommendation `r`.
- `P`: the complete page-closed C1 membership snapshot, including context-only members.

| Class | Branch ID | C2B decision | Required basis and classification | Stop/latch behavior | Exact reason |
| --- | --- | --- | --- | --- | --- |
| proposed frozen C contract | `post_execution_accept` | `accept / candidate_acceptance` | `P + G + X + S(accept_candidate)`; usable process result; exact capsule, validation, review, authority and current-head relations | stop must be clear; direct-local adapter required; available latch must CAS to consumed | `candidate_acceptance_complete` |
| proposed frozen C contract | `post_execution_repair` | `repair / candidate_repair` | `P + G + X + S(repair_candidate)`; successor attempt/candidate refs preassigned | stop must be clear; latch untouched | `candidate_repair_required` |
| proposed frozen C contract | `post_execution_replan` | `replan / attempt_selecting_replan` | `P + G + X + S(replan)`; exact successor accepted-intent/work/WorkSpec family supplied | stop must be clear; latch untouched | `attempt_replan_required` |
| proposed frozen C contract | `post_execution_terminal_reject` | `terminal_reject / program_terminal_reject` | `P + G + X + S(terminal_reject)` | active stop permitted; latch untouched | `candidate_terminal_rejection_required` |
| proposed frozen C contract | `post_execution_block` | `block / program_block` | `P`; either `S(block)` or exact missing/contradictory/multiple branch evidence | active stop permitted; latch untouched | `post_execution_progression_blocked`, `ambiguous_branch_blocked`, or `incomplete_branch_blocked` |
| proposed frozen C contract | `pre_contact_block` | `block / program_block` | `P`; ranks 10–15 absent; at least one exact gate failure or incomplete gate in ranks 1–9 | active stop permitted; no contact; latch untouched | `pre_contact_gate_blocked` |
| proposed frozen C contract | `pre_effect_cancel` | `cancel / effect_cancellation` | `P`; exact target effect/fence/head, originating command, source directive/evidence, preassigned cancellation effect/fence/delivery; no cancellation request yet | clear or active stop permitted; latch untouched | `effect_cancellation_required` |

[proposed frozen C contract] Multiple rank-15 families, multiple simultaneously admissible non-block branches, a proposal/result mismatch, or incomplete successor provisioning maps only to `post_execution_block`. A caller cannot force an accept/repair/replan/reject result through ambiguous evidence.

[proposed frozen C contract] The pure checks rerun for fresh decisions are:

- `validate_phase_entry_basis(...)`;
- every decision-relevant C1 relation marked recomputable;
- exact C1 dependency closure;
- B1 host/custody/authority relations applicable to `G`;
- the Capability declaration/observation/qualification relation;
- Wire worker-result and process/result classification;
- applicable C2A delivery and observation relations;
- exact Section 41 zero-or-nine family reconstruction;
- exact C2B program/work/attempt/fence/effect/delivery/head coherence;
- branch classification and finite reason selection.

[proposed frozen C contract] Decision-time transient operands are:

| Class | Branches | Operand and supplier | Durable binding and SQLite rule |
| --- | --- | --- | --- |
| proposed frozen C contract | all | Exact current `WorkSpecV1`, resupplied by its semantic author/custodian | Bind existing `work_spec_ref`, `work_spec_digest`, safe projection, and C1 transient-binding digest; raw WorkSpec is forbidden |
| proposed frozen C contract | post-execution branches | Exact `CandidateCapsuleManifestV1`, supplied by capsule builder/store | Bind manifest ref, portable digest, safe projection and C1 transient-binding digest; entries and raw manifest are forbidden |
| proposed frozen C contract | applicable rank-12 observations | Exact before/after blob tuples, supplied by observation/validation owner | Bind only the existing transient operand-set digests; raw paths, modes, contents, and blob maps are forbidden |
| proposed frozen C contract | replan | Exact successor `WorkSpecV1`, source-intent pair, and preassigned accepted-intent/work identities | Persist only the normal C2B safe WorkSpec binding and immutable revisions; raw successor WorkSpec is forbidden |
| proposed frozen C contract | validation/review cancel targets | Exact target capsule manifest, supplied by capsule custodian | Bind the target manifest ref and portable digest; author-target cancellation requires both null |
| current owning contract | Section 41 branches | Existing private-artifact binding and proposal family | Raw artifact/model response is neither supplied nor persisted; the immutable binding/family is reconstructed |
| current owning contract | replay/recovery | No raw private operand | Receipt, closure, attestation, owner rows and immutable operand-set digests are sufficient |

[proposed frozen C contract] The canonical command digest excludes ephemeral raw objects and includes their exact safe identities and operand-set digests. Receipt-hit replay therefore works without private content. A receipt miss requires all fresh raw operands; absence produces `decision_transient_operand_unavailable` before any write. A `definitely_not_committed` retry must resupply them.

# Decision closure identity and member grammar

[proposed frozen C contract] Exact schema IDs are:

- `governed-execution.nwp-rw0-c-decision-closure.v1`
- `governed-execution.nwp-rw0-c-decision-closure-member.v1`
- `governed-execution.nwp-rw0-c-decision-attestation.v1`
- `governed-execution.nwp-rw0-c-decision-binding.v1`
- `governed-execution.nwp-record-rw0-c-decision-command.v1`
- `governed-execution.nwp-record-rw0-c-decision-result.v1`
- `governed-execution.nwp-rw0-c-decision-mutation-receipt.v1`

[proposed frozen C contract] All row digests use `SHA-256(schema_id + ".identity" || NUL || canonical JSON)`, excluding only the row’s named self-digest. Canonical JSON is sorted-key, compact UTF-8, `ensure_ascii=false`, `allow_nan=false`.

[proposed frozen C contract] The closure’s exact ordered columns are:

```text
schema_id
closure_ref
phase_basis_ref
phase_basis_digest
program_ref
basis_program_version_ref
basis_program_version_number
basis_decision_ref
basis_decision_digest
work_item_ref
work_item_revision_ref
semantic_attempt_ref
candidate_ref
effect_intent_ref
author_command_ref
attempt_fence_ref
effect_fence_ref
delivery_attempt_ref
k8_digest
branch_id
reason_code
decision_ref
decision_kind
decision_variant
expected_program_head_revision
expected_program_head_digest
expected_program_state
expected_work_item_head_revision
expected_work_item_head_digest
expected_work_state
expected_selection_head_revision
expected_selection_head_digest
expected_selection_disposition
expected_effect_head_revision
expected_effect_head_digest
expected_effect_head_state
expected_delivery_head_revision
expected_delivery_head_digest
expected_delivery_head_state
coding_global_stop_ref
coding_global_stop_version
coding_global_stop_state
global_stop_snapshot_digest
target_effect_intent_ref
target_effect_class
target_effect_fence_ref
target_effect_fence_digest
expected_target_effect_head_revision
expected_target_effect_head_digest
expected_target_effect_head_state
target_delivery_attempt_ref
target_capsule_manifest_ref
target_portable_capsule_digest
source_directive_ref
source_directive_digest
source_evidence_ref
source_evidence_digest
member_count
member_set_digest
attestation_ref
attestation_digest
transient_operand_count
transient_operand_set_digest
nested_development_command_digest
latch_preimage_digest
planned_latch_postimage_digest
closed_at
closure_graph_digest
closure_digest
```

[proposed frozen C contract] The closure member’s exact ordered columns are:

```text
schema_id
closure_ref
phase_basis_ref
phase_basis_digest
closure_ordinal
kind_rank
kind_role
kind_ordinal
member_use
membership_ref
membership_digest
value_ref
value_digest
value_schema_id
member_digest
```

[proposed frozen C contract] `kind_role` is the existing rank-1-through-rank-15 C1 vocabulary. `closure_ordinal` is dense zero-based over `(kind_rank, membership_ref)`. `kind_ordinal` is dense zero-based within each rank. `member_use` is exactly `decision_relevant` or `context_only`.

[proposed frozen C contract] The attestation’s exact ordered columns are:

```text
schema_id
attestation_ref
closure_ref
phase_basis_ref
phase_basis_digest
branch_id
section41_requirement
section41_membership_ref
section41_membership_digest
section41_recommendation
membership_count
membership_set_digest
relevant_member_count
relevant_member_set_digest
owner_snapshot_count
owner_snapshot_set_digest
transient_operand_count
transient_operand_set_digest
relation_count
relation_set_digest
completeness_state
reason_code
attested_at
attestation_digest
```

[proposed frozen C contract] `section41_requirement` is exactly `exact_one_matching`, `forbidden`, or `not_required`. `completeness_state` is exactly `complete_for_branch`.

[proposed frozen C contract] The binding/result row’s exact ordered columns are:

```text
schema_id
binding_ref
mutation_ref
phase_basis_ref
phase_basis_digest
closure_ref
closure_digest
attestation_ref
attestation_digest
program_ref
decision_ref
decision_digest
decision_kind
decision_variant
nested_result_schema_id
nested_result_projection_digest
nested_receipt_digest
result_program_version_ref
latch_postimage_digest
recorded_at
result_schema_id
result_projection_digest
binding_digest
```

[proposed frozen C contract] The outer result projection identity is:

```text
schema_id
mutation_ref
phase_basis_ref
phase_basis_digest
closure_ref
closure_digest
decision_ref
decision_digest
decision_kind
decision_variant
result_program_version_ref
latch_postimage_digest
recorded_at
```

[proposed frozen C contract] The outer receipt’s exact ordered columns are:

```text
schema_id
mutation_ref
mutation_family
command_schema_id
command_digest
phase_basis_ref
phase_basis_digest
closure_ref
closure_digest
binding_ref
binding_digest
decision_ref
decision_digest
result_class
result_projection_digest
nested_development_receipt_digest
latch_postimage_digest
decision_graph_digest
outcome
committed_at
receipt_digest
```

[proposed frozen C contract] The outer constants are:

```text
mutation_family = record_rw0_c_decision
result_class = rw0_c_decision_recorded
outcome = committed
```

[proposed frozen C contract] Exactly one closure is permitted per `phase_basis_ref`; exactly one bound decision, binding, and outer receipt are permitted for that phase. `closure_ref`, `closure_digest`, `decision_ref`, `binding_ref`, `binding_digest`, `receipt_digest`, and `attestation_ref/digest` are independently unique.

[proposed frozen C contract] The closure graph ranks are fixed: phase, basis decision, program-head preimage, work-head preimage, selection-head preimage, effect-head preimage, delivery-head preimage, global-stop preimage, optional cancellation-target heads, C1 memberships, attestation, nested C2B command, optional latch preimage, and optional latch postimage.

[proposed frozen C contract] No table admits JSON, BLOB, extension metadata, raw WorkSpec, capsule entries, raw model content, filesystem paths, credentials, endpoints, process handles, stdout/stderr, or source-native physical payloads.

# Productive acceptance latch

[strategic target] C2B already owns the first-slice one-shot latch meaning and the key `direct_local_first_productive_acceptance`.

[proposed frozen C contract] “Global Coordinator bootstrap” is grounded as exactly one row in one authoritative Coordinator state-root SQLite database. It is not organization-wide, account-wide, repository-wide across databases, or cross-host hidden authority.

[proposed frozen C contract] The table remains `development_first_slice_latch`, with schema ID `governed-execution.nwp-development-first-slice-latch.v1` and ordered columns:

```text
schema_id
latch_ref
scope_kind
state
version
decision_ref
decision_digest
program_ref
program_version_ref
program_version_digest
candidate_ref
capsule_manifest_ref
portable_capsule_digest
consumed_at
latch_postimage_digest
```

[proposed frozen C contract] Its key and initial state are:

```text
latch_ref = direct_local_first_productive_acceptance
scope_kind = coordinator_state_root_database
state = available
version = 0
all consumed bindings = NULL
```

[proposed frozen C contract] The exact initial canonical identity is:

```json
{"candidate_ref":null,"capsule_manifest_ref":null,"consumed_at":null,"decision_digest":null,"decision_ref":null,"latch_ref":"direct_local_first_productive_acceptance","portable_capsule_digest":null,"program_ref":null,"program_version_digest":null,"program_version_ref":null,"schema_id":"governed-execution.nwp-development-first-slice-latch.v1","scope_kind":"coordinator_state_root_database","state":"available","version":0}
```

[proposed frozen C contract] Its initial digest is:

```text
daf85853e1784e445e4d4dcde24aeeab57189868dca3d1a9dd70b4ec7bbe9899
```

[proposed frozen C contract] The sole legal update is an exact CAS from that available preimage to:

```text
state = consumed
version = 1
decision_ref/digest = committed accept decision
program_ref/version_ref/version_digest = accepted postimage
candidate_ref = accepted candidate
capsule_manifest_ref/portable_capsule_digest = accepted capsule
consumed_at = shared transaction timestamp
latch_postimage_digest = exact row identity digest
```

[proposed frozen C contract] The CAS predicate includes literal key, scope, `available`, version `0`, and the initial digest. Rowcount must equal one.

[proposed frozen C contract] No phase-, program-, work-item-, candidate-, or route-scoped second latch exists. The proof being bounded is the first productive direct-local acceptance within the state root.

[proposed frozen C contract] A freshly initialized independent database starts available. A copied consumed database remains consumed; a copied available database remains available. State-root authority and resource binding must prevent two copies from being treated as the same live authoritative root.

[proposed frozen C contract] Test databases are independent state roots and cannot consume or reset an operator database’s latch.

[proposed frozen C contract] Migration from 0004 safely seeds the row because the merged repository implements no productive RW0 decision or acceptance runtime. Any claim of pre-migration productive acceptance is external, unrepresented state and requires operator reconciliation rather than a synthetic consumed row.

# C2B write-side composition

[current owning contract] The reused decision row is the existing 43-column `development_decisions` grammar. No new kind, variant, target class, or field is introduced.

[proposed frozen C contract] The RW0 profile requires the current program-version membership to contain exactly the phase’s single work item. A multi-work program is outside this first RW0 composition and fails `c2b_profile_not_representable`.

| Class | Branch | Exact C2B reads and writes |
| --- | --- | --- |
| proposed frozen C contract | accept | Read current program/version, sole work head/revision, attempt/candidate/fence, current membership, heads and clear global stop. Insert `accept/candidate_acceptance`; insert program version `accepted` at `basis+1`; copy the sole membership; CAS work head to `accepted`, same work revision and `head_revision+1`; CAS program head to new version/state `accepted` and `head_revision+1`; write nested result/receipt; CAS latch to consumed. |
| proposed frozen C contract | repair | Same preimages and clear stop. Insert `repair/candidate_repair` with preassigned attempt/candidate; append program version kind `repair`; copy membership; CAS work head to `repair_required`; CAS program head to new version/state `active`; nested result/receipt; no attempt row and no latch change. |
| proposed frozen C contract | replan | Read current intent/work/version and clear stop. Insert `replan/attempt_selecting_replan`; insert accepted-intent revision `n+1`; insert work-item revision `n+1` kind `replan`; insert exact successor WorkSpec safe binding; insert both supersession edges; append program version kind `replan`; replace the sole membership with the new work revision; CAS work head to new revision/state `planned`; CAS program head to new version/state `active`; nested result/receipt; preassign attempt/candidate; no attempt row and no latch change. |
| proposed frozen C contract | terminal reject | Insert `terminal_reject/program_terminal_reject`; append version kind `terminal_rejected`; copy membership; CAS work head to `terminal_rejected`; CAS program head to state `terminal_rejected`; nested result/receipt; no latch change. |
| proposed frozen C contract | block | Insert `block/program_block`; append version kind `blocked`; copy the sole membership; CAS the sole work head to `blocked`; CAS program head to `blocked`; nested result/receipt; no latch change. |
| proposed frozen C contract | cancel | Read exact current program/version, selected attempt/fence, target effect/fence/head, originating command, conditional capsule, global stop, source directive/evidence and collision probes. Insert only `cancel/effect_cancellation` and the nested result/receipt. Use the current basis program version as `result_program_version_ref`. No version, head, effect, delivery, observation, request, or latch mutation occurs. |

[proposed frozen C contract] Version-advancing decisions use `resulting_program_version_number = basis_program_version_number + 1`. Cancel has both resulting-version fields null in the decision row but its receipt/result projects the existing basis version, as required by the current receipt algebra.

[proposed frozen C contract] All state-changing head updates use exact preimage revision and digest from the closure and advance revision exactly once. Zero or multiple updated rows is a conflict or integrity failure, never acceptance.

[proposed frozen C contract] Accept, repair, and replan are blocked by active coding global stop. Terminal reject, block, and cancel are permitted under active stop. Every decision binds the exact observed stop ref/version.

[proposed frozen C contract] The nested receipt remains:

```text
mutation_family = record_development_progression_decision
command_schema_id = governed-execution.nwp-record-development-progression-decision-command.v1
result_class = development_progression_decision_recorded
decision_ref = result_decision_ref
result_program_version_ref = new version, or existing basis version for cancel
outcome = committed
```

[current owning contract] `development_mutation_receipts` stores no receipt-digest column. The outer binding uses the existing pure row value’s computed receipt digest.

# Decision transaction, replay, and recovery

[proposed frozen C contract] The minimum operation count is one branch-parameterized `_record_rw0_c_decision` entry and one `_resolve_rw0_c_decision_commit_outcome` recovery entry.

[proposed frozen C contract] The safe command identity contains:

- mutation, closure, attestation, binding and decision refs;
- phase ref/digest;
- requested branch and finite reason;
- all branch-applicable preassigned C2B identities;
- expected program/work/selection/effect/delivery heads;
- exact global-stop ref/version/state;
- selected Section 41 membership, when required;
- target/source/capsule fields for cancellation;
- safe identities for current and successor WorkSpecs;
- `transient_operand_set_digest`;
- exact nested C2B command digest;
- canonical outer command digest.

[proposed frozen C contract] Caller input contains intent, expected preimages, safe owner identities, preassigned refs and ephemeral raw operands. It never contains proposed closure rows, member rows, decisions, receipts, persisted digests, latch rows, or head postimages.

[proposed frozen C contract] Fresh ordering is:

1. Closed-world command reconstruction.
2. Session operation guard and shared mutation slot.
3. Resource-bound connection and `BEGIN IMMEDIATE`.
4. Managed-schema/resource revalidation.
5. Durable writer fencing.
6. Outer receipt lookup.
7. Exact replay or mutation-key conflict.
8. Same-phase closure lookup and one-decision conflict.
9. C1 phase/full membership reconstruction.
10. Current owner/head/global-stop reads.
11. Branch classification and transient relation checks.
12. One whole-second UTC timestamp.
13. Build closure/member/attestation and C2B write plans.
14. Insert closure family using deferred decision/attestation FKs.
15. Execute C2B immutable inserts and head CAS updates.
16. Insert nested C2B receipt.
17. Perform latch CAS only for accept.
18. Insert outer binding/result.
19. Insert outer receipt last.
20. Invalidate capability.
21. Attempt exactly one commit.
22. Close while retaining the shared mutation slot.
23. Return only after close proof.

[proposed frozen C contract] Exact replay requires an active writer session, the same mutation ref, and the same canonical command digest. Replay returns the existing outer result after full receipt/closure/binding/nested-family verification and does not reread current mutable heads, invoke a clock, require raw private operands, or mutate the latch.

[proposed frozen C contract] Exact conflicts include:

```text
mutation_ref_reuse_conflict
phase_decision_already_recorded
closure_identity_conflict
attestation_identity_conflict
binding_identity_conflict
decision_identity_conflict
successor_identity_conflict
branch_completeness_conflict
branch_ambiguity_requires_block
decision_evidence_over_limit
owner_row_missing
program_head_conflict
work_item_head_conflict
selection_head_conflict
effect_head_conflict
delivery_head_conflict
global_stop_conflict
target_effect_state_conflict
coding_global_stop_active
productive_acceptance_latch_unavailable
decision_transient_operand_unavailable
c2b_profile_not_representable
```

[current owning contract] Stale writer authority returns only `stale_writer_token`; closed-session and process/thread misuse remain local session failures.

[proposed frozen C contract] Any exception after the commit attempt starts returns `commit_outcome_unknown`. There is no automatic retry.

[proposed frozen C contract] Recovery classifications are:

- `committed_exact`: outer receipt plus the complete closure/member/attestation, C2B decision/write graph, nested receipt, binding/result and applicable latch postimage are exact.
- `definitely_not_committed`: outer/nested receipts and every preassigned immutable identity are absent, applicable heads and latch equal their exact preimages, and no fragment exists.
- `unresolved`: every other result, including fragments, consumed latch without complete receipt, changed head without complete graph, collision, unreadable evidence, or failed close proof.

[proposed frozen C contract] Recovery uses a fresh fenced transaction and immutable locators only. It invokes no clock and needs no raw WorkSpec, capsule, artifact, blob set, or model content.

# Migration 0005 exact freeze

[proposed frozen C contract] The migration identity is:

```text
sequence = 5
migration_id = 0005_rw0_c_decision_state
resource_name = 0005_rw0_c_decision_state.sql
min_app_schema = 2
max_app_schema = 2
destructive = false
description = RW0-C decision closure, binding, receipt, and first productive acceptance latch
```

[proposed frozen C contract] The six tables are exactly:

```text
rw0_c_decision_closures
rw0_c_decision_closure_members
rw0_c_decision_attestations
rw0_c_decision_bindings
development_first_slice_latch
rw0_c_decision_mutation_receipts
```

[proposed frozen C contract] All six are `STRICT`; every column is declared `ANY`; every scalar has an exact `typeof` predicate.

[proposed frozen C contract] Scalar grammar is reused exactly:

- Safe refs: ASCII 1–96, `[0-9A-Za-z][0-9A-Za-z.-]*`, excluding case-insensitive prefixes `connector-`, `tunnel-`, `workspace-`, `org-`, `organization-`, and `user-`.
- Digests: exactly 64 lowercase hexadecimal bytes.
- Timestamps: exact valid whole-second `YYYY-MM-DDTHH:MM:SSZ`.
- Revisions/counts: exact built-in SQLite integers in `0..9223372036854775807`.
- Positive version numbers: `1..9223372036854775807`.
- Enumerations and nullable groups: exactly the branch/schema algebra specified above.
- No JSON or BLOB column exists.

[proposed frozen C contract] Primary/unique constraints are:

- closure PK `closure_ref`; unique closure digest, phase ref, decision ref and attestation ref;
- member PK `(closure_ref, closure_ordinal)`; unique member digest, `(closure_ref,membership_ref)`, and `(closure_ref,kind_rank,kind_ordinal)`;
- attestation PK `attestation_ref`; unique attestation digest, closure ref and phase ref;
- binding PK `binding_ref`; unique binding digest, mutation ref, phase ref, closure ref and decision ref;
- latch PK `latch_ref`, constrained to the singleton literal;
- receipt PK `mutation_ref`; unique receipt digest, phase ref, closure ref, binding ref and decision ref.

[proposed frozen C contract] Foreign keys bind the exact C1 phase and memberships, existing C2B decisions/program versions/receipts, closure family, binding and latch decision. The closure/attestation and closure/decision cycles are `DEFERRABLE INITIALLY DEFERRED`. All actions are `ON UPDATE RESTRICT ON DELETE RESTRICT`.

[proposed frozen C contract] Explicit indexes are exactly:

```text
idx_rw0_c_decision_closure_members_page
  ON rw0_c_decision_closure_members
     (closure_ref, closure_ordinal, kind_rank, membership_ref)

idx_rw0_c_decision_receipts_phase_lookup
  ON rw0_c_decision_mutation_receipts
     (phase_basis_ref, mutation_ref)
```

[proposed frozen C contract] Trigger inventory is exactly:

- no-update and no-delete on each of the five immutable C tables: 10 triggers;
- `development_first_slice_latch_no_delete`;
- `development_first_slice_latch_one_way_update`.

[proposed frozen C contract] The latch trigger permits only the available/version-0 to consumed/version-1 postimage. `INSERT OR REPLACE` is blocked by the delete trigger. Managed-state validation requires exactly one seed row.

[proposed frozen C contract] Cumulative exact totals become:

```text
user tables: 68
explicit application indexes: 7
triggers: 122
seed rows added by 0005: 1
application generation: 2
terminal migration sequence: 5
```

[proposed frozen C contract] Fresh initialization applies 0001–0005. Exact complete 0001, 0002, 0003 and 0004 databases remain explicit-migration-supported prefixes; ordinary inspection/writer/product mutation admits only exact complete terminal-0005 history and schema.

[current owning contract] Migrations 0001–0004 retain byte-for-byte identity and checksums.

[implementation detail] The 0005 catalog checksum is `sha256` over the eventual exact packaged UTF-8 SQL bytes and must be inserted as a literal in `sqlite_migration.py`. Its byte value is deliberately not fabricated in a read-only report; the schema, ordering, constants and checksum rule are frozen.

# Decision readers and assurance

[proposed frozen C contract] New private query specifications are literal explicit-column queries. `{COLUMNS}` below means the exact ordered tuple given above, not `SELECT *`.

```text
SELECT {RECEIPT_COLUMNS}
FROM rw0_c_decision_mutation_receipts
WHERE mutation_ref = ?
LIMIT 2

SELECT {RECEIPT_COLUMNS}
FROM rw0_c_decision_mutation_receipts
WHERE phase_basis_ref = ?
LIMIT 2

SELECT {RECEIPT_COLUMNS}
FROM rw0_c_decision_mutation_receipts
WHERE receipt_digest = ?
LIMIT 2

SELECT {CLOSURE_COLUMNS}
FROM rw0_c_decision_closures
WHERE closure_ref = ?
LIMIT 2

SELECT {CLOSURE_COLUMNS}
FROM rw0_c_decision_closures
WHERE phase_basis_ref = ?
LIMIT 2

SELECT {CLOSURE_COLUMNS}
FROM rw0_c_decision_closures
WHERE closure_digest = ?
LIMIT 2

SELECT {ATTESTATION_COLUMNS}
FROM rw0_c_decision_attestations
WHERE attestation_ref = ?
LIMIT 2

SELECT {ATTESTATION_COLUMNS}
FROM rw0_c_decision_attestations
WHERE attestation_digest = ?
LIMIT 2

SELECT {BINDING_COLUMNS}
FROM rw0_c_decision_bindings
WHERE binding_ref = ?
LIMIT 2

SELECT {BINDING_COLUMNS}
FROM rw0_c_decision_bindings
WHERE decision_ref = ?
LIMIT 2

SELECT {BINDING_COLUMNS}
FROM rw0_c_decision_bindings
WHERE binding_digest = ?
LIMIT 2

SELECT {MEMBER_COLUMNS}
FROM rw0_c_decision_closure_members
WHERE closure_ref = ? AND closure_ordinal > ?
ORDER BY closure_ordinal ASC
LIMIT 257

SELECT {LATCH_COLUMNS}
FROM development_first_slice_latch
WHERE latch_ref = ?
LIMIT 2
```

[proposed frozen C contract] Readers borrow only the nominal mutation capability, call `fetchmany(limit)`, require exact built-in tuples, build one private mapping, validate row self-digests, and never own the connection.

[proposed frozen C contract] Duplicate singleton results, malformed types/digests, non-dense ordinals, graph mismatch, unexpected member count, or cross-family mismatch are `database_integrity_failure`. Expected absence becomes the operation-specific conflict. SQLite operational failures remain `mutation_failed`.

[proposed frozen C contract] Permanent assurance claims are separated:

1. Migration identity, totals, triggers, indexes, prefix behavior and seed.
2. Every row/value schema, closed enumeration and digest vector.
3. Every branch positive vector and cross-branch negative vector.
4. C1 page closure, relevance marking, dense ordering and overflow.
5. Each C2B branch’s exact preimage/postimage graph.
6. One-decision-per-phase and different-command conflict.
7. Receipt-first replay without raw operands or clock.
8. Fresh transient unavailability before writes.
9. Latch CAS, replay, collision, copied/test database behavior.
10. Commit-attempt and close-proof fault injection.
11. Three-way recovery for every branch.
12. Privacy and non-authority boundaries.
13. No public export or `StateStore` widening.

[proposed frozen C contract] Independent audit mutants must remove a phase uniqueness constraint, loosen the latch trigger, alter one C2B variant, omit member overflow detection, swap one Section 41 recommendation, change one head postimage, classify cancellation rejection as success, store a raw/JSON operand, or perform a second commit. Expected values must be independent literals, not generated from the production constants being tested.

# Decision implementation ceiling and protected set

[implementation detail] The provisional new-path ceiling is:

```text
/Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c-decision.md
/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_c_decision_semantic_values.py
/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_c_decision_row_values.py
/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_c_decision_mutation_contracts.py
/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_rw0_c_decision_reader_contracts.py
/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_rw0_c_decision_readers.py
/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_rw0_c_decision.py
/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0005_rw0_c_decision_state.sql
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c_decision_semantic_values.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c_decision_row_values.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c_decision_reader_contracts.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c_decision_private_readers.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_sqlite_rw0_c_decision_migration_0005.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c_decision_private_atomic_persistence.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c_decision_recovery.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c_decision_writer_session_delegation.py
```

[implementation detail] Existing source files permitted only bounded additive integration are:

```text
/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migration.py
/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_transition_transaction.py
/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_writer_session.py
```

[implementation detail] Current-tip, importer, controller, fixture and source-boundary consumers requiring explicit implementation-boundary audit include the exact local files found by static literal inventory, notably:

```text
/Users/ds/Repositories/Governed Execution Coordinator/.docs/architecture.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/autonomous-software-development-operating-model.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/b3-tests-only-coherent-fixtures.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/b3-transition-persistence-contract.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/b3c0a-transition-authority-and-order.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/b3c1-prerequisite-contract.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/b3c1b-rollback-only-writer-fencing.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/b3c3-prerequisite-contract.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/b3c3-rollback-only-transition-dry-run.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/b3c4b-private-atomic-transition-persistence.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/b3c4c-prerequisite-contract.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/b3c4c-public-transition-delegation.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/b4b-private-atomic-global-stop-persistence.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/b4c-public-global-stop-delegation.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/c2a-first-slice-semantic-protocol-contract.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b2-migration-0002.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b2-private-readers.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b3-program-initialization.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/durable-state-model.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c1-durable-evidence.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/software-development-progression-boundary.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/sqlite-bootstrap-and-migrations.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/sqlite-operations-and-recovery.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/sqlite-schema-v1.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/sqlite-state-backend-adr.md
/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md
/Users/ds/Repositories/Governed Execution Coordinator/README.md
/Users/ds/Repositories/Governed Execution Coordinator/tests/b3_coherent_transition_fixture.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_architecture_contracts.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_autonomous_software_development_operating_model.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_b3b2a_read_scope_and_query_contracts.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_b3b2b_select_readers.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_b3c1a_writer_session_authority.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_b3c1b_rollback_only_writer_fencing.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_b3c2_transition_event_readers.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_b3c3_rollback_only_transition_dry_run.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_b3c4a_transition_write_contracts.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_b3c4b_private_atomic_transition_persistence.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_b3c4c_public_transition_delegation.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_b4a_global_stop_readers.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_b4b_private_atomic_global_stop_persistence.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_b4c_public_global_stop_delegation.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2a_nonimplementation.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b0_durable_state_contract.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b2_development_reader_contracts.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b2_field_level_contract.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b2_private_development_readers.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b3_private_program_initialization_delegation.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b3_program_initialization_contract.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b3d_private_author_effect_delegation.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b_pre_io_vs1a_shared_cleanup_foundation.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_runtime_non_authority.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b1_boundaries.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b2_capability_boundaries.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b2_wire_boundaries.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c1_private_readers.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c1_writer_session_delegation.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_sqlite_b1_migrations.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_sqlite_b2b_lock_integration.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_sqlite_b2c_writer_session.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_sqlite_backend_b0_contract.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_sqlite_c2b1_migration_framework.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_sqlite_c2b2_migration_0002.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_sqlite_rw0_c1_migration_0004.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_sqlite_section41_migration_0003.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_worker_execution_semantic_boundaries.py
```

[implementation detail] That list is a provisional audit surface, not permission to edit every listed file. A separate implementation-boundary audit must classify each as changed, rebaselined, or protected before implementation.

[current owning contract] Protected meanings and source remain:

- migrations 0001–0004;
- B1, Wire, Capability and C2A semantic modules;
- C1 phase/evidence schemas, values, readers and mutation behavior;
- current C2B row grammars and frozen reader inventory;
- Section 41 identities and zero/nine family;
- transition/global-stop contracts;
- common writer/fencing/transaction authority;
- `StateStore` and package-root public API;
- all supporting repositories and Execution Substrate.

# RW0-C-Terminal invariants

[strategic target] Terminal closure is a distinct later causal moment with its own ref, digest, timestamp, current snapshot, result, receipt and recovery family.

[proposed frozen C contract] These invariants are freezeable now:

- One terminal outcome at most per phase and committed decision.
- The complete committed RW0-C-Decision family is mandatory.
- Normal decision/outcome mappings are same-kind.
- Terminal accept binds the consumed latch ref/postimage digest and never mutates it.
- Terminal repair/replan/reject/block/cancel never mutate the latch.
- Terminal creates no C2B decision or program version.
- Active-cancel terminal block binds the cancel decision; it does not create a C2B block.
- Terminal replay is receipt-first.
- Terminal uncertainty uses committed-exact/definitely-not/unresolved recovery.
- No terminal value launches a successor or permits Git/publication.
- Physical/source claims remain owner facts, not C-authored truth.

[current owning contract] The existing B1 terminal value has branches:

```text
normal
active_cancel_reconciled
active_cancel_unresolved
pre_effect_cancel_basis_unusable
```

[current owning contract] Its outcomes remain `accept`, `repair`, `replan`, `terminal_reject`, `block`, and `cancel`.

# Pre-effect cancellation basis unusable

[proposed frozen C contract] This branch requires all of the following to be exact before a terminal block is even eligible:

1. RW0-C cancel closure and complete outer receipt.
2. `development_decisions` row `cancel / effect_cancellation`.
3. Exact nested C2B result and receipt.
4. Exact target effect/fence/command/capsule lineage.
5. Exact current program/version/attempt and target-head read.
6. Exact bound stop version/state and authority family.
7. Exact absence or collision state for the preassigned cancellation effect, fence and first delivery.
8. One finite mismatch projection.

[proposed frozen C contract] Permitted mismatch classes are:

```text
program_head_changed
target_effect_head_changed
target_effect_terminal
target_effect_missing
global_stop_version_changed
authority_family_changed
authority_expired
authority_revoked
attempt_fence_mismatch
effect_fence_mismatch
repository_or_base_mismatch
path_or_audience_mismatch
target_capsule_mismatch
preassigned_cancellation_identity_collision
source_basis_incompatible
```

[proposed frozen C contract] An expected row’s absence is proved only by its exact bounded managed-database locator returning zero rows while the schema and resource binding remain valid. A supplied null, missing caller field, failed read, unknown database, or unresolved earlier commit is not absence proof.

[proposed frozen C contract] If the cancel decision row, closure, nested receipt, outer receipt, or recovery result is missing, partial, corrupt, or unresolved, no terminal mutation occurs. A terminal closure cannot fabricate, reconstruct, replace, or supersede that decision.

# Cancellation rejection semantics

[current merged implementation] The Wire cancellation-control classifier returns `finite / cancellation_rejected` before considering `target_process_exited`.

[current owning contract] That classifier explicitly owns no semantic cancellation, terminality, source authenticity, reconciliation, process control, teardown, or runtime truth.

[proposed frozen C contract] `cancellation_rejected` therefore maps to terminal `block`, not terminal `cancel`.

[proposed frozen C contract] A later process-exit claim does not override rejection: exit does not prove request acceptance, semantic cancellation, process-group closure, descendant closure, teardown, or custody reconciliation.

[current merged implementation] No existing value or relation proves an accepted alternative cancellation path for the same target after rejection.

[reopened target seam] A future D/ES contract could add such an owner relation, but that future possibility cannot be used by migration 0006 now.

# D/ES terminal evidence owner ledger

| Class | Required role | Exact current owner/value/reader | Availability to C | Disposition |
| --- | --- | --- | --- | --- |
| current merged implementation | cancellation request | Wire `RW0WireCancellationRequestObservationV1`; schema `governed-execution.nwp-rw0-wire-cancellation-request-observation.v1`; request ref/digest; `rw0_wire_cancellation_request_observations`; C1 rank 10 reader | Full safe supplied-claim projection plus C1 membership | Structurally available; unauthenticated |
| current merged implementation | acknowledgement/rejection | C2A `WorkerObservationV1`; schema `governed-execution.nwp-worker-observation.v1`; observation ref/digest; `rw0_c2a_worker_observations`; C1 rank 12 | Full safe supplied-claim projection plus membership | Structurally available; not terminal proof |
| current merged implementation | signal/resource claim | Wire `RW0WireProcessObservationV1`; schema `governed-execution.nwp-rw0-wire-process-observation.v1`; process ref/digest; `rw0_wire_process_observations`; C1 rank 11 | Full safe claim plus membership | Structurally available; unauthenticated |
| current merged implementation | target process exit | C2A `WorkerObservationV1` with `process_exited`; C1 rank 12 | Full safe claim plus membership | Exit only; not reconciliation |
| reopened target seam | process-group reconciliation | No current value, schema, ref/digest identity, durable row, or reader | Cannot be supplied through current C1 | Missing mandatory owner |
| reopened target seam | descendant reconciliation | No current value, closed descendant-set grammar, durable row, or reader | Cannot be supplied through current C1 | Missing mandatory owner |
| current merged implementation | workspace teardown | C2A `workspace_teardown_succeeded/failed` observation; C1 rank 12 | Safe supplied claim plus membership | Present as claim; no authenticated completeness |
| reopened target seam | capsule custody/retrieval | C2A retrieval observations exist at rank 12; C1 rank-3 custody owns WorkSpec/selected-plan custody, not terminal candidate-capsule custody | Partial claims only | Missing complete physical custody owner |
| reopened target seam | delivery/source receipt | C2B delivery attempts are Coordinator intent; C2A delivery observations are claims; model source-invocation rows are Section 41 facts | Existing refs may be inputs | No source-native terminal receipt family |
| reopened target seam | route/source currentness | B1/Capability/C1 ranks 5–9 provide supplied readiness and qualification; phase/head snapshots provide Coordinator state | Safe evidence only | No authenticated live route/source reconciliation |

[proposed frozen C contract] Existing roles continue through their existing C1 memberships; no sixteenth C1 kind is needed.

[reopened target seam] Missing D/ES roles must later be directly referenced by a terminal closure through exact owner-defined schemas, refs, digests and readers. They must not be disguised as generic C-owned refs, extension bags, JSON, or nullable “physical reconciliation” fields.

[strategic target] Direct-local D owns route-local process-group, descendants, teardown and custody mechanics. Execution Substrate owns ES admission/runtime/reliable-submit and ES-native terminal projections. E supplies separately authorized live currentness/authenticity. C may bind their safe projections but may not author their physical truth.

# Terminal freeze disposition

[reopened target seam] The disposition is `TERMINAL_OWNER_RECONCILIATION_REQUIRED`.

[proposed frozen C contract] Normal terminal branch semantics are stable, but a normal-only migration 0006 is rejected. It would either:

- embed nullable future cancellation fields;
- split one terminal identity across later tables;
- require destructive CHECK/STRICT-table reconstruction;
- or prematurely define a “complete” terminal family that cannot represent active cancellation.

[proposed frozen C contract] No migration 0006 should be created until one owner tranche freezes:

1. process-group reconciliation identity;
2. descendant-set reconciliation identity;
3. authenticated workspace teardown relation;
4. candidate-capsule custody/retrieval terminal state;
5. delivery/source receipt closure;
6. route/source currentness;
7. exact direct-local versus ES owner routing;
8. private durable readers for each.

# Action-specific prerequisite matrix

| Class | Prerequisite | Exact action blocked | Owner | Needed before | Treatment |
| --- | --- | --- | --- | --- | --- |
| current owning contract | Source authenticity is distinct from claim durability | Productive accept or live cancellation effect | external verifier/RW0-E | live D/E, not 0005 schema | Fail closed; refs/digests are not authentication |
| proposed frozen C contract | Complete phase membership snapshot | Any RW0-C decision | RW0-C over C1 | decision write | LIMIT-257 closure; overflow/conflict blocks |
| current owning contract | Section 41 zero/nine family | Normal accept/repair/replan/reject | Section 41 | decision write | Exact nine and one matching proposal |
| proposed frozen C contract | Current heads and global stop | All fresh decisions | C2B/global-stop owner | decision write | Same-transaction reads and CAS |
| proposed frozen C contract | WorkSpec/manifest/blob operands | Fresh branch relation proof | semantic/custody/observation owners | decision write | Raw resupply; no SQLite persistence |
| proposed frozen C contract | Replan successor family | Replan decision | accepted-intent/WorkSpec authority | decision write | Exact refs plus raw successor WorkSpec |
| proposed frozen C contract | Available singleton latch | Productive direct-local accept | Coordinator state root | accept write | One-way CAS or conflict |
| proposed frozen C contract | Exact committed cancel decision | Cancellation effect and any cancel terminal branch | RW0-C-Decision/C2B | terminal and D | Missing or unresolved means no terminal |
| reopened target seam | Physical reconciliation | Terminal cancel and active-cancel block evidence | D/ES | terminal freeze | Owner contract is a stop condition |
| current owning contract | Exact commit recovery | Any retry after uncertain commit | Coordinator transaction owner | decision/terminal runtime | Three-way readback; no automatic retry |

# Exhaustive owner-reuse ledger

| Class | Owner family | Exact reuse |
| --- | --- | --- |
| current merged implementation | C1 | `/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_c1_semantic_values.py`, `_rw0_c1_row_values.py`, `_rw0_c1_mutation_contracts.py`, `_sqlite_rw0_c1_reader_contracts.py`, `_sqlite_rw0_c1_readers.py`, `_sqlite_rw0_c1.py`; phase, membership, relation, operand, typed payload and recovery families remain unchanged |
| current merged implementation | B1 | `/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`; exact phase, host/custody and terminal values remain pure and unchanged |
| current merged implementation | Wire | `/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_wire_protocol_values.py`; NWPF profile, request/process values and cancellation classifier remain unchanged |
| current merged implementation | Capability | `/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py`; declaration/observation/qualification values remain unchanged |
| current merged implementation | C2A | `/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py`; commands, fences, delivery, observations and capsule identity remain unchanged |
| current merged implementation | C2B | `_development_program_row_values.py`, `_development_effect_row_values.py`, `_development_decision_row_values.py`, `_sqlite_development_reader_contracts.py`, `_sqlite_development_readers.py`; existing rows and reader meanings are reused without widening |
| current merged implementation | Section 41 | `_cognitive_proposal_semantic_values.py`, `_cognitive_proposal_row_values.py`, and current Section 41 readers/runtime; post-execution proposal zero/nine family remains unchanged |
| current merged implementation | Common mutation authority | `sqlite_transition_transaction.py`, `sqlite_writer_session.py`, `sqlite_mutation_transaction_contracts.py`; one writer, operation guard, mutation slot, connection, transaction and commit owner |
| current owning contract | Migration/recovery | `sqlite_migration.py`, packaged cumulative SQL, resource-bound recovery and exact schema verification |
| reopened target seam | D/E/ES | No current Coordinator source may substitute for future physical process, custody, authenticated currentness or ES runtime projections |

[proposed frozen C contract] Any change to an upstream schema ID, digest domain, field order, decision variant, result projection, reader cardinality, head meaning, Section 41 role, Wire profile, or C1 membership meaning is downstream semantic churn and stops RW0-C implementation for reconciliation.

# Forecasts and stop conditions

[report-only uncertainty] A migration audit is likely to focus first on the deferred closure/attestation/decision FK cycle and latch seed verification. Any need to alter migrations 0001–0004, change generation 2, or produce totals other than `68/7/122` is a contract contradiction.

[report-only uncertainty] A transaction audit is likely to focus on the single-work block/replan head postimages and nested-versus-outer graph ordering. If any branch requires a new C2B decision field, variant, or reinterpreted result, implementation must stop.

[report-only uncertainty] A terminal audit is likely to confirm that process exit and current C2A teardown/retrieval observations cannot prove process-group, descendant, custody and source-receipt closure. An exact D/ES projection and reader contract would unblock migration 0006; generic safe refs would not.

# Recommended next step

[proposed frozen C contract] The next authorized governance action should be an independent audit of this RW0-C-Decision freeze, followed—only if accepted—by a separate implementation-boundary audit for migration 0005 and the controller/writer integration surface.

[reopened target seam] In parallel or afterward, a distinct D/ES terminal-owner contract should define the missing physical reconciliation values and readers. Migration 0006 should remain unassigned until that contract passes owner review.

[proposed frozen C contract] No implementation prompt is issued by this report.

# Confidence

[report-only uncertainty] Confidence is high that RW0-C-Decision can be implemented without upstream semantic churn and that one-decision-per-phase, transient handling, latch scope, C2B composition, replay and recovery are now bounded.

[report-only uncertainty] Confidence is high that migration 0006 is presently unsafe to freeze. Literal 0005 SQL checksum and the final touched-test subset are implementation-byte and implementation-boundary outputs, not unresolved semantic decisions.

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
RW0_C_DECISION_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
```

RW0_C_TERMINAL_OWNER_RECONCILIATION_REQUIRED
