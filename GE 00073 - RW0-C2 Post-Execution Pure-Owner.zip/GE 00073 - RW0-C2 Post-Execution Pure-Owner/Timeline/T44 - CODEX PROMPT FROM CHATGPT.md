PROMPT_ID

RW0_POST_EXECUTION_AUDIT_INPUT_CANONICAL_PACKAGE_COMPLETION_V1

TITLE

Coordinator RW0 — complete the post-execution canonical audit package after
source-owner reconciliation, without reopening the accepted architecture

ENGAGEMENT TYPE

Parent-only, local, read-only contract reconciliation.

Do not delegate to subagents or internal audit agents. If parent-only execution
cannot be maintained, stop and report that procedural blocker.

Do not edit repository files, generate repository artifacts, format, stage,
commit, push, create a branch or PR, merge, tag, release, deploy, fetch,
contact a remote/live system, install dependencies, execute tests, run
migrations, open or mutate an operator database, invoke a product worker/model,
or inspect/modify supporting repositories.

Do not issue an implementation prompt.

Print the complete substantive report inline. This engagement completes a
contract-audit input package; it does not implement the pure-owner tranche.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_POST_EXECUTION_AUDIT_PACKAGE_BASELINE_MISMATCH

FIXED INPUT REPORT

Treat the immediately preceding Codex response as fixed input.

If supplied as a file, use:

RW0_Post_Execution_Source_Owner_and_Supply_Binding_Reconciliation_Report.txt

Expected identity:

size:
60980 bytes

SHA-256:
5fc70f589d36e6e69f7ad1010a478c2f2b7f038a25009dc188267332ca223474

logical lines:
1051

final newline:
absent

opening:
# Baseline and fixed input

closing token:
RW0_POST_EXECUTION_SOURCE_OWNERS_AND_SUPPLY_BINDINGS_RECONCILED_READY_FOR_INDEPENDENT_AUDIT

If the fixed input differs, stop:

RW0_POST_EXECUTION_AUDIT_PACKAGE_FIXED_INPUT_MISMATCH

DECISION

The fixed report closes the source-owner errors that motivated its engagement:

- validation and review now bind the current C2A `WorkerObservationV1`;
- invented validation/review observation schemas are withdrawn;
- rank-14 binds the current generic C1 relation row plus the literal current
  relation ID/version/profile/proof mode;
- candidate safe projection is narrowed to the current manifest's `sha1`
  domain;
- policy and risk are correctly treated as owner-supplied attestations rather
  than locally recreated external meaning;
- current global-stop, attempt-fence, effect-fence, host-qualification, and
  requirement-evidence owners are named.

Do not reopen those decisions without a direct current-owner contradiction.

The report is nevertheless not yet a self-contained independent-audit input.
Several newly introduced values are expressed as summaries rather than exact
canonical contracts, and the printed hashes cannot be independently reproduced
from the report alone.

This engagement is a narrow canonical-package completion, not another
architecture reset.

PRESERVED DECISIONS

Preserve:

1. The accepted two-context design.
2. Migration-0003's source/proposal context seam using the T1 input context.
3. Section 41 projection V2 and role-resolution V3.
4. Exactly 15 C1 kinds.
5. Current C2A/B1/B2/C1 meanings unchanged.
6. Validation/review sources use current `WorkerObservationV1`.
7. Rank-14 uses the current generic C1 relation-binding row.
8. Candidate safe projection is `sha1` only and omits private entries.
9. Policy/risk matrices are owner-authored supplied attestations; local code
   validates identity and equality but does not recreate external meaning.
10. FiniteBacklog remains only an adapter behind the generic risk interface.
11. V35–V37 remain forecast-only.
12. No migration, persistence, public API, runtime, external contact, branch
    truth, C2B progression write, latch, terminal, D/E, or ES behavior is
    authorized.

FACT CLASSIFICATION

Use exactly:

- current owning contract;
- current merged implementation;
- compatibility edge;
- proposed post-execution evidence owner contract;
- proposed Section 41 role-resolution contract;
- proposed RW0-C decision-input contract;
- proposed future committed-recovery contract;
- implementation-detail observation;
- report-only uncertainty.

BLOCKER 1 — V38 AND V39 ARE NOT LITERAL CANONICAL GRAMMARS

The fixed report describes V38 as “37 fields” using compressed phrases and V39
as “the analogous review fields.” That is not sufficient to reproduce a
canonical mapping.

Print for both V38 and V39:

- exact class name;
- literal schema ID;
- owner module;
- exact ordered field names, one by one;
- exact built-in type for every field;
- exact enum vocabularies;
- exact nullable/non-null branches;
- exact list ordering/cardinality rules;
- exact generated-ref prefix;
- reference preimage fields and domain;
- self-digest domain and self-exclusion;
- complete source/result relation;
- complete positive golden canonical JSON;
- at least one malformed/substitution golden JSON.

Do not use “analogous,” slash notation, “pair,” “triple,” “six coordinates,”
or an unnamed nested mapping in the final registry.

The validation and review result-set values must explicitly bind:

- the complete `WorkerObservationV1` source identity;
- `delivery_attempt_ref`;
- command, attempt fence, effect fence, candidate, and capsule lineage;
- exact current host qualification;
- exact current requirement-evidence value;
- exact tool-profile pair;
- result-set evidence refs;
- owner-authored result/reason data.

BLOCKER 2 — CURRENT REQUIREMENT-EVIDENCE IDENTITY IS AMBIGUOUS

Current requirement evidence contains:

```text
schema_id
requirement_ref
requirement_digest
work_spec_ref
work_spec_digest
safe_evidence_digest
```

The canonical owner identity is the complete value and its
`safe_evidence_digest`; `requirement_digest` is an embedded requirement
coordinate, not a substitute for the value's self-digest.

For validation and review, freeze:

- exact current class and schema;
- exact module;
- exact fields;
- exact identity mapping;
- exact self-digest domain;
- exact equality to the WorkSpec coordinates;
- which ref/digest appear in support entries, dispositions, and result sets.

Regenerate any identity currently based on an ambiguous
“requirement-evidence ref/digest” pair.

BLOCKER 3 — REVIEWER INDEPENDENCE HAS NO LOCALLY RECONSTRUCTIBLE AUTHOR IDENTITY

The current `WorkerCommandV1` carries command and authority coordinates, but no
reviewable author-person identity. A value containing only reviewer
ref/invocation and an author-command pair cannot locally derive
`reviewer_identity_distinct`.

Preferred resolution:

- classify `ReviewerIndependenceAttestationV1` as an owner-authored supplied
  attestation;
- name its source owner;
- include exact subject reviewer identity and exact compared-author identity or
  author-identity evidence coordinates;
- include the attestation author/source coordinates;
- define exact status/reason relation;
- local code validates canonical identity, source equality, lineage, time, and
  closed status/reason coherence only;
- local code does not independently authenticate either identity.

If the merged repository already exposes an exact author-identity owner value,
name and use it. If it does not, do not invent local derivation from the
command. If an exact owner-authored attestation cannot be frozen without a new
authority decision, return the block token and identify that decision.

Print the complete literal V40 mapping and canonical golden values.

BLOCKER 4 — V41 THROUGH V44 ARE SUMMARIES, NOT EXACT VALUES

For each of V41, V42, V43, and V44 print:

- exact owner status;
- exact owner module;
- complete ordered field list;
- exact built-in types and nullability;
- exact nested branch-entry schema and fields;
- exact enums and tuple/list order;
- exact ref posture: supplied or generated;
- exact reference domain/preimage when generated;
- exact digest domain/self-exclusion;
- exact source-to-matrix or source-to-binding equality relation;
- complete canonical profile JSON;
- complete positive golden canonical value;
- malformed/substitution vector.

Specifically expand, rather than summarize:

- “five branch assertions”;
- “generic source-profile triple”;
- “mapping-evidence pair”;
- “policy pair” and “risk-policy pair”;
- every allowed branch/lane/effect vocabulary;
- all 15 ceiling keys;
- every time/currentness field.

No opaque owner-authored attestation may be called locally derived. No supplied
attestation may be treated as source-authenticated merely because its digest
reproduces.

BLOCKER 5 — DISPOSITION RELATIONS MUST BIND THE COMPLETE CURRENT SOURCE GRAPH

For validation and review, freeze the exact relation from
`WorkerObservationV1` to the new disposition and result-set values.

The equality matrix must explicitly include:

- `delivery_attempt_ref`;
- source kind/ref/invocation;
- observation kind, outcome, reason, evidence refs, and observed_at;
- program/version/accepted-intent/work/revision/attempt;
- effect intent;
- command ref/digest;
- attempt fence ref/digest;
- effect fence ref/digest;
- candidate ref;
- capsule manifest ref and portable digest;
- exact effect class;
- exact host-qualification/tool-profile relation;
- exact requirement-evidence complete value;
- exact result-set or independence attestation identity.

Name the exact current C2A relation callable/profile used to establish the
source graph. Do not leave “across every shared field” as the only executable
contract.

BLOCKER 6 — COMPLETE PROFILE JSON IS MISSING

The fixed report prints only byte counts and digests for changed profiles.

Print complete compact canonical JSON for every changed/current profile needed
to reproduce this package, including at minimum:

- post-execution-semantic-review-input.v2;
- section41-post-execution-proposal-family-projection.v2;
- section41-post-execution-role-resolution.v3;
- post-execution-support-set.v1;
- validation-disposition.v1;
- independent-review-disposition.v1;
- post-execution-standing-policy-matrix.v1;
- post-execution-risk-lane-matrix.v1;
- finite-backlog-risk-source.v1;
- post-execution-global-stop.v1;
- post-execution-source-effect-ceiling.v1;
- every new profile governing V38–V44.

For each, print:

- profile schema ID;
- canonical JSON bytes exactly;
- canonical byte length;
- raw SHA-256;
- digest domain;
- domain-separated digest.

The profile JSON must contain literal owner inventories, not references to
prose elsewhere in the report.

BLOCKER 7 — COMPLETE GOLDEN VALUES ARE MISSING

Print complete canonical golden JSON for:

- V38–V44;
- the corrected validation and review dispositions;
- all six support sets;
- corrected policy and risk matrices;
- corrected global-stop snapshot and ceiling evidence;
- rank-14 typed value and relation row;
- candidate safe projection;
- model-input safe projection;
- private input manifest;
- T1 input context;
- model-input binding;
- evidence supply, including all nine role supplies;
- source invocation;
- proposal evidence rows;
- evidence set;
- proposal;
- owner-family graph input;
- Section 41 projection V2;
- rank-15 typed value;
- all nine role-resolution V3 values.

The report may use a clearly delimited canonical JSON appendix, but it must be
part of the fixed response. Do not require the future auditor to trust an
unattached local file or infer a value from a printed digest.

The evidence supply is synthetic golden material and may be printed in full.
Do not include real secrets, credentials, endpoints, private repository bodies,
or real candidate source.

BLOCKER 8 — MODULE ALLOCATION MUST BE VALUE-SPECIFIC

Reissue the import DAG with a literal assignment for every V01–V44 value.

At minimum resolve:

- which module owns V38–V40;
- which module owns V41–V44;
- which module owns each profile value;
- which modules import current C2A/C1 owners;
- which modules may import the FiniteBacklog adapter;
- that C2A/B1/B2/C1 modules import none of the new modules;
- that generic risk code never imports FiniteBacklog-specific types.

BLOCKER 9 — MECHANICAL REPRODUCTION LEDGER

After completing the package, mechanically reproduce:

- every generated ref;
- every self-digest;
- every support-set identity;
- every profile digest;
- every source-binding digest;
- every evidence-binding digest;
- T1, source invocation, proposal, evidence-set, owner-graph, projection,
  rank-15, and role-resolution identities.

Print a supersession ledger. No stale digest from the fixed input may appear in
a current canonical profile or value except inside the explicit supersession
ledger.

Use at least two independent local SHA-256 implementations for the canonical
profile and golden-value package.

Do not claim the SHA-256 of the complete response inside that same response.
The caller will bind the resulting attachment identity afterward.

ASSURANCE COMPLETION

Extend the finite assurance matrix with ordinary tests and external mutants
covering:

1. Requirement `requirement_digest` substituted where
   `safe_evidence_digest` is required.
2. Requirement WorkSpec ref/digest substitution.
3. Disposition source delivery substitution.
4. Result-set field-name/order/nullability substitution.
5. Review result-set copied from the validation schema.
6. Independence marked `independent` without an exact owner attestation.
7. Independence author identity or reviewer identity substitution.
8. Owner-authored policy/risk matrix with a mismatched source attestation.
9. V41–V44 unknown, omitted, reordered, or extension fields.
10. A printed profile digest whose canonical profile JSON is absent.
11. A golden digest whose full canonical value is absent.
12. A new value assigned to an unspecified owner module.
13. C2A importing any new post-execution module.
14. Generic risk importing a FiniteBacklog-specific module.
15. Stale fixed-input identities surviving outside the supersession ledger.

Permanent tests remain ordinary finite semantic and canonical-vector tests.
Independent audit owns external mutation, patch provenance, and cross-owner
authority review.

IMPLEMENTATION BOUNDARY

Do not issue an implementation prompt.

State whether the completed package is ready for a fresh independent contract
audit. The pure-owner tranche remains migration-free and unimplemented.

STOP CONDITIONS

Return a precise blocker if completion requires:

- changing current C2A/B1/B2/C1 semantics;
- changing migration-0003 or C1 durable row meanings;
- inventing a local reviewer-independence fact without an owner;
- introducing source authentication or external I/O;
- a sixteenth C1 kind;
- persisting capsule entries/private bodies;
- FiniteBacklog in generic target semantics;
- model recommendation authority;
- migration/public/runtime changes;
- branch truth, C2B progression, latch, terminal, D/E, or ES semantics.

RETURN FORMAT

# Baseline and fixed input
# Preserved decisions
# Exact current owner bindings
# Complete V38–V44 canonical grammars
# Complete disposition and source-graph relations
# Complete profile canonical JSON package
# Complete golden canonical value package
# Value-to-owner-module and import DAG
# Mechanical reproduction and supersession ledger
# T1/Section41/resupply equality matrix
# Finite assurance matrix
# Remaining seams and stop conditions
# Recommended next step
# Confidence

SUCCESS TOKEN

Return exactly:

RW0_POST_EXECUTION_CANONICAL_AUDIT_PACKAGE_COMPLETE_READY_FOR_INDEPENDENT_AUDIT

only if:

- V38–V44 have complete literal canonical schemas;
- requirement evidence is bound through its exact owner identity;
- reviewer independence has an explicit owner and does not rely on invented
  local derivation;
- every changed profile is printed in complete canonical JSON;
- every required golden value is printed in complete canonical JSON;
- all refs/digests mechanically reproduce;
- module allocation is exact;
- no stale identity survives outside the supersession ledger;
- the response is self-contained;
- no implementation prompt is issued.

Otherwise return:

RW0_POST_EXECUTION_CANONICAL_AUDIT_PACKAGE_BLOCKED

and identify the exact unresolved value/owner decision.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
