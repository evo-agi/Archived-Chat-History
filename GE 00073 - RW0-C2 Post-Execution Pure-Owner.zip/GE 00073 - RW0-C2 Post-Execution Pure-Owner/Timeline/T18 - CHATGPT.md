# Decision

**Accept the audit’s `BLOCK`. Do not move to an implementation-boundary freeze.**

This is no longer a case of filling in a few omitted implementation details. The audit found two explicit owner-contract conflicts plus six major contract-completeness defects and one assurance defect:

- **High:** latch ownership conflicts with current governing documents.
- **High:** the pre-contact finite-reason mapping is absent.
- **High:** the Section 41 authorization projection cannot be deterministically reconstructed.
- **High:** command, basis, plan, receipt, and selector identities are incomplete.
- **High:** branch row builders and CAS postimages are under-specified.
- **High:** cancel silently omits the currently promised decision-evidence binding family.
- **High:** C2B receipt insertion and complete family readback are ordered inconsistently.
- **High:** three-way recovery lacks branch-specific locator and collision matrices.
- **Medium:** the assurance plan is thematic rather than finite and causal.

The audit did confirm several valuable foundations:

```text
Both printed profile digests:
valid

Migration-0002 row variants:
physically capable of representing all proposed decision kinds

Single-work LIMIT 2 profile:
sound

Broad branch row shapes:
plausible

Migration-0002 FK cycles:
compatible in principle with the proposed transaction

One-controller / one-transaction architecture:
sound
```

Those pieces should be preserved.

## The critical architectural choice

The next pass must stop pretending the current owner documents already express the intended target. Two owner seams need an **explicit governing reset**.

### Latch ownership

The correct split remains:

```text
C2B:
owns the exact candidate-acceptance progression result and the semantic fact
that only this branch can participate in latch consumption

RW0-C:
owns direct-local and productive-output proof, the physical singleton row,
the CAS, the outer result/receipt, and composed recovery

Common transaction:
commits the C2B accept family, C closure, and latch postimage atomically
```

Current documents that say the C2B decision itself physically consumes the latch must be explicitly superseded. This is downstream owner-contract churn, not an ordinary compatibility edit.

### Cancel evidence binding

The clean target is:

```text
C2B cancel family:
owner-neutral cancellation authorization basis
+ unchanged cancel decision
+ unchanged progression result
+ unchanged development receipt
+ completed nested C2B receipt

RW0-C decision closure:
sole durable evidence-binding family for the RW0 decision
```

A new hidden C2B evidence-binding table should not be invented merely to preserve stale planned prose. The governing documents must explicitly supersede that earlier target while leaving migration `0002` and the decision row grammar unchanged.

## Why the remaining work belongs in one final reconciliation

After those owner decisions, the next report must close the mechanical contracts completely:

1. A total mapping from the frozen RW0-C pre-contact reason vocabulary to the 13 C2B authorization categories.
2. A pure **Section-41-owned** authorization projection with exact source, artifact, proposal, evidence, disposition, selection-head, lineage, cardinality, role order, and digest rules.
3. Closed schemas and digest domains for every command, basis, assignment, plan, receipt, selector, conflict, and recovery value.
4. Field-level row builders for all seven branches.
5. Exact CAS postimage formulas and zero/one/>1 row-count handling.
6. Correct write ordering:

```text
C2B rows
C2B head CAS
C2B persisted receipt
complete C2B readback
completed nested receipt projection
outer RW0-C rows
accept-only latch CAS
outer receipt
outer readback
capability invalidation
one COMMIT
```

7. Branch-specific committed/absent/unresolved recovery matrices.
8. A finite claim-to-test and claim-to-audit matrix covering every insert, CAS, receipt, readback, commit, cleanup, partial-family, and collision boundary.

Only after this report survives another independent contract audit should we derive the implementation path allowlist.

# Codex handoff

Send this prompt to the same C2B/RW0-C contract conversation:

:chatgpt-content-reference{index="0"}[Download the governing reset and final contract prompt](sandbox:/mnt/data/Coordinator_C2B_Progression_Decision_Governing_Reset_and_Final_Contract_Prompt.txt)

```text
Filename:
Coordinator_C2B_Progression_Decision_Governing_Reset_and_Final_Contract_Prompt.txt

Size:
20,063 bytes

SHA-256:
ec271e3cbbd1d5da6b567fcf5de023766ff1511b8ce759446612bf8cdff054d3
```

The required success token is:

```text
C2B_PROGRESSION_DECISION_GOVERNING_RESET_AND_FINAL_CONTRACT_READY_FOR_INDEPENDENT_AUDIT
```

The prompt remains strictly read-only. It does not authorize source edits, documentation edits, migration work, tests, or implementation.

## Sequence after a successful reconciliation

```text
1. Fresh independent audit of the corrected owner contract.
2. Read-only combined implementation-boundary freeze:
   - Section 41 projection owner
   - C2B progression owner
   - RW0-C Decision
   - migration 0005
   - physical latch composition
3. Only then issue an implementation prompt.
```

A separately published C2B writer is still not required. The likely target remains one combined implementation candidate with separate authoritative modules and one common transaction, accepted only as a complete capability.

## Current project state

```text
RW0-C1:
merged and current

C2B progression-decision owner:
audit blocked; governing reset and exact contract closure required

RW0-C-Decision:
blocked on C2B owner acceptance

migration 0005:
not implementation-authorized

RW0-C-Terminal / migration 0006:
blocked on D/Execution Substrate terminal-evidence owners

RW0-D / RW0-E:
not implemented
```

### Source

- Codex’s independent C2B progression-decision owner-contract audit supplied in this turn.

**Confidence:** High that the `BLOCK` is correct; high that the latch and cancel-evidence findings require explicit owner resets; high that another audit or implementation prompt before this reconciliation would only prolong the loop.
