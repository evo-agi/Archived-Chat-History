Here is Codex's response:

# Baseline and path-grounding correction

[current merged implementation] The required local baseline matches exactly: branch `trunk_dev`; HEAD `a3ff0b7f4f0c2378c2962e24612d605489b51638`; tree `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0`; sole parent `047563de5a443b0f8323401c92979ae2e444d2ed`; subject `feat: implement RW0-C1 durable evidence (#7)`; upstream `origin/trunk_dev`; ahead/behind `0/0`; one worktree; empty status, index, untracked, and unmerged sets.

[current merged implementation] The upstream comparison used local refs only; no fetch or other remote contact occurred.

[compatibility edge] The earlier `src/governed_execution_nwp_coordinator/` path was a report defect and does not exist. The authoritative roots are [`src/ge_nwp_coordinator/`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator>) and [`src/ge_nwp_coordinator/sqlite_migrations/`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations>).

[compatibility edge] Early status prose in [`c2b-durable-development-state.md:12`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:12>) still describes a migration-0002-era posture, while the merged database tip and current reader contract are generation 4; that documentation drift must be corrected when implementation is authorized, not silently inherited.

# Preserved owner decisions

[proposed frozen C2B owner contract] One private branch-parameterized family owns exactly: `accept/candidate_acceptance`, `repair/candidate_repair`, `replan/attempt_selecting_replan`, `terminal_reject/program_terminal_reject`, `block/program_block`, and `cancel/effect_cancellation`.

[proposed frozen C2B owner contract] Version-advancing branches use the explicit single-work profile; cancellation neither reads nor mutates membership.

[current owning contract] The existing decision vocabulary, variant nullability, version effects, and cancellation non-effects are already fixed in [`c2b-durable-development-state.md:200`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:200>), [`_development_decision_row_values.py:35`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:35>), and immutable [`0002_development_program_and_effect_state.sql:475`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql:475>).

[proposed frozen C2B owner contract] C2B owns semantic eligibility, exact rows and postimages, version/revision/edge construction, work-before-program CAS, nested result and receipt, replay, readback, and recovery.

[proposed frozen C2B owner contract] RW0-C consumes one bounded private C2B facade in the common transaction; C2B never imports RW0-C.

[proposed frozen C2B owner contract] There is no standalone C2B commit path: one controller, mutation slot, connection, `BEGIN IMMEDIATE`, timestamp, capability epoch, and commit attempt remain authoritative.

[current owning contract] Migration `0005` and the physical acceptance latch remain RW0-C-owned; migrations `0001`–`0004` remain immutable.

[proposed frozen C2B owner contract] C2B emits only the pure assertion that a fresh productive direct-local acceptance is latch-eligible; it neither stores nor CAS-updates the latch.

[proposed frozen C2B owner contract] No decision kind, variant, persistent field, state, version kind, work-revision kind, or edge kind is added or reinterpreted.

[current owning contract] RW0-C Terminal and migration `0006` remain blocked on D/Execution Substrate terminal-evidence ownership, as recorded in [`autonomous-software-development-operating-model.md:586`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/autonomous-software-development-operating-model.md:586>).

# Exact profile identity

[proposed frozen C2B owner contract] The profile identity is:

- `schema_id`: `governed-execution.nwp-development-progression-owner-profile.v1`
- `profile_ref`: `c2b-progression-single-work-v1`
- canonicalization: recursively closed JSON values, object keys sorted lexicographically, array order preserved, UTF-8, `ensure_ascii=false`, `allow_nan=false`, separators `,` and `:`
- digest domain: `governed-execution.nwp-development-progression-owner-profile.v1.identity`
- digest operation: `SHA-256(domain UTF-8 || 0x00 || canonical manifest bytes)`
- canonical byte length: `5779`
- profile digest: `3a290f811200722e78e7d3e8bb5a7f20eb23eaa41162f02f6b574fe099b7e94f`

[proposed frozen C2B owner contract] The following single line is the exact canonical manifest; whitespace outside the code block is not part of it.

```json
{"authority_nonclaims":["no_external_authority","no_executable_permission","no_external_io","no_public_api","no_standalone_commit","no_latch_storage_or_cas","no_multi_work_mutation","no_new_persisted_vocabulary"],"branches":[{"accepted_intent":"retain_basis","allowed_program_states":["active"],"allowed_work_states":["planned","repair_required"],"branch":"candidate_acceptance","cas_order":["work_item_head","program_head"],"decision_kind":"accept","decision_variant":"candidate_acceptance","global_stop":"clear_required","graph_roles":["program_head_postimage","progression_decision","program_version","work_item_head_postimage","program_version_work_item"],"latch_assertion":"fresh_productive_direct_local_accept_eligible","membership":"copy_sole_basis_member","post_program_state":"accepted","post_work_state":"accepted","required_basis":"selected_phase_and_matching_accept_candidate_post_execution_proposal","result_version":"append_accepted_basis_plus_one","revision_edges":[],"work_revision":"retain_basis","work_spec":"retain_basis_without_new_binding"},{"accepted_intent":"retain_basis","allowed_program_states":["active"],"allowed_work_states":["planned","repair_required"],"branch":"candidate_repair","cas_order":["work_item_head","program_head"],"decision_kind":"repair","decision_variant":"candidate_repair","global_stop":"clear_required","graph_roles":["program_head_postimage","progression_decision","program_version","work_item_head_postimage","program_version_work_item","work_spec_binding"],"latch_assertion":"none","membership":"copy_sole_basis_member","post_program_state":"active","post_work_state":"repair_required","required_basis":"selected_phase_and_matching_repair_candidate_post_execution_proposal","result_version":"append_repair_basis_plus_one","revision_edges":[],"work_revision":"retain_basis","work_spec":"append_version_scoped_rebinding_for_successor_attempt"},{"accepted_intent":"append_superseding_revision","allowed_program_states":["active"],"allowed_work_states":["planned","repair_required"],"branch":"attempt_selecting_replan","cas_order":["work_item_head","program_head"],"decision_kind":"replan","decision_variant":"attempt_selecting_replan","global_stop":"clear_required","graph_roles":["program_head_postimage","accepted_intent_revision","progression_decision","program_version","work_item_head_postimage","work_item_revision","revision_edge","revision_edge","program_version_work_item","work_spec_binding"],"latch_assertion":"none","membership":"same_work_new_revision","post_program_state":"active","post_work_state":"planned","required_basis":"selected_phase_and_matching_replan_post_execution_proposal","result_version":"append_replan_basis_plus_one","revision_edges":["accepted_intent_supersedes","work_item_supersedes"],"work_revision":"append_replan_revision","work_spec":"append_binding_for_new_version_and_revision"},{"accepted_intent":"retain_basis","allowed_program_states":["active"],"allowed_work_states":["planned","repair_required"],"branch":"program_terminal_reject","cas_order":["work_item_head","program_head"],"decision_kind":"terminal_reject","decision_variant":"program_terminal_reject","global_stop":"clear_or_active","graph_roles":["program_head_postimage","progression_decision","program_version","work_item_head_postimage","program_version_work_item"],"latch_assertion":"none","membership":"copy_sole_basis_member","post_program_state":"terminal_rejected","post_work_state":"terminal_rejected","required_basis":"selected_phase_and_matching_terminal_reject_post_execution_proposal","result_version":"append_terminal_rejected_basis_plus_one","revision_edges":[],"work_revision":"retain_basis","work_spec":"retain_basis_without_new_binding"},{"accepted_intent":"retain_basis","allowed_program_states":["active"],"allowed_work_states":["planned","repair_required"],"branch":"program_block","cas_order":["work_item_head","program_head"],"decision_kind":"block","decision_variant":"program_block","global_stop":"clear_or_active","graph_roles":["program_head_postimage","progression_decision","program_version","work_item_head_postimage","program_version_work_item"],"latch_assertion":"none","membership":"copy_sole_basis_member","post_program_state":"blocked","post_work_state":"blocked","required_basis":"selected_phase_and_matching_block_post_execution_proposal","result_version":"append_blocked_basis_plus_one","revision_edges":[],"work_revision":"retain_basis","work_spec":"retain_basis_without_new_binding"},{"accepted_intent":"no_change","allowed_program_states":["active","accepted","terminal_rejected","blocked"],"allowed_work_states":[],"branch":"effect_cancellation","cas_order":[],"decision_kind":"cancel","decision_variant":"effect_cancellation","global_stop":"clear_or_active","graph_roles":["progression_decision"],"latch_assertion":"none","membership":"not_read_or_written","post_program_state":"unchanged","post_work_state":"not_read_or_written","required_basis":"selected_phase_exact_target_effect_and_cancellation_source","result_version":"basis_version_no_new_row","revision_edges":[],"work_revision":"no_change","work_spec":"no_change"}],"canonicalization":"compact_sorted_key_utf8_json","command_schema_id":"governed-execution.nwp-record-development-progression-decision-command.v1","profile_ref":"c2b-progression-single-work-v1","recovery_outcomes":["committed_exact","definitely_not_committed","unresolved"],"schema_id":"governed-execution.nwp-development-progression-owner-profile.v1","single_work_applicability":"all_version_advancing_branches_only","single_work_query":{"fetch_count":257,"logical_maximum":256,"profile_conflict":"progression_profile_requires_exactly_one_work_item","required_membership_count":1,"required_ordinal":0},"timestamp_ownership":"one_outer_transaction_timestamp"}
```

[implementation detail] The byte length and domain-separated digest were calculated from that literal in memory and independently cross-checked with two SHA-256 implementations; neither calculation wrote repository data.

[proposed frozen C2B owner contract] The exact `(profile_ref, profile_digest)` pair is present in the command, completed-receipt projection, RW0-C closure attestation, exact replay proof, and recovery selector/proof.

# Exact command grammar

[current merged implementation] The reserved command schema ID already exists in the closed receipt vocabulary at [`_development_decision_row_values.py:72`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:72>).

[proposed frozen C2B owner contract] The command uses that schema ID and the domain `governed-execution.nwp-record-development-progression-decision-command.v1.identity`; its derived digest is not an input field.

[proposed frozen C2B owner contract] The exact ordered command fields are:

```text
01 schema_id
02 owner_profile_ref
03 owner_profile_digest
04 branch
05 mutation_ref
06 decision_ref
07 program_ref
08 phase_basis_ref
09 phase_basis_digest
10 post_execution_proposal_member_ref
11 post_execution_proposal_member_digest
12 basis_decision_ref
13 basis_decision_digest
14 basis_program_version_ref
15 basis_program_version_number
16 basis_program_version_digest
17 expected_program_head
18 expected_sole_membership
19 expected_sole_work_head
20 expected_sole_work_revision
21 coding_global_stop_ref
22 coding_global_stop_version
23 expected_global_stop_preimage
24 selection_head_preimage
25 target_effect_intent_ref
26 target_effect_class
27 target_effect_fence_ref
28 target_effect_fence_digest
29 expected_target_effect_head
30 originating_command_ref
31 originating_command_digest
32 target_capsule_manifest_ref
33 target_portable_capsule_digest
34 source_directive_ref
35 source_directive_digest
36 source_evidence_ref
37 source_evidence_digest
38 resulting_program_version_ref
39 resulting_accepted_intent_revision_ref
40 resulting_work_item_revision_ref
41 accepted_intent_edge_ref
42 work_item_edge_ref
43 resulting_work_spec_ref
44 resulting_work_spec_safe_projection
45 replan_source_intent_ref
46 replan_source_intent_digest
47 replan_safe_projection_digest
48 preassigned_semantic_attempt_ref
49 preassigned_candidate_ref
50 preassigned_effect_intent_ref
51 preassigned_effect_fence_ref
52 preassigned_delivery_attempt_ref
```

[proposed frozen C2B owner contract] Scalar refs are exact built-in `str` values satisfying the current safe-ref grammar and 1–96-byte bound; digests are exact lowercase 64-hex `str`; version numbers are exact built-in non-negative `int`, never `bool`; `branch` is one of the six manifest branches.

[proposed frozen C2B owner contract] `expected_program_head`, `expected_sole_membership`, `expected_sole_work_head`, `expected_sole_work_revision`, `expected_global_stop_preimage`, `selection_head_preimage`, and `expected_target_effect_head` are sealed typed values with the exact existing complete row projections, including stored digest where the table has one; mappings or caller-selected subsets are forbidden.

[proposed frozen C2B owner contract] `resulting_work_spec_safe_projection` is the exact 16-field `DevelopmentWorkSpecSafeProjection` value already defined at [`_development_program_row_values.py:564`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_program_row_values.py:564>), not arbitrary JSON.

[proposed frozen C2B owner contract] Canonical command bytes are the same compact sorted-key UTF-8 form as the profile; the digest is `SHA-256(command-domain UTF-8 || 0x00 || canonical bytes)` and the closed bound is `1..32768` canonical bytes.

[proposed frozen C2B owner contract] The branch union is exact:

| Classification | Branch | Required branch-specific fields | Fields required null |
|---|---|---|---|
| proposed frozen C2B owner contract | All six | profile pair, mutation/decision/program, phase basis, basis decision/version, complete program-head/global-stop/selection preimages | Every unlisted branch-only field |
| proposed frozen C2B owner contract | Five advancing branches | post-execution proposal member, sole membership/head/revision, resulting program-version ref | cancellation target/source/preassignments |
| proposed frozen C2B owner contract | `candidate_acceptance` | no additional preassignment | result intent/work revision/edges/WorkSpec and all successor/cancel fields |
| proposed frozen C2B owner contract | `candidate_repair` | new WorkSpec ref/projection and successor attempt/candidate | replan intent/work revision/edges and cancel fields |
| proposed frozen C2B owner contract | `attempt_selecting_replan` | new intent ref, work-revision ref, two edge refs, WorkSpec ref/projection, source-intent triple, successor attempt/candidate | cancellation fields |
| proposed frozen C2B owner contract | `program_terminal_reject` | no additional preassignment | result intent/work revision/edges/WorkSpec, successor, and cancel fields |
| proposed frozen C2B owner contract | `program_block` | no additional preassignment | result intent/work revision/edges/WorkSpec, successor, and cancel fields |
| proposed frozen C2B owner contract | `effect_cancellation` | target effect/class/fence/head, originating command pair, source directive/evidence pairs, preassigned cancellation effect/fence/delivery | post-execution member, sole-work values, new version/revision/edge/WorkSpec, successor attempt/candidate |
| proposed frozen C2B owner contract | Cancellation of `author_candidate` | capsule pair null | — |
| proposed frozen C2B owner contract | Cancellation of `validate_candidate` or `review_candidate` | both capsule fields present | — |

[proposed frozen C2B owner contract] Every advancing branch requires the exact current K8 selection identity—program, semantic attempt, candidate, effect intent, author command, attempt fence, effect fence, and delivery attempt—and a complete current selection-head preimage whose disposition is `selected_for_dispatch_gates`; the current K8 definition is pinned in [`_development_pre_execution_plan_disposition_contracts.py:48`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py:48>).

[proposed frozen C2B owner contract] Post-execution recommendation mapping is exact: `accept_candidate→candidate_acceptance`, `repair_candidate→candidate_repair`, `replan→attempt_selecting_replan`, `terminal_reject→program_terminal_reject`, and `block→program_block`; the existing closed recommendations are at [`_cognitive_proposal_row_values.py:423`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_cognitive_proposal_row_values.py:423>).

[proposed frozen C2B owner contract] Cancellation binds the selected phase, exact target effect lineage, target-head preimage, and separately owned source directive/evidence; it has no post-execution recommendation member.

[proposed frozen C2B owner contract] Redundant pairs must agree exactly: stop scalar ref/version with the full stop preimage; basis scalar fields with their rows; WorkSpec ref with its safe projection; selection K8 fields with its head; target fields with the effect/head/command lineage. A mismatch is preflight failure before mutation-slot acquisition.

[proposed frozen C2B owner contract] The caller supplies identities and immutable source projections only. C2B derives reason, states, numbers, postimages, row digests, relation-key digests, graph roles/order, SQL, result/receipt values, timestamp, and latch eligibility.

[proposed frozen C2B owner contract] The profile admits one membership row at ordinal zero for advancing branches. Zero, malformed, or over-limit membership is integrity failure; a valid multi-work basis is the closed profile conflict `progression_profile_requires_exactly_one_work_item`.

# Exact branch decision-row matrix

[current merged implementation] The persistent decision projection is exactly the current 43-column tuple and the current six variants preserve their existing nullability rules; direct tests pin the tuple and variants in [`test_c2b2_development_decision_row_values.py:16`](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b2_development_decision_row_values.py:16>).

[proposed frozen C2B owner contract] Legend: `C` means validated caller-preassigned value; `B` means copied from an authoritative current basis row; `S` means copied from the verified selection lineage; `T` means copied from the verified cancellation target; `D` means deterministically derived by C2B; `N` means SQL `NULL`.

| # | Field | Acceptance | Repair | Replan | Terminal | Block | Cancel |
|---:|---|---|---|---|---|---|---|
| 1 | `schema_id` | D decision schema | D | D | D | D | D |
| 2 | `mutation_ref` | C | C | C | C | C | C |
| 3 | `decision_ref` | C | C | C | C | C | C |
| 4 | `program_ref` | C/B | C/B | C/B | C/B | C/B | C/B |
| 5 | `decision_kind` | D `accept` | D `repair` | D `replan` | D `terminal_reject` | D `block` | D `cancel` |
| 6 | `decision_variant` | D `candidate_acceptance` | D `candidate_repair` | D `attempt_selecting_replan` | D `program_terminal_reject` | D `program_block` | D `effect_cancellation` |
| 7 | `basis_decision_ref` | B | B | B | B | B | B |
| 8 | `basis_program_version_ref` | B | B | B | B | B | B |
| 9 | `basis_program_version_number` | B | B | B | B | B | B |
| 10 | `expected_program_head_revision` | B head | B head | B head | B head | B head | B head |
| 11 | `resulting_program_version_ref` | C | C | C | C | C | N |
| 12 | `resulting_program_version_number` | D `basis+1` | D `basis+1` | D `basis+1` | D `basis+1` | D `basis+1` | N |
| 13 | `selected_semantic_attempt_ref` | S | S | S | S | N | S |
| 14 | `selected_candidate_ref` | S | S | S | S | N | S |
| 15 | `selected_attempt_fence_ref` | S | S | S | S | N | S |
| 16 | `selected_attempt_fence_digest` | S | S | S | S | N | S |
| 17 | `target_effect_intent_ref` | N | N | N | N | N | T |
| 18 | `target_effect_class` | N | N | N | N | N | T |
| 19 | `target_effect_fence_ref` | N | N | N | N | N | T |
| 20 | `target_effect_fence_digest` | N | N | N | N | N | T |
| 21 | `expected_target_effect_head_revision` | N | N | N | N | N | T head |
| 22 | `target_delivery_attempt_ref` | N | N | N | N | N | N |
| 23 | `originating_command_ref` | N | N | N | N | N | T |
| 24 | `originating_command_digest` | N | N | N | N | N | T |
| 25 | `target_capsule_manifest_ref` | N | N | N | N | N | C for validate/review; N for author |
| 26 | `target_portable_capsule_digest` | N | N | N | N | N | C for validate/review; N for author |
| 27 | `coding_global_stop_ref` | B stop | B stop | B stop | B stop | B stop | B stop |
| 28 | `coding_global_stop_version` | B stop | B stop | B stop | B stop | B stop | B stop |
| 29 | `source_directive_ref` | N | N | N | N | N | C |
| 30 | `source_directive_digest` | N | N | N | N | N | C |
| 31 | `source_evidence_ref` | N | N | N | N | N | C |
| 32 | `source_evidence_digest` | N | N | N | N | N | C |
| 33 | `preassigned_semantic_attempt_ref` | N | C | C | N | N | N |
| 34 | `preassigned_candidate_ref` | N | C | C | N | N | N |
| 35 | `preassigned_effect_intent_ref` | N | N | N | N | N | C |
| 36 | `preassigned_effect_fence_ref` | N | N | N | N | N | C |
| 37 | `preassigned_delivery_attempt_ref` | N | N | N | N | N | C |
| 38 | `resulting_accepted_intent_revision_ref` | N | N | C | N | N | N |
| 39 | `resulting_work_item_ref` | N | N | D sole member | N | N | N |
| 40 | `resulting_work_item_revision_ref` | N | N | C | N | N | N |
| 41 | `reason_code` | D `progression.candidate_accepted` | D `progression.candidate_repair_required` | D `progression.attempt_replanned` | D `progression.program_terminal_rejected` | D `progression.program_blocked` | D `progression.effect_cancellation_planned` |
| 42 | `decided_at` | D outer timestamp | D | D | D | D | D |
| 43 | `decision_digest` | D current identity | D | D | D | D | D |

[proposed frozen C2B owner contract] Reason codes come exclusively from this closed C2B profile vocabulary. Section 41 proposal reasons remain transitively bound by the proposal/member digest but are never copied into the decision row.

# Branch preconditions and postimages

| Classification | Branch | Exact preconditions | Exact durable postimage |
|---|---|---|---|
| proposed frozen C2B owner contract | Acceptance | Program `active`; sole work `planned` or `repair_required`; clear stop; exact selected K8 lineage; matching `accept_candidate` member; productive observation; all selected rows and digests coherent | Append version kind `accepted`, number `basis+1`; retain intent/work revision; one ordinal-0 membership; work head `accepted`, program head `accepted`; no edge or WorkSpec row |
| proposed frozen C2B owner contract | Repair | Program `active`; sole work `planned` or `repair_required`; clear stop; exact selected lineage; matching `repair_candidate` member; successor attempt/candidate refs collision-free | Append version kind `repair`; retain intent/work revision; one membership; append a new version-scoped WorkSpec binding with unchanged safe semantic scope; work head `repair_required`, program head `active`; no edge |
| proposed frozen C2B owner contract | Replan | Program `active`; sole work `planned` or `repair_required`; clear stop; exact selected lineage; matching `replan` member; source intent and all successor refs collision-free | Append intent revision `basis+1`, work revision kind `replan` and number `basis+1`, version kind `replan` and number `basis+1`, one membership, new WorkSpec binding, then `accepted_intent_supersedes` and `work_item_supersedes` edges; heads become `planned`/`active` |
| proposed frozen C2B owner contract | Terminal reject | Program `active`; sole work `planned` or `repair_required`; clear or active stop; exact selected lineage; matching `terminal_reject` member | Append version kind `terminal_rejected`; retain intent/work revision; one membership; heads become `terminal_rejected`; no edge or WorkSpec row |
| proposed frozen C2B owner contract | Block | Program `active`; sole work `planned` or `repair_required`; clear or active stop; selected phase and matching `block` member are verified although decision selected fields stay null | Append version kind `blocked`; retain intent/work revision; one membership; heads become `blocked`; no edge or WorkSpec row |
| proposed frozen C2B owner contract | Cancellation | Program may be `active`, `accepted`, `terminal_rejected`, or `blocked`; clear or active stop; exact selected lineage and target; target class `author_candidate`, `validate_candidate`, or `review_candidate`; target effect state exactly `ready_for_delivery`, `delivery_pending`, `delivery_outcome_unknown`, or `observed` | Insert only the cancel decision and nested receipt; program/version/membership/work/head/effect-head state is unchanged |

[current owning contract] Cancellation creates no effect, delivery, observation, version, or head update, and target-head CAS remains owned by later cancellation-effect establishment; this boundary is explicit at [`c2b-durable-development-state.md:232`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:232>).

[proposed frozen C2B owner contract] A repair WorkSpec binding is mandatory because its successor author effect is bound to the newly appended program version even though the work revision and semantic scope remain unchanged.

[proposed frozen C2B owner contract] C2B preassigns repair/replan successor attempt/candidate identities but does not create those rows; current author-effect establishment remains the owner that consumes the committed decision and creates the semantic attempt and effect family, consistent with [`c2b-durable-development-state.md:367`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:367>).

# Single-work query contract

[proposed frozen C2B owner contract] The additive family-local query ID is `progression_single_work_membership_profile`, with exact SQL:

```sql
SELECT schema_id, program_ref, program_version_ref, work_item_ref,
       work_item_revision_ref, membership_ordinal, created_at,
       membership_digest
FROM development_program_version_work_items
WHERE program_ref = ? AND program_version_ref = ?
ORDER BY membership_ordinal ASC, work_item_ref ASC
LIMIT 257
```

[proposed frozen C2B owner contract] The reader performs exactly one `fetchmany(257)` and accepts only exact built-in tuple rows in the displayed eight-column order.

| Classification | Observation | Classification |
|---|---|---|
| proposed frozen C2B owner contract | Zero rows | `database_integrity_failure`; current program versions require non-empty dense membership |
| proposed frozen C2B owner contract | One coherent row at ordinal `0` | Profile admitted |
| proposed frozen C2B owner contract | Two through 256 coherent, dense, unique rows | Private apply conflict `progression_profile_requires_exactly_one_work_item` |
| proposed frozen C2B owner contract | 257 rows | `database_integrity_failure`; the current logical bound was exceeded |
| proposed frozen C2B owner contract | Bad digest, tuple, program/version relation, duplicate, gap, or nonzero sole ordinal | `database_integrity_failure` |

[current owning contract] The existing page contract already uses explicit columns, deterministic ordering, a logical maximum of 256, and physical `LIMIT 257`; zero membership is malformed, not merely unsupported. See [`c2b2-private-readers.md:142`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b2-private-readers.md:142>) and [`_sqlite_development_reader_contracts.py:452`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py:452>).

[proposed frozen C2B owner contract] This query is private to the progression family and does not change or renumber the frozen twenty-four-query C2B2 inventory.

# Immutable write-plan contract

[proposed frozen C2B owner contract] The sealed plan schema is `governed-execution.nwp-development-progression-write-plan.v1`; its variants are exactly the six profile branch names.

[proposed frozen C2B owner contract] Its exact ordered fields are:

```text
schema_id
owner_profile_ref
owner_profile_digest
branch
command_digest
decision_row
accepted_intent_revision_row
work_item_revision_row
program_version_row
membership_rows
work_spec_binding_row
revision_edge_rows
work_head_cas
program_head_cas
mutation_graph_entries
progression_result
mutation_receipt_row
completed_receipt_projection
```

[proposed frozen C2B owner contract] Each row field is the existing exact private row-value type; optional rows use typed `None`; repeated rows use immutable tuples. Generic mappings, raw JSON/BLOBs, SQL text, caller-selected states, and caller-selected graph roles are forbidden.

| Classification | Variant | Plan population |
|---|---|---|
| proposed frozen C2B owner contract | Acceptance, terminal, block | Decision, program version, one membership, two CAS specs, graph, result, receipt, completed projection |
| proposed frozen C2B owner contract | Repair | Acceptance-shaped population plus one version-scoped WorkSpec binding |
| proposed frozen C2B owner contract | Replan | Decision, intent revision, work revision, version, one membership, WorkSpec binding, two ordered edges, two CAS specs, graph, result, receipt, completed projection |
| proposed frozen C2B owner contract | Cancellation | Decision, graph, result, receipt, completed projection; all version/revision/membership/WorkSpec/edge/CAS fields absent or empty |

[proposed frozen C2B owner contract] The CAS schemas are `governed-execution.nwp-development-progression-work-head-cas.v1` and `governed-execution.nwp-development-progression-program-head-cas.v1`, each with ordered fields `schema_id`, `expected_preimage`, `resulting_postimage`.

[proposed frozen C2B owner contract] Replan relation-key digests use schema/domain `governed-execution.nwp-development-revision-edge-relation-key.v1.identity` over exactly `program_ref`, `revision_edge_kind`, `from_accepted_intent_revision_ref`, `to_accepted_intent_revision_ref`, `from_work_item_revision_ref`, and `to_work_item_revision_ref`.

# SQL and private reader contracts

[current merged implementation] Existing row-column authority is in [`_development_program_row_values.py:35`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_program_row_values.py:35>), [`_development_effect_row_values.py:44`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_effect_row_values.py:44>), [`_development_decision_row_values.py:35`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:35>), and [`_cognitive_proposal_row_values.py:299`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_cognitive_proposal_row_values.py:299>).

[proposed frozen C2B owner contract] Exact query projection symbols expand as follows; `D43` is the 43-field decision order printed above.

```text
R19 = schema_id, mutation_ref, mutation_family, command_schema_id,
      command_digest, program_ref, decision_ref, result_program_version_ref,
      result_semantic_attempt_ref, result_effect_intent_ref,
      result_effect_fence_ref, result_delivery_attempt_ref,
      result_observation_ref, result_decision_ref, result_class,
      result_projection_digest, mutation_graph_digest, outcome, committed_at

PH8 = schema_id, program_ref, current_program_version_ref,
      current_program_version_number, head_revision, program_state,
      updated_at, head_digest

PV9 = schema_id, program_version_ref, program_ref, program_version_number,
      program_version_kind, creating_decision_ref,
      accepted_intent_revision_ref, created_at, program_version_digest

AI10 = schema_id, accepted_intent_revision_ref, program_ref,
       accepted_intent_revision_number, prior_accepted_intent_revision_ref,
       source_intent_ref, source_intent_digest, safe_projection_digest,
       created_at, accepted_intent_revision_digest

WH9 = schema_id, work_item_ref, program_ref, current_work_item_revision_ref,
      current_work_item_revision_number, head_revision, work_state,
      updated_at, head_digest

WR10 = schema_id, work_item_revision_ref, program_ref, work_item_ref,
       work_item_revision_number, work_item_revision_kind,
       prior_work_item_revision_ref, accepted_intent_revision_ref,
       created_at, work_item_revision_digest

M8 = schema_id, program_ref, program_version_ref, work_item_ref,
     work_item_revision_ref, membership_ordinal, created_at, membership_digest

E11 = schema_id, revision_edge_ref, relation_key_digest, program_ref,
      revision_edge_kind, from_accepted_intent_revision_ref,
      to_accepted_intent_revision_ref, from_work_item_revision_ref,
      to_work_item_revision_ref, created_at, revision_edge_digest

WS18 = schema_id, work_spec_ref, program_ref, program_version_ref,
       accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
       repository_ref, base_git_object_format, base_git_oid,
       authorized_paths_json, validation_requirement_ref,
       review_requirement_ref, privacy_classification, work_spec_digest,
       safe_projection_digest, recorded_at, work_spec_binding_digest

SA13 = schema_id, semantic_attempt_ref, program_ref, program_version_ref,
       accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
       attempt_number, candidate_ref, attempt_phase, selection_decision_ref,
       created_at, semantic_attempt_digest

AF37 = schema_id, attempt_fence_ref, parent_standing_grant_ref,
       parent_standing_grant_digest, attempt_authorization_ref,
       attempt_authorization_digest, program_ref, program_version_ref,
       accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
       semantic_attempt_ref, repository_ref, base_git_object_format,
       base_git_oid, path_ceiling_json, allowed_effect_class_mask,
       aggregate_max_active_invocations, aggregate_max_candidate_bytes,
       aggregate_max_changed_files, aggregate_max_cost_microusd,
       aggregate_max_cpu_seconds, aggregate_max_deliveries,
       aggregate_max_deployments, aggregate_max_local_commits,
       aggregate_max_memory_bytes, aggregate_max_merges,
       aggregate_max_model_input_tokens, aggregate_max_model_output_tokens,
       aggregate_max_pull_requests, aggregate_max_pushes,
       aggregate_max_wall_seconds, expires_at, global_stop_ref,
       global_stop_version, attempt_fence_digest, recorded_at

AE14 = schema_id, authority_evaluation_ref, program_ref, evaluation_scope,
       evaluation_subject_ref, semantic_attempt_ref, effect_intent_ref,
       authority_ref, authority_digest, authority_state, reason_code,
       expires_at, evaluated_at, authority_evaluation_digest

EI14 = schema_id, effect_intent_ref, program_ref, program_version_ref,
       semantic_attempt_ref, effect_class, candidate_ref, command_ref,
       basis_decision_ref, cancellation_target_effect_intent_ref,
       expected_target_effect_head_revision, portable_capsule_digest,
       created_at, effect_intent_digest

EF47 = schema_id, effect_fence_ref, parent_standing_grant_ref,
       parent_standing_grant_digest, effect_authorization_ref,
       effect_authorization_digest, attempt_fence_ref, attempt_fence_digest,
       program_ref, program_version_ref, accepted_intent_revision_ref,
       work_item_ref, work_item_revision_ref, semantic_attempt_ref,
       effect_intent_ref, effect_class, command_ref, command_digest,
       candidate_ref, repository_ref, base_git_object_format, base_git_oid,
       path_ceiling_json, effect_max_active_invocations,
       effect_max_candidate_bytes, effect_max_changed_files,
       effect_max_cost_microusd, effect_max_cpu_seconds,
       effect_max_deliveries, effect_max_deployments,
       effect_max_local_commits, effect_max_memory_bytes, effect_max_merges,
       effect_max_model_input_tokens, effect_max_model_output_tokens,
       effect_max_pull_requests, effect_max_pushes, effect_max_wall_seconds,
       expires_at, global_stop_ref, global_stop_version,
       portable_capsule_digest, cancellation_target_effect_intent_ref,
       cancellation_target_effect_fence_ref,
       cancellation_target_effect_fence_digest, effect_fence_digest,
       recorded_at

AC54 = schema_id, command_ref, program_ref, program_version_ref,
       accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
       semantic_attempt_ref, effect_intent_ref, effect_class, candidate_ref,
       repository_ref, base_git_object_format, base_git_oid,
       path_ceiling_json, work_spec_ref, work_spec_digest,
       standing_grant_ref, standing_grant_digest, attempt_authorization_ref,
       attempt_authorization_digest, effect_authorization_ref,
       effect_authorization_digest, attempt_fence_ref, attempt_fence_digest,
       effect_fence_ref, effect_fence_digest, global_stop_ref,
       global_stop_version, validation_requirement_ref,
       validation_requirement_digest, review_requirement_ref,
       review_requirement_digest, capsule_schema_id, capsule_profile_ref,
       effect_max_active_invocations, effect_max_candidate_bytes,
       effect_max_changed_files, effect_max_cost_microusd,
       effect_max_cpu_seconds, effect_max_deliveries,
       effect_max_deployments, effect_max_local_commits,
       effect_max_memory_bytes, effect_max_merges,
       effect_max_model_input_tokens, effect_max_model_output_tokens,
       effect_max_pull_requests, effect_max_pushes, effect_max_wall_seconds,
       privacy_classification, redaction_profile_ref, command_digest,
       recorded_at

EH9 = schema_id, effect_intent_ref, program_ref, current_effect_fence_ref,
      head_revision, effect_state, cancellation_effect_intent_ref,
      updated_at, head_digest

DH8 = schema_id, effect_intent_ref, program_ref,
      current_delivery_attempt_ref, head_revision, delivery_state,
      updated_at, head_digest

DA21 = schema_id, delivery_attempt_ref, program_ref, program_version_ref,
       command_ref, command_digest, semantic_attempt_ref, effect_intent_ref,
       attempt_fence_ref, attempt_fence_digest, effect_fence_ref,
       effect_fence_digest, adapter_kind, adapter_safe_correlation_ref,
       delivery_envelope_digest, delivery_kind, delivery_number,
       predecessor_delivery_attempt_ref, basis_decision_ref, recorded_at,
       delivery_attempt_digest

SH41 = schema_id, program_ref, program_version_ref,
       accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
       semantic_attempt_ref, candidate_ref, effect_intent_ref,
       author_command_ref, author_command_digest, attempt_fence_ref,
       attempt_fence_digest, effect_fence_ref, effect_fence_digest,
       delivery_attempt_ref, delivery_envelope_digest, current_proposal_ref,
       current_disposition_ref, current_disposition, head_revision,
       updated_at, program_version_number, semantic_attempt_digest,
       attempt_number, basis_decision_ref, basis_decision_digest,
       work_spec_ref, work_spec_digest, work_spec_safe_projection_digest,
       effect_intent_digest, standing_grant_ref, standing_grant_digest,
       attempt_authorization_ref, attempt_authorization_digest,
       effect_authorization_ref, effect_authorization_digest,
       delivery_attempt_digest, authority_evaluation_ref,
       authority_evaluation_digest, head_digest

GS10 = singleton_id, schema_id, version, active, stop_id, reason_class,
       issuer_ref, issued_at, operator_decision_ref, updated_at

GSE18 = event_ref, event_sequence, idempotency_key, command_digest, action,
        source_version, resulting_version, outcome, reason,
        operator_decision_ref, resulting_global_stop_ref, resulting_status,
        schema_id, event_json, event_digest, replay_global_stop_json,
        replay_global_stop_digest, created_at
```

[proposed frozen C2B owner contract] Receipt-first and basis reads are exact parameterized `SELECT <projection> ... LIMIT 2`: `R19 WHERE mutation_ref=?`; `D43 WHERE program_ref=? AND decision_ref=?`; `PH8 WHERE program_ref=?`; `PV9 WHERE program_ref=? AND program_version_ref=? AND program_version_number=?`; `AI10 WHERE program_ref=? AND accepted_intent_revision_ref=?`; `WH9 WHERE program_ref=? AND work_item_ref=?`; `WR10 WHERE program_ref=? AND work_item_ref=? AND work_item_revision_ref=?`; and `WS18 WHERE program_ref=? AND program_version_ref=? AND work_item_ref=? AND work_item_revision_ref=?`.

[current merged implementation] Those projections and predicates reuse the existing literal readers at [`_sqlite_development_reader_contracts.py:382`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py:382>).

[proposed frozen C2B owner contract] The selection head is read as `SH41` using all eight K8 equality predicates and `LIMIT 2`; dependencies reuse the existing `SA13`, `EI14`, `AC54`, `AF37`, `EF47`, `AE14`, `EH9`, `DH8`, and `DA21` readers with their existing exact predicates.

[proposed frozen C2B owner contract] Collision probes use the full owning projection and `LIMIT 2` for every uniqueness route:

- `D43`: `decision_ref=?` and separately `mutation_ref=?`.
- `PV9`: `program_version_ref=?` and separately `program_ref=? AND program_version_number=?`.
- `AI10`: `accepted_intent_revision_ref=?` and separately `program_ref=? AND accepted_intent_revision_number=?`.
- `WR10`: `work_item_revision_ref=?` and separately `program_ref=? AND work_item_ref=? AND work_item_revision_number=?`.
- `E11`: `revision_edge_ref=?` and separately `relation_key_digest=?`.
- `WS18`: `work_spec_ref=?` and separately `program_ref=? AND program_version_ref=? AND work_item_ref=? AND work_item_revision_ref=?`.
- `SA13`: `semantic_attempt_ref=?` and separately `program_ref=? AND candidate_ref=?`.
- `EI14`: `effect_intent_ref=?`.
- `EF47`: `effect_fence_ref=?`.
- `DA21`: `delivery_attempt_ref=?`.

[proposed frozen C2B owner contract] Every insert is the literal `INSERT INTO <fixed table> (<owning tuple>) VALUES (<matching fixed placeholder count>)`; the table, columns, count, states, and roles cannot originate in caller data.

[proposed frozen C2B owner contract] Full readback uses every primary and alternate unique locator shown above, reconstructs the exact row-value classes, verifies every stored digest and cross-row relation, rereads both heads after CAS, rebuilds graph/result/receipt/completed projection, and accepts no partial family.

[proposed frozen C2B owner contract] All readers validate arguments before borrowing the nominal capability, execute one fixed statement, use the stated `fetchmany` bound, require exact built-in tuple rows, close the cursor without owning the connection, and preserve an execute/fetch failure over a later close failure; a close failure after successful fetch is `mutation_failed`.

[proposed frozen C2B owner contract] Missing freshness rows become the closed private conflict; malformed rows, duplicate singleton results, impossible absence of invariant rows, and digest/relation failures become `database_integrity_failure`; SQLite operational failures become `mutation_failed`.

# CAS and write order

[proposed frozen C2B owner contract] The exact work-head CAS is:

```sql
UPDATE development_work_item_heads
SET current_work_item_revision_ref = ?,
    current_work_item_revision_number = ?,
    head_revision = ?,
    work_state = ?,
    updated_at = ?,
    head_digest = ?
WHERE schema_id = ?
  AND program_ref = ?
  AND work_item_ref = ?
  AND current_work_item_revision_ref = ?
  AND current_work_item_revision_number = ?
  AND head_revision = ?
  AND work_state = ?
  AND updated_at = ?
  AND head_digest = ?
```

[proposed frozen C2B owner contract] The exact program-head CAS is:

```sql
UPDATE development_program_heads
SET current_program_version_ref = ?,
    current_program_version_number = ?,
    head_revision = ?,
    program_state = ?,
    updated_at = ?,
    head_digest = ?
WHERE schema_id = ?
  AND program_ref = ?
  AND current_program_version_ref = ?
  AND current_program_version_number = ?
  AND head_revision = ?
  AND program_state = ?
  AND updated_at = ?
  AND head_digest = ?
```

[proposed frozen C2B owner contract] Each assignment tuple is the complete derived postimage and each predicate is the complete supplied-and-reread preimage. Both CAS statements require `rowcount == 1`; `rowcount > 1` is `database_integrity_failure`.

[proposed frozen C2B owner contract] A zero-row work or program CAS returns the single private conflict `program_head_conflict`. In this one-work aggregate profile, either miss means that the program-level progression basis is stale; using one vocabulary avoids exposing write-order detail or implying separately retryable work authority.

[proposed frozen C2B owner contract] Work CAS always precedes program CAS. Any conflict or pre-commit failure rolls back the whole transaction; exact replay performs neither CAS.

[proposed frozen C2B owner contract] Branch write order is exact:

- Acceptance, terminal, block: decision → version → membership → work CAS → program CAS → receipt → full readback.
- Repair: decision → version → membership → WorkSpec binding → work CAS → program CAS → receipt → full readback.
- Replan: accepted-intent revision → work revision → decision → version → membership → WorkSpec binding → accepted-intent edge → work-item edge → work CAS → program CAS → receipt → full readback.
- Cancellation: decision → receipt → full readback.

[current owning contract] Deferred foreign-key cycles remain enabled and are closed within one transaction; foreign keys are never disabled, as recorded in [`c2b-durable-development-state.md:190`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:190>).

# Mutation-graph contract

[current merged implementation] A graph entry is exactly `(role: nonempty str, ordinal: non-negative exact int, record_ref: safe ref, record_digest: SHA-256)`; tuple order is significant, and duplicate `(role, ordinal)` or `(role, record_ref)` pairs are rejected by [`_development_decision_row_values.py:921`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:921>).

[proposed frozen C2B owner contract] Exact ordered entries are:

| Classification | Branch | Ordered `(role, ordinal)` sequence |
|---|---|---|
| proposed frozen C2B owner contract | Acceptance, terminal, block | `program_head_postimage/0`, `progression_decision/0`, `program_version/0`, `work_item_head_postimage/0`, `program_version_work_item/0` |
| proposed frozen C2B owner contract | Repair | The preceding five, then `work_spec_binding/0` |
| proposed frozen C2B owner contract | Replan | `program_head_postimage/0`, `accepted_intent_revision/0`, `progression_decision/0`, `program_version/0`, `work_item_head_postimage/0`, `work_item_revision/0`, `revision_edge/0`, `revision_edge/1`, `program_version_work_item/0`, `work_spec_binding/0` |
| proposed frozen C2B owner contract | Cancellation | `progression_decision/0` |

[proposed frozen C2B owner contract] Record refs/digests are respectively: program ref/head digest; intent ref/intent digest; decision ref/decision digest; version ref/version digest; work-item ref/head digest; work-revision ref/revision digest; edge ref/edge digest; membership work-item ref/membership digest; WorkSpec ref/binding digest.

[current merged implementation] The graph digest preimage is the receipt envelope with `mutation_graph_digest` omitted plus the supplied ordered `graph_entries`; its domain is the current development mutation-receipt identity domain, not a new graph domain. The exact envelope is visible at [`_development_decision_row_values.py:961`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:961>).

[proposed frozen C2B owner contract] The receipt-envelope fields in that preimage are the other 18 receipt columns in `R19`, in their current identity mapping, followed by the ordered entry mappings `role`, `ordinal`, `record_ref`, `record_digest`.

[proposed frozen C2B owner contract] Graph entries are not new SQL rows and their role strings do not reinterpret any persistent field; only the existing `mutation_graph_digest` is persisted.

# Result and completed-receipt digest

[current merged implementation] The existing progression result is exactly:

```text
schema_id
program_ref
decision_ref
result_program_version_ref
result_decision_ref
result_projection_digest
```

[current merged implementation] Its identity mapping excludes the final digest and requires `result_decision_ref == decision_ref`; see [`_development_decision_row_values.py:436`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:436>).

[proposed frozen C2B owner contract] `result_program_version_ref` is the newly appended version for every advancing branch and the unchanged basis version for cancellation.

[proposed frozen C2B owner contract] The nested receipt is the existing `R19` row with `mutation_family=record_development_progression_decision`, the reserved command schema, the computed command digest, decision ref, result program version, `result_decision_ref=decision_ref`, class `development_progression_decision_recorded`, all semantic-attempt/effect/fence/delivery/observation result refs null, `outcome=committed`, and the shared timestamp.

[proposed frozen C2B owner contract] The additive pure completed projection has schema `governed-execution.nwp-development-progression-completed-receipt-projection.v1`, domain `<schema>.identity`, and exact ordered fields:

```text
schema_id
owner_profile_ref
owner_profile_digest
branch
mutation_ref
command_digest
program_ref
decision_ref
result_program_version_ref
result_projection_digest
mutation_graph_digest
committed_at
fresh_productive_direct_local_accept_latch_eligible
receipt_mapping
completed_receipt_digest
```

[proposed frozen C2B owner contract] `receipt_mapping` is the exact 19-column receipt mapping; the completed digest identity excludes only `completed_receipt_digest`.

[proposed frozen C2B owner contract] Latch eligibility is true only for a fresh `candidate_acceptance` whose verified productive delivery used `adapter_kind=direct_local_bootstrap`; it is false for every other branch and transport. Replay reconstructs the historical value rather than re-evaluating current state.

[proposed frozen C2B owner contract] No SQL column is added for this projection. RW0-C binds its digest, profile pair, mutation ref, and command digest in the closure attestation without restating C2B branch semantics.

[proposed frozen C2B owner contract] Missing, extra, malformed, digest-mismatched, or partly present family rows are corruption/unresolved evidence, never a smaller successful receipt.

# Replay and recovery selector

[current owning contract] The consistent vocabulary is exactly `committed_exact`, `definitely_not_committed`, and `unresolved`; `committed_exactly` is rejected as drift. The current RW0-C1 vocabulary uses `committed_exact` at [`_rw0_c1_durable_evidence_semantic_values.py:261`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_c1_durable_evidence_semantic_values.py:261>).

[proposed frozen C2B owner contract] The recovery selector schema is `governed-execution.nwp-development-progression-recovery-selector.v1`, its domain is `<schema>.identity`, and its exact ordered fields are:

```text
schema_id
owner_profile_ref
owner_profile_digest
branch
mutation_ref
command_digest
program_ref
phase_basis_ref
phase_basis_digest
post_execution_proposal_member_ref
post_execution_proposal_member_digest
decision_ref
basis_decision_ref
basis_program_version_ref
basis_program_version_number
result_program_version_ref
result_program_version_number
resulting_accepted_intent_revision_ref
resulting_accepted_intent_revision_number
resulting_work_item_ref
resulting_work_item_revision_ref
resulting_work_item_revision_number
accepted_intent_edge_ref
work_item_edge_ref
resulting_work_spec_ref
preassigned_semantic_attempt_ref
preassigned_candidate_ref
target_effect_intent_ref
preassigned_effect_intent_ref
preassigned_effect_fence_ref
preassigned_delivery_attempt_ref
expected_program_head
expected_sole_membership
expected_sole_work_head
expected_sole_work_revision
expected_global_stop_preimage
expected_selection_head_preimage
expected_target_effect_head_preimage
selector_digest
```

[proposed frozen C2B owner contract] It is constructed before apply from the validated command and deterministic successor numbers; canonicalization matches the profile, the bound is `1..65536` bytes, and the selector digest excludes only itself.

[proposed frozen C2B owner contract] Cancellation uses the basis version as its result version and nulls all newly created version/revision/edge/WorkSpec/work locators. Advancing branches use every applicable preassigned locator.

[proposed frozen C2B owner contract] Recovery probes receipt by mutation, decision by decision and mutation, version by ref and `(program,number)`, membership by both key forms, WorkSpec by ref and owner tuple, intent/work revision/edges by primary and unique relation keys, successor attempt by ref and candidate, and cancellation effect/fence/delivery by each preassigned ref.

[proposed frozen C2B owner contract] `committed_exact` requires matching outer receipt and closure, exact nested receipt, command/profile binding, all mandatory branch rows, exact digests/relations/graph/result/completed projection, historical stop proof, and either current heads equal to the C2B postimages or an exact bounded chain of legitimate later progression.

[proposed frozen C2B owner contract] `definitely_not_committed` requires outer receipt, nested receipt, decision, all branch-created rows, and all downstream preassigned locators to be absent, plus heads equal to their preimages or a bounded exact later chain that excludes this selector. Cancellation requires the exact absence proof but no head comparison because it mutates no head.

[proposed frozen C2B owner contract] `unresolved` covers any partial family, locator collision, malformed evidence, digest mismatch, incompatible outer/nested status, unprovable head lineage, or proof depth beyond 256.

[proposed frozen C2B owner contract] Later-head proof walks at most 256 immutable versions and their creating decisions/receipts, verifies decreasing contiguous version numbers and basis links, reconstructs each branch’s deterministic membership and head transition, and rejects missing, repeated, malformed, or non-profile steps.

[proposed frozen C2B owner contract] A C2B-complete fragment without its RW0-C closure/outer receipt is `unresolved`; latch-only or outer-only evidence is also `unresolved`. No fragment is promoted to committed merely because SQLite normally commits atomically.

[current owning contract] Commit-attempt or cleanup uncertainty forbids automatic same-writer retry; a new session may perform evidence-only recovery, consistent with the transaction outcome boundary at [`c2b-durable-development-state.md:938`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:938>).

# Global-stop historical binding

[current merged implementation] Current stop rows use exact `GS10`; immutable events use `GSE18`; version zero is the clear seed with ref `global-stop-clear` and timestamp `1970-01-01T00:00:00Z`. See [`persistence_contracts.py:174`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/persistence_contracts.py:174>), [`persistence_contracts.py:240`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/persistence_contracts.py:240>), and [`0001_initial.sql:402`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0001_initial.sql:402>).

[proposed frozen C2B owner contract] The command carries both stop ref/version and the exact `GS10` preimage. Fresh evaluation rereads singleton `1`, requires exact equality, and applies the profile stop matrix.

[proposed frozen C2B owner contract] The decision row deliberately persists only `coding_global_stop_ref` and `coding_global_stop_version`; it does not duplicate mutable stop state.

[proposed frozen C2B owner contract] Historical reconstruction uses this exact bounded query:

```sql
SELECT event_ref, event_sequence, idempotency_key, command_digest, action,
       source_version, resulting_version, outcome, reason,
       operator_decision_ref, resulting_global_stop_ref, resulting_status,
       schema_id, event_json, event_digest, replay_global_stop_json,
       replay_global_stop_digest, created_at
FROM global_stop_events
WHERE outcome = 'accepted' AND resulting_version = ?
ORDER BY event_sequence ASC
LIMIT 2
```

[proposed frozen C2B owner contract] The reader calls `fetchmany(2)`. Version zero must match the literal seed. Every positive version must yield exactly one accepted event, whose canonical event and replay state validate through the existing event contract, whose `source_version+1` equals the requested version, whose resulting ref/status match replay state, and whose `created_at` reconstructs the historical row’s `updated_at`.

[proposed frozen C2B owner contract] Zero historical events for a positive version, two events, malformed replay JSON, or any digest/relation mismatch is `database_integrity_failure`; current-stop advancement does not invalidate an otherwise exact historical replay.

# Composition seam with RW0-C

[proposed frozen C2B owner contract] The pure no-I/O entry is `_evaluate_development_progression_decision(*, command, basis, decided_at) -> DevelopmentProgressionWritePlanV1`.

[proposed frozen C2B owner contract] The bounded SQL entry is `_record_development_progression_decision_in_active_transaction(*, capability, command, decided_at) -> DevelopmentProgressionCompletedReceiptProjectionV1`; it may read, evaluate, write, and read back but may not begin, commit, roll back, close, or own a connection.

[proposed frozen C2B owner contract] The common executor is `_run_atomic_rw0_c_decision_transaction(...)`; it alone owns the operation lease, mutation slot, filesystem-bound connection, `BEGIN IMMEDIATE`, writer fencing, nominal capability epoch, timestamp, invalidation, one commit attempt, rollback, close, and outcome resolution.

[proposed frozen C2B owner contract] Exact composed order is:

1. Local closed-world command/profile/selector preflight.
2. Acquire operation lease and mutation slot.
3. Open one bound connection, `BEGIN IMMEDIATE`, validate managed state, and fence the writer.
4. Read outer receipt first, then nested C2B receipt.
5. Resolve exact replay or conflict before disclosing mutable basis state.
6. Read and verify the RW0-C closure basis, C2B current rows, selection lineage, stop, membership, and collisions.
7. Capture one whole-second UTC timestamp.
8. Invoke the C2B facade exactly once.
9. Complete C2B insert/CAS/readback and construct the completed nested projection.
10. For eligible fresh direct-local acceptance only, perform the RW0-C-owned latch CAS.
11. Write/read back RW0-C decision closure, member, and attestation rows.
12. Insert the outer receipt last and read it back.
13. Permanently invalidate the capability.
14. Attempt exactly one commit.
15. Close and prove cleanup before returning a fresh result.

[current merged implementation] The existing controller already owns nominal capability epochs, `BEGIN IMMEDIATE`, timestamp capture, commit, rollback, and cleanup mechanics in [`sqlite_transition_transaction.py:718`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_transition_transaction.py:718>) and [`sqlite_transition_transaction.py:3299`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_transition_transaction.py:3299>).

[proposed frozen C2B owner contract] Nested completion occurs only after receipt insertion, complete in-transaction readback, graph/result recomputation, and completed-projection verification; it is not yet a committed result.

[proposed frozen C2B owner contract] C2B never imports an RW0-C module. RW0-C imports the bounded C2B facade and supplies its own verified closure basis through the C2B-owned neutral input contract.

[proposed frozen C2B owner contract] No callable C2B path may commit this family without RW0-C closure and the outer receipt in this slice.

# Assurance and independent-audit plan

| Classification | Permanent claim | Independent oracle/challenge |
|---|---|---|
| proposed frozen C2B owner contract | Profile literal and digest | Hard-coded 5779-byte literal, independently calculated domain digest, one-byte/key/order mutants |
| proposed frozen C2B owner contract | Command union | Literal 52-field oracle; every wrong type, missing/extra field, and cross-branch non-null field |
| proposed frozen C2B owner contract | Six decisions/reasons | Literal 43-column expected tuples; closed reason constants; every forbidden nullability mutation |
| proposed frozen C2B owner contract | Single-work query | Literal SQL/columns/parameters/order/limit; external zero/one/two/gap/duplicate/257-row fixtures |
| proposed frozen C2B owner contract | Positive write plans | One literal plan oracle per branch, including repair WorkSpec rebinding |
| proposed frozen C2B owner contract | Forbidden writes | Assertions that cancellation emits only decision/receipt and other branches emit no unowned row |
| proposed frozen C2B owner contract | Version membership | External SQL fixtures for ordinal zero, copied/new revision identity, dense cardinality |
| proposed frozen C2B owner contract | Replan structure | Independent intent/work-revision/edge/relation-key/WorkSpec digest oracles |
| proposed frozen C2B owner contract | CAS | Literal SQL, parameter-order oracle, work-before-program trace, rowcount 0/1/>1 |
| proposed frozen C2B owner contract | Stop matrix/history | Clear/active branch matrix plus current-advanced historical-event fixtures |
| proposed frozen C2B owner contract | Graph/result/receipt | Literal entry order, duplicate-role mutants, reordered entries, altered envelope fields |
| proposed frozen C2B owner contract | Replay/conflict | Same key/digest exact replay, different digest conflict, stale basis, no-write replay traces |
| proposed frozen C2B owner contract | Fault closure | Fault injection before/after every write, each CAS, readback, capability invalidation, commit, rollback, and close |
| proposed frozen C2B owner contract | Recovery | Literal selector and all three outcomes, later-head chains at depths 0, 1, 256, and 257 |
| proposed frozen C2B owner contract | Authority non-widening | Import/export/source-surface checks proving no public API, external I/O, worker, second controller, or standalone commit |

[proposed frozen C2B owner contract] Permanent tests must use literal expected values or separately constructed SQL fixtures; calling the production builder to manufacture the expected result is self-protecting and insufficient.

[proposed frozen C2B owner contract] The independent audit should mutate graph order, row nullability, profile bytes, historical stop evidence, unique locators, CAS rowcounts, partial outer/nested families, and commit/cleanup evidence independently.

[proposed frozen C2B owner contract] Clean/live validation belongs only to a later authorized implementation audit; no test, migration, or database execution was performed during this reconciliation.

# Path-correct provisional surface

[report-only uncertainty] The following is a path-derived provisional surface, not an implementation allowlist; a consumer/source-hash boundary audit may narrow or expand it.

| Classification | Category | Actual paths |
|---|---|---|
| implementation detail | Must change for C2B contract/implementation | [`.docs/c2b-durable-development-state.md`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md>); proposed `.docs/c2b-progression-decision-owner-contract.md`; proposed `src/ge_nwp_coordinator/_development_progression_decision_contracts.py`; proposed `src/ge_nwp_coordinator/_sqlite_development_progression_decision.py`; [`src/ge_nwp_coordinator/sqlite_transition_transaction.py`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_transition_transaction.py>); proposed focused C2B contract, atomic, and recovery tests under [`tests/`](</Users/ds/Repositories/Governed Execution Coordinator/tests>) |
| implementation detail | Must change later for RW0-C Decision/0005 | RW0-C Decision owner document and private modules under [`src/ge_nwp_coordinator/`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator>); [`sqlite_migration.py`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migration.py>); `src/ge_nwp_coordinator/sqlite_migrations/0005_…sql`; common-controller integration and focused RW0-C tests |
| report-only uncertainty | May change after boundary/source-hash audit | [`.docs/autonomous-software-development-operating-model.md`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/autonomous-software-development-operating-model.md>), other authority/software-boundary/SQLite-operation documents, [`README.md`](</Users/ds/Repositories/Governed Execution Coordinator/README.md>), [`AGENTS.md`](</Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md>), import-closure and source-hash oracle tests |
| current owning contract | Protected | Immutable migrations [`0001_initial.sql`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0001_initial.sql>) through [`0004_rw0_c1_durable_evidence.sql`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql>); existing row meanings/nullability; public package exports, `StateStore`, and writer-session surfaces; Bridge and all supporting repositories |

[proposed frozen C2B owner contract] The frozen twenty-four-query module remains unchanged; progression-specific locators and collision probes live with the private progression family.

# Remaining seams and stop conditions

[proposed frozen C2B owner contract] No upstream C2B semantic choice remains: profile, command, branch rows, postimages, SQL/read bounds, CAS, graph, receipt, replay, historical stop proof, recovery, and composition ownership are closed.

[reopened owner seam] RW0-C still owns the exact physical latch row/CAS, closure/member/attestation schemas, outer receipt schema, and migration `0005`; those consumer details must honor the profile pair and completed-receipt digest fixed here.

[current owning contract] RW0-C Terminal, migration `0006`, RW0-D, RW0-E, and Execution Substrate terminal evidence remain outside this freeze.

[compatibility edge] The migration-tip/status drift in the early C2B document must be repaired alongside any later implementation so `.docs/` again describes the merged generation-4 baseline accurately.

[proposed frozen C2B owner contract] Work must stop if implementation would change migration-0002 bytes, an existing decision field/nullability/meaning, a kind/variant/state vocabulary, introduce generic JSON/BLOB plans, allow caller-selected states/edges/roles/SQL, add a second transaction or commit path, make C2B import RW0-C, widen public authority, perform external I/O, or weaken any three-way recovery proof.

# Recommended next step

[proposed frozen C2B owner contract] First perform an independent audit of this exact owner freeze; next perform a dedicated implementation-boundary audit covering the combined C2B-owner and RW0-C-Decision candidate; only after both pass should one integrated implementation candidate—with separate owner modules and one transaction authority—be considered for authorization.

[proposed frozen C2B owner contract] This is an audit recommendation, not an implementation prompt or implementation authorization.

# Confidence

[proposed frozen C2B owner contract] Confidence is high: the freeze is grounded in the exact generation-4 baseline, immutable migration-0002 shapes, current pure row validators, current bounded reader contracts, current graph/result helpers, global-stop event replay, and the existing common transaction controller.

[report-only uncertainty] The only provisional element is the later touched-path inventory pending a consumer/source-hash boundary audit; it does not affect the semantic completeness of the C2B owner freeze.

C2B_PROGRESSION_DECISION_OWNER_FREEZE_RECONCILED_READY_FOR_INDEPENDENT_AUDIT

REPOSITORY_MUTATION_NOT_PERFORMED  
TESTS_NOT_RUN  
MIGRATIONS_NOT_RUN  
STAGING_NOT_PERFORMED  
COMMIT_NOT_PERFORMED  
PUSH_NOT_PERFORMED  
PR_NOT_CREATED  
REMOTE_CONTACT_NOT_PERFORMED  
WORKER_OR_MODEL_NOT_INVOKED  
SUPPORTING_REPOSITORIES_NOT_MODIFIED  
IMPLEMENTATION_NOT_PERFORMED  
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED  
RW0_C_DECISION_NOT_IMPLEMENTED  
RW0_C_TERMINAL_NOT_IMPLEMENTED  
RW0_D_NOT_IMPLEMENTED  
RW0_E_NOT_IMPLEMENTED  
EXECUTION_SUBSTRATE_NOT_MODIFIED
