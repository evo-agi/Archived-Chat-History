PROMPT_ID

RW0_POST_EXECUTION_SOURCE_OWNER_AND_SUPPLY_BINDING_RECONCILIATION_V1

TITLE

Coordinator RW0 — reconcile every post-execution source-owner schema, support
value, relation binding, and exact current owner constraint before independent
audit

ENGAGEMENT TYPE

Parent-only, local, read-only contract reconciliation.

Do not delegate to subagents or internal audit agents. If parent-only execution
cannot be maintained, stop and report that procedural blocker.

Do not edit repository files, generate repository artifacts, format, stage,
commit, push, create a branch or PR, merge, tag, release, deploy, fetch,
contact a remote/live system, install dependencies, execute tests, run
migrations, open or mutate an operator database, invoke a product worker/model,
or inspect/modify supporting repositories.

Do not issue an implementation prompt.

Print the complete substantive report inline. Supplementary evidence paths are
secondary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_POST_EXECUTION_SOURCE_OWNER_BASELINE_MISMATCH

FIXED INPUT REPORT

Treat the immediately preceding Codex response as fixed input.

If supplied as a file, use:

RW0_Post_Execution_Context_Identity_and_Value_Grammar_Reconciliation_Report.txt

Expected identity:

size:
165888 bytes

SHA-256:
8dd26efd25333cd49acc0fe7b64d9b7b05495176e3d5b4f377fa42f8cf60ba58

logical lines:
1026

final newline:
absent

opening:
# Baseline and fixed input

closing token:
RW0_POST_EXECUTION_CONTEXT_IDENTITIES_AND_VALUE_GRAMMARS_RECONCILED_READY_FOR_INDEPENDENT_AUDIT

If the attached fixed input differs, stop:

RW0_POST_EXECUTION_SOURCE_OWNER_FIXED_INPUT_MISMATCH

WHY ANOTHER RECONCILIATION IS REQUIRED

The fixed report successfully separates the L34 lineage context from the T1
model-input context and regenerates the Section 41 projection identities. It
still claims a complete source/value registry while leaving or inventing
source-owner identities that conflict with current merged owners.

Known deterministic examples:

1. Current C2A owns both validation and independent-review source observations
   as exact `WorkerObservationV1` values with schema:

```text
governed-execution.nwp-worker-observation.v1
```

The fixed report leaves `source_observation_schema_id` generic in the
validation/review dispositions and its current golden T1 entries instead use:

```text
governed-execution.nwp-validation-source-observation.v1
governed-execution.nwp-independent-review-source-observation.v1
```

Neither is the current C2A owner schema. The preserved design expressly says
existing C2A `WorkerObservationV1` remains unchanged as the source observation.

2. Current `CandidateCapsuleManifestV1` requires:

```text
base_git_object_format = sha1
```

The fixed report's `CandidateCapsuleSafeProjectionV1` widens that owner field to:

```text
sha1 | sha256
```

A safe projection cannot widen the source-owner domain.

3. The current golden worker-result role uses a proposed
`rw0-c1-wire-process-result-classifier-relation` schema without proving that it
is the exact schema/ID/version/profile of the current C1 rank-14 relation row.

4. Policy, risk-policy, validation/review support, and reviewer-independence
source values are consumed as canonical supplied values, but several lack a
literal owner schema/value grammar in the supposedly complete registry.

Do not send the current report to independent audit. Close these owner bindings
and regenerate every dependent identity first.

PRESERVED DECISIONS

Preserve unless current owning repository contracts prove a contradiction:

1. The two-context design is accepted:

```text
Section41PostExecutionSemanticReviewLineageContextV1
PostExecutionSemanticReviewInputContextV1
```

2. The migration-0003 source/proposal context seam points to the T1 input
   context; the lineage context remains a nested pure operand.

3. Section 41 proposal-family projection V2 and role-resolution V3 remain the
   current proposed versions, subject to mechanically regenerated identities.

4. C1 remains exactly 15 kinds. No current B1/B2/C1/C2A schema or relation is
   changed.

5. Proposal-time evidence, T1/model-input equality, exact resupply, capsule
   privacy, exhaustive membership closure, bounded current snapshot, and the
   pure-versus-forecast implementation boundary remain accepted.

6. Validation/review dispositions bind current C2A observations. They do not
   replace or reinterpret `WorkerObservationV1`.

7. FiniteBacklog remains only a compatibility adapter behind the generic risk
   interface.

8. No migration, persistence, public API, runtime behavior, external contact,
   C2B progression writer, branch truth, latch, terminal, D/E, or ES behavior
   is authorized.

FACT CLASSIFICATION

Use exactly:

- current owning contract;
- current merged implementation;
- compatibility edge;
- proposed post-execution evidence owner contract;
- proposed Section 41 role-resolution contract;
- proposed RW0-C decision-input contract;
- proposed future committed-recovery contract;
- implementation-detail observation;
- report-only uncertainty.

RECONCILIATION A — CURRENT C2A VALIDATION/REVIEW SOURCE BINDING

Freeze the exact current source relation for both dispositions.

Require:

```text
source type:
WorkerObservationV1

source schema:
governed-execution.nwp-worker-observation.v1
```

For validation, freeze exact:

- `source_kind`;
- `observation_kind = validation_completed`;
- current owner outcome vocabulary;
- required/forbidden conditional fields;
- program/work/attempt/effect/command/fence/capsule lineage;
- observation ref/digest;
- source ref/invocation;
- evidence refs and observed_at.

For independent review, freeze the analogous exact current owner mapping with:

```text
observation_kind = independent_review_completed
```

and the current required source kind/outcome/conditional fields.

Then freeze how the new owner-authored disposition relates to the source
observation:

- exact schema/ref/digest;
- exact safe reconstruction;
- source outcome equality;
- lineage equality;
- candidate/capsule equality;
- author role/ref/invocation relation;
- no fabrication by RW0-C or the model.

Delete the invented validation/review source-observation schema identities.
Regenerate every dependent source-binding digest, T1 context, model-input
projection/binding, evidence supply, Section 41 projection, role-resolution
value/profile, and golden vector.

If the desired disposition taxonomy cannot be derived or validated from current
WorkerObservation plus named owner-supplied result values without changing C2A,
identify the exact new neutral owner value required. Do not hide C2A churn.

RECONCILIATION B — CURRENT C1 RANK-14 RELATION BINDING

Inspect the merged C1 rank-14 member, relation-binding row, relation ID/version,
proof mode, NWPF profile pair, subject membership, and operands.

Freeze the worker-result role's source binding using only the current exact
C1 values:

- relation-binding schema;
- relation ref/digest;
- relation ID;
- relation version;
- proof mode;
- profile ref/digest;
- subject membership pair;
- subject value schema/ref/digest;
- operand-set digest as required.

Do not invent a standalone classifier-relation schema if current C1 represents
the proof through the generic relation-binding value plus a literal relation ID.

Regenerate the T1 role grammar and all dependent identities.

RECONCILIATION C — CANDIDATE SAFE PROJECTION MUST NARROW, NOT WIDEN

Bind every `CandidateCapsuleSafeProjectionV1` field to the current exact
`CandidateCapsuleManifestV1` owner.

At minimum:

```text
base_git_object_format = sha1
base_git_oid = exact 40-byte lowercase hex
schema = governed-execution.nwp-candidate-capsule-manifest.v1
```

Freeze equality for every retained safe field.

The safe projection may omit private fields. It may not add a value, enum
member, format, or semantic interpretation unavailable in the owner.

Regenerate its ref/digest, model-input projection, private manifest, T1 context,
supply, source/proposal identities, projection V2, profiles, and all golden
values.

RECONCILIATION D — SOURCE AND SUPPORT OWNER REGISTRY

The report requires canonical source/support values but does not define all of
them. Produce a closed source-owner registry for every non-C1 input used by:

- validation disposition;
- independent-review disposition;
- standing-policy matrix;
- risk matrix;
- proposal-time global-stop snapshot;
- source-effect ceiling evidence.

For each source/support role choose exactly one:

1. existing merged owner value, with exact class/schema/fields/ref/digest and
   relation; or

2. new private pure neutral safe value in the post-execution owner tranche,
   with a complete schema/identity grammar; or

3. opaque external evidence not locally semantically interpreted—in which case
   remove any claim that C locally re-evaluates its internal semantics and
   freeze only exact supplied-attestation validation.

Cover at minimum:

```text
validation tool profile
validation requirement
validation result set
review tool profile
review requirement
review result set
reviewer independence
standing-policy source
parent grant/policy authority source
risk policy
generic risk source profile and binding
global-stop state value
attempt fence
effect fence
authority observation
```

Do not leave `SID`, `O[source]`, `source_profile_canonical_value`, or
`support_canonical_values` dispatched to an unnamed/unregistered schema.

For every new neutral value, add it to the complete value-schema registry,
profile-to-value matrix, golden vectors, and import DAG.

RECONCILIATION E — POLICY AND RISK AUTHORSHIP

Freeze who authors each matrix and what is locally validated.

For standing policy:

- identify the exact policy-source value;
- distinguish external policy meaning from local pure matrix construction;
- freeze the source-to-matrix relation;
- establish whether RW0-C can recompute the matrix or only validate an
  owner-authored matrix;
- keep permit non-authoritative.

For risk:

- keep the generic source interface;
- freeze the risk-policy value;
- freeze the source-profile/source-binding relation;
- retain the FiniteBacklog adapter as only one versioned source;
- do not assume development and backlog IDs are equal;
- keep target risk semantics independent of FiniteBacklog.

If policy or risk requires an external authority or body unavailable to the
pure tranche, classify the matrix as an owner-authored supplied attestation and
freeze exact validation rather than pretending local recomputation.

RECONCILIATION F — GLOBAL STOP AND FENCE OWNER IDENTITIES

Freeze exact current values rather than generic schema placeholders.

For proposal-time global stop:

- identify the current merged `GlobalStopState` schema/value construction;
- exact source row fields and canonical digest;
- exact ref/version/state/update time;
- clear/active optional-field branch;
- correct the active-detail field count;
- exact snapshot relation.

For attempt/effect fences:

- use the exact current C2A schema IDs and mappings;
- preserve the current `sha1` repository posture;
- preserve allowed effect classes, ceilings, separate expiries, stop
  coordinates, and digest identities.

No new owner semantics are permitted.

RECONCILIATION G — FIELD-LEVEL ENUM AND BRANCH CLOSURE

Re-audit the value registry for every field currently described only as broad
`SID`, `R`, `str`, or "fields from the fixed inventory".

Freeze literal constraints wherever an owner already supplies them.

At minimum check:

- source-observation schema/kind/source/outcome;
- base Git format and OID width;
- policy/risk source schemas;
- reviewer-independence schema/status;
- global-stop schema and optional branch;
- authority status/family/revocation vocabularies;
- all 15 ceiling keys;
- evidence-ref ordering/cardinality;
- support role-specific schema inventories;
- relation ID/version/proof mode;
- source-binding triples.

Do not widen current enums for hypothetical future formats.

RECONCILIATION H — DEPENDENT IDENTITY REGENERATION

After all owner bindings are frozen, mechanically regenerate:

- source/support values;
- role entries;
- candidate safe projection;
- model-input safe projection;
- private manifest;
- T1 input context;
- evidence supply;
- model-input binding;
- source invocation;
- artifact binding if affected;
- proposal;
- nine evidence-binding source digests if affected;
- evidence set if affected;
- owner-family graph;
- Section 41 projection V2;
- role-resolution V3;
- every profile whose canonical JSON changed;
- T1/Section41/resupply equality matrix;
- assurance vectors.

Print a superseded identity ledger.

No stale invented source schema or old dependent digest may appear in a current
canonical value.

RECONCILIATION I — COMPLETE OWNER/SCHEMA MATRIX

Reissue the value-schema registry with these additional columns:

```text
owner status:
  current merged owner | new pure neutral owner | opaque supplied attestation

source of canonical bytes:
  reconstructed current value | supplied exact value | parent-bound nested value

local semantic action:
  reconstruct | derive | validate supplied result | identity-only bind

owner relation:
  exact callable/profile/relation ID and version

external-authority claim:
  false, always
```

Reissue the profile-to-value matrix and import DAG.

C2A modules must import none of the new modules. New modules may import current
C2A values privately.

RECONCILIATION J — ASSURANCE

Add ordinary semantic tests and external mutants for:

- invented validation/review source schema;
- correct WorkerObservation schema but wrong observation kind;
- correct kind but wrong source kind/outcome;
- source observation lineage/capsule substitution;
- fabricated classifier-relation schema versus exact current C1 relation;
- `sha256` candidate format accepted by the safe projection;
- wrong base-OID width;
- unnamed source/support schema;
- policy source substitution;
- risk-policy/source-profile/source-binding substitution;
- global-stop clear/active branch mismatch;
- attempt/effect fence schema or expiry substitution;
- support set containing a value outside the consuming profile's literal owner
  inventory;
- stale dependent identity after owner correction.

Permanent tests remain finite ordinary semantic tests. Independent audit owns
external mutation, patch provenance, and owner-boundary review.

IMPLEMENTATION BOUNDARY

Do not issue an implementation prompt.

State whether the resulting report is ready for a fresh independent contract
audit. The pure-owner tranche remains migration-free and unimplemented.

STOP CONDITIONS

Return a precise blocker if reconciliation requires:

- changing current C2A/B1/B2/C1 semantics;
- changing migration-0003 or C1 durable row meanings;
- introducing source authentication or external I/O;
- a sixteenth C1 kind;
- persisting capsule entries/private bodies;
- FiniteBacklog in generic target semantics;
- model recommendation authority;
- migration/public/runtime changes;
- branch truth, C2B progression, latch, terminal, D/E, or ES semantics.

RETURN FORMAT

# Baseline and fixed input
# Preserved decisions
# Current C2A validation/review source binding
# Current C1 worker-result relation binding
# Candidate safe-projection owner equality
# Complete source/support owner registry
# Policy and risk authorship
# Global-stop and fence owner identities
# Corrected value-schema and owner matrix
# Corrected profile-to-value matrix and import DAG
# Regenerated identities and supersession ledger
# T1/Section41/resupply equality matrix
# Finite assurance matrix
# Remaining seams and stop conditions
# Recommended next step
# Confidence

SUCCESS TOKEN

Return exactly:

RW0_POST_EXECUTION_SOURCE_OWNERS_AND_SUPPLY_BINDINGS_RECONCILED_READY_FOR_INDEPENDENT_AUDIT

only if:

- every source/support schema has an exact owner;
- current C2A and C1 owner identities are used without invention;
- the candidate safe projection does not widen its owner;
- all dependent identities reproduce;
- no unregistered source schema remains;
- the report is self-contained;
- no implementation prompt is issued.

Otherwise return:

RW0_POST_EXECUTION_SOURCE_OWNER_RECONCILIATION_BLOCKED

and identify the exact unresolved owner/source decision.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
