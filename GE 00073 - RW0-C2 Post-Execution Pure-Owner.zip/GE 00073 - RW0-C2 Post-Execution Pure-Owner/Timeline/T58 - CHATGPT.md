# Decision

**Do not start the formal independent audit yet.**

Package V4 is mechanically valid and closes the three V3 findings, but it still contains four deterministic internal contract contradictions. These are package-generation defects, not reasons to reopen the post-execution architecture.

## What V4 successfully closes

I independently verified the attached V4 package:

```text
Filename:
RW0_Post_Execution_Canonical_Audit_Package_V4.jsonl

Size:
2,111,217 bytes

SHA-256:
7f71083fec9dbb3df5b7c04dd4b1b73af8e1ebd8e1261985c2f0fbfe9a4f6095

Logical records:
1,175

Final newline:
absent

Content aggregate:
98b16e1a517f3720140395f8b0807cfc5d341af00539ba5a6e1a6430cfacbdf2
```

The JSONL envelope, canonical encoding, payload hashes, domain-separated digests, indexes, manifest, aggregate, closeout, and whole-file identity all pass.

The advertised V3 repairs also pass:

- the host source-owner record now uses the common ten-key payload grammar;
- the contradictory duplicate qualification digest is gone;
- host metadata is now `profile=null` and `relation=validate_host_qualification`;
- the V26 nested entry profile now includes its literal `schema_id` and matches the value schema’s field order.

## Remaining blockers

### `V4-PKG-001` — V11 and V13 golden values contradict their schemas

`PostExecutionRoleSupplyV2.support_canonical_values` is declared with fixed cardinality `0`, but current golden values contain:

```text
0, 0, 6, 7, 4, 4, 0, 2, 5
```

support values.

`PostExecutionSupportSetV1.entries` is declared with fixed cardinality `6`, but its current goldens contain:

```text
6, 7, 4, 4, 2, 5, 2
```

entries.

The governing support profile already implies a consumer-specific inventory with an upper bound, so the value schemas cannot legally freeze one golden example’s length.

The correct posture is:

```text
V11 support values:
0..16
length = support_value_count
length = support-set entry count when a support set is present

V13 entries:
1..16
length/order/schema exactly equal the literal inventory for profile_ref
```

### `V4-PKG-002` — variable owner lists are frozen to current golden lengths

Several fields that are variable under current owners or the package’s own profiles are incorrectly assigned one exact cardinality:

| Field | Required range or relation |
|---|---|
| V14/V15 `source_evidence_refs` | `0..32`, exact source observation list |
| V38/V39 source and result-set evidence refs | `0..32` |
| V17/V41 allowed branches | canonical unique subset, `1..5` |
| V17/V41 allowed risk lanes | sorted unique, `1..32` |
| V17/V41 allowed effect classes | canonical unique subset, `0..5` |
| V18/V42 allowed risk lanes | sorted unique, `1..32` |
| V21 attempt/authority allowed effect classes | sorted unique current subset, `1..5` |
| V25 membership-closure entries | `0..65536`, length equals `entry_count` |
| V40 author-observation locators | `2..3`, length equals rank-13 observation count |

The merged C2A owner permits evidence-reference lists of `0..32` and requires allowed effect classes to be a nonempty sorted unique subset of the current effect-class vocabulary; those are owner properties, not golden-specific constants. 

Fixed counts should remain only where the contract is genuinely invariant, such as:

```text
nine Section 41 roles
five branch-evaluation entries
nine complete Section 41 evidence rows
five current-snapshot external-source coordinates
```

### `V4-PKG-003` — support-set inventories disagree

The support-set profile omits a consumer that is already present elsewhere in the package:

```text
post-execution-reviewer-separation-evaluation.v1
```

Its actual support set contains:

```text
review_observation_membership            rank 1
author_worker_result_membership           rank 2
```

V40 binds that support-set pair, but its governing profile does not declare the corresponding support profile and role inventory.

The standing-policy profile is also internally contradictory. Its current `support_roles` describe five roles:

```text
policy_source
policy_profile
parent_grant
authority_observation
source_effect_intent
```

while its owner inventory and golden support set use four:

```text
policy_source
policy_profile
authority_observation_and_parent_grant
source_effect_fence
```

One literal inventory must govern all five representations:

```text
profile support_roles
profile owner_support_schemas
support-profile owner_inventory_by_consumer
V13 support entries
V11 canonical support values
```

### `V4-PKG-004` — V27 and V29 disagree about risk currentness

The V29 value and golden record contain five currentness components:

```text
validation
review
policy
risk_profile
risk_binding
```

Its behavior profile declares only four:

```text
validation
review
policy
risk
```

and supplies only the risk-binding owner schema.

The same mismatch exists in the current snapshot:

- the V27 golden has five external-source records;
- its profile describes a combined `risk_source_profile_and_binding`.

Risk profile and risk binding are separately versioned owner values. They need distinct currentness components, source schemas, mismatch precedence, and snapshot coordinates.

The target should be five explicit components and five explicit sources in this order:

```text
validation
review
policy
risk_profile
risk_binding
```

## What remains preserved

This correction must not reopen:

- V40 operational reviewer separation;
- the two-context model;
- Section 41 projection V2 and role resolution V3;
- exact resupply and capsule privacy;
- owner-authored policy and risk attestations;
- `FiniteBacklog` as an adapter only;
- C1’s fifteen-kind boundary;
- the retirement of V35–V37 from current normative truth;
- the absence of migration, public API, runtime, progression-writer, latch, terminal, D/E, or Execution Substrate implementation.

## Codex handoff

Send this prompt to the package-generation conversation:

:chatgpt-content-reference{index="2"}[Download the V5 cardinality, support, and currentness repair prompt](sandbox:/mnt/data/Coordinator_RW0_Canonical_Package_V5_Cardinality_Support_Currentness_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_Canonical_Package_V5_Cardinality_Support_Currentness_Repair_Prompt.txt

Size:
13,168 bytes

SHA-256:
56f9c2a8115f937eba2dc9d0de0b39ae7ff215a22937e2972d1feb7beae0d490

Logical lines:
535

Final newline:
absent
```

Attach V4 as its exact fixed input:

:chatgpt-content-reference{index="3"}[Download canonical package V4](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Audit_Package_V4.jsonl)

The required revised attachment is:

```text
RW0_Post_Execution_Canonical_Audit_Package_V5.jsonl
```

The required success token is:

```text
RW0_POST_EXECUTION_CANONICAL_PACKAGE_V5_REPAIRED_READY_FOR_INDEPENDENT_AUDIT
```

The prompt requires Codex to:

1. replace golden-specific fixed cardinalities with literal ranges and count-equality rules;
2. align every support inventory across profiles, schemas, support sets, and role supplies;
3. split risk-profile and risk-binding currentness explicitly;
4. regenerate every transitively affected current identity;
5. add underflow, overflow, duplicate, reorder, and support-substitution assurance cases;
6. rerun all package mechanics and source-owner guards;
7. visibly attach V5 without changing the repository.

The detailed finding record is here:

:chatgpt-content-reference{index="4"}[Download the V4 pre-audit verification](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Audit_Package_V4_PreAudit_Verification.json)

```text
SHA-256:
55324cbaac2d1ee0647880e1c0e2b1adaec60db7f0d6260d9d0b7930aa8d0e02
```

## Next sequence

```text
1. Generate and attach package V5.
2. Independently verify V5’s mechanics and internal consistency.
3. Generate a fresh formal audit prompt using V5’s exact identity.
4. Run the parent-only source-owner and semantic contract audit.
5. Only after ACCEPT, freeze the migration-free implementation boundary.
```

## Current disposition

```text
Package V4 mechanics:
PASS

V3 source-grounding repairs:
PASS

List cardinality contracts:
BLOCK

Support-set inventories:
BLOCK

Risk currentness decomposition:
BLOCK

Formal independent audit:
PREMATURE

Implementation:
NOT AUTHORIZED
```

### Sources

- :chatgpt-content-reference{index="5"}[Canonical package V4](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Audit_Package_V4.jsonl)
- :chatgpt-content-reference{index="6"}[Independent V4 verification](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Audit_Package_V4_PreAudit_Verification.json)
- Current C2A list and effect-class constraints. 

**Confidence:** High that all four findings are deterministic package contradictions; high that the underlying owner architecture remains intact; high that one bounded V5 regeneration should make the package suitable for the next formal audit.
