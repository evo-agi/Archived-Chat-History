PROMPT_ID

RW0_POST_EXECUTION_CANONICAL_OWNER_CONTRACTS_INDEPENDENT_AUDIT_V1

TITLE

Independent audit of the complete RW0 post-execution canonical owner-contract
package: source ownership, value and profile semantics, temporal composition,
privacy, authority, recovery posture, assurance, and migration-free
implementation-boundary readiness

ENGAGEMENT TYPE

Fresh, parent-only, local, read-only independent contract audit.

Do not delegate to subagents or internal audit agents. If parent-only execution
cannot be maintained, stop and report that procedural blocker.

Do not edit repository files, generate repository artifacts inside the
repository, format, stage, commit, push, create a branch or PR, merge, tag,
release, deploy, fetch, contact a remote/live system, install dependencies,
execute tests, run migrations, open or mutate an operator database, invoke a
product worker/model, or inspect/modify supporting repositories.

You may use private external temporary files only for bounded read-only parsing
and identity verification. Remove disposable intermediates before closeout.

Do not repair the fixed package. Do not issue an implementation prompt.

Print the complete substantive audit inline. Evidence paths are supplementary
only and must not contain the core verdict or findings.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

AUDIT_PROVENANCE_MISMATCH

FIXED INPUT

Attach exactly one file named:

RW0_Post_Execution_Canonical_Audit_Package_V2.jsonl

Require exactly:

size:
1659938 bytes

SHA-256:
795bb89f707d29282fbb4bc569fffd4f68d0930d30707ce67522fe8f8660520f

logical records:
615

final newline:
absent

content aggregate:
af3d1eaae0c78e5e21326abcc869c3c0af8c2dafea29a89a7932ce14bf9319d1

first record:
package.manifest.v1

last content record:
remaining-seam.S008

final record:
package.closeout.v1

record-type counts:

package_manifest: 1
source_owner_binding: 23
value_schema: 47
behavior_profile: 28
golden_value: 199
malformed_vector: 33
module_allocation: 47
import_edge: 28
equality_matrix: 45
assurance_case: 58
supersession_entry: 97
remaining_seam: 8
package_closeout: 1

If any fixed-input property differs, stop:

AUDIT_PROVENANCE_MISMATCH

AUDIT POSTURE

The JSONL package is a proposed contract corpus, not repository truth.

Mechanical validity, internal hashes, profile digests, golden identities, and
supersession records prove the identity of the printed package only. They do
not prove that:

- source-owner claims match the merged repository;
- proposed semantics are complete or safe;
- owner boundaries are correctly allocated;
- model output remains non-authoritative;
- privacy and recovery are sufficient;
- the prospective module split is implementable;
- permanent tests are causal;
- implementation is authorized.

Independently inspect current owning repository documents, source, schemas,
readers, relations, tests, and boundaries. State exactly where inspection
stopped and what remains unvalidated.

Use four bounded parent perspectives, without agents:

1. package mechanics, identity, and supersession;
2. source-owner and value/profile grounding;
3. temporal, privacy, resupply, closure, and recovery semantics;
4. authority, assurance, module boundaries, and implementation readiness.

Preserve disagreements and reconcile them in the parent verdict.

FACT CLASSIFICATION

Classify every material claim exactly as one of:

- current owning contract;
- current merged implementation;
- compatibility edge;
- proposed post-execution evidence owner contract;
- proposed Section 41 role-resolution contract;
- proposed RW0-C decision-input contract;
- proposed future committed-recovery contract;
- contract defect;
- owner/authority defect;
- privacy/recovery defect;
- report/package defect;
- compatibility risk;
- implementation-detail observation;
- report-only uncertainty.

CURRENT INVARIANTS TO PRESERVE

Unless current owning repository evidence disproves them:

1. C1 has exactly 15 evidence kinds and owns admitted evidence presence,
   membership, relation receipts, replay, and recovery—not completeness or
   authoritative semantic branch choice.

2. Section 41 owns proposal-family structural coherence and model
   recommendation semantics. The recommendation is evidence, not durable
   branch authority.

3. Existing B1/B2/C1/C2A values, schemas, relations, budgets, and meanings
   remain unchanged.

4. Existing migrations 0001–0004 and Section 41 migration-0003 durable-row
   meanings remain unchanged.

5. Existing public package, StateStore, public WriterSession, and one
   transaction controller remain unchanged.

6. Validation and review source observations are current exact
   `WorkerObservationV1` values.

7. V40 proves operational role/invocation/effect/delivery separation only. It
   proves no distinct human, model, provider, account, credential, host,
   process, organization, cryptographic principal, source authenticity,
   external authority, review quality, acceptance, or permission.

8. Candidate capsule entries and private bodies remain transient and are not
   added to C1 or Section 41 durable state.

9. Policy and risk matrices are owner-authored supplied attestations. Local
   pure code validates identity and coherence but does not recreate external
   policy or risk meaning.

10. FiniteBacklog remains a versioned compatibility adapter behind generic risk
    semantics; it is not target progression authority.

11. Missing or unavailable optional evidence yields `no_decision`.
    Substitution, contradiction, malformed required state, or impossible
    lineage yields `basis_conflict` or integrity failure.

12. Exact resupply is required before an uncommitted decision; committed
    recovery must rely on retained safe values or immutable locators, not
    process memory or opaque aggregate digests.

13. No aggregate branch evaluator, C2B progression writer, migration 0005,
    physical latch, terminal/D/E/Execution Substrate behavior, external contact,
    or implementation is authorized by this package.

PERSPECTIVE 1 — PACKAGE MECHANICS, IDENTITIES, AND SUPERSESSION

A. STRICT JSONL VERIFICATION

Independently verify:

- UTF-8;
- no BOM;
- no blank lines;
- no final newline;
- duplicate-key rejection;
- exact eight-field outer record grammar;
- outer and payload canonical re-encoding;
- payload byte lengths and raw SHA-256;
- every domain-separated digest;
- dense indexes;
- unique record IDs;
- closed record-type order;
- manifest ordered IDs and hashes;
- record-type counts;
- content aggregate;
- closeout reconciliation;
- whole-file SHA-256 with two independent implementations.

B. REPAIRED FINDINGS

Verify closure of:

PKG-CONTRACT-001:
- current review vocabulary is exactly
  `separate | not_separate | unknown | conflict`;
- no current profile/value/support/equality record uses
  `independence_statuses`, `independent`, or `not_independent`;
- permitted occurrences are limited to `independent_reviewer`,
  supersession records, and explicit malformed vectors.

PKG-CONTRACT-002:
- every primary value schema governed by a behavior profile has the exact same
  field set and exact field order;
- schema ID, profile pair, reference posture/preimage, digest posture, and
  self-exclusion agree;
- explicitly verify V02, V14, V15, V22, V38, V39, V40, V43, and V44;
- inspect nested values against their literal nested profile definitions rather
  than incorrectly comparing them to a parent top-level field list.

C. IDENTITY AND GOLDEN CONSISTENCY

Verify:

- every governing profile pair resolves;
- every golden value conforms exactly to its value schema;
- every generated ref and self-digest reproduces;
- all source binding, support set, evidence binding, T1, proposal-family,
  Section 41 projection, rank-15, role-resolution, closure, and snapshot
  identities reproduce;
- superseded identities occur only in supersession records or explicit
  malformed vectors;
- no current canonical profile/value references a superseded identity.

Do not credit Codex’s reported generated-identity count without independent
reconstruction.

PERSPECTIVE 2 — SOURCE-OWNER AND VALUE/PROFILE GROUNDING

D. SOURCE OWNER BINDINGS

For every `source_owner_binding` record, verify against current owning source,
schema, reader, relation, and tests.

At minimum inspect:

- WorkerObservationV1;
- WorkerCommandV1;
- CandidateCapsuleManifestV1;
- validation and review requirement-evidence values;
- RW0EffectHostQualificationV1;
- GlobalStopState;
- AttemptFenceV1 and EffectFenceV1;
- C1 rank-12, rank-13, rank-14, and rank-15 values and relation rows;
- migration-0003 source invocation, artifact, proposal, evidence rows, evidence
  set, selection/disposition, and owner-family graph.

Reject:

- invented source schemas;
- widened enums or formats;
- wrong self-digest field;
- synthetic relation identities where the current owner uses a generic
  relation row plus literal relation ID/version;
- owner fields omitted from a claimed exact reconstruction;
- new semantic meaning attributed to a current owner value.

E. V01–V44 VALUE SCHEMAS

Audit every value schema and nested value for:

- correct owner module and owner status;
- exact field order, types, nullability, and branch rules;
- complete enums and bounds;
- correct reference posture and preimage;
- correct digest domain and self-exclusion;
- unknown-field rejection;
- nested identity posture;
- profile pairing;
- privacy/non-authority claims;
- current versus forecast-only status.

Particularly scrutinize:

- V14 and V15 source/result/support equality;
- V38 and V39 requirement-evidence identity via
  `requirement_ref + safe_evidence_digest`, without substituting embedded
  `requirement_digest`;
- V40 exact current C1/C2A reconstruction and four-result totality;
- V41/V42 owner-authored attestation boundaries;
- V43/V44 generic risk semantics and adapter isolation;
- V35–V37 forecast-only prohibition.

F. BEHAVIOR PROFILES

For all 28 profiles verify:

- complete literal behavior rather than prose references;
- exact value/profile field alignment;
- total result/reason algebra;
- deterministic precedence;
- exact source-support inventories;
- profile identity and digest;
- no unsupported authority claim;
- no circular dependency.

Reject a profile that validates only self-generated values without an
independent literal oracle.

G. MODULE ALLOCATION AND IMPORT DAG

Verify:

- every value/nested value has one exact owner module;
- import direction is acyclic;
- C2A/B1/B2/C1 import none of the new modules;
- new pure modules may privately import exact current owner values;
- generic risk code never imports FiniteBacklog-specific code;
- the adapter imports generic risk values only;
- no package-root export, public API, or current production caller is added;
- V40 remains pure derived local evaluation, not an identity owner.

PERSPECTIVE 3 — TEMPORAL, PRIVACY, RESUPPLY, CLOSURE, AND RECOVERY

H. TWO-CONTEXT AND MODEL-INPUT CONTRACT

Audit:

- distinct lineage context and T1 model-input context namespaces;
- migration-0003 source/proposal context seam;
- exact T1 role entries;
- exact binding from the model invocation to the same nine values later bound
  by Section 41;
- preassigned proposal ref;
- model-input safe projection and private manifest;
- absence of proposal-digest cycles;
- exact semantic construction versus SQL insertion order;
- complete chronology.

Reject a family that is structurally coherent but does not prove the model saw
the same typed values.

I. TRANSIENT SUPPLY AND RESUPPLY

Audit the complete evidence-supply package and all role supplies:

- exact canonical value availability before model invocation;
- exact resupply before uncommitted decision/replay;
- restart-before-decision semantics;
- absence -> `no_decision`;
- malformed/substituted supply -> `basis_conflict`;
- no assumption of process-memory continuity;
- no physical custody or retrieval claim by C.

J. CAPSULE PRIVACY

Verify:

- full CandidateCapsuleManifest is transient/private;
- safe projection narrows exactly to current owner fields and SHA-1 domain;
- no entries, paths, operations, modes, blob identities, byte lengths, private
  bodies, or physical locations enter current durable state;
- model input and decision-time resupply can validate the exact full manifest;
- future committed recovery uses only permitted safe projection and derived
  values;
- no later semantic claim requires forbidden private fields after commit.

K. SECTION 41 ROLE RESOLUTION

Audit all nine role resolutions:

- current composite evidence-row locator;
- exact typed extractor;
- role/rank/ordinal;
- source profile/binding;
- C1 membership and relation where applicable;
- phase/lineage equality;
- recomputable versus attested posture;
- no shape matching;
- no cross-role or sibling-phase substitution;
- zero/nine family handling;
- recommendation non-authority.

L. MEMBERSHIP CLOSURE AND CURRENT SNAPSHOT

Verify:

- exhaustive same-transaction paging;
- strict progress, order, duplication, overflow, and termination;
- complete membership closure identity;
- no C1 completeness authority;
- snapshot owner locators and exact current rows;
- phase/K8 equality;
- current versus proposal-time coordinates;
- bounded inventory sufficient for proposed currentness/authority/stop/ceiling
  profiles;
- no unrelated database state.

M. FUTURE LOGICAL RECOVERY

Audit the package’s logical future committed-recovery contract without treating
it as implemented.

Require:

- full safe values or immutable owner locators;
- no opaque aggregate-digest-only recovery;
- no later mutable-head reread for committed results;
- no transient private package after commit;
- exact distinction between current pure-owner values and forecast-only
  command/result/receipt/recovery values;
- V35–V37 remain prohibited from the current pure-owner implementation
  boundary.

PERSPECTIVE 4 — AUTHORITY, ASSURANCE, COMPATIBILITY, AND READINESS

N. MODEL AND SOURCE NON-AUTHORITY

Verify:

- model recommendation remains evidence only;
- V40 does not claim identity authentication;
- policy/risk supplied attestations do not become executable permission;
- profile/digest validity does not authenticate source;
- persistence does not create authority;
- proposal-time stop/ceiling evidence is not fresh decision permission;
- C2B does not interpret C1 or individual Section 41 evidence.

O. VALIDATION, REVIEW, AND V40

Independently verify the finite algebras:

- validation disposition;
- review result set;
- V40 operational separation;
- independent-review disposition integration.

Exercise conceptually or through local pure reconstruction every positive,
negative, unknown, and conflict tuple in the package.

Pay special attention to:

- one exact author source invocation;
- review invocation inequality;
- distinct author/review effect/fence/delivery;
- shared lineage and capsule equality;
- missing author evidence -> unknown;
- contradictory author evidence -> conflict;
- no person/provider/account identity claim.

P. POLICY, RISK, STOP, CEILING, AND COMPATIBILITY

Verify:

- standing-policy and risk matrices are owner-authored supplied attestations;
- local semantics validate identity/coherence only;
- generic risk schemas contain no mandatory FiniteBacklog fields;
- adapter mapping is explicit and versioned;
- no development/backlog ID equality assumption;
- global-stop proposal snapshot versus fresh future decision evaluation is
  coherent;
- source-effect ceiling evidence preserves separate expiry semantics;
- no branch-specific proposal-time circularity;
- all permit results remain non-authoritative.

Q. FINITE ASSURANCE

Audit all 58 assurance cases and 33 malformed vectors.

Determine whether they causally cover:

- source-owner substitution;
- context and role substitution;
- resupply absence and mismatch;
- capsule privacy;
- value/profile field-order mutation;
- reviewer-separation vocabulary and semantics;
- requirement self-digest substitution;
- policy/risk source substitution;
- FiniteBacklog isolation;
- paging and snapshot corruption;
- superseded-identity leakage;
- public/migration/runtime non-widening.

Permanent tests must remain ordinary finite semantic and canonical-vector
tests. The package must not require a self-protecting audit framework.

R. IMPLEMENTATION DECOMPOSITION

Evaluate whether the proposed migration-free pure-owner tranche is the smallest
non-disposable unit.

It may include only:

- pure values and profiles;
- local pure relations/evaluators;
- Section 41 projection/role-resolution helpers;
- docs and ordinary tests;
- no migration;
- no durable mutation;
- no latch;
- no C2B progression writer;
- no public API;
- no production caller;
- no runtime/external I/O.

Reject the boundary if essential source owners remain missing or if
forecast-only values would be implemented prematurely.

FINDING FORMAT

For every finding print:

```text
ID
Type
Severity: Critical | High | Medium | Low | Observation
Classification
Exact contract
Package record IDs
Repository path/line
Evidence
Impact
Required correction
Uncertainty
```

Distinguish:

- owner/authority defect;
- contract defect;
- privacy/recovery defect;
- compatibility risk;
- package/report defect;
- implementation-detail observation.

VERDICT RULE

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

`ACCEPT` requires:

- exact baseline and fixed-input identity;
- complete package mechanics;
- source-owner grounding;
- no unresolved value/profile contradiction;
- temporal and resupply coherence;
- capsule privacy;
- exact role resolution;
- bounded closure/snapshot;
- safe future logical recovery;
- non-authority preservation;
- FiniteBacklog isolation;
- finite assurance;
- a bounded, migration-free pure-owner implementation boundary;
- no implementation authorization.

On `ACCEPT`, return exactly:

RW0_POST_EXECUTION_CANONICAL_OWNER_CONTRACTS_ACCEPTED_READY_FOR_IMPLEMENTATION_BOUNDARY_FREEZE

This token authorizes only a fresh read-only implementation-boundary freeze. It
does not authorize implementation.

On `BLOCK` or `REJECT`, identify the next owner-contract correction. Do not
issue an implementation prompt.

RETURN FORMAT

# Verdict
# Baseline and fixed-input verification
# Package mechanics and identity audit
# Source-owner grounding audit
# Value and profile audit
# Temporal and Section 41 audit
# Privacy, resupply, closure, and recovery audit
# Authority and compatibility audit
# Assurance audit
# Implementation-boundary assessment
# Severity-ranked findings
# Readiness and next boundary
# Confidence

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
