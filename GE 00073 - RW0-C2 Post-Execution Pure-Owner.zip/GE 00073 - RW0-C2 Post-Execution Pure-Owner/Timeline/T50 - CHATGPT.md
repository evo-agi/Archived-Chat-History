# Decision

**Do not begin the formal independent contract audit yet.** The attached JSONL is a genuine, complete package and its outer mechanics are exceptionally clean, but it contains two deterministic internal contract contradictions. A narrow package-regeneration pass should fix them before we spend the independent audit on source ownership and semantic correctness.

## What passed

I independently verified the attached artifact:

```text
Filename:
RW0_Post_Execution_Canonical_Audit_Package.jsonl

Size:
1,612,437 bytes

SHA-256:
53ebd69d7f58da338a1483a479f7bc8a6ba72d3ccf23bd73139e9b60fe08a674

Records:
576

Final newline:
absent
```

The following all pass:

- strict UTF-8 JSONL parsing with duplicate-key rejection;
- no BOM or blank lines;
- canonical re-encoding of every outer record and every embedded `payload_json`;
- all payload byte lengths and raw SHA-256 values;
- every non-null domain-separated digest;
- dense `0..575` record indexes and unique record IDs;
- the closed record-type order and reported per-type counts;
- manifest lists and hashes for all 574 content records;
- content aggregate:

```text
78cbdb01a18e5e5d5bd66790a0ac7bc9eeb5ee9aa050beb07187883704905eaf
```

- closeout record reconciliation;
- whole-file SHA-256 agreement between Python, OpenSSL, and `shasum`;
- superseded V40 identities confined to supersession records and the dedicated malformed vector.

So Codex solved the earlier delivery problem. The package is actually attached and locally inspectable, rather than being only a private temporary path.

## Blocking package defects

### `PKG-CONTRACT-001` — stale review-separation vocabulary

The package’s current truth is:

```text
V40 status:
separate | not_separate | unknown | conflict

V15 field:
separation_status

V15 semantic tuples:
separate | not_separate | unknown | conflict
```

But the current `independent-review-disposition.v1` profile still contains:

```json
"independence_statuses":
["independent","not_independent","unknown","conflict"]
```

That stale fragment is also embedded in:

```text
golden.V10.full-evidence-supply
golden.V11.role-supply.08.independent_review
```

These are current canonical records—not merely supersession or malformed-vector evidence. The package therefore contains two different status vocabularies for the same V15/V40 relation.

The correction should use one exact operational-separation vocabulary throughout, preferably:

```text
separation_statuses:
separate
not_separate
unknown
conflict
```

That change requires regenerating the review profile, V15 and its support set, rank-8 supply, T1 context, full evidence supply, Section 41 family, role resolutions, and all transitively affected identities.

### `PKG-CONTRACT-002` — contradictory exact field orders

Seven primary value schemas and their governing behavior profiles contain the same field set but declare a different exact order:

| Value | Displaced generated ref |
|---|---|
| V14 validation disposition | `disposition_ref` |
| V15 review disposition | `disposition_ref` |
| V38 validation result set | `result_set_ref` |
| V39 review result set | `result_set_ref` |
| V40 reviewer separation | `evaluation_ref` |
| V43 risk source profile | `source_profile_ref` |
| V44 risk source binding | `source_binding_ref` |

The profiles consistently place the generated ref immediately after `schema_id`; the corresponding `value_schema.ordered_fields` records place it near the end.

Because both records claim to define the exact canonical value grammar, an implementation cannot know which constructor/preimage order is authoritative. Sorted-key JSON makes the current golden object bytes stable, but it does not resolve the conflicting semantic field-order contracts.

The clean target is:

```text
schema_id
generated_ref
...
self_digest
```

which matches the governing profiles and the already-consistent V41/V42 convention. Codex should nevertheless mechanically verify every primary value/profile pair, not only these seven.

## Disposition

```text
Package envelope and artifact delivery:
PASS

Canonical payload integrity:
PASS

Owner-contract package internal consistency:
BLOCK

Formal independent audit:
PREMATURE

Repository implementation:
NOT AUTHORIZED
```

This does **not** reopen:

- V40 operational reviewer separation;
- the current C2A/C1 source graph;
- the two-context design;
- Section 41 projection V2 or role resolution V3;
- policy/risk authorship;
- `FiniteBacklog` adapter isolation;
- capsule privacy;
- C1’s fifteen-kind boundary;
- migration/public/runtime boundaries.

It is a targeted canonical-package correction.

# Codex handoff

Send this prompt to the same architecture conversation:

:chatgpt-content-reference{index="0"}[Download the canonical-package consistency repair prompt](sandbox:/mnt/data/Coordinator_RW0_Canonical_Audit_Package_Internal_Consistency_Repair_Prompt.txt)

```text
Size:
10,254 bytes

SHA-256:
23f8307ffe4886896eff66cf44342e4e8bca86efd4717189672258877c7a0e54

Logical lines:
408

Final newline:
absent
```

Attach the original package as the fixed input:

:chatgpt-content-reference{index="1"}[Download the current canonical package](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Audit_Package.jsonl)

The required revised attachment is:

```text
RW0_Post_Execution_Canonical_Audit_Package_V2.jsonl
```

The required success token is:

```text
RW0_POST_EXECUTION_CANONICAL_AUDIT_PACKAGE_REPAIRED_READY_FOR_INDEPENDENT_AUDIT
```

The prompt requires Codex to:

1. repair the stale review-status vocabulary;
2. reconcile all exact value/profile field orders;
3. regenerate every transitively affected ref and digest;
4. add supersession records for replaced current identities;
5. rerun the complete package verifier;
6. attach the revised JSONL visibly to the response;
7. leave the repository unchanged.

The external pre-audit verification record is available here:

:chatgpt-content-reference{index="2"}[Download the package verification and findings](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Package_PreAudit_Verification.json)

```text
SHA-256:
70da078d75b04a681d19ba9b9a993c17d5d5a8c7a5a70ffab20efbdb1372eb6
```

## Sequence after the repaired package arrives

```text
1. Independently verify the revised JSONL envelope and identities.
2. Start a fresh parent-only semantic/source-owner contract audit.
3. If accepted, perform a read-only implementation-boundary freeze.
4. Only then consider the migration-free pure-owner implementation tranche.
```

### Sources

- Codex completion report supplied in this turn.
- :chatgpt-content-reference{index="3"}[Attached canonical package](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Audit_Package.jsonl)
- :chatgpt-content-reference{index="4"}[Independent pre-audit verification](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Package_PreAudit_Verification.json)

**Confidence:** High in the mechanical package verification; high that both contradictions are real and deterministic; high that a narrow regeneration should close them without another architectural reconciliation.
