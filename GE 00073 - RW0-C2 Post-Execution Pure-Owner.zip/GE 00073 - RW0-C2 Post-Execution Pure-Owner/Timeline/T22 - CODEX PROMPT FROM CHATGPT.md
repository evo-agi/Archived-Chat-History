PROMPT_ID

RW0_C_PRECONTACT_SECTION41_OWNER_FREEZE_COMPLETION_V2

TITLE

Coordinator RW0-C and Section 41 — complete the authorization-owner freeze by
fixing durable-row absence semantics, decision-time derived evaluation,
derived-failure source identity, and all missing canonical value/profile
identities

ENGAGEMENT TYPE

Parent-only, local, read-only contract completion.

Do not delegate to subagents.

Do not edit, format, generate repository files, stage, commit, push, create a
branch or PR, merge, tag, release, deploy, fetch, contact a remote/live system,
install dependencies, execute tests, run migrations, open or mutate an
operator database, invoke a product worker/model, or inspect/modify supporting
repositories.

Do not issue an implementation prompt.

Print the complete substantive report inline. Evidence paths are supplementary
only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_C_AUTHORIZATION_OWNER_COMPLETION_BASELINE_MISMATCH

FIXED INPUT REPORT

Treat the immediately preceding report as fixed input.

If supplied as `Pasted text.txt`, require exactly:

size:
68085 bytes

SHA-256:
c664d9c93f6e862d6ae8c795b1c3c22f5433b86757a80eedc8e045e01c80f9b

logical lines:
676

opening:
# Baseline and accepted blocker

closing token:
RW0_C_PRECONTACT_AND_SECTION41_AUTHORIZATION_OWNERS_READY_FOR_INDEPENDENT_AUDIT

If the fixed input differs, stop:

RW0_C_AUTHORIZATION_OWNER_COMPLETION_FIXED_INPUT_MISMATCH

PRESERVED DECISIONS

Preserve these unless current owner source proves a direct contradiction:

1. RW0-C1 owns admitted evidence presence, not completeness.
2. RW0-C-Decision owns pre-contact reason composition, decision-time closure,
   authorization attestations, route/productivity composition, and the future
   migration-0005 latch.
3. Section 41 owns proposal-family coherence and recommendation semantics.
4. RW0-C selects one exact complete Section 41 family for one decision.
5. C2B consumes one owner-neutral authorization basis and does not interpret
   C1 membership or individual B1/B2/Section 41 evidence.
6. Missing or pending evidence yields `no_decision`, never block.
7. Same-role or raw/derived contradiction yields `basis_conflict`, never block.
8. The latch and cancel-evidence governing supersessions in the fixed report
   remain the target.
9. Existing B1/B2/C1/C2A values, existing Section 41 durable row identities,
   migrations 0001–0004, migration-0002 decision rows, public APIs, and
   transaction authority remain unchanged.
10. `effect_cancellation_authorization` remains a separately unresolved owner
    seam; do not construct it in this pass.
11. RW0-C-Terminal and migration 0006 remain blocked on D/Execution Substrate
    terminal-evidence owners.
12. No implementation is authorized.

FACT CLASSIFICATION

Classify each substantive conclusion exactly as:

- current owning contract;
- current merged implementation;
- compatibility edge;
- proposed RW0-C owner contract;
- proposed Section 41 owner contract;
- proposed cross-owner composition contract;
- implementation detail;
- report-only uncertainty.

KNOWN-PASSING IDENTITIES

Preserve unless changed by a required correction:

Pre-contact profile:

```text
canonical bytes:
18414

raw SHA-256:
1e128271da6e2bda660f4121c4457bf798a6383da1de7b58b9ab8f55b3e288c0

domain:
governed-execution.nwp-rw0-c-pre-contact-decision-basis-profile.v1.identity

domain-separated digest:
aa0373306810415f6941c026e785bd2d975dc8e6acc2d7f559ff76c68f03a8a2
```

Pre-contact golden attestation:

```text
identity bytes:
1265

full bytes:
1353

digest:
16669fa2e0d2851b6bfe95b962fde6ef4853557cb864eb7958b796e6962a4a8f
```

Post-execution golden attestation:

```text
identity bytes:
1984

full bytes:
2072

digest:
0ce9605e905793a567fcb74802a325e5f49fd11254787107cae33dd44907a033
```

If the corrected contract changes any input, regenerate and reprint all affected
identities. Do not preserve stale hashes.

RECONCILIATION A — REQUIRED DURABLE OWNER ROWS MUST FAIL CLOSED

The fixed report currently maps a missing global-stop row or missing current
program/work/selection/effect/delivery coordinate to `no_decision`.

That conflates absent evidence with corruption or unreadable authoritative
state.

Freeze exact source classes:

1. Required durable singleton/head/current rows:
   - global stop;
   - program head;
   - work head;
   - selection head when branch evaluation requires it;
   - effect head when required;
   - delivery head when required.

   For these:
   - exactly one valid row is required;
   - zero, duplicate, malformed, unreadable, or digest-invalid rows are
     `basis_conflict` or the later database-integrity classification;
   - they never produce `no_decision`.

2. Optional admitted evidence roles:
   - authority;
   - subordinate proposal;
   - custody;
   - retrieval;
   - readiness;
   - host qualification;
   - capability declaration/observation/qualification.

   Missing or pending roles may produce `no_decision`.

3. Current preimage mismatch:
   - one or more valid exact rows disagreeing with the frozen expected
     coordinates produce `current_head.conflict`;
   - missing/corrupt current rows do not produce an atom.

Update:

- total source mapping;
- evaluation order;
- result algebra;
- profile manifest;
- current-snapshot grammar;
- tests and mutants;
- golden identities.

RECONCILIATION B — DECISION-TIME DERIVED QUALIFICATION SEMANTICS

The fixed report says both:

- admitted immutable host/capability qualifications are source values; and
- a qualification’s stored `evaluated_at` must equal the later
  `decision_evaluated_at`.

C1 admission and decision are separate durable moments, so equality is not a
safe default.

Make one exact choice.

Preferred contract:

1. Durable admitted qualification values are historical source/support values.
2. At decision time, RW0-C reconstructs their exact admitted raw support
   members and reruns the existing pure owner evaluator using one
   `decision_evaluated_at`.
3. The transient recomputed result is compared with the durable qualification:
   - exact agreement in lineage/result/reason apart from the evaluation-time
     field is coherent;
   - a changed currentness-dependent result is represented by the exact
     recomputed decision-time outcome;
   - an impossible raw/durable contradiction is `basis_conflict`.
4. The source-reason atom binds:
   - the durable qualification membership/ref/digest;
   - every raw support membership/ref/digest;
   - a separately defined decision-time derived-evaluation identity/digest;
   - the recomputed result/reason/evaluated_at.
5. Do not require the historical stored `evaluated_at` to equal decision time.

Alternative:

Define another exact safe rule, but prove that ordinary C1 admission followed
by a later decision remains usable and deterministic.

Freeze separately for:

- effect-host qualification;
- worker-mechanism Capability qualification.

Update profile JSON and golden identities accordingly.

RECONCILIATION C — DERIVED EVALUATION VALUE

Add one exact private pure value, or a closed tagged pair if owner differences
require it, for decision-time derived evaluation.

Freeze:

- schema ID;
- exact ordered fields;
- evaluation kind;
- source evaluator/profile identity;
- complete support-set ref/digest;
- durable source value ref/digest;
- recomputed result;
- recomputed reason;
- evaluated_at;
- evaluation digest;
- canonicalization and digest domain;
- immutable/final/privacy posture.

The source-reason atom must reference this value for derived host/capability
atoms. Do not hide recomputation inside an untyped support-set digest.

RECONCILIATION D — FINITE RELATION/GATE FAILURE SOURCE IDENTITY

The current `finite_relation_gate` role has no exact source value from which
`source_owner_schema_id/ref/digest`, raw reason, replay, or recovery can be
reconstructed.

Freeze one exact private pure `RW0CPreContactFiniteGateEvaluationV1`-like value
with:

- schema/ref/digest;
- gate/relation ID and version;
- exact ordered operand-set digest;
- exact owner profile pair where applicable;
- result `passed | finite_failure`;
- exact finite reason;
- exact current-drift classification input;
- evaluated_at;
- privacy and non-authority claims.

Rules:

- `passed` creates no atom;
- finite failure without proven current drift creates
  `gate.explicit_finite_failure`;
- finite failure with exact current drift creates `current_head.conflict`;
- malformed, ambiguous, or owner-exception state is `basis_conflict`;
- missing required operand is `no_decision`;
- database corruption is not converted into a gate atom.

Use the same explicit evaluation value for subordinate-narrowing relation
failure if appropriate, or define a closed tagged variant.

Update atom source-role grammar and supporting-source sets.

RECONCILIATION E — COMPLETE SOURCE-REASON ATOM AND SUPPORT-SET GRAMMARS

Reissue exact grammars for:

- source-reason atom;
- supporting-source entry;
- supporting-source set;
- decision-time derived evaluation;
- finite gate evaluation;
- atom set;
- current snapshot;
- membership snapshot;
- pre-contact attestation.

For every value print:

- exact schema;
- ordered fields;
- type/nullability rules;
- enum vocabulary;
- ref prefix and reference domain, if applicable;
- digest domain and identity preimage;
- self-exclusion;
- canonical JSON rules;
- outward safe projection;
- reader/reconstruction source;
- privacy/non-authority statements.

Explain what durable or transient record retains each full support-set entry so
that replay and committed recovery do not rely on an opaque digest alone.

RECONCILIATION F — SECTION 41 CONTEXT VALUE IDENTITY

The fixed report names
`Section41PostExecutionSemanticReviewContextV1` and gives an ordered L34
identity, but it does not fully freeze its value grammar.

Freeze:

- exact schema ID;
- exact class/value name;
- ordered fields including `schema_id`, `context_ref`,
  `proposal_phase`, L34, `context_digest`;
- exact ref prefix and reference domain;
- digest domain;
- ref and digest preimages;
- canonicalization;
- immutable/final/non-pickleable posture;
- validation of all L34 owner operands;
- how source/proposal `context_ref/context_digest` equality is checked;
- golden complete value JSON;
- exact identity/full byte lengths and independently reproduced digest/ref.

Do not derive lineage solely from C1.

RECONCILIATION G — SECTION 41 PROJECTION AND PROFILE BYTES

The fixed report provides profile metadata and golden digests but not the exact
canonical profile JSON required to reproduce them.

Print the exact one-line canonical JSON for:

1. Section 41 proposal-family projection profile;
2. one complete golden Section 41 context;
3. one complete golden Section 41 projection.

For the projection freeze:

- projection ref prefix/reference domain;
- projection digest domain and preimage;
- evidence-entry schema and digest;
- evidence-set digest construction;
- owner-family graph binding;
- zero/nine rules;
- exact recommendation/reason grammar;
- exact transient context binding;
- profile manifest;
- golden ref/digest reproduction.

Independently reproduce every digest with two local implementations.

RECONCILIATION H — POST-EXECUTION AUTHORIZATION PROFILE BYTES

The fixed report gives the post-execution attestation fields and one golden
attestation, but not the exact profile manifest whose digest is pinned.

Print exact one-line canonical JSON for:

```text
rw0-c-post-execution-authorization-v1
```

Freeze:

- profile schema/ref;
- manifest;
- branch/recommendation mapping;
- Section 41 profile pair;
- C1 rank-15 wrapper/projection equality;
- current snapshot rules;
- membership snapshot rules;
- ref prefix/reference domain;
- attestation digest domain;
- no-attestation cases;
- privacy/non-authority statements.

Recompute profile and golden identities after all corrections.

RECONCILIATION I — NEUTRAL C2B AUTHORIZATION BASIS PROFILE BYTES

The fixed report supplies field order and profile digest metadata but not exact
canonical profile JSON or full value identity grammar.

Freeze and print:

- profile schema/ref;
- exact manifest JSON;
- exact variants and nullability;
- value schema;
- ordered fields;
- ref, if any, and reference domain;
- authorization-basis digest domain and preimage;
- post-execution profile/attestation/projection requirements;
- pre-contact profile/attestation requirements;
- reserved effect-cancellation posture;
- complete golden post-execution value;
- complete golden pre-contact value;
- byte lengths and independently reproduced digests.

C2B must not inspect C1 memberships, source atoms, or individual evidence.

RECONCILIATION J — SECTION 41 READER AND CURRENTNESS CLOSURE

Verify and freeze:

- exact literal reader queries;
- exact row column order;
- `fetchmany` bounds;
- zero/one/many classifications;
- zero/nine evidence behavior;
- exact source/artifact/proposal/context/evidence reconstruction order;
- proposal recommendation/reason source;
- context lineage source;
- currentness responsibility:
  - Section 41 projection proves immutable family coherence;
  - RW0-C attestation proves decision-time current program/work/head/stop
    posture;
  - no durable Section 41 selection head is invented.

Explicitly classify proposal/source/artifact rows that are missing, duplicated,
malformed, or digest-invalid.

RECONCILIATION K — ASSURANCE MATRIX COMPLETION

Extend the finite matrix with claim IDs for:

- required durable-row absence/corruption;
- decision-time recomputation versus historical qualification time;
- derived-evaluation identity;
- finite-gate evaluation identity;
- support-set retention and recovery;
- Section 41 context ref/digest;
- profile canonical bytes for all three profiles;
- golden context/projection/neutral-basis values;
- reader zero/one/many cases;
- context/proposal mismatch;
- currentness split between Section 41 and RW0-C;
- reserved effect-cancellation rejection.

For each identify permanent test, literal oracle, negative mutant, independent
audit check, and provenance source.

PRESERVE GOVERNING SUPERSESSIONS

Retain exactly the latch and cancel-evidence superseding statements from the
fixed report and their identified governing documents/tests.

Do not re-open C2B progression poststates, migration 0005, or terminal
semantics in this pass.

SUCCESS CONDITIONS

Return:

RW0_C_PRECONTACT_AND_SECTION41_AUTHORIZATION_OWNERS_COMPLETED_READY_FOR_INDEPENDENT_AUDIT

only if:

- required durable-row absence fails closed;
- qualification time semantics are usable across separate C1/decision moments;
- every derived failure has an exact source identity;
- every value/profile/ref/digest grammar is reproducible;
- all claimed profile/golden hashes match exact printed bytes;
- Section 41 context/projection reconstruction is closed;
- finite assurance is expanded;
- no implementation prompt is issued.

Otherwise return one precise blocker:

RW0_C_PRECONTACT_OWNER_COMPLETION_BLOCKED

or:

SECTION41_AUTHORIZATION_OWNER_COMPLETION_BLOCKED

with the unresolved owner decision.

RETURN FORMAT

# Baseline and fixed input
# Preserved decisions
# Required durable-row failure semantics
# Decision-time qualification recomputation
# Derived evaluation value
# Finite gate evaluation value
# Source atom and support-set grammars
# Corrected total mapping and precedence
# Corrected pre-contact profile and golden identities
# Section 41 context value
# Section 41 projection and profile
# Section 41 readers and reconstruction
# Post-execution authorization profile and attestation
# Neutral C2B authorization profile and values
# Governing supersessions
# Expanded finite assurance matrix
# Remaining seams and stop conditions
# Recommended next step
# Confidence

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
