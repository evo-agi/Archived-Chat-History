PROMPT_ID

C2B_PROGRESSION_DECISION_OWNER_GOVERNING_RESET_AND_FINAL_CLOSURE_V1

TITLE

Coordinator C2B — explicitly reset the latch and cancel-evidence ownership
contracts, then complete the progression-decision owner value, write, replay,
recovery, and assurance freeze

ENGAGEMENT TYPE

Parent-only, local, read-only governing-contract reconciliation.

Do not delegate to subagents.

Do not edit, format, generate repository files, stage, commit, push, create a
branch or PR, merge, tag, release, deploy, fetch, contact a remote/live system,
install dependencies, execute tests, run migrations, open or mutate an
operator database, invoke a product worker/model, or inspect/modify supporting
repositories.

Do not issue an implementation prompt.

Print the complete substantive report inline. Evidence files may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

C2B_PROGRESSION_DECISION_GOVERNING_RESET_BASELINE_MISMATCH

AUDIT INPUT

Treat the immediately preceding independent audit response as the authoritative
finding ledger for this pass.

It returned BLOCK with:

- C2B-AUD-001 — latch owner conflict;
- C2B-AUD-002 — missing finite-reason mapping;
- C2B-AUD-003 — Section 41 authorization projection not reconstructible;
- C2B-AUD-004 — incomplete closed value and digest grammars;
- C2B-AUD-005 — under-specified branch writes and CAS postimages;
- C2B-AUD-006 — cancel omits current owner-required evidence bindings;
- C2B-AUD-007 — contradictory receipt/readback ordering;
- C2B-AUD-008 — incomplete three-way recovery matrix;
- C2B-AUD-009 — non-finite assurance plan.

The audit independently passed:

- both final profile identities;
- migration-0002 physical representability of the existing row variants;
- the owner-neutral high-level boundary;
- the `LIMIT 2` single-work query;
- broad branch row-presence shapes;
- migration-0002 FK feasibility in principle;
- the one-controller/one-transaction target;
- no current public or runtime implementation.

Do not repeat a nominal audit. Reconcile the governing owner changes explicitly
and close every missing semantic/value/recovery detail.

FACT CLASSIFICATION

Label every substantive conclusion exactly as one of:

- current owning contract;
- current merged implementation;
- reopened owner seam;
- proposed superseding owner contract;
- compatibility edge;
- implementation detail;
- report-only uncertainty.

Do not claim that a superseding target is already current repository truth.

NON-NEGOTIABLE PRESERVATIONS

Unless a direct current-owner contradiction is demonstrated:

1. Existing migration-0002 bytes, tables, columns, checks, FKs, enums, and row
   meanings remain unchanged.

2. Existing persisted decision pairs remain:

```text
accept / candidate_acceptance
repair / candidate_repair
replan / attempt_selecting_replan
terminal_reject / program_terminal_reject
block / program_block
cancel / effect_cancellation
```

3. Both pre-contact and post-execution block map to the existing
   `block / program_block` row grammar.

4. Version-advancing branches use the explicit first-slice single-work profile.

5. Cancel is non-version-advancing and membership-neutral.

6. Same-work replan, repair WorkSpec rebinding, work-before-program CAS, no CAS
   on cancel, receipt-first replay, the active-stop matrix, one timestamp, one
   common controller/transaction/commit, and no standalone C2B commit path
   remain the target.

7. Migration 0005 remains the physical RW0-C-Decision/latch schema boundary.
   Migration 0006 remains blocked on D/Execution Substrate terminal-evidence
   owners.

8. No public API, StateStore, package, public WriterSession, second controller,
   second connection, second commit, external I/O, or supporting-repository
   change is authorized.

9. No implementation is authorized by this engagement.

PART I — EXPLICIT GOVERNING OWNER RESET

The independent audit found two current-owner conflicts. Do not hide them as
compatibility repairs.

A. LATCH SEMANTIC EVENT VERSUS PHYSICAL ROW/CAS

Current owning prose says that the accepted productive direct-local C2B
decision atomically consumes the latch.

Freeze the superseding owner split as follows unless inspection proves it
incoherent:

1. C2B owns:
   - the exact `accept / candidate_acceptance` progression result;
   - the semantic fact that this is the only progression branch eligible to
     participate in acceptance-latch consumption;
   - no route, productivity, latch-row, or latch-CAS value.

2. RW0-C owns:
   - exact decision closure;
   - exact direct-local route attestation;
   - exact productive-output attestation;
   - the physical singleton latch row in migration 0005;
   - the available/version-0 -> consumed/version-1 CAS;
   - the outer result/receipt and recovery proof.

3. The common transaction atomically commits:
   - the exact C2B accept family;
   - the exact RW0-C decision closure/binding;
   - the exact latch CAS;
   - the outer receipt.

4. Neither the C2B family nor the latch may commit alone.

5. Governing wording must be revised from “C2B physically owns/updates the
   latch” to the exact semantic statement:

```text
A productive direct-local C2B candidate-acceptance decision is the sole
progression result eligible for acceptance-latch consumption. The outer
RW0-C-Decision composition proves route and productivity, owns the physical
singleton and CAS, and commits the C2B acceptance family and latch postimage
atomically in one transaction.
```

6. Freeze every current owner document and direct test whose wording must be
   superseded. Classify this as downstream owner-contract churn, not current
   implementation.

If this split cannot preserve one authoritative semantic owner and one
physical row owner, stop:

C2B_PROGRESSION_DECISION_LATCH_OWNER_RESET_BLOCKED

B. CANCEL DECISION-EVIDENCE BINDINGS

Current owner prose describes the cancel family as including closed-role
decision-evidence bindings, but the current physical migration sequence does
not provide the previously planned owner table under the historical ownership
described by those passages.

Freeze the superseding target:

1. The RW0-C decision closure is the sole durable evidence-binding family for
   an RW0 decision.

2. The C2B cancel family owns only:
   - the exact owner-neutral cancellation authorization basis;
   - the unchanged `cancel / effect_cancellation` decision row;
   - the unchanged progression result;
   - the unchanged development mutation receipt;
   - the completed nested C2B receipt projection.

3. The owner-neutral cancellation authorization basis binds the exact source
   directive/evidence and target/current owner identities needed by the
   existing decision row.

4. The outer RW0-C closure binds the exact C1 memberships and relation proofs
   from which that owner-neutral basis was derived.

5. No separate C2B `development_decision_evidence_bindings` table is added.
   Migration 0002 remains unchanged.

6. Existing prose promising a separate C2B binding family is explicitly
   superseded. Freeze every owner document and test requiring update.

7. Replay and recovery prove:
   - exact C2B decision/result/receipt;
   - exact authorization-basis digest;
   - exact outer C closure/binding;
   - no duplicate hidden evidence family.

If this supersession would leave the cancel family unable to prove its exact
authorization basis or violate an existing persisted row invariant, stop:

C2B_PROGRESSION_DECISION_CANCEL_EVIDENCE_OWNER_RESET_BLOCKED

PART II — CLOSE THE CONTRACT DEFECTS

C. PRE-CONTACT FINITE-REASON MAPPING

Identify the authoritative frozen RW0-C pre-contact source-reason vocabulary
from the latest reconciled C-local contract and current owner documents.

Print:

1. every source reason;
2. every destination category in the 13-category pre-contact profile;
3. one total deterministic mapping table;
4. every permitted many-to-one mapping and why it preserves authorization
   meaning;
5. reasons that yield `no_decision` rather than block;
6. collision/ambiguity rejection;
7. command, attestation, replay, and recovery bindings.

The mapping must distinguish at minimum:

- explicit negative;
- explicit unknown;
- explicit unavailable;
- explicit contradictory/conflicting;
- stale/currentness failure;
- global-stop/head conflict;
- insufficient/missing evidence that remains `no_decision`.

Missing membership alone must never map to block.

If no authoritative source vocabulary can be identified, stop:

C2B_PRECONTACT_REASON_OWNER_RECONCILIATION_REQUIRED

D. EXACT SECTION 41 OWNER PROJECTION

Freeze one exact pure, private, Section-41-owned post-execution decision
authorization projection.

It must not be C1-owned or C2B-invented.

At minimum freeze:

- schema ID;
- ordered fields;
- immutable/final posture;
- canonical identity and digest domain;
- source invocation identity;
- private artifact/binding identity;
- model proposal identity;
- exact evidence-set identity;
- exact zero-or-nine evidence-row cardinality;
- exact role/rank/ordinal order for nine rows;
- disposition identity and recommendation/reason;
- selection-head identity/currentness;
- complete program/work/attempt/candidate/K8 lineage needed by C2B;
- owner-family graph digest;
- source-owner ref/digest equality;
- evaluation timestamp semantics;
- privacy/non-authority statements.

Freeze exact owner-row locators/readers:

- source invocation;
- artifact binding;
- model proposal;
- evidence bindings;
- disposition;
- selection head;
- any required lineage/basis rows.

Freeze exact reconstruction order, bounded cardinalities, duplicate/overflow
classification, missing-row classification, current-selection proof, and
digest construction.

Prefer an additive pure Section 41 projection value reused by:

- C1 rank-15 wrapper verification;
- outer RW0-C closure;
- C2B authorization basis.

Do not change existing owner row identities.

E. CLOSED VALUE AND DIGEST GRAMMARS

Reissue complete exact definitions for every private value:

1. main C2B owner profile;
2. outer pre-contact profile;
3. Section 41 authorization projection;
4. pre-contact authorization attestation;
5. cancellation authorization basis;
6. tagged `DevelopmentProgressionAuthorizationBasisV1`;
7. `DevelopmentProgressionResultAssignmentsV1`;
8. `DevelopmentProgressionOwnerCommandV1`;
9. `DevelopmentProgressionEvaluationBasisV1`;
10. sealed write plan;
11. work-head CAS specification;
12. program-head CAS specification;
13. progression result plan;
14. completed nested C2B receipt projection;
15. recovery selector;
16. conflict value;
17. recovery result.

For every value print:

- exact schema ID;
- ordered field list;
- exact type and nullability;
- closed enums;
- immutable/final/non-pickleable posture where applicable;
- canonical JSON rules;
- digest domain;
- identity mapping;
- self-exclusion rule;
- outward safe projection;
- privacy/non-authority claims.

`resulting_work_spec_safe_projection` must have one exact schema and field
order, not an abstract placeholder.

Rebuild and reprint final profile JSON and digests only after all other
reconciliation decisions are complete.

F. EXACT BRANCH FIELD BUILDERS

For all seven profile branches print exact field-level builders for every
created row.

Freeze:

- every inserted column;
- every source row/command/basis input;
- exact version/revision arithmetic;
- prior refs and digests;
- exact timestamps;
- exact self-digest preimages/domains;
- WorkSpec relation-key and safe-binding construction;
- accepted-intent/work edge source/target/direction/identity;
- membership ordinal and digest;
- branch-forbidden rows/fields;
- result program version;
- decision reason code;
- graph role/ordinal;
- persisted receipt fields.

Branches:

- candidate acceptance;
- candidate repair;
- attempt-selecting replan;
- program terminal reject;
- post-execution program block;
- pre-contact program block;
- effect cancellation.

Do not use “C2B derives” as a substitute for a field formula.

G. EXACT CAS POSTIMAGES AND ROWCOUNT ALGEBRA

For work-head and program-head CAS print:

- exact SQL;
- exact ordered parameters;
- complete preimage predicates;
- exact `head_revision + 1`;
- exact new version/revision ref/number/state;
- exact `updated_at`;
- exact postimage digest domain and preimage;
- one-row requirement;
- rowcount zero -> one private aggregate conflict;
- rowcount greater than one -> `database_integrity_failure`;
- rollback semantics;
- work-before-program order;
- no CAS on cancel/replay.

H. RECEIPT AND READBACK ORDER

Freeze exact composed write/read order:

1. receipt-first lookup and replay/conflict resolution;
2. owner reads and authorization reconstruction;
3. plan construction;
4. C2B immutable rows in branch order;
5. work-head CAS if applicable;
6. program-head CAS if applicable;
7. C2B persisted receipt last among C2B family writes;
8. complete C2B in-transaction readback including that receipt;
9. completed nested C2B receipt projection/digest;
10. outer RW0-C closure/binding rows;
11. latch CAS only for exact eligible accept;
12. outer RW0-C receipt last;
13. complete outer readback;
14. capability invalidation;
15. exactly one COMMIT;
16. full close proof and result handoff.

Explain rollback of all nested rows and latch on any later outer failure.

I. EXACT THREE-WAY RECOVERY MATRICES

For each profile branch freeze two literal matrices.

Receipt-present committed proof:

- persisted C2B receipt;
- command/profile/authorization digests;
- decision row;
- every branch-specific version/membership/revision/WorkSpec/edge row;
- graph;
- result;
- historical head postimage digests;
- completed nested receipt digest;
- exact outer C closure/binding;
- exact latch postimage for eligible accept;
- no extra/colliding row.

Receipt-absent absence proof:

List every operation-owned preassigned locator that must be absent, including
ref and digest alternate/global probes.

Distinguish pre-existing basis rows from operation-owned rows.

For each locator freeze:

- literal query/reader;
- parameters;
- bounded cardinality;
- absent/exact/collision/malformed classification.

Freeze exact outer/nested/latch agreement rules.

Outcomes remain exactly:

```text
committed_exact
definitely_not_committed
unresolved
```

Later unrelated head advancement must not defeat immutable committed or absent
proof. Current retry CAS may still fail on a fresh attempt.

No same-writer automatic retry.

J. FINITE ASSURANCE MATRIX

Replace thematic assurance prose with a finite matrix.

For each claim assign:

- claim ID;
- permanent test;
- literal expected vector/oracle;
- negative mutant;
- external audit check;
- fault site if applicable.

Cover every:

- profile byte/digest;
- value schema/digest;
- pre-contact reason mapping;
- Section 41 reconstruction role/cardinality;
- branch positive graph;
- forbidden row/field;
- WorkSpec and edges;
- single-work zero/one/two;
- branch prestate;
- stop history;
- CAS zero/one/>1 and order;
- each immutable insert;
- C2B receipt insertion;
- nested readback;
- outer closure writes;
- latch CAS;
- outer receipt;
- capability invalidation;
- COMMIT before/after underlying result;
- cursor/connection/controller/lease cleanup;
- replay;
- every branch committed/absent/partial/collision recovery;
- public/authority non-widening.

Permanent tests own finite product behavior. Independent audit owns patch
provenance, external mutants, fault injection confirmation, privacy inspection,
and clean/live validation. No self-protecting tests.

PART III — UPDATED OWNER PROFILE AND IMPLEMENTATION SEQUENCE

After all decisions above:

1. Rebuild the main C2B profile manifest.
2. Rebuild the outer pre-contact profile if its vocabulary/fields changed.
3. Print exact compact canonical JSON as one line for each.
4. Print exact byte lengths.
5. Print exact domain-NUL construction.
6. Independently recompute with two implementations.
7. Print final digests.
8. Update every command/basis/receipt/recovery reference consistently.
9. Print a stale-field/stale-digest audit proving no superseded field remains.

Freeze the implementation sequencing decision:

Preferred target, subject to inspection:

- one combined candidate may add:
  - additive pure Section 41 authorization projection;
  - private C2B progression owner contracts/plans/readback;
  - RW0-C decision closure and migration 0005;
  - physical latch and outer composition;
- ownership remains in separate modules and tests;
- one common transaction/controller;
- acceptance applies only to the complete candidate;
- no independently published standalone C2B writer is required.

If a separately merged Section 41 or governing-doc owner tranche is required,
state why it is independently useful and non-disposable.

TOUCHED-SURFACE FORECAST

Do not issue an implementation allowlist yet.

Return path-derived categories:

- governing docs/tests that must change for latch and cancel-evidence owner
  supersession;
- additive Section 41 projection owner surfaces;
- additive C2B owner contract/planning/readback surfaces;
- RW0-C migration-0005/closure/latch surfaces;
- common controller/writer integration;
- permanent tests;
- status/catalog/source-hash/importer consumers;
- protected migration 0001–0004, semantic-owner values, public surfaces, and
  supporting repositories.

STOP CONDITIONS

Return a precise blocker if reconciliation requires:

- changed migration-0002 bytes;
- new/reinterpreted decision kind/variant/field;
- generic JSON/BLOB semantic payloads;
- C2B interpretation of C1 memberships;
- C selection of C2B poststates;
- a second controller/transaction/commit;
- public API widening;
- external I/O;
- inability to define exact Section 41 projection;
- inability to define total pre-contact reason mapping;
- inability to prove three-way recovery;
- any latch mutation outside exact outer-C productive-direct-local accept;
- terminal/D/ES truth entering this tranche.

RETURN FORMAT

# Baseline and audit findings accepted
# Current versus superseding owner contracts
# Latch governing-owner reset
# Cancel evidence-binding governing-owner reset
# Pre-contact reason vocabulary and total mapping
# Exact Section 41 authorization projection
# Closed private value and digest grammars
# Exact branch field builders
# Exact CAS postimages and rowcount algebra
# Receipt and readback order
# Branch-specific replay and recovery matrices
# Finite assurance matrix
# Final profile identities
# Implementation sequencing decision
# Provisional touched-surface forecast
# Remaining seams and stop conditions
# Recommended next step
# Confidence

SUCCESS TOKEN

Return exactly:

C2B_PROGRESSION_DECISION_GOVERNING_RESET_AND_FINAL_CONTRACT_READY_FOR_INDEPENDENT_AUDIT

only if:

- both owner conflicts are explicitly superseded;
- every High/Medium audit finding is closed at contract level;
- final profile bytes reproduce final digests;
- recovery and assurance are finite;
- no implementation prompt is issued.

Otherwise return:

C2B_PROGRESSION_DECISION_GOVERNING_RESET_BLOCKED

and identify the precise unresolved owner decision.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
