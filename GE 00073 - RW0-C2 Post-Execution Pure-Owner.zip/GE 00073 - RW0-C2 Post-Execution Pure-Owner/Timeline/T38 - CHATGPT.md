# Decision

**Accept the `BLOCK`. Do not authorize the pure-owner implementation tranche yet.**

The audit did not overturn the reconciled owner allocation. It found that the proposal-time/decision-time architecture is directionally sound but still lacks the exact contracts needed to survive process loss, restart, replay, and later committed recovery. The two load-bearing defects are:

1. **No exact T1 model-input value proves that the model consumed the same nine typed values later recorded by Section 41.**
2. **No exact resupply and recovery contract exists for the full candidate manifest and the other non-durable proposal-time values.**

The audit also found six High and two Medium follow-on defects in current-snapshot completeness, profiles, local result algebras, Section 41 locators, logical recovery retention, assurance, expiry semantics, and chronology. :chatgpt-content-reference{index="0"}

## What remains valid

Preserve the prior temporal reconciliation:

- Proposal-time owner values exist before model invocation.
- Policy and risk are five-branch matrices rather than post-hoc evaluations of an already chosen branch.
- Proposal-time global stop is historical evidence; RW0-C later performs a fresh stop evaluation.
- Source-effect ceiling evidence is branch-neutral.
- `FiniteBacklog` remains behind a versioned compatibility adapter.
- Model recommendation remains evidence and is compared only after RW0-C independently derives a branch.

The audit found no defect in those authority and compatibility directions. :chatgpt-content-reference{index="1"}

## The critical missing contract

### T1 semantic-review input context

The proposed chronology refers to a closed T1 manifest, but the report never defines its schema, identity, safe contents, or equality relation to the later Section 41 rows. The current Section 41 evidence-set digest cannot serve as T1 because it includes binding timestamps produced after model invocation and artifact validation. :chatgpt-content-reference{index="2"}

The next freeze should define one exact pure value—provisionally:

```text
PostExecutionSemanticReviewInputContextV1
```

It should be the common predecessor of:

```text
model invocation
        and
the nine later Section 41 evidence rows
```

The existing source-invocation `context_schema_id`, `context_ref`, and `context_digest` seam should bind it. The context must identify the exact typed values supplied to the model, not merely nine opaque ref/digest pairs. :chatgpt-content-reference{index="3"}

### Separate semantic construction from SQL insertion

The corrected order should distinguish:

```text
Pure semantic construction:
owner values
→ T1 context
→ model invocation
→ artifact validation
→ pure evidence-row construction
→ pure proposal construction
```

from the current migration-`0003` insertion order:

```text
source invocation
→ artifact binding
→ proposal parent
→ evidence children
```

The proposal ref may be preassigned, but current immediate foreign keys require the proposal parent to be inserted before the evidence rows. :chatgpt-content-reference{index="4"}

## Resupply without stealing RW0-D custody

The audit calls out the absence of a custodian or retrieval path. That must **not** cause RW0-C to acquire physical custody, storage, or retrieval mechanics reserved for later phases.

The appropriate C contract is:

```text
Before a decision commits:
the exact proposal-time package is a required supplied operation input.

Absence:
no_decision

Identity/schema/content mismatch:
basis_conflict

Restart before decision:
exact resupply required

Exact replay before commit:
exact resupply required

After committed decision:
readback and recovery use retained safe derived values and immutable locators,
not the transient private package.
```

This is a supplied-value contract, not a claim that Coordinator physically possesses or can retrieve the source material.

It applies to:

- the complete `CandidateCapsuleManifestV1`;
- validation and review dispositions;
- policy and risk matrices;
- proposal-time stop snapshot;
- source-effect ceiling evidence;
- their support, profile, and source-binding values.

The audit correctly notes that neither C1 membership nor a Section 41 ref/digest supplies the missing canonical bytes. :chatgpt-content-reference{index="5"}

For the capsule specifically:

- the full manifest can remain transient;
- existing durable state retains only permitted safe bindings;
- later committed recovery retains the safe capsule projection and derived decisions;
- no capsule entries, paths, blob identities, byte lengths, physical locations, or raw private content should be added to C1 or Section 41.

## Decision-time closure and current snapshot

The next freeze also needs two exact RW0-C-owned pure values.

### Complete membership closure

Provisionally:

```text
RW0CDecisionMembershipClosureV1
```

It must be built by exhaustive, same-transaction paging of the existing private C1 reader. C1 still owns only admission; RW0-C owns the decision-time assertion that the complete admitted set has been enumerated for this decision.

The paging contract must freeze:

- initial cursor;
- page size;
- strict monotonic progress;
- duplicate and ordering rejection;
- continuation;
- termination;
- closure identity;
- later-admission posture.

The audit correctly rejects an unexplained `membership_snapshot_ref/digest` because no owner or completeness contract was defined for it. :chatgpt-content-reference{index="6"}

### Minimum sufficient current snapshot

The current snapshot must include the exact coordinates needed by the fresh evaluators, including only the relevant:

- program and work heads;
- selection, effect, and delivery heads;
- phase/K8 and membership closure;
- authority source and parent/family;
- attempt/effect fences and separate expiry values;
- policy/risk current source coordinates;
- global stop;
- capture timestamp.

A historical phase digest is not a substitute for fresh mutable-head state. :chatgpt-content-reference{index="7"}

## Other corrections that should be made in the same pass

The correction should also close:

- total result/reason tables and deterministic precedence for validation and review dispositions;
- branch applicability, governed effect classes, result/reason tables, and precedence for policy and risk matrices;
- distinct attempt-fence, effect-fence, grant, and authority-observation expiry fields;
- complete versioned identities for support sets, matrices, currentness evaluators, decision-time matrices, recommendation consistency, membership closure, and current snapshot;
- Section 41 evidence binding through its current composite locator `(proposal_ref, evidence_role, ordinal)`, rather than an undefined `evidence_binding_ref`;
- exact role-specific typed ref/digest extraction and nullable source-profile/source-binding rules;
- the logical safe values and immutable locators that a future migration-`0005` committed decision must retain;
- the additional temporal, resupply, restart, identity-substitution, paging, snapshot, and recovery mutants identified by the audit. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

## Codex handoff

Send this read-only prompt to the same architecture conversation:

:chatgpt-content-reference{index="14"}[Download the context, resupply, snapshot, and recovery owner-completion prompt](sandbox:/mnt/data/Coordinator_RW0_Post_Execution_Context_Resupply_Snapshot_Recovery_Owner_Completion_Prompt.txt)

```text
Filename:
Coordinator_RW0_Post_Execution_Context_Resupply_Snapshot_Recovery_Owner_Completion_Prompt.txt

Size:
24,855 bytes

SHA-256:
ee270122cc88f12369d25302326428d23d3582e069e8bb93e7fef3e75e7540a4
```

The required successful result is:

```text
RW0_POST_EXECUTION_CONTEXT_RESUPPLY_SNAPSHOT_RECOVERY_OWNERS_READY_FOR_INDEPENDENT_AUDIT
```

The prompt does not reopen the owner allocation or the future total branch truth table. It is limited to:

- T1 context and model-input equality;
- transient-value supply/resupply;
- capsule privacy;
- role locators and extraction;
- local deterministic evaluator algebras;
- complete behavior identities;
- C1 membership closure;
- current snapshot;
- future logical committed-recovery retention;
- finite assurance.

No implementation is authorized.

## Sequence after a successful completion

```text
1. Fresh independent audit of the completed owner contract.
2. Read-only implementation-boundary freeze for the migration-free pure-owner tranche.
3. Implement, independently audit, and merge that owner tranche.
4. Freeze the authoritative RW0-C branch truth table and authorization attestation.
5. Reconcile and audit the C2B progression owner.
6. Freeze the combined C2B + RW0-C-Decision + migration-0005 boundary.
```

## Current project state

```text
RW0-C1:
merged and current

Proposal-time owner allocation:
accepted directionally

T1 model-input binding:
not frozen; Critical blocker

Transient-value resupply/restart:
not frozen; Critical blocker

Decision-time membership closure and current snapshot:
not frozen

Future committed-recovery logical family:
not frozen

Pure governing-owner implementation:
not authorized

C2B progression-decision owner:
blocked

migration 0005:
not implementation-authorized
```

### Source

- Attached independent-audit report. :chatgpt-content-reference{index="10"} :chatgpt-content-reference{index="11"} :chatgpt-content-reference{index="12"} :chatgpt-content-reference{index="13"}

**Confidence:** High that the `BLOCK` is correct; high that exact supplied resupply—rather than C-owned physical custody—is the right resolution before commit; medium-high that this one bounded completion pass can close the remaining owner-contract gaps without reopening B1/B2/C1 or migration semantics.
