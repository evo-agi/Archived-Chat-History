# Decision

**Accept the two-tranche architecture and the terminal-owner blocker. Do not yet accept migration `0005` as ready for independent contract audit or implementation.**

Codex correctly closed the major phase-level questions:

- one RW0-C decision per exact C1 phase;
- a separate later terminal closure;
- a committed cancel decision is mandatory for `pre_effect_cancel_basis_unusable`;
- `cancellation_rejected` cannot currently yield terminal `cancel`;
- the latch is scoped to one authoritative Coordinator state-root database;
- migration `0006` is blocked because process-group, descendant, physical custody, source-receipt, and route-currentness owners do not yet exist. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The correct terminal disposition is therefore:

```text
RW0-C-Terminal:
semantic invariants bounded, physical schema not freezeable

migration 0006:
not authorized

required predecessor:
D/ES terminal-evidence owner reconciliation
```

However, the proposed RW0-C-Decision freeze contains several material contract defects.

## 1. The C1 page limit was mistaken for a total phase-evidence limit

Codex freezes a hard maximum of 256 C1 members because the reader uses `LIMIT 257`. :chatgpt-content-reference{index="2"}

The merged C1 query is actually cursor-paginated:

```sql
WHERE phase_basis_ref = ?
  AND (kind_rank > ? OR (kind_rank = ? AND membership_ref > ?))
ORDER BY kind_rank ASC, membership_ref ASC
LIMIT 257
```

It can be called repeatedly after the last `(kind_rank, membership_ref)` cursor. `257` is a **per-page overflow sentinel**, not a phase-wide maximum. 

RW0-C may still adopt a finite total closure ceiling, but it must be an explicit C-owned engineering limit with its own rationale and failure contract. It cannot be silently inherited from the C1 paging size.

## 2. The branch set `X` contradicts the merged rank-14 contract

The report defines every post-execution branch around:

```text
one rank-13 worker-result binding
plus one rank-14 process/result classification
```

:chatgpt-content-reference{index="4"}

But merged C1 rank 14 supports:

```text
result_state =
  present
  finite_failure
  absent
```

Only `present` has a rank-13 result membership. The durable rank-14 row expressly makes `result_membership_ref/digest` nullable and carries a finite failure reason when applicable. 

The freeze therefore needs three explicit result bases:

```text
X_present
X_finite_failure
X_absent
```

Accept should require `X_present` and a usable classification. Repair, replan, terminal reject, and block need an exact branch-specific matrix rather than a phantom rank-13 result.

## 3. Block currently risks turning missing membership into external truth

The proposed post-execution block permits “missing” branch evidence, while pre-contact block permits an “incomplete gate.” :chatgpt-content-reference{index="6"}

C1 membership proves only that a claim was admitted. It does not prove that an external event did not occur, that a source has finished reporting, or that absent evidence is permanently unavailable. That distinction was already part of the accepted phase direction. :chatgpt-content-reference{index="7"}

A durable `program_block` should instead require at least one of:

- an exact complete Section 41 `block` recommendation;
- an explicit owner-authored negative, unavailable, unknown, or conflicting observation;
- contradictory complete branch families;
- a current authority, stop, or head conflict.

Mere absence of a C1 membership should normally mean **no decision yet**, not permanent block.

## 4. The latch postimage was weakened without a decision

The earlier phase-level design bound the consumed latch to the decision closure and result as well as the decision, candidate, capsule, and program version. The proposed table now directly stores only the decision, program-version, candidate, and capsule identities. :chatgpt-content-reference{index="8"}

That might be defensible through a unique immutable closure-to-decision binding, but the report does not make or defend that choice. The safest contract is for the latch postimage itself to bind:

```text
decision ref/digest
decision-closure ref/digest
outer decision result-projection digest
resulting program-version ref/digest
candidate ref
capsule ref/portable digest
consumed timestamp
latch-postimage digest
```

This does not require another table or change the proposed schema totals.

## 5. Decision-time snapshot semantics remain underdefined

The closure captures the “complete” C1 membership set, but C1 remains open to later admissions—especially after a pre-effect cancel decision. The freeze must define:

- repeated paging to exhaustion;
- any explicit C-owned total ceiling;
- canonical ordering and set digest;
- the decision-time snapshot as an admission-time attestation;
- replay and recovery without incorporating later memberships;
- later terminal closure including post-decision memberships;
- no reliance on same-second timestamps as a hidden high-water mark;
- no mutable C1 completeness head.

Without this, “complete membership snapshot” is not yet an exact durable contract.

# What remains accepted

The following should not be reopened:

```text
RW0-C decomposition:
Decision first, Terminal later

one decision per C1 phase:
accepted

migration 0005:
the correct provisional schema boundary

migration 0006:
blocked

pre-effect cancel unusable:
requires an exact committed cancel decision

cancellation rejection:
terminal block under current owners

D/ES terminal evidence seam:
real and blocking

existing B1/B2/C1/C2A/C2B/Section 41 identities:
protected
```

The proposed six-table migration shape and cumulative `68 tables / 122 triggers / 7 explicit indexes` remain plausible, but the columns and branch checks must be regenerated after the reconciliation above. :chatgpt-content-reference{index="9"}

# Next step

Run one more **read-only decision-contract reconciliation**, then independently audit the resulting freeze. Do not issue an implementation prompt yet.

:chatgpt-content-reference{index="16"}[Download the RW0-C-Decision contract-freeze reconciliation prompt](sandbox:/mnt/data/Coordinator_RW0_C_Decision_Contract_Freeze_Reconciliation_V2_Prompt.txt)

```text
Filename:
Coordinator_RW0_C_Decision_Contract_Freeze_Reconciliation_V2_Prompt.txt

Size:
11,876 bytes

SHA-256:
ee42103636f7a5709560a423c879a0647c45a6718706ab8e9c381a71136a11ab
```

The required successful result is:

```text
RW0_C_DECISION_CONTRACT_FREEZE_RECONCILED_READY_FOR_INDEPENDENT_AUDIT
```

After that result:

1. independently audit the migration-`0005` contract freeze;
2. perform a separate implementation-boundary audit;
3. only then issue an implementation prompt.

The terminal-owner track can proceed independently, but it must not create migration `0006` or add generic C-owned physical-reconciliation fields.

## Current project state

```text
RW0-C1:
merged and current

RW0-C-Decision:
architecture accepted; detailed freeze requires one reconciliation

RW0-C-Terminal:
blocked on D/ES owner contracts

migration 0005:
provisional, not implementation-authorized

migration 0006:
not assignable

RW0-D / RW0-E:
not implemented
```

### Sources

- Codex’s decision-freeze and terminal-seam report. :chatgpt-content-reference{index="10"} :chatgpt-content-reference{index="11"} :chatgpt-content-reference{index="12"} :chatgpt-content-reference{index="13"}
- Merged C1 literal membership-page query. 
- Merged C1 rank-14 durable row shape. 

**Confidence:** High on the decomposition and terminal blocker; high that the pagination and rank-14 issues require reconciliation; medium-high on the latch correction pending independent review of the proposed direct-versus-transitive binding.

The current attachment was fully readable. Older expired uploads would need to be re-uploaded only if the next pass needs their contents directly.
