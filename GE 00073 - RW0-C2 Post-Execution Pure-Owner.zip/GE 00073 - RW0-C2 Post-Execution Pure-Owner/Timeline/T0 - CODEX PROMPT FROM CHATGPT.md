PROMPT_ID

RW0_C2_PHASE_LEVEL_ENGINEERING_RECONNAISSANCE_V1

TITLE

Coordinator RW0-C2 — decide the smallest non-disposable durable decision and
terminal capability from the merged RW0-C1 baseline

ENGAGEMENT TYPE

Parent-only, local, read-only architecture and contract reconnaissance.

Do not delegate to subagents.

Do not edit, format, generate, stage, commit, push, create a branch or PR,
merge, tag, release, deploy, fetch, contact a remote/live system, install
dependencies, run migrations against an operator database, invoke a product
worker/model, or inspect/modify supporting repositories.

Do not issue an implementation prompt or implement any part of RW0-C2.

This engagement must make the phase-level engineering decision and identify any
remaining owner seam before an implementation contract can be frozen.

Print the complete substantive report inline. Evidence paths may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED MERGED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized. Use local Git metadata only.

If the baseline differs, stop:

RW0_C2_BASELINE_MISMATCH

CURRENT CONTRACTS TO PRESERVE

Treat these as current merged contracts unless repository inspection proves a
more precise current statement:

1. RW0-B1, RW0-B2-Wire, and RW0-B2-Capability are current private pure
   no-I/O contracts.

2. RW0-C1 is current private durable evidence mechanics:
   - migration `0004_rw0_c1_durable_evidence`;
   - application generation 2;
   - one immutable RW0 phase;
   - exactly 15 typed supplied-evidence kinds;
   - stable membership identity;
   - same-phase relation/profile bindings;
   - receipt-first replay and collision handling;
   - guarded readback;
   - one commit attempt;
   - `committed_exact` / `definitely_not_committed` / `unresolved` recovery;
   - no completeness, decision, latch, terminality, authenticity, permission,
     external contact, process, worker, runtime, or public storage authority.

3. The current SQLite tip is migration 0004. Migrations 0001–0004 are immutable
   historical prefixes for future work.

4. The existing C2B decision grammar remains unchanged unless an owning
   contract proves a contradiction. Do not add or reinterpret a decision kind
   merely to simplify RW0-C2.

5. The RW0 terminal-outcome fact is distinct from:
   - a `development_decision`;
   - an evidence closure;
   - a supplied source observation;
   - executable authority;
   - effect basis;
   - physical cancellation proof.

6. Only the productive direct-local accept decision consumes the one-way
   acceptance latch. The terminal fact binds the committed latch postimage but
   never mutates the latch.

7. Decision-basis closure and terminal-basis closure represent different causal
   moments and may have different member sets, current snapshots, and recovery
   boundaries.

8. C1 membership proves only admitted evidence presence. It does not prove
   evidence completeness, source authenticity, freshness, custody, execution,
   permission, or semantic acceptance.

9. The Wire cancellation-control classifier has no standalone durable identity
   and is not a C1 evidence kind. RW0-C2 may recompute it from exact immutable
   C1/owner operands when a private transient manifest is available and bind an
   operation-time attestation if required by the owning contract.

10. RW0-D owns later physical custody, transport, process, provider,
    supervisor, cancellation-delivery, capsule, teardown, and offline proof
    mechanics.

11. RW0-E owns the separately authorized live qualified-host proof.

12. Execution Substrate retains external admission and runtime authority.

13. No public API, StateStore widening, package export, Bridge path, worker,
    scheduler, service, queue consumer, provider contact, Git effect, or
    publication path is authorized in RW0-C2.

INSPECTION SCOPE

Inspect together, not in isolation:

Governing/current documentation, including at minimum:

- `.docs/rw0-c1-durable-evidence.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-b2-wire-protocol.md`
- `.docs/rw0-b2-capability.md`
- `.docs/c2a-first-slice-semantic-protocol-contract.md`
- `.docs/c2b-durable-development-state.md`
- `.docs/durable-state-model.md`
- `.docs/authority-boundaries.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/software-development-progression-boundary.md`
- `.docs/sqlite-bootstrap-and-migrations.md`
- `.docs/sqlite-operations-and-recovery.md`
- `.docs/sqlite-schema-v1.md`
- `.docs/sqlite-threat-model.md`
- `.docs/writer-session-authority.md`
- `.docs/worker-execution-boundary.md`
- `AGENTS.md`
- `README.md`

Merged C1 source and migration:

- `src/ge_nwp_coordinator/_rw0_c1_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_c1_row_values.py`
- `src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_reader_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
- `src/ge_nwp_coordinator/sqlite_writer_session.py`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql`

Semantic owners and durable owners, including at minimum:

- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py`
- `src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py`
- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py`
- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py`
- `src/ge_nwp_coordinator/_cognitive_proposal_row_values.py`
- existing decision, selection, head, global-stop, writer, reader, transaction,
  and recovery modules that RW0-C2 would have to compose with.

Direct tests for all inspected contracts, including:

- all nine RW0-C1 test modules;
- B1, Wire, cancellation-control, Capability, C2A, C2B decision, Section 41,
  migration, writer-session, transaction, recovery, architecture, status,
  privacy, and runtime-non-authority tests.

Inspection may use local read-only Git/source commands. Do not execute pytest,
migration application, mutation probes, or database writes in this engagement.

FACT CLASSIFICATION

For every substantive conclusion classify it as one of:

- current owning contract;
- current merged implementation;
- compatibility edge;
- reopened target seam;
- strategic target;
- implementation detail;
- report-only uncertainty.

State conflicts explicitly. Do not silently rewrite a current contract into the
target architecture.

ENGINEERING QUESTIONS

1. OBSERVABLE RW0-C2 RESULT

Define the smallest durable, externally useful ability that should exist at the
end of RW0-C2.

It must be described as an observable capability, not as “migration 0005
exists” or “rows are representable.”

At minimum decide whether the final C2 capability must support:

- immutable decision-basis closure over exact C1 memberships and owner rows;
- recomputation/binding of required pure semantic results, including
  cancellation-control when applicable;
- binding to one existing C2B development decision;
- one-way productive direct-local acceptance-latch consumption;
- a separate immutable terminal-basis closure;
- a separate RW0 terminal-outcome fact;
- active-cancel reconciliation;
- exact replay, collision handling, readback, and commit-uncertainty recovery
  for each mutation family.

State what C2 contributes to remote worker contact through semantic decision
and terminal closure.

State what remains blocked until D and E, including physical execution,
delivery, teardown, custody, source authenticity, provider/runtime proof, and
live host qualification.

2. RW0-C2 DECOMPOSITION

Make a fresh decision from the merged baseline.

Explicitly evaluate:

Option A — one C2 implementation tranche:
- decision closure;
- decision binding;
- acceptance latch;
- terminal closure;
- terminal outcome;
- cancellation reconciliation;
- all recovery.

Option B — two independently acceptable durable tranches:

First tranche:
- immutable decision-basis closure;
- evidence-completeness/result projection required for the selected branch;
- binding to the existing C2B decision grammar;
- atomic productive direct-local accept decision plus one-way latch CAS;
- non-accept decisions without latch mutation;
- decision replay/conflict/readback/recovery.

Second tranche:
- immutable terminal-basis closure;
- separate terminal-outcome fact;
- active-cancel reconciled/unresolved/unusable-basis handling;
- accept terminal binding to the already-consumed latch postimage;
- no latch mutation;
- terminal replay/conflict/readback/recovery.

Option C — another split, only if owning-contract dependencies prove that A and
B are both wrong.

Recommend the smallest non-disposable decomposition.

Do not split merely to multiply gates. Do not combine merely because all state
uses SQLite.

Explicitly decide:

- whether decision closure without terminal closure is independently useful;
- whether the latch belongs in the decision tranche;
- whether terminal closure can safely land later without creating ambiguous
  durable truth;
- whether one migration or two migrations should correspond to the engineering
  decomposition;
- whether schema decomposition and implementation-tranche decomposition must
  be identical.

Avoid naming that collides with the existing C2A semantic protocol. Use
temporary descriptive tranche names until the repository naming decision is
made.

3. DECISION-BASIS CLOSURE

Determine the exact logical role of a decision-basis closure.

Address:

- identity;
- phase/K8 binding;
- deterministic ordered membership;
- C1 membership identities versus reusable value identities;
- exact relation/profile bindings;
- current program/work/effect/delivery/global-stop snapshots;
- Section 41 post-execution proposal-family binding;
- evidence membership versus evidence completeness;
- privacy-safe transient inputs;
- closure immutability;
- one decision per closure and whether one closure may be referenced by more
  than one decision;
- replay and collision rules;
- completeness/result projection without source-authenticity claims.

For each existing C2B decision branch, identify the exact required evidence and
proposal binding:

- productive direct-local accept;
- repair;
- replan;
- terminal reject;
- block;
- pre-effect cancellation.

Use the exact current decision-kind/result-variant names from the owning source.
Do not invent approximate names.

Determine whether `attempt_selecting_replan` remains usable and under what
existing prerequisites.

4. ACCEPTANCE LATCH

Freeze the action-specific latch contract.

Determine:

- exact owner;
- initial state and version;
- one-way mutation;
- the exact decision branch that may consume it;
- why only productive direct-local accept is eligible;
- exact candidate/capsule/decision/result bindings;
- CAS preimage and postimage;
- transaction atomicity with the accept decision;
- behavior when unavailable, already consumed, stale, or conflicting;
- replay behavior;
- commit uncertainty and recovery;
- whether any non-accept branch may read, bind, or mutate it;
- how later terminal acceptance binds the postimage without mutation.

Do not let the latch become generic acceptance authority, executable
authorization, or a progression head.

5. TERMINAL-BASIS CLOSURE AND TERMINAL OUTCOME

Define the separate terminal moment.

Address:

- identity;
- relation to phase, decision closure, and committed decision;
- current snapshots at terminal time;
- branch-specific evidence;
- exact RW0 terminal-outcome value/relation reuse from B1;
- one terminal outcome per phase or decision;
- terminal outcome versus development decision;
- terminal outcome versus source observation;
- terminal outcome versus effect basis;
- immutable closure and terminal receipt;
- replay/conflict/readback/recovery;
- absence and unresolved-state handling.

For accept, prove that terminal persistence:

- reads and binds the committed consumed latch postimage;
- never updates the latch;
- cannot fabricate a latch postimage;
- cannot turn a non-accept decision into accept.

6. CANCELLATION BRANCHES

Distinguish all causal stages:

- cancellation decision;
- cancellation request;
- acknowledgement or rejection;
- signal/resource/process observations;
- process exit;
- teardown;
- descendant/process-group reconciliation;
- capsule custody;
- source/route receipts;
- terminal closure.

Evaluate at minimum:

A. Pre-effect cancellation decision.

B. Pre-effect basis unusable:
- original cancellation decision exists;
- mismatch evidence is exact;
- absence of cancel effect/delivery/request/signal is proved;
- terminal outcome is block;
- no replacement cancel or block decision is created.

C. Active cancel reconciled:
- original cancellation decision;
- cancel effect/fence/delivery;
- exact request and response;
- target signal/process/exit evidence;
- later D/ES teardown, descendant, custody, and source reconciliation where
  owning contracts require them;
- terminal outcome cancel.

D. Active cancel unresolved:
- original cancellation decision;
- exact absent/unknown/stale/conflicting classification;
- terminal outcome block;
- no new C2B block decision.

Decide which branches are representable in C2 using supplied fake observations
only and which terminal claims must remain blocked until D/E evidence owners
exist.

Do not treat finite Wire control evidence as semantic cancellation, teardown,
custody, or terminality.

7. ACTION-SPECIFIC PREREQUISITES

For each material prerequisite report:

- exact action it blocks;
- owning contract, missing evidence dependency, or proposed engineering
  precaution;
- must settle before the first C2 tranche, before the later C2 tranche, or only
  before D/E;
- whether it is a stop condition.

At minimum cover:

- external verifier authenticity versus durable recording of a supplied claim;
- evidence membership versus completeness;
- C1 admission-time attestation versus operation-time recomputation;
- private transient manifest availability;
- current-head and global-stop snapshots;
- Section 41 proposal-family state;
- decision grammar and result variants;
- productive direct-local route qualification;
- latch availability;
- cancellation request/response/process facts;
- teardown/custody/source reconciliation;
- exact recovery after uncertain commit;
- absence proofs without hidden truth.

8. C1/B1/B2/C2A/C2B/SECTION 41 REUSE LEDGER

Produce an exhaustive owner-reuse ledger.

For every reused value/relation/reader/state family identify:

- owner;
- exact identity/version;
- C2 use;
- full durable projection, ref/digest binding, or transient operand;
- whether recomputable;
- authority nonclaim.

Include:

- C1 phase, membership, relation, typed-value, page, receipt, graph, and
  recovery readers;
- B1 terminal-outcome value and relations;
- Wire NWPF and cancellation-control profiles/classifiers;
- Capability evidence;
- C2A observations/fences/deliveries/capsule semantics;
- C2B decisions/results/heads/receipts;
- Section 41 post-execution proposal families;
- program/work/effect/delivery/global-stop current state;
- writer/transaction/recovery machinery.

Any required change to a merged B1, B2, C1, C2A, C2B, or Section 41 identity,
field meaning, relation, budget, profile, ownership rule, or reader contract
must be reported as downstream semantic churn and treated as a stop condition,
not hidden as an ordinary C2 compatibility edit.

9. LOGICAL DURABLE FACTS AND MIGRATION STRATEGY

Do not prematurely choose table names. First define the minimal logical facts
and mutable singleton(s).

At minimum assess:

- decision closure;
- decision-closure members;
- decision binding/result;
- acceptance latch;
- terminal closure;
- terminal-closure members;
- cancellation reconciliation/mismatch projection;
- terminal outcome;
- mutation receipts;
- recovery projections.

Decide:

- whether the latch is the only new mutable singleton;
- whether any new progression or phase head is justified;
- whether closures and outcomes are immutable;
- whether C2 should be migration 0005 only or a 0005/0006 sequence;
- whether one schema migration can safely support two implementation tranches;
- seed requirements;
- application generation compatibility;
- cumulative-schema authority;
- migration-prefix compatibility;
- why existing migrations 0001–0004 remain byte-exact.

Reject generic JSON/BLOB payloads and hidden closure truth.

If exact physical schema cannot yet be frozen, state the missing owner decision
rather than inventing counts.

10. TRANSACTIONS, REPLAY, AND COMMIT UNCERTAINTY

For every proposed mutation family define:

- command preflight;
- operation guard;
- mutation slot;
- connection and BEGIN authority;
- schema/binding validation;
- writer fence;
- receipt-first replay;
- current reads;
- closure reconstruction;
- owner relation/classifier invocation;
- write ordering;
- latch CAS where applicable;
- receipt-last publication;
- capability invalidation;
- one commit attempt;
- outer close proof;
- `commit_outcome_unknown`;
- recovery under a fresh fenced writer.

Determine the minimum mutation families. Evaluate whether closure creation and
decision binding must be atomic, and whether terminal closure/outcome must be
atomic.

For each family define `committed_exact`, `definitely_not_committed`, and
`unresolved` proof requirements.

No same-writer automatic retry. No external I/O inside a transaction.

11. AUTHORITY AND PRIVACY

Define:

- values safe for full durable projection;
- values restricted to ref/digest or bounded safe binding;
- transient private operands;
- material never stored.

Explicitly prohibit:

- raw WorkSpec or selected-plan content;
- capsule entries or raw capsule bytes;
- private artifacts;
- credentials, bearers, signatures, trust roots;
- endpoint/host/workspace/account secrets;
- prompts, transcripts, model reasoning/responses;
- stdout/stderr/provider/session logs;
- process handles or runtime-control objects.

Persistence proves only Coordinator committed a validated representation. It
does not prove source authenticity, custody, permission, execution, or external
authorization.

12. ASSURANCE ARCHITECTURE

Design finite acceptance evidence for the actual C2 capability.

Permanent repository tests own finite:

- schema;
- typed values;
- closure identity;
- completeness/result rules;
- decision binding;
- latch atomicity;
- terminal separation;
- cancellation branches;
- transaction ordering;
- replay/conflict;
- commit uncertainty/recovery;
- privacy;
- public/authority non-widening.

Independent audit owns:

- patch provenance;
- migration/resource identities;
- adversarial transaction faults;
- closure/member mutants;
- latch CAS mutants;
- decision/terminal branch mutants;
- source/privacy inspection;
- clean/live validation.

Do not import the RW0-B2 G5–G18 self-protecting evidence-harness architecture.
Permanent tests must not defend themselves against equal-authority mutation.

Keep these defect classes distinct:

- candidate defect;
- contract/authority defect;
- test/oracle defect;
- audit-harness defect;
- report defect;
- environment defect.

For each proposed check state the exact product claim it supports.

13. FORECASTS AND STOP CONDITIONS

Give two or three falsifiable forecasts covering:

- likely schema/transaction contradictions;
- likely semantic churn after freeze;
- likely migration/touched-file scope;
- likely audit finding classes.

State evidence that would require architectural replanning rather than ordinary
implementation repair.

Do not use unsupported numerical confidence percentages.

14. TOUCHED-SURFACE FORECAST

Do not produce an implementation allowlist yet unless the logical contract is
fully closed.

Give a path-derived forecast of:

- likely new owner document;
- likely migration resource(s);
- likely private value/row/reader/persistence modules;
- likely transaction/writer integration;
- likely new tests;
- likely current-status/catalog/inventory updates;
- protected semantic-owner and public surfaces.

Separate:

- must change;
- may change pending contract decision;
- protected.

Any exact ceiling must be labeled provisional until a dedicated implementation-
contract freeze verifies every consumer and source-hash oracle.

STOP CONDITIONS

Stop and return an explicit architectural/owner finding if any of these is
required:

- new or reinterpreted C2B decision kind/result variant;
- changed B1 terminal-outcome meaning;
- changed B1/B2/C1/C2A identity or relation;
- persisted cancellation-control classification as a C1 fact;
- generic mutable evidence-completeness head;
- more than one acceptance latch;
- latch mutation outside productive direct-local accept;
- terminal transaction mutating the latch;
- second authoritative progression head;
- external I/O inside a transaction;
- public API or production caller;
- D/E/ES physical authority absorbed into C2;
- inability to prove exact three-way recovery;
- closure that conflates decision and terminal moments;
- raw/private material required in SQLite.

RETURN

Return:

1. baseline and inspection boundary;
2. current-contract versus strategic-target distinctions;
3. observable RW0-C2 capability;
4. recommended decomposition and acceptance boundary;
5. decision-basis closure contract;
6. acceptance-latch contract;
7. terminal-basis closure and terminal-outcome contract;
8. cancellation branch model;
9. action-specific prerequisite matrix;
10. exhaustive owner-reuse ledger;
11. logical durable facts and migration strategy;
12. transaction/replay/recovery model;
13. authority/privacy boundary;
14. assurance architecture;
15. forecasts and stop conditions;
16. provisional touched-surface forecast;
17. unresolved owner seams;
18. recommended next contract-freeze step.

Do not issue an implementation prompt.

Use the token:

RW0_C2_PHASE_LEVEL_ENGINEERING_DECISION_READY

only if the phase-level operating model is internally coherent and no owner
reconciliation must precede the next contract-freeze pass.

Otherwise return a precise blocking token and identify the owner tranche that
must precede RW0-C2.

Required statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
RW0_C2_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
