PROMPT_ID

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V3_SOURCE_GROUNDING_REPAIR_V1

TITLE

Coordinator RW0 — repair the canonical owner package against the merged source:
host qualification fields, non-temporal C1 relations, V40 nested closure,
source-owner modules and locators, explicit future-recovery deferral, and finite
assurance completeness

ENGAGEMENT TYPE

Parent-only, local, repository-read-only canonical-package correction.

Do not delegate to subagents or internal audit agents.

Do not edit repository files, format repository files, stage, commit, push,
create a branch or PR, merge, tag, release, deploy, fetch, contact a remote or
live system, install dependencies, execute repository tests, run migrations,
open or mutate an operator database, invoke a product worker/model, or
inspect/modify supporting repositories.

You MAY create files only in one fresh private external temporary root for
bounded source inspection and package reconstruction. Remove disposable
intermediate files before closeout.

Return the revised package through the client-visible attachment mechanism. A
path under `/private/tmp`, `/tmp`, or another local filesystem is not a
deliverable.

Do not issue an implementation prompt.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V3_BASELINE_MISMATCH

FIXED INPUTS

Attach exactly:

1. `RW0_Post_Execution_Canonical_Audit_Package_V2.jsonl`
2. `RW0_Post_Execution_Canonical_Owner_Contracts_Independent_Audit_Block_Report.txt`

Package V2 must match exactly:

size:
1659938 bytes

SHA-256:
795bb89f707d29282fbb4bc569fffd4f68d0930d30707ce67522fe8f8660520f

logical records:
615

final newline:
absent

content aggregate:
af3d1eaae0c78e5e21326abcc869c3c0af8c2dafea29a89a7932ce14bf9319d1

Audit report must match exactly:

size:
28120 bytes

SHA-256:
e2517399fee26ca4cc14aa97c662bda32bc3b7af27fd3e7789509d0ef0633367

logical lines:
592

final newline:
absent

opening:
# Verdict

verdict:
BLOCK

closing section:
# Confidence

If either fixed input differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V3_FIXED_INPUT_MISMATCH

AUDIT FINDINGS TO CLOSE

Close exactly:

- RW0-AUDIT-001 — current host-qualification fields/module are wrong;
- RW0-AUDIT-002 — four rank-12 C2A observation relations incorrectly carry
  non-null `evaluated_at`;
- RW0-AUDIT-003 — V40.n01 literal nested profile omits `schema_id`;
- RW0-AUDIT-004 — V35–V37 falsely suggest a complete future committed-recovery
  grammar;
- RW0-AUDIT-005 — finite assurance omits the material source, temporal,
  paging, snapshot, resupply, and non-widening mutations;
- RW0-AUDIT-006 — GlobalStopState owner module/digest posture is wrong;
- RW0-AUDIT-007 — three source-owner module names are wrong;
- RW0-AUDIT-008 — migration-0003 evidence binding row is composite-located,
  not located by `evidence_ref`.

STRATEGIC DISPOSITION

Findings 001, 002, 003, 006, 007, and 008 require direct source-grounded
correction.

Finding 005 requires a larger but still finite ordinary assurance corpus.

Finding 004 must be resolved by explicit deferral, not by prematurely freezing
migration-0005 command/result/receipt/recovery schemas.

V35–V37 are not part of the migration-free pure-owner implementation boundary.
Retire their current normative schemas and goldens. Preserve only the logical
future obligation as an explicit remaining seam. Do not invent physical future
tables or an exhaustive recovery family before the authoritative branch
evaluator and neutral C2B basis exist.

PRESERVED DECISIONS

Do not reopen:

1. V40 operational reviewer separation.
2. Validation/review source values are current C2A `WorkerObservationV1`.
3. Requirement identity uses `requirement_ref + safe_evidence_digest`.
4. Rank 14 uses the current generic C1 relation row.
5. Candidate safe projection preserves the current SHA-1 owner domain and
   excludes private entries.
6. Policy/risk matrices are owner-authored supplied attestations.
7. FiniteBacklog remains only a versioned adapter behind generic risk.
8. Two-context model, Section 41 projection V2, role-resolution V3, exact
   resupply, capsule privacy, membership closure, and bounded current snapshot.
9. Exactly 15 C1 kinds.
10. No migration, persistence, public API, runtime behavior, progression write,
    latch, terminal, D/E, or Execution Substrate behavior.

CORRECTION A — HOST QUALIFICATION OWNER

Rebuild `source-owner.host-qualification` against:

module:
`ge_nwp_coordinator._rw0_phase_entry_semantic_values`

class:
`RW0EffectHostQualificationV1`

Use the exact current fields:

```text
required_worker_artifact_ref
required_worker_artifact_digest
required_worker_protocol_ref
required_worker_protocol_digest
```

Do not use:

```text
required_worker_artifact_profile_ref
required_worker_artifact_profile_digest
required_worker_protocol_profile_ref
required_worker_protocol_profile_digest
```

Use every other exact current owner field and relation unchanged.

Regenerate the validation and review host-qualification golden values from the
current owner constructor. Independently recompute their self-digests.

The audit's expected corrected digests are cross-checks only:

```text
validation:
307dcc7ac6f2222f8729a1491797e0214f72190ee103cf0ada8ea9ab8006a4dc

review:
971eb49f780922384eda949e7ecbaaae67554d4c6cb750a6b7b5fe46ddfd05dc
```

Cascade through:

- V38/V39;
- validation/review support sets;
- V14/V15;
- role supplies;
- complete evidence supply;
- T1 context;
- model-input binding;
- source invocation and proposal family;
- Section 41 projection/rank-15/role resolutions;
- closure/snapshot/currentness values that remain current;
- malformed vectors;
- supersession ledger;
- package manifest and closeout.

Replace the nonexistent import edge to `_rw0_semantic_values.py` with the exact
current module edge.

CORRECTION B — NON-TEMPORAL RANK-12 RELATIONS

The relation schema:

```text
governed-execution.nwp-rw0-c1-c2a-worker-observation-relation.v1
```

is in the current non-temporal relation registry.

For these four current golden relation rows:

```text
golden.owner.author-rank12.000.relation
golden.owner.author-rank12.001.relation
golden.owner.author-rank12.002.relation
golden.owner.review-rank12.relation
```

set:

```text
evaluated_at = null
```

Preserve the relation refs and exact current operands.

Independently reconstruct using the current C1 relation-value contract and
migration-0004 checks.

Use the audit's expected relation digests as cross-checks:

```text
ff1de622d161b73fd0cd45fe26d80660d92ead8df40c44055b731267a1ad64e5
fb0118fccb6af48ff606e1067ef6ff726cc0400030dc703ad18b40fd1eb4cfb3
26455b56b10cd03745e307f902af014af90d3cc22f8d251813e8fd0cc05211d2
9f9055ab4044d52c7182c407da3a78ca184137674fbbfa6b8e04cdd1096ac2f7
```

Recompute rather than trusting those strings.

Cascade through:

- relation row digests;
- relation-set digests;
- memberships;
- admission graphs;
- rank-13 worker result;
- rank-14 classification binding;
- V40 locators/value/profile;
- validation/review dispositions and supports;
- evidence supply;
- T1 and Section 41 family;
- C1 closure and current snapshot;
- all current downstream decision-input values;
- supersessions and package envelope.

Add a package-wide guard:

```text
for every current C1 relation row:
  relation_schema_id in current non-temporal registry -> evaluated_at is null
  relation_schema_id in current temporal registry -> evaluated_at has the exact
  owner-defined timestamp posture
```

CORRECTION C — V40 NESTED PROFILE CLOSURE

In:

```text
behavior-profile.post-execution-reviewer-separation-evaluation.v1
```

the literal nested `author_observation_locator.fields` must equal the complete
V40.n01 schema fields exactly.

Add as the first nested field:

```text
schema_id
```

with the literal constant:

```text
governed-execution.nwp-post-execution-reviewer-separation-author-observation-locator.v1
```

Do not treat a metadata property named `schema_id` as a field declaration.

Regenerate:

- the V40 behavior profile digest;
- V40 golden value ref/digest;
- V15 profile/value and support;
- supplies/T1/model binding;
- Section 41 family and role resolutions;
- current downstream decision-input values;
- all supersessions and package envelope.

Add an automated package-wide nested contract check:

```text
every nested value schema:
  exact field set equals literal nested profile fields
  exact field order equals
  literal schema constant equals
  nullability/type/enum rules equal
```

CORRECTION D — EXPLICITLY DEFER FUTURE COMMITTED RECOVERY

Retire these records from current normative truth:

```text
value-schema.V35.rw0cdecisionevaluationcommandv1
value-schema.V36.rw0ccommittedrecoverymemberv1
value-schema.V37.rw0ccommittedrecoverymanifestv1

golden.V35.primary
golden.V36.primary
golden.V37.primary

module-allocation.V35
module-allocation.V36
module-allocation.V37
```

Also retire the nine current equality records:

```text
equality.05.future_safe_retention.candidate_capsule
equality.06.future_safe_retention.worker_result
equality.07.future_safe_retention.validation_result
equality.08.future_safe_retention.independent_review
equality.09.future_safe_retention.standing_policy
equality.10.future_safe_retention.risk_lane
equality.11.future_safe_retention.authority_currentness_attestation
equality.12.future_safe_retention.global_stop
equality.13.future_safe_retention.effect_ceiling
```

Do not renumber V01–V44. Reserve V35–V37 as unallocated future IDs.

Add explicit supersession entries for every retired current identity.

Replace `remaining-seam.S002` with a precise non-normative obligation:

```text
future RW0-C decision command/result/receipt/committed-recovery owner not frozen

before a future implementation boundary, the owner must define retention of
full safe values or immutable locators for:
- selected Section 41 projection and rank-15 family;
- all nine role-resolution results;
- proposal-time safe values;
- V25 membership closure;
- V27 current snapshot;
- V29 proposal-currentness result;
- V31 authority matrix;
- V32 global-stop matrix;
- V33 source-effect ceiling matrix;
- V34 recommendation-consistency result;
- authoritative branch evaluation/attestation when frozen;
- neutral C2B basis and progression result/receipt when frozen;
- outer result/receipt/recovery selectors.

Opaque aggregate digests alone are insufficient.
No schema, ref, digest, module, or physical table is frozen now.
```

The migration-free pure-owner implementation boundary must explicitly exclude
V35–V37.

Do not claim that future committed recovery is complete in this package.

CORRECTION E — GLOBAL STOP SOURCE OWNER

Rebuild `source-owner.global-stop` against:

module:
`ge_nwp_coordinator.global_stop`

class:
`GlobalStopState`

Exact owner fields:

```text
schema_id
version
active
stop_id
reason_class
issuer_ref
issued_at
operator_decision_ref
```

Exact current derived properties:

```text
stop_ref = stop_id when active else global-stop-clear
status = active | clear
```

Exact digest posture:

```text
canonical_digest() = raw SHA-256 of the canonical owner mapping
```

Do not claim owner fields named:

```text
global_stop_ref
global_stop_digest
```

and do not invent a domain-separated owner identity.

V20 may retain a projection field called `global_stop_digest` only if the
contract says explicitly that it is the captured raw return value of the
owner's `canonical_digest()`, not a stored owner field or domain-separated
self-digest.

The existing correct V20 raw digest may be preserved only after independent
reconstruction.

CORRECTION F — EXACT SOURCE MODULES AND EVIDENCE-ROW LOCATOR

Use exact current modules:

```text
ModelProposalEvidenceSetV1:
ge_nwp_coordinator._cognitive_proposal_semantic_values

DevelopmentValidationRequirementEvidenceV1:
ge_nwp_coordinator._development_author_effect_establishment_contracts

DevelopmentReviewRequirementEvidenceV1:
ge_nwp_coordinator._development_author_effect_establishment_contracts
```

Update corresponding import edges and source-owner records.

For migration-0003 proposal evidence rows:

- owner module remains
  `ge_nwp_coordinator._cognitive_proposal_row_values`;
- the immutable row locator is exactly:
  `(proposal_ref, evidence_role, ordinal)`;
- `evidence_binding_digest` is the row self-digest;
- `evidence_ref` identifies the bound evidence value, not the binding row;
- do not synthesize a binding-row ref;
- align the source-owner record with role-resolution V3.

Reverify all 23 source-owner records after these changes. Do not assume the
remaining sixteen are correct merely because the prior audit passed them.

CORRECTION G — FINITE ASSURANCE COMPLETION

Add ordinary finite assurance cases and malformed/substitution vectors for at
least:

Current source grounding:
1. host module substitution;
2. `required_worker_artifact_*` changed to nonexistent profile fields;
3. `required_worker_protocol_*` changed to nonexistent profile fields;
4. GlobalStopState wrong owner module;
5. owner raw digest replaced by a domain-separated digest;
6. evidence-set owner module substitution;
7. validation/review requirement owner module substitution;
8. evidence-binding row addressed by `evidence_ref` instead of the composite
   locator.

Temporal relations:
9. non-temporal rank-12 relation with non-null `evaluated_at`;
10. temporal relation with null or wrong owner timestamp;
11. rank-12 relation digest/row/set/membership cascade not updated.

Nested profile:
12. V40.n01 missing `schema_id`;
13. V40.n01 field reorder;
14. nested type/nullability/profile mismatch.

Resupply:
15. exact resupply absent -> `no_decision`;
16. exact resupply present but schema/ref/digest/bytes mismatch ->
    `basis_conflict`;
17. candidate manifest absent at decision;
18. candidate manifest wrong bytes/ref/digest/schema/phase.

Membership paging:
19. duplicate entry;
20. non-monotonic cursor;
21. reordered page;
22. no cursor progress;
23. overflow;
24. premature termination;
25. continuation-page substitution;
26. capability-epoch or phase change during closure construction.

Current snapshot:
27. selected rank-1 membership substitution;
28. selected rank-15 membership substitution;
29. external current-source coordinate substitution;
30. phase/K8 mismatch;
31. missing required current row;
32. malformed current row;
33. unrelated extra database state leaves the bounded snapshot unchanged.

Non-widening:
34. package-root export;
35. public StateStore method;
36. public WriterSession protocol method;
37. migration or SQL resource addition;
38. production caller/importer;
39. direct SQLite/connection authority in a new pure module;
40. filesystem/network/process/provider I/O.

Future recovery deferral:
41. V35–V37 imported by the current pure-owner tranche;
42. forecast-only schema/golden/equality reintroduced as current truth;
43. opaque-digest-only recovery presented as complete.

Each case must name:
- claim;
- literal control;
- exact one-predicate mutation;
- expected finite failure or contract classification;
- permanent-test responsibility;
- independent-audit responsibility.

Do not create a self-protecting test framework.

PACKAGE V3 DELIVERABLE

Attach exactly one revised file:

```text
RW0_Post_Execution_Canonical_Audit_Package_V3.jsonl
```

Use the same canonical JSONL envelope and closed record types.

It is acceptable for record counts to decrease because V35–V37 and the nine
future-retention equalities are retired.

Preserve relative order for unchanged records where practical, but semantic
correctness and closed record-type ordering take precedence.

Add supersession entries for every replaced or retired current identity.

No stale wrong module, host field, temporal relation digest, V40 profile digest,
or retired recovery identity may appear in current profiles/goldens/equalities.

MECHANICAL VERIFICATION

Before success:

1. Repeat every original package mechanic check.
2. Independently instantiate/reconstruct every current-owner golden value where
   a current owner exists.
3. Validate every current relation row against migration-0004 branch checks.
4. Reproduce all refs, self-digests, relation/row/set/membership/admission
   digests, support sets, profiles, T1, proposal family, Section 41 projection,
   rank-15, role resolutions, closure, and snapshot.
5. Verify every primary and nested schema/profile field set and order.
6. Verify every source-owner module exists at the exact baseline.
7. Verify every source-owner locator is executable and bounded as claimed.
8. Verify the retired recovery records are absent from current truth and present
   only in supersession/seam records.
9. Verify the expanded assurance inventory.
10. Verify manifest, aggregate, closeout, whole-file hash, and repository
    cleanliness with two independent local readers/hashes.

INLINE REPORT

Print:

- disposition for RW0-AUDIT-001 through RW0-AUDIT-008;
- exact filename, size, SHA-256, records, final-newline posture;
- per-type counts and content aggregate;
- changed and retired record IDs;
- supersession entries added;
- assurance-case and malformed-vector counts;
- confirmation that V35–V37 are reserved but not current normative values;
- confirmation that the revised file is visibly attached;
- confirmation that no private path is offered as the deliverable;
- success token.

SUCCESS TOKEN

Return exactly:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V3_REPAIRED_READY_FOR_INDEPENDENT_AUDIT

only if:

- all eight audit findings are closed according to the dispositions above;
- V3 is visibly attached;
- all verifications pass;
- repository state remains unchanged;
- no implementation prompt is issued.

Otherwise return:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V3_REPAIR_BLOCKED

and classify the blocker as:

- fixed-input mismatch;
- source-owner contradiction;
- semantic contradiction;
- regeneration failure;
- canonical verification failure;
- attachment mechanism unavailable;
- baseline mismatch.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
