Here is Codex's response:

# Baseline and fixed input

[current merged implementation] The required local baseline matches exactly, without fetch or remote contact.

| Item | Observed |
|---|---|
| Branch | `trunk_dev` |
| HEAD | `a3ff0b7f4f0c2378c2962e24612d605489b51638` |
| Tree | `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0` |
| Sole parent | `047563de5a443b0f8323401c92979ae2e444d2ed` |
| Subject | `feat: implement RW0-C1 durable evidence (#7)` |
| Upstream | `origin/trunk_dev` |
| Ahead/behind | `0/0` |
| Worktrees | `1` |
| Worktree/index/untracked/unmerged | clean |

[implementation-detail observation] The fixed input report at [RW0_Post_Execution_Context_Identity_and_Value_Grammar_Reconciliation_Report.txt](</Users/ds/Downloads/RW0_Post_Execution_Context_Identity_and_Value_Grammar_Reconciliation_Report.txt>) also matches:

- Size: `165888` bytes
- SHA-256: `8dd26efd25333cd49acc0fe7b64d9b7b05495176e3d5b4f377fa42f8cf60ba58`
- Logical lines: `1026`
- Final newline: absent
- Opening: `# Baseline and fixed input`
- Final substantive status token: `RW0_POST_EXECUTION_CONTEXT_IDENTITIES_AND_VALUE_GRAMMARS_RECONCILED_READY_FOR_INDEPENDENT_AUDIT`

Parent-only execution was maintained. No subagent or internal audit agent was used.

# Preserved decisions

[proposed post-execution evidence owner contract]

1. The accepted two-context design remains:

   - `Section41PostExecutionSemanticReviewLineageContextV1`
   - `PostExecutionSemanticReviewInputContextV1`

2. The migration-0003 source/proposal seam continues to reference the T1 input context. The lineage context remains its nested pure operand.
3. Section 41 projection V2 and role-resolution V3 remain the proposed versions.
4. C1 remains exactly 15 kinds. No existing B1, B2, C1, or C2A schema or relation meaning changes.
5. Exact proposal-time evidence, T1/model-input equality, exact resupply, capsule privacy, exhaustive membership closure, bounded current snapshot, and the pure-versus-forecast boundary remain.
6. Validation and review dispositions bind current C2A `WorkerObservationV1` values; they do not replace or reinterpret them.
7. FiniteBacklog remains a compatibility adapter behind the generic risk interface.
8. No migration, persistence, public API, runtime behavior, external contact, progression write, terminal behavior, D/E behavior, or ES behavior is introduced.

# Current C2A validation/review source binding

[current owning contract] Both source observations are the exact current class and schema:

```text
WorkerObservationV1
governed-execution.nwp-worker-observation.v1
digest domain:
governed-execution.nwp-worker-observation.v1.identity
```

The complete required fields are:

```text
schema_id
observation_ref
source_kind
source_ref
source_invocation_ref
delivery_attempt_ref
program_ref
program_version_ref
accepted_intent_revision_ref
work_item_ref
work_item_revision_ref
semantic_attempt_ref
effect_intent_ref
command_ref
command_digest
attempt_fence_ref
attempt_fence_digest
effect_fence_ref
effect_fence_digest
observation_kind
outcome
reason_code
evidence_refs
observed_at
observation_digest
```

The only optional fields are:

```text
candidate_ref
capsule_manifest_ref
portable_capsule_digest
process_exit_code
```

For the two relevant kinds, the exact branches are:

| Use | `source_kind` | `observation_kind` | Outcomes | Required conditional fields | Forbidden conditional field | Required effect class |
|---|---|---|---|---|---|---|
| Validation | `validator` | `validation_completed` | `passed`, `failed`, `inconclusive`, `not_run` | `candidate_ref`, `capsule_manifest_ref`, `portable_capsule_digest` | `process_exit_code` | `validate_candidate` |
| Independent review | `independent_reviewer` | `independent_review_completed` | `passed`, `failed`, `inconclusive` | `candidate_ref`, `capsule_manifest_ref`, `portable_capsule_digest` | `process_exit_code` | `review_candidate` |

Additional current constraints:

- `evidence_refs` is a sorted, duplicate-free list of at most 32 safe refs.
- `reason_code` matches `[a-z][a-z0-9_.-]{0,95}`.
- `provably_not_accepted` is reserved to `delivery_rejected`.
- Observation digest excludes only `observation_digest`.
- The observation must equal its delivery, command, attempt fence, effect fence, candidate, and capsule operands across every shared field.

The invented schemas are withdrawn:

```text
governed-execution.nwp-validation-source-observation.v1
governed-execution.nwp-independent-review-source-observation.v1
```

They may not appear in any current role entry, source-binding triple, supply, profile, or golden value.

[proposed post-execution evidence owner contract] The disposition relation is now exact:

- `source_observation_schema_id` equals `governed-execution.nwp-worker-observation.v1`.
- Source ref/digest equals the supplied observation.
- `source_outcome` equals the observation outcome.
- Program, version, accepted intent, work, revision, semantic attempt, effect intent, command, attempt fence, effect fence, candidate, capsule ref, and portable capsule digest are equal.
- Validation `author_role=validator`; review `author_role=independent_reviewer`.
- `author_ref=source_ref`.
- `author_invocation_ref=source_invocation_ref`.
- Tool profile pairs come from the matching current `RW0EffectHostQualificationV1`.
- Requirement pairs come from the matching current development requirement-evidence value.
- The new result-set and independence values are supplied by their named owner and validated; RW0-C and the model may not fabricate them.

Validation’s closed semantic tuples are:

```text
source outcome | result                  | repairability              | reason
passed         | passed                  | not_applicable             | validation_passed
failed         | repairable_failure      | repairable                 | validation_failed_repairable
failed         | replan_required         | same_attempt_insufficient  | validation_failed_replan_required
failed         | terminal_failure        | nonrepairable              | validation_failed_terminal
failed         | unknown                 | unknown                    | validation_failed_unclassified
inconclusive   | unknown                 | unknown                    | validation_inconclusive
not_run        | not_run                 | not_applicable             | validation_not_run
```

Review’s closed semantic tuples are:

```text
source outcome | independence    | result            | reason
passed         | independent     | passed            | review_passed
failed         | independent     | repair_required   | review_failed_repair_required
failed         | independent     | replan_required   | review_failed_replan_required
failed         | independent     | terminal_reject   | review_failed_terminal_reject
failed         | independent     | unknown           | review_failed_unclassified
inconclusive   | independent     | unknown           | review_inconclusive
any valid      | unknown         | unknown           | review_independence_unknown
any valid      | not_independent | basis_conflict    | review_not_independent
any valid      | conflict        | basis_conflict    | reviewer_independence_conflict
```

Any other tuple is rejected as `outcome_disposition_mismatch`.

# Current C1 worker-result relation binding

[current merged implementation] Rank 14’s typed value is:

```text
RW0C1WireProcessResultClassificationBindingV1
governed-execution.nwp-rw0-c1-wire-process-result-classification-binding.v1
```

Its exact identity fields are:

```text
schema_id, value_ref, phase_basis_ref, phase_basis_digest, program_ref,
semantic_attempt_ref, candidate_ref, effect_intent_ref, author_command_ref,
attempt_fence_ref, effect_fence_ref, delivery_attempt_ref,
wire_profile_ref, wire_profile_digest, result_state, result_membership,
result_failure_reason, adapter_observations, request_membership,
process_observations, classification, reason
```

`value_digest` is the domain-separated digest over that mapping.

Exact vocabularies:

- `result_state`: `present | finite_failure | absent`
- `classification=usable`: reason `usable`
- `classification=invalid`: `invalid_input | unrelated_fact | duplicate_fact | conflicting_fact | cancellation_graph_mismatch`
- `classification=unusable`: `resource_limit_exceeded | deadline_elapsed | signal_delivered | cancellation_request_pending | cancellation_acknowledged | cancellation_rejected | process_result_contradiction | process_failed | result_missing | result_invalid | process_evidence_incomplete`

The source-binding value is the existing generic relation row:

```text
relation-binding schema:
governed-execution.nwp-rw0-c1-relation-binding.v1

literal semantic relation ID:
governed-execution.nwp-rw0-c1-wire-process-result-classifier-relation.v1

relation version:
1

NWPF profile:
rw0-wire-nwpf-v1
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
```

Proof mode is:

| `result_state` | Proof mode |
|---|---|
| `present` | `derived_wrapper_recomputable` |
| `absent` | `derived_wrapper_recomputable` |
| `finite_failure` | `relation_attested_at_admission` |

The relation’s mandatory owner operands, in order, are:

```text
author_command
author_delivery
attempt_fence
author_effect_fence
```

A cancellation-bearing classification adds:

```text
cancellation_effect_fence
cancellation_delivery
```

`finite_failure` adds the transient operand:

```text
worker_result_failure / wire_protocol_error
```

The T1 source-binding triple is therefore:

```text
schema = governed-execution.nwp-rw0-c1-relation-binding.v1
ref    = relation_ref
digest = relation_digest
```

The literal classifier relation ID is a field inside that row; it is not a standalone row schema. Exact resupply also verifies `relation_row_digest`, subject membership, subject typed value, profile pair, proof mode, relation version, operand count, and operand-set digest.

The regenerated absent-result golden has:

```text
relation_ref:
rw0-c1-relation.f832ac7a876f6ecf708eda9639c2e1f75429adf7f2b50fa95a8e188269d3f17b

relation_digest:
937530ecaf6e9bc9fc3cc127b89174684f7f1f33b1d41c04b21004233273ba6d

relation_row_digest:
03537ea01893cd664a212edf7b7c03817af891e84dab515f4f5be03cfec83c4c

subject_membership_digest:
ee75dbe615d7a35a39e02f7827857964bc5a525f11db90690ece9a6774fd5899

operand_set_digest:
fb9e1987f285dacc79283cba5b6537c0012588c890edb13951747467e4fd5111

operand_count:
4
```

# Candidate safe-projection owner equality

[current owning contract] `CandidateCapsuleManifestV1` is:

```text
governed-execution.nwp-candidate-capsule-manifest.v1
canonicalization_profile = canonical-json.sorted-keys.utf8.v1
digest_domain = governed-execution.nwp-candidate-capsule-manifest.v1.identity
base_git_object_format = sha1
base_git_oid = [0-9a-f]{40}
```

Its complete fields are:

```text
schema_id, canonicalization_profile, digest_domain, candidate_ref,
capsule_manifest_ref, program_ref, program_version_ref,
accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
semantic_attempt_ref, effect_intent_ref, command_ref, command_digest,
attempt_fence_ref, attempt_fence_digest, effect_fence_ref,
effect_fence_digest, repository_ref, base_git_object_format, base_git_oid,
authorized_path_scope_digest, entries, portable_capsule_digest
```

Its three entries are ordered exactly as:

```text
.docs/system_overview/hybrid_integration_architecture_adr.md
PLANS.md
docs_contract_test.go
```

Each entry has exact path, `operation=replace_regular_file`, mode `100644|100755`, before hash/length, and after hash/length.

[proposed post-execution evidence owner contract] `CandidateCapsuleSafeProjectionV1` retains and requires byte-for-byte equality for:

```text
candidate_ref, capsule_manifest_ref, portable_capsule_digest, program_ref,
program_version_ref, accepted_intent_revision_ref, work_item_ref,
work_item_revision_ref, semantic_attempt_ref, effect_intent_ref, command_ref,
command_digest, attempt_fence_ref, attempt_fence_digest, effect_fence_ref,
effect_fence_digest, repository_ref, base_git_object_format, base_git_oid,
authorized_path_scope_digest
```

It omits `canonicalization_profile`, `digest_domain`, and private `entries`. It adds no owner-domain value. In particular:

```text
base_git_object_format = sha1
base_git_oid = exactly 40 lowercase hexadecimal characters
```

The prior `sha1 | sha256` projection grammar is superseded.

# Complete source/support owner registry

The literal consuming-profile inventories are:

| Consumer | Rank | Support role | Exact schema | Chosen owner |
|---|---:|---|---|---|
| Validation | 1 | `source_observation` | `governed-execution.nwp-worker-observation.v1` | Existing C2A `WorkerObservationV1` |
| Validation | 2 | `disposition_profile` | `governed-execution.nwp-validation-disposition-profile.v1` | New pure profile |
| Validation | 3 | `validation_tool_qualification` | `governed-execution.nwp-rw0-effect-host-qualification.v1` | Current host qualification; owns the nested validation-tool profile pair |
| Validation | 4 | `validation_requirement` | `governed-execution.nwp-development-validation-requirement-evidence.v1` | Current requirement evidence |
| Validation | 5 | `validation_result_set` | `governed-execution.nwp-post-execution-validation-result-set.v1` | New neutral owner value |
| Validation | 6 | `candidate_capsule` | `governed-execution.nwp-candidate-capsule-manifest.v1` | Current C2A manifest |
| Review | 1 | `source_observation` | `governed-execution.nwp-worker-observation.v1` | Existing C2A `WorkerObservationV1` |
| Review | 2 | `disposition_profile` | `governed-execution.nwp-independent-review-disposition-profile.v1` | New pure profile |
| Review | 3 | `review_tool_qualification` | `governed-execution.nwp-rw0-effect-host-qualification.v1` | Current host qualification; owns the nested review-tool profile pair |
| Review | 4 | `review_requirement` | `governed-execution.nwp-development-review-requirement-evidence.v1` | Current requirement evidence |
| Review | 5 | `review_result_set` | `governed-execution.nwp-post-execution-review-result-set.v1` | New neutral owner value |
| Review | 6 | `reviewer_independence` | `governed-execution.nwp-reviewer-independence-attestation.v1` | New neutral owner value |
| Review | 7 | `candidate_capsule` | `governed-execution.nwp-candidate-capsule-manifest.v1` | Current C2A manifest |
| Standing policy | 1 | `policy_source` | `governed-execution.nwp-post-execution-standing-policy-source-attestation.v1` | Opaque supplied attestation |
| Standing policy | 2 | `policy_profile` | `governed-execution.nwp-post-execution-standing-policy-matrix-profile.v1` | New pure profile |
| Standing policy | 3 | `authority_observation_and_parent_grant` | `governed-execution.nwp-rw0-authority-verification-observation.v1` | Current rank-1 owner value, including its parent-grant pair |
| Standing policy | 4 | `source_effect_fence` | `governed-execution.nwp-effect-fence.v1` | Current C2A effect fence |
| Risk | 1 | `risk_source_profile` | `governed-execution.nwp-post-execution-risk-source-profile.v1` | New generic neutral profile value |
| Risk | 2 | `risk_source_binding` | `governed-execution.nwp-post-execution-risk-source-binding.v1` | New generic neutral binding value |
| Risk | 3 | `risk_policy` | `governed-execution.nwp-post-execution-risk-policy-attestation.v1` | Opaque supplied attestation |
| Risk | 4 | `risk_profile` | `governed-execution.nwp-post-execution-risk-lane-matrix-profile.v1` | New pure profile |
| Global stop | 1 | `global_stop_current` | `governed-execution.nwp-global-stop.v1` | Reconstructed current `GlobalStopState` |
| Global stop | 2 | `stop_profile` | `governed-execution.nwp-post-execution-global-stop-profile.v1` | New pure profile |
| Effect ceiling | 1 | `attempt_fence` | `governed-execution.nwp-attempt-fence.v1` | Current C2A attempt fence |
| Effect ceiling | 2 | `effect_fence` | `governed-execution.nwp-effect-fence.v1` | Current C2A effect fence |
| Effect ceiling | 3 | `authority_observation` | `governed-execution.nwp-rw0-authority-verification-observation.v1` | Current rank-1 value |
| Effect ceiling | 4 | `standing_policy_matrix` | `governed-execution.nwp-post-execution-standing-policy-branch-matrix.v1` | Supplied policy-owner matrix |
| Effect ceiling | 5 | `ceiling_profile` | `governed-execution.nwp-post-execution-source-effect-ceiling-profile.v1` | New pure profile |

There is no standalone validation-tool or review-tool `SID`. The exact profile pairs are the current host qualification’s:

```text
required_validation_tool_profile_ref/digest
required_review_tool_profile_ref/digest
```

The complete current host-qualification profile-pair inventory is:

```text
scenario, platform, architecture, worker_artifact, worker_protocol,
execution_identity, process, isolation, resource, cancellation,
credential_handoff, capsule_store, validation_tool, review_tool, cleanup
```

# Policy and risk authorship

[proposed post-execution evidence owner contract] Standing-policy authorship is frozen as follows:

- `PostExecutionStandingPolicySourceAttestationV1` is supplied by the standing-policy owner.
- `PostExecutionStandingPolicyBranchMatrixV1` is also a supplied policy-owner attestation.
- Local code validates canonical identity, profile identity, source-to-matrix equality, parent grant, authority observation, fence relation, branch order, and support set.
- Local code does not recreate external policy meaning.
- A `permit` result is neither executable authorization nor external authority.

The source-to-matrix equality includes policy source schema/ref/digest, author ref/invocation, status, revocation status, parent-grant pair, audience, repository, path scope, allowed branches, lanes, effect classes, ceilings, validity interval, and the five branch assertions.

[proposed post-execution evidence owner contract] Risk authorship is frozen as follows:

- `PostExecutionRiskPolicyAttestationV1` and `PostExecutionRiskLaneBranchMatrixV1` are supplied by the risk-policy owner.
- `PostExecutionRiskSourceProfileV1` and `PostExecutionRiskSourceBindingV1` are the generic neutral interface.
- Local code validates identities and relations; it does not reconstruct external risk meaning.
- The generic binding explicitly carries `development_work_item_ref`.
- A source-specific value remains behind `source_value_schema_id/ref/digest`.
- No generic field contains FiniteBacklog terminology.
- A risk `permit` is non-authoritative.

[compatibility edge] `FiniteBacklogRiskSourceBindingV1` is only one adapter input. It produces the generic source profile/binding. Its `development_work_item_ref` and `backlog_work_item_id` are deliberately independent and need not be equal.

# Global-stop and fence owner identities

[current merged implementation] `GlobalStopState` is:

```text
governed-execution.nwp-global-stop.v1
```

Exact canonical fields:

```text
schema_id, version, active, stop_id, reason_class,
issuer_ref, issued_at, operator_decision_ref
```

Branches:

- `active=false`: all five detail fields are null.
- `active=true`: all five are non-null:

  ```text
  stop_id
  reason_class
  issuer_ref
  issued_at
  operator_decision_ref
  ```

- `reason_class` is exactly `operator_stop | policy_stop | safety_stop`.
- Derived ref is `stop_id` when active and `global-stop-clear` when clear.
- Derived state is `active | clear`.
- Digest is raw SHA-256 of the canonical state mapping, without a domain prefix.

The source row is exactly:

```text
singleton_id, schema_id, version, active, stop_id, reason_class,
issuer_ref, issued_at, operator_decision_ref, updated_at
```

`singleton_id` and `updated_at` belong to the row envelope, not the canonical state mapping.

The corrected proposal snapshot includes:

```text
global_stop_schema_id, global_stop_ref, global_stop_version,
global_stop_state, global_stop_stop_id, global_stop_reason_class,
global_stop_issuer_ref, global_stop_issued_at,
global_stop_operator_decision_ref, global_stop_digest,
global_stop_updated_at
```

[current owning contract] `AttemptFenceV1` uses:

```text
governed-execution.nwp-attempt-fence.v1
base_git_object_format = sha1
base_git_oid = [0-9a-f]{40}
```

Its complete fields are:

```text
schema_id, attempt_fence_ref, parent_standing_grant_ref/digest,
attempt_authorization_ref/digest, program_ref, program_version_ref,
accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
semantic_attempt_ref, repository_ref, base_git_object_format, base_git_oid,
path_ceiling, allowed_effect_classes, aggregate_ceilings, expires_at,
global_stop_ref, global_stop_version, attempt_fence_digest
```

[current owning contract] `EffectFenceV1` uses:

```text
governed-execution.nwp-effect-fence.v1
```

Its complete fields are:

```text
schema_id, effect_fence_ref, parent_standing_grant_ref/digest,
effect_authorization_ref/digest, attempt_fence_ref/digest,
program_ref, program_version_ref, accepted_intent_revision_ref,
work_item_ref, work_item_revision_ref, semantic_attempt_ref,
effect_intent_ref, effect_class, command_ref/digest, candidate_ref,
repository_ref, base_git_object_format, base_git_oid, path_ceiling,
effect_ceilings, expires_at, global_stop_ref, global_stop_version,
portable_capsule_digest, cancellation_target_effect_intent_ref,
cancellation_target_effect_fence_ref,
cancellation_target_effect_fence_digest, effect_fence_digest
```

Effect classes are exactly:

```text
author_candidate
cancel_effect
local_git_commit
review_candidate
validate_candidate
```

The portable-capsule and cancellation-target branches remain exactly as owned:

- `author_candidate`: portable digest null.
- `validate_candidate | review_candidate | local_git_commit`: portable digest non-null.
- `cancel_effect`: all three cancellation-target fields non-null.
- Other classes: all three cancellation-target fields null.

The exact 15 ceiling keys are:

```text
max_active_invocations
max_candidate_bytes
max_changed_files
max_cost_microusd
max_cpu_seconds
max_deliveries
max_deployments
max_local_commits
max_memory_bytes
max_merges
max_model_input_tokens
max_model_output_tokens
max_pull_requests
max_pushes
max_wall_seconds
```

[current merged implementation] `RW0AuthorityVerificationObservationV1` remains:

```text
governed-execution.nwp-rw0-authority-verification-observation.v1
```

Its closed vocabularies are:

```text
status:            verified | denied | unknown
family_status:     compatible | incompatible | unknown
revocation_status: unrevoked | revoked | unknown
global_stop_state: clear | active
base format:       sha1
base OID:          [0-9a-f]{40}
```

It is evidence about parent grant, family, fences, ceilings, expiry, current heads, and stop coordinates. It is never external authority.

# Corrected value-schema and owner matrix

Canonical notation in this section:

```text
R  = exact built-in safe ref: 1..96 ASCII bytes; first alphanumeric;
     remaining characters [0-9A-Za-z.-]; reserved private prefixes rejected
H  = exact built-in string of 64 lowercase hexadecimal characters
T  = exact whole-second UTC timestamp YYYY-MM-DDThh:mm:ssZ
N0 = exact built-in int, never bool, in 0..2^63-1
N1 = exact built-in int, never bool, in 1..2^63-1
B  = exact built-in bool
```

Every `schema_id` below is the displayed literal. Unknown, missing, duplicate, subclassed, or extension fields fail before canonicalization. Canonical JSON uses sorted keys, compact separators, strict UTF-8, no BOM, no NaN, and no Unicode normalization.

Unless explicitly marked owner-supplied, generated refs use:

```text
prefix ||
SHA256(schema_id + ".key" || NUL ||
       canonical_json(fields excluding schema_id, generated ref, self digest))
```

Self-digests use:

```text
SHA256(schema_id + ".identity" || NUL ||
       canonical_json(fields excluding the self digest))
```

Corrected/new exact grammars are:

- `V04 CandidateCapsuleSafeProjectionV1`: the 23 fields listed in the candidate section; format literal `sha1`, OID `[0-9a-f]{40}`.
- `V14 ValidationDispositionV1`, 42 fields:

  ```text
  schema_id, profile_ref/digest, source_observation_schema_id/ref/digest,
  source_outcome, author_role/ref/invocation_ref, program_ref,
  program_version_ref, accepted_intent_revision_ref, work_item_ref,
  work_item_revision_ref, semantic_attempt_ref/digest, attempt_number,
  candidate_ref, effect_intent_ref, capsule_manifest_ref/digest,
  validation_tool_profile_ref/digest,
  validation_tool_qualification_schema_id/ref/digest,
  validation_requirement_schema_id/ref/digest,
  validation_result_set_schema_id/ref/digest,
  result, reason, repairability, evaluated_at, expires_at,
  support_set_ref/digest, disposition_ref/digest
  ```

- `V15 IndependentReviewDispositionV1`, 45 fields:

  ```text
  schema_id, profile_ref/digest, source_observation_schema_id/ref/digest,
  source_outcome, author_role/ref/invocation_ref, program_ref,
  program_version_ref, accepted_intent_revision_ref, work_item_ref,
  work_item_revision_ref, semantic_attempt_ref/digest, attempt_number,
  candidate_ref, effect_intent_ref, capsule_manifest_ref/digest,
  review_tool_profile_ref/digest,
  review_tool_qualification_schema_id/ref/digest,
  review_requirement_schema_id/ref/digest,
  review_result_set_schema_id/ref/digest,
  reviewer_independence_schema_id/ref/digest, independence_status,
  result, reason, evaluated_at, expires_at,
  support_set_ref/digest, disposition_ref/digest
  ```

- `V17 PostExecutionStandingPolicyBranchMatrixV1`, 41 fields:

  ```text
  schema_id, matrix_ref, profile_ref/digest, proposal_phase,
  program_ref, program_version_ref, accepted_intent_revision_ref,
  work_item_ref, work_item_revision_ref, semantic_attempt_ref,
  candidate_ref, effect_intent_ref, author_command_ref,
  matrix_author_ref, matrix_author_invocation_ref,
  policy_source_schema_id/ref/digest, policy_status,
  policy_revocation_status, parent_grant_ref/digest, audience_ref,
  repository_ref, path_scope_digest, risk_lane,
  source_effect_fence_ref/digest, source_effect_class,
  allowed_branches, allowed_risk_lanes, allowed_effect_classes,
  policy_ceilings, not_before, expires_at, evaluated_at,
  entries, support_set_ref/digest, matrix_digest
  ```

  `matrix_ref` is owner-supplied, not locally generated.

- `V18 PostExecutionRiskLaneBranchMatrixV1`, 36 fields:

  ```text
  schema_id, matrix_ref, profile_ref/digest, proposal_phase,
  program_ref, program_version_ref, accepted_intent_revision_ref,
  development_work_item_ref, work_item_revision_ref, semantic_attempt_ref,
  candidate_ref, author_command_ref, matrix_author_ref,
  matrix_author_invocation_ref, risk_lane,
  source_profile_schema_id/ref/digest,
  source_binding_schema_id/ref/digest,
  risk_policy_schema_id/ref/digest, policy_status,
  policy_revocation_status, allowed_risk_lanes, required_risk_lane,
  not_before, expires_at, evaluated_at, entries,
  support_set_ref/digest, matrix_digest
  ```

  `matrix_ref` is owner-supplied.

- `V20 PostExecutionGlobalStopSnapshotV1`, 19 fields:

  ```text
  schema_id, profile_ref/digest, global_stop_schema_id/ref/version/state,
  global_stop_stop_id, global_stop_reason_class, global_stop_issuer_ref,
  global_stop_issued_at, global_stop_operator_decision_ref,
  global_stop_digest, global_stop_updated_at, evaluated_at,
  support_set_ref/digest, snapshot_ref/digest
  ```

- `V21 PostExecutionSourceEffectCeilingEvidenceV1`, 47 fields:

  ```text
  schema_id, profile_ref/digest, proposal_phase, program_ref,
  program_version_ref, accepted_intent_revision_ref, work_item_ref,
  work_item_revision_ref, semantic_attempt_ref, candidate_ref,
  effect_intent_ref, repository_ref, base_git_object_format, base_git_oid,
  source_effect_class, source_effect_ceilings, path_scope_digest,
  attempt_fence_schema_id/ref/digest, attempt_allowed_effect_classes,
  attempt_ceilings, attempt_fence_expires_at,
  effect_fence_schema_id/ref/digest, effect_fence_class,
  effect_ceilings, effect_fence_expires_at,
  authority_schema_id, authority_observation_ref/digest,
  authority_status, authority_family_status, authority_revocation_status,
  authority_allowed_effect_classes, authority_ceilings,
  authority_grant_expires_at, authority_observation_expires_at,
  evaluated_at, result, reason, support_set_ref/digest,
  evidence_ref/digest
  ```

New owner values:

| ID | Value and literal schema | Exact fields/constraints |
|---|---|---|
| V38 | `PostExecutionValidationResultSetV1`; `governed-execution.nwp-post-execution-validation-result-set.v1` | 37 fields: `schema_id`, generated `result_set_ref/digest`, source observation schema/ref/digest/outcome, author ref/invocation, six program/work coordinates, candidate and capsule pair, command pair, attempt-fence pair, effect-intent ref, effect-fence pair, tool-profile pair, host-qualification ref/digest fixed to its current schema, requirement-evidence ref/digest fixed to its current schema, sorted unique `evidence_refs≤32`, `result`, `repairability`, `reason`, `evaluated_at`, `expires_at`. Semantic tuples are exactly the validation table above. |
| V39 | `PostExecutionReviewResultSetV1`; `governed-execution.nwp-post-execution-review-result-set.v1` | 36 fields: the analogous review fields, without repairability. Results are `passed, repair_required, replan_required, terminal_reject, unknown`; source outcomes and reasons follow the review table. |
| V40 | `ReviewerIndependenceAttestationV1`; `governed-execution.nwp-reviewer-independence-attestation.v1` | 19 fields: `schema_id`, source observation schema/ref/digest, reviewer ref/invocation, author-command pair, candidate ref, capsule pair, basis pair, `status`, `reason`, `evaluated_at`, `expires_at`, generated attestation ref/digest. Status is `independent, not_independent, unknown, conflict`; reasons are respectively `reviewer_identity_distinct`, `reviewer_identity_not_distinct`, `reviewer_identity_unknown`, `reviewer_identity_conflict`. |
| V41 | `PostExecutionStandingPolicySourceAttestationV1`; `governed-execution.nwp-post-execution-standing-policy-source-attestation.v1` | 24 fields: supplied attestation ref, author ref/invocation, policy pair, parent-grant pair, grant-family pair, audience, repository, path-scope digest, status, revocation status, ordered allowed branches/lanes/effect classes, exact 15 ceilings, five branch assertions, `not_before`, `expires_at`, `evaluated_at`, self-digest. |
| V42 | `PostExecutionRiskPolicyAttestationV1`; `governed-execution.nwp-post-execution-risk-policy-attestation.v1` | 18 fields: supplied attestation ref, author ref/invocation, risk-policy pair, status, revocation status, allowed lanes, required lane, generic source-profile triple, five branch assertions, `not_before`, `expires_at`, `evaluated_at`, self-digest. |
| V43 | `PostExecutionRiskSourceProfileV1`; `governed-execution.nwp-post-execution-risk-source-profile.v1` | 9 fields: `schema_id`, `source_family=versioned_external_risk_source`, source-system schema ID, adapter profile pair, `profile_version=1`, `external_authority_claim=false`, generated profile ref/digest. |
| V44 | `PostExecutionRiskSourceBindingV1`; `governed-execution.nwp-post-execution-risk-source-binding.v1` | 15 fields: source-profile triple, development work ref, risk lane, source-value schema/ref/digest, mapping-evidence pair, `evaluated_at`, `expires_at`, generated binding ref/digest. |

The owner matrix is:

| Values | Classification | Owner status | Source of canonical bytes | Local semantic action | Owner relation | External-authority claim |
|---|---|---|---|---|---|---|
| Current `WorkerObservationV1`, manifest, fences | current owning contract | current merged owner | reconstructed current value | reconstruct | Current C2A factories/validators, version 1 | false |
| Current authority observation, host qualification, requirements, global stop | current merged implementation | current merged owner | reconstructed current value | reconstruct | Current exact class/from-mapping contracts, version 1 | false |
| Current rank-14 typed value and relation row | current merged implementation | current merged owner | reconstructed current value | reconstruct | C1 kind 14, relation rank 0, relation version 1 | false |
| V01–V13 | proposed post-execution evidence owner contract | new pure neutral owner | parent-bound nested value | derive | Input V2 and support-set V1 profiles | false |
| V14–V15 | proposed post-execution evidence owner contract | new pure neutral owner | supplied exact value | validate supplied result | Validation/review disposition V1 profiles | false |
| V16 | proposed post-execution evidence owner contract | new pure neutral owner | parent-bound nested value | derive | Parent matrix profile | false |
| V17–V18 | proposed post-execution evidence owner contract | opaque supplied attestation | supplied exact value | identity-only bind | Standing-policy/risk matrix V1 profiles | false |
| V19 | compatibility edge | new pure neutral owner | parent-bound nested value | derive | FiniteBacklog adapter V1 | false |
| V20–V21 | proposed post-execution evidence owner contract | new pure neutral owner | parent-bound nested value | derive | Global-stop/ceiling V1 profiles | false |
| V22–V24 | proposed Section 41 role-resolution contract | new pure neutral owner | parent-bound nested value | derive | Projection V2 and role-resolution V3 | false |
| V25–V34 | proposed RW0-C decision-input contract | new pure neutral owner | parent-bound nested value | derive | Named RW0-C decision profiles | false |
| V35–V37 | proposed future committed-recovery contract | new pure neutral owner | parent-bound nested value | derive | Forecast-only recovery grammar | false |
| V38–V40 | proposed post-execution evidence owner contract | new pure neutral owner | supplied exact value | validate supplied result | Exact source observation, host qualification, requirement, capsule, and author relations | false |
| V41–V42 | proposed post-execution evidence owner contract | opaque supplied attestation | supplied exact value | identity-only bind | Supplied source/policy identity and equality only | false |
| V43–V44 | proposed post-execution evidence owner contract | new pure neutral owner | parent-bound nested value | derive | Generic risk interface V1 | false |

No `SID`, source profile, source binding, or support canonical value remains dispatched to an unnamed schema.

# Corrected profile-to-value matrix and import DAG

The final profile identities are:

| Profile ref | Bytes | Raw canonical SHA-256 | Domain-separated identity digest | Governs |
|---|---:|---|---|---|
| `post-execution-semantic-review-input.v2` | 9190 | `6a3129f4701f022e86b628a544613e8c21b020221a5a93cacbec964472b55c8c` | `c51f75566ce39bbd641700401b696741229a4f3bec4a5d372b838db5fb0fcd13` | V02–V11 and nine role bindings |
| `section41-post-execution-proposal-family-projection.v2` | 5161 | `51cc133a726921c3781731a75ad55383d71bfac4245d6e124ad8e19732c5fedc` | `5d381ea3d303683dd9432323957649c2f6ef459284f9b905ba3ad8c3a9223a75` | V22–V23 |
| `section41-post-execution-role-resolution.v3` | 6843 | `ace8dbb9056fef660c5101a55e5d191c3bfa636a939a24652319484f3f19e11f` | `badce719dd69330043c4fa88fb2f23cde6aceffdd3347df7f8d1c8e01cee20da` | V24 |
| `post-execution-support-set.v1` | 3219 | `31f29710430fa3f31b14354ebfa6df6a4b4f1930c40a7f4db97390925a9613e2` | `69c8b4b730e44d0c47d0c22c6e86038876b5f52a9c5b0f3e9850423d1059ad07` | V12–V13 and six literal inventories |
| `validation-disposition.v1` | 2870 | `e6257faeda41ce04dbe02240e7bf1fad02d060c139af8d3411961ad7d7e794b6` | `43342213b6c9f2d259242de1353c5a271b77de6fef2b58e814fc8182c45b3218` | V14, V38 |
| `independent-review-disposition.v1` | 3759 | `b9a4c34be12b33ad8231c6cdcbd9ca7ef2ced7e8493b5523d0de837f4a9d6c75` | `b3c7eca17d03e4991831d6eaa202a0c58455a57e0ddf6ad80e001a1d66ccf873` | V15, V39, V40 |
| `post-execution-standing-policy-matrix.v1` | 2571 | `e5af2bad3a46c0fc1a0e48d38bac77b5bc4d590c3e4fb8ca486cf3e3dae58800` | `808c290476337184b5c9235c7d27ac567f1b06ea35e2c966dbafbfe21cb6820a` | V16, V17, V41 |
| `post-execution-risk-lane-matrix.v1` | 2573 | `54f4be1eca04468fa13b9885cddf5773f92803f1ec9a1c78141e9e168f2bfe04` | `d4d6ce64d1df38d6aa16826dd1b7a241f1d4a18652a628bb1452c568b42683b5` | V16, V18, V42–V44 |
| `finite_backlog_risk_source.v1` | 1108 | `ca72d15bc24401e8683b5367a199f0866743b038cd75efbeaa67f73d3225fce0` | `d9967ec99849f4725630f43697daf57563b3f28d69f543701da8ec0f37a1dfe5` | V19 → V43/V44 |
| `post-execution-global-stop.v1` | 2289 | `a240b9538cbdc3fab35c331192951a37addc7f2524d93beddb5e00063caad945` | `bc3473c96e3b54f40218135f5698236fe26abeac431928417b83d518114bc487` | V20 |
| `post-execution-source-effect-ceiling.v1` | 2952 | `462dc4bb08f3471c6de0d969b52c2f210c4c719e66e577822e8e0a052e4c7c54` | `d2304b9363f61fcefe3b5a87632a9962475578fdc85a26563b7efd5392999440` | V21 |
| `rw0-c-decision-membership-closure.v1` | 990 | `5e5f608cdbb83057c90165a617ad8d56a0d1ad00302121f3725d5fc1f5296144` | `ee888fefe4fb5a9de378265741e9e68a57e117eed8ef732261fd6ccbdebe638d` | V25–V26 |
| `rw0-c-decision-current-snapshot.v1` | 1675 | `54115bb68e9a8e70fa724ae5ce9a1cddee404f542de3e504928ecd9b5e161715` | `dc77c5ea9ea2540cb2559f8059b67e2f288f248bd38c216b7fa27deddb1d27df` | V27–V28 |
| `rw0-c-proposal-evidence-currentness.v1` | 1301 | `39232a8d15f6587c747d9256ba95d89e8121d946a78d7715f45524b5b45f1750` | `da73acc25b59e276d5d330c26aae0c0d0eb1471f0d48cba5d0bbe2ca63bbcddf` | V29–V30 |
| `rw0-c-decision-time-authority-branch.v1` | 1379 | `7b90906177bf489bd61a85f0938b102ad19e275c7366d61d54f224c374b17b40` | `07384a871dd87a8387c97bb1cd60e6cc8207333428e04e7766044ec8567677dc` | V31 |
| `rw0-c-decision-time-source-effect-ceiling-branch.v1` | 1672 | `4158dbcdc821cab7d09147d0450d38320cf43af739396fb8f36e109eb4c6c548` | `bfec10fc571e8adf7cd9a0498681d888d30f554367d60db8d4af85cc4b9eb41f` | V33 |
| `rw0-c-recommendation-consistency.v1` | 798 | `e8c93e807beff0e2d36dcfcf27c0bbca0060b7a655a558aaf578e4af55798676` | `b85aba9ee6564d53dcb075c5bb60e33a3b923a504c9b38046f2f96aa28f05ebd` | V34 |

The three corrected support-role arrays now exactly equal their literal inventories:

```text
validation:
source_observation, disposition_profile, validation_tool_qualification,
validation_requirement, validation_result_set, candidate_capsule

review:
source_observation, disposition_profile, review_tool_qualification,
review_requirement, review_result_set, reviewer_independence,
candidate_capsule

standing policy:
policy_source, policy_profile, authority_observation_and_parent_grant,
source_effect_fence
```

[proposed post-execution evidence owner contract] The import DAG is:

```text
_worker_execution_semantic_values
_rw0_phase_entry_semantic_values
_development_author_effect_establishment_contracts
global_stop
_rw0_c1_semantic_values
_rw0_c1_mutation_contracts
_rw0_c1_row_values
_rw0_wire_protocol_values
        |
        | private imports only
        v
_post_execution_evidence_values
        |
        +------------------------------+
        v                              v
_post_execution_policy_values   _section41_post_execution_proposal_family_projection
        ^                              |
        |                              v
_finite_backlog_risk_source_adapter   _section41_post_execution_role_resolution
        \                              /
         +------------+---------------+
                      v
             _rw0_c_decision_input_values
```

C2A modules import none of the new modules. The new modules may privately import current C2A/C1 values. No public package export is implied.

# Regenerated identities and supersession ledger

The final golden source/support anchors are:

| Value | Ref | Identity digest |
|---|---|---|
| Attempt fence | `attempt-fence-golden.0001` | `0c16e39a65d024b6e021ae98fb0eee8202d6c47bfaf67bd08be1c8c49d1e2343` |
| Author effect fence | `effect-fence-golden.0001` | `7bcb85e71e835fece7a10d45009d46d1a60a4ab5e349f4ae88904bd3081f1482` |
| Candidate capsule manifest | `candidate-capsule-golden.0001` | `69e877aa464d8c6ed7c681c5cb6a8e5b5ddfa2d67ab4d7a7d251d8aa53a0c2c9` |
| Validation observation | `validation-observation-golden.0001` | `68c763df17b2e3bb17d2d3b646ed0639b3cdb21a85f1b1bd2a621be759568757` |
| Review observation | `review-observation-golden.0001` | `60b566682748140d235b25dfb0a7bd3e5ba3172d7f30895abc856769ff3fdf9f` |
| Authority observation | `authority-currentness-attestation-golden.0001` | `3827c5c8e9795f0f29c50ae59a3e131c90c9df217421d4760b60ac7a137eabb1` |
| Validation host qualification | `validation-host-qualification-golden.0001` | `b03c136ac46699c984d271d95224b31c21f54597efa30a982a85c8880939d766` |
| Review host qualification | `review-host-qualification-golden.0001` | `5b8afd0f85138c460724a26d7b8a388790796d693027662c97e9d6f55cb9874d` |
| Validation requirement | `validation-requirement-golden.0001` | `171d1e7556d23e9d267ee24b87a44911b0db12eaee2d8ed27c7fe1442afa465e` |
| Review requirement | `review-requirement-golden.0001` | `10f9f7d9fb1c733fcdc4a8d469dc245ff037fcc5119a50d90ec5a7f2ae90d1ce` |
| Validation result set | `post-validation-result-set.3cf831cbf4acdea8f53b4458c8bada5866abe93898cc2c4564b2a0ff0d3e6200` | `ff94e09284c7f9264bb78da2440cbfeb24a0ae4ab55be108b1bd62bcfff1c3b8` |
| Review result set | `post-review-result-set.f9a892027e311f6b4210e1b86b85062380f78657215a0b0940cd8413c039c250` | `9d3d0ae23b560d87cc62e26e9d5e7459d068a0813d8a68dd81fabe56c98b38f6` |
| Reviewer independence | `reviewer-independence.c359045da5b2c8a9df8af815506ca47f4d0eeb6c1fbe71cd44319c67ca284cc4` | `07540bd4d8b9754b8fcf3feac81bd678bcd34d937800305c252186f816896eb9` |
| Policy source | `standing-policy-source-golden.0001` | `c865c94ec86a366d9d52fb802b64d8460a7760f746b4385c1b6b9e9d4713c410` |
| Risk source profile | `post-risk-source-profile.a0b7e7180a03eefa0f18010a2064209c4a56d9bea97ae9eacfa48d8ac1d05017` | `81affb2b18b8b13fdf94e9f568a065dc0670cba26037590d2be4be420cef183e` |
| FiniteBacklog binding | `finite-backlog-risk-binding.b983ff8c1c78643a8e5774843b07851ec743687adfc4debf801dc52af18772d1` | `a4f0e4d4e850e414c9839fe8c4882ceda400c5d26e8dc5ded74ade8f4b177039` |
| Generic risk binding | `post-risk-source-binding.567f06ce1c92631b3c6a42e2efb2d7f944923cbe96bf9ff5b63cc3a369586e92` | `73fe7fe91bdc648946a46ca1a6bda40e3f9fb099911a706eedd8687c1bffdc44` |
| Risk policy | `risk-policy-golden.0001` | `394340a371d761fc50dfc890dba0cd72ec46c493775ec633c88958541a3c668c` |
| Clear global-stop state | `global-stop-clear` | `9c95de33e1ebfa68c828e1069fae29c2652ab4033f7de0c36c2d3fde7192b0ab` |

Support-set identities are:

| Consumer | Ref | Digest | Entries |
|---|---|---|---:|
| Validation | `post-support-set.94f4263d72c0c1d43e3842d752208f612f0939f33c964325aa44c8a2d5215a11` | `c28eb1d525fc1ee44c10092aafb83403a6786c3e41d8205bff226db6bd0dbe4f` | 6 |
| Review | `post-support-set.cd893dcfa20cbca3f0a9c3b93655ae13328e4b55ae5c897f0892fce219a11f08` | `7c4c51ac81a435ab3bb1df03f065959327f74411059464e302c9e34116bc6cee` | 7 |
| Standing policy | `post-support-set.abc8d63ce6b3b01345d41d94271835d5bbb1cd0c3e5d943e154f72160fb2edea` | `160dddd3b684132bcf577174f2fb869d25a2ff8827a2d5e4a8bc41eef3a56575` | 4 |
| Risk | `post-support-set.206b120d9a4427261d35af15fff4f9b27d3683395e4917c4d56e25e04a572ec6` | `745114a8b5a3aab6eb769d329f640f78d2c77e0d7b533bfc9c2a091dda6ca571` | 4 |
| Global stop | `post-support-set.7f4ccd68abbffc3cbc3e1a52856e165a98a2d29e03ba9a7d8494638fab54b4f8` | `7c151a41bb920f78d3dcecadddb82ef0d3597cd3729e9bbaa79cdc62e5a3524c` | 2 |
| Effect ceiling | `post-support-set.a550486a693286c03535803de2585e2c7166a1d4f56c09083fbd9f5181bde72b` | `109bba6d5f01d0fa90b6c9a2f988501508a85ec5fc7eb398ce60a4d79434452d` | 5 |

Regenerated downstream identities:

| Value | Ref | Identity digest | Canonical bytes |
|---|---|---|---:|
| Validation disposition | `validation-disposition.6f369bf6740926feb389b35fe47b980cb0ab285a3fdfe82deae7ea868a499251` | `5f6a15046f28b924acf5bef108bb9811b7631e99b50054397ccef9a0811c2a8e` | 2811 |
| Review disposition | `independent-review-disposition.c363257c18fc3c03b8fdac41a722e7e2e45b6003825d307b6d0e75f198829c07` | `ce91ce3ec5fb55b3177df51ae0dbd7a90bf378b655770ba63ddb743e73b0686f` | 3078 |
| Standing-policy matrix | `standing-policy-matrix-golden.0001` | `5f4ff24ad16254f6e9b39e81194b3ef551a466c331a8715f8b0f916cd6986c5d` | 3536 |
| Risk matrix | `risk-lane-matrix-golden.0001` | `ff7b4700ac4e07bf27d933dee4e50afc8526e84a5d8d2a2079aa78a58f529e0e` | 2981 |
| Global-stop snapshot | `post-global-stop-snapshot.fb9ef657c57d88d181015c054a8321a4fe545bfa7f3f714bc1c1d3405a0d83db` | `956c1a100e6d532f80376b87a25dc8f5d42f93793fd79388b54df292694ffadf` | 1077 |
| Ceiling evidence | `post-source-effect-ceiling.f2b5565845a05324705eba52570b3a5fc818b3604223514741ad84764cf22ea0` | `c16e2ce19bf2eff25c3c13d959ceabebf24490f487709101d9d1ba8d80cc2941` | 4141 |
| Rank-14 typed value | `worker-result-golden.0001` | `32d99f305712ad3b5f327177f0f0f9526fba69e705f26389ea8411c5ddd87488` | 1056 |
| Lineage context | `section41-post-lineage.6786ef654a8b1c2f44fe0ae3e4ab25351509a47675d9b24747ffc062e6d16817` | `e2618385b2228f6e5e7b97b37e5bec586ff01647022f688ff89422a9f900106f` | 2610 |
| Candidate safe projection | `candidate-safe-projection.a12298fa42d10a277555f24d8eee95fa67e88d97dcb016904e3812fc2bf26663` | `7d5ce6cdfc90b21afb1af8294195a3c0444a9987979340f79cd3e4a14e4cdee0` | 1439 |
| Model-input projection | `post-model-input-projection-v2.6e30b5980e0323efdad70c0074eb1fa5ab0f5d41d87b97caf248adb5944a2ba8` | `fd3fdf03ef05e96be2a5186ed739d4a10fd4f700cdd8964455ccbb2c601059c7` | 7212 |
| Private manifest | `post-private-input-manifest-v2.cc3f5253dc91d7d92573ac2b624f83a7f901bbe28f1438fa7fdc1ef5bc13a8a5` | `7e6ba350cc73f31ec8a7f961088d774a7da7ecf37e9606dfaef99be70ad7378f` | 1253 |
| T1 input context | `post-semantic-input-context.1eb97f04c1d09d4a6d66e72657b482e851257c44663151deb5ecf563dd27689c` | `a786d6d4da1916758aa314d7b372444a25602dcb0a225d49cac23b69eb07c9f9` | 10449 |
| Evidence supply | `post-evidence-supply-v2.a78987bb8aa72b28eae420a394dcc0531c928e7667b5b041d80c3c6e8a154282` | `d0afce1caf3af5716454edbb151b4fa8e6f792fa3df384b61b6fefa60bd93b7f` | 151570 |
| Source invocation | `source-invocation-post-golden.0001` | `05f7c8d88079f3a4e5ab7e7c86edbbd39ebd3f35923952891645068de51d7088` | 1224 |
| Artifact binding | `post-artifact-golden.0001` | `b4f3d836f3518d93bf5a7c715870f6eec874faf3469a2ae1cbf0e2f71c958d8b` | 776 |
| Evidence set | `post-evidence-set-golden.0001` | `48603020bb22e2f873540001a59c1a832d72ee430e219dbb93e9c3b661272eb4` | 3108 |
| Proposal | `post-proposal-golden.0001` | `38c4cec4b7e887ff21188c2772763072254a5982acd112e8f68578a70fb56480` | 1633 |
| Owner-family graph | `owner-family-graph` | `b3bbea2850aa28e2ff8d04dcdca4ad324167277ef8a3f80b832b3b679de253b5` | 3190 |
| Section 41 projection V2 | `section41-post-projection-v2.d6efd15854e9dda7cb6bcfcd955b89a5eede77466d1db439b954e5136010c4ac` | `a6e629c65f2b1b31e93f67b48fc8ccd2c9e947221602ccfb07862ecefb0d21e2` | 10038 |
| Model-input binding V2 | `post-model-input-binding-v2.94aef33a158cf4b09689a56f0b50f1018eec202f17716cb7611716cf9a84d134` | `18b3b69a8a33d77b3f1d1ab69893c60833debed4f7c06bc66b6062c414648a5e` | 3145 |
| Rank-15 typed value | `section41-member-golden.0001` | `984b52178314393d0dbc8cd6cbf51ab18228d14fa759a9de655d4e0df8122341` | 1995 |
| Validation role-resolution V3 | `section41-role-relation-v3.0c12068a7e4d914f7e4fda060a4acdb43eb33c792c9b52d723aba2664753f30f` | `f1586f7cb6b1f66b39bc9675419d3f97a4ab79f3209ec2a594449e12de8ad93d` | 3652 |

The evidence supply remains under its cap:

```text
151570 <= 1048576
```

Important supersessions:

| Superseded | Replacement |
|---|---|
| Invented validation/review observation schemas | Current `WorkerObservationV1` schema |
| Standalone rank-14 classifier row schema in T1 | Generic C1 relation-binding row plus literal relation ID/version |
| V04 `sha1 | sha256` grammar | Literal `sha1` and 40-hex OID |
| Input profile digest `c4346cf2…` | `c51f7556…` |
| Projection profile digest `c40867c7…` | `5d381ea3…` |
| Role-resolution profile digest `fd051f9c…` | `badce719…` |
| Support profile digest `026bad9c…` | `69c8b4b7…` |
| Validation profile digest `a53ccecb…` | `43342213…` |
| Review profile digest `ffdeb616…` | `b3c7eca1…` |
| Policy profile digest `c6e4ea9c…` | `808c2904…` |
| Risk profile digest `eda9c576…` | `d4d6ce64…` |
| FiniteBacklog profile digest `1dace7cf…` | `d9967ec9…` |
| Global-stop profile digest `2d76a693…` | `bc3473c9…` |
| Ceiling profile digest `950bf044…` | `d2304b93…` |
| Candidate safe ref/digest `candidate-safe-projection.210584…` / `9a5aee7c…` | `candidate-safe-projection.a12298…` / `7d5ce6cd…` |
| Lineage ref/digest `section41-post-lineage.3c1d06…` / `5dcf26f2…` | `section41-post-lineage.6786ef…` / `e2618385…` |
| Model projection ref/digest `post-model-input-projection-v2.3c4176…` / `f305c80d…` | `post-model-input-projection-v2.6e30b5…` / `fd3fdf03…` |
| Private manifest ref/digest `post-private-input-manifest-v2.7508ce…` / `1db620d4…` | `post-private-input-manifest-v2.cc3f52…` / `7e6ba350…` |
| T1 ref/digest `post-semantic-input-context.119a8d…` / `8d2cd3aa…` | `post-semantic-input-context.1eb97f…` / `a786d6d4…` |
| Source invocation digest `a147683a…` | `05f7c8d8…` |
| Evidence-set digest `59753e83…` | `48603020…` |
| Proposal digest `d878c87b…` | `38c4cec4…` |
| Owner-family graph digest `f51f641c…` | `b3bbea28…` |
| Section 41 projection ref/digest `section41-post-projection-v2.8afc2a…` / `5c9631e3…` | `section41-post-projection-v2.d6efd1…` / `a6e629c6…` |

The artifact binding remains byte-identical because no affected field enters it.

# T1/Section41/resupply equality matrix

The final T1 role identities are:

| Rank | Role | Typed schema/ref/digest | Source profile | Source-binding triple |
|---:|---|---|---|---|
| 5 | `candidate_capsule` | Manifest / `candidate-capsule-golden.0001` / `69e877aa…` | null | null |
| 6 | `worker_result` | Rank-14 value / `worker-result-golden.0001` / `32d99f30…` | `rw0-wire-nwpf-v1` / `470cb5bf…` | generic C1 relation row / `rw0-c1-relation.f832ac…` / `937530ec…` |
| 7 | `validation_result` | Validation disposition / `validation-disposition.6f369b…` / `5f6a1504…` | `validation-disposition.v1` / `43342213…` | Worker observation / `validation-observation-golden.0001` / `68c763df…` |
| 8 | `independent_review` | Review disposition / `independent-review-disposition.c36325…` / `ce91ce3e…` | `independent-review-disposition.v1` / `b3c7eca1…` | Worker observation / `review-observation-golden.0001` / `60b56668…` |
| 9 | `standing_policy` | Policy matrix / `standing-policy-matrix-golden.0001` / `5f4ff24a…` | `post-execution-standing-policy-matrix.v1` / `808c2904…` | Policy source attestation / `standing-policy-source-golden.0001` / `c865c94e…` |
| 10 | `risk_lane` | Risk matrix / `risk-lane-matrix-golden.0001` / `ff7b4700…` | Generic risk profile / `post-risk-source-profile.a0b7e7…` / `81affb2b…` | Generic risk binding / `post-risk-source-binding.567f06…` / `73fe7fe9…` |
| 11 | `authority_currentness_attestation` | Authority observation / `authority-currentness-attestation-golden.0001` / `3827c5c8…` | null | null; direct C1 rank-1 membership |
| 12 | `global_stop` | Stop snapshot / `post-global-stop-snapshot.fb9ef6…` / `956c1a10…` | `post-execution-global-stop.v1` / `bc3473c9…` | GlobalStopState / `global-stop-clear` / `9c95de33…` |
| 13 | `effect_ceiling` | Ceiling evidence / `post-source-effect-ceiling.f2b556…` / `c16e2ce1…` | `post-execution-source-effect-ceiling.v1` / `d2304b93…` | EffectFenceV1 / `effect-fence-golden.0001` / `7bcb85e7…` |

Required equalities:

| Boundary | Exact equality |
|---|---|
| T1 → role supply | Role, rank, ordinal, typed schema/ref/digest, source profile pair, source-binding triple, and posture |
| Role supply → supplied bytes | Recomputed canonical identity equals every advertised ref/digest; no opaque value is reconstructed from summaries |
| Candidate typed value → model value | Typed value remains full manifest; model value is V04; private manifest binds the full manifest’s byte length and identity |
| Disposition → observation | Exact schema/ref/digest, outcome, author, program/work/attempt/effect/command/fence/candidate/capsule equality |
| Disposition → support | Exact consuming profile inventory, order, cardinality, schema/ref/digest, and canonical value |
| Worker role → C1 | Exact rank-14 membership, typed value, generic relation row, semantic relation ID/version, proof mode, NWPF profile, and operand-set digest |
| T1 → durable evidence rows | Nine typed refs/digests equal nine proposal evidence-binding rows |
| Durable evidence rows → Section 41 projection | Same role/rank/ordinal/ref/digest and evidence-binding digest |
| Proposal/source → projection | Exact input-context triple, lineage triple, source invocation, artifact, proposal, evidence set, model contract/configuration, chronology |
| Projection → rank-15 C1 member | Exact proposal/source/artifact/context/evidence-set/owner-graph fields |
| Role resolution V3 | Reconstructs one role from T1, projection, evidence row, rank-15 member, source profile/binding, and currentness profile |
| T1 timing | Rank-15 membership is unavailable and forbidden at T1; it is only a later admission result |
| Resupply | Same canonical bytes reproduce all identities; missing exact supply is `no_decision`; substitution or contradiction is `basis_conflict` |

The regenerated nine durable evidence-binding digests, ranks 5–13, are:

```text
e1d8c9fb13ec6719b04cd1687620565ee00e55ea1f3e3965b998aad5011b820a
0d4bcad233a3265992c6ff85b6655fca7cfef6e3ea871f27294768601b3f612c
592880296e9a3e32ebdd9ac3570f40bb4074de9782a651da6b9673d0f59aedbc
a67436526856cacb33a69b08c895f41aab0ce9401cce9d673263f122882ffa13
0376ed40d038bd9d9927bc546c9dd07c8cc53eda0f6d69be57e7d064f2de77a7
b3b3e16252df2c6e1774e8b955a759b1799872fb3e3870ad326feb48acb6e9a1
695445d763c4156b3c8fc5b4a619a3962983440c9809ad1b4e67f41b410964d0
5650d3a6b4c20d31cec6ee9a532840a663fe146551ef3e650df1703b755aef75
69db11dd2f484ad33502ae1167c5ca1218fd6a2c3f7ca95965caaffcd2fbef10
```

The corresponding projection-entry digests are:

```text
a306944410402f921ff600029eada2b0d95d0e854636bec00dfd81b35111bf1a
fb6016d954134e4dcdbe5d8c17bb905e059bc5611ac250b812d10d5a3bc86133
2c5971abb5de5ccd38870ba8a692798b421ff252f2999b18287c3c5a4b8551b9
51d43f45dd1b3479d36e8b055294a508da1e536d0e521768755279f67ba41b31
5f3bacaf64e356c833e2ff8fa11039d51d08cfabe12582b4ae69de0247b8d434
49e5b7fa7f6e2085f27f683dc251d1d308ddaf389818a9f7788e6a97d5f9f4fd
f336e1e7ae05216871192ab14340b485a40abf48de3cd15a13ffd20d9552a1cd
a6a8f54e4f83177309853c8c0dc78d1af055444c9b8c616976a1ecc02ba25696
55ad589fe8d01e50b5b9a98575f71b4b580280d5148a7fc39ee02e6ff4e153a0
```

# Finite assurance matrix

These are finite ordinary semantic-test and external-mutant requirements. They were specified and mechanically reconciled here, but no test suite was run.

| ID | Type | Mutant/case | Required result |
|---|---|---|---|
| A01 | Ordinary | Invented validation observation schema | Reject before canonicalization |
| A02 | Ordinary | Invented review observation schema | Reject before canonicalization |
| A03 | Ordinary | Correct WorkerObservation schema, wrong observation kind | Reject |
| A04 | Ordinary | Correct kind, wrong source kind | Reject |
| A05 | Ordinary | Correct kind/source, invalid outcome | Reject |
| A06 | Ordinary | Observation program/work/attempt/effect/command/fence substitution | `basis_conflict` |
| A07 | Ordinary | Candidate or capsule substitution | `basis_conflict` |
| A08 | Ordinary | Fabricated standalone classifier-row schema | Reject; require generic C1 relation row |
| A09 | Ordinary | Wrong rank-14 relation ID/version/proof/profile | Reject |
| A10 | Ordinary | `sha256` candidate format | Reject |
| A11 | Ordinary | Base OID not exactly 40 lowercase hex | Reject |
| A12 | Ordinary | Unregistered support/source schema | Reject |
| A13 | Ordinary | Policy-source substitution | `basis_conflict` |
| A14 | Ordinary | Risk-policy substitution | `basis_conflict` |
| A15 | Ordinary | Generic risk source-profile substitution | `basis_conflict` |
| A16 | Ordinary | Generic risk source-binding substitution | `basis_conflict` |
| A17 | Ordinary | Development/backlog ID equality assumed | Reject adapter relation |
| A18 | Ordinary | Global-stop clear with any active detail | Reject |
| A19 | Ordinary | Global-stop active with any missing detail | Reject |
| A20 | Ordinary | Same stop version with a field mismatch | `basis_conflict` |
| A21 | Ordinary | Attempt-fence schema, digest, stop coordinate, or expiry substitution | Conflict/noncompliant according to precedence |
| A22 | Ordinary | Effect-fence schema, digest, class, capsule branch, target branch, or expiry substitution | Conflict/noncompliant |
| A23 | Ordinary | Authority status/family/revocation outside closed vocabulary | Reject |
| A24 | Ordinary | Missing or extra ceiling key | Reject |
| A25 | Ordinary | Unsorted, duplicate, or more than 32 evidence refs | Reject |
| A26 | Ordinary | Support entry outside literal consuming inventory | Reject |
| A27 | Ordinary | Wrong support order, rank, ordinal, count, or repeated source pair | Reject |
| A28 | Ordinary | Stale profile or dependent identity after owner correction | Digest mismatch |
| A29 | Ordinary | Locally fabricated validation/review disposition | Reject authorship/source relation |
| A30 | Ordinary | Local recomputation claim for opaque policy/risk meaning | Reject contract/profile |
| X01 | External mutant | Patch C2A observation schema/kind relation | Independent audit detects owner-boundary violation |
| X02 | External mutant | Patch C1 rank-14 relation schema/profile/proof relation | Independent audit detects durable C1 drift |
| X03 | External mutant | Patch candidate format to admit SHA-256 | Independent audit detects source-domain widening |
| X04 | External mutant | Patch source/support registry or profile without regenerating dependents | Independent audit detects stale-identity provenance |

Permanent repository tests remain ordinary bounded semantic tests. External mutation, patch provenance, and cross-owner review remain independent-audit responsibilities.

# Remaining seams and stop conditions

[report-only uncertainty] The pure-owner tranche remains unimplemented. The exact schemas and profiles above are contract definitions and mechanically reproduced vectors, not merged source.

[proposed future committed-recovery contract] V35–V37 remain forecast-only. Their existence does not authorize migration, persistence, decision writing, receipt recovery, terminal behavior, or runtime integration.

No stop condition was triggered:

- No current C2A, B1, B2, or C1 semantic change is required.
- No migration-0003 or C1 durable-row meaning changes.
- No source authentication or external I/O.
- No sixteenth C1 kind.
- No capsule entry or private body persistence.
- No FiniteBacklog concept in generic target semantics.
- No model recommendation authority.
- No branch truth, C2B progression, latch, terminal, D/E, or ES semantics.

The remaining implementation boundary is deliberate: the report closes contract ownership but does not implement it.

# Recommended next step

The resulting report is ready for a fresh independent contract audit.

The audit should verify current-owner fidelity, profile/value reproduction, exact source resupply, privacy, and import direction. Implementation should remain blocked pending that audit’s acceptance.

# Confidence

High confidence in:

- Required baseline and fixed-input identity
- Current C2A observation, capsule, fence, qualification, requirement, authority, and global-stop ownership
- Current C1 rank-14 typed value and generic relation-row binding
- Literal source/support inventories
- Corrected profile identities
- Reproduced source, T1, proposal-family, projection, rank-15, and role-resolution identities
- Absence of repository or external-system mutation

Confidence is intentionally limited to contract reconciliation. It does not extend to the unimplemented pure-owner tranche, future durable recovery, decision writing, terminal behavior, D/E behavior, or ES integration.

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
```

RW0_POST_EXECUTION_SOURCE_OWNERS_AND_SUPPLY_BINDINGS_RECONCILED_READY_FOR_INDEPENDENT_AUDIT
