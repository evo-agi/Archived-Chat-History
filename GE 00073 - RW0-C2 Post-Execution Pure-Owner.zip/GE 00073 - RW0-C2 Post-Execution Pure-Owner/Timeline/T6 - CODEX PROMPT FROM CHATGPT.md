PROMPT_ID

C2B_PROGRESSION_DECISION_WRITE_OWNER_CONTRACT_RECONCILIATION_V1

TITLE

Coordinator C2B — freeze the authoritative write-side progression-decision
contract needed by RW0-C-Decision without moving C2B state semantics into RW0-C

ENGAGEMENT TYPE

Parent-only, local, read-only owner-contract reconnaissance.

Do not delegate to subagents.

Do not edit, format, generate repository files, stage, commit, push, create a
branch or PR, merge, tag, release, deploy, fetch, contact a remote/live system,
install dependencies, run migrations, execute tests, open an operator
database, invoke a product worker/model, or inspect/modify supporting
repositories.

Do not issue an implementation prompt.

Print the complete substantive report inline. Evidence paths may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

C2B_PROGRESSION_DECISION_OWNER_BASELINE_MISMATCH

WHY THIS PASS IS REQUIRED

The reconciled RW0-C-Decision contract established that the current merged
repository freezes:

- the existing 43-field `development_decisions` row grammar;
- exact decision kinds and variants;
- branch field nullability;
- immutable program/work/version/revision row grammars;
- the nested progression-result projection;
- the generic `development_mutation_receipts` envelope;
- private readers and the common transaction/writer authority.

It did NOT establish an implemented or fully frozen write-side progression
mutation for:

- `accept / candidate_acceptance`;
- `repair / candidate_repair`;
- `replan / attempt_selecting_replan`;
- `terminal_reject / program_terminal_reject`;
- `block / program_block`.

The missing owner decisions include exact program/work head post-states,
work-revision creation or retention, membership copying/replacement, accepted
intent revisions, revision edges, CAS order, write order, and recovery graph.

`cancel / effect_cancellation` is already compatible as a non-version-advancing
decision, but its exact no-op progression behavior must remain explicit.

RW0-C must not choose or reinterpret C2B-owned progression semantics merely to
make migration 0005 implementable.

CURRENT CONTRACTS TO PRESERVE

1. RW0-C1 is merged and current. Its values, schemas, readers, membership
   semantics, relation proofs, recovery, and migration 0004 remain unchanged.

2. RW0-C-Decision remains the accepted strategic consumer:
   - one exact decision closure per C1 phase;
   - one bound existing C2B decision;
   - only productive direct-local accept consumes the latch;
   - terminal closure remains later and separate;
   - migration 0005 remains provisional until this owner seam closes.

3. Existing C2B decision kinds remain exactly:

```text
initialize
accept
repair
replan
terminal_reject
block
redeliver
cancel
```

4. Existing relevant variants remain exactly:

```text
candidate_acceptance
candidate_repair
attempt_selecting_replan
program_terminal_reject
program_block
effect_cancellation
```

5. No new or reinterpreted decision field, kind, variant, result field, receipt
   field, program state, version kind, work state, work revision kind, or edge
   kind is permitted without an explicit owner contradiction and a stop.

6. Current closed state vocabularies remain:

```text
program states:
active
accepted
terminal_rejected
blocked

program-version kinds:
initial
accepted
repair
replan
terminal_rejected
blocked

work states:
planned
active
accepted
repair_required
terminal_rejected
blocked

work-revision kinds:
initial
replan

revision-edge kinds:
accepted_intent_supersedes
work_item_supersedes
work_item_split
work_item_merge
```

7. The existing progression result remains exactly:

```text
schema_id
program_ref
decision_ref
result_program_version_ref
result_decision_ref
result_projection_digest
```

with `result_decision_ref == decision_ref`.

8. The existing nested receipt family remains:

```text
mutation_family = record_development_progression_decision
command_schema_id =
  governed-execution.nwp-record-development-progression-decision-command.v1
result_class = development_progression_decision_recorded
outcome = committed
```

9. Existing migrations 0001–0004, public APIs, StateStore, package exports,
transaction authority, global-stop authority, Section 41, B1/B2/C1/C2A, and
supporting repositories remain unchanged.

10. No implementation is authorized by this engagement.

FACT CLASSIFICATION

Classify every substantive conclusion as exactly one of:

- current owning contract;
- current merged implementation;
- compatibility edge;
- reopened owner seam;
- proposed frozen C2B owner contract;
- implementation detail;
- report-only uncertainty.

State conflicts explicitly. Do not silently convert historical plans into
current contracts or current target prose into implemented behavior.

INSPECTION SCOPE

Inspect together:

Governing C2B/current documents:

- `.docs/c2b-durable-development-state.md`
- `.docs/c2b2-pure-durable-row-values.md`
- `.docs/c2b2-private-readers.md`
- `.docs/c2b3-program-initialization.md`
- `.docs/c2b3c-author-effect-establishment.md` if present
- `.docs/c2b3d-author-effect-establishment.md` if present
- `.docs/software-development-progression-boundary.md`
- `.docs/durable-state-model.md`
- `.docs/sqlite-operations-and-recovery.md`
- `.docs/writer-session-authority.md`
- `.docs/authority-boundaries.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/rw0-c1-durable-evidence.md`
- `AGENTS.md`
- `README.md`

C2B row/value/read owners:

- `_development_program_row_values.py`
- `_development_effect_row_values.py`
- `_development_decision_row_values.py`
- `_development_row_value_support.py`
- `_sqlite_development_reader_contracts.py`
- `_sqlite_development_readers.py`
- all current private C2B apply/replay/recovery modules;
- all exact direct tests pinning decision variants, program/work rows,
  memberships, accepted-intent revisions, revision edges, results, receipts,
  heads, global stop, writer delegation, and transaction authority.

Common owner machinery:

- `sqlite_transition_transaction.py`
- `sqlite_writer_session.py`
- `sqlite_mutation_transaction_contracts.py`
- `sqlite_transition_select_support.py`
- migration 0002 and its direct tests;
- current program initialization, effect establishment, selection/disposition,
  transition, and global-stop implementations used as patterns.

RW0-C contract inputs:

- the latest read-only RW0-C-Decision reconciliation report supplied in the
  conversation;
- C1 phase/K8/member semantics;
- Section 41 proposal families;
- exact current global-stop and head owners.

No tests, migrations, or database commands may run.

ENGINEERING DECISIONS

1. OWNER AND CAPABILITY BOUNDARY

Define the smallest authoritative C2B write-side capability that must exist.

Decide whether the owner contract is:

A. One branch-parameterized private progression-decision planning and
persistence family covering accept, repair, replan, terminal reject, block, and
cancel.

B. Multiple owner families split by advancing versus non-advancing decisions.

C. Another split, only if current owner dependencies prove A and B incorrect.

The owner must define progression truth independently of RW0-C. RW0-C may
compose the owner’s closed plan into one outer transaction; it may not author
the program/work semantics.

State whether this owner capability is independently useful outside RW0-C.

2. COMPOSITION SEAM WITH RW0-C

Freeze how RW0-C can atomically combine:

- C decision closure;
- C2B decision/progression rows;
- nested C2B result and receipt;
- accept-only latch CAS;
- outer C binding/result/receipt;

without:

- opening a nested transaction;
- acquiring a second mutation slot;
- using a second connection;
- committing twice;
- calling a standalone operation that publishes partial state;
- importing C-owned semantics into C2B.

Evaluate and choose an exact seam, such as:

- a pure C2B command evaluator and immutable closed write plan owned by C2B,
  executed by the common controller inside the outer C transaction;
- an owner-provided resolver/readback contract plus controller execution;
- another exact single-transaction design.

Freeze:

- owner module;
- consumer module;
- import direction;
- allowed inputs;
- returned plan/result;
- who captures the transaction timestamp;
- who owns SQL specifications;
- who executes writes;
- who performs full family readback;
- how the nested receipt is produced;
- how recovery reconstructs the C2B graph;
- whether a standalone C2B operation is required now.

3. EXACT BRANCH MATRIX

For each branch freeze all fields below.

## Accept — `accept / candidate_acceptance`

Determine exactly:

- required basis decision/program version/selection fields;
- required selected attempt/candidate/fence;
- new program-version number and kind;
- program-version membership rows;
- whether the current work revision is copied unchanged;
- whether a new work revision is forbidden;
- resulting program-head state/revision/digest;
- targeted work-head state/revision/digest;
- treatment of every other work item if a program has more than one;
- whether this first-slice profile requires exactly one work item;
- accepted-intent/revision-edge behavior;
- global-stop behavior;
- result and receipt;
- collision probes and recovery locators.

## Repair — `repair / candidate_repair`

Determine exactly:

- successor attempt/candidate preassignments;
- new program version kind/number;
- membership copying;
- whether current work revision is retained;
- whether a new work revision is forbidden;
- work-head transition to `repair_required`;
- program-head post-state;
- accepted-intent/revision-edge behavior;
- multi-work behavior;
- result/receipt/recovery.

## Replan — `replan / attempt_selecting_replan`

Determine exactly:

- whether the existing work item or a new work item is targeted;
- resulting accepted-intent revision number/prior/source identity;
- resulting work-item revision number/kind/prior identity;
- exact WorkSpec binding;
- exact required revision edges:
  - accepted-intent supersedes;
  - work-item supersedes;
  - split;
  - merge;
- when each edge kind is legal;
- new program-version membership set and order;
- program/work head post-states;
- successor attempt/candidate semantics;
- result/receipt/recovery.

Do not silently narrow the existing variant beyond its owner grammar without an
explicit versioned profile.

## Terminal reject — `terminal_reject / program_terminal_reject`

Determine exactly:

- new program version kind/number;
- membership copying;
- targeted work identity;
- whether work revision is retained;
- work-head state;
- program-head state;
- multi-work behavior;
- result/receipt/recovery.

## Block — `block / program_block`

The decision row does not identify a work item. Freeze:

- whether block is program-wide;
- whether all current work heads become `blocked`;
- whether only a one-work first-slice profile is permitted;
- whether no work head changes;
- exact program-version membership behavior;
- exact program-head and work-head post-states;
- zero-work/multi-work behavior;
- result/receipt/recovery.

Do not let RW0-C infer a target work item that the owner decision does not
identify.

## Cancel — `cancel / effect_cancellation`

Confirm exactly:

- no new program version;
- no program/work head mutation;
- no effect/delivery creation in this decision transaction;
- exact target/head/source/capsule/preassignment checks;
- result projects the basis program version;
- receipt/recovery graph;
- active-stop behavior.

4. SINGLE-WORK FIRST-SLICE PROFILE

Decide whether RW0-C may require exactly one current work item in the basis
program version.

If yes:

- define it as a versioned C2B composition/profile constraint;
- prove it does not reinterpret the generic decision variant;
- specify exact bounded membership read and failure reason;
- specify behavior for zero or multiple work items;
- decide which branches require the profile;
- do not mutate unspecified work heads.

If no:

- freeze complete multi-work branch behavior for every advancing decision.

5. PROGRAM-VERSION MEMBERSHIP

For every advancing branch freeze:

- whether old membership is copied exactly;
- whether one membership is replaced;
- ordering/ordinal semantics;
- uniqueness;
- creation timestamp;
- membership digest;
- relationship to resulting work revisions;
- collision and partial-family behavior.

6. HEAD CAS AND ORDERING

Freeze exact preimage and postimage fields for:

- program head;
- every affected work head;
- accepted-intent head, if one exists;
- selection head, if changed;
- effect/delivery heads, if read-only or changed;
- global stop.

For each CAS:

- exact `WHERE` predicates;
- exact revision increment;
- exact digest preimage;
- exact postimage digest;
- rowcount requirement;
- ordering relative to immutable inserts;
- conflict reason;
- replay behavior.

No head update may be selected by C.

7. RESULT AND RECEIPT

Freeze:

- exact progression result per branch;
- `result_program_version_ref` for advancing and cancel branches;
- exact result digest;
- nested mutation graph entries and ordering;
- receipt fields;
- no receipt-digest column in SQL, if that remains current;
- pure computed receipt digest;
- receipt-last publication;
- exact replay reconstruction;
- partial-family corruption classification.

8. REPLAY, COMMIT UNCERTAINTY, AND RECOVERY

For every branch define:

- exact replay;
- same mutation-ref/different-command conflict;
- semantic identity collision;
- definitely-not-committed proof;
- committed-exact proof;
- unresolved cases;
- head/latch behavior after uncertainty;
- no automatic retry;
- fresh fenced writer requirement;
- close-proof and result-handoff behavior.

The C2B owner recovery graph must be composable into the outer RW0-C recovery
without creating a second truth or retry path.

9. GLOBAL STOP

Freeze exact behavior:

- accept;
- repair;
- productive replan;
- terminal reject;
- block;
- cancel.

Distinguish:

- receipt-hit replay;
- fresh operation;
- current stop version/state;
- stop activation after an earlier committed decision;
- whether the decision row binds stop ref/version only or state too.

10. LATCH OWNERSHIP BOUNDARY

The latch is consumed only in the outer RW0-C accept transaction, but its
historic semantic identity originated in C2B planning.

Decide:

- whether C2B owns only the meaning of productive acceptance while migration
  0005/C owns the physical latch row;
- exact key and scope literal;
- `coordinator_state_root_database` versus historical
  `global_coordinator_bootstrap` terminology;
- whether any C2B row directly references the latch;
- whether C2B plan evaluation must assert latch eligibility but leave CAS to
  the outer C layer;
- why non-accept branches cannot read or mutate it.

Do not create a second latch or put generic progression authority in the latch.

11. LOGICAL OWNER VALUES AND MODULES

Before choosing file names, define the minimum private C2B owner contracts:

- branch/profile value;
- command evaluator;
- immutable write plan;
- result plan;
- readback/recovery projection;
- conflict vocabulary;
- SQL specification ownership.

Decide whether any current row/value module must change. A changed existing
field meaning is a stop condition; additive owner contracts may be proposed.

12. ASSURANCE ARCHITECTURE

Permanent C2B tests must causally prove:

- each branch’s exact positive write graph;
- every cross-branch nullability failure;
- one-work or multi-work profile;
- version membership;
- accepted-intent/work revision and edge grammar;
- head CAS postimages and rowcount;
- active-stop matrix;
- result and receipt;
- receipt-first replay;
- every write/commit/cleanup boundary;
- three-way recovery;
- no public/API/authority widening.

Independent audit owns:

- patch provenance;
- external row/head/edge mutants;
- fault injection;
- migration/resource identities if a migration is proposed;
- clean/live validation;
- privacy and authority inspection.

Do not introduce self-protecting tests or broad source hashes as semantic proof.

13. DECOMPOSITION AND NEXT BOUNDARY

Decide whether:

A. A standalone C2B progression-decision owner implementation must land and
merge before RW0-C-Decision.

B. The C2B owner contract and implementation can be introduced in the same
candidate as RW0-C-Decision while remaining a separate owner module and
separately auditable seam.

C. Another sequence is required.

Prefer one authoritative writer and avoid temporary architecture hardening by
inertia. Do not combine merely to reduce PR count, and do not split if the
intermediate owner capability is disposable.

14. TOUCHED-SURFACE FORECAST

Do not issue an implementation allowlist unless the owner contract fully closes.

Forecast:

- new owner document;
- new private C2B contract/planning/readback modules;
- transaction/controller integration;
- tests;
- existing docs/status/source-hash/importer consumers;
- whether migration 0005 remains solely RW0-C-owned;
- protected migrations 0001–0004 and public surfaces.

Separate:

- must change;
- may change;
- protected.

STOP CONDITIONS

Return an explicit blocker if any of these is required:

- new or reinterpreted decision kind/variant;
- changed existing decision field nullability;
- changed migration 0002 bytes;
- new public StateStore or WriterSession method;
- second transaction controller/connection/commit path;
- generic JSON/BLOB write plan;
- C choosing C2B head states or revision edges;
- C2B absorbing RW0-C closure, latch, or terminal semantics;
- external I/O in the transaction;
- inability to prove three-way recovery;
- inconsistent multi-work behavior;
- a decision branch that cannot be represented by existing rows.

RETURN FORMAT

# Baseline and inspection boundary
# Current C2B owner reality
# Owner-capability decision
# Composition seam with RW0-C
# Exact branch write matrix
# Single-work versus multi-work profile
# Program-version membership contract
# Accepted-intent/work revision and edge contract
# Head CAS and ordering
# Global-stop behavior
# Result, mutation graph, and receipt
# Replay, commit uncertainty, and recovery
# Latch ownership boundary
# Assurance architecture
# Decomposition and sequencing recommendation
# Provisional touched-surface forecast
# Findings and stop conditions
# Recommended next step
# Confidence

SUCCESS TOKEN

Return exactly:

C2B_PROGRESSION_DECISION_WRITE_OWNER_CONTRACT_READY_FOR_INDEPENDENT_AUDIT

only if:

- every branch is owner-frozen without changing current row meanings;
- the composition seam is exact;
- recovery is complete;
- no implementation prompt is issued.

Otherwise return:

C2B_PROGRESSION_DECISION_OWNER_RECONCILIATION_BLOCKED

and identify the precise upstream owner decision required.

Required statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
