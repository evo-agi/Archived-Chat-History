# Decision

**Accept the owner direction, but do not send this contract to independent audit yet. It needs one more read-only reconciliation.**

Codex has made the important architectural decisions correctly:

- C2B owns one private, branch-parameterized progression-decision family.
- RW0-C consumes a bounded C2B facade; C2B does not import or interpret RW0-C.
- The common Coordinator transaction remains the sole connection, mutation-slot, timestamp, and commit authority.
- The first writer profile is explicitly single-work for advancing branches.
- Accept, repair, replan, terminal reject, block, and cancel now have plausible branch-specific progression semantics.
- Migration `0005` remains RW0-C-owned; migration `0002` and its existing row meanings remain unchanged.
- The C2B owner module and RW0-C composition may land in one eventual candidate while remaining separately auditable seams. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

Those decisions should be preserved.

## Why it is not yet an auditable freeze

### 1. The report is not grounded in the real repository paths

Its principal source links use:

```text
src/governed_execution_nwp_coordinator/
```

and place the migration under a `migrations/` directory. :chatgpt-content-reference{index="3"}

The merged repository actually uses:

```text
src/ge_nwp_coordinator/
src/ge_nwp_coordinator/sqlite_migrations/
```

The live merged `_development_program_row_values.py` is at the former path, and the report’s package path returns no file. 

This may be a report-generation mistake rather than a semantic failure, but an independent contract audit needs exact valid paths and lines. The next pass must correct every citation and rebuild the path-derived surface from the actual tree.

### 2. The “profile” is only a name, not a frozen identity

The report names:

```text
governed-execution.nwp-c2b-progression-single-work-profile.v1
```

and gives its broad behavior, but it does not provide:

- a canonical manifest;
- profile ref versus schema ID;
- canonicalization rules;
- digest domain;
- profile digest;
- where that profile pair is bound in the command, receipt, RW0-C attestation, replay, and recovery.

:chatgpt-content-reference{index="5"}

That leaves future code free to change the meaning of “single-work profile v1” without changing durable identities.

### 3. The command and write-plan contracts remain implicit

The report says the owner accepts an “exact closed C2B command” and returns sealed advancing or non-advancing plans, but never freezes their field order, schemas, digest domains, branch unions, preassigned locators, or bounded cardinalities. :chatgpt-content-reference{index="6"}

That is material because the command digest governs:

- replay;
- mutation-ref reuse;
- current-head preimages;
- all preassigned result identities;
- definitely-not-committed proof;
- composed RW0-C recovery.

The current decision row itself has 43 ordered fields, including all basis, result, target, source, successor, reason, time, and digest fields.  The next report must give an exact per-branch projection over those fields rather than only a prose description of created rows.

### 4. Decision `reason_code` provenance is unresolved

The branch matrix defines versions, memberships, states, and edges, but it never says who owns the actual `reason_code` inserted into the C2B decision:

- copied from the Section 41 proposal;
- copied from another owner result;
- selected from a new closed C2B profile vocabulary;
- or supplied by the RW0-C caller.

The last option would be an authority error. The decision row’s `reason_code` is part of its canonical identity, so this cannot be left to implementation judgment. 

### 5. SQL and private-reader contracts are still conceptual

The report provides a high-level single-work query and CAS semantics, but not the literal private query contract needed for audit:

- exact columns;
- predicates;
- ordering;
- limits;
- tuple shapes;
- cardinality classification;
- collision queries;
- immutable insert SQL;
- CAS SQL;
- branch readback;
- recovery locators.

The proposed CAS order—work head first, program head second—is plausible, but an auditor cannot verify a contract that does not yet state its exact predicates and assignments. :chatgpt-content-reference{index="9"}

### 6. The mutation-graph contract is asserted, not reconciled

The report proposes exact role sequences for every branch. :chatgpt-content-reference{index="10"}

It does not prove that:

- each role string conforms to the current graph-entry grammar;
- ordinal and ordering behavior matches the current digest helper;
- the receipt envelope used in the digest is exact;
- no current graph meaning is being reinterpreted.

That must be resolved against the actual current graph owner before audit.

### 7. Recovery is not an exact value contract

The report gives a strong recovery concept but not:

- a recovery-selector schema;
- ordered selector fields;
- when it is constructible;
- every preassigned operation-owned locator;
- exact DNC absence routes;
- a recovery-result schema.

It also uses `committed_exactly`, while the merged RW0-C recovery vocabulary and the surrounding project work consistently use `committed_exact`. :chatgpt-content-reference{index="11"}

That may be a wording error, but a frozen composition contract cannot have ambiguous result vocabulary.

### 8. Global-stop historical reconstruction is not proven

The report correctly makes replay receipt-first and says later stop activation cannot invalidate replay. It records only the stop ref/version in the decision. :chatgpt-content-reference{index="12"}

The next pass must prove how historical stop state is reconstructed after the mutable current row advances:

- immutable stop history;
- command-bound state;
- receipt/graph projection;
- or another current owner mechanism.

It cannot implicitly rely on the later current row.

## What remains accepted

```text
C2B owner:
one branch-parameterized private family

advancing first profile:
single-work only

cancel:
non-version-advancing and membership-neutral

composition:
one controller, transaction, timestamp, and commit

migration 0002:
unchanged

migration 0005:
RW0-C-owned

latch:
RW0-C physical row; C2B accept-eligibility semantics only

implementation sequencing:
C2B and RW0-C may land in one candidate, but in separate owner modules
```

The proposed branch semantics are good enough to preserve as the starting point:

```text
accept:
accepted version, accepted program/work heads

repair:
repair version, active program, repair_required work

replan:
new intent revision, new same-work replan revision,
two supersession edges, active/planned heads

terminal reject:
terminal_rejected version and heads

block:
blocked version and heads under the sole-work profile

cancel:
decision and receipt only; no version or head mutation
```

:chatgpt-content-reference{index="13"}

# Next step

Run one final read-only freeze reconciliation that converts this conceptual owner design into an exact audit target. Do not implement and do not start the independent audit yet.

:chatgpt-content-reference{index="21"}[Download the C2B owner-freeze reconciliation prompt](sandbox:/mnt/data/Coordinator_C2B_Progression_Decision_Owner_Freeze_Reconciliation_V2_Prompt.txt)

```text
Filename:
Coordinator_C2B_Progression_Decision_Owner_Freeze_Reconciliation_V2_Prompt.txt

Size:
17,874 bytes

SHA-256:
4f0f84765e4ca53908327992e7030376b3c56edb5c906dd1ca9c26fec1c7d94d
```

The successful result is:

```text
C2B_PROGRESSION_DECISION_OWNER_FREEZE_RECONCILED_READY_FOR_INDEPENDENT_AUDIT
```

That result must include exact:

- path-correct sources;
- profile manifest and digest;
- command grammar;
- branch decision-row matrix and reason-code ownership;
- immutable write-plan schemas;
- literal private queries and CAS specifications;
- mutation-graph contract;
- result and completed-receipt digest;
- recovery selector and three-way result vocabulary;
- historical global-stop binding;
- composition seam;
- provisional path-derived implementation surface.

Only then should we commission an independent contract audit.

## Current project state

```text
RW0-C1:
merged and current

RW0-C-Decision C-local contract:
substantially reconciled

C2B progression semantics:
direction selected, exact owner freeze still incomplete

migration 0005:
not implementation-authorized

RW0-C-Terminal / migration 0006:
blocked on D/ES owner contracts

RW0-D / RW0-E:
not implemented
```

### Sources

- Attached C2B owner-reconciliation report. :chatgpt-content-reference{index="14"} :chatgpt-content-reference{index="15"} :chatgpt-content-reference{index="16"}
- Live merged source path and current program-row owner.  
- Current 43-field decision and receipt owner grammar.  

**Confidence:** High that the branch architecture and composition direction are sound; high that the current report is not exact enough for independent audit or implementation; high that the additional reconciliation can remain read-only and bounded.

Some older Project uploads have expired. The current attachment and live merged source were sufficient for this assessment; re-upload an older file only if the next pass specifically needs its contents.

# Decision

**Proceed to a fresh independent contract audit. Do not authorize implementation yet.**

Codex has closed the correct owner seam at the architectural level:

- C2B—not RW0-C—owns progression decisions, program/work post-states, immutable progression rows, head CAS, nested results and receipts, replay, and recovery.
- RW0-C may compose one private C2B facade into the same transaction, but C2B must not import or interpret C closure, latch, or terminal state.
- There remains one mutation slot, connection, timestamp, and commit attempt.
- Migration `0005` remains exclusively RW0-C-owned; the proposed C2B capability reuses the existing migration-`0002` schema. :chatgpt-content-reference{index="22"} :chatgpt-content-reference{index="23"}

That direction is sound. The next step is **not another parent self-reconciliation** and not implementation. It is an adversarial source-grounded audit of the proposed owner contract.

## What the report successfully freezes

The proposed first profile is now materially concrete:

| Branch | Proposed C2B-owned durable effect |
|---|---|
| Accept | New `accepted` program version; copied sole-work membership; accepted program/work heads |
| Repair | New `repair` program version; copied membership; active program head; `repair_required` work head |
| Replan | New accepted-intent revision, work revision, WorkSpec, `replan` version, two supersession edges, planned work head |
| Terminal reject | New `terminal_rejected` version; copied membership; terminal-rejected heads |
| Block | New `blocked` version; copied sole membership; blocked heads |
| Cancel | Decision and receipt only; no program version or head mutation |

:chatgpt-content-reference{index="24"}

The single-work profile is also a legitimate way to avoid silently inventing multi-work semantics. It treats zero membership as corruption, exactly one ordinal-zero membership as eligible, and two or more memberships as valid-but-unsupported rather than corrupt. It also resolves the otherwise ambiguous target of `program_block`, whose decision row does not name a work item. :chatgpt-content-reference{index="25"}

The report further specifies:

- version-membership behavior; :chatgpt-content-reference{index="26"}
- replan’s accepted-intent/work-revision and edge behavior; :chatgpt-content-reference{index="27"}
- work-head then program-head CAS, each requiring exactly one updated row; :chatgpt-content-reference{index="28"}
- receipt-first replay and global-stop handling; :chatgpt-content-reference{index="29"}
- branch-specific graph/result/receipt projections; :chatgpt-content-reference{index="30"}
- three-way recovery and atomic composition with the outer RW0-C family; :chatgpt-content-reference{index="31"}
- the correct latch split: C2B owns accept eligibility, while RW0-C owns the physical singleton and CAS. :chatgpt-content-reference{index="32"}

Those are substantial decisions, not placeholders.

## Why implementation is still premature

The report is ready to be audited, but it is not yet an implementation contract.

### 1. The private command and sealed plan grammars are not exact

The report says the owner accepts an “exact closed C2B command” and returns sealed plans, but it does not freeze:

- command schema ID and ordered fields;
- canonicalization and digest domain;
- which identities the caller preassigns;
- which values are owner-derived;
- exact expected-head fields;
- exact profile identity and digest;
- immutable plan/result/readback value fields;
- recovery selector fields;
- completed-receipt digest field order and domain.

:chatgpt-content-reference{index="33"}

That is acceptable for an audit input, but not for implementation. The audit must determine whether those are merely placement details or missing semantic contract.

### 2. Branch pre-state rules may be overbroad

The report gives all advancing branches the shared basis condition:

```text
program = active
work state ∈ {planned, active, repair_required}
```

:chatgpt-content-reference{index="34"}

That requires independent challenge. In particular:

- Can accept legitimately advance a `planned` or `repair_required` work item?
- Can repair start from `planned`?
- Are terminal reject and block legal from every listed state?
- Does replan have the same valid pre-state set as repair?
- Is work state irrelevant to cancel, provided its exact target effect/head is current?

These cannot be inferred from the existence of enum values.

### 3. The proposed insert order must be checked against actual foreign keys

The report inserts the progression decision before the result program version and later inserts WorkSpec and edges. :chatgpt-content-reference{index="35"}

That order is valid only if migration `0002`’s immediate/deferred foreign keys allow it. The audit must derive the actual topological order from `PRAGMA`-equivalent schema inspection or direct SQL reading—not accept the report’s sequence by assertion.

### 4. The nested receipt digest needs an exact contract

The report proposes a pure completed-receipt digest that is not persisted and is bound by RW0-C. That is a good approach, but its canonical field order and digest domain are not reported. :chatgpt-content-reference{index="36"}

Because that digest becomes the cross-owner binding between the C2B subgraph and RW0-C closure, ambiguity there is material.

### 5. Recovery terminology and mutable-head absence proof need review

The report uses `committed_exactly`, while RW0-C uses `committed_exact`. It also makes exact program/work head preimages part of `definitely_not_committed`. :chatgpt-content-reference{index="37"}

The audit should determine whether:

- this vocabulary distinction is deliberate and safely mapped;
- exact mutable-head preimages are retry-eligibility conditions rather than proof that the original transaction did not commit;
- later legitimate head advancement creates `unresolved` unnecessarily;
- the nested and outer recovery graphs cannot disagree.

### 6. The report contains a source-path inconsistency

Its principal-evidence paragraph refers to paths under:

```text
src/governed_execution_nwp_coordinator/...
```

:chatgpt-content-reference{index="38"}

The merged repository has previously used `src/ge_nwp_coordinator/...`. This may be a report typo rather than a substantive defect, but the audit must resolve the actual physical paths and classify any inaccurate references explicitly.

# Independent-audit handoff

Start a **new read-only Codex conversation** and attach both:

1. the audit prompt below; and
2. the exact current `Pasted text.txt` contract report.

:chatgpt-content-reference{index="43"}[Download the C2B progression-decision owner-contract independent audit prompt](sandbox:/mnt/data/Coordinator_C2B_Progression_Decision_Write_Owner_Contract_Independent_Audit_Prompt.txt)

```text
Filename:
Coordinator_C2B_Progression_Decision_Write_Owner_Contract_Independent_Audit_Prompt.txt

Size:
20,423 bytes

SHA-256:
85164acd32d8ecb1c4fcb0661d33ac550ccaf5221602aca8be576dc413f9547e
```

Fixed-input contract report:

```text
Filename:
Pasted text.txt

Size:
33,424 bytes

SHA-256:
3babfa419549f633c3f52a959639c46dad4eedde385ef82c66c4ac3a9affb673
```

The audit is instructed to return:

```text
ACCEPT

C2B_PROGRESSION_DECISION_WRITE_OWNER_CONTRACT_ACCEPTED_READY_FOR_IMPLEMENTATION_BOUNDARY_FREEZE
```

only when there is no Critical, High, Medium, or Low contract defect.

An acceptance result will **not** authorize implementation. The subsequent step would be a separate implementation-boundary freeze deriving exact value grammars, modules, touched paths, tests, validation order, and integration/audit sequencing.

## Current project state

```text
RW0-C1:
merged and current

RW0-C-Decision C-local contract:
reconciled but blocked on C2B owner acceptance

C2B progression-decision owner contract:
proposed; ready for independent audit

migration 0005:
not implementation-authorized

RW0-C-Terminal / migration 0006:
blocked on D/ES owner contracts

RW0-D / RW0-E:
not implemented
```

### Source

- Attached C2B progression-decision write-owner contract. :chatgpt-content-reference{index="39"} :chatgpt-content-reference{index="40"} :chatgpt-content-reference{index="41"} :chatgpt-content-reference{index="42"}

**Confidence:** High that the owner direction and single-transaction composition are correct; high that an independent contract audit is now the appropriate next gate; medium on implementation readiness because command/plan identities, branch pre-state rules, FK ordering, and the cross-owner receipt digest remain to be independently closed.

The current attachment was fully readable. Some older Project uploads have expired; re-upload a specific older file only if the independent audit needs to inspect it directly.
