# Decision

**Do not treat this as the independent audit. Send the contract back for one final reconciliation.**

Codex did not return the requested audit verdict:

```text
ACCEPT
C2B_PROGRESSION_DECISION_WRITE_OWNER_CONTRACT_ACCEPTED_READY_FOR_IMPLEMENTATION_BOUNDARY_FREEZE
```

or:

```text
BLOCK
```

Instead, it produced another substantially revised owner contract and ended with:

```text
C2B_PROGRESSION_DECISION_OWNER_FREEZE_RECONCILED_READY_FOR_INDEPENDENT_AUDIT
```

:chatgpt-content-reference{index="0"}

That revision contains valuable work: it corrects the repository paths, expands the command grammar, defines branch rows and postimages, gives literal CAS SQL, specifies graph/result/receipt shapes, and closes much of the recovery selector. But it still contains deterministic inconsistencies and unresolved owner boundaries. Sending it directly to audit would merely ask the auditor to rediscover defects already visible from the report.

## Blocking contract defects

### 1. The printed profile digest does not match the printed profile bytes

The response freezes:

```text
canonical manifest length:
7338 bytes

digest algorithm:
SHA-256(domain UTF-8 || NUL || canonical manifest bytes)

claimed digest:
8a8d67fb444c6d2a79f2a70f98f3dfa02baae0476b270396ea364e029100b4dc
```

and then prints the supposedly exact canonical JSON. :chatgpt-content-reference{index="1"}

Using that exact 7,338-byte JSON and the stated domain:

```text
governed-execution.nwp-development-progression-owner-profile.v1.identity
```

the digest is:

```text
9303a62e3a99d71745055faa11ba3d2611fb797982f9af6a749071dd44692f2d
```

not `8a8d67fb…`.

The report’s claim that Python and OpenSSL independently reproduced `8a8d67fb…` is therefore itself inconsistent with the exact bytes printed in the same report. This alone prevents the profile pair from being frozen.

Because the manifest must change again for the issues below, neither digest should be retained. Codex must regenerate the final manifest and independently recompute its identity only after all semantics are closed.

### 2. The C2B owner command is still semantically coupled to RW0-C/C1

The report says C2B is independently reusable, RW0-C imports one bounded C2B facade, and C2B does not import or interpret RW0-C. :chatgpt-content-reference{index="2"}

But the proposed C2B command directly includes:

```text
phase_basis_ref
phase_basis_digest
section41_membership_ref
section41_membership_digest
section41_post_execution_proposal_family_member_ref
section41_post_execution_proposal_family_member_digest
```

:chatgpt-content-reference{index="3"}

The report further requires C2B to validate that the C1 rank-15 membership and wrapped owner value belong to the phase. :chatgpt-content-reference{index="4"}

That is not merely a one-way module import. It makes C1 membership semantics part of the C2B owner command and recovery identity.

The cleaner authority split is:

- C2B consumes C2B rows plus exact Section 41 **owner-row** identities or a neutral owner projection.
- RW0-C owns the C1 phase, membership, closure, and proof that its rank-15 member resolves to that Section 41 family.
- The outer RW0-C attestation binds both sides.
- C2B never validates C1 membership semantics.

If a neutral composition-basis value is used, its exact schema, fields, digest, ownership, construction, and replay/recovery posture must be frozen. The current abstract evaluator argument named `basis` is not an adequate contract.

### 3. The accepted pre-contact block branch disappeared

The proposed profile has only one block branch:

```text
program_block
```

and all advancing commands require both the C1 rank-15 membership pair and the complete post-execution Section 41 family. :chatgpt-content-reference{index="5"}

The block precondition is consequently:

```text
exact selection
exact rank-15 recommendation = block
```

:chatgpt-content-reference{index="6"}

But the reconciled RW0-C decision contract already distinguishes:

- post-execution block; and
- pre-contact block based on explicit authority, custody, retrieval, readiness, qualification, head, or global-stop evidence. :chatgpt-content-reference{index="7"}

That contract also explicitly says missing evidence is not itself block evidence. :chatgpt-content-reference{index="8"}

The owner contract must therefore represent two authorization bases without changing the existing durable decision row:

```text
pre_contact_program_block
post_execution_program_block
```

Both may map to the existing:

```text
decision_kind = block
decision_variant = program_block
```

and the same C2B write graph. Their outer evidence basis differs. A pre-contact block must not fabricate a Section 41 post-execution family.

### 4. Productive direct-local latch eligibility has no exact input

The completed C2B receipt projection includes:

```text
fresh_productive_direct_local_accept_latch_eligible
```

and says it becomes true only when the result is productive and:

```text
adapter_kind = direct_local_bootstrap
```

:chatgpt-content-reference{index="9"}

But neither the 54-field command nor the rank-15 wrapper contains an exact route or productive-output proof. The report only says RW0-C supplies a “verified neutral basis,” without defining its schema or fields. :chatgpt-content-reference{index="10"}

The freeze must choose one authority split:

- **Preferred:** C2B proves the accept progression result; RW0-C computes the composite productive-direct-local latch eligibility from its closure and route evidence.
- **Alternative:** C2B receives a precisely defined neutral eligibility input containing the route and productive-result identity, binds it into the command/profile/receipt, and proves it without importing C1 or runtime semantics.

It cannot infer route or productivity from the Section 41 recommendation, evidence count, or graph digest.

### 5. The single-work query uses an unnecessary and potentially misleading 256-member boundary

The proposed profile uses:

```sql
LIMIT 257
```

and treats:

- rows 2–256 as a valid-but-unsupported multi-work profile;
- 257 rows as database corruption. :chatgpt-content-reference{index="11"}

For a profile whose only question is zero, exactly one, or more than one, the direct contract should normally be:

```sql
ORDER BY membership_ordinal, work_item_ref
LIMIT 2
```

The second row is sufficient to return:

```text
program_membership_profile_conflict
```

Using 257 is defensible only if a current owning contract establishes 256 as a hard total membership invariant. A bounded reader limit is not automatically a schema invariant.

### 6. The shared branch pre-state matrix remains a proposed semantic choice

The report permits accept, repair, replan, terminal reject, and block only when:

```text
program = active
work = planned or repair_required
```

:chatgpt-content-reference{index="12"}

That matrix may be reasonable, but it needs branch-specific ownership rationale:

- why accept from `repair_required` is valid;
- why repair from `planned` is valid;
- why `active` work is excluded;
- whether terminal reject or block may apply to active work;
- how repair’s `repair_required` post-state interacts with the current genesis-oriented author-effect establishment seam.

This should be explicitly versioned in the profile rather than presented as if existing enums alone prove it.

## What should remain preserved

The following parts are strong enough to carry forward:

- existing six decision variants and their current field nullability;
- version-advancing versus cancel behavior;
- single-work first-slice strategy;
- same-work replan;
- repair’s version-specific WorkSpec rebinding;
- work-head CAS before program-head CAS;
- no CAS for cancel;
- receipt-first replay;
- active-stop matrix;
- exact mutation-graph ordering;
- one common controller, transaction, timestamp, and commit attempt;
- no standalone C2B commit path;
- migration `0005` remaining RW0-C-owned;
- the migration-`0006` terminal owner blocker.

The current source also confirms that `program_block` deliberately has null selection fields and that `effect_cancellation` deliberately has no `target_delivery_attempt_ref`; those existing row meanings should remain untouched. 

# Next step

Send one final **read-only owner-contract reconciliation** to the same Codex conversation. Do not yet start the independent audit and do not authorize implementation.

:chatgpt-content-reference{index="23"}[Download the final C2B owner reconciliation prompt](sandbox:/mnt/data/Coordinator_C2B_Progression_Decision_Owner_Final_Reconciliation_Prompt.txt)

```text
Filename:
Coordinator_C2B_Progression_Decision_Owner_Final_Reconciliation_Prompt.txt

Size:
17,182 bytes

SHA-256:
ad82f9cd7ef24043e3e6c9e2e1c11f5a69f4873f1c35ddfdc45b91e72da8e8bf
```

The required successful result is:

```text
C2B_PROGRESSION_DECISION_OWNER_FINAL_RECONCILIATION_READY_FOR_INDEPENDENT_AUDIT
```

That result must include:

- one exact final profile manifest whose printed bytes reproduce its digest;
- an owner-neutral C2B command and basis;
- both pre-contact and post-execution block profiles;
- an explicit owner for productive-direct-local latch eligibility;
- a corrected single-work query;
- a branch-specific state matrix;
- updated command, plan, completed-receipt, replay, and recovery contracts.

Only then should the exact resulting report become the fixed input to a fresh independent contract audit.

## Current project state

```text
RW0-C1:
merged and current

RW0-C-Decision C-local contract:
reconciled but still waiting on C2B owner closure

C2B progression owner:
substantially specified, but final reconciliation required

migration 0005:
not implementation-authorized

RW0-C-Terminal / migration 0006:
blocked on D/ES owner contracts

RW0-D / RW0-E:
not implemented
```

### Sources

- Current attached C2B owner-contract revision. :chatgpt-content-reference{index="14"} :chatgpt-content-reference{index="15"} :chatgpt-content-reference{index="16"} :chatgpt-content-reference{index="17"} :chatgpt-content-reference{index="18"}
- Reconciled RW0-C block and snapshot contract. :chatgpt-content-reference{index="19"} :chatgpt-content-reference{index="20"}
- Current decision-row owner grammar.  

**Confidence:** High that the printed profile identity is invalid; high that pre-contact block and latch-eligibility ownership remain unresolved; high that one more bounded reconciliation is preferable to knowingly sending an inconsistent freeze to audit.

The current attachment was fully readable. Some older Project uploads have expired; re-upload one only if a later audit must inspect it directly.
