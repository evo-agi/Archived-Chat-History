PROMPT_ID

RW0_POST_EXECUTION_CANONICAL_AUDIT_ARTIFACT_DELIVERY_V1

TITLE

Coordinator RW0 — deliver the complete canonical post-execution owner-contract
audit package as one client-visible attachment after the accepted V40
operational-separation reconciliation

ENGAGEMENT TYPE

Parent-only, local, repository-read-only contract-package generation.

Do not delegate to subagents or internal audit agents.

Do not edit repository files, format repository files, stage, commit, push,
create a branch or PR, merge, tag, release, deploy, fetch, contact a remote or
live system, install dependencies, execute tests, run migrations, open or
mutate an operator database, invoke a product worker/model, or inspect/modify
supporting repositories.

You MAY create files only in one fresh private external temporary root for the
purpose of constructing the requested response attachment. Remove disposable
intermediate files before closeout. The final package file itself must be
returned through the client-visible response attachment/artifact mechanism.

A path under `/private/tmp`, `/tmp`, or any other local filesystem is not a
deliverable. Do not merely print such a path. If the response surface cannot
attach the complete file, return the blocker token below instead of claiming
success.

Do not issue an implementation prompt.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_POST_EXECUTION_CANONICAL_ARTIFACT_BASELINE_MISMATCH

FIXED INPUT REPORT

Treat the immediately preceding Codex response as fixed input.

If supplied as a file, use:

RW0_Post_Execution_V40_Reviewer_Separation_Reconciliation_Report.txt

Expected identity:

size:
14395 bytes

SHA-256:
c662e934c827bf6522ceab75f2386a285aebcacc7af234192a5b5db497d652f2

logical lines:
341

final newline:
absent

opening:
# Baseline and fixed input

closing token:
RW0_POST_EXECUTION_CANONICAL_AUDIT_PACKAGE_BLOCKED

If the fixed input differs, stop:

RW0_POST_EXECUTION_CANONICAL_ARTIFACT_FIXED_INPUT_MISMATCH

ACCEPTED SEMANTIC DECISIONS

Treat the following as frozen unless exact current repository ownership proves
a contradiction:

1. V40 is `PostExecutionReviewerSeparationEvaluationV1`, not an authenticated
   reviewer-person identity attestation.

2. V40 proves only operational separation of governed source roles,
   source-invocation refs, effect intents/fences, and deliveries.

3. V40 proves no distinct human, model, provider, account, credential, host,
   process, organization, cryptographic principal, source authenticity,
   external authority, review quality, acceptance, permission, or execution
   authority.

4. V40 uses the exact current C2A and C1 source graph:
   - one rank-12 `independent_review_completed` observation;
   - its same-phase membership and relation;
   - one rank-13 author worker-result binding;
   - every referenced rank-12 author observation, membership, and relation;
   - exact author/review command, delivery, attempt-fence, effect-fence,
     candidate, capsule, phase, program, work, and semantic-attempt lineage.

5. Review source kind is `independent_reviewer`; author worker source kind is
   `worker`.

6. One exact author source invocation is required for `separate`; the review
   source invocation must differ.

7. Author and review effect intent/fence/delivery identities must be distinct.
   Shared program/work/attempt/candidate/capsule lineage must remain coherent.

8. V40 result vocabulary is:
   - `separate`;
   - `not_separate`;
   - `unknown`;
   - `conflict`.

9. V15 integrates V40 as:
   - `separate` -> existing review source-outcome mapping;
   - `unknown` -> `unknown / reviewer_separation_unknown`;
   - `not_separate` ->
     `basis_conflict / review_not_operationally_separate`;
   - `conflict` ->
     `basis_conflict / reviewer_separation_conflict`.

10. Validation/review use current `WorkerObservationV1`.

11. Requirement evidence uses `requirement_ref` plus
    `safe_evidence_digest`; embedded `requirement_digest` is not the value
    self-digest.

12. Rank 14 uses the current generic C1 relation-binding row and literal current
    relation ID/version/profile/proof mode.

13. Candidate safe projection preserves the current `sha1`/40-hex owner domain
    and omits private entries.

14. Policy and risk matrices are owner-authored supplied attestations; local
    code validates exact identity and coherence without recreating external
    policy/risk meaning.

15. FiniteBacklog remains only a versioned compatibility adapter behind the
    generic risk interface.

16. The accepted two-context design, Section 41 projection V2, role-resolution
    V3, exact resupply, capsule privacy, complete C1 membership closure, bounded
    current snapshot, and pure-versus-forecast implementation boundary remain
    frozen.

17. C1 remains exactly 15 kinds.

18. No migration, persistence, public API, runtime, external contact,
    aggregate branch truth, C2B progression writer, latch, terminal, D/E, or
    Execution Substrate behavior is authorized.

DELIVERABLES

Return:

1. A complete concise substantive report inline.
2. Exactly one client-visible attached file named:

   `RW0_Post_Execution_Canonical_Audit_Package.jsonl`

The attachment is the complete fixed canonical corpus. It must not be replaced
by a filesystem path, a summary, a hash-only list, an omitted appendix, or a
promise of later delivery.

INLINE REPORT

The inline report must contain:

# Baseline and fixed input
# Preserved semantic decisions
# Final V40 contract
# Canonical artifact schema
# Artifact manifest summary
# Mechanical verification
# Supersession summary
# Finite assurance summary
# Remaining seams and stop conditions
# Recommended next step
# Confidence

It must print the attached file's exact:

- filename;
- byte size;
- SHA-256;
- logical line count;
- final-newline posture;
- record count by record type;
- first record ID;
- final record ID;
- content-aggregate SHA-256.

It must not attempt to include the package's full JSON inline.

CANONICAL ARTIFACT ENCODING

The attached file must be:

- UTF-8;
- one compact JSON object per physical line;
- LF line separators;
- no BOM;
- no blank lines;
- no final newline;
- duplicate keys forbidden;
- every record line canonicalized with:
  - exact built-in JSON values;
  - sorted keys;
  - separators `(",", ":")`;
  - `ensure_ascii=false`;
  - `allow_nan=false`;
  - no Unicode normalization.

Each physical line must use exactly this outer record grammar:

```json
{
  "digest_domain": "string or null",
  "domain_digest": "64-lowercase-hex or null",
  "payload_byte_length": 0,
  "payload_json": "exact compact sorted-key canonical JSON string",
  "payload_raw_sha256": "64-lowercase-hex",
  "record_id": "safe unique string",
  "record_index": 0,
  "record_type": "closed record type"
}
```

The physical line itself must be compact sorted-key canonical JSON.

`payload_json` is a JSON string whose decoded UTF-8 bytes are the exact complete
canonical JSON for that record's payload. It must parse with duplicate-key
rejection and re-encode byte-for-byte under the common canonicalization rules.

`payload_byte_length` and `payload_raw_sha256` apply to the decoded
`payload_json` bytes.

When `digest_domain` is non-null:

```text
domain_digest =
SHA256(UTF8(digest_domain) || NUL || UTF8(payload_json))
```

When no domain-separated identity is applicable, both `digest_domain` and
`domain_digest` are null.

CLOSED RECORD TYPES

Use exactly:

```text
package_manifest
source_owner_binding
value_schema
behavior_profile
golden_value
malformed_vector
module_allocation
import_edge
equality_matrix
assurance_case
supersession_entry
remaining_seam
package_closeout
```

RECORD ORDER

Record indexes are dense zero-based integers.

Order exactly:

1. `package_manifest`;
2. `source_owner_binding`, sorted by `record_id`;
3. `value_schema`, sorted by V-number then nested value ID;
4. `behavior_profile`, sorted by profile ref;
5. `golden_value`, sorted by semantic dependency order;
6. `malformed_vector`, sorted by test/vector ID;
7. `module_allocation`, sorted by V-number;
8. `import_edge`, sorted by source then target;
9. `equality_matrix`, sorted by role rank then boundary;
10. `assurance_case`, sorted by assurance ID;
11. `supersession_entry`, sorted by superseded record ID;
12. `remaining_seam`, sorted by seam ID;
13. `package_closeout`.

PACKAGE MANIFEST

The first record's payload must contain exactly:

```text
package_schema_id
package_version
baseline_commit
baseline_tree
fixed_input_sha256
accepted_decisions_id
record_type_counts
ordered_record_ids
ordered_payload_hashes
content_aggregate_sha256
created_at
whole_file_hash_location = external_inline_report
```

`created_at` is a report-construction timestamp only; it creates no product
fact or authority.

`content_aggregate_sha256` is:

```text
SHA256(
  UTF8(join(
    "\n",
    record_id + "\t" + payload_raw_sha256
    for every record after package_manifest and before package_closeout
    in physical order
  ))
)
```

The manifest itself and package-closeout record are excluded.

The `package_closeout` payload must repeat:

```text
package_schema_id
package_version
record_count
record_type_counts
first_record_id
last_content_record_id
content_aggregate_sha256
```

It must not contain the whole-file SHA-256.

The external whole-file SHA-256 is printed only in the inline report after the
final file bytes exist. This avoids self-reference.

REQUIRED PACKAGE CONTENT

The package must be self-contained and must not require an auditor to infer
canonical bytes from earlier reports.

A. SOURCE OWNER BINDINGS

Include complete source-owner records for at least:

- current `WorkerObservationV1`;
- current `WorkerCommandV1`;
- current `CandidateCapsuleManifestV1`;
- current validation requirement evidence;
- current review requirement evidence;
- current `RW0EffectHostQualificationV1`;
- current `GlobalStopState`;
- current `AttemptFenceV1`;
- current `EffectFenceV1`;
- current C1 rank-12 value/relation;
- current C1 rank-13 value/relation;
- current C1 rank-14 value/relation;
- current C1 rank-15 value;
- migration-0003 source invocation, proposal, evidence rows, evidence set, and
  owner-family graph rows.

Each record must identify exact current owner module/table, schema, fields,
identity/digest, relation/profile, and non-authority posture.

B. COMPLETE VALUE SCHEMAS

Include literal complete schema records for V01–V44 and every nested entry
value.

For every value print:

- value name;
- literal schema ID;
- local owner module;
- owner status;
- ordered fields one-by-one;
- exact built-in type for every field;
- nullability and grouped branch rules;
- enum vocabularies;
- list/tuple order and cardinality;
- unknown-field behavior;
- ref posture;
- ref prefix/domain/preimage/self-exclusions;
- digest domain/preimage/self-exclusions;
- canonicalization;
- nested-entry identity posture;
- governing profile pair or explicit no-separate-profile rationale;
- source of canonical bytes;
- local semantic action;
- exact owner relation;
- privacy/non-authority posture.

V35–V37 must be clearly marked forecast-only and prohibited from the current
pure-owner implementation boundary.

C. FINAL V40 GRAMMAR

Include the exact complete V40 schema with no shorthand.

The field inventory must bind enough exact current values and locators to
evaluate all frozen rules, including:

- schema/ref/digest;
- phase pair;
- rank-12 review membership/value/relation identity;
- rank-13 author result membership/value/relation identity;
- every author rank-12 member locator/value/relation needed to establish one
  source invocation;
- author and review source kind/ref/invocation;
- author/review effect intent/fence/delivery identity;
- author command and attempt-fence identity;
- shared program/work/attempt/candidate/capsule lineage;
- evaluator profile pair;
- support set pair;
- status/reason;
- evaluated_at.

Use only exact current owner fields that are reconstructible. Do not add human,
provider, model, account, credential, host, process, organization, or
cryptographic-principal fields.

D. COMPLETE BEHAVIOR PROFILES

Include the complete compact canonical JSON, byte length, raw SHA-256, digest
domain, and domain-separated digest for every current profile needed by the
package, including at minimum:

- post-execution semantic-review input;
- model-input binding;
- evidence supply;
- validation disposition;
- reviewer separation V40;
- independent-review disposition;
- support set;
- standing-policy matrix;
- risk-lane matrix;
- FiniteBacklog risk source;
- proposal-time global stop;
- source-effect ceiling;
- Section 41 proposal-family projection V2;
- Section 41 role resolution V3;
- membership closure;
- current snapshot;
- proposal currentness;
- decision-time authority matrix;
- decision-time global-stop matrix;
- decision-time source-effect ceiling matrix;
- recommendation consistency.

Every profile payload must contain its complete literal owner inventory and
finite behavior, not references to prose elsewhere.

E. COMPLETE GOLDEN VALUES

Include complete canonical golden JSON for at least:

- V01–V44 current values;
- every nested entry;
- all six support sets;
- rank-14 typed value and exact generic relation row;
- candidate safe projection;
- model-input safe projection and entries;
- private input manifest and entries;
- T1 input context;
- model-input binding;
- full evidence supply with all nine role supplies;
- source invocation;
- artifact binding when identity depends on changed context;
- nine proposal evidence rows;
- evidence set;
- proposal;
- owner-family graph input;
- Section 41 projection V2;
- rank-15 typed value;
- all nine role-resolution V3 values;
- membership closure;
- current snapshot;
- currentness/authority/stop/ceiling/recommendation-consistency values.

Synthetic values only. Do not include real credentials, endpoints, private
repository bodies, real candidate source, or secrets.

F. MALFORMED AND SUBSTITUTION VECTORS

Include every finite malformed/substitution vector frozen across the preceding
reconciliations, including:

- wrong context namespace;
- wrong role schema/ref/digest;
- wrong current C2A observation kind/source/outcome;
- requirement embedded digest substituted for `safe_evidence_digest`;
- wrong WorkSpec pair;
- wrong C1 rank-14 relation identity;
- candidate Git format `sha256` or wrong OID width;
- policy/risk source substitution;
- FiniteBacklog adapter substitution;
- global-stop branch mismatch;
- fence/expiry substitution;
- profile/value mismatch;
- V40 wrong role/invocation/effect/delivery/lineage;
- unsupported identity-authentication claim;
- stale superseded identity.

G. MODULE AND IMPORT DAG

Include one module-allocation record for every V01–V44 and nested value.

Include every allowed and forbidden import edge needed to prove:

- C2A/B1/B2/C1 import none of the new modules;
- new modules may privately import exact current owner values;
- generic risk never imports the FiniteBacklog adapter;
- the adapter imports generic risk values only;
- no package-root export or current production caller;
- V40 is pure derived local evaluation.

H. EQUALITY MATRIX

Include the complete T1/model-input/Section41/resupply/future-safe-retention
equality matrix for all nine roles, with exact schema/ref/digest/profile/source
binding/C1 membership/phase/lineage/privacy fields.

I. ASSURANCE MATRIX

Include the complete finite assurance matrix accumulated across all prior
reconciliations, plus the V40 operational-separation cases.

Permanent tests remain ordinary finite semantic and canonical-vector tests.
Independent audit owns external mutation, patch provenance, source-owner review,
and clean/live validation.

J. SUPERSESSION LEDGER

List every superseded context/profile/value/ref/digest from the prior fixed
input chain.

At minimum supersede:

- old combined context identity;
- previous T1/context/projection/profile identities;
- invented validation/review source schemas;
- widened candidate safe projection;
- invented standalone rank-14 classifier relation schema;
- old V40 identity-attestation class/schema/profile/ref/digest;
- every dependent V15/support/T1/supply/Section41/rank-15/role-resolution/
  RW0-C input identity changed by the V40 replacement.

No superseded identity may appear in a current profile or golden value except
inside a supersession record.

MECHANICAL VERIFICATION

Before reporting success:

1. Parse every physical line with duplicate-key rejection.
2. Verify dense record indexes and unique record IDs.
3. Decode and re-canonicalize every `payload_json` byte-for-byte.
4. Verify every payload byte length and raw SHA-256.
5. Verify every non-null domain-separated digest.
6. Recompute every generated ref, self-digest, support set, source binding,
   evidence binding, profile digest, T1 identity, proposal-family identity,
   Section 41 projection, rank-15 value, role resolution, closure, and snapshot.
7. Verify the manifest's ordered record IDs and hashes.
8. Verify the content aggregate.
9. Verify the closeout counts and aggregate.
10. Verify no superseded identity appears outside supersession records.
11. Verify the completed file from a second independent local reader and
    SHA-256 implementation.
12. Verify the repository baseline and cleanliness remained exact.

INLINE SUCCESS REPORT

On success, print:

- exact filename, size, SHA-256, lines, final-newline posture;
- record count and per-type counts;
- content aggregate;
- profile count;
- golden-value count;
- malformed-vector count;
- supersession count;
- V40 final schema/profile/ref/digest;
- confirmation that the file is visibly attached to the response;
- confirmation that no private/tmp path is being offered as the deliverable;
- the success token.

Do not print the corpus inline.

SUCCESS TOKEN

Return exactly:

RW0_POST_EXECUTION_CANONICAL_AUDIT_PACKAGE_COMPLETE_READY_FOR_INDEPENDENT_AUDIT

only if the client-visible attachment is present and every package verification
passes.

Otherwise return:

RW0_POST_EXECUTION_CANONICAL_AUDIT_ARTIFACT_DELIVERY_BLOCKED

and state whether the blocker is:

- attachment mechanism unavailable;
- package generation incomplete;
- canonical verification failure;
- source-owner contradiction;
- baseline mismatch.

A private filesystem path does not close the blocker.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
