Here is Codex's response:

# Baseline and inspection boundary

[current merged implementation] The required baseline matches exactly: branch `trunk_dev`; HEAD `a3ff0b7f4f0c2378c2962e24612d605489b51638`; tree `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0`; sole parent `047563de5a443b0f8323401c92979ae2e444d2ed`; subject `feat: implement RW0-C1 durable evidence (#7)`; upstream `origin/trunk_dev`; ahead/behind `0/0`; one worktree; clean index, worktree, untracked, and unmerged state.

[implementation detail] Inspection was parent-only, local, and read-only. No fetch, database open, test, migration, dependency installation, product worker/model invocation, or supporting-repository inspection occurred.

[current merged implementation] The inspected C1 test inventory was the eight `test_rw0_c1_*` modules plus [test_sqlite_rw0_c1_migration_0004.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_sqlite_rw0_c1_migration_0004.py:74>), which is the ninth C1 module for this scope.

[current owning contract] `.docs/` was treated as authoritative, with source and tests used to verify merged implementation rather than reinterpret owning contracts.

# Preserved decisions

[proposed frozen C contract] RW0-C remains decomposed into independently useful `RW0-C-Decision` and owner-blocked `RW0-C-Terminal`.

[proposed frozen C contract] RW0-C-Decision remains assigned to additive migration 0005, subject to the C2B owner reconciliation identified below.

[proposed frozen C contract] At most one decision closure and one bound C2B decision may exist for an exact `(phase_basis_ref, phase_basis_digest)` pair.

[proposed frozen C contract] Only productive direct-local `accept / candidate_acceptance` may consume the one-way latch, atomically with that decision.

[strategic target] Terminal acceptance later binds the exact committed consumed-latch postimage and never mutates, advances, repairs, or reopens it.

[reopened target seam] RW0-C-Terminal and migration 0006 remain blocked until D/ES owners provide exact physical reconciliation values, identities, schemas, and readers.

[proposed frozen C contract] An exact admitted `cancellation_rejected` observation maps fail-closed to terminal block; the wire value itself remains non-terminal evidence. The current wire contract classifies it as finite but explicitly denies terminal authority in [rw0-b2-wire-protocol.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-b2-wire-protocol.md:104>).

[strategic target] A `pre_effect_cancel_basis_unusable` terminal block requires an exact committed and recoverable `cancel / effect_cancellation` decision and exact mismatch evidence; it creates no replacement C2B block decision.

[current owning contract] Existing B1, B2, C1, C2A, C2B, Section 41, migrations 0001–0004, transaction ownership, writer fencing, and public surfaces remain unchanged.

[implementation detail] This report authorizes no implementation.

# Reconciled membership pagination and total ceiling

[current merged implementation] The C1 membership query is cursor-paginated by `(kind_rank, membership_ref)`, ordered ascending, with `LIMIT 257`; it is not a total-cardinality invariant. See [_sqlite_rw0_c1_reader_contracts.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_rw0_c1_reader_contracts.py:395>).

[current merged implementation] `_read_membership_page()` accepts a payload maximum from 1 through 256, returns only that many rows, and uses additional rows solely to produce `next_cursor`. See [_sqlite_rw0_c1_readers.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py:687>) and its two-page test in [test_rw0_c1_private_readers.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c1_private_readers.py:147>).

[current owning contract] C1 admits one member at a time, permits any dependency-closed partial phase, and asserts no completeness. See [rw0-c1-durable-evidence.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c1-durable-evidence.md:70>).

[proposed frozen C contract] RW0-C owns a separate ceiling named `RW0_C_DECISION_CLOSURE_MAX_MEMBERS`, fixed at `1024`. It is a C transaction-work ceiling, not a C1 fact-grammar limit.

[proposed frozen C contract] `1024` permits four full 256-member payload pages, preserves actual pagination, and gives decision evaluation a finite memory, read, digest, and recovery bound. It is intentionally independent of C1’s per-page limit and may be revised only by a new versioned C profile.

[proposed frozen C contract] The exact profile identity is:

```text
schema_id: governed-execution.nwp-rw0-c-decision-closure-profile.v1
profile_ref: rw0-c-decision-closure-v1
canonical_order: [kind_rank, membership_ref]
initial_cursor:
  after_kind_rank: 0
  after_membership_ref: cursor.start
page_payload_limit: 256
page_fetch_limit: 257
total_member_limit: 1024
termination: next_cursor_null
page_overflow: continue
total_overflow: decision_closure_member_limit_exceeded
snapshot_semantics: transaction_observed_exact_membership_set
```

[proposed frozen C contract] The proposed domain-separated profile digest is `96f9b6a05725066f2674674ca7cdd17eef61e8df1dee34a75f862dffbb1101d8`. It is a profile-identity digest, not a migration SQL checksum.

[report-only uncertainty] That proposed profile digest has not been independently reproduced by a second implementation during this read-only engagement and therefore remains an independent-audit item.

[proposed frozen C contract] The command identity and durable attestation both bind the profile ref, profile digest, payload limit, fetch limit, and total limit. The receipt binds the command digest.

[proposed frozen C contract] A 257th fetched row means only “another page exists.” It is never a total-overflow error and is never included in the current page.

[proposed frozen C contract] Total overflow occurs only when 1024 accepted members have been accumulated and the current page still returns a non-null cursor, or when accepting a row would raise the accumulated count above 1024.

[proposed frozen C contract] Total overflow raises the content-free reason `decision_closure_member_limit_exceeded`, rolls back, writes no closure, C2B decision, latch postimage, binding, or receipt, and is not converted into `program_block`.

[current owning contract] C1 may admit later memberships after any C decision, including after a cancel decision; C1 remains neither frozen nor complete merely because C captured a decision-time snapshot.

# Reconciled branch result-state matrix

[current merged implementation] Rank 14 has exactly `present`, `finite_failure`, and `absent`. `present` requires an exact rank-13 locator and forbids a failure reason; `finite_failure` forbids rank 13 and requires an admitted wire failure reason; `absent` forbids both. See [_rw0_c1_semantic_values.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_c1_semantic_values.py:794>).

[current merged implementation] Persistence tests prove all three physical forms: `(absent, NULL, NULL)`, `(finite_failure, NULL, short_header)`, and `(present, rank13_ref, NULL)`. See [test_rw0_c1_private_atomic_persistence.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c1_private_atomic_persistence.py:1693>).

[proposed frozen C contract] `X_present` means one selected rank-14 `present` membership plus its exact same-phase rank-13 result membership.

[proposed frozen C contract] `X_finite_failure` means one selected rank-14 `finite_failure` membership, no selected rank-13 result, and its exact admitted failure reason.

[proposed frozen C contract] `X_absent` means one selected rank-14 `absent` membership, no selected rank-13 result, and no failure reason.

[proposed frozen C contract] `X_conflicting` is a C-local block-only aggregate, not a fourth C1 result state. It requires at least two individually complete admitted rank-14 families whose identities or conclusions cannot coherently support one branch.

| Classification | C2 branch | Required result basis | Permitted | Forbidden | Required Section 41 family |
|---|---|---|---|---|---|
| proposed frozen C contract | `accept / candidate_acceptance` | Exactly one `X_present` | `present` | `finite_failure`, `absent`, `conflicting` | Complete `accept_candidate` |
| proposed frozen C contract | `repair / candidate_repair` | Exactly one of `X_present`, `X_finite_failure` | `present`, `finite_failure` | `absent`, `conflicting` | Complete `repair_candidate` |
| proposed frozen C contract | `replan / attempt_selecting_replan` | Exactly one of `X_present`, `X_finite_failure`, `X_absent` | All three C1 states | `conflicting` | Complete `replan` |
| proposed frozen C contract | `terminal_reject / program_terminal_reject` | Exactly one `X_present` | `present` | `finite_failure`, `absent`, `conflicting` | Complete `terminal_reject` |
| proposed frozen C contract | `post_execution_block / program_block` | One C1 state or `X_conflicting`, plus independent block evidence | `present`, `finite_failure`, `absent`, `conflicting` | None solely by result-state class | Complete `block`, or another exact block basis below |

[current merged implementation] Section 41’s post-execution recommendations are exactly `accept_candidate`, `repair_candidate`, `replan`, `terminal_reject`, and `block`, with nine canonical evidence roles when the evidence family is present. See [_cognitive_proposal_row_values.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_cognitive_proposal_row_values.py:430>) and [_cognitive_proposal_row_values.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_cognitive_proposal_row_values.py:455>).

[current owning contract] C1’s rank-15 wrapper proves either zero or exactly the complete nine-row family; it does not widen Section 41 or manufacture completeness. See [rw0-c1-durable-evidence.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c1-durable-evidence.md:92>).

[proposed frozen C contract] Missing rank 14, a missing required rank 13, an incomplete Section 41 family, or a missing required branch operand means “no decision yet” unless a separately enumerated exact block basis exists.

# Reconciled finite block semantics

[proposed frozen C contract] Every durable block has one exact `block_reason_code`, at least one reconstructable block-evidence entry, an exact evidence count, and a canonical evidence-set digest.

[proposed frozen C contract] Pre-contact reason codes and their minimum evidence are:

| Classification | Exact code | Required evidence |
|---|---|---|
| proposed frozen C contract | `pre_contact_authority_denied` | Current admitted authority observation with `status=denied` |
| proposed frozen C contract | `pre_contact_authority_unknown` | Current admitted authority observation with `status=unknown` |
| proposed frozen C contract | `pre_contact_authority_noncurrent` | Exact current owner verification proving revoked, expired, or otherwise non-current authority |
| proposed frozen C contract | `pre_contact_custody_unavailable` | Current admitted custody observation with `availability=unavailable` |
| proposed frozen C contract | `pre_contact_custody_unknown` | Current admitted custody observation with `availability=unknown` |
| proposed frozen C contract | `pre_contact_retrieval_failed` | Current admitted retrieval event `failed` |
| proposed frozen C contract | `pre_contact_retrieval_expired` | Current admitted retrieval event `expired` |
| proposed frozen C contract | `pre_contact_retrieval_revoked` | Current admitted retrieval event `revoked` |
| proposed frozen C contract | `pre_contact_retrieval_unknown` | Current admitted retrieval event `unknown` |
| proposed frozen C contract | `pre_contact_readiness_unready` | Current admitted readiness observation with `status=unready` |
| proposed frozen C contract | `pre_contact_readiness_unknown` | Current admitted readiness observation with `status=unknown` |
| proposed frozen C contract | `pre_contact_host_qualification_blocked` | Current admitted host qualification `result=blocked` and its exact owner reason |
| proposed frozen C contract | `pre_contact_host_qualification_unknown` | Current admitted host qualification `result=unknown` |
| proposed frozen C contract | `pre_contact_capability_qualification_blocked` | Current admitted mechanism qualification `result=blocked` and its exact reason |
| proposed frozen C contract | `pre_contact_capability_qualification_unknown` | Current admitted mechanism qualification `result=unknown` |
| proposed frozen C contract | `pre_contact_phase_program_head_diverged` | Phase program-head preimage plus exact differing current owner head |
| proposed frozen C contract | `pre_contact_phase_work_head_diverged` | Phase work-head preimage plus exact differing current owner head |
| proposed frozen C contract | `pre_contact_global_stop_active` | Exact current stop ref/version/state with `state=active` |

[current merged implementation] The relevant current owner vocabularies are authority `verified|denied|unknown`, readiness `ready|unready|unknown`, custody `available|unavailable|unknown`, qualification `qualified|blocked|unknown`, and retrieval `issued|redeemed|consumed|expired|revoked|failed|unknown`. See [_rw0_phase_entry_semantic_values.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:973>) and [_rw0_phase_entry_semantic_values.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:127>).

[current merged implementation] Mechanism capability qualification uses `qualified|blocked|unknown` with a closed reason vocabulary. See [_rw0_worker_mechanism_capability_values.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py:85>).

[proposed frozen C contract] Post-execution reason codes and their minimum evidence are:

| Classification | Exact code | Required evidence |
|---|---|---|
| proposed frozen C contract | `post_execution_section41_block` | Exact complete rank-15 Section 41 family recommending `block` |
| proposed frozen C contract | `post_execution_result_finite_failure` | `X_finite_failure` plus an exact complete block recommendation or explicit owner-negative block basis |
| proposed frozen C contract | `post_execution_result_absent_attested` | `X_absent` plus independent exact block evidence; absence alone is insufficient |
| proposed frozen C contract | `post_execution_owner_negative` | Exact current admitted owner-authored negative or unavailable value |
| proposed frozen C contract | `post_execution_owner_unknown` | Exact current admitted owner-authored unknown value |
| proposed frozen C contract | `post_execution_complete_branch_conflict` | Two or more complete contradictory branch families, all bound as evidence |
| proposed frozen C contract | `post_execution_phase_program_head_diverged` | Phase program-head preimage plus exact differing current owner head |
| proposed frozen C contract | `post_execution_phase_work_head_diverged` | Phase work-head preimage plus exact differing current owner head |
| proposed frozen C contract | `post_execution_global_stop_active` | Exact current stop ref/version/state with `state=active` |

[proposed frozen C contract] No generic “other failure” or free-form block code exists. A new owner condition requires a versioned contract change.

[proposed frozen C contract] Missing Coordinator rows never prove physical non-contact, external absence, permanent unavailability, process nonexistence, or source completeness.

[proposed frozen C contract] `X_absent` says only that the admitted C1 classifier supplied `result_state=absent`; it does not establish that no external result ever existed.

[proposed frozen C contract] A command’s expected-head mismatch is an apply conflict and creates no durable decision. A phase’s already-observed immutable head preimage differing from an exact current owner head may be block evidence because both sides of that divergence are explicit.

[proposed frozen C contract] Page incompleteness, total-ceiling overflow, missing required evidence, or an unprovable owner row yields failure or “no decision yet,” never a fabricated permanent `program_block`.

# Decision-time snapshot contract

[proposed frozen C contract] Enumeration occurs inside the same writer-fenced `BEGIN IMMEDIATE` transaction that would record the decision.

[proposed frozen C contract] Enumeration starts at `(0, "cursor.start")`, calls the existing C1 reader with `maximum=256`, and appends only returned payload entries.

[proposed frozen C contract] Every entry must match the exact phase, be strictly greater than its predecessor under `(kind_rank, membership_ref)`, and have a valid exact membership digest. Duplicate, non-monotone, foreign-phase, or malformed entries are database-integrity failures.

[proposed frozen C contract] A non-null cursor must equal the last accepted entry’s `(kind_rank, membership_ref)` and advances the next query. Enumeration terminates only when `next_cursor is None`.

[proposed frozen C contract] The snapshot persists dense `member_ordinal` values starting at zero, `member_count`, `enumeration_page_count`, and one ordered member-set digest over `(ordinal, kind_rank, membership_ref, membership_digest)`.

[proposed frozen C contract] The member-set digest domain is `governed-execution.nwp-rw0-c-decision-closure-member-set.v1.identity` and binds the exact phase pair, closure profile pair, member count, and ordered entries.

[proposed frozen C contract] One canonical whole-second UTC `decided_at` is captured after enumeration and before currentness evaluation and writes. It is used consistently by currentness checks, decision records, closure, attestation, binding, latch consumption, and receipts.

[current owning contract] C1 already distinguishes durable admission time from later decision-time currentness and requires C2 to establish its own currentness. See [rw0-c1-durable-evidence.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c1-durable-evidence.md:137>).

[proposed frozen C contract] The explicit persisted member rows—not timestamps—define the decision boundary. A later admission with the same whole-second timestamp is excluded because it is absent from the stored member set.

[proposed frozen C contract] The closure is an admission-time attestation of what this transaction observed, not a claim that the set remains C1’s current complete membership.

[proposed frozen C contract] Replay and committed recovery verify the stored closure, dense members, exact C1 membership foreign keys, count, canonical order, profile, and set digest. They do not re-enumerate current C1 membership and compare it for equality.

[proposed frozen C contract] Later C1 memberships therefore neither invalidate nor enlarge an earlier decision closure.

[strategic target] A later terminal transaction performs a new exact enumeration under its separately frozen terminal profile and may include evidence admitted after the C decision while still binding the original decision closure.

[proposed frozen C contract] No mutable C1 completeness head, “closed” flag, maximum-membership revision, or C-owned prohibition on later C1 admission is introduced.

# Acceptance-latch postimage contract

[proposed frozen C contract] The direct-binding option is selected. A consumed latch directly stores and digests:

```text
decision_ref
decision_digest
decision_closure_ref
decision_closure_digest
result_projection_digest
program_ref
program_version_ref
program_version_digest
candidate_ref
capsule_manifest_ref
portable_capsule_digest
consumed_at
latch_postimage_digest
```

[proposed frozen C contract] The seed identity is:

```text
schema_id: governed-execution.nwp-development-first-slice-latch.v1
latch_ref: direct_local_first_productive_acceptance
scope_kind: global_coordinator_bootstrap
state: available
version: 0
all consumed-binding fields: null
```

[proposed frozen C contract] The proposed seed postimage digest is `c37db374f32c4364eb12fb2820fae2cb3e2e370e81bcd1bb7c0fb844932ef0be`.

[report-only uncertainty] The seed digest remains subject to independent reproduction against the final literal row-value constructor; it is not a migration SQL checksum.

[proposed frozen C contract] The only legal mutation is an exact CAS from `available/version=0` to `consumed/version=1` in a productive direct-local accept transaction. All consumed-binding fields become non-null together.

[proposed frozen C contract] Repair, replan, terminal reject, block, cancel, replay, and recovery perform no latch update.

[proposed frozen C contract] Digest construction is acyclic: decision and closure precede the outer result projection; that result projection intentionally excludes the latch digest; the latch postimage binds the result projection; the binding then binds the latch postimage; the final receipt and mutation graph bind all preceding records.

[proposed frozen C contract] The binding/result and latch relation uses deferred reciprocal foreign keys: the binding’s latch pair points to the consumed latch, and the latch’s result projection points to the binding’s unique outer result projection. Full in-transaction readback must close the cycle before commit.

[proposed frozen C contract] A copied database remains valid only if the complete consumed-latch family is present and coherent. A consumed latch without its decision, closure, binding, result, program version, or candidate relation is a foreign-key or readback integrity failure.

[strategic target] Terminal acceptance binds the exact latch ref and postimage digest from the committed accept decision. Terminal recovery cannot consume the latch again.

# Verified C2B write-side matrix

[current merged implementation] C2B’s closed state vocabularies are program states `active|accepted|terminal_rejected|blocked`, version kinds `initial|accepted|repair|replan|terminal_rejected|blocked`, work states `planned|active|accepted|repair_required|terminal_rejected|blocked`, work revision kinds `initial|replan`, and four revision-edge kinds. See [_development_program_row_values.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_program_row_values.py:202>).

[current merged implementation] C2B’s decision row/value implementation freezes field nullability and variant identity, but the structured owner record explicitly says progression mutation is not implemented. See [_development_decision_row_values.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:556>) and [c2b-durable-development-state.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:2843>).

[current owning contract] Advancing decisions append versions; redeliver and cancel do not. See [c2b-durable-development-state.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:217>).

[current merged implementation] The nested progression result is exactly `(schema_id, program_ref, decision_ref, result_program_version_ref, result_decision_ref)`, with `result_decision_ref == decision_ref`. See [_development_decision_row_values.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:873>) and [test_c2b2_field_level_contract.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b2_field_level_contract.py:6133>).

[current owning contract] For accept, repair, replan, terminal reject, and block, that nested result uses the new resulting version. For cancel it uses the unchanged basis version. See [c2b-durable-development-state.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:7196>).

[current owning contract] A fresh active global stop blocks accept, repair, and productive replan, but permits terminal reject, block, and cancel; exact replay precedes stop/head checks. See [c2b-durable-development-state.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:503>).

| Classification | Branch | Verified fields and result | Head/revision/edge proof | Stop behavior | Finding |
|---|---|---|---|---|---|
| current merged implementation | `accept / candidate_acceptance` | Basis, new result version, and selection are required; target, source, preassignment, result-intent, and result-work groups are null. See [test_c2b2_field_level_contract.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b2_field_level_contract.py:1958>). Version kind is `accepted`; nested receipt uses the new version. | Program state `accepted`, work state `accepted`, exact head CAS, absence of a new work revision, and edge behavior are not frozen by a current mutation contract. | Fresh active stop blocks. | Owner reconciliation required. |
| current merged implementation | `repair / candidate_repair` | Basis, new result version, selection, and preassigned successor attempt/candidate are required; other groups are null. See [test_c2b2_field_level_contract.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b2_field_level_contract.py:1993>). Version kind is `repair`; nested receipt uses the new version. | Program state, `repair_required` work-state transition, exact work-head CAS, revision retention, and edge behavior are not frozen. | Fresh active stop blocks. | Owner reconciliation required. |
| current merged implementation | `replan / attempt_selecting_replan` | Basis, new result version, selection, successor attempt/candidate, resulting accepted-intent revision, work item, and work revision are required. See [test_c2b2_field_level_contract.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b2_field_level_contract.py:2064>). Version kind is `replan`; nested receipt uses the new version. | Whether the work item is new or existing, exact revision number/kind/prior ref, program/work post-states, and required accepted-intent/work supersession or split/merge edges are not frozen. | Fresh productive replan is blocked. | Owner reconciliation required. |
| current merged implementation | `terminal_reject / program_terminal_reject` | Basis, new result version, and selection are required; other variant groups are null. See [test_c2b2_field_level_contract.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b2_field_level_contract.py:2105>). Version kind is `terminal_rejected`; nested receipt uses the new version. | Program/work terminal-state mapping, exact work-head mutation, and revision behavior are not frozen. | Fresh operation is permitted under active stop. | Owner reconciliation required. |
| current merged implementation | `block / program_block` | Basis and new result version are required; selection, target, source, preassignment, result-intent, and result-work groups are null. See [test_c2b2_field_level_contract.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b2_field_level_contract.py:2141>). Version kind is `blocked`; nested receipt uses the new version. | The decision names no work item, so which work head, if any, becomes `blocked` is not owner-frozen. Program/work post-state and CAS relations are unproved. | Fresh operation is permitted under active stop. | Owner reconciliation required. |
| current owning contract | `cancel / effect_cancellation` | Basis, selection, target effect/head, originating command, source directive/evidence, and preassigned cancellation effect/fence/delivery are required; result version, target delivery, successor attempt, result-intent, and result-work are null. Author targets forbid capsule fields; validate/review targets require them. See [test_c2b2_field_level_contract.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b2_field_level_contract.py:2259>). | No program version or head advances; program and target revisions are checks, and later cancellation-effect establishment owns target CAS. See [c2b-durable-development-state.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:286>). | Permitted under active stop. | Compatible without reinterpretation. |

[current owning contract] The C2B reader contract explicitly says the `work_state_revision_kind_relation` is “not frozen by this reader contract.” See [c2b-durable-development-state.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:5821>).

[reopened target seam] C2B assigns accept, repair, replan, terminal reject, block, latch, and version/head recovery to the future C2B6 tranche. See [c2b-durable-development-state.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:981>).

[reopened target seam] Freezing the missing post-state, work-revision, supersession-edge, and CAS relationships inside RW0-C would create or reinterpret C2B-owned semantics. The governing result is therefore `RW0_C_OWNER_RECONCILIATION_REQUIRED`.

# Decision closure/member/attestation schemas

[proposed frozen C contract] Subject to C2B reconciliation, migration 0005 has six tables:

```text
rw0_c_decision_closures
rw0_c_decision_closure_members
rw0_c_decision_attestations
rw0_c_decision_bindings
development_first_slice_latch
rw0_c_decision_mutation_receipts
```

[proposed frozen C contract] `rw0_c_decision_closures` has this exact proposed order:

```text
schema_id
closure_ref
mutation_ref
command_schema_id
command_digest
phase_basis_ref
phase_basis_digest
program_ref
closure_kind
closure_profile_ref
closure_profile_digest
page_payload_limit
page_fetch_limit
total_member_limit
enumeration_page_count
member_count
member_set_digest
enumeration_state
decision_ref
decision_digest
decision_kind
decision_variant
result_basis_class
result_membership_ref
result_membership_digest
classification_membership_ref
classification_membership_digest
result_failure_reason
section41_membership_ref
section41_membership_digest
section41_recommendation
block_reason_code
block_evidence_count
block_evidence_set_digest
expected_program_head_revision
expected_work_item_head_revision
global_stop_ref
global_stop_version
decided_at
closure_digest
```

[proposed frozen C contract] `closure_kind` is exactly `post_execution`, `pre_contact_block`, or `effect_cancellation`; `enumeration_state` is exactly `exhausted`.

[proposed frozen C contract] `post_execution` requires a result basis and Section 41 fields under the branch matrix. `pre_contact_block` requires `decision_kind=block`, null result/Section 41 fields, and non-null block fields. `effect_cancellation` requires `decision_kind=cancel`, null result/Section 41/block fields, and the exact bound C2B cancel decision.

[proposed frozen C contract] `result_basis_class` is nullable outside post-execution and otherwise exactly `present|finite_failure|absent|conflicting`. Present requires both result and classification membership pairs; finite failure requires no result pair, one classification pair, and one failure reason; absent requires no result pair, one classification pair, and no failure reason; conflicting requires no selected classification pair and at least two marked conflicting members.

[proposed frozen C contract] Closure constraints include primary key `closure_ref`; unique `mutation_ref`; unique exact phase pair; unique decision ref; and unique `(closure_ref, closure_digest)`. The phase pair has an immediate FK to `rw0_phase_instances`; the decision FK is deferred because the C2B decision and closure commit atomically.

[proposed frozen C contract] `rw0_c_decision_closure_members` has this exact proposed order:

```text
schema_id
closure_ref
member_ordinal
phase_basis_ref
phase_basis_digest
kind_rank
membership_ref
membership_digest
block_evidence_ordinal
member_digest
```

[proposed frozen C contract] Its primary key is `(closure_ref, member_ordinal)`; it has unique `(closure_ref, membership_ref)` and unique `(closure_ref, block_evidence_ordinal)` for non-null block ordinals; and it uses the existing exact C1 composite FK `(phase_basis_ref, phase_basis_digest, membership_ref, membership_digest)`. That C1 unique key exists in migration 0004 at [0004_rw0_c1_durable_evidence.sql](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql:150>).

[proposed frozen C contract] Dense member and block-evidence ordinals, member count, order, and digests are verified by bounded reader reconstruction and guarded readback; they are not inferred from SQL row count alone.

[proposed frozen C contract] `rw0_c_decision_attestations` has this exact proposed order:

```text
schema_id
attestation_ref
closure_ref
closure_digest
phase_basis_ref
phase_basis_digest
closure_profile_ref
closure_profile_digest
page_payload_limit
page_fetch_limit
total_member_limit
enumeration_page_count
member_count
member_set_digest
enumeration_state
decision_ref
decision_digest
decision_kind
decision_variant
result_basis_class
result_membership_ref
result_membership_digest
classification_membership_ref
classification_membership_digest
result_failure_reason
section41_membership_ref
section41_membership_digest
section41_recommendation
block_reason_code
block_evidence_count
block_evidence_set_digest
program_head_revision
program_head_digest
program_state
work_item_head_revision
work_item_head_digest
work_state
selection_head_revision
selection_head_digest
effect_head_revision
effect_head_digest
effect_head_state
delivery_head_revision
delivery_head_digest
delivery_head_state
global_stop_ref
global_stop_version
global_stop_state
latch_preimage_digest
attested_at
attestation_digest
```

[proposed frozen C contract] The attestation has primary key `attestation_ref`, unique `closure_ref`, unique `(attestation_ref, attestation_digest)`, and an immediate FK to the closure pair. It repeats closure-critical identity intentionally so recovery can prove equality rather than rely on an unverified join.

[proposed frozen C contract] The block-evidence-set digest contains role-tagged entries from marked C1 members and, where the reason requires them, the exact program head, work head, or global-stop postimage in this attestation.

[proposed frozen C contract] `rw0_c_decision_bindings` has this exact proposed order:

```text
schema_id
binding_ref
closure_ref
closure_digest
attestation_ref
attestation_digest
decision_ref
decision_digest
decision_kind
decision_variant
development_mutation_ref
result_program_version_ref
result_program_version_digest
development_result_projection_digest
development_mutation_graph_digest
outer_result_projection_digest
latch_postimage_ref
latch_postimage_digest
bound_at
binding_digest
```

[proposed frozen C contract] The binding has primary key `binding_ref`; unique closure, attestation, decision, and outer-result identities; deferred FKs to the closure/decision family; and an accept-only latch pair. Every non-accept branch requires both latch fields null.

[proposed frozen C contract] `development_first_slice_latch` has this exact proposed order:

```text
schema_id
latch_ref
scope_kind
state
version
decision_ref
decision_digest
decision_closure_ref
decision_closure_digest
result_projection_digest
program_ref
program_version_ref
program_version_digest
candidate_ref
capsule_manifest_ref
portable_capsule_digest
consumed_at
latch_postimage_digest
```

[proposed frozen C contract] Its primary key is `latch_ref`; the ref and scope are fixed constants; the available and consumed shapes are mutually exclusive; and deferred FKs close the accept binding/result cycle.

[proposed frozen C contract] `rw0_c_decision_mutation_receipts` has this exact proposed order:

```text
schema_id
mutation_ref
mutation_family
command_schema_id
command_digest
phase_basis_ref
phase_basis_digest
closure_ref
closure_digest
attestation_ref
attestation_digest
binding_ref
binding_digest
decision_ref
decision_digest
development_mutation_ref
development_result_projection_digest
development_mutation_graph_digest
result_class
result_projection_digest
mutation_graph_digest
outcome
committed_at
receipt_digest
```

[proposed frozen C contract] The receipt fixes `mutation_family=record_rw0_c_decision`, `result_class=rw0_c_decision_recorded`, and `outcome=committed`; it is written last and has immediate or deferred FKs to every local family required for exact replay.

# Migration 0005 revised exact freeze

[current merged implementation] The current tip is migration 0004, application generation 2, with 62 user tables, 110 triggers, and five explicit indexes. See [sqlite_migration.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migration.py:388>), [sqlite-bootstrap-and-migrations.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/sqlite-bootstrap-and-migrations.md:627>), and [test_sqlite_rw0_c1_migration_0004.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_sqlite_rw0_c1_migration_0004.py:100>).

[compatibility edge] Historical C2B text assigning a different migration 0003 inventory is superseded; the merged migration 0003 owns cognitive proposal/selection state, and 0004 owns C1.

[proposed frozen C contract] The provisional catalog entry is sequence 5, migration ID `0005_rw0_c_decision_state`, application bounds `[2,2]`, non-destructive, and one literal SQL resource.

[proposed frozen C contract] It contains six `CREATE TABLE` statements, twelve triggers, two explicit indexes, and one latch-seed `INSERT`, for a provisional total of 21 migration statements.

[proposed frozen C contract] Five immutable tables each receive no-update and no-delete triggers. The latch receives one no-delete trigger and one one-way available-to-consumed update guard.

[proposed frozen C contract] The two explicit indexes are:

```text
idx_rw0_c_decision_closure_members_phase_order
  ON rw0_c_decision_closure_members
     (phase_basis_ref, kind_rank, membership_ref, closure_ref)

uq_rw0_c_decision_bindings_result_projection
  UNIQUE ON rw0_c_decision_bindings
     (outer_result_projection_digest)
```

[proposed frozen C contract] Provisional cumulative inventory is 68 user tables, 122 triggers, and seven explicit indexes.

[proposed frozen C contract] Fresh initialization would apply migrations 0001 through 0005. Explicit administrative migration would apply only the complete contiguous suffix from an exact supported prefix. Inspection, validation, writer acquisition, and product mutation would admit only exact tip 0005.

[proposed frozen C contract] `CURRENT_APPLICATION_SCHEMA` remains 2, SQLite 3.37.0 remains the pre-write minimum, and all existing migration lock, catalog equality, readback, rollback, and uncertainty behavior remains unchanged.

[proposed frozen C contract] Proposed readers use explicit ordered columns and these bounds:

```text
decision_receipt_by_mutation_ref             LIMIT 2
decision_closure_by_phase_basis              LIMIT 2
decision_closure_by_ref                      LIMIT 2
decision_closure_members_page                LIMIT 257
decision_attestation_by_closure              LIMIT 2
decision_binding_by_closure                  LIMIT 2
decision_binding_by_result_projection        LIMIT 2
first_slice_latch_by_ref                     LIMIT 2
```

[proposed frozen C contract] `decision_closure_members_page` is ordered by `member_ordinal ASC`, exposes at most 256 payload rows, and uses row 257 only as lookahead.

[report-only uncertainty] No final SQL exists, so no literal SQL byte count, statement parser proof, or SQL checksum can be truthfully reported.

[reopened target seam] Because the exact C2B work-head/revision/edge/post-state matrix is not owner-frozen, this remains a C-local internally structured proposal rather than an authorized final migration 0005 freeze.

# Decision readers, transaction, replay, and recovery

[current owning contract] The existing Coordinator mutation controller remains the sole owner of the mutation slot, operation lease, connection, `BEGIN IMMEDIATE`, writer fence, nominal capability, commit attempt, uncertainty state, and cleanup.

[proposed frozen C contract] The transaction order is:

1. operation guard and mutation slot;
2. `BEGIN IMMEDIATE`;
3. writer fencing;
4. C receipt lookup and exact replay classification;
5. exact C1 phase read;
6. paginated membership enumeration;
7. one transaction timestamp;
8. current program/work/selection/effect/delivery/global-stop and required owner reads;
9. branch-specific evidence/currentness evaluation;
10. C2B plan construction under the owner-approved matrix;
11. C2B decision/version/head/revision/edge writes;
12. closure members, closure, attestation, and development result construction;
13. accept-only latch CAS;
14. binding and outer result;
15. C receipt last;
16. complete in-transaction readback;
17. capability invalidation;
18. exactly one commit attempt;
19. cleanup before result publication.

[proposed frozen C contract] No external I/O, worker, model, Bridge, ES, Git, capsule store, validation executor, or reviewer runs inside or after this mutation as part of the transaction.

[proposed frozen C contract] Same mutation ref plus the same canonical command digest returns exact replay without new enumeration, timestamp, C2B write, or latch mutation. Same ref with another digest is a mutation-ref reuse conflict.

[proposed frozen C contract] Fresh replay classification remains receipt-first after writer fencing, so a committed operation is replayable even when current heads, stop state, or later C1 membership have changed.

[proposed frozen C contract] A commit-attempt exception returns `commit_outcome_unknown`; automatic retry is forbidden.

[proposed frozen C contract] Recovery returns `committed_exact` only when the exact C receipt, closure, dense members, attestation, binding, C2B decision/result/receipt/version graph, and accept-only latch postimage all reconstruct and match.

[proposed frozen C contract] Recovery returns `definitely_not_committed` only when every mutation-addressed C and C2B record is absent and the latch remains at the exact preimage.

[proposed frozen C contract] Any partial family, digest mismatch, impossible branch, missing result, unexpected latch state, conflicting semantic identity, unreadable row, or mixed complete/absent cross-owner graph is `unresolved`.

[proposed frozen C contract] Recovery verifies the historical member rows stored in the closure; it never incorporates memberships admitted later.

[reopened target seam] Steps 10–11 cannot be frozen or implemented until C2B owns the exact advancing-branch write plans.

# Assurance and independent-audit matrix

| Classification | Reconciliation item | Result |
|---|---|---|
| current merged implementation | C1 `LIMIT 257` interpretation | Proven to be page lookahead, not a total ceiling. |
| proposed frozen C contract | Separate total ceiling | Named and fixed at 1024; bound in command, profile, closure, and attestation. |
| proposed frozen C contract | Page overflow versus total overflow | Distinct; only total overflow raises `decision_closure_member_limit_exceeded`. |
| proposed frozen C contract | Rank-14 branch matrix | Present, finite failure, and absent are represented without inventing rank 13. |
| proposed frozen C contract | Absence safety | Missing membership and `X_absent` do not become external-negative truth. |
| proposed frozen C contract | Block grammar | Finite codes and exact evidence requirements are closed. |
| proposed frozen C contract | Snapshot semantics | Explicit ordered members, count, digest, and transaction observation; timestamps are not boundaries. |
| proposed frozen C contract | Later C1 admissions | Legal and excluded from replay of the earlier closure. |
| proposed frozen C contract | Latch postimage | Directly binds decision, closure, result, version, candidate, and capsule. |
| current merged implementation | C2B decision nullability/result envelope | Verified for all six requested branches. |
| reopened target seam | C2B program/work post-state, revision, edge, and CAS matrix | Not frozen; owner reconciliation required. |
| reopened target seam | Migration 0005 finality | Physical C-local shape is reconciled, but final authorization is blocked by C2B. |
| reopened target seam | Terminal owner values/readers | Still absent; migration 0006 remains blocked. |
| implementation detail | Tests and migrations | Not executed by instruction. |

# Provisional implementation surface and protected set

[reopened target seam] The only provisional future surface is one additive private RW0-C decision contract/value/reader/mutation/recovery family, one migration 0005 resource and catalog entry, corresponding private tests, and synchronized `.docs/` records.

[implementation detail] That surface is an inventory for later review, not an implementation prompt or authorization.

[current owning contract] Protected and unchanged surfaces include migrations 0001–0004; migration 0002 C2B schema; migration 0003 Section 41 schema; migration 0004 C1 schema; all B1, Wire, Capability, C2A, C1, and C2B semantic values; the frozen C2B reader inventory; Section 41 identities; the mutation controller; writer-session authority; public `StateStore` and `WriterSession` surfaces; and all Bridge/ES boundaries.

[reopened target seam] No C-local implementation may select program/work post-states, create a new C2B variant, reinterpret a decision field, invent a work revision, or choose revision edges on C2B’s behalf.

# Terminal owner blocker

[current merged implementation] A pure `RW0TerminalOutcomeV1` shape exists and carries decision, head, evidence, latch, reconciliation, and mismatch identities. See [_rw0_phase_entry_semantic_values.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:746>).

[current owning contract] Its four semantic branches are `normal`, `active_cancel_reconciled`, `active_cancel_unresolved`, and `pre_effect_cancel_basis_unusable`. See [_rw0_phase_entry_semantic_values.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:1055>).

[reopened target seam] The merged owner contract explicitly defers terminal identity, digest, row, receipt, graph, table, migration, application-generation, and public representation. See [rw0-remote-worker-contact-phase-entry.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:384>).

[reopened target seam] Exact merged values/readers still do not prove process-group and descendant reconciliation, authenticated teardown, terminal capsule custody/retrieval, delivery/source receipt closure, route/source currentness, or the direct-local/ES routing distinction.

[current owning contract] Request, acknowledgement, signal, process exit, and workspace teardown remain separate facts, and only complete non-ambiguous source reconciliation can support terminal cancellation. See [rw0-remote-worker-contact-phase-entry.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:299>).

[current owning contract] ES owns ES admission, reliable submit, runtime lifecycle, cancellation, runtime identity, credentials, and retained results; direct-local owns only its route-local process control and source-native facts. See [rw0-remote-worker-contact-phase-entry.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:415>).

[reopened target seam] The required blocker remains:

```text
TERMINAL_OWNER_RECONCILIATION_REQUIRED
```

[reopened target seam] Migration 0006 and any partial terminal schema remain forbidden.

# Forecasts and stop conditions

[report-only uncertainty] No implementation-readiness forecast is valid until C2B freezes the missing advancing-decision write relationships.

[strategic target] After that owner decision, an independent audit can determine whether the C-local migration 0005 proposal closes cleanly without changing existing owner semantics.

[reopened target seam] Work must stop if owner reconciliation requires a new C2B field or variant, changes an existing branch’s nullability, changes migration 0002, widens public APIs, or assigns C ownership over C2B progression state.

[reopened target seam] Work must also stop if the 1024-member ceiling, profile identity, latch digest graph, or direct latch binding changes without a versioned C contract.

[reopened target seam] Terminal work remains stopped until every terminal owner item listed above has a merged exact value and reader contract.

[implementation detail] A baseline change requires a new read-only reconciliation against that new commit before relying on this report.

# Recommended next step

[reopened target seam] Conduct one owner-only, read-only C2B contract reconciliation that freezes, for accept, repair, replan, terminal reject, and block:

- exact program-head post-state;
- exact work-head post-state and targeted work identity;
- whether a new work revision is created;
- exact work-revision kind, number, prior ref, and accepted-intent relation;
- required accepted-intent and work supersession/split/merge edges;
- program/work CAS ownership and ordering;
- exact recovery graph for the progression receipt.

[implementation detail] Do not authorize migration 0005 implementation until that owner record is merged and the revised C contract receives independent audit.

# Confidence

[current merged implementation] Confidence is high in the baseline, C1 pagination finding, rank-14 state algebra, Section 41 vocabulary, migration inventory, C2B decision nullability, nested result envelope, cancel behavior, and absence of a merged progression mutation.

[proposed frozen C contract] Confidence is medium-high in the reconciled C-local pagination, snapshot, block, latch, and six-table design.

[report-only uncertainty] Confidence cannot be elevated to implementation-ready because the exact advancing C2B write-side relations and final SQL/checksum do not exist.

RW0_C_OWNER_RECONCILIATION_REQUIRED

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
RW0_C_DECISION_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
