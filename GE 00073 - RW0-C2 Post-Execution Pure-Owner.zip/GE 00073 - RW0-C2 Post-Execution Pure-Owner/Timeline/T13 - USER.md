Here is Codex's response:

# Baseline and fixed-input identity

[current merged implementation] The required baseline matches exactly, without fetch:

| Fact | Verified value |
|---|---|
| Branch | `trunk_dev` |
| HEAD | `a3ff0b7f4f0c2378c2962e24612d605489b51638` |
| Tree | `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0` |
| Sole parent | `047563de5a443b0f8323401c92979ae2e444d2ed` |
| Subject | `feat: implement RW0-C1 durable evidence (#7)` |
| Upstream | `origin/trunk_dev` |
| Ahead/behind | `0/0` |
| Worktrees | `1` |
| Worktree/index/untracked/unmerged | clean |

[report-only uncertainty] No 70,128-byte attachment containing the preceding report was supplied. Per the same-conversation rule, the immediately preceding response—opening `# Baseline and path-grounding correction` and closing with `C2B_PROGRESSION_DECISION_OWNER_FREEZE_RECONCILED_READY_FOR_INDEPENDENT_AUDIT`—was treated as the fixed input.

# Classification of the prior non-audit response

[report-only uncertainty] The preceding response was a detailed owner-contract proposal, not an independent audit or acceptance.

[report-only uncertainty] Its 7,338-byte printed profile manifest and claimed digest `8a8d67fb444c6d2a79f2a70f98f3dfa02baae0476b270396ea364e029100b4dc` contradict its stated algorithm. Those bytes under `governed-execution.nwp-development-progression-owner-profile.v1.identity` produce `9303a62e3a99d71745055faa11ba3d2611fb797982f9af6a749071dd44692f2d`. The prior cross-check claim is therefore a report defect.

[reopened owner seam] The prior command’s C1 phase, membership, rank-15, and wrapper identities created a hidden RW0-C/C1 dependency.

[reopened owner seam] Its single post-execution basis made pre-contact block unrepresentable.

[reopened owner seam] Its C2B completed-receipt latch Boolean lacked route/productivity evidence.

[reopened owner seam] Its `LIMIT 257` classification confused a reader page cap with a 256-member integrity invariant.

[proposed frozen C2B owner contract] All four defects are resolved below. Neither old digest remains valid for the revised manifest.

# Preserved owner decisions

[proposed frozen C2B owner contract] One private branch-parameterized owner covers seven profile branches mapping to the six existing persisted decision pairs; the block pair has two authorization profiles but the same existing `block/program_block` row grammar.

[proposed frozen C2B owner contract] Six version-advancing branches use the explicit single-work profile. `effect_cancellation` remains non-version-advancing and membership-neutral.

[current owning contract] C2B owns branch validity, immutable progression rows, program/work poststates, revisions and edges, exact head CAS, result/receipt construction, replay, and recovery.

[proposed frozen C2B owner contract] RW0-C consumes one bounded private C2B facade inside its common transaction. C2B imports no RW0-C or C1 semantic type or row.

[proposed frozen C2B owner contract] There is one controller, connection, mutation slot, capability epoch, timestamp, and commit attempt. No standalone C2B commit path exists in this slice.

[proposed frozen C2B owner contract] Migration 0005 and the physical one-way latch remain RW0-C-owned. C2B owns no latch row, route semantics, or productivity semantics.

[compatibility edge] Migration 0002, the existing decision fields/nullability, enums, row identities, and graph-digest helper remain unchanged. The current field and variant algebra is visible in [_development_decision_row_values.py](/Users/ds/Repositories/Governed%20Execution%20Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:35).

[reopened owner seam] RW0-C-Terminal and migration 0006 remain blocked on D/Execution Substrate terminal-evidence owners.

# Corrected owner-profile identity

[proposed frozen C2B owner contract] The final identity is:

```text
schema_id: governed-execution.nwp-development-progression-owner-profile.v1
profile_ref: c2b-progression-owner-single-work-v1
canonicalization: canonical-json.sorted-keys.utf8.v1
digest domain: governed-execution.nwp-development-progression-owner-profile.v1.identity
canonical UTF-8 byte length: 10273
profile digest: f1c07181337764b1409a725390db74ac76dfc74240111b7264c000ef6f0a32d6
```

[proposed frozen C2B owner contract] Exact final single-line canonical JSON:

```json
{"authority_nonclaims":["no_c1_or_rw0_c_semantic_import","no_route_or_productivity_semantics","no_external_io","no_public_api","no_standalone_commit","no_migration_change"],"authorization_basis_profiles":[{"basis_profile":"post_execution_owner_projection","basis_value_schema_id":"governed-execution.nwp-section41-post-execution-proposal-family-projection.v1","branches":["candidate_acceptance","candidate_repair","attempt_selecting_replan","program_terminal_reject","post_execution_program_block"]},{"basis_profile":"pre_contact_owner_authorization","basis_value_schema_id":"governed-execution.nwp-development-pre-contact-block-authorization.v1","branches":["pre_contact_program_block"],"source_attestation_schema_id":"governed-execution.nwp-rw0-c-pre-contact-block-basis-attestation.v1","source_profile_digest":"702a3580c11589cb58471c4aed507b885c20cb02edab22cdacde9ce35b83caca","source_profile_ref":"rw0-c-pre-contact-block-basis-v1"},{"basis_profile":"effect_cancellation_source","basis_value_schema_id":"governed-execution.nwp-development-effect-cancellation-basis.v1","branches":["effect_cancellation"]}],"authorization_basis_schema_id":"governed-execution.nwp-development-progression-authorization-basis.v1","branches":[{"accepted_intent":"reuse","allowed_program_states":["active"],"allowed_work_states":["planned","active","repair_required"],"authorization_basis_profile":"post_execution_owner_projection","branch":"candidate_acceptance","cancel_preassignments":false,"cas_order":["work_item_head","program_head"],"decision_kind":"accept","decision_variant":"candidate_acceptance","global_stop_states":["clear"],"graph_roles":["program_head_postimage","progression_decision","program_version","work_item_head_postimage","program_version_work_item"],"membership":"ordinal_zero_reuse_current_revision","post_execution_recommendation":"accept_candidate","reason_code":"progression.candidate_accepted","result_program_state":"accepted","result_program_version_kind":"accepted","result_program_version_ref":"new","result_work_state":"accepted","selection":"required_current","successor_attempt_candidate":false,"target_effect_classes":[],"target_effect_states":[],"version_advance":true,"work_revision":"reuse","work_spec_binding":"none"},{"accepted_intent":"reuse","allowed_program_states":["active"],"allowed_work_states":["planned","active","repair_required"],"authorization_basis_profile":"post_execution_owner_projection","branch":"candidate_repair","cancel_preassignments":false,"cas_order":["work_item_head","program_head"],"decision_kind":"repair","decision_variant":"candidate_repair","global_stop_states":["clear"],"graph_roles":["program_head_postimage","progression_decision","program_version","work_item_head_postimage","program_version_work_item","work_spec_binding"],"membership":"ordinal_zero_reuse_current_revision","post_execution_recommendation":"repair_candidate","reason_code":"progression.candidate_repair_required","result_program_state":"active","result_program_version_kind":"repair","result_program_version_ref":"new","result_work_state":"repair_required","selection":"required_current","successor_attempt_candidate":true,"target_effect_classes":[],"target_effect_states":[],"version_advance":true,"work_revision":"reuse","work_spec_binding":"new_binding_same_revision"},{"accepted_intent":"append","allowed_program_states":["active"],"allowed_work_states":["planned","active","repair_required"],"authorization_basis_profile":"post_execution_owner_projection","branch":"attempt_selecting_replan","cancel_preassignments":false,"cas_order":["work_item_head","program_head"],"decision_kind":"replan","decision_variant":"attempt_selecting_replan","global_stop_states":["clear"],"graph_roles":["program_head_postimage","accepted_intent_revision","progression_decision","program_version","work_item_head_postimage","work_item_revision","program_version_work_item","work_spec_binding","accepted_intent_revision_edge","work_item_revision_edge"],"membership":"ordinal_zero_new_revision","post_execution_recommendation":"replan","reason_code":"progression.attempt_replanned","result_program_state":"active","result_program_version_kind":"replan","result_program_version_ref":"new","result_work_state":"planned","selection":"required_current","successor_attempt_candidate":true,"target_effect_classes":[],"target_effect_states":[],"version_advance":true,"work_revision":"append_replan_same_work_item","work_spec_binding":"new_binding_new_revision"},{"accepted_intent":"reuse","allowed_program_states":["active"],"allowed_work_states":["planned","active","repair_required"],"authorization_basis_profile":"post_execution_owner_projection","branch":"program_terminal_reject","cancel_preassignments":false,"cas_order":["work_item_head","program_head"],"decision_kind":"terminal_reject","decision_variant":"program_terminal_reject","global_stop_states":["clear","active"],"graph_roles":["program_head_postimage","progression_decision","program_version","work_item_head_postimage","program_version_work_item"],"membership":"ordinal_zero_reuse_current_revision","post_execution_recommendation":"terminal_reject","reason_code":"progression.program_terminal_rejected","result_program_state":"terminal_rejected","result_program_version_kind":"terminal_rejected","result_program_version_ref":"new","result_work_state":"terminal_rejected","selection":"required_current","successor_attempt_candidate":false,"target_effect_classes":[],"target_effect_states":[],"version_advance":true,"work_revision":"reuse","work_spec_binding":"none"},{"accepted_intent":"reuse","allowed_program_states":["active"],"allowed_work_states":["planned","active","repair_required"],"authorization_basis_profile":"post_execution_owner_projection","branch":"post_execution_program_block","cancel_preassignments":false,"cas_order":["work_item_head","program_head"],"decision_kind":"block","decision_variant":"program_block","global_stop_states":["clear","active"],"graph_roles":["program_head_postimage","progression_decision","program_version","work_item_head_postimage","program_version_work_item"],"membership":"ordinal_zero_reuse_current_revision","post_execution_recommendation":"block","reason_code":"progression.program_blocked_post_execution","result_program_state":"blocked","result_program_version_kind":"blocked","result_program_version_ref":"new","result_work_state":"blocked","selection":"required_current_but_not_persisted_in_decision_selection_fields","successor_attempt_candidate":false,"target_effect_classes":[],"target_effect_states":[],"version_advance":true,"work_revision":"reuse","work_spec_binding":"none"},{"accepted_intent":"reuse","allowed_program_states":["active"],"allowed_work_states":["planned","active","repair_required"],"authorization_basis_profile":"pre_contact_owner_authorization","branch":"pre_contact_program_block","cancel_preassignments":false,"cas_order":["work_item_head","program_head"],"decision_kind":"block","decision_variant":"program_block","global_stop_states":["clear","active"],"graph_roles":["program_head_postimage","progression_decision","program_version","work_item_head_postimage","program_version_work_item"],"membership":"ordinal_zero_reuse_current_revision","post_execution_recommendation":null,"reason_code":"progression.program_blocked_pre_contact","result_program_state":"blocked","result_program_version_kind":"blocked","result_program_version_ref":"new","result_work_state":"blocked","selection":"forbidden","successor_attempt_candidate":false,"target_effect_classes":[],"target_effect_states":[],"version_advance":true,"work_revision":"reuse","work_spec_binding":"none"},{"accepted_intent":"not_read_or_changed","allowed_program_states":["active","accepted","terminal_rejected","blocked"],"allowed_work_states":[],"authorization_basis_profile":"effect_cancellation_source","branch":"effect_cancellation","cancel_preassignments":true,"cas_order":[],"decision_kind":"cancel","decision_variant":"effect_cancellation","global_stop_states":["clear","active"],"graph_roles":["progression_decision"],"membership":"not_read_or_changed","post_execution_recommendation":null,"reason_code":"progression.effect_cancellation_recorded","result_program_state":"unchanged","result_program_version_kind":null,"result_program_version_ref":"basis","result_work_state":"not_read_or_changed","selection":"required_current","successor_attempt_candidate":false,"target_effect_classes":["author_candidate","validate_candidate","review_candidate"],"target_effect_states":["ready_for_delivery","delivery_pending","delivery_outcome_unknown","observed"],"version_advance":false,"work_revision":"none","work_spec_binding":"none"}],"canonicalization":"canonical-json.sorted-keys.utf8.v1","command_schema_id":"governed-execution.nwp-record-development-progression-decision-command.v1","completed_receipt_schema_id":"governed-execution.nwp-development-progression-completed-receipt.v1","evaluation_basis_schema_id":"governed-execution.nwp-development-progression-evaluation-basis.v1","latch_eligibility_owner":"outer_rw0_c","profile_ref":"c2b-progression-owner-single-work-v1","recovery_selector_schema_id":"governed-execution.nwp-development-progression-recovery-selector.v1","recovery_vocabulary":["committed_exact","definitely_not_committed","unresolved"],"schema_id":"governed-execution.nwp-development-progression-owner-profile.v1","single_work_profile":{"advancing_branches":["candidate_acceptance","candidate_repair","attempt_selecting_replan","program_terminal_reject","post_execution_program_block","pre_contact_program_block"],"cancel_membership":"not_read","fetch_count":2,"multiple_result":"program_membership_profile_conflict","query_id":"development_progression_single_work_membership_profile","required_member_count":1,"required_ordinal":0,"sql":"SELECT schema_id, program_ref, program_version_ref, work_item_ref, work_item_revision_ref, membership_ordinal, created_at, membership_digest FROM development_program_version_work_items WHERE program_ref = ? AND program_version_ref = ? ORDER BY membership_ordinal ASC, work_item_ref ASC LIMIT 2","zero_or_malformed_result":"database_integrity_failure"},"timestamp_owner":"common_composed_transaction_controller","write_plan_schema_id":"governed-execution.nwp-development-progression-write-plan.v1"}
```

[proposed frozen C2B owner contract] Exact digest input:

```text
UTF-8("governed-execution.nwp-development-progression-owner-profile.v1.identity")
|| 0x00
|| the exact 10273 canonical bytes printed above
```

[proposed frozen C2B owner contract] Python `hashlib.sha256` and OpenSSL `dgst -sha256` independently returned:

```text
f1c07181337764b1409a725390db74ac76dfc74240111b7264c000ef6f0a32d6
```

[proposed frozen C2B owner contract] Every command, completed-receipt projection, replay proof, recovery selector, and outer-C closure attestation must bind exactly this profile pair.

# Owner-neutral command and composition basis

[proposed frozen C2B owner contract] C2B accepts a closed `DevelopmentProgressionAuthorizationBasisV1`, not C1 phase/membership/rank values. Its ordered fields are:

```text
schema_id
basis_profile
source_owner_schema_id
source_owner_ref
source_owner_digest
program_ref
program_version_ref
program_version_number
work_item_ref
work_item_revision_ref
semantic_attempt_ref
candidate_ref
authorized_branch
post_execution_owner_projection
pre_contact_owner_authorization
effect_cancellation_source
authorization_basis_digest
```

[proposed frozen C2B owner contract] Exactly one nested value is non-null:

- `post_execution_owner_projection` for five post-execution branches;
- `pre_contact_owner_authorization` for `pre_contact_program_block`;
- `effect_cancellation_source` for `effect_cancellation`.

[proposed frozen C2B owner contract] The neutral Section 41 projection has schema `governed-execution.nwp-section41-post-execution-proposal-family-projection.v1` and ordered fields:

```text
schema_id
proposal_family_ref
proposal_family_graph_digest
source_invocation_ref
source_invocation_digest
context_schema_id
context_ref
context_digest
artifact_schema_id
artifact_ref
artifact_digest
safe_projection_schema_id
safe_projection_digest
proposal_ref
proposal_digest
evidence_set_ref
evidence_set_digest
program_ref
program_version_ref
program_version_number
work_item_ref
work_item_revision_ref
semantic_attempt_ref
candidate_ref
attempt_fence_ref
attempt_fence_digest
selection_head_revision
selection_head_digest
recommendation
reason_code
projection_digest
```

[proposed frozen C2B owner contract] C2B validates the exact Section 41 rows, graph digest, lineage, current selection head, and recommendation-to-branch mapping. It does not inspect any C1 membership identity.

[proposed frozen C2B owner contract] The neutral pre-contact authorization has schema `governed-execution.nwp-development-pre-contact-block-authorization.v1` and ordered fields:

```text
schema_id
source_attestation_schema_id
source_attestation_profile_ref
source_attestation_profile_digest
source_attestation_ref
source_attestation_digest
program_ref
program_version_ref
program_version_number
work_item_ref
work_item_revision_ref
authorized_branch
authorization_digest
```

[proposed frozen C2B owner contract] C2B validates only its exact digest, program/work lineage, `authorized_branch`, and pinned outer profile pair. It does not receive or interpret the outer finite reason or C1 evidence members.

[proposed frozen C2B owner contract] The cancellation basis has schema `governed-execution.nwp-development-effect-cancellation-basis.v1` and ordered fields:

```text
schema_id
basis_ref
program_ref
basis_program_version_ref
basis_program_version_number
semantic_attempt_ref
candidate_ref
attempt_fence_ref
attempt_fence_digest
selection_head_revision
selection_head_digest
target_effect_intent_ref
target_effect_class
target_effect_fence_ref
target_effect_fence_digest
expected_target_effect_head_revision
originating_command_ref
originating_command_digest
target_capsule_manifest_ref
target_portable_capsule_digest
source_directive_ref
source_directive_digest
source_evidence_ref
source_evidence_digest
basis_digest
```

[proposed frozen C2B owner contract] All three identities use compact sorted-key UTF-8 canonical JSON and `SHA-256(schema_id + ".identity" || NUL || identity bytes)`, excluding only the value’s self-digest.

# Pre-contact and post-execution block profiles

[proposed frozen C2B owner contract] Both branch IDs map to the unchanged persisted pair `decision_kind=block`, `decision_variant=program_block`. Both append a `blocked` program version, retain accepted intent/current work revision, insert ordinal-zero membership, CAS work then program to `blocked`, and use the same graph roles.

[proposed frozen C2B owner contract] Their differences are exact:

| Branch | Authorization | Section 41 selection | Decision selected fields | Reason code |
|---|---|---|---|---|
| `post_execution_program_block` | exact Section 41 `block` family | required current | all four remain null | `progression.program_blocked_post_execution` |
| `pre_contact_program_block` | exact neutral projection of outer-C attestation | forbidden | all four remain null | `progression.program_blocked_pre_contact` |

[proposed frozen C2B owner contract] The outer pre-contact profile is:

```text
schema_id: governed-execution.nwp-rw0-c-pre-contact-block-basis-profile.v1
profile_ref: rw0-c-pre-contact-block-basis-v1
canonical length: 1428 bytes
profile digest: 702a3580c11589cb58471c4aed507b885c20cb02edab22cdacde9ce35b83caca
```

[proposed frozen C2B owner contract] Exact outer profile canonical JSON:

```json
{"attestation_digest_domain":"governed-execution.nwp-rw0-c-pre-contact-block-basis-attestation.v1.identity","attestation_field_order":["schema_id","attestation_profile_ref","attestation_profile_digest","attestation_ref","program_ref","program_version_ref","program_version_number","work_item_ref","work_item_revision_ref","authorized_branch","finite_reason_code","evidence_snapshot_ref","evidence_snapshot_digest","evidence_member_count","attested_at","attestation_digest"],"attestation_schema_id":"governed-execution.nwp-rw0-c-pre-contact-block-basis-attestation.v1","authorized_branch":"pre_contact_program_block","canonicalization":"canonical-json.sorted-keys.utf8.v1","evidence_member_count_minimum":1,"evidence_rule":"one_or_more_exact_current_admitted_owner_values_explicitly_support_the_finite_reason","finite_reason_codes":["authority.currentness_negative","authority.currentness_unknown","custody.availability_negative","custody.availability_unknown","retrieval.capability_negative","retrieval.capability_unknown","readiness.currentness_negative","readiness.currentness_unknown","qualification.currentness_negative","qualification.currentness_unknown","coding_global_stop.active","current_head.conflict","gate.explicit_finite_failure"],"missing_evidence_result":"no_decision","owner":"rw0_c","profile_ref":"rw0-c-pre-contact-block-basis-v1","schema_id":"governed-execution.nwp-rw0-c-pre-contact-block-basis-profile.v1"}
```

[proposed frozen C2B owner contract] Its digest input is the outer profile identity domain, NUL, and the exact 1,428 bytes above. Python and OpenSSL both returned `702a3580c11589cb58471c4aed507b885c20cb02edab22cdacde9ce35b83caca`.

[proposed frozen C2B owner contract] `evidence_member_count >= 1` is mandatory. Mere missing C1 evidence yields `no_decision`; it cannot construct an attestation or authorize block. No Section 41 row is fabricated.

# Latch-eligibility ownership

[proposed frozen C2B owner contract] Option 1 is selected. Outer RW0-C owns composite latch eligibility and migration-0005 latch CAS.

[proposed frozen C2B owner contract] Eligibility is true only when all are exact:

```text
C2B branch == candidate_acceptance
C2B completed receipt/result is exact
outer decision closure is exact
route attestation says adapter_kind == direct_local_bootstrap
productive-output attestation is verified and binds the accepted candidate/capsule
```

[proposed frozen C2B owner contract] The outer writer then requires the exact available latch preimage and performs the one-way CAS atomically in the same transaction. A later terminal `accept` binds that committed postimage without mutating it.

[proposed frozen C2B owner contract] C2B’s command, evaluation basis, result, and completed receipt contain no latch Boolean, adapter kind, route proof, or productive-output assertion.

[reopened owner seam] Legacy C2B prose still describes latch consumption with the accepted decision, while the later composition contract places the physical row and CAS in RW0-C. This reconciliation resolves the ownership as: C2B owns the accepted decision; outer RW0-C owns eligibility composition and the physical CAS. Repository documentation must be reconciled before implementation.

# Single-work query contract

[proposed frozen C2B owner contract] Query ID:

```text
development_progression_single_work_membership_profile
```

[proposed frozen C2B owner contract] Exact SQL:

```sql
SELECT schema_id, program_ref, program_version_ref, work_item_ref,
       work_item_revision_ref, membership_ordinal, created_at, membership_digest
FROM development_program_version_work_items
WHERE program_ref = ? AND program_version_ref = ?
ORDER BY membership_ordinal ASC, work_item_ref ASC
LIMIT 2
```

[proposed frozen C2B owner contract] Parameters are `(program_ref, basis_program_version_ref)`. Execution uses one cursor and `fetchmany(2)`.

[proposed frozen C2B owner contract] Classification is:

- zero rows: `database_integrity_failure`, because every current program version is owner-required to have nonempty membership;
- one exact built-in tuple, valid row, matching lookup, ordinal zero: eligible;
- two valid rows: `program_membership_profile_conflict`;
- malformed, incoherent, duplicate, wrong lookup, or nonzero first ordinal: `database_integrity_failure`.

[compatibility edge] This is a family-local query and does not alter the frozen twenty-four-query inventory. The current `LIMIT 257` query remains a paged aggregate-reader cap, not a schema maximum; see [_sqlite_development_reader_contracts.py](/Users/ds/Repositories/Governed%20Execution%20Coordinator/src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py:452).

# Branch pre-state matrix

[proposed frozen C2B owner contract] Every row in this matrix has that classification:

| Branch | Program prestate | Work prestate | Evidence/selection prerequisites | Stop |
|---|---|---|---|---|
| `candidate_acceptance` | `active` | `planned`, `active`, `repair_required` | exact current Section 41 `accept_candidate` family | clear |
| `candidate_repair` | `active` | `planned`, `active`, `repair_required` | exact current Section 41 `repair_candidate` family | clear |
| `attempt_selecting_replan` | `active` | `planned`, `active`, `repair_required` | exact current Section 41 `replan` family | clear |
| `program_terminal_reject` | `active` | `planned`, `active`, `repair_required` | exact current Section 41 `terminal_reject` family | clear or active |
| `post_execution_program_block` | `active` | `planned`, `active`, `repair_required` | exact current Section 41 `block` family | clear or active |
| `pre_contact_program_block` | `active` | `planned`, `active`, `repair_required` | exact outer pre-contact authorization; no Section 41 family | clear or active |
| `effect_cancellation` | any existing program state | not read | current selection and target effect; target state in `ready_for_delivery`, `delivery_pending`, `delivery_outcome_unknown`, `observed` | clear or active |

[current merged implementation] `planned` must remain valid because the current author-effect implementation requires and leaves the current work head at `planned`; see [_sqlite_development_author_effect_establishment.py](/Users/ds/Repositories/Governed%20Execution%20Coordinator/src/ge_nwp_coordinator/_sqlite_development_author_effect_establishment.py:638).

[proposed frozen C2B owner contract] `active` is allowed because it is an existing nonterminal vocabulary value and terminal reject/block must be able to close active work. Pre-contact describes the current contact phase, not an inference from `work_state`; historical activity does not disqualify pre-contact block.

[proposed frozen C2B owner contract] Repair from `planned` is meaningful under the current author-effect posture. Acceptance or replan from `repair_required` is meaningful after a successor attempt while the head retains its prior repair state. Repeated repair from `repair_required` is allowed.

[proposed frozen C2B owner contract] `accepted`, `terminal_rejected`, and `blocked` work prestates are excluded from advancing branches because they are terminal work states. Cancel ignores that profile and is governed by the exact target-effect head.

[implementation detail] A later author-effect tranche must extend the current initialization-only validation to consume exact committed `repair` or attempt-selecting `replan` bases. It may not reinterpret these progression states.

# Exact branch write matrix

[proposed frozen C2B owner contract] Immutable writes listed before the receipt occur in the stated order; work CAS always precedes program CAS.

| Branch | Immutable rows before CAS | CAS | Final immutable row |
|---|---|---|---|
| acceptance | decision, accepted program version, ordinal-zero membership | work→`accepted`; program→new version/`accepted` | development mutation receipt |
| repair | decision, repair version, membership, new WorkSpec binding for same work revision | work→`repair_required`; program→new version/`active` | receipt |
| replan | accepted-intent revision, replan work revision, two supersession edges, decision, replan version, membership, new WorkSpec binding | work→new revision/`planned`; program→new version/`active` | receipt |
| terminal reject | decision, terminal-rejected version, membership | work→`terminal_rejected`; program→new version/`terminal_rejected` | receipt |
| either block | decision, blocked version, membership | work→`blocked`; program→new version/`blocked` | receipt |
| cancel | decision only | none | receipt |

[proposed frozen C2B owner contract] Acceptance, repair, terminal rejection, and block reuse the accepted-intent and work revision. Replan appends one accepted-intent revision, one same-work-item `replan` revision, one `accepted_intent_supersedes` edge, and one `work_item_supersedes` edge.

[proposed frozen C2B owner contract] Cancel writes no program version, membership, revision, WorkSpec, edge, or head update. Its existing receipt’s `result_program_version_ref` is the unchanged basis version.

# Command and basis grammars

[proposed frozen C2B owner contract] The reserved command schema is retained:

```text
governed-execution.nwp-record-development-progression-decision-command.v1
```

[proposed frozen C2B owner contract] Exact ordered command fields:

```text
schema_id
owner_profile_ref
owner_profile_digest
branch
mutation_ref
decision_ref
program_ref
authorization_basis
basis_decision_ref
basis_decision_digest
basis_program_version_ref
basis_program_version_number
basis_program_version_digest
expected_program_head
expected_sole_membership
expected_work_item_head
expected_work_item_revision
coding_global_stop_ref
coding_global_stop_version
result_assignments
```

[proposed frozen C2B owner contract] `expected_program_head` is a complete typed current program-head row and is required for all branches. The membership/work values are complete typed migration-0002 rows, required for every advancing branch and exactly null for cancel. All refs use existing safe-ref grammar; all digests are lowercase SHA-256; numbers are exact built-in non-Boolean integers.

[proposed frozen C2B owner contract] `result_assignments` has ordered fields:

```text
schema_id
branch
resulting_program_version_ref
resulting_accepted_intent_revision_ref
resulting_work_item_revision_ref
accepted_intent_edge_ref
work_item_edge_ref
resulting_work_spec_ref
resulting_work_spec_safe_projection
replan_source_intent_ref
replan_source_intent_digest
replan_safe_projection_digest
preassigned_semantic_attempt_ref
preassigned_candidate_ref
preassigned_effect_intent_ref
preassigned_effect_fence_ref
preassigned_delivery_attempt_ref
```

[proposed frozen C2B owner contract] Optionality is exact:

- acceptance, terminal rejection, and both blocks: only `resulting_program_version_ref`;
- repair: resulting version, WorkSpec ref/projection, successor attempt and candidate;
- replan: resulting version, accepted-intent revision, work revision, both edges, WorkSpec, replan source triple, successor attempt and candidate;
- cancel: only preassigned cancel effect, fence, and first delivery.

[proposed frozen C2B owner contract] The caller supplies identities and safe source projections, never a poststate, reason code, row digest, graph role/order, SQL, CAS, latch state, or timestamp. C2B derives those exclusively from branch/profile.

[proposed frozen C2B owner contract] The command digest is:

```text
SHA-256(
  UTF-8("governed-execution.nwp-record-development-progression-decision-command.v1.identity")
  || 0x00
  || canonical command identity bytes
)
```

[proposed frozen C2B owner contract] Unknown keys, subclassed scalars, duplicate JSON keys, non-NFC strings, and wrong nullability fail before digest comparison.

[proposed frozen C2B owner contract] The exact evaluator basis schema is `governed-execution.nwp-development-progression-evaluation-basis.v1`, with ordered fields:

```text
schema_id
branch
authorization_basis
program_head
program_version
basis_decision
accepted_intent_revision
sole_membership
work_item_head
work_item_revision
work_spec_binding
selection_head
semantic_attempt
attempt_fence
effect_intent
effect_fence
author_command
delivery_attempt
target_effect_head
global_stop_current
basis_digest
```

[proposed frozen C2B owner contract] Only `authorization_basis` is supplied. The private C2B facade reads every other value inside the active transaction and constructs the immutable basis. Post-execution branches populate the full current program/work/selection/effect lineage; pre-contact block populates program/work values and leaves selection/effect values null; cancel populates program and selection/target-effect lineage but leaves membership/work-profile values null.

[proposed frozen C2B owner contract] The basis contains no C1 type, caller poststate, private WorkSpec content, credential, endpoint, route proof, productivity proof, or executable authority.

# Write-plan, CAS, graph, result, and receipt

[proposed frozen C2B owner contract] The sealed write-plan schema is `governed-execution.nwp-development-progression-write-plan.v1`, with fields:

```text
schema_id
owner_profile_ref
owner_profile_digest
branch
command_digest
authorization_basis_digest
evaluation_basis_digest
decision
accepted_intent_revision
work_item_revision
program_version
membership
work_spec_binding
accepted_intent_edge
work_item_edge
work_head_cas
program_head_cas
graph_entries
result_projection
development_receipt
completed_receipt
```

[proposed frozen C2B owner contract] Optional rows follow the branch matrix exactly. Values are typed owner values and sealed CAS specifications, never raw mappings or caller SQL.

[proposed frozen C2B owner contract] The existing ordered 43-field decision row remains unchanged. Common non-null fields are schema, mutation/decision/program refs, kind/variant, basis decision/version, expected program-head revision, stop ref/version, derived reason, decision timestamp, and digest.

[proposed frozen C2B owner contract] For acceptance, repair, replan, and terminal rejection, the four selected attempt/candidate/fence fields are copied from verified current owner rows. Both block variants keep all four null. Cancel populates selection, target effect, originating command, source directive/evidence, and cancel preassignments; its capsule pair is null for author targets and required for validation/review targets. This matches the current constructor algebra in [_development_decision_row_values.py](/Users/ds/Repositories/Governed%20Execution%20Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:631).

[proposed frozen C2B owner contract] Exact work CAS SQL:

```sql
UPDATE development_work_item_heads
SET current_work_item_revision_ref = ?,
    current_work_item_revision_number = ?,
    head_revision = ?,
    work_state = ?,
    updated_at = ?,
    head_digest = ?
WHERE schema_id = ?
  AND program_ref = ?
  AND work_item_ref = ?
  AND current_work_item_revision_ref = ?
  AND current_work_item_revision_number = ?
  AND head_revision = ?
  AND work_state = ?
  AND updated_at = ?
  AND head_digest = ?
```

[proposed frozen C2B owner contract] Exact program CAS SQL:

```sql
UPDATE development_program_heads
SET current_program_version_ref = ?,
    current_program_version_number = ?,
    head_revision = ?,
    program_state = ?,
    updated_at = ?,
    head_digest = ?
WHERE schema_id = ?
  AND program_ref = ?
  AND current_program_version_ref = ?
  AND current_program_version_number = ?
  AND head_revision = ?
  AND program_state = ?
  AND updated_at = ?
  AND head_digest = ?
```

[proposed frozen C2B owner contract] Each CAS requires rowcount exactly one. Either miss is reported as `program_head_conflict`: the single-work program/work pair is one aggregate CAS unit, and the common reason avoids exposing which internal head raced. Any miss rolls back the whole nested plan.

[proposed frozen C2B owner contract] Every graph entry is the existing `(role, ordinal, record_ref, record_digest)` value, ordinal zero, with roles in the exact profile order. The tuple order is semantically significant; the current helper includes entries in supplied order and rejects duplicate role/ordinal and role/ref pairs in [_development_decision_row_values.py](/Users/ds/Repositories/Governed%20Execution%20Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:952).

[proposed frozen C2B owner contract] The existing progression result remains:

```text
schema_id
program_ref
decision_ref
result_program_version_ref
result_decision_ref
result_projection_digest
```

[proposed frozen C2B owner contract] Advancing branches return the new version; cancel returns the unchanged basis version.

[proposed frozen C2B owner contract] The persisted development receipt retains its migration-0002 fields and `development_progression_decision_recorded` result class. No column is added.

[proposed frozen C2B owner contract] The additive pure completed-receipt projection has schema `governed-execution.nwp-development-progression-completed-receipt.v1` and ordered fields:

```text
schema_id
owner_profile_ref
owner_profile_digest
branch
mutation_ref
command_digest
authorization_basis_digest
evaluation_basis_digest
program_ref
decision_ref
result_program_version_ref
result_projection_digest
mutation_graph_digest
committed_at
completed_receipt_digest
```

[proposed frozen C2B owner contract] It contains no latch-eligibility field. It is recomputed from exact readback and adds no SQL column.

[proposed frozen C2B owner contract] Closed preflight failures are `invalid_progression_command` and `owner_profile_mismatch`. Closed fresh-operation conflicts are:

```text
mutation_ref_reuse_conflict
authorization_basis_conflict
program_head_conflict
program_membership_profile_conflict
selection_head_conflict
target_effect_head_conflict
global_stop_version_conflict
coding_global_stop_active
semantic_identity_conflict
```

[current owning contract] Missing/malformed mandatory managed rows, impossible partial families, and digest/graph contradictions are integrity failures, not domain conflicts.

# Replay and recovery

[proposed frozen C2B owner contract] Receipt lookup by `mutation_ref` precedes current stop, head, membership, or authorization checks. Same mutation ref plus exact command digest reconstructs and returns the original result; a different digest returns `mutation_ref_reuse_conflict`.

[proposed frozen C2B owner contract] Replay verifies the final profile pair, authorization and evaluation basis digests, decision, branch-specific family, graph, result, persisted receipt, and completed-receipt digest. It does not call a clock or re-evaluate present route/productivity facts.

[proposed frozen C2B owner contract] Historical global stop is bound by the immutable decision’s stop ref/version. Version zero has the canonical initial-clear meaning; later versions resolve through immutable accepted stop-event history. A newer mutable current row cannot alter replay.

[proposed frozen C2B owner contract] Recovery selector schema `governed-execution.nwp-development-progression-recovery-selector.v1` has ordered fields:

```text
schema_id
owner_profile_ref
owner_profile_digest
branch
mutation_ref
command_schema_id
command_digest
authorization_basis_digest
program_ref
decision_ref
basis_decision_ref
basis_program_version_ref
basis_program_version_number
expected_program_head
expected_sole_membership
expected_work_item_head
expected_work_item_revision
coding_global_stop_ref
coding_global_stop_version
resulting_program_version_ref
resulting_accepted_intent_revision_ref
resulting_work_item_revision_ref
accepted_intent_edge_ref
work_item_edge_ref
resulting_work_spec_ref
preassigned_semantic_attempt_ref
preassigned_candidate_ref
preassigned_effect_intent_ref
preassigned_effect_fence_ref
preassigned_delivery_attempt_ref
selector_digest
```

[proposed frozen C2B owner contract] It is built from the validated command before writes and is immutable. Its digest excludes only `selector_digest`.

[proposed frozen C2B owner contract] Recovery outcomes are exact:

- `committed_exact`: exact receipt exists and every branch row, digest, graph, result, completed projection, and profile pair reconstructs exactly;
- `definitely_not_committed`: receipt and every selector-owned immutable locator are absent, with no exact or conflicting family fragment;
- `unresolved`: any fragment, collision, mismatched receipt, impossible partial outer/nested family, or unprovable cleanup.

[proposed frozen C2B owner contract] Later legitimate head advancement does not defeat `committed_exact`; immutable family readback reconstructs historical postimages without requiring current heads to equal them. Exact absence of all immutable locators can prove `definitely_not_committed` even if an unrelated later operation advanced a head.

[proposed frozen C2B owner contract] A C2B-only fragment inside an outer RW0-C operation, or an outer/latch-only fragment without the exact C2B family, is `unresolved`. It is never treated as a completed nested or composed operation.

[current owning contract] A commit-attempt exception yields `commit_outcome_unknown`; the same writer does not retry. A fresh fenced writer performs readback. Rollback/close uncertainty also requires readback and may remain unresolved.

# Composition seam with RW0-C

[proposed frozen C2B owner contract] The exact composed order is:

1. Outer RW0-C acquires the existing operation lease/mutation slot and opens the common fenced transaction.
2. Outer receipt-first replay runs.
3. Outer RW0-C reads and validates its C1 phase, paginated membership snapshot, rank wrapper, completeness, block, route, and productivity evidence.
4. For post-execution branches, outer RW0-C proves its C1 snapshot resolves to the exact Section 41 family projected to C2B.
5. For pre-contact block, outer RW0-C constructs the exact attestation and neutral authorization projection; no Section 41 family is manufactured.
6. C2B’s private facade reads C2B/Section 41 rows, builds the evaluation basis, and evaluates once.
7. The common controller captures one whole-second UTC decision timestamp after current checks and before writes.
8. C2B writes its immutable rows, performs work-before-program CAS, reads back the complete nested family, and inserts its receipt.
9. Outer RW0-C writes its closure/attestations and, only for eligible acceptance, performs the migration-0005 latch CAS.
10. Outer receipt is inserted last.
11. The capability is permanently invalidated before exactly one `COMMIT`.
12. Cleanup and composed three-way recovery use the same filesystem-bound database proof.

[proposed frozen C2B owner contract] C2B does not import or query C1/RW0-C tables. Outer RW0-C does not select C2B poststates or graph roles. The only crossing values are the validated authorization basis, command/result, final profile pair, and completed-receipt digest.

[proposed frozen C2B owner contract] No callable path in this slice may commit C2B progression independently of the outer closure.

# Assurance architecture

[proposed frozen C2B owner contract] Permanent future tests must each protect one causal owner claim:

- literal 10,273 profile bytes and independent expected digest;
- command field order, closed-world parsing, profile pair, and absence of C1/RW0 fields;
- all three authorization-basis variants and cross-owner substitution rejection;
- pre-contact/post-execution branch swaps and missing-evidence `no_decision`;
- absence of route/productivity/latch values from C2B;
- single-work zero/one/two and malformed-row behavior;
- every allowed and excluded branch prestate;
- exact seven positive plans and every forbidden row;
- repair WorkSpec rebinding and replan revisions/edges;
- work-before-program SQL, rowcount, and rollback;
- exact graph tuple order, result, receipt, and completed digest;
- receipt-first replay, later-head advancement, and all three recovery outcomes;
- no C/RW0 semantic import, public widening, second controller, or standalone commit.

[proposed frozen C2B owner contract] Independent audit—not permanent self-derived tests—owns literal digest recomputation, external SQL/FK fixtures, branch-substitution mutants, route/productivity mutants, fault injection, partial-family recovery, and clean/live validation.

# Provisional implementation surface

[report-only uncertainty] The surface is provisional until a dedicated implementation-boundary and consumer/source-hash audit.

[implementation detail] Likely C2B-owned additions are private progression contract/runtime modules, plausibly:

```text
src/ge_nwp_coordinator/_development_progression_decision_contracts.py
src/ge_nwp_coordinator/_sqlite_development_progression_decision.py
```

[implementation detail] Existing private reader specifications/readers may need additive family-local queries:

```text
src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py
src/ge_nwp_coordinator/_sqlite_development_readers.py
```

[implementation detail] The common transaction and private composition entry may require bounded changes in:

```text
src/ge_nwp_coordinator/sqlite_transition_transaction.py
src/ge_nwp_coordinator/sqlite_writer_session.py
```

[implementation detail] RW0-C Decision, its closure/attestation values, catalog integration, and migration-0005 resource remain a separate outer-owned surface under `src/ge_nwp_coordinator/` and `src/ge_nwp_coordinator/sqlite_migrations/`.

[compatibility edge] Migrations 0001–0004, migration-0002 bytes, current decision columns/enums, public `StateStore`/`WriterSession` APIs, and existing Section 41/C1 semantics are protected.

[current owning contract] Any implementation must update `.docs/` to make the outer latch ownership and final profile pair authoritative and remove drift.

# Remaining seams and stop conditions

[reopened owner seam] `TERMINAL_OWNER_RECONCILIATION_REQUIRED` remains in force. D/Execution Substrate still own the absent process-group, descendant, authenticated teardown, custody/retrieval terminality, source-receipt closure, and route-currentness evidence.

[current merged implementation] No C2B progression writer, outer decision closure, migration 0005, latch, or terminal runtime exists at this baseline.

[implementation detail] The current author-effect runtime accepts only the initialized version-one/planned lineage. Future repair/replan consumption requires a separately audited extension consistent with the already accepted author-effect target.

[reopened owner seam] Private WorkSpec custody/retrieval remains external. A safe binding or digest is not retrieval authority.

[proposed frozen C2B owner contract] Stop conditions are any need to change migration-0002 bytes or decision grammar; add a kind/variant; permit generic payloads or caller-selected poststates/SQL; support multi-work inside this profile; import C1/RW0-C into C2B; add a second transaction/commit path; widen public APIs; perform external I/O; or weaken exact recovery.

# Recommended next step

[proposed frozen C2B owner contract] The contract is ready for an independent audit of the literal profile bytes/digests, branch and basis substitution boundaries, SQL/FK feasibility, and recovery proofs. After that, perform the separate implementation-boundary audit for the combined C2B-owner plus RW0-C-Decision candidate. This is sequencing guidance, not an implementation prompt or authorization.

# Confidence

[proposed frozen C2B owner contract] High confidence in the corrected identity, owner-neutral boundary, dual block representation, latch owner, single-work query, branch matrix, and replay/recovery closure.

[report-only uncertainty] Medium confidence in the provisional touched-file inventory until the required consumer/source-hash audit is performed.

C2B_PROGRESSION_DECISION_OWNER_FINAL_RECONCILIATION_READY_FOR_INDEPENDENT_AUDIT

REPOSITORY_MUTATION_NOT_PERFORMED  
TESTS_NOT_RUN  
MIGRATIONS_NOT_RUN  
STAGING_NOT_PERFORMED  
COMMIT_NOT_PERFORMED  
PUSH_NOT_PERFORMED  
PR_NOT_CREATED  
REMOTE_CONTACT_NOT_PERFORMED  
WORKER_OR_MODEL_NOT_INVOKED  
SUPPORTING_REPOSITORIES_NOT_MODIFIED  
IMPLEMENTATION_NOT_PERFORMED  
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED  
RW0_C_DECISION_NOT_IMPLEMENTED  
RW0_C_TERMINAL_NOT_IMPLEMENTED  
RW0_D_NOT_IMPLEMENTED  
RW0_E_NOT_IMPLEMENTED  
EXECUTION_SUBSTRATE_NOT_MODIFIED
