# Decision

**Do not start the next formal independent audit yet.** Package V3 closes the eight findings from the prior audit and passes its JSONL mechanics, but it introduces three deterministic internal contradictions. They are narrow package defects, not architectural failures.

## What V3 successfully repaired

The attached report and package substantively close the prior findings:

- the host-qualification owner module and field names now match the merged B1 owner;
- the four rank-12 C2A observation relations are non-temporal and use `evaluated_at = null`;
- the V40 nested locator now includes its literal `schema_id`;
- V35–V37 and the nine future-recovery equalities are retired from current normative truth;
- the source-owner modules and migration-`0003` evidence-row locator are corrected;
- the assurance corpus was expanded;
- future committed recovery is explicitly deferred rather than prematurely frozen.

The V3 package mechanics also pass: 1,121 canonical JSONL records, correct payload hashes and domain digests, exact manifest and closeout reconciliation, and the reported content aggregate.

## Remaining deterministic defects

### `V3-PKG-001` — contradictory duplicate host-qualification digest

In `source-owner.host-qualification`, the actual owner value contains:

```text
canonical_value.qualification_digest =
971eb49f780922384eda949e7ecbaaae67554d4c6cb750a6b7b5fe46ddfd05dc
```

That value independently reproduces under the correct owner digest domain.

But the same source-owner payload also contains a second top-level field:

```text
qualification_digest =
fb18bf1d97830fa0ff602f90d59cf0f718f3df53754c3f28e27d7f40d7b62681
```

The second value is neither the canonical review qualification digest nor the reported validation qualification digest.

This record is also the only one of the 23 `source_owner_binding` records that adds an eleventh, record-specific key. The other 22 use the same ten-key source-owner payload grammar.

**Required correction:** remove the duplicate top-level field and enforce one exact source-owner-binding payload shape.

### `V3-PKG-002` — host relation/profile metadata is not source-grounded

The same record claims:

```text
profile = rw0-wire-nwpf-v1
relation = rank-6 host qualification relation
```

But its canonical qualification carries a different required worker-protocol pair, and the merged `validate_host_qualification(...)` relation accepts no separate profile operand. It validates the qualification’s required worker artifact/protocol pairs against the readiness observation directly. 

The current host-qualification row also owns the exact unprofiled `required_worker_artifact_ref/digest` and `required_worker_protocol_ref/digest` fields now used in V3. 

The source-owner metadata should therefore be source-grounded, most likely:

```json
{
  "profile": null,
  "relation": "validate_host_qualification"
}
```

unless Codex identifies a different literal current relation contract from the merged source.

### `V3-PKG-003` — V26 nested entry schema omitted from its governing profile

The exact V26 value schema and every golden membership-closure entry contain:

```text
schema_id =
governed-execution.nwp-rw0-c-decision-membership-closure-entry.v1
```

as the first field.

But `behavior-profile.rw0-c-decision-membership-closure.v1` defines its exact `entry_fields` without `schema_id`:

```text
kind_rank
membership_ref
membership_digest
...
```

This repeats the same class of nested-contract defect previously fixed for V40.

The profile must declare the literal entry schema and the exact field order:

```text
schema_id
kind_rank
membership_ref
membership_digest
value_schema_id
value_ref
value_digest
scope_binding_digest
relation_set_digest
admitted_at
admission_graph_digest
```

That changes the closure profile digest, V25/V26 profile pairs, the closure identity, and every downstream current snapshot or evaluation that binds the closure.

## Disposition

```text
V3 JSONL mechanics:
PASS

Prior audit findings RW0-AUDIT-001 through RW0-AUDIT-008:
substantially closed

V3 internal source-owner and nested-profile consistency:
BLOCK

Formal independent audit:
PREMATURE

Repository implementation:
NOT AUTHORIZED
```

These findings do **not** reopen:

- V40 operational reviewer separation;
- the two-context design;
- Section 41 projection V2 or role resolution V3;
- exact resupply and capsule privacy;
- policy/risk authorship;
- the `FiniteBacklog` adapter boundary;
- the fifteen-kind C1 contract;
- explicit deferral of future recovery ownership.

# Codex handoff

Send this repair prompt to the package-generation conversation:

:chatgpt-content-reference{index="5"}[Download the V4 internal-consistency repair prompt](sandbox:/mnt/data/Coordinator_RW0_Canonical_Package_V4_Internal_Consistency_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_Canonical_Package_V4_Internal_Consistency_Repair_Prompt.txt

Size:
10,207 bytes

SHA-256:
859f98d5495e6fb8efb1feafaf94bd62a7c1ac962e7a62e8361e7794bd4ff371

Logical lines:
394

Final newline:
absent
```

Attach the V3 package as its sole fixed input:

:chatgpt-content-reference{index="6"}[Download canonical package V3](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Audit_Package_V3.jsonl)

```text
Size:
2,066,851 bytes

SHA-256:
d01e1ad90f406dedf8f80bc0453505df022a9c9013a7914a0ed7e52d202ffefe

Logical records:
1,121

Content aggregate:
e460b60c49460622dc669f21fd90429dc3b705755a20e0e8321941558c503336
```

The required revised deliverable is:

```text
RW0_Post_Execution_Canonical_Audit_Package_V4.jsonl
```

The required success token is:

```text
RW0_POST_EXECUTION_CANONICAL_PACKAGE_V4_REPAIRED_READY_FOR_INDEPENDENT_AUDIT
```

The prompt requires Codex to:

1. remove the contradictory duplicate host digest;
2. correct the host relation/profile metadata against the merged source;
3. add `schema_id` to the literal V26 nested-entry profile;
4. regenerate every transitively affected current identity;
5. add finite assurance and malformed vectors for all three defects;
6. run package-wide source-owner and nested-schema consistency guards;
7. visibly attach V4 without changing the repository.

The detailed pre-audit verification and finding ledger is here:

:chatgpt-content-reference{index="7"}[Download the V3 pre-audit verification](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Audit_Package_V3_PreAudit_Verification.json)

```text
SHA-256:
8b13a322a988f7b79b444eec1ea56d3b2d6c9cd1362f15a1621be33f75fde8be
```

## After V4

Regenerate the formal independent-audit prompt using V4’s exact external identity. Do not reuse the prior audit prompt unchanged, because its fixed-input identity and some expected record counts will differ.

### Sources

- Current host-qualification owner and relation.  
- Current C1 row shape. 
- :chatgpt-content-reference{index="8"}[Canonical package V3](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Audit_Package_V3.jsonl)
- :chatgpt-content-reference{index="9"}[V3 pre-audit verification](sandbox:/mnt/data/RW0_Post_Execution_Canonical_Audit_Package_V3_PreAudit_Verification.json)

**Confidence:** High that all three contradictions are deterministic; high that this is a narrow package-regeneration task rather than another owner-architecture reconciliation; high that V4 should be the appropriate fixed input for the next formal audit.

The current Codex response and V3 package were fully available. Some older project uploads have expired; they only need to be uploaded again if a later audit must inspect their exact historical bytes.
