# Decision

**Do not start the formal independent audit yet. Run one final, tightly bounded source-owner reconciliation first.**

Codex substantially improved the contract. It cleanly separated the L34 lineage context from the T1 model-input context, assigned distinct schema and digest namespaces, moved the Section 41 projection to V2, moved role resolution to V3, regenerated dependent identities, and produced a much more complete value/schema registry, locator matrix, equality matrix, and assurance matrix. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

The headline context collision is therefore closed.

However, the report now exposes a more fundamental class of mismatch: several supposedly exact proposal-time source values are not actually bound to the current owning schemas and relations. Sending this package directly to audit would likely produce another predictable `BLOCK`.

## 1. Validation and review use invented source schemas

The merged C2A owner represents both validation and independent-review observations as `WorkerObservationV1` under the exact schema:

```text
governed-execution.nwp-worker-observation.v1
```

The current owner also closes the observation fields, source kinds, observation kinds, outcomes, optional fields, lineage, capsule identity, and observation digest.  

The reconciliation report’s value registry leaves `source_observation_schema_id` as a generic `SID` for both disposition values rather than fixing it to the C2A owner. :chatgpt-content-reference{index="5"}

Worse, its current golden T1 context uses newly invented identities:

```text
governed-execution.nwp-validation-source-observation.v1
governed-execution.nwp-independent-review-source-observation.v1
```

rather than the current `WorkerObservationV1` schema. :chatgpt-content-reference{index="6"}

That silently creates new source-observation owners while claiming C2A remains unchanged.

The correct contract must bind each disposition to the exact current C2A observation:

```text
source schema:
governed-execution.nwp-worker-observation.v1

validation:
observation_kind = validation_completed

review:
observation_kind = independent_review_completed
```

It must then freeze the exact current source kind, outcome, conditional fields, capsule lineage, source identity, and observation digest before applying the additive owner-authored disposition taxonomy.

## 2. The capsule safe projection widens the current owner

The report defines:

```text
CandidateCapsuleSafeProjectionV1.base_git_object_format:
sha1 | sha256
```

:chatgpt-content-reference{index="7"}

The current `CandidateCapsuleManifestV1` owner requires exactly:

```text
base_git_object_format = sha1
```

and validates the corresponding 40-character base OID. 

A safe projection may omit private fields, but it cannot widen an owner enum. Accepting `sha256` would allow a projection that no valid current capsule manifest can produce.

The projection must preserve:

```text
base_git_object_format = sha1
base_git_oid = exact 40-character lowercase hexadecimal
```

This correction changes the projection’s ref and digest and therefore requires regeneration of the model-input projection, private manifest, T1 input context, source invocation, proposal, Section 41 projection, role-resolution profile, equality ledger, and all dependent golden vectors.

## 3. The worker-result role does not use the exact current C1 relation contract

The golden T1 role entry binds the worker result through a proposed schema resembling:

```text
governed-execution.nwp-rw0-c1-wire-process-result-classifier-relation.v1
```

:chatgpt-content-reference{index="9"}

But merged C1 represents relation proof through its generic relation-binding row, with a literal relation ID/version, proof mode, NWPF profile pair, subject membership, operand-set identity, relation digest, and relation-row digest.

The reconciliation needs to identify the exact current rank-14 relation:

- relation-binding schema;
- relation ID;
- relation version;
- proof mode;
- NWPF profile ref/digest;
- subject rank-14 membership;
- subject value schema/ref/digest;
- required operand closure.

It should not invent a standalone relation schema unless the current owner actually defines one.

## 4. The “complete” source/support registry still has unnamed owners

`PostExecutionRoleSupplyV2` carries arbitrary role-dispatched canonical values for:

- source profiles;
- source bindings;
- support sets;
- support values.

But the report leaves these as generic constructs such as `SID`, `O[source]`, `O[profile]`, and `A[...closed role-specific values]` without registering every actual source schema and ownership relation. :chatgpt-content-reference{index="10"}

This is especially material for:

- validation tool, requirement, and result-set values;
- review tool, requirement, result set, and reviewer-independence values;
- standing-policy source;
- parent-grant/policy authority source;
- risk policy;
- generic risk-source profile and binding;
- global-stop source value;
- attempt and effect fences;
- authority observation.

Each must be classified as one of:

```text
current merged owner
new private neutral pure owner
opaque owner-authored supplied attestation
```

For each, the report must say whether the local tranche reconstructs, derives, validates an owner-supplied result, or merely binds identity. Without this, the contract still leaves implementation free to invent source schemas and semantics.

# What should remain frozen

Do not reopen the strong results already achieved:

- two distinct context values and namespaces;
- migration-`0003` continuing to store the T1 context through its opaque context triple;
- Section 41 projection V2 and role resolution V3;
- exact resupply rather than process-memory continuity;
- full candidate manifest remaining transient/private;
- exhaustive C1 membership closure;
- bounded RW0-C current snapshot;
- `FiniteBacklog` remaining an adapter rather than generic risk truth;
- forecast-only treatment of future command, receipt, and recovery schemas;
- no migration, public API, runtime, branch-decision, latch, terminal, D/E, or ES implementation.

The next correction should only bind the already-designed values to their real current owners and regenerate identities mechanically.

# Codex handoff

Send this read-only prompt to the same architecture conversation:

:chatgpt-content-reference{index="18"}[Download the source-owner and supply-binding reconciliation prompt](sandbox:/mnt/data/Coordinator_RW0_Post_Execution_Source_Owner_and_Supply_Binding_Reconciliation_Prompt.txt)

```text
Filename:
Coordinator_RW0_Post_Execution_Source_Owner_and_Supply_Binding_Reconciliation_Prompt.txt

Size:
17,274 bytes

SHA-256:
b668817402d871070da19c1d3dc5f237419390a615c2d051d2115bb59cc7755b

Logical lines:
580

Final newline:
absent
```

Attach this exact fixed input:

:chatgpt-content-reference{index="19"}[Download the context-identity and value-grammar reconciliation report](sandbox:/mnt/data/RW0_Post_Execution_Context_Identity_and_Value_Grammar_Reconciliation_Report.txt)

```text
Size:
165,888 bytes

SHA-256:
8dd26efd25333cd49acc0fe7b64d9b7b05495176e3d5b4f377fa42f8cf60ba58

Logical lines:
1,026

Final newline:
absent
```

The required successful result is:

```text
RW0_POST_EXECUTION_SOURCE_OWNERS_AND_SUPPLY_BINDINGS_RECONCILED_READY_FOR_INDEPENDENT_AUDIT
```

The prompt is restricted to:

- current C2A validation/review source bindings;
- current C1 rank-14 relation proof;
- capsule safe-projection narrowing;
- a closed source/support owner registry;
- policy and risk authorship;
- exact global-stop and fence owner values;
- field-level enum and branch closure;
- dependent identity regeneration;
- owner/schema and profile matrices;
- finite source-substitution assurance.

It does not authorize implementation.

## Sequence after successful reconciliation

```text
1. Fresh independent audit of the self-contained owner contract.
2. Read-only implementation-boundary freeze for the migration-free pure-owner tranche.
3. Implement, audit, and merge the pure-owner tranche.
4. Freeze the aggregate RW0-C authoritative branch evaluator.
5. Reconcile the neutral C2B authorization basis and progression writer.
6. Freeze migration 0005 and the combined atomic decision boundary.
```

## Current state

```text
Context namespace collision:
closed

T1 / Section 41 / resupply temporal model:
substantially closed

Value and profile registry:
substantially closed

Current source-owner bindings:
not closed

Validation/review source schemas:
currently incorrect

Candidate safe-projection Git format:
currently widened beyond owner

C1 worker-result relation identity:
not source-grounded

Independent audit:
premature

Implementation:
not authorized
```

### Sources

- Attached reconciliation report. :chatgpt-content-reference{index="11"} :chatgpt-content-reference{index="12"} :chatgpt-content-reference{index="13"} :chatgpt-content-reference{index="14"}
- Current C2A worker-observation and capsule owners.   

**Confidence:** High that the context collision is genuinely resolved; high that the C2A source-schema and capsule-format mismatches are real contract defects; high that one bounded owner-binding reconciliation should be the final correction before formal independent audit.

Some older uploaded files have expired. The current attachment was fully available; older material only needs to be re-uploaded if a later audit requires its exact bytes rather than the current self-contained report.
