PROMPT_ID

RW0_C_DECISION_CONTRACT_FREEZE_RECONCILIATION_V2

TITLE

Coordinator RW0-C-Decision — reconcile closure pagination, branch-specific
result states, finite block evidence, latch postimage binding, and snapshot
semantics while preserving the terminal owner blocker

ENGAGEMENT TYPE

Parent-only, local, read-only contract reconciliation.

Do not delegate to subagents.

Do not edit, format, generate repository files, stage, commit, push, create a
branch or PR, merge, tag, release, deploy, fetch, contact a remote/live system,
install dependencies, run migrations, execute tests, invoke a product
worker/model, or inspect/modify supporting repositories.

Do not issue an implementation prompt.

Print the complete substantive report inline. Evidence files may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_C_DECISION_RECONCILIATION_BASELINE_MISMATCH

PRESERVED DECISIONS

Preserve unless an owning repository contract proves a direct contradiction:

1. RW0-C is decomposed into:
   - RW0-C-Decision;
   - RW0-C-Terminal.

2. RW0-C-Decision is independently useful and belongs in additive migration
   0005.

3. Exactly one RW0-C decision closure and one bound C2B decision may exist per
   exact C1 phase.

4. Only productive direct-local `accept / candidate_acceptance` may consume the
   one-way latch, atomically with the decision.

5. Terminal acceptance later binds the committed consumed latch postimage and
   never mutates it.

6. RW0-C-Terminal and migration 0006 remain blocked until D/ES owns exact
   physical reconciliation schemas, identities, and readers.

7. `cancellation_rejected` maps fail-closed to terminal block under current
   owners.

8. Pre-effect-basis-unusable terminal block requires an exact committed and
   recoverable `cancel / effect_cancellation` decision.

9. Existing B1, B2, C1, C2A, C2B, Section 41, migration 0001–0004, public, and
   transaction-owner semantics remain unchanged.

10. This engagement remains read-only and does not authorize implementation.

SOURCE-GROUNDED DEFECTS TO RECONCILE

A. C1 PAGE SIZE IS NOT A TOTAL MEMBERSHIP CEILING

The merged C1 literal query is cursor-paginated:

```text
WHERE phase_basis_ref = ?
  AND (kind_rank > ? OR (kind_rank = ? AND membership_ref > ?))
ORDER BY kind_rank ASC, membership_ref ASC
LIMIT 257
```

The prior freeze incorrectly treated `LIMIT 257` as proving a hard total of 256
phase memberships.

Freeze one of these, with explicit rationale:

1. Preferred: page repeatedly until exhaustion, while enforcing a separately
   named C2-owned total decision-closure work/member ceiling; or

2. prove from the complete RW0 fact grammar that a tighter finite total is an
   owning invariant.

Do not infer the total from the C1 per-page reader limit.

If a C2-owned total ceiling is retained:

- name it explicitly;
- state whether 256 remains the chosen value;
- derive or defend the value;
- bind it in the command/attestation/profile;
- distinguish page overflow from total-ceiling overflow;
- define exact content-free failure;
- ensure C1 still permits later membership admission independently.

B. BRANCH SET `X` CONFLICTS WITH C1 RANK-14 RESULT STATES

Current C1 rank 14 supports:

```text
result_state = present | finite_failure | absent
```

Rank 13 is required only for the `present` branch. The prior freeze defined
post-execution `X` as always containing one rank-13 result, which would exclude
valid finite-failure/absent branches.

Replace `X` with an exact branch-specific matrix, at minimum:

- `X_present`: exact rank-13 membership plus rank-14 `present`;
- `X_finite_failure`: no rank-13 membership; rank-14 `finite_failure` with the
  exact admitted finite reason;
- `X_absent`: no rank-13 membership; rank-14 `absent`.

For each C2 decision branch state exactly which result-state classes are:

- required;
- permitted;
- forbidden.

Cover:

- accept;
- repair;
- replan;
- terminal reject;
- post-execution block.

Do not invent a rank-13 result for finite failure or absence.

C. BLOCK MUST NOT TURN MEMBERSHIP ABSENCE INTO EXTERNAL TRUTH

C1 membership proves presence only. A complete page-closed membership snapshot
does not prove that an external fact did not occur, that a source is complete,
or that missing evidence is permanently unavailable.

Reconcile both block profiles:

1. `post_execution_block`

   It may use:
   - an exact complete Section 41 `block` recommendation;
   - explicit admitted owner-authored unknown/unavailable/negative/conflicting
     observations;
   - multiple contradictory complete branch families;
   - exact current owner/head/global-stop conflicts.

   It must not use mere absence of a required C1 membership as proof of an
   external negative fact.

2. `pre_contact_block`

   It may use:
   - exact current authority/readiness/custody/qualification negative or unknown
     values;
   - exact current stop or head conflict;
   - an explicit finite gate failure.

   It must not claim physical non-contact or external absence from missing
   Coordinator rows.

Freeze exact finite reason codes and the evidence needed for each. State when
the correct result is “no decision yet” rather than permanent `program_block`.

D. DECISION-TIME MEMBERSHIP SNAPSHOT SEMANTICS

A decision closure must prove the exact C1 membership set observed inside its
transaction while allowing later C1 admissions, especially after a cancel
decision.

Freeze:

- paginated enumeration algorithm;
- canonical order;
- termination rule;
- total-ceiling rule, if any;
- member count and set digest;
- decision timestamp semantics;
- whether the complete set is an admission-time attestation or later
  recomputable fact;
- how replay and committed recovery verify the original snapshot without
  incorrectly incorporating later memberships;
- how later terminal closure can include memberships admitted after the
  decision;
- how same-second admission timestamps avoid becoming a hidden snapshot
  boundary;
- why no mutable C1 completeness head is introduced.

Do not rely on timestamps alone to distinguish pre-decision from post-decision
members.

E. LATCH POSTIMAGE BINDING

The earlier phase-level design bound the latch postimage to the accepted
decision, decision closure, and result. The latest table retained only decision,
program-version, candidate, and capsule fields.

Make and defend one explicit choice.

Preferred contract:

The consumed latch directly stores and digests:

- decision_ref / decision_digest;
- decision_closure_ref / decision_closure_digest;
- outer decision result_projection_digest;
- resulting program_version_ref / program_version_digest;
- candidate_ref;
- capsule_manifest_ref / portable_capsule_digest;
- consumed_at;
- latch_postimage_digest.

If direct closure/result fields are rejected, prove why transitive lookup
through immutable unique binding rows is equally safe for:

- SQL integrity;
- replay;
- commit recovery;
- terminal accept binding;
- partial-family corruption;
- copied/test database behavior.

Do not silently weaken the postimage relative to the accepted phase-level
decision.

F. EXACT C2B WRITE-SIDE AND RESULT COMPATIBILITY

Reverify every branch against current owning source and tests, not only the
decision-kind inventory.

For each branch cite exact current owner paths/lines and prove:

- permitted nullable/non-null decision fields;
- program-version kind;
- program-head state;
- work-head state;
- whether a new work revision is required;
- accepted-intent and supersession-edge requirements;
- resulting program-version fields;
- nested result projection;
- nested development receipt;
- target/current-head fields;
- active-stop behavior.

Branches:

- accept / candidate_acceptance;
- repair / candidate_repair;
- replan / attempt_selecting_replan;
- terminal_reject / program_terminal_reject;
- block / program_block;
- cancel / effect_cancellation.

Treat any required new/reinterpreted C2B field or variant as:

RW0_C_OWNER_RECONCILIATION_REQUIRED

G. MIGRATION 0005 CONSISTENCY AFTER RECONCILIATION

Update the proposed exact migration freeze consistently.

Re-report:

- table inventory;
- exact ordered columns;
- branch nullability/check algebra;
- PK/UNIQUE/FK constraints;
- deferred cycles;
- explicit indexes;
- triggers;
- latch seed;
- cumulative totals;
- reader queries and limits;
- migration prefix/generation behavior.

Changing columns without changing table count is permitted if justified.
Do not fabricate the final SQL checksum.

Explicitly show how the closure/member schema represents:

- paginated complete snapshot;
- branch-specific result-state matrix;
- explicit block evidence;
- direct or transitive latch binding.

H. TERMINAL OWNER BLOCKER

Preserve and restate:

```text
TERMINAL_OWNER_RECONCILIATION_REQUIRED
```

unless exact merged owner values/readers now prove all of:

- process-group reconciliation;
- descendant reconciliation;
- authenticated teardown;
- candidate-capsule custody/retrieval terminal state;
- delivery/source receipt closure;
- route/source currentness;
- direct-local versus ES routing.

Do not create migration 0006 or a partial terminal schema.

INSPECTION SCOPE

Inspect local read-only:

- C1 reader contracts/readers, row values, mutation contracts, persistence, and
  all nine C1 test modules;
- C2B decision/program/effect row values, readers, tests, and authoritative
  durable-state docs;
- Section 41 values/readers/tests;
- B1/Wire/Capability/C2A owner source and direct tests;
- migration catalog/current schema;
- transaction/writer/recovery contracts;
- current status and authority documents.

No tests, migrations, databases, or external commands may run.

CLASSIFICATION

Label every substantive statement exactly as:

- current owning contract;
- current merged implementation;
- compatibility edge;
- reopened target seam;
- strategic target;
- proposed frozen C contract;
- implementation detail;
- report-only uncertainty.

RETURN FORMAT

# Baseline and inspection boundary
# Preserved decisions
# Reconciled membership pagination and total ceiling
# Reconciled branch result-state matrix
# Reconciled finite block semantics
# Decision-time snapshot contract
# Acceptance-latch postimage contract
# Verified C2B write-side matrix
# Decision closure/member/attestation schemas
# Migration 0005 revised exact freeze
# Decision readers, transaction, replay, and recovery
# Assurance and independent-audit matrix
# Provisional implementation surface and protected set
# Terminal owner blocker
# Forecasts and stop conditions
# Recommended next step
# Confidence

SUCCESS TOKEN

Return exactly:

RW0_C_DECISION_CONTRACT_FREEZE_RECONCILED_READY_FOR_INDEPENDENT_AUDIT

only if:

- all defects above are resolved;
- migration 0005 is internally exact;
- current owner semantics remain unchanged;
- terminal owner blocker is preserved;
- no implementation prompt is issued.

Otherwise return one of:

RW0_C_OWNER_RECONCILIATION_REQUIRED
RW0_C_DECISION_FREEZE_STILL_INCOMPLETE

Required statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
RW0_C_DECISION_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
