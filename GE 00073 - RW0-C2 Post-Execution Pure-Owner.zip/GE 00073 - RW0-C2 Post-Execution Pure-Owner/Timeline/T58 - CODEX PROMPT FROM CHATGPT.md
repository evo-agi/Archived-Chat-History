PROMPT_ID

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V5_CARDINALITY_SUPPORT_CURRENTNESS_REPAIR_V1

TITLE

Coordinator RW0 — repair package V4 list-cardinality, support-inventory, and
proposal-currentness contradictions, regenerate every dependent identity, and
deliver package V5 for formal independent audit

ENGAGEMENT TYPE

Parent-only, local, repository-read-only canonical-package repair.

Do not delegate to subagents or internal audit agents.

Do not edit repository files, format repository files, stage, commit, push,
create a branch or PR, merge, tag, release, deploy, fetch, contact a remote or
live system, install dependencies, execute repository tests, run migrations,
open or mutate an operator database, invoke a product worker/model, or
inspect/modify supporting repositories.

You MAY create files only in one fresh private external temporary root for
bounded source inspection and package reconstruction. Remove disposable
intermediates before closeout.

Return the revised package through the client-visible attachment mechanism.
A private filesystem path is not a deliverable.

Do not issue an implementation prompt.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V5_BASELINE_MISMATCH

FIXED INPUT

Attach exactly:

RW0_Post_Execution_Canonical_Audit_Package_V4.jsonl

Require exactly:

size:
2111217 bytes

SHA-256:
7f71083fec9dbb3df5b7c04dd4b1b73af8e1ebd8e1261985c2f0fbfe9a4f6095

logical records:
1175

final newline:
absent

content aggregate:
98b16e1a517f3720140395f8b0807cfc5d341af00539ba5a6e1a6430cfacbdf2

first record:
package.manifest.v1

last content record:
remaining-seam.S008

final record:
package.closeout.v1

If any property differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V5_FIXED_INPUT_MISMATCH

PRESERVED DISPOSITION

Preserve every accepted V4 repair:

- the common 10-key source-owner payload grammar;
- exact host qualification digest and `validate_host_qualification` metadata;
- V26 nested entry schema and order;
- all V3 source-owner, non-temporal relation, GlobalStopState, evidence-locator,
  future-recovery deferral, and assurance repairs;
- V40 operational reviewer separation;
- two-context design;
- Section 41 projection V2 and role-resolution V3;
- exact resupply and capsule privacy;
- policy/risk owner-authored attestation posture;
- FiniteBacklog adapter isolation;
- exactly 15 C1 kinds;
- no migration, persistence, public API, runtime, progression writer, latch,
  terminal, D/E, or Execution Substrate behavior.

Do not change semantics merely to preserve an existing package hash.

FINDING V4-PKG-001 — GOLDEN VALUES CONTRADICT THEIR VALUE SCHEMAS

V11 currently declares:

```text
support_canonical_values cardinality = 0
```

but its nine current goldens contain:

```text
0, 0, 6, 7, 4, 4, 0, 2, 5
```

values.

V13 currently declares:

```text
entries cardinality = 6
```

but its current support-set goldens contain:

```text
6, 7, 4, 4, 2, 5, 2
```

entries.

Required correction:

V11:

```text
support_canonical_values:
  exact built-in list
  minimum 0
  maximum 16
  length equals support_value_count
  if support_set is null:
    support_value_count = 0
    support_canonical_values = []
  if support_set is non-null:
    length equals support_set.entries length
    each value corresponds exactly, in order, to the support entry's
    schema/ref/digest
```

V13:

```text
entries:
  exact built-in list
  minimum 1
  maximum 16
  length equals the exact owner_inventory_by_consumer entry count for
  profile_ref
  order and values equal that literal inventory
```

Remove fixed golden-specific cardinalities.

Add package-wide guards proving every golden list length satisfies its literal
schema/profile rule.

FINDING V4-PKG-002 — VARIABLE OWNER/PROFILE LISTS ARE FROZEN TO GOLDEN LENGTHS

Replace exact golden-length cardinalities with the following literal contracts.

Current WorkerObservation-derived fields:

```text
V14.source_evidence_refs: 0..32, sorted unique safe refs
V15.source_evidence_refs: 0..32, sorted unique safe refs
V38.source_evidence_refs: 0..32, sorted unique safe refs
V38.result_set_evidence_refs: 0..32, sorted unique safe refs
V39.source_evidence_refs: 0..32, sorted unique safe refs
V39.result_set_evidence_refs: 0..32, sorted unique safe refs
```

The disposition's source list must equal the exact source observation list.
Result-set lists remain independently exact under their profiles.

Standing-policy values:

```text
V41.allowed_branches: 1..5, canonical branch order, unique
V41.allowed_risk_lanes: 1..32, strict lexical order, unique
V41.allowed_effect_classes: 0..5, canonical current effect-class order, unique

V17 copies the exact V41 lists with the same ranges and order.
```

Risk values:

```text
V42.allowed_risk_lanes: 1..32, strict lexical order, unique
V18 copies the exact V42 list with the same range and order.
```

Current fence/authority values:

```text
V21.attempt_allowed_effect_classes:
  1..5, sorted unique subset of the current _EFFECT_CLASSES

V21.authority_allowed_effect_classes:
  1..5, sorted unique subset of the current _EFFECT_CLASSES
```

C1 membership closure:

```text
V25.entries:
  0..65536
  length equals entry_count
  exact (kind_rank, membership_ref) order
  complete result of the frozen exhaustive page algorithm
```

Reviewer separation:

```text
V40.author_observation_locators:
  2..3
  length equals the exact rank-13 observation_count
  exact rank-13 worker-result tuple order
```

Do not change exact fixed cardinalities that are genuinely invariant, including
nine roles, five branch-evaluation entries, nine Section 41 evidence entries,
and five current-snapshot external sources.

For every affected value:

- align value schema and governing profile;
- regenerate goldens and malformed vectors;
- regenerate all dependent refs/digests;
- add one fixed-min, fixed-max, underflow, overflow, reorder, and duplicate
  finite assurance vector where applicable.

FINDING V4-PKG-003 — SUPPORT-SET INVENTORY IS INCOMPLETE AND SELF-CONTRADICTORY

The support profile lacks the current reviewer-separation consumer even though
the package contains its support set and V40 binds that support pair.

Add exactly:

```text
post-execution-reviewer-separation-evaluation.v1:
  review_observation_membership
    rank 1
    governed-execution.nwp-rw0-c1-evidence-membership.v1

  author_worker_result_membership
    rank 2
    governed-execution.nwp-rw0-c1-evidence-membership.v1
```

Add to the V40 behavior profile:

```text
support_profile_ref = post-execution-support-set.v1
support_profile_digest = current regenerated digest
support_roles = [
  ["review_observation_membership",1],
  ["author_worker_result_membership",2]
]
```

The standing-policy profile currently contains two contradictory support
inventories.

Freeze the current owner/golden inventory:

```text
policy_source                         rank 1
policy_profile                        rank 2
authority_observation_and_parent_grant rank 3
source_effect_fence                   rank 4
```

Align:

- owner_support_schemas;
- support_roles;
- post-execution-support-set owner inventory;
- V13 policy support set;
- V11 policy role supply;
- V17 profile/value;
- every dependent identity.

Remove the stale five-role inventory:

```text
parent_grant
authority_observation
source_effect_intent
```

as separate entries.

Add package-wide guards:

```text
for every profile with a support set:
  profile support_roles
  profile owner_support_schemas
  support profile owner_inventory_by_consumer
  golden V13 entries
  V11 support values
must have identical role/rank/schema order.
```

FINDING V4-PKG-004 — CURRENTNESS AND SNAPSHOT DISAGREE ABOUT THE RISK SOURCE

Current V29 and its golden value contain five components:

```text
validation
review
policy
risk_profile
risk_binding
```

The V29 governing profile instead declares four:

```text
validation
review
policy
risk
```

and maps only the risk binding schema.

Freeze five explicit currentness components in this order:

```text
validation
review
policy
risk_profile
risk_binding
```

Use exact owner schemas:

```text
validation:
  governed-execution.nwp-worker-observation.v1

review:
  governed-execution.nwp-worker-observation.v1

policy:
  governed-execution.nwp-post-execution-standing-policy-source-attestation.v1

risk_profile:
  governed-execution.nwp-post-execution-risk-source-profile.v1

risk_binding:
  governed-execution.nwp-post-execution-risk-source-binding.v1
```

Freeze separate conflict, stale, and unknown precedence for risk_profile and
risk_binding.

Align the V27 current-snapshot profile to five explicit resupplied sources in
the same order. Replace the combined phrase
`risk_source_profile_and_binding`.

Preserve V27.external_sources cardinality 5 and V29.components cardinality 5.

Regenerate:

- V27 profile/digest/value;
- V29 profile/digest/value;
- V30 component constraints;
- every currentness/snapshot downstream value;
- T1/Section41/resupply equality records if affected;
- assurances, malformed vectors, supersessions, manifest, and closeout.

PACKAGE-WIDE LIST-CONTRACT GUARD

Before success, enforce:

```text
for every list-valued value-schema field:
  fixed cardinality is permitted only when every valid value has that exact
  cardinality under the governing profile

  otherwise the schema must state literal minimum, maximum, ordering,
  uniqueness, and count-equality rules

for every golden:
  list length and contents satisfy the exact value schema and profile

for every profile/value pair:
  cardinality/range rules do not contradict

for every owner-derived list:
  the proposed value preserves the exact current owner range and ordering
```

Explicitly report every remaining field with a numeric fixed cardinality and
why it is invariant.

REVISED DELIVERABLE

Attach exactly:

RW0_Post_Execution_Canonical_Audit_Package_V5.jsonl

Use the same canonical JSONL envelope and closed record types.

Add supersession entries for every replaced current identity. No stale V4
identity may appear in current truth outside supersession or dedicated
malformed-vector records.

MECHANICAL VERIFICATION

Before success:

1. Repeat every original package mechanic check.
2. Verify all V4 repairs remain closed.
3. Verify V4-PKG-001 through V4-PKG-004.
4. Validate every golden against exact schema field set, types, nullability,
   constants, enums, list ranges, ordering, uniqueness, and cross-field counts.
5. Validate every primary and nested profile/value contract.
6. Validate every support inventory across all five representations listed
   above.
7. Reconstruct every currentness component and current-snapshot source.
8. Reproduce every generated ref, self-digest, support/profile/source binding,
   T1, Section 41, closure, snapshot, and downstream current identity.
9. Verify supersession leakage, manifest, aggregate, closeout, and whole-file
   SHA-256 with two independent readers/hash tools.
10. Recheck the repository baseline and cleanliness.

INLINE REPORT

Print:

- disposition for V4-PKG-001 through V4-PKG-004;
- exact filename, size, SHA-256, records, final-newline posture;
- per-type counts and content aggregate;
- changed/new/retired record IDs;
- supersession entries added;
- assurance and malformed-vector counts;
- complete remaining fixed-cardinality field ledger and rationale;
- confirmation that support inventories align;
- confirmation that V27/V29 use five explicit sources/components;
- confirmation that V5 is visibly attached;
- confirmation that no private path is offered as the deliverable;
- success token.

SUCCESS TOKEN

Return exactly:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V5_REPAIRED_READY_FOR_INDEPENDENT_AUDIT

only if:

- all four findings are closed;
- V5 is visibly attached;
- every verification passes;
- repository state remains unchanged;
- no implementation prompt is issued.

Otherwise return:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V5_REPAIR_BLOCKED

and classify the blocker as:

- fixed-input mismatch;
- source-owner contradiction;
- semantic contradiction;
- regeneration failure;
- canonical verification failure;
- attachment mechanism unavailable;
- baseline mismatch.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
