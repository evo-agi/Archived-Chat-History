ROMPT_ID

RW0_POST_EXECUTION_CONTEXT_RESUPPLY_SNAPSHOT_RECOVERY_OWNER_COMPLETION_V1

TITLE

Coordinator RW0 — complete the post-execution owner contract by freezing the
model-input context, exact transient-value resupply, Section 41 role locators,
decision-time membership/current snapshots, local evaluator algebras, and the
logical committed-recovery family

ENGAGEMENT TYPE

Parent-only, local, read-only owner-contract completion.

Do not delegate to subagents or internal audit agents. If parent-only execution
cannot be maintained, stop and report that procedural blocker.

Do not edit repository files, generate repository artifacts, format, stage,
commit, push, create a branch or PR, merge, tag, release, deploy, fetch,
contact a remote/live system, install dependencies, execute tests, run
migrations, open or mutate an operator database, invoke a product worker/model,
or inspect/modify supporting repositories.

Do not issue an implementation prompt.

Print the complete substantive report inline. Supplementary evidence files may
be listed only after the complete inline result.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_POST_EXECUTION_CONTEXT_RECOVERY_BASELINE_MISMATCH

FIXED AUDIT INPUT

Treat the immediately preceding Codex audit report as the fixed finding input.

If supplied as a file, use this distinct name:

RW0_Post_Execution_Evidence_Temporal_Owner_Independent_Audit_Block_Report.txt

Expected identity:

size:
25133 bytes

SHA-256:
6fad3bcebfa9b6418af078357f0bf6a9ca105a815675518d895e00bcbe93481e

logical lines:
388

final newline:
absent

opening:
# Verdict

verdict:
BLOCK

closing section:
# Confidence

If an attached fixed input differs, stop:

RW0_POST_EXECUTION_CONTEXT_RECOVERY_FIXED_INPUT_MISMATCH

ACCEPTED FINDINGS

Close every finding from the fixed audit:

Critical:

- RW0-AUD-001 — no exact T1 model-input context/manifest binds what the model
  consumed to the nine later Section 41 evidence rows;
- RW0-AUD-002 — no exact custody/resupply/restart contract exists for the full
  candidate manifest or other transient proposal-time values.

High:

- RW0-AUD-003 — the decision snapshot and C1 membership closure are incomplete;
- RW0-AUD-004 — behavior-sensitive profiles and value identities are incomplete;
- RW0-AUD-005 — validation/review and policy/risk/matrix result-reason algebras
  are not total and deterministic;
- RW0-AUD-006 — Section 41 role locators, typed extractors, source-pair rules,
  and relation identity are incomplete;
- RW0-AUD-007 — the logical future committed-recovery family and typed locators
  are incomplete;
- RW0-AUD-008 — assurance omits the central temporal, resupply, identity,
  restart, and recovery mutants.

Medium:

- RW0-AUD-009 — source-effect ceiling evidence collapses distinct fence and
  authority expiry semantics;
- RW0-AUD-010 — the chronology and causal diagram conflate pure construction
  with durable insertion and do not share one exact dependency order.

PRESERVED DECISIONS

Preserve unless owning repository evidence proves a direct contradiction:

1. C1 retains exactly 15 kinds and owns admitted evidence presence, typed
   membership, relation receipts, replay, and recovery—not completeness or
   branch decision.

2. Section 41 owns immutable proposal-family structure and model recommendation
   semantics. Model output remains evidence, never branch authority.

3. Proposal-time owner values are complete before the model invocation.

4. Policy and risk remain complete five-branch proposal-time matrices.

5. Proposal-time global stop is an immutable snapshot; later RW0-C evaluation
   rereads the mutable singleton separately.

6. Source-effect ceiling evidence is proposal-time and branch-neutral.

7. Validation and review dispositions are owner-authored proposal-time values;
   RW0-C does not infer them from coarse observations.

8. FiniteBacklog remains a versioned compatibility adapter behind a generic
   risk-source interface.

9. RW0-C later owns a complete membership closure, fresh current snapshot,
   fresh authority/stop/ceiling evaluations, authoritative branch derivation,
   recommendation consistency, closure, and migration-0005 persistence.

10. C2B later consumes one owner-neutral authorization basis and does not
    interpret C1 memberships, Section 41 roles, policy bodies, model output, or
    transient private values.

11. Missing or unavailable optional evidence yields `no_decision`; malformed,
    substituted, contradictory, or corrupt required state yields
    `basis_conflict` or database-integrity failure.

12. Existing B1/B2/C1/C2A meanings, Section 41 durable rows, migrations
    0001–0004, migration-0002 decisions, public APIs, and one transaction
    controller remain unchanged.

13. No implementation, migration, latch, progression writer, public widening,
    external contact, terminal truth, D/E, or Execution Substrate behavior is
    authorized.

FACT CLASSIFICATION

Classify each substantive statement exactly as:

- current owning contract;
- current merged implementation;
- compatibility edge;
- proposed post-execution evidence owner contract;
- proposed Section 41 role-resolution contract;
- proposed RW0-C decision-input contract;
- proposed future committed-recovery contract;
- implementation-detail observation;
- report-only uncertainty.

Do not use broader or alternate labels.

PART I — T1 POST-EXECUTION SEMANTIC-REVIEW INPUT CONTEXT

A. OWNER AND PURPOSE

Freeze one exact pure private value, using a repository-consistent final name,
provisionally:

PostExecutionSemanticReviewInputContextV1

It is the exact T1 model-input contract.

It must:

- exist before model invocation;
- bind the exact proposal-time typed inputs available to the model;
- be referenced by the existing Section 41 source-invocation
  `context_schema_id/context_ref/context_digest` fields;
- be independent of the final model proposal digest;
- be the common predecessor of both:
  - the model invocation; and
  - all nine later Section 41 evidence rows.

B. COMPLETE VALUE GRAMMAR

Freeze exact ordered fields at minimum:

```text
schema_id
context_ref
profile_ref
profile_digest
proposal_phase
preassigned_proposal_ref
program_ref
program_version_ref
accepted_intent_revision_ref
work_item_ref
work_item_revision_ref
semantic_attempt_ref
semantic_attempt_digest
attempt_number
candidate_ref
phase_basis_ref
phase_basis_digest
role_entry_count
role_entries
model_input_safe_projection_digest
private_input_manifest_digest
constructed_at
context_digest
```

Revise only with source-grounded rationale.

Each of exactly nine role entries must bind:

```text
role
role_rank
ordinal
typed_schema_id
typed_value_ref
typed_value_digest
source_posture
c1_kind
c1_kind_rank
c1_membership_ref
c1_membership_digest
source_profile_ref
source_profile_digest
source_binding_ref
source_binding_digest
model_input_posture
```

Close all nullability by role.

C. MODEL-INPUT BINDING

Freeze one pure relation proving:

- the model invocation received exactly this context identity;
- every nonprivate typed value required by the model is represented by exact
  canonical bytes or an exact safe projection in the supplied invocation
  package;
- candidate-capsule private material is supplied under the context’s private
  input manifest, not persisted in the source-invocation row;
- the source-invocation `context_*` fields equal the T1 context;
- all nine later Section 41 evidence rows equal the corresponding role entries;
- proposal ref preassignment is exact;
- the final proposal may be created only from the artifact produced by that
  invocation and the same context.

Nine opaque ref/digest pairs alone are insufficient unless the exact typed
canonical bytes or safe model-input projections are also bound.

D. PURE CONSTRUCTION VERSUS SQL WRITE ORDER

Freeze one chronology and distinguish:

Semantic construction:

```text
T0 owner values complete
T1 context constructed
T2 model invocation consumes context
T3 source invocation completes and artifact validates
T4 nine evidence-binding row values are purely constructed from context entries
T5 proposal row is purely constructed
```

Durable insertion under migration 0003:

```text
source invocation
artifact binding
proposal parent row
nine evidence child rows
selection/disposition rows as already owned
```

Respect current immediate foreign keys. No report may imply child insertion
before the proposal parent.

Freeze exact timestamp inequalities and identify which timestamps are equal by
current owner contract rather than convenience.

PART II — TRANSIENT VALUE SUPPLY, CUSTODY, AND RESUPPLY

E. TRANSIENT INPUT PACKAGE

Freeze one exact pure operation-input package, provisionally:

PostExecutionEvidenceSupplyV1

It carries the complete canonical values needed for:

- T1 context construction;
- model input;
- Section 41 role resolution;
- later RW0-C decision evaluation before commit.

It is not durable truth and creates no source authenticity.

At minimum include:

- the T1 context;
- complete CandidateCapsuleManifestV1;
- validation disposition;
- review disposition;
- policy matrix;
- risk matrix;
- proposal-time stop snapshot;
- source-effect ceiling evidence;
- authority observation;
- exact worker-result locator/value reconstruction inputs;
- supporting profile/binding/support-set values required to validate each item.

Close exact fields, ordering, cardinality, canonical identity, and digest.

F. SUPPLY POSTURE

Freeze these rules:

1. No physical custodian or retrieval mechanism is claimed by C.

2. Before a future decision commits, every non-C1 proposal-time value that is
   needed semantically must be resupplied as an exact operation input.

3. Resupply is verified against:
   - T1 context role entry;
   - Section 41 evidence row;
   - typed value self-identity;
   - role-resolution relation;
   - relevant support/profile identities.

4. Absence of an exact resupplied optional value yields `no_decision`.

5. Ref/digest match with malformed canonical bytes, wrong schema, wrong role,
   wrong phase, or wrong support yields `basis_conflict`.

6. Exact replay before commit resupplies the same package and verifies the same
   identities; it does not trust process memory.

7. Restart before decision requires resupply. No in-memory continuity is
   assumed.

8. A future committed decision must not require resupply of private values for
   readback/recovery; it must retain the safe derived values and locators frozen
   in Part VII.

G. CANDIDATE CAPSULE PRIVACY

Freeze exact use of CandidateCapsuleManifestV1:

- full manifest may exist only as a transient supplied value;
- C1/Section 41 retain only current permitted ref/digest and safe bindings;
- no capsule entries, paths, operations, modes, blob digests, byte lengths,
  private bodies, or physical location are added to current durable state;
- model input may receive the exact full manifest when required;
- decision evaluation may receive exact resupply;
- future committed recovery retains only the safe candidate/manifest/portable
  digest/path-scope/lineage projection and derived evaluation outcomes;
- no D/E custody fact is invented.

If authoritative branch semantics require private manifest fields after commit,
return a precise blocker rather than weakening privacy.

PART III — SECTION 41 ROLE LOCATORS AND ROLE RESOLUTION

H. EVIDENCE-BINDING LOCATOR

Current migration 0003 has no `evidence_binding_ref`.

Choose one exact contract:

Preferred:

- use the current composite locator:
  `(proposal_ref, evidence_role, ordinal)`;
- bind `evidence_binding_digest` as the row identity;
- do not invent a synthetic ref.

Alternative:

- define a pure synthetic locator with exact schema, prefix, reference domain,
  preimage, and digest; justify why the composite locator is insufficient.

Reissue the role-resolution fields accordingly.

I. ROLE-SPECIFIC EXTRACTORS

For every role freeze:

- proposal schema;
- extraction of typed value ref/digest;
- whether source profile and source binding are required;
- C1 kind/rank/semantic/membership/value fields when required;
- transient-package source when not C1-durable;
- exact source posture;
- exact role/rank/ordinal;
- model-input posture;
- later decision-time currentness profile.

No generic “inspect a mapping” behavior is permitted.

J. ROLE-RESOLUTION POSTURE

Freeze whether the role resolution is:

```text
recomputable_from_resupply
admission_time_attested
future_decision_time_attested
```

Recommended target:

- pure recomputable relation while exact supply is available;
- future migration-0005 decision closure persists the relation result and
  typed locators/projections needed for committed recovery;
- no migration-0003 or C1 row change.

Freeze the relation value’s schema, key/ref or composite identity, digest,
profile, error algebra, and replay behavior.

PART IV — TOTAL LOCAL ALGEBRAS AND BEHAVIOR PROFILES

K. VALIDATION DISPOSITION

Freeze a complete total table over:

```text
source outcome
owner-supplied result
repairability
finite reason
```

Every allowed tuple must be explicit. Every disallowed tuple must fail.

Freeze deterministic reason precedence when multiple support facts are adverse.

Do not infer the owner-supplied disposition from coarse `failed`.

L. REVIEW DISPOSITION

Freeze the complete total table over:

```text
source outcome
independence status
owner-supplied result
finite reason
```

Every tuple and precedence must be explicit.

M. POLICY MATRIX

Freeze:

- exact ordered five branches;
- exact `governed | halt_only` applicability per branch;
- exact governed effect class per governed branch;
- complete `result/reason` table;
- complete condition-precedence table;
- evaluator/profile identity;
- source-policy currentness rules;
- exact not-before/expiry behavior;
- no policy-body reinterpretation by RW0-C.

N. RISK MATRIX

Freeze the same for risk, using the generic source-profile/binding interface.

Do not embed FiniteBacklog in the generic contract.

O. PROPOSAL-TIME STOP SNAPSHOT

Freeze a behavior profile covering construction from `global_stop_current`,
identity, timestamps, and the equal/higher/lower/missing/malformed decision-time
matrix.

P. SOURCE-EFFECT CEILING EVIDENCE

Correct the expiry grammar:

- attempt-fence expiry;
- effect-fence expiry;
- authority grant expiry;
- authority observation expiry;

must be preserved separately unless one exact profiled derivation is frozen.

Freeze componentwise ceiling comparison, total result/reason table, support
order, failure precedence, and branch-neutral posture.

Q. SUPPORT SET

Freeze its profile, entry schemas, exact allowed roles per owner value,
ordering, cardinality, duplicate/substitution behavior, and identity.

R. DECISION-TIME PROFILES

Freeze exact behavior profiles and complete result/reason tables for:

- proposal-evidence currentness;
- authority branch matrix;
- global-stop branch matrix;
- source-effect ceiling branch matrix;
- recommendation consistency.

Do not freeze the aggregate authoritative branch truth table yet.

S. PROFILE DISCIPLINE

Do not proliferate meaningless profiles.

For every behavior-sensitive value, either:

- its schema/version and closed total relation completely determine behavior;
  or
- it references one exact behavior profile with canonical JSON and digest.

Print exact canonical profile JSON and independently reproduced digests for
every required profile. Identify value schemas that need no separate profile
and explain why.

PART V — RW0-C MEMBERSHIP CLOSURE AND CURRENT SNAPSHOT

T. MEMBERSHIP CLOSURE OWNER

Freeze a new RW0-C-owned pure value, provisionally:

RW0CDecisionMembershipClosureV1

It does not change C1’s authority. It is an outer decision-time closure over
the complete admitted C1 phase membership.

Freeze:

- schema/ref/digest;
- phase pair;
- ordered complete membership entries;
- each entry’s kind/rank, membership pair, value schema/ref/digest, relation-set
  digest, admission-graph digest, and admitted_at as needed;
- member count;
- capture timestamp;
- closure profile;
- later-admission posture;
- privacy boundary.

U. EXHAUSTIVE PAGING ALGORITHM

Using the current private C1 page reader, freeze:

- initial cursor;
- page size;
- continuation cursor;
- strict monotonic progress;
- row-order checks;
- duplicate detection;
- overflow behavior;
- termination;
- full closure construction;
- no first-page shortcut;
- same transaction/capability epoch;
- replay and recovery identity.

Absence of a required member can yield `no_decision`; malformed paging or
inconsistent rows yields basis/integrity failure.

V. CURRENT SNAPSHOT

Freeze the minimum sufficient current snapshot after inspecting exact owner
rows. It must bind all coordinates actually required by the proposed
currentness, authority, stop, and ceiling profiles, including as applicable:

- program head/version/state/revision/digest;
- work head/revision/state/digest;
- selection head/state/revision/digest;
- effect head/state/revision/digest;
- delivery head/state/revision/digest;
- phase pair and K8;
- membership-closure pair;
- authority observation/current source coordinates;
- parent grant/family and expiry/revocation support;
- attempt/effect fences and separate expiries;
- policy and risk current-source coordinates;
- global-stop row;
- capture time.

Do not copy unrelated database state. Prove the selected inventory is complete
for the profiles in Part IV.

Freeze schema/ref/digest, owner locators, corruption/absence behavior, and
current-versus-proposal comparison.

PART VI — PRE-INvOCATION, ROLE, SNAPSHOT, AND RECOMMENDATION IDENTITIES

W. COMPLETE IDENTITY GRAMMARS

Freeze exact schemas, fields, types, nullability, ref preimages, digest domains,
self-exclusions, canonicalization, enums, bounds, and unknown-field behavior for:

- T1 context;
- transient supply package;
- role resolution;
- support set;
- membership closure;
- current snapshot;
- proposal-currentness value;
- authority/stop/ceiling matrices;
- recommendation-consistency value;
- all corrected owner values.

Print complete golden values or finite literal vectors sufficient for an
independent implementation.

PART VII — LOGICAL FUTURE COMMITTED-RECOVERY FAMILY

X. RETAINED LOGICAL VALUES

Without authorizing migration 0005, freeze the exact logical family that a
future committed RW0-C decision must retain.

At minimum:

1. outer command identity;
2. C1 phase pair and complete membership-closure value;
3. T1 context identity;
4. selected Section 41 rank-15 membership and complete family projection;
5. nine role-resolution results;
6. full safe proposal-time values needed after restart:
   - validation disposition;
   - review disposition;
   - policy matrix;
   - risk matrix;
   - stop snapshot;
   - source-effect ceiling evidence;
   - authority observation safe projection;
   - worker-result binding;
   - candidate-capsule safe projection;
7. current snapshot;
8. proposal-currentness result;
9. decision-time authority/stop/ceiling matrices;
10. recommendation-consistency result;
11. later branch-evaluation/attestation identities when frozen;
12. neutral C2B authorization basis when frozen;
13. outer result/receipt/recovery locators.

For each state whether the full value, safe projection, or immutable owner
locator must be retained.

Opaque aggregate digests alone are forbidden.

Y. RESTART STATES

Freeze:

```text
before proposal:
  exact supply required

after proposal but before decision:
  exact resupply required; absence -> no_decision

during uncommitted decision/replay:
  exact resupply required; mismatch -> basis_conflict

after commit:
  committed readback/recovery uses retained safe values/locators and never
  requires transient private supply or later mutable-head rereads
```

Do not freeze physical tables.

PART VIII — ASSURANCE COMPLETION

Z. EXTEND THE FINITE MATRIX

Add ordinary permanent tests and independent-audit mutants for:

- T1 context/source-invocation substitution;
- one role pair changed between T1 and Section 41;
- model receives a different canonical value under the same claimed ref/digest;
- proposal evidence unavailable before invocation;
- exact resupply absent after proposal;
- candidate manifest absent at decision;
- candidate manifest wrong bytes/ref/digest/schema/phase;
- profile-version substitution;
- stale evaluator identity;
- support-set role/order/substitution;
- role-relation reconstruction after restart;
- composite evidence-binding locator substitution;
- incomplete paging, nonprogress, duplication, and reorder;
- current snapshot omission/substitution;
- expiry-field collapse;
- invalid result/reason pair and reason precedence;
- missing typed recovery locator;
- committed recovery after mutable-head advancement;
- no C1 completeness authority;
- no migration/public/runtime widening.

Permanent tests remain ordinary semantic tests. Independent audit owns external
mutation, provenance, and owner-boundary checking.

PART IX — DECOMPOSITION AND READINESS

AA. PURE OWNER TRANCHE

Re-evaluate the migration-free module split. Preserve natural owners and avoid
disposable intermediate modules.

The corrected import DAG must explicitly include policy-value consumption by
role resolution and RW0-C without circular imports.

BB. IMPLEMENTATION-BOUNDARY READINESS

State whether the complete pure-owner tranche is now ready for an independent
contract audit.

Do not issue an implementation allowlist or implementation prompt.

STOP CONDITIONS

Return a precise blocker if closing these findings requires:

- changing existing B1/B2/C1/C2A meanings;
- changing Section 41 durable row meaning;
- adding a sixteenth C1 kind;
- persisting capsule entries/private bodies in C1 or migration 0003;
- claiming physical custody/retrieval inside C;
- model recommendation becoming authority;
- FiniteBacklog entering generic target risk semantics;
- migration/public API/runtime changes;
- C2B interpreting individual evidence;
- total branch truth table, effect cancellation, terminal, D/E, or ES semantics
  in this pass.

RETURN FORMAT

# Baseline and fixed audit input
# Preserved decisions
# T1 semantic-review input context
# Model-input and Section 41 equality relation
# Construction chronology and SQL write order
# Transient supply and resupply contract
# Candidate-capsule privacy and resupply
# Section 41 role locators and extractors
# Role-resolution posture and identity
# Total validation disposition algebra
# Total review disposition algebra
# Policy and risk matrix algebras
# Stop and source-effect ceiling profiles
# Support-set contract
# Decision-time behavior profiles
# C1 membership closure and paging
# RW0-C current snapshot
# Complete identity grammars and golden vectors
# Future committed-recovery logical family
# Restart and replay states
# Extended finite assurance matrix
# Pure owner-tranche decomposition
# Remaining seams and stop conditions
# Recommended next step
# Confidence

SUCCESS TOKEN

Return exactly:

RW0_POST_EXECUTION_CONTEXT_RESUPPLY_SNAPSHOT_RECOVERY_OWNERS_READY_FOR_INDEPENDENT_AUDIT

only if:

- the T1 model-input contract is exact;
- the model is bound to the same nine later Section 41 pairs and values;
- transient/private resupply and restart semantics are exact;
- candidate-capsule privacy and availability are compatible;
- role locators/extractors are exact;
- every local result/reason algebra is total;
- all behavior profiles and value identities reproduce;
- membership closure and current snapshot are complete but bounded;
- future committed recovery has exact safe values/locators;
- assurance is finite;
- no implementation prompt is issued.

Otherwise return:

RW0_POST_EXECUTION_CONTEXT_RESUPPLY_SNAPSHOT_RECOVERY_OWNER_BLOCKED

and identify the exact unresolved owner, privacy, or recovery decision.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
