# Decision

**Accept the owner direction, but do not send this contract to independent audit yet. It needs one more read-only reconciliation.**

Codex has made the important architectural decisions correctly:

- C2B owns one private, branch-parameterized progression-decision family.
- RW0-C consumes a bounded C2B facade; C2B does not import or interpret RW0-C.
- The common Coordinator transaction remains the sole connection, mutation-slot, timestamp, and commit authority.
- The first writer profile is explicitly single-work for advancing branches.
- Accept, repair, replan, terminal reject, block, and cancel now have plausible branch-specific progression semantics.
- Migration `0005` remains RW0-C-owned; migration `0002` and its existing row meanings remain unchanged.
- The C2B owner module and RW0-C composition may land in one eventual candidate while remaining separately auditable seams. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

Those decisions should be preserved.

## Why it is not yet an auditable freeze

### 1. The report is not grounded in the real repository paths

Its principal source links use:

```text
src/governed_execution_nwp_coordinator/
```

and place the migration under a `migrations/` directory. :chatgpt-content-reference{index="3"}

The merged repository actually uses:

```text
src/ge_nwp_coordinator/
src/ge_nwp_coordinator/sqlite_migrations/
```

The live merged `_development_program_row_values.py` is at the former path, and the report’s package path returns no file. 

This may be a report-generation mistake rather than a semantic failure, but an independent contract audit needs exact valid paths and lines. The next pass must correct every citation and rebuild the path-derived surface from the actual tree.

### 2. The “profile” is only a name, not a frozen identity

The report names:

```text
governed-execution.nwp-c2b-progression-single-work-profile.v1
```

and gives its broad behavior, but it does not provide:

- a canonical manifest;
- profile ref versus schema ID;
- canonicalization rules;
- digest domain;
- profile digest;
- where that profile pair is bound in the command, receipt, RW0-C attestation, replay, and recovery.

:chatgpt-content-reference{index="5"}

That leaves future code free to change the meaning of “single-work profile v1” without changing durable identities.

### 3. The command and write-plan contracts remain implicit

The report says the owner accepts an “exact closed C2B command” and returns sealed advancing or non-advancing plans, but never freezes their field order, schemas, digest domains, branch unions, preassigned locators, or bounded cardinalities. :chatgpt-content-reference{index="6"}

That is material because the command digest governs:

- replay;
- mutation-ref reuse;
- current-head preimages;
- all preassigned result identities;
- definitely-not-committed proof;
- composed RW0-C recovery.

The current decision row itself has 43 ordered fields, including all basis, result, target, source, successor, reason, time, and digest fields.  The next report must give an exact per-branch projection over those fields rather than only a prose description of created rows.

### 4. Decision `reason_code` provenance is unresolved

The branch matrix defines versions, memberships, states, and edges, but it never says who owns the actual `reason_code` inserted into the C2B decision:

- copied from the Section 41 proposal;
- copied from another owner result;
- selected from a new closed C2B profile vocabulary;
- or supplied by the RW0-C caller.

The last option would be an authority error. The decision row’s `reason_code` is part of its canonical identity, so this cannot be left to implementation judgment. 

### 5. SQL and private-reader contracts are still conceptual

The report provides a high-level single-work query and CAS semantics, but not the literal private query contract needed for audit:

- exact columns;
- predicates;
- ordering;
- limits;
- tuple shapes;
- cardinality classification;
- collision queries;
- immutable insert SQL;
- CAS SQL;
- branch readback;
- recovery locators.

The proposed CAS order—work head first, program head second—is plausible, but an auditor cannot verify a contract that does not yet state its exact predicates and assignments. :chatgpt-content-reference{index="9"}

### 6. The mutation-graph contract is asserted, not reconciled

The report proposes exact role sequences for every branch. :chatgpt-content-reference{index="10"}

It does not prove that:

- each role string conforms to the current graph-entry grammar;
- ordinal and ordering behavior matches the current digest helper;
- the receipt envelope used in the digest is exact;
- no current graph meaning is being reinterpreted.

That must be resolved against the actual current graph owner before audit.

### 7. Recovery is not an exact value contract

The report gives a strong recovery concept but not:

- a recovery-selector schema;
- ordered selector fields;
- when it is constructible;
- every preassigned operation-owned locator;
- exact DNC absence routes;
- a recovery-result schema.

It also uses `committed_exactly`, while the merged RW0-C recovery vocabulary and the surrounding project work consistently use `committed_exact`. :chatgpt-content-reference{index="11"}

That may be a wording error, but a frozen composition contract cannot have ambiguous result vocabulary.

### 8. Global-stop historical reconstruction is not proven

The report correctly makes replay receipt-first and says later stop activation cannot invalidate replay. It records only the stop ref/version in the decision. :chatgpt-content-reference{index="12"}

The next pass must prove how historical stop state is reconstructed after the mutable current row advances:

- immutable stop history;
- command-bound state;
- receipt/graph projection;
- or another current owner mechanism.

It cannot implicitly rely on the later current row.

## What remains accepted

```text
C2B owner:
one branch-parameterized private family

advancing first profile:
single-work only

cancel:
non-version-advancing and membership-neutral

composition:
one controller, transaction, timestamp, and commit

migration 0002:
unchanged

migration 0005:
RW0-C-owned

latch:
RW0-C physical row; C2B accept-eligibility semantics only

implementation sequencing:
C2B and RW0-C may land in one candidate, but in separate owner modules
```

The proposed branch semantics are good enough to preserve as the starting point:

```text
accept:
accepted version, accepted program/work heads

repair:
repair version, active program, repair_required work

replan:
new intent revision, new same-work replan revision,
two supersession edges, active/planned heads

terminal reject:
terminal_rejected version and heads

block:
blocked version and heads under the sole-work profile

cancel:
decision and receipt only; no version or head mutation
```

:chatgpt-content-reference{index="13"}

# Next step

Run one final read-only freeze reconciliation that converts this conceptual owner design into an exact audit target. Do not implement and do not start the independent audit yet.

:chatgpt-content-reference{index="21"}[Download the C2B owner-freeze reconciliation prompt](sandbox:/mnt/data/Coordinator_C2B_Progression_Decision_Owner_Freeze_Reconciliation_V2_Prompt.txt)

```text
Filename:
Coordinator_C2B_Progression_Decision_Owner_Freeze_Reconciliation_V2_Prompt.txt

Size:
17,874 bytes

SHA-256:
4f0f84765e4ca53908327992e7030376b3c56edb5c906dd1ca9c26fec1c7d94d
```

The successful result is:

```text
C2B_PROGRESSION_DECISION_OWNER_FREEZE_RECONCILED_READY_FOR_INDEPENDENT_AUDIT
```

That result must include exact:

- path-correct sources;
- profile manifest and digest;
- command grammar;
- branch decision-row matrix and reason-code ownership;
- immutable write-plan schemas;
- literal private queries and CAS specifications;
- mutation-graph contract;
- result and completed-receipt digest;
- recovery selector and three-way result vocabulary;
- historical global-stop binding;
- composition seam;
- provisional path-derived implementation surface.

Only then should we commission an independent contract audit.

## Current project state

```text
RW0-C1:
merged and current

RW0-C-Decision C-local contract:
substantially reconciled

C2B progression semantics:
direction selected, exact owner freeze still incomplete

migration 0005:
not implementation-authorized

RW0-C-Terminal / migration 0006:
blocked on D/ES owner contracts

RW0-D / RW0-E:
not implemented
```

### Sources

- Attached C2B owner-reconciliation report. :chatgpt-content-reference{index="14"} :chatgpt-content-reference{index="15"} :chatgpt-content-reference{index="16"}
- Live merged source path and current program-row owner.  
- Current 43-field decision and receipt owner grammar.  

**Confidence:** High that the branch architecture and composition direction are sound; high that the current report is not exact enough for independent audit or implementation; high that the additional reconciliation can remain read-only and bounded.

Some older Project uploads have expired. The current attachment and live merged source were sufficient for this assessment; re-upload an older file only if the next pass specifically needs its contents.
