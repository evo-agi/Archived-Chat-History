Here is Codex's response:

Decision: **Option B — two independently acceptable durable tranches.** RW0-C2 should first add phase-scoped decision-basis closure plus the one-shot productive-direct-local acceptance latch, then add separate terminal closure and outcome. No existing owner contract needs reconciliation before the C2 contract-freeze pass.

Classification labels used below are exactly: `current owning contract`, `current merged implementation`, `compatibility edge`, `reopened target seam`, `strategic target`, `implementation detail`, and `report-only uncertainty`.

## 1. Baseline and inspection boundary

- **[current merged implementation]** Inspected branch `trunk_dev` at HEAD `a3ff0b7f4f0c2378c2962e24612d605489b51638`, tree `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0`, parent `047563de5a443b0f8323401c92979ae2e444d2ed`.
- **[current merged implementation]** The branch matched `origin/trunk_dev` with ahead/behind `0/0`, used one worktree, and remained clean before and after inspection.
- **[current merged implementation]** Inspection was local and read-only. It covered `.docs/`, migration SQL/catalog code, C2A/C2B/Section 41 value and row contracts, C1 mutation/read/recovery code, writer/transaction integration, and direct C1 tests.
- **[current merged implementation]** No tests, migrations, external executables, supporting repositories, network operations, or remote Git operations were run.
- **[current owning contract]** `.docs/` was treated as authoritative throughout.

Principal evidence anchors:

- [RW0-C1 durable evidence](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c1-durable-evidence.md:3>)
- [RW0 phase-entry target](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:127>)
- [RW0-B1 pure phase values](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-b1-pure-phase-values.md:171>)
- [Wire cancellation-control contract](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-b2-wire-protocol.md:106>)
- [C2B durable development state](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:7250>)
- [Current C2B decision grammar](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:77>)
- [Migration catalog](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migration.py:31>)
- [Coordinator transaction controller](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_transition_transaction.py:773>)
- [C1 writer delegation](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_writer_session.py:6429>)

## 2. Current contract versus strategic target

| Classification | Finding |
|---|---|
| **current merged implementation** | RW0-C1 durably establishes one immutable phase and admits exact evidence memberships through private guarded-writer mutations. It implements idempotency, fencing, commit uncertainty, exact readback, and three-way recovery. |
| **current owning contract** | A C1 membership proves admitted presence of one exact member. It does not prove family completeness, currentness at a later decision, external authenticity, semantic acceptance, execution permission, or terminality. |
| **current merged implementation** | C2B physically represents the exact development-decision variants and the `development_progression_decision_recorded` result/receipt grammar, but progression-decision mutation runtime is not implemented. |
| **current owning contract** | Section 41 owns the post-execution proposal family: source invocation, private artifact binding, model proposal, and either zero or exactly nine evidence bindings. The proposal is not program truth or a Coordinator decision. |
| **current owning contract** | B1 supplies pure terminal-outcome values and relations only. Wire supplies pure classifications only. C2A supplies pure source-value and relation contracts only. |
| **strategic target** | The Coordinator first commits one matching C2B decision, consuming the latch only for productive direct-local accept, and later commits a distinct RW0 terminal outcome. |
| **strategic target** | Active cancellation uses one pre-effect `cancel` decision. A later terminal `cancel` or `block` binds that same decision and never creates a second cancel/block decision. |
| **reopened target seam** | C2 currently has no frozen closure identities, rows, commands, result projections, receipts, SQL, mutation runtime, or recovery proofs. |

## 3. Observable RW0-C2 capability

- **[implementation detail]** The smallest non-disposable C2 capability is a private writer-fenced state transition from “C1 evidence only” to “one exact C2B decision with a durable decision-basis closure.”
- **[implementation detail]** Productive direct-local `accept` additionally performs the only permitted latch transition, atomically with that decision.
- **[implementation detail]** A second private mutation moves the phase from “decision committed, nonterminal” to “one terminal closure and one B1-conformant terminal outcome.”
- **[implementation detail]** The durable states are therefore explicit:

  1. Phase/evidence exist; no decision closure.
  2. Decision closure and C2B decision are committed; terminal outcome is absent, so RW0 remains nonterminal.
  3. Terminal closure and outcome are committed; RW0 is closed.

- **[current owning contract]** State 2 permits no successor, Git effect, publication, or speculative second decision. The sole exception is that a current compatible `effect_cancellation` decision may later basis its separately governed cancellation effect.
- **[implementation detail]** C2 remains private SQLite composition. It adds no public reader, public `WriterSession` method, service, process, worker, model call, adapter, supervisor, ES call, Git effect, or publication behavior.

## 4. Decomposition and acceptance boundary

**Option B is selected.**

### Tranche C2.1: decision closure and acceptance latch

- **[implementation detail]** Atomically create the decision-basis closure and members, write the exact C2B decision and its existing C2B result/receipt family, create the C2 closure-to-decision binding/result, and conditionally consume the latch.
- **[implementation detail]** This tranche is independently acceptable because its committed decision is durable progression truth that the later terminal outcome must reuse. Absence of a terminal outcome has one unambiguous meaning: nonterminal and fail-closed.
- **[implementation detail]** Commit uncertainty blocks later contact until exact recovery. A committed accepted decision retains its consumed latch even if terminal recording is delayed.

### Tranche C2.2: terminal closure and outcome

- **[implementation detail]** Atomically create a separate terminal closure and members, any exact reconciliation or mismatch projection, the B1 terminal outcome, and a terminal result/receipt.
- **[implementation detail]** This tranche depends on a committed C2.1 decision but does not rewrite it, consume the latch, or create another C2B decision.

### Why not the alternatives

- **[implementation detail]** Option A is rejected because combining the decision transaction, latch CAS, terminal closure, and all active-cancellation reconciliation into one implementation tranche creates an unnecessarily large authority and recovery surface.
- **[implementation detail]** Option C is rejected because the current owners already provide sufficient identities, pure relations, decision variants, writer fencing, and commit-recovery mechanics to freeze C2 without changing upstream contracts.

### Migration cut

- **[implementation detail]** Use two additive migrations aligned with the two acceptance boundaries:

  - Migration 0005: decision closure, closure membership/binding/result, and acceptance latch.
  - Migration 0006: terminal closure, terminal membership, reconciliation/mismatch projection, terminal outcome, and terminal receipt/result.

- **[implementation detail]** Both remain application generation 2 unless the contract-freeze audit identifies an actual generation incompatibility. No current evidence requires a generation bump.
- **[implementation detail]** Splitting the migrations avoids landing unused terminal schema in the independently accepted decision tranche.

## 5. Decision-basis closure

### Closure moment and identity

- **[implementation detail]** The decision closure is evaluated inside the same `BEGIN IMMEDIATE` transaction that records the decision, after writer fencing and idempotency lookup and after rereading all current owner rows.
- **[implementation detail]** The closure is inserted atomically with the decision; it is never a separately committed authorization token.
- **[implementation detail]** Its identity must include a preassigned safe closure ref, exact C1 phase ref/digest and K8 identity, branch profile, current owner snapshots, ordered member-set digest, closure timestamp, and closure self-digest.
- **[implementation detail]** Each closure binds exactly one decision, and each RW0 decision binds exactly one closure. Reusing admitted evidence across closures is allowed; reusing one closure for multiple decisions is forbidden.

### Membership and completeness

- **[current owning contract]** C1 membership identity is the membership ref/digest pair. The underlying evidence value ref/digest alone is insufficient because one reusable value may have different phase admission histories.
- **[implementation detail]** Closure members therefore store the exact C1 membership ref/digest, evidence kind, safe value schema/ref/digest, role rank, and ordinal.
- **[implementation detail]** Member ordering must be dense and canonical by closure-owned role rank and ordinal. Duplicates, gaps, aliases, unknown roles, and surplus members fail closed.
- **[implementation detail]** A closure proves completeness only against one named C2 branch profile. It must not upgrade C1’s general membership semantics.

### Admission-time validation versus decision-time recomputation

- **[current owning contract]** C1 validation proves relations at evidence-admission time.
- **[implementation detail]** C2 must reread current heads, stop state, authority windows, fences, selection, effect/delivery state, decision lineage, and all addressed C1 memberships.
- **[implementation detail]** Pure B1, C2A, Wire, Capability, Section 41, and C1 relations are rerun at the decision timestamp using exact durable values plus any required private transient operands.
- **[implementation detail]** Wire cancellation-control classification is recomputed from its exact operand closure. Because that classification has no durable identity, C2 stores only its finite classification/reason, the fixed profile ref/digest, and an operand-set digest as a derived closure fact—not as a Wire source fact.
- **[implementation detail]** Any required transient WorkSpec, capsule manifest, before/after blob-set value, or private artifact must be supplied before transaction entry, validated purely, retained only for the operation, and never written as raw content.

### Exact decision mapping

Every decision uses the existing result class `development_progression_decision_recorded` and schema `governed-execution.nwp-record-development-progression-decision-result.v1`.

| Branch | Exact C2 closure rule | Exact C2B decision |
|---|---|---|
| Productive accept | **[implementation detail]** Complete Section 41 family with all nine evidence roles and recommendation `accept_candidate`; exact candidate capture and capsule seal; usable worker/process result binding; `validation_completed=passed`; `independent_review_completed=passed`; verified/current authority; clear stop; exact current heads/fences; qualified direct-local route; latch preimage available. | `accept` / `candidate_acceptance` |
| Repair | **[implementation detail]** Complete Section 41 family with recommendation `repair_candidate`; exact sealed candidate/capsule and usable result; at least one validation/review result is `failed`; no missing, contradictory, expired, or inconclusive prerequisite; repair reason is finite under the frozen C2 policy; successor attempt/candidate refs are preassigned. | `repair` / `candidate_repair` |
| Replan | **[implementation detail]** Complete Section 41 family with recommendation `replan`; current phase selection and candidate are bound; exact evidence establishes an unusable attempt, changed accepted intent, or non-repairable planning basis; clear stop; new accepted-intent revision, work item/revision, WorkSpec safe binding, and successor attempt/candidate are already valid and supplied. | `replan` / `attempt_selecting_replan` |
| Terminal reject | **[implementation detail]** Complete Section 41 family with recommendation `terminal_reject`; exact validation/review/policy evidence establishes a finite non-repairable rejection under current policy; selected attempt/candidate/fence remain exact. | `terminal_reject` / `program_terminal_reject` |
| Post-execution block | **[implementation detail]** Complete Section 41 family with recommendation `block`; evidence is complete enough to establish a finite safe block but insufficient or incompatible for accept, repair, replan, or terminal rejection. | `block` / `program_block` |
| Pre-contact/gate block | **[implementation detail]** Section 41 family must be zero, not incomplete; exact authority, stop, custody, readiness, host, or mechanism evidence establishes the blocking gate; the complete phase-addressed C1 set contains no admitted contact/result facts. This proves no Coordinator-admitted contact, not physical non-contact. | `block` / `program_block` |
| Pre-effect cancellation | **[implementation detail]** No Section 41 proposal is required. Bind the exact current target effect/fence/head/delivery/command, stop or cancellation directive and source evidence, current authority, capsule pair where required, and preassigned cancel effect/fence/first delivery identities. | `cancel` / `effect_cancellation` |

Additional decisions:

- **[implementation detail]** `program_replan` is not used by phase-specific RW0-C2. It remains valid C2B grammar for a program-scoped replan outside this phase composition.
- **[implementation detail]** `productive_redelivery` and `cancellation_redelivery` are not C2 terminal decisions.
- **[implementation detail]** Ambiguous mapping between repair, replan, terminal reject, and block resolves to `program_block`; C2 must never infer the more permissive branch.
- **[implementation detail]** A zero-member Section 41 family is acceptable only for a specifically frozen pre-contact/gate block or the pre-effect cancellation path. It is never sufficient for a post-execution decision.

## 6. Productive-direct-local acceptance latch

- **[strategic target]** The latch is Coordinator-owned, global to the Coordinator bootstrap scope, one-shot, and named `direct_local_first_productive_acceptance`.
- **[implementation detail]** Migration 0005 seeds exactly one row in state `available`, version `0`, with all consumption bindings absent.
- **[implementation detail]** The only legal update is a guarded CAS from `available/0` to `consumed/1`, in the same transaction as `accept/candidate_acceptance`.
- **[implementation detail]** The consumed postimage binds:

  - accepted decision ref/digest;
  - decision-closure ref/digest;
  - resulting program-version ref/number/digest;
  - candidate ref;
  - capsule-manifest ref and portable capsule digest;
  - C2B result-projection digest;
  - consumption timestamp;
  - latch-postimage digest.

- **[implementation detail]** Reset, deletion, reinsertion, repair, reuse, version skipping, or binding replacement is forbidden by SQL guards and typed values.
- **[implementation detail]** Repair, replan, terminal reject, block, and cancel mutations neither read for semantic use nor bind nor mutate the latch.
- **[implementation detail]** Exact replay of the already committed accept returns its receipt and postimage. An already-consumed latch owned by any different decision is a conflict, not a new accept.
- **[implementation detail]** Missing, duplicate, malformed, or illegally advanced latch state is database-integrity failure.
- **[strategic target]** Terminal accept later reads and binds the exact consumed postimage. It performs no latch update.

## 7. Terminal closure and outcome

- **[implementation detail]** Terminal closure is a new closure moment after exact decision commit or recovery. It has its own ref/digest, member set, timestamp, and current head/stop snapshot.
- **[implementation detail]** Decision closure and terminal closure must remain distinct even when many evidence members overlap. The first answers “why was this decision committed?”; the second answers “why is RW0 now closed?”
- **[implementation detail]** At most one terminal outcome may exist per C1 phase and per C2 decision. A different attempted outcome collides rather than superseding.
- **[current owning contract]** Normal outcomes must match their decision kind exactly:

| Decision | B1 branch/outcome |
|---|---|
| `accept/candidate_acceptance` | `normal` / `accept`, with exact latch postimage |
| `repair/candidate_repair` | `normal` / `repair` |
| `replan/attempt_selecting_replan` | `normal` / `replan` |
| `terminal_reject/program_terminal_reject` | `normal` / `terminal_reject` |
| `block/program_block` | `normal` / `block` |

- **[implementation detail]** A normal terminal closure binds the exact decision closure and C2B decision/result/receipt, current program/work/selection/effect/delivery heads, current stop observation, and the complete terminal member set.
- **[implementation detail]** Unexpected progression-head drift after the decision is an integrity/conflict condition because the phase must permit no intervening successor. A later global-stop version is recorded exactly but does not rewrite the already committed decision.
- **[strategic target]** Normal cleanup or custody facts may follow terminal closure without altering the outcome.
- **[strategic target]** No terminal outcome launches a successor, Git effect, or publication within RW0.

## 8. Cancellation branches

### A. Pre-effect cancel decision

- **[strategic target]** Commit one `cancel/effect_cancellation` decision before establishing any cancellation effect.
- **[implementation detail]** Its decision closure binds the exact target effect lineage, current head and stop, original command, source directive/evidence, and preassigned cancellation effect/fence/delivery identities.
- **[implementation detail]** Commit uncertainty must resolve before currentness verification or cancellation-effect establishment.

### B. Pre-effect basis unusable

- **[strategic target]** If that exact decision is missing, stale, superseded, incompatible, or ambiguous when reread, establish no cancel effect, fence, delivery, request, or signal.
- **[implementation detail]** The terminal closure stores an exact expected-versus-observed mismatch projection and produces:

  - decision kind `cancel`;
  - branch `pre_effect_cancel_basis_unusable`;
  - outcome `block`;
  - mismatch ref/digest present;
  - reconciliation and latch pairs absent.

- **[strategic target]** No replacement C2B `cancel` or `block` decision is created.
- **[implementation detail]** Bounded absence checks may prove absence of addressed Coordinator rows for the preassigned cancel effect/fence/delivery. They do not claim physical process or network absence.

### C. Active cancel reconciled

- **[strategic target]** Once a compatible cancellation effect exists, source-native reconciliation must cover the request, response, signal state, target-process exit, process-group and descendants, workspace teardown, capsule custody/retrieval, and applicable delivery/source receipts.
- **[implementation detail]** The terminal closure binds exact C1 membership identities for those facts, their owner-row projections, current heads/stop, and a closure-time Wire cancellation-control classification.
- **[current owning contract]** Wire `finite` means only `cancellation_rejected` or `target_process_exited` in the supplied control graph. It is not terminal cancellation.
- **[implementation detail]** `cancellation_rejected` can support terminal `cancel` only when the later source-native reconciliation independently proves the entire branch complete and nonambiguous. Otherwise the outcome is `block`.
- **[implementation detail]** Complete reconciliation produces:

  - decision kind `cancel`;
  - branch `active_cancel_reconciled`;
  - outcome `cancel`;
  - reconciliation ref/digest present;
  - mismatch and latch pairs absent.

### D. Active cancel unresolved

- **[strategic target]** Incomplete, contradictory, stale, unauthenticated, or ambiguous reconciliation closes as `block` against the same cancel decision.
- **[implementation detail]** The closure must contain explicit source-owned unknown/negative/conflict observations for required external roles; missing SQLite rows alone cannot prove physical absence.
- **[implementation detail]** The outcome is:

  - decision kind `cancel`;
  - branch `active_cancel_unresolved`;
  - outcome `block`;
  - reconciliation ref/digest present and identifying the unresolved graph;
  - mismatch and latch pairs absent.

- **[strategic target]** No second C2B block decision is created.

## 9. Action prerequisite matrix

| Prerequisite | Owner | Needed for | Failure behavior | Classification |
|---|---|---|---|---|
| Exact C1 phase and K8 | C1 | Both tranches | Conflict/integrity failure | current owning contract |
| Exact C1 membership identities | C1 | Both | Missing member fails branch completeness | current owning contract |
| Branch-specific completeness profile | C2 | Decision | No decision until frozen; ambiguity maps to block | implementation detail |
| Current program/work/selection/effect/delivery heads | C2B | Both | Apply conflict or unresolved recovery | current owning contract |
| Current global stop | Operator/repo policy + C2B storage | Both | Recorded exactly; active state blocks productive branches | current owning contract |
| Complete Section 41 post-execution family | Section 41 | Normal post-execution decisions | Zero only for explicit gate-block/cancel profiles; partial always invalid | current owning contract |
| Private transient WorkSpec/capsule operands | Existing private caller; later D | Pure recomputation | No raw persistence; unavailable operands block the consuming branch | implementation detail |
| C2B successor revision/attempt identities | C2B/external provisioning seam | Repair/replan | Fail closed; C2 never fabricates them | reopened target seam |
| Qualified direct-local mechanism/host | B1/B2 + later D/E source proof | Productive accept | Accept unavailable; another finite branch may be selected | strategic target |
| Latch available preimage | C2 | Productive accept | Conflict; no decision | implementation detail |
| Cancellation request/process/teardown/custody evidence | D/ES/source owners | Active-cancel terminal outcome | Unresolved branch becomes terminal block | strategic target |
| External authenticity and live trust | External verifier/E | Live claim | Fake/offline C2 mechanics may be tested; live terminal assertion remains blocked | reopened target seam |
| Exact commit recovery | C2 using common transaction owner | Both | `commit_outcome_unknown`, then fresh-writer recovery; no speculative retry | implementation detail |

## 10. Exhaustive owner-reuse ledger

| Existing family | Reuse in C2 | C2 may add | C2 must not claim | Classification |
|---|---|---|---|---|
| C1 phase, K8 and phase digest | Exact phase anchor | Closure reference/binding | New phase identity or changed K8 | current owning contract |
| All 15 C1 evidence kinds | Exact membership ref/digest and owner value binding | Branch-specific completeness over selected memberships | That admitted membership alone is complete/current/authentic | current owning contract |
| C1 registry, dependency, relation, operand, typed-family and page readers | Transaction-internal exact reads | New C2 family locators/readers | Public read API or altered frozen C1 queries | current merged implementation |
| C1 Section 41 zero-or-nine family reader | Establish exact owner family shape | Require nine for post-execution decisions | Treat zero as post-execution completeness | current merged implementation |
| C1 mutation receipts and recovery model | Pattern for receipt-last, uncertainty and three-way recovery | C2-specific result/receipt proof | Reinterpret C1 receipts as decisions/outcomes | current owning contract |
| B1 phase/authority/custody/qualification/terminal pure values | Rerun exact relations; use terminal shape | Durable C2 rows representing validated outputs | Source authenticity, permission or I/O | current owning contract |
| NWPF v1 and process-result classifier | Validate exact wire/result evidence | Closure member and derived result binding | Transport/runtime authority | current owning contract |
| Wire cancellation-control profile | Recompute from exact operands | Profile/operand closure plus derived classification/reason | Durable Wire identity or terminality | current owning contract |
| Capability declaration/observation/qualification | Bind exact C1 memberships and recompute qualification | Decision closure binding | Physical host proof or permission | current owning contract |
| C2A WorkSpec/fences/command/delivery/observation/capsule values | Reconstruct safe values and rerun owner relations | Ref/digest projections and transient-operation use | Raw content custody or source authenticity | current owning contract |
| C2B `development_decisions` | Write exact existing variants | C2 closure binding | New or reinterpreted decision kind/variant | current owning contract |
| C2B program/version/work/head rows | Perform exact existing branch-specific state changes | None beyond closure references | Parallel progression head | current owning contract |
| C2B `development_mutation_receipts` and `development_progression_decision_recorded` | Insert and verify exact nested decision receipt/result | Outer C2 closure binding/result | Alter existing schema or result projection | current owning contract |
| Section 41 source/artifact/proposal/evidence rows | Bind exact family and proposal recommendation | Closure membership references | Model output as decision or durable truth | current owning contract |
| Common writer guard, mutation slot, bound DB, fencing, capability epoch and transaction controller | Own both C2 transactions | Narrow private entries | Parallel connection/transaction authority | current merged implementation |
| D/E/ES future facts | Later input to C2 through exact safe projections | C2 reconciliation bindings only | Process, custody, transport, verifier or runtime ownership | strategic target |

The 15 C1 kinds reused through that ledger are:

`authority_verification_observation`, `subordinate_authorization_proposal`, `custody_availability_observation`, `retrieval_capability_event_observation`, `remote_host_readiness_observation`, `effect_host_qualification`, `worker_mechanism_capability_declaration`, `worker_mechanism_capability_observation`, `worker_mechanism_capability_qualification`, `wire_cancellation_request_observation`, `wire_process_observation`, `c2a_worker_observation`, `wire_worker_result_binding`, `wire_process_result_classification_binding`, and `section41_post_execution_proposal_family_member`.

## 11. Logical facts and migration strategy

### Migration 0005 logical facts

- **[implementation detail]** Immutable decision-closure header.
- **[implementation detail]** Immutable ordered decision-closure members.
- **[implementation detail]** Immutable closure-to-C2B-decision binding and C2 outer result/receipt, referencing the existing development decision/result/receipt.
- **[implementation detail]** Singleton acceptance latch with one legal CAS.
- **[implementation detail]** No new progression head.

### Migration 0006 logical facts

- **[implementation detail]** Immutable terminal-closure header.
- **[implementation detail]** Immutable ordered terminal-closure members.
- **[implementation detail]** Immutable cancellation reconciliation or pre-effect mismatch projection, present only on the corresponding branch.
- **[implementation detail]** Immutable B1-shaped terminal outcome.
- **[implementation detail]** Immutable terminal result/receipt.
- **[implementation detail]** No terminal head, supersession, update, or reopening mechanism.

### Physical constraints

- **[implementation detail]** All tables are STRICT, explicit-column, closed-world tables. Generic JSON records, metadata bags, nullable extension columns, and unbounded payloads are prohibited.
- **[implementation detail]** Foreign keys use `ON UPDATE RESTRICT ON DELETE RESTRICT`.
- **[implementation detail]** All closure/outcome/member/binding/receipt rows are append-only with no-update/no-delete guards.
- **[implementation detail]** Unique constraints enforce one decision per closure, one closure per decision, one terminal outcome per phase, one terminal closure per decision, and dense unique member positions.
- **[implementation detail]** The latch allows only the exact version-0 available to version-1 consumed transition; triggers reject every other update and all deletion.
- **[current merged implementation]** Migrations 0001–0004 remain byte-for-byte immutable. The current cumulative schema is 62 tables, 110 triggers, and 5 indexes at generation 2.
- **[implementation detail]** Each new migration extends the packaged cumulative schema manifest and catalog hash. Initialization applies the complete new tip; explicit migration applies the exact contiguous suffix.
- **[report-only uncertainty]** Exact table/trigger/index counts and final migration IDs should be frozen only after the logical schema and guards are audited.

A formerly contemplated “migration 0003 decision-evidence binding” must not be revived: migration 0003 is now the immutable Section 41 migration. New bindings belong in 0005.

## 12. Transaction, replay and recovery

### Common operation order

1. **[implementation detail]** Pure closed-world command preflight occurs before mutation-slot acquisition.
2. **[current merged implementation]** Enter the existing operation guard and one resource-owned mutation slot.
3. **[current merged implementation]** Open one fresh state-root-bound managed connection and execute `BEGIN IMMEDIATE`.
4. **[current merged implementation]** Revalidate filesystem binding, managed schema, and durable writer issuance.
5. **[implementation detail]** Perform receipt-first idempotency lookup only after writer fencing.
6. **[implementation detail]** Read exact C1/C2B/C2 rows through the nominal capability and classify cardinality.
7. **[implementation detail]** Capture one whole-second Coordinator timestamp and rerun branch relations/currentness.
8. **[implementation detail]** Construct one immutable write plan.
9. **[implementation detail]** Write data rows, then nested C2B decision receipt where applicable, then the outer C2 result/receipt last.
10. **[current merged implementation]** Invalidate the capability before one commit attempt; close with existing cleanup precedence.

### Replay

- **[implementation detail]** Same mutation ref and same outer canonical command digest returns only after reconstructing the exact complete family.
- **[implementation detail]** Same mutation ref with another digest conflicts.
- **[implementation detail]** The decision replay verifies the closure/member graph, C2B decision, result, development receipt, branch state changes, C2 binding/result, and latch postimage when accepting.
- **[implementation detail]** Terminal replay verifies the terminal closure/members, reconciliation or mismatch projection, B1 outcome, result and receipt.
- **[current owning contract]** Replay does not call a clock, re-evaluate a model proposal, re-consume the latch, or reveal idempotency detail to a stale writer.

### Commit uncertainty

- **[current owning contract]** Any exception after commit attempt, or cleanup that prevents proving the result safe, surfaces only as `commit_outcome_unknown`.
- **[implementation detail]** Automatic retry is forbidden. A fresh writer must invoke the family-specific recovery selector.

### Decision recovery

- **[implementation detail]** `committed_exact` requires the exact closure/member graph, decision, program/version/work/head postimages, nested development result/receipt, C2 binding/result/receipt, and exact consumed latch postimage when accepting.
- **[implementation detail]** `definitely_not_committed` requires all preassigned target identities absent and every authoritative preimage still exact, including latch `available/0` for accept.
- **[implementation detail]** Any partial family, digest alias, collision, changed preimage, unexpected latch state, unverifiable cleanup, or ambiguous head is `unresolved`.

### Terminal recovery

- **[implementation detail]** `committed_exact` requires the complete terminal closure/member graph, branch-specific reconciliation/mismatch row, exact outcome, result and receipt.
- **[implementation detail]** Accept additionally requires the unchanged consumed latch postimage already owned by the accepted decision.
- **[implementation detail]** `definitely_not_committed` requires all terminal target identities absent while the exact committed decision and expected terminal preimages remain intact.
- **[implementation detail]** Partial, conflicting, aliased, or unprovable evidence is `unresolved`.
- **[strategic target]** An unresolved decision or terminal outcome permits no new effect, successor, Git action, or publication.

## 13. Authority and privacy

| Persistence class | Material | Classification |
|---|---|---|
| Fully durable | Closure refs/digests, ordered member identities, C1 membership refs/digests, safe owner-row refs/digests/schemas, current head revisions/digests/states, stop ref/version/state, exact C2B decision/result/receipt, safe derived enum/reason values, latch postimage, terminal outcome, reconciliation/mismatch projections, timestamps and graph digests | implementation detail |
| Ref/digest only | WorkSpec, candidate capsule manifest and portable digest, private artifact, model proposal source invocation, source evidence, external authority evidence, source receipts, route/profile identities, private custody artifacts | current owning contract |
| Transient operation-only | Full WorkSpec, capsule entries, before/after blob sets, private artifact content, Wire frames and exact classifier operands, path tuples, private verifier inputs, bounded source manifests | implementation detail |
| Never in Coordinator SQLite | Raw prompts/responses/reasoning, provider JSONL, stdout/stderr, credentials, bearer material, endpoints, account/org/session IDs, absolute paths, workspace roots, physical store paths, retrieval tokens, trust roots, blob bytes, repository content, patches/diffs, arbitrary environment or metadata | current owning contract |

- **[current owning contract]** A valid digest is not permission.
- **[implementation detail]** C2 persistence proves only that the guarded Coordinator writer committed a validated safe representation under the recorded inputs.
- **[implementation detail]** It does not prove external source authenticity, physical custody, process execution, signal delivery, teardown, live host qualification, or ES runtime truth.
- **[implementation detail]** C2 adds no executable authority and cannot self-authorize or mint standing authority.

## 14. Assurance plan

- **[current merged implementation]** Direct C1 test sources were inspected. They cover K8 identity, exact relation inventories, zero-or-nine Section 41 reading, receipt/commit witnesses, `commit_outcome_unknown`, and `committed_exact` / `definitely_not_committed` / `unresolved` recovery behavior.
- **[current merged implementation]** Those tests were not executed.

Permanent C2 tests must cover:

- **[implementation detail]** Migration catalog, exact old hashes, cumulative manifest, zero/one-row seeding, STRICT declarations, foreign keys, guards, indexes, and both 0004→0005 and 0005→0006 paths.
- **[implementation detail]** Closed-world typed values, subclass rejection, digest reconstruction, privacy rejection, member ordering, duplicate/gap/overflow rejection, and immutable row adapters.
- **[implementation detail]** Every branch in the decision matrix, exact Section 41 recommendation mapping, zero/complete/incomplete family distinctions, and exact C2B variant/result mapping.
- **[implementation detail]** The latch CAS, only-accept rule, replay, collision, malformed state, and preservation through terminal uncertainty.
- **[implementation detail]** Separation of decision and terminal closure moments.
- **[implementation detail]** All three cancellation terminal branches and the prohibition on a second cancel/block decision.
- **[implementation detail]** Fault injection at every execute/fetch/write/receipt/commit/rollback/close/handoff boundary.
- **[implementation detail]** Three-way recovery proofs, including fragments, aliases, incorrect preimages, and cleanup uncertainty.
- **[implementation detail]** Public-surface and import-boundary tests proving no `StateStore`, package-root, worker, model, or external-I/O widening.

Independent audit must separately examine:

- **[implementation detail]** Literal schema and digest vectors without deriving expected values solely through production helpers.
- **[implementation detail]** Adversarial SQL fixtures that attempt partial families, latch repair/reset, member substitution, receipt aliasing, branch substitution, and outcome duplication.
- **[implementation detail]** Authority/privacy review of every durable column and every error projection.
- **[implementation detail]** Decision/terminal transaction ordering and recovery under real post-commit fault injection.
- **[implementation detail]** Clear defect classification: contract defect, implementation defect, test defect, or unavailable D/E integration evidence. Tests must not make their own contract self-protecting.

## 15. Forecasts and stop conditions

### Forecasts

- **[report-only uncertainty]** The likely implementation surface is two migration resources, approximately six private C2 source modules, two narrow integrations, and six to ten focused test modules.
- **[report-only uncertainty]** The most likely semantic defect is treating a C1 member or Section 41 evidence-set digest as completeness without binding the exact phase membership identities.
- **[report-only uncertainty]** The most likely transaction defect is recovering the decision row while omitting the latch, head postimage, nested development receipt, or outer closure binding.
- **[report-only uncertainty]** The most likely cancellation defect is using Wire `finite`, process exit, or database-row absence as semantic cancellation.
- **[report-only uncertainty]** The most likely migration conflict is attempting to reuse the obsolete planned migration-0003 decision-binding shape rather than adding a new migration after the actual Section 41 migration.

### Mandatory stop conditions

Stop the implementation-contract pass if it discovers any need to:

- **[implementation detail]** change an existing C2B decision kind, variant, or row field;
- **[implementation detail]** weaken Section 41’s zero-or-complete-nine rule;
- **[implementation detail]** infer physical absence from missing Coordinator rows;
- **[implementation detail]** consume the latch outside the accept-decision transaction;
- **[implementation detail]** permit a terminal outcome to create or rewrite a C2B decision;
- **[implementation detail]** persist raw private content or generic JSON metadata;
- **[implementation detail]** alter migrations 0001–0004;
- **[implementation detail]** add public writer/read APIs, worker/model invocation, external I/O, or ES authority;
- **[implementation detail]** claim live active-cancel reconciliation without the future D/ES source contract;
- **[implementation detail]** produce a result that cannot be resolved exactly after commit uncertainty.

Such a discovery requires explicit owner reconciliation rather than a workaround.

## 16. Touched surface forecast

No file was changed during this reconnaissance.

### Expected future changes after contract freeze

- **[implementation detail]** New authoritative C2 contract under `.docs/`.
- **[implementation detail]** New migration resources under `src/ge_nwp_coordinator/sqlite_migrations/` for 0005 and 0006.
- **[implementation detail]** `src/ge_nwp_coordinator/sqlite_migration.py` for the additive catalog and cumulative manifest.
- **[implementation detail]** New private C2 semantic-value, row-value, mutation-contract, reader-contract, reader, and atomic-persistence modules.
- **[implementation detail]** Narrow private integration in:

  - `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
  - `src/ge_nwp_coordinator/sqlite_writer_session.py`

- **[implementation detail]** New migration, semantic, reader, atomic-persistence, writer-delegation, fault, and recovery tests.
- **[implementation detail]** Status/cross-reference updates to the phase-entry, authority-boundary, durable-state, README, and AGENTS documentation.

### May change only if the freeze proves necessary

- **[implementation detail]** Existing private development readers/contracts may gain narrowly owned callers, but their frozen 24-query inventory should not be widened merely for convenience.
- **[implementation detail]** Section 41 and C1 reader modules may receive no semantic changes; C2 should add its own locators if the existing reader results are insufficient.

### Protected surface

- **[current owning contract]** Migrations 0001–0004 and their packaged bytes/hashes.
- **[current owning contract]** B1, B2 Wire/Capability, C2A, C1, C2B decision-row, and Section 41 value identities and grammars.
- **[current owning contract]** Public `StateStore`, public `WriterSession`, package-root exports, Bridge, Execution Substrate, and all supporting repositories.
- **[current owning contract]** Worker, model/provider, Git, publication, scheduler, service, adapter, supervisor, and live-host behavior.

## 17. Unresolved seams

- **[reopened target seam]** C2 must freeze exact schema IDs, field order, reason-code vocabulary, member ranks, graph domains, SQL names, and result/receipt projections. This is C2-owned detail, not an upstream-owner conflict.
- **[reopened target seam]** Repair versus replan versus terminal-reject policy reasons need a finite C2 mapping. Ambiguity must map to block.
- **[reopened target seam]** The external provisioner for a replan’s accepted-intent revision, work-item revision, WorkSpec safe binding, and successor attempt/candidate remains outside C2. C2 only verifies supplied owner rows.
- **[reopened target seam]** D/ES must later define the source-native process-group, descendant, request, signal, exit, teardown, custody, and receipt reconciliation projection used for live active cancellation.
- **[reopened target seam]** E must later supply authenticated live verifier and qualified-host evidence.
- **[reopened target seam]** Model invocation and private artifact custody remain external; C2 consumes only the already-admitted safe Section 41 family.
- **[strategic target]** These seams block live D/E assertions but do not block freezing or implementing C2 with exact fake/supplied observations.
- **[implementation detail]** No current seam requires changing C1, B1, B2, C2A, C2B, or Section 41 before the next C2 contract-freeze pass.

## 18. Next contract-freeze step

- **[implementation detail]** The next step is one authoritative RW0-C2 contract document covering both tranches and explicitly freezing:

  1. decision-closure values, members and branch profiles;
  2. exact embedded C2B commands/results/receipts;
  3. acceptance-latch preimage, CAS and postimage;
  4. terminal-closure and cancellation reconciliation/mismatch values;
  5. B1 terminal-outcome binding;
  6. migrations 0005 and 0006, including full schema/guard/index manifests;
  7. transaction order, replay and three-way recovery proofs;
  8. authority/privacy boundaries;
  9. permanent test and independent-audit matrices;
  10. a strict implementation file allowlist and protected surface.

- **[implementation detail]** That freeze should undergo independent contract audit before any implementation prompt is issued.
- **[implementation detail]** This report does not authorize or issue the RW0-C2 implementation prompt.

REPOSITORY_MUTATION_NOT_PERFORMED  
TESTS_NOT_RUN  
MIGRATIONS_NOT_RUN  
STAGING_NOT_PERFORMED  
COMMIT_NOT_PERFORMED  
PUSH_NOT_PERFORMED  
PR_NOT_CREATED  
REMOTE_CONTACT_NOT_PERFORMED  
WORKER_OR_MODEL_NOT_INVOKED  
SUPPORTING_REPOSITORIES_NOT_MODIFIED  
IMPLEMENTATION_NOT_PERFORMED  
RW0_C2_NOT_IMPLEMENTED  
RW0_D_NOT_IMPLEMENTED  
RW0_E_NOT_IMPLEMENTED  
EXECUTION_SUBSTRATE_NOT_MODIFIED  

RW0_C2_PHASE_LEVEL_ENGINEERING_DECISION_READY
