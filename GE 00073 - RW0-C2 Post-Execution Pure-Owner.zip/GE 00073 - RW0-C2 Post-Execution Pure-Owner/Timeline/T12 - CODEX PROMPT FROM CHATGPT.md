PROMPT_ID

C2B_PROGRESSION_DECISION_OWNER_FINAL_RECONCILIATION_V2

TITLE

Coordinator C2B — final reconciliation of the progression-decision owner
contract: correct profile identity, restore pre-contact block composition,
remove hidden RW0-C coupling, and close latch-eligibility ownership

ENGAGEMENT TYPE

Parent-only, local, read-only owner-contract reconciliation.

Do not delegate to subagents.

Do not edit, format, generate repository files, stage, commit, push, create a
branch or PR, merge, tag, release, deploy, fetch, contact a remote/live system,
install dependencies, execute tests, run migrations, open or mutate an operator
database, invoke a product worker/model, or inspect/modify supporting
repositories.

Do not issue an implementation prompt.

Print the complete substantive result inline. Evidence files may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

C2B_PROGRESSION_DECISION_FINAL_RECONCILIATION_BASELINE_MISMATCH

CURRENT REPORT BEING RECONCILED

The preceding Codex response is the current proposed owner freeze.

Expected attachment identity if supplied as `Pasted text.txt`:

size:
70128 bytes

SHA-256:
852d11d06b9f691009ac2ed9a21a6abfb40a48e059cb978f20b1772bcfa9e566

opening heading:
# Baseline and path-grounding correction

closing token:
C2B_PROGRESSION_DECISION_OWNER_FREEZE_RECONCILED_READY_FOR_INDEPENDENT_AUDIT

If an attachment is supplied, verify this identity. If the work occurs in the
same conversation, treat the immediately preceding response as the fixed
input.

WHY ANOTHER RECONCILIATION IS REQUIRED

The preceding response did not perform the requested independent audit. It
produced a new, more detailed contract revision. That revision closes many
earlier gaps, but it contains one deterministic identity contradiction and
material C2B/RW0-C boundary gaps.

Do not represent this pass as an audit or acceptance.

PRESERVED OWNER DECISIONS

Preserve unless the merged source proves a direct contradiction:

1. One private branch-parameterized C2B progression owner covers:
   - accept / candidate_acceptance;
   - repair / candidate_repair;
   - replan / attempt_selecting_replan;
   - terminal_reject / program_terminal_reject;
   - block / program_block;
   - cancel / effect_cancellation.

2. Version-advancing branches use an explicit first-slice single-work profile.

3. Cancel is non-version-advancing and membership-neutral.

4. C2B owns:
   - branch validity;
   - immutable progression rows;
   - program/work post-states;
   - revisions and edges;
   - exact head CAS;
   - C2B result and receipt;
   - replay and recovery.

5. RW0-C composes one bounded private C2B facade into one common transaction.
   C2B does not import RW0-C modules or rows.

6. There is one controller, connection, mutation slot, transaction timestamp,
   capability epoch, and commit attempt.

7. Migration 0005 and the physical one-way acceptance latch remain RW0-C-owned.

8. Migration 0002 and existing row/enum meanings remain byte- and
   semantics-exact.

9. RW0-C-Terminal and migration 0006 remain blocked on D/Execution Substrate
   terminal-evidence owners.

10. No implementation is authorized by this engagement.

FACT CLASSIFICATION

Label every substantive conclusion exactly as:

- current owning contract;
- current merged implementation;
- compatibility edge;
- reopened owner seam;
- proposed frozen C2B owner contract;
- implementation detail;
- report-only uncertainty.

State conflicts explicitly.

RECONCILIATION A — PROFILE IDENTITY IS MATHEMATICALLY INCONSISTENT

The preceding response states:

```text
schema_id:
governed-execution.nwp-development-progression-owner-profile.v1

digest domain:
governed-execution.nwp-development-progression-owner-profile.v1.identity

digest:
SHA-256(domain UTF-8 || NUL || canonical manifest bytes)

canonical manifest length:
7338

claimed profile digest:
8a8d67fb444c6d2a79f2a70f98f3dfa02baae0476b270396ea364e029100b4dc
```

Using the exact 7338-byte JSON printed in that response, compact sorted-key
UTF-8 canonicalization, and the stated domain-separated algorithm yields:

```text
9303a62e3a99d71745055faa11ba3d2611fb797982f9af6a749071dd44692f2d
```

not the claimed `8a8d67fb...`.

Required resolution:

1. Rebuild the final profile manifest only after every reconciliation below is
   complete.
2. Print the exact final single-line canonical JSON.
3. Print exact byte length.
4. Independently recompute with two implementations.
5. Print exact domain input construction.
6. Print the resulting digest.
7. Ensure every command, completed-receipt projection, replay proof, recovery
   selector, and downstream C attestation uses that exact final pair.
8. Do not preserve either current digest if the manifest changes.
9. Classify the prior cross-check claim as a report defect.

No profile identity may be declared frozen while its printed bytes and digest
disagree.

RECONCILIATION B — REMOVE HIDDEN RW0-C/C1 COUPLING FROM THE C2B OWNER COMMAND

The preceding C2B command includes:

- `phase_basis_ref/digest`;
- C1 rank-15 membership ref/digest;
- C1 wrapped Section 41 value ref/digest.

The report simultaneously claims:

- C2B is independently reusable by a governed composer;
- dependency direction is one-way, RW0-C -> C2B;
- C2B does not interpret RW0-C closure/evidence rows.

Those claims are not yet coherent.

Make and defend one exact design.

Preferred boundary:

1. The C2B owner command contains only:
   - C2B-owned basis rows and expected heads;
   - exact existing Section 41 owner-row identities or one neutral,
     Section-41-owned proposal-family projection;
   - branch-specific preassigned C2B identities;
   - global-stop inputs;
   - the C2B profile pair.

2. The outer RW0-C command/closure binds:
   - C1 phase identity;
   - C1 membership identity;
   - C1 rank-15 wrapper identity;
   - decision-time C1 membership snapshot;
   - C-local completeness and block evidence.

3. The outer RW0-C attestation proves that its C1 membership resolves to the
   exact Section 41 owner family supplied to C2B.

4. C2B may validate the Section 41 recommendation and owner-family graph
   without importing C1 types or depending on C1 membership identity.

Alternative:

Define one exact neutral composition-basis schema, owned outside C2B and RW0-C,
with:

- exact ordered fields;
- schema/ref/digest;
- source owner identities;
- branch authorization;
- no C-only truth;
- no C2B post-state choices;
- exact construction and verification responsibilities.

If retaining C1 phase or membership fields in the C2B command, prove why they
are generic owner-neutral facts rather than a hidden C dependency, and show how
the owner family remains independently useful outside RW0-C.

Update consistently:

- command schema and field order;
- command digest;
- profile manifest;
- write-plan inputs;
- completed-receipt projection;
- recovery selector;
- replay/readback;
- composition call seam.

Do not let C2B validate C1 membership semantics.

RECONCILIATION C — RESTORE PRE-CONTACT BLOCK WITHOUT REINTERPRETING C2B

The accepted RW0-C decision contract has two materially different block bases:

1. post-execution block;
2. pre-contact block based on explicit current negative/unknown gate evidence.

The preceding C2B freeze requires both rank-15 pairs and a complete
post-execution recommendation for every advancing branch. That makes
pre-contact `program_block` impossible.

Freeze an exact composition that supports both without changing the existing
decision row:

Preferred:

- two C2B profile branch IDs:
  - `post_execution_program_block`;
  - `pre_contact_program_block`;
- both map to:
  - `decision_kind = block`;
  - `decision_variant = program_block`;
  - identical C2B write graph and post-state;
- their owner-neutral authorization inputs differ:
  - post-execution binds exact Section 41 `block` owner family;
  - pre-contact binds one exact outer-C block-basis attestation digest/profile
    without C2B interpreting individual C1 evidence.

Alternative:

- one `program_block` branch with an exact versioned `basis_profile` union.

Requirements:

- pre-contact block does not fabricate Section 41 rows;
- block decision persistent selected fields remain null, as required by the
  existing row grammar;
- C2B does not infer a target work item beyond the sole-member profile;
- missing C1 evidence alone remains “no decision,” not block;
- outer C retains ownership of finite block-reason evidence;
- C2B owns only the program/work blocked transition once a valid block
  authorization basis is supplied.

Update profile manifest, command optionality, plan variant, receipt projection,
replay, and recovery selector.

RECONCILIATION D — FREEZE PRODUCTIVE DIRECT-LOCAL LATCH ELIGIBILITY OWNERSHIP

The preceding completed-receipt projection contains:

```text
fresh_productive_direct_local_accept_latch_eligible
```

and claims it is true only when:

```text
verified productive output
adapter_kind = direct_local_bootstrap
```

But the printed 54-field C2B command, rank-15 wrapper, and C2B-owned rows do not
contain an exact productive-output or adapter-route proof. The pure evaluator
also accepts an undefined `basis`.

Make one explicit owner decision.

Option 1 — outer RW0-C owns composite latch eligibility (preferred unless a
current C2B owner proves otherwise):

- C2B completed receipt records only the accepted progression branch/result;
- C2B does not carry a direct-local/productive latch Boolean;
- outer RW0-C computes latch eligibility from:
  - exact C2B accept result;
  - exact decision closure;
  - exact route and productive-output attestations;
- migration 0005/C owns physical latch CAS;
- C2B owns no route semantics.

Option 2 — C2B owns a neutral eligibility assertion:

- define an exact neutral input schema and field order;
- include exact route kind, productive-result identity, source owner, and
  digest;
- bind it in command/profile/receipt/recovery;
- prove C2B can verify it without importing C1/RW0-C or interpreting physical
  runtime truth;
- define replay and recovery behavior.

Do not infer route or productivity from rank-15 family count, recommendation,
or graph digest.

Whichever option is chosen, update:

- owner boundary;
- profile manifest;
- command and basis grammar;
- completed receipt;
- latch composition seam;
- assurance matrix.

RECONCILIATION E — SINGLE-WORK PROFILE QUERY

The preceding profile query uses `LIMIT 257` and classifies:

- 2..256 rows as valid-but-unsupported profile conflict;
- 257 rows as database-integrity failure.

For a profile that needs only to distinguish zero, exactly one, and more than
one, the default should be:

```sql
ORDER BY membership_ordinal, work_item_ref
LIMIT 2
```

with:

- zero -> database-integrity failure if nonempty membership is an owner
  invariant;
- one coherent ordinal-zero row -> eligible;
- second row -> `program_membership_profile_conflict`.

Use `LIMIT 257` only if a current owning contract establishes a hard maximum of
256 members and explains why 257 rows are corrupt rather than merely
unsupported.

Do not conflate a bounded reader implementation limit with a schema invariant.

Freeze:

- query ID;
- exact SQL;
- fetch count;
- result classification;
- whether the existing 24-query inventory changes;
- profile manifest fields.

RECONCILIATION F — BRANCH PRE-STATE MATRIX

The preceding report chooses:

```text
accept, repair, replan, terminal reject, block:
program active
work planned or repair_required
```

and excludes `active`.

Ground each branch separately in current owner semantics and intended first-
slice progression.

For every branch explain:

- why each allowed state is valid;
- why each excluded nonterminal state is invalid;
- exact evidence/selection prerequisites;
- whether repair from planned is meaningful;
- whether accept from repair_required is meaningful;
- whether replan from repair_required is meaningful;
- whether terminal reject/block may apply to active work;
- interaction with later author-effect establishment;
- no silent reinterpretation of existing state vocabularies.

If current owners do not settle the matrix, classify it as a proposed
versioned profile decision and include it in the profile manifest and tests.

Cancel remains governed by exact target-effect state rather than the
single-work state profile.

RECONCILIATION G — EXACT OWNER-NEUTRAL BASIS VALUE

The evaluator currently has the abstract signature:

```text
_evaluate_development_progression_decision(*, command, basis, decided_at)
```

Freeze the exact `basis` value.

It must specify:

- schema ID;
- ordered fields;
- immutable/final posture;
- owner of each field;
- whether fields are read inside the active transaction or supplied by the
  outer composer;
- exact validation;
- no C1-specific types if C2B is independent;
- no caller-selected post-state;
- exact branch authorization;
- exact relationship to command digest;
- exact relationship to replay and recovery;
- privacy/non-authority posture.

If basis differs by branch, freeze a closed tagged union.

Do not leave `basis` as an implementation placeholder.

RECONCILIATION H — COMMAND, PLAN, RECEIPT, AND RECOVERY CONSISTENCY

After A–G, reissue complete exact definitions:

- final profile manifest and digest;
- branch IDs and mapping to existing decision kind/variant;
- command schema and ordered fields;
- optionality matrix;
- neutral basis schema;
- write plan schema/fields;
- CAS schemas;
- graph order;
- progression result;
- completed receipt projection;
- recovery selector;
- conflict vocabulary;
- committed_exact / definitely_not_committed / unresolved proofs;
- composition seam with outer RW0-C.

Verify no stale field remains from the superseded contract.

PRESERVE THE FOLLOWING UNLESS RECONCILIATION REQUIRES A DIRECT CHANGE

- existing migration-0002 row grammar and enums;
- same-work replan;
- repair WorkSpec rebinding;
- work-before-program CAS;
- no CAS on cancel;
- receipt-first replay;
- active-stop matrix;
- one timestamp;
- one common transaction and commit;
- no standalone C2B commit path;
- migration 0005 remains RW0-C-owned;
- terminal owner blocker remains;
- no public/API widening;
- no external I/O.

ASSURANCE REQUIREMENTS

Permanent future tests must causally protect:

- exact final profile bytes/digest;
- owner-neutral command/basis boundary;
- pre-contact versus post-execution block profiles;
- latch eligibility ownership;
- single-work zero/one/two behavior;
- branch basis-state matrix;
- exact positive write graphs;
- forbidden writes;
- CAS order and rowcount;
- result/graph/receipt;
- replay and all recovery outcomes;
- no C/RW0 semantic import into C2B;
- no public/transaction-authority widening.

Independent audit later owns:

- literal digest recomputation;
- cross-owner substitution mutants;
- pre-contact/post-execution branch swaps;
- route/productivity eligibility mutants;
- FK/write-order verification;
- fault injection;
- clean/live validation.

Do not introduce self-protecting tests.

RETURN FORMAT

# Baseline and fixed-input identity
# Classification of the prior non-audit response
# Preserved owner decisions
# Corrected owner-profile identity
# Owner-neutral command and composition basis
# Pre-contact and post-execution block profiles
# Latch-eligibility ownership
# Single-work query contract
# Branch pre-state matrix
# Exact branch write matrix
# Command and basis grammars
# Write-plan, CAS, graph, result, and receipt
# Replay and recovery
# Composition seam with RW0-C
# Assurance architecture
# Provisional implementation surface
# Remaining seams and stop conditions
# Recommended next step
# Confidence

SUCCESS TOKEN

Return exactly:

C2B_PROGRESSION_DECISION_OWNER_FINAL_RECONCILIATION_READY_FOR_INDEPENDENT_AUDIT

only if:

- the printed final profile bytes and digest agree;
- C2B is no longer semantically coupled to C1/RW0-C;
- both block bases are representable;
- latch eligibility has an exact owner;
- single-work and state matrices are exact;
- command/basis/plan/receipt/recovery contracts are complete;
- no implementation prompt is issued.

Otherwise return:

C2B_PROGRESSION_DECISION_OWNER_RECONCILIATION_BLOCKED

and identify the precise unresolved owner decision.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
