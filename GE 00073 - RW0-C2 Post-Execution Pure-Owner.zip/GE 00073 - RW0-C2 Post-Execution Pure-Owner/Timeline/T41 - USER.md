Here is Codex's response:

# Baseline and fixed input

| Classification | Result |
|---|---|
| current merged implementation | Branch `trunk_dev`; HEAD `a3ff0b7f4f0c2378c2962e24612d605489b51638`; tree `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0`; sole parent `047563de5a443b0f8323401c92979ae2e444d2ed`; subject `feat: implement RW0-C1 durable evidence (#7)`. |
| current merged implementation | Upstream is `origin/trunk_dev`; ahead/behind is `0/0`; exactly one worktree exists; worktree, index, untracked, and unmerged state are clean. |
| implementation-detail observation | Baseline verification was local and read-only. No fetch or remote contact occurred. |
| implementation-detail observation | The immediately preceding Codex response was recovered as the fixed input: 81,049 bytes, SHA-256 `d30f6182ff9312bb66f2e8e6914fba08f5d8106e6bb0d69493338cf25ff5a2d6`, 1,232 logical lines, no final newline, opening `# Baseline and fixed audit input`, and closing success token `RW0_POST_EXECUTION_CONTEXT_RESUPPLY_SNAPSHOT_RECOVERY_OWNERS_READY_FOR_INDEPENDENT_AUDIT`. |
| current owning contract | `.docs/` was treated as authoritative. The primary anchors remain [RW0-C1 durable evidence](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c1-durable-evidence.md>), [durable development state and Section 41](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md>), and [migration 0003](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0003_cognitive_proposal_and_selection_state.sql>). |

# Preserved decisions

| Classification | Preserved decision |
|---|---|
| current owning contract | C1 retains exactly 15 kinds and owns evidence presence, typed membership, relation receipts, replay, and recovery. It does not own decision completeness. |
| proposed post-execution evidence owner contract | All nine proposal-time owner values exist before model invocation. |
| proposed post-execution evidence owner contract | The model consumes one exact T1 input contract; the same nine typed semantic identities later appear in Section 41. |
| proposed Section 41 role-resolution contract | Section 41 owns structural proposal-family coherence and recommendation. Recommendation is not branch authority. |
| proposed post-execution evidence owner contract | Missing exact transient resupply before an uncommitted decision is `no_decision`; malformed, contradictory, or substituted supply is `basis_conflict`. |
| proposed post-execution evidence owner contract | The complete candidate manifest remains transient/private. |
| proposed future committed-recovery contract | Committed recovery retains only the candidate safe projection and derived safe results, never the complete candidate manifest. |
| proposed Section 41 role-resolution contract | The durable evidence-row locator remains `(proposal_ref, evidence_role, ordinal)` and role resolution is recomputable from exact resupply. |
| proposed post-execution evidence owner contract | The frozen validation, review, policy, risk, stop, and source-effect ceiling algebras remain unchanged except for mechanical context/profile rebinding. |
| proposed RW0-C decision-input contract | RW0-C owns exhaustive decision-time membership closure and a bounded current snapshot without granting C1 completeness authority. |
| current owning contract | Existing B1/B2/C1/C2A meanings, migrations 0001–0004, migration-0002 decisions, Section 41 durable row meanings, public APIs, and the single transaction controller remain unchanged. |
| report-only uncertainty | Aggregate branch truth, neutral C2B basis, migration 0005, a physical decision latch, terminal/D/E behavior, ES behavior, and effect cancellation remain outside scope. |
| current owning contract | No implementation is authorized by this report. |

# Context-identity collision

[implementation-detail observation] The fixed input assigned two incompatible shapes to `governed-execution.nwp-post-execution-semantic-review-context.v1`: the earlier L34-only Section 41 context and the later T1 model-input context. Their field sets, reference preimages, and digest preimages are materially different, so retaining one schema/version for both would make canonical reconstruction ambiguous.

[proposed post-execution evidence owner contract] The collision is resolved using the preferred two-value architecture:

| Classification | Value | Final schema |
|---|---|---|
| proposed Section 41 role-resolution contract | `Section41PostExecutionSemanticReviewLineageContextV1` | `governed-execution.nwp-section41-post-execution-semantic-review-lineage-context.v1` |
| proposed post-execution evidence owner contract | `PostExecutionSemanticReviewInputContextV1` | `governed-execution.nwp-post-execution-semantic-review-context.v1` |

[proposed post-execution evidence owner contract] The migration-compatible generic schema is now exclusive to the T1 input context. It no longer denotes the L34-only value.

[proposed Section 41 role-resolution contract] The lineage value has a distinct schema, class name, prefix, reference domain, and digest domain. No incompatible context shape shares a schema/version, reference domain, or digest domain.

# Final context decomposition

[proposed Section 41 role-resolution contract] `Section41PostExecutionSemanticReviewLineageContextV1` has this exact ordered mapping:

```text
schema_id
lineage_context_ref
proposal_phase
program_ref
program_version_ref
program_version_number
accepted_intent_revision_ref
work_item_ref
work_item_revision_ref
semantic_attempt_ref
semantic_attempt_digest
attempt_number
candidate_ref
basis_decision_ref
basis_decision_digest
work_spec_ref
work_spec_digest
work_spec_safe_projection_digest
effect_intent_ref
effect_intent_digest
author_command_ref
author_command_digest
standing_grant_ref
standing_grant_digest
attempt_authorization_ref
attempt_authorization_digest
effect_authorization_ref
effect_authorization_digest
attempt_fence_ref
attempt_fence_digest
effect_fence_ref
effect_fence_digest
delivery_attempt_ref
delivery_envelope_digest
delivery_attempt_digest
authority_evaluation_ref
authority_evaluation_digest
lineage_context_digest
```

[proposed Section 41 role-resolution contract] Its identity grammar is:

```text
schema:
governed-execution.nwp-section41-post-execution-semantic-review-lineage-context.v1

reference prefix:
section41-post-lineage.

reference domain:
governed-execution.nwp-section41-post-execution-semantic-review-lineage-context-reference.v1.identity

reference preimage:
proposal_phase + exact L34 fields
(excludes schema_id, lineage_context_ref, lineage_context_digest)

digest domain:
governed-execution.nwp-section41-post-execution-semantic-review-lineage-context.v1.identity

digest preimage:
complete mapping including schema_id and generated lineage_context_ref,
excluding only lineage_context_digest
```

[proposed post-execution evidence owner contract] `PostExecutionSemanticReviewInputContextV1` has this exact ordered mapping:

```text
schema_id
input_context_ref
profile_ref
profile_digest
proposal_phase
lineage_context_schema_id
lineage_context_ref
lineage_context_digest
phase_basis_ref
phase_basis_digest
preassigned_proposal_ref
role_entry_count
role_entries
model_input_safe_projection_schema_id
model_input_safe_projection_ref
model_input_safe_projection_digest
private_input_manifest_schema_id
private_input_manifest_ref
private_input_manifest_digest
constructed_at
input_context_digest
```

[proposed post-execution evidence owner contract] Its identity grammar is:

```text
schema:
governed-execution.nwp-post-execution-semantic-review-context.v1

reference prefix:
post-semantic-input-context.

reference domain:
governed-execution.nwp-post-execution-semantic-review-input-context-reference.v1.identity

reference preimage, in field order:
profile_ref, profile_digest, proposal_phase,
lineage_context_schema_id, lineage_context_ref, lineage_context_digest,
phase_basis_ref, phase_basis_digest, preassigned_proposal_ref,
role_entry_count, role_entries,
model_input_safe_projection_schema_id,
model_input_safe_projection_ref,
model_input_safe_projection_digest,
private_input_manifest_schema_id,
private_input_manifest_ref,
private_input_manifest_digest,
constructed_at

digest domain:
governed-execution.nwp-post-execution-semantic-review-context.v1.identity

digest preimage:
complete mapping including schema_id and generated input_context_ref,
excluding only input_context_digest
```

[proposed post-execution evidence owner contract] `role_entry_count` is exactly 9. Each entry uses schema `governed-execution.nwp-post-execution-semantic-review-role-entry.v2`, is parent-only, has no independent ref or self-digest, and has these fields:

```text
schema_id
role
role_rank
ordinal
typed_schema_id
typed_value_ref
typed_value_digest
source_posture
direct_c1_kind
direct_c1_kind_rank
direct_c1_membership_ref
direct_c1_membership_digest
source_profile_ref
source_profile_digest
source_binding_schema_id
source_binding_ref
source_binding_digest
model_input_posture
```

[proposed post-execution evidence owner contract] Exact role/nullability grammar is:

| Classification | Role/rank | Typed schema | Direct C1 group | Source profile/binding group | Model posture |
|---|---|---|---|---|---|
| proposed post-execution evidence owner contract | `candidate_capsule` / 5 | `governed-execution.nwp-candidate-capsule-manifest.v1` | all null | all null | `private_exact_canonical_value` |
| proposed post-execution evidence owner contract | `worker_result` / 6 | `governed-execution.nwp-rw0-c1-wire-process-result-classification-binding.v1` | kind `wire_process_result_classification_binding`, rank 14, membership pair non-null | wire profile pair and classification-relation triple non-null | `nonprivate_exact_canonical_value` |
| proposed post-execution evidence owner contract | `validation_result` / 7 | `governed-execution.nwp-validation-disposition.v1` | all null | disposition profile pair and source-observation triple non-null | `nonprivate_exact_canonical_value` |
| proposed post-execution evidence owner contract | `independent_review` / 8 | `governed-execution.nwp-independent-review-disposition.v1` | all null | disposition profile pair and source-observation triple non-null | `nonprivate_exact_canonical_value` |
| proposed post-execution evidence owner contract | `standing_policy` / 9 | `governed-execution.nwp-post-execution-standing-policy-branch-matrix.v1` | all null | policy profile pair and policy-source triple non-null | `nonprivate_exact_canonical_value` |
| proposed post-execution evidence owner contract | `risk_lane` / 10 | `governed-execution.nwp-post-execution-risk-lane-branch-matrix.v1` | all null | risk-source profile pair and source-binding triple non-null | `nonprivate_exact_canonical_value` |
| proposed post-execution evidence owner contract | `authority_currentness_attestation` / 11 | `governed-execution.nwp-rw0-authority-verification-observation.v1` | kind `authority_verification_observation`, rank 1, membership pair non-null | all null | `nonprivate_exact_canonical_value` |
| proposed post-execution evidence owner contract | `global_stop` / 12 | `governed-execution.nwp-post-execution-global-stop-snapshot.v1` | all null | stop profile pair and global-stop-state triple non-null | `nonprivate_exact_canonical_value` |
| proposed post-execution evidence owner contract | `effect_ceiling` / 13 | `governed-execution.nwp-post-execution-source-effect-ceiling-evidence.v1` | all null | ceiling profile pair and effect-fence triple non-null | `nonprivate_exact_canonical_value` |

[current owning contract] Rank-15 Section 41 membership does not exist at T1 because its value includes the later proposal family. T1 therefore contains direct C1 provenance only for rank 14 and rank 1.

[proposed post-execution evidence owner contract] Pure chronology is:

```text
T0 owner and support values complete
T1 lineage context, model-input projection, private manifest,
   nine role entries, T1 input context, and transient supply complete
T2 model invocation consumes exactly that T1 package
T3 source invocation completes and the artifact binding validates
T4 nine evidence-row values and the evidence-set identity are constructed
T5 the proposal value is constructed from T3 and T4
```

# Migration-0003 binding

[current merged implementation] Migration 0003 stores only opaque `context_schema_id`, `context_ref`, and `context_digest` fields on `development_model_source_invocations` and `development_model_proposals`.

[current merged implementation] Its phase algebra already admits exactly `governed-execution.nwp-post-execution-semantic-review-context.v1` for `post_execution_semantic_review`. The selected T1 value therefore occupies the existing seam without any SQL-byte change.

[proposed post-execution evidence owner contract] Source invocation and proposal rows repeat:

```text
context_schema_id = T1.schema_id
context_ref       = T1.input_context_ref
context_digest    = T1.input_context_digest
```

[proposed Section 41 role-resolution contract] The L34 lineage context remains a nested pure operand of T1 and the Section 41 projection. It is not a new durable row and does not require a migration.

[current merged implementation] Evidence children retain the immediate foreign key to the proposal parent. Durable write order remains:

```text
development_model_source_invocations
development_private_proposal_artifact_bindings
development_model_proposals
development_model_proposal_evidence_bindings, nine rows
existing selection/disposition rows when applicable
```

[proposed post-execution evidence owner contract] Pure construction of the nine child-row values before proposal insertion does not violate the foreign key; only physical insertion remains parent-first.

[proposed post-execution evidence owner contract] Frozen cross-row equalities are:

1. Source and proposal repeat the exact T1 schema/ref/digest.
2. T1 repeats the exact lineage schema/ref/digest.
3. T1, model-input projection, private manifest, and supply repeat one profile pair, proposal phase, and lineage triple.
4. T1 role entries and Section 41 evidence rows have identical role/rank/ordinal and typed ref/digest identities.
5. The model-input projection uses the typed identity for eight roles and the named candidate safe projection for the private candidate role.
6. The private manifest and candidate role supply bind the complete candidate-manifest identity.
7. The proposal repeats the source invocation, model-contract, model-configuration, artifact, context, and evidence-set identities.
8. The reconstructed evidence-set digest equals the proposal’s evidence-set digest.
9. All nine durable evidence rows have one common `evidence_bound_at`.

# Section 41 projection/version reconciliation

[proposed Section 41 role-resolution contract] Context semantics are not byte-compatible with the earlier projection contract. The final projection is `Section41PostExecutionProposalFamilyProjectionV2` with schema `governed-execution.nwp-section41-post-execution-proposal-family-projection.v2`.

[proposed Section 41 role-resolution contract] Its exact ordered fields are:

```text
schema_id
projection_ref
profile_ref
profile_digest
proposal_phase
source_invocation_ref
source_invocation_digest
artifact_ref
artifact_digest
artifact_binding_digest
proposal_ref
proposal_digest
model_contract_ref
model_contract_digest
model_configuration_ref
model_configuration_digest
input_context_schema_id
input_context_ref
input_context_digest
lineage_context_schema_id
lineage_context_ref
lineage_context_digest
safe_projection_schema_id
safe_projection_digest
evidence_set_ref
evidence_set_digest
evidence_binding_count
evidence_bindings
owner_family_graph_digest
recommendation
reason_code
source_invocation_started_at
source_invocation_completed_at
artifact_validated_at
evidence_bound_at
proposal_created_at
projection_evaluated_at
projection_digest
```

[proposed Section 41 role-resolution contract] Its reference identity is:

```text
prefix:
section41-post-projection-v2.

domain:
governed-execution.nwp-section41-post-execution-proposal-family-projection-reference.v2.identity

preimage:
profile_ref
profile_digest
proposal_ref
proposal_digest
input_context_schema_id
input_context_ref
input_context_digest
lineage_context_schema_id
lineage_context_ref
lineage_context_digest
evidence_set_ref
evidence_set_digest
owner_family_graph_digest
```

[proposed Section 41 role-resolution contract] Its digest domain is `governed-execution.nwp-section41-post-execution-proposal-family-projection.v2.identity`; the digest preimage is the complete mapping including `projection_ref` and excluding only `projection_digest`.

[proposed Section 41 role-resolution contract] Each evidence entry uses schema `governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2` and fields:

```text
schema_id
proposal_ref
proposal_phase
evidence_set_ref
evidence_role
role_rank
ordinal
evidence_ref
evidence_digest
required_for_selection
evidence_bound_at
source_binding_schema_id
source_binding_digest
projection_evidence_entry_digest
```

[proposed Section 41 role-resolution contract] A projection entry has no ref but has an independent self-digest under `governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2.identity`, excluding only `projection_evidence_entry_digest`.

[proposed Section 41 role-resolution contract] A successful nine-row projection orders entries by `(role_rank, ordinal, evidence_role)`. A zero-row projection uses an empty entry tuple, count 0, null `evidence_bound_at`, and the three-row owner graph. Counts 1–8 or greater than 9 are `basis_conflict`.

[proposed Section 41 role-resolution contract] Chronology is:

```text
input_context.constructed_at <= source_invocation_started_at
source_invocation_started_at <= source_invocation_completed_at
source_invocation_completed_at <= artifact_validated_at
artifact_validated_at <= evidence_bound_at, for the nine-row form
evidence_bound_at <= proposal_created_at, for the nine-row form
projection_evaluated_at = proposal_created_at
```

[implementation-detail observation] Regenerated current identities are:

| Value | Canonical bytes | Raw SHA-256 | Domain-separated identity |
|---|---:|---|---|
| lineage context | 2,597 | `d9f3228ce29cb380d2dac996c60e2bb82cfe8d74c0573f37d02b759a330ce28d` | `5dcf26f21b26e2dbca640ee52c2a7b9502a6e8cd5caa39266ec3ff6372ccb5e6` |
| candidate safe projection | 1,439 | `443584b0f77f641db2ebf99db6a5677d03e3c450d331f5f2b03f7f67978df02e` | `9a5aee7c7fea034b1575ed4f0d245c310e7c98694f2d7a0cdee5ae78ae2cbb0a` |
| model-input safe projection | 6,674 | `f7cfc27328aa1f2d1a6e562840fcb4880efc1cbb953a9c85721fec0155c5cab2` | `f305c80d4bf862e14ea3746bd33d0421df812235c7a8e3eec95e91aecc52fda6` |
| private-input manifest | 1,253 | `cce9b2166d4bde6205f839988ca640238ca629f1412a3ca703eb792a3d7ceb32` | `1db620d4ce5383a849197ae9bf0c3c0886bd2b6758fb67ee63eb6fec4b2d6f55` |
| T1 input context | 10,070 | `b80b9662d12dd2495e6b24a6efd27e2b652dfeb5867e187cacf79eddf1e1c9d5` | `8d2cd3aa43ea55bfc2fe910cbea9eaff23994a713285340da0d852f4d340a7cc` |
| source invocation | 1,224 | `dcfef8f1561d8bb41724dcd15d98ec4b82eed1acf872e2bf12d8a13ffcb70cd5` | `a147683ac73637d708ad9b5907ef880a9b265e993381b5fe5e79ce9fe4b7d7ce` |
| artifact binding | 776 | `d2cd2457e054052a944fac0247c9cd4d39c1c4b99ece9293991c1865d124a1c4` | `b4f3d836f3518d93bf5a7c715870f6eec874faf3469a2ae1cbf0e2f71c958d8b` |
| evidence set | 2,839 | `41bdb2ff0357c03305135b77f358bf884241bc89a963de6b91b804ecfb1afe15` | `59753e8360b4085c651f73745ce2267b9816c11269d2fd6e67fae1f317982d7a` |
| proposal | 1,633 | `f0ad00780e2c458ea84f49a677791ee69aef99537783732ab3f0f7680b7ef875` | `d878c87b39f56f08438585c77bf98354f96630765ac345789356136e841b8b01` |
| owner-family graph | 3,190 | `782b18a74348de412879d9a22805633e93dc2114c769348f5634e19226071d41` | `f51f641cdcab3bee9122f4d767ce572f9e189983712cca4f8811aba5c16fe736` |
| Section 41 projection V2 | 9,769 | `b38e648cbf02dac61f590e81ec6b4f6ef98b72d9ce44471d5af77e40a0350b72` | `5c9631e31fb55950cb208664534ef7a807b76059d4b8c88d254a5b7fd5c35f9c` |

# Superseded identity ledger

| Classification | Superseded identity | Status and replacement |
|---|---|---|
| implementation-detail observation | L34-only `Section41PostExecutionSemanticReviewContextV1` under generic schema; ref `section41-post-context.341a5f56eed8fe9cc32118c780479469f7c9374ee50e87b2c43e776571e7dad1`; digest `5b9d2cc52de34e86159a88dd0d3aeba98122781649effe994e7c1821df53e89f`; 2,563 bytes | Invalid under the current contract. Replaced by the lineage-specific schema/ref/digest. |
| implementation-detail observation | Generic old reference prefix/domain `section41-post-context.` / `governed-execution.nwp-post-execution-semantic-review-context-reference.v1.identity` for the L34 shape | Withdrawn. The generic schema is exclusive to T1; lineage uses `section41-post-lineage.` and its lineage-specific domain. |
| implementation-detail observation | `section41-post-execution-proposal-family-projection-v1`; profile digest `141689f43443f1f5b0e460d14b50eca5e7ef15de8969f38825c396bd99f6a7ac`; raw SHA `24c018d37c836015fc4c0c5473994a092bd87294ed5224a74effa1368358262e`; 21,725 bytes | Replaced by projection profile V2, digest `c40867c7bf2519eb0f50f4cb21056b4b8b0aca6fb88162c03deb46e77f246cb0`. |
| implementation-detail observation | Projection ref `section41-post-projection.1870a51ca0adc4b9a4088670fd59022073b018ed979ec047d29f7f7acfcd342f`; digest `8bfc2a2ae63e8bac405b484335de0bf5343114feed160d382e5fe8aebfe260de` | Replaced by V2 ref `section41-post-projection-v2.8afc2aa3ade73a60388f296523ae4f30cc65d3693dec2a9ab383dc34d5b42cb4` and digest `5c9631e31fb55950cb208664534ef7a807b76059d4b8c88d254a5b7fd5c35f9c`. |
| implementation-detail observation | Old source invocation digest `27864765362ac41c00e38a1b056c6b2c50c7079a813754a9cf74aaf7614700fa` | Replaced by `a147683ac73637d708ad9b5907ef880a9b265e993381b5fe5e79ce9fe4b7d7ce`. |
| implementation-detail observation | Old proposal digest `7c88518b5398ae99872b3856a42a29c0794242375e20b38fe1f4d15f997fb57e` | Replaced by `d878c87b39f56f08438585c77bf98354f96630765ac345789356136e841b8b01`. |
| implementation-detail observation | Old owner-family graph digest `4f2d6370f6a0c39c89c6be7930eb7effa88d09be9283c097183f74281aed5d5a` | Replaced by `f51f641cdcab3bee9122f4d767ce572f9e189983712cca4f8811aba5c16fe736`. |
| implementation-detail observation | Earlier speculative rank-15 value digest `ec4548be22b8d39a51f30fff5160610ebf19b060da7d6f203e155f88e4989ce8` and membership digest `5589e68218a51ac5b413877b6f633b45e1c02b529d753103315e522d4f0379d4` | Withdrawn. They bind stale proposal/context data and cannot appear in a current vector. No replacement membership is fabricated at T1. |
| implementation-detail observation | `rw0-c-post-execution-authorization-v1` profile: 7,036 bytes; raw SHA `99c7355d255f41425a16f97f2678f2ab7bdb9882cb2b5f20a33610ef817df87a`; digest `4f5aefd0fdfb500495f3f76b42b3ec7251af741156eb5ccaeb8bcdd667f846fb` | Withdrawn because the aggregate branch evaluator is outside scope. |
| implementation-detail observation | Attestation ref `rw0-c-postexec-attestation.12d21a9d6e678db090cca3801bd938630c60bf24375f9a3a82ea9e030e9155d1`; digest `60edab80a699e64998367756939669f577d21d820f9fe77546a5e08bf8c3ac3c` | Withdrawn with the stale authorization profile; no current replacement is asserted. |
| implementation-detail observation | `development-progression-authorization-basis-v1` profile: 4,469 bytes; raw SHA `42b801db924035a890e42d4c7fcabc8b228f73cfe45be92dbfa52f6554e176e8`; digest `e191d01d6e2d804c3d0fc9dcc34c4dc5e0f8c880705ebb6c3b2dcf41968461d9`; old golden basis digest `d2c919b85f2504409f1dc02059ecb7ad8eca78c3cd5cfc6d84c736b93c8c2fbb` | Withdrawn pending a separately frozen aggregate branch evaluator and neutral C2B basis. |
| implementation-detail observation | `post-execution-semantic-review-input.v1`: 4,638 bytes; raw SHA `c168839636a26d0767d3058b97e6a1b6462d1c8b0cad4b326ee2106cbbad427d`; digest `b887c04539c16ac344f116da5483a9cdfd9e47e23a7b3877ec4c5fd8b9f953b3` | Replaced by input profile V2. |
| implementation-detail observation | `section41-post-execution-role-resolution.v2`: 3,344 bytes; raw SHA `5ce21d904a06392958b32fb45b09e3c28eb69491e125409d5f355ac45266f0d3`; digest `4dd51e79388423e0befdaba2b665dc1c3eb1cd9845a01a84e2eae8cd4219c9e3` | Replaced by role-resolution profile V3. |
| implementation-detail observation | Unversioned/superseded `post-semantic-context.` generated-ref grammar | No valid current golden exists; replaced by the explicit T1 input-context reference grammar. |
| implementation-detail observation | `PostExecutionSemanticReviewRoleEntryV1`, `PostExecutionModelInputSafeProjectionV1`, `PostExecutionModelInputProjectionEntryV1`, `PostExecutionPrivateInputManifestV1`, `PostExecutionPrivateInputManifestEntryV1`, `PostExecutionEvidenceSupplyV1`, `PostExecutionRoleSupplyV1`, and `PostExecutionModelInputBindingV1` | Replaced by the literal V2 schemas below. No earlier incomplete V1 nested identity is current. |

# Complete value-schema registry

[proposed post-execution evidence owner contract] Canonical mapping type notation is:

```text
SID  = exact built-in str equal to the listed literal schema
R    = exact built-in str; 1–96 ASCII chars; first char alphanumeric;
       remaining chars [0-9A-Za-z.-]; reserved private prefixes rejected
H    = exact built-in str of 64 lowercase hexadecimal characters
T    = exact built-in str, valid whole-second UTC YYYY-MM-DDThh:mm:ssZ
N0   = exact built-in int, never bool, in 0..2^63-1
N1   = exact built-in int, never bool, in 1..2^63-1
B    = exact built-in bool
E{x} = exact built-in str in the displayed closed vocabulary
O[X] = exact built-in dict containing X's complete closed canonical mapping
A[n,X] = exact built-in list of exactly n X mappings in canonical JSON;
         private immutable implementations use exact tuple internally
?    = exact null or the named exact built-in type
```

[proposed post-execution evidence owner contract] All schemas reject unknown, missing, duplicate, subclassed, or extension fields before canonicalization. JSON uses sorted keys, compact separators, UTF-8, no BOM/newline, `allow_nan=false`, and no Unicode normalization. Unless a row specifies an explicit reference domain, generated refs use:

```text
ref = prefix || SHA256(schema_id + ".key" || NUL ||
                       canonical_json(all fields except
                       schema_id, generated-ref field, self-digest field))

self_digest = SHA256(schema_id + ".identity" || NUL ||
                     canonical_json(all fields except self-digest field))
```

## Registry fields and nullability

| ID | Classification | Value; literal schema; owner module | Ordered fields with exact mapping types and nullability |
|---|---|---|---|
| V01 | proposed Section 41 role-resolution contract | `Section41PostExecutionSemanticReviewLineageContextV1`; `governed-execution.nwp-section41-post-execution-semantic-review-lineage-context.v1`; `_post_execution_evidence_values.py` | `schema_id:SID, lineage_context_ref:R, proposal_phase:E{post_execution_semantic_review}, program_ref:R, program_version_ref:R, program_version_number:N1, accepted_intent_revision_ref:R, work_item_ref:R, work_item_revision_ref:R, semantic_attempt_ref:R, semantic_attempt_digest:H, attempt_number:N1, candidate_ref:R, basis_decision_ref:R, basis_decision_digest:H, work_spec_ref:R, work_spec_digest:H, work_spec_safe_projection_digest:H, effect_intent_ref:R, effect_intent_digest:H, author_command_ref:R, author_command_digest:H, standing_grant_ref:R, standing_grant_digest:H, attempt_authorization_ref:R, attempt_authorization_digest:H, effect_authorization_ref:R, effect_authorization_digest:H, attempt_fence_ref:R, attempt_fence_digest:H, effect_fence_ref:R, effect_fence_digest:H, delivery_attempt_ref:R, delivery_envelope_digest:H, delivery_attempt_digest:H, authority_evaluation_ref:R, authority_evaluation_digest:H, lineage_context_digest:H`. No nullable fields. |
| V02 | proposed post-execution evidence owner contract | `PostExecutionSemanticReviewInputContextV1`; `governed-execution.nwp-post-execution-semantic-review-context.v1`; `_post_execution_evidence_values.py` | `schema_id:SID, input_context_ref:R, profile_ref:R, profile_digest:H, proposal_phase:E{post_execution_semantic_review}, lineage_context_schema_id:SID(V01), lineage_context_ref:R, lineage_context_digest:H, phase_basis_ref:R, phase_basis_digest:H, preassigned_proposal_ref:R, role_entry_count:N1=9, role_entries:A[9,V03], model_input_safe_projection_schema_id:SID(V05), model_input_safe_projection_ref:R, model_input_safe_projection_digest:H, private_input_manifest_schema_id:SID(V07), private_input_manifest_ref:R, private_input_manifest_digest:H, constructed_at:T, input_context_digest:H`. No nullable fields. |
| V03 | proposed post-execution evidence owner contract | `PostExecutionSemanticReviewRoleEntryV2`; `governed-execution.nwp-post-execution-semantic-review-role-entry.v2`; `_post_execution_evidence_values.py` | Fields are the 18-field role-entry mapping printed above. `role:E{nine roles}`, `role_rank:N1=5..13`, `ordinal:N0=0`; typed triple always non-null. Direct-C1 four-field group is all non-null only for worker/rank14 and authority/rank1. Source-profile pair and source-binding triple follow the exact role table; each group is wholly null or wholly non-null. |
| V04 | proposed post-execution evidence owner contract | `CandidateCapsuleSafeProjectionV1`; `governed-execution.nwp-candidate-capsule-safe-projection.v1`; `_post_execution_evidence_values.py` | `schema_id:SID, projection_ref:R, candidate_ref:R, capsule_manifest_ref:R, portable_capsule_digest:H, program_ref:R, program_version_ref:R, accepted_intent_revision_ref:R, work_item_ref:R, work_item_revision_ref:R, semantic_attempt_ref:R, effect_intent_ref:R, command_ref:R, command_digest:H, attempt_fence_ref:R, attempt_fence_digest:H, effect_fence_ref:R, effect_fence_digest:H, repository_ref:R, base_git_object_format:E{sha1,sha256}, base_git_oid:str constrained by format, authorized_path_scope_digest:H, projection_digest:H`. No nullable fields. |
| V05 | proposed post-execution evidence owner contract | `PostExecutionModelInputSafeProjectionV2`; `governed-execution.nwp-post-execution-model-input-safe-projection.v2`; `_post_execution_evidence_values.py` | `schema_id:SID, projection_ref:R, profile_ref:R, profile_digest:H, proposal_phase:E{post_execution_semantic_review}, lineage_context_schema_id:SID(V01), lineage_context_ref:R, lineage_context_digest:H, entry_count:N1=9, entries:A[9,V06], projection_digest:H`. No nullable fields. |
| V06 | proposed post-execution evidence owner contract | `PostExecutionModelInputProjectionEntryV2`; `governed-execution.nwp-post-execution-model-input-projection-entry.v2`; `_post_execution_evidence_values.py` | `schema_id:SID, role:E{nine roles}, role_rank:N1=5..13, ordinal:N0=0, typed_schema_id:SID, typed_value_ref:R, typed_value_digest:H, model_value_schema_id:SID, model_value_ref:R, model_value_digest:H, model_input_posture:E{private_exact_canonical_value,nonprivate_exact_canonical_value}`. Candidate model value is V04; all others equal the typed triple. |
| V07 | proposed post-execution evidence owner contract | `PostExecutionPrivateInputManifestV2`; `governed-execution.nwp-post-execution-private-input-manifest.v2`; `_post_execution_evidence_values.py` | `schema_id:SID, manifest_ref:R, profile_ref:R, profile_digest:H, proposal_phase:E{post_execution_semantic_review}, lineage_context_schema_id:SID(V01), lineage_context_ref:R, lineage_context_digest:H, entry_count:N1=1, entries:A[1,V08], manifest_digest:H`. No nullable fields. |
| V08 | proposed post-execution evidence owner contract | `PostExecutionPrivateInputManifestEntryV2`; `governed-execution.nwp-post-execution-private-input-manifest-entry.v2`; `_post_execution_evidence_values.py` | `schema_id:SID, role:E{candidate_capsule}, role_rank:N1=5, ordinal:N0=0, typed_schema_id:SID(CandidateCapsuleManifestV1), typed_value_ref:R, typed_value_digest:H, canonical_byte_length:N1, privacy_classification:E{private_candidate_capsule_manifest}`. |
| V09 | proposed post-execution evidence owner contract | `PostExecutionModelInputBindingV2`; `governed-execution.nwp-post-execution-model-input-binding.v2`; `_post_execution_evidence_values.py` | `schema_id:SID, binding_ref:R, profile_ref:R, profile_digest:H, input_context_schema_id:SID(V02), input_context_ref:R, input_context_digest:H, lineage_context_schema_id:SID(V01), lineage_context_ref:R, lineage_context_digest:H, model_input_safe_projection_schema_id:SID(V05), model_input_safe_projection_ref:R, model_input_safe_projection_digest:H, private_input_manifest_schema_id:SID(V07), private_input_manifest_ref:R, private_input_manifest_digest:H, source_invocation_ref:R, source_invocation_digest:H, model_contract_ref:R, model_contract_digest:H, model_configuration_ref:R, model_configuration_digest:H, artifact_schema_id:SID, artifact_ref:R, artifact_digest:H, artifact_binding_digest:H, artifact_safe_projection_schema_id:SID, artifact_safe_projection_digest:H, proposal_ref:R, proposal_digest:H, evidence_set_ref:R, evidence_set_digest:H, source_invocation_started_at:T, source_invocation_completed_at:T, artifact_validated_at:T, result:E{exact}, reason:E{model_input_context_exact}, binding_digest:H`. |
| V10 | proposed post-execution evidence owner contract | `PostExecutionEvidenceSupplyV2`; `governed-execution.nwp-post-execution-evidence-supply.v2`; `_post_execution_evidence_values.py` | `schema_id:SID, supply_ref:R, profile_ref:R, profile_digest:H, input_context:O[V02], model_input_safe_projection:O[V05], private_input_manifest:O[V07], role_supply_count:N1=9, role_supplies:A[9,V11], supply_created_at:T, supply_digest:H`. Canonical bytes must be at most 1,048,576. |
| V11 | proposed post-execution evidence owner contract | `PostExecutionRoleSupplyV2`; `governed-execution.nwp-post-execution-role-supply.v2`; `_post_execution_evidence_values.py` | `schema_id:SID, role:E{nine roles}, role_rank:N1, ordinal:N0=0, typed_schema_id:SID, typed_value_ref:R, typed_value_digest:H, typed_canonical_value:O[role-specific value], source_profile_ref:R?, source_profile_digest:H?, source_profile_canonical_value:O[profile]?, source_binding_schema_id:SID?, source_binding_ref:R?, source_binding_digest:H?, source_binding_canonical_value:O[source]?, support_set_ref:R?, support_set_digest:H?, support_set_canonical_value:O[V13]?, support_value_count:N0, support_canonical_values:A[0..16,closed role-specific values], model_input_posture:E{private_exact_canonical_value,nonprivate_exact_canonical_value}`. Nullable groups follow V03 and are jointly null/non-null. |
| V12 | proposed post-execution evidence owner contract | `PostExecutionSupportEntryV1`; `governed-execution.nwp-post-execution-support-entry.v1`; `_post_execution_evidence_values.py` | Parent-dispatched fields `role:str from consuming-profile inventory, rank:N1, ordinal:N0=0, source_schema_id:SID, source_ref:R, source_digest:H`. No encoded `schema_id` field; the literal nested schema is fixed by the parent/profile. |
| V13 | proposed post-execution evidence owner contract | `PostExecutionSupportSetV1`; `governed-execution.nwp-post-execution-support-set.v1`; `_post_execution_evidence_values.py` | `schema_id:SID, support_set_ref:R, profile_ref:R, profile_digest:H, entries:A[profile-exact cardinality ≤16,V12], support_set_digest:H`. Entries are ordered by `(rank,ordinal,role,source_schema_id,source_ref)`. |
| V14 | proposed post-execution evidence owner contract | `ValidationDispositionV1`; `governed-execution.nwp-validation-disposition.v1`; `_post_execution_evidence_values.py` | Exact 41 fields: `schema_id, disposition_ref, profile_ref, profile_digest, source_observation_schema_id, source_observation_ref, source_observation_digest, source_outcome, author_role, author_ref, author_invocation_ref, program_ref, program_version_ref, accepted_intent_revision_ref, work_item_ref, work_item_revision_ref, semantic_attempt_ref, semantic_attempt_digest, attempt_number, candidate_ref, effect_intent_ref, capsule_manifest_ref, capsule_manifest_digest, validation_tool_profile_schema_id, validation_tool_profile_ref, validation_tool_profile_digest, validation_requirement_schema_id, validation_requirement_ref, validation_requirement_digest, validation_result_set_schema_id, validation_result_set_ref, validation_result_set_digest, result, reason, repairability, evaluated_at, expires_at, support_set_ref, support_set_digest, disposition_digest`; schemas are `SID`, refs/roles are `R`, digests `H`, attempt `N1`, times `T`; enums are exactly the validation profile tuples. No nullable fields. |
| V15 | proposed post-execution evidence owner contract | `IndependentReviewDispositionV1`; `governed-execution.nwp-independent-review-disposition.v1`; `_post_execution_evidence_values.py` | Exact 44 fields: V14’s common lineage/source fields, review tool/requirement/result-set triples, reviewer-independence triple, `independence_status`, `result`, `reason`, times, support pair, self-digest. Types follow V14; enums are exactly the review profile tuples. No nullable fields. |
| V16 | proposed post-execution evidence owner contract | `DecisionBranchEvaluationEntryV1`; `governed-execution.nwp-post-execution-decision-branch-evaluation-entry.v1`; `_post_execution_policy_values.py` | Parent-dispatched fields `branch:E{candidate_acceptance,candidate_repair,attempt_selecting_replan,program_terminal_reject,post_execution_program_block}, applicability:E{governed,halt_only}, governed_effect_class:E{author_candidate}?, result:E{permit,deny,unknown,conflict}, reason:reason-code str`. Effect class is non-null iff applicability is `governed`. |
| V17 | proposed post-execution evidence owner contract | `PostExecutionStandingPolicyBranchMatrixV1`; `governed-execution.nwp-post-execution-standing-policy-branch-matrix.v1`; `_post_execution_policy_values.py` | Exact fields from the fixed inventory: identity/profile/phase/program/work/attempt/candidate/effect/author fields; policy-source triple; `policy_status:E{active,inactive,unknown}`; `policy_revocation_status:E{not_revoked,revoked,unknown}`; parent grant pair; audience/repository/path/risk/source-effect fields; ordered allowed-branch/risk/effect tuples; exact 15-key nonnegative ceiling mapping; validity times; `entries:A[5,V16]`; support pair; self-digest. No nullable fields except `governed_effect_class` inside halt-only entries. |
| V18 | proposed post-execution evidence owner contract | `PostExecutionRiskLaneBranchMatrixV1`; `governed-execution.nwp-post-execution-risk-lane-branch-matrix.v1`; `_post_execution_policy_values.py` | Exact fields from the fixed inventory: identity/profile/phase/development-work/attempt/candidate/author fields; risk lane; source-profile pair; source-binding pair; risk-policy triple; policy/revocation statuses; allowed lanes and required lane; validity times; `entries:A[5,V16]`; support pair; self-digest. Required lane is a non-null exact safe ref/string. |
| V19 | compatibility edge | `FiniteBacklogRiskSourceBindingV1`; `governed-execution.nwp-finite-backlog-risk-source-binding.v1`; `_finite_backlog_risk_source_adapter.py` | `schema_id:SID, binding_ref:R, development_work_item_ref:R, backlog_ref:R, backlog_digest:H, backlog_lease_ref:R, backlog_work_item_id:R, risk_lane:R, mapping_author_ref:R, mapping_author_digest:H, mapping_evidence_ref:R, mapping_evidence_digest:H, binding_digest:H`. No nullable fields. |
| V20 | proposed post-execution evidence owner contract | `PostExecutionGlobalStopSnapshotV1`; `governed-execution.nwp-post-execution-global-stop-snapshot.v1`; `_post_execution_evidence_values.py` | `schema_id:SID, snapshot_ref:R, profile_ref:R, profile_digest:H, global_stop_schema_id:SID, global_stop_ref:R, global_stop_version:N0, global_stop_state:E{clear,active}, global_stop_reason_class:str?, global_stop_issuer_ref:R?, global_stop_issued_at:T?, global_stop_operator_decision_ref:R?, global_stop_digest:H, global_stop_updated_at:T, evaluated_at:T, support_set_ref:R, support_set_digest:H, snapshot_digest:H`. The five active-detail fields are all non-null iff state is `active`; all are null for `clear`. |
| V21 | proposed post-execution evidence owner contract | `PostExecutionSourceEffectCeilingEvidenceV1`; `governed-execution.nwp-post-execution-source-effect-ceiling-evidence.v1`; `_post_execution_evidence_values.py` | Exact fixed fields: identity/profile/phase/program/work/attempt/candidate/effect; source effect class, exact 15-key source ceilings, path scope; attempt-fence pair/classes/ceilings/expiry; effect-fence pair/ceilings/expiry; authority pair/status/family/revocation/classes/ceilings/grant expiry/observation expiry; evaluated time; `result:E{compliant,noncompliant,unknown,conflict}`; reason; support pair; self-digest. Authority ceilings may be null only with an authority-unknown result; all other mappings are complete. |
| V22 | proposed Section 41 role-resolution contract | `Section41PostExecutionProposalFamilyProjectionV2`; `governed-execution.nwp-section41-post-execution-proposal-family-projection.v2`; `_section41_post_execution_proposal_family_projection.py` | Exact 38-field projection mapping printed above. `evidence_binding_count:N0` is 0 or 9; `evidence_bindings:A[0 or 9,V23]`; `evidence_bound_at:T?` is null iff count 0. Recommendations are exactly `accept_candidate, repair_candidate, replan, terminal_reject, block`. |
| V23 | proposed Section 41 role-resolution contract | `Section41PostExecutionProjectionEvidenceEntryV2`; `governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2`; `_section41_post_execution_proposal_family_projection.py` | Exact 14 fields printed above; `required_for_selection:N1=1`; role/rank/ordinal use the nine-role inventory; no nullable fields. |
| V24 | proposed Section 41 role-resolution contract | `Section41PostExecutionRoleResolutionV3`; `governed-execution.nwp-section41-post-execution-role-resolution.v3`; `_section41_post_execution_role_resolution.py` | `schema_id, relation_ref, profile_ref, profile_digest, input_context_schema_id/ref/digest, lineage_context_schema_id/ref/digest, projection_schema_id/ref/digest, source_invocation_ref/digest, proposal_ref/digest, evidence_set_ref/digest, section41_membership_ref/digest, section41_value_ref/digest, context_role_entry_schema_id, context_role, context_role_rank, context_role_ordinal, evidence_locator_proposal_ref/role/ordinal, evidence_binding_digest, evidence_bound_at, typed_schema_id/ref/digest, source_posture, direct_c1_kind/rank/membership_ref/membership_digest, source_profile_ref/digest, source_binding_schema_id/ref/digest, model_input_posture, decision_currentness_profile_ref/digest, resolution_posture, result, reason, relation_digest`. Role-specific nullable groups follow V03. `resolution_posture=recomputable_from_exact_resupply`; `result=resolved`; `reason=exact_role_binding`. |
| V25 | proposed RW0-C decision-input contract | `RW0CDecisionMembershipClosureV1`; `governed-execution.nwp-rw0-c-decision-membership-closure.v1`; `_rw0_c_decision_input_values.py` | `schema_id:SID, closure_ref:R, profile_ref:R, profile_digest:H, phase_basis_ref:R, phase_basis_digest:H, member_count:N0≤65536, members:A[member_count,V26], captured_at:T, closure_digest:H`. |
| V26 | proposed RW0-C decision-input contract | `RW0CDecisionMembershipClosureEntryV1`; `governed-execution.nwp-rw0-c-decision-membership-closure-entry.v1`; `_rw0_c_decision_input_values.py` | Parent-dispatched fields `kind_rank:N1=1..15, membership_ref:R, membership_digest:H, value_schema_id:SID, value_ref:R, value_digest:H, scope_binding_digest:H, relation_set_digest:H, admitted_at:T, admission_graph_digest:H`. |
| V27 | proposed RW0-C decision-input contract | `RW0CDecisionCurrentSnapshotV1`; `governed-execution.nwp-rw0-c-decision-current-snapshot.v1`; `_rw0_c_decision_input_values.py` | Exact fields: `schema_id, snapshot_ref, profile_ref, profile_digest, phase_basis_ref, phase_basis_digest, k8_digest, membership_closure_ref, membership_closure_digest, selected_authority_membership_ref, selected_authority_membership_digest, selected_section41_membership_ref, selected_section41_membership_digest, selected_section41_value_ref, selected_section41_value_digest, program_head, program_version, accepted_intent_revision, work_item_head, work_item_revision, selection_head, effect_head, delivery_head, phase_instance, attempt_fence, effect_fence, authority_observation, global_stop_current, external_current_sources, captured_at, snapshot_digest`. Nested owner values are complete closed `O[X]`; external sources are `A[4,V28]`. No nullable top-level fields. |
| V28 | proposed RW0-C decision-input contract | `ExternalCurrentSourceCoordinateV1`; `governed-execution.nwp-rw0-c-external-current-source-coordinate.v1`; `_rw0_c_decision_input_values.py` | `schema_id:SID, role:E{validation,review,policy,risk}, availability:E{available,unavailable}, source_schema_id:SID?, source_ref:R?, source_digest:H?, source_profile_ref:R?, source_profile_digest:H?, source_binding_schema_id:SID?, source_binding_ref:R?, source_binding_digest:H?, effect_intent_ref:R?, delivery_attempt_ref:R?, observed_at:T?, evaluated_at:T?, expires_at:T?, source_posture:E{exact_supplied_owner_value}?`. `unavailable` requires every identity/time/posture field null; `available` requires the source/profile/binding triples and role-required times. |
| V29 | proposed RW0-C decision-input contract | `RW0CProposalEvidenceCurrentnessV1`; `governed-execution.nwp-rw0-c-proposal-evidence-currentness.v1`; `_rw0_c_decision_input_values.py` | `schema_id:SID, currentness_ref:R, profile_ref:R, profile_digest:H, proposal_ref:R, proposal_digest:H, decision_snapshot_ref:R, decision_snapshot_digest:H, components:A[4,V30], evaluated_at:T, result:E{current,stale,unknown,conflict}, reason:reason-code str, currentness_digest:H`. |
| V30 | proposed RW0-C decision-input contract | `RW0CProposalEvidenceCurrentnessComponentV1`; `governed-execution.nwp-rw0-c-proposal-evidence-currentness-component.v1`; `_rw0_c_decision_input_values.py` | `schema_id:SID, role:E{validation,review,policy,risk}, proposal_value_schema_id:SID, proposal_value_ref:R, proposal_value_digest:H, current_source_availability:E{available,unavailable}, current_value_schema_id:SID?, current_value_ref:R?, current_value_digest:H?, profile_ref:R, profile_digest:H, current_expires_at:T?, result:E{current,stale,unknown,conflict}, reason:reason-code str`. Current-value group is null only for `unavailable`. |
| V31 | proposed RW0-C decision-input contract | `RW0CDecisionTimeAuthorityBranchMatrixV1`; `governed-execution.nwp-rw0-c-decision-time-authority-branch-matrix.v1`; `_rw0_c_decision_input_values.py` | `schema_id, matrix_ref, profile_ref, profile_digest, decision_snapshot_ref, decision_snapshot_digest, authority_observation_ref, authority_observation_digest, parent_grant_ref, parent_grant_digest, evaluated_at, entries:A[5,V16], support_set_ref, support_set_digest, matrix_digest`; all identity/time fields use `SID/R/H/T`; no nullable fields. |
| V32 | proposed RW0-C decision-input contract | `RW0CDecisionTimeGlobalStopBranchMatrixV1`; `governed-execution.nwp-rw0-c-decision-time-global-stop-branch-matrix.v1`; `_rw0_c_decision_input_values.py` | `schema_id, matrix_ref, profile_ref, profile_digest, decision_snapshot_ref, decision_snapshot_digest, proposal_stop_snapshot_ref, proposal_stop_snapshot_digest, version_relation:E{same,advanced}, evaluated_at, entries:A[5,V16], support_set_ref, support_set_digest, matrix_digest`. Invalid comparison returns conflict rather than constructing a matrix. |
| V33 | proposed RW0-C decision-input contract | `RW0CDecisionTimeSourceEffectCeilingBranchMatrixV1`; `governed-execution.nwp-rw0-c-decision-time-source-effect-ceiling-branch-matrix.v1`; `_rw0_c_decision_input_values.py` | `schema_id, matrix_ref, profile_ref, profile_digest, decision_snapshot_ref, decision_snapshot_digest, proposal_ceiling_evidence_ref, proposal_ceiling_evidence_digest, evaluated_at, entries:A[5,V16], support_set_ref, support_set_digest, matrix_digest`; no nullable fields. |
| V34 | proposed RW0-C decision-input contract | `RW0CRecommendationConsistencyEvaluationV1`; `governed-execution.nwp-rw0-c-recommendation-consistency-evaluation.v1`; `_rw0_c_decision_input_values.py` | Exact fields from the fixed inventory; `model_recommendation:E{five recommendations}`, `authoritative_branch:E{five branches}`, `result:E{consistent,inconsistent,stale_context,basis_conflict}`; all pairs and evaluated time non-null. |
| V35 | proposed future committed-recovery contract | `RW0CDecisionEvaluationCommandV1`; `governed-execution.nwp-rw0-c-decision-evaluation-command.v1`; `_rw0_c_decision_input_values.py`, forecast-only | `schema_id, mutation_ref, preassigned_decision_ref, preassigned_receipt_ref, phase_basis_ref/digest, membership_closure_ref/digest, input_context_schema_id/ref/digest, lineage_context_schema_id/ref/digest, selected_section41_membership_ref/digest, proposal_ref/digest, role_resolution_set_digest, current_snapshot_ref/digest, proposal_currentness_ref/digest, authority_matrix_ref/digest, global_stop_matrix_ref/digest, ceiling_matrix_ref/digest, expected_program_head_revision/digest, expected_work_head_revision/digest, expected_selection_head_revision/digest, expected_effect_head_revision/digest, expected_delivery_head_revision/digest, expected_global_stop_version/digest, command_digest`. Revisions/versions are `N0`; no nullable fields. |
| V36 | proposed future committed-recovery contract | `RW0CCommittedRecoveryMemberV1`; `governed-execution.nwp-rw0-c-committed-recovery-member.v1`; `_rw0_c_decision_input_values.py`, forecast-only | `schema_id:SID, role:R, rank:N0, ordinal:N0, retention_mode:E{full_value,safe_projection,immutable_owner_locator}, value_schema_id:SID, value_ref:R?, value_digest:H, retained_value:O[X]?, owner_locator_kind:R?, owner_table:R?, owner_key_fields:O[closed key mapping]?, member_digest:H`. Full/safe modes require retained value and null locator fields; locator mode requires locator fields and null retained value. |
| V37 | proposed future committed-recovery contract | `RW0CCommittedRecoveryManifestV1`; `governed-execution.nwp-rw0-c-committed-recovery-manifest.v1`; `_rw0_c_decision_input_values.py`, forecast-only | `schema_id:SID, recovery_manifest_ref:R, mutation_ref:R, command_digest:H, phase_basis_ref:R, phase_basis_digest:H, member_count:N1, members:A[member_count,V36], decision_ref:R, decision_digest:H, receipt_ref:R, receipt_digest:H, committed_at:T, recovery_manifest_digest:H`. |

## Registry identity, profile, projection, and vectors

| ID | Classification | Ref/digest posture | Governing profile | Safe outward/privacy posture | Positive vector; malformed/substitution vector |
|---|---|---|---|---|---|
| V01 | proposed Section 41 role-resolution contract | Explicit `section41-post-lineage.` grammar above; self-digest | No separate profile; schema plus exact L34 relation is complete | Complete mapping is safe lineage, not authority | G: complete golden lineage below; M: generic context schema substituted |
| V02 | proposed post-execution evidence owner contract | Explicit `post-semantic-input-context.` grammar above; self-digest | `post-execution-semantic-review-input.v2` | Safe identities only; no full candidate body | G: complete golden T1 below; M: V01 object supplied as T1 |
| V03 | proposed post-execution evidence owner contract | Parent-only, no ref/self-digest | Input V2 | Parent T1 digest protects entry | G: worker entry with rank14 group; M: candidate entry with non-null C1 group |
| V04 | proposed post-execution evidence owner contract | Generated `candidate-safe-projection.` using V04 `.key`; self-digest | Input V2 relation | Entire mapping safe; no capsule entries/paths/bodies/locator | G: complete vector below; M: added path/body field |
| V05 | proposed post-execution evidence owner contract | Generated `post-model-input-projection-v2.` using V05 `.key`; self-digest | Input V2 | Entire mapping safe | G: complete nine-entry vector below; M: candidate model pair equals private manifest |
| V06 | proposed post-execution evidence owner contract | Parent-only | Input V2 | Parent projection protects entry | G: validation typed/model triples equal; M: independent-review schema under validation role |
| V07 | proposed post-execution evidence owner contract | Generated `post-private-input-manifest-v2.` using V07 `.key`; self-digest | Input V2 | Only manifest identity and byte length; outward pair only by default | G: complete one-entry vector below; M: physical locator added |
| V08 | proposed post-execution evidence owner contract | Parent-only | Input V2 | Private metadata, no body | G: rank5 candidate entry; M: second entry or zero byte length |
| V09 | proposed post-execution evidence owner contract | Generated `post-model-input-binding-v2.` using V09 `.key`; self-digest | Input V2 | Complete safe relation only | G: all T1/source/proposal identities exact; M: source/proposal context disagreement |
| V10 | proposed post-execution evidence owner contract | Generated `post-evidence-supply-v2.` using V10 `.key`; self-digest | Input V2 | Transient/private; outward ref/digest only | G: nine exact supplies under 1 MiB; M: missing candidate supply |
| V11 | proposed post-execution evidence owner contract | Parent-only | Input V2 | Transient; candidate entry may contain private canonical manifest | G: exact role-specific value/profile/support; M: digest-valid bytes under wrong schema |
| V12 | proposed post-execution evidence owner contract | Parent-only | Support-set V1 | Safe source coordinates | G: source observation rank1; M: duplicate source pair |
| V13 | proposed post-execution evidence owner contract | Generated `post-support-set.` using V13 `.key`; self-digest | Support-set V1 | Complete safe mapping | G: frozen ordered inventory; M: reordered entries |
| V14 | proposed post-execution evidence owner contract | Generated `validation-disposition.` using V14 `.key`; self-digest | Validation disposition V1 | Complete safe mapping | G: `passed/passed/not_applicable`; M: `passed/terminal_failure` |
| V15 | proposed post-execution evidence owner contract | Generated `independent-review-disposition.` using V15 `.key`; self-digest | Review disposition V1 | Complete safe mapping | G: `passed/independent/passed`; M: `not_independent/passed` |
| V16 | proposed post-execution evidence owner contract | Parent-only | Consuming matrix profile | Parent matrix protects entry | G: halt-only permit; M: halt-only `author_candidate` |
| V17 | proposed post-execution evidence owner contract | Generated `post-policy-matrix.` using V17 `.key`; self-digest | Policy matrix V1 | Complete safe evaluated matrix; not authority | G: five entries with otherwise permit; M: missing terminal branch |
| V18 | proposed post-execution evidence owner contract | Generated `post-risk-matrix.` using V18 `.key`; self-digest | Risk matrix V1 | Complete safe evaluated matrix | G: exact generic binding; M: FiniteBacklog field injected into generic matrix |
| V19 | compatibility edge | Generated `finite-backlog-risk-binding.` using V19 `.key`; self-digest | FiniteBacklog source V1 | Complete compatibility mapping, no progression authority | G: explicit dev/backlog mapping; M: IDs assumed equal without evidence |
| V20 | proposed post-execution evidence owner contract | Generated `post-global-stop-snapshot.` using V20 `.key`; self-digest | Global-stop V1 | Complete safe snapshot | G: clear state with null active details; M: clear state with issuer |
| V21 | proposed post-execution evidence owner contract | Generated `post-source-effect-ceiling.` using V21 `.key`; self-digest | Source-effect ceiling V1 | Complete safe evidence; not future effect permission | G: four distinct live expiries and compliant ceilings; M: collapsed expiry fields |
| V22 | proposed Section 41 role-resolution contract | Explicit projection V2 reference grammar; self-digest | Projection V2 | Complete safe family projection; no private artifact/capsule body | G: complete projection below; M: stale V1 context/profile pair |
| V23 | proposed Section 41 role-resolution contract | No ref; independent self-digest | Projection V2 | Safe durable-row projection | G: candidate row entry digest `8f5f…`; M: composite locator changed |
| V24 | proposed Section 41 role-resolution contract | Explicit `section41-role-relation-v3.`; reference domain `governed-execution.nwp-section41-post-execution-role-resolution-reference.v3.identity`; all semantic fields except schema/ref/self; self domain V24 `.identity` | Role-resolution V3 | Complete safe relation; recomputable, not branch authority | G: exact validation role relation; M: parent-only role entry treated as independently addressable |
| V25 | proposed RW0-C decision-input contract | Generated `rw0c-membership-closure.` using V25 `.key`; self-digest | Membership closure V1 | Complete safe closure | G: exact finite page closure; M: early termination |
| V26 | proposed RW0-C decision-input contract | Parent-only | Closure V1 | Full entry retained in parent | G: exact selected rank15 entry; M: valid-looking pair with wrong admission graph |
| V27 | proposed RW0-C decision-input contract | Generated `rw0c-current-snapshot.` using V27 `.key`; self-digest | Current snapshot V1 | Complete safe snapshot; no private supply | G: all required owners reconstruct; M: unresolved selection-head locator |
| V28 | proposed RW0-C decision-input contract | Parent-only | Current snapshot V1 | Safe coordinate only; no custody claim | G: available validation coordinate; M: unavailable with non-null digest |
| V29 | proposed RW0-C decision-input contract | Generated `rw0c-evidence-currentness.` using V29 `.key`; self-digest | Proposal currentness V1 | Complete safe evaluation | G: four current components; M: same ref/different digest |
| V30 | proposed RW0-C decision-input contract | Parent-only | Proposal currentness V1 | Safe comparison result | G: exact fresh pair/current; M: wrong profile/current |
| V31 | proposed RW0-C decision-input contract | Generated `rw0c-authority-matrix.` using V31 `.key`; self-digest | Authority branch V1 | Complete safe matrix; permit is not executable authority | G: live verified authority; M: expired attempt fence marked permit |
| V32 | proposed RW0-C decision-input contract | Generated `rw0c-stop-matrix.` using V32 `.key`; self-digest | Global-stop V1, shared with V20 | Complete safe matrix | G: higher valid clear version; M: lower version |
| V33 | proposed RW0-C decision-input contract | Generated `rw0c-ceiling-matrix.` using V33 `.key`; self-digest | Decision-time ceiling V1 | Complete safe matrix; not future permission | G: current ceilings cover source use; M: source exceeds current attempt |
| V34 | proposed RW0-C decision-input contract | Generated `rw0c-recommendation-check.` using V34 `.key`; self-digest | Recommendation consistency V1 | Complete safe comparison; no branch authority | G: `accept_candidate` versus independently supplied acceptance branch; M: recommendation used to derive branch |
| V35 | proposed future committed-recovery contract | `mutation_ref` owner-supplied; no generated command ref; `command_digest` under V35 `.identity`, excluding itself | None yet; branch-evaluator contract is missing | Safe input identity; no authority | G: reserved complete command after branch freeze; M: import into current pure tranche |
| V36 | proposed future committed-recovery contract | No ref; independent `member_digest` under V36 `.identity` | None yet | Full safe value or immutable locator; never private capsule body | G: candidate safe-projection member; M: opaque digest-only `full_value` |
| V37 | proposed future committed-recovery contract | Generated `rw0c-recovery-manifest.` using V37 `.key`; self-digest | None yet; forecast-only | Safe values/locators; no private supply | G: complete future committed family; M: missing branch evaluation or neutral basis |

# Profile-to-value matrix

| Classification | Profile | Governed values/relations |
|---|---|---|
| proposed post-execution evidence owner contract | `post-execution-semantic-review-input.v2` | V02–V11, including transient supply, model-input binding, candidate safe-projection relation, all role/nullability rules, and T1/lineage equality |
| proposed Section 41 role-resolution contract | `section41-post-execution-proposal-family-projection.v2` | V22 and V23 |
| proposed Section 41 role-resolution contract | `section41-post-execution-role-resolution.v3` | V24 |
| proposed post-execution evidence owner contract | `post-execution-support-set.v1` | V12 and V13 |
| proposed post-execution evidence owner contract | `validation-disposition.v1` | V14 |
| proposed post-execution evidence owner contract | `independent-review-disposition.v1` | V15 |
| proposed post-execution evidence owner contract | `post-execution-standing-policy-matrix.v1` | V16 when nested in V17, and V17 |
| proposed post-execution evidence owner contract | `post-execution-risk-lane-matrix.v1` | V16 when nested in V18, and V18 |
| compatibility edge | `finite_backlog_risk_source.v1` | V19 |
| proposed post-execution evidence owner contract | `post-execution-global-stop.v1` | Proposal-time V20 and decision-time V32; no separate stop-matrix profile |
| proposed post-execution evidence owner contract | `post-execution-source-effect-ceiling.v1` | V21 |
| proposed RW0-C decision-input contract | `rw0-c-decision-membership-closure.v1` | V25 and V26 |
| proposed RW0-C decision-input contract | `rw0-c-decision-current-snapshot.v1` | V27 and V28 |
| proposed RW0-C decision-input contract | `rw0-c-proposal-evidence-currentness.v1` | V29 and V30 |
| proposed RW0-C decision-input contract | `rw0-c-decision-time-authority-branch.v1` | V16 when nested in V31, and V31 |
| proposed RW0-C decision-input contract | `rw0-c-decision-time-source-effect-ceiling-branch.v1` | V16 when nested in V33, and V33 |
| proposed RW0-C decision-input contract | `rw0-c-recommendation-consistency.v1` | V34 |
| proposed future committed-recovery contract | No current behavior profile | V35–V37 remain forecast-only. Their versioned logical schemas do not authorize implementation. |

[implementation-detail observation] Profile digests use `SHA256(profile_schema_id + ".identity" || NUL || canonical_profile_json)`. All 17 current profile byte strings reproduced with Python 3.13.4 `hashlib` and `/usr/bin/openssl` using LibreSSL 3.3.6.

| Profile | Bytes | Raw SHA-256 | Domain-separated digest |
|---|---:|---|---|
| `post-execution-semantic-review-input.v2` | 6,895 | `982525eded404c3130aaf1df39ce14ef7288d6b6c90e3806656e6be0bd90893e` | `c4346cf2e33382a030fb8e897601ea62494be986ccc6428780398eec10809819` |
| `section41-post-execution-proposal-family-projection.v2` | 5,077 | `837f92444a33ee148237c1a256101bcda7cd6b943f8c59bc47ecc02ee6e9fe7f` | `c40867c7bf2519eb0f50f4cb21056b4b8b0aca6fb88162c03deb46e77f246cb0` |
| `section41-post-execution-role-resolution.v3` | 5,392 | `16293a4aa1baf99dbd986fb7f486628b60d94e14ab06555566bb768973fdfa0b` | `fd051f9c484aff121740db9592b5b3509de04ca4adbc3986081236d31efb7920` |
| `post-execution-support-set.v1` | 531 | `9953312e8e5d8a134fce04f1f60da31ef39b4e8bd88ffc4ea7c93bfc39740926` | `026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097` |
| `validation-disposition.v1` | 1,456 | `731e582f7b27023f6d6336616510c268a321b8296e741288ec0169ddbb4d68ff` | `a53ccecbfa11c0a593536e8eda8ed59bec59f7e145a70cd04599913bf1e72157` |
| `independent-review-disposition.v1` | 2,157 | `cda4a67c8a755507f6adee78a21098eed65863b899cef0c71c4f2c2092ab9f35` | `ffdeb616c6beba4494bf08120f73a95adebbe724d78425cc7b6403a7c2394bbf` |
| `post-execution-standing-policy-matrix.v1` | 1,622 | `d92a56b0e7e98a99ffc0b0d31379235b3a4e431ba388fa787f51f06eb2996549` | `c6e4ea9c56f45150d15ded0dca48f68fb15be0fa7f0b444e72f06a0137a1c9e8` |
| `post-execution-risk-lane-matrix.v1` | 1,586 | `e40347aa8ec3f50439a093fa7ca39fc04962e97ba7976f87cc7f19f842207c7d` | `eda9c5762c05f5fa825f8fa7a6a7562959ec39b09187e89f01c519dfb0167567` |
| `finite_backlog_risk_source.v1` | 827 | `d930f41abee9016a854e634523bf2a1eeda2047eecc3a7ea204ca7838b6179f8` | `1dace7cff29db22842b948482aeafb4f8a5b43fb7695a867901e49e2d22b7eac` |
| `post-execution-global-stop.v1` | 1,435 | `91b6abad81c5ee2ab0ec6d659b086645221e1bc73e0663951157af935e72f80a` | `2d76a6933c708473707fb1398e98ee76c8e7092436ffbf544cb54d2ad2b26ff2` |
| `post-execution-source-effect-ceiling.v1` | 1,907 | `1bd34450399ae30fc80ca0adf42d353a99452a2e1718583a5b727f172d19daba` | `950bf044d7d7c7fc7721e732f748d97213413afe501d0ac3d71f726d06a340a0` |
| `rw0-c-decision-membership-closure.v1` | 990 | `5e5f608cdbb83057c90165a617ad8d56a0d1ad00302121f3725d5fc1f5296144` | `ee888fefe4fb5a9de378265741e9e68a57e117eed8ef732261fd6ccbdebe638d` |
| `rw0-c-decision-current-snapshot.v1` | 1,284 | `54d2345917c75c529cde39463c29c3eca4ed818b44d2d356e438d20322bd2c1f` | `5db66a2bc4ac9c69e6be2fea77f0ca912fb7785d5b1db2afa82d149fac057d0d` |
| `rw0-c-proposal-evidence-currentness.v1` | 964 | `a1f3534a64a9fcd9bcc85e34638ca0af9a4c9b58f22497b920f75729cf1c9f47` | `cbee95522a01784f7c3ab7a2645ecf42afd2d0461f4e3a5951613688f69e435a` |
| `rw0-c-decision-time-authority-branch.v1` | 1,379 | `7b90906177bf489bd61a85f0938b102ad19e275c7366d61d54f224c374b17b40` | `07384a871dd87a8387c97bb1cd60e6cc8207333428e04e7766044ec8567677dc` |
| `rw0-c-decision-time-source-effect-ceiling-branch.v1` | 1,672 | `a3ef96811be1ed5ade01dbcbf359a163a351b825db181990f243c79389493e7a` | `500a7d6ef544251d3592022766b750aadd3313120b8c48dabed78858100ebbe1` |
| `rw0-c-recommendation-consistency.v1` | 798 | `e8c93e807beff0e2d36dcfcf27c0bbca0060b7a655a558aaf578e4af55798676` | `b85aba9ee6564d53dcb075c5bb60e33a3b923a504c9b38046f2f96aa28f05ebd` |

[proposed post-execution evidence owner contract] Complete current canonical profile JSON for `post-execution-semantic-review-input.v2`:

```json
{"canonicalization":"canonical-json.sorted-keys.no-whitespace.utf8.v1","context_digest_domain":"governed-execution.nwp-post-execution-semantic-review-context.v1.identity","context_fields":["schema_id","input_context_ref","profile_ref","profile_digest","proposal_phase","lineage_context_schema_id","lineage_context_ref","lineage_context_digest","phase_basis_ref","phase_basis_digest","preassigned_proposal_ref","role_entry_count","role_entries","model_input_safe_projection_schema_id","model_input_safe_projection_ref","model_input_safe_projection_digest","private_input_manifest_schema_id","private_input_manifest_ref","private_input_manifest_digest","constructed_at","input_context_digest"],"context_reference_domain":"governed-execution.nwp-post-execution-semantic-review-input-context-reference.v1.identity","context_reference_fields":["profile_ref","profile_digest","proposal_phase","lineage_context_schema_id","lineage_context_ref","lineage_context_digest","phase_basis_ref","phase_basis_digest","preassigned_proposal_ref","role_entry_count","role_entries","model_input_safe_projection_schema_id","model_input_safe_projection_ref","model_input_safe_projection_digest","private_input_manifest_schema_id","private_input_manifest_ref","private_input_manifest_digest","constructed_at"],"context_reference_prefix":"post-semantic-input-context.","context_schema_id":"governed-execution.nwp-post-execution-semantic-review-context.v1","context_self_exclusion":["input_context_digest"],"context_value_name":"PostExecutionSemanticReviewInputContextV1","lineage_binding":"exact_schema_ref_digest_and_reconstructed_l34","lineage_context_schema_id":"governed-execution.nwp-section41-post-execution-semantic-review-lineage-context.v1","malformed_substituted_or_contradictory":"basis_conflict","maximum_supply_canonical_bytes":1048576,"missing_complete_input":"no_decision_and_invocation_forbidden","missing_exact_resupply":"no_decision","model_input_projection_entry_identity":"parent_only_no_ref_no_self_digest","model_input_projection_entry_schema_id":"governed-execution.nwp-post-execution-model-input-projection-entry.v2","model_input_projection_schema_id":"governed-execution.nwp-post-execution-model-input-safe-projection.v2","private_candidate_rule":"model_projection_uses_candidate_safe_projection_and_private_manifest_binds_exact_full_manifest","private_input_manifest_entry_identity":"parent_only_no_ref_no_self_digest","private_input_manifest_entry_schema_id":"governed-execution.nwp-post-execution-private-input-manifest-entry.v2","private_input_manifest_schema_id":"governed-execution.nwp-post-execution-private-input-manifest.v2","profile_ref":"post-execution-semantic-review-input.v2","proposal_phase":"post_execution_semantic_review","role_entry_count":9,"role_entry_identity":"parent_only_no_ref_no_self_digest","role_entry_schema_id":"governed-execution.nwp-post-execution-semantic-review-role-entry.v2","role_supply_schema_id":"governed-execution.nwp-post-execution-role-supply.v2","roles":[{"decision_currentness":"none","direct_c1":null,"model_input_posture":"private_exact_canonical_value","ordinal":0,"role":"candidate_capsule","role_rank":5,"source_binding":"null","source_posture":"transient_private_resupply","source_profile":"null","typed_schema_id":"governed-execution.nwp-candidate-capsule-manifest.v1"},{"decision_currentness":"immutable","direct_c1":{"kind":"wire_process_result_classification_binding","kind_rank":14},"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"worker_result","role_rank":6,"source_binding":"classification_relation_pair","source_posture":"c1_admitted_exact_value","source_profile":"wire_profile_pair","typed_schema_id":"governed-execution.nwp-rw0-c1-wire-process-result-classification-binding.v1"},{"decision_currentness":"proposal_evidence_currentness","direct_c1":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"validation_result","role_rank":7,"source_binding":"source_observation_triple","source_posture":"transient_owner_resupply","source_profile":"disposition_profile_pair","typed_schema_id":"governed-execution.nwp-validation-disposition.v1"},{"decision_currentness":"proposal_evidence_currentness","direct_c1":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"independent_review","role_rank":8,"source_binding":"source_observation_triple","source_posture":"transient_owner_resupply","source_profile":"disposition_profile_pair","typed_schema_id":"governed-execution.nwp-independent-review-disposition.v1"},{"decision_currentness":"proposal_evidence_currentness","direct_c1":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"standing_policy","role_rank":9,"source_binding":"policy_source_triple","source_posture":"transient_owner_resupply","source_profile":"policy_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-standing-policy-branch-matrix.v1"},{"decision_currentness":"proposal_evidence_currentness","direct_c1":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"risk_lane","role_rank":10,"source_binding":"risk_source_binding_triple","source_posture":"transient_owner_resupply","source_profile":"risk_source_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-risk-lane-branch-matrix.v1"},{"decision_currentness":"authority_branch_matrix","direct_c1":{"kind":"authority_verification_observation","kind_rank":1},"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"authority_currentness_attestation","role_rank":11,"source_binding":"null","source_posture":"c1_admitted_exact_value","source_profile":"null","typed_schema_id":"governed-execution.nwp-rw0-authority-verification-observation.v1"},{"decision_currentness":"global_stop_branch_matrix","direct_c1":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"global_stop","role_rank":12,"source_binding":"global_stop_state_triple","source_posture":"transient_owner_resupply","source_profile":"stop_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-global-stop-snapshot.v1"},{"decision_currentness":"source_effect_ceiling_branch_matrix","direct_c1":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"effect_ceiling","role_rank":13,"source_binding":"effect_fence_triple","source_posture":"transient_owner_resupply","source_profile":"ceiling_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-source-effect-ceiling-evidence.v1"}],"schema_id":"governed-execution.nwp-post-execution-semantic-review-input-profile.v2","section41_rank15_membership_at_t1":"forbidden_unavailable","source_and_proposal_context_equality":"schema_ref_digest_exact","supply_schema_id":"governed-execution.nwp-post-execution-evidence-supply.v2","unknown_fields":"reject_before_canonicalization"}
```

[proposed Section 41 role-resolution contract] Complete current canonical profile JSON for `section41-post-execution-proposal-family-projection.v2`:

```json
{"c1_change":false,"canonicalization":"canonical-json.sorted-keys.no-whitespace.utf8.v1","chronology":["input_context_constructed_at<=source_invocation_started_at","source_invocation_started_at<=source_invocation_completed_at","source_invocation_completed_at<=artifact_validated_at","artifact_validated_at<=evidence_bound_at","evidence_bound_at<=proposal_created_at","projection_evaluated_at=proposal_created_at"],"cross_row_equality":["source_and_proposal_model_contract_pair","source_and_proposal_model_configuration_pair","source_and_proposal_input_context_schema_ref_digest","input_context_nested_lineage_schema_ref_digest","source_artifact_and_proposal_artifact_schema_ref_digest","artifact_and_proposal_safe_projection_schema_digest","proposal_source_invocation_ref_digest","proposal_and_rows_evidence_set_ref_digest","rows_and_input_role_schema_ref_digest","nine_rows_common_evidence_bound_at"],"durable_evidence_locator":["proposal_ref","evidence_role","ordinal"],"durable_evidence_row_identity":"evidence_binding_digest","durable_evidence_row_schema_id":"governed-execution.nwp-model-proposal-evidence-binding.v1","evidence_cardinality":{"absent":0,"all_other":"basis_conflict","complete":9},"evidence_order":["role_rank","ordinal","evidence_role"],"input_context_schema_id":"governed-execution.nwp-post-execution-semantic-review-context.v1","input_profile_digest":"c4346cf2e33382a030fb8e897601ea62494be986ccc6428780398eec10809819","input_profile_ref":"post-execution-semantic-review-input.v2","lineage_context_schema_id":"governed-execution.nwp-section41-post-execution-semantic-review-lineage-context.v1","migration_0003_change":false,"owner_family_graph":{"digest_domain":"governed-execution.nwp-rw0-c1-section41-owner-family-graph.v1.identity","locator_counts":[3,12],"schema_id":"governed-execution.nwp-rw0-c1-section41-owner-family-graph.v1","unchanged":true},"privacy":"safe_refs_digests_finite_enums_and_times_only_no_private_artifact_or_capsule_entries","profile_ref":"section41-post-execution-proposal-family-projection.v2","projection_digest_domain":"governed-execution.nwp-section41-post-execution-proposal-family-projection.v2.identity","projection_evidence_entry_digest_domain":"governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2.identity","projection_evidence_entry_fields":["schema_id","proposal_ref","proposal_phase","evidence_set_ref","evidence_role","role_rank","ordinal","evidence_ref","evidence_digest","required_for_selection","evidence_bound_at","source_binding_schema_id","source_binding_digest","projection_evidence_entry_digest"],"projection_evidence_entry_identity":"independent_self_digest_no_ref","projection_evidence_entry_schema_id":"governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2","projection_fields":["schema_id","projection_ref","profile_ref","profile_digest","proposal_phase","source_invocation_ref","source_invocation_digest","artifact_ref","artifact_digest","artifact_binding_digest","proposal_ref","proposal_digest","model_contract_ref","model_contract_digest","model_configuration_ref","model_configuration_digest","input_context_schema_id","input_context_ref","input_context_digest","lineage_context_schema_id","lineage_context_ref","lineage_context_digest","safe_projection_schema_id","safe_projection_digest","evidence_set_ref","evidence_set_digest","evidence_binding_count","evidence_bindings","owner_family_graph_digest","recommendation","reason_code","source_invocation_started_at","source_invocation_completed_at","artifact_validated_at","evidence_bound_at","proposal_created_at","projection_evaluated_at","projection_digest"],"projection_reference_domain":"governed-execution.nwp-section41-post-execution-proposal-family-projection-reference.v2.identity","projection_reference_fields":["profile_ref","profile_digest","proposal_ref","proposal_digest","input_context_schema_id","input_context_ref","input_context_digest","lineage_context_schema_id","lineage_context_ref","lineage_context_digest","evidence_set_ref","evidence_set_digest","owner_family_graph_digest"],"projection_reference_prefix":"section41-post-projection-v2.","projection_schema_id":"governed-execution.nwp-section41-post-execution-proposal-family-projection.v2","projection_self_exclusion":["projection_digest"],"projection_value_name":"Section41PostExecutionProposalFamilyProjectionV2","recommendation_authority":false,"recommendations":["accept_candidate","repair_candidate","replan","terminal_reject","block"],"schema_id":"governed-execution.nwp-section41-post-execution-proposal-family-projection-profile.v2","source_rows":[["section41_post_source_invocation_v1","development_model_source_invocations","source_invocation_ref",2],["section41_post_private_artifact_binding_v1","development_private_proposal_artifact_bindings","artifact_ref",2],["section41_post_model_proposal_v1","development_model_proposals","proposal_ref",2],["rw0_c1_section41_post_execution_evidence_family","development_model_proposal_evidence_bindings","proposal_ref",16]],"unknown_fields":"reject_before_canonicalization"}
```

[proposed Section 41 role-resolution contract] Complete current canonical profile JSON for `section41-post-execution-role-resolution.v3`:

```json
{"absent_behavior":"no_decision","c1_change":false,"canonicalization":"canonical-json.sorted-keys.no-whitespace.utf8.v1","evidence_binding_locator_fields":["proposal_ref","evidence_role","ordinal"],"evidence_binding_row_identity":"evidence_binding_digest","evidence_cardinality":{"absent":0,"complete":9},"future_attestation":"migration_0005_may_retain_relation_and_safe_value_or_locator_only_after_separate_authorization","incomplete_or_substituted_behavior":"basis_conflict","input_context_schema_id":"governed-execution.nwp-post-execution-semantic-review-context.v1","input_profile_digest":"c4346cf2e33382a030fb8e897601ea62494be986ccc6428780398eec10809819","input_profile_ref":"post-execution-semantic-review-input.v2","lineage_context_schema_id":"governed-execution.nwp-section41-post-execution-semantic-review-lineage-context.v1","migration_0003_change":false,"profile_ref":"section41-post-execution-role-resolution.v3","projection_profile_digest":"c40867c7bf2519eb0f50f4cb21056b4b8b0aca6fb88162c03deb46e77f246cb0","projection_profile_ref":"section41-post-execution-proposal-family-projection.v2","rank15_c1_kind":"section41_post_execution_proposal_family_member","rank15_c1_kind_rank":15,"relation_digest_domain":"governed-execution.nwp-section41-post-execution-role-resolution.v3.identity","relation_reference_domain":"governed-execution.nwp-section41-post-execution-role-resolution-reference.v3.identity","relation_reference_prefix":"section41-role-relation-v3.","relation_schema_id":"governed-execution.nwp-section41-post-execution-role-resolution.v3","resolution_posture":"recomputable_from_exact_resupply","role_entry_identity":"parent_only_reconstructed_by_role_rank_ordinal","roles":[{"decision_currentness":"none","direct_c1":null,"model_input_posture":"private_exact_canonical_value","ordinal":0,"role":"candidate_capsule","role_rank":5,"source_binding":"null","source_posture":"transient_private_resupply","source_profile":"null","typed_schema_id":"governed-execution.nwp-candidate-capsule-manifest.v1"},{"decision_currentness":"immutable","direct_c1":{"kind":"wire_process_result_classification_binding","kind_rank":14},"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"worker_result","role_rank":6,"source_binding":"classification_relation_pair","source_posture":"c1_admitted_exact_value","source_profile":"wire_profile_pair","typed_schema_id":"governed-execution.nwp-rw0-c1-wire-process-result-classification-binding.v1"},{"decision_currentness":"proposal_evidence_currentness","direct_c1":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"validation_result","role_rank":7,"source_binding":"source_observation_triple","source_posture":"transient_owner_resupply","source_profile":"disposition_profile_pair","typed_schema_id":"governed-execution.nwp-validation-disposition.v1"},{"decision_currentness":"proposal_evidence_currentness","direct_c1":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"independent_review","role_rank":8,"source_binding":"source_observation_triple","source_posture":"transient_owner_resupply","source_profile":"disposition_profile_pair","typed_schema_id":"governed-execution.nwp-independent-review-disposition.v1"},{"decision_currentness":"proposal_evidence_currentness","direct_c1":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"standing_policy","role_rank":9,"source_binding":"policy_source_triple","source_posture":"transient_owner_resupply","source_profile":"policy_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-standing-policy-branch-matrix.v1"},{"decision_currentness":"proposal_evidence_currentness","direct_c1":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"risk_lane","role_rank":10,"source_binding":"risk_source_binding_triple","source_posture":"transient_owner_resupply","source_profile":"risk_source_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-risk-lane-branch-matrix.v1"},{"decision_currentness":"authority_branch_matrix","direct_c1":{"kind":"authority_verification_observation","kind_rank":1},"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"authority_currentness_attestation","role_rank":11,"source_binding":"null","source_posture":"c1_admitted_exact_value","source_profile":"null","typed_schema_id":"governed-execution.nwp-rw0-authority-verification-observation.v1"},{"decision_currentness":"global_stop_branch_matrix","direct_c1":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"global_stop","role_rank":12,"source_binding":"global_stop_state_triple","source_posture":"transient_owner_resupply","source_profile":"stop_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-global-stop-snapshot.v1"},{"decision_currentness":"source_effect_ceiling_branch_matrix","direct_c1":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"effect_ceiling","role_rank":13,"source_binding":"effect_fence_triple","source_posture":"transient_owner_resupply","source_profile":"ceiling_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-source-effect-ceiling-evidence.v1"}],"schema_id":"governed-execution.nwp-section41-post-execution-role-resolution-profile.v3","unknown_fields":"reject_before_canonicalization"}
```

[proposed post-execution evidence owner contract] Complete canonical JSON for the 14 preserved profiles:

```json
{"cardinality":"exact_consuming_profile_inventory","duplicate_policy":"reject_any_repeated_role_rank_ordinal_or_source_pair","entry_fields":["role","rank","ordinal","source_schema_id","source_ref","source_digest"],"maximum_entries":16,"ordering":["rank","ordinal","role","source_schema_id","source_ref"],"ordinal":0,"profile_ref":"post-execution-support-set.v1","schema_id":"governed-execution.nwp-post-execution-support-set-profile.v1","substitution_policy":"exact_profile_role_schema_ref_digest_required","unknown_role":"reject"}
{"all_other_tuples":"reject_outcome_disposition_mismatch","model_dependence":false,"profile_ref":"validation-disposition.v1","schema_id":"governed-execution.nwp-validation-disposition-profile.v1","semantic_tuples":[["passed","passed","not_applicable","validation_passed"],["failed","repairable_failure","repairable","validation_failed_repairable"],["failed","replan_required","same_attempt_insufficient","validation_failed_replan_required"],["failed","terminal_failure","nonrepairable","validation_failed_terminal"],["failed","unknown","unknown","validation_failed_unclassified"],["inconclusive","unknown","unknown","validation_inconclusive"],["not_run","not_run","not_applicable","validation_not_run"]],"source_observation_kind":"validation_completed","source_outcomes":["passed","failed","inconclusive","not_run"],"structural_precedence":["source_observation_mismatch","lineage_mismatch","author_identity_conflict","profile_identity_conflict","requirement_identity_conflict","result_set_identity_conflict","candidate_identity_conflict","support_identity_conflict","timestamp_conflict"],"structural_tuple":["any_source_outcome","basis_conflict","conflict","first_structural_reason"],"support_profile_digest":"026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097","support_roles":[["source_observation",1],["disposition_profile",2],["validation_tool_profile",3],["validation_requirement",4],["validation_result_set",5],["candidate_capsule",6]]}
{"all_other_tuples":"reject_outcome_disposition_mismatch","independence_statuses":["independent","not_independent","unknown","conflict"],"model_dependence":false,"profile_ref":"independent-review-disposition.v1","schema_id":"governed-execution.nwp-independent-review-disposition-profile.v1","semantic_tuples":[["passed","independent","passed","review_passed"],["failed","independent","repair_required","review_failed_repair_required"],["failed","independent","replan_required","review_failed_replan_required"],["failed","independent","terminal_reject","review_failed_terminal_reject"],["failed","independent","unknown","review_failed_unclassified"],["inconclusive","independent","unknown","review_inconclusive"],["passed","unknown","unknown","review_independence_unknown"],["failed","unknown","unknown","review_independence_unknown"],["inconclusive","unknown","unknown","review_independence_unknown"],["passed","not_independent","basis_conflict","review_not_independent"],["failed","not_independent","basis_conflict","review_not_independent"],["inconclusive","not_independent","basis_conflict","review_not_independent"],["passed","conflict","basis_conflict","reviewer_independence_conflict"],["failed","conflict","basis_conflict","reviewer_independence_conflict"],["inconclusive","conflict","basis_conflict","reviewer_independence_conflict"]],"source_observation_kind":"independent_review_completed","source_outcomes":["passed","failed","inconclusive"],"structural_precedence":["source_observation_mismatch","lineage_mismatch","author_identity_conflict","profile_identity_conflict","requirement_identity_conflict","result_set_identity_conflict","candidate_identity_conflict","independence_identity_conflict","support_identity_conflict","timestamp_conflict"],"structural_tuple":["any_source_outcome","any_independence_status","basis_conflict","first_structural_reason"],"support_profile_digest":"026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097","support_roles":[["source_observation",1],["disposition_profile",2],["review_tool_profile",3],["review_requirement",4],["review_result_set",5],["reviewer_independence",6],["candidate_capsule",7]]}
{"branches":[{"applicability":"governed","branch":"candidate_acceptance","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"candidate_repair","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"attempt_selecting_replan","governed_effect_class":"author_candidate"},{"applicability":"halt_only","branch":"program_terminal_reject","governed_effect_class":null},{"applicability":"halt_only","branch":"post_execution_program_block","governed_effect_class":null}],"permit_is_executable_authority":false,"precedence":[["policy_identity_conflict","conflict"],["evaluator_profile_mismatch","conflict"],["support_conflict","conflict"],["halt_only","permit","halt_only_policy_not_applicable"],["policy_revoked","deny"],["before_not_before","deny","policy_not_yet_valid"],["at_or_after_expiry","deny","policy_expired"],["branch_not_allowed","deny"],["audience_mismatch","deny"],["repository_mismatch","deny"],["path_scope_mismatch","deny"],["risk_lane_not_allowed","deny"],["effect_class_not_allowed","deny"],["ceilings_exceeded","deny"],["policy_status_unknown","unknown"],["policy_currentness_unknown","unknown"],["otherwise","permit","policy_permits"]],"profile_ref":"post-execution-standing-policy-matrix.v1","results":["permit","deny","unknown","conflict"],"schema_id":"governed-execution.nwp-post-execution-standing-policy-matrix-profile.v1","support_profile_digest":"026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097","support_roles":[["policy_source",1],["policy_profile",2],["parent_grant",3],["authority_observation",4],["source_effect_intent",5]]}
{"branches":[{"applicability":"governed","branch":"candidate_acceptance","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"candidate_repair","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"attempt_selecting_replan","governed_effect_class":"author_candidate"},{"applicability":"halt_only","branch":"program_terminal_reject","governed_effect_class":null},{"applicability":"halt_only","branch":"post_execution_program_block","governed_effect_class":null}],"finite_backlog_in_generic_schema":false,"generic_source_fields":["development_work_item_ref","risk_lane","source_profile_ref","source_profile_digest","source_binding_ref","source_binding_digest"],"precedence":[["risk_source_conflict","conflict"],["policy_identity_conflict","conflict"],["evaluator_profile_mismatch","conflict"],["support_conflict","conflict"],["halt_only","permit","halt_only_risk_not_applicable"],["policy_revoked","deny"],["before_not_before","deny","policy_not_yet_valid"],["at_or_after_expiry","deny","policy_expired"],["required_lane_mismatch","deny"],["risk_lane_not_allowed","deny"],["policy_status_unknown","unknown"],["otherwise","permit","risk_lane_permits"]],"profile_ref":"post-execution-risk-lane-matrix.v1","results":["permit","deny","unknown","conflict"],"schema_id":"governed-execution.nwp-post-execution-risk-lane-matrix-profile.v1","support_profile_digest":"026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097","support_roles":[["risk_source_profile",1],["risk_source_binding",2],["risk_policy",3],["risk_profile",4]]}
{"binding_schema_id":"governed-execution.nwp-finite-backlog-risk-source-binding.v1","generic_projection_fields":["development_work_item_ref","risk_lane","source_profile_ref","source_profile_digest","source_binding_ref","source_binding_digest"],"profile_ref":"finite_backlog_risk_source.v1","relations":["backlog_identity_exact","backlog_item_exact","risk_lane_exact","development_to_backlog_mapping_explicit","development_and_backlog_ids_need_not_equal"],"schema_id":"governed-execution.nwp-finite-backlog-risk-source-profile.v1","source_fields":["development_work_item_ref","backlog_ref","backlog_digest","backlog_lease_ref","backlog_work_item_id","risk_lane","mapping_author_ref","mapping_author_digest","mapping_evidence_ref","mapping_evidence_digest"],"standing_lease_permission":false,"target_progression_authority":false}
{"branches":[{"applicability":"governed","branch":"candidate_acceptance","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"candidate_repair","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"attempt_selecting_replan","governed_effect_class":"author_candidate"},{"applicability":"halt_only","branch":"program_terminal_reject","governed_effect_class":null},{"applicability":"halt_only","branch":"post_execution_program_block","governed_effect_class":null}],"entry_table":[["clear","governed","permit","global_stop_clear"],["clear","halt_only","permit","halt_only_global_stop_clear"],["active","governed","deny","global_stop_active"],["active","halt_only","permit","halt_only_global_stop_active"]],"permit_is_complete_authority":false,"profile_ref":"post-execution-global-stop.v1","same_version_fields":["global_stop_ref","global_stop_state","global_stop_digest","global_stop_updated_at"],"schema_id":"governed-execution.nwp-post-execution-global-stop-profile.v1","snapshot_source":"one_exact_global_stop_current_envelope","support_profile_digest":"026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097","support_roles":[["global_stop_current",1],["stop_profile",2]],"version_relation":[["missing_or_malformed","basis_conflict"],["lower","basis_conflict"],["same_with_any_field_mismatch","basis_conflict"],["same_exact","same"],["higher_well_formed","advanced"]]}
{"branch_neutral":true,"ceiling_fields":["max_active_invocations","max_candidate_bytes","max_changed_files","max_cost_microusd","max_cpu_seconds","max_deliveries","max_deployments","max_local_commits","max_memory_bytes","max_merges","max_model_input_tokens","max_model_output_tokens","max_pull_requests","max_pushes","max_wall_seconds"],"comparison":"componentwise_source_less_than_or_equal_to_each_attempt_effect_authority_ceiling","expiry_fields":["attempt_fence_expires_at","effect_fence_expires_at","authority_grant_expires_at","authority_observation_expires_at"],"future_effect_permission":false,"precedence":[["profile_mismatch","conflict"],["lineage_conflict","conflict"],["fence_identity_conflict","conflict"],["authority_identity_conflict","conflict"],["support_conflict","conflict"],["authority_denied_or_revoked","noncompliant"],["attempt_fence_expired","noncompliant"],["effect_fence_expired","noncompliant"],["authority_grant_expired","noncompliant"],["authority_observation_expired","noncompliant"],["effect_class_not_allowed_by_attempt","noncompliant"],["effect_class_not_allowed_by_authority","noncompliant"],["effect_exceeds_attempt","noncompliant"],["effect_exceeds_effect_fence","noncompliant"],["effect_exceeds_authority","noncompliant"],["authority_status_unknown","unknown"],["authority_family_unknown","unknown"],["authority_revocation_unknown","unknown"],["authority_ceiling_unknown","unknown"],["otherwise","compliant","source_effect_within_ceilings"]],"profile_ref":"post-execution-source-effect-ceiling.v1","results":["compliant","noncompliant","unknown","conflict"],"schema_id":"governed-execution.nwp-post-execution-source-effect-ceiling-profile.v1","support_profile_digest":"026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097","support_roles":[["attempt_fence",1],["effect_fence",2],["authority_observation",3],["standing_policy_matrix",4],["ceiling_profile",5]]}
{"c1_completeness_authority":false,"entry_fields":["kind_rank","membership_ref","membership_digest","value_schema_id","value_ref","value_digest","scope_binding_digest","relation_set_digest","admitted_at","admission_graph_digest"],"full_family_verification_per_entry":true,"initial_cursor":[0,"0"],"later_admission_after_commit":"does_not_rewrite_committed_closure","later_admission_before_commit":"forbidden_by_same_begin_immediate","malformed_duplicate_reordered_nonprogress":"basis_conflict_or_database_integrity","maximum_entries":65536,"order":["kind_rank","membership_ref"],"overflow":"no_decision_membership_closure_overflow","overflow_probe_entry":65537,"page_size":256,"profile_ref":"rw0-c-decision-membership-closure.v1","query_limit":257,"reader":"current_private_c1_membership_page","same_transaction_capability_epoch":true,"schema_id":"governed-execution.nwp-rw0-c-decision-membership-closure-profile.v1","strict_progress":true,"termination":"next_cursor_null_after_final_page"}
{"c1_inputs":["complete_membership_closure","selected_rank1_authority_membership","selected_rank15_section41_membership"],"capture":"one_begin_immediate_one_capability_epoch_one_controller_timestamp","excluded_state":"all_rows_not_consumed_by_currentness_authority_stop_or_ceiling_relations","malformed_or_cross_row_mismatch":"basis_conflict_or_database_integrity","missing_optional_resupplied_source":"no_decision","missing_required_sqlite_or_c1_family":"basis_conflict_or_database_integrity","mutable_head_advancement_before_commit":"current_state_conflict_requires_recapture","post_commit_advancement":"does_not_rewrite_committed_snapshot","profile_ref":"rw0-c-decision-current-snapshot.v1","resupplied_owner_sources":["validation_source","review_source","standing_policy_source","risk_source_profile_and_binding"],"schema_id":"governed-execution.nwp-rw0-c-decision-current-snapshot-profile.v1","sqlite_owner_rows":["development_program_heads","development_program_versions","development_accepted_intent_revisions","development_work_item_heads","development_work_item_revisions","development_pre_execution_selection_heads","development_effect_heads","development_delivery_heads","rw0_phase_instances","global_stop_current","development_attempt_fences","development_effect_fences"]}
{"aggregate_precedence":[["validation_conflict","conflict"],["review_conflict","conflict"],["policy_conflict","conflict"],["risk_conflict","conflict"],["validation_stale","stale"],["review_stale","stale"],["policy_stale","stale"],["risk_stale","stale"],["validation_unknown","unknown"],["review_unknown","unknown"],["policy_unknown","unknown"],["risk_unknown","unknown"],["otherwise","current"]],"component_table":[["same_ref_same_digest_and_fresh","current"],["same_ref_different_digest","conflict"],["different_well_formed_pair","stale"],["exact_value_expired_at_capture","stale"],["source_unavailable","unknown"],["malformed_or_wrong_profile","conflict"]],"components":["validation","review","policy","risk"],"outer_mapping":{"conflict":"basis_conflict","current":"continue","stale":"no_decision","unknown":"no_decision"},"profile_ref":"rw0-c-proposal-evidence-currentness.v1","schema_id":"governed-execution.nwp-rw0-c-proposal-evidence-currentness-profile.v1"}
{"branches":[{"applicability":"governed","branch":"candidate_acceptance","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"candidate_repair","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"attempt_selecting_replan","governed_effect_class":"author_candidate"},{"applicability":"halt_only","branch":"program_terminal_reject","governed_effect_class":null},{"applicability":"halt_only","branch":"post_execution_program_block","governed_effect_class":null}],"permit_is_executable_authority":false,"precedence":[["snapshot_or_phase_mismatch","conflict"],["parent_or_fence_identity_mismatch","conflict"],["profile_mismatch","conflict"],["support_conflict","conflict"],["halt_only","permit","halt_only_authority_not_applicable"],["authority_denied","deny"],["authority_revoked","deny"],["attempt_fence_expired","deny"],["effect_fence_expired","deny"],["authority_grant_expired","deny"],["authority_observation_expired","deny"],["effect_class_not_allowed","deny"],["authority_status_unknown","unknown"],["family_status_unknown","unknown"],["revocation_status_unknown","unknown"],["otherwise","permit","authority_verified_current"]],"profile_ref":"rw0-c-decision-time-authority-branch.v1","results":["permit","deny","unknown","conflict"],"schema_id":"governed-execution.nwp-rw0-c-decision-time-authority-branch-profile.v1"}
{"branches":[{"applicability":"governed","branch":"candidate_acceptance","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"candidate_repair","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"attempt_selecting_replan","governed_effect_class":"author_candidate"},{"applicability":"halt_only","branch":"program_terminal_reject","governed_effect_class":null},{"applicability":"halt_only","branch":"post_execution_program_block","governed_effect_class":null}],"permit_is_future_effect_authority":false,"precedence":[["snapshot_lineage_or_fence_mismatch","conflict"],["proposal_evidence_conflict","conflict"],["profile_mismatch","conflict"],["support_conflict","conflict"],["halt_only","permit","halt_only_ceiling_not_applicable"],["proposal_evidence_noncompliant","deny"],["attempt_fence_expired","deny"],["effect_fence_expired","deny"],["authority_grant_expired","deny"],["authority_observation_expired","deny"],["effect_class_not_allowed","deny"],["source_effect_exceeds_current_attempt","deny"],["source_effect_exceeds_current_effect","deny"],["source_effect_exceeds_current_authority","deny"],["proposal_evidence_unknown","unknown"],["current_authority_unknown","unknown"],["otherwise","permit","source_effect_within_current_ceilings"]],"profile_ref":"rw0-c-decision-time-source-effect-ceiling-branch.v1","proposal_profile_digest":"950bf044d7d7c7fc7721e732f748d97213413afe501d0ac3d71f726d06a340a0","proposal_profile_ref":"post-execution-source-effect-ceiling.v1","results":["permit","deny","unknown","conflict"],"schema_id":"governed-execution.nwp-rw0-c-decision-time-source-effect-ceiling-branch-profile.v1"}
{"branch_authority":false,"mapping":{"accept_candidate":"candidate_acceptance","block":"post_execution_program_block","repair_candidate":"candidate_repair","replan":"attempt_selecting_replan","terminal_reject":"program_terminal_reject"},"precedence":[["identity_or_provenance_mismatch","basis_conflict"],["proposal_or_snapshot_not_current","stale_context"],["mapped_branch_equals_authoritative_branch","consistent"],["otherwise","inconsistent"]],"preconditions":["authoritative_branch_already_derived_without_model_recommendation","proposal_currentness_current","all_input_identities_exact"],"profile_ref":"rw0-c-recommendation-consistency.v1","results":["consistent","inconsistent","stale_context","basis_conflict"],"schema_id":"governed-execution.nwp-rw0-c-recommendation-consistency-profile.v1"}
```

# Snapshot owner-locator matrix

| Classification | Component | Reconstructible owner source and key | Reader/query ID | Cardinality, verification, currentness, and failure |
|---|---|---|---|---|
| current merged implementation | Program head | `development_program_heads(program_ref)` | `program_head` | `LIMIT 2`; zero/two is required-state integrity failure; one reconstructs and verifies `head_digest`. Current version coordinates must match the version row and phase lineage. |
| current merged implementation | Program version | `development_program_versions(program_ref, program_version_ref, program_version_number)` | `current_program_version` | Same bounded cardinality; verifies `program_version_digest`; must equal head and lineage. |
| current merged implementation | Accepted intent | `development_accepted_intent_revisions(program_ref, accepted_intent_revision_ref)` | `accepted_intent_revision` | Same bounded cardinality; verifies `accepted_intent_revision_digest`; must equal version/work/phase lineage. |
| current merged implementation | Work head | `development_work_item_heads(program_ref, work_item_ref)` | `work_item_head` | Same bounded cardinality; verifies `head_digest`; current revision pair must match work revision and phase. |
| current merged implementation | Work revision | `development_work_item_revisions(program_ref, work_item_ref, work_item_revision_ref)` | `work_item_revision` | Same bounded cardinality; verifies `work_item_revision_digest`; must match accepted intent and phase. |
| current merged implementation | Selection head | `development_pre_execution_selection_heads` keyed by the exact K8 | Current helper `_read_selection_head`; proposed immutable snapshot query ID `rw0_c_snapshot_selection_head_v1` | Zero/two/malformed is integrity failure; one verifies `head_digest`; K8 and all L34 fields must equal phase/lineage. |
| current merged implementation | Effect head | `development_effect_heads(program_ref,effect_intent_ref)` | `effect_head` | Bounded cardinality; verifies `head_digest`; current fence, revision, state, cancellation ref, and timestamp are captured. |
| current merged implementation | Delivery head | `development_delivery_heads(program_ref,effect_intent_ref)` | `delivery_head` | Bounded cardinality; verifies `head_digest`; current delivery attempt, revision, state, and timestamp are captured. |
| current merged implementation | C1 phase | `rw0_phase_instances(phase_basis_ref,phase_basis_digest)` and exact K8 alternative | `rw0_c1_phase_by_pair`, `rw0_c1_phase_by_k8` | Exactly one coherent row; verifies `phase_row_digest`, `phase_graph_digest`, `relation_set_digest`, L34, K8, and current-head preimages. |
| current merged implementation | Attempt fence | `development_attempt_fences(program_ref,attempt_fence_ref)` | `attempt_fence` | Bounded cardinality; reconstructs `DevelopmentAttemptFenceRowValue` and recomputes `attempt_fence_digest`; must equal phase/T1. |
| current merged implementation | Effect fence | `development_effect_fences(program_ref,effect_intent_ref)` | `current_effect_fence` | Bounded cardinality; reconstructs `DevelopmentEffectFenceRowValue` and recomputes `effect_fence_digest`; must equal phase/T1 and effect head. |
| current merged implementation | Rank-1 authority observation | C1 membership, typed rank-1 row, relation family, and child effect classes | `rw0_c1_membership_by_ref`, `rw0_c1_typed_value_rank_1`, `rw0_c1_relations_for_membership`, `rw0_c1_operands_for_relation`, `rw0_c1_authority_effect_classes` | Membership and typed value must each be unique and self-valid; relation/operand/effect-class counts must equal their stored counts/set digests. Missing selected authority is `no_decision`; malformed family is `basis_conflict` or database integrity failure. |
| current owning contract | Parent grant/family support | `parent_grant_ref/digest` and `grant_family_ref/digest` in the exact rank-1 typed row; owner locators in its verified relation operands | Same rank-1 relation/operand readers | Coordinator owns the immutable C1 evidence binding, not external grant custody. Exact resupply/reconstruction is required; unresolved owner locator is `no_decision`, contradiction is `basis_conflict`. |
| current merged implementation | Global stop | `global_stop_current(singleton_id=1)` | `global_stop_current` | Columns reconstruct `GlobalStopState`; table has no self-digest, so its canonical digest is recomputed. Missing/duplicate/malformed is `basis_conflict`. |
| current merged implementation | Selected rank-15 membership | C1 membership plus typed rank-15 wrapper and Section 41 owner family | `rw0_c1_membership_by_ref`, `rw0_c1_typed_value_rank_15`, `rw0_c1_relations_for_membership`, `rw0_c1_operands_for_relation`, `rw0_c1_section41_post_execution_evidence_family` | Missing selected rank15 is `no_decision`; one exact wrapper must match proposal/source/artifact/evidence graph; counts other than zero/nine fail. |
| proposed RW0-C decision-input contract | Validation current source | Immutable supplied source keyed by `(validation, source_binding_schema_id, source_binding_ref)` | `post_validation_current_source_v1` | Zero means unavailable/unknown and outer `no_decision`; one exact value yields V28; more than one, wrong profile, or substitution is `basis_conflict`. |
| proposed RW0-C decision-input contract | Review current source | Keyed by `(review, source_binding_schema_id, source_binding_ref)` | `post_review_current_source_v1` | Same behavior. |
| proposed RW0-C decision-input contract | Policy current source | Keyed by `(policy, source_binding_schema_id, source_binding_ref)` | `post_standing_policy_current_source_v1` | Same behavior. |
| proposed RW0-C decision-input contract | Risk current source | Keyed by `(risk, source_binding_schema_id, source_binding_ref)` | `post_risk_current_source_v1` | Same behavior. Coordinator does not claim physical custody. |

[current merged implementation] Exact development-row column inventories are:

```text
program_head:
schema_id, program_ref, current_program_version_ref,
current_program_version_number, head_revision, program_state,
updated_at, head_digest

program_version:
schema_id, program_version_ref, program_ref, program_version_number,
program_version_kind, creating_decision_ref, accepted_intent_revision_ref,
created_at, program_version_digest

accepted_intent:
schema_id, accepted_intent_revision_ref, program_ref,
accepted_intent_revision_number, prior_accepted_intent_revision_ref,
source_intent_ref, source_intent_digest, safe_projection_digest,
created_at, accepted_intent_revision_digest

work_head:
schema_id, work_item_ref, program_ref, current_work_item_revision_ref,
current_work_item_revision_number, head_revision, work_state,
updated_at, head_digest

work_revision:
schema_id, work_item_revision_ref, program_ref, work_item_ref,
work_item_revision_number, work_item_revision_kind,
prior_work_item_revision_ref, accepted_intent_revision_ref,
created_at, work_item_revision_digest

selection_head:
schema_id, program_ref, program_version_ref,
accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
semantic_attempt_ref, candidate_ref, effect_intent_ref, author_command_ref,
author_command_digest, attempt_fence_ref, attempt_fence_digest,
effect_fence_ref, effect_fence_digest, delivery_attempt_ref,
delivery_envelope_digest, current_proposal_ref, current_disposition_ref,
current_disposition, head_revision, updated_at, program_version_number,
semantic_attempt_digest, attempt_number, basis_decision_ref,
basis_decision_digest, work_spec_ref, work_spec_digest,
work_spec_safe_projection_digest, effect_intent_digest,
standing_grant_ref, standing_grant_digest, attempt_authorization_ref,
attempt_authorization_digest, effect_authorization_ref,
effect_authorization_digest, delivery_attempt_digest,
authority_evaluation_ref, authority_evaluation_digest, head_digest

effect_head:
schema_id, effect_intent_ref, program_ref, current_effect_fence_ref,
head_revision, effect_state, cancellation_effect_intent_ref,
updated_at, head_digest

delivery_head:
schema_id, effect_intent_ref, program_ref, current_delivery_attempt_ref,
head_revision, delivery_state, updated_at, head_digest
```

[current merged implementation] Exact fence and authority column inventories are:

```text
attempt_fence:
schema_id, attempt_fence_ref, parent_standing_grant_ref,
parent_standing_grant_digest, attempt_authorization_ref,
attempt_authorization_digest, program_ref, program_version_ref,
accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
semantic_attempt_ref, repository_ref, base_git_object_format, base_git_oid,
path_ceiling_json, allowed_effect_class_mask,
aggregate_max_active_invocations, aggregate_max_candidate_bytes,
aggregate_max_changed_files, aggregate_max_cost_microusd,
aggregate_max_cpu_seconds, aggregate_max_deliveries,
aggregate_max_deployments, aggregate_max_local_commits,
aggregate_max_memory_bytes, aggregate_max_merges,
aggregate_max_model_input_tokens, aggregate_max_model_output_tokens,
aggregate_max_pull_requests, aggregate_max_pushes,
aggregate_max_wall_seconds, expires_at, global_stop_ref,
global_stop_version, attempt_fence_digest, recorded_at

effect_fence:
schema_id, effect_fence_ref, parent_standing_grant_ref,
parent_standing_grant_digest, effect_authorization_ref,
effect_authorization_digest, attempt_fence_ref, attempt_fence_digest,
program_ref, program_version_ref, accepted_intent_revision_ref,
work_item_ref, work_item_revision_ref, semantic_attempt_ref,
effect_intent_ref, effect_class, command_ref, command_digest,
candidate_ref, repository_ref, base_git_object_format, base_git_oid,
path_ceiling_json, effect_max_active_invocations,
effect_max_candidate_bytes, effect_max_changed_files,
effect_max_cost_microusd, effect_max_cpu_seconds, effect_max_deliveries,
effect_max_deployments, effect_max_local_commits,
effect_max_memory_bytes, effect_max_merges,
effect_max_model_input_tokens, effect_max_model_output_tokens,
effect_max_pull_requests, effect_max_pushes, effect_max_wall_seconds,
expires_at, global_stop_ref, global_stop_version, portable_capsule_digest,
cancellation_target_effect_intent_ref,
cancellation_target_effect_fence_ref,
cancellation_target_effect_fence_digest, effect_fence_digest, recorded_at

rank1 authority:
schema_id, kind_rank, value_ref, value_digest, value_schema_id,
source_ref, evidence_ref, evidence_digest, phase_basis_ref,
phase_basis_digest, parent_grant_ref, parent_grant_digest,
grant_family_ref, grant_family_digest, attempt_basis_ref,
attempt_basis_digest, effect_basis_ref, effect_basis_digest,
attempt_fence_ref, attempt_fence_digest, effect_fence_ref,
effect_fence_digest, audience_ref, repository_ref, base_git_object_format,
base_git_oid, path_scope_digest, allowed_effect_class_count,
the 15 ceiling fields, effect_class, status, family_status,
revocation_status, grant_expires_at, observed_at,
observation_expires_at, current_effect_head_digest,
current_delivery_head_digest, global_stop_ref, global_stop_version,
global_stop_state, payload_row_digest

global_stop_current:
singleton_id, schema_id, version, active, stop_id, reason_class,
issuer_ref, issued_at, operator_decision_ref, updated_at
```

[current merged implementation] Exact C1 phase and membership core inventories are:

```text
membership:
schema_id, membership_ref, membership_digest, phase_basis_ref,
phase_basis_digest, kind_rank, value_ref, value_digest, value_schema_id,
scope_binding_digest, relation_set_digest, admitted_by_mutation_ref,
admitted_at, admission_graph_digest

rank15 wrapper:
schema_id, kind_rank, value_ref, value_digest, value_schema_id,
phase_basis_ref, phase_basis_digest, source_invocation_ref,
source_invocation_digest, artifact_ref, artifact_digest,
artifact_binding_digest, proposal_ref, proposal_digest,
model_contract_ref, model_contract_digest, model_configuration_ref,
model_configuration_digest, context_schema_id, context_ref, context_digest,
safe_projection_schema_id, safe_projection_digest, evidence_set_ref,
evidence_set_digest, evidence_binding_count, recommendation, reason_code,
proposal_created_at, owner_family_graph_digest, payload_row_digest

relation:
schema_id, phase_basis_ref, phase_basis_digest, relation_ref,
relation_digest, subject_type, subject_membership_ref,
subject_membership_digest, subject_kind_rank, subject_value_ref,
subject_value_digest, subject_value_schema_id, relation_rank,
relation_schema_id, relation_version, proof_mode, profile_ref,
profile_digest, evaluated_at, operand_count, operand_set_digest,
relation_row_digest

operand:
schema_id, phase_basis_ref, relation_ref, relation_digest,
operand_ordinal, operand_role, operand_source,
source_membership_ref, source_membership_digest, source_kind_rank,
owner_role, owner_locator_ref, owner_locator_revision,
owner_locator_subrole, owner_locator_ordinal, transient_binding_kind,
transient_error_reason, snapshot_binding_kind, operand_schema_id,
operand_ref, operand_digest, operand_scope_digest, operand_row_digest
```

# T1/Section41/resupply equality matrix

| Classification | Role | Exact equality chain | Profile/source/C1 posture | Model/privacy/future posture |
|---|---|---|---|---|
| proposed post-execution evidence owner contract | Candidate | V03 typed triple = V08 typed triple = V11 typed triple = Section 41 row role/ref/digest = V24 typed triple. V06 retains the same typed triple but its model triple is V04. | No source profile/binding; no direct C1. Phase and lineage come from V02/V05/V07/V22. | Full manifest exists only in transient V11; model receives V04; future retention is V04 only. |
| proposed post-execution evidence owner contract | Worker result | T1, supply, model projection, Section 41 row, and V24 all use schema `governed-execution.nwp-rw0-c1-wire-process-result-classification-binding.v1` and one exact ref/digest. | Profile `rw0-wire-nwpf-v1` / `470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454`; exact classifier-relation triple; rank14 membership pair required. | Nonprivate exact value; future retains full safe C1 value and membership locator. |
| proposed post-execution evidence owner contract | Validation | Same schema/ref/digest through all stages. | Profile `validation-disposition.v1` / `a53ccecbfa11c0a593536e8eda8ed59bec59f7e145a70cd04599913bf1e72157`; source-observation triple; no direct C1. | Nonprivate; exact resupply; future full safe value. |
| proposed post-execution evidence owner contract | Review | Same schema/ref/digest through all stages. | Profile `independent-review-disposition.v1` / `ffdeb616c6beba4494bf08120f73a95adebbe724d78425cc7b6403a7c2394bbf`; source-observation triple; no direct C1. | Nonprivate; exact resupply; future full safe value. |
| proposed post-execution evidence owner contract | Policy | Same schema/ref/digest through all stages. | Profile `post-execution-standing-policy-matrix.v1` / `c6e4ea9c56f45150d15ded0dca48f68fb15be0fa7f0b444e72f06a0137a1c9e8`; policy-source triple; no direct C1. | Nonprivate; exact resupply; future full safe value. |
| compatibility edge | Risk | Same generic matrix schema/ref/digest through all stages; the source binding is V19. | Source profile `finite_backlog_risk_source.v1` / `1dace7cff29db22842b948482aeafb4f8a5b43fb7695a867901e49e2d22b7eac`; V19 triple; no direct C1. | Generic matrix contains no FiniteBacklog-specific fields; future retains the full safe matrix and binding. |
| proposed post-execution evidence owner contract | Authority | Same rank1 schema/ref/digest through all stages. | No separate source profile/binding; exact rank1 membership pair and verified C1 family required. | Nonprivate; future retains full safe typed value plus rank1 locator. |
| proposed post-execution evidence owner contract | Global stop | Same V20 schema/ref/digest through all stages. | Profile `post-execution-global-stop.v1` / `2d76a6933c708473707fb1398e98ee76c8e7092436ffbf544cb54d2ad2b26ff2`; exact global-stop-state triple; no direct C1. | Proposal snapshot is immutable; decision rereads singleton; future retains full safe V20 and V32. |
| proposed post-execution evidence owner contract | Effect ceiling | Same V21 schema/ref/digest through all stages. | Profile `post-execution-source-effect-ceiling.v1` / `950bf044d7d7c7fc7721e732f748d97213413afe501d0ac3d71f726d06a340a0`; exact effect-fence triple; no direct C1. | Nonprivate, branch-neutral, not future permission; future retains V21 and V33. |

[proposed Section 41 role-resolution contract] Section 41 rows do not store `typed_schema_id`; the schema is recovered from the closed role/rank profile, then the exact canonical supplied value must reconstruct the stored ref/digest. Digest equality alone is insufficient.

[proposed post-execution evidence owner contract] V09 succeeds only when the input-context and lineage triples, all nine typed identities, model/private identities, source/proposal context triples, artifact identities, and evidence-set identity are exact.

# Pure-owner implementation boundary versus future forecast

[implementation-detail observation] The migration-free pure-owner tranche is decomposed as:

```text
_post_execution_evidence_values.py
    V01–V15 and V20–V21

_post_execution_policy_values.py
    V16–V18

_finite_backlog_risk_source_adapter.py
    V19; imports the generic risk protocol, never the reverse

_section41_post_execution_proposal_family_projection.py
    V22–V23

_section41_post_execution_role_resolution.py
    V24; imports evidence and policy values

_rw0_c_decision_input_values.py
    V25–V34
```

[proposed post-execution evidence owner contract] Values V01–V24 are ready for a migration-free pure-owner tranche, subject to independent audit. They add no I/O, database reader, mutation, model call, custody mechanism, or runtime behavior.

[proposed RW0-C decision-input contract] Values V25–V34 are complete pure decision-input contracts. They remain non-authoritative inputs/evaluations and do not implement the RW0-C decision write.

[proposed future committed-recovery contract] V35–V37 remain forecast-only until the aggregate authoritative branch evaluator, its exact result value, and the neutral C2B authorization basis are separately frozen.

[proposed future committed-recovery contract] Current required recovery concepts are:

```text
phase pair
complete membership closure
T1 and lineage identities
model-input binding
selected rank15 membership and closure entry
safe Section 41 family projection and exact durable locators
nine role-resolution values
candidate safe projection
worker and authority safe C1 values plus membership locators
validation/review/policy/risk/stop/ceiling safe values
current snapshot
currentness and decision-time matrices
recommendation consistency
```

[proposed future committed-recovery contract] Reserved future fields are:

```text
authoritative branch evaluation
neutral C2B authorization basis
decision/result/receipt identities
commit timestamp
recovery selector/readback identity
```

[proposed future committed-recovery contract] Prohibited now are source implementation or persistence of V35–V37, migration-0005 rows, branch truth, neutral-basis values, decision receipts, result values, recovery selectors, commit recovery, and any digest-only substitute for required safe values/locators.

[proposed future committed-recovery contract] A future committed decision must retain complete safe values or immutable typed locators. Opaque aggregate digests alone are insufficient.

# Finite assurance matrix

| ID | Classification | Test or independent mutant | Required outcome |
|---|---|---|---|
| A01 | proposed post-execution evidence owner contract | Source invocation context pair substituted | `basis_conflict` |
| A02 | proposed Section 41 role-resolution contract | One T1 role differs from its Section 41 row | `basis_conflict` |
| A03 | proposed post-execution evidence owner contract | Different canonical bytes under a claimed ref/digest | self-identity failure |
| A04 | proposed post-execution evidence owner contract | Complete proposal-time input unavailable before invocation | invocation prohibited; `no_decision` |
| A05 | proposed post-execution evidence owner contract | Exact resupply absent after proposal | `no_decision` |
| A06 | proposed post-execution evidence owner contract | Candidate manifest absent at decision time | `no_decision` |
| A07 | proposed post-execution evidence owner contract | Candidate schema/ref/digest/bytes/phase substituted | `basis_conflict` |
| A08 | proposed post-execution evidence owner contract | Input profile version/digest substituted | `basis_conflict` |
| A09 | proposed post-execution evidence owner contract | Stale evaluator profile | `basis_conflict` |
| A10 | proposed post-execution evidence owner contract | Support omitted, reordered, duplicated, or substituted | support rejection |
| A11 | proposed Section 41 role-resolution contract | Restart with exact resupply | identical nine relation identities |
| A12 | proposed Section 41 role-resolution contract | Composite evidence locator changed with valid-looking digest | `basis_conflict` |
| A13 | proposed RW0-C decision-input contract | Membership paging terminates early | `basis_conflict` |
| A14 | proposed RW0-C decision-input contract | Paging cursor fails to advance | `basis_conflict` |
| A15 | proposed RW0-C decision-input contract | Membership page duplicates/reorders an entry | `basis_conflict` |
| A16 | proposed RW0-C decision-input contract | Entry 65,537 exists | `no_decision/membership_closure_overflow` |
| A17 | proposed RW0-C decision-input contract | Snapshot omits/substitutes a consumed coordinate | `basis_conflict` |
| A18 | proposed post-execution evidence owner contract | Two of the four ceiling expiries collapse | schema/profile failure |
| A19 | proposed post-execution evidence owner contract | Invalid validation/review tuple | tuple rejection |
| A20 | proposed post-execution evidence owner contract | Multiple adverse supports | first frozen precedence reason |
| A21 | proposed future committed-recovery contract | Required typed recovery locator absent | recovery family invalid |
| A22 | proposed future committed-recovery contract | Mutable heads advance after commit | recover original retained result |
| A23 | current owning contract | Closure treated as C1 completeness authority | owner-boundary failure |
| A24 | current merged implementation | Evidence child inserted before proposal parent | immediate-FK failure |
| A25 | proposed post-execution evidence owner contract | Rank15 membership claimed at T1 | input-profile failure |
| A26 | proposed post-execution evidence owner contract | Capsule entries/path/body placed in durable value | privacy-boundary failure |
| A27 | compatibility edge | Generic risk module imports FiniteBacklog adapter | import-boundary failure |
| A28 | proposed RW0-C decision-input contract | Model recommendation influences branch derivation | provenance failure |
| A29 | proposed RW0-C decision-input contract | Same stop version changes ref/state/digest/time | `basis_conflict` |
| A30 | proposed RW0-C decision-input contract | Lower stop version | `basis_conflict` |
| A31 | proposed RW0-C decision-input contract | Higher valid stop version | fresh state governs |
| A32 | proposed future committed-recovery contract | Postcommit recovery requests private supply | recovery-contract failure |
| A33 | current owning contract | Sixteenth C1 kind introduced | inventory failure |
| A34 | current owning contract | Migration/public API/controller/runtime surface changes | boundary/catalog failure |
| A35 | proposed RW0-C decision-input contract | C2B interprets individual evidence | owner-boundary failure |
| A36 | proposed post-execution evidence owner contract | Old L34 lineage object supplied as T1 input | schema/shape rejection |
| A37 | proposed Section 41 role-resolution contract | T1 object supplied as lineage context | schema/shape rejection |
| A38 | proposed post-execution evidence owner contract | Correct schema ID paired with an incompatible field shape | unknown/missing-field rejection before hashing |
| A39 | proposed Section 41 role-resolution contract | Stale context, projection, or profile digest | `basis_conflict` |
| A40 | proposed post-execution evidence owner contract | T1’s nested lineage triple substituted | `basis_conflict` |
| A41 | proposed post-execution evidence owner contract | Source and proposal repeat different T1 identities | `basis_conflict` |
| A42 | proposed post-execution evidence owner contract | Role-entry schema or nullable group substituted | input-profile rejection |
| A43 | proposed Section 41 role-resolution contract | Parent-only role/model/private/support entry treated as addressable | identity-grammar failure |
| A44 | proposed RW0-C decision-input contract | Value supplied under the wrong behavior profile | `basis_conflict` |
| A45 | proposed post-execution evidence owner contract | Literal schema identity omitted from registry/dispatch | schema-dispatch failure |
| A46 | proposed RW0-C decision-input contract | Snapshot component has unresolved owner locator | `no_decision` for optional external source; integrity failure for required SQLite/C1 state |
| A47 | proposed Section 41 role-resolution contract | Previous golden context/projection identity appears in a current profile/value | stale-identity failure |
| A48 | proposed future committed-recovery contract | Forecast-only command/member/manifest imported or persisted by pure tranche | import/catalog boundary failure |

[proposed post-execution evidence owner contract] Permanent tests are ordinary pure semantic, canonical-vector, import-boundary, and public/catalog-surface tests. They must not validate themselves by importing private expected constants from the implementation under test.

# Self-contained audit package

[implementation-detail observation] Reference-preimage reproductions are:

| Identity | Preimage bytes | Raw preimage SHA-256 | Domain-separated reference digest |
|---|---:|---|---|
| Lineage ref | 2,296 | `861285f7fef528f6452454a5b2f68e7418cf78a051c229c608f6b526b62185c0` | `3c1d06d996537cbe41dda41fa1739df2189a61e4e8635aa337507439abe90913` |
| Lineage self-digest preimage | 2,505 | `1190600ff45089103a2cdaabf97929f812ff19f3c64263c676729439beca576d` | `5dcf26f21b26e2dbca640ee52c2a7b9502a6e8cd5caa39266ec3ff6372ccb5e6` |
| T1 ref | 9,786 | `b93b91e505dd19bf32d07876283e24e326e378e5597a1ee982f0cf9debabed06` | `119a8daa273112a1f616e8c321a8a18384a71f14956a2cdd210b72cd18d508e7` |
| T1 self-digest preimage | 9,980 | `478a2aa17ac0ad19c50058a2103415c1fe101ed81e2480bf7e697bdb254ea96b` | `8d2cd3aa43ea55bfc2fe910cbea9eaff23994a713285340da0d852f4d340a7cc` |
| Projection V2 ref | 1,134 | `cf46e0c0023207b4701d09644d74b423495612219c21292bef9e414deb09ed4a` | `8afc2aa3ade73a60388f296523ae4f30cc65d3693dec2a9ab383dc34d5b42cb4` |
| Projection V2 self-digest preimage | 9,682 | `4d040db5092a181e56ec92d6c89d53e0b47478129d434f90ef42ae9d3b2f78e5` | `5c9631e31fb55950cb208664534ef7a807b76059d4b8c88d254a5b7fd5c35f9c` |

[proposed Section 41 role-resolution contract] Complete canonical golden lineage context:

```json
{"accepted_intent_revision_ref":"accepted-intent-golden.0001","attempt_authorization_digest":"0808080808080808080808080808080808080808080808080808080808080808","attempt_authorization_ref":"attempt-auth-golden.0001","attempt_fence_digest":"0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a","attempt_fence_ref":"attempt-fence-golden.0001","attempt_number":1,"author_command_digest":"0606060606060606060606060606060606060606060606060606060606060606","author_command_ref":"author-command-golden.0001","authority_evaluation_digest":"0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e","authority_evaluation_ref":"authority-evaluation-golden.0001","basis_decision_digest":"0202020202020202020202020202020202020202020202020202020202020202","basis_decision_ref":"decision-basis-golden.0001","candidate_ref":"candidate-golden.0001","delivery_attempt_digest":"0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d","delivery_attempt_ref":"delivery-attempt-golden.0001","delivery_envelope_digest":"0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c","effect_authorization_digest":"0909090909090909090909090909090909090909090909090909090909090909","effect_authorization_ref":"effect-auth-golden.0001","effect_fence_digest":"0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b","effect_fence_ref":"effect-fence-golden.0001","effect_intent_digest":"0505050505050505050505050505050505050505050505050505050505050505","effect_intent_ref":"effect-intent-golden.0001","lineage_context_digest":"5dcf26f21b26e2dbca640ee52c2a7b9502a6e8cd5caa39266ec3ff6372ccb5e6","lineage_context_ref":"section41-post-lineage.3c1d06d996537cbe41dda41fa1739df2189a61e4e8635aa337507439abe90913","program_ref":"program-golden.0001","program_version_number":1,"program_version_ref":"program-version-golden.0001","proposal_phase":"post_execution_semantic_review","schema_id":"governed-execution.nwp-section41-post-execution-semantic-review-lineage-context.v1","semantic_attempt_digest":"0101010101010101010101010101010101010101010101010101010101010101","semantic_attempt_ref":"semantic-attempt-golden.0001","standing_grant_digest":"0707070707070707070707070707070707070707070707070707070707070707","standing_grant_ref":"standing-grant-golden.0001","work_item_ref":"work-item-golden.0001","work_item_revision_ref":"work-item-revision-golden.0001","work_spec_digest":"0303030303030303030303030303030303030303030303030303030303030303","work_spec_ref":"work-spec-golden.0001","work_spec_safe_projection_digest":"0404040404040404040404040404040404040404040404040404040404040404"}
```

[proposed post-execution evidence owner contract] Complete canonical golden candidate safe projection:

```json
{"accepted_intent_revision_ref":"accepted-intent-golden.0001","attempt_fence_digest":"0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a","attempt_fence_ref":"attempt-fence-golden.0001","authorized_path_scope_digest":"2121212121212121212121212121212121212121212121212121212121212121","base_git_object_format":"sha1","base_git_oid":"3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a","candidate_ref":"candidate-golden.0001","capsule_manifest_ref":"candidate-capsule-golden.0001","command_digest":"0606060606060606060606060606060606060606060606060606060606060606","command_ref":"author-command-golden.0001","effect_fence_digest":"0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b","effect_fence_ref":"effect-fence-golden.0001","effect_intent_ref":"effect-intent-golden.0001","portable_capsule_digest":"2020202020202020202020202020202020202020202020202020202020202020","program_ref":"program-golden.0001","program_version_ref":"program-version-golden.0001","projection_digest":"9a5aee7c7fea034b1575ed4f0d245c310e7c98694f2d7a0cdee5ae78ae2cbb0a","projection_ref":"candidate-safe-projection.210584b61ab02117c803a71f509f8aeca57b0b92f34f5f7e39fc4297230d65a2","repository_ref":"repository-golden.0001","schema_id":"governed-execution.nwp-candidate-capsule-safe-projection.v1","semantic_attempt_ref":"semantic-attempt-golden.0001","work_item_ref":"work-item-golden.0001","work_item_revision_ref":"work-item-revision-golden.0001"}
```

[proposed post-execution evidence owner contract] Complete canonical golden model-input safe projection:

```json
{"entries":[{"model_input_posture":"private_exact_canonical_value","model_value_digest":"9a5aee7c7fea034b1575ed4f0d245c310e7c98694f2d7a0cdee5ae78ae2cbb0a","model_value_ref":"candidate-safe-projection.210584b61ab02117c803a71f509f8aeca57b0b92f34f5f7e39fc4297230d65a2","model_value_schema_id":"governed-execution.nwp-candidate-capsule-safe-projection.v1","ordinal":0,"role":"candidate_capsule","role_rank":5,"schema_id":"governed-execution.nwp-post-execution-model-input-projection-entry.v2","typed_schema_id":"governed-execution.nwp-candidate-capsule-manifest.v1","typed_value_digest":"1515151515151515151515151515151515151515151515151515151515151515","typed_value_ref":"candidate-capsule-golden.0001"},{"model_input_posture":"nonprivate_exact_canonical_value","model_value_digest":"1616161616161616161616161616161616161616161616161616161616161616","model_value_ref":"worker-result-golden.0001","model_value_schema_id":"governed-execution.nwp-rw0-c1-wire-process-result-classification-binding.v1","ordinal":0,"role":"worker_result","role_rank":6,"schema_id":"governed-execution.nwp-post-execution-model-input-projection-entry.v2","typed_schema_id":"governed-execution.nwp-rw0-c1-wire-process-result-classification-binding.v1","typed_value_digest":"1616161616161616161616161616161616161616161616161616161616161616","typed_value_ref":"worker-result-golden.0001"},{"model_input_posture":"nonprivate_exact_canonical_value","model_value_digest":"1717171717171717171717171717171717171717171717171717171717171717","model_value_ref":"validation-result-golden.0001","model_value_schema_id":"governed-execution.nwp-validation-disposition.v1","ordinal":0,"role":"validation_result","role_rank":7,"schema_id":"governed-execution.nwp-post-execution-model-input-projection-entry.v2","typed_schema_id":"governed-execution.nwp-validation-disposition.v1","typed_value_digest":"1717171717171717171717171717171717171717171717171717171717171717","typed_value_ref":"validation-result-golden.0001"},{"model_input_posture":"nonprivate_exact_canonical_value","model_value_digest":"1818181818181818181818181818181818181818181818181818181818181818","model_value_ref":"independent-review-golden.0001","model_value_schema_id":"governed-execution.nwp-independent-review-disposition.v1","ordinal":0,"role":"independent_review","role_rank":8,"schema_id":"governed-execution.nwp-post-execution-model-input-projection-entry.v2","typed_schema_id":"governed-execution.nwp-independent-review-disposition.v1","typed_value_digest":"1818181818181818181818181818181818181818181818181818181818181818","typed_value_ref":"independent-review-golden.0001"},{"model_input_posture":"nonprivate_exact_canonical_value","model_value_digest":"1919191919191919191919191919191919191919191919191919191919191919","model_value_ref":"standing-policy-golden.0001","model_value_schema_id":"governed-execution.nwp-post-execution-standing-policy-branch-matrix.v1","ordinal":0,"role":"standing_policy","role_rank":9,"schema_id":"governed-execution.nwp-post-execution-model-input-projection-entry.v2","typed_schema_id":"governed-execution.nwp-post-execution-standing-policy-branch-matrix.v1","typed_value_digest":"1919191919191919191919191919191919191919191919191919191919191919","typed_value_ref":"standing-policy-golden.0001"},{"model_input_posture":"nonprivate_exact_canonical_value","model_value_digest":"1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a","model_value_ref":"risk-lane-golden.0001","model_value_schema_id":"governed-execution.nwp-post-execution-risk-lane-branch-matrix.v1","ordinal":0,"role":"risk_lane","role_rank":10,"schema_id":"governed-execution.nwp-post-execution-model-input-projection-entry.v2","typed_schema_id":"governed-execution.nwp-post-execution-risk-lane-branch-matrix.v1","typed_value_digest":"1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a","typed_value_ref":"risk-lane-golden.0001"},{"model_input_posture":"nonprivate_exact_canonical_value","model_value_digest":"1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b","model_value_ref":"authority-currentness-attestation-golden.0001","model_value_schema_id":"governed-execution.nwp-rw0-authority-verification-observation.v1","ordinal":0,"role":"authority_currentness_attestation","role_rank":11,"schema_id":"governed-execution.nwp-post-execution-model-input-projection-entry.v2","typed_schema_id":"governed-execution.nwp-rw0-authority-verification-observation.v1","typed_value_digest":"1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b","typed_value_ref":"authority-currentness-attestation-golden.0001"},{"model_input_posture":"nonprivate_exact_canonical_value","model_value_digest":"1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c","model_value_ref":"global-stop-golden.0001","model_value_schema_id":"governed-execution.nwp-post-execution-global-stop-snapshot.v1","ordinal":0,"role":"global_stop","role_rank":12,"schema_id":"governed-execution.nwp-post-execution-model-input-projection-entry.v2","typed_schema_id":"governed-execution.nwp-post-execution-global-stop-snapshot.v1","typed_value_digest":"1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c","typed_value_ref":"global-stop-golden.0001"},{"model_input_posture":"nonprivate_exact_canonical_value","model_value_digest":"1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d","model_value_ref":"effect-ceiling-golden.0001","model_value_schema_id":"governed-execution.nwp-post-execution-source-effect-ceiling-evidence.v1","ordinal":0,"role":"effect_ceiling","role_rank":13,"schema_id":"governed-execution.nwp-post-execution-model-input-projection-entry.v2","typed_schema_id":"governed-execution.nwp-post-execution-source-effect-ceiling-evidence.v1","typed_value_digest":"1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d","typed_value_ref":"effect-ceiling-golden.0001"}],"entry_count":9,"lineage_context_digest":"5dcf26f21b26e2dbca640ee52c2a7b9502a6e8cd5caa39266ec3ff6372ccb5e6","lineage_context_ref":"section41-post-lineage.3c1d06d996537cbe41dda41fa1739df2189a61e4e8635aa337507439abe90913","lineage_context_schema_id":"governed-execution.nwp-section41-post-execution-semantic-review-lineage-context.v1","profile_digest":"c4346cf2e33382a030fb8e897601ea62494be986ccc6428780398eec10809819","profile_ref":"post-execution-semantic-review-input.v2","projection_digest":"f305c80d4bf862e14ea3746bd33d0421df812235c7a8e3eec95e91aecc52fda6","projection_ref":"post-model-input-projection-v2.3c417618a80d6efc9b1d5bbba00c06dd7f3741046453d2e8e33e8465d7ee7dfd","proposal_phase":"post_execution_semantic_review","schema_id":"governed-execution.nwp-post-execution-model-input-safe-projection.v2"}
```

[proposed post-execution evidence owner contract] Complete canonical golden private-input manifest:

```json
{"entries":[{"canonical_byte_length":4096,"ordinal":0,"privacy_classification":"private_candidate_capsule_manifest","role":"candidate_capsule","role_rank":5,"schema_id":"governed-execution.nwp-post-execution-private-input-manifest-entry.v2","typed_schema_id":"governed-execution.nwp-candidate-capsule-manifest.v1","typed_value_digest":"1515151515151515151515151515151515151515151515151515151515151515","typed_value_ref":"candidate-capsule-golden.0001"}],"entry_count":1,"lineage_context_digest":"5dcf26f21b26e2dbca640ee52c2a7b9502a6e8cd5caa39266ec3ff6372ccb5e6","lineage_context_ref":"section41-post-lineage.3c1d06d996537cbe41dda41fa1739df2189a61e4e8635aa337507439abe90913","lineage_context_schema_id":"governed-execution.nwp-section41-post-execution-semantic-review-lineage-context.v1","manifest_digest":"1db620d4ce5383a849197ae9bf0c3c0886bd2b6758fb67ee63eb6fec4b2d6f55","manifest_ref":"post-private-input-manifest-v2.7508ce4cef3fc772772a99098dc67ed9a6e2693474cddf45a5cca3f0d33712b0","profile_digest":"c4346cf2e33382a030fb8e897601ea62494be986ccc6428780398eec10809819","profile_ref":"post-execution-semantic-review-input.v2","proposal_phase":"post_execution_semantic_review","schema_id":"governed-execution.nwp-post-execution-private-input-manifest.v2"}
```

[proposed post-execution evidence owner contract] Complete canonical golden T1 input context:

```json
{"constructed_at":"2026-09-30T11:59:57Z","input_context_digest":"8d2cd3aa43ea55bfc2fe910cbea9eaff23994a713285340da0d852f4d340a7cc","input_context_ref":"post-semantic-input-context.119a8daa273112a1f616e8c321a8a18384a71f14956a2cdd210b72cd18d508e7","lineage_context_digest":"5dcf26f21b26e2dbca640ee52c2a7b9502a6e8cd5caa39266ec3ff6372ccb5e6","lineage_context_ref":"section41-post-lineage.3c1d06d996537cbe41dda41fa1739df2189a61e4e8635aa337507439abe90913","lineage_context_schema_id":"governed-execution.nwp-section41-post-execution-semantic-review-lineage-context.v1","model_input_safe_projection_digest":"f305c80d4bf862e14ea3746bd33d0421df812235c7a8e3eec95e91aecc52fda6","model_input_safe_projection_ref":"post-model-input-projection-v2.3c417618a80d6efc9b1d5bbba00c06dd7f3741046453d2e8e33e8465d7ee7dfd","model_input_safe_projection_schema_id":"governed-execution.nwp-post-execution-model-input-safe-projection.v2","phase_basis_digest":"2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a","phase_basis_ref":"rw0-phase-golden.0001","preassigned_proposal_ref":"post-proposal-golden.0001","private_input_manifest_digest":"1db620d4ce5383a849197ae9bf0c3c0886bd2b6758fb67ee63eb6fec4b2d6f55","private_input_manifest_ref":"post-private-input-manifest-v2.7508ce4cef3fc772772a99098dc67ed9a6e2693474cddf45a5cca3f0d33712b0","private_input_manifest_schema_id":"governed-execution.nwp-post-execution-private-input-manifest.v2","profile_digest":"c4346cf2e33382a030fb8e897601ea62494be986ccc6428780398eec10809819","profile_ref":"post-execution-semantic-review-input.v2","proposal_phase":"post_execution_semantic_review","role_entries":[{"direct_c1_kind":null,"direct_c1_kind_rank":null,"direct_c1_membership_digest":null,"direct_c1_membership_ref":null,"model_input_posture":"private_exact_canonical_value","ordinal":0,"role":"candidate_capsule","role_rank":5,"schema_id":"governed-execution.nwp-post-execution-semantic-review-role-entry.v2","source_binding_digest":null,"source_binding_ref":null,"source_binding_schema_id":null,"source_posture":"transient_private_resupply","source_profile_digest":null,"source_profile_ref":null,"typed_schema_id":"governed-execution.nwp-candidate-capsule-manifest.v1","typed_value_digest":"1515151515151515151515151515151515151515151515151515151515151515","typed_value_ref":"candidate-capsule-golden.0001"},{"direct_c1_kind":"wire_process_result_classification_binding","direct_c1_kind_rank":14,"direct_c1_membership_digest":"2222222222222222222222222222222222222222222222222222222222222222","direct_c1_membership_ref":"c1-worker-membership-golden.0001","model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"worker_result","role_rank":6,"schema_id":"governed-execution.nwp-post-execution-semantic-review-role-entry.v2","source_binding_digest":"2323232323232323232323232323232323232323232323232323232323232323","source_binding_ref":"worker-classification-relation-golden.0001","source_binding_schema_id":"governed-execution.nwp-rw0-c1-wire-process-result-classifier-relation.v1","source_posture":"c1_admitted_exact_value","source_profile_digest":"470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454","source_profile_ref":"rw0-wire-nwpf-v1","typed_schema_id":"governed-execution.nwp-rw0-c1-wire-process-result-classification-binding.v1","typed_value_digest":"1616161616161616161616161616161616161616161616161616161616161616","typed_value_ref":"worker-result-golden.0001"},{"direct_c1_kind":null,"direct_c1_kind_rank":null,"direct_c1_membership_digest":null,"direct_c1_membership_ref":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"validation_result","role_rank":7,"schema_id":"governed-execution.nwp-post-execution-semantic-review-role-entry.v2","source_binding_digest":"2424242424242424242424242424242424242424242424242424242424242424","source_binding_ref":"validation-observation-golden.0001","source_binding_schema_id":"governed-execution.nwp-validation-source-observation.v1","source_posture":"transient_owner_resupply","source_profile_digest":"a53ccecbfa11c0a593536e8eda8ed59bec59f7e145a70cd04599913bf1e72157","source_profile_ref":"validation-disposition.v1","typed_schema_id":"governed-execution.nwp-validation-disposition.v1","typed_value_digest":"1717171717171717171717171717171717171717171717171717171717171717","typed_value_ref":"validation-result-golden.0001"},{"direct_c1_kind":null,"direct_c1_kind_rank":null,"direct_c1_membership_digest":null,"direct_c1_membership_ref":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"independent_review","role_rank":8,"schema_id":"governed-execution.nwp-post-execution-semantic-review-role-entry.v2","source_binding_digest":"2525252525252525252525252525252525252525252525252525252525252525","source_binding_ref":"review-observation-golden.0001","source_binding_schema_id":"governed-execution.nwp-independent-review-source-observation.v1","source_posture":"transient_owner_resupply","source_profile_digest":"ffdeb616c6beba4494bf08120f73a95adebbe724d78425cc7b6403a7c2394bbf","source_profile_ref":"independent-review-disposition.v1","typed_schema_id":"governed-execution.nwp-independent-review-disposition.v1","typed_value_digest":"1818181818181818181818181818181818181818181818181818181818181818","typed_value_ref":"independent-review-golden.0001"},{"direct_c1_kind":null,"direct_c1_kind_rank":null,"direct_c1_membership_digest":null,"direct_c1_membership_ref":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"standing_policy","role_rank":9,"schema_id":"governed-execution.nwp-post-execution-semantic-review-role-entry.v2","source_binding_digest":"2626262626262626262626262626262626262626262626262626262626262626","source_binding_ref":"standing-policy-source-golden.0001","source_binding_schema_id":"governed-execution.nwp-standing-policy-source.v1","source_posture":"transient_owner_resupply","source_profile_digest":"c6e4ea9c56f45150d15ded0dca48f68fb15be0fa7f0b444e72f06a0137a1c9e8","source_profile_ref":"post-execution-standing-policy-matrix.v1","typed_schema_id":"governed-execution.nwp-post-execution-standing-policy-branch-matrix.v1","typed_value_digest":"1919191919191919191919191919191919191919191919191919191919191919","typed_value_ref":"standing-policy-golden.0001"},{"direct_c1_kind":null,"direct_c1_kind_rank":null,"direct_c1_membership_digest":null,"direct_c1_membership_ref":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"risk_lane","role_rank":10,"schema_id":"governed-execution.nwp-post-execution-semantic-review-role-entry.v2","source_binding_digest":"2727272727272727272727272727272727272727272727272727272727272727","source_binding_ref":"finite-backlog-risk-binding-golden.0001","source_binding_schema_id":"governed-execution.nwp-finite-backlog-risk-source-binding.v1","source_posture":"transient_owner_resupply","source_profile_digest":"1dace7cff29db22842b948482aeafb4f8a5b43fb7695a867901e49e2d22b7eac","source_profile_ref":"finite_backlog_risk_source.v1","typed_schema_id":"governed-execution.nwp-post-execution-risk-lane-branch-matrix.v1","typed_value_digest":"1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a","typed_value_ref":"risk-lane-golden.0001"},{"direct_c1_kind":"authority_verification_observation","direct_c1_kind_rank":1,"direct_c1_membership_digest":"2828282828282828282828282828282828282828282828282828282828282828","direct_c1_membership_ref":"c1-authority-membership-golden.0001","model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"authority_currentness_attestation","role_rank":11,"schema_id":"governed-execution.nwp-post-execution-semantic-review-role-entry.v2","source_binding_digest":null,"source_binding_ref":null,"source_binding_schema_id":null,"source_posture":"c1_admitted_exact_value","source_profile_digest":null,"source_profile_ref":null,"typed_schema_id":"governed-execution.nwp-rw0-authority-verification-observation.v1","typed_value_digest":"1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b","typed_value_ref":"authority-currentness-attestation-golden.0001"},{"direct_c1_kind":null,"direct_c1_kind_rank":null,"direct_c1_membership_digest":null,"direct_c1_membership_ref":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"global_stop","role_rank":12,"schema_id":"governed-execution.nwp-post-execution-semantic-review-role-entry.v2","source_binding_digest":"2929292929292929292929292929292929292929292929292929292929292929","source_binding_ref":"global-stop-state-golden.0001","source_binding_schema_id":"governed-execution.nwp-global-stop.v1","source_posture":"transient_owner_resupply","source_profile_digest":"2d76a6933c708473707fb1398e98ee76c8e7092436ffbf544cb54d2ad2b26ff2","source_profile_ref":"post-execution-global-stop.v1","typed_schema_id":"governed-execution.nwp-post-execution-global-stop-snapshot.v1","typed_value_digest":"1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c","typed_value_ref":"global-stop-golden.0001"},{"direct_c1_kind":null,"direct_c1_kind_rank":null,"direct_c1_membership_digest":null,"direct_c1_membership_ref":null,"model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"effect_ceiling","role_rank":13,"schema_id":"governed-execution.nwp-post-execution-semantic-review-role-entry.v2","source_binding_digest":"0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b","source_binding_ref":"effect-fence-golden.0001","source_binding_schema_id":"governed-execution.nwp-effect-fence.v1","source_posture":"transient_owner_resupply","source_profile_digest":"950bf044d7d7c7fc7721e732f748d97213413afe501d0ac3d71f726d06a340a0","source_profile_ref":"post-execution-source-effect-ceiling.v1","typed_schema_id":"governed-execution.nwp-post-execution-source-effect-ceiling-evidence.v1","typed_value_digest":"1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d","typed_value_ref":"effect-ceiling-golden.0001"}],"role_entry_count":9,"schema_id":"governed-execution.nwp-post-execution-semantic-review-context.v1"}
```

[proposed Section 41 role-resolution contract] Complete canonical golden Section 41 projection V2:

```json
{"artifact_binding_digest":"b4f3d836f3518d93bf5a7c715870f6eec874faf3469a2ae1cbf0e2f71c958d8b","artifact_digest":"1010101010101010101010101010101010101010101010101010101010101010","artifact_ref":"post-artifact-golden.0001","artifact_validated_at":"2026-09-30T11:59:59Z","evidence_binding_count":9,"evidence_bindings":[{"evidence_bound_at":"2026-09-30T12:00:00Z","evidence_digest":"1515151515151515151515151515151515151515151515151515151515151515","evidence_ref":"candidate-capsule-golden.0001","evidence_role":"candidate_capsule","evidence_set_ref":"post-evidence-set-golden.0001","ordinal":0,"projection_evidence_entry_digest":"8f5fc12b1d1e909b8cee51ce896cb2a7abb167e98e29c40b2dea901388828e77","proposal_phase":"post_execution_semantic_review","proposal_ref":"post-proposal-golden.0001","required_for_selection":1,"role_rank":5,"schema_id":"governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2","source_binding_digest":"dddda6cf8d0f37088c9c7547bad556f87e5bb83e06941cd33f102690a2d7e2c7","source_binding_schema_id":"governed-execution.nwp-model-proposal-evidence-binding.v1"},{"evidence_bound_at":"2026-09-30T12:00:00Z","evidence_digest":"1616161616161616161616161616161616161616161616161616161616161616","evidence_ref":"worker-result-golden.0001","evidence_role":"worker_result","evidence_set_ref":"post-evidence-set-golden.0001","ordinal":0,"projection_evidence_entry_digest":"054aef672da471b6941dcd88025777bb07348cfa0b4ee1cbb185544a0b2c221b","proposal_phase":"post_execution_semantic_review","proposal_ref":"post-proposal-golden.0001","required_for_selection":1,"role_rank":6,"schema_id":"governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2","source_binding_digest":"2bca1ea37ea522a1c14a5b218fa2688bb8ca9692d580e44d6fc01d3c67844825","source_binding_schema_id":"governed-execution.nwp-model-proposal-evidence-binding.v1"},{"evidence_bound_at":"2026-09-30T12:00:00Z","evidence_digest":"1717171717171717171717171717171717171717171717171717171717171717","evidence_ref":"validation-result-golden.0001","evidence_role":"validation_result","evidence_set_ref":"post-evidence-set-golden.0001","ordinal":0,"projection_evidence_entry_digest":"1c981046c7debda69bd39e8d589c44f0085d8693d2671d0f4ab0a8be06caf24d","proposal_phase":"post_execution_semantic_review","proposal_ref":"post-proposal-golden.0001","required_for_selection":1,"role_rank":7,"schema_id":"governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2","source_binding_digest":"582c7bb9e0fb727e4d104658be449a06fc26250aee517f5ffd1f7066cb0fbdb2","source_binding_schema_id":"governed-execution.nwp-model-proposal-evidence-binding.v1"},{"evidence_bound_at":"2026-09-30T12:00:00Z","evidence_digest":"1818181818181818181818181818181818181818181818181818181818181818","evidence_ref":"independent-review-golden.0001","evidence_role":"independent_review","evidence_set_ref":"post-evidence-set-golden.0001","ordinal":0,"projection_evidence_entry_digest":"76f6b376b79227dc8aafd38c20b1a5bb5f38cbb8f7359454d1f5e0d2584f8b89","proposal_phase":"post_execution_semantic_review","proposal_ref":"post-proposal-golden.0001","required_for_selection":1,"role_rank":8,"schema_id":"governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2","source_binding_digest":"aa158a14441d389f8bd4fcd4ffe788e4b5e84f135e2fe9c4a9ce9f0608222d86","source_binding_schema_id":"governed-execution.nwp-model-proposal-evidence-binding.v1"},{"evidence_bound_at":"2026-09-30T12:00:00Z","evidence_digest":"1919191919191919191919191919191919191919191919191919191919191919","evidence_ref":"standing-policy-golden.0001","evidence_role":"standing_policy","evidence_set_ref":"post-evidence-set-golden.0001","ordinal":0,"projection_evidence_entry_digest":"a0a3a57395063e3df410f8266b757eb2e66b1c28b48fe088a7d998a6a335adbe","proposal_phase":"post_execution_semantic_review","proposal_ref":"post-proposal-golden.0001","required_for_selection":1,"role_rank":9,"schema_id":"governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2","source_binding_digest":"03f652853c48bbfdb10e0e70c7f05d962ae04b23acaab5c148a9b77f1456bf4b","source_binding_schema_id":"governed-execution.nwp-model-proposal-evidence-binding.v1"},{"evidence_bound_at":"2026-09-30T12:00:00Z","evidence_digest":"1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a","evidence_ref":"risk-lane-golden.0001","evidence_role":"risk_lane","evidence_set_ref":"post-evidence-set-golden.0001","ordinal":0,"projection_evidence_entry_digest":"481403a2afe4536594656949e3b1f64fc0c8cb0df58fdeef3c574528a018f8e0","proposal_phase":"post_execution_semantic_review","proposal_ref":"post-proposal-golden.0001","required_for_selection":1,"role_rank":10,"schema_id":"governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2","source_binding_digest":"0eaad122123703bb215b0c5c5545d747190941524d4905979a164bc7cf53cc8d","source_binding_schema_id":"governed-execution.nwp-model-proposal-evidence-binding.v1"},{"evidence_bound_at":"2026-09-30T12:00:00Z","evidence_digest":"1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b","evidence_ref":"authority-currentness-attestation-golden.0001","evidence_role":"authority_currentness_attestation","evidence_set_ref":"post-evidence-set-golden.0001","ordinal":0,"projection_evidence_entry_digest":"c1a2ec4cd0ba2cf2752aaca00bd3a4aa2b3a23e1cb576db645c9b51e329c1304","proposal_phase":"post_execution_semantic_review","proposal_ref":"post-proposal-golden.0001","required_for_selection":1,"role_rank":11,"schema_id":"governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2","source_binding_digest":"34f37e2a6e202b62489f239305bad4df57a151cbb9e41c7854aafaf8255fb392","source_binding_schema_id":"governed-execution.nwp-model-proposal-evidence-binding.v1"},{"evidence_bound_at":"2026-09-30T12:00:00Z","evidence_digest":"1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c1c","evidence_ref":"global-stop-golden.0001","evidence_role":"global_stop","evidence_set_ref":"post-evidence-set-golden.0001","ordinal":0,"projection_evidence_entry_digest":"4717f77c310dd0836e516d26df7bb661a71c53c8ede8d3d965676e6a3333e46b","proposal_phase":"post_execution_semantic_review","proposal_ref":"post-proposal-golden.0001","required_for_selection":1,"role_rank":12,"schema_id":"governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2","source_binding_digest":"6e721190980c8b5c56574720f46decdb082eccfd23b59f3fd04e578b314fea75","source_binding_schema_id":"governed-execution.nwp-model-proposal-evidence-binding.v1"},{"evidence_bound_at":"2026-09-30T12:00:00Z","evidence_digest":"1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d1d","evidence_ref":"effect-ceiling-golden.0001","evidence_role":"effect_ceiling","evidence_set_ref":"post-evidence-set-golden.0001","ordinal":0,"projection_evidence_entry_digest":"58179b468c1c360a092b66b86ea9ef54e90329fbf1a0e1232be664498cb24459","proposal_phase":"post_execution_semantic_review","proposal_ref":"post-proposal-golden.0001","required_for_selection":1,"role_rank":13,"schema_id":"governed-execution.nwp-section41-post-execution-projection-evidence-entry.v2","source_binding_digest":"80c2588586bee7be0ee285dc60acfd78e15937222ca5fe5d2d150012749dd8dd","source_binding_schema_id":"governed-execution.nwp-model-proposal-evidence-binding.v1"}],"evidence_bound_at":"2026-09-30T12:00:00Z","evidence_set_digest":"59753e8360b4085c651f73745ce2267b9816c11269d2fd6e67fae1f317982d7a","evidence_set_ref":"post-evidence-set-golden.0001","input_context_digest":"8d2cd3aa43ea55bfc2fe910cbea9eaff23994a713285340da0d852f4d340a7cc","input_context_ref":"post-semantic-input-context.119a8daa273112a1f616e8c321a8a18384a71f14956a2cdd210b72cd18d508e7","input_context_schema_id":"governed-execution.nwp-post-execution-semantic-review-context.v1","lineage_context_digest":"5dcf26f21b26e2dbca640ee52c2a7b9502a6e8cd5caa39266ec3ff6372ccb5e6","lineage_context_ref":"section41-post-lineage.3c1d06d996537cbe41dda41fa1739df2189a61e4e8635aa337507439abe90913","lineage_context_schema_id":"governed-execution.nwp-section41-post-execution-semantic-review-lineage-context.v1","model_configuration_digest":"1414141414141414141414141414141414141414141414141414141414141414","model_configuration_ref":"model-config-golden.0001","model_contract_digest":"1313131313131313131313131313131313131313131313131313131313131313","model_contract_ref":"model-contract-golden.0001","owner_family_graph_digest":"f51f641cdcab3bee9122f4d767ce572f9e189983712cca4f8811aba5c16fe736","profile_digest":"c40867c7bf2519eb0f50f4cb21056b4b8b0aca6fb88162c03deb46e77f246cb0","profile_ref":"section41-post-execution-proposal-family-projection.v2","projection_digest":"5c9631e31fb55950cb208664534ef7a807b76059d4b8c88d254a5b7fd5c35f9c","projection_evaluated_at":"2026-09-30T12:00:00Z","projection_ref":"section41-post-projection-v2.8afc2aa3ade73a60388f296523ae4f30cc65d3693dec2a9ab383dc34d5b42cb4","proposal_created_at":"2026-09-30T12:00:00Z","proposal_digest":"d878c87b39f56f08438585c77bf98354f96630765ac345789356136e841b8b01","proposal_phase":"post_execution_semantic_review","proposal_ref":"post-proposal-golden.0001","reason_code":"review.accepted","recommendation":"accept_candidate","safe_projection_digest":"1212121212121212121212121212121212121212121212121212121212121212","safe_projection_schema_id":"governed-execution.nwp-post-execution-semantic-review-safe-projection.v1","schema_id":"governed-execution.nwp-section41-post-execution-proposal-family-projection.v2","source_invocation_completed_at":"2026-09-30T11:59:59Z","source_invocation_digest":"a147683ac73637d708ad9b5907ef880a9b265e993381b5fe5e79ce9fe4b7d7ce","source_invocation_ref":"source-invocation-post-golden.0001","source_invocation_started_at":"2026-09-30T11:59:58Z"}
```

[implementation-detail observation] The projection’s nine entry digests, in rank order 5–13, are:

```text
8f5fc12b1d1e909b8cee51ce896cb2a7abb167e98e29c40b2dea901388828e77
054aef672da471b6941dcd88025777bb07348cfa0b4ee1cbb185544a0b2c221b
1c981046c7debda69bd39e8d589c44f0085d8693d2671d0f4ab0a8be06caf24d
76f6b376b79227dc8aafd38c20b1a5bb5f38cbb8f7359454d1f5e0d2584f8b89
a0a3a57395063e3df410f8266b757eb2e66b1c28b48fe088a7d998a6a335adbe
481403a2afe4536594656949e3b1f64fc0c8cb0df58fdeef3c574528a018f8e0
c1a2ec4cd0ba2cf2752aaca00bd3a4aa2b3a23e1cb576db645c9b51e329c1304
4717f77c310dd0836e516d26df7bb661a71c53c8ede8d3d965676e6a3333e46b
58179b468c1c360a092b66b86ea9ef54e90329fbf1a0e1232be664498cb24459
```

[implementation-detail observation] No superseded context, profile, projection, source, proposal, owner-graph, attestation, neutral-basis, or rank-15 golden digest appears in any current canonical value above.

# Remaining seams and stop conditions

[report-only uncertainty] The aggregate authoritative branch truth table and its typed branch-evaluation value remain unfrozen.

[report-only uncertainty] The neutral C2B authorization basis, migration 0005, physical decision/result/receipt/recovery schema, atomic write plan, and commit-uncertainty readback remain unfrozen.

[report-only uncertainty] External validation, review, policy, and risk custody/transport remain unspecified. This report freezes supplied-value validation and reconstructible logical locators, not a physical retrieval service.

[report-only uncertainty] No replacement is asserted for the withdrawn post-execution authorization attestation or neutral progression basis.

[current owning contract] None of the stop conditions was triggered: no existing B1/B2/C1/C2A meaning changes; no migration-0003 or Section 41 row change; no sixteenth C1 kind; no durable private capsule contents; no C-owned external custody; no recommendation authority; no FiniteBacklog leakage into generic semantics; no migration/public/runtime work; no C2B interpretation of individual evidence; and no terminal, D/E, cancellation, publication, Git, or ES semantics.

# Recommended next step

[implementation-detail observation] Submit this fixed, self-contained reconciliation to independent contract audit. The next step is audit only; this report is neither an implementation allowlist nor an implementation prompt.

# Confidence

[report-only uncertainty] Confidence is high that the context collision, identity namespaces, dependent profile/golden regeneration, migration-0003 binding, Section 41 projection versioning, value-schema registry, snapshot locators, T1/Section41/resupply equality, privacy boundary, and pure-versus-forecast boundary are closed.

[report-only uncertainty] Confidence is intentionally withheld for the future aggregate branch evaluator, neutral C2B basis, migration-0005 physical design, decision write, receipt/recovery implementation, terminal behavior, D/E behavior, and ES integration.

RW0_POST_EXECUTION_CONTEXT_IDENTITIES_AND_VALUE_GRAMMARS_RECONCILED_READY_FOR_INDEPENDENT_AUDIT

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
```
