Here is Codex's response:

# Baseline and fixed audit input

| Classification | Result |
|---|---|
| current merged implementation | Branch `trunk_dev`; HEAD `a3ff0b7f4f0c2378c2962e24612d605489b51638`; tree `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0`; sole parent `047563de5a443b0f8323401c92979ae2e444d2ed`; subject `feat: implement RW0-C1 durable evidence (#7)`. |
| current merged implementation | Upstream `origin/trunk_dev`; ahead/behind `0/0`; exactly one worktree; worktree, index, untracked, and unmerged state clean. |
| implementation-detail observation | The baseline and final tree were checked locally without fetching. |
| implementation-detail observation | The fixed input was the immediately preceding audit report with verdict `BLOCK` and findings RW0-AUD-001 through RW0-AUD-010. No fixed-audit file was attached in this turn, so the conditional file-size/hash/line checks were inapplicable. |
| current owning contract | Primary anchors were [RW0-C1 durable evidence](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c1-durable-evidence.md:50>), [Section 41](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:22698>), [migration 0003](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0003_cognitive_proposal_and_selection_state.sql:1>), and the [RW0 phase-entry contract](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:358>). |

# Preserved decisions

[ current owning contract ] C1 remains a 15-kind presence, typed-membership, relation, replay, and recovery owner. It gains no completeness or decision authority.

[ proposed Section 41 role-resolution contract ] Section 41 continues to own the immutable post-execution proposal-family shape and model recommendation. A recommendation is evidence, not branch authority.

[ proposed post-execution evidence owner contract ] All nine proposal-time owner values must exist before model invocation. Validation and review remain owner-authored and are never inferred by RW0-C.

[ proposed post-execution evidence owner contract ] Policy and risk remain complete five-branch matrices. Proposal-time stop is immutable, while decision-time stop rereads the singleton.

[ proposed post-execution evidence owner contract ] Source-effect ceiling evidence remains proposal-time and branch-neutral.

[ compatibility edge ] FiniteBacklog remains behind an explicit generic risk-source binding and grants no target progression or execution authority.

[ proposed RW0-C decision-input contract ] RW0-C later owns exhaustive C1 membership closure, the current snapshot, fresh authority/stop/ceiling matrices, independent branch derivation, recommendation consistency, and future migration-0005 closure.

[ proposed RW0-C decision-input contract ] C2B later receives one neutral authorization basis and does not interpret individual evidence, policy bodies, model output, or private supply.

[ current owning contract ] B1/B2/C1/C2A meanings, migration-0002 decisions, Section 41 rows, migrations 0001–0004, current public APIs, and the single transaction controller remain unchanged.

[ proposed RW0-C decision-input contract ] Missing optional supply is `no_decision`. Malformed, substituted, contradictory, or corrupt required state is `basis_conflict` or database-integrity failure.

# T1 semantic-review input context

[ proposed post-execution evidence owner contract ] The final class name is `PostExecutionSemanticReviewInputContextV1`. Its schema must remain the migration-0003-compatible `governed-execution.nwp-post-execution-semantic-review-context.v1`.

[ proposed post-execution evidence owner contract ] Its exact ordered fields are:

```text
schema_id
context_ref
profile_ref
profile_digest
proposal_phase
preassigned_proposal_ref
program_ref
program_version_ref
accepted_intent_revision_ref
work_item_ref
work_item_revision_ref
semantic_attempt_ref
semantic_attempt_digest
attempt_number
candidate_ref
phase_basis_ref
phase_basis_digest
role_entry_count
role_entries
model_input_safe_projection_ref
model_input_safe_projection_digest
private_input_manifest_ref
private_input_manifest_digest
constructed_at
context_digest
```

`proposal_phase` is exactly `post_execution_semantic_review`; `role_entry_count` is exactly 9.

[ proposed post-execution evidence owner contract ] Each `PostExecutionSemanticReviewRoleEntryV1` has:

```text
role
role_rank
ordinal
typed_schema_id
typed_value_ref
typed_value_digest
source_posture
c1_kind
c1_kind_rank
c1_membership_ref
c1_membership_digest
source_profile_ref
source_profile_digest
source_binding_ref
source_binding_digest
model_input_posture
role_entry_digest
```

[ proposed post-execution evidence owner contract ] Nullability and direct provenance are exact:

| Role/rank | Direct C1 group | Source profile/binding | Input posture |
|---|---|---|---|
| `candidate_capsule` / 5 | all four C1 fields null | both pairs null | `private_exact_canonical_value` |
| `worker_result` / 6 | rank 14 `wire_process_result_classification_binding`; membership pair required | wire-profile and classification-relation pairs required | `nonprivate_exact_canonical_value` |
| `validation_result` / 7 | all null | disposition-profile and source-observation pairs required | `nonprivate_exact_canonical_value` |
| `independent_review` / 8 | all null | disposition-profile and source-observation pairs required | `nonprivate_exact_canonical_value` |
| `standing_policy` / 9 | all null | policy-profile and policy-source pairs required | `nonprivate_exact_canonical_value` |
| `risk_lane` / 10 | all null | generic risk-source-profile and source-binding pairs required | `nonprivate_exact_canonical_value` |
| `authority_currentness_attestation` / 11 | rank 1 `authority_verification_observation`; membership pair required | both pairs null | `nonprivate_exact_canonical_value` |
| `global_stop` / 12 | all null | stop-profile and global-stop-state pairs required | `nonprivate_exact_canonical_value` |
| `effect_ceiling` / 13 | all null | ceiling-profile and effect-fence pairs required | `nonprivate_exact_canonical_value` |

[ current owning contract ] The single C1 rank-15 Section 41 membership cannot exist at T1 because its value includes the not-yet-created proposal family.

[ proposed post-execution evidence owner contract ] Consequently, T1 entries bind only direct source C1 provenance where it already exists: ranks 14 and 1. The later rank-15 membership is an operand of role resolution, not a fabricated T1 field. This closes the temporal cycle without changing C1.

# Model-input and Section 41 equality relation

[ proposed post-execution evidence owner contract ] `CandidateCapsuleSafeProjectionV1` has:

```text
schema_id
projection_ref
candidate_ref
capsule_manifest_ref
portable_capsule_digest
program_ref
program_version_ref
accepted_intent_revision_ref
work_item_ref
work_item_revision_ref
semantic_attempt_ref
effect_intent_ref
command_ref
command_digest
attempt_fence_ref
attempt_fence_digest
effect_fence_ref
effect_fence_digest
repository_ref
base_git_object_format
base_git_oid
authorized_path_scope_digest
projection_digest
```

It contains no capsule entries, paths, operations, modes, blob digests, byte lengths, body bytes, locator, or credential.

[ proposed post-execution evidence owner contract ] `PostExecutionModelInputSafeProjectionV1` contains exactly nine ordered entries. Each entry contains the role/rank/ordinal, original typed pair, actual model-value schema/ref/digest, and input posture. For eight nonprivate roles the model-value pair equals the typed pair. For `candidate_capsule`, the model-value pair is the safe projection, while the exact full manifest is separately bound by the private-input manifest.

[ proposed post-execution evidence owner contract ] `PostExecutionPrivateInputManifestV1` has exactly one entry:

```text
role = candidate_capsule
role_rank = 5
ordinal = 0
typed_schema_id
typed_value_ref
typed_value_digest
canonical_byte_length
privacy_classification = private_candidate_capsule_manifest
```

It contains no physical location or retrieval mechanism.

[ proposed post-execution evidence owner contract ] `PostExecutionModelInputBindingV1` has:

```text
schema_id
binding_ref
context_ref
context_digest
model_input_safe_projection_ref
model_input_safe_projection_digest
private_input_manifest_ref
private_input_manifest_digest
source_invocation_ref
source_invocation_digest
model_contract_ref
model_contract_digest
model_configuration_ref
model_configuration_digest
artifact_schema_id
artifact_ref
artifact_digest
artifact_binding_digest
artifact_safe_projection_schema_id
artifact_safe_projection_digest
proposal_ref
proposal_digest
evidence_set_ref
evidence_set_digest
source_invocation_started_at
source_invocation_completed_at
artifact_validated_at
result
reason
binding_digest
```

`result/reason` is exactly `exact/model_input_context_exact`.

[ proposed post-execution evidence owner contract ] Its pure relation succeeds only if:

1. The invocation’s `context_schema_id/context_ref/context_digest` equals the T1 context.
2. Its model-contract and model-configuration pairs equal those repeated by the final proposal.
3. The supplied model-input projection and private manifest reconstruct the context digests.
4. Every role supply reconstructs its typed self-identity and the corresponding role entry.
5. The invocation’s artifact pair equals the validated artifact binding and final proposal.
6. The proposal ref equals `preassigned_proposal_ref`.
7. The final proposal repeats the context pair and was constructed from that invocation and artifact.
8. The nine Section 41 rows use the same role/rank/ordinal and typed ref/digest pairs.
9. The reconstructed evidence-set digest equals the proposal’s evidence-set digest.

Missing complete pre-invocation input prevents invocation and yields the zero-row `no_decision` posture. Any claimed equality with different canonical bytes, schema, phase, profile, or support is `basis_conflict`.

# Construction chronology and SQL write order

[ proposed post-execution evidence owner contract ] Pure construction order is:

```text
T0 owner values and support values complete
T1 model-input projection, private-input manifest, context, and supply complete
T2 model invocation consumes that exact context and supply
T3 source invocation completes; artifact validates
T4 nine evidence-binding row values and evidence-set identity are constructed
T5 proposal row is constructed from the T3 artifact and T4 evidence set
```

[ current merged implementation ] Migration 0003 has an immediate foreign key from each evidence row to its proposal parent. Durable insertion therefore remains:

```text
source invocation
private artifact binding
proposal parent row
nine evidence child rows
existing selection/disposition rows when applicable
```

[ proposed Section 41 role-resolution contract ] T4 is pure construction, not child insertion. The proposal row is inserted before its child rows even though its value depends on the already-constructed evidence-set identity.

[ current owning contract ] Current Section 41 requires all nine `evidence_bound_at` values to be equal. No other current timestamp equality is implied.

[ proposed post-execution evidence owner contract ] Exact temporal relations are:

```text
maximum present owner observed_at/evaluated_at <= context.constructed_at
context.constructed_at = supply.supply_created_at
context.constructed_at <= source_invocation_started_at
source_invocation_started_at <= source_invocation_completed_at
source_invocation_completed_at <= artifact_validated_at
artifact_validated_at <= common evidence_bound_at
common evidence_bound_at <= proposal_created_at
proposal_created_at < decision_snapshot.captured_at
```

[ proposed RW0-C decision-input contract ] Membership closure capture, current-snapshot capture, currentness evaluation, three decision-matrix evaluations, and recommendation-consistency evaluation use one future decision-operation timestamp. Freshness is always `evaluated_at < expires_at`; equality means expired.

# Transient supply and resupply contract

[ proposed post-execution evidence owner contract ] `PostExecutionEvidenceSupplyV1` is private, pure operation input:

```text
schema_id
supply_ref
context
model_input_safe_projection
private_input_manifest
role_supply_count
role_supplies
supply_created_at
supply_digest
```

It has exactly nine role supplies and a maximum canonical size of 1,048,576 bytes.

[ proposed post-execution evidence owner contract ] Each `PostExecutionRoleSupplyV1` has:

```text
role
role_rank
ordinal
typed_schema_id
typed_value_ref
typed_value_digest
typed_canonical_value
source_profile_ref
source_profile_digest
source_profile_canonical_value
source_binding_ref
source_binding_digest
source_binding_canonical_value
support_set_ref
support_set_digest
support_set_canonical_value
support_value_count
support_canonical_values
model_input_posture
```

Every `*_canonical_value` is dispatched to the exact role-specific closed schema; it is not an extension bag. Pair/value groups are jointly present or jointly null according to the T1 role table.

[ proposed post-execution evidence owner contract ] Supply rules are:

1. No physical custodian, lookup, store, or retrieval API is claimed.
2. Every semantically required non-C1 value is supplied exactly before a future decision commits.
3. Verification covers the T1 entry, Section 41 row, typed self-identity, role relation, profiles, source binding, and support set.
4. Missing exact optional supply is `no_decision`.
5. Malformed bytes, wrong schema, wrong phase, wrong role, wrong profile, wrong support, or a false claimed digest is `basis_conflict`.
6. Precommit replay resupplies and revalidates; process memory is never evidence.
7. Restart before commit requires complete resupply.
8. Committed recovery uses retained safe values and locators and never asks for the transient package.

# Candidate-capsule privacy and resupply

[ current owning contract ] The complete `CandidateCapsuleManifestV1` includes exact entries and paths and is not Coordinator durable state.

[ proposed post-execution evidence owner contract ] The full manifest may exist only in the transient supply and model private-input package. It is required again for precommit decision/replay validation. Absence is `no_decision`; wrong bytes, ref, digest, schema, lineage, or phase is `basis_conflict`.

[ proposed future committed-recovery contract ] Committed recovery retains `CandidateCapsuleSafeProjectionV1`, not the full manifest. The projection retains candidate, manifest and portable digests, path-scope digest, and lineage only.

[ proposed future committed-recovery contract ] No scoped postcommit recovery relation needs capsule entries or bodies. If a future authoritative branch requires those private fields after commit, that future contract must stop rather than widen migration 0003/C1 or invent custody.

# Section 41 role locators and extractors

[ current merged implementation ] The evidence-binding locator is exactly:

```text
(proposal_ref, evidence_role, ordinal)
```

`evidence_binding_digest` is its row identity. No `evidence_binding_ref` is invented.

[ proposed Section 41 role-resolution contract ] Extractors are closed:

| Role | Typed extraction | Source profile/binding | Direct C1 | Decision-time profile |
|---|---|---|---|---|
| candidate | `capsule_manifest_ref`, `portable_capsule_digest` | null/null | none | none |
| worker result | `value_ref`, `value_digest` | `wire_profile_*`, `relation_*` | rank 14 membership | immutable |
| validation | `disposition_ref`, `disposition_digest` | disposition profile, source observation | none | proposal currentness |
| review | `disposition_ref`, `disposition_digest` | disposition profile, source observation | none | proposal currentness |
| policy | `matrix_ref`, `matrix_digest` | policy profile, policy source | none | proposal currentness |
| risk | `matrix_ref`, `matrix_digest` | risk-source profile, source binding | none | proposal currentness |
| authority | `observation_ref`, `observation_digest` | null/null | rank 1 membership | authority matrix |
| stop | `snapshot_ref`, `snapshot_digest` | stop profile, global-stop state | none | stop matrix |
| ceiling | `evidence_ref`, `evidence_digest` | ceiling profile, effect fence | none | ceiling matrix |

No extractor inspects an arbitrary mapping. Each reconstructs the exact named type before reading fields.

# Role-resolution posture and identity

[ proposed Section 41 role-resolution contract ] Resolution posture is `recomputable_from_resupply`. Migration 0005 may later retain the successful relation and safe typed values/locators, but migration 0003 and C1 remain unchanged.

[ proposed Section 41 role-resolution contract ] `Section41PostExecutionRoleResolutionV2` has:

```text
schema_id
relation_ref
profile_ref
profile_digest
context_ref
context_digest
context_role_entry_digest
source_invocation_ref
source_invocation_digest
proposal_ref
proposal_digest
evidence_set_ref
evidence_set_digest
section41_membership_ref
section41_membership_digest
section41_value_ref
section41_value_digest
evidence_locator_proposal_ref
evidence_locator_role
evidence_locator_ordinal
evidence_binding_digest
evidence_bound_at
typed_schema_id
typed_value_ref
typed_value_digest
source_posture
direct_c1_kind
direct_c1_kind_rank
direct_c1_membership_ref
direct_c1_membership_digest
source_profile_ref
source_profile_digest
source_binding_ref
source_binding_digest
model_input_posture
decision_currentness_profile_ref
decision_currentness_profile_digest
resolution_posture
result
reason
relation_digest
```

`result/reason` is exactly `resolved/exact_role_binding`. Candidate and worker decision-currentness profile pairs are null; all other pairs are fixed by the role table.

[ proposed Section 41 role-resolution contract ] The function returns:

- `no_decision` for zero Section 41 rows, absent exact optional resupply, or absent selected membership;
- `basis_conflict` for 1–8 or more than 9 rows, reorder, duplication, composite-locator substitution, typed mismatch, profile/support mismatch, or contradictory supplied bytes;
- exactly nine successful relation values otherwise.

# Total validation disposition algebra

[ proposed post-execution evidence owner contract ] With no structural defect, the only legal tuples are:

| Source outcome | Result | Repairability | Reason |
|---|---|---|---|
| `passed` | `passed` | `not_applicable` | `validation_passed` |
| `failed` | `repairable_failure` | `repairable` | `validation_failed_repairable` |
| `failed` | `replan_required` | `same_attempt_insufficient` | `validation_failed_replan_required` |
| `failed` | `terminal_failure` | `nonrepairable` | `validation_failed_terminal` |
| `failed` | `unknown` | `unknown` | `validation_failed_unclassified` |
| `inconclusive` | `unknown` | `unknown` | `validation_inconclusive` |
| `not_run` | `not_run` | `not_applicable` | `validation_not_run` |

[ proposed post-execution evidence owner contract ] Structural precedence is:

```text
source_observation_mismatch
lineage_mismatch
author_identity_conflict
profile_identity_conflict
requirement_identity_conflict
result_set_identity_conflict
candidate_identity_conflict
support_identity_conflict
timestamp_conflict
```

If any is present, the only legal result is `basis_conflict`, repairability is `conflict`, and reason is the first adverse condition. Every other tuple fails `outcome_disposition_mismatch`; it is never normalized or inferred.

# Total review disposition algebra

[ proposed post-execution evidence owner contract ] For `independent` review, legal tuples are:

| Source outcome | Result | Reason |
|---|---|---|
| `passed` | `passed` | `review_passed` |
| `failed` | `repair_required` | `review_failed_repair_required` |
| `failed` | `replan_required` | `review_failed_replan_required` |
| `failed` | `terminal_reject` | `review_failed_terminal_reject` |
| `failed` | `unknown` | `review_failed_unclassified` |
| `inconclusive` | `unknown` | `review_inconclusive` |

For any source outcome, `unknown` independence permits only `unknown/review_independence_unknown`; `not_independent` permits only `basis_conflict/review_not_independent`; `conflict` permits only `basis_conflict/reviewer_independence_conflict`.

[ proposed post-execution evidence owner contract ] Structural precedence is source, lineage, author, profile, requirement, result set, candidate, independence identity, support, then timestamp. A structural condition forces `basis_conflict` with the first reason. All other tuples fail.

# Policy and risk matrix algebras

[ proposed post-execution evidence owner contract ] Ordered branch applicability is:

| Branch | Applicability | Governed effect class |
|---|---|---|
| `candidate_acceptance` | `governed` | `author_candidate` |
| `candidate_repair` | `governed` | `author_candidate` |
| `attempt_selecting_replan` | `governed` | `author_candidate` |
| `program_terminal_reject` | `halt_only` | null |
| `post_execution_program_block` | `halt_only` | null |

`author_candidate` classifies the completed source effect whose evidence is being evaluated. It does not authorize a new effect or successor.

[ proposed post-execution evidence owner contract ] Policy precedence is:

```text
policy_identity_conflict -> conflict
evaluator_profile_mismatch -> conflict
support_conflict -> conflict
halt_only -> permit/halt_only_policy_not_applicable
policy_revoked -> deny/policy_revoked
before_not_before -> deny/policy_not_yet_valid
at_or_after_expiry -> deny/policy_expired
branch_not_allowed -> deny/branch_not_allowed
audience_mismatch -> deny/audience_mismatch
repository_mismatch -> deny/repository_mismatch
path_scope_mismatch -> deny/path_scope_mismatch
risk_lane_not_allowed -> deny/risk_lane_not_allowed
effect_class_not_allowed -> deny/effect_class_not_allowed
ceilings_exceeded -> deny/ceilings_exceeded
policy_status_unknown -> unknown/policy_status_unknown
policy_currentness_unknown -> unknown/policy_currentness_unknown
otherwise -> permit/policy_permits
```

The valid interval is `not_before <= evaluated_at < expires_at`.

[ proposed post-execution evidence owner contract ] Risk precedence is:

```text
risk_source_conflict -> conflict
policy_identity_conflict -> conflict
evaluator_profile_mismatch -> conflict
support_conflict -> conflict
halt_only -> permit/halt_only_risk_not_applicable
policy_revoked -> deny/policy_revoked
before_not_before -> deny/policy_not_yet_valid
at_or_after_expiry -> deny/policy_expired
required_lane_mismatch -> deny/required_lane_mismatch
risk_lane_not_allowed -> deny/risk_lane_not_allowed
policy_status_unknown -> unknown/policy_status_unknown
otherwise -> permit/risk_lane_permits
```

Missing risk source prevents matrix construction and is outer `no_decision`; it is not a synthetic matrix entry.

[ compatibility edge ] `FiniteBacklogRiskSourceBindingV1` retains only the explicit development-work/backlog/lease/item/lane/mapping identities. The generic matrix contains only the generic source profile and binding pairs.

# Stop and source-effect ceiling profiles

[ proposed post-execution evidence owner contract ] `PostExecutionGlobalStopSnapshotV1` retains the full safe `GlobalStopState`, its canonical digest, `updated_at`, the stop-profile pair, evaluation time, and support-set pair.

[ proposed RW0-C decision-input contract ] Stop comparison is total:

| Current observation | Result |
|---|---|
| missing/malformed | `basis_conflict` |
| lower version | `basis_conflict` |
| same version with any ref/state/digest/updated-at mismatch | `basis_conflict` |
| exact same version | comparison `same` |
| higher, well-formed version | comparison `advanced`; fresh state governs |

Clear permits every stop predicate. Active denies the three governed branches and permits both halt-only branches. Such permit is not complete authorization.

[ proposed post-execution evidence owner contract ] `PostExecutionSourceEffectCeilingEvidenceV1` retains separately:

```text
attempt_fence_expires_at
effect_fence_expires_at
authority_grant_expires_at
authority_observation_expires_at
```

It also retains source, attempt, effect, and authority ceilings; attempt and authority effect-class sets; exact fence and authority identities; evaluation time; support; result; and reason.

[ proposed post-execution evidence owner contract ] Ceiling precedence is structural conflict, explicit denied/revoked authority, the four expiries in the displayed order, effect-class exclusions, componentwise attempt/effect/authority exceedance, authority unknown cases, then compliance. Equality with any expiry is expired.

# Support-set contract

[ proposed post-execution evidence owner contract ] `PostExecutionSupportEntryV1` is:

```text
role
rank
ordinal
source_schema_id
source_ref
source_digest
```

`PostExecutionSupportSetV1` is:

```text
schema_id
support_set_ref
profile_ref
profile_digest
entries
support_set_digest
```

Entries are in `(rank, ordinal, role, source_schema_id, source_ref)` order; ordinal is zero; maximum cardinality is 16. Actual cardinality and allowed roles are exactly the consuming profile’s inventory. Duplicate role/rank/ordinal, duplicate source pair, reorder, substitution, extra entry, or omission fails.

# Decision-time behavior profiles

[ proposed RW0-C decision-input contract ] Proposal-currentness has four ordered components: validation, review, policy, risk. Component outcomes are:

```text
same pair and fresh -> current
same ref with different digest -> conflict
different well-formed pair -> stale
expired exact value -> stale
source unavailable -> unknown
malformed or wrong profile -> conflict
```

Aggregate precedence is conflict, then stale, then unknown, then current. Outer mapping is `current -> continue`, `stale|unknown -> no_decision`, `conflict -> basis_conflict`.

[ proposed RW0-C decision-input contract ] Authority and decision-time ceiling matrices use the same five ordered branches. Structural conflicts precede all semantic results. Halt-only entries permit after structural validation. Explicit deny/revocation/expiry/class/ceiling failures precede unknown. Permit is neither external authority nor future effect permission.

[ proposed RW0-C decision-input contract ] Recommendation consistency is constructed only after an authoritative branch is independently supplied by the later branch owner:

```text
accept_candidate -> candidate_acceptance
repair_candidate -> candidate_repair
replan -> attempt_selecting_replan
terminal_reject -> program_terminal_reject
block -> post_execution_program_block
```

Identity/provenance mismatch yields `basis_conflict`; noncurrent proposal/snapshot yields `stale_context`; equal mapped branch yields `consistent`; otherwise `inconsistent`.

# C1 membership closure and paging

[ proposed RW0-C decision-input contract ] `RW0CDecisionMembershipClosureV1` has:

```text
schema_id
closure_ref
profile_ref
profile_digest
phase_basis_ref
phase_basis_digest
member_count
members
captured_at
closure_digest
```

Each ordered member contains:

```text
kind_rank
membership_ref
membership_digest
value_schema_id
value_ref
value_digest
scope_binding_digest
relation_set_digest
admitted_at
admission_graph_digest
```

[ proposed RW0-C decision-input contract ] Paging is exact:

1. Use the current private C1 page reader under one transaction capability epoch.
2. Initial cursor is `(0, "0")`.
3. Page size is 256; SQL limit remains 257.
4. Enforce strict `(kind_rank, membership_ref)` increase.
5. Verify every returned membership’s complete C1 family and all entry fields.
6. Continue only from the exact returned cursor.
7. Null cursor terminates closure.
8. Empty-with-cursor, nonprogress, duplication, reorder, pair mismatch, or inconsistent family is `basis_conflict` or database-integrity failure.
9. Entry 65,537 is an overflow sentinel; more than 65,536 members yields `no_decision/membership_closure_overflow`.
10. The same `BEGIN IMMEDIATE` prevents a later admission before decision commit. Admission after commit cannot rewrite the retained closure.

[ proposed RW0-C decision-input contract ] This proves exhaustive observed membership for that transaction. It does not grant C1 completeness authority or assert that a particular semantic inventory is sufficient. Absence of the selected rank-15 member is `no_decision`.

# RW0-C current snapshot

[ proposed RW0-C decision-input contract ] `RW0CDecisionCurrentSnapshotV1` has:

```text
schema_id
snapshot_ref
profile_ref
profile_digest
phase_basis_ref
phase_basis_digest
k8_digest
membership_closure_ref
membership_closure_digest
selected_authority_membership_ref
selected_authority_membership_digest
selected_section41_membership_ref
selected_section41_membership_digest
selected_section41_value_ref
selected_section41_value_digest
program_head
program_version
accepted_intent_revision
work_item_head
work_item_revision
selection_head
effect_head
delivery_head
phase_instance
attempt_fence
effect_fence
authority_observation
global_stop_current
external_current_sources
captured_at
snapshot_digest
```

Every nested SQLite/C1 value is its complete validated safe mapping, not merely an aggregate digest.

[ proposed RW0-C decision-input contract ] Exact owner locators are:

| Component | Locator |
|---|---|
| program head | `development_program_heads(program_ref)` |
| program version | `development_program_versions(program_version_ref)` |
| accepted intent | `development_accepted_intent_revisions(accepted_intent_revision_ref)` |
| work head | `development_work_item_heads(work_item_ref)` |
| work revision | `development_work_item_revisions(work_item_revision_ref)` |
| selection head | its complete eight-coordinate K8 primary key |
| effect head | `development_effect_heads(effect_intent_ref)` |
| delivery head | `development_delivery_heads(effect_intent_ref)` |
| phase | `rw0_phase_instances(phase_basis_ref)` |
| attempt/effect fences | their immutable refs |
| global stop | `global_stop_current(singleton_id=1)` |
| membership | exact C1 membership pair |
| Section 41 row | exact composite locator plus row digest |

[ proposed RW0-C decision-input contract ] Each `ExternalCurrentSourceCoordinateV1` has role, availability, schema/ref/digest, profile pair, binding pair, effect/delivery coordinates when applicable, observed/evaluated/expiry times, and source posture. `unavailable` requires all identity/time fields null. Malformed partial groups cannot be represented.

[ proposed RW0-C decision-input contract ] The inventory is complete because:

- proposal currentness consumes only validation, review, policy, and risk source coordinates;
- authority consumes phase, heads, authority, parent/family, fences, effect class, and expiries;
- stop consumes the full singleton;
- ceiling consumes source evidence, authority, fences, effect class, and ceilings;
- membership selection consumes the closure and selected rank-1/rank-15 pairs.

No unrelated database state is copied.

# Complete identity grammars and golden vectors

[ proposed post-execution evidence owner contract ] Common grammar is exact built-in values only. Refs are current 1–96-character safe ASCII refs; digests are 64 lowercase hex; timestamps are canonical 20-byte whole-second UTC; integers are exact `int`, never `bool`, in `0..2^63-1`; schemas/enums/reasons are closed ASCII. There is no Unicode normalization. Unknown, missing, duplicate, subclassed, or unversioned extension fields fail before canonicalization.

[ proposed post-execution evidence owner contract ] Canonical JSON uses sorted keys, compact separators, UTF-8, and no BOM/newline:

```text
digest = SHA256(domain_utf8 || 0x00 || canonical_json_utf8)
```

For every generated ref:

```text
key_mapping = complete identity mapping
              minus schema_id, generated-ref field, and self-digest field

ref = prefix || SHA256(schema_id + ".key" || 0x00 ||
                       canonical_json(key_mapping))
```

The self digest includes the generated ref and excludes only the named self-digest. Nested entries have no hidden fields.

[ proposed post-execution evidence owner contract ] Ref prefixes are:

```text
post-support-set.
validation-disposition.
independent-review-disposition.
post-policy-matrix.
finite-backlog-risk-binding.
post-risk-matrix.
post-global-stop-snapshot.
post-source-effect-ceiling.
candidate-safe-projection.
post-model-input-projection.
post-private-input-manifest.
post-semantic-context.
post-evidence-supply.
post-model-input-binding.
section41-role-relation.
rw0c-membership-closure.
rw0c-current-snapshot.
rw0c-evidence-currentness.
rw0c-authority-matrix.
rw0c-stop-matrix.
rw0c-ceiling-matrix.
rw0c-recommendation-check.
rw0c-recovery-manifest.
```

[ proposed post-execution evidence owner contract ] Corrected owner-value field inventories are:

```text
ValidationDispositionV1 =
(schema_id, disposition_ref, profile_ref, profile_digest,
 source_observation_schema_id, source_observation_ref,
 source_observation_digest, source_outcome,
 author_role, author_ref, author_invocation_ref,
 program_ref, program_version_ref, accepted_intent_revision_ref,
 work_item_ref, work_item_revision_ref, semantic_attempt_ref,
 semantic_attempt_digest, attempt_number, candidate_ref, effect_intent_ref,
 capsule_manifest_ref, capsule_manifest_digest,
 validation_tool_profile_schema_id, validation_tool_profile_ref,
 validation_tool_profile_digest, validation_requirement_schema_id,
 validation_requirement_ref, validation_requirement_digest,
 validation_result_set_schema_id, validation_result_set_ref,
 validation_result_set_digest, result, reason, repairability,
 evaluated_at, expires_at, support_set_ref, support_set_digest,
 disposition_digest)

IndependentReviewDispositionV1 =
(schema_id, disposition_ref, profile_ref, profile_digest,
 source_observation_schema_id, source_observation_ref,
 source_observation_digest, source_outcome,
 author_role, author_ref, author_invocation_ref,
 program_ref, program_version_ref, accepted_intent_revision_ref,
 work_item_ref, work_item_revision_ref, semantic_attempt_ref,
 semantic_attempt_digest, attempt_number, candidate_ref, effect_intent_ref,
 capsule_manifest_ref, capsule_manifest_digest,
 review_tool_profile_schema_id, review_tool_profile_ref,
 review_tool_profile_digest, review_requirement_schema_id,
 review_requirement_ref, review_requirement_digest,
 review_result_set_schema_id, review_result_set_ref,
 review_result_set_digest, reviewer_independence_schema_id,
 reviewer_independence_ref, reviewer_independence_digest,
 independence_status, result, reason, evaluated_at, expires_at,
 support_set_ref, support_set_digest, disposition_digest)

DecisionBranchEvaluationEntryV1 =
(branch, applicability, governed_effect_class, result, reason)

PostExecutionStandingPolicyBranchMatrixV1 =
(schema_id, matrix_ref, profile_ref, profile_digest,
 phase_basis_ref, phase_basis_digest,
 program_ref, program_version_ref, work_item_ref, work_item_revision_ref,
 semantic_attempt_ref, candidate_ref, effect_intent_ref,
 author_role, author_ref, author_invocation_ref,
 policy_source_schema_id, policy_ref, policy_digest,
 policy_status, policy_revocation_status,
 parent_grant_ref, parent_grant_digest,
 audience_ref, repository_ref, path_scope_digest, risk_lane,
 source_effect_class, allowed_branches, allowed_risk_lanes,
 allowed_effect_classes, maximum_ceilings,
 not_before, expires_at, evaluated_at, entries,
 support_set_ref, support_set_digest, matrix_digest)

PostExecutionRiskLaneBranchMatrixV1 =
(schema_id, matrix_ref, profile_ref, profile_digest,
 phase_basis_ref, phase_basis_digest,
 development_work_item_ref, work_item_revision_ref, semantic_attempt_ref,
 candidate_ref, author_role, author_ref, author_invocation_ref,
 risk_lane, source_profile_ref, source_profile_digest,
 source_binding_ref, source_binding_digest,
 risk_policy_schema_id, risk_policy_ref, risk_policy_digest,
 policy_status, policy_revocation_status,
 allowed_risk_lanes, required_risk_lane,
 not_before, expires_at, evaluated_at, entries,
 support_set_ref, support_set_digest, matrix_digest)

PostExecutionGlobalStopSnapshotV1 =
(schema_id, snapshot_ref, profile_ref, profile_digest,
 global_stop_schema_id, global_stop_ref, global_stop_version,
 global_stop_state, global_stop_reason_class, global_stop_issuer_ref,
 global_stop_issued_at, global_stop_operator_decision_ref,
 global_stop_digest, global_stop_updated_at, evaluated_at,
 support_set_ref, support_set_digest, snapshot_digest)

PostExecutionSourceEffectCeilingEvidenceV1 =
(schema_id, evidence_ref, profile_ref, profile_digest,
 phase_basis_ref, phase_basis_digest,
 program_ref, program_version_ref, work_item_ref, work_item_revision_ref,
 semantic_attempt_ref, candidate_ref, effect_intent_ref,
 source_effect_class, source_effect_ceilings, path_scope_digest,
 attempt_fence_ref, attempt_fence_digest,
 attempt_allowed_effect_classes, attempt_ceilings,
 attempt_fence_expires_at,
 effect_fence_ref, effect_fence_digest, effect_ceilings,
 effect_fence_expires_at,
 authority_observation_ref, authority_observation_digest,
 authority_status, authority_family_status, authority_revocation_status,
 authority_allowed_effect_classes, authority_ceilings,
 authority_grant_expires_at, authority_observation_expires_at,
 evaluated_at, result, reason,
 support_set_ref, support_set_digest, evidence_digest)
```

[ proposed RW0-C decision-input contract ] Decision values are:

```text
RW0CProposalEvidenceCurrentnessV1 =
(schema_id, currentness_ref, profile_ref, profile_digest,
 proposal_ref, proposal_digest, decision_snapshot_ref,
 decision_snapshot_digest, components, evaluated_at,
 result, reason, currentness_digest)

RW0CDecisionTimeAuthorityBranchMatrixV1 =
(schema_id, matrix_ref, profile_ref, profile_digest,
 decision_snapshot_ref, decision_snapshot_digest,
 authority_observation_ref, authority_observation_digest,
 parent_grant_ref, parent_grant_digest,
 evaluated_at, entries, support_set_ref, support_set_digest, matrix_digest)

RW0CDecisionTimeGlobalStopBranchMatrixV1 =
(schema_id, matrix_ref, profile_ref, profile_digest,
 decision_snapshot_ref, decision_snapshot_digest,
 proposal_stop_snapshot_ref, proposal_stop_snapshot_digest,
 version_relation, evaluated_at, entries,
 support_set_ref, support_set_digest, matrix_digest)

RW0CDecisionTimeSourceEffectCeilingBranchMatrixV1 =
(schema_id, matrix_ref, profile_ref, profile_digest,
 decision_snapshot_ref, decision_snapshot_digest,
 proposal_ceiling_evidence_ref, proposal_ceiling_evidence_digest,
 evaluated_at, entries, support_set_ref, support_set_digest, matrix_digest)

RW0CRecommendationConsistencyEvaluationV1 =
(schema_id, evaluation_ref, profile_ref, profile_digest,
 proposal_ref, proposal_digest, model_recommendation,
 authoritative_branch, decision_snapshot_ref, decision_snapshot_digest,
 proposal_currentness_ref, proposal_currentness_digest,
 authority_matrix_ref, authority_matrix_digest,
 global_stop_matrix_ref, global_stop_matrix_digest,
 ceiling_matrix_ref, ceiling_matrix_digest,
 result, reason, evaluated_at, evaluation_digest)
```

[ proposed post-execution evidence owner contract ] Canonical profile JSON and independently reproduced semantic digests are below. In precedence arrays, a two-element entry uses the condition token as the reason; a three-element entry names the result and distinct reason explicitly.

```text
post-execution-support-set.v1
026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097
{"cardinality":"exact_consuming_profile_inventory","duplicate_policy":"reject_any_repeated_role_rank_ordinal_or_source_pair","entry_fields":["role","rank","ordinal","source_schema_id","source_ref","source_digest"],"maximum_entries":16,"ordering":["rank","ordinal","role","source_schema_id","source_ref"],"ordinal":0,"profile_ref":"post-execution-support-set.v1","schema_id":"governed-execution.nwp-post-execution-support-set-profile.v1","substitution_policy":"exact_profile_role_schema_ref_digest_required","unknown_role":"reject"}

post-execution-semantic-review-input.v1
b887c04539c16ac344f116da5483a9cdfd9e47e23a7b3877ec4c5fd8b9f953b3
{"candidate_private_input":"exact_manifest_bound_by_private_input_manifest","context_schema_id":"governed-execution.nwp-post-execution-semantic-review-context.v1","malformed_or_substituted_role_set":"basis_conflict","missing_complete_role_set":"no_decision","model_input_equality":"exact_typed_canonical_value_or_named_safe_projection","profile_ref":"post-execution-semantic-review-input.v1","proposal_phase":"post_execution_semantic_review","role_entry_count":9,"roles":[{"c1_kind":null,"c1_kind_rank":null,"c1_membership_required":false,"decision_currentness":"none","model_input_posture":"private_exact_canonical_value","ordinal":0,"role":"candidate_capsule","role_rank":5,"source_binding_rule":"null","source_posture":"transient_private_resupply","source_profile_rule":"null","typed_schema_id":"governed-execution.nwp-candidate-capsule-manifest.v1"},{"c1_kind":"wire_process_result_classification_binding","c1_kind_rank":14,"c1_membership_required":true,"decision_currentness":"immutable","model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"worker_result","role_rank":6,"source_binding_rule":"classification_relation_pair","source_posture":"c1_admitted_exact_value","source_profile_rule":"wire_profile_pair","typed_schema_id":"governed-execution.nwp-rw0-c1-wire-process-result-classification-binding.v1"},{"c1_kind":null,"c1_kind_rank":null,"c1_membership_required":false,"decision_currentness":"proposal_evidence_currentness","model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"validation_result","role_rank":7,"source_binding_rule":"source_observation_pair","source_posture":"transient_owner_resupply","source_profile_rule":"disposition_profile_pair","typed_schema_id":"governed-execution.nwp-validation-disposition.v1"},{"c1_kind":null,"c1_kind_rank":null,"c1_membership_required":false,"decision_currentness":"proposal_evidence_currentness","model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"independent_review","role_rank":8,"source_binding_rule":"source_observation_pair","source_posture":"transient_owner_resupply","source_profile_rule":"disposition_profile_pair","typed_schema_id":"governed-execution.nwp-independent-review-disposition.v1"},{"c1_kind":null,"c1_kind_rank":null,"c1_membership_required":false,"decision_currentness":"proposal_evidence_currentness","model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"standing_policy","role_rank":9,"source_binding_rule":"policy_source_pair","source_posture":"transient_owner_resupply","source_profile_rule":"policy_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-standing-policy-branch-matrix.v1"},{"c1_kind":null,"c1_kind_rank":null,"c1_membership_required":false,"decision_currentness":"proposal_evidence_currentness","model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"risk_lane","role_rank":10,"source_binding_rule":"risk_source_binding_pair","source_posture":"transient_owner_resupply","source_profile_rule":"risk_source_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-risk-lane-branch-matrix.v1"},{"c1_kind":"authority_verification_observation","c1_kind_rank":1,"c1_membership_required":true,"decision_currentness":"authority_branch_matrix","model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"authority_currentness_attestation","role_rank":11,"source_binding_rule":"null","source_posture":"c1_admitted_exact_value","source_profile_rule":"null","typed_schema_id":"governed-execution.nwp-rw0-authority-verification-observation.v1"},{"c1_kind":null,"c1_kind_rank":null,"c1_membership_required":false,"decision_currentness":"global_stop_branch_matrix","model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"global_stop","role_rank":12,"source_binding_rule":"global_stop_state_pair","source_posture":"transient_owner_resupply","source_profile_rule":"stop_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-global-stop-snapshot.v1"},{"c1_kind":null,"c1_kind_rank":null,"c1_membership_required":false,"decision_currentness":"source_effect_ceiling_branch_matrix","model_input_posture":"nonprivate_exact_canonical_value","ordinal":0,"role":"effect_ceiling","role_rank":13,"source_binding_rule":"effect_fence_pair","source_posture":"transient_owner_resupply","source_profile_rule":"ceiling_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-source-effect-ceiling-evidence.v1"}],"schema_id":"governed-execution.nwp-post-execution-semantic-review-input-profile.v1","section41_rank15_membership_at_t1":"forbidden_unavailable"}

validation-disposition.v1
a53ccecbfa11c0a593536e8eda8ed59bec59f7e145a70cd04599913bf1e72157
{"all_other_tuples":"reject_outcome_disposition_mismatch","model_dependence":false,"profile_ref":"validation-disposition.v1","schema_id":"governed-execution.nwp-validation-disposition-profile.v1","semantic_tuples":[["passed","passed","not_applicable","validation_passed"],["failed","repairable_failure","repairable","validation_failed_repairable"],["failed","replan_required","same_attempt_insufficient","validation_failed_replan_required"],["failed","terminal_failure","nonrepairable","validation_failed_terminal"],["failed","unknown","unknown","validation_failed_unclassified"],["inconclusive","unknown","unknown","validation_inconclusive"],["not_run","not_run","not_applicable","validation_not_run"]],"source_observation_kind":"validation_completed","source_outcomes":["passed","failed","inconclusive","not_run"],"structural_precedence":["source_observation_mismatch","lineage_mismatch","author_identity_conflict","profile_identity_conflict","requirement_identity_conflict","result_set_identity_conflict","candidate_identity_conflict","support_identity_conflict","timestamp_conflict"],"structural_tuple":["any_source_outcome","basis_conflict","conflict","first_structural_reason"],"support_profile_digest":"026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097","support_roles":[["source_observation",1],["disposition_profile",2],["validation_tool_profile",3],["validation_requirement",4],["validation_result_set",5],["candidate_capsule",6]]}

independent-review-disposition.v1
ffdeb616c6beba4494bf08120f73a95adebbe724d78425cc7b6403a7c2394bbf
{"all_other_tuples":"reject_outcome_disposition_mismatch","independence_statuses":["independent","not_independent","unknown","conflict"],"model_dependence":false,"profile_ref":"independent-review-disposition.v1","schema_id":"governed-execution.nwp-independent-review-disposition-profile.v1","semantic_tuples":[["passed","independent","passed","review_passed"],["failed","independent","repair_required","review_failed_repair_required"],["failed","independent","replan_required","review_failed_replan_required"],["failed","independent","terminal_reject","review_failed_terminal_reject"],["failed","independent","unknown","review_failed_unclassified"],["inconclusive","independent","unknown","review_inconclusive"],["passed","unknown","unknown","review_independence_unknown"],["failed","unknown","unknown","review_independence_unknown"],["inconclusive","unknown","unknown","review_independence_unknown"],["passed","not_independent","basis_conflict","review_not_independent"],["failed","not_independent","basis_conflict","review_not_independent"],["inconclusive","not_independent","basis_conflict","review_not_independent"],["passed","conflict","basis_conflict","reviewer_independence_conflict"],["failed","conflict","basis_conflict","reviewer_independence_conflict"],["inconclusive","conflict","basis_conflict","reviewer_independence_conflict"]],"source_observation_kind":"independent_review_completed","source_outcomes":["passed","failed","inconclusive"],"structural_precedence":["source_observation_mismatch","lineage_mismatch","author_identity_conflict","profile_identity_conflict","requirement_identity_conflict","result_set_identity_conflict","candidate_identity_conflict","independence_identity_conflict","support_identity_conflict","timestamp_conflict"],"structural_tuple":["any_source_outcome","any_independence_status","basis_conflict","first_structural_reason"],"support_profile_digest":"026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097","support_roles":[["source_observation",1],["disposition_profile",2],["review_tool_profile",3],["review_requirement",4],["review_result_set",5],["reviewer_independence",6],["candidate_capsule",7]]}

post-execution-standing-policy-matrix.v1
c6e4ea9c56f45150d15ded0dca48f68fb15be0fa7f0b444e72f06a0137a1c9e8
{"branches":[{"applicability":"governed","branch":"candidate_acceptance","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"candidate_repair","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"attempt_selecting_replan","governed_effect_class":"author_candidate"},{"applicability":"halt_only","branch":"program_terminal_reject","governed_effect_class":null},{"applicability":"halt_only","branch":"post_execution_program_block","governed_effect_class":null}],"permit_is_executable_authority":false,"precedence":[["policy_identity_conflict","conflict"],["evaluator_profile_mismatch","conflict"],["support_conflict","conflict"],["halt_only","permit","halt_only_policy_not_applicable"],["policy_revoked","deny"],["before_not_before","deny","policy_not_yet_valid"],["at_or_after_expiry","deny","policy_expired"],["branch_not_allowed","deny"],["audience_mismatch","deny"],["repository_mismatch","deny"],["path_scope_mismatch","deny"],["risk_lane_not_allowed","deny"],["effect_class_not_allowed","deny"],["ceilings_exceeded","deny"],["policy_status_unknown","unknown"],["policy_currentness_unknown","unknown"],["otherwise","permit","policy_permits"]],"profile_ref":"post-execution-standing-policy-matrix.v1","results":["permit","deny","unknown","conflict"],"schema_id":"governed-execution.nwp-post-execution-standing-policy-matrix-profile.v1","support_profile_digest":"026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097","support_roles":[["policy_source",1],["policy_profile",2],["parent_grant",3],["authority_observation",4],["source_effect_intent",5]]}

post-execution-risk-lane-matrix.v1
eda9c5762c05f5fa825f8fa7a6a7562959ec39b09187e89f01c519dfb0167567
{"branches":[{"applicability":"governed","branch":"candidate_acceptance","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"candidate_repair","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"attempt_selecting_replan","governed_effect_class":"author_candidate"},{"applicability":"halt_only","branch":"program_terminal_reject","governed_effect_class":null},{"applicability":"halt_only","branch":"post_execution_program_block","governed_effect_class":null}],"finite_backlog_in_generic_schema":false,"generic_source_fields":["development_work_item_ref","risk_lane","source_profile_ref","source_profile_digest","source_binding_ref","source_binding_digest"],"precedence":[["risk_source_conflict","conflict"],["policy_identity_conflict","conflict"],["evaluator_profile_mismatch","conflict"],["support_conflict","conflict"],["halt_only","permit","halt_only_risk_not_applicable"],["policy_revoked","deny"],["before_not_before","deny","policy_not_yet_valid"],["at_or_after_expiry","deny","policy_expired"],["required_lane_mismatch","deny"],["risk_lane_not_allowed","deny"],["policy_status_unknown","unknown"],["otherwise","permit","risk_lane_permits"]],"profile_ref":"post-execution-risk-lane-matrix.v1","results":["permit","deny","unknown","conflict"],"schema_id":"governed-execution.nwp-post-execution-risk-lane-matrix-profile.v1","support_profile_digest":"026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097","support_roles":[["risk_source_profile",1],["risk_source_binding",2],["risk_policy",3],["risk_profile",4]]}

finite_backlog_risk_source.v1
1dace7cff29db22842b948482aeafb4f8a5b43fb7695a867901e49e2d22b7eac
{"binding_schema_id":"governed-execution.nwp-finite-backlog-risk-source-binding.v1","generic_projection_fields":["development_work_item_ref","risk_lane","source_profile_ref","source_profile_digest","source_binding_ref","source_binding_digest"],"profile_ref":"finite_backlog_risk_source.v1","relations":["backlog_identity_exact","backlog_item_exact","risk_lane_exact","development_to_backlog_mapping_explicit","development_and_backlog_ids_need_not_equal"],"schema_id":"governed-execution.nwp-finite-backlog-risk-source-profile.v1","source_fields":["development_work_item_ref","backlog_ref","backlog_digest","backlog_lease_ref","backlog_work_item_id","risk_lane","mapping_author_ref","mapping_author_digest","mapping_evidence_ref","mapping_evidence_digest"],"standing_lease_permission":false,"target_progression_authority":false}

post-execution-global-stop.v1
2d76a6933c708473707fb1398e98ee76c8e7092436ffbf544cb54d2ad2b26ff2
{"branches":[{"applicability":"governed","branch":"candidate_acceptance","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"candidate_repair","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"attempt_selecting_replan","governed_effect_class":"author_candidate"},{"applicability":"halt_only","branch":"program_terminal_reject","governed_effect_class":null},{"applicability":"halt_only","branch":"post_execution_program_block","governed_effect_class":null}],"entry_table":[["clear","governed","permit","global_stop_clear"],["clear","halt_only","permit","halt_only_global_stop_clear"],["active","governed","deny","global_stop_active"],["active","halt_only","permit","halt_only_global_stop_active"]],"permit_is_complete_authority":false,"profile_ref":"post-execution-global-stop.v1","same_version_fields":["global_stop_ref","global_stop_state","global_stop_digest","global_stop_updated_at"],"schema_id":"governed-execution.nwp-post-execution-global-stop-profile.v1","snapshot_source":"one_exact_global_stop_current_envelope","support_profile_digest":"026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097","support_roles":[["global_stop_current",1],["stop_profile",2]],"version_relation":[["missing_or_malformed","basis_conflict"],["lower","basis_conflict"],["same_with_any_field_mismatch","basis_conflict"],["same_exact","same"],["higher_well_formed","advanced"]]}

post-execution-source-effect-ceiling.v1
950bf044d7d7c7fc7721e732f748d97213413afe501d0ac3d71f726d06a340a0
{"branch_neutral":true,"ceiling_fields":["max_active_invocations","max_candidate_bytes","max_changed_files","max_cost_microusd","max_cpu_seconds","max_deliveries","max_deployments","max_local_commits","max_memory_bytes","max_merges","max_model_input_tokens","max_model_output_tokens","max_pull_requests","max_pushes","max_wall_seconds"],"comparison":"componentwise_source_less_than_or_equal_to_each_attempt_effect_authority_ceiling","expiry_fields":["attempt_fence_expires_at","effect_fence_expires_at","authority_grant_expires_at","authority_observation_expires_at"],"future_effect_permission":false,"precedence":[["profile_mismatch","conflict"],["lineage_conflict","conflict"],["fence_identity_conflict","conflict"],["authority_identity_conflict","conflict"],["support_conflict","conflict"],["authority_denied_or_revoked","noncompliant"],["attempt_fence_expired","noncompliant"],["effect_fence_expired","noncompliant"],["authority_grant_expired","noncompliant"],["authority_observation_expired","noncompliant"],["effect_class_not_allowed_by_attempt","noncompliant"],["effect_class_not_allowed_by_authority","noncompliant"],["effect_exceeds_attempt","noncompliant"],["effect_exceeds_effect_fence","noncompliant"],["effect_exceeds_authority","noncompliant"],["authority_status_unknown","unknown"],["authority_family_unknown","unknown"],["authority_revocation_unknown","unknown"],["authority_ceiling_unknown","unknown"],["otherwise","compliant","source_effect_within_ceilings"]],"profile_ref":"post-execution-source-effect-ceiling.v1","results":["compliant","noncompliant","unknown","conflict"],"schema_id":"governed-execution.nwp-post-execution-source-effect-ceiling-profile.v1","support_profile_digest":"026bad9c97825b23e472806699e39a443dec678b956a35a5dc4f7b9c3bb82097","support_roles":[["attempt_fence",1],["effect_fence",2],["authority_observation",3],["standing_policy_matrix",4],["ceiling_profile",5]]}

section41-post-execution-role-resolution.v2
4dd51e79388423e0befdaba2b665dc1c3eb1cd9845a01a84e2eae8cd4219c9e3
{"absent_behavior":"no_decision","c1_change":false,"evidence_binding_locator_fields":["proposal_ref","evidence_role","ordinal"],"evidence_cardinality":{"absent":0,"complete":9},"future_attestation":"migration_0005_retains_relation_value_and_typed_safe_value_or_locator","incomplete_behavior":"basis_conflict","input_profile_digest":"b887c04539c16ac344f116da5483a9cdfd9e47e23a7b3877ec4c5fd8b9f953b3","input_profile_ref":"post-execution-semantic-review-input.v1","migration_0003_change":false,"profile_ref":"section41-post-execution-role-resolution.v2","proposal_phase":"post_execution_semantic_review","rank15_c1_kind":"section41_post_execution_proposal_family_member","rank15_c1_kind_rank":15,"resolution_posture":"recomputable_from_resupply","roles":[{"decision_currentness":"none","ordinal":0,"role":"candidate_capsule","role_rank":5,"source_binding_rule":"null","source_profile_rule":"null","typed_schema_id":"governed-execution.nwp-candidate-capsule-manifest.v1"},{"decision_currentness":"immutable","ordinal":0,"role":"worker_result","role_rank":6,"source_binding_rule":"classification_relation_pair","source_profile_rule":"wire_profile_pair","typed_schema_id":"governed-execution.nwp-rw0-c1-wire-process-result-classification-binding.v1"},{"decision_currentness":"proposal_evidence_currentness","ordinal":0,"role":"validation_result","role_rank":7,"source_binding_rule":"source_observation_pair","source_profile_rule":"disposition_profile_pair","typed_schema_id":"governed-execution.nwp-validation-disposition.v1"},{"decision_currentness":"proposal_evidence_currentness","ordinal":0,"role":"independent_review","role_rank":8,"source_binding_rule":"source_observation_pair","source_profile_rule":"disposition_profile_pair","typed_schema_id":"governed-execution.nwp-independent-review-disposition.v1"},{"decision_currentness":"proposal_evidence_currentness","ordinal":0,"role":"standing_policy","role_rank":9,"source_binding_rule":"policy_source_pair","source_profile_rule":"policy_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-standing-policy-branch-matrix.v1"},{"decision_currentness":"proposal_evidence_currentness","ordinal":0,"role":"risk_lane","role_rank":10,"source_binding_rule":"risk_source_binding_pair","source_profile_rule":"risk_source_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-risk-lane-branch-matrix.v1"},{"decision_currentness":"authority_branch_matrix","ordinal":0,"role":"authority_currentness_attestation","role_rank":11,"source_binding_rule":"null","source_profile_rule":"null","typed_schema_id":"governed-execution.nwp-rw0-authority-verification-observation.v1"},{"decision_currentness":"global_stop_branch_matrix","ordinal":0,"role":"global_stop","role_rank":12,"source_binding_rule":"global_stop_state_pair","source_profile_rule":"stop_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-global-stop-snapshot.v1"},{"decision_currentness":"source_effect_ceiling_branch_matrix","ordinal":0,"role":"effect_ceiling","role_rank":13,"source_binding_rule":"effect_fence_pair","source_profile_rule":"ceiling_profile_pair","typed_schema_id":"governed-execution.nwp-post-execution-source-effect-ceiling-evidence.v1"}],"row_identity_field":"evidence_binding_digest","schema_id":"governed-execution.nwp-section41-post-execution-role-resolution-profile.v2"}

rw0-c-decision-membership-closure.v1
ee888fefe4fb5a9de378265741e9e68a57e117eed8ef732261fd6ccbdebe638d
{"c1_completeness_authority":false,"entry_fields":["kind_rank","membership_ref","membership_digest","value_schema_id","value_ref","value_digest","scope_binding_digest","relation_set_digest","admitted_at","admission_graph_digest"],"full_family_verification_per_entry":true,"initial_cursor":[0,"0"],"later_admission_after_commit":"does_not_rewrite_committed_closure","later_admission_before_commit":"forbidden_by_same_begin_immediate","malformed_duplicate_reordered_nonprogress":"basis_conflict_or_database_integrity","maximum_entries":65536,"order":["kind_rank","membership_ref"],"overflow":"no_decision_membership_closure_overflow","overflow_probe_entry":65537,"page_size":256,"profile_ref":"rw0-c-decision-membership-closure.v1","query_limit":257,"reader":"current_private_c1_membership_page","same_transaction_capability_epoch":true,"schema_id":"governed-execution.nwp-rw0-c-decision-membership-closure-profile.v1","strict_progress":true,"termination":"next_cursor_null_after_final_page"}

rw0-c-decision-current-snapshot.v1
5db66a2bc4ac9c69e6be2fea77f0ca912fb7785d5b1db2afa82d149fac057d0d
{"c1_inputs":["complete_membership_closure","selected_rank1_authority_membership","selected_rank15_section41_membership"],"capture":"one_begin_immediate_one_capability_epoch_one_controller_timestamp","excluded_state":"all_rows_not_consumed_by_currentness_authority_stop_or_ceiling_relations","malformed_or_cross_row_mismatch":"basis_conflict_or_database_integrity","missing_optional_resupplied_source":"no_decision","missing_required_sqlite_or_c1_family":"basis_conflict_or_database_integrity","mutable_head_advancement_before_commit":"current_state_conflict_requires_recapture","post_commit_advancement":"does_not_rewrite_committed_snapshot","profile_ref":"rw0-c-decision-current-snapshot.v1","resupplied_owner_sources":["validation_source","review_source","standing_policy_source","risk_source_profile_and_binding"],"schema_id":"governed-execution.nwp-rw0-c-decision-current-snapshot-profile.v1","sqlite_owner_rows":["development_program_heads","development_program_versions","development_accepted_intent_revisions","development_work_item_heads","development_work_item_revisions","development_pre_execution_selection_heads","development_effect_heads","development_delivery_heads","rw0_phase_instances","global_stop_current","development_attempt_fences","development_effect_fences"]}

rw0-c-proposal-evidence-currentness.v1
cbee95522a01784f7c3ab7a2645ecf42afd2d0461f4e3a5951613688f69e435a
{"aggregate_precedence":[["validation_conflict","conflict"],["review_conflict","conflict"],["policy_conflict","conflict"],["risk_conflict","conflict"],["validation_stale","stale"],["review_stale","stale"],["policy_stale","stale"],["risk_stale","stale"],["validation_unknown","unknown"],["review_unknown","unknown"],["policy_unknown","unknown"],["risk_unknown","unknown"],["otherwise","current"]],"component_table":[["same_ref_same_digest_and_fresh","current"],["same_ref_different_digest","conflict"],["different_well_formed_pair","stale"],["exact_value_expired_at_capture","stale"],["source_unavailable","unknown"],["malformed_or_wrong_profile","conflict"]],"components":["validation","review","policy","risk"],"outer_mapping":{"conflict":"basis_conflict","current":"continue","stale":"no_decision","unknown":"no_decision"},"profile_ref":"rw0-c-proposal-evidence-currentness.v1","schema_id":"governed-execution.nwp-rw0-c-proposal-evidence-currentness-profile.v1"}

rw0-c-decision-time-authority-branch.v1
07384a871dd87a8387c97bb1cd60e6cc8207333428e04e7766044ec8567677dc
{"branches":[{"applicability":"governed","branch":"candidate_acceptance","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"candidate_repair","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"attempt_selecting_replan","governed_effect_class":"author_candidate"},{"applicability":"halt_only","branch":"program_terminal_reject","governed_effect_class":null},{"applicability":"halt_only","branch":"post_execution_program_block","governed_effect_class":null}],"permit_is_executable_authority":false,"precedence":[["snapshot_or_phase_mismatch","conflict"],["parent_or_fence_identity_mismatch","conflict"],["profile_mismatch","conflict"],["support_conflict","conflict"],["halt_only","permit","halt_only_authority_not_applicable"],["authority_denied","deny"],["authority_revoked","deny"],["attempt_fence_expired","deny"],["effect_fence_expired","deny"],["authority_grant_expired","deny"],["authority_observation_expired","deny"],["effect_class_not_allowed","deny"],["authority_status_unknown","unknown"],["family_status_unknown","unknown"],["revocation_status_unknown","unknown"],["otherwise","permit","authority_verified_current"]],"profile_ref":"rw0-c-decision-time-authority-branch.v1","results":["permit","deny","unknown","conflict"],"schema_id":"governed-execution.nwp-rw0-c-decision-time-authority-branch-profile.v1"}

rw0-c-decision-time-source-effect-ceiling-branch.v1
500a7d6ef544251d3592022766b750aadd3313120b8c48dabed78858100ebbe1
{"branches":[{"applicability":"governed","branch":"candidate_acceptance","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"candidate_repair","governed_effect_class":"author_candidate"},{"applicability":"governed","branch":"attempt_selecting_replan","governed_effect_class":"author_candidate"},{"applicability":"halt_only","branch":"program_terminal_reject","governed_effect_class":null},{"applicability":"halt_only","branch":"post_execution_program_block","governed_effect_class":null}],"permit_is_future_effect_authority":false,"precedence":[["snapshot_lineage_or_fence_mismatch","conflict"],["proposal_evidence_conflict","conflict"],["profile_mismatch","conflict"],["support_conflict","conflict"],["halt_only","permit","halt_only_ceiling_not_applicable"],["proposal_evidence_noncompliant","deny"],["attempt_fence_expired","deny"],["effect_fence_expired","deny"],["authority_grant_expired","deny"],["authority_observation_expired","deny"],["effect_class_not_allowed","deny"],["source_effect_exceeds_current_attempt","deny"],["source_effect_exceeds_current_effect","deny"],["source_effect_exceeds_current_authority","deny"],["proposal_evidence_unknown","unknown"],["current_authority_unknown","unknown"],["otherwise","permit","source_effect_within_current_ceilings"]],"profile_ref":"rw0-c-decision-time-source-effect-ceiling-branch.v1","proposal_profile_digest":"950bf044d7d7c7fc7721e732f748d97213413afe501d0ac3d71f726d06a340a0","proposal_profile_ref":"post-execution-source-effect-ceiling.v1","results":["permit","deny","unknown","conflict"],"schema_id":"governed-execution.nwp-rw0-c-decision-time-source-effect-ceiling-branch-profile.v1"}

rw0-c-recommendation-consistency.v1
b85aba9ee6564d53dcb075c5bb60e33a3b923a504c9b38046f2f96aa28f05ebd
{"branch_authority":false,"mapping":{"accept_candidate":"candidate_acceptance","block":"post_execution_program_block","repair_candidate":"candidate_repair","replan":"attempt_selecting_replan","terminal_reject":"program_terminal_reject"},"precedence":[["identity_or_provenance_mismatch","basis_conflict"],["proposal_or_snapshot_not_current","stale_context"],["mapped_branch_equals_authoritative_branch","consistent"],["otherwise","inconsistent"]],"preconditions":["authoritative_branch_already_derived_without_model_recommendation","proposal_currentness_current","all_input_identities_exact"],"profile_ref":"rw0-c-recommendation-consistency.v1","results":["consistent","inconsistent","stale_context","basis_conflict"],"schema_id":"governed-execution.nwp-rw0-c-recommendation-consistency-profile.v1"}
```

[ implementation-detail observation ] All sixteen displayed profile digests were independently reproduced with Python SHA-256 and `/usr/bin/openssl dgst -sha256`.

[ proposed post-execution evidence owner contract ] Golden generated-ref vector:

```text
schema:
governed-execution.nwp-post-execution-support-set.v1

key canonical JSON:
{"entries":[{"ordinal":0,"rank":1,"role":"source_observation","source_digest":"1111111111111111111111111111111111111111111111111111111111111111","source_ref":"source.example.0001","source_schema_id":"governed-execution.example-source.v1"}],"profile_digest":"a53ccecbfa11c0a593536e8eda8ed59bec59f7e145a70cd04599913bf1e72157","profile_ref":"validation-disposition.v1"}

key digest:
84bfbc2430c831c4d46aa867e4a95243d0eb67be685efd7d39ca04ec309f396a

generated ref:
post-support-set.84bfbc2430c831c4d46aa867e4a95243d0eb67be685efd7d39ca04ec309f396a

identity canonical UTF-8 length:
535

identity digest:
e4216c336ed3ad3a267a1efda61e67ab6967ef281125f4122a435be834a31e51
```

Both key and identity digests reproduced with OpenSSL.

# Future committed-recovery logical family

[ proposed future committed-recovery contract ] `RW0CDecisionEvaluationCommandV1` binds:

```text
schema_id
mutation_ref
preassigned_decision_ref
preassigned_receipt_ref
phase_basis_ref
phase_basis_digest
membership_closure_ref
membership_closure_digest
context_ref
context_digest
selected_section41_membership_ref
selected_section41_membership_digest
proposal_ref
proposal_digest
role_resolution_set_digest
current_snapshot_ref
current_snapshot_digest
proposal_currentness_ref
proposal_currentness_digest
authority_matrix_ref
authority_matrix_digest
global_stop_matrix_ref
global_stop_matrix_digest
ceiling_matrix_ref
ceiling_matrix_digest
expected_program_head_revision
expected_program_head_digest
expected_work_head_revision
expected_work_head_digest
expected_selection_head_revision
expected_selection_head_digest
expected_effect_head_revision
expected_effect_head_digest
expected_delivery_head_revision
expected_delivery_head_digest
expected_global_stop_version
expected_global_stop_digest
command_digest
```

It is an input identity, not branch authority.

[ proposed future committed-recovery contract ] Each recovery member has:

```text
role
rank
ordinal
retention_mode
value_schema_id
value_ref
value_digest
retained_value
owner_locator_kind
owner_table
owner_key_fields
member_digest
```

`retention_mode` is `full_value`, `safe_projection`, or `immutable_owner_locator`. `retained_value` is mandatory for full/safe projection and null for an immutable owner locator; owner locator fields have the inverse rule.

[ proposed future committed-recovery contract ] Required retention is:

| Logical member | Retention |
|---|---|
| outer command | full value |
| phase and complete membership closure | full values |
| T1 context and model-input binding | full safe values |
| selected rank-15 C1 membership | immutable membership pair plus full closure entry |
| source invocation, artifact binding, proposal, nine Section 41 rows | immutable typed locators plus a complete safe family projection |
| nine role resolutions | nine full relation values |
| candidate capsule | `CandidateCapsuleSafeProjectionV1` only |
| worker-result binding | full safe C1 value and membership locator |
| validation/review/policy/risk/stop/ceiling | full safe values |
| authority observation | full existing safe value and rank-1 membership locator |
| current snapshot | full value |
| proposal currentness | full value |
| authority/stop/ceiling matrices | full values |
| recommendation consistency | full value |
| later authoritative branch evaluation | full typed value, mandatory once frozen |
| neutral C2B authorization basis | full typed value, mandatory once frozen |
| decision/result/receipt/recovery selector | full typed values and exact locators |

Opaque aggregate digests alone are insufficient for every `full_value` or `safe_projection` member.

[ proposed future committed-recovery contract ] The aggregate manifest is `governed-execution.nwp-rw0-c-committed-recovery-manifest.v1`:

```text
schema_id
recovery_manifest_ref
mutation_ref
command_digest
phase_basis_ref
phase_basis_digest
member_count
members
decision_ref
decision_digest
receipt_ref
receipt_digest
committed_at
recovery_manifest_digest
```

No physical table layout is frozen.

# Restart and replay states

[ proposed future committed-recovery contract ]

```text
before proposal:
  exact supply required

after proposal but before decision:
  exact resupply required
  absence -> no_decision

during uncommitted decision or precommit replay:
  exact resupply required
  mismatch -> basis_conflict
  mutable-head change -> recapture/re-evaluate, never reuse stale snapshot

after commit:
  use retained safe values and immutable locators
  never require transient private supply
  never derive the committed result from later mutable heads
```

[ proposed future committed-recovery contract ] Commit uncertainty requires guarded readback of the future receipt/recovery family. It never authorizes automatic semantic recomputation or a second decision.

# Extended finite assurance matrix

| ID | Classification | Mutant | Required outcome |
|---|---|---|---|
| A01 | proposed post-execution evidence owner contract | Context pair substituted in source invocation | `basis_conflict` |
| A02 | proposed Section 41 role-resolution contract | One T1 role pair differs from its later row | `basis_conflict` |
| A03 | proposed post-execution evidence owner contract | Different canonical value under claimed ref/digest | self-identity failure |
| A04 | proposed post-execution evidence owner contract | Proposal evidence unavailable before invocation | invocation prohibited; zero-row `no_decision` |
| A05 | proposed post-execution evidence owner contract | Exact resupply missing after proposal | `no_decision` |
| A06 | proposed post-execution evidence owner contract | Candidate manifest missing at decision | `no_decision` |
| A07 | proposed post-execution evidence owner contract | Candidate bytes/ref/digest/schema/phase substituted | `basis_conflict` |
| A08 | proposed post-execution evidence owner contract | Profile version or digest substituted | `basis_conflict` |
| A09 | proposed post-execution evidence owner contract | Stale evaluator profile identity | `basis_conflict` |
| A10 | proposed post-execution evidence owner contract | Support role omitted, reordered, duplicated, or substituted | support rejection |
| A11 | proposed Section 41 role-resolution contract | Restart reconstructs nine relations from exact resupply | exact same relation identities |
| A12 | proposed Section 41 role-resolution contract | Composite row locator changed with valid-looking row digest | `basis_conflict` |
| A13 | proposed RW0-C decision-input contract | Paging ends early | `basis_conflict` |
| A14 | proposed RW0-C decision-input contract | Paging cursor does not advance | `basis_conflict` |
| A15 | proposed RW0-C decision-input contract | Page duplicates or reorders a member | `basis_conflict` |
| A16 | proposed RW0-C decision-input contract | 65,537th member exists | `no_decision/membership_closure_overflow` |
| A17 | proposed RW0-C decision-input contract | Current snapshot omits or substitutes a consumed coordinate | `basis_conflict` |
| A18 | proposed post-execution evidence owner contract | Any two expiry fields collapse | schema/profile failure |
| A19 | proposed post-execution evidence owner contract | Invalid validation/review result-reason tuple | tuple rejection |
| A20 | proposed post-execution evidence owner contract | Multiple adverse supports | first frozen precedence reason |
| A21 | proposed future committed-recovery contract | Required typed recovery locator absent | recovery unresolved/family invalid |
| A22 | proposed future committed-recovery contract | Mutable heads advance after commit | original retained result recovered |
| A23 | current owning contract | Closure is treated as C1 completeness authority | owner-boundary failure |
| A24 | current merged implementation | Evidence child inserted before proposal parent | immediate-FK failure |
| A25 | proposed post-execution evidence owner contract | Rank-15 membership claimed at T1 | context-profile failure |
| A26 | proposed post-execution evidence owner contract | Capsule entries/path/body placed in a durable value | privacy-boundary failure |
| A27 | compatibility edge | Generic risk module imports FiniteBacklog adapter | import-boundary failure |
| A28 | proposed RW0-C decision-input contract | Model recommendation influences branch derivation | provenance failure |
| A29 | proposed RW0-C decision-input contract | Same-version stop changes digest/state/update time | `basis_conflict` |
| A30 | proposed RW0-C decision-input contract | Lower stop version supplied | `basis_conflict` |
| A31 | proposed RW0-C decision-input contract | Higher valid stop version | fresh state governs; history remains coherent |
| A32 | proposed future committed-recovery contract | Postcommit recovery asks for private supply | recovery-contract failure |
| A33 | current owning contract | Add C1 kind 16 or change a current kind | inventory failure |
| A34 | current owning contract | Migration/public API/controller/runtime surface changes | boundary/catalog failure |
| A35 | proposed RW0-C decision-input contract | C2B interprets individual evidence instead of neutral basis | owner-boundary failure |

[ proposed post-execution evidence owner contract ] Permanent tests remain ordinary pure semantic, vector, import-boundary, and catalog/public-surface tests. Independent audit owns external mutation, provenance, privacy, and owner-boundary mutants.

# Pure owner-tranche decomposition

[ implementation-detail observation ] A natural migration-free split is:

```text
existing C2A/B1/B2/C1/Section41 semantic owners
        │
        ├──> _post_execution_evidence_values.py
        │      support, validation, review, stop, ceiling,
        │      candidate safe projection, T1 context and supply
        │
        ├──> _post_execution_policy_values.py
        │      standing-policy and generic risk matrices
        │
        ├──> _finite_backlog_risk_source_adapter.py
        │      imports generic risk protocol; never imported by it
        │
        ├──> _section41_post_execution_role_resolution.py
        │      imports evidence values AND policy values
        │
        └──> _rw0_c_decision_input_values.py
               imports evidence values, policy values, and role resolution;
               owns membership closure, current snapshot, fresh matrices,
               recommendation consistency, and logical recovery values
```

[ proposed post-execution evidence owner contract ] Existing C2A modules import none of these. The generic policy/risk module does not import the compatibility adapter. Role resolution and RW0-C explicitly consume the policy values, eliminating the earlier missing edge.

# Remaining seams and stop conditions

[ report-only uncertainty ] The aggregate authoritative branch truth table, selected branch-evaluation value, neutral C2B authorization-basis semantics, physical migration-0005 schema, atomic write plan, and commit-uncertainty implementation remain deliberately unfrozen.

[ report-only uncertainty ] Physical custody and resupply transport remain external. This contract specifies validation of supplied values, not how a caller retrieves them.

[ proposed future committed-recovery contract ] A future commit is prohibited until the branch-evaluation and neutral authorization-basis values have full schemas and are included in the recovery family.

[ current owning contract ] No result here changes Section 41 row meaning, adds a C1 kind, persists capsule entries, makes recommendation authoritative, places FiniteBacklog in generic semantics, gives C2B evidence interpretation, or defines terminal, D/E, cancellation, Git, publication, or ES behavior.

# Recommended next step

[ implementation-detail observation ] The complete migration-free pure-owner tranche is ready for an independent contract audit against this fixed baseline. This is not an implementation allowlist or implementation prompt.

# Confidence

[ report-only uncertainty ] Confidence is high for the T1 equality chain, resupply and privacy boundary, composite locators, total local algebras, exhaustive membership closure, bounded snapshot, and safe committed-recovery inventory. Confidence is intentionally withheld for the later aggregate branch truth table and physical migration/write design.

RW0_POST_EXECUTION_CONTEXT_RESUPPLY_SNAPSHOT_RECOVERY_OWNERS_READY_FOR_INDEPENDENT_AUDIT

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
```
