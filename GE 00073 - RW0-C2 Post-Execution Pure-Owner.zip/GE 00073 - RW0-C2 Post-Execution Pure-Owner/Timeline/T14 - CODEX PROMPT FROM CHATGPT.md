PROMPT_ID

C2B_PROGRESSION_DECISION_OWNER_FINAL_CONTRACT_INDEPENDENT_AUDIT_V1

TITLE

Coordinator C2B — fresh independent audit of the final progression-decision
owner contract before any implementation-boundary freeze

ENGAGEMENT TYPE

Fresh parent-only, local, read-only contract audit.

Do not delegate to subagents.

Do not edit, format, generate repository files, stage, commit, push, create a
branch or PR, merge, tag, release, deploy, fetch, contact a remote/live system,
install dependencies, run tests, execute migrations, open or mutate an
operator database, invoke a product worker/model, or inspect/modify supporting
repositories.

Do not issue an implementation prompt.

Print the complete substantive report inline. Evidence paths may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED MERGED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized. Use local Git metadata only.

If the baseline differs, stop:

C2B_PROGRESSION_DECISION_FINAL_AUDIT_BASELINE_MISMATCH

FIXED INPUT CONTRACT REPORT

The user must attach the exact report being audited as:

Pasted text.txt

Required identity:

size:
48394 bytes

SHA-256:
bfe47094070b87dece8ba216bcc7b32b01563dac10028c18dafaf70cd0873f9b

line count:
739

opening heading:

# Baseline and fixed-input identity

closing token:

C2B_PROGRESSION_DECISION_OWNER_FINAL_RECONCILIATION_READY_FOR_INDEPENDENT_AUDIT

Verify the attachment bytes before substantive inspection.

If the fixed input is missing or differs, stop:

C2B_PROGRESSION_DECISION_FINAL_AUDIT_FIXED_INPUT_MISMATCH

AUDIT PURPOSE

Determine whether the final proposed C2B progression-decision owner contract is
ready for a separate implementation-boundary freeze.

The audit must establish that the contract:

1. is source-grounded in the current merged migration-0002/C2B owners;
2. preserves every current row, enum, field-nullability, reader, public,
   authority, and migration meaning;
3. defines exact owner-neutral command, authorization-basis, evaluation-basis,
   plan, result, receipt, replay, and recovery values;
4. represents all seven profile branches using the six existing persisted
   decision kind/variant pairs;
5. supports both pre-contact and post-execution block without making C2B
   interpret C1/RW0-C evidence;
6. leaves route/productivity and physical latch CAS exclusively to outer
   RW0-C;
7. uses one controller, transaction, timestamp, capability epoch, and commit;
8. is physically representable under unchanged migration-0002 foreign keys,
   unique constraints, and row grammars;
9. has exact three-way recovery and no hidden second truth;
10. contains no unresolved semantic choice that would be deferred to
    implementation.

This is a contract audit, not an implementation audit.

PROJECT BOUNDARIES TO PRESERVE

1. RW0-C1 is merged and current.

2. RW0-C-Decision is a future outer composer:
   - one decision closure per exact C1 phase;
   - one bound existing C2B decision;
   - one outer C result/receipt;
   - accept-only one-way latch CAS;
   - one common transaction and commit.

3. RW0-C-Terminal and migration 0006 remain blocked on D/Execution Substrate
   terminal-evidence ownership.

4. Migration 0005 remains RW0-C-owned and provisional.

5. C2B owns:
   - branch validity;
   - program versions and version membership;
   - accepted-intent revisions;
   - work revisions and heads;
   - revision edges and WorkSpec bindings;
   - progression decisions;
   - result and persisted receipt;
   - C2B replay and recovery.

6. C2B must not import or interpret C1/RW0-C closure, evidence, route,
   productivity, latch, or terminal rows.

7. RW0-C must not choose C2B poststates, numbers, revisions, edges, graph
   roles, row digests, SQL, or CAS specifications.

8. Existing decision kinds, variants, fields, migration-0002 bytes, enums,
   public surfaces, and transaction ownership remain unchanged.

9. No second controller, connection, transaction, mutation slot, commit path,
   public API, external I/O, or supporting-repository change is permitted.

FACT CLASSIFICATION

For every substantive claim use exactly one label:

- current owning contract;
- current merged implementation;
- compatibility edge;
- proposed owner contract;
- contract defect;
- authority/ownership defect;
- report defect;
- implementation-detail observation;
- report-only uncertainty.

Do not silently repair the report. Record required corrections.

SOURCE INSPECTION SCOPE

Inspect together:

Authoritative documentation:

- `.docs/c2b-durable-development-state.md`
- `.docs/c2b2-pure-durable-row-values.md`
- `.docs/c2b2-private-readers.md`
- `.docs/c2b3-program-initialization.md`
- every present C2B3C/C2B3D author-effect document
- `.docs/software-development-progression-boundary.md`
- `.docs/durable-state-model.md`
- `.docs/sqlite-operations-and-recovery.md`
- `.docs/writer-session-authority.md`
- `.docs/authority-boundaries.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/rw0-c1-durable-evidence.md`
- `AGENTS.md`
- `README.md`

Current row/schema/read owners:

- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_development_effect_row_values.py`
- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_row_value_support.py`
- `src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_development_readers.py`
- current private program-initialization writers
- current author-effect writers
- Section 41 selection/disposition owners
- global-stop owners/readers
- `sqlite_transition_transaction.py`
- `sqlite_writer_session.py`
- `sqlite_mutation_transaction_contracts.py`
- `sqlite_transition_select_support.py`

Direct tests pinning:

- decision variant and nullability matrices;
- program/version/membership rows;
- accepted-intent/work-revision/edge rows;
- WorkSpec binding;
- result/receipt/graph construction;
- private readers;
- initialization/effect apply, replay, and recovery;
- global stop;
- controller/writer authority;
- public/import/runtime boundaries.

Resolve actual paths from the repository. Classify inaccurate report paths as
report defects.

Do not run tests, migrations, databases, or external commands.

AUDIT STRUCTURE

Use exactly four bounded, non-nesting parent perspectives:

1. profile/value/owner-boundary audit;
2. schema/FK/branch-write audit;
3. transaction/replay/recovery audit;
4. authority/assurance/readiness audit.

Reconcile all perspectives in one parent verdict.

AUDIT HYPOTHESES

A. FIXED PROFILE IDENTITIES

Independently extract and verify both printed canonical JSON values.

Main C2B owner profile:

```text
expected byte length:
10273

domain:
governed-execution.nwp-development-progression-owner-profile.v1.identity

expected digest:
f1c07181337764b1409a725390db74ac76dfc74240111b7264c000ef6f0a32d6
```

Outer pre-contact basis profile:

```text
expected byte length:
1428

domain:
governed-execution.nwp-rw0-c-pre-contact-block-basis-profile.v1.identity

expected digest:
702a3580c11589cb58471c4aed507b885c20cb02edab22cdacde9ce35b83caca
```

Require exact compact sorted-key UTF-8 identity bytes and domain-NUL hashing.
Use two independent local read-only implementations. A mismatch is High.

Audit that every command, profile binding, receipt, replay proof, recovery
selector, and outer C seam refers to the same final profile pair.

B. CURRENT ROW AND ENUM COMPATIBILITY

For all profile branches verify exact representability under unchanged current
rows:

- `candidate_acceptance`
  -> `accept / candidate_acceptance`
- `candidate_repair`
  -> `repair / candidate_repair`
- `attempt_selecting_replan`
  -> `replan / attempt_selecting_replan`
- `program_terminal_reject`
  -> `terminal_reject / program_terminal_reject`
- `post_execution_program_block`
  -> `block / program_block`
- `pre_contact_program_block`
  -> `block / program_block`
- `effect_cancellation`
  -> `cancel / effect_cancellation`

Verify:

- all 43 decision fields;
- branch nullability;
- reason-code grammar;
- result-version posture;
- selection posture;
- cancellation target/source/preassignments;
- author versus validation/review capsule branch;
- existing result and persisted receipt grammar.

Return BLOCK if any branch needs a new/reinterpreted field, enum, variant, or
migration-0002 change.

C. OWNER-NEUTRAL BOUNDARY

Audit that C2B receives no C1/RW0-C semantic value.

Verify:

- `DevelopmentProgressionAuthorizationBasisV1` is owner-neutral;
- C2B validates Section 41 owner rows, not C1 memberships;
- the pre-contact projection is treated as one exact external authorization
  attestation, not as permission to interpret C1 evidence;
- C2B does not import C1/RW0-C source or reader modules;
- outer C proves the C1-member-to-owner-row relationship;
- the authorization-basis digest closes exact source identity, branch, and
  program/work lineage;
- no C2B row persists C1 phase/member identity.

Challenge whether embedding the outer C pre-contact profile pair in the C2B
owner profile creates an unacceptable owner cycle. ACCEPT only if the
dependency is a one-way versioned authorization interface with no digest cycle
or C-owned state interpretation.

D. PRE-CONTACT AND POST-EXECUTION BLOCK

Verify both branches are exact and cannot be confused.

Post-execution:

- exact Section 41 owner projection;
- current selection;
- recommendation `block`;
- persisted decision selected fields remain null;
- reason `progression.program_blocked_post_execution`.

Pre-contact:

- no Section 41 family;
- exact outer pre-contact attestation/profile;
- at least one explicit evidence member in the outer attestation;
- missing evidence maps to `no_decision`;
- persisted decision selected fields remain null;
- reason `progression.program_blocked_pre_contact`.

Audit the mapping from the previously frozen RW0-C finite block-reason
vocabulary to the 13 pre-contact profile categories. Require a total,
deterministic, non-lossy-enough mapping for authorization and replay. If the
mapping is absent or ambiguous, report Medium or High contract incompleteness.

C2B must not infer a work target beyond the sole-member profile.

E. LATCH-ELIGIBILITY OWNERSHIP

Verify C2B contains no:

- route kind;
- productive-output assertion;
- latch Boolean;
- latch row/CAS;
- C-owned eligibility result.

Verify the completed receipt contains no eligibility field.

Verify outer RW0-C alone composes:

- exact C2B accept result;
- exact decision closure;
- direct-local route attestation;
- productive-output attestation;
- available latch preimage.

Ensure this split creates no missing cross-owner digest or recovery proof.

F. SINGLE-WORK PROFILE

Verify exact SQL and bounded behavior:

```sql
SELECT schema_id, program_ref, program_version_ref, work_item_ref,
       work_item_revision_ref, membership_ordinal, created_at, membership_digest
FROM development_program_version_work_items
WHERE program_ref = ? AND program_version_ref = ?
ORDER BY membership_ordinal ASC, work_item_ref ASC
LIMIT 2
```

Require:

- zero -> integrity failure only if nonempty membership is a current owner
  invariant;
- one coherent ordinal-zero row -> eligible;
- second valid row -> `program_membership_profile_conflict`;
- malformed/gapped/wrong lookup -> integrity failure;
- cancel does not execute the query;
- no change to the frozen 24-query module inventory unless the report
  explicitly and correctly creates a family-local query.

G. BRANCH PRESTATE MATRIX

Independently challenge the allowed shared work states:

```text
planned
active
repair_required
```

for each advancing branch.

Determine whether each is:

- current-owner supported;
- a coherent new versioned profile rule;
- over-permissive;
- under-permissive.

Specifically audit:

- accept from planned, active, repair_required;
- repair from planned, active, repair_required;
- replan from planned, active, repair_required;
- terminal reject and both block branches from active work;
- exclusion of accepted, terminal_rejected, blocked;
- interaction with the current author-effect implementation and future
  repair/replan successor effect establishment.

A profile choice is acceptable only if explicitly versioned, internally
coherent, and not represented as already implemented.

H. AUTHORIZATION-BASIS VALUES

Audit exact schemas, ordered fields, branch unions, digest domains, and
optionality for:

- `DevelopmentProgressionAuthorizationBasisV1`;
- Section 41 post-execution owner projection;
- pre-contact owner authorization;
- effect-cancellation basis.

Verify:

- exactly one nested variant is non-null;
- source owner ref/digest is exact;
- program/version/work/attempt/candidate lineage agrees;
- branch authorization cannot be substituted;
- self-digests exclude only themselves;
- no raw/private C1 content is embedded;
- replay and recovery bind exact authorization-basis digest.

I. COMMAND AND RESULT-ASSIGNMENT GRAMMAR

Verify the exact command fields and nested `result_assignments`.

Audit:

- schema ID and profile pair;
- command digest domain;
- closed-world parsing;
- caller-preassigned versus owner-derived values;
- expected head/member/revision rows;
- stop ref/version;
- per-branch result-assignment nullability;
- no caller-selected state, reason, graph role, timestamp, SQL, or row digest;
- raw WorkSpec/privacy posture;
- canonical bound if one is required.

If the nested result-assignment value needs its own schema/digest but none is
defined, classify the gap.

J. EVALUATION BASIS

Verify exact basis fields and ownership.

Require:

- only authorization basis supplied by the outer composer;
- every current C2B row read inside the active transaction;
- no C1/RW0-C types;
- branch-specific nullability;
- current selection/target-effect reads where required;
- no caller poststate;
- exact basis digest and replay/recovery binding.

Challenge whether pre-contact block legitimately leaves all selection/effect
fields null while still deriving a valid basis decision and program transition.

K. EXACT BRANCH WRITE GRAPH

For each of seven profile branches reconstruct every intended row:

Acceptance:
- decision;
- accepted version;
- sole membership;
- accepted heads;
- no WorkSpec/revision/edge.

Repair:
- decision;
- repair version;
- sole membership;
- same-revision version-specific WorkSpec binding;
- repair_required/active heads;
- successor attempt/candidate preassignments only.

Replan:
- accepted-intent revision;
- same-work replan revision;
- two supersession edges;
- decision;
- replan version;
- sole membership;
- WorkSpec binding;
- planned/active heads.

Terminal reject:
- decision;
- terminal-rejected version/membership/heads.

Both block profiles:
- decision;
- blocked version/membership/heads.

Cancel:
- decision only;
- no membership/version/revision/WorkSpec/edge/head mutation.

Verify exact version/revision numbers, priors, accepted-intent identities,
timestamps, membership ordinals, WorkSpec bindings, edge orientation, and
branch-forbidden rows.

L. MIGRATION-0002 FK AND INSERT ORDER

Derive actual foreign keys and deferral posture from the immutable SQL.

Verify each proposed branch can be inserted legally in its stated order.
Particularly inspect:

- replan revision/edge/decision/version ordering;
- decision reference to resulting version;
- version reference to creating decision;
- WorkSpec reference requirements;
- membership FKs;
- receipt FKs;
- deferred cycles.

A physically illegal or under-specified write order is High.

M. CAS CONTRACT

Verify literal work-head and program-head SQL:

- parameter order;
- complete preimage predicates;
- derived postimage;
- revision increment;
- timestamp;
- digest;
- work-before-program order;
- `rowcount == 1`;
- rollback on zero;
- integrity failure on greater than one;
- no CAS during replay/cancel;
- single private conflict does not leak which internal head raced.

N. GRAPH, RESULT, RECEIPT, AND COMPLETED RECEIPT

Verify:

- exact profile graph-role order for every branch;
- compatibility with the current generic graph-entry helper;
- record ref/digest pairs;
- no persisted graph-entry rows;
- result projection uses new version or basis version as required;
- persisted receipt fields and class;
- receipt-last publication;
- completed-receipt schema and field order;
- digest domain and self-exclusion;
- no latch/route/productivity field;
- outer C can bind its digest without restating C2B semantics.

O. CONFLICT ALGEBRA

Audit the proposed closed preflight and fresh-conflict vocabularies.

Require finite distinctions for:

- mutation-ref reuse;
- authorization-basis conflict;
- program/work CAS aggregate conflict;
- single-work profile conflict;
- selection conflict;
- target-effect conflict;
- stop version/active stop;
- semantic identity collision.

Ensure corruption and operational errors are not misclassified as domain
conflicts.

P. REPLAY AND RECOVERY

Verify receipt-first replay precedes current mutable-state disclosure.

Committed proof must include:

- profile pair;
- command and authorization-basis digests;
- decision;
- every branch row;
- graph;
- result;
- persisted receipt;
- completed-receipt digest;
- outer composed agreement.

Definitely-not-committed must include absence of every selector-owned immutable
locator and no partial/conflicting family.

Unresolved must cover:

- partial nested family;
- outer/nested disagreement;
- latch-only/outer-only/C2B-only fragments;
- digest mismatch;
- cleanup uncertainty.

Verify:

- later unrelated head advancement does not defeat immutable committed proof;
- later unrelated head advancement does not by itself prevent absence proof;
- no same-writer retry;
- fresh fenced writer;
- exact vocabulary `committed_exact`, `definitely_not_committed`, `unresolved`.

Q. GLOBAL STOP

Verify:

- exact current row read;
- command stop ref/version;
- branch stop matrix;
- replay before stop checks;
- historical event reconstruction;
- version-zero seed;
- later stop advancement does not invalidate replay;
- no duplicated stop-state field in decision row.

R. COMPOSITION WITH RW0-C

Verify one-way composition:

- outer C owns C1 snapshot/completeness/block/route/productivity;
- C2B owns progression plan;
- one common controller and transaction;
- C2B nested receipt is uncommitted until outer success;
- C2B rows precede dependent C rows;
- latch CAS only after exact C2B acceptance and outer eligibility;
- outer receipt last;
- mixed fragments unresolved;
- no callable standalone commit path;
- no C import into C2B;
- C cannot choose C2B poststates.

S. AUTHORITY, PRIVACY, AND PUBLIC BOUNDARY

Verify no contract requires:

- migration-0002 changes;
- public package/StateStore/WriterSession changes;
- second controller/connection/commit;
- external I/O;
- generic JSON/BLOB semantic payloads;
- private C1 evidence in C2B;
- C2B latch ownership;
- C2B terminal ownership;
- D/ES physical truth;
- supporting-repository work.

T. ASSURANCE SUFFICIENCY

Determine whether the proposed permanent-test and independent-audit matrix is
finite and causally tied to each claim.

Require coverage for:

- final profile bytes/digest;
- owner-neutral command/basis;
- branch swaps;
- pre-contact/post-execution block;
- latch nonownership;
- single-work zero/one/two;
- every branch prestate;
- exact positive/forbidden rows;
- FK/write order;
- WorkSpec and edges;
- CAS faults;
- graph/result/receipt;
- stop matrix/history;
- replay;
- every write/commit/cleanup fault;
- three-way recovery;
- public/authority nonwidening.

Reject self-protecting tests.

U. CONTRACT COMPLETENESS

The audit may ACCEPT only if:

- both printed profile identities reproduce exactly;
- no semantic dependency cycle remains;
- all seven branches are representable;
- no current owner meaning changes;
- basis/command/plan/result/receipt/recovery contracts are exact;
- pre-contact reason mapping is complete;
- physical insert/CAS ordering is legal;
- no owner decision is deferred to implementation.

Implementation placement and touched paths may remain provisional.

FINDING FORMAT

For every finding report:

- ID;
- type;
- severity: Critical / High / Medium / Low / Observation;
- exact contract;
- source path/line;
- evidence;
- impact;
- required correction;
- uncertainty;
- classification.

Do not silently repair the contract in the audit.

RETURN FORMAT

# Verdict
# Baseline and fixed-input verification
# Profile identity verification
# Source grounding and owner compatibility
# Owner-neutral boundary
# Block-profile audit
# Latch-eligibility boundary
# Single-work profile
# Branch prestate matrix
# Authorization-basis values
# Command, evaluation basis, and plan grammar
# Exact branch write graphs
# Migration-0002 FK and write-order audit
# CAS, global stop, graph, result, and receipts
# Replay and recovery
# Composition with RW0-C
# Authority, privacy, and public boundary
# Assurance architecture
# Severity-ranked finding ledger
# Readiness and next boundary
# Confidence

SUCCESS

Return:

ACCEPT

and exactly:

C2B_PROGRESSION_DECISION_OWNER_CONTRACT_ACCEPTED_READY_FOR_IMPLEMENTATION_BOUNDARY_FREEZE

only if no Critical, High, Medium, or Low contract defect remains.

Otherwise return:

BLOCK

with findings and no implementation prompt.

After ACCEPT, the next step is a separate read-only implementation-boundary
freeze for the combined C2B-owner plus RW0-C-Decision candidate. ACCEPT does not
authorize implementation.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
