PROMPT_ID

RW0_POST_EXECUTION_CANONICAL_PACKAGE_INTERNAL_CONSISTENCY_REPAIR_V1

TITLE

Coordinator RW0 — repair two deterministic internal contradictions in the
delivered canonical audit package, regenerate every dependent identity, and
return one client-visible revised package for formal independent audit

ENGAGEMENT TYPE

Parent-only, local, repository-read-only canonical-package repair.

Do not delegate to subagents or internal audit agents.

Do not edit repository files, stage, commit, push, create a branch or PR,
merge, tag, release, deploy, fetch, contact a remote/live system, install
dependencies, execute tests, run migrations, open or mutate an operator
database, invoke a product worker/model, or inspect/modify supporting
repositories.

You MAY create files only in one fresh private external temporary root for
package reconstruction. Remove disposable intermediates before closeout.

Return the revised package through the client-visible attachment mechanism.
A `/private/tmp`, `/tmp`, or other local path is not a deliverable. If the
response surface cannot attach the complete file, return the delivery blocker.

Do not issue an implementation prompt.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_REPAIR_BASELINE_MISMATCH

FIXED INPUT

Attach exactly:

RW0_Post_Execution_Canonical_Audit_Package.jsonl

Require exactly:

size:
1612437 bytes

SHA-256:
53ebd69d7f58da338a1483a479f7bc8a6ba72d3ccf23bd73139e9b60fe08a674

logical lines / records:
576

final newline:
absent

content aggregate:
78cbdb01a18e5e5d5bd66790a0ac7bc9eeb5ee9aa050beb07187883704905eaf

first record:
package.manifest.v1

last content record:
remaining-seam.S008

final record:
package.closeout.v1

If any property differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_REPAIR_FIXED_INPUT_MISMATCH

MECHANICAL BASELINE ALREADY ESTABLISHED

The fixed package has already independently passed:

- strict UTF-8 JSONL parsing with duplicate-key rejection;
- exact outer and payload canonical re-encoding;
- payload lengths and raw SHA-256;
- all non-null domain-separated digests;
- dense record indexes and unique record IDs;
- closed record-type ordering;
- manifest content-record IDs and hashes;
- content aggregate;
- closeout reconciliation;
- independent OpenSSL and `shasum` whole-file SHA-256.

Do not reopen the package envelope unless required by the two findings below.

FINDING PKG-CONTRACT-001 — STALE REVIEW STATUS VOCABULARY

Current truth in the same package is:

```text
V40 status:
separate | not_separate | unknown | conflict

V15 field:
separation_status

V15 semantic tuples:
separate | not_separate | unknown | conflict
```

But these current records still embed the superseded vocabulary:

```text
behavior-profile.independent-review-disposition.v1
golden.V10.full-evidence-supply
golden.V11.role-supply.08.independent_review
```

Observed stale fragment:

```json
"independence_statuses":
["independent","not_independent","unknown","conflict"]
```

This is not confined to a supersession or malformed-vector record. It is
current canonical truth and contradicts V15/V40.

Required correction:

1. Replace the key with one exact current name, recommended:

```text
separation_statuses
```

2. Use exactly:

```text
separate
not_separate
unknown
conflict
```

3. Verify no current profile, golden value, support value, model-input value,
   or equality record contains:
   - `independence_statuses`;
   - the exact enum `independent`;
   - the exact enum `not_independent`.

Occurrences are allowed only where semantically required in:
- `independent_reviewer`;
- supersession records;
- explicit malformed/substitution vectors.

4. Regenerate the independent-review disposition profile digest and every
dependent current identity, including as applicable:
   - V15 value ref/digest;
   - review support set;
   - rank-8 role supply;
   - full evidence supply;
   - T1 context;
   - model-input binding;
   - source invocation;
   - proposal evidence row and evidence set;
   - proposal;
   - owner-family graph;
   - Section 41 projection;
   - rank-15 value;
   - role-resolution values;
   - downstream current RW0-C input values;
   - manifest, closeout, and package aggregate.

5. Add exact supersession entries for every replaced current profile/value
identity.

FINDING PKG-CONTRACT-002 — EXACT FIELD-ORDER CONTRADICTION

The following primary `value_schema.ordered_fields` records and their governing
behavior profiles contain the same field set but a different exact order:

```text
V14 validation disposition
  moved field: disposition_ref

V15 independent-review disposition
  moved field: disposition_ref

V38 validation result set
  moved field: result_set_ref

V39 review result set
  moved field: result_set_ref

V40 reviewer-separation evaluation
  moved field: evaluation_ref

V43 generic risk source profile
  moved field: source_profile_ref

V44 generic risk source binding
  moved field: source_binding_ref
```

In each governing profile, the generated ref is immediately after `schema_id`.
In the corresponding value-schema record, that ref is placed near the end.
Both representations claim an exact ordered field grammar.

Required correction:

1. Freeze one authoritative order for each affected value.
2. Recommended target: preserve the governing-profile convention:

```text
schema_id
generated_ref
...
self_digest
```

This matches V41/V42 and the profile reference contract.

3. Align:
   - the primary `value_schema.ordered_fields`;
   - governing profile field order;
   - generated-reference preimage;
   - constructor/projection field inventory;
   - malformed vectors;
   - golden canonical values;
   - all dependent identity records.

4. If source inspection proves another order is authoritative, use it
consistently and state the reason. Do not preserve two exact orders.

5. Run an automated package-wide consistency check:

```text
for every primary value schema governed by a behavior profile:
  exact field set equal
  exact field order equal
  schema ID equal
  profile pair equal
  ref posture/preimage equal
  digest posture/self-exclusion equal
```

Nested values must be compared to their literal nested profile definition, not
to the parent top-level field list.

6. No current `value_schema`/profile pair may remain inconsistent.

PRESERVED SEMANTIC DECISIONS

Do not reopen:

- V40 operational reviewer separation;
- the four-result V40 algebra;
- V15 mapping through `separation_status`;
- current C2A/C1 source-owner bindings;
- requirement evidence through `safe_evidence_digest`;
- current generic rank-14 relation binding;
- SHA-1 candidate owner domain;
- owner-authored policy/risk attestations;
- FiniteBacklog adapter boundary;
- two-context design;
- Section 41 projection V2;
- role-resolution V3;
- exact resupply and capsule privacy;
- complete C1 membership closure and bounded current snapshot;
- exactly 15 C1 kinds;
- no migration, persistence, public API, runtime, progression write, latch,
  terminal, D/E, or ES behavior.

Do not change semantics to make hashes convenient.

REVISED DELIVERABLE

Attach exactly one revised file named:

RW0_Post_Execution_Canonical_Audit_Package_V2.jsonl

Use the same JSONL envelope and closed record types.

The package schema may remain:

```text
governed-execution.nwp-post-execution-canonical-audit-package.v1
```

because the envelope format is unchanged. The manifest and closeout
`package_version` may remain `1`; this package was never accepted as a product
contract. Distinguish it by filename and external identity.

Do not add an implementation effect.

REQUIRED VERIFICATION

Before success:

1. Repeat every original mechanical package check.
2. Verify PKG-CONTRACT-001 is closed.
3. Verify PKG-CONTRACT-002 is closed.
4. Verify all profile references/digests in value schemas resolve exactly.
5. Verify every golden value conforms to its literal value schema and governing
   profile.
6. Verify no superseded identity survives outside supersession or dedicated
   malformed-vector records.
7. Verify content-record manifest lists and hashes exactly.
8. Verify content aggregate and closeout.
9. Verify whole-file SHA-256 through two independent local implementations.
10. Recheck the repository baseline and cleanliness.

INLINE REPORT

Print:

- disposition for both finding IDs;
- exact revised filename;
- size;
- SHA-256;
- logical lines / record count;
- final-newline posture;
- per-type counts;
- content aggregate;
- changed record IDs;
- supersession entries added;
- first and final record IDs;
- confirmation that the revised file is visibly attached;
- confirmation that no private filesystem path is offered as the deliverable.

SUCCESS TOKEN

Return exactly:

RW0_POST_EXECUTION_CANONICAL_AUDIT_PACKAGE_REPAIRED_READY_FOR_INDEPENDENT_AUDIT

only if:

- the revised client-visible attachment is present;
- both findings are closed;
- every verification passes;
- repository state is unchanged;
- no implementation prompt is issued.

Otherwise return:

RW0_POST_EXECUTION_CANONICAL_AUDIT_PACKAGE_REPAIR_BLOCKED

and classify the blocker as:

- fixed-input mismatch;
- semantic contradiction;
- regeneration failure;
- canonical verification failure;
- attachment mechanism unavailable;
- baseline mismatch.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
