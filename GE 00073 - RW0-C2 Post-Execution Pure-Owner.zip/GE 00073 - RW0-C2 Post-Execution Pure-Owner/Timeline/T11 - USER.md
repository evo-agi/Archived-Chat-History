Here is Codex's response:

# Baseline and path-grounding correction

[current merged implementation] The local baseline matches exactly: branch `trunk_dev`; HEAD `a3ff0b7f4f0c2378c2962e24612d605489b51638`; tree `d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0`; sole parent `047563de5a443b0f8323401c92979ae2e444d2ed`; subject `feat: implement RW0-C1 durable evidence (#7)`; upstream `origin/trunk_dev`; ahead/behind `0/0`; one worktree; clean index, worktree, untracked, and unmerged state.

[current merged implementation] The upstream comparison used local refs only; no fetch or other remote contact occurred.

[compatibility edge] `src/governed_execution_nwp_coordinator/` does not exist. The authoritative roots are [`src/ge_nwp_coordinator/`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator>) and [`src/ge_nwp_coordinator/sqlite_migrations/`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations>).

[compatibility edge] The preceding response’s citation to `_rw0_c1_durable_evidence_semantic_values.py` was also invalid; the actual source is [`src/ge_nwp_coordinator/_rw0_c1_semantic_values.py`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_c1_semantic_values.py>).

[compatibility edge] The preceding `5779`-byte profile and digest `3a290f…` underbound the reason-code, cancellation-target, selection, and rank-15 membership/value policies. It is superseded by the complete profile below.

[compatibility edge] Early status prose in [`c2b-durable-development-state.md:48`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:48>) still describes a two-migration generation-2 posture, while the merged repository is at migration `0004`; that documentation drift must be corrected with any authorized implementation.

# Preserved owner decisions

[proposed frozen C2B owner contract] One private branch-parameterized family owns exactly `accept/candidate_acceptance`, `repair/candidate_repair`, `replan/attempt_selecting_replan`, `terminal_reject/program_terminal_reject`, `block/program_block`, and `cancel/effect_cancellation`.

[proposed frozen C2B owner contract] All version-advancing branches use the explicit single-work profile; cancellation neither reads nor mutates membership.

[proposed frozen C2B owner contract] C2B owns semantic eligibility, row construction, deterministic postimages, version/revision/edge creation, work-before-program CAS, nested result/receipt, exact replay, readback, and recovery.

[proposed frozen C2B owner contract] RW0-C consumes one bounded private C2B facade inside the common transaction; C2B never imports RW0-C.

[proposed frozen C2B owner contract] No standalone C2B commit path exists: one controller, connection, mutation slot, transaction timestamp, capability epoch, and commit attempt remain authoritative.

[current owning contract] Migration `0005` and the physical acceptance latch remain RW0-C-owned; migrations `0001`–`0004` remain immutable.

[proposed frozen C2B owner contract] C2B emits only the pure assertion that a fresh productive direct-local acceptance is latch-eligible; it neither stores nor CAS-updates that latch.

[current owning contract] The current decision kinds, variants, and nullability are pinned by [`_development_decision_row_values.py:35`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:35>) and immutable [`0002_development_program_and_effect_state.sql:475`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql:475>).

[proposed frozen C2B owner contract] No existing kind, variant, field, state, version kind, work-revision kind, edge kind, or field meaning is added or reinterpreted.

[current owning contract] RW0-C Terminal and migration `0006` remain blocked on D/Execution Substrate terminal-evidence ownership, consistent with [`autonomous-software-development-operating-model.md:586`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/autonomous-software-development-operating-model.md:586>).

# Exact profile identity

[proposed frozen C2B owner contract] The exact profile identity is:

- `schema_id`: `governed-execution.nwp-development-progression-owner-profile.v1`
- `profile_ref`: `c2b-progression-single-work-v1`
- canonicalization: recursively closed JSON; object keys sorted lexicographically; array order preserved; UTF-8; `ensure_ascii=false`; `allow_nan=false`; separators `,` and `:`
- digest domain: `governed-execution.nwp-development-progression-owner-profile.v1.identity`
- digest operation: `SHA-256(domain UTF-8 || 0x00 || canonical bytes)`
- canonical byte length: `7338`
- profile digest: `8a8d67fb444c6d2a79f2a70f98f3dfa02baae0476b270396ea364e029100b4dc`

[proposed frozen C2B owner contract] The following single line is the exact canonical manifest:

```json
{"authority_nonclaims":["no_external_authority","no_executable_permission","no_external_io","no_public_api","no_standalone_commit","no_latch_storage_or_cas","no_multi_work_mutation","no_new_persisted_vocabulary"],"branches":[{"accepted_intent":"retain_basis","allowed_program_states":["active"],"allowed_target_effect_classes":[],"allowed_target_effect_states":[],"allowed_work_states":["planned","repair_required"],"branch":"candidate_acceptance","capsule_policy":"not_applicable","cas_order":["work_item_head","program_head"],"decision_kind":"accept","decision_variant":"candidate_acceptance","global_stop":"clear_required","graph_roles":["program_head_postimage","progression_decision","program_version","work_item_head_postimage","program_version_work_item"],"latch_assertion":"fresh_productive_direct_local_accept_eligible","membership":"copy_sole_basis_member","post_program_state":"accepted","post_work_state":"accepted","reason_code":"progression.candidate_accepted","required_basis":"selected_phase_and_matching_post_execution_member","result_version":"append_accepted_basis_plus_one","revision_edges":[],"section41_recommendation":"accept_candidate","work_revision":"retain_basis","work_spec":"retain_basis_without_new_binding"},{"accepted_intent":"retain_basis","allowed_program_states":["active"],"allowed_target_effect_classes":[],"allowed_target_effect_states":[],"allowed_work_states":["planned","repair_required"],"branch":"candidate_repair","capsule_policy":"not_applicable","cas_order":["work_item_head","program_head"],"decision_kind":"repair","decision_variant":"candidate_repair","global_stop":"clear_required","graph_roles":["program_head_postimage","progression_decision","program_version","work_item_head_postimage","program_version_work_item","work_spec_binding"],"latch_assertion":"none","membership":"copy_sole_basis_member","post_program_state":"active","post_work_state":"repair_required","reason_code":"progression.candidate_repair_required","required_basis":"selected_phase_and_matching_post_execution_member","result_version":"append_repair_basis_plus_one","revision_edges":[],"section41_recommendation":"repair_candidate","work_revision":"retain_basis","work_spec":"append_version_scoped_rebinding_for_successor_attempt"},{"accepted_intent":"append_superseding_revision","allowed_program_states":["active"],"allowed_target_effect_classes":[],"allowed_target_effect_states":[],"allowed_work_states":["planned","repair_required"],"branch":"attempt_selecting_replan","capsule_policy":"not_applicable","cas_order":["work_item_head","program_head"],"decision_kind":"replan","decision_variant":"attempt_selecting_replan","global_stop":"clear_required","graph_roles":["program_head_postimage","accepted_intent_revision","progression_decision","program_version","work_item_head_postimage","work_item_revision","revision_edge","revision_edge","program_version_work_item","work_spec_binding"],"latch_assertion":"none","membership":"same_work_new_revision","post_program_state":"active","post_work_state":"planned","reason_code":"progression.attempt_replanned","required_basis":"selected_phase_and_matching_post_execution_member","result_version":"append_replan_basis_plus_one","revision_edges":["accepted_intent_supersedes","work_item_supersedes"],"section41_recommendation":"replan","work_revision":"append_replan_revision","work_spec":"append_binding_for_new_version_and_revision"},{"accepted_intent":"retain_basis","allowed_program_states":["active"],"allowed_target_effect_classes":[],"allowed_target_effect_states":[],"allowed_work_states":["planned","repair_required"],"branch":"program_terminal_reject","capsule_policy":"not_applicable","cas_order":["work_item_head","program_head"],"decision_kind":"terminal_reject","decision_variant":"program_terminal_reject","global_stop":"clear_or_active","graph_roles":["program_head_postimage","progression_decision","program_version","work_item_head_postimage","program_version_work_item"],"latch_assertion":"none","membership":"copy_sole_basis_member","post_program_state":"terminal_rejected","post_work_state":"terminal_rejected","reason_code":"progression.program_terminal_rejected","required_basis":"selected_phase_and_matching_post_execution_member","result_version":"append_terminal_rejected_basis_plus_one","revision_edges":[],"section41_recommendation":"terminal_reject","work_revision":"retain_basis","work_spec":"retain_basis_without_new_binding"},{"accepted_intent":"retain_basis","allowed_program_states":["active"],"allowed_target_effect_classes":[],"allowed_target_effect_states":[],"allowed_work_states":["planned","repair_required"],"branch":"program_block","capsule_policy":"not_applicable","cas_order":["work_item_head","program_head"],"decision_kind":"block","decision_variant":"program_block","global_stop":"clear_or_active","graph_roles":["program_head_postimage","progression_decision","program_version","work_item_head_postimage","program_version_work_item"],"latch_assertion":"none","membership":"copy_sole_basis_member","post_program_state":"blocked","post_work_state":"blocked","reason_code":"progression.program_blocked","required_basis":"selected_phase_and_matching_post_execution_member","result_version":"append_blocked_basis_plus_one","revision_edges":[],"section41_recommendation":"block","work_revision":"retain_basis","work_spec":"retain_basis_without_new_binding"},{"accepted_intent":"no_change","allowed_program_states":["active","accepted","terminal_rejected","blocked"],"allowed_target_effect_classes":["author_candidate","validate_candidate","review_candidate"],"allowed_target_effect_states":["ready_for_delivery","delivery_pending","delivery_outcome_unknown","observed"],"allowed_work_states":[],"branch":"effect_cancellation","capsule_policy":"author_forbids_pair_validate_review_require_pair","cas_order":[],"decision_kind":"cancel","decision_variant":"effect_cancellation","global_stop":"clear_or_active","graph_roles":["progression_decision"],"latch_assertion":"none","membership":"not_read_or_written","post_program_state":"unchanged","post_work_state":"not_read_or_written","reason_code":"progression.effect_cancellation_planned","required_basis":"selected_phase_exact_target_effect_and_cancellation_source","result_version":"basis_version_no_new_row","revision_edges":[],"section41_recommendation":null,"work_revision":"no_change","work_spec":"no_change"}],"canonicalization":"compact_sorted_key_utf8_json","command_schema_id":"governed-execution.nwp-record-development-progression-decision-command.v1","profile_pair_bindings":["command","completed_receipt_projection","rw0_c_closure_attestation","replay_proof","recovery_selector_and_proof"],"profile_ref":"c2b-progression-single-work-v1","recovery_outcomes":["committed_exact","definitely_not_committed","unresolved"],"schema_id":"governed-execution.nwp-development-progression-owner-profile.v1","section41_binding":"advancing_branches_bind_rank15_membership_and_value_pairs_cancel_binds_none","selection_binding":"complete_current_k8_selection_head_preimage","single_work_applicability":"all_version_advancing_branches_only","single_work_query":{"fetch_count":257,"logical_maximum":256,"profile_conflict":"progression_profile_requires_exactly_one_work_item","required_membership_count":1,"required_ordinal":0},"timestamp_ownership":"one_outer_transaction_timestamp"}
```

[implementation detail] The manifest was generated only in process memory, canonicalized with the repository’s compact sorted-key rule, hashed with Python `hashlib`, and independently cross-checked by OpenSSL over the same domain-NUL-manifest bytes; both returned `8a8d67fb444c6d2a79f2a70f98f3dfa02baae0476b270396ea364e029100b4dc`.

[proposed frozen C2B owner contract] The exact profile pair is present in the command, completed-receipt projection, RW0-C closure attestation, exact replay proof, and recovery selector/proof.

# Exact command grammar

[current merged implementation] The reserved schema ID `governed-execution.nwp-record-development-progression-decision-command.v1` already exists in the closed receipt vocabulary at [`_development_decision_row_values.py:72`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:72>).

[proposed frozen C2B owner contract] The exact command domain is that schema ID plus `.identity`; its digest is derived and is not a caller field.

[proposed frozen C2B owner contract] The exact ordered command fields are:

```text
01 schema_id
02 owner_profile_ref
03 owner_profile_digest
04 branch
05 mutation_ref
06 decision_ref
07 program_ref
08 phase_basis_ref
09 phase_basis_digest
10 section41_membership_ref
11 section41_membership_digest
12 section41_post_execution_proposal_family_member_ref
13 section41_post_execution_proposal_family_member_digest
14 basis_decision_ref
15 basis_decision_digest
16 basis_program_version_ref
17 basis_program_version_number
18 basis_program_version_digest
19 expected_program_head
20 expected_sole_membership
21 expected_sole_work_head
22 expected_sole_work_revision
23 coding_global_stop_ref
24 coding_global_stop_version
25 expected_global_stop_preimage
26 selection_head_preimage
27 target_effect_intent_ref
28 target_effect_class
29 target_effect_fence_ref
30 target_effect_fence_digest
31 expected_target_effect_head
32 originating_command_ref
33 originating_command_digest
34 target_capsule_manifest_ref
35 target_portable_capsule_digest
36 source_directive_ref
37 source_directive_digest
38 source_evidence_ref
39 source_evidence_digest
40 resulting_program_version_ref
41 resulting_accepted_intent_revision_ref
42 resulting_work_item_revision_ref
43 accepted_intent_edge_ref
44 work_item_edge_ref
45 resulting_work_spec_ref
46 resulting_work_spec_safe_projection
47 replan_source_intent_ref
48 replan_source_intent_digest
49 replan_safe_projection_digest
50 preassigned_semantic_attempt_ref
51 preassigned_candidate_ref
52 preassigned_effect_intent_ref
53 preassigned_effect_fence_ref
54 preassigned_delivery_attempt_ref
```

[proposed frozen C2B owner contract] Refs are exact built-in safe-ref strings; digests are exact lowercase 64-hex strings; `basis_program_version_number` is a positive exact built-in integer; `coding_global_stop_version` is non-negative; `branch` is one of the six profile branches.

[proposed frozen C2B owner contract] Fields 19–22, 25–26, and 31 are sealed typed complete preimages, not mappings: existing program head, membership, work head, work revision, global-stop current row, 41-field selection head, and effect head respectively.

[proposed frozen C2B owner contract] A preimage includes its already-persisted digest where that table has one, but C2B recomputes and rereads it; no caller supplies any resulting row digest or postimage.

[current merged implementation] The rank-15 value contains the exact identities `schema_id`, value ref, phase-basis pair, source-invocation pair, artifact pair and binding digest, proposal pair, model-contract pair, model-configuration pair, context schema/ref/digest, safe-projection schema/digest, evidence-set pair/count, recommendation, reason, proposal timestamp, owner-family graph digest, and derived value digest at [`_rw0_c1_semantic_values.py:872`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_c1_semantic_values.py:872>).

[current owning contract] Later C2 closure must bind the exact C1 membership pair, not merely the wrapped owner-value pair; [`rw0-c1-durable-evidence.md:108`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-c1-durable-evidence.md:108>) preserves that distinction.

[proposed frozen C2B owner contract] Advancing commands require both rank-15 pairs and require the member’s embedded phase basis to equal fields 8–9. Cancellation requires all four rank-15 membership/value fields null.

[proposed frozen C2B owner contract] The complete selection-head preimage binds the exact K8 tuple: program, semantic attempt, candidate, effect intent, author command, attempt fence, effect fence, and delivery attempt; the current K8 definition is at [`_development_pre_execution_plan_disposition_contracts.py:48`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py:48>).

[proposed frozen C2B owner contract] Advancing recommendation mapping is exact: `accept_candidate→candidate_acceptance`, `repair_candidate→candidate_repair`, `replan→attempt_selecting_replan`, `terminal_reject→program_terminal_reject`, and `block→program_block`.

[proposed frozen C2B owner contract] Branch optionality is exact:

| Classification | Branch | Additional required fields | Required-null branch fields |
|---|---|---|---|
| proposed frozen C2B owner contract | All six | Profile pair, mutation/decision/program, phase basis, basis decision/version, program-head/global-stop/selection preimages | Every branch-only field not listed |
| proposed frozen C2B owner contract | All advancing | Both Section 41 pairs, sole membership/head/revision, resulting version | Cancellation target/source/effect preassignments |
| proposed frozen C2B owner contract | Acceptance | None beyond common advancing fields | New intent/work revision/edges/WorkSpec, successor, cancellation fields |
| proposed frozen C2B owner contract | Repair | Result WorkSpec ref/projection and successor attempt/candidate | Replan intent/work revision/edges and cancellation fields |
| proposed frozen C2B owner contract | Replan | Result intent/work revision/two edge refs/WorkSpec, source-intent triple, successor attempt/candidate | Cancellation fields |
| proposed frozen C2B owner contract | Terminal reject | None beyond common advancing fields | New intent/work revision/edges/WorkSpec, successor, cancellation fields |
| proposed frozen C2B owner contract | Block | None beyond common advancing fields | New intent/work revision/edges/WorkSpec, successor, cancellation fields |
| proposed frozen C2B owner contract | Cancellation | Target effect/class/fence/head, originating command pair, source directive/evidence pairs, preassigned effect/fence/delivery | Both Section 41 pairs, sole-work values, new version/revision/edge/WorkSpec, successor attempt/candidate |
| proposed frozen C2B owner contract | Cancel author target | Both capsule fields null | — |
| proposed frozen C2B owner contract | Cancel validate/review target | Both capsule fields present | — |

[proposed frozen C2B owner contract] Redundant values must agree exactly: stop scalars with the complete stop preimage; basis fields with immutable basis rows; selection K8 with the selection head; Section 41 membership/value/phase pairs with one another; WorkSpec ref with its safe projection; and cancellation fields with the target lineage.

[proposed frozen C2B owner contract] The caller supplies identities and existing safe semantic projections only. C2B derives states, numbers, timestamps, postimages, row digests, relation-key digests, reason codes, graph roles/order, SQL, result/receipt values, and latch eligibility.

[proposed frozen C2B owner contract] Command canonicalization is compact sorted-key UTF-8 JSON; the digest is `SHA-256(command-domain UTF-8 || 0x00 || canonical bytes)`; canonical bytes are bounded to `1..32768`.

[proposed frozen C2B owner contract] `resulting_work_spec_safe_projection` is the exact current 16-field safe value at [`_development_program_row_values.py:564`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_program_row_values.py:564>); its semantic digest is verified, while the new durable binding digest is derived by C2B.

# Exact branch decision-row matrix

[current merged implementation] The durable projection has exactly 43 fields, and current constructor tests pin their order and variant nullability at [`test_c2b2_development_decision_row_values.py:16`](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2b2_development_decision_row_values.py:16>).

[proposed frozen C2B owner contract] Legend: `C` is a validated caller-preassigned identity; `B` is copied from an authoritative basis row; `S` is copied from verified selection lineage; `T` is copied from the cancellation target; `D` is C2B-derived; `N` is SQL `NULL`.

| # | Field | Accept | Repair | Replan | Terminal | Block | Cancel |
|---:|---|---|---|---|---|---|---|
| 1 | `schema_id` | D | D | D | D | D | D |
| 2 | `mutation_ref` | C | C | C | C | C | C |
| 3 | `decision_ref` | C | C | C | C | C | C |
| 4 | `program_ref` | C/B | C/B | C/B | C/B | C/B | C/B |
| 5 | `decision_kind` | D `accept` | D `repair` | D `replan` | D `terminal_reject` | D `block` | D `cancel` |
| 6 | `decision_variant` | D `candidate_acceptance` | D `candidate_repair` | D `attempt_selecting_replan` | D `program_terminal_reject` | D `program_block` | D `effect_cancellation` |
| 7 | `basis_decision_ref` | B | B | B | B | B | B |
| 8 | `basis_program_version_ref` | B | B | B | B | B | B |
| 9 | `basis_program_version_number` | B | B | B | B | B | B |
| 10 | `expected_program_head_revision` | B | B | B | B | B | B |
| 11 | `resulting_program_version_ref` | C | C | C | C | C | N |
| 12 | `resulting_program_version_number` | D `basis+1` | D `basis+1` | D `basis+1` | D `basis+1` | D `basis+1` | N |
| 13 | `selected_semantic_attempt_ref` | S | S | S | S | N | S |
| 14 | `selected_candidate_ref` | S | S | S | S | N | S |
| 15 | `selected_attempt_fence_ref` | S | S | S | S | N | S |
| 16 | `selected_attempt_fence_digest` | S | S | S | S | N | S |
| 17 | `target_effect_intent_ref` | N | N | N | N | N | T |
| 18 | `target_effect_class` | N | N | N | N | N | T |
| 19 | `target_effect_fence_ref` | N | N | N | N | N | T |
| 20 | `target_effect_fence_digest` | N | N | N | N | N | T |
| 21 | `expected_target_effect_head_revision` | N | N | N | N | N | T |
| 22 | `target_delivery_attempt_ref` | N | N | N | N | N | N |
| 23 | `originating_command_ref` | N | N | N | N | N | T |
| 24 | `originating_command_digest` | N | N | N | N | N | T |
| 25 | `target_capsule_manifest_ref` | N | N | N | N | N | C for validate/review; N for author |
| 26 | `target_portable_capsule_digest` | N | N | N | N | N | C for validate/review; N for author |
| 27 | `coding_global_stop_ref` | B | B | B | B | B | B |
| 28 | `coding_global_stop_version` | B | B | B | B | B | B |
| 29 | `source_directive_ref` | N | N | N | N | N | C |
| 30 | `source_directive_digest` | N | N | N | N | N | C |
| 31 | `source_evidence_ref` | N | N | N | N | N | C |
| 32 | `source_evidence_digest` | N | N | N | N | N | C |
| 33 | `preassigned_semantic_attempt_ref` | N | C | C | N | N | N |
| 34 | `preassigned_candidate_ref` | N | C | C | N | N | N |
| 35 | `preassigned_effect_intent_ref` | N | N | N | N | N | C |
| 36 | `preassigned_effect_fence_ref` | N | N | N | N | N | C |
| 37 | `preassigned_delivery_attempt_ref` | N | N | N | N | N | C |
| 38 | `resulting_accepted_intent_revision_ref` | N | N | C | N | N | N |
| 39 | `resulting_work_item_ref` | N | N | D sole member | N | N | N |
| 40 | `resulting_work_item_revision_ref` | N | N | C | N | N | N |
| 41 | `reason_code` | D `progression.candidate_accepted` | D `progression.candidate_repair_required` | D `progression.attempt_replanned` | D `progression.program_terminal_rejected` | D `progression.program_blocked` | D `progression.effect_cancellation_planned` |
| 42 | `decided_at` | D outer timestamp | D | D | D | D | D |
| 43 | `decision_digest` | D | D | D | D | D | D |

[proposed frozen C2B owner contract] Reason codes come solely from the profile manifest. Section 41’s reason remains bound by the member digest but is never copied into the decision row.

# Branch preconditions and postimages

| Classification | Branch | Exact preconditions | Exact postimage |
|---|---|---|---|
| proposed frozen C2B owner contract | Acceptance | Program `active`; sole work `planned` or `repair_required`; clear stop; exact K8 selection with disposition `selected_for_dispatch_gates`; exact rank-15 membership/value pairs; recommendation `accept_candidate`; coherent selected attempt/candidate/effect/delivery; productive observation | Append version kind `accepted`, number `basis+1`; retain intent/work revision; one ordinal-0 membership; work head `accepted`; program head `accepted`; no edge or WorkSpec row |
| proposed frozen C2B owner contract | Repair | Same state/selection/clear-stop rules; recommendation `repair_candidate`; successor attempt/candidate and result WorkSpec identities collision-free | Append version kind `repair`; retain intent/work revision; one membership; append version-scoped WorkSpec rebinding; work head `repair_required`; program head `active`; no edge |
| proposed frozen C2B owner contract | Replan | Same state/selection/clear-stop rules; recommendation `replan`; source-intent and all result identities collision-free | Append intent revision, work revision kind `replan`, version kind `replan`, one membership, WorkSpec binding, `accepted_intent_supersedes` edge, and `work_item_supersedes` edge; heads become `planned`/`active` |
| proposed frozen C2B owner contract | Terminal reject | Program `active`; work `planned` or `repair_required`; clear or active stop; exact selection and rank-15 recommendation `terminal_reject` | Append `terminal_rejected` version; retain intent/work revision; one membership; both heads `terminal_rejected`; no edge or WorkSpec row |
| proposed frozen C2B owner contract | Block | Program `active`; work `planned` or `repair_required`; clear or active stop; exact selection and rank-15 recommendation `block`, although persistent selected fields remain null | Append `blocked` version; retain intent/work revision; one membership; both heads `blocked`; no edge or WorkSpec row |
| proposed frozen C2B owner contract | Cancellation | Program state any of the four closed states; no membership/work read; clear or active stop; exact selected lineage; target class author/validate/review; target effect state ready/pending/unknown/observed; capsule rule satisfied | Insert only decision and nested receipt; no program/version/work/effect head or membership mutation |

[current owning contract] Active stop blocks accept, repair, and productive replan but permits terminal reject, block, and cancel; exact replay precedes fresh stop checks. See [`c2b-durable-development-state.md:503`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:503>).

[proposed frozen C2B owner contract] Every advancing program-head revision and work-head revision becomes its preimage revision plus one and uses the one outer timestamp.

[proposed frozen C2B owner contract] Repair creates a new WorkSpec binding because the successor author effect is bound to the new program version, while the safe semantic scope and work revision remain unchanged.

[current owning contract] C2B preassigns repair/replan successor attempt and candidate refs but author-effect establishment owns creation of the later semantic-attempt/effect family, as stated at [`c2b-durable-development-state.md:367`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:367>).

# Single-work query contract

[proposed frozen C2B owner contract] Query ID: `progression_single_work_membership_profile`.

[proposed frozen C2B owner contract] Exact SQL:

```sql
SELECT schema_id, program_ref, program_version_ref, work_item_ref,
       work_item_revision_ref, membership_ordinal, created_at,
       membership_digest
FROM development_program_version_work_items
WHERE program_ref = ? AND program_version_ref = ?
ORDER BY membership_ordinal ASC, work_item_ref ASC
LIMIT 257
```

[proposed frozen C2B owner contract] The reader executes one `fetchmany(257)` and accepts only exact built-in tuples in the displayed eight-column order.

| Classification | Observation | Result |
|---|---|---|
| proposed frozen C2B owner contract | Zero rows | `database_integrity_failure` |
| proposed frozen C2B owner contract | One coherent row at ordinal zero | Profile admitted |
| proposed frozen C2B owner contract | Two through 256 coherent, dense, unique rows | `progression_profile_requires_exactly_one_work_item` |
| proposed frozen C2B owner contract | 257 rows | `database_integrity_failure` for bounded overflow |
| proposed frozen C2B owner contract | Malformed tuple/digest/relation, duplicate, gap, or nonzero sole ordinal | `database_integrity_failure` |

[current owning contract] Zero membership violates the existing nonempty dense program-version membership invariant, so it is corruption rather than merely an unsupported profile. The current bound and ordering are pinned in [`c2b2-private-readers.md:142`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b2-private-readers.md:142>) and [`_sqlite_development_reader_contracts.py:452`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py:452>).

[proposed frozen C2B owner contract] This family-local query does not alter the frozen twenty-four-query C2B2 inventory.

# Immutable write-plan contract

[proposed frozen C2B owner contract] The sealed plan schema is `governed-execution.nwp-development-progression-write-plan.v1`; variants are exactly the six branch names.

[proposed frozen C2B owner contract] Exact ordered fields:

```text
schema_id
owner_profile_ref
owner_profile_digest
branch
command_digest
decision_row
accepted_intent_revision_row
work_item_revision_row
program_version_row
membership_rows
work_spec_binding_row
revision_edge_rows
work_head_cas
program_head_cas
mutation_graph_entries
progression_result
mutation_receipt_row
completed_receipt_projection
```

[proposed frozen C2B owner contract] Every row is an existing exact private row-value type; optional rows are typed `None`; repeated rows are immutable tuples. Raw SQL, generic mappings, JSON/BLOB semantic payloads, caller-selected states, and caller-selected graph roles are forbidden.

| Classification | Variant | Populated plan rows |
|---|---|---|
| proposed frozen C2B owner contract | Accept, terminal, block | Decision, version, one membership, both CAS specs, graph, result, receipt, completed projection |
| proposed frozen C2B owner contract | Repair | The preceding population plus one WorkSpec binding |
| proposed frozen C2B owner contract | Replan | Intent revision, work revision, decision, version, membership, WorkSpec binding, two ordered edges, both CAS specs, graph, result, receipt, completed projection |
| proposed frozen C2B owner contract | Cancel | Decision, graph, result, receipt, completed projection only |

[proposed frozen C2B owner contract] CAS value schemas are `governed-execution.nwp-development-progression-work-head-cas.v1` and `governed-execution.nwp-development-progression-program-head-cas.v1`, each ordered as `schema_id`, `expected_preimage`, `resulting_postimage`.

[proposed frozen C2B owner contract] Replan relation-key digests use domain `governed-execution.nwp-development-revision-edge-relation-key.v1.identity` over exactly `program_ref`, `revision_edge_kind`, both accepted-intent endpoints, and both work-revision endpoints.

# SQL and private reader contracts

[current merged implementation] Exact row-column authority remains in [`_development_program_row_values.py:35`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_program_row_values.py:35>), [`_development_effect_row_values.py:44`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_effect_row_values.py:44>), and [`_development_decision_row_values.py:35`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:35>).

[proposed frozen C2B owner contract] Projection aliases expand exactly as follows; `D43` is the decision order printed above.

```text
R19 = schema_id, mutation_ref, mutation_family, command_schema_id,
      command_digest, program_ref, decision_ref, result_program_version_ref,
      result_semantic_attempt_ref, result_effect_intent_ref,
      result_effect_fence_ref, result_delivery_attempt_ref,
      result_observation_ref, result_decision_ref, result_class,
      result_projection_digest, mutation_graph_digest, outcome, committed_at

PH8 = schema_id, program_ref, current_program_version_ref,
      current_program_version_number, head_revision, program_state,
      updated_at, head_digest

PV9 = schema_id, program_version_ref, program_ref, program_version_number,
      program_version_kind, creating_decision_ref,
      accepted_intent_revision_ref, created_at, program_version_digest

AI10 = schema_id, accepted_intent_revision_ref, program_ref,
       accepted_intent_revision_number, prior_accepted_intent_revision_ref,
       source_intent_ref, source_intent_digest, safe_projection_digest,
       created_at, accepted_intent_revision_digest

WH9 = schema_id, work_item_ref, program_ref, current_work_item_revision_ref,
      current_work_item_revision_number, head_revision, work_state,
      updated_at, head_digest

WR10 = schema_id, work_item_revision_ref, program_ref, work_item_ref,
       work_item_revision_number, work_item_revision_kind,
       prior_work_item_revision_ref, accepted_intent_revision_ref,
       created_at, work_item_revision_digest

M8 = schema_id, program_ref, program_version_ref, work_item_ref,
     work_item_revision_ref, membership_ordinal, created_at, membership_digest

E11 = schema_id, revision_edge_ref, relation_key_digest, program_ref,
      revision_edge_kind, from_accepted_intent_revision_ref,
      to_accepted_intent_revision_ref, from_work_item_revision_ref,
      to_work_item_revision_ref, created_at, revision_edge_digest

WS18 = schema_id, work_spec_ref, program_ref, program_version_ref,
       accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
       repository_ref, base_git_object_format, base_git_oid,
       authorized_paths_json, validation_requirement_ref,
       review_requirement_ref, privacy_classification, work_spec_digest,
       safe_projection_digest, recorded_at, work_spec_binding_digest

SA13 = schema_id, semantic_attempt_ref, program_ref, program_version_ref,
       accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
       attempt_number, candidate_ref, attempt_phase, selection_decision_ref,
       created_at, semantic_attempt_digest

AF37 = schema_id, attempt_fence_ref, parent_standing_grant_ref,
       parent_standing_grant_digest, attempt_authorization_ref,
       attempt_authorization_digest, program_ref, program_version_ref,
       accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
       semantic_attempt_ref, repository_ref, base_git_object_format,
       base_git_oid, path_ceiling_json, allowed_effect_class_mask,
       aggregate_max_active_invocations, aggregate_max_candidate_bytes,
       aggregate_max_changed_files, aggregate_max_cost_microusd,
       aggregate_max_cpu_seconds, aggregate_max_deliveries,
       aggregate_max_deployments, aggregate_max_local_commits,
       aggregate_max_memory_bytes, aggregate_max_merges,
       aggregate_max_model_input_tokens, aggregate_max_model_output_tokens,
       aggregate_max_pull_requests, aggregate_max_pushes,
       aggregate_max_wall_seconds, expires_at, global_stop_ref,
       global_stop_version, attempt_fence_digest, recorded_at

AE14 = schema_id, authority_evaluation_ref, program_ref, evaluation_scope,
       evaluation_subject_ref, semantic_attempt_ref, effect_intent_ref,
       authority_ref, authority_digest, authority_state, reason_code,
       expires_at, evaluated_at, authority_evaluation_digest

EI14 = schema_id, effect_intent_ref, program_ref, program_version_ref,
       semantic_attempt_ref, effect_class, candidate_ref, command_ref,
       basis_decision_ref, cancellation_target_effect_intent_ref,
       expected_target_effect_head_revision, portable_capsule_digest,
       created_at, effect_intent_digest

EF47 = schema_id, effect_fence_ref, parent_standing_grant_ref,
       parent_standing_grant_digest, effect_authorization_ref,
       effect_authorization_digest, attempt_fence_ref, attempt_fence_digest,
       program_ref, program_version_ref, accepted_intent_revision_ref,
       work_item_ref, work_item_revision_ref, semantic_attempt_ref,
       effect_intent_ref, effect_class, command_ref, command_digest,
       candidate_ref, repository_ref, base_git_object_format, base_git_oid,
       path_ceiling_json, effect_max_active_invocations,
       effect_max_candidate_bytes, effect_max_changed_files,
       effect_max_cost_microusd, effect_max_cpu_seconds,
       effect_max_deliveries, effect_max_deployments,
       effect_max_local_commits, effect_max_memory_bytes, effect_max_merges,
       effect_max_model_input_tokens, effect_max_model_output_tokens,
       effect_max_pull_requests, effect_max_pushes, effect_max_wall_seconds,
       expires_at, global_stop_ref, global_stop_version,
       portable_capsule_digest, cancellation_target_effect_intent_ref,
       cancellation_target_effect_fence_ref,
       cancellation_target_effect_fence_digest, effect_fence_digest,
       recorded_at

EH9 = schema_id, effect_intent_ref, program_ref, current_effect_fence_ref,
      head_revision, effect_state, cancellation_effect_intent_ref,
      updated_at, head_digest

DH8 = schema_id, effect_intent_ref, program_ref,
      current_delivery_attempt_ref, head_revision, delivery_state,
      updated_at, head_digest

DA21 = schema_id, delivery_attempt_ref, program_ref, program_version_ref,
       command_ref, command_digest, semantic_attempt_ref, effect_intent_ref,
       attempt_fence_ref, attempt_fence_digest, effect_fence_ref,
       effect_fence_digest, adapter_kind, adapter_safe_correlation_ref,
       delivery_envelope_digest, delivery_kind, delivery_number,
       predecessor_delivery_attempt_ref, basis_decision_ref, recorded_at,
       delivery_attempt_digest

SH41 = schema_id, program_ref, program_version_ref,
       accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
       semantic_attempt_ref, candidate_ref, effect_intent_ref,
       author_command_ref, author_command_digest, attempt_fence_ref,
       attempt_fence_digest, effect_fence_ref, effect_fence_digest,
       delivery_attempt_ref, delivery_envelope_digest, current_proposal_ref,
       current_disposition_ref, current_disposition, head_revision,
       updated_at, program_version_number, semantic_attempt_digest,
       attempt_number, basis_decision_ref, basis_decision_digest,
       work_spec_ref, work_spec_digest, work_spec_safe_projection_digest,
       effect_intent_digest, standing_grant_ref, standing_grant_digest,
       attempt_authorization_ref, attempt_authorization_digest,
       effect_authorization_ref, effect_authorization_digest,
       delivery_attempt_digest, authority_evaluation_ref,
       authority_evaluation_digest, head_digest

GS10 = singleton_id, schema_id, version, active, stop_id, reason_class,
       issuer_ref, issued_at, operator_decision_ref, updated_at

GSE18 = event_ref, event_sequence, idempotency_key, command_digest, action,
        source_version, resulting_version, outcome, reason,
        operator_decision_ref, resulting_global_stop_ref, resulting_status,
        schema_id, event_json, event_digest, replay_global_stop_json,
        replay_global_stop_digest, created_at
```

[proposed frozen C2B owner contract] Receipt-first and basis queries are exact explicit-column parameterized statements with no ordering and `LIMIT 2`: `R19 WHERE mutation_ref=?`; `D43 WHERE program_ref=? AND decision_ref=?`; `PH8 WHERE program_ref=?`; `PV9 WHERE program_ref=? AND program_version_ref=? AND program_version_number=?`; `AI10 WHERE program_ref=? AND accepted_intent_revision_ref=?`; `WH9 WHERE program_ref=? AND work_item_ref=?`; `WR10 WHERE program_ref=? AND work_item_ref=? AND work_item_revision_ref=?`; and `WS18 WHERE program_ref=? AND program_version_ref=? AND work_item_ref=? AND work_item_revision_ref=?`.

[current merged implementation] Those projections and predicates reuse the current private reader specifications at [`_sqlite_development_reader_contracts.py:382`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py:382>).

[proposed frozen C2B owner contract] Selection uses `SH41` with equality predicates for all eight K8 fields and `LIMIT 2`; selected dependencies reuse current `SA13`, `EI14`, author-command, `AF37`, `EF47`, `AE14`, `EH9`, `DH8`, and `DA21` readers.

[proposed frozen C2B owner contract] Section 41 membership and wrapped owner rows remain RW0-C-owned reads. RW0-C supplies the verified neutral basis to C2B; C2B binds the exact pairs but does not duplicate or import RW0-C reader code.

[proposed frozen C2B owner contract] Collision probes use full projections and `LIMIT 2` for every unique route:

```text
D43:  decision_ref=?
D43:  mutation_ref=?
PV9:  program_version_ref=?
PV9:  program_ref=? AND program_version_number=?
AI10: accepted_intent_revision_ref=?
AI10: program_ref=? AND accepted_intent_revision_number=?
WR10: work_item_revision_ref=?
WR10: program_ref=? AND work_item_ref=? AND work_item_revision_number=?
E11:  revision_edge_ref=?
E11:  relation_key_digest=?
WS18: work_spec_ref=?
WS18: program_ref=? AND program_version_ref=? AND work_item_ref=? AND work_item_revision_ref=?
SA13: semantic_attempt_ref=?
SA13: program_ref=? AND candidate_ref=?
EI14: effect_intent_ref=?
EF47: effect_fence_ref=?
DA21: delivery_attempt_ref=?
```

[proposed frozen C2B owner contract] Immutable inserts are literal `INSERT INTO` statements using exactly `AI10`, `WR10`, `D43`, `PV9`, `M8`, `WS18`, `E11`, or `R19` as applicable, with an identical fixed placeholder count and no caller-selected table or column.

[proposed frozen C2B owner contract] Full readback uses both primary and alternate unique locators, reconstructs exact typed rows, verifies stored digests and cross-record relations, rereads both heads after CAS, and recomputes graph, result, receipt, and completed projection.

[proposed frozen C2B owner contract] Every reader validates inputs before capability borrow, accepts only the nominal transaction capability, executes one fixed statement, performs the specified bounded fetch, requires built-in tuples, and closes its cursor without owning the connection.

[proposed frozen C2B owner contract] Zero rows mean either a named freshness conflict or invariant failure according to the queried role; two rows, malformed rows, impossible missing invariant rows, and digest/relation failures are `database_integrity_failure`; SQLite operational failures are `mutation_failed`.

# CAS and write order

[proposed frozen C2B owner contract] Exact work-head CAS:

```sql
UPDATE development_work_item_heads
SET current_work_item_revision_ref = ?,
    current_work_item_revision_number = ?,
    head_revision = ?,
    work_state = ?,
    updated_at = ?,
    head_digest = ?
WHERE schema_id = ?
  AND program_ref = ?
  AND work_item_ref = ?
  AND current_work_item_revision_ref = ?
  AND current_work_item_revision_number = ?
  AND head_revision = ?
  AND work_state = ?
  AND updated_at = ?
  AND head_digest = ?
```

[proposed frozen C2B owner contract] Exact program-head CAS:

```sql
UPDATE development_program_heads
SET current_program_version_ref = ?,
    current_program_version_number = ?,
    head_revision = ?,
    program_state = ?,
    updated_at = ?,
    head_digest = ?
WHERE schema_id = ?
  AND program_ref = ?
  AND current_program_version_ref = ?
  AND current_program_version_number = ?
  AND head_revision = ?
  AND program_state = ?
  AND updated_at = ?
  AND head_digest = ?
```

[proposed frozen C2B owner contract] Assignment parameters are complete derived postimages; predicate parameters are complete supplied-and-reread preimages. Each statement requires `rowcount == 1`; `rowcount > 1` is `database_integrity_failure`.

[proposed frozen C2B owner contract] A zero-row miss from either CAS is the single private conflict `program_head_conflict`, because this one-work profile treats both heads as one progression aggregate and does not expose separately retryable work authority.

[proposed frozen C2B owner contract] Work CAS always precedes program CAS. Any conflict or pre-commit failure rolls back the complete transaction; replay performs neither CAS.

[proposed frozen C2B owner contract] Exact branch write order:

- Acceptance, terminal, block: decision → version → membership → work CAS → program CAS → receipt → full readback.
- Repair: decision → version → membership → WorkSpec binding → work CAS → program CAS → receipt → full readback.
- Replan: accepted-intent revision → work revision → decision → version → membership → WorkSpec binding → accepted-intent edge → work edge → work CAS → program CAS → receipt → full readback.
- Cancellation: decision → receipt → full readback.

[current owning contract] Deferred foreign-key cycles remain enabled throughout; foreign keys are never disabled, as recorded at [`c2b-durable-development-state.md:190`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:190>).

# Mutation-graph contract

[current merged implementation] A graph entry is exactly `role`, `ordinal`, `record_ref`, `record_digest`; tuple order is significant; duplicate `(role,ordinal)` or `(role,record_ref)` pairs fail. The current helper is at [`_development_decision_row_values.py:921`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:921>).

| Classification | Branch | Exact ordered `(role, ordinal)` |
|---|---|---|
| proposed frozen C2B owner contract | Accept, terminal, block | `program_head_postimage/0`, `progression_decision/0`, `program_version/0`, `work_item_head_postimage/0`, `program_version_work_item/0` |
| proposed frozen C2B owner contract | Repair | The preceding five, then `work_spec_binding/0` |
| proposed frozen C2B owner contract | Replan | `program_head_postimage/0`, `accepted_intent_revision/0`, `progression_decision/0`, `program_version/0`, `work_item_head_postimage/0`, `work_item_revision/0`, `revision_edge/0`, `revision_edge/1`, `program_version_work_item/0`, `work_spec_binding/0` |
| proposed frozen C2B owner contract | Cancel | `progression_decision/0` |

[proposed frozen C2B owner contract] Record pairs are: program ref/head digest; intent ref/revision digest; decision ref/decision digest; version ref/version digest; work ref/head digest; work-revision ref/revision digest; edge ref/edge digest; membership work ref/membership digest; WorkSpec ref/binding digest.

[current merged implementation] The graph digest preimage is the 18 receipt fields other than `mutation_graph_digest`, followed by the ordered entry mappings; the domain is the development mutation-receipt identity domain. See [`_development_decision_row_values.py:961`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:961>).

[proposed frozen C2B owner contract] Graph entries are not persistent SQL rows. Only the existing receipt’s `mutation_graph_digest` is stored, so no field addition or role reinterpretation is required.

# Result and completed-receipt digest

[current merged implementation] The existing progression result order is `schema_id`, `program_ref`, `decision_ref`, `result_program_version_ref`, `result_decision_ref`, `result_projection_digest`; its identity excludes the last field. See [`_development_decision_row_values.py:436`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:436>).

[proposed frozen C2B owner contract] Advancing branches use the new version ref; cancellation uses the unchanged basis version; `result_decision_ref` always equals `decision_ref`.

[proposed frozen C2B owner contract] The nested receipt is existing `R19` with family `record_development_progression_decision`, the reserved command schema and digest, decision and result-version refs, `result_decision_ref=decision_ref`, class `development_progression_decision_recorded`, all attempt/effect/fence/delivery/observation result refs null, `outcome=committed`, and the outer timestamp.

[proposed frozen C2B owner contract] The pure completed projection schema is `governed-execution.nwp-development-progression-completed-receipt-projection.v1`, domain `<schema>.identity`, with exact order:

```text
schema_id
owner_profile_ref
owner_profile_digest
branch
mutation_ref
command_digest
program_ref
decision_ref
result_program_version_ref
result_projection_digest
mutation_graph_digest
committed_at
fresh_productive_direct_local_accept_latch_eligible
receipt_mapping
completed_receipt_digest
```

[proposed frozen C2B owner contract] `receipt_mapping` is the complete `R19` mapping; the identity excludes only `completed_receipt_digest`.

[proposed frozen C2B owner contract] Latch eligibility is true only for a fresh acceptance with verified productive output and `adapter_kind=direct_local_bootstrap`; replay reconstructs that historical value. It is false for every other branch or transport.

[proposed frozen C2B owner contract] No SQL column stores this projection. RW0-C binds its digest, profile pair, mutation ref, and command digest in its closure attestation without restating branch semantics.

[proposed frozen C2B owner contract] Missing, extra, malformed, digest-mismatched, or partially present family rows never yield a smaller successful receipt.

# Replay and recovery selector

[current merged implementation] The established vocabulary is exactly `committed_exact`, `definitely_not_committed`, and `unresolved` at [`_rw0_c1_semantic_values.py:275`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_c1_semantic_values.py:275>).

[proposed frozen C2B owner contract] `committed_exactly` is invalid vocabulary and is not retained as an alias.

[proposed frozen C2B owner contract] Recovery-selector schema: `governed-execution.nwp-development-progression-recovery-selector.v1`; domain: `<schema>.identity`; exact order:

```text
schema_id
owner_profile_ref
owner_profile_digest
branch
mutation_ref
command_digest
program_ref
phase_basis_ref
phase_basis_digest
section41_membership_ref
section41_membership_digest
section41_post_execution_proposal_family_member_ref
section41_post_execution_proposal_family_member_digest
decision_ref
basis_decision_ref
basis_decision_digest
basis_program_version_ref
basis_program_version_number
basis_program_version_digest
result_program_version_ref
result_program_version_number
resulting_accepted_intent_revision_ref
resulting_accepted_intent_revision_number
resulting_work_item_ref
resulting_work_item_revision_ref
resulting_work_item_revision_number
accepted_intent_edge_ref
accepted_intent_edge_relation_key_digest
work_item_edge_ref
work_item_edge_relation_key_digest
resulting_work_spec_ref
resulting_work_spec_safe_projection_digest
replan_source_intent_ref
replan_source_intent_digest
replan_safe_projection_digest
preassigned_semantic_attempt_ref
preassigned_candidate_ref
target_effect_intent_ref
target_effect_class
target_effect_fence_ref
target_effect_fence_digest
originating_command_ref
originating_command_digest
target_capsule_manifest_ref
target_portable_capsule_digest
source_directive_ref
source_directive_digest
source_evidence_ref
source_evidence_digest
preassigned_effect_intent_ref
preassigned_effect_fence_ref
preassigned_delivery_attempt_ref
expected_program_head
expected_sole_membership
expected_sole_work_head
expected_sole_work_revision
expected_global_stop_preimage
expected_selection_head_preimage
expected_target_effect_head_preimage
selector_digest
```

[proposed frozen C2B owner contract] The selector is constructed before apply from the validated command and deterministic successor numbers/relation keys; its compact canonical bound is `1..65536` bytes and its identity excludes only `selector_digest`.

[proposed frozen C2B owner contract] Cancellation uses the basis version as result, nulls all Section 41 and new version/revision/edge/WorkSpec fields, and retains every target/source/preassigned cancellation identity. Advancing branches use every applicable result locator.

[proposed frozen C2B owner contract] Recovery probes receipt by mutation; decision by decision and mutation; version by ref and `(program,number)`; membership by key and ordinal; WorkSpec by ref and owner tuple; intent/work revision/edges by primary and unique relation keys; successor attempt by attempt ref and candidate; and cancellation effect/fence/delivery by each preassigned ref.

[proposed frozen C2B owner contract] `committed_exact` requires matching outer closure/receipt and nested receipt, exact profile and command bindings, every mandatory branch row, exact row/graph/result/completed digests, historical stop proof, and either current heads equal to the C2B postimages or a bounded exact chain of later progression.

[proposed frozen C2B owner contract] `definitely_not_committed` requires absence of outer receipt, nested receipt, decision, every branch-created row, and every downstream preassigned locator, plus exact head preimages or a bounded later chain that excludes this selector. Cancellation requires the absence proof but no head comparison.

[proposed frozen C2B owner contract] `unresolved` covers any partial family, conflicting locator, malformed evidence, digest mismatch, outer/nested disagreement, unprovable head lineage, or proof depth beyond 256.

[proposed frozen C2B owner contract] Later-head proof walks at most 256 immutable versions and creating decisions/receipts, requires contiguous decreasing version numbers and exact basis links, and reconstructs every deterministic membership/head transition.

[proposed frozen C2B owner contract] A complete C2B fragment without its RW0-C closure and outer receipt is `unresolved`; latch-only and outer-only fragments are also `unresolved`.

[current owning contract] Commit-attempt or cleanup uncertainty forbids automatic same-writer retry; a new session may perform evidence-only recovery, consistent with [`c2b-durable-development-state.md:938`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:938>).

# Global-stop historical binding

[current merged implementation] Current rows use the exact ten fields in [`persistence_contracts.py:174`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/persistence_contracts.py:174>); events use the exact eighteen fields at [`persistence_contracts.py:240`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/persistence_contracts.py:240>); version zero is the literal clear seed in [`0001_initial.sql:402`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0001_initial.sql:402>).

[proposed frozen C2B owner contract] The command binds both stop ref/version and the complete ten-field current-row preimage. Fresh evaluation rereads singleton `1`, requires exact equality, and applies the profile stop matrix.

[proposed frozen C2B owner contract] The decision persists only `coding_global_stop_ref` and `coding_global_stop_version`; it intentionally does not duplicate mutable stop state.

[proposed frozen C2B owner contract] Historical reconstruction uses:

```sql
SELECT event_ref, event_sequence, idempotency_key, command_digest, action,
       source_version, resulting_version, outcome, reason,
       operator_decision_ref, resulting_global_stop_ref, resulting_status,
       schema_id, event_json, event_digest, replay_global_stop_json,
       replay_global_stop_digest, created_at
FROM global_stop_events
WHERE outcome = 'accepted' AND resulting_version = ?
ORDER BY event_sequence ASC
LIMIT 2
```

[proposed frozen C2B owner contract] The reader calls `fetchmany(2)`. Version zero must match the literal seed. Every positive version must yield exactly one accepted event whose canonical event/replay digests, source/result versions, resulting ref/status, operator decision, and timestamp validate; event `created_at` reconstructs that version’s historical `updated_at`.

[proposed frozen C2B owner contract] Zero positive-version events, two events, malformed replay JSON, or any relation/digest mismatch is `database_integrity_failure`; advancement of the mutable current row does not invalidate exact historical proof.

# Composition seam with RW0-C

[proposed frozen C2B owner contract] Pure evaluator entry: `_evaluate_development_progression_decision(*, command, basis, decided_at) -> DevelopmentProgressionWritePlanV1`.

[proposed frozen C2B owner contract] Bounded active-transaction facade: `_record_development_progression_decision_in_active_transaction(*, capability, command, basis, decided_at) -> DevelopmentProgressionCompletedReceiptProjectionV1`.

[proposed frozen C2B owner contract] The facade may read, evaluate, write, and read back but may not begin, commit, roll back, close, or own a connection.

[proposed frozen C2B owner contract] Common executor: `_run_atomic_rw0_c_decision_transaction(...)`; it alone owns the operation lease, mutation slot, bound connection, `BEGIN IMMEDIATE`, writer fence, capability epoch, timestamp, invalidation, rollback, commit attempt, close, and outcome resolution.

[proposed frozen C2B owner contract] Exact call order:

1. `[proposed frozen C2B owner contract]` Closed-world command/profile/selector preflight.
2. `[proposed frozen C2B owner contract]` Acquire operation lease and mutation slot.
3. `[proposed frozen C2B owner contract]` Open one bound connection, begin immediate, revalidate managed state, and fence writer issuance.
4. `[proposed frozen C2B owner contract]` Read outer receipt first and nested C2B receipt second.
5. `[proposed frozen C2B owner contract]` Resolve replay or mutation-ref conflict before mutable basis disclosure.
6. `[proposed frozen C2B owner contract]` Verify C1 closure basis, selection lineage, current C2B rows, stop, membership, and collisions.
7. `[proposed frozen C2B owner contract]` Capture one whole-second UTC timestamp.
8. `[proposed frozen C2B owner contract]` Invoke the C2B facade exactly once.
9. `[proposed frozen C2B owner contract]` Complete nested insert/CAS/readback and completed-projection verification.
10. `[proposed frozen C2B owner contract]` Perform RW0-C’s latch CAS only for eligible fresh direct-local acceptance.
11. `[proposed frozen C2B owner contract]` Write and read back RW0-C closure/member/attestation rows.
12. `[proposed frozen C2B owner contract]` Insert and read back the outer receipt last.
13. `[proposed frozen C2B owner contract]` Permanently invalidate the capability.
14. `[proposed frozen C2B owner contract]` Attempt one commit.
15. `[proposed frozen C2B owner contract]` Close and prove cleanup before returning a fresh result.

[current merged implementation] The common controller already owns nominal capability epochs, transaction opening, timestamps, rollback, commit, and cleanup mechanics in [`sqlite_transition_transaction.py:718`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_transition_transaction.py:718>) and [`sqlite_transition_transaction.py:3299`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_transition_transaction.py:3299>).

[proposed frozen C2B owner contract] Nested completion occurs only after receipt insertion, complete in-transaction readback, and graph/result/completed-projection recomputation; it is not yet a committed result.

[proposed frozen C2B owner contract] RW0-C converts its verified C1 objects into a C2B-owned neutral basis value. C2B does not import RW0-C types or readers.

[proposed frozen C2B owner contract] No C2B entry can commit the nested family without RW0-C closure and the outer receipt in this slice.

# Assurance and independent-audit plan

| Classification | Permanent claim | Independent challenge |
|---|---|---|
| proposed frozen C2B owner contract | Profile bytes/digest | Hard-coded 7338-byte literal, independent domain digest, one-byte/key/order/reason/member-binding mutants |
| proposed frozen C2B owner contract | Command union | Literal 54-field oracle; missing/extra/type and cross-branch non-null mutants |
| proposed frozen C2B owner contract | Section 41 identity | Membership/value collapse, wrong rank/member, phase-pair mismatch, recommendation mismatch |
| proposed frozen C2B owner contract | Decision rows/reasons | Literal 43-column tuples and every forbidden nullability mutation |
| proposed frozen C2B owner contract | Single-work query | Literal SQL plus external zero/one/two/gap/duplicate/257-row fixtures |
| proposed frozen C2B owner contract | Positive plans | One literal plan oracle per branch, including repair rebinding |
| proposed frozen C2B owner contract | Forbidden writes | Assert cancellation emits only decision/receipt and other branches emit no unowned row |
| proposed frozen C2B owner contract | Membership/version | Independent ordinal, revision, and version-number fixtures |
| proposed frozen C2B owner contract | Replan structure | Independent intent/work-revision/edge/relation-key/WorkSpec digest oracles |
| proposed frozen C2B owner contract | CAS | Literal SQL/parameter order, work-before-program trace, rowcount 0/1/>1 |
| proposed frozen C2B owner contract | Stop matrix/history | Clear/active matrix and advanced-current historical-event fixtures |
| proposed frozen C2B owner contract | Graph/result/receipt | Reordered entries, duplicate role/ref, envelope mutants, result-scalar contradictions |
| proposed frozen C2B owner contract | Replay/conflict | Same mutation/digest replay; different digest conflict; stale-basis no-write trace |
| proposed frozen C2B owner contract | Fault closure | Fault before/after each write, CAS, readback, invalidation, commit, rollback, and close |
| proposed frozen C2B owner contract | Recovery | Literal selector and all three outcomes; later-head depths 0, 1, 256, and 257 |
| proposed frozen C2B owner contract | Authority non-widening | Import/export/source checks for no public API, external I/O, second controller, or standalone commit |

[proposed frozen C2B owner contract] Permanent tests must use literal expected values or independently built SQL fixtures; production builders cannot manufacture their own expected oracle.

[proposed frozen C2B owner contract] The independent audit must include graph-order mutants, rank-15 membership/value substitution, row-nullability mutants, stop-history corruption, unique-locator collision, CAS rowcount faults, partial outer/nested families, and commit/cleanup uncertainty.

[proposed frozen C2B owner contract] Clean/live validation belongs only to a later authorized implementation audit; none was run here.

# Path-correct provisional surface

[report-only uncertainty] This inventory uses only paths that currently exist; it is provisional, not an implementation allowlist, and intentionally does not invent future filenames.

| Classification | Category | Existing path-grounded surface |
|---|---|---|
| implementation detail | Must change for the C2B owner contract | [`.docs/c2b-durable-development-state.md`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md>) and the existing documentation/source/test parent directories [`.docs/`](</Users/ds/Repositories/Governed Execution Coordinator/.docs>), [`src/ge_nwp_coordinator/`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator>), and [`tests/`](</Users/ds/Repositories/Governed Execution Coordinator/tests>) |
| implementation detail | Must change for common private composition | [`src/ge_nwp_coordinator/sqlite_transition_transaction.py`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_transition_transaction.py>) |
| implementation detail | Must change later for RW0-C Decision/0005 | [`src/ge_nwp_coordinator/sqlite_migration.py`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migration.py>), [`src/ge_nwp_coordinator/sqlite_migrations/`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations>), [`src/ge_nwp_coordinator/`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator>), [`tests/`](</Users/ds/Repositories/Governed Execution Coordinator/tests>), and RW0 documentation under [`.docs/`](</Users/ds/Repositories/Governed Execution Coordinator/.docs>) |
| report-only uncertainty | May change after consumer/source-hash audit | [`.docs/autonomous-software-development-operating-model.md`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/autonomous-software-development-operating-model.md>), [`.docs/software-development-progression-boundary.md`](</Users/ds/Repositories/Governed Execution Coordinator/.docs/software-development-progression-boundary.md>), [`README.md`](</Users/ds/Repositories/Governed Execution Coordinator/README.md>), [`AGENTS.md`](</Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md>), and source-hash/import-oracle tests under [`tests/`](</Users/ds/Repositories/Governed Execution Coordinator/tests>) |
| current owning contract | Protected | Existing migration files [`0001_initial.sql`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0001_initial.sql>) through [`0004_rw0_c1_durable_evidence.sql`](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql>); existing row meanings/nullability; frozen reader inventory; public package, `StateStore`, and writer-session surfaces; all supporting repositories |

[proposed frozen C2B owner contract] The frozen twenty-four-query module remains unchanged; progression-family locators and collision probes belong beside the new private family inside the existing source package.

# Remaining seams and stop conditions

[proposed frozen C2B owner contract] No upstream C2B semantic choice remains: profile, rank-15 binding, command, branch rows, postimages, query bounds, CAS, graph, result, receipt, replay, stop history, recovery, and composition ownership are closed.

[reopened owner seam] RW0-C still owns the physical latch row/CAS, closure/member/attestation row schemas, outer receipt, and migration `0005`; those consumer choices must bind the exact profile pair and completed-receipt digest frozen here.

[current owning contract] RW0-C Terminal, migration `0006`, RW0-D, RW0-E, and Execution Substrate terminal evidence remain outside this freeze.

[compatibility edge] The stale early C2B migration/status prose must be reconciled when repository changes are authorized.

[proposed frozen C2B owner contract] Work must stop if implementation would alter migration-0002 bytes, existing decision semantics/nullability, closed vocabularies, introduce generic semantic payloads, accept caller-selected states/edges/roles/SQL, add a second transaction or commit path, make C2B import RW0-C, widen a public API, perform external I/O, or weaken exact recovery proof.

# Recommended next step

[proposed frozen C2B owner contract] Independently audit this corrected exact freeze first; then perform a dedicated implementation-boundary audit of the combined C2B-owner plus RW0-C-Decision candidate; only after both pass should one integrated implementation candidate with separate modules and one transaction authority be considered for authorization.

[proposed frozen C2B owner contract] This is an audit recommendation, not an implementation prompt or implementation authorization.

# Confidence

[proposed frozen C2B owner contract] Confidence is high: the corrected profile now binds reason policy, cancellation policy, complete selection preimage, and both rank-15 membership/value identities, while preserving current migration-0002 row grammar, bounded readers, mutation-graph helper, stop-event history, and common-controller authority.

[report-only uncertainty] Only the later touched-file inventory remains provisional pending consumer and source-hash inspection; it does not leave a C2B semantic choice open.

C2B_PROGRESSION_DECISION_OWNER_FREEZE_RECONCILED_READY_FOR_INDEPENDENT_AUDIT

REPOSITORY_MUTATION_NOT_PERFORMED  
TESTS_NOT_RUN  
MIGRATIONS_NOT_RUN  
STAGING_NOT_PERFORMED  
COMMIT_NOT_PERFORMED  
PUSH_NOT_PERFORMED  
PR_NOT_CREATED  
REMOTE_CONTACT_NOT_PERFORMED  
WORKER_OR_MODEL_NOT_INVOKED  
SUPPORTING_REPOSITORIES_NOT_MODIFIED  
IMPLEMENTATION_NOT_PERFORMED  
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED  
RW0_C_DECISION_NOT_IMPLEMENTED  
RW0_C_TERMINAL_NOT_IMPLEMENTED  
RW0_D_NOT_IMPLEMENTED  
RW0_E_NOT_IMPLEMENTED  
EXECUTION_SUBSTRATE_NOT_MODIFIED
