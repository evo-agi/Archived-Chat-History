# Decision

**Accept Codex’s blocker. Do not audit or implement migration `0005` yet.**

The reconciliation successfully fixes the C-local defects we sent back:

- C1’s `LIMIT 257` is now correctly treated as paginated lookahead, not a total phase-membership ceiling.
- RW0-C introduces a separate, versioned closure ceiling rather than changing C1.
- Rank 14 is now represented through distinct `present`, `finite_failure`, and `absent` bases without inventing a rank-13 worker result.
- Missing C1 membership no longer becomes proof of an external negative fact.
- Decision-time membership is an immutable transaction-observed snapshot, while later C1 admissions remain legal.
- The consumed latch now directly binds the decision, decision closure, outer result, program version, candidate, and capsule. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

Those are meaningful corrections. The proposed six-table C-local schema is now internally structured enough to preserve as a **provisional downstream contract**.

## The new blocker is real

The remaining problem is not an RW0-C modeling defect. It is missing C2B owner semantics.

The merged repository currently freezes:

- decision kinds and variants;
- field nullability;
- immutable program/work/version/revision row shapes;
- the nested progression result;
- the generic mutation receipt envelope.

It does **not** yet own the write-side progression transition for the advancing decisions. Codex found that the exact program/work state changes, work-revision behavior, membership changes, revision edges, and CAS graph are not frozen for:

- `accept / candidate_acceptance`;
- `repair / candidate_repair`;
- `replan / attempt_selecting_replan`;
- `terminal_reject / program_terminal_reject`;
- `block / program_block`.

Only `cancel / effect_cancellation` is sufficiently bounded as a non-version-advancing decision. :chatgpt-content-reference{index="4"}

This means RW0-C cannot safely decide, for example:

- whether accept retains the current work revision or creates another;
- whether repair merely changes the work-head state;
- whether replan targets the same work item, creates another work item, or uses supersession/split/merge edges;
- which work heads a program-wide block affects;
- how multi-work programs behave;
- the exact order and recovery graph of program-version, membership, revision, edge, and head writes.

Those are C2B progression semantics. Letting `_sqlite_rw0_c_decision.py` choose them would silently make RW0-C the owner of C2B state progression.

Therefore the correct disposition is exactly the one Codex returned:

```text
RW0_C_OWNER_RECONCILIATION_REQUIRED
```

## What remains provisionally accepted

The following should remain stable while the owner seam is resolved:

```text
RW0-C decomposition:
Decision first, Terminal later

one decision per C1 phase:
accepted

decision-time C1 snapshot:
ordered, paginated, immutable, later admissions allowed

rank-14 branch algebra:
present / finite_failure / absent

block semantics:
explicit evidence required; missing membership alone is insufficient

acceptance latch:
one state-root-scoped singleton; accept-only one-way CAS

migration 0005:
provisional six-table C schema

migration 0006:
blocked on D/ES terminal owners
```

The proposed `1024` closure-member ceiling is a reasonable finite engineering precaution, but it and its profile digest remain provisional until independent audit; Codex explicitly did not independently reproduce the digest. :chatgpt-content-reference{index="5"}

The terminal blocker also remains unchanged: current owners still lack exact process-group, descendant, authenticated teardown, terminal capsule-custody, source-receipt, and route-currentness values and readers. Migration `0006` remains forbidden. :chatgpt-content-reference{index="6"}

# Next step: C2B owner contract

The next work must be a **read-only C2B progression-decision write-contract reconciliation**, not an RW0-C implementation pass.

The key decision is not merely what each branch writes. The pass must also define the composition seam:

- C2B owns a closed branch-specific evaluation and write plan.
- The common transaction controller executes that plan in the same transaction as the RW0-C closure and accept-only latch.
- There is no nested transaction, second connection, second mutation slot, or second commit.
- RW0-C supplies the selected branch and exact closure evidence but cannot choose C2B post-states, revisions, memberships, or edges.
- C2B readback and recovery remain independently reconstructable inside the outer RW0-C recovery graph.

It must also decide whether the C2B owner capability should land independently before RW0-C-Decision, or whether both may be introduced in one candidate while remaining separate owner modules and separately auditable seams.

## Codex handoff

Send this prompt to the existing Coordinator Codex conversation:

:chatgpt-content-reference{index="12"}[Download the C2B progression-decision owner-contract reconciliation prompt](sandbox:/mnt/data/Coordinator_C2B_Progression_Decision_Write_Owner_Contract_Reconciliation_Prompt.txt)

```text
Filename:
Coordinator_C2B_Progression_Decision_Write_Owner_Contract_Reconciliation_Prompt.txt

Size:
19,727 bytes

SHA-256:
056ca16897bfab793aa35acea7a42bd7dc873f1b6f59b1b248d84343419d128c
```

It is read-only and does not authorize implementation.

The successful result is:

```text
C2B_PROGRESSION_DECISION_WRITE_OWNER_CONTRACT_READY_FOR_INDEPENDENT_AUDIT
```

Otherwise it must return:

```text
C2B_PROGRESSION_DECISION_OWNER_RECONCILIATION_BLOCKED
```

with the exact upstream decision that remains unresolved.

## Current project state

```text
RW0-C1:
merged and current

RW0-C-Decision C-local contract:
substantially reconciled, provisional

C2B advancing-decision write owner:
not frozen; current critical-path blocker

migration 0005:
not implementation-authorized

RW0-C-Terminal / migration 0006:
blocked on D/ES owner contracts

RW0-D:
not implemented

RW0-E:
not implemented
```

### Sources

- Attached RW0-C-Decision reconciliation report. :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"} :chatgpt-content-reference{index="10"} :chatgpt-content-reference{index="11"}

**Confidence:** High that the C-local defects are closed enough to preserve; high that C2B owner reconciliation is required before migration `0005` can be finalized; high that RW0-C must not select progression post-states on C2B’s behalf.

The current attachment was fully readable. Older expired uploads would need to be re-uploaded only if a later pass requires their contents directly.
