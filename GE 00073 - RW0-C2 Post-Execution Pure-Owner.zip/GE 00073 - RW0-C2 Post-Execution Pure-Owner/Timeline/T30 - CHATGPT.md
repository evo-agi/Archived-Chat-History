# Decision

**Accept the `BLOCK`. Do not rerun this same audit and do not move toward implementation.**

The audit was procedurally nonconformant—it used internal audit agents despite the parent-only instruction and briefly created then removed bytecode. That prevents the report from serving as a formal acceptance attestation. It does **not** neutralize the blocking findings. Because the verdict is already `BLOCK`, the correct move is to repair the owner contract, then run a fresh, clean parent-only audit against the replacement freeze.

The two Critical findings change the architecture priority:

1. **A coherent Section 41 proposal is evidence, not semantic decision authority.**
2. **A durable authority digest is not fresh permission. RW0-C needs a decision-time authority/currentness evaluation with branch-specific global-stop rules.**

The next owner boundary should therefore be:

```text
Section 41
  owns coherent proposal-family evidence and model recommendation

RW0-C-Decision
  reconstructs typed safe evidence
  derives the authoritative semantic branch independently
  evaluates fresh authority/currentness/global stop
  selects one exact decision-time closure
  issues the authorization attestation

C2B
  consumes one neutral authorization basis
  validates lineage and performs the progression transition
  does not inspect C1 evidence or model output
```

## What remains preserved

The audit passed the mechanical identity chain and much of the existing decomposition. Preserve:

- RW0-C1 as evidence presence, not completeness.
- Section 41’s family-coherence ownership.
- Pre-contact missing/pending evidence as `no_decision`.
- One common controller, transaction, timestamp, capability epoch, and commit.
- Outer RW0-C ownership of the physical latch and CAS.
- No duplicate C2B cancel-evidence table.
- Existing B1/B2/C1/C2A and migration-`0002` row meanings.
- The reserved `effect_cancellation_authorization` and terminal D/ES seams.

## What the next freeze must close

The new contract pass must define an authoritative RW0-C post-execution evaluator with a total result algebra:

```text
no_decision
candidate_acceptance
candidate_repair
attempt_selecting_replan
program_terminal_reject
post_execution_program_block
basis_conflict
```

It must derive those results from the **typed safe contents** behind the nine Section 41 roles—not from the presence of their refs/digests and not from the model recommendation. The model recommendation remains bound evidence and should normally have to agree with the independently derived result.

It must also close:

- a fresh decision-time authority value covering ancestry, scope, expiry, revocation, ceilings, fences, current heads, and global stop;
- branch-specific stop semantics;
- actual result-producing host and Capability evaluators or finite derivation tables;
- the complete subordinate-narrowing gate operands and result classifier;
- per-role C1 support constructors and typed locators;
- exhaustive same-transaction membership paging;
- full pre-contact attestation cross-value equality;
- Section 41 context reconstruction from the durable WorkSpec safe binding, without later raw WorkSpec custody;
- deterministic rank-15 selection:
  - zero eligible families → `no_decision`;
  - exactly one → select;
  - more than one → `basis_conflict`;
- complete decision-time snapshot retention for committed recovery;
- exact semantic-attempt, candidate, and fence lineage in the neutral C2B basis;
- exact mapping from RW0-C branches to the existing C2B decision kind/variant pairs;
- path-and-assertion-level latch and cancel-evidence supersession ledgers;
- finite permanent-test and independent-audit matrices for every semantic, authority, recovery, and supersession claim.

# Codex handoff

Send this read-only prompt to the same architecture conversation:

:chatgpt-content-reference{index="0"}[Download the RW0-C decision semantic-authority owner-freeze prompt](sandbox:/mnt/data/Coordinator_RW0_C_Decision_Semantic_Authority_Owner_Freeze_Prompt.txt)

```text
Filename:
Coordinator_RW0_C_Decision_Semantic_Authority_Owner_Freeze_Prompt.txt

Size:
28,037 bytes

SHA-256:
8f540b9678932d5a46078ad895a981331e2885e4ebde42126089e1ffba80e418
```

The required successful result is:

```text
RW0_C_DECISION_SEMANTIC_AUTHORITY_OWNERS_READY_FOR_INDEPENDENT_AUDIT
```

A narrower blocker is acceptable when a required typed evidence or authority owner genuinely does not exist. No implementation prompt is authorized.

## Sequence after a successful freeze

```text
1. Fresh parent-only independent audit of the completed owner contract.
2. Implement and merge one pure governing-owner tranche:
   - governing docs and direct contract tests;
   - RW0-C semantic evaluators and profiles;
   - fresh authority/currentness evaluator;
   - Section 41 context/projection contracts;
   - neutral C2B authorization basis;
   - no migration, latch row, progression writer, or public API.
3. Rerun the C2B progression-owner reconciliation on the merged baseline.
4. Audit C2B.
5. Freeze the combined implementation boundary for:
   - C2B progression owner;
   - RW0-C-Decision;
   - migration 0005;
   - physical acceptance latch.
```

## Current project state

```text
RW0-C1:
merged and current

Section 41 family projection:
mechanically coherent, but not semantic decision authority

RW0-C decision semantic authority:
not frozen; current critical-path owner seam

Decision-time external authority/currentness:
not frozen; current critical-path owner seam

C2B progression-decision owner:
blocked pending those RW0-C owner contracts

migration 0005:
not implementation-authorized

RW0-C-Terminal / migration 0006:
blocked on D/Execution Substrate owners
```

Some earlier conversation uploads have expired; they were not needed for this pass. Re-upload a specific expired snapshot or report when a later audit must inspect its exact bytes.

### Source

- Codex independent audit report provided in this turn. This response treats its repository findings as **Codex-reported evidence**, not as a new direct repository inspection.

**Confidence:** High that implementation remains blocked; high that semantic branch derivation and fresh authority evaluation belong to RW0-C rather than Section 41 or C2B; medium-high that the attached owner-freeze prompt is the shortest path to a stable, auditable contract.
