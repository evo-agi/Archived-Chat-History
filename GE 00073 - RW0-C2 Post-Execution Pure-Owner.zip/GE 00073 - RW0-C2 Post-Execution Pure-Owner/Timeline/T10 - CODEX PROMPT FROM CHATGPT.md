PROMPT_ID

C2B_PROGRESSION_DECISION_OWNER_FREEZE_RECONCILIATION_V2

TITLE

Coordinator C2B — convert the progression-decision owner proposal into an
exact, path-correct, independently auditable contract freeze

ENGAGEMENT TYPE

Parent-only, local, read-only owner-contract reconciliation.

Do not delegate to subagents.

Do not edit, format, generate repository files, stage, commit, push, create a
branch or PR, merge, tag, release, deploy, fetch, contact a remote/live system,
install dependencies, run migrations, execute tests, open an operator
database, invoke a product worker/model, or inspect/modify supporting
repositories.

Do not issue an implementation prompt.

Print the complete substantive report inline. Evidence files may be
supplementary only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

C2B_PROGRESSION_OWNER_FREEZE_BASELINE_MISMATCH

PATH-GROUNDING CORRECTION

The preceding report cited source paths under:

src/governed_execution_nwp_coordinator/

That package path does not exist in the merged repository. The authoritative
package root is:

src/ge_nwp_coordinator/

The migration resource is under:

src/ge_nwp_coordinator/sqlite_migrations/

This pass must use exact existing repo-relative paths and line references for
every material current-contract claim. Treat the former links as a report
defect; do not carry them into the frozen contract or audit target.

PRESERVED OWNER DECISIONS

Preserve these conclusions unless exact current owner source proves a direct
contradiction:

1. C2B owns one private branch-parameterized progression-decision family for:

   - accept / candidate_acceptance;
   - repair / candidate_repair;
   - replan / attempt_selecting_replan;
   - terminal_reject / program_terminal_reject;
   - block / program_block;
   - cancel / effect_cancellation.

2. The first profile is an explicit single-work progression profile for all
   advancing branches. Cancel remains membership-neutral.

3. C2B owns branch semantics, row construction, post-states, revision/edge
   creation, head CAS, nested result/receipt, replay, readback, and recovery.

4. RW0-C may consume one bounded private C2B facade and compose it into the
   same common-controller transaction. C2B never imports RW0-C.

5. No standalone C2B commit path is required for this slice. One controller,
   one connection, one mutation slot, one timestamp, and one commit attempt
   remain authoritative.

6. Migration 0005 remains RW0-C-owned. The C2B owner family reuses the
   immutable migration-0002 schema without changing migrations 0001–0004.

7. The physical acceptance latch remains RW0-C-owned. C2B owns only the
   branch-semantic assertion that fresh productive direct-local accept is
   latch-eligible.

8. No new or reinterpreted decision kind, variant, persisted field, state,
   version kind, work-revision kind, or revision-edge kind is permitted.

9. RW0-C-Terminal and migration 0006 remain blocked on D/ES terminal-evidence
   owners.

WHY THE PRECEDING REPORT IS NOT YET AN AUDITABLE FREEZE

The prior report selected plausible branch semantics but left material contract
choices implicit:

- no exact profile manifest or digest;
- no exact command schema, field order, branch union, or digest domain;
- no exact immutable write-plan/result-plan/recovery-selector grammar;
- no exact branch reason-code provenance;
- no exact SQL query/CAS specifications or bounded-read contracts;
- no exact profile binding in command, receipt, replay, and recovery;
- no exact durable locator inventory for definitely-not-committed proof;
- inconsistent recovery vocabulary (`committed_exactly` versus the project’s
  established `committed_exact` family);
- no explicit proof that every proposed mutation-graph role and ordering is
  compatible with the current graph-digest contract;
- no path-correct touched-surface ledger.

This pass must close those issues. Do not defer semantic choices to an
implementer or an independent auditor.

FACT CLASSIFICATION

Classify every substantive statement as exactly one of:

- current owning contract;
- current merged implementation;
- compatibility edge;
- reopened owner seam;
- proposed frozen C2B owner contract;
- implementation detail;
- report-only uncertainty.

State conflicts explicitly.

INSPECTION SCOPE

Inspect together, using exact repo-relative paths:

- `.docs/c2b-durable-development-state.md`;
- `.docs/c2b2-pure-durable-row-values.md`;
- `.docs/c2b2-private-readers.md`;
- `.docs/c2b3-program-initialization.md`;
- all current author-effect, progression, SQLite, writer-session, authority,
  durable-state, software-progression, and RW0-C1 owner documents;
- `src/ge_nwp_coordinator/_development_program_row_values.py`;
- `src/ge_nwp_coordinator/_development_decision_row_values.py`;
- `src/ge_nwp_coordinator/_development_row_value_support.py`;
- `src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py`;
- `src/ge_nwp_coordinator/_sqlite_development_readers.py`;
- current initialization, author-effect, disposition, transition, global-stop,
  transaction, writer, and recovery modules;
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`;
- all direct tests pinning every reused row, variant, reader, graph, receipt,
  head, global-stop, transaction, replay, and recovery contract;
- the latest RW0-C-Decision reconciliation report from the conversation.

No tests, migrations, database commands, or external calls may run.

RECONCILIATION REQUIREMENTS

1. EXACT OWNER PROFILE

Freeze one complete profile identity for the first C2B writer.

At minimum return:

```text
schema_id
profile_ref
canonical manifest with exact key order and values
canonicalization rule
digest domain
canonical byte length
profile digest
```

The manifest must freeze:

- supported branches;
- single-work applicability;
- basis-membership cardinality;
- allowed basis program/work states per branch;
- post-state matrix;
- version/membership/revision/edge behavior;
- CAS order;
- global-stop matrix;
- graph role/order matrix;
- recovery vocabulary;
- authority/nonclaims.

The profile pair must be bound by the command, completed receipt projection,
RW0-C closure attestation, replay proof, and recovery proof.

If exact digest calculation is performed, describe the read-only method and
independent cross-check. Do not invent a digest without canonical literal
bytes.

2. EXACT COMMAND GRAMMAR

Freeze the exact private command value used by all six branches.

Determine whether the existing reserved schema ID is used:

```text
governed-execution.nwp-record-development-progression-decision-command.v1
```

Return:

- exact ordered fields;
- exact types and optionality;
- branch-specific field matrix;
- profile ref/digest;
- mutation ref;
- decision ref;
- basis decision/program-version identities;
- expected program-head and sole-work-head complete preimages;
- global-stop ref/version;
- exact Section 41/selection/basis identities required by each branch;
- every preassigned result version, intent revision, work revision, edge,
  WorkSpec, successor attempt/candidate, effect/fence/delivery identity;
- reason-code source and exact binding rule;
- transaction-independent command canonicalization and digest domain;
- command work/cardinality bounds.

No caller-supplied post-state, graph ordering, SQL, row digest, or latch state
may be accepted.

3. BRANCH-SPECIFIC DECISION ROW AND REASON CODE

For each branch, give the exact 43-field decision-row projection and identify:

- which fields are non-null;
- which fields are null;
- which are copied from current owner rows;
- which are caller-preassigned;
- which are derived by C2B;
- the exact reason-code source.

Reason-code policy must be explicit. Decide whether it is copied from the exact
Section 41 proposal, copied from another owner value, or selected from a closed
C2B profile vocabulary. Free-form implementer choice is forbidden.

Reverify all six rows against current constructors and direct field-level tests.

4. BRANCH PRECONDITION AND POSTIMAGE MATRIX

Freeze a literal matrix for every branch covering:

- allowed basis program states;
- allowed sole-work states;
- required attempt/candidate/selection/effect/capsule posture;
- active-stop behavior;
- result program-version kind/number;
- accepted-intent revision behavior;
- work-item revision behavior;
- program-version membership behavior;
- revision-edge behavior;
- result program/work states;
- whether each head changes;
- result projection;
- receipt graph.

Do not use one broad shared prestate set unless each branch’s owning semantics
supports it.

5. SINGLE-WORK PROFILE QUERY CONTRACT

Freeze the additive private reader/query used to distinguish:

- zero membership;
- exactly one membership at ordinal zero;
- valid-but-unsupported multiple memberships;
- malformed duplicate/non-dense state.

Return exact:

- query ID;
- SQL with explicit columns and parameters;
- ORDER BY;
- LIMIT and fetch count;
- row tuple;
- integrity versus profile-conflict classification;
- profile conflict reason;
- no change to the frozen twenty-four-query C2B2 inventory.

Explain why zero membership is integrity failure under current owner contracts
rather than merely unsupported profile state.

6. IMMUTABLE WRITE-PLAN CONTRACT

Define the exact private sealed plan returned by the C2B evaluator.

Return exact plan schemas/variants and ordered fields for:

- decision row;
- accepted-intent revision, when present;
- work-item revision, when present;
- result program version;
- result membership rows;
- WorkSpec binding, when present;
- revision edges, when present;
- work-head CAS specification;
- program-head CAS specification;
- mutation-graph entries;
- progression result projection;
- completed receipt projection.

The plan must contain typed owner values and closed CAS specifications, never
raw SQL fragments, generic mappings, JSON/BLOB payloads, caller-selected
states, or caller-selected graph roles.

7. SQL AND READER OWNERSHIP

Freeze exact private SQL specifications for:

- receipt-first lookup;
- basis program/head/version;
- sole-work membership/profile query;
- work head/revision;
- accepted-intent revision;
- selection/attempt/candidate/fence dependencies;
- collision probes for every preassigned identity;
- immutable inserts;
- work-head CAS;
- program-head CAS;
- full branch readback;
- recovery locators.

For every query state:

- exact columns;
- WHERE predicates;
- ORDER BY;
- LIMIT/fetch bound;
- cardinality interpretation;
- safe failure classification.

No `SELECT *`, caller-selected table/column name, unbounded read, or raw
connection authority.

8. CAS AND WRITE ORDER

Reverify and freeze exact work-before-program CAS behavior.

For each CAS return:

- exact expected preimage fields;
- exact postimage fields;
- exact SQL predicate and assignment columns;
- rowcount requirement;
- conflict vocabulary;
- whether `program_head_conflict` intentionally covers a work-head miss and why;
- rollback behavior;
- replay behavior.

Freeze the complete branch write order, including deferred-FK closure and full
in-transaction readback before the nested receipt is treated as complete.

9. MUTATION GRAPH CONTRACT

Reconcile every proposed role/order with the current mutation-graph value and
digest helper.

Return:

- exact graph-entry row grammar already current;
- exact allowed role strings per branch;
- exact ordinal rules;
- exact record refs/digests;
- canonical ordering rule;
- graph digest preimage;
- receipt envelope relation;
- proof that no new persisted graph field or role reinterpretation is needed.

Correct any branch order that conflicts with the current digest owner.

10. RESULT, COMPLETED RECEIPT DIGEST, AND OUTER BINDING

Freeze:

- exact existing progression-result mapping;
- exact branch `result_program_version_ref`;
- pure completed-receipt digest projection;
- schema/domain for that projection if additive;
- proof that no SQL column is added;
- how RW0-C binds the nested receipt digest without restating branch semantics;
- partial-family and corruption behavior.

11. REPLAY AND RECOVERY SELECTOR

Use one consistent three-way vocabulary:

```text
committed_exact
definitely_not_committed
unresolved
```

If current C2B owner text requires another spelling, cite and reconcile it
explicitly. Do not introduce `committed_exactly` casually.

Freeze the exact recovery-selector value:

- schema ID;
- ordered fields;
- construction before apply;
- branch/profile pair;
- mutation/command/decision/program identities;
- every preassigned branch-owned locator;
- expected program/work/global-stop preimages;
- selector digest.

Freeze exact proofs for:

- committed exact;
- definitely not committed;
- unresolved;
- later legitimate head advancement;
- C2B-only fragment inside an outer RW0-C operation;
- latch-only or outer-only partial family;
- cleanup uncertainty;
- no same-writer retry.

12. GLOBAL STOP

Freeze the exact source rows/readers and command binding for global stop.

Explain how replay reconstructs historical stop ref/version after the current
stop advances. Decide whether state is copied into a durable row, reconstructed
from immutable history, or intentionally absent from the decision row. Do not
rely on a mutable current row to prove historical state.

13. COMPOSITION SEAM

Freeze exact API-level ownership, without implementation code:

- C2B evaluator entry;
- C2B SQL/readback facade entry;
- common-controller executor;
- RW0-C composer call order;
- timestamp ownership;
- nested receipt completion point;
- latch CAS point;
- outer receipt-last point;
- capability invalidation;
- one COMMIT attempt;
- close-proof behavior;
- composed recovery.

Confirm that no standalone C2B operation can commit the nested family without
the RW0-C closure in this slice.

14. ASSURANCE PLAN

Map each permanent test to one finite owner claim:

- profile literal/digest;
- command branch matrix;
- exact decision rows/reason codes;
- single-work query;
- each positive branch write plan;
- every forbidden row;
- version membership;
- replan revisions/edges/WorkSpec;
- CAS SQL/order/rowcount;
- stop matrix;
- graph/result/receipt;
- replay/conflict;
- every write/commit/cleanup fault;
- three-way recovery;
- public/authority non-widening.

Define independent audit challenges using literal oracles, external SQL
fixtures, graph mutants, fault injection, and clean/live validation. Do not
make permanent tests self-protecting.

15. PATH-CORRECT PROVISIONAL SURFACE

Produce a path-derived provisional inventory using only actual repo paths.
Separate:

- must change for the C2B owner contract/implementation;
- must change later for RW0-C Decision/migration 0005;
- may change after consumer/source-hash audit;
- protected.

Do not issue an implementation allowlist or prompt. Mark the inventory
provisional until an implementation-boundary audit verifies every current
consumer and source-hash oracle.

16. SEQUENCING

Re-evaluate the prior recommendation:

- independently audit the exact C2B owner freeze;
- then perform a dedicated implementation-boundary audit for the combined
  C2B-owner plus RW0-C-Decision candidate;
- only then authorize one integrated implementation candidate with separate
  modules and one transaction authority.

State whether the owner contract is now independently auditable and whether any
upstream owner seam remains.

STOP CONDITIONS

Return a blocker if closure requires:

- changing any existing decision field/nullability/meaning;
- changing migration 0002 bytes;
- adding a decision kind or variant;
- generic JSON/BLOB command or plan payloads;
- caller-selected states, edges, graph roles, or SQL;
- a second transaction/connection/commit path;
- C2B importing RW0-C;
- external I/O;
- public API widening;
- a recovery proof that cannot be made exact;
- unresolved multi-work behavior inside the first profile.

RETURN FORMAT

# Baseline and path-grounding correction
# Preserved owner decisions
# Exact profile identity
# Exact command grammar
# Exact branch decision-row matrix
# Branch preconditions and postimages
# Single-work query contract
# Immutable write-plan contract
# SQL and private reader contracts
# CAS and write order
# Mutation-graph contract
# Result and completed-receipt digest
# Replay and recovery selector
# Global-stop historical binding
# Composition seam with RW0-C
# Assurance and independent-audit plan
# Path-correct provisional surface
# Remaining seams and stop conditions
# Recommended next step
# Confidence

SUCCESS TOKEN

Return exactly:

C2B_PROGRESSION_DECISION_OWNER_FREEZE_RECONCILED_READY_FOR_INDEPENDENT_AUDIT

only if the contract is exact enough that an independent auditor and later
implementer need make no semantic choice.

Otherwise return:

C2B_PROGRESSION_DECISION_OWNER_FREEZE_STILL_INCOMPLETE

or:

C2B_PROGRESSION_DECISION_OWNER_RECONCILIATION_BLOCKED

with the precise unresolved owner decision.

Required statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
