# Decision

**Accept Option B as the phase-level direction, but do not yet accept the report’s implication that both durable tranches are equally ready for contract freeze.**

The correct decomposition is:

1. **RW0-C-Decision** — decision-basis closure, exact existing C2B decision binding, and the one-way productive-direct-local acceptance latch.
2. **RW0-C-Terminal** — a later terminal-basis closure and distinct B1 terminal outcome, without another C2B decision or latch mutation.

This split is substantive rather than gate multiplication. A committed decision is durable progression truth and can remain safely nonterminal; terminal closure answers a later causal question. Codex correctly rejected a single combined transaction surface and proposed separate migrations `0005` and `0006`. :chatgpt-content-reference{index="0"}

## What is ready

**RW0-C-Decision is ready for a detailed contract-freeze pass.**

The reconnaissance gives a coherent foundation:

- closure members use exact C1 membership identities, not reusable value identities;
- completeness is branch-specific rather than a mutation of C1’s membership semantics;
- the closure and C2B decision commit atomically;
- only `accept / candidate_acceptance` may consume the latch;
- repair, replan, reject, block, and cancel preserve the existing C2B grammar;
- replay and commit recovery compose with the current writer and transaction authority. :chatgpt-content-reference{index="1"}

The exact decision mapping is plausible and should now be frozen against the write-side C2B rows and head transitions—not merely the value grammar. In particular, `replan / attempt_selecting_replan` is preserved while `program_replan` remains outside phase-specific RW0 composition. :chatgpt-content-reference{index="2"}

## What is not yet closed

I would not freeze migration `0006` from this report alone. Four issues need explicit resolution.

### 1. One decision per phase is not fully frozen

The report states one decision per closure and one closure per decision, but that does not itself prevent multiple distinct closure/decision families for one C1 phase. :chatgpt-content-reference{index="3"}

The next pass should freeze:

```text
at most one RW0-C decision closure and one bound C2B decision per C1 phase
```

A second attempted branch for the same phase must conflict rather than become another durable progression truth.

### 2. The pre-effect unusable branch contains a contradiction

The report says a cancel decision may be “missing” when the terminal branch records `pre_effect_cancel_basis_unusable`, yet that terminal outcome is supposed to bind the original cancel decision. :chatgpt-content-reference{index="4"}

The correct rule is:

- the exact `cancel / effect_cancellation` decision, result, and receipt **must exist and be recoverable**;
- what later proves unusable is its current basis for establishing the cancellation effect;
- an absent, partial, corrupt, or unresolved decision cannot be terminalized;
- no replacement cancel or block decision is created.

### 3. Rejection-to-cancel is too permissive

Codex allows a finite `cancellation_rejected` fact to support terminal `cancel` when later source-native reconciliation is complete. :chatgpt-content-reference{index="5"}

That should default to **terminal block**. A rejected request is a finite control denial, not evidence that cancellation succeeded. Terminal `cancel` after a rejection is defensible only if an existing owner supplies an exact, separately accepted cancellation path for the same target. A future D/ES aspiration is not enough.

### 4. The terminal D/ES owner seam is unresolved

The report requires process-group, descendant, teardown, custody, and source-receipt facts for active-cancel terminal reconciliation. It also says D/ES must define those projections later. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

Those statements cannot both support a fully frozen migration `0006` today unless Codex proves that every required role already has:

- an exact current owner value and schema;
- an exact durable row or C1 membership route;
- a bounded reader;
- no need for a sixteenth C1 evidence kind;
- no transfer of physical truth into C2 ownership.

If that proof fails, the correct state is:

```text
RW0-C-Decision:
contract-freezable now

RW0-C-Terminal:
operating model bounded, but active-cancel schema blocked on a D/ES owner contract
```

This is not a reason to delay the decision tranche.

## Acceptance latch correction

The one-shot latch belongs with the decision transaction, and terminal acceptance should only bind its committed postimage. That part is sound. :chatgpt-content-reference{index="8"}

But “global to the Coordinator bootstrap scope” needs a precise meaning. The freeze must identify it as one seeded singleton per managed Coordinator database/state root—not a hidden cross-database, organization-wide, or process-global authority. It must also define the database-copy and fresh-bootstrap posture explicitly.

## Recommended next step

Run a **read-only contract-freeze pass focused asymmetrically on the two tranches**:

- fully freeze RW0-C-Decision and migration `0005`;
- freeze only those RW0-C-Terminal invariants currently supported;
- force an explicit proof or blocker for the D/ES-dependent migration `0006`;
- do not issue an implementation prompt.

:chatgpt-content-reference{index="13"}[Download the RW0-C Decision contract-freeze and Terminal seam-resolution prompt](sandbox:/mnt/data/Coordinator_RW0_C_Decision_Contract_Freeze_and_Terminal_Seam_Resolution_Prompt.txt)

```text
Filename:
Coordinator_RW0_C_Decision_Contract_Freeze_and_Terminal_Seam_Resolution_Prompt.txt

Size:
19,546 bytes

SHA-256:
6ad30c6450cd975761cc68a1513407a297e8a188a039b6ad1589ca5dde34b28a
```

The prompt permits three honest outcomes:

```text
RW0_C_DECISION_CONTRACT_FREEZE_READY_TERMINAL_SEAM_BOUNDED
```

```text
RW0_C_OWNER_RECONCILIATION_REQUIRED
```

```text
RW0_C_TERMINAL_OWNER_RECONCILIATION_REQUIRED
```

It does not authorize implementation.

## Current project state

```text
RW0-C1:
merged and current

RW0-C-Decision:
phase direction accepted; detailed contract freeze pending

RW0-C-Terminal:
operating model accepted; physical owner/schema readiness unproven

RW0-D:
not implemented

RW0-E:
not implemented
```

### Source

- Codex’s RW0-C2 phase-level engineering reconnaissance. :chatgpt-content-reference{index="9"} :chatgpt-content-reference{index="10"} :chatgpt-content-reference{index="11"} :chatgpt-content-reference{index="12"}

**Confidence:** High on the two-part decomposition and immediate readiness of the decision-contract freeze; medium on terminal migration readiness because the report itself leaves D/ES reconciliation identities unresolved.

Some older Project uploads have expired. The current attachment was sufficient for this assessment; re-upload a specific older snapshot only if the next pass needs to inspect it directly.
