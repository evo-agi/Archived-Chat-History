PROMPT_ID

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V4_INTERNAL_CONSISTENCY_REPAIR_V1

TITLE

Coordinator RW0 — repair three deterministic internal contradictions in
canonical package V3, regenerate every dependent identity, and deliver package
V4 for formal independent audit

ENGAGEMENT TYPE

Parent-only, local, repository-read-only canonical-package repair.

Do not delegate to subagents or internal audit agents.

Do not edit repository files, format repository files, stage, commit, push,
create a branch or PR, merge, tag, release, deploy, fetch, contact a remote or
live system, install dependencies, execute repository tests, run migrations,
open or mutate an operator database, invoke a product worker/model, or
inspect/modify supporting repositories.

You MAY create files only in one fresh private external temporary root for
bounded source inspection and package reconstruction. Remove disposable
intermediate files before closeout.

Return the revised package through the client-visible attachment mechanism.
A private filesystem path is not a deliverable.

Do not issue an implementation prompt.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly:

branch:
trunk_dev

HEAD:
a3ff0b7f4f0c2378c2962e24612d605489b51638

tree:
d8dc2a3b0bce084ff9e2a587e6d617e08970e6a0

sole parent:
047563de5a443b0f8323401c92979ae2e444d2ed

subject:
feat: implement RW0-C1 durable evidence (#7)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean

No fetch is authorized.

If the baseline differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V4_BASELINE_MISMATCH

FIXED INPUT

Attach exactly:

RW0_Post_Execution_Canonical_Audit_Package_V3.jsonl

Require exactly:

size:
2066851 bytes

SHA-256:
d01e1ad90f406dedf8f80bc0453505df022a9c9013a7914a0ed7e52d202ffefe

logical records:
1121

final newline:
absent

content aggregate:
e460b60c49460622dc669f21fd90429dc3b705755a20e0e8321941558c503336

first record:
package.manifest.v1

last content record:
remaining-seam.S008

final record:
package.closeout.v1

If any property differs, stop:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V4_FIXED_INPUT_MISMATCH

PRESERVED DISPOSITION

Preserve the V3 repairs for RW0-AUDIT-001 through RW0-AUDIT-008:

- exact current host-qualification field names and module;
- non-temporal rank-12 relation timestamps;
- complete V40.n01 nested schema;
- explicit deferral and retirement of V35–V37;
- expanded finite assurance;
- exact GlobalStopState owner/digest posture;
- corrected source modules;
- migration-0003 composite evidence-row locator.

Do not reopen V40, the two-context design, Section 41 V2/V3, exact resupply,
capsule privacy, policy/risk authorship, FiniteBacklog isolation, C1's 15 kinds,
or future recovery deferral.

FINDING V3-PKG-001 — DUPLICATE HOST-QUALIFICATION DIGEST CONTRADICTION

Record:

source-owner.host-qualification

Current canonical owner value contains:

```text
qualification_digest =
971eb49f780922384eda949e7ecbaaae67554d4c6cb750a6b7b5fe46ddfd05dc
```

Independent recomputation under:

```text
governed-execution.nwp-rw0-effect-host-qualification.v1.identity
```

produces the same value.

The same source-owner payload also contains a duplicate top-level field:

```text
qualification_digest =
fb18bf1d97830fa0ff602f90d59cf0f718f3df53754c3f28e27d7f40d7b62681
```

That value is neither the canonical review qualification digest nor the
reported validation qualification digest.

Additionally, 22 of 23 source-owner records use the same exact 10-key payload
shape:

```text
canonical_value
current_posture
identity_and_digest
non_authority
ordered_fields
owner_id
owner_module
owner_tables
relation_and_profile
schema_id
```

The host record alone adds a record-specific duplicate identity field.

Required correction:

1. Remove the duplicate top-level `qualification_digest`.
2. Preserve the canonical value's exact correct digest.
3. Freeze one exact common source-owner-binding payload schema using the
   10-key shape above.
4. Add a package-wide guard:
   - no source-owner payload has an unknown top-level key;
   - no source-owner payload repeats a canonical-value field at top level;
   - every declared digest field reproduces from the canonical owner value.
5. Add one assurance control and one-predicate malformed vector for a
   contradictory duplicate identity field.
6. Regenerate package hashes, manifest, closeout, assurance counts, malformed
   counts, and supersession records as applicable.

FINDING V3-PKG-002 — HOST RELATION/PROFILE MISSTATEMENT

The same record currently states:

```text
relation_and_profile.profile = rw0-wire-nwpf-v1
relation_and_profile.relation = rank-6 host qualification relation
```

But:

- the canonical qualification carries
  `required_worker_protocol_ref/digest =
   worker-protocol-profile-golden.0001 / 3d...`;
- the current source callable is `validate_host_qualification(...)`;
- that callable has no separate profile-pair operand;
- it validates the qualification's required worker-protocol pair against the
  readiness observation.

Required correction:

1. Reinspect the exact current owner source.
2. Freeze the source-owner metadata to the current relation contract.
3. Preferred target unless source proves otherwise:

```json
{
  "profile": null,
  "relation": "validate_host_qualification"
}
```

4. Do not claim that the B1 host-qualification relation is governed by the
   fixed NWPF profile merely because a later Capability or Wire contract uses
   that pair.
5. Add assurance and malformed-vector coverage for profile substitution and
   relation-name substitution.
6. Regenerate package identities as required.

FINDING V3-PKG-003 — V26 NESTED ENTRY SCHEMA OMITTED FROM PROFILE

Records:

```text
value-schema.V26.rw0cdecisionmembershipclosureentryv1
behavior-profile.rw0-c-decision-membership-closure.v1
```

The V26 value schema and all current golden closure entries contain:

```text
schema_id =
governed-execution.nwp-rw0-c-decision-membership-closure-entry.v1
```

as the first field.

But the governing profile's literal `entry_fields` omits `schema_id`.

Required correction:

1. Add:

```text
entry_schema_id =
governed-execution.nwp-rw0-c-decision-membership-closure-entry.v1
```

to the governing profile.

2. Make the exact entry field order:

```text
schema_id
kind_rank
membership_ref
membership_digest
value_schema_id
value_ref
value_digest
scope_binding_digest
relation_set_digest
admitted_at
admission_graph_digest
```

3. Regenerate:
   - the membership-closure behavior-profile digest;
   - V25/V26 governing profile pairs;
   - V25 closure ref/digest;
   - every downstream current snapshot/currentness/matrix/recommendation value
     that binds the closure;
   - affected T1/Section41/resupply equality records if any;
   - malformed vectors, supersessions, manifest, aggregate, and closeout.

4. Add a package-wide nested-contract guard:

```text
for every nested value with a literal governing profile definition:
  literal schema constant equal
  exact field set equal
  exact field order equal
  exact type/nullability/enum rule equal
```

5. Add one assurance case and one malformed vector for omitted V26 schema ID.

PACKAGE-WIDE CONSISTENCY CHECKS

Before reporting success, additionally verify:

1. Every source-owner payload matches the common 10-key grammar.
2. Every source-owner canonical-value field set equals `ordered_fields`.
3. Every source-owner declared digest reproduces.
4. No source-owner metadata profile contradicts the canonical value's profile
   coordinates or current relation signature.
5. Every primary value schema and governing profile agree on field set/order
   where the profile declares exact fields.
6. Every nested value with a literal profile definition agrees exactly.
7. Every golden value conforms to its current schema and profile.
8. No superseded identity appears outside supersession or dedicated malformed
   records.
9. All previous V3 source-grounding and temporal/non-temporal guards remain
   green.
10. All original JSONL envelope, manifest, aggregate, closeout, and whole-file
    hash checks pass through two independent local readers/hash tools.
11. Repository baseline and cleanliness remain unchanged.

REVISED DELIVERABLE

Attach exactly:

RW0_Post_Execution_Canonical_Audit_Package_V4.jsonl

Use the same canonical JSONL envelope and closed record types.

It is acceptable for assurance, malformed-vector, and supersession counts to
increase.

No implementation effect is authorized.

INLINE REPORT

Print:

- disposition for V3-PKG-001 through V3-PKG-003;
- exact filename, size, SHA-256, records, final-newline posture;
- per-type counts and content aggregate;
- changed/new/retired record IDs;
- new supersession entries;
- assurance and malformed-vector counts;
- confirmation that the common source-owner payload grammar passes;
- confirmation that V26 schema/profile order passes;
- confirmation that the revised file is visibly attached;
- confirmation that no private path is offered as the deliverable;
- success token.

SUCCESS TOKEN

Return exactly:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V4_REPAIRED_READY_FOR_INDEPENDENT_AUDIT

only if:

- all three findings are closed;
- V4 is visibly attached;
- every verification passes;
- repository state remains unchanged;
- no implementation prompt is issued.

Otherwise return:

RW0_POST_EXECUTION_CANONICAL_PACKAGE_V4_REPAIR_BLOCKED

and classify the blocker as:

- fixed-input mismatch;
- source-owner contradiction;
- semantic contradiction;
- regeneration failure;
- canonical verification failure;
- attachment mechanism unavailable;
- baseline mismatch.

REQUIRED STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
IMPLEMENTATION_NOT_PERFORMED
POST_EXECUTION_EVIDENCE_OWNER_NOT_IMPLEMENTED
RW0_C_DECISION_NOT_IMPLEMENTED
C2B_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
RW0_C_TERMINAL_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
