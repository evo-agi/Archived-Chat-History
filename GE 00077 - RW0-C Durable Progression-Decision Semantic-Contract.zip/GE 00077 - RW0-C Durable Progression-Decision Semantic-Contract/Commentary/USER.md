`Timeline/T38 - CODEX PROMPT FROM CHATGPT.md` is not executed as part of `RW0-C Durable Progression-Decision Semantic-Contract` in chat GE 00077. 
