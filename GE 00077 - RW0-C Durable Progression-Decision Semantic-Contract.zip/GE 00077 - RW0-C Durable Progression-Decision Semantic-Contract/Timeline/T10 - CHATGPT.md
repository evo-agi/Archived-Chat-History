# Disposition

**Accept the independent audit’s `BLOCKED` verdict. Do not stage or commit this candidate.**

The audit reproduced the exact seven-path candidate, baseline, validation results, and final provenance. No source, migration, runtime, or public boundary widened, and the full suite still passed with **6,337 tests and the three expected warnings**. This is therefore a contract-and-test repair, not an architecture reset or implementation rollback. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

## What must be repaired

Three findings are fundamental.

First, the reducer currently has no normative projection from the actual V14/V15 tuple fields into the abstract `accept / repair / replan / terminal / nonconclusive / conflict` classes. The owner mixes raw `source_outcome`, derived `result`, repairability, separation, and newly invented compound aliases. The reducer itself is coherent after normalization, but that normalization is not defined. :chatgpt-content-reference{index="2"}

Second, the tests are circular. They parse the embedded JSON, implement one test-local reducer, and compare it with another test-local reducer. Material prose, oracle, source-vocabulary, matrix-inventory, and converted-block-flow drift can remain green. The hostile-copy results prove this is not a theoretical concern. :chatgpt-content-reference{index="3"}

Third, the new owner incorrectly says repository **source** is the sole authority for current implementation. That conflicts with the repository’s `.docs/` authority and the operating model’s composition authority. Two changed status documents also retain stale candidate/current-future wording. :chatgpt-content-reference{index="4"}

The medium findings follow from those defects:

- the complete five-matrix inventory is not fixed independently;
- productive-branch denial converts to block without a causal test that re-evaluates all five halt-only block entries;
- source/runtime absence guards are structurally incomplete;
- some embedded-oracle fields are unused or tautological.

The accepted reducer architecture itself should remain intact. The audit expressly found the abstract currentness, severity, branch, and reason-precedence model internally coherent, and it found no malformed-evidence-to-block fallback or physical-scope widening. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

## Exact normalization decision

The repaired contract should consume the already validated **V14 validation disposition** and **V15 review disposition**, not invent aliases directly from raw observations.

### Validation projection

| Exact accepted V14 fields | Normalized class |
|---|---|
| `passed / passed / not_applicable / validation_passed` | `accept` |
| `failed / repairable_failure / repairable / validation_failed_repairable` | `repair` |
| `failed / replan_required / same_attempt_insufficient / validation_failed_replan_required` | `replan` |
| `failed / terminal_failure / nonrepairable / validation_failed_terminal` | `terminal` |
| `failed / unknown / unknown / validation_failed_unclassified` | `nonconclusive` |
| `inconclusive / unknown / unknown / validation_inconclusive` | `nonconclusive` |
| `not_run / not_run / not_applicable / validation_not_run` | `nonconclusive` |
| `result=basis_conflict / repairability=conflict / reason=source_observation_mismatch` | `conflict` |

The first column is:

```text
source_outcome / result / repairability / reason
```

Any other combination is not another reducer input. It is an invalid or contradictory basis and therefore **no-write**.

### Review projection

| Exact accepted V15 fields | Normalized class |
|---|---|
| `passed / separate / passed / review_passed` | `accept` |
| `failed / separate / repair_required / review_failed_repair_required` | `repair` |
| `failed / separate / replan_required / review_failed_replan_required` | `replan` |
| `failed / separate / terminal_reject / review_failed_terminal_reject` | `terminal` |
| `failed / separate / unknown / review_failed_unclassified` | `nonconclusive` |
| `inconclusive / separate / unknown / review_inconclusive` | `nonconclusive` |
| `* / not_separate / basis_conflict / review_not_operationally_separate` | `conflict` |
| `* / unknown / unknown / reviewer_separation_unknown` | `nonconclusive` |
| `* / conflict / basis_conflict / reviewer_separation_conflict` | `conflict` |

The first column is:

```text
source_outcome / separation_status / result / reason
```

`*` means any source outcome accepted by the current V15 owner. Separation status takes precedence in those three rows. Any other combination is no-write.

This removes the unsupported compound aliases while preserving the selected reducer:

```text
any conflict       → no write
any nonconclusive  → durable block
otherwise          → terminal > replan > repair > accept
```

---

# Complete replacement Codex prompt

Use this in the **same workspace-write implementation conversation**. No attachments or external artifacts are required.

```text
# Governed Execution Coordinator — RW0-C Durable Decision Branch Contract Repair

## Objective

Repair the uncommitted RW0-C2 durable progression-decision semantic-contract
candidate after its independent audit BLOCK.

This remains a documentation-and-contract-tests-only tranche.

The repair must:

1. define an exact normative projection from the current V14 validation and V15
   review semantic tuples into the reducer classes;
2. remove unsupported compound aliases and competing-authority wording;
3. reconcile stale current-versus-future status prose;
4. replace circular or adaptive tests with source-bound, document-bound,
   independently fixed and causally hostile contract tests;
5. causally freeze the two-stage productive-to-block matrix path;
6. retain the existing reducer, five-branch scope, latch abstraction, terminal
   separation, and physical-persistence nonimplementation boundary.

Do not modify source, migrations, schemas, runtime, public APIs, transaction
code, writer code, or package exports.

Return one substantive inline closeout report. Do not create or attach reports,
manifests, freeze packages, or other external artifacts.

## Repository and committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- tree: `9e69d4a517b482704c159958abc2f90ed3cdcfd8`
- sole parent: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- subject: `feat: implement RW0-C post-execution pure owners`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged and unmerged paths
- no active Git operation or index lock

Do not fetch or contact remotes.

## Exact opening candidate

Before editing, require exactly these seven candidate paths and no other
difference from HEAD:

| Status | Path | Bytes | SHA-256 |
|---|---|---:|---|
| `M` | `.docs/architecture.md` | 42,104 | `d10da9d372c9920ed567f2f705d798cd52f8fb37a9bb94a414f9f4ce193d5494` |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 37,198 | `971c3986011f6fb6473bb6018822c2e6c3abc037ec952fa54c8b322e5c70f1bf` |
| `M` | `.docs/c2b-durable-development-state.md` | 1,887,232 | `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5` |
| `M` | `.docs/rw0-c1-durable-evidence.md` | 14,275 | `398911e2631ed1ad928febcd957034d534c860e8fc915a54371c577f7a7e98bf` |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 55,814 | `4b5d9a53e2de8d8b0186a4b93818d1e91df322a2d2de19defa51059f28aa5383` |
| `??` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 25,225 | `93854cc7ac0eee8296edbb06546af2bcc46015f8507d794529dc2c1ac0ff3539` |
| `??` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 28,880 | `450c1d559cdcbda3d67a14ade51dc2cc0473a6f2cb8b70680081383c6ab29837` |

All seven must be regular non-symlink mode-`0644` files.

Also require:

`AGENTS.md`

- bytes: `60,530`
- SHA-256:
  `c12a3449e761728f2093c19bb30134c54994b045843313471a6d715b648355a6`

Stop without editing on any mismatch and return:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIR_BLOCKED`

## Audit findings accepted as the repair basis

The independent audit reproduced candidate provenance and all prescribed
validation. It found no source, migration, schema, runtime, public-surface, or
physical-persistence widening.

The repair must close exactly these findings:

1. The contract has no normative projection from current validation/review
   tuple fields into its abstract reducer classes.
2. The owning document says repository source is the sole current authority,
   conflicting with `.docs/` and the operating model’s composition authority.
3. C1 and RW0 status prose contains stale “this candidate” and wholesale
   “RW0-C remains future” wording.
4. Tests parse an embedded oracle but execute duplicated test-local semantics.
5. Prose-only drift, oracle remapping, matrix-owner removal, current-source
   disposition drift, and removal of the converted-block halt-only check can
   remain green.
6. The complete five-matrix inventory and two-stage productive-to-block path
   are not causally fixed.
7. Some oracle fields are unused or tautological.
8. The AST import/absence guards are structurally incomplete.

Do not reopen the accepted reducer unless current source directly contradicts
the exact projection specified below.

## Source-of-truth posture

Preserve this exact authority split:

- Git owns commit, tree, object, and ref facts.
- `AGENTS.md` routes repository composition and contract authority.
- `.docs/` owns current and target contract semantics within each document’s
  declared scope.
- `.docs/autonomous-software-development-operating-model.md` is the
  authoritative composition/current-status record.
- source and migrations implement current behavior and durable representation;
  they are not the sole repository contract authority.
- tests are executable evidence and drift guards; they do not become a second
  semantic owner.
- reports and generated artifacts are evidence only.

Remove or replace any statement that says repository source alone is the sole
authority.

The C2 owner remains an accepted future semantic contract. It is not current
runtime behavior.

## Exact normative input projection

The reducer consumes already validated V14 and V15 semantic values. It does not
consume raw source observations directly and does not invent compound aliases
that current source does not define.

### Validation projection

The complete accepted normal rows are:

| `source_outcome` | `result` | `repairability` | `reason` | Normalized class |
|---|---|---|---|---|
| `passed` | `passed` | `not_applicable` | `validation_passed` | `accept` |
| `failed` | `repairable_failure` | `repairable` | `validation_failed_repairable` | `repair` |
| `failed` | `replan_required` | `same_attempt_insufficient` | `validation_failed_replan_required` | `replan` |
| `failed` | `terminal_failure` | `nonrepairable` | `validation_failed_terminal` | `terminal` |
| `failed` | `unknown` | `unknown` | `validation_failed_unclassified` | `nonconclusive` |
| `inconclusive` | `unknown` | `unknown` | `validation_inconclusive` | `nonconclusive` |
| `not_run` | `not_run` | `not_applicable` | `validation_not_run` | `nonconclusive` |

A V14 value accepted by its current owner with:

- `result = basis_conflict`
- `repairability = conflict`
- `reason = source_observation_mismatch`

normalizes to `conflict`, regardless of which allowed source-outcome value it
retains.

Any other V14 field combination is an invalid or contradictory basis and
produces no durable write.

### Review projection

When `separation_status = separate`, the complete accepted rows are:

| `source_outcome` | `result` | `reason` | Normalized class |
|---|---|---|---|
| `passed` | `passed` | `review_passed` | `accept` |
| `failed` | `repair_required` | `review_failed_repair_required` | `repair` |
| `failed` | `replan_required` | `review_failed_replan_required` | `replan` |
| `failed` | `terminal_reject` | `review_failed_terminal_reject` | `terminal` |
| `failed` | `unknown` | `review_failed_unclassified` | `nonconclusive` |
| `inconclusive` | `unknown` | `review_inconclusive` | `nonconclusive` |

The exact separation-status override rows are:

| `separation_status` | `result` | `reason` | Normalized class |
|---|---|---|---|
| `not_separate` | `basis_conflict` | `review_not_operationally_separate` | `conflict` |
| `unknown` | `unknown` | `reviewer_separation_unknown` | `nonconclusive` |
| `conflict` | `basis_conflict` | `reviewer_separation_conflict` | `conflict` |

Those override rows accept any `source_outcome` already accepted by the V15
owner.

Any other V15 combination is an invalid or contradictory basis and produces no
durable write.

Do not use or retain unsupported aliases such as:

- `basis_owner_profile_conflict`
- `basis_owner_separation_profile_conflict`

unless a current source owner actually defines and validates them. Prefer the
exact current fields and normalized classes above.

## Reducer semantics to preserve

After exact input projection:

1. any `conflict` → no durable write;
2. any `nonconclusive` → `post_execution_program_block`;
3. otherwise select:

`terminal > replan > repair > accept`

Preserve:

- currentness conflict → no write;
- currentness stale or unknown → block;
- currentness current → continue;
- exact five durable branches;
- exact migration-0002 kind/variant mapping;
- block-reason precedence;
- model recommendation non-authority;
- caller expected branch as conflict assertion only;
- no-write/block/recovery-unresolved separation;
- acceptance-latch abstract dependency;
- terminal/RW0-D/E separation;
- physical persistence as a later freeze.

## Two-stage matrix contract

The exact matrix-owner inventory is closed and ordered:

1. `standing_policy`
2. `risk_lane`
3. `decision_time_authority`
4. `global_stop`
5. `source_effect_ceiling`

The contract and tests must reject any missing, additional, duplicated, or
reordered owner.

For a productive provisional branch:

1. evaluate that productive branch in all five matrices;
2. any conflict → no write;
3. all permit → retain the productive branch;
4. any deny or unknown → convert provisionally to
   `post_execution_program_block`;
5. after conversion, evaluate the block/halt-only entry in all five matrices;
6. all five exact halt-only permits are required for a durable block;
7. any block-entry deny, unknown, conflict, malformed reason, wrong
   applicability, or wrong effect class → no write.

For a directly selected terminal-reject or block branch, all five exact
halt-only entries must likewise permit.

Tests must prove the second stage. It is not enough to prove the productive
denial alone.

Required active-stop cases include:

- conclusive terminal evidence + active stop → terminal reject, after all
  terminal halt-only entries permit;
- conclusive acceptance/repair/replan candidate + active stop → provisional
  block, then durable block only after all block halt-only entries permit;
- one malformed/nonpermit block entry after productive denial → no write.

## Owning document representation

The owning document remains:

`.docs/rw0-c2-durable-progression-decision-semantic-contract.md`

It may retain one embedded machine-readable contract block, but:

- the document as a whole is the owner;
- the human-readable tables and machine-readable block are two exact
  representations of the same contract;
- tests must parse and compare both;
- changing either representation alone must fail;
- no embedded field may be unused, decorative, or tautological;
- remove any field that is not semantically validated;
- every normative field must have at least one direct assertion and one
  appropriate hostile control.

Clearly distinguish:

- current implemented facts;
- accepted future semantic contract;
- future physical implementation;
- evidence and tests.

## Documentation reconciliation

Repair at least these stale statements:

1. `.docs/rw0-c1-durable-evidence.md`
   - replace “implemented in this candidate” or equivalent wording with
     current merged-baseline language;
   - make clear that C1 is already implemented and unchanged by this
     documentation-contract tranche.

2. `.docs/rw0-remote-worker-contact-phase-entry.md`
   - distinguish current RW0-C1 durable evidence from future RW0-C2 durable
     progression decision, latch, and terminal mechanics;
   - do not describe all RW0-C durable mechanics as future.

3. `.docs/autonomous-software-development-operating-model.md`
   - make the same C1-current/C2-future distinction in the authoritative
     composition record.

Keep append-only/supersession treatment in
`.docs/c2b-durable-development-state.md`.

Do not modify `AGENTS.md`, `.docs/authority-boundaries.md`, or
`.docs/software-development-progression-boundary.md`; the audit found no
contradiction requiring those changes.

## Test architecture

Replace the circular test structure.

### Current-source binding

Use static AST/text inspection without importing live repository modules.

Derive and verify from current source:

- `_VALIDATION_TUPLES`;
- `_REVIEW_TUPLES`;
- V14 conflict grammar;
- V15 separation-status override grammar;
- canonical five-branch inventory;
- current result/reason enum vocabulary relevant to the projection.

The owner document’s projection must equal the current source-derived tuples
exactly.

Current-source drift must fail the test rather than adapt silently.

### Independent fixed expectations

The tests must contain an independently fixed accepted contract expectation for:

- exact validation projection rows;
- exact review projection rows;
- exact normalized reducer outcomes;
- exact reason classes;
- exact matrix-owner inventory and order;
- exact branch mapping;
- exact block-reason precedence;
- exact latch and terminal nonclaims.

Do not implement two test-local reducers and compare them with each other.

Prefer:

- parsing the owner’s human-readable tables;
- parsing its machine-readable block;
- comparing both to one fixed accepted golden representation;
- using a small generic interpreter only to exercise the owner’s parsed data;
- comparing finite outcomes to independently fixed expected rows.

### Permanent hostile controls

Permanent tests must prove failure for in-memory or temporary external copies
with each one-premise mutation:

1. change a prose reason while leaving the machine block unchanged;
2. change a machine projection while leaving prose unchanged;
3. remap one admission fault;
4. remove `risk_lane`;
5. add, duplicate, or reorder a matrix owner;
6. alter one current-source validation tuple;
7. alter one review separation override;
8. remove productive-to-block final halt-only verification;
9. change one block halt-only entry to deny;
10. change one block halt-only entry to unknown;
11. change one block halt-only entry to conflict;
12. change model recommendation while holding all authoritative inputs fixed;
13. change one branch-to-kind/variant mapping;
14. add `cancel` or `redeliver`;
15. claim migration 0005, a writer, latch owner, terminal owner, public export,
    or production caller as current.

Each hostile must fail at the intended contract boundary.

### Structural absence and import guards

Fix AST inspection to examine:

- `ast.ImportFrom.module`;
- aliases on `ast.Import`;
- package-root exports;
- class method definitions in `StateStore` and `WriterSession`;
- migration resource inventory;
- source-module inventory;
- current production importers/callers.

Do not infer imported modules from alias names alone.

Require structurally:

- no migration 0005;
- migrations exactly 0001–0004;
- no RW0-C2 source/SQLite writer module;
- no package-root export;
- no new StateStore or WriterSession public method;
- no production caller;
- no runtime, service, worker, Git, ES, Bridge, or provider integration.

## Allowed path ceiling

Only these seven paths may differ from HEAD at closeout:

1. `.docs/architecture.md`
2. `.docs/autonomous-software-development-operating-model.md`
3. `.docs/c2b-durable-development-state.md`
4. `.docs/rw0-c1-durable-evidence.md`
5. `.docs/rw0-remote-worker-contact-phase-entry.md`
6. `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
7. `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`

Use the smallest truthful edits within this exact ceiling.

No other existing test module may change.

## Protected surfaces

Do not modify:

- `AGENTS.md`;
- any `src/` path;
- any migration;
- `sqlite_migration.py`;
- transaction, reader, writer, StateStore, or package-export code;
- `.docs/authority-boundaries.md`;
- `.docs/software-development-progression-boundary.md`;
- schemas, configs, examples, or supporting repositories.

## Validation

Run serially with:

- `PYTHONDONTWRITEBYTECODE=1`
- pytest cache disabled.

At minimum:

1. repaired contract-test module;
2. permanent hostile-copy tests;
3. architecture/operating-model/progression tests;
4. C2B, RW0-C1, remote-phase, migration, runtime-nonauthority, and
   nonimplementation groups relevant to the tranche;
5. the complete repository suite;
6. `git diff --check`;
7. new-file whitespace checks;
8. exact source and migration byte-preservation checks;
9. final seven-path status and per-file receipt;
10. artifact/cache scan.

Use a clean private local-only external clone for the full suite if needed.
Do not contact a remote and do not modify the live ignored cache.

Ephemeral test-fixture databases are permitted. Do not open or mutate any
operator or product-state database.

## Closeout provenance

Do not generate an external manifest.

Report inline:

- opening and closing Git coordinates;
- exact seven changed paths;
- status/classification/mode;
- per-file byte size and SHA-256;
- SHA-256 of the deterministic full binary Git diff;
- concise per-file change description;
- exact validation commands and results;
- hostile-control results;
- source and migration preservation;
- cache/artifact posture;
- unresolved latch and physical-persistence seams;
- all non-authorizations.

Run the exact receipt calculation twice and require identical output before
claiming success.

## Success token

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIRED_VALIDATED_READY_FOR_REAUDIT`

Success authorizes only a fresh read-only independent audit.

## Blocking token

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIR_BLOCKED`

## Required non-actions

State:

```text
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
```

After a successful repair, the exact seven live paths need a fresh independent audit. The acceptance-latch and physical-persistence freezes remain out of scope until this semantic contract is accepted.

**Sources:** The independent audit’s exact verdict, findings, validation, and prescribed successor boundary. :chatgpt-content-reference{index="7"}

**Confidence:** High that the audit block is correct; high that the reducer architecture itself should be retained; high that the repair above closes the documented semantic, authority, supersession, and test-causality defects without widening the seven-path boundary.
