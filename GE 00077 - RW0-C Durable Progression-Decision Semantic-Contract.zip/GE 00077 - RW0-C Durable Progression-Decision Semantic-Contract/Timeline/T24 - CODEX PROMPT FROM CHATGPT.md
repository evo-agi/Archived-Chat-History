# Governed Execution Coordinator — RW0-C Durable Decision Branch Contract V4 Independent Re-audit

## Role

Perform a fresh, parent-led, local, read-only independent re-audit of the V4
RW0-C durable progression-decision semantic-contract candidate.

The checked-out repository is the sole audit target and source of current
contract truth.

Do not request or use chat exports, prior audit attachments, Downloads
artifacts, Project artifacts, historical JSONL packages, generated manifests,
or sibling repositories.

Do not repair the candidate.

Return one substantive audit report inline in the final response. Do not create
or attach a report, manifest, package, freeze artifact, or other client-visible
file.

## Repository and committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Expected committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- HEAD tree: `9e69d4a517b482704c159958abc2f90ed3cdcfd8`
- sole parent: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- subject: `feat: implement RW0-C post-execution pure owners`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Any baseline mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Exact V4 candidate

The live worktree must contain exactly these seven candidate paths and no other
tracked or untracked difference from HEAD:

| Status | Path | Mode | Bytes | SHA-256 |
|---|---|---|---:|---|
| `M` | `.docs/architecture.md` | `0644` | 42,104 | `d10da9d372c9920ed567f2f705d798cd52f8fb37a9bb94a414f9f4ce193d5494` |
| `M` | `.docs/autonomous-software-development-operating-model.md` | `0644` | 37,278 | `f78a4e62a2e17e7b2cf511a2eb5638e8fa6b64d291207d5fdc6b9fa08a8183ee` |
| `M` | `.docs/c2b-durable-development-state.md` | `0644` | 1,887,232 | `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5` |
| `M` | `.docs/rw0-c1-durable-evidence.md` | `0644` | 14,370 | `3507dca630a103a8ba54f643b662183371ae8d76333d721a91ba6e716eb9f93b` |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | `0644` | 55,944 | `d3fdc11e379cf7bad3bd547c6cc848abdaaa145e0e11ef6058cb7cec9bb29b54` |
| `??` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | `0644` | 68,944 | `92f1d2b34f9cf2486102edf31de142acc07db9a116f64d64212ca497d0a554c1` |
| `??` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | `0644` | 225,054 | `2e890348745bc5c22470e461cb665912302b12033ad83c8d52c43bd6bd586660` |

All seven must be regular non-symlink files.

Require:

- exactly five tracked modifications;
- exactly two untracked files;
- zero staged files;
- zero unmerged files;
- zero additional modified, added, deleted, renamed, type-changed, or untracked
  paths.

The following file must remain exact:

`AGENTS.md`

- bytes: `60,530`
- SHA-256:
  `c12a3449e761728f2093c19bb30134c54994b045843313471a6d715b648355a6`

Protected current surfaces must remain byte-identical to HEAD:

- every `src/` path;
- every existing tracked test;
- all migrations;
- `src/ge_nwp_coordinator/sqlite_migration.py`;
- transaction, reader, writer, StateStore, WriterSession, and package-export
  source;
- `.docs/authority-boundaries.md`;
- `.docs/software-development-progression-boundary.md`;
- migrations 0001–0004 and their catalog identities.

Migration `0005` must remain absent.

Any path, classification, type, mode, size, or SHA mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

## Deterministic binary-patch corroboration

Independently construct the complete binary patch by processing the seven paths
in the table order.

For each tracked path:

`git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- <path>`

For each untracked path:

`git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null <path>`

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate the exact stdout bytes in table order.

Expected V4 candidate:

- bytes: `311,587`
- SHA-256:
  `418851b0af06775e4ddd2979ffe5eb8dd230eccbdec61535e8f08226bf4a4fb6`

The per-file receipts and live Git status are primary provenance. An unresolved
binary-patch mismatch is a provenance mismatch.

## V3-to-V4 transition corroboration

The implementation closeout reports that only these two paths changed from the
V3 candidate:

1. `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
   - V3: 68,424 bytes /
     `2f4885a64d28470463fda6f7763c5820c23b036931ce1769bb7174ec71399681`
   - V4: 68,944 bytes /
     `92f1d2b34f9cf2486102edf31de142acc07db9a116f64d64212ca497d0a554c1`

2. `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
   - V3: 154,849 bytes /
     `86a85d0a028ecc1f351d6442db04681965592620f0cc6512360ba9f0a0ba4460`
   - V4: 225,054 bytes /
     `2e890348745bc5c22470e461cb665912302b12033ad83c8d52c43bd6bd586660`

The other five candidate paths must match the exact V4 receipts above.

This transition is corroborating evidence only. The live V4 bytes are the audit
target.

## Cache-report defect and audit treatment

The implementation closeout quotes this as the closing cache SHA-256:

`13d161c803f1242f87d7c8e62b76cf0eb7b7d36a3a8ea87a53849736a94fe`

That string is not a valid SHA-256 representation because it contains only 61
hexadecimal characters.

Treat it as a report-only defect, not as a fixed provenance input.

At audit opening:

1. inventory the live ignored cache without moving or modifying it;
2. record every repository-relative path, file type, mode, byte size, and
   SHA-256;
3. encode a deterministic canonical inventory;
4. record its exact byte size and SHA-256.

At closeout, require exact byte equality with the opening inventory.

Block only if the live cache changes, current candidate provenance is
uncertain, or additional repository effects are discovered. Otherwise report
the malformed implementation-report digest as a low-severity report defect.

Do not move, delete, rewrite, import through, or otherwise touch the live cache.

## Validation-count report treatment

The implementation closeout reports:

- complete contract module: `1266 passed`;
- architecture/operating/progression: `85 passed`;
- remote phase: `969 passed`;
- C2B/C1/migration/runtime/nonimplementation: `1677 passed`;
- complete repository: `7450 passed, 3 warnings`.

The broad group count differs from the prior V3 closeout’s `2655` because the
exact command is not included in the V4 summary. Do not treat either broad count
as a fixed acceptance coordinate.

Use the repository and this prompt to define the relevant test modules. Record
the exact command and observed result. The complete module, exact selectors,
and complete repository count are fixed claims to reproduce.

## Audit posture

This is an independent audit, not implementation validation.

Permitted:

- read-only Git inspection;
- static documentation, source, migration, and test inspection;
- read-only Python and AST parsing with `PYTHONDONTWRITEBYTECODE=1`;
- production-module execution only in a private external local clone;
- temporary hostile copies outside the live repository;
- at most three bounded read-only explorer subagents with self-contained
  prompts.

Prohibited:

- editing, formatting, cleaning, or repairing live repository files;
- staging, committing, pushing, or modifying a PR;
- remote contact;
- sibling-repository inspection;
- modifying or moving the ignored live cache;
- importing repository modules in the live checkout;
- opening or mutating an operator or product-state database;
- running migrations;
- installing dependencies;
- starting services;
- generating client-visible artifacts.

Temporary audit data must remain outside the repository and be removed at
closeout. Record its cleanup disposition.

## Source-of-truth posture

Apply the repository’s authority hierarchy:

- Git owns commit, tree, blob, and ref facts.
- `AGENTS.md` routes repository composition and contract authority.
- `.docs/` owns current and target contract semantics within each document’s
  declared scope.
- `.docs/autonomous-software-development-operating-model.md` is the
  authoritative composition/current-status record.
- source and migrations implement current behavior and durable
  representation.
- tests are executable evidence and drift guards, not an independent semantic
  owner.
- reports and generated artifacts are evidence only.

The V4 C2 document is intended to be the sole owner of an accepted future
semantic contract. It must not claim that the future reducer or durable
decision owner is currently implemented.

Classify findings as:

- authority/contract drift;
- semantic defect;
- documentation/supersession defect;
- test-adequacy defect;
- provenance mismatch;
- validation defect;
- artifact/security concern;
- process noncompliance;
- report-only uncertainty.

## Recommended explorer structure

At most three bounded read-only explorers may be used.

### Explorer 1 — production witness and reachability audit

Inspect:

- final accepted/excluded matrix-pair partition;
- actual constructor/evaluator/relation execution;
- first accepted output;
- excluded-pair proof boundaries;
- fixed-versus-observed independence.

### Explorer 2 — oracle and hostile-causality audit

Inspect:

- documented pipeline versus executable interpreter;
- duplicate-key rejection;
- exact JSON-pointer protection;
- halt-only and earlier-block traces;
- model-after-latch ordering;
- external mutant causality;
- whether the test module is becoming a shadow implementation.

### Explorer 3 — authority, structural, and documentation audit

Inspect:

- sole owner and future/current classification;
- temporary source barrier;
- semantic alias/re-export guards;
- migration/public/runtime nonimplementation;
- append-only C2B treatment;
- process/report deviations.

The parent must independently inspect central evidence and reconcile all
explorer findings.

## Required inspection

Read in full or through all relevant current and superseding sections:

- `AGENTS.md`
- `README.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/architecture.md`
- `.docs/authority-boundaries.md`
- `.docs/software-development-progression-boundary.md`
- `.docs/c2b-durable-development-state.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/c2a-first-slice-semantic-protocol-contract.md`
- `.docs/durable-state-model.md`
- `.docs/sqlite-operations-and-recovery.md`
- `.docs/sqlite-threat-model.md`

Inspect current source owners without modifying them:

- `src/ge_nwp_coordinator/_post_execution_evidence_values.py`
- `src/ge_nwp_coordinator/_post_execution_policy_values.py`
- `src/ge_nwp_coordinator/_rw0_c_decision_input_values.py`
- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_development_effect_row_values.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- current RW0-C1 replay/recovery owners;
- transition-controller and writer-session contracts;
- package-root exports, StateStore, and WriterSession.

Inspect:

- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- all post-execution pure-owner tests;
- architecture, operating-model, progression, C2B, C1, remote-phase,
  migration, runtime-nonauthority, and nonimplementation tests relevant to the
  tranche.

## Audit question 1 — authority and current-versus-future truth

Verify that:

- the new C2 document is the sole future reducer owner;
- the operating model remains composition/status authority;
- architecture and other changed documents route to the owner without claiming
  implementation;
- C1 remains current merged implementation;
- C2 reducer, command, writer, latch, terminal, recovery family, physical
  persistence, and migration treatment remain future;
- no current durable decision writer, migration 0005, production caller,
  public export, receipt family, or runtime behavior is claimed;
- the C2B addition remains append-only and creates no second current owner;
- untouched authority and progression documents remain compatible.

A competing authority or implementation overclaim is blocking.

## Audit question 2 — independently rederive the final matrix partition

Do not trust the owner document, machine block, fixed test constants, witness
registry, or implementation report.

Independently derive the complete metadata-declared owner/result/reason
inventory from current source.

Then independently classify every metadata pair by the first valid complete
production path:

- `accepted_emittable`;
- `no_evaluator_branch`;
- `valid_construction_precludes`;
- `accepted_relation_precludes`.

The implementation reports:

| Owner | Accepted | Excluded | Metadata total |
|---|---:|---:|---:|
| `standing_policy` | 8 | 9 | 17 |
| `risk_lane` | 5 | 7 | 12 |
| `decision_time_authority` | 15 | 1 | 16 |
| `global_stop` | 3 | 3 | 6 |
| `source_effect_ceiling` | 13 | 4 | 17 |
| **Total** | **44** | **24** | **68** |

Treat those counts as claims to verify.

Specifically adjudicate:

`source_effect_ceiling / deny / source_effect_exceeds_current_effect`

The V4 report says it is now `accepted_relation_precludes` because the required
production relation rejects first with `source_owner_mismatch`.

Require exact source, constructor, evaluator, and relation/action evidence.

Any accepted pair without a complete valid path, or excluded pair with a valid
path, is blocking.

## Audit question 3 — all accepted production witnesses

For every final accepted pair:

1. construct valid current production inputs;
2. invoke the actual current production evaluator;
3. invoke the actual required relation/action when the decision basis consumes
   a relation-owned value;
4. read the observed owner/result/reason only from the returned production
   object or accepted relation/action result;
5. identify the first accepted boundary;
6. compare the independently observed pair with a fixed expected pair.

The witness builder must not receive, store, close over, or reconstruct its
expected result/reason.

Reconstruct the complete observed ledger:

```text
witness_id
production constructors
production evaluator
relation/action boundary
observed owner
observed result
observed reason
first accepted boundary
```

Require exact set equality with the final accepted inventory.

Independently instrument relation/action invocation counts for every
relation-owned witness.

Direct `from_mapping`, forged output values, dataclass substitution,
monkeypatching, or membership checks against a requested label receive no
witness credit.

Reproduce the earlier V21 source-owner mismatch probe and confirm that rejected
evidence credits no downstream pair.

## Audit question 4 — all excluded-pair proofs

For each excluded metadata pair, verify its exact classification.

### `no_evaluator_branch`

Require:

- normalized AST fingerprint of the exact evaluator/helper surface;
- resolution of return-site values through names, local constants, mappings,
  tuple/list construction, conditional expressions, and called local helpers;
- fixed reviewed return-pair inventory;
- dynamic-construction hostile detection independent of the complete source
  manifest.

### `valid_construction_precludes`

Invoke the actual production constructor/invariant boundary and assert the exact
first rejection class/reason.

### `accepted_relation_precludes`

Invoke the actual standing-policy, risk-lane, or other required relation/action
boundary and assert the exact first rejection class/reason.

A proof that merely dispatches from its own classification ledger or rebuilds a
final value with `from_mapping` is blocking.

Require direct forgery of every excluded pair into the contract interpreter to
yield `matrix_conflict`.

## Audit question 5 — fixed-versus-observed independence

Require real independence among:

1. fixed expected accepted/excluded partition;
2. source metadata extraction;
3. witness-builder registry;
4. observed production ledger;
5. excluded-boundary proof registry;
6. human-document parsing;
7. machine-contract parsing;
8. generic contract interpretation;
9. fixed finite reducer outcomes;
10. hostile expectations.

Block if:

- one mutable record authors both expected and observed labels;
- a builder ID or closure contains its expected pair and the test reads it back;
- reachability classifications choose their own proof result;
- source extraction becomes its own expected answer;
- parsed contract data supplies its own expected output;
- removing a witness or proof silently reduces parameter count;
- a hostile receives credit from an unrelated assertion.

## Audit question 6 — documented and executable pipeline order

Require exact order:

1. basis grammar/identity/lineage/profile/provenance validation;
2. complete matrix inventory/owner/profile/applicability/effect/pair validation;
3. currentness reduction;
4. V14/V15 reduction;
5. productive evaluation when required;
6. final branch and block-summary selection;
7. halt-only verification when required;
8. acceptance-latch validation when acceptance is selected;
9. model recommendation consistency last.

Directly test combined faults:

- missing matrix owner + V14 conflict;
- foreign matrix pair + V14 conflict;
- currentness conflict + V14 conflict with valid matrices;
- V14 conflict alone;
- V15 conflict alone.

Require the documented earlier stage to control each case.

Inspect the generic interpreter and trace rather than relying only on tests.

## Audit question 7 — duplicate-key rejection

Require recursive duplicate-key rejection for:

- embedded machine contract;
- fixed normative JSON literals;
- hostile temporary copies;
- any JSON used as a semantic expectation.

Independently add a contradictory shadowed duplicate key and require
`duplicate_json_key:<exact-key-or-pointer>` before canonicalization or semantic
comparison.

No unrestricted last-key-wins parser may receive normative credit.

## Audit question 8 — exact scalar-pointer protection

Independently enumerate all final normative scalar leaves.

The implementation reports:

- independent scalar JSON pointers: `453`;
- selector nodes: `455` in the V4 summary.

Reconcile the distinction exactly.

Require:

```text
fixed scalar count
=
enumerated pointer count
=
positive coverage-map count
=
hostile coverage-map count
```

For every pointer:

- direct positive assertion;
- one-premise mutation;
- exact expected error pointer;
- exact equality of reported and expected pointer.

Independently weaken the pointer checker to generic prefix/substring matching.
The permanent module must fail at a dedicated checker-integrity test, not only
because another unrelated leaf comparison fails.

## Audit question 9 — earlier-block evidence and trace

For any conclusive productive candidate, productive matrices must be evaluated
and retained even when stale/unknown currentness already gives the final
block-summary reason.

Require trace markers and retained evidence for:

- stale currentness + productive candidate;
- unknown currentness + productive candidate;
- earlier block + productive deny;
- earlier block + productive unknown;
- earlier block + exact matrix conflict.

Require:

- all five productive entries in canonical order;
- exact observed result/reason pairs;
- matrix conflicts still produce no-write;
- block summary remains `decision_basis_not_current` when appropriate.

Reproduce the suppression mutant. It must fail at the exact
`productive_matrix_evaluated` or retained-evidence boundary.

## Audit question 10 — all halt-only routes

Audit independently:

1. direct terminal reject;
2. stale-currentness block;
3. unknown-currentness block;
4. validation-nonconclusive block;
5. review-nonconclusive block;
6. productive-deny converted block;
7. productive-unknown converted block.

For each route and each of the five owners, substitute the same owner’s
productive permit and require:

`halt_only_matrix_contract_conflict`

Reproduce all 35 direct hostiles.

Also verify deny, unknown, exact conflict, foreign reason, wrong pair, wrong
applicability, and wrong effect-class negatives.

A bypass mutant must fail at the intended route/owner boundary.

## Audit question 11 — model recommendation after latch

Require model consistency to execute only after every authoritative no-write
gate, including acceptance-latch validation.

For every authoritative branch, test:

- all five recognized recommendations;
- one out-of-vocabulary recommendation.

Require exact status/reason while branch/admission remain unchanged.

For acceptance, combine every recommendation with every defined latch-failure
class and require:

- latch no-write controls;
- model trace marker absent.

An isolated unrecognized recommendation must remain non-authoritative evidence.

## Audit question 12 — semantic test complexity and shadow-implementation risk

The V4 contract-test file is 225,054 bytes.

Determine whether it remains a verifier or has become a parallel semantic
implementation.

Acceptable verifier responsibilities:

- fixed expectations;
- source AST inspection;
- production witness construction;
- generic data-driven interpretation of the owner contract;
- exhaustive finite assertions;
- hostile mutation helpers.

Blocking shadow-owner signals include:

- a second bespoke implementation of production evaluators;
- test-local recreation of relation/action semantics instead of invoking them;
- a second independent reducer whose truth is not parsed from the owner;
- complex source emulation used as primary behavioral evidence;
- test data and interpreter jointly authoring expected outcomes;
- source changes requiring duplicate edits in the test oracle even when the
  owning contract is unchanged.

Report code-size and complexity only as evidence. Do not reject merely because
the file is large. Reject if semantic authority has moved into test code or the
test reproduces source behavior instead of observing it.

## Audit question 13 — temporary source barrier and semantic structural guards

Independently reconstruct the exact committed source manifest.

Require the complete temporary barrier to catch:

- any added source file;
- any deleted source file;
- any modified source byte;
- any nested module;
- symlink or unsupported type;
- mode drift.

Verify the owner calls this barrier temporary and supersedable by a future
authorized source tranche.

Separately inspect semantic AST resolution for:

- `ast.Import`;
- every absolute/relative `ast.ImportFrom` form;
- module aliases;
- symbol aliases;
- attribute call chains;
- re-exports through `__init__.py`;
- nested packages;
- full module identity rather than basename-only identity.

Reproduce absolute alias, relative alias, and package re-export mutants. Each
must fail the semantic guard even when the complete source-manifest check is
not executed.

## Audit question 14 — exact hostile boundaries

Review every hostile category that receives semantic credit.

Require:

- exact exception class;
- exact reason or boundary ID;
- exact JSON pointer or owner/pair where applicable;
- exact trace stage where applicable.

Bare “some AssertionError occurred” is insufficient.

Sample at least one hostile from every major category and inspect the complete
fixed hostile registry for generic assertions.

## Audit question 15 — external-mutant reproduction

Independently construct at least these 16 mutants in disposable copies:

1. V14/V15 conflict returned before matrix grammar;
2. witness label self-authored from expected metadata;
3. relation-owned witness bypassing its relation/action;
4. accepted pair made unreachable;
5. metadata-only pair dynamically emitted through non-literal construction;
6. accepted-relation proof that skips the relation;
7. contradictory duplicate JSON key;
8. exact pointer checker weakened to generic containment;
9. aliased absolute import/call;
10. aliased relative import/call;
11. package re-export alias;
12. productive evaluation suppressed after earlier block;
13. same-owner productive permit accepted on halt-only;
14. model evaluation moved before latch;
15. neutral source file added;
16. existing source byte modified.

For each mutant require:

- full expected module collection;
- failure at the intended exact boundary;
- no parameter-count shrinkage;
- no syntax/format-only failure.

## Audit question 16 — exact selector reproducibility

For the contract module, run `--collect-only -q` before each selector and
record exact selected node count.

Implementation-reported selectors:

| Selector | Reported selected/execution |
|---|---:|
| `pipeline_order` | `5 / 5 passed` |
| `production_witness` | `56 / 56 passed` |
| `source_reachability` | `36 / 36 passed` |
| `duplicate_key` | `2 / 2 passed` |
| `scalar_pointer` | `455 / 455 passed` |
| `halt_only` | `363 / 363 passed` |
| `earlier_block` | `1 / 1 passed` |
| `model_authority` | `36 / 36 passed` |
| `structural_nonimplementation` | `12 / 12 passed` |
| `hostile` | `551 / 551 passed` |

Reproduce rather than assume.

No selector may select zero tests, silently over-select unrelated repository
tests, or rely on undisclosed module scoping.

## Audit question 17 — preserved semantics and boundaries

Verify V4 did not drift:

- exact V14/V15 projection;
- matrix inventory/order;
- conflict and no-write precedence;
- currentness meanings;
- nonconclusive block;
- `terminal > replan > repair > accept`;
- exact five branches and migration-0002 mapping;
- all five version advancing;
- cancel/redeliver exclusion;
- block-summary precedence;
- no-write/block/recovery-unresolved distinction;
- caller expected branch as conflict assertion only;
- model and caller non-authority;
- abstract latch dependency;
- terminal and RW0-D/E separation;
- future bounded-hybrid persistence;
- migration 0005 absence.

## Audit question 18 — documentation and supersession

Verify:

- C1 remains current merged implementation;
- C2 reducer/latch/terminal/persistence remain future;
- operating model remains composition/status authority;
- architecture points to the semantic owner without claiming implementation;
- remote-phase map distinguishes C1 from C2;
- C2B remains append-only and creates no competing reducer owner;
- untouched authority/progression documents remain compatible;
- no changed document reports the test verifier as production behavior.

## Independent validation

Construct a private external local clone from committed HEAD without remote
contact.

Overlay exactly the seven live candidate files after verifying all receipts.

Do not move, delete, rewrite, or import through the live ignored cache.

Run serially with:

- `PYTHONDONTWRITEBYTECODE=1`
- `PYTHONPATH=.:src`
- pytest cache disabled;
- external `--basetemp`.

At minimum run:

1. complete repaired contract module;
2. every exact selector listed above;
3. architecture, operating-model, and progression tests;
4. remote-phase tests;
5. relevant C2B/C1/migration/runtime/nonimplementation tests, with the exact
   command reported;
6. complete repository suite;
7. `git diff --check`;
8. both untracked-file whitespace checks;
9. CR, trailing-whitespace, and final-newline checks;
10. source, migration, existing-test, and protected-document preservation;
11. external-clone artifact scan.

Implementation-reported fixed results:

- complete contract module: `1266 passed`;
- complete repository: `7450 passed, 3 warnings`.

Reproduce rather than assume.

The only expected warnings are the existing Python 3.13 multi-threaded `fork()`
deprecations from unchanged B2C writer-session tests.

Any other warning, count mismatch, or failure must be investigated.

## Final provenance

After deleting all audit-created temporary material, reverify:

- exact seven-path status;
- exact file types, modes, sizes, and hashes;
- exact binary-patch size and SHA;
- zero staged and unmerged paths;
- no additional changed or untracked path;
- exact `AGENTS.md`;
- unchanged source tree;
- unchanged existing tracked tests;
- unchanged protected documents;
- migrations exactly 0001–0004;
- no migration 0005;
- exact opening/closing ignored-cache equality;
- no audit-created repository artifact.

Run the complete receipt calculation twice and require byte-identical output.

## Severity and verdict rules

Any of the following is blocking:

- provenance mismatch;
- incorrect accepted/excluded partition;
- accepted pair without a valid independent production witness;
- excluded pair without the claimed real boundary proof;
- expected and observed witness coupling;
- pipeline-order disagreement;
- duplicate-key acceptance;
- pointer-check weakening escape;
- suppressed productive evaluation;
- bypassable halt-only route;
- model evaluation before latch or model authority;
- shadow semantic implementation in the test module;
- semantic structural-guard bypass;
- generic hostile boundaries;
- authority conflict or implementation overclaim;
- physical/runtime/public scope widening;
- validation mismatch not attributable to the audit environment.

### Accept

Use only when no unresolved High- or Medium-severity finding remains:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance authorizes only a separate commit/publication gate for the exact
seven audited paths.

It does not authorize:

- source implementation;
- migration `0005`;
- durable decision writing;
- acceptance-latch implementation;
- terminal-outcome implementation;
- runtime activation;
- public API widening;
- the later physical-persistence implementation.

### Block

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_AUDIT_BLOCKED`

### Provenance mismatch

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Inline report structure

Return:

1. primary verdict;
2. exact baseline and candidate provenance;
3. binary-patch and V3-to-V4 reconciliation;
4. cache-report defect and live-cache reconciliation;
5. inspection scope and limits;
6. authority/current-versus-future audit;
7. independently derived matrix partition;
8. accepted production-witness audit;
9. excluded-pair proof audit;
10. fixed-versus-observed independence audit;
11. pipeline-order audit;
12. duplicate-key audit;
13. scalar-pointer audit;
14. earlier-block trace audit;
15. all halt-only routes audit;
16. model/latch ordering audit;
17. shadow-implementation risk audit;
18. source-manifest and semantic structural-guard audit;
19. exact hostile-boundary audit;
20. independent mutant results;
21. selector/count reproducibility;
22. preserved semantics and documentation audit;
23. independent validation results;
24. final live provenance;
25. severity-ranked findings;
26. exact next boundary;
27. required non-actions;
28. final token.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TRACKED_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
