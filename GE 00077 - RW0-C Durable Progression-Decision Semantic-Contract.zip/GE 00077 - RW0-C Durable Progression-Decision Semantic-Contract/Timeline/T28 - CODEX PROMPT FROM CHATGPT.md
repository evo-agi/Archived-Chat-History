# Governed Execution Coordinator — RW0-C Durable Decision Branch Contract Verifier Repair V5

## Objective

Repair the uncommitted RW0-C durable progression-decision semantic-contract
candidate after the resumed V4 independent audit returned:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_AUDIT_BLOCKED`

The audit found no High or Medium defect in the semantic contract, matrix
partition, production relations, authority routing, documentation,
migration boundary, or runtime/public nonimplementation posture.

Exactly four Medium verifier/test-adequacy defects remain:

1. production-witness ledger labels can be self-authored from fixed
   expectations while all tests remain green;
2. exact JSON-pointer comparison can be weakened to prefix comparison while all
   tests remain green;
3. retained productive-evidence reasons are not asserted exactly;
4. complete matrix permit-reason validation is not causally fixed to the
   documented pre-currentness/pre-selection stage.

This is a parent-only, one-file test repair.

Do not modify the semantic owner document, any other documentation, source,
migrations, existing tracked tests, schemas, transaction code, readers,
writers, StateStore, WriterSession, package exports, public APIs, or runtime
behavior.

Return one substantive inline closeout report. Do not create or attach an
external report, manifest, package, or freeze artifact.

## Repository and exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- tree: `9e69d4a517b482704c159958abc2f90ed3cdcfd8`
- sole parent: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- subject: `feat: implement RW0-C post-execution pure owners`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged and unmerged paths
- no active Git operation or index lock

Do not fetch or contact remotes.

## Exact opening seven-path candidate

Require exactly these seven regular non-symlink mode-`0644` files and no other
difference from HEAD:

| Status | Path | Bytes | SHA-256 |
|---|---|---:|---|
| `M` | `.docs/architecture.md` | 42,104 | `d10da9d372c9920ed567f2f705d798cd52f8fb37a9bb94a414f9f4ce193d5494` |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 37,278 | `f78a4e62a2e17e7b2cf511a2eb5638e8fa6b64d291207d5fdc6b9fa08a8183ee` |
| `M` | `.docs/c2b-durable-development-state.md` | 1,887,232 | `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5` |
| `M` | `.docs/rw0-c1-durable-evidence.md` | 14,370 | `3507dca630a103a8ba54f643b662183371ae8d76333d721a91ba6e716eb9f93b` |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 55,944 | `d3fdc11e379cf7bad3bd547c6cc848abdaaa145e0e11ef6058cb7cec9bb29b54` |
| `??` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 68,944 | `92f1d2b34f9cf2486102edf31de142acc07db9a116f64d64212ca497d0a554c1` |
| `??` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 225,054 | `2e890348745bc5c22470e461cb665912302b12033ad83c8d52c43bd6bd586660` |

Require exact `AGENTS.md`:

- bytes: `60,530`
- SHA-256:
  `c12a3449e761728f2093c19bb30134c54994b045843313471a6d715b648355a6`

Correct opening deterministic seven-path binary patch:

- bytes: `312,049`
- SHA-256:
  `86c5de54e890016234d95df72146864cfe8b5d88b95e333cb6701d03b845e4df`

Stop before editing on any mismatch:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_VERIFIER_REPAIR_V5_BLOCKED`

## Mutation ceiling

Only this path may change from its opening bytes:

`tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`

The semantic owner and the other five candidate documents must remain
byte-identical to the opening receipts.

No existing tracked test may change.

The final candidate path set remains exactly the same seven paths relative to
HEAD.

## Accepted audit results that must not be reopened

Preserve without semantic change:

- the sole-owner and current-versus-future documentation posture;
- the exact `44 accepted / 24 excluded / 68 metadata total` matrix partition;
- every accepted production witness and excluded-pair boundary;
- `source_effect_exceeds_current_effect` as
  `accepted_relation_precludes`;
- documented and executable pipeline order;
- recursive duplicate-key rejection;
- productive evaluation after earlier currentness block;
- all seven halt-only routes;
- all 35 same-owner productive-permit rejections;
- model consistency after acceptance-latch validation;
- exact five durable branches and migration-0002 mapping;
- V14/V15 projection and precedence;
- no-write/block/recovery-unresolved separation;
- caller/model non-authority;
- abstract future latch interface;
- terminal and RW0-D/E separation;
- future bounded-hybrid persistence;
- migration `0005` absence;
- the temporary and supersedable complete-source manifest barrier;
- semantic alias, relative-import, and re-export guards.

Do not change the owner contract merely to make tests easier.

## 1. Production-witness label provenance

The production witness ledger must derive `result` and `reason` exclusively
from the actual returned production entry or accepted relation/action result.

Fixed expectations may be used only after observation, to compare the observed
ledger against the accepted set.

### Required separation

Maintain these distinct layers:

1. witness-builder registry:
   - stable witness ID;
   - builder callable;
   - constructor/evaluator/relation description;
   - no expected result or reason;
2. runtime observation:
   - returned production object;
   - observed owner;
   - observed result read from the returned entry;
   - observed reason read from the returned entry;
   - first accepted boundary;
3. fixed expected pair set;
4. equality assertion between the observed set and the fixed expected set.

No function that extracts observed labels may read, receive, close over, or
index:

- `FIXED_EXPECTED_ACCEPTED_PAIRS`;
- the machine contract’s accepted-pair inventory;
- the human contract table;
- any expected-result/expected-reason field.

### Runtime extractor-integrity test

Add a direct integrity test over the exact extraction path used by
`_production_witness_ledger()`:

- provide a returned-entry-shaped object or immutable mapping whose
  `result/reason` are sentinel values distinct from the fixed expectation;
- require the extraction path to return those exact sentinel values;
- then require the separate accepted-set comparison to reject them at the exact
  boundary:
  `production_witness:observed_pair_set:<owner>`.

The integrity test must invoke the same extraction helper used by the live
production ledger. A separate test-only extractor receives no credit.

### Structural provenance guard

Statically inspect the ledger and observed-label extraction functions and
require:

- no load/reference to fixed expected pair constants;
- no load/reference to parsed contract accepted-pair inventories;
- direct access to the returned entry’s `result` and `reason`;
- observed labels are stored before the fixed-set comparison.

Use AST structure, not substring matching alone.

### Required external mutant

Replace observed ledger labels with values sourced from the fixed expected set
while leaving every builder invocation and relation/action count intact.

The full contract module must fail at the exact observed-label provenance or
sentinel-integrity boundary.

## 2. Exact JSON-pointer checker integrity

The contract-drift checker must require exact pointer equality.

Add a permanent checker-integrity test with the prefix case the V4 audit found
missing:

```text
expected pointer: /some/path
observed pointer: /some/path/suffix
```

or an equivalent real JSON Pointer pair.

The test must require rejection because the observed pointer is not exactly the
expected pointer.

Also cover the inverse and sibling cases:

```text
expected: /some/path/suffix
observed: /some/path

expected: /some/path
observed: /some/other
```

Assert the exact checker-integrity boundary, not merely that an assertion
occurred.

### Required external mutant

Weaken exact equality to `observed.startswith(expected)`.

The permanent module must fail specifically at the prefix-integrity test.

Do not alter the accepted scalar-pointer inventory unless the live owner
contract itself changed, which is not authorized.

## 3. Exact retained productive-evidence contents

When a conclusive productive candidate is evaluated, the interpreter’s retained
productive evidence must preserve the exact canonical sequence of all five
entries:

```text
owner
branch
applicability
governed_effect_class
result
reason
```

The current tests already protect:

- owner order;
- entry count;
- selected results;
- trace presence.

Extend them to protect every exact reason and all retained fields.

### Required cases

At minimum assert the complete five-entry retained sequence for:

- stale currentness + productive acceptance candidate;
- unknown currentness + productive repair candidate;
- earlier currentness block + productive deny;
- earlier currentness block + productive unknown;
- earlier currentness block + productive matrix conflict;
- normal currentness + all-permit productive branch.

Use owner-distinct valid reasons so replacing reasons with one fabricated
constant cannot accidentally match.

The expected retained sequence must be fixed independently of the returned
trace.

### Required external mutant

Replace every retained productive-evidence reason with a fabricated constant
while preserving owner order, result values, branch, and trace marker.

The full contract module must fail at an exact retained-evidence boundary that
identifies the owner or sequence position.

## 4. Complete matrix reason validation before currentness and selection

The owning document requires complete matrix grammar validation before
currentness reduction, V14/V15 reduction, and branch selection.

Every entry in every owner matrix must have its exact owner/profile/result/reason
grammar validated, including entries that are not ultimately selected.

No `evaluate_semantics` flag, selected-branch condition, currentness result, or
block-reason state may disable complete permit-reason validation.

### Required direct tests

For each of the five matrix owners:

1. start with a valid complete matrix;
2. mutate an unselected governed permit reason to a foreign or wrong same-owner
   permit reason;
3. combine it with a later currentness conflict or V14/V15 conflict;
4. require the matrix-grammar conflict to control before that later fault;
5. require no currentness/V14/V15 trace marker.

Repeat for an unselected halt-only permit reason.

This yields at least ten direct precedence tests:

- five owners × governed permit;
- five owners × halt-only permit.

Where one owner has only one valid permit for a profile, use a foreign valid
reason from another owner or the owner’s other-profile permit reason.

### Interpreter requirement

Complete matrix grammar validation must be unconditional for the full matrix
inventory.

A flag may suppress later semantic branch evaluation only after complete
grammar validation has succeeded. It may not suppress pair/reason validation.

### Required external mutant

Condition permit-reason validation on `evaluate_semantics=True`, selected
branch, absence of block reasons, or an equivalent later-stage predicate.

The full module must fail at the complete-matrix-stage precedence tests.

## 5. Exact hostile boundaries

Every new hostile or integrity test must assert:

- exact exception class;
- exact reason/boundary identifier;
- exact owner, sequence position, or JSON pointer where applicable;
- exact trace-stage absence/presence where applicable.

Bare `pytest.raises(AssertionError)` without an exact message or structured
boundary receives no semantic credit.

## 6. Do not expand into a shadow implementation

Use the existing data-driven interpreter, witness builders, trace, and coverage
maps.

Do not add:

- another reducer;
- another matrix grammar;
- another copy of the owner contract;
- another witness system;
- source evaluator emulation.

The repair should add integrity assertions around the existing verifier, not
create a new semantic owner in tests.

If closing these four gaps requires semantic changes to the owner contract or
production source, stop with the blocking token and report the required new
tranche instead of widening this one-file repair.

## 7. Reproducible selectors

Add or preserve uniquely reproducible, module-scoped selectors for:

```text
-k witness_label_provenance
-k pointer_checker_integrity
-k retained_productive_evidence
-k complete_matrix_stage
-k hostile
```

Before reporting each:

1. run `--collect-only -q`;
2. record the exact selected node count;
3. run the exact selector;
4. report the exact observed result.

No selector may select zero tests.

## 8. Required external mutants

In disposable external copies, prove exact failure for at least:

1. witness labels sourced from fixed expectations;
2. pointer equality weakened to prefix matching;
3. retained productive reasons replaced by one fabricated constant;
4. permit-reason validation conditioned on `evaluate_semantics=True`;
5. permit-reason validation limited to the selected branch;
6. complete matrix validation skipped after an earlier currentness block.

Each mutant must:

- retain the expected complete test-module collection;
- fail at the intended exact boundary;
- not rely on syntax, formatting, or parameter-count shrinkage.

## 9. Validation

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
-p no:cacheprovider
--basetemp=<external path>
```

Use a clean local-only external clone for production execution and the complete
suite.

Do not move, delete, rewrite, or import through the live ignored cache.

At minimum run:

1. complete repaired contract module;
2. each exact selector above;
3. existing selectors:
   - `pipeline_order`
   - `production_witness`
   - `source_reachability`
   - `duplicate_key`
   - `scalar_pointer`
   - `halt_only`
   - `earlier_block`
   - `model_authority`
   - `structural_nonimplementation`;
4. architecture/operating-model/progression tests;
5. remote-phase tests;
6. the exact repository-grounded broad group used by the V4 audit:
   - `tests/test_c2b*.py`
   - `tests/test_rw0_c1_*.py`
   - `tests/test_sqlite_b1_migrations.py`
   - `tests/test_sqlite_c2b1_migration_framework.py`
   - `tests/test_sqlite_c2b2_migration_0002.py`
   - `tests/test_sqlite_section41_migration_0003.py`
   - `tests/test_sqlite_rw0_c1_migration_0004.py`
   - `tests/test_runtime_non_authority.py`
   - `tests/test_c2a_nonimplementation.py`
   - `tests/test_sqlite_b1_runtime_boundary.py`;
7. complete repository suite;
8. `git diff --check`;
9. both untracked-file whitespace checks;
10. CR, trailing-whitespace, and final-newline checks;
11. source, migration, existing-test, semantic-owner, and other-document
    preservation;
12. live-cache opening/closing byte equality;
13. external-clone artifact scan.

V4 audit reference results:

- contract module: `1,266 passed`;
- architecture/operating/progression: `85 passed`;
- exact remote phase: `969 passed`;
- repository-grounded broad group: `1,682 passed`;
- complete repository: `7,450 passed, 3 warnings`.

Final counts may increase. Report observed commands and results only.

The only expected warnings are the existing Python 3.13 multi-threaded `fork()`
deprecations from unchanged B2C writer-session tests.

## 10. Closeout provenance

Report inline:

- opening and closing Git coordinates;
- exact seven-path candidate;
- proof that only the one test file changed from V4;
- status, mode, bytes, and SHA-256 for all seven paths;
- deterministic seven-path binary-patch bytes and SHA-256;
- two independent complete receipt calculations;
- exact semantic-owner preservation receipt;
- exact counts for every selector;
- external-mutant outcomes and intended boundaries;
- full validation commands/results;
- source/migration/existing-test/other-document preservation;
- live-cache and artifact posture;
- unresolved latch and physical-persistence seams;
- all required non-actions.

Do not create an external report or manifest.

## Success token

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_VERIFIER_REPAIRED_V5_VALIDATED_READY_FOR_REAUDIT`

Success authorizes only another fresh independent read-only audit.

## Blocking token

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_VERIFIER_REPAIR_V5_BLOCKED`

## Required non-actions

State:

```text
SEMANTIC_OWNER_DOCUMENT_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TRACKED_TESTS_NOT_MODIFIED
OTHER_SIX_CANDIDATE_PATHS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
