# Governed Execution Coordinator — RW0-C Durable Progression-Decision Semantic Contract Freeze

## Role

Act as the read-only semantic-contract architect for the Governed Execution Coordinator repository.

This is a repository-first, source-grounded contract-freeze engagement. The checked-out merged repository is the sole source of current contract truth. Do not use or request historical JSONL packages, audit reports, chat exports, Downloads artifacts, Project artifacts, snapshots, or sibling repositories.

Return one substantive report inline in the Codex response. Do not create or attach files.

## Repository and exact baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Expected baseline:

- branch: `trunk_dev`
- HEAD: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- tree: `9e69d4a517b482704c159958abc2f90ed3cdcfd8`
- sole parent: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- subject: `feat: implement RW0-C post-execution pure owners`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- clean index, worktree, untracked, and unmerged posture
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Verify every coordinate before substantive work. If anything differs, stop with:

`RW0_C_DURABLE_DECISION_SEMANTIC_CONTRACT_BLOCKED`

Do not fetch or contact remotes.

## Current architecture decision to refine, not reopen without source conflict

Treat the following as the selected architecture direction, subject to exact repository verification:

1. The first scope is exactly five non-cancel post-execution branches:
   - `candidate_acceptance`
   - `candidate_repair`
   - `attempt_selecting_replan`
   - `program_terminal_reject`
   - `post_execution_program_block`

2. `redeliver` and `cancel` remain outside this owner.

3. One coherent semantic owner must cover:
   - closed command grammar;
   - Coordinator-derived authoritative branch;
   - durable development decision;
   - exact result;
   - mutation receipt;
   - exact replay;
   - recovery selector;
   - `committed_exact`, `definitely_not_committed`, and `unresolved`.

4. Receipt and committed recovery are part of the decision owner’s semantics, not a later independent interpretation of committed truth.

5. Existing migration-0002 decision, version, head, and mutation-receipt facts remain canonical. A later physical persistence freeze is expected to evaluate a bounded hybrid additive migration `0005` for missing immutable safe-basis, currentness, graph-preimage, result-closure, and recovery relations. This engagement does not freeze SQL or physical rows.

6. The acceptance latch is a separate owner. For `accept`, it must be consumed atomically in the same guarded decision transaction. Non-accept branches must not mutate it. The latch identity, state grammar, row, receipt, and recovery representation remain a separate future freeze.

7. Terminal outcome is a later separate immutable fact. It is not a development decision, receipt, latch mutation, process result, or runtime fact.

8. Model output is proposal evidence only. It never authors the authoritative branch.

If current repository evidence contradicts any point materially, state the contradiction and stop rather than silently preserving this direction.

## Why another semantic freeze is required

The prior architecture reconnaissance established the broad owner and migration direction but deliberately left unresolved:

- deterministic authoritative-branch derivation;
- the distinction between command rejection/no-write and a committed `block` decision;
- exact caller expectation versus Coordinator derivation;
- acceptance-latch co-commit interface;
- exact semantic command/result/receipt/recovery value inventory;
- branch-specific output and postimage obligations.

This engagement must resolve those semantic questions. It must not design physical SQL.

## Read-only posture

Permitted:

- `git status`, `git diff --check`, `git rev-parse`, `git show`, `git ls-tree`;
- `rg`, `grep`, `find`, `sed`, `awk`, `nl`, `cat`;
- read-only Python/AST parsing with `PYTHONDONTWRITEBYTECODE=1`;
- static inspection of docs, source, migrations, schemas, and tests;
- at most three bounded read-only explorer subagents with self-contained prompts.

Prohibited:

- repository edits;
- tests;
- importing repository modules;
- migration execution;
- database creation/open/mutation;
- dependency installation;
- service or runtime execution;
- remote or sibling-repository access;
- staging, commit, push, PR operations;
- artifact or manifest generation;
- implementation prompts;
- SQL design;
- assigning final migration table names, checksums, or bytes.

Verify final repository cleanliness.

## Source-of-truth and evidence rules

1. Owning repository docs, source, migrations, and tests define current contracts in their scope.
2. Later current-status/supersession sections govern older forecasts in append-only documents.
3. Tests are contract evidence and drift guards; they do not silently override owning docs/source.
4. Git owns commit/tree/ref truth.
5. Reports and historical packages are not current contract sources.
6. Label every material statement as:
   - `CURRENT IMPLEMENTED CONTRACT`
   - `CURRENT COMPATIBILITY EDGE`
   - `ACCEPTED STRATEGIC TARGET`
   - `HISTORICAL OR SUPERSEDED FORECAST`
   - `IMPLEMENTATION DETAIL`
   - `INFERENCE`
   - `UNRESOLVED`
7. Cite every substantive claim with exact repo-relative `path:line-line` evidence.
8. Preserve contradictions explicitly.

## Required inspection

Read complete relevant portions, not search snippets only.

### Guidance and governing docs

- `AGENTS.md`
- `README.md`
- `.docs/architecture.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/authority-boundaries.md`
- `.docs/software-development-progression-boundary.md`
- `.docs/durable-state-model.md`
- `.docs/sqlite-operations-and-recovery.md`
- `.docs/sqlite-threat-model.md`
- `.docs/c2b-durable-development-state.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`

### Current pure semantic owners

- `src/ge_nwp_coordinator/_post_execution_evidence_values.py`
- `src/ge_nwp_coordinator/_post_execution_policy_values.py`
- `src/ge_nwp_coordinator/_finite_backlog_risk_source_adapter.py`
- `src/ge_nwp_coordinator/_section41_post_execution_proposal_family_projection.py`
- `src/ge_nwp_coordinator/_section41_post_execution_role_resolution.py`
- `src/ge_nwp_coordinator/_rw0_c_decision_input_values.py`

Inspect validation and review dispositions, recommendation mapping, all five branch matrices, proposal currentness, and recommendation consistency.

### Current decision, row, receipt, transaction, and recovery patterns

- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_development_effect_row_values.py`
- `src/ge_nwp_coordinator/_development_row_value_support.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql`
- `src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_development_readers.py`
- `src/ge_nwp_coordinator/sqlite_mutation_transaction_contracts.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
- `src/ge_nwp_coordinator/sqlite_writer_session.py`
- current program-genesis, author-effect, Section 41, and RW0-C1 mutation/recovery families.

### Tests

Inspect at minimum:

- all four `tests/test_post_execution_pure_owner_*.py`
- `tests/test_c2a_nonimplementation.py`
- `tests/test_runtime_non_authority.py`
- `tests/test_software_development_progression_boundary.py`
- `tests/test_architecture_contracts.py`
- `tests/test_autonomous_software_development_operating_model.py`
- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- decision-row, reader, migration-0002, transaction-controller, writer-session, exact-replay, commit-uncertainty, Section 41, and RW0-C1 recovery tests.

Do not run tests.

## Central semantic distinction

Freeze three different outcomes and never collapse them:

1. **Command rejection / no write**
   - malformed command;
   - identity/provenance conflict;
   - missing required immutable input;
   - inability to establish one complete current decision basis;
   - stale caller expectation;
   - mutation-ref reuse with another command digest;
   - unresolved current-source or transaction precondition.
   - This produces no development decision, version, receipt, latch mutation, or terminal fact.

2. **Committed `post_execution_program_block`**
   - a complete and current decision basis exists;
   - Coordinator can truthfully derive a program-level halt-only block branch from that basis;
   - the block is not a fallback for malformed or insufficient evidence.

3. **Recovery `unresolved`**
   - used only after commit uncertainty when durable state cannot prove either exact commitment or exhaustive non-commitment;
   - it is not a decision branch and creates no new decision.

The report must freeze exact boundaries among these three.

## Required decisions

### A. Normative branch derivation

Derive and freeze one deterministic branch-selection algebra from current repository values and target contracts.

At minimum adjudicate this candidate ordering:

1. Establish a complete, internally coherent, current decision basis. If this cannot be established, reject the command with no write.
2. Determine whether a current, complete program-block condition exists independently of malformed/missing basis.
3. From current validation and review dispositions, use severity precedence:
   - explicit terminal rejection;
   - replan required;
   - repair required;
   - acceptance eligible.
4. Apply standing policy, risk, authority, global-stop, and ceiling matrices to the candidate branches.
5. Preserve halt-only semantics under active stop.
6. Model recommendation remains evidence; recommendation inconsistency is retained but does not author the branch.
7. Produce exactly one branch or reject with no write. No arbitrary tuple-order tie break.

Do not accept the candidate ordering merely because it appears here. Compare it to repository sources. Return the exact selected rule, including:

- all preconditions for branch derivation;
- terminal-reject versus block distinction;
- precedence when validation and review disagree;
- precedence when productive branches are denied;
- treatment of stale/unknown/conflicting matrices;
- treatment of model inconsistency;
- whether any complete/current basis can still yield no durable branch;
- exact reason vocabulary or reason classes;
- proof that only one branch can be selected.

If current evidence cannot support one deterministic rule, end with:

`RW0_C_DURABLE_DECISION_BRANCH_PRECEDENCE_BLOCKED`

Do not continue to physical design.

### B. Five-branch mapping

Freeze exact mapping:

- pure branch;
- development decision kind;
- decision variant;
- selection/nullability posture;
- version advancement;
- successor refs;
- required program/work/attempt postimages;
- latch effect;
- later terminal-outcome relation.

Do not add `cancel` or `redeliver`.

### C. Closed command responsibilities

Freeze semantic field responsibilities, without final Python names:

- schema/profile identity;
- `mutation_ref`;
- `decision_ref`;
- expected current program head/version/revision/digest;
- accepted-intent and work-head expectations;
- selected attempt/candidate/fence coordinates where applicable;
- current effect/delivery/selection coordinates where applicable;
- exact immutable Section 41, C1 closure, snapshot/currentness, policy/risk/stop/ceiling inputs or locators;
- branch-dependent preassigned output refs;
- optional caller expected-branch assertion as conflict detection only;
- controller-owned semantic time;
- command digest;
- privacy exclusions.

Explicitly state fields/results the caller may not author.

### D. Semantic value inventory

Recommend the minimum closed private semantic value set needed before physical design. At minimum adjudicate whether separate values are needed for:

- command;
- authoritative branch derivation;
- exact result;
- receipt projection;
- recovery selector;
- committed family projection;
- recovery disposition;
- ordered graph entry/preimage;
- acceptance-latch co-commit assertion interface.

Do not revive historical V35–V37 names or identities. Use role descriptions; final symbols remain for the later repository contract-writing tranche.

### E. Exact result and receipt

Freeze:

- decision identity/kind/variant/reason/digest;
- program version ref/number/digest and program-head postimage;
- branch-specific work/attempt/candidate successor coordinates;
- exact safe basis closure/currentness/matrix/branch bindings or locators;
- ordered graph preimage and digest;
- result identity/digest;
- operation semantic time;
- receipt identity/digest;
- latch postimage binding on acceptance only;
- non-accept proof of latch non-mutation;
- exact replay equality.

Preserve existing migration-0002 nullability where it is current truth.

### F. Replay and mutation-ref reuse

Freeze:

- same `mutation_ref` + same closed command digest;
- exact replay result;
- same ref + different digest;
- preassigned identity collisions;
- replay when current heads have advanced;
- no use of current mutable state to change a historical replay result.

### G. Committed recovery

Freeze one recovery selector and exact three-way semantics:

- receipt-first verification;
- `committed_exact`;
- `definitely_not_committed`;
- `unresolved`;
- exhaustive family-local absence;
- duplicate/partial/foreign/contradictory/malformed cases;
- no blind retry after one commit attempt;
- fresh fenced writer for recovery;
- no new clock;
- no current-head reconstruction of historical truth.

### H. Acceptance-latch interface

Do not freeze the latch’s row or migration representation.

Freeze only the progression-decision contract’s dependency on the future latch owner:

- exact precondition needed for acceptance;
- current latch identity/state/version/digest or equivalent semantic coordinates;
- preassigned latch mutation/postimage coordinates, if required for replay/recovery;
- same-transaction atomicity;
- result/receipt binding to committed latch postimage;
- non-accept non-mutation;
- commit-uncertainty behavior;
- prohibition on making the accept writer callable before the latch owner is separately frozen.

Determine whether the latch interface must be included in the decision command digest and recovery selector. Explain why.

If the repository cannot define this interface without first freezing the complete latch owner, use:

`RW0_C_DURABLE_DECISION_LATCH_CONTRACT_REQUIRED_FIRST`

### I. Terminal and RW0-D/E separation

Freeze only the constraints the later terminal owner needs:

- terminal fact binds the committed decision/result/receipt;
- acceptance terminal binds the already-committed latch postimage;
- terminal does not mutate the latch;
- terminal is not a development decision or effect basis;
- no process, transport, cancellation, Git, ES, or publication truth appears in the decision result.

Do not design terminal storage or RW0-D/E mechanics.

### J. Physical-persistence handoff

Do not design SQL. Produce the exact semantic requirements that the later physical freeze must satisfy:

- canonical migration-0002 facts that remain authoritative;
- supplemental immutable facts that must be persisted;
- graph entry/preimage retention;
- closure member retention;
- immutable locators;
- exact result/postimage relations;
- aliases and absence routes for recovery;
- acceptance-latch dependency;
- expected migration and application-generation posture as recommendation only;
- physical stop conditions.

### K. Repository contract-writing plan

Without issuing an implementation prompt, identify the smallest later docs-and-contract-tests tranche that would adopt this semantic contract into the repository.

Recommend:

- one authoritative owning document;
- cross-reference/status docs;
- exact categories of contract tests;
- protected current source/migrations;
- whether any source module should remain unchanged during contract writing;
- stop conditions.

Do not provide patch instructions or code.

## Required report structure

Return one inline report:

1. **Disposition**
2. **Exact baseline**
3. **Inspection scope and limits**
4. **Current versus target truth**
5. **No-write versus block versus recovery-unresolved**
6. **Normative branch derivation**
7. **Five-branch mapping**
8. **Command contract**
9. **Semantic value inventory**
10. **Result and receipt contract**
11. **Replay and mutation-ref reuse**
12. **Committed recovery contract**
13. **Acceptance-latch interface**
14. **Terminal/RW0-D/E separation**
15. **Physical-persistence requirements**
16. **Repository contract-writing plan**
17. **Rejected alternatives**
18. **Unresolved items**
19. **Qualitative evidence strength**
20. **Continuation capsule**
21. **Final token**

## Continuation capsule

Append a self-contained capsule of at most 1,000 words covering:

- exact baseline;
- frozen semantic owner;
- exact branch precedence;
- no-write/block/unresolved distinction;
- command/result/receipt/recovery responsibilities;
- latch interface;
- excluded terminal/runtime seams;
- physical persistence requirements;
- next permitted action;
- non-authorizations.

## Disposition tokens

End with exactly one token.

### Semantic contract ready

Use only if branch derivation, command/result/receipt/replay/recovery semantics, and latch interface are all sufficiently frozen:

`RW0_C_DURABLE_DECISION_SEMANTIC_CONTRACT_READY`

### Latch owner must be frozen first

`RW0_C_DURABLE_DECISION_LATCH_CONTRACT_REQUIRED_FIRST`

### Branch precedence blocked

`RW0_C_DURABLE_DECISION_BRANCH_PRECEDENCE_BLOCKED`

### General block

`RW0_C_DURABLE_DECISION_SEMANTIC_CONTRACT_BLOCKED`

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
DATABASE_NOT_OPENED_OR_MUTATED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
ARTIFACTS_NOT_GENERATED
JSON_MANIFEST_NOT_GENERATED
IMPLEMENTATION_PROMPT_NOT_ISSUED
IMPLEMENTATION_NOT_PERFORMED
MIGRATION_0005_NOT_CREATED
DURABLE_PROGRESSION_DECISION_WRITE_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
```
