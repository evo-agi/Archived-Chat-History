# Disposition

**Proceed to a fresh independent read-only re-audit. Do not stage or commit the V5 candidate.**

The repair has the correct boundary: only the untracked verifier changed, while the semantic owner, the other five candidate documents, all source, migrations, and existing tracked tests reportedly remained byte-identical. That is exactly the successor tranche required by the prior audit, which found no High or Medium semantic, authority, provenance, or documentation defect, but blocked on four verifier-integrity findings—including two required mutants that escaped the complete module. :chatgpt-content-reference{index="0"}

No deterministic pre-audit blocker is apparent in Codex’s closeout. It reports direct closure of all four findings:

- observed production labels now have a shared extraction path, sentinel test, and structural independence guard;
- pointer integrity now covers prefix, inverse, and sibling mismatches;
- six productive-evidence cases now bind every retained field and exact reason;
- ten tests now require complete matrix reason validation before later currentness or V14/V15 faults.

The six required external mutants reportedly fail at the intended boundaries, the contract module passes **1,286 tests**, and the complete repository passes **7,470 tests with the same three expected warnings**.

Those are implementation-conversation claims. A fresh auditor still needs to prove that the new guards are genuinely independent and cannot be satisfied by another test-local self-authorship route.

## Audit target

The exact changed verifier is now:

```text
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py

Bytes:
239,999

SHA-256:
9b0751f55b238c55130b6481bbea34454c5ed8866212f5546baa6e5af1b0fa19
```

The semantic owner must remain exact:

```text
.docs/rw0-c2-durable-progression-decision-semantic-contract.md

Bytes:
68,944

SHA-256:
92f1d2b34f9cf2486102edf31de142acc07db9a116f64d64212ca497d0a554c1
```

Codex reports this seven-path patch coordinate:

```text
Bytes:
327,443

SHA-256:
b76ee8a85bc12250f8d56cd8eb15f48c35b5ee7c18acd7dd1772ed76c6a3890f
```

The audit prompt treats the exact path set, classifications, modes, sizes, and per-file hashes as primary provenance. The aggregate patch coordinate is corroborating evidence, so a stale aggregate alone will not cause another unnecessary provenance stop when the actual endpoint bytes are unambiguous.

# Fresh V5 independent re-audit handoff

Use a **new parent-led, local, read-only Codex conversation**. Send only the prompt text. Attach no reports, manifests, snapshots, packages, or chat exports.

:chatgpt-content-reference{index="2"}[Download the V5 independent re-audit prompt](sandbox:/mnt/data/Coordinator_RW0_C_Durable_Decision_Branch_Contract_V5_Independent_Reaudit_Prompt.txt)

```text
Filename:
Coordinator_RW0_C_Durable_Decision_Branch_Contract_V5_Independent_Reaudit_Prompt.txt

Size:
23,843 bytes

SHA-256:
e1f53e2e99f3a849bdb8981d4d23f1fc7be9e82fe324098e4e691802dd9fb932

Logical lines:
728

Final newline:
present
```

The prompt concentrates on the four repaired findings rather than reopening the already accepted semantic contract. It requires the auditor to prove:

1. **Production-label provenance**
   - labels are read from returned production entries;
   - the extraction path cannot consult fixed expectations or parsed contract pairs;
   - sentinel values flow through the real extraction helper;
   - the self-authorship mutant fails at the exact provenance boundary.

2. **Pointer-checker integrity**
   - pointer equality is exact;
   - prefix, inverse-prefix, and sibling cases reject;
   - weakening equality to `startswith` fails the dedicated integrity test.

3. **Retained productive evidence**
   - all five entries retain exact owner, branch, applicability, effect class, result, and reason;
   - all six required scenarios are checked;
   - replacing reasons with one fabricated constant fails at the precise owner/index boundary.

4. **Complete matrix-stage validation**
   - all selected and unselected matrix entries are grammar-validated before currentness and V14/V15 reduction;
   - ten direct owner/profile precedence cases pass;
   - conditioning validation on `evaluate_semantics`, selected branch, or absence of an earlier block is caught.

It also rechecks that the one-file repair did not alter:

- the `44 accepted / 24 excluded` partition;
- pipeline order;
- duplicate-key rejection;
- earlier-block evidence retention;
- all halt-only routes;
- model-after-latch ordering;
- the five durable branches;
- latch, terminal, persistence, migration, public, and runtime nonimplementation boundaries.

## Fixed validation claims

The auditor must independently reproduce:

```text
Contract module:
1,286 passed

Architecture / operating model / progression:
85 passed

Exact remote-phase tests:
969 passed

Repository-grounded broad group:
1,682 passed

Complete repository:
7,470 passed, 3 warnings
```

It must collect and run the exact module-scoped selectors, including:

```text
witness_label_provenance          2
pointer_checker_integrity         3
retained_productive_evidence      6
complete_matrix_stage            10
hostile                          571
pipeline_order                     5
production_witness                56
source_reachability               36
duplicate_key                       2
scalar_pointer                    457
halt_only                         368
earlier_block                       4
model_authority                    36
structural_nonimplementation       12
```

## Possible outcomes

Successful independent acceptance:

```text
RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
```

Semantic or verifier-integrity block:

```text
RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_AUDIT_BLOCKED
```

Actual byte or repository-identity mismatch:

```text
AUDIT_PROVENANCE_MISMATCH
```

Even an acceptance authorizes only a separate commit/publication gate for the exact seven audited paths. It does not authorize source implementation, migration `0005`, durable decision writing, acceptance-latch or terminal implementation, public API widening, runtime activation, or physical persistence.

**Sources:** Current Codex V5 implementation closeout; prior resumed V4 independent audit, which isolated the remaining work to four Medium verifier-integrity defects and found no High or Medium defect in the semantic contract or authority model. :chatgpt-content-reference{index="1"}

**Confidence:** High that the V5 candidate is ready for a fresh independent re-audit; no acceptance confidence is assigned until the four repaired verifier properties and six external mutants are independently reproduced.
