# Disposition

**Proceed to a fresh independent audit. Do not stage or commit the seven-path candidate yet.**

Codex’s closeout has the correct shape for this tranche:

- documentation and contract tests only;
- five modified governing/status documents;
- one new authoritative semantic-contract document;
- one new causal contract-test module;
- no `src/`, migration, schema, public API, or runtime changes;
- targeted and full validation passed;
- the committed baseline remained unchanged.

The work directly addresses the earlier repository-grounded blocker: the repository previously had five eligible branches but no total reducer, while the latch remained a second prerequisite. :chatgpt-content-reference{index="0"} It also preserves the previously selected architecture—one coherent semantic owner followed later by a separate physical-persistence freeze. :chatgpt-content-reference{index="1"}

There is no deterministic pre-audit blocker in Codex’s report. The candidate still requires an independent audit because the implementation conversation cannot establish that:

1. the new test module actually enforces repository text rather than merely testing a duplicated test-local reducer;
2. the reducer is total, mutually exclusive, and consistent with the current validation, review, policy, risk, authority, stop, and ceiling vocabularies;
3. untouched governing files—especially `AGENTS.md`, `.docs/authority-boundaries.md`, and `.docs/software-development-progression-boundary.md`—remain consistent with the new owner;
4. the new document is discoverable as the authoritative future contract even though `AGENTS.md` remained byte-exact;
5. append-only updates in the large C2B document properly supersede rather than silently conflict with older forecasts;
6. no wording accidentally reports the future reducer, latch interface, or durable decision owner as implemented current behavior.

The fresh audit should use the live repository as its sole input. No report, manifest, or attachment needs to be transported.

---

# Complete replacement Codex prompt

```text
# Governed Execution Coordinator — RW0-C Durable Decision Branch Contract Independent Audit

## Role

Perform a fresh, parent-led, local, read-only independent audit of the uncommitted
RW0-C durable progression-decision semantic-contract candidate.

The checked-out repository is the sole audit target. Do not request or use
attachments, chat exports, prior audit packages, Downloads artifacts, snapshots,
or sibling repositories.

Do not repair the candidate.

Return one substantive audit report inline. Do not generate or attach files.

## Repository

Physical root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Expected committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- HEAD tree: `9e69d4a517b482704c159958abc2f90ed3cdcfd8`
- sole parent: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- subject: `feat: implement RW0-C post-execution pure owners`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- no staged or unmerged path
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

## Exact candidate identity

The live worktree must contain exactly these seven candidate paths and no other
tracked or untracked difference from HEAD.

| Path | Expected status | Bytes | SHA-256 |
|---|---|---:|---|
| `.docs/architecture.md` | tracked modified | 42,104 | `d10da9d372c9920ed567f2f705d798cd52f8fb37a9bb94a414f9f4ce193d5494` |
| `.docs/autonomous-software-development-operating-model.md` | tracked modified | 37,198 | `971c3986011f6fb6473bb6018822c2e6c3abc037ec952fa54c8b322e5c70f1bf` |
| `.docs/c2b-durable-development-state.md` | tracked modified | 1,887,232 | `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5` |
| `.docs/rw0-c1-durable-evidence.md` | tracked modified | 14,275 | `398911e2631ed1ad928febcd957034d534c860e8fc915a54371c577f7a7e98bf` |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | tracked modified | 55,814 | `4b5d9a53e2de8d8b0186a4b93818d1e91df322a2d2de19defa51059f28aa5383` |
| `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | untracked regular file | 25,225 | `93854cc7ac0eee8296edbb06546af2bcc46015f8507d794529dc2c1ac0ff3539` |
| `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | untracked regular file | 28,880 | `450c1d559cdcbda3d67a14ade51dc2cc0473a6f2cb8b70680081383c6ab29837` |

Required file mode for all seven paths: `0644`.

Opening status must be exactly:

- five tracked modifications;
- two untracked files;
- zero staged files;
- zero unmerged files;
- zero other changed, deleted, renamed, type-changed, or untracked paths.

The following current repository surfaces must remain byte-identical to HEAD:

- all `src/`;
- all migration resources;
- `src/ge_nwp_coordinator/sqlite_migration.py`;
- all transaction, reader, writer, StateStore, and package-export source;
- migrations 0001–0004;
- all existing test modules except no existing test module is expected to have
  changed in this candidate;
- `AGENTS.md`;
- `.docs/authority-boundaries.md`;
- `.docs/software-development-progression-boundary.md`.

Codex reported the retained `AGENTS.md` identity as:

- bytes: `60,530`
- SHA-256:
  `c12a3449e761728f2093c19bb30134c54994b045843313471a6d715b648355a6`

Verify it independently.

Any baseline, path-set, classification, type, mode, size, or SHA mismatch must
stop before semantic inspection with:

`AUDIT_PROVENANCE_MISMATCH`

## Audit posture

This is an independent audit, not implementation validation.

Permitted:

- read-only Git inspection;
- static source, documentation, migration, and test inspection;
- read-only Python/AST parsing with `PYTHONDONTWRITEBYTECODE=1`;
- test execution in a private external local clone;
- at most three bounded read-only explorer subagents with self-contained prompts.

Prohibited:

- editing, formatting, cleanup, or repairing repository files;
- staging, committing, pushing, or modifying a PR;
- fetching or contacting remotes;
- modifying ignored cache;
- importing repository modules in the live repository;
- opening or mutating a product-state database;
- running migrations;
- installing dependencies;
- creating a new report or manifest file;
- inspecting sibling repositories.

Audit-created temporary material must remain outside the repository and be
removed recoverably at closeout.

## Source-of-truth posture

The repository owns current contract semantics.

Classify material as:

- current implemented contract;
- compatibility edge;
- accepted future semantic contract;
- historical or superseded forecast;
- implementation detail;
- inference;
- unresolved.

The candidate is intended to adopt a future contract. It must not claim that a
durable post-execution decision writer, branch reducer, latch owner, terminal
owner, migration 0005, production caller, public export, or runtime behavior
currently exists.

Tests are contract evidence. They do not become the semantic authority and must
not silently override the owning document.

## Explorer structure

At most three read-only explorers may be used.

Suggested perspectives:

1. **Contract and authority auditor**
   - owning-document authority;
   - current-versus-future classifications;
   - reducer semantics;
   - latch, terminal, model, external-authority, and public/runtime boundaries.

2. **Test-adequacy auditor**
   - causal relationship between tests and the owning document;
   - complete finite coverage;
   - self-referential or duplicated test-local models;
   - negative and hostile controls;
   - mutation of one premise at a time.

3. **Documentation and composition auditor**
   - discoverability from `AGENTS.md` and the operating model;
   - consistency with untouched authority/progression docs;
   - append-only C2B supersession;
   - stale forecasts and overclaims.

The parent must inspect the core evidence itself and reconcile the reports.

## Required inspection

Read in full or through all relevant current/superseding sections:

- `AGENTS.md`
- `README.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/architecture.md`
- `.docs/authority-boundaries.md`
- `.docs/software-development-progression-boundary.md`
- `.docs/c2b-durable-development-state.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/durable-state-model.md`
- `.docs/sqlite-operations-and-recovery.md`
- `.docs/sqlite-threat-model.md`

Inspect current semantic/source owners as evidence, without modifying them:

- `src/ge_nwp_coordinator/_post_execution_evidence_values.py`
- `src/ge_nwp_coordinator/_post_execution_policy_values.py`
- `src/ge_nwp_coordinator/_rw0_c_decision_input_values.py`
- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_development_effect_row_values.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- current RW0-C1 replay/recovery owners;
- current transition-controller and writer-session contracts.

Inspect:

- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- all post-execution pure-owner tests;
- existing architecture, operating-model, progression, C2B, RW0-C1,
  remote-phase-entry, runtime-nonauthority, migration, and nonimplementation
  tests relevant to the candidate.

## Audit question 1 — authoritative owner and discoverability

Determine whether:

1. `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` is
   unambiguously the single owner of the future reducer contract;
2. the operating model and architecture route future readers to that document;
3. leaving `AGENTS.md` byte-exact does not make the owner undiscoverable or
   contradict the repository’s composition rules;
4. untouched `.docs/authority-boundaries.md` and
   `.docs/software-development-progression-boundary.md` remain consistent;
5. `.docs/c2b-durable-development-state.md` follows its append-only and
   supersession conventions rather than rewriting history or creating two
   current owners.

A broken authority route or multiple current owners is blocking.

## Audit question 2 — current versus future truth

Require the candidate to state clearly that:

- the reducer is a frozen future semantic contract;
- current source still contains only private pure input/evaluator owners;
- no durable decision command, writer, receipt family, recovery selector,
  latch owner, terminal owner, migration 0005, or production caller exists;
- migrations 0001–0004 and application generation 2 remain current;
- the contract does not claim implementation merely because tests encode it.

Search every changed document for contradictory current-tense or
implementation-complete language.

Any material overclaim is blocking.

## Audit question 3 — three-outcome separation

Verify exact, non-overlapping treatment of:

1. command rejection / no durable write;
2. durable `post_execution_program_block`;
3. committed-recovery `unresolved`.

Require:

- malformed, conflicting, partial, stale caller expectation, ref reuse, and
  identity collision to create no decision;
- `program_block` to require a complete nonconflicting basis;
- recovery `unresolved` to exist only after commit uncertainty and never be a
  branch;
- no fallback that silently turns malformed or missing evidence into block.

The contract and tests must prove the distinction causally.

## Audit question 4 — currentness reduction

Verify the exact adopted rule:

- `conflict` → no write;
- `stale` → block;
- `unknown` → block;
- `current` → continue.

Audit the distinction between:

- a stale caller expectation, which is no-write;
- a complete current observation proving that the supplied decision basis is
  stale or unknown, which is block.

Require the durable reason:

`decision_basis_not_current`

Audit that this meaning is consistent with current source vocabularies and
currentness ownership.

## Audit question 5 — validation/review total reducer

Independently derive all declared validation and review dispositions from the
current source.

Verify normalization into:

- accept;
- repair;
- replan;
- terminal;
- nonconclusive;
- conflict.

Require:

1. any conflict → no write;
2. any nonconclusive → block;
3. otherwise:
   `terminal > replan > repair > accept`.

Audit every declared validation × review combination.

Required examples include:

- pass + pass → acceptance;
- repair + pass → repair;
- repair + replan → replan;
- terminal + pass → terminal reject;
- terminal + replan → terminal reject;
- any unknown, inconclusive, or not-run input → block;
- any conflict input → no write.

Verify the closed durable reason classes:

- `candidate_evidence_conclusively_accepted`
- `candidate_evidence_requires_repair`
- `candidate_evidence_requires_replan`
- `candidate_evidence_terminally_rejected`
- `candidate_evidence_nonconclusive`

A missing source disposition, ambiguous mapping, or untested combination is
blocking.

## Audit question 6 — matrix eligibility and active stop

For the selected candidate branch, verify treatment of all five matrices:

- standing policy;
- risk lane;
- decision-time authority;
- global stop;
- source-effect ceiling.

Productive branches:

- any conflict → no write;
- all permit → retain productive branch;
- any deny or unknown → block.

Required block reason:

`productive_branch_not_permitted`

Halt-only branches:

- every matrix must produce its profile-owned halt-only permit;
- any non-permit halt-only result is evaluator-contract conflict and no-write.

Verify active-stop behavior:

- conclusive terminal evidence under active stop → terminal reject;
- otherwise a productive candidate denied by active stop → block;
- tuple order is never used as semantic tie-breaking.

Require causal hostile tests for deny, unknown, conflict, and malformed
halt-only results.

## Audit question 7 — model non-authority

Verify that recommendation consistency is evaluated only after branch
derivation and cannot change the branch.

Tests must prove that a changed model recommendation affects only consistency
evidence, not authoritative branch selection.

## Audit question 8 — branch and reason closure

Verify exact branch mapping:

- acceptance → `accept` / `candidate_acceptance`;
- repair → `repair` / `candidate_repair`;
- replan → `replan` / `attempt_selecting_replan`;
- terminal reject → `terminal_reject` / `program_terminal_reject`;
- block → `block` / `program_block`.

Require:

- all five version-advancing;
- existing migration-0002 nullability preserved;
- `cancel` and `redeliver` excluded;
- exactly one branch or typed no-write;
- no arbitrary default branch.

Verify block-reason summary precedence:

1. `decision_basis_not_current`
2. `candidate_evidence_nonconclusive`
3. `productive_branch_not_permitted`

Lower-level evidence must remain retained rather than erased by the summary.

## Audit question 9 — command and caller authority

Verify that an optional expected-branch value is conflict detection only.

The caller and model must be prohibited from authoring:

- authoritative branch;
- currentness conclusions;
- matrix conclusions;
- durable decision/result;
- receipt;
- latch postimage;
- terminal outcome;
- commit or recovery classification.

No document may imply that a caller-requested branch becomes authoritative.

## Audit question 10 — acceptance-latch interface

Verify the candidate freezes only an abstract future-owner dependency:

- exact available preimage;
- preassigned consumed postimage;
- inclusion in command digest and recovery selector;
- same-transaction atomic decision+latch commitment for acceptance;
- no-write on mismatch, missing, duplicate, malformed, ambiguous, or already
  consumed state;
- replay without second mutation;
- decision+latch family recovery;
- nonaccept non-mutation;
- accept writer remains uncallable before separate latch freeze.

The candidate must not select table names, row grammar, migration bytes,
storage identities, or current implementation claims.

## Audit question 11 — terminal and RW0-D/E separation

Verify:

- terminal outcome is a later immutable fact;
- it binds but does not reopen the committed decision;
- acceptance terminal binds the already-consumed latch postimage;
- terminal does not mutate the latch;
- terminal is not a development decision or effect basis;
- process, transport, cancellation, Git, ES, publication, RW0-D, and RW0-E
  facts remain excluded.

## Audit question 12 — physical-persistence non-freeze

Require the candidate to preserve:

- migration-0002 canonical decision/version/head/receipt facts;
- no migration 0005;
- no SQL, table, key, trigger, index, checksum, reader, writer, transaction, or
  application-generation change;
- bounded-hybrid persistence only as a later question.

Any physical schema presented as already decided beyond these constraints is
blocking.

## Audit question 13 — test causality and repository binding

This is a critical gate.

Determine whether the new 688-line test module genuinely enforces the owning
repository contract, rather than merely testing a duplicated test-local reducer.

Require evidence that tests:

- read or parse the authoritative owner document or stable machine-readable
  contract markers owned by that document;
- verify changed cross-reference documents against the owner;
- derive source vocabularies from current source where appropriate;
- fail if the owner document’s reducer, reasons, precedence, mapping, or
  nonclaims are changed;
- do not receive semantic credit from test-local constants that can drift
  independently of repository text;
- mutate one premise at a time;
- prove the expected first semantic outcome;
- cover every declared validation/review pair;
- cover matrix permit/deny/unknown/conflict behavior;
- cover active-stop terminal-versus-block behavior;
- cover no-write/block/unresolved separation;
- cover model non-authority;
- cover latch and terminal nonimplementation;
- guard source/migration/public/runtime absence.

Create temporary hostile copies outside the repository when useful. For
example, alter one owner-document reason, precedence row, or branch mapping and
prove the contract test detects the drift without editing the live repository.

A test suite that passes while its authoritative document can materially drift
is a blocking test-adequacy defect.

## Audit question 14 — untouched governing surfaces

Inspect whether the decision not to modify:

- `AGENTS.md`;
- `.docs/authority-boundaries.md`;
- `.docs/software-development-progression-boundary.md`

is truthful.

Do not require edits merely for completeness. Block only if current text now
contradicts the new owner, misroutes authority, or makes the owner
undiscoverable.

## Validation

Construct a private external local clone from committed HEAD without remote
contact.

Overlay exactly the seven live candidate files after independently checking
their sizes and SHA-256 values.

Run serially with:

- `PYTHONDONTWRITEBYTECODE=1`
- pytest cache disabled.

At minimum rerun:

1. `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
2. all existing test modules modified or named by the candidate’s
   cross-reference contract;
3. architecture, operating-model, progression-boundary, C2B, RW0-C1,
   remote-phase-entry, migration, runtime-nonauthority, and nonimplementation
   suites relevant to the tranche;
4. the complete repository test suite;
5. `git diff --check`;
6. artifact and cache scans.

Codex reported these implementation-validation results:

- new contract module: `153 passed`;
- operating-model/architecture/progression group: `85 passed`;
- `tests/test_c2b*.py` plus runtime nonauthority: `1301 passed`;
- complete suite: `6337 passed, 3 warnings`.

Reproduce rather than assume them.

The expected warnings are the pre-existing Python 3.13 multi-threaded `fork()`
deprecation warnings from `tests/test_sqlite_b2c_writer_session.py`. Any other
warning or changed count must be explained and adjudicated.

Do not mutate the live ignored cache.

## Final provenance

After removing audit-created temporary material, reverify:

- exact seven-path status;
- all seven sizes and hashes;
- zero staged and unmerged paths;
- no extra changed/untracked path;
- unchanged source and migration trees;
- clean diff checks;
- unchanged ignored cache posture.

## Severity

Classify findings as:

- authority/contract drift;
- semantic defect;
- test-adequacy defect;
- documentation/supersession defect;
- provenance mismatch;
- validation defect;
- artifact/security concern;
- report-only uncertainty.

Any provenance mismatch, semantic ambiguity, authority conflict, material
overclaim, self-referential test corpus, incomplete finite reducer, or physical
scope widening is blocking.

Do not repair findings.

## Inline report

Return:

1. primary verdict;
2. exact baseline and candidate receipts;
3. audit scope and limits;
4. authority/discoverability audit;
5. current-versus-future truth audit;
6. reducer audit;
7. no-write/block/unresolved audit;
8. branch/reason/matrix audit;
9. model-authority audit;
10. latch/terminal/physical-boundary audit;
11. test-causality audit;
12. documentation and append-only supersession audit;
13. independent validation results;
14. final live provenance;
15. severity-ranked findings;
16. exact next boundary;
17. required non-actions;
18. final token.

## Success token

Use only when there is no unresolved High- or Medium-severity finding:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

Success authorizes only a separate commit/publication gate for the exact seven
audited paths. It does not authorize source implementation, migration 0005,
latch implementation, terminal implementation, runtime activation, or the
later physical persistence freeze.

## Blocking token

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_AUDIT_BLOCKED`

## Provenance mismatch token

`AUDIT_PROVENANCE_MISMATCH`

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
DATABASE_NOT_OPENED_OR_MUTATED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
```

A successful audit should be followed by a bounded commit/publication gate for these seven exact files. After that merge, the next architecture engagement is the separate acceptance-latch owner freeze—not migration `0005` implementation.

**Sources:** Codex implementation response in this turn; the preceding repository-first audit, which established the branch-precedence and latch prerequisites; and the architecture reconnaissance selecting a semantic-owner/physical-owner split. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

**Confidence:** High that the reported candidate is ready for independent audit; no independent acceptance confidence is assigned until the live seven-path bytes, semantic reducer, document authority, and test causality are audited.
