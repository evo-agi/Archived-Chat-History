# Disposition

**Accept the independent re-audit’s `BLOCK` verdict. Do not stage or commit the repaired candidate.**

The result is not a provenance, scope, documentation-authority, V14/V15 projection, migration, or validation failure. The exact seven-path candidate remained stable, and all requested suites—including **6,606 tests**—passed. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The reducer architecture also remains sound. The remaining defects are concentrated in the owning contract’s matrix semantics and the test suite’s ability to prove them:

1. The machine contract does not own the complete per-matrix result/reason grammar. It delegates missing semantics to a test-local convention, allowing impossible cross-owner pairs such as `risk_lane / unknown / policy_currentness_unknown` and `risk_lane / deny / global_stop_active`.
2. Halt-only verification is not causal for direct terminal reject or native block paths.
3. An earlier block reason can suppress later matrix-conflict evaluation.
4. An unrecognized model recommendation can cause no-write, which gives model output decision authority.
5. The structural absence guard misses aliased `ImportFrom`, relative imports, and nested production modules.
6. Productive profile mismatch is misclassified as a halt-only conflict. :chatgpt-content-reference{index="2"}

The audit’s prescribed boundary is correct: another documentation/test repair inside the same seven-path candidate, with no source, migration, writer, latch, terminal, or runtime work. :chatgpt-content-reference{index="3"}

## Engineering decisions for the repair

### Matrix truth must move into the owner

The human contract and embedded machine representation must both encode the complete source-derived grammar for each matrix owner. A global pool of reasons is insufficient.

The exact current-source pairs to bind are:

| Owner | Exact result/reason pairs |
|---|---|
| `standing_policy` | conflicts: `policy_identity_conflict`, `evaluator_profile_mismatch`, `support_conflict`; halt permit: `halt_only_policy_not_applicable`; denies: `policy_revoked`, `policy_not_yet_valid`, `policy_expired`, `branch_not_allowed`, `audience_mismatch`, `repository_mismatch`, `path_scope_mismatch`, `risk_lane_not_allowed`, `effect_class_not_allowed`, `ceilings_exceeded`; unknowns: `policy_status_unknown`, `policy_currentness_unknown`; governed permit: `policy_permits` |
| `risk_lane` | conflicts: `risk_source_conflict`, `policy_identity_conflict`, `evaluator_profile_mismatch`, `support_conflict`; halt permit: `halt_only_risk_not_applicable`; denies: `policy_revoked`, `policy_not_yet_valid`, `policy_expired`, `required_lane_mismatch`, `risk_lane_not_allowed`; unknown: **`policy_status_unknown`**; governed permit: `risk_lane_permits` |
| `decision_time_authority` | conflicts: `snapshot_or_phase_mismatch`, `parent_or_fence_identity_mismatch`, `profile_mismatch`, `support_conflict`; halt permit: `halt_only_authority_not_applicable`; denies: `authority_denied`, `authority_revoked`, `attempt_fence_expired`, `effect_fence_expired`, `authority_grant_expired`, `authority_observation_expired`, `effect_class_not_allowed`; unknowns: `authority_status_unknown`, `family_status_unknown`, `revocation_status_unknown`; governed permit: `authority_verified_current` |
| `global_stop` | conflicts: `snapshot_or_stop_identity_mismatch`, `profile_mismatch`; unknown: `global_stop_unknown`; halt permit: `halt_only_stop_checked`; deny: `global_stop_active`; governed permit: `global_stop_clear` |
| `source_effect_ceiling` | conflicts: `snapshot_lineage_or_fence_mismatch`, `proposal_evidence_conflict`, `profile_mismatch`, `support_conflict`; halt permit: `halt_only_ceiling_not_applicable`; denies: `proposal_evidence_noncompliant`, `attempt_fence_expired`, `effect_fence_expired`, `authority_grant_expired`, `authority_observation_expired`, `effect_class_not_allowed`, `source_effect_exceeds_current_attempt`, `source_effect_exceeds_current_effect`, `source_effect_exceeds_current_authority`; unknowns: `proposal_evidence_unknown`, `current_authority_unknown`; governed permit: `source_effect_within_current_ceilings` |

The test must compare this fixed grammar independently against:

- the current source-owner metadata and evaluator code;
- the human tables;
- the embedded machine contract.

No layer may derive its expected answer from another layer under test.

### No-write must globally outrank block reasons

A stale or unknown currentness result may create a provisional block reason, but it may never suppress later detection of a source, identity, profile, support, or matrix conflict.

The reducer pipeline should be frozen as:

1. Validate the complete basis and every matrix’s owner/profile/result/reason grammar.
2. Any exact owner conflict or invalid/foreign pair → no-write.
3. Compute currentness and validation/review outcomes.
4. When validation/review yields a conclusive productive branch, evaluate its productive entries even when an earlier block reason already exists; retain the evidence.
5. Select the final branch and block-summary reason.
6. Every final terminal-reject or block branch must independently pass all five exact halt-only entries.
7. Evaluate model recommendation only after the authoritative branch/no-write outcome is settled.

The existing block-summary priority remains:

```text
decision_basis_not_current
candidate_evidence_nonconclusive
productive_branch_not_permitted
```

That ordering applies only among valid block reasons. It never outranks no-write.

### All halt-only routes need the same proof

The five exact halt-only permits must be checked for:

- direct terminal reject;
- native block from stale currentness;
- native block from unknown currentness;
- native block from validation nonconclusive;
- native block from review nonconclusive;
- block converted from productive deny;
- block converted from productive unknown.

A valid conflict pair still produces no-write. A halt-only deny, unknown, foreign reason, wrong applicability, or wrong effect class produces `halt_only_matrix_contract_conflict`.

A productive entry with the wrong applicability, effect profile, or foreign owner pair produces `matrix_conflict`, not the halt-only rejection class.

### Model recommendation remains non-authoritative even when unrecognized

Given an otherwise valid proposal family and fixed authoritative inputs:

- the five recognized recommendations may yield `consistent` or `inconsistent`;
- an unrecognized recommendation string yields retained evidence  
  `inconsistent / model_recommendation_unrecognized`;
- it does not create no-write, block, terminal reject, or another branch.

A malformed or absent **proposal family** can still be an invalid basis. The isolated recommendation token cannot decide admission.

---

# Complete replacement Codex prompt

Resume the **same parent-only workspace-write conversation**. No attachments, subagents, or external artifacts are needed.

```text
# Governed Execution Coordinator — RW0-C Durable Decision Branch Contract Repair V2

## Objective

Repair the uncommitted RW0-C durable progression-decision semantic-contract
candidate after its second independent audit BLOCK.

This remains a documentation-and-contract-test repair only.

The repair must close:

1. incomplete owner-specific matrix result/reason grammar;
2. surviving terminal and native-block halt-only bypasses;
3. matrix-conflict suppression after an earlier block reason;
4. model recommendation incorrectly creating no-write;
5. productive-profile mismatch using the halt-only rejection class;
6. incomplete recursive import/source-absence guards.

Do not modify source, migrations, schemas, transaction code, readers, writers,
StateStore, WriterSession, package exports, public APIs, or runtime behavior.

Return one substantive inline closeout report. Do not create or attach reports,
manifests, packages, or other external artifacts.

## Repository and committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- tree: `9e69d4a517b482704c159958abc2f90ed3cdcfd8`
- sole parent: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- subject: `feat: implement RW0-C post-execution pure owners`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged and unmerged paths
- no active Git operation or index lock

Do not fetch or contact remotes.

## Exact opening candidate

Require exactly these seven paths and no other difference from HEAD:

| Status | Path | Mode | Bytes | SHA-256 |
|---|---|---|---:|---|
| `M` | `.docs/architecture.md` | `0644` | 42,104 | `d10da9d372c9920ed567f2f705d798cd52f8fb37a9bb94a414f9f4ce193d5494` |
| `M` | `.docs/autonomous-software-development-operating-model.md` | `0644` | 37,278 | `f78a4e62a2e17e7b2cf511a2eb5638e8fa6b64d291207d5fdc6b9fa08a8183ee` |
| `M` | `.docs/c2b-durable-development-state.md` | `0644` | 1,887,232 | `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5` |
| `M` | `.docs/rw0-c1-durable-evidence.md` | `0644` | 14,370 | `3507dca630a103a8ba54f643b662183371ae8d76333d721a91ba6e716eb9f93b` |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | `0644` | 55,944 | `d3fdc11e379cf7bad3bd547c6cc848abdaaa145e0e11ef6058cb7cec9bb29b54` |
| `??` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | `0644` | 43,962 | `29b6b13bdd6cd363bf42e82bac944766b60fc17c74f76f7faeb02630ca74457e` |
| `??` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | `0644` | 75,415 | `aaf7952c2fbae387ff383f7ec1dfbc99c8aa20f916f44bb1d3ef44fd806f01d0` |

All seven must be regular non-symlink files.

Require the opening deterministic binary patch to be:

- bytes: `132,899`
- SHA-256:
  `c879635950fcf2330c28ab0a79fb4ca7d00dbf3827203cd4a9d762b0c4e520e6`

Require `AGENTS.md`:

- bytes: `60,530`
- SHA-256:
  `c12a3449e761728f2093c19bb30134c54994b045843313471a6d715b648355a6`

Stop before editing on any mismatch:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIR_V2_BLOCKED`

## Mutation ceiling

Only these two candidate files may change from their opening bytes:

1. `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
2. `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`

The other five candidate documents must remain byte-identical to the opening
receipts above.

The final candidate path set remains exactly seven paths relative to HEAD.

## Preserved accepted semantics

Do not reopen:

- currentness:
  - conflict → no-write;
  - stale → block;
  - unknown → block;
  - current → continue;
- V14/V15 projection tables;
- validation/review reducer:
  - conflict before all branches;
  - nonconclusive → block;
  - otherwise terminal > replan > repair > accept;
- exact five branches and migration-0002 mappings;
- cancel/redeliver exclusion;
- block-summary precedence;
- no-write versus durable block versus recovery-unresolved;
- model non-authority;
- abstract acceptance-latch dependency;
- terminal and RW0-D/E separation;
- physical persistence as a later freeze.

## Complete owner-specific matrix grammar

The owning document’s human tables and machine-readable block must encode the
following complete exact grammars.

No global nonpermit-reason pool may substitute for these per-owner grammars.

### `standing_policy`

Exact result/reason pairs:

```text
conflict / policy_identity_conflict
conflict / evaluator_profile_mismatch
conflict / support_conflict

permit / halt_only_policy_not_applicable

deny / policy_revoked
deny / policy_not_yet_valid
deny / policy_expired
deny / branch_not_allowed
deny / audience_mismatch
deny / repository_mismatch
deny / path_scope_mismatch
deny / risk_lane_not_allowed
deny / effect_class_not_allowed
deny / ceilings_exceeded

unknown / policy_status_unknown
unknown / policy_currentness_unknown

permit / policy_permits
```

### `risk_lane`

```text
conflict / risk_source_conflict
conflict / policy_identity_conflict
conflict / evaluator_profile_mismatch
conflict / support_conflict

permit / halt_only_risk_not_applicable

deny / policy_revoked
deny / policy_not_yet_valid
deny / policy_expired
deny / required_lane_mismatch
deny / risk_lane_not_allowed

unknown / policy_status_unknown

permit / risk_lane_permits
```

`risk_lane / unknown / policy_currentness_unknown` is forbidden.

### `decision_time_authority`

```text
conflict / snapshot_or_phase_mismatch
conflict / parent_or_fence_identity_mismatch
conflict / profile_mismatch
conflict / support_conflict

permit / halt_only_authority_not_applicable

deny / authority_denied
deny / authority_revoked
deny / attempt_fence_expired
deny / effect_fence_expired
deny / authority_grant_expired
deny / authority_observation_expired
deny / effect_class_not_allowed

unknown / authority_status_unknown
unknown / family_status_unknown
unknown / revocation_status_unknown

permit / authority_verified_current
```

### `global_stop`

```text
conflict / snapshot_or_stop_identity_mismatch
conflict / profile_mismatch

unknown / global_stop_unknown

permit / halt_only_stop_checked

deny / global_stop_active

permit / global_stop_clear
```

### `source_effect_ceiling`

```text
conflict / snapshot_lineage_or_fence_mismatch
conflict / proposal_evidence_conflict
conflict / profile_mismatch
conflict / support_conflict

permit / halt_only_ceiling_not_applicable

deny / proposal_evidence_noncompliant
deny / attempt_fence_expired
deny / effect_fence_expired
deny / authority_grant_expired
deny / authority_observation_expired
deny / effect_class_not_allowed
deny / source_effect_exceeds_current_attempt
deny / source_effect_exceeds_current_effect
deny / source_effect_exceeds_current_authority

unknown / proposal_evidence_unknown
unknown / current_authority_unknown

permit / source_effect_within_current_ceilings
```

## Matrix profile contract

Canonical productive profile:

```text
applicability = governed
governed_effect_class = author_candidate
```

Canonical halt-only profile:

```text
applicability = halt_only
governed_effect_class = null
```

Freeze these rejection classes:

- productive wrong applicability, effect class, owner, profile binding, or
  foreign result/reason pair:
  `matrix_conflict`
- exact owner conflict pair, whether encountered on a productive or halt-only
  entry:
  `matrix_conflict`
- final halt-only entry that is deny, unknown, foreign, malformed, wrong
  applicability, wrong effect class, or wrong non-conflict pair:
  `halt_only_matrix_contract_conflict`

Do not classify a productive profile mismatch as
`halt_only_matrix_contract_conflict`.

## Reducer evaluation order and precedence

The contract must state and the generic interpreter must enforce:

1. Validate complete basis grammar and identities.
2. Validate all five matrix owners, inventory, profiles, and exact
   result/reason provenance.
3. Any basis conflict, exact matrix conflict pair, profile conflict, foreign
   pair, or owner mismatch yields no-write.
4. Compute currentness and V14/V15 reduction.
5. When V14/V15 produces a conclusive productive candidate, evaluate all five
   productive entries even if an earlier currentness block reason already
   exists.
6. Retain every productive matrix result in the immutable basis.
7. Productive deny/unknown adds
   `productive_branch_not_permitted`.
8. Select the final branch using existing block-summary precedence.
9. Every final terminal-reject or block branch must evaluate all five
   halt-only entries.
10. A durable halt-only branch requires all five exact owner-specific
    halt-only permits.
11. Evaluate model recommendation only after authoritative no-write/branch
    selection.

No-write conditions globally outrank every block reason.

Block-summary precedence applies only after the candidate has passed all
no-write gates:

```text
decision_basis_not_current
candidate_evidence_nonconclusive
productive_branch_not_permitted
```

## Mandatory halt-only paths

Causally prove all five exact halt-only permits for:

1. direct `program_terminal_reject`;
2. native block from stale currentness;
3. native block from unknown currentness;
4. native block from validation nonconclusive;
5. native block from review nonconclusive;
6. converted block from productive deny;
7. converted block from productive unknown.

For every path, parameterize across all five matrix owners.

For each applicable path/owner, hostiles must include as semantically relevant:

- exact conflict pair;
- deny;
- unknown;
- foreign owner reason;
- wrong reason for the result;
- wrong applicability;
- wrong governed effect class.

The expected outcome must be the exact no-write classification, not merely
“some test failed.”

Add permanent mutation controls proving failure when terminal or native-block
halt-only verification is bypassed.

## Earlier block reason must not suppress conflicts

Add permanent cases including:

- stale currentness + each owner’s exact conflict pair → no-write;
- unknown currentness + each owner’s exact conflict pair → no-write;
- validation nonconclusive + matrix conflict → no-write;
- review nonconclusive + matrix conflict → no-write.

Also prove:

- stale/unknown currentness + productive deny/unknown retains the
  `decision_basis_not_current` summary reason;
- lower-level matrix evidence remains present;
- final block still requires all five halt-only permits.

A condition such as `and not block_reasons` must never suppress matrix
validation or productive evidence evaluation.

## Model recommendation non-authority

The current recognized post-execution recommendation map is:

```text
accept_candidate → candidate_acceptance
repair_candidate → candidate_repair
replan → attempt_selecting_replan
terminal_reject → program_terminal_reject
block → post_execution_program_block
```

Given an otherwise valid proposal family and fixed authoritative inputs:

- recognized equal mapping:
  `consistent / mapped_branch_equals_authoritative_branch`
- recognized unequal mapping:
  `inconsistent / mapped_branch_differs_from_authoritative_branch`
- unrecognized recommendation string:
  `inconsistent / model_recommendation_unrecognized`

An unrecognized recommendation must not create:

- no-write;
- block;
- terminal reject;
- another durable branch;
- matrix conflict;
- currentness conflict.

A missing or malformed complete proposal family may remain an invalid basis.
The isolated recommendation token is non-authoritative evidence.

Add a hostile test using an out-of-vocabulary recommendation while all
authoritative inputs remain fixed.

## Human/machine/source three-way binding

The test architecture must independently compare:

1. fixed source-derived expectations;
2. current source AST-derived matrix owner metadata/evaluator vocabularies;
3. human-readable contract tables;
4. embedded machine-readable contract;
5. fixed finite reducer outcomes.

No layer may use the layer under test as its expected answer.

Require:

- every source pair appears once in human and machine representations;
- no extra pair exists;
- each pair belongs only to its exact owner;
- every normative machine leaf is consumed by at least one direct assertion;
- every leaf has an appropriate one-premise hostile;
- changing one representation alone fails;
- removing one pair fails rather than reducing parameter count;
- swapping a reason between owners fails;
- changing `risk_lane` unknown to `policy_currentness_unknown` fails;
- changing it to `global_stop_unknown` fails.

Remove the test-local `NONPERMIT_REASONS` convention or replace it with direct
interpretation of the owner-specific machine grammar.

## Structural guards

Recursively inspect every production Python file under:

`src/ge_nwp_coordinator/**/*.py`

Exclude only explicitly authorized cache paths and non-source artifacts.

For `ast.Import`, record each full `alias.name`.

For `ast.ImportFrom`:

- record `node.module`;
- resolve `level` against the importing module’s package;
- record each potential imported module as resolved-base plus `alias.name`;
- handle `from package import module as alias`;
- handle `from . import module as alias`;
- handle nested packages;
- do not infer module identity from the local alias alone.

Add external hostile source trees proving detection of:

```python
from ge_nwp_coordinator import _sqlite_rw0_c2_decision as x
from . import _sqlite_rw0_c2_decision as x
```

and a nested production module such as:

```text
src/ge_nwp_coordinator/internal/_sqlite_rw0_c2_decision.py
```

Preserve structural guards for:

- migrations exactly 0001–0004;
- no migration 0005;
- no RW0-C2 source/writer module;
- no package-root export;
- no public StateStore method;
- no public WriterSession method;
- no production caller;
- no service, worker, runtime, Git, ES, Bridge, provider, process, filesystem,
  or network integration.

## Owning-document representation

The owner remains:

`.docs/rw0-c2-durable-progression-decision-semantic-contract.md`

Its human tables and machine block must be complete equivalent representations.

Do not change the other five candidate documents unless an opening-byte
verification shows the candidate differs from the required receipts; that case
must block rather than repair.

## Protected surfaces

Do not modify:

- the other five candidate documents;
- `AGENTS.md`;
- any `src/` path;
- any migration;
- any existing tracked test;
- `.docs/authority-boundaries.md`;
- `.docs/software-development-progression-boundary.md`;
- transaction, reader, writer, StateStore, WriterSession, or package-export
  code;
- schemas, configs, examples, or supporting repositories.

## Validation

Run serially with:

- `PYTHONDONTWRITEBYTECODE=1`
- `PYTHONPATH=.:src`
- pytest cache disabled;
- external `--basetemp`.

At minimum run:

1. repaired contract module;
2. hostile-only selection;
3. explicit matrix-pair grammar tests;
4. terminal halt-only path selection;
5. native-block halt-only path selection;
6. converted-block halt-only path selection;
7. stale/unknown-plus-matrix-conflict selection;
8. model recommendation non-authority selection;
9. structural guard hostile selection;
10. architecture, operating-model, and progression tests;
11. remote-phase tests;
12. relevant C2B/C1/migration/runtime/nonimplementation suites;
13. complete repository suite;
14. `git diff --check`;
15. new-file whitespace checks;
16. source, migration, existing-test, protected-document preservation;
17. artifact/cache scans.

Use a clean local-only external clone for the full suite if required. Do not
contact a remote or alter the live ignored cache.

## Closeout

Report inline:

- opening and closing committed coordinates;
- exact seven-path candidate;
- exact two-file opening-to-closing repair transition;
- status, mode, byte size, and SHA-256 for all seven paths;
- deterministic full binary diff size and SHA-256;
- two independently repeated receipt calculations;
- concise semantic and test changes;
- exact validation commands and results;
- hostile mutant outcomes;
- protected-surface preservation;
- cache/artifact posture;
- unresolved latch and physical-persistence seams;
- required non-actions.

Do not create an external report or manifest.

## Success token

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIRED_V2_VALIDATED_READY_FOR_REAUDIT`

Success authorizes only a fresh independent read-only audit.

## Blocking token

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIR_V2_BLOCKED`

## Required non-actions

State:

```text
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TRACKED_TESTS_NOT_MODIFIED
OTHER_FIVE_CANDIDATE_DOCUMENTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
```

After a successful repair, the same seven-path candidate must receive another fresh independent audit. The acceptance-latch and physical-persistence tranches remain blocked until this semantic contract is accepted.

**Sources:** Current independent re-audit report, which confirms exact provenance and validation while identifying the six remaining semantic and test-adequacy findings. :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

**Confidence:** High that `BLOCK` is correct; high that the reducer architecture remains valid; high that the two-file repair above addresses every reported finding without widening the seven-path candidate or reopening source and migration work.
