# Disposition

**Proceed to a fresh independent re-audit. Do not stage or commit the V4 candidate.**

Codex reports the correct bounded successor shape:

- the candidate remains exactly seven paths;
- only the semantic owner and its verifier changed from V3;
- the other five candidate documents remained byte-identical;
- source, migrations, existing tracked tests, public surfaces, and runtime behavior remained unchanged;
- the matrix partition was re-adjudicated from `45/23` to **44 accepted / 24 excluded** rather than preserved by inertia;
- the verifier now reports runtime-observed witnesses, actual relation/action guards, control-flow reachability fingerprints, duplicate-key rejection, exact pointer diagnostics, alias/re-export resolution, and sixteen detected mutants;
- the complete suite reportedly passes with **7,450 tests and the same three expected warnings**.

That directly targets the previous audit’s blockers: self-described witnesses, weak reachability proofs, pipeline-order disagreement, duplicate-key acceptance, pointer-check weakening, and semantic-import bypasses. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

This is sufficient for re-audit, not acceptance.

## Two closeout issues to carry into the audit

### Malformed cache digest

The reported closing cache value is:

```text
13d161c803f1242f87d7c8e62b76cf0eb7b7d36a3a8ea87a53849736a94fe
```

That is only **61 hexadecimal characters**, so it cannot be a SHA-256 digest. I classify this provisionally as a **report-only defect**, not a candidate-provenance failure. The auditor must ignore that claimed digest, independently inventory the live ignored cache at opening, and require exact byte equality at closeout without moving or rewriting it.

### Validation-group count is not reproducible from the summary alone

The reported relevant C2B/C1/migration/runtime group fell from `2,655` in V3 to `1,677` in V4, but the V4 response does not include the exact command. The full-suite increase from `7,417` to `7,450` is internally consistent with the contract-module increase from `1,233` to `1,266`, so this is not a pre-audit blocker. The auditor should define the relevant group directly from repository surfaces, report the exact command, and treat only the complete module, selectors, and full suite as fixed reproduction claims.

## Primary audit risk

The verifier is now **225,054 bytes**. Size alone is not a defect, but the auditor must determine whether it remains a contract verifier or has become a second semantic implementation.

The acceptable pattern is:

```text
fixed expectations
+ source inspection
+ real production witness execution
+ parsed owner contract
+ small data-driven interpreter
+ exhaustive finite assertions
```

The blocking pattern is:

```text
test-local recreation of evaluator/relation behavior
+ self-authored expected outputs
+ a parallel reducer whose truth does not come from the owner document
```

That distinction is explicit in the audit prompt.

# Fresh V4 independent re-audit handoff

Use a **new parent-led, local, read-only Codex conversation**. Send only the prompt. Attach no prior reports, manifests, packages, snapshots, or chat exports.

:chatgpt-content-reference{index="3"}[Download the V4 independent re-audit prompt](sandbox:/mnt/data/Coordinator_RW0_C_Durable_Decision_Branch_Contract_V4_Independent_Reaudit_Prompt.txt)

```text
Filename:
Coordinator_RW0_C_Durable_Decision_Branch_Contract_V4_Independent_Reaudit_Prompt.txt

Size:
32,088 bytes

SHA-256:
1395dfa5792a376f5e0ce50cd58533dfee16364620c53c2a9413622976bbe543

Logical lines:
982

Final newline:
present
```

The prompt requires independent verification of:

- the exact seven-path candidate and `311,587`-byte binary patch;
- the `44 accepted / 24 excluded / 68 total` partition;
- every accepted pair through the complete constructor → evaluator → required relation/action path;
- every excluded pair at its real constructor, evaluator-control-flow, or relation boundary;
- the specific removal of `source_effect_exceeds_current_effect` from accepted ceiling outputs;
- independence among fixed expectations, builders, observed outputs, reachability proofs, document data, and interpreter;
- documented versus executable pipeline order under combined faults;
- recursive duplicate-key rejection;
- exact scalar-pointer protection and checker-integrity mutation;
- productive evaluation after an earlier currentness block;
- all 35 same-owner productive-permit substitutions across all halt-only routes;
- model evaluation strictly after acceptance-latch validation;
- whether the 225 KB verifier has become a shadow semantic owner;
- temporary full-source manifest protection and independent semantic alias/re-export guards;
- exact hostile failure boundaries;
- all sixteen external mutants;
- exact selector collection and execution counts;
- the complete `1,266`-test contract module and `7,450`-test repository suite;
- opening/closing cache equality without relying on the malformed reported digest;
- continued absence of migration `0005`, source implementation, a durable writer, latch owner, terminal owner, production caller, public export, and runtime widening.

Success token:

```text
RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
```

Blocking token:

```text
RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_AUDIT_BLOCKED
```

Provenance-mismatch token:

```text
AUDIT_PROVENANCE_MISMATCH
```

Even an `ACCEPT` verdict authorizes only a separate commit/publication gate for the exact seven audited paths. It does not authorize source implementation, migration `0005`, durable decision writing, acceptance-latch implementation, terminal-outcome implementation, public API widening, runtime activation, or the physical-persistence tranche.

**Sources:** Current Codex V4 repair response; prior V3 independent audit, which verified exact provenance and authority posture but required another documentation/test-only repair for the semantic-proof and test-adequacy findings. :chatgpt-content-reference{index="2"}

**Confidence:** High that the V4 candidate is ready for a fresh adversarial audit. No acceptance confidence is assigned until the 44 production witnesses, 24 exclusion proofs, pipeline order, pointer integrity, structural guards, and shadow-implementation risk are independently adjudicated.
