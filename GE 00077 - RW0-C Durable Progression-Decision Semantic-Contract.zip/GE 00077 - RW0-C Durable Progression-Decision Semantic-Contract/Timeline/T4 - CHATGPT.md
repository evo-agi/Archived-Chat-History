# Disposition

**Accept the architecture, but normalize the actionable disposition to:**

```text
RW0_C_DURABLE_DECISION_OWNER_SPLIT_REQUIRED
```

Codex’s substantive recommendation is strong. Its final token is slightly too permissive for the next effect boundary.

The report selects one coherent semantic owner for command, Coordinator-derived decision, result, receipt, replay, recovery selector, and three-way recovery. It then requires a second freeze for the physical schema/reader/writer owner, using a bounded hybrid migration `0005`. :chatgpt-content-reference{index="0"} That is precisely an **ordered contract split required before an implementation contract can be frozen**, even though the overall architecture is now clear.

This is not a rejection of the architecture. It is a sequencing correction.

## Accepted architecture decisions

### One semantic owner

Command, branch derivation, decision, exact result, receipt, exact replay, recovery selector, and committed-recovery classification must share one semantic contract. Receipt and recovery cannot be separated into a weaker interpretation of what the command may have committed. :chatgpt-content-reference{index="1"}

### Exactly five initial branches

The first owner is bounded to:

```text
candidate_acceptance
candidate_repair
attempt_selecting_replan
program_terminal_reject
post_execution_program_block
```

These map to the existing `accept`, `repair`, `replan`, `terminal_reject`, and `block` decision forms. `redeliver` and `cancel` remain separate contracts. :chatgpt-content-reference{index="2"}

### Bounded hybrid persistence

Migration-free reuse is insufficient because current durable state cannot reconstruct the decision-time closure, currentness components, matrices, branch derivation, ordered mutation graph, full result postimages, or exhaustive recovery absence proof.

A standalone replacement schema would be wrong because it would duplicate decision, version, head, and receipt authority.

The selected direction is therefore:

- preserve migration-0002 decision, version, head, and receipt rows as canonical;
- add only the missing immutable basis, closure, currentness, graph-preimage, result-postimage, and recovery relations;
- provisionally use additive migration `0005`;
- provisionally retain application generation 2.

The migration number and generation treatment remain target recommendations until the physical freeze validates the exact catalog contract. :chatgpt-content-reference{index="3"}

### Decision, latch, and terminal outcome remain distinct

The progression decision is one fact. The acceptance latch is another owner, although acceptance must consume it atomically in the same transaction as the decision. Terminal outcome is a later immutable fact that binds the committed decision and—on acceptance—the already-committed latch postimage. It never mutates the latch again. :chatgpt-content-reference{index="4"}

## Why implementation is still blocked

Two semantic decisions remain architecture-critical.

First, the current pure owner verifies a caller-supplied `authoritative_branch`; it does not derive one. The deterministic precedence among terminal reject, replan, repair, acceptance, and program block therefore remains unfrozen. :chatgpt-content-reference{index="5"}

Second, the latch’s identity, state grammar, currentness/CAS posture, receipt, postimage, and recovery selector are not frozen. The `accept` writer cannot become callable until that separate owner is coherent. :chatgpt-content-reference{index="6"}

There is also a distinction the next freeze must make explicit:

```text
invalid, stale, contradictory, or incomplete command
    → reject with no write

complete current basis that truthfully derives a program block
    → durable post_execution_program_block decision

uncertain commit with neither exact commitment nor exhaustive absence
    → recovery unresolved
```

A malformed or incomplete decision basis must not be converted automatically into a durable block decision. `block` is a semantic progression branch, not an error-handling substitute.

## Required sequence

The critical path is now:

1. **Freeze the semantic decision-owner contract.**  
   Resolve deterministic branch derivation, command admission/no-write behavior, exact result/receipt/replay/recovery semantics, and the abstract acceptance-latch co-commit interface.

2. **Freeze the acceptance-latch owner.**  
   Define its identity, state transition, CAS, postimage, receipt, replay, and recovery semantics.

3. **Freeze the physical persistence owner.**  
   Define the exact bounded hybrid migration `0005`, rows, relations, readers, writer family, recovery selectors, transaction integration, catalog treatment, and application generation.

4. **Only then freeze an implementation boundary.**

This preserves one authoritative writer per fact and avoids hardening an incomplete latch or branch-selection model into SQL.

# Next Codex handoff

Use a **new read-only Codex conversation**. Attach nothing. The merged repository is the sole current-contract source.

:chatgpt-content-reference{index="9"}[Download the self-contained semantic-contract-freeze prompt](sandbox:/mnt/data/Coordinator_RW0_C_Durable_Decision_Semantic_Contract_Freeze_Prompt.txt)

```text
Filename:
Coordinator_RW0_C_Durable_Decision_Semantic_Contract_Freeze_Prompt.txt

Size:
18,812 bytes

SHA-256:
7ba429cf8df1889e95e99b9625e505d9de4f2feed12de09702f31215f501dcf0

Logical lines:
504

Final newline:
present
```

The prompt requires one inline report and no generated artifacts. It specifically freezes:

- command rejection/no-write versus durable block versus recovery-unresolved;
- deterministic branch-selection precedence;
- validation/review disagreement handling;
- productive-branch denial and halt-only behavior;
- model-recommendation non-authority;
- exact five-branch decision mapping;
- command responsibilities and caller prohibitions;
- minimum semantic value inventory;
- result, receipt, replay, and recovery contracts;
- the abstract acceptance-latch co-commit interface;
- terminal and RW0-D/E separation;
- semantic requirements handed to the later physical freeze.

Possible outcomes are:

```text
RW0_C_DURABLE_DECISION_SEMANTIC_CONTRACT_READY
RW0_C_DURABLE_DECISION_LATCH_CONTRACT_REQUIRED_FIRST
RW0_C_DURABLE_DECISION_BRANCH_PRECEDENCE_BLOCKED
RW0_C_DURABLE_DECISION_SEMANTIC_CONTRACT_BLOCKED
```

It does not authorize repository mutation, SQL, migration `0005`, tests, database access, an implementation prompt, or any durable decision/latch/terminal behavior.

**Sources:** Repository-first reconnaissance report. The report independently verified the merged baseline, selected the semantic/physical decomposition, rejected migration-free and duplicate-schema alternatives, and identified branch precedence and latch ownership as the remaining blockers. :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"}

**Confidence:** High on the five-branch scope, single semantic owner, and need for supplemental durable relations; high that the next engagement must resolve semantic precedence before physical design; moderate on migration `0005` and generation-2 continuation until the physical persistence freeze validates them.
