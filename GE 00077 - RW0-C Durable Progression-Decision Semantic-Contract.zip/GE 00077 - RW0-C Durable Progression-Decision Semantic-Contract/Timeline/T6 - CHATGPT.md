# Disposition

**Accept Codex’s `RW0_C_DURABLE_DECISION_BRANCH_PRECEDENCE_BLOCKED` verdict.**

Codex did not fail to complete the requested work. It reached the prompt’s required stop condition: the repository has five branch-indexed evaluators, but no total reducer that chooses one authoritative branch. Clear/current inputs permit all five branches, while an active global stop leaves both halt-only branches permitted. Canonical tuple order is encoding order, not semantic precedence. :chatgpt-content-reference{index="0"}

The report also correctly preserved three different outcomes:

```text
invalid, incomplete, contradictory, or stale command expectation
    → no durable write

complete current basis that establishes a halt condition
    → durable post_execution_program_block decision

uncertain commit whose exact outcome cannot be proved
    → recovery unresolved
```

`program_block` is a real version-advancing decision, not malformed-input handling, and recovery `unresolved` creates no decision. :chatgpt-content-reference{index="1"}

The acceptance latch remains a second prerequisite, but it is not the first blocker: branch derivation must be settled before the future decision and latch owners can be made coherent. :chatgpt-content-reference{index="2"}

This is now a strategic architecture decision for us, not another reconnaissance question for Codex.

# Selected branch reducer

The following is the **chat-decided strategic target**. It is not a current repository contract until the owning document and contract tests adopt it.

## 1. Command and basis admission

Before branch selection, the Coordinator must establish one complete, exact decision basis.

Any of these produces a typed **no-write** outcome:

- malformed, missing, duplicate, partial, foreign, or contradictory required facts;
- identity, owner, lineage, profile, or provenance conflict;
- current-head or caller-expectation mismatch;
- `mutation_ref` reuse with a different command digest;
- collision at a preassigned identity or deterministic family route;
- any branch-matrix result of `conflict`;
- mismatch between an optional caller expected-branch assertion and the derived branch;
- any halt-only matrix result other than its contractually required `permit`;
- an acceptance-latch precondition conflict once that owner exists.

No decision, program version, head change, receipt, latch mutation, or terminal fact is created.

This separates malformed or stale commands from a truthful durable `block`.

## 2. Decision-time currentness

Once the basis is structurally complete:

| Proposal/evidence currentness | Treatment |
|---|---|
| `conflict` | No write |
| `stale` | `post_execution_program_block` |
| `unknown` | `post_execution_program_block` |
| `current` | Continue to validation/review reduction |

A stale caller expectation remains no-write. A complete current observation proving that the supplied decision basis is stale or unknown is different: it truthfully establishes that this run cannot progress, so it yields `block`.

Durable reason class:

```text
decision_basis_not_current
```

## 3. Validation and review reduction

Normalize the current validation and review vocabularies into these semantic classes:

| Class | Validation values | Review values |
|---|---|---|
| `accept` | passed | passed |
| `repair` | repairable failure | repair required |
| `replan` | replan required | replan required |
| `terminal` | terminal failure | terminal reject |
| `nonconclusive` | unknown, inconclusive, not run | unknown, inconclusive |
| `conflict` | basis/owner/profile conflict | basis/owner/separation/profile conflict |

The total reducer is:

1. Any `conflict` → no write.
2. Any `nonconclusive` → `post_execution_program_block`.
3. Otherwise choose the highest conclusive severity:

```text
terminal > replan > repair > accept
```

Therefore:

- terminal + pass → terminal reject;
- replan + repair → replan;
- repair + pass → repair;
- pass + pass → acceptance;
- any pair containing unknown, inconclusive, or not-run → block;
- no positive source can waive a more severe conclusive source result.

Durable branch reason classes:

```text
candidate_evidence_conclusively_accepted
candidate_evidence_requires_repair
candidate_evidence_requires_replan
candidate_evidence_terminally_rejected
candidate_evidence_nonconclusive
```

Requiring both evidence sources to be conclusive before a candidate-quality branch prevents an inconclusive review from being silently converted into repair, replan, or terminal-quality truth. The repository already says validation/review/model inconclusive results permit no acceptance and require reconciliation or a nonaccepting decision; `block` is the only branch here that does not invent a more specific candidate-quality conclusion.

## 4. Policy, risk, authority, stop, and ceiling eligibility

Apply the selected branch entry from all five matrices:

```text
standing policy
risk lane
decision-time authority
global stop
source-effect ceiling
```

For a productive branch—acceptance, repair, or replan:

| Selected-entry results | Final branch |
|---|---|
| Any `conflict` | No write |
| All `permit` | Retain the validation/review branch |
| Any `deny` or `unknown` | `post_execution_program_block` |

Durable reason class:

```text
productive_branch_not_permitted
```

All individual matrix results and reasons remain in the immutable decision basis; this reason class is only the durable summary.

For terminal reject or program block, all matrix entries must have the profile-mandated halt-only `permit`. A non-permit halt-only result indicates a broken or mismatched evaluator contract and produces no write.

This resolves the active-stop ambiguity:

- conclusive terminal candidate evidence + active stop → terminal reject;
- otherwise a productive branch denied by active stop → program block;
- there is no tuple-order tie-break between the two halt-only branches.

## 5. Model recommendation

The model recommendation is compared only **after** authoritative branch derivation.

It produces:

```text
consistent
inconsistent
stale_context
basis_conflict
```

as retained evidence, but never changes the branch. Codex correctly observed that the existing V34 evaluator already consumes an authoritative branch rather than deriving one. :chatgpt-content-reference{index="3"}

## 6. Exact branch mapping

| Derived branch | Durable kind / variant |
|---|---|
| `candidate_acceptance` | `accept` / `candidate_acceptance` |
| `candidate_repair` | `repair` / `candidate_repair` |
| `attempt_selecting_replan` | `replan` / `attempt_selecting_replan` |
| `program_terminal_reject` | `terminal_reject` / `program_terminal_reject` |
| `post_execution_program_block` | `block` / `program_block` |

All five advance the program version under exact current-head CAS. Their migration-0002 nullability remains authoritative. The block result must retain the candidate-bearing decision basis through supplemental immutable relations even though the compact decision row intentionally has no selected-candidate fields.

`cancel` and `redeliver` remain outside this owner.

# Acceptance-latch semantic interface

The complete latch owner remains a separate future freeze, but the progression-decision contract can now state its exact dependency:

- The semantic command contains a future-owner-defined acceptance-latch bundle sufficient to identify an exact expected available preimage and a preassigned consumed postimage.
- That bundle is a ceiling on acceptance; it does not request or author acceptance.
- It is covered by the command digest and committed-recovery selector.
- If the reducer selects acceptance, the writer must verify the exact available preimage and atomically commit the decision and consumed postimage in one transaction.
- A mismatch, missing row, duplicate, malformed family, consumed state, or ambiguous preimage produces no write—not a fallback block.
- Exact replay returns the already-committed decision and latch postimage without another mutation.
- Commit recovery verifies the decision and latch as one family.
- Every nonaccept branch performs no latch mutation and contains no committed latch postimage.
- No acceptance writer may become callable until the separate latch owner freezes its identity, state/version/digest grammar, row representation, receipt, CAS, replay, and recovery.

This is enough for the decision semantic contract. It does not prematurely select the latch’s physical scope or schema; earlier exact latch representations were explicitly reopened, while the one-way policy ceiling was retained.

# Required sequence

1. **Write this semantic decision contract into the repository**, with finite contract tests. No source or migration work.
2. **Independently audit that contract tranche.**
3. **Freeze the separate acceptance-latch owner.**
4. **Freeze the bounded-hybrid physical persistence owner**, including migration treatment and the complete decision/latch transaction family.
5. Only then define an implementation boundary.

Codex’s report already recommended a docs-and-contract-tests-only next tranche and explicitly prohibited changing current source, migrations, transaction code, or public surfaces. :chatgpt-content-reference{index="4"}

# Complete replacement Codex prompt

Use a **workspace-write, parent-only Codex conversation**. No attachments and no subagents are required.

```text
# Governed Execution Coordinator — RW0-C Durable Progression-Decision Semantic Contract Writing

## Objective

Adopt one repository-owned semantic contract for the future RW0-C durable
post-execution progression-decision owner.

This is a documentation-and-contract-tests-only tranche. It writes the
architecture decision supplied below into the owning repository documents and
finite contract tests.

It does not implement the decision owner, branch reducer, acceptance latch,
migration 0005, SQLite rows, readers, writer, transaction integration, replay,
recovery, terminal outcome, RW0-D/E, or any runtime/public behavior.

Return one substantive inline report. Do not create or attach external reports,
JSON manifests, freeze packages, or other transport artifacts.

## Repository and baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required opening baseline:

- branch: `trunk_dev`
- HEAD: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- tree: `9e69d4a517b482704c159958abc2f90ed3cdcfd8`
- sole parent: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- subject: `feat: implement RW0-C post-execution pure owners`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- clean tracked, untracked, staged, and unmerged posture
- no active Git operation or lock

Stop without editing if any coordinate differs.

Do not fetch or contact remotes.

## Source-of-truth posture

The repository is the sole source of current implemented truth.

The semantic reducer below is a chat-decided strategic target that this tranche
is authorized to adopt into the repository as a future contract. It is not
current runtime behavior.

Preserve these classifications:

- current merged pure-owner modules remain private, pure, no-I/O inputs and
  evaluators only;
- migration 0002 remains the current generic decision/receipt representation;
- migrations 0001–0004 remain byte- and meaning-exact;
- migration 0005 does not exist;
- no durable post-execution decision writer exists;
- no acceptance-latch owner exists;
- no terminal-outcome owner exists;
- no production caller or public export exists.

Do not import historical package identities or revive V35–V37 names.

## Authorized architecture decision

### 1. Three distinct outcomes

Never collapse:

1. command rejection / no durable write;
2. durable `post_execution_program_block`;
3. committed-recovery `unresolved`.

No-write creates no decision, version, head mutation, receipt, latch mutation,
or terminal fact.

`program_block` is a real version-advancing decision derived from a complete,
nonconflicting current basis.

Recovery `unresolved` exists only after commit uncertainty and creates no
decision.

### 2. Basis-admission no-write gate

The following are no-write conditions:

- malformed, missing, duplicate, partial, foreign, or contradictory required
  facts;
- owner, identity, lineage, profile, or provenance conflict;
- stale caller head or expectation;
- `mutation_ref` reuse with another command digest;
- preassigned identity or family-route collision;
- any matrix `conflict`;
- optional expected-branch mismatch;
- any halt-only matrix result other than its required `permit`;
- acceptance-latch precondition conflict once that owner exists.

These are typed rejection classes, not durable branch reasons.

### 3. Decision-time currentness

- `conflict` → no write
- `stale` → `post_execution_program_block`
- `unknown` → `post_execution_program_block`
- `current` → continue

The block reason class is:

`decision_basis_not_current`

A stale caller expectation remains no-write. A complete current observation
that proves the supplied evidence basis stale or unknown is a durable block.

### 4. Validation/review normalization

Normalize validation:

- passed → `accept`
- repairable failure → `repair`
- replan required → `replan`
- terminal failure → `terminal`
- unknown, inconclusive, not-run → `nonconclusive`
- basis/owner/profile conflict → `conflict`

Normalize review:

- passed → `accept`
- repair required → `repair`
- replan required → `replan`
- terminal reject → `terminal`
- unknown or inconclusive → `nonconclusive`
- basis/owner/separation/profile conflict → `conflict`

Reducer:

1. any conflict → no write;
2. any nonconclusive → `post_execution_program_block`;
3. otherwise choose the maximum conclusive severity:

`terminal > replan > repair > accept`

Examples that contract tests must freeze:

- pass + pass → acceptance
- repair + pass → repair
- repair + replan → replan
- terminal + pass → terminal reject
- terminal + replan → terminal reject
- any pair containing unknown, inconclusive, or not-run → block
- any pair containing conflict → no write

Durable reason classes:

- `candidate_evidence_conclusively_accepted`
- `candidate_evidence_requires_repair`
- `candidate_evidence_requires_replan`
- `candidate_evidence_terminally_rejected`
- `candidate_evidence_nonconclusive`

### 5. Matrix eligibility

For the selected branch, consume the exact selected entry from:

- standing policy;
- risk lane;
- decision-time authority;
- global stop;
- source-effect ceiling.

For productive branches—acceptance, repair, replan:

- any conflict → no write;
- all permit → retain selected branch;
- any deny or unknown → `post_execution_program_block`.

The block reason class is:

`productive_branch_not_permitted`

Retain all individual matrix results/reasons in the immutable decision basis.

For terminal reject or block, every matrix must return the exact profile-owned
halt-only permit. Any non-permit halt-only result is an evaluator-contract
conflict and produces no write.

This yields the required active-stop behavior:

- terminal evidence → terminal reject;
- otherwise an active stop converts a productive candidate branch to block;
- no tuple-order tie-break exists.

### 6. Model recommendation

Evaluate recommendation consistency only after the authoritative branch exists.

Recommendation consistency is retained evidence and never changes the branch.

### 7. Durable branch mapping

Freeze exactly:

- `candidate_acceptance` → `accept` / `candidate_acceptance`
- `candidate_repair` → `repair` / `candidate_repair`
- `attempt_selecting_replan` → `replan` / `attempt_selecting_replan`
- `program_terminal_reject` → `terminal_reject` /
  `program_terminal_reject`
- `post_execution_program_block` → `block` / `program_block`

All five are version-advancing.

Preserve migration-0002 nullability and branch grammar.

Do not add `redeliver` or `cancel`.

### 8. Block-reason precedence

When more than one block condition exists, the durable summary reason class is
selected in this pipeline order:

1. `decision_basis_not_current`
2. `candidate_evidence_nonconclusive`
3. `productive_branch_not_permitted`

All lower-level currentness, disposition, and matrix results remain retained in
the basis closure. The summary reason does not erase them.

### 9. Command authority

The future command may contain an optional expected-branch assertion for
conflict detection only.

The caller or model may not author:

- the authoritative branch;
- decision-time currentness conclusions;
- matrix conclusions;
- durable decision or result;
- receipt;
- latch postimage;
- terminal outcome;
- commit/recovery classification.

Model output remains proposal evidence only.

### 10. Acceptance-latch semantic dependency

Do not freeze latch storage, table, migration, or final field names.

Freeze only this interface:

- the future decision command must bind a future-owner-defined latch selector
  sufficient to identify an exact expected available preimage and preassigned
  consumed postimage;
- the selector is covered by the command digest and recovery selector;
- it grants no authority and does not request acceptance;
- if acceptance is derived, the guarded writer must verify the exact available
  preimage and commit the accept decision plus consumed postimage atomically;
- any mismatch, missing/duplicate/malformed/ambiguous state, or consumed
  preimage produces no write, not a fallback block;
- replay returns the committed decision and latch postimage without another
  mutation;
- recovery verifies decision and latch as one committed family;
- nonaccept branches create no latch mutation or postimage;
- no accept writer may become callable until the complete latch owner is
  separately frozen.

### 11. Terminal and RW0-D/E separation

The later terminal-outcome fact:

- binds the exact committed decision/result/receipt;
- on acceptance binds the already-committed latch postimage;
- never consumes or mutates the latch;
- is not a development decision or effect basis.

Do not design terminal storage.

Do not add worker, process, transport, cancellation, Git, ES, publication,
RW0-D, or RW0-E semantics.

### 12. Physical persistence status

Record only the selected direction:

- migration-0002 decision/version/head/receipt facts remain canonical;
- a later bounded-hybrid physical freeze must determine whether supplemental
  immutable basis/currentness/graph/result/recovery relations require migration
  0005;
- no SQL, table, key, trigger, index, checksum, reader, writer, migration, or
  application-generation change is frozen here.

## Authoritative owner document

Create:

`.docs/rw0-c2-durable-progression-decision-semantic-contract.md`

It must be the single semantic owner for this future contract and must contain:

- status and nonimplementation statement;
- truth/authority classification;
- exact no-write/block/unresolved distinction;
- complete reducer and finite tables;
- branch mapping;
- reason classes;
- model non-authority;
- command authority and prohibitions;
- abstract result/receipt/replay/recovery responsibilities;
- acceptance-latch dependency;
- terminal/RW0-D/E separation;
- physical-persistence handoff;
- implementation and audit stop conditions.

## Allowed path ceiling

Only these paths may change or be created:

1. `AGENTS.md`
2. `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
3. `.docs/autonomous-software-development-operating-model.md`
4. `.docs/architecture.md`
5. `.docs/authority-boundaries.md`
6. `.docs/software-development-progression-boundary.md`
7. `.docs/rw0-remote-worker-contact-phase-entry.md`
8. `.docs/rw0-c1-durable-evidence.md`
9. `.docs/c2b-durable-development-state.md`
10. `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
11. `tests/test_autonomous_software_development_operating_model.py`
12. `tests/test_architecture_contracts.py`
13. `tests/test_software_development_progression_boundary.py`
14. `tests/test_rw0_remote_contact_phase_entry_contract.py`
15. `tests/test_post_execution_pure_owner_boundaries.py`
16. `tests/test_c2b0_durable_state_contract.py`

Do not touch every allowed path merely because it is allowed. Use the smallest
truthful subset.

If another path is required, stop without widening scope.

For `.docs/c2b-durable-development-state.md`, preserve its append-only and
supersession conventions. Do not rewrite older forecasts as though they had
always contained this decision.

## Contract-test requirements

Tests must causally enforce, not merely inventory:

- all validation × review combinations;
- conflict before any durable branch;
- nonconclusive before candidate-quality severity;
- conclusive severity order;
- currentness conflict/stale/unknown/current;
- selected productive matrix permit/deny/unknown/conflict;
- active-stop terminal-versus-block behavior;
- halt-only permit requirement;
- model inconsistency non-authority;
- exactly one final branch or no-write;
- closed reason classes and block-reason precedence;
- exact branch-to-kind/variant mapping;
- cancel/redeliver exclusion;
- accept-only latch mutation dependency;
- nonaccept latch non-mutation;
- no-write versus block versus recovery-unresolved;
- absence of command/writer/latch/terminal implementation;
- absence of migration 0005 and public/runtime widening.

Tests must mutate one premise at a time and prove the expected outcome.

Do not import or execute future source modules. This is a documentation-contract
test tranche.

## Protected surfaces

Do not change:

- any `src/` path;
- any migration;
- `sqlite_migration.py`;
- transaction, reader, writer, or StateStore code;
- package exports;
- current post-execution pure-owner source;
- existing decision-row source;
- public protocols;
- examples, schemas, configs, or supporting repositories.

## Validation

Run serially with bytecode and pytest caches disabled.

At minimum:

1. the new contract-test module;
2. every modified existing test module;
3. the relevant architecture, operating-model, progression, RW0, C2B and
   nonimplementation test groups;
4. the complete repository test suite;
5. `git diff --check`;
6. status and artifact checks proving only the authorized paths changed and no
   generated artifact remains.

If the full suite requires a clean external local clone because of pre-existing
ignored cache, validate the exact working-tree bytes in that clone without
contacting a remote.

Do not alter repository bytes in response to an unrelated pre-existing warning.

## Inline closeout report

Return inline:

- opening and closing Git coordinates;
- exact changed paths;
- per-file byte size and SHA-256;
- concise diff classification;
- exact validation commands and results;
- any source contradiction encountered;
- remaining latch and physical-persistence seams;
- skipped validation;
- artifact/cache posture;
- all non-authorizations.

Do not create an external report or manifest.

## Success token

Use only if the contract and causal tests are complete and validation passes:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_WRITTEN_VALIDATED_READY_FOR_INDEPENDENT_AUDIT`

## Blocking token

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_WRITING_BLOCKED`

## Required non-actions

State:

```text
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
DATABASE_NOT_OPENED_OR_MUTATED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
```

**Sources:** Codex’s semantic-freeze report. It independently verified the exact merged baseline, identified the absence of a total reducer, preserved the no-write/block/recovery distinction, and confined the next step to repository-owned documentation and causal contract tests. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

**Confidence:** High that Codex’s block is correct; high that the reducer above resolves the reported non-uniqueness without giving the model or caller decision authority; moderate-to-high on the exact treatment of inconclusive validation/review as `block`, which is the safest interpretation of the current target and should now be made explicit in the owning repository contract.
