# Governed Execution Coordinator — RW0-C Durable Decision Branch Contract V5 Independent Re-audit

## Objective

Perform a fresh, parent-led, local, read-only independent re-audit of the V5
RW0-C durable progression-decision semantic-contract candidate.

The checked-out repository is the sole audit target and current-contract
source. Do not request or use chat exports, prior audit attachments, Downloads
artifacts, Project artifacts, historical JSONL packages, generated manifests,
or sibling repositories.

Do not repair the candidate.

Return one substantive audit report inline. Do not create or attach a report,
manifest, package, freeze artifact, or other client-visible file.

## Repository and committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Expected committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- HEAD tree: `9e69d4a517b482704c159958abc2f90ed3cdcfd8`
- sole parent: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- subject: `feat: implement RW0-C post-execution pure owners`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

A mismatch in repository identity, path set, classification, file type, mode,
size, or per-file SHA-256 requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Exact V5 candidate

The live worktree must contain exactly these seven candidate paths and no other
tracked or untracked difference from HEAD:

| Status | Path | Mode | Bytes | SHA-256 |
|---|---|---|---:|---|
| `M` | `.docs/architecture.md` | `0644` | 42,104 | `d10da9d372c9920ed567f2f705d798cd52f8fb37a9bb94a414f9f4ce193d5494` |
| `M` | `.docs/autonomous-software-development-operating-model.md` | `0644` | 37,278 | `f78a4e62a2e17e7b2cf511a2eb5638e8fa6b64d291207d5fdc6b9fa08a8183ee` |
| `M` | `.docs/c2b-durable-development-state.md` | `0644` | 1,887,232 | `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5` |
| `M` | `.docs/rw0-c1-durable-evidence.md` | `0644` | 14,370 | `3507dca630a103a8ba54f643b662183371ae8d76333d721a91ba6e716eb9f93b` |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | `0644` | 55,944 | `d3fdc11e379cf7bad3bd547c6cc848abdaaa145e0e11ef6058cb7cec9bb29b54` |
| `??` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | `0644` | 68,944 | `92f1d2b34f9cf2486102edf31de142acc07db9a116f64d64212ca497d0a554c1` |
| `??` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | `0644` | 239,999 | `9b0751f55b238c55130b6481bbea34454c5ed8866212f5546baa6e5af1b0fa19` |

All seven must be regular non-symlink files.

Require exact `AGENTS.md`:

- bytes: `60,530`
- SHA-256:
  `c12a3449e761728f2093c19bb30134c54994b045843313471a6d715b648355a6`

Protected current surfaces must remain byte-identical to HEAD:

- every `src/` path;
- every existing tracked test;
- all migrations;
- `src/ge_nwp_coordinator/sqlite_migration.py`;
- transaction, reader, writer, StateStore, WriterSession, and package-export
  source;
- `.docs/authority-boundaries.md`;
- `.docs/software-development-progression-boundary.md`;
- migrations 0001–0004 and their catalog identities.

Migration `0005` must remain absent.

## Binary-patch corroboration

Construct a deterministic seven-path binary patch by processing the paths in
the table order.

For each tracked path:

`git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- <path>`

For each untracked path:

`git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null <path>`

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate exact stdout bytes in table order.

Implementation-reported V5 coordinate:

- bytes: `327,443`
- SHA-256:
  `b76ee8a85bc12250f8d56cd8eb15f48c35b5ee7c18acd7dd1772ed76c6a3890f`

Run the assembly twice.

Per-file receipts and live Git status are the primary provenance identity. If
all primary coordinates match but the aggregate differs, do not stop
automatically. Reproduce the specified assembly, record the stable observed
coordinate, classify the stale aggregate as a report-only discrepancy, and
continue only when there is no candidate-byte ambiguity. Any unresolved
per-file, path-set, or baseline difference remains
`AUDIT_PROVENANCE_MISMATCH`.

## V4-to-V5 transition classification

The implementation report says only this file changed from V4:

`tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`

Reported transition:

- V4: 225,054 bytes /
  `2e890348745bc5c22470e461cb665912302b12033ad83c8d52c43bd6bd586660`
- V5: 239,999 bytes /
  `9b0751f55b238c55130b6481bbea34454c5ed8866212f5546baa6e5af1b0fa19`

The semantic owner and other five candidate documents must match the fixed V5
receipts above.

Historical V4 bytes are not required audit inputs. The live V5 candidate is the
audit target.

## Audit posture

This is an independent audit, not implementation validation.

Permitted:

- read-only Git inspection;
- static documentation, source, migration, and test inspection;
- read-only Python and AST parsing with `PYTHONDONTWRITEBYTECODE=1`;
- production-module execution and pytest only in a private external local clone;
- temporary hostile copies and mutants outside the live repository;
- at most three bounded read-only explorer subagents with self-contained
  prompts.

Prohibited:

- editing, formatting, cleaning, or repairing live repository files;
- staging, committing, pushing, or modifying a PR;
- remote contact;
- sibling-repository inspection;
- moving, deleting, rewriting, or importing through the live ignored cache;
- opening or mutating an operator or product-state database;
- running migrations;
- installing dependencies;
- starting services;
- generating client-visible artifacts.

Remove all audit-created temporary data at closeout.

## Source-of-truth posture

Apply the repository authority hierarchy:

- Git owns commit, tree, blob, and ref facts.
- `AGENTS.md` routes repository composition and contract authority.
- `.docs/` owns current and target contract semantics within each document’s
  declared scope.
- `.docs/autonomous-software-development-operating-model.md` is the
  composition/current-status authority.
- source and migrations implement current behavior and durable representation.
- tests are executable evidence and drift guards, not an independent semantic
  owner.
- reports and generated artifacts are evidence only.

The semantic owner document is unchanged from the substantively audited V4
candidate. The V5 audit must confirm that the one-file verifier repair closes
the four prior Medium test-adequacy findings without changing semantic
authority or creating a second owner.

## Recommended explorer structure

At most three read-only explorers may be used.

### Explorer 1 — witness and retained-evidence causality

Inspect:

- production-label extraction;
- AST independence guard;
- sentinel-integrity tests;
- exact retained productive evidence;
- external witness-label and retained-reason mutants.

### Explorer 2 — pointer and stage-order causality

Inspect:

- exact pointer-check helper and integrity tests;
- complete matrix-reason validation;
- combined-fault precedence;
- external pointer and matrix-stage mutants.

### Explorer 3 — scope, provenance, and regression audit

Inspect:

- one-file mutation boundary;
- semantic-owner immutability;
- source/migration/public/runtime nonimplementation;
- selector reproducibility;
- full validation and artifact hygiene.

The parent must independently inspect the core evidence and reconcile all
findings.

## Required inspection

Read in full or through all relevant current sections:

- `AGENTS.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/architecture.md`
- `.docs/authority-boundaries.md`
- `.docs/software-development-progression-boundary.md`
- `.docs/c2b-durable-development-state.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`

Inspect current source owners as needed to confirm that the V5 test changes do
not forge or replace production behavior:

- `src/ge_nwp_coordinator/_post_execution_evidence_values.py`
- `src/ge_nwp_coordinator/_post_execution_policy_values.py`
- `src/ge_nwp_coordinator/_rw0_c_decision_input_values.py`

Inspect migration, public-surface, transaction, reader, writer, and
nonimplementation guards relevant to the candidate.

## Audit question 1 — one-file repair boundary

Verify that:

- the semantic owner document is byte-identical to the fixed V4/V5 receipt;
- the other five candidate documents are unchanged;
- all source, migrations, and existing tracked tests remain unchanged;
- only the untracked contract verifier changed from V4;
- no new authority, contract, branch, matrix grammar, reducer, source behavior,
  public surface, migration, or runtime behavior was introduced.

Any semantic-document or source change is blocking.

## Audit question 2 — production-witness label provenance

The prior audit found that witness labels could be copied from fixed expected
pairs while every production builder still ran and all tests remained green.

Independently inspect the exact extraction path used by
`_production_witness_ledger()`.

Require:

1. a builder registry containing no expected result/reason;
2. runtime-returned production objects or accepted relation/action results;
3. an extraction helper that reads `owner`, `result`, and `reason` directly
   from the returned object or immutable returned mapping;
4. storage of observed labels before comparison with fixed expectations;
5. a later, separate equality check against the fixed accepted set.

The extraction path must not read, receive, close over, or index:

- `FIXED_EXPECTED_ACCEPTED_PAIRS`;
- parsed machine-contract accepted pairs;
- parsed human tables;
- another expected result/reason field.

### Sentinel-integrity reproduction

Use the same extraction helper as the live ledger.

Feed it a returned-entry-shaped object or immutable mapping whose result/reason
are sentinel values different from the fixed expectation.

Require:

- the extractor returns the exact sentinels;
- the later observed-set comparison rejects them at:
  `production_witness:observed_pair_set:<owner>`.

A separate test-only extractor receives no credit.

### Structural provenance guard

Inspect and rerun the AST guard. It must prove that the ledger/extractor
functions:

- contain no load/reference to fixed expected-pair constants;
- contain no load/reference to parsed accepted-pair inventories;
- directly access returned entry labels;
- persist observed labels before comparison.

### Independent mutant

Replace the observed labels with values sourced from fixed expectations while
preserving all builder invocations and relation/action counts.

The complete module must fail at the exact forbidden-reference,
sentinel-integrity, or observed-pair-set boundary.

## Audit question 3 — exact JSON-pointer checker integrity

Inspect the exact contract-drift checker.

Require exact pointer equality, not prefix, substring, suffix, or sibling
acceptance.

Permanent integrity tests must cover:

```text
expected: /some/path
observed: /some/path/suffix

expected: /some/path/suffix
observed: /some/path

expected: /some/path
observed: /some/other
```

Each must assert the exact checker-integrity boundary.

Independently weaken equality to:

`observed.startswith(expected)`

The complete module must fail specifically at the prefix-integrity test:

`pointer_checker_integrity:expected_prefix_of_observed:nonexact_pointer_accepted`

Also confirm the existing 453 normative scalar leaves remain exactly bound and
that the 457-node selector count is explained by the scalar cases plus
coverage/integrity tests.

## Audit question 4 — exact retained productive evidence

For every conclusive productive candidate, the retained productive evidence
must preserve the exact canonical five-entry sequence with all fields:

```text
owner
branch
applicability
governed_effect_class
result
reason
```

Independently inspect the six V5 cases:

- stale currentness + productive acceptance candidate;
- unknown currentness + productive repair candidate;
- earlier block + productive deny;
- earlier block + productive unknown;
- earlier block + productive matrix conflict;
- normal currentness + all-permit productive branch.

Require:

- fixed expected sequences independent of the returned trace;
- exact owner order;
- exact branch/profile fields;
- exact result and reason for every owner;
- exact boundary identifying owner or sequence position on mismatch.

Independently replace every retained reason with one fabricated constant while
preserving owner order, result values, branch, and trace marker.

The module must fail in all six cases at an exact
`retained_productive_evidence:<case>:<index>:<owner>:reason` boundary.

## Audit question 5 — complete matrix-stage validation

The owner contract requires complete matrix grammar validation before
currentness and V14/V15 reduction.

Every entry in every owner matrix must have owner/profile/applicability/effect
class/result/reason validated, including unselected governed and halt-only
entries.

Require unconditional grammar validation. No `evaluate_semantics`, selected
branch, currentness, block-reason, or later-stage condition may suppress it.

Independently inspect the ten direct V5 precedence tests:

- five owners × unselected governed permit-reason mutation;
- five owners × unselected halt-only permit-reason mutation.

Each test must combine the malformed earlier-stage matrix with a later
currentness or V14/V15 conflict and require the matrix-stage conflict to
control. No currentness or V14/V15 trace marker may appear.

### Independent mutants

Construct and run at least these variants:

1. permit-reason validation only when `evaluate_semantics=True`;
2. permit-reason validation only for the selected branch;
3. complete matrix validation skipped after an earlier currentness block.

Each must retain the complete module collection and fail at the intended
`complete_matrix_stage:<owner>:<profile>:rejection` boundary.

## Audit question 6 — exact hostile boundaries

For every newly credited V5 hostile or integrity test, require:

- exact exception class;
- exact boundary/reason ID;
- exact owner, sequence position, pointer, or stage where applicable;
- no generic “some AssertionError occurred” credit;
- no failure caused only by syntax, formatting, collection shrinkage, or an
  unrelated assertion.

Inspect the complete new hostile registry and sample every category directly.

## Audit question 7 — verifier versus shadow owner

The test module is now 239,999 bytes.

Determine whether V5 remains an integrity repair around the existing
data-driven verifier rather than a second semantic owner.

Acceptable V5 additions:

- extraction integrity;
- structural AST independence checks;
- fixed trace/evidence assertions;
- pointer-check integrity;
- stage-order precedence cases;
- hostile mutation helpers.

Blocking signs:

- a second reducer;
- a second matrix grammar;
- a copied semantic owner;
- source evaluator/relation emulation;
- expected and observed values authored by the same new table;
- test-local semantics that override the unchanged owner document.

Do not reject on file size alone.

## Audit question 8 — regression of already accepted V4 semantics

Verify that V5 did not drift:

- `44 accepted / 24 excluded / 68 total` partition;
- all accepted production witnesses and exclusion proofs;
- documented/executable pipeline order;
- recursive duplicate-key rejection;
- productive evaluation after earlier block;
- all seven halt-only routes;
- all 35 same-owner productive-permit rejections;
- model evaluation after latch;
- exact five durable branches and migration-0002 mapping;
- V14/V15 projection;
- currentness semantics;
- block-summary precedence;
- no-write/block/recovery-unresolved separation;
- model and caller non-authority;
- abstract latch dependency;
- terminal and RW0-D/E separation;
- future bounded-hybrid persistence;
- migration `0005` absence.

Run representative or complete existing selector groups as specified below.

## Audit question 9 — selector reproducibility

For every selector:

1. run `--collect-only -q`;
2. record exact selected count;
3. run the exact module-scoped selector;
4. report observed result.

V5 fixed claims:

| Selector | Expected selected/execution |
|---|---:|
| `witness_label_provenance` | `2 / 2 passed` |
| `pointer_checker_integrity` | `3 / 3 passed` |
| `retained_productive_evidence` | `6 / 6 passed` |
| `complete_matrix_stage` | `10 / 10 passed` |
| `hostile` | `571 / 571 passed` |
| `pipeline_order` | `5 / 5 passed` |
| `production_witness` | `56 / 56 passed` |
| `source_reachability` | `36 / 36 passed` |
| `duplicate_key` | `2 / 2 passed` |
| `scalar_pointer` | `457 / 457 passed` |
| `halt_only` | `368 / 368 passed` |
| `earlier_block` | `4 / 4 passed` |
| `model_authority` | `36 / 36 passed` |
| `structural_nonimplementation` | `12 / 12 passed` |

No selector may select zero or silently over-select unrelated repository tests.

## Audit question 10 — external mutants

Independently reproduce at least these six V5 mutants:

1. witness labels sourced from fixed expectations;
2. pointer equality weakened to `startswith`;
3. retained productive reasons replaced with one fabricated constant;
4. permit-reason validation conditioned on `evaluate_semantics=True`;
5. permit-reason validation limited to the selected branch;
6. complete matrix validation skipped after currentness block.

For each require:

- the expected complete 1,286-node module collection;
- failure at the intended exact boundary;
- no parameter-count shrinkage;
- no syntax/format-only failure.

Report exact failed test IDs or exact boundary IDs.

## Independent validation

Construct a private external local clone from committed HEAD without remote
contact. Overlay exactly the seven live candidate files after verifying their
receipts.

Do not move, delete, rewrite, or import through the live ignored cache.

Run serially with:

- `PYTHONDONTWRITEBYTECODE=1`
- `PYTHONPATH=.:src`
- pytest cache disabled;
- external `--basetemp`.

At minimum run:

1. complete contract module;
2. every exact selector listed above;
3. architecture, operating-model, and progression tests;
4. exact remote-phase tests;
5. repository-grounded broad group:
   - `tests/test_c2b*.py`
   - `tests/test_rw0_c1_*.py`
   - `tests/test_sqlite_b1_migrations.py`
   - `tests/test_sqlite_c2b1_migration_framework.py`
   - `tests/test_sqlite_c2b2_migration_0002.py`
   - `tests/test_sqlite_section41_migration_0003.py`
   - `tests/test_sqlite_rw0_c1_migration_0004.py`
   - `tests/test_runtime_non_authority.py`
   - `tests/test_c2a_nonimplementation.py`
   - `tests/test_sqlite_b1_runtime_boundary.py`;
6. complete repository suite;
7. `git diff --check`;
8. both untracked-file whitespace checks;
9. CR, trailing-whitespace, and final-newline checks;
10. source, migration, existing-test, semantic-owner, and other-document
    preservation;
11. external-clone artifact scan.

Implementation-reported reference results:

- contract module: `1,286 passed`;
- architecture/operating/progression: `85 passed`;
- exact remote phase: `969 passed`;
- broad group: `1,682 passed`;
- complete repository: `7,470 passed, 3 warnings`.

Reproduce rather than assume.

The only expected warnings are the existing Python 3.13 multi-threaded `fork()`
deprecations from unchanged B2C writer-session tests.

## Live cache and closeout

At audit opening, inventory the live ignored cache without modifying it:

- repository-relative paths;
- file types;
- modes;
- byte sizes;
- SHA-256 values;
- deterministic canonical inventory bytes and digest.

At closeout require exact byte equality with opening.

Implementation-reported current coordinate:

- 37 files;
- canonical inventory bytes: `7,785`;
- SHA-256:
  `d047d86d6e29658cd214939df52c534ec156ec9372c20311f3b09d818c91f7a2`

Treat it as evidence to independently reproduce.

After deleting all audit-created temporary material, reverify:

- exact seven-path status;
- exact file types, modes, sizes, and hashes;
- zero staged and unmerged paths;
- no additional changed or untracked path;
- exact `AGENTS.md`;
- unchanged source tree;
- unchanged existing tracked tests;
- unchanged semantic owner and five other candidate documents;
- migrations exactly 0001–0004;
- no migration 0005;
- exact opening/closing cache equality;
- no audit-created repository artifact.

Run the complete receipt calculation twice and require byte-identical output.

## Severity and verdict rules

Any of the following is blocking:

- provenance mismatch;
- witness labels not proven to originate from returned production entries;
- pointer-prefix weakening escape;
- retained productive reasons not exactly protected;
- incomplete matrix grammar validation after or conditional on later stages;
- generic hostile boundaries;
- verifier becoming a shadow semantic owner;
- regression in previously accepted V4 semantics;
- semantic-owner, source, migration, public, or runtime widening;
- validation mismatch not attributable to the audit environment.

### Accept

Use only when no unresolved High- or Medium-severity finding remains:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance authorizes only a separate commit/publication gate for the exact
seven audited paths.

It does not authorize:

- source implementation;
- migration `0005`;
- durable decision writing;
- acceptance-latch implementation;
- terminal-outcome implementation;
- runtime activation;
- public API widening;
- the later physical-persistence implementation.

### Block

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_AUDIT_BLOCKED`

### Provenance mismatch

`AUDIT_PROVENANCE_MISMATCH`

## Inline report structure

Return:

1. primary verdict;
2. exact baseline and V5 candidate provenance;
3. binary-patch reconciliation;
4. inspection scope and limits;
5. one-file repair-boundary audit;
6. witness-label provenance audit;
7. pointer-checker integrity audit;
8. retained productive-evidence audit;
9. complete matrix-stage audit;
10. exact hostile-boundary audit;
11. verifier/shadow-owner audit;
12. preserved V4-semantics audit;
13. selector/count reproducibility;
14. external-mutant results;
15. independent validation results;
16. live-cache and final provenance;
17. severity-ranked findings;
18. exact next boundary;
19. required non-actions;
20. final token.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
SEMANTIC_OWNER_DOCUMENT_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TRACKED_TESTS_NOT_MODIFIED
OTHER_SIX_CANDIDATE_PATHS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
