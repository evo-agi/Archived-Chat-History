# Disposition

**Accept the independent audit’s `BLOCKED` verdict. Do not stage or commit the V3 candidate.**

This is not a provenance or scope failure. The auditor reproduced the exact baseline, seven-path candidate, binary patch, 66-file source manifest, and unchanged cache. Authority routing and current-versus-future status also passed. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The complete repository still passes **7,417 tests with the three expected warnings**. The candidate is blocked because several of those tests do not prove the semantic claims they advertise. :chatgpt-content-reference{index="2"}

## What the audit actually invalidates

### The `45 accepted / 23 unreachable` partition is not yet proven

The partition reconciles syntactically across metadata, prose, machine data, and fixed test constants. But the accepted witness ledger is partly self-describing:

- expected and observed labels both come from `PRODUCTION_WITNESS_METADATA`;
- builders record requested results rather than independently observed first accepted results;
- some relation-owned values are reconstructed directly instead of passing through their real relation/action boundary. :chatgpt-content-reference{index="3"}

The concrete V21 probe is decisive: a manufactured `support_conflict` value was rejected by the real relation with `source_owner_mismatch`, yet downstream witness builders still credited authority and ceiling pairs. Therefore **45 cannot remain a fixed target merely because V3 said 45**.

### The “unreachable” proofs are too weak

The three `accepted_relation_precludes` cases do not invoke the actual policy/risk relation, and `no_evaluator_branch` is inferred from literal tuple scanning rather than actual control flow. A dynamically constructed new pair escaped the reachability tests. :chatgpt-content-reference{index="4"}

The repair must independently rederive the final accepted/excluded partition. If the truthful result is 43/25, 44/24, or another split, the owner and tests must change accordingly. Source must not be altered merely to preserve 45/23.

### Representation and meta-test escapes remain

A duplicate JSON key can shadow contradictory contract data because normative JSON is parsed with ordinary last-key-wins behavior. :chatgpt-content-reference{index="5"}

The scalar-pointer corpus currently reports exact pointers, but weakening the exact equality assertion to a generic containment check leaves all 1,233 tests green. :chatgpt-content-reference{index="6"}

### The executable oracle contradicts its owner

The owner document requires matrix grammar and currentness to precede V14/V15 reduction. The test interpreter reduces V14/V15 first and can return before those earlier stages execute. This is a direct semantic-order contradiction, not merely missing coverage. :chatgpt-content-reference{index="7"}

### The temporary source barrier works, but the semantic guard does not

The full source-manifest barrier catches source additions and mutations. The separate AST guard can still be bypassed with aliased relative imports/calls and nested-path handling. That matters because the owner claims the semantic guard remains meaningful beyond the temporary manifest. :chatgpt-content-reference{index="8"}

## Engineering decision

The next boundary remains a **two-file documentation/test repair**, but with one correction to the audit’s framing:

> Do not repair toward a predetermined 45/23 partition. Re-adjudicate the partition from actual constructor → evaluator → relation/action behavior.

The V4 repair must:

- align the interpreter with the documented stage order;
- make witness builders return actual production observations rather than expected labels;
- invoke real relation/action boundaries for relation-owned values;
- replace literal-only reachability scanning with production execution plus fixed evaluator/control-flow guards;
- reject duplicate JSON keys;
- make weakening exact pointer checks causally fail;
- resolve aliases, relative imports, re-exports, and nested modules in the semantic guard;
- replace generic “something failed” hostiles with exact boundary assertions.

I also added a stop condition against another test-only spiral: if truthful closure requires a second full reducer implementation or source behavior recreated primarily in tests, Codex must stop and recommend a separately authorized private pure-reducer source tranche.

# V4 repair handoff

Resume the **same parent-only workspace-write Codex conversation**. Attach nothing.

:chatgpt-content-reference{index="10"}[Download the complete V4 repair prompt](sandbox:/mnt/data/Coordinator_RW0_C_Durable_Decision_Branch_Contract_Repair_V4_Prompt.txt)

```text
Filename:
Coordinator_RW0_C_Durable_Decision_Branch_Contract_Repair_V4_Prompt.txt

Size:
21,452 bytes

SHA-256:
3c62752e3e903cb646efdf61d97871ee6c61eb4c246097b0ac17398c062f728d

Logical lines:
667

Final newline:
present
```

The mutation ceiling remains:

```text
.docs/rw0-c2-durable-progression-decision-semantic-contract.md
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
```

The other five candidate documents must remain byte-identical.

Success token:

```text
RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT
```

Blocking token:

```text
RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIR_V4_BLOCKED
```

A successful repair still authorizes only another fresh read-only audit. It does not authorize source implementation, migration `0005`, durable decision writing, acceptance-latch implementation, terminal-outcome implementation, staging, commit, publication, or runtime activation.

**Sources:** V3 independent re-audit report. Its final provenance remained exact, and it prescribed a further documentation/test-only repair rather than an architecture reset. :chatgpt-content-reference{index="9"}

**Confidence:** High that `BLOCKED` is correct; high that the witness/reachability and pipeline-order findings are substantive; moderate-to-high that one final two-file repair is still efficient. If V4 again requires a larger shadow reducer in tests, the better path is a separately frozen private pure-source reducer tranche.
