# Governed Execution Coordinator — RW0-C Durable Decision Branch Contract Repair V4

## Objective

Repair the uncommitted RW0-C durable progression-decision semantic-contract
candidate after the V3 independent re-audit BLOCK.

This remains a repository-first, parent-only, documentation-and-contract-test
repair. The checked-out repository is the sole current-contract source.

Only these two files may change from their exact opening bytes:

1. `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
2. `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`

Do not modify source, migrations, existing tracked tests, schemas, readers,
writers, transaction code, StateStore, WriterSession, package exports, public
APIs, or runtime behavior.

Return one substantive inline closeout report. Do not create or attach an
external report, manifest, package, or freeze artifact.

This is the final authorized documentation/test-only repair pass. If exact
production behavior cannot support a truthful contract without source changes,
stop and report that a separate private pure-reducer source tranche is required.
Do not continue building a larger shadow implementation in tests.

## Repository and exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- tree: `9e69d4a517b482704c159958abc2f90ed3cdcfd8`
- sole parent: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- subject: `feat: implement RW0-C post-execution pure owners`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged and unmerged paths
- no active Git operation or index lock

Do not fetch or contact remotes.

## Exact opening candidate

Require exactly these seven regular non-symlink mode-`0644` paths and no other
difference from HEAD:

| Status | Path | Bytes | SHA-256 |
|---|---|---:|---|
| `M` | `.docs/architecture.md` | 42,104 | `d10da9d372c9920ed567f2f705d798cd52f8fb37a9bb94a414f9f4ce193d5494` |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 37,278 | `f78a4e62a2e17e7b2cf511a2eb5638e8fa6b64d291207d5fdc6b9fa08a8183ee` |
| `M` | `.docs/c2b-durable-development-state.md` | 1,887,232 | `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5` |
| `M` | `.docs/rw0-c1-durable-evidence.md` | 14,370 | `3507dca630a103a8ba54f643b662183371ae8d76333d721a91ba6e716eb9f93b` |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 55,944 | `d3fdc11e379cf7bad3bd547c6cc848abdaaa145e0e11ef6058cb7cec9bb29b54` |
| `??` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 68,424 | `2f4885a64d28470463fda6f7763c5820c23b036931ce1769bb7174ec71399681` |
| `??` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 154,849 | `86a85d0a028ecc1f351d6442db04681965592620f0cc6512360ba9f0a0ba4460` |

Opening deterministic seven-path binary patch:

- bytes: `239,446`
- SHA-256:
  `856b01ca0a2b9fd7607656d4f369a78baa0a14d45231c102796cee6dcbd901c0`

Require exact `AGENTS.md`:

- bytes: `60,530`
- SHA-256:
  `c12a3449e761728f2093c19bb30134c54994b045843313471a6d715b648355a6`

Stop before editing on any mismatch:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIR_V4_BLOCKED`

## Mutation ceiling

Only the semantic owner and its untracked contract-test module may change from
their opening bytes.

The other five candidate documents must remain byte-identical to the receipts
above.

No existing tracked test may change.

The final worktree must still contain exactly the same seven candidate paths
relative to HEAD.

## Accepted V3 audit findings

Treat the V3 independent audit as the repair basis:

1. The documented owner and the test interpreter disagree on stage order:
   V14/V15 conflict currently returns before matrix grammar and currentness.
2. The claimed production witness ledger is self-describing:
   expected and observed labels share `PRODUCTION_WITNESS_METADATA`, and some
   relation-owned values are reconstructed directly instead of passing through
   their required relation/action.
3. At least the demonstrated V21 `support_conflict` construction is not a valid
   relation-backed witness; the real relation rejects it earlier with
   `source_owner_mismatch`.
4. The three `accepted_relation_precludes` proofs do not invoke the actual
   standing-policy or risk-lane relation/action.
5. `no_evaluator_branch` is supported only by literal tuple scanning and misses
   dynamic construction/control-flow changes.
6. Machine-contract parsing accepts duplicate JSON keys.
7. Weakening exact JSON-pointer checking to generic drift lets all tests pass.
8. The semantic AST guard misses aliased relative imports/calls, re-exports,
   and nested-path cases; the full-source manifest currently catches them.
9. Several hostiles prove only that some `AssertionError` occurred rather than
   the exact intended boundary.
10. Selector and ordinary regression validation otherwise reproduced exactly.
11. Authority, current/future classification, metadata partition syntax,
    earlier-block behavior, all halt-only routes, model/latch ordering,
    documentation hierarchy, and provenance are otherwise sound.

Do not reopen accepted semantics except where behavior-backed witness
adjudication requires changing the accepted/unaccepted pair partition.

## 1. Align the executable oracle with the normative stage order

The owning contract’s deterministic stage order remains:

1. basis grammar, identity, lineage, profile, and provenance validation;
2. complete matrix inventory, owner, profile, applicability, effect class, and
   exact result/reason grammar validation;
3. decision-time currentness reduction;
4. V14 validation and V15 review projection/reduction;
5. productive matrix evaluation when a conclusive productive candidate exists;
6. final branch and block-summary selection;
7. final halt-only matrix verification when the selected branch is terminal or
   block;
8. acceptance-latch validation when acceptance is selected;
9. model recommendation consistency last.

The generic interpreter must execute exactly that order and expose the same
ordered trace.

Freeze combined-fault precedence with direct tests:

- missing matrix owner + V14 conflict:
  matrix inventory/grammar no-write controls;
- foreign matrix pair + V14 conflict:
  matrix conflict controls;
- currentness conflict + V14 conflict, with valid matrix grammar:
  currentness conflict controls;
- V14 conflict alone, with every earlier stage valid:
  V14 conflict controls;
- V15 conflict alone, with every earlier stage valid:
  V15 conflict controls.

No later-stage fault may mask an earlier stage, and no earlier stage may be
skipped merely because a later conflict is already present.

## 2. Re-adjudicate the accepted matrix-pair partition from behavior

Do not preserve `45 accepted / 23 unreachable` by inertia.

Treat it as the V3 hypothesis to verify.

For every metadata-declared owner/result/reason pair:

1. inspect the current metadata declaration;
2. inspect the actual constructor and evaluator control flow;
3. construct a valid production input where possible;
4. invoke the actual production evaluator;
5. invoke the actual required relation/action boundary when the decision basis
   consumes a relation-owned value;
6. record the first accepted production owner/result/reason output;
7. classify the pair as:
   - `accepted_emittable`;
   - `no_evaluator_branch`;
   - `valid_construction_precludes`;
   - `accepted_relation_precludes`.

If a V3-accepted pair cannot be observed through that complete chain, move it
out of `accepted_emittable`.

If a V3-unreachable pair is actually observable, move it into
`accepted_emittable`.

Update human tables, machine data, fixed expectations, counts, and tests to the
truthfully re-derived final partition.

Do not modify current source to preserve a desired count.

If the partition cannot be established without source changes, stop with the
blocking token and recommend a separate private pure-source semantic tranche.

## 3. Production witness architecture

Remove or redesign `PRODUCTION_WITNESS_METADATA` so that expected and observed
pairs cannot share one mutable record.

Maintain independent layers:

### Fixed expected partition

A fixed, manually reviewed owner-specific set of expected accepted pairs and
expected excluded pairs.

### Witness-builder registry

A registry keyed only by stable witness ID and callable/builder identity.

A builder must not receive or store its expected `result` or `reason`.

It must return the actual production object or actual accepted relation/action
result from which the test reads:

```text
owner
result
reason
```

### Observed ledger

Create the observed ledger only from runtime-observed production outputs.

Compare the observed set and owner provenance to the fixed expected accepted
set.

The ledger must record:

```text
witness_id
production constructors
production evaluator
relation/action boundary, if any
observed owner
observed result
observed reason
first accepted boundary
```

### Relation-owned values

For every relation-owned pair, the witness must invoke the actual relation or
action used by the decision basis.

Direct `from_mapping` reconstruction of the final relation-owned value does not
receive witness credit.

Add a permanent negative reproducing the audit’s V21 probe:

- mutate `effect_fence_class`;
- require the real relation to reject with the exact current
  `source_owner_mismatch` boundary;
- ensure no downstream authority/ceiling pair is credited from that rejected
  evidence.

## 4. Unreachable-pair proof architecture

### `accepted_relation_precludes`

Invoke the actual standing-policy or risk-lane relation/action, not merely
`V41/V42.from_mapping`.

Assert the exact first rejection class/reason.

### `valid_construction_precludes`

Invoke the actual production constructor or invariant boundary.

Assert the exact first rejection class/reason.

### `no_evaluator_branch`

Do not rely on searching one function for literal string tuples.

For each relevant evaluator:

1. create a fixed normalized AST fingerprint for the exact evaluator/helper
   control-flow surface used by the contract;
2. enumerate and resolve its result/reason-producing return sites, including:
   - names bound to constants;
   - tuple/list construction;
   - conditional expressions;
   - local constant mappings;
   - called local helpers that produce result/reason;
3. compare that source-semantic inventory to a fixed reviewed inventory;
4. execute all reachable return paths with production witnesses;
5. require every accepted source return pair to have a witness.

Add an external dynamic mutant that emits a metadata-only pair using a
non-literal construction such as `tuple([...])`.

The `source_reachability` selection itself must fail at the evaluator
control-flow/return-site boundary, independently of the complete source-manifest
barrier.

The normalized evaluator/helper AST fingerprint is a temporary contract guard
for this contract-only tranche and must be documented as supersedable by a
later authorized source tranche.

## 5. Five-way reconciliation

Require:

```text
metadata pairs
=
accepted_emittable pairs ∪ excluded metadata pairs
```

with disjoint sets.

Require:

```text
accepted_emittable pairs
=
fixed expected accepted pairs
=
actual production observed ledger
=
human accepted table
=
machine accepted inventory
```

Require:

```text
excluded metadata pairs
=
fixed expected excluded pairs
=
source boundary proofs
=
human excluded ledger
=
machine excluded inventory
```

No layer may derive its expected result from the layer under test.

No shared mutable table may author both an expectation and its observed proof.

## 6. Duplicate-key rejection

Parse every normative JSON representation with recursive duplicate-key
rejection.

This includes:

- the embedded machine-readable contract;
- any fixed JSON literal used as an expected representation;
- temporary hostile copies.

Do not use unrestricted `json.loads` for normative contract data.

Add one permanent hostile with a contradictory shadowed duplicate key and
require the exact `duplicate_json_key` boundary before canonical or semantic
comparison.

The hostile must fail even when last-key-wins parsing would otherwise make the
visible parsed object equal to the accepted contract.

## 7. Exact JSON-pointer protection

Keep per-leaf exact pointer checks, but add an independent behavioral guard for
the checker itself.

Use a helper equivalent to:

```text
assert_exact_contract_drift(exception, expected_pointer)
```

It must compare the complete exact error text or structured pointer, not a
substring.

Add a separate test that supplies:

- the right generic prefix;
- the wrong pointer.

The helper must raise an assertion failure.

Therefore weakening the helper from exact equality to generic containment must
make the permanent module fail.

Also require:

- one fixed independent scalar-leaf count constant;
- exact equality between that constant, enumerated pointer set, positive
  coverage map, and hostile coverage map;
- no duplicate pointers;
- no coordinated shrinkage;
- exact one-premise mutation per pointer.

The final scalar count may change if the re-adjudicated matrix partition changes.
Report the final value; do not preserve `452` by inertia.

## 8. Semantic AST guard and temporary source barrier

Preserve the complete 66-file source-manifest barrier as the exact temporary
contract-only no-source-change gate.

Clarify in the owner document:

- it is authoritative for this tranche’s source-byte nonimplementation claim;
- it is intentionally supersedable by a future authorized source tranche;
- semantic AST checks are supplementary and protect named authority/public
  boundaries;
- they are not claimed to detect every conceivable future neutral-named source
  implementation after the manifest is superseded.

Repair the supplementary semantic resolver so it independently handles:

- `ast.Import`;
- absolute and relative `ast.ImportFrom`;
- imported aliases;
- module aliases;
- symbol aliases;
- attribute call chains;
- re-exports through package `__init__.py`;
- nested packages;
- full repository-relative module identity rather than basename-only identity.

Add isolated synthetic-tree tests proving semantic detection of:

```python
from ge_nwp_coordinator import _rw0_c_decision_input_values as d
d.some_future_decision_call(...)
```

```python
from . import _rw0_c_decision_input_values as d
d.some_future_decision_call(...)
```

and equivalent re-export/alias paths.

These semantic tests must fail at the resolved import/call boundary even when
the complete source-manifest check is not invoked.

Keep the source-manifest hostiles for neutral new files and modified existing
source.

## 9. Exact hostile boundaries

Replace bare or generic:

```python
with pytest.raises(AssertionError):
```

where semantic credit is claimed.

For source-binding, witness, human/machine ledger, halt bypass, pointer,
duplicate-key, and manifest hostiles, assert:

- exact exception class;
- exact reason/boundary identifier;
- exact JSON pointer or owner/pair where applicable;
- exact stage/trace marker where applicable.

A hostile receives no credit merely because some unrelated assertion failed.

## 10. Preserve already accepted behavior

Do not regress:

- exact V14/V15 projection;
- complete matrix inventory/order;
- conflict-first behavior within the normative stage order;
- currentness meanings;
- nonconclusive block;
- `terminal > replan > repair > accept`;
- productive evaluation after earlier currentness block;
- all seven halt-only routes;
- all 35 same-owner productive-permit rejections;
- model recommendation after latch;
- exact five branches and migration-0002 mapping;
- version advancement;
- cancel/redeliver exclusion;
- block-summary precedence;
- no-write/block/recovery-unresolved separation;
- caller/model non-authority;
- abstract future latch interface;
- terminal and RW0-D/E separation;
- future bounded-hybrid persistence;
- migration `0005` absence;
- authority and current/future documentation classification.

## 11. Test architecture stop condition

The test module must remain a contract verifier, not become an alternate source
implementation.

If completing the repair requires:

- a second full reducer implementation;
- a general symbolic executor;
- source behavior recreated primarily in test-local code rather than invoked;
- or a larger shadow owner than the future private pure reducer itself,

stop with the blocking token and recommend a separate private pure-reducer
source tranche.

## 12. Exact selectors

Provide uniquely reproducible module-scoped selectors:

```text
-k pipeline_order
-k production_witness
-k source_reachability
-k duplicate_key
-k scalar_pointer
-k halt_only
-k earlier_block
-k model_authority
-k structural_nonimplementation
-k hostile
```

Before reporting each result:

1. run `--collect-only -q`;
2. record the exact selected node count;
3. run the exact selection;
4. report the observed command and result only.

No selector may select zero tests.

## 13. Required external mutants

In disposable external copies, independently prove failure for at least:

1. V14/V15 conflict returned before matrix grammar;
2. one accepted witness label self-authored from expectation metadata;
3. one relation-owned witness bypassing its relation/action;
4. one accepted pair made unreachable;
5. one metadata-only pair dynamically emitted through `tuple([...])`;
6. one `accepted_relation_precludes` proof that skips the relation;
7. contradictory duplicate JSON key;
8. exact pointer checker weakened to generic containment;
9. aliased absolute import/call;
10. aliased relative import/call;
11. package re-export alias;
12. productive evaluation suppressed after earlier block;
13. same-owner productive permit accepted on halt-only;
14. model evaluation moved before latch;
15. neutral source file added;
16. existing source byte modified.

Each mutant must:

- retain the expected full module collection;
- fail at the intended exact boundary;
- not rely on syntax, formatting, or parameter-count shrinkage.

## 14. Validation

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
-p no:cacheprovider
--basetemp=<external path>
```

Use a clean local-only external clone for production execution and the complete
suite. Do not move, delete, or rewrite the live ignored cache.

At minimum run:

1. complete repaired contract module;
2. every exact selector above;
3. architecture/operating-model/progression tests;
4. remote-phase tests;
5. relevant C2B/C1/migration/runtime/nonimplementation tests;
6. complete repository suite;
7. `git diff --check`;
8. both untracked-file whitespace checks;
9. CR/trailing-whitespace/final-newline checks;
10. source, migration, existing-test, and protected-document preservation;
11. live-cache opening/closing equality;
12. external-clone artifact scan.

The prior audit reproduced:

- complete module: `1,233 passed`;
- full repository: `7,417 passed, 3 warnings`.

The final counts may change. Report observed results only.

The only expected warnings are the existing Python 3.13 multi-threaded `fork()`
deprecations from unchanged B2C writer-session tests.

## 15. Closeout provenance

Report inline:

- opening and closing Git coordinates;
- exact seven-path candidate;
- exact two-file opening-to-closing transition;
- status, mode, bytes, and SHA-256 for all seven paths;
- deterministic binary-patch bytes and SHA-256;
- two independent complete receipt calculations;
- final accepted/excluded matrix-pair counts by owner;
- complete production-witness count;
- unreachable-proof count by proof type;
- final scalar-pointer count;
- exact selector collection/execution counts;
- external mutant results and intended boundaries;
- full validation commands/results;
- source/migration/existing-test preservation;
- live-cache and artifact posture;
- historical cache-movement process deviation noted but not repeated;
- unresolved latch and physical-persistence seams;
- all required non-actions.

Do not create an external report or manifest.

## Success token

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT`

Success authorizes only another fresh read-only independent audit.

## Blocking token

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIR_V4_BLOCKED`

Use the blocking token if a truthful final accepted/excluded partition or proof
architecture requires current source changes.

## Required non-actions

State:

```text
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TRACKED_TESTS_NOT_MODIFIED
OTHER_FIVE_CANDIDATE_DOCUMENTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
