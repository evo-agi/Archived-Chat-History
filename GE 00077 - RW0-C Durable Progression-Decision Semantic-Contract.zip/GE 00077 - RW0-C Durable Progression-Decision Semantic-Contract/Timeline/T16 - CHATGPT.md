# Disposition

**Proceed to a fresh independent re-audit. Do not stage or commit the V2 repair candidate.**

Codex reports a properly bounded repair:

- exactly the semantic owner document and its contract-test module changed from the prior audited candidate;
- the other five candidate documents stayed byte-identical;
- all source, migrations, existing tracked tests, public/runtime surfaces, and protected documents stayed unchanged;
- the contract module increased from 422 to **1,059 passing tests**;
- the complete suite increased from 6,606 to **7,243 passing tests**, with the same three expected warnings;
- all four independently constructed regression mutants were detected;
- the final candidate remains exactly seven paths.

That is the correct shape for the successor repair ordered by the prior audit. The prior audit found exact provenance and successful ordinary validation but blocked on six semantic and test-causality defects, then confined the successor to another seven-path documentation/test repair. :chatgpt-content-reference{index="0"}

No deterministic pre-audit blocker is visible in the closeout. The candidate is not accepted yet. The implementation conversation’s 1,059 passing tests cannot independently establish that:

1. the claimed 68 owner/result/reason pairs exactly match current source;
2. the human and machine representations are complete and mutually equivalent;
3. every terminal and block route executes the required five halt-only checks;
4. an earlier block reason cannot suppress a later no-write conflict;
5. model recommendation remains non-authoritative for out-of-vocabulary values;
6. productive and halt-only profile failures use the correct rejection taxonomy;
7. the recursive import and source-absence guards actually catch aliases, relative imports, and nested modules;
8. the enlarged hostile suite cannot adapt silently to a weakened contract.

The re-audit should remain repository-first and attachment-free.

---

## Complete replacement Codex prompt

```text
# Governed Execution Coordinator — RW0-C Durable Decision Branch Contract V2 Independent Re-audit

## Role

Perform a fresh, parent-led, local, read-only independent re-audit of the
repaired V2 RW0-C durable progression-decision semantic-contract candidate.

The checked-out repository is the sole audit target and source of current
contract truth.

Do not request or use:

- chat exports;
- prior audit attachments;
- Downloads artifacts;
- Project artifacts;
- historical JSONL packages;
- generated manifests;
- sibling repositories.

Do not repair the candidate.

Return one substantive audit report inline in the final response. Do not create
or attach a report, manifest, package, freeze artifact, or other client-visible
file.

## Repository and committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Expected committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- HEAD tree: `9e69d4a517b482704c159958abc2f90ed3cdcfd8`
- sole parent: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- subject: `feat: implement RW0-C post-execution pure owners`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Any baseline mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Exact V2 repair candidate

The live worktree must contain exactly these seven candidate paths and no other
tracked or untracked difference from HEAD:

| Status | Path | Mode | Bytes | SHA-256 |
|---|---|---|---:|---|
| `M` | `.docs/architecture.md` | `0644` | 42,104 | `d10da9d372c9920ed567f2f705d798cd52f8fb37a9bb94a414f9f4ce193d5494` |
| `M` | `.docs/autonomous-software-development-operating-model.md` | `0644` | 37,278 | `f78a4e62a2e17e7b2cf511a2eb5638e8fa6b64d291207d5fdc6b9fa08a8183ee` |
| `M` | `.docs/c2b-durable-development-state.md` | `0644` | 1,887,232 | `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5` |
| `M` | `.docs/rw0-c1-durable-evidence.md` | `0644` | 14,370 | `3507dca630a103a8ba54f643b662183371ae8d76333d721a91ba6e716eb9f93b` |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | `0644` | 55,944 | `d3fdc11e379cf7bad3bd547c6cc848abdaaa145e0e11ef6058cb7cec9bb29b54` |
| `??` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | `0644` | 58,936 | `f14c09460a5ce3eb3a5aa1e0820975c7d8d1542fa002fd69bd6cb17774add04f` |
| `??` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | `0644` | 103,312 | `fae9fdcb5c3367ecfbdd40a8febfb571c2aebac8ef504a7ca07566688ce5bac1` |

All seven must be regular non-symlink files.

Require:

- exactly five tracked modifications;
- exactly two untracked files;
- zero staged files;
- zero unmerged files;
- zero additional modified, added, deleted, renamed, type-changed, or untracked
  paths.

The following file must remain exact:

`AGENTS.md`

- bytes: `60,530`
- SHA-256:
  `c12a3449e761728f2093c19bb30134c54994b045843313471a6d715b648355a6`

Protected current surfaces must remain byte-identical to HEAD:

- every `src/` path;
- every existing tracked test;
- all migrations;
- `src/ge_nwp_coordinator/sqlite_migration.py`;
- transaction, reader, writer, StateStore, WriterSession, and package-export
  source;
- `.docs/authority-boundaries.md`;
- `.docs/software-development-progression-boundary.md`;
- migrations 0001–0004 and their catalog identities.

Migration `0005` must remain absent.

A path, classification, type, mode, size, or SHA mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

## Deterministic binary-patch corroboration

Independently construct the complete binary patch by processing the seven paths
in the table order.

For each tracked path:

`git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- <path>`

For each untracked path:

`git diff --no-index --binary --full-index --no-ext-diff --no-textconv -- /dev/null <path>`

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate the exact stdout bytes in table order.

Expected V2 candidate:

- bytes: `176,730`
- SHA-256:
  `dddd32e0d1f1ce83144491cf84952c2da3ee9c219a0981d7e362ec0b70749d99`

The per-file receipts and live Git status are primary provenance. An unresolved
binary-patch mismatch is a provenance mismatch.

## Repair-transition corroboration

The current V2 repair claims that only these two paths changed from the prior
blocked candidate:

1. `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
   - old: 43,962 bytes /
     `29b6b13bdd6cd363bf42e82bac944766b60fc17c74f76f7faeb02630ca74457e`
   - current: 58,936 bytes /
     `f14c09460a5ce3eb3a5aa1e0820975c7d8d1542fa002fd69bd6cb17774add04f`

2. `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
   - old: 75,415 bytes /
     `aaf7952c2fbae387ff383f7ec1dfbc99c8aa20f916f44bb1d3ef44fd806f01d0`
   - current: 103,312 bytes /
     `fae9fdcb5c3367ecfbdd40a8febfb571c2aebac8ef504a7ca07566688ce5bac1`

The other five candidate paths must exactly match the receipts above.

This transition information is corroborating evidence only. The live seven-path
candidate is the audit target.

## Audit posture

This is an independent audit, not implementation validation.

Permitted:

- read-only Git inspection;
- static documentation, source, migration, and test inspection;
- read-only Python and AST parsing with `PYTHONDWRITEBYTECODE=1`;
- test execution in a private external local clone;
- temporary hostile copies outside the live repository;
- at most three bounded read-only explorer subagents with self-contained
  prompts.

Prohibited:

- editing, formatting, cleaning, or repairing live repository files;
- staging, committing, pushing, or modifying a PR;
- remote contact;
- sibling-repository inspection;
- modifying the ignored live cache;
- importing repository modules in the live checkout;
- opening or mutating an operator or product-state database;
- running migrations;
- installing dependencies;
- starting services;
- generating client-visible artifacts.

Temporary audit data must remain outside the repository and be removed at
closeout. Record its cleanup disposition.

## Source-of-truth posture

Apply the repository’s authority hierarchy:

- Git owns commit, tree, blob, and ref facts.
- `AGENTS.md` routes repository composition and contract authority.
- `.docs/` owns current and target contract semantics within each document’s
  declared scope.
- `.docs/autonomous-software-development-operating-model.md` is the
  authoritative composition/current-status record.
- source and migrations implement current behavior and durable
  representation.
- tests are executable evidence and drift guards, not an independent semantic
  owner.
- reports and generated artifacts are evidence only.

The repaired C2 document is intended to be the single owner of an accepted
future semantic contract. It must not claim that the future reducer or durable
decision owner is currently implemented.

Classify findings as:

- authority/contract drift;
- semantic defect;
- documentation/supersession defect;
- test-adequacy defect;
- provenance mismatch;
- validation defect;
- artifact/security concern;
- report-only uncertainty.

## Recommended explorer structure

At most three bounded read-only explorers may be used.

### Explorer 1 — semantic and source-provenance audit

Inspect:

- all five matrix-owner result/reason grammars;
- current-source metadata and evaluator branches;
- productive versus halt-only profiles;
- global no-write precedence;
- model recommendation non-authority.

### Explorer 2 — test-causality and hostile audit

Inspect:

- source/human/machine three-way binding;
- fixed versus adaptive expectations;
- scalar-leaf mutation coverage;
- terminal/native/converted halt-only paths;
- earlier-block conflict precedence;
- structural guard hostiles.

### Explorer 3 — authority and documentation audit

Inspect:

- single-owner authority;
- current-versus-future status;
- append-only C2B treatment;
- latch, terminal, physical-persistence, runtime, migration, and public
  nonimplementation claims.

The parent must independently inspect central evidence and reconcile all
explorer findings.

## Required inspection

Read in full or through all relevant current and superseding sections:

- `AGENTS.md`
- `README.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/architecture.md`
- `.docs/authority-boundaries.md`
- `.docs/software-development-progression-boundary.md`
- `.docs/c2b-durable-development-state.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/c2a-first-slice-semantic-protocol-contract.md`
- `.docs/durable-state-model.md`
- `.docs/sqlite-operations-and-recovery.md`
- `.docs/sqlite-threat-model.md`

Inspect the current source owners without modifying them:

- `src/ge_nwp_coordinator/_post_execution_evidence_values.py`
- `src/ge_nwp_coordinator/_post_execution_policy_values.py`
- `src/ge_nwp_coordinator/_rw0_c_decision_input_values.py`
- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_development_effect_row_values.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- current RW0-C1 replay/recovery owners;
- current transition-controller and writer-session contracts;
- package-root exports, `StateStore`, and `WriterSession`.

Inspect:

- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- all post-execution pure-owner tests;
- architecture, operating-model, progression, C2B, C1, remote-phase,
  migration, runtime-nonauthority, and nonimplementation tests relevant to the
  tranche.

## Audit question 1 — authority and current-versus-future truth

Verify that:

- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` remains the
  one future reducer owner;
- the operating model remains composition/status authority;
- architecture and the other changed documents route to the owner without
  claiming implementation;
- C1 is current merged implementation;
- C2 reducer, command, writer, latch, terminal, recovery family, physical
  persistence, and migration treatment remain future;
- no current durable decision writer, migration 0005, production caller, public
  export, receipt family, or runtime behavior is claimed;
- the C2B addition remains append-only and creates no second current owner;
- untouched authority and progression documents remain compatible.

A competing authority or implementation overclaim is blocking.

## Audit question 2 — independently derive the exact matrix grammars

Do not trust the owner document, embedded machine block, or test constants.

Independently derive the accepted result/reason pairs from current source
metadata and evaluator behavior for these exact owners:

1. `standing_policy`
2. `risk_lane`
3. `decision_time_authority`
4. `global_stop`
5. `source_effect_ceiling`

The repair reports:

- `standing_policy`: 17 pairs;
- `risk_lane`: 12 pairs;
- `decision_time_authority`: 16 pairs;
- `global_stop`: 6 pairs;
- `source_effect_ceiling`: 17 pairs;
- total: 68 pairs.

Treat those numbers as claims to verify, not acceptance facts.

For every owner, independently record:

- every exact `permit / reason` pair;
- every exact `deny / reason` pair;
- every exact `unknown / reason` pair;
- every exact `conflict / reason` pair;
- which permit is governed;
- which permit is halt-only;
- whether the source evaluator can emit every declared pair;
- whether any current source pair is missing from the contract;
- whether the contract adds a foreign or impossible pair.

Specifically verify that:

```text
risk_lane / unknown / policy_status_unknown
```

is valid, while these are invalid:

```text
risk_lane / unknown / policy_currentness_unknown
risk_lane / deny / global_stop_active
```

Any missing, extra, foreign, unreachable, or cross-owner pair is blocking.

## Audit question 3 — source, human, and machine three-way equality

The owning document contains human-readable semantics and an embedded
machine-readable contract.

Require exact set equality among:

1. the independently source-derived owner-specific grammar;
2. the human-readable owner/result/reason tables;
3. the machine-readable owner/result/reason grammar;
4. the independently fixed expectations in the contract test.

Require:

- total pair count equality;
- exact per-owner counts;
- exact pair membership;
- exact owner provenance;
- no global substitute reason pool;
- no test-local `NONPERMIT_REASONS`-style convention;
- no pair interpreted only through undocumented test logic;
- no normative machine field without a human counterpart;
- no human normative rule without a machine counterpart;
- no unused, decorative, or tautological normative leaf.

Changing or removing one representation alone must fail.

## Audit question 4 — scalar-leaf mutation coverage

Codex reports that every normative scalar leaf has an independent mutation
control.

Independently enumerate every normative scalar leaf in the machine contract.

Require a complete coverage map:

```text
machine-contract JSON pointer
→ direct positive assertion
→ one-premise hostile test
→ expected exact failure boundary
```

Require:

- no uncovered leaf;
- no duplicate coverage masking a missing leaf;
- no leaf whose hostile merely changes parameter count;
- no hostile that accepts any failure instead of the intended failure;
- no expected answer derived from the mutated representation itself.

Sample execution is insufficient when the candidate claims exhaustive scalar
coverage. Reconstruct the complete map.

## Audit question 5 — productive and halt-only profile taxonomy

Independently verify the contract’s two profiles.

Canonical productive profile:

```text
applicability = governed
governed_effect_class = author_candidate
```

Canonical halt-only profile:

```text
applicability = halt_only
governed_effect_class = null
```

Require exact rejection taxonomy:

- productive wrong applicability, effect class, owner, profile binding, or
  foreign pair:
  `matrix_conflict`
- exact owner conflict pair on any entry:
  `matrix_conflict`
- final halt-only deny, unknown, malformed/foreign non-conflict pair, wrong
  applicability, or wrong effect class:
  `halt_only_matrix_contract_conflict`

A productive profile mismatch must never receive the halt-only rejection class.

Independently execute one hostile for every taxonomy boundary.

## Audit question 6 — global no-write precedence

Verify the reducer pipeline enforces:

1. complete basis grammar and identity validation;
2. complete five-owner matrix inventory and owner/profile/pair validation;
3. any basis conflict, exact matrix conflict, profile conflict, foreign pair,
   or owner mismatch → no-write;
4. currentness and V14/V15 reduction;
5. productive-entry evaluation when V14/V15 gives a conclusive productive
   candidate, even if an earlier block reason already exists;
6. block-summary selection only after all no-write gates;
7. final halt-only verification;
8. model recommendation evaluation last.

No-write must globally outrank every block summary.

Independently test at least:

- stale currentness + each owner’s exact conflict pair → no-write;
- unknown currentness + each owner’s exact conflict pair → no-write;
- validation nonconclusive + each owner’s exact conflict pair → no-write;
- review nonconclusive + each owner’s exact conflict pair → no-write;
- stale currentness + productive deny → block with
  `decision_basis_not_current`, while retaining matrix evidence;
- unknown currentness + productive unknown → block with
  `decision_basis_not_current`, while retaining matrix evidence.

A condition equivalent to:

```python
and not block_reasons
```

must not suppress matrix validation or productive evidence evaluation.

## Audit question 7 — every halt-only route

Every final `program_terminal_reject` or `post_execution_program_block` must
independently verify all five exact owner-specific halt-only permits.

Audit these routes separately:

1. direct terminal reject;
2. native block from stale currentness;
3. native block from unknown currentness;
4. native block from validation nonconclusive;
5. native block from review nonconclusive;
6. converted block from productive deny;
7. converted block from productive unknown.

For every route and matrix owner, require causal negatives for the applicable
cases:

- exact conflict pair;
- deny;
- unknown;
- foreign owner reason;
- wrong result/reason pairing;
- wrong applicability;
- wrong governed-effect class.

A bypass of any one route must make the permanent test module fail.

## Audit question 8 — independently reproduce bypass mutants

In temporary external copies, independently construct at least these semantic
mutants:

1. bypass terminal-reject halt-only verification;
2. bypass native-block halt-only verification;
3. bypass converted-block halt-only verification;
4. skip productive matrix evaluation when currentness already created a block
   reason;
5. allow a foreign owner/result/reason pair;
6. classify productive profile mismatch with the halt-only rejection;
7. convert an unrecognized model recommendation to no-write.

Run the contract module against every mutant.

Require:

- each mutant fails;
- the failure reaches the intended contract test;
- parameter counts do not merely shrink;
- the test does not fail only because of unrelated formatting or syntax.

Codex reports these four implementation-time mutants were caught:

- terminal halt bypass: 10 failures;
- native-block halt bypass: 40 failures;
- earlier-block conflict suppression: 10 failures;
- unrecognized-model no-write regression: 1 failure.

Reproduce those conclusions independently and extend them to the additional
mutants above.

## Audit question 9 — model recommendation non-authority

Independently verify the current recognized mapping:

```text
accept_candidate → candidate_acceptance
repair_candidate → candidate_repair
replan → attempt_selecting_replan
terminal_reject → program_terminal_reject
block → post_execution_program_block
```

With every authoritative input fixed:

- recognized equal recommendation:
  `consistent / mapped_branch_equals_authoritative_branch`
- recognized unequal recommendation:
  `inconsistent / mapped_branch_differs_from_authoritative_branch`
- out-of-vocabulary recommendation:
  `inconsistent / model_recommendation_unrecognized`

An isolated unrecognized recommendation must not create:

- no-write;
- block;
- terminal reject;
- another branch;
- matrix conflict;
- currentness conflict.

A malformed or absent complete proposal family may remain an invalid basis.
Distinguish that from an isolated recommendation-token mutation.

## Audit question 10 — matrix inventory and order

Independently require the exact ordered owner inventory:

1. `standing_policy`
2. `risk_lane`
3. `decision_time_authority`
4. `global_stop`
5. `source_effect_ceiling`

Require permanent failure for:

- omission;
- addition;
- duplication;
- reordering;
- substitution;
- owner-name alias;
- pair moved from one owner to another.

Removing one owner or pair must fail a fixed inventory assertion and must not
merely reduce generated test cases.

## Audit question 11 — fixed versus adaptive expectations

Determine whether the repaired suite maintains real independence among:

1. current-source AST extraction;
2. fixed auditor-independent expectations;
3. human-document parsing;
4. machine-contract parsing;
5. generic interpretation;
6. fixed finite expected outcomes;
7. hostile mutation expectations.

Block if:

- source extraction becomes its own expected answer;
- human representation derives expected machine values;
- machine representation derives expected human values;
- parsed contract data supplies its own expected reducer result;
- a removed source pair or matrix owner silently reduces test count;
- two test-local interpreters merely compare with each other;
- hostile tests assert only that “something failed.”

## Audit question 12 — structural guards

Inspect the recursive production-source guard.

It must scan:

`src/ge_nwp_coordinator/**/*.py`

For `ast.Import`, require full `alias.name`.

For `ast.ImportFrom`, require:

- `node.module`;
- resolution of `node.level` against the importing module’s package;
- every possible imported module formed from resolved base plus `alias.name`;
- support for:
  - `from package import module as alias`;
  - `from . import module as alias`;
  - nested packages.

Independently create external hostile source trees containing:

```python
from ge_nwp_coordinator import _sqlite_rw0_c2_decision as x
```

```python
from . import _sqlite_rw0_c2_decision as x
```

and:

```text
src/ge_nwp_coordinator/internal/_sqlite_rw0_c2_decision.py
```

Require each hostile to fail at the intended structural boundary.

Also require structural proof of:

- migrations exactly 0001–0004;
- no migration 0005;
- no RW0-C2 source/SQLite writer module;
- no package-root export;
- no new public StateStore method;
- no new public WriterSession method;
- no production caller;
- no service, worker, runtime, Git, ES, Bridge, provider, process, filesystem,
  or network integration.

Filename or substring scans alone are insufficient where AST/path structure is
available.

## Audit question 13 — preserved reducer semantics

Verify that the V2 repair did not reopen or drift:

- currentness:
  - conflict → no-write;
  - stale → block;
  - unknown → block;
  - current → continue;
- exact V14/V15 projections;
- validation/review reducer:
  - conflict first;
  - nonconclusive → block;
  - otherwise terminal > replan > repair > accept;
- exact five branches;
- exact migration-0002 kind/variant mapping;
- all five version-advancing;
- `cancel` and `redeliver` excluded;
- block-summary precedence:
  1. `decision_basis_not_current`
  2. `candidate_evidence_nonconclusive`
  3. `productive_branch_not_permitted`
- exact separation among no-write, durable block, and recovery-unresolved;
- caller expected branch as conflict assertion only;
- model and caller non-authority;
- abstract latch dependency;
- terminal and RW0-D/E separation;
- physical persistence as a later freeze.

## Audit question 14 — latch, terminal, and physical nonimplementation

Verify that the owner freezes only an abstract future latch interface:

- exact available preimage;
- preassigned consumed postimage;
- inclusion in command digest and recovery selector;
- atomic decision+latch commitment on acceptance;
- no-write on latch mismatch;
- replay without a second latch mutation;
- decision+latch committed-family recovery;
- no mutation for nonaccept branches;
- accept writer remains uncallable before a separate latch freeze.

Require no:

- table;
- migration;
- row grammar;
- reader;
- writer;
- source module;
- StateStore/WriterSession method;
- public export;
- production caller;
- current implementation claim.

Verify terminal outcome and RW0-D/E remain distinct future seams.

Verify migration `0005` remains absent and bounded-hybrid persistence remains a
future physical-contract question.

## Audit question 15 — documentation and supersession

Verify:

- C1 remains current merged implementation;
- C2 reducer/latch/terminal/persistence remain future;
- operating model remains composition/status authority;
- architecture points to the semantic owner without claiming implementation;
- remote-phase map distinguishes C1 from C2;
- C2B remains append-only and creates no competing reducer owner;
- untouched authority/progression documents remain compatible;
- no changed document reports the V2 contract test as production behavior.

## Independent validation

Construct a private external local clone from committed HEAD without remote
contact.

Overlay exactly the seven live candidate files after verifying all receipts.

Run serially with:

- `PYTHONDONTWRITEBYTECODE=1`
- `PYTHONPATH=.:src`
- pytest cache disabled;
- external `--basetemp`.

At minimum run:

1. repaired contract module;
2. hostile-only selection;
3. matrix-pair selection;
4. terminal halt-only selection;
5. native-block halt-only selection;
6. converted-block halt-only selection;
7. stale/unknown conflict and earlier-block precedence selection;
8. model selection;
9. structural selection;
10. architecture, operating-model, and progression tests;
11. remote-phase tests;
12. relevant C2B/C1/migration/runtime/nonimplementation suites;
13. complete repository suite;
14. `git diff --check`;
15. both new-file whitespace checks;
16. CR, trailing-whitespace, and final-newline checks;
17. source, migration, existing-test, and protected-document preservation;
18. artifact/cache scans.

Implementation-reported reference results:

| Selection | Reported result |
|---|---|
| Contract module | `1059 passed` |
| `-k hostile` | `520 passed, 539 deselected` |
| `-k matrix_pair` | `140 passed, 919 deselected` |
| Terminal halt-only | `40 passed, 1019 deselected` |
| Native-block halt-only | `160 passed, 899 deselected` |
| Converted-block halt-only | `80 passed, 979 deselected` |
| Earlier-block/currentness conflict | `40 passed, 1019 deselected` |
| `-k model` | `4 passed, 1055 deselected` |
| `-k structural` | `3 passed, 1056 deselected` |
| Architecture/operating/progression | `85 passed` |
| Remote phase | `195 passed` |
| Relevant C2B/C1/migration/runtime/nonimplementation | `1718 passed` |
| Complete suite | `7243 passed, 3 warnings` |

Reproduce rather than assume them.

The only expected warnings are the existing Python 3.13 multi-threaded
`fork()` deprecations from unchanged B2C writer-session tests.

Any other warning, changed count, or failure must be investigated.

## Live cache treatment

Do not mutate the live ignored cache.

At audit opening:

- record the exact ignored path set;
- record file types, modes, sizes, and SHA-256 values;
- compute a deterministic repository-relative inventory digest.

At closeout, require exact byte equality with the opening inventory.

The implementation report’s cache digest is evidence only unless its exact
algorithm is independently reconstructed. Equality within this audit is the
required condition.

## Final provenance

After deleting audit-created temporary material, reverify:

- exact seven-path status;
- exact file types, modes, sizes, and hashes;
- exact binary-patch size and SHA;
- zero staged and unmerged paths;
- no additional changed or untracked path;
- exact `AGENTS.md`;
- unchanged source tree;
- unchanged existing tracked tests;
- unchanged protected documents;
- migrations exactly 0001–0004;
- no migration 0005;
- unchanged ignored-cache inventory;
- no audit-created repository artifact.

Run the complete receipt calculation twice and require identical output.

## Severity and verdict rules

Any of the following is blocking:

- provenance mismatch;
- missing or extra owner/result/reason pair;
- human/machine/source disagreement;
- foreign or unreachable pair accepted;
- uncovered normative scalar leaf;
- bypassable terminal/native/converted halt-only path;
- suppressed matrix conflict;
- model recommendation changing branch/admission;
- wrong profile rejection taxonomy;
- adaptive test corpus;
- structural guard bypass;
- authority conflict or current-implementation overclaim;
- physical/runtime/public scope widening;
- validation mismatch not attributable to the audit environment.

### Accept

Use only when no unresolved High- or Medium-severity finding remains:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance authorizes only a separate commit/publication gate for the exact
seven audited paths.

It does not authorize:

- source implementation;
- migration `0005`;
- durable decision writing;
- acceptance-latch implementation;
- terminal-outcome implementation;
- runtime activation;
- public API widening;
- the later physical-persistence implementation.

### Block

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_AUDIT_BLOCKED`

### Provenance mismatch

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Inline report structure

Return:

1. primary verdict;
2. exact baseline and candidate provenance;
3. repair-transition and binary-patch reconciliation;
4. inspection scope and limits;
5. authority/current-versus-future audit;
6. independently derived owner-specific matrix grammar;
7. source/human/machine equality audit;
8. scalar-leaf mutation coverage audit;
9. profile and rejection-taxonomy audit;
10. global no-write precedence audit;
11. all halt-only routes audit;
12. independent mutant results;
13. model non-authority audit;
14. fixed-versus-adaptive test audit;
15. structural guard audit;
16. preserved reducer/latch/terminal/physical-boundary audit;
17. documentation and supersession audit;
18. independent validation results;
19. final live provenance;
20. severity-ranked findings;
21. exact next boundary;
22. required non-actions;
23. final token.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TRACKED_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
```

A successful audit should be followed by a bounded commit/publication gate for the exact seven audited paths. After that merge, the next architecture tranche remains the separate acceptance-latch owner freeze.

**Sources:** Codex’s V2 repair closeout in the current turn; the prior independent audit that established the six blocking findings and prescribed the seven-path repair boundary. :chatgpt-content-reference{index="1"}

**Confidence:** High that the V2 candidate is ready for a fresh adversarial re-audit; no acceptance confidence is assigned until the 68-pair source provenance, all halt-only routes, conflict precedence, model non-authority, scalar-leaf coverage, and structural guards are independently reproduced.
