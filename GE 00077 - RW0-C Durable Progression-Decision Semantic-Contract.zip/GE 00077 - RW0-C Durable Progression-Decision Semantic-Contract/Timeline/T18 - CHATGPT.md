# Disposition

**Accept the independent audit’s `BLOCKED` verdict. Do not stage or commit the V2 candidate.**

The audit reproduced the exact baseline, seven-path candidate, per-file receipts, and binary patch. It found no authority drift, implementation overclaim, source/migration change, public-surface widening, or provenance mismatch. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The complete suite also reproduced at **7,243 passed with the three expected warnings**. Passing validation is therefore not the issue. :chatgpt-content-reference{index="2"}

The remaining blockers are substantive:

1. The contract freezes 68 metadata-declared matrix pairs, but only **45 are reachable through the accepted current value/evaluator/relation call graph**. The tests compare metadata, human prose, machine data, and fixed constants to one another without proving actual evaluator reachability. :chatgpt-content-reference{index="3"}
2. Productive-matrix evaluation can still be skipped when currentness has already created a block reason; the exact forbidden mutant passed all 1,059 tests. :chatgpt-content-reference{index="4"}
3. A halt-only entry can use the same owner’s productive permit and still pass. :chatgpt-content-reference{index="5"}
4. The current structural guard is still name-driven. A differently named nested writer module bypassed it. :chatgpt-content-reference{index="6"}
5. Model evaluation occurs before the acceptance-latch gate and is not exhaustively checked for every branch/recommendation pairing. :chatgpt-content-reference{index="7"}
6. Scalar-leaf mutation checks do not require the exact JSON Pointer or semantic boundary. :chatgpt-content-reference{index="8"}
7. Three reported pytest selector/count claims were not reproducible. :chatgpt-content-reference{index="9"}

The audit’s successor boundary is correct: one more **two-file documentation/test repair**, followed by a fresh audit. No source, migration, writer, latch, terminal, or runtime work is authorized. :chatgpt-content-reference{index="10"}

## Engineering decision: separate metadata vocabulary from accepted reducer inputs

The source metadata’s 68 pairs are an over-approximation. The future durable reducer must accept only pairs currently reachable through valid source construction, evaluator control flow, and required relation calls.

The repaired owner should therefore distinguish:

- **45 currently emittable matrix pairs**: valid reducer inputs.
- **23 metadata-only unreachable pairs**: recorded as current source limitations, never valid matrix entries, and rejected as `matrix_conflict` if injected.
- A later source tranche may deliberately make one of those 23 reachable, but that requires source changes and a corresponding contract update. The documentation/test tranche must not assume that expansion now.

### Accepted 45-pair grammar

| Owner | Currently emittable exact pairs |
|---|---|
| `standing_policy` | `permit/halt_only_policy_not_applicable`; `deny/policy_revoked`; `deny/branch_not_allowed`; `deny/risk_lane_not_allowed`; `deny/effect_class_not_allowed`; `unknown/policy_status_unknown`; `unknown/policy_currentness_unknown`; `permit/policy_permits` |
| `risk_lane` | `permit/halt_only_risk_not_applicable`; `deny/policy_revoked`; `deny/required_lane_mismatch`; `unknown/policy_status_unknown`; `permit/risk_lane_permits` |
| `decision_time_authority` | `conflict/snapshot_or_phase_mismatch`; `conflict/parent_or_fence_identity_mismatch`; `conflict/support_conflict`; `permit/halt_only_authority_not_applicable`; `deny/authority_denied`; `deny/authority_revoked`; `deny/attempt_fence_expired`; `deny/effect_fence_expired`; `deny/authority_grant_expired`; `deny/authority_observation_expired`; `deny/effect_class_not_allowed`; `unknown/authority_status_unknown`; `unknown/family_status_unknown`; `unknown/revocation_status_unknown`; `permit/authority_verified_current` |
| `global_stop` | `permit/halt_only_stop_checked`; `deny/global_stop_active`; `permit/global_stop_clear` |
| `source_effect_ceiling` | `conflict/snapshot_lineage_or_fence_mismatch`; `conflict/proposal_evidence_conflict`; `permit/halt_only_ceiling_not_applicable`; `deny/proposal_evidence_noncompliant`; `deny/attempt_fence_expired`; `deny/effect_fence_expired`; `deny/authority_grant_expired`; `deny/authority_observation_expired`; `deny/effect_class_not_allowed`; `deny/source_effect_exceeds_current_attempt`; `deny/source_effect_exceeds_current_effect`; `deny/source_effect_exceeds_current_authority`; `unknown/current_authority_unknown`; `permit/source_effect_within_current_ceilings` |

### Metadata-only unreachable 23

These remain visible as a non-normative reachability ledger:

```text
standing_policy
  conflict/policy_identity_conflict                 no evaluator branch
  conflict/evaluator_profile_mismatch               no evaluator branch
  conflict/support_conflict                         no evaluator branch
  deny/policy_not_yet_valid                         accepted relation precludes
  deny/policy_expired                               valid construction precludes
  deny/audience_mismatch                            no evaluator branch
  deny/repository_mismatch                          no evaluator branch
  deny/path_scope_mismatch                          no evaluator branch
  deny/ceilings_exceeded                            no evaluator branch

risk_lane
  conflict/risk_source_conflict                     no evaluator branch
  conflict/policy_identity_conflict                 no evaluator branch
  conflict/evaluator_profile_mismatch               no evaluator branch
  conflict/support_conflict                         no evaluator branch
  deny/policy_not_yet_valid                         accepted relation precludes
  deny/policy_expired                               valid construction precludes
  deny/risk_lane_not_allowed                        accepted relation precludes

decision_time_authority
  conflict/profile_mismatch                         no evaluator branch

global_stop
  conflict/snapshot_or_stop_identity_mismatch       valid construction precludes
  conflict/profile_mismatch                         no evaluator branch
  unknown/global_stop_unknown                       valid construction precludes

source_effect_ceiling
  conflict/profile_mismatch                         no evaluator branch
  conflict/support_conflict                         valid construction precludes
  unknown/proposal_evidence_unknown                 valid construction precludes
```

These conditions remain fail-closed at constructor, relation, profile, or evaluator admission. They do not become durable matrix entries.

# Complete replacement Codex prompt

Resume the **same parent-only workspace-write conversation**. No attachments, subagents, or generated artifacts are required.

```text
# Governed Execution Coordinator — RW0-C Durable Decision Branch Contract Repair V3

## Objective

Repair the uncommitted RW0-C durable progression-decision semantic-contract
candidate after its V2 independent audit BLOCK.

This remains a two-file documentation-and-contract-test repair.

Only these files may change from their exact opening bytes:

1. `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
2. `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`

The other five candidate documents must remain byte-identical.

Do not modify source, migrations, existing tracked tests, schemas, readers,
writers, transaction code, StateStore, WriterSession, package exports, public
APIs, or runtime behavior.

Return one substantive inline closeout report. Do not generate or attach an
external report, manifest, package, or freeze artifact.

## Repository and committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- tree: `9e69d4a517b482704c159958abc2f90ed3cdcfd8`
- sole parent: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- subject: `feat: implement RW0-C post-execution pure owners`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged and unmerged paths
- no active Git operation or index lock

Do not fetch or contact remotes.

## Exact opening candidate

Require exactly these seven regular mode-`0644` paths and no other difference
from HEAD:

| Status | Path | Bytes | SHA-256 |
|---|---|---:|---|
| `M` | `.docs/architecture.md` | 42,104 | `d10da9d372c9920ed567f2f705d798cd52f8fb37a9bb94a414f9f4ce193d5494` |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 37,278 | `f78a4e62a2e17e7b2cf511a2eb5638e8fa6b64d291207d5fdc6b9fa08a8183ee` |
| `M` | `.docs/c2b-durable-development-state.md` | 1,887,232 | `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5` |
| `M` | `.docs/rw0-c1-durable-evidence.md` | 14,370 | `3507dca630a103a8ba54f643b662183371ae8d76333d721a91ba6e716eb9f93b` |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 55,944 | `d3fdc11e379cf7bad3bd547c6cc848abdaaa145e0e11ef6058cb7cec9bb29b54` |
| `??` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 58,936 | `f14c09460a5ce3eb3a5aa1e0820975c7d8d1542fa002fd69bd6cb17774add04f` |
| `??` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 103,312 | `fae9fdcb5c3367ecfbdd40a8febfb571c2aebac8ef504a7ca07566688ce5bac1` |

Opening binary patch:

- bytes: `176,730`
- SHA-256:
  `dddd32e0d1f1ce83144491cf84952c2da3ee9c219a0981d7e362ec0b70749d99`

Require exact `AGENTS.md`:

- bytes: `60,530`
- SHA-256:
  `c12a3449e761728f2093c19bb30134c54994b045843313471a6d715b648355a6`

Stop before editing on any mismatch:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIR_V3_BLOCKED`

## Accepted findings and repair boundary

The independent audit established:

- provenance and authority gates pass;
- the seven-path boundary is exact;
- all source, migrations, existing tests, protected documents, public surfaces,
  and runtime surfaces remain unchanged;
- all prescribed suites pass;
- 23 of 68 metadata-declared matrix pairs are unreachable through the accepted
  current value/evaluator/relation call graph;
- tests currently bind to `_META` rather than source behavior;
- productive evaluation can be skipped after an earlier block;
- a same-owner productive permit can be accepted as halt-only;
- a neutral differently named writer module can bypass the structural guard;
- model evaluation occurs before the latch;
- scalar-leaf hostiles do not assert exact JSON-pointer failure boundaries;
- some reported pytest selectors/counts are not reproducible.

Do not reopen reducer architecture, branch scope, V14/V15 projection,
currentness, block precedence, latch abstraction, terminal separation, or
physical nonimplementation.

## 1. Separate metadata declaration from reducer input grammar

The source metadata declares 68 pairs.

The durable reducer contract must accept only the 45 pairs currently emittable
through valid source construction, evaluator control flow, and required
relation calls.

The owner’s human and machine representations must contain two disjoint,
complete inventories:

1. `accepted_emittable_pairs`
2. `metadata_only_unreachable_pairs`

Their union must equal the exact 68 metadata-declared pairs.

Their intersection must be empty.

A metadata-only unreachable pair is not a valid reducer input. If supplied or
forged, it yields `matrix_conflict` and no durable write.

Do not alter source metadata in this tranche.

A later source-and-contract tranche may deliberately make a currently
unreachable pair emittable; no automatic adaptation is allowed.

## 2. Exact accepted 45-pair grammar

### `standing_policy` — 8

```text
permit / halt_only_policy_not_applicable
deny / policy_revoked
deny / branch_not_allowed
deny / risk_lane_not_allowed
deny / effect_class_not_allowed
unknown / policy_status_unknown
unknown / policy_currentness_unknown
permit / policy_permits
```

### `risk_lane` — 5

```text
permit / halt_only_risk_not_applicable
deny / policy_revoked
deny / required_lane_mismatch
unknown / policy_status_unknown
permit / risk_lane_permits
```

### `decision_time_authority` — 15

```text
conflict / snapshot_or_phase_mismatch
conflict / parent_or_fence_identity_mismatch
conflict / support_conflict
permit / halt_only_authority_not_applicable
deny / authority_denied
deny / authority_revoked
deny / attempt_fence_expired
deny / effect_fence_expired
deny / authority_grant_expired
deny / authority_observation_expired
deny / effect_class_not_allowed
unknown / authority_status_unknown
unknown / family_status_unknown
unknown / revocation_status_unknown
permit / authority_verified_current
```

### `global_stop` — 3

```text
permit / halt_only_stop_checked
deny / global_stop_active
permit / global_stop_clear
```

### `source_effect_ceiling` — 14

```text
conflict / snapshot_lineage_or_fence_mismatch
conflict / proposal_evidence_conflict
permit / halt_only_ceiling_not_applicable
deny / proposal_evidence_noncompliant
deny / attempt_fence_expired
deny / effect_fence_expired
deny / authority_grant_expired
deny / authority_observation_expired
deny / effect_class_not_allowed
deny / source_effect_exceeds_current_attempt
deny / source_effect_exceeds_current_effect
deny / source_effect_exceeds_current_authority
unknown / current_authority_unknown
permit / source_effect_within_current_ceilings
```

## 3. Exact metadata-only unreachable 23

Encode each pair with one reachability classification:

- `no_evaluator_branch`
- `valid_construction_precludes`
- `accepted_relation_precludes`

### `standing_policy`

```text
conflict / policy_identity_conflict
  no_evaluator_branch
conflict / evaluator_profile_mismatch
  no_evaluator_branch
conflict / support_conflict
  no_evaluator_branch
deny / policy_not_yet_valid
  accepted_relation_precludes
deny / policy_expired
  valid_construction_precludes
deny / audience_mismatch
  no_evaluator_branch
deny / repository_mismatch
  no_evaluator_branch
deny / path_scope_mismatch
  no_evaluator_branch
deny / ceilings_exceeded
  no_evaluator_branch
```

### `risk_lane`

```text
conflict / risk_source_conflict
  no_evaluator_branch
conflict / policy_identity_conflict
  no_evaluator_branch
conflict / evaluator_profile_mismatch
  no_evaluator_branch
conflict / support_conflict
  no_evaluator_branch
deny / policy_not_yet_valid
  accepted_relation_precludes
deny / policy_expired
  valid_construction_precludes
deny / risk_lane_not_allowed
  accepted_relation_precludes
```

### `decision_time_authority`

```text
conflict / profile_mismatch
  no_evaluator_branch
```

### `global_stop`

```text
conflict / snapshot_or_stop_identity_mismatch
  valid_construction_precludes
conflict / profile_mismatch
  no_evaluator_branch
unknown / global_stop_unknown
  valid_construction_precludes
```

### `source_effect_ceiling`

```text
conflict / profile_mismatch
  no_evaluator_branch
conflict / support_conflict
  valid_construction_precludes
unknown / proposal_evidence_unknown
  valid_construction_precludes
```

The human table and machine representation must state that these 23 are
metadata-declared but not accepted outputs of the current complete call graph.

## 4. Bind tests to actual evaluator/value/relation behavior

Do not treat `_META` as the expected answer.

Maintain five independent layers:

1. fixed accepted expectations;
2. static metadata extraction;
3. production value/evaluator/relation execution;
4. human-document parsing;
5. machine-contract parsing.

### Emittable witnesses

For every one of the 45 accepted pairs:

- construct valid current production values;
- invoke the actual current evaluator;
- pass through the required accepted relation caller where the decision basis
  consumes a relation-owned result;
- observe the exact owner/result/reason pair;
- prove the pair is reachable without monkeypatching or forged output values.

Create a fixed witness ledger:

```text
owner
result
reason
production constructor(s)
production evaluator
relation/action boundary, if any
witness-builder identifier
```

Every accepted pair must have exactly one or more valid witnesses.

Removing an evaluator branch or making a witness unreachable must fail a fixed
count and exact-pair assertion, not reduce parameterization silently.

### Unreachable proofs

For every one of the 23 unreachable pairs, prove its exact boundary:

- `no_evaluator_branch`:
  static control-flow inspection confirms no accepted return path emits the
  pair;
- `valid_construction_precludes`:
  current production construction/invariant validation prevents a valid input
  reaching that output, with the exact current failure boundary asserted;
- `accepted_relation_precludes`:
  the relevant accepted relation/action caller rejects or excludes the state
  before the pair can become an accepted decision-basis entry.

A direct forged pair supplied to the generic contract interpreter must produce
`matrix_conflict`.

The test must not claim universal source reachability merely because a reason
literal appears in `_META`.

## 5. Human, machine, fixed, metadata, and behavior reconciliation

Require:

```text
metadata-declared pairs
=
accepted_emittable_pairs
  union metadata_only_unreachable_pairs

accepted_emittable_pairs
=
production behavior witnesses
=
human accepted-pair table
=
machine accepted-pair inventory
=
fixed accepted expectations
```

Also require:

```text
metadata_only_unreachable_pairs
=
human unreachable ledger
=
machine unreachable inventory
=
fixed unreachable expectations
=
source reachability proofs
```

No global pair pool may substitute for owner-specific provenance.

No accepted or unreachable pair may move between owners without failure.

## 6. Exact scalar JSON-pointer coverage

Enumerate every normative scalar leaf in the final machine contract.

For each leaf:

1. assert the exact positive value at its exact JSON Pointer;
2. mutate only that leaf;
3. require the exact exception boundary:
   `contract drift at <exact-json-pointer>`;
4. assert the reported pointer equals the mutated pointer;
5. reject generic “some contract drift occurred” credit.

Produce an in-test coverage map:

```text
JSON Pointer
→ positive assertion identifier
→ hostile identifier
→ exact expected failure pointer
```

Require exact one-to-one coverage and no duplicate or uncovered pointer.

The final scalar count may change after the 68→45+23 representation repair.
Report the final exact count; do not preserve 411 by inertia.

## 7. Prove productive evaluation after an earlier block

The machine contract and prose must require:

- if V14/V15 yields a conclusive productive candidate, all five productive
  entries are evaluated and retained even when stale/unknown currentness has
  already established a higher-priority block summary;
- matrix conflicts remain global no-write;
- block-summary priority changes only the summary reason, not evidence
  evaluation.

The generic interpreter must return an internal audit trace containing at
least:

```text
basis_validated
matrix_grammar_validated
currentness_reduced
validation_review_reduced
productive_matrix_evaluated      # when a conclusive productive candidate exists
branch_selected
halt_only_matrix_evaluated       # when final branch is halt-only
acceptance_latch_checked          # only when final branch is acceptance
model_consistency_evaluated       # always last when basis remains valid
```

For `productive_matrix_evaluated`, retain:

- provisional productive branch;
- all five owner entries in canonical order;
- exact result/reason pairs.

Tests must assert the trace and retained entries for:

- stale currentness plus productive candidate;
- unknown currentness plus productive candidate;
- currentness block plus productive deny;
- currentness block plus productive unknown;
- currentness block plus exact matrix conflict.

The mutant:

```python
if candidate_branch in matrix["productive_branches"] and not block_reasons:
```

must fail permanent trace/evidence assertions.

## 8. Same-owner productive permit is invalid on halt-only entries

For every halt-only route and every owner, substitute the same owner’s exact
productive permit:

```text
standing_policy:
  permit / policy_permits

risk_lane:
  permit / risk_lane_permits

decision_time_authority:
  permit / authority_verified_current

global_stop:
  permit / global_stop_clear

source_effect_ceiling:
  permit / source_effect_within_current_ceilings
```

Each substitution must produce:

`halt_only_matrix_contract_conflict`

Cover every route:

1. direct terminal reject;
2. stale-currentness block;
3. unknown-currentness block;
4. validation-nonconclusive block;
5. review-nonconclusive block;
6. productive-deny converted block;
7. productive-unknown converted block.

This requires at least 35 direct causal hostiles.

A mutant that accepts same-owner productive permit on a halt-only entry must
fail the permanent module.

## 9. Model evaluation is last

Move model consistency evaluation after every authoritative no-write gate,
including the acceptance-latch check.

The contract evaluation order must be:

1. basis validation;
2. matrix grammar/profile/pair validation;
3. currentness and V14/V15 reduction;
4. productive evaluation when required;
5. branch selection;
6. halt-only verification when required;
7. acceptance-latch validation when acceptance was selected;
8. model recommendation consistency.

If any earlier stage produces no-write, model consistency is not evaluated.

Add trace assertions.

### Exhaustive recommendation behavior

For each of the five authoritative branches and each of the five recognized
recommendations, assert:

- branch remains unchanged;
- exact consistency status;
- exact consistency reason.

For each authoritative branch, an out-of-vocabulary recommendation yields:

```text
inconsistent / model_recommendation_unrecognized
```

without changing admission or branch.

For acceptance, combine every recognized and unrecognized recommendation with
a failing latch precondition and assert:

- latch no-write wins;
- `model_consistency_evaluated` is absent from the trace.

## 10. Replace structural name filtering with exact source nonimplementation proof

The current tranche changes no source.

Add a temporary, explicit nonimplementation barrier in the contract test:

1. recursively enumerate every regular file beneath
   `src/ge_nwp_coordinator`;
2. exclude only ignored cache/bytecode artifacts;
3. canonicalize records containing repository-relative path, file type, mode,
   byte size, and SHA-256;
4. compare the complete manifest count and SHA-256 to a fixed baseline derived
   from the current committed source tree;
5. fail on:
   - any new source file, regardless of name;
   - any deleted source file;
   - any modified source byte;
   - any nested package/module;
   - any symlink or unsupported type.

The owner document must classify this as a temporary nonimplementation guard
to be deliberately superseded by a future authorized source tranche. It is not
an enduring prohibition on Coordinator development.

Retain semantic AST checks for:

- package-root exports;
- public `StateStore` methods;
- public `WriterSession` methods;
- production imports/callers of the pure-owner modules;
- migration inventory;
- package/runtime integration.

Permanent external hostiles must include:

- a neutral nested module:
  `src/ge_nwp_coordinator/internal/worker.py`;
- a differently named writer:
  `src/ge_nwp_coordinator/internal/_sqlite_rw0_c2_writer.py`;
- modification of an existing neutral source module;
- the prior absolute and relative aliased imports.

Every hostile must fail at the source-manifest or semantic structural boundary.

## 11. Reproducible test selectors and closeout claims

Ensure actual test function names support exact selectors.

At minimum provide uniquely reproducible selections for:

```text
-k source_reachability
-k matrix_pair
-k scalar_pointer
-k halt_only
-k earlier_block
-k model_authority
-k structural_nonimplementation
-k hostile
```

Before reporting counts:

1. run `pytest --collect-only -q` for each selector;
2. record the exact selected node count;
3. run the exact selection;
4. report only the observed command and output.

Do not report generic `-k model` or `-k structural` counts when those
expressions select unrelated tests.

Do not claim a selector that selects zero tests.

## 12. Preserved semantics

Do not reopen:

- V14/V15 projection;
- conflict-first reduction;
- nonconclusive → block;
- `terminal > replan > repair > accept`;
- currentness conflict/no-write, stale/block, unknown/block, current/continue;
- global no-write precedence;
- exact five branches;
- migration-0002 branch mapping and nullability;
- version advancement;
- `cancel` and `redeliver` exclusion;
- block-summary precedence;
- no-write/block/recovery-unresolved separation;
- caller expected branch as conflict assertion only;
- model and caller non-authority;
- abstract acceptance-latch dependency;
- terminal and RW0-D/E separation;
- future bounded-hybrid physical persistence;
- migration `0005` absence.

## Mutation ceiling

Only these two paths may change from their opening bytes:

```text
.docs/rw0-c2-durable-progression-decision-semantic-contract.md
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
```

The other five candidate documents must remain exact.

No existing tracked test may change.

## Validation

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
-p no:cacheprovider
--basetemp=<external path>
```

At minimum run:

1. complete repaired contract module;
2. `-k source_reachability`;
3. `-k matrix_pair`;
4. `-k scalar_pointer`;
5. `-k halt_only`;
6. `-k earlier_block`;
7. `-k model_authority`;
8. `-k structural_nonimplementation`;
9. `-k hostile`;
10. architecture/operating-model/progression tests;
11. remote-phase tests;
12. relevant C2B/C1/migration/runtime/nonimplementation tests;
13. complete repository suite;
14. `git diff --check`;
15. both new-file whitespace checks;
16. source, migration, existing-test, protected-document preservation;
17. artifact/cache scans.

### Required external mutants

In disposable external copies, independently prove failure for:

1. one accepted evaluator pair made unreachable;
2. one unreachable metadata pair moved into accepted inputs;
3. productive evaluation suppressed after earlier block;
4. same-owner productive permit accepted on halt-only;
5. model evaluation moved before latch;
6. exact JSON-pointer assertion weakened to generic drift;
7. neutral nested source module added;
8. differently named writer module added;
9. existing source file modified;
10. matrix pair moved between owners.

Report the intended failure boundary for each mutant.

## Closeout

Report inline:

- opening and closing Git coordinates;
- exact seven-path candidate;
- exact two-file opening-to-closing transition;
- status, mode, bytes, and SHA-256 for all seven paths;
- deterministic binary patch size and SHA-256;
- two independent complete receipt calculations;
- final accepted-pair count and unreachable-pair count;
- exact per-owner pair counts;
- final scalar JSON-pointer count;
- exact selector collection and execution counts;
- external mutant outcomes;
- full validation commands/results;
- source and migration preservation;
- cache/artifact posture;
- unresolved latch and physical-persistence seams;
- all required non-actions.

Do not create an external report or manifest.

## Success token

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIRED_V3_VALIDATED_READY_FOR_REAUDIT`

Success authorizes only another fresh read-only independent audit.

## Blocking token

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_REPAIR_V3_BLOCKED`

## Required non-actions

State:

```text
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TRACKED_TESTS_NOT_MODIFIED
OTHER_FIVE_CANDIDATE_DOCUMENTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
```

The next step after a successful repair is another fresh read-only audit of the exact seven live paths. The acceptance-latch and physical-persistence tranches remain blocked until this semantic contract is accepted.

**Sources:** The V2 independent audit report, which found exact provenance and authority posture but blocked on evaluator reachability, test causality, halt-only validation, structural nonimplementation, model ordering, exact leaf coverage, and report reproducibility. :chatgpt-content-reference{index="11"} :chatgpt-content-reference{index="12"}

**Confidence:** High that the audit block is correct; high that narrowing the reducer to the 45 currently emittable pairs while explicitly retaining the 23 metadata-only unreachable pairs is the narrowest truthful contract repair; high that the proposed two-file boundary addresses every reported finding without reopening source or migration work.
