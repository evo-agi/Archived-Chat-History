# Disposition

**Proceed to a fresh independent re-audit. Do not stage or commit the V3 candidate.**

Codex’s closeout has the correct bounded shape:

- the candidate remains exactly seven paths;
- only the semantic owner and its contract-test module changed from V2;
- the other five candidate documents remained byte-identical;
- all source, migrations, existing tracked tests, protected documents, package exports, and runtime surfaces reportedly remained unchanged;
- the repair directly addresses every item ordered by the prior audit;
- the complete suite reportedly passes with **7,417 tests and the same three expected warnings**.

The previous audit required source-behavior binding, a causal earlier-block trace, same-owner productive-permit halt-only hostiles, generic source-nonimplementation proof, model-after-latch ordering, exact JSON-pointer failures, and reproducible selectors before another audit. :chatgpt-content-reference{index="0"} Codex now claims closure of each item.

That is enough to begin the audit, not enough to accept the contract.

## Primary audit risks

The fresh auditor must independently establish five things that the implementation conversation cannot prove for itself.

First, the **45 accepted pairs** must genuinely be reachable through valid production constructors, evaluators, and required relation/action boundaries. A witness built from the contract’s own accepted-pair table would remain circular.

Second, the **23 unreachable pairs** must fail for their claimed source reason—no evaluator branch, constructor exclusion, or relation exclusion—not merely because the test labels them unreachable.

Third, the test must prove that productive matrices are evaluated and retained even when stale or unknown currentness already supplies the final block-summary reason. The trace, not only the final branch, is contractually significant.

Fourth, every terminal or block route must reject the same owner’s productive permit when it appears in a halt-only slot. This requires all seven routes across all five owners, not only representative cases.

Fifth, the complete source-manifest guard must remain a **temporary tranche guard**, not become an accidental architectural rule that freezes all Coordinator source indefinitely.

## Process deviation

Codex reports that it temporarily moved the pre-existing ignored `__pycache__` tree outside the live repository for validation and restored it byte-exactly. The repair instructions prohibited altering that live cache and directed validation to a clean external clone.

I do not treat that as a pre-audit candidate blocker because:

- the seven candidate bytes are independently identified;
- opening and closing cache manifests reportedly match;
- no source or tracked byte reportedly changed.

The auditor must classify it explicitly as historical process noncompliance, independently reproduce current cache equality, and avoid touching the live cache. Any present cache mismatch or concealed repository effect becomes blocking.

# Fresh independent re-audit handoff

Use a **new parent-led, local, read-only Codex conversation**. Send only the prompt text. Do not attach prior reports, manifests, packages, snapshots, or chat exports.

:chatgpt-content-reference{index="2"}[Download the V3 independent re-audit prompt](sandbox:/mnt/data/Coordinator_RW0_C_Durable_Decision_Branch_Contract_V3_Independent_Reaudit_Prompt.txt)

```text
Filename:
Coordinator_RW0_C_Durable_Decision_Branch_Contract_V3_Independent_Reaudit_Prompt.txt

Size:
29,904 bytes

SHA-256:
4b54a205e7568b031aec80a39dc371794842c6772979c310887ec71738c6d30a

Logical lines:
947

Final newline:
present
```

The prompt requires the auditor to independently verify:

- the exact seven-path candidate and `239,446`-byte binary patch;
- the `45 + 23 = 68` metadata partition;
- all 45 production behavior witnesses;
- all 23 unreachable-source proofs;
- exact source/human/machine/fixed equality;
- all 452 scalar JSON-pointer boundaries;
- productive evaluation after an earlier block reason;
- all 35 same-owner productive-permit halt-only hostiles;
- model evaluation strictly after latch validation;
- the temporary 66-file source-manifest barrier;
- all ten reported external mutants;
- exact selector collection and execution counts;
- the complete `7,417`-test suite;
- current live-cache equality and the historical cache-movement deviation;
- continued absence of migration `0005`, source implementation, a durable writer, latch owner, terminal owner, production caller, public export, and runtime widening.

The success token is:

```text
RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
```

Blocking token:

```text
RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_AUDIT_BLOCKED
```

Provenance mismatch token:

```text
AUDIT_PROVENANCE_MISMATCH
```

Even an `ACCEPT` verdict authorizes only a separate commit/publication gate for the exact seven audited paths. It does not authorize source implementation, migration `0005`, durable decision writing, acceptance-latch implementation, terminal-outcome implementation, runtime activation, public API widening, or physical-persistence implementation.

**Sources:** Codex’s V3 repair closeout pasted in this turn; prior V2 independent audit and its exact successor boundary. :chatgpt-content-reference{index="1"}

**Confidence:** High that the V3 candidate is ready for an adversarial independent audit. No acceptance confidence is assigned until the production witnesses, unreachable proofs, trace semantics, halt-only matrix coverage, source barrier, selectors, and full validation are independently reproduced.
