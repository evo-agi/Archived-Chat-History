The durable progression-decision owner is a plausible next critical-path seam,
but the current reconnaissance handoff repeats the attachment-heavy workflow
that has become a material operating failure.

Please replace the current unexecuted Codex prompt with one complete,
self-contained, repository-first read-only reconnaissance prompt.

Use the current merged repository as the sole source of current contract truth:

- branch `trunk_dev`;
- HEAD `db16de711986ae40a2bb848ed00cdddd3145ee02`;
- owning docs, source, schemas, migrations, and tests in that tree.

Do not require the V11 JSONL package, V11 audit report, or merge receipt as
attachments.

Those artifacts are historical evidence only:

- Git owns the merged commit and tree facts;
- the repository owns current contract semantics;
- the audit report establishes prior acceptance evidence;
- any rule found only in V11 and not adopted into the repository must be
  classified as unadopted historical evidence, not silently imported as a
  current contract.

The reconnaissance objective remains narrow:

1. Determine whether the missing post-execution durable progression-decision
   owner should be one command/result/receipt/recovery contract or a justified
   split.

2. Determine whether the first supported scope is exactly the five current
   non-cancel post-execution branches.

3. Determine whether existing `development_decisions`,
   `development_mutation_receipts`, private row values/readers, and the current
   transaction controller can retain the complete safe decision basis needed
   for exact replay and committed recovery.

4. Compare migration-free reuse, additive migration 0005, and a bounded hybrid.
   Do not select the smallest diff by default; select the narrowest truthful
   representation.

5. Separate:
   - durable progression decision ownership;
   - future acceptance-latch ownership;
   - future terminal-outcome ownership;
   - RW0-D/E runtime and physical mechanics.

6. Identify the exact current owner of every mutable fact and every fact that
   remains external evidence.

Inspect at minimum:

- `AGENTS.md`;
- `.docs/rw0-c1-durable-evidence.md`;
- `.docs/rw0-remote-worker-contact-phase-entry.md`;
- `.docs/software-development-progression-boundary.md`;
- `.docs/authority-boundaries.md`;
- the six merged post-execution pure-owner modules;
- `_rw0_c_decision_input_values.py`;
- `_development_decision_row_values.py`;
- migration 0002 and migration 0004;
- relevant private readers;
- the mutation transaction controller and writer session;
- the post-execution boundary tests and current nonimplementation tests.

Use at most three bounded read-only explorers. No mutation, tests, migration,
installation, service, or external effect.

Return one substantive report inline in the Codex response with exact
repo-relative path-and-line evidence.

Do not generate a JSON freeze manifest or require me to transport additional
artifacts. A later accepted implementation contract may be written into the
owning repository; this reconnaissance itself is evidence only.

The report must end with one disposition:

- `RW0_C_DURABLE_DECISION_OWNER_ARCHITECTURE_READY`
- `RW0_C_DURABLE_DECISION_OWNER_SPLIT_REQUIRED`
- `RW0_C_DURABLE_DECISION_OWNER_BLOCKED`

Do not issue an implementation prompt. Do not use unsupported numerical
confidence percentages.

Also append a compact continuation capsule of no more than 1,000 words covering:

- current merged capability;
- selected recommendation;
- rejected alternatives;
- unresolved seams;
- exact baseline;
- next permitted decision.

Return your engineering assessment followed by one complete replacement Codex
prompt. Do not provide a delta or ask me to combine prompts.
