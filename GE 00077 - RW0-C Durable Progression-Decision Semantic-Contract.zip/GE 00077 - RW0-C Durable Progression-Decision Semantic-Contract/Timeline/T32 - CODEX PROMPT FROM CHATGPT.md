# Governed Execution Coordinator — RW0-C Durable Decision Branch Contract Commit and PR Publication Gate

## Objective

Commit and publish the exact independently accepted seven-path RW0-C durable
progression-decision semantic-contract candidate through the repository-required
pull-request route.

This is a **commit and PR-publication gate** over already audited bytes. It
authorizes only:

1. exact local and remote pre-effect verification;
2. staging exactly the seven audited paths;
3. staged-blob equality and staged-byte validation;
4. one exact local commit;
5. one plain push of that exact commit to one exact remote topic branch;
6. creation or exact reuse of one open, non-draft pull request into `trunk_dev`;
7. read-only verification of the commit, branch, and PR;
8. one inline closeout report.

It does **not** authorize candidate repair, amendment, rebase, merge, auto-merge,
force-push, tag, release, deployment, source implementation, migration `0005`,
durable decision writing, acceptance-latch implementation, terminal-outcome
implementation, runtime activation, public API widening, RW0-D/E behavior, or
Execution Substrate changes.

Do not create or attach external reports, receipts, manifests, or packages.
Return the complete closeout inline.

## Repository and exact baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required local baseline before any effect:

- branch: `trunk_dev`
- HEAD: `db16de711986ae40a2bb848ed00cdddd3145ee02`
- tree: `9e69d4a517b482704c159958abc2f90ed3cdcfd8`
- sole parent: `a3ff0b7f4f0c2378c2962e24612d605489b51638`
- subject: `feat: implement RW0-C post-execution pure owners`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged and unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Required remote repository:

`evo-agi/Governed-Execution-Coordinator`

Required remote base before publication:

`refs/heads/trunk_dev = db16de711986ae40a2bb848ed00cdddd3145ee02`

Do not fetch tags.

## Accepted audit disposition

The exact candidate passed a fresh independent audit with:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

The audit found:

- no unresolved High-, Medium-, or Low-severity finding;
- exact candidate provenance;
- exact witness-label provenance;
- exact JSON-pointer checker integrity;
- exact retained productive evidence;
- unconditional complete matrix-stage validation;
- all required mutants caught at their intended boundaries;
- `1,286` contract tests passed;
- `7,470` repository tests passed with the three expected unchanged warnings;
- no semantic-owner, source, migration, public, or runtime widening.

This gate must verify the live bytes independently. The audit token is
authorization context, not a substitute for byte verification.

## Exact seven-path candidate

The live worktree must contain exactly these paths and no other tracked or
untracked difference from HEAD:

| Status | Path | Mode | Bytes | SHA-256 |
|---|---|---|---:|---|
| `M` | `.docs/architecture.md` | `0644` | 42,104 | `d10da9d372c9920ed567f2f705d798cd52f8fb37a9bb94a414f9f4ce193d5494` |
| `M` | `.docs/autonomous-software-development-operating-model.md` | `0644` | 37,278 | `f78a4e62a2e17e7b2cf511a2eb5638e8fa6b64d291207d5fdc6b9fa08a8183ee` |
| `M` | `.docs/c2b-durable-development-state.md` | `0644` | 1,887,232 | `77bf3d3c6ed710da669db7fa4353f46f3d1e9b4e09636918046d16d94ed962e5` |
| `M` | `.docs/rw0-c1-durable-evidence.md` | `0644` | 14,370 | `3507dca630a103a8ba54f643b662183371ae8d76333d721a91ba6e716eb9f93b` |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | `0644` | 55,944 | `d3fdc11e379cf7bad3bd547c6cc848abdaaa145e0e11ef6058cb7cec9bb29b54` |
| `??` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | `0644` | 68,944 | `92f1d2b34f9cf2486102edf31de142acc07db9a116f64d64212ca497d0a554c1` |
| `??` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | `0644` | 239,999 | `9b0751f55b238c55130b6481bbea34454c5ed8866212f5546baa6e5af1b0fa19` |

All seven must be regular, non-symlink files.

Require exact `AGENTS.md`:

- bytes: `60,530`
- SHA-256:
  `c12a3449e761728f2093c19bb30134c54994b045843313471a6d715b648355a6`

The implementation-reported seven-path binary patch is corroborating evidence:

- bytes: `327,443`
- SHA-256:
  `b76ee8a85bc12250f8d56cd8eb15f48c35b5ee7c18acd7dd1772ed76c6a3890f`

Per-file receipts, path set, file classifications, and Git blobs are the primary
identity. If the aggregate patch differs while every primary coordinate is
exact, investigate and report it; do not silently substitute another candidate.
Any unresolved byte ambiguity blocks the gate.

## Current remote policy to re-observe

At gate design time, live GitHub evidence showed:

- remote `trunk_dev` at the required baseline commit;
- active repository ruleset `18957283` applies to `refs/heads/trunk_dev`;
- pull requests are required;
- required approving reviews: `0`;
- review-thread resolution is required;
- no bypass actor exists;
- the current user cannot bypass;
- allowed merge method: `squash` only;
- repository auto-merge is disabled;
- the exact topic branch below does not exist;
- no open PR exists for that topic branch.

Re-observe the policy and refs before any local mutation. Do not rely on the
design-time observation if live state differs.

## Exact publication coordinates

Remote topic branch:

`codex/rw0-c-durable-decision-branch-contract-v1`

Pull-request base:

`trunk_dev`

Pull-request title:

`docs: freeze RW0-C durable decision branch contract`

No alternate branch, base, title, or commit is authorized.

## Mandatory stop conditions

Stop before staging with:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_COMMIT_PUBLICATION_GATE_BLOCKED`

if any of the following is true:

- local baseline differs;
- live path set, classification, type, mode, size, or SHA differs;
- a staged or unmerged path already exists;
- another changed or untracked path exists;
- an active Git operation or lock exists;
- `AGENTS.md` differs;
- any source, migration, existing tracked test, protected authority/progression
  document, public surface, or runtime file differs from HEAD;
- remote `trunk_dev` differs from the required baseline;
- the current active rules require a publication method incompatible with this
  prompt;
- the exact remote topic branch exists at a different object;
- an existing PR for the exact topic branch has incompatible base/head/title
  coordinates;
- authentication cannot safely perform the exact authorized effects;
- staging, validation, or publication would require editing bytes, rebasing,
  merging, amending, force-pushing, or selecting another branch.

Do not repair any mismatch inside this engagement.

## Gate A — local provenance and protected-surface verification

Before remote contact or staging:

1. Verify the physical repository root and every baseline coordinate.
2. Verify the complete live status is exactly five tracked modifications and two
   untracked files from the table above.
3. Verify every file type, mode, byte size, and SHA-256.
4. Verify exact `AGENTS.md`.
5. Verify:
   - all `src/` paths equal HEAD;
   - every existing tracked test equals HEAD;
   - migrations remain exactly `0001`–`0004`;
   - migration `0005` is absent;
   - `.docs/authority-boundaries.md` equals HEAD;
   - `.docs/software-development-progression-boundary.md` equals HEAD;
   - package exports, StateStore, WriterSession, readers, writers, transactions,
     and runtime surfaces equal HEAD.
6. Record the ignored live-cache inventory without importing through, moving,
   deleting, or rewriting it.
7. Reproduce the seven-path aggregate patch as corroboration.
8. Run the complete receipt calculation twice and require byte-identical output.

## Gate B — live remote-policy and ref observation

Remote read access is authorized here.

1. Read the exact `origin` identity without printing credentials.
2. Observe:
   - remote `refs/heads/trunk_dev`;
   - remote topic branch, if any;
   - active rulesets applying to `trunk_dev`;
   - repository merge settings;
   - existing PRs for the exact topic branch.
3. Require remote `trunk_dev` to equal:
   `db16de711986ae40a2bb848ed00cdddd3145ee02`.
4. Topic branch:
   - absent: publication may proceed later;
   - present at the eventual exact new commit: reuse after local commit
     verification;
   - present at another object: block.
5. Existing PR:
   - none: creation may proceed later;
   - one open, non-draft PR with exact eventual head and base: reuse after
     commit verification;
   - incompatible open/closed/merged PR: block.

Do not stage if the remote base or policy is incompatible.

## Gate C — exact staging

Stage exactly the seven paths from the fixed table.

After staging require:

- exactly seven stage-0 index entries;
- every index mode `100644`;
- five modifications and two additions;
- no deletion, rename, type change, symlink, executable, submodule,
  intent-to-add, or conflict stage;
- no path outside the seven-path set is staged;
- no unstaged, untracked, or unmerged path remains;
- `git diff --cached --check` passes.

For each path:

1. read the staged blob with Git object commands;
2. verify staged blob byte size and SHA-256 against the audited receipt;
3. verify staged blob bytes equal the pre-stage working-tree bytes;
4. record staged blob OID.

Capture and record the staged tree. Do not commit if any staged coordinate
differs.

## Gate D — staged-byte validation

Create a private external local-only clone from the exact baseline commit. Do
not contact a remote.

Populate the clone’s seven candidate paths exclusively from the live index
blobs. Verify every copied file before testing.

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
-p no:cacheprovider
--basetemp=<external path>
```

Required validation:

1. contract module:

```text
python3 -m pytest -q -p no:cacheprovider   --basetemp=<external path>   tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
```

Expected: `1,286 passed`.

2. architecture/operating-model/progression:

```text
python3 -m pytest -q -p no:cacheprovider   --basetemp=<external path>   tests/test_architecture_contracts.py   tests/test_autonomous_software_development_operating_model.py   tests/test_software_development_progression_boundary.py
```

Expected: `85 passed`.

3. exact remote phase:

```text
python3 -m pytest -q -p no:cacheprovider   --basetemp=<external path>   tests/test_remote_worker_pre_execution_planning_contract.py   tests/test_rw0_remote_contact_phase_entry_contract.py
```

Expected: `969 passed`.

4. complete repository:

```text
python3 -m pytest -q -p no:cacheprovider   --basetemp=<external path>
```

Expected: `7,470 passed, 3 warnings`.

The only accepted warnings are the unchanged Python 3.13 multi-threaded `fork()`
deprecations from the three B2C writer-session tests identified by the audit.

After testing require:

- all seven clone candidate files still match staged blobs;
- no bytecode, pytest cache, database, journal, WAL/SHM, lock, build, archive,
  symlink, or unsupported artifact remains outside `.git`;
- the live index and worktree remain unchanged;
- live ignored cache remains byte-identical to opening;
- `git diff --cached --check` still passes.

Remove the external validation root at closeout.

Any failure blocks the gate. Do not repair candidate bytes.

## Gate E — exact commit

Create exactly one commit. Do not amend.

Exact subject:

`docs: freeze RW0-C durable decision branch contract`

Exact body, including final LF:

```text
Adopt the accepted future semantic contract for the RW0-C durable
post-execution progression-decision reducer and its causal contract verifier.

This change adds no production reducer, durable writer, migration, latch,
terminal outcome, public export, runtime behavior, RW0-D/E behavior, or
Execution Substrate behavior.

Audit: RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
```

Exact body SHA-256 over UTF-8 body bytes with final LF:

`2ee0d81f3edc2f6713776ceae9b67eeb8b7213b6eea8d753150b837eb9bb0249`

Do not add a co-author, signoff, generated trailer, or alternate audit token
unless Git applies a repository-mandated signature outside the message bytes.

After commit require:

- exactly one parent, equal to
  `db16de711986ae40a2bb848ed00cdddd3145ee02`;
- exact subject and body;
- exact seven-path diff;
- commit tree equal to the staged tree;
- every committed path mode and blob OID equal its staged entry;
- no unrelated path changed;
- local branch remains `trunk_dev`;
- repository is clean;
- local divergence from `origin/trunk_dev` is `1 ahead / 0 behind`;
- ignored-cache inventory remains exact.

If commit creation succeeds but a later publication effect fails, preserve the
commit and report the partial effect. Do not amend or delete it.

## Gate F — exact topic-branch publication

Immediately before the push, re-observe remote `trunk_dev`, topic branch, and
applicable rules.

Require remote `trunk_dev` still equals the commit parent.

If the topic branch is absent, perform exactly one plain, non-force push:

```text
git push origin <exact-new-commit>:refs/heads/codex/rw0-c-durable-decision-branch-contract-v1
```

Forbidden:

- direct push to `trunk_dev`;
- force or force-with-lease;
- deletion;
- tags;
- alternate branch;
- retries with changed coordinates.

If the topic branch already equals the exact new commit, reuse it and do not
push again.

Afterward require the remote topic branch to equal the exact local commit.

If branch publication fails, do not retry or create a different branch. Return:

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_COMMITTED_PUBLICATION_NOT_COMPLETED`

## Gate G — exact PR creation or reuse

Inspect existing PRs for the exact topic branch.

If one open, non-draft PR already has:

- head branch:
  `codex/rw0-c-durable-decision-branch-contract-v1`;
- head OID: exact new commit;
- base: `trunk_dev`;

reuse it after exact verification.

If none exists, create one normal, non-draft PR.

Exact title:

`docs: freeze RW0-C durable decision branch contract`

Exact body:

```markdown
## Summary

- adopt the accepted future semantic contract for the RW0-C durable post-execution progression-decision reducer
- freeze deterministic no-write, block, branch-selection, matrix, result, receipt, replay, and recovery semantics
- add a causal contract verifier bound to current production value/evaluator/relation behavior
- preserve the separate future acceptance-latch, terminal-outcome, and physical-persistence seams

## Verification

- independent audit: `RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`
- exact staged and committed blobs matched the audited seven-path receipts
- contract verifier: `1,286 passed`
- full repository: `7,470 passed, 3 expected warnings`

## Explicit non-claims

This change does not add a production reducer, durable decision writer, migration `0005`, acceptance-latch owner, terminal-outcome owner, production caller, public export, runtime behavior, RW0-D/E behavior, or Execution Substrate behavior.
```

Do not add labels, reviewers, assignees, milestones, projects, merge queue, or
auto-merge unless GitHub applies metadata automatically.

Do not merge the PR.

## Gate H — final verification

After PR creation or reuse, verify:

- PR state: `OPEN`;
- draft: `false`;
- merged: `false`;
- base: `trunk_dev`;
- head branch: exact topic branch;
- head OID: exact new commit;
- exact title;
- body contains the exact audit token, validation counts, and non-claims;
- auto-merge disabled;
- remote topic branch equals exact commit;
- remote `trunk_dev` remains at the baseline;
- local `trunk_dev` remains at the exact new commit;
- local upstream remains `origin/trunk_dev`;
- local divergence remains `1/0`;
- local repository is clean;
- ignored-cache inventory equals opening;
- no gate-created temporary material remains.

Capture immediate checks/reviews/mergeability only as transient projection. Do
not wait indefinitely and do not merge.

## Inline closeout

Return:

1. outcome token;
2. opening and final local Git coordinates;
3. opening and final remote refs;
4. ruleset and publication-policy observation;
5. exact seven-path opening receipt;
6. staged tree and all seven staged blob OIDs;
7. exact validation commands and results;
8. commit ID, tree, parent, subject, and body SHA-256;
9. topic-branch publication result;
10. PR number, URL, state, draft/base/head/title/body verification;
11. final local divergence and cleanliness;
12. ignored-cache opening/closing equality;
13. cleanup result;
14. every non-action and any partial effect.

Do not create an external report or receipt.

## Outcome tokens

### Full success

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_COMMITTED_AND_PR_OPENED`

### Commit exact, publication incomplete

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_COMMITTED_PUBLICATION_NOT_COMPLETED`

### Topic branch exact, PR incomplete

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_BRANCH_PUBLISHED_PR_NOT_COMPLETED`

### Blocked before commit

`RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_COMMIT_PUBLICATION_GATE_BLOCKED`

Never claim rollback of a successful commit or remote branch creation unless a
separately authorized rollback actually occurred.

## Required non-actions

State:

```text
CANDIDATE_BYTES_NOT_CHANGED
REPAIRS_NOT_PERFORMED
COMMIT_NOT_AMENDED
REBASE_NOT_PERFORMED
MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
DIRECT_PUSH_TO_TRUNK_DEV_NOT_PERFORMED
FORCE_PUSH_NOT_PERFORMED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
SEMANTIC_OWNER_DOCUMENT_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TRACKED_TESTS_NOT_MODIFIED
OPERATOR_OR_PRODUCT_DATABASE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
ACCEPTANCE_LATCH_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_GENERATED
```
