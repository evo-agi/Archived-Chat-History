# Disposition

**Accept the audit’s `BLOCKED` verdict. Do not stage or commit the candidate.**

This is now a narrowly bounded **verifier-integrity failure**, not a semantic-contract failure. The resumed audit established `PROVENANCE_BASELINE_READY`, reproduced the exact seven files and corrected `312,049`-byte patch, reconciled the live cache, and found no High or Medium defect in the semantic matrix, authority split, documentation, migration boundary, production relations, or nonimplementation posture. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The underlying contract survived the substantive audit:

- the `44 accepted / 24 excluded / 68 total` partition was independently rederived;
- the production witness outputs and all excluded-pair boundaries were substantively correct;
- pipeline ordering, duplicate-key rejection, halt-only routes, model-after-latch ordering, source-manifest protection, structural import guards, and current-versus-future documentation all passed;
- the complete repository validation reproduced at **7,450 passed with three expected warnings**. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

## Remaining defects

Exactly four Medium test-adequacy defects remain:

1. **Witness-label provenance is not causal.** Replacing labels observed from returned production entries with labels copied from fixed expectations still leaves all 1,266 tests green. The builders continue to execute, so call-count tests do not detect the self-authorship. :chatgpt-content-reference{index="8"}

2. **The exact JSON-pointer checker is not protected.** Weakening exact equality to prefix matching still leaves the complete contract module green. :chatgpt-content-reference{index="9"}

3. **Retained productive evidence does not bind exact reasons.** Owner order, result, and count are protected, but replacing every retained reason with a fabricated constant escapes. :chatgpt-content-reference{index="10"}

4. **Complete permit-reason validation is not causally fixed to the matrix-validation stage.** Making permit-reason checks conditional on later semantic evaluation still passes, allowing malformed unselected entries to evade the documented pre-currentness validation stage. :chatgpt-content-reference{index="11"}

The two explicitly required mutants that escaped are confirmed in the audit’s independent mutant table. :chatgpt-content-reference{index="12"}

## Repair boundary

The semantic owner is accepted as written. The next repair should therefore modify **only**:

```text
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
```

The following six paths must stay byte-identical:

```text
.docs/architecture.md
.docs/autonomous-software-development-operating-model.md
.docs/c2b-durable-development-state.md
.docs/rw0-c1-durable-evidence.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/rw0-c2-durable-progression-decision-semantic-contract.md
```

This one-file repair should add integrity checks around the existing verifier—not another reducer, another witness system, or another copy of the semantic contract.

The audit prescribed the same narrow successor boundary: prove observed labels originate in returned entries, add the missing pointer-prefix case, bind all retained productive reasons, and prove complete matrix reason validation happens before currentness and branch selection. :chatgpt-content-reference{index="13"}

# V5 verifier-repair handoff

Resume the **same parent-only workspace-write Codex conversation**. Attach nothing.

:chatgpt-content-reference{index="15"}[Download the complete V5 verifier-repair prompt](sandbox:/mnt/data/Coordinator_RW0_C_Durable_Decision_Branch_Contract_Verifier_Repair_V5_Prompt.txt)

```text
Filename:
Coordinator_RW0_C_Durable_Decision_Branch_Contract_Verifier_Repair_V5_Prompt.txt

Size:
17,400 bytes

SHA-256:
57c2d1286e8206ca5b4423ab3af19899c5c369cefe047b52ee19fa1c68eafe6a

Logical lines:
528

Final newline:
present
```

The prompt requires:

- a runtime sentinel proving witness labels are extracted from returned production entries;
- an AST guard preventing the observed-label path from consulting fixed expectations or parsed accepted-pair inventories;
- a prefix-specific pointer-check integrity test;
- exact retained productive evidence, including every owner-specific reason;
- unconditional full-matrix permit-reason validation before currentness and V14/V15 reduction;
- six external mutants targeting those exact defects;
- exact, module-scoped selector collection and execution;
- full repository validation;
- proof that only the one untracked test file changed;
- no movement or modification of the live ignored cache.

Success token:

```text
RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_VERIFIER_REPAIRED_V5_VALIDATED_READY_FOR_REAUDIT
```

Blocking token:

```text
RW0_C_DURABLE_DECISION_BRANCH_CONTRACT_VERIFIER_REPAIR_V5_BLOCKED
```

A successful repair authorizes only another fresh independent read-only audit. It does not authorize semantic-document changes, source implementation, migration `0005`, durable decision writing, latch or terminal implementation, staging, commit, publication, or runtime activation.

**Sources:** Resumed V4 independent audit report. Its provenance, semantic, authority, documentation, and validation gates passed; only four Medium verifier-integrity findings remain. :chatgpt-content-reference{index="14"}

**Confidence:** High that `BLOCKED` is correct; high that the candidate semantics should remain unchanged; high that a one-file verifier repair is the narrowest sufficient next step.
