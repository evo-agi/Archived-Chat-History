Chat GE 00130 was started, after we merged tranche `RW0 Normal Terminal Closure`. It should have been started sooner, to be fair, because it addresses the overlaps between coordinator and control plane. Chat GE 00071 agreed as well, and it created `Timeline/T0 - USER PROMPT FROM CHATGPT.md`.

Hmm... Maybe we should reuse `Timeline/T10 - USER.md` whenever more than one file is used for a handoff?

Uh oh... Only after `Timeline/T21 - CHATGPT.md` did I realize I did not capture the prompts at all. I didn't put the zips in `Generated/` either. Alright. I went back and downloaded the zips between `Timeline/T21 - CHATGPT.md` and `Timeline/T10 - USER.md`.

This tranche is becoming more than what I could remembered. I checked with Chat GE 00071 before running the zip from `Timeline/T27 - CHATGPT.md`. The reaction is captured in `Commentary/CHATGPT (GE 00071) - after T27.md`. I then confirmed my desire to have lifecycle-related functionalities. That caused Chat GE 00071 to create `Timeline/T28 - USER PROMPT FROM CHATGPT.md`.

`Timeline/T31 - CHATGPT.md` did not request a snapshot...

`Timeline/T38 - CHATGPT.md` did not request a snapshot...

It's not clear if T32-T38 should be considered to be a new tranche.
