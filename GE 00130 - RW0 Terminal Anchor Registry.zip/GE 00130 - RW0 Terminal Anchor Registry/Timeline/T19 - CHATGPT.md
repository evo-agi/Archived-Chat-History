## Verdict

Codex stopped correctly with `REPAIR_SCOPE_REPLAN_REQUIRED`. This is a **test-fixture scope problem**, not a production, migration, or terminal-authority problem.

Two corrections matter:

1. **A fresh re-audit is not required yet.** No repository bytes changed, the canonical manifest remains `da2c06d...f61d92`, and there is no new candidate to audit. The existing blocked audit still governs these bytes. Fresh audit becomes mandatory only after a repair changes the candidate. Governed Execution Codex Subage…
2. **The previous repair prompt was overconstrained.** It required a second distinct program and broadly distinct predecessor coordinates. The audit actually requires two coherent terminal families in one exact-0008 database that can expose cross-family mixing. It does not require two completely independent program universes. Legitimately shared program, singleton, or ancestor rows may be the correct construction. The original T2 finding was about independent coordinate-mapping proof, not duplicating every predecessor fact. Pasted text

The likely solution is one of:

- extend one coherent predecessor closure with a second legitimate phase/decision/family;
- parameterize a bounded test-only fixture with deterministic identities;
- add a dedicated multi-family exact-0008 test fixture.

The exact choice and touched paths should be source-grounded before another write turn. Production code, migration SQL, catalog, and documentation remain frozen.

## Next action

Run one **parent-only, read-only fixture replan** in the original implementation Codex conversation. It will:

- enumerate the reported 20 uniqueness collisions;
- classify each as shared ancestor, singleton, or family-specific identity;
- remove the unnecessary “distinct program” requirement;
- choose one exact construction strategy;
- freeze the smallest test-only touched-path manifest;
- define validation and provenance for the later repair.

The active provenance chain remains on the exact v1 recipe; changing recipe versions would require an explicit re-baseline and fresh audit. Governed Execution Provenance G…

**Prompt to execute:**

`RW0_TERMINAL_ANCHOR_EVOLUTION_T2_R1_FIXTURE_REPLAN_PROMPT.md`

RW0_TERMINAL_ANCHOR_EVOLUTION_T2_R1_FIXTURE_REPLAN_HANDOFF.zip[Download the complete fixture-replan handoff ZIP](sandbox:/mnt/data/RW0_TERMINAL_ANCHOR_EVOLUTION_T2_R1_FIXTURE_REPLAN_HANDOFF.zip)

ZIP SHA-256:

```text
779224ddeb4942ca5ea8cf71863caa45ef9d341da874c6018e975e644afaabfb
```

After `T2_R1_FIXTURE_REPLAN_READY`, the same implementation conversation can receive a new workspace-write prompt authorizing only the exact test-helper scope it identifies. Only then—after changed bytes, validation, and new provenance—does a fresh independent re-audit become appropriate.

**Sources:** Codex scope-replan report supplied in your message; original independent-audit T2 finding: Pasted text; repair and re-audit lifecycle: Governed Execution Codex Subage…; provenance recipe-selection rule: Governed Execution Provenance G….

**Confidence:** 0.99 that no re-audit is warranted before new bytes exist; 0.96 that the next step is test-fixture reconnaissance rather than production replanning; 0.82 that a shared-ancestor multi-family construction will avoid the reported collisions.
