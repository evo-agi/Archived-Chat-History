## Provisional engineering judgment

**Do not design a Coordinator–Control Plane integration.** Design a **Control Plane containment and retirement boundary**, harvest useful mechanics, and build Coordinator’s operating loop directly against Execution Substrate.

The architecture should distinguish three layers:

1. **Bounded present reality:** CP may still own workflow truth inside the maintained MVP/demo path and remain an active ES consumer. The earlier MVP freeze explicitly assigned CP objective/task progression, review gates, checkpoints, escalation, and Temporal shell state for that bounded path. mvp
2. **Accepted target:** Coordinator becomes the sole durable development-program progression authority. ES remains execution admission/runtime authority; Git owns repository objects and refs; CI and validating runtimes own observed validation results. CP, reports, connectors, and model sessions do not become program truth. Pasted text
3. **Transition and retirement:** CP remains only where a named demo, compatibility, preservation, or retirement obligation requires it. There should be no CP–Coordinator state synchronization, no default migration of CP history, and no new permanent dependency on CP. Pasted text

This is not a transfer of CP’s state machine into Coordinator. It is a re-derivation of selected operational mechanics behind Coordinator-native contracts.

Coordinator already has a meaningful durable foundation: program/work state, guarded initialization, proposal recording, evidence admission, artificial-offline execution and review, physical P0/P1 progression, and normal terminal closure. Its material gaps are active-cancel closure, live supplier/custody, production provider and worker invocation, reliable ES routing, publication effects, scheduling, recovery, and automatic successor launch. Pasted text

### Architecture rule

For any CP capability, the default decision order should be:

1. Is this still a bounded current compatibility obligation?
2. Is it merely historical evidence?
3. Is there a useful implementation mechanic independent of CP semantics?
4. Can that mechanic be re-derived behind a Coordinator-owned contract?
5. Does adopting it create a permanent dependency on demised CP?

Only the fourth outcome should normally enter the Coordinator roadmap.

---

## Highest-risk authority overlaps

| Overlap | Primary risk | Provisional disposition |
|---|---|---|
| CP Temporal workflow state vs Coordinator durable program state | Two durable sources decide what work is current, blocked, complete, or resumable | No synchronization or shared ownership. CP authority remains confined to existing CP runs; Coordinator owns new autonomous-development programs |
| CP `on_hold` vs Coordinator `block` | Similar labels conceal different resumability and closure semantics | No direct mapping; inspect transitions and obligations independently |
| CP completion/failure/rejection vs Coordinator accept/repair/replan/terminal reject/block | Technical attempt completion can be mistaken for semantic acceptance | No direct mapping; derive a typed translation only at evidence-ingestion boundaries, not by state equivalence |
| CP retry/revise vs Coordinator repair/replan | Attempt-level retry can be confused with cognitive plan revision or successor creation | Reuse retry mechanics only; Coordinator owns the progression decision |
| CP workspace/checkpoint state vs Coordinator capsule/candidate custody | Filesystem snapshots could become an accidental authority for the accepted candidate | Re-derive preservation mechanics under explicit candidate, capsule, and provenance contracts |
| CP cancellation workflow vs Coordinator request/closure and ES lifecycle facts | Premature terminalization, lost cancellation, or contradictory state | Coordinator owns cancellation intent and durable progression; ES owns execution-side observation; closure requires an explicit join |
| CP provider/Codex adapters vs Coordinator worker/provider boundary | CP process behavior could silently define Coordinator’s production worker contract | Re-derive adapters behind Coordinator-owned invocation, custody, result, and failure contracts |
| CP Git or publication actions vs Coordinator policy and Git truth | Multiple writers or reports treated as publication authority | Git remains object/ref authority; publication effects must be Coordinator-policy-bound and independently evidenced |
| CP ES summaries vs ES lifecycle and retained-result facts | A CP projection could override execution authority | Consume ES facts directly; CP records remain historical or compatibility evidence |
| CP operator interventions vs Coordinator progression decisions | A UI action could become an alternate program authority | Reuse guarded-write mechanics only; all actions must resolve against Coordinator-owned durable state |
| CP notifications/escalations vs program state | Delivery or acknowledgement can be mistaken for progression truth | Delivery remains an effect with outbox/idempotency evidence, never program authority |
| CP experiments/comparisons vs Coordinator work graph | Demo wrappers could harden into the permanent development model | Reference only unless a later Coordinator-native experiment contract is justified |

The most dangerous overlap is **not code duplication**. It is accidentally preserving CP’s domain model through Temporal workflow reuse, state migration, adapter reuse, or UI-driven interventions.

---

## Likely reusable CP mechanics

These are provisional classifications. Reconnaissance must verify that each mechanic actually exists and is separable from CP semantics.

| CP surface | Provisional classification | Treatment |
|---|---|---|
| Temporal workflow supervision as an architectural model | **REUSE CONCEPT ONLY** | Study durable timers, replay, activity supervision, and recovery patterns; do not import CP workflow histories or state vocabulary |
| Temporal-specific workflow definitions and state machines | **DEMO/REFERENCE ONLY** | Useful evidence of prior behavior, not Coordinator program truth |
| Task-attempt execution adapters | **RE-DERIVE MECHANIC BEHIND COORDINATOR CONTRACT** | Place behind a Coordinator worker invocation and result boundary |
| Codex invocation and process supervision | **RE-DERIVE MECHANIC BEHIND COORDINATOR CONTRACT** | Preserve process isolation, output capture, cancellation, and failure handling without CP task semantics |
| Workspace preservation and restoration | **RE-DERIVE MECHANIC BEHIND COORDINATOR CONTRACT** | Bind to explicit capsule/candidate identity and provenance |
| Delayed terminalization after cancellation | **RE-DERIVE MECHANIC BEHIND COORDINATOR CONTRACT** | Likely high-value for active-cancel closure and Coordinator–ES joining |
| Effect/outbox deduplication | **RE-DERIVE MECHANIC BEHIND COORDINATOR CONTRACT** | Use for notifications, worker calls, ES submit, and publication effects without making the outbox authoritative |
| Notification delivery | **RE-DERIVE MECHANIC BEHIND COORDINATOR CONTRACT** | Delivery evidence only; no progression transition based solely on notification state |
| Escalation delivery | **RE-DERIVE MECHANIC BEHIND COORDINATOR CONTRACT** | Separate the decision to block/escalate from the effect that informs an operator |
| Guarded intervention and stale-write fingerprints | **RE-DERIVE MECHANIC BEHIND COORDINATOR CONTRACT** | Potential basis for Coordinator-native operator actions |
| Operator console and read-model composition | **REUSE CONCEPT ONLY** | Build a new Coordinator read model; do not make CP’s snapshot schema permanent |
| WebAuthn/passkey step-up | **RE-DERIVE MECHANIC BEHIND COORDINATOR CONTRACT** | Relevant when Coordinator exposes sensitive operator writes; not a near-term autonomy prerequisite by itself |
| Provider/model adapters | **RE-DERIVE MECHANIC BEHIND COORDINATOR CONTRACT** | Provider invocation must conform to Coordinator’s cognitive and custody boundaries |
| CP-to-ES normal-shell route | **PRESERVE TEMPORARY COMPATIBILITY** | Keep bounded while CP remains a supported demo consumer; do not use CP as Coordinator’s bridge to ES |
| CP experiment/comparison workflows | **DEMO/REFERENCE ONLY** | Preserve as examples unless a real target requirement emerges |
| CP Temporal history, SQLite run state, and old workspaces | **HISTORICAL EVIDENCE ONLY** | Retain only for a named audit, demo, compatibility, or historical obligation |
| Legacy direct orchestration | **RETIRE** | No target role after the bounded compatibility path is no longer needed |
| CP durable-state vocabulary as Coordinator schema | **RETIRE** | Do not copy or map wholesale |
| Exact reuse of Temporal as Coordinator’s durable engine | **UNRESOLVED** | The burden of proof is on adoption; existing Coordinator durability makes a second runtime a material architectural decision |

The attached direction correctly frames the central question as which mechanics can be re-derived, which compatibility edges survive temporarily, and which material is merely historical—not how Coordinator should integrate with CP. Pasted text

---

## Likely compatibility, freeze, and retirement boundary

### Keep runnable temporarily

Only the smallest explicitly named surface:

- the maintained CP MVP/demo route, if a current demo or operator obligation still depends on it;
- CP’s current ES consumer path;
- `control-plane-normal-shell/v1` and associated runtime-profile compatibility until its actual consumers are retired or migrated;
- any bounded tests needed to demonstrate that the frozen route still works.

The historical MVP freeze classifies the normal-shell profile and CP consumption of ES contract, prepare, submit, status, logs, result, and cancel as compatibility edges rather than enduring architecture. mvp mvp

### Keep readable

Preserve as source-grounded reference:

- architecture and invariants;
- state-transition definitions;
- cancellation handling;
- effect/outbox patterns;
- provider and process adapters;
- workspace and checkpoint mechanics;
- operator intervention guards;
- security boundaries;
- representative tests;
- migration and retirement records.

Readable does not mean imported, executed, or supported indefinitely.

### Preserve as cold historical evidence only

Potentially:

- selected Temporal histories;
- selected SQLite state;
- sanitized reports and experiments;
- representative workspaces or artifacts;
- demo recordings and proof summaries.

Preservation needs a named reason. No bulk migration into Coordinator should occur.

### Retirement trigger

CP can move from bounded-runnable to archived/reference-only when all of the following are true:

1. Coordinator has a productive direct route to ES.
2. That route covers reliable submit, response-loss recovery, lifecycle correlation, retained results, cancellation request, and terminal observation.
3. Coordinator has native worker/provider invocation and custody.
4. Required operator interventions have a Coordinator-native read/write surface or are intentionally deferred.
5. No maintained demo or consumer depends on CP.
6. ES has an accepted migration/removal treatment for `control-plane-normal-shell/v1`.
7. Required historical evidence has been inventoried and preserved safely.
8. Docs and contract tests no longer describe CP as a target product or permanent authority.

The repo may remain archived after retirement. Retirement should mean **no product dependency and no feature development**, not necessarily deletion.

---

## Questions reconnaissance must settle

### Baselines and evidence

1. Does each live checkout match the supplied branch, commit, and tree?
2. What unpublished or dirty CP state exists, and is it source work, generated evidence, operator state, or sensitive material?
3. Which CP claims remain current contracts, which are merely maintained demo compatibility, and which are historical?
4. Do Coordinator’s current docs and tests fully reflect the normal-terminal implementation, or do older non-orchestration assumptions still constrain it?

### Semantic ownership

5. What are the exact transition, resumability, and terminality rules for CP `on_hold`, completed, failed, rejected, retry, revise, cancellation, escalation, and finalization?
6. What are the corresponding exact Coordinator rules for accept, repair, replan, terminal reject, block, and the unimplemented active-cancel path?
7. Where would any proposed mapping lose identity, causality, review status, custody, or authority?
8. Which CP records are authoritative only inside a CP workflow, and which are merely projections or evidence?

### Reusable mechanics

9. Which CP mechanics are sufficiently isolated from CP schemas and workflow vocabulary to re-derive?
10. Which apparently reusable components embed hidden assumptions about immutable tasks, operator control, local workspaces, Temporal ownership, or CP finalization?
11. Do cancellation, outbox, workspace, provider, Codex, WebAuthn, and console implementations have reusable boundaries, or are they tightly coupled to CP state?
12. Which existing tests would incorrectly freeze CP semantics if copied or treated as target contracts?

### Coordinator roadmap

13. Is active-cancel terminal closure a self-contained next tranche, or does it require live worker/ES contracts first?
14. What is the minimum production provider and worker boundary that produces a real, custody-bound result without introducing publication authority?
15. What durable scheduler or queue behavior is actually needed for the first autonomous loop?
16. Where should automatic repair/replan successor creation occur, and what evidence must close the predecessor first?
17. What is the minimum operator/read surface needed before direct-local bootstrap can be retired?

### Coordinator–ES roadmap

18. What is the current accepted ES reliable-submit contract, and what blockers remain?
19. What keyed identity should correlate Coordinator work, attempt, effect, ES execution, retained result, and cancellation?
20. What caller-side response-loss recovery is required in Coordinator?
21. What ES-to-Nomad registration uncertainty remains visible to a caller?
22. What is the minimum resolved execution-plan representation Coordinator can submit without importing CP grammar?
23. Which runtime profiles are generic ES contracts, and which are CP-specific compatibility?
24. What exact conditions permit removal or replacement of `control-plane-normal-shell/v1`?
25. Which Coordinator and ES work can proceed independently, and what is their first required integration join?

---

## Read-only Codex reconnaissance prompt

```text
# COORDINATOR–CONTROL PLANE DEMISE RECONCILIATION
# READ-ONLY CROSS-REPOSITORY RECONNAISSANCE

## Objective

Perform one bounded, read-only reconciliation across Governed Execution
Coordinator, the demised Control Plane, and Execution Substrate.

Produce source-grounded findings that determine:

1. which Control Plane responsibilities remain bounded current/demo authority;
2. which Control Plane mechanics are worth re-deriving behind
   Coordinator-native contracts;
3. which CP compatibility edges must remain temporarily;
4. which CP state and artifacts require historical preservation;
5. what can eventually be frozen or retired;
6. the shortest credible Coordinator capability roadmap after normal terminal
   closure; and
7. a separate roadmap for Coordinator consuming Execution Substrate directly.

This is architecture and discussion work only. Do not implement anything.

Do not answer “how should Coordinator integrate with Control Plane?”
Answer:

- which CP responsibilities remain bounded and temporary;
- which mechanics can be re-derived without importing CP semantics;
- which compatibility obligations survive;
- which historical evidence must be retained; and
- how Coordinator reaches direct ES consumption without CP becoming a bridge or
  second source of truth.

## Exact repositories

Coordinator:
  /Users/ds/Repositories/Governed Execution Coordinator/

Control Plane:
  /Users/ds/Repositories/Control Plane/

Execution Substrate:
  /Users/ds/Repositories/Execution Substrate/

## Expected baselines

### Coordinator

Expected current published baseline:
  branch: trunk_dev
  commit: 69fc836dbaa0e2124b427bc9611de2e0fba77040
  tree: 8c3b409d1e0c9013ae519d23016af266b3c38cd8
  parent: 3be0096c163b456c9975326be3eb2c30d2b4bbd1
  subject: docs: correct RW0 normal terminal closure current status (#19)

Normal-terminal source integration anchor:
  commit: 3be0096c163b456c9975326be3eb2c30d2b4bbd1
  tree: bc10382edd1b2c097fc729e4e168d72e710391fe

The current status-only successor is expected to record normal terminal closure as
integrated while preserving older candidate/local-commit passages as historical
evidence.

### Control Plane

Published GitHub main baseline supplied for comparison:
  commit: 2871486a8f4f232e9e363079c9156a010d4a65ca
  tree: 7b5b0e233b709d746d54ea05f5cc9362f5062d95

Do not presume the local checkout equals published main. Identify and separately
label:

- published baseline;
- current local branch and HEAD;
- tracked, staged, untracked, or ignored local overlays where safely observable;
- maintained MVP/demo compatibility;
- historical evidence;
- later target direction.

Do not fetch or contact GitHub.

### Execution Substrate

Expected current published baseline:
  branch: trunk_dev
  commit: 1453e2f33f1c9564ebaade2ef0e71184a4a0e034
  tree: ff1b60430aefbc28c14fecb376ca22e969bfa278

Use ES only to establish current execution contracts, CP compatibility,
reliable-submit status, and the minimum direct Coordinator consumer route.

## Fixed product direction

Control Plane is demised.

That means:

- CP is not a target product;
- CP is not a target peer of Coordinator;
- CP is not a permanent durable-development authority;
- CP is not required in the target autonomous-development topology;
- CP Temporal, SQLite, task, checkpoint, projection, escalation, UI, report,
  session, and artifact state does not become Coordinator program truth;
- no CP–Coordinator dual write or state synchronization is presumed;
- no bulk CP-state migration is presumed;
- no new CP feature work is presumed;
- CP architecture must not survive through inertia.

CP may still contain:

- maintained MVP/demo compatibility;
- temporary ES compatibility obligations;
- useful implementation mechanics;
- useful security or operator-interface patterns;
- historical evidence;
- preservation and retirement obligations.

Coordinator is the intended durable autonomy core.

Execution Substrate remains execution admission/runtime authority, including
runtime-profile compatibility, submission and response-loss recovery, lifecycle
observation, cancellation boundaries, and retained execution results.

Git owns repository object and ref truth.

CI and validating runtimes own observed validation results.

Model reasoning supplies proposals and judgment. Model sessions, ChatGPT state,
CP state, Bridge state, reports, connectors, dashboards, and generated artifacts
are not durable program truth.

## Known Coordinator capability

Treat the following as supplied current-baseline claims to verify against source,
docs, tests, and migrations:

Implemented within bounded private/artificial-offline contracts:

- durable development-program and work state;
- guarded program initialization and author-effect establishment;
- Section 41 pre- and post-execution proposal recording;
- RW0-C1 evidence admission;
- private artificial-offline planner/worker/capsule execution;
- private artificial-offline validation, independent review, and review-model
  closure;
- physical P0 admission-history recording;
- physical P1 five-branch progression decision;
- separate normal terminal closure for:
  accept, repair, replan, terminal_reject, block.

Not currently implemented:

- active-cancel terminal closure;
- qualified live supplier/custody;
- production model/provider invocation;
- production worker or qualified remote contact;
- reliable Coordinator-to-ES execution routing;
- Coordinator-owned Git or publication effects;
- public service, queue consumer, scheduler, or autonomous runtime loop;
- automatic repair/replan successor launch.

Do not report target capabilities as current merely because docs discuss them.

## Current versus target discipline

For every claim, classify it as one of:

- CURRENT OWNING-REPOSITORY CONTRACT
- IMPLEMENTED SOURCE BEHAVIOR
- ACCEPTED TARGET-ONLY CONTRACT
- TEMPORARY COMPATIBILITY EDGE
- HISTORICAL OR DEMO EVIDENCE
- UNPUBLISHED LOCAL OVERLAY
- CHAT-DECIDED STRATEGIC DIRECTION
- INFERENCE
- UNCERTAINTY

State conflicts explicitly. Do not rewrite current contracts into the target and
do not preserve current contracts by inertia when evaluating the target.

A CP workflow may remain authoritative for an existing CP run while CP is still
demised in the target architecture. Preserve that distinction.

## Read-only posture

This entire turn is read-only.

Do not:

- edit, create, delete, rename, format, or regenerate files;
- run tests, services, migrations, workers, workflows, CLIs, or scripts;
- install or update dependencies;
- start or stop Temporal, SQLite-backed services, ES, Nomad, Docker, Vault,
  SPIRE, Codex, or any other runtime;
- contact networks or remote services;
- fetch, pull, checkout, switch branches, reset, clean, stash, rebase, merge,
  cherry-pick, create worktrees, stage, commit, push, or create PRs;
- write temporary files inside any repository;
- unpack or mutate archives;
- inspect secret values, environment files, credential stores, raw WebAuthn
  material, TLS/SPIFFE/Vault/API-key material, or SQLite row contents;
- print sensitive endpoints, tokens, prompts, private logs, or operator data.

Allowed activity is bounded static inspection, such as:

- pwd;
- git rev-parse;
- git branch --show-current;
- git status --short and safe path-level classification;
- git diff and git show for source inspection;
- git ls-files;
- rg, grep, sed, head, tail, cat, find, ls, and stat where they do not expose
  sensitive contents;
- reading tracked docs, source, tests, migrations, schemas, configs, examples,
  and safe text artifacts.

Do not use git fetch or network-backed commands.

If the working tree is dirty, do not alter it. Record safe path names and
classifications. Do not inspect ignored or sensitive contents merely to explain
the dirtiness.

## Baseline verification

For each repository record:

- absolute repository path;
- current branch;
- HEAD;
- tree;
- parent where relevant;
- upstream if locally configured;
- git status --short;
- whether the supplied expected baseline matches;
- whether any local overlay is tracked, staged, untracked, ignored, generated,
  sensitive, or unresolved, to the extent safely knowable.

A baseline mismatch is evidence to report, not permission to change anything.

Continue on a mismatch only when the current local identity can still be clearly
reported and the mismatch does not make authority claims ambiguous. Otherwise
return a partial or blocked result.

Do not claim that a Project snapshot was inspected unless it is actually
available in the local reconnaissance environment and authenticated. State that
snapshot comparison remains unvalidated when applicable.

## Subagent workflow

Use exactly four read-only explorer agents in parallel.

Do not use nested delegation.

Give every explorer a complete self-contained context capsule containing:

- all three repository paths;
- expected baselines;
- fixed product direction;
- authority split;
- current-versus-target classification rules;
- mutation authority: none;
- command restrictions;
- its exact assigned scope;
- required report format.

Do not assume explorer agents inherit this parent prompt.

Make at most one retry if an explorer fails to start.

Do not silently replace a missing required report with parent inference.

Close every explorer before the parent finishes.

### Explorer 1 — Coordinator contract and capability roadmap

Inspect Coordinator, including as applicable:

- AGENTS.md and nested guidance;
- README.md;
- PLANS.md;
- .docs/architecture.md;
- autonomous-development operating model;
- software-development progression boundary;
- worker execution boundary;
- D1/D2 owners;
- post-D2 native proposal admission;
- P0/P1 physical implementation;
- normal terminal closure;
- active-cancel seam;
- provider and live-custody seams;
- repair/replan successor behavior;
- service and transaction boundaries;
- readers, writers, migrations, schemas, commands, tests, examples, and safe
  artifacts relevant to the claims.

Return:

- verified current capability;
- current contracts that constrain the next step;
- target-only capability;
- stale docs or tests;
- exact missing operating capabilities;
- candidate tranche boundaries;
- dependencies and replan conditions;
- uninspected areas.

### Explorer 2 — Control Plane authority, mechanics, and retirement

Inspect Control Plane, including as applicable:

- AGENTS.md and guidance;
- README.md;
- .docs/architecture.md;
- invariants;
- development-queue or non-goal statements;
- hybrid integration ADRs;
- long-running operator mode;
- Temporal workflow definitions;
- task lifecycle and task-attempt behavior;
- on_hold, retry, revise, completed, failed, rejected, escalation, finalization,
  and cancellation semantics;
- delayed cancellation terminalization;
- workspace and checkpoint ownership;
- candidate/artifact handling;
- provider and model adapters;
- Codex invocation and process supervision;
- ES integration;
- notification and outbox behavior;
- effect deduplication;
- WebAuthn/passkey paths;
- console, read models, guarded interventions, and actionability fingerprints;
- experiment and comparison workflows;
- relevant migrations, schemas, configs, examples, tests, and safe artifacts.

For each potentially reusable item, identify:

- useful mechanic;
- embedded CP assumptions that must not survive;
- current CP owner;
- Coordinator-native target boundary;
- coupling to CP state or Temporal vocabulary;
- whether it accelerates an already selected capability;
- whether it creates a permanent CP dependency.

Classify each candidate as exactly one:

- REUSE CONCEPT ONLY
- RE-DERIVE MECHANIC BEHIND COORDINATOR CONTRACT
- PRESERVE TEMPORARY COMPATIBILITY
- DEMO/REFERENCE ONLY
- HISTORICAL EVIDENCE ONLY
- RETIRE
- UNRESOLVED

Also identify:

- what must remain runnable;
- what need only remain readable;
- what can be cold archived;
- what historical state needs preservation;
- what can be retired after named triggers.

### Explorer 3 — Execution Substrate direct-consumer boundary

Inspect ES, including as applicable:

- AGENTS.md;
- PLANS.md;
- architecture and system boundaries;
- execution lifecycle contracts;
- reliable-submit contracts, implementation, tests, and current blockers;
- keyed submit and response-loss behavior;
- ES-to-Nomad registration uncertainty;
- current prepare, submit, status, logs, result, and cancel paths;
- retained result ownership and authentication;
- lifecycle projection;
- cancellation request and terminal observation;
- runtime-profile contracts;
- source-grounded execution-plan resolution;
- caller identity and admission boundaries;
- control-plane-normal-shell/v1;
- CP-specific compatibility ownership and removal conditions;
- relevant migrations, schemas, configs, examples, tests, and safe artifacts.

Return:

- current ES authority contract;
- minimum ES capability needed for the first Coordinator-operated productive
  route;
- minimum Coordinator capability required to consume it;
- reliable-submit status and blockers;
- required attempt/effect/run/result/cancellation correlation;
- CP compatibility obligations;
- removal or versioning conditions;
- dependencies that do and do not block current ES work;
- uninspected areas.

The paused non-enabling outside-observer lane is not an automatic dependency.

Do not redirect or interfere with separate reliable-submit or Linux-restoration
work.

### Explorer 4 — Cross-repository semantic and authority reconciliation

Inspect all three repositories only as needed to reconcile:

- objective and intent intake;
- startup and planning;
- task/work-item progression;
- attempts and retries;
- repair, revise, and replan;
- checkpoints and workspace progression;
- candidate and capsule custody;
- validation and independent review;
- model review;
- acceptance and rejection;
- block, on-hold, and escalation;
- cancellation request, observation, and terminal closure;
- Git and publication effects;
- notification delivery;
- operator intervention;
- read models, monitoring, and UI;
- experiment and comparison workflows;
- ES runtime facts and CP projections.

Build an evidence-backed non-mapping analysis for:

- CP on_hold vs Coordinator block;
- CP task completion vs Coordinator acceptance;
- CP retry/revise vs Coordinator repair/replan;
- CP checkpoint/workspace vs Coordinator capsule/candidate custody;
- CP rejected/failed/completed vs Coordinator terminal outcomes;
- CP Temporal workflow state vs Coordinator durable program state;
- CP escalation state vs Coordinator progression decisions;
- CP substrate-attempt summaries vs ES runtime/lifecycle facts.

Where no safe mapping exists, say so.

Identify tests, docs, schemas, or examples that would preserve obsolete CP
authority if reused without redesign.

Evaluate security and authority risk around:

- dual durable truth;
- cancellation races;
- outbox/effect replay;
- provider and worker invocation;
- filesystem/workspace custody;
- Git publication;
- WebAuthn or operator writes;
- secret-bearing artifacts;
- generated evidence mistaken for authority.

## Required explorer report envelope

Every explorer must return:

SUBAGENT REPORT

Role:
Assigned scope:
Baseline observed:
Files and documents inspected:

Claim ledger:
- ID:
  Type: evidence | inference | uncertainty
  Layer:
  Claim:
  Source: repository-relative-path:line
  Implication:
  Required docs/source/tests impact:
  Confidence:

Current contracts and invariants:
Implemented source behavior:
Accepted target-only direction:
Compatibility edges:
Historical/demo evidence:
Unpublished local overlays:
Semantic conflicts or non-mappings:
Likely reusable mechanics:
Likely retirement obligations:
Roadmap implications:
Risks and unresolved uncertainty:
Scope not inspected:
Mutation performed: no
Commands with side effects performed: no
Nested subagents created: no

Every material factual claim requires exact repository-relative path and line
references.

## Parent reconciliation requirements

Wait for all required explorers.

Preserve disagreements and minority findings.

Do not force apparent consensus where repositories or evidence layers differ.

The parent must independently inspect enough source to validate major synthesis
claims rather than merely concatenate explorer reports.

Produce substantive findings inline. Do not create a ZIP, report file, freeze
manifest, preservation package, or other artifact.

### 1. Baseline and evidence-layer reconciliation

For each repository distinguish:

- current owning-repository contract;
- implemented source behavior;
- accepted target-only contract;
- compatibility edge;
- historical/demo evidence;
- unpublished local overlay;
- strategic direction;
- inference and uncertainty.

State baseline mismatches and inspection limitations.

### 2. Authority-overlap matrix

For every material overlap provide:

- capability;
- CP current/historical owner;
- Coordinator current implemented owner;
- Coordinator accepted target owner;
- ES, Git, CI, or validating-runtime owner where applicable;
- whether overlap is real, superficial, or semantically different;
- recommended disposition;
- exact evidence.

Cover at minimum all capabilities listed in Explorer 4’s scope.

### 3. Semantic non-mapping table

For each required state pair provide:

- CP meaning;
- Coordinator meaning;
- shared words but different semantics;
- whether any partial evidence translation is valid;
- forbidden inference;
- required future contract, if any.

Do not invent one-to-one mappings.

### 4. Reusable-mechanics matrix

For each candidate provide:

- exact classification;
- useful mechanic;
- CP assumptions that must not survive;
- Coordinator-native authority boundary;
- code/schema/state coupling;
- whether it accelerates an already selected capability;
- permanent-dependency risk;
- recommendation.

Use exactly one classification per candidate:

- REUSE CONCEPT ONLY
- RE-DERIVE MECHANIC BEHIND COORDINATOR CONTRACT
- PRESERVE TEMPORARY COMPATIBILITY
- DEMO/REFERENCE ONLY
- HISTORICAL EVIDENCE ONLY
- RETIRE
- UNRESOLVED

### 5. CP compatibility, freeze, and retirement plan

For each retained item provide:

- current owner;
- current user or dependency;
- current contract;
- preserve, freeze, or retire disposition;
- removal trigger;
- required retirement evidence;
- whether CP code must remain runnable, readable, or cold archived.

Default direction:

- freeze CP as demised demo/reference;
- preserve only explicit bounded compatibility;
- do not add CP orchestration features;
- do not add Coordinator dependencies on CP;
- retire runtime use when compatibility, demo, and historical obligations are
  satisfied.

### 6. Historical-state preservation recommendation

Address:

- Temporal histories;
- SQLite state;
- workspaces;
- reports;
- experiments;
- generated artifacts;
- selected demo evidence.

For each, distinguish:

- no retention need;
- cold historical preservation;
- named audit/demo/compatibility obligation;
- prohibited migration into Coordinator;
- unresolved sensitivity or provenance concern.

Evidence preservation must not create a runtime dependency or program authority.

### 7. Coordinator capability roadmap

Recommend the shortest credible sequence from the verified current Coordinator
baseline to an operating autonomous-development loop.

Consider:

- active-cancel terminal closure;
- production model/provider invocation;
- production worker invocation;
- live supplier/custody;
- automatic repair/replan successor progression;
- standing authority;
- service boundary;
- durable scheduling or queue consumption;
- Git-effect and publication handling;
- operating-loop recovery;
- operator/read surfaces;
- direct-local bootstrap retirement.

Do not presume each missing item deserves a standalone tranche.

For every recommended tranche provide:

- tranche name;
- observable operating result;
- authority owner;
- implementation dependencies;
- what remains blocked;
- why it advances operating capability rather than representation alone;
- affected docs/source/tests/schemas/config/examples/artifacts;
- evidence that would force replanning.

Separate:

- implemented capability;
- target-only contract;
- compatibility work;
- missing operating capability;
- live-proof prerequisite;
- optional future hardening.

### 8. Coordinator–ES direct-integration roadmap

Produce a separate roadmap for Coordinator consuming ES directly.

Consider:

- source-grounded resolved execution-plan extraction;
- reliable keyed submit;
- caller-to-ES response-loss recovery;
- ES-to-Nomad registration uncertainty;
- worker command/result/capsule contracts;
- attempt/effect correlation;
- retained results;
- cancellation request and terminal observation;
- runtime-profile compatibility;
- qualified live execution;
- direct-local bootstrap retirement;
- control-plane-normal-shell/v1 compatibility and removal.

Do not make CP a permanent bridge.

State:

- minimum ES capability for the first productive route;
- minimum Coordinator capability required to consume it;
- which side owns every durable fact;
- recovery behavior at every uncertain boundary;
- contract and proof prerequisites.

### 9. Immediate sequencing decision

Recommend:

- the next one or two Coordinator implementation-bearing tranches;
- the next one or two Coordinator–ES integration tranches;
- which may proceed independently;
- their first join point;
- which CP obligations genuinely block a step;
- which CP obligations do not block the work.

Do not make reconciliation a prerequisite for unrelated work without a named
authority or compatibility conflict.

### 10. Explicit non-goals and replan conditions

List:

- architecture and product non-goals;
- implementation non-goals;
- state-migration non-goals;
- CP dependency non-goals;
- evidence and authority non-goals;
- exact findings that would require roadmap revision.

### 11. Inspection limits

State:

- repositories and identities inspected;
- files and surfaces inspected;
- unavailable snapshots or artifacts;
- skipped sensitive material;
- missing subagent reports;
- source areas not inspected;
- claims that remain report-only or inferred.

## Required decision record

End with exactly this concise record:

- CP STATUS:
- TARGET AUTHORITY:
- TEMPORARY COMPATIBILITY:
- REUSABLE MECHANICS:
- RETIREMENT TRIGGER:
- CURRENT COORDINATOR BASELINE:
- NEXT COORDINATOR CAPABILITY:
- CURRENT ES BASELINE:
- NEXT COORDINATOR–ES CAPABILITY:
- UNRESOLVED DECISIONS:

Then return exactly one reconnaissance verdict:

RECONNAISSANCE_READY
RECONNAISSANCE_PARTIAL
RECONNAISSANCE_BLOCKED
SUBAGENT_UNAVAILABLE

## Non-goals

Do not:

- revive Control Plane;
- design a CP–Coordinator dual-authority system;
- synchronize CP Temporal state with Coordinator state;
- migrate CP run history by default;
- make CP a permanent Coordinator-to-ES bridge;
- copy CP schemas, workflow definitions, or vocabulary wholesale;
- treat similarly named states as equivalent;
- make reports, projections, Bridge ledgers, dashboards, or chat state
  authoritative;
- implement, patch, test, stage, commit, push, or publish;
- create an implementation prompt;
- delay unrelated Coordinator or ES work without a named conflict;
- inspect or disclose sensitive material;
- create another artifact or chat-history dependency.

## Stop conditions

Stop and return a blocked or partial result if:

- any repository changes during reconnaissance;
- baseline identity cannot be established safely;
- a required repository is absent;
- a critical explorer cannot run after one retry;
- sensitive material would need to be exposed;
- answering requires a test, service, network call, migration, or mutation;
- CP local overlays cannot be separated from current contract safely;
- reliable-submit status cannot be grounded in ES source and tests;
- a material authority conflict prevents responsible tranche ordering;
- required evidence is missing and parent inference would be substituted for it.

Confirm at closeout that no repository mutation occurred.
```

## Non-goals for the present decision

This reconnaissance must not become a pretext to:

- revive CP under a new name;
- adopt Temporal simply because CP already uses it;
- postpone active Coordinator work while CP is studied;
- treat CP’s console or task state as the Coordinator domain model;
- shift ES runtime authority into Coordinator;
- make direct Coordinator–ES integration depend on continued CP operation;
- begin implementation before current semantics and target ownership are reconciled.

My provisional sequencing judgment is that **Coordinator’s active-cancel closure and internal operating-loop work should not wait for CP reconciliation unless source inspection reveals a direct semantic dependency**. Likewise, ES reliable-submit work should continue independently. The reconciliation primarily gates reuse decisions, CP retirement, and the exact shape of the direct Coordinator–ES join—not unrelated progress. The supplied direction explicitly says not to delay unrelated work without a named authority or compatibility conflict. Pasted text

### Sources

- Governing reconciliation task and fixed product direction: Pasted text
- Current Coordinator capability and missing operating surfaces: Pasted text
- Required reusable-mechanics and retirement analysis: Pasted text
- Earlier bounded MVP authority and compatibility freeze: mvp
- Read-only Codex reconnaissance discipline: Governed Execution Codex Subage…

**Confidence:** 0.91 on the authority and retirement direction; 0.72 on the provisional mechanics classifications and tranche ordering pending repository reconnaissance.
