## Verdict

Codex stopped correctly. This is a **one-file test-scope correction**, not a source, migration, or architecture contradiction.

The integrated `test_c2b0_durable_state_contract.py` currently calls `_strip_rw0_anchor_0009_status()` first, and that helper requires the migration-0009 candidate marker to be the document’s final suffix. Appending the new integrated-status successor therefore breaks the helper exactly as reported. 

The correct repair is to widen the scope by exactly:

```text
tests/test_c2b0_durable_state_contract.py
```

That file should add a strict new layer which:

1. authenticates and strips the integrated successor;
2. proves the resulting predecessor is the exact merged-tree document ending in the candidate successor;
3. invokes the unchanged candidate-successor stripping logic;
4. continues through the older status history.

The candidate helper must **not** be relaxed to accept arbitrary trailing bytes or perform a loose marker search.

The existing 26 modified files should remain in place. After the one-file repair, Codex should rerun the affected module, the status oracle, the terminal-anchor regressions, and the full suite; then generate the same new-chain v2 provenance, commit, push, and open the documentation-only PR. V2 is the correct recipe for this new status-correction chain. Governed Execution Provenance G… Governed Execution Provenance G…

Remote `trunk_dev` remains at the expected integrated source commit `856c5ac7efd268f70512169c127c91cf097bd200`. 

**Prompt to execute in the same workspace-write Codex conversation:**

`RW0_TERMINAL_ANCHOR_POST_MERGE_STATUS_SCOPE_REPAIR_PROMPT.md`

RW0_TERMINAL_ANCHOR_POST_MERGE_STATUS_SCOPE_REPAIR_HANDOFF.zip[Download the complete scope-repair handoff ZIP](sandbox:/mnt/data/RW0_TERMINAL_ANCHOR_POST_MERGE_STATUS_SCOPE_REPAIR_HANDOFF.zip)

ZIP SHA-256:

```text
627934e51cbfb49bf0376b85ffc56df2bbb7ce2360d47adfeb899d503f047102
```

The handoff authorizes exactly 27 changed paths: the existing 25 documentation successors, the cross-document status oracle, and the newly added strict historical-chain compatibility repair. It prohibits source, SQL, migration, schema, active-cancellation, pause/resume, merge, and deployment changes.

This remains closure of PR #20’s documentation state, not another enabler-only tranche. After its PR is integrated, the next implementation-bearing work remains:

```text
RW0-ACTIVE-CANCEL-PRE-EFFECT-SAFETY-CLOSURE
```

### Sources

Current suffix-helper implementation:   
Provenance recipe selection: Governed Execution Provenance G…  
Current remote `trunk_dev`: 

**Confidence:** scope diagnosis 0.99; repair design 0.98; handoff completeness 0.98.
