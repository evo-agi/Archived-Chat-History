## Verdict

Accept Codex’s `RECONNAISSANCE_READY`. The previous authority blocker is resolved, and the same Codex conversation can now move to the **parent-only workspace-write implementation turn**.

The plan is sufficiently closed because it establishes:

- one cross-profile terminal route rather than a second terminal truth;
- byte-preserving treatment of migrations 0001–0008 and all existing normal rows;
- one explicit migration, table, backfill relation, trigger set, reader path, and recovery model;
- no cancel outcome, cancellation effect, request, process control, or live-source claim;
- a closed touched-path manifest, sequential validation, exact provenance, and hard stop conditions. Pasted text Pasted text

The trigger ordering is coherent: the normal receipt remains the last branch-family row; its `AFTER INSERT` trigger creates the anchor inside the same statement and transaction; the anchor guard can then verify the now-complete normal family. Failure rolls back the receipt statement, preventing both orphan directions. The administrative verifier separately protects migration-time backfill and migration commit recovery. Pasted text Pasted text

### One implementation guard

Migration 0009’s family-admission trigger is intentionally **normal-only**. The implementation and documentation must not imply that the trigger already generically supports future cancellation or live-normal profiles. A later family must receive an explicit later migration that evolves the admission guards while preserving `rw0_terminal_anchors.PRIMARY KEY(phase_basis_ref)` as the single cross-profile route. Do not pre-generalize 0009, but also do not describe its hard-coded current profile as the final multi-family mechanism.

Attach this exact provenance recipe to the Codex turn:

:chatgpt-content-reference{index="11"}[Download the exact provenance recipe](sandbox:/mnt/data/governed_execution_audit_patch_manifest_v1.py)

Calculated SHA-256 of the uploaded recipe:  
`db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`

## Next Codex prompt

```text
# RW0 TERMINAL ANCHOR EVOLUTION
# PARENT-ONLY WORKSPACE-WRITE IMPLEMENTATION

Permission is now workspace-write.

Implement the reconciled RW0-TERMINAL-ANCHOR-EVOLUTION plan from the immediately
preceding read-only reconnaissance.

This is the implementation turn for tranche 1 only.

Do not spawn subagents. You are the sole repository writer.

## Repository

/Users/ds/Repositories/Governed Execution Coordinator/

Do not inspect or mutate Control Plane, Execution Substrate, Bridge,
Infrastructure Manager, Maintenance Agent, or any other repository.

## Required opening baseline

Before editing, verify exactly:

- branch: trunk_dev
- HEAD: 69fc836dbaa0e2124b427bc9611de2e0fba77040
- tree: 8c3b409d1e0c9013ae519d23016af266b3c38cd8
- parent: 3be0096c163b456c9975326be3eb2c30d2b4bbd1
- upstream: origin/trunk_dev
- staged paths: none
- tracked modifications: none
- untracked paths: none

Stop without editing on any mismatch.

Do not fetch, pull, switch, reset, clean, stash, rebase, merge, create a worktree,
or substitute another baseline.

## Objective

Implement migration 0009 and the private branch-neutral terminal-anchor registry
so that:

1. every complete existing migration-0008 normal terminal family is registered
   during explicit migration;
2. every newly recorded normal terminal family atomically gains exactly one
   registry route;
3. guarded normal read, replay, recovery, and commit-uncertainty handling route
   through that registry;
4. migration 0008, every earlier migration, every existing normal row, and the
   normal terminal semantic payload remain unchanged; and
5. no cancellation capability or external authority is added.

The observable result is:

- one immutable cross-profile phase route per terminal family;
- unchanged normal outcome semantics;
- exact preservation of historical normal-family bytes;
- corruption rather than absence for orphaned or contradictory registry/family
  state.

## Frozen authority model

Implement the preceding reconnaissance decision exactly:

- `rw0_terminal_anchors` owns the sole cross-profile phase route.
- The registry is not an outcome, progression decision, effect basis,
  authorization, cryptographic replacement, or independent terminal fact.
- The selected branch-specific context, outcome, result, graph, and receipt
  retain terminal semantic meaning.
- Through migration 0008, the normal context uniqueness remains historical and
  normal-family-local.
- Beginning with migration 0009, terminal truth requires the registry plus
  exactly one completely verified selected family.
- Registry-only, family-only, incomplete, contradictory, aliased, or multiple
  routes establish neither terminal truth nor definite absence.
- Coordinator remains the sole guarded terminal writer.
- Historical replay uses committed historical operands and must not consult
  later mutable heads or current semantic stop state.

## Exact migration design

Implement exactly:

- sequence: 9
- migration ID: 0009_rw0_terminal_anchor_registry
- SQL resource:
  src/ge_nwp_coordinator/sqlite_migrations/0009_rw0_terminal_anchor_registry.sql
- description:
  Branch-neutral RW0 terminal anchor registry and normal-family backfill
- application compatibility: [2,2]
- destructive: false
- application schema generation remains 2

The SQL resource must contain the reconciled six packaged statements:

1. one new STRICT table;
2. four triggers;
3. one normal-family backfill statement.

Do not modify migrations 0001–0008, their catalog identities, checksums, SQL
bytes, or historical inventory assertions.

### Table

Create exactly:

  rw0_terminal_anchors

with the 21 non-null columns frozen in the reconnaissance:

- schema_id
- phase_basis_ref
- phase_basis_digest
- family_profile
- family_route
- mutation_ref
- command_digest
- program_ref
- decision_ref
- context_ref
- context_digest
- outcome_value_ref
- outcome_value_digest
- result_ref
- result_digest
- receipt_ref
- receipt_digest
- graph_profile
- graph_digest
- committed_result_digest
- recorded_at

Use the fixed schema tag:

  governed-execution.nwp-rw0-terminal-anchor.v1

Do not add a registry self-digest.

Every other registry field must be copied verbatim from the selected durable
family. Store no outcome body, command body, external observation, or
authorization body.

Implement exactly these constraints:

- PRIMARY KEY(phase_basis_ref)
- UNIQUE(phase_basis_ref, phase_basis_digest)
- individual UNIQUE constraints on:
  - family_route
  - mutation_ref
  - decision_ref
  - context_ref
  - outcome_value_ref
  - result_ref
  - receipt_ref
- composite FK:
  (phase_basis_ref, phase_basis_digest) -> rw0_phase_instances
- composite FK:
  (program_ref, decision_ref) -> development_decisions

Do not add an unconditional FK to the current normal receipt table.

### Triggers

Create exactly these trigger identities:

- rw0_terminal_anchors_no_update
- rw0_terminal_anchors_no_delete
- rw0_terminal_anchors_require_registered_family
- rw0_terminal_receipts_register_anchor

The update and delete triggers must fail closed with `RAISE(ABORT)`.

For migration 0009, the family-admission guard is intentionally limited to:

  artificial_offline_normal.v1

It must require the exact complete normal-family relation. Unknown or unsupported
profiles fail closed.

The receipt `AFTER INSERT` trigger must:

1. project the exact matching anchor through the complete normal-family relation;
2. insert that anchor;
3. explicitly abort when the exact anchor does not exist afterward, including
   when an `INSERT ... SELECT` would otherwise insert zero rows.

Direct registry insertion must abort unless the exact complete matching normal
family already exists.

A normal receipt and anchor must be inseparable at commit.

### Future-profile wording guard

Do not claim that migration 0009’s normal-only trigger already supports future
cancel or live-normal profiles.

Document that:

- the registry table and phase key are the durable cross-profile foundation;
- 0009 admits the current normal family only;
- admission of any later branch profile requires a separate explicit migration
  that evolves the family-validation trigger contract;
- no later branch may introduce a second phase-unique terminal store.

Do not design or implement that later migration in this tranche.

## Exact backfill

Use the exact `INSERT ... SELECT` relation frozen in the reconnaissance.

It must:

- start from `rw0_terminal_receipts`;
- join the exact matching context, outcome, and result;
- preserve every existing identity, digest, graph coordinate, committed-result
  digest, and timestamp;
- restrict the relation to:
  - `artificial_offline_normal.v1`
  - `governed-execution.nwp-rw0-terminal-normal-graph.v1`
  - normal outcome and result branches;
- order deterministically by `phase_basis_ref`;
- perform no Python row rewrite, rehash, or timestamp reconstruction.

The administrative verifier must reject a zero-row or partial backfill when
historical normal rows exist.

## Migration administration and recovery

Create the private read-only administrative verifier specified by the
reconnaissance.

It must run:

- after migration-0009 statements and before migration commit;
- during exact migration commit-uncertainty recovery.

It must prove, at minimum:

- equal counts for normal contexts, outcomes, results, receipts, and anchors;
- the exact complete five-way relation has that same count;
- totality in both directions;
- one-to-one routing;
- persisted value/self-digest validity;
- saved normal graph validity;
- command-digest consistency;
- committed-result-digest consistency;
- expected profile and graph identities;
- no aliases, extra routes, unsupported profiles, or malformed family.

It is a read-only verifier. It must not become another migration executor or
rewrite any row.

Preserve the existing one-commit migration framework and three-way recovery:

- committed_exact
- definitely_not_committed
- unresolved

`committed_exact` for 0009 requires exact migration history, exact cumulative
schema, and the complete administrative backfill invariant.

Do not add protected terminal-row scans to ordinary pre-fence writer admission.

## Normal writer, reader, replay, and recovery

Preserve normal fresh-record order:

  context -> outcome -> result -> receipt

The receipt remains the last branch-family row.

Its trigger creates the registry row in the same statement and transaction.

Before the one commit attempt, guarded code must read back and verify:

- the unchanged four-row normal family;
- the exact anchor;
- the exact copied route coordinates.

After common admission, fencing, and positive disclosure, anchor lookup becomes
the first terminal-family routing lookup.

For the current tranche:

- the supported profile selects the existing checked normal family;
- an unsupported profile fails closed;
- exact replay returns the original committed result and time;
- historical replay does not re-evaluate current heads or semantic stop;
- anchor/family mismatch, inverse orphan, aliases, unsupported profile, partial
  rows, or contradictory coordinates are integrity failures in ordinary
  operation and unresolved in recovery;
- definite absence requires the complete exclusion proof from the
  reconnaissance;
- missing anchor or missing receipt alone never proves absence;
- recovery never authorizes a new effect, terminal family, or semantic attempt.

Preserve:

- normal command and value types;
- existing four-row normal shape;
- normal graph profile;
- committed-result digest;
- head witness;
- `TerminalCommittedV1`;
- public writer-session shape;
- transaction-controller single-commit ownership.

## Closed touched-path scope

The exact touched-path manifest in the preceding reconnaissance is authoritative.

Create only the six paths classified there:

- src/ge_nwp_coordinator/sqlite_migrations/0009_rw0_terminal_anchor_registry.sql
- src/ge_nwp_coordinator/_rw0_terminal_anchor_rows.py
- src/ge_nwp_coordinator/_sqlite_rw0_terminal_anchor.py
- src/ge_nwp_coordinator/_sqlite_rw0_terminal_anchor_migration_invariants.py
- tests/test_sqlite_rw0_terminal_anchor_migration_0009.py
- tests/test_sqlite_rw0_terminal_anchor_controls.py

Modify only:

- the implementation paths named in the reconnaissance;
- the exact 25 marked-status documents named there;
- the exact tests and fixtures named there.

Do not alter config or example paths.

Do not add a path to the patch merely because it is nearby or convenient.

If implementation genuinely requires any path outside the frozen manifest, stop
before making that out-of-scope edit and return:

  IMPLEMENTATION_SCOPE_REPLAN_REQUIRED

Identify the path, reason, and owning contract.

## Documentation treatment

Preserve every existing migration-0008 historical status block byte-for-byte.

Append the marked migration-0009 successor wording instead of rewriting history.

The detailed owning contract belongs in:

- .docs/rw0-terminal-outcome-physical-closure.md
- .docs/sqlite-bootstrap-and-migrations.md
- .docs/sqlite-operations-and-recovery.md

The remote-contact owner must explicitly state that terminal-anchor evolution
adds no physical cancel capability.

The status successors must not imply:

- live execution;
- qualified supplier or custody;
- cancellation decisions or outcomes;
- cancellation effects or requests;
- external source reconciliation;
- successor launch;
- Git, publication, or deployment effects.

## Test requirements

Add and update tests so that the candidate proves at least:

- fresh 0001–0009 installation with zero seeded terminal rows;
- explicit populated 0008-prefix upgrade;
- an actual coherent committed normal family created under exact 0008 history;
- byte-identical 0008 rows before and after migration;
- preserved 0001–0008 checksums;
- preserved historical `(78,142,5)` 0008-prefix inventory;
- current 0009 inventory:
  - 79 tables
  - 146 triggers
  - five explicit indexes
  - 1814 columns
  - 242 foreign keys
- complete one-to-one backfill;
- malformed, partial, contradictory, or aliased old family rollback;
- direct orphan anchor rejection;
- complete family without anchor rejection;
- unsupported and wrong profile rejection;
- cross-phase and route collisions;
- normal fresh record and exact replay;
- protected disclosure ordering;
- registry/family corruption classification;
- exact command reuse and conflicting reuse;
- lost commit response;
- post-commit cleanup failure;
- old-binary refusal of the newer tip;
- all three recovery classes;
- unchanged normal connected behavior;
- unchanged normal head-witness behavior;
- unchanged historical replay semantics.

Do not weaken, delete, or broadly rewrite existing tests to obtain a pass.

## Sequential validation

Run these commands sequentially on one final candidate tree:

PYTHONDONTWRITEBYTECODE=1 python -m pytest -p no:cacheprovider -q tests/test_sqlite_rw0_terminal_anchor_migration_0009.py tests/test_sqlite_rw0_terminal_migration_0008.py tests/test_sqlite_b1_migrations.py tests/test_sqlite_c2b1_migration_framework.py

PYTHONDONTWRITEBYTECODE=1 python -m pytest -p no:cacheprovider -q tests/test_sqlite_rw0_terminal_anchor_controls.py tests/test_sqlite_rw0_terminal_controls.py tests/test_sqlite_rw0_terminal_connected.py tests/test_rw0_terminal_head_witness_regression.py tests/test_rw0_terminal_outcome_values.py

PYTHONDONTWRITEBYTECODE=1 python -m pytest -p no:cacheprovider -q tests/test_sqlite_rw0_c1_migration_0004.py tests/test_sqlite_section41_migration_0003.py tests/test_sqlite_section41_migration_0005.py tests/test_sqlite_rw0_c2_migration_0006.py tests/test_sqlite_rw0_c2_migration_0007.py tests/test_b3_coherent_transition_fixture.py tests/test_c2b0_durable_state_contract.py tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py

PYTHONDONTWRITEBYTECODE=1 python -m pytest -p no:cacheprovider -q tests

git diff --check
git status --porcelain=v1 --untracked-files=normal
git diff --name-only
git diff --cached --name-only

Do not run tests concurrently.

Repair failures caused by this tranche while remaining inside the frozen scope.

If a failure demonstrates that a frozen authority, schema, migration, or
touched-path decision is wrong, stop and return a replan result rather than
weakening the contract.

## Artifact hygiene

Do not use broad cleanup commands.

Remove only individually identified artifacts created by this implementation,
including any implementation-created:

- __pycache__ directories;
- pyc or pyo files;
- pytest caches;
- temporary SQLite databases, journals, WAL, or SHM files;
- temporary manifests accidentally written inside the repository.

Do not remove or modify any pre-existing artifact without separate authority.

Run final validation and provenance only after cleanup.

## Exact provenance

Use the exact attached file:

  governed_execution_audit_patch_manifest_v1.py

Expected recipe SHA-256:

  db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Do not modify or reconstruct the recipe.

From the repository root:

1. independently hash the supplied recipe and require the expected SHA-256;
2. run the exact recipe twice;
3. require byte-identical canonical output;
4. keep its temporary output outside the repository;
5. record:
   - recipe ID;
   - exact recipe source SHA-256;
   - tracked textual-diff SHA-256;
   - canonical-manifest SHA-256;
   - file count;
   - complete canonical manifest JSON;
   - candidate branch, HEAD, tree, and upstream.

The provenance manifest must include every tracked and untracked patch path.

Provenance establishes byte identity only. Do not claim that it proves
correctness, authority, or successful validation.

## Prohibited effects

Do not:

- spawn subagents;
- perform an independent audit;
- modify another repository;
- contact a network or live service;
- install or update dependencies;
- run live workers, models, Coordinator services, ES, CP, Bridge, Nomad, Docker,
  Vault, or SPIRE;
- inspect secrets, credentials, environment files, private databases, or private
  evidence;
- add a cancellation decision, outcome, effect, request, process observation, or
  reconciliation path;
- add a live provider, supplier, custody path, scheduler, queue, service,
  successor launch, Git effect, publication, or deployment;
- edit historical migration bytes;
- stage, commit, push, create a PR, merge, or deploy.

## Stop conditions

Stop without broadening or repairing around the issue if:

- the opening baseline differs;
- repository state changes unexpectedly;
- a required path lies outside the frozen touched-path manifest;
- migration 0008 or an earlier migration/status block would need modification;
- an existing normal row would need rewriting, rehashing, or retimestamping;
- the backfill is not total and one-to-one;
- a registry digest would need to be fabricated;
- a normal receipt can commit without its exact anchor;
- an anchor can commit without one exact complete family;
- two family routes can claim one phase;
- direct registry insertion can bypass complete-family verification;
- registry or family corruption would be classified as absence;
- full protected terminal rows must be scanned before fencing and positive
  disclosure;
- historical replay must consult later mutable heads or current semantic stop;
- an old binary can write against migration 0009;
- application schema generation would need to advance without a newly grounded
  contract;
- the current tranche would add or imply cancel capability;
- future cancellation would still require an independent phase-unique terminal
  store;
- the current normal-only trigger cannot later be deliberately evolved by an
  explicit migration without replacing the terminal anchor itself;
- validation cannot pass without weakening an owning contract or test.

## Required implementation report

Return:

IMPLEMENTATION REPORT

Objective:
Repository:
Opening branch:
Opening HEAD:
Opening tree:
Opening upstream:
Final branch:
Final HEAD:
Final tree:
Final working-tree status:

Baseline verification:

Implementation decision:
- terminal authority treatment
- migration treatment
- existing-row treatment
- normal fresh-write treatment
- reader/replay/recovery treatment
- future-profile non-claim

Files touched:
- exact path
- create or modify
- governing classification
- implementation summary

Migration 0009:
- resource checksum
- statement inventory
- table/trigger/index/column/FK inventory
- exact supported-prefix behavior
- fresh-install result
- populated-0008-prefix result
- backfill verification result
- old-binary result
- commit-uncertainty result

Validation:
- exact command
- exit/result
- concise output summary
- candidate bytes against which it ran

Failed or skipped validation:
Generated/artifact hygiene:
Authority/security/protocol widening:
Cross-repository impact:
Assumptions:
Unresolved seams:
Scope not inspected:

Provenance:
- recipe ID
- recipe source SHA-256
- tracked textual-diff SHA-256
- canonical-manifest SHA-256
- file count
- complete canonical manifest JSON
- repeated-run equality result

Confirm exactly:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED

End with exactly one:

IMPLEMENTATION_READY_FOR_INDEPENDENT_AUDIT
IMPLEMENTATION_REPLAN_REQUIRED
IMPLEMENTATION_BLOCKED
```

After this implementation returns, the next action is a **fresh read-only, provenance-first independent audit**, not staging or commit. The reconnaissance itself explicitly requires separate audits of migration/backfill, single terminal authority, replay/recovery, and privacy/source boundaries on the exact candidate bytes. Pasted text

### Sources

- Readiness, baseline, and sole-authority decision: Pasted text
- Closed migration and backfill design: Pasted text
- Transaction, replay, and recovery plan: Pasted text
- Closed touched-path scope: Pasted text
- Validation, provenance, and stop gate: Pasted text
- Parent-only mutation and fresh-audit protocol: Governed Execution Codex Subage…

**Confidence:** implementation-plan confidence 0.93; repository-validation confidence 0.78 because the evidence remains Codex-reported and no implementation tests have run; provenance confidence becomes assessable only after the exact patch manifest is produced.
