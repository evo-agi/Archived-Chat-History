## Verdict

Codex’s `BLOCK` verdict is correct. The candidate’s architecture and migration design survived audit, but acceptance is blocked by two fail-closed correctness defects:

- Ordinary read and fresh record can return absence or `route_collision` before checking all unique anchor aliases and validating any matched anchor’s selected family.
- Recovery can miss those anchor aliases and incorrectly return `definitely_not_committed` for corrupt registry state that must be `unresolved`. Pasted text

The three test findings are also valid. Two leave core migration and corruption behavior causally unproved; the third allows one of the 25 status successors to disappear without failing the positive oracle. Pasted text

This is a **bounded repair**, not an architecture reset. The audit accepted the single cross-profile route, normal-family authority, receipt-trigger atomicity, administrative migration verifier, historical replay posture, documentation boundaries, old-catalog treatment, and two-test scope contraction. Pasted text

The pre-provenance source inspection was a process deviation, but it does not invalidate the blocking findings: the auditor subsequently reproduced the exact 68-path manifest, completed the correctness review against those bytes, reran all requested validation, and preserved the candidate unchanged. Pasted text Pasted text

## Next action

Resume the **original implementation Codex conversation** in workspace-write mode. Do not use the audit conversation for repair. The repair prompt limits mutation to the registry-routing source and directly relevant tests, prohibits migration or documentation changes, reproduces the blocked provenance before editing, and requires new validation and provenance afterward.

After any repair byte changes, the prior audit no longer applies. The repaired candidate must go to a fresh read-only independent audit before staging or committing. Governed Execution Codex Subage…

**Prompt to execute:**  
`RW0_TERMINAL_ANCHOR_EVOLUTION_AUDIT_REPAIR_PROMPT.md`

RW0_TERMINAL_ANCHOR_EVOLUTION_AUDIT_REPAIR_HANDOFF.zip[Download the complete audit-repair handoff ZIP](sandbox:/mnt/data/RW0_TERMINAL_ANCHOR_EVOLUTION_AUDIT_REPAIR_HANDOFF.zip)

ZIP SHA-256:

```text
54df685438272405413e927f59013ab6a5e64c259c7d31bb2f7fea5e56e7b4dc
```

The ZIP contains the named repair prompt, `README_FIRST.md`, the blocking audit report, the original implementation report, the exact provenance recipe, and handoff checksums.

### Sources

- Independent audit findings and verdict: Pasted text
- Accepted contract conclusions and validation: Pasted text
- Repair and mandatory re-audit protocol: Governed Execution Codex Subage…

**Confidence:** audit-verdict confidence 0.98; repair-scope confidence 0.93; implementation confidence remains 0.62 until the alias-corruption paths are repaired and independently re-audited.
