Here is Codex's response:

# T2-R1 FIXTURE REPLAN REPORT

**Objective:** Freeze a test-only construction for the two-family, exact-0008 backfill proof.  
**Repository:** `/Users/ds/Repositories/Governed Execution Coordinator`

**Baseline/provenance verdict: MATCH.** The ZIP members matched `HANDOFF_SHA256SUMS.txt`, and the archive integrity check passed. The repository remains on `trunk_dev` at HEAD `69fc836dbaa0e2124b427bc9611de2e0fba77040`, tree `8c3b409d1e0c9013ae519d23016af266b3c38cd8`, parent `3be0096c163b456c9975326be3eb2c30d2b4bbd1`, upstream `origin/trunk_dev`. It still has 62 tracked modifications, six untracked files, and no staged paths. The existing fixed-output manifest was read without changing its custody; its SHA-256 remains `da2c06d6b9def69fe78d2f42496f2a27ce4504726cc0e8c5434abefca3f61d92`. The opening textual-diff SHA-256 remains `dd1d516774b70d8a9889d27e9c8b7068063338a337866c356e1dfa2d237761b8`. All listed target and prior-repair file hashes matched.

## Audit requirement and construction decision

T2-R1 requires two complete, coherent normal terminal families **in one genuine 0008 database**, followed by one 0009 migration, two independently assembled 21-field anchor comparisons, and preservation of every old terminal row.

The earlier prompt required distinct programs without showing why. The live [0009 backfill SELECT](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0009_rw0_terminal_anchor_registry.sql:111>) supplies **only `program_ref` from the context row**; the remaining anchor coordinates come from the receipt. To make a wrong cross-family *context* join visible in the 21-field result, the two contexts therefore need different `program_ref` values. Other ancestors need not be wholly independent. The global-stop singleton must be shared, and a P0 fact may be shared only if its checked scope applies to both chains. Distinct timestamps would expose a timestamp field swap, although they are not needed to make the context join observable. Branch and outcome may be equal.

The schema permits multiple families with different phases and decisions: [0008 terminal keys](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0008_rw0_terminal_outcome.sql:63>) are per family. A second phase cannot be made by changing its ref alone: [C1 uniquely constrains the K8 digest](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql:78>). That K8 includes program, attempt, candidate, effect, command, fences, and delivery. The intended two-program construction is contractually possible, but the inspected test seams do not yet provide an exact, bounded way to build and combine both **checked** chains under one 0008 history.

**Selected strategy for further fixture work: C — a dedicated exact-0008 test fixture. This is a feasibility direction, not a frozen implementation authorization.** Strategy A with a shared program cannot detect the context-to-program mix through the specified anchor tuple. Strategy B cannot be closed by parameterizing only `prepared_normal_case`: the connected [D1/D2 helper](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_sqlite_rw0_terminal_connected.py:214>) creates one run and one state root, while D2 fixes additional source and proposal identities. Strategy D would establish only row shape and foreign keys unless it also reconstructs the full checked Section 41/C1/P1 semantics.

## Collision ledger

The prior probe’s “20 collisions” were **primary-key conflicts in the terminal rows’ recursive FK ancestor closure**, not an inventory of every row in two complete checked runs. The ledger below identifies those 20. For a second *different-program* chain, none can be copied under the same key with different bytes. Changing an identity requires recomputing its row digest and every dependent command, receipt, phase, P1, and terminal digest through the existing value contracts.

| Durable row and global key | Fixed identity source | Required disposition and dependent chain |
|---|---|---|
| `development_decisions(decision_ref)` — `decision.d1` | [D1 genesis](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:281>) | Distinct genesis decision; recompute program/version and downstream author lineage. |
| `development_semantic_attempts(semantic_attempt_ref)` — `semantic-attempt.d1` | [D1 genesis/ingress](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:138>) | Distinct attempt, candidate binding, author rows, and phase K8. |
| `development_attempt_fences(attempt_fence_ref)` — `attempt-fence.d1` | [D1 ingress](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:128>) | Distinct fence and digest; rebind author command, selection, and phase. |
| `development_author_commands(command_ref)` — `command.d1` | [D1 ingress](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:189>) | Distinct command/digest and dependent effect, delivery, selection, phase. |
| `development_authority_evaluations(authority_evaluation_ref)` — `authority-evaluation.d1` | [D1 ingress](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:190>) | Distinct checked author authority row and phase binding. |
| `development_effect_intents(effect_intent_ref)` — `effect-intent.d1` | [D1 ingress](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:167>) | Distinct effect, authorization binding, heads, selection, phase. |
| `development_effect_fences(effect_fence_ref)` — `effect-fence.d1` | [D1 ingress](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:188>) | Distinct fence/digest and phase/current-head bindings. |
| `development_delivery_attempts(delivery_attempt_ref)` — `delivery-attempt.d1` | [D1 ingress](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:191>) | Distinct delivery/digest and selection/phase bindings. |
| `development_pre_execution_planning_contexts(planning_context_ref)` — `planning-context-d1` | [pre-execution builder](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_pre_execution.py:233>) | Distinct context/digest, model source, proposal, disposition. |
| `development_model_source_invocations(source_invocation_ref)` — `source-invocation-d1` | [pre-execution builder](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_pre_execution.py:384>) | Distinct source/digest and proposal. |
| `development_private_proposal_artifact_bindings(artifact_ref)` — `private-plan-d1` | [pre-execution builder](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_pre_execution.py:110>) | Distinct artifact/binding digests and proposal/selection. |
| `development_model_proposals(proposal_ref)` — `model-proposal-d1` | [pre-execution builder](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_pre_execution.py:354>) | Distinct proposal/digest and selection/phase. |
| `development_pre_execution_dispositions(disposition_ref)` — `planning-disposition.d1` | [D1 selection call](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:360>) | Distinct disposition/digest and selection-head/phase postimage. |
| `development_model_source_invocations(source_invocation_ref)` — `source-invocation.d2.fake-review` | [D2 model call](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2_offline.py:88>) | Distinct D2 source/digest and post-execution proposal lineage. |
| `development_private_proposal_artifact_bindings(artifact_ref)` — `artifact.d2.post-review` | [D2 proposal builder](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2b_proposal.py:325>) | Distinct artifact/binding digests and Section 41 evidence. |
| `development_model_proposals(proposal_ref)` — `proposal.d2.post-review` | [D2 model input](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2b_model_input.py:425>) | Distinct proposal/evidence-set, Section 41, C1 rank-15, P1. |
| `rw0_c2_historical_continuity_bases(basis_ref)` — `continuity-A` | [P1 history helper](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_progression_plan.py:126>) | Distinct program-bound projection digest and P1 basis. |
| `rw0_c2_historical_sole_active_bases(basis_ref)` — `sole-A` | [P1 history helper](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_progression_plan.py:126>) | Distinct program-bound projection digest and P1 basis. |
| `rw0_c2_decision_bases(basis_ref)` — `basis-A` | [P1 basis helper](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_progression_contracts.py:43>) | Distinct basis/digest, relation preassignments, decision and terminal command. |
| `development_mutation_receipts(mutation_ref)` — `p1-mutation-A` | [P1 command helper](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_c2_progression_plan.py:152>) | Distinct receipt graph/digest and terminal reached-owner manifest. |

The keys above are imposed by [0002](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql:152>), [0003](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0003_cognitive_proposal_and_selection_state.sql:1>), and [0007](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0007_rw0_c2_progression_decision.sql:1>). Separate database generation caused the collisions: each run could reuse fixed literal refs locally, but two differing rows cannot occupy the same global key in one database.

The 20-row closure also omits fixed identities needed by a *complete checked graph*: D1 uses `mutation-genesis.d1`, `mutation-author.d1`, and `cognitive-mutation.d1` ([D1 calls](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:277>)); the phase builder fixes `basis.d1.offline` and `mutation.d1.phase` ([phase builder](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_pre_execution.py:574>)); D2A fixes mutation and membership label prefixes ([D2A admission](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2a_offline.py:268>)), while C1 membership refs are globally unique ([C1 schema](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql:150>)). These need distinct phase-specific values and their dependent digests. By contrast, the [global-stop row is a singleton](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0001_initial.sql:333>) and must be reused. P0’s [fact, act, lineage, and scope keys](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_migrations/0006_rw0_c2_scope_admission.sql:16>) may be shared only as one unchanged checked admission, never duplicated under the same keys.

## Causal proof design once a fixture exists

Use explicit `COLUMNS[table]` order to save **both complete row sets** from context, outcome, result, and receipt before migration, keyed by `phase_basis_ref`. Build each expected 21-field tuple in the test from those raw rows using explicit field assignments and only the fixed anchor schema tag. Do not call `expected_normal_anchor` or reuse the migration SELECT for that oracle. Migrate once; query exactly `BACKFILL_COLUMNS` ordered by phase; require two tuples, reject cross-family swaps, and compare all four full ordered historical row sets before and after. Require a clean `PRAGMA foreign_key_check` before migration and the administrative [backfill verifier](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_sqlite_rw0_terminal_anchor_migration_invariants.py:38>) to accept after migration.

The two-program distinction detects a wrong context/program pairing. Distinct phase, decision, route, mutation, command, terminal refs and digests detect copied receipt coordinates; distinct times detect a timestamp swap. Schema/profile/graph-profile and branch/outcome can legitimately match. An outcome or result join that pairs the wrong row while selecting no value from it and preserving one row per receipt would be observationally inert to the 21-field oracle; the proof should not claim to detect that SQL mutant.

## Scope, order, and validation

**Closed touched-path manifest: not frozen.** [The target migration test](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_sqlite_rw0_terminal_anchor_migration_0009.py:164>) must change. A dedicated tests-only fixture path is the likely second path, but static inspection did not establish an exact constructor for the second checked Section 41/C1/P1 graph in one existing 0008 database. The legacy [B3 coherent fixture](</Users/ds/Repositories/Governed Execution Coordinator/tests/b3_coherent_transition_fixture.py:254>) is not that constructor: its [owning contract](</Users/ds/Repositories/Governed Execution Coordinator/.docs/b3-tests-only-coherent-fixtures.md:1>) leaves C2B and C1 tables empty. Naming a new file now as an authorized path would conceal this unresolved seam.

The next implementation order is: establish a test-only second-program constructor using existing typed value and checked-reader contracts; prove both predecessor chains coexist in one exact-0008 database; build and commit the two terminal plans in context → outcome → result → receipt order; then add the independent migration assertion. If the first step requires production or schema changes, keep the repair blocked.

After that constructor and its touched paths are fixed, validation must run sequentially: the new test, its whole module, any changed helper’s callers, the focused anchor set, the three prior implementation groups, the full `tests` suite, then `git diff --check`, status/path checks, artifact hygiene, and two custody-safe v1 manifest runs. **No validation command was run in this read-only turn.** The later provenance must start from manifest `da2c06d6b9def69fe78d2f42496f2a27ce4504726cc0e8c5434abefca3f61d92`, preserve 0009 SQL SHA-256 `ee9a063b4974bffee39af691dc059535172f189e89d96789befe716cd89b3d25` and every non-authorized path, and obtain a fresh independent audit for any changed bytes.

**Authority/security/protocol widening:** none.  
**Production/schema/docs widening:** none.  
**Unresolved seam:** exact tests-only construction and validation of the second checked predecessor graph; therefore no closed path manifest or ready repair plan.  
**Scope not inspected:** other repositories, secrets, private databases, live state, and services.

REPOSITORY_MUTATION_NOT_PERFORMED  
TESTS_NOT_RUN  
MIGRATIONS_NOT_RUN  
STAGING_NOT_PERFORMED  
COMMIT_NOT_PERFORMED  
PUSH_NOT_PERFORMED

T2_R1_FIXTURE_REPLAN_BLOCKED

RECONNAISSANCE_PARTIAL
