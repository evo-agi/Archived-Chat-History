## Verdict

Codex stopped at the right boundary. This is not an implementation failure; it found the architecture decision that the previous roadmap had left implicit.

The clean baseline was preserved, all four explorers completed, and no repository mutation or validation command occurred. Pasted text Pasted text

The substantive finding is sound:

- Migration 0008 is deliberately a **normal-only** terminal family.
- Its phase-unique context is declared to be the single terminal-truth anchor for normal and future cancellation outcomes.
- The existing contract forbids an independent cancel terminal store.
- The repository does not yet define how to evolve that anchor without rewriting existing normal rows or creating two competing terminal truths. Pasted text

Therefore, **do not switch this Codex conversation to workspace-write yet**.

## Architecture decision

I am making the missing strategic decision as follows, subject to Codex verifying its physical feasibility against the live repository:

### Evolve the anchor additively; do not replace or fork it

Migration 0009 should introduce one **branch-neutral terminal-anchor registry** above the existing 0008 normal family.

The design constraints are:

1. **Migrations 0001–0008 and every existing normal terminal row remain byte-for-byte unchanged.**
2. **No destructive table rebuild, rename, drop, row rewrite, rehash, or in-place widening of 0008.**
3. Every complete existing 0008 normal family is backfilled into the new registry during migration.
4. The registry has exactly one entry per `phase_basis_ref` across every terminal branch and profile.
5. The registry is the sole cross-profile uniqueness and family-routing authority after migration 0009.
6. The existing four-row 0008 family remains the semantic and cryptographic payload for normal outcomes. It becomes a registered branch family; it is not copied into a replacement normal store.
7. A future cancellation family must register through the same anchor. It cannot own an independent phase-unique key or become a competing source of terminal truth.
8. New normal closures after 0009 must create the registry binding and the existing normal family in one transaction.
9. The existing rule that the terminal-family receipt is inserted last must remain intact. The registry binding may be established earlier in the same transaction using precomputed identities, with the receipt or managed invariant proving that the complete bound family exists before commit.
10. The registry must not fabricate a new cryptographic digest that migration SQL cannot derive. It should bind the existing context, outcome, result, receipt, graph, and committed-result identities and digests. Full semantic integrity remains in the selected branch family.
11. Migration-time backfill must fail closed, inside the migration transaction, if an existing 0008 context cannot be joined to exactly one complete and internally consistent outcome/result/receipt graph.
12. After migration, readers and recovery resolve the anchor first, select exactly one branch family, and then perform that family’s complete historical verification.
13. A partial registry/family relation, an unregistered normal family, or two families for one phase is managed-state corruption—not “absence” and not a stale-currentness conflict.
14. Old binaries continue to refuse the newer catalog tip. No compatibility shim may allow an old writer to add unregistered 0008 rows.

This is an evolution of the single anchor, not a new cancel store. The registry is an immutable branch selector and uniqueness root; the registered terminal family remains the full terminal fact.

### Why this path

Rebuilding the four 0008 tables would conflict with the repository’s non-destructive migration posture and create unnecessary historical-row and digest risk. A cancel-only context table without a common anchor would directly violate the single-anchor contract. An additive registry can preserve existing bytes, backfill old rows, enforce cross-profile uniqueness, and let normal and cancel families retain distinct evidence graphs.

The exact table name, columns, trigger arrangement, application-schema generation, migration resource, and invariant implementation remain repo-level decisions that Codex must now freeze.

## Revised tranche sequence

The previous “active cancel next” recommendation was too coarse. It now decomposes into three boundaries:

### 1. `RW0-TERMINAL-ANCHOR-EVOLUTION`

Add the branch-neutral anchor registry, backfill 0008 normal families, update the normal writer to register new closures, and update readers/recovery/invariants. This tranche adds **no cancel outcome**.

Its observable result is that every historical and newly recorded normal terminal family is selected through one branch-neutral, phase-unique anchor without changing normal terminal semantics.

### 2. `RW0-ACTIVE-CANCEL-PRE-EFFECT-SAFETY-CLOSURE`

Physically add the pre-effect cancel decision path and the zero-effect terminal `block` path for a **proven unusable basis**. It establishes no cancellation effect, request, signal, or live contact.

This tranche must limit itself to exact, legitimate mismatch evidence. Absence of a qualified authority observation cannot be reclassified as a proven mismatch merely to make the branch close. Codex identified that distinction explicitly. Pasted text

### 3. `RW0-ACTIVE-CANCEL-SOURCE-RECONCILIATION`

Implement reconciled terminal `cancel` and post-teardown unresolved `block` only with the qualified worker/supervisor/custody source path. Request, acknowledgement, signal, exit, teardown, custody, and reconciliation must remain distinct facts; current supplied C1 evidence and fake D1 process mechanics do not prove live source-native cancellation. Pasted text

This third tranche should join the one-qualified-live-attempt work rather than construct another large artificial-only cancellation program first.

## Next Codex prompt

Continue in the **same Codex conversation**, still read-only:

```text
# RW0 TERMINAL ANCHOR EVOLUTION
# FOCUSED CONTRACT AND MIGRATION RECONCILIATION

## Objective

Continue the preceding read-only Coordinator reconnaissance.

Freeze the exact authority-safe contract and implementation plan for evolving the
single RW0 terminal-truth anchor so that the existing normal terminal family and
a future active-cancel family can coexist without:

- changing migration 0008 bytes;
- rewriting existing normal terminal rows;
- rebuilding or dropping existing tables;
- creating a competing cancel terminal store;
- introducing two phase-unique terminal authorities; or
- weakening historical replay, recovery, receipt, or corruption semantics.

Do not implement anything in this turn.

This turn should produce the closed plan for the first implementation-bearing
tranche:

  RW0-TERMINAL-ANCHOR-EVOLUTION

That tranche must preserve all current normal outcome behavior and must not add a
cancel outcome, cancellation effect, external request, live process control, or
source-reconciliation path.

## Repository

/Users/ds/Repositories/Governed Execution Coordinator/

Do not inspect or mutate Control Plane or Execution Substrate.

## Required baseline

Expected repository identity:

- branch: trunk_dev
- HEAD: 69fc836dbaa0e2124b427bc9611de2e0fba77040
- tree: 8c3b409d1e0c9013ae519d23016af266b3c38cd8
- parent: 3be0096c163b456c9975326be3eb2c30d2b4bbd1
- upstream: origin/trunk_dev
- working tree: clean

Verify branch, HEAD, tree, parent, upstream, staged state, tracked changes, and
untracked paths before substantive work.

Stop on any mismatch or drift. Do not repair or substitute a baseline.

## Current repo-validated contract

Verify these current facts against owning docs, source, SQL, and tests:

1. Migration 0008 is the current catalog tip.
2. Its four terminal tables and eight immutability triggers are normal-only.
3. It records only:
   - accept
   - repair
   - replan
   - terminal_reject
   - block
4. `rw0_terminal_contexts` is unique by phase basis and prior decision.
5. The current contract declares the phase-unique context key to be the single
   terminal-truth anchor, including for a later versioned cancel program.
6. A competing cancel terminal store is forbidden.
7. The current normal writer uses fenced receipt-first replay, fresh-record
   verification, receipt-last insertion, one commit attempt, and three-way
   commit recovery.
8. Existing normal historical replay does not re-evaluate later mutable heads or
   current semantic stop state.
9. Migrations 0001–0008, their resource bytes, catalog projections, checksums,
   and existing normal rows are immutable.
10. The migration system accepts only explicit forward catalog suffixes and
    refuses selected destructive migrations.
11. Active-cancel physical closure and a cancel-specific writer do not exist.

Do not promote target documentation into current implementation.

## Fixed strategic architecture decision

Treat the following as the selected target to reconcile—not as current
implementation:

### A. Additive branch-neutral anchor registry

The next migration introduces one immutable branch-neutral terminal-anchor
registry.

The registry:

- has exactly one row per `phase_basis_ref`;
- is unique across all normal and future cancellation profiles;
- binds one phase to exactly one registered terminal family;
- records enough safe identities and digests to select and verify that family;
- is not an independent second outcome or replacement semantic fact;
- cannot be used without complete verification of its selected branch family.

### B. Existing normal-family preservation

Migration 0008 and its tables remain byte-for-byte unchanged.

Every complete existing 0008 normal context/outcome/result/receipt family is
backfilled into the registry during migration 0009.

Backfill must:

- preserve all existing refs, digests, graph identity, committed-result identity,
  timestamps, and receipts;
- perform no row rewrite or rehash;
- register exactly one anchor for each complete existing normal family;
- fail closed before commit if any existing family is missing, partial,
  ambiguous, contradictory, or multiply joined;
- produce no invented cryptographic claim.

The existing 0008 family remains the full normal semantic and cryptographic
payload.

### C. New normal writes

After migration 0009, the normal terminal writer must register the anchor and
record the existing four-row normal family atomically.

The existing terminal-family receipt must remain the last terminal-family row.

The exact operation ordering may insert an immutable anchor reservation before
the branch rows when all referenced identities and digests are already
deterministically precomputed. The completed receipt and managed invariants must
prove that a committed anchor cannot remain without its exact complete family.

No old or alternate writer may commit a new unregistered 0008 family.

### D. Future cancel family

A future cancel family will use its own versioned branch-specific context,
outcome, result, receipt, and graph semantics where justified.

It must bind through the same registry.

It may not:

- own an independent phase-unique terminal key;
- bypass the registry;
- reinterpret an existing normal family;
- create a second terminal outcome for a phase;
- reuse normal-only graph or profile identifiers;
- infer terminal cancellation from request, acknowledgement, signal, exit,
  teardown, or reconciliation alone.

This reconnaissance does not design or implement the complete cancel family
except where necessary to prove that the anchor design can support it.

### E. Registry integrity posture

Do not invent a new self-digest during SQL backfill unless it can be derived
exactly from already committed bytes under a repo-accepted domain.

Prefer an immutable registry binding whose integrity is established through:

- exact phase and family identities;
- existing context/outcome/result/receipt refs and digests;
- graph profile and graph digest;
- committed-result digest;
- uniqueness constraints;
- immutable triggers;
- branch-family completion checks;
- managed-state invariants; and
- guarded reader reconstruction.

Determine whether an additional registry digest is necessary and, if so,
identify one exact derivation that works identically for existing backfilled
families and future families without custom migration-time hashing or fabricated
history.

### F. Recovery and corruption

After migration 0009:

- anchor lookup is the first terminal-family routing lookup after common guarded
  admission and disclosure;
- a valid anchor selects exactly one family version;
- the selected family is then fully reconstructed and verified;
- exact replay returns the original result and time;
- later mutable heads do not reinterpret historical closure;
- a missing anchor plus absence of every registered terminal-family route may
  support definite absence only under the existing full exclusion rules;
- anchor present/family missing, family present/anchor missing, inconsistent
  identities, graph mismatch, multiple family routes, or incomplete backfill
  are integrity failures or unresolved recovery—not absence;
- no recovery path authorizes retry, a second terminal family, or a new effect.

## Decisions this pass must freeze

Return one exact decision for each item:

1. Migration sequence, ID, resource filename, description, and application
   compatibility bounds.
2. Exact registry table name.
3. Exact registry columns and their semantic ownership.
4. Primary key and every uniqueness constraint.
5. Foreign keys that are safe and useful.
6. Where conditional branch-family relationships require triggers or managed
   invariants instead of foreign keys.
7. Exact immutability triggers.
8. Exact backfill `INSERT ... SELECT` relation from the complete 0008 family.
9. Exact in-transaction verification that backfill is total and one-to-one.
10. Fresh-install behavior when no normal rows exist.
11. Upgrade behavior when existing normal rows exist.
12. Exact normal-writer insert ordering while retaining receipt-last semantics.
13. Exact branch-family receipt or trigger rule requiring a matching anchor.
14. Exact anchor-first reader and replay behavior.
15. Exact definite-absence and commit-uncertainty recovery behavior.
16. Exact managed-state invariants required at writer admission and migration.
17. Whether the application schema generation remains 2 or advances, and why.
18. Exact old-binary and supported-prefix behavior.
19. Exact inventory changes: tables, triggers, explicit indexes, statements, and
    fixture expectations.
20. Exact treatment of currently normal-only row/value modules, readers, graph
    verification, and connected tests.
21. Exact contract wording that supersedes or refines the current
    “phase-unique context key” sentence.
22. The exact first implementation touched-path manifest.
23. The exact validation and provenance gate.

Do not leave competing schema options open.

## Important feasibility constraints

The selected design must remain compatible with the repository’s current
migration engine:

- no top-level transaction statements in SQL resources;
- no PRAGMA, ATTACH, DETACH, VACUUM, or custom migration runtime;
- no selected destructive migration;
- no dependency on SHA functions unavailable to SQLite;
- no custom Python row rewrite hidden outside the packaged migration;
- deterministic cumulative manifest generation;
- full schema and managed-invariant verification before migration commit;
- migration commit uncertainty resolved by existing migration recovery;
- old binaries refuse the newer tip;
- explicit migration from the exact 0008 prefix.

Confirm whether the migration framework’s post-statement, pre-commit schema and
managed-invariant verification is sufficient to make the backfill fail closed.
If not, specify the exact additional invariant or SQL-level guard required.

## Legitimate mismatch evidence seam

This tranche does not implement the pre-effect cancel block, but the anchor
design must not foreclose it.

State the future evidence boundary precisely:

- Coordinator-owned current-head, stop, and persisted-family mismatches may be
  proven from exact guarded reads.
- Source-authenticated denial, revocation, incompatibility, or unknown status may
  be used only under its owning source contract.
- Missing verifier evidence is not automatically a proven mismatch.
- No adapter absence, report, exception, or failure to contact a source may be
  converted into cancellation truth.
- The future unusable-basis block must bind one existing cancel decision and one
  exact mismatch evidence family without creating a replacement block decision.

Do not design the full source-ingest implementation in this turn.

## Governing surfaces to inspect

Inspect all relevant nested guidance and at least:

- AGENTS.md
- README.md
- .docs/architecture.md
- .docs/authority-boundaries.md
- .docs/rw0-terminal-outcome-physical-closure.md
- .docs/rw0-remote-worker-contact-phase-entry.md
- .docs/rw0-b1-pure-phase-values.md
- .docs/rw0-c2-durable-progression-decision-semantic-contract.md
- .docs/sqlite-bootstrap-and-migrations.md
- .docs/sqlite-operations-and-recovery.md
- .docs/sqlite-threat-model.md
- migration 0008 SQL
- migration catalog and migration execution/recovery code
- terminal row, value, contract, runtime, transaction, reader, and writer-entry
  modules
- normal terminal migration, transaction, replay, recovery, corruption,
  head-witness, and connected tests
- cumulative schema fixtures and repository policy tests
- safe examples or status wording that would become stale

Inspect docs, source, SQL, tests, fixtures, examples, and migration/recovery
behavior together.

## Read-only posture

This turn remains read-only.

Do not:

- edit, create, delete, rename, format, or regenerate files;
- run tests, scripts, migrations, or SQLite writes;
- open or initialize mutable databases;
- install dependencies;
- invoke services, workers, models, Codex children with write permission, ES,
  CP, Bridge, or external providers;
- contact networks;
- stage, commit, push, fetch, merge, rebase, reset, clean, stash, or create
  worktrees;
- inspect private database rows, secrets, credentials, environment files, or
  generated private evidence.

## Subagent workflow

Use exactly four read-only explorer agents in parallel.

No nested delegation. Make at most one retry for a failed explorer. Do not
replace a missing required report with parent inference. Close every explorer
before finishing.

Give each explorer a complete context capsule containing the repository,
baseline, current contract, fixed strategic decision, mutation authority,
restrictions, assigned scope, and required report format.

### Explorer 1 — Migration and backfill feasibility

Inspect the migration engine, catalog, schema manifest, managed invariants,
0008 SQL, migration tests, prefix migration, commit recovery, and SQLite
constraints.

Return:

- exact additive migration design;
- exact backfill relation;
- exact fail-closed verification;
- application-generation treatment;
- schema inventory changes;
- migration/recovery risks;
- any contradiction with the fixed architecture decision.

### Explorer 2 — Normal writer, reader, and recovery impact

Inspect the complete normal terminal writer, transaction integration, values,
rows, receipts, graph, readers, replay, recovery, head witness, disclosure, and
connected tests.

Return:

- exact normal-writer changes;
- insertion order preserving receipt-last semantics;
- anchor-first replay/read/recovery design;
- exact corruption and absence classifications;
- closed touched paths;
- normal behavior that must remain byte- and semantics-compatible.

### Explorer 3 — Terminal authority and future-cancel compatibility

Inspect governing terminal and active-cancel contracts and pure values.

Return:

- exact revised anchor wording;
- semantic ownership of registry versus branch families;
- why this is one terminal authority rather than dual truth;
- exact future cancel-family obligations;
- legitimate mismatch evidence boundary;
- contract tests required before cancel implementation;
- any unresolved authority contradiction.

### Explorer 4 — Validation, security, and audit planner

Inspect migration, transaction, replay, corruption, schema, artifact, and
provenance requirements.

Return:

- exact targeted and regression commands;
- existing-row and fresh-database migration cases;
- corruption and partial-family cases;
- generated-artifact risks;
- authority or security widening;
- independent audit roles;
- commit-gate prerequisites;
- commands that must not run concurrently.

## Required explorer report

SUBAGENT REPORT

Role:
Assigned scope:
Baseline observed:
Files and documents inspected:

Claim ledger:
- ID:
  Type: evidence | inference | uncertainty
  Layer: current contract | implemented source | fixed target | implementation detail
  Claim:
  Source: repository-relative-path:line
  Implication:
  Required docs/source/tests/schema impact:
  Confidence:

Fixed decision feasibility:
Exact proposed design:
Existing-row treatment:
Fresh-write treatment:
Reader/recovery treatment:
Migration implications:
Likely touched paths:
Validation implications:
Authority/security risks:
Contradictions or stop conditions:
Scope not inspected:
Mutation performed: no
Commands with side effects performed: no
Nested subagents created: no

Every material factual claim requires an exact repository-relative path and line.

## Parent synthesis requirements

Wait for all four explorers and independently verify the major claims.

Return:

### 1. Baseline verdict

Exact opening and final branch, HEAD, tree, parent, upstream, and status.

### 2. Contract reconciliation verdict

State whether the fixed branch-neutral anchor registry is authority-safe and
physically compatible with the current migration system.

Return exactly one:

- ANCHOR_EVOLUTION_CONTRACT_READY
- ANCHOR_EVOLUTION_CONTRACT_REQUIRES_REVISION
- ANCHOR_EVOLUTION_BLOCKED

### 3. Exact terminal authority model

Define:

- the one phase-unique terminal anchor;
- the role of the registry;
- the role of the existing normal family;
- the future role of a cancel family;
- which row or family owns terminal semantic truth;
- how the design avoids dual durable truth.

### 4. Exact migration decision

Provide one closed migration design containing all 23 decisions listed above.

Do not leave alternatives open.

### 5. Exact transaction and recovery design

Give ordered fresh-record, replay, read, definite-absence, corruption, commit
uncertainty, and migration-recovery algorithms.

Identify the single authoritative writer for every new durable fact.

### 6. Exact touched-path manifest

For each path state:

- create or modify;
- exact purpose;
- current contract versus target classification;
- docs/source/SQL/tests/fixture/example role.

No generic directories.

### 7. Implementation tranche plan

Freeze no more than these three boundaries:

1. terminal-anchor evolution and normal-family registration;
2. pre-effect cancel safety closure;
3. source-native cancel reconciliation joined to qualified live execution.

For each, state observable result, dependencies, non-goals, and replan
conditions.

Identify only tranche 1 as the next implementation candidate.

### 8. Validation and provenance plan

Provide exact commands and what each proves or does not prove.

Require full provenance because this changes:

- SQLite schema and migration semantics;
- terminal authority;
- replay and recovery;
- cross-profile uniqueness; and
- corruption classification.

### 9. Implementation stop conditions

Stop implementation later if:

- backfill cannot be total and one-to-one;
- an existing 0008 row must be rewritten;
- a new digest would be fabricated;
- normal closure can commit without an anchor;
- an anchor can commit without one complete family;
- two branch families can bind one phase;
- migration requires a destructive definition;
- normal replay semantics change;
- definite absence can be inferred from a missing receipt or registry row alone;
- old binaries can write against the newer schema;
- the future cancel family would still need an independent phase-unique store.

## Closeout

Confirm:

- no repository mutation occurred;
- no test, script, migration, database write, service, or network operation ran;
- all four explorers completed and closed;
- final HEAD/tree/status match the opening baseline.

End with exactly one standard reconnaissance verdict:

RECONNAISSANCE_READY
RECONNAISSANCE_PARTIAL
RECONNAISSANCE_BLOCKED
SUBAGENT_UNAVAILABLE
```

The key sequencing correction is that **terminal-anchor evolution is now the next Coordinator implementation candidate**, not full active-cancel closure. Full terminal `cancel` remains dependent on source-authenticated request, process, teardown, and custody observations; the current repository only has supplied evidence and artificial process mechanics. The clear causal ordering Codex recovered remains valid, but the storage authority must be settled first. Pasted text

### Sources

- Active-cancel reconnaissance verdict, clean baseline, and prerequisite matrix: Pasted text
- Single-anchor migration block and unresolved contract decisions: Pasted text
- Validation requirements and no-mutation closeout: Pasted text
- Earlier roadmap’s explicit anchor replan condition: Pasted text
- Project protocol requiring reconciliation before mutation when an authority decision is unresolved: Governed Execution Codex Subage…

**Confidence:** 0.96 that Codex’s block is correct; 0.84 that an additive branch-neutral registry is the best authority-preserving design; 0.68 on its exact SQLite realization until this focused reconciliation verifies backfill, trigger, invariant, and receipt-order feasibility.
