## Verdict

The `BLOCK` verdict is correct, but the remaining issue is now narrowly isolated to **test adequacy**, not production code, migration SQL, authority, or architecture.

`T2-R1` requires one exact-0008 database containing multiple coherent terminal families. The current test independently verifies all 21 anchor fields, but each database contains only one family, so it cannot reveal a backfill join that mixes coordinates across families. This sharpens the original T2 requirement rather than reopening it. Pasted text

The repair should therefore modify exactly:

```text
tests/test_sqlite_rw0_terminal_anchor_migration_0009.py
```

It should not change production source, migration 0009 SQL, the migration catalog, documentation, or the already accepted M1/M2/T1/T3 repairs. The prompt requires two complete families in one exact-0008 database, independently assembled 21-field expected anchors, cross-family exclusion checks, and byte-for-byte preservation of all historical rows.

After any test-byte change, the repaired candidate requires new provenance and another fresh read-only independent audit; the prior audit cannot accept changed bytes. Governed Execution Codex Subage… The handoff remains on the active v1 provenance chain rather than silently switching recipes. Governed Execution Provenance G…

**Prompt to execute in the original workspace-write implementation Codex conversation:**

`RW0_TERMINAL_ANCHOR_EVOLUTION_T2_R1_TEST_REPAIR_PROMPT.md`

RW0_TERMINAL_ANCHOR_EVOLUTION_T2_R1_REPAIR_HANDOFF.zip[Download the complete T2-R1 repair handoff ZIP](sandbox:/mnt/data/RW0_TERMINAL_ANCHOR_EVOLUTION_T2_R1_REPAIR_HANDOFF.zip)

ZIP SHA-256:

```text
e11db4f7ef0ac57fdaa5dda24cc0cc557ae78cc57e077c276a3015d9d1d457b1
```

The ZIP contains the named prompt, `README_FIRST.md`, the normalized blocking re-audit finding, the prior repair closeout summary, the exact v1 provenance recipe, and handoff checksums.

**Sources:** Fresh independent re-audit supplied in your message; original T2 audit finding: Pasted text; repair and mandatory re-audit protocol: Governed Execution Codex Subage….

**Confidence:** provenance-handoff confidence 0.99; repair-scope confidence 0.98; implementation confidence remains 0.88 until the multi-family case passes and receives fresh independent acceptance.
