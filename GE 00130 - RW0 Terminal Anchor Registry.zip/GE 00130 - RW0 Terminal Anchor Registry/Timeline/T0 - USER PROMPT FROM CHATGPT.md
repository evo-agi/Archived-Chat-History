# Coordinator–Control Plane Demise Reconciliation, Mechanics Harvest, and Roadmap Reset

Act as the cognitive engineering lead for a bounded, read-only reconciliation between Governed Execution Coordinator and the demised Control Plane, followed by separate roadmaps for:

1. Coordinator’s own next capabilities; and
2. Coordinator’s direct integration with Execution Substrate.

This is discussion and architecture work only.

Do not mutate repositories, create implementation patches, change schemas, run tests or services, install dependencies, migrate data, stage, commit, push, create worktrees, or initiate an implementation program.

## Fixed product direction

Control Plane is demised.

That means:

- Control Plane is not being revived as a target product;
- it is not a target peer of Coordinator;
- it is not a permanent durable-development authority;
- it is not a required service in the target autonomous-development topology;
- its Temporal workflows, SQLite state, task state, checkpoints, projections,
  escalations, UI state, reports, chat/session state, and generated artifacts do
  not become Coordinator program truth;
- no dual-write or synchronization architecture between Control Plane and
  Coordinator is presumed;
- no bulk CP-state migration into Coordinator is presumed;
- no future work should preserve CP architecture through inertia;
- new CP feature development is out of scope except a separately justified
  compatibility, preservation, migration, or retirement correction.

Control Plane may still contain:

- maintained MVP/demo compatibility;
- temporary ES compatibility obligations;
- reusable implementation mechanics;
- useful security or operator-interface patterns;
- historical evidence;
- migration and retirement obligations.

The objective is to identify those items without reactivating Control Plane.

Coordinator is the intended durable autonomy core.

Execution Substrate remains execution admission/runtime authority, including
runtime-profile compatibility, submission and response-loss recovery, lifecycle
observation, cancellation boundaries, and retained execution results.

Git owns repository object and ref truth. CI and validating runtimes own observed
validation results. Model reasoning supplies proposals and judgment; model
sessions, ChatGPT state, CP state, reports, and connector state are not durable
program truth.

## Current baselines and evidence layers

### Coordinator

Repository:
  /Users/ds/Repositories/Governed Execution Coordinator/

Current published baseline:
  branch: trunk_dev
  commit: 69fc836dbaa0e2124b427bc9611de2e0fba77040
  tree: 8c3b409d1e0c9013ae519d23016af266b3c38cd8
  parent: 3be0096c163b456c9975326be3eb2c30d2b4bbd1
  subject: docs: correct RW0 normal terminal closure current status (#19)

Normal-terminal source integration anchor:
  commit: 3be0096c163b456c9975326be3eb2c30d2b4bbd1
  tree: bc10382edd1b2c097fc729e4e168d72e710391fe

The current status-only successor records the normal-terminal source as an
integrated capability and preserves older candidate/local-commit passages as
historical evidence.

The latest Project-source snapshot is named:
  Governed Execution Coordinator - Snapshot - 2026-10-31.zip

Treat that snapshot as an inspectable baseline only if its contents match the
current commit/tree above. State any mismatch rather than silently substituting
one source for another. Current Git objects and the live repository establish
current repository truth.

Current implemented Coordinator capability includes, within its bounded private
and artificial-offline contracts:

- durable development-program and work state;
- guarded program initialization and author-effect establishment;
- Section 41 pre- and post-execution proposal recording;
- RW0-C1 evidence admission;
- private artificial-offline planner/worker/capsule execution;
- private artificial-offline validation, independent review, and review-model
  closure;
- physical P0 admission-history recording;
- physical P1 five-branch progression decision;
- separate normal terminal closure for:
    accept, repair, replan, terminal_reject, block.

The current implementation does not add:

- active-cancel terminal closure;
- a qualified live supplier/custody path;
- production model/provider invocation;
- production worker or qualified remote contact;
- reliable Coordinator-to-ES execution routing;
- Coordinator-owned Git or publication effects;
- a public service, queue consumer, scheduler, or autonomous runtime loop;
- automatic repair/replan successor launch.

### Control Plane

Repository:
  /Users/ds/Repositories/Control Plane/

Published GitHub main baseline:
  commit: 2871486a8f4f232e9e363079c9156a010d4a65ca
  tree: 7b5b0e233b709d746d54ea05f5cc9362f5062d95

Available Project-source snapshot:
  Control Plane - Snapshot - 2026-07-23.zip

Inspect the current local CP checkout and distinguish it from:

- published GitHub main;
- the July 23 snapshot;
- any unpublished or dirty local state;
- maintained MVP/demo compatibility;
- historical evidence;
- later chat-decided strategic direction.

Do not silently treat either published main or the July snapshot as complete
current CP truth.

### Execution Substrate

Repository:
  /Users/ds/Repositories/Execution Substrate/

Current published baseline:
  branch: trunk_dev
  commit: 1453e2f33f1c9564ebaade2ef0e71184a4a0e034
  tree: ff1b60430aefbc28c14fecb376ca22e969bfa278

Use ES read-only only where needed to establish:

- current CP compatibility obligations;
- control-plane-normal-shell/v1;
- submit, cancellation, lifecycle, and retained-result contracts;
- current reliable-submit status and blockers;
- removal conditions for CP-specific compatibility.

The non-enabling outside-observer work is paused and is not an automatic
dependency of this reconciliation.

Linux restoration and reliable-submit work may be active in separate lanes.
This reconciliation must not mutate, redirect, or block those lanes merely
because it inspects their owning contracts.

## Central decision

Do not ask:

> How should Coordinator integrate with Control Plane?

Ask:

> Which CP responsibilities remain bounded demo/current authority, which
> mechanics are worth re-deriving behind Coordinator-native contracts, which
> compatibility edges must survive temporarily, what historical material must
> be retained, and what can eventually be frozen or retired without creating a
> second source of program truth?

## Primary questions

### 1. Baseline and evidence-layer reconciliation

For each repository, distinguish:

- current owning-repository contract;
- implemented source behavior;
- accepted target-only contract;
- compatibility edge;
- historical/demo evidence;
- unpublished local overlay;
- chat-decided strategic direction;
- inference and uncertainty.

State conflicts explicitly. Do not silently rewrite one layer into another.

### 2. Authority overlap

For every materially overlapping capability, identify:

- CP’s current or historical owner;
- Coordinator’s current implemented owner;
- Coordinator’s accepted target owner;
- ES, Git, CI, or validating-runtime ownership where applicable;
- whether the apparent overlap is real, superficial, or semantically different;
- the recommended disposition.

Examine at minimum:

- objective/intent intake;
- startup and planning;
- task/work-item progression;
- attempts and retries;
- revise, repair, and replan behavior;
- checkpoint and workspace progression;
- candidate and capsule custody;
- validation and independent review;
- model review;
- acceptance and rejection;
- block, on-hold, and escalation;
- cancellation request, observation, and terminal closure;
- Git and publication effects;
- notification delivery;
- operator intervention;
- read models, monitoring, and UI;
- experiment and comparison workflows.

### 3. Semantic non-mapping

Do not map similarly named states automatically.

At minimum, evaluate and state whether there is any valid mapping between:

- CP `on_hold` and Coordinator `block`;
- CP task completion and Coordinator acceptance;
- CP retry/revise and Coordinator repair or replan;
- CP checkpoint/workspace state and Coordinator capsule/candidate custody;
- CP rejected/failed/completed and Coordinator terminal outcomes;
- CP Temporal workflow state and Coordinator durable program state;
- CP escalation state and Coordinator progression decisions;
- CP substrate attempt summaries and ES runtime/lifecycle facts.

Where no safe direct mapping exists, say so.

### 4. Reusable mechanics and concepts

Identify useful CP mechanics that may be re-derived behind Coordinator-native
contracts, including where present:

- Temporal workflow supervision;
- task-attempt execution adapters;
- workspace preservation and restoration;
- delayed terminalization after cancellation;
- escalation and notification delivery mechanics;
- effect/outbox deduplication;
- operator console and read-model patterns;
- WebAuthn or passkey step-up mechanics;
- provider/model adapters;
- Codex invocation and process supervision;
- ES normal-shell integration;
- experiment and comparison mechanics;
- observability and monitoring.

Classify each candidate as exactly one of:

- REUSE CONCEPT ONLY;
- RE-DERIVE MECHANIC BEHIND COORDINATOR CONTRACT;
- PRESERVE TEMPORARY COMPATIBILITY;
- DEMO/REFERENCE ONLY;
- HISTORICAL EVIDENCE ONLY;
- RETIRE;
- UNRESOLVED.

Do not copy CP durable-state semantics merely because source is available.

For every proposed reuse, identify:

- the useful mechanic;
- the CP assumptions that must not survive;
- the Coordinator-native authority boundary;
- whether the reuse accelerates an already-selected capability;
- whether it creates a new permanent dependency on demised CP.

### 5. CP compatibility, freeze, and retirement

Identify what must remain temporarily operational, readable, or preserved,
especially the current CP-to-ES normal-shell compatibility edge.

For each item, define:

- current owner;
- current user or dependency;
- current contract;
- preserve/freeze/retire disposition;
- removal trigger;
- retirement evidence;
- whether CP code must remain runnable, merely readable, or can be archived.

Default direction:

- freeze CP as demised demo/reference;
- preserve only explicit bounded compatibility;
- do not develop new CP orchestration capability;
- avoid new CP dependencies;
- retire CP when compatibility, demo, and historical obligations are satisfied.

Do not delete or mutate CP in this task.

### 6. Historical state and artifact preservation

Determine whether any CP Temporal history, SQLite state, workspaces, reports,
experiments, or artifacts require preservation.

Default:

- historical evidence remains historical;
- no bulk migration into Coordinator;
- no transformation of CP state into Coordinator authority;
- retain only what supports a named compatibility, audit, demo, migration, or
  historical obligation.

Distinguish evidence preservation from runtime dependency.

### 7. Coordinator roadmap after normal terminal closure

Using the current Coordinator baseline, recommend the shortest credible sequence
toward an operating autonomous-development loop.

Separate:

- implemented capability;
- target-only contract;
- compatibility work;
- missing operating capability;
- live-proof prerequisite;
- optional future hardening.

Consider at minimum:

- active-cancellation terminal closure;
- production provider/model invocation;
- production worker invocation;
- repair/replan successor progression;
- standing-authority and live-custody integration;
- public/private service boundary;
- durable scheduling/queue consumption;
- Git-effect and publication handling;
- durable operating-loop recovery;
- operator/read surfaces;
- direct-local bootstrap retirement.

Do not presume every missing item deserves a standalone tranche.

For each recommended tranche, state:

- observable operating result;
- authority owner;
- implementation dependency;
- what remains blocked;
- why it advances accepted capability rather than representation alone;
- evidence that would force replanning.

### 8. Coordinator–ES integration roadmap

Produce a separate roadmap for Coordinator consuming ES directly as execution
authority.

Consider at minimum:

- source-grounded resolved execution-plan extraction;
- reliable keyed submit;
- caller-to-ES response-loss recovery;
- ES-to-Nomad registration-response uncertainty;
- worker command/result/capsule contracts;
- attempt/effect correlation;
- retained results;
- cancellation request and terminal observation;
- runtime-profile compatibility;
- qualified live execution;
- direct-local bootstrap retirement;
- control-plane-normal-shell/v1 compatibility and removal.

Do not make CP a permanent bridge between Coordinator and ES.

State the minimum ES capability needed for the first Coordinator-operated
productive route and the minimum Coordinator capability needed to consume it.

### 9. Immediate sequencing decision

Recommend:

- the next one or two Coordinator implementation-bearing tranches;
- the next one or two Coordinator–ES integration tranches;
- which work may proceed independently;
- the join point;
- which CP compatibility obligations block a step, and which do not.

Do not make the CP reconciliation a prerequisite for unrelated work unless a
specific authority or compatibility conflict requires it.

## Read-only reconnaissance

Repository inspection is required before final architecture conclusions.

Use Codex in read-only mode.

A single reconnaissance may inspect all three repositories, but it must:

- name each exact local path;
- include a self-contained context capsule;
- distinguish current contract from strategic target;
- inspect docs, source, tests, schemas/migrations, scripts, configs, examples,
  and artifacts appropriate to each claim;
- prohibit mutation, tests with side effects, installs, service operations,
  staging, commits, pushes, fetches, worktree creation, and live network/runtime
  actions;
- cite exact repository-relative paths and lines;
- preserve disagreement and uncertainty;
- state where inspection stopped;
- verify each repository baseline and report mismatches rather than changing
  state.

Give every explorer a self-contained context capsule.

Inspect, as relevant:

Coordinator:
- AGENTS.md;
- README.md;
- PLANS.md if present;
- .docs/architecture.md;
- autonomous-development operating model;
- software-development progression boundary;
- worker execution boundary;
- D1/D2 owners;
- post-D2 native proposal admission;
- P0/P1 physical implementation;
- normal terminal closure;
- cancellation and live-provider seams;
- relevant migrations, readers, writers, service boundaries, and tests.

Control Plane:
- AGENTS.md/guidance;
- README.md;
- .docs/architecture.md;
- invariants;
- execution-substrate integration;
- development-queue non-goal, where present;
- hybrid integration ADR, where present;
- long-running operator mode;
- Temporal workflows and task lifecycle;
- escalation and notification mechanics;
- workspace/checkpoint ownership;
- WebAuthn/passkey paths;
- provider/Codex adapters;
- console/read models;
- configs, examples, and tests.

Execution Substrate:
- AGENTS.md;
- PLANS.md;
- architecture and lifecycle boundaries;
- reliable-submit contracts and implementation;
- current submit/cancel/result paths;
- runtime-profile compatibility;
- control-plane-normal-shell/v1 ownership and removal condition;
- relevant tests and examples.

Return substantive findings inline.

Create no architecture ZIP, freeze manifest, preservation package, or external
report artifact.

## Required first response

First make an independent engineering judgment from the supplied direction and
current known baselines.

Then provide one complete self-contained read-only Codex reconnaissance prompt.

Do not issue an implementation prompt in the first response.

The first response must include:

1. provisional reconciliation thesis;
2. highest-risk authority overlaps;
3. likely reusable CP mechanics;
4. likely retirement and compatibility boundaries;
5. the exact questions reconnaissance must settle;
6. one complete Codex prompt;
7. explicit non-goals and stop conditions.

Do not ask me to select internal files, schemas, tests, mechanics, or ordinary
risk treatment.

## Required post-reconnaissance output

After the Codex report returns, provide:

1. baseline and evidence-layer reconciliation;
2. authority-overlap matrix;
3. semantic non-mapping table;
4. reusable-mechanics matrix;
5. CP compatibility/freeze/retirement plan;
6. historical-state preservation recommendation;
7. Coordinator roadmap;
8. Coordinator–ES integration roadmap;
9. next one or two implementation-bearing tranches for each roadmap;
10. explicit non-goals and replan conditions;
11. inspection limits.

End with this concise decision record:

- CP STATUS:
- TARGET AUTHORITY:
- TEMPORARY COMPATIBILITY:
- REUSABLE MECHANICS:
- RETIREMENT TRIGGER:
- CURRENT COORDINATOR BASELINE:
- NEXT COORDINATOR CAPABILITY:
- CURRENT ES BASELINE:
- NEXT COORDINATOR–ES CAPABILITY:
- UNRESOLVED DECISIONS:

## Non-goals

Do not:

- revive Control Plane;
- create a CP–Coordinator dual-authority design;
- synchronize CP Temporal state with Coordinator SQLite;
- migrate CP run history by default;
- make CP a permanent Coordinator-to-ES bridge;
- copy CP schemas or state-machine vocabulary wholesale;
- initiate implementation before reconciliation is complete;
- delay unrelated Coordinator or ES work without a named conflict;
- create another large artifact or chat-history dependency;
- treat chat state as product authority.

No previous chat history is required. Use current repositories, matching
snapshots, and this context as the starting point.
