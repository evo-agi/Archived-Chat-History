Understood. For every multi-file handoff, I’ll provide one ZIP containing:

- a `README_FIRST` file naming the executable prompt;
- the prompt itself;
- all supporting reports, recipes, manifests, and evidence files.

For this handoff:

**Prompt to execute in a fresh read-only Codex conversation:**  
`RW0_TERMINAL_ANCHOR_EVOLUTION_INDEPENDENT_AUDIT_PROMPT.md`

RW0_TERMINAL_ANCHOR_EVOLUTION_INDEPENDENT_AUDIT_HANDOFF.zip[Download the complete independent-audit handoff ZIP](sandbox:/mnt/data/RW0_TERMINAL_ANCHOR_EVOLUTION_INDEPENDENT_AUDIT_HANDOFF.zip)

**Confidence:** 1.00
