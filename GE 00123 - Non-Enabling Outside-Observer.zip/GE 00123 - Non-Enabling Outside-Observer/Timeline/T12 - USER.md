Here is Codex's response:

# R6J-R9.28/Stage-A plan

**Planning verdict: `R6J_R928_STAGE_A_CONTRACT_ONLY_PLAN_READY`.** The bounded tranche can add governing documentation, private untrusted data shapes, static validators, and contract tests. **`AUTHORITY_DEPENDENT_ADOPTION_NOT_READY`** remains in force: the accepted artifact assumes an existing signed `RunEntryV4` issuer, key suite, and atomic permit ledger, but the inspected ES checkout does not establish that contract. This plan selects none of the proposed components as that issuer.

I treated the attached `PROMPT.md` as the task the user asked me to execute. The other capsule and owner contents were evidence; [AGENTS.md](</Users/ds/Repositories/Execution Substrate/AGENTS.md:25>) and the current repository docs govern repository work. **This turn was read-only:** no files were changed, programs from archives executed, or tests run.

## Inputs and current boundary

Current reads confirmed the [completion capsule](/Users/ds/Downloads/R6J_R928_STAGE_A_CONTRACT_ONLY_PLAN_COMPLETION_20261027_01.zip) at 110,511 bytes, SHA-256 `829dc9829f21f9bacb604b2c4ca06d60108746bd48ccc7a355251d2aadd4fb03`; its eight manifest-listed files match their sizes, modes, and hashes. The [R9.28 delivery envelope](/Users/ds/Downloads/OWNER_R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_28_COMPLETED_READY_FOR_FRESH_REVIEW_DELIVERY_ENVELOPE.zip) remains 168,307,308 bytes with SHA-256 `5b637a7247af865c888590863b021db9e5aa7fc15dd91aed50ad552a2cbad33c`. Its embedded owner remains 167,125,065 bytes with SHA-256 `b9c1f5933155d39cf5f656f9ca6a69d27fa86c7ccac4bdfd32aee57b829bb647`. The capsule’s accepted-review ZIP matches SHA-256 `fc0a604e8fd294840f69c623aeba94754c1bad4088d3f3e0f54bb0b9d837a9f6`; its `VERDICT.json` and `REVIEW_REPORT.md` match the requested hashes. I reused that review’s bounded acceptance and did not rerun its 505 controls or 700 probes.

The owner’s `AUTHORITY_AND_PERMIT_CONTRACT.json` excludes ES admission, the observer, receiver, app, and runtime helper from permit-consumption authority. Its `STAGE_BOUNDARY_CONTRACT.json` allows Stage A source/docs, exact private schemas, static validators, and tests with **no mutable authority or production wiring**. The independent review accepts artifact design; it does not establish repository behavior or authorize activation. Preserve the sealed owner and the navigation erratum **F01–F05 → R9.28.2–R9.28.6** without an R9.29 repair.

In the checkout, [PLANS.md](</Users/ds/Repositories/Execution Substrate/PLANS.md:97>) and the [hybrid ADR](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/hybrid_integration_architecture_adr.md:96>) keep authority issuance and worker/runtime handoff reopened. Current ES admission, Nomad lifecycle projection, and runtime handoff remain governed by [PLANS.md](</Users/ds/Repositories/Execution Substrate/PLANS.md:2198>); caller SPIFFE allowlisting remains active in the [lifecycle contract](</Users/ds/Repositories/Execution Substrate/.docs/execution_lifecycle/contracts.md:165>). The existing workload JWT endpoint in [runtime_identity_handoff.md](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/runtime_identity_handoff.md:27>) is separate from the proposed observer/receiver endpoint. The current [supervisor](</Users/ds/Repositories/Execution Substrate/es/runtimehelper/supervisor.go:67>) starts and waits for its child; the proposed PID1 observer is not installed behavior. `control-plane-normal-shell/v1` remains a **Temporary compatibility edge** under the [profile matrix](</Users/ds/Repositories/Execution Substrate/.docs/execution_lifecycle/contracts.md:343>).

This is a doc-first extension within **Reopened redesign seams**, not a change to those current invariants. The R9.28 model and review results are target and report-only evidence. The existing [shared evidence kernel](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/shared_kernel.md:25>) is not expanded.

## Opening and closing baseline

Read-only Git observations at both opening and closeout matched: root `/Users/ds/Repositories/Execution Substrate`, branch `trunk_dev`, upstream `origin/trunk_dev`, HEAD `b92bd9884106154d25342e1573dcc4c312311436`; **66 modified, 17 untracked, zero staged** paths. All 83 listed paths are regular files. The NUL-delimited status SHA-256 was `35458ebe1f4ebda81675d53f670b11715586a4c927c3896f05044b91cdeb31b7` at both checks; the text status SHA-256 was `a4c2337504cb9a1de6c42a6b319f3171d759a6a1fda87a750b78e0c7ee7af98c`. The unstaged diff-stat SHA-256 remained `9b31e0628211a3020404d4ea82f61bbf894124981b70efa7542e17e657117fa6`.

**The complete safe changed-path inventory** is below. Each row gives an absolute directory followed by every changed basename in it; `M` and `??` retain Git’s meanings.

| Status | Absolute directory | Basenames |
|---|---|---|
| M | `/Users/ds/Repositories/Execution Substrate` | `PLANS.md`, `README.md`, `docs_contract_test.go`, `remote_alpha_check_es_writable_state_readiness_test.go`, `remote_alpha_es_service_user_rollback_rehearsal_test.go`, `remote_alpha_migrate_es_service_user_test.go`, `remote_alpha_operator_test.go`, `remote_alpha_plan_old_root_cleanup_test.go`, `remote_alpha_prepare_es_writable_state_ownership_test.go`, `remote_alpha_runtime_security_boundary_check_test.go`, `remote_alpha_stage_es_service_user_migration_test.go`, `remote_alpha_stage_es_writable_state_readiness_check_test.go` |
| M | `/Users/ds/Repositories/Execution Substrate/.docs/execution_lifecycle` | `contracts.md`, `design.md`, `es_execution_admission_model.md`, `implementation.md`, `reliable_submit_persistence_and_concurrency.md`, `submit_idempotency_correlation_and_recovery.md` |
| M | `/Users/ds/Repositories/Execution Substrate/.docs/system_overview` | `artifact_publication_storage.md`, `boundaries.md`, `capability_probing.md`, `configuration.md`, `contracts.md`, `remote_alpha_beta_es_privilege_boundary_assessment.md`, `remote_alpha_beta_es_privileged_operation_matrix.md`, `remote_alpha_beta_es_runtime_ownership_normalization.md`, `remote_alpha_beta_es_writable_state_ownership.md`, `remote_supported_host_alpha.md`, `runtime_config_ownership.md`, `supported_linux_host_qualification.md` |
| M | `/Users/ds/Repositories/Execution Substrate/.runbooks/execution` | `v1_submit_runtime_identity_reference.md`, `v1_submit_static_script.md` |
| M | `/Users/ds/Repositories/Execution Substrate/.runbooks/system` | `v1_bringup.md` |
| M | `/Users/ds/Repositories/Execution Substrate/es/admission` | `authorityhandoff.go`, `authorityhandoff_test.go`, `executionpackage.go`, `executionpackage_test.go`, `lifecycle.go`, `lifecycle_nomad_test.go`, `lifecycle_test.go`, `mounts.go`, `mounts_test.go`, `ownership.go`, `policy_payload.go`, `reliable_submit_guardrails_test.go`, `results.go`, `results_test.go`, `service.go`, `service_direct_test.go`, `submit.go`, `submit_test.go`, `workstream_c_guardrails_test.go`, `writablestate_preflight.go`, `writablestate_readiness_test.go` |
| M | `/Users/ds/Repositories/Execution Substrate/es/app` | `proof_codex_shim_test.go`, `result_integration_test.go`, `staging_cleanup_integration_test.go`, `submit_integration_test.go` |
| M | `/Users/ds/Repositories/Execution Substrate/scripts/internal` | `operator_failures.sh`, `remote_alpha_check_es_writable_state_readiness.sh`, `remote_alpha_es_service_user_rollback_rehearsal.sh`, `remote_alpha_migrate_es_service_user.sh`, `remote_alpha_plan_old_root_cleanup.sh`, `remote_alpha_prepare_es_writable_state_ownership.sh`, `remote_alpha_stage_es_writable_state_readiness_check.sh` |
| M | `/Users/ds/Repositories/Execution Substrate/scripts` | `remote_alpha_operator.sh` |
| ?? | `/Users/ds/Repositories/Execution Substrate/es/admission` | `execution_roots.go`, `execution_roots_darwin.go`, `execution_roots_darwin_test.go`, `execution_roots_linux.go`, `execution_roots_linux_test.go`, `execution_roots_test.go`, `resolved_execution_plan.go`, `resolved_execution_plan_test.go`, `resource_limits.go`, `resource_limits_test.go`, `staging_custody.go`, `staging_custody_darwin.go`, `staging_custody_darwin_test.go`, `staging_custody_linux.go`, `staging_custody_linux_test.go`, `staging_custody_test.go`, `tranche_b2_privacy_guardrails_test.go` |

No changed path was excluded from this *name/type* inventory as a credential file by its path. I did not inspect every unrelated file’s contents, hash ignored files, or produce credential-derived digests. The preceding conversation had no byte-complete opening manifest; matching status and diff-stat hashes do **not** prove that all 83 file contents matched that earlier turn.

Only two proposed paths overlap dirty work:

| Existing planned path | Status; type, mode, size | Current SHA-256 | Current HEAD-diff SHA-256 |
|---|---|---|---|
| [PLANS.md](</Users/ds/Repositories/Execution Substrate/PLANS.md>) | M; regular, `0644`, 217,504 bytes | `b3a18e6ee2375018ab993129572495e7e9314d81187afa11bd25ad6986035f55` | `bf76c139e8b73ad83b3c3a1135071f7f6401e24085dcec6922388b872553537f` |
| [boundaries.md](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/boundaries.md>) | M; regular, `0644`, 68,229 bytes | `43c95f0e2b4778764a1450d872af2be422fc844de83d991ee22ebd608d9ab406` | `0aceae4e2390023580b9d88f0e421aaac477fc64409c29293210da7baf98358a` |

Their inspected existing diff hunks do not occupy the proposed Stage A insertion sections. The other nine proposed paths below are absent. This is a safe planning overlap, subject to a fresh byte check before any later write.

## Frozen touched-file set and order

The later sole writer’s allowed set is **exactly these 11 paths**; all other pre-existing changes are protected. Follow the [doc-first order](</Users/ds/Repositories/Execution Substrate/AGENTS.md:79>): plan, governing docs, tests, then code.

| Path | Planned content |
|---|---|
| [PLANS.md](</Users/ds/Repositories/Execution Substrate/PLANS.md>) | Add a namespaced `R6J-R9.28/Stage-A` pointer and gate: bounded accepted design, unestablished issuer premise, inert scope, deferred authority decisions, unchanged ES priorities. |
| [boundaries.md](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/boundaries.md>) | State current ES admission/runtime and SPIFFE ownership alongside proposed observer/receiver nonownership. No issuer or ledger assignment by inference. |
| `/Users/ds/Repositories/Execution Substrate/.docs/execution_lifecycle/outside_observer_protocol.md` | New target-only contract: artifact identities and erratum, selected structural schemas, journal/cache role, current JWT endpoint separation, exclusions, later stage gates, and the permit/receipt syntax discrepancy below. |
| `/Users/ds/Repositories/Execution Substrate/outside_observer_docs_contract_test.go` | New root contract tests for the required doc statements and AST/source guards against production imports, API routes, config fields, job wiring, and supervisor activation. |
| `/Users/ds/Repositories/Execution Substrate/es/internal/outsideobserverprotocol/canonical.go` | Private `parseCanonicalV2`/`encodeCanonicalV2` for exact canonical JSON v2 bytes. |
| `/Users/ds/Repositories/Execution Substrate/es/internal/outsideobserverprotocol/canonical_test.go` | Canonical positive/negative tables, exact integer versus boolean checks, malformed bytes, limits, and deterministic parser controls. |
| `/Users/ds/Repositories/Execution Substrate/es/internal/outsideobserverprotocol/schema.go` | Untrusted Go representations for the selected frame, Ack, journal records, five evidence payloads, two Hellos, and internal `DerivedSourceState`. |
| `/Users/ds/Repositories/Execution Substrate/es/internal/outsideobserverprotocol/validate.go` | `ParseEvidenceFrameV1`, `ParseAckV1`, `ParseJournalHeaderV2`, `ParseJournalFrameV2`, `ParseJournalCommitV2`, `ParseObserverHelloV1`, `ParseReceiverHelloV1`, and payload dispatch. Each returns only untrusted data or an error. |
| `/Users/ds/Repositories/Execution Substrate/es/internal/outsideobserverprotocol/validate_test.go` | Small native valid examples and one-field mutations for closed fields, bounds, enums, base64/hex syntax, decoded payloads, and exact integer typing. |
| `/Users/ds/Repositories/Execution Substrate/es/internal/outsideobserverprotocol/domain.go` | `ComputeJournalSegmentID` using the selected four-field canonical core and domain. No authority or session result. |
| `/Users/ds/Repositories/Execution Substrate/es/internal/outsideobserverprotocol/domain_test.go` | Independent expected digest vector; change each core field; prove non-core journal/session fields do not change the segment ID and that wider journal identity is distinct. |

This leaves the existing hybrid ADR, lifecycle contracts, implementation guide, admission source, `docs_contract_test.go`, shared kernel, `go.mod`, and all examples/scripts untouched. The private placement follows the existing ES `internal` convention and has no current production import.

## Exact static ceiling and deferred gates

Canonical validation is bounded to the owner’s `r6j-canonical-json/v2`: at most 4 MiB, depth 128, strict UTF-8, sorted decoded keys, no duplicates, byte-identical re-encoding, ASCII integer grammar, and refusal of booleans where integers are required. `EvidenceFrameV1` has its closed 16 fields, selected payload schemas and local payload/record hash domains; `AckV1` has **exactly 11 fields**, at most 16,384 canonical bytes, and exact integer bounds. The three journal V2 records and both Hello V1 messages get closed fields, literals, syntax, fixed limits, and only local computations possible from supplied values. Their parsed values remain **untrusted claims**. `DerivedSourceState` is an internal representation only: no caller-supplied cache acceptance, serializer, or state store.

No Stage A Go permit, consume-request, receipt, or `RunEntryV4` type or executable validator is in this set. Their proposed field tables remain in the new doc. There is a concrete deferred cross-object conflict: the owner permit contract allows `issuer_id`/`key_id` as ASCII length 1–128, while its receipt wire registry applies the narrower lowercase `ascii_id_1_128` pattern. A permitted identifier may therefore fail receipt syntax. This is a **design-governance issue for the future authority path**, not a reason to weaken either accepted field silently. The `SOURCE_STATE/v2` schema literal also appears in accepted model source but was not found as an explicit frozen architecture literal; Stage A does not serialize it.

Structural success must never be named or returned as a verified entry, authenticated permit, consumed receipt, approved session, or launch permission. There is no signature verifier, `verified=true` input, fake successful verifier, key lookup, trust root, issuer custody, ledger, live endpoint, persistence, process/Wait/reap logic, recovery engine, or job construction in this tranche.

| Accepted correction | Stage A acceptance | First later executable gate |
|---|---|---|
| **F01** | Compute `SHA256("R6J-OBS-JOURNAL-SEGMENT/v1" \|\| NUL \|\| canonical {run_id,source_instance_id,epoch,endpoint_nonce})`; test distinction from wider journal identity. | Bind it to recovered transactions and real sessions. |
| **F02** | Reject malformed or mis-typed eleven-field Ack objects; enforce byte and integer bounds. | **Stage B:** bind every Ack field to the internally recovered final commit *before* accepting chronology `ack_sha256`. |
| **F03** | Document exact record/event shapes only. | **Stage B:** recover from the supplied raw journal image and its actual framed transaction; reject synthetic absent offsets. |
| **F04** | Document the relation only. | **Stage B:** independently recover both images, require `post[:E] == pre[:E]`, matching complete transactions and derived states, and both images’ tail rules. |
| **F05** | Small native structural tables and domain controls; retain the accepted 354+151 control accounting as artifact evidence. | **Stage B:** relational controls and all four historical counterexamples, without treating artifact pass reports as repository tests. |

Stage B must preserve the owner’s tail classifications: partial frame/commit or frame without commit retains the committed open prefix and can truncate to durable end; a complete invalid open tail preserves the prefix but refuses continuation; a complete valid post-terminal transaction refuses rather than being silently truncated; partial, invalid, or uncommitted terminal residue retains the terminal prefix. The four counterexamples are segment-as-journal identity, malformed Ack accepted by chronology, a synthetic transaction absent from the raw image, and divergent same-header restart history. Image relations do not prove physical `fdatasync` or crash durability.

Pure Stage B recovery and image-relation work can be planned as untrusted byte processing. **Before any Stage B permit client, signature verification, consume/receipt verifier, or authority-dependent state machine**, the owning contracts must establish `RunEntryV4` bytes and digest, issuer/delegation owner, key suite and trust root, atomic ledger and receipt semantics, and resolve the identifier mismatch. Stage C isolated Linux process/TLS tests need their own behavior-based capability and security qualification; Stage D disabled ES integration needs explicit doc-first migration and rollback; Stage E additionally needs live issuer/ledger, SPIRE, filesystem durability, deployment, and independent source/security evidence. None is authorized by this Stage A plan. Capability checks must follow [capability_probing.md](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/capability_probing.md:9>), with no OS-label branch or fallback.

## Later validation and provenance

After creation, the future writer should run the commands below in order, recording exact results. They were **not run now**. [go.mod](</Users/ds/Repositories/Execution Substrate/go.mod:1>) requires Go 1.26.5; an unavailable local toolchain or offline dependency is a reported unavailable check, never permission to download.

```sh
GOTOOLCHAIN=local go version
GOTOOLCHAIN=local GOPROXY=off go test -count=1 ./es/internal/outsideobserverprotocol
GOTOOLCHAIN=local GOPROXY=off go test -count=1 .
GOTOOLCHAIN=local GOPROXY=off go test -count=1 ./es/admission ./es/runtimehelper ./es/api ./es/config
GOTOOLCHAIN=local GOPROXY=off go test -count=1 ./es/...
GOTOOLCHAIN=local GOPROXY=off go test -count=1 ./...
```

Expected evidence is passing private structural/domain tests, root doc and no-wiring guards, and existing workload identity, default/CP-profile literal job, API/config, and broader regression tests. Those tests cannot qualify future cryptography, issuer/ledger behavior, raw-image recovery, Linux Wait/reap, TLS endpoints, or physical durability.

For the later mutation, first capture a **fresh opening** HEAD/branch/upstream and every safe changed path’s type, mode, size, SHA-256, plus the full binary HEAD-diff digest; classify sensitive or ignored material before hashing it. Stop and reconcile if this observed baseline or either dirty overlap differs. Capture a closing snapshot the same way. The allowed opening-to-closing delta is only the 11 paths above: preserve the opening bytes of the two modified docs and identify their added hunks separately; the nine absent paths may become present; every other pre-existing path must remain byte-identical. A full HEAD diff must never be labeled “the Stage A patch.”

The capsule’s proposed, unexecuted recipe `governed_execution_audit_patch_manifest_v1.py` has SHA-256 `db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`. It hashes **all** tracked HEAD changes and untracked paths and writes the historical fixed name `/tmp/ge-coordinator-b3a-audit-manifest-v1.json` (absent when checked). If later path classification makes it safe and that output is unowned/absent, the sole writer may run the exact source with `GIT_OPTIONAL_LOCKS=0`, preserve its opening output before its own closing run, and report source and manifest hashes. If a sensitive path or output collision makes the recipe unsuitable, record the incompatibility and obtain an explicit treatment; do not silently edit or approximate it. Its whole-tree manifests supplement, but do not replace, the opening-to-closing allowed-delta proof.

The implementation report should identify input hashes, opened/closed bytes, exact changed paths and patch digest, protected dirty-work comparison, doc/test/code alignment, test results or unavailable conditions, and absence of wiring and authority effects. An independent audit should then authenticate inputs and baseline, verify the allowed delta and recipe evidence, inspect the frozen source/docs/tests, and only then assess validation results.

**Confidence:** artifact identity and bounded review acceptance are high; current baseline is well observed for paths and the two planned overlaps, with no prior byte-complete manifest; validation of the proposed repository code is unperformed; implementation and runtime qualification are absent.
