**I agree with `BLOCK`. PRED-T01 is confirmed, and the next step is a two-file forward repair—not an amendment of the predecessor or a reopening of Stage A.**

The audit found a concrete documentation-validator defect. It found no additional authority or custody blocker within its reviewed scope. **Stage A’s local acceptance remains intact; publication remains blocked pending the correction and its independent review.** REPORT.md[Supplied audit report](sandbox:/mnt/data/r928_pred_t01_followup/retained/report/REPORT.md)

:chatgpt-content-reference{index="2"}[Full assessment, source references and inspection limits](sandbox:/mnt/data/R6J_R928_PRED_T01_FORWARD_REPAIR_ASSESSMENT_20261028_01.md)

## What the evidence confirms

The probe demonstrates more than a missing test. The unchanged helper accepts these invalid substitutions:

```json
"hosts": "1"
```

and:

```json
"hosts": "\u0031"
```

It also accepts equivalent quoted strings at the other six numeric positions. The canonical positive passes, while the boolean and null controls refuse. The probe therefore records **eight failing negative subtests and their failing parent**—not eight successful refusals.

The source explains the result: `docs_contract_test.go:10192–10238` scans strings and numbers without retaining the required field-specific numeric kind; the seven fields use `json.Number` at **10286–10307**; and **10383–10397** compares only their resulting text. The retained probe calls the unchanged whole-record helper with isolated mutations. SOURCE_EVIDENCE.md[Exact source and probe excerpts](sandbox:/mnt/data/r928_pred_t01_followup/SOURCE_EVIDENCE.md)

I independently checked the delivered evidence:

| Check | Result |
|---|---|
| Audit archive | **9,339,619 bytes; 132 members / 131 self-excluding manifest rows** verified. |
| Embedded publication preflight | Matches the previously supplied archive identity and verifies against its manifest. |
| Command receipts | All **eight** stdout/stderr pairs match their recorded sizes and hashes. |
| Focused validation | Raw events confirm **14 tests and 57 subtests passed**, without failures or skips. |
| Counterexamples | Every supplied specimen reproduces as exactly one mutation of the canonical JSON. |
| Predecessor patch | Independently reconstructs all **eight after-files / 1,267,502 bytes**. |
| Preservation records | Four manifests match the expected **83-row baseline**; retained opening/closing index, refs, status and snapshots agree. |

The initial routing-canary attempt ran zero tests and receives no validation credit. The corrected canary ran and passed. **I inspected these records and source bytes; I did not access the live repository or execute its tests.** INSPECTION.json[Computed inspection](sandbox:/mnt/data/r928_pred_t01_followup/INSPECTION.json)

## The correction needs two paths

The full audit calls for an explicit owning-document rule as well as enforcement. The permitted scope is therefore:

| Path | Required change |
|---|---|
| `.docs/system_overview/remote_alpha_external_tls_one_time_incident_contract.md` | Clarify that the seven fields require number tokens with their existing exact integer spellings. Preserve the entire normative JSON and all authority/custody rules. |
| `docs_contract_test.go` | Preserve and enforce numeric token kinds before decoding can erase the distinction; add isolated regressions and a test binding the clarification. |

The fix must not coerce strings into numbers, compare through floating point, accept decimal/exponent equivalents, or default missing fields to zero. **The last case matters particularly for `ca_path_length`, whose required value is zero but whose presence remains mandatory.**

The handoff requires the seven quoted-equivalent negatives, the escaped-digit case, matching positives, and field-kind/absence coverage. Existing duplicate-member, malformed-input, numeric-boundary, limit and bounded-diagnostic tests remain intact. There is no need for a shared schema framework, a production parser change, or another R9.28 artifact revision. R6J_R928_PRED_T01_FORWARD_REPAIR_ASSESSMENT_20261028_01.md[Repair requirements](sandbox:/mnt/data/R6J_R928_PRED_T01_FORWARD_REPAIR_ASSESSMENT_20261028_01.md)

## Preserve the dirty overlap and isolate the future commit now

`docs_contract_test.go` already contains unrelated work:

| Version | Size | SHA-256 prefix |
|---|---:|---|
| Committed HEAD | 683,890 bytes | `fa5cd9fc788a…` |
| Expected dirty working file | 692,288 bytes | `6cd5749a034e…` |

**Do not replace the dirty file with its committed counterpart.** The repair must capture its opening bytes, make localized edits, and prove that removing only those edits recovers the opening file exactly. The other **82 existing dirty paths** and every Stage A path stay unchanged.

The same turn must also construct **committed HEAD plus only the two-file repair** in external scratch, validate that candidate, and retain both patches and replay proofs. This avoids discovering another publication-isolation problem after implementation. The complete dirty-file diff must never be presented as the repair. R6J_R928_PRED_T01_FORWARD_REPAIR_ASSESSMENT_20261028_01.md[Baseline identities and isolation requirements](sandbox:/mnt/data/R6J_R928_PRED_T01_FORWARD_REPAIR_ASSESSMENT_20261028_01.md)

Validation stays focused: the fourteen existing documentation tests, the new repair tests, the established routing canary, and the three native Stage A root guards. No broad-suite restart, new adapter design, privilege escalation, or TLS operation is required.

## Ready-to-relay repair handoff

Return to the **implementation Codex conversation**, not the audit conversation, with this capsule:

R6J_R928_PRED_T01_FORWARD_REPAIR_CAPSULE_20261028_01.zip[Download the PRED-T01 forward-repair capsule](sandbox:/mnt/data/R6J_R928_PRED_T01_FORWARD_REPAIR_CAPSULE_20261028_01.zip)

**9,622,701 bytes** · SHA-256:

```text
85f4e4988dce0d801748c677bf972acbb3f61863e8513a89619357c0c3cbc141
```

R6J_R928_PRED_T01_FORWARD_REPAIR_PROMPT_20261028_01.md[Standalone prompt](sandbox:/mnt/data/R6J_R928_PRED_T01_FORWARD_REPAIR_PROMPT_20261028_01.md) · R6J_R928_PRED_T01_FORWARD_REPAIR_CAPSULE_20261028_01_VERIFICATION.json[Capsule verification](sandbox:/mnt/data/R6J_R928_PRED_T01_FORWARD_REPAIR_CAPSULE_20261028_01_VERIFICATION.json)

The capsule includes the exact audit and its nested evidence chain, expected baseline, committed source references, counterexample specimens, provenance recipe, guidance and complete prompt. **No additional owner-envelope upload is required.**

Send:

> Please execute `PROMPT.md` from the attached capsule as the sole implementation writer. Repair PRED-T01 only in the two permitted paths, preserve all unrelated dirty work and the accepted Stage A commit, and return the validated uncommitted repair plus its isolated HEAD-based publication candidate. Do not amend or rewrite history, stage, commit, push, perform TLS operations or begin Stage B.

Afterward, a fresh independent audit should close PRED-T01 and assess the **corrected cumulative publication scope**. The original predecessor `BLOCK` stays in the historical record; a later corrected successor must not be described as proof that the predecessor originally passed. Repair and independent re-audit remain separate engagements. Governed Execution Codex Subage…

**Sources:** R6J_R928_PREDECESSOR_PUBLICATION_INDEPENDENT_AUDIT_20261028_01.zip[Supplied audit package](sandbox:/mnt/data/R6J_R928_PREDECESSOR_PUBLICATION_INDEPENDENT_AUDIT_20261028_01.zip); linked report, source excerpts, assessment and computed inspection; project repair/re-audit guidance cited above.

**Confidence:** delivered-byte integrity **0.99**; retained validation-evidence consistency **0.98**; bounded repair strategy **0.97**. The repaired implementation does not yet exist. Authority-dependent adoption and runtime qualification remain outside this work.
