**The stop is correct. S3 remains accepted, and the HEAD-based candidate remains unchanged.** This is another validation-context blocker—not a new Stage A implementation defect.

My previous prompt authorized a one-file adapter before establishing the complete dependency set. That was too narrow. **The correction is to finish the dependency inventory and freeze the full, tightly bounded relocation plan—not keep adding one filename per turn.**

:chatgpt-content-reference{index="2"}[Full assessment, source references and inspection limits](sandbox:/mnt/data/R6J_R928_STAGE_A_REQUALIFICATION_STOP_ASSESSMENT_20261027_01.md)

## The additional escape is real

I independently checked the complete `remote_alpha_vault_workload_auth_check_test.go` bytes against the supplied pinned-HEAD mapping. They match its size, SHA-256 and Git blob identity.

Its `runSourcedHelper` function contains **two independent source-checkout literals**:

| Location | Effect |
|---|---|
| **Line 312** | Constructs the Bash helper path beneath the dirty source checkout. |
| **Line 315** | Sets the subprocess working directory to that checkout. |

Neither uses the shared `executionSubstrateRepoRoot` constant that the earlier adapter would replace. `TestRemoteAlphaVaultWorkloadAuthCheckPassWritesSafeSummary` calls this helper at **line 446**. Its fake Vault server and synthetic commands do not relocate the helper file itself. SOURCE_EVIDENCE.md[Exact source excerpts and identities](sandbox:/mnt/data/r928_requalification_stop_followup/SOURCE_EVIDENCE.md)

That makes **three confirmed root-literal sites in two files**: the shared constant, the Vault helper path, and the Vault subprocess working directory. Changing only the shared constant cannot isolate the broad run.

Go’s own documentation also makes the relevant limitation explicit: `-overlay` substitutes build inputs; it does not provide filesystem redirection when tests execute. The compiled path values must therefore select the correct scratch tree. [Go Packages](https://pkg.go.dev/cmd/go%40go1.26.5)

## What the delivered evidence establishes

The supplied ZIP authenticates at **2,600,971 bytes**, SHA-256:

```text
e0d1736650c62e4216660d360bfc3e8bbe298f39168e8d3ce49722841f5fd3cc
```

| Check | Inspection result |
|---|---|
| Archive integrity | **46 members / 45 manifest rows** verify. All **eight archives** in the nested evidence chain pass the inspected integrity and manifest checks. |
| S3 provenance | All four retained opening/closing manifests equal the exact **92-row S3 manifest**. Their command receipts match the retained output bytes. |
| Candidate contribution | All eleven delivered candidate-after files match their mappings. The mappings retain nine additions, two document changes and 339 unchanged entries. |
| Candidate tree identity | Recomputing the supplied mapping reproduces `51569c46dae44bf398f5623108488bcfbe21647a`. |
| Current validation | **No fresh native or adapted test run occurred.** The package consistently records the Phase 1 stop. |

These are checks of delivered artifacts and source bytes. **I did not inspect the live checkout or execute repository tests.** The report’s verification of all 350 live scratch files remains Codex-observed evidence. INSPECTION.json[Computed inspection record](sandbox:/mnt/data/r928_requalification_stop_followup/INSPECTION.json)

The historical **21 private tests, 528 subtests and three root guards** remain valid historical candidate receipts. They must not be presented as fresh results from this blocked turn. Likewise, the earlier matching broad failures remain contaminated evidence—not a qualified pristine-HEAD comparison.

## The next task should close the validation plan, not reopen Stage A

The report explicitly says that inspection stopped before completing the other effect routes. Therefore, simply authorizing the second file and immediately rerunning the suite would still leave an unsupported assumption about the remaining dependencies. R6J_R928_STAGE_A_REQUALIFICATION_STOP_ASSESSMENT_20261027_01.md[Assessment](sandbox:/mnt/data/R6J_R928_STAGE_A_REQUALIFICATION_STOP_ASSESSMENT_20261027_01.md)

The replacement handoff makes four concrete changes:

**Complete the inventory before broad execution.** Codex must trace runtime reads, helper execution, working directories, sourced scripts, nested Go commands and service dependencies. Additional unresolved routes should be collected into one bounded report rather than stopping inspection at the next match.

**Permit a closed class of root relocations.** The three known sites are authorized. Additional sites qualify only when they are exact source-root string literals in existing Go test files, used as repository-root locators. Every site must be identified, justified and frozen before compilation. Production source, helper scripts, assertions, control flow, fixtures and module files remain unchanged.

**Verify both actual dispatch routes.** The external canary must cover the shared-root route and the independently hard-coded Vault route—not merely assert that a replacement constant has the expected value. Any definitions-only helper probe must first be shown safe; it must not invoke a service-check or authentication function.

**Separate the native and broad lanes.** Once their own safety and environment gates close, native Stage A checks can run without an overlay even if broader qualification remains blocked. The matched broad pair runs only after the complete dependency and adapter gates close, and its results must remain labeled **test-root-adapted validation**.

The earlier environment corrections also remain required: independent scratch Git context, behaviorally qualified short socket paths, verified group inheritance, and an explicit test-child umask behind an owner-only outer directory. None authorizes changing the accepted candidate.

**No broad failure is waived in advance.** A remaining qualified baseline failure should be reported with its cause, not repaired opportunistically or used to justify another unrestricted workaround.

## Ready-to-relay handoff

R6J_R928_STAGE_A_COMPLETE_TEST_ROOT_REQUALIFICATION_CAPSULE_20261027_01.zip[Download the complete test-root requalification capsule](sandbox:/mnt/data/R6J_R928_STAGE_A_COMPLETE_TEST_ROOT_REQUALIFICATION_CAPSULE_20261027_01.zip)

**2,647,194 bytes** · SHA-256:

```text
64f0b4d93bd9d9741405ff2f03251da885ca66ea998badcec5d8e76fe7399b0c
```

R6J_R928_STAGE_A_COMPLETE_TEST_ROOT_REQUALIFICATION_PROMPT_20261027_01.md[Standalone prompt](sandbox:/mnt/data/R6J_R928_STAGE_A_COMPLETE_TEST_ROOT_REQUALIFICATION_PROMPT_20261027_01.md) · R6J_R928_STAGE_A_COMPLETE_TEST_ROOT_REQUALIFICATION_CAPSULE_20261027_01_VERIFICATION.json[Capsule verification](sandbox:/mnt/data/R6J_R928_STAGE_A_COMPLETE_TEST_ROOT_REQUALIFICATION_CAPSULE_20261027_01_VERIFICATION.json)

The capsule includes the exact latest stop package and its nested candidate/acceptance chain, expected S3 manifest, source evidence, assessment, provenance recipe and complete prompt. **No additional owner-envelope upload is required.** Codex still needs the local repository’s pinned Git objects to materialize the complete baseline.

Return to the **existing implementation Codex conversation** and send:

> Please execute `PROMPT.md` from the attached capsule. Preserve the accepted S3 source and exact candidate. Complete the dependency inventory, freeze the permitted test-root relocations, and report native and adapted validation separately. Do not edit repository or candidate source files, stage, commit, push, or begin Stage B.

Even a successful result will support a later publication decision—not authorize publication itself. **`AUTHORITY_DEPENDENT_ADOPTION_NOT_READY` remains unchanged.**

**Sources:** R6J_R928_STAGE_A_CANDIDATE_ISOLATION_REQUALIFICATION_BLOCKED_20261027_01.zip[Supplied blocked package](sandbox:/mnt/data/R6J_R928_STAGE_A_CANDIDATE_ISOLATION_REQUALIFICATION_BLOCKED_20261027_01.zip); linked source evidence, assessment and inspection record; official Go documentation cited above.

**Confidence:** delivered-byte consistency **0.99**; additional helper-route finding **0.99**; bounded continuation strategy **0.95**. Complete execution-path isolation, adapted broad validation and commit readiness remain unestablished.
