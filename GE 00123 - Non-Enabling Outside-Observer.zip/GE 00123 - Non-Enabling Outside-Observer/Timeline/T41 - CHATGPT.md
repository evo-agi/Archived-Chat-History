**The repair is ready for a fresh independent audit.** The inspected source addresses PRED-T01, and the isolated publication candidate contains only the two authorized changes. **I found no new source blocker in this closeout inspection.**

There is one validation-location discrepancy to close during that audit: the three native Stage A guards ran in the dirty checkout, not the publication candidate. That requires a correctly located audit run—not another implementation turn.

:chatgpt-content-reference{index="1"}[Full closeout assessment, with source references and inspection limits](sandbox:/mnt/data/R6J_R928_PRED_T01_REPAIR_CLOSEOUT_ASSESSMENT_20261028_01.md)

## What I verified

The supplied repair ZIP matches **12,982,807 bytes** and SHA-256:

```text
b233e4a91472e547e30e009fb834d50623ef0e820459973a8165e40af451ca49
```

| Check | Independent artifact-inspection result |
|---|---|
| Archive integrity | **472 members / 471 self-excluding manifest rows** verify. The embedded repair capsule and predecessor audit also authenticate. |
| Complete candidate | All **350 files / 7,470,918 bytes** match their declared modes, sizes, SHA-256 digests and Git blob identities. |
| Scope | Exactly **two candidate paths differ from HEAD**. All other 348 entries—including every Stage A file—remain exact. |
| Independent reconstruction | Both patches reproduce their exact targets: **705,305 bytes** for the two publication files; **713,703 bytes** for the two live files. |
| Dirty-work preservation | Both closing manifests agree at **84 rows**. All **82 unrelated original dirty rows** remain unchanged; reversing the repair recovers the original dirty test file exactly. |
| Focused validation records | **16 tests, 57 existing subtests and 50 new leaf cases** pass, plus seven grouping terminals. No failures, skips, missing or duplicate terminals were found. |

The complete candidate bytes independently reproduce this tree:

```text
ff1b60430aefbc28c14fecb376ca22e969bfa278
```

The exact closing live manifest is:

```text
fd295284337cb2d7ed346eaf93d16de24a51d635cfd0a0a4f3fa0d78f37132c4
```

These are checks of delivered bytes and retained execution records. **I did not access the live repository or execute its tests.** Live HEAD, index and ref preservation remain Codex-observed evidence. INSPECTION.json[Computed inspection results](sandbox:/mnt/data/r928_pred_t01_repair_followup/INSPECTION.json)

## The correction addresses the actual defect

The new local `remoteAlphaTLSNumber` decoder at `docs_contract_test.go:10270–10286` distinguishes number tokens from strings before the distinction can be lost. It retains the original number spelling; the unchanged whole-record checks at **10401–10415** then require the seven exact values.

That preserves two important boundaries: decimal/exponent alternatives still refuse, and **missing or null `ca_path_length` does not become an accepted zero**. The complete validator rejects the empty representation used for those cases.

The new tests exercise the whole-record validator, not merely the new decoder. They bind all eight historical string counterexamples to their archived hashes, check valid isolated mutations, and cover quoted values, restored numeric positives, booleans, nulls, objects, arrays and omissions at every selected field. All fourteen prior focused test definitions remain byte-identical. SOURCE_EVIDENCE.md[Exact source excerpts](sandbox:/mnt/data/r928_pred_t01_repair_followup/SOURCE_EVIDENCE.md)

The owning document adds only **551 bytes** explaining those token requirements. Its **6,190-byte normative JSON fixture remains unchanged**, as do the surrounding authority, custody and incident terms. No production parser or Stage A source changes.

## One audit obligation: run the native guards against the candidate

`evidence/validation/native_root.json:11` records:

```text
/Users/ds/Repositories/Execution Substrate
```

That is the dirty source checkout. The report discloses this accurately, but the implementation prompt required the commands to run from the isolated candidate.

The three passes are therefore **valid checkout evidence—not fresh repaired-candidate evidence**. By contrast, the focused documentation tests and routing canary did run in the candidate.

I have made this explicit as **OBS-VAL-01** in the handoff. The fresh auditor must run the three native guards **without an overlay, from its authenticated candidate mirror**, alongside the focused documentation tests and independent numeric probes. No source repair, adapter expansion or broad-suite restart is needed to close this discrepancy. R6J_R928_PRED_T01_REPAIR_CLOSEOUT_ASSESSMENT_20261028_01.md[Validation assessment](sandbox:/mnt/data/R6J_R928_PRED_T01_REPAIR_CLOSEOUT_ASSESSMENT_20261028_01.md)

## Ready-to-relay independent audit

Use a **fresh read-only Codex conversation**. The changed bytes require a new independent verdict; implementation validation does not replace that review. Governed Execution Codex Subage…

R6J_R928_PRED_T01_FORWARD_REPAIR_FRESH_INDEPENDENT_AUDIT_CAPSULE_20261028_01.zip[Download the PRED-T01 fresh independent-audit capsule](sandbox:/mnt/data/R6J_R928_PRED_T01_FORWARD_REPAIR_FRESH_INDEPENDENT_AUDIT_CAPSULE_20261028_01.zip)

**13,070,570 bytes** · SHA-256:

```text
c9d7fa0060e410cd2e81edc1f15def614e82effcb52dede5a301b854a364c4da
```

R6J_R928_PRED_T01_FORWARD_REPAIR_FRESH_INDEPENDENT_AUDIT_PROMPT_20261028_01.md[Standalone audit prompt](sandbox:/mnt/data/R6J_R928_PRED_T01_FORWARD_REPAIR_FRESH_INDEPENDENT_AUDIT_PROMPT_20261028_01.md) · R6J_R928_PRED_T01_FORWARD_REPAIR_FRESH_INDEPENDENT_AUDIT_CAPSULE_20261028_01_VERIFICATION.json[Capsule verification](sandbox:/mnt/data/R6J_R928_PRED_T01_FORWARD_REPAIR_FRESH_INDEPENDENT_AUDIT_CAPSULE_20261028_01_VERIFICATION.json)

The capsule includes the exact repair target, complete candidate, prior audit/evidence chain, expected live manifest, both patches, specimens, provenance recipe and complete audit instructions. **No separate owner-envelope upload is required.**

Send:

> Please execute `PROMPT.md` from the attached capsule in this fresh read-only conversation. Independently audit the PRED-T01 forward repair and corrected cumulative publication candidate. Resolve PRED-T01 and OBS-VAL-01, preserve the accepted Stage A commit and all dirty work, and return one audit verdict. Do not repair, stage, commit, push, perform TLS operations or begin Stage B.

An `ACCEPT` would close the correction’s independent-review prerequisite. It would **not** retroactively erase the predecessor’s `BLOCK` or authorize publication. The later forward commit must use the isolated HEAD-based patch—not the complete dirty `docs_contract_test.go`.

**Sources:** R6J_R928_PRED_T01_FORWARD_REPAIR_UNCOMMITTED_20261028_01.zip[Supplied repair package](sandbox:/mnt/data/R6J_R928_PRED_T01_FORWARD_REPAIR_UNCOMMITTED_20261028_01.zip); linked assessment, source excerpts and independent inspection; project repair/re-audit guidance cited above.

**Confidence:** delivered-byte integrity and reconstruction **0.99**; retained validation-evidence consistency **0.98**; bounded repair-readiness assessment **0.96**. Independent repair acceptance remains outstanding. **Authority-dependent adoption and runtime qualification remain unready.**
