**Codex correctly stopped, but this is a scope defect in my previous validation prompt—not a new Stage A implementation failure.** The correction is to authorize the existing test’s isolated Git-fixture operations while continuing to prohibit source-repository staging, candidate commits and publication.

**Resume the already prepared comparison. Do not change Stage A, expand the adapter, or restart the dependency inventory.** The previous prompt explicitly prohibited creating a new commit “even in scratch,” so Codex could not safely interpret that prohibition as applying only to publication. R6J_R928_STAGE_A_FIXTURE_GIT_SCOPE_ASSESSMENT_20261027_01.md[Assessment and exact source references](sandbox:/mnt/data/R6J_R928_STAGE_A_FIXTURE_GIT_SCOPE_ASSESSMENT_20261027_01.md)

## The fixture is not committing the candidate

I independently recovered the complete `es/app/proof_codex_shim_test.go` and matched it against the latest package’s pinned-HEAD size, SHA-256 and Git blob identity.

The relevant test does the following:

- At **lines 136–144**, it creates a `t.TempDir()` workspace, writes a synthetic README and assigns that workspace as the Git subprocess working directory.
- At **lines 149–153**, it initializes that fixture repository, sets synthetic local author information, stages the README and commits the baseline.
- At **lines 155–187**, it creates an untracked proof file and checks that the entrypoint’s workspace diff includes it.

The source tree supplies the entrypoint being tested; **the temporary fixture supplies the repository being committed**. The entrypoint’s `workspace_diff` implementation performs local diff and untracked-file reads. This is test setup for the untracked-diff assertion, not publication of the Stage A contribution. SOURCE_EVIDENCE.md[Exact fixture and entrypoint excerpts](sandbox:/mnt/data/r928_fixture_git_scope_followup/SOURCE_EVIDENCE.md)

I should have distinguished those effects in the earlier handoff.

## What I verified in this delivery

The supplied package matches **3,417,708 bytes** and SHA-256:

```text
061c0100cb5454611e4a2782fc689daab42e872c94c554a6f71e33a8c3b4d422
```

| Check | Independent artifact-inspection result |
|---|---|
| Archive integrity | **133 members / 132 self-excluding manifest rows** verify. All eight nested archives also pass their archive and manifest checks. |
| Accepted S3 binding | All four retained opening/closing manifests equal the exact **92-row S3 manifest**. Source-state records differ only in their opening/closing labels. |
| Native validation records | Actual JSON events confirm **21 private top-level tests, 528 subtests and exactly three root guards passed**, without failures or skips. |
| Routing canaries | Each context records **one top-level test and two subtests passed**, without failures or skips. |
| Candidate and adapter bytes | The eleven captured candidate files match their mappings. Both tree identities recompute correctly. Reversing only the three declared literal substitutions recovers the original backing sources exactly. |
| Adapted broad comparison | **Not run.** No broad pass, failure equivalence or skip comparison is established. |

The candidate remains:

```text
51569c46dae44bf398f5623108488bcfbe21647a
```

These are checks of delivered bytes, source and retained execution records. **I did not access the live repository or execute its tests.** The complete live-tree preservation and exhaustive dependency classification remain Codex-observed evidence; the canaries are not a general filesystem or network sandbox. INSPECTION.json[Computed inspection record](sandbox:/mnt/data/r928_fixture_git_scope_followup/INSPECTION.json)

## The corrected permission boundary

The new handoff separates three contexts explicitly.

**The source checkout remains read-only.** Its files, real index, refs, object store and configuration cannot change.

**The pristine and candidate validation trees remain exact.** Their independent Git metadata can represent the pinned inputs, but neither tree may receive a new publication commit or source modification.

**Fresh synthetic test repositories may perform the existing fixture sequence.** That permits local initialization, synthetic identity configuration, staging and baseline commits inside the test-owned temporary directories, plus a small containment preflight. It does not authorize arbitrary commits elsewhere.

The containment check matters: a subprocess working directory alone is insufficient when inherited Git variables can redirect the repository, index or object storage. The handoff therefore requires a clean environment, independent fixture metadata, empty hooks/templates, no remotes or shared object storage, and no signing or operator-credential dependency. Git documents these redirection and configuration mechanisms explicitly. [Git](https://git-scm.com/docs/git)

The final report must also distinguish **fixture commits performed** from **source and candidate commits not performed**. An unqualified `COMMIT_NOT_PERFORMED` would become inaccurate once the fixture succeeds.

## What the next turn should accomplish

The next task reauthenticates the existing inventory and frozen three-site adapter, qualifies the fixture permission and final environment, and runs **one matched pristine/candidate adapted broad pair**. It keeps the native results separate and requires the previously blocked test to actually run in both broad streams—not skip because Git was hidden.

Ordinary test failures in the pristine run should not prevent the matched candidate run, provided containment and provenance still hold. Any remaining failures must be classified from their actual diagnostics. Matching baseline failures are not automatically waived, and no unrelated source repair is authorized.

**S3’s acceptance remains intact. Broad validation and the later publication decision remain open.** Another parser repair or R9.28 design revision is not justified by this report. R6J_R928_STAGE_A_FIXTURE_GIT_SCOPE_ASSESSMENT_20261027_01.md[Assessment](sandbox:/mnt/data/R6J_R928_STAGE_A_FIXTURE_GIT_SCOPE_ASSESSMENT_20261027_01.md)

## Ready-to-relay handoff

R6J_R928_STAGE_A_FIXTURE_GIT_SCOPE_AND_BROAD_VALIDATION_20261027_01.zip[Download the fixture-Git scope and broad-validation capsule](sandbox:/mnt/data/R6J_R928_STAGE_A_FIXTURE_GIT_SCOPE_AND_BROAD_VALIDATION_20261027_01.zip)

**3,422,063 bytes** · SHA-256:

```text
d5b182a76e8836d01d8a2db5df36ac69ce1b00d9199427cf63a35e85805c8e47
```

R6J_R928_STAGE_A_FIXTURE_GIT_SCOPE_AND_BROAD_VALIDATION_20261027_01.md[Standalone prompt](sandbox:/mnt/data/R6J_R928_STAGE_A_FIXTURE_GIT_SCOPE_AND_BROAD_VALIDATION_20261027_01.md) · R6J_R928_STAGE_A_FIXTURE_GIT_SCOPE_AND_BROAD_VALIDATION_20261027_01_VERIFICATION.json[Capsule verification](sandbox:/mnt/data/R6J_R928_STAGE_A_FIXTURE_GIT_SCOPE_AND_BROAD_VALIDATION_20261027_01_VERIFICATION.json)

The capsule includes the exact latest package and its nested accepted evidence chain, expected S3 manifest, source evidence, provenance recipe and complete prompt. **No separate owner-envelope upload is required.**

Return to the **existing implementation Codex conversation**, attach the capsule and send:

> Please execute `PROMPT.md` from the attached capsule. The isolated R15 test-fixture Git operations and containment preflight are explicitly authorized. Preserve the source checkout and exact candidate, reuse the completed inventory and frozen adapter, and finish the matched broad validation. Do not stage or commit the source repository or publication candidate, push, or begin Stage B.

**Sources:** R6J_R928_STAGE_A_COMPLETE_TEST_ROOT_REQUALIFICATION_BLOCKED_20261027_01.zip[Supplied blocked package](sandbox:/mnt/data/R6J_R928_STAGE_A_COMPLETE_TEST_ROOT_REQUALIFICATION_BLOCKED_20261027_01.zip); linked assessment, exact source excerpts and computed inspection; official Git documentation cited above.

**Confidence:** delivered-byte integrity **0.99**; retained native/canary evidence consistency **0.98**; fixture-scope diagnosis **0.98**. Broad-suite results and publication readiness remain unestablished.
