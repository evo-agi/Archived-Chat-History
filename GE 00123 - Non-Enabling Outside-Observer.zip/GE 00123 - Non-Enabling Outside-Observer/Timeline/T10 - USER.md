Here is Codex's response:

# STAGE_A_RECONNAISSANCE_BLOCKED

The supplied R9.28 review accepts the **artifact design**, and I verified the supplied bytes. A governing authority gap prevents a frozen Stage A adoption plan: the owner contract assumes an *existing signed `RunEntryV4` issuer* with an atomic outside-observation permit ledger. No such issuer, permit, or receipt contract appears in the inspected ES checkout. [PLANS.md](</Users/ds/Repositories/Execution Substrate/PLANS.md:97>) and the [hybrid integration ADR](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/hybrid_integration_architecture_adr.md:96>) leave issuer/delegation topology and worker/runtime handoff open. Artifact acceptance cannot settle that ES contract.

I treated the prompt as the user’s delegated read-only task and the ZIP contents as evidence. I did not execute packaged programs, repository scripts, or tests.

## Identity and repository baseline

| Input | Verified identity |
| --- | --- |
| Delivery envelope | 168,307,308 bytes; SHA-256 `5b637a7247af865c888590863b021db9e5aa7fc15dd91aed50ad552a2cbad33c` |
| Embedded owner | 167,125,065 bytes; SHA-256 `b9c1f5933155d39cf5f656f9ca6a69d27fa86c7ccac4bdfd32aee57b829bb647` |
| Accepted review ZIP | SHA-256 `fc0a604e8fd294840f69c623aeba94754c1bad4088d3f3e0f54bb0b9d837a9f6` |

I independently checked the review, delivery, and embedded-owner ZIP inventories: entries were unique, safe regular files, and matched their self-excluding manifests. `VERDICT.json` and `REVIEW_REPORT.md` matched the prompt’s required hashes. The supplied prompt is byte-identical to the review ZIP’s `NEXT_REPO_TASK.md`. The verdict is `R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_28_ARTIFACT_REVIEW_ACCEPTED`; its repository-adoption and runtime-qualification claims remain false.

The actual root is `/Users/ds/Repositories/Execution Substrate`, on `trunk_dev` tracking `origin/trunk_dev`, at `b92bd9884106154d25342e1573dcc4c312311436`. The pre-existing tree has **66 modified, 17 untracked, and zero staged paths**. At closeout, HEAD, branch, upstream, status hash (`a4c23375…e7af98c`), and unstaged diff-stat hash (`9b31e062…17fa6`) matched the opening baseline. No repository content was changed.

## Current behavior versus the proposal

| Surface | Repository finding | R9.28 treatment |
| --- | --- | --- |
| Authority | ES owns admission and runtime handoff; Nomad owns submitted lifecycle. Current caller authorization is authenticated SPIFFE identity plus a narrow allowlist ([PLANS.md](</Users/ds/Repositories/Execution Substrate/PLANS.md:2198>), [lifecycle contracts](</Users/ds/Repositories/Execution Substrate/.docs/execution_lifecycle/contracts.md:165>)). | The assumed `RunEntryV4` issuer and permit ledger are an unresolved **reopened redesign seam**, not current authority. |
| Process ownership | The current supervisor starts and waits for its helper and workload children ([supervisor.go](</Users/ds/Repositories/Execution Substrate/es/runtimehelper/supervisor.go:67>)). | Outside-observer PID1, sole Wait/reap ownership, and namespace drain are target contracts only. |
| Endpoint and state | The existing run-scoped endpoint serves workload Vault JWT requests ([common.go](</Users/ds/Repositories/Execution Substrate/es/runtimehelper/common.go:32>), [runtimeidentity.go](</Users/ds/Repositories/Execution Substrate/es/admission/runtimeidentity.go:23>)). ES projects lifecycle from Nomad ([lifecycle.go](</Users/ds/Repositories/Execution Substrate/es/admission/lifecycle.go:75>)). | The nonce-bound receiver session and journal are new private proposals; they cannot replace the workload identity endpoint or become run truth. |
| Compatibility | `control-plane-normal-shell/v1` and its annotation are a **temporary compatibility edge** ([lifecycle contracts](</Users/ds/Repositories/Execution Substrate/.docs/execution_lifecycle/contracts.md:343>)). | Preserve them until an explicit migration contract exists. |

The five accepted corrections map to **proposed new contract and test work**, with no current ES implementation: the four-field segment hash domain (F01); complete eleven-field Ack validation before hash credit (F02); chronology derived from the supplied raw journal image and its final recovered transaction (F03); exact post-restart committed-prefix equality, transaction equality, and independent tail classification (F04); and stronger relational controls (F05). The owner’s `target/normative/R9_28_APPENDIX.md:7–41` and `target/frozen/R9_28_RELATION_CONTRACT.json` define these targets. The review reports 505/505 delivered controls and 700/700 independent probes; I did not rerun them. Its navigation erratum is carried as **F01–F05 → R9.28.2–R9.28.6**, without changing the accepted owner.

## Recommended bounded Stage A tranche, once the authority seam is decided

**Critical path:** Record an ES governing decision that names the actual launch-authority issuer, signed-entry verification contract, permit-consumption ledger owner, receipt verification, and failure semantics. If `RunEntryV4` is a future design rather than an existing contract, the docs must say so and keep every authority-bearing path disabled. Namespace the artifact’s “Stage A–E” labels in `PLANS.md`; they are not current ES workstream labels. Follow the repository’s [doc-first order](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/evolution.md:110>) before adding tests or Go source.

The bounded file set for that tranche is:

- Governing ownership: [PLANS.md](</Users/ds/Repositories/Execution Substrate/PLANS.md>), [hybrid integration ADR](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/hybrid_integration_architecture_adr.md>), [boundaries.md](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/boundaries.md>), [system contracts.md](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/contracts.md>), and [runtime_identity_handoff.md](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/runtime_identity_handoff.md>) to distinguish current owners, proposed owners, and the existing JWT endpoint.
- ES lifecycle contracts: [es_execution_admission_model.md](</Users/ds/Repositories/Execution Substrate/.docs/execution_lifecycle/es_execution_admission_model.md>), [contracts.md](</Users/ds/Repositories/Execution Substrate/.docs/execution_lifecycle/contracts.md>), [implementation.md](</Users/ds/Repositories/Execution Substrate/.docs/execution_lifecycle/implementation.md>), and proposed `/Users/ds/Repositories/Execution Substrate/.docs/execution_lifecycle/outside_observer_protocol.md` for exact target wire, Ack, journal, chronology, restart, tail, and non-enablement rules.
- Native static contract surface: [docs_contract_test.go](</Users/ds/Repositories/Execution Substrate/docs_contract_test.go>); proposed `/Users/ds/Repositories/Execution Substrate/es/admission/outside_observer_guardrails_test.go`; and proposed `schema.go`, `validate.go`, `schema_test.go`, and `validate_test.go` under `/Users/ds/Repositories/Execution Substrate/es/internal/outsideobserverprotocol/`.

The private Go package would define closed types and static validation for the owner’s `ObserverHelloV1`, `ReceiverHelloV1`, `PermitConsumptionReceiptV1`, `EvidenceFrameV1`, `AckV1`, journal V2 records, and derived source-state shape. It must enforce exact fields, canonical encoding, types, bounds, context bindings, and the segment domain without reusing the narrow shared evidence kernel ([shared_kernel.md](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/shared_kernel.md:25>)). Contract tests should pin the four supplied refusal counterexamples and the retained tail rules: eligible partial open tails retain the committed prefix; a complete invalid open tail refuses continuation; a complete valid post-terminal transaction refuses; eligible terminal residue truncates. The journal is target evidence custody, while `SOURCE_STATE.json` is a derived cache.

**Stage A stops at static contracts.** Raw-image recovery, executable chronology and restart relation engines belong to the proposed Stage B; isolated Linux process tests to C; disabled ES integration to D; and live issuer, SPIFFE, receiver, and Nomad effects to E. No Stage A import into active submit, runtime helper, API, config, or job construction is in scope. The current runtime path and CP compatibility stay covered by existing regression tests. Capability-sensitive future gates must follow [capability_probing.md](</Users/ds/Repositories/Execution Substrate/.docs/system_overview/capability_probing.md:9>): behavior or static-resource checks at validation boundaries, with no OS-label fallback.

Later validation should use the exact Go 1.26.5 baseline ([go.mod](</Users/ds/Repositories/Execution Substrate/go.mod:1>)); these commands were **not run**:

```sh
GOTOOLCHAIN=local go version
GOTOOLCHAIN=local GOPROXY=off go test -count=1 .
GOTOOLCHAIN=local GOPROXY=off go test -count=1 ./es/admission ./es/runtimehelper ./es/api ./es/config
GOTOOLCHAIN=local GOPROXY=off go test -count=1 ./es/...
GOTOOLCHAIN=local GOPROXY=off go test -count=1 ./...
```

The first result must report `go1.26.5`; a cold offline dependency cache is a recorded validation skip, not grounds for an unrecorded download. The test plan must explicitly cover direct versus chronology Ack agreement, raw-image transaction binding, divergent restart prefixes, and tail classifications when Stage B implements those relations. Existing default and CP-profile literal job tests in [resolved_execution_plan_test.go](</Users/ds/Repositories/Execution Substrate/es/admission/resolved_execution_plan_test.go:1269>) are regression gates for non-enablement.

**Stop conditions:** Do not freeze an operable permit schema while issuer/key/ledger custody remains unidentified; do not promote the owner’s modeled PID1 or durability claims into current behavior; stop on any changed public API, active job, credential handling, CP compatibility, or independent Ack/chronology/restart contradiction. A later mutation turn must recheck this dirty baseline, use one writer, and record exact touched files, patch provenance, input identities, commands and results, skipped checks, assumptions, artifacts, unresolved seams, and any authority or security widening. I found no general historical patch-provenance recipe in the inspected governing files, so none was executed or substituted. Independent audit belongs in a later fresh read-only conversation.

**Confidence:** byte provenance is high for the supplied objects, without a signer-authenticity claim; artifact semantic validation rests on the accepted bounded review; repository implementation and live-runtime validation remain unassessed. The full historical corpus, all dirty diffs, external issuer implementations, hosts, and live services were outside this read-only inspection.
