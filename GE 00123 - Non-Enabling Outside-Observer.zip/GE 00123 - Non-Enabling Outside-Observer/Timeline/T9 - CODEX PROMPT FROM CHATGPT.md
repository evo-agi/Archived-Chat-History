ES R9.28 — read-only repository grounding and Stage A plan
Objective and effect ceiling
Independently ground the accepted R9.28 artifact design in the current Execution Substrate repository and return one frozen, bounded Stage A implementation plan. Do not implement that plan in this turn.
Primary repository: /Users/ds/Repositories/Execution Substrate/.
This is read-only reconnaissance. Do not edit, create, delete, format, install, execute tests or repository scripts, launch services, contact hosts/networks, issue credentials or authority, stage, commit, push, open a PR, merge, deploy, or enable production wiring. Do not extract artifacts into the repository. Do not execute any program from the owner, predecessor or reviewer ZIPs. Reading ZIP members and computing hashes in a separate artifact sandbox is permitted; repository contents remain unchanged.
The user is not a routine per-task approval service. Produce the complete decision-ready plan using available evidence. Return a specific evidence/authority stop only when a genuine unresolved seam prevents a sound plan; do not substitute vague confirmation requests for source inspection.
Required supplied artifacts
1. OWNER_R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_28_COMPLETED_READY_FOR_FRESH_REVIEW_DELIVERY_ENVELOPE.zip
   - bytes: 168307308
   - SHA-256: 5b637a7247af865c888590863b021db9e5aa7fc15dd91aed50ad552a2cbad33c
   - accepted embedded owner: OWNER_R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_28_COMPLETED_READY_FOR_FRESH_REVIEW.zip
   - owner bytes: 167125065
   - owner SHA-256: b9c1f5933155d39cf5f656f9ca6a69d27fa86c7ccac4bdfd32aee57b829bb647
2. R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_28_ARTIFACT_REVIEW_ACCEPTED_20261026_01.zip
   - authenticate its safe, unique, regular entries and self-excluding manifest;
   - require exact VERDICT.json SHA-256 363789c3ea5c07fd38134e707fb4d4e3a8c4202f9d56ed05f704983fd425ecce;
   - require exact REVIEW_REPORT.md SHA-256 b74be281811fe6405fa7f6ace79d2b1de48f20dfe57aa392ffe90fc938d2db41;
   - require verdict R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_28_ARTIFACT_REVIEW_ACCEPTED for the exact owner above.
3. This prompt. It is byte-identical to the review package's NEXT_REPO_TASK.md.
Resolve supplied artifacts through their actual provided local paths or attachments. Never invent a path or use chat recollection as a substitute. If either substantive artifact is inaccessible or mismatches, report STAGE_A_RECONNAISSANCE_BLOCKED_INPUT_IDENTITY with the exact missing/mismatched object; do not author source changes.
Read the review's VERDICT.json, REVIEW_REPORT.md, FINDINGS.json, NONNORMATIVE_ERRATA.json, REQUIREMENT_MATRIX.json, SOURCE_INDEX.md, and METHOD_AND_LIMITS.md. In the owner, read README_FIRST.md, current R9.28 appendix/relation contract, current architecture/frozen schemas, SURFACE_STATUS.json, current bindings, preserved-profile status and staged-boundary contract. Historical archives remain inert evidence; the entire proof history is not a repository-import target.
Classification and governing boundary
Accepted evidence: R9.28 artifact-level segment identity, complete Ack validation, raw-image recovery-derived chronology, exact pre/post committed-prefix relation, and inspected preservation/reconstruction/delivery closure. This is not repository-validated behavior or permission to deploy. The owner's historical false nonclaim flags remain unchanged; the independent review decision is external evidence, not runtime authority.
Current contracts: determine from the actual ES checkout, not this artifact, an old snapshot, a past chat or filenames. The latest ES PLANS.md governs status and sequencing. Label newer report-only facts separately.
Strategic direction: ES owns admission, runtime handoff and execution facts under its owning contracts. No artifact, reader result, Bridge report or helper repository becomes a hidden run-truth store. CP remains only the bounded maintained demo/compatibility consumer, not a target peer or constraint by inertia. Preserve existing compatibility such as control-plane-normal-shell/v1 unless a deliberate migration is separately specified. Do not introduce Coordinator, model-worker, publication or recovery capabilities as if already implemented.
Stage A in this proposal is governing docs/contracts, exact private schemas, static validators and contract tests, with no mutable authority or production wiring. Stage B pure libraries, Stage C Linux integration, Stage D disabled integration and Stage E production effects remain separate. Report any collision between these labels and the actual repo plan rather than silently reconciling it.
Baseline and source inspection
Record actual repository root, branch or detached-HEAD state, HEAD, upstream if present, and tracked/untracked/staged status. Use non-mutating reads with GIT_OPTIONAL_LOCKS=0; do not fetch, reset, clean, stash or absorb existing work. A dirty tree must be described, not cleaned. Recheck the observed baseline at closeout.
Suggested read-only Git observations, from the exact ES root:
GIT_OPTIONAL_LOCKS=0 git rev-parse --show-toplevel
GIT_OPTIONAL_LOCKS=0 git rev-parse HEAD
GIT_OPTIONAL_LOCKS=0 git symbolic-ref --quiet --short HEAD
GIT_OPTIONAL_LOCKS=0 git rev-parse --abbrev-ref --symbolic-full-name '@{u}'
GIT_OPTIONAL_LOCKS=0 git status --porcelain=v1 --untracked-files=all
GIT_OPTIONAL_LOCKS=0 git diff --no-ext-diff --no-textconv --stat
GIT_OPTIONAL_LOCKS=0 git diff --cached --no-ext-diff --no-textconv --stat
Missing upstream or detached HEAD is a recorded baseline fact, not permission to invent one. Inspect relevant existing changes only where safe and necessary; do not print secret-bearing diffs.
Read AGENTS.md, relevant nested guidance, the latest PLANS.md, referenced owning architecture/lifecycle/security/runtime contracts, and the actual relevant source, tests, schemas, scripts, configuration, examples and retained safe validation artifacts. Discover current paths rather than assuming the artifact's temporary paths are repository paths. Pay particular attention to outside-observer/runtime-helper ownership, PID1/direct-parent/Wait/reap semantics, permit versus launch authority, endpoint ownership and nonce/session binding, protocol encoding, journal/cache state, error/recovery semantics, profile compatibility and fail-closed stage gates.
Do not enumerate or expose security directories, private state databases, environment files, WebAuthn, TLS/SPIFFE/Vault/Codex/API-key material. Classify suspicious generated files before judging them; do not delete caches, archives, build output or OS metadata.
Bounded investigation and reconciliation
Use one foreground parent and, when supported, at most three read-only explorers: (1) governing contracts and stage/authority conflicts; (2) source/test/schema mapping; (3) validation, security and migration acceptance evidence. Supply self-contained context and the exact same baseline to each. No nested agents or writers. Reconcile reports, retain disagreements and close every child. If a capability is unavailable, record that and complete the bounded read-only investigation directly; do not claim delegation occurred.
Produce a source-grounded mapping of each accepted correction to existing repo contracts and exact candidate touched paths. Classify each as already supported, proposed new contract/test, compatibility obligation, reopened seam, or evidence-only. Identify any contradiction or missing operating-model decision before suggesting implementation.
Do not copy Python artifact checkers, the 551 KB cumulative temporal corpus, nested predecessor ZIPs, generated pass reports or historical profile fixtures wholesale into product source. Determine the smallest native contract/schema/test adoption surface consistent with the repo language, structure and validation conventions. The 429 records and four profile cores remain immutable evidence; do not reinterpret them as runtime observations or silently regenerate them.
Carry the non-blocking crosswalk erratum only as a navigation correction: F01–F05 correspond to R9.28.2–R9.28.6, respectively. It does not reopen the accepted protocol or justify resealing the owner.
Required plan and validation design
Return one recommended Stage A tranche, not a menu or broad multi-repo implementation request. Separate its critical path from optional read-only investigations. Define objective, owning contracts, explicit touched-file set with reasons, contract-test changes before/with any future code, migration/compatibility treatment, non-goals, integration/audit order, required evidence and stop conditions.
Derive exact validation commands from current repo files; do not invent module/test names, and do not run the commands in this turn. Cover docs/contract alignment, exact schemas and types, segment-domain distinction, direct/chronology Ack equivalence, raw-image transaction binding, exact restart prefixes, retained tail classifications, stage non-enablements and affected regression tests. Preserve the supplied relational counterexamples as requirements, not as a mandated implementation language.
Specify what the later implementation report must retain: touched files, exact commands/results, input identities, assumptions, unresolved seams, skipped validation, artifacts and any authority/security widening. Require exact patch provenance under the repo's current guidance; do not execute, replace or approximate a historical provenance recipe during reconnaissance. A later mutation turn must recheck this frozen baseline, use one writer, and remain separately authorized. Independent audit occurs in a later fresh read-only conversation.
Final output and stop conditions
Return STAGE_A_RECONNAISSANCE_READY only with a complete source-grounded plan and no unresolved authority/contract conflict. Otherwise return STAGE_A_RECONNAISSANCE_BLOCKED or STAGE_A_RECONNAISSANCE_PARTIAL, state the precise missing evidence/decision, and preserve all useful completed findings.
Include baseline identity and closeout comparison, inspected paths with line references, current-versus-target classification, artifact-versus-repo status, exact planned touched paths and validation commands, preservation/migration rules, risks/uninspected areas, and separate provenance/validation/implementation confidence. No tests ran and no implementation was performed in this turn. Do not stage, commit, push or claim repository adoption/live qualification.



















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Drag to reorder pinned navigation items


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
