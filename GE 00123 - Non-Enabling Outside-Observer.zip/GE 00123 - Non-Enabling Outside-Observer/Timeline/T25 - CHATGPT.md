**Keep S3 accepted and the candidate unchanged, but do not commit yet.** The `VALIDATION_UNAVAILABLE` verdict is appropriate. However, I found a more important problem than “pristine HEAD also fails”: **the broad test runs were not confined to their scratch trees.**

The failure sets really do match. They do **not** establish a clean comparison against pristine HEAD because some committed tests reach back into the original, dirty checkout.

:chatgpt-content-reference{index="2"}[Full assessment, including source identities, findings and inspection limits](sandbox:/mnt/data/R6J_R928_STAGE_A_CANDIDATE_ISOLATION_ASSESSMENT_20261027_01.md)

## The blocking finding: tests escape the candidate

The exact declared-HEAD source at `remote_alpha_normal_shell_runtime_image_check_test.go:16` contains:

```go
const executionSubstrateRepoRoot = "/Users/ds/Repositories/Execution Substrate"
```

That file’s helper at **lines 18–24** constructs an executable helper path beneath this root and sets the subprocess working directory to it. Another caller, `remote_alpha_check_es_writable_state_readiness_test.go:28–36`, does the same when executing the writable-state readiness script.

**Running Go from an external candidate directory does not change that compiled absolute path.** Those tests can therefore combine scratch-compiled test code with helpers from the dirty source repository. The defining file and callers were checked against the candidate package’s declared HEAD identities—not assumed current merely because they appeared in an older snapshot. SOURCE_EVIDENCE.md[Exact source excerpts and identity checks](sandbox:/mnt/data/r928_candidate_followup/SOURCE_EVIDENCE.md)

I classify this as **CV-ISO-01: high-severity validation-context contamination**. It is an inherited test-isolation problem, **not an identified Stage A parser defect**.

Consequently, the report’s attribution of the root failures to committed-baseline drift is not established. We should neither repair those failures as though Stage A caused them nor waive them wholesale because the two runs produced matching names.

## The candidate construction itself checks out

| Check | My inspection result |
|---|---|
| Delivered archive | **2,510,364 bytes**; reported SHA-256 matches. **90 members / 89 self-excluding manifest rows** verify. |
| Accepted evidence chain | Nested S3 ACCEPT and S3 target match their previously supplied identities. |
| Source provenance | All four retained opening/closing manifests equal the exact **92-row S3 manifest**. |
| Candidate contribution | Nine new files are exact S3 bytes; the two shared documents contain only their exact accepted insertions into HEAD. |
| Independent patch reconstruction | All **eleven changed files / 382,680 bytes** reconstruct exactly from the supplied HEAD-before bytes and patch. |
| Candidate tree identity | Recomputing the tree from the supplied object-ID mapping yields `51569c46dae44bf398f5623108488bcfbe21647a`. |
| Targeted validation records | **21 private tests, 528 subtests and exactly three root guards passed**, with no failures or skips. |

I also verified that the matched broad runs contain the same **321 failing test identities and 38 skipped identities**. Their failure diagnostics match after explicit normalization of scratch paths, random fixture names and timing. The problem is the provenance of the test inputs—not an inaccurate count.

These are archive, source and retained-event inspections. **I did not access the live repository or execute its tests.** The 339 unchanged candidate paths are represented by matching manifest rows; their complete live bytes and post-test invariance remain Codex-observed evidence. INSPECTION.json[Computed inspection results](sandbox:/mnt/data/r928_candidate_followup/INSPECTION.json)

## Other validation-environment problems are also visible

| Observation | Required treatment |
|---|---|
| `TestTrackedGeneratedArtifactHygiene` invokes `git ls-files`, but the candidate is a plain directory without Git metadata. | Supply independent scratch Git metadata and an exact scratch index—not access to the source index. |
| All **18 failing app tests** report mock Unix-socket bind errors beneath the long private HOME path. | Qualify a short private HOME/socket path before attributing these failures to source. |
| **Six admission failures** show group-20/group-0 ownership disagreement. | Verify actual scratch-directory ownership and inheritance against the fixture’s process-group assumptions. |
| The runtime-helper fixture expects `0755`, but the imposed `0077` umask produces `0700`. | Use an explicit test-child umask behind an owner-only outer scratch directory; do not modify source or assertions. |

The first pristine comparison did not reproduce the runtime-helper failure; the explicitly umask-matched run did. That supports the environment diagnosis for that case. The socket and ownership corrections still require observation rather than an assumed pass. SOURCE_EVIDENCE.md[Source and diagnostic evidence](sandbox:/mnt/data/r928_candidate_followup/SOURCE_EVIDENCE.md)

My previous prompt required a plain checkout and failed to account for the inherited absolute test root. **That validation setup needs correction; the accepted Stage A implementation does not.**

## Next step: one bounded isolation requalification

Return to the **existing implementation Codex conversation**. The new handoff preserves every candidate byte and permits only external validation setup.

It requires native, unmodified Stage A tests first. For broader validation, it explicitly permits a narrowly bounded **test-root build adapter**: an external backing copy changes only the inherited root constant to the appropriate scratch tree, with a separate canary confirming the compiled binding. Every original assertion, production file, helper and module remains unchanged.

This distinction is important: Go’s build overlay does not virtualize runtime filesystem access. The adapter must change the compiled test-root value and establish correct helper routing before the broader run. Its result must be labeled **test-root-adapted broad validation**, not an unmodified full-suite pass. [Go Packages](https://pkg.go.dev/cmd/go?utm_source=chatgpt.com)

The task also requires independent scratch Git context, behaviorally qualified temporary paths and ownership, and one matched pristine/candidate broad pair. Any remaining failure must be classified from actual source and diagnostics. **No unrelated dirty fixes, test weakening, repository edits, staging or commit are authorized.**

This avoids both bad outcomes: treating contaminated evidence as a clean baseline comparison, or turning this inert Stage A contribution into a repository-wide cleanup project.

## Ready-to-relay handoff

R6J_R928_STAGE_A_CANDIDATE_ISOLATION_REQUALIFICATION_20261027_01.zip[Download the candidate-isolation requalification capsule](sandbox:/mnt/data/R6J_R928_STAGE_A_CANDIDATE_ISOLATION_REQUALIFICATION_20261027_01.zip)

**2,643,552 bytes** · SHA-256:

```text
c9f488c5d53617a8b9b83b8056da810f278f38a9e3e3e3708193f0896102ba9a
```

R6J_R928_STAGE_A_CANDIDATE_ISOLATION_REQUALIFICATION_20261027_01.md[Standalone prompt](sandbox:/mnt/data/R6J_R928_STAGE_A_CANDIDATE_ISOLATION_REQUALIFICATION_20261027_01.md) · R6J_R928_STAGE_A_CANDIDATE_ISOLATION_REQUALIFICATION_20261027_01_VERIFICATION.json[Capsule verification](sandbox:/mnt/data/R6J_R928_STAGE_A_CANDIDATE_ISOLATION_REQUALIFICATION_20261027_01_VERIFICATION.json)

The capsule contains the exact candidate review and its nested accepted evidence chain, expected identities, source evidence, assessment and complete prompt. **No additional upload of the 168 MB owner envelope is required.**

Send:

> Please execute `PROMPT.md` from the attached capsule. Preserve the accepted S3 source and exact candidate, correct only the external validation context, and return the native and explicitly test-root-adapted results separately. Do not repair repository files, stage, commit, push or begin Stage B.

**Sources:** R6J_R928_STAGE_A_HEAD_BASED_COMMIT_CANDIDATE_REVIEW_20261027_01.zip[Supplied candidate review](sandbox:/mnt/data/R6J_R928_STAGE_A_HEAD_BASED_COMMIT_CANDIDATE_REVIEW_20261027_01.zip); SOURCE_EVIDENCE.md[HEAD-matched source evidence](sandbox:/mnt/data/r928_candidate_followup/SOURCE_EVIDENCE.md); linked inspection and assessment; official Go documentation cited above.

**Confidence:** delivered-byte integrity and reconstruction **0.99**; retained result accounting **0.98**; validation-isolation finding **0.99**. Candidate commit readiness remains **unestablished**. The exact S3 acceptance is unchanged; authority-dependent adoption and runtime qualification remain outside it.
