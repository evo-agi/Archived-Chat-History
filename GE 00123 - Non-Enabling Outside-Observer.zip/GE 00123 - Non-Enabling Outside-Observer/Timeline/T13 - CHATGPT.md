**The plan is ready for bounded implementation, with one concrete correction: `EvidenceFrameV1` has 17 fields, not 16.** I have incorporated that correction into the implementation handoff. Another planning round or R9.29 artifact repair is not needed.

The next step is **parent-only Stage A implementation in the existing Codex conversation**, followed by a fresh independent audit. R9.28’s bounded artifact acceptance remains intact; **`AUTHORITY_DEPENDENT_ADOPTION_NOT_READY`** remains in force. The plan correctly separates those two decisions. Pasted text

## The correction that must precede code

The report describes `EvidenceFrameV1` as having “closed 16 fields.” Pasted text

I checked the exact accepted owner. Its current sources agree:

| Object | Exact field count | Source |
|---|---:|---|
| Complete `EvidenceFrameV1` message | **17** | `target/architecture/WIRE_SCHEMA_REGISTRY.json:1005–1023`; `tools/r928_protocol.py:63–69` |
| Record-hash input, after omitting `record_hash` | **16** | `tools/r928_protocol.py:778–780` |

The distinction matters: a 16-field hash input must not become the accepted complete wire message. The implementation prompt requires a native regression that accepts the complete 17-field object, rejects each individual omission and unknown fields, and separately checks hashing of the exact 16-field core. **`AckV1` remains eleven fields.**

The exact excerpts and inspected identities are preserved in the R6J_R928_STAGE_A_PLAN_ASSESSMENT_SOURCES_20261027_01.md[assessment source note](sandbox:/mnt/data/R6J_R928_STAGE_A_PLAN_ASSESSMENT_SOURCES_20261027_01.md). This corrects the planning report—not the accepted protocol.

## What the plan gets right

The eleven-path scope is appropriately bounded: two additions to existing governing documents, one new protocol document, one new root contract-test file, and seven files in the private `outsideobserverprotocol` package. It leaves active admission, runtime-helper, API, configuration, job construction, shared-kernel and dependency surfaces untouched. Pasted text

More importantly, it distinguishes **structurally valid untrusted data** from authenticated or authorized data. A successfully parsed Ack is not yet bound to a recovered transaction; a well-formed Hello is not an authenticated session; a self-consistent journal hash is not a durable commit. The plan places recovery, chronology and restart relationships at their later executable gate rather than claiming that Stage A schemas establish them. Pasted text

The newly identified authority-schema discrepancy is also real and correctly excluded from this implementation. The permit contract allows `issuer_id` and `key_id` as ASCII strings of length 1–128, while the receipt registry applies the narrower lowercase identifier grammar. The report explicitly leaves permit, consume-request, receipt and `RunEntryV4` executable types and validators outside Stage A. Pasted text

I independently confirmed that discrepancy in the owner’s `AUTHORITY_AND_PERMIT_CONTRACT.json:156` and `WIRE_SCHEMA_REGISTRY.json:1235–1240,1402–1407`. **Do not silently narrow both schemas to their intersection or normalize identifiers.** That would select a future authority contract by implementation convenience. The handoff requires the issue to remain documented and resolved before the first dependent authority implementation.

Likewise, keeping `DerivedSourceState` as an internal representation without a parser, serializer or store avoids turning the reported `SOURCE_STATE/v2` literal gap into an executable wire decision. Pasted text

## The dirty checkout needs a precise write boundary

Codex reports the same HEAD and **66 modified plus 17 untracked paths**, but it correctly acknowledges that matching status and diff-stat hashes do not prove historical byte identity across all 83 files. It provides exact current identities for the two planned overlapping documents and reports the other nine proposed paths absent. Pasted text Pasted text

The implementation handoff therefore requires:

- **A fresh opening baseline before edits:** verify repository identity, exact changed-path set, the two document hashes, absence of the nine new files, and safe classification before running the supplied provenance recipe.
- **An eleven-path opening-to-closing delta:** preserve unrelated work byte-for-byte, make localized additive insertions to the two existing documents, and bind every new file’s contents.
- **A reconstructable audit target:** retain before/after bytes, a tranche-only patch, a scratch-tree replay comparison, and repeated opening and closing manifests.

The full diff against HEAD must never be presented as “the Stage A patch.” That would incorrectly include the pre-existing work. The supplied v1 recipe remains unchanged and supplements—not replaces—the tranche-specific delta proof. This follows the plan’s intended provenance treatment and the project’s distinction between byte identity and correctness. Pasted text Governed Execution Provenance G…

## Ready-to-relay implementation handoff

R6J_R928_STAGE_A_PARENT_ONLY_IMPLEMENTATION_20261027_01.zip[Download the Stage A parent-only implementation capsule](sandbox:/mnt/data/R6J_R928_STAGE_A_PARENT_ONLY_IMPLEMENTATION_20261027_01.zip)

**Size:** 131,826 bytes  
**SHA-256:**
```text
53bdb061ae2cdacca5b77884deba1ae5759519963bc126794932cf2e865d9ac5
```

The capsule contains the complete prompt, exact Codex plan, accepted review, prior planning instruction, source assessment, an independently calculated synthetic segment-ID test vector, and the exact provenance recipe and guidance. Its 13-member archive and self-excluding manifest were reopened and verified.

R6J_R928_STAGE_A_PARENT_ONLY_IMPLEMENTATION_20261027_01.md[Standalone implementation prompt](sandbox:/mnt/data/R6J_R928_STAGE_A_PARENT_ONLY_IMPLEMENTATION_20261027_01.md) · R6J_R928_STAGE_A_PARENT_ONLY_IMPLEMENTATION_20261027_01_VERIFICATION.json[Capsule verification](sandbox:/mnt/data/R6J_R928_STAGE_A_PARENT_ONLY_IMPLEMENTATION_20261027_01_VERIFICATION.json)

Use the existing Codex conversation in workspace-write mode, attach the capsule, and send:

> Please execute `PROMPT.md` from the attached capsule. Continue with the corrected Stage A plan as the sole writer; do not stage, commit, push or activate runtime behavior.

That conversation must retain access to the **exact R9.28 delivery envelope already supplied**. The capsule includes the accepted review again but deliberately does not duplicate the 168 MB envelope.

The prompt authorizes only the eleven-path implementation, specified local validation and external evidence packaging. It requires native structural tests rather than recycled artifact pass counts, preserves the unresolved authority gates, and prohibits Stage B engines or runtime integration. The subsequent independent audit remains a separate, fresh conversation against the exact resulting bytes.

**Sources:** Codex’s attached Stage A plan; authenticated R9.28 owner excerpts and identities in the R6J_R928_STAGE_A_PLAN_ASSESSMENT_SOURCES_20261027_01.md[assessment source note](sandbox:/mnt/data/R6J_R928_STAGE_A_PLAN_ASSESSMENT_SOURCES_20261027_01.md); project provenance guidance.

**Confidence:** inspected artifact identities and field-count correction **0.99**; bounded implementation sequencing **0.95**. Current checkout facts remain **Codex-reported**. I did not access the live repository, execute its tests, rerun the artifact model, or assess an implementation that does not yet exist.
