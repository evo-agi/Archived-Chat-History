Here is Codex's response:

**`R6J_R928_STAGE_A_IMPLEMENTATION_PARTIAL`**
I implemented the corrected Stage A slice in the eleven permitted paths. The complete `EvidenceFrameV1` now requires **17 fields**; its record-hash preimage has 16. The new private package returns only untrusted structural data. No production route, config, job, or runtime behavior was activated.
The required Go test gates remain open: `go.mod` requires **Go 1.26.5**, and the installed local toolchain is **1.26.1**. All five required test commands stopped before compilation. `git diff --check` passed. Supplemental offline checks passed 51 private test events, all 3 new root guards, and a repository-wide compile-only sweep using an external temporary modfile. Supplemental admission guard tests still hit the toolchain requirement through nested Go commands.
Provenance closed: both opening manifests match each other, both closing manifests match each other, all **81 protected paths** are unchanged, and a scratch replay reconstructed all **11** touched files byte for byte. HEAD and the empty index are unchanged.
[Download the review ZIP](/Users/ds/Downloads/R6J_R928_STAGE_A_IMPLEMENTATION_PARTIAL_REVIEW_20261027_01.zip) — 359,853 bytes; SHA-256 `1a362de29449f5b504ae7fc74d2aa9591e434568eda5195a7a5f85afa2e1730c`. It contains the full eleven-path before/after inventory, patch, manifests, replay proof, and command outputs.
`AUTHORITY_DEPENDENT_ADOPTION_NOT_READY`\
`INDEPENDENT_AUDIT_NOT_PERFORMED`\
`RUNTIME_ACTIVATION_NOT_PERFORMED`\
`STAGING_NOT_PERFORMED`\
`COMMIT_NOT_PERFORMED`\
`PUSH_NOT_PERFORMED`
