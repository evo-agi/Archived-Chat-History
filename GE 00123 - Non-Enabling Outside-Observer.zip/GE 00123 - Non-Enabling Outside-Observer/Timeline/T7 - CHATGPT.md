# Verdict

**`R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_27_ARTIFACT_REVIEW_BLOCKED`**

R9.27 is authentic, reproducible, and materially stronger than R9.26. It is nevertheless **not ready for independent acceptance, repository-adoption planning, or implementation prompting**.

The delivery successfully closes much of the earlier work:

- The canonical parser now has an ASCII-exact numeric grammar and a total refusal boundary.
- The split commit-hash and commit-ID domains, CRC32C scope, post-commit ACK offset, exact `EvidenceFrameV1` wrapper, and mathematical size bounds are consistently selected.
- Exact field/type checks reject JSON booleans in integer positions.
- The recovery function materially returns a longest valid committed prefix, derived state, durable end, and classified tail.
- The capability-free endpoint model remains consistent.
- The selected-tree reconstruction, active-map and profile preservation, checkpoint, repeatability, and delivery packaging all reproduce.

Four high-severity semantic defects remain, accompanied by one medium-severity control-adequacy defect.

## Independently reproduced successes

The complete 162,265,960-byte delivery envelope authenticates at SHA-256:

`c930e5f6dcfb3686570fe61efba77d55feba955e4e883d69e55a497990071afb`

The owner, checkpoint, validation evidence, frozen inputs, prior blocked review, and direct versus embedded copies all pass ZIP safety, entry uniqueness, encryption, file-type, CRC, and manifest verification.

I independently reproduced:

- **71 reconstructed members**
- **15,028,839 reconstructed bytes**
- zero route, selected-manifest, final-owner-manifest, or final-owner-byte differences
- exact preservation of all **429 active-map records**
- byte-identical preservation of all four profile cores
- the checkpoint save/reopen result
- two byte-identical frozen-input generations
- the final artifact reader at **16/16**
- the finite control suite at **354/354**

The repeated reader result is exactly:

- 6,257 bytes
- SHA-256 `20ff2d67fc0914b84a67a2f9f28a4928f1d4b724bbe97ca38f26c8319a5163c1`

Those are genuine structural successes. The problem is that the selected checker and controls do not model several required relationships.

## Blocking findings

| ID | Severity | Finding |
|---|---|---|
| **R927-F01** | High | `AckV1.journal_segment_id` has two incompatible current definitions. |
| **R927-F02** | High | Chronology accepts a malformed Ack when its hash is recomputed. |
| **R927-F03** | High | Chronology can be constructed and accepted without any journal reread or recovery. |
| **R927-F04** | High | Restart validation accepts a committed post-restart history that is not a prefix of the pre-crash history. |
| **R927-F05** | Medium | The 354-control suite cannot detect the four defects above. |

### 1. `journal_segment_id` is internally contradictory

The current wire registry and private protocol define:

```text
SHA256(
  "R6J-OBS-JOURNAL-SEGMENT/v1" ||
  NUL ||
  canonical {run_id, source_instance_id, epoch, endpoint_nonce}
)
```

The R9.27 reference model instead sets and validates:

```text
journal_segment_id = journal_identity_sha256
```

For the delivered fixture:

- selected registry formula:  
  `c317a4abb74b2a3e60217a42aff40f6b9f266e8d3d1686995cfe19a5c66d9b04`
- delivered Ack value:  
  `456010167efa689ecb54bf7b4e5fdd301288569c82e5faa1e97c9827ec10a27d`

The values differ, yet `validate_ack` accepts the delivered Ack.

This was not one of the seven authorized R9.27 corrections. It silently changes an inherited wire field while leaving the current registry and frozen private protocol unchanged. A future implementation would therefore have to make an unreviewed protocol choice.

### 2. A malformed Ack passes chronology

`validate_chronology` verifies the hash of the Ack object supplied by its caller. It does **not** call `validate_ack`.

I changed the Ack’s:

- `run_id`
- `source_instance_id`
- `epoch`
- `sequence`
- `record_hash`
- `journal_segment_id`
- `durable_offset`

I then recomputed `ack_sha256`.

Direct Ack validation correctly refused the object with:

```text
JOURNAL::ACK_BINDING: run_id
```

The same Ack was accepted by `validate_chronology`.

Consequently, the final chronology event can cryptographically identify an Ack that does not belong to the transaction it purports to acknowledge.

### 3. The chronology is not recovery-derived

`build_transaction` creates the commit, derives state directly from it, and immediately constructs events named:

- `fdatasync`
- `reread-validation`
- `state-publication`
- `ack`

No reread or recovery occurs first.

`validate_chronology` receives caller-supplied objects, record bytes, and an offset. It receives neither a journal byte image nor a `RecoveryResult`, and it never invokes `recover_journal`.

An independently constructed transaction at arbitrary offset `123456`, absent from any journal, was accepted and claimed durable offset `126641`.

The model therefore proves that a synthetic event bundle is internally consistent. It does not prove the selected R9.27 claim that the state, record identities, offsets, and Ack came from the **same reread and recovered transaction**.

This does not require the artifact model to prove that a real operating-system `fdatasync` occurred. It does require the model’s `reread-validation` and publication facts to be derived from the supplied journal image rather than constructed in advance.

### 4. Restart validation does not prove prefix preservation

`validate_restart_identity` compares only header fields. The sole `restart-pair` control then checks:

- the post-restart state;
- the post-restart transaction count; and
- that the pre-crash image contains more transactions.

It never compares the committed histories.

I constructed a same-header post-restart journal with one valid committed transaction that differed from the first transaction in the pre-crash journal:

- pre-crash first commit:  
  `981a66ec14ac24e8c32c8f78f9583281b80758d0d22c3f55d8737f3c891e2abf`
- post-restart first commit:  
  `4dbf3d1a416ac99d0fa7cd0127d9fa071992c8d6affd2e0d7383af7308fcb4eb`

The post-restart history was **not** a prefix of the pre-crash history, but the supplied restart-pair condition evaluated true.

That does not establish that only a volatile trailing transaction disappeared. It allows the durable prefix itself to be replaced.

### 5. Why 354/354 does not close these issues

The finite-suite result is accurate, but its coverage is incomplete:

- There are zero controls referring to `journal_segment_id`.
- The only restart-pair control uses the weak header/state/count test.
- The chronology controls mutate a synthetically built transaction rather than starting from raw journal bytes and recovery.
- The cross-surface controls compare commit domains, CRC scope, ACK offset, frame selection, bounds, encoding, tail rules, and event schemas—but not the Ack segment-domain formula.
- No control supplies a malformed Ack with a recomputed event hash.

The suite therefore cannot detect R927-F01 through R927-F04.

## Required continuation

The correct next step is a bounded **R9.28 artifact-design repair**, not Codex, repository work, adoption planning, or runtime qualification.

R9.28 should preserve all passed R9.27 work and make five focused changes:

1. Restore the inherited `R6J-OBS-JOURNAL-SEGMENT/v1` formula in Ack construction and validation, unless an explicit migration changes every current surface.
2. Run complete Ack validation from chronology before accepting `ack_sha256`.
3. Derive chronology from the exact post-fdatasync journal image and its recovery result.
4. Prove that post-restart committed bytes and transaction identities are an exact prefix of the pre-crash image.
5. Add controls for all four counterexamples and correct the stale `R9.26 control method` heading.

## Review artifacts

R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_27_ARTIFACT_REVIEW_BLOCKED_20261026_01.zip[Download the complete R9.27 blocked-review package](sandbox:/mnt/data/R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_27_ARTIFACT_REVIEW_BLOCKED_20261026_01.zip)

- Size: **21,805 bytes**
- SHA-256: `bfe85b10c09dc7baf8997756b104d34ed7f52fbb287882fd5529ff7c832476de`
- Members: **15**
- Self-excluding payload: **14 members, 44,871 bytes**
- Manifest SHA-256: `16a98dae3ed1223568e450090265e2e17dfe4d6b8dab17aa65087bb45ac79786`

The package contains the verdict, full review, five findings, requirement matrix, authentication report, independent reproduction results, exact counterexamples, contract contradictions, control-adequacy analysis, source index, method and limits, portable reproducer, and R9.28 task.

:chatgpt-content-reference{index="1"}[Download the relay-ready R9.28 repair prompt](sandbox:/mnt/data/R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_28_REPAIR_PROMPT_20261026_01.md)

- Size: **6,255 bytes**
- SHA-256: `745a4f520a3b8965cdf21fef10cb15838a3e323d97339fb21f9f11f41af5584d`
- Byte-identical to the review package’s `NEXT_OWNER_TASK.md`

:chatgpt-content-reference{index="2"}[Download the review-package verification](sandbox:/mnt/data/R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_27_ARTIFACT_REVIEW_BLOCKED_20261026_01_VERIFICATION.json)

### Sources

- OWNER_R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_27_COMPLETED_READY_FOR_FRESH_REVIEW_DELIVERY_ENVELOPE.zip[Authenticated R9.27 delivery envelope](sandbox:/mnt/data/OWNER_R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_27_COMPLETED_READY_FOR_FRESH_REVIEW_DELIVERY_ENVELOPE.zip)
- R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_27_ARTIFACT_REVIEW_BLOCKED_20261026_01.zip[Complete fresh-review package](sandbox:/mnt/data/R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_27_ARTIFACT_REVIEW_BLOCKED_20261026_01.zip)
- :chatgpt-content-reference{index="5"}[R9.28 continuation task](sandbox:/mnt/data/R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_28_REPAIR_PROMPT_20261026_01.md)

**Confidence:** archive authentication 0.99; structural reproduction 0.99; semantic blocking verdict 0.98. Repository implementation and live-runtime behavior were not assessed.
