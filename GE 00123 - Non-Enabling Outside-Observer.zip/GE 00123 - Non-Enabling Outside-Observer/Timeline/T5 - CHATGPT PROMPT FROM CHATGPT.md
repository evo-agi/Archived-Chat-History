Next owner task — R9.27 correction
Continue as the artifact-only design owner for the successor to the blocked R9.26 outside-observer protocol closure.
Required inputs
Authenticate and read:
1. OWNER_R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_26_COMPLETED_READY_FOR_FRESH_REVIEW_DELIVERY_ENVELOPE.zip
   - exact size: 164516781 bytes
   - exact SHA-256: dc0120533e700a080d218ab06791a2cc82662efacf5aed96e0d3e39fa10b2a46
2. R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_26_ARTIFACT_REVIEW_BLOCKED_20261026_01.zip
3. the owner, checkpoint, validation evidence, R9.25 predecessor, and prior review carried inside the authenticated R9.26 delivery
Read this review package's README_FIRST.md, VERDICT.json, REVIEW_REPORT.md, FINDINGS.json, REQUIREMENT_MATRIX.json, TARGETED_COUNTEREXAMPLES.json, CONTRACT_CONTRADICTIONS.json, CONTROL_ADEQUACY.json, SOURCE_INDEX.md, and METHOD_AND_LIMITS.md before authoring.
Author one complete successor under the same migration family with normative section R9.27. Preserve the accepted R9.21–R9.26 ownership, topology, PID1/direct-parent, Wait/reap, SPIFFE, endpoint-authentication, stage-gating, modeled-profile, active-map, exact-P-action, endpoint-nonce, capability-free receiver, reconstruction, checkpoint, repeatability, delivery, and nonclaim decisions except where this review requires a correction. Preserve the exact 429-record active map and the four profile cores unless an explicitly documented correction requires a bounded change.
Required corrections
1. Make canonical JSON parsing total and ASCII-token exact
- Tokenize numeric grammar from raw bytes or explicit ASCII code points only. Unicode isdigit() or equivalent broad Unicode classifications must not decide JSON number tokens.
- Every malformed byte string must return one deterministic refusal code. No malformed input may escape as ValueError, OverflowError, UnicodeError, recursion error, or another uncaught parser exception.
- Preserve exact UTF-8, BOM, key order, duplicate-key, scalar, surrogate, escape, integer-only, non-finite, whitespace, trailing-data, and byte-equality rules.
- Add finite controls for superscript, Arabic-Indic, fullwidth, and other digit-like non-ASCII characters outside strings, including after -, plus malformed-byte fuzz or an exhaustive bounded corpus proving total refusal behavior.
- Preserve positive string controls for -0, 1.0, 1e2, and literal \u0061.
2. Select one Journal V2 wire and durability contract everywhere
Adopt the R9.26 split domains as the single selected contract unless the successor explicitly replaces them everywhere:
- commit_hash = SHA256("R6J-JOURNAL-COMMIT-HASH/v2" || NUL || canonical commit core);
- commit_id = SHA256("R6J-JOURNAL-COMMIT-ID/v2" || NUL || raw commit_hash);
- CRC32C over every canonical journal record payload;
- ACK durable_offset equal to the exact byte offset after the complete framed JournalCommitV2 record.
Remove the superseded single R6J-JOURNAL-COMMIT/v2 definition and EvidenceFrame-only CRC/offset language from every current normative, frozen, architecture, control, binding, fixture, checker, checkpoint, and validation surface. Add cross-surface controls that compare the selected domain strings, CRC scope, and offset definition rather than validating each registry in isolation.
3. Journal the selected outside-observer frame, not an unregistered synthetic schema
- Use the selected EvidenceFrameV1 as the exact observation frame consumed by Journal V2. Do not retain r6j-observation-frame-v2/v1 unless a complete explicit migration replaces EvidenceFrameV1 across every current protocol surface.
- Validate the exact EvidenceFrameV1 field set, types, bounds, canonical payload, payload hash, record hash, previous-record chain, source sequence, run/entry/permit/source/epoch/session bindings, and endpoint-nonce lineage before append.
- Reconcile frame and record bounds so every protocol-permitted EvidenceFrameV1 can be represented in JournalFrameV2. Account for the expansion of the selected byte encoding; do not leave a 2,162,688-byte wire frame behind a 65,536-byte journal cap or a wrapper that cannot fit the journal-record limit.
- Freeze one exact byte encoding for the embedded frame and derive its maximum canonical JournalFrameV2 payload size mathematically.
4. Enforce exact JSON types and bounds for every record and event
- Apply exact u32, u64, string, enum, hex, and literal checks to every field in JournalHeaderV2, JournalFrameV2, JournalCommitV2, SOURCE_STATE.json, and every chronology event.
- Explicitly reject JSON booleans where an integer is required. Equality to sequence 1 is not a type check.
- Define closed event schemas for append-frame, append-commit, fdatasync, reread-validation, state publication, and ACK.
- Bind append event hashes to the actual framed bytes, publication state to reread-derived state, and every offset/commit identifier to the same recovered transaction.
5. Derive restart and cache identity from the parsed journal header
- Return the validated journal-header identity as part of derived journal state.
- Require pre-restart and post-restart headers to match exactly on run, source instance, epoch, entry, permit, endpoint nonce, receiver session nonce, and journal nonce under the selected restart contract.
- Derive every SOURCE_STATE.json identity field from the post-restart header and recovered chain. Remove fixture constants from production validation logic.
- Bind the recovered chain to its header identity through one explicit domain or exact cross-binding. Add independent negatives for every header/cache and pre/post-header mismatch.
6. Implement actual longest-valid-prefix recovery
- Parse and return the longest valid committed chain, its durable end offset, derived state, and classified tail.
- Reconcile the current contradiction between “any post-terminal record refuses” and crash row JCRASH-08, which says a partial or invalid tail after COMPLETE retains the COMPLETE prefix and is truncated. Select one exact rule for partial, invalid, uncommitted, and complete valid post-terminal tails and propagate it everywhere.
- For the selected rule, prove recovery for partial frame, frame without commit, partial commit, corrupt CRC, broken chain, uncommitted complete pair, partial tail after COMPLETE, and complete valid record after COMPLETE/ABORTED.
- Do not map every partial post-restart tail to loss of the preceding committed transaction.
7. Bind chronology contents, not only event names and order
- Validate exact event field sets and types.
- Require append-frame and append-commit hashes to equal the actual framed records.
- Require published state to equal the reread-derived state.
- Require fdatasync and reread offsets, ACK commit ID and offset, and all event transaction identities to refer to the same recovered commit.
- Add controls showing that zeroed append hashes, stale state publication, duplicate events, extra fields, boolean ordinals, and cross-transaction substitutions refuse.
Validation and stop conditions
Save and reopen the first substantive corrected checkpoint before broad control expansion. Re-run the complete finite suite, all independent counterexamples above, two byte-identical frozen-input generations, two byte-identical final reader runs, and a fresh selected-tree reconstruction against the final-owner manifest. Preserve exact commands, inputs, stdout, stderr, exit codes, structured results, and byte identities.
Stop rather than claiming completion if:
- any malformed canonical input can raise outside the refusal interface;
- any current surface retains incompatible commit, CRC, ACK-offset, observation-frame, size, recovery, or terminal-tail semantics;
- any exact integer field accepts a boolean;
- cache or restart identity is hard-coded or not derived from the authenticated journal header;
- controls validate only event names/order while ignoring event content;
- recovery does not materialize the longest valid committed prefix and selected tail treatment;
- reconstruction, endpoint consistency, preservation, checkpoint reopen, repeatability, or delivery completeness regresses.
Do not launch Codex, access repositories or hosts, execute programs inside predecessor or reviewer archives, implement source, issue credentials or authority, adopt the proposal, wire production, execute runtime behavior, or claim live qualification or independent acceptance.



















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Drag to reorder pinned navigation items


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
