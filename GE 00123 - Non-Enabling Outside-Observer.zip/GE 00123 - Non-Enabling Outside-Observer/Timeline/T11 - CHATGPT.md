**Codex was right to stop the authority-dependent adoption plan. R9.28’s bounded artifact acceptance remains intact.** I would not start another artifact-repair cycle or build a new issuer merely to unblock Stage A.

The next step is to **complete a narrower, non-enabling Stage A plan**, while keeping the issuer contract explicitly unresolved. Codex’s report supports that distinction: it identifies the missing authority contract, but also identifies a separable static-contract tranche with no active runtime integration. Pasted text Pasted text

## What Codex correctly found

The accepted owner does assume an “existing `RunEntryV4` issuer.” I checked the actual artifact, not just the report:

- `target/architecture/AUTHORITY_AND_PERMIT_CONTRACT.json:10–18` assigns launch authority and permit consumption to that assumed issuer.
- Lines **3–8** expressly exclude ES admission, the observer, receiver, app and runtime helper from permit-consumption authority.
- Lines **156 and 194–196** depend on that issuer’s verification suite and receipt-signing contract.

Codex reports that it could not find the corresponding issuer, permit or receipt contract in the inspected ES checkout. That is a genuine integration gap—not something artifact authentication or the earlier 505/505 controls can resolve. Pasted text

There is also an important historical qualification. The earlier tranche history described the independent approver/custodian as a **proposed role**, with the external actor’s implementation left to a later gate. Consequently, “existing issuer” must not become a repository fact merely because that wording survived through successive artifact revisions. The exact authority, stage and historical excerpts are retained in the R6J_R928_STAGE_A_BLOCKER_ASSESSMENT_SOURCES_20261027_01.md[assessment source note](sandbox:/mnt/data/R6J_R928_STAGE_A_BLOCKER_ASSESSMENT_SOURCES_20261027_01.md).

**Do not resolve this by assigning issuance to ES admission or Coordinator by convenience.** That would be a new architectural decision, and assigning consumption to ES admission would contradict the accepted artifact’s explicit ownership exclusion.

## Where I would narrow the blocker

My previous reconnaissance prompt required “no unresolved authority/contract conflict” without sufficiently limiting that condition to the proposed tranche. Codex followed that stop condition. I would now distinguish three things:

| Boundary | Assessment |
|---|---|
| **Bounded R9.28 artifact acceptance** | Retained. This report does not overturn the reviewed protocol corrections. |
| **Authority-dependent repository adoption** | Not ready. Issuer ownership, signature verification, key custody, ledger ownership and receipt semantics remain unestablished in the supplied repository evidence. |
| **Non-enabling documentation and structural schemas** | A bounded plan can proceed, provided it neither chooses those missing contracts nor produces an authorization result. |

The distinction is **structural validity versus authenticity and authority**.

For example, a private package can potentially check a closed field set, canonical encoding, exact integer types, lengths, hash domains and explicitly supplied value bindings. Passing those checks must mean only **“well-formed untrusted data.”** It must not mean “authenticated issuer,” “valid execution grant,” “permit consumed,” or “launch permitted.”

Conversely, non-enablement is not an excuse to leave an executable contract ambiguous. Where a validator actually depends on an unidentified signature suite or authority relationship, that validator stays outside this tranche. The missing decision must be resolved **before its first dependent implementation**, not automatically deferred until production Stage E.

This is a narrower adoption boundary—not a waiver of the authority finding.

## The next tranche should remain bounded

I recommend returning to the **same read-only Codex conversation** to finish one plan for:

**`R6J-R9.28/Stage-A — non-enabling contracts and structural schemas`**

Its governing documentation should distinguish current ES behavior, the accepted artifact model and the unestablished issuer dependency. Its proposed private schemas should remain absent from active admission, runtime-helper, API, configuration and job-construction paths. Authority-bearing verification, permit consumption, persistence, process ownership and executable recovery/chronology/restart engines remain outside this static tranche.

Codex’s preservation requirements are appropriate: retain the existing workload JWT endpoint, Nomad-backed lifecycle projection and bounded `control-plane-normal-shell/v1` compatibility. None should be repurposed to fill the new protocol’s missing authority dependency. Pasted text Pasted text

The completed plan should map the accepted R9.28 corrections to either an actual Stage A structural test or a named later executable gate. It must not claim that schema tests establish the full recovery and restart relationships.

## One additional prerequisite before writing

The checkout is already substantially dirty: Codex reports **66 modified and 17 untracked paths**, with nothing staged. Its opening/closing HEAD, status and diff-stat comparisons are useful reconnaissance evidence, but they are not a byte-complete baseline for a subsequent patch. Pasted text

Before any mutation, the plan needs to identify which proposed files overlap that existing work and how the writer will distinguish:

**pre-existing changes → this tranche’s exact changes → final audit target.**

A manifest covering everything changed relative to HEAD must not mislabel all 83 existing changes as this tranche. The project provenance guidance likewise distinguishes byte identity from correctness and requires tracked and untracked content to be bound precisely. Governed Execution Provenance G… Governed Execution Provenance G…

I have included the exact existing provenance recipe and guidance in the handoff for inspection and later planning. They are **not authorized for execution in this read-only completion turn**.

## Ready-to-relay handoff

R6J_R928_STAGE_A_CONTRACT_ONLY_PLAN_COMPLETION_20261027_01.zip[Download the Stage A plan-completion capsule](sandbox:/mnt/data/R6J_R928_STAGE_A_CONTRACT_ONLY_PLAN_COMPLETION_20261027_01.zip)

It includes the new prompt, Codex’s report, the original reconnaissance task, the accepted-review ZIP, the source excerpts, and the exact project provenance guidance and recipe.

**Capsule identity:** 110,511 bytes  
**SHA-256:** `829dc9829f21f9bacb604b2c4ca06d60108746bd48ccc7a355251d2aadd4fb03`

:chatgpt-content-reference{index="10"}[Download the standalone prompt](sandbox:/mnt/data/R6J_R928_STAGE_A_CONTRACT_ONLY_PLAN_COMPLETION_20261027_01.md)

Send the capsule to the same Codex conversation with:

> Please execute `PROMPT.md` from the attached capsule, continuing the read-only reconnaissance.

That conversation still needs access to the **exact R9.28 delivery envelope already supplied**. The capsule includes the accepted review again but deliberately does not duplicate the 168 MB envelope.

The requested outcome is a complete, byte-grounded **contract-only plan**, alongside an explicit **authority-dependent adoption not ready** status. It does not authorize edits, tests, an issuer implementation, or runtime enablement.

**Sources:** Codex’s attached reconnaissance report; the authenticated R9.28 authority/stage artifacts and historical passages collected in the R6J_R928_STAGE_A_BLOCKER_ASSESSMENT_SOURCES_20261027_01.md[assessment source note](sandbox:/mnt/data/R6J_R928_STAGE_A_BLOCKER_ASSESSMENT_SOURCES_20261027_01.md); project provenance guidance.

**Confidence:** supplied artifact identities **0.99**; scope and sequencing assessment **0.94**. Current checkout facts remain **Codex-reported**; I did not inspect its live dirty files, run repository validation, or reassess runtime behavior.
