**Stage A remains complete locally. Do not push the two-commit range yet.** The preflight correctly isolates a missing predecessor review, but the next step should be **a bounded independent audit of that predecessor—not a request for you to approve it without that review**.

My source inspection also found a specific numeric-type concern in the predecessor’s documentation-test helper. That gives the audit a concrete issue to resolve; this is not merely missing paperwork.

:chatgpt-content-reference{index="2"}[Full assessment, source references and inspection limits](sandbox:/mnt/data/R6J_R928_STAGE_A_PREDECESSOR_PUBLICATION_ASSESSMENT_20261027_01.md)

## What the preflight establishes

The supplied ZIP matches **8,315,341 bytes** and SHA-256:

```text
99c6a99eec1b16460ac98c4c242b2bdd9f279e9d5cce764d496b8f931056a788
```

| Check | My independent artifact-inspection result |
|---|---|
| Archive integrity | **64 members / 63 self-excluding manifest rows** verify. All **16 distinct archives** in the retained chain pass the inspected archive and manifest checks. |
| Predecessor reconstruction | Its patch reconstructs all **eight after-files / 1,267,502 bytes** exactly. Supplied before/after blobs match their recorded identities. |
| Committed projections | The supplied mappings reproduce the **341-entry predecessor tree** and **350-entry Stage A tree** exactly. |
| Stage A preservation | The eleven supplied Stage A blobs and complete index mapping agree with the accepted candidate. |
| Dirty-work preservation | Four retained provenance manifests equal the expected **83-row post-commit manifest**; opening and closing retained ref maps agree. |

The remote receipt records `trunk_dev` at `4f797fb6…` on **October 28, 2026, at 03:42:07 UTC**. The reported outgoing chain is therefore:

```text
4f797fb6…  →  b92bd988…  →  68ec38c3…
remote       TLS contract   accepted Stage A
```

That remains a **time-bounded Codex observation**, not a current remote lock. I did not contact the remote or access the live checkout. Raw commit objects were not packaged, so commit linkage remains supported by Codex’s recorded object checks; I independently recomputed tree and supplied blob identities. INSPECTION.json[Inspection results](sandbox:/mnt/data/r928_publication_followup/INSPECTION.json)

## Why the predecessor needs its own review

`b92bd988…` changes seven documentation files and `docs_contract_test.go`. It adds no production implementation, but it **does change a security-relevant governing contract**.

In particular, it narrows the previous no-replacement language to **reusable P0u**, preserves `unsupported_signing_topology` for that route, and defines a separate one-time external TLS incident. That incident has its own consumption, custody, installation, rollback, ES-acceptance, IM-handoff and retirement rules. The new document also expressly lists independent contract audit and later operational gates as remaining work. SOURCE_EVIDENCE.md[Exact contract and changed-text excerpts](sandbox:/mnt/data/r928_publication_followup/SOURCE_EVIDENCE.md)

Consequently, neither “documentation-only” nor Stage A’s acceptance establishes that this ancestor is ready for publication. Conversely, reviewing or eventually publishing the document must **not** be treated as permission to generate keys, sign certificates, install TLS material, restart services or mutate an IM profile.

The available Chat 00078 history already treats this commit as an existing baseline. My bounded search did not recover its separate earlier acceptance record. **That does not prove no earlier review occurred.** The supplied complete delta now lets us conduct a fresh review without making recovery of old approval history another prerequisite. HISTORY_SEARCH.json[Search scope and limits](sandbox:/mnt/data/r928_publication_followup/HISTORY_SEARCH.json)

## A concrete issue for the auditor: quoted numbers

**PRED-T01 — medium-severity, source-derived test-validator concern; native reproduction outstanding.**

The predecessor’s helper declares seven numeric positions as `json.Number`. Its preflight accepts string and numeric tokens without preserving their field-specific kinds, and its final checks compare only `.String()` against expected text. The relevant implementation is at `docs_contract_test.go:10273–10314` and **10383–10397**. SOURCE_EVIDENCE.md[Source excerpts](sandbox:/mnt/data/r928_publication_followup/SOURCE_EVIDENCE.md)

That creates this candidate counterexample:

```json
"hosts": 1
```

changed only to:

```json
"hosts": "1"
```

Go 1.26.5’s standard decoder accepts valid numeric text inside a JSON string into a `json.Number` destination. Comparing the resulting text with `"1"` therefore does not establish that the original token was a JSON number. [raw.githubusercontent.com](https://raw.githubusercontent.com/golang/go/go1.26.5/src/encoding/json/decode.go)

The same concern applies to `incidents`, `executions`, `fresh_keypairs`, `client_uri_count_per_leaf`, `leaf_maximum_days` and `ca_path_length`. The existing tests cover malformed and near-valued numbers, decimals, exponents and several wrong types—but not these equivalent-text quoted numbers. R6J_R928_STAGE_A_PREDECESSOR_PUBLICATION_ASSESSMENT_20261027_01.md[Test analysis](sandbox:/mnt/data/R6J_R928_STAGE_A_PREDECESSOR_PUBLICATION_ASSESSMENT_20261027_01.md)

**I have not executed the counterexample.** The fresh auditor should prove or refute it against the unchanged helper, with a valid positive control and seven isolated mutations. This is not a finding against the Stage A production parser, and it does not authorize a repair during audit.

## Keep the audit narrow

The predecessor’s relevant tests are not unvalidated in every sense: both retained final adapted broad runs contain **71 passing events—14 top-level tests and 57 subtests—for this selection**. Those are historical results, and they do not cover the quoted-number concern. HISTORICAL_TARGETED_TERMINALS.json[Extracted terminal-event evidence](sandbox:/mnt/data/r928_publication_followup/HISTORICAL_TARGETED_TERMINALS.json)

The next audit should inspect all eight changed paths, assess their authority and custody semantics, rerun those selected tests, and resolve the specific counterexamples. **No broad-suite restart, Stage A re-audit, live TLS proof or new harness-development program is needed.**

I also checked the focused tests’ isolation requirements. The closure test reads the operator script through the inherited absolute-root helper, so a plain scratch checkout would still risk reading the dirty original script. The handoff explicitly reuses the reviewed literal-only test-root adaptation and requires a read-only routing canary. It labels those results as **adapted focused validation**, not unmodified native validation. SOURCE_EVIDENCE.md[Pinned helper evidence](sandbox:/mnt/data/r928_publication_followup/SOURCE_EVIDENCE.md)

## Ready-to-relay predecessor audit

Use a **fresh read-only Codex conversation** with this single attachment:

R6J_R928_STAGE_A_PREDECESSOR_PUBLICATION_AUDIT_CAPSULE_20261027_01.zip[Download the predecessor publication-audit capsule](sandbox:/mnt/data/R6J_R928_STAGE_A_PREDECESSOR_PUBLICATION_AUDIT_CAPSULE_20261027_01.zip)

**8,472,060 bytes** · SHA-256:

```text
f1eadece0a672b08977d9ae67c4e2885a1f696f74559794cfd2243bcc963a79e
```

R6J_R928_STAGE_A_PREDECESSOR_PUBLICATION_AUDIT_PROMPT_20261027_01.md[Standalone prompt](sandbox:/mnt/data/R6J_R928_STAGE_A_PREDECESSOR_PUBLICATION_AUDIT_PROMPT_20261027_01.md) · R6J_R928_STAGE_A_PREDECESSOR_PUBLICATION_AUDIT_CAPSULE_20261027_01_VERIFICATION.json[Capsule verification](sandbox:/mnt/data/R6J_R928_STAGE_A_PREDECESSOR_PUBLICATION_AUDIT_CAPSULE_20261027_01_VERIFICATION.json)

The capsule contains the exact preflight evidence and nested Stage A acceptance chain, predecessor and parent mappings, expected live baseline, source assessment, focused test selection, counterexample specifications and provenance guidance. **No additional owner-envelope upload is required.**

Send:

> Please execute `PROMPT.md` from the attached capsule in this fresh read-only conversation. Independently audit predecessor `b92bd9884106154d25342e1573dcc4c312311436` for publication, resolve PRED-T01, and preserve the accepted Stage A commit and all dirty work. Do not repair, rewrite history, stage, commit, push, perform TLS operations or begin Stage B.

An `ACCEPT` would close this separate review prerequisite. Publication would still require its own exact-range effect gate. A finding would receive a bounded correction plan—not an automatic amendment, cherry-pick or reopening of Stage A.

**Sources:** R6J_R928_STAGE_A_PUBLICATION_RANGE_PREFLIGHT_EVIDENCE_20261027_01.zip[Supplied publication preflight](sandbox:/mnt/data/R6J_R928_STAGE_A_PUBLICATION_RANGE_PREFLIGHT_EVIDENCE_20261027_01.zip); linked assessment, source excerpts and inspection records; release-tagged Go source cited above.

**Confidence:** delivered-byte consistency **0.99**; retained selected-validation evidence **0.98**; numeric-kind concern from source inspection **0.96**, pending native reproduction. Stage A’s local acceptance is unchanged; predecessor publication acceptance and live operational readiness remain unestablished.
