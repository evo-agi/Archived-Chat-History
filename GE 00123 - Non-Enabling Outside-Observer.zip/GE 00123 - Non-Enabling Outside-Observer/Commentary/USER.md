`Timeline/T0 - USER.md` is the start for Chat GE 00123.

Well, shit. Chat GE 00123 started putting prompts in files, at `Timeline/T1 - CODEX PROMPT FROM CHATGPT.md`. How? Because I supplied Chat EG 00078's history? 

I'm very excited to see the result in `Timeline/T22 - USER.md`, though I've long lost track of what we are working on...

`Timeline/T26 - USER.md`... Spoke too soon. :/

`Timeline/T43 - CHATGPT.md`... Finally.
