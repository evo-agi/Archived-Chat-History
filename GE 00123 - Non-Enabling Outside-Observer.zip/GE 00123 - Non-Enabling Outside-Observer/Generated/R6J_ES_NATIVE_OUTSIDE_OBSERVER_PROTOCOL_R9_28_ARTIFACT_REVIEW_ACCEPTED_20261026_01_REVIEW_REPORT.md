# R9.28 independent artifact review — accepted

**Verdict:** `R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_R9_28_ARTIFACT_REVIEW_ACCEPTED`.

The bounded R9.28 correction gate is closed. All five R9.27 review findings are resolved in the inspected successor. There are no blocking findings in this review scope. One low-severity subsection-navigation defect is retained as an external erratum; it does not require another owner-design repair.

This verdict accepts artifact design and artifact-model validation only. It does not change owning repository contracts, establish a deployed capability, authorize repository mutation, qualify physical durability, or permit production wiring. The sealed owner's original `independent_acceptance: false` records remain untouched; this independent decision is a separate evidence artifact.

## Exact accepted input

| Object | Bytes | SHA-256 |
| --- | ---: | --- |
| R9.28 delivery envelope | 168,307,308 | `5b637a7247af865c888590863b021db9e5aa7fc15dd91aed50ad552a2cbad33c` |
| R9.28 owner | 167,125,065 | `b9c1f5933155d39cf5f656f9ca6a69d27fa86c7ccac4bdfd32aee57b829bb647` |
| Independent delivered-reader result | 13,530 | `da7044cb2ce4910359aae3fa49450a35b009727dccd2407e02fca3281478f893` |

The independently recomputed framed contract/map identity is `d73fb665dc72eb35bd1cd2a36ccb5be2538b3f8258a0a6f739025d9e9a2c2d1d`. The complete predecessor contract is an exact prefix of the new contract; the suffix is two LF bytes followed by the exact R9.28 appendix.

## Semantic correction closure

### R927-F01 — selected Ack segment identity: closed

`compute_journal_segment_id` validates the parsed header and hashes exactly the four-field canonical core `{run_id, source_instance_id, epoch, endpoint_nonce}` under `R6J-OBS-JOURNAL-SEGMENT/v1` plus one NUL. Construction and validation call the same helper. It is no longer an alias for wider journal identity. Current wire/private schemas, journal contracts and the relation binding agree. Non-core journal/session fields still participate in their separate identities.

Source: `tools/r928_protocol.py:1043-1047,1079-1104`; `target/normative/R9_28_APPENDIX.md:7-13`. The exact old wrong-segment specimen now refuses. Independent fixtures varying core fields and non-core journal identity also pass the intended distinction.

### R927-F02 — complete Ack validation inside chronology: closed

The direct Ack validator checks exact fields, schema/version, integer types and bounds, IDs/hashes, source-state enum and every context binding. `validate_chronology` invokes it against the journal-recovered header, evidence and state before comparing the Ack event hash. Recomputing `ack_sha256` therefore does not rescue a malformed or misbound Ack.

Source: `tools/r928_protocol.py:1050-1091,1177-1191,1268-1280`; `target/normative/R9_28_APPENDIX.md:15-19`. The exact prior malformed-Ack specimen refuses. Reviewer-authored mutations of every Ack field, including boolean/numeric/type and missing-field cases, also refuse; direct and chronology results agree.

### R927-F03 — raw-image, recovery-derived chronology: closed

The positive boundary now consumes `journal_image`. It calls recovery internally, requires an eligible nonempty committed prefix, and selects its final transaction. Recovery retains actual frame/commit spans, framed bytes and hashes, evidence identity, commit identity and derived state. Chronology binds all six events to those actual slices and that same transaction. Candidate transaction construction returns only candidate frame/commit material, not positive reread state, Ack or chronology.

Source: `tools/r928_protocol.py:1107-1191,1241-1280,1285-1358`; `target/normative/R9_28_APPENDIX.md:21-27`. The arbitrary-offset absent transaction refuses. Independent five-transaction histories, divergent images, incomplete transactions, event-field mutations and event permutations were checked. These are consistency checks against supplied bytes—not evidence that a real operating-system fdatasync occurred.

### R927-F04 — exact persisted-prefix relationship: closed

`validate_restart` recovers both images, compares validated header identities, enforces `post_image[:E] == pre_image[:E]`, compares each corresponding complete recovered transaction and derived state, and checks the exact durable end. Each image must independently satisfy the retained tail policy. Counts and matching headers alone are no longer accepted as proof.

Source: `tools/r928_protocol.py:1407-1466`; `target/normative/R9_28_APPENDIX.md:29-35`. The exact same-header divergent-prefix specimen refuses. Independent probes cover all 36 ordered pairs of zero-through-five committed prefixes, divergence at each transaction position, changed terminal state, header changes, partial records and valid post-terminal transactions.

The selected artifact contract deliberately proves an image relation, not which writes were physically acknowledged durable. Header-only or shorter exact committed prefixes are permitted under its modeled volatile-suffix rule. This review does not reinterpret that permission as physical durability evidence.

### R927-F05 — validation adequacy for the corrected relations: closed

All 354 original control rows/IDs are retained exactly; 151 relational controls are added. Existing chronology oracles now start from raw-image recovery, and restart-pair evaluation uses the exact-prefix validator. The stale control-method heading is corrected. Cross-surface checks cover the repaired formula, schema and relations.

Source: `tools/model_checker.py:154-164,220-263,341-378`; `tools/relation_checks.py:51-241`; `target/controls/METHOD.md`. Static document-preservation checks remain weaker evidence and are not treated as runtime tests.

## Independent validation and preservation

| Check | Observed result |
| --- | --- |
| Archive safety and manifest checks | 13 inspected archives passed: current envelope/components, exact R9.27 envelope/owner, reconstruction patch and four profile archives |
| Delivered reader | One fresh independent invocation passed 18/18; its bytes equal both physically retained owner runs and the envelope result |
| Delivered finite suite | 505/505 reproduced; the exact four prior counterexamples refuse |
| Reviewer-authored semantic probes | 700/700 passed; separate fixture framing, bitwise CRC32C, domain hashes, commit fixed points, expected state and events |
| Independent selected-tree reconstruction | 80 members / 15,984,985 bytes; 7 predecessor members and 73 patch members; final owner used only as comparison target |
| Active-map preservation | All 429 objects across six arrays are exact |
| Profiles | All four core projections and extensions exact; retained POSITIVE exports unchanged |
| Source preservation | All 53 declared unchanged protocol functions/classes are AST-identical to R9.27 |
| Checkpoint | Physical checkpoint reopened by the delivered reader; exact final model and relation bytes match checkpoint and validation copies |
| Frozen-input repeatability | Reader regenerates twice; generated bytes equal the delivered and both retained frozen ZIPs |
| Archive repeatability | Reviewer independently rebuilt owner, validation archive and envelope twice each; every result matches the respective delivered ZIP exactly |
| Reconstruction guards | Delivered reader reproduces all 12 refusal guards |

Raw evidence is in `AUTHENTICATION.json`, `INDEPENDENT_STRUCTURE.json`, `INDEPENDENT_READER_RESULTS.json`, `INDEPENDENT_SEMANTIC_PROBES.json` and `INDEPENDENT_REPEATABILITY.json`. The test count is not itself the acceptance argument: the inspected data flow, selected contracts, exact reconstructed bytes and negative relations support the verdict.

## Validation history and disclosure

The retained 504/505 first pass contains the stated negative-specimen isolation failure. The subsequent control-source change supplies the genuine append-commit record hash while retaining phantom offsets, so the intended offset guard is reached instead of an earlier correct hash refusal. The inspected protocol module and early checkpoint did not change. The interrupted repeat-reader record grants no pass credit; completed A/B results are physically retained and equal the independently reproduced result.

Checkpoint-before-expansion chronology is supported by retained numbered command receipts and the early checkpoint's contents. This review reopened and compared the checkpoint but did not independently witness the author's historical execution timing.

The separately advertised original final-envelope receiving verification was not supplied outside the envelope. No correctness claim here depends on that report: this review independently authenticates and deterministically rebuilds the actual sealed envelope. This is not a missing normative input or a new blocker.

A reviewer structural probe initially assumed a one-LF separator before the appendix. Inspection showed two LF bytes, with the entire predecessor contract preserved and the framed pair correct. The reviewer assumption was corrected and the failed attempt retained in `REVIEWER_ITERATION.json`; it is not an owner defect. An unsupported streaming-tool attempt also earned no pass credit; the normal reader invocation completed successfully.

## Non-blocking erratum

**R928-O01, low, documentation/navigation.** `target/analysis/SOURCE_DECISION_CROSSWALK.json:4-30` points findings F01–F05 to sections R9.28.1–R9.28.5. Their correct sections are R9.28.2–R9.28.6 (`target/normative/R9_28_APPENDIX.md:7-41`). The associated function names and semantic treatments are correct. Preserve the accepted owner bytes and carry `NONNORMATIVE_ERRATA.json` forward; do not create another design-repair tranche solely for these pointers.

## Continuation and limits

Move to fresh read-only ES repository grounding and a Stage A plan. The artifact's Stage A is docs/contracts, exact private schemas, static validators and contract tests with no mutable authority; Stage E alone concerns production wiring (`target/frozen/STAGE_GATING_V4.json:4-12,35-40`). This review does not establish that Stage A is already implemented or authorize any stage's repository changes.

The local ES checkout, its latest `AGENTS.md`/`PLANS.md`, relevant source/tests/configuration and any newer Codex-reported work must be inspected before selecting touched paths or implementation commands. Do not import the historical corpus, nested proof archives or Python validation package wholesale into the repository, and do not let the proposal override owning contracts silently. The accompanying next-step prompt is read-only.

Inspection covered the current R9.28 correction, its callable validation model, inspected predecessor delta, preservation/binding/reconstruction evidence and delivery. It did not re-derive every historical line of the 551,426-byte temporal corpus, audit all six repositories, execute predecessor/reviewer programs, operate a host or runtime, or test real crash, filesystem, credential, issuer, SPIRE, Nomad or Docker behavior. Hashes establish byte identity/integrity, not signer authenticity, correctness or runtime authority.

**Confidence:** provenance 0.99; structural reproduction 0.99; bounded semantic acceptance 0.95. Repository implementation and live-runtime behavior: not assessed.
