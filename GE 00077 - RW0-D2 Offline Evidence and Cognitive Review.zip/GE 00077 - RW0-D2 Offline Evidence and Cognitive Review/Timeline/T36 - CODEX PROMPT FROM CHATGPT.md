# Governed Execution Coordinator — RW0-D2 A-to-B Binding Audit Repair V3
# ACTIVE TASK: repair final consumption of checkpoint-bound model input
# Preserve V1 authority-role and V2 reason/facts invariants; two-file ceiling

## 0. Routing, execution authority and first protected action

Send ONCE to the original Coordinator IMPLEMENTATION/repair conversation identified
as "00077 54", not the independent auditor that found the crossed-run defect. Leave
all other repository conversations idle. This is a newly authorized SOURCE/TEST
repair interval for the exact repaired-V2 candidate below. It supersedes older
Continuation-04, V1/V2 repair and audit instructions as execution authority for THIS
engagement. Their observations remain historical evidence. Do not re-run a vector
repair, select an old attachment's opening, restart D2, or claim an audit pass.

One parent writer only; no subagents, extra model sessions, provider calls, network,
external suppliers or cross-chat work. Report visible model/effort/permissions or
`not visible`. Dispatch discipline is not OS-level exclusion. If actual source or
index observations establish another writer, stop rather than race it; no provider
state inspection, machine-wide argument scans, unknown-process signaling or new
repository lock/service is authorized.

FIRST protected repository action: read live AGENTS.md as text with tool workdir `/`:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

Read the complete output, with further plain-file reads for truncation. Then run
section 2's filesystem-only opener BEFORE Git, repository listing, source inspection,
imports, tests or edits. Reading this external instruction as plain data is allowed
preparation; prefer an absolute external path and neutral cwd. Cwd alone is not a
Git operation. A genuine protected pre-opening operation requires an immediate stop,
not resetting metadata or silently replacing an opening. The helper checks commands
routed through it; it is not an OS interlock. No initial git status/branch discovery.

After full authentication and the bounded ref check, reproduce both crossed-run
cases, repair the consuming relation, and complete all validation without another
user approval or a mapping-only handoff. This is one bounded repair, not a new
contract, phase, value-grammar or architecture program.

All repository imports/tests/scripts/fake children/disposable SQLite execute ONLY
in positively owned, remote-free external copies. Live operations are inert/guarded
inspection and section 1's two working-file edits. Installed tools only. No live
checkout execution, operator database, credentials/provider state, package install,
source/doc/test outside the ceiling, stage/add -N/write-tree/index/ref/config/worktree
write, commit/fetch/push/PR/merge, service/deployment, sibling repo or ES/Bridge/CP/IM/MA
operation. No public API, schema/version/field-order change, migration/catalog change,
Section 41 post-execution recording, rank-15 admission, complete C2 decision input,
physical C2 decision/acceptance/terminal writer, or new attempt/retry/repair executor.

## 1. Finding, selected repair and exact edit ceiling

The latest independent audit authenticated the complete repaired-V2 subject in a
valid interval, passed all 46 integration nodes, and independently reproduced
R01/J01/J02. It then found a DIFFERENT relational defect. The following is supplied
AUDITOR-REPORTED evidence, not a reconstruction already executed by you:

- A genuine preadmission_ready handback for one candidate accepted the other
  candidate's complete model input, model process and repair_candidate proposal
  while retaining the first candidate's different capsule and checked A evidence.
- Both dataclasses.replace construction and an independently forged exact wrapper's
  explicit validate() accepted this mixed graph. A genuine stopped handback also
  accepted the donor's paired input_context/evidence_supply.
- In the ready probe the recipient capsule digest was
  57c9cc03885c396c583ad3b5b1011cebe1148f96986d173eae41846ca1c0090e,
  while the accepted donor context carried
  d1a674004b8554994a75e8a5b99af892dab36d25a9e780da1c49cead3d296272.
  The recipient's genuine recommendation was accept_candidate; the mixed result
  reported repair_candidate. These are HISTORICAL SPECIMEN values, not constants
  to put in production or pin as the identities of newly generated runs.
- The substitution was in memory: database bytes and child identities did not
  change. It does not establish that the normal producer misattributes results,
  grants executable authority, persists a new decision, or is externally exploitable.
- Reported source pointers: `_rw0_d2_handback.py:266` checks the B subgraph against
  itself; `_rw0_d2b_model_input.py:272` derives its capsule role from the A checkpoint.
  Inspect actual source. Do not treat line numbers as proof of an implementation.

To avoid phase/run ambiguity in your code and report, call the two proof invocations
run_alpha and run_beta. Use D2A/D2B for the evidence/model phases. Run_beta's B graph
being internally valid does not make it evidence about run_alpha's A checkpoint.

SELECTED REPAIR: a PURE final-consuming relation connecting the retained A evidence
checkpoint to its actual B input context/supply, role values, supports and lineage.
Preserve the existing downstream input-to-model/artifact/proposal relations. Enforce
this join whenever the existing final shape retains B input, including stopped and
cleanup-unresolved shapes, not only preadmission_ready. Do not fix only the example
capsule mismatch or use reference names/PID inequality as global run identity.

ONLY these existing C-status candidate paths may change:

| Path | Purpose | Opening bytes | Opening SHA-256 |
|---|---|---:|---|
| `src/ge_nwp_coordinator/_rw0_d2_handback.py` | Own pure A-to-B consuming relation, used by existing construction and validate() | 19,106 | `5e3aca1bbd8fbb82a747f1561ed6c2b65029b14c45d607209a9afb262b867388` |
| `tests/test_rw0_d2_offline_integration.py` | Actual two-run positives/negatives, stopped/consumer tests and bounded omission controls | 41,541 | `486dc60afd7c4a6f6c2982b0d5ad8503722f43e0de449509975952e490b84692` |

Both remain C (working creations absent from HEAD and index). No new file, rename,
delete, mode change or test module. All other 68 candidate payloads and 216
noncandidate tracked payloads are protected. In particular:

- `_rw0_d2a_handback.py`: 20,455 bytes,
  7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f;
- `_rw0_d2b_model_input.py`: 81,718 bytes,
  e2bbe585f8ae19df5dd6547212cf239ac58411795cbae904cf3ed869910bdd9a;
- all actual producers, native writers, C1 owners, model/fake child modules,
  schemas, nine-edge and symbol registries, protected hashes, docs and guidance.

Preserve V1's role-specific source/C1 relationship, V2's complete status/reason-
reached-facts check, the present-checkpoint revalidation call, and the existing B
internal validators. No field/type layout, role count, profile/domain identity,
recommendation meaning, process frame, currentness policy or custody change is
selected. Use the existing content-free invalid_d2_preadmission_handback error.
A small pure helper inside the final-handback owner is permitted; no generic join
library, new owner or new consumer/import permission is authorized.

This explicit two-file ceiling does not require a mechanical .docs edit for fixing
an already governing invariant. Inspect the existing docs and report a substantive
contradiction if one exists; do not silently override an owner or expand the ceiling.
An indispensable unlisted implementation dependency or unrepresentable required
relation stops the repair with exact evidence and retained work, not a bypass.

### Required source inspection before editing (inside this repair, not another map)

Read both mutable files IN FULL. Read the current checkpoint/role validator,
`_rw0_d2_offline.py`, `_rw0_d2a_offline.py`, `_rw0_d2a_evidence.py`,
`_rw0_d2b_model_input.py` and `_rw0_d2b_proposal.py` at every supplying/consuming
path reached by this join, plus current D2 owner and affected tests/guards.
Follow model input's canonical types into `_post_execution_evidence_values.py`
and its policy/C1/phase/worker source owners. Compare prospective imports/calls to
current explicit permissions before editing; do not smuggle an API through aliases,
type-name comparisons, reflection or runtime table discovery.

Baseline inspection anchors (unchanged supplier, confirm current bytes):
- `_post_execution_evidence_values.py:91-136`: nine fixed roles, typed schemas,
  source postures and direct C1 ranks;
- :1637-1787, :2295ff: lineage fields and input-context identities;
- :2613ff, :2715ff: canonical role supply and complete evidence supply;
- :5214-5329: pure evidence-supply check against independently supplied role/support
  owners (passing it with donor-derived expected values alone repeats the defect);
- :5387-5418, :5821-5854: input-binding/context checks against supplied owners.
These functions are no-I/O semantic checks, not producers or proof of currentness.
Do not invoke a factory merely because it exists if its current consumer role is
not permitted. Reuse available canonical data and permitted pure validation; the
new final join must not call B's side-effecting/currentness-aware builder.

## 2. Fixed baseline, safe opening and complete repaired-V2 subject

Repository: `/Users/ds/Repositories/Governed Execution Coordinator`

```text
branch: trunk_dev
HEAD: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
tree: cc3cc104300f553ada581cee24e80dab6dd885b1
sole parent: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
subject: feat: add RW0-D1 offline process and capsule spine
upstream: origin/trunk_dev, locally same commit, divergence 0/0
one worktree; no active operation/unexplained lock
index: exactly 263 stage-zero HEAD entries, no staged/unmerged change
working candidate: 47 M + 23 C = 70 changed paths
216 other tracked working files HEAD-exact
286 current source endpoints = 263 baseline + 23 additions
current AGENTS SHA-256: ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166
reported unchanged index SHA-256: 7af425d5a47b91b0a14294660f5d449f5ba6308dc8846a8b13aca371c191a587
opaque cache: src/ge_nwp_coordinator/__pycache__, directory plus 37 regular members
migrations/catalog: existing 0001-0004 only; no 0005
```

Authenticate every current payload and baseline relationship. A matching file count
or byte length alone is insufficient. Do not require a clean working tree, an old
69-path overlay or pre-V1/V2 handback bytes. Every C file is present in working files
and absent from baseline HEAD/index. All 70 candidate endpoints are regular
nonsymlink OS 0644/Git 100644. Preserve actual OS modes of all other files, including
`tests/test_c2b3_private_atomic_program_initialization.py` at OS 0600/Git 100644.
No remote contact; local tracking comparison is not fresh GitHub truth.

The baseline archive is corroboration only: 3,134,667 bytes, SHA-256
06d981b6100fc1d6ad9792aff35800eb0772b8d35f708ed030177967ccb9c40e;
its 263 source leaves reconstruct the fixed tree, but it contains no D2 working
candidate. No historical snapshot or mutant delivery is needed: use the exact
local baseline objects and current fixed working payloads below.

Establish this NEW interval. The latest audit's correct opening does not authorize
reuse of its deleted helper. The existing filesystem-only opener follows, with
repair labels. It invokes no Git/repository code and writes only a new owned
external private record/helper. Guidance/index/cache remain immutable. Do not run
it twice to overwrite a drift result. Never reconstruct old index timestamps.

```sh
python3 -I -B -S - <<'PY_OPEN'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env


import datetime
import shutil
import tempfile

guarded_environment()
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_not_exact_audited_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_unavailable')
gate_root = Path(tempfile.mkdtemp(prefix='rw0-d2-a-to-b-repair-v3-'))
os.chmod(gate_root, 0o700)
print('GATE_OWNED_ROOT=' + str(gate_root), flush=True)
record = {
    'schema': 'rw0-d2-a-to-b-repair-v3-opening-observation',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents, 'index_path': str(index),
    'index': index_before, 'cache': cache_before, 'git_executable': git,
    'git_environment': GUARDS,
    'limit': 'This A-to-B binding repair interval only. Only the two named working payloads may change. Index, guidance, cache and protected refs remain unchanged; section 3 qualifies separately observed diagnostic refs. No ref write, staging, commit or remote action is authorized.'
}
READ_HELPER = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\n\nimport subprocess\nimport sys\nopening = json.loads(Path(__file__).with_name('opening.json').read_text(encoding='utf-8'))\n\ndef immutable_checks():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('audit_index_content_or_metadata_drift')\n    if regular_record(REPO / 'AGENTS.md') != opening['guidance']:\n        raise RuntimeError('audit_guidance_content_or_metadata_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n\nimmutable_checks()\nindex_before_read = regular_record(index_path())\nargs = sys.argv[1:]\nif args == ['--check']:\n    print('READ_HELPER_IMMUTABLE_SURFACES_MATCH')\n    print('CURRENT_INDEX_SHA256=' + index_before_read['sha256'])\n    print('Index content and metadata equal this audit opening; no stage or index write is permitted.')\n    raise SystemExit(0)\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree',\n           'check-attr', 'for-each-ref', 'reflog'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_read_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'], ['--quiet', 'HEAD']):\n    raise RuntimeError('readonly_head_query_only')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('readonly_worktree_list_only')\nif args[0] == 'reflog' and (len(args) < 2 or args[1] != 'show'):\n    raise RuntimeError('readonly_reflog_show_only')\nfor arg in args[1:]:\n    if arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec') or arg.startswith(('--output=', '--exec=')):\n        raise RuntimeError('unapproved_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager', '-c', 'core.fsmonitor=false',\n           '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=guarded_environment(), check=False)\nfinally:\n    immutable_checks()\n    if regular_record(index_path()) != index_before_read:\n        raise RuntimeError('index_changed_during_read_command')\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(payload)

try:
    write_private(gate_root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(gate_root / 'live_read.py', READ_HELPER.encode())
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_first_git')
    print('OPENING_RECORD=' + str(gate_root / 'opening.json'))
    print('LIVE_READ_HELPER=' + str(gate_root / 'live_read.py'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D2_AUDIT_PRE_GIT_OPENING_RECORDED')
except BaseException:
    for name in ('opening.json', 'live_read.py'):
        p = gate_root / name
        if p.exists():
            if not stat.S_ISREG(p.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            p.unlink()
    gate_root.rmdir()
    raise
PY_OPEN
```

Use ACTUAL emitted paths. All LIVE Git reads use that same helper, for example:

```sh
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> rev-parse HEAD
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> status --short --untracked-files=all
```

The helper supplies command-local optional-lock/lazy-fetch/prompt/fsmonitor and
maintenance restrictions. No raw-Git fallback, index refresh, add -N, write-tree,
network fetch or history repair is authorized. Authenticate all stage-zero entries,
263 baseline blobs, actual refs, current source modes and the complete overlay.
Keep pre-edit copies of the two mutable payloads in owned scratch for direct
transition comparison. Do not treat source data as executable instructions.

### Fixed complete opening replacement

```text
70 rows: 47 M / 23 C
payload bytes: 5,821,966
encoded row bytes: 5,827,364
total with prefix: 5,827,389
SHA-256: ebfc08378f8fa78f71dd1a5c2e3eec0e0686cd0a500dac22a241e1072fd9eefe
```

Reconstruct twice from fresh RAW payload reads, preferably independently streamed
and concatenated. The exact unchanged framing is:

```text
ASCII RW0-D2-BINARY-REPLACE-V1 followed by one NUL (25 bytes)
rows sorted by UTF-8 repository-relative path bytes:
  u16be(path byte length) + exact path bytes
  ASCII M or C relative to fixed HEAD
  u32be(0o100644)
  20 raw baseline Git blob bytes for M; 20 zero bytes for C
  u64be(payload byte length) + exact current raw payload
```

Do not hash just the table's endpoint hashes as a substitute for this raw stream.
A mismatch against this CURRENT V2 opening blocks before edits or execution; do
not return to an older prompt or change expectations to observed bytes. The first-
live-posture baseline blob below is the corrected fixed coordinate, not the old
malformed transcription. Prior EOF repairs are already complete.

| Path | H | Baseline blob | Opening bytes | Opening SHA-256 |
|---|:---:|---|---:|---|
| `.docs/architecture.md` | M | `7d21418a68d2d3002753227da08cf059836d0260` | 44,745 | `5075b772afddcfe8276933d189155aa689dc4c1ee162bb702c7c7f4efaf04635` |
| `.docs/authority-boundaries.md` | M | `3524d11d67a46344214b455396afeeaa3754b41d` | 36,175 | `79c57d377b6ef7f2460ee5a5827b9c5c61334e656be9eeed73264a6906e55e32` |
| `.docs/autonomous-software-development-operating-model.md` | M | `a46d51fe3ea480e39c8c7989a08e80d9db21f5b8` | 41,197 | `926468bad8cd51c57e3aec6da775c6dced52880215f24d5b03177499a119c6c2` |
| `.docs/b3b2a-read-scope-and-query-contracts.md` | M | `c3237c31fc4b59dcd632b827a4be9907cfcfb998` | 10,013 | `74b1d21b02cd9886a697e1f1cb01dca6977cabb2da194269a35d49745fe548f6` |
| `.docs/b3b2b-select-readers.md` | M | `f1ba74b0a5cd3946a3138de326949d29f789cfac` | 6,477 | `fa7a364ce070b3fcef44907bc884bc783200e1951c618fd7e392d485497c7f07` |
| `.docs/c2b-durable-development-state.md` | M | `04c068d07cd08feaf6c56dafbf3494ccde037ede` | 1,891,411 | `8db2ba24f0685ac21fae2103bb664727a8d9635d3ead5f6bae0d42b35aaf34d2` |
| `.docs/c2b2-private-readers.md` | M | `018b3d905f5db80cf15b546f881dc8c1de3a67b7` | 14,020 | `f765b2dcd74979e235cb04c15dd1fbc81eca149aec017ca500708903bbc105d2` |
| `.docs/c2b2-pure-durable-row-values.md` | M | `1cab6d886f2cd3101987476064a9ce82d2eb4dd2` | 8,540 | `0970595b4c292517d0770542ff8e12a03b98ea93057d4e715d6518415e83aaf3` |
| `.docs/durable-state-model.md` | M | `49694cd86a51f3fb0fb3799e734a52c1a395b8c7` | 42,053 | `7f9cba19f491322dd2fc0f1656ac6b76e698723a6700d1f9919d22b2196e9e80` |
| `.docs/rw0-b1-pure-phase-values.md` | M | `5b7fb0072c6d04898cd212fdc4ff5f63903cf13b` | 35,115 | `7294e7b3aabad5338c4d846e44686ffd075b3e8fe4598495a3e7267103a9ef1e` |
| `.docs/rw0-b2-wire-protocol.md` | M | `5e41d1cb3b2f430d29eb88bdbf2b46570faf3c6b` | 26,084 | `ac1091f043f5fa6042ced1e919c740a08af975b7df1e5e97b66634f85cb68e69` |
| `.docs/rw0-c1-durable-evidence.md` | M | `a7111c4dcf761b60df35c59794bf2e3acd949745` | 15,037 | `f2c6c51d0437aa78b7975bfca3e6fc629fc2898d55c0c696750221000343a02c` |
| `.docs/rw0-c2-first-live-proof-posture.md` | M | `4b69e424655ea67900f6c6042c0cbacaf2d53f8a` | 17,674 | `ba61008234eb5ec85416c459dab0a82b19f7e1a0662dcb15f1289ba445fdf5bd` |
| `.docs/rw0-d1-offline-process-and-capsule-spine.md` | M | `f3557ca523cac0d6fa26647b17a84aef66fecc15` | 5,624 | `b537fbe074717aacdfaefd2cf32cd22c46046034ae115453ddded4e2dc25201b` |
| `.docs/rw0-d2-offline-evidence-and-review.md` | C | `absent` | 8,348 | `f9306ad7333ae08aefd62456041629380c05e984bddc3925258c655a28fa7580` |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | M | `230167a39b115634c8f9b5ae5a0699639f6ff454` | 59,586 | `bee20ed00c7e6f86db3394351f0cbe29626413c635cd9a982416984b288e6fbd` |
| `.docs/worker-execution-boundary.md` | M | `464aef2aa7a561e4adc6792d1d07642d3576f364` | 32,409 | `3cfc1208d96e1f59a81dcd70dce5d43d89f2cb70cc5af6eca453650c33742769` |
| `AGENTS.md` | M | `254854d4a57487d97ce02a73ce2ed26c86ece170` | 64,142 | `ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166` |
| `README.md` | M | `088c832ca7e28d18c82ff6317738ac8ca1c7b5d1` | 47,694 | `f48f2439d282350e36b5d8374864cb5dfe19eb417672737e820500c3a68224f3` |
| `src/ge_nwp_coordinator/_cognitive_proposal_semantic_values.py` | M | `c164616b9e86379c3c6a9210cf4941429a596d4c` | 71,190 | `40243b96765ee0bf49e56a36123e0553f3bb9ab3e0fada38dbe619a2acc1eacd` |
| `src/ge_nwp_coordinator/_development_bound_effect_establishment_contracts.py` | C | `absent` | 43,039 | `fd8fb53c8129001b74df8fa5b15ae69bb45fd970e2aa93f3bc5c20eeeeb1b370` |
| `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | M | `cb37f733141f1e3c3ce874fcc052149de1f82881` | 3,668 | `21e0c9d6c2ece57b87dfb05e961ba1a99a48e72346bbab2c4c1ed571eb5f1f00` |
| `src/ge_nwp_coordinator/_rw0_d1_handback.py` | M | `ecfcf767a5f1c32c0cf007a2c8aa3137ef92374d` | 16,920 | `3cae7fa4423187d53382ba23d9e459a5f0efcb6900a4deed6d4498ed2534ed56` |
| `src/ge_nwp_coordinator/_rw0_d1_offline.py` | M | `4f2a82e46fda9be8123888f5ca46968a4345c25f` | 23,371 | `9546f06f211253d72ea91e0dc2eaf4f0b47fdd54e3d431207f59960fbc742c95` |
| `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | M | `7dc90a0442e348aaac985d711c4d1a97adb7cc05` | 12,175 | `a236bbf599e7d32b4edcc31d23182fd9613c5d290f31a0f1e57961b6a104fe56` |
| `src/ge_nwp_coordinator/_rw0_d2_handback.py` | C | `absent` | 19,106 | `5e3aca1bbd8fbb82a747f1561ed6c2b65029b14c45d607209a9afb262b867388` |
| `src/ge_nwp_coordinator/_rw0_d2_offline.py` | C | `absent` | 6,967 | `d838dd02495cab5cbafa2e6e0b99d6a4e6b4b30e4ac5cb288cb9dd2db02d0d44` |
| `src/ge_nwp_coordinator/_rw0_d2a_evidence.py` | C | `absent` | 53,134 | `e93c2592c8f838bd178ffa8e57f57a9116fcdf567b248e511496d00384968ec9` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_reviewer.py` | C | `absent` | 2,878 | `0d061fdf600039ff69ba0d0dc3f1a0239c2527500461244bb53455bbdd326973` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_validator.py` | C | `absent` | 2,726 | `c1eb49503b4345d25047814e089545f9d1cd4c85f10ae20254b8b6283fa58fbe` |
| `src/ge_nwp_coordinator/_rw0_d2a_handback.py` | C | `absent` | 20,455 | `7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f` |
| `src/ge_nwp_coordinator/_rw0_d2a_offline.py` | C | `absent` | 30,416 | `d81db9535b17c7daae7be449d7e30dbcaaa599749ddc2619dbfa7d40f87db838` |
| `src/ge_nwp_coordinator/_rw0_d2a_process_frames.py` | C | `absent` | 6,397 | `2c969b1ec303674500143bbbd721e4fe5f7ee161e00b4343f71a611a7f075c8d` |
| `src/ge_nwp_coordinator/_rw0_d2a_workspace.py` | C | `absent` | 5,075 | `45086c2b216639d3a35deef972acda526f004608780a8a8b5e30ed51253f0697` |
| `src/ge_nwp_coordinator/_rw0_d2b_fake_review_model.py` | C | `absent` | 3,771 | `492288c84c2491120a56c7056000f8ec3860c7fbce2bcb3c33249e5e1af5d93a` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_frames.py` | C | `absent` | 8,032 | `e4b7cddc6cfd4caa7e34781e1c34c00833d6f83a98477d46ce55e878e97dfcef` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_input.py` | C | `absent` | 81,718 | `e2bbe585f8ae19df5dd6547212cf239ac58411795cbae904cf3ed869910bdd9a` |
| `src/ge_nwp_coordinator/_rw0_d2b_proposal.py` | C | `absent` | 22,718 | `deec7caf82206c40545a308f3a8845fb867e64a211a81e055fb29ffbafc0666a` |
| `src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py` | C | `absent` | 23,762 | `d5012ef7dd383ae39364772d7702364fc0eadde31a1e64997c0a6773d6025245` |
| `src/ge_nwp_coordinator/_sqlite_rw0_c1.py` | M | `635b5dd49256e14103fced6ff8ea4db76649e22c` | 203,409 | `d17490b3ce1b136eeb3d559f01f44e97836827bc137325b306ec01530e06e9e7` |
| `src/ge_nwp_coordinator/sqlite_transition_transaction.py` | M | `f8053db4010faaba41b38b531d93a8b21e80daa8` | 180,600 | `6d662dcb83a2641b9d95dee7209ddbd0d8b991bc720da3aafa5b4b9fb3bc5521` |
| `src/ge_nwp_coordinator/sqlite_writer_session.py` | M | `97162e3a749a7f1f1ae75de90c4b2d9092068107` | 299,804 | `54f9c5a0844421686c1c89cdecf3c2865263b3339d2faec933c615ca2ca3d404` |
| `tests/test_b2a_writer_session_contract.py` | M | `ccadd884de29d606c9243ea7796cc380e29fe5c2` | 29,168 | `835b386274f410f2fc52b1a40b2c936009ac5286fb22bc23cc28efa789be0664` |
| `tests/test_b3b2a_read_scope_and_query_contracts.py` | M | `66cab4655d33c1b864f5fb4c22e853a39c5a8188` | 26,502 | `4cabeed0c37a99c0f937c0b49f25c7c6a049eb9125e64127019c449dcd86313a` |
| `tests/test_b3b2b_select_readers.py` | M | `c0c5a0e091572f30a428fd5a2634c21d25a6ad64` | 118,350 | `22061f6846b0ebc969f9b67bac399b8d8eb237c8df0e2de92d84d477c0f1ce2b` |
| `tests/test_b3c4c_prerequisite_contract.py` | M | `f1ee03232e33da8bbfa5592fe81c53414acb25b1` | 36,340 | `3d25c2ffb8ee86856c154cfc9dd842bab2db87ea2b200cd75758a62f372b5cd8` |
| `tests/test_c2a_nonimplementation.py` | M | `3f343ae5886c92941ebfff63ba4213de2109025e` | 30,650 | `c0db68e10f4588c02bbc38da1b95d6898a3d7896c127038533ce0c8a6715442e` |
| `tests/test_c2b0_durable_state_contract.py` | M | `b910d61aaf670ba40a0d649f933c06767e7360e5` | 887,367 | `995c3690500e3d3009f1fe93b276db506e1d454764dd2e5167df52bf81252c1a` |
| `tests/test_c2b2_development_reader_contracts.py` | M | `122f0d44b46e0a8d7b283d5baec1ce465e2028b6` | 71,365 | `28dbf4fff09d75d7522af35c8fddc8908b7c4c1d18ff8043d19dbf6b90f30970` |
| `tests/test_c2b2_development_row_value_boundaries.py` | M | `d7dea23786bec2ca98bb702bbe93cc31e4192221` | 17,972 | `f2a7089748f39dc8c40a932ac770edd3ffa7f8ea581b053af101dfda8100c830` |
| `tests/test_post_execution_pure_owner_boundaries.py` | M | `437a4e7cbd39682bdd08f03b3a30c0bbbd057614` | 19,302 | `7945be6d5e01c2a1b437cabc57972bbd70a725da9c14f7dd92574ff8f8633014` |
| `tests/test_post_execution_pure_owner_vectors.py` | M | `3eed1c6bc08b6876d1e74d94a4e5509c14786eb0` | 103,682 | `3d526cabcead871b5bba47952b914df76a34b5d85a7b730e55afb951c050de16` |
| `tests/test_runtime_non_authority.py` | M | `79d4ab185815234c9d087c48d2439b9a1d95d95d` | 48,343 | `fef5729d8e7f4c619ddb2731b52d3500bc8e75988a3f422648b9dea743ef01c9` |
| `tests/test_rw0_b1_boundaries.py` | M | `17d1e09c30b01287718c6b5175bac76b03daf458` | 52,838 | `af8d9f7507733876a5978d1a3f5b871a81030380eba929cbffe6959f9d639aaa` |
| `tests/test_rw0_b2_capability_boundaries.py` | M | `4668d2a2c285d2d79bf6ebfb0c9c9f60166bcb27` | 50,538 | `85ee20f37629ffc852154cea67dd5dc983b0f2f74ab2d370192c13d999b397c3` |
| `tests/test_rw0_b2_wire_boundaries.py` | M | `9e04f528326a6f337a4f47e7e9f9eda3c9a82e0a` | 38,513 | `13531d5d46258ca67cc7bf0bddd78c560ce9b7308ff296068a146299f349ba27` |
| `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | M | `0f0159c172e1448d2b96ab19411e1f85467a2931` | 120,405 | `af7f49ac8da64c12e97d03a536ee10b89a11996651b0d712dc04baef427d8cf3` |
| `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | M | `e9d95b54a4b5921be8ec39d2bf3f6216204750c7` | 247,679 | `e8de37791388c28f1b1626747af6c4094622469168ed9799eaa78f7f6f4d3613` |
| `tests/test_rw0_d1_handback_values.py` | M | `982be9b37aa05db0c6d6a3321b775c7c64f2142d` | 30,189 | `e8addc00e8b37aa5e6f24a91a637c9f5053656c58a0d4c06e713618229e448b6` |
| `tests/test_rw0_d1_offline_integration.py` | M | `33c2d85012cbdf0e7e04fdeb7d333d2c8675ae3f` | 53,132 | `c5997a4e9161253974b04b203bf55754c12b465c3b0b5924247e6c1df8e05c9e` |
| `tests/test_rw0_d1_worker_process.py` | M | `e2a83abe44db720b5ce0725682ac71d30372959d` | 1,737 | `512d7d61083e8ad8c61c197aefc86f70d61a1f7e41273fab435bb493cc08631f` |
| `tests/test_rw0_d2_bound_effect_contracts.py` | C | `absent` | 5,636 | `4c8f04a5f16d0e0b236f8fff636e5d9a5d41c465dad6fc726bd488fb76b59574` |
| `tests/test_rw0_d2_bound_effect_persistence.py` | C | `absent` | 6,068 | `839a68b7285480a6ca19885be2df2e398dbedb8e6909f381f5cfe4aa8155da67` |
| `tests/test_rw0_d2_c1_checked_readback.py` | C | `absent` | 17,750 | `20237660028125bacccf52bb695cb275adebefb2ed1f0a28bb271688f7aadb01` |
| `tests/test_rw0_d2_evidence_children.py` | C | `absent` | 3,635 | `fd4cd60a30cb641d34b458f7782bcc27d020a37f47f6523c37cfcf83895d516b` |
| `tests/test_rw0_d2_model_handback.py` | C | `absent` | 4,966 | `89c53206f1b636257ecf5f71027e11ca4ef4cfdd00883e55b2c0fa02fe2a7a6e` |
| `tests/test_rw0_d2_offline_integration.py` | C | `absent` | 41,541 | `486dc60afd7c4a6f6c2982b0d5ad8503722f43e0de449509975952e490b84692` |
| `tests/test_rw0_d2_process_frames.py` | C | `absent` | 6,894 | `f77f49268e4ed693d049560307aa3794538842efc8afa24e1500664fc4884264` |
| `tests/test_rw0_remote_contact_phase_entry_contract.py` | M | `2a9144c3dfd2c883555703c8adecd21f447d6d34` | 177,317 | `6df3c991a219633d148106396336f2702c323b6cddb82932b41152ea3e5ac16a` |
| `tests/test_sqlite_backend_b0_contract.py` | M | `c646df6d439d0b70f45d6d72200fbedb5e730779` | 26,412 | `1eb038201c19be7e9680f5ee6c4425fb50051b8bc0df31e3feeab06620cc094e` |

## 3. Protected refs, correct historical qualification and current observation

The latest independent audit observed 53 refs (28 protected, 25 conditionally
diagnostic), unchanged at opening and closing, serialized snapshot SHA-256
054a2971c49bc1843a84adbd41e72d0ce082be03a538ecb8d64e067fc699a490.
HEAD resolved through refs/heads/trunk_dev; origin/HEAD pointed to origin/main.
These are PRIOR OBSERVATIONS, not fixed current counts or a supplied current map.

Correct this specific attribution in the latest prose: the V2 repair's earlier
54-ref observation (28 protected, 26 diagnostic) ALSO reported zero interval delta,
snapshot SHA-256 06bb83e9c8cd9d28f99dc090433dbb643a08115a4b98dab270b2f472bfe2391f.
The all-ref-preservation failure belonged to the earlier V1 repair, with two removed
refs at object 014f6845ec3672c7a2c2e54f8745e8d2e0505a06 and two added refs at object
1450a5e4845d20d9199004ea862ebdeadb8139e0. Do not attach that failure to the V2 54-ref
interval or infer a writer/cause from these different counts. No new forensic task
or historical ref restoration is needed for the present source defect.

After the opener, before editing/executing: capture all actual ref names/OIDs/
symbolic targets through the helper (for-each-ref with refname, objectname, symref;
symbolic-ref -q HEAD). Store the exact serialization externally with its digest.
Protect EVERY ref by default. Only specific records under:

```text
refs/codex/turn-diffs/captures/
refs/codex/turn-diffs/checkpoints/
```

may be classified non-authoritative diagnostics if current source/config/guidance,
actual source/copy selection and available records establish no program, baseline,
policy, admission, publication, recovery or validation dependency. Inspect relevant
generic ref enumeration/--all use; absence of a literal string alone is not proof.
No protected symbolic target may resolve through a diagnostic ref. This task's
execution source is exact HEAD plus authenticated current payloads, not a captured
tree. All other refs, unknown/out-of-scope refs and any relevant dependency remain
protected. A new symbolic edge or record needs the same bounded classification;
no blanket refs/codex/** exemption.

The prior classification may support this check for unchanged supplying source,
but naming alone does not establish ownership or harmlessness. No provider data,
recursive capture dump, fetch of absent historical objects or attribution campaign.
The responsible writer/cause of the old rotation remains unknown unless available
actual records establish it. Do not "fix" origin/HEAD or any diagnostic reference.

Compare protected refs against THIS opening before final execution and at closing.
Record all qualified diagnostic deltas separately with exact old/new values. Such
a delta is not a source defect or permission to write a ref. Unknown protected
use, source/index/protected-ref drift or an observed competing writer is a stop.
Never reset an expected snapshot on drift or report all refs unchanged when they
were not. All live ref writes remain forbidden. Source/index/guidance/cache and
unrelated files remain protected regardless of diagnostic classification.

## 4. Exact A-to-B consuming invariant

### 4.1 Close the whole selected projection, not just the demonstrated capsule

In THIS repair, derive a compact nine-role source-to-consumer table from the current
B constructor, A checkpoint producer/validators, final handback and supplying pure
owners. For each entry name the actual A field or checked family; B role entry and
canonical supply path; schema/ref/digest/profile/source-binding and support identities;
lineage/fence/phase anchors; and whether a field is retained A evidence or genuinely
B-created historical metadata. Report exact path:line and the comparison selected.
This table is inline/test-local evidence, not a new production schema, public API,
architecture package or separate mapping deliverable.

The fixed existing role order is:

```text
candidate_capsule
worker_result
validation_result
independent_review
standing_policy
risk_lane
authority_currentness_attestation
global_stop
effect_ceiling
```

There are nine roles at the existing ranks/ordinals; support counts are
(0,0,6,7,4,4,0,2,5). Counts are structural requirements, NOT association proof.
The existing A checkpoint holds D1/manifest/adapter/bound proofs/checked admissions,
source observations, dispositions/separation and policy/support evidence. Use the
actual typed fields, not an assumed row number or a caller-provided role name.
Only genuine C1 families have admission posture; neighboring data does not acquire it.

Before comparison, preserve all existing exact outer/nested types, canonical
self-digest validations, role grammar, source postures, checked-family validators,
reason/prefix predicates and checkpoint consumption. Check malformed scalars and
containers before using equality or dependent lookup; Python subclass equality,
assertions disabled by runtime flags, missing/duplicate values, and bool-as-int
must not supply false confidence. No new input-coercion rule is selected.

### 4.2 Identity must be derived independently from retained A owners

Bind B's context, safe input projection, private manifest, roles and supply back to
the independently retained A checkpoint and D1/native/C1 facts. The map must include:

- Original program/version/work/revision, semantic attempt, candidate and WorkSpec
  coordinates represented by the context lineage, capsule and checkpoint. Distinguish
  the original development basis decision from the Section 41 pre-execution selection.
  Compare digests as well as refs; D1 fixture refs may repeat in separate databases.
- The author command, standing grant, author effect, attempt/current author fence,
  delivery and authority coordinates actually used by the existing lineage factory.
  Do not substitute a validate/review fence into author lineage because its type fits.
- phase_basis_ref AND phase_basis_digest, and every explicit current projection/
  private-manifest/context correlation required by the existing pure grammar.
- All A-derived values of each of the nine roles, their actual source/profile bindings,
  and the support values/sets used to construct that exact role. Neither matching
  labels nor values selected FROM THE DONOR B GRAPH can be the independent expectation.

Use direct existing canonical mappings or permitted pure validation/reconstruction
at the consuming boundary. A supplies expectations; B supplies assertions to check.
Passing the existing evidence-supply validator with owners reconstructed solely from
B's own supplied canonical values can verify B internally but does not repair this
missing relation. A new cached hash of arbitrary entire objects is not a substitute
for the explicit existing canonical relations.

### 4.3 Required role associations (derive exact current accessors, no invented fields)

| Role | Existing independent relationship to preserve |
|---|---|
| candidate_capsule | Full canonical manifest identity/value from this checkpoint, tied to retained capture/D1 candidate and lineage; compare digest, not only capsule_manifest_ref or candidate_ref. Preserve existing private capsule projection and canonical byte-length relation. |
| worker_result | The exact retained rank-14 checked classification value, its schema/ref/digest and direct C1 membership ref/digest in this phase; preserve original author-result/adapter operands and profile relation. Not another run's well-formed classification with the same labels. |
| validation_result | This checkpoint's actual validation disposition, validator source/result-set and role-specific bound proof/qualification/support values, under their existing canonical rules. |
| independent_review | This checkpoint's review disposition, reviewer source/result-set, semantic separation, correct review effect/qualification and supports. A validator result or donor review graph is not independent review of this candidate. |
| standing_policy | The exact retained policy matrix/source attestation and supporting values the current builder consumes from A; preserve fixed profile meanings and current selected per-role provenance. |
| risk_lane | The retained risk matrix/source profile/binding and supporting values for the actual work item and candidate relation, not a mere matching lane string. |
| authority_currentness_attestation | The actual author-role rank-1 checked family/source of THIS checkpoint with exact C1 membership identity and canonical value; keep validation/review authority roles distinct and preserve V1. |
| global_stop | The actual retained A-derived inputs and B-time snapshot/support relationships that the producer represents; identify B-time facts separately. Do not replace a fresh B observation with stale A data, or make handback validation reacquire current state. |
| effect_ceiling | The represented source ceiling evidence and its actual attempt/effect/authority/policy/stop inputs, with the existing canonical support relationships to the checkpoint. No transfer of executable permission. |

Some source profile definitions are fixed shared metadata rather than run-specific
values; validate their existing canonical identity, not Python object address or a
new invocation-specific profile. A rank-14/rank-1 locator cannot be copied from B
as if it proved admission into A's checked set. Preserve all required supports,
not only the main role digest. Do not blindly equate tuple positions across types
without confirming their fixed owner grammar.

Global-stop snapshots, B context/supply times and other B-entry-only values must
retain their actual authoring and sampling meanings. Equality with a prior A clock
value is not universally required. Use the retained historical facts and their
source-supported relation to A; pure validation does not prove fresh acquisition
or an unretained observation. If a material selected relation cannot be expressed
by current retained data, name the exact missing fact/owner and stop without adding
a field, weakening the claim, inventing an observation or changing a producer.
Do not use that rule to reopen an unrelated full execution-history design.

### 4.4 Consume whenever B input exists; preserve stopped and partial shapes

The same operative pure join must run on the PRESENT handback in construction,
dataclasses.replace and explicit validate(), whenever input_context/evidence_supply
is present. The existing pair/shape rules remain: a pair cannot be excused by
status='stopped', and early stops with no B pair do not need new complete-A evidence.
A ready path and every genuinely produced complete-A stopped/cleanup path carrying
B input receive the A-to-B check. Do not gate it only on proposal or model_input_binding:
the auditor's stopped case has the paired input without a complete output proposal.

Bind to the validated checkpoint belonging to this final handback, maintaining its
existing equality with final d1_handback, checked_admissions, committed_bound_effects
and checker outcomes. Donor A values must not replace recipient A values to make the
mixed B graph pass. The checkpoint's own validation remains owned there; retain the
existing single final checkpoint revalidation rather than duplicating it inside an
unrelated normalizer merely to count tests.

Once the B input is bound, preserve its existing linkage to actual model process,
source invocation, context/supply identity, private output artifact, safe OUTPUT
projection, evidence bindings/set, proposal and V09 model-input binding. Input-safe
and output-safe projections are not the same type/identity. Normalize/validate only
what is present under the existing V2 prefix matrix; never demand a completed model
output for a genuine pre-output stop. No valid recommendation is rejected just for
being repair/replan/reject/block, and equal recommendations do not excuse bad binding.

### 4.5 No reconstruction of authority and no test-driven overbinding

Rejection is the only selected behavior for a cross-bound graph. Do NOT:
- sort or strip fields, repair the reason, substitute A/B owners, rewrite a proposal,
  choose another candidate, auto-renormalize the donor against the recipient, or
  resample/renew an observation;
- call the offline B input constructor, query SQLite, open a writer/cursor, reacquire
  live currentness, read a workspace/run path, or run any child from handback validation;
- call V22-V34 admitted-family/decision helpers, create rank 15, issue a validation
  token, add a run UUID/session field, or use cached 'already checked' booleans;
- make equality depend on Python `is`, all process IDs being identical, a unique
  fixture name, the sample capsule hashes above, or globally unique fixed refs;
- duplicate all 81 KiB of model input construction/profile code in the handback or
  broaden consumer guards simply to reuse its I/O-bearing builder.

Semantically identical independently reconstructed values must remain valid. A
second invocation is not automatically invalid if ALL relevant canonical evidence
and allowed B metadata relations are identical. The rule excludes mismatched
content/lineage, not foreign Python allocation. A coherent historical handback must
not become invalid merely because wall time advanced; currentness is checked by
the existing producer at B entry, not resampled at historical consumption.

Keep role profiles, schema/field orders/domains, error vocabulary, nine-edge literal,
fixed function consumers, status matrix and no-public/no-persistence boundaries
unchanged. Inspect import/dependency restrictions before adding any reference.

## 5. Permanent regression matrix and bounded causal experiments

### 5.1 Reproduce both opening failures on authenticated pre-edit copies

Use actual D2 invocations for run_alpha and run_beta in one positively owned test
lifecycle. Choose legitimate existing input variations that produce different
candidate/capsule identities and ordinary accept_candidate versus repair_candidate
recommendations without passing an expected answer to the model. Record real normal
handbacks and the exact distinct A identities. Neither is a malformed or test-seeded
persisted family. Keep their run owners separate and close each only through its
own custody path.

Ready probe: retain run_alpha's D1/checkpoint, committed bound proofs, checked
admissions, validator/reviewer outcomes and capture. Substitute run_beta's COMPLETE
internally consistent downstream B input/model/output graph, updating only the B
slots and the model portion of child_outcomes where required by their existing
internal equality. Do not substitute the recipient's A facts. Record the exact
changed fields and both original positive validations. Reproduce accepted
construction and explicit forged-wrapper consumption on opening bytes.

Stopped probe: derive a GENUINE producer stopped result with complete A and its
paired context/supply using a controlled fault at an actual supported B boundary.
Swap the donor pair while preserving the recipient's status/reason, A checkpoint
and all other required facts. Reproduce replacement and independently reached
validate(). Do not fabricate an impossible reason to obtain a rejection; keep the
V2 source-derived matrix. The earlier audit driver tried a nonexistent role-entry
attribute while formatting a result: use actual fields/mappings and preserve any
new driver correction's evidence limit, without repeating that mistake for credit.

During each substitution there is no new child, admission, model output or durable
write. Observe the fixture database(s) and actual child handles before/after those
in-memory phases; source invocations themselves have their normal separate effects.
Do not claim the historical sample hashes/PIDs or deleted audit script bytes are
reproduced by a fresh invocation. Record new identities and exact deltas.

### 5.2 Tests in the existing integration module

Preserve all current 46 nodes and their meanings. Fixed expected A bindings and
roles are test-local, not read from the new production predicate. Shared real-run
fixtures are acceptable; observer logic must not sanitize or gate a forbidden
input/child or manufacture the expected relation.

Minimum finite tests:

1. Normal recipients/donors with their OWN complete graphs pass; all five legitimate
   recommendations and current early/late stopped positives remain supported.
2. The full ready cross-run transplant is rejected by constructor/replacement.
3. Bypass only construction in a test-only forged exact final wrapper and demonstrate
   explicit validate() rejects the same otherwise well-shaped crossed graph.
   Do not call the new helper in the test first and credit that failure to the consumer.
4. A real stopped complete-A paired-input transplant is rejected at both boundaries.
   Include a genuine supported cleanup-unresolved B-input shape if the current
   producer provides it; a stop without B input remains valid. Do not invent a status.
5. Same capsule is NOT sufficient: obtain two actual normal evidence contexts with
   equal canonical capsule but a materially different retained noncapsule role or
   support (for example actual admitted worker/review evidence or a legal policy
   variation). Show the donor B graph remains internally coherent, then reject it
   against the unchanged recipient A. Confirm the difference, not just a second PID.
   If a chosen second invocation is canonically identical, it is a positive, not a
   negative; select an actual differing supported input/evidence source.
6. Exercise the closed nine-role comparison coverage with a bounded test-local
   matrix of valid typed value/source-binding/membership/support mismatches. Keep
   dependent B internal references/digests consistent using current pure constructors
   in EXTERNAL specimens. For a case rejected earlier, credit the earlier predicate;
   do not claim it tested the new join. One specimen may cover multiple documented
   roles. No 9xall-fields Cartesian product or fresh unrelated fuzzing campaign.
7. A canonically identical reconstructed context/supply and normalized evidence graph
   is accepted against the same checkpoint, even if objects were separately allocated.
   Retained B-created time/ref differences remain valid where the existing semantics
   permit them; there is no blanket equality to a freshly rebuilt clock-dependent B.
8. Confirm the mismatches do not trigger validation-side DB reads/writes, new child
   execution, source renewal, mutation of the original run or disposal of the donor.
   Use actual available instrumentation; do not introduce production callbacks to
   make observations. Close every owned run in finally blocks on failed assertions.

Do not manufacture an 'admitted' positive from hand-built expected C1 rows. Direct
forged-exact-wrapper or resealed semantic negatives must be labeled as test objects,
not supported producer execution. Keep all prior R01/J01/J02 controls.

### 5.3 X01/X02: two bounded omissions protecting the new relation

Build each from the final repaired source and leave FINAL TESTS unchanged. Record
complete source manifest, exact mutation, selected complete nodes and signal.

X01 — omit/neutralize ONLY the new A-to-B consuming relation. Preserve V1 authority
roles, V2 reason/facts, checkpoint validation, and all B internal checks. Normal and
legitimate stopped positives pass; ready and stopped crossed-graph negatives lose
rejection, producing their intended failed rejection assertions. This isolates the
new missing edge, not a deletion of validate() or a malformed fixture.

X02 — retain the capsule association but omit the remaining operative noncapsule
A-to-B associations (a precisely identified capsule-only weakening). The normal
positive and capsule-mismatch control retain their expected behavior; the internally
coherent SAME-CAPSULE/noncapsule-mismatch case loses rejection. This demonstrates
that a capsule-only patch cannot satisfy the selected evidence boundary. Keep the
model graph internally valid and identify which real noncapsule relation is tested;
credit only the predicates actually isolated, not every role separately.

The code need not have a named helper or artificial split just to ease a mutant.
Identify actual statements. Copies must parse/import/collect normally with identical
integration node sets and only the stated source delta before/after use. No credit
for import/architecture/hash/collection/format/harness errors. Do not run a full suite
per copy or weaken a legitimate redundant safeguard just to obtain a mutation kill.

### 5.4 Preserve R01/J01/J02, with accurate overlap treatment

The latest independent audit ALREADY ran normal 46/46 and reproduced R01/J01/J02
on V2. These remain prior independent scoped observations, not full A12 or D2
acceptance. After editing the final consumer, rerun these small affected controls:

- R01: remove only reason/reached-facts enforcement; keep the new A-to-B join.
  Its coherent same-run early/late positives and reason-only negatives still test
  the reason relation rather than a donor mismatch.
- J01: remove only checkpoint authority-role join; its direct same-role-alternate
  negative is still evaluated at the checkpoint, not masked by this final join.
- J02: remove only existing final checkpoint revalidation; keep the checkpoint's
  own correctness, reason check and new A-to-B relation intact. Use a genuine
  supported ready/stopped shape for its checkpoint-consumer specimen.

A legitimate new cross-join MAY independently reject an old J02 authority-mismatch
specimen. Do not weaken the new join, falsify expected results or delete multiple
validators to force the old failure. First report that overlap. Use one bounded
existing checkpoint-only inconsistency reaching the final consumer if available
without crossing another earlier predicate. If that layer cannot be independently
isolated under the current graph, preserve the call and report the combined invariant
and test limitation, not an invented individual-layer pass. This is a clarification
of causal evidence credit, not permission to omit checkpoint validation or ignore
a real surviving mismatch. Apply the same rule to any redundant X01/X02 predicate.

The repair writer is not tasked with performing the entire A01-A13 independent
audit. Complete this finite repair and original positive regressions; remaining
native/runtime/model/source-review obligations stay with the later independent gate.

## 6. Final source validation and exact group membership

After the LAST source/test edit, create one fresh normal remote-free copy of the
263-file fixed baseline plus all 70 current candidate payloads. Authenticate all
286 endpoint bytes/types/modes before and after every normal command. No live
cache, secret or product database is copied. Do not hardlink mutable live sources.
Tests that need local Git metadata may use a local-only clone at the supplied
baseline with its remote removed before execution; no fetch/network or captured
ref source selection. Ordinary manifest-checked source copying is also permitted.

Use installed Python 3.13 and pytest; record the exact versions. Set umask 022,
owned TMPDIR, PYTHONDONTWRITEBYTECODE=1, PYTHONPATH=.:src, -B, and
-p no:cacheprovider. No xdist/parallel groups, dependency install, skip/xfail,
warning suppression, or selector changes to manufacture a result. Precreate
separate collection/run basetemp parents for every group.

First complete the whole integration module, X01/X02, and the affected R01/J01/J02 checks,
plus directly coupled architecture/consumer smoke. Then run all six groups below
serially, collection before execution, followed by one FULL collection/execution
with NO path selector. The reported V2 9,081-pass run is implementation evidence,
not a substitute for final-byte validation after this source change.

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-group-collect> --collect-only <exact-group-paths>

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-group-run> <exact-group-paths>
```

The full fixture lifecycle is outside the live checkout. Use lstat for artifact
inventory, hash/open only regular files, follow no fixture symlinks or special
files. Keep actual child handles/PIDs/groups and positively owned roots through
failed tests. Emergency rescue must be separated from runtime cleanup credit;
never kill by name, signal unknown processes or sweep generic /tmp.

### Exact selections

#### A0_D1

```text
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_offline_integration.py
tests/test_rw0_d1_planner_process.py
tests/test_rw0_d1_process_frames.py
tests/test_rw0_d1_process_supervisor.py
tests/test_rw0_d1_worker_process.py
tests/test_rw0_d1_workspace_capsule.py
```

#### BINDING_COMPAT

```text
tests/test_c2b3c_author_effect_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_c2b3d_author_effect_establishment_recovery.py
tests/test_c2b3d_private_atomic_author_effect_establishment.py
tests/test_c2b3d_private_author_effect_delegation.py
tests/test_worker_execution_semantic_relations.py
tests/test_worker_execution_semantic_vectors.py
```

#### A_NATIVE

```text
tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_private_readers.py
tests/test_rw0_c1_reader_contracts.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_row_values.py
tests/test_rw0_c1_semantic_values.py
tests/test_rw0_c1_writer_session_delegation.py
tests/test_rw0_d2_bound_effect_contracts.py
tests/test_rw0_d2_bound_effect_persistence.py
tests/test_rw0_d2_c1_checked_readback.py
```

#### A_EVIDENCE

```text
tests/test_post_execution_pure_owner_relations.py
tests/test_post_execution_pure_owner_values.py
tests/test_rw0_d2_c1_checked_readback.py
tests/test_rw0_d2_evidence_children.py
tests/test_rw0_d2_process_frames.py
```

#### B_MODEL

```text
tests/test_rw0_d2_model_handback.py
tests/test_rw0_d2_offline_integration.py
tests/test_section41_cognitive_proposal_row_values.py
tests/test_section41_cognitive_proposal_semantic_values.py
tests/test_section41_pre_execution_plan_disposition_contracts.py
tests/test_section41_pre_execution_plan_disposition_recovery.py
tests/test_section41_private_atomic_pre_execution_plan_disposition.py
tests/test_section41_private_pre_execution_plan_disposition_delegation.py
```

#### GUARDS

```text
tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_b2a_writer_session_contract.py
tests/test_b3a_persistence_contracts.py
tests/test_b3b2a_read_scope_and_query_contracts.py
tests/test_b3b2b_select_readers.py
tests/test_b3c4c_prerequisite_contract.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b2_development_reader_contracts.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_post_execution_pure_owner_boundaries.py
tests/test_post_execution_pure_owner_vectors.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_c2_private_value_versioning_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_sqlite_b1_runtime_boundary.py
tests/test_sqlite_b2c_writer_session.py
tests/test_sqlite_backend_b0_contract.py
```

FULL: no test-path argument for collection or execution. The existing repository
has 131 test modules; no new module is authorized. The following are FIXED OPENING
module identities and reported prior node identities/counts, not future target
counts. Measure and authenticate actual opening membership before source changes.

| Group | Modules | Prior nodes/passed | Fixed opening MODULE SHA-256 | Reported opening NODE SHA-256 |
|---|---:|---:|---|---|
| A0_D1 | 7 | 117 | `bd79dcd6261a545b90e3709e7bff2b16fa00d9fb71f67baa4082f71de6b75236` | `8ba8dc88ab588e3e12d56d8c3db542b08f04ddb1d1714a4e687e62697ab849ad` |
| BINDING_COMPAT | 7 | 160 | `0851123786b9bcbab0f2f417539ec3d1a0e6ffc753c4075e3d33b15e27dccd30` | `fddc0c493b032ecac479c59e6480a1f58c52759b8133f829795f6a82d8856806` |
| A_NATIVE | 11 | 118 | `07f8d2d3b7f971ab76b23f537de7985ed9e5388c5f5f69dc6d5d3b9d995fc22d` | `d5911062ec95a45b37662d236c0fb9af7374ccaee193da0a423f1f0019c3dfdd` |
| A_EVIDENCE | 5 | 659 | `d74195c30fd2f5c9e56591b2365651836ec7c982d0c1fe96da3f1fc26850b1ba` | `8c27f90a27da2fe62242f3bf3c368b2ce5792e102354c685bc8d99e1e19c35f2` |
| B_MODEL | 8 | 215 | `a9502f1aa3c71c448fe037284d01b19f3d27389158fa9bbdb5be357c082baba1` | `dad51c53f7fa4dd6ac05db5b5303161b3083a519352d56a43a42260e1c51f967` |
| GUARDS | 24 | 4,162 | `4533bd1c1f6ee61c1e96847b3d6ce684af46046304ae9a6df28348eaace2b617` | `547c990efa2ac226f2316e0d3c276b6709afa0c4deb20493a1e3db2230b9260b` |
| FULL | 131 | 9,081 | `eefc35b538cdd2924d51e0d28304fc27367fc532ed7e30895122009f2f189d74` | `f123678369adb994586f1d92be175146782296266e61cfa732854e52e2fe58bf` |

The latest independent re-audit collected 46 integration nodes; complete-node
SHA-256 `0c0d5f328816519628415d614df883c877b422bc42530785b20ffce3ba2b6474`.
Its unmodified integration module passed 46/46 with zero reported warnings. It
reproduced R01/J01/J02 but did NOT run the six independent groups or FULL after
the new material finding. Do not relabel the writer's 9,081 passes as an independent
full result or this repair's execution.

Only B_MODEL contains the permitted amended test. A0_D1, BINDING_COMPAT, A_NATIVE,
A_EVIDENCE and GUARDS keep their exact module inventories. Recompute B_MODEL and
FULL inventories after the test changes; do not overwrite an expected old value
with an observation and call that authentication. All six still execute because
a production validator changes. Report the actual new counts, with this check:

```text
final full count = 9,081 + (final B_MODEL count - 215)
```

This is bookkeeping, not permission to remove cases. Opening group occurrences
were 5,431; unique union 5,429; only overlap two checked-C1 nodes in A_NATIVE and
A_EVIDENCE; full 9,081 contained the union and 3,652 others. Derive final overlaps
and full inclusion from complete node IDs, preserving spaces in parameter strings.

Inventory grammars, no prefix:
- MODULE: unique paths sorted by UTF-8 bytes, each u32be(path byte length) + path
  bytes + raw 32-byte SHA-256(module payload).
- NODE: deduplicated COMPLETE node IDs sorted by UTF-8 bytes, each u32be(ID byte
  length) + exact ID bytes. Do not split parameter strings on whitespace.

Only the three established Python 3.13 multithreaded-fork DeprecationWarnings in
unchanged tests/test_sqlite_b2c_writer_session.py are expected (normally GUARDS
and FULL):

```text
test_operation_guard_close_waits_and_retains_authority_until_exit
test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Inspect category, message, node and location; a count of three is not by itself
proof the expected warnings occurred. Record actual completion/exit status, not
progress marks. Driver mistakes may be corrected externally and affected gates
rerun with the distinction retained. No source edit after final validation without
reidentification and affected reruns. A new protected guard conflict is not
permission to refresh its hash or change its import set.

Before the expensive full run, complete tracked diff --check plus ALL 23 C-path
no-index whitespace checks; distinguish ordinary no-index difference status from
whitespace diagnostics. Check UTF-8, no BOM/CR/trailing spaces, selected final-LF
form, regular-file/modes and source/module/executable inventories. Preserve SQL,
catalog, public interfaces and every protected source exactly. Do not reapply
historical EOF fixes or regress fixed B2a/B3c4c/C10 successors.


## 7. Source/copy provenance, retained work, closing and operative report

Maintain full manifests for each normal and controlled external copy: all 286
relative paths, actual regular-file type, OS/Git modes, raw length and SHA-256
BEFORE and AFTER execution. Do not hardlink mutable live source. Record each exact
controlled delta, selected complete node IDs, positive/negative/failure signals
and actual effects. For this repair use this disclosed RAW full-copy framing:

```text
ASCII RW0-D2-A-TO-B-BINDING-REPAIR-V3 followed by NUL
all source endpoints sorted by UTF-8 relative-path bytes:
  u32be(path length) + path bytes + u32be(Git mode)
  + u64be(payload length) + exact raw payload
```

OS modes are separately recorded. This framing is NOT the historical audit's or
V2 repair's full-copy framing. The latest report's normal/R01/J01/J02 source-copy
hashes have their original interpretation; do not claim to recreate them under
this new framing or execute deleted audit scripts. No lost historical artifact
or extra user transport round is required. Identity proves bytes, not authority.

At closing, re-read all 263 baseline relationships and 70 candidate endpoints;
reconstruct the full final raw replacement TWICE using section 2's unchanged
HEAD-relative framing. Report 47 M/23 C, no staged/unmerged/new path or live
artifact, the two allowed opening-to-final transitions, and byte-identical 68
protected candidate plus 216 other tracked endpoints. Both repair files stay C.
The V1 checkpoint, V2 model input, all owner/docs/SQL/public/guard expectations stay
exact. No final edit after validation without reidentification and affected reruns.

Preserve this interval's HEAD/tree/parent/branch/upstream/worktree, index content
AND metadata, current guidance, cache directory/member records and protected refs.
Use section 3 for explicitly classified diagnostic records, report actual old/new
deltas, and do not turn a prior 53/54 count into a fixed expected inventory. Do not
reset/recreate/remove refs or change the original opening record. Correct naming
of the old V1 all-ref limit does not prove its cause or erase it.

Every real or intentionally unreported child remains accounted for by an actual
handle/group record. Keep run_alpha/run_beta and all owned workspaces separate.
On rejection, validation itself must not close/erase either owner. On final test
cleanup, explicitly close every owned run and reap its children; no destructor-
only claim, unknown PID signaling, process-name kill or broad filesystem sweep.
Classify artifacts with lstat, hash regular files only, follow no symlinks or
special files. A complete per-child ledger was missing from the latest broad
audit; do not inherit a blanket cleanup claim from that report. Prove the bounded
children/roots you actually create here and label any emergency rescue separately.

Remove only positively owned external copies/fixtures/helper root after final
checks; verify absence without further raw live Git. No retained audit ZIP,
repository report, database, generated service, snapshot or new evidence-transport
prerequisite is requested. Return operative details INLINE. Do not claim removed
records still exist.

On a concrete unlisted dependency, wrong opening or material problem, preserve the
explained partial repair rather than reverting D2 to an obsolete candidate. Do not
quietly bypass a guard or enlarge this two-file ceiling. A test count or digest
cannot close acceptance. The latest independent interval established exact V2
subject/preservation, selected role/reason protections and a NEW failed A10/A12
cross-run specimen, not a complete audit.

Required closeout:
1. Supported verdict and visible settings; actual correct opening, exact subject,
   ref classification/qualification and protected closing preservation.
2. Compact nine-role A-source -> B-role/supply/support/lineage map with actual
   owner/producer/consumer path:line; retained A facts versus B-only metadata,
   applicable stopped shapes and represented-data limitations. No new schema.
3. Opening ready and stopped cross-run reproduction on pre-edit bytes with exact
   substituted fields, actual normal positives, source/candidate differences and
   in-memory DB/process non-effects; external-driver corrections labeled.
4. Pure final repair; every present-pair consuming path; independent constructor
   and forged-wrapper tests; same-capsule/noncapsule mismatch, equivalent-object
   positive, existing negative recommendation/stop/cleanup preservation.
5. X01/X02 and retained R01/J01/J02: exact mutations, whole-copy and endpoint
   identities, complete collections, selected node IDs and actual causal signals.
   Masked/redundant checks described accurately rather than inflated into passes.
6. Two allowed endpoints' opening/final size/SHA/mode and reason; all 70 closing
   receipts OR unambiguous inherited-table confirmation plus both replacements;
   full raw replacement length/hash twice and protected-payload equality.
7. All six final focused and FULL selectors, collection/execution results,
   module/node inventories, overlaps/inclusion, structured warnings, failed or
   interrupted trials, skipped checks and source-copy equality.
8. Actual per-child/run/root cleanup, no unauthorized actions, and exact repaired
   continuation subject. State independent A01-A13/source review/final validation
   remain a later gate; neither the writer nor its model output grants acceptance.

Success token:
`RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_REPAIRED_V3_VALIDATED_READY_FOR_REAUDIT`

Requires the pure binding repair, valid positives and genuine relation negatives,
causal evidence at its stated scope, all final validation and preservation/cleanup.
It enables consideration of a separately issued INDEPENDENT RE-AUDIT only.
No staging, commit, PR/publication, Section 41 post-execution persistence, rank 15,
physical C2, migration, live provider/supplier/grant, ES/Bridge, deployment or RW0-E.

Other dispositions:
- `RW0_D2_REPAIR_PROVENANCE_BLOCKED`: fixed subject/opening/protected preservation
  or safe ref classification not established; report expected/actual and retain work.
- `RW0_D2_A_TO_B_BINDING_REPAIR_REPLAN_REQUIRED`: exact unlisted dependency or
  genuinely unrepresentable selected relation prevents this repair; name it precisely.
- `RW0_D2_A_TO_B_BINDING_REPAIR_VALIDATION_BLOCKED`: repair/tests/causal/final
  execution/cleanup remain incomplete; list actual failures and omissions.

The repair writer does not return ACCEPTED or launch the next auditor. Complete
this one repair in the current engagement, with no routine user handoff inside it.
