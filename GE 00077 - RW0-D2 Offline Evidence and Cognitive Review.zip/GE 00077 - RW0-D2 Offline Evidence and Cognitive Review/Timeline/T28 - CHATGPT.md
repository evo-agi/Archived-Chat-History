## Disposition

**Accept the audit block. Repair the final handback’s status/reason-to-reached-facts validation in two files. Preserve the authority-role repair and the rest of D2. Do not stage, commit, or publish.**

This is a new material evidence-integrity defect—not a recurrence of the authority-source mismatch and not another provenance failure. The auditor produced a genuine late failure, changed only its explanation, and showed that the validator accepted an impossible account of where execution stopped.

The observed scope remains bounded: **the normal producer returned the appropriate late-failure reason**. The defect is that subsequent construction and validation accepted the false `d1_stopped` replacement. The probe established neither an extra durable write nor executable authority.

The existing A12 requirement already calls for a reason/evidence matrix derived from actual producer sites. This repair implements that requirement; it does not introduce another lifecycle contract. Coordinator_RW0_D2_Repaired_V1\_…

## Repair the relationship—not just the demonstrated string

The malformed handback contains two contradictory statements:

```text
reason = d1_stopped
```

```text
D1 was capsule_ready;
two D2 bound effects committed;
14 C1 families were admitted;
A completed;
the review-model process ran.
```

Checking that `d1_stopped` is a well-formed string cannot reconcile those facts.

**The selected repair covers the existing final reason-to-evidence relationship, rather than adding a one-off blacklist for `d1_stopped`.** Codex must derive the finite supported combinations from the current final-handback producer, its A/B return and exception paths, and the owning document. That derivation belongs inside this implementation repair—not in another standalone mapping pass.

### `d1_stopped` requires both conditions

First, the retained D1 result must belong to the actual non-continuing D1 branch supported by the outer producer. It cannot be `capsule_ready`.

Second, the final handback must not retain D2 work that could only follow successful D1 continuation: bound-effect proofs, D2 admissions or child outcomes, an A checkpoint, or B model/proposal material.

**Neither condition substitutes for the other.** A ready D1 followed by no D2 work is still not a D1 stop. Conversely, changing the nested D1 label cannot make later D2 evidence compatible with an early-stop explanation.

This must not erase legitimate **D1-owned** history. A real D1 stop may retain its own program, author, selection, process, capture, or cleanup evidence. The restriction concerns impossible later D2 facts, not a demand that every stopped invocation contain no evidence.

### Preserve the genuine late failure

The original `model_input_or_normalization_failed` handback must remain valid with the evidence actually produced before the failure—including the complete A checkpoint and model-process outcome in this case.

A reason can legitimately cover more than one evidence prefix. **“Model-input or normalization failure” must not be interpreted as “the model never ran.”** The repair must preserve that ambiguity where the existing producers support it.

The same treatment applies to the other current reason families: partial native/C1 progress, checking failures, cancellation, timeout, cleanup uncertainty, and valid negative model recommendations must retain their existing meanings. No new stage field, execution ledger, timestamp, schema, cached validation flag, or authority token is selected.

This remains pure consistency validation. It rejects explanations contradicted by retained facts; it does not independently observe an unretained execution history.

## Exact two-file ceiling

Only these files may change:

```text
src/ge_nwp_coordinator/_rw0_d2_handback.py
tests/test_rw0_d2_offline_integration.py
```

The final handback module owns the status/reason relation. Its constructor and explicit consuming validator must enforce that relation on the object’s **present** contents.

The integration tests provide actual producer positives, reason-only substitutions, independently reached consumer tests, and bounded omission controls.

The other **68 candidate payloads** and **216 noncandidate tracked payloads** remain unchanged. In particular, preserve the repaired checkpoint:

```text
src/ge_nwp_coordinator/_rw0_d2a_handback.py

20,455 bytes
7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f
```

No producer, writer, controller, profile, migration, document, import permission, or field layout needs to change for the reported defect. The previous broader implementation ceiling does not remain an open authorization during this repair.

## Required tests

The repair must first reproduce the reported opening defect through a real late model failure. It must observe the actual response decode and subsequent failure, rather than start with a fabricated stopped handback.

The permanent tests then establish three complementary properties:

| Boundary | Required result |
|---|---|
| Legitimate outcomes | Normal readiness, genuine D1 stops, supported partial failures, and the genuine late normalization failure remain accepted. |
| Construction | Changing only the late failure’s reason to `d1_stopped` is rejected by replacement/construction. |
| Current consumption | A test-only forged exact wrapper reaches `validate()` directly and is rejected, without crediting an earlier constructor failure. |

The test matrix should also cover reason-only moves between materially different existing prefixes. Its expectations must be fixed independently of the production predicate under test. This is a finite check of the existing reason families, not a Cartesian product or new fuzzing program.

The in-memory substitutions must create no additional admission, child, or cleanup effect. The legitimate run owner stays separate and is closed through its own ownership path.

### Protect the new check causally

The handoff requires one targeted omission control, **R01**: remove or neutralize the newly operative reason-to-reached-facts check while preserving the authority-role, checkpoint, and nested-value validators.

The valid early and late positives should remain valid. The false-reason negative must then lose rejection, making its unchanged permanent test fail for that reason—not because the copy fails to import or trips an unrelated source guard.

Constructor and consumer coverage must remain distinguishable. A stronger preceding check that masks an omission receives credit only for the invariant it actually demonstrates. That evidence discipline is already part of the audit mandate. Coordinator_RW0_D2_Repaired_V1\_…

## Preserve the verified V1 work

The latest auditor independently reproduced J01 and J02 and passed the normal **19-test integration module**. That supplies useful confirmation of the previous authority-role repair.

**Do not reopen that repair or describe it as untested.** However, this change touches the final validator and its integration tests, so the small J01/J02 controls must be rerun on the repaired bytes.

The complete-A stopped specimen used by J02 must remain a genuinely supported stopped result under the new reason matrix. Otherwise the new reason check could reject first and mask the checkpoint-consumption defect.

Those focused checks do not complete A12 as a whole, much less A01–A13. The latest audit expressly left the wider source review, durable-family proofs, process/model campaigns, and independent final suite incomplete.

## The ref issue is not the current blocker

The latest audit reports that all **53 observed refs** remained unchanged, with 28 protected and 25 classified diagnostic records. It also verified that the selected source and validation copies did not depend on the diagnostic refs.

**No ref restoration, provenance restart, or investigation into the earlier rotation’s author is needed to fix this source defect.**

The repair prompt carries the narrower preservation procedure forward explicitly. It records a fresh complete ref inventory, protects every ref by default, and permits diagnostic treatment only for the two previously selected subtrees when their non-authoritative use remains established. It does not exempt `refs/codex/**` generally or authorize any ref write. The prior all-ref failure remains qualified history. Coordinator_RW0_D2_Repaired_V1\_…

The reported 53-ref snapshot is prior evidence, not a fixed count that the next task should manufacture.

## Validation after the repair

Only the integration-test module is permitted to change among tests. Therefore the module inventories for `A0_D1`, `BINDING_COMPAT`, `A_NATIVE`, `A_EVIDENCE`, and `GUARDS` remain fixed. `B_MODEL` and the full inventory must be recomputed.

After the last edit, Codex must execute all six focused groups and the complete repository suite from a fresh, authenticated external copy. The count reconciliation is:

```text
final full count = 9,054 + (final B_MODEL count − 188)
```

That is accounting, not a target to achieve by removing tests.

The previous **9,054-pass result remains implementation validation**. The latest independent audit ran the integration module and omission controls, not the independent six-group/full-suite gate. The repair writer must not promote either result into independent acceptance.

## Complete repair handoff

**Send this once to the original implementation/repair conversation, “00077 54,” not the independent auditor. Leave the other repository conversations idle.**

:chatgpt-content-reference{index="3"}[Download the complete D2 stop-reason and reached-facts repair prompt](sandbox:/mnt/data/Coordinator_RW0_D2_Stop_Reason_Reached_Facts_Audit_Repair_V2_Prompt.txt)

```text
Filename:
Coordinator_RW0_D2_Stop_Reason_Reached_Facts_Audit_Repair_V2_Prompt.txt

Bytes:
68,044

SHA-256:
637414e45f940d74d7bd8e0872a41580a5c125c3766499aa2b47546820e04aa4

Lines:
989

Final newline:
present
```

It binds the unchanged opening subject:

```text
HEAD:
43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18

Baseline tree:
cc3cc104300f553ada581cee24e80dab6dd885b1

Candidate:
47 modified tracked paths + 23 creations = 70 changed paths

Replacement stream:
5,799,621 bytes
f7b8580df9a59f1270858ddf316f5bab2fafec5079a77c4e41d7bda6a4abc05e
```

The prompt includes all 70 receipts, the two-file ceiling, existing opener, qualified ref treatment, source-derived reason-matrix requirements, direct and causal tests, exact validation selections, and preservation rules.

Success is:

```text
RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_REPAIRED_V2_VALIDATED_READY_FOR_REAUDIT
```

That supports a separately issued independent re-audit. It authorizes **no acceptance, staging, publication, Section 41 post-execution persistence, rank-15 admission, physical C2, new migration, live provider/supplier work, ES/Bridge integration, deployment, or RW0-E**.

## Evidence boundary

I reviewed the latest report and operative mandate, inspected the baseline D1 status/reason implementation as inert source, corroborated all 47 baseline blob identities and 23 baseline absences, and checked the replacement arithmetic and six focused/full module inventories using the supplied candidate hashes.

I reopened the generated prompt and syntax-checked its embedded opener/helper without executing them. **I did not inspect the live repaired D2 source, reproduce the new counterexample, or run repository tests.** The latest defect and successful preservation interval remain attributed to the independent auditor.

Some older uploads are unavailable. Re-upload a specific historical original when a later comparison requires its bytes; the materials needed for this repair handoff were available.

**Sources:** Your latest independent audit closeout; the repaired-V1 re-audit mandate cited above; the Coordinator baseline’s `_rw0_d1_handback.py:32–82,159–239` for the existing reason/prefix distinction.

**Confidence:** High on the two-file repair boundary and preserving the verified V1 work. The complete reason-matrix implementation, final validation, and independent D2 acceptance remain unresolved.
