## Disposition

**Accept the audit block. Repair the final handback’s A-to-B evidence binding in two files. Preserve the authority-role and stop-reason repairs, and leave the rest of D2 unchanged. Do not stage, commit, or publish.**

This is a material composition defect: the validator accepts a model graph that is internally consistent **but belongs to different candidate evidence**. The auditor demonstrated both ready-handback replacement and a stopped-handback input substitution.

The scope remains precise. The probe changed evidence in memory; it did not show that the ordinary producer naturally misattributes recommendations, performs another durable write, or grants execution permission.

**No new architecture or contract tranche is needed.** The existing mandate already requires the nine-role model input to be grounded in its source evidence and rejects cross-bound responses. The missing consuming relationship must now enforce that requirement. Coordinator_RW0_D2_Repaired_V2\_… Coordinator_RW0_D2_Repaired_V2\_…

## Close the connection between the two validated graphs

The current checks establish something like:

```text
A checkpoint is internally valid.

B input, model result and proposal are internally valid.
```

They do not establish:

```text
This B input and proposal are about this A checkpoint.
```

That explains why replacing the **entire** B graph succeeds where replacing one isolated field might fail: all the donor graph’s internal relationships remain consistent.

**The repair must cover the complete selected A-to-B projection—not just compare the two capsule digests from this specimen.** Otherwise a donor with the same capsule but different validation, review, authority, or policy evidence could preserve the same missing relationship.

### Bind each role to its independent source

The final consumer must derive expectations from the retained A checkpoint and its D1, bound-effect, and checked-C1 values—not from the B graph being checked.

| Model-input role | Required association |
|---|---|
| `candidate_capsule` | This checkpoint’s canonical manifest, candidate and lineage, including its digest—not merely a reused reference name. |
| `worker_result` | This checkpoint’s exact rank-14 classification value and checked membership. |
| `validation_result` | Its actual validation disposition, source, result set, qualification and supports. |
| `independent_review` | Its actual review disposition, reviewer evidence, separation and supports. |
| `standing_policy`, `risk_lane` | The retained policy/risk values and source bindings consumed by the existing B constructor. |
| `authority_currentness_attestation` | This checkpoint’s author-role rank-1 value and exact checked membership, preserving V1’s role distinction. |
| `global_stop`, `effect_ceiling` | Their represented source and support relationships, with B-entry observations distinguished from earlier A evidence. |

The role list, source postures and support counts already exist. Counts alone are not association proof. The original implementation mandate required each support to be bound to the actual lineage and observation. Coordinator_RW0_D2_Implementati…

The baseline pure supply validator also accepts independently supplied role and support owners. Passing it owners reconstructed solely from the donor’s own B supply would verify B internally and **repeat the present defect**. See `_post_execution_evidence_values.py:5214–5329`.

### Preserve B-entry semantics

This must remain a **pure historical-consistency check**.

The consumer must not call the offline model-input builder again, reopen SQLite, resample time, renew authority, or reconstruct a fresh B input and compare against that. B-entry stop/head observations and context timestamps have their own production boundaries; they are not universally equal to earlier A values.

Similarly, do not add a run UUID or require Python object identity. The existing fixture references can repeat across disposable databases. What matters is the canonical content, lineage, membership and support relationship.

A separately reconstructed but semantically identical graph must remain valid. The check rejects mismatched evidence—not a different Python allocation.

## Apply the relation whenever B input is present

**The join cannot be conditional on `preadmission_ready`, a completed proposal, or `model_input_binding`.** The stopped probe already demonstrates why: paired B context and supply can exist before the final model-output graph is complete.

The same relation must be enforced by construction, `dataclasses.replace`, and explicit `validate()` whenever the existing handback shape retains B input.

This preserves both sides:

```text
Early stop without B input
    remains valid under the existing V2 reason matrix.

Stopped result with B input
    must bind that input to its retained A checkpoint.
```

No new status, field, stage ledger, receipt, schema or permission is selected. The final validator should reject a mismatch—not strip fields, substitute the donor’s checkpoint, rewrite the recommendation, or silently normalize the donor graph against the recipient.

## Exact two-file ceiling

Only these files may change:

```text
src/ge_nwp_coordinator/_rw0_d2_handback.py
tests/test_rw0_d2_offline_integration.py
```

The final handback owns the pure consuming relation. The integration module supplies actual crossed-run tests and causal controls.

The other **68 candidate payloads** and **216 noncandidate tracked payloads** remain fixed. In particular, the repaired checkpoint and B constructor are read-only dependencies:

```text
_rw0_d2a_handback.py:
20,455 bytes
7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f

_rw0_d2b_model_input.py:
81,718 bytes
e2bbe585f8ae19df5dd6547212cf239ac58411795cbae904cf3ed869910bdd9a
```

Codex must derive the exact source-to-consumer mapping while reading the current producers and validators **inside this repair**, not return another mapping-only result. An indispensable unlisted dependency or genuinely unrepresentable required relation must be reported precisely; it does not authorize a new field or weakened claim.

## Tests must distinguish full binding from a capsule-only patch

The permanent tests should reproduce the opening defect with two actual D2 invocations, keeping their owners separate. To avoid confusing invocation names with D2 phases, the handoff calls them `run_alpha` and `run_beta`.

The required cases are:

| Case | Required result |
|---|---|
| Each invocation’s own ready graph | Accepted. |
| Recipient A evidence plus donor’s complete B graph | Rejected at construction and independently reached explicit consumption. |
| Genuine stopped recipient plus donor context/supply pair | Rejected without relying on an impossible stopped reason. |
| Same capsule, materially different noncapsule evidence | Rejected when the otherwise coherent donor B graph is attached to the recipient A checkpoint. |
| Canonically identical reconstructed evidence | Accepted without object-identity requirements. |

The existing nine-role relationships also need bounded mismatch coverage. Earlier rejection by a type, digest, or internal-B check must be credited to that actual layer—not reported as proof that the new A-to-B comparison ran.

Two external omission controls make the distinction explicit:

**X01** removes only the new A-to-B relation. Legitimate positives should remain valid, while crossed ready and stopped negatives lose rejection.

**X02** retains capsule association but removes the remaining noncapsule associations. The capsule-mismatch check should still work, while the same-capsule/different-evidence negative loses rejection.

These are two bounded controls of the reported composition weakness, not a new fuzzing program or a full-suite-per-mutant requirement.

During substitutions, neither database nor child execution should change. Both real run owners must remain separately usable until their own cleanup. Test observers must not sanitize the malformed graph or become an additional production gate.

## Preserve R01/J01/J02—and report overlapping protection honestly

The latest independent audit passed the normal **46-test integration module** and reproduced the selected R01/J01/J02 omissions. That is useful independent evidence for the earlier fixes. It does not close the new A-to-B relation or the wider audit.

Because this repair touches the final consumer, those small controls must be rerun on the amended bytes. There is one important qualification: **the new A-to-B join may independently reject an old J02 authority-mismatch specimen.**

Do not weaken the new join to recover an expected mutant failure. Instead, report that overlap and use an existing checkpoint-only inconsistency that reaches the relevant consumer when one can be isolated. A masked deletion proves the combined invariant, not independent enforcement of every redundant layer. That is already the mandate’s causal-evidence rule. Coordinator_RW0_D2_Repaired_V1\_…

The repair does not authorize a blanket rerun or redesign of A01–A13 by the implementation writer. The broader source, durable-state, process and model audit remains a later independent gate.

## Preservation succeeded; correct one historical attribution

There is no current provenance blocker to repair. The latest audit authenticated V2, preserved its source/index/cache, and observed **zero ref changes within its 53-ref interval**.

Its phrase associating the earlier **54-ref snapshot** with “its all-ref preservation failure” conflates two intervals. The V2 repair’s 54-ref observation reported zero interval delta. The all-ref failure belonged to the earlier **V1 repair**. The operative mandate explicitly separates them. Coordinator_RW0_D2_Repaired_V2\_…

This requires a reporting correction, not ref restoration, another provenance investigation, or another snapshot. The new repair retains the same conditional diagnostic-ref treatment and establishes its own opening.

The audit’s missing complete per-child handle ledger likewise remains a limitation of that audit. The repair must account for the children and roots it actually creates; it must not inherit a blanket cleanup claim from completed test processes alone.

## Validation and fixed subject

Only the integration-test module may change among tests. Therefore the module inventories for `A0_D1`, `BINDING_COMPAT`, `A_NATIVE`, `A_EVIDENCE`, and `GUARDS` remain fixed. `B_MODEL` and FULL must be recomputed.

After the last edit, Codex must run all six focused collections/executions and the complete repository suite from a fresh external copy:

```text
final full count = 9,081 + (final B_MODEL count − 215)
```

That is accounting—not permission to remove tests to preserve an expected count. The writer’s prior 9,081 passes and the auditor’s 46 focused passes do not substitute for final-byte validation after this source change.

The unchanged opening remains:

```text
HEAD:
43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18

Baseline tree:
cc3cc104300f553ada581cee24e80dab6dd885b1

Candidate:
47 modified tracked paths + 23 creations
70 changed paths; 286 source endpoints

Raw replacement:
5,827,389 bytes
ebfc08378f8fa78f71dd1a5c2e3eec0e0686cd0a500dac22a241e1072fd9eefe
```

## Complete repair handoff

**Send this once to the original implementation/repair conversation, “00077 54,” not the independent auditor. Leave the other repository conversations idle.**

:chatgpt-content-reference{index="5"}[Download the complete D2 A-to-B evidence-binding repair prompt](sandbox:/mnt/data/Coordinator_RW0_D2_A_To_B_Evidence_Binding_Audit_Repair_V3_Prompt.txt)

```text
Filename:
Coordinator_RW0_D2_A_To_B_Evidence_Binding_Audit_Repair_V3_Prompt.txt

Bytes:
75,480

SHA-256:
b3a939f24f55fbdbf7bede79a7e51a0f6009173f8c881613b57a9b3826dd6432

Lines:
1,082
```

The prompt contains all 70 opening receipts, the existing opener and qualified ref procedure, the two-file ceiling, the nine-role mapping requirements, ready/stopped and equivalent-value controls, X01/X02, retained R01/J01/J02 treatment, and all final validation selections.

Success is:

```text
RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_REPAIRED_V3_VALIDATED_READY_FOR_REAUDIT
```

That supports consideration of a separately issued independent re-audit. It authorizes **no acceptance, staging, publication, Section 41 post-execution persistence, rank-15 admission, physical C2, new migration, live provider/supplier work, ES/Bridge integration, deployment, or RW0-E**.

## Evidence boundary

I reviewed the latest report and operative requirements, inspected the baseline nine-role, lineage, supply and input-binding definitions as inert source, corroborated all 47 baseline blob identities and 23 baseline absences, and checked the seventy-row arithmetic and six focused/full module inventories using the supplied candidate hashes.

I reopened the generated prompt and syntax-checked its embedded opener/helper without executing them. **I did not inspect the live D2 payloads, reproduce the crossed-run probes, run repository tests, or authenticate the live replacement digest myself.**

Some earlier uploads are unavailable; re-upload a specific historical original before requesting a byte-level comparison against it. The materials required for this handoff were available.

**Sources:** Your latest independent audit; the current audit and implementation mandates cited above; Coordinator baseline `_post_execution_evidence_values.py:91–136,1637–1787,5214–5418,5821–5854`.

**Confidence:** High on the missing consuming relationship and two-file repair boundary. The complete implementation, causal adequacy, final validation, and independent D2 acceptance remain unresolved.
