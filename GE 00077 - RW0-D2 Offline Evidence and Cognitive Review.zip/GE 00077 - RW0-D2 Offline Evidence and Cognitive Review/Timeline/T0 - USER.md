Alright. Let's continue then.
