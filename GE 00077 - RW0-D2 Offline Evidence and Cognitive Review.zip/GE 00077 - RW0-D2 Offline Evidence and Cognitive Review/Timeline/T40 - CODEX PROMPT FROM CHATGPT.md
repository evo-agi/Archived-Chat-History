# Governed Execution Coordinator — RW0-D2 Strict-Expiry Audit Repair V4
# ACTIVE TASK: native fresh bound-effect upper-lifetime boundary
# One implementation writer; two-file ceiling; preserve completed V1/V2/V3 work

## 0. Routing, first action, and authorization

Send this ONCE to the original IMPLEMENTATION/repair conversation identified as
"00077 54", not the independent auditor that found the lifetime defect. Leave
other repository conversations idle. This authorizes a new bounded source/test
REPAIR interval, not a repeat audit, old vector repair, mapping pass, contract
tranche, or physical C2 program. This complete mandate supersedes older task
instructions AS EXECUTION AUTHORITY FOR THIS ENGAGEMENT; their results remain
historical evidence. Do not select an obsolete V2 or pre-V3 opening.

FIRST protected repository action: tool working directory '/', plain guidance read:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

Read the complete output, using additional plain reads for truncation. Then run
section 2's filesystem-only opener BEFORE Git, source inspection, directory
listing, imports, tests, or edits. External instruction reading as plain data is
permitted preparation, preferably using absolute paths and neutral cwd. Cwd alone
is not a repository action. A genuine protected pre-opening action is an immediate
stop; do not replace an interval, reset the index, or reconstruct old metadata.
No initial git status/branch lookup. The helper is not an OS interlock.

After the correct opening, authenticate ALL 70 endpoints and the fixed V3 raw
replacement, perform the bounded ref check, reproduce the fresh expiry defect,
repair it, and complete the selected evidence/validation without another user
approval or a preflight-only handoff. One parent writer; no subagents, extra model
sessions, provider calls, network, or cross-chat work. Report actually visible
model/effort/permissions or 'not visible'. Dispatch discipline does not establish
OS-level exclusion. Observed competing source/index writes require a stop, not
racing another job, machine-wide process/credential scans, or a new lock service.

The LIVE checkout permits only inert/guarded inspection and the two working-file
edits in section 1. ALL repository imports, tests, SQLite fixtures, fixed fake
children and controlled defects execute ONLY in positively owned, remote-free
external copies. Installed tools only. No live-checkout code execution or database
open; no operator/product state, credentials, provider state, sibling repository,
ES/Bridge/CP/IM/MA operation, network, package install, source/doc/test outside the
ceiling, stage/add -N/write-tree/index refresh, ref/config/worktree write, commit,
fetch/push/PR/merge/tag/release/service/deployment. No public API, schema/domain/
field-order change, migration/catalog change, rank-15 admission, Section 41
post-execution persistence, physical C2 decision/acceptance/terminal writer,
new attempt/retry executor, or RW0-E effect. No live ref restoration of any kind.

## 1. Finding and exact source/test ceiling

The latest INDEPENDENT read-only audit authenticated repaired V3 and reproduced a
material HIGH-severity contract/authority-lifetime and durable-state defect in
an external fixture using the real fenced writer. It reports that the fresh
bound-effect predicate near `_sqlite_development_bound_effect_establishment.py:271`
uses `binding.expires_at >= now` and `attempt.expires_at >= now`; the subsequent
freshness decision near :319 lets a validation family commit at equality.

Both represented expiries were 2099-01-01T00:00:00Z. Changing ONLY the transaction
clock in otherwise supported fixtures produced:

| Supplied transaction time | Observed outcome | Target mutation receipts |
|---|---|---:|
| Exactly equal to both expiries | committed | 1 |
| One second after expiry, fresh fixture | CURRENT_STATE_CONFLICT | 0 |

This is an actual durable boundary counterexample, not merely a source-text
mutation or a malformed returned handback. The timestamp is controlled TEST time,
not a claim about the wall clock. The safe binding is an artificial local
assertion: no external grant authenticity or production execution permission was
proved. The auditor made no repair. Inspect actual current source and owners;
line numbers are pointers, not assumptions about names or implementation.

SELECTED CORRECTION: on the genuine FRESH path, require BOTH

```text
transaction_now < binding.expires_at
transaction_now < attempt.expires_at
```

Use the existing validated timestamp representation and the existing transaction
sample. Equality is expired. Preserve all other current-state, command, capsule,
ceiling, grant, stop, receipt, fence, and transaction predicates. This fixes the
implementation to its existing contract; it does not select a new lifetime policy.

ONLY these two existing C-status candidate files may change:

| Path | Purpose | Opening bytes | Opening SHA-256 |
|---|---|---:|---|
| `src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py` | Correct the fresh native upper-expiry predicates, preserving receipt-first replay and readback-only recovery | 23,762 | `d5012ef7dd383ae39364772d7702364fc0eadde31a1e64997c0a6773d6025245` |
| `tests/test_rw0_d2_bound_effect_persistence.py` | Real fenced validation/review boundary tests, durable no-write assertions, replay/recovery preservation, and bounded causal controls | 6,068 | `839a68b7285480a6ca19885be2df2e398dbedb8e6909f381f5cfe4aa8155da67` |

Both are working creations absent from HEAD/index; both remain C. No new path,
delete, rename, or mode change. The other 68 candidate payloads and 216 other
tracked payloads remain exact. Earlier broader ceilings do not grant extra rights.
Preserve all existing tests and their meanings; add regressions rather than replace
or bypass them. No production helper, public clock injection, new parser, schema,
error vocabulary, source profile, consumer registry, or transaction owner is needed.

The prior final-handback, checkpoint, and integration repairs are PROTECTED:

```text
src/ge_nwp_coordinator/_rw0_d2_handback.py
  28,905 bytes
  85ea3872fe52dbf12608b1dcd47499b76ff11fc556b0c689498fdce56346f7ed
src/ge_nwp_coordinator/_rw0_d2a_handback.py
  20,455 bytes
  7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f
tests/test_rw0_d2_offline_integration.py
  51,581 bytes
  e682b402875f7115d210d9c11bf1211f004efc388f8414163e4b42556ab96e36
```

The V3 missing endpoint receipts are now resolved by the auditor's authenticated
measurement and fixed full aggregate. They are exact opening expectations here,
not placeholders to be filled or old V2 values to reuse.

This explicit repair ceiling does not require a mechanical .docs change for
correcting an already-governing rule. Leave docs/guidance unchanged. A substantive
owner contradiction or an indispensable unlisted change is a stop with exact
source evidence, not permission to weaken the rule or alter a protected hash.
Retain authorized partial work on a substantive stop; do not roll back completed D2.

### Read before editing, inside this repair rather than another map

Read both mutable files IN FULL and their current called command validation,
write-plan, exact-family verification, replay/recovery and cleanup methods. Follow
the current concrete WriterSession delegation and transaction controller through
fencing, receipt lookup, current-state reads, timestamp capture, inserts, receipt,
commit/rollback, capability invalidation, result return, and recovery. Inspect the
D2 owner, B1 lifetime rule, bound-effect subset/receipt owner, and relevant existing
persistence/recovery and source-boundary tests before choosing an edit.

Read-only supporting paths include:
- `.docs/rw0-b1-pure-phase-values.md` (baseline :181-185 and :252-265);
- `.docs/rw0-d2-offline-evidence-and-review.md` (current candidate owner);
- `.docs/c2b-durable-development-state.md` (reached bound-effect/receipt sections);
- `.docs/writer-session-authority.md`, `.docs/worker-execution-boundary.md`,
  `.docs/rw0-c1-durable-evidence.md` and the directly relevant recovery rules;
- `_development_bound_effect_establishment_contracts.py`,
  `_worker_execution_semantic_values.py`, relevant effect/decision row values,
  `sqlite_transition_transaction.py`, `sqlite_writer_session.py`, and
  `_rw0_d2a_offline.py` under src/ge_nwp_coordinator;
- existing D2 command/persistence/readback/integration tests and owning guards.

Baseline inspection anchors, to confirm against actual current bytes:
- B1 :181-185: `observed_at <= now_utc < expires_at`; equal-time expiry fails.
- B1 :264-265: now_utc is strictly before each applicable expiry.
- `_worker_execution_semantic_values.py:3843-3845`: current effect expiry is
  at most attempt expiry; :3231-3233 gives the corresponding author containment.
- Existing controller's `_capture_transaction_timestamp` and existing tests'
  monkeypatching of that source illustrate controlled external test time. Do not
  edit the controller or patch its decision logic. Inspect the current call graph.

The B1 observation rule does not turn this native binding into authenticated
external evidence, and this repair does not import all B1 relations into the
writer. It restores the strict upper boundary on the two lifetime fields the
fresh native path already checks. Do not change lawful non-strict *containment*
(`effect.expires_at <= attempt.expires_at`) or unrelated event ordering into strict
inequalities. Deadline equality is the defect; equality between allowed nested
expiry bounds is not itself a defect.

## 2. Fixed V3 baseline, opener, and complete subject

Repository: `/Users/ds/Repositories/Governed Execution Coordinator`

```text
branch: trunk_dev
HEAD: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
tree: cc3cc104300f553ada581cee24e80dab6dd885b1
sole parent: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
subject: feat: add RW0-D1 offline process and capsule spine
upstream: origin/trunk_dev at locally the same commit; divergence 0/0
one worktree; no active Git operation or unexplained lock
index: exactly 263 stage-zero HEAD entries; no staged/unmerged change
working candidate: 47 M + 23 C = 70 changed paths
other tracked working files: 216 HEAD-exact
current source endpoints: 286 = 263 baseline + 23 additions
AGENTS SHA-256: ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166
index SHA-256: 7af425d5a47b91b0a14294660f5d449f5ba6308dc8846a8b13aca371c191a587
known opaque cache: src/ge_nwp_coordinator/__pycache__, directory + 37 members
SQL resources/catalog: unchanged 0001-0004 only; no 0005
```

All 70 candidate files are regular nonsymlink OS 0644/Git 100644. Preserve actual
other-file modes, including tests/test_c2b3_private_atomic_program_initialization.py
at OS 0600/Git 100644. All 23 creations are PRESENT in the working directory and
ABSENT from HEAD/index. Do not demand a clean worktree, an older 69-path overlay,
pre-V3 handback bytes, or an index matching the working candidate. No network:
local upstream equality is not fresh GitHub truth.

Baseline archive corroboration only: 3,134,667 bytes, SHA-256
06d981b6100fc1d6ad9792aff35800eb0772b8d35f708ed030177967ccb9c40e;
263 source leaves reconstruct the given tree. It has no current D2 candidate and
no .git ref history. The existing local baseline and fixed current receipts are
sufficient; no new snapshot or historical mutant package is required.

Establish this new interval using the existing filesystem-only opener below.
Only labels/root prefixes have been adapted. It records guidance, index and
cache bytes/metadata and writes its own external helper/record; it invokes no Git
or repository code. Do not reuse a deleted audit root or replace a failed opening.
Guidance, index and cache remain immutable even though two working files may change.

```sh
python3 -I -B -S - <<'PY_OPEN'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env


import datetime
import shutil
import tempfile

guarded_environment()
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_not_exact_audited_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_unavailable')
gate_root = Path(tempfile.mkdtemp(prefix='rw0-d2-strict-expiry-repair-v4-'))
os.chmod(gate_root, 0o700)
print('GATE_OWNED_ROOT=' + str(gate_root), flush=True)
record = {
    'schema': 'rw0-d2-strict-expiry-repair-v4-opening-observation',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents, 'index_path': str(index),
    'index': index_before, 'cache': cache_before, 'git_executable': git,
    'git_environment': GUARDS,
    'limit': 'This strict-expiry repair V4 interval only. Only the two named working payloads may change. Index, guidance, cache and protected refs remain unchanged; section 3 qualifies separately observed diagnostic refs. No ref write, staging, commit or remote action is authorized.'
}
READ_HELPER = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\n\nimport subprocess\nimport sys\nopening = json.loads(Path(__file__).with_name('opening.json').read_text(encoding='utf-8'))\n\ndef immutable_checks():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('audit_index_content_or_metadata_drift')\n    if regular_record(REPO / 'AGENTS.md') != opening['guidance']:\n        raise RuntimeError('audit_guidance_content_or_metadata_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n\nimmutable_checks()\nindex_before_read = regular_record(index_path())\nargs = sys.argv[1:]\nif args == ['--check']:\n    print('READ_HELPER_IMMUTABLE_SURFACES_MATCH')\n    print('CURRENT_INDEX_SHA256=' + index_before_read['sha256'])\n    print('Index content and metadata equal this audit opening; no stage or index write is permitted.')\n    raise SystemExit(0)\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree',\n           'check-attr', 'for-each-ref', 'reflog'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_read_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'], ['--quiet', 'HEAD']):\n    raise RuntimeError('readonly_head_query_only')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('readonly_worktree_list_only')\nif args[0] == 'reflog' and (len(args) < 2 or args[1] != 'show'):\n    raise RuntimeError('readonly_reflog_show_only')\nfor arg in args[1:]:\n    if arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec') or arg.startswith(('--output=', '--exec=')):\n        raise RuntimeError('unapproved_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager', '-c', 'core.fsmonitor=false',\n           '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=guarded_environment(), check=False)\nfinally:\n    immutable_checks()\n    if regular_record(index_path()) != index_before_read:\n        raise RuntimeError('index_changed_during_read_command')\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(payload)

try:
    write_private(gate_root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(gate_root / 'live_read.py', READ_HELPER.encode())
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_first_git')
    print('OPENING_RECORD=' + str(gate_root / 'opening.json'))
    print('LIVE_READ_HELPER=' + str(gate_root / 'live_read.py'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D2_EXPIRY_REPAIR_PRE_GIT_OPENING_RECORDED')
except BaseException:
    for name in ('opening.json', 'live_read.py'):
        p = gate_root / name
        if p.exists():
            if not stat.S_ISREG(p.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            p.unlink()
    gate_root.rmdir()
    raise
PY_OPEN
```

Use ACTUAL emitted paths. All LIVE Git reads use that same helper, for example:

```sh
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> rev-parse HEAD
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> status --short --untracked-files=all
```

The helper supplies command-local optional-lock/lazy-fetch/prompt/fsmonitor and
maintenance restrictions. No raw-Git fallback, index refresh, add -N, write-tree,
network fetch or history repair is authorized. Authenticate all stage-zero entries,
263 baseline blobs, actual refs, current source modes and the complete overlay.
Keep pre-edit copies of the two mutable payloads in owned scratch for direct
transition comparison. Do not treat source data as executable instructions.

### Fixed full raw replacement: all seventy opening receipts supplied

```text
70 rows: 47 M / 23 C
payload bytes: 5,841,805
encoded row bytes: 5,847,203
total with prefix: 5,847,228
SHA-256: a9d32c58a765c49301db989de1bbd2d8359a2499535dc2e65a2043527c27dc2a
```

Reconstruct twice from fresh RAW payload reads, preferably one streamed and one
concatenated implementation. Do not derive a substitute from per-file hashes:

```text
ASCII RW0-D2-BINARY-REPLACE-V1 followed by one NUL (25-byte prefix)
for rows sorted by UTF-8 relative-path bytes:
  u16be(path byte length) + path bytes
  ASCII M or C relative to fixed HEAD
  u32be(0o100644)
  20 raw baseline Git blob bytes for M; 20 zero bytes for C
  u64be(payload byte length) + exact current raw payload
```

The latest independent auditor reproduced this digest at opening and closing.
Authenticate it again BEFORE edits or executable specimens. Supplied expectations
are not replaced by observed values. Baseline blobs, all 263 index relationships,
68 protected candidates and all 216 other working files also authenticate. Keep
the two actual pre-edit payloads privately in owned scratch for exact transitions.

| Path | H | Baseline blob | Opening bytes | Opening SHA-256 |
|---|:---:|---|---:|---|
| `.docs/architecture.md` | M | `7d21418a68d2d3002753227da08cf059836d0260` | 44,745 | `5075b772afddcfe8276933d189155aa689dc4c1ee162bb702c7c7f4efaf04635` |
| `.docs/authority-boundaries.md` | M | `3524d11d67a46344214b455396afeeaa3754b41d` | 36,175 | `79c57d377b6ef7f2460ee5a5827b9c5c61334e656be9eeed73264a6906e55e32` |
| `.docs/autonomous-software-development-operating-model.md` | M | `a46d51fe3ea480e39c8c7989a08e80d9db21f5b8` | 41,197 | `926468bad8cd51c57e3aec6da775c6dced52880215f24d5b03177499a119c6c2` |
| `.docs/b3b2a-read-scope-and-query-contracts.md` | M | `c3237c31fc4b59dcd632b827a4be9907cfcfb998` | 10,013 | `74b1d21b02cd9886a697e1f1cb01dca6977cabb2da194269a35d49745fe548f6` |
| `.docs/b3b2b-select-readers.md` | M | `f1ba74b0a5cd3946a3138de326949d29f789cfac` | 6,477 | `fa7a364ce070b3fcef44907bc884bc783200e1951c618fd7e392d485497c7f07` |
| `.docs/c2b-durable-development-state.md` | M | `04c068d07cd08feaf6c56dafbf3494ccde037ede` | 1,891,411 | `8db2ba24f0685ac21fae2103bb664727a8d9635d3ead5f6bae0d42b35aaf34d2` |
| `.docs/c2b2-private-readers.md` | M | `018b3d905f5db80cf15b546f881dc8c1de3a67b7` | 14,020 | `f765b2dcd74979e235cb04c15dd1fbc81eca149aec017ca500708903bbc105d2` |
| `.docs/c2b2-pure-durable-row-values.md` | M | `1cab6d886f2cd3101987476064a9ce82d2eb4dd2` | 8,540 | `0970595b4c292517d0770542ff8e12a03b98ea93057d4e715d6518415e83aaf3` |
| `.docs/durable-state-model.md` | M | `49694cd86a51f3fb0fb3799e734a52c1a395b8c7` | 42,053 | `7f9cba19f491322dd2fc0f1656ac6b76e698723a6700d1f9919d22b2196e9e80` |
| `.docs/rw0-b1-pure-phase-values.md` | M | `5b7fb0072c6d04898cd212fdc4ff5f63903cf13b` | 35,115 | `7294e7b3aabad5338c4d846e44686ffd075b3e8fe4598495a3e7267103a9ef1e` |
| `.docs/rw0-b2-wire-protocol.md` | M | `5e41d1cb3b2f430d29eb88bdbf2b46570faf3c6b` | 26,084 | `ac1091f043f5fa6042ced1e919c740a08af975b7df1e5e97b66634f85cb68e69` |
| `.docs/rw0-c1-durable-evidence.md` | M | `a7111c4dcf761b60df35c59794bf2e3acd949745` | 15,037 | `f2c6c51d0437aa78b7975bfca3e6fc629fc2898d55c0c696750221000343a02c` |
| `.docs/rw0-c2-first-live-proof-posture.md` | M | `4b69e424655ea67900f6c6042c0cbacaf2d53f8a` | 17,674 | `ba61008234eb5ec85416c459dab0a82b19f7e1a0662dcb15f1289ba445fdf5bd` |
| `.docs/rw0-d1-offline-process-and-capsule-spine.md` | M | `f3557ca523cac0d6fa26647b17a84aef66fecc15` | 5,624 | `b537fbe074717aacdfaefd2cf32cd22c46046034ae115453ddded4e2dc25201b` |
| `.docs/rw0-d2-offline-evidence-and-review.md` | C | `absent` | 8,348 | `f9306ad7333ae08aefd62456041629380c05e984bddc3925258c655a28fa7580` |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | M | `230167a39b115634c8f9b5ae5a0699639f6ff454` | 59,586 | `bee20ed00c7e6f86db3394351f0cbe29626413c635cd9a982416984b288e6fbd` |
| `.docs/worker-execution-boundary.md` | M | `464aef2aa7a561e4adc6792d1d07642d3576f364` | 32,409 | `3cfc1208d96e1f59a81dcd70dce5d43d89f2cb70cc5af6eca453650c33742769` |
| `AGENTS.md` | M | `254854d4a57487d97ce02a73ce2ed26c86ece170` | 64,142 | `ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166` |
| `README.md` | M | `088c832ca7e28d18c82ff6317738ac8ca1c7b5d1` | 47,694 | `f48f2439d282350e36b5d8374864cb5dfe19eb417672737e820500c3a68224f3` |
| `src/ge_nwp_coordinator/_cognitive_proposal_semantic_values.py` | M | `c164616b9e86379c3c6a9210cf4941429a596d4c` | 71,190 | `40243b96765ee0bf49e56a36123e0553f3bb9ab3e0fada38dbe619a2acc1eacd` |
| `src/ge_nwp_coordinator/_development_bound_effect_establishment_contracts.py` | C | `absent` | 43,039 | `fd8fb53c8129001b74df8fa5b15ae69bb45fd970e2aa93f3bc5c20eeeeb1b370` |
| `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | M | `cb37f733141f1e3c3ce874fcc052149de1f82881` | 3,668 | `21e0c9d6c2ece57b87dfb05e961ba1a99a48e72346bbab2c4c1ed571eb5f1f00` |
| `src/ge_nwp_coordinator/_rw0_d1_handback.py` | M | `ecfcf767a5f1c32c0cf007a2c8aa3137ef92374d` | 16,920 | `3cae7fa4423187d53382ba23d9e459a5f0efcb6900a4deed6d4498ed2534ed56` |
| `src/ge_nwp_coordinator/_rw0_d1_offline.py` | M | `4f2a82e46fda9be8123888f5ca46968a4345c25f` | 23,371 | `9546f06f211253d72ea91e0dc2eaf4f0b47fdd54e3d431207f59960fbc742c95` |
| `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | M | `7dc90a0442e348aaac985d711c4d1a97adb7cc05` | 12,175 | `a236bbf599e7d32b4edcc31d23182fd9613c5d290f31a0f1e57961b6a104fe56` |
| `src/ge_nwp_coordinator/_rw0_d2_handback.py` | C | `absent` | 28,905 | `85ea3872fe52dbf12608b1dcd47499b76ff11fc556b0c689498fdce56346f7ed` |
| `src/ge_nwp_coordinator/_rw0_d2_offline.py` | C | `absent` | 6,967 | `d838dd02495cab5cbafa2e6e0b99d6a4e6b4b30e4ac5cb288cb9dd2db02d0d44` |
| `src/ge_nwp_coordinator/_rw0_d2a_evidence.py` | C | `absent` | 53,134 | `e93c2592c8f838bd178ffa8e57f57a9116fcdf567b248e511496d00384968ec9` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_reviewer.py` | C | `absent` | 2,878 | `0d061fdf600039ff69ba0d0dc3f1a0239c2527500461244bb53455bbdd326973` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_validator.py` | C | `absent` | 2,726 | `c1eb49503b4345d25047814e089545f9d1cd4c85f10ae20254b8b6283fa58fbe` |
| `src/ge_nwp_coordinator/_rw0_d2a_handback.py` | C | `absent` | 20,455 | `7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f` |
| `src/ge_nwp_coordinator/_rw0_d2a_offline.py` | C | `absent` | 30,416 | `d81db9535b17c7daae7be449d7e30dbcaaa599749ddc2619dbfa7d40f87db838` |
| `src/ge_nwp_coordinator/_rw0_d2a_process_frames.py` | C | `absent` | 6,397 | `2c969b1ec303674500143bbbd721e4fe5f7ee161e00b4343f71a611a7f075c8d` |
| `src/ge_nwp_coordinator/_rw0_d2a_workspace.py` | C | `absent` | 5,075 | `45086c2b216639d3a35deef972acda526f004608780a8a8b5e30ed51253f0697` |
| `src/ge_nwp_coordinator/_rw0_d2b_fake_review_model.py` | C | `absent` | 3,771 | `492288c84c2491120a56c7056000f8ec3860c7fbce2bcb3c33249e5e1af5d93a` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_frames.py` | C | `absent` | 8,032 | `e4b7cddc6cfd4caa7e34781e1c34c00833d6f83a98477d46ce55e878e97dfcef` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_input.py` | C | `absent` | 81,718 | `e2bbe585f8ae19df5dd6547212cf239ac58411795cbae904cf3ed869910bdd9a` |
| `src/ge_nwp_coordinator/_rw0_d2b_proposal.py` | C | `absent` | 22,718 | `deec7caf82206c40545a308f3a8845fb867e64a211a81e055fb29ffbafc0666a` |
| `src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py` | C | `absent` | 23,762 | `d5012ef7dd383ae39364772d7702364fc0eadde31a1e64997c0a6773d6025245` |
| `src/ge_nwp_coordinator/_sqlite_rw0_c1.py` | M | `635b5dd49256e14103fced6ff8ea4db76649e22c` | 203,409 | `d17490b3ce1b136eeb3d559f01f44e97836827bc137325b306ec01530e06e9e7` |
| `src/ge_nwp_coordinator/sqlite_transition_transaction.py` | M | `f8053db4010faaba41b38b531d93a8b21e80daa8` | 180,600 | `6d662dcb83a2641b9d95dee7209ddbd0d8b991bc720da3aafa5b4b9fb3bc5521` |
| `src/ge_nwp_coordinator/sqlite_writer_session.py` | M | `97162e3a749a7f1f1ae75de90c4b2d9092068107` | 299,804 | `54f9c5a0844421686c1c89cdecf3c2865263b3339d2faec933c615ca2ca3d404` |
| `tests/test_b2a_writer_session_contract.py` | M | `ccadd884de29d606c9243ea7796cc380e29fe5c2` | 29,168 | `835b386274f410f2fc52b1a40b2c936009ac5286fb22bc23cc28efa789be0664` |
| `tests/test_b3b2a_read_scope_and_query_contracts.py` | M | `66cab4655d33c1b864f5fb4c22e853a39c5a8188` | 26,502 | `4cabeed0c37a99c0f937c0b49f25c7c6a049eb9125e64127019c449dcd86313a` |
| `tests/test_b3b2b_select_readers.py` | M | `c0c5a0e091572f30a428fd5a2634c21d25a6ad64` | 118,350 | `22061f6846b0ebc969f9b67bac399b8d8eb237c8df0e2de92d84d477c0f1ce2b` |
| `tests/test_b3c4c_prerequisite_contract.py` | M | `f1ee03232e33da8bbfa5592fe81c53414acb25b1` | 36,340 | `3d25c2ffb8ee86856c154cfc9dd842bab2db87ea2b200cd75758a62f372b5cd8` |
| `tests/test_c2a_nonimplementation.py` | M | `3f343ae5886c92941ebfff63ba4213de2109025e` | 30,650 | `c0db68e10f4588c02bbc38da1b95d6898a3d7896c127038533ce0c8a6715442e` |
| `tests/test_c2b0_durable_state_contract.py` | M | `b910d61aaf670ba40a0d649f933c06767e7360e5` | 887,367 | `995c3690500e3d3009f1fe93b276db506e1d454764dd2e5167df52bf81252c1a` |
| `tests/test_c2b2_development_reader_contracts.py` | M | `122f0d44b46e0a8d7b283d5baec1ce465e2028b6` | 71,365 | `28dbf4fff09d75d7522af35c8fddc8908b7c4c1d18ff8043d19dbf6b90f30970` |
| `tests/test_c2b2_development_row_value_boundaries.py` | M | `d7dea23786bec2ca98bb702bbe93cc31e4192221` | 17,972 | `f2a7089748f39dc8c40a932ac770edd3ffa7f8ea581b053af101dfda8100c830` |
| `tests/test_post_execution_pure_owner_boundaries.py` | M | `437a4e7cbd39682bdd08f03b3a30c0bbbd057614` | 19,302 | `7945be6d5e01c2a1b437cabc57972bbd70a725da9c14f7dd92574ff8f8633014` |
| `tests/test_post_execution_pure_owner_vectors.py` | M | `3eed1c6bc08b6876d1e74d94a4e5509c14786eb0` | 103,682 | `3d526cabcead871b5bba47952b914df76a34b5d85a7b730e55afb951c050de16` |
| `tests/test_runtime_non_authority.py` | M | `79d4ab185815234c9d087c48d2439b9a1d95d95d` | 48,343 | `fef5729d8e7f4c619ddb2731b52d3500bc8e75988a3f422648b9dea743ef01c9` |
| `tests/test_rw0_b1_boundaries.py` | M | `17d1e09c30b01287718c6b5175bac76b03daf458` | 52,838 | `af8d9f7507733876a5978d1a3f5b871a81030380eba929cbffe6959f9d639aaa` |
| `tests/test_rw0_b2_capability_boundaries.py` | M | `4668d2a2c285d2d79bf6ebfb0c9c9f60166bcb27` | 50,538 | `85ee20f37629ffc852154cea67dd5dc983b0f2f74ab2d370192c13d999b397c3` |
| `tests/test_rw0_b2_wire_boundaries.py` | M | `9e04f528326a6f337a4f47e7e9f9eda3c9a82e0a` | 38,513 | `13531d5d46258ca67cc7bf0bddd78c560ce9b7308ff296068a146299f349ba27` |
| `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | M | `0f0159c172e1448d2b96ab19411e1f85467a2931` | 120,405 | `af7f49ac8da64c12e97d03a536ee10b89a11996651b0d712dc04baef427d8cf3` |
| `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | M | `e9d95b54a4b5921be8ec39d2bf3f6216204750c7` | 247,679 | `e8de37791388c28f1b1626747af6c4094622469168ed9799eaa78f7f6f4d3613` |
| `tests/test_rw0_d1_handback_values.py` | M | `982be9b37aa05db0c6d6a3321b775c7c64f2142d` | 30,189 | `e8addc00e8b37aa5e6f24a91a637c9f5053656c58a0d4c06e713618229e448b6` |
| `tests/test_rw0_d1_offline_integration.py` | M | `33c2d85012cbdf0e7e04fdeb7d333d2c8675ae3f` | 53,132 | `c5997a4e9161253974b04b203bf55754c12b465c3b0b5924247e6c1df8e05c9e` |
| `tests/test_rw0_d1_worker_process.py` | M | `e2a83abe44db720b5ce0725682ac71d30372959d` | 1,737 | `512d7d61083e8ad8c61c197aefc86f70d61a1f7e41273fab435bb493cc08631f` |
| `tests/test_rw0_d2_bound_effect_contracts.py` | C | `absent` | 5,636 | `4c8f04a5f16d0e0b236f8fff636e5d9a5d41c465dad6fc726bd488fb76b59574` |
| `tests/test_rw0_d2_bound_effect_persistence.py` | C | `absent` | 6,068 | `839a68b7285480a6ca19885be2df2e398dbedb8e6909f381f5cfe4aa8155da67` |
| `tests/test_rw0_d2_c1_checked_readback.py` | C | `absent` | 17,750 | `20237660028125bacccf52bb695cb275adebefb2ed1f0a28bb271688f7aadb01` |
| `tests/test_rw0_d2_evidence_children.py` | C | `absent` | 3,635 | `fd4cd60a30cb641d34b458f7782bcc27d020a37f47f6523c37cfcf83895d516b` |
| `tests/test_rw0_d2_model_handback.py` | C | `absent` | 4,966 | `89c53206f1b636257ecf5f71027e11ca4ef4cfdd00883e55b2c0fa02fe2a7a6e` |
| `tests/test_rw0_d2_offline_integration.py` | C | `absent` | 51,581 | `e682b402875f7115d210d9c11bf1211f004efc388f8414163e4b42556ab96e36` |
| `tests/test_rw0_d2_process_frames.py` | C | `absent` | 6,894 | `f77f49268e4ed693d049560307aa3794538842efc8afa24e1500664fc4884264` |
| `tests/test_rw0_remote_contact_phase_entry_contract.py` | M | `2a9144c3dfd2c883555703c8adecd21f447d6d34` | 177,317 | `6df3c991a219633d148106396336f2702c323b6cddb82932b41152ea3e5ac16a` |
| `tests/test_sqlite_backend_b0_contract.py` | M | `c646df6d439d0b70f45d6d72200fbedb5e730779` | 26,412 | `1eb038201c19be7e9680f5ee6c4425fb50051b8bc0df31e3feeab06620cc094e` |

## 3. Protected refs and carried-forward diagnostic observation

The latest independent interval observed 52 refs: 28 protected and 24 conditionally
classified diagnostic records, unchanged at opening, pre-execution and closing.
Its reported snapshot SHA-256 was
e4b7d69b413ddf78d66a9ddd934b9312e1c8cc1f3c07b2af065c97203120b226.
This is a PRIOR observation, not a fixed count or complete ref map for this repair.
HEAD was symbolic to refs/heads/trunk_dev; origin/HEAD resolved to origin/main.
Do not 'correct' that unrelated symbolic target. No current ref defect is selected.

After the opener, BEFORE editing/external execution, capture actual ref names,
OIDs and symbolic targets via the emitted helper, including for-each-ref with
`--format=%(refname)%09%(objectname)%09%(symref)` and `symbolic-ref -q HEAD`.
Keep an immutable external snapshot and disclose its serialization/digest.
Every ref is protected by default. Only records under these exact subtrees may
receive a conditional diagnostic classification:

```text
refs/codex/turn-diffs/captures/
refs/codex/turn-diffs/checkpoints/
```

Reconfirm applicable non-use from unchanged/current source, guidance, configs and
available records: none supplies program/admission/policy/recovery/publication or
validation authority; no protected symbolic ref resolves through one; no source
copy or expectation selects its captured tree. Consider reached generic ref
selection/--all use, not merely literal-search absence. The source subject is fixed
HEAD plus authenticated payloads only. Names alone and prior counts are not proof.
All unknown/outside refs and any inside ref with a protected dependency stay
protected. Reclassify a newly seen record only on the same bounded evidence.

Capture refs before edits, before final execution and at closing. Keep protected
refs against the SAME opening and disclose exact old/new diagnostic exceptions.
No exception permits changing source, index, guidance, cache, configs or policy.
Source/index/protected-ref drift or an unclassified dependency blocks. No raw Git
fallback, ref writer, ref restoration, fetching old objects, recursive captured
payload dump, provider-state investigation, or new forensic program is authorized.

The earlier V1 repair's all-ref failure remains qualified history (two removals at
014f6845ec3672c7a2c2e54f8745e8d2e0505a06 and two additions at
1450a5e4845d20d9199004ea862ebdeadb8139e0). Its writer/cause remain unestablished.
The later V2 and V3 intervals had their own reported unchanged ref snapshots.
Do not attach the old failure to the latest 52-ref interval or manufacture an
interval-wide immutability claim from endpoint-only observations.

## 4. Strict fresh lifetime; preserve historical replay and recovery

### 4.1 The two upper boundaries are exclusive

Inspect the actual fresh path before changing it. Correct each reported inclusive
comparison to its strict counterpart on the already checked canonical values:

```text
binding.expires_at > transaction_now
attempt.expires_at > transaction_now
```

Equivalent strict spelling is acceptable; a new abstraction is unnecessary.
Both validate_candidate and review_candidate must use the repaired boundary.
Do not change lifetime start bounds, author behavior, grant-source authentication,
expiry containment, schema/digest identity, ceilings, stop semantics, or lower-level
transaction mechanics merely because their code is nearby.

The comparison remains AFTER the existing writer/session fencing and required
owner reads, on the genuine fresh path and BEFORE any selected family insertion.
The original transaction owner supplies the time; do not introduce a second clock
sample or a caller-selected bypass. Do not push the only check into a command
constructor or parent orchestrator. A well-formed command created while valid
can be expired by the actual transaction check.

Use the existing time precision/normalization. No grace period, tolerance, one-second
subtraction/addition, timestamp clamp, date shift, automatic renewal, sleep, retry,
'allow_expired' flag, host-clock change or timezone change. Valid strict comparison
on canonical whole-second UTC is enough. The guarantee remains about the existing
transaction-time check, not a new assertion of continuous authority through a
later wall-clock COMMIT instant or arbitrary external-clock authentication.

Return the current content-free CURRENT_STATE_CONFLICT outcome when freshness
fails. Do not insert a success or refusal receipt, partial family, new head or
updated historical timestamp merely to record the refusal. Preserve current
error/collision precedence outside the selected expiry correction. No automatic
child launch, admission or new mutation identity may follow to bypass refusal.

### 4.2 Node validity and lifetime containment are separate

Do not relax existing exact-type/canonical/digest or source-to-command/owner
validation to reach a clock test. The binding and current fence's expiry are
related by their owner, and the current fence must remain within the attempt's
expiry. Read the actual current constructor relation and state it in the report.

In particular, with binding expiry <= attempt expiry, an attempt that has expired
cannot coexist with a strictly unexpired binding in a valid command. A strict
binding check may therefore mask a weakened attempt check. Do not construct an
invalid wider binding, reseal a broken parent graph, or disable containment to
claim that the attempt comparison was independently reached by a legal writer.
Equal-expiry tests prove the combined boundary. A shorter binding with a longer
valid attempt can isolate the binding boundary. Preserve BOTH explicit strict
checks and label any redundant-layer limitation accurately.

### 4.3 Do not turn a fresh-operation gate into historical reauthorization

Receipt-first exact replay remains after fencing/full original-family validation.
A family that VALIDLY COMMITTED strictly before both expiries stays an historical
fact when a later identical command is replayed or its outcome is read back.
Clock advancement alone must not turn that into a new mutation, refreshed grant,
new receipt, changed timestamp, or fresh CURRENT_STATE_CONFLICT.

Use the existing same-command exact_replay and readback-only committed_exact
recovery paths. Preserve selectors, receipt digests, member graphs, timestamp
identity and uncertainty handling. No new query, retry or repair executor.
Whether the existing caller captures an unused time is an observed implementation
fact; do not add a new clock read or alter a protected controller. Where the
existing contract/path is clock-free, preserve and test that guarantee. In all
cases replay/recovery must not refresh stored time or apply the fresh expiry test
as a new admission rule.

This positive concerns families committed BEFORE expiry. It neither approves nor
migrates an invalid equality-time family created by the old defect. Those repro
fixtures are disposable. No live database inspection, rewriting, migration or
retroactive reconciliation is authorized. Existing absent/partial-family recovery
classification remains conservative; do not invent a successful record because
an earlier attempt might have committed.

## 5. Required real-writer tests and bounded causal proof

### 5.1 Reproduce the authenticated opening defect before editing

Create a remote-free external copy of exact baseline plus all current candidate
payloads. Use the real D1-produced or existing accepted persistence fixture inputs,
canonical bound commands, concrete fenced writer/controller and disposable SQLite.
No hand-seeded target family/receipt, mocked success result, bypassed guard, direct
SQL creation of the subject, or stand-in freshness predicate supplies the proof.
Test-only supported setup may reuse current fixture helpers; inspect their actual
state path and semantics before use. All fixture execution stays external.

Confirm the command and prerequisite graph are otherwise valid. Through the
actual transaction timestamp seam, reproduce equality at
2099-01-01T00:00:00Z with both expiries equal, and one-second-after in a separate
fresh fixture. Record outcome and the exact target receipt/family delta. Changing
the supplied test clock is not changing the host clock or rewriting the command.
A fresh equality fixture is necessary: an already-committed identical command
would exercise replay, not the faulty fresh branch.

At minimum reproduce the auditor's validation case. Then apply the permanent
matrix to BOTH checking classes. If review requires an existing valid predecessor
in the selected fixture, establish it through its owner and record it separately;
'zero target receipts' never means the entire database has no prior receipts.
Do not make fixture-expired prerequisites or stale CAS hide the target boundary.

### 5.2 Durable boundary matrix in the one allowed test module

Add fixed parametrized tests to tests/test_rw0_d2_bound_effect_persistence.py.
Retain existing tests. Expected boundaries are fixed independently of the helper
being tested. For BOTH validate_candidate and review_candidate, use a distinct
fresh fixture for each fresh-operation result:

| Setup | Transaction time | Required fresh result |
|---|---|---|
| Binding and attempt both expire at E | E minus one second | committed, one exact new target family/receipt |
| Same two expiries | E | CURRENT_STATE_CONFLICT, zero target durable mutation |
| Same two expiries | E plus one second | CURRENT_STATE_CONFLICT, zero target durable mutation |
| Valid narrower binding expires at E; attempt expiry later | E minus one second | committed |
| Same narrower binding; attempt still unexpired | E | CURRENT_STATE_CONFLICT |
| Same narrower binding; attempt still unexpired | E plus one second, before attempt expiry | CURRENT_STATE_CONFLICT |

Use valid canonical factories/commands and consistent current fences/requirements
for the narrower-binding variant. Every other prerequisite must remain valid.
No source-body or oracle patch changes freshness for these normal cases. Inspect
and use the installed private clock seam (for example the existing controller
_capture_transaction_timestamp, if that is the actual supplying call) rather than
edit production to add an injection API. Do not blindly patch a guessed name.

For success, independently read back the six target members (intent, current fence,
pending authority evaluation, initial delivery, effect head, delivery head) and
receipt; verify the existing owner identities/graph/time with actual returned data.
For equality/after failures, independently show no target receipt AND no partial
member/head/delivery persisted after the operation completed and a readback view
was opened. Relevant pre-existing owner rows/heads/receipts remain unchanged.
Use logical persisted-row snapshots and target-key probes, not only returned labels
or global row counts. SQLite file bytes can change for legitimate housekeeping;
do not mislabel that as a semantic write or demand raw-file equality as the sole
oracle. Conversely, absence of a receipt alone cannot excuse orphaned rows.

Where call-through SQL/transaction observations are already available, record
that the expiry conflict occurs before target inserts. The observer must not
suppress an insert or return an expected conflict for the writer. Any stronger
preceding refusal is evidence for that earlier predicate, not the expiry check.

Use fixed whole-second boundaries without sleeps. The exact year is a test fixture;
no production constant, lookup exception, or current-real-date dependency is added.
Tests must fail for both checking classes at equality, not merely accept two enum
values while invoking the writer for only one.

### 5.3 Historical replay/readback and no duplicates after expiry

For each effect class, first commit a correct fresh family at E minus one second.
Keep the exact canonical command, original result, six members and receipt. With
all non-temporal predecessor/stop/identity conditions held stable, make later
identical calls at E and E plus one second using actual supported fenced sessions.
They must produce the existing exact replay rather than fresh insertion/refusal
solely due to time. Verify all original refs/digests/times and no additional rows.

Use the actual readback-only recovery API under its required fresh session on that
same valid original family at the boundary and afterward. Expect committed_exact
with the original result and immutable family; no renewal/rewrite. If the existing
path takes no time input, make the test clock available at the later value and
observe non-use according to its current contract instead of injecting a clock
into recovery. Do not assert past expiry prevents looking up established history.

A missing or partial family must not be rescued by these positives. Keep existing
recovery/collision negatives passing; one representative exact-selector mismatch
or missing-member negative from this module can be reused if it actually reaches
the current recovery owner. No general new fault matrix is commissioned.

### 5.4 E01/E02: finite clock-boundary omission controls

Run these on final source with FINAL tests unchanged, one external source delta
in the native writer each, and complete before/after 286-endpoint manifests:

E01 — restore the old inclusive fresh upper checks for BOTH binding and attempt.
The strictly-before positive passes; the equal-expiry permanent real-writer tests
for both classes must lose rejection and fail on their expected conflict/no-write
assertions. Record the actual committed target receipt/family in that copy, then
clean only its fixture. Syntax/import/source-hash/collection failures do not earn
causal credit. This is a combined boundary mutant, not independent proof of each
redundant comparison.

E02 — weaken ONLY the binding expiry comparison back to inclusive, leaving the
attempt comparison strict. Use the valid shorter-binding/later-attempt fixture.
The positive remains valid; equality at the binding expiry must expose a fresh
commit and fail the fixed permanent regression. This isolates the lower effective
lifetime without violating nesting. Credit the actual reached comparison.

An attempt-only inclusive mutation may remain masked by binding containment and
the still-strict binding check. Do not force it to fail with invalid input, claim
it was independently killed, or alter another guard to manufacture that result.
Source review must still confirm both selected comparisons are strict. No E03
campaign, whole validate() deletion, or full-suite run per mutant is required.

Reproduce focused normal cases and E01/E02 BEFORE the expensive final matrix.
Keep exact selected node IDs, positive/negative signals, copy/endpoint hashes,
clock values and target durable effects. Each controlled copy must parse/import
and retain the full persistence-module collection. A collector/import failure is
not a lifetime regression. Controlled old behavior in a disposable copy is not a
new live effect or permission to preserve invalid durable production state.

### 5.5 Preserve earlier repairs without expanding this repair into the audit

The current final handback, checkpoint and integration tests are byte-protected.
No X01/X02/R01/J01/J02 reauthoring or broad rerun campaign is required of this
writer just to change native expiry. Run the unchanged integration module as part
of B_MODEL and all other final groups. Preserve the old controls and their actual
provenance; do not label unexecuted independent predicates as completed.

The latest independent audit passed 49 integration nodes and traced the nine-role
map, but stopped on this durable defect. It did NOT complete X01/X02/R01/J01/J02,
C10, A01-A13, six final groups, or FULL in that interval. Earlier independently
executed controls retain their earlier subject/scope. The writer's 9,084 full
passes remain implementation history, not independent acceptance.

## 6. Exact validation posture, groups, and inventories

After the LAST source/test edit, create ONE fresh normal external copy of the fixed
263-file baseline plus authenticated current 70-file overlay. Verify all 286 source
endpoints before and after every normal command. No live cache/operator database/
secret copy and no hardlinks to mutable live files. A local-only clone can read the
fixed local baseline and must have its remote removed before any execution. Source
copying is also permitted where tests' actual local Git needs are met. Do not fetch
or select turn-diffs trees.

Use installed Python 3.13/pytest, record exact versions, umask 022,
PYTHONDONTWRITEBYTECODE=1, PYTHONPATH=.:src, owned TMPDIR, -B and no pytest cache.
No installs/network, xdist/parallel groups, warnings suppression, skips/xfails,
or altered selectors to manufacture success. Precreate each owned collect/run
basetemp parent. Collection precedes serial execution for every group:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-group-collect> --collect-only <exact-group-paths>

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-group-run> <exact-group-paths>
```

Run all SIX selections below, then complete repository collection AND execution
with NO path selector. No full suite per mutant. First run the full amended
persistence module and its direct boundary controls so an obvious failure is not
deferred to the final suite. An external driver error can be corrected externally
and its affected gates rerun; failed/interrupted attempts retain their dispositions.
Any candidate edit after validation requires new source identity and affected
final validation on that final copy. No guard hash refresh or new permission is
allowed to mask an unforeseen dependency.

### A0_D1

```text
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_offline_integration.py
tests/test_rw0_d1_planner_process.py
tests/test_rw0_d1_process_frames.py
tests/test_rw0_d1_process_supervisor.py
tests/test_rw0_d1_worker_process.py
tests/test_rw0_d1_workspace_capsule.py
```

### BINDING_COMPAT

```text
tests/test_c2b3c_author_effect_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_c2b3d_author_effect_establishment_recovery.py
tests/test_c2b3d_private_atomic_author_effect_establishment.py
tests/test_c2b3d_private_author_effect_delegation.py
tests/test_worker_execution_semantic_relations.py
tests/test_worker_execution_semantic_vectors.py
```

### A_NATIVE

```text
tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_private_readers.py
tests/test_rw0_c1_reader_contracts.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_row_values.py
tests/test_rw0_c1_semantic_values.py
tests/test_rw0_c1_writer_session_delegation.py
tests/test_rw0_d2_bound_effect_contracts.py
tests/test_rw0_d2_bound_effect_persistence.py
tests/test_rw0_d2_c1_checked_readback.py
```

### A_EVIDENCE

```text
tests/test_post_execution_pure_owner_relations.py
tests/test_post_execution_pure_owner_values.py
tests/test_rw0_d2_c1_checked_readback.py
tests/test_rw0_d2_evidence_children.py
tests/test_rw0_d2_process_frames.py
```

### B_MODEL

```text
tests/test_rw0_d2_model_handback.py
tests/test_rw0_d2_offline_integration.py
tests/test_section41_cognitive_proposal_row_values.py
tests/test_section41_cognitive_proposal_semantic_values.py
tests/test_section41_pre_execution_plan_disposition_contracts.py
tests/test_section41_pre_execution_plan_disposition_recovery.py
tests/test_section41_private_atomic_pre_execution_plan_disposition.py
tests/test_section41_private_pre_execution_plan_disposition_delegation.py
```

### GUARDS

```text
tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_b2a_writer_session_contract.py
tests/test_b3a_persistence_contracts.py
tests/test_b3b2a_read_scope_and_query_contracts.py
tests/test_b3b2b_select_readers.py
tests/test_b3c4c_prerequisite_contract.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b2_development_reader_contracts.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_post_execution_pure_owner_boundaries.py
tests/test_post_execution_pure_owner_vectors.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_c2_private_value_versioning_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_sqlite_b1_runtime_boundary.py
tests/test_sqlite_b2c_writer_session.py
tests/test_sqlite_backend_b0_contract.py
```

FULL: no test path for collection or execution. The repository has 131 modules; no new test module is permitted.

### Exact opening module identities

These module hashes have been calculated from baseline source hashes plus the
70 fixed current endpoint receipts, including the two newly supplied V3 receipts.
They are module identities, NOT independently executed V3 node inventories.
Counts below are writer-reported. The auditor independently collected/ran only
the 49-node integration module; it supplied no new full node/inclusion ledger.

| Group | Modules | Reported V3 nodes/passed | Fixed opening MODULE SHA-256 |
|---|---:|---:|---|
| A0_D1 | 7 | 117 | `bd79dcd6261a545b90e3709e7bff2b16fa00d9fb71f67baa4082f71de6b75236` |
| BINDING_COMPAT | 7 | 160 | `0851123786b9bcbab0f2f417539ec3d1a0e6ffc753c4075e3d33b15e27dccd30` |
| A_NATIVE | 11 | 118 | `07f8d2d3b7f971ab76b23f537de7985ed9e5388c5f5f69dc6d5d3b9d995fc22d` |
| A_EVIDENCE | 5 | 659 | `d74195c30fd2f5c9e56591b2365651836ec7c982d0c1fe96da3f1fc26850b1ba` |
| B_MODEL | 8 | 218 | `d00d48fcba4bf4f95bc359c59c57233dc770eafe51957ca40068a46c2c685147` |
| GUARDS | 24 | 4,162 | `4533bd1c1f6ee61c1e96847b3d6ce684af46046304ae9a6df28348eaace2b617` |
| FULL | 131 | 9,084 | `066c92f093831b4744ef25d5ae8992caea59a295ad4b46bf72599072b6543071` |

Only tests/test_rw0_d2_bound_effect_persistence.py may change among tests.
Therefore A_NATIVE and FULL inventories change; A0_D1, BINDING_COMPAT, A_EVIDENCE,
B_MODEL and GUARDS retain their exact module memberships and hashes. All six still
execute after the production writer changes. Recompute actual complete node sets,
module and node hashes on final bytes. Do not invent V3 node hashes from counts.

```text
final full count = 9,084 + (final A_NATIVE count - 118)
```

This is bookkeeping, not a target achieved by deleting tests or changing selectors.
The reported V3 group counts sum to 5,434 occurrences; the inherited two checked-C1
overlaps would give 5,432 distinct IDs and 3,652 FULL-only IDs. Derive final actual
overlap/inclusion from complete collected IDs, not arithmetic assumptions. This
new test belongs to A_NATIVE, not A_EVIDENCE; no new cross-group overlap is intended.
Keep parameter strings, spaces and full node identities intact.

Inventory grammars (no prefix):
- MODULE: paths sorted uniquely by UTF-8 bytes; u32be(path byte length) + path bytes
  + raw 32-byte SHA-256 of module payload.
- NODE: full node IDs sorted/deduplicated by UTF-8 bytes; u32be(ID byte length)
  + exact ID bytes. Never split parameter text on whitespace.

Expected warnings remain only the three existing Python 3.13 multithreaded-fork
DeprecationWarnings in unchanged tests/test_sqlite_b2c_writer_session.py:

```text
test_operation_guard_close_waits_and_retains_authority_until_exit
test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Inspect structured category/message/node/location and actual command completion.
GUARDS and FULL normally show those three; no count-only or suppression claim.
A new warning, collection discrepancy, failure or harness correction must be named.

Before expensive validation, pass tracked diff --check, ALL 23 creation no-index
whitespace checks, strict UTF-8/no BOM/CR/trailing whitespace, selected terminal-LF
form, types/modes, migration/catalog absence and protected inventory checks.
Ordinary no-index differences are not whitespace defects. Do not edit docs or any
protected fixed expected hash to make a source guard pass. An indispensable
unlisted dependency requires a precise stop and retained work.

## 7. Provenance, owned cleanup, and complete operative closeout

Record each normal/controlled copy's full 286-source manifest BEFORE and AFTER
execution: path, regular-file type, OS/Git mode, raw length, SHA-256. A mutant must
have exactly its declared one-file source change and unchanged tests. For optional
full-copy identity use the explicit new framing:

```text
ASCII RW0-D2-STRICT-EXPIRY-REPAIR-V4 followed by NUL
for each source endpoint sorted by UTF-8 relative-path bytes:
  u32be(path byte length) + path bytes + u32be(Git mode)
  + u64be(payload byte length) + raw payload
```

Record OS modes separately. This is not the audit's or V3 repair's different
full-copy framing. Do not claim byte identity from unequal digest grammars.
The HEAD-relative 70-row replacement grammar in section 2 is unchanged.

Every real child and owned fixture/root must be accounted for. Tests may create
SQLite fixtures, links or special files: use lstat, open/hash only regular files,
follow no symlinks, and do not open FIFO/socket/device entries for inventory.
Keep actual handles/groups and cleanup outcomes for produced children; test rescue
is distinct from runtime success. No blanket /tmp sweeps, name-based process kill,
unknown-process signals, deletion of another run, or destructor-only cleanup claim.
Only positively owned roots are removed after checks; verify absence.

At closing reproduce ALL 70 raw replacement rows twice from fresh reads. Confirm
47 M/23 C; 263 unchanged index entries; no new path, staged/unmerged state or live
artifact; 68 unchanged candidate endpoints and 216 other tracked files HEAD-exact.
The two edited paths remain C. Report full final size/SHA/mode for BOTH, even if
one unexpectedly stayed unchanged; state the exact reason. Supply the full final
70-row table OR explicit inherited-table confirmation plus the two complete
replacements. Report payload, encoded and framed byte totals and full aggregate
SHA-256 from both constructions. No abbreviated final hashes or omitted length.

Keep this SAME opening's HEAD/tree/parent/branch/upstream/worktree, index content
AND metadata, guidance, cache directory and all 37 members, protected refs and
other source modes. Apply section 3 only to actual qualified diagnostic deltas;
record old/new values without restoring any ref or replacing the opening snapshot.
No final edit after closing validation/receipts without reidentification and reruns.

Remove the owned scratch/helper root only after its final comparisons and all
child cleanup, then verify removal without additional raw live Git. Retain the
uncommitted repaired candidate on a material stop. No evidence ZIP, database,
new snapshot, repository report file, contract package or user-transport prerequisite
is requested. No asynchronous continuation is promised.

Return operative results INLINE, including:
1. Verdict/settings; correct opening and current baseline/candidate/ref/source,
   index/cache/mode preservation, with scope and limitations.
2. Reproduced pre-edit equality commit and after-expiry refusal, exact actual clock
   seam/values, effect class, result and observed target rows/receipts; no live clock
   or external authority claim. Separate historical auditor report from new execution.
3. Exact two-comparison repair and owning contract/clock/receipt ordering with
   path:line. State expiry containment, masking limits and unchanged error/authority
   semantics. No new policy, writer TTL, schema or grant verification.
4. Permanent real-writer matrix for BOTH classes: strict-before, equal, after;
   equal bounds and valid narrower binding; target six-member/receipt readback or
   absence, preserved predecessor rows, original timestamps and no duplicate writes.
5. Valid pre-expiry family replay and readback-only recovery at/after expiry; actual
   exact selectors/result times and no renewal/second family. Existing negatives.
6. E01/E02 actual transformations, target endpoint and full-copy hashes, full module
   collection, selected complete nodes, positives and precise causal failures;
   any earlier masking, corrected harness trial, or unperformed case explicitly.
7. Full two-file opening/final receipts, all-70 inherited confirmation/replacements,
   complete raw replacement length/SHA twice; exact protected endpoint equality.
8. All six focused and FULL commands, module/node inventories, actual collected/
   passed counts, overlaps/inclusion, structured warnings, interruption history,
   skipped gates, before/after source equality, and owned resources/cleanup.
9. Continuation capsule naming the exact repaired candidate and independent
   A01-A13/source review/validation still required. The new result is not acceptance.

Success token:
`RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT`

This requires strict fresh expiry, real durable boundary tests, preserved historical
replay/recovery, E01/E02 causal proof at its stated scope, complete final validation,
protected preservation and cleanup. It supports only consideration of a NEWLY ISSUED
independent re-audit. No acceptance, stage/commit/push/PR/publication, rank 15,
Section 41 post-execution recording, physical C2, migration, live provider/supplier/
grant, ES/Bridge, deployment or RW0-E permission follows.

Blocked dispositions:
- `RW0_D2_REPAIR_PROVENANCE_BLOCKED`: wrong opening, subject, protected preservation
  or unresolved protected ref use; state expected/actual, never adopt another subject.
- `RW0_D2_STRICT_EXPIRY_REPAIR_REPLAN_REQUIRED`: exact unlisted owner/representation
  dependency prevents this two-file correction; no silent widening or workaround.
- `RW0_D2_STRICT_EXPIRY_REPAIR_VALIDATION_BLOCKED`: implementation, causal, validation
  or cleanup obligation not met; list failures/omissions without claiming READY.

The latest independent audit proved this material expiry defect and the exact V3
subject. It passed 49 integration tests and traced selected handback code, but did
not complete independent X01/X02/R01/J01/J02, C10, the full A01-A13 ledger or final
six-group/FULL execution. Neither old writer passes nor this narrow repair supply
those missing independent proofs. Do not claim restored full authority or product
readiness from a timestamp fix or a passing test count.
