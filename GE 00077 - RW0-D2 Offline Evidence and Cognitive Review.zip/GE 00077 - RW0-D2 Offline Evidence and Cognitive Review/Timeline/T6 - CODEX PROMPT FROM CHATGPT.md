Use the attached `GE 00077 - RW0-D2/Generated/Coordinator_RW0_D2_Bound_Effects_and_Preadmission_Proposal_Map_Completion_Prompt.txt` as the complete
instruction, subject to the clarification below.

This is the final broad read-only mapping pass for D2. Do not force the selected
capability into one mutation tranche merely to preserve the current label.

If repository inspection establishes that one integrated D2 tranche is
coherent, bounded, and independently auditable, recommend it.

If the capability is coherent but one tranche would combine too many distinct
durable writers, process owners, evidence producers, or failure domains, return
RW0_D2_IMPLEMENTATION_MAP_REPLAN_REQUIRED with one exact ordered split into
source-bearing implementation increments.

The preferred split to evaluate is:

D2A — offline evidence closure:
- guarded validation and review effect establishment;
- actual separate validator and independent-reviewer processes;
- required C1 evidence admissions and exact readback;
- one typed admitted evidence bundle suitable for the frozen model-input
  contracts.

D2B — cognitive-review handback:
- exact nine-role model-input construction from D2A evidence;
- one deterministic fake review-model process;
- canonical transient source/artifact/proposal values;
- one typed preadmission handback.

A selected split must:
- preserve the capsule as the D1/D2 boundary;
- preserve the existing Coordinator program, author-effect, Section 41
  pre-execution selection, and C1 authority paths;
- give each increment a reusable observable result;
- introduce no standalone docs-only or semantic-only tranche;
- introduce no shadow program, evidence, proposal, or decision truth;
- leave durable post-execution Section 41 proposal-family recording, C1 rank-15
  admission, complete C2 decision inputs, physical C2 decision persistence,
  terminal outcome, and migration 0005 outside D2;
- preserve the eventual D2 message-bus-free result.

Do not split merely because the implementation is large. Split only when the
writer, process, evidence, or audit boundaries support independently useful
increments.

Conversely, do not recommend one integrated tranche merely because all stages
belong to D2.

The completed map must identify the exact first source-bearing implementation
prompt boundary. No third broad reconnaissance pass follows this one.

Use the highest available reasoning setting and report the visible setting when
available. Return the complete operative result inline.
