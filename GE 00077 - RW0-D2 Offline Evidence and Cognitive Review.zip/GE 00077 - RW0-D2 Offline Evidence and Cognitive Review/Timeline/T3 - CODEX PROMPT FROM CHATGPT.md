# RW0-D2 — Read-Only Implementation Map: Explicit Restart 01

## NEXT PROTECTED TOOL ACTION — workdir /, plain guidance read only

Use tool workdir `/` and execute only this command before any repository
reconnaissance, Git command, `.docs/` listing, or settings discovery that accesses
the repository:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

Read the complete output. If truncated, use further plain-file reads for the
remainder. Then execute the EXISTING filesystem-only opener in section 1 of the
retained mandate below, before the first Git command. Use its actual emitted
helper for all subsequent live Git inspections. Do not invent another helper.

Plain-data reading of this externally supplied prompt/attachment is permitted
preparation under the retained mandate's conditions. Prefer neutral cwd and an
absolute external path. This exception permits no Git/index operation, repository
content/import/script access, `.docs/` listing, product-state access or mutation.
It cannot excuse a real pre-opening `git status`.

## New interval and sole routing amendment

The cognitive lead authorizes ONE NEW read-only D2 mapping interval in a FRESH,
MAPPING-ONLY, parent Codex conversation. Do not resume the D1 implementation thread
for this pass and do not spawn a subagent. This routing supersedes ONLY the
retained mandate's direction to use the Coordinator implementation conversation.
The same repository, exact baseline, source questions, output requirements,
read-only limits, and lead-review-before-implementation rule remain in force.

The preceding mapping attempt actually ran `git status --short` and listed
`.docs/` before guidance and the opening record. It reported no source inspection,
tests, edits or implementation map and created no opening helper. Its BLOCKED
verdict stands. It establishes neither a D2 architecture conflict nor a complete
preservation interval. Do not claim its index/cache metadata were preserved or
changed; that interval was not measured.

This restart does not restore missing metadata or retroactively satisfy the old
order. Do not reset the index, restore timestamps, recreate merged D1, request a
new snapshot merely for this procedural miss, or reinterpret it as a D2 replan.
Current fixed coordinates must still authenticate in the new interval; drift is
a stop, not permission to adopt another baseline.

Changing the conversation is an execution-context mitigation, NOT an OS-level
interlock or guarantee. The helper checks commands routed through it and cannot
prevent an earlier raw command. Perform the required opening. If a real protected
action again occurs first, stop immediately before further inspection, tests,
clones or edits; do not silently create another interval.

After successful opening and baseline authentication, complete the ENTIRE
implementation-oriented map without a new user approval. Do not return an
opening-only result, run tests/collection, execute a child, contact a network,
create a source candidate, write an architecture package, or issue the D2
implementation prompt. Proposed validation commands remain output only.

The fixed target remains:

```text
repository: /Users/ds/Repositories/Governed Execution Coordinator
branch: trunk_dev
HEAD: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
tree: cc3cc104300f553ada581cee24e80dab6dd885b1
sole parent: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
263 tracked leaves; clean index/worktree; local tracking divergence 0/0
```

These are fixed conditions to verify, not observations supplied by the failed
attempt. Local tracking equality does not establish fresh remote truth; network
access remains prohibited.

The complete original mandate follows BYTE-FOR-BYTE. Its first-action and
opening instructions refer to THIS SAME new interval. Read them before acting;
do not run the opener twice when reaching the reproduced heading. This prefix
adds no new mapping question, assurance requirement, mutation permission or
user handoff. It makes no implementation or test-execution claim.

Retained mandate identity:
47,433 bytes
SHA-256: 4ed82a7ddd8acc6fa1685e0ad6fc2b968db550ee068158f12f96e862b1fa68a7

--- BEGIN UNCHANGED D2 IMPLEMENTATION-MAP MANDATE ---

# Governed Execution Coordinator — RW0-D2 Read-Only Implementation Map
# One offline implementation program; D1 merged; D2 before physical C2

## 0. Mandate and next protected action

Perform ONE bounded, implementation-oriented, READ-ONLY mapping pass for:

RW0-D2 — offline evidence and cognitive-review closure.

Use the Coordinator implementation conversation, with the parent as sole mapper.
No subagent, other model session, provider, or worker may be invoked. Report the
visible model, reasoning setting and permission posture, or `not visible`;
seeking extra account/computer access to expose those settings is not authorized.

The next protected repository action must read live AGENTS.md as plain text,
using tool workdir `/`:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

Read its complete output, with further plain-text reads if truncated. Then run
section 1's filesystem-only opener before ANY Git command, repository import,
script, test or probe. Do not start with git status or Git-backed reconnaissance.

Reading this external instruction/attachment as plain data is permitted
preparation. Prefer absolute external paths and neutral cwd. A repository cwd
alone is not evidence of a Git/index operation. That allowance does not permit
repository content/import/script access, product-state reads or mutations before
guidance/opening. Assess actual operations, not guessed shell startup effects.
A real pre-opening protected action requires a stop; never reset metadata or
silently replace the opening record.

After opening and baseline authentication, complete the map without another
user approval. Return operative findings INLINE. Do not write a repository file,
architecture package, freeze manifest, report, snapshot, patch, schema, migration,
proof artifact, implementation script or test. Only the temporary external
opening helper/record and bounded inert inspection scratch needed to protect
read-only work are permitted; remove them after closing comparisons.

This is NOT an implementation authorization and NOT another semantic-contract
tranche. Do not implement even an apparently obvious helper during the map.
The cognitive lead will review the map before issuing a D2 mutation prompt.

## 1. Exact merged baseline and preservation

Repository:
`/Users/ds/Repositories/Governed Execution Coordinator`

Required current local coordinates:

```text
branch: trunk_dev
HEAD: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
tree: cc3cc104300f553ada581cee24e80dab6dd885b1
sole parent: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
subject: feat: add RW0-D1 offline process and capsule spine
upstream: origin/trunk_dev
local tracking ref: same squash HEAD
local divergence: 0 ahead / 0 behind
worktrees: one
index/worktree: clean, all 263 tracked leaves equal HEAD
staged, unmerged and untracked paths: none
active Git operation/sequencer/unexpected lock: none
migration resources: exactly 0001–0004; no 0005
```

The supplied snapshot has 263 source leaves and reconstructs the same exact tree.
Its ZIP is named `Governed Execution Coordinator - Snapshot - 2026-10-16.zip`,
3,134,667 bytes, SHA-256
`06d981b6100fc1d6ad9792aff35800eb0772b8d35f708ed030177967ccb9c40e`.
The filename's date is not a claim that the source predates D1. Archive tree
identity is snapshot-backed; the squash/branch facts came from the merge report
and must be checked locally here. No archive attachment is needed by this mapper.

Do not fetch or contact GitHub. Local tracking equality is not fresh remote
truth. Do not demand the pre-squash source HEAD or recreate the 46-file candidate:
all 263 leaves are now tracked. PR #14's source commit remains historical
`f0e3169c55fad62d8d830d9fc799263d7c5332f1`; no manipulation of it is needed.

Preserve all actual OS modes, including the existing nonexecuting 0600
program-initialization test. The 37 live bytecode files are opaque preservation
material, not source or code to import. No ignored database, secret, credential,
TLS/Vault/OpenAI/Codex state, host configuration or sibling repository is in scope.

### Existing pre-Git mechanism

After the guidance read, run this data-only block from `/`. It reads no product
state, runs no Git and imports no repository module. Its only writes are under
its newly created external root. It preserves index/cache contents and metadata.
This is inspection instrumentation, not run truth, a product receipt or an OS
interlock against commands issued outside it.

```sh
python3 -I -B -S - <<'PY_OPEN'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env


import datetime
import shutil
import tempfile

guarded_environment()
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_not_exact_audited_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_unavailable')
gate_root = Path(tempfile.mkdtemp(prefix='rw0-d2-readonly-map-'))
os.chmod(gate_root, 0o700)
print('GATE_OWNED_ROOT=' + str(gate_root), flush=True)
record = {
    'schema': 'rw0-d2-readonly-map-opening-observation',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents, 'index_path': str(index),
    'index': index_before, 'cache': cache_before, 'git_executable': git,
    'git_environment': GUARDS,
    'limit': 'This mapping interval only. All repository bytes, refs, index and cache stay fixed. No repository or remote mutation is authorized.'
}
READ_HELPER = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\n\nimport subprocess\nimport sys\nopening = json.loads(Path(__file__).with_name('opening.json').read_text(encoding='utf-8'))\n\ndef immutable_checks():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('map_index_content_or_metadata_drift')\n    if regular_record(REPO / 'AGENTS.md')['sha256'] != AGENTS_SHA:\n        raise RuntimeError('candidate_guidance_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n\nimmutable_checks()\nindex_before_read = regular_record(index_path())\nargs = sys.argv[1:]\nif args == ['--check']:\n    print('READ_HELPER_IMMUTABLE_SURFACES_MATCH')\n    print('CURRENT_INDEX_SHA256=' + index_before_read['sha256'])\n    print('Index content and metadata equal this mapping opening; no stage or index write is permitted.')\n    raise SystemExit(0)\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree',\n           'check-attr', 'for-each-ref', 'reflog'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_read_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'], ['--quiet', 'HEAD']):\n    raise RuntimeError('readonly_head_query_only')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('readonly_worktree_list_only')\nif args[0] == 'reflog' and (len(args) < 2 or args[1] != 'show'):\n    raise RuntimeError('readonly_reflog_show_only')\nfor arg in args[1:]:\n    if arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec') or arg.startswith(('--output=', '--exec=')):\n        raise RuntimeError('unapproved_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager', '-c', 'core.fsmonitor=false',\n           '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=guarded_environment(), check=False)\nfinally:\n    immutable_checks()\n    if regular_record(index_path()) != index_before_read:\n        raise RuntimeError('index_changed_during_read_command')\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(payload)

try:
    write_private(gate_root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(gate_root / 'live_read.py', READ_HELPER.encode())
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_first_git')
    print('OPENING_RECORD=' + str(gate_root / 'opening.json'))
    print('LIVE_READ_HELPER=' + str(gate_root / 'live_read.py'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D2_MAP_PRE_GIT_OPENING_RECORDED')
except BaseException:
    for name in ('opening.json', 'live_read.py'):
        p = gate_root / name
        if p.exists():
            if not stat.S_ISREG(p.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            p.unlink()
    gate_root.rmdir()
    raise
PY_OPEN
```

Use the ACTUAL emitted helper and root paths; do not assume shell variables
persist or guess a temporary path. Every live Git inspection uses that helper:

```sh
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> rev-parse HEAD
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> status --short --untracked-files=all
```

The helper performs command-local optional-lock, lazy-fetch and prompt
suppression. No Git WRITE, including write-tree, is authorized. Verify tree and
index equality by reading stage-0 entries and blobs, not by refreshing the index.
Read every tracked payload against its HEAD blob and preserve opening/closing
index content AND metadata and cache directory/member metadata. Complete-tree
identity is sufficient for this map; do not create another candidate manifest.

Allowed analysis: text reads, read-only Git object/ref/status inventory, hashes,
and standard-library AST/JSON/TOML/SQL-text inspection as inert data. Do not import
modules, construct repository value objects, call a reducer, open SQLite, run
pytest (including collection), compile repository code, launch any child/fake,
clone/check out another tree, install a package, or run repository scripts.
A source-level prediction must not be reported as an executed result.

Give one concise opening acknowledgment, then proceed. A fixed-baseline mismatch
ends the map before recommending implementation against a different subject.

## 2. Fixed product direction and observable D2 result

The selected sequence is D1 -> D2 -> physical RW0-C2. D1 is merged. Do not run D2
and physical C2 as concurrent implementation programs, split D2 into new user-
relayed programs, or insert another standalone contract/value/envelope tranche.
An ordinary clarification can accompany later source work. A genuinely unsafe
contract contradiction must be named with its owner and consequence.

D2 must extend the accepted offline program from:

```text
D1 capsule + immutable before/after bytes + actual committed lineage
+ same-creator-process parent-only disposable-state owner
  -> process-separated validator
  -> process-separated independent reviewer
  -> process-separated deterministic fake semantic-review model
  -> typed post-execution proposal/evidence
  -> final handback compatible with the frozen RW0-C2 input vocabulary
```

One bounded parent invocation must compose D1 and D2 without the user copying
messages or artifacts between stages. D2 may also expose a private composition
entry accepting the existing D1 run owner in that same parent process; propose
one exact ownership/API arrangement rather than returning alternatives to the
user. No new public intent grammar, CLI, service, queue, scheduler or daemon.
The initial program/WorkSpec and artificial three-path fixture remain D1's
accepted private input, not a new natural-language product API.

D2 must demonstrate distinct evidence authors, exact-capsule binding, real
bounded verification/review work on the reconstruction, fake-model invocation,
and typed positive/repair/replan/reject/block proposals plus cancellation,
timeout, malformed/unavailable-result handling where applicable. Preserve the
existing literal vocabularies and distinguish process stop from a model proposal,
C2 decision, acceptance fact or RW0 terminal outcome. Do not invent a new model
`cancel` recommendation if the supplied schema does not admit one.

The fake review model is deterministic offline machinery, not a live provider
or a claim of competent semantic judgment. Validator and reviewer should perform
finite real checks over the artificial candidate/evidence, not simply copy a
caller-provided `passed` flag. Negative fixture modes exercise boundaries; they
must not become independent evidence of genuine correctness or policy authority.
The reviewer is a distinct role/invocation with no author write authority; a
separate PID alone is not sufficient semantic separation evidence.

Do not implement repair/replan/retry loops or launch a new coding attempt. A
repair/replan proposal is a typed handback, not authorization to execute it.
Cancellation is bounded D2 process control/evidence; the live RW0 cancellation
decision/effect/terminal protocol remains outside this proof.

Exact nonclaims remain: no durable C2 decision/version/head family, no scope-
admission provisioning, acceptance fact, terminal outcome, migration 0005,
public export/entry point, Git operation/publication, live source verification,
provider/credentials, privileged custody supplier, restore/handoff support,
ES/Bridge integration or RW0-E. Disposable existing C1 evidence admission is not
a C2 decision. A process result, model output, report or hash is not permission.

## 3. Snapshot-backed findings to verify, not assume away

Read current local bytes before adopting any pointer below. These are starting
findings from inert snapshot inspection, not executed D2 proofs:

1. `.docs/rw0-d1-offline-process-and-capsule-spine.md:7–29,41–68` and
   `_rw0_d1_handback.py:105–245,252–309` bind the path-free typed handback and a
   distinct creator-PID-fenced state owner. D1 removes its mutable workspace;
   D2 gets immutable capture/manifest, not that workspace. `.location` is parent
   custody access; it is not child input. The owner retains no open writer.
2. `_rw0_d1_process_supervisor.py:20–23,142–178` admits exactly the fake planner
   and fake worker. It is NOT already a general child launcher. It has bounded
   input/output/deadline behavior and a fixed seven-key environment. D2's three
   child roles need an explicit, narrowly coupled extension and guard changes.
3. C1 has private `_admit_rw0_evidence` and explicit evidence-admission recovery
   delegates in `sqlite_writer_session.py:6450–6469`, with exactly fifteen kinds
   and dependency-closed partial admission. See `.docs/rw0-c1-durable-evidence.md:
   51–109,162–244`. C1 admission proves neither completeness nor source authenticity.
4. Rank 15 consumes ALREADY EXISTING Section 41 source-invocation, artifact,
   proposal and evidence rows. `_sqlite_rw0_c1.py:2062–2076` reads them;
   `.docs/rw0-c1-durable-evidence.md:93–102` pins the owner relation. The current
   pre-execution writer validates `proposal_phase == pre_execution_plan`
   (`_sqlite_development_pre_execution_plan_disposition.py:435–500`). Do not
   assume it writes a post-execution family because the physical tables exist.
5. `section41_post_execution_proposal_family_projection(...)` requires typed
   owner rows, exact reader tuples, locators, rank-15 value/relation/graph/
   membership, and admitted-by identity; its complete projection requires nine
   evidence rows (`_section41_post_execution_proposal_family_projection.py:
   475–647,672–676`). Existing tests construct golden owner rows and memberships
   in memory (`tests/test_post_execution_pure_owner_relations.py:83–158`). Those
   tests do not establish a runtime writer for those facts.
6. `_rw0_c_decision_input_values.py:1–5` is pure supplied-input vocabulary, not a
   decision writer. Some helpers consume an ALREADY DERIVED authoritative branch
   (`evaluate_rw0_c_recommendation_consistency`, :1748–1765). A fake review-model
   recommendation or harness flag must not become that branch by convenience.
7. `tests/test_post_execution_pure_owner_boundaries.py:223–273,286–326` enforces
   no current runtime consumers and absence of `_rw0_d2*.py`. Its six-module
   allocation, allowed import DAG and machine-record projections are coupled.
   B1, Wire, Capability, package/runtime and scoped-C2 guards also bind exact
   consumers, source inventory and private entry points. Do not evade them by
   file naming, import indirection, aliases or dynamically derived expectations.

The scope-admission/continuity target and first-live profile do NOT block
repeatable disposable offline engineering merely because their live supplier
is unimplemented. But this proof must never label synthetic currentness or a
locally reconstructed fixture as qualified live authority.

## 4. Critical mapping questions — resolve before file selection

### A. Exact D1 input, custody and orchestration arrangement

Trace actual fields and constructors from `run_rw0_d1_offline` to the ready
handback/run owner. List which original WorkSpec/fixture/context values must be
retained privately by the parent in addition to the handback; do not assume the
handback contains every source body. Define one private D2 input and return
shape using the existing types wherever possible.

Map normal, stopped, cleanup-unresolved, wrong-PID and already-closed D1 inputs.
No D2 child may start from a non-ready D1 handback or unproved cleanup. State who
owns the run's lifetime while D2 is active and after final handback, including
idempotent close, cancellation and exceptions. Use the same creator process;
no IPC transfer or serialization of the run/location/writer. Retain no live
writer/connection/lock across child execution. No destructor-owned authority.

D1's SQLite program/head, author effect, Section 41 selection and C1 phase remain
the sole existing lifecycle. The orchestrator's local variables and D2 output
are projections, not a second durable or in-memory progression authority.

### B. Three real child roles, one supervisor, bounded reconstruction

Default strategy: extend the EXISTING sole supervisor to an exact closed set
including the three D2 children. Preserve D1's allowlist entries and behavior.
Do not rename/extract it into a generic executor or build a second subprocess
owner merely for naming aesthetics. If a neutral extraction is materially
necessary, identify the concrete import/purity conflict and full migration/test
impact before recommending it.

Recommend exact source placement, package-private child invocation method and
closed frames. Reuse safe framing primitives without reinterpreting D1O1/D1W1
or existing NWPF semantics. Determine which existing WorkerCommandV1, Wire,
observation and result grammars actually fit validator/reviewer roles. Do not
claim an author command bases a validate/review delivery when it does not.

Each validator/reviewer consumes an exact original-base-plus-capsule
reconstruction in its own read-only or separately isolated workspace. Bind the
observed bytes/modes/digests and detect forbidden changes. The fake review model
receives bounded evidence/private input through stdin, never database, writer,
lock, custody handles, credentials, opaque metadata bags or ambient environment.
Do not turn advisory same-UID file modes into an adversarial sandbox claim.

Map child arguments, stdin, bounded stdout/stderr, cwd, environment, inherited
FDs, per-stage deadline and cancellation, failure and result parsing, actual
Popen-level observation, TERM/KILL/reap/group-clear, workspace cleanup and error
precedence. Distinguish a failed start, valid negative result, malformed result,
process exit and cleanup uncertainty. A zero exit cannot rescue bad evidence.
Recommend safe aggregate frame/byte bounds from actual D1 capture limits rather
than widening everything or silently truncating evidence to fit.

### C. Evidence authorship, nine-role supply and proposal causality

For each required post-execution input, map:

```text
semantic role -> exact class/schema/version -> observed/fake source author
-> actual immutable input -> constructor/validator -> parent binding
-> C1 rank/dependency or other current owner -> final proposal/handback consumer
```

Include actual validation and review result sets/dispositions, reviewer
separation, capsule projection, support sets, model-input safe projection and
private manifest, policy/risk/effect-ceiling/global-stop/currentness sources,
model source invocation/artifact/proposal and the exact role supply. Select only
what the existing contracts require; do not force all 44 types through every
failure branch. Explicitly map legitimately absent and nonconclusive evidence.

Keep validator, reviewer, fake model and parent process-observation authors
separate. Parent assigns structural correlations where current contracts assign
them; it cannot fabricate successful child observations. Typed fake authority
sources must be separately identified as proof fixtures and bound to the actual
run coordinates; fixture equality, hashes, a PID or clock alone do not prove
source authenticity. No per-command user approval or user evidence relay.

The model's proposal must depend on the validator/reviewer/capsule context and
use the frozen five recommendation semantics. Its response is not the result of
a C2 decision reducer. Identify which pure constructors validate an expected
assertion rather than derive a result; parent construction must not use expected
fixture output as its own independent correctness oracle.

### D. Resolve the physical/preadmission seam explicitly

Do this before claiming the complete D2 end-to-end map is safe:

1. Derive the exact dependency order for needed C1 evidence from the real D1
   outputs and separately fake source inputs. Distinguish records already in
   SQLite from values merely retained in the D1 handback. Do not require every
   rank regardless of outcome; preserve C1's dependency-closed partial phases.
2. Locate current producers/guarded writers for validator/reviewer effect/fence/
   initial-delivery facts wherever the consumed C2A/C1 relation requires them.
   The live RW0 timeline calls for distinct validate_candidate/review_candidate
   effects; current bound-effect persistence is not proven merely by its target
   schema. Identify the exact offline exception, existing current writer, or
   missing owner—do not invent a committed effect from a test fixture.
3. Locate the actual insertion/receipt/replay path for the Section 41
   post-execution source/artifact/proposal/evidence family needed before rank-15
   admission. Reading an existing family and constructing a row value are not
   its writer. Identify every required predecessor and any circular dependency.
4. For C1-backed evidence use the current guarded admission/recovery methods and
   read-only readers, with real results and locators. Do not directly seed rows,
   use raw SQL from orchestration, import test builders, copy golden memberships,
   change a digest to fit, or claim admission from a constructed tuple.
5. Determine the narrowest truthful final handback cut. Name the exact existing
   proposal/evidence classes delivered and every later C2 argument they satisfy.
   Distinguish a typed preadmission proposal from an actually admitted Section 41
   projection and from a complete decision-time C2 input. Do not call the first
   the second; do not call `evaluate_rw0_c_recommendation_consistency` with a
   model-selected/harness-supplied authoritative branch to fake compatibility.

The selected target is C2-compatible evidence and proposal with no semantic
translation, NOT execution of the C2 reducer, acceptance or terminal writer.
That does not permit a vague 'can be converted later' claim: provide the exact
field/type/identity mapping and the owner-supplied values still legitimately
required at decision time. A bounded representation adapter cannot supply a
missing authority fact or change source authorship.

If new source-bearing evidence-recording glue is indispensable, identify the
smallest existing-owner extension, its exact tables/callers/receipts/recovery
and invariant changes, and whether it remains within the intended D2 evidence
slice. A proposal/evidence writer is not automatically a C2 decision writer,
but it is also not automatically authorized merely because the table exists.
Recommend a concrete disposition for lead review. Do not implement it, hide it
inside an offline harness, or commission a standalone contract prelude.

If satisfying the requested output would really require physical C2, migration
0005, a new authoritative program lifecycle, widened C1 inventory/authority,
unreviewed effect issuance or live contact, report a concrete replan boundary.
Do not preserve the appearance of progress by manufacturing durable evidence.

## 5. Existing source, contracts and tests to inspect together

Read live guidance first. Then read the following owners in their relevant
current-status and semantic sections, following exact cross references. There is
no root PLANS.md in this snapshot; D1's artificial `PLANS.md` is fixture content,
not the Coordinator's governing plan. Do not substitute an ES plan or old chat
sequencing. Inspect any newly present governing plan only if baseline checks
explain it; fixed HEAD/tree drift is a stop.

### Governing documents

```text
.docs/rw0-d1-offline-process-and-capsule-spine.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/worker-execution-boundary.md
.docs/autonomous-software-development-operating-model.md
.docs/architecture.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
.docs/c2b-durable-development-state.md
.docs/c2a-first-slice-semantic-protocol-contract.md
.docs/c2a1-pure-semantic-values.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-b2-capability.md
.docs/rw0-c1-durable-evidence.md
.docs/rw0-c2-durable-progression-decision-semantic-contract.md
.docs/rw0-c2-private-value-versioning.md
.docs/rw0-c2-first-live-proof-posture.md
.docs/rw0-c2-scope-admission-provisioning-contract.md
```

Read the D1 owner and needed C1 sections in full. In the large durable-state
owner, focus on Sections 38–42 and post-execution/context/evidence/machine-registry
records actually constraining D2; do not print or restudy an unrelated megabyte
ledger. Preserve normative machine blocks and exact schema IDs unless the map
identifies a concrete required owner amendment for later review.

### Production paths

Inspect all nine `_rw0_d1_*.py` modules and the seven D1 tests. Trace constructors,
callers and actual source dependencies in:

```text
_worker_execution_semantic_values.py
_rw0_phase_entry_semantic_values.py
_rw0_wire_protocol_values.py
_rw0_worker_mechanism_capability_values.py
_post_execution_evidence_values.py
_post_execution_policy_values.py
_finite_backlog_risk_source_adapter.py
_section41_post_execution_proposal_family_projection.py
_section41_post_execution_role_resolution.py
_rw0_c_decision_input_values.py
_cognitive_proposal_semantic_values.py
_cognitive_proposal_row_values.py
_development_program_initialization_contracts.py
_development_author_effect_establishment_contracts.py
_development_pre_execution_plan_disposition_contracts.py
_sqlite_development_program_initialization.py
_sqlite_development_author_effect_establishment.py
_sqlite_development_pre_execution_plan_disposition.py
_rw0_c1_semantic_values.py
_rw0_c1_mutation_contracts.py
_rw0_c1_row_values.py
_sqlite_rw0_c1.py
_sqlite_rw0_c1_reader_contracts.py
_sqlite_rw0_c1_readers.py
sqlite_writer_session.py
sqlite_location.py
state_authority_lock.py
```

Paths above are under `src/ge_nwp_coordinator/`. For large files follow the
specific constructors, delegates, readers, row factories and transaction/replay
owners needed by the map; state the inspected boundaries. No execution/import.
The six post-execution pure modules must remain pure; new I/O belongs in an
explicit runtime owner, not silently inside a validator/evaluator.

### Tests, configuration and resources

Inspect these families and actual source-guard callers, not only name inventories:

```text
tests/test_rw0_d1_*.py
tests/test_post_execution_pure_owner_*.py
tests/test_section41*.py
tests/test_rw0_c1*.py
tests/test_worker_execution_semantic_*.py
tests/test_rw0_b1_*.py
tests/test_rw0_b2_wire_*.py
tests/test_rw0_b2_capability_*.py
tests/test_rw0_c2_*contract.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_software_development_progression_boundary.py
tests/test_c2b0_durable_state_contract.py
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_b1_runtime_boundary.py
tests/test_b2a_writer_session_contract.py
tests/test_b3a_persistence_contracts.py
tests/test_sqlite_b2c_writer_session.py
pyproject.toml
src/ge_nwp_coordinator/__init__.py
src/ge_nwp_coordinator/sqlite_migrations/0001_initial.sql
src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql
src/ge_nwp_coordinator/sqlite_migrations/0003_cognitive_proposal_and_selection_state.sql
src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql
schemas/sqlite/coordinator-state-v1.sql
.codex/agents/nwp-coordinator-boundary-auditor.toml
```

Read script/config/example/fixture/artifact inventories as data and follow any
that the selected path really consumes. Do not run a configured agent, script,
SQL file or fixture. Existing pure-test golden rows and seed helpers demonstrate
value contracts, not a runtime authority path to import into production.

## 6. Complete prospective touched-surface closure

Do not repeat D1's incomplete mutation-ceiling cycle. Before recommending an
implementation boundary, statically search the complete tracked source/tests/
.docs/config set for the affected module names, consumer registries, status
blocks, exact file inventories, hashes, executable-entry restrictions and test
helpers projecting them. Include constant/machine-record ownership, not merely
literal `subprocess` searches.

For each proposed runtime import or new child, identify:

- exact source file and imported class/function;
- direct owner contract and independent consumer/shape guard;
- permitted role (constructor, evidence holder, relation caller, process owner);
- no-I/O restrictions that remain in supplying pure modules;
- all synchronized document/status projections and their independent tests;
- any complete-byte identity guard affected by truthful status changes.

Specifically close the already known dependencies:

1. Post-execution six-module allocations/DAG and no-production-caller records,
   including the owning machine data imported by their tests.
2. B1 version-3 constructor/evidence consumer registry and independently fixed
   phase-entry projection; no extra symbols or aliases by indirection.
3. Wire/Capability exact consumers, fake executable guards and source inventories.
4. Exactly one subprocess owner and every historical whole-source runtime guard.
5. Current D1 status blocks across guidance/docs and the five normalized
   Capability status projections.
6. Protected AGENTS/README content rows and independent bootstrap replacement
   expectations, including the new single-literal-binding protections. If D2
   status changes these files, map all literal identity updates together; never
   derive expected hashes dynamically from the documents being checked.
7. Scoped C2 nonimplementation guards: distinguish legitimate D2 pure-input
   consumers from forbidden C2 decision/acceptance/terminal/migration runtime.
   Do not restore a blanket no-source rule or remove scoped protection wholesale.
8. Any source digest/schema/migration/table constraints reached by the proposed
   evidence-recording path. Broad representation changes are not implied by
   choosing an offline proof.

Return a recommended exact path list, not a menu. For each path give create or
modify, minimal responsibility, coupled owner/test, and why needed. Separately
list protected untouched surfaces. Paths discovered in this read-only map are
PROPOSED for a later reviewed ceiling, not authorized edits now.

Do not label every stale status assertion an architectural contradiction. A
narrow truthful status/consumer update belongs with its implementation. A real
contract clash means the required source behavior would violate an owning
invariant or require an unselected authority/effect, not merely change an old
file count. Explain that distinction in each finding.

## 7. Implementation sequence, acceptance evidence and audit order

Recommend ONE source-bearing D2 tranche with dependency checkpoints inside it:
first safe D1 composition and evidence producers, then the fake review model
and exact final projection/handback, then integrated fault/regression evidence.
Select the exact internal order from the map; do not create D2a/D2b publication
programs, separate approvals, premature status claims, or parallel physical-C2
work. If the minimum safe sequence cannot fit the selected capability, explain
one concrete product/authority boundary for lead review rather than silently
splitting work or asking the user to choose ordinary mechanics.

Specify the exact later private call graph, existing methods used, proposed
new functions/modules, deterministic fixture behavior, and preservation checkpoints.
No implementation now. Recommended validation commands are OUTPUT ONLY.

Acceptance should observe actual effects rather than only returned values:

- one parent invocation, no user relay, no extra worker attempt or duplicate
  durable family;
- separate validator/reviewer/model process attempts/PIDs through the sole real
  supervisor call site, with correct ordering and current writer-close gates;
- each real child's original argv/env/cwd/stdin/FD boundary, including the actual
  parent database/state root exclusion; unrelated direct fixtures are not enough;
- independent candidate reconstruction/verification BEFORE evidence or proposal
  readiness, with genuine refusal respected;
- exact capsule/command/fence/invocation/requirement binding and actual independent
  reviewer separation, not an author observation relabeled as reviewer;
- valid negative, missing/not-run, malformed, stale, contradictory and rejected
  observations distinct from zero exit and success;
- typed model proposal depends on its bound evidence and does not select a durable
  C2 decision; no fabricated currentness or standing grant;
- closed nested handback content, no live resource or DB path, consistent stage
  facts, wrong-PID/closed-run refusal and idempotent explicit custody cleanup;
- timeout/cancellation, TERM/KILL/reap/group clear and exceptional cleanup,
  including unreported children and audit-rescue versus runtime-cleanup distinction;
- real C1 admission/replay/readback where actually used; response-loss unresolved
  forbids the next dependent action; no SQL seed/golden-membership shortcut;
- exact mapping to the selected frozen C2 vocabulary, without constructor checks
  being mistaken for durable admission or later completeness/currentness;
- unchanged D1 happy/failure/recovery/capsule/child-input controls and scoped
  B1/Wire/Capability/C2 boundaries remain causally effective.

Choose a SMALL finite initial negative-copy set tied to those actual seams.
Include missing invocation, fabricated or cross-bound evidence, swapped/reused
reviewer, skipped verifier, stale/ignored result, hidden child launch, leaked
parent-state input and lost cleanup only where the implementation really exposes
those paths. A normal passing suite, count-only observer, or unrelated guard
failure cannot substitute for the target causal evidence. Do not invent a large
unbounded mutation quota or repeat a full suite per mutant.

Map direct test nodes/fixtures that can be extended and new modules needed. Give
exact proposed focused selectors and their owning reason, followed by one normal
full-suite collection and execution under the existing external-clone posture:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-root> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<precreated-owned-path> [--collect-only] <exact-later-selectors>
```

Do NOT execute these commands in the map. Baseline accepted validation was
9,005 tests in 124 modules with three specified writer-session fork warnings;
those are prior observations, not this map's result and not frozen D2 counts.
Installed runtime/dependency compatibility is for the later source/validation
gate; do not install, launch probes or recollect to resolve ordinary mapping.

Audit order: source and integrated D2 evidence -> exact uncommitted candidate
independent review -> separate publication/integration -> refreshed baseline ->
physical C2. Coordinate owning docs and contract/assurance tests inside source
work, never patch around them or claim target semantics are already runtime.

## 8. Required inline result and stop criteria

Return an operative map, not an architecture package or another prompt. Use
exact repository-relative path:line citations for material claims. Keep a clear
separation among current contract/invariant, implemented owner, bounded proof,
compatibility edge, stale/status guard, newly proposed source, open authority
seam and inference. Normal source decomposition is not a replan.

Return these concrete results:

1. Opening/closing coordinates and preservation; exact areas inspected and where
   inspection stopped. No claim of tests or execution.
2. Minimum end-to-end D2 observable result and exact nonclaims.
3. Recommended private entry/return/custody arrangement and actual D1->D2 call
   graph, including each writer/close/child/reconstruction/evidence boundary.
4. Evidence/constructor/consumer mapping, distinct authors and finite outcome
   handling, with the exact frozen vocabulary endpoint selected.
5. Explicit disposition of bound-effect provenance, rank-15/Section 41 owner-row
   production, C1 admission and any missing persistence entry. State whether the
   plan truly reaches the promised output without shadow facts or physical C2.
6. Exact prospective create/modify/untouched table and full coupled guard/owner
   closure. Identify the minimal new runtime pieces; do not return file choices
   to the user or request another broad recon by default.
7. One integrated implementation sequence, finite acceptance evidence and exact
   proposed validation selectors/commands, plus independent audit order.
8. Concrete conflicts/risks/assumptions and evidence that would force replanning.
   Separate source-inspection confidence from unexecuted feasibility predictions.

Approximately 3,000–5,000 words is adequate for the operative map when needed;
do not pad it with repeated historical receipts or claim completeness by length.
Include a continuation capsule <=600 words suitable for the next implementation
prompt review. Return complete details inline; no delivered artifact is required.

Before ending, use the SAME opening helper to prove clean baseline/index/cache
preservation and all 263 payloads HEAD-exact. Remove only this map's positively
owned external helper/record/scratch. Do not change index metadata to imitate
an older interval. No stage/commit/push/ref/network/clone/test/source effect.

Use one supported final token:

`RW0_D2_IMPLEMENTATION_MAP_READY_FOR_REVIEW`
  Complete concrete implementation plan within the selected D2 boundary; every
  indispensable producer, authority dependency and coupled guard is accounted
  for. This token authorizes no mutation; lead review must precede source work.

`RW0_D2_IMPLEMENTATION_MAP_REPLAN_REQUIRED`
  A named, source-supported unresolved contradiction makes the selected output
  unsafe or forces an excluded authority/effect. Specify exact owner paths,
  consequence and smallest recommended disposition. Do not offer schema choices
  or commission a new contract program by default.

`RW0_D2_IMPLEMENTATION_MAP_BLOCKED`
  Baseline drift, unavailable material source, genuine pre-opening protected
  action, preservation failure or incomplete material inspection prevents a
  supported map. Preserve everything and report the actual limit.

No D2 implementation prompt is to be issued by Codex in this pass.
