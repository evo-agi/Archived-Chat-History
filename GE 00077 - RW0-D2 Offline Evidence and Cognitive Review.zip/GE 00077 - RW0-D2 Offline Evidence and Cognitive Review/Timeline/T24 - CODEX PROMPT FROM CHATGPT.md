# Governed Execution Coordinator — RW0-D2 Audit Repair V1
# Authority-source / checked-C1 role binding; exact 70-path retained candidate

## 0. Routing, authority and first protected action

Resume the SAME parent IMPLEMENTATION Codex conversation that completed D2
Continuation 04, not the independent auditor. This separately authorizes one
bounded source/test repair after the audit's A12 finding. It is not an audit,
new map, new contract tranche, source redesign, or publication gate.

This prompt is self-contained. No earlier prompt attachment, historical mutant
payload, new snapshot, or user-mediated evidence transfer is needed. No subagent,
extra model session, provider or network call. Report visible model/effort and
permissions or `not visible`; do not seek additional access to discover them.

FIRST protected repository action: tool workdir `/`, plain-text guidance read:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

Read the complete output, using further plain-file reads if it is truncated.
Then run the filesystem-only opener in section 2 before Git or other protected
repository inspection. Reading this external instruction as plain data is
permitted preparation; prefer absolute external paths and neutral cwd. A cwd
alone is not a repository operation. A real pre-opening Git/import/test/write
is an immediate stop, not permission to replace an opening or restore metadata.
No initial git status, branch lookup, repository listing or bootstrap script.

After authenticating the exact baseline and ALL 70 working endpoints, reproduce
the failure, perform this repair, and complete validation without another user
approval. Use installed tools only. All repository imports, tests, disposable
SQLite and fixed fake children execute only in positively owned, remote-free
external copies. The live checkout permits only these three working-file edits
and inert, guarded inspection. Its index, refs, cache and other files stay fixed.

The earlier 80-path implementation ceiling and the read-only audit mandate do
NOT grant extra edit rights in this repair. Section 1 is the entire mutation
ceiling. No stage, add -N, write-tree, commit, fetch, push, PR, merge, ref/config/
worktree change, dependency install, public API, schema/migration change, service,
provider/supplier, operator-state, secret, sibling-repository, ES/Bridge or RW0-E
work. No live-checkout test, repository import, process launch or database open.
No new Section 41 post-execution writer, rank-15 admission or physical C2 work.

## 1. Finding, disposition and exact edit ceiling

The independent auditor authenticated the complete unchanged candidate in a valid
new interval and reproduced this DIRECT IN-MEMORY defect, not a production-source
mutant: a real normal run produced `preadmission_ready`, 14 checked C1 families
and three D2 child outcomes. Its first two authority observations were distinct
and matched the corresponding families. Swapping those two sources using
`dataclasses.replace` was accepted by the checkpoint and final ready-handback
validators. Authority source 0 then did not match checked family 6, but the
handback still claimed readiness. No additional durable write was made by the
swap. The existing nested-evidence test checked type/count but not this binding.

Reported locations: `_rw0_d2a_handback.py:122`, `_rw0_d2_handback.py:180`, and
`tests/test_rw0_d2_offline_integration.py:55`. Inspect actual current code; these
are starting pointers, not executable assumptions about method names or fields.
The finding is a material offline evidence-integrity defect. It does not show a
live grant, external source authentication, execution admission, or C2 decision.

Selected repair: bind each of the THREE authority-source roles to its exact
checked rank-1 C1 family and actual existing role lineage, and enforce that
checkpoint invariant when final handbacks consume it. Preserve genuinely valid
values, historical times, normal negative outcomes, data-only evidence and
same-process custody. No new authority policy or schema is selected.

ONLY these existing candidate files may change:

1. `src/ge_nwp_coordinator/_rw0_d2a_handback.py`
   Own the pure role-specific source/family/lineage relation, after existing
   exact-type and nested-value checks. Add a small private helper here if useful.
2. `src/ge_nwp_coordinator/_rw0_d2_handback.py`
   Ensure the final consuming validator revalidates the nested checkpoint and
   ties its relevant authority families to the final handback's checked evidence.
   Reuse the checkpoint owner; do not duplicate the whole policy. If its existing
   call already supplies that enforcement, leave this file byte-identical.
3. `tests/test_rw0_d2_offline_integration.py`
   Add fixed real-run, role-mismatch, independently reached consumer, positive
   preservation and bounded causal controls. Keep all current tests intact.

All three are existing C-status working files, absent from baseline HEAD/index.
They remain C after editing. No new path, delete, rename, mode change or new test
module. The other 67 candidate payloads and 216 noncandidate tracked payloads
remain byte-identical. No source-schema/version identifier, field order, container
cardinality, authority-profile meaning, role/consumer registry, pure-owner import
edge, frame, controller, writer or admission logic changes. No doc/guidance change
is needed: this repairs the existing whole-graph invariant. Content-free existing
error vocabulary is retained; do not leak values in exceptions or repr.

Before editing, inspect these three files IN FULL, their actual checkpoint
producer in `_rw0_d2a_offline.py` / `_rw0_d2a_evidence.py`, current checked-family
validation/reconstruction in `_sqlite_rw0_c1.py`, and final composition and model
consumers. Read the current D2 owner document and directly coupled tests/guards.
Follow only dependencies necessary to this join and its preservation. Confirm
there is no unlisted required consumer or content-pin change before editing;
report a precise conflict rather than hiding an import, using type names as
proof, widening a guard, or commissioning another broad map.

The latest audit established only subject/preservation and the failed A12
specimen. A01-A11 and A13, the whole semantic review, the independent six groups
and FULL remain UNPROVED in that audit. The writer's 9,044 passes are prior
implementation evidence. No procedural restart or index repair is required for
this finding; establish this repair's own correct interval.

### Opening receipts for the repair ceiling

| Path | HEAD status | Baseline blob | Opening bytes | Opening SHA-256 |
|---|:---:|---|---:|---|
| `src/ge_nwp_coordinator/_rw0_d2_handback.py` | C | `absent` | 13,339 | `1e4fddda53315d7a14d042780730e0cce07b9a5c67d41233ddff550a430ac24f` |
| `src/ge_nwp_coordinator/_rw0_d2a_handback.py` | C | `absent` | 11,551 | `9c28eff0a2e042b735ae9bdc40a8fe6f387027db53b80ec41e434d0ae92bb338` |
| `tests/test_rw0_d2_offline_integration.py` | C | `absent` | 7,008 | `d6d2b0d445b9151d811f4df426f5a8d66b7c9221d85c33bd9b4a9b9254bc7916` |

## 2. Fixed baseline, opening and complete candidate authentication

Repository: `/Users/ds/Repositories/Governed Execution Coordinator`

```text
branch: trunk_dev
HEAD: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
tree: cc3cc104300f553ada581cee24e80dab6dd885b1
sole parent: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
subject: feat: add RW0-D1 offline process and capsule spine
upstream: origin/trunk_dev at the same locally observed commit; divergence 0/0
worktrees: one
index: 263 stage-zero HEAD entries; no staged or unmerged change
working candidate: 47 modified tracked + 23 creations = 70 changed paths
other tracked working files: 216 HEAD-exact
current source endpoints: 286 = 263 baseline + 23 working additions
current AGENTS SHA-256: ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166
reported index SHA-256: 7af425d5a47b91b0a14294660f5d449f5ba6308dc8846a8b13aca371c191a587
opaque cache: src/ge_nwp_coordinator/__pycache__, directory plus 37 regular files
SQL/catalog resources: existing 0001-0004 only; no 0005
```

Do not demand a clean working tree, reconstruct a prior partial candidate or
change the index to match the working payloads. The unrelated protected
`tests/test_c2b3_private_atomic_program_initialization.py` has OS 0600 and Git
100644; preserve its observed mode. Every changed candidate endpoint is regular
nonsymlink OS 0644/Git 100644. Observe actual OS modes for all other source files.
No remote contact: local upstream equality is not fresh GitHub truth.

The supplied baseline snapshot, 3,134,667 bytes, SHA-256
`06d981b6100fc1d6ad9792aff35800eb0772b8d35f708ed030177967ccb9c40e`, reconstructs
the specified 263-leaf tree. That is baseline corroboration only. The audit
report independently reproduced the current replacement; authenticate it again
from actual bytes here before any repair or executable specimen. No snapshot
attachment is needed when the exact local objects and working files are present.

The opener is the previously used external observation mechanism, with only its
repair-interval labels changed. It is not an OS interlock. It authenticates the
current guidance and records index/cache bytes AND metadata before the first Git
command. It writes only its new external owned record/helper root. Guidance,
index and cache remain immutable for this entire repair. Never reuse the deleted
auditor root or generate a second opening to overwrite a failed observation.

```sh
python3 -I -B -S - <<'PY_OPEN'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env


import datetime
import shutil
import tempfile

guarded_environment()
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_not_exact_audited_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_unavailable')
gate_root = Path(tempfile.mkdtemp(prefix='rw0-d2-authority-role-repair-'))
os.chmod(gate_root, 0o700)
print('GATE_OWNED_ROOT=' + str(gate_root), flush=True)
record = {
    'schema': 'rw0-d2-authority-role-repair-opening-observation',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents, 'index_path': str(index),
    'index': index_before, 'cache': cache_before, 'git_executable': git,
    'git_environment': GUARDS,
    'limit': 'This repair interval only. Only the three named working files may change. All other payloads, refs, index, guidance and cache remain unchanged. No staging, commit or remote action is authorized.'
}
READ_HELPER = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\n\nimport subprocess\nimport sys\nopening = json.loads(Path(__file__).with_name('opening.json').read_text(encoding='utf-8'))\n\ndef immutable_checks():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('audit_index_content_or_metadata_drift')\n    if regular_record(REPO / 'AGENTS.md') != opening['guidance']:\n        raise RuntimeError('audit_guidance_content_or_metadata_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n\nimmutable_checks()\nindex_before_read = regular_record(index_path())\nargs = sys.argv[1:]\nif args == ['--check']:\n    print('READ_HELPER_IMMUTABLE_SURFACES_MATCH')\n    print('CURRENT_INDEX_SHA256=' + index_before_read['sha256'])\n    print('Index content and metadata equal this audit opening; no stage or index write is permitted.')\n    raise SystemExit(0)\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree',\n           'check-attr', 'for-each-ref', 'reflog'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_read_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'], ['--quiet', 'HEAD']):\n    raise RuntimeError('readonly_head_query_only')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('readonly_worktree_list_only')\nif args[0] == 'reflog' and (len(args) < 2 or args[1] != 'show'):\n    raise RuntimeError('readonly_reflog_show_only')\nfor arg in args[1:]:\n    if arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec') or arg.startswith(('--output=', '--exec=')):\n        raise RuntimeError('unapproved_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager', '-c', 'core.fsmonitor=false',\n           '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=guarded_environment(), check=False)\nfinally:\n    immutable_checks()\n    if regular_record(index_path()) != index_before_read:\n        raise RuntimeError('index_changed_during_read_command')\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(payload)

try:
    write_private(gate_root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(gate_root / 'live_read.py', READ_HELPER.encode())
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_first_git')
    print('OPENING_RECORD=' + str(gate_root / 'opening.json'))
    print('LIVE_READ_HELPER=' + str(gate_root / 'live_read.py'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D2_AUDIT_PRE_GIT_OPENING_RECORDED')
except BaseException:
    for name in ('opening.json', 'live_read.py'):
        p = gate_root / name
        if p.exists():
            if not stat.S_ISREG(p.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            p.unlink()
    gate_root.rmdir()
    raise
PY_OPEN
```

Use the ACTUAL emitted paths and the same record/helper throughout:

```sh
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> rev-parse HEAD
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> status --short --untracked-files=all
```

The helper supplies command-local Git environment protection. No raw Git fallback,
fetch, write-tree, index refresh or write is authorized. Authenticate all baseline
blobs/stage-0 entries, current refs, modes and this exact overlay. Capture the
three original working payloads in owned external scratch for an exact transition
comparison; do not overwrite their fixed expected hashes with observed values.

### Fixed complete opening replacement

```text
70 rows: 47 M / 23 C
payload bytes: 5,772,762
encoded row bytes: 5,778,160
total with prefix: 5,778,185
SHA-256: c7eb1f23446134391adb4d0a460dc489bbb5abe31376e75af86e4f5a4a6cc25c
```

Construct twice from fresh reads, preferably once streaming and once by explicit
concatenation. The identity is over RAW PAYLOAD BYTES, not a list of file hashes:

```text
ASCII RW0-D2-BINARY-REPLACE-V1 followed by one NUL (25-byte prefix)
rows sorted by UTF-8 repository-relative path bytes:
 u16be(path byte length) + exact path bytes
 ASCII M or C relative to the fixed HEAD
 u32be(0o100644)
 20 raw baseline Git blob bytes for M; 20 zero bytes for C
 u64be(payload byte length) + exact current payload
```

| Path | HEAD status | Baseline blob | Opening bytes | Opening SHA-256 |
|---|:---:|---|---:|---|
| `.docs/architecture.md` | M | `7d21418a68d2d3002753227da08cf059836d0260` | 44,745 | `5075b772afddcfe8276933d189155aa689dc4c1ee162bb702c7c7f4efaf04635` |
| `.docs/authority-boundaries.md` | M | `3524d11d67a46344214b455396afeeaa3754b41d` | 36,175 | `79c57d377b6ef7f2460ee5a5827b9c5c61334e656be9eeed73264a6906e55e32` |
| `.docs/autonomous-software-development-operating-model.md` | M | `a46d51fe3ea480e39c8c7989a08e80d9db21f5b8` | 41,197 | `926468bad8cd51c57e3aec6da775c6dced52880215f24d5b03177499a119c6c2` |
| `.docs/b3b2a-read-scope-and-query-contracts.md` | M | `c3237c31fc4b59dcd632b827a4be9907cfcfb998` | 10,013 | `74b1d21b02cd9886a697e1f1cb01dca6977cabb2da194269a35d49745fe548f6` |
| `.docs/b3b2b-select-readers.md` | M | `f1ba74b0a5cd3946a3138de326949d29f789cfac` | 6,477 | `fa7a364ce070b3fcef44907bc884bc783200e1951c618fd7e392d485497c7f07` |
| `.docs/c2b-durable-development-state.md` | M | `04c068d07cd08feaf6c56dafbf3494ccde037ede` | 1,891,411 | `8db2ba24f0685ac21fae2103bb664727a8d9635d3ead5f6bae0d42b35aaf34d2` |
| `.docs/c2b2-private-readers.md` | M | `018b3d905f5db80cf15b546f881dc8c1de3a67b7` | 14,020 | `f765b2dcd74979e235cb04c15dd1fbc81eca149aec017ca500708903bbc105d2` |
| `.docs/c2b2-pure-durable-row-values.md` | M | `1cab6d886f2cd3101987476064a9ce82d2eb4dd2` | 8,540 | `0970595b4c292517d0770542ff8e12a03b98ea93057d4e715d6518415e83aaf3` |
| `.docs/durable-state-model.md` | M | `49694cd86a51f3fb0fb3799e734a52c1a395b8c7` | 42,053 | `7f9cba19f491322dd2fc0f1656ac6b76e698723a6700d1f9919d22b2196e9e80` |
| `.docs/rw0-b1-pure-phase-values.md` | M | `5b7fb0072c6d04898cd212fdc4ff5f63903cf13b` | 35,115 | `7294e7b3aabad5338c4d846e44686ffd075b3e8fe4598495a3e7267103a9ef1e` |
| `.docs/rw0-b2-wire-protocol.md` | M | `5e41d1cb3b2f430d29eb88bdbf2b46570faf3c6b` | 26,084 | `ac1091f043f5fa6042ced1e919c740a08af975b7df1e5e97b66634f85cb68e69` |
| `.docs/rw0-c1-durable-evidence.md` | M | `a7111c4dcf761b60df35c59794bf2e3acd949745` | 15,037 | `f2c6c51d0437aa78b7975bfca3e6fc629fc2898d55c0c696750221000343a02c` |
| `.docs/rw0-c2-first-live-proof-posture.md` | M | `4b69e424655ea67900f6c6042c0cbacaf2d53f8a` | 17,674 | `ba61008234eb5ec85416c459dab0a82b19f7e1a0662dcb15f1289ba445fdf5bd` |
| `.docs/rw0-d1-offline-process-and-capsule-spine.md` | M | `f3557ca523cac0d6fa26647b17a84aef66fecc15` | 5,624 | `b537fbe074717aacdfaefd2cf32cd22c46046034ae115453ddded4e2dc25201b` |
| `.docs/rw0-d2-offline-evidence-and-review.md` | C | `absent` | 8,348 | `f9306ad7333ae08aefd62456041629380c05e984bddc3925258c655a28fa7580` |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | M | `230167a39b115634c8f9b5ae5a0699639f6ff454` | 59,586 | `bee20ed00c7e6f86db3394351f0cbe29626413c635cd9a982416984b288e6fbd` |
| `.docs/worker-execution-boundary.md` | M | `464aef2aa7a561e4adc6792d1d07642d3576f364` | 32,409 | `3cfc1208d96e1f59a81dcd70dce5d43d89f2cb70cc5af6eca453650c33742769` |
| `AGENTS.md` | M | `254854d4a57487d97ce02a73ce2ed26c86ece170` | 64,142 | `ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166` |
| `README.md` | M | `088c832ca7e28d18c82ff6317738ac8ca1c7b5d1` | 47,694 | `f48f2439d282350e36b5d8374864cb5dfe19eb417672737e820500c3a68224f3` |
| `src/ge_nwp_coordinator/_cognitive_proposal_semantic_values.py` | M | `c164616b9e86379c3c6a9210cf4941429a596d4c` | 71,190 | `40243b96765ee0bf49e56a36123e0553f3bb9ab3e0fada38dbe619a2acc1eacd` |
| `src/ge_nwp_coordinator/_development_bound_effect_establishment_contracts.py` | C | `absent` | 43,039 | `fd8fb53c8129001b74df8fa5b15ae69bb45fd970e2aa93f3bc5c20eeeeb1b370` |
| `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | M | `cb37f733141f1e3c3ce874fcc052149de1f82881` | 3,668 | `21e0c9d6c2ece57b87dfb05e961ba1a99a48e72346bbab2c4c1ed571eb5f1f00` |
| `src/ge_nwp_coordinator/_rw0_d1_handback.py` | M | `ecfcf767a5f1c32c0cf007a2c8aa3137ef92374d` | 16,920 | `3cae7fa4423187d53382ba23d9e459a5f0efcb6900a4deed6d4498ed2534ed56` |
| `src/ge_nwp_coordinator/_rw0_d1_offline.py` | M | `4f2a82e46fda9be8123888f5ca46968a4345c25f` | 23,371 | `9546f06f211253d72ea91e0dc2eaf4f0b47fdd54e3d431207f59960fbc742c95` |
| `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | M | `7dc90a0442e348aaac985d711c4d1a97adb7cc05` | 12,175 | `a236bbf599e7d32b4edcc31d23182fd9613c5d290f31a0f1e57961b6a104fe56` |
| `src/ge_nwp_coordinator/_rw0_d2_handback.py` | C | `absent` | 13,339 | `1e4fddda53315d7a14d042780730e0cce07b9a5c67d41233ddff550a430ac24f` |
| `src/ge_nwp_coordinator/_rw0_d2_offline.py` | C | `absent` | 6,967 | `d838dd02495cab5cbafa2e6e0b99d6a4e6b4b30e4ac5cb288cb9dd2db02d0d44` |
| `src/ge_nwp_coordinator/_rw0_d2a_evidence.py` | C | `absent` | 53,134 | `e93c2592c8f838bd178ffa8e57f57a9116fcdf567b248e511496d00384968ec9` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_reviewer.py` | C | `absent` | 2,878 | `0d061fdf600039ff69ba0d0dc3f1a0239c2527500461244bb53455bbdd326973` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_validator.py` | C | `absent` | 2,726 | `c1eb49503b4345d25047814e089545f9d1cd4c85f10ae20254b8b6283fa58fbe` |
| `src/ge_nwp_coordinator/_rw0_d2a_handback.py` | C | `absent` | 11,551 | `9c28eff0a2e042b735ae9bdc40a8fe6f387027db53b80ec41e434d0ae92bb338` |
| `src/ge_nwp_coordinator/_rw0_d2a_offline.py` | C | `absent` | 30,416 | `d81db9535b17c7daae7be449d7e30dbcaaa599749ddc2619dbfa7d40f87db838` |
| `src/ge_nwp_coordinator/_rw0_d2a_process_frames.py` | C | `absent` | 6,397 | `2c969b1ec303674500143bbbd721e4fe5f7ee161e00b4343f71a611a7f075c8d` |
| `src/ge_nwp_coordinator/_rw0_d2a_workspace.py` | C | `absent` | 5,075 | `45086c2b216639d3a35deef972acda526f004608780a8a8b5e30ed51253f0697` |
| `src/ge_nwp_coordinator/_rw0_d2b_fake_review_model.py` | C | `absent` | 3,771 | `492288c84c2491120a56c7056000f8ec3860c7fbce2bcb3c33249e5e1af5d93a` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_frames.py` | C | `absent` | 8,032 | `e4b7cddc6cfd4caa7e34781e1c34c00833d6f83a98477d46ce55e878e97dfcef` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_input.py` | C | `absent` | 81,718 | `e2bbe585f8ae19df5dd6547212cf239ac58411795cbae904cf3ed869910bdd9a` |
| `src/ge_nwp_coordinator/_rw0_d2b_proposal.py` | C | `absent` | 22,718 | `deec7caf82206c40545a308f3a8845fb867e64a211a81e055fb29ffbafc0666a` |
| `src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py` | C | `absent` | 23,762 | `d5012ef7dd383ae39364772d7702364fc0eadde31a1e64997c0a6773d6025245` |
| `src/ge_nwp_coordinator/_sqlite_rw0_c1.py` | M | `635b5dd49256e14103fced6ff8ea4db76649e22c` | 203,409 | `d17490b3ce1b136eeb3d559f01f44e97836827bc137325b306ec01530e06e9e7` |
| `src/ge_nwp_coordinator/sqlite_transition_transaction.py` | M | `f8053db4010faaba41b38b531d93a8b21e80daa8` | 180,600 | `6d662dcb83a2641b9d95dee7209ddbd0d8b991bc720da3aafa5b4b9fb3bc5521` |
| `src/ge_nwp_coordinator/sqlite_writer_session.py` | M | `97162e3a749a7f1f1ae75de90c4b2d9092068107` | 299,804 | `54f9c5a0844421686c1c89cdecf3c2865263b3339d2faec933c615ca2ca3d404` |
| `tests/test_b2a_writer_session_contract.py` | M | `ccadd884de29d606c9243ea7796cc380e29fe5c2` | 29,168 | `835b386274f410f2fc52b1a40b2c936009ac5286fb22bc23cc28efa789be0664` |
| `tests/test_b3b2a_read_scope_and_query_contracts.py` | M | `66cab4655d33c1b864f5fb4c22e853a39c5a8188` | 26,502 | `4cabeed0c37a99c0f937c0b49f25c7c6a049eb9125e64127019c449dcd86313a` |
| `tests/test_b3b2b_select_readers.py` | M | `c0c5a0e091572f30a428fd5a2634c21d25a6ad64` | 118,350 | `22061f6846b0ebc969f9b67bac399b8d8eb237c8df0e2de92d84d477c0f1ce2b` |
| `tests/test_b3c4c_prerequisite_contract.py` | M | `f1ee03232e33da8bbfa5592fe81c53414acb25b1` | 36,340 | `3d25c2ffb8ee86856c154cfc9dd842bab2db87ea2b200cd75758a62f372b5cd8` |
| `tests/test_c2a_nonimplementation.py` | M | `3f343ae5886c92941ebfff63ba4213de2109025e` | 30,650 | `c0db68e10f4588c02bbc38da1b95d6898a3d7896c127038533ce0c8a6715442e` |
| `tests/test_c2b0_durable_state_contract.py` | M | `b910d61aaf670ba40a0d649f933c06767e7360e5` | 887,367 | `995c3690500e3d3009f1fe93b276db506e1d454764dd2e5167df52bf81252c1a` |
| `tests/test_c2b2_development_reader_contracts.py` | M | `122f0d44b46e0a8d7b283d5baec1ce465e2028b6` | 71,365 | `28dbf4fff09d75d7522af35c8fddc8908b7c4c1d18ff8043d19dbf6b90f30970` |
| `tests/test_c2b2_development_row_value_boundaries.py` | M | `d7dea23786bec2ca98bb702bbe93cc31e4192221` | 17,972 | `f2a7089748f39dc8c40a932ac770edd3ffa7f8ea581b053af101dfda8100c830` |
| `tests/test_post_execution_pure_owner_boundaries.py` | M | `437a4e7cbd39682bdd08f03b3a30c0bbbd057614` | 19,302 | `7945be6d5e01c2a1b437cabc57972bbd70a725da9c14f7dd92574ff8f8633014` |
| `tests/test_post_execution_pure_owner_vectors.py` | M | `3eed1c6bc08b6876d1e74d94a4e5509c14786eb0` | 103,682 | `3d526cabcead871b5bba47952b914df76a34b5d85a7b730e55afb951c050de16` |
| `tests/test_runtime_non_authority.py` | M | `79d4ab185815234c9d087c48d2439b9a1d95d95d` | 48,343 | `fef5729d8e7f4c619ddb2731b52d3500bc8e75988a3f422648b9dea743ef01c9` |
| `tests/test_rw0_b1_boundaries.py` | M | `17d1e09c30b01287718c6b5175bac76b03daf458` | 52,838 | `af8d9f7507733876a5978d1a3f5b871a81030380eba929cbffe6959f9d639aaa` |
| `tests/test_rw0_b2_capability_boundaries.py` | M | `4668d2a2c285d2d79bf6ebfb0c9c9f60166bcb27` | 50,538 | `85ee20f37629ffc852154cea67dd5dc983b0f2f74ab2d370192c13d999b397c3` |
| `tests/test_rw0_b2_wire_boundaries.py` | M | `9e04f528326a6f337a4f47e7e9f9eda3c9a82e0a` | 38,513 | `13531d5d46258ca67cc7bf0bddd78c560ce9b7308ff296068a146299f349ba27` |
| `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | M | `0f0159c172e1448d2b96ab19411e1f85467a2931` | 120,405 | `af7f49ac8da64c12e97d03a536ee10b89a11996651b0d712dc04baef427d8cf3` |
| `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | M | `e9d95b54a4b5921be8ec39d2bf3f6216204750c7` | 247,679 | `e8de37791388c28f1b1626747af6c4094622469168ed9799eaa78f7f6f4d3613` |
| `tests/test_rw0_d1_handback_values.py` | M | `982be9b37aa05db0c6d6a3321b775c7c64f2142d` | 30,189 | `e8addc00e8b37aa5e6f24a91a637c9f5053656c58a0d4c06e713618229e448b6` |
| `tests/test_rw0_d1_offline_integration.py` | M | `33c2d85012cbdf0e7e04fdeb7d333d2c8675ae3f` | 53,132 | `c5997a4e9161253974b04b203bf55754c12b465c3b0b5924247e6c1df8e05c9e` |
| `tests/test_rw0_d1_worker_process.py` | M | `e2a83abe44db720b5ce0725682ac71d30372959d` | 1,737 | `512d7d61083e8ad8c61c197aefc86f70d61a1f7e41273fab435bb493cc08631f` |
| `tests/test_rw0_d2_bound_effect_contracts.py` | C | `absent` | 5,636 | `4c8f04a5f16d0e0b236f8fff636e5d9a5d41c465dad6fc726bd488fb76b59574` |
| `tests/test_rw0_d2_bound_effect_persistence.py` | C | `absent` | 6,068 | `839a68b7285480a6ca19885be2df2e398dbedb8e6909f381f5cfe4aa8155da67` |
| `tests/test_rw0_d2_c1_checked_readback.py` | C | `absent` | 17,750 | `20237660028125bacccf52bb695cb275adebefb2ed1f0a28bb271688f7aadb01` |
| `tests/test_rw0_d2_evidence_children.py` | C | `absent` | 3,635 | `fd4cd60a30cb641d34b458f7782bcc27d020a37f47f6523c37cfcf83895d516b` |
| `tests/test_rw0_d2_model_handback.py` | C | `absent` | 4,966 | `89c53206f1b636257ecf5f71027e11ca4ef4cfdd00883e55b2c0fa02fe2a7a6e` |
| `tests/test_rw0_d2_offline_integration.py` | C | `absent` | 7,008 | `d6d2b0d445b9151d811f4df426f5a8d66b7c9221d85c33bd9b4a9b9254bc7916` |
| `tests/test_rw0_d2_process_frames.py` | C | `absent` | 6,894 | `f77f49268e4ed693d049560307aa3794538842efc8afa24e1500664fc4884264` |
| `tests/test_rw0_remote_contact_phase_entry_contract.py` | M | `2a9144c3dfd2c883555703c8adecd21f447d6d34` | 177,317 | `6df3c991a219633d148106396336f2702c323b6cddb82932b41152ea3e5ac16a` |
| `tests/test_sqlite_backend_b0_contract.py` | M | `c646df6d439d0b70f45d6d72200fbedb5e730779` | 26,412 | `1eb038201c19be7e9680f5ee6c4425fb50051b8bc0df31e3feeab06620cc094e` |

No history is rewritten by this repair. The earlier failed audit opening remains
unproved; the latest valid interval is separate. Its differing external-copy
digest belongs to its disclosed copy grammar and is not interchangeable with the
HEAD-relative replacement above. Identity proves bytes, not correctness or
permission. Unexplained subject mismatch stops before edits or code execution.

## 3. Required invariant: exact roles, actual checked families, no new authority

### 3.1 Derive the mapping from the retained producer, not from observed success

Read the actual A producer, checkpoint definition, D2 owner and all relevant
consumers. Its reported normal sequence is:

```text
C1 ranks by admission position, zero-based:
(12,12,12,12,13,14,1,1,5,6,12,6,12,1)
authority_sources order: validation, review, author
```

Confirm this before authoring. The selected role relation is:

| Role | Source slot | Corresponding checked family | Required lineage anchor |
|---|---:|---|---|
| validation | 0 | validation rank-1 admission (reported slot 6) | actual validate_candidate bound-effect command/result and its current fence |
| review | 1 | review rank-1 admission (reported slot 7) | actual review_candidate bound-effect command/result and its distinct current fence |
| author | 2 | author rank-1 admission (reported slot 13) | original D1 author lineage, AttemptFence and author EffectFence |

Positions document the existing closed producer order; numeric rank alone is NOT
the role identity. Do not silently change tuple order, sort inputs, choose any
matching record from a set, or accept whichever source the caller supplied as the
role definition. If the actual authenticated producer/order contradicts this
reported mapping, state the exact source and stop before redefining semantics.
Use explicit existing roles and their independent command/fence/phase coordinates.

### 3.2 Validate nodes before comparing the relation

Preserve exact outer and nested type checks and canonical self-digest validation
for each source, checked family, bound proof and existing row value. An integer
rank must be an actual int, not bool; subclassed scalars and forged exact wrappers
must not bypass the existing validation discipline through overloaded equality.
Use the existing pure reconstructors/validators and canonical mappings already
available to these consumers. Do not add a new B1 construction/qualification
permission or import a SQL read function into a handback to obtain confidence.

A source observation is RW0AuthorityVerificationObservationV1. Its baseline
owner at `_rw0_phase_entry_semantic_values.py:592-614` supplies explicit schema,
observation/source/evidence refs and digests, phase basis, parent/grant/attempt/
effect basis, both fences, audience/repository/base/path scope, effect class,
ceilings, status/revocation, historical times, head digests and global-stop data.
Use the actual owner fields; do not invent a second authority envelope.

The existing C1 rows expose rank/value/schema and phase/member/receipt identity.
Baseline guidance for inspection:
- `_rw0_c1_row_values.py:55-84,97-113`: registry, membership, relation/operands,
  rank-1 typed payload fields;
- `_sqlite_rw0_c1.py:1532-1588`: reconstruction of original semantic values from
  typed C1 evidence;
- `_sqlite_rw0_c1.py:4181-4246`: receipt/member/registry/phase equality;
- `.docs/rw0-c1-durable-evidence.md:114-160`: exact membership and historical times.
These are baseline pointers; inspect the current D2 checked-value validation as
well. Do not execute a writer or reader in the checkpoint's pure validation.

### 3.3 Enforce the source-to-family join for all three roles

For each role, establish ONE matching checked rank-1 family in the same phase,
with the exact existing member identity. A matching rank or effect_class alone,
a nonempty digest, a count of three, or membership in an unordered set is not
sufficient. Validate the checked value's internal relations rather than trusting
a caller-replaced evidence_value field because the wrapper type is correct.

After existing nested validation, compare:
- source schema/ref/digest to the family registry, membership, admission result
  and typed authority payload through their actual canonical accessors;
- complete canonical source value to that family's reconstructed evidence_value,
  including supplied evidence/source refs and historical timestamps, not only
  effect_class or issuer name;
- phase-basis ref AND digest to the actual D1 phase and the family phase/member;
- the source's current effect class and current fence ref/digest to the selected
  validation/review bound-effect proof or original author fence, respectively;
- the applicable original attempt/grant/basis/command/fence and current role
  coordinates using existing fields and semantic meanings. Follow the checked
  relation's relevant existing-owner operands where its representation requires
  them. Do not invent a field or treat Section 41 selection as the original
  development basis decision;
- validation/review qualification verification_ref/digest and fence references
  to their already retained role-specific authority sources where those current
  fields consume the sources. Preserve current readiness and qualification
  semantics; this is the same evidence join, not a new temporal policy.

No slot may reuse another role's checked family merely because it has rank 1.
Preserve distinct member identity where the existing complete path requires it;
do not require different source_ref/issuer values when a legitimate artificial
source supplies more than one observation. A shared issuer is not the defect.

Moving both a source and its checked family together must NOT evade the fixed
role/lineage anchor. The role is defined independently by its existing command,
effect class and fence, not by the pair being compared. The repair must reject
valid-type substitutions with freshly correct self-digests when their relational
binding is wrong. A stale self-digest must not mask the intended test.

Do not silently repair, canonicalize, reorder, replace, re-admit or regenerate an
observation/family. Reject inconsistent evidence with the existing content-free
validation error. Do not add status='verified', cached validation booleans, a new
receipt or an authority token. No object-identity `is` requirement for semantic
equality: a separately reconstructed but canonically equal valid value must work.
The D1 adapter's existing producer-identity requirements remain unchanged.

### 3.4 Revalidate at the final consuming boundary

Keep one authoritative pure checkpoint invariant. The final handback validator
must invoke it on the checkpoint supplied NOW and preserve its existing joins to
checked_admissions / committed_bound_effects and model evidence. A constructor
that ran earlier is not proof that a nested exact wrapper is still coherent.

This applies wherever a checkpoint is present in an otherwise legitimate final
status, not only a particular happy-path constructor. Do not demand a completed A
checkpoint in an early stopped/cancelled/cleanup_unresolved path which never
produced one. Preserve reached-prefix rules, valid negative checker/model results
and final no-invented-proposal behavior. The repair is not a reason to erase
already produced evidence or promote a failure to `preadmission_ready`.

If the final validator already calls the checkpoint validator at the correct
point, reuse that call and leave the final module unchanged. An added pure helper
in the checkpoint owner is permitted, but no new consumer schema, type layout,
serialization form, import role, I/O owner or broad general-purpose join library.

### 3.5 Historical consistency is not fresh authority

Validate the retained evidence relation, not current external truth. Do not query
SQLite, poll a PID, resample wall time, requalify/revoke/renew a source, access a
network service, or perform another admission while validating a handback. Do
not reject a coherent historical record solely because its expiry passed after
the original run; retain the existing separately governed B-entry currentness
checks and their timestamps. No new freshness claim follows from this repair.

Artificial authority sources remain artificial. Checked C1 evidence retains its
historical admission meaning; it is not a signed external permission. Digest and
role matching do not prove arbitrary coordinated forgeries or all possible
whole-graph substitutions. The broader independent A01-A13 audit remains required.

## 4. Focused permanent tests and bounded causal evidence

Reproduce the auditor's actual source-only swap on a fresh external copy BEFORE
editing. Use a real normal D2 invocation and retain its open run owner separately
for cleanup. Confirm its sources are individually valid, distinct for their
roles, and originally match the corresponding checked families. Swap source 0/1
only, leaving all other records unchanged; reproduce successful checkpoint and
ready validation on the opening candidate. This is an in-memory object mutation,
not a claim that the ordinary producer misorders the tuple. Do not invent the
auditor's deleted script bytes or external-copy digest.

Implement fixed tests in the one allowed integration-test module. New helpers
are test-local; predicates/expected roles must not be imported from the mutable
production helper under test. Parent-created test observers are evidence tools,
not launch gates, C1 producers, or authority oracles.

### 4.1 Positive and direct hostile matrix

Use a small finite matrix with actual D2-produced checkpoints:

- Unmodified normal run: both validators accept; real retained source/family/
  phase/fence/qualification equalities are independently asserted. Preserve all
  14 members, the five process roles (three D2 outcomes), and normal owned cleanup.
- Semantically identical reconstruction: rebuild an authority observation via
  its current canonical no-I/O constructor/mapping without altering a field.
  It is accepted in the same role despite being a different Python object.
- The demonstrated validation/review source-only swap is rejected at checkpoint
  construction/replacement and by its explicit consuming validator.
- Exercise the other two source transpositions involving the author (0/2, 1/2)
  and one duplicate-source substitution, keeping each individual value valid.
- Move the validation/review checked families alone, then move the two source+
  family pairs together. The former tests association; the latter must fail the
  independent fixed role/fence anchor rather than an unrelated type/count error.
- Use one same-role, well-formed and self-consistently resealed alternate source
  (changed safe observation/evidence identity), with unchanged checked family.
  It must fail the exact admitted-value join even though effect_class still fits.
- Show a one-sided supplied family.evidence_value substitution cannot satisfy
  the source relation while its registry/payload/member refer to another value.
  Use the current checked-family validator; do not modify its owner or seed rows.

These are finite cases of the SAME three-role relation, not a broad policy or
schema-fuzzing program. A single parametrized test may cover several cases.
Confirm shape and node-level validity before using each as evidence of the join
check; do not award that credit to stale digest, rank/type or unrelated prefix
errors. Record any existing stronger predicate that already rejects a specimen.
If a direct schema-valid alternate cannot be produced by the current constructors,
state that limit and use a real same-role record from a second owned normal run;
do not disable node validation or widen semantic types.

### 4.2 Prove final consumption independently of constructor rejection

After the constructor fix, a normal dataclasses.replace may reject too early to
exercise the final consumer. Use an explicitly test-only forged exact checkpoint
wrapper (e.g. a controlled frozen-dataclass field overwrite) retaining all real
fields except the swapped authority tuple. Independently exercise its validator.
Then reach the FINAL handback validator with that forged nested checkpoint,
bypassing initial construction only as needed in the external test specimen.
Do not call the checkpoint validator from the test immediately before final
validation and count its rejection as final-consumer protection. Record the
expected existing validation failure at each genuinely reached boundary.

Apply the checkpoint-consumption rule to an actually supported non-ready status
that legitimately carries a complete A checkpoint if such a producer exists.
Do not invent an impossible stopped reason just to construct a test. Also retain
one legitimate early stopped path with no checkpoint; no full-A requirement is
introduced there. Ordinary negative evidence/recommendations remain represented.

The in-memory substitution phase must not run another child, write/re-admit a
family, touch provider state or dispose the borrowed valid run. Observe those
non-effects where the existing test instrumentation permits it. Finally close
only positively owned runs and new child/reconstruction resources. The original
successful run remains usable until its own explicit close; double-close and
wrong-PID protection remain unchanged. No test may leak a live run on rejection.

### 4.3 Exactly the focused omission controls, not a full suite per mutant

From the final repaired bytes, build separate external controlled copies with
unchanged final tests:

J01 — remove/neutralize the newly operative role-to-checked-source join in the
checkpoint owner. The legitimate positive still passes; the fixed swap/alternate
negative must fail semantically because the violation is no longer rejected.
If an existing independent role guard masks the narrow deletion, report that
scope and select a valid same-role alternate reaching the new join. Do not claim
individual redundant-layer protection from a combined disabling experiment.

J02 — bypass the final consuming path's revalidation of its present checkpoint,
while leaving the checkpoint validator itself correct. The forged-checkpoint
final-consumption test must fail because final validation no longer rejects it;
the direct checkpoint negative should remain effective. If a separate existing
consumer check still rejects, report the actual invariant and use a narrowly
identified combined omission only to demonstrate that combined consuming
boundary, without claiming each redundant predicate was proved individually.

Both copies must parse/import and retain the full expected integration collection.
A failure in source hashes, import inventory, syntax, unknown type, collection,
missing basetemp or test harness does not prove runtime evidence rejection.
No real D2 child is necessary merely for syntactic controls, but use real-run
values for the role specimens. The former audit's 9,044-test implementation result
is not a substitute for executing the repaired positive/negative tests.

Run these focused controls and the whole integration module before the expensive
final matrix. Keep the finite A01-A13 independent audit open; do NOT attempt to
claim its untouched rows accepted or run a new full audit as the repair writer.

## 5. Final validation: unchanged memberships, revised B_MODEL/FULL identities

After the last source/test edit, rebuild one final remote-free external copy of
the fixed 263-file baseline plus ALL 70 current candidate payloads. No live cache,
operator data or secrets. Verify all 286 source endpoints before and after every
normal run. No hardlinks to mutable live files. Use installed Python 3.13/pytest,
umask 022, PYTHONDONTWRITEBYTECODE=1, PYTHONPATH=.:src, a positively owned TMPDIR,
-B, no pytest cache and separate precreated collection/run basetemp parents.
No xdist, parallel groups, installs or network.

For EACH of the six groups below, collect then execute serially:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-group-collect> --collect-only <exact-group-paths>

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-group-run> <exact-group-paths>
```

### A0_D1

```text
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_offline_integration.py
tests/test_rw0_d1_planner_process.py
tests/test_rw0_d1_process_frames.py
tests/test_rw0_d1_process_supervisor.py
tests/test_rw0_d1_worker_process.py
tests/test_rw0_d1_workspace_capsule.py
```

### BINDING_COMPAT

```text
tests/test_c2b3c_author_effect_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_c2b3d_author_effect_establishment_recovery.py
tests/test_c2b3d_private_atomic_author_effect_establishment.py
tests/test_c2b3d_private_author_effect_delegation.py
tests/test_worker_execution_semantic_relations.py
tests/test_worker_execution_semantic_vectors.py
```

### A_NATIVE

```text
tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_private_readers.py
tests/test_rw0_c1_reader_contracts.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_row_values.py
tests/test_rw0_c1_semantic_values.py
tests/test_rw0_c1_writer_session_delegation.py
tests/test_rw0_d2_bound_effect_contracts.py
tests/test_rw0_d2_bound_effect_persistence.py
tests/test_rw0_d2_c1_checked_readback.py
```

### A_EVIDENCE

```text
tests/test_post_execution_pure_owner_relations.py
tests/test_post_execution_pure_owner_values.py
tests/test_rw0_d2_c1_checked_readback.py
tests/test_rw0_d2_evidence_children.py
tests/test_rw0_d2_process_frames.py
```

### B_MODEL

```text
tests/test_rw0_d2_model_handback.py
tests/test_rw0_d2_offline_integration.py
tests/test_section41_cognitive_proposal_row_values.py
tests/test_section41_cognitive_proposal_semantic_values.py
tests/test_section41_pre_execution_plan_disposition_contracts.py
tests/test_section41_pre_execution_plan_disposition_recovery.py
tests/test_section41_private_atomic_pre_execution_plan_disposition.py
tests/test_section41_private_pre_execution_plan_disposition_delegation.py
```

### GUARDS

```text
tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_b2a_writer_session_contract.py
tests/test_b3a_persistence_contracts.py
tests/test_b3b2a_read_scope_and_query_contracts.py
tests/test_b3b2b_select_readers.py
tests/test_b3c4c_prerequisite_contract.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b2_development_reader_contracts.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_post_execution_pure_owner_boundaries.py
tests/test_post_execution_pure_owner_vectors.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_c2_private_value_versioning_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_sqlite_b1_runtime_boundary.py
tests/test_sqlite_b2c_writer_session.py
tests/test_sqlite_backend_b0_contract.py
```


FULL: collect then execute with NO test-path argument. It remains 131 modules
unless a legitimate discrepancy is reported; no new test file is authorized.
Do not infer a full run from overlapping groups or from the prior writer result.
One full execution after final edits, not one full run per mutant. If an execution
must stop early, report exactly what ran, what failed and what was omitted.

### Opening inventory anchors (implementation evidence, not independent passes)

| Group | Modules | Opening nodes (reported) | Fixed opening module SHA-256 |
|---|---:|---:|---|
| A0_D1 | 7 | 117 | `bd79dcd6261a545b90e3709e7bff2b16fa00d9fb71f67baa4082f71de6b75236` |
| BINDING_COMPAT | 7 | 160 | `0851123786b9bcbab0f2f417539ec3d1a0e6ffc753c4075e3d33b15e27dccd30` |
| A_NATIVE | 11 | 118 | `07f8d2d3b7f971ab76b23f537de7985ed9e5388c5f5f69dc6d5d3b9d995fc22d` |
| A_EVIDENCE | 5 | 659 | `d74195c30fd2f5c9e56591b2365651836ec7c982d0c1fe96da3f1fc26850b1ba` |
| B_MODEL | 8 | 178 | `502a95c07c4162623dde67af3204e201fc6f278dffb964cc96044d072119e304` |
| GUARDS | 24 | 4162 | `4533bd1c1f6ee61c1e96847b3d6ce684af46046304ae9a6df28348eaace2b617` |

Opening FULL module identity:
`45152861800f4322e8d3d4111205b731c2c86f5e89d52814234dfc22fbe400bc`
Opening FULL: 131 modules / writer-reported 9,044 passed.
Opening six-group occurrences 5,394 / unique nodes 5,392; two checked-C1 overlaps
between A_NATIVE and A_EVIDENCE; 3,652 full-suite nodes outside that union.
The latest audit executed NONE of these final pytest groups.

Only B_MODEL contains the permitted amended test. A0_D1, BINDING_COMPAT, A_NATIVE,
A_EVIDENCE and GUARDS keep exact module memberships and payload hashes. Recompute
B_MODEL and FULL module/node inventories; do not preserve an obsolete hash by
changing test selection. All six executions remain required because source
validators changed. With no other test edit, count reconciliation is:

```text
final full test count = 9,044 + (final B_MODEL count - 178)
```

That is accounting, not a target or permission to remove/skip/xfail tests. Keep
complete node IDs including spaces in parameter text. Report actual set overlaps
and inclusion. Unexpected collection identity changes require a concrete cause,
not a silent normalization of expected values.

Inventory grammars (no prefix):
MODULE = sorted unique path UTF-8 records, each u32be(path byte length) + path
bytes + raw 32-byte SHA-256(module payload).
NODE = sorted/deduplicated full UTF-8 IDs, each u32be(ID byte length) + ID bytes.
Do not label module hashes as node hashes or sum overlapping group totals.

Only the three established Python 3.13 multithreaded-fork DeprecationWarnings in
tests/test_sqlite_b2c_writer_session.py are expected, normally in GUARDS and FULL:

```text
test_operation_guard_close_waits_and_retains_authority_until_exit
test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Inspect the structured node/category/message/location, not only a count. No
warning suppression or new-warning relabeling. Separate failed/interrupted
harness trials, corrected runs and final-byte results. A passing focused specimen
cannot stand in for an omitted full run or the later independent audit.

All 23 creation no-index whitespace checks and tracked diff checks must pass,
plus strict UTF-8, no BOM/CR/trailing spaces, exactly selected final-LF form and
regular-file/mode checks. No migration/catalog, controller, writer, pure-owner,
public export, 9-edge registry, profile/digest-domain or prior guard identity
changes are permitted. Do not 'refresh' any hash to accommodate this repair.
If a protected file becomes indispensable, stop with the exact dependency and
retain all already-authorized partial work; no bypass or broader edit permission.

## 6. Copy provenance, retention, closing and report

Use a complete external source manifest for every normal and controlled copy:
all 286 relative paths, types, Git/OS modes, lengths and full SHA-256 values.
For each mutation retain the exact source transformation, target file, original/
mutated endpoint hashes, selected node IDs, actual failure/positive and source
manifest equality after execution. Do not claim identity to deleted auditor
programs or compare unequal digest grammars as if they identified the same bytes.

A disclosed full-copy grammar for this repair is:

```text
ASCII RW0-D2-ROLE-REPAIR-COPY-V1 followed by NUL
for every source endpoint sorted by UTF-8 path bytes:
 u32be(path byte length) + path bytes + u32be(Git mode)
 + u64be(payload length) + exact raw payload
```

Record OS modes separately. A digest proves identity, not authority/correctness.
Keep actual handles and group/root identities for all produced children, including
intentionally unreported ones. A failed assertion must still run positively owned
cleanup. Never kill by name, scan/sweep generic /tmp, clean another injected run,
follow symlinks, or open a FIFO/socket/device for artifact inventory. Use lstat
and hash only regular files. Tests may create disposable SQLite, symlinks and
special fixtures outside the checkout; classify them instead of treating their
mere presence as a repository defect. Audit/repair rescue is not runtime cleanup.

At closing compare against THIS interval's actual opening: HEAD/tree/parent/refs,
upstream/worktree facts, full index bytes and metadata, guidance, cache directory
and all 37 members, modes, all 263 baseline relationships, the 67 protected
candidate payloads and all 216 noncandidate files. The three allowed paths may
have only this explained repair. Every old M remains M and C remains C; no stage,
new path, public effect or repository artifact. No source edit after closing
receipts without reidentification and affected validation.

Recompute the entire final 70-row HEAD-relative replacement stream twice from
fresh actual payload reads using section 2's grammar. Report full identities,
not abbreviations. Report each of the three allowed endpoints as changed or
unchanged with opening/final size/SHA and the reason. All old payloads remain
available only as long as actually retained; do not claim removed scratch exists.

After completed process and preservation checks, remove only positively owned
external roots (including the opener) and verify removal without running further
raw live Git. Preserve the uncommitted repaired candidate on a substantive stop;
do not reset/discard it. No report ZIP, retained database, user transport bundle,
repository report file, new service or background continuation is requested.

Return operative results INLINE:
1. Verdict, actual settings, correct opening/closing provenance and exact subject.
2. The source-to-checked-family role table confirmed from actual producers,
   field joins, historical/non-authority semantics and constructor/consumer paths.
3. Reproduced opening 0/1 swap, normal/equivalent positives, all selected direct
   mismatches and independently reached final consuming rejection; exact nodes,
   observed effects, content-free failure and owned cleanup.
4. J01/J02 actual transformations and full identities, reached failure signals,
   redundant-layer qualifications, and valid positive controls.
5. Three allowed-file opening/final receipts, exact entire 70-row final table or
   full inherited-table confirmation plus unambiguous replacements, raw aggregate
   length/SHA twice, and unchanged 67 candidate / 216 baseline files.
6. All final commands and selectors, collections/results, module and node
   inventories, overlaps, warnings, failed trials, skipped validation and cleanup.
7. A concise continuation capsule: exact repaired candidate; what this repair
   proves; independent audit A01-A13/full review/final execution still pending.

Only supported complete result:
`RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_REPAIRED_V1_VALIDATED_READY_FOR_REAUDIT`
This requires the scoped fix, direct and causal checks, all final validation and
preservation. It grants only eligibility for a newly issued independent re-audit,
not acceptance, staging, commit, publication or runtime activation.

Other dispositions:
`RW0_D2_REPAIR_PROVENANCE_BLOCKED` — fixed subject/opening/preservation not established.
`RW0_D2_AUTHORITY_BINDING_REPAIR_REPLAN_REQUIRED` — exact protected dependency or
owning contradiction prevents this three-file repair; preserve the candidate.
`RW0_D2_AUTHORITY_BINDING_REPAIR_VALIDATION_BLOCKED` — implementation or validation/
causal/cleanup requirements incomplete; name the omissions without claiming READY.

The prior audit remains BLOCKED on a material candidate defect. Its valid
preservation interval is not the failed earlier opening; neither is rewritten.
No independent acceptance claim follows from these implementation results. No
Section 41 post-execution persistence, rank 15, physical C2 decision/terminal,
new migration, live grant/provider/supplier, ES/Bridge, Git/publication or RW0-E
effect is selected.
