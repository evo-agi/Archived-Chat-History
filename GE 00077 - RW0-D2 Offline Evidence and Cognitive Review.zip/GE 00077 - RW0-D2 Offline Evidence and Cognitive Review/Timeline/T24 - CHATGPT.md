## Disposition

**Accept the audit block. Repair the authority-source binding in the checkpoint and its final-handback consumer, with permanent integration tests. Preserve the rest of the D2 candidate. Do not stage, commit, or publish.**

This is a **material candidate defect**, not another stale guard or procedural failure. The auditor used unchanged source, obtained a normal ready result, and then demonstrated that individually valid authority observations could be assigned to the wrong roles without either validator rejecting the handback.

The scope of that observation matters: the normal invocation initially supplied matching evidence. The probe established acceptance of a subsequently malformed evidence graph—not that the normal producer swapped the observations, issued live permission, or made a C2 decision.

The existing A12 requirement already covers wrong-family/ref/digest substitutions at constructor and consuming boundaries. No new authority rule or architecture tranche is needed to repair it. Coordinator_RW0_D2_Independent\_…

## The missing invariant is relational

These two statements are not equivalent:

```text
Every authority observation is individually well formed.
```

```text
Every authority observation is the exact observation admitted
for its assigned role in this checkpoint.
```

A valid schema and self-digest establish the first. They do not establish the second.

**The repair must bind all three roles—not merely special-case the demonstrated 0/1 swap.**

| Authority role | Required existing binding |
|---|---|
| Validation | Its checked rank-1 family, the actual validation effect, and that effect’s current fence |
| Review | Its checked rank-1 family, the distinct review effect, and that effect’s current fence |
| Author | Its checked rank-1 family and the original D1 author lineage and fence |

The implementation must confirm the exact tuple positions from the retained producer and owner document. It must not define the role by whichever observation the caller happens to place there.

For each role, the comparison must cover the source’s canonical identity and value, the checked family’s registry/member/payload identity, and the corresponding phase and fence relationships. A matching `effect_class`, a nonempty digest, or the right number of rank-1 families is insufficient.

The baseline types already carry the necessary distinctions: `RW0AuthorityVerificationObservationV1` includes its observation identity, phase basis, attempt/effect bases, fences, effect class, and historical evidence fields; C1 separately records the admitted value and membership identities. See:

```text
_rw0_phase_entry_semantic_values.py:592–614
_rw0_c1_row_values.py:55–84,97–113
```

The repair should use those existing meanings, not introduce another authority envelope.

### Reject substitutions; do not silently repair them

Sorting the observations, searching for any matching family, swapping the records back, or regenerating an observation would conceal the malformed input rather than validate it.

Moving both an observation and its checked family together must also fail when they no longer belong to the fixed validation/review role. Their equality to each other cannot replace their relationship to the correct command and fence.

Conversely, **semantic equality must not become Python object identity**. A separately reconstructed but canonically identical authority value should remain valid. The regression concerns assignment to the wrong role, not whether two variables reference the same object.

Shared issuer/source identifiers also need not be prohibited when the existing artificial source legitimately supplies multiple observations. The actual observation, membership, role, and lineage bindings are what matter.

## Exact three-file repair ceiling

Only these existing candidate files may change:

```text
src/ge_nwp_coordinator/_rw0_d2a_handback.py
src/ge_nwp_coordinator/_rw0_d2_handback.py
tests/test_rw0_d2_offline_integration.py
```

The checkpoint owner should hold the pure binding invariant. The final-handback validator must apply that invariant to the nested checkpoint it is consuming now.

**If the final validator already invokes the checkpoint validator correctly, it can remain byte-identical.** There is no benefit in duplicating the same policy in two places. Its independent consumer protection still needs to be demonstrated.

The other **67 candidate payloads** and **216 noncandidate tracked payloads** remain fixed. No document, schema, field-order, cardinality, profile, migration, writer, controller, source producer, or consumer-permission change is selected. The earlier implementation ceiling does not authorize unrelated edits during this repair.

This also remains a **pure evidence-consistency check**. It must not query SQLite, read current authority, resample time, renew an observation, or re-admit a family while validating a handback. C1’s historical admission evidence and separately governed model-entry currentness remain distinct. The audit mandate already requires that separation. Coordinator_RW0_D2_Independent\_…

## Prove the fix at both boundaries

The permanent tests should first reproduce the exact opening defect using a real D2 result: swap validation and review authority observations while leaving their checked families unchanged.

The repaired test matrix then needs a small set of discriminating cases: the other role swaps involving author authority, a duplicate source, family-only and paired source/family swaps, and one correctly formed same-role observation that is not the admitted observation. These are bounded variations of the same relation—not another general fuzzing program.

The positives are equally important: the unchanged ready result must pass; canonically identical reconstructed evidence must pass; and legitimate early stopped paths must not suddenly require a complete checkpoint that was never produced.

### Constructor rejection cannot stand in for final-consumer protection

After the fix, `dataclasses.replace` may reject the malformed checkpoint before the final handback is reached. That would prove constructor protection but leave the consuming boundary untested.

The handoff therefore requires an explicitly test-only forged exact wrapper to reach final-handback validation with the malformed nested checkpoint. The final validator must reject it **without the test first calling the checkpoint validator and taking credit for that earlier rejection**.

This is exactly the distinction required by the existing audit: a stronger preceding predicate can mask the layer being tested, and that masking must not be reported as independent coverage of both layers. Coordinator_RW0_D2_Independent\_…

Two bounded external omission controls protect the correction:

| Control | Required discrimination |
|---|---|
| Remove the new checkpoint source/family binding enforcement | A fixed relational negative loses rejection while the legitimate positive remains valid |
| Bypass final consumption’s checkpoint revalidation | The forged-checkpoint final test loses rejection while direct checkpoint validation remains effective |

Any redundant check that masks a deletion must be reported accurately. Syntax, import, inventory, or unrelated shape failures do not establish this runtime relation.

The substitution phase must create no additional admission or child execution. Cleanup must preserve the separately held legitimate run until its own explicit close.

## Preserve the useful audit evidence—and its limits

**The restart’s opening and preservation succeeded.** There is no reason to repeat a procedural restart, reset the index, or recreate the candidate. The earlier failed interval remains separate.

This audit authenticated the exact candidate and produced a direct hostile A12 specimen. It did **not** establish A01–A11 or A13, complete the semantic review, or execute the independent six-group/full-suite validation. The writer’s **9,044 passes remain prior implementation evidence**.

Those omissions must remain explicit through the repair and subsequent re-audit. Fixing this finding will not imply that the remaining evidence graph, native transactions, process boundaries, or model causality have independently passed. The mandate requires a predicate-level ledger rather than promoting a normal-suite result into causal coverage. Coordinator_RW0_D2_Independent\_…

## Validation after repair

Only `test_rw0_d2_offline_integration.py` is permitted to change among test files. Therefore the module identities for `A0_D1`, `BINDING_COMPAT`, `A_NATIVE`, `A_EVIDENCE`, and `GUARDS` remain fixed. `B_MODEL` and the full inventory must be recomputed.

After the final edit, the repair writer must run all six focused collections/executions and the complete repository suite from a fresh, remote-free external copy. The count reconciliation is:

```text
final full count = 9,044 + (final B_MODEL count − 178)
```

That is bookkeeping, not a target to achieve by removing or selecting tests. No full-suite run per mutant is required. The later independent audit remains a separate gate. The existing validation mandate already distinguishes module identity, node identity, and actual execution. Coordinator_RW0_D2_Independent\_…

## Complete repair handoff

Send this to the **implementation Codex conversation that completed D2 Continuation 04**, not the independent auditor.

:chatgpt-content-reference{index="5"}[Download the complete D2 authority-role-binding repair prompt](sandbox:/mnt/data/Coordinator_RW0_D2_Authority_Role_Binding_Audit_Repair_V1_Prompt.txt)

```text
Filename:
Coordinator_RW0_D2_Authority_Role_Binding_Audit_Repair_V1_Prompt.txt

Bytes:
62,281

SHA-256:
6491be1e40a0eb0ca76f03999a7519fca1620c7b8591a2612f22b4cd22d03ff3

Lines:
922

Final newline:
present
```

It binds the unchanged opening:

```text
HEAD:
43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18

Baseline tree:
cc3cc104300f553ada581cee24e80dab6dd885b1

Candidate:
47 modified tracked paths + 23 creations = 70 changed paths

Replacement stream:
5,778,185 bytes
c7eb1f23446134391adb4d0a460dc489bbb5abe31376e75af86e4f5a4a6cc25c
```

The prompt includes all 70 receipts, the existing pre-Git mechanism, the three-file ceiling, role and consumer requirements, focused causal controls, exact validation selections, and preservation rules. It requires no historical mutant attachment or further mapping pass.

Success is:

```text
RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_REPAIRED_V1_VALIDATED_READY_FOR_REAUDIT
```

That supports a newly issued independent re-audit. It authorizes **no acceptance, staging, publication, Section 41 post-execution persistence, rank-15 admission, physical C2, new migration, live provider/supplier work, ES/Bridge integration, or RW0-E**.

## Evidence boundary

I reviewed your latest audit report and the relevant operative mandate, and inspected the baseline authority-value, C1 identity, reconstruction, and historical-time contracts as inert source. I corroborated the 47 baseline blob identities, 23 baseline absences, replacement arithmetic, and six focused/full module inventories using baseline bytes plus supplied candidate hashes.

I reopened the repair prompt and syntax-checked its embedded opener/helper without executing it. **I did not inspect the current live D2 files, reproduce the swap, run repository tests, or verify the live aggregate myself.** The defect and latest preservation interval remain attributed to the independent auditor.

Some earlier uploads have expired. Please re-upload a specific historical original when a later byte-level comparison requires it; the materials needed for this handoff were available.

**Sources:** Your latest independent audit closeout; the restart mandate cited above; the Coordinator snapshot’s authority and C1 source boundaries identified here.

**Confidence:** High on the relational repair and three-file scope. Implementation adequacy, complete independent validation, and commit eligibility remain unresolved.
