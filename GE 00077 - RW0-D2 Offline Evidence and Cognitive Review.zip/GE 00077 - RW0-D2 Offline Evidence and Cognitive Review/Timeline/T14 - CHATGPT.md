## Disposition

**Accept the scope stop. Preserve the retained D2 candidate, add the B2a test to the implementation ceiling, and complete final validation. Do not send these bytes for independent audit yet.**

This is a guard-dependency correction, not a new D2 architecture problem. The test was already included in the required `GUARDS` selection, but I omitted it from the permitted edit ceiling. Codex correctly stopped rather than hiding the required profile fields or editing an unauthorized path. Pasted text

The continuation needs two corrections: the narrowly scoped test amendment and authentication of a malformed provenance entry. Neither calls for discarding the implemented source.

## 1. Narrow only the conflicting `expiry` check

The snapshot confirms the reported failure mechanism:

```text
tests/test_b2a_writer_session_contract.py:90–91
    _source() concatenates every Python source file.

tests/test_b2a_writer_session_contract.py:481–507
    The B2c writer-boundary test rejects “expiry” in that complete text.
```

The owning writer contract prohibits TTL-, heartbeat-, takeover-, or durable-row-based reconstruction of writer authority. That is different from D2 carrying data about **source-evidence expiration**. See `.docs/writer-session-authority.md:134–141,665–684`.

The current pure post-execution owner also binds source-profile schemas, identities, and canonical profile digests. Altering profile content merely to placate an unrelated lexical scan is not the right repair. See `_post_execution_evidence_values.py:138–158,4940–5028`. The particular `at_or_after_expiry` and `expiry_fields` occurrences in the new D2 file remain Codex-reported until the continuation inspects those payloads. Pasted text

**The selected correction is smaller than narrowing the whole B2a test.**

Keep `_source()`, `_source_without_lock()`, and `_sqlite_sources()` unchanged. They serve other assertions. Move **only the `expiry` prohibition** to an explicitly named, fixed writer-authority source set covering the writer protocol, issuance/session/lock owners, and their connection/fencing/transaction machinery.

Every other existing forbidden fragment remains checked against its existing input. Preserve the release-marker, proof, public-interface, SQLite-row, lock-exclusivity, migration, network-client, and sole-subprocess-owner checks.

This avoids turning one legitimate vocabulary collision into a blanket exemption for D2—or weakening unrelated tests by changing what `_source()` means globally.

### The amended test must prove both sides

The permanent controls must establish that legitimate profile data outside writer authority passes, while a `writer_expiry` declaration in a protected authority source fails the **actual owning check**. Removing that scoped enforcement must make its fixed negative control fail. A still-global prohibited fragment outside the scoped owner set must remain rejected.

These are bounded source-guard controls, not a general Python analyzer or a new runtime expiry mechanism. No production change is indicated merely to resolve this blocker.

## 2. The provenance “correction” is still invalid

The closeout’s baseline blob entry for:

```text
.docs/rw0-c2-first-live-proof-posture.md
```

contains a malformed value. Its subsequent attempted correction is also malformed: it has **35 characters**, not a valid 40-character Git object ID. It must not be carried forward as verified. Pasted text Pasted text

The mounted baseline and the issued continuation agree on:

```text
Correct baseline blob:
4b69e424655ea67900f6c6042c0cbacaf2d53f8a

Baseline bytes:
16,985

Baseline SHA-256:
c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e
```

That is a source-backed correction to the **reported baseline coordinate**, not permission to change the current document. The prior mandate contains the same valid receipt. Coordinator_RW0_D2_Implementati…

The reported current document remains a separate expectation:

```text
17,674 bytes
ba61008234eb5ec85416c459dab0a82b19f7e1a0662dcb15f1289ba445fdf5bd
```

**Before any edit or executable validation**, Codex must read the actual baseline blob, authenticate all 67 current endpoints, and reproduce the supplied aggregate using the correct baseline coordinates.

If everything matches the same fixed aggregate, this is a report-transcription correction with no candidate mutation. If it does not, stop with the precise provenance discrepancy. Do not silently replace the aggregate or “repair” a payload to fit the report.

The aggregate’s length accounting is consistent:

```text
Payload bytes:       5,601,299
Encoded row bytes:   5,606,463
Prefix:                     25
Total:               5,606,488
```

I checked that arithmetic. **I have not reproduced its SHA-256 from the live payloads.**

## Preserve the substantial implementation progress

The report now describes both A and B source paths, the distinct bound-effect binding, native commits and recovery, checked C1 families, separate checking processes, nine-role model input, and a transient proposal handback. This is no longer the ten-file prototype from the preceding stop. Pasted text

It also reports useful focused execution: both bound-effect variants and replay, commit-uncertainty recovery, fourteen checked members, five child roles, and all five recommendations. Those remain **implementation observations**, not independent acceptance or proof that every required causal boundary is covered. Pasted text

In particular, the reported call-path diagram is a summary. The actual qualification/admission sequence and writer-close-before-child ordering must remain supported by the lower-level observations. Likewise, disposal of the underlying D1 state and cleanup of D2’s reconstructed workspaces are separate custody obligations; the report’s shorthand does not merge their ownership.

The new continuation does not reopen the author-only binding, receipt projection, SQL schema, C1 rank inventory, or preadmission endpoint.

## Final validation has not been completed

The report is appropriately explicit about its stopping point:

| Group | Reported pre-repair result |
|---|---:|
| `A0_D1` | 116 passed |
| `BINDING_COMPAT` | 160 passed |
| `A_NATIVE` | 118 passed |
| `A_EVIDENCE` | 659 passed |
| `B_MODEL` | 178 passed |
| `GUARDS` | 3,891 passed; five failed |

Four guard failures were subsequently corrected, and a focused recheck left only B2a failing. **The six complete groups and full repository suite were not rerun on the closing bytes.** The earlier successes therefore cannot be presented as final-candidate validation. Pasted text

The continuation requires all six groups, followed by complete collection and execution, from a fresh final external copy. B2a already belongs to `GUARDS`; no new validation group is needed.

The reported hashes are labeled “collection inventory.” Their serialization is not sufficiently specified to equate them with earlier **test-file inventory** hashes. The next closeout must distinguish module-byte inventories from collected-node inventories and preserve complete parameterized node IDs.

The original finite causal campaign also remains required. The report details three transformed-copy results, including a C1 mutation initially masked by a redundant check. Those observations cannot automatically close every original obligation. Preserve substantiated completed evidence, execute the missing or affected bounded controls, and keep the failed one-layer experiment’s limitation explicit. Pasted text

No full-suite-per-mutant requirement is added.

## Continuation boundary

The only newly authorized file is:

```text
tests/test_b2a_writer_session_contract.py
```

The maximum ceiling becomes **78 paths: 55 existing paths and 23 creations**. The primary expected change is that one test. The 67 retained candidate endpoints should otherwise remain unchanged.

The original ceiling remains available only for a concrete unfinished original requirement or an observed in-scope validation defect—not opportunistic rewriting. Any additional change needs its reason, exact endpoint transition, and rebuilt final validation.

The new opening is:

```text
44 modified tracked paths
23 untracked creations
219 other tracked working files equal HEAD
263 unchanged baseline index entries
286 current source endpoints
```

The opener now authenticates the **reported D2-edited `AGENTS.md`**, not the older D1 HEAD payload. It does not demand a clean checkout or recreate the previous ten-file overlay.

The post-opening raw `git status` remains a procedural deviation. Reported opening/closing equality supports those observed endpoints; it does not prove every intermediate command was metadata-inert. Similarly, the missing historical OS-mode record for the protected test is not reconstructed. Neither establishes source damage or warrants resetting the candidate. This continuation records its own complete opening and uses the guarded inspection path. Pasted text

## Complete implementation continuation

Send this to the **same implementation Codex conversation that retained the 67-path candidate**.

:chatgpt-content-reference{index="10"}[Download the complete D2 B2a-guard and validation continuation prompt](sandbox:/mnt/data/Coordinator_RW0_D2_Implementation_Continuation_02_B2a_Guard_Prompt.txt)

```text
Filename:
Coordinator_RW0_D2_Implementation_Continuation_02_B2a_Guard_Prompt.txt

Bytes:
126,024

SHA-256:
6b1daaa87e916ab8352e7c3ebd0f9db6c7a50721dfd9426c62732ae799b8e198

Lines:
1,808

Final newline:
present
```

It binds the current **reported** opening candidate:

```text
HEAD:
43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18

Baseline tree:
cc3cc104300f553ada581cee24e80dab6dd885b1

Replacement:
67 rows — 44 M / 23 C
5,606,488 bytes
4de3b2fe6ea31dcfc258cc214bc998eb27958be3025e39ac693e3489b7508017
```

The replacement prompt includes all 67 endpoint receipts, the explicit malformed-cell reconciliation, the updated guidance opening, the complete 78-path ceiling, retained implementation requirements, six exact validation selections, and preservation rules.

Success remains:

```text
RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_IMPLEMENTED_VALIDATED_READY_FOR_INDEPENDENT_AUDIT
```

That supports an independent audit of the complete uncommitted candidate. It authorizes no staging, publication, Section 41 post-execution persistence, rank-15 admission, physical C2, migration `0005`, live provider/supplier work, ES/Bridge integration, or RW0-E.

## Evidence boundary

I read the closeout and relevant continuation requirements, inspected the snapshot’s complete B2a test and relevant writer-authority/profile owners as inert source, and reauthenticated the 263-file snapshot tree. Its tree matches `cc3cc104300f553ada581cee24e80dab6dd885b1`; the archive CRC check passed.

I checked the 67-row arithmetic, corroborated all 44 baseline blob coordinates—with the one explicit correction above—and verified all 55 existing-path baseline receipts in the new ceiling. The generated prompt was reopened, and its embedded instrumentation was syntax-checked, not executed.

**I did not inspect the live D2 payloads, reproduce their aggregate, or run repository code or tests.**

Some older uploads have expired; re-upload a specific historical original when a later comparison requires its bytes. The current report, mandate, and snapshot were available.

**Sources:** Codex’s latest continuation closeout and the issued continuation mandate, cited above; Governed Execution Coordinator - Snapshot - 2026-10-16.zip[Coordinator snapshot](sandbox:/mnt/data/Governed%20Execution%20Coordinator%20-%20Snapshot%20-%202026-10-16.zip), particularly `tests/test_b2a_writer_session_contract.py:90–107,452–507,594–631` and `.docs/writer-session-authority.md:134–141,665–684`.

**Confidence:** High on the narrow guard correction and baseline-coordinate correction. Live candidate authentication, complete final validation, and implementation correctness remain unresolved.
