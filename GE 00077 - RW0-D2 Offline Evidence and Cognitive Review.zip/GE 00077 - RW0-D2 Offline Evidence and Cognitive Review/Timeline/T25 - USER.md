Turned out I sent the audit prompt twice to two different chats.

First Codex chat replied:

````
`RW0_D2_REPAIR_PROVENANCE_BLOCKED`

The authority-role repair is implemented and the final source copy passed all required tests. The ready-for-reaudit token is blocked by one closing preservation check: four `refs/codex/turn-diffs` entries differed from this repair interval’s authenticated opening. No Git write was authorized to restore them. HEAD, branch, upstream, index, guidance, cache, worktree count, and all candidate payloads otherwise matched their required identities.

The visible model family was GPT-6; the exact selected model and reasoning-effort setting were not visible. Permissions were `danger-full-access` with approval policy `never`.

## Repair and observed behavior

[The checkpoint validator](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2a_handback.py:213>) now binds each authority observation to its fixed checked C1 family and existing role lineage:

| Role | Source slot | C1 family slot | Membership | Effect and fence |
|---|---:|---:|---|---|
| Validation | 0 | 6 | `membership.d2.validation-authority` | `validate_candidate`, `effect-fence.d2.validation` |
| Review | 1 | 7 | `membership.d2.review-authority` | `review_candidate`, `effect-fence.d2.review` |
| Author | 2 | 13 | `membership.d2.author-authority` | `author_candidate`, D1 author fence |

The producer’s actual rank sequence was `(12,12,12,12,13,14,1,1,5,6,12,6,12,1)`. After existing node validation, the repair joins schema/ref/digest through the registry, typed payload, membership, receipt, and admission result; compares the complete canonical observation with the reconstructed admitted value; and checks phase, membership, relation operands, attempt/grant/command coordinates, role fence, and validation/review qualification pointers. It checks retained historical evidence without sampling current authority or time.

[The final handback](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2_handback.py:110>) already revalidates its *present* checkpoint and joins its families to `checked_admissions`, so that file remained byte-identical. The first repair attempt added an import rejected by an architecture guard; I removed it and used the checkpoint’s existing import surface. The affected 166-test architecture module then passed.

The opening candidate’s real 0/1 validation/review source swap was accepted by both checkpoint and ready-handback validation despite mismatching family 6. On the repaired candidate, the unmodified ready run and a separately reconstructed, canonically equal observation pass. Seven individually named cases reject source transpositions, duplication, family-only movement, paired source/family movement, and a valid resealed same-role alternate with the existing content-free checkpoint error. A one-sided family-value substitution is rejected by the checked-family validator. Forged exact wrappers independently reach and fail the final ready and genuine complete-evidence stopped consumers; an early stopped path without a checkpoint remains valid. The in-memory substitutions left the database hash and child IDs unchanged. The observed five child processes were reaped and owned runs closed.

Final-byte causal controls each collected all 19 integration nodes:

- J01 removed the checkpoint’s role-join call. Its normal positive passed; the source swap, paired swap, and same-role alternate each failed their rejection tests with `DID NOT RAISE`. Full-copy SHA-256: `aac29b39dfcf66feede02ca23b7e7cc68e256ac646d7b910f3900bb0292d6507`; target endpoint `7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f` → `6b790c21c9ec1c7c7798cf7f33c9351512f0852123d031e3c178aeeada3d3408`.
- J02 removed only the final checkpoint-validation call. Its normal positive and direct checkpoint rejection passed; the forged ready and complete-evidence stopped consumers failed their rejection tests with `DID NOT RAISE`. Full-copy SHA-256: `c180e53c772fd8c90d0ec6b1d080960b6433d23c23c7462a47edf0f3345672de`; target endpoint `1e4fddda53315d7a14d042780730e0cce07b9a5c67d41233ddff550a430ac24f` → `24b2975d5df6002e7aad5850b4055402e5fbccc1e7bd095656c06260ca21ae13`.

Both mutants changed only their stated endpoint, parsed and imported, retained the complete integration collection, and matched their 286-file manifests after execution. The repaired [integration module](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_d2_offline_integration.py:134>) passed **19/19**.

## Final-byte validation

Every group was collected and executed serially in the external `final3` copy. Each command used Python 3.13 with `PYTHONDONTWRITEBYTECODE=1`, `PYTHONPATH=.:src`, an owned `TMPDIR`, `-B -m pytest -q -p no:cacheprovider`, and separate owned `--basetemp` locations for collection and execution. Collection added `--collect-only`; FULL used no test-path selector. The complete 286-source manifest was checked before and after every command. Its disclosed full-copy SHA-256 was `15f225e8016671326b693f3e9d7c94c41d6699afe7b63d680cfd9ef4b792fb30`.

| Selector | Modules | Collected and passed | Module SHA-256 | Node SHA-256 |
|---|---:|---:|---|---|
| A0_D1 | 7 | 117 | `bd79dcd6261a545b90e3709e7bff2b16fa00d9fb71f67baa4082f71de6b75236` | `8ba8dc88ab588e3e12d56d8c3db542b08f04ddb1d1714a4e687e62697ab849ad` |
| BINDING_COMPAT | 7 | 160 | `0851123786b9bcbab0f2f417539ec3d1a0e6ffc753c4075e3d33b15e27dccd30` | `fddc0c493b032ecac479c59e6480a1f58c52759b8133f829795f6a82d8856806` |
| A_NATIVE | 11 | 118 | `07f8d2d3b7f971ab76b23f537de7985ed9e5388c5f5f69dc6d5d3b9d995fc22d` | `d5911062ec95a45b37662d236c0fb9af7374ccaee193da0a423f1f0019c3dfdd` |
| A_EVIDENCE | 5 | 659 | `d74195c30fd2f5c9e56591b2365651836ec7c982d0c1fe96da3f1fc26850b1ba` | `8c27f90a27da2fe62242f3bf3c368b2ce5792e102354c685bc8d99e1e19c35f2` |
| B_MODEL | 8 | 188 | `c4e8491566196799126a07839fd714357cc2576a3d3f4fd6b341f244cc9a5e05` | `22c8bac05f6006ceae1fa0867b4ea669978dfd0cfa2655eb1881827bfc73f406` |
| GUARDS | 24 | 4,162 | `4533bd1c1f6ee61c1e96847b3d6ce684af46046304ae9a6df28348eaace2b617` | `547c990efa2ac226f2316e0d3c276b6709afa0c4deb20493a1e3db2230b9260b` |
| FULL, no paths | 131 | **9,054** | `c60be07b4de88c1fceee2942a6dcae343645e1a7f9a2879ff0de57b4df596d46` | `4f16c9ad98b8a6377413ef77b062fd88ae0fdf31b8d686fb07bb51e8d6e8100b` |

The exact selector paths, all under `tests/`, were:

```text
A0_D1:
test_rw0_d1_handback_values.py test_rw0_d1_offline_integration.py
test_rw0_d1_planner_process.py test_rw0_d1_process_frames.py
test_rw0_d1_process_supervisor.py test_rw0_d1_worker_process.py
test_rw0_d1_workspace_capsule.py

BINDING_COMPAT:
test_c2b3c_author_effect_contract.py
test_c2b3d_author_effect_establishment_contracts.py
test_c2b3d_author_effect_establishment_recovery.py
test_c2b3d_private_atomic_author_effect_establishment.py
test_c2b3d_private_author_effect_delegation.py
test_worker_execution_semantic_relations.py
test_worker_execution_semantic_vectors.py

A_NATIVE:
test_rw0_c1_mutation_contracts.py test_rw0_c1_private_atomic_persistence.py
test_rw0_c1_private_readers.py test_rw0_c1_reader_contracts.py
test_rw0_c1_recovery.py test_rw0_c1_row_values.py
test_rw0_c1_semantic_values.py test_rw0_c1_writer_session_delegation.py
test_rw0_d2_bound_effect_contracts.py test_rw0_d2_bound_effect_persistence.py
test_rw0_d2_c1_checked_readback.py

A_EVIDENCE:
test_post_execution_pure_owner_relations.py
test_post_execution_pure_owner_values.py
test_rw0_d2_c1_checked_readback.py test_rw0_d2_evidence_children.py
test_rw0_d2_process_frames.py

B_MODEL:
test_rw0_d2_model_handback.py test_rw0_d2_offline_integration.py
test_section41_cognitive_proposal_row_values.py
test_section41_cognitive_proposal_semantic_values.py
test_section41_pre_execution_plan_disposition_contracts.py
test_section41_pre_execution_plan_disposition_recovery.py
test_section41_private_atomic_pre_execution_plan_disposition.py
test_section41_private_pre_execution_plan_disposition_delegation.py

GUARDS:
test_architecture_contracts.py
test_autonomous_software_development_operating_model.py
test_b2a_writer_session_contract.py test_b3a_persistence_contracts.py
test_b3b2a_read_scope_and_query_contracts.py
test_b3b2b_select_readers.py test_b3c4c_prerequisite_contract.py
test_c2a_nonimplementation.py test_c2b0_durable_state_contract.py
test_c2b2_development_reader_contracts.py
test_c2b2_development_row_value_boundaries.py
test_post_execution_pure_owner_boundaries.py
test_post_execution_pure_owner_vectors.py
test_runtime_non_authority.py test_rw0_b1_boundaries.py
test_rw0_b2_capability_boundaries.py test_rw0_b2_wire_boundaries.py
test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
test_rw0_c2_durable_progression_decision_semantic_contract.py
test_rw0_c2_private_value_versioning_contract.py
test_rw0_remote_contact_phase_entry_contract.py
test_sqlite_b1_runtime_boundary.py test_sqlite_b2c_writer_session.py
test_sqlite_backend_b0_contract.py
```

The six groups contain 5,404 occurrences and 5,402 unique nodes. Their only overlap is two `test_rw0_d2_c1_checked_readback.py` nodes shared by A_NATIVE and A_EVIDENCE. The full suite contains all group nodes plus 3,652 others. GUARDS and FULL each emitted only the three expected Python 3.13 multithreaded-fork `DeprecationWarning` records, at `multiprocessing/popen_fork.py:67` and `test_sqlite_b2c_writer_session.py:1442,1554`, for the three specified writer-session nodes. No warnings were suppressed.

A preliminary model execution was interrupted after collection and was rerun to completion. An earlier guard run had 11 failures caused by the added import; after correcting that boundary, the final-byte architecture module, all six groups, and FULL passed. These preliminary results are not counted as final-byte passes.

## Closing provenance and blocker

The authenticated subject remained `feat: add RW0-D1 offline process and capsule spine`, HEAD `43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18`, tree `cc3cc104300f553ada581cee24e80dab6dd885b1`, and sole parent `0d0926e3a483a3ab1a4fd597ac0495927352bf35`. Branch `trunk_dev`, locally observed `origin/trunk_dev`, and 0/0 divergence remained fixed; there was one worktree. The 263-entry stage-zero index, guidance, and opaque cache directory plus 37 members matched their opening bytes and metadata. Status remained 47 modified tracked plus 23 creations, with no staged change. All 67 protected candidate endpoints and 216 other tracked endpoints were exact; modes, tracked whitespace, all 23 creation no-index whitespace checks, UTF-8, and final LF checks passed.

All 70 opening replacement rows were confirmed, with only these three authorized C-status endpoints differing as shown:

| Endpoint | Opening bytes / SHA-256 | Closing bytes / SHA-256 |
|---|---|---|
| `_rw0_d2_handback.py` | 13,339 / `1e4fddda53315d7a14d042780730e0cce07b9a5c67d41233ddff550a430ac24f` | **unchanged** |
| `_rw0_d2a_handback.py` | 11,551 / `9c28eff0a2e042b735ae9bdc40a8fe6f387027db53b80ec41e434d0ae92bb338` | 20,455 / `7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f` |
| `test_rw0_d2_offline_integration.py` | 7,008 / `d6d2b0d445b9151d811f4df426f5a8d66b7c9221d85c33bd9b4a9b9254bc7916` | 19,540 / `b6f9f0d7906b22e116d25e09dd4ed42eb48c33af9dd6aeeba7c56406b2b1808a` |

The opening 70-row replacement was 5,772,762 payload bytes, 5,778,185 total encoded bytes, SHA-256 `c7eb1f23446134391adb4d0a460dc489bbb5abe31376e75af86e4f5a4a6cc25c`. Two fresh closing calculations agreed at 5,794,198 payload bytes, 5,799,621 total encoded bytes, SHA-256 `f7b8580df9a59f1270858ddf316f5bab2fafec5079a77c4e41d7bda6a4abc05e`.

The ref-list exception was exact. Two opening entries disappeared:

```text
refs/codex/turn-diffs/captures/1792391206851/6906c3d0-a90d-4f9a-bbdc-1c5d0a4d03bb/base 014f6845ec3672c7a2c2e54f8745e8d2e0505a06
refs/codex/turn-diffs/checkpoints/9cdec58754d2008c5f9d1c798eb1508d/e39bda8d697aa440e3e73d7ec57ce3e1/1792391151519/cf8c33b8-0d66-474f-b9bf-8dea4258f2f2 014f6845ec3672c7a2c2e54f8745e8d2e0505a06
```

Two closing entries appeared:

```text
refs/codex/turn-diffs/captures/1792397725974/53e8e119-ec56-4a4b-aa85-14932711d248/base 1450a5e4845d20d9199004ea862ebdeadb8139e0
refs/codex/turn-diffs/checkpoints/9cdec58754d2008c5f9d1c798eb1508d/5b28b0639b3a0d0101b64c63dda76ece/1792397668681/34819c59-8638-4570-ac9f-34222d209428 1450a5e4845d20d9199004ea862ebdeadb8139e0
```

The cause of that ref rotation was not established. It prevents the prompt’s exact opening-to-closing **ref preservation** claim and therefore prevents `READY_FOR_REAUDIT`, despite the completed repair and passing tests. The positively owned external test root was removed and its removal verified; the uncommitted repaired candidate remains in the checkout. Independent A01–A13 audit and acceptance remain pending.
````

Second Codex chat replied:

```
RW0_D2_REPAIR_PROVENANCE_BLOCKED
The original implementation chat, “00077 54,” completed the authority-source repair in the [checkpoint validator (line 213)](/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d2a_handback.py:213) and added [integration tests (line 134)](/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_d2_offline_integration.py:134). The final handback file remained unchanged.
The repaired candidate passed 19 integration tests, all six focused groups, and the 9,054-test full suite in external copies. Both causal omission controls produced the expected failures.
The ready-for-reaudit verdict is blocked because two refs/codex/turn-diffs refs present at the authenticated opening were replaced by two different refs at closing. Their cause was not established. All other required preservation checks passed, but the prompt required exact ref preservation and prohibited Git writes to restore them. The external test root was removed; the uncommitted repair remains in the checkout. Independent re-audit remains pending.
```
