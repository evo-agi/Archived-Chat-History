## Disposition

**Approve source entry for one integrated RW0-D2 implementation tranche, with the corrections below overriding the map. Do not commission another mapping pass or standalone contract tranche.**

The closure now supplies enough source-grounded structure to begin implementation: the original adapter observation has an explicit retention path, event timestamps have identified producers, the bound-effect family fits the selected existing representation, and C1 readback has a proposed guarded interface. These remain **implementation plans, not executed capabilities**. Pasted text Pasted text

I am **not adopting the map’s type tables verbatim**. They contain a live-custody contradiction and two writer-interface problems that should be resolved directly in the source mandate—not carried into implementation or sent through another reconnaissance cycle.

A and B remain internal development checkpoints:

```text
A — bound effects, checking processes, admitted evidence and readback
B — evidence-bound model input, fake review model and preadmission handback
```

There is one final candidate, one integrated acceptance review, and no user relay between A and B.

## 1. Remove live custody from the evidence graph

The map says its proposed checkpoint contains no live handle, but then gives it:

```text
run_owner: RW0D1OfflineRun
```

and places that checkpoint inside the final `RW0D2PreadmissionHandbackV1`. That would transitively put the live disposable-state owner into the purported evidence-only handback. Freezing the dataclass, hiding its representation, or prohibiting serialization would not remove that capability. **This is a contradiction in the proposed design, not a leak in implemented D2—D2 does not exist yet.** Pasted text

The selected correction is:

```text
RW0D2EvidenceCheckpointV1
    immutable, resource-free evidence only

RW0D2PreadmissionHandbackV1
    resource-free evidence, proposal and outcome values

RW0D2OfflineRun
    separate parent-only wrapper around the original RW0D1OfflineRun
    and the final handback
```

The original WorkSpec and fixture remain private composition inputs rather than fields in the evidence checkpoint. Safe references and digests may be retained as data where needed.

The outer entry remains:

```python
run_rw0_d2_offline(work_spec, fixture, *, cancelled=None)
```

It invokes D1 exactly once. An internal continuation may borrow the resulting D1 owner in that same creator process, but it is not a user-facing prerequisite or a second lifetime authority. It cleans its own new resources; it must not delete an unrelated run merely because that run was supplied in a negative test.

This preserves the existing D1 separation between the handback and `RW0D1OfflineRun`, rather than undoing it through a nested field. See `_rw0_d1_handback.py:105–121,252–309`.

## 2. Give the bound-effect command the evidence its writer must validate

The proposed reducer accepts the actual capsule and requirement evidence. Its returned command, however, lists principally references and digests for those values. The writer is then expected to revalidate the capsule after fencing. The capsule is transient D1 evidence, not an existing persisted object that can simply be reloaded from those coordinates. Pasted text

**A digest is a binding, not the value being checked.**

The source mandate requires the private command to retain the actual typed capsule, requirement evidence, and bounded immutable before/after blobs needed by the existing capsule relation. It also retains the exact proposed fence and delivery values that the guarded store must independently compare with their canonical reconstruction.

That follows the established author-command pattern, which carries typed assertions and values rather than relying on unattached hashes:

```text
_development_author_effect_establishment_contracts.py:649–715
_development_author_effect_establishment_contracts.py:879–890
```

The existing capsule validator explicitly consumes original and resulting blobs as well as the manifest and lineage. See `_worker_execution_semantic_values.py:4169–4237`.

The new command’s canonical identity must bind these retained inputs using the existing semantic mappings and computed path/length/digest descriptors. Raw file content stays private and transient; it does not become a new SQL column, public field, log payload, or authority claim.

The writer must still reload the authoritative program, attempt, candidate, author command/fence, selection, and phase predecessors **after fencing**. Retained command values are assertions to verify—not substitutes for those owner reads.

### Keep the operation result separate from the receipt projection

The map proposes a richer operation result under the schema already reserved for the narrower bound-effect receipt projection. Those are different ordered structures. Pasted text

The mandate therefore selects a distinct private operation-result identity:

```text
governed-execution.nwp-development-bound-effect-establishment-result.v1
```

while preserving the existing receipt projection:

```text
governed-execution.nwp-establish-development-bound-effect-intent-result.v1
```

This mirrors the current author-effect implementation’s separation between its operation result and receipt result. See `_development_author_effect_establishment_contracts.py:53–70` and `_development_decision_row_values.py:390–415`.

**No migration or existing receipt-schema change follows from this correction.**

## 3. Preserve the evidence sequence without inventing completion

The adapter retention and chronology proposals are suitable starting points. The implementation must retain the **same `adapter_exit` object and semantic identity used by D1 classification**, not synthesize a replacement in D2. Worker timestamps must be sampled at the actual named events; the parent exit observation is sampled at its own boundary. Pasted text

The normal evidence sequence also needs one explicit ordering correction: authority observations for the new validation and review fences cannot precede those fences’ actual committed families. The mandate establishes both bound-effect families before admitting evidence that refers to them, then qualifies each checking role before its child runs.

The reported fourteen-member success set remains the selected normal-path expectation:

```text
rank 1 × 3
rank 5 × 1
rank 6 × 2
rank 12 × 6
rank 13 × 1
rank 14 × 1
```

It is **not a requirement to populate fourteen members on every failure branch**. Failed or incomplete paths retain only the actual dependency-closed evidence reached. Rank 15 remains absent. The map itself distinguishes C1 admission from later currentness and model-entry checks; the implementation must preserve that distinction. Pasted text

For commit uncertainty:

```text
committed_exact
    may continue after the recovered result is verified and the writer closes

definitely_not_committed or unresolved
    stops this D2 invocation
```

There is no automatic retry or new command identity to work around uncertainty. The new recovery method remains readback-only.

The guarded C1 checked-family return must contain detached, validated values—not a cursor, connection, nominal capability, or a constructed “admitted” family copied from expected inputs. That is a distinct read interface, not a relabeling of the existing write-plan readback. Pasted text

## 4. Update the actual consumer guards, not only the D2 filename prohibition

The map’s proposal to update only S004’s absence claim and D2 inventory is insufficient. The current post-execution boundary tests also assert that the allocated values have no production callers and that their supplying modules have no production importers. Permitting new filenames alone would leave those direct restrictions inconsistent. Pasted text

The snapshot makes those separate checks visible at:

```text
tests/test_post_execution_pure_owner_boundaries.py:234–273
tests/test_post_execution_pure_owner_boundaries.py:313–326
```

The implementation mandate includes the fixed, explicit external-consumer amendments while preserving the six pure modules’ allocations, internal dependency graph, and no-I/O behavior. It does not authorize blanket acceptance of all `_rw0_d2*` consumers.

It also includes the coupled native SQLite and row-reader guards that the new bound-effect owner reaches:

```text
tests/test_b3b2a_read_scope_and_query_contracts.py
tests/test_b3b2b_select_readers.py
tests/test_c2b2_development_row_value_boundaries.py
```

These are coordinated assurance changes accompanying source implementation—not new authority, a return to dynamically generated expected identities, or permission to bypass guards through aliases.

## What the source tranche must deliver

The complete path is now fixed at the operating level:

```text
WorkSpec and artificial fixture
→ D1 once, retaining its actual adapter observation
→ guarded validation and review effect families
→ separately reconstructed validator and reviewer workspaces
→ two actual checking processes through the existing supervisor
→ applicable C1 admissions and checked readback
→ resource-free evidence checkpoint A
→ refreshed model-entry checks and exact nine-role input
→ one deterministic fake review-model process
→ canonical transient source/artifact/proposal values
→ resource-free preadmission handback B
```

The same Coordinator transaction controller remains the mutation owner. The same process supervisor remains the sole `Popen` owner. The same underlying D1 run owner retains disposable-state custody.

The reported conditional instruction about splitting work should not be denied or ignored. The reason to proceed as one source tranche is the selected reuse of these owners and the explicit internal checkpoints—not merely preserving the “D2” label. A newly discovered, unselected authority requirement would still stop implementation. Pasted text

**The result remains preadmission.** It introduces no Section 41 post-execution family writer, rank-15 membership, complete C2 decision-time basis, authoritative branch, acceptance fact, or terminal outcome. A later owner may reject the proposal as stale or conflicting without rewriting its historical recommendation. Pasted text

## Implementation ceiling and validation

The prompt has a **maximum 77-path ceiling**:

| Surface | Existing paths permitted to change | Authorized new paths |
|---|---:|---:|
| Production source | 8 | 15 |
| Tests | 27 | 7 |
| Guidance and documents | 19 | 1 |
| **Total** | **54** | **23** |

This is a ceiling, **not an instruction to modify every existing path**. Unneeded entries stay byte-identical. The other **209 baseline paths** are protected.

The protected surfaces include migrations 0001–0004 and their catalog, package exports, `StateStore`, `pyproject.toml`, existing C1 rank semantics, and the deferred C2/Section 41 persistence boundaries. No staging or publication is authorized.

Development validation proceeds at A and B, then from a fresh final candidate. The acceptance checks must observe the real effects and their ordering: fenced writes and recovery, writer close before children, actual child inputs, genuine reconstruction and refusal, exact C1 readback, evidence-dependent model output, nested handback safety, and complete owned cleanup.

The mandate supplies bounded causal controls and exact focused selections, followed by one complete normal collection and execution. It does not demand a full suite per mutant or freeze the future count at the historical 9,005 tests.

**All repository execution occurs in owned, remote-free external copies.** The live checkout permits the authorized source/document/test edits and inert inspections only; its index, references, and known cache remain unchanged. If an implementation defect cannot be resolved inside the ceiling, Codex must retain the partial candidate and report the precise boundary—not automatically discard the work.

## Complete implementation handoff

Send this to **one parent Coordinator implementation Codex conversation**. It separately authorizes source work and replaces the previous mapping-only ceiling for that engagement.

:chatgpt-content-reference{index="11"}[Download the complete RW0-D2 implementation prompt](sandbox:/mnt/data/Coordinator_RW0_D2_Offline_Evidence_and_Cognitive_Review_Implementation_Prompt.txt)

```text
Filename:
Coordinator_RW0_D2_Offline_Evidence_and_Cognitive_Review_Implementation_Prompt.txt

Bytes:
84,090

SHA-256:
d92c0740a9a11a2f4f1d52aeb8832dddceca8260d7a46d1edbd2b55bdf061e43

Lines:
1,255

Final newline:
present
```

It binds the unchanged merged baseline:

```text
HEAD:
43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18

Tree:
cc3cc104300f553ada581cee24e80dab6dd885b1

Sole parent:
0d0926e3a483a3ab1a4fd597ac0495927352bf35
```

The prompt includes all baseline receipts for the permitted existing paths, the exact creation list, the corrected command/custody relationships, the opening mechanism, the A→B sequence, validation, provenance, and retained-work rules. No historical attachment or additional user handoff is required.

Success is:

```text
RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_IMPLEMENTED_VALIDATED_READY_FOR_INDEPENDENT_AUDIT
```

That supports an independent review of the **complete uncommitted candidate**. It authorizes no commit, publication, migration `0005`, physical C2, live provider/supplier work, deployment, ES/Bridge integration, or RW0-E.

## Evidence boundary

I read the closure report and issued scope, inspected the relevant snapshot producers, handback, command/result patterns, C1 readers, semantic values, and coupled guards as inert data, and reauthenticated the archive. Its 263 source leaves reconstruct the expected tree, and its CRC check passed.

I also verified all 54 allowed existing-path receipts, the absence of the 23 proposed creations, the validation-path inventory, and the generated prompt. Its embedded opening/helper code was syntax-checked, **not executed against your Mac**.

I did not inspect the live checkout, construct repository values, run tests, launch repository children, or open SQLite. The map’s local preservation claims remain Codex-reported; the new D2 implementation remains to be built and validated.

Some older attachments have expired. Re-upload a specific historical original when a later byte-level comparison needs it; the current report, mandate, and snapshot were available.

**Sources:** The current source-entry closure report and mandate, cited above; Governed Execution Coordinator - Snapshot - 2026-10-16.zip[Coordinator snapshot](sandbox:/mnt/data/Governed%20Execution%20Coordinator%20-%20Snapshot%20-%202026-10-16.zip), particularly the source and test references identified here.

**Confidence:** High on snapshot provenance and the identified custody, command, result-schema, and guard corrections. Medium-high on source-entry readiness; the new writer, evidence composition, and post-execution normalization still require implementation tests and independent audit.
