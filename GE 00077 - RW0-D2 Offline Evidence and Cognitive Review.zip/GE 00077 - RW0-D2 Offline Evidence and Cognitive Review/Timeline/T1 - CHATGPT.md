**Proceed with the bounded, read-only D2 implementation map. Do not authorize source changes yet.**

The map will select the exact implementation path for the second tranche of the existing RW0-D program—not create another contract tranche or a parallel C2 program.

:chatgpt-content-reference{index="0"}[Download the complete RW0-D2 implementation-map prompt](sandbox:/mnt/data/Coordinator_RW0_D2_Offline_Evidence_Cognitive_Review_Implementation_Map_Prompt.txt)

```text
Filename:
Coordinator_RW0_D2_Offline_Evidence_Cognitive_Review_Implementation_Map_Prompt.txt

Bytes:
47,433

SHA-256:
4ed82a7ddd8acc6fa1685e0ad6fc2b968db550ee068158f12f96e862b1fa68a7

Lines:
795

Final newline:
present
```

Send it to the **Coordinator implementation Codex conversation**, with the parent as sole mapper. It requires no historical attachment and authorizes no repository mutation, tests, child execution, network contact, or publication.

## The capability being mapped

The intended result remains:

```text
D1 capsule, immutable capture, committed lineage,
and same-process parent-owned disposable state
→ separate validator
→ separate independent reviewer
→ separate deterministic fake review model
→ typed post-execution proposal and evidence
→ C2-compatible final handback
```

One parent invocation must compose the stages without your copying messages or artifacts between them. The validator and reviewer must perform bounded checks on the actual reconstruction; the fake model must consume their bound evidence rather than merely echo a caller-selected outcome.

The existing D1 owner explicitly provides the retained capture and parent-only state lifetime for this continuation. It also explicitly leaves validation, review, model closure, and post-execution proposal production to D2. See `.docs/rw0-d1-offline-process-and-capsule-spine.md:41–68`.

## Three dependencies the map must resolve

### 1. Extend the existing supervisor without creating a second process owner

The current supervisor admits exactly two modules: the fake planner and fake coding worker. It is not already a generic executor into which three new names can simply be passed. See `_rw0_d1_process_supervisor.py:20–23,142–178`.

The selected default is a **narrow extension of that existing owner**, preserving D1 behavior and its process, child-input, timeout, cancellation, reap, and cleanup safeguards. A new supervisor or a general executor extraction needs a concrete dependency justification—not merely cleaner naming.

D2 must reconstruct validator and reviewer workspaces from the retained immutable evidence. It must not revive the deleted author workspace or send the Coordinator database location, writer authority, or run owner to a child. The current custody boundary is defined at `_rw0_d1_handback.py:252–309`.

### 2. Distinguish compatible values from actually admitted evidence

This is the most important unresolved implementation dependency.

C1 admits one evidence member at a time and requires dependency-closed membership. Its rank-15 member wraps **existing Section 41 post-execution source, artifact, proposal, and evidence rows**. It does not create those owner rows merely because their locators appear in an admission command. See `.docs/rw0-c1-durable-evidence.md:51–109` and `_sqlite_rw0_c1.py:2062–2076`.

The pure post-execution projection likewise consumes the complete owner family, reader tuples, and C1 admission evidence. Meanwhile, the inspected current Section 41 writer enforces the pre-execution phase. See:

```text
_section41_post_execution_proposal_family_projection.py:475–647,672–676
_sqlite_development_pre_execution_plan_disposition.py:435–500
```

**The map must locate the actual producer/writer path or identify the smallest missing source-bearing owner extension.** It must not import test fixtures, construct golden membership rows, seed SQLite directly, or call a preadmission proposal an admitted family.

This is not a conclusion that D2 is blocked. It is a concrete question the implementation map must answer before promising the end-to-end result.

The same distinction applies at the final C2 boundary. Some existing pure evaluators consume an already-derived authoritative branch. D2 cannot satisfy that argument by relabeling the fake model’s recommendation as Coordinator decision authority. See `_rw0_c_decision_input_values.py:1748–1765`.

The deliverable must therefore name the exact evidence/proposal classes D2 returns, the later C2 arguments they satisfy, and any genuinely later decision-time inputs. “Convertible later” without that mapping is insufficient.

### 3. Close the coupled guard dependencies before proposing an edit ceiling

The current post-execution tests enforce both **no runtime consumers** and **no D2 modules**. They also bind machine-record allocations and import relationships. See `tests/test_post_execution_pure_owner_boundaries.py:223–273,286–326`.

D2 will require coordinated changes to the relevant status and consumer restrictions. The map must follow those dependencies through B1, Wire, Capability, the independent registry projections, executable-module inventories, sole-subprocess ownership, protected document identities, and scoped C2 nonimplementation checks.

That coordination belongs **inside the later source-bearing D2 tranche**. It is neither permission to bypass the guards nor justification for another standalone semantic freeze.

The prompt requires one recommended create/modify/untouched file table with each path’s purpose and coupled owner/test. It does not authorize those edits now.

## What Codex must return

The operative map must contain the exact private entry and custody arrangement, the proposed call graph, evidence authorship and constructor mapping, the disposition of the evidence-writer dependencies, complete prospective touched surfaces, and one implementation sequence with internal checkpoints.

It must also propose the later acceptance tests and exact validation selectors. Those tests should observe actual effects and causal dependencies: distinct child invocations, correct writer-close ordering, real parent-state exclusion, verification before readiness, genuine refusal handling, reviewer separation, and truthful negative outcomes.

**No additional implementation program is introduced.** D2 remains one tranche; physical C2 follows it. Ordinary source decomposition is not a replan. A genuine replan requires an identified owning contradiction or an excluded authority/effect—not merely a stale file-count assertion.

The expected mapping outcome is:

```text
RW0_D2_IMPLEMENTATION_MAP_READY_FOR_REVIEW
```

That means the map is ready for review, **not that implementation is authorized**. Codex must instead report a precise replan or inspection blocker when the required output cannot be reached safely.

## Baseline and inspection limits

The prompt binds:

```text
Merged HEAD:
43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18

Tree:
cc3cc104300f553ada581cee24e80dab6dd885b1

Sole parent:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Branch:
trunk_dev
```

I rechecked the mounted archive: its 263 source leaves reconstruct the expected tree, and its CRC check passed. I inspected the relevant D1, C1, post-execution, projection, and consumer-boundary source as inert text. The merged commit/ref association remains merge-report-backed until Codex checks the live local coordinates.

I did not run repository imports, tests, processes, or SQLite operations. The generated prompt’s opening/helper code was syntax-checked, not executed against your Mac.

Some earlier uploads have expired. Re-upload a specific older original when a future byte-level comparison requires it; this map needs none.

**Sources:** Governed Execution Coordinator - Snapshot - 2026-10-16.zip[Refreshed Coordinator snapshot](sandbox:/mnt/data/Governed%20Execution%20Coordinator%20-%20Snapshot%20-%202026-10-16.zip), particularly the repository paths and line ranges above; PR #14 merge closeout for commit/ref attribution.

**Confidence:** High on the snapshot identity, D1 reuse boundary, and the specific dependencies the map must resolve. D2’s complete writer/constructor path and final implementation ceiling remain provisional until that map is reviewed.
