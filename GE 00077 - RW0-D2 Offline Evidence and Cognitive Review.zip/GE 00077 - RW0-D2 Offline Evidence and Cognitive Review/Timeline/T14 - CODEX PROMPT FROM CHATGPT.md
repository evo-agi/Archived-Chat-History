# Governed Execution Coordinator — RW0-D2 Implementation Continuation 02
# Retain the 67-path candidate; correct the B2a expiry guard and finish validation
# One integrated SOURCE implementation tranche; internal checkpoints A -> B

## 0. Authority, routing, and first protected action

Resume the SAME parent implementation Codex conversation that returned
RW0_D2_IMPLEMENTATION_REPLAN_REQUIRED for the whole-source B2a `expiry` scan.
This is an implementation/validation continuation, not an independent audit,
new mapping pass, new contract tranche or authorization to recreate D2.
Preserve the reported 67-path working candidate. This complete replacement adds
ONLY tests/test_b2a_writer_session_contract.py to the previous working-file ceiling:
55 existing permitted paths + 23 creations = maximum 78 paths.

The primary amendment is in that one newly authorized test. Keep the other 67
opening candidate payloads unchanged unless a concrete remaining original-mandate
obligation or an observed failing validation requires an in-ceiling correction.
Record every such extra change and its reason; no opportunistic rewrite, added
capability, schema redesign or unrelated cleanup. An unchanged runtime is the
expected result of fixing this reported blocker, not an unverified assumption.

First protected repository action: read live AGENTS.md as plain text from tool
workdir `/`:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

Read the complete output. Then run section 2's data-only opener BEFORE Git or
further protected inspection. External instruction reading as plain data is
permitted preparation; prefer absolute paths and neutral cwd. Do not begin with
status, .docs listing, repository imports or scripts. A cwd alone is not a Git
operation; an actual protected pre-opening action is a stop. Never reset the
index, restore timestamps or silently replace an opening interval.

After opening, authenticate the fixed Git baseline AND the complete section-2A
67-path overlay, including reconciliation of the malformed report cell, before
any edit or candidate execution. Do not require a clean working tree or the old
ten-file overlay. Then fix the scoped guard, close missing original causal
obligations, and execute all six final groups plus the full suite. No intermediate
user approval, A-only delivery, new parallel C2 program or user message relay.

No subagents, additional model sessions, provider calls or network. Use installed
tools and the highest reasoning setting actually exposed; report settings or
`not visible` without seeking account access. All repository imports, tests,
mutants, D1/D2 children and disposable SQLite fixtures run only in owned remote-free
external copies. Live effects are named working-file edits and inert inspection.

No staging, commit, push, PR, merge, fetch, ref/config/index write, live branch or
worktree change, dependency install, live-repository execution/SQLite, secret read,
operator-state access, supplier/source qualification, new public API/StateStore
surface, migration/catalog/SQL edits, Section 41 post-execution recording, C1
rank 15, physical C2/acceptance/terminal work, new author attempt, redelivery or
repair/replan loop, ES/Bridge/CP/IM/MA work, service or deployment.

The earlier post-opening raw status is a reported procedural deviation. Do not
claim it could not mutate metadata merely because it was intended as read-only.
The report's opening/closing equality is an endpoint observation, not a trace of
every intermediate operation. No pre-opening Git is reported in that interval;
no content damage is established. Preserve the limitation without resetting any
state. Establish this continuation's own opening and route every admitted live
Git inspection through its helper. Likewise capture current OS modes of all
source endpoints, including the known 0600 file; do not manufacture its missing
historical mode record. Neither limitation alone requires discarding the candidate.

Return ONE complete uncommitted candidate and a truthful inline validation report.
Ready means ready for independent audit, not accepted, committed, or live-capable.

## 1. Disposition and retained engineering decisions

The reported stop is justified: the protected B2a test scans all Python source and
forbids `expiry`, while D2's model-input source carries canonical expiry-related
profile data. The test was already included in final GUARDS validation but omitted
from the permitted edit ceiling. Correct that dependency here, not the profile's
spelling or the runtime's evidence meanings. No new writer-authority mechanism is
selected by this correction.

The last report describes A and B source implementation and focused execution,
not completed final validation. Five earlier groups passed; GUARDS had five
failures, four later corrected inside the old ceiling. Only focused rechecks ran
after those changes. The final six groups, full repository suite and complete
original finite campaign have NOT been established on closing bytes. Do not
promote pre-repair group results or three described transformed copies into that
claim. Treat all current source behavior as writer-reported until authenticated,
validated and independently reviewed.

The new bound-only safe binding is now reported implemented. The original
DevelopmentEffectAuthorizationSafeBindingV1, its author-only meaning, source,
fixtures, row factories and Capability P02 identity remain protected. C1-C6 below
remain the implementation requirements; they are not instructions to replace an
already conforming implementation. C7 selects the one new guard correction.

### C1 — evidence is not a live custody container

The map's RW0D2EvidenceCheckpointV1 included run_owner and was nested inside the
final handback. Do NOT implement that graph. Neither nonprinting nor disabled
serialization makes a live run handle into evidence.

- RW0D2EvidenceCheckpointV1 is immutable evidence ONLY. Remove run_owner, fixture
  and work_spec from its fields. The exact WorkSpec/fixture remain parent-local
  composition inputs; safe source identities/digests may be retained as data.
- RW0D2OfflineRun is the separate parent-only wrapper around the one original
  RW0D1OfflineRun and a resource-free final handback. It owns no second database,
  program head, selection, acceptance or progression ledger.
- Whole-graph handback validation rejects live run owners, paths, sessions,
  connections, descriptors, locks, nominal capabilities, arbitrary objects and
  mutable escape-hatch containers at every nested slot. Closed relative repository
  paths and opaque captured bytes retain their legitimate data meanings.
- Single-input entry: run_rw0_d2_offline(work_spec, fixture, *, cancelled=None)
  calls D1 exactly once. A private same-process continuation may BORROW
  (d1_run, work_spec, fixture) internally, but it is not the only entry and does
  not require the user to produce an A bundle. There is no generic public intent API.
- The outer creator owns disposal on uncaught failure. A borrowed continuation
  cleans only its new child/reconstruction resources and never deletes an unrelated
  run used as a test specimen. Explicit close and double close delegate to the
  original owner; wrong-PID/closed-owner access fails before state exposure.

### C2 — preserve the difference between operation result and receipt projection

The map reused `governed-execution.nwp-establish-development-bound-effect-intent-result.v1`
for a richer operation result. That existing schema belongs to the reserved
receipt result projection and has its own exact field order and digest.

Use a NEW private operation-result identity:
`governed-execution.nwp-development-bound-effect-establishment-result.v1`
with `.identity` domain, mirroring the existing author's distinction. Keep the
reserved receipt projection and its digest/schema/fields EXACTLY unchanged.
`DevelopmentBoundEffectEstablishmentResultV1` and its recovery wrapper are not
aliases for the receipt projection and cannot be interchanged.

### C3 — a digest-only command cannot carry an absent transient value

The map's reducer accepts a real capsule and requirement but its listed command
keeps only coordinates. D1's capsule and before/after bytes are not stored in
SQLite. Do not claim that the writer reloads them from owner rows.

The command must retain exact, nonprinting transient inputs sufficient to rerun
its pure checks AFTER fencing and during exact same-command recovery:
CandidateCapsuleManifestV1, the exact class-specific requirement evidence, and
closed immutable before/after blob tuples. Include the derived current
EffectFenceV1 and DeliveryEnvelopeV1 so the parent can use the SAME canonical
values after exact persisted-family confirmation. No arbitrary D1 run/capture
handle or filesystem path belongs in this native command.

Bind every retained value to the scalar coordinates and command digest. The
canonical identity includes the manifest, requirement's full safe identity and
self digest, current fence/delivery mappings, and ordered per-blob path/length/
SHA-256 bindings. Actual bytes remain in the closed command value for pure
revalidation, not in a public response, log or new SQLite payload column.
Recompute bindings from bytes before comparison; digests alone are not validation.
The private proposed command schema is new in this tranche; update its fixed
ordered fields and normative tests together. No existing schema is redefined.

### C4 — bind the admission order to actual owner existence

Use a complete dependency-closed positive case, not an instruction to seed 14
rows mechanically. Establish BOTH initial bound-effect families before creating
rank-1 evidence referring to their new fences. Then:
- admit actual historical D1 author observations (three) and retained adapter
  observation, rank-13 author result, and rank-14 classification;
- supply/admit artificial validation/review authority and readiness, then current
  validation qualification BEFORE validator launch;
- invoke validator, validate/admit its observation; qualify review immediately
  before reviewer, invoke reviewer, validate/admit its observation;
- obtain reviewer separation from exact checked C1 members/relations;
- freshly supply/admit author authority at A completion immediately before B;
- recheck expiry and current stop/head at B entry without pretending admission
  guarantees future currentness.
The normal complete case has ranks 1x3, 5x1, 6x2, 12x6, 13x1, 14x1 = 14 members.
Valid failure paths have their actually reached dependency-closed subset. Readback
or classification is not a membership producer; source evidence is not C2 policy.

### C5 — change all real consumer guards, not only an absence marker

The existing post-execution test does more than S004's no-D2 filename assertion:
`tests/test_post_execution_pure_owner_boundaries.py:234-273` also asserts no
production caller for all 44 allocations and no current-runtime import edges.
Admit only the exact new D2 external consumers while preserving the six pure
owners, their internal value/schema allocation and internal no-I/O DAG. Do not
change only S004 or dynamically accept every observed caller. Preserve historical
records; add a narrow explicitly current successor/consumer registry and fixed,
independently checked expectations as needed.

The native writer also reaches fixed SQLite, C2B row-value, and reader importer
sets. The additional coupled guard paths in section 4 are deliberate, supported
by current source: `test_b3b2a_read_scope_and_query_contracts.py:578-599`,
`test_b3b2b_select_readers.py:502ff`, and
`test_c2b2_development_row_value_boundaries.py:204-244`.
No general reader/export/subprocess permission is authorized.

### C6 — separate local safe-binding identity; preserve the author contract

Do not add _development_author_effect_establishment_contracts.py or its author
runtime/tests to the edit ceiling. The existing author-only class, its schema,
helper, digest vectors and Capability P02 protected content identity stay exact.
The wider-sounding class name is not a promise of support for bound effects.

Declare the new bound-only class and pure constructor/revalidator in
src/ge_nwp_coordinator/_development_bound_effect_establishment_contracts.py,
with its tests in the already authorized tests/test_rw0_d2_bound_effect_contracts.py.
Use that new exact type in the native command, the offline artificial source,
guarded writer checks, same-command replay/recovery, and evidence holding.
Use the existing requirement-evidence types without changing their owner.

The new schema describes a private assertion and local canonical binding, not a
source-authentication mechanism or effect permission. No SQL/C1/Wire/fence schema,
receipt projection, public export, extra source file or new migration is selected.
Document this new private type in the already authorized D2 owner and bounded C2B
current successor, leaving historical author schema/fixtures/machine blocks intact.

### C7 — narrow the `expiry` sentinel, not every source guard

Primary changed file:
`tests/test_b2a_writer_session_contract.py`.

Read the whole current test and the actual authority owner before editing:
`.docs/writer-session-authority.md:134-141,561-588,665-684`;
`state_store.py`, `sqlite_writer_state.py`, `sqlite_writer_session.py`,
`state_authority_lock.py` and the transaction/connection authority boundaries.
Read the actual D2 model-input occurrences and their supplying profile contract
as data. Required canonical profile data may not be renamed, split into strings,
encoded, loaded from a test, or hidden through dynamic construction to evade a scan.
A field describing source-evidence expiration does not grant writer TTL takeover.

Baseline test boundaries:
- `_source()` :90-91 concatenates ALL src/**/*.py.
- `test_b2c_contains_no_writer_release_takeover_or_reconstruction_runtime`
  :481-507 uses that text to forbid `expiry` among other fragments.
- `_source()` has OTHER callers; `_source_without_lock()` and `_sqlite_sources()`
  serve independent assertions. Changing their global meaning is not authorized.
- The same file has the whole-tree sole-subprocess-owner test at :594-631.

Selected minimum correction:
1. Keep `_source()`, `_source_without_lock()` and `_sqlite_sources()` unchanged.
2. In the named B2c test only, move JUST the literal `expiry` assertion to a
   clearly named writer-authority source check. Keep every OTHER currently banned
   fragment on its existing whole-source input. Preserve the protocol, proof
   generation/comparison, fcntl/flock exclusivity, release-marker, row-write,
   public-export, no-requests-client, migration and subprocess assertions.
3. Use this fixed literal protected path set for the scoped `expiry` check:

```text
src/ge_nwp_coordinator/__init__.py
src/ge_nwp_coordinator/state_store.py
src/ge_nwp_coordinator/state_authority_lock.py
src/ge_nwp_coordinator/sqlite_writer_state.py
src/ge_nwp_coordinator/sqlite_writer_session.py
src/ge_nwp_coordinator/sqlite_connection.py
src/ge_nwp_coordinator/sqlite_security.py
src/ge_nwp_coordinator/sqlite_mutation_transaction_contracts.py
src/ge_nwp_coordinator/sqlite_transition_transaction.py
```

The set covers public writer exposure, issuance/session/exclusion and the
connection/fencing/controller authority plumbing. It is not dynamically inferred
from which files lack `expiry`, not a blanket exclusion of D2 code from every
runtime test, and not a grant to implement alternate writer authority elsewhere.
Require all named paths; missing/duplicate/unknown inventory must not count as a
successful empty scan. Comments in the test should cite the actual authority
contract and distinguish writer authority from source-profile data. No doc change
is needed solely to explain this test-scope correction.

4. The owning test must call the same scoped helper exercised by the controls.
   Do not create a helper tested in isolation while the real test bypasses it.
   Preserve literal existing expectations; do not derive expected profiles or
   allowed consumers from a candidate scan.
5. Add bounded permanent controls in THIS file: current complete sources pass;
   valid profile literals outside the writer-authority set do not trip this
   scoped check; a direct `writer_expiry` declaration/use inserted into a protected
   authority source fails it; each required source's membership is checked;
   a still-global banned fragment in a non-authority source remains rejected.
   Use inert source-string/copy fixtures, not live edits or executable authority.

Perform a small, causally discriminating external-copy check with unchanged final
tests: (a) current candidate with its real D2 profile data passes the named owner
and whole B2a module; (b) syntactically valid `writer_expiry` in a fixed authority
source fails the intended scoped assertion rather than syntax/import/inventory
or unrelated guards; (c) removal of the scoped expiry enforcement loses that
permanent negative while its legitimate positive remains accepted. A retained
whole-source `reconstruct_writer_session` negative outside the owner set confirms
that this was not a global `_source()` narrowing. No universal Python analyzer,
new broad mutant family, or full-suite-per-mutant requirement is selected.

If the actual retained authority files use `expiry` for another legitimate
unrelated purpose, identify that exact owner/call site before altering the chosen
set. Do not delete the set member or silently broaden the exception to make it
pass. An in-scope implementation bug may be repaired under the retained original
ceiling; an unselected authority conflict remains a stop.

This correction does not permit TTL/heartbeat-based writer issuance, automatic
writer takeover/failover, session reconstruction from metadata/SQLite, authority
row release markers, or source relocation to circumvent any guard.

Before the full final suite, complete the B2a module and relevant GUARDS smoke
checks, then finish every still-unproved original finite-campaign obligation.
Do not stop at a one-test green result or re-audit-readiness without full final
validation. All current preadmission, custody and source-authorship boundaries
below remain in force.

## 2. Fixed merged baseline and preserved opening

Repository: /Users/ds/Repositories/Governed Execution Coordinator

```text
branch: trunk_dev
HEAD: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
tree: cc3cc104300f553ada581cee24e80dab6dd885b1
sole parent: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
subject: feat: add RW0-D1 offline process and capsule spine
upstream: origin/trunk_dev at the same local commit; local divergence 0/0
one worktree; index equals all 263 HEAD entries
working state: exactly section 2A's 44 modified tracked and 23 untracked files
219 other tracked working files equal HEAD; total current source endpoints 286
no staged or unmerged path; no active operation/unexpected Git lock
migrations/catalog: current 0001-0004, no 0005
```

Snapshot corroboration (not live Git/ref truth):
3,134,667-byte archive; SHA-256
06d981b6100fc1d6ad9792aff35800eb0772b8d35f708ed030177967ccb9c40e.
Its 263 source leaves reconstruct the fixed tree. Source dates in its filename
are not authority. No old D1 candidate or mutant ZIP is required.

After guidance run the following existing-style data-only opener from `/`.
It invokes no Git, repository code or SQLite. This source-gate variant keeps
INDEX and CACHE content/metadata invariant for the entire interval. It authenticates
AGENTS at opening but permits the separately authorized working-file status edits;
that is not permission to change this gate's effect ceiling. The original record
is immutable. HEAD/refs and all non-ceiling paths also remain fixed.

```sh
python3 -I -B -S - <<'PY_OPEN'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env


import datetime
import shutil
import tempfile

guarded_environment()
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_not_exact_audited_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_unavailable')
gate_root = Path(tempfile.mkdtemp(prefix='rw0-d2-implementation-cont01-'))
os.chmod(gate_root, 0o700)
print('GATE_OWNED_ROOT=' + str(gate_root), flush=True)
record = {
    'schema': 'rw0-d2-implementation-continuation-01-opening-observation',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents, 'index_path': str(index),
    'index': index_before, 'cache': cache_before, 'git_executable': git,
    'git_environment': GUARDS,
    'limit': 'This source interval only. HEAD, refs, index and cache stay fixed. Only the named working-file ceiling may change; no staging, commit or remote action.'
}
READ_HELPER = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\n\nimport subprocess\nimport sys\nopening = json.loads(Path(__file__).with_name('opening.json').read_text(encoding='utf-8'))\n\ndef immutable_checks():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('implementation_index_content_or_metadata_drift')\n    # Guidance was authenticated before editing; authorized documentation\n    # changes are governed by the source ceiling and final endpoint receipts.\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n\nimmutable_checks()\nindex_before_read = regular_record(index_path())\nargs = sys.argv[1:]\nif args == ['--check']:\n    print('READ_HELPER_IMMUTABLE_SURFACES_MATCH')\n    print('CURRENT_INDEX_SHA256=' + index_before_read['sha256'])\n    print('Index content and metadata equal this implementation opening; no stage or index write is permitted.')\n    raise SystemExit(0)\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree',\n           'check-attr', 'for-each-ref', 'reflog'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_read_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'], ['--quiet', 'HEAD']):\n    raise RuntimeError('readonly_head_query_only')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('readonly_worktree_list_only')\nif args[0] == 'reflog' and (len(args) < 2 or args[1] != 'show'):\n    raise RuntimeError('readonly_reflog_show_only')\nfor arg in args[1:]:\n    if arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec') or arg.startswith(('--output=', '--exec=')):\n        raise RuntimeError('unapproved_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager', '-c', 'core.fsmonitor=false',\n           '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=guarded_environment(), check=False)\nfinally:\n    immutable_checks()\n    if regular_record(index_path()) != index_before_read:\n        raise RuntimeError('index_changed_during_read_command')\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(payload)

try:
    write_private(gate_root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(gate_root / 'live_read.py', READ_HELPER.encode())
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_first_git')
    print('OPENING_RECORD=' + str(gate_root / 'opening.json'))
    print('LIVE_READ_HELPER=' + str(gate_root / 'live_read.py'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D2_IMPLEMENTATION_PRE_GIT_OPENING_RECORDED')
except BaseException:
    for name in ('opening.json', 'live_read.py'):
        p = gate_root / name
        if p.exists():
            if not stat.S_ISREG(p.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            p.unlink()
    gate_root.rmdir()
    raise
PY_OPEN
```

Use the emitted ACTUAL helper paths; do not assume shell state persists. Route
live Git reads through the helper. Missing objects, unsupported overrides or a
failed helper are stops, not raw-Git/fetch fallback permission. No write-tree,
index refresh, staging, compileall, import or test is permitted in the live tree.
The helper is external instrumentation, not an OS interlock or product authority.

Authenticate all 263 BASELINE Git entries and the fixed tree/ref conditions.
Then authenticate the actual 67-path overlay below BEFORE editing or execution.
The 44 modified files intentionally differ from HEAD, and all 23 authorized
creations exist untracked. All 219 other tracked working payloads/Git modes equal
HEAD; all 23 creations remain absent from HEAD and index. No other untracked
source or generated artifact is admitted. Current guidance is the reported D2
AGENTS payload, not the old D1 HEAD payload; both have separate receipts below.

Keep immutable external copies of all 67 opening payloads and the original HEAD
bytes for permitted existing paths. Capture current OS type/mode metadata for all
286 endpoints in this interval; preserve the known nonexecuting 0600 test and do
not normalize files. Read/hash only regular files, never follow special files.
The existing opener covers index/cache before Git. These additional current
source-mode records do not reconstruct the earlier omitted mode record.

The one newly authorized B2a file must still equal its authenticated HEAD bytes
before editing (receipt in section 2A). All observed later changes must be within
the explicit ceiling. No deleted old helper is needed; no historical interval is
reconstructed, and no old clean-worktree assertion applies to this candidate.

## 2A. Exact retained 67-path candidate and malformed-report reconciliation

These are the reported CLOSED working payloads of the blocked continuation, not
independent acceptance. Every payload SHA-256 below was fully supplied. The lead
checked all 44 M baseline identities against the 263-file snapshot and prior
mandate. Exactly ONE baseline cell in the report is invalid; its attempted
correction is invalid too. The corrected expectation below is explicitly sourced
from the fixed baseline, not guessed by extending the malformed string:

```text
path: .docs/rw0-c2-first-live-proof-posture.md
correct original HEAD Git blob: 4b69e424655ea67900f6c6042c0cbacaf2d53f8a
HEAD bytes: 16,985
HEAD SHA-256: c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e
reported closing payload: 17,674 bytes
reported closing SHA-256: ba61008234eb5ec85416c459dab0a82b19f7e1a0662dcb15f1289ba445fdf5bd
```

The report's `4b69e424655ea6792d1d07642d3576f364a` is 35 characters, NOT a valid
40-hex Git object ID. The earlier cell also had a question mark. Do not repeat
that as verified. Read the actual raw HEAD blob and verify the correct value.
Reproduce the fixed aggregate using actual baseline blob bytes and candidate
payloads. If EVERY row and the same reported aggregate match, record this as a
report transcription correction with no candidate edit. If they do not match,
STOP before any edit/test with RW0_D2_SOURCE_ENTRY_PROVENANCE_BLOCKED and exact
observed discrepancy. Do not adopt a new aggregate or silently repair a payload.

All rows: exact regular nonsymlink OS mode 0644, Git mode 100644. M/C are always
relative to HEAD 43ae26b9..., not to a checkpoint or future source commit.

| Path | Effect | Baseline Git blob | Opening bytes | Opening SHA-256 | Encoded row bytes |
|---|---|---|---:|---|---:|
| `.docs/architecture.md` | `M` | `7d21418a68d2d3002753227da08cf059836d0260` | 44,745 | `5075b772afddcfe8276933d189155aa689dc4c1ee162bb702c7c7f4efaf04635` | 44,801 |
| `.docs/authority-boundaries.md` | `M` | `3524d11d67a46344214b455396afeeaa3754b41d` | 36,175 | `79c57d377b6ef7f2460ee5a5827b9c5c61334e656be9eeed73264a6906e55e32` | 36,239 |
| `.docs/autonomous-software-development-operating-model.md` | `M` | `a46d51fe3ea480e39c8c7989a08e80d9db21f5b8` | 41,197 | `926468bad8cd51c57e3aec6da775c6dced52880215f24d5b03177499a119c6c2` | 41,288 |
| `.docs/b3b2a-read-scope-and-query-contracts.md` | `M` | `c3237c31fc4b59dcd632b827a4be9907cfcfb998` | 10,013 | `74b1d21b02cd9886a697e1f1cb01dca6977cabb2da194269a35d49745fe548f6` | 10,093 |
| `.docs/b3b2b-select-readers.md` | `M` | `f1ba74b0a5cd3946a3138de326949d29f789cfac` | 6,477 | `fa7a364ce070b3fcef44907bc884bc783200e1951c618fd7e392d485497c7f07` | 6,541 |
| `.docs/c2b-durable-development-state.md` | `M` | `04c068d07cd08feaf6c56dafbf3494ccde037ede` | 1,891,411 | `8db2ba24f0685ac21fae2103bb664727a8d9635d3ead5f6bae0d42b35aaf34d2` | 1,891,484 |
| `.docs/c2b2-private-readers.md` | `M` | `018b3d905f5db80cf15b546f881dc8c1de3a67b7` | 14,020 | `f765b2dcd74979e235cb04c15dd1fbc81eca149aec017ca500708903bbc105d2` | 14,084 |
| `.docs/c2b2-pure-durable-row-values.md` | `M` | `1cab6d886f2cd3101987476064a9ce82d2eb4dd2` | 8,540 | `0970595b4c292517d0770542ff8e12a03b98ea93057d4e715d6518415e83aaf3` | 8,612 |
| `.docs/durable-state-model.md` | `M` | `49694cd86a51f3fb0fb3799e734a52c1a395b8c7` | 42,053 | `7f9cba19f491322dd2fc0f1656ac6b76e698723a6700d1f9919d22b2196e9e80` | 42,116 |
| `.docs/rw0-b1-pure-phase-values.md` | `M` | `5b7fb0072c6d04898cd212fdc4ff5f63903cf13b` | 35,115 | `7294e7b3aabad5338c4d846e44686ffd075b3e8fe4598495a3e7267103a9ef1e` | 35,183 |
| `.docs/rw0-b2-wire-protocol.md` | `M` | `5e41d1cb3b2f430d29eb88bdbf2b46570faf3c6b` | 26,084 | `ac1091f043f5fa6042ced1e919c740a08af975b7df1e5e97b66634f85cb68e69` | 26,148 |
| `.docs/rw0-c1-durable-evidence.md` | `M` | `a7111c4dcf761b60df35c59794bf2e3acd949745` | 15,037 | `f2c6c51d0437aa78b7975bfca3e6fc629fc2898d55c0c696750221000343a02c` | 15,104 |
| `.docs/rw0-c2-first-live-proof-posture.md` | `M` | `4b69e424655ea67900f6c6042c0cbacaf2d53f8a` | 17,674 | `ba61008234eb5ec85416c459dab0a82b19f7e1a0662dcb15f1289ba445fdf5bd` | 17,749 |
| `.docs/rw0-d1-offline-process-and-capsule-spine.md` | `M` | `f3557ca523cac0d6fa26647b17a84aef66fecc15` | 5,207 | `41d04b1d2c64794940569b714aab7219caf09259ed6227962856389cb6025b95` | 5,291 |
| `.docs/rw0-d2-offline-evidence-and-review.md` | `C` | `absent` | 8,267 | `02ca82f0acb00a623d7610cb35eb274d8a5c1ca92e331615a38409bd3fe53f2a` | 8,345 |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | `M` | `230167a39b115634c8f9b5ae5a0699639f6ff454` | 59,586 | `bee20ed00c7e6f86db3394351f0cbe29626413c635cd9a982416984b288e6fbd` | 59,667 |
| `.docs/worker-execution-boundary.md` | `M` | `464aef2aa7a561e4adc6792d1d07642d3576f364` | 32,409 | `3cfc1208d96e1f59a81dcd70dce5d43d89f2cb70cc5af6eca453650c33742769` | 32,478 |
| `AGENTS.md` | `M` | `254854d4a57487d97ce02a73ce2ed26c86ece170` | 64,142 | `ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166` | 64,186 |
| `README.md` | `M` | `088c832ca7e28d18c82ff6317738ac8ca1c7b5d1` | 47,694 | `f48f2439d282350e36b5d8374864cb5dfe19eb417672737e820500c3a68224f3` | 47,738 |
| `src/ge_nwp_coordinator/_cognitive_proposal_semantic_values.py` | `M` | `c164616b9e86379c3c6a9210cf4941429a596d4c` | 71,190 | `40243b96765ee0bf49e56a36123e0553f3bb9ab3e0fada38dbe619a2acc1eacd` | 71,286 |
| `src/ge_nwp_coordinator/_development_bound_effect_establishment_contracts.py` | `C` | `absent` | 43,040 | `16d8fe16528600ac9b7d65b456ae6f393adbbeb366031e63dd3a024d96fe7578` | 43,150 |
| `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | `M` | `cb37f733141f1e3c3ce874fcc052149de1f82881` | 3,668 | `21e0c9d6c2ece57b87dfb05e961ba1a99a48e72346bbab2c4c1ed571eb5f1f00` | 3,748 |
| `src/ge_nwp_coordinator/_rw0_d1_handback.py` | `M` | `ecfcf767a5f1c32c0cf007a2c8aa3137ef92374d` | 16,439 | `87bdab7b35fc6a20c93471e13162b6dd56e97c48b78577445a41d6d7919ceb1b` | 16,516 |
| `src/ge_nwp_coordinator/_rw0_d1_offline.py` | `M` | `4f2a82e46fda9be8123888f5ca46968a4345c25f` | 23,326 | `93a6dd7f10141d22edd074f66a7cc427ab8bdb6fb1936763b3bf4a8e34a7d1e9` | 23,402 |
| `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | `M` | `7dc90a0442e348aaac985d711c4d1a97adb7cc05` | 12,175 | `a236bbf599e7d32b4edcc31d23182fd9613c5d290f31a0f1e57961b6a104fe56` | 12,262 |
| `src/ge_nwp_coordinator/_rw0_d2_handback.py` | `C` | `absent` | 13,339 | `1e4fddda53315d7a14d042780730e0cce07b9a5c67d41233ddff550a430ac24f` | 13,416 |
| `src/ge_nwp_coordinator/_rw0_d2_offline.py` | `C` | `absent` | 6,967 | `d838dd02495cab5cbafa2e6e0b99d6a4e6b4b30e4ac5cb288cb9dd2db02d0d44` | 7,043 |
| `src/ge_nwp_coordinator/_rw0_d2a_evidence.py` | `C` | `absent` | 53,134 | `e93c2592c8f838bd178ffa8e57f57a9116fcdf567b248e511496d00384968ec9` | 53,212 |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_reviewer.py` | `C` | `absent` | 2,878 | `0d061fdf600039ff69ba0d0dc3f1a0239c2527500461244bb53455bbdd326973` | 2,961 |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_validator.py` | `C` | `absent` | 2,726 | `c1eb49503b4345d25047814e089545f9d1cd4c85f10ae20254b8b6283fa58fbe` | 2,810 |
| `src/ge_nwp_coordinator/_rw0_d2a_handback.py` | `C` | `absent` | 11,551 | `9c28eff0a2e042b735ae9bdc40a8fe6f387027db53b80ec41e434d0ae92bb338` | 11,629 |
| `src/ge_nwp_coordinator/_rw0_d2a_offline.py` | `C` | `absent` | 30,416 | `d81db9535b17c7daae7be449d7e30dbcaaa599749ddc2619dbfa7d40f87db838` | 30,493 |
| `src/ge_nwp_coordinator/_rw0_d2a_process_frames.py` | `C` | `absent` | 6,397 | `2c969b1ec303674500143bbbd721e4fe5f7ee161e00b4343f71a611a7f075c8d` | 6,481 |
| `src/ge_nwp_coordinator/_rw0_d2a_workspace.py` | `C` | `absent` | 5,075 | `45086c2b216639d3a35deef972acda526f004608780a8a8b5e30ed51253f0697` | 5,154 |
| `src/ge_nwp_coordinator/_rw0_d2b_fake_review_model.py` | `C` | `absent` | 3,771 | `492288c84c2491120a56c7056000f8ec3860c7fbce2bcb3c33249e5e1af5d93a` | 3,858 |
| `src/ge_nwp_coordinator/_rw0_d2b_model_frames.py` | `C` | `absent` | 8,032 | `e4b7cddc6cfd4caa7e34781e1c34c00833d6f83a98477d46ce55e878e97dfcef` | 8,114 |
| `src/ge_nwp_coordinator/_rw0_d2b_model_input.py` | `C` | `absent` | 81,718 | `e2bbe585f8ae19df5dd6547212cf239ac58411795cbae904cf3ed869910bdd9a` | 81,799 |
| `src/ge_nwp_coordinator/_rw0_d2b_proposal.py` | `C` | `absent` | 22,718 | `deec7caf82206c40545a308f3a8845fb867e64a211a81e055fb29ffbafc0666a` | 22,796 |
| `src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py` | `C` | `absent` | 23,762 | `d5012ef7dd383ae39364772d7702364fc0eadde31a1e64997c0a6773d6025245` | 23,869 |
| `src/ge_nwp_coordinator/_sqlite_rw0_c1.py` | `M` | `635b5dd49256e14103fced6ff8ea4db76649e22c` | 203,409 | `d17490b3ce1b136eeb3d559f01f44e97836827bc137325b306ec01530e06e9e7` | 203,484 |
| `src/ge_nwp_coordinator/sqlite_transition_transaction.py` | `M` | `f8053db4010faaba41b38b531d93a8b21e80daa8` | 180,600 | `6d662dcb83a2641b9d95dee7209ddbd0d8b991bc720da3aafa5b4b9fb3bc5521` | 180,690 |
| `src/ge_nwp_coordinator/sqlite_writer_session.py` | `M` | `97162e3a749a7f1f1ae75de90c4b2d9092068107` | 299,804 | `54f9c5a0844421686c1c89cdecf3c2865263b3339d2faec933c615ca2ca3d404` | 299,886 |
| `tests/test_b3b2a_read_scope_and_query_contracts.py` | `M` | `66cab4655d33c1b864f5fb4c22e853a39c5a8188` | 26,502 | `4cabeed0c37a99c0f937c0b49f25c7c6a049eb9125e64127019c449dcd86313a` | 26,587 |
| `tests/test_b3b2b_select_readers.py` | `M` | `c0c5a0e091572f30a428fd5a2634c21d25a6ad64` | 118,350 | `22061f6846b0ebc969f9b67bac399b8d8eb237c8df0e2de92d84d477c0f1ce2b` | 118,419 |
| `tests/test_c2a_nonimplementation.py` | `M` | `3f343ae5886c92941ebfff63ba4213de2109025e` | 30,650 | `c0db68e10f4588c02bbc38da1b95d6898a3d7896c127038533ce0c8a6715442e` | 30,720 |
| `tests/test_c2b0_durable_state_contract.py` | `M` | `b910d61aaf670ba40a0d649f933c06767e7360e5` | 887,367 | `995c3690500e3d3009f1fe93b276db506e1d454764dd2e5167df52bf81252c1a` | 887,443 |
| `tests/test_c2b2_development_reader_contracts.py` | `M` | `122f0d44b46e0a8d7b283d5baec1ce465e2028b6` | 71,365 | `28dbf4fff09d75d7522af35c8fddc8908b7c4c1d18ff8043d19dbf6b90f30970` | 71,447 |
| `tests/test_c2b2_development_row_value_boundaries.py` | `M` | `d7dea23786bec2ca98bb702bbe93cc31e4192221` | 17,972 | `f2a7089748f39dc8c40a932ac770edd3ffa7f8ea581b053af101dfda8100c830` | 18,058 |
| `tests/test_post_execution_pure_owner_boundaries.py` | `M` | `437a4e7cbd39682bdd08f03b3a30c0bbbd057614` | 19,302 | `7945be6d5e01c2a1b437cabc57972bbd70a725da9c14f7dd92574ff8f8633014` | 19,387 |
| `tests/test_runtime_non_authority.py` | `M` | `79d4ab185815234c9d087c48d2439b9a1d95d95d` | 48,343 | `fef5729d8e7f4c619ddb2731b52d3500bc8e75988a3f422648b9dea743ef01c9` | 48,413 |
| `tests/test_rw0_b1_boundaries.py` | `M` | `17d1e09c30b01287718c6b5175bac76b03daf458` | 52,838 | `af8d9f7507733876a5978d1a3f5b871a81030380eba929cbffe6959f9d639aaa` | 52,904 |
| `tests/test_rw0_b2_capability_boundaries.py` | `M` | `4668d2a2c285d2d79bf6ebfb0c9c9f60166bcb27` | 50,538 | `85ee20f37629ffc852154cea67dd5dc983b0f2f74ab2d370192c13d999b397c3` | 50,615 |
| `tests/test_rw0_b2_wire_boundaries.py` | `M` | `9e04f528326a6f337a4f47e7e9f9eda3c9a82e0a` | 38,513 | `13531d5d46258ca67cc7bf0bddd78c560ce9b7308ff296068a146299f349ba27` | 38,584 |
| `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | `M` | `0f0159c172e1448d2b96ab19411e1f85467a2931` | 120,405 | `af7f49ac8da64c12e97d03a536ee10b89a11996651b0d712dc04baef427d8cf3` | 120,505 |
| `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | `M` | `e9d95b54a4b5921be8ec39d2bf3f6216204750c7` | 247,679 | `e8de37791388c28f1b1626747af6c4094622469168ed9799eaa78f7f6f4d3613` | 247,781 |
| `tests/test_rw0_d1_handback_values.py` | `M` | `982be9b37aa05db0c6d6a3321b775c7c64f2142d` | 28,938 | `f571fbb7c9e6a55da56155078841266ee985b3ee0e9ffdcd86be77771bc342db` | 29,009 |
| `tests/test_rw0_d1_offline_integration.py` | `M` | `33c2d85012cbdf0e7e04fdeb7d333d2c8675ae3f` | 53,132 | `c5997a4e9161253974b04b203bf55754c12b465c3b0b5924247e6c1df8e05c9e` | 53,207 |
| `tests/test_rw0_d1_worker_process.py` | `M` | `e2a83abe44db720b5ce0725682ac71d30372959d` | 1,737 | `512d7d61083e8ad8c61c197aefc86f70d61a1f7e41273fab435bb493cc08631f` | 1,807 |
| `tests/test_rw0_d2_bound_effect_contracts.py` | `C` | `absent` | 5,637 | `300809721541e6fb457f5a05ca31fe03a58d0ec9ac88c3fa6a367bc909daa739` | 5,715 |
| `tests/test_rw0_d2_bound_effect_persistence.py` | `C` | `absent` | 6,068 | `839a68b7285480a6ca19885be2df2e398dbedb8e6909f381f5cfe4aa8155da67` | 6,148 |
| `tests/test_rw0_d2_c1_checked_readback.py` | `C` | `absent` | 17,750 | `20237660028125bacccf52bb695cb275adebefb2ed1f0a28bb271688f7aadb01` | 17,825 |
| `tests/test_rw0_d2_evidence_children.py` | `C` | `absent` | 3,635 | `fd4cd60a30cb641d34b458f7782bcc27d020a37f47f6523c37cfcf83895d516b` | 3,708 |
| `tests/test_rw0_d2_model_handback.py` | `C` | `absent` | 4,966 | `89c53206f1b636257ecf5f71027e11ca4ef4cfdd00883e55b2c0fa02fe2a7a6e` | 5,036 |
| `tests/test_rw0_d2_offline_integration.py` | `C` | `absent` | 7,008 | `d6d2b0d445b9151d811f4df426f5a8d66b7c9221d85c33bd9b4a9b9254bc7916` | 7,083 |
| `tests/test_rw0_d2_process_frames.py` | `C` | `absent` | 6,894 | `f77f49268e4ed693d049560307aa3794538842efc8afa24e1500664fc4884264` | 6,964 |
| `tests/test_rw0_remote_contact_phase_entry_contract.py` | `M` | `2a9144c3dfd2c883555703c8adecd21f447d6d34` | 177,317 | `6df3c991a219633d148106396336f2702c323b6cddb82932b41152ea3e5ac16a` | 177,405 |
| `tests/test_sqlite_backend_b0_contract.py` | `M` | `c646df6d439d0b70f45d6d72200fbedb5e730779` | 26,412 | `1eb038201c19be7e9680f5ee6c4425fb50051b8bc0df31e3feeab06620cc094e` | 26,487 |

Fixed opening replacement (section 13's unchanged RAW-PAYLOAD recipe):

```text
prefix: RW0-D2-BINARY-REPLACE-V1 plus one NUL = 25 bytes
rows: 67 (44 M / 23 C)
payload bytes: 5,601,299
encoded row bytes: 5,606,463
total bytes: 5,606,488
SHA-256: 4de3b2fe6ea31dcfc258cc214bc998eb27958be3025e39ac693e3489b7508017
```

Construct it twice from fresh reads, using independently streaming/concatenating
calculations if useful. The lead checked length arithmetic only; actual payload
and aggregate authentication is REQUIRED here. Never hash digest strings in place
of payload bytes or substitute the old 176,721-byte ten-file overlay.

The newly admitted test is NOT one of those 67 changes. Its current entry must
match this baseline receipt before the scoped amendment:

```text
path: tests/test_b2a_writer_session_contract.py
bytes: 26,240
SHA-256: dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1
Git blob: ccadd884de29d606c9243ea7796cc380e29fe5c2
Git mode: 100644
OS mode: 0644
```

After successful opening authentication, inspect the whole B2a test, relevant
live owner guidance, actual D2 profile data and any tightly coupled guard before
editing. The snapshot showed no test-file content pin on this path; verify the
actual retained source references rather than infer there are none. The source
value contract must not be weakened to bypass the lexical test.

The source report now describes implemented A/B paths and focused runs. Do not
call them absent prototype scaffolding as in the prior ten-file start. Equally,
do not call them fully validated or audit-ready: final normal gates and the
complete original causal campaign still require completion.

## 3. Capability, ownership and nonclaims

One private invocation must demonstrate:
WorkSpec/fixture -> D1 -> sealed evidence -> two native bound effects -> independent
validator/reviewer children and applicable C1 admissions/readback -> nine-role
model input -> one fake review-model child -> canonical transient proposal.

Existing Coordinator owners retain program/author/Section-41 selection/C1 phase
truth; the new native writer owns only its selected effect establishment family;
C1 owns admission; Git alone owns later publication; external standing authority
is NOT implemented. Parent sequencing variables and statuses are projections and
control flow, not another authoritative program lifecycle. Fake policy/readiness/
authority sources are explicitly artificial evidence for this proof.

Successful D2 is `preadmission_ready`, not candidate acceptance. The five model
recommendations remain `accept_candidate`, `repair_candidate`, `replan`,
`terminal_reject`, `block`. They are source proposals, never a C2-derived branch.
Valid negative checking evidence may support one of these recommendations.
Missing/malformed/failed/uncertain source evidence must NOT be converted into a
fabricated `block` recommendation. Preserve process stop and cleanup uncertainty.

D2 supplies no Section 41 post-execution source-family rows, receipt, graph,
rank-15 member/projection, complete C2 decision-time closure/currentness, terminal
result, new migration, live grant, qualified supplier, restart/relocation/handoff
capability, hostile-code sandbox, service or autonomous Git operation.

## 4. Exact working-file ceiling

Maximum: 55 existing M paths + 23 C paths = 78. This is the previous 77-path set
plus ONLY tests/test_b2a_writer_session_contract.py. All 23 C paths already exist
in section 2A's overlay and remain absent in HEAD/index. Forty-four permitted M
paths already differ; eleven permitted M paths are still HEAD-exact, including
the new B2a test. The 208 baseline paths outside this ceiling remain protected.
No deletion, rename, executable-bit, submodule, symlink or unlisted file change.

Primary work is C7's one-file test repair. Preserve the other 67 candidate
endpoints. Existing original-ceiling files remain available ONLY to complete a
named original requirement or repair a concrete in-scope failure encountered in
this continuation; document the evidence and exact transition for each such edit.
Do not reimplement conforming code, add another runtime owner, or change scope
because a final suite has not yet run. Every further source edit invalidates the
affected pre-edit validation; rebuild final copies and revalidate as below.

Do a compact current dependency inspection before edits. Do not commission another
map. An indispensable unlisted surface requires a precise retained-work stop;
no filename/import tricks. No new source permission is supplied by the newly
scoped `expiry` check. The complete inherited ceiling follows for self-containment.

### New runtime owners (C)

- `src/ge_nwp_coordinator/_development_bound_effect_establishment_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py`
- `src/ge_nwp_coordinator/_rw0_d2a_process_frames.py`
- `src/ge_nwp_coordinator/_rw0_d2a_fake_validator.py`
- `src/ge_nwp_coordinator/_rw0_d2a_fake_reviewer.py`
- `src/ge_nwp_coordinator/_rw0_d2a_workspace.py`
- `src/ge_nwp_coordinator/_rw0_d2a_evidence.py`
- `src/ge_nwp_coordinator/_rw0_d2a_handback.py`
- `src/ge_nwp_coordinator/_rw0_d2a_offline.py`
- `src/ge_nwp_coordinator/_rw0_d2b_model_frames.py`
- `src/ge_nwp_coordinator/_rw0_d2b_fake_review_model.py`
- `src/ge_nwp_coordinator/_rw0_d2b_model_input.py`
- `src/ge_nwp_coordinator/_rw0_d2b_proposal.py`
- `src/ge_nwp_coordinator/_rw0_d2_handback.py`
- `src/ge_nwp_coordinator/_rw0_d2_offline.py`

The two bound-effect files own native pure command/family and SQL implementation.
A's frame/children/workspace/evidence/handback/runner files own only their named
proof mechanics. B's frame/model/input/proposal and final handback/composition
files complete the same invocation. No fourth child or alternate supervisor.
All new modules stay package-private with no package-root export.

### Existing runtime changes (M)

- `src/ge_nwp_coordinator/_rw0_d1_handback.py`
- `src/ge_nwp_coordinator/_rw0_d1_offline.py`
- `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py`
- `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py`
- `src/ge_nwp_coordinator/_cognitive_proposal_semantic_values.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
- `src/ge_nwp_coordinator/sqlite_writer_session.py`

The D1 edits are only adapter-evidence retention, real event-time sampling,
corresponding truthful stage relations, and exactly three new child allowlist
entries. The common cognitive edit is an exact post-phase pure constructor branch,
not a rewrite of pre-execution semantics. The C1 edit supplies private checked
readback. Session/controller changes add only the guarded native operations and
the bounded current-head/stop observation; no new transaction/connection owner.

### New tests and detailed implementation owner (C)

- `tests/test_rw0_d2_bound_effect_contracts.py`
- `tests/test_rw0_d2_bound_effect_persistence.py`
- `tests/test_rw0_d2_c1_checked_readback.py`
- `tests/test_rw0_d2_process_frames.py`
- `tests/test_rw0_d2_evidence_children.py`
- `tests/test_rw0_d2_model_handback.py`
- `tests/test_rw0_d2_offline_integration.py`
- `.docs/rw0-d2-offline-evidence-and-review.md`

### Existing direct/coupled tests (M; preserve unrelated assertions)

- `tests/test_b2a_writer_session_contract.py` — NEW permission, C7 only
- `tests/test_rw0_d1_handback_values.py`
- `tests/test_rw0_d1_offline_integration.py`
- `tests/test_rw0_d1_worker_process.py`
- `tests/test_rw0_d1_process_supervisor.py`
- `tests/test_rw0_c1_writer_session_delegation.py`
- `tests/test_rw0_c1_reader_contracts.py`
- `tests/test_rw0_c1_private_readers.py`
- `tests/test_section41_cognitive_proposal_semantic_values.py`
- `tests/test_post_execution_pure_owner_boundaries.py`
- `tests/test_post_execution_pure_owner_values.py`
- `tests/test_rw0_b1_boundaries.py`
- `tests/test_rw0_b2_wire_boundaries.py`
- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- `tests/test_rw0_b2_capability_boundaries.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
- `tests/test_c2b2_development_reader_contracts.py`
- `tests/test_c2b2_development_row_value_boundaries.py`
- `tests/test_b3b2a_read_scope_and_query_contracts.py`
- `tests/test_b3b2b_select_readers.py`
- `tests/test_runtime_non_authority.py`
- `tests/test_c2a_nonimplementation.py`
- `tests/test_architecture_contracts.py`
- `tests/test_autonomous_software_development_operating_model.py`
- `tests/test_c2b0_durable_state_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_rw0_c2_private_value_versioning_contract.py`
- `tests/test_sqlite_backend_b0_contract.py`

### Governing/status/reader documents (M; narrow successors, not historical rewrites)

- `AGENTS.md`
- `README.md`
- `.docs/c2b-durable-development-state.md`
- `.docs/c2b2-private-readers.md`
- `.docs/c2b2-pure-durable-row-values.md`
- `.docs/b3b2b-select-readers.md`
- `.docs/b3b2a-read-scope-and-query-contracts.md`
- `.docs/rw0-d1-offline-process-and-capsule-spine.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-b2-wire-protocol.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/architecture.md`
- `.docs/authority-boundaries.md`
- `.docs/durable-state-model.md`
- `.docs/worker-execution-boundary.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/rw0-c2-first-live-proof-posture.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`

Keep byte-guarded historical prefixes and source/phase semantics intact. Use a
bounded current-status or consumer successor where an old frozen statement is
historical. The giant C2B owner is not permission for a wholesale rewrite. Record
A as a development checkpoint and B as final implemented D2 only when both exist.
The five normalized Capability status projections and literal AGENTS/README
identities must be updated together with their independent bootstrap checks.
Expected hashes are fixed literals, never dynamically derived test oracles.

B1 external consumer changes must distinguish the native command's basis check,
D2 evidence construction/evaluation, and D2 evidence holding. Add only actual
named imports and symbols. Do not grant handback construction/qualification
functions. Wire still owns classification; no handback classifier execution.
External D2 consumers may use the pure post-execution suppliers, not V22-V34 as
admitted projection or C2 decision/currentness evaluators. Those later production
callers remain absent. Keep no-I/O semantics in the six supplying pure modules.

Protected source includes the entire SQL/catalog/schema authority, StateStore,
package __init__.py, pyproject, existing C1 reader query specifications and
implementation, existing C2B 24 query specifications and readers, all existing
semantic row factories and portable capsule/Wire contracts. Only the specifically
listed common cognitive phase validator changes. The D1 capsule/workspace/frame
owners are unchanged. Do not move the supervisor to another file for aesthetics.

## 5. Internal checkpoint A0 — retained D1 evidence and event-time facts

Sections 5-11 retain the original implementation and acceptance obligations.
Read them as preservation/completion requirements for the current candidate,
not as instructions to discard it and implement it again. Use actual source
inspection and existing supported evidence; finish missing in-scope behavior or
controls where necessary. C7 is the selected primary amendment.

Read D1 source and all seven existing D1 test modules before editing. Retain the
EXACT WorkerObservationV1 adapter_exit object immediately after construction and
before its classifier use. Add `adapter_exit: WorkerObservationV1 | None` between
wire_result and wire_classification in private RW0D1HandbackV1. Its field inventory
becomes 17; its evidence prefix becomes 14. Amend all exact type, relationship,
status/reason and stage assertions together, not just indexes or annotations.

The same adapter ref/digest/fields must reach classification, handback, rank-12
admission, rank-14 recomputation and D2 evidence. Classifier-only labels, exit
scalars or later reconstructed timestamps cannot supply the missing record.
No record exists on failed start, unproved early cleanup, nonzero/deadline/cancel
or undecodable output before its actual producer site. Classification refusal
and later capture/capsule/cleanup failures retain it once actually produced.

Revalidate both outer and nested types at construction AND consumption. Check
observation kind/source, current author delivery, command, both fences, source
invocation, process code and exact digest. Use the existing semantic relations,
not string/class-name tricks or author/result equality alone. Do not introduce a
new public/wire version; this is an explicit coordinated amendment of a private,
nonserialized evidence class and its consumers.

Sample actual whole-second UTC at the worker's actual events: started after valid
launch decode and before work; captured after the actual change when present;
completed after work and before result output. Parent samples adapter observed_at
after clean/reaped result and successful decode, before classification. Do not
construct all three times at the end or retain the 2028 literals in the live
composition. Preserve legitimate optional two-observation and three-observation
Wire grammars and all negative fixture meanings.

D2 checks started <= optional capture <= completed <= adapter exit; same-second
equality is valid. B1/C1/result-set relations keep THEIR actual requirements.
Qualification is evaluated and admitted before the relevant checking child;
replay/recovery reuse transaction times. Reversal/stale/expired inputs stop the
dependent path. No sleeping/clamping/backdating or moving the controller clock
to a fixture year. Supervisor deadlines remain monotonic and separate.

Record the controlled compatibility treatment: the earlier D1 proof used
artificial times; this source amendment supplies current proof event times for
D1+D2. It neither asserts live source authenticity nor reclassifies the already
accepted historical proof as a production security failure.

## 6. Native bound-effect owner on unchanged migration 0002

### 6.0 Distinct bound-effect safe assertion: exact new private owner

Implement in the ALREADY AUTHORIZED
src/ge_nwp_coordinator/_development_bound_effect_establishment_contracts.py:

```text
class: DevelopmentBoundEffectAuthorizationSafeBindingV1
schema: governed-execution.nwp-development-bound-effect-authorization-safe-binding.v1
digest domain: governed-execution.nwp-development-bound-effect-authorization-safe-binding.v1.identity
pure factory: _development_bound_effect_authorization_safe_binding
pure exact-value check: _require_exact_bound_effect_authorization_safe_binding
```

This schema is newly selected here. It is not an old schema newly discovered in
the repository. Both functions and the class are package-private, pure/no-I/O,
nonprinting and nonserializable. Keep __all__ empty. Do not subclass, alias,
re-export, monkeypatch or reinterpret DevelopmentEffectAuthorizationSafeBindingV1.
Do not construct an author binding and patch its class/fields afterward.

Fixed field order (16 fields):

```text
schema_id
parent_standing_grant_ref
parent_standing_grant_digest
effect_authorization_ref
effect_authorization_digest
attempt_fence_ref
attempt_fence_digest
semantic_attempt_ref
effect_intent_ref
effect_class
path_ceiling
effect_ceilings
expires_at
global_stop_ref
global_stop_version
safe_binding_digest
```

Use exact built-in strings for scalar text, the existing safe-reference/lowercase
SHA-256/real whole-second UTC grammar, exact nonnegative int for the stop version
(not bool), exact tuple[str,...] for path_ceiling, and exact canonical CeilingsV1
for effect_ceilings. Reconstruct and validate nested ceilings; frozen wrappers do
not prove nested validity. Validate malformed/subclassed fields before equality,
membership or digest comparison; emit the existing content-free native error
vocabulary, with no leaked path/source bytes/traceback payload.

The new class admits EXACTLY validate_candidate and review_candidate. It rejects
author_candidate, cancel_effect, local_git_commit, every publication/deployment
class, unknown strings, subclassed values, the old schema, and the old class.
A positive structurally valid binding is not yet a valid bound-effect command.
Use the existing canonical safe-path rules and the current fence factory's exact
path relation; do not invent path equivalence, casefolding, or normalization.

Canonical identity follows the current _domain_separated_digest convention:
new UTF-8 domain + one NUL + canonical sorted-key compact JSON of every field
except safe_binding_digest. path_ceiling is represented as its canonical JSON
array and CeilingsV1 by its canonical field mapping. Require ensure_ascii=False,
allow_nan=False and no extra newline in canonical bytes. The helper under test
must not supply a test's expected digest. Keep at least one independently fixed
preimage/digest vector and direct supplied-digest checks in the new contract test.
An author vector's schema/domain/fields/digest remain unchanged.

The bound command's effect_authorization_safe_binding slot now accepts only this
new exact type. Its complete canonical mapping INCLUDING safe_binding_digest
participates in the command identity. Preserve every other retained typed input,
blob binding and distinct command/operation-result/receipt-projection rule in
sections C2/C3 and 6.1. This uncommitted, unconstructible prototype may change its
own proposed command bytes in place; do not promise compatibility with any
prototype command/receipt that was never constructed or committed.

The original D1 author command and safe binding stay on their current author-only
class. Establish TWO new class-specific artificial authorization assertions for
the validation/review proof, with distinct effect intents and safe authorization
references/digests supplied as bounded proof-source input. Sharing the same
AttemptFence/parent grant is legitimate; relabeling the original author's binding
or using its authorization as proof of a new class is not. This mandate supplies
no real external grant, source-verification service or standing-policy widening.

Perform semantic joins in the pure reducer, exact native-command revalidation,
and again against owner data AFTER writer fencing on the fresh-write path:

- new binding class == requested bound class == new current fence/intent class;
- validation uses DevelopmentValidationRequirementEvidenceV1; review uses
  DevelopmentReviewRequirementEvidenceV1, checked against the original WorkSpec;
- parent grant ref/digest, attempt ref/digest, semantic attempt and global-stop
  ref/version match the actual checked predecessors;
- effect_intent_ref names the corresponding new current effect, not the author
  or sibling bound effect; proposed current effect/fence/delivery identities are
  distinct as required by the existing graph/identity contracts;
- use the existing create_effect_fence(attempt_fence, author_command,
  author_effect_fence, ..., effect_class, effect_authorization_ref/digest,
  effect_ceilings, expires_at, capsule_manifest) and validate_delivery_relation.
  That factory already supports these bound classes without accepting a Python
  safe-binding object. Do not modify its schema, fields, source or meaning;
- compare all canonical new-fence authorization/path/ceiling/expiry/stop fields
  to this binding. Preserve original author command/fence and capsule linkage;
- match exact path ceilings produced by the current factory, lifetime bounds,
  selected effect max_deliveries <=1 and actual aggregate <=3, no new Git or
  deployment effects, and all class-specific requirements. Do not broaden the
  attempt/parent grant or equate differently cased/related paths;
- same-command exact replay verifies the persisted original family and canonical
  command without renewing safe-source assertions or rewriting historical time.
  Recovery remains fenced and readback-only; neither definitely_not_committed nor
  unresolved triggers a reissue in this invocation.

Distinguish effect_authorization_digest (supplied safe source assertion),
safe_binding_digest (this new local value identity), effect_fence_digest, and
command_digest. They are not interchangeable. In the existing pending authority
row use the supplied effect_authorization_ref/digest in the same semantic columns
as the current owner pattern. Do not replace authority_digest with the local
binding digest to force a match, add a binding-schema SQL column, or label the
row verified. The six-member graph, receipt schema/result projection and the
pending / external_verification_pending disposition are unchanged.

Before further native-writer work, make BOTH real-D1-derived command variants
construct in a fresh external copy with their correct requirements, new binding,
new current fence, delivery, original author pair and capsule/blob evidence.
Use current source producers; do not fabricate the command by object.__new__ in
positive tests, import golden test builders into production, or mock the old
constructor into accepting another effect class. Direct pure positives do not
yet count as a committed family or child execution.

Permanent discrimination in tests/test_rw0_d2_bound_effect_contracts.py must cover:

1. Existing author vector stays byte/digest-equivalent and author-only; a valid
   new bound binding is not accepted by the unchanged author command consumer,
   and a valid author binding is not accepted in a bound command. The two bound
   classes succeed with their own independently derived real-D1 inputs.
2. New class/schema/domain and each retained exact field are enforced at ordinary
   construction AND at command/writer consumption. Controlled forged exact values
   test consumption separately; successful constructor rejection is not credit
   for revalidation of a forged value. Unknown/subclassed/bool-int/nested-mutable
   inputs remain invalid without coercion or raw exception disclosure.
3. Resealed, individually well-formed validation/review/sibling/cross-run binding
   substitutions fail at their intended joins (class, intent, requirement,
   attempt, grant, stop, canonical fence), not only because of an old self-digest.
4. Changing a valid bound binding changes its computed local identity and the
   enclosing command identity when it is a valid new command; retaining an old
   digest fails. Class-specific fresh writes/readbacks and exact replay/recovery
   keep those identities consistent and do not mint permission.

Extend the EXISTING native-family causal row (section 11) with only the pertinent
finite source mutations: relaxing the exact new type/schema check, skipping a
class/intent join with all other inputs well formed, and skipping the guarded
revalidation reached after fencing. Demonstrate targeted semantic failures and
unmodified positives. No new large mutation taxonomy or full suite per copy.

The new type's prose/ordered schema/vector and tests are implemented together
with their native consumer in the already authorized module/doc/test files. Do
not insert a separately published contract-only step. Update the retained
prototype's D2 binding constructor/type/mapping imports explicitly; do not leave
an author-only conversion on a guarded replay or recovery path.

#### Additional protected identities — NO edit permission

The following snapshot-backed HEAD receipts are supplementary preservation
checks, not additions to the M ceiling. Capability P02 remains the existing
63,518-byte author contract identity. All author golden tests and historical
binding/projection records remain unchanged except separately authorized D2
current-status additions outside protected historical text.

| Protected path | HEAD bytes | HEAD SHA-256 | HEAD Git blob |
|---|---:|---|---|
| `src/ge_nwp_coordinator/_development_author_effect_establishment_contracts.py` | 63,518 | `f6938024436a765a69e9a44d20d834a85075ba10b821e61e3e91bfb09cf17af0` | `5eed45f66e811e76904196d0730d5f5a2035fe33` |
| `src/ge_nwp_coordinator/_sqlite_development_author_effect_establishment.py` | 56,749 | `351f8186d1772f14a04774a6d94f6c243b4486d5bd0b902ab62a1e34a8bec175` | `a4f72d81d2128ac6bc6e52a43af7d6eecabb3374` |
| `src/ge_nwp_coordinator/_development_decision_row_values.py` | 53,230 | `9e0e9c0695adb9f0ad72d9d92c6859c995c2c5ade154a5546f0a1efc347db8ae` | `99dc988cb6a73a6964cf41a68a841117c790233d` |
| `src/ge_nwp_coordinator/_worker_execution_semantic_values.py` | 171,211 | `313aa2a51fc9abb632f9278df8672a90c5ee9045c4967f340d3234d9c6760d4c` | `98134a06a6a5ad97c70b710f2fd7731c882b56b6` |

Source basis for this choice: author safe-binding class and identity validator,
_development_author_effect_establishment_contracts.py:378-468; exact author
consumer :543-574, :794-806; guarded author join
_sqlite_development_author_effect_establishment.py:470-480; generic native
create_effect_fence _worker_execution_semantic_values.py:3419-3550; Capability
P02 tests/test_rw0_b2_capability_boundaries.py:120-128. These are baseline source
coordinates, not inspected coordinates in the retained new prototype.

### 6.1 Command and result identities

Implement in the two named native modules, using the real author-effect family as
a reference, not copying its result and changing its label. Public interfaces
remain untouched; sole intended new caller is the offline parent.

Use `DevelopmentBoundEffectEstablishmentCommandV1`,
`DevelopmentBoundEffectEstablishmentResultV1`, a closed conflict value, and
`DevelopmentBoundEffectEstablishmentRecoveryResultV1`. Existing-name private
session entries:

```text
_establish_development_bound_effect_intent(command)
_resolve_development_bound_effect_establishment_commit_outcome(command)
```

The exact full command is the recovery selector. No key-only absence proof.
The new command schema is:
`governed-execution.nwp-establish-development-bound-effect-intent-command.v1`
with `.identity` domain. Its fixed scalar-coordinate order before typed payloads is:

```text
schema_id, mutation_ref, effect_class, program_ref, program_version_ref,
accepted_intent_revision_ref, work_item_ref, work_item_revision_ref,
basis_decision_ref, basis_decision_digest, semantic_attempt_ref, candidate_ref,
attempt_fence_ref, attempt_fence_digest, originating_command_ref,
originating_command_digest, author_effect_fence_ref, author_effect_fence_digest,
selected_disposition_ref, selected_disposition_digest, phase_basis_ref,
phase_basis_digest, capsule_manifest_ref, portable_capsule_digest, requirement_ref,
requirement_safe_digest, effect_intent_ref, effect_fence_ref,
authority_evaluation_ref, delivery_attempt_ref, adapter_safe_correlation_ref
```

Then retain, in fixed order:

```text
effect_authorization_safe_binding, capsule_manifest, requirement_evidence,
before_blob_entries, after_blob_entries, effect_fence, delivery_envelope,
command_digest
```

Each blob entry is an exact immutable `(relative_path: str, bytes)` pair in the
manifest's canonical path order, bounded by the existing D1 capture constraints.
No absolute path, live object, mutable mapping or class-substituted byte/string
is permitted. The command identity represents those entries by path, byte length
and freshly computed SHA-256, and includes the other canonical typed mappings.
The original semantic values remain available for checks, not hidden in globals.
Use the exact existing class-specific requirement types and section 6.0's NEW
DevelopmentBoundEffectAuthorizationSafeBindingV1. The previous instruction to use
the existing author-only safe-binding class is withdrawn. Reconstruct/validate
all values before trusting equality or their stored digests. Match scalar refs and
hashes to all typed bodies. The reducer receives actual D1 author command/delivery,
AttemptFence, author fence, basis/selection and immutable capture, derives these
assertions and the new effect/delivery; the writer independently reloads the
persisted predecessors after fencing.

Only validate_candidate/review_candidate are supported. No cancellation variant,
redelivery, fresh author/attempt/program version or general admission issuer.
Effect safe-binding input is explicitly proof-only here, narrower than the
AttemptFence and parent grant bounds; never a verified executable grant.

The operation result has the map's fixed safe fields (disposition, mutation_ref,
command_digest, program_ref, decision_ref, program_version_ref, semantic_attempt_ref,
candidate_ref, effect_class, effect_intent_ref, effect_fence_ref,
delivery_attempt_ref, transaction_timestamp) under the DISTINCT private result
identity selected in C2 above. Use `committed` and `exact_replay` like the current
author operation. The unchanged reserved receipt projection remains its exact
nine-field owner shape in `_development_decision_row_values.py:390-415`.

### 6.2 Fenced mutation, complete graph and conservative recovery

Enter the existing concrete writer's operation guard/lease and the existing
transaction controller. Fence before any receipt/current-state disclosure. On
receipt hit, require matching command and full persisted family/graph readback;
no timestamps or policy reevaluation rewrite a historical exact replay.
A conflicting digest or any partial/unverifiable family fails closed.

On a fresh miss independently read/verify actual current program/work preimages,
original development decision, attempt/candidate, WorkSpec binding, AttemptFence,
author command/fence and effect/delivery heads, selected Section 41 disposition,
C1 phase/basis, and current global stop. The effect and delivery basis_decision_ref
is the ORIGINAL development decision, NOT the separate cognitive disposition.
Both predecessor relationships must hold.

Revalidate the actual transient manifest and blobs using the existing portable
capsule relation with the reconstructed author command/fences. Revalidate the
class-specific requirement against the bound WorkSpec and originating command.
A ref/digest assertion alone is not evidence that the body was checked.

Check expiry, class, path and numerical ceilings, no wider grant lifetime, all
identity collisions, and the actual existing effect/delivery set. Enforce the
selected single initial validation and review on this attempt, no second same-
class effect disguised with another mutation ID, and aggregate max_deliveries=3
with each selected effect <=1. Do not invent a durable counter or treat summing
caller labels as proof of the actual committed set. Family-local bounded reads
belong only in the native owner under its existing nominal capability, not in
D2 orchestration or a public generic query API.

Construct and insert EXACTLY six new graph members and one receipt:
1. effect intent: new current ref/class, original program/attempt/candidate/
   command/decision, real capsule digest; cancellation columns null;
2. current EffectFence: new intent/class/ref, original attempt and author command,
   actual capsule, narrower safe binding/ceilings; never reuse the author fence;
3. authority evaluation: new ref/current effect scope, supplied safe binding,
   pending / external_verification_pending; it does NOT authorize execution;
4. initial DeliveryEnvelope: number 1, no predecessor, original author command/
   AttemptFence and original decision, NEW current fence; exact delivery relation;
5. effect head: new intent/fence, revision 0, ready_for_delivery;
6. delivery head: new intent/delivery, revision 0, planned;
7. unchanged receipt family establish_development_bound_effect_intent, command
   digest, exact six-entry graph and existing result projection; inserted last.

Use existing row factories and compute_development_mutation_graph_digest. One
fresh controller timestamp supplies the row/receipt time. Read back all new rows,
relations/projection and exact selectors in-transaction. Invalidate the nominal
capability before the one COMMIT attempt and preserve existing close witnesses.
Do not alter author/program/work/selection/C1 phase heads or historical row times.

Any uncertain commit/close result is not a failed-no-write assumption. Close the
old writer and resolve using a fresh fenced writer and exact command with
readback only. committed_exact may provide its exact recovered result and continue
only after proven writer close. definitely_not_committed and unresolved STOP this
D2 invocation; no automatic reissue, new identity or retry program. The native
recovery vocabulary does not grant a per-task approval or retry authority.
Test exact replay, full/partial/colliding graphs, stale CAS, cleanup, ambiguous
commit and no duplicate families. Any SQL/catalog requirement contrary to the
selected representation is a replan stop, not a schema edit.

## 7. C1 checked evidence and model-entry observation

Add the map's private session method:
`_read_rw0_c1_checked_family(selector: RW0C1AdmitEvidenceResultV1)`.
The selector is an assertion, not a capability. This new endpoint supports only
ranks 1, 5, 6, 12, 13 and 14; other ranks remain outside its caller contract.
Validate it and fence before lookup/disclosure. Do not treat exact outer type as evidence the caller is honest.

Return a detached `RW0C1CheckedEvidenceFamilyV1` owned by `_sqlite_rw0_c1.py` with
fixed ordered fields: admission_result, phase, registry, payload, children,
membership, relations, receipt, evidence_value. Use exact existing row and
relation aggregate types; reconstruct the rank's exact semantic value. Validate
all nested contents and identity joins; no path/connection/cursor/capability leaks.

This is a READ operation under the existing controller: begin the bound read
transaction with existing fencing, lend its nominal capability to existing C1
readers, call full family/receipt verification and canonical reconstruction,
compare EVERY selector ref/digest/rank/schema/time/result/graph field, invalidate
capability, roll back, close with proven cleanup, then return. It is not commit
recovery and does not recompute history using current wall-clock observations.
No new SQL reader kind or C2B 24-query entry; the existing family readers suffice.
A readback/close error cannot return a checked family.

Add a similarly bounded parent-only current-head/global-stop read for B entry
through the SAME controller/session. Select a closed local selector from the D1
phase identity, verify current program/work/selection/effect/delivery heads and
return detached actual owner rows plus a parent observation time. Use the
existing global-stop reader and C1 owner resolution, not a fabricated 'clear'
string or a general open query surface. This is point-in-time evidence; it grants
no new stop writer, continuous currentness or admission permission. Failure stops
before the model.

The actual C1 admissions use `_admit_rw0_evidence` and its existing recovery
entry, with genuine current owner operands, exact transient bindings and immutable
phase CAS preimages. C1 retains one-member dependency-closed admission, fifteen
kinds and no blanket completeness/currentness/authenticity claim. Apply C4's
normal order and record actual reached members on failure. Existing wrapper
result/classification types are not author/validator/reviewer observations.

For separation call the existing evaluator with checked reviewer rank-12,
author rank-13 and the author rank-12 member/relation rows. Validate/refuse a
reused author invocation, effect, fence, delivery or capsule; PID inequality alone
is inadequate. The model's worker_result role uses rank 14 and its retained
adapter locator. The authority role uses the author rank 1; validation/review
qualifications use their own new-fence rank 1 and readiness memberships.

## 8. Evidence children and immutable reconstruction

Keep the existing supervisor as the only Popen owner. Extend its exact allowlist
to the three named D2 fake modules and no others. Existing planner/worker choices,
-B -m invocation, absolute interpreter, shell=False, new session, close_fds,
empty pass_fds, no preexec, exact seven-key environment, monotonic timeout,
bounded streams, cancellation polling, TERM/KILL, direct reap and group-clear
observation remain. Pure process values and actual effects must remain consistent.

Introduce role-specific closed D2 frames; do not reinterpret D1O1/D1W1/NWPF.
Use exact scalar types, canonical encoding, duplicate/unknown/trailing/multiple-
frame refusal, exact magic/length and bounded allocation. Each role frame must
bind actual command/effect/fence/delivery, capsule/requirements and its invocation.
Document fixed magics and fields with source and independent test expectations
before the first new child test. Keep request <=256 KiB, evidence responses <=64
KiB, and model artifact <=64 KiB within a bounded model response <=128 KiB. Existing
supervisor limits may only be used through admitted parameters, not globally
raised. No three-MiB blob payload over stdin: children read their own reconstructions.

The child may emit a closed source-record frame; the parent may normalize it to
the existing WorkerObservationV1 using its retained original before/after bytes.
It must preserve the child-authored outcome, source time, identity and evidence,
and verify the canonical digest and current relation. The parent cannot invent
a successful source outcome or make a missing child into a supplied observation.

The parent reconstructs original base plus captured candidate independently into
TWO separately owned temporary roots. Verify the exact three paths, modes, no
links/special files, hashes/lengths and original capsule relation before launch
and verify unchanged reconstruction after each checking child. A workspace is
not the old author workspace. No Git command, live repository checkout, unowned
filesystem access or credential is involved. Owned same-user permissions are proof
controls, not an adversarial sandbox.

Validators/reviewer do bounded REAL checks of actual bytes under a documented,
closed artificial requirement/profile. Derive passed/failed/inconclusive outcomes
from those checks, not a caller 'passed' flag or expected recommendation. Tests
may supply different allowed fixture CONTENT or artificial source policy to
exercise the five semantic outcomes; the child still observes and computes.
Do not expand into compiling arbitrary supplied projects or executing captured
code. Review is a separate role/invocation with its own effect and no author write
job; it must not blindly reuse the validator's result as independent evidence.

Validate the actual child-authored C2A observations, requirement and qualified proof profile,
process result and before/after immutability before admission. Failed starts,
malformed/missing frame, nonzero, deadline/cancel and cleanup uncertainty yield
no fabricated valid checking result. A VALID negative source observation remains
negative evidence and may still support a complete model-input branch.

Use actual run-owned references and exact cross-joins. D1 fixed reference names
are scoped by its isolated database; do not claim globally unique runs or source
authentication from PID/ref/digest equality. Never pass the parent state-root,
database, lock/session/proof/capability, original run owner, token or unbounded
metadata to a child via argv/env/cwd/stdin/descriptors. Observe original launch
inputs rather than rewriting them in tests. Account for even discarded children.

## 9. A checkpoint, B model, and final preadmission handback

### 9.1 Resource-free checkpoint

Define RW0D2EvidenceCheckpointV1 in the named A handback owner, with fixed ordered
fields from the map EXCEPT the deleted custody/original-input fields:

```text
d1_handback, capture, capsule_manifest, adapter_exit, bound_effects,
admitted_families, authority_sources, readiness_source, qualifications,
validator_process, reviewer_process, validation_source, review_source,
validation_result_set, review_result_set, validation_disposition,
review_disposition, reviewer_separation, policy_sources, policy_matrices,
support_sets
```

On complete A: two bound-effect proof values; fourteen checked families with
explicit per-member posture and dependencies; three authority values; one
readiness; two qualifications; two real child outcomes/observations; existing
V38/V39/V14/V15/V40 results; closed artificial policy/risk inputs and derived support.
No 'everything is admitted' implication: only actual C1 families have that posture.
No run_owner, WorkSpec object, fixture or implicit cached custody.

`RW0D2BoundEffectProofV1` holds the exact native command, confirmed result, current
fence/delivery and requirement assertion. Actual command/result/family binding
must be checked. No successful prefix is reconstructed from an expected fixture.
A checkpoint may be inspected at the A development checkpoint, but ordinary
execution proceeds to B without external transport or approval.

### 9.2 Nine-role model input and effect-neutral recommendation

Use the existing exact source schemas, profile pairs, required roles/postures,
canonical refs/digests and support-value counts (0,0,6,7,4,4,0,2,5). Bind each
support to the actual lineage and observation; a count alone is not proof.
Model roles at ranks 5..13, ordinal 0, are:

```text
candidate_capsule, worker_result, validation_result, independent_review,
standing_policy, risk_lane, authority_currentness_attestation, global_stop,
effect_ceiling
```

Worker result and authority are exact C1 values. Other roles retain their actual
transient/source support posture. A's history remains immutable. At B entry
perform the actual point-in-time stop/head read and recheck all applicable
currentness/expiry without backdating, silently renewing source evidence or
claiming that checked admission stays current indefinitely.

Use current post-execution V01 lineage, V03 entries, V05 safe model projection,
V07 private manifest, V02 context and V10/V11 evidence supply. A successful pure
constructor is an equality/shape relation, not evidence acquisition. Construct
only after required source inputs exist. Do not invoke V22-V34 or pass an alleged
authoritative branch from the model/harness.

Invoke one fake review-model child via the sole supervisor only after the required
writers close. It consumes the exact bounded context/supply. Its deterministic
algorithm chooses among the five existing recommendations based on real supplied
validation/review, separation, risk/policy, stop/authority and ceiling evidence.
No expected recommendation, action override or fixture outcome field is provided
to that child. Controlled artificial policy inputs are not hidden authority.
The parent must validate the returned content against input binding and closed
grammar, not overwrite it with the answer it expected.

### 9.3 Common pure phase branch and canonical transient content

Extend only the existing common ModelSourceInvocationV1,
PrivateProposalArtifactBindingV1, ModelProposalEvidenceBindingV1,
ModelProposalEvidenceSetV1, and historical-name PreExecutionModelProposalV1
validators to admit the exact post_execution_semantic_review tuple. Preserve
pre-execution bundle/artifact/context/projection and its 14-or-15 role behavior;
post-execution has exactly nine complete roles for this proof. Test mixed-phase
schemas, recommendations, binding sets and aliased/shared mutable values fail.
Do not rename/export old classes, change existing field order or digest domains,
or claim a model proposal is a persisted row.

Post schemas remain the specified Section 41 identities:
- governed-execution.nwp-post-execution-semantic-review-context.v1
- governed-execution.nwp-post-execution-semantic-review-artifact.v1
- governed-execution.nwp-post-execution-semantic-review-safe-projection.v1
- governed-execution.nwp-model-proposal-envelope.v1 (common envelope)

Implement phase-specific pure PostExecutionSemanticReviewArtifactV1 and
PostExecutionSemanticReviewSafeProjectionV1 in `_rw0_d2b_proposal.py`. Keep their
map-selected field order. Artifact:

```text
schema_id, artifact_ref, proposal_ref, proposal_phase, input_context_ref,
capsule_manifest_ref, validation_disposition_ref, review_disposition_ref,
findings, recommendation, reason_code, artifact_digest
```

Projection:

```text
schema_id, proposal_ref, proposal_phase, artifact_schema_id, artifact_ref,
artifact_digest, input_context_schema_id, input_context_ref, input_context_digest,
recommendation, reason_code, safe_projection_digest
```

Use a bounded tuple (0..8) of pure `RW0D2ReviewFindingV1` entries for findings:
`finding_ref, source_role, source_value_ref, source_value_digest, reason_code`.
source_role is one of the nine actual role names; the ref/digest must resolve to
that exact bound input. Ref grammar and reason codes use the existing closed
safe scalar rules. Unique finding refs; canonical source-role/rank order and
stable per-role ordering; no freeform metadata, unknown fields, live handle or
unbounded raw model text. This is a newly implemented bounded artifact detail,
not a claim that the complete artifact value was already in current source.
Record it under the existing Section 41 phase owner via the D2 detailed source
doc and its narrow cross-reference; preserve earlier history.

The model frame supplies its source content and fixed correlations; parent
normalization validates and derives these canonical fields, artifact bytes,
safe projection, common source invocation, private artifact binding, nine common
evidence bindings/set and common proposal. Domains use the corresponding existing
schema + .identity rule; exclude only each named self-digest. Preserve distinct
input-safe projection and output-safe projection identities. Do not build a
completed model source before the actual child has completed.

Parent times: context before launch, start before actual launch attempt, completion
after clean process outcome, then artifact validation, evidence binding and
proposal normalization in nondecreasing whole-second UTC. No future recording,
receipt, rank-15 or C2 decision time exists here. V09 binds these actual normalized
values to the exact V02/V05/V07 input after proposal construction. Later recorders
may refuse stale data; they cannot silently rewrite its historical recommendation.

### 9.4 Final wrapper and path-free handback

Implement separate RW0D2OfflineRun holding ONLY original D1 owner, the final
handback, and its creator/closed housekeeping. It delegates custody and exposes
no public serializer; it adds no second database or durable lifecycle. Its direct
`.handback` data graph is not custody. All owner-affecting actions fence PID and
closed state first. Do not depend on __del__ for cleanup.

Final RW0D2PreadmissionHandbackV1 has the map's evidence fields (status/reason,
d1_handback, committed_bound_effects, checked_admissions, child_outcomes,
evidence_checkpoint, input_context, evidence_supply, model_input_binding,
model_source_invocation, private_artifact, artifact_binding, safe_projection,
evidence_bindings, evidence_set, proposal, model_process). Define fixed exact
nested types/cardinalities and a reason/evidence/cleanup matrix from actual
producer sites. child_outcomes retains the 0..3 actually observed attempt prefix;
model_process, when present, equals its corresponding outcome, not an independent
success claim. No object/Any/map slot as an escape hatch.

Ready requires complete A, exact nine roles, authentic model invocation/output,
canonical complete post-phase values and proved process/workspace cleanup.
Stopped/cleanup_unresolved retain true reached evidence and do not invent a
model block recommendation or erase negative process facts. No raw traceback,
path, blob, fixture, credential or owner enters repr/errors/logs. A complete ready
handback contains no retained run handle even through its evidence checkpoint.

## 10. Guard changes and historical compatibility

Coordinate actual direct imports and named roles across B1, Wire, C2B row/reader,
SQLite nominal access, pure post-execution consumers, package and executable
inventories, and scoped C2 nonimplementation. Never route an import through another
module or inspect a runtime type by name to evade a fixed guard.

Current post-execution allocations and internal DAG are preserved. New D2 external
consumer checks have fixed literal path/symbol/function roles with independent
negative controls for unauthorized callers, extra symbols/exports/dynamic loader
forms and unintended I/O. Leave V22-V34 without production decision callers.
C1 readback proof fields do not acquire capability by merely being constructed.

The new native writer is an explicit fifth C2B2 private reader consumer where it
actually imports those roles; existing 12 roles/24 query specifications remain.
Add its permitted SQLite/global-stop/row-value consumer roles only to the named
guards that actually govern them. No blanket allow for filenames beginning D2.
Legacy sole-subprocess-owner tests need not change: the supervisor path is the
same. Test counts and exact source inventories may change truthfully; frozen
historical baseline checks remain historical rather than rewritten as current.

Add a D2 current-status successor to the large C2B doc and update its exact
projection in test_c2b0_durable_state_contract.py. Preserve the original
1,887,232-byte protected prefix and unrelated bootstrap/genesis histories.
Do not claim that all broader bound effects/observation ingest/current C2 are now
implemented; only this selected validation/review subset is current.

AGENTS/README changed-file hashes must be fixed literals in Capability and the
independent bootstrap checker. Preserve one literal binding/no dynamic replacement
and prior identity attribution; compute updated endpoint hashes only AFTER final
doc bytes and insert explicit constants. No runtime derivation of expected identity.

## 11. Development checkpoints and finite acceptance evidence

The report cites actual native commits/recovery, checked families, five child
roles and recommendations, but documents only three transformed-copy results
in detail. It does not substantiate every original finite obligation below.
Build a compact coverage register from actual retained command/results; preserve
credible completed observations with their exact source identity, and execute
only unsupported or materially affected causal checks on current bytes. Do not
require old deleted payloads as a new user-delivery prerequisite; construct and
identify equivalent current copies where necessary. Normal-suite passes alone
cannot close named causal rows. No new assurance categories are added.

Run C7's guard discrimination BEFORE expensive final validation. Keep fixed
positive and negative controls separate from altered source. Report whether each
failure proves the intended boundary rather than a stronger earlier validator,
syntax error or global inventory guard. The earlier one-layer C1 mutation was
masked; it gives no credit for the intended layer. The two-layer result has only
the scope actually demonstrated, not proof of each redundant predicate.

The latest diagram is a summary, not timing evidence: actual C1 sequence and
qualification-before-child/writer-close ordering must be observed at the lower
call sites. Parent disposal of D1 state is distinct from D2-owned reconstruction
cleanup; do not infer all custody guarantees from the report's shorthand.

Continuation entry: authenticate and read the ten retained files; correct the
binding contract/consumers/tests under section 6.0; demonstrate the two native
commands and unchanged author compatibility in fresh external copies. Re-run
all SEVEN A0 D1 tests after the final retention/chronology/test corrections.
The prior 16-test selection cannot discharge that checkpoint. Inspect direct
consumer restrictions before continuing; do not change the old author owner.
Proceed to A/B in this engagement when the fixed prerequisite checks pass.

A0: implement D1 retention/chronology and the exact pure/native result distinctions;
focused tests show the original adapter survives and actual sample times/negative
paths remain truthful. Include the whole-graph custody prohibition early.

A: implement the native bound families and checked C1 readers, actual two checking
children, safe reconstructions, admissions and resource-free checkpoint. Save and
reopen one substantive source/test checkpoint in the task-owned external area,
record exact candidate identities and focused results, then continue in THIS
engagement. Do not require a user to keep a live D1 process across development
sessions; each integration test uses its own disposable invocation.

B: extend the pure common phase branch, exact role supply, one model invocation,
normalization and final handback. Complete all coupled guards and final checks.
No standalone docs pass, A-only publication or additional coding attempt.

Permanent tests and a SMALL finite external-copy campaign must discriminate these
already selected boundaries. One specimen can satisfy several rows only when its
actual failure proves them; do not count syntax/import/inventory failures as causal
runtime protection. Keep fixed expectations outside mutated helpers. No full-suite
run per mutant. Record actual commands, selected nodes, complete copy hashes and
which effects happened. The following is finite, not a quota of arbitrary variants:

- Adapter omission/substitution/cross-run: actual classifier object -> handback ->
  rank12 -> rank14; no new observation fabricated after failure. Check exact inner
  graph, not outer type or hidden repr.
- Event-time misplacement/reversal/2028 reuse and stale qualification: samples at
  real events, <= where allowed; invalid history stops before dependent process.
- Native owner bypass, author-fence reuse/wrong decision or over-ceiling attempt:
  verify real committed six-member/receipt graphs and original unchanged heads.
- Receipt/row collisions and missing members, before/after commit uncertainty:
  real writer/recovery, no duplicate/updated historical timestamps, no later child
  after unresolved or definitely_not_committed. Cover both bound effects and
  representative C1 dependencies without a full combinatorial cross product.
- Checked C1 readback replaced by supplied expected rows, selector/receipt mismatch,
  capability used after invalidation or close failure: no checked return/admission
  projection is accepted merely from a well-shaped value.
- Validator/reviewer omitted, observation relabeled from author, wrong current
  fence/delivery/capsule or copied reviewer identity: actual separate effect and
  source identities, original relation checks and genuine negative controls.
- Reconstruction or independent capsule verifier skipped, outside hardlink or
  extra path: real no-alias positive and targeted failure not masked by a different
  malformed fixture. Checking children do not write candidate bytes.
- Actual lower Popen inputs/FD census: real run's state-root/DB sentinel, extra or
  early child, unrelated direct fixture is not composition evidence. Observer is
  call-through, never a sanitizer or execution gate. Capture all attempted children.
- Lost process reap/group-clear/selector cleanup: real process trace and failed
  permanent test. Audit/repair rescue must be separate from runtime cleanup credit.
- Nine-role/support swap, stale B-entry stop/currentness, model invocation omitted
  or expected-recommendation shortcut: result depends on the actual checked input;
  no model-supplied C2 branch or fabricated negative proposal.
- Raw live run in checkpoint/final handback, arbitrary nested object, wrong PID or
  closed owner, missing ready evidence/impossible later prefix: fixed inventory,
  deep validation, independent consumption rejection and safe owned cleanup.
- Mixed pre/post semantic schemas/recommendations/evidence cardinalities: preserve
  existing pre-phase behavior and exact post-phase canonical digests/content;
  no row/receipt/rank15 creation or call of C2 decision-time helper.
- Unauthorized pure/runtime/SQLite/subprocess consumer, extra executable/new C2
  owner or dynamic protected hashes: each owning independent guard discriminates
  its finite role without blanket exceptions.

Test the five legitimate model recommendations from actual proof content/policy
inputs, and source-negative outcomes separately from process failures. No fixture
expected recommendation may be delivered to the model. Track every subprocess
handle/group/root even if a deliberately broken copy omits it from a handback;
rescue only positively owned resources and identify it as test cleanup.

## 12. Exact validation posture and command selectors

The prior PRE-REPAIR copy collected 116 / 160 / 118 / 659 / 178 / 3,896 nodes
for the six groups below (5,127 occurrences, 5,125 unique reported IDs). The first
five passed, GUARDS had five failures; four corrections were made after that.
The final five-test smoke left only the B2a defect. Those are prior observations,
NOT fixed expected final counts or completed final-byte runs.

The report labels its hashes 'collection inventory'. It does not specify their
serialization well enough to compare them with earlier test-file inventory
hashes. Do not conflate node inventories with raw test-module inventories, or
make a new expected hash from the observed value. Record BOTH final grammars:
(a) sorted test paths: u32be(path length)+path UTF-8+raw SHA-256(module bytes);
(b) node IDs: sorted/deduplicated complete UTF-8 IDs, each u32be(length)+ID bytes.
Preserve parameter text, including spaces. These outputs are measured final
evidence, not previously supplied fixed identities to silently overwrite.

B2a already belongs to GUARDS, not BINDING_COMPAT or another named group. A
one-file-only repair changes the GUARDS/full test-file inventories; first five
test-file inventories remain equal to THIS authenticated opening. Nevertheless
rerun all SIX groups and full collection/execution from a fresh final normal
candidate because four other closing edits have no complete final run. Any extra
original-ceiling correction requires accounting for its affected inventories.
Do not freeze the final count at 9,005 or predict it by summing overlapping groups.
Recompute all overlaps and membership from actual full collected IDs.

All execution is in fresh local-only external copies/clones of exact baseline
plus this candidate, with no configured remote and no copied live cache. Live
repo operations are only authorized file edits and inert/guarded Git reads.
Use installed Python 3.13 and pytest, test-process umask 022, owned TMPDIR,
PYTHONDONTWRITEBYTECODE=1, PYTHONPATH=.:src and -p no:cacheprovider. No xdist,
parallel groups, package installs, live imports, real provider or network access.
Precreate distinct external basetemp parents. Collect BEFORE each execution.

For each selected group from the validation copy:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-group-collect> --collect-only <exact-paths>

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-group-run> <exact-paths>
```

Exact proposed focused selectors (each token expands to tests/test_<token>.py):

```text
A0_D1: rw0_d1_handback_values, rw0_d1_worker_process, rw0_d1_process_frames, rw0_d1_process_supervisor, rw0_d1_planner_process, rw0_d1_workspace_capsule, rw0_d1_offline_integration
BINDING_COMPAT: c2b3c_author_effect_contract, c2b3d_author_effect_establishment_contracts, c2b3d_private_atomic_author_effect_establishment, c2b3d_author_effect_establishment_recovery, c2b3d_private_author_effect_delegation, worker_execution_semantic_relations, worker_execution_semantic_vectors
A_NATIVE: rw0_d2_bound_effect_contracts, rw0_d2_bound_effect_persistence, rw0_d2_c1_checked_readback, rw0_c1_mutation_contracts, rw0_c1_private_atomic_persistence, rw0_c1_private_readers, rw0_c1_reader_contracts, rw0_c1_recovery, rw0_c1_row_values, rw0_c1_semantic_values, rw0_c1_writer_session_delegation
A_EVIDENCE: rw0_d2_process_frames, rw0_d2_evidence_children, rw0_d2_c1_checked_readback, post_execution_pure_owner_values, post_execution_pure_owner_relations
B_MODEL: rw0_d2_model_handback, rw0_d2_offline_integration, section41_cognitive_proposal_semantic_values, section41_cognitive_proposal_row_values, section41_pre_execution_plan_disposition_contracts, section41_pre_execution_plan_disposition_recovery, section41_private_atomic_pre_execution_plan_disposition, section41_private_pre_execution_plan_disposition_delegation
GUARDS: post_execution_pure_owner_boundaries, rw0_b1_boundaries, rw0_b2_wire_boundaries, rw0_b2_capability_boundaries, rw0_c2_bootstrap_acceptance_guard_semantic_contract, rw0_c2_durable_progression_decision_semantic_contract, rw0_c2_private_value_versioning_contract, rw0_remote_contact_phase_entry_contract, c2b2_development_reader_contracts, c2b2_development_row_value_boundaries, b3b2a_read_scope_and_query_contracts, b3b2b_select_readers, c2b0_durable_state_contract, autonomous_software_development_operating_model, architecture_contracts, c2a_nonimplementation, runtime_non_authority, sqlite_backend_b0_contract, b2a_writer_session_contract, b3a_persistence_contracts, sqlite_b1_runtime_boundary, sqlite_b2c_writer_session
```

At intermediate checkpoint A, run only completed applicable selectors; record
what is not yet implemented. After the last source/doc/test edit rebuild ONE
normal final clone and run all SIX groups serially (including BINDING_COMPAT),
then one complete repository
collection/execution with NO test-path arguments. Overlap is expected; report
unique full node IDs without splitting parameter strings on whitespace. Do not
manufacture coverage by adding group totals. Do not run a new full suite just to
label the same unchanged passing result again.

The 9,005 tests /124 modules/three known writer-session fork warnings describe
BASELINE evidence, not a frozen D2 test count. Report actual final new totals and
inventory hashes. Source must add real tests, not remove/skip/xfail existing ones
to meet a number. Only the established Python 3.13 fork DeprecationWarnings in
these three existing tests are expected:

```text
test_operation_guard_close_waits_and_retains_authority_until_exit
test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Inspect structured records; no warning suppression or new-warning relabeling.
Unexpected source defects may be repaired ONLY within the authorized ceiling;
then rebuild and rerun affected final gates. An identified external driver error
may be corrected externally and affected gates rerun; distinguish every trial.
A failed/import-shortened mutant is not the intended semantic negative signal.

Also check all new files by no-index whitespace and all tracked diffs, strict
UTF-8/no BOM/CR/trailing whitespace/final LF, exact regular-file/Git modes, source
and executable inventories, migration/catalog/public preservation, and initial/
final 263 baseline endpoint accounting. Tests use disposable SQLite only, never
the live product state. Record before/after equality of each validation clone's
candidate source endpoints. Scans use lstat; open/hash only regular files and
never follow test symlinks or open FIFOs/sockets/devices.

## 13. Exact provenance, failure handling, and closeout

Live HEAD, tree, refs, upstream, worktree membership, INDEX bytes/metadata and
cache directory/member bytes/metadata remain the opening values. Candidate edits
are unstaged working files only. No index write or 'git add -N' is authorized.
All actual changed paths must be a subset of section 4; all other tracked paths
must remain byte- and Git-mode-identical to the fixed HEAD. Every new path must be
from C; no __pycache__, database, generated package, build/cache metadata or audit
output is left in the repository. Preserve existing known cache without importing it.

Use ordinary binary/no-ext-diff/no-textconv Git diff for inspection, but closeout
identity must include untracked source payloads too. Construct twice, from fresh
reads, this exact replacement stream over the ACTUAL changed set:

```text
prefix: ASCII RW0-D2-BINARY-REPLACE-V1 followed by one NUL (25 bytes)
rows sorted by UTF-8 repository-relative path bytes:
  u16be(path length) + path bytes
  ASCII M or C (relative to fixed HEAD)
  u32be(0o100644)
  20 raw baseline Git blob bytes, or 20 zero bytes for a C path
  u64be(final payload length) + exact final payload bytes
```

This stream contains RAW bytes, not per-file digests. Report row/component counts,
byte length and full SHA-256; never fill missing hashes with abbreviations.
Also report every changed path, status, baseline blob or absence, final size/SHA-256,
Git and OS mode. Receipt identity is evidence only, never admission or acceptance.
No delivered patch/ZIP/manifest is requested; operative report and receipts inline.
Task-owned manifests/logs/checkpoints are external scratch and removed after
final comparison. Do not demand historical D1 mutant payloads or create another
user-transport prerequisite.

Keep the same opening record/helper through all immutable comparisons, then
remove only task-owned roots after all processes terminate. Retain exact handles
for deliberate negative copies, and separate emergency rescue from production
cleanup. No kill-by-name, generic /tmp sweep, following links or cleanup of an
unrelated original run injected as evidence. If cleanup is unproved, report it.

On a substantive stop, preserve this engagement's existing candidate bytes and
classify the highest completed source checkpoint. Do not restore all changes
just because a guard outside the ceiling is implicated; do not widen that guard
without authority either. No source or test mutation is authorized after closing
receipts without rebuilding/revalidating that new exact candidate.

Success requires complete A AND B, all final validation, finite causal controls,
truthful authority/nonclaims, fixed protected surfaces and owned cleanup. Return:

`RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_IMPLEMENTED_VALIDATED_READY_FOR_INDEPENDENT_AUDIT`

Alternatives:
- `RW0_D2_SOURCE_ENTRY_PROVENANCE_BLOCKED`: opening/baseline/access/preservation;
- `RW0_D2_IMPLEMENTATION_REPLAN_REQUIRED`: one exact owner/field/row/migration/effect
  contradiction or indispensable unlisted path prevents this selected source scope;
- `RW0_D2_IMPLEMENTATION_VALIDATION_BLOCKED`: in-scope validation/cleanup incomplete.

Do not use READY merely for a map, value-only test or A-only checkpoint. A READY
implementation is still not independent acceptance, staging, commit, publication
or D2 live authorization. Its next gate is independent audit of exact bytes.

Return inline:
1. supported verdict; settings; opening/closing coordinates and scope, including
   authentication of the retained 67-path opening rather than a false clean start;
   explicit first-live-posture baseline-cell reconciliation, unchanged aggregate,
   current guidance identity, new B2a permission and author-preservation checks;
2. actual implemented call graph and A/B checkpoints, five process roles across
   D1+D2, actual guarded operations and writer-close boundaries;
3. every source correction above: owner-free nested evidence, full native command
   inputs, distinct result/projection identities, chronological adapter retention,
   real dependency order and all coupled guard dispositions;
4. exact new command/result/recovery/readback and content schemas, fields/domains,
   current source claims versus later Section 41/C2 omissions;
5. actual positive/negative/response-loss/replay/cleanup/model evidence with exact
   tests, paths/lines and full transformed-copy identities; no oracle masking;
6. exact final HEAD-relative changed-file table and replacement identity twice;
   report every actual opening-to-final transition with full sizes/hashes and its
   causal reason, identify the new B2a amendment, and state exactly which of the
   67 retained endpoints stayed byte-identical. No duplicate historical table is
   required; do not conceal a source correction inside an 'unchanged' total;
7. commands, selectors, collections/results, full-node overlaps, warnings, skipped
   work, corrections/interrupted trials, and clone/source equality;
8. every protected source/schema/ref/index/cache fact and external effects/cleanup;
9. concise continuation capsule <=800 words for independent audit, not a new prompt.

## 14. Baseline receipts for the closed M ceiling (source-entry corroboration)

These are calculated from the supplied merged-tree snapshot. Verify against live
HEAD at entry; they are neither section 2A's current working-overlay receipts nor
final payload expectations. Forty-four of these M files already differ in the retained
candidate. A permitted path still unused should keep this HEAD value and stay
outside the final changed set. C paths remain absent from both HEAD and the
unchanged index; all 23 C paths already exist only as working files.

| M path | Baseline bytes | Baseline SHA-256 | Baseline Git blob |
|---|---:|---|---|
| `.docs/architecture.md` | 44056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `7d21418a68d2d3002753227da08cf059836d0260` |
| `.docs/authority-boundaries.md` | 35881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `3524d11d67a46344214b455396afeeaa3754b41d` |
| `.docs/autonomous-software-development-operating-model.md` | 40903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `a46d51fe3ea480e39c8c7989a08e80d9db21f5b8` |
| `.docs/b3b2a-read-scope-and-query-contracts.md` | 9738 | `aa91aefbd8be7f1d003b9bd4cc4c4cdff2bd16ff63a99cc7071a748626f17213` | `c3237c31fc4b59dcd632b827a4be9907cfcfb998` |
| `.docs/b3b2b-select-readers.md` | 6171 | `c961569cdceec4f5e8f2ecb5d5841b6bb95c76fcb3dfce9240d39e52ec502261` | `f1ba74b0a5cd3946a3138de326949d29f789cfac` |
| `.docs/c2b-durable-development-state.md` | 1890378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `04c068d07cd08feaf6c56dafbf3494ccde037ede` |
| `.docs/c2b2-private-readers.md` | 12889 | `c1d4234648f0c44d7b1ccd07c79197ac4d784b0d745468f0236b44977b455d8f` | `018b3d905f5db80cf15b546f881dc8c1de3a67b7` |
| `.docs/c2b2-pure-durable-row-values.md` | 8244 | `3ead05378cdb0eb258bcdadf9ab2be704d0162986ffa7f4b509c5db0a6266ccd` | `1cab6d886f2cd3101987476064a9ce82d2eb4dd2` |
| `.docs/durable-state-model.md` | 41759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `49694cd86a51f3fb0fb3799e734a52c1a395b8c7` |
| `.docs/rw0-b1-pure-phase-values.md` | 34629 | `a353aadd81f7dd0e4ac8a57e5a3d2682725c90a17b00634353aade08e733ecad` | `5b7fb0072c6d04898cd212fdc4ff5f63903cf13b` |
| `.docs/rw0-b2-wire-protocol.md` | 25395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `5e41d1cb3b2f430d29eb88bdbf2b46570faf3c6b` |
| `.docs/rw0-c1-durable-evidence.md` | 14370 | `3507dca630a103a8ba54f643b662183371ae8d76333d721a91ba6e716eb9f93b` | `a7111c4dcf761b60df35c59794bf2e3acd949745` |
| `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `56a0d057ec833234edc2dc7345a11706b9446b80` |
| `.docs/rw0-c2-first-live-proof-posture.md` | 16985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `4b69e424655ea67900f6c6042c0cbacaf2d53f8a` |
| `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `f3557ca523cac0d6fa26647b17a84aef66fecc15` |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | 59292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `230167a39b115634c8f9b5ae5a0699639f6ff454` |
| `.docs/worker-execution-boundary.md` | 32115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `464aef2aa7a561e4adc6792d1d07642d3576f364` |
| `AGENTS.md` | 62778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `254854d4a57487d97ce02a73ce2ed26c86ece170` |
| `README.md` | 46898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `088c832ca7e28d18c82ff6317738ac8ca1c7b5d1` |
| `src/ge_nwp_coordinator/_cognitive_proposal_semantic_values.py` | 69555 | `2a2a8259576ef0b408a9ee7db5fa40069c3981949556083d28db4787ec109b35` | `c164616b9e86379c3c6a9210cf4941429a596d4c` |
| `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `cb37f733141f1e3c3ce874fcc052149de1f82881` |
| `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 14257 | `4de860eec2bd4a233506bd1b6df48226943ecb63947230089737068d89bb45b9` | `ecfcf767a5f1c32c0cf007a2c8aa3137ef92374d` |
| `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 23206 | `7dfa5346b71237c17977fc2ab64d01e81f8708b3a06e186fc8d97e25d270cd95` | `4f2a82e46fda9be8123888f5ca46968a4345c25f` |
| `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 12023 | `cae6310a605e4b5fc55a0068155360ad42fc7a0a7568a1210c45ffd38e07bf2a` | `7dc90a0442e348aaac985d711c4d1a97adb7cc05` |
| `src/ge_nwp_coordinator/_sqlite_rw0_c1.py` | 192869 | `c2e682b4c92f90f6e64c7882476ce38b82d87771ce574ffdbb75d3ae754ec5ec` | `635b5dd49256e14103fced6ff8ea4db76649e22c` |
| `src/ge_nwp_coordinator/sqlite_transition_transaction.py` | 162612 | `6833879bce815e6440945563538e714aae8081430d3275dca132ce10f1f51d2d` | `f8053db4010faaba41b38b531d93a8b21e80daa8` |
| `src/ge_nwp_coordinator/sqlite_writer_session.py` | 284048 | `076200b37cdfbf5648bce5b82f290f69e88beaf62187430589d82f2f1be132ec` | `97162e3a749a7f1f1ae75de90c4b2d9092068107` |
| `tests/test_architecture_contracts.py` | 100517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `c595611ac47ebe2c12d522886150aa4ec1975e67` |
| `tests/test_autonomous_software_development_operating_model.py` | 72904 | `e9a77edb1f99b181c612e52c4a7cfee814ac3f0df4d974e7c3a0756aec6da8df` | `811c5716fdee034814e0f31511f9c901f44cae9b` |
| `tests/test_b2a_writer_session_contract.py` | 26240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `ccadd884de29d606c9243ea7796cc380e29fe5c2` |
| `tests/test_b3b2a_read_scope_and_query_contracts.py` | 26418 | `950656a6b640e71f6146930d83c0ed2269a01f9226fc78b39c0d2648d062fe09` | `66cab4655d33c1b864f5fb4c22e853a39c5a8188` |
| `tests/test_b3b2b_select_readers.py` | 116316 | `0082d6e86e77009cb24e4f09d0177a1e88b77f3abd667bda6e8e01bcc5d1cf25` | `c0c5a0e091572f30a428fd5a2634c21d25a6ad64` |
| `tests/test_c2a_nonimplementation.py` | 29764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `3f343ae5886c92941ebfff63ba4213de2109025e` |
| `tests/test_c2b0_durable_state_contract.py` | 885966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `b910d61aaf670ba40a0d649f933c06767e7360e5` |
| `tests/test_c2b2_development_reader_contracts.py` | 70509 | `1fa8e67321eb3f29fc20c90cd0ea81261347852c3434cd8e298fcacf15212e12` | `122f0d44b46e0a8d7b283d5baec1ce465e2028b6` |
| `tests/test_c2b2_development_row_value_boundaries.py` | 17823 | `4c892136f8c6fd629eb44e95bc8dd7a9aa1a5250e97cc61499171f2835bb4f42` | `d7dea23786bec2ca98bb702bbe93cc31e4192221` |
| `tests/test_post_execution_pure_owner_boundaries.py` | 17931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `437a4e7cbd39682bdd08f03b3a30c0bbbd057614` |
| `tests/test_post_execution_pure_owner_values.py` | 519239 | `8539edc46783a3a53e38bcdac640406c7e63aa431028916e68d1119a1beaf0d1` | `e9248930e8737f517f7154b31f35960e524923ae` |
| `tests/test_runtime_non_authority.py` | 47074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `79d4ab185815234c9d087c48d2439b9a1d95d95d` |
| `tests/test_rw0_b1_boundaries.py` | 51392 | `88eb35d2c0644227c4b8a8276286b69846a25c1a67d158bcc093afd189343967` | `17d1e09c30b01287718c6b5175bac76b03daf458` |
| `tests/test_rw0_b2_capability_boundaries.py` | 50244 | `cadcb41f652a539b5e2ac50ca6fe0bc192e321a663ac338ff9a2516d7d0b5844` | `4668d2a2c285d2d79bf6ebfb0c9c9f60166bcb27` |
| `tests/test_rw0_b2_wire_boundaries.py` | 37866 | `08d0a091ec3383185683f5cab974f7fb08a4fad73e23ef0454f66c4953c4558a` | `9e04f528326a6f337a4f47e7e9f9eda3c9a82e0a` |
| `tests/test_rw0_c1_private_readers.py` | 10200 | `aa7c19014eb8a1289aab5e29e06967465c228ce197fa9e9e19a2379a73f6302c` | `a2af9d6e7a297de068bd82471c870c30d407256a` |
| `tests/test_rw0_c1_reader_contracts.py` | 3435 | `ab397873a25b0430c012db705864133dd5dddad8673aa4b77242190191025051` | `f41a6329f82eb0398e2ad6ba6301b3d90fdfa2a7` |
| `tests/test_rw0_c1_writer_session_delegation.py` | 7993 | `71af3e6e9da066647cccc300ad9e66fe128a9f990f70dde9c02696ae7afff4f6` | `7173fe2c23486187f3763efff7ecd963e4c688dc` |
| `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 120405 | `44089176794734a285afd3852c97fddcfd073fb6d99d2d68667b91952d392921` | `0f0159c172e1448d2b96ab19411e1f85467a2931` |
| `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `e9d95b54a4b5921be8ec39d2bf3f6216204750c7` |
| `tests/test_rw0_c2_private_value_versioning_contract.py` | 339022 | `011d88401851315b18dafee6d17c64e0eb0b509f8598d5dcabad121d349e4762` | `f08a3092f48e0605ce979635d25b012da0fb0a92` |
| `tests/test_rw0_d1_handback_values.py` | 26977 | `bdf1f78b9a359dfbc36c768e8bb44b2151de8bcaf74046401e4f8a9c20d73807` | `982be9b37aa05db0c6d6a3321b775c7c64f2142d` |
| `tests/test_rw0_d1_offline_integration.py` | 53116 | `21796d33330e62b4a389207063022e44c5458a4fe847e509f33d247b65b80afe` | `33c2d85012cbdf0e7e04fdeb7d333d2c8675ae3f` |
| `tests/test_rw0_d1_process_supervisor.py` | 13969 | `7e7c22aed082926936454a128c712e44a26cb51e2d8ff75b54fbf5a79b2564e5` | `4ed2162e5fd09f202cf8be93cb10752c91aa1bf8` |
| `tests/test_rw0_d1_worker_process.py` | 1482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `e2a83abe44db720b5ce0725682ac71d30372959d` |
| `tests/test_rw0_remote_contact_phase_entry_contract.py` | 176999 | `1118eed1b5ac8073a19bd46cf7abde4927d65ca6fb9bbe7275facbdd408a11d1` | `2a9144c3dfd2c883555703c8adecd21f447d6d34` |
| `tests/test_section41_cognitive_proposal_semantic_values.py` | 23659 | `da480022e87d0c8966fcf9c5bbfd9ab268b56676989df6c506f7f71d807911fe` | `61ab0bb935db215af802127b0226f92d6a07d600` |
| `tests/test_sqlite_backend_b0_contract.py` | 26328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `c646df6d439d0b70f45d6d72200fbedb5e730779` |


The source-entry review inspected these supporting owners in the snapshot as
inert data: D1 runner/handback/worker/supervisor; native author command/result and
receipt projection; migration-0002 bound-effect reservation; C1 admission/result,
readers and full readback; the six pure post-execution role/profile suppliers;
common cognitive field and phase validators; nominal transaction/session;
consumer/source/status guards. Static map predictions are NOT runtime tests.
The implementation must read current `.docs/` guidance and relevant full source
and tests before modifying their semantics, preserve the stated baseline, and
report where validation stops rather than invent a guarantee.
