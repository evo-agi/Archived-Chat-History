## Disposition

**Accept the High-severity audit block. Correct the fresh bound-effect expiry check and add durable boundary regressions for both checking effect classes. Preserve the completed handback repairs and the rest of D2. Do not stage, commit, or publish.**

This finding is more consequential than the earlier in-memory handback substitutions: the auditor exercised a real fenced writer in a disposable database and observed a committed validation-effect family at its expiry instant.

The qualification remains important. The binding was an artificial local assertion, and the clock was controlled test input. **The result demonstrates a private durable-state contract violation—not verified external authority or production execution permission.**

No architecture reset, new lifetime contract, or migration is needed.

## Restore the existing exclusive expiry boundary

The selected fresh-path rule is:

```python
transaction_now < binding.expires_at
transaction_now < attempt.expires_at
```

Equivalently, both existing `expires_at >= now` comparisons must become strict `expires_at > now` comparisons.

The baseline B1 owner explicitly requires `observed_at <= now_utc < expires_at` and states that equal-time expiry fails. It also requires the current time to be strictly before each applicable expiry. See `.docs/rw0-b1-pure-phase-values.md:181–185,252–265`.

**Use the transaction’s existing sampled time.** Do not introduce a second clock, grace period, one-second adjustment, timestamp clamp, automatic renewal, or constructor-only substitute for the guarded writer check. The native owner must enforce the boundary on the actual fresh operation after fencing and the required authoritative reads, before inserting the family.

This restores the rule already expected of the fresh writer; the existing audit mandate requires current lifetime validation, exact persisted families, and conservative replay/recovery. Coordinator_RW0_D2_Repaired_V3\_…

### Do not change legitimate containment equality

There are two different relationships:

```text
Current transaction time < expiry
```

```text
Effect expiry <= attempt expiry
```

The first is the exclusive lifetime boundary. The second permits an effect to expire at the same instant as its containing attempt. The baseline effect relation explicitly allows that containment equality at `_worker_execution_semantic_values.py:3843–3845`.

**Only the fresh-time comparisons are being repaired.** A global replacement of non-strict comparisons would change unrelated semantics.

## Exact two-file repair ceiling

Only these existing candidate files may change:

```text
src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py
tests/test_rw0_d2_bound_effect_persistence.py
```

The native writer owns the correction. The persistence test owns the real fenced boundary, no-write, and historical replay regressions.

The other **68 candidate payloads** and **216 noncandidate tracked payloads** remain unchanged. The final handback, checkpoint, integration tests, transaction controller, writer-session owner, command schemas, profiles, documentation, migrations, and consumer guards are protected.

There is no reason to reopen the authority-role, stop-reason, or A-to-B repairs. Nor should a fixed source expectation be refreshed merely to accommodate this change. An indispensable unlisted dependency must be reported precisely rather than bypassed.

## Test the durable boundary—not just the Boolean helper

For **both** `validate_candidate` and `review_candidate`, the permanent tests must exercise the real writer using separate fresh fixtures:

| Represented lifetimes | Transaction time | Required result |
|---|---|---|
| Binding and attempt expire at `E` | `E − 1 second` | Commit the exact target family and receipt |
| Same lifetimes | `E` | `CURRENT_STATE_CONFLICT`; no target durable mutation |
| Same lifetimes | `E + 1 second` | `CURRENT_STATE_CONFLICT`; no target durable mutation |
| Binding expires at `E`, attempt expires later | Before `E` | Commit |
| Same narrower binding, attempt still valid | At or after `E` | Conflict; no target durable mutation |

Each fixture must keep the other prerequisites valid so that an unrelated stale head, invalid command, or malformed fence does not reject first.

The refusal assertions must inspect persisted state after the operation. **Zero target receipts alone is insufficient:** no partial intent, fence, authority-evaluation member, delivery, or head may have survived. Existing predecessor rows must remain unchanged.

These are target-family assertions, not a claim that the database contains no earlier receipts. A review fixture may legitimately contain previously established prerequisites. Logical row comparisons are also preferable to treating SQLite file-byte equality as the sole no-write oracle.

### Account for the overlapping expiry checks honestly

Because a valid effect lifetime is contained within its attempt lifetime, a strict binding check may also reject every valid command whose attempt has expired. Consequently, an attempt-only weakened comparison can be masked by the binding check.

The repair must preserve **both strict comparisons**, but the tests must not manufacture an invalid binding that outlives its attempt merely to claim independent coverage.

The handoff uses two bounded omission controls:

**E01** restores both inclusive comparisons. The equal-expiry durable tests must then lose rejection for both checking classes.

**E02** restores only the binding comparison to inclusive while leaving the attempt comparison strict. The shorter-binding/later-attempt fixture must expose the erroneous equality-time commit.

That isolates the operative binding boundary without violating containment. A masked attempt-only deletion is reported as overlapping protection—not falsely counted as an independently detected regression. This follows the existing audit’s rule against giving causal credit to a predicate that was never reached. Coordinator_RW0_D2_Repaired_V3\_…

## Preserve replay and readback after expiry

**An expired lifetime must prevent a new effect; it must not erase a valid earlier commit.**

For each checking class, the tests must first commit a legitimate family strictly before both expiries. At the expiry instant and afterward, an identical command must retain the existing exact-replay behavior, and readback-only recovery must retain `committed_exact` when its original family remains valid.

The result must preserve the original references, digests, members, receipt, and timestamps. It must not create a second family, renew the binding, or apply the fresh expiry gate as a new authorization requirement for reading established history. Receipt-first replay and readback-only recovery are already part of the selected contract. Coordinator_RW0_D2_Repaired_V3\_…

This positive applies only to **families originally committed before expiry**. It does not legitimize equality-time families created by the old defect. Those audit fixtures are disposable; no live database migration, historical repair, or retrospective approval is authorized.

The guarantee also remains bounded to the existing transaction-time check. This change does not introduce a new claim of continuously verified external authority through the later wall-clock COMMIT instant.

## The current subject is now fully identified

The auditor resolved the two endpoint receipts omitted from the V3 writer’s closeout:

| Protected endpoint | Authenticated bytes | SHA-256 |
|---|---:|---|
| `_rw0_d2_handback.py` | 28,905 | `85ea3872fe52dbf12608b1dcd47499b76ff11fc556b0c689498fdce56346f7ed` |
| `test_rw0_d2_offline_integration.py` | 51,581 | `e682b402875f7115d210d9c11bf1211f004efc388f8414163e4b42556ab96e36` |

The new handoff therefore supplies **all 70 exact endpoint receipts**, with no aggregate-bound placeholders.

The fixed opening is:

```text
HEAD:
43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18

Baseline tree:
cc3cc104300f553ada581cee24e80dab6dd885b1

Candidate:
47 modified tracked paths + 23 creations
70 changed paths; 286 source endpoints

Payload bytes:
5,841,805

Complete framed replacement:
5,847,228 bytes
a9d32c58a765c49301db989de1bbd2d8359a2499535dc2e65a2043527c27dc2a
```

The latest audit reports successful source/index/cache preservation and no change among its 52 observed refs. **There is no provenance restart or ref restoration to perform.** The repair establishes its own opening and retains the conditional diagnostic-ref procedure; the historical ref-rotation cause remains unestablished.

## Validation and audit credit

The latest independent audit passed **49 integration tests** and traced the handback’s nine-role association. It did **not** independently execute X01/X02/R01/J01/J02 in this interval, complete the broader A01–A13 register, or run the six final groups and FULL.

Those omissions remain explicit. A passing integration module does not establish the native writer’s lifetime boundary, and correcting this boundary will not establish the rest of D2.

For this repair, only the persistence-test module may change among tests. Therefore:

```text
A_NATIVE and FULL module inventories change.

A0_D1, BINDING_COMPAT, A_EVIDENCE,
B_MODEL and GUARDS remain fixed.
```

After the last edit, the writer must run all six focused collections/executions and one complete repository collection/execution from a fresh external copy. The count reconciliation is:

```text
final full count = 9,084 + (final A_NATIVE count − 118)
```

That is accounting, not a target achieved by removing tests.

I recomputed the current six module inventories and the full inventory from the mounted baseline and the supplied candidate hashes. The now-complete V3 receipts also allow fixed `B_MODEL` and FULL module hashes to be supplied in the handoff. **This is source-identity bookkeeping, not independent execution or reconstruction of the missing node inventories.**

The repair writer is not tasked with repeating all five prior handback omission campaigns. Those files remain protected, their normal tests run in final validation, and their remaining independent causal review stays with the later audit.

## Complete repair handoff

**Send this once to the original implementation/repair conversation, “00077 54,” not the independent auditor. Leave the other repository conversations idle.**

:chatgpt-content-reference{index="3"}[Download the complete D2 strict-expiry repair prompt](sandbox:/mnt/data/Coordinator_RW0_D2_Strict_Expiry_Boundary_Audit_Repair_V4_Prompt.txt)

```text
Filename:
Coordinator_RW0_D2_Strict_Expiry_Boundary_Audit_Repair_V4_Prompt.txt

Bytes:
67,710

SHA-256:
513cf8ff3b7e9f880c259ab5d5f04604164439a7b22b722c22b80a1c1e83e531

Lines:
1,011
```

It includes the two-file ceiling, all 70 opening receipts, the existing opener and qualified ref treatment, strict fresh-time semantics, both effect classes’ durable boundary tests, post-expiry replay/recovery preservation, E01/E02, exact validation selectors, and complete closing-report requirements.

Success is:

```text
RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT
```

That supports consideration of a separately issued independent re-audit. It authorizes **no acceptance, staging, publication, rank-15 admission, Section 41 post-execution persistence, physical C2, migration, live provider/supplier work, ES/Bridge integration, deployment, or RW0-E**.

## Evidence boundary

I reviewed the latest audit and operative requirements, inspected the baseline B1 lifetime rule, effect-expiry containment, existing receipt-first author implementation, and transaction-clock test usage as inert source. I reauthenticated the snapshot’s 263-file tree, corroborated the 47 baseline blob identities and 23 baseline absences, and checked the seventy-row arithmetic and module inventories.

I reopened the generated prompt and syntax-checked its embedded opener/helper without executing them. **I did not inspect the live native writer, reproduce the expiry experiment, run repository tests, or authenticate the live replacement digest myself.** The durable counterexample remains attributed to the independent auditor.

Some older uploads have expired; re-upload a specific historical original when its bytes are needed for a later comparison. The materials required for this repair were available.

**Sources:** Your latest independent audit; the current audit/repair mandates cited above; Coordinator baseline `.docs/rw0-b1-pure-phase-values.md:181–185,252–265`, `_worker_execution_semantic_values.py:3231–3233,3843–3845`, and the existing transaction/replay source.

**Confidence:** High on the strict-boundary correction and two-file scope. The repaired writer’s durable behavior, replay preservation, complete validation, and independent D2 acceptance remain unproved.
