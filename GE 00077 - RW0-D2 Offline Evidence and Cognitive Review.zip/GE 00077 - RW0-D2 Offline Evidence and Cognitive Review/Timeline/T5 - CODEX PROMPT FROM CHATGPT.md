# RW0-D2 — Bound Effects and Preadmission Proposal: Implementation-Map Completion 01
# Same merged D1 baseline; source-bearing D2 later; NO edits in this mapping pass

## First protected action and routing

Resume the SAME mapping-only parent Codex conversation that returned
RW0_D2_IMPLEMENTATION_MAP_REPLAN_REQUIRED. Do not return to a procedural restart,
use the D1 writer, spawn a subagent, or open a parallel C2 program. This is one
newly authorized READ-ONLY completion interval with an explicitly revised D2
output boundary. It is not implementation permission.

Read the live guidance as plain text, using tool workdir `/`, before any protected
repository operation:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

Read the complete output, then use section 1's existing filesystem-only opener
before Git or other repository inspection. Plain-data reading of this external
instruction is permitted preparation; prefer absolute external paths and neutral
cwd. It authorizes no repository import, Git/index action, script, test, product
state access, or mutation. A cwd alone is not evidence of such an operation.
A real pre-opening protected action still requires a stop; do not replace the
opening record or restore metadata. The helper protects only commands routed
through it, not commands issued before it exists.

After opening and exact baseline authentication, finish the bounded map without
per-step user approval. No tests or collection, repository imports, SQLite opens,
clones, fake-child execution, network, provider/supplier access, installs, edits,
index/ref/config writes, staging, publication or D2 implementation. Inert text,
AST, JSON/TOML and SQL-text inspection is permitted. Return operative findings
INLINE; create no architecture package, standalone contract, freeze manifest,
implementation patch or user-delivered evidence file. Temporary external opening
instrumentation and inert inspection scratch only; remove them at close.

## Engineering disposition: preserve the real finding, separate the two dependencies

The previous map correctly identified that existing production has neither the
bound validation/review effect writer nor a receipt-backed post-execution
Section 41 family writer. It also showed that C1 rank 15 reads an ALREADY EXISTING
Section 41 family, and that the current cognitive receipt is pre-execution-only.
Do not reinterpret those absences as implemented capabilities.

However, they are not both prerequisites for the selected cognitive-loop result.
The original user-facing D2 objective is process-separated validation, independent
review, fake semantic-review-model output, and a typed handback projectable into
the frozen C2 vocabulary. It does not require that the model's newly authored
proposal already be a committed/admitted rank-15 family. The earlier map's fully
admitted endpoint unnecessarily joins those two cuts.

For THIS mapping completion, the cognitive lead selects:

* INSIDE the later one source-bearing D2 tranche: a narrowly supported guarded
  bound-effect establishment/replay/recovery path for validate_candidate and
  review_candidate in the existing disposable database; actual C1 admissions and
  readback required by the existing nine-role model input and reviewer-separation
  contracts; three separate D2 child roles; exact transient model-output values.
* OUTSIDE D2: durable recording of the new Section 41 post-execution source,
  artifact, proposal and evidence rows; C1 rank-15 admission of that family; the
  admitted proposal-family projection and complete decision-time C2 inputs;
  physical C2 decision/acceptance/terminal writers; migration 0005 or any other
  new migration. Record these as later obligations, not missing D2 successes.

The later persistence work must introduce its own legitimate Section 41 receipt,
replay and recovery basis BEFORE rank-15 admission and physical C2 consumption.
It must not make C1 the producer of the Section 41 family. That later work is not
being implemented, physically designed in detail, or run concurrently here.

This is an explicit D2 handback-cut revision and selection of one bounded native
owner implementation for future source work. It is NOT a new wire grammar,
standing-authority claim, C1 kind, proposal semantics, or new program lifecycle.
No source mutation is authorized until the completed map is reviewed.

The map must establish whether this selected cut is actually implementable with
unchanged migrations 0001-0004 and existing frozen semantic fields. Do not say it
is feasible merely because a table or a pure constructor exists. Equally, do not
call absence of the deliberately deferred Section 41 receipt a blocker to a
correctly labeled transient proposal.

## 1. Exact merged baseline and preservation

Repository:
`/Users/ds/Repositories/Governed Execution Coordinator`

Required current local coordinates:

```text
branch: trunk_dev
HEAD: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
tree: cc3cc104300f553ada581cee24e80dab6dd885b1
sole parent: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
subject: feat: add RW0-D1 offline process and capsule spine
upstream: origin/trunk_dev
local tracking ref: same squash HEAD
local divergence: 0 ahead / 0 behind
worktrees: one
index/worktree: clean, all 263 tracked leaves equal HEAD
staged, unmerged and untracked paths: none
active Git operation/sequencer/unexpected lock: none
migration resources: exactly 0001–0004; no 0005
```

The supplied snapshot has 263 source leaves and reconstructs the same exact tree.
Its ZIP is named `Governed Execution Coordinator - Snapshot - 2026-10-16.zip`,
3,134,667 bytes, SHA-256
`06d981b6100fc1d6ad9792aff35800eb0772b8d35f708ed030177967ccb9c40e`.
The filename's date is not a claim that the source predates D1. Archive tree
identity is snapshot-backed; the squash/branch facts came from the merge report
and must be checked locally here. No archive attachment is needed by this mapper.

Do not fetch or contact GitHub. Local tracking equality is not fresh remote
truth. Do not demand the pre-squash source HEAD or recreate the 46-file candidate:
all 263 leaves are now tracked. PR #14's source commit remains historical
`f0e3169c55fad62d8d830d9fc799263d7c5332f1`; no manipulation of it is needed.

Preserve all actual OS modes, including the existing nonexecuting 0600
program-initialization test. The 37 live bytecode files are opaque preservation
material, not source or code to import. No ignored database, secret, credential,
TLS/Vault/OpenAI/Codex state, host configuration or sibling repository is in scope.

### Existing pre-Git mechanism

After the guidance read, run this data-only block from `/`. It reads no product
state, runs no Git and imports no repository module. Its only writes are under
its newly created external root. It preserves index/cache contents and metadata.
This is inspection instrumentation, not run truth, a product receipt or an OS
interlock against commands issued outside it.

```sh
python3 -I -B -S - <<'PY_OPEN'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env


import datetime
import shutil
import tempfile

guarded_environment()
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_not_exact_audited_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_unavailable')
gate_root = Path(tempfile.mkdtemp(prefix='rw0-d2-readonly-map-'))
os.chmod(gate_root, 0o700)
print('GATE_OWNED_ROOT=' + str(gate_root), flush=True)
record = {
    'schema': 'rw0-d2-readonly-map-opening-observation',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents, 'index_path': str(index),
    'index': index_before, 'cache': cache_before, 'git_executable': git,
    'git_environment': GUARDS,
    'limit': 'This mapping interval only. All repository bytes, refs, index and cache stay fixed. No repository or remote mutation is authorized.'
}
READ_HELPER = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\n\nimport subprocess\nimport sys\nopening = json.loads(Path(__file__).with_name('opening.json').read_text(encoding='utf-8'))\n\ndef immutable_checks():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('map_index_content_or_metadata_drift')\n    if regular_record(REPO / 'AGENTS.md')['sha256'] != AGENTS_SHA:\n        raise RuntimeError('candidate_guidance_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n\nimmutable_checks()\nindex_before_read = regular_record(index_path())\nargs = sys.argv[1:]\nif args == ['--check']:\n    print('READ_HELPER_IMMUTABLE_SURFACES_MATCH')\n    print('CURRENT_INDEX_SHA256=' + index_before_read['sha256'])\n    print('Index content and metadata equal this mapping opening; no stage or index write is permitted.')\n    raise SystemExit(0)\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree',\n           'check-attr', 'for-each-ref', 'reflog'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_read_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'], ['--quiet', 'HEAD']):\n    raise RuntimeError('readonly_head_query_only')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('readonly_worktree_list_only')\nif args[0] == 'reflog' and (len(args) < 2 or args[1] != 'show'):\n    raise RuntimeError('readonly_reflog_show_only')\nfor arg in args[1:]:\n    if arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec') or arg.startswith(('--output=', '--exec=')):\n        raise RuntimeError('unapproved_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager', '-c', 'core.fsmonitor=false',\n           '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=guarded_environment(), check=False)\nfinally:\n    immutable_checks()\n    if regular_record(index_path()) != index_before_read:\n        raise RuntimeError('index_changed_during_read_command')\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(payload)

try:
    write_private(gate_root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(gate_root / 'live_read.py', READ_HELPER.encode())
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_first_git')
    print('OPENING_RECORD=' + str(gate_root / 'opening.json'))
    print('LIVE_READ_HELPER=' + str(gate_root / 'live_read.py'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D2_MAP_PRE_GIT_OPENING_RECORDED')
except BaseException:
    for name in ('opening.json', 'live_read.py'):
        p = gate_root / name
        if p.exists():
            if not stat.S_ISREG(p.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            p.unlink()
    gate_root.rmdir()
    raise
PY_OPEN
```

Use the ACTUAL emitted helper and root paths; do not assume shell variables
persist or guess a temporary path. Every live Git inspection uses that helper:

```sh
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> rev-parse HEAD
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> status --short --untracked-files=all
```

The helper performs command-local optional-lock, lazy-fetch and prompt
suppression. No Git WRITE, including write-tree, is authorized. Verify tree and
index equality by reading stage-0 entries and blobs, not by refreshing the index.
Read every tracked payload against its HEAD blob and preserve opening/closing
index content AND metadata and cache directory/member metadata. Complete-tree
identity is sufficient for this map; do not create another candidate manifest.

Allowed analysis: text reads, read-only Git object/ref/status inventory, hashes,
and standard-library AST/JSON/TOML/SQL-text inspection as inert data. Do not import
modules, construct repository value objects, call a reducer, open SQLite, run
pytest (including collection), compile repository code, launch any child/fake,
clone/check out another tree, install a package, or run repository scripts.
A source-level prediction must not be reported as an executed result.

Give one concise opening acknowledgment, then proceed. A fixed-baseline mismatch
ends the map before recommending implementation against a different subject.

## 2. Exact observable result and nonclaims

One private parent invocation must produce:

```text
accepted D1 WorkSpec + artificial fixture
  -> run D1 once using its current guarded program/author/selection/C1 owners
  -> same-creator-process open run owner, ready evidence and proved cleanup
  -> reverify original-base/capture/capsule; reconstruct separate check workspaces
  -> guarded validate_candidate effect/fence/initial delivery -> writer closed
  -> validator child and genuine bounded source observation
  -> guarded review_candidate effect/fence/initial delivery -> writer closed
  -> distinct independent reviewer child and genuine bounded source observation
  -> required existing C1 evidence admissions/recovery/readback
  -> frozen nine-role model input with exact evidence and proof-source provenance
  -> distinct deterministic fake review-model child
  -> exact typed, canonical TRANSIENT post-execution source/artifact/proposal data
  -> path-free evidence/proposal handback plus the one retained parent run owner
```

The precise admission order is to be derived from current dependency closure,
not copied mechanically from this overview. Close every writer/connection/lock
before the next child. Any unresolved required commit stops dependent work; a
physical commit with no caller-visible exact recovery is not permission to launch.

The single model output uses only accept_candidate, repair_candidate, replan,
terminal_reject and block, in their frozen recommendation meanings. These are
recommendations, not execution or semantic acceptance. Cancellation/deadline,
failed start, malformed or unavailable response, and unproved cleanup remain
process/evidence outcomes, not an invented sixth recommendation. Legitimate
negative observations remain representable. No repair/replan execution loop,
redelivery/retry policy, additional author attempt or routine user relay is added.

The successful handback is explicitly NOT any of:

- a committed Section 41 post-execution source family;
- RW0C1Section41PostExecutionProposalFamilyMemberV1 admitted at rank 15;
- Section41PostExecutionProposalFamilyProjectionV2 established from owner rows;
- a complete RW0-C2 decision input/currentness/continuity basis;
- a C2-derived authoritative branch, acceptance fact, terminal outcome or grant.

Keep source-native/ref/digest evidence distinct from later recording timestamps,
receipt/row/graph identities, membership locators and currentness. Do not add
fake null/default owner fields to a closed admitted type to label it preadmission.
The outer private D2 result may identify its support level, but it cannot change
any supplying value's schema or manufacture durable facts.

D2 remains fake-model/fake-worker offline engineering. It does not prove competent
semantic judgment, hostile-code isolation, live supplier qualification, external
source authenticity, restore/handoff safety, public service/CLI, autonomous Git
or deployment capability. The user is not a routine evidence/recovery transporter.

## 3. Keep the completed map; finish only the newly selected critical path

Do not rerun broad reconnaissance from scratch. Reuse prior source pointers as
starting points, confirm their current bytes, and resolve the following four
connected questions before presenting a final prospective edit ceiling.

### A. Bounded validation/review effect establishment on the existing schema

Current owning target: .docs/c2b-durable-development-state.md:389-451.
Current physical reservation: sqlite_migrations/0002_development_program_and_effect_state.sql:537-566.
Current reference implementation: the actual author-effect writer/controller,
its command/reducer/write-plan, family-local readers, exact replay and recovery.
Inspect sqlite_writer_session.py's exact delegates and transaction ownership.

The selected supported subset is ONE initial validate_candidate effect and ONE
initial review_candidate effect for the D1 candidate. Do not implement cancellation
bound-effect mutation, productive/cancellation redelivery, retries, new semantic
attempts, author commands, program versions, or acceptance. The broader target
remains target-only outside that subset; unsupported variants fail closed.

Reuse the original attempt, candidate, originating author command, author fence,
requirements and current program/work basis. Create only the target-required new
current effect intent, narrower effect fence, authority evaluation, initial
delivery, effect/delivery heads and mutation receipt. No new shadow state store.
The shared Coordinator transaction controller still owns BEGIN/COMMIT/rollback,
nominal read capability, writer fencing, lease and commit uncertainty.

Inspect exact preconditions and required existing tables/fields/row digests:

- Which safe external-authority fixture inputs and requirement records are
  supplied, which owner values are read, and which identities the Coordinator
  derives versus checks as caller assertions. Do not copy the author's authority
  binding and change its effect class without establishing the new relation.
- Exact original command/fence post-binding: the author fence is post-bound to
  its originating command, NOT to a sealed capsule. The author capsule field
  stays null. Validation/review current fences bind the actual sealed capsule.
- Snapshot pointer: D1 _author_ingress already lists validation/review in the
  attempt's allowed classes and max_deliveries=3 at _rw0_d1_offline.py:113-145.
  Confirm actual ceilings, counting and all narrower checks. Membership in that
  list is not live authority, an implicit new grant, or permission to widen D1.
- Fresh-state CAS, effect/identity collisions, complete family cardinality,
  one transaction timestamp, canonical command/digests and exact readback.
- Which current receipt family and result projection encode this selected writer.
  Prove the existing physical constraints actually admit its rows. Do not add a
  column, reuse a pre-execution cognitive receipt, or seed a generic receipt.
- Exact replay and commit-response-loss selectors. A new fenced writer may
  resolve uncertainty; neither unresolved nor definitely_not_committed silently
  launches a child or causes automatic reissue in this proof.
- What every write changes and, critically, what it does NOT change in the
  existing author, program/work, Section 41 selection and C1 phase preimages.
  Show later C1 admissions remain compatible with those actual preimages.

Propose exact new/modified private source modules, pure command/result/recovery
values and tests for this bounded owner. Distinguish a minimal native module from
a shortcut importing production fixtures or constructing committed results in
D2 orchestration. The prospective name _establish_development_bound_effect_intent
comes from the owner; resolve the supported subset and companion recovery path
without pretending either currently exists.

Do not expose the operation publicly or turn fixture verification into a live
authority verifier. The only intended caller in D2 is the bounded offline parent;
ordinary session/transaction protection and existing unsupported-live behavior
remain enforced. Name any necessary status/target-subset amendment WITH source.
No standalone docs-only or contract-test-only prerequisite tranche is selected.

If another indispensable owner is found, name its exact prerequisite and why the
existing typed/C1 path cannot supply it. Do not silently add a general ingest,
scheduler, live qualification or source-authority program.

### B. Genuine C1 evidence for the model input, but no rank-15 output admission

Derive the dependency-closed prefix from current C1 specifications. Rank numbers
are not an instruction to populate every kind. For each admitted member, name:

```text
source author -> exact semantic value and identity -> real owner row/operand
-> exact command/recovery delegate -> committed membership/relation/readback
-> actual consumer in the post-execution evidence path
```

In particular, show how author observations/result/classification, validator and
reviewer observations, rank-1 authority evidence, and required host/qualification
or support values become sufficient for the nine existing roles. Supply only what
the existing contracts actually require. Fake source attestations are explicitly
artificial and separately bound to the run; membership rows and receipts are
created by C1, never fabricated by the parent or copied from golden tests.

Current source pointers to inspect:

- _rw0_c1_mutation_contracts.py:398-414 and :550-607 for ranks and owner operands;
- _sqlite_rw0_c1.py:1950-2083 for current preimages and existing-owner resolution;
- _post_execution_evidence_values.py:91-181 for the nine roles and postures;
- :5479-5588 for reviewer separation against actual C1 membership/relation rows;
- :5214-5247 for nine-role supply and :5821-5854 for construct-checked model input;
- .docs/rw0-c1-durable-evidence.md:51-109 for partial admission versus completeness.

The reviewer is separate both operationally and in its required C1/source identity
relations. A new PID is not the separation predicate. A pure evaluator checking
an expected value is not the producer of its independently supplied evidence.

Preserve the rank-14 worker-result and rank-1 authority roles' actual
c1_admitted_exact_value posture. The selected revision does NOT permit synthetic
memberships for them or a transient stand-in for reviewer-separation rows.

Rank 15 wraps a later ALREADY RECORDED post-execution family and is OUTSIDE D2.
No row, relation, locator or receipt asserting rank-15 admission is returned by
this proof. The fifteen-kind C1 inventory, its owner allocation and relation
semantics remain unchanged. Ordinary closed consumer/status additions may be
needed; identify them instead of widening the evidence grammar.

### C. Canonical model input and transient output without semantic translation

The complete map must name every output class/schema, ordered field set,
ref/digest owner and later consumer. The word 'preadmission' alone is not a design.
Keep the exact frozen five recommendations and existing domain-separated digest
and identity rules. A new generic dict/metadata envelope is not an answer.

The snapshot confirms that the existing pure model-input construction does not
itself require rank 15. It does require the frozen nine independently supported
roles. Establish the full causal order: evidence exists -> context bound -> model
invoked -> model output observed -> output normalized/verified -> handback.
Do not fabricate model-source completion before invoking the child merely to
satisfy a type whose status says normalized_typed_proposal_supplied.

The current common cognitive semantic constructors reject the post-execution
phase (_cognitive_proposal_semantic_values.py:1638-1653,1765-1785), while current
row-value grammars can represent post-execution variants
(_cognitive_proposal_row_values.py:807-832,864-928). That is a concrete constructor
coverage seam, not a requirement to persist those rows now.

Select the minimum pure, source-bearing constructor/normalizer coverage for the
ALREADY SPECIFIED post-execution context/artifact/proposal grammar. Recommend its
owning placement and precise coupled tests; do not silently widen a pre-execution
class, bypass its validation, import a test builder, or invent new semantics.
A private new Python type name is not automatically a new wire schema. Explain
exactly which existing schema/identity it realizes and how it stays no-I/O.

Return one prospective field/type table covering:

1. D1 identity/capsule/capture and actual effect/delivery lineage;
2. validator/reviewer source observations and V14/V15/support values;
3. actual C1 memberships required by the nine-role input;
4. model input context, safe projection, private manifest, supply and binding;
5. observed fake-model invocation and private output artifact/proposal values;
6. model recommendation and source-native/normalization timestamps;
7. final process/status/cleanup evidence and parent-only custody delegation;
8. EXPLICITLY LATER owner-recording timestamps/receipts/row membership/currentness
   and complete rank-15/C2 arguments that D2 does not yet supply.

For every final semantic field show its exact future Section 41/C2 destination.
Do not promise that evidence is permanently current. Later source-family
recording, rank-15 admission and decision-time evaluation may reject stale,
revoked or conflicting input without changing its historical semantic content.
Those are later validity/admission decisions, not permission to rewrite the
model recommendation or replace it with an authoritative branch.

Pay special attention to timestamp/digest direction: proposal_created_at,
artifact_validated_at and evidence_bound_at have existing owners. Do not assign
a future writer's commit/recording time today, hash a speculative receipt, or call
unpersisted row objects evidence of their existence. Distinguish immutable
source/semantic payloads from genuinely later record/receipt/graph digests. If
byte/digest identity cannot be preserved at the selected semantic boundary,
show the exact field and owner conflict rather than claiming 'no translation'.

No call to evaluate_rw0_c_recommendation_consistency with the fake model's choice
as the authoritative branch. No C2 completeness/currentness matrix is fabricated
from a passing input constructor. A failed/partial child path must retain its
truthful missing evidence and does not manufacture nine roles or a proposal.

The handback is a typed preadmission supply for later recording/evaluation, NOT
Section41PostExecutionProposalFamilyProjectionV2. Provide the precise new private
outer return shape and fixed nested allowed types, reject live resources/paths,
and keep the one creator-process D1 state owner separate from evidence.

### D. Minimum complete touched-surface closure and acceptance plan

Retain the previous map's safe process/reconstruction arrangement: one existing
supervisor extended to the exact three additional fake roles; immutable D1
input, separately reconstructed validator/reviewer workspaces; real finite checks;
a deterministic evidence-dependent fake model; bounded frames and I/O, actual
Popen-level observation; no user relay; no writer authority across a launch.

Do not reissue the previous conditional file list with 'new owner modules TBD'.
Select one exact prospective create/modify/untouched list for this revised cut.
Each row states responsibility, actual imported symbols/callers, direct owner
and coupled tests/status/machine-record constraints. Include the new bound-effect
command/writer/recovery/readback owner and post-execution pure-normalization
coverage. Exclude any Section 41 proposal-family PERSISTENCE owner or migration.

Complete the static dependency scan for the newly recommended imports and status
changes across current source/tests/.docs/config. In particular:

- bound-effect target-only status, reserved receipt/result row grammar and reader
  permissions; do not add a caller to a frozen reader inventory by accident;
- six post-execution pure owners, their 44-value/31-edge allocation and allowed
  import DAG, exact constructor and future-runtime status records;
- B1 constructor/evidence consumer roles, both independently fixed projections;
- Wire exact forms/symbols/consumers and each helper's finite loader/re-export rule;
- Capability pure semantics, five normalized status blocks and protected rows;
- AGENTS/README literal hash identities and independent bootstrap checks when
  truthful implementation status changes; no dynamic expected-hash generation;
- actual executable entry/module counts and every sole-subprocess-owner guard;
- scoped C2 nonimplementation checks, preserving decision/acceptance/terminal
  absence and migration 0005 absence while admitting only selected D2 consumers.

Keep __init__.py/public exports, StateStore surface, pyproject/entry points,
installed-schema catalog/SQL 0001-0004, C1 kind inventory and current D1 wire
meaning protected. Identify an unavoidable conflict now; never evade exact guards
through filename tricks, imports through another module or runtime aliases.

Acceptance recommendations must prove the intended causal behavior, not a
handback label or constructed row alone. Include a SMALL finite set tied to:

- effect write and exact recovery -> relevant writer close -> each real child;
- incomplete/unresolved effects/admissions cause zero dependent child attempts;
- actual parent DB/state isolation at original launch inputs and child FD probe;
- genuine reconstruction/check/reviewer refusal versus zero exit or fake pass flag;
- distinct author/reviewer identity and exact capsule/evidence binding;
- model invocation and recommendation depend on real bound input, not caller mode;
- real C1 admission/readback, no fixture receipt or shadow row production;
- no post-execution Section 41 rows/receipt or rank-15 admission by this D2 endpoint;
- final semantic payload/ref/digest equality at the selected later-consumer cut;
- complete nested value validation, legitimate negative statuses, creator-PID
  custody and cleanup, including deliberately unreported children;
- D1 regression and all changed guard/status invariants remain intact.

The future writer must also have transaction/CAS/collision/replay/readback-only
recovery and no-duplicate tests, with exact positive and negative graph
specimens. No broad migration test program is needed when no migration changes.
Do not propose a full-suite run per mutant or an unbounded mutation taxonomy.

Give exact prospective focused test paths and command forms, and one complete
normal collection/execution after the final future source edit. These commands
are OUTPUT ONLY in this map:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-root> python3 -B -m pytest -q -p no:cacheprovider   --basetemp=<precreated-owned-path> [--collect-only] <exact-proposed-selectors>
```

Prior baseline: 9,005 tests / 124 modules with three known writer-session fork
warnings. Do not freeze a future D2 count to 9,005 or claim this static map ran it.

## 4. Inspect these owning surfaces, not a new architecture corpus

Use the previous map's actual references and read the specific connected owners
needed for the questions above. No need to reprint irrelevant machine ledgers.
Minimum grounding includes:

```text
.docs/rw0-d1-offline-process-and-capsule-spine.md
.docs/c2b-durable-development-state.md (Sections 11-13, bound-effect and Section 41 source/phase/transaction owners)
.docs/c2a-first-slice-semantic-protocol-contract.md (fence/current-effect/source matrices)
.docs/rw0-c1-durable-evidence.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/rw0-c2-durable-progression-decision-semantic-contract.md
.docs/rw0-c2-private-value-versioning.md
.docs/autonomous-software-development-operating-model.md
src/ge_nwp_coordinator/_rw0_d1_offline.py
src/ge_nwp_coordinator/_rw0_d1_handback.py
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py
src/ge_nwp_coordinator/_development_author_effect_establishment_contracts.py
src/ge_nwp_coordinator/_sqlite_development_author_effect_establishment.py
src/ge_nwp_coordinator/_development_effect_row_values.py
src/ge_nwp_coordinator/_development_decision_row_values.py
src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py
src/ge_nwp_coordinator/_sqlite_development_readers.py
src/ge_nwp_coordinator/sqlite_writer_session.py
src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py
src/ge_nwp_coordinator/_sqlite_rw0_c1.py
src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py
src/ge_nwp_coordinator/_post_execution_evidence_values.py
src/ge_nwp_coordinator/_post_execution_policy_values.py
src/ge_nwp_coordinator/_cognitive_proposal_semantic_values.py
src/ge_nwp_coordinator/_cognitive_proposal_row_values.py
src/ge_nwp_coordinator/_section41_post_execution_proposal_family_projection.py
src/ge_nwp_coordinator/_section41_post_execution_role_resolution.py
src/ge_nwp_coordinator/_rw0_c_decision_input_values.py
src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql
src/ge_nwp_coordinator/sqlite_migrations/0003_cognitive_proposal_and_selection_state.sql
src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql
```

Inspect the direct current tests, schemas/configs, fixtures and exact guards
coupled to those paths as inert data. Preserve the distinction between a pure
golden-value test and a supported producer/guarded writer. Follow a dependency
where it is genuinely implicated; state where inspection stops.

## 5. Return one completed implementation map, not another open-ended program

The requested output is an INLINE completion of the existing map:

1. Actual opening/closing provenance and inspected ranges; no execution claim.
2. Confirm the revised D2 result and exact exclusion of Section 41 recording,
   rank-15 admission, full C2 inputs and new migration.
3. One concrete private API/custody/call graph with the two productive bound
   effects, actual C1 evidence, three children and transient final proposal.
4. The bounded writer's native source placement, command/receipt/graph/CAS/replay/
   recovery specification and proof that existing physical representation fits.
5. Exact nine-role authorship/constructor/admission map and final semantic output
   table, with no-transformation mapping and later owner fields clearly absent.
6. Final prospective create/modify/protected path table, including all coupled
   status, pure-owner, consumer, and identity guards. Do not label TBD paths
   implementation-ready or ask the user to pick ordinary files/schema mechanics.
7. One source-bearing D2 implementation sequence with internal checkpoints,
   finite acceptance evidence, exact future validation selectors and audit order.
8. Source-backed residual contradictions and a bounded continuation capsule.

Recommend one integrated D2 tranche: bounded effect/admission foundation with
its owning docs/tests, process/evidence construction, fake model and transient
proposal, then integrated regression. Internal dependency steps are NOT new
D2a/D2b publication programs, a standalone contract freeze, or concurrent C2 work.
A pure declaration needed for an already-specified schema is implemented with
its runtime consumer and tests, not used to defer source work again.

If a necessary dependency remains unsatisfied by this cut, state the precise
owner, field/row/transaction predicate and minimal consequence. In particular,
stop rather than widening a migration, using a synthetic C1 membership, claiming
live fixture authority, or returning a generic packet while advertising canonical
C2 compatibility. This is a real source-backed contradiction, not ordinary module
decomposition. No mapper-issued implementation prompt or repository mutation.

Use one final token:

RW0_D2_IMPLEMENTATION_MAP_READY_FOR_REVIEW
  The exact revised cut has a complete concrete source/owner/dependency plan.
  This token authorizes no edits; cognitive-lead review precedes source work.

RW0_D2_IMPLEMENTATION_MAP_REPLAN_REQUIRED
  A specific necessary owner or semantic/physical predicate prevents the revised
  cut without an excluded effect. State that predicate and minimal disposition.

RW0_D2_IMPLEMENTATION_MAP_BLOCKED
  Opening/provenance/preservation/material-source access or incomplete inspection
  prevents the map. Do not silently restart or guess a missing result.

Before finishing use the SAME opening helper to verify the fixed HEAD/tree/ref
facts, clean index and all 263 payloads, index content/metadata and full cache
directory/member equality. Remove only this interval's external opening/scratch
files after final comparisons. No tests, code imports, SQLite, fake children,
clones, network, stage/commit/push, snapshot/export or source mutation occurred
unless truthfully reported as an out-of-scope deviation. End with one token.
