# RW0-D2 — Bounded Source-Entry Closure
# One D2 tranche with two internal dependency checkpoints; mapping only

## Decision, routing and first protected action

Resume the SAME mapping-only parent Codex conversation that produced the latest
D2A/D2B proposal. Do not use the implementation writer or a subagent. This is one
new READ-ONLY source-entry closure interval, not implementation permission, a
new architecture program, or a repeated broad reconnaissance pass.

First protected repository action: read live AGENTS.md as plain text from tool
workdir `/`:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

Read the complete guidance, using further file-only reads when truncated. Then
run the unchanged filesystem-only opener in section 1 BEFORE any Git command or
other repository inspection. Use its actual emitted helper for live Git reads.
Reading this supplied external instruction as plain data is allowed preparation;
prefer neutral cwd. It permits no repository import, Git/index operation, test,
script, product-state access, or repository mutation. Do not treat cwd alone as
proof of such an action; equally, a real pre-opening Git command remains a stop.
No reset, metadata restoration, replacement opening, or silent restart.

After a valid opening and exact subject authentication, complete the requested
closure without another user checkpoint. No tests or collection, repository
imports/value construction, SQLite opens, fake-child launches, clones, network,
provider/supplier work, installs, source/doc/test edits, stage/commit/ref/config
writes, or delivered report/package. Only the existing external opening helper
and bounded inert inspection scratch are permitted; remove owned scratch after
closing checks. Proposed source and test commands remain OUTPUT ONLY.

The latest report contains useful source findings. Retain them; do not restudy
unrelated historical ledgers. It does NOT yet provide a safe complete mutation
ceiling. This instruction closes specific gaps below before a source prompt.

## Operating-model disposition

The selected end result remains ONE private invocation:

D1 input and existing state owner -> guarded validation/review effects -> two
separate evidence children -> real required C1 admissions/readback -> nine-role
model input -> one separate fake review model -> typed transient preadmission
proposal/evidence handback. No routine user evidence transport.

The reported evidence/model split is useful as TWO INTERNAL SOURCE CHECKPOINTS:
A, evidence closure; B, cognitive-review handback. It is NOT permission for a new
D2A-only publication program, a separate serialized handoff through the user, or
an independent review approval required between the two portions of one running
D2 invocation. Keep one D2 implementation tranche, integrated final acceptance,
and publication only after that candidate is accepted. Focused tests and lead
inspection at development checkpoints do not introduce another runtime authority.
Do not stop the future source program at evidence-only delivery and label D2 done.

The report says "under the user's clarification" but that clarification was not
supplied with the report to the cognitive lead and is not in the issued completion
mandate. Treat the report's split as a recommendation, not evidence that a scope
change was already authorized. If the mapper actually has a materially conflicting
direct user instruction, identify its exact words and source in the returned
scope note rather than inventing it; do not silently assert or implement a new
approval sequence. This pass remains read-only in all cases.

Provisional _rw0_d2a/_rw0_d2b file names may be retained where useful as dependency
grouping; naming does not create two product programs. Do not spend this pass on
renaming for aesthetics. The lead has not selected extra services or workflows.

Retain the narrower endpoint and genuine prerequisites:

- Native bound-effect establishment/replay/recovery for ONE initial
  validate_candidate and ONE initial review_candidate, reusing D1's attempt,
  candidate, author command, post-bound author fence and current lineage.
- Actual C1 memberships and exact readback wherever the supplying post-execution
  values require them. Typed fake authority/readiness/policy sources stay visibly
  artificial. Admission verifies relations, not live source authenticity.
- Existing sole subprocess supervisor, two reconstructed checking workspaces,
  validator/reviewer evidence based on actual checks, and evidence-dependent fake
  model output. No writer/connection/lock/custody capability crosses to a child.
- Canonical TRANSIENT post-execution source/artifact/proposal/evidence data;
  no durable Section 41 post-execution recording, no rank-15 admission or admitted
  family projection, no complete C2 decision-time basis or authoritative branch.
- No migration 0005 or other migration, no modifications to SQL 0001-0004/catalog,
  no public API/CLI/service/StateStore widening, no repair/replan/retry execution,
  no new coding attempt, no cancellation-effect establishment, live credentials,
  provider/supplier, ES/Bridge, Git/publication or RW0-E effects.

A reserved schema/result class is supporting representation evidence, not proof
of a currently implemented writer. Source inspection is not runtime validation.

## 1. Exact merged baseline and preservation

Repository:
`/Users/ds/Repositories/Governed Execution Coordinator`

Required current local coordinates:

```text
branch: trunk_dev
HEAD: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
tree: cc3cc104300f553ada581cee24e80dab6dd885b1
sole parent: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
subject: feat: add RW0-D1 offline process and capsule spine
upstream: origin/trunk_dev
local tracking ref: same squash HEAD
local divergence: 0 ahead / 0 behind
worktrees: one
index/worktree: clean, all 263 tracked leaves equal HEAD
staged, unmerged and untracked paths: none
active Git operation/sequencer/unexpected lock: none
migration resources: exactly 0001–0004; no 0005
```

The supplied snapshot has 263 source leaves and reconstructs the same exact tree.
Its ZIP is named `Governed Execution Coordinator - Snapshot - 2026-10-16.zip`,
3,134,667 bytes, SHA-256
`06d981b6100fc1d6ad9792aff35800eb0772b8d35f708ed030177967ccb9c40e`.
The filename's date is not a claim that the source predates D1. Archive tree
identity is snapshot-backed; the squash/branch facts came from the merge report
and must be checked locally here. No archive attachment is needed by this mapper.

Do not fetch or contact GitHub. Local tracking equality is not fresh remote
truth. Do not demand the pre-squash source HEAD or recreate the 46-file candidate:
all 263 leaves are now tracked. PR #14's source commit remains historical
`f0e3169c55fad62d8d830d9fc799263d7c5332f1`; no manipulation of it is needed.

Preserve all actual OS modes, including the existing nonexecuting 0600
program-initialization test. The 37 live bytecode files are opaque preservation
material, not source or code to import. No ignored database, secret, credential,
TLS/Vault/OpenAI/Codex state, host configuration or sibling repository is in scope.

### Existing pre-Git mechanism

After the guidance read, run this data-only block from `/`. It reads no product
state, runs no Git and imports no repository module. Its only writes are under
its newly created external root. It preserves index/cache contents and metadata.
This is inspection instrumentation, not run truth, a product receipt or an OS
interlock against commands issued outside it.

```sh
python3 -I -B -S - <<'PY_OPEN'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env


import datetime
import shutil
import tempfile

guarded_environment()
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_not_exact_audited_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_unavailable')
gate_root = Path(tempfile.mkdtemp(prefix='rw0-d2-readonly-map-'))
os.chmod(gate_root, 0o700)
print('GATE_OWNED_ROOT=' + str(gate_root), flush=True)
record = {
    'schema': 'rw0-d2-readonly-map-opening-observation',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents, 'index_path': str(index),
    'index': index_before, 'cache': cache_before, 'git_executable': git,
    'git_environment': GUARDS,
    'limit': 'This mapping interval only. All repository bytes, refs, index and cache stay fixed. No repository or remote mutation is authorized.'
}
READ_HELPER = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\n\nimport subprocess\nimport sys\nopening = json.loads(Path(__file__).with_name('opening.json').read_text(encoding='utf-8'))\n\ndef immutable_checks():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('map_index_content_or_metadata_drift')\n    if regular_record(REPO / 'AGENTS.md')['sha256'] != AGENTS_SHA:\n        raise RuntimeError('candidate_guidance_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n\nimmutable_checks()\nindex_before_read = regular_record(index_path())\nargs = sys.argv[1:]\nif args == ['--check']:\n    print('READ_HELPER_IMMUTABLE_SURFACES_MATCH')\n    print('CURRENT_INDEX_SHA256=' + index_before_read['sha256'])\n    print('Index content and metadata equal this mapping opening; no stage or index write is permitted.')\n    raise SystemExit(0)\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree',\n           'check-attr', 'for-each-ref', 'reflog'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_read_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'], ['--quiet', 'HEAD']):\n    raise RuntimeError('readonly_head_query_only')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('readonly_worktree_list_only')\nif args[0] == 'reflog' and (len(args) < 2 or args[1] != 'show'):\n    raise RuntimeError('readonly_reflog_show_only')\nfor arg in args[1:]:\n    if arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec') or arg.startswith(('--output=', '--exec=')):\n        raise RuntimeError('unapproved_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager', '-c', 'core.fsmonitor=false',\n           '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=guarded_environment(), check=False)\nfinally:\n    immutable_checks()\n    if regular_record(index_path()) != index_before_read:\n        raise RuntimeError('index_changed_during_read_command')\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(payload)

try:
    write_private(gate_root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(gate_root / 'live_read.py', READ_HELPER.encode())
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_first_git')
    print('OPENING_RECORD=' + str(gate_root / 'opening.json'))
    print('LIVE_READ_HELPER=' + str(gate_root / 'live_read.py'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D2_MAP_PRE_GIT_OPENING_RECORDED')
except BaseException:
    for name in ('opening.json', 'live_read.py'):
        p = gate_root / name
        if p.exists():
            if not stat.S_ISREG(p.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            p.unlink()
    gate_root.rmdir()
    raise
PY_OPEN
```

Use the ACTUAL emitted helper and root paths; do not assume shell variables
persist or guess a temporary path. Every live Git inspection uses that helper:

```sh
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> rev-parse HEAD
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> status --short --untracked-files=all
```

The helper performs command-local optional-lock, lazy-fetch and prompt
suppression. No Git WRITE, including write-tree, is authorized. Verify tree and
index equality by reading stage-0 entries and blobs, not by refreshing the index.
Read every tracked payload against its HEAD blob and preserve opening/closing
index content AND metadata and cache directory/member metadata. Complete-tree
identity is sufficient for this map; do not create another candidate manifest.

Allowed analysis: text reads, read-only Git object/ref/status inventory, hashes,
and standard-library AST/JSON/TOML/SQL-text inspection as inert data. Do not import
modules, construct repository value objects, call a reducer, open SQLite, run
pytest (including collection), compile repository code, launch any child/fake,
clone/check out another tree, install a package, or run repository scripts.
A source-level prediction must not be reported as an executed result.

Give one concise opening acknowledgment, then proceed. A fixed-baseline mismatch
ends the map before recommending implementation against a different subject.

## 2. Retain the findings that are already grounded

The latest map says the following; verify only affected current relationships:

- Migration 0002 and existing effect/result grammar can represent the selected
  initial validation/review families without a new migration. The native target
  is in .docs/c2b-durable-development-state.md:389-451. The reserved projection is
  _development_decision_row_values.py:390-415. Author command uniqueness is
  specific to author_candidate; sharing its originating command does not make
  an author fence valid as the current validation/review fence.
- The reference owner remains the actual author-effect writer/controller,
  receipt-first replay, nominal read capability, exact family readback and
  readback-only three-way recovery. The new family has six immutable graph
  members plus its receipt; it creates no new program version, candidate,
  author command or source observation. Recheck the exact six-member binding
  against target and existing SQL rather than inferring it from this sentence.
- Required C1 ranks proposed are 1, 5, 6, 12, 13 and 14, with per-member
  dependencies derived from actual consumers; no ranks merely for completeness.
  Rank 15 is deliberately excluded. Reviewer separation consumes actual
  committed rank-12/13 membership and relation values.
- The nine-role support-value counts are reported as
  (0, 0, 6, 7, 4, 4, 0, 2, 5). Preserve their supplying owners; counts alone do
  not prove the exact types, binding or completeness of a proposed bundle.
- The common cognitive semantic validators currently reject post-execution in
  several paths while row-value grammar can represent it. The future pure branch
  must realize the existing post-execution grammar, not skip pre-phase validation
  or make row construction a persistence claim.

The useful mapped source grouping is retained as a starting point:

Native writer contracts/runtime:
  _development_bound_effect_establishment_contracts.py
  _sqlite_development_bound_effect_establishment.py
  sqlite_transition_transaction.py
  sqlite_writer_session.py

C1 exact guarded readback:
  _sqlite_rw0_c1.py and the actual supplying reader contracts/readers it uses

Evidence children/composition:
  _rw0_d2a_process_frames.py
  _rw0_d2a_fake_validator.py
  _rw0_d2a_fake_reviewer.py
  _rw0_d2a_workspace.py
  _rw0_d2a_evidence.py
  _rw0_d2a_handback.py
  _rw0_d2a_offline.py

Model/proposal/composition:
  _rw0_d2b_model_frames.py
  _rw0_d2b_fake_review_model.py
  _rw0_d2b_model_input.py
  _rw0_d2b_proposal.py
  _rw0_d2_handback.py
  _rw0_d2_offline.py
  _cognitive_proposal_semantic_values.py

All are under src/ge_nwp_coordinator/. They are proposed, not current newly
implemented files or authorized edits. Remove a redundant proposed owner if
existing ownership suffices, but explain the selected final placement once.

## 3. Concrete missing datum: D1 adapter process-exit evidence

Lead inspection of the exact snapshot found an evidence-supply omission not
accounted for in the latest prospective path table:

- _rw0_d1_offline.py:434-445 creates adapter_exit: WorkerObservationV1 in a LOCAL
  variable. It contains the parent-authored process_exited observation, delivery,
  command, fences and worker exit code.
- :446-453 passes exactly that observation to classify_wire_process_result and
  retains only the classification in facts.
- :503-506 returns RW0D1HandbackV1 and RW0D1OfflineRun with no adapter observation.
- _rw0_d1_handback.py:105-121 has sixteen fields, including worker_process,
  wire_result and wire_classification, but no adapter_exit/adapter observations.
  Its owner slots at :255 are state root, location, closed, creator PID and
  handback only; it is not an existing hidden evidence store.
- _rw0_d1_process_supervisor.py:35-47 has process facts and bytes, but no semantic
  observed_at field from which the omitted adapter observation can be recovered.
- _rw0_wire_protocol_values.py:560-576 carries only classification/reason in the
  classification value. It is not a transcript of the classifier's inputs.
- _rw0_c1_semantic_values.py:763-817 represents rank-14 adapter_observations by
  actual rank-12 locators; _rw0_c1_mutation_contracts.py:519-542 requires their
  exact prerequisite ordering. The proposed usable binding must be recomputed
  against the real admitted evidence, not against a remembered output label.

Resolve this exact boundary, not a new generic observation bus:

1. Reconfirm the actual loss from source/call sites. Identify whether any existing
   legitimate retained path contains the observation; never assume it does.
2. Select the smallest explicit TYPED retention change at the D1 producing
   boundary so D2 receives the same source record/ref/digest that the original
   classifier consumed. Preferred direction is a narrowly amended D1 handback
   evidence field or owned immutable companion, not callbacks, monkey-patching,
   globals, test interception, arbitrary metadata, or fabricated SQL rows.
3. Specify exact field/type/cardinality, producing assignment, all consuming
   validators and the private version/compatibility treatment. Do not silently
   change a frozen field inventory. Select the treatment rather than returning
   schema choices to the user. No public schema expansion or generic serializer.
4. Map status-dependent presence: not before a recorded exit exists; retain on
   later legitimate failures; never invent an observation for a failed start.
   Handle the actual D1 stage order and cleanup semantics without deleting facts
   to fit a matrix. Inspect whether the existing private version can be amended
   with all owning tests or needs a explicitly named private successor; explain.
5. The source record is authored once; normal D1 classification, C1 rank-12
   admission, rank-14 recomputation and final evidence must refer to that record.
   Existing classifier and observation relation semantics remain authoritative.
6. Name every affected D1 owner/test and fixed consumer/field/status projection.
   _rw0_d1_handback.py was missing from the proposed modify list: account for it
   or prove another complete explicit source-owned retention path. No import
   indirection to avoid its field/import guard.

Do NOT regenerate the missing old observation in D2 with a new timestamp and
call it the record used earlier by D1. Do not invent old bytes/ref/digest from
classification == usable, stdout, or a process exit scalar. A newly designed
adapter observation after handoff would be a different event requiring an
explicit different contract; it is not the selected default.

Return a short producer -> retained value -> C1 owner -> consumer table and the
precise future tests proving identity and missing/wrong/cross-run refusal. Tests
must observe actual production values, not reconstruct expected evidence in the
observer. Do not implement or run them during mapping.

## 4. Resolve observation chronology at the same retention boundary

The latest report correctly identifies these literal values in the snapshot:

- _rw0_d1_fake_worker.py:58-74 constructs all three observations after the file
  operation and supplies observed_at=2028-01-01T00:00:00Z at :68;
- _rw0_d1_offline.py:440 supplies adapter observed_at=2028-01-01T00:00:01Z.

They are artificial D1 inputs, not observed timestamps from a current D2 run.
Do not globally relabel the accepted D1 proof defective merely from its fixture
clock. Establish the actual consumer requirement that needs a change in the
D1+D2 composition and map that narrow implementation explicitly.

Changing those two literals to a call to a clock is NOT a complete chronology
plan. Address the actual events and authors:

- child worker-start, captured-candidate and completion facts, including whether
  their current late tuple construction needs distinct event-time sampling;
- parent observation of the completed/reaped worker result, its retained adapter
  record and exact classifier use;
- new effect writer transaction time, proof authority/readiness source times and
  expiry, host qualification semantic evaluation time, and their admission time;
- validator/reviewer actual source observations and disposition evaluation;
- fresh parent model-entry context/stop observation versus historical source
  evidence, model invocation start/completion and model proposal creation;
- artifact validation and evidence-binding times; genuinely later Section 41
  recording/receipt time remains absent.

For each time name exact field, author, sampling point, exact format, equality
or inequality required by the CURRENT owner, and the function that enforces it.
Use source references including _rw0_c1_semantic_values.py:1544-1569,
_rw0_phase_entry_semantic_values.py:1494-1498,2074-2094 as applicable, and the
actual post-execution result-set/model-input validators. Do not pretend those
few checks constrain every timestamp; follow the actual consuming relations.

Same-second events may have equal whole-second timestamps when the contract
allows it. Use the supervisor's monotonic clock only for timeout mechanics;
wall-clock values are source evidence, not a proof of causal order. No blanket
strict-increase requirement, sleep to fabricate chronology, timestamp clamping,
backdating, mutation of old signed/canonical evidence or advancing a controller
clock to 2028 to make assertions pass. A real clock reversal/expiry/conflict
must have the existing conservative failure treatment rather than forged times.

Clarify fixture determinism after real timestamps: semantic data/check behavior
can stay deterministic without byte-identical wall-clock observations. If a
synthetic time profile remains anywhere, label it and show it cannot masquerade
as current observation or postdate a consuming current-time requirement.

Map exact D1 tests, source/owner status and fixed inventories affected by this
retention/chronology amendment. Preserve all existing D1 process/capsule meanings
and real positive/negative controls; do not suppress old tests because time varies.
This is part of the later SOURCE tranche, not a preliminary chronology contract.

## 5. Close native writer/readback and exact value boundaries

This is completion of the previous map, not a request for speculative runtime
code. Use concise exact signatures, field/row assignments and dependency tables.

### A. Bound-effect command and recovery

Select exact private command, result and recovery-selector types/functions and
ordered fields for the two supported initial effect classes. Name existing
reused row factories/digest functions and the reserved result projection. Specify
which values are preassigned caller assertions versus Coordinator-derived from
verified owner rows. Map every inserted row, original owner/CAS preimage and
unchanged head. A list of six output categories alone is not that mapping.

Use the original development selection decision already bound to the attempt
where its owning contract requires it; do not confuse it with the distinct
Section 41 pre-execution proposal-selection result. Account for both genuine
predecessors where needed.

Pin receipt-first replay after fencing, exact collision/readback behavior, the
single controller-owned timestamp/commit attempt, and readback-only recovery on
a fresh fenced writer. Name the result of committed_exact,
definitely_not_committed and unresolved for dependent launch; no automatic
reissue or new command identity to evade uncertainty. Preserve no new program
version, attempt, author command, source observation or authority grant.

Show the existing migration-0002 constraints admit each selected row and how
D1's aggregate max_deliveries=3 and current effect ceilings are checked without
becoming live permission or a new counter. Existing schema capacity does not
relax a semantic precondition. No SQL/schema/catalog change is selected.

### B. Exact guarded C1 family readback

The current _readback_rw0_c1_evidence_admission at _sqlite_rw0_c1.py:4602-4648
verifies a write plan and returns RW0C1AdmitEvidenceResultV1. That is not itself
the already-exposed caller API for returning the membership/relation rows used
by reviewer separation.

Name the proposed minimal readback selector, return type, writer-session and
controller delegation, transaction/capability lifetime and actual existing
family readers/verifier. It must return immutable checked row/evidence values,
not a connection, raw SELECT function, read capability, unvalidated row mapping,
or test helper. No public API and no expansion of the unrelated 24-query reader
inventory merely for convenience. No writes performed by the readback itself.
Read-only recovery and family readback are distinct call purposes.

Give the ordered positive admission set with each actual source/owner operand,
prerequisite membership and consumer. Identify when rank-1/5/6 evidence is
observed/qualified/admitted relative to each child, so the overview does not
hide a qualification invented after the event it purports to qualify.
Admit only the needed dependency-closed set; rank 15 stays absent. Preserve
immutable C1 phase preimages despite the new bound-effect head insertions.

### C. Evidence checkpoint and final preadmission output

Return ordered field/type/cardinality tables for the evidence checkpoint and
final private handback. Use exact Python class and schema/domain names, not just
V-number aliases or phrases such as 'closed common schema'. Proposed types are
explicitly proposed. Fields must be closed and nested values type-safe.

Separate at least these categories:

- actual committed C1 membership/relation/receipt data;
- source evidence supplied to those admissions;
- transient derived dispositions/separation/support sets;
- explicitly artificial policy/readiness/currentness sources and their bindings;
- actual process/control/cleanup observations;
- immutable base/capture/manifest and original source inputs required later;
- transient source invocation, private artifact, proposal and nine bindings;
- facts intentionally absent until later recording/currentness/C2 work.

Do not name the aggregate as though every member is admitted. The proposed
RW0D2AAdmittedEvidenceBundleV1 also contains transient policy/risk/stop/ceiling
values. Choose an accurate private name or explicit per-member support posture;
actual C1 admission must not be inferred from the container's name.

The checkpoint is not a durable resume capsule and does not promise indefinite
currentness. It is consumed in the same parent invocation with the same D1 run
owner. Model-entry currentness/global-stop checks belong where current owners
require them; record unchanged historical source facts separately. No user
transport or serializing the live run between A and B. A copied evidence bundle
cannot reopen a closed run, acquire authority or launch a child in another PID.

For the model output, list the exact common source/artifact/proposal/binding
classes extended for the post-execution phase, existing field order and digest
functions, and new phase-specific private normalizer placement. Relevant existing
field inventories begin in _cognitive_proposal_semantic_values.py:355-386 and
its proposal/evidence-set sections. Show each returned field's future destination
and distinguish present source/normalization times from absent future recording,
receipt/graph/membership and decision-time values. No future writer's timestamp
or fabricated rank-15 row in a transient value. Preserve the five recommendation
literals; no model-selected authoritative C2 branch.

A finite fake-model branch fixture may select input content, not supply its own
expected outcome as evidence. State the actual evidence-dependent derivation and
the exact validator/checking function for that output.

## 6. Final prospective path closure, not another broad survey

Complete only the dependencies introduced or exposed above and produce ONE exact
create/modify/protected table for the single D2 tranche. Each row must name its
internal checkpoint, responsibility, actual imported classes/functions, owning
contract, and directly coupled tests/independent guards. No 'if imports change',
'new tests TBD', wildcard-only future filenames or unnamed reader/source module.
Select ordinary mechanics; do not send file or schema choices to the user.

In addition to the previous table, account explicitly for:

- D1 adapter observation retention and exact handback field/status/version tests;
- D1 fake-worker/parent timing changes and any observation-shape/import guards;
- nominal writer/controller/capability and existing C1 readback scope;
- native bound-effect command/graph/result/recovery tests;
- complete evidence-checkpoint and final proposal field/serializer restrictions;
- post-execution six-module purity/allocation/DAG and the owning machine record;
- B1/Wire actual imports, fixed consumer forms and both B1 projections when used;
- sole subprocess owner and exact executable-module inventories;
- truthful per-checkpoint/final status in D1/D2 and governing docs;
- fixed AGENTS/README identities, all five Capability status projections, and
  BOTH the Capability and bootstrap protected-content checkers when status edits
  require them. Do not omit the latter from the table as conditional prose;
- scoped C2 absence guards, preserving rank-15/persistence/terminal/0005 absence;
- any exact source or reader inventory coupled to the native bound-effect owner.

Do not change the six pure owners' I/O posture or generalize the supervisor.
No public/package exports, StateStore, pyproject, migrations/catalog, repository
schema, deployment, ES/Bridge or provider changes. Any necessary exception to
that boundary must be a precise unresolved finding, never silently admitted.

No need to reread unrelated megabyte ledgers or reauthenticate old D1 mutants.
Read the affected actual source/contracts/tests as text and state inspection
ranges. Source-tree integrity is rechecked once at opening and closing. Do not
run tests to find dependencies in a read-only map.

## 7. Later acceptance recommendations; OUTPUT ONLY

Retain the existing small causal plan; add only implications of the newly found
retention/clock seam, not another open-ended mutation taxonomy:

1. Actual adapter observation retained from original classifier to C1/role supply;
   lost/substituted/cross-run datum cannot become a fabricated usable binding.
2. Actual source timestamp sites and explicit legitimate inequalities; no future
   evidence or backdated qualification introduced to make admission pass.
3. Bound-effect/C1 write and exact recovery -> relevant writer close -> every real
   child; unresolved outcome creates zero dependent process attempts.
4. Genuine independent reconstruction/validation/review and exact source/effect/
   capsule identity; no author observation relabeled as independent review.
5. Actual child channels/FDs exclude parent state; same sole supervisor accounts
   for every attempted/ignored child and cleanup.
6. Model input uses exact supported nine-role values; proposal follows actual
   model observation and retains five recommendation meanings with no C2 decision.
7. Closed nested checkpoint/handback, failed and cleanup-unresolved paths, creator-
   PID lifetime, no rank-15 or post-execution owner-row persistence effects.

Select exact new test filenames and fixed later selectors in the prospective
table. Include bound-effect persistence, exact replay/three-way recovery, C1
family readback, D1 retention/timing regressions, evidence children, model/pure
normalization, and integrated no-user-relay path. Give the finite mutation-to-
permanent-test mapping and distinguish fixtures, observed effects and derived
values. No full-suite run per mutant. Neither returned status nor a constructed
row substitutes for the real guarded operation.

One source-bearing D2 implementation may use internal development checkpoints:
A first demonstrates the native writers, two children and typed evidence;
B adds model/proposal closure. A is not an independent completion/publication
barrier and must not leave the user as their runtime message bus. Run focused
validation after affected source steps; independent acceptance concerns the
complete exact D2 candidate. One final full collection/execution follows the
last edit, then independent review and separately authorized publication.

Later command form, not executable in this map:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-root> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<precreated-owned-path> [--collect-only] <exact-selected-paths>
```

No freeze of future D2 counts to the prior 9,005 baseline; preserve legitimate
existing test cases and structured warnings. Actual runtime validation remains
for source work. A real excluded authority/schema conflict is a review stop;
an already-mapped status/import inventory update is not an architectural replan.

## 8. Deliverable, preservation and disposition

Return one focused INLINE source-entry closure, with no downloadable map package
or repo mutation. Avoid repeating the entire prior prose. Include:

1. Actual opening/closing baseline and inspection ranges; static/no-execution
   limits, plus the operational-checkpoint interpretation and any precisely
   sourced direct user instruction conflict.
2. The original adapter observation's complete future retention/admission path,
   exact private field/version choice, and amended source/test dependencies.
3. Compact timestamp author/sampling/consumer table and exact D1 change needed,
   separating actual observations, fixture clocks and currentness predicates.
4. Exact native bound-effect command/result/recovery and guarded C1 readback
   signatures/field/row mapping, required admission order and no-migration basis.
5. Closed evidence checkpoint and preadmission proposal tables, five outcomes,
   same-parent custody and exact later destination/absent-fact mapping.
6. One complete prospective source/doc/test/guard path table (no TBD or conditional
   scope), the integrated source sequence and finite acceptance selectors.
7. Any remaining precise owning contradiction, confidence and <=600-word
   continuation capsule. Do not issue an implementation prompt yourself.

If the four required missing shapes already have an exact supported source path,
show it with the relevant fields and callers; do not add abstractions just to
satisfy this request. Conversely, do not mark this map ready while the adapter
record disappears, the return shapes are only names, or the edit list leaves
coupled guards unspecified.

Use the same opening helper to verify clean HEAD/tree/ref/index, all 263 tracked
payloads and actual modes, complete index metadata/content and cache DIRECTORY
plus all 37 members. Remove only this interval's owned external helper/record/
scratch after final checks. No metadata normalization or historical restoration.

Supported final tokens:

RW0_D2_IMPLEMENTATION_MAP_READY_FOR_REVIEW
  The selected single D2 tranche has a complete precise source/owner/evidence/
  typed-output and coupled edit plan. This authorizes NO mutation.

RW0_D2_IMPLEMENTATION_MAP_REPLAN_REQUIRED
  A specific necessary semantic/physical/authority predicate would require an
  excluded effect. Identify that predicate and minimal owning consequence.
  Ordinary internal A/B decomposition alone is not this outcome.

RW0_D2_IMPLEMENTATION_MAP_BLOCKED
  Baseline/opening/preservation/material-source availability or uncompleted
  required inspection prevents the supported map. Preserve work and state the
  actual limitation. Do not silently create another interval.

No broad reconnaissance reset, docs-only contract tranche, new standing authority,
public service, D2A-only user handoff, physical C2, migration, or live execution
is authorized. End with one supported token.
