## Disposition

**Accept the map’s finding that the fully admitted endpoint exceeds the present D2 boundary. Do not adopt both missing writers as inseparable D2 prerequisites.**

I am selecting a narrower endpoint: **D2 should produce genuinely supported validation/review evidence and a canonical, transient model proposal; it should not yet persist and admit that new proposal family.**

The next step is a **targeted completion of the existing implementation map**, not a source mutation, another broad reconnaissance pass, or a standalone contract tranche. D1 remains unchanged.

This is a substantive engineering finding, unlike the preceding opening failures. Codex authenticated the merged baseline and identified missing owners from source and physical constraints. Its map is useful even though it is not yet implementation-ready. Pasted text

## The two missing writers serve different points in the sequence

### Bound validation/review effects are needed before the evidence can support the model

The map is right about this dependency. The current semantics require a `validate_candidate` effect for `validation_completed` and a `review_candidate` effect for `independent_review_completed`. The author’s effect cannot simply be reused under a different observation label. C1 also requires actual owner operands for the corresponding delivery and fence. Pasted text

The snapshot corroborates the distinction:

```text
.docs/c2a-first-slice-semantic-protocol-contract.md:967–987
src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py:583–589
```

Moreover, the existing reviewer-separation evaluator consumes actual C1 membership and relation values. A distinct reviewer PID alone does not satisfy that boundary:

```text
src/ge_nwp_coordinator/_post_execution_evidence_values.py:5479–5586
```

**Selected treatment:** include a narrowly supported bound-effect establishment path in the eventual source-bearing D2 tranche, together with its replay, recovery, and tests. Use it for one initial validation effect and one initial review effect on the existing D1 candidate.

That is an implementation of a native target owner—not permission for D2 orchestration to manufacture committed effect values.

The owner contract already specifies that these operations reuse the existing attempt, candidate, originating command, and author fence. They create the new current effect/fence, authority evaluation, initial delivery, heads, and receipt; they do **not** create another semantic attempt, author command, or program version. Migration 0002 already reserves the bound-effect receipt family. The completion map must prove that the existing representation and constraints suffice for the selected subset. Pasted text

Relevant snapshot boundaries are:

```text
.docs/c2b-durable-development-state.md:389–451
src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql:537–566
```

Cancellation-effect establishment, redelivery, retry policy, and new coding attempts remain outside D2. D2 cancellation continues to mean bounded process control and truthful evidence—not implementation of the larger cancellation decision protocol.

### Proposal-family persistence is needed after model output, before later admission

The map is also right that the current cognitive receipt cannot record a post-execution family. Its mutation family, result class, and foreign keys are pre-execution-specific. C1 rank 15 reads an **already existing** Section 41 family; it is not that family’s producer. Pasted text

That rules out reusing the existing receipt dishonestly, inserting rows from the offline harness, or making C1 own Section 41 production.

**It does not establish that D2 must perform that persistence before returning the model’s proposal.**

The original mapping mandate expressly asked for the narrowest truthful handback cut and distinguished a typed preadmission proposal from an admitted projection and complete decision-time input. The mapper’s recommended expansion joins those cuts; we do not need to select that expansion. Coordinator_RW0_D2_Offline_Evid…

## Selected D2 capability

The revised end-to-end path is:

```text
D1 capsule, committed lineage, and parent-owned disposable state
→ guarded validation effect and closed writer
→ separate validator
→ guarded review effect and closed writer
→ separate independent reviewer
→ required genuine C1 evidence admissions and readback
→ exact nine-role model input
→ separate deterministic fake review model
→ canonical transient source/artifact/proposal values
→ typed preadmission handback
```

**This is not a wholesale retreat to synthetic evidence.** The evidence that must already be admitted for the model input remains admitted through C1.

The current nine-role contract explicitly gives `worker_result` and `authority_currentness_attestation` a `c1_admitted_exact_value` posture, at ranks 14 and 1 respectively. Reviewer separation also depends on C1-backed evidence. Those facts cannot become golden fixture memberships merely because the final proposal is transient. See:

```text
src/ge_nwp_coordinator/_post_execution_evidence_values.py:91–136
src/ge_nwp_coordinator/_post_execution_evidence_values.py:5479–5586
```

The postponed work is specifically:

```text
durable Section 41 post-execution source/artifact/proposal/evidence recording
→ its legitimate receipt, replay, and recovery
→ C1 rank-15 admission
→ admitted proposal-family projection
→ complete decision-time C2 input and physical C2 decision
```

That later persistence work must preserve the Section 41/C1 ownership split. Deferring it does not make C1 its eventual writer or imply that the missing receipt problem has been solved.

### Why this is the shortest defensible path

A process-only demonstration that bypasses the existing evidence prerequisites would weaken the requested semantic result. Conversely, implementing the full post-execution persistence family now would pull a receipt/schema decision—and potentially a new migration—into D2 despite the selected exclusion.

The chosen cut retains the meaningful part of the capability: **the parent conducts validation, independent review, and model review without your relaying messages, and produces precisely bound proposal material.** It defers recording that newly produced proposal, rather than deferring the cognitive loop itself.

It also preserves the original sequence:

```text
D1 → D2 → later persistence/physical C2 work
```

There is still one D2 implementation program, not concurrent D2 and C2 programs.

## “C2-compatible” needs an exact, narrower claim

The successful D2 result must be described as **preadmission proposal and evidence material**, not:

- an admitted `Section41PostExecutionProposalFamilyProjectionV2`;
- a complete C2 currentness or decision-input basis;
- a Coordinator-derived authoritative branch;
- acceptance, terminality, or permission.

The five model recommendations retain their existing meanings. A later owner may reject the evidence as stale or conflicting without rewriting its historical recommendation. Cancellation or a missing model result must not be turned into a sixth recommendation. Pasted text Pasted text

**“Preadmission” cannot be a label hiding an incomplete type mapping.** The completion must identify every returned class, schema, reference, digest, timestamp, and later destination. It must distinguish immutable source/semantic content from later recording, receipt, graph, and membership identities.

There is a concrete constructor gap to resolve. The current common cognitive semantic constructors reject post-execution phases, while the row-value grammar can represent post-execution variants:

```text
_cognitive_proposal_semantic_values.py:1638–1653,1765–1785
_cognitive_proposal_row_values.py:807–832,864–928
```

That warrants mapping the minimum pure constructor/normalizer coverage for the **already specified** post-execution grammar. It does not justify bypassing the pre-execution validator or pretending that a constructed row has been persisted.

The exact source placement and timestamp/digest relationships remain to be established. I am selecting the operating boundary, **not claiming that this remaining constructor path is already implemented or fully proved feasible**.

## What the completion map must settle

The completed map should resolve four connected matters:

**The bounded writer.** Name its exact private modules, commands, existing receipt/result representation, current-state checks, collision handling, transaction ownership, replay, and readback-only recovery. Demonstrate that no new migration or change to migrations 0001–0004 is required. The existing schema’s capacity is evidence to inspect, not proof of a safe writer.

**The evidence dependency closure.** Trace the real validator/reviewer observations and required C1 members into the nine-role input. No fabricated memberships, copied test rows, author-fence substitution, or harness-selected authoritative branch.

**The transient output boundary.** Give the exact canonical proposal/artifact/source values and their later Section 41/C2 destinations, with genuinely later recording and admission facts explicitly absent. Do not invent a generic metadata packet and call it compatible.

**The complete prospective edit ceiling.** Replace “new owner modules—unresolved” with one recommended path list and its coupled owner/test/status changes. The existing process, reconstruction, and guard work should be reused, not remapped from scratch. The current report itself acknowledges that its unresolved owner representation prevents treating that list as ready. Pasted text

Those are prerequisites to issuing a reliable source prompt. They are not another docs-only tranche. Necessary owner clarifications and assurance-test changes belong with the eventual implementation.

## Complete mapping-completion handoff

Resume the **same mapping-only Codex conversation that produced this substantive map**.

:chatgpt-content-reference{index="8"}[Download the complete D2 bound-effects and preadmission-proposal mapping prompt](sandbox:/mnt/data/Coordinator_RW0_D2_Bound_Effects_and_Preadmission_Proposal_Map_Completion_Prompt.txt)

```text
Filename:
Coordinator_RW0_D2_Bound_Effects_and_Preadmission_Proposal_Map_Completion_Prompt.txt

Bytes:
43,652

SHA-256:
37fd3d44dcb1e152f91933ff9e6e7e6a56331fab11d78e490b9bd3ff252ba1e6

Lines:
693

Final newline:
present
```

The prompt makes the revised endpoint explicit, retains the existing opening mechanism, and authorizes **read-only mapping only**. It requires no tests, collection, SQLite operations, children, network, source edits, or new architecture package.

The fixed baseline remains:

```text
HEAD:
43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18

Tree:
cc3cc104300f553ada581cee24e80dab6dd885b1

Sole parent:
0d0926e3a483a3ab1a4fd597ac0495927352bf35
```

The desired outcome remains:

```text
RW0_D2_IMPLEMENTATION_MAP_READY_FOR_REVIEW
```

That authorizes no mutation. If this narrower cut still requires an excluded owner or physical change, Codex must identify the exact remaining predicate—not silently widen the scope or return placeholder evidence.

## Evidence boundary

I read the latest map in full and inspected the mounted snapshot’s relevant D1, C2A, bound-effect, C1, post-execution-value, cognitive-row, receipt, and consumer-boundary source as inert data. The archive’s 263 source leaves reconstruct the expected tree, and its CRC check passed. I also reopened the generated prompt and syntax-checked its included opening/helper code without executing it.

I did **not** inspect the live repository, run tests, construct repository values, or open SQLite. The map’s local preservation claims remain Codex-reported; the proposed D2 implementation remains unimplemented.

Some older uploads have expired. Re-upload a specific historical original when its bytes are needed; the current map, mandate, and snapshot were available.

**Sources:** Codex’s D2 map and the issued mapping mandate, cited above; the refreshed Coordinator snapshot, particularly the repository paths and line ranges identified here.

**Confidence:** High on the distinction between pre-model evidence prerequisites and post-model proposal persistence. Medium-high on this narrower D2 path; the exact bound-effect writer and canonical transient-output mapping still require the targeted completion before source authorization.
