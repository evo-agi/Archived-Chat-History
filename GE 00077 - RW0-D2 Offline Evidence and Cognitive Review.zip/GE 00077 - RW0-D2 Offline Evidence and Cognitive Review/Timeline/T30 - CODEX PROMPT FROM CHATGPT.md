# RW0-D2 Stop-Reason Repair V2 — Dispatch Correction 01
# Select the already-issued V2 task; preserve the repaired-V1 candidate

## Operative task: STOP-REASON REPAIR V2, NOT Continuation 04

Send this ONCE to the original implementation/repair conversation identified as
"00077 54". Leave the independent auditor and duplicate repository conversations
idle. This is a newly authorized execution interval for the SAME issued V2 repair,
not Repair V3, another vector repair, a new source baseline, or an audit.

The latest response applied Continuation 04's obsolete opening and stopped without
edits or tests. It required 46 modified + 23 created files and the pre-vector,
pre-authority-repair payloads. That is NOT the operative task in this message.
The report does not establish whether an older attachment was sent, selected, or
reused from history. Do not investigate attachment routing or ask another model to
resolve it. Select the complete V2 mandate included below and execute that task.

This dispatch correction explicitly supersedes Continuation 04 and other earlier
repair/audit task instructions AS EXECUTION AUTHORITY FOR THIS ENGAGEMENT. Their
results remain historical evidence. The included V2 body is the sole operative
repair mandate, including its exact opening, two-file ceiling, qualified ref
procedure, validation, and stop conditions. Its body is reproduced byte-for-byte:

Original filename:
Coordinator_RW0_D2_Stop_Reason_Reached_Facts_Audit_Repair_V2_Prompt.txt
Original body length: 68,044 bytes
Original body SHA-256:
637414e45f940d74d7bd8e0872a41580a5c125c3766499aa2b47546820e04aa4

These identify only the retained original body after the delimiter below, NOT the
whole dispatch-corrected file. Read the complete body as external instruction data
before protected repository operations. Do not select an older similarly named
attachment or treat conversational recollection as a replacement for this body.
In the normal opening progress message identify this as STOP-REASON REPAIR V2;
that announcement is not a separate confirmation gate or an opening-only task.

## Required candidate already matches the reported generation

V2's fixed expected opening is:
- HEAD 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18;
- tree cc3cc104300f553ada581cee24e80dab6dd885b1;
- 47 modified tracked + 23 working creations = 70 changed paths;
- all 263 index entries equal HEAD; 216 noncandidate tracked files HEAD-exact;
- 286 current source endpoints;
- replacement length 5,799,621 bytes;
- replacement SHA-256
  f7b8580df9a59f1270858ddf316f5bab2fafec5079a77c4e41d7bda6a4abc05e.

The reported current sizes of 103,682 bytes for the vector, 20,455 for the
checkpoint, and 19,540 for the D2 integration test are exactly the V2 EXPECTATIONS.
The complete hashes are in V2's 70-row table. These size matches and the latest
status count are NOT full candidate authentication. Independently reproduce all
fixed receipts and the raw replacement before editing; never replace a supplied
expectation with the current observation merely to pass.

Do not restore the vector to 97,266 bytes, the checkpoint to 11,551, or the
integration test to 7,008. Do not restart or repeat V3G039, discard the authority
repair, reset the index, repair timestamps, or obtain another snapshot merely to
satisfy obsolete opening requirements.

Only the two V2 paths may change:
  src/ge_nwp_coordinator/_rw0_d2_handback.py
  tests/test_rw0_d2_offline_integration.py
The vector and the repaired checkpoint are protected. The task is to bind the
final status/reason to its permitted reached facts, including rejection of the
false d1_stopped explanation after actual A/B execution while preserving genuine
late failures. It is NOT to implement or redo authority-role binding.

## New interval, unchanged safe opening and full execution

Start a NEW opening after receiving this instruction. The previous task's deleted
external helper/record cannot be reused. Follow V2's first protected action exactly:
plain live AGENTS.md read from tool workdir '/', complete guidance read, then its
filesystem-only opener BEFORE Git, repository listing, source inspection, imports,
tests, or edits. Reading this external instruction as data is permitted preparation.
No initial status or branch lookup. Use the emitted helper for subsequent live Git.

Once the exact current candidate authenticates, continue through V2's reproduction,
two-file repair, R01 and retained J01/J02 controls, six focused groups and full
validation WITHOUT another user approval or a task-selection-only return.
If the actual subject differs from V2's fixed receipts, stop and report that V2
expected/actual discrepancy. Do not return to Continuation 04's expectations or
silently adopt another candidate. Preserve qualified diagnostic-ref treatment;
no live ref/index/config writes, publication, other repository job, or scope
expansion is authorized.

The desired result remains:
RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_REPAIRED_V2_VALIDATED_READY_FOR_REAUDIT
It is not independent acceptance or permission to stage, commit, or publish.
All original V2 nonclaims, exclusions, and blocked dispositions remain intact.

The complete unchanged V2 mandate begins immediately after the next delimiter.

--- BEGIN UNCHANGED V2 MANDATE ---

# Governed Execution Coordinator — RW0-D2 Stop-Reason Audit Repair V2
# Bind final status/reason to permitted reached facts; preserve authority-role V1
# One implementation writer; two-file ceiling; no publication or new runtime owner

## 0. Authority, routing, first action and execution boundary

Send this ONCE to the original Coordinator IMPLEMENTATION/repair conversation
identified previously as "00077 54", not the independent auditor that found the
stop-reason defect. The auditor and duplicate summary conversation remain idle.
This separately authorizes one bounded SOURCE/TEST repair interval. It is not an
independent audit, another mapping pass, architecture reset, or new D2 tranche.
No other conversation is asked to modify, validate, or transport this candidate
in parallel. Do not claim that dispatch discipline establishes OS-level exclusion.
Observed competing source/index writes are a stop, not permission to race them.

FIRST protected repository action: read the live guidance as text with tool
working directory `/`:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

Read the COMPLETE output, using further plain-file reads for truncation. Then run
section 2's filesystem-only opener before Git, repository listing, source inspection,
imports, tests or writes. External instructions may be read as plain data before
that, preferably using an absolute external path and neutral cwd. A cwd alone is
not a Git action. A real protected pre-opening action requires an immediate stop;
do not reconstruct its metadata, reset the index, or silently replace an opening.
The helper protects commands routed through it; it is not an OS interlock.

After the opening, authenticate the fixed baseline, all 70 opening payloads and
section 3's current ref treatment. Then reproduce the finding, implement the
selected fix and complete all required validation in this engagement without a
new user approval, intermediate evidence handoff, or separate reason-contract pass.
This prompt is complete; no lost mutant package or refreshed snapshot is required.

ONLY section 1's two existing working files may be edited. All repository code,
imports, tests, controlled defect copies, fake children and disposable SQLite
fixtures execute ONLY in positively owned, remote-free external copies. Installed
tools only; no network, provider/supplier calls, dependency install or subagent.
Report model, reasoning and permissions actually visible, or `not visible`.

No live-checkout execution, product/operator database, secret read, source/guidance
change outside the two-file ceiling, staging, add -N, write-tree, commit, fetch,
ref/index/config/worktree write, push, PR, merge, service or deployment. No sibling
repo, ES/Bridge/CP/IM/MA operation, public API, schema/field-order change, migration,
Section 41 post-execution writer, rank-15 admission, complete C2 decision input,
physical C2 decision/acceptance/terminal writer, new attempt or retry/repair loop.
Every live ref write is prohibited, including restoring diagnostic refs. Section 3
classifies observed ref changes; it does not authorize producing them.

## 1. Finding, selected repair and exact edit ceiling

The latest independent read-only audit authenticated the repaired-V1 candidate
and completed its 19-node integration module and role-join omission controls.
It found a DIFFERENT material offline evidence-integrity defect:

- A genuine final handback was `stopped / model_input_or_normalization_failed`
  AFTER an actual review-model response was decoded.
- Its D1 handback was `capsule_ready`; it retained two committed bound effects,
  14 checked admissions, an A checkpoint, and three D2 child outcomes.
- Changing ONLY `reason` to `d1_stopped` using dataclasses.replace was accepted;
  an explicit validate() also accepted the resulting impossible explanation.
- The external fixture database hash did not change during the substitution.

Reported locations: `_rw0_d2_handback.py:70,169`. These are current inspection
pointers, not guarantees about method names or offsets after repair. The probe
shows a validator can accept a false stage explanation. It does NOT show that
the ordinary runner naturally emitted the wrong reason, acquired executable
permission, made a C2 decision, or performed an extra durable write.

SELECTED REPAIR: enforce the existing final handback's status/reason-to-reached-
facts relation, starting with d1_stopped and covering the existing closed reason
families that the current owning producers actually support. Keep the genuine
late model-input/normalization failure valid. Preserve all reached evidence and
negative process facts. Do not merely blacklist d1_stopped, require every stopped
result to be empty, or add an exception for the exact reported tuple.

Only these two paths may change:

| Path | Role | Opening bytes | Opening SHA-256 |
|---|---|---:|---|
| `src/ge_nwp_coordinator/_rw0_d2_handback.py` | Own and consume the pure final status/reason/evidence relation | 13,339 | `1e4fddda53315d7a14d042780730e0cce07b9a5c67d41233ddff550a430ac24f` |
| `tests/test_rw0_d2_offline_integration.py` | Real producer positives, reason substitutions, independent consumption and bounded causal controls | 19,540 | `b6f9f0d7906b22e116d25e09dd4ed42eb48c33af9dd6aeeba7c56406b2b1808a` |

Both paths are existing C-status working files, absent from baseline HEAD and
index. They remain C. No new file, rename, deletion or mode change is authorized.
All other 68 candidate payloads and 216 noncandidate tracked payloads stay exact.
The earlier three-file repair ceiling and 80-path implementation ceiling DO NOT
supply additional edit rights here.

In particular PRESERVE this checkpoint endpoint exactly:
`src/ge_nwp_coordinator/_rw0_d2a_handback.py`, 20,455 bytes,
SHA-256 `7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f`.
Its V1 source/family/role join remains the one checkpoint invariant. Preserve the
existing final call that revalidates the PRESENT nested checkpoint and its joins
to the final checked admissions. Do not repair stop reasons by weakening that call.

No new status/reason schema, version, stage field, event ledger, validation cache,
permission token, source registry, import permission, fresh clock query, DB read,
or model-input/producer behavior is selected. Use the existing error vocabulary
and content-free failures. An internal pure helper in the final handback module
is permitted. Reuse its authorized direct import surface; no type-name tests,
dynamic imports or re-exports to evade fixed consumer guards.

Read BOTH repair files completely before editing. Follow their actual callers
and return/exception paths in `_rw0_d2_offline.py`, `_rw0_d2a_offline.py`, and the
model-input/frame/proposal owners, the current D2 detailed owner document, and
relevant D1 status/cleanup and A handback validators. Read the repaired checkpoint
and direct consumer/guard dependencies as inert source. The purpose is to derive
the concrete existing final-result matrix, not to remap or reimplement D2.

The current D2 payloads are not in the merged baseline snapshot. Use the actual
authenticated working candidate for exact reason strings, fields, return sites
and tests. The report establishes the two named reasons above; do not invent
further literals from the categories used later in this prompt.

## 2. Fixed baseline, preserved opening and all 70 subject receipts

Repository: `/Users/ds/Repositories/Governed Execution Coordinator`

```text
branch: trunk_dev
HEAD: 43ae26b9bccf9ad6ce61ec4722e14ac7b460ab18
tree: cc3cc104300f553ada581cee24e80dab6dd885b1
sole parent: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
subject: feat: add RW0-D1 offline process and capsule spine
upstream: origin/trunk_dev at the same locally observed commit; divergence 0/0
one worktree; no active operation or unexplained lock
index: exactly 263 stage-zero HEAD entries; no staged/unmerged change
working candidate: 47 M + 23 C = 70 changed paths
other tracked working files: 216 HEAD-exact
current source endpoints: 286 = 263 baseline + 23 additions
current AGENTS SHA-256: ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166
reported unchanged index SHA-256: 7af425d5a47b91b0a14294660f5d449f5ba6308dc8846a8b13aca371c191a587
known cache: src/ge_nwp_coordinator/__pycache__, directory plus 37 regular members
migrations and catalog: unchanged existing 0001-0004; no 0005
```

Authenticate actual bytes rather than trusting a status count. Do not demand a
clean worktree, earlier 69-path overlay, or the pre-V1 checkpoint bytes. The index
is the baseline tree, not this candidate. All 23 C files are present as working
files and absent from HEAD/index. All 70 changed files are regular nonsymlink OS
0644/Git 100644. Preserve actual modes of the other files, including the unrelated
`tests/test_c2b3_private_atomic_program_initialization.py` at OS 0600/Git 100644.
Local origin/trunk_dev equality is not current remote truth; no network check.

Baseline snapshot corroboration only: 3,134,667-byte archive, SHA-256
`06d981b6100fc1d6ad9792aff35800eb0772b8d35f708ed030177967ccb9c40e`;
its 263 source leaves reconstruct the fixed tree. No .git commit/ref attribution
is inferred from an archive filename. Local baseline objects and this receipt
are sufficient; no historical archive delivery is needed by this task.

The latest independent audit reports a valid opening/closing preservation
interval and no current ref delta. Its earlier all-ref failure is separate
history. Establish this new repair's own opening, without attempting to restore
or manufacture earlier records. The following is the existing opener with repair
labels; it writes only a new external helper/record and runs no Git or repo code.

```sh
python3 -I -B -S - <<'PY_OPEN'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env


import datetime
import shutil
import tempfile

guarded_environment()
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_not_exact_audited_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_unavailable')
gate_root = Path(tempfile.mkdtemp(prefix='rw0-d2-stop-reason-repair-v2-'))
os.chmod(gate_root, 0o700)
print('GATE_OWNED_ROOT=' + str(gate_root), flush=True)
record = {
    'schema': 'rw0-d2-stop-reason-repair-v2-opening-observation',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents, 'index_path': str(index),
    'index': index_before, 'cache': cache_before, 'git_executable': git,
    'git_environment': GUARDS,
    'limit': 'This stop-reason repair interval only. Only the two named working payloads may change. Index, guidance, cache and protected refs remain unchanged; section 3 qualifies separately observed diagnostic refs. No ref write, staging, commit or remote action is authorized.'
}
READ_HELPER = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = 'ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\n\nimport subprocess\nimport sys\nopening = json.loads(Path(__file__).with_name('opening.json').read_text(encoding='utf-8'))\n\ndef immutable_checks():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('audit_index_content_or_metadata_drift')\n    if regular_record(REPO / 'AGENTS.md') != opening['guidance']:\n        raise RuntimeError('audit_guidance_content_or_metadata_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n\nimmutable_checks()\nindex_before_read = regular_record(index_path())\nargs = sys.argv[1:]\nif args == ['--check']:\n    print('READ_HELPER_IMMUTABLE_SURFACES_MATCH')\n    print('CURRENT_INDEX_SHA256=' + index_before_read['sha256'])\n    print('Index content and metadata equal this audit opening; no stage or index write is permitted.')\n    raise SystemExit(0)\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree',\n           'check-attr', 'for-each-ref', 'reflog'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_read_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'], ['--quiet', 'HEAD']):\n    raise RuntimeError('readonly_head_query_only')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('readonly_worktree_list_only')\nif args[0] == 'reflog' and (len(args) < 2 or args[1] != 'show'):\n    raise RuntimeError('readonly_reflog_show_only')\nfor arg in args[1:]:\n    if arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec') or arg.startswith(('--output=', '--exec=')):\n        raise RuntimeError('unapproved_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager', '-c', 'core.fsmonitor=false',\n           '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=guarded_environment(), check=False)\nfinally:\n    immutable_checks()\n    if regular_record(index_path()) != index_before_read:\n        raise RuntimeError('index_changed_during_read_command')\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(payload)

try:
    write_private(gate_root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(gate_root / 'live_read.py', READ_HELPER.encode())
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_first_git')
    print('OPENING_RECORD=' + str(gate_root / 'opening.json'))
    print('LIVE_READ_HELPER=' + str(gate_root / 'live_read.py'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D2_AUDIT_PRE_GIT_OPENING_RECORDED')
except BaseException:
    for name in ('opening.json', 'live_read.py'):
        p = gate_root / name
        if p.exists():
            if not stat.S_ISREG(p.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            p.unlink()
    gate_root.rmdir()
    raise
PY_OPEN
```

Use only the actual emitted record/helper paths; do not reuse a deleted root or
assume shell variables survive tool calls. Every LIVE Git read uses the helper:

```sh
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> rev-parse HEAD
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> status --short --untracked-files=all
```

Capture all baseline blobs/index entries and actual source modes, then authenticate
the following fixed RAW-PAYLOAD identity twice before edits or candidate execution.
A streamed and concatenated construction provide useful independent calculations.

```text
70 rows: 47 M / 23 C
payload bytes: 5,794,198
encoded row bytes: 5,799,596
total including prefix: 5,799,621
SHA-256: f7b8580df9a59f1270858ddf316f5bab2fafec5079a77c4e41d7bda6a4abc05e

25-byte prefix: ASCII RW0-D2-BINARY-REPLACE-V1 followed by NUL
rows sorted by UTF-8 repository-relative path bytes:
  u16be(path byte length) + path bytes
  ASCII M or C (relative to fixed HEAD)
  u32be(0o100644)
  20 raw baseline blob bytes for M; 20 zero bytes for C
  u64be(payload byte length) + exact current raw payload bytes
```

Do not compute that identity from the per-file hashes instead of the payloads,
accept an obsolete opening or replace the supplied expected aggregate. All listed
rows are regular nonsymlink OS 0644/Git 100644. `absent` means absent from HEAD and
index, not absent from the current working directory. The resolved first-live
posture baseline blob below is final; no malformed historical cell is reused.

| Path | H | Baseline blob | Bytes | SHA-256 |
|---|:---:|---|---:|---|
| `.docs/architecture.md` | M | `7d21418a68d2d3002753227da08cf059836d0260` | 44,745 | `5075b772afddcfe8276933d189155aa689dc4c1ee162bb702c7c7f4efaf04635` |
| `.docs/authority-boundaries.md` | M | `3524d11d67a46344214b455396afeeaa3754b41d` | 36,175 | `79c57d377b6ef7f2460ee5a5827b9c5c61334e656be9eeed73264a6906e55e32` |
| `.docs/autonomous-software-development-operating-model.md` | M | `a46d51fe3ea480e39c8c7989a08e80d9db21f5b8` | 41,197 | `926468bad8cd51c57e3aec6da775c6dced52880215f24d5b03177499a119c6c2` |
| `.docs/b3b2a-read-scope-and-query-contracts.md` | M | `c3237c31fc4b59dcd632b827a4be9907cfcfb998` | 10,013 | `74b1d21b02cd9886a697e1f1cb01dca6977cabb2da194269a35d49745fe548f6` |
| `.docs/b3b2b-select-readers.md` | M | `f1ba74b0a5cd3946a3138de326949d29f789cfac` | 6,477 | `fa7a364ce070b3fcef44907bc884bc783200e1951c618fd7e392d485497c7f07` |
| `.docs/c2b-durable-development-state.md` | M | `04c068d07cd08feaf6c56dafbf3494ccde037ede` | 1,891,411 | `8db2ba24f0685ac21fae2103bb664727a8d9635d3ead5f6bae0d42b35aaf34d2` |
| `.docs/c2b2-private-readers.md` | M | `018b3d905f5db80cf15b546f881dc8c1de3a67b7` | 14,020 | `f765b2dcd74979e235cb04c15dd1fbc81eca149aec017ca500708903bbc105d2` |
| `.docs/c2b2-pure-durable-row-values.md` | M | `1cab6d886f2cd3101987476064a9ce82d2eb4dd2` | 8,540 | `0970595b4c292517d0770542ff8e12a03b98ea93057d4e715d6518415e83aaf3` |
| `.docs/durable-state-model.md` | M | `49694cd86a51f3fb0fb3799e734a52c1a395b8c7` | 42,053 | `7f9cba19f491322dd2fc0f1656ac6b76e698723a6700d1f9919d22b2196e9e80` |
| `.docs/rw0-b1-pure-phase-values.md` | M | `5b7fb0072c6d04898cd212fdc4ff5f63903cf13b` | 35,115 | `7294e7b3aabad5338c4d846e44686ffd075b3e8fe4598495a3e7267103a9ef1e` |
| `.docs/rw0-b2-wire-protocol.md` | M | `5e41d1cb3b2f430d29eb88bdbf2b46570faf3c6b` | 26,084 | `ac1091f043f5fa6042ced1e919c740a08af975b7df1e5e97b66634f85cb68e69` |
| `.docs/rw0-c1-durable-evidence.md` | M | `a7111c4dcf761b60df35c59794bf2e3acd949745` | 15,037 | `f2c6c51d0437aa78b7975bfca3e6fc629fc2898d55c0c696750221000343a02c` |
| `.docs/rw0-c2-first-live-proof-posture.md` | M | `4b69e424655ea67900f6c6042c0cbacaf2d53f8a` | 17,674 | `ba61008234eb5ec85416c459dab0a82b19f7e1a0662dcb15f1289ba445fdf5bd` |
| `.docs/rw0-d1-offline-process-and-capsule-spine.md` | M | `f3557ca523cac0d6fa26647b17a84aef66fecc15` | 5,624 | `b537fbe074717aacdfaefd2cf32cd22c46046034ae115453ddded4e2dc25201b` |
| `.docs/rw0-d2-offline-evidence-and-review.md` | C | `absent` | 8,348 | `f9306ad7333ae08aefd62456041629380c05e984bddc3925258c655a28fa7580` |
| `.docs/rw0-remote-worker-contact-phase-entry.md` | M | `230167a39b115634c8f9b5ae5a0699639f6ff454` | 59,586 | `bee20ed00c7e6f86db3394351f0cbe29626413c635cd9a982416984b288e6fbd` |
| `.docs/worker-execution-boundary.md` | M | `464aef2aa7a561e4adc6792d1d07642d3576f364` | 32,409 | `3cfc1208d96e1f59a81dcd70dce5d43d89f2cb70cc5af6eca453650c33742769` |
| `AGENTS.md` | M | `254854d4a57487d97ce02a73ce2ed26c86ece170` | 64,142 | `ddf5485d88fc4604429a2b553643e3a8a80828002d17f7cfcb10cb935d018166` |
| `README.md` | M | `088c832ca7e28d18c82ff6317738ac8ca1c7b5d1` | 47,694 | `f48f2439d282350e36b5d8374864cb5dfe19eb417672737e820500c3a68224f3` |
| `src/ge_nwp_coordinator/_cognitive_proposal_semantic_values.py` | M | `c164616b9e86379c3c6a9210cf4941429a596d4c` | 71,190 | `40243b96765ee0bf49e56a36123e0553f3bb9ab3e0fada38dbe619a2acc1eacd` |
| `src/ge_nwp_coordinator/_development_bound_effect_establishment_contracts.py` | C | `absent` | 43,039 | `fd8fb53c8129001b74df8fa5b15ae69bb45fd970e2aa93f3bc5c20eeeeb1b370` |
| `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | M | `cb37f733141f1e3c3ce874fcc052149de1f82881` | 3,668 | `21e0c9d6c2ece57b87dfb05e961ba1a99a48e72346bbab2c4c1ed571eb5f1f00` |
| `src/ge_nwp_coordinator/_rw0_d1_handback.py` | M | `ecfcf767a5f1c32c0cf007a2c8aa3137ef92374d` | 16,920 | `3cae7fa4423187d53382ba23d9e459a5f0efcb6900a4deed6d4498ed2534ed56` |
| `src/ge_nwp_coordinator/_rw0_d1_offline.py` | M | `4f2a82e46fda9be8123888f5ca46968a4345c25f` | 23,371 | `9546f06f211253d72ea91e0dc2eaf4f0b47fdd54e3d431207f59960fbc742c95` |
| `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | M | `7dc90a0442e348aaac985d711c4d1a97adb7cc05` | 12,175 | `a236bbf599e7d32b4edcc31d23182fd9613c5d290f31a0f1e57961b6a104fe56` |
| `src/ge_nwp_coordinator/_rw0_d2_handback.py` | C | `absent` | 13,339 | `1e4fddda53315d7a14d042780730e0cce07b9a5c67d41233ddff550a430ac24f` |
| `src/ge_nwp_coordinator/_rw0_d2_offline.py` | C | `absent` | 6,967 | `d838dd02495cab5cbafa2e6e0b99d6a4e6b4b30e4ac5cb288cb9dd2db02d0d44` |
| `src/ge_nwp_coordinator/_rw0_d2a_evidence.py` | C | `absent` | 53,134 | `e93c2592c8f838bd178ffa8e57f57a9116fcdf567b248e511496d00384968ec9` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_reviewer.py` | C | `absent` | 2,878 | `0d061fdf600039ff69ba0d0dc3f1a0239c2527500461244bb53455bbdd326973` |
| `src/ge_nwp_coordinator/_rw0_d2a_fake_validator.py` | C | `absent` | 2,726 | `c1eb49503b4345d25047814e089545f9d1cd4c85f10ae20254b8b6283fa58fbe` |
| `src/ge_nwp_coordinator/_rw0_d2a_handback.py` | C | `absent` | 20,455 | `7d1fc29c303666907c3f6e863f551d448684009db0d0b1db9881d64889e0e14f` |
| `src/ge_nwp_coordinator/_rw0_d2a_offline.py` | C | `absent` | 30,416 | `d81db9535b17c7daae7be449d7e30dbcaaa599749ddc2619dbfa7d40f87db838` |
| `src/ge_nwp_coordinator/_rw0_d2a_process_frames.py` | C | `absent` | 6,397 | `2c969b1ec303674500143bbbd721e4fe5f7ee161e00b4343f71a611a7f075c8d` |
| `src/ge_nwp_coordinator/_rw0_d2a_workspace.py` | C | `absent` | 5,075 | `45086c2b216639d3a35deef972acda526f004608780a8a8b5e30ed51253f0697` |
| `src/ge_nwp_coordinator/_rw0_d2b_fake_review_model.py` | C | `absent` | 3,771 | `492288c84c2491120a56c7056000f8ec3860c7fbce2bcb3c33249e5e1af5d93a` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_frames.py` | C | `absent` | 8,032 | `e4b7cddc6cfd4caa7e34781e1c34c00833d6f83a98477d46ce55e878e97dfcef` |
| `src/ge_nwp_coordinator/_rw0_d2b_model_input.py` | C | `absent` | 81,718 | `e2bbe585f8ae19df5dd6547212cf239ac58411795cbae904cf3ed869910bdd9a` |
| `src/ge_nwp_coordinator/_rw0_d2b_proposal.py` | C | `absent` | 22,718 | `deec7caf82206c40545a308f3a8845fb867e64a211a81e055fb29ffbafc0666a` |
| `src/ge_nwp_coordinator/_sqlite_development_bound_effect_establishment.py` | C | `absent` | 23,762 | `d5012ef7dd383ae39364772d7702364fc0eadde31a1e64997c0a6773d6025245` |
| `src/ge_nwp_coordinator/_sqlite_rw0_c1.py` | M | `635b5dd49256e14103fced6ff8ea4db76649e22c` | 203,409 | `d17490b3ce1b136eeb3d559f01f44e97836827bc137325b306ec01530e06e9e7` |
| `src/ge_nwp_coordinator/sqlite_transition_transaction.py` | M | `f8053db4010faaba41b38b531d93a8b21e80daa8` | 180,600 | `6d662dcb83a2641b9d95dee7209ddbd0d8b991bc720da3aafa5b4b9fb3bc5521` |
| `src/ge_nwp_coordinator/sqlite_writer_session.py` | M | `97162e3a749a7f1f1ae75de90c4b2d9092068107` | 299,804 | `54f9c5a0844421686c1c89cdecf3c2865263b3339d2faec933c615ca2ca3d404` |
| `tests/test_b2a_writer_session_contract.py` | M | `ccadd884de29d606c9243ea7796cc380e29fe5c2` | 29,168 | `835b386274f410f2fc52b1a40b2c936009ac5286fb22bc23cc28efa789be0664` |
| `tests/test_b3b2a_read_scope_and_query_contracts.py` | M | `66cab4655d33c1b864f5fb4c22e853a39c5a8188` | 26,502 | `4cabeed0c37a99c0f937c0b49f25c7c6a049eb9125e64127019c449dcd86313a` |
| `tests/test_b3b2b_select_readers.py` | M | `c0c5a0e091572f30a428fd5a2634c21d25a6ad64` | 118,350 | `22061f6846b0ebc969f9b67bac399b8d8eb237c8df0e2de92d84d477c0f1ce2b` |
| `tests/test_b3c4c_prerequisite_contract.py` | M | `f1ee03232e33da8bbfa5592fe81c53414acb25b1` | 36,340 | `3d25c2ffb8ee86856c154cfc9dd842bab2db87ea2b200cd75758a62f372b5cd8` |
| `tests/test_c2a_nonimplementation.py` | M | `3f343ae5886c92941ebfff63ba4213de2109025e` | 30,650 | `c0db68e10f4588c02bbc38da1b95d6898a3d7896c127038533ce0c8a6715442e` |
| `tests/test_c2b0_durable_state_contract.py` | M | `b910d61aaf670ba40a0d649f933c06767e7360e5` | 887,367 | `995c3690500e3d3009f1fe93b276db506e1d454764dd2e5167df52bf81252c1a` |
| `tests/test_c2b2_development_reader_contracts.py` | M | `122f0d44b46e0a8d7b283d5baec1ce465e2028b6` | 71,365 | `28dbf4fff09d75d7522af35c8fddc8908b7c4c1d18ff8043d19dbf6b90f30970` |
| `tests/test_c2b2_development_row_value_boundaries.py` | M | `d7dea23786bec2ca98bb702bbe93cc31e4192221` | 17,972 | `f2a7089748f39dc8c40a932ac770edd3ffa7f8ea581b053af101dfda8100c830` |
| `tests/test_post_execution_pure_owner_boundaries.py` | M | `437a4e7cbd39682bdd08f03b3a30c0bbbd057614` | 19,302 | `7945be6d5e01c2a1b437cabc57972bbd70a725da9c14f7dd92574ff8f8633014` |
| `tests/test_post_execution_pure_owner_vectors.py` | M | `3eed1c6bc08b6876d1e74d94a4e5509c14786eb0` | 103,682 | `3d526cabcead871b5bba47952b914df76a34b5d85a7b730e55afb951c050de16` |
| `tests/test_runtime_non_authority.py` | M | `79d4ab185815234c9d087c48d2439b9a1d95d95d` | 48,343 | `fef5729d8e7f4c619ddb2731b52d3500bc8e75988a3f422648b9dea743ef01c9` |
| `tests/test_rw0_b1_boundaries.py` | M | `17d1e09c30b01287718c6b5175bac76b03daf458` | 52,838 | `af8d9f7507733876a5978d1a3f5b871a81030380eba929cbffe6959f9d639aaa` |
| `tests/test_rw0_b2_capability_boundaries.py` | M | `4668d2a2c285d2d79bf6ebfb0c9c9f60166bcb27` | 50,538 | `85ee20f37629ffc852154cea67dd5dc983b0f2f74ab2d370192c13d999b397c3` |
| `tests/test_rw0_b2_wire_boundaries.py` | M | `9e04f528326a6f337a4f47e7e9f9eda3c9a82e0a` | 38,513 | `13531d5d46258ca67cc7bf0bddd78c560ce9b7308ff296068a146299f349ba27` |
| `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | M | `0f0159c172e1448d2b96ab19411e1f85467a2931` | 120,405 | `af7f49ac8da64c12e97d03a536ee10b89a11996651b0d712dc04baef427d8cf3` |
| `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | M | `e9d95b54a4b5921be8ec39d2bf3f6216204750c7` | 247,679 | `e8de37791388c28f1b1626747af6c4094622469168ed9799eaa78f7f6f4d3613` |
| `tests/test_rw0_d1_handback_values.py` | M | `982be9b37aa05db0c6d6a3321b775c7c64f2142d` | 30,189 | `e8addc00e8b37aa5e6f24a91a637c9f5053656c58a0d4c06e713618229e448b6` |
| `tests/test_rw0_d1_offline_integration.py` | M | `33c2d85012cbdf0e7e04fdeb7d333d2c8675ae3f` | 53,132 | `c5997a4e9161253974b04b203bf55754c12b465c3b0b5924247e6c1df8e05c9e` |
| `tests/test_rw0_d1_worker_process.py` | M | `e2a83abe44db720b5ce0725682ac71d30372959d` | 1,737 | `512d7d61083e8ad8c61c197aefc86f70d61a1f7e41273fab435bb493cc08631f` |
| `tests/test_rw0_d2_bound_effect_contracts.py` | C | `absent` | 5,636 | `4c8f04a5f16d0e0b236f8fff636e5d9a5d41c465dad6fc726bd488fb76b59574` |
| `tests/test_rw0_d2_bound_effect_persistence.py` | C | `absent` | 6,068 | `839a68b7285480a6ca19885be2df2e398dbedb8e6909f381f5cfe4aa8155da67` |
| `tests/test_rw0_d2_c1_checked_readback.py` | C | `absent` | 17,750 | `20237660028125bacccf52bb695cb275adebefb2ed1f0a28bb271688f7aadb01` |
| `tests/test_rw0_d2_evidence_children.py` | C | `absent` | 3,635 | `fd4cd60a30cb641d34b458f7782bcc27d020a37f47f6523c37cfcf83895d516b` |
| `tests/test_rw0_d2_model_handback.py` | C | `absent` | 4,966 | `89c53206f1b636257ecf5f71027e11ca4ef4cfdd00883e55b2c0fa02fe2a7a6e` |
| `tests/test_rw0_d2_offline_integration.py` | C | `absent` | 19,540 | `b6f9f0d7906b22e116d25e09dd4ed42eb48c33af9dd6aeeba7c56406b2b1808a` |
| `tests/test_rw0_d2_process_frames.py` | C | `absent` | 6,894 | `f77f49268e4ed693d049560307aa3794538842efc8afa24e1500664fc4884264` |
| `tests/test_rw0_remote_contact_phase_entry_contract.py` | M | `2a9144c3dfd2c883555703c8adecd21f447d6d34` | 177,317 | `6df3c991a219633d148106396336f2702c323b6cddb82932b41152ea3e5ac16a` |
| `tests/test_sqlite_backend_b0_contract.py` | M | `c646df6d439d0b70f45d6d72200fbedb5e730779` | 26,412 | `1eb038201c19be7e9680f5ee6c4425fb50051b8bc0df31e3feeab06620cc094e` |

## 3. Protected refs and the carried-forward diagnostic qualification

This repair explicitly adopts the narrower observation procedure selected for
the last independent audit; it does NOT inherit a false all-ref-preservation pass.
The auditor reported 53 observed refs, classified as 28 protected and 25 diagnostic,
with all 53 unchanged at opening, pre-execution and closing. Its complete observed
snapshot hash was `cadfb74fa8e220dbf09674e163615e4021cabcd9889f80de961a609c196e0237`
under its reported serialization. `origin/HEAD` resolved to `origin/main`, while
the branch under review was trunk_dev tracking origin/trunk_dev. Do not "correct"
that unrelated symbolic target. These are PRIOR OBSERVATIONS, not a hard-coded
current ref count or a complete list supplied in this prompt.

After the opener and BEFORE edits/external code execution, capture complete actual
ref names, OIDs and symbolic targets through the emitted read helper, e.g.
`for-each-ref --format=%(refname)%09%(objectname)%09%(symref)` and `symbolic-ref -q HEAD`.
Keep an immutable external record and its disclosed serialization. Protect every
ref by default. A narrow diagnostic classification may cover only actual records
under these EXACT two subtrees:

```text
refs/codex/turn-diffs/captures/
refs/codex/turn-diffs/checkpoints/
```

Reconfirm applicable use/non-use from current source/config/guidance and available
records: no baseline, execution copy, program, policy, admission, publication,
recovery or validation expectation is selected from these records; no protected
symbolic reference resolves through them. A names-only rule or literal search
alone is insufficient where generic ref enumeration or --all selection is used.
This repair selects executable source from the fixed HEAD plus authenticated raw
working payloads ONLY. Do not select captured trees. The unchanged supplying
source and earlier classified observations may support the bounded reconfirmation;
no investigation of who wrote the earlier refs or another provenance program is
needed. Missing historical objects need not be fetched, restored or recursively
read. Do not access captured secrets, provider state or arbitrary untracked data.

Only records whose non-authoritative diagnostic use is established may be listed
separately. All others, including unknown refs in or outside those subtrees, stay
protected unless the same conditions are established. A new ref or symbolic
relationship requires classification; nothing under refs/codex/** is automatically
ignored. No need to relabel an unclassified object as harmless merely to pass.

Compare protected refs, HEAD symbolic target and resolved object, upstream,
worktree membership, source, index, guidance and cache with this SAME opening.
Record full snapshots before edits, before final execution, and at closing.
Qualified diagnostic deltas are disclosed old/new exceptions, not automatic
source defects. Source/index/protected-ref drift, an uncertain protected dependency,
or observed competing source edits blocks this repair. Never reset expected
inventories, restore any ref, claim interval-wide immutability from endpoint-only
observations, or claim diagnostic refs are outside Git truth.

The earlier V1 repair's two removals at object
`014f6845ec3672c7a2c2e54f8745e8d2e0505a06` and two additions at
`1450a5e4845d20d9199004ea862ebdeadb8139e0` remain a qualified historical failure
under its older all-ref rule. Their writer/cause remains unestablished. No current
ref delta occurred in the latest independent audit. This new procedure neither
rewrites that history nor authorizes a ref write by this repair task.

## 4. Pure status/reason-to-reached-facts invariant

### 4.1 Derive one closed relation from existing producer sites

Within this implementation pass, record a compact table for ALL existing final
handback status/reason families. For each list actual producer path:line, status
and reason (including bounded forwarded reasons where the current owner supports
them), D1 prerequisites, permitted committed-effect/admission prefix, D2 child
attempt/outcome prefix, checkpoint presence, model-input/output presence and
applicable cleanup facts. Follow exception and early-return sites, not just the
normal return. Include shared generic failure reasons at every supported site.
Put this operative derivation in the inline closeout and test-local fixed
expectations/comments; do not create a new doc, schema, freeze artifact or ledger
in production. Do not stop at a separate mapping result.

Use the present retained data to validate whether that explanation is possible.
A reason may map to MULTIPLE permitted evidence prefixes. No bijection between
reason and stage is implied. A generic model-input/normalization reason can span
prelaunch failure and genuine late post-response failure where the source uses it.
Do not reject those valid branches to obtain a tidy single stage number.

An evidence-prefix matrix includes semantic conditions and exact existing
cardinalities/relationships, not just number-of-non-null-fields. Check nested
node types/values before dependent comparisons; do not dereference missing values
or invoke overloaded equality on unchecked scalars. Use existing nested validators,
including the unchanged authority-role checkpoint validator.

No new full execution history is being added. A pure handback validator can reject
an explanation inconsistent with retained facts; it does not independently observe
unretained hidden actions or prove every historical statement. State that limit.
Where two legitimate paths have identical retained facts, preserve their existing
permitted ambiguity. If a genuinely required distinction CANNOT be expressed
without a new field or changing a producer/schema, report the exact contradiction
and retain work; do not silently create another lifecycle or invent evidence.

### 4.2 The d1_stopped implication is two-part

For any status/reason combination where the existing wrapper legitimately uses
`d1_stopped`, BOTH must hold:

1. The retained D1 handback belongs to the actual non-continuing D1 branch accepted
   by the current D2 producer; it cannot be `capsule_ready`. Use existing D1 status,
   reason and cleanup validation. Do not assume its only legitimate status is the
   literal `stopped` if the actual producer also propagates cleanup_unresolved.
2. No D2-owned later evidence is retained: no committed D2 bound-effect proof,
   D2 checked admission, D2 child outcome, A checkpoint, B model input/supply/
   binding, model source/process, post-review artifact/projection/evidence set or
   proposal. Use the exact empty/absent representation already selected by the
   current handback. Validate ALL present final fields by their owners, not a
   hard-coded check of only checked_admissions length.

Do NOT require all prior D1 facts to be empty. A legitimate D1 stop can retain
its own program/author/selection/phase, planner/worker, capture, failure or cleanup
evidence according to its own contract. This repair never erases that history or
relabels it as an earlier stop. D1 nonselection is an existing D1 reason, not a new
D2 status chosen here. Preserve whatever current outer producer mapping is supported.

Conversely, changing the reported late failure's reason to d1_stopped must fail
even if all those later values are individually valid and the D1 run was ready.
A ready D1 with an otherwise empty D2 portion is still NOT a D1 stop; emptiness
alone is not sufficient. An impossible D1/D2 mixture remains invalid even if some
other current cross-check independently rejects it. Credit that actual check,
not a hypothetical execution of a masked new predicate.

### 4.3 Preserve legitimate A, B and cleanup outcomes

Bind every other existing reason family to its source-supported prerequisites and
retained evidence shapes. Use actual source literals; the categories below name
obligations, not additional statuses or invented error names:

- Failures before or during native effect establishment and C1 admission retain
  their true verified prefix; no blanket two-effects/14-families requirement on
  a stopped invocation and no discarded confirmed work.
- Checking source failures, start failures, cancellation, timeout, malformed frames
  and failed reconstruction may occur after prerequisites but before a complete
  checkpoint. Retain actual child attempts and cleanup evidence, not successful
  evidence invented to complete a tuple.
- A complete A checkpoint can legitimately appear in a stopped B path. Keep its
  original source/family/role binding and final checked-admission relationship.
- `model_input_or_normalization_failed` MUST still admit the real reported
  post-decode failure with two effects, 14 families, complete checkpoint and three
  D2 child outcomes. Do not treat that reason as proof the model was never launched.
  Require only the model-input/output fields actually retained by its producer.
- Cleanup-unresolved is not ordinary clean success or automatic D1 failure.
  Preserve the responsible child/workspace outcomes and actual reached prefix.
  Do not label a clean record cleanup_unresolved without the contract's basis.
- A valid negative source observation or any of the five legitimate recommendations
  is not itself an execution failure. Preserve valid preadmission_ready results
  carrying repair/replan/reject/block recommendations under the current contract.
- Ready status/reason still requires its existing complete evidence and successful
  cleanup. Do not make stopped mean merely "not ready", or permit a success reason
  with absent required evidence.

Reject unsupported or syntactically valid-but-inapplicable reasons through the
existing content-free error. Preserve the selected bounded grammar where an owner
forwards a finite family of reasons; do not define validity by the set of labels
which happened to appear in this one run. No post-execution semantic schema,
recommendation meaning, frame, field order, clock policy or admission rule changes.

### 4.4 Constructor AND current consumer

Ensure the final object's construction/replacement and its explicit consuming
validate() reach the same operative pure invariant on the PRESENT data. A prior
constructor result is not proof that a forged exact wrapper is still coherent.
Do not implement a test-only gate or store a flag that says the object was validated.
Preserve existing _rw0_d2_handback -> checkpoint revalidation and role joins.
No new inner owner or secondary assertion type is needed for this rule.

Never fix a mismatch by sorting, stripping evidence, substituting a different D1
handback, rewriting the reason, re-running a child, consulting SQLite, sampling
current time/authority or manufacturing a model block proposal. The only selected
behavior for the malformed graph is rejection. A correctly formed historical
handback does not become invalid merely because its old source expiry passed
since its original invocation; B-entry currentness remains separately governed.

## 5. Permanent evidence and finite causal controls

### 5.1 Reproduce the reported reason-only defect on opening bytes

After authentication, create a remote-free external copy. Use a real D2 invocation
and a controlled fault at an ACTUAL existing model-input/normalization failure
boundary AFTER a real model response has been decoded. Observe that decode and
fault without replacing the child with a prepared handback, making the observer
a launch gate, or copying expected DB rows. The baseline handback must genuinely
return stopped/model_input_or_normalization_failed with the reported D1 readiness,
two effects, 14 checked families, checkpoint and three D2 child outcomes.

Assert its original validation succeeds. Change ONLY reason to d1_stopped and
reproduce successful dataclasses.replace/validate on the opening candidate.
Independently show its retained later facts contradict that explanation. The
substitution itself is in-memory and must not write/readmit a family, create a
new child, mutate a valid run or dispose somebody else's run. Record external
DB identity and actual child handles before/after the substitution where the
existing test mechanics permit. Treat the genuine invocation's own effects
separately. Close all positively owned runs in finally blocks.

Do not claim to recreate the auditor's deleted script or its differently framed
copy digest. Your specimen has its own manifest, source identity and commands.
If reproduction materially differs, inspect the actual producer and report the
difference before editing; do not modify code to manufacture the opening bug.

### 5.2 Fixed positives and reason-mutation matrix

Add tests ONLY in tests/test_rw0_d2_offline_integration.py. Preserve all existing
19 node meanings and the V1 independent role/final-consumer tests. Test helpers
may share real-run setup, but fixed expectations must not be obtained from the
production reason table or predicate being tested.

Cover these bounded obligations without a Cartesian product of all reasons:

- Normal ready D2 remains accepted. Existing five recommendation tests stay valid.
- Genuine D1-stopped/non-continuing propagation remains accepted with its legitimate
  D1 prefix and no D2 evidence. Include applicable D1 cleanup/nonselection mapping
  when supported by the actual producer; do not invent a new permitted combination.
- The genuine late model-normalization failure remains accepted unchanged and its
  ONLY-reason -> d1_stopped replacement is rejected. It must reach the new relation,
  not fail earlier through a stale digest, wrong nested type or fabricated prefix.
- Independently reach explicit validate() with a controlled forged exact final
  wrapper differing only in reason. Bypass construction solely in test specimens
  where necessary; do not call another validator first and credit that refusal
  as final consumption. Both replacement construction and final consumption fail.
- Independently rule out ready D1 + empty D2 being called d1_stopped. This may be
  an actual early-A failure if one exists, otherwise label a pure consumer specimen
  honestly; do not claim the artificial wrapper was naturally produced.
- Exercise one actual positive for each distinct permitted prefix family from
  section 4's source-derived table, using existing negatives where they already
  provide it. Test reason-only moves between materially different early-A,
  checking and B prefixes, and mismatched ready/stopped/cleanup categories as
  applicable. A reason with several valid prefix shapes needs those legitimate
  representatives; a coincidentally allowed cross-label is not an expected refusal.
- An unknown/wrong-runtime-type reason continues failing under existing discipline;
  those cases do not substitute for the valid-string wrong-stage counterexample.
- Existing partial-effect/admission, authentic negative-result, cancellation,
  timeout, cleanup and no-invented-model-result tests remain truthful. A valid
  stopped result with complete A evidence is NOT repaired into a checkpoint-free
  result to make the rule easier.

List every current reason/family, actual producer and coverage disposition in the
closeout. The finite inventory is the current producer grammar, not a new public
contract or a requirement to instrument every possible Python exception. Do not
hide a real untested represented family behind an aggregate count.

### 5.3 R01 — direct omission of the new operative relation

Use one final-byte external controlled copy, tests unchanged, to remove or
neutralize the newly operative final status/reason-to-reached-facts check. Keep
role-source joins, checkpoint validation, all nested validators and process/schema
checks intact. The original positive and genuine early/late positives pass; the
fixed reason-only negative loses rejection and the corresponding permanent test
fails at its expected rejection assertion. The explicit forged-wrapper consumer
negative should discriminate that same omission.

The actual code need not be organized around a named helper solely to make the
mutation easy. Identify the exact statement/predicate delta. If separate existing
checks mask a narrow deletion, report the demonstrated invariant and select a
bounded valid predecessor reaching the intended condition; a combined omission
proves the combined relation only. No blanket deletion of validate(), changing test
expectations, fixture errors, stale nested values, syntax/import/collection failures
or unrelated source-inventory failure earns causal credit.

Record positive and hostile node IDs, complete unchanged collection, targeted
exception/assertion, actual effects, source identities and endpoint preservation.
No full suite per defect copy is authorized or necessary.

### 5.4 Preserve V1 J01/J02 without treating them as the whole audit

The latest independent audit ALREADY reproduced J01 and J02 on V1: role-join
omission lost source/paired/same-role rejection; final checkpoint-validation
omission lost forged ready and genuine complete-A stopped consumer rejection,
while positives and direct checkpoint rejection behaved as expected. Its normal
integration module passed 19/19. Preserve that as prior independent evidence,
not a new claim of complete A12 or A01-A13 acceptance.

Because this repair changes the same final validator and its test module, rerun
the existing small J01/J02 controls on final repaired bytes. In J01, remove only
the existing checkpoint role-join call; retain the new reason validation. In J02,
remove only final checkpoint revalidation, leaving both checkpoint correctness
and the new status/reason relation intact. The genuine stopped positive used by
J02 must satisfy the new matrix; do not reuse an impossible reason label or let
the new reason check mask the checkpoint-consumption defect. Do not edit the
protected checkpoint source in the LIVE repo; its temporary mutant is external.

Use actual final source endpoints to identify these new copies. No historical
copy package or repeated broad independent campaign is required of the repair
writer. The independent A01-A13 completion remains a later gate.

## 6. Final source validation and exact group membership

After the LAST source/test edit, create one fresh normal remote-free copy of the
263-file fixed baseline plus all 70 current candidate payloads. Authenticate all
286 endpoint bytes/types/modes before and after every normal command. No live
cache, secret or product database is copied. Do not hardlink mutable live sources.
Tests that need local Git metadata may use a local-only clone at the supplied
baseline with its remote removed before execution; no fetch/network or captured
ref source selection. Ordinary manifest-checked source copying is also permitted.

Use installed Python 3.13 and pytest; record the exact versions. Set umask 022,
owned TMPDIR, PYTHONDONTWRITEBYTECODE=1, PYTHONPATH=.:src, -B, and
-p no:cacheprovider. No xdist/parallel groups, dependency install, skip/xfail,
warning suppression, or selector changes to manufacture a result. Precreate
separate collection/run basetemp parents for every group.

First complete the whole integration module, R01, and the affected J01/J02 checks,
plus directly coupled architecture/consumer smoke. Then run all six groups below
serially, collection before execution, followed by one FULL collection/execution
with NO path selector. The original 9,054-pass run is implementation evidence,
not a substitute for final-byte validation after this source change.

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-group-collect> --collect-only <exact-group-paths>

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-tmp> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<owned-group-run> <exact-group-paths>
```

The full fixture lifecycle is outside the live checkout. Use lstat for artifact
inventory, hash/open only regular files, follow no fixture symlinks or special
files. Keep actual child handles/PIDs/groups and positively owned roots through
failed tests. Emergency rescue must be separated from runtime cleanup credit;
never kill by name, signal unknown processes or sweep generic /tmp.

### Exact selections

#### A0_D1

```text
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_offline_integration.py
tests/test_rw0_d1_planner_process.py
tests/test_rw0_d1_process_frames.py
tests/test_rw0_d1_process_supervisor.py
tests/test_rw0_d1_worker_process.py
tests/test_rw0_d1_workspace_capsule.py
```

#### BINDING_COMPAT

```text
tests/test_c2b3c_author_effect_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_c2b3d_author_effect_establishment_recovery.py
tests/test_c2b3d_private_atomic_author_effect_establishment.py
tests/test_c2b3d_private_author_effect_delegation.py
tests/test_worker_execution_semantic_relations.py
tests/test_worker_execution_semantic_vectors.py
```

#### A_NATIVE

```text
tests/test_rw0_c1_mutation_contracts.py
tests/test_rw0_c1_private_atomic_persistence.py
tests/test_rw0_c1_private_readers.py
tests/test_rw0_c1_reader_contracts.py
tests/test_rw0_c1_recovery.py
tests/test_rw0_c1_row_values.py
tests/test_rw0_c1_semantic_values.py
tests/test_rw0_c1_writer_session_delegation.py
tests/test_rw0_d2_bound_effect_contracts.py
tests/test_rw0_d2_bound_effect_persistence.py
tests/test_rw0_d2_c1_checked_readback.py
```

#### A_EVIDENCE

```text
tests/test_post_execution_pure_owner_relations.py
tests/test_post_execution_pure_owner_values.py
tests/test_rw0_d2_c1_checked_readback.py
tests/test_rw0_d2_evidence_children.py
tests/test_rw0_d2_process_frames.py
```

#### B_MODEL

```text
tests/test_rw0_d2_model_handback.py
tests/test_rw0_d2_offline_integration.py
tests/test_section41_cognitive_proposal_row_values.py
tests/test_section41_cognitive_proposal_semantic_values.py
tests/test_section41_pre_execution_plan_disposition_contracts.py
tests/test_section41_pre_execution_plan_disposition_recovery.py
tests/test_section41_private_atomic_pre_execution_plan_disposition.py
tests/test_section41_private_pre_execution_plan_disposition_delegation.py
```

#### GUARDS

```text
tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_b2a_writer_session_contract.py
tests/test_b3a_persistence_contracts.py
tests/test_b3b2a_read_scope_and_query_contracts.py
tests/test_b3b2b_select_readers.py
tests/test_b3c4c_prerequisite_contract.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b2_development_reader_contracts.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_post_execution_pure_owner_boundaries.py
tests/test_post_execution_pure_owner_vectors.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_c2_private_value_versioning_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_sqlite_b1_runtime_boundary.py
tests/test_sqlite_b2c_writer_session.py
tests/test_sqlite_backend_b0_contract.py
```

FULL: no test-path argument for collection or execution. The existing repository
has 131 test modules; no new module is authorized. The following are FIXED OPENING
module identities and reported prior node identities/counts, not future target
counts. Measure and authenticate actual opening membership before source changes.

| Group | Modules | Prior nodes/passed | Fixed opening MODULE SHA-256 | Reported opening NODE SHA-256 |
|---|---:|---:|---|---|
| A0_D1 | 7 | 117 | `bd79dcd6261a545b90e3709e7bff2b16fa00d9fb71f67baa4082f71de6b75236` | `8ba8dc88ab588e3e12d56d8c3db542b08f04ddb1d1714a4e687e62697ab849ad` |
| BINDING_COMPAT | 7 | 160 | `0851123786b9bcbab0f2f417539ec3d1a0e6ffc753c4075e3d33b15e27dccd30` | `fddc0c493b032ecac479c59e6480a1f58c52759b8133f829795f6a82d8856806` |
| A_NATIVE | 11 | 118 | `07f8d2d3b7f971ab76b23f537de7985ed9e5388c5f5f69dc6d5d3b9d995fc22d` | `d5911062ec95a45b37662d236c0fb9af7374ccaee193da0a423f1f0019c3dfdd` |
| A_EVIDENCE | 5 | 659 | `d74195c30fd2f5c9e56591b2365651836ec7c982d0c1fe96da3f1fc26850b1ba` | `8c27f90a27da2fe62242f3bf3c368b2ce5792e102354c685bc8d99e1e19c35f2` |
| B_MODEL | 8 | 188 | `c4e8491566196799126a07839fd714357cc2576a3d3f4fd6b341f244cc9a5e05` | `22c8bac05f6006ceae1fa0867b4ea669978dfd0cfa2655eb1881827bfc73f406` |
| GUARDS | 24 | 4,162 | `4533bd1c1f6ee61c1e96847b3d6ce684af46046304ae9a6df28348eaace2b617` | `547c990efa2ac226f2316e0d3c276b6709afa0c4deb20493a1e3db2230b9260b` |
| FULL | 131 | 9,054 | `c60be07b4de88c1fceee2942a6dcae343645e1a7f9a2879ff0de57b4df596d46` | `4f16c9ad98b8a6377413ef77b062fd88ae0fdf31b8d686fb07bb51e8d6e8100b` |

The independent re-audit additionally collected the same 19 integration nodes
in its normal and both omission copies; its integration node SHA-256 was
`b9b6ee8aa1e6a934fbb11668082c0f67ead9c80a584a7b3b5c6e1a5d2b743902`.
That is prior independent focused evidence, not a full final-suite result.

Only B_MODEL contains the permitted amended test. A0_D1, BINDING_COMPAT, A_NATIVE,
A_EVIDENCE and GUARDS keep their exact module inventories. Recompute B_MODEL and
FULL inventories after the test changes; do not overwrite an expected old value
with an observation and call that authentication. All six still execute because
a production validator changes. Report the actual new counts, with this check:

```text
final full count = 9,054 + (final B_MODEL count - 188)
```

This is bookkeeping, not permission to remove cases. Opening group occurrences
were 5,404; unique union 5,402; only overlap two checked-C1 nodes in A_NATIVE and
A_EVIDENCE; full 9,054 contained the union and 3,652 others. Derive final overlaps
and full inclusion from complete node IDs, preserving spaces in parameter strings.

Inventory grammars, no prefix:
- MODULE: unique paths sorted by UTF-8 bytes, each u32be(path byte length) + path
  bytes + raw 32-byte SHA-256(module payload).
- NODE: deduplicated COMPLETE node IDs sorted by UTF-8 bytes, each u32be(ID byte
  length) + exact ID bytes. Do not split parameter strings on whitespace.

Only the three established Python 3.13 multithreaded-fork DeprecationWarnings in
unchanged tests/test_sqlite_b2c_writer_session.py are expected (normally GUARDS
and FULL):

```text
test_operation_guard_close_waits_and_retains_authority_until_exit
test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Inspect category, message, node and location; a count of three is not by itself
proof the expected warnings occurred. Record actual completion/exit status, not
progress marks. Driver mistakes may be corrected externally and affected gates
rerun with the distinction retained. No source edit after final validation without
reidentification and affected reruns. A new protected guard conflict is not
permission to refresh its hash or change its import set.

Before the expensive full run, complete tracked diff --check plus ALL 23 C-path
no-index whitespace checks; distinguish ordinary no-index difference status from
whitespace diagnostics. Check UTF-8, no BOM/CR/trailing spaces, selected final-LF
form, regular-file/modes and source/module/executable inventories. Preserve SQL,
catalog, public interfaces and every protected source exactly. Do not reapply
historical EOF fixes or regress fixed B2a/B3c4c/C10 successors.

## 7. Copy identity, preservation, evidence limits and closeout

Each external normal or controlled copy needs all 286 source endpoints recorded
BEFORE and AFTER use: path, type, Git/OS modes, byte count and full SHA-256. Retain
an exact intended delta for every defect copy, its target opening/mutant identity,
selected complete node IDs, positive/negative results and observed effects.
Use a disclosed raw source-copy grammar, for example:

```text
ASCII RW0-D2-STOP-REASON-REPAIR-V2 followed by NUL
for every source endpoint sorted by UTF-8 path bytes:
  u32be(path byte length) + path bytes + u32be(Git mode)
  + u64be(payload byte length) + exact payload
```

Record OS modes separately. This is a NEW grammar, not identical to V1 repair or
the auditor's different full-copy digest. Never claim to match a prior copy hash
under another framing. Identity is evidence of bytes, not program authority.

Before finalizing, re-read every one of the 263 baseline relationships and 70
candidate endpoints; reconstruct the complete FINAL replacement twice from fresh
raw reads using section 2's unchanged HEAD-relative grammar. Confirm exactly 47 M
and 23 C, no staged/unmerged/new path, no generated live artifact, 68 unchanged
candidate endpoints and 216 other tracked working files equal HEAD. Both permitted
paths remain C. Record their opening/final sizes, full SHA-256, modes and purpose.
The protected V1 checkpoint must remain 20,455 bytes with its exact supplied hash.

Preserve this SAME opening's HEAD/tree/parent/branch/upstream/worktree/index bytes
and metadata, guidance, cache directory and 37 members, and protected refs. Apply
section 3 to diagnostic observations and explicitly disclose every actual delta.
Do not claim all refs stayed unchanged when a qualified exception occurred. Do not
restore refs or update an expected manifest on an unexplained mismatch.

Keep the original opening record/helper until final comparisons are complete.
Then remove only positively owned external roots after every child is accounted
for; verify removal without further raw live Git. No destructor-owned cleanup,
unknown-process signal, blanket filesystem sweep or deletion of unrelated test
runs. A deliberately injected foreign run/Path remains owned by its own test and
must not be destroyed by validating an evidence wrapper.

No source repair is applied by ChatGPT in this handoff; the local implementation
writer performs the authorized changes. No independent acceptance occurs during
this repair. The latest independent audit completed subject/preservation, scoped
ref classification, 19 normal integration tests and J01/J02. It did NOT complete
A01-A11, remaining A12 custody and evidence work, A13/full semantic review, the six
independent final groups or independent FULL. Preserve those precise omissions.
The material reason-only specimen and the old all-ref deviation retain their
original provenance; a fresh interval does not erase them.

This task must not become a full A01-A13 audit or a proposal for new schemas or
policies. On an indispensable unlisted path or true representational/contract
conflict, stop and retain the explained partial repair. No rollback of all prior
D2 work and no bypass of an owner/guard are authorized. A passing test count or
source digest never supplies acceptance, authority, or permission to publish.

Return operative results INLINE, not another prompt, repository report, audit ZIP,
retained database, or new user-transport prerequisite:

1. Supported verdict and settings; current opening/closing and exact candidate
   authentication, ref classification/deltas and protected-surface preservation.
2. Source-derived status/reason-to-permitted-facts table with actual producer
   path:line and coverage for each existing family; genuine ambiguities retained.
3. Reproduction of the opening late-model reason-only substitution, positive
   early/late/ready outcomes, wrong-prefix variants and independent construction/
   consuming validation; actual database/process non-effects of substitutions.
4. Pure repair details, retained V1 authority-role and checkpoint revalidation,
   no schema/producer/custody/currentness or authority change, content-free errors.
5. R01 and J01/J02 exact final-copy deltas, identities, collections, selected
   complete node IDs and causal signals; masked predicates and trials labeled.
6. Both allowed endpoints' exact opening/final receipts and whether changed;
   full final 70-row table OR an unambiguous inherited-table confirmation plus
   both replacements; complete raw replacement length and SHA-256 reproduced twice.
7. Six focused and full commands/collections/results, module/node inventories,
   overlap/inclusion, structured warnings, corrections/skips and copy equality.
8. Exact cleanup and non-actions, followed by a concise continuation capsule
   identifying the newly repaired subject and the independent re-audit still needed.

Success token:
`RW0_D2_OFFLINE_EVIDENCE_COGNITIVE_REVIEW_REPAIRED_V2_VALIDATED_READY_FOR_REAUDIT`

It requires the bounded repair, direct and causal checks, complete final validation,
protected preservation and qualified resource/ref treatment. It enables only
consideration of a NEWLY ISSUED independent re-audit. No staging, commit, PR,
publication, migration, Section 41 post-execution recording, rank 15, physical C2,
live source/provider/supplier, ES/Bridge, deployment or RW0-E authority follows.

Other dispositions:
- `RW0_D2_REPAIR_PROVENANCE_BLOCKED`: opening/subject/protected preservation or
  safe ref classification not established; report expected/actual and retain work.
- `RW0_D2_STOP_REASON_REPAIR_REPLAN_REQUIRED`: exact unlisted owner/field/guard or
  actual contradiction prevents the selected two-file repair; no scope widening.
- `RW0_D2_STOP_REASON_REPAIR_VALIDATION_BLOCKED`: incomplete repair/causal/final
  validation/cleanup, with precise failed and unperformed work.

The repair writer does not return the independent ACCEPTED token. Completing
this one relation does not close the wider D2 assurance register.
