#!/bin/bash
# Read-only look at why the workload login failed on the Remote Alpha box.
# David runs in Terminal on his Mac:
#
#   bash ~/Downloads/es-vault-login-diagnose.sh
#
# It asks for nothing and changes nothing in Vault. It copies the reviewed
# check script to a temporary folder on the box, runs it once (a workload
# login that, if it succeeds, revokes its own token), prints only
# non-secret labels, and deletes both temporary folders. The whole output is
# safe to paste into the project thread.

set -u
BRANCH="claude/project-thread-vmre16"
BOX="[test box name withheld]"
PLAYGROUND="/Users/ds/Repositories/Playground"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
T="${PLAYGROUND}/es-vault-diagnose-${STAMP}"
B="/tmp/es-vault-diagnose-${STAMP}"
FILES="scripts/remote_alpha_vault_workload_auth_check.sh
scripts/internal/remote_alpha_vault_workload_auth_check.sh"
EXPECTED="fbea06973f0f184c3d9f4c4bd31e4bc507312e9163b883efab06d56defa826a8  scripts/remote_alpha_vault_workload_auth_check.sh
c6c077dd4bb249ce19deb7f0799b9b2706325791d94c666fb7a0124984b96b82  scripts/internal/remote_alpha_vault_workload_auth_check.sh"
BOX_FOLDER_MADE=no

step() { printf '\n===== %s (%s)\n' "$1" "$(date -u +%H:%M:%SZ)"; }
cleanup() {
  step "4. Clean up"
  if [ "${BOX_FOLDER_MADE}" = yes ]; then
    ssh "${BOX}" "rm -rf '${B}' && test ! -e '${B}' && echo 'box temp folder: gone'"
  fi
  rm -rf "${T}" && [ ! -e "${T}" ] && echo "Mac temp folder: gone"
}
stop() { printf '\nSTOPPED: %s\n' "$1"; cleanup; printf '\nRESULT: stopped. Paste this whole output into the project thread.\n'; exit 1; }

step "1. Get the check script"
mkdir -p "${T}" || stop "could not make ${T}"
ORIGIN="$(git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin 2>/dev/null || true)"
case "${ORIGIN}" in
  git@*|ssh://*) URL="git@github.com:evo-agi/Execution-Substrate.git" ;;
  *) URL="https://github.com/evo-agi/Execution-Substrate.git" ;;
esac
git clone --quiet --depth 1 --branch "${BRANCH}" "${URL}" "${T}/es" || stop "git clone failed"
GOT="$(cd "${T}/es" && shasum -a 256 ${FILES})"
echo "${GOT}"
[ "${GOT}" = "${EXPECTED}" ] || stop "the check files are not the reviewed ones (SHA-256 differs)"
ssh "${BOX}" "mkdir -m 700 '${B}' && mkdir -m 700 '${B}/scripts' '${B}/scripts/internal'" || stop "could not make ${B} on the box"
BOX_FOLDER_MADE=yes
scp -q "${T}/es/scripts/remote_alpha_vault_workload_auth_check.sh" "${BOX}:${B}/scripts/" || stop "copy failed"
scp -q "${T}/es/scripts/internal/remote_alpha_vault_workload_auth_check.sh" "${BOX}:${B}/scripts/internal/" || stop "copy failed"

step "2. Facts on the box (read-only)"
ssh "${BOX}" "ip -4 route get 172.17.0.1; ip -4 -br addr show docker0; echo 'earlier check summary:'; sudo -n python3 -I -" <<'PY'
import json, os
p = "/var/tmp/execution-substrate-remote-alpha/vault-workload-auth-summary.json"
if not os.path.exists(p):
    print("  none on the box")
else:
    s = json.load(open(p))
    a = s.get("auth_smoke", {})
    print("  checked_at:", s.get("checked_at"), "| smoke:", s.get("vault_workload_auth_smoke"))
    print("  " + json.dumps({k: v for k, v in a.items()}, sort_keys=True))
PY

step "3. Workload login check, once"
ssh "${BOX}" "sudo -n bash '${B}/scripts/remote_alpha_vault_workload_auth_check.sh' --summary-path '${B}/check-summary.json' >/dev/null 2>&1; echo check EXIT=\$?"
ssh "${BOX}" "sudo -n python3 -I - '${B}/check-summary.json'" <<'PY'
import json, os, sys
if not os.path.exists(sys.argv[1]):
    print("the check wrote no summary")
    raise SystemExit(0)
s = json.load(open(sys.argv[1]))
print("smoke:", s.get("vault_workload_auth_smoke"))
print("auth_smoke:", json.dumps(s.get("auth_smoke", {}), sort_keys=True))
v = s.get("vault", {})
print("vault:", json.dumps({k: v.get(k) for k in ("address", "role", "audience", "sealed", "token_ttl_seconds", "policy_names", "listener_addresses", "listener_scope_ok")}, sort_keys=True))
print("spire:", json.dumps(s.get("spire", {}), sort_keys=True))
print("workload:", json.dumps(s.get("workload", {}), sort_keys=True))
print("workload_zone_config:", json.dumps({k: s.get("workload_zone_config", {}).get(k) for k in ("validation_result", "validation_error", "address", "auth_role", "jwt_audience")}, sort_keys=True))
PY

cleanup
printf '\nRESULT: done. Paste this whole output into the project thread.\n'
