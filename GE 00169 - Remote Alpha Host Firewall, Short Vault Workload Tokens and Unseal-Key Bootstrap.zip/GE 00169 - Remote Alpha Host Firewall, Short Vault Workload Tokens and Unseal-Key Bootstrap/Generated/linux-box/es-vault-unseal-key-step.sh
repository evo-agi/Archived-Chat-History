#!/bin/bash
# Vault step for the Remote Alpha box, run by David in Terminal on his Mac:
#
#   bash ~/Downloads/es-vault-unseal-key-step.sh
#
# What it does, in order. It stops at the first unexpected result.
#  1. Gets the reviewed Vault helper from GitHub into a new folder under
#     Playground and checks its four files by SHA-256.
#  2. Reads Vault's state on the box (read-only). Nothing secret is read.
#  3. Copies the helper to a new folder in /tmp on the box.
#  4. Runs the helper. It asks for the Vault UNSEAL KEY (hidden input).
#     With that key it makes a root token, uses it once to make a token that
#     expires after 15 minutes, and revokes the root token at once. With the
#     short token it sets 15-minute workload logins that only work from the
#     Docker network, replaces the old Codex value with a random value
#     (all old versions deleted), and revokes the short token at the end.
#     Vault 2.x only allows making a root token without a token when its
#     configuration says so: if needed, the helper adds that one line to
#     /etc/vault.d/vault.hcl, reloads Vault (no restart, Vault stays
#     unsealed), and puts the file back exactly as it was right after the
#     root token is made.
#  5. Checks a real workload login (read-only check script).
#  6. Reads Vault's state again and compares.
#  7. Deletes both temporary folders (with the two non-secret summaries,
#     whose contents this output shows).
# No token, key or secret value is printed. The whole output is safe to
# paste into the project thread.

set -u
BRANCH="claude/project-thread-vmre16"
BOX="[test box name withheld]"
PLAYGROUND="/Users/ds/Repositories/Playground"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
T="${PLAYGROUND}/es-vault-step-${STAMP}"
B="/tmp/es-vault-step-${STAMP}"
FILES="scripts/remote_alpha_vault_workload_auth_bootstrap.sh
scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh
scripts/remote_alpha_vault_workload_auth_check.sh
scripts/internal/remote_alpha_vault_workload_auth_check.sh"
EXPECTED="7db4909d5ad89f450b0bfbe5a2f8ada7dd72ca7aeb5bacfc542f6ed9b4a8b141  scripts/remote_alpha_vault_workload_auth_bootstrap.sh
4adb7343472887e3d1e212ee0a939a196779d0944e5dd2a325a70954b1ff3c61  scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh
fbea06973f0f184c3d9f4c4bd31e4bc507312e9163b883efab06d56defa826a8  scripts/remote_alpha_vault_workload_auth_check.sh
c6c077dd4bb249ce19deb7f0799b9b2706325791d94c666fb7a0124984b96b82  scripts/internal/remote_alpha_vault_workload_auth_check.sh"
BOX_FOLDER_MADE=no

step() { printf '\n===== %s (%s)\n' "$1" "$(date -u +%H:%M:%SZ)"; }

cleanup() {
  step "7. Clean up"
  if [ "${BOX_FOLDER_MADE}" = yes ]; then
    ssh "${BOX}" "rm -rf '${B}' && test ! -e '${B}' && echo 'box temp folder: gone'"
  fi
  rm -rf "${T}" && [ ! -e "${T}" ] && echo "Mac temp folder: gone"
  [ -d "${PLAYGROUND}" ] && echo "Playground: still there"
}

stop() {
  printf '\nSTOPPED: %s\n' "$1"
  cleanup
  printf '\nRESULT: stopped. Paste this whole output into the project thread.\n'
  exit 1
}

# Read-only state of Vault on the box. Prints facts and one PRECHECK line.
box_vault_state() {
  ssh "${BOX}" 'sudo -n python3 -I -' <<'PY'
import hashlib, json, os, re, ssl, subprocess, urllib.error, urllib.request
cfg = json.load(open("/etc/execution-substrate/vault/workload-zone-vault-config.json"))["vault_config"]
pem = (cfg.get("ca_bundle_pem") or "").strip()
ctx = ssl.create_default_context(cadata=pem) if pem else ssl.create_default_context()
def get(path):
    try:
        with urllib.request.urlopen(cfg["address"].rstrip("/") + "/v1/" + path, context=ctx, timeout=10) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, {}
problems = []
code, seal = get("sys/seal-status")
print(f"vault: HTTP {code}, sealed={seal.get('sealed')}, version={seal.get('version')}, key shares={seal.get('n')}, threshold={seal.get('t')}")
if seal.get("sealed") is not False:
    problems.append("Vault is not unsealed")
if seal.get("n") != 1 or seal.get("t") != 1:
    problems.append("Vault does not use exactly one key share")
code, _ = get("sys/generate-root/attempt")
print(f"vault generate-root without a token: HTTP {code} ({'allowed' if code == 200 else 'refused' if code == 403 else 'unexpected'})")
if code not in (200, 403):
    problems.append("unexpected answer from sys/generate-root/attempt")
show = subprocess.run(["systemctl", "show", "-p", "ExecStart", "-p", "ExecReload", "vault.service"], capture_output=True, text=True).stdout
start = next((l for l in show.splitlines() if l.startswith("ExecStart=")), "")
reload_line = next((l for l in show.splitlines() if l.startswith("ExecReload=")), "")
m = re.search(r"-config[= ](\S+)", start)
config = m.group(1) if m else "NOT FOUND"
print(f"vault.service config file: {config}")
print(f"vault.service reload sends HUP: {'yes' if 'HUP' in reload_line else 'no'}")
if code == 403 and (config != "/etc/vault.d/vault.hcl" or "HUP" not in reload_line):
    problems.append("Vault refuses generate-root without a token and its config file or reload is not the expected one")
p = "/etc/vault.d/vault.hcl"
raw = open(p, "rb").read()
st = os.stat(p)
mentions = b"enable_unauthenticated_access" in raw
print(f"{p}: sha256 {hashlib.sha256(raw).hexdigest()}, owner {st.st_uid}:{st.st_gid}, mode {oct(st.st_mode & 0o7777)}, mentions enable_unauthenticated_access: {'yes' if mentions else 'no'}")
if mentions:
    problems.append("vault.hcl already mentions enable_unauthenticated_access")
print("PRECHECK OK" if not problems else "PRECHECK STOP: " + "; ".join(problems))
PY
}

step "1. Get the helper"
mkdir -p "${T}" || stop "could not make ${T}"
ORIGIN="$(git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin 2>/dev/null || true)"
case "${ORIGIN}" in
  git@*|ssh://*) URL="git@github.com:evo-agi/Execution-Substrate.git" ;;
  *) URL="https://github.com/evo-agi/Execution-Substrate.git" ;;
esac
echo "clone from: ${URL}"
git clone --quiet --depth 1 --branch "${BRANCH}" "${URL}" "${T}/es" || stop "git clone failed"
git -C "${T}/es" log --oneline -1
GOT="$(cd "${T}/es" && shasum -a 256 ${FILES})"
echo "${GOT}"
[ "${GOT}" = "${EXPECTED}" ] || stop "the helper files are not the reviewed ones (SHA-256 differs)"
echo "all four SHA-256 match"

step "2. Vault on the box before (read-only)"
BEFORE="$(box_vault_state)" || stop "could not read Vault's state on the box"
echo "${BEFORE}"
printf '%s\n' "${BEFORE}" | /usr/bin/grep -q '^PRECHECK OK$' || stop "a check before the change failed (see the PRECHECK line)"

step "3. Copy the helper to the box"
ssh "${BOX}" "mkdir -m 700 '${B}' && mkdir -m 700 '${B}/scripts' '${B}/scripts/internal'" || stop "could not make ${B} on the box"
BOX_FOLDER_MADE=yes
scp -q "${T}/es/scripts/remote_alpha_vault_workload_auth_bootstrap.sh" "${T}/es/scripts/remote_alpha_vault_workload_auth_check.sh" "${BOX}:${B}/scripts/" || stop "copy failed"
scp -q "${T}/es/scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh" "${T}/es/scripts/internal/remote_alpha_vault_workload_auth_check.sh" "${BOX}:${B}/scripts/internal/" || stop "copy failed"
ONBOX="$(ssh "${BOX}" "cd '${B}' && sha256sum ${FILES//$'\n'/ }")"
echo "${ONBOX}"
[ "${ONBOX}" = "${EXPECTED}" ] || stop "the copies on the box differ"

step "4. Configure Vault with your unseal key"
echo "The box now asks for the Vault UNSEAL KEY. Paste it and press Enter."
echo "Nothing appears while you paste. It is used only on the box and never shown or saved."
ssh -tt "${BOX}" "sudo -n env REMOTE_ALPHA_BOOTSTRAP_SUMMARY_PATH='${B}/bootstrap-summary.json' REMOTE_ALPHA_BOOTSTRAP_AUTHORITY=unseal-key REMOTE_ALPHA_BOOTSTRAP_PROOF_VALUE=generate REMOTE_ALPHA_BOOTSTRAP_GENERATE_ROOT_ACCESS=temporary-config bash '${B}/scripts/remote_alpha_vault_workload_auth_bootstrap.sh'"
HELPER_EXIT=$?
echo "helper EXIT=${HELPER_EXIT}"
ssh "${BOX}" "sudo -n python3 -I - '${B}/bootstrap-summary.json'" <<'PY'
import json, os, sys
if not os.path.exists(sys.argv[1]):
    print("the helper wrote no summary")
    raise SystemExit(0)
s = json.load(open(sys.argv[1]))
print("summary overall_status:", s.get("overall_status"), "| failure:", s.get("failure_phase"), s.get("failure_class"), s.get("failure_message_class"))
for name, op in sorted(s.get("operations", {}).items()):
    extra = {k: v for k, v in op.items() if k in ("token_ttl", "token_max_ttl", "token_bound_cidrs", "vault_allows_generate_root_without_token", "file_restored_byte_for_byte", "vault_reloaded", "vault_refuses_generate_root_without_token_again", "prompt_source", "error_classification")}
    print(f"  {name}: {op.get('status')} {json.dumps(extra, sort_keys=True) if extra else ''}")
PY

step "5. Real workload login (read-only check)"
if [ "${HELPER_EXIT}" = 0 ]; then
  ssh "${BOX}" "sudo -n bash '${B}/scripts/remote_alpha_vault_workload_auth_check.sh' --summary-path '${B}/check-summary.json' >/dev/null 2>&1; echo check EXIT=\$?"
  ssh "${BOX}" "sudo -n python3 -I - '${B}/check-summary.json'" <<'PY'
import json, os, sys
if not os.path.exists(sys.argv[1]):
    print("the check wrote no summary")
    raise SystemExit(0)
s = json.load(open(sys.argv[1]))
a = s.get("auth_smoke", {})
v = s.get("vault", {})
p = s.get("proof_runtime_secret", {})
print("workload auth smoke:", s.get("vault_workload_auth_smoke"))
print("  jwt fetch:", a.get("jwt_fetch"), "| vault login:", a.get("vault_login"), "| token lookup:", a.get("token_lookup"), "| proof read:", a.get("proof_read"), "| token revoked:", a.get("token_revoked"))
print("  workload token ttl seconds:", v.get("token_ttl_seconds"), "| policies:", v.get("policy_names"), "| sealed:", v.get("sealed"))
print("  runtime profile value present:", p.get("field_present"), "| non-empty:", p.get("field_nonempty"))
PY
else
  echo "skipped: the helper did not finish"
fi

step "6. Vault on the box after (read-only)"
AFTER="$(box_vault_state)"
echo "${AFTER}"
B_HCL="$(printf '%s\n' "${BEFORE}" | /usr/bin/grep '^/etc/vault.d/vault.hcl:')"
A_HCL="$(printf '%s\n' "${AFTER}" | /usr/bin/grep '^/etc/vault.d/vault.hcl:')"
B_GR="$(printf '%s\n' "${BEFORE}" | /usr/bin/grep '^vault generate-root without a token:')"
A_GR="$(printf '%s\n' "${AFTER}" | /usr/bin/grep '^vault generate-root without a token:')"
[ "${B_HCL}" = "${A_HCL}" ] && echo "vault.hcl: identical to before (sha256, owner, mode)" || echo "vault.hcl: DIFFERS from before"
[ "${B_GR}" = "${A_GR}" ] && echo "generate-root without a token: same as before" || echo "generate-root without a token: DIFFERS from before"
printf '%s\n' "${AFTER}" | /usr/bin/grep -q 'sealed=False' && echo "Vault: still unsealed" || echo "Vault: NOT unsealed now (unseal it as usual: vault operator unseal)"

cleanup
if [ "${HELPER_EXIT}" = 0 ]; then
  printf '\nRESULT: done. Paste this whole output into the project thread.\n'
else
  printf '\nRESULT: the helper failed (EXIT=%s). Paste this whole output into the project thread.\n' "${HELPER_EXIT}"
fi
