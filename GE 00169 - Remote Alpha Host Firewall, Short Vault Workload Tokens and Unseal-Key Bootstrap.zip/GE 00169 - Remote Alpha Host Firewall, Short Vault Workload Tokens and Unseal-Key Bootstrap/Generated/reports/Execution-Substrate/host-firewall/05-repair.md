# 05 — Repair of ES draft PR #35 after the 04 re-audit (BLOCK on R1)

Writer: the PR #35 writer thread. Date: 2026-11-23.
Target for the narrow re-audit: head `6a9d4c742941beeaeca1dc417b6713c18ae9360f` on `claude/project-thread-vmre16`, base trunk_dev `0aa4a2b`, manifest `dc5b53b74e59e1146a8819101cbc46fb06e9e7195926c9c0f30322033d2c1297`.

## Plain summary (for relaying)

R1 is fixed as the re-audit proposed. The bridge table now drops every frame that goes from one bridge port to another, so VLAN-tagged frames and forged ARP replies between containers are stopped too. The re-audit's extended real-kernel test is in and passes.

Three things go with it:

- **A setting is retired.** With the drop-all rule, `CONTAINER_BRIDGE_SUBNETS` no longer decides anything. The re-audit's diff kept it for the bridge check, but that check would then have printed "NOT isolated at layer 2" for a container bridge outside the list, which is no longer true. So the setting is gone, the check only requires the Vault address to be on a container interface, and a settings file that still names the setting is refused as unknown. The box's settings file does not name it.
- **R2 (should-fix) is done.** `--status` repeats the bridge and container-IPv6 checks and fails when a later host change breaks them.
- **The marker tests are in.** An `--apply` that stops before loading leaves no `unconfirmed` marker: when the timer cannot be armed (A6), when it is not active after arming, and when nft refuses the ruleset (A7).

trunk_dev `0aa4a2b` is merged with no conflict; it touches none of the PR's files. All 14 mutants aimed at the new code are killed, and the changed suites pass as root, unprivileged and with PR #30's narrow root PATH. Nothing was run on the box. Run 4 still waits for the red-team.

## 1. Target

| Item | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| PR | #35 (draft), branch `claude/project-thread-vmre16` |
| Re-audited head | `27e8b64631cf5426774fdbeb198886abe0348aa1` (04 re-audit, BLOCK on R1) |
| Repair commit | `bf771af79eb38879fa61fed0b5c104c2b5dd910a`, one commit on top of 27e8b64 |
| Head | `6a9d4c742941beeaeca1dc417b6713c18ae9360f` (bf771af with trunk_dev 0aa4a2b merged, no conflict), tree `7cf3383c82cc325a9333bf90baef85c5249a83ca` |
| Base | `trunk_dev` `0aa4a2b5d8e93a10f65b3bb724b286ee79a0aa7e` |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified) |
| Manifest SHA-256 (head vs base) | `dc5b53b74e59e1146a8819101cbc46fb06e9e7195926c9c0f30322033d2c1297` (taken twice in a fresh clone of the pushed head, HEAD reset to the base, upstream pinned; identical) |
| textual_diff_sha256 | `172987d7c737ab582b8983660def3faac530240596583e57475f833ea19ace12` |
| Changed paths vs base | 12 (the same 12 as before) |
| Delta for the narrow re-audit | `git diff 27e8b64 bf771af`: 5 files, +228 −105 (`05-repair-evidence/repair.diff`) |
| Beyond the 04 fix diff | `05-repair-evidence/beyond-04-fix.diff`: the repair commit compared with 27e8b64 plus `04-re-audit-fix.diff`, 5 files, +158 −59 |

The merge commit brings in #36 (README) and #33 (`es/config` tests). It overlaps none of the PR's paths. `git merge-tree --write-tree bf771af 0aa4a2b` gives the head tree, and the PR's diff against its base is the same before and after the merge with index lines and hunk positions dropped (`merge-check.txt`). So the merge needs a provenance check only.

## 2. Findings, one by one

### R1 (medium): VLAN-tagged frames and ARP between containers

Applied `04-re-audit-fix.diff` as it stands, after review:

- `remote_alpha_host_firewall.py` renders one rule in the bridge `forward` chain: `counter name "container_to_container" drop`. The comment says why.
- The golden file, the invariants pin, the doc bullet and its pin, and the validation sentence and its pin are as in the diff.
- `TestRemoteAlphaHostFirewallRealKernelBridgeIsolation` now also sends VLAN-0-tagged IPv4 and IPv6 frames and an ARP reply that claims the gateway. It counts distinct frames by id: `ipv4=3 ipv6=3 tagged=6 arp=3` without the firewall, `ipv4=0 ipv6=0 tagged=0 arp=0` with it, and the counter at 15.

Review notes:

- **What the rule can break.** Only traffic from one bridge port to another. Frames to the bridge itself (Vault on 172.17.0.1, DNS and the internet through the host) are local delivery, and the real-kernel tests show they still work. A container's broadcast ARP request for the gateway is still delivered to the host; only the flood copy to the other ports is dropped. On the box, run 1 already blocked container-to-container IPv4 in the inet chain (br_netfilter is active there) and every service stayed healthy, so nothing on the box depends on traffic between containers.
- **Stale test comment.** The diff left the invariants comment describing the old IPv4/IPv6 rules. It now describes the single drop rule.

Beyond the diff, on purpose:

- **`CONTAINER_BRIDGE_SUBNETS` is retired.** The diff kept it because the bridge check used it. But with the drop-all rule the list no longer decides isolation, and the check would have printed "NOT isolated at layer 2 (inet forward rule only, needs br_netfilter)" for a container bridge outside the list, which is false (`TestRemoteAlphaHostFirewallBridgeCheck` even pinned that line for `br-abc123`).
  - The setting is gone from the defaults, the exported names, the settings-file names, the rendered header and the `--plan` summary.
  - `bridge-check` now reports every container interface as isolated and refuses (exit 7) only when the Vault address is missing or on an interface that is not a container interface. The `--plan`/`--apply` check line is now "the Vault address is on a container interface".
  - A settings file that still names `CONTAINER_BRIDGE_SUBNETS` is refused as an unknown setting, with the list of allowed names. The box's settings file does not name it (it holds `SERVICE_CALLERS`, `SSH_SOURCES`, `SSH_PASSWORD_SOURCES`, `ACCEPT_BLOCKED_LISTENERS` and `PROBE_IMAGE`). A code search over the organisation's default branches finds the name nowhere else.
  - Tests: the bridge-check test expects `br-abc123` to be reported as isolated and no "NOT isolated" line, and refuses when `CONTAINER_INTERFACES` leaves out `docker0`; the settings-file test refuses the retired name; the settings-validation case for the setting is gone.
- The `bridges` command's message and docstring now say the bridge table drops every frame between the ports of a bridge that is not a container interface.

### R2 (observation, should-fix): host checks only at --plan and --apply

Done. `--status` now runs the bridge check and the container-IPv6 check after the unit check:

- it prints `every bridge is a container interface: pass/FAIL` and `no container interface has IPv6: pass/FAIL`, with the details on a FAIL;
- a FAIL makes the exit 1 (unless an apply is pending, exit 3), and the result line reads `RESULT: not installed, changed, or a host check failed`;
- `--status` now needs `ip`, like `--plan` and `--apply`.

`--help` and the doc's `--status` bullet say so, and a new "Known limits" bullet explains what a bridge created later loses and how to fix it. The fakes test now checks the two pass lines on a clean status and, with a `virbr0` bridge or a `docker0` IPv6 address appearing after confirm, the FAIL line, the details and exit 1.

### Mutant survivors A6 and A7 (and the third early exit)

New `TestRemoteAlphaHostFirewallApplyFailuresLeaveNoUnconfirmedMarker`, with three fakes cases:

- `timer_cannot_be_armed`: `systemd-run` fails (A6);
- `timer_not_active_after_arming`: `systemd-run` succeeds but no timer waits, the other exit path between writing the marker and loading;
- `nft_refuses_the_ruleset`: `nft -f` refuses the candidate (A7).

Each checks the exit and message, that the marker is gone, that nothing is loaded and no drop-in installed, for the nft case that the armed timer is stopped, and that the next `--plan` passes "no earlier apply awaiting confirm". The fakes gained three switches for this (`FAKE_SYSTEMD_RUN_FAIL`, `FAKE_SYSTEMD_RUN_NO_TIMER`, `FAKE_NFT_LOAD_FAIL`).

### A5 and R3

- A5 (generate-root's `except BaseException` not cancelling a started attempt): not tested. As the re-audit says, it is equivalent at the only call site, which runs inside the signal mask, and the re-audit asked for no test.
- R3 (`STANDING_ROOT_TOKENS=revoke` revokes every non-expiring root token): unchanged, acceptable as documented.

## 3. Mutants

Script: `05-repair-evidence/mutants5.py` (same method as round 3: one exact replacement, `-test.failfast`, file restored byte for byte, checksums compared before and after). Log: `mutants5.log`.

| Mutant | Result | First failing test |
|---|---|---|
| P1 the two old bridge rules (as at 27e8b64) | killed | `TestRemoteAlphaHostFirewallRulesetInvariants` |
| P1b the same, real-kernel tests only | killed | `TestRemoteAlphaHostFirewallRealKernelBridgeIsolation` |
| P2 `ether type { ip, ip6, arp }` drop (VLAN passes), real-kernel only | killed | `TestRemoteAlphaHostFirewallRealKernelBridgeIsolation` |
| P3 `ether type { ip, ip6, vlan }` drop (ARP passes), real-kernel only | killed | `TestRemoteAlphaHostFirewallRealKernelBridgeIsolation` |
| P4 bridge rule removed | killed | `TestRemoteAlphaHostFirewallRulesetInvariants` |
| P5 Vault on a non-container interface accepted | killed | `TestRemoteAlphaHostFirewallBridgeCheck` |
| P6 retired setting allowed in the settings file again | killed | `TestRemoteAlphaHostFirewallSettingsFile` |
| P7 `--status` ignores other bridges | killed | `TestRemoteAlphaHostFirewallApplyConfirmRollbackOrderWithFakes` |
| P8 `--status` ignores container IPv6 | killed | `TestRemoteAlphaHostFirewallApplyConfirmRollbackOrderWithFakes` |
| P9 a failed host check does not change the `--status` exit | killed | `TestRemoteAlphaHostFirewallApplyConfirmRollbackOrderWithFakes` |
| P10 marker left when the timer cannot be armed (A6) | killed | `TestRemoteAlphaHostFirewallApplyFailuresLeaveNoUnconfirmedMarker` |
| P11 marker left when the timer is not active | killed | `TestRemoteAlphaHostFirewallApplyFailuresLeaveNoUnconfirmedMarker` |
| P12 marker left when nft refuses the ruleset (A7) | killed | `TestRemoteAlphaHostFirewallApplyFailuresLeaveNoUnconfirmedMarker` |
| P13 timer not stopped when nft refuses the ruleset | killed | `TestRemoteAlphaHostFirewallApplyFailuresLeaveNoUnconfirmedMarker` |

Result: 14 of 14 killed. P1b, P2 and P3 show the real-kernel test catches the behaviour, not only the rendered text: each partial rule lets one kind of frame through.

## 4. Validation

All runs are on the exact head bytes (6a9d4c7; the script checks that the tree did not change during the runs). Logs are in `05-repair-evidence/validation/`.

| Run | Result | Log |
|---|---|---|
| Root: `TestRemoteAlphaHostFirewall*` and `TestRemoteAlphaVaultWorkloadAuthBootstrap*`, real kernel, real sshd, Vault 2.2.2 on PATH | 122 pass, 0 fail, 5 skip | `root-targeted-6a9d4c7.log` |
| PR #30's root step (`sudo -n -- /usr/bin/env -i PATH=/usr/bin:/bin`), the four root-only tests | 4 pass, 0 fail, 2 skip | `pr30-path-6a9d4c7.log` |
| Unprivileged (uid 65534), the same suites, Vault on PATH | 120 pass, 0 fail, 5 skip | `unpriv-targeted-6a9d4c7.log` |
| Unprivileged, the whole root package minus the 11 environment-only entries, Vault on PATH | 2144 pass, 157 fail in 10 top-level tests, 5 skip | `unpriv-root-package-6a9d4c7.log`, `failing-6a9d4c7.txt` |

- Root skips: the three IPv6 lab subtests (no IPv6 kernel here) and the two bootstrap tests that skip themselves as root. Unprivileged skips: the four root-only tests (listed `skips-itself`) and the IPv6 subtest of the source check.
- Both real-Vault tests ran and passed unprivileged, in the targeted run and in the whole-package run.
- The 157 failures are exactly the set of the round-3 run on 27e8b64, which matched base fdfa3bc in this container (03 report, section 4): `failing-6a9d4c7.txt` equals `03-repair-evidence/validation/failing-27e8b64.txt`. None is a test of this PR.
- Mutants: 14 of 14 (section 3).
- Static checks: gofmt on the changed Go file, `go vet` for linux and `GOOS=darwin`, `bash -n`, `py_compile` (its `__pycache__` removed), no untracked files.
- A token-pattern scan of the evidence finds only fixture strings of other tests in the whole-package log (`hvs.abcdefghijklmnopqrstuvwxyz` and the like).
- CI "build, vet and test" on 6a9d4c7: success (run 45286107678, 23:08 to 23:48 UTC), including the CI gate's skips-itself check, so both real-Vault tests ran on the runner too.

## 5. Box

The box was not touched. Box run 4 still waits for the red-team. It now also brings the drop-all bridge rule and the status checks to the box: `--plan`, `--apply`, `--confirm`, `--status`, `--probe`, then the workload-auth check. `--status` on the box reports "current settings: do not render the installed ruleset" until then.

## 6. Remaining uncertainty

- The box's `bridge-nf-filter-vlan-tagged` value and whether Nomad tasks there have `NET_RAW` (both from the re-audit). The drop-all rule makes both irrelevant for traffic between containers.
- The IPv6 lab subtests still have never run here (no IPv6 kernel). First run: the CI runner, through #30's root step.
- The PR #39 sync, when it happens, moves real test bytes and needs its own delta check (as the re-audit says).

## 7. Effects

- Two commits pushed to `claude/project-thread-vmre16`: the repair bf771af and the trunk_dev merge 6a9d4c7.
- PR #35 description updated.
- Report and evidence written under this folder.
- No PR comment and no merge. The box was not contacted.
