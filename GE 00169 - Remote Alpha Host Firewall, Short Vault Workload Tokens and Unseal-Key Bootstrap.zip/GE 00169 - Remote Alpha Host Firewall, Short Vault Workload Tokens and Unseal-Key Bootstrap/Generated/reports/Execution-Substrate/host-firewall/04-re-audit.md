# 04 — Narrow re-audit of ES draft PR #35 after the repair (head 27e8b64)

Writer of this report: the PR #35 audit thread (read-only). Date: 2026-11-23, about 23:00Z.
Verdict: **BLOCK** (see the end). One new medium finding; everything the 02 audit asked for is fixed.

## Plain summary (for relaying)

The repair fixes everything the first audit raised, and the two changes that go beyond my suggested diff are improvements. Revoking the root token before the reload means a SIGKILL during the restore now leaves only the 15-minute token, and the next run refuses before it asks for the key (tested against a real Vault). The new tests catch every mutant that slipped through before.

I still block the PR for one problem. My own F3 fix suggestion missed it, and so did the repair.

- **R1 (medium):** the layer-2 rule between containers still lets frames through:
  - frames with an 802.1Q priority tag (VLAN 0), which the receiving kernel delivers like any other frame;
  - forged ARP replies.

  This holds on the box too, where `br_netfilter` is active. A container that can send raw frames can:
  - deliver one-way UDP to another container's services;
  - convince another container that it is the gateway, and then read that container's outgoing internet and DNS traffic.

  The fix is one rule: drop every frame from one bridge port to another. I tested it, including an extended test that fails on the current head.

Two more points:

- trunk_dev has since moved to 0aa4a2b (README and `es/config` test changes only), which merges cleanly.
- A later sync with PR #39, which moves root script tests into `scripts/`, will change real files. It needs a delta check, not just a provenance check.

Nothing was pushed or posted, and the box was not touched.

---

```text
INDEPENDENT AUDIT REPORT (narrow re-audit)
```

## 1. Target

| Item | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate, draft PR #35, branch `claude/project-thread-vmre16` |
| Head | `27e8b64631cf5426774fdbeb198886abe0348aa1`, tree `09b2e7e4d4bea761fb5c97e8c50c09fd73b72ceb` |
| Repair commit | `10bfe9b0ae8ec0d27087a07b51484a345e5442e8` (parent `0c95eb7`) |
| Merge commit | `27e8b64` = `10bfe9b` + trunk_dev `fdfa3bc` (#29) |
| Base | `fdfa3bc67cdedb11f583a19df7036c20c612741f` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (my copy and the one in `operating-protocol/tools/` both match the pinned value) |
| Manifest SHA-256 | `912de42517c13fb535fe0f07b3fca0f079ef8573f577eb67e0ff4e9cb266ec39`, reproduced (section 3) |
| textual_diff_sha256 | `f2a54f6e461f718365b8a7cbc778a8a2ddc29d882d46dae9316dd14c98e43aff` |
| Changed paths vs base | 12 (the same 12 as in the 02 audit) |
| Delta read | `git diff 0c95eb7 10bfe9b`: 10 files, +1321 −144. SHA-256 of the diff `f0ae58ad…0181`, equal to the writer's `03-repair-evidence/repair.diff` |
| Writer's report | `03-repair.md`, delivered with manifests and evidence (closes F12) |
| Remote state at 22:55Z | PR head `27e8b64`, trunk_dev `0aa4a2b` |

## 2. Posture and effects

- Read-only, done by the parent thread alone.
- Private clones under `/opt/audit/`:
  - `ES4`: the audit tree at 27e8b64, HEAD reset to fdfa3bc.
  - `ES5`: a scratch copy at 27e8b64 for the candidate fix and the probes.
- Probe files were compiled only in `ES5` and removed after each build.
- No commit, push, comment, PR change or merge. The box was not contacted.
- Shared-folder writes: this report, `04-re-audit-fix.diff` and `04-re-audit-evidence/`.

## 3. Provenance

- Fresh clone with `umask 022`.
- `git checkout -B claude/project-thread-vmre16 27e8b64`, then `git reset --mixed fdfa3bc`, with upstream set to `origin/trunk_dev`. The recipe records the upstream by name only, so trunk_dev's later move does not matter.
- The recipe ran twice and produced identical outputs: manifest `912de425…ec39`, 12 files, the value the writer reported.
- Closing manifest after all audit work: see section 10.

**Merge commit 27e8b64, checked for provenance only, as briefed:**

| Check | Result |
|---|---|
| Parents | `10bfe9b`, `fdfa3bc`. `fdfa3bc` is an ancestor of the current trunk_dev |
| Tree | `git merge-tree --write-tree 10bfe9b fdfa3bc` gives `09b2e7e4…`, equal to the head tree, so the merge is clean with no hand edits |
| Overlap | trunk_dev `76c030f..fdfa3bc` changed 29 paths. Only `PLANS.md` is among the PR's paths, and the other 11 PR paths are byte-identical to `10bfe9b` |
| PR diff across the merge | `git diff 76c030f 10bfe9b` and `git diff fdfa3bc 27e8b64` are identical once `index` and `@@` lines are dropped; the PLANS.md hunk is identical too. This matches the writer's `merge-check.txt` |
| CI on 27e8b64 | run 45271110605 (`go`): completed, `success`, 21:34–22:07Z (read through the GitHub API) |

**trunk_dev since then.** It is now `0aa4a2b` (re-checked at 22:55Z), after two commits:

- `400ff7f` (#36, README rewrite, 1 file);
- `0aa4a2b` (#33, `es/config` tests, 2 files).

None of these 3 files overlaps the PR. A trial `git merge-tree 27e8b64 0aa4a2b` is clean (`dad8b4fa…`).

PR #39 has not landed on trunk_dev yet. If it moves root script tests into `scripts/`, the sync that follows will have to move or adapt PR #35's root-package tests (`remote_alpha_host_firewall_test.go` and the two bootstrap test files). That is a change of real bytes, so it needs a delta check and a fresh manifest, not provenance only.

## 4. Coverage

**Read in full:**

- the repair delta of both scripts (`remote_alpha_host_firewall.sh` and `.py`), the bootstrap helper, the golden ruleset and the CI list;
- the doc and PLANS.md changes;
- the new and changed tests, as far as the findings and mutants needed.

**Checked against the 02 audit's tested diff:**

- F2, F4 and F5 hunks are identical to `02-audit-fix.diff`.
- F3's IPv4 rule is identical to the diff, plus the new IPv6 rule.
- F1 keeps the diff's mechanism (mask, handlers, catch), with the changes listed in section 5.

**Not re-run:**

- The writer's whole-root-package unprivileged comparison: 157 failures in 10 tests, the same on base and head.
- The box.
- The IPv6 lab, because the kernel here has no IPv6.

## 5. Findings

### R1: The bridge table still passes VLAN-tagged frames and ARP between containers, br_netfilter active or not

```text
AUDIT FINDING
ID / Type / Severity: R1 / security risk + contract drift / medium
```

**Current contract.** Doc lines 6659–6667 say containers "cannot reach each other at layer 2, whatever the `br_netfilter` state and whatever source address a container writes …, and no IPv6 frame passes from one bridge port to another". The same sentence is pinned at `remote_alpha_host_firewall_test.go:2082`.

**Path and line (repo-validated, 27e8b64).** `remote_alpha_host_firewall.py:459–464` renders:

```
ether type ip ip daddr {subnet} counter name "container_to_container" drop
ether type ip6 counter name "container_to_container" drop
```

Everything else in the bridge `forward` chain is accepted (`policy accept`).

**Why frames get through:**

- nft reads `ether type` as the outer type. A frame carrying an 802.1Q tag shows `8021q`, so neither rule matches it, whatever it carries inside.
- The receiving container's kernel strips a VLAN-0 (priority) tag and delivers the inner IPv4 or IPv6 packet as if the frame were untagged.
- ARP (`0x0806`) is not matched at all.
- With `br_netfilter` active, as on the box, the inet rules do not see these frames either. `bridge-nf-filter-vlan-tagged` defaults to 0, so tagged frames skip them, and ARP is not IP.

**Evidence (lab-validated).** The probe is `04-re-audit-evidence/probes/bridgeprobe.sh` with `frames.py`; the log is `logs/bridgeprobe-2.log`. It uses a minimal netns lab (docker0 with two containers) and loads the PR's golden ruleset at 27e8b64. Frames are sent with AF_PACKET from c1, and the count is what reached the other container's eth0.

| Frame | br_netfilter off | br_netfilter on (as on the box) |
|---|---|---|
| IPv4 to c2, untagged | 0/3 | 0/3 |
| IPv4 to c2, VLAN-0 tag | **arrived** | **arrived**, and c2's UDP socket on `0.0.0.0:9999` received it from `172.17.0.2` |
| IPv4 to 255.255.255.255, unicast to c2's MAC | arrived (c2's socket: not tested with calls off) | 0/3 (inet drops it) |
| IPv6, untagged | 0/3 | 0/3 |
| IPv6, VLAN-0 tag | **arrived** | **arrived** |
| ARP reply "172.17.0.1 is at c1's MAC", to c2 | **arrived** | **arrived**. c2's neighbour entry for the gateway changed to c1's MAC |
| c2's normal UDP to 203.0.113.10:53 after that spoofed reply | — | **seen by c1** (`c2-outbound-secret=1`) |

**Impact:**

- A container that can write raw frames (`CAP_NET_RAW`) can:
  - deliver one-way UDP, with a real or forged source, to any UDP service of another container on the same bridge (replies, being untagged, are dropped);
  - poison another container's gateway entry and read its outgoing non-subnet traffic: internet and DNS to [home network address withheld];
  - cut another container off from Vault (frames to 172.17.0.1 are then sent to the attacker and dropped).
- Two-way connections between containers are still blocked.
- It applies to the box as it runs today: the run-3 ruleset has the older, weaker rule and `br_netfilter` is active. Inference: the box has the default `bridge-nf-filter-vlan-tagged=0` (not checked; the box was not touched).
- Exposure needs two containers on the same bridge, one of them hostile with `CAP_NET_RAW`:
  - Docker's default capabilities include `NET_RAW`.
  - Inference: Nomad's Docker driver leaves `NET_RAW` out by default, so Nomad-run tasks may not have it. Not checked.

**Required correction (tested, `04-re-audit-fix.diff`, applies to 27e8b64).**

- Render a single rule in the bridge `forward` chain: `counter name "container_to_container" drop`. That drops every frame from one bridge port to another: IPv4 whatever its addresses, IPv6, VLAN-tagged, ARP.
  - This keeps the existing scope: every bridge, with `--apply` refusing other bridges.
  - The bridge `forward` hook carries only port-to-port frames, so traffic to and from the host and the gateway is untouched.
  - `CONTAINER_BRIDGE_SUBNETS` stays, because `bridge-check` still uses it.
- Update the golden file, the invariants pin, the doc bullet and its pin to say "no frame passes from one bridge port to another (IPv4 whatever its addresses, IPv6, VLAN-tagged frames, ARP)".
- Extend `TestRemoteAlphaHostFirewallRealKernelBridgeIsolation`:
  - the sender adds VLAN-0-tagged IPv4 and IPv6 frames and an ARP reply that claims the gateway;
  - the receiver counts distinct frames by id;
  - without the firewall, `ipv4=3 ipv6=3 tagged=6 arp=3`; with it, `ipv4=0 ipv6=0 tagged=0 arp=0` and the counter at 15.
- Results:
  - With the candidate, the whole `TestRemoteAlphaHostFirewall*` set passes as root under `env -i PATH=/usr/bin:/bin` (40 PASS lines, `candidate-bridge-fix-full.log`) and unprivileged (36 PASS, the four root tests skip, `candidate-bridge-fix-ci.log`).
  - The real-kernel traffic test still shows containers reaching Vault, DNS and the internet.
  - The extended test **fails on the 27e8b64 render**, with `ipv4=0 ipv6=0 tagged=6 arp=3` (`candidate-test-on-tip-render.log`).
  - `bridgeprobe.sh` on the candidate ruleset: every case 0/3 with `br_netfilter` on or off; c2's gateway entry did not change; c1 saw nothing.

**Uncertainty:**

- The VLAN-tag behaviour depends on the receiving kernel. The lab shows it on kernel 6.18; Inference: the box's Ubuntu kernel behaves the same.
- 802.1ad (QinQ) and other ethertypes are covered by the candidate rule anyway.

**Classification.** Patch defect, present since 8bef528. Both the 02 audit and the repair missed it: my F3 diff fixed only the source-address case.

### R2: Observation, the bridge and container-IPv6 checks run only at --plan and --apply

`--plan` and `--apply` refuse a non-container bridge and a container interface with IPv6 (`remote_alpha_host_firewall.sh:569–583`). `--status` does not repeat either check.

- A bridge created later (for example a libvirt bridge) would silently lose IPv6 between its ports. With R1's fix it would lose everything between its ports.
- A Docker network given IPv6 later would reach the LAN's global IPv6 prefix.

Both are noticed only at the next `--apply`. Suggest running both checks in `--status` too. Not tested.

### R3: Observation, `STANDING_ROOT_TOKENS=revoke` revokes every root token that never expires

This includes a token an operator holds on purpose. The run's own 15-minute token is safe, because it has an `expire_time`. The doc and the warning text say to use `revoke` only "if nobody should hold one". Acceptable as documented.

### R4: Mutant survivors

See section 7. Each survivor is listed with its effect.

### Repair items verified (no finding)

**F1, signals.**

- The mask now covers generate-root, the 15-minute token, the root revoke and the restore.
- Handlers turn SIGTERM, SIGHUP and SIGQUIT into a clean stop. The exit code is 128 plus the signal number.
- My original regression probe (`zz_audit_signal_regression_test.go`, 6 cases) **passes** on 27e8b64 (`re-signal-regression.log`). The writer's new `TestRemoteAlphaVaultWorkloadAuthBootstrapSignalsWithRealVault` passes too.

One detail of the mask, checked in CPython's source behaviour: if a signal arrives just before the mask is set, `signal.pthread_sigmask` raises it at once, before the `try`. At that point nothing has been made, so it is harmless. A signal held during the section is raised when the mask is lifted, after `short_lived = True`, so `finally` revokes the 15-minute token. The A1 mutant pins this ordering.

**F1, the root revoke before the reload (design change beyond my diff).** The order is now: generate-root, create the 15-minute token, revoke the root token, then restore. I agree with it. The cost is that unauthenticated generate-root stays open for two more requests, and using it needs the unseal key anyway. The gain is that the non-expiring root token no longer lives through a reload and its waits.

New SIGKILL probe against real Vault 2.2.2 (`zz_audit_sigkill_probe_test.go`, `re-sigkill-probe.log`):

- **SIGKILL before the restore reload applies:**
  - Left behind: the 15-minute token only (root policy, `ttl=899`, orphan) and Vault answering generate-root from memory. No new non-expiring token.
  - The next run refuses with the "does not mention" message **before it asks for the key**.
- **SIGKILL after the enable reload:**
  - Left behind: no token, the setting still in the file.
  - The next run refuses with `already_mentions` before the key prompt.

**F1 (c) and (d).**

- The refusal of an open Vault while the file is clean happens at preflight and again inside generate-root (N7 and N8 killed).
- The standing-root-token check counts root-policy tokens with no `expire_time`, or periodic ones, before any configuration request. It skips accessors that vanish (HTTP 400) and records counts only.
- The docs block "Signals and interrupted runs" is accurate against the code.

**F2.**

- Rule, comment, doc and pin match the diff.
- The DNAT lab case passes.
- R6' (flag test) is killed by the invariants test and, as the writer shows, by the real-kernel traffic test.

**F3, apart from R1.**

- `br_netfilter` is now read from `/proc/sys/net/bridge/bridge-nf-call-iptables`, which is correct for a built-in module too.
- The `bridges` check works and is killed by N22–N24.

**F4.** All four root tests pass with `env -i PATH=/usr/bin:/bin` (`re-pr30-path.log`). All four are listed `skips-itself`.

**F5.**

- Loopback and out-of-source peers no longer count.
- The writer found and fixed a test gap (N30) by adding a loopback network to `SSH_SOURCES`.

**F6.**

- The records and the `unconfirmed` marker now live in `/var/lib/es-host-firewall`.
- The marker is written before the timer is armed and removed by every exit path that changes nothing, by `rollback.sh`, `--confirm` and `--rollback`.
- After a reboot, `--status` reports the leftover state and `--plan` and `--apply` refuse.
- `--rollback` deletes the backup of the previous drop-in instead of restoring it. That fits its "remove everything" meaning, and the guidance is "--rollback, then --apply again".

**F7, F8.** "Known limits" bullets match the code. The listener line now says "a service here would be BLOCKED".

**F9.** The real-Vault client timeout is 60 s, and the `%!s(<nil>)` format error is gone.

**F10.**

- `container-ipv6` refuses any container interface holding a global or unique-local IPv6 address. Unique-local addresses are scope global in Linux, so `ip -6 addr show scope global` lists them.
- On this kernel, which has no IPv6, it passes trivially. The unit test covers the parsing.

## 6. Validation re-run (exact 27e8b64 bytes)

| Run | Result | Log |
|---|---|---|
| Root, `TestRemoteAlphaHostFirewall*` and `TestRemoteAlphaVaultWorkloadAuthBootstrap*`, Vault 2.2.2 on PATH | PASS, 119 PASS lines, 5 skips (3 IPv6 subtests, 2 bootstrap tests that skip as root) | `re-root-targeted.log` |
| Unprivileged (user `ci`), same suites | PASS, 117 PASS lines, the 4 root tests skip themselves | `re-ci-targeted.log` |
| PR #30's root environment (`env -i PATH=/usr/bin:/bin`), the 4 root tests | 4 PASS | `re-pr30-path.log` |
| 02-audit signal regression probe (6 cases, real Vault) | PASS | `re-signal-regression.log` |
| New SIGKILL leftover probe (2 cases, real Vault) | PASS: no non-expiring token left, and each re-run refuses before the key prompt | `re-sigkill-probe.log` |
| Bridge probe, br_netfilter on and off | R1 reproduced; candidate closes it | `bridgeprobe-2.log` |

These match the writer's counts (119 pass, 5 skip as root).

## 7. Mutants

I ran 46 mutants myself, with the test binary built from 27e8b64 as root and Vault 2.2.2 on PATH, each with `-test.failfast`:

- the writer's 36 (paths adapted);
- 10 of my own, aimed at the new code.

Each file was restored byte for byte, and the checksums of the three scripts matched before and after the run.

Script: `04-re-audit-evidence/probes/re_mutants.py`. Logs: `logs/re-mutants-run.log` and `logs/re-mutants-all.json`.

**Result: 43 killed, 3 survived.**

- **The writer's 36:** all killed. That includes the 02 audit's former survivors R6 (now R6'), S5, S8 and B3, and the pins R2, R9, D1 and B7.

My 10:

| Mutant | Result | What it changes |
|---|---|---|
| A1 `short_lived = True` moved after the unmask | killed (signals test) | a held signal would skip the 15-minute token's revoke |
| A2 SIGHUP not in the deferred set | killed (signals test) | |
| A3 a failed root revoke no longer revokes the 15-minute token | killed | |
| A4 a failed 15-minute token create no longer revokes the root token | killed | |
| A5 generate-root's `except BaseException` no longer cancels a started attempt | **survived** | Inference: equivalent at the only call site, which always runs inside the signal mask, so no `BaseException` other than one raised in code can reach it. It is defence in depth. No test needed; if one is wanted, a fake-Vault case that raises `KeyboardInterrupt` from the nonce request would pin it |
| A6 the marker is left when the timer cannot be armed | **survived** | fail-safe: the next `--plan` or `--apply` refuses with "never confirmed" until `--rollback`. Wrong message, no lockout. **Add a test**: a fakes case with a failing `systemd-run`, then check the marker is gone |
| A7 the marker is left when `nft -f` refuses the ruleset | **survived** | same effect as A6. **Add a test**: a fakes case with a failing `nft -f` |
| A8 `--rollback` keeps the apply records | killed | |
| A10 the standing check also counts non-root tokens | killed | |
| A11 interrupted exit code always 1 | killed | |

Note: the extended layer-2 test in `04-re-audit-fix.diff` is itself a killing test for R1. It fails on the 27e8b64 render.

## 8. Fix diff

[`04-re-audit-fix.diff`](/mnt/project-files/reports/Execution-Substrate/host-firewall/04-re-audit-fix.diff), SHA-256 `df2ae04ea9cdb031bd6ddc62572c9d7b781557eaa3c0f69aaf36eff58e657f94`. It applies to 27e8b64 and changes 4 files, +70 −46:

- `scripts/internal/remote_alpha_host_firewall.py`: one drop-all rule in the bridge `forward` chain, plus the comment.
- `testdata/remote_alpha_host_firewall/ruleset.golden.nft`: the same.
- `.docs/system_overview/remote_supported_host_alpha.md`: the bridge bullet and the validation sentence.
- `remote_alpha_host_firewall_test.go`:
  - the invariants pin and two docs pins;
  - the layer-2 sender and receiver, which add VLAN-0-tagged IPv4 and IPv6 frames and an ARP reply, counted as distinct frames;
  - the bridge isolation expectations.

Checks on the candidate:

- `gofmt -l` is clean.
- `go vet .` is clean.
- The tests are listed in section 5, R1.

## 9. Sensitive material

- Only throwaway test Vaults with test-generated keys and tokens were used, and the probes assert that the unseal key and root token never appear in output.
- The copied logs were scanned for token and key patterns: none found.
- No box data was copied.

## 10. Closing provenance

After all probes and mutants, `ES4`'s working tree was unchanged (11 status entries, the same as at the start), and the scripts' checksums matched.

I ran the recipe twice more. Both outputs are byte-identical to the opening manifest: `912de42517c13fb535fe0f07b3fca0f079ef8573f577eb67e0ff4e9cb266ec39`. Copies are in `04-re-audit-evidence/manifests/`.

## 11. Remaining uncertainty

- The box's `bridge-nf-filter-vlan-tagged` value and kernel behaviour. Inference: default 0, same behaviour as here.
- Whether Nomad tasks on the box have `NET_RAW`.
- The IPv6 lab, never run. Its first run is on the CI runner, through #30's root step.
- The PR #39 sync (section 3).

## 12. Confidence

| Kind | Confidence | Why |
|---|---|---|
| Provenance | 0.99 | manifest reproduced twice, merge reproduced, CI run checked |
| Validation | 0.85 | targeted suites as root, unprivileged and with #30's PATH; probes on real Vault and a real kernel; 46 mutants. No box, no IPv6 lab, no whole-package run |
| Implementation | 0.80 | the repair is careful and the changes beyond my diff are sound; R1 is a real gap in the layer-2 contract |

## 13. Effect status

Repair, commit, push, PR change, comment and merge were all **not performed**. The box was not contacted.

## 14. Delivery

- This file: `/mnt/project-files/reports/Execution-Substrate/host-firewall/04-re-audit.md`. Its SHA-256 is given in the thread message.
- Fix diff and evidence: `04-re-audit-fix.diff` and `04-re-audit-evidence/`.

## 15. Verdict

**BLOCK**

Required:

- R1: the drop-all bridge rule, its docs and pins, and the extended layer-2 test. `04-re-audit-fix.diff` is tested and ready.

Should be done in the same round:

- R2: repeat the bridge and container-IPv6 checks in `--status`.
- The survivors in section 7 that are marked "add a test".

After the repair, a narrow delta check is enough: the R1 bytes plus provenance. The red-team should then take that head, and its target should include layer-2 tricks beyond the ones listed here. The PR #39 sync needs its own delta check when it happens.
