# 10 — A8-1 test applied to ES draft PR #35, with trunk_dev 5b82a6e (#34) merged

Writer: the PR #35 writer thread. Date: 2026-11-24, about 02:45Z.
Target for the auditor's delta check: head `1914fcb8eeff82ee9cde58e7f6b2be257d95ac4e` on `claude/project-thread-vmre16`, base trunk_dev `5b82a6e`, manifest `575f4c0d780edf5dbf4cb7edc40f3369b0db7613cf02dce3b8b9d1aa17e4103d`.

## Plain summary (for relaying)

- **A8-1 is fixed with the auditor's test, applied unchanged.** The commit's diff is byte-identical to `08-re-audit-fix.diff`. The new test kills both mutants the audit named: the restore step deleted, and a failing chown ignored. No product code changed.
- **trunk_dev is merged again.** While the re-audit ran, #34 (the SPIRE agent helper) landed and put its own docs section where this PR's firewall section goes, so GitHub reported a conflict. The merge keeps both sections unchanged, #34's first. Every line this PR adds or removes is the same as before against the new base.
- The firewall, bootstrap and SPIRE agent tests, the docs tests and #39's layout checks pass, as root and as an unprivileged user. The real-kernel firewall tests pass as root. Nothing was run on the box.

## 1. Target

| Item | Value |
|---|---|
| Re-audited head | `74b0846` (08 re-audit: BLOCK on A8-1 only; 09 red-team re-check: cleared) |
| Merge commit | `f60fd33290328c2d12518592c0f14e3d4149a277`: 74b0846 with trunk_dev `5b82a6e` merged (#43 README, #42 es/app test ports, #34 SPIRE agent helper) |
| Head | `1914fcb8eeff82ee9cde58e7f6b2be257d95ac4e`: f60fd33 plus the A8-1 test. Tree `e31cfa6ae3b6689687e7e38550f5bf7fb82e2b3b` |
| Base | trunk_dev `5b82a6eea55e66faddadf7ebcf59393bfa129ba2` |
| Recipe | v2, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Manifest SHA-256 (head vs base) | `575f4c0d780edf5dbf4cb7edc40f3369b0db7613cf02dce3b8b9d1aa17e4103d`, taken twice with identical output. Method as before: fresh clone of the pushed head, HEAD reset to the base, upstream pinned to `origin/trunk_dev` |
| textual_diff_sha256 | `e043c370846cfdcffad7e280a7ccde764951921e786fbc0a2d6510beb04346b1` |
| Changed paths vs base | 12, the same 12 as at 74b0846 |
| Delta to check | `10-repair-evidence/a8-1-test.diff` (1 file, +62 −3) and `10-repair-evidence/merge-resolution.diff` (`git show --remerge-diff f60fd33`: the docs conflict only) |

## 2. A8-1

The commit `1914fcb` applies `08-re-audit-fix.diff` (SHA-256 `729dbf5e…4bd7`) with `git apply`, and nothing else. `git diff 1914fcb^ 1914fcb` is byte-identical to that file.

- The fake `chown` fails when `FAKE_CHOWN_FAIL` is set.
- `TestRemoteAlphaHostFirewallInstallsFilesDurably` also runs `--confirm` with a failing chown.
- New `TestRemoteAlphaHostFirewallApplyRestoresAfterAFailedDropInInstall`, with three subtests: every flush failing, only directory flushes failing, and chown failing. Each requires that `--apply` exits 1 with "could not install the sshd drop-in; restored the state from before --apply". The previous drop-in must be back, with no temporary file, loaded tables, unconfirmed marker or waiting timer left, and the next `--plan` must pass.

Mutants, at 1914fcb, run with the firewall tests as root (`validation/a81-mutant-*.log`; the script was restored and its checksum checked):

| Mutant | Result | Failing tests |
|---|---|---|
| A11: the `rollback.sh` call in the drop-in failure branch deleted | killed | all three subtests of `…ApplyRestoresAfterAFailedDropInInstall` |
| A7: a failing `chown` ignored in the installer | killed | `…InstallsFilesDurably` and the `fake_chown_fail` subtest |

## 3. The merge of trunk_dev 5b82a6e

trunk_dev moved from `4c991ba` to `5b82a6e`: #43 (README.md), #42 (es/app test ports) and #34 (SPIRE agent helper: `scripts/remote_alpha_spire_agent.sh`, its internal Python, its test, a docs section and a PLANS.md entry).

- **Conflict.** Only `.docs/system_overview/remote_supported_host_alpha.md`. Both PRs added a new section in the same place, after the workload-auth evidence list and before "Non-Goals". The resolution keeps both sections unchanged: "Remote SPIRE Agent Bootstrap Trust And Recovery Helper" (#34) first, then "Remote Alpha Host Firewall" (this PR). `merge-resolution.diff` shows it.
- **PLANS.md** merged without a conflict.
- **Checks** (`merge-check.txt`):
  - For each of the PR's 12 files, the lines the PR adds and removes against `4c991ba` (at 74b0846) are the same as against `5b82a6e` (at f60fd33). Only context lines differ.
  - f60fd33 differs from trunk_dev only in those 12 files.

## 4. Validation

Logs in `10-repair-evidence/validation/`. Every run had SIGINT at its default.

| Run | Where | Result |
|---|---|---|
| Firewall, bootstrap and SPIRE agent tests, plus every scripts test with "Doc" in its name, as root | f60fd33 | 195 pass, 0 fail, 7 skip |
| The same, unprivileged (uid 65534), Vault on `PATH` | f60fd33 | 193 pass, 0 fail, 7 skip |
| `internal/testutil` (#39's layout and path checks), unprivileged | f60fd33 | 6 pass, 0 fail |
| Root package (docs tests), as root | f60fd33 | 343 pass, 0 fail |
| Firewall tests as root, the four real-kernel and real-sshd tests included | 1914fcb | 54 pass, 0 fail, 3 skip (IPv6 lab subtests: no IPv6 kernel here) |
| Firewall tests, unprivileged | 1914fcb | 50 pass, 0 fail, 5 skip |

1914fcb changes only the firewall test file, so the f60fd33 results stand for the other suites. gofmt and `go vet ./scripts/` are clean at 1914fcb. CI on 1914fcb runs on the push; I report it in the thread only if it fails.

## 5. Effects

- Two commits pushed to `claude/project-thread-vmre16`: the merge f60fd33 and the A8-1 test 1914fcb.
- No PR comment and no merge. The box was not contacted.
- Box run 4 still waits for this check and David's go.
