# 06 — Narrow re-audit of ES draft PR #35 after the R1 repair (head 6a9d4c7)

Writer of this report: the PR #35 audit thread (read-only). Date: 2026-11-23, about 23:45Z.
Verdict: **ACCEPT**

## Plain summary (for relaying)

R1 is fixed exactly as I proposed, and the three additions all check out:

- the retired `CONTAINER_BRIDGE_SUBNETS` setting;
- `--status` repeating the bridge and container-IPv6 checks;
- the tests for an `--apply` that stops before loading.

In the lab, every kind of frame between two containers is now dropped, with `br_netfilter` on or off: tagged, ARP, broadcast, and the ARP-poisoning path. Containers still reach Vault, DNS and the internet. All tests pass as root, unprivileged and with PR #30's PATH, and every mutant I ran is killed. CI on 6a9d4c7 passed (run 45286107678, finished 23:48Z).

I have no new findings. Nothing was pushed or posted, and the box was not touched.

---

```text
INDEPENDENT AUDIT REPORT (narrow re-audit)
```

## 1. Target

| Item | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate, draft PR #35, branch `claude/project-thread-vmre16` |
| Head | `6a9d4c742941beeaeca1dc417b6713c18ae9360f`, tree `7cf3383c82cc325a9333bf90baef85c5249a83ca` |
| Repair commit | `bf771af79eb38879fa61fed0b5c104c2b5dd910a` (parent `27e8b64`) |
| Merge commit | `6a9d4c7` = `bf771af` + trunk_dev `0aa4a2b` |
| Base | `0aa4a2b5d8e93a10f65b3bb724b286ee79a0aa7e` |
| Recipe | v2, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified) |
| Manifest SHA-256 | `dc5b53b74e59e1146a8819101cbc46fb06e9e7195926c9c0f30322033d2c1297`, reproduced twice and the same at close |
| textual_diff_sha256 | `172987d7c737ab582b8983660def3faac530240596583e57475f833ea19ace12` |
| Changed paths vs base | 12 (unchanged set) |
| Delta read | `git diff 27e8b64 bf771af`: 5 files, +228 −105. SHA-256 `2b98ae71…b7f8`, equal to the writer's `05-repair-evidence/repair.diff` |
| Beyond my 04 fix | I applied `04-re-audit-fix.diff` to 27e8b64, committed it locally, and diffed against `bf771af`: 5 files, +158 −59. The result is **byte-identical** to the writer's `beyond-04-fix.diff` (SHA-256 `139286b3…1b86`) |
| Writer's report | `05-repair.md`, with manifests, mutants and validation logs |
| Remote state at 23:36Z | PR head `6a9d4c7`; trunk_dev `725c97a` (section 3) |

## 2. Posture and effects

- Read-only, done by the parent thread alone.
- Private clones:
  - `/opt/audit/ES6`: the audit tree at 6a9d4c7, HEAD reset to 0aa4a2b.
  - `/opt/audit/ES7`: 27e8b64 plus my 04 fix, used only for the beyond-diff comparison.
- No commit to any remote, no push, no comment, no PR change, no merge. The box was not contacted.
- Shared-folder writes: this report and `06-re-audit-evidence/`.

## 3. Provenance

**Manifest.**

- Fresh clone with `umask 022`.
- `git checkout -B claude/project-thread-vmre16 6a9d4c7`, then `git reset --mixed 0aa4a2b`, with upstream `origin/trunk_dev`.
- The recipe ran twice with identical output: manifest `dc5b53b7…1297`, 12 files.
- After all tests and mutants, the tree still showed the same 11 status entries and both firewall scripts' checksums matched. Two closing runs are byte-identical to the opening one.

**Merge 6a9d4c7, provenance only:**

- Its parents are `bf771af` and `0aa4a2b`.
- `git merge-tree --write-tree bf771af 0aa4a2b` gives `7cf3383c…`, equal to the head tree.
- trunk_dev `fdfa3bc..0aa4a2b` (#36 README, #33 `es/config` tests: 3 files) touches none of the PR's paths. All 12 PR paths are byte-identical to `bf771af`.
- The PR's diff against its base is the same before and after the merge, once `index` and `@@` lines are dropped (`git diff fdfa3bc bf771af` vs `git diff 0aa4a2b 6a9d4c7`).

**trunk_dev since then.**

- trunk_dev is now `725c97a` (#41: two test files under `internal/contracts/runtimeconfig/v1/`). No overlap with the PR, and a trial `git merge-tree 6a9d4c7 725c97a` is clean (`0eeb8bb1…`).
- PR #39 has still not landed. As before, the sync that brings it in needs a delta check.

## 4. What was checked

### R1: drop every frame between bridge ports

**Applied as written.** The render, golden file, invariants pin, doc bullet, validation sentence and both doc pins, and the extended `TestRemoteAlphaHostFirewallRealKernelBridgeIsolation`, are those of `04-re-audit-fix.diff`. The only difference in those hunks is an updated invariants comment, which now describes the single rule.

The rendered bridge chain at 6a9d4c7 (golden lines 123–126) is:

```
chain forward {
	type filter hook forward priority filter - 10; policy accept;
	counter name "container_to_container" drop
}
```

**Lab-validated.** `bridgeprobe.sh` from `04-re-audit-evidence/probes/` was run against the 6a9d4c7 golden ruleset (log `06-re-audit-evidence/logs/r6-bridgeprobe.log`). With `br_netfilter` calls off and on, all seven frame kinds arrived 0 of 3 times:

- untagged IPv4;
- VLAN-0-tagged IPv4;
- IPv4 to 255.255.255.255;
- untagged IPv6;
- VLAN-0-tagged IPv6;
- an ARP reply claiming the gateway;
- c2's internet-bound frame sent to c1's MAC.

Also:

- c2's UDP socket received nothing.
- c2's gateway neighbour entry kept the real gateway MAC after the spoofed reply.
- c1 did not see c2's outbound UDP.

The real-kernel traffic test shows containers still reach Vault, DNS and the internet.

### `CONTAINER_BRIDGE_SUBNETS` retired (beyond my diff)

I agree with the writer's reasoning. With the drop-all rule, the subnet list no longer decides isolation, and the old bridge check would have printed "NOT isolated at layer 2" for a container bridge outside the list, which is now false.

Repo-validated at 6a9d4c7:

- The name is gone from:
  - the defaults;
  - the exported environment names;
  - the settings-file name list (`remote_alpha_host_firewall.sh:43`);
  - `load_settings`, the rendered header and `describe`.
- `bridge-check` now requires only that the Vault address is on a container interface (exit 7 otherwise). The `--plan`/`--apply` line reads "the Vault address is on a container interface".
- A settings file that names the setting is refused as an unknown setting (test case "retired bridge subnets"). A leftover environment variable with that name is ignored. That is harmless, and paths and test-only names already behave this way.
- A search of the 6a9d4c7 tree finds the name only in that test case.
- The box's settings file, as recorded in project memory and the 05 report, holds `SERVICE_CALLERS`, `SSH_SOURCES`, `SSH_PASSWORD_SOURCES`, `ACCEPT_BLOCKED_LISTENERS` and `PROBE_IMAGE`, so it is not affected (thread-reported; the box was not read).

As expected, the rendered header no longer has the `container_bridge_subnets` line, so `--status` on the box will report that the current settings do not render the installed ruleset until box run 4. The 05 report says so.

### R2: `--status` repeats the host checks

- `remote_alpha_host_firewall_status` runs `bridges` and `container-ipv6` after the unit check and prints pass or FAIL with details.
- A FAIL turns exit 0 into 1, and leaves a pending-apply 3 as it is. The result line reads "not installed, changed, or a host check failed".
- `--status` now requires `ip`.
- In the `[[ "${status}" -eq 0 ]] && status=1` lines, a false first test is part of an `&&` list, so it does not trip `errexit`.
- The fakes test checks both pass lines, then the `virbr0` and `docker0` IPv6 drift cases, with exit 1. Mutants P7, P8 and P9 are killed.

### Marker tests (former survivors A6 and A7)

`TestRemoteAlphaHostFirewallApplyFailuresLeaveNoUnconfirmedMarker` has three cases:

- `systemd-run` fails;
- the timer is not active after arming;
- `nft -f` refuses the ruleset.

Each case checks:

- the exit code and message;
- that no marker is left;
- that nothing is loaded and no drop-in is installed;
- for the nft case, that the timer is stopped;
- that the next `--plan` passes.

My A6 and A7 mutants are now killed (section 6).

### A5, R3

Unchanged, and acceptable as stated in 04.

## 5. Validation re-run (exact 6a9d4c7 bytes, binary built from the audit tree)

| Run | Result | Log (`06-re-audit-evidence/logs/`) |
|---|---|---|
| Root, `TestRemoteAlphaHostFirewall*` and `TestRemoteAlphaVaultWorkloadAuthBootstrap*`, Vault 2.2.2 on PATH | PASS, 122 PASS lines, 5 skips (3 IPv6 subtests, 2 bootstrap tests that skip as root) | `r6-root-targeted.log` |
| Unprivileged (user `ci`), same suites | PASS, 120 PASS lines, the 4 root tests skip themselves | `r6-ci-targeted.log` |
| PR #30's root environment (`env -i PATH=/usr/bin:/bin`), the 4 root tests | 4 PASS | `r6-pr30-path.log` |
| Bridge probe, `br_netfilter` off and on | every frame dropped (section 4) | `r6-bridgeprobe.log` |

These match the writer's counts. Not re-run: the writer's whole-root-package unprivileged comparison, the IPv6 lab (no IPv6 kernel here), and the box.

## 6. Mutants

All runs used the binary built from 6a9d4c7, as root with Vault on PATH. Files were restored byte for byte, and the checksums matched before and after.

| Set | Result | Log |
|---|---|---|
| The writer's 14 (`mutants5.py`, paths adapted): P1–P13 plus P1b | **14 of 14 killed**. That includes P1b, P2 and P3, which run the real-kernel tests only: each partial rule lets one kind of frame through, and the extended layer-2 test catches it | `r6-mutants-run.log` |
| Mine from 04, re-run on the new code: A6, A7, A8, N30, N31, N40–N44 | **10 of 10 killed**. A6 and A7 are now killed by the new marker test | `r6-mine-run.log` |

## 7. CI

Run 45286107678 (run 124, `pull_request`, head `6a9d4c742941beeaeca1dc417b6713c18ae9360f`), job "build, vet and test" (138082720829): **success**, 23:08:12Z to 23:48:44Z.

- Every step passed: build, vet, macOS vet, the test gate, Test (23:12:59Z to 23:35:36Z) and "Listed tests still fail" (23:35:36Z to 23:48:40Z).
- The previous head 27e8b64 also passed (run 45271110605).
- Inference from earlier rounds, not re-read in this run's logs: the CI Test step runs unprivileged, so the four root real-kernel tests skip there. They run in CI only once PR #30's root step lands. My root and PR #30-PATH runs in section 5 cover them for now.
- At 23:49Z the PR head and branch were still `6a9d4c7` and trunk_dev was still `725c97a`.

## 8. Findings

None new. The 04 findings stand as follows:

| ID | Status |
|---|---|
| R1 (medium) | fixed as proposed; lab- and test-validated |
| R2 (observation) | done |
| R3 (observation) | unchanged, acceptable as documented |
| A5 survivor | equivalent at its only call site; no test needed |
| A6, A7 survivors | killed by the new test |

## 9. Sensitive material

- No secrets handled beyond throwaway test Vaults inside the test runs.
- The copied logs, probes and manifests were scanned for Vault token prefixes, private-key headers, GitHub and cloud key patterns, and unseal-key assignments. There were no matches.
- No box data.

## 10. Remaining uncertainty

- The IPv6 lab still has never run. Its first run is on the CI runner, once PR #30's root step runs these tests.
- The box still runs the run-3 ruleset, which lacks R1's fix. Box run 4, after the red-team, brings it. Until then the layer-2 gap from 04 remains on the box. Inference: low practical exposure, because it needs a hostile container with `NET_RAW` next to a victim.
- The PR #39 sync.

## 11. Confidence

| Kind | Confidence | Why |
|---|---|---|
| Provenance | 0.99 | |
| Validation | 0.88 | targeted suites in three modes, a real-kernel layer-2 probe, 24 mutants; no box, no IPv6 lab, no whole-package run |
| Implementation | 0.88 | small, well-tested delta; the beyond-diff changes are consistent and pinned |

## 12. Effect status

Repair, commit, push, PR change, comment and merge were all **not performed**. The box was not contacted.

## 13. Delivery

- This file: `/mnt/project-files/reports/Execution-Substrate/host-firewall/06-re-audit.md`. Its SHA-256 is given in the thread message.
- Evidence: `06-re-audit-evidence/`.

## 14. Verdict

**ACCEPT** for head `6a9d4c7` (manifest `dc5b53b7…1297`).

- R1 is fixed as proposed and validated in the lab and by tests. The retired setting, the `--status` host checks and the marker tests are correct and covered by tests. CI is green, and there are no new findings.
- This verdict covers only these bytes. Any new commit, including the PR #39 sync, needs a delta check.

Next steps (for the coordinator):

1. Red-team on `6a9d4c7`.
2. Box run 4 after the red-team, with David's go. Until then the box runs the run-3 ruleset without R1's fix, and `--status` will report a settings mismatch until run 4 (expected).
3. Before merge, do the PR #39 sync, with a delta check of the moved root script tests.
