# Red-team re-check of ES PR #35 (box host firewall) — 09-redteam-recheck

Target: Execution-Substrate draft PR #35, branch `claude/project-thread-vmre16`,
head `74b0846d6fc3b7c672a3d4447434b0fb39dbc255`, tree
`7c4f33b06ffaacdb8ce4b782bc95fbe88929abf0` (verified by fetch). The prior
red-team (`07-redteam.md`) was at `6a9d4c742941beeaeca1dc417b6713c18ae9360f`,
which is an ancestor of the current head.

Scope (coordinator's brief): confirm the two Low findings from `07-redteam.md`
are really closed, and that the fixes open nothing new:

- **RT07-1** — a crash just after `--confirm` could leave the installed ruleset
  and its listing present but empty; `--status` and the boot unit then reported
  healthy while no tables were loaded (box open, status green).
- **RT07-2** — the Vault workload-auth bootstrap never turned core dumps off, so
  a crash while the unseal key or a token was in memory could persist it to a
  core file.

Local lab only (cloud container, Go 1.26.5, Python 3.11), read-only, nothing
pushed. Evidence: `09-redteam-recheck-evidence/`.

## Outcome in one line

Both findings are closed, and the fixes open nothing new. RT07-1 is fixed at all
three layers (durable install, a `--status` that checks the loaded tables, and a
boot unit that fails when the tables are absent) and confirmed end to end on a
real kernel; RT07-2 turns core dumps off before any secret is read and is
confirmed at runtime. No new finding.

## What the writer changed

The fix is commit `d650fb9` ("Fix red-team RT07-1 and RT07-2: durable installs,
loaded-table checks, no core dumps"); `7036bcf` merges `trunk_dev` (unrelated);
`74b0846` is a test-only follow-up. `d650fb9` touches eight files: the two
status-tool shell scripts, the firewall renderer `.py`, the two test files, the
service golden, a doc and `PLANS.md`. No other product code changed. Blob SHA-256
of the changed product files at the head: `head/pr-file-sha256.txt`.

## RT07-1 — closed (install durability + loaded-table checks + boot unit)

The fix (`logs/fix-firewall-install-status.diff`) has three parts, each of which
removes one link in the original chain:

1. **Durable install.** `remote_alpha_host_firewall_install_file` now
   `cat → chmod → chown → sync "${tmp}" → mv -f "${target}"`, then
   `sync "$(dirname "${target}")"`; on any step's failure it removes the temp
   file and returns 1. `sync(1)` with a file operand calls `fsync(2)`, so the new
   content is durable before the rename and the rename is durable after — the
   "rename reaches the disk before the data" window that left an empty file is
   closed. `sync` is added to `require_commands` for both `--apply` and
   `--confirm`, so a host without it fails closed rather than installing
   non-durably.
2. **`--status` checks the tables themselves.** For `inet` and `bridge` it runs
   `nft list table <family> es_host_firewall`; if either is absent it prints
   `loaded tables: MISSING (… not loaded); the firewall is not in force` and
   exits non-zero. An empty installed ruleset or listing is now reported
   `installed ruleset: EMPTY (…after a crash during an install)` and exits
   non-zero. The old "empty listing == empty live output == match" path can no
   longer report healthy, because the table-existence check runs first and the
   listing comparison is gated on the tables being present.
3. **Boot unit fails on an empty load.** `render_unit` adds
   `StandardOutput=null` and two `ExecStartPost=<nft> list table {inet,bridge}
   es_host_firewall` lines. `nft -f` succeeds on an empty file and loads
   nothing; the `ExecStartPost` table checks then fail, so the oneshot unit
   fails instead of silently booting an empty ruleset.

**Verified.** Fake-based regression tests pass (`logs/regression-rt07.txt`):
`TestRemoteAlphaHostFirewallStatusChecksTheTablesAreLoaded` (subtests
`tables_gone_files_intact`, `ruleset_empty_tables_loaded`,
`listing_empty_tables_loaded`, `both_empty_tables_gone`),
`…StatusRefusesEmptyInstalledRulesetAfterCrash`, `…InstallsFilesDurably`
(verifies the flush order and flush-failure handling with a fake `sync`). And
confirmed **end to end on a real kernel** as root, in an isolated `ip netns`,
by `TestRemoteAlphaHostFirewallRealKernelApplyConfirmRollback`
(`logs/real-kernel-root.txt`): the test empties both installed files and runs
`nft delete table inet/bridge es_host_firewall` (the crash-then-boot scenario),
then asserts `--status` exits 1 with `loaded tables: MISSING (table inet
es_host_firewall, table bridge es_host_firewall not loaded)` and `installed
ruleset: EMPTY (`, and never `loaded tables: match`; and it runs the unit's own
`ExecStart` + `ExecStartPost` lines on the real kernel, where `nft -f` of the
empty file succeeds but the `ExecStartPost` table check fails (the unit fails).

## RT07-2 — closed (core dumps off before any secret is read)

The fix (`logs/fix-bootstrap-coredumps-signals.diff`) adds `disable_core_dumps()`
and calls it as the first operation in `main()`'s try block, before
`validate_choices()` and any prompt:

- `resource.setrlimit(RLIMIT_CORE, (0, 0))`, read back, raises if not `(0, 0)`.
  RLIMIT_CORE 0 blocks a core file and is inherited by every command the run
  starts.
- On Linux, `prctl(PR_SET_DUMPABLE, 0)` then `prctl(PR_GET_DUMPABLE)`; a non-zero
  readback raises. `PR_SET_DUMPABLE` 0 also stops a `core_pattern` pipe (e.g.
  systemd-coredump) and keeps other same-user processes out of this process's
  memory.
- If either does not hold, the run stops (phase `disable_core_dumps`,
  `core_dumps_not_disabled`) before anything is read.

**Verified.** Source guard: `…DisablesCoreDumpsBeforeSecrets` asserts a disabler
(`RLIMIT_CORE`/`PR_SET_DUMPABLE`/`prctl`/`ulimit -c 0`) exists and precedes the
first secret prompt. Runtime (as non-root `ci`, which is what exercises the
dumpability assertion — `logs/runtime-coredump-signals.txt`):
`TestRemoteAlphaVaultWorkloadAuthBootstrapFakeVaultWritesExpectedObjectsAndSafeSummary`
runs the real bootstrap helper and, via `assertBootstrapCoreDumpsOff`, confirms a
command the helper starts inherits `core_limit=0/0` (soft and hard) and the
helper's `/proc/<pid>/status` is owned by root, i.e. the helper is not dumpable.
The follow-up `74b0846` is the one correctness fix to this check: it reads
`/proc/<pid>/status` ownership (which flips to root when dumpable is 0) rather
than the `/proc/<pid>` directory (which keeps the process's own user either way).

The finding — the bootstrap process's own secrets in its own memory — is fully
closed: the process is non-dumpable and RLIMIT_CORE 0, so no core file or pipe
dump of it is produced. The writer's comment honestly scopes the one residual:
a command the run starts becomes dumpable again after it `exec`s, but it still
inherits RLIMIT_CORE 0 (no core file), and the script's secret posture never
passes secrets to children through argv, env or files. Not a new finding.

### Minor observation from 07 — also fixed

`07-redteam.md`'s minor note (an accidental Ctrl-Z could freeze the run while
generate-root was open) is addressed: `SIGTSTP`, `SIGTTIN`, `SIGTTOU` are added
to the `pthread_sigmask` block held over the generate-root section
(`DEFERRED_SIGNALS | HELD_STOP_SIGNALS`), restored after. Confirmed at runtime by
`TestRemoteAlphaVaultWorkloadAuthBootstrapTemporaryGenerateRootAccess` →
`assertSignalsHeldDuringReloads`, which reads the reload command's
`/proc/<pid>/status` `SigBlk` and asserts all seven signals (the four deferred
plus the three stop signals) are blocked during both reloads.

## The fixes open nothing new

- **No regressions.** The full firewall + bootstrap suite passes: 44 pass, 0
  fail, 6 skip as `ci` (`logs/firewall-bootstrap-suite-ci.txt`), and all three
  real-kernel firewall tests pass as root
  (`TestRemoteAlphaHostFirewallRealKernelTraffic`,
  `…RealKernelBridgeIsolation`, `…RealKernelApplyConfirmRollback` —
  `logs/real-kernel-root.txt`), so the box's L3/L2 isolation still holds after
  the fix. `RenderMatchesGolden` and `DocsContract` pass, so the new
  `ExecStartPost` lines, the updated golden and the docs agree.
- **The six skips are environment, not code**: `…SSHDDropInWithRealSSHD` (no
  `openssh-server`), the three `RealKernel*` tests when run as non-root (they need
  root to create network namespaces; all three pass when run as root here), and
  the two `…WithRealVault` tests (no `vault` binary in the container). These are
  the same prerequisites noted in `07-redteam.md`; none masks the fix.
- **The changes are defensive and fail-closed.** `install_file` fsyncs and, on
  any failure, removes the temp file and returns 1 (no partial or empty
  install). `--status` and the `ExecStartPost` checks are read-only and only ever
  tighten the healthy verdict; for a correctly installed-and-loaded firewall they
  pass (`RESULT: installed and unchanged`, confirmed by the real-kernel test), so
  there is no false "unhealthy". `disable_core_dumps()` only lowers limits a
  process may always lower for itself, and aborts the run before any secret on
  failure. Blocking the stop signals only over the critical section makes a
  backgrounded run fail rather than freeze, and the mask is restored after.
- **No secret-shape content added.** `logs/secret-scan.txt` flags only the
  bootstrap's own redaction regex (`-----BEGIN … PRIVATE KEY-----`) and the
  pre-existing secret-shaped decoys in the bootstrap test's redaction suite; the
  fix adds none (confirmed against `d650fb9`'s added lines). No real credential.

## Coverage this pass could not provide

- Real power-cut durability of the fsync-before-rename pattern cannot be proven
  in a container; `…InstallsFilesDurably` verifies the flush ordering and
  failure handling with a fake `sync`, and the mechanism (`sync(1)` → `fsync`,
  data before rename, directory after) is the correct one. The real-kernel test
  confirms the behavioural consequence (empty files / dropped tables are reported
  and fail the unit).
- The `RealKernel*` and `…WithRealVault` paths that need a real sshd or a real
  Vault were not exercised beyond what root + `ip netns` allow here; the live box
  run is the writer's/operator's step.

## Pointers

Audit chain: `07-redteam.md` (this re-check's target findings), `08-repair.md`,
`08-re-audit.md`. Contract / docs:
`.docs/system_overview/remote_supported_host_alpha.md`. Finding record:
[[es-pr35-red-team-07]].
