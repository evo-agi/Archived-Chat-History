# 08 — Repair of ES draft PR #35 after the 07 red-team (RT07-1, RT07-2), with #39 taken

Writer: the PR #35 writer thread. Date: 2026-11-24.
Target for the narrow re-audit and the red-team re-check: head `74b0846d6fc3b7c672a3d4447434b0fb39dbc255` on `claude/project-thread-vmre16`, base trunk_dev `4c991ba`, manifest `90ef077ee3694d00b8f6f4bd55a0a11fb521f0d20d419d8e3e4f059e440fa164`.

## Plain summary (for relaying)

Both red-team findings are fixed, and the red-team's minor Ctrl-Z observation is fixed with them.

- **RT07-1 (an empty ruleset reported as healthy).** Installs now flush the new file to disk before the rename and flush the directory after it, so a crash leaves the old file or the new one, never an empty one. `--status` now checks that both tables are actually loaded, and it counts an empty installed file as not installed. After loading, the boot unit checks that both tables exist and fails if they don't.
- **RT07-2 (core dumps).** The Vault bootstrap turns core dumps off before it reads anything: the core file limit is set to 0, and on Linux the process is made not dumpable. It reads both settings back and stops if either does not hold.
- **Ctrl-Z (the red-team's minor observation).** Ctrl-Z and the two other terminal stop signals now wait, like Ctrl-C, until generate-root is closed again.

trunk_dev `4c991ba` is merged, which brings in #39. #39 moved the Remote Alpha script tests into `scripts/`, so the merge also moves this PR's two root test files there and points their four CI-list entries at the scripts package. Nothing else in the PR changes with the merge. CI on the merge then caught a mistake in one of my new test checks (it looked at the wrong `/proc` file, and only runs unprivileged); 74b0846 fixes it, and the test now passes unprivileged. All 23 mutants aimed at the new code are killed. Nothing was run on the box. Box run 4 is still to come and now also brings these fixes.

## 1. Target

| Item | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| PR | #35 (draft), branch `claude/project-thread-vmre16` |
| Red-teamed head | `6a9d4c742941beeaeca1dc417b6713c18ae9360f` (06 re-audit ACCEPT; 07 red-team: RT07-1, RT07-2, both Low) |
| Repair commit | `d650fb9884bbd39d6bee60a0d50b134bb68e3e93`, one commit on top of 6a9d4c7 |
| Merge commit | `7036bcf2550cb06dd0fff67076e97826ceee7d62`: d650fb9 with trunk_dev `4c991ba` merged and the PR's root tests moved into `scripts/` |
| Head | `74b0846d6fc3b7c672a3d4447434b0fb39dbc255`: 7036bcf plus one test-only commit that fixes the `/proc` check CI failed on (section 3a). Tree `7c4f33b06ffaacdb8ce4b782bc95fbe88929abf0` |
| Base | `trunk_dev` `4c991ba1c43ac135d9d94853696d14a21523a690` (#41, #37, #39 since 0aa4a2b) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified) |
| Manifest SHA-256 (head vs base) | `90ef077ee3694d00b8f6f4bd55a0a11fb521f0d20d419d8e3e4f059e440fa164`, taken twice with identical output. Method: fresh clone of the pushed head, HEAD reset to the base, upstream pinned to `origin/trunk_dev` |
| textual_diff_sha256 | `0ad881c8f3c1f1e23d8dd3ef632189a1487ff98506b9ee597938cc4d6d144ba4` |
| Superseded manifest | `e863eb10…1690` at 7036bcf. The two manifests differ only in `scripts/remote_alpha_vault_workload_auth_bootstrap_test.go` |
| Changed paths vs base | 12. These are the same 12 as before, except that the two root test files are now `scripts/remote_alpha_host_firewall_test.go` and `scripts/remote_alpha_vault_workload_auth_bootstrap_real_vault_test.go`, and the bootstrap test is at `scripts/remote_alpha_vault_workload_auth_bootstrap_test.go` (moved there by #39) |
| Delta for the narrow re-audit | `git diff 6a9d4c7 d650fb9`: 8 files, +548 −48 (`08-repair-evidence/repair.diff`) |
| What the merge does beyond a plain merge | `08-repair-evidence/merge-beyond-plain.diff`: 3 files, +34 −19 (section 3) |
| The CI fix | `git diff 7036bcf 74b0846`: 1 test file, +9 −8 (`08-repair-evidence/fix.diff`, section 3a) |
| trunk_dev now | `523648c` (#43, README.md only). Not merged: a trial merge is clean and the PR does not touch README.md, so it is taken at the merge gate, as for #38 |

## 2. Findings, one by one

### RT07-1 (Low): `--status` and the boot unit called an empty ruleset healthy

I reproduced the finding by reading the code, and the red-team's test failed at 6a9d4c7. Three changes, as the coordinator asked (flush, plus `--status` and the unit checking that rules are actually loaded):

**The installer flushes (`remote_alpha_host_firewall_install_file`).**
- It writes the temporary file, sets its mode and owner, flushes it (`sync FILE`), renames it into place, then flushes the directory (`sync DIR`).
- Any failing step before the rename removes the temporary file and fails the install. A failing directory flush also fails the install. The callers already restore on failure: `--confirm` puts the previous files back and runs the rollback, and `--apply` runs the rollback for the drop-in.
- The function used to ignore a failing `cat`, `chmod` or `chown` (only the final `mv` decided the result). Now every step counts.
- `sync` is added to the commands `--apply` and `--confirm` require. On the box it is coreutils `sync`, which flushes the named files (the real-kernel lab used it).

**`--status` checks the tables themselves.**
- It runs `nft list table inet es_host_firewall` and `nft list table bridge es_host_firewall`. If either is missing it prints `loaded tables: MISSING (table inet es_host_firewall, table bridge es_host_firewall not loaded); the firewall is not in force` and the exit becomes 1. A pending apply keeps exit 3.
- An installed ruleset or listing that exists but is empty prints `installed ruleset: EMPTY (… for example after a crash during an install); run --plan, --apply and --confirm again` and the exit becomes 1.
- The listing is compared with the loaded tables only when both tables exist. So the old "empty matches empty" case cannot happen, and a missing table is reported as MISSING, not as DIFFER.

**The boot unit checks the tables after loading.**
- It gains `ExecStartPost=<nft> list table inet es_host_firewall` and the same line for `bridge`. If the ruleset file loads nothing, the unit fails instead of standing active with no firewall.
- `StandardOutput=null` keeps the table listings out of the journal at every boot. nft writes errors to stderr, which still reaches the journal.
- The red-team suggested an `nft list table …` check; this puts it in both places.

**Tests.**
- The red-team's `TestRemoteAlphaHostFirewallStatusRefusesEmptyInstalledRulesetAfterCrash`, unchanged except that it now lives in `scripts/remote_alpha_host_firewall_test.go`.
- New `TestRemoteAlphaHostFirewallStatusChecksTheTablesAreLoaded`, with four fakes cases: tables gone with the files intact; ruleset empty with the tables loaded; listing empty with the tables loaded; both files empty with the tables gone. Each case checks exit 1, the expected lines, and the lines that must not appear.
- New `TestRemoteAlphaHostFirewallInstallsFilesDurably`. A fake `sync` logs what it flushes, fails for a missing path, and notes a directory flushed while an earlier-flushed temporary file still exists, which would mean the rename had not happened yet.
  - For each of the four installed files (the drop-in at `--apply`; the ruleset, unit and listing at `--confirm`), the test checks that the temporary file `<target>.XXXXXX` is flushed, then the directory, never before the rename.
  - With every flush failing, and then with only directory flushes failing, `--confirm` fails with "install failed; restoring", no ruleset and no temporary file stay behind, and no tables are loaded.
- `TestRemoteAlphaHostFirewallRealKernelApplyConfirmRollback` gains a crash-and-boot step in the real-kernel lab:
  - after `--confirm`, it empties both installed files and deletes both tables;
  - `--status` must exit 1 with MISSING and EMPTY, and must not print "match";
  - the installed unit's own `ExecStart` and `ExecStartPost` lines, run in the box namespace with real nft, must fail on the `list table inet` line;
  - after the files are restored, the same lines must pass and `--status` must exit 0.
- The fakes' `systemctl restart` now runs the unit's `ExecStartPost` lines, as systemd does. The order test pins both lines in the installed unit, and the golden unit file has them.
- The help text and doc pins are updated (section 2, docs).

### RT07-2 (Low): the Vault bootstrap did not disable core dumps

The coordinator ruled it in scope.

- New `disable_core_dumps()` runs first in `main()`, before the choices are validated and long before the first prompt (phase `disable_core_dumps`).
  - It sets `RLIMIT_CORE` to (0, 0) and reads it back.
  - On Linux it calls `prctl(PR_SET_DUMPABLE, 0)` through ctypes (arguments passed as `unsigned long`) and reads it back with `PR_GET_DUMPABLE`.
  - If anything does not hold, the run stops with `core_dumps_not_disabled` before it reads a secret.
  - The summary records `operations.disable_core_dumps` = pass, with `rlimit_core: 0` and `dumpable: false` on Linux.
- Why both settings:
  - the limit alone does not stop every `core_pattern` pipe, while a process that is not dumpable gets no core dump at all, piped or not;
  - not dumpable also keeps other processes of the same user out of the helper's memory;
  - commands the helper starts inherit the zero limit, and are dumpable again once they exec, so the reload command and the SPIRE server command are not affected.
- On macOS (the fakes tests on David's Mac) only the limit applies.

**Tests.**
- The red-team's `TestRemoteAlphaVaultWorkloadAuthBootstrapDisablesCoreDumpsBeforeSecrets`, a source contract that requires a disabler before the first prompt.
- Behaviour, which the source contract alone cannot show: the fake SPIRE server, which the helper starts during preflight before any prompt, records the core limit it inherited and, where `/proc` exists, the owner of the helper's `/proc/<pid>/status`.
  - The fake-Vault success test requires `core_limit=0/0`.
  - When the test does not run as root, it requires the helper's `/proc/<pid>/status` to belong to root, which is how a process that is not dumpable appears. That check runs in CI, which runs unprivileged. (The first version read the owner of the `/proc/<pid>` directory, which is wrong; see section 3a.)
  - It also requires the summary operation.

### Ctrl-Z during generate-root (the red-team's minor observation)

- `HELD_STOP_SIGNALS` = SIGTSTP, SIGTTIN, SIGTTOU are blocked over the same section as the deferred signals, from before generate-root until the root token is revoked and the configuration is back.
- An accidental Ctrl-Z there now stops the run only after that section, instead of freezing it with generate-root open. SIGSTOP cannot be blocked, and the docs say so.
- Test: the temporary-config fixture's reload command records the helper's `SigBlk` from `/proc/<helper>/status` at both reloads. The success case requires INT, TERM, HUP, QUIT, TSTP, TTIN and TTOU blocked at both.

### Not changed

- Secrets held as plain Python strings that can be swapped out (the red-team's second minor observation, "not claimed by the design").
- `ExecReload` does not run the table checks, because systemd has no post-reload hook. `--status` covers a reload.

### Docs and help

- `.docs/system_overview/remote_supported_host_alpha.md`:
  - host firewall: the unit bullet (fails unless both tables exist), the `--confirm` bullet (flush, rename, flush), and the `--status` bullet and its exit rule;
  - P0q-R1: a new first bullet under "Signals and interrupted runs" (core dumps off, phase `disable_core_dumps`), and the stop-signal sentence.
- `PLANS.md` P0q-R1 slice: one clause each for Ctrl-Z and core dumps.
- `--help` of both scripts: the same.
- Each new sentence is pinned in the docs and help tests.

### Small fixes on the way

- A doc comment that the round-4 insertion had separated from `TestRemoteAlphaHostFirewallUnconfirmedApplyRecords` is back above its function.
- The CI-list comment said "the first two … the third" for the four root-only firewall tests. It now says three and the fourth.

## 3. The merge of trunk_dev 4c991ba, with #39's move

trunk_dev moved from `0aa4a2b` to `4c991ba`:
- #41: runtimeconfig/v1 guard tests;
- #37: runbook renames;
- #39: the Remote Alpha script tests move from the root into `scripts/`, with `internal/testutil` holding the shared helpers and checking the layout.

`git merge-tree --write-tree d650fb9 4c991ba` is clean (`dc37cbde…`). On top of that plain merge, the merge commit does what #39 asks of this PR's root tests (`merge-beyond-plain.diff`, 3 files, +34 −19):

- **Move.** `remote_alpha_host_firewall_test.go` and `remote_alpha_vault_workload_auth_bootstrap_real_vault_test.go` move to `scripts/` as package `scripts_test`, with file and test names unchanged. Both compile there against the scripts package's helpers (`writeExecutable`, `writeFile`, `mustRead`, `executionSubstrateRepoRoot` and the others) with no other change.
- **Working directories.** #39's `TestImportersNameRepositoryPathsFromTheRoot` flagged ten commands that had no working directory (ssh-keygen, rollback.sh, the lab's `ip`/`python3` commands and the real Vault server). Each now gets `Dir = executionSubstrateRepoRoot`, which is what the tests had at the root. I also gave the lab's `inBox` command one, though the check had not flagged it.
- **Loop variable.** The check also flagged two `os.Stat(path)` calls on absolute paths, because an earlier loop in the same function used a variable named `path` for relative names. That loop's variable is now `name`.
- **CI list.** The four `skips-itself` firewall entries now name `execution-substrate/scripts`, and their comment says "Scripts package".
- **The bootstrap test.** This PR's changes to `remote_alpha_vault_workload_auth_bootstrap_test.go` merged into `scripts/remote_alpha_vault_workload_auth_bootstrap_test.go` with no conflict.

Checks (`merge-check.txt`):
- The PR's diff of every other file against its base is the same before and after the merge, once index, hunk and path lines are dropped. That includes the bootstrap test, the docs, PLANS.md, the three scripts and both golden files.
- The moved files differ from their root versions only by the lines above: +23 −9 and +2 −1.
- #39 overlaps the PR only in the CI list and the bootstrap test, as described.
- `internal/testutil` passes (`TestRootKeepsOnlyItsDocsTests` and `TestImportersNameRepositoryPathsFromTheRoot` included), and so does the root package, which now holds docs tests only.

## 3a. CI on the merge, and the fix (74b0846)

CI run 45302001904 on 7036bcf failed one test, `TestRemoteAlphaVaultWorkloadAuthBootstrapFakeVaultWritesExpectedObjectsAndSafeSummary`: `the helper must not be dumpable (its /proc entry must belong to root), got: … uid=1001 helper_proc_owner=1001`.

- The product code was right; my check was wrong. For a process that is not dumpable, the kernel makes the files under `/proc/<pid>` belong to root, but the `/proc/<pid>` directory keeps the process's own user. I checked this here: directory owned by 65534, `status` owned by 0, for a non-dumpable process of uid 65534.
- The check runs only when the tests do not run as root, and my targeted runs before the push were as root, so I missed it. The unprivileged run of the whole scripts package showed the same single failure after the push.
- 74b0846 makes the fake SPIRE server record the owner of `/proc/$PPID/status` instead (`helper_proc_status_owner=`), and the assertion requires 0. Nothing else changes. The test now passes unprivileged, and Q22b (section 4) is killed by this check.
- A consequence for the earlier mutant table: at 7036bcf the Q22b "killed" came from the wrong check, which failed whatever the helper did. Q20–Q25 were run again at 74b0846 (section 4).

For PR #30: its root step runs the listed root-package `skips-itself` tests as root. After #39 those entries, the firewall ones included, are in `execution-substrate/scripts`. Whichever of #30 and #35 lands second adapts that step and the runner packages, as before.

## 4. Mutants

Script: `08-repair-evidence/mutants6.py`. Method as in rounds 3 and 5:
- one or more exact replacements per mutant;
- the prebuilt scripts test binary from the head, run with `-test.failfast`, as root unless marked;
- every file restored byte for byte, with checksums compared before and after.

Two runs:
- Q1–Q13 (firewall) at 7036bcf, log `mutants6.log`. 74b0846 changes only the bootstrap test, so these results stand for the head.
- Q20–Q25 (bootstrap) again at 74b0846, log `mutants6-rerun-74b0846.log`, with each mutant's test output in `mutant-output-74b0846/`. The table shows that run.

A note on the rerun. My first rerun was launched as a background shell job, which starts with SIGINT and SIGQUIT ignored. The helper keeps an inherited ignore, so in that run `TestRemoteAlphaVaultWorkloadAuthBootstrapSignalsWithRealVault/sigint_during_restore_reload` failed for every mutant ("an interrupted run must not exit 0") before the intended test was reached. On the unmutated head, run normally, that test passes. The runner now resets SIGINT, SIGQUIT, SIGHUP and SIGTERM to their defaults for the test binary, and the table comes from that run. The same applies to anyone running the real-Vault signal test from a background job: it fails for this reason, not because of the helper.

| Mutant | Result | First failing test |
|---|---|---|
| Q1 empty installed files pass as installed (the -s branch gone) | killed | `TestRemoteAlphaHostFirewallStatusChecksTheTablesAreLoaded` |
| Q2 status does not check the tables exist | killed | `TestRemoteAlphaHostFirewallStatusChecksTheTablesAreLoaded` |
| Q3 missing tables do not change the exit | killed | `TestRemoteAlphaHostFirewallStatusChecksTheTablesAreLoaded` |
| Q4 an empty installed file does not change the exit | killed | `TestRemoteAlphaHostFirewallStatusChecksTheTablesAreLoaded` |
| Q5 listing compared even when tables are missing | killed | `TestRemoteAlphaHostFirewallStatusChecksTheTablesAreLoaded` |
| Q5b status table check gone, real kernel only | killed | `TestRemoteAlphaHostFirewallRealKernelApplyConfirmRollback` |
| Q6 temporary file not flushed | killed | `TestRemoteAlphaHostFirewallInstallsFilesDurably` |
| Q7 directory not flushed | killed | `TestRemoteAlphaHostFirewallInstallsFilesDurably` |
| Q8 directory flushed before the rename | killed | `TestRemoteAlphaHostFirewallInstallsFilesDurably` |
| Q9 a failed directory flush ignored | killed | `TestRemoteAlphaHostFirewallInstallsFilesDurably` |
| Q10 temporary file left after a failed step | killed | `TestRemoteAlphaHostFirewallInstallsFilesDurably` |
| Q11 unit without the table checks | killed | `TestRemoteAlphaHostFirewallApplyConfirmRollbackOrderWithFakes` |
| Q11b unit without the table checks, real kernel only | killed | `TestRemoteAlphaHostFirewallRealKernelApplyConfirmRollback` |
| Q12 unit checks only the inet table | killed | `TestRemoteAlphaHostFirewallRenderMatchesGolden` |
| Q13 unit stdout not discarded | killed | `TestRemoteAlphaHostFirewallRenderMatchesGolden` |
| Q20 core dumps never disabled (call gone) | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapFakeVaultWritesExpectedObjectsAndSafeSummary` (core limit not 0) |
| Q21 RLIMIT_CORE not set | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapFakeVaultWritesExpectedObjectsAndSafeSummary` (core limit not 0) |
| Q22 PR_SET_DUMPABLE not set (read-back still there) | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapUnsealKeyWithRealVault` |
| Q22b PR_SET_DUMPABLE and its read-back gone, unprivileged | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapFakeVaultWritesExpectedObjectsAndSafeSummary` (`/proc/<pid>/status` not owned by root) |
| Q23 core dumps disabled only after the prompts | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapFakeVaultWritesExpectedObjectsAndSafeSummary` (core limit not 0) |
| Q23b core dumps disabled only after the prompts, behaviour only | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapFakeVaultWritesExpectedObjectsAndSafeSummary` (core limit not 0) |
| Q24 stop signals not held | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapTemporaryGenerateRootAccess` (SIGTSTP not in SigBlk) |
| Q25 SIGTTOU not held | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapTemporaryGenerateRootAccess` (SIGTTOU not in SigBlk) |

Result: 23 of 23 killed.

- Q5b, Q11b and Q23b run only the behavioural tests: the real-kernel lab for Q5b and Q11b, and everything except the red-team's source contract for Q23b. Each catches its mutant through behaviour, not only through text.
- Q22b runs unprivileged and is killed by the `/proc/<pid>/status` ownership check, which is how CI would catch it. (At 7036bcf it was also "killed", but by the wrong check, which failed whatever the helper did; section 3a.)
- Q22 (the setting removed, the read-back kept) makes every run stop at `disable_core_dumps`.
- Not mutated: the `raise_failure` branch when `disable_core_dumps` fails. Lowering the core limit to 0 and making a process not dumpable cannot fail for an unprivileged process, so no test can reach that branch. It fails closed by construction.

## 5. Validation

All at head 74b0846, from fresh clones (not the working tree the mutation run edits), run one after another. Script and logs: `08-repair-evidence/validation/`. The head clone was unchanged at the end.

| Run | Result |
|---|---|
| Firewall and bootstrap tests, as root | 130 pass, 0 fail, 5 skip |
| The four root-only firewall tests with PR #30's root `PATH=/usr/bin:/bin` | 4 pass, 0 fail (2 IPv6 subtests skip: no IPv6 kernel here) |
| Firewall and bootstrap tests, unprivileged (uid 65534), Vault 2.2.2 on `PATH` | 128 pass, 0 fail, 5 skip. This includes the `/proc/<pid>/status` check that failed CI on 7036bcf |
| `internal/testutil` (#39's layout and path checks), unprivileged | 6 pass, 0 fail |
| Root package (docs tests only after #39), unprivileged, head and base | 3 fail on both, the same 3: `git ls-files` exits 128 for uid 65534 in a clone owned by root (a container limit). None is a test of this PR |
| Whole scripts package minus the environment-only entries, unprivileged, head and base `4c991ba` | 156 fail on both. The failing tests and subtests are identical. At 7036bcf the head had one more, the `/proc` check |

The runs had SIGINT at its default, as the real-Vault signal test needs (section 4); the script records its signal dispositions at the start.

Also at 74b0846: gofmt on the three changed Go test files, `go vet ./scripts/` (also with `GOOS=darwin`), `py_compile` and `bash -n` on the changed scripts, all clean.

CI: run 45302001904 on 7036bcf failed on the `/proc` check (section 3a). Run 45305354190 on 74b0846: success ("build, vet and test", 01:29–02:07 UTC). GitHub shows the PR as behind trunk_dev `523648c` (#43, README only), which is merged at the gate.

## 6. Box

The box was not touched. It still runs the run-3 ruleset. Box run 4, after this re-check and with David's go, now brings:
- the drop-all bridge rule and the status checks from round 5;
- the flushed installs, the loaded-table checks and the unit's table checks from this round.

The steps are `--plan`, `--apply`, `--confirm`, `--status`, `--probe`, then the workload-auth check. `--confirm` reinstalls the unit, so the box gets the `ExecStartPost` lines then. The bootstrap changes take effect the next time David runs the Vault step; nothing on the box needs them now.

## 7. Remaining uncertainty

- `sync DIR` relies on coreutils `sync` accepting a directory. It does here and in the real-kernel lab, and Ubuntu's coreutils has done so since 8.24. The box runs Ubuntu, but I have not checked its version.
- Whether a `core_pattern` pipe on the box (systemd-coredump or apport) honours a zero limit does not matter: a process that is not dumpable is never dumped.
- The IPv6 lab subtests have still never run here (no IPv6 kernel). Their first run is on a CI runner, through #30's root step.

## 8. Effects

- Three commits pushed to `claude/project-thread-vmre16`: the repair d650fb9, the trunk_dev merge 7036bcf, and the test fix 74b0846.
- PR #35 description updated.
- Report and evidence written under this folder.
- No PR comment and no merge. The box was not contacted.
