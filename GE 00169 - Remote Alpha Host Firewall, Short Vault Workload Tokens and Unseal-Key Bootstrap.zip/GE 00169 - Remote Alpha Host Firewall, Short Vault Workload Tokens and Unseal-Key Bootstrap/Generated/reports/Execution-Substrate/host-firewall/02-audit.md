# 02 — Independent audit of ES draft PR #35 (Remote Alpha host firewall, sshd drop-in, Vault bootstrap limits)

Writer of this report: the PR #35 independent correctness audit thread (read-only). Date: 2026-11-23, about 20:35Z.
Verdict: **BLOCK** (see the end).

## Plain summary (for relaying)

The firewall itself does what the box needs today, and its lockout protection (a rollback timer armed before any rule loads) holds up, including against 32 deliberate code breakages. The audit blocks the PR for five fixable problems. Every fix below has been tested.

1. **Medium, Vault bootstrap.** If the bootstrap helper gets Ctrl-C, a hang-up or a terminate signal at the wrong moment (between making the root token and revoking it), it can leave a valid root token that never expires. Vault also keeps accepting unauthenticated generate-root requests. The docs promise this cannot happen. I reproduced it against a real Vault 2.2.2 in 5 of 6 timings. It does not affect the box: David's 19:17Z run completed normally and its root tokens were revoked.
2. **Low, firewall.** The rule meant to let Docker published ports through blocks them instead. That fails closed: the box publishes no ports today, so nothing is exposed. But the docs and a test assert the opposite. The recommended fix keeps it closed and makes the docs say so.
3. **Low, firewall.** The layer-2 rule between containers can be bypassed by a container that forges its source address, when `br_netfilter` is not active. On the box, `br_netfilter` is active, so the main table catches it (Inference). A one-word rule change closes it.
4. **Low, CI.** The real-kernel tests fail under PR #30's root CI step, because that step's PATH has no `/usr/sbin`, where `nft` and `ip` live. The fix belongs in PR #35 (two lines in the test helper).
5. **Low, lockout safety.** `--confirm` accepts a loopback SSH connection, or one from outside the allowed sources, as proof that a new SSH connection got through. That proves nothing about the operator's path.

The later head 0c95eb7 is exactly 8bef528 merged with trunk_dev 76c030f, as the writer said. Verified by tree and manifest (section 9).

Nothing was pushed, committed or posted, and the box was not touched.

---

```text
INDEPENDENT AUDIT REPORT
```

## 1. Repository and audit target

| Item | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| PR | #35 (draft), branch `claude/project-thread-vmre16` |
| Audited topic commit | `8bef528e98887dadcd136c499fa936254e0e109d`, tree `75422fb37230413623f293299f13153e2b1aee4a` |
| Base | `trunk_dev` `8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce` (merged into the topic) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, file `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (matches the pinned value) |
| Canonical manifest SHA-256 | `dcb29d4c332464d399aea656f2f3e8f768f03b2dbce8fea5d815ffe96afbcafe` |
| textual_diff_sha256 | `b9f92a6b094762b37c9eaaa276541e6115d777c469743627e97b53a4e7c3c845` |
| Changed paths | 12 |
| Later head (claim checked, section 9) | `0c95eb71afef4343d02fce3c05d9ff93cc6eea52`, tree `f8323e5e5aed8bfcb33800838138851f82919692`, manifest `a96d84db93c054f3e3737f461609d80254e1feb65d192ab1fc21967b05a57cce` against base `76c030f` |
| Remote state at 20:33Z | PR head `0c95eb7`, `trunk_dev` `76c030f` (`git ls-remote`) |

The 12 paths at 8bef528, with sha256 prefix and size:

| Path | Kind | sha256 | Size |
|---|---|---|---|
| `.docs/system_overview/remote_supported_host_alpha.md` | modified | `8a7371f1…` | 356306 |
| `.github/ci/environment-only-tests.txt` | modified | `aa62ba3e…` | 9886 |
| `PLANS.md` | modified | `6adf171e…` | 318126 |
| `remote_alpha_host_firewall_test.go` | new | `fe6cbf0d…` | 79386 |
| `remote_alpha_vault_workload_auth_bootstrap_real_vault_test.go` | new | `62248a34…` | 18282 |
| `remote_alpha_vault_workload_auth_bootstrap_test.go` | modified | `ade57eda…` | 93516 |
| `scripts/internal/remote_alpha_host_firewall.py` | new | `479fecbb…` | 43399 |
| `scripts/internal/remote_alpha_host_firewall.sh` | new, 0755 | `d8e9277c…` | 52156 |
| `scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh` | modified | `4adb7343…` | 65014 |
| `scripts/remote_alpha_host_firewall.sh` | new, 0755 | `b5a00d5b…` | 257 |
| `testdata/remote_alpha_host_firewall/es-host-firewall.service.golden` | new | `5e8230d7…` | 876 |
| `testdata/remote_alpha_host_firewall/ruleset.golden.nft` | new | `b74344d8…` | 5148 |

Full manifests: `02-audit-evidence/manifests/`.

No implementation report and no expected manifest were delivered for this PR. There is no `01-implementation.md` in this folder, and the PR body gives no manifest. The audit target is therefore bound by commit SHA, tree SHA and the manifest above (see F12).

## 2. Audit posture

- Read-only. A single parent thread did all the work, with no subagents.
- Work happened in private clones under `/opt/audit/`:
  - `ES`: the audit tree.
  - `ES2`: the 0c95eb7 check.
  - `ES3`: the fix copy, detached at 8bef528.
- Probe test files were copied into the audit tree only while they ran, then removed. `git status` showed the tree clean afterwards, and the closing manifest equals the opening one.
- Effects:
  - No commit, push, PR, comment or merge.
  - The disposable Linux box was not contacted.
  - Nothing was written to any repository.
  - The only shared-folder writes are this report, `02-audit-fix.diff` and `02-audit-evidence/`.

## 3. Provenance reproduction

- Recipe bytes verified: SHA-256 `c08597e2…3ca`.
- Setup:
  - Fresh clone, `umask 022`.
  - `git checkout -B claude/project-thread-vmre16 8bef528`, then `git reset --mixed 8ba1edb`, so the working tree holds the topic bytes on top of the base.
  - Upstream pinned to `origin/trunk_dev`.
- Recipe run twice (opening): identical output, manifest `dcb29d4c…afe`, 12 files.
- Recipe run twice again after all audit work (closing): byte-identical to the opening manifest (`cmp`).
- No mode-bit differences were tolerated; none were needed.

## 4. Coverage

Inspected in full:

- `scripts/internal/remote_alpha_host_firewall.sh`: settings file parsing, plan/apply/confirm/rollback/status, rollback.sh generation, host-facts checks.
- `scripts/internal/remote_alpha_host_firewall.py`: render, unit and sshd drop-in rendering, sshd expectations, listeners, ssh-peers, new-ssh-peer, bridge check, host-vault-source.
- The bootstrap helper diff: token limits, generate-root from the unseal key, temporary-config enable and restore, short-lived authority, proof-history deletion, main exit paths.
- Both new test files and the bootstrap test changes.
- The golden ruleset and unit.
- The CI environment-only list change.
- The doc sections "P0q-R1 Bootstrap Token Limits, Proof History And Unseal-Key Authority" and "Remote Alpha Host Firewall".
- The PLANS.md slice "Current Remote Alpha Host Network Boundary Slice".
- Box evidence in `evidence/` (box runs 1–3, vault-step).
- PR #30's `.github/ci/go_test_as_root.py` and `go.yml` step, at `0b8b9c0`, for the reconciliation question.

Not inspected or not exercised:

- The full module test suite. The writer reported the same 47 environment failures as trunk_dev; I did not rerun it.
- The IPv6 lab subtests: this cloud kernel has no IPv6 (`/proc/sys/net/ipv6` is missing).
- Docker itself: the lab emulates Docker's masquerade and DNAT with nft.
- Nomad bridges.
- The live box.
- macOS.
- Runbook PR #3 in Archived-Runbooks.

## 5. Findings

Patch defects first, then pre-existing issues and observations. Fact labels follow the project rules:

- **Repo-validated** means path:line at 8bef528.
- **Lab-validated** means reproduced in this audit.
- **Thread-reported** means taken from box evidence.
- **Inference** and **Guess** are marked as such.

### F1: A signal during generate-root leaves a non-expiring root token and Vault open to unauthenticated generate-root

```text
AUDIT FINDING
ID / Type / Severity: F1 / security risk + contract drift / medium
```

**Current contract.** Doc lines 3066–3068: "revokes the root token with `auth/token/revoke-self` before any configuration request … the helper revokes before it exits, also after a failure". Lines 3072–3073 add "a root token that cannot be revoked fails the run with `root_token_revoke_failed` and a plain warning". Lines 3098–3101 say that if the restore cannot be shown, "it revokes the root token, fails with `vault_config_restore_failed` and prints the exact line".

**Path and line (repo-validated):**

- `scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh` has no signal handling and does not import `signal`.
- `generate_root_token` (757–770) wraps only `generate_root_token_with_access` in `except BaseException`. After that, the restore (767) and the revoke run unprotected.
- `TemporaryGenerateRootAccess.restore` (703–735) catches only `Exception` (714, 719, 724), so a `KeyboardInterrupt` inside its reload or wait escapes before the root token is revoked.
- `main` (1456–1471) has `except BootstrapFailure`, `SystemExit` and `Exception`, but no `KeyboardInterrupt`. Its `finally` (1472) revokes only the short-lived token, and only once `short_lived` is set (1444).
- Python's default handling of SIGTERM and SIGHUP ends the process without running `finally` at all.

**Evidence (lab-validated against a real Vault 2.2.2).** The probe delivers the signal from inside the helper's own reload command, so the timing is exact. Files: `02-audit-evidence/probes/zz_audit_signal_probe_test.go` and `zz_audit_signal_regression_test.go`; logs `probe-signal.log` and `tip-regression.log`.

| Signal and moment | Tokens still valid after the run | vault.hcl | Unauthenticated `sys/generate-root/attempt` after the run | Exit code |
|---|---|---|---|---|
| SIGINT during the restore reload | +1 (generated root, no TTL) | back byte for byte | HTTP 200 (still open) | 130 |
| SIGTERM during the restore reload | +1 | back | 200 | 143 |
| SIGHUP during the restore reload | +1 | back | 200 | 129 |
| SIGHUP during the enable reload | +0 | still holds the added setting | 200 | 129 |
| SIGTERM during the enable reload (regression probe) | +0 | still holds the setting | 200 | non-zero |
| SIGINT during the enable reload (regression probe) | +0 | back | 403 | non-zero (already clean on the tip) |

Other observations from the same runs:

- For SIGTERM and SIGHUP, the output is only the shell's "Terminated" or "Hangup" line. The helper writes no summary and prints no warning.
- For SIGINT, the summary is written, but the post-run warnings are skipped, because the `KeyboardInterrupt` propagates past them.
- No secret appears in any output: the probes assert that the unseal key and the root token are absent.
- A second run after the enable-window case is refused at preflight with `vault_config_already_mentions_enable_unauthenticated_access`. So that leftover is machine-detected.
- The restore-window leftovers are not detected: the file is clean, but Vault still accepts the request in memory, and the root token stays valid.

`probe-signal.log` prints "summary written: true" for every case. That line comes from a probe bug (an existence check on a placeholder string), not from the helper. The corrected reading is the one given above.

**Additional gap (repo-validated, 785–793).** With `temporary-config`, if Vault already accepts unauthenticated generate-root while the file does not mention the setting, the helper uses that access and leaves it as it is. That state is exactly the signature of the restore-window leftover, so a second run neither detects nor repairs it.

**Impact.**

- An interrupted run can leave a root-policy token with no TTL in process memory, which dies with the process. The token is never written anywhere, but it stays valid in Vault until someone revokes it with another root-level token. David has no root token, and the accessor list needs one.
- Vault keeps accepting unauthenticated generate-root attempts until its next reload. Anyone who can reach Vault's API and holds the unseal key share can mint root. On a single-share setup, that is the unseal key holder anyway, so the main harm is the dangling token and the broken promise.
- Thread-reported: the box is not affected. vault-step-20261123T191721Z shows the 19:17Z run completed and revoked its tokens.

**Required correction (tested, see section 7):**

- (a) Block SIGINT, SIGTERM, SIGHUP and SIGQUIT with `signal.pthread_sigmask` from before generate-root until the root token is revoked and the configuration is restored. That covers the whole `make_short_lived_authority` call. Install handlers that turn SIGTERM, SIGHUP and SIGQUIT into a `BaseException` (`BootstrapInterrupted`), so `finally` runs, and catch it together with `KeyboardInterrupt` in `main`: record `interrupted` and exit 130.
- (b) Add the regression test, `zz_audit_signal_regression_test.go`, as a permanent test, renamed into the PR's real-Vault test file.
- (c) Not in my diff (untested): with `temporary-config`, refuse when Vault already accepts unauthenticated generate-root but the file does not mention the setting, with a plain message to reload Vault first. The alternative is to reload Vault once at the end; I recommend refusing, which is fail-closed and causes no surprise effect.
- (d) The docs must say that SIGKILL or power loss inside the window cannot be covered, and how to check afterwards. The fix narrows the exposure to those two cases.

**Notes on the fix.**

- Blocked signals are inherited by the reload child: `subprocess` passes on the parent's mask. The reload is bounded by its 60 s timeout and each wait by 20 s, so Ctrl-C is deferred for at most about 3 minutes in the worst case and is acted on as soon as the section ends.
- `getpass` restores the terminal echo in its own `finally`. So the new handlers also fix a smaller problem on the tip: SIGTERM during the hidden prompt left echo off.

**Uncertainty.** Whether the restore reload can really be interrupted with `systemctl reload vault.service` depends on timing; the probe forces the timing. A Ctrl-C at the terminal reaches the whole foreground process group, so the risk is real for an operator who presses it during the "waiting" phase.

**Classification.** Patch defect: the code path was added by this PR.

### F2: Published ports are dropped, but the docs and a test say they pass

```text
AUDIT FINDING
ID / Type / Severity: F2 / bug + contract drift + test gap / low (fail-closed)
```

**Current contract.**

- Doc lines 6607–6608: "new connections into containers pass only through Docker's published-port DNAT (`ct status dnat`)". The test pins this sentence at `remote_alpha_host_firewall_test.go:1675`.
- Doc line 6722, validation: "check real traffic (LAN, containers, Vault, DNS, published ports, …)".

**Path and line (repo-validated).** `remote_alpha_host_firewall.py:410` renders `{oif} ct state new ct status != dnat counter name "into_container" drop`.

- In nft, `ct status != dnat` is an exact comparison of the whole status word, not a flag test.
- When the kernel applies the DNAT in prerouting, it sets the DNAT-done bit (`IPS_DST_NAT_DONE`) next to `dnat`. So by the time the first packet reaches forward, the status is never exactly `dnat`, and the rule drops the connection. The lab confirms the drop.
- The flag test is `ct status ! dnat`, and nft lists it as a different rule.

**Evidence (lab-validated; `zz_audit_lab_probe_test.go`, log `probe-lab-2.log`).** A Docker-style DNAT was added to the netns lab (`wlp2s0 tcp dport 18080 → 172.17.0.3:8080`).

- As rendered: LAN [home network address withheld], caller [home network address withheld] and public 198.51.100.10 all time out. The `into_container` counter reached 6.
- With the flag-test variant, the public source connects. LAN sources still time out, because `container_egress` drops the container's replies to private ranges.
- So even with the intended rule, published ports would only work from the internet, never from the LAN.
- The PR's lab has no DNAT at all, so the "published ports" validation claim is untested.
- Mutant R6 (dnat condition removed) survives.

**Impact.**

- No exposure: this fails closed.
- Thread-reported: box run 1 shows no docker-proxy listeners and no published ports today.
- The contract text is false, and a future operator who publishes a port would see it silently dropped.

**Required correction (tested).** Option (a), recommended:

- Keep it fail-closed by rendering `ct state new counter name "into_container" drop`.
- Change the docs sentence and the test pin to "no new connection into a container is forwarded, published ports (Docker DNAT) included".
- Add a DNAT lab expectation: LAN caller and public source to box:18080 must time out.

Option (b), real published-port support, would need a flag test plus a reply exemption in `container_egress` (`ct direction reply` or `ct status dnat accept` placed before the private-range drops). That is a product decision, not a fix.

**Uncertainty.** None for the rule semantics. Docker's exact rule layout on the box was not checked (the box was not touched).

**Classification.** Patch defect.

### F3: The layer-2 bridge rule lets forged-source frames through when br_netfilter is inactive

```text
AUDIT FINDING
ID / Type / Severity: F3 / security risk vs stated contract / low
```

**Current contract.** Doc lines 6610–6611: containers "cannot reach each other at layer 2, whatever the `br_netfilter` state".

**Path and line (repo-validated).** `remote_alpha_host_firewall.py:456–457` renders `ether type ip ip saddr {net} ip daddr {net} … drop`. The rule needs the source to be in the subnet too.

**Evidence (lab-validated; `spoofdbg.sh`, log `spoofdbg.log`).** A minimal bridge lab with only the bridge table loaded, sending a raw IPv4/UDP packet from container c1 to container c2:

- Real source 172.17.0.2: dropped (counter 3).
- Forged source 203.0.113.99: received by c2.
- Proposed rule `ether type ip ip daddr 172.17.0.0/16 … drop`: both dropped.
- In the full lab with the proposed rule, containers still reach Vault, DNS and the internet, and the box still reaches Vault (`probe-lab-2.log`). That holds because the bridge `forward` hook sees only port-to-port frames: frames to the gateway or the host take the bridge `input` path.

**Impact.**

- A container with `CAP_NET_RAW` (Docker grants it by default) can send one-way packets to another container on the same bridge with a forged source. Replies go to the forged address, so this gives no two-way connection, but it allows one-way UDP injection.
- Inference: on the box, `br_netfilter` is loaded (box run 1), so the inet `container_egress` chain catches these frames by destination anyway. In this cloud lab, `br_netfilter` is built in and active, which is why the full-lab spoof probe received nothing.
- The contract's "whatever the br_netfilter state" is false as written.

**Also (repo-validated).**

- `remote_alpha_host_firewall.sh:392–395` reports `br_netfilter: not loaded` when `/sys/module/br_netfilter` is missing. That is wrong when it is built in (`CONFIG_BRIDGE_NETFILTER=y`, as on this cloud kernel). `/proc/sys/net/bridge/bridge-nf-call-iptables` is the reliable signal.
- The bridge table covers only `ether type ip`. IPv6 frames between containers, link-local included, are not covered. Whether Docker containers on the box get IPv6 link-local addresses depends on the Docker version and settings: Unknown, untested (no IPv6 kernel here).

**Required correction (tested for the IPv4 rule).**

- Render the destination-only rule.
- Update the golden file, the invariants test and the doc ("whatever source address a container writes").
- Read `br_netfilter` state from `/proc/sys/net/bridge/bridge-nf-call-iptables`.
- Either add an `ether type ip6` rule for the container subnets' IPv6 ranges, or state plainly that IPv6 between containers is out of scope.

**Classification.** Patch defect.

### F4: Real-kernel tests fail under PR #30's root CI step (PATH without /usr/sbin)

```text
AUDIT FINDING
ID / Type / Severity: F4 / CI and test gap / low
```

**Current contract.**

- PR #35 lists its three root tests as `skips-itself` in `.github/ci/environment-only-tests.txt`.
- PR #30's `.github/ci/go_test_as_root.py` runs every root-package `skips-itself` test as root with `sudo -n -- /usr/bin/env -i PATH=/usr/bin:/bin`, and fails unless each one passes.

**Path and line (repo-validated).** `requireHostFirewallLab` (`remote_alpha_host_firewall_test.go:1099–1107`) calls `exec.LookPath` for `ip`, `nft` and `python3` and fails with "running as root but … is missing". `nft` and `ip` live in `/usr/sbin`. The sshd test falls back to `/usr/sbin/sshd` (482–485).

**Evidence (lab-validated; `pr30-path-tip.log` and `pr30-path-fix.log`).** Same binary, run as root with `env -i PATH=/usr/bin:/bin`:

| Test | 8bef528 | With fix |
|---|---|---|
| `TestRemoteAlphaHostFirewallRealKernelTraffic` | FAIL: nft is missing | PASS |
| `TestRemoteAlphaHostFirewallRealKernelApplyConfirmRollback` | FAIL: nft is missing | PASS |
| `TestRemoteAlphaHostFirewallSSHDDropInWithRealSSHD` | PASS | PASS |

**Impact.** Whichever of #30 and #35 lands second turns the root step red. It is loud, not silent.

**Required correction, and which PR adjusts.**

- **PR #35 adjusts.** Its lab helper appends `/usr/sbin:/sbin` to PATH (tested two-line fix), so the tests do not depend on the caller's PATH. PR #30's narrow PATH is the right security posture and should stay.
- Independently of landing order, the PR that lands second must:
  - make sure the GitHub runner has `nftables`, `iproute2` and `openssh-server`, installed in a workflow step if missing. Whether the runner image has them is Unknown.
  - prove the root step green with a trial merge of both branches before merging.
- That CI run will also be the first execution of the IPv6 lab subtests anywhere (see F11). The runner kernel has IPv6.

**Classification.** Patch defect, a cross-PR compatibility edge.

### F5: `--confirm` accepts a loopback or out-of-source SSH connection as proof of the operator's path

```text
AUDIT FINDING
ID / Type / Severity: F5 / lockout-safety weakening / low
```

**Current contract.** The `--confirm` design: confirm requires an SSH connection opened after `--apply`, to show that a new connection got through the new rules before the rollback timer is stopped.

**Path and line (repo-validated).** `cmd_new_ssh_peer` (`remote_alpha_host_firewall.py:735–756`) returns 0 for any established peer on `SSH_PORT` that is not in the recorded list (751).

**Evidence (lab-validated; `TestAuditProbeNewSSHPeerLoopback`, `probe-lab.log`).**

- `127.0.0.1:41000` gives exit 0, "new ssh connection".
- `[home network address withheld]:41000`, outside `SSH_SOURCES`, gives exit 0.
- Mutant D3 (always pass) is killed, but no test covers these two cases.

**Impact.**

- A loopback connection proves nothing about the firewall. Examples: `ssh localhost` on the box, a local agent, or the confirm step itself if run through a local hop.
- If the Mac's path is broken, confirm still stops the timer and installs the boot unit, so the lockout outlives the timer.
- Low on a box with physical access.

**Required correction (tested).**

- Skip recorded peers, non-IP peers, loopback peers, and peers outside `SSH_SOURCES`, normalizing IPv4-mapped addresses.
- Tests for `127.0.0.1`, `::1` and `10.20.30.40` expect exit 5.

**Classification.** Patch defect.

### F6: A reboot inside the confirm window loses the rollback state

```text
AUDIT FINDING
ID / Type / Severity: F6 / lockout-safety edge / low
```

**Path and line (repo-validated).**

- The timer is transient: `systemd-run --on-active`, at `remote_alpha_host_firewall.sh:672–676`.
- The run dir defaults to `/run/es-host-firewall` (106).
- The previous drop-in backup lives in the run dir as `sshd-previous.conf` (666), and rollback.sh restores from it (615–616).

**Impact.**

- After a reboot before `--confirm`, the timer and `/run` records are gone, and the nft tables are gone too (they are not persisted before confirm). If a ruleset was installed earlier, its unit loads that old ruleset at boot.
- The new sshd drop-in in `/etc/ssh/sshd_config.d/` stays, unconfirmed. A previous drop-in it replaced cannot be restored, because its backup was in `/run`.
- Not a lockout for the Mac (key login and the Mac's password Match still work). But the state is "half applied" and `--status` cannot show what the previous drop-in was.

**Required correction.** Either keep the drop-in backup and pending marker under the state dir (persistent) until confirm or rollback, or document the reboot case and what to run (`--rollback` removes the marked drop-in). Not tested.

**Classification.** Patch defect, design edge.

### F7: Observation, listener classification

`cmd_listeners` (`remote_alpha_host_firewall.py:673–674`) treats any UDP socket at or above the ephemeral floor as a client socket ("replies only"). A real UDP service on a high port would therefore be classified as harmless and then blocked silently by the default-drop input. Fail-closed. Suggest listing high-port UDP sockets with their process name as "check" rather than as harmless. Not tested.

### F8: Observation, `token_bound_cidrs` vs the firewall's container interfaces

- The role's default `token_bound_cidrs` is `172.17.0.0/16` (bootstrap `.sh:13`).
- The firewall lets every `CONTAINER_INTERFACES` member (`docker0 br-* nomad`) reach `VAULT_ADDRESS:VAULT_PORT`.
- Logins from `br-*` or `nomad` subnets reach Vault but are refused with 403. That is fail-closed, but confusing.
- The identity snat puts every local process that connects to `172.17.0.1:8200` inside the bound CIDR. So the bound CIDR limits by network, not by workload. Inference: this is intended (the box's own workload-auth check needs it).
- Suggest one doc line on both points.

### F9: Observation, real-Vault test flake

- `TestRemoteAlphaVaultWorkloadAuthBootstrapUnsealKeyWithRealVault` failed once in 5 runs here with "vault init: 0 %!s(<nil>)": `sys/init` got no answer within the test client's 10 s timeout on a loaded machine. Reruns passed.
- One unprivileged run of the fix copy printed FAIL without the failing test name captured; two reruns passed. Inference: the same flake. Unverified.
- Suggest a longer client timeout or a readiness retry for `sys/init`. The error format also prints `%!s(<nil>)`, a format verb with no error.

### F10: Low (latent), IPv6 egress to the LAN's global prefix

- `BLOCKED_V6` (`remote_alpha_host_firewall.py:47–53`) holds `::1`, `::ffff:0:0/96`, `[home network address withheld]/7`, `[home network address withheld]/10` and `ff00::/8`. The LAN's global IPv6 prefix is not in it.
- Thread-reported: the box has 4 global IPv6 addresses (box run 1).
- Today, Docker on the box has no IPv6 ("IPv6 resolvers dropped as Docker does without IPv6"), so containers cannot use it.
- Nothing enforces that, though. If IPv6 is ever enabled for a container network, containers could reach other LAN hosts by their global IPv6 addresses.
- Recommend that `--plan` and `--apply` refuse (or warn) when any container interface has a global IPv6 address, or derive the LAN prefixes from the LAN interface and block them. Not tested.

### F11: Observation, IPv6 and boot-time coverage

- The IPv6 lab subtests (`RealKernelTraffic/ipv6_*`, `HostVaultSource/ipv6`) skip on this cloud kernel. Guess: they also skipped wherever the writer ran them, since the writer used the same cloud environment. They have never been seen to pass.
- The IPv6 claims rest on box run 1's LAN probes (thread-reported): SSH on the 4 global addresses, one ULA address and the link-local address timed out from the Mac. Those are real and good evidence for the box as configured.
- Boot-time loading of `es-host-firewall.service` (`DefaultDependencies=no`, `Before=network-pre.target docker.service nomad.service`, `WantedBy=sysinit.target`) has not been exercised on the box. Inference: check it with `--status` after the pending libc6 reboot.

### F12: Process observation, no implementation report or manifest

There is no delivered implementation report (protocol §11) and no expected manifest for #35, so this audit could not compare against the writer's claimed bytes or validation. The audit stands on the reproduced manifest. The repair round should deliver both.

### Areas checked and found sound

Repo-validated, plus lab-validated where a test or mutant is named.

**Lockout ordering.** All of the following happen before `nft -f candidate`:

- the host checks;
- `nft -c` of the candidate;
- the live-listing rollback file, itself checked with `nft -c`;
- the drop-in backup and rollback.sh;
- arming the transient timer.

After loading, the drop-in is installed and the live `sshd -T` is compared; a mismatch triggers a self-undo. Mutant S7 (load before arming) is killed.

**Confirm.**

- Requires a pending timer, the same rendering, and a new SSH peer (see F5).
- Stops the timer first, then compares the live listing, then installs the ruleset and unit, and restores on any failure.
- Mutants S1 and S2 are killed.

**Settings file.**

- Accepts known names only.
- Refuses quotes, `$`, backquote, backslash and CR.
- Refuses a non-root owner, and a group- or other-writable mode, when run as root.
- Paths are environment-only.
- Mutants S3 and S4 are killed.

**Ruleset, IPv4 and IPv6 input.**

- Default drop at `filter - 10`.
- SSH only from `SSH_SOURCES`; service ports only from callers.
- IPv6 input takes only ND, RA, MLD query, DHCPv6 replies, and what IPv6 source entries allow, so public IPv6 is closed (golden file, box run 1).
- Container to host: only `VAULT_ADDRESS:VAULT_PORT`.
- Container egress: resolvers on port 53, the internet, and no private, loopback, link-local, multicast or reserved IPv4 range.
- The identity snat at `srcnat - 10` is the only address rewrite.
- Mutants R1, R3, R4, R5, R7, R8 and R10 are killed.

**sshd drop-in.**

- `PasswordAuthentication no`, `KbdInteractiveAuthentication no` and `X11Forwarding no`, then a `Match Address` block that allows password login only from the sources.
- Checked with real `sshd -T -C` for an outside IPv4 and IPv6 address and for each source. Mutant D2 is killed.

**Vault bootstrap, except for F1.**

- The 15-minute orphan token is non-renewable, with `explicit_max_ttl`.
- The root token is revoked right after the child is created (B1 killed).
- The child is revoked in `finally` (B6 killed).
- Generate-root refuses an attempt in progress and a threshold other than 1 (B8 killed).
- A started attempt is cancelled on failure (B10 killed).
- vault.hcl is restored byte for byte with owner and mode on every `Exception` path (B2 and B9 killed). The restore wait has no killing test (B3 survives).
- Prior proof versions are deleted through KV v2 metadata (B4 killed).
- `token_bound_cidrs` is enforced (B5 killed).

**Secret handling.**

- The unseal key and proof secret are read with `getpass`. Tokens, nonce and OTP stay in memory, travel only over HTTPS in the request bodies and headers, and are never put on a command line.
- The reload command gets no secret.
- The summary records labels only.
- No secret appeared in any probe output (asserted).

## 6. Validation assessment

**Re-run on the exact 8bef528 bytes:**

- As root, all `TestRemoteAlphaHostFirewall*` and `TestRemoteAlphaVaultWorkloadAuthBootstrap*`: `ok` in 82.4 s, 95 PASS lines (`root-targeted.log`). This includes the real-kernel netns lab, real sshd and real Vault 2.2.2.
- Skipped as root: three IPv6 subtests (no IPv6 kernel) and two pre-existing bootstrap skips.
- Unprivileged (user `ci`, same suites): `ok` in 46.5 s, 94 PASS lines (`ci-targeted.log`). The three root tests skip themselves as listed.
- With PR #30's exact root environment (`env -i PATH=/usr/bin:/bin`): the two real-kernel tests FAIL (F4).
- Prebuilt test binary as root, baseline before mutants: one real-Vault flake, then clean (F9).

**Mutation testing:** 32 mutants, prebuilt root test binary, each file restored byte for byte after each mutant (`02-audit-evidence/probes/mutants.py`, `logs/mutants-all.json`, `logs/mutants-subset.json`). The golden test alone kills any render change (R11), so render mutants were judged with the golden test excluded.

| Result | Mutants |
|---|---|
| Killed (24) | R1, R3, R4, R5, R7, R8, R10, R11, D2, D3, S1, S2, S3, S4, S6, S7, B1, B2, B4, B5, B6, B8, B9, B10 |
| Survived (8) | R2, R6, R9, D1, S5, S8, B3, B7 |

What each survivor means, with the test that should exist:

- **R2:** the `ct state invalid … drop` line can be removed. Add an invariant line.
- **R6:** the dnat condition can be removed (this is F2). The F2 fix adds the DNAT lab case.
- **R9:** the echo rate limit can be removed. Add an invariant line.
- **D1:** `KbdInteractiveAuthentication no` can be removed from the drop-in. It survives because the fixture `sshd_config` already says no. Add a drop-in golden file or a fixture with `KbdInteractiveAuthentication yes`.
- **S5:** `--plan` and `--apply` can ignore a failed ssh-peers check. Add an apply test with no SSH peer from a source, expecting a refusal.
- **S8:** rollback.sh can skip restoring a previous drop-in. Extend the fakes test with a pre-existing drop-in and check that it is back after rollback.
- **B3:** the restore can skip waiting for Vault to refuse again. Add a fake-Vault case that keeps answering 200 after the restore, expecting `vault_config_restore_failed` and a revoke.
- **B7:** the in-generate attempt-in-progress check can be removed. Inference: nearly equivalent, because Vault refuses a second attempt and preflight checks too. A cheap fake-Vault case would still pin it.

Required for the repair round: tests for R6 (with F2), and for S5, S8 and B3, since these are lockout or secret paths. R2, R9, D1 and B7 are low-cost pins and should go into the same round.

**Fix copy (ES3, 8bef528 plus `02-audit-fix.diff`):**

- Root, targeted suites: `ok` in 81.2 s (`fix-root.log`).
- Unprivileged: `ok` in 48.4 s, 94 PASS (`fix-ci.log`), after one flaky run (F9).
- PR #30 PATH: all three root tests PASS (`pr30-path-fix.log`).
- Signal regression probe (6 cases): PASS on the fix (`fix1-regression.log`); 5 of 6 FAIL on the tip (`tip-regression.log`).

**Not re-run:**

- The full module suite.
- `go vet`. (`gofmt -l` was run: clean on the three changed Go files, both on the tip and on the fix copy.)
- The IPv6 lab.
- Anything on the box.
- macOS.

## 7. Tested fix diffs

File: [`02-audit-fix.diff`](/mnt/project-files/reports/Execution-Substrate/host-firewall/02-audit-fix.diff), SHA-256 `ec8273b87df5e7c342e3e2f5c4470e62678ee622ac053d171e661632d858829f`. It applies to 8bef528 and also to 0c95eb7, since none of its files differ between the two. It touches 5 files, +89 −22:

| Finding | Files | Change |
|---|---|---|
| F1 | bootstrap `.sh` | `import signal`; `BootstrapInterrupted(BaseException)` and a handler for SIGTERM, SIGHUP and SIGQUIT installed at the start of `main`; `pthread_sigmask(SIG_BLOCK, {INT, TERM, HUP, QUIT})` around `make_short_lived_authority` up to `short_lived = True`, restored in `finally`; new `except (KeyboardInterrupt, BootstrapInterrupted)` in `main` recording `interrupted`/`signal` and exiting 130 |
| F2 | firewall `.py`, golden, docs, test | forward rule `ct state new counter name "into_container" drop`; comment, doc sentence and test pin "no new connection into a container is forwarded, published ports (Docker DNAT) included"; DNAT lab expectations (caller and public to box:18080 time out) |
| F3 | firewall `.py`, golden, docs, invariants test | bridge rule `ether type ip ip daddr {net} counter name "container_to_container" drop`; doc adds "and whatever source address a container writes (the rule matches the destination only)" |
| F4 | test helper | `requireHostFirewallLab` appends `/usr/sbin:/sbin` to PATH before `LookPath` |
| F5 | firewall `.py`, test | `new-ssh-peer` skips recorded, non-IP, loopback and out-of-source peers (IPv4-mapped normalized); tests for `127.0.0.1`, `::1` and `10.20.30.40` expect exit 5 |

Not in the diff, still required:

- F1 (b), (c) and (d). The regression probe is in `02-audit-evidence/probes/zz_audit_signal_regression_test.go`, ready to adapt.
- F3's `br_netfilter` detection and the IPv6 bridge decision.
- The surviving-mutant tests.
- F6, F10 and F12.

## 8. PR #30 reconciliation

- **Answer: PR #35 adjusts.** It makes its lab tests independent of PATH (F4 fix, tested).
- PR #30 keeps `PATH=/usr/bin:/bin` for its sudo step, which is the right posture.
- Whichever PR lands second owns these:
  - (1) the runner packages: `nftables`, `iproute2` and `openssh-server` must be present for the root step. Whether `ubuntu-latest` ships them is Unknown.
  - (2) a trial merge of both branches with the root step green before the merge.
- The first runner run will also execute the IPv6 lab subtests for the first time. If they fail, that is a real finding, not a reason to skip them.

## 9. Verification of the 0c95eb7 claim

**Writer's claim:** only a merge of trunk_dev 76c030f (PR #27), touching no firewall, bootstrap, docs or CI-list files, with PLANS.md auto-merged in an unrelated section.

**Result: verified.**

| Check | Result |
|---|---|
| Parents of 0c95eb7 | `8bef528` and `76c030f`; `origin/trunk_dev` = `76c030f` |
| Tree | `f8323e5e5aed8bfcb33800838138851f82919692`, equal to `git merge-tree --write-tree 8bef528 76c030f`, a clean merge with no hand edits |
| trunk_dev side | 8ba1edb..76c030f changed 41 paths. Of the PR's 12 paths, only `PLANS.md` is among them, and the other 40 are byte-identical to `76c030f` |
| PLANS.md | equals a clean `git merge-file` 3-way merge. The PR's own PLANS.md hunk is byte-identical before and after the merge (hunk hash `1253b8b0…1b15`) |
| Commits | `git range-diff` shows every PR commit unchanged |
| Manifest at 0c95eb7 vs base 76c030f | taken twice, identical: manifest_sha256 `a96d84db93c054f3e3737f461609d80254e1feb65d192ab1fc21967b05a57cce`, textual_diff `9e40d4b29e861d2099ac58920b66aeab48f3d7faf8def7418eff63b966758ba9`, 12 files |
| Difference from the 8bef528 manifest | only `PLANS.md` (`6adf171e…`, 318126 bytes → `f6f26887…`, 320457 bytes). The other 11 entries are identical |

So every finding above applies unchanged to 0c95eb7, and the fix diff applies to it as is.

## 10. Sensitive-material handling

- No real secret was handled. The real-Vault tests use a throwaway Vault 2.2.2 with test-generated unseal keys and tokens, which never leave the test process.
- The probes assert that the unseal key and root token are absent from all output.
- The copied logs were scanned for token and key patterns; the only matches are prompt text and test names.
- The box evidence files (with IPv6 addresses cut by their reporter) were read but not copied. This report quotes no box address beyond the LAN IPv4 addresses already in the PR.

## 11. Remaining uncertainty and stop conditions

Uncertain:

- F1 timing on a real `systemctl reload` (forced in the probe).
- The Docker version on the box, and whether it gives containers IPv6 link-local addresses (F3).
- Runner image packages (F4).
- The IPv6 lab, never run.
- Boot-time unit behaviour on the box (F11).
- The F9 flake cause.

Stop conditions:

- None hit.
- Provenance matched, and opening equals closing.
- The red-team pass (separate thread) has not run yet and should take the fixed combined change as its target.

## 12. Confidence

| Kind | Confidence | Why |
|---|---|---|
| Provenance | 0.99 | recipe hash verified, manifest reproduced twice, opening equals closing, and the 0c95eb7 merge reproduced independently |
| Validation | 0.80 | targeted suites rerun as root and unprivileged on the exact bytes, plus 32 mutants and targeted probes; but no full module suite, no IPv6 lab, no box |
| Implementation | 0.75 | the core firewall and lockout ordering are sound, but F1 is a real security gap against the stated contract, and F2 and F3 make contract statements false |

## 13. Effect status

Repair, commit, push, PR, comment and merge were all **not performed**. The box was not contacted.

## 14. Report delivery

- This file: `/mnt/project-files/reports/Execution-Substrate/host-firewall/02-audit.md`. Its SHA-256 is given in the thread message that delivers it, because a file cannot contain its own hash.
- Fix diff: `02-audit-fix.diff`, SHA-256 `ec8273b8…829f`.
- Evidence: `02-audit-evidence/`, holding the probes, logs and manifests.

## 15. Final verdict

**BLOCK**

Required before the merge:

- F1: (a) to (d).
- F2: option (a), or an explicit product decision for (b).
- F3: the rule change, the `br_netfilter` detection, and the IPv6 bridge decision.
- F4.
- F5.
- Tests for the surviving mutants R6, S5, S8 and B3. Pins for R2, R9, D1 and B7 go in the same round.

Should be fixed in the same round (low):

- F6, F10, plus doc lines for F7 and F8.
- Delivery of an implementation report and manifest (F12).

The repaired head needs a fresh narrow audit of the delta, then the red-team.
