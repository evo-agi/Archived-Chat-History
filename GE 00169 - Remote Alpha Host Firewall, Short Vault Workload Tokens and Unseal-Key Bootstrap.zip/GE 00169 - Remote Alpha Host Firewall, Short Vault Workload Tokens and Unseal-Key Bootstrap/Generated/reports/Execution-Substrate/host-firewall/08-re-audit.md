# 08 — Narrow re-audit of ES draft PR #35 after the 07 red-team repair (head 74b0846)

Writer of this report: the PR #35 audit thread (read-only). Date: 2026-11-24, about 02:30Z.
Verdict: **BLOCK** (one Low test gap, A8-1; the fix is test-only and ready as a diff)

## Plain summary (for relaying)

The two red-team fixes and the Ctrl-Z fix are correct, tested and documented.

- **RT07-1 (empty ruleset reported as healthy).**
  - Installed files are now flushed to disk before and after the rename.
  - `--status` now checks that both tables are loaded, and counts an empty installed file as not installed.
  - The boot unit now fails if either table is missing after loading.
- **RT07-2 (core dumps).** The Vault bootstrap turns core dumps off before it reads anything: core size limit 0, and not dumpable on Linux. It stops if either setting does not hold.
- **Ctrl-Z.** The stop signals now wait until generate-root is closed, as Ctrl-C does.

The #39 merge only moves this PR's two root test files into `scripts/` and adjusts them for #39's checks. Every other PR file is unchanged by the merge. The one-file `/proc` test fix is right; I checked its premise on this kernel.

All tests pass as root, unprivileged and with PR #30's PATH. Of 34 mutants (the writer's 23 and 11 of mine), 31 are killed. CI on 74b0846 passed (run 45305354190).

**One Low finding, A8-1, a missing test.** When `--apply` cannot install the sshd drop-in, the code correctly puts the box back as it was. But no test checks this, and this round makes that failure reachable in new ways (a failed flush, chmod or chown). If the restore step were deleted, the firewall tests would still pass. A box could then be left with the new rules loaded and no rollback timer. The product code needs no change. `08-re-audit-fix.diff` adds the test (one test file, +62 −3). It passes on the head, and it catches mutant A7 (a failing chown ignored) and mutant A11 (the restore step deleted). Nothing was pushed or posted, and the box was not touched.

---

```text
INDEPENDENT AUDIT REPORT (narrow re-audit)
```

## 1. Target

| Item | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate, draft PR #35, branch `claude/project-thread-vmre16` |
| Head | `74b0846d6fc3b7c672a3d4447434b0fb39dbc255`, tree `7c4f33b06ffaacdb8ce4b782bc95fbe88929abf0` |
| Commits since my 06 ACCEPT (6a9d4c7) | repair `d650fb9` (parent 6a9d4c7); merge `7036bcf` (parents d650fb9 and trunk_dev `4c991ba`); test fix `74b0846` (parent 7036bcf) |
| Base | trunk_dev `4c991ba1c43ac135d9d94853696d14a21523a690` (#41, #37, #39 since 0aa4a2b) |
| Recipe | v2, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified) |
| Manifest SHA-256 | `90ef077ee3694d00b8f6f4bd55a0a11fb521f0d20d419d8e3e4f059e440fa164`, reproduced twice; closing runs equal |
| textual_diff_sha256 | `0ad881c8f3c1f1e23d8dd3ef632189a1487ff98506b9ee597938cc4d6d144ba4` |
| Changed paths vs base | 12 |
| Writer's report | `08-repair.md`, with `08-repair-evidence/` |
| Remote state at 02:00Z | PR head `74b0846`; trunk_dev `6ce0034` (section 3) |

## 2. Posture and effects

- Read-only, done by the parent thread alone.
- Private clones:
  - `/opt/audit/ES8`: the audit tree at 74b0846, HEAD reset to 4c991ba. Tests and mutants ran here.
  - `/opt/audit/ES8b`: a plain checkout of 74b0846, used for #39's layout checks and the trunk_dev trial merge.
- No commit to any remote, no push, no comment, no PR change, no merge. The box was not contacted.
- Shared-folder writes: this report and `08-re-audit-evidence/`.

## 3. Provenance

**Manifest.**

- Fresh clone with `umask 022`.
- `git checkout -B claude/project-thread-vmre16 74b0846`, then `git reset --mixed 4c991ba`, with upstream `origin/trunk_dev`.
- The recipe ran twice with identical output: manifest `90ef077e…a164`, 12 files.
- After all tests and mutants: the tree still showed the same 11 status entries, the three scripts' checksums matched, and two closing runs are byte-identical to the opening one. My probe test was removed first.

**The three deltas are byte-identical to the writer's files:**

| Delta | Mine | Writer's file |
|---|---|---|
| Repair: `git diff 6a9d4c7 d650fb9` (8 files, +548 −48) | `9353cbf1…a4a4` | `repair.diff`, same |
| Merge beyond a plain merge: `git diff <merge-tree of d650fb9 and 4c991ba> 7036bcf` (3 files, +34 −19) | `d2cad925…e738` | `merge-beyond-plain.diff`, same |
| Test fix: `git diff 7036bcf 74b0846` (1 file, +9 −8) | `cb586efa…b822` | `fix.diff`, same |

**Merge 7036bcf.**

- `git merge-tree --write-tree d650fb9 4c991ba` is clean (`dc37cbde…`).
- For the eight PR files that are not test files, the PR's diff against its base is the same before and after the merge, once `index`, `@@` and header lines are dropped. Each of the eight is byte-identical to `d650fb9`.
- The bootstrap test, which #39 moved to `scripts/` and whose only content change was the package line, carries the same PR diff after the move.
- The two moved root test files differ from their `d650fb9` versions by +23 −9 and +2 −1, exactly the lines in `merge-beyond-plain.diff`.
- #39 overlaps the PR only in the CI list and the bootstrap test.

**trunk_dev since then.**

- trunk_dev is now `6ce0034`: #43 (README.md) and #42 (`es/app` test ports, 3 files). No overlap with the PR's paths.
- A trial `git merge-tree 74b0846 6ce0034` is clean (`75c9da96…`).

## 4. What was checked

### RT07-1: durable installs, loaded-table checks, boot unit check

**Installer (`remote_alpha_host_firewall_install_file`).**

- The order is: `mktemp`, then `cat`, `chmod`, `chown` and `sync FILE` on the temporary file, then `mv -f`, then `sync DIR`.
- The steps up to the rename are one `&&` chain inside an `if !`, so any failure removes the temporary file and returns 1. A failing `mktemp` returns 1. A failing directory flush is the function's own exit status.
- The callers already restore when an install fails: `--confirm` puts back the previous files, and `--apply` runs `rollback.sh`.
- `sync` is now required by `--apply` and `--confirm`.
- This is the standard way to replace a file safely on ext4.

**`--status`.**

- `nft list table <family> es_host_firewall` runs for `inet` and `bridge`. Any missing table prints `loaded tables: MISSING (…)` and turns exit 0 into 1. A pending apply keeps its 3.
- A ruleset or listing file that exists but is empty prints `installed ruleset: EMPTY …` and turns exit 0 into 1.
- The listing is compared only when both tables exist. So "empty matches empty" can no longer pass, and a missing table shows as MISSING, not DIFFER.

**Boot unit.**

- `StandardOutput=null`, then `ExecStart=<nft> -f <ruleset>`, then two `ExecStartPost=<nft> list table …` lines, one for `inet` and one for `bridge`. The golden unit file has all three.
- systemd runs `ExecStartPost` only after `ExecStart` succeeds, and a failing one marks the oneshot unit failed. So an empty ruleset file now gives a failed unit, not an active one with no firewall.
- nft errors still go to the journal through stderr.

**Tests.**

- The red-team's `…StatusRefusesEmptyInstalledRulesetAfterCrash`.
- The new `…StatusChecksTheTablesAreLoaded` (four fakes cases) and `…InstallsFilesDurably`. The fake `sync` in the second test checks, for all four installed files, that the temporary file is flushed before the directory and the directory after the rename. It also covers both failure modes.
- In the real-kernel lab, `…RealKernelApplyConfirmRollback` gains a crash-and-boot step: both files emptied and both tables deleted. `--status` must then exit 1 with MISSING and EMPTY. The installed unit's own `ExecStart`/`ExecStartPost` lines, run in the box namespace, must fail on `list table inet`. After a restore, they pass and `--status` exits 0.
- All of these passed in my root run (section 5).

**Checked and not a finding: the apply records under `/var/lib/es-host-firewall` are not flushed.**

- `--apply` writes `sshd-previous.conf`, `rollback.sh` and the `unconfirmed` marker with plain `cp`/`>`. After a power cut inside the confirm window, they could come back empty.
- That does not matter, for three reasons:
  - The recovery after a reboot is `--rollback`, which reads none of these records. It removes the tables, the unit, the managed drop-in and the whole records directory.
  - The leftover check only looks at whether the marker exists (`[[ -f … ]]`).
  - Inference about ext4's ordered journal, not tested: the marker is created before the drop-in's flushed rename, so whenever the new drop-in survives a power cut, the marker's directory entry does too.
- The reverse case is harmless. A power cut within seconds after `--confirm` could leave a stale marker. `--status` would then report an unconfirmed apply, and the instructed `--rollback` then `--apply` redoes the install. That is visible extra work, not a silent opening.

**Also noted, not new.** A failed boot unit does not stop Docker or Nomad from starting: the unit is ordered before them but not required by them. The PR has never claimed it is. A failed unit is now visible, and `--status` reports MISSING.

### RT07-2: core dumps off

- `disable_core_dumps()` is the first thing inside `main()`'s `try`, before `validate_choices` and long before `secret_prompts_started`. Before it, `main()` only sets up signal handlers and checks that the summary is writable. Nothing secret is read before it.
- It sets `RLIMIT_CORE` to (0, 0) and reads it back. On Linux it calls `prctl(PR_SET_DUMPABLE, 0)` through ctypes, with `c_int` and `c_ulong` arguments, and requires `PR_GET_DUMPABLE` to return 0. Any failure raises, and the run stops with `core_dumps_not_disabled`.
- The doc says a non-dumpable process also escapes a `core_pattern` pipe. I believe that is correct: the kernel's core-dump code gives up before any core-pattern handling when the process is not dumpable. That comes from my knowledge of `fs/coredump.c`; I did not re-read it in this audit.
- The summary's `dumpable` field is `false` on Linux and `true` elsewhere (only the limit applies on macOS). That is accurate.
- **The `/proc` test premise, probed independently** (`r8-dumpable-probe.log`, user `ci`, this kernel): after `PR_SET_DUMPABLE 0`, `/proc/<pid>` stays owned by the user (30033) while `/proc/<pid>/status` becomes owned by root. So 74b0846's check of the `status` file is the right one, and 7036bcf's directory check could never pass. That matches the writer's section 3a.

### Ctrl-Z

- `HELD_STOP_SIGNALS` (TSTP, TTIN, TTOU) is added to the same `pthread_sigmask(SIG_BLOCK, …)` as the deferred signals, so it is held over the same section.
- A pending stop takes effect when the mask is restored.
- The fixture's reload command records the helper's `SigBlk` at both reloads, and the test requires all seven signals. This passed both as root and unprivileged.
- The reload command inherits the mask, as it already did for SIGINT. That is intended and documented.

### #39 merge extras

- The two moved files changed only their package line, ten `Dir = executionSubstrateRepoRoot` assignments plus the extra one on `inBox`, and a loop variable renamed from `path` to `name`. The four CI-list entries now name `execution-substrate/scripts`, and the comment now says "three … the fourth".
- #39's `internal/testutil` checks pass unprivileged (6 of 6, `r8-testutil-ci.log`).
- As a check on that check, I removed the `keygenCmd.Dir` line in a scratch clone. `TestImportersNameRepositoryPathsFromTheRoot` then failed at exactly that line (`r8-testutil-dir-mutant.log`). The file was restored.

### Docs and help

- The new doc bullets (unit, `--confirm` flush, `--status` exit rule, core dumps, stop signals), the PLANS.md clauses and the `--help` text match the code.
- They are pinned by the docs and help tests, which pass.

## 5. Validation (exact 74b0846 bytes, binary built from the audit tree)

| Run | Result | Log (`08-re-audit-evidence/logs/`) |
|---|---|---|
| Root, `TestRemoteAlphaHostFirewall*` and `TestRemoteAlphaVaultWorkloadAuthBootstrap*`, Vault 2.2.2 on PATH, SIGINT at its default | PASS, 130 PASS lines, 5 skips (3 IPv6 subtests, 2 bootstrap tests that skip as root). The real-kernel, real-sshd and real-Vault tests (unseal key, signals, temporary generate-root) all ran and passed | `r8-root-targeted.log` |
| Unprivileged (user `ci`, uid 30033), same suites | PASS, 128 PASS lines; the 4 root tests skip themselves. This includes the `/proc/<pid>/status` check that failed CI on 7036bcf | `r8-ci-targeted.log` |
| PR #30's root environment (`env -i PATH=/usr/bin:/bin`), the 4 root tests | 4 PASS | `r8-pr30-path.log` |
| `internal/testutil`, unprivileged | 6 PASS | `r8-testutil-ci.log` |
| `go vet ./scripts`, `gofmt -l` on the 3 changed Go files, `bash -n`, `py_compile` | clean | (inline) |

These match the writer's counts (130, 128, 4, 6). Not re-run: the writer's whole-package unprivileged comparison, the IPv6 lab (no IPv6 kernel here), and the box.

## 6. Mutants

Method:

- The writer's `mutants6.py`, with paths adapted, plus 11 mutants of mine (`probes/r8_mutants.py`).
- One prebuilt scripts test binary from the audit tree, run with `-test.failfast`.
- Run as root, except Q22b, which runs as uid 65534.
- SIGINT, SIGQUIT, SIGHUP and SIGTERM reset to their defaults for the test binary.
- Every file restored byte for byte, with checksums matching before and after.

Log: `r8-mutants-run.log`; JSON: `r8-mutants-all.json`.

| Set | Result |
|---|---|
| The writer's Q1–Q13, Q5b, Q11b, Q20–Q25, Q22b, Q23b | **23 of 23 killed**, each by the same test the writer names |
| A1 `--status` checks only that the inet table exists | killed (`…StatusChecksTheTablesAreLoaded`) |
| A1b the same, real kernel only | killed (`…RealKernelApplyConfirmRollback`) |
| A2 unit checks only the bridge table, golden test excluded | killed (`…ApplyConfirmRollbackOrderWithFakes`) |
| A3 empty check covers only the ruleset | killed |
| A4 empty check covers only the listing | killed |
| A8 SIGTTIN not held | killed (`…TemporaryGenerateRootAccess`) |
| A9 only the soft core limit set to 0 | killed (`core_limit=0/0` check) |
| A10 core dumps disabled just after preflight starts the SPIRE server, source contract excluded | killed (behaviour) |
| A5 `--apply` no longer requires `sync` | **survived**. Equivalent in outcome: a missing `sync` fails at the first flush and the run restores (shown below) |
| A6 `--confirm` no longer requires `sync` | **survived**. Equivalent in outcome: the writer's every-flush-fails `--confirm` case covers it |
| A7 a failing `chmod` or `chown` no longer fails the install | **survived**. Not equivalent: the writer says "every step counts", but nothing tests it (A8-1) |

**Follow-up on the survivors.**

- **A probe of `--apply` when the drop-in flush fails** (`probes/zz_audit_apply_flush_probe_test.go`, run three times, `r8-apply-flush-probe.log`). For an every-flush failure and a directory-only failure, `--apply` exits 1 with "could not install the sshd drop-in; restored…". The previous drop-in is back. No temporary file, tables, marker or waiting timer stays, and the next `--plan` passes. So the product code is right, and A5 is equivalent.
- **Mutant A11: delete the `rollback.sh` call in that branch.** The PR's whole firewall suite still **passes** (`r8-mutant-A11.log`), while my probe fails. That is A8-1.
- **With `08-re-audit-fix.diff` applied**, A11 is killed by the new `…ApplyRestoresAfterAFailedDropInInstall` and A7 by the extended `…InstallsFilesDurably` (`r8-fix-root.log`).

## 7. CI

Run 45305354190 (`pull_request`, head `74b0846d6fc3b7c672a3d4447434b0fb39dbc255`), job "build, vet and test" (138147747964): **success**, 01:29:03Z to 02:07:49Z.

- Every step passed: build, vet, macOS vet, the test gate, Test (01:33:30Z to 01:55:37Z) and "Listed tests still fail" (01:55:37Z to 02:07:46Z).
- The run on 7036bcf (45302001904) failed only on the `/proc` check, as the writer reports. 74b0846 fixes that check.
- CI runs unprivileged, so the unprivileged `/proc/<pid>/status` check ran there. The four root real-kernel tests skip there until PR #30's root step lands (inference from earlier rounds). My root runs in section 5 cover them.

## 8. Findings

### A8-1 (Low, test gap): `--apply`'s restore after a failed drop-in install is untested

- **What.** The branch of `--apply` that handles a failed drop-in install stops the timer, runs `rollback.sh` and exits 1 (`remote_alpha_host_firewall.sh`, after `nft -f "${candidate}"`). No test reaches it.
  - Before this round, only a failing `mv` could reach it.
  - Now a failing `sync` of the temporary file or the directory, or a failing `chmod` or `chown`, can reach it too. The directory flush runs after the rename, so the new drop-in is already in place when it fails.
- **Evidence.**
  - Mutant A11 deletes the `rollback.sh` call there. The PR's whole firewall suite still passes.
  - In that mutant, a failed flush would leave the candidate tables loaded, the rollback timer stopped and the marker in place, with no automatic rollback. That is the lockout case the confirm window exists to prevent.
  - The writer's report also says a failing `chmod` or `chown` now fails the install. Mutant A7, which ignores them, survives.
- **Current code.** Correct: my probe shows a full restore (section 6).
- **Fix (test only), `08-re-audit-fix.diff`** (SHA-256 `729dbf5ee7cb4dcadd402350e5776aa34f1d90af548d727576c956c61ccd4bd7`, one file, +62 −3). It applies cleanly to 74b0846.
  - The fake `chown` fails when `FAKE_CHOWN_FAIL` is set.
  - New `TestRemoteAlphaHostFirewallApplyRestoresAfterAFailedDropInInstall`. For an every-flush failure, a directory-only failure and a failing chown, it checks: exit 1 with the restore message; the previous drop-in is back; no temporary file, tables or marker stays; the timer is not waiting; the next `--plan` passes.
  - `TestRemoteAlphaHostFirewallInstallsFilesDurably` adds `FAKE_CHOWN_FAIL=1` to its `--confirm` failure loop.
  - With the diff: gofmt and vet are clean. The firewall suite passes as root (54 PASS lines) and unprivileged (50; the 4 root tests skip). The new tests kill A11 and A7 (`r8-fix-root.log`, `r8-fix-ci.log`).
- **Severity.** Low. The product code is right and no box is at risk now. But this branch guards the confirm window's main promise, and this round added new ways to reach it.

### Earlier findings

| ID | Status |
|---|---|
| RT07-1 (Low) | fixed; flush, table checks and unit checks validated by tests and mutants |
| RT07-2 (Low) | fixed; behaviour tested root and unprivileged; `/proc` premise probed |
| Ctrl-Z (red-team observation) | fixed; `SigBlk` tested at both reloads |
| Secrets as plain strings (red-team observation) | not changed, as the design does not claim it |
| R1, R2, R3 and earlier | unchanged since 06 |

## 9. Sensitive material

- No secrets handled beyond throwaway test Vaults inside the test runs.
- The copied logs, probes and manifests were scanned for Vault token prefixes, private-key headers, GitHub and cloud key patterns, and unseal-key assignments. There were no matches.
- No box data.

## 10. Remaining uncertainty

- `sync DIR` needs a coreutils that flushes a named directory. Ubuntu has shipped one since 16.04 (coreutils 8.24 and later), but the box's version was not checked. If it were older, the flush would fail, the install would fail and restore, and the box would not be left open.
- The IPv6 lab has still never run. Its first run is on the CI runner, once PR #30's root step runs these tests.
- The box still runs the run-3 ruleset, without R1's drop-all rule and without this round's fixes, until box run 4.

## 11. Confidence

| Kind | Confidence | Why |
|---|---|---|
| Provenance | 0.99 | manifest reproduced, three deltas byte-identical, merge checked file by file |
| Validation | 0.88 | targeted suites in three modes with the real-kernel and real-Vault tests, #39's checks, mutants; no box, no IPv6 lab, no whole-package run |
| Implementation | 0.9 | small, standard changes with behavioural tests for each |

## 12. Effect status

Repair, commit, push, PR change, comment and merge were all **not performed**. The box was not contacted.

## 13. Delivery

- This file: `/mnt/project-files/reports/Execution-Substrate/host-firewall/08-re-audit.md`. Its SHA-256 is given in the thread message.
- Evidence: `08-re-audit-evidence/`.

## 14. Verdict

**BLOCK** for head `74b0846` (manifest `90ef077e…a164`), on A8-1 only.

- The repairs for RT07-1, RT07-2 and Ctrl-Z are correct, documented and tested. The #39 merge and the `/proc` fix are right. CI is green.
- A8-1 is a missing test on a branch this round made easier to reach. The fix is test-only and ready: `08-re-audit-fix.diff`.

Next steps (for the coordinator):

1. The writer applies `08-re-audit-fix.diff` (or an equivalent test) and pushes.
2. A narrow delta check of that one test file, which I can do quickly, then the red-team re-check that is already planned.
3. Box run 4 after that, with David's go.
4. trunk_dev `6ce0034` (#43 README, #42 `es/app` tests) has no overlap and merges cleanly. It can be taken at the merge gate.
