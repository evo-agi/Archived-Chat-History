# 13 — Byte check of the PR #35 trunk_dev sync (head e73c69e)

Writer of this report: the PR #35 audit thread (read-only). Date: 2026-11-24, about 08:00Z.
Verdict: **ACCEPT**

## Plain summary (for relaying)

- The sync is a plain git merge of my accepted 1914fcb and trunk_dev 2ba2db8, with no hand edit.
- Nine of the PR's 12 files are byte-identical to 1914fcb. The other three (Remote Alpha docs, CI list, PLANS.md) carry exactly the PR's lines and exactly trunk's lines, and nothing else.
- The manifest `311f88a8…986c` reproduces.
- Firewall, bootstrap and docs tests pass at the new head.
- CI on e73c69e was still running at writing; the merge gate requires it to pass.
- Nothing was pushed or posted, and the box was not touched.

## Checks

| Check | Result |
|---|---|
| Head | `e73c69e596c317a9bb8d89cc4075270197593aa5`; parents `1914fcb` (11-delta-check ACCEPT) and trunk_dev `2ba2db8ff997b52a1789a976c28233d488141861`; trunk_dev was still 2ba2db8 at 07:44Z |
| Plain merge | `git merge-tree --write-tree 1914fcb 2ba2db8` = `f09e4343…`, equal to the head's tree, so there was no hand edit |
| trunk since 5b82a6e | #31, #38, #44, #46, #12, #48 (142 files) |
| The PR's lines | For all 12 PR files, the added and removed lines (`-U0`) of `5b82a6e..1914fcb` equal those of `2ba2db8..e73c69e` |
| Unchanged files | Nine PR files are byte-identical to 1914fcb: all scripts, tests and golden files |
| Auto-merged files | The docs, CI list and PLANS.md, the only PR files trunk touched. For each, trunk's added and removed lines (`5b82a6e..2ba2db8`) equal those of `1914fcb..e73c69e` |
| Changed paths | e73c69e differs from trunk only in the same 12 PR paths |
| Docs | Section order kept: SPIRE agent helper (6610), Remote Alpha Host Firewall (6780), Non-Goals (7020). No conflict markers in any of the three files |
| CI list | The four firewall entries still name `execution-substrate/scripts` (lines 172–175). trunk's new entries were added elsewhere. No duplicate entries |
| Manifest vs 2ba2db8 | `311f88a8c01bc65067e30f51b0d9a2ebf5b94133db31d84106c9353af71e986c`, reproduced twice in a fresh clone; the closing run is equal. 12 paths. Nine entries equal my 575f4c0d manifest; the three auto-merged files differ. textual_diff `e171613a…56b9` |
| Cross-PR reading | The new trunk code talks to Nomad on 127.0.0.1 (4646/4647), which the firewall's `iifname "lo" accept` allows. I found no new need for containers to reach host services. The `network_mode` and `host` hits are in tests of the limited Docker driver, which refuses them |

## Tests at e73c69e

Binary built from the audit tree; logs in `13-sync-check-evidence/logs/`.

| Run | Result |
|---|---|
| Root: firewall, bootstrap and scripts doc tests, Vault 2.2.2 on PATH | PASS, 159 PASS lines, 5 skips, the same counts as at 1914fcb. Includes the real-kernel tests and the A8-1 test (`r12-root-scripts.log`) |
| Root package (docs tests, now including trunk's new ones) | PASS, 604 (`r12-root-package.log`) |

CI: run 45350212498 on e73c69e was in progress at 07:50Z. The repository requires "build, vet and test" to pass before merge.

## Findings

None.

## Effects

Read-only, in private clone `/opt/audit/ES12`. No commit, push, comment, PR change or merge. The box was not contacted. Log scan: no token or key patterns.

## Verdict

**ACCEPT** for head `e73c69e` (manifest `311f88a8…986c`), subject to the required CI check passing at the merge gate. This agrees with the writer's `12-sync.md` (SHA-256 `7d6b061d…0a72`).
