# 11 — Delta check of ES draft PR #35 at 1914fcb (A8-1 test plus trunk_dev 5b82a6e)

Writer of this report: the PR #35 audit thread (read-only). Date: 2026-11-24, about 03:05Z.
Verdict: **ACCEPT**

## Plain summary (for relaying)

- My A8-1 test diff landed unchanged: commit 1914fcb is byte-identical to `08-re-audit-fix.diff`.
- The docs conflict is resolved correctly. The SPIRE agent section from #34 comes first, then this PR's firewall section, then "Non-Goals". Both sections are unchanged and no conflict markers remain.
  - This PR's added and removed lines are exactly what they were against the old base.
  - trunk's lines are exactly what trunk added.
- The merge changed no other PR file.
- Tests pass as root and unprivileged, including the new test and the real-kernel tests.
- CI on 1914fcb was still running at writing. The merge gate requires it to pass, and I will report only if it fails.
- Nothing was pushed or posted, and the box was not touched.

## Target and provenance

| Item | Value |
|---|---|
| Head | `1914fcb8eeff82ee9cde58e7f6b2be257d95ac4e`, tree `e31cfa6ae3b6689687e7e38550f5bf7fb82e2b3b` (verified) |
| Commits since 74b0846 | merge `f60fd33` (parents 74b0846 and trunk_dev `5b82a6e`), then `1914fcb` (the A8-1 test) |
| Base | trunk_dev `5b82a6eea55e66faddadf7ebcf59393bfa129ba2` (#43 README, #42 es/app test ports, #34 SPIRE agent helper). Still trunk_dev at 02:47Z, so the branch is up to date |
| Manifest SHA-256 | `575f4c0d780edf5dbf4cb7edc40f3369b0db7613cf02dce3b8b9d1aa17e4103d`, reproduced twice in a fresh clone (umask 022, HEAD reset to the base, upstream `origin/trunk_dev`). The closing run is equal. textual_diff `e043c370…46b1`. 12 paths, the same 12 as at 74b0846 |

## What was checked

**A8-1 commit.**

- `git diff f60fd33 1914fcb` has SHA-256 `729dbf5e…4bd7`, byte-identical to `08-re-audit-fix.diff`.
- It touches one file: `scripts/remote_alpha_host_firewall_test.go`, +62 −3.

**The merge f60fd33.**

- Ten of the PR's 12 files are byte-identical to 74b0846. Only the docs file and `PLANS.md` differ, and those are the only PR paths that trunk `4c991ba..5b82a6e` touched.
- `f60fd33` differs from trunk_dev only in the 12 PR paths.

**The two merged files.** I checked both directions, comparing only the `+` and `−` lines (`-U0`):

- The PR's changes against `5b82a6e` (at f60fd33) are identical to its changes against `4c991ba` (at 74b0846).
- trunk's changes `4c991ba → 5b82a6e` are identical to `74b0846 → f60fd33`.

So each merged file is the old base plus trunk's change plus the PR's unchanged change, and nothing else.

**The docs conflict.**

- `git show --remerge-diff f60fd33` shows only the docs conflict. It is identical to the writer's `merge-resolution.diff`, apart from that file's 17-line commit header.
- In the merged file, `## Remote SPIRE Agent Bootstrap Trust And Recovery Helper` (line 6610) is followed by `## Remote Alpha Host Firewall` (6771), then `## Non-Goals` (7011).
- There are no conflict markers.
- PLANS.md merged without a conflict.

**Cross-check with #34, by reading.**

- The SPIRE helper talks to the server over 127.0.0.1:8081 and a unix socket. The firewall's input chain accepts everything on `lo` (`iifname "lo" accept`, golden line 48), so the two do not interfere.

**Tests** (binary built from the audit tree at 1914fcb; logs in `11-delta-check-evidence/logs/`):

| Run | Result |
|---|---|
| Root: firewall, bootstrap and scripts doc tests, Vault 2.2.2 on PATH | PASS: 159 PASS lines, 5 skips (3 IPv6 subtests, 2 bootstrap tests that skip as root). Includes all three subtests of the new `…ApplyRestoresAfterAFailedDropInInstall` and the three real-kernel tests (`r10-root-scripts.log`) |
| Root package (docs tests), as root | PASS, 343 (`r10-root-package.log`) |
| Firewall tests, unprivileged (user `ci`) | PASS, 50; the 4 root tests skip themselves (`r10-ci-firewall.log`) |
| `go vet ./scripts`, `gofmt -l` on the changed test file | clean |

I had already shown in 08 that the new test kills mutants A11 and A7. The writer's re-run at 1914fcb agrees. I did not repeat it, because the test file is byte-identical to the one I validated.

**CI.** Run 45314555921 on 1914fcb was in progress at 02:50Z. The repository requires "build, vet and test" to pass before merge.

Update at 03:26Z: the run passed. Every step of job "build, vet and test" (138178141175) succeeded, finishing at 03:23:32Z.

## Findings

None. A8-1 is closed.

## Effects and delivery

- Read-only.
  - Private clone `/opt/audit/ES10`.
  - No commit, push, comment, PR change or merge. The box was not contacted.
- This file and `11-delta-check-evidence/` (logs, manifests, `remerge-diff.txt`). Log scan for token and key patterns: no matches.

## Verdict

**ACCEPT** for head `1914fcb` (manifest `575f4c0d…103d`), CI on 1914fcb passed (run 45314555921).

Next (for the coordinator): box run 4 with David's go, and the merge gate.
