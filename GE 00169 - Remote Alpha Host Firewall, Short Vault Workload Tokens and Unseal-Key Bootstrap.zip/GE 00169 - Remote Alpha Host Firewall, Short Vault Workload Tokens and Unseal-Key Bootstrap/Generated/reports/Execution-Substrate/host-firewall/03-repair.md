# 03 — Repair of ES draft PR #35 after the 02 audit (BLOCK)

Writer: the PR #35 writer thread. Date: 2026-11-23.
Target for the narrow re-audit: head `27e8b64631cf5426774fdbeb198886abe0348aa1` on `claude/project-thread-vmre16`, base trunk_dev `fdfa3bc`, manifest `912de42517c13fb535fe0f07b3fca0f079ef8573f577eb67e0ff4e9cb266ec39`.

## Plain summary (for relaying)

All five blocking findings are fixed, the four surviving mutants the audit named now have killing tests (plus the four cheap pins), and the should-fix items F6, F7, F8, F9 and F10 are done too. Every fix has a test; the changed suites pass as root, unprivileged, and with PR #30's narrow root PATH. A mutation run over the repaired code killed 36 of 36 mutants (one needed an added test case).

trunk_dev moved during the round (#29, fdfa3bc). It is merged in a second commit with no conflict, and the PR's own diff against its base is byte for byte the same before and after that merge.

Two fixes go further than the audit's diff, on purpose:

1. **F1, Vault bootstrap.** Besides deferring signals (the audit's fix), the root token is now revoked with the request right after the 15-minute token is made, before Vault's configuration is put back. Before, the root token, which never expires, lived through the restore reload and its wait (up to about 80 s). Now it lives for two requests. That shrinks the one window no code can protect (SIGKILL, power loss) from about 80 s to milliseconds. And because "how to check afterwards" needed a root token David does not have, the helper now counts root tokens that never expire on every unseal-key run and warns; `REMOTE_ALPHA_BOOTSTRAP_STANDING_ROOT_TOKENS=revoke` revokes them.
2. **F3, layer 2.** The audit left the IPv6 decision open. The bridge table now drops all IPv6 between bridge ports. The kernel here cannot match on the bridge name (`meta ibrname` is not supported), and containers have no IPv6 subnet to match on, so the rule covers every bridge; `--plan` and `--apply` refuse while a bridge exists that is not a container interface. A new real-kernel test turns br_netfilter off and sends forged-source IPv4 and raw IPv6 frames between two containers: both arrive without the firewall, neither with it.

Nothing was run on the box in this round. The box still runs the run-3 ruleset, which already fails closed on both F2 and F3 there (br_netfilter is active on the box). The new ruleset differs from the installed one, so `--status` on the box will say "current settings do not render the installed ruleset" once this branch is used. The re-apply belongs after the red-team, before or at merge (see section 5).

## 1. Target

| Item | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| PR | #35 (draft), branch `claude/project-thread-vmre16` |
| Audited head | `0c95eb71afef4343d02fce3c05d9ff93cc6eea52` (02 audit, BLOCK) |
| Repair commit | `10bfe9b0ae8ec0d27087a07b51484a345e5442e8`, one commit on top of 0c95eb7 |
| Head | `27e8b64631cf5426774fdbeb198886abe0348aa1` (10bfe9b with trunk_dev fdfa3bc merged, no conflict), tree `09b2e7e4d4bea761fb5c97e8c50c09fd73b72ceb` |
| Base | `trunk_dev` `fdfa3bc67cdedb11f583a19df7036c20c612741f` (#29 merged; the 02 audit's base was 76c030f) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified) |
| Manifest SHA-256 (head vs base) | `912de42517c13fb535fe0f07b3fca0f079ef8573f577eb67e0ff4e9cb266ec39` (taken twice in a fresh clone of the pushed head, HEAD reset to the base, upstream pinned; identical) |
| textual_diff_sha256 | `f2a54f6e461f718365b8a7cbc778a8a2ddc29d882d46dae9316dd14c98e43aff` |
| Changed paths vs base | 12 (the same 12 as the 02 audit) |
| Delta for the narrow re-audit | `git diff 0c95eb7 10bfe9b`: 10 files, +1321 −144; plus the merge commit 27e8b64 (`merge-check.txt`) |

The repair commit touches only files already in the PR. Its diff against 0c95eb7 is in `03-repair-evidence/repair.diff`; the manifests are in `03-repair-evidence/manifests/`.

The merge commit brings in #29 (29 paths, es/admission and docs). It overlaps the PR only in `PLANS.md`, which merged automatically. `merge-check.txt` compares `git diff 76c030f 10bfe9b` with `git diff fdfa3bc 27e8b64`, with index lines and hunk positions dropped: identical. So the re-audit can read the repair as `repair.diff` and the merge as provenance only.

## 2. Findings, one by one

### F1 (medium): signals between generate-root and the revoke

File: `scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh`.

Kept from `02-audit-fix.diff`, after review:

- `import signal`, `BootstrapInterrupted(BaseException)`, handlers for SIGTERM, SIGHUP and SIGQUIT installed at the start of `main`.
- `pthread_sigmask(SIG_BLOCK, {INT, TERM, HUP, QUIT})` around the whole authority section, restored in `finally`. Subprocesses inherit the mask, so a Ctrl-C to the process group does not cut the reload short either.
- `except (KeyboardInterrupt, BootstrapInterrupted)` in `main`.

Changed from the diff:

- The exit code is 128 plus the signal number (130 INT, 143 TERM, 129 HUP, 131 QUIT), not 130 for all. The summary records `failure_class=interrupted`, `failure_message_class` the signal name, and a new `interrupted_by`. The output says `Interrupted by SIGxxx; cleanup ran before exit.`
- Right after the masked section, `next_operation` is set to `standing_root_tokens`, so a signal delivered on unmask reports a real phase, not `unexpected`.
- The post-run messages are now derived from the recorded operations, not from a local flag, so they are right on every exit path (the diff left the restore-failure path without the "short-lived token revoked" line).
- Token values are appended to the redaction-scan list as soon as each exists, so the summary scan also covers failure paths. Before, a failure inside the authority section lost them.

Added beyond the diff:

- **Order (a design change).** Old order: generate-root, put the configuration back (write, reload, wait up to 20 s), create the 15-minute token, revoke the root token. New order: generate-root, create the 15-minute token, revoke the root token (the very next request), then put the configuration back. The root token, which never expires, now exists for two requests instead of through a reload and its wait. If the restore then fails, the 15-minute token is revoked and the run fails with `vault_config_restore_failed`, as before. All configuration requests still come after the restore. Generate-root stays open for two requests longer than before, which matters less: using it needs the unseal key, and on a one-share Vault the key holder can already make root. `generate_root_token` (the old wrapper) is gone; `create_short_lived_token` is split out of `make_short_lived_authority`.
- **(c) Refuse a Vault that is open while the file is clean.** With `temporary-config`, a Vault that answers generate-root without a token while `VAULT_CONFIG_PATH` does not mention `enable_unauthenticated_access` is refused with `generate_root_access_open_outside_config_file`: at `generate_root_access_preflight` (before the key prompt) and again inside generate-root (if Vault opens in between). The output says to reload Vault, or to use `as-configured` if the setting is meant to stay on. This replaces the old "Vault that allows it is not touched" path, as the audit recommended.
- **(d) How to check after SIGKILL or a power loss.** Checking for a leftover root token needs a root-level token, which David does not have. So with `unseal-key`, after the 15-minute token exists and before any configuration, the helper lists token accessors, looks each up, and counts root-policy tokens with no `expire_time` or with a `period` (operation `standing_root_tokens`). It warns when any exist. `REMOTE_ALPHA_BOOTSTRAP_STANDING_ROOT_TOKENS=revoke` (unseal-key only, validated with the other choices) revokes them with `auth/token/revoke-accessor`. An accessor that is gone by lookup time (HTTP 400) is skipped. The summary records counts only, never accessors. A failure of the check fails the run before configuration, and the 15-minute token is still revoked.
- Docs: a new "Signals and interrupted runs" block in the P0q-R1 subsection, covering what SIGKILL and a power loss can leave, how each leftover is found, and what to do. The PLANS.md slice and the helper's `--help` are updated too.

Tests:

- New `TestRemoteAlphaVaultWorkloadAuthBootstrapSignalsWithRealVault` (adapted from `zz_audit_signal_regression_test.go`), against a real Vault 2.2.2. SIGINT, SIGTERM, SIGHUP and SIGQUIT during the restore reload, and SIGINT, SIGTERM and SIGHUP during the enable reload. For each case it checks:
  - the exact exit code;
  - both reloads ran;
  - the accessor list is unchanged;
  - `vault.hcl` is byte-identical;
  - unauthenticated generate-root answers 403;
  - no attempt is left open;
  - no `jwt/` auth mount exists, so no configuration ran after the signal;
  - the summary records `interrupted_by`;
  - neither secret appears in the output or the summary.
- Real-Vault run 1 now expects `WARNING: Vault holds 1 root token(s) that never expire.` (the initial root token). A new last run with `revoke` expects `Revoked 1 root token(s)` and checks that the initial root token's lookup-self answers 403.
- Fake Vault: create-orphan returns an accessor, plus LIST accessors, lookup-accessor and revoke-accessor.
  - The order test now pins that the root revoke is the request right after create-orphan, and that the accessor check comes before configuration.
  - The temporary-config test pins that the root token is created and revoked while access is still open, and that access is closed before the first configuration request.
  - New cases: `vault_open_but_file_clean`, `vault_opens_after_preflight`, `standing_root_token_check_fails`, and `TestRemoteAlphaVaultWorkloadAuthBootstrapStandingRootTokens` (report and revoke, with standing, periodic, expiring-root, workload and vanished accessors).
  - Two new invalid-choice cases.
- F9 is fixed in the same file: the real-Vault client timeout is 60 s (it was 10 s), and a transport error now carries its message, so `%!s(<nil>)` is gone.

### F2 (low): published ports

Kept as in the diff: `ct state new counter name "into_container" drop`, with the comment, doc sentence and test pin "no new connection into a container is forwarded, published ports (Docker DNAT) included", plus the DNAT lab case. The doc adds that a port published later stays closed until this rule changes. The validation bullet now says "a Docker-style published port that must stay closed". The invariants test pins the rule and forbids any `ct status` match.

### F3 (low): layer 2 between containers

- IPv4 rule as in the diff: `ether type ip ip daddr {subnet} … drop`.
- **IPv6 decision: covered, not declared out of scope.** New rule `ether type ip6 counter name "container_to_container" drop` in the bridge table's forward chain.
  - Why not keyed on the container bridges: `meta ibrname` fails here with "Operation not supported" (`nft -c`, nftables 1.0.9, kernel 6.18), so a name-keyed rule would not be testable here and might not load everywhere.
  - Why not keyed on an address: the containers have no IPv6 subnet to key on.
  - The bridge forward hook carries only port-to-port frames, so the rule never touches traffic to or from the host.
  - The rule therefore covers every bridge, and new checks keep that scope exact. `--plan` and `--apply` list every bridge (`ip -o link show type bridge`, new Python command `bridges`) and fail "every bridge is a container interface" while one is not.
- br_netfilter detection reads `/proc/sys/net/bridge/bridge-nf-call-iptables` and `-ip6tables`, which exist whether it is a module or built in. Host facts print both values, plus the bridge list.
- New `TestRemoteAlphaHostFirewallRealKernelBridgeIsolation` (root, listed `skips-itself`):
  - it turns `bridge-nf-call-iptables`, `-ip6tables` and `-arptables` off in the box namespace, so only the bridge table stands between the containers;
  - it sends three IPv4/UDP frames with the forged source 203.0.113.99 and three IPv6/UDP frames ([home network address withheld] to [home network address withheld]) from c1 to c2's MAC address, over AF_PACKET, so no IPv6 kernel is needed;
  - without the firewall, c2 receives `ipv4=3 ipv6=3`; with it, `ipv4=0 ipv6=0`, and the bridge counter is exactly 6;
  - containers still reach Vault, DNS and the internet.
- Docs: the bridge bullet now says "whatever source address a container writes … and no IPv6 frame passes from one bridge port to another", and gives the scope and refusal.

### F4 (low): PR #30's root PATH

Kept as in the diff: `requireHostFirewallLab` appends `/usr/sbin:/sbin` to PATH. All four root tests pass with `sudo -n -- /usr/bin/env -i PATH=/usr/bin:/bin`, the new bridge test included (section 4).

Owned by whichever of #30 and #35 lands second: the runner packages (`nftables`, `iproute2`, `openssh-server`) and a trial merge with the root step green. That step will also be the first run of the IPv6 lab subtests, since the runner kernel has IPv6.

### F5 (low): loopback or out-of-source confirm

Kept as in the diff (`new-ssh-peer` skips recorded, non-IP, loopback and out-of-source peers, IPv4-mapped normalized), with the tests for `127.0.0.1`, `::1` and `10.20.30.40`. Added: the loopback cases again with loopback networks inside `SSH_SOURCES` (the settings accept them), so the loopback rule is tested on its own (mutant N30). The doc and `--help` now say so under `--confirm`.

### F6 (low): a reboot inside the confirm window

- The apply records (candidate, rollback file, rollback.sh, the previous drop-in, peers) now live in `/var/lib/es-host-firewall` (setting `RUN_DIR`), not `/run`.
- `--apply` writes a marker, `unconfirmed`, before it arms the timer. `rollback.sh` removes it as its last step (the timer, or a failed apply undoing itself), and so do `--confirm` and `--rollback`. Each early-exit path of `--apply` removes it as well.
- "Marker present and no waiting timer" means the apply was cut short by a reboot. Then:
  - `--status` reports `unconfirmed apply: … run --rollback, then --apply again` and exits 1;
  - `--plan` and `--apply` fail the check "no earlier apply awaiting confirm" with the same instruction;
  - `--confirm` is refused (no waiting timer).
- New `TestRemoteAlphaHostFirewallUnconfirmedApplyRecords`, with fakes:
  - a pre-existing managed drop-in;
  - `--apply`, then `rollback.sh` run as the timer would run it: the previous drop-in is back byte for byte and the marker is gone, so `--plan` passes;
  - `--apply` again, then the timer vanishes: status, plan and apply report or refuse, and confirm is refused;
  - `--rollback` clears it, and `--plan` passes again.
- `--help` now lists the `--apply` refusals (SSH peer outside `SSH_SOURCES`, other bridges, container IPv6, an unconfirmed earlier apply), the records in `RUN_DIR`, and that `--rollback` removes them; `TestRemoteAlphaHostFirewallArgumentsAndRoot` pins those lines. The `--rollback` result line names the records too.

### F7 (observation): high-port UDP listeners

The classification line now reads `ephemeral range: taken as a client socket (replies only); a service here would be BLOCKED`, still with the owner process. The doc has a "Known limits" bullet. The behaviour is unchanged: it fails closed.

### F8 (observation): bound CIDR vs br-*/nomad, and the snat

Doc "Known limits" bullet. Containers on `br-*` or `nomad` reach Vault but their logins get a 403 until their subnet is added to `token_bound_cidrs`. The identity snat makes the bound CIDR limit by network, not by workload: a process on the box passes it, which the box's own check needs.

### F9 (observation): real-Vault flake

Fixed (see F1, Tests).

### F10 (low, latent): container IPv6

New Python command `container-ipv6` reads `ip -o -6 addr show scope global`. `--plan` and `--apply` fail "no container interface has IPv6" when a container interface holds a global or unique-local IPv6 address, and print the addresses. Unit test, plus a fakes test of the wiring. Doc "Known limits" bullet. On the box this passes today: Docker has no IPv6 there.

### F11, F12

- F11: no change. The IPv6 lab subtests still skip here; the first run is on the runner (F4).
- F12: this report and the manifest.

## 3. Mutants

Script: `03-repair-evidence/mutants.py` (each mutant replaces one exact string that must occur once, runs the prebuilt test binary for the named tests with `-test.failfast`, and restores the file byte for byte; file checksums were compared before and after the run). Log: `03-repair-evidence/mutants.log`.

| Mutant | File | Result | First failing test |
|---|---|---|---|
| R2 no invalid drop | firewall | killed | `TestRemoteAlphaHostFirewallRulesetInvariants` |
| R6' published-port flag test | firewall | killed | `TestRemoteAlphaHostFirewallRulesetInvariants` |
| R9 echo without limit | firewall | killed | `TestRemoteAlphaHostFirewallRulesetInvariants` |
| D1 drop-in keeps kbd-interactive | firewall | killed | `TestRemoteAlphaHostFirewallSSHDDropInWithRealSSHD` |
| S5 ssh-peers check ignored | firewall | killed | `TestRemoteAlphaHostFirewallApplyRefusesSSHPeerOutsideSources` |
| S8 rollback.sh does not restore drop-in | firewall | killed | `TestRemoteAlphaHostFirewallUnconfirmedApplyRecords` |
| B3 restore skips refusal wait | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapTemporaryGenerateRootAccess` |
| B7 attempt-in-progress check removed | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapUnsealKeyAuthorityFailures` |
| N1 no signal mask | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapSignalsWithRealVault` |
| N2 no TERM/HUP/QUIT handlers | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapSignalsWithRealVault` |
| N3 interrupted not caught | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapSignalsWithRealVault` |
| N4 restore before child/root revoke (old order) | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapTemporaryGenerateRootAccess` |
| N5 no restore on failure path | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapUnsealKeyWithRealVault` |
| N6 child not revoked after restore failure | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapTemporaryGenerateRootAccess` |
| N7 preflight accepts open access | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapTemporaryGenerateRootAccess` |
| N8 generate accepts open access | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapTemporaryGenerateRootAccess` |
| N9 standing never counted | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapUnsealKeyWithRealVault` |
| N10 periodic root not standing | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapStandingRootTokens` |
| N11 revoke mode does not revoke | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapUnsealKeyWithRealVault` |
| N12 vanished accessor fails run | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapStandingRootTokens` |
| N13 standing check skipped | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapUnsealKeyWithRealVault` |
| N14 revoke allowed with root-token | bootstrap | killed | `TestRemoteAlphaVaultWorkloadAuthBootstrapRejectsInvalidChoicesBeforePromptsAndVaultWrites` |
| N20 bridge rule needs source too | firewall | killed | `TestRemoteAlphaHostFirewallRulesetInvariants` |
| N21 no IPv6 bridge rule | firewall | killed | `TestRemoteAlphaHostFirewallRulesetInvariants` |
| N22 br_netfilter via /sys/module | firewall | killed | `TestRemoteAlphaHostFirewallApplyRefusesOtherBridgesAndContainerIPv6` |
| N23 bridges check ignored | firewall | killed | `TestRemoteAlphaHostFirewallApplyRefusesOtherBridgesAndContainerIPv6` |
| N24 bridges command passes all | firewall | killed | `TestRemoteAlphaHostFirewallBridgesAndContainerIPv6` |
| N25 container-ipv6 check ignored | firewall | killed | `TestRemoteAlphaHostFirewallApplyRefusesOtherBridgesAndContainerIPv6` |
| N26 container-ipv6 never finds | firewall | killed | `TestRemoteAlphaHostFirewallBridgesAndContainerIPv6` |
| N30 confirm accepts loopback | firewall | survived, then killed (see below) | `TestRemoteAlphaHostFirewallSSHPeerChecks (after the added case)` |
| N31 confirm accepts outside sources | firewall | killed | `TestRemoteAlphaHostFirewallSSHPeerChecks` |
| N40 no unconfirmed marker | firewall | killed | `TestRemoteAlphaHostFirewallUnconfirmedApplyRecords` |
| N41 rollback.sh keeps marker | firewall | killed | `TestRemoteAlphaHostFirewallUnconfirmedApplyRecords` |
| N42 checks ignore leftover | firewall | killed | `TestRemoteAlphaHostFirewallUnconfirmedApplyRecords` |
| N43 status ignores leftover | firewall | killed | `TestRemoteAlphaHostFirewallUnconfirmedApplyRecords` |
| N44 confirm keeps marker | firewall | killed | `TestRemoteAlphaHostFirewallApplyConfirmRollbackOrderWithFakes` |

Result: 36 mutants, 35 killed in the first run, and 36 of 36 after one added test case.

- **N30 survived the first run.** Every loopback case in the test used an `SSH_SOURCES` without a loopback network, so the source check skipped those peers as well and the loopback check was never the deciding rule. The settings accept a loopback network in `SSH_SOURCES`, so the mutant is not equivalent. `TestRemoteAlphaHostFirewallSSHPeerChecks` now also runs with `SSH_SOURCES="[home network address withheld]/24 127.0.0.0/8 ::1/128"`: a LAN connection opened after `--apply` still counts, and `127.0.0.1`, `::1` and `::ffff:127.0.0.1` still do not. Re-run: killed (`mutants-N30-rerun.log`).
- **Behaviour, not only text.** The invariants test kills R6', N20 and N21 by reading the rendered ruleset. To show the real-kernel tests catch the behaviour too, the three were run again as root with only `^TestRemoteAlphaHostFirewallRealKernel`: R6' is killed by `TestRemoteAlphaHostFirewallRealKernelTraffic` (the published-port case), N20 and N21 by `TestRemoteAlphaHostFirewallRealKernelBridgeIsolation` (`mutants-behavioural.log`).
- The audit's surviving mutants R6, S5, S8 and B3 and its pins R2, R9, D1 and B7 are the first eight rows.

## 4. Validation

| Run | Bytes | Result | Log (`03-repair-evidence/validation/`) |
|---|---|---|---|
| Root: the changed suites (`TestRemoteAlphaHostFirewall`, `TestRemoteAlphaVaultWorkloadAuthBootstrap`), real kernel, real sshd, real Vault 2.2.2 | 10bfe9b (the working tree's diff hash at the start equals `git diff 0c95eb7 10bfe9b`, `tree-state-10bfe9b.txt`) | 119 pass, 0 fail, 5 skip | `root-targeted-10bfe9b.log` |
| PR #30's root step: `sudo -n -- /usr/bin/env -i PATH=/usr/bin:/bin`, the four root-only tests | 10bfe9b | 4 pass, 0 fail, 2 skip | `pr30-root-path-10bfe9b.log` |
| Root: the changed suites again | 27e8b64 | 119 pass, 0 fail, 5 skip | `root-targeted-27e8b64.log` |
| Unprivileged (uid 65534, as on the runner): the whole root package minus the 11 environment-only entries | 27e8b64 | 2132 pass, 157 fail in 10 top-level tests, 7 skip | `unpriv-root-package-27e8b64.log` |
| The same 10 tests, unprivileged, same container | base fdfa3bc | the same 157 failures | `base-fdfa3bc-same-tests.log`, `failing-27e8b64.txt` = `failing-fdfa3bc.txt` |
| Unprivileged: the bootstrap suites with Vault 2.2.2 on PATH (the whole-package run above had no Vault on its PATH, so its two real-Vault tests skipped there) | 27e8b64 | 81 pass, 0 fail, 0 skip | `unpriv-bootstrap-real-vault-27e8b64.log` |

- The skips: the three IPv6 lab subtests (this kernel has no IPv6; F11), and, as root, two bootstrap tests that skip themselves as root and pass in the unprivileged run.
- The 10 failing tests fail identically on the base in this container, so none comes from this PR, and none is a host-firewall or bootstrap test. They are the `en_US.UTF-8` variants of the operator byte-stable matrices (the `C` variants pass), a `git ls-files` refusal for uid 65534 in a root-owned checkout, and TLS-status and operator fixtures. The CI runner is the gate for them.
- Mutants: 36 of 36 killed, and the 3 behavioural re-runs killed (section 3).
- Static checks: gofmt on the three changed Go files; `go vet` for linux and `GOOS=darwin`; `bash -n` on the three scripts; `py_compile` on the firewall's Python and on the bootstrap's embedded Python; no untracked or generated files left (the `__pycache__` that `py_compile` made was removed before the commit).
- CI "build, vet and test" on 27e8b64: success (run 45271110605, 21:34 to 22:07 UTC), including the CI gate's check that the tests which skip themselves on the runner are exactly the listed ones, the new bridge test among them. So both real-Vault tests ran on the runner too: they are not listed, and a skip would have failed the gate.

## 5. Box

The box was not touched in this round, and none of the fixes needs a box run to be safe. On the box, br_netfilter is active, so the inet chain already drops the forged-source and IPv6 cases. The F2 rule already failed closed. F6 and F10 add checks, not rules.

The repaired ruleset differs from the installed run-3 ruleset only in the bridge table and the forward rule. After the red-team, a box run should:

1. Run `--plan`, which also exercises the new bridge, container-IPv6 and br_netfilter lines on the real host.
2. Run `--apply` and `--confirm`.
3. Run `--status` and `--probe`.
4. Run the workload-auth check again.

That would be run 4, recorded as usual.

## 6. Remaining uncertainty

- `meta ibrname` support on the box kernel is unknown. It is no longer needed.
- The IPv6 lab has never run (no IPv6 kernel here). First run: the runner, via #30's root step.
- Real `systemctl reload vault.service` timing under a signal. The real-Vault test forces the timing with a reload command that signals the helper.
- Docker's IPv6 link-local behaviour on the box. The IPv6 bridge rule covers it either way.

## 7. Effects

- Two commits pushed to `claude/project-thread-vmre16`: the repair 10bfe9b and the trunk_dev merge 27e8b64.
- PR #35 description updated for the new behaviour and review state.
- Report and evidence written under this folder.
- No PR comment and no merge. The box was not contacted.
