# Red-team of ES PR #35 (box host firewall) — 07-redteam

Target: Execution-Substrate draft PR #35, branch `claude/project-thread-vmre16`,
head `6a9d4c742941beeaeca1dc417b6713c18ae9360f`, tree
`7cf3383c82cc325a9333bf90baef85c5249a83ca` (verified by fetch; the head did not
move during the pass). `trunk_dev` was `42db33920d9a402e28f4f7c2344c66d8f1115215`
at the end of the pass; a trial merge of it onto the PR head is clean.

Scope (coordinator's brief): try to break host or container isolation — reach
SSH, ES or AGS from anything other than [home network address withheld], container-to-container,
container-to-LAN and IPv6 paths; leak or keep the Vault root token through a
crash or a signal mid-run; and find a way the apply/confirm/rollback flow leaves
the box locked out or open. Local lab only, no access to the real box or the home
network, read-only.

Everything here was produced in a cloud container by the root user with Go
1.26.5, nftables, iproute2 and network namespaces. Nothing was committed or
pushed. The real box, Docker, a real Vault and a real sshd were not used (see
"What this pass did not cover"). Evidence: `07-redteam-evidence/`. Writer patch
(two new failing tests): `07-redteam-finding-tests.patch`.

## Outcome in one line

The isolation and flow defences hold for everything that can be exercised here;
the PR's own test suite passes in full. Two Low findings on the edges: RT07-1,
`--status` (and the boot unit) report a healthy firewall after a crash that
leaves the installed ruleset empty, when in fact no tables are loaded and the box
is open at the nft layer; RT07-2, the Vault bootstrap does not disable core
dumps, so a crash can persist a secret to disk — this one sits at the edge of the
PR's stated "not protection against root" boundary. No way was found to defeat
the container or LAN isolation itself.

## Method

- Read the two firewall scripts, the Vault workload-auth bootstrap helper, the
  golden ruleset and unit, the three test files, and the "Remote Alpha Host
  Firewall" doc section. SHA-256 of each cited file at the head is in
  `07-redteam-evidence/head/pr-file-sha256.txt`.
- Ran the PR's own test suite as root, including the real-kernel namespace tests
  that load the rendered ruleset and send real traffic. Source: run.
- Probed the gaps the suite does not cover (status reporting after a crash, the
  no-fsync install, the bootstrap's crash/signal handling), and wrote a failing
  regression test for each finding plus a scratch candidate fix (evidence only,
  not proposed code) to show the test discriminates and does not break the PR's
  own tests.

## What holds (verified here)

The PR's suite passes in full at the head (`07-redteam-evidence/logs/delivered-head.log`):
all 20 `TestRemoteAlphaHostFirewall*` tests pass; the IPv6 traffic subtests and
the real-sshd test skip for lack of a kernel-IPv6 stack and an `sshd` binary. In
particular the real-kernel tests confirm, for IPv4, that:

- a container reaches only `VAULT_ADDRESS:VAULT_PORT` on the host and nothing
  else (`RealKernelTraffic`);
- with `br_netfilter` off in the lab, forged-source IPv4, raw IPv6, VLAN-tagged
  and ARP frames sent between two containers do not arrive at the other
  (`RealKernelBridgeIsolation`) — the layer-2 tricks the 06 auditor asked about;
- a Docker-style published port stays closed;
- `--apply`, `--confirm`, `--status` and `--rollback` run in order and the source
  SNAT reports `REWRITTEN` to the LAN address without the firewall and `kept`
  with it (`RealKernelApplyConfirmRollback`).

The Vault bootstrap's deferral of the catchable termination signals is covered by
the PR's own `TestRemoteAlphaVaultWorkloadAuthBootstrapSignalsWithRealVault`
(reading): SIGINT/SIGTERM/SIGHUP/SIGQUIT delivered during either reload of the
generate-root window are deferred, both reloads run, the generated root token is
revoked, Vault's config is restored byte for byte and generate-root is refused
again. I did not re-run it here (needs the Vault 2.2.2 binary). By reading, the
generated root token exists only inside `make_short_lived_authority`, is revoked
within two requests, and SIGKILL / power-loss are documented as not deferrable
with next-run recovery (`check_standing_root_tokens`,
`refuse_open_generate_root_access`). I found no undocumented way to keep or
surface the token through the catchable signals.

No new network-isolation bypass was found.

## Findings

### RT07-1 — `--status` and the boot unit report a healthy firewall when a crash leaves the installed ruleset empty (Low; bug + monitoring gap; introduced by this PR)

`remote_alpha_host_firewall_install_file` (scripts/internal/remote_alpha_host_firewall.sh
lines 780-788) writes a file with `mktemp` + `cat` + `mv -f` and never fsyncs the
temp file or its directory. On ext4 with the default `data=ordered`, a crash or
power loss just after `--confirm` can leave the renamed `es-host-firewall.nft`
and `es-host-firewall.listing` present but zero bytes (the rename is journalled,
the data is not yet on disk). Both files are installed this way (lines 861, 868).

`--status` (lines 909-919) then misreports:

- line 909 gates "installed ruleset: none" on `! -f` (file absent), not on an
  empty file, so two 0-byte files pass as "installed";
- `remote_alpha_host_firewall_live_listing` prints nothing when no tables are
  loaded, so `live_listing | cmp -s - listing` compares empty to empty and prints
  "loaded tables: match the installed ruleset".

With the sshd drop-in and the unit surviving (the common case — only the two
state files were truncated), `--status` prints `RESULT: installed and unchanged`
and exits 0 although no `es_host_firewall` tables are loaded: the box is open at
the nft layer while the operator's one monitoring command says healthy. The unit
makes it worse: `ExecStart=/usr/sbin/nft -f .../es-host-firewall.nft` on an empty
file succeeds and loads no tables, so after a reboot the unit is active with no
firewall and `--status` still reports health.

Source: run. `07-redteam-evidence/logs/delivered-head.log` shows
`TestRemoteAlphaHostFirewallStatusRefusesEmptyInstalledRulesetAfterCrash` driving
a real `--apply`/`--confirm`, truncating both files, dropping the loaded tables,
and getting exit 0 "installed and unchanged" with "loaded tables: match".

Realism: needs a crash in the small window after `--confirm`'s rename and before
the data is flushed. Narrow, but the impact is a silently open box, and the box
runs on home power. Low.

Fix: `--status` should treat an empty or no-longer-parseable installed ruleset as
not installed (and ideally confirm the tables exist with `nft list table …`
rather than comparing a possibly-empty listing); the installer should fsync the
temp file and the directory before and after the rename so a crash leaves either
the old file or the whole new file, never a 0-byte one. A one-character
illustration (`! -f` → `! -s` on line 909) already clears the regression test and
leaves the PR's own flow tests green
(`07-redteam-evidence/candidates/candidate-fix-RC07.diff`,
`07-redteam-evidence/logs/candidate-pass.log`); the writer should decide between
that, a tables-exist check, the fsync, or all three.

Regression test: `TestRemoteAlphaHostFirewallStatusRefusesEmptyInstalledRulesetAfterCrash`
in the patch. Fails at the head, passes under the candidate.

### RT07-2 — the Vault bootstrap does not disable core dumps, so a crash can persist a secret to disk (Low; secret hygiene / defense-in-depth; at the edge of the stated "not protection against root" boundary)

The bootstrap helper
(scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh) holds the unseal
key, the generated root token, the short-lived token and the proof secret in
ordinary Python memory and takes care to keep the generated root token alive for
only two requests (the comment at lines 956-963). It never lowers the core-dump
limit: there is no `resource.setrlimit(RLIMIT_CORE, …)`, no `prctl(PR_SET_DUMPABLE)`
and no `ulimit -c 0` in the bash wrapper (reading; the finding test below also
fails for want of any of these). So a crash while a secret is in memory — a
genuine fault, or `kill -ABRT`/`-SEGV`, neither of which is in the deferred set —
produces a core file. On this box's Ubuntu that goes to systemd-coredump under
`/var/lib/systemd/coredump/`, where it persists (root-readable) long after the
run. That defeats the deliberate minimal-lifetime design: the secret the helper
works to keep in memory for two requests ends up on disk indefinitely.

Boundary: reading the core, and sending an arbitrary crash signal, both need
root or the same user, and the doc's Non-claims say the firewall is "not
protection against root on the box". So this sits at the edge of the stated
threat model and may be judged out of scope. It is still worth raising because
(a) a *genuine* crash (not an attacker) is enough to leak, and (b) the whole
point of the helper's design is minimal secret lifetime, which a core dump
undoes. Severity Low / defense-in-depth; the writer and David decide whether to
adopt.

Source: reading + run. The finding test fails at the head and passes once the
helper disables core dumps.

Fix: before reading any secret, `import resource;
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))` (and/or `prctl(PR_SET_DUMPABLE, 0)`
via ctypes). Illustrated in the candidate diff; it clears the test.

Regression test: `TestRemoteAlphaVaultWorkloadAuthBootstrapDisablesCoreDumpsBeforeSecrets`
in the patch (a source contract, in the style of the existing
`…SourceKeepsPreflightAndBoundaries`). It accepts any of the usual disablers and
requires one before the first secret prompt.

## Minor observations (report-only; under the stated boundary; no separate tests)

- SIGTSTP is not blocked or ignored during the generate-root window
  (`DEFERRED_SIGNALS` is INT/TERM/HUP/QUIT; the `pthread_sigmask` at line 1574
  wraps only `make_short_lived_authority`). An accidental Ctrl-Z there stops the
  process with the temporary-config `enable_unauthenticated_access =
  ["generate-root"]` setting live until it resumes or is killed. Deliberate
  freezing is inherent — SIGSTOP can never be blocked — so blocking SIGTSTP only
  closes the accidental path; a kill while stopped is recovered next run by the
  leftover-marker detection. Low; include SIGTSTP (and SIGTTIN/SIGTTOU) in the
  masked set if the writer wants the accidental case closed. Source: reading.
- Secrets are held as plain Python `str`, not `mlock`ed, so they can be paged to
  swap. Not claimed by the design; defense-in-depth only. Source: reading.

## What this pass did not cover

- IPv6 real traffic: the cloud kernel has no IPv6 (`/proc/sys/net/ipv6` absent),
  so the suite's IPv6 subtests skip. The doc documents the IPv6 limit (containers
  with IPv6 could reach the LAN's global-prefix hosts because the forward chain
  blocks only private IPv6 ranges) and `--apply`/`--status` refuse or flag a
  container interface that has a global/ULA IPv6 address; that refusal path is
  verified here for IPv4 inputs, the IPv6 traffic path itself is not.
- The real box, a running Docker daemon, a real Vault (2.2.2) and a real sshd:
  not available here. The real-sshd test and the real-Vault bootstrap/signal
  tests skip; a live `--probe` was not run. Isolation was exercised with the
  suite's own network-namespace real-kernel tests instead, which is the method
  the PR itself uses.
- The guard, other ES admission work, and anything outside PR #35.

## Box checks that would confirm this, if David wants them (need his go; box only)

- On a box with the Vault 2.2.2 binary, run
  `TestRemoteAlphaVaultWorkloadAuthBootstrapSignalsWithRealVault` and the
  real-sshd test to re-confirm the signal deferral and the drop-in on real
  tooling.
- RT07-1 on the box is awkward to stage (it needs a power cut at the exact
  moment); the regression test stands in for it. If wanted, truncating the two
  state files by hand and running `--status` reproduces the misreport.

## Pointers

Earlier audit: `06-re-audit.md` (ACCEPT). Method notes for this lab:
[[es-host-network-audit-lessons]]. Finding record: [[es-pr35-red-team-07]].
