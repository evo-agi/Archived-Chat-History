Got it: ES and AGS will accept only [home network address withheld], your reserved Mac address. The allowed list goes into a small settings file on the box that the firewall script reads. Adding a device later means adding one address to one line and re-running the script.

I'm adding that settings file now. Meanwhile your Mac is doing the read-only checks on the box, and the firewall goes on right after that.

STATUS: WORKING (box run in progress; next update when the firewall is on and checked)
