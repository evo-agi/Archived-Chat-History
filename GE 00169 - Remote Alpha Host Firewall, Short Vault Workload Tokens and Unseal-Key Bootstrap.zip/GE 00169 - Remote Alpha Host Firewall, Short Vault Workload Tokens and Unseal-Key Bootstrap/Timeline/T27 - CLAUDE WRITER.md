Handed the machine session instructions

Update to the box run: please do steps 0 to 3 only (all read-only), report their output, and then STOP before step 4. Do not copy anything to the box or run --plan/--apply yet. A new commit with a persistent settings file is coming, with new hashes and revised steps 4 onward. Also add to step 1: report whether the Mac's current address on that interface is exactly [home network address withheld] (David just reserved that address for the Mac on the router). Keep the folder $T for now.
