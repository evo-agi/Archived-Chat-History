Found it, and nothing is needed from you. Vault was turning down the login because of where it thought the request came from, not because of the token or the Vault step.

Docker rewrites the box's own connections to Vault (172.17.0.1) so they appear to come from the box's Wi-Fi address. The new address limit on the Vault role only lets 172.17.0.x in, so it refused the box. Workload containers are not affected. I reproduced this in a test setup.

The fix is one rule in the firewall's own table that keeps the box's real address on its connections to Vault. Nothing in Vault changes, so your unseal key isn't needed again. Tests and docs are pushed, and the box run (plan, apply, confirm, probe, then the login check again) is running now from your Mac.

STATUS: WORKING
