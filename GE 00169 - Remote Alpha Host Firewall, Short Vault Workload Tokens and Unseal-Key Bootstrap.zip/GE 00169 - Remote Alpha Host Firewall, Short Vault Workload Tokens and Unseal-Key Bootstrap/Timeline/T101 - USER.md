> Two things you could approve now so work keeps moving while you're out:


Approved for the box runs, and please give the thread(s) a heads up on possible WiFi connectivity issues.

For the tester identity, I think I already answered them in the thread.
