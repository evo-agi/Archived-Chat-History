The box's workload login to Vault works again: the firewall was making the box look like it came from the Wi-Fi address, and one rule fixed it. All checks pass and nothing was restarted. One small click when convenient: the safety filter blocked me from merging the runbook update, so please press merge on [Archived-Runbooks PR 3](https://github.com/evo-agi/Archived-Runbooks/pull/3). It's docs only and leak-checked.

STATUS: NEEDS DAVID (merge runbook PR 3, low priority)
