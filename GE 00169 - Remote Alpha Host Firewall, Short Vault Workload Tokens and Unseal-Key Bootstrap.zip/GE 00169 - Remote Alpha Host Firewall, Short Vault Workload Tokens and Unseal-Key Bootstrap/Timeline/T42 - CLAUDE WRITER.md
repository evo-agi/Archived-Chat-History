The Vault part worked. The one failing line is the workload login, so I'm finding out why before I ask you for anything else.
