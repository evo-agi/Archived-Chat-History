The infrastructure audit is done: 22 findings, each with a quick mitigation and a proper fix, in a budget-sized order. The application code is in much better shape than the hand-built box setup around it. The top risks:
1. A run with network access can reach your home network (router, Mac, NAS). Nothing runs on the box now, so this needs fixing before the next run.
2. ES's Nomad key could still start a root container that mounts the whole disk. That's a design call for later.
3. The box was configured by hand, so fixes can't be reviewed or reapplied after a rebuild.

Three of its items are now part of the Nomad lock, mainly HTTPS, which PR 12 needs anyway. Next comes a small change: a firewall rule plus short Vault login lifetimes.

Three questions, none blocking, but the third shapes the firewall:
1. Is the Codex secret in the box's Vault a real OpenAI key?
2. Which machines call ES and AGS over your network?
3. Is the box on your main Wi-Fi or a separate network?

STATUS: NEEDS DAVID (the three answers when you can; the instructions draft answers are also open)
