Yes, this one is about your Mac: which devices can reach ES and AGS on the box. "Any home device" is simpler, but it would let every phone, TV and smart plug on the main Wi-Fi reach ES. A compromised gadget would then be one hop from the system that runs code. Since only your Mac calls ES and AGS, I'd keep it Mac-only and reserve your Mac's IP on the router, the same way the box's is. Adding a device later is a one-line change. Want to go with that?

STATUS: waiting on you for this choice, SSH passwords, archive names and the two instructions-draft answers.
