R1 is fixed and PR #35 is ready for the narrow re-audit at head `6a9d4c742941beeaeca1dc417b6713c18ae9360f`, with base trunk_dev `0aa4a2b` and manifest `dc5b53b74e59e1146a8819101cbc46fb06e9e7195926c9c0f30322033d2c1297`. I took the manifest twice in a fresh clone and both runs match.

- **R1:** I applied the re-audit's fix as written. The bridge table now drops every frame between bridge ports. The extended real-kernel test passes: VLAN-tagged, ARP and both IP kinds all go from 3 frames to 0.
- **One step beyond the diff:** I retired `CONTAINER_BRIDGE_SUBNETS`. With the drop-all rule the bridge check would have reported a container bridge as "NOT isolated", which is false. A settings file that still names it is now refused. The box's settings file doesn't use it.
- **R2 is also done.** `--status` now repeats the bridge check and the container-IPv6 check.
- **Marker tests:** I added the two you asked for (arming the timer fails, nft refuses the ruleset) plus a third early exit. None leaves an `unconfirmed` marker.
- **Mutants:** 14 of 14 killed.
- **Local tests:** the changed suites pass as root, as an unprivileged user and with PR #30's root PATH.
- **CI:** still running. It started at 23:08 UTC, and I'll report it if it fails.

The delta to re-audit is `05-repair-evidence/repair.diff`. What goes beyond the 04 fix is in `beyond-04-fix.diff`. I haven't touched the box; run 4 still waits for the red-team.

STATUS: WAITING (narrow re-audit)
