The firewall is on the test box and every check passed.

- **Your Mac ([home network address withheld])** still reaches ES, AGS and SSH. No other home device can reach them now.
- **Containers on the box** can reach Vault, DNS and the internet. They can't reach your router, your other devices, the box's own services or each other. Counters on the box confirmed the blocked attempts were dropped.
- **SSH over IPv6** is closed on all the box's public and private IPv6 addresses. Over IPv4 it's open only to your Mac.
- **Nothing else changed:** SPIRE, Nomad and Vault report the same health as before, and all 10 services are still running. Nothing was restarted or rebooted.

One thing to keep in mind: if the Mac's address ever changes, for example because the router reservation is lost, SSH to the box stops working and you'd need the box's own keyboard and screen.

Next, I'll limit SSH password logins for `ds` to your Mac and turn off X11 forwarding. That's a second short run on the box, with the same automatic undo. After that comes the Vault step, which needs you at your terminal with the unseal key. I'll send you a ready-to-run script for it.

STATUS: WORKING (SSH password limit, then the Vault script and the draft PR)
