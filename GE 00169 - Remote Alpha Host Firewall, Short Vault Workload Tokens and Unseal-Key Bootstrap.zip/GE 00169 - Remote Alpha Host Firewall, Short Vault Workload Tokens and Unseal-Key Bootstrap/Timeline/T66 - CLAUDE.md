Nothing needs you. Here's where the reviews stand.

**Still working**
- [Make ES verify fetched program files](#cmsg_01Un4xQgjBAczV8DABQvcLrx671PBLg8CxiSYsLRAYo6fD): the red-team found ES followed web redirects, even to another server. That's fixed and being re-checked.
- [Lock Nomad so only ES can submit](#cmsg_01Un4xQgjBAczV8DABQvcLrx7qaBgesL513RdQXm7D49pW): the audit blocked it, because the last repair let other tokens scale, stop or open a shell in ES's jobs. A fix using Nomad's own permission check is going in.
- [Make SPIRE agent recoverable on the box](#cmsg_01Un4xQgjBAczV8DABQvcLrxBrsnNzo5Dn7AEAfNm8J7ME): the audit wants SPIRE itself to enforce the server pin during recovery. That fix is in progress.
- [Contain TLS status collector child processes](#cmsg_01Un4xQgjBAczV8DABQvcLrxNuvEmZiJw74ZSmc17LCNmS): fixing a 20-second stall on failure paths before its red-team.
- [Finish maintenance agent fifth repair](#cmsg_01Un4xQgjBAczV8DABQvcLrxXXZRTbEtdbvV8c4236YR2V): fixing one rare race the audit found.
- The ES config safety check (PR 33) is repaired and in re-audit. The PR 12 red-team is underway, and so are the box firewall audit, the READMEs and the runbook move.

STATUS: WORKING (next update when something lands or needs you)
