Catch-up: nothing needs you yet. Every security PR has now passed its audit and red-team, and they're merging into trunk_dev one at a time to avoid re-check churn.

**Done**
- Test-file cleanup (#39), your README (#43), port-race fix (#42) and runbook check (AR #4) merged.
- Red-teams found nothing exploitable in the caller identity (#38), SPIRE helper (#34) or Nomad lock (#31). The firewall (#35) and TLS collector (#30) fixes passed their re-checks.

**Still working**
- Merge queue: #34 now, then #31, #38, the two flaky-test fixes (#44, #45), #35 and #30.
- After #31, reliable submit (PR 12) takes the Nomad token change and gets a final red-team.

**Coming up for you:** one bundled go for the box runs (SPIRE fix, Nomad lock, firewall and live Nomad checks), once these merge.

STATUS: WORKING
