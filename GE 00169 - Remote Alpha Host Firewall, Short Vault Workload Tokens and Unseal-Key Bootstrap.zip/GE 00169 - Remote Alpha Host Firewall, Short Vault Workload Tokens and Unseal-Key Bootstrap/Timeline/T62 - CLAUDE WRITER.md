Thanks for merging the runbook PR.

GitHub didn't reject the push; my own safety check did. It treats pushing to a main branch, or merging my own PR into one, as something a person should do, even with the standing go for runbooks. The setting that could allow it only works in projects with a single repository, and this one has eight. So for runbooks, a PR that you merge is the route for now.

PR #35's audit has started, and the red-team follows it. I'll handle whatever they find.

STATUS: WAITING
