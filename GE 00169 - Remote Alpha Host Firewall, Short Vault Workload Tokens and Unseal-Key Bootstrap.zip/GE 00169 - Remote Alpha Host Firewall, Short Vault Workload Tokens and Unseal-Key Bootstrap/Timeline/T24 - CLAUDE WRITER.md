A member's own session is running on their device.
