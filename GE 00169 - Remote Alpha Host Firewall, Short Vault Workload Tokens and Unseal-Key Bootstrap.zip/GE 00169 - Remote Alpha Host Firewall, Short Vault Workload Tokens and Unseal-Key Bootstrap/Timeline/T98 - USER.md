My home wifi got disrupted. It was restored just now, so if any of the threads needed connection, they may have been interrupted.
