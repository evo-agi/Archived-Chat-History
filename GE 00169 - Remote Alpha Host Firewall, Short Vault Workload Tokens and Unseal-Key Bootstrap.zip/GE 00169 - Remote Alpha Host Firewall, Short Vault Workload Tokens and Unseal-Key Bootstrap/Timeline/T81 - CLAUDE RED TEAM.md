PR #35 firewall red-team is done. The isolation holds: I ran the PR's own test suite as root in the lab, including the real-kernel network-namespace tests, and all 20 firewall tests pass (the forged-source, raw-IPv6, VLAN and ARP layer-2 tricks between containers are all blocked; a container reaches only Vault; a published port stays closed). I found no new way to break container or LAN isolation.

Two Low findings, both on the edges, each with a failing regression test and a candidate fix:

- RT07-1 (open-box + monitoring bug): the installer writes the ruleset without fsync, so a crash just after confirm can leave it empty. `--status` and the boot unit then report the firewall healthy while no rules are actually loaded, so the box is silently open. Worth fixing.
- RT07-2 (secret hygiene): the Vault bootstrap does not disable core dumps, so a crash while a token is in memory could leave it in a core file on disk. This sits right at the edge of the PR's stated "not protection against root" boundary, so it's the writer's/your call whether it's in scope.

I've sent both to the PR #35 writer with the patch. Nothing was pushed. Report SHA-256: 0daf69ee3464eb5455e6e6ee1deb7561c9f71d504a8df543ab32282281e68875.

Not covered here: the real box, a running Docker, a real Vault/sshd, and IPv6 real traffic (this kernel has no IPv6). Those would need the box or a container with those tools.

STATUS: READY
