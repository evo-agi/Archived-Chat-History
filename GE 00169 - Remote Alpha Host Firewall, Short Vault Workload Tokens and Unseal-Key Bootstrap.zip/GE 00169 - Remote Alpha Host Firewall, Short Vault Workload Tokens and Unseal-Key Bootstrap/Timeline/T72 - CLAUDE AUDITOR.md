**Verdict on PR #35 at 27e8b64: BLOCK.** The block is for one new medium finding, R1, which comes with a tested fix. Everything the first audit raised is fixed.

**R1 (medium, missed by my first audit and by the repair):** the layer-2 rule between containers still lets two kinds of frames from one container through to another. This holds with `br_netfilter` on (as on the box) or off:
- **VLAN-0-tagged frames.** In the lab, another container's UDP socket received them.
- **Forged ARP replies.** These let one container pose as the gateway and read another container's outgoing internet and DNS traffic.

The fix replaces the two rules with a single drop of every frame from one bridge port to another. I extended the layer-2 test, and it fails on the current head. With the fix, all firewall tests pass as root, unprivileged and under PR #30's PATH, and containers still reach Vault, DNS and the internet.

**The repair itself is sound:**
- Revoking the root token before the reload works as intended. Against a real Vault, a SIGKILL during the restore leaves only the 15-minute token, and the next run refuses before it asks for the key.
- My original signal regression probe passes.
- Of 46 mutants (the writer's 36 plus 10 of mine), 43 were killed. The writer's 36 were all killed. Of my 3 survivors, two need small fakes tests: the `unconfirmed` marker is left behind if arming the timer fails or nft refuses the ruleset. That is fail-safe, but the next refusal gives the wrong message. The third is effectively equivalent.
- The merge 27e8b64 is clean, the manifest reproduces at `912de425…ec39` (the same at the end of the audit), and CI on 27e8b64 is green.

**Sync note:** trunk_dev is now 0aa4a2b. Its new commits are README and `es/config` test changes only, and a trial merge with the PR is clean. A sync that pulls in PR #39 (root script tests moving into `scripts/`) will change real files, so it needs a delta check, not only a provenance check.

Files:
- [04-re-audit.md](/mnt/project-files/reports/Execution-Substrate/host-firewall/04-re-audit.md), SHA-256 `bb32ce21f6c4cd905660dc5807619d4665560f119a772956cf9862541bc6c39e`
- [04-re-audit-fix.diff](/mnt/project-files/reports/Execution-Substrate/host-firewall/04-re-audit-fix.diff), SHA-256 `df2ae04ea9cdb031bd6ddc62572c9d7b781557eaa3c0f69aaf36eff58e657f94`
- Probes, logs and manifests are in `host-firewall/04-re-audit-evidence/`.

Nothing was pushed, committed or merged, and the box was not touched.

Next: the writer applies R1 (plus the two small tests), then a narrow check of those bytes, then the red-team.

STATUS: READY (nothing needed from David; R1 repair is next)
