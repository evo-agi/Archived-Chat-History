Closed the card: answered in the conversation

Option 1
