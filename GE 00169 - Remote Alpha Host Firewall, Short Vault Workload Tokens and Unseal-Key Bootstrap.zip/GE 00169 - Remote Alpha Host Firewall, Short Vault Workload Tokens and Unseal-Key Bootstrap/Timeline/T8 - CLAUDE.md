How should the box recognize your Mac for ES and AGS? Decided
