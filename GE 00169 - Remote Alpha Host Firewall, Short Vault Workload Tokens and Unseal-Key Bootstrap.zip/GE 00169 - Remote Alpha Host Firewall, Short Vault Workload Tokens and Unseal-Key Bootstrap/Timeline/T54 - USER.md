> The box's workload login to Vault works again: the firewall was making the box look like it came from the Wi-Fi address,…


Merged and deleted branch.

Not sure why direct push was rejected.
