**Verdict on PR #35 (audited 8bef528): BLOCK.** There are five fixable problems, and I wrote and tested a fix for each one. The box is not affected.

- **F1 (medium, Vault bootstrap):** if Ctrl-C, a hang-up or a terminate signal hits the helper between generate-root and the root revoke, two things are left behind: a valid root token with no expiry, and Vault still accepting unauthenticated generate-root. I reproduced this against a real Vault 2.2.2 in 5 of 6 timings. The docs promise it cannot happen. David's 19:17Z run completed cleanly, so the box has no such leftover.
- **F2 (low):** `ct status != dnat` compares the exact value rather than testing the flag, so Docker published ports are dropped. The docs and a test say they pass. This fails closed, and nothing is published today.
- **F3 (low):** the layer-2 bridge rule lets frames with a forged source address through when `br_netfilter` is off. The box has it on, so this matters only on other hosts.
- **F4 (low):** under PR #30's root CI step (PATH without `/usr/sbin`), the two real-kernel tests fail. **PR #35 should adjust**, with a two-line PATH fix in its test helper. Whichever PR lands second should check that the runner has the needed packages and run a trial merge.
- **F5 (low):** `--confirm` accepts a loopback SSH connection as proof that the operator's path works.

Mutation testing: 24 of 32 deliberate code breakages were caught. Four of the 8 that slipped through need new tests: R6, S5, S8 and B3.

The writer's claim about **0c95eb7** checks out: it is a clean merge of 8bef528 and trunk_dev 76c030f, with only PLANS.md changed in the manifest (`a96d84db…cce`). All findings and the fix diff apply to it unchanged.

Files:
- [02-audit.md](/mnt/project-files/reports/Execution-Substrate/host-firewall/02-audit.md), SHA-256 `281058dc204405200de03a2b3b36ef8fa876e6d5b52cc2cccba287d31503c4bf`
- [02-audit-fix.diff](/mnt/project-files/reports/Execution-Substrate/host-firewall/02-audit-fix.diff), SHA-256 `ec8273b87df5e7c342e3e2f5c4470e62678ee622ac053d171e661632d858829f`
- Probes, logs and manifests are in `host-firewall/02-audit-evidence/`.

Provenance is reproduced, and the manifest at the end equals the one at the start (`dcb29d4c…afe`). Nothing was pushed, committed or merged, and the box was not touched.

Next is the writer's repair round, with an implementation report and manifest, then a narrow audit of the changes and the red-team on the fixed head.

STATUS: READY (nothing needed from David; repair is next)
