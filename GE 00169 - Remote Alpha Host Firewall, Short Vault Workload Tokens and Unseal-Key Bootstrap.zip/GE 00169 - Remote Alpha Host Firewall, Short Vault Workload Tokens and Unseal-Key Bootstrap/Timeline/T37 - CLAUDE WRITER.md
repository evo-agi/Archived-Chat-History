The SSH password limit is now live on the box. Password login for `ds` works only from your Mac ([home network address withheld]). Every other address can use keys only. Keyboard-interactive login and X11 forwarding are off for everyone.

It was applied and confirmed at 18:48Z. The firewall rules are byte-identical to run 1. All 10 services are still active, and SPIRE, Nomad and Vault report the same health as before.

No password was typed during the run. If you like, log in once as `ds` from your Mac with your password to confirm end to end.

Next, I'm finishing the Vault helper that turns your unseal key into a one-time root token, so you get a single command to run.

STATUS: WORKING
