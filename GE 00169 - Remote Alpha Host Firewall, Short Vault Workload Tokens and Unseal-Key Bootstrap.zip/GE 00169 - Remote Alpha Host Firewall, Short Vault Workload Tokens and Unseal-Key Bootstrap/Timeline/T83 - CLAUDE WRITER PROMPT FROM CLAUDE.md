#39 merged as 4c991ba. Fold that sync into your RT07 repair, and move #35's root test into scripts/.
