A member's own session went offline; messages wait for it.
