Handed the machine session instructions

Third box run, same approval ("Please go ahead.", 18:26 UTC) and same rules as before: no secrets printed, no reboots, no service restarts (only what the script itself does), no other home devices, IPv6 global/ULA addresses cut to the last two groups, /usr/bin/grep, verbatim output with EXIT lines, stop at the first unexpected result and report.

Why: after the Vault step, the workload-auth check fails with a plain 403. The Vault role now only accepts logins from 172.17.0.0/16. The check logs in from the box itself to 172.17.0.1:8200, and Docker's masquerade rule rewrites that connection's source to the box's LAN address. The new commit adds one nat chain to the firewall's own table that keeps the bridge address as the source for the box's own Vault connections, and a check that shows which source Vault sees.

Step A. Files (Mac)
  T="/Users/ds/Repositories/Playground/es-host-firewall-$(date -u +%Y%m%dT%H%M%SZ)"; mkdir -p "$T"
  git clone --depth 1 --branch claude/project-thread-vmre16 git@github.com:evo-agi/Execution-Substrate.git "$T/es"
  HEAD must be 96309e905515581ea7a14e538c5e1da9112aed89, and in "$T/es" shasum -a 256 must print
    b5a00d5b79df4e3cac9338ff9602708ba39af418d6f53c0e046fcdedae58785e  scripts/remote_alpha_host_firewall.sh
    d8e9277c0ca2fdfcf35164ad22d93244aee0e661930294e60ea66afeb988ca7a  scripts/internal/remote_alpha_host_firewall.sh
    479fecbbfc78c4e249bbe00ed178499ca2e624d6aec5a723be960267791daed5  scripts/internal/remote_alpha_host_firewall.py
    fbea06973f0f184c3d9f4c4bd31e4bc507312e9163b883efab06d56defa826a8  scripts/remote_alpha_vault_workload_auth_check.sh
    c6c077dd4bb249ce19deb7f0799b9b2706325791d94c666fb7a0124984b96b82  scripts/internal/remote_alpha_vault_workload_auth_check.sh

Step B. Copy to the box (the settings file on the box stays as it is; do not touch it)
  B="/tmp/es-host-firewall-$(date -u +%Y%m%dT%H%M%SZ)"
  ssh [test box name withheld] "mkdir -m 700 -p $B/scripts/internal"
  scp the five files above into $B/scripts and $B/scripts/internal (same relative paths), then
  ssh [test box name withheld] "cd $B && sha256sum scripts/remote_alpha_host_firewall.sh scripts/internal/remote_alpha_host_firewall.sh scripts/internal/remote_alpha_host_firewall.py scripts/remote_alpha_vault_workload_auth_check.sh scripts/internal/remote_alpha_vault_workload_auth_check.sh"

Step C. Plan (read-only) and the ruleset difference
  ssh [test box name withheld] "sudo bash $B/scripts/remote_alpha_host_firewall.sh --plan; echo EXIT=\$?"
  Expected: RESULT: ready to apply, EXIT=0, and in the host facts a line starting "host to Vault source: REWRITTEN (Vault sees ..." naming the box's LAN address. IMPORTANT: if that line says "kept" or "unknown" instead, STOP here and report; do not apply.
  ssh [test box name withheld] "sudo bash $B/scripts/remote_alpha_host_firewall.sh --render > $B/new.nft; sudo diff /etc/execution-substrate/host-firewall/es-host-firewall.nft $B/new.nft; echo DIFF_EXIT=\$?"
  Expected: DIFF_EXIT=1 and the only differences are two added blocks: the counter "host_to_vault_source_kept" and the chain "host_to_vault_source" (comment lines plus one rule with "snat ip to 172.17.0.1"). Anything else: stop and report.

Step D. Apply, then confirm from a NEW connection right away
  ssh [test box name withheld] "sudo bash $B/scripts/remote_alpha_host_firewall.sh --apply; echo EXIT=\$?"
  ssh -o ConnectTimeout=15 [test box name withheld] "sudo bash $B/scripts/remote_alpha_host_firewall.sh --confirm; echo EXIT=\$?"
  Same failure handling as before (one retry; otherwise wait 4 minutes for the automatic rollback, then report `sudo nft list tables`).

Step E. Checks after
  Mac: ssh [test box name withheld] true; echo "ssh EXIT=$?"   (expected 0)
  Mac: for p in 22 8444 8445; do nc -z -G 3 -w 3 [home network address withheld] $p; echo "v4 $p EXIT=$?"; done   (expected 0)
  ssh [test box name withheld] "sudo bash $B/scripts/remote_alpha_host_firewall.sh --status; echo EXIT=\$?"   (expected EXIT=0 and "host to Vault source: kept (Vault sees 172.17.0.1)")
  ssh [test box name withheld] "sudo bash $B/scripts/remote_alpha_host_firewall.sh --probe; echo EXIT=\$?"   (expected every line PASS including "PASS host to Vault source: kept (Vault sees 172.17.0.1)", RESULT: probe passed, EXIT=0)
  ssh [test box name withheld] "systemctl is-active es ags ars egs vault nomad docker spire-server spire-agent ssh 2>&1 | paste -sd' ' -"   (expected all active)

Step F. Workload login check, once (logs in to Vault with the workload identity, revokes its own token; prints only non-secret labels)
  ssh [test box name withheld] "sudo -n bash $B/scripts/remote_alpha_vault_workload_auth_check.sh --summary-path $B/check-summary.json >/dev/null 2>&1; echo check EXIT=\$?"
  Then print the summary with this exact command (it prints labels and numbers only):
  ssh [test box name withheld] "sudo -n python3 -I -c 'import json,sys; s=json.load(open(sys.argv[1])); a=s.get(\"auth_smoke\",{}); v=s.get(\"vault\",{}); print(\"smoke:\", s.get(\"vault_workload_auth_smoke\")); print(\"auth_smoke:\", json.dumps(a, sort_keys=True)); print(\"vault:\", json.dumps({k: v.get(k) for k in (\"sealed\",\"token_ttl_seconds\",\"policy_names\",\"role\")}, sort_keys=True))' $B/check-summary.json"
  Expected: check EXIT=0, smoke: pass, vault_login pass, token_lookup pass, proof_read pass, token_revoked pass, token_ttl_seconds about 900, sealed false. If it fails, report the output as it is (do not retry, do not change anything).
  Then: ssh [test box name withheld] "sudo nft list counter inet es_host_firewall host_to_vault_source_kept"   (expected packets above 0)

Step G. Clean up: ssh [test box name withheld] "rm -rf $B && test ! -e $B && echo box-clean"; rm -rf "$T" && echo mac-clean. Report every step verbatim and what changed on the box.
