**Needs you (about 2 minutes):** the Vault step is ready to run.

1. Save the attached file to Downloads.
2. In Terminal, run: `bash ~/Downloads/es-vault-unseal-key-step.sh`
3. When it asks, paste the Vault unseal key and press Enter. Nothing shows while you paste.
4. Paste the whole output here. Nothing secret is printed.

One thing changed from the plan. Vault 2.x won't make a root token without a token unless its config file allows it. So, if needed, the script adds that one line to the config file just for that moment. It then puts the file back exactly as it was. Vault is only reloaded, not restarted, so it stays unsealed. I tested this against a real Vault server.

STATUS: NEEDS DAVID
