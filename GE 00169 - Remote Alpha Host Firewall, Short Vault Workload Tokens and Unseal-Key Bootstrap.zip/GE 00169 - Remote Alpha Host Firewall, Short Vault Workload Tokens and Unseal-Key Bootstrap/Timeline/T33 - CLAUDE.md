Thanks. Password login for `ds` stays, but only from your Mac, and SSH closes to everything else, including public IPv6. CI changes will merge after audit without your review. The archive names will follow the existing convention. I'll bring back the three instruction rules in plain words shortly.

STATUS: waiting on nothing from you right now.
