> Thanks. The Vault step itself fully worked:


Here is the output:


```
===== 1. Get the check script (19:21:57Z)
fbea06973f0f184c3d9f4c4bd31e4bc507312e9163b883efab06d56defa826a8  scripts/remote_alpha_vault_workload_auth_check.sh
c6c077dd4bb249ce19deb7f0799b9b2706325791d94c666fb7a0124984b96b82  scripts/internal/remote_alpha_vault_workload_auth_check.sh

===== 2. Facts on the box (read-only) (19:22:03Z)
local 172.17.0.1 dev lo src 172.17.0.1 uid 1002 
    cache <local> 
docker0          DOWN           172.17.0.1/16 
earlier check summary:
  checked_at: 2026-05-25T00:24:30Z | smoke: pass
  {"jwt_audience_verified": true, "jwt_fetch": "pass", "jwt_issuer_actual_class": "matches_expected", "jwt_issuer_expected_class": "spiffe_trust_domain", "jwt_issuer_expected_source": "repo_bound_issuer_from_trust_domain", "jwt_issuer_verified": true, "jwt_subject_verified": true, "proof_read": "pass", "proof_runtime_secret": "pass", "token_lookup": "pass", "token_revoked": "pass", "vault_login": "pass"}

===== 3. Workload login check, once (19:22:04Z)
check EXIT=1
smoke: fail
auth_smoke: {"jwt_audience_verified": true, "jwt_fetch": "pass", "jwt_issuer_actual_class": "matches_expected", "jwt_issuer_expected_class": "spiffe_trust_domain", "jwt_issuer_expected_source": "repo_bound_issuer_from_trust_domain", "jwt_issuer_verified": true, "jwt_subject_verified": true, "proof_read": "not_exercised", "proof_runtime_secret": "not_exercised", "token_lookup": "not_exercised", "token_revoked": "not_exercised", "vault_login": "fail", "vault_login_error_class": "permission_denied", "vault_login_error_count": 1, "vault_login_failure_class": "permission_denied", "vault_login_failure_phase": "vault_login", "vault_login_http_status": 403, "vault_login_raw_error_recorded": false}
vault: {"address": "https://172.17.0.1:8200", "audience": "vault", "listener_addresses": ["172.17.0.1:8200"], "listener_scope_ok": true, "policy_names": [], "role": "service_execution", "sealed": false, "token_ttl_seconds": null}
spire: {"agent_healthcheck": "pass", "agent_service_active": true, "server_healthcheck": "pass", "server_service_active": true, "socket_path": "/run/spire/sockets/agent.sock", "trust_domain": "execution.internal"}
workload: {"registration_alpha_only": true, "registration_selector_scope": ["unix:gid:0", "unix:uid:0"], "spiffe_id": "spiffe://execution.internal/workload"}
workload_zone_config: {"address": "https://172.17.0.1:8200", "auth_role": "service_execution", "jwt_audience": "vault", "validation_error": "", "validation_result": "pass"}

===== 4. Clean up (19:22:08Z)
box temp folder: gone
Mac temp folder: gone

RESULT: done. Paste this whole output into the project thread.
```
