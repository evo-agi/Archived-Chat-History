PR #35 is merged into trunk_dev as `f058d8a`.

- **Before merging:** the auditor accepted the trunk_dev sync with no findings, and CI on the synced head passed.
- **After merging:** trunk_dev's tree equals the checked head's tree, and all 12 manifest paths match.

Box run 4 is still to come; I'll start it when the coordinator gives me the box. The box hasn't been touched yet.

STATUS: WAITING (box turn for run 4)
