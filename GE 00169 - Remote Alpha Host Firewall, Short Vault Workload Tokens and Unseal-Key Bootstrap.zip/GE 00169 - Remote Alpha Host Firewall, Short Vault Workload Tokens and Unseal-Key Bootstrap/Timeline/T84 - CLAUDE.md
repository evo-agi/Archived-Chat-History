Nothing needs you. Here's where the box security work stands:

- **SPIRE helper (#34):** the red-team found nothing. It merges after one last CI run.
- **Nomad lock (#31):** the red-team couldn't get around the lock. One small docs fix is going in, then it merges.
- **Firewall (#35):** isolation held under the red-team. Two edge fixes are in progress. One is a crash just after setup that could leave the box open while status says it's fine.
- **Caller identity (#38):** in its red-team now.

STATUS: WORKING
