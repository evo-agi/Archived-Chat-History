The box inventory turned up one urgent gap: the box accepts SSH passwords on every address, including its public IPv6 ones, and it has no firewall. Do you ever SSH into the box with a password rather than a key? If not, the firewall run will turn password login off. One more thing: the SPIRE agent on the box can't recover if it's down past Nov 25 at 5:45 AM EST, so I'm getting that fixed first.

STATUS: waiting on you for the SSH password question, the firewall items, the archive names and the two instructions-draft answers.
