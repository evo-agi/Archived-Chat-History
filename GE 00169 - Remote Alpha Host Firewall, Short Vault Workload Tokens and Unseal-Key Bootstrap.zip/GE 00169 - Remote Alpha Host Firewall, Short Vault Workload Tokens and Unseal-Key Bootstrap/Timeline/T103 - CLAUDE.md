Thanks. I've passed your approval and the Wi-Fi heads-up to all four box-run threads: SPIRE, the Nomad lock, the firewall and reliable submit. If the connection drops, each one stops cleanly, leaves the box working and retries later. They'll run one at a time. Right, you already answered on the identity; my mistake.

STATUS: WORKING (merge queue, then the box runs)
