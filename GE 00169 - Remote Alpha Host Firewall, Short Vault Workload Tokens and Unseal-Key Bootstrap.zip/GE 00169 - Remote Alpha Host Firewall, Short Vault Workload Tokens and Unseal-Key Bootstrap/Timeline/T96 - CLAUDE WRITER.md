CI passed on `1914fcb`, so the auditor's delta-check ACCEPT now holds without conditions. The PR is ready for its merge-queue turn.

trunk_dev has since moved to `0842983` (#31, the Nomad lock). Of this PR's files it only touches PLANS.md, and a trial merge is clean. I'll merge it in at the gate. Box run 4 still needs David's go.

STATUS: WAITING (merge queue; box run 4 needs David's go)
