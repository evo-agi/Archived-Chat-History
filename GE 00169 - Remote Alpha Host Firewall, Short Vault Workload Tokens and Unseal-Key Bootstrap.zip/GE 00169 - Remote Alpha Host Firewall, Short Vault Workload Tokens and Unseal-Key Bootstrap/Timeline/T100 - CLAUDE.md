Two things you could approve now so work keeps moving while you're out:

1. **The box runs.** This is the big one. Once the queue merges, threads deploy the SPIRE fix, the Nomad lock, its setup fixes (#48) and the firewall to the box, then run the live checks. They'd work through Remote Control on your Mac, so the Mac needs to stay on with the Claude app open. A yes now lets them go as soon as each piece merges, with no further ask.
2. **The tester identity name**, if you want the alpha tests ready to resume after Thursday. I recommend caller/claude-alpha.

Some things I can't approve in advance. When a tool blocks a step on its own, like the branch card just now or Remote Control's first-run prompt on the Mac, only you can tap it. I'll keep those to as few as possible and bundle them.

STATUS: NEEDS DAVID (go on the box runs, and optionally the identity name)
