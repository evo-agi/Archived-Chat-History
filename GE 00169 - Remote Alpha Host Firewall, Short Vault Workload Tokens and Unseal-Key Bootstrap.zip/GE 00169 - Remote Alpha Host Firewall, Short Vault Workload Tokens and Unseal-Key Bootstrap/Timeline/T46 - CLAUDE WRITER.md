Thanks. Vault refused the login with a plain 403, which points at the new address limit. Checking why now.
