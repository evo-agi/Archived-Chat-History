> The box firewall needs a few things from you, though none of them blocks the work yet. First, choose how the box should …


I have the vault unseal key.

And I gave the go ahead.

Will look into the cards now, if that still matters...
