The code is up as [draft PR #35](https://github.com/evo-agi/Execution-Substrate/pull/35) into trunk_dev, with the audit and red-team requested and CI being watched. It covers the firewall, the SSH password limit, the Vault changes and the fix for the box's login. The full test suite shows no new failures compared with trunk_dev.

One thing needs you, when you have a minute. My tools won't let me merge [Archived-Runbooks PR #3](https://github.com/evo-agi/Archived-Runbooks/pull/3) myself. It is docs only, and the leak and link checks passed. Could you press **Squash and merge** on it?

STATUS: NEEDS DAVID
