The box firewall code ([PR 35](https://github.com/evo-agi/Execution-Substrate/pull/35)) is up, so I'm starting its audit. Its red-team follows.
