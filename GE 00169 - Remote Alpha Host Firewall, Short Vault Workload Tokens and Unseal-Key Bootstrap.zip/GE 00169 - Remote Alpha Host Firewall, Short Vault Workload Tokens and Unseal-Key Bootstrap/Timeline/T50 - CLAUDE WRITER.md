The workload login to Vault works again. Box run 3 confirmed the cause before changing anything: Vault was seeing the box as [home network address withheld]. After the fix it sees 172.17.0.1, the login check passes with 15-minute tokens, all 13 probe checks pass, and all 10 services are still up. Nothing was restarted.

The runbook update is up for review as [Archived-Runbooks PR #3](https://github.com/evo-agi/Archived-Runbooks/pull/3). The tool blocked a direct push to main. The code PR comes next, once a full test comparison finishes.

STATUS: WORKING
