Asked the project to choose an option

How should the box recognize your Mac for ES and AGS?

1. Reserve its IP on the router (recommended): You add a DHCP reservation for the Mac once (Private Wi-Fi Address set to Fixed). The firewall allows only that address and needs no upkeep.
2. Pin today's IP, re-pin if moved: No router change. If the Mac's address changes, ES/AGS calls fail closed until I re-run the script. SSH keeps working.
3. Any home device (mTLS only): ES and AGS stay open to the whole home network as today, protected only by mTLS client certificates.

Why recommended: Same protection as pinning today's IP, but it never drifts, so ES/AGS never break when the Mac gets a new address.
