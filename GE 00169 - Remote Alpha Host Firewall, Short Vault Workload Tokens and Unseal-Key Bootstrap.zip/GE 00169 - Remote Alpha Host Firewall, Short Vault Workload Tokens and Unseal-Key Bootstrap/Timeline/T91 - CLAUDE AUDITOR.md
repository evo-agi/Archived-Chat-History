**BLOCK for PR #35 at 74b0846, on one Low finding (A8-1), a missing test. The fix is test-only and ready to apply.**

Report: [08-re-audit.md](/mnt/project-files/reports/Execution-Substrate/host-firewall/08-re-audit.md) (SHA-256 `9c6df9ea2d97bad11b053b4babcf63954262d9b2b5c271ad7c47caad97e95d27`)
Fix: [08-re-audit-fix.diff](/mnt/project-files/reports/Execution-Substrate/host-firewall/08-re-audit-fix.diff) (SHA-256 `729dbf5ee7cb4dcadd402350e5776aa34f1d90af548d727576c956c61ccd4bd7`)

**What checks out**
- The RT07-1, RT07-2 and Ctrl-Z fixes are correct, documented and tested.
- The #39 merge only moves and adjusts the two root test files.
- The `/proc` test fix is right; I probed its premise on this kernel.
- The manifest reproduces, and all three diffs are byte-identical to the writer's.
- All tests pass as root, unprivileged and with PR #30's PATH. CI on 74b0846 is green.
- 31 of 34 mutants are killed. Two of the three survivors (`sync` no longer required up front by `--apply` or `--confirm`) are harmless: a missing `sync` fails at the first flush and the box is restored.

**A8-1**
- When `--apply` can't install the sshd drop-in, it puts the box back as it was. My probe confirms the code does this correctly.
- But no test covers this path, and this round adds new ways to reach it: a failed flush, chmod or chown.
- If the restore step were deleted, the whole firewall suite would still pass. A box could then be left with the new rules loaded and no rollback timer.
- The diff adds that test plus a chown-failure case: one test file, +62 −3. It passes on the head and catches both gaps.

**Next**
1. The writer applies the diff.
2. I do a quick delta check.
3. Then the red-team re-check and box run 4.

Nothing was pushed or posted, and the box was not touched.

STATUS: BLOCKED (on A8-1, test-only fix)
