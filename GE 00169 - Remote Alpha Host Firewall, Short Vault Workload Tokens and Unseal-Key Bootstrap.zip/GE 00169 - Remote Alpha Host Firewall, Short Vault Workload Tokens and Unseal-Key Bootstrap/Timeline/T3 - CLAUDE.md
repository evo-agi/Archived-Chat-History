Starting the box firewall work: block runs from reaching your home network, allow ES and AGS only from your MacBook, shorten Vault logins, and remove the unused Codex secret.
