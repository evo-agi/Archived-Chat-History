Here is the response from CLAUDE INFRA AUDIT:

Facts from today's box inventory (18:03Z) that bear on your firewall. Details are in Addendum A of /mnt/project-files/reports/infra-security-audit.md (new finding INF-23).

1. IPv6 is live. wlp2s0 holds several global IPv6 addresses (ISP-delegated /64s) plus link-local. ip6tables INPUT policy is ACCEPT. sshd listens on [::]:22 and avahi on [::]:5353. Please make the LAN-inbound default-deny cover IPv6 too (an inet-family table or a matching ip6 chain), with SSH allowed only from [home network address withheld]/10 and the LAN's IPv6 prefix, read at apply time because the ISP can change it. Whether the router blocks unsolicited inbound IPv6 is Unknown.
2. sshd has PasswordAuthentication yes, X11Forwarding yes, MaxAuthTries 6 and PermitRootLogin without-password. ufw and fail2ban are inactive, and ds has full sudo with a password. I recommend your box run also add an sshd drop-in (PasswordAuthentication no, X11Forwarding no). Keys already exist for ds, ds-ro and claude. I'm asking David in my thread whether he ever uses SSH passwords, since that changes his login path.
3. The box is on Wi-Fi wlp2s0 ([home network address withheld]/24, default route via [home network address withheld]). enp1s0 is DOWN, yet nomad.hcl still sets network_interface = "enp1s0". Don't key rules on enp1s0.
4. Docker: daemon.json is absent and only the default bridge exists, with no IPv6. The iptables backend is nf_tables (ip nat/filter/raw and ip6 nat/filter tables). FORWARD policy is DROP and jumps to DOCKER-USER (empty), then DOCKER-FORWARD. icc and masquerade are on, ip_forward=1 and bridge-nf-call-iptables=1.
5. DNS: systemd-resolved listens on 127.0.0.53 and 127.0.0.54, but the upstream servers were not captured. My guess is the router at [home network address withheld] via DHCP, possibly plus IPv6 RDNSS servers. Docker gives containers the upstreams from /run/systemd/resolve/resolv.conf, so read them at apply time rather than hard-coding them.

No reply needed.
