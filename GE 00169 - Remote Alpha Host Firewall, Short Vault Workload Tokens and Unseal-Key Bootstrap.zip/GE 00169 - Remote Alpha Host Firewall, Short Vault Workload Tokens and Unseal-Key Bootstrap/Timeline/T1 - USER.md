> The infrastructure audit is done: 22 findings, each with a quick mitigation and a proper fix, in a budget-sized order. T…


For your questions,

1. No idea. But, since we are not using OpenAI, you can just discard it.
2. If you mean what may call ES and AGS, right now it's just my MacBook, aka where I'm typing this response.
3. Main WiFi. And, no, we are not getting a new WiFi. You'll have to add the necessary patch/support, and still configure it to use home WiFi.
