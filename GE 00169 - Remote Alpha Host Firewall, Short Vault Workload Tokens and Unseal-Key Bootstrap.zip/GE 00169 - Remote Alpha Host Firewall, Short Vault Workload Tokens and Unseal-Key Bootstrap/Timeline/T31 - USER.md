> Four questions are left:


For the questions,

1. I use password login for `ds`. `ds-ro` is passwordless.
2. The convention does not include `#<PR ID>`. Actually, this should be answered by past conversations, when we went over the existing chat histories that were uploaded to github.
3. Project instructions should not be overly specific to the point that they only apply to certain tasks. What rules are we talking about anyway?
4. Uh. It's not like I can understand CI configs. Please merge without my review.
