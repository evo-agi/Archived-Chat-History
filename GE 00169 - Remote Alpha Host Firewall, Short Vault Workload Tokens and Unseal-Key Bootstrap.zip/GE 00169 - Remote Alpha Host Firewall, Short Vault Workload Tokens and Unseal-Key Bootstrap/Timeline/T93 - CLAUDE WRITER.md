A8-1 is fixed with the auditor's test, applied unchanged, and head `1914fcb` is ready for the auditor's delta check.

- **Commit:** its diff is byte-identical to `08-re-audit-fix.diff`. It kills both mutants the audit named (restore step deleted, failing chown ignored). No product code changed.
- **Conflict:** while the re-audit ran, #34 landed and GitHub reported a conflict in the shared docs file. I merged trunk_dev `5b82a6e` and kept both new sections unchanged. Every line this PR adds or removes is the same against the new base.
- **Manifest:** `575f4c0d…103d` vs base `5b82a6e`, taken twice and identical.
- **Tests:** the affected suites pass as root and unprivileged, including the real-kernel ones.

CI on `1914fcb` is running; I'll only post again if it fails. The box wasn't touched.

STATUS: WAITING (auditor's delta check, then the merge queue)
