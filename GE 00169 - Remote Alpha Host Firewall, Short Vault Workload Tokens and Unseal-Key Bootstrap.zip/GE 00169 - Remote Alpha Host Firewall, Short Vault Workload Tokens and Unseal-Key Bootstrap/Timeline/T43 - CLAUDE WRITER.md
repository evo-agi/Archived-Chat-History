Thanks. The Vault step itself fully worked:
- The root token made from your key and the 15-minute token are both revoked.
- Workload logins are now limited to 15 minutes and the Docker network.
- The old Codex value is gone, with all its versions.
- Vault's config file is back byte for byte, and Vault stayed unsealed.

**Needs you (about 30 seconds):** the follow-up workload login failed. My summary only showed that it failed, not why. The attached script is read-only and asks for nothing. Run `bash ~/Downloads/es-vault-login-diagnose.sh` and paste the output here.

My guess is the new address limit, but I want the reason before changing anything.

STATUS: NEEDS DAVID
