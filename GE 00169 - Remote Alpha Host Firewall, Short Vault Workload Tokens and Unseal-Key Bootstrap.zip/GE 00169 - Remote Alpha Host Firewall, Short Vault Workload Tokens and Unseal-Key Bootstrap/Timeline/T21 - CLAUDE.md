Done. Only your Mac at [home network address withheld] will be allowed, and the device list will live in a config file, so adding a device later is a one-line config change.

STATUS: waiting on you for SSH passwords, the archive names and the two instructions-draft answers.
