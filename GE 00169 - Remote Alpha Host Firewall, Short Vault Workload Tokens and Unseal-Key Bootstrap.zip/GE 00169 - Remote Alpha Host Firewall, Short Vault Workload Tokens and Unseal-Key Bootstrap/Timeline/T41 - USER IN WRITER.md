> Needs you (about 2 minutes): the Vault step is ready to run.


Here is the output:


```
===== 1. Get the helper (19:17:21Z)
clone from: git@github.com:evo-agi/Execution-Substrate.git
b4961b5 (grafted, HEAD -> claude/project-thread-vmre16, origin/claude/project-thread-vmre16) Let the Vault bootstrap use the unseal key instead of a root token
7db4909d5ad89f450b0bfbe5a2f8ada7dd72ca7aeb5bacfc542f6ed9b4a8b141  scripts/remote_alpha_vault_workload_auth_bootstrap.sh
4adb7343472887e3d1e212ee0a939a196779d0944e5dd2a325a70954b1ff3c61  scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh
fbea06973f0f184c3d9f4c4bd31e4bc507312e9163b883efab06d56defa826a8  scripts/remote_alpha_vault_workload_auth_check.sh
c6c077dd4bb249ce19deb7f0799b9b2706325791d94c666fb7a0124984b96b82  scripts/internal/remote_alpha_vault_workload_auth_check.sh
all four SHA-256 match

===== 2. Vault on the box before (read-only) (19:17:22Z)
vault: HTTP 200, sealed=False, version=2.0.0, key shares=1, threshold=1
vault generate-root without a token: HTTP 403 (refused)
vault.service config file: /etc/vault.d/vault.hcl
vault.service reload sends HUP: yes
/etc/vault.d/vault.hcl: sha256 bb1455eae4575967610cbf639758cba24453eb1f75855335b6c0a03a9d5a4c66, owner 0:981, mode 0o640, mentions enable_unauthenticated_access: no
PRECHECK OK

===== 3. Copy the helper to the box (19:17:24Z)
7db4909d5ad89f450b0bfbe5a2f8ada7dd72ca7aeb5bacfc542f6ed9b4a8b141  scripts/remote_alpha_vault_workload_auth_bootstrap.sh
4adb7343472887e3d1e212ee0a939a196779d0944e5dd2a325a70954b1ff3c61  scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh
fbea06973f0f184c3d9f4c4bd31e4bc507312e9163b883efab06d56defa826a8  scripts/remote_alpha_vault_workload_auth_check.sh
c6c077dd4bb249ce19deb7f0799b9b2706325791d94c666fb7a0124984b96b82  scripts/internal/remote_alpha_vault_workload_auth_check.sh

===== 4. Configure Vault with your unseal key (19:17:29Z)
The box now asks for the Vault UNSEAL KEY. Paste it and press Enter.
Nothing appears while you paste. It is used only on the box and never shown or saved.
Vault unseal key (input hidden; not logged; used once to make a root token that is revoked at once, and a 15m token for this run): 
The root token made from the unseal key was revoked at once; the short-lived token for this run is revoked too.
Vault's configuration file is back byte for byte, and Vault again refuses generate-root without a token.
Remote Alpha Vault workload-auth bootstrap helper finished.
overall_status=pass
Remote summary path: /tmp/es-vault-step-20261123T191721Z/bootstrap-summary.json
Summary is non-secret evidence/projection only and was not copied to Mac .out.
Workload-auth check, reset/unseal, IM refresh, support-bundle collection, CP proof, and runtime identity generation were not run.
Non-claims: not workload-auth success, not runtime-profile readiness, not submit readiness, not Vault production readiness, not ES Vault token brokerage.
Connection to [home network address withheld] closed.
helper EXIT=0
summary overall_status: pass | failure: None None None
  bootstrap_choices: pass 
  config_load: pass 
  generate_root_access_enable: pass 
  generate_root_access_preflight: pass {"vault_allows_generate_root_without_token": false}
  generate_root_access_probe: pass {"vault_allows_generate_root_without_token": false}
  generate_root_access_restore: pass {"file_restored_byte_for_byte": true, "vault_refuses_generate_root_without_token_again": true, "vault_reloaded": true}
  generate_root_token: pass 
  generated_root_token_revoke: pass 
  jwt_auth_config: pass 
  jwt_auth_mount: pass 
  kv_v2_mount: pass 
  prompt_bootstrap_authority: pass {"prompt_source": "remote_tty"}
  prompt_proof_secret: pass {"prompt_source": "generated"}
  proof_secret_codex_runtime_profile: pass 
  proof_secret_prior_versions: pass 
  proof_secret_runtime_identity_vault_login: pass 
  role_token_limits: pass {"token_bound_cidrs": ["172.17.0.0/16"], "token_max_ttl": "30m", "token_ttl": "15m"}
  runtime_identity_policy: pass 
  service_execution_role: pass {"token_bound_cidrs": ["172.17.0.0/16"], "token_max_ttl": "30m", "token_ttl": "15m"}
  short_lived_authority_token: pass 
  short_lived_authority_token_revoke: pass 
  spire_jwt_validation_material: pass 
  summary_preflight: pass 
  vault_client_init: pass 
  vault_config_preflight: pass 
  workload_zone_config: pass 

===== 5. Real workload login (read-only check) (19:17:49Z)
check EXIT=1
workload auth smoke: fail
  jwt fetch: pass | vault login: fail | token lookup: not_exercised | proof read: not_exercised | token revoked: not_exercised
  workload token ttl seconds: None | policies: [] | sealed: False
  runtime profile value present: False | non-empty: False

===== 6. Vault on the box after (read-only) (19:17:52Z)
vault: HTTP 200, sealed=False, version=2.0.0, key shares=1, threshold=1
vault generate-root without a token: HTTP 403 (refused)
vault.service config file: /etc/vault.d/vault.hcl
vault.service reload sends HUP: yes
/etc/vault.d/vault.hcl: sha256 bb1455eae4575967610cbf639758cba24453eb1f75855335b6c0a03a9d5a4c66, owner 0:981, mode 0o640, mentions enable_unauthenticated_access: no
PRECHECK OK
vault.hcl: identical to before (sha256, owner, mode)
generate-root without a token: same as before
Vault: still unsealed

===== 7. Clean up (19:17:53Z)
box temp folder: gone
Mac temp folder: gone
Playground: still there

RESULT: done. Paste this whole output into the project thread.
```
