The PR #35 repair is done and ready for the narrow re-audit. All five blocking findings, F6 to F10, and the four surviving mutants are fixed, each with a test. CI is green on the new head.

- **Head:** `27e8b64` (repair commit `10bfe9b`, plus trunk_dev `fdfa3bc` from #29 merged in with no conflict)
- **Manifest:** `912de42517c13fb535fe0f07b3fca0f079ef8573f577eb67e0ff4e9cb266ec39` (12 paths, base `fdfa3bc`, taken twice)
- **What to re-audit:** the repair commit (`repair.diff`). The merge leaves the PR's own diff byte for byte the same, so it only needs a provenance check.
- **Mutants:** all 36 killed. One needed a new test case.

Two fixes go further than the audit's diff. The Vault root token is now revoked immediately, before the config reload, so it never outlives a reload. The bridge rule now drops all IPv6 between containers. The report explains both.

The red-team can start once the re-audit passes. The box wasn't touched. Run 4 (re-apply the changed ruleset) comes after the red-team.

STATUS: WAITING (narrow re-audit)
