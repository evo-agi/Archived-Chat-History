Quick status: the SPIRE helper (PR #34) passed its audit and is now in a narrow red-team. The Nomad lock (#31), the firewall (#35) and the test-file move (#39) are in final re-checks. Nothing needs you.

STATUS: WORKING
