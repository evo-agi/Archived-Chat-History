Handed the machine session instructions

Box run: apply the Execution-Substrate host firewall to the disposable Linux test box (ssh alias `[test box name withheld]`, user `claude`, passwordless sudo). David approved this run in his project thread ("Please go ahead.", 18:26 UTC).

Rules for the whole run:
- Never print or copy secrets (Vault tokens, keys, certificates' private parts). Nothing in these steps prints any.
- Never reboot the box. Never restart vault, docker, nomad, es, ags, ars, egs or spire. Only the commands below change the box.
- Contact no other home device. The only LAN targets are the box itself (and the box's own probe of the router, which the box's firewall is expected to stop).
- When reporting IPv6 global addresses (2603:… or fd00:…), show only the last two groups, e.g. `…:a0bb:1617`.
- Use /usr/bin/grep, not grep (grep is a shell function on this Mac).
- Report every step's full output verbatim (all of it is non-secret), including each `EXIT=` line. Stop at the first unexpected result and report; do not improvise fixes on the box.

Step 0. Get the files (Mac, Playground only)
  T="/Users/ds/Repositories/Playground/es-host-firewall-$(date -u +%Y%m%dT%H%M%SZ)"; mkdir -p "$T"
  Read the protocol of the existing clone: git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin
  Clone with the same protocol, but the evo-agi repository (https://github.com/evo-agi/Execution-Substrate.git or git@github.com:evo-agi/Execution-Substrate.git):
    git clone --depth 1 --branch claude/project-thread-vmre16 <url> "$T/es"
  Check: git -C "$T/es" rev-parse HEAD must print 774297757881ecebc9007317ddc66b0ed6f53a37
  Check: (cd "$T/es" && shasum -a 256 scripts/remote_alpha_host_firewall.sh scripts/internal/remote_alpha_host_firewall.sh scripts/internal/remote_alpha_host_firewall.py) must print
    b5a00d5b79df4e3cac9338ff9602708ba39af418d6f53c0e046fcdedae58785e  scripts/remote_alpha_host_firewall.sh
    0908e5ac9ba1223c1da397f5d935e05457c3a339912863dcace8e1edbc820bb9  scripts/internal/remote_alpha_host_firewall.sh
    1fdfe816b92d523a04cf97cf639a93717456b980e718434bcb9c3f501452b940  scripts/internal/remote_alpha_host_firewall.py
  Any mismatch: stop and report.

Step 1. Mac facts (read-only)
  ssh -G [test box name withheld] | /usr/bin/grep -E '^(hostname|user|port) '
  IF="$(route -n get [home network address withheld] | awk '/interface:/{print $2}')"; echo "IF=$IF"
  ipconfig getifaddr "$IF"
  ifconfig "$IF" | /usr/bin/grep inet6
  If hostname is not [home network address withheld] (for example a .local name): do steps 2 and 3, then stop before step 4 and report.

Step 2. Box facts (read-only)
  ssh [test box name withheld] 'echo "SSH_CLIENT=$SSH_CLIENT"; for c in nft ip ss systemctl python3 sha256sum docker nsenter install; do printf "%s=%s\n" "$c" "$(command -v $c)"; done; sudo -n true && echo sudo_ok; ip -br addr; ip -6 addr show dev wlp2s0 scope link; echo "nftables.service: $(systemctl is-enabled nftables 2>&1)"; systemctl is-active es ags ars egs vault nomad docker spire-server spire-agent ssh 2>&1 | paste -sd" " -; /usr/bin/grep -h "^nameserver" /etc/resolv.conf /run/systemd/resolve/resolv.conf; sudo nft list tables'
  MAC_IP = the first field of SSH_CLIENT. It must be an IPv4 address in [home network address withheld]/24 and equal the ipconfig value from step 1. If not: stop and report.
  BOX_LL = the box's [home network address withheld] address on wlp2s0 (without /64). BOX_V6 = the first 2603: address on wlp2s0 from `ip -br addr` (without /64).

Step 3. Baseline from the Mac, before the firewall (read-only; record results)
  for p in 22 8444 8445; do nc -z -G 3 -w 3 [home network address withheld] $p; echo "v4 $p EXIT=$?"; done
  nc -6 -z -G 3 -w 3 "$BOX_V6" 22; echo "v6 global 22 EXIT=$?"
  nc -6 -z -G 3 -w 3 "$BOX_LL%$IF" 22; echo "v6 link-local 22 EXIT=$?"

Step 4. Copy the files to the box and write the settings
  B="/tmp/es-host-firewall-$(date -u +%Y%m%dT%H%M%SZ)"
  ssh [test box name withheld] "mkdir -m 700 -p $B/scripts/internal"
  scp "$T/es/scripts/remote_alpha_host_firewall.sh" "[test box name withheld]:$B/scripts/"
  scp "$T/es/scripts/internal/remote_alpha_host_firewall.sh" "$T/es/scripts/internal/remote_alpha_host_firewall.py" "[test box name withheld]:$B/scripts/internal/"
  Write $B/settings.env on the box with exactly these three lines (put MAC_IP in):
    REMOTE_ALPHA_HOST_FIREWALL_SERVICE_CALLERS="<MAC_IP>/32"
    REMOTE_ALPHA_HOST_FIREWALL_ACCEPT_BLOCKED_LISTENERS="udp/5353"
    REMOTE_ALPHA_HOST_FIREWALL_PROBE_IMAGE="alpine:3.20"
  Write $B/fw on the box with exactly:
    #!/bin/bash
    set -a; . "$(dirname "$0")/settings.env"; set +a
    exec bash "$(dirname "$0")/scripts/remote_alpha_host_firewall.sh" "$@"
  ssh [test box name withheld] "cd $B && sha256sum scripts/remote_alpha_host_firewall.sh scripts/internal/remote_alpha_host_firewall.sh scripts/internal/remote_alpha_host_firewall.py && cat settings.env"
  (The three hashes must match step 0.)

Step 5. Plan (read-only)
  ssh [test box name withheld] "sudo bash $B/fw --plan; echo EXIT=\$?"
  Expected: last line "RESULT: ready to apply" and EXIT=0. If not, stop and report. Do not add listener tokens or change settings.

Step 6. Apply, then confirm from a NEW ssh connection
  ssh [test box name withheld] "sudo bash $B/fw --apply; echo EXIT=\$?"
  Expected EXIT=0. It arms an automatic rollback that fires after 180 seconds unless confirmed.
  Right away (well within 2 minutes), as a separate new connection:
  ssh -o ConnectTimeout=15 [test box name withheld] "sudo bash $B/fw --confirm; echo EXIT=\$?"
  Expected "RESULT: confirmed" and EXIT=0.
  If that ssh cannot connect: try once more. If it still fails, wait 4 minutes (the rollback restores the old rules), then run `ssh [test box name withheld] 'sudo nft list tables'` and report. If confirm prints an error, report it as is.

Step 7. From the Mac, after the firewall
  for p in 22 8444 8445; do nc -z -G 3 -w 3 [home network address withheld] $p; echo "v4 $p EXIT=$?"; done        (expected: all EXIT=0)
  nc -6 -z -G 5 -w 5 "$BOX_V6" 22; echo "v6 global 22 EXIT=$?"                                  (expected: EXIT=1, the global IPv6 address no longer takes SSH)
  nc -6 -z -G 3 -w 3 "$BOX_LL%$IF" 22; echo "v6 link-local 22 EXIT=$?"                          (expected: EXIT=0 if it was 0 in step 3)
  ssh [test box name withheld] true; echo "ssh EXIT=$?"                                                        (expected: EXIT=0)

Step 8. Probe from throwaway containers on the box (they are removed afterwards)
  ssh [test box name withheld] "sudo bash $B/fw --probe; echo EXIT=\$?"
  Expected: every line PASS and EXIT=0. One probe tries the router's port 80 from a container; the box's firewall is expected to drop it (that line shows PASS when it was dropped).
  If any line shows FAIL: run ssh [test box name withheld] "sudo bash $B/fw --rollback; echo EXIT=\$?; sudo nft list tables", then report everything.

Step 9. Status and services
  ssh [test box name withheld] "sudo bash $B/fw --status; echo EXIT=\$?; systemctl is-enabled es-host-firewall; systemctl is-active es-host-firewall; systemctl is-active es ags ars egs vault nomad docker spire-server spire-agent ssh 2>&1 | paste -sd' ' -"
  Expected: status EXIT=0, enabled, active, and the same service states as in step 2.

Step 10. Clean up temporary copies (the installed firewall stays)
  ssh [test box name withheld] "rm -rf $B"
  rm -rf "$T"
  Report: each step's output, the step 3 and step 7 results side by side, and confirm both temp folders are gone.
