Four questions are left:

1. **SSH passwords:** do you ever SSH into the box with a password rather than a key? If not, password login gets turned off.
2. **Archive names:** are these OK for four merged PRs, or would you word them differently?
   - #16: Reliablesubmit Lock-Contention Test No Longer Depends on Timing
   - #17: Repair Three ES App Integration Tests That Fail Since PR 8
   - #22: TLS Status Collector Parses the Proc Stat Line as Bytes and Confirms Absence with pidfd_open
   - #24: Run the ES App Integration Tests with Nomad, Vault and SPIRE in CI
3. **Instructions headroom:** may three rarely used rules move from the project instructions into the procedures file? That brings the instructions down to about 14,550 characters, safely under the limit.
4. **Merges without your review:** should CI config changes join test-only changes as PRs that can merge without your review, once audited?

STATUS: waiting on you for these four; everything else is moving.
