Both red-team findings on #35 are fixed, #39 is folded in with the PR's tests moved into scripts/, and the head is ready for the narrow re-audit and red-team re-check.

- **Head:** `74b0846` on `claude/project-thread-vmre16`, base trunk_dev `4c991ba`. The manifest was taken twice and both runs match: `90ef077e…a164`.
- **RT07-1:** installs now flush the file before the rename and the directory after it. `--status` and the boot unit now fail when the tables aren't loaded, and `--status` also fails when an installed file is empty.
- **RT07-2:** the Vault bootstrap turns core dumps off before it reads anything. I also fixed the Ctrl-Z observation, so Ctrl-Z now waits like Ctrl-C.
- **What to review:** the repair diff (8 files), the merge's extra changes (3 files) and a one-file test fix. CI on the merge commit caught one of my new checks looking at the wrong `/proc` file, which `74b0846` corrects.
- **Mutants:** all 23 killed. I re-ran the 8 bootstrap ones at `74b0846`, and each was killed by the check written for it.
- **Validation:** the targeted suites pass as root, as an unprivileged user and with PR #30's PATH. The whole-package failures are the same as on base.

CI on `74b0846` is still running. I'm watching it and will only post again if it fails. trunk_dev has since moved to `523648c` (README only, merges cleanly); I'll take it at the merge gate. The box wasn't touched, and box run 4 waits for the re-check and David's go.

STATUS: WAITING (narrow re-audit and red-team re-check)
