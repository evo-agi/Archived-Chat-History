I'll start by writing the firewall rules and Vault changes as reviewed scripts, then plan one box run together with the Nomad lock.
