Thanks, the unseal key is enough. A fresh Vault root token can be made from it when the time comes, and revoked right after. The cards still matter: the Mac address one shapes the firewall. The SSH password question and the four archive names are still open too.

STATUS: firewall box run approved and queued; waiting on you for the Mac address card, SSH passwords, archive names and the two instructions-draft answers.
