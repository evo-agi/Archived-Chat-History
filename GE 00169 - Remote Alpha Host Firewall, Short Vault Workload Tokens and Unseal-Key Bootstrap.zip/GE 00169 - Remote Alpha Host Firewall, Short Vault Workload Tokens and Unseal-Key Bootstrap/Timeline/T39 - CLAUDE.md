Changing topic briefly. The box's Vault step is ready, and it takes about 2 minutes. In [Firewall the test box on home Wi-Fi](#cmsg_01Un4xQgjBAczV8DABQvcLrxYZKVpdQDC9R2bs6oLNZYKJ), download the attached script, run it in Terminal, and paste your unseal key when it asks. Then paste the output back in that thread. It prints nothing secret. It shortens Vault login lifetimes and deletes the unused Codex secret.

Also done: the test-only [PR 26](https://github.com/evo-agi/Execution-Substrate/pull/26) passed its final audit and merged into trunk_dev as `8ba1edb`.

STATUS: NEEDS DAVID (run the Vault script)
