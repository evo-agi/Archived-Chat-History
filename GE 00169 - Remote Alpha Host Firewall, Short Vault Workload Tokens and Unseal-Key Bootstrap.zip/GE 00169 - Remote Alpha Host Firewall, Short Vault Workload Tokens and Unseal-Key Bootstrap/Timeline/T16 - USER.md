> Thanks, the unseal key is enough. A fresh Vault root token can be made from it when the time comes, and revoked right af…


The Linux's box's IP is reserved on the router. Oh, is this for the Mac? Actually, why not any home device? This feels like a more scalable option.
