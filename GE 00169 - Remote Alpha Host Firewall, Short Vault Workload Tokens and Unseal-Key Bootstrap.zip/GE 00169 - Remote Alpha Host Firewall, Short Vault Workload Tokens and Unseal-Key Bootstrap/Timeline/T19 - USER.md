> Yes, this one is about your Mac: which devices can reach ES and AGS on the box. "Any home device" is simpler, but it wou…


If the "one-line change" is a config change, then sure.

Just reserved the MacBook's IP: [home network address withheld]
