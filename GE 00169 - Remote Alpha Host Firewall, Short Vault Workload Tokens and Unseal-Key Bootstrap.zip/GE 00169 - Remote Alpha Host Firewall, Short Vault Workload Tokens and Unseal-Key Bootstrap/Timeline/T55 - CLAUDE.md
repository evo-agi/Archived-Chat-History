Thanks! Guess at the cause: the safety filter judges each push only from what that thread can see. A thread can't see your standing permission for runbooks on main unless its instructions spell it out, so the filter read the push as unapproved. Earlier runbook threads had that in their brief; this one didn't. From now on I'll write the permission into every brief that may touch runbooks. If it happens again despite that, I'll dig further.

STATUS: WORKING (PR 27 summary for your review coming next)
