Thanks. First I'll finish today's IPv6 and Wi-Fi fixes, then start the box run from your Mac.
