Three things I'll need from you later. None of them blocks me right now.

1. **Box run.** When you have a moment, please write "go ahead" in this thread. Remote Control on your Mac only accepts a box run if you've written in this thread yourself. I'll use it once the change is built and tested here. The run applies the firewall with an automatic rollback after 3 minutes, which only stops if a fresh SSH login from your Mac still works. Then it checks from a throwaway container that your LAN, ES, AGS and SSH are unreachable while Vault, DNS and the internet still work. One of those probes tries your router's port 80. The firewall should stop it on the box, and a packet counter will show that it did.
2. **Vault root token.** Making Vault logins short and discarding the Codex secret both need the Vault root token, and only you have it. Do you still have it? If you do, it's a single script run at your terminal later. If not, we can make a new one from your unseal key.
3. **Your Mac's address.** The decision card below asks how the box should recognize your Mac. Until you choose, I'll plan on allowing your Mac's current IP address.

STATUS: WORKING (writing the firewall script, the Vault changes and tests; next update when the draft PR is up, roughly 2 to 3 hours)
