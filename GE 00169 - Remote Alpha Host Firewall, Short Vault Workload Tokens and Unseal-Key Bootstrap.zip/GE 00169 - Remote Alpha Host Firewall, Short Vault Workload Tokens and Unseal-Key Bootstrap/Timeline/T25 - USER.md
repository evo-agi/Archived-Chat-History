> Done. Only your Mac at [home network address withheld] will be allowed, and the device list will live in a config file, so adding a device…


What are the remaining questions?
