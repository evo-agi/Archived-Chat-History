I started capturing this sequence of events after I uploaded a fresh snapshot to project sources. `Timeline/T0 - CHATGPT.md` marks a clean start for the tranche.
