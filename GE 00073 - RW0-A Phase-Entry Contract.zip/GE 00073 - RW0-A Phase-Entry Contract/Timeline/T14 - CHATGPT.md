## Verdict

**Advance the exact ten-path RW0-A candidate to a fresh independent read-only audit. No further implementation repair is justified before that audit.**

Codex’s closeout is internally coherent:

```text
Direct RW0-A oracle:        28/28
Complete C2B3C file:        46/46
Focused regression:      1,565/1,565
Complete suite:          4,284/4,284
Final node identity:     4,284 unchanged
```

The final repair is also narrowly accounted for:

```text
Opening manifest:
2,328 bytes
e8c5714fcc4d73735198fa3bc48475108c150ba40321c244e4259e48c052066f

Final audit target:
2,328 bytes
71d13c026567732210e1a35f5fa962b0efa853c35eb6797d0af745bc02fd3394

Only changed entry:
tests/test_c2b3c_author_effect_contract.py

Opening:
416,116 bytes
9719b3a2bab169eba790440381f7120d214a133483e030e188a1613542ca06e2

Final:
416,182 bytes
935ca6fe7b18d39055d5cdc2c911302e7c0726304f3699472f3994a32f7b4778
```

The file correctly remains local mode `0600` while Git records mode `100644`. That must be preserved as part of the audit target, not “normalized” to `0644`.

## Audit scope

This cannot be merely a targeted review of the last 66-byte diagnostic change. **RW0-A has never received an independent audit**, so the auditor must inspect the whole ten-path contract freeze:

- the authoritative RW0 phase-entry document;
- four current-target cross-references;
- the append-only H3 under final Section 42;
- the complete authority, custody, identity, fact, ambiguity, cancellation, and ES/IM model;
- all 28 new direct contract tests;
- the existing architecture, Section 42, and C2B3C compatibility tests.

The audit prompt independently challenges the candidate with mutants for:

- current-runtime overclaims;
- authority reversal;
- synchronous user approval;
- ref-as-retrieval-permission;
- provisional ES fixture hardening;
- base-drift absorption;
- premature SSH/framing choices;
- host fallback or a third adapter;
- second delivery or second productive acceptance;
- evidence becoming authority;
- ES/IM ownership absorption;
- Git or publication effects;
- terminal-outcome omissions and region masking;
- cancellation collapse;
- fenced, hidden, duplicated, or same-title-relocated Markdown owners;
- duplicate committed-status blocks and H2 Section 43.

It also independently reruns the direct, C2B3C, focused, collection, and complete-suite gates.

## Next action

Send this prompt in a **new read-only Codex conversation**:

:chatgpt-content-reference{index="3"}

The authoritative target is:

```text
/private/tmp/ge-coordinator-rw0a-marker-repair.vOkQZp/
  final-manifest-immutable.json

2,328 bytes
SHA-256:
71d13c026567732210e1a35f5fa962b0efa853c35eb6797d0af745bc02fd3394
```

A successful audit must return:

```text
ACCEPT

COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FREEZE_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Only then should the lifecycle continue:

```text
independent ACCEPT
→ stage exact ten audited paths
→ staged-blob and Git-mode equality
→ final validation on unchanged bytes
→ one feature-branch commit
→ committed-blob equality
→ feature-branch push
→ PR to trunk_dev
→ squash-merge and merged-tree verification
```

The committed baseline beneath this candidate remains the merged Coordinator commit `1a894c55…` and tree `53c1834e…`.  Independent audit belongs in a fresh read-only conversation, separate from the implementation writer.  Any later byte change invalidates the audit and returns the work to implementation and re-audit.  The exact manifest proves byte identity, not architectural correctness or test sufficiency; those remain the purpose of this audit. 

### Sources

- Codex implementation closeout supplied in this turn.
- RW0 reconnaissance baseline. 
- Independent-audit and repair lifecycle.  
- Provenance authority and limitations. 

**Confidence:** 99% that the candidate is ready for independent audit; 96% that the supplied audit scope is broad enough to expose any remaining RW0-A contract or oracle defect before publication.
