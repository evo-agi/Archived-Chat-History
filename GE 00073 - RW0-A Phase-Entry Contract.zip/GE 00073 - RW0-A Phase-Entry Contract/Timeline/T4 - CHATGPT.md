## Verdict

**Proceed to RW0-A implementation, but not with the reconnaissance report taken literally.** The investigation is strong enough to freeze the first tranche after four parent-level corrections.

Codex did the important work correctly:

- It verified the exact Coordinator baseline and separated committed ES/IM facts from local overlays. 
- It reconstructed the exact current VS1B → C2B3D → Section 41 starting families and preserved `selected_for_dispatch_gates` as non-executable planning state. 
- Its identity matrix, target fact timeline, failure/recovery model, cancellation ordering, capsule boundary, and ES/IM ownership split are coherent and worth adopting.  
- The five-tranche sequence is sensible, and a docs-and-contract-tests-only RW0-A is the correct first increment. 
- The proposed nine-file maximum scope is bounded and keeps all runtime capability absent. 

## Required parent corrections

### 1. Subordinate authority remains Coordinator-derived

The report made both the parent grant and narrower attempt/effect authorization externally authored.  It repeated that choice in the authority matrix and called it a reconciled target decision.  

That conflicts with the already accepted Coordinator target in the committed snapshot:

```text
external standing-policy authority authors the parent grant;
Coordinator may derive narrower subordinate attempt/effect records and fences
inside the verified parent grant.
```

RW0-A must preserve that target. Current executable authorization is still completely absent and fail-closed; this tranche merely freezes the future split.

### 2. The exact ES commit and paths are a provisional fixture

The report selected ES commit `b92bd988…` and three exact paths as the frozen scenario. 

That is useful reconnaissance evidence, but ES is active and its base can move long before RW0-E. The governing contract should freeze:

- exact repository/base/path binding at execution time;
- a docs/docs-contract-only first task with a maximum three-path ceiling;
- mandatory replan and new WorkSpec on drift.

The reported commit and paths may appear only as a clearly labeled, stale-able initial fixture candidate—not enduring Coordinator identity, authority, or contract.

### 3. Custody properties are frozen; the custodian implementation is not

The report chose an operator-preprovisioned remote custodian and one-use out-of-band capability. 

RW0-A should freeze the privacy and authorization properties:

- no raw WorkSpec in SQLite, argv, environment, logs, capsule, or reports;
- safe refs and digests are not retrieval permission;
- retrieval is expiring, one-use, attempt/effect/audience-bound, and revocable;
- restart never reuses a bearer;
- the user is not a synchronous per-attempt approver.

A standing operator-provisioned custodian can remain a bounded proof candidate. It must not become enduring architecture or the routine human critical path.

### 4. SSH and length-prefixed framing remain implementation decisions

The report selected a host-key-pinned SSH forced command and later specified a length-prefixed launch frame.  

RW0-A should freeze only:

- the `direct_local_bootstrap` compatibility route;
- one authenticated, qualified remote Linux host;
- one actual delivery;
- no Mac, Coordinator-host, alternate-host, or third-adapter fallback;
- process separation and bounded I/O;
- no SQLite or writer authority in the worker.

Exact SSH mechanics, framing grammar, terminal-result schema, and numeric limits belong to RW0-B/RW0-D. Codex correctly classified those as later open decisions elsewhere in the report. 

## First tranche

The corrected tranche remains:

```text
RW0-A-PHASE-ENTRY-CONTRACT-FREEZE
```

It creates:

- one authoritative `.docs/rw0-remote-worker-contact-phase-entry.md`;
- four identical bounded cross-references;
- an append-only target cross-reference beneath final H2 Section 42;
- one new direct contract-test module;
- bounded updates to the existing architecture and pre-execution planning tests.

It adds **no source, schema, migration, process, transport, worker, provider, model, service, queue, Git effect, or external contact**.

The implementation prompt also strengthens the reconnaissance plan by requiring:

- a causal red-before-green test;
- the full existing 4,256-node list to remain intact;
- all new test nodes to come only from the new test file;
- focused validation followed by one pre-audit full-suite run;
- exact nine-path provenance;
- no staging or publication before independent audit.

## Next action

Resume the **same Codex conversation**, change it to workspace-write, and send:

:chatgpt-content-reference{index="2"}

A successful response should end with:

```text
COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FROZEN_READY_FOR_INDEPENDENT_AUDIT
```

The lifecycle is:

```text
parent-only RW0-A docs/tests implementation
→ focused validation
→ one complete suite run
→ exact nine-path provenance
→ fresh independent audit
→ ACCEPT
→ feature-branch commit and PR
```

No additional broad reconnaissance is needed. The unresolved verifier, custodian, framing, Codex, host-authenticity, schema, latch, capsule-store, validation/review, and ES decisions are properly deferred to later tranches once the corrections above are applied. 

### Sources

- Codex RW0 reconnaissance and tranche recommendation.  
- Authority, custody, scenario, and transport choices requiring correction. 
- :chatgpt-content-reference{index="3"}
- Parent-only implementation and later independent-audit workflow. 

**Confidence:** 99% that RW0-A is the correct first tranche; 98% that these parent corrections prevent bootstrap fixtures from hardening into the target architecture.
