TITLE

Coordinator RW0-A phase-entry contract freeze — fresh independent re-audit
after the third-audit findings repair

ENGAGEMENT TYPE

Fresh-conversation independent audit.

Run this in a new Codex conversation with read-only repository posture.

Do not resume or use the implementation conversation or any preceding audit
conversation as this audit conversation. Their reports and retained evidence
are inputs only.

Repository mutation is not authorized. Do not edit, format, create, delete,
rename, chmod, clean repository paths, switch branches, stage, commit, amend,
push, create or update a PR, merge, rebase, reset, tag, release, deploy,
install dependencies, run live migrations, invoke a model/provider or Codex,
launch a worker/process, contact a host, Bridge, Execution Substrate,
Infrastructure Manager, or any remote.

Temporary audit output is authorized only beneath one audit-created,
operator-owned, non-symlink, mode-0700 external root. Do not write audit output
inside the repository. Remove only audit-created external artifacts when safe.
Do not delete, overwrite, or normalize implementation evidence.

If any repository byte, local permission, path, index entry, branch, Git
operation state, or topology changes, stop and report it. Do not silently
restore or clean it.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

WORKSTREAM

COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1

TRANCHE

RW0-A-PHASE-ENTRY-CONTRACT-FREEZE

PRIMARY OBJECTIVE

Independently re-audit the exact final ten-path RW0-A candidate after the
parent-only repair of the third independent audit’s two findings:

1. RW0-A-DECISION-C2B-CONFLICT — the target previously required both the
   existing pre-effect C2B `cancel` decision and a second post-reconciliation
   final `cancel` decision.

2. RW0-A-MD-02-CAUSALITY — the checked-in empty-visible-block mutants placed
   the hidden real body before the visible H3 owner heading rather than inside
   the same live owner range.

The implementation reports that:

- the existing immutable C2B `cancel` decision remains the sole pre-effect basis
  for the cancellation effect;
- the cancel effect cites that exact decision;
- no second C2B cancel or block decision is created on the active-cancel branch;
- RW0 now freezes a separate future Coordinator-owned durable terminal-outcome
  semantic fact after reconciliation;
- the terminal-outcome fact is not a `development_decision`, effect basis,
  executable permission, source observation, report, projection, or route
  truth;
- the terminal-outcome value domain remains:
  `accept`, `repair`, `replan`, `terminal_reject`, `block`, `cancel`;
- on non-cancel branches the terminal-outcome fact binds one same-kind C2B
  decision;
- on the active-cancel branch terminal-outcome `cancel` or `block` binds the
  exact pre-effect cancel decision plus the reconciled cancellation facts,
  without creating another C2B decision;
- the physical representation of the terminal-outcome fact remains deferred:
  no table, migration, row type, public type, receipt, graph, wire shape, or
  runtime was implemented;
- the direct, architecture, and remote-worker test surfaces now construct the
  exact in-range hidden-body case:
  visible intended H3, hidden byte-exact real body, visible empty BEGIN/END
  block, same owner range;
- both backtick and tilde fence styles are exercised across all four
  cross-references;
- direct, architecture, remote-worker, protected C2B3C, focused, collection,
  and full-suite gates are exact-green;
- all 4,284 candidate node IDs remain byte-identical to the opening candidate;
- the ten-path topology and protected C2B/C2B3C bytes remain exact;
- no source, schema, migration, runtime, public API, worker, model, network,
  supporting-repository, staging, or publication effect occurred.

Do not trust those claims as correctness evidence.

First bind this audit to the exact final manifest through the hash-pinned
closeout report. Then inspect the entire ten-path candidate and independently
reproduce every first-, second-, and third-audit finding class relevant to the
changed bytes.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Do not repair findings.

CURRENT COMMITTED BASELINE

Require and verify:

- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- HEAD tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- HEAD subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1

CURRENT IMPLEMENTATION BOUNDARY

Verify from the committed baseline and unchanged source that current capability
still stops at:

- internal C2A pure values and validators;
- private readers;
- guarded writer/transaction authority;
- private VS1B genesis;
- private C2B3D author-effect establishment with inert planned
  `direct_local_bootstrap` author delivery;
- private Section 41 pre-execution proposal selection;
- application generation 2 and migrations through 0003.

Verify that current capability still does not implement:

- executable parent-grant verification or subordinate authorization derivation;
- WorkSpec physical custody or bearer retrieval;
- direct-local adapter, supervisor, worker, Codex invocation, or process launch;
- dispatcher, queue, service, IPC, outbox/inbox, or reconciler;
- capsule builder/store/retrieval;
- validation, independent review, model invocation/proposal runtime, or
  post-execution semantic-decision runtime;
- RW0 terminal-outcome persistence or runtime;
- cancellation delivery/acknowledgement/runtime reconciliation;
- productive-direct-local acceptance latch;
- Git effect;
- Bridge or ES handoff;
- publication or autonomous loop.

EXPECTED OPENING REPOSITORY IDENTITY

Require exactly before correctness inspection:

- Physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- Subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1
- Dirty paths:
  exactly 10
- Tracked modifications:
  exactly 8
- Untracked:
  exactly 2
- Staged/unmerged:
  0/0
- No deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  or Git lock
- Repository residue:
  empty
- `git diff --check HEAD --`:
  clean.

Expected path classifications:

Tracked modifications:

.docs/c2b-durable-development-state.md
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_architecture_contracts.py
tests/test_c2b3c_author_effect_contract.py

Untracked:

.docs/rw0-remote-worker-contact-phase-entry.md
tests/test_rw0_remote_contact_phase_entry_contract.py

Expected local mode posture:

- these nine paths are regular working-tree mode `0644`:

  .docs/rw0-remote-worker-contact-phase-entry.md
  .docs/c2b-durable-development-state.md
  .docs/autonomous-software-development-operating-model.md
  .docs/worker-execution-boundary.md
  .docs/authority-boundaries.md
  .docs/durable-state-model.md
  tests/test_rw0_remote_contact_phase_entry_contract.py
  tests/test_remote_worker_pre_execution_planning_contract.py
  tests/test_architecture_contracts.py

- this path is regular working-tree mode `0600`, current-operator-owned, with no
  execute bits:

  tests/test_c2b3c_author_effect_contract.py

- Git index mode for every tracked candidate path is `100644`;
- no Git-recorded mode change exists.

The local `0600` mode is a restrictive working-tree metadata overlay. Do not
chmod it. It is not a defect when content, ownership, no-execute posture,
target manifest, and Git index mode match.

Do not fetch or contact a remote. Any identity, topology, path-set,
classification, mode, or branch mismatch is AUDIT_PROVENANCE_MISMATCH.

AUTHORITATIVE FINAL CLOSEOUT REPORT

Use exactly:

/private/tmp/ge-rw0a-third-repair-8fujftd9/final_provenance/report.json

Require:

- every path component lstat-safe and non-symlink;
- evidence root operator-owned, non-symlink, mode 0700;
- report regular and safely readable;
- SHA-256:
  b445b1f04bce237c4d0938528f3a42874e1735297989c2373c6b11313ee74866.

Copy the exact verified bytes into the audit root as an immutable mode-0400
report.

Parse the report and require it records, without contradiction:

- opening manifest:
  /private/tmp/ge-rw0a-second-repair-m22z10x8/final_provenance/run-2-manifest.json
- opening manifest SHA-256:
  cdfc576d53de6d116e5a46131319927df2fd56f0774ac6815eb0e0dda61323c5
- final manifest:
  /private/tmp/ge-rw0a-third-repair-8fujftd9/final_provenance/run-2-manifest.json
- final manifest size:
  2,328 bytes
- final manifest SHA-256:
  e46474d1b2af374e2bd84ded976e2bb1dd01399dfdc4a2b31b93bbd13f5c830e
- recipe source size:
  3,945 bytes
- recipe source SHA-256:
  db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
- exact final complete-output size and SHA-256;
- exact final tracked textual-diff SHA-256;
- branch, HEAD, upstream, ten-path topology, classifications, and modes;
- every per-file opening/final size and SHA-256;
- causal-red, exact in-range Markdown-causality, targeted, focused, collection,
  full-suite, and guard evidence identities;
- opening/final node-list identity.

Do not infer any omitted aggregate value. Extract it from the verified report.

If the report is missing, unsafe, malformed, has the wrong hash, omits a
required exact identity, or contradicts the supplied implementation closeout,
return AUDIT_PROVENANCE_MISMATCH.

AUTHORITATIVE FINAL AUDIT TARGET

After the report passes, safely verify:

/private/tmp/ge-rw0a-third-repair-8fujftd9/final_provenance/run-2-manifest.json

Require:

- every path component lstat-safe and non-symlink;
- regular and safely readable;
- exact size:
  2,328 bytes;
- SHA-256:
  e46474d1b2af374e2bd84ded976e2bb1dd01399dfdc4a2b31b93bbd13f5c830e.

Copy the exact bytes into the audit root as an immutable mode-0400 target.

Parse canonical JSON and require:

- recipe_id:
  governed-execution.audit-patch-manifest.v1
- branch:
  codex/rw0-phase-entry-contract-freeze
- head:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- textual_diff_sha256:
  exact value recorded by the verified closeout report
- exactly ten entries;
- exactly eight `tracked_modified`;
- exactly two `untracked`;
- C2B3C test regular mode `0600`;
- every other entry regular mode `0644`;
- no tracked addition/deletion, missing path, symlink, or unsupported type.

If the target is missing, unsafe, malformed, or different, return
AUDIT_PROVENANCE_MISMATCH. Do not reconstruct it from the live tree,
implementation report, or aggregate hashes.

PRECEDING THIRD-AUDIT TARGET

Safely verify and copy:

/private/tmp/ge-rw0a-second-repair-m22z10x8/final_provenance/run-2-manifest.json

Require:

- size:
  2,328 bytes
- SHA-256:
  cdfc576d53de6d116e5a46131319927df2fd56f0774ac6815eb0e0dda61323c5
- exact canonical topology and modes.

Compare preceding and final manifests entry by entry.

Require:

- no added or removed path;
- no classification or mode change;
- no change to:

  .docs/c2b-durable-development-state.md
  tests/test_c2b3c_author_effect_contract.py

Protected exact identities:

- `.docs/c2b-durable-development-state.md`
  - 1,884,626 bytes
  - SHA-256:
    5fd66a1266e63f8f026a27de7d84f42029813acdadc6b3ecb1978c3ff9ce9b1e
  - mode:
    0644

- `tests/test_c2b3c_author_effect_contract.py`
  - 416,182 bytes
  - SHA-256:
    935ca6fe7b18d39055d5cdc2c911302e7c0726304f3699472f3994a32f7b4778
  - working-tree mode:
    0600
  - Git index mode:
    100644

Only these eight paths may differ:

.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/worker-execution-boundary.md
tests/test_architecture_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py

The verified closeout report is the source for each exact opening/final
size/SHA-256 pair. Report all eight pairs. Any ninth changed entry or protected
entry mismatch is AUDIT_PROVENANCE_MISMATCH.

EXPECTED PROVENANCE RECIPE

Recipe ID:

governed-execution.audit-patch-manifest.v1

Exact source size:

3,945 bytes

Exact source SHA-256:

db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Use the exact source below. Do not normalize, improve, approximate, or version
it during the audit.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

OPENING PROVENANCE GATE

1. Verify exact recipe source size and SHA-256.
2. Safely classify:
   /tmp/ge-coordinator-b3a-audit-manifest-v1.json
3. If it exists:
   - require regular, non-symlink, operator-owned;
   - preserve exact pre-audit bytes and all safely available metadata in the
     audit root before the recipe runs;
   - do not delete unrelated evidence.
4. Run the exact recipe twice.
5. Require both invocations return 0 with empty stderr.
6. Require byte-identical complete stdout.
7. Require byte-identical canonical manifests.
8. Require generated canonical bytes equal the immutable final target
   byte-for-byte.
9. Require complete stdout size/hash and tracked-diff hash equal the exact values
   from the verified closeout report.
10. Compare every path, classification, type, mode, size, and SHA-256 entry.

Any mismatch is AUDIT_PROVENANCE_MISMATCH. Stop before correctness inspection.

PROTECTED BASELINE AND APPEND-ONLY PINS

Require:

1. `.docs/c2b-durable-development-state.md`

   The complete committed-baseline bytes remain the exact candidate prefix:

   - 1,883,380 bytes
   - SHA-256:
     9401d62a0eb36e0cca1af5b8a6a80b540ddc4c781fee3faaf7318546cb532ccc

2. The append-only RW0 H3 remains wholly after that prefix and after:

   `COORDINATOR_SECTION41_COMMITTED_CURRENT_STATUS_END`

3. Final visible H2 remains Section 42, with no H2 Section 43.

4. The exact C2B3C committed-status owner remains protected and compatible with
   later governed H3 extensions.

Require no diff outside the ten-path target, especially no diff in:

- AGENTS.md
- README.md
- .docs/architecture.md
- .docs/c2a-first-slice-semantic-protocol-contract.md
- .docs/software-development-progression-boundary.md
- every `src/**` path
- all SQL and migrations
- migration catalog and application generation
- schemas
- package exports and public protocols
- StateStore and WriterSession
- fixtures, scripts, configs, examples, or supporting repositories.

TARGETED AUDIT TASKS

Only after provenance matches, spawn exactly four bounded read-only audit tasks
in parallel when capacity permits. No nested subagents and no subagent-run
tests. If only three child slots are available, start the fourth immediately
when a slot frees. Make at most one retry for a failed start.

Give every task the same exact final manifest identity, all prior finding
classes, the third-audit parent repair decision, current contract, accepted
strategic target, reopened seams, compatibility obligations, non-goals, and
mutation prohibition.

1. C2B DECISION, TERMINAL-OUTCOME, AUTHORITY, AND NONIMPLEMENTATION AUDITOR

   Inspect the complete changed documentation and relevant unchanged C2A/C2B3D/
   Section 41 contracts.

   Determine whether:

   - the existing C2B `cancel` decision remains the sole immutable pre-effect
     cancel decision;
   - the cancel effect’s `basis_decision_ref` binds that exact decision;
   - no second cancel or block C2B decision appears on the active-cancel branch;
   - a separate future RW0 terminal-outcome semantic fact is coherently defined;
   - the terminal-outcome fact is not a `development_decision`, effect basis,
     permission, source observation, report, projection, or route truth;
   - the six terminal values do not widen or reinterpret the closed C2B
     decision-kind inventory;
   - non-cancel terminal values bind one same-kind C2B decision;
   - active-cancel terminal `cancel` or `block` binds the exact pre-effect cancel
     decision and reconciliation evidence without creating another decision;
   - the terminal-outcome fact cannot basis an effect or advance program version
     by itself;
   - its physical storage/identity/digest/receipt/schema/public representation
     remains deferred;
   - immutable fence-bound authorization-basis and subordinate-record relations
     from the prior repair remain exact;
   - one existing author lineage/invocation remains exact;
   - current runtime remains unsupported and fail-closed;
   - no source, schema, migration, table, public type, wire format, verifier, or
     runtime is claimed implemented.

2. CANCELLATION, RECOVERY, FACT OWNERSHIP, AND ES/IM AUDITOR

   Inspect the sole owner’s timelines, failure/recovery matrix,
   decision/outcome relations, worker facts, and route ownership.

   Determine whether:

   - cancel decision commit uncertainty is resolved before cancel-effect
     establishment;
   - request, acknowledgement, signal, process exit, workspace teardown, and
     source-native reconciliation remain distinct;
   - source reconciliation covers descendants, worker observations,
     cancellation facts, workspace cleanup, capsule/custody state, and
     delivery/source receipts;
   - active-cancel terminal outcome `cancel` requires complete unambiguous
     reconciliation;
   - active-cancel terminal outcome `block` is required for incomplete,
     contradictory, stale, or ambiguous reconciliation;
   - no second C2B block decision is created for that terminal `block`;
   - terminal-outcome commit uncertainty is resolved through guarded-writer
     readback before any new effect or successor;
   - reports, source observations, model proposals, and route receipts cannot
     establish the terminal outcome themselves;
   - non-cancel branches bind exactly one same-kind C2B decision;
   - only matching committed `accept` decision plus matching terminal outcome
     may bind/consume the future latch;
   - supervisor/worker fact ownership remains exact;
   - direct-local/ES/IM ownership remains exact;
   - no successor, Git, or publication follows any outcome.

3. MARKDOWN CAUSALITY AND TEST-NONWEAKENING AUDITOR

   Inspect all changed tests and all candidate documents.

   Determine whether:

   - the direct, architecture, and remote-worker test surfaces construct the
     exact in-range hidden-body case;
   - each applicable mutant orders:
     visible intended H3
     → balanced fence containing byte-exact valid real body
     → visible BEGIN
     → blank visible body
     → visible END
     → same owner-range terminator;
   - the hidden real body remains inside the same live owner range;
   - markers remain visible and correctly owned;
   - the broken raw checker accepts the exact mutant;
   - the authoritative visible-region oracle rejects the same bytes because the
     visible body is empty;
   - failure is not caused by missing markers, wrong owner, historical
     relocation, or premature range termination;
   - both backtick and tilde fence styles are used across all four
     cross-reference specs, with every spec covered;
   - the complete map-wide oracle, not merely an inner helper, exercises all
     specs;
   - one correct visible block plus irrelevant hidden duplicate remains
     accepted;
   - all prior sole-owner, leading/trailing prose, same-title relocation,
     hidden-marker, fenced-body, terminal-inventory, author-lineage,
     authorization-basis, cancellation, effect-delivery, worker-fact, and
     ES-boundary mutants remain causal;
   - no existing test was weakened, renamed, removed, skipped, xfailed,
     collapsed, or re-parameterized;
   - no new node was added.

4. PROVENANCE, SECURITY, PUBLIC-BOUNDARY, AND ARTIFACT AUDITOR

   Inspect:

   - the complete ten-path diff;
   - the exact eight-entry preceding-to-final delta;
   - protected C2B/C2B3C bytes;
   - local `0600` versus Git `100644` posture;
   - the closeout report and all retained validation records;
   - source/schema/migration/public-surface diff guards;
   - artifact and sensitive-material posture.

   Determine whether:

   - the candidate is genuinely docs/tests-only;
   - no credential, bearer, raw WorkSpec, prompt, transcript, endpoint, private
     host identity, or sensitive log is embedded;
   - no source, process, worker, model, service, network, or database behavior
     was introduced;
   - no evidence/report became authority;
   - the candidate is suitable for a later audited-byte feature-branch commit
     and PR gate.

Each task must return severity-ranked, path:line-grounded findings and state:

- current contract versus strategic target;
- patch defect versus pre-existing issue;
- impact;
- required correction;
- uncertainty;
- scope not inspected;
- mutation performed:
  no;
- tests run:
  no;
- nested subagents:
  no.

The parent must inspect and reconcile every report. Preserve factual,
interpretive, or target-level disagreements.

MANDATORY PARENT INSPECTION

Inspect directly:

- the hash-pinned closeout report;
- both authoritative manifests and the exact eight-entry comparison;
- all ten candidate paths;
- complete diff against HEAD;
- complete preceding-to-final diffs for every safely reconstructable changed
  entry;
- current C2A decision/effect/delivery/fence/observation/cancellation contracts;
- current C2B3D and Section 41 lineage/nonimplementation contracts;
- exact C2B cancel decision and cancel-effect basis relation;
- every changed sole-owner section, matrix, timeline, branch, and failure rule;
- all four changed bounded cross-reference bodies and structural owners;
- every changed test helper and strengthened existing test node;
- exact in-range hidden-body constructions and broken raw controls;
- protected C2B and C2B3C bytes;
- retained causal-red, targeted, focused, collection, full-suite, guard, and
  provenance records.

If complete preceding bytes for one changed untracked file are not safely
retained, report that as an evidence limitation. Do not invent a textual diff.
The exact manifest identity delta remains mandatory.

Do not re-audit unchanged runtime internals wholesale after exact no-diff proof,
unless changed documentation or tests contradict them.

ACCEPTANCE CHECK — EXISTING C2B CANCEL DECISION

Require:

1. `cancel` remains an existing immutable C2B decision kind.

2. The cancel decision commits before the cancellation effect.

3. The cancellation effect cites that exact decision through
   `basis_decision_ref`.

4. The decision preassigns the cancel effect/fence/first delivery/exact target
   as the existing C2B contract requires.

5. It is not request, acknowledgement, signal, process exit, teardown,
   reconciliation, semantic abandonment, semantic cancellation, or RW0
   terminal closure.

6. No second cancel decision exists after reconciliation.

7. No C2B decision kind is added, renamed, or reinterpreted by RW0-A.

Independently reject:

- a post-reconciliation second cancel decision;
- cancel effect based on the terminal-outcome fact;
- cancel effect based on a report or source observation;
- cancellation request treated as the decision;
- pre-effect decision omitted.

ACCEPTANCE CHECK — DISTINCT RW0 TERMINAL-OUTCOME FACT

Require:

- exactly one future Coordinator-owned durable RW0 terminal-outcome fact per RW0
  run;
- exact finite value domain:
  `accept`, `repair`, `replan`, `terminal_reject`, `block`, `cancel`;
- not a `development_decision`;
- not effect basis, permission, source observation, report, projection, model
  proposal, or route truth;
- not a program-version transition by itself;
- authored only by the future guarded Coordinator writer;
- binds exact phase-entry identity, existing semantic attempt, author
  effect/command/candidate, current Section 41 selection head, applicable
  decision refs/digests, effect/delivery/source evidence, capsule/validation/
  review/model evidence when reached, global-stop/current-head state, and latch
  postimage when applicable;
- establishes only that RW0 is terminal;
- authorizes no successor, effect, Git action, or publication;
- physical identity, digest, row, table, receipt, graph, migration,
  application-generation, public type, and wire representation remain deferred.

Independently reject:

- terminal outcome omitted;
- two terminal outcomes;
- terminal outcome represented as a report/projection/source observation;
- terminal outcome represented as another C2B decision;
- terminal outcome used as effect authority;
- terminal outcome advancing program version by itself;
- terminal-outcome storage/runtime claimed implemented now.

ACCEPTANCE CHECK — NON-CANCEL DECISION/OUTCOME RELATION

For:

`accept`, `repair`, `replan`, `terminal_reject`, `block`

require:

- exactly one immutable C2B decision of the same kind;
- terminal outcome binds that exact decision ref/digest;
- terminal outcome cannot contradict the decision kind/lineage;
- outcome is not established before the decision commits;
- no cancellation-control decision exists;
- only matching committed `accept` decision plus matching terminal outcome may
  bind/consume the future latch.

Independently reject:

- no same-kind decision;
- mismatched decision kind;
- outcome before decision commit;
- extra cancel decision;
- accept latch consumed from outcome alone;
- second progression decision.

ACCEPTANCE CHECK — ACTIVE-CANCEL DECISION/OUTCOME RELATION

Require:

- exactly one pre-effect C2B cancel decision;
- cancel effect cites it;
- request, acknowledgement, signal, exit, teardown, and reconciliation remain
  distinct;
- terminal `cancel` only after complete non-ambiguous reconciliation;
- terminal `block` for incomplete/contradictory/stale/ambiguous reconciliation;
- neither terminal value creates another C2B decision;
- terminal `block` is not `development_decision(kind=block)` on this branch;
- terminal outcome binds the exact cancel decision and reconciliation evidence;
- cancel decision does not itself prove terminal outcome;
- terminal outcome cannot basis the cancel effect;
- no other Coordinator progression decision exists on the branch;
- no successor, Git, or publication follows.

Independently reject:

- final cancel before reconciliation;
- final cancel on ambiguous reconciliation;
- missing block fallback;
- second cancel decision;
- second block decision;
- terminal outcome used as cancel-effect basis;
- reconciliation itself establishing outcome without Coordinator commit;
- report/model/source observation establishing outcome.

ACCEPTANCE CHECK — RECOVERY AND COMMIT UNCERTAINTY

Require:

- cancel-decision commit uncertainty resolved before cancel-effect
  establishment;
- cancel-effect/delivery ambiguity remains a source/reconciliation matter;
- terminal-outcome commit uncertainty resolved by exact guarded-writer readback;
- unresolved terminal-outcome commit permits no new effect or successor;
- replay/recovery never fabricates a second cancel or block decision;
- evidence/projections never become terminal-outcome authority.

ACCEPTANCE CHECK — EXACT IN-RANGE EMPTY-VISIBLE-BLOCK CAUSALITY

For the sole owner or each applicable cross-reference specification require the
checked-in mutant to preserve this exact owner-range order:

1. visible intended owner H3;
2. balanced backtick or tilde fence containing a byte-exact otherwise-valid real
   marked body;
3. visible BEGIN marker;
4. only blank lines between BEGIN and END;
5. visible END marker;
6. no same-or-higher heading before the range terminator.

Require:

- hidden body actually lies inside the same live owner range;
- raw markers/body remain present;
- deliberately broken raw checker accepts;
- authoritative visible-region oracle rejects because visible body is empty;
- failure is not due to absent markers, wrong owner, historical relocation, or
  early range end;
- live positive document accepts;
- valid visible block plus irrelevant hidden duplicate accepts;
- two visible blocks reject.

Across the four cross-reference specs:

- every spec is exercised through the complete map-wide oracle;
- both backtick and tilde fences are used;
- at least one fence style is applied to every spec.

Independently reconstruct the exact mutants rather than trusting the checked-in
assertions.

PRIOR-FINDING REGRESSION MATRIX

Independently verify that all earlier findings remain closed:

- one author delivery versus distinct later current-effect deliveries;
- no author redelivery/relaunch/replacement lineage;
- model proposal not a DeliveryEnvelope effect;
- existing inert author fences plus separate subordinate authorization;
- per-fence basis equality/common-family verification;
- fail-closed incompatible authorization family;
- post-teardown reconciliation;
- one final terminal outcome;
- supervisor launch versus worker-authored start;
- direct-local versus ES route ownership;
- sole-owner visible marker pair;
- all visible owner-range prose inside markers;
- four normalized-identical visible cross-references;
- hidden duplicate acceptance;
- same-title/historical/fenced/split/duplicate-visible rejection;
- independent terminal inventories and stop rules;
- C2B3C committed-status extension compatibility and exact duplicate diagnostic;
- current/nonimplementation and all deferred seams.

CURRENT-VERSUS-TARGET AND DEFERRED DECISIONS

Require:

- accepted strategic target, not current-runtime claim;
- external parent grant plus future Coordinator-derived narrower subordinate
  record;
- raw WorkSpec privacy and ref/digest non-authority;
- exact custodian/issuer/backend/transport/Codex/sandbox/framing/schema/latch/
  capsule/validator/reviewer/model/ES details remain deferred;
- terminal-outcome representation remains deferred;
- one qualified remote Linux host, no fallback, no third adapter;
- provisional ES fixture remains non-authoritative and stale-able;
- base/path drift requires replan/new WorkSpec;
- author versus later current-effect delivery split remains exact;
- supervisor/worker fact ownership remains exact;
- direct-local/ES/IM ownership remains exact;
- no Git/publication in RW0.

IMPLEMENTATION EVIDENCE TO INSPECT, NOT TRUST

Safely inspect:

/private/tmp/ge-rw0a-third-repair-8fujftd9

At minimum inspect through the verified closeout report:

- causal-red evidence;
- exact in-range Markdown-causality evidence;
- final direct 28/28;
- final architecture 30/30;
- final remote-worker 774/774;
- protected C2B3C 46/46;
- focused 1,565/1,565;
- final collection and opening/final node lists;
- full-suite 4,284/4,284;
- final guards;
- two final provenance runs;
- per-file opening/final comparison.

No correctness credit comes from implementation evidence.

The preceding audit root is:

/private/tmp/ge-rw0a-independent-reaudit-hop9mho3

Inspect its independent finding and exact in-range mutant records when safely
available. Missing retained records are evidence limitations, not automatic
acceptance or rejection.

VALIDATION ISOLATION

Use one audit-created external, operator-owned, non-symlink, mode-0700 root.

For every pytest child:

- save actual caller umask;
- create evidence under secure posture;
- restore caller umask before launch;
- record child-observed umask and require numerical equality;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`
  - `LC_ALL=C`
  - `LANG=C`
  - `PYTHONDONTWRITEBYTECODE=1`
  - distinct external `PYTHONPYCACHEPREFIX`
  - distinct external `TMPDIR`
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
  - `PYTEST_ADDOPTS=''`
  - `PYTHONHASHSEED=0`
  - `python3 -B -m pytest`
  - `-p no:cacheprovider`
  - `-W error`
  - distinct external `--basetemp`
  - external `--junitxml`
  - serial execution.

Retain exact argv, environment, caller/child umask, return code, elapsed time,
stdout/stderr/JUnit sizes and SHA-256, parsed counts, warnings, parse errors,
unmapped cases, and before/after target equality.

DIRECT RW0-A ORACLE — EXACTLY ONCE

Run:

tests/test_rw0_remote_contact_phase_entry_contract.py

Require exactly 28/28 green.

ARCHITECTURE REGRESSION — EXACTLY ONCE

Run:

tests/test_architecture_contracts.py

Require exactly 30/30 green.

REMOTE-WORKER REGRESSION — EXACTLY ONCE

Run:

tests/test_remote_worker_pre_execution_planning_contract.py

Require exactly 774/774 green.

C2B3C PROTECTED REGRESSION — EXACTLY ONCE

Run:

tests/test_c2b3c_author_effect_contract.py

Require exactly 46/46 green.

COMPLETE RW0-A FOCUSED REGRESSION — EXACTLY ONCE

Run exactly:

tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_software_development_progression_boundary.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_worker_execution_semantic_boundaries.py

Require exactly 1,565/1,565 green.

NODE IDENTITY

After focused validation:

1. Collect the candidate exactly once.
2. Require exactly 4,284 node IDs.
3. Create one clean external `git archive HEAD`.
4. Collect HEAD exactly once.
5. Require exactly 4,256 HEAD node IDs.
6. Require:
   - intersection:
     4,256;
   - candidate-only:
     exactly 28;
   - HEAD-only:
     0;
   - all 28 candidate-only nodes belong to
     `tests/test_rw0_remote_contact_phase_entry_contract.py`;
   - no existing node changed identity or order.
7. Require exact candidate node-list SHA-256:
   7fb16833d1fcf8916f62ad17b0238b87b8cda8bb03432039771290bc713d12e8
8. Require exact existing-file counts:
   - architecture:
     30;
   - C2B3C:
     46;
   - remote-worker:
     774;
   - direct RW0-A:
     28.

FULL SUITE — EXACTLY ONCE

Only after inspection, independent mutants, targeted/focused validation, node
comparison, and artifact cleanup are green, run the complete repository suite
exactly once:

python3 -B -m pytest -p no:cacheprovider -W error \
  --basetemp=<external> \
  --junitxml=<external> \
  .

Require exactly:

- 4,284 collected;
- 4,284 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository bytes, modes, topology, and target manifest unchanged.

Do not run a second full-suite attempt. If immutable JUnit parsing initially
misclassifies paths, reparse the same JUnit without rerunning pytest.

FINAL GUARDS

Require:

- exact ten-path target set;
- exactly eight tracked modifications and two untracked paths;
- zero staged or unmerged paths;
- expected local mode posture, including C2B3C `0600`;
- Git index mode `100644` for every tracked candidate path;
- no Git-recorded mode change;
- no path outside target changed;
- protected C2B and C2B3C entries exact;
- append-only prefix exact;
- final H2 Section 42 and no Section 43;
- four bounded cross-reference bodies normalized-identical;
- one sole detailed RW0 owner;
- exact existing C2B cancel-decision/effect-basis relation;
- exactly one separate future RW0 terminal-outcome fact;
- no second cancel or block C2B decision on active cancel;
- exact non-cancel decision/outcome binding;
- exact active-cancel reconciliation/outcome binding;
- terminal-outcome representation deferred;
- exact in-range hidden-body causal coverage;
- no current implementation overclaim;
- no enduring ES fixture, custodian, SSH/framing, Codex, schema, latch,
  capsule-backend, validator/reviewer/model-adapter, terminal-outcome backend,
  or ES reliable-submit choice accidentally frozen;
- no source, SQL, migration, catalog, schema, application-generation, package,
  public protocol, StateStore, WriterSession, runtime, fixture, script, config,
  or supporting-repository diff;
- `git diff --check` clean;
- no repository cache, bytecode, pytest cache, database, journal, WAL/SHM,
  build output, archive, generated manifest, or OS metadata;
- no Git operation or lock;
- no remote contact or runtime effect.

FINDING AND VERDICT RULES

Classify findings by:

- current-versus-target contract drift;
- C2B decision/terminal-outcome conflict;
- effect-basis or authority/fence drift;
- author-lineage or invocation drift;
- ambiguity/recovery/cancellation defect;
- Markdown ownership/liveness or mutation-causality defect;
- test non-weakening defect;
- ES/IM ownership drift;
- source/public-boundary widening;
- security/privacy issue;
- provenance/validation gap;
- artifact hygiene issue;
- pre-existing observation outside the patch.

Use severity:

critical
high
medium
low
observation

For every finding report:

- stable ID;
- type and severity;
- exact path:line evidence;
- current contract or strategic target;
- impact;
- required correction;
- uncertainty;
- patch defect or pre-existing issue.

ACCEPT only when:

- opening and closing provenance equal the exact final target;
- closeout report and final manifest both verify exactly;
- preceding and final manifests differ only inside the eight authorized paths,
  with the protected two exact;
- all four audit tasks complete;
- both third-audit findings are independently and causally closed;
- all first- and second-audit finding classes remain closed;
- current implementation is not overclaimed;
- existing C2B cancel decision remains the sole cancel-effect basis;
- separate terminal-outcome fact is coherent and non-authorizing;
- no second cancel/block C2B decision exists on active cancel;
- non-cancel and cancel decision/outcome relations are exact;
- terminal-outcome representation remains deferred;
- exact in-range Markdown mutants are checked in and causal;
- no existing test was weakened or its node identity changed;
- direct, architecture, remote-worker, C2B3C, focused, node, and full-suite
  validation are exact-green;
- no Critical, High, Medium, or Low patch defect remains;
- the exact candidate is suitable for an audited-byte feature-branch commit,
  push, PR, and later squash-merge gate.

Use BLOCK for a repairable defect, non-green validation, materially incomplete
evidence, or unresolved uncertainty preventing acceptance.

Use REJECT only for a fundamental architecture or authority failure that cannot
be repaired within RW0-A.

Use AUDIT_PROVENANCE_MISMATCH for target-byte, closeout-report, branch,
path-set, topology, recipe, retained-manifest, mode, or classification mismatch.

CLOSEOUT PROVENANCE

After all inspection and validation, and after removing only safe
audit-created external artifacts:

1. Run the exact recipe twice again.
2. Require complete identity with the immutable opening target.
3. Recheck protected entries, append-only prefix, modes, Git index modes, path
   set, topology, residue, operations, and locks.
4. Do not accept if audit activity changed repository bytes or metadata, even if
   later restored.

FINAL REPORT

Begin with exactly one primary verdict token:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Then report:

1. Exact opening and closing identity/provenance.
2. Verified closeout-report identity and extracted target metadata.
3. Exact preceding-to-final path comparison and eight-entry identities.
4. Audit tasks, completion, retries, and disagreements.
5. Complete severity-ranked finding ledger.
6. Disposition of every first-, second-, and third-audit finding.
7. Current implementation versus RW0 target assessment.
8. Existing C2B cancel-decision/effect-basis assessment.
9. Separate terminal-outcome semantic-contract assessment.
10. Non-cancel and active-cancel decision/outcome/recovery assessment.
11. Exact in-range Markdown-causality results across all test surfaces.
12. Prior-finding regression matrix.
13. Test non-weakening and node-identity assessment.
14. Direct, architecture, remote-worker, C2B3C, focused, and full-suite
    validation.
15. Protected-byte, mode, public-boundary, security, and artifact checks.
16. Limitations and separate provenance, validation, and implementation
    confidence estimates.

If ACCEPT, include:

COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FREEZE_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

If not ACCEPT, do not provide a commit or PR prompt and do not repair.

Required closing statements:

REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
