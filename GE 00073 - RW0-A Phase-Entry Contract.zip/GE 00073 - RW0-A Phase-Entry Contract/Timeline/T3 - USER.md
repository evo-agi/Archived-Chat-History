Here is Codex's response:

Reconnaissance is complete and the first implementation tranche is ready to proceed as a bounded docs-and-contract-tests freeze. No repository was modified, no tests or migrations ran, and no worker, model, service, network, or remote-host contact occurred.

## A. Baselines and inspection boundary

| Repository | Committed identity | Upstream/worktrees | Final status |
|---|---|---|---|
| Coordinator | `trunk_dev`; HEAD `1a894c5527c610ab40d8e5ae5e530a762c6e60bf`; tree `53c1834e7e3364c9b278153d5be8b0315d88ff5c`; sole parent `394d625aa63935140eeaf88ecff6f59f0547cb7e`; subject `docs: normalize Coordinator post-publication status (#1)` | `origin/trunk_dev`; ahead/behind `0/0`; 1 worktree | Clean index/worktree/untracked state; no Git operation or lock |
| Execution Substrate | `trunk_dev`; HEAD `b92bd9884106154d25342e1573dcc4c312311436`; tree `cdd4e44bac15c1952d70997143040644361f0bb1` | `origin/trunk_dev`; ahead 1, behind 0; 5 worktrees | Pre-existing overlay: 64 unstaged tracked modifications and 11 untracked files; no staged/unmerged state or lock |
| Infrastructure Manager | `trunk_dev`; HEAD `5ddde89b416e8898719c5640ca75edcaaeb8ae41`; tree `9303ac89c856e98a8ea513dd6de3b5de9e23d5a5`; parent `d013e82d972af3700bfd8f2ab98d9f22a8bf12dc` | `origin/trunk_dev`; ahead 2, behind 0; 1 worktree | Clean; no Git operation or lock |

The final recheck matched the opening state for all three repositories. ES conclusions use committed `HEAD:path` material only; its local overlay, including the untracked resolved-plan/resource-limit/staging-custody files, is non-authoritative.

Exactly four bounded explorers completed:

- authority, custody, and privacy;
- durable progression and state;
- worker, host, process, and capsule;
- validation, failure recovery, and ES conformance.

No nested agents were created. Inspection stopped at the requested Coordinator surfaces and relevant committed ES/IM contracts. Bridge, Control Plane, Maintenance Agent, GitHub, live databases, services, credentials, and actual remote hosts were not inspected.

No live Coordinator state database was supplied. Therefore, the report establishes the implemented family contracts and the exact required entry pattern; it does not claim that a production K8 selection family currently exists.

## B. One bounded RW0 scenario

The frozen first productive scenario is:

1. **Target repository/base:** Execution Substrate at committed base `b92bd9884106154d25342e1573dcc4c312311436`, tree `cdd4e44bac15c1952d70997143040644361f0bb1`, materialized in a fresh isolated remote workspace. The dirty main ES worktree is never copied or treated as base truth.

2. **Allowed candidate change:** docs/docs-contract reclassification only, limited to:

   - `PLANS.md`
   - `.docs/system_overview/hybrid_integration_architecture_adr.md`
   - `docs_contract_test.go`

   No ES runtime behavior, admission implementation, reliable-submit implementation, or privileged-operation behavior may change.

3. **Entry state:** one current Section 41 selection at exact K8 with disposition `selected_for_dispatch_gates`, causally backed by its existing C2B3D author-effect, command, fences, candidate, and initial `direct_local_bootstrap` delivery. Baseline drift requires replan/new WorkSpec; it cannot be absorbed.

4. **Authority:** the parent grant and narrower attempt/effect authorization are externally authored. Coordinator only verifies and durably binds a current safe attestation; it does not mint or reinterpret executable authority.

5. **WorkSpec/plan custody:** immutable private bytes are operator-preprovisioned in a remote private-input custodian. This is standing provisioning, not synchronous per-attempt user approval. Retrieval uses one expiring, one-use, attempt/effect/audience-bound capability delivered out of band.

6. **Host:** one owner-neutrally qualified Linux host. No Mac, Coordinator-host, or alternate-host fallback.

7. **Transport:** one host-key-pinned SSH forced command within the existing `direct_local_bootstrap` route. No listener, mailbox, daemon, port forwarding, X11, agent forwarding, or third adapter kind.

8. **Process topology:** Coordinator → ephemeral direct-local adapter → remote supervisor → separate author worker. Capsule builder/store, validator, independent reviewer, and model-proposal invocation remain separate roles. None receives Coordinator SQLite/writer authority.

9. **Codex seam:** unresolved and explicitly blocking before worker-source execution. Codex CLI is the preferred candidate, but it must first prove exact noninteractive behavior, bounded terminal output, cancellation, ephemeral state, credential isolation, transcript suppression, and no Git side effect. App Server cannot be substituted silently.

10. **Capsule:** one immutable manifest covering exactly the three allowed paths, with referenced before/after blobs, hashes, lengths, and modes. Validation and review operate on an isolated reconstruction of the exact base plus capsule—not the worker’s mutable workspace.

11. **Validation:**

    - capsule/path/base structural verification;
    - `git diff --check` for the three allowed paths;
    - `env GOTOOLCHAIN=local GOPROXY=off go test .`;
    - `env GOTOOLCHAIN=local GOPROXY=off go test ./...`.

12. **Terminal decision:** exactly one of `accept`, `repair`, `replan`, `terminal_reject`, `block`, or `cancel`. Every outcome ends RW0. Repair/replan may describe or preassign successor state, but no successor is launched.

13. **Maximum effect ceiling:** one real delivery attempt, one worker invocation, one candidate/capsule, bounded validation, one independent review, one model proposal, and one Coordinator decision. Zero Git commits, pushes, PRs, merges, deployments, or publication.

## C. Current-versus-target ledger

### Exact current durable starting families

| Family | Exact durable content and result |
|---|---|
| VS1B genesis | 9 physical rows: program head, accepted-intent revision, work head, work revision, initialize decision, program version, membership, WorkSpec safe binding, receipt. The graph has 8 members. Program/work heads start at revision 0. The receipt projection binds program/version/decision/work/WorkSpec/preassigned attempt/candidate/time. |
| C2B3D author effect | 10 physical rows: semantic attempt, attempt fence, author-effect intent, effect fence, author command, pending authority evaluation, effect head, initial delivery attempt, delivery head, receipt. The graph has 9 members. Attempt is `established`; authority is `pending/external_verification_pending`; effect head revision 0 is `ready_for_delivery`; initial delivery number 1 and delivery head revision 0 are `planned`. Its result binds mutation/command, program/version/intent/decision/work/WorkSpec, attempt, candidate, effect/fence, delivery, and transaction time. |
| Section 41 selection | 22 physical rows/21 graph members without readiness evidence, or 23/22 with it: source invocation, planning context, private artifact binding, proposal, plan projection, 14/15 evidence bindings, Coordinator disposition, selection-head postimage, and receipt. The receipt is physical but excluded from the graph. The result binds proposal/disposition, program/attempt/candidate/effect, selection revision/digest, authority-selection observation, graph, timestamp, and receipt digest. |

C2B3D precedes Section 41: Section 41 reconstructs the exact C2B3D lineage and selects it for later gates without advancing its effect or delivery heads. `selected_for_dispatch_gates` remains non-executable planning state. [Section 41’s preserved non-claims](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md:24510>) and [the C2B3D/Section 41 durable model](</Users/ds/Repositories/Governed Execution Coordinator/.docs/durable-state-model.md:475>) are explicit about this boundary.

| Seam | Classification | Reconciled state |
|---|---|---|
| C2A identities/digests/fences | Current invariant | Preserve byte-for-byte; no competing schema or identity. |
| C2B3D planned delivery | Current compatibility edge | Sufficient author intent for RW0; do not mint another author effect, command, candidate, or initial delivery. |
| Section 41 selection | Current contract | Mandatory current entry lineage, but never launch authority. |
| Executable authorization | Current fail-closed contract | Unsupported today. RW0 target uses externally authored authorization and separate verification. |
| WorkSpec physical custody | Reopened seam | Target choice is an operator-preprovisioned private custodian with one-use OOB retrieval authority. |
| Pre-contact phase-entry fact | Accepted target | Must be committed before verifier/host/custody contact; exact schema is deferred to a later schema tranche. |
| Delivery/source observation ingest | Reopened seam | Needs durable source claims, ingest dispositions, and recovery; cannot be adapter memory. |
| Qualified host | Accepted target plus reopened mechanics | Owner-neutral readiness observation plus effect-bound qualification evaluation; IM may only corroborate. |
| Worker/supervisor | Accepted target | Separate OS processes on one remote Linux host. Packaging and containment mechanics remain deferred. |
| Codex invocation | Reported unresolved decision | CLI preferred, but offline capability proof is mandatory before source/runtime work. |
| Capsule | Existing semantic contract plus reopened custody | Freeze immutable manifest and referenced before/after blobs; storage technology and exact retention duration remain later decisions. |
| Validation/review/model | Accepted target, not implemented | Separate source invocations and facts; model proposal is non-authoritative. |
| Post-execution decision | Representable but unimplemented | Coordinator alone decides; current migration lacks the complete runtime/evidence relation. |
| One-shot acceptance latch | Reopened target seam | First committed direct-local `accept` must atomically consume it. |
| Durable schema | Current tip 0003 | A successor migration, ordinarily 0004, will be necessary; migrations 0001–0003 remain immutable. |
| ES routing | Deferred to ES ownership | Current ES unkeyed submit is unusable for RW0 reliability. |
| Git/publication | Outside RW0 | Separate future effect only. |

Current generation 2/migrations 0001–0003 do not contain a complete phase-entry receipt, worker/source claim and ingest family, safe capsule binding, exact decision-evidence relation, or acceptance latch. That is why later schema work is required; the first tranche does not perform it.

## D. Authority, custody, and fact-owner matrix

| Fact/material | Author/authority and verifier | Recorder/custodian | Safe Coordinator binding | Prohibited retention and freshness rule |
|---|---|---|---|---|
| Parent grant | External standing-policy authority; separate current verifier | External authority system; Coordinator stores verification projection | Grant ref/digest, audience, ceiling/binding result, status, verified/expiry times | No raw grant, signature, trust key, credential, or bearer. Recheck revocation/expiry/current scope immediately before retrieval/launch. |
| Attempt/effect authorization | Externally authored narrower subordinate authority for RW0 | External authority custodian; Coordinator safe binding only | Authorization refs/digests and exact attempt/effect/fence/repository/base/path relations | Coordinator does not mint, renew, widen, or outlive it. |
| Selected proposal/disposition | Model proposes; Coordinator owns disposition | Coordinator SQLite | K8/L34, proposal/disposition refs and digests, head revision/digest | No raw prompt, reasoning, response, provider session, or private artifact bytes. Must be the current head. |
| Raw WorkSpec and selected-plan bytes | Accepted intent/operator provisioning; custodian verifies capability | Private remote input custodian | Safe artifact refs/digests and a non-bearer custody-receipt ref | Never SQLite, argv, environment, logs, reports, capsule, or public errors. Bearer is expiring/one-use and discarded on crash. |
| Host readiness | Host-owning process authors observation; Coordinator evaluates fitness for the exact effect | Host evidence custodian; Coordinator records safe observation/evaluation | Opaque host-binding/profile/evidence refs and digests, observed/expiry times | No hostname, IP, filesystem path, host key, credential, or IM bundle body. Must be current for repository/base/scenario. |
| Delivery/process facts | Adapter/supervisor/OS | Source-owned terminal/reconciliation record; bounded Coordinator observation | Delivery/source invocation/observation refs, finite outcome, safe correlation ref | No raw stdout/stderr, PID, endpoint, session secret, or adapter memory as truth. |
| Candidate bytes | Worker authors candidate | Attempt workspace until seal | Candidate ref/digest only | No candidate bytes in SQLite/report. Exit does not prove capture or absence. |
| Capsule | Builder owns manifest/seal; store owns physical custody | Private immutable content-addressed store | Capsule ref, manifest digest, portable digest, safe custody ref | No physical path, retrieval bearer, WorkSpec, prompt, transcript, log, credential, or arbitrary workspace metadata. |
| Validation | Validator/test runtime | Private detailed evidence; Coordinator bounded observation | Exact capsule/base/tool profile, finite result/reason, safe evidence refs | Detailed command output stays private. Observation must be current and exact-capsule-bound. |
| Independent review | Separate reviewer role/invocation | Reviewer evidence custodian; Coordinator bounded observation | Exact capsule binding, reviewer invocation/observation refs, finite result | No author workspace write access, author credential reuse, or Coordinator writer access. |
| Model proposal | Model adapter/configured model proposes | Private provider/session custodian; Coordinator stores typed proposal | Proposal ref/digest, evidence bindings, normalized recommendation | No prompt, raw response, hidden reasoning, endpoint, header, session, transcript, or credential. |
| Semantic decision/latch | Coordinator writer alone | Coordinator SQLite | Decision ref/digest, exact evidence graph, current heads, latch postimage | No source observation becomes acceptance by itself. Commit uncertainty must be resolved before further contact. |

Raw WorkSpec handling follows the existing privacy boundary: safe refs/digests are not retrieval authority. [C2A WorkSpec and delivery boundaries](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2a-first-slice-semantic-protocol-contract.md:649>) and [Coordinator authority roles](</Users/ds/Repositories/Governed Execution Coordinator/.docs/authority-boundaries.md:134>) remain controlling.

## E. Identity and correlation matrix

The exact RW0 entry address is:

```text
K8 = (
  program_ref,
  semantic_attempt_ref,
  candidate_ref,
  effect_intent_ref,
  author_command_ref,
  attempt_fence_ref,
  effect_fence_ref,
  delivery_attempt_ref
)
```

The full L34 selection-head lineage remains authoritative and unchanged. [The implemented K8/L34 field inventories](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py:48>) are not widened.

| Stage | Required identity/correlation | Non-collapse rule |
|---|---|---|
| Program/work | Program, version, accepted intent, work item/revision, WorkSpec safe binding | Program/work identity is not attempt or effect identity. |
| Author attempt | Existing semantic attempt and candidate | Do not create a second attempt merely to launch the selected work. |
| Author effect | Existing effect intent, author command, attempt fence, effect fence | Authorization evaluation and selected proposal do not replace the effect or fences. |
| Initial delivery | Existing C2B3D `delivery_attempt_ref`, envelope digest, route, safe adapter correlation | Exactly one actual RW0 delivery. Route/session/run identifiers cannot alter semantic identity. |
| Section 41 selection | K8 plus expected selected proposal/disposition, `selected_for_dispatch_gates`, head revision/digest and full L34 | K8 alone is insufficient without the exact current head postimage. |
| Phase-entry/contact claim | New mutation identity bound to K8, current effect/delivery heads, current selection preimage and global-stop state | It reserves/reconciles this phase; it does not authorize launch. |
| Authority/host/custody gates | Independent verification, readiness, qualification and custody receipt refs/digests | None may be folded into a digest-only permission claim. |
| Source invocation | One identity for each author, validator, reviewer, or model invocation | Invocation, delivery, observation, and semantic decision remain distinct. |
| Observation | Source-kind, invocation, observation ref/digest and exact semantic bindings | Duplicate/conflicting/stale/late observations retain their own ingest disposition. |
| Capsule | Candidate ref, manifest ref/digest, portable capsule digest, physical custody ref | Portable identity excludes storage path, encryption, host, and retrieval capability. |
| Validation/review | Separate effect/delivery/invocation/observation identities | Validation success and review success are evidence, never acceptance. |
| Model proposal | Separate model invocation and proposal identity | Proposal is not a Coordinator decision. |
| Decision/latch | Decision ref/digest and acceptance-latch postimage | Only a committed Coordinator `accept` consumes the latch. |

## F. End-to-end durable/fact timeline

| Order | Coordinator-owned durable fact | External/source truth |
|---|---|---|
| 1 | Reconstruct VS1B → C2B3D → current Section 41 K8/L34; require selected disposition, current heads, exact base/path ceiling, clear global stop | No external contact |
| 2 | Commit a receipt-backed phase-entry/contact claim using CAS over the current selection/effect/delivery state | Still no external contact |
| 3 | — | External verifier evaluates grant/subauthorization/fences/expiry/revocation; host owner supplies current readiness; custodian proves safe availability |
| 4 | Commit the fresh launch-gate result, binding safe authority, host, custody, current-head and global-stop facts | No raw authority or bearer persisted |
| 5 | Record/reconcile retrieval source fact | Custodian redeems one-use capability and supplies exact WorkSpec/selected-plan bytes out of band |
| 6 | CAS existing effect/delivery state into its pre-send claim; retain the existing initial delivery identity | Direct-local adapter performs the one host-key-pinned SSH forced command |
| 7 | Ingest ack/reject/unknown as a source observation | Supervisor’s durable source-native receipt is transport truth |
| 8 | Ingest start/deadline/exit/cancel observations | Supervisor starts and controls one separate worker process |
| 9 | Record candidate-capture and capsule-safe bindings after ingest | Worker produces bytes; builder seals immutable capsule; store takes custody |
| 10 | Establish and ingest a separate validation effect/invocation/observation | Validator reconstructs exact base+capsule and executes bounded commands |
| 11 | Establish and ingest a separate review effect/invocation/observation | Independent reviewer reads the exact sealed capsule |
| 12 | Establish and ingest a separate model invocation/proposal | Model adapter produces one normalized non-authoritative proposal |
| 13 | Reread current evidence, authority, global stop, effect ceiling and heads; commit one semantic decision | No external actor decides progression |
| 14 | If `accept`, consume the one-way productive-direct-local latch atomically with the decision | No Git effect follows |
| 15 | Record terminal teardown/custody facts | Supervisor reaps processes and removes mutable workspace; capsule remains retained through all unresolved recovery and later Git handoff |

Observation ingest must preserve the existing `duplicate_exact`, `conflict_quarantined`, `ambiguous_quarantined`, `stale_retained`, `late_retained`, and `recorded` precedence. [C2A observation and redelivery rules](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2a-first-slice-semantic-protocol-contract.md:1020>) remain unchanged.

Decision evidence minimum for this scenario:

- `accept`: exact capsule, successful worker terminal evidence, validation `passed`, review `passed`, unambiguous source facts, current authority/fences, clear global stop, and available latch.
- `repair`: exact capsule plus bounded defect evidence and a repair proposal; it may establish successor intent later but does not launch it.
- `replan`: evidence that the selected plan/base/policy/requirements are no longer suitable; no same-run replacement.
- `terminal_reject`: definitive unacceptable/invalid evidence.
- `block`: missing, stale, inconclusive, ambiguous, unauthorized, or globally stopped evidence.
- `cancel`: current risk/policy/global-stop basis and distinct cancellation facts; a model recommendation is not required to reduce risk.

## G. Failure, ambiguity, cancellation, and recovery matrix

| Phase | Failure/unknown and authoritative owner | Durable response; retry/reconciliation | Global stop/restart; artifact possibility |
|---|---|---|---|
| Phase-entry claim | Commit error/unknown; Coordinator SQLite | No contact. Fresh-writer readback yields committed, definitely absent, or unresolved. Only definitely absent permits deliberate same-command reissue; unresolved stops. | Restart resolves receipt/head first. No candidate/capsule. |
| Authority/host gates | Missing, stale, expired, revoked, incompatible or ambiguous; external verifier/host owner | Record blocked/unknown gate result; no retrieval or launch. A later fresh evaluation is a new current observation, not reinterpretation. | Active stop blocks. No candidate/capsule. |
| WorkSpec retrieval | Expired/revoked/consumed/failed/unknown; custodian | Record/reconcile custody outcome. Never reuse the bearer. Fresh handoff only after current gates and proof that launch was not accepted. | Stop closes capability. Restart discards bearer and queries custodian. No candidate unless launch separately occurred. |
| Delivery | Rejected, response lost, unknown acceptance; supervisor/source receipt | Record exact observation; no second delivery in RW0. Reconcile source-native receipt. C2A’s five-condition redelivery remains preserved for future work but is not exercised here. | Stop before send prevents send. After send, candidate may exist even without ack. |
| Worker invocation | Start/exit/deadline/terminal-frame ambiguity; supervisor/OS | Ingest bounded observations; do not infer rejection or completion. Commit cancellation intent/effect before signaling. No relaunch. | Restart reconciles supervisor/process/store. Candidate may exist. |
| Candidate capture/seal | Capture or seal failed/unknown; worker/builder/store | Record distinct capture/seal facts; block progression. Reconcile content store before assuming absence. No author rerun. | Stop prevents later phases. Candidate may exist; capsule may or may not exist. |
| Validation | `failed`, `inconclusive`, `not_run`, or invocation unknown; validator | No accept. Separate explicit later effect would be required for another run, but RW0 terminates with repair/replan/block/cancel. | Stop cancels active validator separately. Capsule exists and is retained. |
| Independent review | `failed`, `inconclusive`, or invocation unknown; reviewer | No accept and no automatic second reviewer invocation. Reconcile or block. | Stop prevents model phase; capsule remains. |
| Model proposal | Missing, malformed, ambiguous or lost normalized proposal; model adapter | Raw response cannot drive a decision. No blind provider reinvocation; reconcile source invocation or commit `block`. | Stop prevents new model effect. Capsule/evidence remain. |
| Coordinator decision | Commit error/unknown; Coordinator SQLite | Fresh-writer exact readback only. Never emit a second decision or consume latch speculatively. Unresolved stops all contact. | Global stop is checked in transaction. A previously committed accept is not erased. |
| Cleanup/custody | Descendants, workspace teardown, or capsule retention unknown; supervisor/custodian/store | Record incomplete terminal state; perform only custodian-defined idempotent cleanup/reconciliation. Never infer semantic cancellation. | Restart reconciles process/store. Candidate/capsule may persist and must not be garbage-collected. |

Cancellation ordering is fixed:

```text
Coordinator cancellation decision/intent
→ cancellation effect/delivery
→ request
→ acknowledgement
→ OS signal
→ process exit
→ workspace teardown
→ semantic abandonment/cancellation
```

None of those facts implies the next. [The Worker Execution Boundary](</Users/ds/Repositories/Governed Execution Coordinator/.docs/worker-execution-boundary.md:234>) and [C2A cancellation semantics](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2a-first-slice-semantic-protocol-contract.md:837>) require that separation.

## H. Host, process, credential, and artifact boundary

Frozen minimum:

- `RemoteHostReadinessObservationV1`-equivalent evidence is authored by the host-owning process and includes opaque host binding, Linux/architecture, exact worker artifact/version/digest, supported protocol version, dedicated-user profile, workspace/sandbox profile, process/cancellation limits, transport/host-key profile, credential handoff, capsule-store profile, validation/review tools, timestamps, finite status/reason, and self-digest.
- A separate effect-bound qualification evaluation decides whether that observation satisfies this repository/base/scenario and its ceilings. Readiness is not authority.
- One dedicated unprivileged account; no sudo/root, Docker socket, Coordinator database, writer material, unrelated repositories, SSH agent, inherited credentials, or capsule-store visibility.
- Attempt workspace mode `0700`, `umask 077`, exact clean base, no symlink/hardlink/device escape, one process group, closed unrelated descriptors, explicit wall/CPU/memory/disk/output ceilings.
- One bounded length-prefixed launch frame on stdin and one bounded protocol-only terminal result on stdout; duplicate keys, trailing frames/bytes, wrong built-in types and oversize content fail closed.
- Stderr is private, capped and redacted. It is never Coordinator state or capsule content.
- WorkSpec/plan and credentials travel only through one-shot private channels, never argv/environment/logs.
- Capsule store is outside the mutable workspace and invisible to the author worker. Writes are atomic/content-addressed; same digest with different bytes fails closed.
- The physical capsule contains the canonical manifest and every referenced before/after blob for the three allowed paths. It excludes WorkSpec, plan text, prompts, transcripts, JSONL, stdout/stderr, credentials, endpoints and unrelated files.
- Retain through validation, review, model proposal, durable decision, all ambiguity/cancellation recovery, and later Git handoff. Acceptance alone does not permit garbage collection.

Explicitly deferred:

- exact sandbox/container technology;
- exact numeric framing/resource caps;
- exact credential broker/provider;
- Codex CLI versus App Server final selection;
- capsule encryption/backend/quota/archival and final GC duration;
- exact worker packaging filenames;
- ES public wire representation.

These are later blocking gates, not incidental source choices. The current repository still contains no process or worker runtime. [Current worker nonimplementation and target topology](</Users/ds/Repositories/Governed Execution Coordinator/.docs/worker-execution-boundary.md:32>) remain authoritative.

## I. ES/IM dependency ledger

| Owner | What may be consumed | What remains owner authority / must be deferred |
|---|---|---|
| ES committed HEAD | Boundary contracts, future reliable-submit semantics, runtime-profile ownership, cancellation/result responsibilities, and later dual-route conformance requirements | ES admission, resolved effective plan, public keyed-submit DTO/route/errors, state path/backend/TTL, caller/response-loss recovery, Nomad ambiguity, `run_id`, runtime lifecycle, cancellation, credential handoff and retained results. Coordinator cannot scrape Nomad or create parallel lifecycle truth. |
| ES dirty overlay | Nothing architectural | All 75 local differences are non-authoritative for this plan. |
| IM committed HEAD | Optional evidence of declared remote-Linux topology, copied hashes/provenance, CP/ES connectivity probes and redaction posture | IM cannot prove worker artifact, sandbox/user isolation, exact workspace/base, Codex, WorkSpec custody, authority, capsule store, reviewer independence, latch state or execution permission. Its `accepted` posture cannot be mapped directly to RW0 qualification. |
| Host owner | Fresh owner-neutral host observation | Must define authenticity, freshness and exact capability profile independently of IM. |
| Coordinator | Effect-bound qualification and semantic progression | Must not import IM as a required runtime dependency or absorb ES execution authority. |

ES committed HEAD still has unkeyed async submit with random `run_id`, no caller submit key, no exact public replay, and no public recovery lookup. Its private reliable-submit foundations remain unwired. Sources: `Execution Substrate@b92bd988:.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:65-142` and `Execution Substrate@b92bd988:PLANS.md:106-131`.

Later conformance must run the same worker artifact and C2A fixtures through direct-local and ES, requiring identical canonical semantic bytes, fences, observation/capsule rules, replay/conflict behavior, privacy, ambiguity and cancellation semantics. Only transport wrappers and route-owned correlations may differ. [C2A ES conformance boundary](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2a-first-slice-semantic-protocol-contract.md:1305>).

IM is evidence-only by its own architecture. [IM architecture boundary](</Users/ds/Repositories/Infrastructure Manager/.docs/architecture.md:37>) and [Remote Alpha’s pre-live posture](</Users/ds/Repositories/Infrastructure Manager/.docs/remote-supported-host-alpha.md:302>) do not confer execution authority.

Productive direct-local becomes unusable when the first direct-local `accept` and one-way latch consumption commit atomically. Commit uncertainty blocks all further productive contact. After accepted ES routing/conformance, direct-local remains disabled by default except under a separately governed proof/recovery policy.

## J. Tranche map

1. **RW0-A — Phase-entry contract freeze**

   - Adds: one source-of-truth target contract and direct static contract tests.
   - Decisions required: all target choices already made in this report.
   - Ceiling: docs/tests only; no source, schema, I/O, worker or remote contact.
   - Surfaces: exact nine-file allowlist in Section K.
   - Validation/audit: focused contract tests, full suite, independent contract/security audit.
   - Stops: any need to edit source/schema/C2A vectors/supporting repos.
   - Remains: every runtime capability.

2. **RW0-B — Pure protocol and value contracts**

   - Adds: private no-I/O values for phase-entry, host readiness/qualification, custody receipt, terminal receipt, framing and exact selected-plan binding.
   - Decisions first: framing caps, terminal-result grammar, authority/custody input shapes, Codex capability interface.
   - Ceiling: pure deterministic source/tests only; no SQLite, subprocess, filesystem, network or model.
   - Surfaces: new private modules/tests plus governing docs; no package-root export.
   - Validation/audit: vector/type/privacy/fuzz-like boundary tests and C2A compatibility regression.
   - Stops: any executable permission, public API or alternate identity.
   - Remains: persistence and execution.

3. **RW0-C — Durable phase-entry and observation state**

   - Adds: immutable migration 0004 or accepted successor, private readers/mutations/recovery for contact claim, launch gate, source claims/ingest, capsule safe binding, decision evidence and atomic acceptance latch.
   - Decisions first: exact tables/receipts/graph, app-generation treatment, commit-recovery probes, post-execution proposal reuse.
   - Ceiling: fake supplied observations only; no external I/O.
   - Surfaces: migration/catalog, private row/value/read/write modules, tests and docs.
   - Validation/audit: migration equivalence, recovery/commit uncertainty, replay/conflict, privacy and one-writer audit.
   - Stops: modification of 0001–0003, public API widening or external contact.
   - Remains: worker and transport.

4. **RW0-D — Offline worker/supervisor/capsule proof**

   - Adds: standalone in-repository worker artifact, one-shot supervisor, strict framing, capsule builder/store, validation/review adapters and fake Codex/model executables.
   - Decisions first: Codex seam, sandbox, credentials, exact capsule retention and tool profiles.
   - Ceiling: temporary repositories and fake transports/providers only; no network or live model/host.
   - Surfaces: separate worker subproject, private adapter modules, fixtures/tests and docs.
   - Validation/audit: timeout/cancel/reap, stdout/stderr privacy, capsule collision/recovery, independent-role isolation.
   - Stops: Coordinator DB access by worker, real credentials, daemon/listener or hidden state.
   - Remains: productive remote contact.

5. **RW0-E — One live qualified-host proof**

   - Adds: the one bounded scenario from fresh verification through semantic decision.
   - Decisions first: all prior tranches accepted plus exact host and credentials.
   - Ceiling: one delivery/worker/capsule/validation/review/model proposal/decision; no Git.
   - Surfaces: no opportunistic code changes during the proof.
   - Validation/audit: exact artifact/protocol provenance and independent after-action review.
   - Stops: any ambiguity, stale gate, fallback, second delivery, candidate drift or publication request.
   - Remains: local Git and ES migration.

## K. Recommended first tranche

**Stable ID:** `RW0-A-PHASE-ENTRY-CONTRACT-FREEZE`  
**Title:** Remote worker contact through semantic decision — governing contract freeze

This is the critical-path increment because source choices would otherwise decide authority, custody, retry, process, capsule and decision semantics accidentally.

**Type:** docs and direct contract tests only.

### Exact maximum touched-file allowlist

1. `.docs/rw0-remote-worker-contact-phase-entry.md` — new
2. [.docs/c2b-durable-development-state.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2b-durable-development-state.md>)
3. [.docs/autonomous-software-development-operating-model.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/autonomous-software-development-operating-model.md>)
4. [.docs/worker-execution-boundary.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/worker-execution-boundary.md>)
5. [.docs/authority-boundaries.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/authority-boundaries.md>)
6. [.docs/durable-state-model.md](</Users/ds/Repositories/Governed Execution Coordinator/.docs/durable-state-model.md>)
7. `tests/test_rw0_remote_contact_phase_entry_contract.py` — new
8. [tests/test_remote_worker_pre_execution_planning_contract.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_remote_worker_pre_execution_planning_contract.py>)
9. [tests/test_architecture_contracts.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_architecture_contracts.py>)

This is a maximum allowlist; touching fewer files is acceptable.

### Protected surfaces

- Every path outside that allowlist.
- All `src/**`, SQL, migration/catalog and application-generation files.
- C2A contract text, semantic source, golden values and vectors.
- Existing C2B3D and Section 41 source/runtime/recovery tests.
- Existing Sections 38–42 of the C2B durable document; append a successor section rather than rewriting history.
- `__init__.py`, `state_store.py`, public `WriterSession` and package exports.
- `README.md` and `AGENTS.md`, because implemented capability does not change.
- Both supporting repositories.

### Test treatment

The new direct oracle should assert the current/target distinction, exact bounded scenario, ownership, one-delivery ceiling, no-blind-retry rules, terminal decision behavior, later migration need and protected-surface exclusions.

Do not freeze pytest node IDs, count, ordering, output hashes or timing as compatibility contracts.

Planned focused validation:

```text
python -m pytest -q -W error \
  tests/test_rw0_remote_contact_phase_entry_contract.py

python -m pytest -q -W error \
  tests/test_architecture_contracts.py \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_software_development_progression_boundary.py \
  tests/test_c2a_first_slice_semantic_protocol_contract.py \
  tests/test_c2a_effects_and_recovery.py \
  tests/test_c2a_nonimplementation.py \
  tests/test_remote_worker_pre_execution_planning_contract.py \
  tests/test_runtime_non_authority.py

python -m pytest -q

git diff --check -- \
  .docs/rw0-remote-worker-contact-phase-entry.md \
  .docs/c2b-durable-development-state.md \
  .docs/autonomous-software-development-operating-model.md \
  .docs/worker-execution-boundary.md \
  .docs/authority-boundaries.md \
  .docs/durable-state-model.md \
  tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_remote_worker_pre_execution_planning_contract.py \
  tests/test_architecture_contracts.py
```

The full suite is **pre-audit** against the exact candidate. After independent ACCEPT, only unchanged-byte, diff, provenance, baseline and commit gates run. Any byte change invalidates ACCEPT and requires focused/full validation and a fresh audit.

### Provenance and independent audit

Record:

- opening/final branch, HEAD, tree, upstream, status and worktrees;
- exact allowlist and protected-complement checks;
- unified diff and per-file SHA-256;
- commands, interpreter/tool versions, exits, warnings/skips and UTC times;
- explicit no-network/no-worker/no-model/no-service attestations;
- independent ACCEPT bound to exact candidate bytes and diff.

Audit perspectives:

1. authority/privacy;
2. semantic identity and non-collapse;
3. durable replay/ambiguity/commit recovery;
4. process/capsule boundary;
5. ES/IM non-absorption;
6. provenance and nonimplementation.

### Publication plan

When implementation is separately authorized:

- create `codex/rw0-phase-entry-contract-freeze` from the unchanged required baseline;
- validate and audit the exact pre-commit candidate;
- commit once only after external ACCEPT;
- open a PR to `trunk_dev`;
- use required checks/review and squash without bypass;
- never update `trunk_dev` directly.

This repository contribution workflow is not an RW0 product Git effect.

**Planned tranche completion token:** `COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FROZEN`

Hard stops include baseline drift, any tenth path, source/schema/API change, rewriting Sections 38–42, altered C2A identity/vector, supporting-repository mutation, runtime/network/model contact, or language implying current executable capability.

## L. Open decisions

None blocks RW0-A. Each blocks only a later tranche.

| Open decision | Why evidence cannot resolve it / owner | Blocks | Smallest follow-up |
|---|---|---|---|
| External verifier deployment, trust root, grant encoding and revocation transport | Deliberately external to Coordinator; standing-policy owner plus Coordinator verifier boundary | RW0-B/E | Focused authority protocol/threat-model reconnaissance |
| Custodian implementation and capability issuance | Current contract freezes privacy but not physical custody | RW0-B/D/E | Compare one-use local broker, remote object custodian and anonymous-FD handoff against the frozen rules |
| Codex CLI vs App Server | Repository explicitly leaves the seam open | RW0-D/E | Offline capability proof of exact versions, I/O, cancellation, history and credential behavior |
| Host observation authenticity and sandbox mechanism | IM evidence is insufficient and no owner-neutral producer exists | RW0-B/D/E | One-host capability/provenance reconnaissance with no productive execution |
| Exact framing caps and terminal-result schema | C2A freezes semantic bytes, not the direct-local wrapper | RW0-B | Pure codec contract proposal and adversarial vectors |
| Migration 0004 tables, receipt graph and application-generation treatment | Current schema lacks required facts but does not preselect representation | RW0-C | Schema-only design review against existing migration/catalog invariants |
| Atomic acceptance-latch representation | Trigger is frozen; table/CAS representation is reopened | RW0-C | Durable-state proof covering accept commit uncertainty |
| Capsule backend, encryption, retention duration and GC | Portable identity is frozen; physical custody remains open | RW0-D/E | Store/custody threat model and recovery matrix |
| Validation/reviewer implementation and model adapter protocol | Ownership/outcomes are frozen, mechanism is not | RW0-D/E | Offline role-isolation and normalized-proposal protocol proof |
| ES reliable-submit/resolved-plan/public recovery details | ES-owned and incomplete at committed HEAD | Future ES migration only | Separate ES-owner reconnaissance after current ES priorities permit |

Reconciled report disagreements:

- **Authority authorship — target decision:** although the long-term C1 direction permits narrower Coordinator-derived authority, RW0 preserves externally authored parent and subordinate authorization; Coordinator only verifies and binds.
- **Redelivery — target decision:** C2A’s five-condition redelivery contract remains intact, but this proof permits one actual delivery only. Reject/unknown ends RW0.
- **First-tranche breadth — interpretive:** explorers proposed seven- and nine-file variants. The nine-file set above is the bounded maximum because it includes one dedicated source-of-truth document and the existing pre-execution planning regression oracle.
- **Full-suite timing — process evidence:** repository precedent resolves this as pre-audit, not first run after ACCEPT.
- **Codex seam — genuinely open:** CLI is preferred but remains a later blocking gate rather than an incidental implementation choice.

## Final verdict

RECONNAISSANCE_READY

COORDINATOR_RW0_PHASE_ENTRY_PLAN_FROZEN
