TITLE

Coordinator RW0-A phase-entry contract freeze — squash-merge and merged-tree verification gate

ENGAGEMENT TYPE

Remote merge and local synchronization gate for an independently accepted, audited-byte pull request.

Run this in the existing foreground Codex conversation that created PR #2. You are the sole actor. Do not create or resume subagents.

This turn authorizes only:

- read-only local and remote preflight;
- exactly one squash-merge attempt for PR #2;
- read-only post-merge verification;
- one exact fetch of the base and feature refs;
- switching the clean local worktree to `trunk_dev`;
- one fast-forward-only synchronization of local `trunk_dev`;
- one focused post-merge validation run on the verified merged tree;
- external evidence creation and cleanup.

This turn does not authorize implementation repair, another commit, amend, rebase, cherry-pick, reset, revert, direct trunk push, force, bypass, admin merge, auto-merge, merge-commit or rebase merge, a second merge attempt, branch deletion, review submission, self-approval, thread resolution, PR edits, tag, release, deployment, or supporting-repository mutation.

Stop before merge on any mismatch. After the one merge command, never retry it.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REMOTE

evo-agi/Governed-Execution-Coordinator

PULL REQUEST

#2
https://github.com/evo-agi/Governed-Execution-Coordinator/pull/2

ACCEPTED TARGET

Canonical manifest:

/private/tmp/ge-rw0a-fourth-repair-nlhdj0o8/final-canonical-manifest.json

Require:

- 2,328 bytes;
- SHA-256 `3d880594f269d8bb7f13479df50cf4cd5b24b7dd6e913620517cd8c15c24ccf2`;
- safe external regular operator-owned non-symlink file;
- exact ten-file inventory.

Accepted feature commit:

`7b57ce2f2b28264176572c0bedd18a147bb88baf`

Accepted feature tree:

`8fc05f5626bdbb01808df1698c9c2245ab06f1cb`

Accepted base:

`1a894c5527c610ab40d8e5ae5e530a762c6e60bf`

Feature commit subject:

`docs: freeze RW0-A phase-entry contract`

Feature commit body: empty.

Accepted scope:

- exactly ten changed paths;
- exactly eight modifications and two additions;
- zero deletions, renames, copies, or mode changes;
- Git mode `100644` for all paths;
- every blob byte-identical to the audited manifest.

INDEPENDENT ACCEPTANCE

The fresh independent audit returned:

ACCEPT

COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FREEZE_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

It independently verified no Critical, High, Medium, or Low patch defect; exact provenance and evidence-chain binding; direct 28/28, architecture 30/30, remote-worker 774/774, protected C2B3C 46/46, focused 1,565/1,565, and full suite 4,284/4,284; candidate node-list SHA-256 `7fb16833d1fcf8916f62ad17b0238b87b8cda8bb03432039771290bc713d12e8`; and no source, SQL, migration, schema, package, public API, runtime, or supporting-repository change.

Do not repeat the independent audit.

COMMIT-GATE EVIDENCE

Safely verify without modifying:

/private/tmp/gec-rw0a-commit-gate-txmks4bb/evidence-index.json

Require:

- evidence root mode `0700`, operator-owned, non-symlink;
- index regular mode `0400`;
- 8,304 bytes;
- SHA-256 `0b7f2c77fc114b5367e7bca0ed5374cad1dc81240df0a34f9dd7504ebadaad91`;
- index excludes itself;
- indexed staged comparison, committed comparison, validation, commit, push, PR, and final guard records match their recorded sizes and hashes.

OPENING LOCAL GATE

Require exactly:

- branch `codex/rw0-phase-entry-contract-freeze`;
- HEAD `7b57ce2f2b28264176572c0bedd18a147bb88baf`;
- tree `8fc05f5626bdbb01808df1698c9c2245ab06f1cb`;
- sole parent `1a894c5527c610ab40d8e5ae5e530a762c6e60bf`;
- subject exact, body empty;
- upstream `origin/codex/rw0-phase-entry-contract-freeze`;
- ahead/behind `0/0`;
- local `trunk_dev` and `origin/trunk_dev` both at the accepted base;
- local and remote-tracking feature refs both at the accepted feature commit;
- one worktree;
- worktree/index/untracked/unmerged clean;
- no Git operation, lock, or repository residue.

Recompare all ten feature-commit blobs and Git modes to the immutable audited manifest. Stop on any difference.

Create one new operator-owned non-symlink mode-`0700` merge-gate evidence root beneath `/private/tmp`. Retained files must be mode `0400`.

REMOTE PREFLIGHT — READ ONLY

Immediately before merge require PR #2:

- open, non-draft, not merged;
- mergeable and clean;
- base `trunk_dev` at `1a894c5527c610ab40d8e5ae5e530a762c6e60bf`;
- head `codex/rw0-phase-entry-contract-freeze` at `7b57ce2f2b28264176572c0bedd18a147bb88baf`;
- title `docs: freeze RW0-A phase-entry contract`;
- exact body unchanged;
- one commit and ten files;
- no auto-merge or merge commit;
- no requested reviewers;
- no reviews;
- no inline review threads;
- no issue, review, or discussion comments;
- no unresolved thread;
- no check runs;
- no workflow runs;
- no commit statuses; a synthetic combined `pending` is acceptable only with `total_count=0`.

Require remote refs immediately before merge:

- `trunk_dev` at the accepted base;
- feature ref at the accepted feature commit.

RULESET AND SETTINGS

Require active ruleset ID `18957283`, name `trunk_dev`, applying exactly to `refs/heads/trunk_dev`, with:

- deletion, non-fast-forward, creation, and pull-request rules;
- required approving reviews `0`;
- stale-review dismissal false;
- code-owner review false;
- last-push approval false;
- thread resolution required;
- extra approval for unattributed changes true;
- squash as the only allowed merge method;
- no bypass actors;
- current user bypass `never`.

Require repository settings:

- squash allowed;
- auto-merge disabled;
- delete-branch-on-merge disabled;
- update-branch disabled.

Do not change rules, settings, reviews, threads, comments, statuses, or checks. Stop if any preflight condition differs.

MERGE — EXACTLY ONCE

Execute exactly:

```sh
gh pr merge 2   --repo evo-agi/Governed-Execution-Coordinator   --squash   --match-head-commit 7b57ce2f2b28264176572c0bedd18a147bb88baf   --subject "docs: freeze RW0-A phase-entry contract (#2)"   --body ""
```

Do not add `--admin`, `--auto`, `--delete-branch`, another merge method, bypass, or force.

Record exact argv, return code, stdout, stderr, timing, and pre/post refs. Do not retry.

On nonzero or ambiguous result, perform read-only reconciliation only. Do not issue another merge command.

POST-MERGE REMOTE VERIFICATION

Require:

- PR #2 is merged/closed with `merged=true`;
- auto-merge absent;
- original head OID retained in PR metadata;
- feature branch still exists at the accepted feature commit;
- remote `trunk_dev` advanced exactly once to one new squash commit.

Require the squash commit:

- sole parent `1a894c5527c610ab40d8e5ae5e530a762c6e60bf`;
- tree `8fc05f5626bdbb01808df1698c9c2245ab06f1cb`;
- subject `docs: freeze RW0-A phase-entry contract (#2)`;
- body empty;
- ten paths: eight modified, two added;
- zero deletions, renames, copies, or mode changes;
- mode `100644` for all paths;
- all merged blobs identical to both the feature commit and audited manifest.

Require the feature commit not to be an ancestor of the squash commit. Exact tree/blob identity is controlling.

Record GitHub and local signature states honestly. A local inability to verify a GitHub-generated signature is not a failure if GitHub reports it verified and object/tree identity is exact.

LOCAL SYNCHRONIZATION

Only after remote verification:

1. Fetch exactly the remote `trunk_dev` and feature refs once.
2. Require the fetched OIDs to equal the verified remote OIDs.
3. Switch the clean worktree to local `trunk_dev`.
4. Run exactly:

```sh
git merge --ff-only origin/trunk_dev
```

Do not pull, rebase, merge the feature branch, or delete either feature ref.

Require:

- local `trunk_dev` equals the squash commit;
- upstream `origin/trunk_dev`, ahead/behind `0/0`;
- tree `8fc05f5626bdbb01808df1698c9c2245ab06f1cb`;
- local feature branch and remote-tracking feature ref remain at `7b57ce2f2b28264176572c0bedd18a147bb88baf`;
- one worktree;
- worktree/index/untracked/unmerged clean;
- no operation, lock, or residue.

POST-MERGE FOCUSED VALIDATION — EXACTLY ONCE

Do not rerun the full suite. Its 4,284/4,284 result applies only after exact feature-tree/merged-tree equality is proven.

Run one isolated serial pytest invocation over exactly:

```text
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_c2b3c_author_effect_contract.py
```

Use unset tracing/warning variables, `LC_ALL=C`, `LANG=C`, bytecode suppression, distinct external pycache/TMP/basetemp/JUnit paths, disabled plugin autoload, empty `PYTEST_ADDOPTS`, `PYTHONHASHSEED=0`, `python3 -B -m pytest -p no:cacheprovider -W error`, and serial execution.

Require exactly:

- direct 28;
- architecture 30;
- remote-worker 774;
- C2B3C 46;
- total 878 collected and passed;
- zero failures, errors, skips, xfails, warnings, duplicate/ambiguous/unmapped JUnit cases;
- return code 0;
- empty stderr;
- caller/child umask equal;
- merged tree and repository status unchanged before/after.

Do not rerun this validation. If it fails, stop without reverting the merge or changing history.

FINAL GUARDS

Require:

- PR #2 merged exactly once without bypass;
- remote/local `trunk_dev` equal the squash commit;
- squash tree and every blob equal the accepted target;
- remote/local feature refs intact;
- no direct trunk push;
- no force, admin, bypass, auto-merge, review, thread resolution, or branch deletion;
- clean worktree/index/untracked/unmerged;
- one worktree;
- no Git operation, lock, or repository residue;
- protected C2B and C2B3C blobs exact;
- no source, SQL, migration, schema, package, public API, runtime, or supporting-repository change;
- no tag, release, or deployment.

EVIDENCE CLOSEOUT

Retain under the external merge-gate root:

- opening local identity;
- accepted-manifest and feature-blob comparison;
- PR/ruleset/settings/review/thread/comment/status/check/workflow preflight;
- exact merge command record;
- post-merge PR and remote refs;
- squash commit/tree/parent/subject/body/signature evidence;
- feature-versus-merged and manifest-versus-merged comparisons;
- exact fetch and local ff-only synchronization evidence;
- focused-validation stdout/stderr/JUnit/result;
- final local/remote guards;
- deterministic evidence index with relative path, mode, size, and SHA-256, excluding itself.

Keep root mode `0700`, retained files mode `0400`, and remove only merge-gate-created transient caches and extracted trees. Do not retain credentials or raw authorization/signature payloads.

STOP CONDITIONS

Stop before merge if any opening, target, PR, ref, ruleset, setting, review, thread, comment, status, check, workflow, or mergeability condition differs.

After the one merge command, stop without retry if the command is nonzero/ambiguous, the squash commit differs, refs transition unexpectedly, local synchronization cannot be exact fetch plus ff-only, or focused validation is not exact-green.

Do not reset, revert, force, amend, rebase, delete branches, or issue a second merge attempt.

CLOSEOUT

Return exactly:

COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FREEZE_SQUASH_MERGED_AND_VERIFIED

only if the PR was squash-merged once without bypass, the exact accepted tree/blobs landed on `trunk_dev`, local and remote `trunk_dev` are synchronized, feature refs remain intact, focused validation is exact-green, and final guards are clean.

Report:

1. Opening local identity.
2. Accepted manifest and feature-blob equality.
3. Live PR/ruleset/settings/check/review/thread preflight.
4. Exact merge command and result.
5. Squash commit OID, tree, parent, subject, body, author, committer, timestamps, and signature states.
6. Exact merged path/status/mode/blob comparison.
7. Before/after remote refs.
8. Local fetch/switch/ff-only synchronization.
9. Focused 878-test validation.
10. Final PR state.
11. Final local/remote guards.
12. Evidence-root path and evidence-index size/SHA-256.

Required final statements:

IMPLEMENTATION_REPAIR_NOT_PERFORMED
DIRECT_TRUNK_PUSH_NOT_PERFORMED
BYPASS_NOT_USED
FORCE_PUSH_NOT_PERFORMED
SECOND_COMMIT_NOT_PERFORMED
AMEND_NOT_PERFORMED
REBASE_NOT_PERFORMED
SECOND_MERGE_ATTEMPT_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
REVIEW_NOT_SUBMITTED
THREAD_NOT_RESOLVED
FEATURE_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
