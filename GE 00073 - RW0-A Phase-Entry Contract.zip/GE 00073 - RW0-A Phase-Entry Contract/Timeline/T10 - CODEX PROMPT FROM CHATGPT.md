TITLE

Coordinator RW0-A — repair Section 42 committed-status extension compatibility
and complete the phase-entry contract-freeze validation

ENGAGEMENT TYPE

Bounded parent-only scope expansion in the existing workspace-write
implementation conversation for:

COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1
RW0-A-PHASE-ENTRY-CONTRACT-FREEZE

Do not create or resume subagents. You are the sole repository writer.

The preceding repair correctly stopped because the one authorized full-suite
run exposed one existing collateral contract test outside the one-file repair
allowlist. The RW0-A direct oracle repair itself passed, the focused regression
passed, and node identity remained exact.

This turn explicitly authorizes:

- verification and immutable capture of the exact stopped ten-minus-one-path
  candidate;
- mutation of exactly one newly authorized existing test file:
  `tests/test_c2b3c_author_effect_contract.py`;
- repair of the stale Section 42 end-of-file assumption;
- a fresh final validation sequence against the resulting bytes;
- final ten-path working-tree provenance.

This turn does not authorize:

- any documentation change;
- any change to the three already modified/untracked RW0-A tests;
- any source, SQL, migration, schema, catalog, application-generation, package,
  public protocol, StateStore, WriterSession, fixture, script, config, runtime,
  worker, provider, Bridge, ES, or IM path;
- staging, commit, push, PR creation, merge, tag, release, or deployment;
- fetch, pull, remote contact, network access, model/provider invocation, Codex
  invocation, process/worker launch, SSH, live service, or live database
  contact;
- reset, clean, revert, branch switch, discard, or history rewrite.

The accepted RW0-A documentation and its later Section 42 H3 extension are
protected. Do not relocate, rewrite, shorten, or duplicate them to satisfy the
stale test.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED STOPPED STATE

Require exactly before mutation:

- Physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- HEAD tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- HEAD subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1
- Dirty paths:
  exactly 9
- Tracked modifications:
  exactly 7
- Untracked paths:
  exactly 2
- Staged/unmerged:
  0/0
- Every candidate path:
  regular mode 0644
- No deletion, rename, copy, symlink, mode change, Git operation, or Git lock
- Repository residue:
  empty
- `git diff --check HEAD --`:
  clean.

Require the exact stopped nine-path set:

.docs/rw0-remote-worker-contact-phase-entry.md
.docs/c2b-durable-development-state.md
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_architecture_contracts.py

Require that this additional existing file remains clean against HEAD before
mutation:

tests/test_c2b3c_author_effect_contract.py

Opening clean-file pin:

- size:
  414,292 bytes
- SHA-256:
  b38b9bf82b0be4f97970ec0af1e0ba12a0d8944c015e893f70c4ce86d96888e0
- working-tree file type:
  regular
- working-tree mode:
  0600
- owner:
  current operator
- execute bits:
  none
- Git index mode:
  100644
- Git status against HEAD:
  clean

The working-tree `0600` mode is an accepted restrictive local metadata overlay.
Git records this tracked non-executable path as `100644`; the content, blob
identity, and Git cleanliness are exact. Do not widen the filesystem permission
to `0644`.

Stop without mutation on any other mismatch. Do not fetch or absorb drift.

PRESERVED FAILURE EVIDENCE

Safely inspect, but do not modify:

/private/tmp/ge-coordinator-rw0a-repair.UDYgzx

Require:

- every path component lstat-safe and non-symlink;
- root operator-owned, non-symlink, mode 0700;
- the retained full-suite command ran once against the stopped post-oracle-
  repair candidate;
- collection:
  4,284;
- passed:
  4,283;
- failed:
  exactly 1;
- zero errors, skips, xfails, or warnings;
- the sole failure is:

  tests/test_c2b3c_author_effect_contract.py::
  test_current_status_regions_are_reconciled_without_historical_rewrite

- the failure reaches `_section_42_committed_status()` and the assertion
  corresponding to line 4269 of the clean baseline test;
- the rejected document already contains the later bounded RW0-A H3
  cross-reference after the exact committed-status block;
- no repository mutation occurred after the full-suite failure.

Treat this retained full-suite failure as the causal predecessor-red evidence.
Do not rerun the stopped bytes merely to manufacture another red result.

If the retained evidence root is missing, unsafe, contradictory, or does not
identify this sole failure, stop and return:

COORDINATOR_RW0_A_SECTION42_COMPATIBILITY_REPAIR_EVIDENCE_MISMATCH

MODE CORRECTION TO THE PRECEDING DIRECTION

The earlier continuation over-constrained one clean tracked path by requiring
working-tree mode `0644`.

For this engagement:

- Git object/index mode `100644` is the repository object-mode contract.
- The observed working-tree mode `0600` is a stricter local permission overlay.
- The provenance recipe must record that exact `0600` mode once the file becomes
  dirty.
- The independent-audit target must later expect `0600` for this path.
- A later staged/committed-blob gate must require index/commit mode `100644`;
  it must not mistake the local `0600` permission for a Git mode change.
- Do not broaden permissions merely to make the working tree resemble a fresh
  clone.

This correction changes no content scope, test scope, validation requirement,
or authority boundary.

OPENING REPAIR PROVENANCE

Create one new external, operator-owned, non-symlink, mode-0700 repair evidence
root under `/private/tmp`.

Preserve safe metadata and hashes for the predecessor full-suite failure in the
new evidence root without altering the original evidence.

Use the exact unchanged provenance recipe below twice before repository
mutation.

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

Recipe requirements:

- source size:
  3,945 bytes
- source SHA-256:
  db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Safely classify the fixed output path:

/tmp/ge-coordinator-b3a-audit-manifest-v1.json

If it exists, require a regular non-symlink operator-owned file and preserve its
exact pre-run bytes and metadata externally. Do not delete unrelated evidence.

Require both opening recipe runs to:

- return 0;
- have empty stderr;
- produce byte-identical complete stdout;
- produce byte-identical canonical manifests;
- identify the exact branch, HEAD, upstream, and nine-path set above;
- classify exactly seven entries as `tracked_modified`;
- classify exactly two entries as `untracked`;
- classify every entry as regular mode 0644;
- contain no deletion, rename, symlink, or unsupported type.

Freeze one immutable mode-0400 copy of the opening nine-path canonical manifest
as the repair-opening target. Report its exact size and SHA-256.

MAXIMUM AUTHORIZED REPOSITORY MUTATION

Exactly one newly authorized path:

tests/test_c2b3c_author_effect_contract.py

This path must become a tracked modification with:

- regular file type;
- exact working-tree mode `0600`;
- current-operator ownership;
- no execute bits;
- Git index mode remaining `100644`;
- no Git-recorded mode change.

Preserve the restrictive `0600` mode. Do not chmod it to `0644`. Prefer an
in-place edit that preserves metadata. If the authorized editing mechanism
changes the working-tree mode, the only permission correction authorized in
this turn is restoring this exact path to `0600` before validation and
provenance. Record that correction explicitly; do not alter any other path
mode.

The stopped nine candidate entries must remain byte-identical to the immutable
repair-opening target, including:

- all six documentation files;
- `tests/test_rw0_remote_contact_phase_entry_contract.py`;
- `tests/test_remote_worker_pre_execution_planning_contract.py`;
- `tests/test_architecture_contracts.py`.

No eleventh dirty path is permitted.

Expected final topology:

- exactly 10 dirty paths;
- exactly 8 tracked modifications;
- exactly 2 untracked files;
- 0 staged;
- 0 unmerged.

DEFECT CLASSIFICATION

This is a compatibility collateral test defect.

The existing C2B3C helper correctly owns and protects the exact committed
Section 42 status block beginning at the historical opening-prefix boundary. It
incorrectly assumes that the committed-status block is also the end of the
entire owner document:

`assert suffix == EXPECTED_SECTION_42_COMMITTED_STATUS`

RW0-A validly appends a later bounded H3 strategic-target cross-reference under
the still-final H2 Section 42.

The C2B3C status test must continue to own the exact committed-status block. It
must not own all future subordinate Section 42 extensions and must not duplicate
the detailed RW0-A contract.

REPAIR REQUIREMENTS

Modify only the existing C2B3C test helper and existing test body as necessary.

1. EXACT COMMITTED BLOCK AT THE FROZEN OFFSET

   Preserve:

   - `EXPECTED_OWNER_OPENING_UTF8_LENGTH = 1_881_520`;
   - `EXPECTED_OWNER_OPENING_SHA256`;
   - `EXPECTED_SECTION_42_COMMITTED_STATUS`;
   - exact committed-status marker constants;
   - every existing commit, Git/report authority, status-only supersession, and
     non-capability assertion.

   Require the exact committed-status bytes at:

   `source[EXPECTED_OWNER_OPENING_UTF8_LENGTH:
           EXPECTED_OWNER_OPENING_UTF8_LENGTH + len(expected)]`

   Do not require the complete remaining file suffix to equal that block.

2. OWN ONLY THE COMMITTED-STATUS REGION

   `_section_42_committed_status()` must normalize and return only the exact
   committed-status block, not later subordinate extensions.

   It must continue to reject:

   - a byte mutation inside the committed-status block;
   - a missing or swapped implementation commit;
   - report/audit ownership of Git truth;
   - broadened supersession;
   - a current model/provider/runtime/public-surface capability claim;
   - duplicate committed-status begin/end markers anywhere in the document;
   - relocation of the committed block away from the exact frozen offset;
   - an H2 Section 43 after Section 42.

3. ALLOW GOVERNED LATER SUBORDINATE EXTENSIONS

   The helper must accept later visible H3-or-deeper Section 42 extensions after
   the exact committed-status end.

   It must not copy, hash-pin, semantically restate, or become a second owner of
   the detailed RW0-A block.

   Detailed validation of:

   - the RW0-A H3;
   - its markers;
   - target/current distinction;
   - authority model;
   - deferred seams;
   - append-only placement;

   remains owned by:

   - `tests/test_rw0_remote_contact_phase_entry_contract.py`; and
   - `tests/test_remote_worker_pre_execution_planning_contract.py`.

4. STRUCTURAL CEILING

   The C2B3C helper may assert that no visible H1 or H2 successor such as
   Section 43 appears after the committed-status block.

   Do not introduce a competing complete Section 42 heading inventory. Use the
   existing owner tests for detailed allowed-subheading structure.

5. NO DOCUMENTATION CHANGE

   Do not edit the owner document or any RW0-A document/test to accommodate the
   stale EOF assumption.

CAUSAL CONTROLS IN THE EXISTING NODE

Strengthen only the existing node:

tests/test_c2b3c_author_effect_contract.py::
test_current_status_regions_are_reconciled_without_historical_rewrite

Do not add or parameterize a test node.

Require at least:

A. Positive extension compatibility

   Construct:

   - the exact protected opening prefix;
   - the exact committed-status block;
   - a later visible H3 subordinate extension with content.

   `_section_42_committed_status()` must accept and return the same normalized
   committed-status block as the live document.

B. Mutation inside committed block

   Mutate one required commit/status/authority phrase inside the exact committed
   block while keeping a valid later extension. Reject.

C. Relocation

   Put a later H3 extension before the committed-status block so that the block
   no longer begins at the frozen offset. Reject.

D. Duplicate committed block

   Retain one exact block at the frozen offset and append a second copy after a
   later H3 extension. Reject through marker uniqueness.

E. H2 successor

   Append `## 43. Invalid successor` after the exact block. Reject.

F. Existing owner mutants

   Retain the existing commit-swap, report-authority, broadened-supersession,
   capability-overclaim, and duplicate-block controls.

MUTATION-SENSITIVITY CONTROL

Construct or retain one clearly named broken EOF checker representing the
predecessor behavior:

- it requires the entire suffix to equal the committed-status block;
- it rejects the valid positive-extension candidate;
- the repaired region-scoped helper accepts the same bytes.

This is a compatibility control only. It must not be used as the authoritative
positive oracle.

TEST-NODE BOUNDARY

Do not add, remove, rename, skip, xfail, decorate, parameterize, collapse, or
weaken any test.

Before mutation, collect exactly once under the isolated posture:

1. Complete repository:
   - exactly 4,284 node IDs;
   - retain the ordered list.

2. Direct RW0-A test:
   - exactly 28 node IDs;
   - retain the ordered list.

3. C2B3C test file:
   - exactly 46 node IDs;
   - retain the ordered list.

4. The other two existing RW0-A modified test files:
   - retain their ordered lists and counts.

After final bytes freeze, require literal byte-for-byte equality with every
opening ordered node list.

VALIDATION ISOLATION

Use the new external repair evidence root.

For every pytest child:

- save actual caller umask;
- create evidence under secure posture;
- restore caller umask before launch;
- record child-observed umask and require numerical equality;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`
  - `LC_ALL=C`
  - `LANG=C`
  - `PYTHONDONTWRITEBYTECODE=1`
  - distinct external `PYTHONPYCACHEPREFIX`
  - distinct external `TMPDIR`
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
  - `PYTEST_ADDOPTS=''`
  - `PYTHONHASHSEED=0`
  - `python3 -B -m pytest`
  - `-p no:cacheprovider`
  - `-W error`
  - distinct external `--basetemp`
  - external `--junitxml`
  - serial execution.

Retain exact argv, effective environment, caller/child umask, return code,
elapsed time, stdout/stderr/JUnit sizes and SHA-256, parsed counts, warnings,
parse errors, unmapped cases, and before/after repository identity.

TARGETED GREEN GATE — EXACTLY ONCE

After repairing only the authorized C2B3C test, run exactly:

tests/test_c2b3c_author_effect_contract.py::
test_current_status_regions_are_reconciled_without_historical_rewrite

Require:

- 1 collected;
- 1 passed;
- zero failure, error, skip, xfail, or warning;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository identity unchanged.

This is a fresh post-repair run. Do not run a second attempt if terminal
evidence is lost.

COMPLETE C2B3C REGRESSION

Run:

tests/test_c2b3c_author_effect_contract.py

Require exactly:

- 46 collected;
- 46 passed;
- zero failure, error, skip, xfail, warning, stderr, parse error, or unmapped
  case.

DIRECT RW0-A ORACLE REGRESSION

Run:

tests/test_rw0_remote_contact_phase_entry_contract.py

Require exactly:

- 28 collected;
- 28 passed;
- zero failure, error, skip, xfail, warning, stderr, parse error, or unmapped
  case.

COMPLETE RW0-A FOCUSED REGRESSION

Run exactly the same complete focused set as the stopped implementation:

tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_software_development_progression_boundary.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_worker_execution_semantic_boundaries.py

Require exactly:

- 1,565 collected;
- 1,565 passed;
- zero failure, error, skip, xfail, warning, stderr, parse error, or unmapped
  case.

If any named file is absent, stop rather than substituting.

FINAL NODE COLLECTION

After targeted and focused validation plus cleanup:

- collect the complete repository exactly once;
- require exactly 4,284 nodes;
- require literal equality with the stopped-candidate opening list;
- require the direct test remains exactly 28 nodes;
- require C2B3C remains exactly 46 nodes;
- require the other two modified test-file lists remain exact;
- require no added, removed, renamed, skipped, xfailed, collapsed, or
  re-parameterized node.

FULL SUITE — EXACTLY ONCE ON FINAL BYTES

Only after all prior gates and artifact cleanup pass, run:

python3 -B -m pytest -p no:cacheprovider -W error \
  --basetemp=<external> \
  --junitxml=<external> \
  .

exactly once on the repaired final bytes.

Require exactly:

- 4,284 collected;
- 4,284 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository bytes, topology, and node identity unchanged before/after.

Do not run a second full-suite attempt. If terminal evidence is lost or the
suite is not exact-green, stop without further mutation.

FINAL CONTRACT AND PATH GUARDS

Require:

- exactly 10 dirty paths;
- exactly 8 tracked modifications;
- exactly 2 untracked files;
- zero staged/unmerged paths;
- the original nine candidate paths remain regular mode `0644`;
- `tests/test_c2b3c_author_effect_contract.py` is regular mode `0600`;
- every candidate path has no execute bits;
- Git records every tracked candidate path as mode `100644`;
- no Git-recorded mode change exists;
- exactly one newly dirty entry relative to the immutable nine-path
  repair-opening target:
  `tests/test_c2b3c_author_effect_contract.py`;
- all nine stopped-candidate entries byte-identical;
- all six documentation files byte-identical;
- all three earlier RW0-A test entries byte-identical;
- the append-only C2B opening prefix remains exact;
- final H2 remains Section 42;
- the RW0-A H3 remains visible, unique, unfenced, and subordinate;
- four RW0 cross-reference bodies remain normalized-identical;
- the exact committed-status block remains at the frozen offset and unique;
- the corrected authority model, target/current distinction, deferred seams,
  fixture non-authority, one-delivery ceiling, cancellation ordering, terminal
  outcome inventories, and ES/IM non-absorption remain unchanged;
- no current source/schema/migration/public/runtime capability exists or is
  claimed;
- `git diff --check` clean;
- no repository cache, bytecode, pytest cache, database, journal, WAL/SHM,
  build output, archive, generated manifest, or OS metadata;
- no Git operation or lock;
- no remote contact.

FINAL PROVENANCE

After final validation and cleanup, run the exact unchanged provenance recipe
twice again.

Require:

- both return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- exactly 10 entries;
- exactly 8 `tracked_modified`;
- exactly 2 `untracked`;
- the original nine entries remain regular mode `0644`;
- `tests/test_c2b3c_author_effect_contract.py` is regular mode `0600`;
- all entries have no execute bits;
- no deletion, rename, symlink, Git-recorded mode change, or unsupported type.

Compare the final manifest with the immutable nine-path repair-opening target
and prove:

- exactly one added dirty entry:
  `tests/test_c2b3c_author_effect_contract.py`;
- the added entry is `tracked_modified`, regular, working-tree mode `0600`,
  with Git index mode `100644`;
- the nine shared entries remain byte-identical;
- no shared path changes kind, mode, size, or SHA-256;
- no Git-recorded mode change exists;
- final path classifications and topology are exact.

Report:

- repair-opening manifest path, size, and SHA-256;
- final manifest path, size, and SHA-256;
- exact added-entry size/hash/mode;
- recipe source size/hash;
- complete-output size/hash;
- tracked textual-diff hash;
- retained predecessor-full-suite failure evidence hashes;
- targeted, C2B3C, direct, focused, collection, and final full-suite record
  paths/hashes;
- opening/final node-list hashes and equality;
- final path, historical, residue, and no-effect guards.

Do not stage. The final ten-path working-tree manifest is the future
independent-audit target.

STOP CONDITIONS

Stop without further mutation if:

- opening identity, path set, clean-file pin, evidence, or node count differs;
- documentation or another test/source path appears necessary;
- the committed-status block cannot be owned independently of later subordinate
  extensions;
- repairing the stale EOF assumption requires weakening exact block, marker,
  commit, authority, supersession, or capability assertions;
- any existing test node must change;
- targeted, file, direct, focused, collection, or full-suite validation is not
  exact-green;
- another path changes;
- the authorized file cannot remain regular mode `0600` with Git index mode
  `100644` and no execute bits;
- any permission widening to group or other users would be required;
- final provenance is unstable;
- remote contact, staging, publication, worker/model/process activity, or
  supporting-repository mutation would be required.

On stop, preserve exact state and evidence. Do not reset, clean, revert, switch
branches, stage, or discard work.

CLOSEOUT

Return exactly:

COORDINATOR_RW0_T1_SECTION42_STATUS_EXTENSION_COMPATIBILITY_REPAIRED_READY_FOR_INDEPENDENT_AUDIT

only if:

- the C2B3C committed-status block remains exact, unique, and causally
  protected;
- later subordinate Section 42 extensions are accepted without becoming owned
  by the C2B3C test;
- the stale EOF behavior is reproduced by the broken control and rejected as
  authoritative behavior;
- all stopped-candidate bytes remain exact;
- targeted, focused, node, and full-suite validation are exact-green;
- final ten-path provenance is stable;
- only the newly authorized C2B3C test became additionally dirty;
- no docs, source, schema, runtime, remote, staging, or publication effect
  occurred.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
