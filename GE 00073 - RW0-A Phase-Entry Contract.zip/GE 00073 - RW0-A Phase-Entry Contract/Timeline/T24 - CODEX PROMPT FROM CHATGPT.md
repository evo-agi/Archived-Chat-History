TITLE

Coordinator RW0-A — reconcile the existing C2B cancel decision with a distinct
RW0 terminal-outcome fact and complete the exact in-range Markdown causality
proof after the third independent audit

ENGAGEMENT TYPE

Bounded parent-only repair in the existing workspace-write implementation
conversation for:

COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1
RW0-A-PHASE-ENTRY-CONTRACT-FREEZE

Do not create or resume subagents. You are the sole repository writer.

The third fresh independent audit returned BLOCK against the exact ten-path
candidate.

It accepted:

- exact opening and closing provenance;
- the exact eight-entry second-audit repair delta;
- current nonimplementation and fail-closed runtime boundaries;
- immutable per-fence authorization-basis binding and common-family
  verification;
- one existing author lineage and invocation;
- post-teardown source reconciliation;
- live owner-range marker coverage;
- visible leading/trailing contradiction rejection;
- the actual visible-region oracle’s rejection of exact in-range hidden-body
  counterexamples;
- supervisor/worker fact ownership;
- direct-local versus ES route ownership;
- protected C2B and C2B3C bytes;
- source/schema/migration/public-surface non-change;
- all independently executed targeted and focused validation.

It found exactly two repairable defects:

1. RW0-A-DECISION-C2B-CONFLICT — High

   The target currently requires an early cancellation-control decision before
   the cancellation effect and another final `cancel` decision after teardown
   and reconciliation.

   The existing C2B contract already defines `cancel` as the immutable
   pre-effect Coordinator decision, and the cancel effect must cite that exact
   cancel decision. The target therefore cannot use a second cancel decision as
   the post-effect terminal closure.

2. RW0-A-MD-02-CAUSALITY — Medium

   The checked-in empty-visible-block mutants place the hidden real body before
   the visible owner heading. They do not prove the required case in which the
   visible owner heading, hidden real body, and visible empty BEGIN/END block are
   all inside the same live owner range.

This turn authorizes correction of those two findings only, followed by fresh
validation and provenance.

This turn does not authorize:

- revision of the C2B decision-kind grammar;
- mutation of `.docs/c2b-durable-development-state.md`;
- mutation of `tests/test_c2b3c_author_effect_contract.py`;
- any source/runtime/schema/migration/catalog/application-generation/package/
  public-protocol/StateStore/WriterSession change;
- implementation of a terminal-outcome row, verifier, custody, transport,
  process launch, worker, Codex, capsule storage, validation/review/model
  execution, semantic-decision runtime, acceptance latch, Git, ES routing,
  service, queue, scheduler, or autonomous loop;
- mutation of Execution Substrate, Infrastructure Manager, or any other
  repository;
- staging, commit, push, PR creation, merge, tag, release, or deployment;
- fetch, pull, remote contact, network access, model/provider invocation, Codex
  invocation, process/worker launch, SSH, live service, or live database
  contact;
- reset, clean, revert, branch switch, discard, or history rewrite.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OPENING BASELINE AND TARGET GATE

Require exactly before mutation:

- Physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- HEAD tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- HEAD subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1
- Dirty paths:
  exactly 10
- Tracked modifications:
  exactly 8
- Untracked paths:
  exactly 2
- Staged/unmerged:
  0/0
- No deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  or Git lock
- Repository residue:
  empty
- `git diff --check HEAD --`:
  clean.

Require the exact ten-path set:

.docs/rw0-remote-worker-contact-phase-entry.md
.docs/c2b-durable-development-state.md
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_architecture_contracts.py
tests/test_c2b3c_author_effect_contract.py

Require mode posture:

- these nine paths are regular working-tree mode `0644`:

  .docs/rw0-remote-worker-contact-phase-entry.md
  .docs/c2b-durable-development-state.md
  .docs/autonomous-software-development-operating-model.md
  .docs/worker-execution-boundary.md
  .docs/authority-boundaries.md
  .docs/durable-state-model.md
  tests/test_rw0_remote_contact_phase_entry_contract.py
  tests/test_remote_worker_pre_execution_planning_contract.py
  tests/test_architecture_contracts.py

- this path is regular working-tree mode `0600`, current-operator-owned, with no
  execute bits:

  tests/test_c2b3c_author_effect_contract.py

- Git index mode for every tracked candidate path is `100644`;
- no Git-recorded mode change exists.

Do not chmod any path. Do not widen the local `0600` permission.

AUTHORITATIVE OPENING TARGET

Use exactly:

/private/tmp/ge-rw0a-second-repair-m22z10x8/final_provenance/run-2-manifest.json

Require:

- every path component lstat-safe and non-symlink;
- evidence root operator-owned, non-symlink, mode 0700;
- manifest regular and safely readable;
- size:
  2,328 bytes;
- SHA-256:
  cdfc576d53de6d116e5a46131319927df2fd56f0774ac6815eb0e0dda61323c5.

Copy the safely verified bytes into one new repair-created external,
operator-owned, non-symlink, mode-0700 evidence root as an immutable mode-0400
opening target.

Parse and require:

- recipe_id:
  governed-execution.audit-patch-manifest.v1
- branch:
  codex/rw0-phase-entry-contract-freeze
- head:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- textual_diff_sha256:
  f14dc7e28416c3afb80f5967d42e37873830731dc79afc07c3c255c3e0013d53
- exactly ten entries;
- exactly eight `tracked_modified`;
- exactly two `untracked`;
- expected working-tree modes above;
- no deletion, missing path, symlink, or unsupported type.

Run the exact provenance recipe below twice before editing and require exact
byte equality with the immutable target.

Expected opening provenance:

- Recipe source:
  3,945 bytes
- Recipe SHA-256:
  db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
- Complete stdout:
  2,561 bytes
- Complete-output SHA-256:
  7312ad6f01ba1105b01e458b2438888d6076f92895c1cdf78a84542f9a2feb54
- Stderr:
  0 bytes
- Tracked textual-diff SHA-256:
  f14dc7e28416c3afb80f5967d42e37873830731dc79afc07c3c255c3e0013d53
- Canonical manifest:
  2,328 bytes
- Canonical-manifest SHA-256:
  cdfc576d53de6d116e5a46131319927df2fd56f0774ac6815eb0e0dda61323c5
- File count:
  10

Stop without mutation and return:

COORDINATOR_RW0_A_THIRD_AUDIT_REPAIR_PROVENANCE_MISMATCH

on any mismatch. Do not reconstruct the target from the live tree, report, or
aggregate hashes.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

PRESERVED THIRD-AUDIT EVIDENCE

Safely inspect, but do not modify:

/private/tmp/ge-rw0a-independent-reaudit-hop9mho3

Use it only as predecessor evidence. Do not grant correctness credit merely
because records exist.

When safely available, inspect:

- the independent finding report;
- the independent mutant matrix;
- closing guards;
- direct, architecture, remote-worker, C2B3C, focused, and collection records;
- opening and closing provenance records.

Require retained evidence to be consistent with the supplied audit report:

- exact candidate provenance matched;
- the High decision/C2B conflict was found;
- the checked-in empty-visible-block mutants placed the hidden real body before
  the visible owner heading;
- the independent auditor’s exact in-range mutant was accepted by the broken
  raw checker and rejected by the final visible-region oracle;
- independently executed direct, architecture, remote-worker, C2B3C, focused,
  and collection gates were green;
- the full suite was withheld because inspection was non-green.

If the evidence root is unavailable or incomplete, continue from the supplied
audit report and current source inspection, but disclose the limitation. Do not
invent hashes or missing probe results.

MAXIMUM AUTHORIZED MUTATION

Documentation:

1. .docs/rw0-remote-worker-contact-phase-entry.md
2. .docs/autonomous-software-development-operating-model.md
3. .docs/worker-execution-boundary.md
4. .docs/authority-boundaries.md
5. .docs/durable-state-model.md

Tests:

6. tests/test_rw0_remote_contact_phase_entry_contract.py
7. tests/test_architecture_contracts.py
8. tests/test_remote_worker_pre_execution_planning_contract.py

No other path may change.

Protected exact candidate bytes:

- .docs/c2b-durable-development-state.md
- tests/test_c2b3c_author_effect_contract.py

The protected C2B document must retain exact size/hash/mode:

- 1,884,626 bytes
- SHA-256:
  5fd66a1266e63f8f026a27de7d84f42029813acdadc6b3ecb1978c3ff9ce9b1e
- mode:
  0644

The protected C2B3C test must retain exact size/hash/mode:

- 416,182 bytes
- SHA-256:
  935ca6fe7b18d39055d5cdc2c911302e7c0726304f3699472f3994a32f7b4778
- working-tree mode:
  0600
- Git index mode:
  100644

The final path set and topology must remain exactly ten paths, eight tracked
modifications, two untracked files, zero staged, and zero unmerged.

If an allowlisted document or test does not require a byte change, preserve it
byte-identically and report that fact.

PARENT CONTRACT DECISION — DO NOT REVISE C2B

The existing C2B decision grammar remains authoritative and unchanged.

A. EXISTING C2B CANCEL DECISION

Freeze and test:

1. `cancel` is the existing immutable C2B Coordinator decision kind.

2. The C2B cancel decision is committed before the cancellation effect.

3. The cancellation effect’s `basis_decision_ref` cites that exact pre-effect
   cancel decision.

4. The cancel decision preassigns the cancellation effect, cancellation fence,
   first cancellation delivery, and exact target as the existing C2B contract
   requires.

5. The cancel decision is not:
   - cancellation request;
   - acknowledgement;
   - signal;
   - process exit;
   - workspace teardown;
   - source reconciliation;
   - semantic abandonment;
   - semantic cancellation;
   - or RW0 terminal closure.

6. RW0 creates no second cancel decision after the effect.

7. RW0-A does not add, rename, or reinterpret a C2B decision kind.

B. DISTINCT FUTURE RW0 TERMINAL-OUTCOME FACT

Freeze a separate future semantic contract without selecting its storage
schema, public type, table, migration, or wire representation.

1. Every RW0 run has exactly one future Coordinator-owned durable
   `RW0 terminal outcome` fact.

2. The terminal-outcome fact is not a `development_decision`, not an effect
   basis, not executable permission, not a source observation, and not a report
   or projection.

3. It does not alter the closed C2B decision-kind inventory, create a program
   version by itself, or authorize another effect.

4. It is authored only by the future guarded Coordinator writer after all
   outcome-specific evidence and current-head relations are complete.

5. Its exact finite value domain remains:

   `accept`, `repair`, `replan`, `terminal_reject`, `block`, `cancel`

6. It binds the exact RW0 phase-entry identity and current lineage, including
   the existing semantic attempt, author effect/command/candidate, current
   Section 41 selection head, applicable decision ref(s), effect/delivery/source
   evidence, capsule/validation/review/model evidence when reached,
   global-stop/current-head state, and acceptance-latch postimage when
   applicable.

7. It is the authoritative durable fact that RW0 itself is terminal. It does not
   become external execution authority or hidden route truth.

8. No successor launch, Git effect, or publication follows any terminal-outcome
   value inside RW0.

9. Exact identity, digest, row, receipt, graph, table, migration, application
   generation, and public API representation remain deferred to the later
   durable-schema tranche.

C. NON-CANCEL BRANCH RELATION

For terminal values:

`accept`, `repair`, `replan`, `terminal_reject`, `block`

require:

1. exactly one corresponding immutable C2B `development_decision` of the same
   kind;

2. the terminal-outcome fact binds that exact decision ref/digest and may not
   contradict its kind or lineage;

3. the final outcome is not established before that decision commits;

4. only the committed `accept` decision plus its matching terminal-outcome fact
   may consume/bind the productive-direct-local acceptance-latch postimage;

5. no additional cancellation-control decision exists on a non-cancel branch.

D. ACTIVE-CANCEL BRANCH RELATION

Require:

1. exactly one immutable pre-effect C2B `cancel` decision;

2. the cancel effect cites that exact decision as its basis;

3. request, acknowledgement, signal, process exit, workspace teardown, and
   post-teardown source-native reconciliation remain distinct facts;

4. after reconciliation:
   - terminal-outcome value `cancel` is permitted only when every required
     process, workspace, source, capsule/custody, and delivery relation is
     complete and non-ambiguous;
   - terminal-outcome value `block` is required when reconciliation is
     incomplete, contradictory, stale, or ambiguous;

5. neither terminal-outcome value creates a second C2B decision:
   - terminal `cancel` is not another cancel decision;
   - terminal `block` on the active-cancel branch is not a
     `development_decision(kind=block)`;

6. the terminal-outcome fact binds the exact pre-effect cancel decision and the
   exact reconciliation evidence;

7. the pre-effect cancel decision does not itself prove terminal cancel or
   terminal block;

8. the terminal-outcome fact cannot basis the cancellation effect because it is
   established only after the effect and reconciliation;

9. no other Coordinator progression decision is created in the active-cancel
   branch;

10. no successor, Git, or publication follows.

E. FAILURE AND RECOVERY

Require:

- commit uncertainty for the pre-effect cancel decision is resolved before
  cancellation effect establishment;
- cancellation-effect and delivery ambiguity remain source/reconciliation
  concerns;
- terminal-outcome commit uncertainty is resolved through exact guarded-writer
  readback;
- an unresolved terminal-outcome commit permits no new effect or successor;
- replay/recovery never fabricates a second cancel or block decision;
- reports, model proposals, source observations, and route receipts cannot
  establish the terminal outcome by themselves.

F. TERMINOLOGY CORRECTION

Remove or replace every target statement equivalent to:

- “final cancel decision after teardown”;
- “one final semantic outcome decision” when it treats all six outcome values
  as C2B decisions;
- “early cancellation-control decision” when it obscures that the early fact is
  exactly the existing C2B `cancel` decision;
- “terminal block decision” on the active-cancel branch.

Use exact distinctions:

- pre-effect C2B cancel decision;
- post-effect source-native reconciliation;
- separate future RW0 terminal-outcome fact;
- final terminal-outcome value `cancel` or `block`.

DOCUMENT REPAIR REQUIREMENTS

SOLE OWNER DOCUMENT

Update the affected sections in:

.docs/rw0-remote-worker-contact-phase-entry.md

At minimum reconcile:

- status/nonimplementation;
- identity and fact ownership matrix;
- target fact timeline;
- normal/non-cancel branch;
- active-cancel branch;
- failure/recovery matrix;
- terminal-outcome domain;
- capsule/validation/review/model/decision section;
- tranche/open-decision section.

State explicitly that the final-outcome semantic role is frozen now but its
physical durable representation remains a later schema decision.

Preserve:

- sole detailed ownership;
- accepted-target/nonimplementation classification;
- exact K8/L34 lineage;
- immutable authorization-basis/subordinate-record relation;
- raw WorkSpec privacy;
- one qualified remote Linux host/no fallback/no third adapter;
- one author lineage and invocation;
- author versus later current-effect delivery distinction;
- supervisor/worker fact ownership;
- direct-local/ES/IM split;
- no Git/publication;
- every deferred implementation seam;
- no selected table, migration, application generation, public class, wire
  format, or backend.

FOUR CROSS-REFERENCES

Inspect the bounded blocks in exactly:

.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md

If the compact body contains ambiguous “one final decision” or early
cancellation-control wording, update all four normalized bodies identically.

Their compact meaning must remain:

- sole detailed owner path;
- current runtime absent and fail-closed;
- existing C2B pre-effect `cancel` decision remains the sole basis of the cancel
  effect;
- future RW0 terminal closure is a separate Coordinator-owned fact, not a
  second C2B decision;
- active cancel ends with terminal-outcome `cancel` only after complete
  reconciliation, otherwise terminal-outcome `block`;
- no second cancel/block decision is created;
- one existing author lineage/invocation/delivery;
- no fallback, third adapter, Git, or publication;
- direct-local does not absorb ES-route authority;
- custody, transport, framing, Codex, schema, terminal-outcome representation,
  latch, and backend choices remain deferred.

All four normalized bodies must remain identical. Do not duplicate the detailed
matrix.

TEST CONTRACT — C2B DECISION VERSUS RW0 OUTCOME

Strengthen existing nodes without adding or parameterizing test nodes.

In `tests/test_rw0_remote_contact_phase_entry_contract.py`, independently
require and mutate:

1. exact existing C2B decision kinds remain unchanged;

2. cancel effect cites the pre-effect C2B cancel decision;

3. the terminal-outcome fact is explicitly not a `development_decision`;

4. non-cancel outcome values bind one same-kind C2B decision;

5. active-cancel terminal `cancel` binds the pre-effect cancel decision plus
   successful reconciliation without creating a second decision;

6. active-cancel terminal `block` binds the pre-effect cancel decision plus
   unresolved reconciliation without creating a block decision;

7. terminal outcome cannot basis an effect;

8. cancel decision cannot prove terminal cancellation;

9. source reconciliation cannot prove terminal outcome without Coordinator
   commit;

10. exactly one terminal-outcome fact exists;

11. no successor/Git/publication follows.

Causal mutants must independently reject:

- second post-teardown cancel decision;
- cancel effect based on the terminal-outcome fact;
- final `cancel` before reconciliation;
- active-cancel `block` implemented as a second C2B block decision;
- terminal-outcome fact omitted entirely;
- terminal-outcome fact called a report/projection/source observation;
- terminal outcome advancing program version by itself;
- non-cancel outcome without a same-kind decision;
- non-cancel outcome contradicting the decision kind;
- two terminal-outcome facts;
- terminal-outcome fact authorizing another effect;
- terminal-outcome representation claimed implemented now.

Retain all previous authority-basis, author-lineage, delivery, cancellation,
Markdown, ES/IM, privacy, and nonimplementation mutants.

EXACT IN-RANGE EMPTY-VISIBLE-BLOCK CAUSALITY

Repair the checked-in mutants identified by the audit in:

- tests/test_rw0_remote_contact_phase_entry_contract.py
- tests/test_architecture_contracts.py
- tests/test_remote_worker_pre_execution_planning_contract.py

For the sole owner or each applicable cross-reference specification, construct
the exact ordering inside one intended live owner range:

1. visible intended owner H3 heading;
2. balanced backtick or tilde fence containing a byte-exact otherwise-valid real
   marked body;
3. visible BEGIN marker;
4. only blank lines between BEGIN and END;
5. visible END marker;
6. no intervening same-or-higher-level heading before the range terminator.

Require:

- raw marker/body bytes remain present;
- the deliberately broken raw checker accepts the hidden real body;
- the authoritative visible-region oracle rejects the empty visible block;
- the failure is attributable to empty visible body, not absent markers, wrong
  owner, historical relocation, or range termination;
- the live positive document still accepts;
- one valid visible block plus irrelevant hidden duplicate still accepts.

Exercise all four cross-reference specifications through the complete map-wide
oracle. Use both backtick and tilde fences across the matrix, with at least one
marker kind applied to every specification.

Do not add, rename, remove, parameterize, skip, or xfail a test node.

TEST-NODE BOUNDARY

Before editing, collect exactly once under isolated posture:

- complete repository:
  exactly 4,284 nodes;
- direct RW0-A file:
  exactly 28 nodes;
- architecture file:
  exactly 30 nodes;
- remote-worker file:
  exactly 774 nodes;
- C2B3C file:
  exactly 46 nodes.

Retain literal ordered lists.

Final ordered lists must be byte-identical to opening lists.

CAUSAL RED PHASE

Before changing documentation:

1. strengthen only the authorized test helpers/mutants;
2. keep all documentation at the exact opening target;
3. use bounded external in-memory diagnostics as needed to calibrate mutants;
4. run one formal causal-red pytest gate over:

   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_remote_worker_pre_execution_planning_contract.py

   exactly once;

5. require non-green results causally demonstrating the decision/C2B conflict
   and missing terminal-outcome semantic distinction;

6. require the corrected exact in-range empty-visible-block cases to pass the
   final structural oracle while their broken raw controls accept the same
   bytes;

7. require no unrelated import, collection, setup, or evidence-recorder error.

The Markdown causality correction may be green before documentation changes
because the final oracle already handles the case. That is acceptable when the
test proves the broken raw checker accepts and the final oracle rejects the
same exact in-range bytes.

Then repair documentation and finalize helpers. Do not rerun the formal red gate
on predecessor bytes.

VALIDATION ISOLATION

Use one new external, operator-owned, non-symlink, mode-0700 repair root.

For every pytest child:

- save actual caller umask;
- create evidence under secure posture;
- restore caller umask before launch;
- record child-observed umask and require numerical equality;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`
  - `LC_ALL=C`
  - `LANG=C`
  - `PYTHONDONTWRITEBYTECODE=1`
  - distinct external `PYTHONPYCACHEPREFIX`
  - distinct external `TMPDIR`
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
  - `PYTEST_ADDOPTS=''`
  - `PYTHONHASHSEED=0`
  - `python3 -B -m pytest`
  - `-p no:cacheprovider`
  - `-W error`
  - distinct external `--basetemp`
  - external `--junitxml`
  - serial execution.

Retain exact argv, effective environment, caller/child umask, return code,
elapsed time, stdout/stderr/JUnit sizes and SHA-256, parsed counts, warnings,
parse errors, unmapped cases, and before/after target identity.

FINAL TARGETED GREEN GATES

Run exactly once each on frozen final bytes:

1. Direct RW0-A:

   tests/test_rw0_remote_contact_phase_entry_contract.py

   Require exactly 28/28 green.

2. Architecture:

   tests/test_architecture_contracts.py

   Require exactly 30/30 green.

3. Remote-worker planning:

   tests/test_remote_worker_pre_execution_planning_contract.py

   Require exactly 774/774 green.

4. Protected C2B3C:

   tests/test_c2b3c_author_effect_contract.py

   Require exactly 46/46 green.

COMPLETE RW0-A FOCUSED REGRESSION

Run exactly:

tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_software_development_progression_boundary.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_worker_execution_semantic_boundaries.py

Require exactly 1,565/1,565 green.

If any named file is absent, stop rather than substituting.

FINAL NODE COLLECTION

After targeted/focused validation and cleanup:

- collect the complete repository exactly once;
- require exactly 4,284 nodes;
- require literal equality with the opening candidate list;
- require direct test remains 28;
- architecture remains 30;
- remote-worker remains 774;
- C2B3C remains 46;
- require no added, removed, renamed, skipped, xfailed, collapsed, or
  re-parameterized node.

FULL SUITE — EXACTLY ONCE

Only after all targeted/focused gates, node identity, path boundary, and
artifact cleanup are green, run exactly once:

python3 -B -m pytest -p no:cacheprovider -W error \
  --basetemp=<external> \
  --junitxml=<external> \
  .

Require exactly:

- 4,284 collected;
- 4,284 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository bytes, topology, modes, and node identity unchanged before/after.

Do not run a second full-suite attempt.

FINAL CONTRACT AND PATH GUARDS

Require:

- exact ten-path candidate set;
- exactly eight tracked modifications and two untracked files;
- zero staged/unmerged paths;
- expected working-tree modes, including C2B3C `0600`;
- Git index mode `100644` for every tracked path;
- no Git-recorded mode change;
- no path outside the ten-path target changed;
- `.docs/c2b-durable-development-state.md` byte-identical to the opening target;
- `tests/test_c2b3c_author_effect_contract.py` byte-identical to the opening
  target;
- one sole detailed owner;
- four normalized-identical bounded cross-reference bodies;
- exact existing C2B cancel-decision grammar preserved;
- exact cancellation-effect basis relation preserved;
- exactly one distinct future RW0 terminal-outcome fact;
- no second cancel or block decision on the active-cancel branch;
- exact non-cancel same-kind decision/outcome relation;
- exact cancel-decision/reconciliation/outcome relation;
- exact in-range empty-visible-block causal tests;
- all live owner-range body content marker-owned;
- immutable authorization-basis/subordinate relation preserved;
- one author lineage/invocation preserved;
- no current implementation overclaim;
- no enduring fixture, custodian, SSH/framing, Codex, schema, terminal-outcome
  representation, latch, capsule-backend, validator/reviewer/model-adapter, or
  ES reliable-submit implementation choice added;
- no source, SQL, migration, catalog, schema, application-generation, package,
  public protocol, StateStore, WriterSession, runtime, fixture, script, config,
  or supporting-repository diff;
- `git diff --check` clean;
- no repository cache, bytecode, pytest cache, database, journal, WAL/SHM,
  build output, archive, generated manifest, or OS metadata;
- no Git operation or lock;
- no remote contact or runtime effect.

FINAL PROVENANCE

After final validation and cleanup, run the exact unchanged provenance recipe
twice.

Require:

- both return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- exactly ten entries;
- exactly eight `tracked_modified`;
- exactly two `untracked`;
- expected working-tree modes;
- no deletion, rename, symlink, Git-recorded mode change, or unsupported type.

Compare final manifest with the immutable opening target and report:

- every changed entry, opening/final size and SHA-256;
- every byte-identical protected entry;
- exact path classifications and modes;
- recipe source size/hash;
- complete-output size/hash;
- tracked textual-diff hash;
- canonical-manifest size/hash;
- causal-red evidence;
- exact in-range Markdown-causality evidence;
- targeted/focused/collection/full-suite evidence paths and hashes;
- current/target/deferred classification guard;
- no-effect/no-network/no-supporting-repo evidence.

Do not stage. The final working-tree manifest is the future independent-audit
target.

STOP CONDITIONS

Stop without further mutation if:

- opening identity, target, path set, mode posture, or node count differs;
- the findings cannot be closed inside the eight-path maximum mutation
  allowlist;
- `.docs/c2b-durable-development-state.md` or the C2B3C test must change;
- closing the conflict requires altering the C2B decision-kind grammar;
- a distinct RW0 terminal-outcome fact cannot be defined without selecting a
  physical schema or public API in RW0-A;
- any source/schema/migration/public/runtime change appears necessary;
- the exact in-range Markdown mutant cannot be represented without changing the
  live documents;
- an existing test node must change;
- targeted, focused, collection, or full-suite validation is not exact-green;
- another path changes;
- final provenance is unstable;
- remote contact, staging, publication, worker/model/process activity, or
  supporting-repository mutation would be required.

On stop, preserve exact state and evidence. Do not reset, clean, revert, switch
branches, stage, or discard work.

CLOSEOUT

Return exactly:

COORDINATOR_RW0_T1_THIRD_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

only if:

- the existing C2B pre-effect cancel decision remains the sole cancellation
  effect basis;
- no second cancel or block decision is created on the active-cancel branch;
- a separate future RW0 terminal-outcome semantic fact is coherently frozen;
- non-cancel and active-cancel decision/outcome relations are exact;
- terminal-outcome representation remains deferred;
- the exact in-range empty-visible-block causal tests are correct in all named
  test surfaces;
- validation is exact-green;
- node identity is unchanged;
- final ten-path provenance is stable;
- no source/runtime/remote/staging/publication effect occurred.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
