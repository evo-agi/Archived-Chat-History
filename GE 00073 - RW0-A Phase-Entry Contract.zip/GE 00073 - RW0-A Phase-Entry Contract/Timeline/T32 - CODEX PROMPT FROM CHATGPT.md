TITLE

Coordinator RW0-A phase-entry contract freeze — fresh independent re-audit
after the fourth-audit findings repair

ENGAGEMENT TYPE

Fresh-conversation independent audit.

Run this in a new Codex conversation with read-only repository posture.

Do not resume or use the implementation conversation or any preceding audit
conversation as this audit conversation. Their reports and retained evidence
are inputs only.

Repository mutation is not authorized. Do not edit, format, create, delete,
rename, chmod, clean repository paths, switch branches, stage, commit, amend,
push, create or update a PR, merge, rebase, reset, tag, release, deploy,
install dependencies, run live migrations, invoke a model/provider or Codex,
launch a worker/process, contact a host, Bridge, Execution Substrate,
Infrastructure Manager, or any remote.

Temporary audit output is authorized only beneath one audit-created,
operator-owned, non-symlink, mode-0700 external root. Do not write audit output
inside the repository. Remove only audit-created external artifacts when safe.
Do not delete, overwrite, or normalize implementation evidence.

If any repository byte, local permission, path, index entry, branch, Git
operation state, or topology changes, stop and report it. Do not silently
restore or clean it.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

WORKSTREAM

COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1

TRANCHE

RW0-A-PHASE-ENTRY-CONTRACT-FREEZE

PRIMARY OBJECTIVE

Independently audit the exact final ten-path RW0-A candidate after the
parent-only repair of the latest audit findings:

1. RW0A-SEM-01 — the accepted C2B decision and later terminal-outcome fact had
   conflicting latch-consumption semantics;

2. RW0A-SEM-02 — the target lacked a fail-closed terminal path when the exact
   pre-effect C2B cancel decision became stale or incompatible before cancel-
   effect establishment;

3. RW0A-TEST-01 — hostile one-document Markdown mutations were exercised only
   through path-local helpers rather than the complete authoritative four-
   document map-wide oracle;

4. RW0A-PROV-01 — the prior implementation report did not explicitly bind its
   separate final-guard evidence identity.

The implementation now reports that:

- the immutable C2B `development_decision(kind=accept)` alone atomically
  consumes the productive-direct-local acceptance latch in its guarded writer
  transaction;
- the later RW0 terminal-outcome fact binds the exact accept-decision ref/digest
  and committed latch postimage but cannot consume, mutate, reopen, or repair
  the latch;
- terminal-outcome commit uncertainty after a committed accept blocks every
  later effect, successor, Git action, and publication until exact readback,
  without another accept decision or latch mutation;
- a stale, missing, incompatible, superseded, or ambiguous pre-effect cancel
  basis establishes no cancel effect, fence, delivery, request, signal,
  replacement decision, replacement effect, or replacement lineage inside RW0;
- that fail-closed sub-branch commits one separate RW0 terminal-outcome fact
  with value `block`, bound to the exact unusable cancel decision and mismatch
  evidence, without creating a C2B block decision;
- every hostile one-document cross-reference mutation is inserted into a
  complete four-document map and routed through the same complete authoritative
  map-wide oracle;
- the direct, architecture, remote-worker, protected C2B3C, focused, node, and
  full-suite gates are exact-green;
- the final report explicitly binds the final guard;
- the final evidence index safely verifies 94 retained evidence files;
- no source, schema, migration, runtime, public API, worker, model, network,
  supporting-repository, staging, or publication effect occurred.

Do not trust those claims as correctness evidence.

First bind this audit to the exact canonical manifest and verify the report →
guard → evidence-index chain. Then inspect the complete ten-path candidate,
independently reproduce every relevant hostile mutant, and rerun validation.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Do not repair findings.

CURRENT COMMITTED BASELINE

Require and verify:

- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- HEAD tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- HEAD subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1

CURRENT IMPLEMENTATION BOUNDARY

Verify from the committed baseline and unchanged source that current capability
still stops at:

- internal C2A pure values and validators;
- private readers;
- guarded writer/transaction authority;
- private VS1B genesis;
- private C2B3D author-effect establishment with inert planned
  `direct_local_bootstrap` author delivery;
- private Section 41 pre-execution proposal selection;
- application generation 2 and migrations through 0003.

Verify that current capability still does not implement:

- executable parent-grant verification or subordinate authorization derivation;
- WorkSpec physical custody or bearer retrieval;
- direct-local adapter, supervisor, worker, Codex invocation, or process launch;
- dispatcher, queue, service, IPC, outbox/inbox, or reconciler;
- capsule builder/store/retrieval;
- validation, independent review, model invocation/proposal runtime, or
  post-execution semantic-decision runtime;
- RW0 terminal-outcome persistence or runtime;
- cancellation delivery/acknowledgement/runtime reconciliation;
- productive-direct-local acceptance-latch runtime;
- Git effect;
- Bridge or ES handoff;
- publication or autonomous loop.

EXPECTED OPENING REPOSITORY IDENTITY

Require exactly before correctness inspection:

- Physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- Subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1
- Dirty paths:
  exactly 10
- Tracked modifications:
  exactly 8
- Untracked:
  exactly 2
- Staged/unmerged:
  0/0
- No deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  or Git lock
- Repository residue:
  empty
- `git diff --check HEAD --`:
  clean.

Expected path classifications:

Tracked modifications:

.docs/c2b-durable-development-state.md
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_architecture_contracts.py
tests/test_c2b3c_author_effect_contract.py

Untracked:

.docs/rw0-remote-worker-contact-phase-entry.md
tests/test_rw0_remote_contact_phase_entry_contract.py

Expected local mode posture:

- these nine paths are regular working-tree mode `0644`:

  .docs/rw0-remote-worker-contact-phase-entry.md
  .docs/c2b-durable-development-state.md
  .docs/autonomous-software-development-operating-model.md
  .docs/worker-execution-boundary.md
  .docs/authority-boundaries.md
  .docs/durable-state-model.md
  tests/test_rw0_remote_contact_phase_entry_contract.py
  tests/test_remote_worker_pre_execution_planning_contract.py
  tests/test_architecture_contracts.py

- this path is regular working-tree mode `0600`, current-operator-owned, with no
  execute bits:

  tests/test_c2b3c_author_effect_contract.py

- Git index mode for every tracked candidate path is `100644`;
- no Git-recorded mode change exists.

The local `0600` mode is a restrictive working-tree metadata overlay. Do not
chmod it. It is not a defect when content, ownership, no-execute posture,
target manifest, and Git index mode match.

Do not fetch or contact a remote. Any identity, topology, path-set,
classification, mode, or branch mismatch is AUDIT_PROVENANCE_MISMATCH.

AUTHORITATIVE FINAL EVIDENCE ARTIFACTS

Safely verify these exact files through every path component.

1. FINAL GUARD

/private/tmp/ge-rw0a-fourth-repair-nlhdj0o8/final-guard.json

Require:

- evidence root operator-owned, non-symlink, mode 0700;
- file regular, operator-owned, non-symlink, mode 0400;
- size:
  6,435 bytes;
- SHA-256:
  0e0e0a5b2e94410654cefad7ee3d1fe48a8657a9ed8fb7481e71b187adae1259.

2. FINAL CLOSEOUT REPORT

/private/tmp/ge-rw0a-fourth-repair-nlhdj0o8/final-closeout-report.json

Require:

- regular, operator-owned, non-symlink, mode 0400;
- size:
  21,813 bytes;
- SHA-256:
  549b7c1791501f5ab3636bfcf3d43dc844343f1515ee0de260db84161359da22.

3. FINAL EVIDENCE INDEX

/private/tmp/ge-rw0a-fourth-repair-nlhdj0o8/final-evidence-index.json

Require:

- regular, operator-owned, non-symlink, mode 0400;
- size:
  18,140 bytes;
- SHA-256:
  85b129525c541f1c0c7849d3e53be710f5b7673942b58848171f049bbfc51565.

4. FINAL CANONICAL MANIFEST

/private/tmp/ge-rw0a-fourth-repair-nlhdj0o8/final-canonical-manifest.json

Require:

- regular, operator-owned, non-symlink, mode 0400;
- size:
  2,328 bytes;
- SHA-256:
  3d880594f269d8bb7f13479df50cf4cd5b24b7dd6e913620517cd8c15c24ccf2.

Copy the exact verified bytes of all four artifacts into the audit root under
immutable mode-0400 names before running the provenance recipe.

EVIDENCE BINDING GATE

The canonical manifest and live Git are authoritative for repository identity.
The guard, report, and index are evidence/projection and must not replace Git or
repository contracts.

Parse the closeout report and require it explicitly records:

- branch, HEAD, and upstream;
- opening-target path/size/SHA-256;
- final canonical-manifest path/size/SHA-256;
- recipe source path/size/SHA-256;
- complete-output size/SHA-256;
- tracked textual-diff SHA-256;
- exact per-file opening/final identities;
- exact test and node results with evidence paths/hashes;
- protected-byte results;
- limitations and unresolved seams;
- all required no-effect statements;
- a `guard_evidence` field containing the exact final-guard path, size, and
  SHA-256 above.

Safely verify the report’s `guard_evidence` target byte-for-byte against the
pinned final guard.

Parse the final evidence index and require:

- exactly 94 indexed external evidence files, excluding the index itself;
- every indexed path is safe, external, regular, operator-owned, non-symlink,
  and mode 0400;
- every indexed size and SHA-256 matches the live retained file;
- the index includes at least:
  - opening target;
  - both final provenance recipe sources/runs and manifests;
  - final canonical manifest;
  - causal-red report/stdout/stderr/JUnit;
  - every final targeted/focused/collection/full-suite report/stdout/stderr/
    JUnit;
  - opening and final node lists;
  - final guard;
  - final closeout report;
- the report and guard identities inside the index match the pinned values.

If the report-to-guard binding fails, the index omits or contradicts required
entries, the expected count differs, or any indexed bytes differ, return
AUDIT_PROVENANCE_MISMATCH.

Do not reject merely because external evidence uses implementation-local
absolute paths. Safe exact bytes and explicit hashes are decisive.

AUTHORITATIVE FINAL AUDIT TARGET

Parse the pinned final canonical manifest and require:

- recipe_id:
  governed-execution.audit-patch-manifest.v1
- branch:
  codex/rw0-phase-entry-contract-freeze
- head:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- exactly ten entries;
- exactly eight `tracked_modified`;
- exactly two `untracked`;
- C2B3C test regular mode `0600`;
- every other entry regular mode `0644`;
- no tracked addition/deletion, missing path, symlink, or unsupported type.

Require the manifest’s textual-diff SHA-256 to equal both:

- the value in the pinned closeout report; and
- the value in the pinned final guard.

Any mismatch is AUDIT_PROVENANCE_MISMATCH.

PRECEDING FOURTH-REPAIR TARGET

Safely verify the opening target named by the pinned closeout report.

Require:

- safe regular immutable bytes;
- SHA-256:
  e46474d1b2af374e2bd84ded976e2bb1dd01399dfdc4a2b31b93bbd13f5c830e;
- size:
  2,328 bytes;
- canonical branch, HEAD, upstream, topology, classifications, and modes equal
  to the final target.

Compare opening and final manifests entry by entry.

Require:

- no added or removed path;
- no classification or mode change;
- no change to:

  .docs/c2b-durable-development-state.md
  tests/test_c2b3c_author_effect_contract.py

Protected exact identities:

- `.docs/c2b-durable-development-state.md`
  - 1,884,626 bytes
  - SHA-256:
    5fd66a1266e63f8f026a27de7d84f42029813acdadc6b3ecb1978c3ff9ce9b1e
  - mode:
    0644

- `tests/test_c2b3c_author_effect_contract.py`
  - 416,182 bytes
  - SHA-256:
    935ca6fe7b18d39055d5cdc2c911302e7c0726304f3699472f3994a32f7b4778
  - working-tree mode:
    0600
  - Git index mode:
    100644

Only these eight paths may differ:

.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/worker-execution-boundary.md
tests/test_architecture_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py

Use the pinned closeout report as the source for every exact opening/final
size/SHA-256 pair and verify them against both manifests and live bytes.

Any ninth changed entry or protected-entry mismatch is
AUDIT_PROVENANCE_MISMATCH.

EXPECTED PROVENANCE RECIPE

Recipe ID:

governed-execution.audit-patch-manifest.v1

Exact source size:

3,945 bytes

Exact source SHA-256:

db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Use the exact source below. Do not normalize, improve, approximate, or version
it during the audit.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

OPENING PROVENANCE GATE

1. Verify exact recipe source size and SHA-256.
2. Safely classify:
   /tmp/ge-coordinator-b3a-audit-manifest-v1.json
3. If it exists:
   - require regular, non-symlink, operator-owned;
   - preserve exact pre-audit bytes and safely available metadata in the audit
     root;
   - do not delete unrelated evidence.
4. Run the exact recipe twice.
5. Require both invocations return 0 with empty stderr.
6. Require byte-identical complete stdout.
7. Require byte-identical canonical manifests.
8. Require generated canonical bytes equal the pinned final canonical manifest
   byte-for-byte.
9. Require complete-output size/hash and tracked-diff hash equal the values in
   the pinned report and guard.
10. Compare every path, classification, type, mode, size, and SHA-256 entry.

Any mismatch is AUDIT_PROVENANCE_MISMATCH. Stop before correctness inspection.

PROTECTED BASELINE AND APPEND-ONLY PINS

Require:

1. `.docs/c2b-durable-development-state.md`

   The complete committed-baseline bytes remain the exact candidate prefix:

   - 1,883,380 bytes
   - SHA-256:
     9401d62a0eb36e0cca1af5b8a6a80b540ddc4c781fee3faaf7318546cb532ccc

2. The append-only RW0 H3 remains wholly after that prefix and after:

   `COORDINATOR_SECTION41_COMMITTED_CURRENT_STATUS_END`

3. Final visible H2 remains Section 42, with no H2 Section 43.

4. The exact C2B3C committed-status owner remains protected and compatible with
   later governed H3 extensions.

Require no diff outside the ten-path target, especially no diff in:

- AGENTS.md
- README.md
- .docs/architecture.md
- .docs/c2a-first-slice-semantic-protocol-contract.md
- .docs/software-development-progression-boundary.md
- every `src/**` path
- all SQL and migrations
- migration catalog and application generation
- schemas
- package exports and public protocols
- StateStore and WriterSession
- fixtures, scripts, configs, examples, or supporting repositories.

TARGETED AUDIT TASKS

Only after provenance and evidence binding match, spawn exactly four bounded
read-only audit tasks in parallel when capacity permits. No nested subagents
and no subagent-run tests. If only three child slots are available, start the
fourth immediately when a slot frees. Make at most one retry for a failed start.

Give every task the same exact canonical manifest, preceding audit findings,
parent repair decisions, current contract, accepted strategic target, reopened
seams, compatibility obligations, non-goals, and mutation prohibition.

1. ACCEPT-LATCH, TERMINAL-OUTCOME, AND NONIMPLEMENTATION AUDITOR

   Inspect the complete changed documentation and relevant unchanged C2A/C2B3D/
   Section 41 contracts.

   Determine whether:

   - the accepted C2B development decision alone atomically consumes the latch;
   - latch consumption occurs in the same guarded writer transaction as the
     accept decision;
   - the later terminal-outcome fact binds the exact accept-decision ref/digest
     and exact committed latch postimage;
   - terminal-outcome commit does not consume, mutate, reopen, repair, or
     prerequisite the latch mutation;
   - unresolved terminal-outcome commit after accepted decision leaves the
     latch consumed but blocks all later effect/successor/Git/publication until
     exact guarded-writer readback;
   - no second accept decision or second latch mutation exists;
   - every non-accept outcome leaves the latch unchanged;
   - terminal-outcome storage/runtime remains deferred;
   - current runtime remains unsupported and fail-closed;
   - no source, schema, migration, table, public type, wire format, verifier, or
     runtime is claimed implemented.

2. STALE CANCEL BASIS, RECOVERY, AUTHORITY, AND FACT-OWNER AUDITOR

   Inspect the sole owner’s cancellation branches, failure/recovery matrix,
   authorization/fence relations, terminal-outcome relations, worker facts, and
   route ownership.

   Determine whether:

   - exact cancel-decision readback precedes pre-effect currentness evaluation;
   - current stop-version, target head, program/version/attempt/target,
     parent-grant, subordinate authorization, basis/fence, expiry/revocation,
     repository/base/path/audience, and preassigned effect/fence/delivery/target
     relations are complete before cancel-effect establishment;
   - any stale, incompatible, missing, superseded, or ambiguous basis creates no
     cancel effect, fence, delivery, request, signal, replacement decision,
     replacement effect, or replacement lineage;
   - that branch produces terminal-outcome `block`, bound to the exact unusable
     cancel decision and mismatch evidence;
   - terminal `block` is not a C2B block decision;
   - no successor/replan occurs inside the same RW0 run;
   - the valid-basis branch retains request/ack/signal/exit/teardown/
     reconciliation ordering and final `cancel` or unresolved `block`;
   - reports, observations, route receipts, and verifier projections cannot
     author the terminal outcome;
   - every earlier authority-basis, author-lineage, delivery, supervisor/worker,
     direct-local/ES/IM, and cancellation finding remains closed.

3. COMPLETE MAP-WIDE MARKDOWN AND TEST-NONWEAKENING AUDITOR

   Inspect all changed tests and all candidate documents.

   Determine whether:

   - one closed four-entry inventory defines path, intended current owner and
     ancestor chain, predecessor/range terminator, BEGIN, and END markers;
   - the complete authoritative oracle consumes a complete four-document map;
   - every hostile mutation starts from the complete live map, mutates exactly
     one document, retains the other three exact, and calls the same complete
     oracle;
   - path-local helpers receive no final correctness credit by themselves;
   - all four specs exercise the exact in-range hidden-real/visible-empty case
     through the complete oracle;
   - both backtick and tilde fences occur across the matrix and every spec is
     covered;
   - complete-map mutations also cover visible leading/trailing prose,
     fenced-only body, split/reversed markers, historical relocation,
     same-title sibling/ancestor relocation, two visible blocks, and one-body
     mismatch;
   - exact live map and hidden-duplicate positive controls pass through the
     complete oracle;
   - deliberately broken raw/path-local controls reproduce predecessor
     weakness but are never authoritative;
   - no existing test was weakened, renamed, removed, skipped, xfailed,
     collapsed, or re-parameterized;
   - no new test node was added.

4. PROVENANCE, SECURITY, PUBLIC-BOUNDARY, AND ARTIFACT AUDITOR

   Inspect:

   - the complete ten-path diff;
   - exact eight-entry opening-to-final delta;
   - canonical manifest;
   - closeout report and its bound guard;
   - all 94 evidence-index entries;
   - protected C2B/C2B3C bytes;
   - local `0600` versus Git `100644` posture;
   - source/schema/migration/public-surface diff guards;
   - artifact and sensitive-material posture.

   Determine whether:

   - the candidate is genuinely docs/tests-only;
   - report, guard, and index are internally exact but remain evidence only;
   - no credential, bearer, raw WorkSpec, prompt, transcript, endpoint, private
     host identity, or sensitive log is embedded;
   - no source, process, worker, model, service, network, or database behavior
     was introduced;
   - no evidence/report became authority;
   - the candidate is suitable for a later audited-byte feature-branch commit
     and PR gate.

Each task must return severity-ranked, path:line-grounded findings and state:

- current contract versus strategic target;
- patch defect versus pre-existing issue;
- impact;
- required correction;
- uncertainty;
- scope not inspected;
- mutation performed:
  no;
- tests run:
  no;
- nested subagents:
  no.

The parent must inspect and reconcile every report. Preserve factual,
interpretive, or target-level disagreements.

MANDATORY PARENT INSPECTION

Inspect directly:

- all four pinned final evidence artifacts;
- report → guard binding;
- every evidence-index entry;
- opening and final canonical manifests;
- exact eight-entry comparison;
- all ten candidate paths;
- complete diff against HEAD;
- complete opening-to-final diffs for every safely reconstructable changed
  entry;
- current C2A decision/latch/effect/delivery/fence/observation/cancellation
  contracts;
- current C2B3D and Section 41 lineage/nonimplementation contracts;
- exact accept decision/latch transaction relation;
- exact stale-cancel pre-effect currentness relation;
- every changed sole-owner section, matrix, timeline, branch, and failure rule;
- all four changed bounded cross-reference bodies and structural owners;
- every changed test helper and strengthened existing test node;
- complete map-wide mutation calls and broken controls;
- protected C2B and C2B3C bytes;
- retained causal-red, targeted, focused, collection, full-suite, guard, report,
  index, and provenance records.

If complete opening bytes for one changed untracked file are not safely
retained, report that as an evidence limitation. Do not invent a textual diff.
The exact manifest identity delta remains mandatory.

Do not re-audit unchanged runtime internals wholesale after exact no-diff proof,
unless changed documentation or tests contradict them.

ACCEPTANCE CHECK — ACCEPT DECISION AND LATCH ATOMICITY

Require:

1. On `accept`, one immutable C2B `development_decision(kind=accept)` alone
   consumes the productive-direct-local latch.

2. The decision and latch mutation are atomic in one guarded writer
   transaction.

3. The later RW0 terminal-outcome fact with value `accept` binds:
   - exact accepted-decision ref/digest;
   - exact committed latch postimage.

4. The outcome fact cannot consume, mutate, reopen, repair, or prerequisite the
   latch mutation.

5. If outcome commit is uncertain after accepted decision:
   - latch remains consumed;
   - exact guarded-writer readback resolves the outcome;
   - no new effect, successor, Git action, or publication occurs;
   - no second accept decision or latch mutation occurs.

6. `repair`, `replan`, `terminal_reject`, `block`, and `cancel` do not mutate the
   latch.

Independently reject:

- delayed latch consumption at outcome commit;
- outcome-owned latch mutation;
- outcome as prerequisite to decision/latch commit;
- wrong latch postimage binding;
- second latch mutation;
- unresolved outcome permitting successor/Git/publication;
- non-accept outcome consuming the latch.

ACCEPTANCE CHECK — STALE PRE-EFFECT CANCEL BASIS

Require:

1. Exact cancel-decision commit/readback is resolved before currentness
   evaluation.

2. Currentness is re-established immediately before cancel-effect
   establishment across every required relation.

3. A stale, incompatible, missing, superseded, or ambiguous basis yields:
   - no cancel effect;
   - no fence or delivery;
   - no request or signal;
   - no replacement cancel/block decision;
   - no replacement effect/lineage;
   - one RW0 terminal-outcome fact with value `block`;
   - exact binding to the unusable cancel decision and mismatch evidence;
   - no successor, Git, or publication.

4. That terminal block is not a C2B block decision.

5. A current valid cancel basis proceeds through the existing active-cancel
   sequence and final reconciliation.

6. A later successor outside RW0 may replan; the current RW0 run cannot absorb
   the drift.

Independently reject:

- stale decision still establishing effect;
- replacement cancel decision;
- replacement block decision;
- mismatch reinterpreted as compatible;
- request/signal without effect;
- terminal cancel on unusable basis;
- omitted terminal path;
- successor/replan inside same RW0 run;
- report/verifier projection authoring outcome.

ACCEPTANCE CHECK — COMPLETE FOUR-DOCUMENT ORACLE

For exactly:

.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md

require:

- one complete authoritative oracle accepts a four-document map only when every
  intended owner range has one valid visible block and all normalized bodies
  are identical;
- every hostile mutant supplies a complete four-document map;
- exactly one document is mutated per case;
- the other three documents remain exact live positives;
- every mutant reaches the same complete oracle;
- path-local checks alone cannot make the test pass;
- all four specs receive the in-range hidden-real/visible-empty mutant;
- both backtick and tilde fences are used across the matrix;
- every spec receives at least one fence style;
- complete-map leading/trailing prose, fenced-only, split/reversed, historical,
  same-title, duplicate-visible, and body-mismatch mutants reject;
- live map and hidden-duplicate positive controls accept;
- broken raw/path-local controls reproduce predecessor weakness but are never
  authoritative.

Independently reconstruct representative complete-map mutants rather than
trusting checked-in assertions alone.

PRIOR-FINDING REGRESSION MATRIX

Independently verify that every earlier finding class remains closed:

- one author delivery versus separate later current-effect deliveries;
- no author redelivery/relaunch/replacement lineage;
- model proposal not a DeliveryEnvelope effect;
- immutable per-fence authorization basis plus separate subordinate record;
- common-family verification and fail-closed incompatibility;
- distinct C2B cancel decision and terminal-outcome fact;
- post-teardown source reconciliation;
- one final terminal outcome;
- supervisor launch versus worker-authored start;
- direct-local versus ES route ownership;
- sole-owner visible marker pair;
- all visible owner-range prose inside markers;
- four normalized-identical visible cross-references;
- hidden duplicate acceptance;
- same-title/historical/fenced/split/duplicate-visible rejection;
- independent terminal inventories and stop rules;
- C2B3C committed-status extension compatibility and exact duplicate diagnostic;
- current/nonimplementation and every deferred seam.

CURRENT-VERSUS-TARGET AND DEFERRED DECISIONS

Require:

- accepted strategic target, not current-runtime claim;
- external parent grant plus future Coordinator-derived narrower subordinate
  record;
- raw WorkSpec privacy and ref/digest non-authority;
- exact custodian/issuer/backend/transport/Codex/sandbox/framing/schema/latch/
  capsule/validator/reviewer/model/ES details remain deferred;
- terminal-outcome and latch representations remain deferred;
- one qualified remote Linux host, no fallback, no third adapter;
- provisional ES fixture remains non-authoritative and stale-able;
- base/path drift requires replan/new WorkSpec;
- author versus later current-effect delivery split remains exact;
- supervisor/worker fact ownership remains exact;
- direct-local/ES/IM ownership remains exact;
- no Git/publication in RW0.

IMPLEMENTATION EVIDENCE TO INSPECT, NOT TRUST

Use the verified closeout report and evidence index to locate and inspect:

- causal-red evidence;
- final direct 28/28;
- final architecture 30/30;
- final remote-worker 774/774;
- protected C2B3C 46/46;
- focused 1,565/1,565;
- final collection and opening/final node lists;
- full-suite 4,284/4,284;
- final guard;
- two final provenance runs;
- per-file opening/final comparison;
- independent implementation-side binding check.

No correctness credit comes from implementation evidence.

VALIDATION ISOLATION

Use one audit-created external, operator-owned, non-symlink, mode-0700 root.

For every pytest child:

- save actual caller umask;
- create evidence under secure posture;
- restore caller umask before launch;
- record child-observed umask and require numerical equality;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`
  - `LC_ALL=C`
  - `LANG=C`
  - `PYTHONDONTWRITEBYTECODE=1`
  - distinct external `PYTHONPYCACHEPREFIX`
  - distinct external `TMPDIR`
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
  - `PYTEST_ADDOPTS=''`
  - `PYTHONHASHSEED=0`
  - `python3 -B -m pytest`
  - `-p no:cacheprovider`
  - `-W error`
  - distinct external `--basetemp`
  - external `--junitxml`
  - serial execution.

Retain exact argv, environment, caller/child umask, return code, elapsed time,
stdout/stderr/JUnit sizes and SHA-256, parsed counts, warnings, parse errors,
unmapped cases, and before/after target equality.

DIRECT RW0-A ORACLE — EXACTLY ONCE

Run:

tests/test_rw0_remote_contact_phase_entry_contract.py

Require exactly 28/28 green.

ARCHITECTURE REGRESSION — EXACTLY ONCE

Run:

tests/test_architecture_contracts.py

Require exactly 30/30 green.

REMOTE-WORKER REGRESSION — EXACTLY ONCE

Run:

tests/test_remote_worker_pre_execution_planning_contract.py

Require exactly 774/774 green.

C2B3C PROTECTED REGRESSION — EXACTLY ONCE

Run:

tests/test_c2b3c_author_effect_contract.py

Require exactly 46/46 green.

COMPLETE RW0-A FOCUSED REGRESSION — EXACTLY ONCE

Run exactly:

tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_software_development_progression_boundary.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_worker_execution_semantic_boundaries.py

Require exactly 1,565/1,565 green.

NODE IDENTITY

After focused validation:

1. Collect the candidate exactly once.
2. Require exactly 4,284 node IDs.
3. Create one clean external `git archive HEAD`.
4. Collect HEAD exactly once.
5. Require exactly 4,256 HEAD node IDs.
6. Require:
   - intersection:
     4,256;
   - candidate-only:
     exactly 28;
   - HEAD-only:
     0;
   - all 28 candidate-only nodes belong to
     `tests/test_rw0_remote_contact_phase_entry_contract.py`;
   - no existing node changed identity or order.
7. Require exact candidate node-list SHA-256:
   7fb16833d1fcf8916f62ad17b0238b87b8cda8bb03432039771290bc713d12e8
8. Require exact existing-file counts:
   - architecture:
     30;
   - C2B3C:
     46;
   - remote-worker:
     774;
   - direct RW0-A:
     28.

FULL SUITE — EXACTLY ONCE

Only after inspection, independent mutants, targeted/focused validation, node
comparison, and artifact cleanup are green, run the complete repository suite
exactly once:

python3 -B -m pytest -p no:cacheprovider -W error \
  --basetemp=<external> \
  --junitxml=<external> \
  .

Require exactly:

- 4,284 collected;
- 4,284 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository bytes, modes, topology, and target manifest unchanged.

Do not run a second full-suite attempt. If immutable JUnit parsing initially
misclassifies paths, reparse the same JUnit without rerunning pytest.

FINAL GUARDS

Require:

- exact ten-path target set;
- exactly eight tracked modifications and two untracked paths;
- zero staged or unmerged paths;
- expected local mode posture, including C2B3C `0600`;
- Git index mode `100644` for every tracked candidate path;
- no Git-recorded mode change;
- no path outside target changed;
- protected C2B and C2B3C entries exact;
- append-only prefix exact;
- final H2 Section 42 and no Section 43;
- four bounded cross-reference bodies normalized-identical;
- one sole detailed RW0 owner;
- accepted decision atomically owns latch consumption;
- terminal outcome only binds the accepted latch postimage;
- stale pre-effect cancel basis yields terminal `block` with no replacement
  decision/effect/request;
- complete four-document mutated maps route through the authoritative oracle;
- all prior findings remain closed;
- no current implementation overclaim;
- no enduring ES fixture, custodian, SSH/framing, Codex, schema, latch,
  capsule-backend, validator/reviewer/model-adapter, terminal-outcome backend,
  or ES reliable-submit choice accidentally frozen;
- no source, SQL, migration, catalog, schema, application-generation, package,
  public protocol, StateStore, WriterSession, runtime, fixture, script, config,
  or supporting-repository diff;
- `git diff --check` clean;
- no repository cache, bytecode, pytest cache, database, journal, WAL/SHM,
  build output, archive, generated manifest, or OS metadata;
- no Git operation or lock;
- no remote contact or runtime effect.

FINDING AND VERDICT RULES

Classify findings by:

- current-versus-target contract drift;
- latch/decision atomicity defect;
- stale cancel-basis/recovery defect;
- authority/fence or author-lineage drift;
- ambiguity/cancellation/terminal-outcome defect;
- Markdown map-wide ownership or mutation-causality defect;
- test non-weakening defect;
- ES/IM ownership drift;
- source/public-boundary widening;
- security/privacy issue;
- provenance/evidence-binding/validation gap;
- artifact hygiene issue;
- pre-existing observation outside the patch.

Use severity:

critical
high
medium
low
observation

For every finding report:

- stable ID;
- type and severity;
- exact path:line evidence;
- current contract or strategic target;
- impact;
- required correction;
- uncertainty;
- patch defect or pre-existing issue.

ACCEPT only when:

- opening and closing provenance equal the exact canonical target;
- report → guard binding verifies exactly;
- all 94 evidence-index entries verify exactly;
- opening and final manifests differ only inside the eight authorized paths,
  with the protected two exact;
- all four audit tasks complete;
- RW0A-SEM-01, RW0A-SEM-02, RW0A-TEST-01, and RW0A-PROV-01 are independently
  and causally closed;
- all earlier finding classes remain closed;
- current implementation is not overclaimed;
- accept-decision/latch atomicity is exact;
- terminal outcome does not mutate the latch;
- stale pre-effect cancel basis terminates as RW0 block without another C2B
  decision/effect;
- every hostile four-document mutation reaches the complete authoritative
  oracle;
- no existing test was weakened or its node identity changed;
- direct, architecture, remote-worker, C2B3C, focused, node, and full-suite
  validation are exact-green;
- no Critical, High, Medium, or Low patch defect remains;
- the exact candidate is suitable for an audited-byte feature-branch commit,
  push, PR, and later squash-merge gate.

Use BLOCK for a repairable defect, non-green validation, materially incomplete
evidence, or unresolved uncertainty preventing acceptance.

Use REJECT only for a fundamental architecture or authority failure that cannot
be repaired within RW0-A.

Use AUDIT_PROVENANCE_MISMATCH for canonical target-byte, branch, path-set,
topology, recipe, report-to-guard, evidence-index, retained-manifest, mode, or
classification mismatch.

CLOSEOUT PROVENANCE

After all inspection and validation, and after removing only safe
audit-created external artifacts:

1. Run the exact recipe twice again.
2. Require complete identity with the immutable opening target.
3. Recheck report/guard/index integrity, protected entries, append-only prefix,
   modes, Git index modes, path set, topology, residue, operations, and locks.
4. Do not accept if audit activity changed repository bytes or metadata, even if
   later restored.

FINAL REPORT

Begin with exactly one primary verdict token:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Then report:

1. Exact opening and closing repository identity and canonical provenance.
2. Exact guard, report, index, and manifest identities.
3. Explicit report → guard binding and 94-entry index verification.
4. Exact opening-to-final eight-entry comparison.
5. Audit tasks, completion, retries, and disagreements.
6. Complete severity-ranked finding ledger.
7. Disposition of RW0A-SEM-01, RW0A-SEM-02, RW0A-TEST-01, RW0A-PROV-01, and
   every earlier finding class.
8. Current implementation versus RW0 target assessment.
9. Accept-decision/latch atomicity assessment.
10. Stale pre-effect cancel-basis and recovery assessment.
11. Complete four-document map-wide oracle and hostile-mutant results.
12. Authority, author-lineage, cancellation, fact-owner, ES/IM, and Markdown
    prior-finding regression matrix.
13. Test non-weakening and node-identity assessment.
14. Direct, architecture, remote-worker, C2B3C, focused, and full-suite
    validation.
15. Protected-byte, mode, public-boundary, security, and artifact checks.
16. Limitations and separate provenance, validation, and implementation
    confidence estimates.

If ACCEPT, include:

COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FREEZE_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

If not ACCEPT, do not provide a commit or PR prompt and do not repair.

Required closing statements:

REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
