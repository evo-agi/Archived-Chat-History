## Verdict

**Advance the exact candidate to a fresh independent read-only re-audit. No further implementation repair is justified before that audit.**

The closeout resolves the two categories that blocked the previous audit cycle:

1. **Repository-contract repairs**
   - The accepted C2B decision now owns latch consumption atomically.
   - The later terminal-outcome fact only binds the committed latch postimage.
   - An unusable pre-effect cancel basis now terminates RW0 as `block` without creating another C2B decision, effect, delivery, or request.
   - The hostile Markdown cases now exercise complete four-document maps rather than path-local helpers.

2. **Evidence-closeout repair**
   - The closeout report explicitly binds the final guard.
   - The evidence index reportedly verifies 94 retained evidence files.
   - The canonical manifest remains the authoritative patch identity; the report, guard, and index remain supporting evidence rather than repository authority.

The implementation-side “independent read-only check” of the evidence chain is useful closeout validation, but it is **not** the fresh independent audit required by the lifecycle. Independent audit belongs in a separate read-only conversation, after exact provenance reproduction and before any commit or publication action. 

## New audit target

Codex reports these exact evidence artifacts:

```text
Final guard
/private/tmp/ge-rw0a-fourth-repair-nlhdj0o8/final-guard.json
6,435 bytes
SHA-256:
0e0e0a5b2e94410654cefad7ee3d1fe48a8657a9ed8fb7481e71b187adae1259
```

```text
Final closeout report
/private/tmp/ge-rw0a-fourth-repair-nlhdj0o8/final-closeout-report.json
21,813 bytes
SHA-256:
549b7c1791501f5ab3636bfcf3d43dc844343f1515ee0de260db84161359da22
```

```text
Final evidence index
/private/tmp/ge-rw0a-fourth-repair-nlhdj0o8/final-evidence-index.json
18,140 bytes
SHA-256:
85b129525c541f1c0c7849d3e53be710f5b7673942b58848171f049bbfc51565
```

```text
Canonical manifest
/private/tmp/ge-rw0a-fourth-repair-nlhdj0o8/final-canonical-manifest.json
2,328 bytes
SHA-256:
3d880594f269d8bb7f13479df50cf4cd5b24b7dd6e913620517cd8c15c24ccf2
```

These are still **Codex-reported facts** until the auditor safely verifies every path, byte count, digest, mode, report-to-guard binding, and indexed artifact.

## What the re-audit must establish

The prompt first checks the evidence chain in this order:

```text
live Git identity
→ canonical manifest
→ closeout report
→ report.guard_evidence
→ final guard
→ evidence index
→ all 94 indexed files
```

The canonical manifest and Git remain authoritative for patch identity. Provenance can establish that implementation, audit, staging, and commit refer to the same bytes, but it cannot prove architecture correctness, authority soundness, or test sufficiency. 

Only after that binding passes does the auditor review the three substantive repairs.

### Accept and latch atomicity

The audit independently requires:

```text
C2B accept decision
→ atomically commits the latch postimage

later terminal-outcome accept
→ binds decision ref/digest
→ binds that exact latch postimage
→ does not mutate the latch
```

It attacks delayed latch consumption, outcome-owned latch mutation, a second latch mutation, incorrect postimage binding, and unresolved outcome being treated as permission for successor, Git, or publication.

### Stale pre-effect cancel basis

The auditor verifies that a stale or incompatible cancel decision produces:

```text
no cancel effect
no new fence
no delivery
no request or signal
no replacement cancel decision
no C2B block decision
no replacement lineage

RW0 terminal-outcome = block
```

That `block` must bind the exact unusable cancel decision and mismatch evidence. A later successor outside RW0 may replan; the current RW0 run cannot absorb the drift.

### Complete four-document Markdown oracle

For each of the four cross-reference documents, the auditor independently reconstructs a **complete four-document map**, mutates one document, retains the other three exact, and invokes the complete authoritative oracle.

That covers:

- visible empty blocks with hidden real bodies;
- fenced-only content;
- visible prose before or after markers;
- split or reversed markers;
- historical and same-title relocation;
- duplicate visible blocks;
- one mismatched body;
- hidden-duplicate positive controls.

The earlier audit chain demonstrated why green tests alone were insufficient: exact provenance and green validation coexisted with a C2B decision conflict and a causality gap in the checked-in Markdown mutants. 

## Validation expected from the fresh auditor

```text
Direct RW0-A:             28/28
Architecture:             30/30
Remote-worker planning:  774/774
Protected C2B3C:          46/46
Focused regression:    1,565/1,565
Candidate collection:  4,284
Clean HEAD collection: 4,256
Candidate-only nodes:      28
Full suite:            4,284/4,284
```

The candidate node-list digest remains expected as:

```text
7fb16833d1fcf8916f62ad17b0238b87b8cda8bb03432039771290bc713d12e8
```

The audit prompt also preserves the prior finding matrix: authority-basis binding, one author lineage, effect-delivery separation, C2B decision versus terminal-outcome distinction, post-teardown reconciliation, supervisor/worker fact ownership, direct-local versus ES authority, terminal inventories, live Markdown ownership, and C2B3C extension compatibility.

## Next action

Start a **new read-only Codex conversation** and send:

:chatgpt-content-reference{index="3"}

A successful audit must return:

```text
ACCEPT

COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FREEZE_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Only after that result should the lifecycle advance:

```text
fresh independent ACCEPT
→ reproduce the accepted canonical manifest
→ stage exactly the ten audited paths
→ compare staged blobs, sizes, and Git modes
→ run final validation without changing bytes
→ create one feature-branch commit
→ compare committed blobs with the accepted manifest
→ push the feature branch
→ open the PR to trunk_dev
→ later squash-merge and verify the merged tree
```

Any new byte change returns the work to implementation and another independent audit; a previous audit cannot remain binding after repair.  The commit or publication gate begins only after an independent `ACCEPT`. 

### Sources

- Codex implementation closeout supplied in this turn.
- Previous independent audit’s C2B-decision and Markdown-causality blockers. 
- Independent-audit and repair lifecycle. 
- Provenance scope and confidence boundaries. 

**Confidence:** 99% that the candidate is ready for fresh independent re-audit; 98% that the evidence closeout now eliminates the prior loose-guard provenance failure; 97% that the audit prompt is broad enough to detect any remaining contract or test-oracle defect before publication.
