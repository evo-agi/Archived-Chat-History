TITLE

Coordinator RW0-A — repair cancellation reconciliation, immutable
authorization-basis binding, final-decision cardinality, and live Markdown
region oracles after the second independent audit

ENGAGEMENT TYPE

Bounded parent-only repair in the existing workspace-write implementation
conversation for:

COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1
RW0-A-PHASE-ENTRY-CONTRACT-FREEZE

Do not create or resume subagents. You are the sole repository writer.

The second fresh independent audit returned BLOCK against the exact ten-path
candidate.

It accepted:

- exact opening and closing provenance;
- the exact eight-entry first-audit repair delta;
- current nonimplementation and fail-closed runtime boundaries;
- one author delivery versus distinct later current-effect deliveries;
- existing-fence reuse at a high level;
- supervisor/worker fact ownership;
- direct-local versus ES route ownership;
- legal-indentation terminal inventory closure;
- the original hidden-marker/fenced-body cases;
- C2B and C2B3C protected bytes;
- source/schema/migration/public-surface non-change;
- all independently executed targeted and focused validation.

It found exactly six remaining repairable defects:

1. RW0-A-CANCEL-01 — the active-cancellation sequence omits an explicit
   post-teardown source-reconciliation fact before final `cancel` or unresolved
   `block`.

2. RW0-A-MD-01 — the sole-owner and four-cross-reference extractors accept
   contradictory visible prose outside the END marker but still inside the
   same live Markdown owner range.

3. RW0-A-AUTH-01 — existing immutable fence-bound externally authored
   authorization refs/digests are not related precisely enough to the future
   Coordinator-derived narrower subordinate authorization record.

4. RW0-A-TEST-01 — the direct oracle accepts a mutant permitting a replacement
   semantic attempt, second author effect, and second candidate-authoring
   invocation.

5. RW0-A-MD-02 — the current empty-owner mutant removes the visible marker pair
   and therefore does not prove rejection of one visible empty block plus a
   hidden real body.

6. RW0-A-DECISION-01 — “one Coordinator semantic decision” is ambiguous because
   an active-cancellation branch may contain one earlier immutable
   cancellation-control decision/intent plus one later final terminal outcome.

This turn authorizes correction of those findings only, followed by fresh
validation and provenance.

This turn does not authorize:

- any source/runtime/schema/migration/catalog/application-generation/package/
  public-protocol/StateStore/WriterSession change;
- implementation of parent-grant verification, subordinate authorization,
  custody, transport, process launch, worker, Codex, capsule storage,
  validation/review/model execution, semantic-decision runtime, acceptance
  latch, Git, ES routing, service, queue, scheduler, or autonomous loop;
- mutation of Execution Substrate, Infrastructure Manager, or any other
  repository;
- staging, commit, push, PR creation, merge, tag, release, or deployment;
- fetch, pull, remote contact, network access, model/provider invocation, Codex
  invocation, process/worker launch, SSH, live service, or live database
  contact;
- reset, clean, revert, branch switch, discard, or history rewrite.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OPENING BASELINE AND TARGET GATE

Require exactly before mutation:

- Physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- HEAD tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- HEAD subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1
- Dirty paths:
  exactly 10
- Tracked modifications:
  exactly 8
- Untracked paths:
  exactly 2
- Staged/unmerged:
  0/0
- No deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  or Git lock
- Repository residue:
  empty
- `git diff --check HEAD --`:
  clean.

Require the exact ten-path set:

.docs/rw0-remote-worker-contact-phase-entry.md
.docs/c2b-durable-development-state.md
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_architecture_contracts.py
tests/test_c2b3c_author_effect_contract.py

Require mode posture:

- these nine paths are regular working-tree mode `0644`:

  .docs/rw0-remote-worker-contact-phase-entry.md
  .docs/c2b-durable-development-state.md
  .docs/autonomous-software-development-operating-model.md
  .docs/worker-execution-boundary.md
  .docs/authority-boundaries.md
  .docs/durable-state-model.md
  tests/test_rw0_remote_contact_phase_entry_contract.py
  tests/test_remote_worker_pre_execution_planning_contract.py
  tests/test_architecture_contracts.py

- this path is regular working-tree mode `0600`, current-operator-owned, with no
  execute bits:

  tests/test_c2b3c_author_effect_contract.py

- Git index mode for every tracked candidate path is `100644`;
- no Git-recorded mode change exists.

Do not chmod any path. Do not widen the local `0600` permission.

AUTHORITATIVE OPENING TARGET

Use exactly:

/private/tmp/ge-rw0a-audit-repair.jmT10j/final-manifest-immutable.json

Require:

- every path component lstat-safe and non-symlink;
- evidence root operator-owned, non-symlink, mode 0700;
- manifest regular and safely readable;
- size:
  2,328 bytes;
- SHA-256:
  29044da643bf1300aec209fbf7df5d1b7fed2d79bf076b08931562ce6b47ab63.

Copy the safely verified bytes into one new repair-created external,
operator-owned, non-symlink, mode-0700 evidence root as an immutable mode-0400
opening target.

Parse and require:

- recipe_id:
  governed-execution.audit-patch-manifest.v1
- branch:
  codex/rw0-phase-entry-contract-freeze
- head:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- exactly ten entries;
- exactly eight `tracked_modified`;
- exactly two `untracked`;
- expected working-tree modes above;
- no deletion, missing path, symlink, or unsupported type.

Run the exact provenance recipe below twice before editing and require exact
byte equality with the immutable target.

Expected opening provenance:

- Recipe source:
  3,945 bytes
- Recipe SHA-256:
  db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
- Complete stdout:
  2,561 bytes
- Complete-output SHA-256:
  24071f487f4e9a61a92e3871ae43ef8de228f986941bf67c6ea139ca7d1addb6
- Stderr:
  0 bytes
- Tracked textual-diff SHA-256:
  a5972c454f89bd17da1f3aba3f5d7fa44914fe2fd63f9cea9ea893928d162dac
- Canonical manifest:
  2,328 bytes
- Canonical-manifest SHA-256:
  29044da643bf1300aec209fbf7df5d1b7fed2d79bf076b08931562ce6b47ab63
- File count:
  10

Stop without mutation and return:

COORDINATOR_RW0_A_SECOND_AUDIT_REPAIR_PROVENANCE_MISMATCH

on any mismatch. Do not reconstruct the target from the live tree, report, or
aggregate hashes.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

PRESERVED SECOND-AUDIT EVIDENCE

Safely inspect, but do not modify:

/private/tmp/ge-rw0a-independent-157o_6er

Use it only as predecessor evidence. Do not grant correctness credit merely
because records exist.

When present, inspect at least:

- `independent-mutants.json`;
- closing guards;
- direct, architecture, remote-worker, C2B3C, focused, and collection records;
- exact target and provenance records.

Require retained evidence to be consistent with the supplied audit report:

- three invalid mutants were accepted:
  - second author effect/replacement attempt;
  - visible contradictory prose after sole-owner END;
  - visible contradictory prose after cross-reference END;
- the current empty-visible-owner mutant does not preserve a visible empty
  marker block;
- current cancellation prose omits explicit reconciliation after teardown;
- current authority prose does not specify the new subordinate record’s exact
  relation to immutable fence-bound authorization refs/digests;
- full suite was not independently rerun because inspection was already
  non-green.

If the evidence root is unavailable or incomplete, continue from the supplied
audit report and current source inspection, but disclose the limitation. Do not
invent hashes or missing probe results.

MAXIMUM AUTHORIZED MUTATION

Documentation:

1. .docs/rw0-remote-worker-contact-phase-entry.md
2. .docs/autonomous-software-development-operating-model.md
3. .docs/worker-execution-boundary.md
4. .docs/authority-boundaries.md
5. .docs/durable-state-model.md

Tests:

6. tests/test_rw0_remote_contact_phase_entry_contract.py
7. tests/test_architecture_contracts.py
8. tests/test_remote_worker_pre_execution_planning_contract.py

No other path may change.

Protected exact candidate bytes:

- .docs/c2b-durable-development-state.md
- tests/test_c2b3c_author_effect_contract.py

The protected C2B document must retain exact size/hash/mode:

- 1,884,626 bytes
- SHA-256:
  5fd66a1266e63f8f026a27de7d84f42029813acdadc6b3ecb1978c3ff9ce9b1e
- mode:
  0644

The protected C2B3C test must retain exact size/hash/mode:

- 416,182 bytes
- SHA-256:
  935ca6fe7b18d39055d5cdc2c911302e7c0726304f3699472f3994a32f7b4778
- working-tree mode:
  0600
- Git index mode:
  100644

The final path set and topology must remain exactly ten paths, eight tracked
modifications, two untracked files, zero staged, and zero unmerged.

If an allowlisted architecture or remote-worker test does not require a byte
change, preserve it byte-identically and report that fact.

PARENT CONTRACT DECISIONS FOR THIS REPAIR

A. IMMUTABLE FENCE-BOUND AUTHORIZATION BASIS AND NEW SUBORDINATE RECORD

Freeze this exact relation without selecting a storage schema or encoding.

1. C2B3D has already persisted exact author attempt-fence and author
   effect-fence identities/digests. Each fence also binds its own exact
   externally authored authorization reference and digest.

2. Call each persisted fence pair its immutable external authorization-basis
   binding. The existing fence-bound authorization refs/digests are inert
   lineage and ceiling bindings. Their existence and digest validity are not
   executable permission.

3. The future Coordinator-derived narrower subordinate authorization is a
   separate record with its own identity and digest. It does not replace,
   rewrite, or become retroactively embedded in either existing fence.

4. For each applicable existing fence, the future subordinate record must bind
   the corresponding persisted authorization-basis reference and digest
   byte-for-byte.

5. The fresh external verifier must prove:
   - the current parent grant is valid, unexpired, unrevoked, and audience/
     repository/base/path/effect compatible;
   - the parent grant authorizes the exact immutable authorization-basis family
     referenced by the existing fences;
   - the attempt-fence and author-effect-fence authorization-basis bindings are
     jointly compatible with the same parent-grant family and exact K8/L34
     lineage;
   - the future subordinate record is a strict narrowing of that verified
     parent/basis relation;
   - the subordinate record binds the exact existing attempt/effect fence refs
     and digests;
   - all required global-stop and current-head relations are current.

6. Do not require the attempt-fence authorization pair and effect-fence
   authorization pair to be byte-equal to each other unless the unchanged C2A
   contract already requires that equality. Require their exact per-fence
   equality to the new record’s corresponding bindings and a verified common
   parent-grant-family compatibility relation.

7. If any per-fence equality, parent/basis ancestry relation, common-family
   compatibility, scope ceiling, freshness, revocation, expiry, repository,
   base, path, or global-stop relation is false, missing, stale, or ambiguous:
   - no subordinate authorization record is established;
   - no WorkSpec retrieval, contact, author delivery, or worker launch occurs;
   - no replacement attempt fence, effect fence, author effect, or author
     attempt is minted in RW0;
   - the current RW0 run terminates fail-closed as final `block`.

8. A later successor outside RW0 may replan and establish a different semantic
   attempt/effect lineage. RW0 itself never absorbs an incompatible
   authorization family.

9. For later validation, review, or active-cancellation effects:
   - the originating semantic attempt and applicable attempt-fence lineage stay
     exact;
   - each later effect has its own current effect intent, effect fence, and
     subordinate authorization binding;
   - each later binding must prove compatibility with the same verified parent
     grant family and its own exact applicable fence binding;
   - the author effect fence is never reused as a validation, review, or cancel
     effect fence.

10. Current executable authorization remains unsupported and fail-closed. RW0-A
    implements no verifier, subordinate record, fence, or runtime.

Use descriptive contract language. Do not invent a versioned public class,
table, field name, row type, migration, or wire schema in RW0-A.

B. ACTIVE-CANCELLATION SEQUENCE WITH POST-TEARDOWN RECONCILIATION

Freeze this exact branch:

1. Coordinator commits at most one early immutable cancellation-control
   decision/intent. It is not the final terminal outcome.
2. Coordinator establishes the distinct `cancel_effect`, its current effect
   fence, subordinate authorization binding, and initial cancellation delivery.
3. Cancellation request is emitted.
4. Acknowledgement is observed or remains absent/unknown.
5. OS signal delivery is observed or remains absent/unknown.
6. Process exit is observed or remains absent/unknown.
7. Mutable workspace teardown is observed or remains absent/unknown.
8. Source-native reconciliation runs after teardown over:
   - process-group and descendant state;
   - worker observations;
   - cancellation request/ack/signal/exit facts;
   - workspace cleanup state;
   - capsule/custody terminal state;
   - applicable delivery and source receipts.
9. Only after reconciliation proves every required terminal relation complete
   and non-ambiguous may Coordinator commit the one final terminal semantic
   outcome `cancel`.
10. If reconciliation is incomplete, contradictory, stale, or ambiguous,
    Coordinator commits the one final terminal semantic outcome `block`, not
    `cancel`.
11. None of the facts above implies the next.
12. No successor launches and no Git/publication follows.

The source-reconciliation fact must be explicit in the canonical sequence and
the failure/recovery table.

C. COORDINATOR DECISION CARDINALITY

Replace ambiguous “one Coordinator semantic decision” wording with:

- exactly one final RW0 semantic outcome decision from:
  `accept`, `repair`, `replan`, `terminal_reject`, `block`, `cancel`;
- on the active-cancellation branch only, at most one earlier immutable
  cancellation-control decision/intent may additionally exist;
- the early cancellation-control decision is not the final semantic outcome,
  does not terminate RW0, does not consume the acceptance latch, and does not
  count as a second final outcome;
- normal/non-cancel branches contain no early cancellation-control decision;
- no other Coordinator progression decision is created in RW0.

D. NO SECOND AUTHOR LINEAGE OR INVOCATION

Independently freeze and test:

- exactly the existing C2B3D semantic attempt;
- exactly the existing author effect intent;
- exactly the existing author command;
- exactly the existing author candidate;
- exactly the existing initial author delivery identity;
- at most one actual author-candidate delivery;
- at most one candidate-authoring worker/source invocation;
- no replacement or second author attempt;
- no replacement or second author effect;
- no second candidate-authoring invocation;
- no author relaunch or author redelivery;
- no replacement author candidate.

Later validation/review/cancel effects remain distinct current effects under the
same originating semantic attempt and do not count as additional author
attempts, author effects, or author invocations.

E. COMPLETE LIVE MARKDOWN REGION OWNERSHIP

For the sole owner and each of the four cross-reference blocks:

1. Determine one unique visible Markdown owner range through fence-aware ATX
   events, unique parent/owner identity, predecessor adjacency, and next
   same-or-higher-level range termination.

2. The owner heading itself may lie outside the marker pair.

3. Inside the owner range, every visible nonblank Markdown body byte after the
   heading must lie inside the one visible BEGIN/END marker pair.

4. Before BEGIN and after END, permit only:
   - blank lines; and
   - hidden HTML comments that contain no visible Markdown body.

5. Reject visible prose, list items, headings, blockquotes, code, or other
   visible content before BEGIN or after END inside the same owner range,
   including text that contradicts or widens the marked contract.

6. Content inside an active supported backtick or tilde fence is hidden and
   cannot establish the live owner body.

7. One correct visible block plus irrelevant hidden duplicate bytes is
   accepted.

8. Two visible blocks, two visible owners, split/reversed markers, hidden-only
   body, historical relocation, same-title sibling/ancestor relocation, or
   visible trailing/leading prose outside the pair is rejected.

9. Raw marker/body count, `find`, `index`, split, or regex may be diagnostic
   only after the visible structural span is established.

F. EXACT EMPTY-VISIBLE-BLOCK MUTANT

Add the exact causal mutant the audit found missing:

- retain the intended visible owner heading;
- retain one visible BEGIN marker;
- retain one visible END marker;
- leave the visible marker body empty except for blank lines;
- place a byte-exact otherwise-valid real body inside a balanced backtick fence
  or tilde fence elsewhere in the same structural owner range;
- retain raw body bytes and raw markers so a broken raw extractor can find
  them.

The authoritative visible-region oracle must reject this mutant because the
one visible block is empty and the real body is hidden.

A deliberately broken raw-body checker must accept the same bytes. It must
never be used as the positive oracle.

DOCUMENT REPAIR REQUIREMENTS

SOLE OWNER DOCUMENT

Update only the affected regions in:

.docs/rw0-remote-worker-contact-phase-entry.md

Correct:

- immutable external authorization-basis/subordinate-record relationship;
- fail-closed incompatible-family behavior;
- active-cancellation sequence with post-teardown reconciliation;
- final-outcome versus early cancellation-control decision cardinality;
- explicit no-second-author-attempt/effect/invocation ceiling.

Preserve:

- sole detailed ownership;
- accepted-target/nonimplementation classification;
- exact K8/L34 lineage;
- raw WorkSpec privacy;
- one qualified remote Linux host/no fallback/no third adapter;
- author versus later current-effect delivery distinction;
- supervisor/worker fact ownership;
- direct-local/ES/IM split;
- terminal-outcome domain;
- no Git/publication;
- every deferred implementation seam;
- no selected table, schema, migration, public API, wire format, or backend.

FOUR CROSS-REFERENCES

Inspect the bounded blocks in exactly:

.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md

If an existing compact sentence repeats an affected ambiguous statement, update
all four bodies identically.

The normalized bodies must remain byte-for-byte identical after whitespace
normalization.

At minimum their compact meaning must remain:

- sole detailed owner path;
- current runtime still absent and fail-closed;
- external parent grant plus future Coordinator-derived narrower subordinate
  record;
- existing per-fence external authorization-basis bindings remain immutable and
  must be exactly bound/verified, never replaced;
- exactly one author lineage/invocation/delivery, with distinct later current
  effects only if reached;
- no relaunch/redelivery;
- one final semantic outcome, with at most one separate early
  cancellation-control decision on the active-cancel branch;
- no fallback, third adapter, Git, or publication;
- direct-local does not absorb ES-route authority;
- physical custody, transport, framing, Codex, schema, latch, and backend
  choices remain deferred.

Do not duplicate the detailed matrices.

TEST-ORACLE REPAIRS

GENERAL MARKDOWN MODEL

In every changed test file that validates RW0 Markdown ownership:

- use one bounded fence-aware structural model local to that file;
- recognize visible ATX headings with 0–3 ASCII-space indentation;
- hide headings/markers/body inside active backtick or tilde fences;
- bind one unique parent/owner range through stable adjacent structural events;
- require all visible owner-range body content to be enclosed by the visible
  marker pair;
- accept blank lines and hidden comments outside the pair;
- reject visible leading/trailing body outside the pair;
- accept irrelevant hidden duplicate bytes;
- reject duplicate visible owners/blocks;
- do not dynamically import another test module;
- do not let raw counts or text search determine liveness.

Do not add a new exact diagnostic requirement unless an existing test contract
already owns one. Require causal rejection and region attribution, not an
incidental message string.

SOLE OWNER AND CROSS-REFERENCE TRAILING-PROSE MUTANTS

In `tests/test_rw0_remote_contact_phase_entry_contract.py` and any existing
architecture/remote-worker test that owns the same structural claim, add
in-memory mutants without adding test nodes:

1. append visible contradictory prose after the sole-owner END marker but before
   its owner-range terminator — reject;

2. insert visible contradictory prose before the sole-owner BEGIN marker but
   after its heading — reject;

3. for every cross-reference spec, append visible contradictory prose after END
   inside the exact owner range — reject;

4. for at least one representative spec and any shared complete oracle, insert
   visible contradictory prose before BEGIN — reject;

5. accept the exact live document and one visible block plus hidden duplicate;

6. retain fenced-only, split/reversed, same-title relocation, historical
   relocation, and duplicate-visible controls.

The contradictory text must be semantically meaningful, for example:

`This region authorizes a second author attempt and immediate worker launch.`

Do not use a comment-only mutation.

AUTHORIZATION-BASIS MUTANTS

Strengthen existing direct-test nodes without adding or parameterizing nodes.

Independently reject:

- subordinate record substitutes a different authorization-basis ref for the
  existing attempt fence;
- subordinate record substitutes a different authorization-basis digest for the
  existing author effect fence;
- existing fences are rewritten to point at the new subordinate record;
- parent grant is current but has no verified ancestry/authorization relation to
  the fence-bound basis family;
- attempt/effect fence basis pairs are accepted as one common family without a
  current verifier result;
- an incompatible or ambiguous family causes retrieval/launch rather than
  terminal `block`;
- replacement attempt/effect fences are minted to absorb a mismatch;
- later validation/review/cancel reuses the author effect fence;
- the subordinate record is treated as externally authored;
- Coordinator is treated as parent-grant issuer;
- existing fence possession alone is permission.

Positive control:

- existing per-fence basis refs/digests remain exact;
- current verifier proves both per-fence equality bindings and their common
  parent-grant-family compatibility;
- Coordinator derives a separate narrower subordinate record bound to exact
  existing fence refs/digests;
- no existing fence bytes are changed;
- runtime remains target-only and unimplemented.

SECOND-AUTHOR MUTANTS

Independently mutate only the bounded scenario/identity region to permit:

- a replacement semantic attempt;
- a second author effect;
- a second author command;
- a second author candidate;
- a second candidate-authoring invocation;
- an author relaunch;
- an author redelivery.

Require every mutant to fail even when all later validation/review/cancel effect
statements remain correct.

Do not let one broad “one candidate” string satisfy the attempt/effect/invocation
requirements. Require the distinct prohibitions independently.

CANCELLATION AND DECISION-CARDINALITY MUTANTS

Independently reject:

- terminal `cancel` immediately after workspace teardown with no explicit source
  reconciliation;
- reconciliation before teardown;
- final `cancel` on ambiguous reconciliation;
- omission of the `block` result for unresolved reconciliation;
- early cancellation-control decision counted as the final semantic outcome;
- two final semantic outcomes;
- normal branch containing an early cancellation-control decision;
- early decision consuming the acceptance latch;
- source reconciliation implying terminal cancel without Coordinator commit.

Require the exact positive active-cancel sequence and one-final-outcome
cardinality.

EXACT EMPTY-VISIBLE-BLOCK MUTANT

Replace or supplement the inadequate prior mutant so it keeps:

- visible owner heading;
- visible BEGIN and END;
- visible empty body;
- hidden valid real body.

Require the complete authoritative oracle to reject it. Require a deliberately
broken raw extractor to accept it.

TEST-NODE BOUNDARY

Before editing, collect exactly once under isolated posture:

- complete repository:
  exactly 4,284 nodes;
- direct RW0-A file:
  exactly 28 nodes;
- architecture file:
  exactly 30 nodes;
- remote-worker file:
  exactly 774 nodes;
- C2B3C file:
  exactly 46 nodes.

Retain literal ordered lists.

Do not add, remove, rename, skip, xfail, decorate, parameterize, collapse, or
weaken any test node.

Final ordered lists must be byte-identical to opening lists.

CAUSAL RED PHASE

Before changing documentation:

1. strengthen only the authorized test helpers/mutants;
2. keep all documentation at the exact opening target;
3. use bounded external in-memory diagnostics as needed to ensure each mutant
   actually targets the intended region; diagnostic calibration may be repeated
   but must not modify repository bytes;
4. run one formal causal-red pytest gate over the changed test files exactly
   once;
5. require non-green results causally demonstrating:
   - missing post-teardown reconciliation;
   - ambiguous one-decision wording;
   - unspecified authorization-basis equality/family relation;
   - accepted second-author lineage/invocation;
   - accepted visible trailing prose outside owner/cross-reference markers;
   - accepted visible empty block with hidden real body;
6. require no unrelated collection/import/setup error.

An expected causal-red failure is not a stop condition. Proceed only when every
finding class is reproduced and retained.

Then repair documentation and finalize helpers. Do not rerun the formal red gate
on predecessor bytes.

VALIDATION ISOLATION

Use one new external, operator-owned, non-symlink, mode-0700 repair root.

For every pytest child:

- save actual caller umask;
- create evidence under secure posture;
- restore caller umask before launch;
- record child-observed umask and require numerical equality;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`
  - `LC_ALL=C`
  - `LANG=C`
  - `PYTHONDONTWRITEBYTECODE=1`
  - distinct external `PYTHONPYCACHEPREFIX`
  - distinct external `TMPDIR`
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
  - `PYTEST_ADDOPTS=''`
  - `PYTHONHASHSEED=0`
  - `python3 -B -m pytest`
  - `-p no:cacheprovider`
  - `-W error`
  - distinct external `--basetemp`
  - external `--junitxml`
  - serial execution.

Retain exact argv, effective environment, caller/child umask, return code,
elapsed time, stdout/stderr/JUnit sizes and SHA-256, parsed counts, warnings,
parse errors, unmapped cases, and before/after target identity.

FINAL TARGETED GREEN GATES

Run exactly once each on frozen final bytes:

1. Direct RW0-A:

   tests/test_rw0_remote_contact_phase_entry_contract.py

   Require exactly 28/28 green.

2. Architecture:

   tests/test_architecture_contracts.py

   Require exactly 30/30 green.

3. Remote-worker planning:

   tests/test_remote_worker_pre_execution_planning_contract.py

   Require exactly 774/774 green.

4. Protected C2B3C:

   tests/test_c2b3c_author_effect_contract.py

   Require exactly 46/46 green.

COMPLETE RW0-A FOCUSED REGRESSION

Run exactly:

tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_software_development_progression_boundary.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_worker_execution_semantic_boundaries.py

Require exactly 1,565/1,565 green.

If any named file is absent, stop rather than substituting.

FINAL NODE COLLECTION

After targeted/focused validation and cleanup:

- collect the complete repository exactly once;
- require exactly 4,284 nodes;
- require literal equality with the opening candidate list;
- require direct test remains 28;
- architecture remains 30;
- remote-worker remains 774;
- C2B3C remains 46;
- require no added, removed, renamed, skipped, xfailed, collapsed, or
  re-parameterized node.

FULL SUITE — EXACTLY ONCE

Only after all targeted/focused gates, node identity, path boundary, and
artifact cleanup are green, run exactly once:

python3 -B -m pytest -p no:cacheprovider -W error \
  --basetemp=<external> \
  --junitxml=<external> \
  .

Require exactly:

- 4,284 collected;
- 4,284 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository bytes, topology, modes, and node identity unchanged before/after.

Do not run a second full-suite attempt.

FINAL CONTRACT AND PATH GUARDS

Require:

- exact ten-path candidate set;
- exactly eight tracked modifications and two untracked files;
- zero staged/unmerged paths;
- expected working-tree modes, including C2B3C `0600`;
- Git index mode `100644` for every tracked path;
- no Git-recorded mode change;
- no path outside the ten-path target changed;
- `.docs/c2b-durable-development-state.md` byte-identical to the opening target;
- `tests/test_c2b3c_author_effect_contract.py` byte-identical to the opening
  target;
- one sole detailed owner;
- four normalized-identical bounded cross-reference bodies;
- all visible owner-range body content enclosed by markers;
- no visible leading/trailing prose outside markers;
- exact external-basis/subordinate-record relation and fail-closed mismatch;
- no replacement author attempt/effect/command/candidate/invocation;
- exact active-cancel sequence including post-teardown source reconciliation;
- exactly one final semantic outcome and at most one separate early
  cancellation-control decision on the active-cancel branch;
- no current implementation overclaim;
- no enduring fixture, custodian, SSH/framing, Codex, schema, latch,
  capsule-backend, validator/reviewer/model-adapter, or ES reliable-submit
  implementation choice added;
- no source, SQL, migration, catalog, schema, application-generation, package,
  public protocol, StateStore, WriterSession, runtime, fixture, script, config,
  or supporting-repository diff;
- `git diff --check` clean;
- no repository cache, bytecode, pytest cache, database, journal, WAL/SHM,
  build output, archive, generated manifest, or OS metadata;
- no Git operation or lock;
- no remote contact or runtime effect.

FINAL PROVENANCE

After final validation and cleanup, run the exact unchanged provenance recipe
twice.

Require:

- both return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- exactly ten entries;
- exactly eight `tracked_modified`;
- exactly two `untracked`;
- expected working-tree modes;
- no deletion, rename, symlink, Git-recorded mode change, or unsupported type.

Compare final manifest with the immutable opening target and report:

- every changed entry, opening/final size and SHA-256;
- every byte-identical protected entry;
- exact path classifications and modes;
- recipe source size/hash;
- complete-output size/hash;
- tracked textual-diff hash;
- canonical-manifest size/hash;
- causal-red evidence;
- targeted/focused/collection/full-suite evidence paths and hashes;
- current/target/deferred classification guard;
- no-effect/no-network/no-supporting-repo evidence.

Do not stage. The final working-tree manifest is the future independent-audit
target.

STOP CONDITIONS

Stop without further mutation if:

- opening identity, target, path set, mode posture, or node count differs;
- the findings cannot be closed inside the eight-path maximum mutation
  allowlist;
- `.docs/c2b-durable-development-state.md` or the C2B3C test must change;
- any source/schema/migration/public/runtime change appears necessary;
- current C2A/C2B3D contracts contradict the per-fence external-basis relation
  above;
- the parent-grant/basis/subordinate relation cannot be stated without inventing
  a storage schema or rewriting existing fence identities;
- the active-cancellation branch cannot distinguish early control decision,
  post-teardown reconciliation, and final outcome;
- a causal predecessor defect cannot be reproduced;
- an existing test node must change;
- targeted, focused, collection, or full-suite validation is not exact-green;
- another path changes;
- final provenance is unstable;
- remote contact, staging, publication, worker/model/process activity, or
  supporting-repository mutation would be required.

On stop, preserve exact state and evidence. Do not reset, clean, revert, switch
branches, stage, or discard work.

CLOSEOUT

Return exactly:

COORDINATOR_RW0_T1_SECOND_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

only if:

- RW0-A-CANCEL-01, RW0-A-MD-01, RW0-A-AUTH-01, RW0-A-TEST-01,
  RW0-A-MD-02, and RW0-A-DECISION-01 are causally and contractually closed;
- existing fence identities and authorization-basis bindings remain exact and
  non-authorizing;
- no incompatible authorization family can be absorbed inside RW0;
- no replacement author lineage or invocation is permitted;
- post-teardown reconciliation precedes final cancel/block;
- exactly one final semantic outcome is distinguished from any early
  cancellation-control decision;
- all visible owner-range prose is marker-owned;
- validation is exact-green;
- node identity is unchanged;
- final ten-path provenance is stable;
- no source/runtime/remote/staging/publication effect occurred.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
