## Verdict

**Codex stopped correctly. This is a narrow test-oracle defect, not a problem with the RW0-A contract or documentation.**

The authoritative document intentionally contains two terminal-outcome inventories:

1. The bounded RW0 scenario says every run ends with one of the six outcomes.
2. The later decision section defines the same exact Coordinator decision domain.

The failing mutant changed only the first inventory. The validator still passed because it searched the whole document and found the unchanged second inventory. Simply changing the mutant to replace both inventories would make the test green while preserving the defective global oracle. The correct repair is to make **each structurally owned inventory independently mandatory**.

The six terminal decisions and the rule that every outcome ends RW0 are part of the frozen reconnaissance target; no successor is launched and no Git or publication effect follows. 

## Repair boundary

Exactly one file may change:

```text
tests/test_rw0_remote_contact_phase_entry_contract.py
```

All six documentation files and the two existing modified tests remain byte-pinned. The stopped candidate remains:

```text
Branch:              codex/rw0-phase-entry-contract-freeze
HEAD:                1a894c5527c610ab40d8e5ae5e530a762c6e60bf
Dirty paths:         9
Tracked modified:    7
Untracked:           2
Staged/unmerged:     0/0
```

The retained `27 passed, 1 failed` run becomes the causal predecessor-red evidence. It should **not** be rerun on the old bytes.

The repaired oracle must independently bind:

```text
Bounded RW0 scenario class
    → accept, repair, replan, terminal_reject, block, cancel

Capsule, validation, review, model, and decision
    → accept, repair, replan, terminal_reject, block, cancel
```

Each region must fail independently when its own inventory is incomplete, reordered, extended, fenced, or relocated—even when the other region remains perfect.

The prompt also requires a deliberately broken whole-document checker that accepts the predecessor mutant while the final region-scoped checker rejects the same bytes. That prevents the test from becoming green for an unrelated reason.

## Fresh validation sequence

After the one-file repair:

```text
direct RW0-A oracle:       28/28
focused regression:        all collected passed
complete node collection:  4,284, unchanged
complete suite:            4,284/4,284
```

No existing node may change. The 28 new RW0-A nodes remain exactly the same.

The final manifest must still contain nine paths. Relative to the stopped-state manifest:

- exactly the untracked direct test may differ;
- the other eight entries must be byte-identical;
- the tracked diff digest must remain unchanged, because only an untracked file is repaired;
- the canonical manifest digest must change, because that untracked file’s bytes change.

This follows the established repair lifecycle: the implementation parent performs the bounded repair and produces new validation and provenance; changed bytes then require a fresh independent audit.  Provenance binds the implementation and later auditor to the same bytes but does not itself establish test sufficiency. 

## Next action

Resume the **same workspace-write Codex conversation** and send:

:chatgpt-content-reference{index="3"}

A successful closeout should return:

```text
COORDINATOR_RW0_T1_TERMINAL_OUTCOME_ORACLE_REPAIRED_READY_FOR_INDEPENDENT_AUDIT
```

Then proceed with:

```text
one-file test repair
→ exact-green validation
→ new nine-path provenance
→ fresh read-only independent audit
→ ACCEPT
→ feature-branch commit and PR gate
```

Do not reopen the authority model, WorkSpec custody boundary, transport deferrals, proof-fixture classification, or any RW0 documentation during this repair.

### Sources

- RW0 reconnaissance baseline, current-state boundary, and bounded terminal behavior. 
- Repair and fresh-audit protocol after changed bytes. 
- Provenance purpose and limitations. 

**Confidence:** 99% that the stop was correct; 99% that the repair is confined to the new direct test file; 98% that independent region-scoped inventories close the demonstrated defect without changing the RW0-A contract.
