TITLE

Coordinator RW0-A phase-entry contract freeze — fresh independent re-audit
after the second-audit findings repair

ENGAGEMENT TYPE

Fresh-conversation independent audit.

Run this in a new Codex conversation with read-only repository posture.

Do not resume or use the implementation or either preceding audit conversation
as this audit conversation. Their reports and retained evidence are inputs
only.

Repository mutation is not authorized. Do not edit, format, create, delete,
rename, chmod, clean repository paths, switch branches, stage, commit, amend,
push, create or update a PR, merge, rebase, reset, tag, release, deploy,
install dependencies, run live migrations, invoke a model/provider or Codex,
launch a worker/process, contact a host, Bridge, Execution Substrate,
Infrastructure Manager, or any remote.

Temporary audit output is authorized only beneath one audit-created,
operator-owned, non-symlink, mode-0700 external root. Do not write audit output
inside the repository. Remove only audit-created external artifacts when safe.
Do not delete, overwrite, or normalize implementation evidence.

If any repository byte, local permission, path, index entry, branch, Git
operation state, or topology changes, stop and report it. Do not silently
restore or clean it.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

WORKSTREAM

COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1

TRANCHE

RW0-A-PHASE-ENTRY-CONTRACT-FREEZE

PRIMARY OBJECTIVE

Independently re-audit the exact final ten-path RW0-A candidate after the
parent-only repair of the second independent audit’s six findings:

- RW0-A-CANCEL-01 — post-teardown source reconciliation was absent from the
  canonical active-cancellation sequence;
- RW0-A-MD-01 — sole-owner and cross-reference oracles accepted contradictory
  visible prose outside their marker pairs but inside their live owner ranges;
- RW0-A-AUTH-01 — the future narrower subordinate authorization record was not
  related precisely enough to immutable fence-bound external authorization
  basis refs/digests;
- RW0-A-TEST-01 — the direct oracle accepted a replacement semantic attempt,
  second author effect, and second candidate-authoring invocation;
- RW0-A-MD-02 — the empty-owner mutant did not retain a visible empty
  BEGIN/END block plus a hidden real body;
- RW0-A-DECISION-01 — “one Coordinator semantic decision” was ambiguous beside
  one earlier immutable cancellation-control decision/intent.

The implementation reports that:

- post-teardown source-native reconciliation now precedes final terminal
  `cancel` or unresolved `block`;
- exactly one final RW0 semantic outcome is distinguished from at most one
  earlier cancellation-control decision/intent on the active-cancel branch;
- each persisted author attempt/effect fence retains its immutable external
  authorization-basis ref/digest;
- a future Coordinator-derived narrower subordinate authorization is a
  separate record that binds those exact existing fence and basis identities
  without rewriting the fences;
- a current verifier must prove per-fence equality bindings, common compatible
  parent-grant family, strict narrowing, freshness, scope, revocation, expiry,
  repository/base/path, current-head, and global-stop relations;
- an incompatible, stale, missing, or ambiguous family produces no retrieval,
  contact, launch, replacement fence, replacement attempt/effect, or author
  invocation, and terminates RW0 as `block`;
- RW0 is limited to the existing author semantic attempt, effect, command,
  candidate, initial delivery identity, one actual author delivery, and one
  candidate-authoring invocation;
- sole-owner and four-cross-reference marker pairs now enclose all visible body
  content in their exact live owner ranges;
- visible leading/trailing prose outside a marker pair is rejected;
- an exact visible empty block with a hidden otherwise-valid body is rejected;
- direct, architecture, remote-worker, protected C2B3C, focused, collection,
  and full-suite gates are exact-green;
- all 4,284 candidate node IDs remain byte-identical to the opening candidate;
- the ten-path topology and protected C2B/C2B3C bytes remain exact;
- no source, schema, migration, runtime, public API, worker, model, network,
  supporting-repository, staging, or publication effect occurred.

Do not trust those claims as correctness evidence.

First bind this audit to the exact final manifest through the hash-pinned final
evidence summary. Then inspect the entire ten-path candidate and independently
reproduce every first- and second-audit finding class relevant to the changed
bytes.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Do not repair findings.

CURRENT COMMITTED BASELINE

Require and verify:

- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- HEAD tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- HEAD subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1

CURRENT IMPLEMENTATION BOUNDARY

Verify from the committed baseline and unchanged source that current capability
still stops at:

- internal C2A pure values and validators;
- private readers;
- guarded writer/transaction authority;
- private VS1B genesis;
- private C2B3D author-effect establishment with inert planned
  `direct_local_bootstrap` author delivery;
- private Section 41 pre-execution proposal selection;
- application generation 2 and migrations through 0003.

Verify that current capability still does not implement:

- executable parent-grant verification or subordinate authorization derivation;
- WorkSpec physical custody or bearer retrieval;
- direct-local adapter, supervisor, worker, Codex invocation, or process launch;
- dispatcher, queue, service, IPC, outbox/inbox, or reconciler;
- capsule builder/store/retrieval;
- validation, independent review, model invocation/proposal runtime, or
  post-execution semantic-decision runtime;
- cancellation delivery/acknowledgement/runtime reconciliation;
- productive-direct-local acceptance latch;
- Git effect;
- Bridge or ES handoff;
- publication or autonomous loop.

EXPECTED OPENING REPOSITORY IDENTITY

Require exactly before correctness inspection:

- Physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- Subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1
- Dirty paths:
  exactly 10
- Tracked modifications:
  exactly 8
- Untracked:
  exactly 2
- Staged/unmerged:
  0/0
- No deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  or Git lock
- Repository residue:
  empty
- `git diff --check HEAD --`:
  clean.

Expected path classifications:

Tracked modifications:

.docs/c2b-durable-development-state.md
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_architecture_contracts.py
tests/test_c2b3c_author_effect_contract.py

Untracked:

.docs/rw0-remote-worker-contact-phase-entry.md
tests/test_rw0_remote_contact_phase_entry_contract.py

Expected local mode posture:

- these nine paths are regular working-tree mode `0644`:

  .docs/rw0-remote-worker-contact-phase-entry.md
  .docs/c2b-durable-development-state.md
  .docs/autonomous-software-development-operating-model.md
  .docs/worker-execution-boundary.md
  .docs/authority-boundaries.md
  .docs/durable-state-model.md
  tests/test_rw0_remote_contact_phase_entry_contract.py
  tests/test_remote_worker_pre_execution_planning_contract.py
  tests/test_architecture_contracts.py

- this path is regular working-tree mode `0600`, current-operator-owned, with no
  execute bits:

  tests/test_c2b3c_author_effect_contract.py

- Git index mode for every tracked candidate path is `100644`;
- no Git-recorded mode change exists.

The local `0600` mode is a restrictive working-tree metadata overlay. Do not
chmod it. It is not a defect when content, ownership, no-execute posture,
target manifest, and Git index mode match.

Do not fetch or contact a remote. Any identity, topology, path-set,
classification, mode, or branch mismatch is AUDIT_PROVENANCE_MISMATCH.

AUTHORITATIVE FINAL EVIDENCE SUMMARY

Use exactly:

/private/tmp/ge-rw0a-second-repair-m22z10x8/final-evidence-summary.json

Require:

- every path component lstat-safe and non-symlink;
- evidence root operator-owned, non-symlink, mode 0700;
- summary regular and safely readable;
- SHA-256:
  1d5359cdef7155d5303e7ac2d2e2a8a5b4bf9241a9c0896b461fbe3c471b98da.

Copy the exact verified bytes into the audit root as an immutable mode-0400
summary.

Parse the summary and require it records, without contradiction:

- opening manifest SHA-256:
  29044da643bf1300aec209fbf7df5d1b7fed2d79bf076b08931562ce6b47ab63
- final manifest path:
  /private/tmp/ge-rw0a-second-repair-m22z10x8/final_provenance/run-2-manifest.json
- final manifest SHA-256:
  cdfc576d53de6d116e5a46131319927df2fd56f0774ac6815eb0e0dda61323c5
- final tracked textual-diff SHA-256:
  f14dc7e28416c3afb80f5967d42e37873830731dc79afc07c3c255c3e0013d53
- recipe source size:
  3,945 bytes
- recipe source SHA-256:
  db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
- branch, HEAD, upstream, ten-path topology, classifications, modes, and
  opening/final per-file identities;
- exact targeted/focused/full-suite records and node-list identities.

Do not accept a summary that omits the final manifest byte size, final complete
stdout size/hash, or per-file opening/final identities. Extract and report
those exact values from the verified summary; do not infer or invent them.

If the summary is missing, unsafe, malformed, has the wrong hash, or
contradicts the supplied closeout, return AUDIT_PROVENANCE_MISMATCH.

AUTHORITATIVE FINAL AUDIT TARGET

After the summary passes, safely verify:

/private/tmp/ge-rw0a-second-repair-m22z10x8/final_provenance/run-2-manifest.json

Require:

- every path component lstat-safe and non-symlink;
- regular and safely readable;
- exact byte size equal to the value recorded in the verified evidence summary;
- SHA-256:
  cdfc576d53de6d116e5a46131319927df2fd56f0774ac6815eb0e0dda61323c5.

Copy the exact bytes into the audit root as an immutable mode-0400 target.

Parse canonical JSON and require:

- recipe_id:
  governed-execution.audit-patch-manifest.v1
- branch:
  codex/rw0-phase-entry-contract-freeze
- head:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- textual_diff_sha256:
  f14dc7e28416c3afb80f5967d42e37873830731dc79afc07c3c255c3e0013d53
- exactly ten entries;
- exactly eight `tracked_modified`;
- exactly two `untracked`;
- C2B3C test regular mode `0600`;
- every other entry regular mode `0644`;
- no tracked addition/deletion, missing path, symlink, or unsupported type.

If the target is missing, unsafe, malformed, or different, return
AUDIT_PROVENANCE_MISMATCH. Do not reconstruct it from the live tree,
implementation report, or aggregate hashes.

PRECEDING SECOND-AUDIT TARGET

Safely verify and copy:

/private/tmp/ge-rw0a-audit-repair.jmT10j/final-manifest-immutable.json

Require:

- SHA-256:
  29044da643bf1300aec209fbf7df5d1b7fed2d79bf076b08931562ce6b47ab63
- byte size equal to the opening-manifest size recorded in the verified final
  evidence summary;
- exact canonical topology and modes.

Compare preceding and final manifests entry by entry.

Require:

- no added or removed path;
- no classification or mode change;
- no change to:

  .docs/c2b-durable-development-state.md
  tests/test_c2b3c_author_effect_contract.py

Protected exact identities:

- `.docs/c2b-durable-development-state.md`
  - 1,884,626 bytes
  - SHA-256:
    5fd66a1266e63f8f026a27de7d84f42029813acdadc6b3ecb1978c3ff9ce9b1e
  - mode:
    0644

- `tests/test_c2b3c_author_effect_contract.py`
  - 416,182 bytes
  - SHA-256:
    935ca6fe7b18d39055d5cdc2c911302e7c0726304f3699472f3994a32f7b4778
  - working-tree mode:
    0600
  - Git index mode:
    100644

Only these eight paths may differ:

.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/worker-execution-boundary.md
tests/test_architecture_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py

The verified evidence summary is the source for each exact opening/final
size/SHA-256 pair. Report all eight pairs. Any ninth changed entry or protected
entry mismatch is AUDIT_PROVENANCE_MISMATCH.

EXPECTED PROVENANCE RECIPE

Recipe ID:

governed-execution.audit-patch-manifest.v1

Exact source size:

3,945 bytes

Exact source SHA-256:

db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Use the exact source below. Do not normalize, improve, approximate, or version
it during the audit.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

OPENING PROVENANCE GATE

1. Verify exact recipe source size and SHA-256.
2. Safely classify:
   /tmp/ge-coordinator-b3a-audit-manifest-v1.json
3. If it exists:
   - require regular, non-symlink, operator-owned;
   - preserve exact pre-audit bytes and metadata in the audit root;
   - do not delete unrelated evidence.
4. Run the exact recipe twice.
5. Require both invocations return 0 with empty stderr.
6. Require byte-identical complete stdout.
7. Require byte-identical canonical manifests.
8. Require generated canonical bytes equal the immutable final target
   byte-for-byte.
9. Require complete stdout size/hash equal the exact values from the verified
   final evidence summary.
10. Compare every path, classification, type, mode, size, and SHA-256 entry.

Any mismatch is AUDIT_PROVENANCE_MISMATCH. Stop before correctness inspection.

PROTECTED BASELINE AND APPEND-ONLY PINS

Require:

1. `.docs/c2b-durable-development-state.md`

   The complete committed-baseline bytes remain the exact candidate prefix:

   - 1,883,380 bytes
   - SHA-256:
     9401d62a0eb36e0cca1af5b8a6a80b540ddc4c781fee3faaf7318546cb532ccc

2. The append-only RW0 H3 remains wholly after that prefix and after:

   `COORDINATOR_SECTION41_COMMITTED_CURRENT_STATUS_END`

3. Final visible H2 remains Section 42, with no H2 Section 43.

4. The exact C2B3C committed-status owner remains protected and compatible with
   later governed H3 extensions.

Require no diff outside the ten-path target, especially no diff in:

- AGENTS.md
- README.md
- .docs/architecture.md
- .docs/c2a-first-slice-semantic-protocol-contract.md
- .docs/software-development-progression-boundary.md
- every `src/**` path
- all SQL and migrations
- migration catalog and application generation
- schemas
- package exports and public protocols
- StateStore and WriterSession
- fixtures, scripts, configs, examples, or supporting repositories.

TARGETED AUDIT TASKS

Only after provenance matches, spawn exactly four bounded read-only audit tasks
in parallel when capacity permits. No nested subagents and no subagent-run
tests. If only three child slots are available, start the fourth immediately
when a slot frees. Make at most one retry for a failed start.

Give every task the same exact final manifest identity, preceding audit
findings, parent repair decisions, current contract, accepted strategic target,
reopened seams, compatibility obligations, non-goals, and mutation prohibition.

1. AUTHORIZATION BASIS, AUTHOR LINEAGE, AND NONIMPLEMENTATION AUDITOR

   Inspect the complete changed documentation and relevant unchanged C2A/C2B3D/
   Section 41 contracts.

   Determine whether:

   - each existing author attempt/effect fence retains its exact immutable
     external authorization-basis ref/digest;
   - those existing bindings remain inert lineage/ceiling bounds, never
     executable permission;
   - the future narrower Coordinator-derived subordinate authorization is a
     separate record with its own identity/digest;
   - the new record binds each applicable existing fence ref/digest and its
     exact persisted authorization-basis ref/digest;
   - a current verifier must prove both per-fence equalities and common
     compatible parent-grant-family ancestry;
   - the two per-fence authorization pairs are not incorrectly required to be
     byte-equal unless the unchanged C2A contract says so;
   - incompatible/missing/stale/ambiguous relations fail closed to final
     `block` without retrieval, contact, launch, replacement fence, replacement
     attempt/effect, or author invocation;
   - validation/review/cancel effects use their own later current effect
     intents/fences and subordinate bindings under the same originating
     semantic attempt, never the author effect fence;
   - RW0 permits no replacement semantic attempt, second author effect, second
     author command, second author candidate, second candidate-authoring
     invocation, author relaunch, or author redelivery;
   - current runtime remains unsupported and fail-closed;
   - no table, row, public type, schema, migration, wire format, verifier, or
     runtime is claimed implemented.

2. CANCELLATION, DECISION CARDINALITY, FACT OWNERSHIP, AND ES/IM AUDITOR

   Inspect the sole owner’s timelines, failure/recovery matrix, cancellation
   sequence, final-outcome rules, worker facts, and route ownership.

   Determine whether:

   - the active-cancel branch orders:
     early cancellation-control decision/intent
     → cancel effect/fence/subordinate binding/delivery
     → request
     → acknowledgement
     → signal
     → process exit
     → workspace teardown
     → source-native reconciliation
     → final `cancel` or unresolved `block`;
   - reconciliation explicitly covers process descendants, worker
     observations, cancellation facts, workspace cleanup, capsule/custody
     terminal state, and delivery/source receipts;
   - final `cancel` is impossible until every required relation is complete and
     non-ambiguous;
   - incomplete/contradictory/stale/ambiguous reconciliation yields final
     `block`;
   - exactly one final RW0 semantic outcome decision exists;
   - only the active-cancel branch may additionally contain at most one earlier
     cancellation-control decision/intent;
   - the early control decision is not terminal, does not consume the latch,
     and is not counted as a second final outcome;
   - normal branches contain no early cancellation-control decision;
   - supervisor process launch remains distinct from worker-authored
     `worker_started`, `worker_completed`, and `candidate_captured`;
   - direct-local owns only its route-local process/cancel-delivery/receipt and
     reconciliation facts;
   - ES retains ES-route admission, reliable submit, lifecycle, cancellation,
     identity/credential handoff, route correlations, and retained results;
   - IM remains corroborating evidence only.

3. MARKDOWN LIVE-RANGE OWNERSHIP AND TEST-CAUSALITY AUDITOR

   Inspect all changed tests and all candidate documents.

   Determine whether:

   - each test file uses one bounded fence-aware structural model for the
     ownership claims it makes;
   - 0–3-space ATX indentation is recognized;
   - backtick/tilde-fenced headings, markers, and body are hidden;
   - the sole-owner and every cross-reference marker pair encloses all visible
     nonblank body content in its exact live owner range;
   - outside the pair, only blank lines and hidden non-visible comments are
     accepted;
   - visible leading/trailing prose, list items, headings, blockquotes, or code
     inside the owner range are rejected;
   - one valid visible block plus irrelevant hidden duplicate bytes is
     accepted;
   - two visible blocks/owners, split/reversed markers, hidden-only blocks,
     historical/same-title relocation, and visible outside-marker prose are
     rejected;
   - the exact visible-empty-BEGIN/END plus hidden-real-body mutant is rejected;
   - broken raw-marker/body controls accept predecessor-class mutants and are
     never authoritative;
   - every second-author-lineage/invocation mutant is independently rejected;
   - every authorization-basis, cancellation-reconciliation, and decision-
     cardinality mutant is independently rejected;
   - no existing test node was weakened, renamed, removed, skipped, xfailed,
     collapsed, or re-parameterized.

4. PROVENANCE, SECURITY, PUBLIC-BOUNDARY, AND ARTIFACT AUDITOR

   Inspect:

   - the entire ten-path diff;
   - the exact eight-entry preceding-to-final delta;
   - protected C2B/C2B3C bytes;
   - local `0600` versus Git `100644` posture;
   - the final evidence summary and all retained validation records;
   - source/schema/migration/public-surface diff guards;
   - artifact and sensitive-material posture.

   Determine whether:

   - the candidate is genuinely docs/tests-only;
   - no credential, bearer, raw WorkSpec, prompt, transcript, endpoint, private
     host identity, or sensitive log is embedded;
   - no source, process, worker, model, service, network, or database behavior
     was introduced;
   - no evidence/report became authority;
   - the candidate is suitable for a later audited-byte feature-branch commit
     and PR gate.

Each task must return severity-ranked, path:line-grounded findings and state:

- current contract versus strategic target;
- patch defect versus pre-existing issue;
- impact;
- required correction;
- uncertainty;
- scope not inspected;
- mutation performed:
  no;
- tests run:
  no;
- nested subagents:
  no.

The parent must inspect and reconcile every report. Preserve factual,
interpretive, or target-level disagreements.

MANDATORY PARENT INSPECTION

Inspect directly:

- the hash-pinned final evidence summary;
- both authoritative manifests and the exact eight-entry comparison;
- all ten candidate paths;
- complete diff against HEAD;
- complete preceding-to-final diffs for every changed entry, reconstructing
  preceding bytes only from safe retained evidence or exact verified Git/object
  material;
- current C2A authorization/fence/delivery/observation/cancellation contracts;
- current C2B3D and Section 41 lineage/nonimplementation contracts;
- every changed sole-owner section, matrix, timeline, and branch;
- all four changed bounded cross-reference bodies and structural owners;
- every changed test helper and strengthened existing test node;
- broken raw/whole-document mutation controls;
- protected C2B and C2B3C bytes;
- retained causal-red, targeted, focused, collection, full-suite, guard, and
  provenance records.

If complete preceding bytes for one changed file are not safely retained, report
that as an evidence limitation. Do not invent a textual diff. The exact
manifest identity delta remains mandatory.

Do not re-audit unchanged runtime internals wholesale after exact no-diff proof,
unless changed documentation or tests contradict them.

ACCEPTANCE CHECK — IMMUTABLE AUTHORIZATION BASIS

Require:

1. C2B3D already persisted exact attempt-fence and author-effect-fence
   identities/digests and their own externally authored authorization-basis
   refs/digests.

2. Existing fence-bound authorization bases remain immutable, inert, and
   non-authorizing.

3. The future narrower subordinate authorization is a separate record with its
   own identity/digest.

4. For each applicable existing fence, the subordinate record binds:
   - exact existing fence ref/digest;
   - exact persisted authorization-basis ref/digest.

5. A current verifier must prove:
   - current parent grant validity/freshness/revocation/expiry/audience/scope;
   - authorization of the exact persisted basis family;
   - compatibility of attempt/effect fence bindings with the same parent-grant
     family and exact K8/L34 lineage;
   - strict narrowing;
   - repository/base/path/effect/global-stop/current-head relations.

6. The contract does not incorrectly require the attempt and effect
   authorization pairs to be byte-identical when the unchanged C2A contract
   does not.

7. Any false, missing, stale, incompatible, or ambiguous relation yields:
   - no subordinate record;
   - no retrieval/contact/delivery/launch;
   - no replacement fence/attempt/effect/author invocation;
   - final `block`.

8. Later validation/review/cancel effects use their own current effect fences
   and bindings, not the author effect fence.

Independently reject:

- basis-ref substitution;
- basis-digest substitution;
- existing fences rewritten to the new subordinate record;
- no parent/basis ancestry relation;
- no common-family verifier result;
- mismatch absorbed by replacement attempt/effect fences;
- incompatible relation still allowing retrieval/launch;
- later current effect reusing author effect fence;
- externally authored subordinate record;
- Coordinator parent-grant authorship;
- fence possession as permission.

Require the valid positive relation to pass.

ACCEPTANCE CHECK — ONE AUTHOR LINEAGE AND INVOCATION

Require independent contract statements and test enforcement for:

- existing semantic attempt only;
- existing author effect only;
- existing author command only;
- existing author candidate only;
- existing initial author delivery identity only;
- at most one actual author delivery;
- at most one candidate-authoring source/worker invocation;
- no replacement/second attempt;
- no replacement/second author effect;
- no second author command;
- no second author candidate;
- no second author invocation;
- no relaunch;
- no redelivery.

Later validator/reviewer/cancel effects must not satisfy or weaken those
requirements.

Independently mutate each fact and require rejection.

ACCEPTANCE CHECK — ACTIVE CANCELLATION AND FINAL OUTCOME

Require the exact active-cancel sequence:

1. at most one early immutable cancellation-control decision/intent;
2. distinct cancel effect, current effect fence, subordinate binding, and
   initial cancellation delivery;
3. request;
4. acknowledgement;
5. signal;
6. process exit;
7. workspace teardown;
8. source-native reconciliation;
9. exactly one final semantic outcome:
   - `cancel` if all terminal relations are complete and non-ambiguous;
   - `block` if reconciliation is incomplete, contradictory, stale, or
     ambiguous.

Require reconciliation to cover:

- process-group and descendant state;
- worker observations;
- request/ack/signal/exit facts;
- workspace cleanup;
- capsule/custody terminal state;
- applicable delivery/source receipts.

Require:

- none of the facts implies the next;
- early decision is not final;
- early decision does not consume the latch;
- early decision does not count as a second final outcome;
- normal branches contain no early cancellation-control decision;
- no other Coordinator progression decision exists in RW0;
- no successor/Git/publication follows.

Independently reject:

- no reconciliation after teardown;
- reconciliation before teardown;
- final cancel on ambiguous reconciliation;
- omission of block fallback;
- early decision counted as final;
- two final outcomes;
- normal branch with early cancel-control decision;
- early decision consuming latch;
- reconciliation itself implying final outcome without Coordinator commit.

ACCEPTANCE CHECK — COMPLETE LIVE OWNER-RANGE MARKERS

For the sole owner and every one of the four bounded cross-references require:

- one unique visible intended Markdown owner range;
- one visible BEGIN/END pair;
- all visible nonblank body bytes after the heading and before the next
  same-or-higher-level heading lie inside the pair;
- only blank lines and hidden non-visible comments may occur outside the pair;
- owner heading may remain outside the pair;
- hidden fenced bytes cannot establish the live body;
- one valid visible block plus hidden duplicate accepted;
- two visible blocks/owners rejected;
- visible prose before BEGIN rejected;
- visible prose after END rejected;
- split/reversed markers rejected;
- hidden-only body rejected;
- historical/same-title relocation rejected;
- raw text operations are diagnostic only.

Independently test semantically contradictory leading and trailing prose for
the sole owner and every cross-reference spec.

ACCEPTANCE CHECK — VISIBLE EMPTY BLOCK WITH HIDDEN REAL BODY

Require an exact mutant that retains:

- visible intended owner heading;
- visible BEGIN;
- visible END;
- visible body containing only blank lines;
- a byte-exact otherwise-valid real body inside a balanced backtick or tilde
  fence in the same owner range;
- raw marker/body bytes discoverable by a deliberately broken raw checker.

Require:

- broken raw checker accepts;
- authoritative visible-region oracle rejects;
- positive live document accepts.

CURRENT-VERSUS-TARGET AND DEFERRED DECISIONS

Require:

- accepted strategic target, not current-runtime claim;
- external parent grant plus future Coordinator-derived narrower subordinate
  record;
- raw WorkSpec privacy and ref/digest non-authority;
- exact custodian/issuer/backend/transport/Codex/sandbox/framing/schema/latch/
  capsule/validator/reviewer/model/ES details remain deferred;
- one qualified remote Linux host, no fallback, no third adapter;
- provisional ES fixture remains non-authoritative and stale-able;
- base/path drift requires replan/new WorkSpec;
- author delivery versus later current-effect delivery split remains exact;
- supervisor/worker fact ownership remains exact;
- direct-local/ES/IM ownership remains exact;
- terminal inventories/cancellation ordering from prior repair remain intact;
- no Git/publication in RW0.

IMPLEMENTATION EVIDENCE TO INSPECT, NOT TRUST

Safely inspect:

/private/tmp/ge-rw0a-second-repair-m22z10x8

At minimum inspect through the verified evidence summary:

- causal-red report and JUnit;
- final direct 28/28;
- final architecture 30/30;
- final remote-worker 774/774;
- protected C2B3C 46/46;
- focused 1,565/1,565;
- final collection and opening/final node lists;
- full-suite 4,284/4,284;
- final guards;
- two final provenance runs;
- per-file opening/final comparison.

No correctness credit comes from implementation evidence.

The predecessor audit root is:

/private/tmp/ge-rw0a-independent-157o_6er

Inspect its independent-mutant record when safely available. Missing retained
records are evidence limitations, not automatic acceptance or rejection.

VALIDATION ISOLATION

Use one audit-created external, operator-owned, non-symlink, mode-0700 root.

For every pytest child:

- save actual caller umask;
- create evidence under secure posture;
- restore caller umask before launch;
- record child-observed umask and require numerical equality;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`
  - `LC_ALL=C`
  - `LANG=C`
  - `PYTHONDONTWRITEBYTECODE=1`
  - distinct external `PYTHONPYCACHEPREFIX`
  - distinct external `TMPDIR`
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
  - `PYTEST_ADDOPTS=''`
  - `PYTHONHASHSEED=0`
  - `python3 -B -m pytest`
  - `-p no:cacheprovider`
  - `-W error`
  - distinct external `--basetemp`
  - external `--junitxml`
  - serial execution.

Retain exact argv, environment, caller/child umask, return code, elapsed time,
stdout/stderr/JUnit sizes and SHA-256, parsed counts, warnings, parse errors,
unmapped cases, and before/after target equality.

DIRECT RW0-A ORACLE — EXACTLY ONCE

Run:

tests/test_rw0_remote_contact_phase_entry_contract.py

Require exactly 28/28 green.

ARCHITECTURE REGRESSION — EXACTLY ONCE

Run:

tests/test_architecture_contracts.py

Require exactly 30/30 green.

REMOTE-WORKER REGRESSION — EXACTLY ONCE

Run:

tests/test_remote_worker_pre_execution_planning_contract.py

Require exactly 774/774 green.

C2B3C PROTECTED REGRESSION — EXACTLY ONCE

Run:

tests/test_c2b3c_author_effect_contract.py

Require exactly 46/46 green.

COMPLETE RW0-A FOCUSED REGRESSION — EXACTLY ONCE

Run exactly:

tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_software_development_progression_boundary.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_worker_execution_semantic_boundaries.py

Require exactly 1,565/1,565 green.

NODE IDENTITY

After focused validation:

1. Collect the candidate exactly once.
2. Require exactly 4,284 node IDs.
3. Create one clean external `git archive HEAD`.
4. Collect HEAD exactly once.
5. Require exactly 4,256 HEAD node IDs.
6. Require:
   - intersection:
     4,256;
   - candidate-only:
     exactly 28;
   - HEAD-only:
     0;
   - all 28 candidate-only nodes belong to
     `tests/test_rw0_remote_contact_phase_entry_contract.py`;
   - no existing node changed identity or order.
7. Require exact candidate node-list SHA-256:
   7fb16833d1fcf8916f62ad17b0238b87b8cda8bb03432039771290bc713d12e8
8. Require exact existing-file counts:
   - architecture:
     30;
   - C2B3C:
     46;
   - remote-worker:
     774;
   - direct RW0-A:
     28.

FULL SUITE — EXACTLY ONCE

Only after inspection, independent mutants, targeted/focused validation, node
comparison, and artifact cleanup are green, run the complete repository suite
exactly once:

python3 -B -m pytest -p no:cacheprovider -W error \
  --basetemp=<external> \
  --junitxml=<external> \
  .

Require exactly:

- 4,284 collected;
- 4,284 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository bytes, modes, topology, and target manifest unchanged.

Do not run a second full-suite attempt. If immutable JUnit parsing initially
misclassifies paths, reparse the same JUnit without rerunning pytest.

FINAL GUARDS

Require:

- exact ten-path target set;
- exactly eight tracked modifications and two untracked paths;
- zero staged or unmerged paths;
- expected local mode posture, including C2B3C `0600`;
- Git index mode `100644` for every tracked candidate path;
- no Git-recorded mode change;
- no path outside target changed;
- protected C2B and C2B3C entries exact;
- append-only prefix exact;
- final H2 Section 42 and no Section 43;
- four bounded cross-reference bodies normalized-identical;
- one sole detailed RW0 owner;
- all live owner-range body content marker-owned;
- no current implementation overclaim;
- exact immutable-basis/subordinate relation and fail-closed incompatibility;
- exact one-author-lineage/invocation ceiling;
- exact post-teardown reconciliation and one-final-outcome cardinality;
- no enduring ES fixture, custodian, SSH/framing, Codex, schema, latch,
  capsule-backend, validator/reviewer/model-adapter, or ES reliable-submit
  choice accidentally frozen;
- no source, SQL, migration, catalog, schema, application-generation, package,
  public protocol, StateStore, WriterSession, runtime, fixture, script, config,
  or supporting-repository diff;
- `git diff --check` clean;
- no repository cache, bytecode, pytest cache, database, journal, WAL/SHM,
  build output, archive, generated manifest, or OS metadata;
- no Git operation or lock;
- no remote contact or runtime effect.

FINDING AND VERDICT RULES

Classify findings by:

- current-versus-target contract drift;
- authorization-basis/fence drift;
- author-lineage or invocation drift;
- ambiguity/recovery/cancellation/decision-cardinality defect;
- Markdown ownership/liveness defect;
- test/mutation inadequacy;
- ES/IM ownership drift;
- source/public-boundary widening;
- security/privacy issue;
- provenance/validation gap;
- artifact hygiene issue;
- pre-existing observation outside the patch.

Use severity:

critical
high
medium
low
observation

For every finding report:

- stable ID;
- type and severity;
- exact path:line evidence;
- current contract or strategic target;
- impact;
- required correction;
- uncertainty;
- patch defect or pre-existing issue.

ACCEPT only when:

- opening and closing provenance equal the exact final target;
- final evidence summary and final manifest both verify exactly;
- preceding and final manifests differ only inside the eight authorized paths,
  with the protected two exact;
- all four audit tasks complete;
- all six second-audit findings are independently and causally closed;
- all first-audit finding classes remain closed;
- current implementation is not overclaimed;
- immutable fence/basis bindings and separate subordinate record are exact;
- no incompatible authorization family can be absorbed within RW0;
- no replacement author lineage or invocation is permitted;
- post-teardown reconciliation and final cancel/block rules are exact;
- exactly one final semantic outcome is distinguished from any early
  cancellation-control decision;
- sole-owner and cross-reference marker pairs own all live visible range content;
- exact visible-empty/hidden-real-body mutant is rejected;
- no existing test was weakened or its node identity changed;
- direct, architecture, remote-worker, C2B3C, focused, node, and full-suite
  validation are exact-green;
- no Critical, High, Medium, or Low patch defect remains;
- the exact candidate is suitable for an audited-byte feature-branch commit,
  push, PR, and later squash-merge gate.

Use BLOCK for a repairable defect, non-green validation, materially incomplete
evidence, or unresolved uncertainty preventing acceptance.

Use REJECT only for a fundamental architecture or authority failure that cannot
be repaired within RW0-A.

Use AUDIT_PROVENANCE_MISMATCH for target-byte, summary, branch, path-set,
topology, recipe, retained-manifest, mode, or classification mismatch.

CLOSEOUT PROVENANCE

After all inspection and validation, and after removing only safe
audit-created external artifacts:

1. Run the exact recipe twice again.
2. Require complete identity with the immutable opening target.
3. Recheck protected entries, append-only prefix, modes, Git index modes, path
   set, topology, residue, operations, and locks.
4. Do not accept if audit activity changed repository bytes or metadata, even if
   later restored.

FINAL REPORT

Begin with exactly one primary verdict token:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Then report:

1. Exact opening and closing identity/provenance.
2. Verified evidence-summary identity and extracted exact target metadata.
3. Exact preceding-to-final path comparison and eight-entry identities.
4. Audit tasks, completion, retries, and disagreements.
5. Complete severity-ranked finding ledger.
6. Disposition of every first- and second-audit finding.
7. Current implementation versus RW0 target assessment.
8. Immutable authorization-basis/subordinate-record assessment.
9. One-author-lineage/invocation assessment.
10. Active-cancellation, reconciliation, and decision-cardinality assessment.
11. Sole-owner and four-cross-reference live-range ownership assessment.
12. Exact visible-empty/hidden-real-body mutant result.
13. Independent mutant matrix results.
14. Test non-weakening and node-identity assessment.
15. Direct, architecture, remote-worker, C2B3C, focused, and full-suite
    validation.
16. Protected-byte, mode, public-boundary, security, and artifact checks.
17. Limitations and separate provenance, validation, and implementation
    confidence estimates.

If ACCEPT, include:

COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FREEZE_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

If not ACCEPT, do not provide a commit or PR prompt and do not repair.

Required closing statements:

REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
