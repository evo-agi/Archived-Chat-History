TITLE

Coordinator RW0-A — repair phase-entry effect ceilings, fence timing,
cancellation sequencing, fact ownership, and Markdown/test oracles after the
first independent audit

ENGAGEMENT TYPE

Bounded parent-only repair in the existing workspace-write implementation
conversation for:

COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1
RW0-A-PHASE-ENTRY-CONTRACT-FREEZE

Do not create or resume subagents. You are the sole repository writer.

The fresh independent audit returned BLOCK against the exact ten-path candidate.
It accepted provenance, current nonimplementation, most of the authority and
custody model, the append-only Section 42 placement, the current document
content outside the findings, C2B3C compatibility, source/public boundaries,
and the executed validation groups.

It found nine patch defects:

- RW0-01 — the phrase “one actual delivery” conflicts with the distinct author,
  validation, review, and cancellation current-effect deliveries required by
  C2A;
- RW0-02 — the four-cross-reference oracle accepts a real block hidden inside a
  Markdown fence;
- RW0-03 — the sole-owner extractor accepts a hidden BEGIN marker;
- RW0-04 — the target ambiguously treats already persisted C2B3D fences as both
  pre-existing and newly issued after parent verification;
- RW0-05 — the linear target timeline places the terminal decision before
  teardown while the active-cancellation branch requires teardown before final
  semantic cancellation;
- RW0-06 — the terminal-outcome parser ignores a second visible inventory with
  legal Markdown indentation;
- RW0-07 — the decision region does not independently state that every terminal
  outcome ends RW0 without successor launch;
- RW0-08 — worker-start evidence is attributed to the supervisor rather than
  distinguishing supervisor process launch from the worker-authored start
  observation;
- RW0-09 — the ES boundary wording can be read as denying the direct-local
  supervisor’s own route-local process and cancellation responsibilities.

This turn authorizes correction of those findings only, followed by fresh
validation and provenance.

This turn does not authorize:

- any source/runtime/schema/migration/catalog/application-generation/package/
  public-protocol/StateStore/WriterSession change;
- implementation of authority verification, custody, transport, process launch,
  worker, Codex, capsule storage, validation/review/model execution, semantic
  decision runtime, latch, Git, ES routing, service, queue, scheduler, or
  autonomous loop;
- mutation of Execution Substrate, Infrastructure Manager, or any other
  repository;
- staging, commit, push, PR creation, merge, tag, release, or deployment;
- fetch, pull, remote contact, network access, model/provider invocation, Codex
  invocation, process/worker launch, SSH, live service, or live database
  contact;
- reset, clean, revert, branch switch, discard, or history rewrite.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OPENING BASELINE AND TARGET GATE

Require exactly before mutation:

- Physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- HEAD tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- HEAD subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1
- Dirty paths:
  exactly 10
- Tracked modifications:
  exactly 8
- Untracked paths:
  exactly 2
- Staged/unmerged:
  0/0
- No deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  or Git lock
- Repository residue:
  empty
- `git diff --check HEAD --`:
  clean.

Require the exact ten-path set:

.docs/rw0-remote-worker-contact-phase-entry.md
.docs/c2b-durable-development-state.md
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_architecture_contracts.py
tests/test_c2b3c_author_effect_contract.py

Require mode posture:

- these nine paths are regular working-tree mode `0644`:

  .docs/rw0-remote-worker-contact-phase-entry.md
  .docs/c2b-durable-development-state.md
  .docs/autonomous-software-development-operating-model.md
  .docs/worker-execution-boundary.md
  .docs/authority-boundaries.md
  .docs/durable-state-model.md
  tests/test_rw0_remote_contact_phase_entry_contract.py
  tests/test_remote_worker_pre_execution_planning_contract.py
  tests/test_architecture_contracts.py

- this path is regular working-tree mode `0600`, current-operator-owned, with no
  execute bits:

  tests/test_c2b3c_author_effect_contract.py

- Git index mode for every tracked candidate path is `100644`;
- no Git-recorded mode change exists.

Do not chmod any path. Do not widen the local `0600` permission.

AUTHORITATIVE OPENING TARGET

Use exactly:

/private/tmp/ge-coordinator-rw0a-marker-repair.vOkQZp/final-manifest-immutable.json

Require:

- every path component lstat-safe and non-symlink;
- evidence root operator-owned, non-symlink, mode 0700;
- manifest regular and safely readable;
- size:
  2,328 bytes;
- SHA-256:
  71d13c026567732210e1a35f5fa962b0efa853c35eb6797d0af745bc02fd3394.

Copy the safely verified bytes into one new repair-created external,
operator-owned, non-symlink, mode-0700 evidence root as an immutable mode-0400
opening target.

Parse and require:

- recipe_id:
  governed-execution.audit-patch-manifest.v1
- branch:
  codex/rw0-phase-entry-contract-freeze
- head:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- exactly ten entries;
- exactly eight `tracked_modified`;
- exactly two `untracked`;
- expected modes above;
- no deletion, missing path, symlink, or unsupported type.

Run the exact provenance recipe below twice before editing and require exact
byte equality with the immutable target.

Expected opening provenance:

- Recipe source:
  3,945 bytes
- Recipe SHA-256:
  db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
- Complete stdout:
  2,561 bytes
- Complete-output SHA-256:
  0a87b39aa2f91c7df37f42db58e39ae29d21698060bead32c1684081e6f62657
- Stderr:
  0 bytes
- Tracked textual-diff SHA-256:
  8be7180b14f8456990da11e968ef775013aae241aaaefa2ca8c513b9834ab997
- Canonical manifest:
  2,328 bytes
- Canonical-manifest SHA-256:
  71d13c026567732210e1a35f5fa962b0efa853c35eb6797d0af745bc02fd3394
- File count:
  10

Stop without mutation and return:

COORDINATOR_RW0_A_AUDIT_REPAIR_PROVENANCE_MISMATCH

on any mismatch. Do not reconstruct the target from the live tree, report, or
aggregate hashes.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

PRESERVED INDEPENDENT-AUDIT EVIDENCE

Safely inspect, but do not modify:

/private/tmp/ge-rw0-independent-audit.xTJQZg

Use it only as predecessor evidence. Do not grant correctness credit merely
because records exist.

Require the retained audit report and probes to support:

- the one-total-delivery contradiction with C2A current-effect deliveries;
- fenced four-cross-reference body acceptance;
- hidden owner BEGIN-marker acceptance;
- fence-timing ambiguity;
- cancellation-branch ordering ambiguity;
- indented duplicate terminal inventories accepted in both owner regions;
- missing independent no-successor rule in the decision region;
- supervisor/worker-start attribution ambiguity;
- direct-local/ES lifecycle wording ambiguity.

If the root is unavailable, continue from the attached audit report and current
source inspection, but disclose the missing retained evidence. Do not invent
hashes or probe results.

MAXIMUM AUTHORIZED MUTATION

Documentation:

1. .docs/rw0-remote-worker-contact-phase-entry.md
2. .docs/autonomous-software-development-operating-model.md
3. .docs/worker-execution-boundary.md
4. .docs/authority-boundaries.md
5. .docs/durable-state-model.md

Tests:

6. tests/test_rw0_remote_contact_phase_entry_contract.py
7. tests/test_architecture_contracts.py
8. tests/test_remote_worker_pre_execution_planning_contract.py

No other path may change.

Protected exact candidate bytes:

- .docs/c2b-durable-development-state.md
- tests/test_c2b3c_author_effect_contract.py

The protected C2B document must retain its exact append-only prefix, RW0 H3,
final H2 Section 42, and all markers byte-for-byte.

The C2B3C test must retain its exact final 416,182-byte content and SHA-256:

935ca6fe7b18d39055d5cdc2c911302e7c0726304f3699472f3994a32f7b4778

and working-tree mode `0600`.

The final path set and topology must remain exactly ten paths, eight tracked
modifications, two untracked files, zero staged, and zero unmerged.

PARENT CONTRACT DECISIONS FOR THIS REPAIR

The following reconciliations are authoritative for RW0-A.

A. AUTHOR DELIVERY VERSUS LATER CURRENT-EFFECT DELIVERIES

Replace every ambiguous enduring claim of “one actual delivery” or “one
delivery” with the following exact semantic split:

1. The selected C2B3D `author_candidate` effect has exactly one existing initial
   delivery identity and permits exactly one actual author-candidate delivery
   in RW0.

2. RW0 performs no author redelivery, author relaunch, second author effect,
   second candidate-authoring invocation, or replacement author attempt.

3. Validation, independent review, and cancellation are not uses of the author
   delivery. If reached, each requires its own distinct current effect intent,
   current effect fence, and initial delivery under the same originating
   semantic attempt and author-command lineage, as required by C2A.

4. In RW0 there may be at most:
   - one actual author-candidate delivery;
   - one actual validation-effect delivery;
   - one actual review-effect delivery; and
   - on an active-cancellation branch, one actual cancellation-effect delivery
     for the exact currently targeted effect.

5. Each reached effect instance has zero redelivery/retry in RW0. Ambiguous
   delivery stops and reconciles; it never causes a second delivery.

6. The model-review proposal is a separate source invocation/proposal, not a
   `DeliveryEnvelopeV1` effect class.

7. “At most one productive acceptance” remains unchanged. Only one candidate
   and one final Coordinator decision may exist in RW0.

Apply this correction to the sole owner and all four bounded cross-reference
bodies. The four bodies must remain normalized-identical.

B. EXISTING AUTHOR FENCES AND FUTURE SUBORDINATE AUTHORIZATION

Freeze this exact distinction:

1. C2B3D has already persisted the exact semantic attempt, attempt-fence
   identity/digest, author effect intent, author effect-fence identity/digest,
   author command, planned initial author delivery, and related K8/L34 lineage.

2. Those persisted fences are inert structural/durable bounds. Their existence,
   digest validity, or possession is not executable permission.

3. RW0 phase entry must reconstruct and reuse the exact existing author attempt
   fence and author effect fence. It must not mint replacement author fences,
   create a second author effect, or alter K8/L34 merely to launch.

4. Immediately before WorkSpec retrieval and again before author launch/effect,
   a current verifier must prove the complete parent grant, revocation, expiry,
   repository, base, path, global-stop, existing fence, and subordinate-
   authorization relation.

5. Within the freshly verified parent grant, Coordinator target derives a
   narrower subordinate authorization record bound to the exact existing author
   attempt/effect fences. That record makes no change to the existing fence
   identities and does not make Coordinator a parent-grant issuer.

6. For later validation, review, or cancellation effects, Coordinator may
   establish the distinct current effect intent and current effect fence inside
   the verified parent grant. Those later current-effect fences are not the
   author effect fence, while the originating attempt fence and author-command
   lineage remain exact.

7. Before any effect, the complete grant, subordinate authorization, applicable
   attempt fence, applicable current effect fence, expiry/revocation,
   repository/base/path, and current-global-stop relation must be current and
   complete.

8. Current runtime behavior remains unsupported and fail-closed.

Remove or clarify any wording that says the existing author fences are newly
issued after phase entry, or that existing fences alone authorize launch.

C. NORMAL AND ACTIVE-CANCELLATION TIMELINES

Split the target timeline into explicit branches.

Normal/non-cancel terminal branch:

- validation, review, and model proposal complete or become conclusively
  unavailable;
- Coordinator commits one of:
  `accept`, `repair`, `replan`, `terminal_reject`, or `block`;
- only committed `accept` consumes the future one-way latch;
- mutable workspace/process cleanup and capsule-custody terminal facts are
  recorded without changing the semantic outcome;
- no successor launches and no Git follows.

Active-cancellation branch:

1. Coordinator commits a cancellation intent/decision that is not yet the final
   terminal `cancel` outcome.
2. Coordinator establishes the distinct `cancel_effect` intent, current effect
   fence, and cancellation delivery.
3. Request, acknowledgement, signal delivery, process exit, and workspace
   teardown remain distinct source facts in that order.
4. Only after required reconciliation and teardown may Coordinator commit the
   terminal RW0 semantic outcome `cancel` or record semantic
   abandonment/cancellation.
5. Cleanup/custody ambiguity prevents final semantic `cancel` when the contract
   requires unresolved process/workspace state to remain `block`.
6. None of the cancellation facts implies the next.
7. No successor launches and no Git follows.

Do not use the early cancellation intent and the final terminal `cancel`
outcome as the same fact.

D. TERMINAL OUTCOME OWNERSHIP

Both structurally owned regions:

- `Bounded RW0 scenario class`; and
- `Capsule, validation, review, model, and decision`

must independently contain the exact ordered terminal domain:

`accept`, `repair`, `replan`, `terminal_reject`, `block`, `cancel`

Each region must independently state:

- every listed outcome ends RW0;
- no successor is launched in RW0;
- no Git or publication effect follows.

One region may not satisfy the other.

E. PROCESS-LAUNCH AND WORKER-START FACT OWNERSHIP

Freeze the exact attribution:

- the direct-local supervisor owns the process-launch attempt, process-group
  control, deadlines, signals, and route-local process supervision;
- the worker process is the underlying fact owner and canonical observation
  author for `worker_started`, `worker_completed`, and `candidate_captured`;
- OS/supervisor evidence owns process exit and deadline facts;
- the adapter/supervisor may carry the worker observation but does not become
  its author;
- process launch does not prove `worker_started`;
- `worker_started` does not prove completion or candidate capture.

Correct the target fact timeline and ownership matrix accordingly.

F. DIRECT-LOCAL VERSUS ES ROUTE OWNERSHIP

Clarify:

- direct-local supervisor/adapter owns only direct-local route process control,
  cancellation-request delivery, route receipts, and source-native
  reconciliation facts;
- ES owns ES admission, reliable-submit, ES-route runtime lifecycle,
  cancellation, runtime identity/credential handoff, route correlations, and
  retained results when the ES route is used;
- Coordinator owns semantic progression, safe observation ingest, and final
  decision, not route lifecycle;
- direct-local must not claim ES-route facts or create a parallel ES lifecycle
  store;
- preserving ES ownership does not deny the direct-local supervisor’s own
  bounded route-local process and cancellation responsibilities.

DOCUMENT REPAIR REQUIREMENTS

SOLE OWNER DOCUMENT

Update only the affected regions in:

.docs/rw0-remote-worker-contact-phase-entry.md

Preserve:

- sole detailed ownership;
- accepted-target/nonimplementation classification;
- all unaffected authority, custody, privacy, host, capsule, validation,
  recovery, ES/IM, tranche, and deferred-decision content;
- no selected transport/framing/custodian/Codex/schema/backend implementation;
- no current capability overclaim.

Correct:

- scenario/effect ceiling;
- authority/fence timing;
- identity/fact-owner matrix;
- fact timeline;
- active-cancellation branch;
- terminal-decision region;
- ES/direct-local wording.

FOUR CROSS-REFERENCES

Update the bounded blocks in exactly:

.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md

Preserve their begin/end markers and current structural owners.

All four normalized bodies must remain identical and state compactly:

- sole detailed owner path;
- current repository still stops at C2B3D planned author delivery plus Section
  41 selection;
- external parent-grant authorship and Coordinator-derived narrower subordinate
  authorization target;
- existing author fences are inert and reused exactly; they are not permission;
- exactly one actual author delivery, while any reached validation, review, or
  cancellation uses a separate current-effect delivery;
- no redelivery or relaunch;
- one host, no fallback, no third adapter;
- current worker/custody/capsule/validation/review/model/decision/latch/Git/
  publication runtime remains absent;
- direct-local route-local ownership does not absorb ES-route authority;
- exact custodian, transport, framing, Codex, schema, latch, and backend choices
  remain deferred.

Do not duplicate detailed matrices.

TEST-ORACLE REPAIRS

GENERAL MARKDOWN MODEL

For every changed test file that validates Markdown ownership, use one bounded
fence-aware structural model in that file:

- visible ATX headings support 0–3 ASCII-space indentation;
- headings/markers/content inside active backtick or tilde fences are hidden;
- marker visibility and ownership derive from scanner events, not raw global
  `count`, `find`, `index`, split, or regex;
- raw operations may be diagnostic only after one exact visible span is found;
- unique owners bind through parent range and stable adjacent heading events;
- one valid visible owner plus irrelevant hidden duplicate bytes is accepted;
- two visible owners/blocks are rejected.

Do not dynamically import another test module.

SOLE OWNER ORACLE — RW0-03

In `tests/test_rw0_remote_contact_phase_entry_contract.py`:

- require exactly one visible, unfenced BEGIN/END marker pair;
- require both markers enclose the complete live owner body;
- reject a fenced BEGIN, fenced END, split pair, reversed pair, hidden-only
  pair, duplicate visible pair, or pair outside the intended live owner;
- accept one visible pair plus an irrelevant hidden duplicate;
- preserve raw hidden bytes as a positive control;
- add a deliberately broken raw-marker extractor that accepts the audit’s
  hidden-marker mutant while the final oracle rejects it;
- never use the broken extractor as the positive oracle.

FOUR-CROSS-REFERENCE ORACLE — RW0-02

In the new direct test and any pre-existing changed test that currently claims
cross-reference structure:

- freeze a closed four-entry map of path, unique current owner, parent,
  predecessor/range terminator, begin marker, and end marker;
- require one complete visible block in the intended owner range;
- require all four visible bodies normalized-identical;
- reject fenced-only body, visible empty H3 plus hidden real body, historical
  relocation, same-title sibling/ancestor relocation, split markers, and two
  visible blocks;
- accept one correct visible block plus irrelevant hidden duplicate bytes;
- remove raw marker-count authority;
- add a broken raw-body checker that accepts the audit’s fenced-body mutant while
  the final complete oracle rejects it.

If `tests/test_architecture_contracts.py` or
`tests/test_remote_worker_pre_execution_planning_contract.py` contains the weak
predecessor structural check reproduced by the audit, repair that exact check.
If one file does not require a byte change, keep it byte-identical and report
that fact.

TERMINAL OUTCOME ORACLE — RW0-06 AND RW0-07

In the direct test:

- identify the two unique owner ranges independently;
- parse every visible Markdown inventory candidate in each range, including
  legal 0–3-space indentation;
- ignore only fenced content;
- require exactly one visible authoritative inventory per range;
- reject an indented second visible inventory, duplicate exact inventory,
  sibling inventory, missing/reordered/substituted/seventh outcome, or relocated
  inventory;
- require the exact six ordered outcomes in each range;
- independently require “every outcome ends RW0” and “no successor launch” in
  each range;
- one region may not satisfy the other;
- retain the broken whole-document checker and require it to accept the
  predecessor one-region mutant while the final region oracle rejects it.

CONTRACT-SEMANTIC MUTANTS — RW0-01, RW0-04, RW0-05, RW0-08, RW0-09

Strengthen existing nodes without adding or parameterizing nodes. Add in-memory
mutants that must fail independently:

- replace “one author delivery” with one total delivery;
- reuse the author delivery for validation, review, or cancellation;
- permit author redelivery/relaunch;
- treat model proposal as a DeliveryEnvelope effect class;
- mint replacement author fences after phase entry;
- claim existing fences alone authorize launch;
- omit the complete grant/subordinate/fence/currentness relation;
- commit terminal `cancel` before process exit and teardown;
- collapse early cancellation intent with final terminal `cancel`;
- attribute `worker_started` to supervisor/adapter;
- treat process launch as proof of worker start;
- deny direct-local route-local process/cancel ownership;
- let direct-local own ES admission/lifecycle/cancellation/result truth.

Retain all prior mutants and current nonimplementation/public-boundary checks.

TEST NODE BOUNDARY

Before editing, collect exactly once under isolated posture:

- complete repository:
  exactly 4,284 nodes;
- direct RW0-A file:
  exactly 28 nodes;
- architecture file:
  exactly 30 nodes;
- remote-worker file:
  exactly 774 nodes;
- C2B3C file:
  exactly 46 nodes.

Retain literal ordered lists.

Do not add, remove, rename, skip, xfail, decorate, parameterize, collapse, or
weaken any test node.

Final ordered lists must be byte-identical to opening lists.

CAUSAL RED GATE

Before changing documentation:

1. strengthen only the authorized test oracles and mutants;
2. keep documentation at the exact opening target;
3. run exactly once:

   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_remote_worker_pre_execution_planning_contract.py

4. require a non-green result causally demonstrating at least:
   - the one-total-delivery wording conflict;
   - one hidden owner/cross-reference mutant accepted by predecessor logic;
   - an indented duplicate terminal inventory accepted by predecessor logic;
   - the missing decision-region no-successor rule;
   - at least one fence-timing/cancellation/fact-owner/ES wording mismatch.

Retain exact evidence.

Then repair the documentation and final test helpers. Do not rerun the red
attempt on predecessor bytes.

If the added mutants do not reproduce the independent audit’s defects, stop
before documentation changes.

VALIDATION ISOLATION

Use one new external, operator-owned, non-symlink, mode-0700 repair root.

For every pytest child:

- save actual caller umask;
- create evidence under secure posture;
- restore caller umask before launch;
- record child-observed umask and require numerical equality;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`
  - `LC_ALL=C`
  - `LANG=C`
  - `PYTHONDONTWRITEBYTECODE=1`
  - distinct external `PYTHONPYCACHEPREFIX`
  - distinct external `TMPDIR`
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
  - `PYTEST_ADDOPTS=''`
  - `PYTHONHASHSEED=0`
  - `python3 -B -m pytest`
  - `-p no:cacheprovider`
  - `-W error`
  - distinct external `--basetemp`
  - external `--junitxml`
  - serial execution.

Retain exact argv, effective environment, caller/child umask, return code,
elapsed time, stdout/stderr/JUnit sizes and SHA-256, parsed counts, warnings,
parse errors, unmapped cases, and before/after target identity.

FINAL TARGETED GREEN GATES

Run exactly once each on frozen final bytes:

1. Direct RW0-A:

   tests/test_rw0_remote_contact_phase_entry_contract.py

   Require exactly 28/28 green.

2. Architecture:

   tests/test_architecture_contracts.py

   Require exactly 30/30 green.

3. Remote-worker planning:

   tests/test_remote_worker_pre_execution_planning_contract.py

   Require exactly 774/774 green.

4. C2B3C compatibility, unchanged bytes:

   tests/test_c2b3c_author_effect_contract.py

   Require exactly 46/46 green.

COMPLETE RW0-A FOCUSED REGRESSION

Run exactly:

tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_software_development_progression_boundary.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_worker_execution_semantic_boundaries.py

Require exactly 1,565/1,565 green.

If any named file is absent, stop rather than substituting.

FINAL NODE COLLECTION

After focused validation and cleanup:

- collect the complete repository exactly once;
- require exactly 4,284 nodes;
- require literal equality with the opening candidate list;
- require direct test remains 28 nodes;
- architecture remains 30;
- remote-worker remains 774;
- C2B3C remains 46;
- require no added, removed, renamed, skipped, xfailed, collapsed, or
  re-parameterized node.

FULL SUITE — EXACTLY ONCE

Only after all targeted/focused gates, node identity, path boundary, and
artifact cleanup are green, run exactly once:

python3 -B -m pytest -p no:cacheprovider -W error \
  --basetemp=<external> \
  --junitxml=<external> \
  .

Require exactly:

- 4,284 collected;
- 4,284 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository bytes, topology, modes, and node identity unchanged before/after.

Do not run a second full-suite attempt.

FINAL CONTRACT AND PATH GUARDS

Require:

- exact ten-path candidate set;
- exactly eight tracked modifications and two untracked files;
- zero staged/unmerged paths;
- expected working-tree modes, including C2B3C `0600`;
- Git index mode `100644` for every tracked path;
- no Git-recorded mode change;
- no path outside the ten-path target changed;
- `.docs/c2b-durable-development-state.md` byte-identical to the opening target;
- `tests/test_c2b3c_author_effect_contract.py` byte-identical to the opening
  target;
- all four cross-reference bodies normalized-identical;
- one sole detailed owner;
- no current implementation overclaim;
- exact parent/subordinate/fence distinction;
- exact author-versus-later-effect delivery ceiling;
- exact normal/cancellation branch distinction;
- exact terminal outcomes in both owner regions;
- exact process-launch/worker-start fact ownership;
- exact direct-local/ES route split;
- no enduring fixture, custodian, SSH/framing, Codex, schema, latch,
  capsule-backend, validator/reviewer/model-adapter, or ES reliable-submit
  implementation choice added;
- no source, SQL, migration, catalog, schema, application-generation, package,
  public protocol, StateStore, WriterSession, runtime, fixture, script, config,
  or supporting-repository diff;
- `git diff --check` clean;
- no repository cache, bytecode, pytest cache, database, journal, WAL/SHM,
  build output, archive, generated manifest, or OS metadata;
- no Git operation or lock;
- no remote contact or runtime effect.

FINAL PROVENANCE

After final validation and cleanup, run the exact unchanged provenance recipe
twice.

Require:

- both return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- exactly ten entries;
- exactly eight `tracked_modified`;
- exactly two `untracked`;
- expected working-tree modes;
- no deletion, rename, symlink, Git-recorded mode change, or unsupported type.

Compare final manifest with the immutable opening target and report:

- every changed entry, opening/final size and SHA-256;
- every byte-identical protected entry;
- exact path classifications and modes;
- recipe source size/hash;
- complete-output size/hash;
- tracked textual-diff hash;
- canonical-manifest size/hash;
- causal red evidence;
- targeted/focused/collection/full-suite evidence paths and hashes;
- current/target/deferred classification guard;
- no-effect/no-network/no-supporting-repo evidence.

Do not stage. The final working-tree manifest is the future independent-audit
target.

STOP CONDITIONS

Stop without further mutation if:

- opening identity, target, path set, mode posture, or node count differs;
- the audit findings cannot be closed inside the eight-path maximum mutation
  allowlist;
- `.docs/c2b-durable-development-state.md` or the C2B3C test must change;
- any source/schema/migration/public/runtime change appears necessary;
- preserving existing author fence identities conflicts with the complete C2A
  grant/subordinate/fence relation;
- the one-author-delivery versus later-current-effect-deliveries split cannot be
  stated without changing C2A;
- the active-cancellation branch cannot distinguish early intent from terminal
  `cancel`;
- a causal predecessor defect cannot be reproduced;
- an existing test node must change;
- targeted, focused, collection, or full-suite validation is not exact-green;
- another path changes;
- final provenance is unstable;
- remote contact, staging, publication, worker/model/process activity, or
  supporting-repository mutation would be required.

On stop, preserve exact state and evidence. Do not reset, clean, revert, switch
branches, stage, or discard work.

CLOSEOUT

Return exactly:

COORDINATOR_RW0_T1_FIRST_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

only if:

- RW0-01 through RW0-09 are causally and contractually closed;
- the existing author fence identities remain exact and non-authorizing;
- distinct later current-effect deliveries are correctly bounded;
- the active-cancellation branch is unambiguous;
- all Markdown owners and inventories are structurally causal;
- accepted current/nonimplementation and deferred-decision boundaries remain;
- validation is exact-green;
- node identity is unchanged;
- final ten-path provenance is stable;
- no source/runtime/remote/staging/publication effect occurred.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
