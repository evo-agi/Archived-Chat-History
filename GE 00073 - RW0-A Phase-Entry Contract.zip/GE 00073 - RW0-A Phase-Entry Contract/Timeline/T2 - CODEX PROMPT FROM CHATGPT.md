TITLE

Coordinator RW0 — remote worker contact through semantic decision phase-entry
reconnaissance and first-tranche freeze

ENGAGEMENT TYPE

Fresh-conversation, read-only architecture and implementation reconnaissance.

Run this in one new Codex parent conversation with read-only posture.

Do not edit, create, delete, rename, format, stage, commit, push, create or
update a PR, merge, install dependencies, run migrations, invoke a model or
Codex worker, launch a process, contact a live service, open a network
connection, or mutate any repository or operator state.

Do not run tests in this turn. Static parsing and read-only Git/source
inspection are permitted.

Use exactly four bounded read-only explorer agents. No nested subagents. The
parent owns reconciliation and the final plan.

PRIMARY REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED COORDINATOR BASELINE

Require exactly:

- Physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- Branch:
  trunk_dev
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- Subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Ahead/behind:
  0/0
- Worktrees:
  1
- Worktree/index/untracked/unmerged:
  clean
- No Git operation or Git lock

Stop with RECONNAISSANCE_BLOCKED on any mismatch. Do not fetch, pull, reset,
clean, rebase, merge, switch branches, or absorb drift.

BOUNDED SUPPORTING REPOSITORIES

Read-only inspection is authorized in:

- Execution Substrate:
  /Users/ds/Repositories/Execution Substrate/

- Infrastructure Manager:
  /Users/ds/Repositories/Infrastructure Manager/

For each supporting repository:

1. record physical root, branch, HEAD, tree, upstream, ahead/behind, worktree
   count, and status;
2. do not require cleanliness;
3. distinguish committed HEAD facts from dirty working-tree overlays;
4. use committed HEAD guidance/contracts as current repo authority;
5. classify any uncommitted local difference as a Codex-reported overlay only;
6. do not let an uncommitted supporting-repo change silently define the
   Coordinator target;
7. do not inspect unrelated implementation surfaces.

No other repository is in scope. Bridge, Control Plane, Maintenance Agent, and
GitHub are non-goals for this turn.

WORKSTREAM ID

COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1

PARENT OBJECTIVE

Freeze the minimum coherent operating model and implementation sequence for the
next substantive Coordinator program:

one currently selected pre-execution proposal and established author-effect
intent
→ one bounded direct-local delivery to one qualified remote Linux host
→ one process-separated coding worker
→ one immutable candidate capsule
→ bounded validation and independent review observations
→ one non-authoritative model review proposal
→ one durable Coordinator semantic decision
→ no Git effect
→ no publication.

The output must select one exact first implementation tranche or return a
blocking decision ledger. This turn must not implement anything.

CURRENT COORDINATOR CONTRACT

Treat these as repo-backed present reality to verify, not as target behavior:

1. Current committed capability comprises:
   - C2A1 internal pure no-I/O worker semantic values and six coherence
     validators;
   - C2B2 private values and twelve private reader roles over twenty-four
     literal query specifications;
   - guarded writer/transaction authority;
   - private route-neutral VS1B program genesis;
   - private C2B3D author-effect establishment, including inert planned
     `direct_local_bootstrap` delivery;
   - private, non-executable Section 41 pre-execution proposal selection;
   - application generation 2 with migrations 0001, 0002, and 0003.

2. Current capability does not implement:
   - external standing-authority verification;
   - executable subordinate authorization;
   - WorkSpec physical custody or attempt-bound retrieval;
   - direct-local adapter or supervisor;
   - worker process or Codex invocation;
   - dispatcher, queue, outbox/inbox, reconciler, service/API/IPC;
   - observation ingest;
   - capsule builder, immutable capsule store, or capsule retrieval;
   - validation, independent review, model-review invocation, or post-execution
     semantic-decision runtime;
   - cancellation delivery/acknowledgement runtime;
   - Git effect;
   - Bridge or ES handoff;
   - publication or autonomous loop.

3. Current executable authorization is unsupported and fail-closed. Coordinator
   cannot self-authorize, mint a parent grant, treat a digest/ref as permission,
   or make reports/model output durable authority.

4. C2B3D persists intent and a planned delivery only. It does not dispatch,
   verify external authority, contact a worker, use credentials, or establish
   execution permission.

5. Section 41 ends at typed pre-execution proposal selection or non-selection.
   It does not invoke a model/provider, contact a worker, execute review or
   validation, or make a post-execution semantic decision.

6. Reports, traces, model responses, topology/profile observations, transport
   receipts, support artifacts, and Bridge records are evidence/projection only.

ACCEPTED STRATEGIC TARGET

Treat this as a planning overlay, not current behavior:

1. The frozen dependency order is:
   - pre-I/O Coordinator progression;
   - remote worker contact through semantic decision;
   - separate local-Git effect and stop;
   - migration to ES before another productive bootstrap slice.

2. The first author-effect delivery uses the existing
   `direct_local_bootstrap` compatibility token as a bounded direct/non-ES route
   to one qualified remote Linux host.

3. There is no Mac fallback, Coordinator-host execution fallback, or third
   adapter kind.

4. The route may produce at most one productive acceptance.

5. Initial worker source and release machinery belong in the Coordinator
   repository; the worker runs as a separate OS process and receives no
   Coordinator SQLite or writer authority.

6. Raw WorkSpec and retrieval bearer authority never enter Coordinator SQLite.
   A safe ref or digest is not retrieval permission.

7. External standing-policy authority remains the parent-grant author. A
   separate current verifier must prove grant/fence/expiry/revocation/repository/
   base/path/global-stop relations immediately before launch or effect.

8. A qualified-remote-host readiness gate must be satisfied before real
   retrieval, worker/Codex invocation, validation, review, or Git execution.
   Readiness evidence is not identity or effect authority.

9. Worker completion, capsule sealing, validation, independent review, model
   proposal, Coordinator semantic decision, Git commit, PR, merge, and
   deployment remain distinct facts.

10. The same worker artifact and versioned command/observation/fence/capsule
    semantic contracts must later map through an ES adapter. Direct-local must
    not absorb ES admission, reliable-submit, runtime lifecycle, retained-result,
    or cancellation authority.

11. Local Git remains out of scope for RW0.

GOVERNING SEMANTIC CONTRACTS TO PRESERVE

The C2A contract already freezes distinct identities for program/version,
accepted intent, work/revision, semantic attempt, effect intent, delivery
attempt, source invocation, observation, candidate, capsule manifest, portable
capsule digest, validation observation, independent review, model proposal,
Coordinator decision, and future Git effect.

The current internal semantic module defines:

- `WorkSpecV1`
- `AttemptFenceV1`
- `EffectFenceV1`
- `WorkerCommandV1`
- `DeliveryEnvelopeV1`
- `CandidateCapsuleManifestV1`
- `WorkerObservationV1`

The exact source-kind inventory is:

- `direct_local_adapter`
- `es_adapter`
- `worker`
- `capsule_builder`
- `validator`
- `independent_reviewer`
- `workspace_custodian`
- `capsule_store`

Do not create competing identities, collapse facts, or casually redesign these
schemas. Identify any genuinely necessary semantic-contract change explicitly
and treat it as a governing-contract decision, not an implementation detail.

REOPENED SEAMS

The current repository deliberately leaves open:

- exact Coordinator program/semantic-attempt durable schema beyond current
  implemented families;
- external grant issuer/verifier deployment, trust root, revocation transport,
  grant encoding, signer, and credential form;
- WorkSpec physical custodian, retention, and attempt-bound retrieval
  authorization;
- durable delivery/outbox/inbox or equivalent mechanics;
- polling, callback, local IPC, service, and process framing;
- worker package, executable, build, supervisor, deployment, and OS identity;
- Codex CLI versus App Server/provider protocol;
- workspace creation, isolation, cleanup, and process containment;
- capsule builder/store path, encryption, serialization, retention, archival,
  garbage collection, and recovery;
- validation executor and independent-review mechanism;
- model-review invocation protocol;
- observation ingest and Coordinator post-execution decision runtime;
- cancellation/global-stop delivery, acknowledgement, process-exit, semantic
  abandonment, and semantic-cancellation relations;
- direct-local ambiguity/recovery policy;
- ES adapter and conformance mechanics.

Do not freeze a seam earlier than the first tranche needs it. Do not leave an
architecture-defining seam to incidental source choices.

COMPATIBILITY OBLIGATIONS

Preserve unless an explicit migration decision says otherwise:

- current private APIs and package non-export posture;
- current `direct_local_bootstrap` route token;
- existing C2A identities, finite domains, digest relations, and golden vectors;
- current C2B3D and Section 41 receipts, replay, recovery, and writer authority;
- current application generation and migrations through 0003;
- current `FiniteBacklog`, standing lease, zero-only budget, READY-only
  dependency, disabled stages, coding `global_stop`, and `WriterSession`
  compatibility surfaces;
- ES ownership of admission/runtime/reliable-submit/lifecycle/cancellation/
  retained-results;
- no Bridge worker ownership;
- no CP target-topology authority.

REQUIRED COORDINATOR INSPECTION

Inspect together, not as isolated documents:

Governing/current status:

- AGENTS.md
- README.md
- .docs/architecture.md
- .docs/autonomous-software-development-operating-model.md
- .docs/software-development-progression-boundary.md
- .docs/worker-execution-boundary.md
- .docs/authority-boundaries.md
- .docs/durable-state-model.md
- .docs/c2a-first-slice-semantic-protocol-contract.md
- .docs/c2a1-pure-semantic-values.md
- .docs/c2b3-program-initialization.md
- .docs/c2b-durable-development-state.md, especially current Sections 38–42
- .docs/sqlite-bootstrap-and-migrations.md
- .docs/sqlite-operations-and-recovery.md
- .docs/sqlite-threat-model.md

Implemented source seams:

- src/ge_nwp_coordinator/_worker_execution_semantic_values.py
- src/ge_nwp_coordinator/_development_program_initialization_contracts.py
- src/ge_nwp_coordinator/_sqlite_development_program_initialization.py
- src/ge_nwp_coordinator/_development_author_effect_establishment_contracts.py
- src/ge_nwp_coordinator/_sqlite_development_author_effect_establishment.py
- src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
- src/ge_nwp_coordinator/_sqlite_development_pre_execution_plan_disposition.py
- src/ge_nwp_coordinator/_development_program_row_values.py
- src/ge_nwp_coordinator/_development_effect_row_values.py
- src/ge_nwp_coordinator/_development_decision_row_values.py
- src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py
- src/ge_nwp_coordinator/_sqlite_development_readers.py
- src/ge_nwp_coordinator/sqlite_writer_session.py
- src/ge_nwp_coordinator/sqlite_migration.py
- migrations 0002 and 0003
- src/ge_nwp_coordinator/__init__.py
- src/ge_nwp_coordinator/state_store.py

Tests/fixtures:

- tests/test_worker_execution_semantic_values.py
- tests/test_worker_execution_semantic_relations.py
- tests/test_worker_execution_semantic_vectors.py
- tests/test_worker_execution_semantic_boundaries.py
- tests/test_c2a_effects_and_recovery.py
- tests/test_c2a_first_slice_semantic_protocol_contract.py
- tests/test_c2a_nonimplementation.py
- tests/test_c2b3d_author_effect_establishment_contracts.py
- tests/test_c2b3d_author_effect_establishment_recovery.py
- tests/test_c2b3d_private_atomic_author_effect_establishment.py
- tests/test_c2b3d_private_author_effect_delegation.py
- tests/test_section41_pre_execution_plan_disposition_contracts.py
- tests/test_section41_pre_execution_plan_disposition_recovery.py
- tests/test_section41_private_atomic_pre_execution_plan_disposition.py
- tests/test_section41_private_pre_execution_plan_disposition_delegation.py
- tests/test_remote_worker_pre_execution_planning_contract.py
- tests/test_software_development_progression_boundary.py
- tests/test_architecture_contracts.py
- tests/test_runtime_non_authority.py
- migration/schema tests relevant to any proposed durable-state change

REQUIRED SUPPORTING-REPO INSPECTION

Execution Substrate, committed HEAD only:

- AGENTS.md
- current PLANS.md
- governing system-boundary and execution-lifecycle contract documents
- current reliable-submit/resolved-execution-plan seams
- current runtime-profile, retained-result, cancellation, and identity ownership
  docs relevant to later adapter conformance

Return only:
- current ES ownership constraints RW0 must not absorb;
- the minimum future conformance surface;
- decisions that must remain deferred to ES;
- current priority conflicts with Coordinator assumptions.

Do not design or modify ES in this turn.

Infrastructure Manager, committed HEAD only:

- AGENTS.md if present
- README.md
- architecture
- supported-local and remote-supported-host guidance
- profile/readiness/report/support evidence contracts relevant to one qualified
  remote Linux host

Return only:
- what current IM evidence can and cannot prove;
- whether any existing evidence can satisfy part of the host-readiness gate;
- why IM evidence cannot become authority;
- exact gaps that need an owner-neutral or Coordinator-consumable contract.

Do not make IM an enduring dependency by inertia.

PHASE-ENTRY QUESTIONS THAT MUST BE ANSWERED

A. Exact starting point

1. What exact committed durable rows, heads, receipts, and result projections
   identify the selected proposal and inert author-effect delivery?
2. What is the causal order between Section 41 selection and C2B3D delivery?
3. Which exact identity is the RW0 entry key?
4. Does current C2B3D contain enough intent to launch once authority/custody are
   supplied, or is a new Coordinator decision/effect establishment required
   first?

B. Authority and freshness

5. What exact parent grant and subordinate attempt/effect facts are required?
6. What component authors verification, what must be checked immediately before
   retrieval/launch, and what safe proof may Coordinator retain?
7. How do revocation, expiry, global stop, repository/base/path ceilings, and
   process lifetime interact?
8. What is the fail-closed result when fresh verification is unavailable or
   ambiguous?
9. Which facts may be durable, which must remain ephemeral, and which are
   prohibited from SQLite?

C. WorkSpec custody and retrieval

10. Who physically holds raw WorkSpec?
11. What exact attempt-bound retrieval capability or one-shot handoff authorizes
    access?
12. How are retrieval, consumption, reuse, expiry, and revocation observed?
13. How is restart handled without putting bearer material in Coordinator
    durable state?
14. Can the first slice use a simpler explicit operator-provided custody
    mechanism without making the user a per-attempt approval service?

D. Delivery and ambiguity

15. What durable fact is committed before external contact?
16. What is the minimum outbox/inbox or equivalent state needed for delivery,
    acknowledgement, rejection, unknown outcome, and redelivery?
17. What idempotency keys bind Coordinator, supervisor, worker, and source
    observations?
18. When is retry allowed, and what exact evidence proves prior non-acceptance?
19. What ambiguity must stop rather than retry?
20. How is restart reconciliation performed without hidden state?

E. Qualified remote host

21. Which process owns qualification?
22. What finite evidence proves OS, architecture, workspace, toolchain, identity,
    credentials, network reachability, capacity, and cleanup posture?
23. What freshness and binding to repository/base/scenario are required?
24. Can current IM output contribute evidence, and what is still missing?
25. How is Mac/Coordinator-host fallback mechanically prevented?

F. Worker and process boundary

26. What is the minimum process-separated worker package and executable?
27. What does the supervisor own versus the worker?
28. What process user, filesystem root, environment, credential, timeout,
    cancellation, stdout/stderr, and cleanup boundaries are required?
29. Is Codex CLI, App Server, or another invocation seam selected for the first
    proof? If not, what decision gate is required before source work?
30. What exact command/envelope/observation serialization and framing is needed
    now without freezing the later ES wire format?
31. What secrets and private materials are prohibited from logs, errors,
    evidence, capsule, and Coordinator state?

G. Candidate capsule and evidence

32. Who builds and seals the capsule?
33. What is included/excluded?
34. What owns manifest identity, portable digest, blobs, modes, and base/candidate
    relation?
35. Where is the immutable capsule stored, how is it retrieved for validation and
    review, and what retention/cleanup policy is minimally required?
36. Which evidence is authoritative, which is projection, and which is never
    retained?

H. Validation, review, model proposal, and Coordinator decision

37. What validation commands or validating runtime own observed results?
38. What makes independent review independent from authoring and model proposal?
39. How is a model review proposal invoked and bound without becoming durable
    authority?
40. Which exact Coordinator decision kinds terminate RW0:
    accept, repair, replan, terminal_reject, block, or cancel?
41. What evidence minimum is required for each decision?
42. Does a repair or replan create a new semantic attempt in this first slice, or
    must RW0 stop after one non-accepting decision?
43. What durable post-execution state and schema are minimally necessary?

I. Cancellation, global stop, and recovery

44. What pre-launch stop conditions block retrieval/launch?
45. How do cancellation intent, request, acknowledgement, signal delivery,
    process exit, workspace teardown, semantic abandonment, and semantic
    cancellation remain distinct?
46. What happens if global stop activates during retrieval, invocation,
    candidate capture, seal, validation, review, or decision?
47. What are the restart and crash-recovery rules for every externally visible
    phase?

J. ES conformance and direct-local ceiling

48. Which direct-local mechanics must be transport-neutral and later reusable?
49. Which facts must stay route-owned and not leak into semantic identity?
50. What conformance tests can later run the same worker artifact/contracts
    through direct-local and ES?
51. What is the exact condition that disables productive direct-local after one
    accepted slice?
52. Which questions are explicitly deferred to ES ownership?

K. First implementation tranche

53. Is the next tranche:
    - governing docs and contract tests only;
    - pure value/contract source only;
    - durable schema/migration;
    - a no-contact supervisor/worker packaging proof;
    - or another bounded prerequisite?
54. What exact capability does it add?
55. What exact effect ceiling remains?
56. What are the maximum touched paths?
57. What contract tests, focused tests, full-suite treatment, provenance, audit,
    and publication path are required?
58. What stop conditions prevent accidental implementation of the full worker
    path?

SUBAGENT WORKFLOW

Spawn exactly four read-only explorers in parallel. Because explorer agents may
not inherit full context, give each a self-contained context capsule with:

- all repository paths;
- exact Coordinator baseline;
- parent objective;
- current contract;
- strategic target;
- compatibility obligations;
- assigned scope;
- non-goals;
- mutation authority:
  none;
- authorized commands:
  read-only inspection only;
- required report envelope below.

No nested subagents. Make at most one retry if a required explorer fails to
start. Preserve disagreements.

EXPLORER 1 — AUTHORITY, CUSTODY, AND PRIVACY

Inspect Coordinator authority and semantic contracts plus relevant implemented
source.

Own questions B, C, and the privacy/authority portions of G and I.

Return:

- exact current authority facts;
- parent-grant/subordinate-verification target;
- durable/ephemeral/prohibited material matrix;
- WorkSpec custodian and retrieval options;
- preferred first-slice authority/custody model;
- alternatives rejected and why;
- schema implications;
- security and privacy stop conditions;
- source/test/doc impact.

EXPLORER 2 — DURABLE PROGRESSION AND STATE MODEL

Inspect current program genesis, author-effect, Section 41 selection, readers,
writer boundary, migrations, schemas, and tests.

Own questions A, D, H40–43, I47, and K’s durable-state implications.

Return:

- exact current row/head/receipt/result timeline;
- Section 41/C2B3D causal relation;
- proposed RW0 durable fact timeline;
- one-writer ownership per fact;
- required replay/recovery/idempotency model;
- whether a new migration is required;
- minimum candidate schema if required, clearly labeled provisional;
- tranche decomposition;
- likely exact touched files/tests for the first tranche.

EXPLORER 3 — WORKER, HOST, PROCESS, AND CAPSULE

Inspect Worker Execution Boundary, C2A values, worker semantic source/tests, and
bounded IM committed guidance.

Own questions E, F, G, and process/custody portions of I.

Return:

- qualified-host evidence model and IM limitations;
- minimum worker/supervisor topology;
- process, filesystem, credential, timeout, cancellation, and cleanup boundary;
- Codex invocation decision or unresolved decision gate;
- capsule builder/store/custody model;
- direct-local framing that does not freeze ES wire details;
- exact packaging/source/test surfaces likely affected;
- sensitive artifact classifications.

EXPLORER 4 — VALIDATION, FAILURE MODEL, AND ES CONFORMANCE

Inspect Coordinator review/decision/failure semantics, tests, and bounded ES
committed guidance.

Own questions H37–39, I, J, and validation/audit/publication portions of K.

Return:

- validation/review/model-proposal ownership;
- finite failure and ambiguity matrix;
- no-blind-retry rules;
- cancellation/global-stop precedence;
- ES ownership constraints and minimum later conformance surface;
- direct-local disablement condition;
- exact validation strategy;
- independent audit perspectives;
- artifact/provenance requirements;
- publication-policy treatment under the current PR/squash/no-bypass model.

STANDARD SUBAGENT REPORT

SUBAGENT REPORT

Role:
Assigned scope:
Repository identities observed:
Files/documents/source/tests inspected:

Claim ledger:
- ID:
  Type: contract/invariant | compatibility edge | reopened seam |
        implementation detail | strategic target | evidence | inference |
        uncertainty
  Claim:
  Source: repo-relative-path:line
  Implication:
  Required docs/source/schema/tests impact:
  Confidence:

Current implemented contract:
Accepted strategic target:
Authority/custody/fact ownership:
Decisions that must be frozen before source:
Decisions safely deferred:
Candidate first-tranche implications:
Risks and stop conditions:
Scope not inspected:
Mutation performed: no
Commands with side effects performed: no
Network contact performed: no
Nested subagents created: no

PARENT RECONCILIATION

After all four reports:

1. Independently inspect every load-bearing source and contract claim.
2. Preserve disagreements and classify them as factual, interpretive, or target
   decisions.
3. Resolve only from owning-repository contracts or an explicit parent strategic
   judgment.
4. Do not let ES or IM proof scaffolding define Coordinator architecture.
5. Do not report target behavior as current.
6. Close every subagent.
7. Recheck Coordinator HEAD, branch, upstream, status, worktree count, and locks.
8. Recheck that no supporting repository changed.
9. Stop without editing.

REQUIRED PARENT OUTPUT

A. Baselines and inspection boundary

- exact identities/status for Coordinator, ES, and IM;
- committed facts versus local overlays;
- exact inspection scope and where inspection stopped.

B. One bounded RW0 scenario

Freeze one concrete first scenario with:

- repository and exact base identity treatment;
- allowed task/change class;
- WorkSpec custody source;
- host-qualification requirements;
- worker/supervisor topology;
- Codex invocation seam or explicit blocking decision;
- workspace/capsule/validation/review path;
- semantic-decision terminal outcomes;
- maximum effect ceiling;
- prohibited fallbacks and publication effects.

Do not choose a toy that bypasses the real authority, custody, process,
capsule, validation, or decision seams. Do keep the scenario small enough for
one bounded proof.

C. Current-versus-target ledger

For every material seam, classify:

- current contract/invariant;
- current compatibility edge;
- accepted strategic target;
- reopened target seam;
- implementation detail deferred;
- report-only uncertainty.

D. Authority, custody, and fact-owner matrix

For each material fact or material:

- author/authority;
- verifier;
- durable recorder;
- physical custodian;
- permitted safe Coordinator binding;
- prohibited retained material;
- freshness/revocation rule.

E. Identity and correlation matrix

Map every required identity from Section 41/C2B3D entry through worker,
capsule, validation, review, model proposal, and Coordinator decision. Preserve
all non-collapse requirements.

F. End-to-end durable/fact timeline

Show the ordered facts from:

selected proposal / author-effect intent
→ fresh verification
→ retrieval
→ delivery
→ acknowledgement/unknown
→ worker start
→ candidate capture
→ capsule seal
→ validation
→ independent review
→ model proposal
→ Coordinator decision
→ cleanup/custody terminal facts.

Separate Coordinator-owned durable facts from source observations and external
truth.

G. Failure, ambiguity, cancellation, and recovery matrix

For each externally visible phase include:

- failure/unknown event;
- authoritative fact owner;
- safe observation;
- durable Coordinator response;
- retry/redelivery eligibility;
- reconciliation requirement;
- stop condition;
- global-stop behavior;
- restart behavior;
- whether candidate/capsule may still exist.

H. Host, process, credential, and artifact boundary

Freeze the minimum first-slice boundary and explicitly defer the rest.

I. ES/IM dependency ledger

- what may be consumed as evidence;
- what remains owner-repo authority;
- what must be deferred;
- what requires a separate owner-repo decision before implementation.

J. Tranche map

Produce three to five coherent tranches from phase-entry contract through the
bounded end-to-end RW0 proof.

For each tranche provide:

- capability added;
- governing decisions required first;
- exact effect ceiling;
- likely maximum touched surfaces;
- dependencies;
- validation;
- audit perspectives;
- stop conditions;
- what remains unimplemented.

K. Recommended first tranche

Select exactly one next implementation tranche.

Provide:

- stable tranche ID and title;
- why it is the first critical-path increment;
- whether it is docs/tests-only, pure source, schema-bearing, packaging-only, or
  another type;
- exact maximum touched-file candidate allowlist;
- exact protected surfaces;
- expected test-node treatment;
- focused validation commands;
- whether a full suite is pre-audit or post-ACCEPT;
- provenance recipe treatment;
- independent-audit plan;
- feature-branch/PR/squash publication plan;
- completion token;
- hard stop conditions.

Do not recommend broad worker implementation unless the authority, custody,
delivery, process, capsule, failure, and decision model is already fully frozen
and source-grounded.

L. Open decisions

List any decision that remains genuinely architecture-defining. For each state:

- why current repo evidence cannot resolve it;
- who owns the decision;
- whether it blocks the first tranche or only a later tranche;
- the smallest follow-up reconnaissance needed.

FINAL VERDICT

Return exactly one:

RECONNAISSANCE_READY
RECONNAISSANCE_PARTIAL
RECONNAISSANCE_BLOCKED
SUBAGENT_UNAVAILABLE

If ready, include:

COORDINATOR_RW0_PHASE_ENTRY_PLAN_FROZEN

A ready verdict requires:

- one bounded scenario;
- one coherent authority/custody model;
- one exact first tranche;
- no unresolved decision that should be made before that tranche;
- exact validation, provenance, audit, and stop conditions;
- no repository mutation or remote contact.

NON-GOALS

Do not:

- implement any source or documentation;
- select a second productive direct-local slice;
- implement local Git;
- implement ES routing;
- widen Bridge;
- revive CP as target authority;
- make IM enduring architecture;
- create a public service/API/IPC;
- create a general scheduler, queue, or autonomous loop;
- treat model output, reports, or evidence as authority;
- assume raw WorkSpec custody or executable authorization already exists;
- install or invoke Codex, a model, a worker, or any live service;
- propose a seventh repository without demonstrated ownership/release need.
