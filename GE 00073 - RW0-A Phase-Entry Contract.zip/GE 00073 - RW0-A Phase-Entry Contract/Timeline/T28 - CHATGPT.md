## Verdict

**Codex stopped correctly under the audit prompt, but the mismatch is in the prompt’s evidence contract—not in the repository candidate or canonical manifest.**

Do **not** return to the workspace-write implementation conversation. Do **not** regenerate the closeout report, rerun tests, or change repository bytes.

The audit prompt incorrectly required the external report to:

1. Repeat the original predecessor manifest’s absolute pathname, even though the report referenced an immutable implementation-local copy with the same manifest hash.
2. Duplicate branch, HEAD, and upstream fields already carried by the canonical manifest and independently verifiable from live Git.

Those requirements are unnecessary for byte binding. The v1 canonical manifest itself records branch, HEAD, upstream, tracked-diff identity, and every changed path’s classification, mode, size, and SHA-256.   The external closeout report is evidence/projection; it does not become the authority for repository identity. 

## Correct reconciliation

The fresh auditor should safely verify three immutable files:

```text
Closeout report:
/private/tmp/ge-rw0a-third-repair-8fujftd9/
  final_provenance/report.json

SHA-256:
b445b1f04bce237c4d0938528f3a42874e1735297989c2373c6b11313ee74866
```

```text
Report-named opening copy:
/private/tmp/ge-rw0a-third-repair-8fujftd9/
  opening-target.json
```

```text
Original predecessor manifest:
/private/tmp/ge-rw0a-second-repair-m22z10x8/
  final_provenance/run-2-manifest.json
```

The two opening manifests must both be:

```text
2,328 bytes
SHA-256:
cdfc576d53de6d116e5a46131319927df2fd56f0774ac6815eb0e0dda61323c5
```

They must also be **byte-for-byte identical** and parse to the same canonical repository identity, path set, classifications, modes, sizes, and per-file hashes.

The final target remains:

```text
/private/tmp/ge-rw0a-third-repair-8fujftd9/
  final_provenance/run-2-manifest.json

2,328 bytes
SHA-256:
e46474d1b2af374e2bd84ded976e2bb1dd01399dfdc4a2b31b93bbd13f5c830e
```

Branch, HEAD, and upstream must come from:

- that final canonical manifest; and
- independent live Git inspection.

The report’s omission of those duplicated fields must not itself cause another mismatch.

## Why no new closeout report is needed

Generating a replacement report would create evidence churn without increasing provenance confidence. The currently pinned report remains useful for its validation records, per-file comparisons, node evidence, and final-manifest identity. Its opening-manifest pathname is simply an evidence alias.

A pathname is not repository authority. Exact safe bytes are what matter.

The audit should return `AUDIT_PROVENANCE_MISMATCH` only if:

- either opening manifest is unsafe or missing;
- their bytes or canonical contents differ;
- the final manifest does not match the live candidate;
- branch, HEAD, upstream, topology, modes, sizes, hashes, or tracked diff differ;
- the recipe output is unstable.

The auditor’s latest response explicitly states that the observed branch, HEAD, and ten-path state matched, and that it stopped before recipe execution or correctness inspection. Therefore, **the RW0-A implementation remains neither accepted nor blocked by that attempt; it remains unaudited on correctness.**

## Next action

Start another **fresh read-only Codex conversation** and send:

:chatgpt-content-reference{index="3"}

The corrected prompt:

- preserves the same final audit target;
- preserves the same contract and hostile-mutant audit;
- verifies the report’s actual `opening-target.json` pathname;
- requires byte equality with the original predecessor manifest;
- obtains Git identity from canonical provenance and live Git;
- explicitly prevents the harmless path alias or omitted duplicate report fields from causing another mismatch.

A successful audit must still return:

```text
ACCEPT

COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FREEZE_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

No commit or PR action is appropriate before that independent acceptance. The project protocol requires provenance verification before correctness inspection, but it also treats the canonical patch identity—not redundant report metadata—as the binding audit input.  Any actual byte change would require implementation, new provenance, and another audit; no byte change has occurred here. 

### Sources

- Latest Codex provenance-mismatch response supplied in this turn.
- Canonical manifest fields and deterministic recipe behavior. 
- Provenance establishes byte identity but not correctness or authority. 
- Fresh independent-audit protocol and provenance-first stop rule. 

**Confidence:** 99.5% that the stop was caused by an overconstrained audit prompt; 99% that no implementation or evidence regeneration is needed; 98% that byte-alias reconciliation plus canonical-manifest/live-Git verification restores a sound audit gate.
