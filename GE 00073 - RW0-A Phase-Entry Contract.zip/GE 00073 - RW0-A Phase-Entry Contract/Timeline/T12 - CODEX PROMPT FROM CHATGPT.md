TITLE

Coordinator RW0-A — normalize the Section 42 committed-status duplicate-marker
diagnostic and complete final validation

ENGAGEMENT TYPE

Bounded parent-only repair in the existing workspace-write implementation
conversation for:

COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1
RW0-A-PHASE-ENTRY-CONTRACT-FREEZE

Do not create or resume subagents. You are the sole repository writer.

The preceding continuation correctly stopped at its one-attempt targeted gate.
The candidate already rejects the duplicate committed-status block through the
existing marker-uniqueness assertion. The sole defect is that this valid
rejection does not emit the exact `C2B3C_STATUS_INVALID` diagnostic required by
the newly added causal control.

This turn explicitly authorizes:

- safe verification and immutable capture of the exact stopped ten-path
  candidate;
- mutation of exactly one path:
  `tests/test_c2b3c_author_effect_contract.py`;
- normalization of the committed-status marker-uniqueness failure to the
  existing `C2B3C_STATUS_INVALID` diagnostic;
- a fresh final validation sequence on the repaired bytes;
- final ten-path working-tree provenance.

This turn does not authorize:

- weakening the duplicate-marker control or accepting an arbitrary exception;
- any documentation change;
- any change to the other three RW0-A test files;
- any source, SQL, migration, schema, catalog, application-generation, package,
  public protocol, StateStore, WriterSession, fixture, script, config, runtime,
  worker, provider, Bridge, ES, or IM path;
- staging, commit, push, PR creation, merge, tag, release, or deployment;
- fetch, pull, remote contact, network access, model/provider invocation, Codex
  invocation, process/worker launch, SSH, live service, or live database
  contact;
- reset, clean, revert, branch switch, discard, or history rewrite.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED STOPPED STATE

Require exactly before mutation:

- Physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- HEAD tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- HEAD subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1
- Dirty paths:
  exactly 10
- Tracked modifications:
  exactly 8
- Untracked paths:
  exactly 2
- Staged/unmerged:
  0/0
- No deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  or Git lock
- Repository residue:
  empty
- `git diff --check HEAD --`:
  clean.

Require the exact ten-path set:

.docs/rw0-remote-worker-contact-phase-entry.md
.docs/c2b-durable-development-state.md
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_architecture_contracts.py
tests/test_c2b3c_author_effect_contract.py

Require mode posture:

- the original nine RW0-A candidate paths retain their opening file types and
  modes;
- `tests/test_c2b3c_author_effect_contract.py` is a regular file, owned by the
  current operator, working-tree mode `0600`, no execute bits;
- Git index mode for every tracked path is `100644`;
- no Git-recorded mode change exists.

Do not widen the authorized file to `0644`.

Stop without mutation on any mismatch. Do not fetch or absorb drift.

PRESERVED FAILURE EVIDENCE

Safely inspect, but do not modify:

/private/tmp/ge-coordinator-rw0a-section42-repair.6TasDc

Require:

- every path component lstat-safe and non-symlink;
- root operator-owned, non-symlink, mode 0700;
- `opening-manifest-immutable.json` is the retained exact nine-path pre-C2B3C
  target;
- `target.junit.xml` and the retained targeted result identify exactly:
  - one collected case;
  - one failed case;
  - no error, skip, xfail, or warning;
  - failure in
    `tests/test_c2b3c_author_effect_contract.py::
     test_current_status_regions_are_reconciled_without_historical_rewrite`;
  - failure at or corresponding to line 4553;
  - the duplicate committed-block mutant was rejected by the existing marker
    count assertion;
  - the test failed only because it required the exact
    `C2B3C_STATUS_INVALID` diagnostic;
- no repository mutation occurred after the targeted failure.

Treat this retained failure as causal predecessor-red evidence. Do not rerun the
pre-repair bytes.

If evidence is absent, unsafe, or contradictory, stop and return:

COORDINATOR_RW0_A_SECTION42_DIAGNOSTIC_REPAIR_EVIDENCE_MISMATCH

OPENING TEN-PATH PROVENANCE

Create one new external, operator-owned, non-symlink, mode-0700 repair evidence
root under `/private/tmp`.

Preserve safe metadata and hashes for the predecessor targeted failure in the
new evidence root without altering the original evidence.

Use the exact unchanged provenance recipe below twice before mutation.

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

Recipe requirements:

- source size:
  3,945 bytes
- source SHA-256:
  db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Safely classify:

/tmp/ge-coordinator-b3a-audit-manifest-v1.json

If it exists, require a regular non-symlink operator-owned file and preserve its
exact pre-run bytes and metadata externally. Do not delete unrelated evidence.

Require both opening recipe runs to:

- return 0;
- have empty stderr;
- produce byte-identical complete stdout;
- produce byte-identical canonical manifests;
- identify the exact branch, HEAD, upstream, and ten-path set;
- classify exactly eight entries as `tracked_modified`;
- classify exactly two entries as `untracked`;
- record the C2B3C path as regular working-tree mode `0600`;
- record no deletion, rename, symlink, or unsupported type.

Freeze one immutable mode-0400 copy of the opening ten-path manifest.

Compare it with:

/private/tmp/ge-coordinator-rw0a-section42-repair.6TasDc/opening-manifest-immutable.json

Require:

- the retained nine paths match exactly in path, kind, type, mode, size, and
  SHA-256;
- exactly one additional path is present:
  `tests/test_c2b3c_author_effect_contract.py`;
- the additional path is `tracked_modified`, regular mode `0600`;
- no other difference exists.

Report the current opening manifest size and SHA-256.

MAXIMUM AUTHORIZED MUTATION

Exactly one path:

tests/test_c2b3c_author_effect_contract.py

Preserve:

- regular file type;
- working-tree mode `0600`;
- current-operator ownership;
- no execute bits;
- Git index mode `100644`;
- no Git-recorded mode change.

Prefer an in-place edit. If the editing mechanism changes the working-tree
permission, the only permission correction authorized is restoring this exact
path to `0600` before validation and provenance. Record that correction
explicitly.

The other nine candidate entries must remain byte-identical to the immutable
opening ten-path manifest.

No eleventh dirty path is permitted.

DEFECT CLASSIFICATION

This is a test-helper diagnostic-consistency defect, not a contract,
documentation, or structural-acceptance defect.

The duplicate-block mutant is already rejected correctly because the committed
status begin/end markers are required to be globally unique.

The test must continue to reject the duplicate. Do not weaken marker uniqueness,
do not accept the mutant, and do not broaden the test to accept arbitrary
assertion failures.

REQUIRED REPAIR

Modify the existing C2B3C test-only helper so that every committed-status marker
uniqueness failure uses the same established exact diagnostic:

`C2B3C_STATUS_INVALID`

Specifically:

1. Replace raw marker-count assertions for the committed-status begin/end
   markers with an explicit fail-closed branch that raises the same assertion
   type and exact `C2B3C_STATUS_INVALID` diagnostic used by the helper’s other
   structural/current-status failures.

2. Require exactly one begin marker and exactly one end marker in the complete
   document.

3. Preserve the existing exact-offset and exact-block checks.

4. Preserve the repaired behavior that accepts later governed H3-or-deeper
   Section 42 extensions after the exact committed-status block.

5. Preserve rejection of:
   - duplicate committed-status markers/blocks;
   - a committed block moved away from the frozen offset;
   - mutations inside the committed block;
   - missing or swapped implementation commits;
   - report/audit ownership of Git truth;
   - broadened supersession;
   - current model/provider/runtime/public-surface capability claims;
   - visible H1/H2 successor such as Section 43.

6. Do not change the accepted owner document, RW0-A document, or any other test.

CAUSAL DUPLICATE CONTROL

Keep the existing duplicate-block mutant in:

tests/test_c2b3c_author_effect_contract.py::
test_current_status_regions_are_reconciled_without_historical_rewrite

Require the mutant to remain otherwise valid:

- exact committed block at the frozen offset;
- valid later H3 extension;
- second exact committed block after that extension;
- exactly two begin and two end marker occurrences;
- no unrelated semantic mutation.

Require the authoritative helper to reject it with exact diagnostic:

`C2B3C_STATUS_INVALID`

Do not replace this with a generic `pytest.raises(AssertionError)` or
`pytest.raises(Exception)` expectation.

Retain the broken EOF compatibility control and all previously added positive
extension, internal-block mutation, relocation, duplicate, H2-successor,
commit-swap, report-authority, broadened-supersession, and capability-overclaim
controls.

TEST-NODE BOUNDARY

Do not add, remove, rename, skip, xfail, decorate, parameterize, collapse, or
weaken any test.

Before mutation, collect exactly once under the isolated posture:

1. Complete repository:
   exactly 4,284 nodes.

2. Direct RW0-A test:
   exactly 28 nodes.

3. C2B3C test file:
   exactly 46 nodes.

4. The two other existing RW0-A modified test files:
   retain their ordered node lists and counts.

After final bytes freeze, require literal byte-for-byte equality with every
opening ordered node list.

VALIDATION ISOLATION

Use the new repair evidence root.

For every pytest child:

- save actual caller umask;
- create evidence under secure posture;
- restore caller umask before launch;
- record child-observed umask and require numerical equality;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`
  - `LC_ALL=C`
  - `LANG=C`
  - `PYTHONDONTWRITEBYTECODE=1`
  - distinct external `PYTHONPYCACHEPREFIX`
  - distinct external `TMPDIR`
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
  - `PYTEST_ADDOPTS=''`
  - `PYTHONHASHSEED=0`
  - `python3 -B -m pytest`
  - `-p no:cacheprovider`
  - `-W error`
  - distinct external `--basetemp`
  - external `--junitxml`
  - serial execution.

Retain exact argv, environment, caller/child umask, return code, elapsed time,
stdout/stderr/JUnit sizes and SHA-256, parsed counts, warnings, parse errors,
unmapped cases, and before/after repository identity.

TARGETED GREEN GATE — EXACTLY ONCE

After repairing only the authorized C2B3C test, run exactly:

tests/test_c2b3c_author_effect_contract.py::
test_current_status_regions_are_reconciled_without_historical_rewrite

Require:

- 1 collected;
- 1 passed;
- zero failure, error, skip, xfail, or warning;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository identity unchanged.

Do not run a second targeted attempt if terminal evidence is lost.

COMPLETE C2B3C REGRESSION

Run:

tests/test_c2b3c_author_effect_contract.py

Require exactly 46/46 green.

DIRECT RW0-A ORACLE REGRESSION

Run:

tests/test_rw0_remote_contact_phase_entry_contract.py

Require exactly 28/28 green.

COMPLETE RW0-A FOCUSED REGRESSION

Run exactly:

tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_software_development_progression_boundary.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_worker_execution_semantic_boundaries.py

Require exactly 1,565/1,565 green.

If any named file is absent, stop rather than substituting.

FINAL NODE COLLECTION

After targeted and focused validation plus cleanup:

- collect the complete repository exactly once;
- require exactly 4,284 nodes;
- require literal equality with the opening list;
- require direct test remains 28 nodes;
- require C2B3C remains 46 nodes;
- require the other two modified test-file lists remain exact;
- require no added, removed, renamed, skipped, xfailed, collapsed, or
  re-parameterized node.

FULL SUITE — EXACTLY ONCE

Only after all prior gates and artifact cleanup pass, run exactly once:

python3 -B -m pytest -p no:cacheprovider -W error \
  --basetemp=<external> \
  --junitxml=<external> \
  .

Require exactly:

- 4,284 collected;
- 4,284 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository bytes, topology, mode posture, and node identity unchanged
  before/after.

Do not run a second full-suite attempt.

FINAL CONTRACT AND PATH GUARDS

Require:

- exactly 10 dirty paths;
- exactly 8 tracked modifications;
- exactly 2 untracked files;
- zero staged/unmerged paths;
- original nine candidate entries unchanged from the opening ten-path manifest;
- only the C2B3C entry changed from the opening ten-path manifest;
- C2B3C remains regular mode `0600`, no execute bits, Git index mode `100644`;
- all six documentation files byte-identical;
- all three earlier RW0-A test entries byte-identical;
- append-only C2B prefix exact;
- final H2 remains Section 42;
- RW0-A H3 visible, unique, unfenced, and subordinate;
- exact committed-status block remains at the frozen offset and globally unique;
- duplicate marker failures emit exact `C2B3C_STATUS_INVALID`;
- four RW0 cross-reference bodies normalized-identical;
- authority model, target/current distinction, deferred seams, fixture
  non-authority, one-delivery ceiling, terminal outcomes, cancellation order,
  and ES/IM non-absorption unchanged;
- no source/schema/migration/public/runtime capability exists or is claimed;
- `git diff --check` clean;
- no cache, bytecode, pytest cache, database, journal, WAL/SHM, build output,
  archive, generated manifest, or OS metadata;
- no Git operation or lock;
- no remote contact.

FINAL PROVENANCE

After final validation and cleanup, run the exact unchanged provenance recipe
twice again.

Require:

- both return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- exactly 10 entries;
- exactly 8 `tracked_modified`;
- exactly 2 `untracked`;
- C2B3C entry regular mode `0600`;
- all other entries retain their opening modes;
- no deletion, rename, symlink, Git-recorded mode change, or unsupported type.

Compare final manifest with the immutable opening ten-path target and prove:

- exactly one changed entry:
  `tests/test_c2b3c_author_effect_contract.py`;
- the other nine entries exact;
- path classifications unchanged;
- no mode drift;
- no additional path.

Report:

- opening ten-path manifest path, size, and SHA-256;
- final manifest path, size, and SHA-256;
- exact one-entry opening/final size/hash comparison;
- recipe source size/hash;
- complete-output size/hash;
- tracked textual-diff hash;
- retained targeted-red evidence hashes;
- targeted, C2B3C, direct, focused, collection, and full-suite evidence
  paths/hashes;
- opening/final node-list hashes and equality;
- final path, mode, historical, residue, and no-effect guards.

Do not stage. The final working-tree manifest is the future independent-audit
target.

STOP CONDITIONS

Stop without further mutation if:

- opening state, evidence, path set, mode posture, or node count differs;
- documentation or another test/source path appears necessary;
- exact diagnostic normalization would require weakening marker uniqueness;
- the duplicate mutant cannot remain otherwise valid and causally isolated;
- any existing node must change;
- targeted, file, direct, focused, collection, or full-suite validation is not
  exact-green;
- another path changes;
- C2B3C cannot remain mode `0600` with Git index mode `100644`;
- final provenance is unstable;
- remote contact, staging, publication, worker/model/process activity, or
  supporting-repository mutation would be required.

On stop, preserve exact state and evidence. Do not reset, clean, revert, switch
branches, stage, or discard work.

CLOSEOUT

Return exactly:

COORDINATOR_RW0_T1_SECTION42_STATUS_EXTENSION_COMPATIBILITY_REPAIRED_READY_FOR_INDEPENDENT_AUDIT

only if:

- duplicate committed-status markers remain fail-closed;
- marker-uniqueness rejection uses exact `C2B3C_STATUS_INVALID`;
- later governed Section 42 H3 extensions remain accepted;
- all stopped-candidate bytes except the authorized C2B3C test remain exact;
- targeted, focused, node, and full-suite validation are exact-green;
- final ten-path provenance is stable;
- no docs, source, schema, runtime, remote, staging, or publication effect
  occurred.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
