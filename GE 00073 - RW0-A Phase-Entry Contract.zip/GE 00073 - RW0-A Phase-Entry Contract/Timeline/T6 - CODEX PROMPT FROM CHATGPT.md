TITLE

Coordinator RW0-A — repair the terminal-outcome region oracle and complete the
phase-entry contract-freeze validation

ENGAGEMENT TYPE

Bounded parent-only repair in the existing workspace-write implementation
conversation for:

COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1
RW0-A-PHASE-ENTRY-CONTRACT-FREEZE

Do not create or resume subagents. You are the sole repository writer.

This turn explicitly authorizes:

- verification and immutable capture of the stopped nine-path candidate;
- mutation of exactly one existing candidate path:
  `tests/test_rw0_remote_contact_phase_entry_contract.py`;
- repair of the terminal-outcome region oracle and its existing causal mutant;
- a fresh validation sequence on the repaired bytes;
- final nine-path working-tree provenance.

This turn does not authorize:

- any documentation change;
- any change to the two existing modified test files;
- any source, SQL, migration, schema, catalog, application-generation, package,
  public protocol, StateStore, WriterSession, fixture, script, config, runtime,
  worker, provider, Bridge, ES, or IM path;
- staging, commit, push, PR creation, merge, tag, release, or deployment;
- fetch, pull, remote contact, network access, model/provider invocation, Codex
  invocation, process/worker launch, SSH, live service, or live database contact;
- reset, clean, revert, branch switch, discard, or history rewrite.

The previous turn stopped correctly at its mandatory green gate. Do not treat
that stop as permission to alter the governing RW0-A contract.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED STOPPED STATE

Require exactly before mutation:

- Physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- HEAD tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- HEAD subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1
- Dirty paths:
  exactly 9
- Tracked modifications:
  exactly 7
- Untracked paths:
  exactly 2
- Staged/unmerged:
  0/0
- Every candidate path:
  regular mode 0644
- No deletion, rename, copy, symlink, mode change, Git operation, or Git lock
- Repository residue:
  empty
- `git diff --check HEAD --`:
  clean.

Require the exact nine-path set:

.docs/rw0-remote-worker-contact-phase-entry.md
.docs/c2b-durable-development-state.md
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_architecture_contracts.py

Stop without mutation on any mismatch. Do not fetch or absorb drift.

PRESERVED IMPLEMENTATION EVIDENCE

Safely inspect, but do not modify, the retained implementation evidence root:

/private/tmp/ge-coordinator-rw0a-evidence.JWHS6a

Require:

- every path component lstat-safe and non-symlink;
- root operator-owned, non-symlink, mode 0700;
- retained green-attempt stdout/JUnit/result/environment/umask records identify
  exactly 28 collected cases, 27 passed, 1 failed;
- the sole failure is the existing causal mutant at or corresponding to
  `tests/test_rw0_remote_contact_phase_entry_contract.py:508`;
- the failure demonstrates that the mutant changed only the first of two
  terminal-outcome inventories while the second intact inventory incorrectly
  satisfied the validator;
- no repository mutation occurred after that terminal failure.

The retained 27/1 run is the causal predecessor-red evidence for this repair.
Do not rerun the pre-repair test state merely to manufacture another red record.
If the evidence root is missing, unsafe, or contradicts the report, stop and
return:

COORDINATOR_RW0_A_TERMINAL_ORACLE_REPAIR_EVIDENCE_MISMATCH

OPENING REPAIR PROVENANCE

Create one new operator-owned, non-symlink, mode-0700 repair evidence root under
`/private/tmp`.

Copy safe metadata and hashes for the retained predecessor-red records into the
new repair evidence root without altering the original evidence.

Use the exact unchanged provenance recipe below twice before mutation.

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

Recipe requirements:

- source size:
  3,945 bytes
- source SHA-256:
  db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Safely classify the fixed output path:

/tmp/ge-coordinator-b3a-audit-manifest-v1.json

If it exists, require a regular non-symlink operator-owned file and preserve its
exact pre-run bytes and metadata externally. Do not delete unrelated evidence.

Require both opening recipe runs to:

- return 0;
- have empty stderr;
- produce byte-identical complete stdout;
- produce byte-identical canonical manifests;
- identify the exact branch, HEAD, upstream, and nine-path set above;
- classify exactly seven entries as `tracked_modified` and two as `untracked`;
- classify every entry as regular mode 0644;
- contain no deletion, rename, symlink, or unsupported type.

Freeze one immutable mode-0400 copy of the opening canonical manifest as the
repair-opening target. Report its exact size and SHA-256.

MAXIMUM AUTHORIZED MUTATION

Exactly one path:

tests/test_rw0_remote_contact_phase_entry_contract.py

This path must remain `untracked`, regular, mode 0644.

The other eight candidate entries—including all six documentation paths and the
two existing test files—must remain byte-identical to the immutable repair-
opening target.

No tenth dirty path is permitted.

DEFECT TO REPAIR

The stopped candidate contains two intentional terminal-outcome inventories in
the authoritative RW0 owner document:

1. the structurally bounded `Bounded RW0 scenario class` region; and
2. the structurally bounded `Capsule, validation, review, model, and decision`
   region.

Both must independently state the exact ordered terminal decision domain:

`accept`, `repair`, `replan`, `terminal_reject`, `block`, `cancel`

The predecessor validator accepted a mutant that altered only the first
inventory because the intact second inventory satisfied a whole-document/global
presence check.

The repair must make each inventory an independently owned current contract.
One region may not satisfy the other.

STRUCTURAL ORACLE REQUIREMENTS

Repair the existing test-only validator; do not alter documentation.

Use the test file’s bounded Markdown structural model, or strengthen one local
fence-aware ATX model in that file. Do not add a global raw-text fallback.

For each of the two terminal-outcome regions require:

1. one unique visible heading/owner event in the authoritative owner document;
2. one exact owner range ending at the next visible heading of the same or
   higher level;
3. the terminal-outcome inventory is parsed only from the inventory sentence or
   list owned by that exact range;
4. the parsed ordered tuple is exactly:
   (`accept`, `repair`, `replan`, `terminal_reject`, `block`, `cancel`);
5. no missing, duplicate, reordered, substituted, or seventh outcome;
6. the inventory is visible and outside every supported backtick/tilde fence;
7. an inventory in the other owner range cannot satisfy this region;
8. unrelated later references to `accept`, `block`, `cancel`, or the latch do
   not count as the inventory;
9. both regions independently retain “every outcome ends RW0” and “no successor
   launch” semantics where owned by the current document;
10. the authoritative positive document is validated through the same complete
    region-scoped oracle used by the mutants.

Prefer deriving the exact inventory from stable owner phrases and structurally
bounded list/sentence tokens. Do not establish correctness with whole-document
`in`, `count`, `find`, `index`, or an unscoped regular expression.

CAUSAL MUTANTS

Strengthen the existing failing test node; do not add or parameterize a test
node.

Within that existing node, require at least these independent mutants:

A. Remove or replace `cancel` only in the bounded-scenario inventory while
   leaving the decision inventory exact — reject with a scenario-region
   diagnostic.

B. Remove or replace `repair` only in the decision inventory while leaving the
   bounded-scenario inventory exact — reject with a decision-region diagnostic.

C. Reorder two outcomes only in the scenario inventory — reject.

D. Add a seventh outcome such as `retry` only in the decision inventory —
   reject.

E. Move one exact inventory beneath an irrelevant or fenced sibling while the
   other region remains exact — reject.

F. Positive control: both exact inventories present in their own visible owner
   ranges — accept.

For A–E, preserve the other inventory and the rest of the document so the
failure is causally attributable to the mutated region.

MUTATION-SENSITIVITY CONTROL

Retain or construct a clearly named broken whole-document outcome checker that:

- accepts mutant A because the second inventory remains intact;
- accepts mutant B because the first inventory remains intact;
- is never used as the authoritative positive oracle.

Require the final region-scoped checker to reject the same bytes. This control
must fail if the test ceases to reproduce the predecessor defect.

TEST-NODE BOUNDARY

Do not add, remove, rename, skip, xfail, decorate, or parameterize any test.

Before mutation, collect exactly once under the isolated posture:

- complete repository node list;
- new direct test file node list;
- the two existing candidate-modified test-file node lists.

Require:

- complete stopped-candidate collection:
  exactly 4,284 nodes;
- `tests/test_rw0_remote_contact_phase_entry_contract.py`:
  exactly 28 nodes;
- every original baseline node remains present;
- no node change is authorized by this repair.

After final bytes freeze, require literal byte-for-byte equality with all opening
ordered node lists.

If the stopped-candidate collection is not exactly 4,284 or the new file is not
exactly 28, stop before mutation and report the observed discrepancy.

VALIDATION ISOLATION

Use the new repair evidence root.

For every pytest child:

- save actual caller umask;
- create evidence under secure posture;
- restore caller umask before launch;
- record child-observed umask and require numerical equality;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`
  - `LC_ALL=C`
  - `LANG=C`
  - `PYTHONDONTWRITEBYTECODE=1`
  - distinct external `PYTHONPYCACHEPREFIX`
  - distinct external `TMPDIR`
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
  - `PYTEST_ADDOPTS=''`
  - `PYTHONHASHSEED=0`
  - `python3 -B -m pytest`
  - `-p no:cacheprovider`
  - `-W error`
  - distinct external `--basetemp`
  - external `--junitxml`
  - serial execution.

Retain exact argv, environment, caller/child umask, return code, elapsed time,
stdout/stderr/JUnit sizes and SHA-256, parsed counts, warnings, parse errors,
unmapped cases, and before/after repository identity.

REPAIR GREEN GATE — EXACTLY ONCE

After repairing only the authorized test file, run:

tests/test_rw0_remote_contact_phase_entry_contract.py

exactly once.

Require exactly:

- 28 collected;
- 28 passed;
- 0 failed;
- 0 errors;
- 0 skipped;
- 0 xfailed;
- 0 warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository identity unchanged before and after.

This is a new post-repair green attempt, not a rerun of the predecessor bytes.
Do not run a second attempt if terminal evidence is lost.

FOCUSED REGRESSION

After the direct oracle passes, run exactly this complete focused set:

tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_software_development_progression_boundary.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_worker_execution_semantic_boundaries.py

Require every collected case passed, with zero failure, error, skip, xfail,
warning, stderr, JUnit parse error, or unmapped case.

If a named file is absent on the exact candidate, stop rather than substituting.

FINAL NODE COLLECTION

After focused validation and cleanup:

- collect the complete repository exactly once;
- require exactly 4,284 nodes;
- require literal equality with the stopped-candidate opening list;
- require the direct file remains exactly 28 nodes;
- require the two existing modified test-file lists remain exact;
- require no added, removed, renamed, skipped, xfailed, collapsed, or
  re-parameterized node.

FULL SUITE — EXACTLY ONCE

Only after the repair green gate, focused regression, final node identity, path
boundary, and artifact cleanup are green, run the complete suite exactly once:

python3 -B -m pytest -p no:cacheprovider -W error   --basetemp=<external>   --junitxml=<external>   .

Require exactly:

- 4,284 collected;
- 4,284 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository bytes and topology unchanged before/after.

Do not run a second full-suite attempt. If it is not exact-green or terminal
evidence is lost, stop without further repository mutation.

FINAL CONTRACT AND PATH GUARDS

Require:

- exactly nine dirty paths;
- exactly seven tracked modifications and two untracked files;
- zero staged/unmerged paths;
- every candidate path regular mode 0644;
- exactly one entry changed from the immutable repair-opening target:
  `tests/test_rw0_remote_contact_phase_entry_contract.py`;
- that entry remains `untracked` and mode 0644;
- the other eight entries remain byte-identical;
- all six documentation files remain byte-identical;
- both existing test files remain byte-identical;
- the append-only C2B opening prefix remains exact;
- final H2 remains Section 42;
- four RW0 cross-reference bodies remain normalized-identical;
- the corrected authority model, target/current distinction, deferred seams,
  fixture non-authority, one-delivery ceiling, cancellation ordering, and
  ES/IM non-absorption remain unchanged;
- no source/schema/migration/public/runtime capability exists or is claimed;
- `git diff --check` clean;
- no repository cache, bytecode, pytest cache, database, journal, WAL/SHM,
  build output, archive, generated manifest, or OS metadata;
- no Git operation or lock;
- no remote contact.

Because the sole repair path is untracked, require the tracked textual-diff
SHA-256 in the final manifest to equal the repair-opening manifest’s tracked
textual-diff SHA-256. The canonical manifest SHA-256 must change because the
untracked test bytes changed.

FINAL PROVENANCE

After final validation and cleanup, run the exact unchanged provenance recipe
twice again.

Require:

- both return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- exactly nine entries;
- seven `tracked_modified` and two `untracked`;
- all regular mode 0644;
- no deletion, rename, symlink, or unsupported type.

Compare final manifest with the immutable repair-opening target and prove:

- exactly one changed entry, the authorized untracked direct test;
- other eight entries exact;
- tracked diff digest unchanged;
- no path classification or mode changed.

Report:

- opening repair manifest path, size, and SHA-256;
- final manifest path, size, and SHA-256;
- exact one-entry opening/final size/hash comparison;
- recipe source size/hash;
- complete-output size/hash;
- tracked textual-diff hash;
- predecessor-red evidence hashes;
- repair-green, focused, collection, and full-suite records/hashes;
- opening/final node-list hashes and equality;
- final guard and residue evidence.

Do not stage. The final working-tree manifest is the future independent-audit
target.

STOP CONDITIONS

Stop without further mutation if:

- opening state, evidence, path set, or node count differs;
- a documentation or second test-file change appears necessary;
- region-scoped outcome ownership cannot be established from the existing
  document without altering prose;
- the broken whole-document control does not reproduce the predecessor defect;
- an existing test node must change;
- direct, focused, collection, or full-suite validation is not exact-green;
- another path changes;
- final provenance is unstable;
- remote contact, staging, publication, worker/model/process activity, or
  supporting-repository mutation would be required.

On stop, preserve exact state and evidence. Do not reset, clean, revert, switch
branches, stage, or discard work.

CLOSEOUT

Return exactly:

COORDINATOR_RW0_T1_TERMINAL_OUTCOME_ORACLE_REPAIRED_READY_FOR_INDEPENDENT_AUDIT

only if:

- both terminal-outcome inventories are independently and causally enforced;
- the predecessor whole-document defect is reproduced by a broken control and
  rejected by the final oracle;
- all 28 direct tests pass;
- focused and full-suite validation are exact-green;
- all stopped-candidate nodes remain exact;
- only the authorized untracked test changed;
- final provenance is stable;
- no docs, source, schema, runtime, remote, staging, or publication effect
  occurred.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
