## Verdict

**Codex stopped correctly. Expand the repair scope by exactly one existing test file; do not change the RW0-A contract or documentation.**

The full suite exposed a genuine collateral incompatibility:

```text
tests/test_c2b3c_author_effect_contract.py
```

Its `_section_42_committed_status()` helper currently requires:

```python
suffix == EXPECTED_SECTION_42_COMMITTED_STATUS
```

That assertion made sense when the committed-status successor was the final byte range in `.docs/c2b-durable-development-state.md`. RW0-A legitimately appends a later **H3 strategic-target cross-reference inside the existing final H2 Section 42**. The old test therefore confuses ownership of the exact committed-status block with ownership of the entire future tail of Section 42.

The full suite did its job: the direct RW0-A oracle is now correct, all 28 direct cases pass, the 1,565-case focused regression passes, and node identity is exact. The only remaining problem is this stale cross-tranche test assumption.

## Correct repair

Authorize one additional path:

```text
tests/test_c2b3c_author_effect_contract.py
```

The final candidate should therefore contain:

```text
dirty paths:          10
tracked modifications: 8
untracked files:       2
staged/unmerged:      0/0
```

All nine stopped-candidate paths—including every RW0-A document and the repaired direct oracle—must remain byte-identical.

The C2B3C test should continue to own and enforce:

- the exact historical opening prefix;
- the exact committed-status block at its frozen byte offset;
- unique committed-status markers;
- both implementation commit identities;
- Git/report authority separation;
- status-only supersession;
- the existing non-capability and public-surface assertions;
- no H2 Section 43.

It should **not** require that the committed-status block is the end of the file. It should normalize and return only that exact block, while permitting later structurally governed H3-or-deeper extensions under Section 42.

The detailed RW0-A extension remains owned by:

```text
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
```

The C2B3C test must not copy or semantically re-own the RW0-A contract.

## Causal controls

The bounded repair prompt requires the existing C2B3C node to demonstrate:

- a correct committed-status block followed by a later H3 extension is accepted;
- a mutation inside the committed block is rejected even with a valid extension;
- relocating the committed block away from its fixed offset is rejected;
- duplicating the committed block later in the document is rejected;
- adding H2 Section 43 is rejected;
- a deliberately broken EOF checker rejects the valid extension case while the repaired region-scoped checker accepts it.

No test node may be added, removed, renamed, skipped, parameterized, or weakened.

## Validation sequence

The retained `4,283 passed / 1 failed` suite is the predecessor-red evidence. It should not be rerun on the old bytes.

After the one-file repair:

```text
targeted failing node:       1/1
complete C2B3C test file:   46/46
direct RW0-A oracle:        28/28
focused RW0-A regression: 1,565/1,565
complete node collection: 4,284 unchanged
full suite:               4,284/4,284
```

The complete suite gets exactly one fresh attempt on the new final bytes.

Final provenance must contain exactly ten paths. Relative to the repair-opening nine-path manifest, only `tests/test_c2b3c_author_effect_contract.py` may be newly dirty; the original nine entries must remain byte-identical.

## Next action

Resume the same workspace-write Codex conversation and send:

:chatgpt-content-reference{index="3"}

A successful closeout should return:

```text
COORDINATOR_RW0_T1_SECTION42_STATUS_EXTENSION_COMPATIBILITY_REPAIRED_READY_FOR_INDEPENDENT_AUDIT
```

Then proceed with:

```text
one-file collateral test repair
→ exact-green full suite
→ ten-path provenance
→ fresh independent audit
→ ACCEPT
→ feature-branch commit and PR gate
```

The frozen RW0 scenario still requires one of six terminal decisions and ends without a successor launch, Git effect, or publication; nothing about this failure reopens that design.  Changed bytes must receive fresh validation, provenance, and independent re-audit before publication.  Provenance will bind the later auditor to the exact ten-path candidate, but it does not itself establish correctness or test sufficiency. 

### Sources

- :chatgpt-content-reference{index="4"}
- Codex stopped-state report supplied in this turn.
- Governed repair and re-audit protocol. 
- Provenance authority and confidence boundaries. 

**Confidence:** 99.5% that the stop is a stale collateral-test issue rather than an RW0-A design defect; 99% that the required repository expansion is exactly one existing test file.
