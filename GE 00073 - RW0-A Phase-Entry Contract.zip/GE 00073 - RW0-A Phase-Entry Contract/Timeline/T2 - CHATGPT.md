## RW0 starts now

The read-only phase-entry reconnaissance prompt is ready:

:chatgpt-content-reference{index="2"}

Send it in a **fresh read-only Codex conversation**.

It binds the investigation to the merged Coordinator baseline:

```text
Branch: trunk_dev
Commit: 1a894c5527c610ab40d8e5ae5e530a762c6e60bf
Tree:   53c1834e7e3364c9b278153d5be8b0315d88ff5c
```

The prompt does not authorize implementation. It uses four bounded explorers to freeze the operating model before source choices harden unresolved architecture:

1. Authority, WorkSpec custody, retrieval, and privacy.
2. Durable progression, delivery ambiguity, replay/recovery, and schema.
3. Qualified host, worker/supervisor process boundary, Codex invocation, and capsule custody.
4. Validation, review, model proposal, semantic decision, cancellation, and future ES conformance.

The bounded end-to-end target is:

```text
selected pre-execution proposal and author-effect intent
→ fresh external verification
→ attempt-bound WorkSpec retrieval
→ one qualified remote Linux host
→ process-separated coding worker
→ immutable candidate capsule
→ validation and independent review
→ non-authoritative model review proposal
→ durable Coordinator semantic decision
→ no Git effect
→ no publication
```

The parent must return one concrete scenario, one authority/custody model, a full fact and identity timeline, a failure/recovery matrix, three to five coherent tranches, and **one exact recommended first implementation tranche**. A ready response ends with:

```text
RECONNAISSANCE_READY

COORDINATOR_RW0_PHASE_ENTRY_PLAN_FROZEN
```

The prompt permits bounded read-only inspection of committed ES and IM contracts, but prevents either repository’s proof scaffolding or uncommitted local state from defining Coordinator architecture. It also preserves the current facts that executable authorization, raw WorkSpec custody, worker execution, capsule storage, observation ingest, post-execution decision runtime, Git effects, and ES routing are not implemented.

This follows the project’s established sequence: read-only explorers first, parent reconciliation and tranche freeze, then a separate parent-only write turn; independent audit remains a fresh later conversation.  The snapshot used for grounding is the newly merged Coordinator baseline:

:chatgpt-content-reference{index="3"}

### Sources

- Merged Coordinator snapshot above.
- Read-only reconnaissance, parent synthesis, and two-turn implementation protocol.  
- Provenance remains evidence rather than correctness or authority. 

**Confidence:** 99% that this is the correct next critical-path step; 96% that the reconnaissance will be sufficient to select the first RW0 implementation tranche without another broad architecture pass.
