TITLE

Coordinator RW0-A phase-entry contract freeze — audited-byte commit, feature push, and PR gate

ENGAGEMENT

Commit/publication gate for the independently accepted exact candidate in:

/Users/ds/Repositories/Governed Execution Coordinator/

Workstream: COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1
Tranche: RW0-A-PHASE-ENTRY-CONTRACT-FREEZE

The fresh independent audit returned:

ACCEPT
COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FREEZE_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

It found no Critical, High, Medium, or Low patch defect and independently passed 28/28 direct RW0-A, 30/30 architecture, 774/774 remote-worker, 46/46 protected C2B3C, 1,565/1,565 focused, and 4,284/4,284 full-suite tests. Do not repeat the independent audit.

AUTHORIZED EFFECTS

Authorized only:

1. verify the exact audited bytes and remote base;
2. stage exactly the ten audited paths;
3. run final validation without changing bytes;
4. create exactly one commit;
5. push exactly one new feature ref;
6. create exactly one open non-draft PR to trunk_dev.

No implementation repair is authorized. Do not edit, format, chmod, generate repository files, amend, rebase, merge, reset, clean, tag, release, deploy, delete a branch, enable auto-merge, submit a review, self-approve, resolve a thread, or push directly to trunk_dev. Do not use force, force-with-lease, admin, bypass, or alternate-history options. No subagents.

AUDITED TARGET

Use exactly:

/private/tmp/ge-rw0a-fourth-repair-nlhdj0o8/final-canonical-manifest.json

Require safe path components, operator ownership, regular non-symlink mode 0400 file beneath a non-symlink mode 0700 root, size 2,328 bytes, SHA-256:

3d880594f269d8bb7f13479df50cf4cd5b24b7dd6e913620517cd8c15c24ccf2

Parse and require:

- recipe_id: governed-execution.audit-patch-manifest.v1
- branch: codex/rw0-phase-entry-contract-freeze
- head: 1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream: origin/trunk_dev
- textual_diff_sha256: 0c0f284cc1b11a22540903ccef874a96bd69f7982c5e92028fdac2298164eecf
- exactly 10 entries: 8 tracked_modified and 2 untracked

Exact paths:

.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/c2b-durable-development-state.md
.docs/durable-state-model.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/worker-execution-boundary.md
tests/test_architecture_contracts.py
tests/test_c2b3c_author_effect_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py

Opening tracked modifications are all except the two untracked paths:

.docs/rw0-remote-worker-contact-phase-entry.md
tests/test_rw0_remote_contact_phase_entry_contract.py

Working-tree modes: nine paths 0644; tests/test_c2b3c_author_effect_contract.py 0600. Do not chmod it. Every staged and committed Git mode must be 100644.

Verify but do not modify:

- final guard: /private/tmp/ge-rw0a-fourth-repair-nlhdj0o8/final-guard.json, 6,435 bytes, SHA-256 0e0e0a5b2e94410654cefad7ee3d1fe48a8657a9ed8fb7481e71b187adae1259
- closeout report: /private/tmp/ge-rw0a-fourth-repair-nlhdj0o8/final-closeout-report.json, 21,813 bytes, SHA-256 549b7c1791501f5ab3636bfcf3d43dc844343f1515ee0de260db84161359da22
- evidence index: /private/tmp/ge-rw0a-fourth-repair-nlhdj0o8/final-evidence-index.json, 18,140 bytes, SHA-256 85b129525c541f1c0c7849d3e53be710f5b7673942b58848171f049bbfc51565

Require report.guard_evidence to bind the exact guard and the index to bind the report and guard.

OPENING LOCAL GATE

Before remote contact or staging require exactly:

- root: /Users/ds/Repositories/Governed Execution Coordinator/
- branch: codex/rw0-phase-entry-contract-freeze
- HEAD: 1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- tree: 53c1834e7e3364c9b278153d5be8b0315d88ff5c
- sole parent: 394d625aa63935140eeaf88ecff6f59f0547cb7e
- subject: docs: normalize Coordinator post-publication status (#1)
- upstream/local origin/trunk_dev: 1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- ahead/behind 0/0; one worktree
- exactly 10 dirty paths: 8 tracked modifications and 2 untracked
- staged/unmerged 0/0
- no tracked add/delete/rename/copy, symlink, Git-recorded mode change, Git operation, lock, or residue
- git diff --check HEAD -- clean

Require every live path, classification, file type, working-tree mode, byte size, and SHA-256 to match the audited manifest. Stop before remote contact or staging on any mismatch.

EVIDENCE ROOT

Create one operator-owned, non-symlink, mode 0700 root under /private/tmp with prefix gec-rw0a-commit-gate. Retained evidence files must be regular, operator-owned, non-symlink, mode 0400. Do not retain credentials, authorization payloads, private environment values, raw WorkSpec, endpoints, prompts, transcripts, or sensitive logs.

PRE-STAGE PROVENANCE

Run the exact recipe below twice before remote contact or staging. Require return code 0, empty stderr, byte-identical complete stdout and manifests, and byte equality with the audited target.

Expected:

- recipe source: 3,945 bytes; SHA-256 db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
- complete stdout: 2,561 bytes; SHA-256 27a2689e77bb07fac7deea367c7e10d293702bd60b6ff9711c470890f5f1453a
- textual diff: 0c0f284cc1b11a22540903ccef874a96bd69f7982c5e92028fdac2298164eecf
- manifest: 2,328 bytes; SHA-256 3d880594f269d8bb7f13479df50cf4cd5b24b7dd6e913620517cd8c15c24ccf2
- file count: 10

Safely preserve any pre-existing fixed recipe output before use. Do not run this working-tree recipe after staging; staging changes the untracked classifications, so use separate staged/committed blob comparisons.

EXACT RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

REMOTE PREFLIGHT — READ ONLY

Only after local/provenance gates pass, remote contact is authorized for read-only preflight. Require:

- origin resolves to evo-agi/Governed-Execution-Coordinator
- authenticated GitHub identity available
- remote trunk_dev exactly 1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- remote feature branch codex/rw0-phase-entry-contract-freeze absent
- no open or closed PR already uses that head branch
- no conflicting tag or alternate ref

Inspect and retain a redacted summary of applicable trunk_dev rulesets, PR requirement, merge methods, approval/check/thread requirements, auto-merge setting, branch-deletion setting, and current merge prerequisites. Change none of them and use no bypass. If trunk_dev advanced or the branch/PR exists, stop without staging; do not fetch, merge, rebase, or absorb drift.

STAGING

Stage exactly the ten manifest paths using an explicit NUL-terminated path list derived from the immutable target. Do not use git add ., git add -A, directory pathspecs, wildcards, or an inferred changed-path list.

Require after staging:

- exactly ten stage-0 entries relative to HEAD
- exactly 8 M and 2 A; zero D/R/C/unmerged/extra
- all index modes 100644
- no unstaged changes or untracked paths
- no working-tree byte/mode change; C2B3C remains 0600 locally

Compare every staged blob to the audited target by path, status, stage, Git mode, size, and SHA-256. Require byte equality for all ten. Retain a deterministic staged-comparison record and cached full-index binary-diff hash. On mismatch stop; do not unstage, repair, or restage.

FINAL VALIDATION ON STAGED BYTES

Use isolated external cache/TMP/basetemp/JUnit paths; unset PYTHONTRACEMALLOC and PYTHONWARNINGS; set LC_ALL=C, LANG=C, PYTHONDONTWRITEBYTECODE=1, PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, PYTEST_ADDOPTS='', PYTHONHASHSEED=0; use python3 -B -m pytest -p no:cacheprovider -W error serially. Record actual caller and child umask and require numerical equality.

Before and after each run require staged blob equality, no unstaged/untracked path, no residue, and no Git operation/lock.

1. Collect the complete candidate exactly once. Require 4,284 nodes and ordered node-list SHA-256:
   7fb16833d1fcf8916f62ad17b0238b87b8cda8bb03432039771290bc713d12e8
   Also require direct RW0-A 28, architecture 30, remote-worker 774, protected C2B3C 46, no duplicate node, and no collection control weakening.

2. Run the full suite exactly once:

   python3 -B -m pytest -p no:cacheprovider -W error --basetemp=<external> --junitxml=<external> -q .

   Require 4,284 collected and passed; zero failed/errors/skipped/xfailed/warnings; rc 0; empty stderr; no JUnit parse error, duplicate, ambiguity, or unmapped case; repository bytes and staged target unchanged; residue empty.

Do not rerun the full suite. A parser mistake may be corrected only by reparsing the same immutable JUnit. On non-green validation stop without repair, edit, unstage, commit, push, or PR.

COMMIT

Create exactly one commit only after every prior gate passes.

Exact subject:

docs: freeze RW0-A phase-entry contract

Body: empty.

Require sole parent 1a894c5527c610ab40d8e5ae5e530a762c6e60bf; exactly ten paths, 8 M and 2 A; no D/R/C/mode change; all committed modes 100644; exact subject and empty body; no amend or second commit. Record actual author, committer, timestamp, and signature status honestly.

Compare every committed blob to the immutable audited target by path, Git mode, size, and SHA-256. Require exact equality and a clean worktree. On mismatch stop before push; do not amend or recommit.

PUSH — EXACTLY ONCE

Execute exactly:

git push -u origin HEAD:refs/heads/codex/rw0-phase-entry-contract-freeze

No force, lease, admin, bypass, deletion, multi-ref push, alternate branch, or direct trunk push. Require rc 0; remote feature ref equals the exact new commit; remote trunk_dev remains the audited base; local feature branch tracks the remote feature branch at 0/0. Do not retry. On ambiguous/failure reconcile read-only and stop.

PULL REQUEST — EXACTLY ONCE

Create one open non-draft PR.

Base: trunk_dev
Head: codex/rw0-phase-entry-contract-freeze
Title: docs: freeze RW0-A phase-entry contract

Exact body:

```markdown
## Summary

- freeze the accepted RW0-A remote-worker-contact phase-entry target
- preserve current nonimplementation, authority, cancellation, and ES/IM boundaries
- add contract tests for the sole owner, cross-references, terminal outcomes, latch semantics, and fail-closed recovery

## Validation

- independent audit: `ACCEPT`
- full repository suite: `4,284/4,284`
- audited canonical manifest: `3d880594f269d8bb7f13479df50cf4cd5b24b7dd6e913620517cd8c15c24ccf2`
- no source, SQL, migration, schema, package, public API, or supporting-repository change

## Publication scope

This PR contains documentation and contract-test changes only. It does not implement remote contact, worker, custody, cancellation delivery, terminal-outcome, latch, Git, publication, or autonomous runtime capability.
```

Require one PR; open, non-draft; exact base/head refs and OIDs; exact title/body; one commit; ten files; auto-merge absent; merge commit absent; no review, self-approval, thread resolution, branch deletion, or merge. Record actual mergeability, review/check status, and rules honestly; blocked/review-required is acceptable. Do not retry PR creation; on ambiguity reconcile read-only and stop.

FINAL GUARDS

Require local branch and remote feature ref at the exact new commit, upstream origin/codex/rw0-phase-entry-contract-freeze at 0/0, remote trunk_dev unchanged, clean worktree/index/untracked/unmerged, one worktree, no Git operation/lock/residue, committed paths/modes/sizes/hashes equal the audited target, and no source/runtime/schema/migration/public/supporting-repo change. No tag, release, deployment, merge, auto-merge, or branch deletion.

EVIDENCE CLOSEOUT

Retain immutable target verification, audited-support verification, opening identity, both pre-stage recipe runs, remote preflight/rules summary, explicit staged list/status/blob comparison, cached diff hash, node and full-suite evidence, commit object/tree/parent/subject/signature evidence, committed comparison, push evidence, PR request/final state, final guards, and deterministic relative-path/mode/size/SHA-256 evidence index. The index does not index itself. Remove only commit-gate-created transient caches after preserving terminal evidence. Do not retain secrets.

STOP CONDITIONS

Stop without further write when applicable if target/opening/remote base differs; feature branch or PR exists; staging is not exactly 8 M + 2 A; any staged/working byte or mode differs; node/full-suite validation differs; residue appears; commit parent/scope/subject/body/blob differs; push or PR is ambiguous/fails; or bypass/force/amend/second write/merge would be required. Preserve state and evidence. Do not reset, clean, unstage, amend, rebase, delete, or retry a write.

CLOSEOUT

Return exactly:

COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FREEZE_COMMITTED_PUSHED_AND_PR_OPENED

only when audited bytes were staged, validated, committed once, pushed once, and represented by one exact open non-draft PR.

Report target, opening identity, audit-evidence verification, remote preflight/rules, pre-stage provenance, staged comparison, validation, commit OID/tree/parent/subject/timestamp/signature, committed comparison, push/final refs, PR number/URL/state/base/head/title/body/check/review/mergeability, final guards, and evidence-root/index identity.

Required final statements:

IMPLEMENTATION_REPAIR_NOT_PERFORMED
INDEPENDENT_AUDIT_NOT_REPEATED
DIRECT_TRUNK_PUSH_NOT_PERFORMED
BYPASS_NOT_USED
FORCE_PUSH_NOT_PERFORMED
AMEND_NOT_PERFORMED
SECOND_COMMIT_NOT_PERFORMED
SECOND_PUSH_NOT_PERFORMED
SECOND_PR_NOT_CREATED
PR_MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
REVIEW_NOT_SELF_APPROVED
FEATURE_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
