TITLE

Coordinator RW0-A — repair accept-latch atomicity, stale pre-effect cancel
handling, complete map-wide Markdown causality, and final evidence binding after
the fourth audit attempt

ENGAGEMENT TYPE

Bounded parent-only repair in the existing workspace-write implementation
conversation for:

COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1
RW0-A-PHASE-ENTRY-CONTRACT-FREEZE

Do not create or resume subagents. You are the sole repository writer.

The latest fresh read-only audit stopped with `AUDIT_PROVENANCE_MISMATCH`
because the hash-pinned implementation closeout report omitted an explicit
identity for its separate final-guard evidence file.

The audit nevertheless mechanically established:

- the live repository bytes exactly matched the specified final ten-path
  canonical manifest at opening and closing;
- the exact provenance recipe was stable;
- branch, HEAD, upstream, path set, classifications, modes, sizes, hashes, and
  tracked diff matched the canonical target;
- the report-named opening copy and original predecessor manifest were
  byte-identical;
- no repository mutation occurred during audit.

Treat the missing report-to-guard binding as an external evidence-closeout
defect, not as proof of a repository-byte mismatch.

The same audit also identified three source-grounded candidate defects:

1. RW0A-SEM-01 — ACCEPT/LATCH ATOMICITY

   The existing C2B contract requires productive-direct-local latch consumption
   atomically with the committed `accept` development decision. The current RW0
   target says the C2B decision commits before a separate terminal-outcome fact
   while also making both the decision and outcome prerequisites to latch
   consumption.

2. RW0A-SEM-02 — STALE PRE-EFFECT CANCEL DECISION

   Existing C2B forbids establishing the cancellation effect from a stale
   cancel decision after relevant stop-version or target-head drift. The current
   RW0 target permits only one cancel decision but does not define the
   fail-closed terminal path when that exact decision becomes unusable before
   cancel-effect establishment.

3. RW0A-TEST-01 — COMPLETE MAP-WIDE MARKDOWN MUTATION PROOF

   The live complete map-wide cross-reference oracle runs over the live
   documents, but the exact in-range hidden-body mutants are passed only through
   path-local helpers in the direct, architecture, and remote-worker tests.
   Every mutated four-document map must be exercised through the same complete
   authoritative map-wide oracle.

This turn authorizes correction of those three repository findings and
generation of a stronger external evidence closeout that explicitly binds the
final guard.

This turn does not authorize:

- revision of the closed C2B decision-kind grammar;
- mutation of `.docs/c2b-durable-development-state.md`;
- mutation of `tests/test_c2b3c_author_effect_contract.py`;
- any source/runtime/schema/migration/catalog/application-generation/package/
  public-protocol/StateStore/WriterSession change;
- implementation of terminal-outcome storage, authority verification, custody,
  transport, process launch, worker, Codex, capsule storage, validation/review/
  model execution, cancellation runtime, acceptance latch, Git, ES routing,
  service, queue, scheduler, or autonomous loop;
- mutation of Execution Substrate, Infrastructure Manager, or any other
  repository;
- staging, commit, push, PR creation, merge, tag, release, or deployment;
- fetch, pull, remote contact, network access, model/provider invocation, Codex
  invocation, process/worker launch, SSH, live service, or live database
  contact;
- reset, clean, revert, branch switch, discard, or history rewrite.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OPENING BASELINE AND TARGET GATE

Require exactly before mutation:

- Physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- HEAD tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- HEAD subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1
- Dirty paths:
  exactly 10
- Tracked modifications:
  exactly 8
- Untracked paths:
  exactly 2
- Staged/unmerged:
  0/0
- No deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  or Git lock
- Repository residue:
  empty
- `git diff --check HEAD --`:
  clean.

Require the exact ten-path set:

.docs/rw0-remote-worker-contact-phase-entry.md
.docs/c2b-durable-development-state.md
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_architecture_contracts.py
tests/test_c2b3c_author_effect_contract.py

Require mode posture:

- these nine paths are regular working-tree mode `0644`:

  .docs/rw0-remote-worker-contact-phase-entry.md
  .docs/c2b-durable-development-state.md
  .docs/autonomous-software-development-operating-model.md
  .docs/worker-execution-boundary.md
  .docs/authority-boundaries.md
  .docs/durable-state-model.md
  tests/test_rw0_remote_contact_phase_entry_contract.py
  tests/test_remote_worker_pre_execution_planning_contract.py
  tests/test_architecture_contracts.py

- this path is regular working-tree mode `0600`, current-operator-owned, with no
  execute bits:

  tests/test_c2b3c_author_effect_contract.py

- Git index mode for every tracked candidate path is `100644`;
- no Git-recorded mode change exists.

Do not chmod any path. Do not widen the local `0600` permission.

AUTHORITATIVE OPENING TARGET

Use exactly:

/private/tmp/ge-rw0a-third-repair-8fujftd9/final_provenance/run-2-manifest.json

Require:

- every path component lstat-safe and non-symlink;
- evidence root operator-owned, non-symlink, mode 0700;
- manifest regular and safely readable;
- size:
  2,328 bytes;
- SHA-256:
  e46474d1b2af374e2bd84ded976e2bb1dd01399dfdc4a2b31b93bbd13f5c830e.

Copy the safely verified bytes into one new repair-created external,
operator-owned, non-symlink, mode-0700 evidence root as an immutable mode-0400
opening target.

Parse and require:

- recipe_id:
  governed-execution.audit-patch-manifest.v1
- branch:
  codex/rw0-phase-entry-contract-freeze
- head:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- textual_diff_sha256:
  517b71cbd5ec527fd2ef38936a55ceaf724284767e3884814f3fa646afecf41c
- exactly ten entries;
- exactly eight `tracked_modified`;
- exactly two `untracked`;
- expected working-tree modes above;
- no deletion, missing path, symlink, or unsupported type.

Run the exact provenance recipe below twice before editing and require exact
byte equality with the immutable target.

Expected opening provenance:

- Recipe source:
  3,945 bytes
- Recipe SHA-256:
  db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
- Complete stdout:
  2,561 bytes
- Complete-output SHA-256:
  dfa649f23c4edb181edbb53f78783bf2062566b5bdab36aa7e439cf944a2e571
- Stderr:
  0 bytes
- Tracked textual-diff SHA-256:
  517b71cbd5ec527fd2ef38936a55ceaf724284767e3884814f3fa646afecf41c
- Canonical manifest:
  2,328 bytes
- Canonical-manifest SHA-256:
  e46474d1b2af374e2bd84ded976e2bb1dd01399dfdc4a2b31b93bbd13f5c830e
- File count:
  10

Stop without mutation and return:

COORDINATOR_RW0_A_FOURTH_AUDIT_REPAIR_PROVENANCE_MISMATCH

on any mismatch. Do not reconstruct the target from the live tree, reports, or
aggregate hashes.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

PRIOR AUDIT EVIDENCE

Safely inspect the latest audit evidence only when its exact path can be
identified from the supplied audit response or existing safe external roots.

Use it only as predecessor evidence. Do not grant correctness credit merely
because records exist.

The latest audit established these exact repository/provenance facts:

- final manifest:
  2,328 bytes,
  `e46474d1b2af374e2bd84ded976e2bb1dd01399dfdc4a2b31b93bbd13f5c830e`;
- complete stdout:
  2,561 bytes,
  `dfa649f23c4edb181edbb53f78783bf2062566b5bdab36aa7e439cf944a2e571`;
- tracked textual diff:
  `517b71cbd5ec527fd2ef38936a55ceaf724284767e3884814f3fa646afecf41c`;
- the report’s omission of a bound final-guard identity;
- exact live byte equality with the canonical target;
- source-grounded findings RW0A-SEM-01, RW0A-SEM-02, and RW0A-TEST-01.

If retained audit evidence is unavailable or incomplete, continue from the
supplied audit report and current source inspection, but disclose the
limitation. Do not invent paths, hashes, or missing records.

MAXIMUM AUTHORIZED REPOSITORY MUTATION

Documentation:

1. .docs/rw0-remote-worker-contact-phase-entry.md
2. .docs/autonomous-software-development-operating-model.md
3. .docs/worker-execution-boundary.md
4. .docs/authority-boundaries.md
5. .docs/durable-state-model.md

Tests:

6. tests/test_rw0_remote_contact_phase_entry_contract.py
7. tests/test_architecture_contracts.py
8. tests/test_remote_worker_pre_execution_planning_contract.py

No other repository path may change.

Protected exact candidate bytes:

- .docs/c2b-durable-development-state.md
- tests/test_c2b3c_author_effect_contract.py

The protected C2B document must retain exact size/hash/mode:

- 1,884,626 bytes
- SHA-256:
  5fd66a1266e63f8f026a27de7d84f42029813acdadc6b3ecb1978c3ff9ce9b1e
- mode:
  0644

The protected C2B3C test must retain exact size/hash/mode:

- 416,182 bytes
- SHA-256:
  935ca6fe7b18d39055d5cdc2c911302e7c0726304f3699472f3994a32f7b4778
- working-tree mode:
  0600
- Git index mode:
  100644

The final path set and topology must remain exactly ten paths, eight tracked
modifications, two untracked files, zero staged, and zero unmerged.

If an allowlisted document or test does not require a byte change, preserve it
byte-identically and report that fact.

PARENT CONTRACT DECISIONS FOR THIS REPAIR

A. ACCEPT DECISION OWNS LATCH CONSUMPTION

Preserve the existing C2B contract.

1. On the non-cancel `accept` branch, the immutable C2B
   `development_decision(kind=accept)` is the sole fact that consumes the
   productive-direct-local acceptance latch.

2. Latch consumption occurs atomically in the same guarded Coordinator writer
   transaction as that accepted decision, exactly as the existing C2B contract
   requires.

3. The later separate RW0 terminal-outcome fact:
   - has value `accept`;
   - binds the exact accepted decision ref/digest;
   - binds the exact committed latch postimage produced by that decision
     transaction;
   - does not consume, advance, reopen, repair, or otherwise mutate the latch;
   - cannot be a prerequisite for the already-atomic latch mutation;
   - cannot contradict the accepted decision or its latch postimage.

4. The accepted decision remains durable even if the later terminal-outcome
   commit is uncertain. Terminal-outcome uncertainty:
   - is resolved by exact guarded-writer readback;
   - permits no new effect, successor launch, Git effect, or publication;
   - never causes a second accept decision or a second latch mutation.

5. RW0 is not terminally closed until the separate outcome fact is resolved, but
   the latch is already consumed if and only if the accept decision committed.

6. For `repair`, `replan`, `terminal_reject`, and ordinary `block` branches:
   - the same-kind C2B decision commits first;
   - no latch mutation occurs;
   - the later terminal-outcome fact binds that exact decision.

7. Do not revise C2B decision kinds, latch ownership, or transaction semantics.

8. The physical identity, row, receipt, graph, table, migration, and public/API
   representation of the terminal-outcome fact remain deferred.

B. STALE PRE-EFFECT CANCEL DECISION FAILS CLOSED INSIDE RW0

Preserve the existing C2B rule that an effect cannot be established from a
stale or incompatible basis decision.

1. Exactly one immutable pre-effect C2B `cancel` decision may exist in RW0.

2. Before cancel-effect establishment, the future guarded Coordinator writer
   and current verifier must re-establish the complete required relation,
   including:
   - exact cancel-decision ref/digest and committed readback;
   - exact current program/version/attempt/target-head relation;
   - exact global-stop version/state;
   - parent grant, subordinate authorization, applicable attempt/effect fence,
     authorization-basis, expiry, revocation, repository, base, path, and
     audience relations;
   - the exact preassigned cancel effect, fence, first delivery, and target
     required by C2B.

3. If the exact cancel decision is stale, superseded, incompatible, missing,
   ambiguous, or no longer current before effect establishment:
   - no cancel effect is established;
   - no cancellation delivery/request/signal is emitted;
   - no replacement cancel decision, block decision, effect, fence, delivery,
     semantic attempt, or author lineage is created inside RW0;
   - the future RW0 terminal-outcome fact is committed with value `block`;
   - that outcome binds the exact unusable cancel decision and the exact
     current-head/stop/verification mismatch evidence;
   - the terminal `block` is not a C2B
     `development_decision(kind=block)`;
   - no successor, Git effect, or publication follows.

4. This is the `pre_effect_cancel_basis_unusable` terminal sub-branch.

5. If the exact cancel decision remains current and valid, the existing
   active-cancel sequence remains:

   cancel decision
   → cancel effect/fence/subordinate binding/initial delivery
   → request
   → acknowledgement
   → signal
   → process exit
   → workspace teardown
   → source-native reconciliation
   → terminal-outcome `cancel` when complete/non-ambiguous
     or terminal-outcome `block` when unresolved.

6. A successor outside RW0 may later replan and create a new decision under its
   own governed program progression. RW0 itself never absorbs the drift.

7. Cancel-decision commit uncertainty must be resolved before currentness
   evaluation. Terminal-outcome commit uncertainty must be resolved before any
   further effect or successor.

8. Reports, observations, route receipts, or verifier projections cannot author
   the terminal outcome.

C. COMPLETE MAP-WIDE MARKDOWN MUTATION AUTHORITY

For the four bounded cross-reference documents, the complete authoritative
oracle must operate on one closed four-document map.

1. Freeze one exact four-entry inventory of:
   - path;
   - intended current owner and ancestor chain;
   - predecessor/range terminator;
   - BEGIN marker;
   - END marker.

2. The complete oracle accepts only when:
   - every one of the four documents has exactly one valid visible block in its
     exact owner range;
   - all four normalized visible bodies are identical;
   - all current semantic requirements are satisfied.

3. For every cross-reference specification and every required hostile mutant:
   - construct a complete four-document map;
   - mutate exactly one document;
   - retain the other three exact live documents;
   - feed the entire mutated map through the same complete authoritative oracle;
   - require rejection for the intended path/owner/body reason.

4. It is insufficient to invoke only a path-local extractor/helper.

5. Path-local helpers may remain implementation details only when the complete
   map-wide oracle calls them and then enforces global map completeness and
   body identity.

6. For the exact in-range hidden-real/visible-empty case:
   - preserve the intended visible H3;
   - place the byte-exact valid real block inside a balanced backtick or tilde
     fence inside the same owner range;
   - retain a visible BEGIN and END with only blank visible body;
   - retain no same-or-higher heading before the range terminator;
   - require a deliberately broken raw helper to accept;
   - require the complete four-document authoritative oracle to reject.

7. Exercise all four specs through the complete map oracle. Use both backtick
   and tilde fences across the matrix, with each spec covered by at least one.

8. Also exercise complete-map rejection for:
   - visible prose before BEGIN;
   - visible prose after END;
   - fenced-only body;
   - split/reversed markers;
   - historical relocation;
   - same-title sibling/ancestor relocation;
   - two visible blocks;
   - body mismatch in one document.

9. Preserve positive controls:
   - exact live four-document map accepts;
   - one correct visible block plus an irrelevant hidden duplicate in one
     document accepts when the complete map remains semantically identical.

DOCUMENT REPAIR REQUIREMENTS

SOLE OWNER DOCUMENT

Update only affected regions in:

.docs/rw0-remote-worker-contact-phase-entry.md

At minimum reconcile:

- accept decision and latch ownership;
- terminal-outcome relation to accepted decision/latch postimage;
- terminal-outcome commit uncertainty after accepted decision;
- stale pre-effect cancel-decision branch;
- active-cancel branch;
- failure/recovery matrix;
- final outcome and no-successor semantics;
- tranche/open-decision statement that terminal-outcome representation remains
  deferred.

Preserve:

- sole detailed ownership;
- accepted-target/nonimplementation classification;
- exact K8/L34 lineage;
- immutable authorization-basis/subordinate-record relation;
- one existing author lineage and invocation;
- author versus later current-effect delivery distinction;
- raw WorkSpec privacy;
- one qualified remote Linux host/no fallback/no third adapter;
- supervisor/worker fact ownership;
- direct-local/ES/IM split;
- no Git/publication;
- all deferred physical implementation seams;
- no selected table, migration, application generation, public class, wire
  format, or backend.

FOUR CROSS-REFERENCES

Inspect the bounded blocks in exactly:

.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md

If their compact normalized body repeats the affected latch or stale-cancel
semantics, update all four identically.

Their compact meaning must remain:

- sole detailed owner path;
- current runtime absent and fail-closed;
- accepted C2B decision atomically consumes the latch;
- later terminal outcome binds but does not mutate the latch postimage;
- stale pre-effect cancel basis produces no cancel effect and terminally blocks
  RW0 without a second C2B decision;
- active cancel otherwise retains request/ack/signal/exit/teardown/
  reconciliation ordering;
- one existing author lineage/invocation/delivery;
- no fallback, third adapter, Git, or publication;
- direct-local does not absorb ES-route authority;
- custody, transport, framing, Codex, schema, terminal-outcome representation,
  latch representation, and backend choices remain deferred.

All four normalized bodies must remain identical. Do not duplicate the detailed
matrix.

TEST CONTRACT — LATCH ATOMICITY

Strengthen existing nodes without adding or parameterizing test nodes.

Independently require and mutate:

1. accept decision atomically consumes the latch;

2. terminal outcome does not consume or mutate the latch;

3. terminal `accept` binds the exact accepted decision ref/digest;

4. terminal `accept` binds the exact latch postimage from the decision
   transaction;

5. terminal outcome is not a prerequisite to the already-atomic latch mutation;

6. accept-decision commit with unresolved terminal-outcome commit leaves the
   latch consumed but blocks all later effects/successors until exact readback;

7. no second accept decision or latch mutation occurs;

8. non-accept branches do not mutate the latch.

Reject causal mutants that:

- delay latch consumption until terminal outcome;
- let terminal outcome consume the latch;
- require outcome as a precondition for decision/latch commit;
- bind the wrong latch postimage;
- allow a second latch mutation during outcome commit;
- treat unresolved outcome as permission for successor/Git/publication;
- let `repair`, `replan`, `terminal_reject`, `block`, or `cancel` consume the
  latch.

TEST CONTRACT — STALE PRE-EFFECT CANCEL BASIS

Independently require and mutate:

1. currentness verification occurs after exact cancel-decision commit readback
   and before cancel-effect establishment;

2. stale stop-version or target-head mismatch prevents effect establishment;

3. missing/ambiguous parent/basis/fence/current-head relation prevents effect
   establishment;

4. pre-effect unusable cancel basis yields terminal outcome `block`;

5. terminal `block` binds the exact unusable cancel decision and mismatch
   evidence;

6. no second cancel/block decision, replacement effect/fence/delivery, request,
   signal, or successor exists;

7. current valid cancel basis proceeds to the existing active-cancel sequence;

8. terminal block remains a terminal-outcome value, not a C2B block decision.

Reject mutants that:

- establish a cancel effect from a stale decision;
- mint a replacement cancel decision;
- mint a block decision;
- reinterpret current head/stop drift as compatible;
- emit request or signal without an effect;
- produce terminal `cancel` on the unusable pre-effect branch;
- omit any terminal path;
- permit successor/replan inside the same RW0 run;
- let a report/verifier projection author the outcome.

TEST CONTRACT — COMPLETE FOUR-DOCUMENT ORACLE

Repair the exact path-local-only weakness in:

- tests/test_rw0_remote_contact_phase_entry_contract.py
- tests/test_architecture_contracts.py
- tests/test_remote_worker_pre_execution_planning_contract.py

Within existing nodes:

- construct complete four-document maps for every required mutant;
- invoke the complete authoritative map-wide oracle, not only an inner helper;
- prove the exact live map accepts;
- prove every one-document mutation rejects the whole map;
- prove hidden-duplicate positive behavior through the complete map;
- retain broken raw/path-local controls solely to reproduce predecessor
  weakness;
- never use a broken helper as the authoritative positive oracle.

Do not add, rename, remove, parameterize, skip, or xfail any test node.

TEST-NODE BOUNDARY

Before editing, collect exactly once under isolated posture:

- complete repository:
  exactly 4,284 nodes;
- direct RW0-A file:
  exactly 28 nodes;
- architecture file:
  exactly 30 nodes;
- remote-worker file:
  exactly 774 nodes;
- C2B3C file:
  exactly 46 nodes.

Retain literal ordered lists.

Final ordered lists must be byte-identical to opening lists.

CAUSAL RED PHASE

Before changing documentation:

1. strengthen only the authorized test helpers/mutants;
2. keep all documentation at the exact opening target;
3. use bounded external in-memory diagnostics as needed to calibrate mutants;
4. run one formal causal-red pytest gate over:

   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_remote_worker_pre_execution_planning_contract.py

   exactly once;

5. require non-green results causally demonstrating:
   - latch consumption is not yet correctly owned by the accepted decision;
   - stale pre-effect cancel basis lacks a terminal fail-closed branch;
   - the prior checked-in mutants do not yet route complete mutated maps through
     the authoritative map-wide oracle;

6. require no unrelated import, collection, setup, or recorder error.

For the Markdown test-adequacy change, a newly strengthened complete-map mutant
may already reject on opening documentation. That is acceptable only when the
test separately demonstrates that the predecessor path-local/broken helper
accepts the same bytes and the complete oracle rejects them.

Then repair documentation and finalize helpers. Do not rerun the formal red gate
on predecessor bytes.

VALIDATION ISOLATION

Use one new external, operator-owned, non-symlink, mode-0700 repair root.

For every pytest child:

- save actual caller umask;
- create evidence under secure posture;
- restore caller umask before launch;
- record child-observed umask and require numerical equality;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`
  - `LC_ALL=C`
  - `LANG=C`
  - `PYTHONDONTWRITEBYTECODE=1`
  - distinct external `PYTHONPYCACHEPREFIX`
  - distinct external `TMPDIR`
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
  - `PYTEST_ADDOPTS=''`
  - `PYTHONHASHSEED=0`
  - `python3 -B -m pytest`
  - `-p no:cacheprovider`
  - `-W error`
  - distinct external `--basetemp`
  - external `--junitxml`
  - serial execution.

Retain exact argv, effective environment, caller/child umask, return code,
elapsed time, stdout/stderr/JUnit sizes and SHA-256, parsed counts, warnings,
parse errors, unmapped cases, and before/after target identity.

FINAL TARGETED GREEN GATES

Run exactly once each on frozen final bytes:

1. Direct RW0-A:

   tests/test_rw0_remote_contact_phase_entry_contract.py

   Require exactly 28/28 green.

2. Architecture:

   tests/test_architecture_contracts.py

   Require exactly 30/30 green.

3. Remote-worker planning:

   tests/test_remote_worker_pre_execution_planning_contract.py

   Require exactly 774/774 green.

4. Protected C2B3C:

   tests/test_c2b3c_author_effect_contract.py

   Require exactly 46/46 green.

COMPLETE RW0-A FOCUSED REGRESSION

Run exactly:

tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_software_development_progression_boundary.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_worker_execution_semantic_boundaries.py

Require exactly 1,565/1,565 green.

If any named file is absent, stop rather than substituting.

FINAL NODE COLLECTION

After targeted/focused validation and cleanup:

- collect the complete repository exactly once;
- require exactly 4,284 nodes;
- require literal equality with the opening candidate list;
- require direct test remains 28;
- architecture remains 30;
- remote-worker remains 774;
- C2B3C remains 46;
- require no added, removed, renamed, skipped, xfailed, collapsed, or
  re-parameterized node.

FULL SUITE — EXACTLY ONCE

Only after all targeted/focused gates, node identity, path boundary, and
artifact cleanup are green, run exactly once:

python3 -B -m pytest -p no:cacheprovider -W error \
  --basetemp=<external> \
  --junitxml=<external> \
  .

Require exactly:

- 4,284 collected;
- 4,284 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository bytes, topology, modes, and node identity unchanged before/after.

Do not run a second full-suite attempt.

FINAL CONTRACT AND PATH GUARDS

Require:

- exact ten-path candidate set;
- exactly eight tracked modifications and two untracked files;
- zero staged/unmerged paths;
- expected working-tree modes, including C2B3C `0600`;
- Git index mode `100644` for every tracked path;
- no Git-recorded mode change;
- no path outside the ten-path target changed;
- `.docs/c2b-durable-development-state.md` byte-identical to the opening target;
- `tests/test_c2b3c_author_effect_contract.py` byte-identical to the opening
  target;
- accepted decision atomically owns latch consumption;
- terminal outcome only binds the latch postimage;
- stale pre-effect cancel basis yields terminal block with no replacement
  decision/effect/request;
- complete four-document mutated maps route through the authoritative oracle;
- one sole detailed owner;
- four normalized-identical bounded cross-reference bodies;
- all prior authority, author-lineage, delivery, cancellation, fact-owner,
  ES/IM, Markdown, terminal-inventory, C2B3C, and nonimplementation repairs
  remain exact;
- no current implementation overclaim;
- no enduring fixture, custodian, SSH/framing, Codex, schema, terminal-outcome
  representation, latch representation, capsule-backend,
  validator/reviewer/model-adapter, or ES reliable-submit implementation choice
  added;
- no source, SQL, migration, catalog, schema, application-generation, package,
  public protocol, StateStore, WriterSession, runtime, fixture, script, config,
  or supporting-repository diff;
- `git diff --check` clean;
- no repository cache, bytecode, pytest cache, database, journal, WAL/SHM,
  build output, archive, generated manifest, or OS metadata;
- no Git operation or lock;
- no remote contact or runtime effect.

FINAL PROVENANCE

After final validation and cleanup, run the exact unchanged provenance recipe
twice.

Require:

- both return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- exactly ten entries;
- exactly eight `tracked_modified`;
- exactly two `untracked`;
- expected working-tree modes;
- no deletion, rename, symlink, Git-recorded mode change, or unsupported type.

Compare final manifest with the immutable opening target and report:

- every changed entry, opening/final size and SHA-256;
- every byte-identical protected entry;
- exact path classifications and modes;
- recipe source size/hash;
- complete-output size/hash;
- tracked textual-diff hash;
- canonical-manifest size/hash;
- causal-red evidence;
- targeted/focused/collection/full-suite evidence paths and hashes;
- current/target/deferred classification guard;
- no-effect/no-network/no-supporting-repo evidence.

Do not stage. The final working-tree manifest is the future independent-audit
target.

FINAL EVIDENCE CLOSEOUT — REQUIRED BINDING

Create exactly these external closeout artifacts beneath the secure repair root:

1. `final-guard.json`
2. `final-closeout-report.json`
3. `final-evidence-index.json`

All retained evidence files must be regular, operator-owned, non-symlink, mode
`0400` after closeout. The evidence root remains mode `0700`.

A. FINAL GUARD

`final-guard.json` must record:

- repository root;
- branch, HEAD, tree, parent, subject, upstream, ahead/behind, worktree count;
- exact status topology and ten-path set;
- working-tree modes and tracked index modes;
- staged/unmerged state;
- name-status and no-mode-change result;
- `git diff --check`;
- protected C2B/C2B3C identities;
- node counts and ordered-node-list hashes;
- repository residue scan;
- Git operation and lock scan;
- no-network/no-remote/no-worker/no-model/no-supporting-repo statements;
- final canonical-manifest path/size/SHA-256;
- final tracked-diff SHA-256.

B. FINAL CLOSEOUT REPORT

`final-closeout-report.json` must explicitly record:

- branch, HEAD, upstream;
- opening target path/size/SHA-256;
- final canonical-manifest path/size/SHA-256;
- recipe source path/size/SHA-256;
- complete-output size/SHA-256;
- tracked textual-diff SHA-256;
- exact per-file opening/final identities;
- exact test/node results and evidence paths/hashes;
- exact final-guard path, size, and SHA-256 under a field named
  `guard_evidence`;
- protected-byte results;
- limitations and unresolved seams;
- all required no-effect statements.

The report is evidence only. It does not replace the canonical manifest or Git
truth.

C. FINAL EVIDENCE INDEX

After the report and guard are immutable, create
`final-evidence-index.json`.

It must index by safe external relative path, mode, size, and SHA-256 at least:

- opening target;
- both final recipe sources/runs and manifests;
- final canonical manifest;
- causal-red report/stdout/stderr/JUnit;
- every final targeted/focused/collection/full-suite report/stdout/stderr/JUnit;
- opening and final node lists;
- `final-guard.json`;
- `final-closeout-report.json`.

The index does not index itself.

D. CLOSEOUT REPORTING

The Codex response must report:

- final-guard path, size, SHA-256;
- final-closeout-report path, size, SHA-256;
- final-evidence-index path, size, SHA-256;
- final canonical manifest path, size, SHA-256.

A future audit must be able to pin the report and index separately and verify
the report’s explicit guard binding. Do not leave a loose, unbound guard file.

STOP CONDITIONS

Stop without further mutation if:

- opening identity, target, path set, mode posture, or node count differs;
- the findings cannot be closed inside the eight-path maximum mutation
  allowlist;
- `.docs/c2b-durable-development-state.md` or the C2B3C test must change;
- closing latch atomicity requires altering C2B decision/latch semantics;
- closing stale cancel handling requires a second C2B decision or effect;
- any source/schema/migration/public/runtime change appears necessary;
- the complete four-map oracle cannot be exercised without adding a test node;
- an existing test node must change identity;
- targeted, focused, collection, or full-suite validation is not exact-green;
- another repository path changes;
- final provenance is unstable;
- the final report cannot explicitly bind the final guard;
- remote contact, staging, publication, worker/model/process activity, or
  supporting-repository mutation would be required.

On stop, preserve exact state and evidence. Do not reset, clean, revert, switch
branches, stage, or discard work.

CLOSEOUT

Return exactly:

COORDINATOR_RW0_T1_FOURTH_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

only if:

- RW0A-SEM-01, RW0A-SEM-02, and RW0A-TEST-01 are causally and contractually
  closed;
- accepted decision alone atomically consumes the latch;
- terminal outcome only binds the accepted latch postimage;
- stale pre-effect cancel basis terminates RW0 as block without a second C2B
  decision or effect;
- every required mutated four-document map reaches the complete authoritative
  oracle;
- all prior findings remain closed;
- validation is exact-green;
- node identity is unchanged;
- final ten-path provenance is stable;
- the final closeout report explicitly binds the final guard;
- no source/runtime/remote/staging/publication effect occurred.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
