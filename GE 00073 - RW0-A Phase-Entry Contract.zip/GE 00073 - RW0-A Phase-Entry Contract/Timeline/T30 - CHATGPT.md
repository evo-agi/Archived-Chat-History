## Verdict

**Do not retry the audit on the unchanged candidate. Return to the workspace-write implementation conversation for one bounded repair.**

The latest `AUDIT_PROVENANCE_MISMATCH` was correct under the audit prompt’s explicit evidence rules, but it does **not** indicate a repository-byte mismatch. The audit independently reproduced the canonical ten-path manifest, branch, HEAD, upstream, modes, classifications, and tracked diff at opening and closing. The missing item was an explicit hash binding from the external closeout report to its separate `final_guards.json`.

That is an **evidence-closeout defect**, not a repository contract defect. Canonical manifests establish exact patch identity; reports and guard records remain evidence rather than authority. 

However, the audit also found three source-grounded defects. Those findings should be repaired now rather than hidden behind another relaxed audit-input prompt.

## Substantive findings

### 1. Accept decision versus latch consumption

The target currently makes both the C2B `accept` decision and the later RW0 terminal-outcome fact prerequisites to consuming the productive-direct-local latch. That conflicts with the existing C2B contract, which owns latch consumption atomically with the accepted decision.

The corrected target should be:

```text
C2B development_decision(kind=accept)
→ atomically consumes the latch in the same guarded transaction
→ produces the exact latch postimage

later RW0 terminal-outcome(value=accept)
→ binds the exact accept decision
→ binds the exact committed latch postimage
→ does not consume or mutate the latch
```

If the later terminal-outcome commit is uncertain, the latch remains consumed because the accepted decision already committed. Exact readback must resolve the terminal-outcome fact before any successor, Git effect, or publication. No second accept decision or second latch mutation is allowed.

For `repair`, `replan`, `terminal_reject`, and ordinary `block`, the same-kind C2B decision commits without latch mutation; the later terminal-outcome fact binds that decision.

### 2. A cancel decision that becomes stale before its effect

The existing C2B contract forbids establishing an effect from a stale cancel decision after relevant stop-version or target-head drift. RW0 also prohibits creating a replacement decision or effect.

The required fail-closed branch is:

```text
exact pre-effect C2B cancel decision
→ fresh currentness verification
→ decision found stale, superseded, incompatible, missing, or ambiguous
→ no cancel effect
→ no delivery, request, or signal
→ no replacement cancel/block decision
→ RW0 terminal-outcome(value=block)
```

That terminal `block` binds the unusable cancel decision and the exact mismatch evidence. It is not a C2B `development_decision(kind=block)`. A later successor outside RW0 may replan; the current RW0 run cannot absorb the drift.

When the cancel decision remains current, the established active-cancel sequence remains unchanged:

```text
cancel decision
→ cancel effect and delivery
→ request
→ acknowledgement
→ signal
→ process exit
→ workspace teardown
→ source reconciliation
→ terminal cancel or block
```

### 3. The Markdown mutants do not reach the complete oracle

The exact in-range hidden-body mutants are currently passed only through path-local helpers. That does not prove that the authoritative **four-document map-wide oracle** rejects a defective map.

For each of the four cross-reference documents, the test must:

1. Start from the complete live four-document map.
2. Mutate exactly one document.
3. Retain the other three exact live documents.
4. Send the entire map through the same complete authoritative oracle.
5. Require rejection for the intended owner/body reason.

This applies to the empty-visible-block/hidden-real-body mutant and the other fenced, relocated, duplicated, split-marker, trailing-prose, and body-mismatch mutants. A path-local helper may remain an implementation detail, but it cannot receive the final correctness credit.

The third independent audit had already narrowed the previous candidate to the C2B decision/terminal-outcome conflict and exact in-range Markdown causality; those findings were real even though the candidate’s byte provenance was exact. 

## Evidence closeout correction

Because repository bytes will change, the next implementation closeout should create new evidence rather than trying to repair the old report.

The prompt requires three immutable external artifacts:

```text
final-guard.json
final-closeout-report.json
final-evidence-index.json
```

The closeout report must explicitly record the final guard’s path, size, and SHA-256 under `guard_evidence`. The evidence index then hashes both the report and the guard, along with every validation and provenance record.

This avoids another “loose guard file” mismatch while keeping the canonical manifest and Git—not the report—as repository authority.

## Repair boundary

The maximum repository mutation scope remains the same eight paths:

```text
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
```

These remain byte-protected:

```text
.docs/c2b-durable-development-state.md
tests/test_c2b3c_author_effect_contract.py
```

The C2B3C test must remain local mode `0600` and Git index mode `100644`.

No source, schema, migration, runtime, package, public API, or supporting-repository change is authorized.

## Required validation

The candidate must retain exactly:

```text
Complete repository:       4,284 nodes
Direct RW0-A file:            28 nodes
Architecture file:            30 nodes
Remote-worker file:           774 nodes
Protected C2B3C file:          46 nodes
```

Final gates:

```text
Direct RW0-A:             28/28
Architecture:             30/30
Remote-worker planning:  774/774
Protected C2B3C:          46/46
Focused regression:    1,565/1,565
Full suite:            4,284/4,284
```

## Next action

Resume the existing workspace-write implementation conversation and send:

:chatgpt-content-reference{index="4"}

A successful response should end with:

```text
COORDINATOR_RW0_T1_FOURTH_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

Then proceed through:

```text
bounded repair
→ exact-green validation
→ new ten-path manifest
→ report-bound final guard and evidence index
→ fresh independent re-audit
→ ACCEPT
→ audited-byte commit and PR gate
```

The implementation/audit protocol requires returning to the single writer for audit findings, producing new validation and provenance, and then starting a fresh independent audit because the bytes changed.  A commit or publication gate is permitted only after independent `ACCEPT`. 

### Sources

- Latest Codex audit response supplied in this turn.
- Prior third-audit blocker and causality findings. 
- Coordinator reconnaissance baseline. 
- Governed repair and fresh re-audit lifecycle. 
- Provenance scope and limitations. 

**Confidence:** 99% that another unchanged-byte audit would be wasted; 99% that the three candidate findings are real and repairable within the existing eight-path scope; 98% that the latch and stale-cancel resolutions preserve the current C2B contracts without requiring schema or runtime work.
