TITLE

Coordinator RW0-A phase-entry contract freeze — fresh independent re-audit
after the first-audit findings repair

ENGAGEMENT TYPE

Fresh-conversation independent audit.

Run this in a new Codex conversation with read-only repository posture.

Do not resume or use the implementation or preceding audit conversation as this
audit conversation. Their reports and retained evidence are inputs only.

Repository mutation is not authorized. Do not edit, format, create, delete,
rename, chmod, clean repository paths, switch branches, stage, commit, amend,
push, create or update a PR, merge, rebase, reset, tag, release, deploy,
install dependencies, run live migrations, invoke a model/provider or Codex,
launch a worker/process, contact a host, Bridge, Execution Substrate,
Infrastructure Manager, or any remote.

Temporary audit output is authorized only beneath one audit-created,
operator-owned, non-symlink, mode-0700 external root. Do not write audit output
inside the repository. Remove only audit-created external artifacts when safe.
Do not delete, overwrite, or normalize implementation evidence.

If any repository byte, local permission, path, index entry, branch, Git
operation state, or topology changes, stop and report it. Do not silently
restore or clean it.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

WORKSTREAM

COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1

TRANCHE

RW0-A-PHASE-ENTRY-CONTRACT-FREEZE

PRIMARY OBJECTIVE

Independently re-audit the exact final ten-path RW0-A candidate after the
parent-only repair of the first independent audit’s nine findings:

- RW0-01 — one-total-delivery contract drift;
- RW0-02 — fenced four-cross-reference body accepted;
- RW0-03 — hidden sole-owner begin marker accepted;
- RW0-04 — existing versus newly issued fence timing ambiguity;
- RW0-05 — cancellation branch ordering ambiguity;
- RW0-06 — legally indented duplicate terminal inventory ignored;
- RW0-07 — decision region did not independently terminate RW0/no-successor;
- RW0-08 — process launch and worker-start fact attribution ambiguity;
- RW0-09 — direct-local route ownership versus ES-route authority ambiguity.

The implementation reports that:

- the single author-candidate delivery is now distinct from separately bounded
  validation, review, and cancellation current-effect deliveries;
- no author redelivery, relaunch, replacement author effect, or second author
  attempt is allowed;
- existing C2B3D attempt/effect fences remain exact inert bounds and are reused,
  while a freshly verified parent grant supports a narrower Coordinator-derived
  subordinate authorization record bound to those exact fences;
- later validation, review, and cancellation effects may have their own distinct
  current effect intents/fences inside the verified parent grant;
- normal and active-cancellation terminal branches are now distinct;
- early cancellation intent is not the final terminal `cancel` outcome;
- supervisor process launch is distinct from worker-authored `worker_started`;
- direct-local owns its bounded route-local process/cancellation facts without
  absorbing ES-route admission/lifecycle/cancellation/result authority;
- the sole-owner, four-cross-reference, and two terminal-inventory oracles now
  use visible fence-aware Markdown regions;
- the direct test, architecture test, remote-worker planning test, protected
  C2B3C test, focused regression, and full suite are all green;
- all 4,284 candidate node IDs remain byte-identical to the opening candidate;
- only eight authorized entries changed from the preceding audited target;
- the C2B durable document and C2B3C compatibility test remain exact;
- no source, schema, migration, runtime, public API, worker, model, network,
  supporting-repository, staging, or publication effect occurred.

Do not trust those claims as correctness evidence.

First bind this audit to the exact final manifest and prove the exact eight-entry
delta from the preceding audit target. Then inspect and independently reproduce
the repaired contract, ownership, and mutation invariants.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Do not repair findings.

CURRENT COMMITTED BASELINE

Require and verify:

- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- HEAD tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- HEAD subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1

CURRENT IMPLEMENTATION BOUNDARY

Verify from the committed baseline and unchanged source that current capability
still stops at:

- internal C2A pure values and validators;
- private readers;
- guarded writer/transaction authority;
- private VS1B genesis;
- private C2B3D author-effect establishment with inert planned
  `direct_local_bootstrap` author delivery;
- private Section 41 pre-execution proposal selection;
- application generation 2 and migrations through 0003.

Verify that current capability still does not implement:

- executable parent-grant verification or subordinate authorization derivation;
- WorkSpec physical custody or bearer retrieval;
- direct-local adapter, supervisor, worker, Codex invocation, or process launch;
- dispatcher, queue, service, IPC, outbox/inbox, or reconciler;
- capsule builder/store/retrieval;
- validation, independent review, model invocation/proposal runtime, or
  post-execution semantic-decision runtime;
- cancellation delivery/acknowledgement runtime;
- productive-direct-local acceptance latch;
- Git effect;
- Bridge or ES handoff;
- publication or autonomous loop.

EXPECTED OPENING REPOSITORY IDENTITY

Require exactly before correctness inspection:

- Physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- Subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1
- Dirty paths:
  exactly 10
- Tracked modifications:
  exactly 8
- Untracked:
  exactly 2
- Staged/unmerged:
  0/0
- No deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  or Git lock
- Repository residue:
  empty
- `git diff --check HEAD --`:
  clean.

Expected path classifications:

Tracked modifications:

.docs/c2b-durable-development-state.md
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_architecture_contracts.py
tests/test_c2b3c_author_effect_contract.py

Untracked:

.docs/rw0-remote-worker-contact-phase-entry.md
tests/test_rw0_remote_contact_phase_entry_contract.py

Expected local mode posture:

- these nine paths are regular working-tree mode `0644`:

  .docs/rw0-remote-worker-contact-phase-entry.md
  .docs/c2b-durable-development-state.md
  .docs/autonomous-software-development-operating-model.md
  .docs/worker-execution-boundary.md
  .docs/authority-boundaries.md
  .docs/durable-state-model.md
  tests/test_rw0_remote_contact_phase_entry_contract.py
  tests/test_remote_worker_pre_execution_planning_contract.py
  tests/test_architecture_contracts.py

- this path is regular working-tree mode `0600`, current-operator-owned, with no
  execute bits:

  tests/test_c2b3c_author_effect_contract.py

- Git index mode for every tracked candidate path is `100644`;
- no Git-recorded mode change exists.

The local `0600` mode is a restrictive working-tree metadata overlay. Do not
chmod it. It is not a candidate defect when content, ownership, no-execute
posture, target manifest, and Git index mode match.

Do not fetch or contact a remote. Any identity, topology, path-set,
classification, mode, or branch mismatch is AUDIT_PROVENANCE_MISMATCH.

AUTHORITATIVE FINAL AUDIT TARGET

Use exactly:

/private/tmp/ge-rw0a-audit-repair.jmT10j/final-manifest-immutable.json

Require:

- every path component lstat-safe and non-symlink;
- implementation evidence root operator-owned, non-symlink, mode 0700;
- manifest regular and safely readable;
- size:
  2,328 bytes;
- SHA-256:
  29044da643bf1300aec209fbf7df5d1b7fed2d79bf076b08931562ce6b47ab63.

Before running the provenance recipe:

1. Verify the target safely through every path component.
2. Copy the exact verified bytes into the audit root as an immutable mode-0400
   target.
3. Parse canonical JSON and require:
   - recipe_id:
     governed-execution.audit-patch-manifest.v1
   - branch:
     codex/rw0-phase-entry-contract-freeze
   - head:
     1a894c5527c610ab40d8e5ae5e530a762c6e60bf
   - upstream:
     origin/trunk_dev
   - exactly ten entries;
   - exactly eight `tracked_modified`;
   - exactly two `untracked`;
   - the C2B3C test is regular mode `0600`;
   - every other entry is regular mode `0644`;
   - no tracked addition/deletion, missing path, symlink, or unsupported type.

If the retained target is missing, unsafe, malformed, or different, return
AUDIT_PROVENANCE_MISMATCH. Do not reconstruct it from the live tree,
implementation report, aggregate hashes, or an earlier manifest.

PRECEDING FIRST-AUDIT TARGET

Safely verify and copy:

/private/tmp/ge-coordinator-rw0a-marker-repair.vOkQZp/final-manifest-immutable.json

Expected:

- size:
  2,328 bytes
- SHA-256:
  71d13c026567732210e1a35f5fa962b0efa853c35eb6797d0af745bc02fd3394.

Require an entry-by-entry comparison between the preceding and final targets.

Exactly these eight entries may differ:

.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/worker-execution-boundary.md
tests/test_architecture_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py

Require their complete preceding/final identities:

1. .docs/authority-boundaries.md
   - preceding:
     27,336 bytes
     134e0bc41ef4c4270e2fa06c155642c1d8dc9ac08d72f874c13517d7e03124b2
   - final:
     27,727 bytes
     087e212754a6440b735d443292ed92e649976e2993852d42daf527631dd6b7bf

2. .docs/autonomous-software-development-operating-model.md
   - preceding:
     29,334 bytes
     27c054b19614e54200862b878a885918d2fa4966f2eeb757e6ad6360af7c42fd
   - final:
     29,725 bytes
     70c752100c92469d58e49f9a415f9d0dcfaa2ec813c009790382a62d3507be48

3. .docs/durable-state-model.md
   - preceding:
     32,521 bytes
     b3128e0e2bf0822190ef9f202413be1c7e31fb9495238c088087e25a4a61652f
   - final:
     32,912 bytes
     95e226e0a57448f2bbc26b8a7c10a176b218c91bcd386cc8f07192fc46c34a83

4. .docs/rw0-remote-worker-contact-phase-entry.md
   - preceding:
     25,980 bytes
     cb66611dc078c16feb834409ef758581f7d7fdcddc1406bbbb80958fa0c7ea87
   - final:
     31,539 bytes
     426a6cd2eca27049e8d1b866f4a2cc069ba084b82220fbfbee341ede16cee1a7

5. .docs/worker-execution-boundary.md
   - preceding:
     23,585 bytes
     fc6e7cf8284f03a2afd33e3fa06aa2efcf5a322ffa53cbac76e82aa9b10b8421
   - final:
     23,976 bytes
     89bafefe6cea60a331a337208cc6006144b71dc22656aff78da97bf725840097

6. tests/test_architecture_contracts.py
   - preceding:
     75,467 bytes
     5611f40e9c086feecad9404eaa951cdad51b89c0025bf18367a29bc65d006c1d
   - final:
     82,420 bytes
     0185e978b1e7975471fd13381303916fcb368652d09dc2d56db108bb78133466

7. tests/test_remote_worker_pre_execution_planning_contract.py
   - preceding:
     896,742 bytes
     dc990952b92d24773babeabb0d7cfea57e5cb4a93a499dcf6ab6e59fcd917be3
   - final:
     902,800 bytes
     3d1fa58194d42eb6da4e5bc7d7ce3a058332d685430bb4dd183294721dc28818

8. tests/test_rw0_remote_contact_phase_entry_contract.py
   - preceding:
     32,318 bytes
     fb0baaf09fbfd730dd8af4000763f3ff15c2735d86ea79af0fcd6aeec08cf81f
   - final:
     52,626 bytes
     af16ae325283046970bd39ece4964553e87aca0591e043039b6147bba23fb7c0

All other two entries must match exactly:

- .docs/c2b-durable-development-state.md
  - size:
    1,884,626 bytes
  - SHA-256:
    5fd66a1266e63f8f026a27de7d84f42029813acdadc6b3ecb1978c3ff9ce9b1e
  - mode:
    0644

- tests/test_c2b3c_author_effect_contract.py
  - size:
    416,182 bytes
  - SHA-256:
    935ca6fe7b18d39055d5cdc2c911302e7c0726304f3699472f3994a32f7b4778
  - working-tree mode:
    0600
  - Git index mode:
    100644

Any ninth changed entry or protected-entry mismatch is
AUDIT_PROVENANCE_MISMATCH.

EXPECTED PROVENANCE RECIPE

Recipe ID:

governed-execution.audit-patch-manifest.v1

Exact source size:

3,945 bytes

Exact source SHA-256:

db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Use the exact source below. Do not normalize, improve, approximate, or version
it during the audit.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

OPENING PROVENANCE GATE

1. Verify exact recipe source size and SHA-256.
2. Safely classify the fixed output path:
   /tmp/ge-coordinator-b3a-audit-manifest-v1.json
3. If it exists:
   - require a regular non-symlink operator-owned file;
   - preserve exact pre-audit bytes and metadata in the audit root;
   - do not delete unrelated evidence.
4. Run the exact recipe twice.
5. Require both invocations to return 0 with empty stderr.
6. Require both complete stdout byte strings to be identical.
7. Require both generated canonical manifest byte strings to be identical.
8. Require generated canonical bytes to equal the immutable final target
   byte-for-byte.
9. Compare every path, classification, type, mode, size, and SHA-256 entry.

Require exactly:

- Complete stdout:
  2,561 bytes
- Complete-output SHA-256:
  24071f487f4e9a61a92e3871ae43ef8de228f986941bf67c6ea139ca7d1addb6
- Stderr:
  0 bytes
- Tracked textual-diff SHA-256:
  a5972c454f89bd17da1f3aba3f5d7fa44914fe2fd63f9cea9ea893928d162dac
- Canonical manifest:
  2,328 bytes
- Canonical-manifest SHA-256:
  29044da643bf1300aec209fbf7df5d1b7fed2d79bf076b08931562ce6b47ab63
- File count:
  10

Any mismatch is AUDIT_PROVENANCE_MISMATCH. Stop before correctness inspection.

PROTECTED BASELINE AND APPEND-ONLY PINS

Require exact append-only preservation:

1. `.docs/c2b-durable-development-state.md`

   The complete committed-baseline bytes remain the exact candidate prefix:

   - 1,883,380 bytes
   - SHA-256:
     9401d62a0eb36e0cca1af5b8a6a80b540ddc4c781fee3faaf7318546cb532ccc

2. The append-only RW0 target block occurs wholly after that prefix and after:

   `COORDINATOR_SECTION41_COMMITTED_CURRENT_STATUS_END`

Require:

- final visible H2 remains Section 42;
- no H2 Section 43;
- the RW0 target block is one visible, unfenced H3 under final H2 Section 42;
- the current exact-column-order owner and all pre-existing Section 42 bytes
  remain unchanged.

Require no diff outside the ten-path target, especially no diff in:

- AGENTS.md
- README.md
- .docs/architecture.md
- .docs/c2a-first-slice-semantic-protocol-contract.md
- .docs/software-development-progression-boundary.md
- every `src/**` path
- all SQL and migrations
- migration catalog and application generation
- schemas
- package exports and public protocols
- StateStore and WriterSession
- fixtures, scripts, configs, examples, or supporting repositories.

TARGETED AUDIT TASKS

Only after provenance matches, spawn exactly four bounded read-only audit tasks
in parallel when capacity permits. No nested subagents and no subagent-run
tests. If runtime capacity permits only three concurrent tasks, start the
fourth immediately when a slot frees. Make at most one retry for a failed start.

Give every task the same exact target manifest identity, preceding audit
findings, parent repair decisions, current contract, accepted strategic target,
reopened seams, compatibility obligations, non-goals, and mutation prohibition.

1. EFFECT, AUTHORITY, FENCE, AND NONIMPLEMENTATION AUDITOR

   Inspect the complete changed documentation and relevant unchanged C2A/C2B3D/
   Section 41 contracts.

   Determine whether:
   - one author-candidate delivery is distinguished from separate validation,
     review, and active-cancellation current-effect deliveries;
   - no author redelivery/relaunch/replacement author effect or attempt exists;
   - model proposal remains a source invocation/proposal rather than a
     DeliveryEnvelope effect;
   - existing author attempt/effect fences remain exact inert persisted bounds;
   - fresh parent-grant verification plus a Coordinator-derived narrower
     subordinate authorization binds those exact existing author fences;
   - later validation/review/cancellation current effects use their own effect
     intents/fences inside the verified parent grant;
   - complete grant/subordinate/applicable-fence/revocation/expiry/repository/
     base/path/global-stop relations are required before every effect;
   - current runtime remains unsupported and fail-closed;
   - no current capability or implementation detail is overclaimed.

2. TIMELINE, CANCELLATION, FACT OWNERSHIP, AND ES/IM AUDITOR

   Inspect the sole owner, identity/fact matrix, timelines, failure/recovery
   table, cancellation sequence, worker boundary, and ES/IM statements.

   Determine whether:
   - normal and active-cancellation branches are distinct and coherent;
   - early cancellation intent/decision is not the final terminal `cancel`;
   - final `cancel` occurs only after required request/ack/signal/exit/teardown
     reconciliation;
   - unresolved cleanup/process state can terminate as `block`;
   - every terminal outcome ends RW0 without successor, Git, or publication;
   - supervisor process launch differs from worker-authored `worker_started`;
   - worker owns canonical started/completed/candidate observations while
     supervisor/OS own launch/exit/deadline facts;
   - direct-local owns only route-local process/cancel delivery/receipt facts;
   - ES retains ES-route admission, reliable submit, lifecycle, cancellation,
     route correlations, runtime identity/credentials, and retained results;
   - Coordinator owns semantic progression/ingest/decision rather than route
     lifecycle;
   - IM remains evidence-only and non-enduring architecture.

3. MARKDOWN OWNERSHIP, TERMINAL INVENTORY, AND TEST-CAUSALITY AUDITOR

   Inspect all changed tests and all candidate documents.

   Determine whether:
   - one fence-aware structural model per test file handles 0–3-space ATX
     headings, backtick/tilde fences, visible markers, parent ranges, and
     same-title sibling/ancestor ownership;
   - the sole owner requires one visible unfenced BEGIN/END pair and accepts one
     visible pair plus irrelevant hidden duplicate;
   - the four cross-reference blocks require complete visible bodies in exact
     current owner ranges and accept hidden duplicates without raw-count
     authority;
   - hidden/fenced-only, split-marker, historical, same-title, empty-visible-
     plus-hidden-real, and duplicate-visible mutants fail;
   - both terminal regions independently parse every visible legal-indentation
     inventory candidate;
   - each region contains exactly one ordered six-outcome inventory;
   - each region independently states every outcome ends RW0, no successor is
     launched, and no Git/publication follows;
   - broken raw/whole-document controls reproduce the predecessor defects and
     are never authoritative;
   - all semantic mutants for RW0-01, RW0-04, RW0-05, RW0-08, and RW0-09 are
     causal;
   - no existing test was weakened or its node identity changed.

4. PROVENANCE, SECURITY, PUBLIC-BOUNDARY, AND ARTIFACT AUDITOR

   Inspect:
   - the entire ten-path diff;
   - the exact eight-entry preceding-to-final delta;
   - protected C2B and C2B3C bytes;
   - local `0600` versus Git `100644` posture;
   - retained implementation evidence;
   - validation records and node lists;
   - source/schema/migration/public-surface diff guards;
   - artifact and sensitive-material posture.

   Determine whether:
   - the candidate is genuinely docs/tests-only;
   - no credential, bearer, raw WorkSpec, prompt, transcript, endpoint, private
     host identity, or sensitive log is embedded;
   - no source, process, worker, model, service, network, or database behavior
     was introduced;
   - no evidence or report became authority;
   - the candidate is suitable for a later audited-byte feature-branch commit
     and PR gate.

Each task must return severity-ranked, path:line-grounded findings and state:

- current contract versus strategic target;
- patch defect versus pre-existing issue;
- impact;
- required correction;
- uncertainty;
- scope not inspected;
- mutation performed:
  no;
- tests run:
  no;
- nested subagents:
  no.

The parent must directly inspect and reconcile every report. Preserve factual,
interpretive, or target-level disagreements.

MANDATORY PARENT INSPECTION

Inspect directly:

- both authoritative manifests and the exact eight-entry comparison;
- all ten candidate paths;
- complete diff against HEAD and complete preceding-to-final diffs for the eight
  changed entries;
- current C2A delivery/fence/observation/cancellation contracts;
- current C2B3D and Section 41 lineage/nonimplementation contracts;
- every changed sole-owner section, matrix, timeline, and branch;
- all four changed bounded cross-reference bodies and structural owners;
- every changed test helper and existing strengthened test node;
- broken raw/whole-document mutation controls;
- protected C2B and C2B3C bytes;
- retained validation and evidence records.

Do not re-audit unchanged runtime internals wholesale after exact no-diff proof,
unless the changed documentation or tests contradict them.

ACCEPTANCE CHECK — AUTHOR AND LATER CURRENT-EFFECT DELIVERIES

Require the target to state and tests to enforce:

1. The selected C2B3D `author_candidate` effect has exactly one existing initial
   delivery identity and at most one actual author-candidate delivery in RW0.

2. No author redelivery, relaunch, replacement author effect, second author
   attempt, or replacement candidate-authoring invocation occurs.

3. If reached, validation, independent review, and active cancellation each use
   a distinct current effect intent, current effect fence, and initial delivery
   under the same originating semantic attempt and author-command lineage.

4. At most one actual delivery exists for each reached effect instance.

5. Every reached effect has zero redelivery/retry in RW0; ambiguity stops and
   reconciles.

6. Model proposal is a separate source invocation/proposal, not a
   DeliveryEnvelope effect class.

7. There remains exactly one candidate and one final Coordinator semantic
   decision, with at most one productive acceptance.

Independently mutate:

- “one author delivery” into one total delivery;
- reuse author delivery for validation/review/cancel;
- permit author redelivery/relaunch;
- turn model proposal into a DeliveryEnvelope effect;
- permit a second author effect/attempt/candidate.

Require rejection for the causal reason.

ACCEPTANCE CHECK — EXISTING FENCES AND SUBORDINATE AUTHORIZATION

Require:

- C2B3D already persisted exact author attempt/effect fence identities/digests;
- those fences remain inert bounds, not permission;
- RW0 reconstructs and reuses the exact author fences without replacement;
- fresh verification occurs before retrieval and again before launch/effect;
- Coordinator derives only a narrower subordinate authorization record inside
  the verified parent grant and binds it to exact existing author fences;
- Coordinator never authors, renews, widens, reinterprets, or outlives the
  parent grant;
- later validation/review/cancel effects may establish their distinct current
  effect fences inside the verified grant;
- complete grant, subordinate authorization, applicable attempt/effect fence,
  expiry, revocation, repository/base/path, and global-stop relations are
  required before every effect;
- current executable authorization remains unsupported.

Independently reject:

- minting replacement author fences;
- treating existing fences alone as permission;
- omitting subordinate authorization;
- omitting any currentness/scope relation;
- making Coordinator an independent parent-grant issuer;
- making later-effect fences identical to the author effect fence.

ACCEPTANCE CHECK — NORMAL AND CANCELLATION BRANCHES

Require an explicit normal/non-cancel branch:

- validation/review/model proposal complete or become conclusively unavailable;
- Coordinator commits one of:
  `accept`, `repair`, `replan`, `terminal_reject`, `block`;
- only committed `accept` consumes the latch;
- cleanup/custody terminal facts follow without changing semantic outcome;
- no successor/Git/publication follows.

Require an explicit active-cancellation branch:

1. commit cancellation intent/decision, not terminal `cancel`;
2. establish distinct `cancel_effect`, current effect fence, and delivery;
3. request;
4. acknowledgement;
5. signal;
6. process exit;
7. workspace teardown;
8. reconciliation;
9. final terminal `cancel` or `block` when unresolved.

Require none of those facts to imply the next.

Independently reject:

- terminal `cancel` before exit/teardown;
- collapse of early intent and final outcome;
- semantic cancel implied by request/ack/signal alone;
- cleanup ambiguity still producing terminal cancel;
- successor launch or Git/publication after either branch.

ACCEPTANCE CHECK — FACT OWNERS

Require:

- supervisor owns process-launch attempt, process-group control, deadlines,
  signals, and route-local supervision;
- worker is underlying fact owner and canonical observation author for
  `worker_started`, `worker_completed`, and `candidate_captured`;
- OS/supervisor evidence owns process exit and deadlines;
- adapter/supervisor may carry but not author worker observations;
- process launch does not prove `worker_started`;
- `worker_started` does not prove completion/candidate capture.

Reject supervisor-authored worker-start or process-launch-implies-start mutants.

ACCEPTANCE CHECK — DIRECT-LOCAL AND ES OWNERSHIP

Require:

- direct-local owns only direct-local route process control, cancellation
  request delivery, route receipts, and source-native reconciliation facts;
- ES owns ES-route admission, reliable submit, runtime lifecycle, cancellation,
  runtime identity/credential handoff, route correlations, and retained results
  when ES route is used;
- Coordinator owns semantic progression, safe observation ingest, and final
  decision;
- direct-local creates no parallel ES lifecycle truth and claims no ES-route
  facts;
- ES ownership wording does not deny direct-local’s own bounded route-local
  responsibilities;
- IM remains corroborating evidence only.

Independently reject both:
- direct-local absorbing ES route authority; and
- wording that denies direct-local its own process/cancellation role.

ACCEPTANCE CHECK — SOLE OWNER MARKDOWN

Require:

- exactly one visible, unfenced BEGIN/END pair;
- markers enclose the complete live owner body;
- intended owner/ancestor events are unique and stable;
- one visible owner plus irrelevant hidden duplicate bytes is accepted;
- two visible owners rejected;
- fenced BEGIN/END, split/reversed pair, hidden-only pair, historical/same-title
  relocation, and pair outside the owner fail;
- raw counts/find/index/splits do not determine authority;
- broken raw-marker control accepts at least one predecessor mutant while the
  final oracle rejects the same bytes.

ACCEPTANCE CHECK — FOUR CROSS-REFERENCES

For exactly:

.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md

Require:

- one complete visible begin/body/end block per intended current owner range;
- unique parent, owner, predecessor, and range terminator;
- normalized bodies identical;
- one visible block plus irrelevant hidden duplicate accepted;
- two visible blocks rejected;
- fenced-only body, visible empty owner plus hidden real body, split markers,
  historical relocation, and same-title sibling/ancestor relocation rejected;
- raw marker/body counting is diagnostic only;
- broken raw-body checker reproduces the prior bypass and is never authoritative.

ACCEPTANCE CHECK — TERMINAL INVENTORIES

For each structurally owned region:

- `Bounded RW0 scenario class`;
- `Capsule, validation, review, model, and decision`;

require independently:

- exactly one visible authoritative inventory;
- every visible legal Markdown inventory candidate is counted, including 0–3
  ASCII-space indentation;
- fenced content is ignored;
- exact ordered domain:
  `accept`, `repair`, `replan`, `terminal_reject`, `block`, `cancel`;
- no missing, duplicate, substituted, reordered, seventh, sibling, indented
  duplicate, fenced, or relocated inventory;
- exact independent rule:
  every outcome ends RW0;
- exact independent rule:
  no successor launches in RW0;
- exact independent rule:
  no Git or publication effect follows.

Require the broken whole-document checker to accept the predecessor one-region
mutant while the final region-scoped oracle rejects it.

CURRENT-VERSUS-TARGET AND DEFERRED DECISIONS

Require all changed documents to preserve:

- accepted strategic target, not current runtime claim;
- external parent grant plus Coordinator-derived narrower subordinate target;
- raw WorkSpec privacy and ref/digest non-authority;
- exact custodian/issuer/backend/transport/Codex/sandbox/framing/schema/latch/
  capsule/validator/reviewer/model/ES details remain deferred;
- one qualified remote Linux host, no fallback, no third adapter;
- provisional ES fixture remains non-authoritative and stale-able;
- base/path drift requires replan/new WorkSpec;
- no Git/publication in RW0.

IMPLEMENTATION EVIDENCE TO INSPECT, NOT TRUST

Safely inspect:

/private/tmp/ge-rw0a-audit-repair.jmT10j

At minimum inspect:

- causal_red/report.json
- final_direct/report.json
- final_architecture/report.json
- final_remote_worker/report.json
- final_c2b3c/report.json
- final_focused/report.json
- full_suite/report.json
- final_nodes/node-list.txt
- final-manifest-immutable.json
- final-guard.json
- recipe.py

Verify reported hashes where present:

- causal-red JUnit:
  d31cbea8b4d97375b7338d8c9f5baf99d4e5aa910b2af184ace15102532e927e
- direct JUnit:
  7b660a5279d7d55ccabdabd44cb617d5d277aff9217eef003dc61eed3301c2e3
- architecture JUnit:
  288eacf47a98507b2f8998a713b554a18c5c9442fbb631aa2d63d1e0e2068f64
- remote-worker JUnit:
  068c5bd6aeffc31d2e00e277c4c6da36b1831ef5960ee8311f9d0cd814ec8dea
- C2B3C JUnit:
  9d52670bac8200d46dd4f659dd7365ca9e5bfc1635e8c71a458756d97fbdeadf
- focused JUnit:
  60bd6937cd8a66999b9eb263e47af5bf7102bdbfb393b9fcf621c426fc9a3702
- full-suite JUnit:
  744b56c886eea8c75a564bdc615a036c218aac2ed10cac987abfd3bf60bcd794
- final guard:
  4f865d46fac45b81ad1d57700ad3fe3e129fede3f6cb77bfa16a332b0d4528d1

The predecessor independent-audit root may not contain a standalone report or
mutant log. The complete predecessor audit finding text is supplied in this
engagement and must be independently reproduced. Do not infer that missing
retained files close or reopen a finding.

No correctness credit comes from implementation evidence.

VALIDATION ISOLATION

Use one audit-created external, operator-owned, non-symlink, mode-0700 root.

For every pytest child:

- save actual caller umask;
- create evidence under secure posture;
- restore caller umask before launch;
- record child-observed umask and require numerical equality;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`
  - `LC_ALL=C`
  - `LANG=C`
  - `PYTHONDONTWRITEBYTECODE=1`
  - distinct external `PYTHONPYCACHEPREFIX`
  - distinct external `TMPDIR`
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
  - `PYTEST_ADDOPTS=''`
  - `PYTHONHASHSEED=0`
  - `python3 -B -m pytest`
  - `-p no:cacheprovider`
  - `-W error`
  - distinct external `--basetemp`
  - external `--junitxml`
  - serial execution.

Retain exact argv, environment, caller/child umask, return code, elapsed time,
stdout/stderr/JUnit sizes and SHA-256, parsed counts, warnings, parse errors,
unmapped cases, and before/after target equality.

DIRECT RW0-A ORACLE — EXACTLY ONCE

Run:

tests/test_rw0_remote_contact_phase_entry_contract.py

Require exactly 28/28 green.

ARCHITECTURE REGRESSION — EXACTLY ONCE

Run:

tests/test_architecture_contracts.py

Require exactly 30/30 green.

REMOTE-WORKER REGRESSION — EXACTLY ONCE

Run:

tests/test_remote_worker_pre_execution_planning_contract.py

Require exactly 774/774 green.

C2B3C PROTECTED REGRESSION — EXACTLY ONCE

Run:

tests/test_c2b3c_author_effect_contract.py

Require exactly 46/46 green.

COMPLETE RW0-A FOCUSED REGRESSION — EXACTLY ONCE

Run exactly:

tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_software_development_progression_boundary.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_worker_execution_semantic_boundaries.py

Require exactly 1,565/1,565 green.

NODE IDENTITY

After focused validation:

1. Collect the candidate exactly once.
2. Require exactly 4,284 node IDs.
3. Create one clean external `git archive HEAD`.
4. Collect HEAD exactly once.
5. Require exactly 4,256 HEAD node IDs.
6. Require:
   - intersection:
     4,256;
   - candidate-only:
     exactly 28;
   - HEAD-only:
     0;
   - all 28 candidate-only nodes belong to
     `tests/test_rw0_remote_contact_phase_entry_contract.py`;
   - no existing node changed identity or order.
7. Require exact candidate node-list SHA-256:
   7fb16833d1fcf8916f62ad17b0238b87b8cda8bb03432039771290bc713d12e8
8. Require exact existing-file counts:
   - architecture:
     30;
   - C2B3C:
     46;
   - remote-worker:
     774;
   - direct RW0-A:
     28.

FULL SUITE — EXACTLY ONCE

Only after inspection, independent mutants, targeted/focused validation, node
comparison, and artifact cleanup are green, run the complete repository suite
exactly once:

python3 -B -m pytest -p no:cacheprovider -W error \
  --basetemp=<external> \
  --junitxml=<external> \
  .

Require exactly:

- 4,284 collected;
- 4,284 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository bytes, modes, topology, and target manifest unchanged.

Do not run a second full-suite attempt. If immutable JUnit parsing initially
misclassifies paths, reparse the same JUnit without rerunning pytest.

FINAL GUARDS

Require:

- exact ten-path target set;
- exactly eight tracked modifications and two untracked paths;
- zero staged or unmerged paths;
- expected local mode posture, including C2B3C `0600`;
- Git index mode `100644` for every tracked candidate path;
- no Git-recorded mode change;
- no path outside target changed;
- protected C2B and C2B3C entries exact;
- append-only prefix exact;
- final H2 Section 42 and no Section 43;
- four bounded cross-reference bodies normalized-identical;
- one sole detailed RW0 owner;
- no current implementation overclaim;
- no enduring ES fixture, custodian, SSH/framing, Codex, schema, latch,
  capsule-backend, validator/reviewer/model-adapter, or ES reliable-submit
  choice accidentally frozen;
- no source, SQL, migration, catalog, schema, application-generation, package,
  public protocol, StateStore, WriterSession, runtime, fixture, script, config,
  or supporting-repository diff;
- `git diff --check` clean;
- no repository cache, bytecode, pytest cache, database, journal, WAL/SHM,
  build output, archive, generated manifest, or OS metadata;
- no Git operation or lock;
- no remote contact or runtime effect.

FINDING AND VERDICT RULES

Classify findings by:

- current-versus-target contract drift;
- effect-delivery or authority/fence drift;
- identity/fact ownership defect;
- ambiguity/recovery/cancellation defect;
- ES/IM ownership drift;
- Markdown ownership/liveness defect;
- test/mutation inadequacy;
- source/public-boundary widening;
- security/privacy issue;
- provenance/validation gap;
- artifact hygiene issue;
- pre-existing observation outside the patch.

Use severity:

critical
high
medium
low
observation

For every finding report:

- stable ID;
- type and severity;
- exact path:line evidence;
- current contract or strategic target;
- impact;
- required correction;
- uncertainty;
- patch defect or pre-existing issue.

ACCEPT only when:

- opening and closing provenance equal the exact final target;
- preceding and final manifests differ in exactly the eight authorized entries;
- all four audit tasks complete;
- RW0-01 through RW0-09 are independently and causally closed;
- the entire ten-path candidate satisfies the corrected RW0-A target;
- current implementation is not overclaimed;
- existing author fences remain exact and non-authorizing;
- separate later current-effect deliveries are correctly bounded;
- normal and active-cancellation branches are unambiguous;
- process launch and worker-start fact ownership is exact;
- direct-local and ES route responsibilities are exact;
- sole-owner, cross-reference, and terminal-inventory oracles are structurally
  causal and accept valid hidden duplicates while rejecting invalid hidden
  owners/bodies;
- no existing test was weakened or its node identity changed;
- direct, architecture, remote-worker, C2B3C, focused, node, and full-suite
  validation are exact-green;
- no Critical, High, Medium, or Low patch defect remains;
- the exact candidate is suitable for an audited-byte feature-branch commit,
  push, PR, and later squash-merge gate.

Use BLOCK for a repairable defect, non-green validation, materially incomplete
evidence, or unresolved uncertainty preventing acceptance.

Use REJECT only for a fundamental architecture or authority failure that cannot
be repaired within RW0-A.

Use AUDIT_PROVENANCE_MISMATCH for target-byte, branch, path-set, topology,
recipe, retained-manifest, mode, or classification mismatch.

CLOSEOUT PROVENANCE

After all inspection and validation, and after removing only safe
audit-created external artifacts:

1. Run the exact recipe twice again.
2. Require complete identity with the immutable opening target.
3. Recheck append-only prefix, protected entries, modes, Git index modes, path
   set, topology, residue, operations, and locks.
4. Do not accept if audit activity changed repository bytes or metadata, even if
   later restored.

FINAL REPORT

Begin with exactly one primary verdict token:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Then report:

1. Exact opening and closing identity/provenance.
2. Exact preceding-to-final eight-entry comparison.
3. Audit tasks, completion, retries, and disagreements.
4. Complete severity-ranked finding ledger.
5. Disposition of RW0-01 through RW0-09.
6. Current implementation versus RW0 target assessment.
7. Author/later-effect delivery and authority/fence assessment.
8. Normal/cancellation branch and fact-owner assessment.
9. Direct-local/ES/IM ownership assessment.
10. Sole-owner, four-cross-reference, and terminal-inventory Markdown results.
11. Independent mutant matrix results.
12. Test non-weakening and node-identity assessment.
13. Direct, architecture, remote-worker, C2B3C, focused, and full-suite
    validation.
14. Protected-byte, mode, public-boundary, security, and artifact checks.
15. Limitations and separate provenance, validation, and implementation
    confidence estimates.

If ACCEPT, include:

COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FREEZE_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

If not ACCEPT, do not provide a commit or PR prompt and do not repair.

Required closing statements:

REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
