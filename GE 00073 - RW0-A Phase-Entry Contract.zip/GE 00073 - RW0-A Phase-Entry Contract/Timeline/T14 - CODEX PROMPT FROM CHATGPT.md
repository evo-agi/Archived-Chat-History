TITLE

Coordinator RW0-A phase-entry contract freeze — fresh independent audit of the
exact final ten-path candidate

ENGAGEMENT TYPE

Fresh-conversation independent audit.

Run this in a new Codex conversation with read-only repository posture.

Do not resume or use the implementation conversation as this audit
conversation. Its reports and retained evidence are inputs only.

Repository mutation is not authorized. Do not edit, format, create, delete,
rename, chmod, clean repository paths, switch branches, stage, commit, amend,
push, create or update a PR, merge, rebase, reset, tag, release, deploy,
install dependencies, run live migrations, invoke a model/provider or Codex,
launch a worker/process, contact a host, Bridge, Execution Substrate,
Infrastructure Manager, or any remote.

Temporary audit output is authorized only beneath one audit-created,
operator-owned, non-symlink, mode-0700 external root. Do not write audit output
inside the repository. Remove only audit-created external artifacts when safe.
Do not delete, overwrite, or normalize implementation evidence.

If any repository byte, local permission, path, index entry, branch, Git
operation state, or topology changes, stop and report it. Do not silently
restore or clean it.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

WORKSTREAM

COORDINATOR_RW0_REMOTE_CONTACT_PHASE_ENTRY_V1

TRANCHE

RW0-A-PHASE-ENTRY-CONTRACT-FREEZE

PRIMARY OBJECTIVE

Independently audit the exact final ten-path RW0-A docs-and-contract-tests
candidate.

The candidate is intended to freeze only the target operating model for:

current VS1B → C2B3D → Section 41 selected lineage
→ future receipt-backed no-contact phase entry
→ future fresh authority, host, and custody gates
→ one future direct-local delivery to one qualified remote Linux host
→ one future process-separated author worker
→ one future immutable capsule
→ future validation, independent review, and non-authoritative model proposal
→ one future Coordinator semantic decision
→ no Git effect
→ no publication.

The tranche must not claim that any RW0 runtime capability exists today.

The implementation reports that:

- one authoritative RW0 target document was added;
- four bounded current-target cross-references were added;
- one append-only H3 target cross-reference was added under final H2 Section 42;
- one direct contract-test file with 28 nodes was added;
- three existing tests were updated without changing existing node identity;
- the current implementation-versus-target boundary, external-parent/
  Coordinator-derived-subordinate authority split, WorkSpec privacy boundary,
  proof-fixture non-authority, transport/custody/schema deferrals, one-delivery
  ceiling, terminal outcomes, cancellation ordering, and ES/IM non-absorption
  were frozen;
- a region-scoped terminal-outcome oracle repair was completed;
- the C2B3C committed-status owner was made compatible with later governed H3
  extensions while preserving its exact block;
- duplicate committed-status markers now fail with the exact
  `C2B3C_STATUS_INVALID` diagnostic;
- direct validation passed 28/28;
- the complete C2B3C file passed 46/46;
- the RW0-A focused set passed 1,565/1,565;
- the complete suite passed 4,284/4,284;
- candidate node identity remained exact across the final repair;
- no worker, model, process, network, remote, supporting-repository, staging, or
  publication effect occurred.

Do not trust those claims as correctness evidence.

First bind the audit to the exact final manifest. Then independently inspect the
entire ten-path candidate, its current-versus-target semantics, authority and
custody model, identity/fact timeline, failure/cancellation model, Markdown
ownership, causal test adequacy, compatibility repairs, and protected
nonimplementation boundaries.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Do not repair findings.

CURRENT COMMITTED BASELINE

Treat these as expected Git facts to verify:

- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- HEAD tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- HEAD subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1

CURRENT IMPLEMENTATION BOUNDARY

Verify from the committed baseline and unchanged source that current capability
still stops at:

- internal C2A pure values and validators;
- private readers;
- guarded writer/transaction authority;
- private VS1B genesis;
- private C2B3D author-effect establishment with inert planned
  `direct_local_bootstrap` delivery;
- private Section 41 pre-execution proposal selection;
- application generation 2 and migrations through 0003.

Verify that current capability does not implement:

- executable authority verification or subordinate authorization derivation;
- WorkSpec physical custody or bearer retrieval;
- direct-local adapter, supervisor, worker, Codex invocation, or process launch;
- dispatcher, queue, service, IPC, outbox/inbox, or reconciler;
- capsule builder/store/retrieval;
- validation, independent review, model invocation/proposal runtime, or
  post-execution semantic-decision runtime;
- cancellation delivery/acknowledgement runtime;
- productive-direct-local acceptance latch;
- Git effect;
- Bridge or ES handoff;
- publication or autonomous loop.

EXPECTED OPENING REPOSITORY IDENTITY

Require exactly before correctness inspection:

- Physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- Branch:
  codex/rw0-phase-entry-contract-freeze
- HEAD:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Tree:
  53c1834e7e3364c9b278153d5be8b0315d88ff5c
- Sole parent:
  394d625aa63935140eeaf88ecff6f59f0547cb7e
- Subject:
  docs: normalize Coordinator post-publication status (#1)
- Upstream:
  origin/trunk_dev
- Local origin/trunk_dev:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- Ahead/behind:
  0/0
- Worktrees:
  1
- Dirty paths:
  exactly 10
- Tracked modifications:
  exactly 8
- Untracked:
  exactly 2
- Staged/unmerged:
  0/0
- No deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  or Git lock
- Repository residue:
  empty
- `git diff --check HEAD --`:
  clean.

Expected local mode posture:

- these nine paths are regular mode `0644`:

  .docs/rw0-remote-worker-contact-phase-entry.md
  .docs/c2b-durable-development-state.md
  .docs/autonomous-software-development-operating-model.md
  .docs/worker-execution-boundary.md
  .docs/authority-boundaries.md
  .docs/durable-state-model.md
  tests/test_rw0_remote_contact_phase_entry_contract.py
  tests/test_remote_worker_pre_execution_planning_contract.py
  tests/test_architecture_contracts.py

- this path is regular working-tree mode `0600`, current-operator-owned, with no
  execute bits:

  tests/test_c2b3c_author_effect_contract.py

- Git index mode for every tracked candidate path is `100644`;
- no Git-recorded mode change exists.

The local `0600` mode is a restrictive working-tree metadata overlay. Do not
chmod it. It is not a candidate defect when the target manifest, file content,
owner, no-execute posture, and Git index mode all match.

Do not fetch or contact a remote. Any identity, topology, path-set,
classification, mode, or branch mismatch is AUDIT_PROVENANCE_MISMATCH.

AUTHORITATIVE FINAL AUDIT TARGET

Use exactly:

/private/tmp/ge-coordinator-rw0a-marker-repair.vOkQZp/final-manifest-immutable.json

Require:

- every path component lstat-safe and non-symlink;
- implementation evidence root operator-owned, non-symlink, mode 0700;
- manifest regular and safely readable;
- size:
  2,328 bytes;
- SHA-256:
  71d13c026567732210e1a35f5fa962b0efa853c35eb6797d0af745bc02fd3394.

Before running the provenance recipe:

1. Verify the target safely through every path component.
2. Copy the exact verified bytes into the audit root as an immutable mode-0400
   target.
3. Parse canonical JSON and require:
   - recipe_id:
     governed-execution.audit-patch-manifest.v1
   - branch:
     codex/rw0-phase-entry-contract-freeze
   - head:
     1a894c5527c610ab40d8e5ae5e530a762c6e60bf
   - upstream:
     origin/trunk_dev
   - exactly ten entries;
   - exactly eight `tracked_modified`;
   - exactly two `untracked`;
   - the C2B3C test is regular mode `0600`;
   - every other entry is regular mode `0644`;
   - no tracked addition/deletion, missing path, symlink, or unsupported type.

If the retained target is missing, unsafe, malformed, or different, return
AUDIT_PROVENANCE_MISMATCH. Do not reconstruct it from the live tree,
implementation report, aggregate hashes, or an earlier manifest.

EXPECTED TEN-PATH SET

Require exactly:

.docs/rw0-remote-worker-contact-phase-entry.md
.docs/c2b-durable-development-state.md
.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_architecture_contracts.py
tests/test_c2b3c_author_effect_contract.py

PRECEDING DIAGNOSTIC-REPAIR TARGET

Safely verify and copy:

/private/tmp/ge-coordinator-rw0a-marker-repair.vOkQZp/opening-manifest-immutable.json

Expected:

- size:
  2,328 bytes
- SHA-256:
  e8c5714fcc4d73735198fa3bc48475108c150ba40321c244e4259e48c052066f.

Require the opening and final manifests to differ in exactly one entry:

tests/test_c2b3c_author_effect_contract.py

Require:

- opening:
  416,116 bytes
  SHA-256:
  9719b3a2bab169eba790440381f7120d214a133483e030e188a1613542ca06e2
  regular mode 0600
  `tracked_modified`

- final:
  416,182 bytes
  SHA-256:
  935ca6fe7b18d39055d5cdc2c911302e7c0726304f3699472f3994a32f7b4778
  regular mode 0600
  `tracked_modified`

All other nine entries must match exactly in path, classification, file type,
mode, size, and SHA-256.

This one-entry comparison limits the final repair delta. It does not reduce the
audit scope: the entire ten-path RW0-A candidate must be reviewed.

EXPECTED PROVENANCE RECIPE

Recipe ID:

governed-execution.audit-patch-manifest.v1

Exact source size:

3,945 bytes

Exact source SHA-256:

db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Use the exact source below. Do not normalize, improve, approximate, or version
it during the audit.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

OPENING PROVENANCE GATE

1. Verify exact recipe source size and SHA-256.
2. Safely classify the fixed output path:
   /tmp/ge-coordinator-b3a-audit-manifest-v1.json
3. If it exists:
   - require a regular non-symlink operator-owned file;
   - preserve exact pre-audit bytes and metadata in the audit root;
   - do not delete unrelated evidence.
4. Run the exact recipe twice.
5. Require both invocations to return 0 with empty stderr.
6. Require both complete stdout byte strings to be identical.
7. Require both generated canonical manifest byte strings to be identical.
8. Require generated canonical bytes to equal the immutable final target
   byte-for-byte.
9. Compare every path, classification, type, mode, size, and SHA-256 entry.

Require exactly:

- Complete stdout:
  2,561 bytes
- Complete-output SHA-256:
  0a87b39aa2f91c7df37f42db58e39ae29d21698060bead32c1684081e6f62657
- Stderr:
  0 bytes
- Tracked textual-diff SHA-256:
  8be7180b14f8456990da11e968ef775013aae241aaaefa2ca8c513b9834ab997
- Canonical manifest:
  2,328 bytes
- Canonical-manifest SHA-256:
  71d13c026567732210e1a35f5fa962b0efa853c35eb6797d0af745bc02fd3394
- File count:
  10

Any mismatch is AUDIT_PROVENANCE_MISMATCH. Stop before correctness inspection.

PROTECTED BASELINE AND APPEND-ONLY PINS

Require exact append-only preservation:

1. `.docs/c2b-durable-development-state.md`

   The complete committed-baseline bytes must remain the exact candidate prefix:

   - 1,883,380 bytes
   - SHA-256:
     9401d62a0eb36e0cca1af5b8a6a80b540ddc4c781fee3faaf7318546cb532ccc

2. The append-only RW0 target block must occur wholly after that prefix and
   after the existing
   `COORDINATOR_SECTION41_COMMITTED_CURRENT_STATUS_END` marker.

Require:

- final visible H2 remains Section 42;
- no H2 Section 43;
- the new RW0 target block is one visible, unfenced H3 under final H2 Section 42;
- the current exact-column-order owner and all pre-existing Section 42 bytes
  remain unchanged.

Require no diff outside the ten-path target, especially no diff in:

- AGENTS.md
- README.md
- .docs/architecture.md
- .docs/c2a-first-slice-semantic-protocol-contract.md
- .docs/software-development-progression-boundary.md
- every `src/**` path
- all SQL and migrations
- migration catalog and application generation
- schemas
- package exports and public protocols
- StateStore and WriterSession
- fixtures, scripts, configs, examples, or supporting repositories.

TARGETED AUDIT TASKS

Only after provenance matches, spawn exactly four bounded read-only audit tasks
in parallel when capacity permits. No nested subagents and no subagent-run
tests. If runtime capacity permits only three concurrent tasks, start the
fourth immediately when a slot frees. Make at most one retry for a failed start.

Give every task the same exact target manifest identity, baseline, current
contract, accepted strategic target, reopened seams, compatibility obligations,
non-goals, and mutation prohibition.

1. CONTRACT, AUTHORITY, CUSTODY, AND NONIMPLEMENTATION AUDITOR

   Inspect all six changed/new documents and relevant unchanged owning source
   contracts.

   Determine whether the candidate correctly freezes:
   - current implementation versus target;
   - external parent-grant authorship;
   - Coordinator-derived narrower subordinate attempt/effect records and
     fences inside a freshly verified parent grant;
   - no Coordinator minting, widening, renewing, reinterpreting, or outliving
     the parent grant;
   - WorkSpec privacy, one-use/fresh/revocable retrieval properties without
     selecting an enduring custodian;
   - no synchronous user-per-attempt approval role;
   - current executable authorization remains unsupported and fail-closed;
   - reports, model output, readiness, transport receipts, and artifacts remain
     evidence only.

2. IDENTITY, FACT TIMELINE, FAILURE, CANCELLATION, AND ES/IM AUDITOR

   Inspect the authoritative RW0 document, C2B durable cross-reference, current
   C2A/C2B3D/Section 41 contracts, and bounded ES/IM ownership statements.

   Determine whether the candidate:
   - preserves exact K8 and current L34/head postimage as necessary but
     non-authorizing entry lineage;
   - creates no competing C2A identity;
   - preserves one writer/owner/custodian per fact;
   - separates phase entry, gates, retrieval, delivery, acknowledgement,
     invocation, observation, candidate, capsule, validation, review, model
     proposal, Coordinator decision, latch, teardown, and custody;
   - preserves ambiguity/no-blind-retry/recovery behavior;
   - preserves cancellation fact ordering and non-implication;
   - freezes exactly six terminal outcomes and no successor launch;
   - preserves one delivery and at most one productive acceptance;
   - keeps Git/publication outside RW0;
   - does not absorb ES lifecycle/reliable-submit/cancellation/result authority;
   - treats IM evidence as non-authoritative and non-enduring architecture.

3. MARKDOWN OWNERSHIP AND TEST-CAUSALITY AUDITOR

   Inspect all four test files and all six candidate documents.

   Determine whether:
   - one authoritative RW0 owner document is structurally unique and live;
   - four bounded cross-reference bodies are normalized-identical, visible,
     unfenced, and under their intended current owners;
   - raw hidden markers do not establish ownership;
   - same-title sibling/ancestor relocation cannot masquerade as the intended
     owner;
   - the append-only Section 42 H3 is live, unique, unfenced, subordinate, and
     outside historical bytes;
   - the new direct test statically verifies exact K8 without redefining C2A;
   - current capability overclaims, authority reversal, per-attempt approval,
     ref-as-permission, fixture hardening, transport hardening, fallback, second
     delivery, identity collapse, authoritative evidence, ES/IM absorption,
     Git/publication, missing outcomes, successor launch, cancellation collapse,
     and current-runtime claims are causally rejected;
   - the two terminal-outcome inventories are independently region-scoped;
   - the broken whole-document outcome control reproduces the predecessor
     defect and is never authoritative;
   - C2B3C owns the exact committed-status block at its frozen offset while
     allowing later governed H3 extensions;
   - duplicate committed-status markers fail with exact
     `C2B3C_STATUS_INVALID`;
   - no existing test was weakened or its node identity changed.

4. PROVENANCE, SECURITY, PUBLIC-BOUNDARY, AND ARTIFACT AUDITOR

   Inspect:
   - complete ten-path diff;
   - both authoritative manifests and the exact one-entry final-repair delta;
   - local `0600` versus Git `100644` mode posture;
   - all retained implementation evidence roots;
   - complete validation records and node lists;
   - source/schema/migration/public-surface diff guards;
   - artifact hygiene and sensitive-material posture.

   Determine whether:
   - the candidate is genuinely docs/tests-only;
   - no credential, bearer, raw WorkSpec, prompt, transcript, endpoint, private
     host identity, or sensitive log is embedded;
   - no source, process, worker, model, service, network, or database behavior
     was introduced;
   - no evidence or report became authority;
   - the restrictive `0600` local mode is preserved without Git mode drift;
   - the candidate is suitable for a later audited-byte feature-branch commit
     and PR gate.

Each task must return severity-ranked, path:line-grounded findings and state:

- current contract versus strategic target;
- patch defect versus pre-existing issue;
- impact;
- required correction;
- uncertainty;
- scope not inspected;
- mutation performed:
  no;
- tests run:
  no;
- nested subagents:
  no.

The parent must inspect and reconcile every report. Preserve factual or
interpretive disagreements.

MANDATORY PARENT INSPECTION

Inspect directly:

- all ten changed/untracked paths;
- complete diff against HEAD;
- exact source contracts for K8/L34 and current C2A identities;
- current C2B3D and Section 41 nonimplementation boundaries;
- all new RW0 owner sections and matrices;
- all four bounded cross-reference blocks;
- append-only Section 42 placement;
- every changed test helper and every new direct test;
- terminal-outcome region scopes;
- C2B3C committed-status extraction and marker uniqueness;
- production/package/public-surface diff guards;
- retained validation and failure evidence listed below.

Do not re-audit unchanged runtime internals wholesale after exact no-diff proof
unless the new documentation or tests contradict them.

ACCEPTANCE CHECK — SOLE DETAILED OWNER

Require exactly one:

COORDINATOR_RW0_PHASE_ENTRY_CONTRACT_BEGIN
COORDINATOR_RW0_PHASE_ENTRY_CONTRACT_END

in:

.docs/rw0-remote-worker-contact-phase-entry.md

Require the block to be visible, unfenced, unique, and the sole detailed owner.

Require its status to be explicitly accepted strategic target and
docs/tests-only freeze, not current implementation.

Require all twelve intended subject areas to be complete and internally
consistent:

1. status/scope/nonimplementation;
2. current entry lineage;
3. bounded scenario class;
4. authority model;
5. WorkSpec/selected-plan custody;
6. host/transport/process boundary;
7. identity/fact ownership;
8. target fact timeline;
9. failure/ambiguity/cancellation/recovery;
10. capsule/validation/review/model/decision;
11. ES/IM ownership;
12. tranche map/open decisions.

Reject duplicated detailed ownership in another document.

ACCEPTANCE CHECK — PARENT AND SUBORDINATE AUTHORITY

Require exact target split:

- external standing-policy authority authors the immutable parent grant,
  revocation/expiry/global-stop directives, and ceilings;
- a separate current verifier proves complete parent-grant relations at required
  freshness boundaries;
- Coordinator target derives only narrower subordinate attempt/effect
  authorization records and fences inside the verified parent grant;
- Coordinator does not mint, renew, widen, reinterpret, or outlive the parent
  grant;
- current executable authorization remains unsupported;
- schema, digest, ref, report, readiness, artifact, or model output is never
  permission.

Reject wording that makes subordinate authorization externally authored as the
frozen target or that makes Coordinator an independent parent-grant issuer.

ACCEPTANCE CHECK — WORKSPEC CUSTODY AND PRIVACY

Require:

- raw WorkSpec/plan bytes never enter Coordinator SQLite, reports, argv,
  environment, logs, capsule, or public errors;
- refs/digests are not retrieval authority;
- target retrieval is expiring, one-use, attempt/effect/audience-bound,
  revocable, and out of band;
- restart never reuses a bearer;
- exact custodian, issuer, transport, backend, and credential mechanisms remain
  deferred;
- operator standing provisioning is only a bounded proof candidate;
- no synchronous user-per-attempt approval role is introduced.

ACCEPTANCE CHECK — SCENARIO AND FIXTURE CLASSIFICATION

Require the enduring scenario class to freeze:

- exact repository/base/path-ceiling binding immediately before productive
  work;
- docs/docs-contract-only first task;
- maximum three changed target-repository paths;
- no target runtime/admission/reliable-submit/privileged behavior change;
- base/path drift causes replan and a new WorkSpec;
- one delivery, one worker invocation, one candidate/capsule, bounded
  validation, one independent review, one model proposal, one Coordinator
  decision;
- every outcome terminates RW0;
- no successor launch;
- no Git or publication effect.

If the ES commit/path candidate appears, require it to be explicitly
non-authoritative, stale-able, non-permission evidence. No test may make those
literal fixture values enduring identity or authority.

ACCEPTANCE CHECK — HOST, TRANSPORT, PROCESS, AND DEFERRALS

Require:

- one owner-neutrally qualified remote Linux host;
- no Mac, Coordinator-host, alternate-host fallback, or third adapter;
- `direct_local_bootstrap` retained as compatibility token;
- one authenticated bounded contact and exactly one actual delivery;
- separate adapter, supervisor, author worker, capsule builder/store, validator,
  reviewer, and model adapter roles;
- no role receives Coordinator SQLite/writer authority;
- private/redacted bounded I/O and isolated process/workspace target
  invariants;
- exact SSH/forced-command details, frame encoding, terminal-result grammar,
  numeric caps, sandbox technology, credential broker, Codex CLI/App Server
  choice, capsule backend, and retention mechanics remain deferred.

Reject accidental selection of those details as governing RW0-A architecture.

ACCEPTANCE CHECK — IDENTITY AND FACT OWNERSHIP

Require:

- exact current K8 inventory derived without modifying C2A;
- current exact L34/head postimage required in addition to K8;
- `selected_for_dispatch_gates` remains planning state, not permission;
- no new attempt/effect/command/candidate/initial-delivery identity is invented
  merely for launch;
- phase entry, authority/host/custody gates, retrieval, delivery, invocation,
  observations, candidate, capsule, validation, review, model proposal,
  Coordinator decision, and future Git effect remain distinct;
- safe source observations never become semantic acceptance;
- one authoritative writer/source/custodian is stated for every material fact.

ACCEPTANCE CHECK — FACT TIMELINE AND FAILURE MODEL

Require:

- a receipt-backed no-contact phase-entry claim before external contact;
- fresh authority/host/custody facts before retrieval/launch;
- no raw bearer persistence;
- one pre-send claim and one delivery;
- source observation ingest rather than adapter memory as truth;
- candidate capture and capsule seal as distinct facts;
- validation, review, model proposal, and Coordinator decision as distinct
  effects/facts;
- only committed `accept` consumes the future one-way productive-direct-local
  latch;
- every other outcome terminates without successor launch;
- cleanup/custody terminal facts remain distinct.

Require finite handling of:

- commit uncertainty;
- stale/missing/ambiguous gates;
- retrieval failure/unknown;
- delivery reject/unknown with no second RW0 delivery;
- process start/exit/deadline ambiguity;
- candidate/seal ambiguity;
- validation/review/model inconclusive states;
- Coordinator decision uncertainty;
- cleanup/custody ambiguity;
- global-stop activation at every externally visible phase;
- restart reconciliation without hidden truth or blind retry.

ACCEPTANCE CHECK — TERMINAL OUTCOMES

Require both structurally owned regions independently contain the exact ordered
domain:

accept
repair
replan
terminal_reject
block
cancel

Require both regions independently reject:

- missing outcome;
- substituted outcome;
- reordered outcome;
- duplicate outcome;
- seventh outcome;
- fenced or relocated inventory.

Require both regions preserve that every outcome ends RW0 and no successor is
launched.

Require the deliberately broken whole-document checker to accept the
predecessor-class one-region mutant while the final region-scoped checker
rejects the same bytes. It must never be the authoritative positive oracle.

ACCEPTANCE CHECK — CANCELLATION ORDER

Require the target ordering remain distinct:

Coordinator cancellation decision/intent
→ cancellation effect/delivery
→ request
→ acknowledgement
→ OS signal
→ process exit
→ workspace teardown
→ semantic abandonment/cancellation.

Reject any test or prose that makes one fact imply the next or collapses these
facts.

ACCEPTANCE CHECK — ES AND IM NON-ABSORPTION

Require:

- ES retains admission, resolved effective plan, reliable-submit, runtime
  lifecycle, cancellation, runtime identity/credential handoff, route-owned
  correlations, and retained results;
- direct-local creates no parallel ES lifecycle truth;
- future conformance reuses the same worker artifact and canonical semantic
  bytes while transport wrappers differ;
- IM evidence may corroborate environment/readiness only;
- IM evidence cannot become execution authority, host identity, custody, or
  semantic truth;
- neither supporting repository becomes an enduring runtime dependency by
  inertia.

ACCEPTANCE CHECK — FOUR CROSS-REFERENCES

For exactly:

.docs/autonomous-software-development-operating-model.md
.docs/worker-execution-boundary.md
.docs/authority-boundaries.md
.docs/durable-state-model.md

Require:

- one visible, unfenced begin/end pair per document;
- unique intended current structural owner;
- no historical/superseded/example relocation;
- same-title sibling/ancestor ambiguity rejected;
- one visible block plus irrelevant hidden duplicate handled correctly;
- two visible blocks rejected;
- normalized bodies identical;
- bodies remain bounded references and do not duplicate detailed matrices.

Use independent in-memory Markdown mutants. Raw marker counting alone is
insufficient.

ACCEPTANCE CHECK — APPEND-ONLY SECTION 42 EXTENSION

Require:

- exact committed baseline document bytes remain the complete prefix;
- RW0 block occurs after the committed-status end marker;
- RW0 block is one visible, unfenced H3 under final H2 Section 42;
- no H2 Section 43;
- no insertion into historical bytes;
- no duplicate RW0 block;
- Section 41 remains the semantic owner of pre-execution selection;
- the RW0 block is target-only and selects no table, row, receipt, migration,
  schema, application generation, or public API representation;
- existing exact-column-order ownership remains unchanged.

ACCEPTANCE CHECK — C2B3C STATUS COMPATIBILITY

Require:

- exact committed-status block begins at the frozen offset;
- exact block content remains protected;
- later governed H3-or-deeper Section 42 extensions are accepted without being
  re-owned by the C2B3C test;
- committed-status begin/end markers are globally unique;
- duplicate markers/blocks fail with exact diagnostic
  `C2B3C_STATUS_INVALID`;
- relocation, internal mutation, commit swap, report authority,
  broadened supersession, capability overclaim, and H2 Section 43 remain
  rejected;
- the broken EOF checker rejects a valid extension while the repaired
  region-scoped helper accepts it;
- C2B3C working-tree mode remains `0600` and Git index mode remains `100644`.

ACCEPTANCE CHECK — TEST CAUSALITY AND NON-WEAKENING

Verify:

- the new direct file has exactly 28 top-level collected nodes;
- all pre-existing HEAD nodes remain byte-for-byte identical in collection
  order;
- no existing node was renamed, removed, skipped, xfailed, collapsed, or
  re-parameterized;
- no warning filter, pytestmark, collection hook, or `__test__` control was
  introduced;
- direct tests use region/owner-specific checks rather than whole-document
  token presence;
- sibling correct text cannot satisfy a damaged region;
- broken controls reproduce predecessor defects but are never authoritative;
- no production private module is imported/executed merely to copy values when
  bounded static parsing is the intended check;
- exact K8 parsing is causal and detects source-field drift.

INDEPENDENT MUTANT MATRIX

The parent must independently construct bounded in-memory mutants covering at
least:

1. claim current worker/contact/runtime capability exists;
2. externally author the subordinate attempt/effect target;
3. make the user a synchronous per-attempt approver;
4. make a safe ref/digest retrieval permission;
5. promote the provisional ES fixture to enduring authority;
6. absorb base/path drift rather than replan;
7. freeze SSH forced command or length-prefix framing as target architecture;
8. allow Mac/Coordinator-host/alternate-host fallback or a third adapter;
9. permit a second delivery, relaunch, or second productive acceptance;
10. collapse validation/review/model proposal into Coordinator decision;
11. make model/report/IM/transport evidence authoritative;
12. let direct-local own ES lifecycle/reliable-submit/result truth;
13. add Git effect or publication;
14. remove one terminal outcome;
15. reorder or add a terminal outcome in only one owned region;
16. allow successor launch;
17. collapse cancellation facts;
18. claim migration/schema/runtime implementation exists;
19. fence or historically relocate one cross-reference;
20. same-title sibling/ancestor-relocate one cross-reference;
21. move the RW0 H3 outside final H2 Section 42;
22. duplicate the RW0 target block;
23. duplicate the committed-status block;
24. append H2 Section 43.

Require each intended negative to fail for the causal reason. Require valid
hidden-duplicate and later-H3 positive controls to remain accepted.

IMPLEMENTATION EVIDENCE TO INSPECT, NOT TRUST

Safely inspect relevant retained evidence beneath:

- /private/tmp/ge-coordinator-rw0a-evidence.JWHS6a
- /private/tmp/ge-coordinator-rw0a-repair.UDYgzx
- /private/tmp/ge-coordinator-rw0a-section42-repair.6TasDc
- /private/tmp/ge-coordinator-rw0a-marker-repair.vOkQZp

At minimum inspect:

- initial direct red and green evidence;
- retained 27/1 terminal-outcome predecessor failure;
- repaired direct 28/28 evidence;
- retained 4,283/1 full-suite stale-EOF failure;
- retained targeted diagnostic failure;
- final targeted, C2B3C, direct, focused, collection, and 4,284/4,284 records;
- opening/final node lists;
- opening and final manifests;
- evidence catalog;
- final guards and residue checks.

Verify the reported predecessor failure JUnit:

/private/tmp/ge-coordinator-rw0a-section42-repair.6TasDc/target.junit.xml

Expected SHA-256:

26edf3a665653bf0207a192edee9f349ad6d80c4477d63f5ea0b9e091bedc37b

No correctness credit comes from implementation evidence. Missing or
incomplete evidence must be disclosed. Fresh audit inspection, mutants, and
validation determine the verdict.

VALIDATION ISOLATION

Use one audit-created external, operator-owned, non-symlink, mode-0700 root.

For every pytest child:

- save actual caller umask;
- create evidence under secure posture;
- restore caller umask before launch;
- record child-observed umask and require numerical equality;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`
  - `LC_ALL=C`
  - `LANG=C`
  - `PYTHONDONTWRITEBYTECODE=1`
  - distinct external `PYTHONPYCACHEPREFIX`
  - distinct external `TMPDIR`
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`
  - `PYTEST_ADDOPTS=''`
  - `PYTHONHASHSEED=0`
  - `python3 -B -m pytest`
  - `-p no:cacheprovider`
  - `-W error`
  - distinct external `--basetemp`
  - external `--junitxml`
  - serial execution.

Retain exact argv, environment, caller/child umask, return code, elapsed time,
stdout/stderr/JUnit sizes and SHA-256, parsed counts, warnings, parse errors,
unmapped cases, and before/after target equality.

DIRECT RW0-A ORACLE — EXACTLY ONCE

Run:

tests/test_rw0_remote_contact_phase_entry_contract.py

Require exactly:

- 28 collected;
- 28 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- target unchanged before/after.

COMPLETE C2B3C REGRESSION — EXACTLY ONCE

Run:

tests/test_c2b3c_author_effect_contract.py

Require exactly:

- 46 collected;
- 46 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- empty stderr;
- no parse error or unmapped case;
- target unchanged before/after.

COMPLETE RW0-A FOCUSED REGRESSION — EXACTLY ONCE

Run exactly:

tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_software_development_progression_boundary.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_worker_execution_semantic_boundaries.py

Require exactly:

- 1,565 collected;
- 1,565 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- empty stderr;
- no parse error or unmapped case;
- target unchanged before/after.

NODE IDENTITY

After focused validation:

1. Collect the candidate exactly once.
2. Require exactly 4,284 node IDs.
3. Create one clean external `git archive HEAD`.
4. Collect HEAD exactly once.
5. Require exactly 4,256 HEAD node IDs.
6. Require:
   - intersection:
     4,256;
   - candidate-only:
     exactly 28;
   - HEAD-only:
     0;
   - all 28 candidate-only nodes belong to
     `tests/test_rw0_remote_contact_phase_entry_contract.py`;
   - no existing node changed identity or order.
7. Require exact candidate node-list SHA-256:
   `7fb16833d1fcf8916f62ad17b0238b87b8cda8bb03432039771290bc713d12e8`.
8. Require exact existing-file counts:
   - architecture:
     30;
   - C2B3C:
     46;
   - remote-worker:
     774;
   - direct RW0-A:
     28.

FULL SUITE — EXACTLY ONCE

Only after inspection, focused validation, node comparison, and artifact cleanup
are green, run the complete repository suite exactly once:

python3 -B -m pytest -p no:cacheprovider -W error \
  --basetemp=<external> \
  --junitxml=<external> \
  .

Require exactly:

- 4,284 collected;
- 4,284 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no JUnit parse error or unmapped case;
- repository bytes, modes, topology, and target manifest unchanged.

Do not run a second full-suite attempt. If immutable JUnit parsing initially
misclassifies paths, reparse the same JUnit without rerunning pytest.

FINAL GUARDS

Require:

- exact ten-path target set;
- exactly eight tracked modifications and two untracked paths;
- zero staged or unmerged paths;
- expected local mode posture, including C2B3C `0600`;
- Git index mode `100644` for every tracked candidate path;
- no Git-recorded mode change;
- no path outside target changed;
- append-only prefix exact;
- final H2 Section 42 and no Section 43;
- four bounded cross-reference bodies normalized-identical;
- one sole detailed RW0 owner;
- no current implementation overclaim;
- no enduring ES fixture, custodian, SSH/framing, Codex, schema, latch,
  capsule-backend, validator/reviewer/model-adapter, or ES reliable-submit
  choice accidentally frozen;
- no source, SQL, migration, catalog, schema, application-generation, package,
  public protocol, StateStore, WriterSession, runtime, fixture, script, config,
  or supporting-repository diff;
- `git diff --check` clean;
- no repository cache, bytecode, pytest cache, database, journal, WAL/SHM,
  build output, archive, generated manifest, or OS metadata;
- no Git operation or lock;
- no remote contact or runtime effect.

FINDING AND VERDICT RULES

Classify findings by:

- current-versus-target contract drift;
- authority/custody ownership drift;
- identity or fact-collapse defect;
- ambiguity/recovery/cancellation defect;
- Markdown ownership/liveness defect;
- test/mutation inadequacy;
- source/public-boundary widening;
- security/privacy issue;
- provenance/validation gap;
- artifact hygiene issue;
- pre-existing observation outside the patch.

Use severity:

critical
high
medium
low
observation

For every finding report:

- stable ID;
- type and severity;
- exact path:line evidence;
- current contract or strategic target;
- impact;
- required correction;
- uncertainty;
- patch defect or pre-existing issue.

ACCEPT only when:

- opening and closing provenance equal the exact final target;
- all four audit tasks complete;
- the entire ten-path candidate satisfies the corrected RW0-A target;
- current implementation is not overclaimed;
- external-parent/Coordinator-derived-subordinate authority is exact;
- WorkSpec privacy/custody properties are exact without premature
  implementation choice;
- provisional proof fixtures remain non-authoritative;
- transport, framing, Codex, schema, latch, capsule, validator/reviewer/model,
  and ES decisions remain properly deferred;
- identities and facts remain non-collapsed;
- terminal outcomes and cancellation ordering are causally enforced;
- ES/IM ownership boundaries are intact;
- all Markdown owner/cross-reference oracles are structurally causal;
- C2B3C committed-status compatibility and exact diagnostic are correct;
- no existing test is weakened;
- direct, C2B3C, focused, node, and full-suite validation are exact-green;
- no Critical, High, Medium, or Low patch defect remains;
- the exact candidate is suitable for an audited-byte feature-branch commit,
  push, PR, and later squash-merge gate.

Use BLOCK for a repairable defect, non-green validation, materially incomplete
evidence, or unresolved uncertainty preventing acceptance.

Use REJECT only for a fundamental architecture or authority failure that cannot
be repaired within RW0-A.

Use AUDIT_PROVENANCE_MISMATCH for target-byte, branch, path-set, topology,
recipe, retained-manifest, mode, or classification mismatch.

CLOSEOUT PROVENANCE

After all inspection and validation, and after removing only safe
audit-created external artifacts:

1. Run the exact recipe twice again.
2. Require complete identity with the immutable opening target.
3. Recheck append-only prefix, modes, Git index modes, path set, topology,
   residue, operations, and locks.
4. Do not accept if audit activity changed repository bytes or metadata, even if
   later restored.

FINAL REPORT

Begin with exactly one primary verdict token:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Then report:

1. Exact opening and closing identity/provenance.
2. Exact opening-to-final one-entry diagnostic-repair comparison.
3. Audit tasks, completion, retries, and disagreements.
4. Complete severity-ranked finding ledger.
5. Current implementation versus RW0 target assessment.
6. Authority/custody/privacy assessment.
7. Scenario, fixture, transport, process, and deferred-decision assessment.
8. Identity/fact-owner and timeline assessment.
9. Failure, ambiguity, cancellation, recovery, and terminal-outcome assessment.
10. ES/IM ownership and conformance assessment.
11. Sole-owner, four-cross-reference, and Section 42 Markdown assessment.
12. Direct-test and existing-test causality/non-weakening assessment.
13. C2B3C extension compatibility and diagnostic assessment.
14. Independent mutant results.
15. Direct, C2B3C, focused, node, and full-suite validation.
16. Protected-byte, mode, public-boundary, and artifact checks.
17. Limitations and separate provenance, validation, and implementation
    confidence estimates.

If ACCEPT, include:

COORDINATOR_RW0_T1_PHASE_ENTRY_CONTRACT_FREEZE_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

If not ACCEPT, do not provide a commit or PR prompt and do not repair.

Required closing statements:

REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
