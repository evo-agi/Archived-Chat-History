# 30. Independent audit of ES PR #59 (macOS CI job) at 6c40bd8

```
INDEPENDENT AUDIT REPORT
Repository: evo-agi/Execution-Substrate, PR #59 "CI: run the test gate on macOS for the scripts package"
Target:     head 6c40bd8fa4f054472761a1f923455387ef3b961f, tree 20375972635f50e9cde48e73d55f4a186547e235,
            base trunk_dev bf5a760a2276f5d8b7600d7b64523e4ee32410d0, branch claude/project-thread-wbmulu
Recipe:     governed_execution_audit_patch_manifest_v2.py, source sha256 c08597e2…a3ca (checked before every run)
Manifest:   a11fa1cc5681a5d6d11cf0344ed2b4545ab9aa70c1d71f1c35259b67d2e63b98, 7 paths (reproduced, open = close = writer's)
Writer:     25-macos-ci-pr59.md (writer thread "Contain TLS status collector child processes")
Posture:    fresh auditor thread, read-only on the target. No subagents (quota). Nothing pushed, no PR comment,
            no workflow re-run, box not touched. Cloud container: Linux 6.18.44, Go 1.26.5, user ci, and root.
Verdict:    ACCEPT 6c40bd8. No critical, high or medium finding. Three low findings (A30-1 to A30-3), none a
            production risk. Under David's standing rule that low findings are fixed in the PR, A30-1 and A30-2
            should be folded in before the merge; the writer's unpushed patch 02-ports-c506156 already covers A30-1.
            A30-3 is a ruleset setting for David.
Red-team:   not needed in my view: CI, test and doc changes only, no product code. The coordinator decides.
```

All times are UTC on 2026-11-25.

## 1. Verdict in short

**ACCEPT.** The new workflow and the gate's `PACKAGES` argument are correct and well held. Every one of the 38 listed failures is a real difference of the macOS host or of a test's own fake, and every failing point lies in box-only code or in test code. Every one of the 80 self-skips has the reason the list gives. The gate cannot be fooled by the list in the ways the coordinator asked about: an unlisted failure fails "Test", a listed test that starts passing fails "Listed tests still fail", and an unlisted skip, or a listed skip that stops skipping, fails "Test".

What the list does not catch, and what I found:

- **A30-1 (low):** one test that the list does not name, `TestRemoteAlphaOperatorPrepareSummaryPathRefusesPlantedArtifactFolder`, passes on macOS without reaching the check it is named for. I reproduced it on Linux with `/tmp` as a link (section 5). The list's own rule forbids exactly this kind of claim.
- **A30-2 (low):** the reason given for the three `stat -c` entries is incomplete. The box helper under test also runs GNU `stat -c` (`scripts/remote_alpha_reset_disposable_vault.sh:410`), so porting the test's own `stat` call cannot clear at least `TestRemoteAlphaResetDisposableVaultNeverFollowsALinkAboveTheRaftDirectory`.
- **A30-3 (low, operating model):** until "test on macOS" is a required check, a red macOS run does not stop a merge, and nothing else reads `environment-only-tests-macos.txt`.
- A failure that changes its reason inside a listed test stays hidden. This is the gate's existing design (O30-1). For these 38 entries it costs no production coverage, because the code they reach runs only on the box and the same tests run on Linux in `go.yml` (except the 7 `ds` tests, which are listed on Linux too).

## 2. Provenance

- The recipe's sha256 was checked with `sha256sum -c` before each run: `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, OK.
- Fresh clone under `umask 022` in `/opt/audit/es`, following provenance §5.3:
  - `origin/claude/project-thread-wbmulu` = `6c40bd8`, the reported tip;
  - `bf5a760` is an ancestor of the tip;
  - checkout of the tip was clean, then `git reset --mixed bf5a760`, upstream `origin/trunk_dev`.
- Two runs at open: byte-identical, `manifest_sha256 = a11fa1cc…3b98`, `textual_diff_sha256 = 270d7924…b3db290`, 7 files. `cmp` with the writer's `25-evidence/manifest-6c40bd8-vs-bf5a760.json`: identical. No mode difference.
- Two runs at close (after all probes, `git status` showing only the 7 patch paths): identical to each other and to the open run.
- At 05:24Z, PR head and branch were still `6c40bd8`, and trunk_dev was still `bf5a760`.
- Both CI runs checked out merge commit `f175e4ed4e49c3a8a429a659f41bfb146a00ef3f` (parents `bf5a760`, `6c40bd8`). Its tree is `20375972…`, the same as the head's, so CI tested the audited bytes.

The 7 paths: `.github/workflows/go-macos.yml` (new), `.github/ci/environment-only-tests-macos.txt` (new), `.github/ci/go_test_gate.py`, `.github/ci/go_test_gate_selftest.py`, `.docs/system_overview/go_toolchain_baseline.md`, `docs_contract_test.go`, `README.md`. No binaries, caches or generated files.

## 3. Can the list hide a real regression?

### 3.1 What the gate catches (read in `go_test_gate.py`, proven by the self-test, seen in the macOS log)

| A change that... | is caught by | evidence |
|---|---|---|
| makes an unlisted test fail on macOS | "Test": `go test` exits non-zero for the package (`gated_runs`) | gate design; self-test |
| makes a listed test pass, skip or not run | "Listed tests still fail": each entry must fail in its own run and in a run of the whole package with nothing skipped | macOS log: "all 38 listed tests still fail on this host, each in a run of its own and in the run of its package" |
| adds a skip that is not listed, or ends a listed skip | "Test": skipped set must equal the `skips-itself` lines | macOS log: "80 tests skipped themselves, all of them listed"; my `cmp` of the 80 names with the 80 lines: equal |
| lets an entry for a subtest cover more than itself | the observed run with the `match.go` overlay | macOS log: "go test skipped exactly the listed tests of this package (38), each once" |
| adds a list line for a package outside `./scripts/...` | `check_list`, exit 2 before any test | my probes 3 and 4 on the real tree (probes.txt) |
| weakens the workflow (e.g. `continue-on-error`) | `MACOS_WORKFLOW_SHA256` hold in the self-test and in `docs_contract_test.go`, plus the line checks | my workflow mutant, probe 6 |

### 3.2 What it cannot catch

1. **A listed test that keeps failing, but for a new reason.** The gate does not pin a failure message (O30-1). On macOS, the code behind the 38 entries runs only up to the first failing point. All of that code is box-only (section 4). 31 of the 38 tests pass on Linux in `go.yml` (run 45545850585), so the Linux job covers what they test. The 7 `ds` tests are listed on Linux too, as before this PR. Three of them (`…FailureWitnessBootstrapOwnedTerminal`, `…RootLoadedStageCustody`, `…StageFIFOSubstitution`) run in David's Mac A4, which passed at `bf5a760` (`29-partial-box-run.md`).
2. **New subtests of a whole-test entry.** 28 entries name whole tests. The two `ds` tests are whole on purpose: some of their subtests pass, but they would pass without reaching their check, as `environment-only-tests.txt` explains (`…FailureWitnessBootstrapOwnedTerminal` 4 pass / 18 fail, `…RootLoadedStageCustody` 11 pass / 4 fail on the runner). For the other whole entries the log shows that every subtest fails, or that the test has none.
3. **A test that passes for the wrong reason.** The list only handles failures and skips. One unlisted test passes on macOS without reaching its check (A30-1). A firewall test is overdetermined on macOS (O30-5).
4. **A red run that nobody has to look at.** The job is not a required check (A30-3).

## 4. The 38 entries, reason by reason

For each entry, the first failing line in its own run is in `30-pr59-audit-evidence/entries-first-failure-line.tsv`, taken from the macOS job log (run 45545850686, job 138975158821, macOS 26.7.2 arm64, image macos-26-arm64 20261117.0516.1). The set of 38 names in the log equals the list's 38 entries (`cmp`).

**No `ds` account (7). Holds.** The TLS status bootstrap, which runs on the box as root through sudo, refuses unless `SUDO_USER` is `ds` and `pwd.getpwnam("ds")` exists (`scripts/remote_alpha_operator.sh:2130-2140`). The log shows `reason=caller_identity_unproved` for the first test and `KeyError: "getpwnam(): name not found: 'ds'"` for the three P0t tests. Linux lists the same seven for the same reason.
- `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal` (whole)
- `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody` (whole)
- `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`
- `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`
- `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`
- `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`
- `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`

Inference: for `…RootLoadedStageCustody`, `…StageFIFOSubstitution` and `…StageFIFORefusal`, the log shows only "correct failed" or "staged_leaf_check_reached failed", not the cause. They use the same bootstrap and fail the same way on Linux, and the first two pass on David's Mac.

**`/var` and `/tmp` are links on macOS (10). Holds.** `remote_alpha_prepare_output_dir` (`scripts/internal/remote_alpha_output_dir.sh`, carried as a copy by each root helper) refuses a link anywhere on the path. That code runs only on the box, or inside a fake host in the tests. Evidence for each group:
- Default under `/var/tmp`, log shows "remote alpha output folder: /var is not a directory or is a symbolic link":
  - `TestRemoteAlphaESBinaryDeploymentCheckOnlyIsDefaultAndNonMutating`
  - `TestRemoteAlphaESConfigTLSPrepRecordsDSSecurityWarningsWithoutFailing`
  - `TestRemoteAlphaESConfigTLSPrepRejectsPreexistingBroadPrepAccount`
- `TestRemoteAlphaVaultServiceUserMigrationApplyRequiresReadyPreflight`: the log shows only that the summary was not written. Code: in apply mode the helper checks the default backup root `/var/tmp/execution-substrate-remote-alpha` before it writes the summary (`scripts/internal/remote_alpha_migrate_vault_service_user.sh:5, 88, 345`).
- Expects a refusal naming `/var/tmp` or `/var/log` and gets the `/var` link refusal first:
  - `TestRemoteAlphaOutputDirRefusesASharedStickyFolderAsTheArtifactFolder`
  - `TestRemoteAlphaVaultServiceUserMigrationPlanRefusesPathsOutsideVault/log_file_in_a_shared_system_directory` (its 4 other subtests pass)
- Fake host under `/tmp`, from `os.MkdirTemp("/tmp", "es-ra-bootstrap-")` at `scripts/remote_alpha_operator_test.go:3766`. Log: "remote alpha output folder: /tmp is not a directory or is a symbolic link", `error_classification=summary_parent_unsafe`:
  - `TestRemoteAlphaOperatorPrepareSummaryPathHandsOverAnUnreadableFolder`
  - `TestRemoteAlphaOperatorPrepareSummaryPathRefusesASummaryLink`
  - `TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareRunsBeforeHelperExecution`
  - `TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSummaryPathUsesBoundedRemoteCommand`

  The route script runs on the Mac, but the refusal comes from the remote command (`remote_alpha_operator.sh:957-1030`), which runs on the box.

**No `O_PATH` (1). Holds.** `flags = getattr(os, "O_PATH", os.O_RDONLY) | …` (`remote_alpha_output_dir.sh:41`). The log shows "… (Permission denied)". The function is box-only, and the fallback exists only so that tests can run.
- `TestRemoteAlphaOutputDirChecksFoldersItCannotRead`

**Fake sshd needs Bash 4 (8). Holds; consistent with the evidence, not reproduced.** `hostFirewallFakeSSHD` (`scripts/remote_alpha_host_firewall_test.go:94-150`) is `#!/bin/bash` with `declare -A` and `${key,,}`. The log shows the plan reaching "sshd -T says password yes, keyboard-interactive yes, X11 yes" for every address. The product firewall script also has one `declare -A` (`scripts/internal/remote_alpha_host_firewall.sh:1121`), but only in `probe`, which these tests do not reach. I found no other Bash 4 feature in it. The script itself is box-only. All subtests fail (3, 3 and 4 where the test has subtests).
- `TestRemoteAlphaHostFirewallApplyConfirmRollbackOrderWithFakes`
- `TestRemoteAlphaHostFirewallApplyFailuresLeaveNoUnconfirmedMarker`
- `TestRemoteAlphaHostFirewallApplyRefusesOtherBridgesAndContainerIPv6`
- `TestRemoteAlphaHostFirewallApplyRestoresAfterAFailedDropInInstall`
- `TestRemoteAlphaHostFirewallInstallsFilesDurably`
- `TestRemoteAlphaHostFirewallStatusChecksTheTablesAreLoaded`
- `TestRemoteAlphaHostFirewallStatusRefusesEmptyInstalledRulesetAfterCrash`
- `TestRemoteAlphaHostFirewallUnconfirmedApplyRecords`

**GNU `stat -c` (3). Host difference holds; the reason is incomplete (A30-2).** The tests call `exec.Command("stat", "-c", "%U", …)` (`scripts/remote_alpha_root_service_paths_test.go:430, 1043`), and the log fails right there. Behind that, `require_vault_owned_raft_dir` runs `sudo stat -c '%U'` itself (`scripts/remote_alpha_reset_disposable_vault.sh:410`), on the box.
- `TestRemoteAlphaResetDisposableVaultNeverFollowsALinkAboveTheRaftDirectory`
- `TestRemoteAlphaResetDisposableVaultRefusesUnsafeRaftStates/raft_directory_of_the_Vault_account`
- `TestRemoteAlphaResetDisposableVaultRefusesUnsafeRaftStates/raft_path_is_a_link`

Its 3 other subtests pass.

**BSD `chmod` and `--` (6). Holds.** The change script `chmod 0755 -- "${stage}"` runs in the test's fake `scp` wrapper (`scripts/remote_alpha_operator_stage_folders_test.go:418-428`), not in the route. The 6 `linked/*` siblings pass on the runner. They reach the same remote refusal, so the Mac-side route stays covered.
- `TestRemoteAlphaOperatorRoutesRefuseAStageFolderThatIsNoLongerPrivate/open/operator-healthcheck-tls-renew`
- `…/open/operator-healthcheck-tls-status`
- `…/open/vault-reset-disposable-dry-run`
- `…/open/vault-reset-disposable-execute`
- `…/open/vault-unseal-existing`
- `…/open/vault-workload-auth-bootstrap`

**LibreSSL refusal form (2). Holds as a host difference; the exact cause is an inference.** The log shows `status_grammar.Incomplete: unexpected_openssl_grammar` from `cert_metadata` (`scripts/internal/remote_alpha_es_tls_status.py:2401`). `_known_malformed_pem` accepts the LibreSSL form only with the full pinned path `LIBRESSL_PEM_ERROR_PATH` (l.1893, including the `BuildRoots/4~CVR0…` and `TemporaryDirectory.kapob0` components). The collector runs in production only on the box, where OpenSSL 3.0.13 is used.

Inference: the runner's `/usr/bin/openssl` (macOS 26.7.2) prints another build path. The log does not show its stderr. David's Mac (26.6.2) passes both tests (A4 at `bf5a760`). See O30-3.
- `TestRemoteAlphaESServiceTLSStatusOpenSSLGrammar`
- `TestRemoteAlphaESServiceTLSStatusCollectionTypedFailures/malformed_cert` (its 10 other subtests pass)

**Mach-O, not ELF (1). Holds.** `go_build_info` refuses anything but a 64-bit little-endian ELF file (`scripts/internal/remote_alpha_upgrade_es.py:863-868`). The test builds `esconfigcheck` for the host (`buildESConfigCheck`, `scripts/remote_alpha_upgrade_es_config_check_test.go:202-212`). The helper's own build mode cross-compiles with `GOOS=linux GOARCH=amd64` (l.1378), so it works on a Mac.
- `TestRemoteAlphaUpgradeESReadsGoBuildInfoLikeGoVersion`

**The writer's claim that "none of the 38 entries is a fault in code that runs on the operator's Mac" holds** for every group above.

## 5. Finding A30-1: a planted-folder test passes on macOS without reaching its check

```
AUDIT FINDING
ID / Type / Severity: A30-1 / test/doc gap (false coverage) / low
Current contract: environment-only-tests.txt (the rules that the macOS list adopts): a subtest that "passes there
  without reaching the custody check it is named for" must not stay in the gate, because "Keeping those subtests
  in the gate would claim a check that does not happen." go_toolchain_baseline.md §10 (this PR): "A green macOS
  run is validation evidence that the tests of those packages that its list does not name pass on that runner image."
Path and line: scripts/remote_alpha_output_dir_test.go:555-598 (TestRemoteAlphaOperatorPrepareSummaryPathRefusesPlantedArtifactFolder);
  harness root scripts/remote_alpha_operator_test.go:3766 (os.MkdirTemp("/tmp", "es-ra-bootstrap-")).
Evidence: the test plants a link at <fake host>/var/tmp/execution-substrate-remote-alpha and asserts only the
  generic strings "remote alpha output folder: ", "is not a directory or is a symbolic link",
  "error_classification=summary_parent_unsafe". On macOS the output-folder check refuses the /tmp link first, with
  exactly those strings (macOS log for the listed sibling …HandsOverAnUnreadableFolder). Reproduced on Linux in a
  chroot whose /tmp is the link /tmp -> private/tmp (30-pr59-audit-evidence/vacuous-pass-run.txt):
    A. audited bytes, plain Linux: both tests PASS;
    B. audited bytes, /tmp as a link: …RefusesPlantedArtifactFolder PASS, …HandsOverAnUnreadableFolder FAIL with
       the runner's message (the simulation matches the runner);
    C. copy with the planted link removed (vacuous-pass-mutant.diff), plain Linux: FAIL ("accepted a planted
       artifact folder");
    D. the same copy, /tmp as a link: PASS.
  So on the macOS runner the test passes whether or not anything is planted.
Impact: the macOS job counts as passing a check that does not run there. No production impact: the check is box-side
  and the Linux job tests it for real.
Required correction: give the harness a fake host root whose path holds no link (for example the physical path of
  /tmp). That also lets the 4 listed /tmp entries pass. Or make the test pin the refused path (the planted link) and
  list it. The writer's unpushed 02-ports-c506156.patch (macos-ci/, 05:13Z) does the first; I have not audited it.
Uncertainty: none for this test. I searched the scripts tests for other unlisted tests that assert only generic
  link-refusal text and found no other one (the others pin the refused path).
Patch defect or pre-existing: introduced by this PR's claim (the test is pre-existing; only the macOS gate counts it).
```

## 6. Other findings

```
AUDIT FINDING
ID / Type / Severity: A30-2 / doc gap (wrong reason in the list) / low
Path and line: .github/ci/environment-only-tests-macos.txt, the "stat -c %U" group; scripts/remote_alpha_reset_disposable_vault.sh:410
Evidence: the list says "The tests read a folder's owner with "stat -c %U", which is the stat of GNU coreutils."
  True, but the helper that they test, require_vault_owned_raft_dir, also runs `sudo stat -c '%U'`. So a port of the
  tests' own stat call cannot make at least …NeverFollowsALinkAboveTheRaftDirectory pass on macOS. Report 25's
  "porting them would remove 21 entries" is too high for the same reason. The writer's own later patch says 19, and
  keeps two raft entries "with a corrected reason".
Impact: the reason misleads whoever tries to shorten the list. It is still a host difference, because the helper is box-only.
Required correction: say in the list that the helper itself uses GNU stat (box-only).
Patch defect or pre-existing: patch (new list text).
```

```
AUDIT FINDING
ID / Type / Severity: A30-3 / operating model (detection without enforcement) / low
Evidence: the trunk_dev ruleset requires only "build, vet and test" (project memory; PR body "After merge"). go.yml
  does not read environment-only-tests-macos.txt, and nothing else does. With "test on macOS" not required, a PR
  that breaks a scripts test only on macOS, or that adds a malformed line to the macOS list, can merge with the macOS
  job red.
Impact: the job reports, but does not block. This is the "prose-only" gap that the project instructions warn about.
Required correction: David makes "test on macOS" a required check in the ruleset. Until then, the coordinator's
  merge gate should treat a green "test on macOS" on the exact head as a merge condition for every ES PR.
Patch defect or pre-existing: neither. It is a setting outside the repo, and the PR states it.
```

**Observations** (no correction required in this PR):

- **O30-1, failure reasons are not pinned (gate design, pre-existing).** A listed test that fails for a new reason, a whole-test entry that gains a subtest, and a listed skip whose reason changes all stay hidden. This is the same for the Linux list. For these 38 entries, section 3.2 shows that no production coverage is lost.
- **O30-2, the time limit is close.** `go test` gets no `-timeout`, so the default of 10 minutes per test binary applies. On macos-26 the scripts package took 434.3 s ("Test"), 375.6 s (observed run) and 323.0 s (whole-package run in "still fail"). Earlier runs at `537eace` and `0ad447a` had "Test" steps of 8m33s and 7m05s. A slower runner or a growing package fails the job with "panic: test timed out", unrelated to the change. It fails closed. `es/app` on Linux (421-426 s) has the same margin today. A gate-wide explicit `-timeout`, with self-test cases, would be its own small change.
- **O30-3, the LibreSSL pin is fragile (pre-existing, product).** The runner's macOS 26.7.2 does not produce the pinned form. David's 26.6.2 does. Inference: a macOS update on David's Mac will likely make `…OpenSSLGrammar` and `…CollectionTypedFailures/malformed_cert` fail in a future Mac A4 run. Also, `.docs/system_overview/remote_supported_host_alpha.md:4004-4011` describes a "fixed Apple LibreSSL build-path suffix `/Sources/libressl/libressl-3.3/crypto/pem/pem_lib.c:694:Expecting:`", while the code pins the whole path including the build hash. The doc and the code do not say the same thing. This is a follow-up for the collector (a product change), outside this PR. The writer raised it too.
- **O30-4, two wording nits in the new files.**
  - The `go-macos.yml` header ("the packages of the Go module whose tests are meant to run on every host") suggests that only `./scripts/...` qualifies. The Test Harness Use rule in `capability_probing.md` makes every test package macOS-capable, and the baseline doc gives the real reason: scripts tests also run on the operator's Mac.
  - The list's "so the lines below are not run as root anywhere" is true of these lines. The same tests do run as root on Linux through `environment-only-tests.txt`.
- **O30-5, one overdetermined pass.** `TestRemoteAlphaHostFirewallApplyRefusesSSHPeerOutsideSources` (unlisted) uses the Bash 4 fake sshd. On macOS its plan fails on the sshd check as well as on the peer check. It still pins "current SSH peers stay allowed: FAIL" and "10.9.9.9", so the check it is named for is visible, but the refusal itself has two causes there. The port in c506156 would remove the second cause.
- **O30-6, merge order with PR #60.** PR #60 (head `f505f72`, on the same base) changes `scripts` tests heavily, for example `remote_alpha_upgrade_es_host_test.go` +1189 lines, and those tests will run on macOS once this job exists. `git merge-tree` of `6c40bd8` and `f505f72` is clean. Whichever of the two merges second needs a green macOS run on its updated head, and #60's new tests may need list lines or ports.
- **O30-7, an unpushed follow-up exists.** `reports/Execution-Substrate/macos-ci/02-ports-c506156.patch` (05:13Z) ports four fakes and drops 19 lines. It is not on the PR branch and not audited here. Folding it into #59 would fix A30-1 and A30-2 and remove most of O30-5. It is new bytes, so it needs a narrow delta audit.

## 7. The 80 self-skips

`30-pr59-audit-evidence/self-skips-with-reasons.txt` has every name with the message it wrote in the macOS run. The 80 names equal the 80 `skips-itself` lines (`cmp`). By reason:

- **PID namespaces, "this Python has no os.unshare, os.setns or os.CLONE_NEWPID":** `TestRemoteAlphaESServiceTLSStatusChildNamespaceRealCollectorDeath`, `…RealDeafAnchor`, `…RealDescendants`, `…RealKernel`, `…RealSiblings`.
- **/proc:**
  - "cannot list /proc/self/fd": `TestRemoteAlphaESServiceTLSStatusChildNamespaceAnchorProcess`;
  - "cannot open /proc/self/stat": `TestRemoteAlphaESServiceTLSStatusProcessIdentityLiveProcesses`, `…ProcessIdentityThreadExecStaysPresent`, `…UnrelatedProcessNameDoesNotHoldCleanup`;
  - "reads /proc/net/tcp; the box is Linux": `TestRemoteAlphaHostFirewallHostVaultSource/ipv4`, `…/ipv6`.
- **`os.waitid`, "this Python has no os.waitid":** `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantRealCollectorDeath`, `…RealCrowd`, `…RealKernel`, `…RealProbeRefusesAChild`, `…RealProcessLimit`.
- **Root:**
  - "needs root to create network namespaces": `TestRemoteAlphaHostFirewallRealKernelApplyConfirmRollback`, `…RealKernelBridgeIsolation`, `…RealKernelTraffic`;
  - "needs root: sshd -t checks its privilege separation setup": `TestRemoteAlphaHostFirewallSSHDDropInWithRealSSHD`.

  These also need Linux network namespaces and nftables. All of them run as root in `go.yml` (run 45545850585, "tests as root passed: 9 of execution-substrate/scripts").
- **Real SPIRE or Vault:**
  - "needs SUPPORTED_LOCAL_TEST_SPIRE_TARBALL": `TestRemoteAlphaSPIREAgentPinAgainstRealSPIRE`, `…RecoverAgainstRealSPIRE`;
  - "needs the vault binary on PATH": `TestRemoteAlphaVaultWorkloadAuthBootstrapSignalsWithRealVault`, `…UnsealKeyWithRealVault`.
- **`prctl`, "prctl is not available (AttributeError)" (56 lines):** every `TestRemoteAlphaVaultWorkloadAuthBootstrap…` line of the list's last group. The skip comes from an independent capability probe (`requireBootstrapNotDumpableCapability`, `scripts/remote_alpha_vault_workload_auth_bootstrap_test.go:41-85`), which makes the helper's own ctypes calls, not from the helper's output. The helper refuses to run without `prctl` by design (`scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh:148-152, 493-496`) and is box-only. The refusal itself still runs on macOS in the unlisted subtests of `TestRemoteAlphaVaultWorkloadAuthBootstrapRefusesWhenTheProcessStaysDumpable`.

## 8. Validation assessment

**Re-run by me on the exact bytes** (Linux container, Go 1.26.5 from proxy.golang.org, as user `ci`; `30-pr59-audit-evidence/probes.txt`):

| Check | Result |
|---|---|
| Gate self-test | Ran 144 tests, OK (187 s) |
| List checks with the gate's own `read_entries`, `module_packages`, `check_list` | 38 entries (28 whole, 10 subtests), 80 skips; `./scripts/...` = `execution-substrate/scripts`, `execution-substrate/scripts/internal/esconfigcheck`; OK |
| Out-of-pattern lines, both modes, both line kinds | exit 2, no test run |
| Bad patterns (`./scripts/../es`), wrong scope (`./es/...`) | exit 2 |
| `TestGo1265ToolchainBaselineDocsAndBuildContract` | PASS |
| `go vet ./scripts/...` for linux/amd64 and darwin/arm64 | clean |
| Workflow mutant (`continue-on-error: true`) | caught by the hash hold, and with a matching hash by the line check |
| A30-1 reproduction (4 runs) | as in section 5 |

**Read from GitHub, not re-run:**

- macOS run 45545850686 (job 138975158821), green:
  - self-check 144 OK;
  - "test gate passed: 2 packages, 1 of them with skipped entries (38 entries); 80 tests skipped themselves, all of them listed";
  - "all 38 listed tests still fail on this host, each in a run of its own and in the run of its package".
- Linux run 45545850585 (job 138975251529), green:
  - self-check 144 OK;
  - "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves";
  - "all 17 listed tests still fail";
  - "tests as root passed: 9";
  - root package `ok execution-substrate 4.138s` (the docs contract test, with the new pins).
- Logs saved to the evidence folder: sha256 `7d434003…b9` (macOS) and `0e18341e…02` (Linux).

**Not run:**

- Anything on macOS. I have no Mac, and the macOS evidence is GitHub's run on the identical tree.
- The full Linux gate in the container.
- A whole-package `/tmp`-link simulation.
- The Bash 3.2 attribution of the firewall entries. I did not build Bash 3.2; the attribution rests on the log and the source.
- The inference that the job would have caught #30. The four P30 tests (`…NoninteractiveDescendantRunCommand`, `…NoninteractiveRemoteCollectorPureFunctions`, `…HardBounds`, `…LifecycleOrdering`) are unlisted and pass on the runner at this head. Inference: they would fail there without #58, as they failed on David's Mac.

## 9. Coverage, handling and confidence

- **Inspected:**
  - all 7 changed files in full diff, including the whole new workflow and the whole list;
  - the gate's `gate` and `still-failing` paths;
  - the source behind every listed group, as cited above;
  - the operating protocol, provenance guide, `procedures.md`, `state.md`, report 25 and the P30 reports.
- **Not inspected:** `go_test_as_root.py` (unchanged); the rest of the self-test beyond the new groups (the self-test passes).
- **Sensitive material:** none read or copied. A leak scan of the saved logs found no token or key pattern. One match, `GITHUB_PATH`, was a false positive.
- **Side effects, all inside the container:**
  - the audit clone `/opt/audit/es`, unchanged, as the closing manifest shows;
  - a copy for the A30-1 mutant (`/opt/audit/sim`), a copy of `.github` for the workflow mutant (`/opt/audit/mut`), and a chroot skeleton `/simroot` with private mounts only;
  - a local user `ci`.
  - Nothing pushed, nothing posted on GitHub.
- **Confidence:**
  - provenance 0.99: reproduced manifest, and the CI merge tree equals the head tree;
  - validation 0.85: the macOS results are GitHub's, read in full but not re-run;
  - implementation 0.9: the gate and workflow are correct; the residual is O30-1 by design, and A30-1 was found by a bounded search, not an exhaustive one.
- **Effect status:** REPAIR_NOT_PERFORMED · COMMIT_NOT_PERFORMED · PUSH_NOT_PERFORMED · PR_NOT_MODIFIED · NO_COMMENT_POSTED · MERGE_NOT_PERFORMED.

**For the merge gate:**

- The PR head must still be `6c40bd8`, with tree `20375972…`, and trunk_dev must still be `bf5a760`.
- If the writer folds in c506156, or trunk_dev moves (e.g. #60), the new head needs:
  - a new manifest;
  - green runs of both workflows;
  - a delta audit, or the sync check of the merge-queue rule if only git's own merge changed.

**Final verdict: ACCEPT** (6c40bd8; low findings A30-1 to A30-3 as above).
