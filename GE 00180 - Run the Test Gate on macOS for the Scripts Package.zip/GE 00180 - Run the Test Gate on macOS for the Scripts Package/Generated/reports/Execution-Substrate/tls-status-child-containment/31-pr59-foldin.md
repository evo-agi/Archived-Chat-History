# 31. PR #59 after audit 30: the ports, A30-1, A30-2, O30-4 and three corrected entries

```
Repository: evo-agi/Execution-Substrate, PR #59 "CI: run the test gate on macOS for the scripts package"
Head:       7fb88b88ccf23160b1a9e8aafb1ed8359d4dc610, tree 630bdaa94ac814c13aaf33a3f6e26d61d94a8c71
Base:       trunk_dev e2af4b27ad8ab443084c90bb9113ed1204fbdf69 (#61, merged 06:44Z; checked 06:58Z: ancestor of the head)
Audited:    6c40bd8 (report 30, ACCEPT with A30-1 to A30-3)
New since:  c506156, 17f6abe, e700693 (sections 1 to 6), then 37402ed (merge of trunk_dev) and 7fb88b8
            (section 7). All tests, CI and docs; no product code.
Manifest:   v2 of 7fb88b8 against e2af4b2: cec3162016c5847da8075ff72ec4f67b19b504c8fbf99b29d5034323c863962e,
            11 files, textual_diff_sha256 2b91d31baa9b993c99cb0c5c3e8ca906a80c940fc944f5bc8fb144d06adf5065,
            taken twice, byte-identical (31-evidence/manifest-7fb88b8-vs-e2af4b2.json).
            Superseded: e700693 against bf5a760, 23f08e1e…9d99 (31-evidence/manifest-e700693-vs-bf5a760.json).
CI:         7fb88b8: both green: "test on macOS" run 45563767720, "build, vet and test" run 45563767801, both on
            merge commit 958a4b2 (parents e2af4b2, 7fb88b8), whose tree is the head's tree 630bdaa9 (section 7).
            e700693: both green: "test on macOS" run 45556839604, "build, vet and test" run 45556839555, both on
            merge commit 7c878f6 (parents bf5a760, e700693), whose tree is the head's tree b8f661c7.
```
All times are UTC on 2026-11-25.

## 1. In short

The three commits after the audited head do what the coordinator asked at 05:05Z and 05:28Z:

- **c506156** ports four test fakes to macOS (the patch the auditor saw as `02-ports-c506156.patch`, O30-7), and fixes **A30-1**.
- **17f6abe** fixes **A30-2** (the stat entries cite the box helper's own GNU `stat -c`) and the two wording nits of **O30-4**.
- **e700693** lists three ported tests again, with their real reasons. Once `/tmp` was resolved, they no longer stop at the `/tmp` link on macOS. They now reach two other host differences in a box command: BSD `chmod` with `--`, and no `O_PATH`.

The macOS list now has **22 entries** and **80 lines for tests that skip themselves**. At 6c40bd8 it had 38 entries. So 16 entries (tests and subtests) that used to be listed now pass on macOS, with their checks reached.

## 2. What each commit changes

### c506156: four fakes ported (tests only)

- `scripts/remote_alpha_operator_stage_folders_test.go`: the fake copy's change script runs `chmod 0755 "${stage}"`, without `--`. Clears the six `…StageFolderThatIsNoLongerPrivate/open/*` subtests.
- `scripts/remote_alpha_operator_test.go`, `setupFakeRemoteAlphaWorkloadAuthBootstrapHarness`: the fake host root is made under `filepath.EvalSymlinks("/tmp")`. On macOS that is `/private/tmp`, so no folder on the path is a link. A comment says why. This is the auditor's first suggested correction for A30-1.
- `scripts/remote_alpha_root_service_paths_test.go`: a new helper, `rootPathOwnerName`, reads a folder's owner with `stat -c %U`, or with `stat -f %Su` on darwin. Both call sites use it. Clears `…RefusesUnsafeRaftStates/raft_path_is_a_link`.
- `scripts/remote_alpha_host_firewall_test.go`: `hostFirewallFakeSSHD` no longer needs Bash 4. It drops `declare -A` and `${x,,}` and uses `tr` and three indexed slots instead. It still lets the first value win, both in the global part and in the matching `Match` block, as before. Clears the eight firewall entries and the second cause in O30-5.

### 17f6abe: A30-2 and O30-4

- The stat group of the list now says that the box helper under test, `require_vault_owned_raft_dir` in `scripts/remote_alpha_reset_disposable_vault.sh:410`, reads the owner itself with `sudo stat -c '%U'`, the stat of GNU coreutils. That is why its two tests stay listed after the port.
- The `go-macos.yml` header now says "Test on macOS the packages whose tests also run on the operator's Mac." The workflow's SHA-256 changed to `e02ada06…bd2`, and the self-test and the docs contract test hold the new hash.
- The heading of the skip lines now says that this workflow does not run them as root, and that those also named in `environment-only-tests.txt` run as root on Linux in `go.yml`.

### e700693: three entries back, with their real reasons

The macOS run on 17f6abe (run 45554489204, job 139003154275) failed with exactly three failures, all in `execution-substrate/scripts` ("FAIL execution-substrate/scripts 495.797s"):

| Test | First failure on macOS | Why |
|---|---|---|
| `TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSummaryPathUsesBoundedRemoteCommand` | `chmod: --: No such file or directory`, `error_classification=summary_parent_chmod_failed` | The test makes the summary folder 0555, so the prepare command hands it over: fake `sudo chown`, then `chmod 0750 -- "${summary_dir}"` (`scripts/remote_alpha_operator.sh:997`). That is GNU chmod syntax. BSD chmod takes its first operand as the mode and every later one as a file, `--` included. |
| `TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareRunsBeforeHelperExecution` | the same | the same (the test also makes the folder 0555) |
| `TestRemoteAlphaOperatorPrepareSummaryPathHandsOverAnUnreadableFolder` | `… is not a directory or is a symbolic link (Permission denied)`, `summary_parent_unsafe` | The folder is 0000. The output folder check needs `O_PATH` to check a folder it may not read; macOS has none, so it falls back to `O_RDONLY` (`scripts/internal/remote_alpha_output_dir.sh:41`). This is the reason of the listed `TestRemoteAlphaOutputDirChecksFoldersItCannotRead`. |

Both causes are in the summary-path prepare command, which runs on the box over ssh, and which the tests' fake ssh runs on the host. Neither is a fault in code that runs on the operator's Mac. The list puts the first two in a new group that cites line 997, and adds the third to the `O_PATH` group, whose text now covers both tests.

I did not port these. A fake GNU `chmod` would make the test run a box command against a Mac emulation of the box. A product change, such as dropping `--`, would change box code for a host where it never runs. Neither would make the test stronger. The gate's rules still hold them: if a change makes any of the three pass on macOS, "Listed tests still fail" fails until its line is removed.

Before c506156 these three were listed for the `/tmp` link. Their reason changed, not their status. The fourth former `/tmp` entry, `…PrepareSummaryPathRefusesASummaryLink`, now passes on macOS. It pins `error_classification=summary_path_symlink`, which the `/tmp` link cannot produce, and checks that sudo ran neither `chown` nor `chmod`.

## 3. A30-1: covered

`TestRemoteAlphaOperatorPrepareSummaryPathRefusesPlantedArtifactFolder` now gets a fake host root with no link on its path, so on macOS it reaches the planted link it is named for:

- In a Linux chroot whose `/tmp` is the link `/tmp -> private/tmp` (the auditor's simulation, `31-evidence/macroot.sh.txt`), with the new bytes it passes. With the auditor's mutant, where nothing is planted, it fails with "summary-path preparation accepted a planted artifact folder" (`31-evidence/a30-1-tmp-link-run.txt`). So on that host, the test passes only when the plant is there.
- On the macOS runner it passes: the scripts package is `ok` in the green run on e700693, and the test is neither one of the 22 entries nor one of the 80 tests that skip themselves (section 5).

## 4. Counts

| | 6c40bd8 (audited) | e700693 |
|---|---|---|
| Entries | 38 | 22 |
| `ds` account | 7 | 7 |
| `/var` or `/tmp` link | 10 | 6 (`/var` only) |
| no `O_PATH` | 1 | 2 |
| BSD `chmod` and `--` | 6 (test fake) | 2 (box command, line 997) |
| GNU `stat -c` | 3 | 2 (box helper, line 410) |
| Bash 4 fake sshd | 8 | 0 |
| LibreSSL form | 2 | 2 |
| Mach-O | 1 | 1 |
| Lines for tests that skip themselves | 80 | 80 |

Report 25 said the ports would drop 19 lines, and guessed that the eight firewall tests would pass once the fake ran on Bash 3.2. The firewall guess held: none of the eight failed on 17f6abe. The 19 became 16, because three tests met the box command's host differences once they got past `/tmp`.

## 5. Validation

In the cloud container (Linux, Go 1.26.5, as user `ci`, on a copy of the e700693 tree):

- The gate's own `read_entries`, `module_packages` and `check_list` on the macOS list against `./scripts/...`: 22 entries, 80 skips, OK.
- Gate self-test: OK.
- The ported tests, on plain Linux and in the `/tmp`-link chroot: pass (31-evidence/a30-1-tmp-link-run.txt, run A).

On GitHub, for head e700693:

- "test on macOS", run 45556839604, job 139010822380 (image macos-26-arm64 20261117.0516.1), green 06:15Z:
  - self-check: "Ran 144 tests", OK;
  - "test gate passed: 2 packages, 1 of them with skipped entries (22 entries); 80 tests skipped themselves, all of them listed";
  - "the observed run passed; go test skipped exactly the listed tests of this package (22), each once";
  - "all 22 listed tests still fail on this host, each in a run of its own and in the run of its package";
  - in their own runs, the two chmod entries fail with "chmod: --: No such file or directory" and "error_classification=summary_parent_chmod_failed", and the `O_PATH` entry fails at `remote_alpha_output_dir_test.go:624`, as listed.
- "build, vet and test", run 45556839555, job 139010918908, green 06:39Z:
  - self-check 144 OK;
  - root package `ok execution-substrate 4.111s` (the docs contract test, with the new workflow hash);
  - "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed";
  - "all 17 listed tests still fail";
  - "tests as root passed: 9 of execution-substrate/scripts".
- Full logs: `31-evidence/macos-run45556839604-job139010822380.log` (sha256 460ced19…0b6f) and `31-evidence/linux-run45556839555-job139010918908.log` (sha256 bb7dbc82…0d31).

Timing (O30-2): on macOS the scripts package took 495.8 s in the failing "Test" step on 17f6abe, but 351.3 s ("Test"), 322.6 s (observed run) and 321.5 s (whole-package run in "still fail") on e700693, against 434.3 s, 375.6 s and 323.0 s at 6c40bd8. So the ports did not make the package slower; the 17f6abe number is runner variance (inference, from one run each). Go's default test timeout is 600 s per test binary, so the margin is real but not new. A slower runner would fail the job with "panic: test timed out". That fails closed, so nothing merges on it, but it would stop every ES PR until someone acts. The fix, an explicit `-timeout` in the gate, landed on trunk_dev in #61 at 06:44Z, and PR #59 now carries it (section 7).

## 6. For the merge

- **A30-3:** "test on macOS" is not a required check yet. Until David makes it one in the ruleset, the merge gate requires it green on the final head.
- **PR #60:** it changes the same `scripts` tests. Whichever of #59 and #60 merges second needs a fresh green macOS run on its updated head, and #60's new tests may need list lines or ports.
- **The LibreSSL pin** (O30-3) is a product follow-up, written up with its triggers in report 25, "Product follow-up to queue".
- A fresh delta audit of c506156..7fb88b8 follows this head (coordinator, 05:28Z; the head moved from e700693 when #61 merged, section 7).

## 7. trunk_dev moved: #61, and the macOS job's time limit

At 06:44Z #61 merged into trunk_dev as e2af4b2. It gives every `go test` of the gate that runs tests `-timeout=20m` (`TIME_LIMIT` in `go_test_gate.py`, so it also reaches the macOS job), and gives go.yml's job 90 minutes instead of 60. This answers O30-2. GitHub then reported a conflict on PR #59.

**37402ed, the merge.** Of the four files that both sides changed, git merged three on its own (the baseline doc, `go_test_gate.py` and `docs_contract_test.go`). The one conflict was the self-check's hash lines: trunk_dev changed `WORKFLOW_SHA256` (go.yml), and this branch added `MACOS_WORKFLOW` and `MACOS_WORKFLOW_SHA256` beside it. The resolution keeps trunk_dev's go.yml hash and this branch's macOS lines. On the merged tree (91abaea8), the self-check ran 145 tests OK (#61 added one), and `TestGo1265ToolchainBaselineDocsAndBuildContract` passed.

**7fb88b8, the macOS job's limit.** #61's reason for go.yml's 90 minutes is that the job's limit has to leave room for a hung test binary to reach `TIME_LIMIT`, even in the last step that runs tests, so the log shows where it hung. The macOS job runs the same gate under its own limit of 60 minutes. Its slowest passing run took 25 minutes (run 45545850686, 6c40bd8). On a runner half as fast, that is about 38 minutes. If a binary then hangs in one of the last runs of "Listed tests still fail", it adds up to 20 minutes, which comes to about 58 minutes. That leaves too little room to count on, so the macOS job now has go.yml's limit of 90 minutes:

- `go-macos.yml`: `timeout-minutes: 90`, with a comment that gives that reason;
- `go_test_gate.py`: the `TIME_LIMIT` comment now says "inside the job's own time limit in each workflow that runs the gate" (it said "in the workflow");
- `go_toolchain_baseline.md` §10: "The macOS job has the same limit of 90 minutes as the Linux job, so a test binary that hangs there also reaches the gate's limit of 20 minutes inside the job";
- `docs_contract_test.go` pins that sentence and `timeout-minutes: 90` in go-macos.yml;
- `MACOS_WORKFLOW_SHA256` is now `c1bf72a6b7313f891cc8bcaf4ab8fb2ebe1488d3143c616e399071fe41ac45d7`.

The limit only matters when a job hangs. A job that runs normally takes 20 to 25 minutes either way.

**Checks on 7fb88b8** (cloud container, as `ci`, copy of tree 630bdaa9):

- gate self-check: Ran 145 tests, OK;
- `go test -count=1 -run TestGo1265ToolchainBaselineDocsAndBuildContract .`: ok;
- `go vet .`: clean, and `gofmt -l docs_contract_test.go` prints nothing;
- the macOS list against `./scripts/...` with the gate's own checks: 22 entries, 80 skips, OK.

**CI on 7fb88b8:** both green, both on merge commit 958a4b2 (parents e2af4b2, 7fb88b8), whose tree is the head's tree 630bdaa9.

- "test on macOS", run 45563767720, job 139033467344, green 07:13Z, 21 minutes:
  - self-check: "Ran 145 tests", OK;
  - "test gate passed: 2 packages, 1 of them with skipped entries (22 entries); 80 tests skipped themselves, all of them listed";
  - "the observed run passed; go test skipped exactly the listed tests of this package (22), each once";
  - "all 22 listed tests still fail on this host, each in a run of its own and in the run of its package";
  - the scripts package took 370.5 s ("Test") and 325.1 s (observed run);
  - all 26 logged `go test -json` commands carry `-timeout=20m`, none lacks it.
- "build, vet and test", run 45563767801, job 139033467754, green 07:34Z:
  - self-check: "Ran 145 tests", OK;
  - root package `ok execution-substrate 3.940s`;
  - "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed";
  - "all 17 listed tests still fail";
  - "tests as root passed: 9 of execution-substrate/scripts";
  - all 25 logged `go test -json` commands carry `-timeout=20m`.
- Full logs: `31-evidence/macos-run45563767720-job139033467344.log` (sha256 343dafd0…3b67) and `31-evidence/linux-run45563767801-job139033467754.log` (sha256 45492596…f714).

The list did not change after e700693, and the run on 7fb88b8 gives the same list results as section 5.


## 8. Merge

Merged at 07:38:53Z by squash as `819f712cde8fd83f5b73b2154263afa18cf29623` on trunk_dev (parent e2af4b2), after the delta audit (report 32, ACCEPT 7fb88b8) and the merge gate: the base was trunk_dev e2af4b2, the head was still 7fb88b8 (passed as the expected head), GitHub reported the PR mergeable and clean, and both "build, vet and test" and "test on macOS" were green on 7fb88b8. The tree of 819f712 is 630bdaa9, the audited head tree.
