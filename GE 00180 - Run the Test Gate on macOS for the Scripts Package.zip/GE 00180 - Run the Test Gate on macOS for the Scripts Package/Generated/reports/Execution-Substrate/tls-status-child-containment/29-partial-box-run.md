# Partial P30 rerun at trunk_dev bf5a760: PASS

**P30 now passes for trunk_dev `bf5a760` (PR #58 merged).** The Mac A4 check exits 0, and the four tests that failed at `fd0529a` now pass. On the box, the new remote collector (`b4722c83…1138`) passes B4 and all five B5c probes. Together with the parts of `23-box-run.md` that #58 cannot change (B5 and B5b, root collector unchanged), every P30 criterion is met. **The gate in `p30-gate-moved-from-es-upgrade-plan.md` is open:** TLS status checks may run on the box from a checkout at or after `bf5a760`. They may not run from a commit that holds #30 but not #58. The box was handed back in working order at 03:32Z: the folder was removed, all 9 services were active as before, and no process was left.

Written by the writer thread "Contain TLS status collector child processes". Brief: `28-partial-p30-brief.md`. The run went through Remote Control on David's Mac, on the coordinator's box turn of 2026-11-25 03:20Z, under David's bulk approval of box runs (2026-11-24 04:23Z).

## Results against the pass criteria

| # | Check | Result |
|---|---|---|
| 1 | Mac A4 | **Passed.** Exit 0. 1,033 PASS, 14 SKIP, 0 FAIL (ran 03:28:27Z to 03:30:43Z). `…DescendantRunCommand`, `…RemoteCollectorPureFunctions`, `…RemoteCollectorHardBounds` and `…RemoteCollectorLifecycleOrdering` all PASS. No `panic:` or `AttributeError` line. The 14 skips are exactly the expected ones: the five `…ChildNamespaceReal…` tests and `…AnchorProcess`, the five `…DescendantReal…` tests, and the three `/proc` tests (`…ProcessIdentityLiveProcesses`, `…ProcessIdentityThreadExecStaysPresent`, `…UnrelatedProcessNameDoesNotHoldCleanup`) |
| — | Mac A7 | The patch sum matched on the first write. The dump ran with exit 0, and all five remote probe sums were as listed |
| 2 | B3b | **Passed.** Every sum matched: the collector `b4722c83…1138`, `pr30_box_probe.py` `cf6dcade…eb75` and the five probes. Folders were 700 and files 600, all owned by `claude` |
| 3 | B4 | **Passed.** The verbatim lines are below |
| 4 | B5c (`new`) | **Passed.** All five probes: `"capability": true`, exit 0, `"failed cases": []`. Cases ran: 10, 2, 4, 3 and 2 |
| 5 | B7 | **Passed.** No process line, the folder was gone, and all 9 services were active, as in B1 |

Environment:

- Mac: macOS 26.6.2 (25G83), arm64, go1.26.5 inside the clone, address `en0 [home network address withheld]`.
- Box: `[test box name withheld]`, kernel 7.0.0-42-generic, login user `claude` (uid 1002), `sudo -n` ok.
- The clone was at `bf5a760`, tree `9a4cf094…` (as expected).

## B4, verbatim (03:31:31Z to 03:31:33Z, exit 0)

```
{"RLIMIT_NPROC": [54196, 54196], "cgroup": "0::/user.slice/user-1002.slice/session-3261.scope", "children file": "", "part": "r2 facts", "pids.current": "3", "pids.max": "max", "process limit of the fixed child": 0, "python": "3.12.3", "sigchld": "0", "status": {"NoNewPrivs": "0", "Seccomp": "0", "Threads": "1"}, "uid": 1002}
{"flag": true, "part": "r2 descendant probe", "verdict": "accepted"}
{"bytes from stand-ins": 1, "flag": true, "part": "r2 fixed command that tries to start a descendant that ignores TERM", "process left after return": false, "returncode": 0, "runtime_failed": false, "stdout": "EAGAIN"}
{"flag": true, "part": "r2 fixed command through sudo -n under the process limit: /usr/bin/id -u", "returncode": 0, "runtime_failed": false, "stderr": "", "stdout": "0"}
{"flag": true, "part": "r2 fixed command through sudo -n under the process limit: /usr/bin/stat -c %a:%u:%g:%F /etc/hostname", "returncode": 0, "runtime_failed": false, "stderr": "", "stdout": "644:0:0:regular file"}
```

## B5c, verbatim (03:31:39Z to 03:31:53Z)

```
{"capability": true, "cases": 10, "detail": {}, "exit": 0, "failed cases": [], "part": "probe OperatorHealthcheckTLSStatusNoninteractiveDescendantRealKernel on new", "reason": null, "seconds": 2.13, "stderr tail": "", "unparsed stdout": null}
{"capability": true, "cases": 2, "detail": {}, "exit": 0, "failed cases": [], "part": "probe OperatorHealthcheckTLSStatusNoninteractiveDescendantRealProbeRefusesAChild on new", "reason": null, "seconds": 0.28, "stderr tail": "", "unparsed stdout": null}
{"capability": true, "cases": 4, "detail": {}, "exit": 0, "failed cases": [], "part": "probe OperatorHealthcheckTLSStatusNoninteractiveDescendantRealCrowd on new", "reason": null, "seconds": 4.75, "stderr tail": "", "unparsed stdout": null}
{"capability": true, "cases": 3, "detail": {}, "exit": 0, "failed cases": [], "part": "probe OperatorHealthcheckTLSStatusNoninteractiveDescendantRealProcessLimit on new", "reason": null, "seconds": 0.11, "stderr tail": "", "unparsed stdout": null}
{"capability": true, "cases": 2, "detail": {}, "exit": 0, "failed cases": [], "part": "probe OperatorHealthcheckTLSStatusNoninteractiveDescendantRealCollectorDeath on new", "reason": null, "seconds": 1.28, "stderr tail": "", "unparsed stdout": null}
```

Each probe line was followed by `exit 0`.

## Departures from the brief (none changes a result)

- The session ran B1 and the B3 staging on the box while A4 ran on the Mac. B3b, the sum check, B4 and B5c ran only after A7 had finished.
- It wrote both files before A7. For the patch, it typed a placeholder for each tab, replaced each with a tab using perl, then checked the sum. Both sums matched on the first write.
- In C4 it ran `chmod -R u+w` on `$T/gocache` before `rm -rf`. That touched nothing outside `$T`.
- No box step needed a retry, and Wi-Fi held.

## Side note

The Mac clone's origin is `github.com:SeritArbores/Execution-Substrate`. This is already known in project memory (the repository redirects to evo-agi), and nothing here depends on it.
