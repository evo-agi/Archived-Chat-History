# 32. Independent delta audit of ES PR #59 (macOS CI job), 6c40bd8 to 7fb88b8

```
INDEPENDENT AUDIT REPORT
Repository: evo-agi/Execution-Substrate, PR #59 "CI: run the test gate on macOS for the scripts package"
Target:     head 7fb88b88ccf23160b1a9e8aafb1ed8359d4dc610, tree 630bdaa94ac814c13aaf33a3f6e26d61d94a8c71,
            base trunk_dev e2af4b27ad8ab443084c90bb9113ed1204fbdf69 (#61), branch claude/project-thread-wbmulu
Delta:      from 6c40bd8 (report 30, ACCEPT with A30-1, A30-2, A30-3): c506156, 17f6abe, e700693,
            37402ed (merge of trunk_dev e2af4b2, one conflict), 7fb88b8
Recipe:     governed_execution_audit_patch_manifest_v2.py, source sha256 c08597e2…a3ca (checked before every run)
Manifest:   cec3162016c5847da8075ff72ec4f67b19b504c8fbf99b29d5034323c863962e, 11 paths
            (reproduced twice, byte-identical, equal to the writer's; open = close)
            Also reproduced, now superseded: e700693 against bf5a760, 23f08e1e…9d99, equal to the writer's.
Writer:     31-pr59-foldin.md (sha256 916b7ea6…e972 as read at 06:55Z)
Posture:    fresh auditor thread; I have not audited this PR before. Read-only on the target. No subagents.
            Nothing pushed, no PR comment, no workflow re-run, box not touched.
            Cloud container: Linux 6.18.44, Go 1.26.5, tests as an unprivileged user ci.
Verdict:    ACCEPT 7fb88b8. No open finding in the patch. A30-1 and A30-2 are closed. One new low finding,
            L32-1 (the PR description named the superseded target), was fixed by the writer at 07:35:59Z
            and changed no repo bytes. A30-3 stays open as a ruleset setting for David. Both workflows are
            green on the exact head tree.
Red-team:   not needed in my view: CI, test and doc changes only, no product code. The coordinator decides.
```

All times are UTC on 2026-11-25.

## 1. Verdict in short

**ACCEPT 7fb88b8.** The delta does what the coordinator asked, and both workflows are green on the exact head tree.

- **A30-1 is fixed.** `TestRemoteAlphaOperatorPrepareSummaryPathRefusesPlantedArtifactFolder` now reaches the planted link on a host whose `/tmp` is a link, and fails there when nothing is planted (section 4).
- **A30-2 is fixed.** The stat group now names the box helper's own `sudo stat -c '%U'` at `scripts/remote_alpha_reset_disposable_vault.sh:410`, and the runner's log shows that exact failure (section 5).
- **A30-3 is still open.** It is a ruleset setting for David, outside the repo. Until it changes, the merge gate has to require a green "test on macOS" on the final head.
- **The four ports are sound.** Each ported fake still exercises the check its tests are named for (section 6).
- **The 22 entries are right.** Each entry's first failure in its own run on the runner is the host difference its group names (section 7).
- **The gate still fails when a listed test passes or an unlisted one fails.** A real run on 17f6abe failed on three unlisted failures, my probe on 7fb88b8 failed on all 15 entries that pass on Linux, and the self-test passes (section 8).
- **PR #61 covers the macOS margin, now that #59 is merged with it.** Every `go test` of the gate that runs tests gets `-timeout=20m`, and 7fb88b8 gives the macOS job go.yml's 90 minutes (section 9).
- **One new low finding, L32-1, already fixed:** at 07:05Z the PR description still named e700693, base bf5a760 and manifest 23f08e1e…9d99. The writer updated it at 07:35:59Z, and at 07:37Z it names 7fb88b8, merge commit 958a4b2, manifest cec31620…962e and the 90-minute limit.

## 2. Provenance

**Recipe.** I checked the sha256 of `governed_execution_audit_patch_manifest_v2.py` with `sha256sum -c` before every run: `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, OK.

**Trunk moved during this audit.** I began on the target the coordinator first named: e700693 on base bf5a760.

- I reproduced its manifest: `23f08e1e…9d99`, 11 files, the same bytes as the writer's `31-evidence/manifest-e700693-vs-bf5a760.json`.
- At 06:44Z #61 merged into trunk_dev as `e2af4b2`, and GitHub then reported PR #59 as conflicting.
- At 06:52Z the coordinator retargeted this audit to `7fb88b8` on base `e2af4b2`.

**The final target**, in a fresh clone under `umask 022` (`/opt/audit/es`), following provenance §5.3:

- `origin/claude/project-thread-wbmulu` = `7fb88b88ccf23160b1a9e8aafb1ed8359d4dc610`, the reported tip;
- `origin/trunk_dev` = `e2af4b27ad8ab443084c90bb9113ed1204fbdf69`, an ancestor of the tip;
- the tip's tree is `630bdaa94ac814c13aaf33a3f6e26d61d94a8c71`;
- the checkout of the tip was clean; then `git reset --mixed e2af4b2`, upstream `origin/trunk_dev`.

| Run | Result |
|---|---|
| Open, twice | byte-identical; `manifest_sha256 = cec3162016c5847da8075ff72ec4f67b19b504c8fbf99b29d5034323c863962e`, `textual_diff_sha256 = 2b91d31b…5065`, 11 files |
| `cmp` with the writer's `31-evidence/manifest-7fb88b8-vs-e2af4b2.json` | identical, no mode difference |
| Close, twice (after all probes) | identical to each other and to the open run |

The 11 paths:

- `.github/workflows/go-macos.yml` (new);
- `.github/ci/environment-only-tests-macos.txt` (new);
- `.github/ci/go_test_gate.py`, `.github/ci/go_test_gate_selftest.py`;
- `.docs/system_overview/go_toolchain_baseline.md`, `docs_contract_test.go`, `README.md`;
- `scripts/remote_alpha_host_firewall_test.go`, `scripts/remote_alpha_operator_stage_folders_test.go`, `scripts/remote_alpha_operator_test.go`, `scripts/remote_alpha_root_service_paths_test.go`.

No binaries, caches or generated files.

**The merge of trunk_dev (37402ed) had one conflict, so I resolved it myself.**

- `git merge-tree` of `e2af4b2` and `e700693` gives one conflict block: the `WORKFLOW_SHA256` line of `go_test_gate_selftest.py`. trunk_dev changed that hash for go.yml, and the branch added the `MACOS_WORKFLOW` lines beside it. The other three files that both sides changed merged on their own.
- In a separate worktree I kept trunk_dev's go.yml hash (`618f13cb…a05c`, which is the sha256 of go.yml at e2af4b2) and the branch's macOS lines.
- My tree is `91abaea825c8c324edaa0ba40fe54205baa3b18d`. The writer's merge commit `37402ed` has the same tree, so its resolution is exactly that one.

**The PR's patch did not change in the merge, apart from 7fb88b8.** I compared the added and removed lines of each file, PR head against PR base, before the merge (e700693 against bf5a760) and after it (7fb88b8 against e2af4b2):

- 6 files are identical: `README.md`, the macOS list and the four scripts test files.
- In the other 5, the only differences are 7fb88b8's: the go-macos.yml limit and its comment, the `TIME_LIMIT` comment, the baseline doc sentence, two docs-contract pins and the new `MACOS_WORKFLOW_SHA256`.

Everything else in the merge is #61's own change, which is audited elsewhere and is already on trunk_dev.

**CI tested these bytes.** Section 10 has the runs on 7fb88b8 and the merge commit they checked out. For e700693, both runs (45556839604 and 45556839555) checked out `7c878f6b…` (parents bf5a760 and e700693), and I confirmed that its tree is `b8f661c7…`, the e700693 tree.

## 3. The delta, commit by commit

| Commit | What it changes | Kind |
|---|---|---|
| c506156 | ports four test fakes to macOS; drops 19 list lines | tests, CI list |
| 17f6abe | A30-2 list text; the two O30-4 wording fixes; new macOS workflow hash | CI list, workflow comment, self-test hash |
| e700693 | lists three ported tests again, with their real reasons | CI list |
| 37402ed | merges trunk_dev e2af4b2 (#61); one conflict, resolved as in section 2 | merge |
| 7fb88b8 | macOS job `timeout-minutes: 60` → `90`, with its reason; `TIME_LIMIT` comment; baseline doc sentence and docs-contract pins; new workflow hash | CI, docs |

No product code changed. `go_test_gate.py` changed only in a comment between 6c40bd8 and 7fb88b8, apart from #61's own change.

## 4. A30-1: closed

**The change.** `setupFakeRemoteAlphaWorkloadAuthBootstrapHarness` now makes its fake host root under `filepath.EvalSymlinks("/tmp")` (`scripts/remote_alpha_operator_test.go:3769-3776`). On macOS that is `/private/tmp`. So no folder on the fake host's path is a link, and the output-folder check can no longer refuse the path before it reaches the planted link.

**Simulation.** I used a chroot whose `/tmp` is the link `/tmp -> private/tmp`, as on macOS (`32-pr59-delta-audit-evidence/macroot.sh.txt`, adapted from the earlier audit's). I ran the five tests that use this harness and the summary-path prepare command on plain Linux and in the chroot (`a30-1-sim-and-mutants.txt`):

| Tree | `…RefusesPlantedArtifactFolder` on plain Linux | the same in the `/tmp`-link chroot |
|---|---|---|
| 6c40bd8 (old harness) | PASS | PASS, vacuously: the other four fail on the `/tmp` link, as they did on the runner |
| e700693 (new harness; same test bytes as 7fb88b8) | PASS | PASS |
| e700693 with nothing planted (mutant) | FAIL: "summary-path preparation accepted a planted artifact folder" | FAIL, the same |

So on a host whose `/tmp` is a link, the test now passes only when the plant is there.

**The runner agrees.** On the macOS run of e700693, the scripts package is `ok`, and the test is neither an entry nor a self-skip. The refusal that the listed sibling `…HandsOverAnUnreadableFolder` prints there names `/private/tmp/es-ra-bootstrap-1987319581/var/tmp/execution-substrate-remote-alpha`, which shows that the harness is now under the real path.

**Another former `/tmp` entry now passes on macOS, and it reaches its check too.** `TestRemoteAlphaOperatorPrepareSummaryPathRefusesASummaryLink` pins `error_classification=summary_path_symlink`, and in the chroot a mutant with no planted link fails ("accepted a summary path that is a link").

**A harness regression would be caught.** If the harness went back under the `/tmp` link, `…RefusesASummaryLink` would fail on the runner, as it does in the chroot at 6c40bd8 ("refusal missing error_classification=summary_path_symlink"). It is unlisted, so the gate would fail. See O32-1.

## 5. A30-2: closed

The stat group (`environment-only-tests-macos.txt:70-77`) now says that `require_vault_owned_raft_dir` reads the owner with `sudo stat -c '%U'`, at `scripts/remote_alpha_reset_disposable_vault.sh:410`.

- The line number is right: the function starts at line 401, and line 410 is `owner="$(sudo stat -c '%U' -- "${path}")"`.
- The tests now read the owner with the host's own stat, through `rootPathOwnerName`, which runs `stat -f %Su` on darwin and `stat -c %U` elsewhere. Neither form follows a link.
- On the runner, both listed tests fail in the helper with `stat: illegal option -- c`:
  - `TestRemoteAlphaResetDisposableVaultNeverFollowsALinkAboveTheRaftDirectory` at `remote_alpha_root_service_paths_test.go:1054`;
  - `TestRemoteAlphaResetDisposableVaultRefusesUnsafeRaftStates/raft_directory_of_the_Vault_account` at line 455.
- The third former entry, `…RefusesUnsafeRaftStates/raft_path_is_a_link`, now passes on macOS, and the reason is the right one. The helper refuses a link with `sudo test -L` before it reaches `stat`, and the test pins "Vault raft path is a symbolic link".

## 6. The four ports

**The fake sshd (`hostFirewallFakeSSHD`).** It no longer uses `declare -A` or `${x,,}`. It keeps the three settings it reports in an indexed array and lowers case with `tr`.

- I extracted the fake from 6c40bd8 and from e700693 and ran both under the same Bash 5.2 on one corpus (`fake_sshd_diff.sh.txt`, `fake-sshd-diff-result.txt`). The corpus has: global first-value-wins; a value repeated inside a matching `Match` block; `Match Address` lists with `/32` and `/128`; `Include` globs expanded in place; a `Match` block that ends at the end of its included file; keys in mixed case; unknown keys; tabs; a file with no final newline; an empty file; `FAKE_SSHD_WRONG_FOR`; and `-t` with and without `FAKE_SSHD_T_FAIL`.
- Result: 62 cases, 0 different outputs or exit codes.
- The script has no `set -e`, so `slot` returning non-zero for an unknown key does not stop it.
- I could not build Bash 3.2 here: ftp.gnu.org is refused by this container's proxy (HTTP 403). The Bash 3.2 evidence is the runner: on e700693 the eight formerly listed firewall tests are not entries and the package is `ok` under the runner's `/bin/bash`. Those tests are `…ApplyConfirmRollbackOrderWithFakes`, `…ApplyFailuresLeaveNoUnconfirmedMarker`, `…ApplyRefusesOtherBridgesAndContainerIPv6`, `…ApplyRestoresAfterAFailedDropInInstall`, `…InstallsFilesDurably`, `…StatusChecksTheTablesAreLoaded`, `…StatusRefusesEmptyInstalledRulesetAfterCrash` and `…UnconfirmedApplyRecords`, all `TestRemoteAlphaHostFirewall…`.

**The stage-folder "open" change (`chmod 0755 "${stage}"`, no `--`).**

- `${stage}` always starts with `${FAKE_REMOTE_ROOT}/`, an absolute path, so dropping `--` cannot turn it into an option.
- The run step's check (`scripts/remote_alpha_operator.sh:1362`, and the same check at 1500, 1687, 1692 and 2764) needs `find -maxdepth 0 -perm 0700`, which BSD find and GNU find both read as an exact mode. The six `linked/*` siblings already passed on the runner at 6c40bd8.
- A mutant whose "open" change does nothing makes all six `TestRemoteAlphaOperatorRoutesRefuseAStageFolderThatIsNoLongerPrivate/open/*` subtests fail ("route succeeded with a stage folder that is not private"), so they depend on the change.

**`rootPathOwnerName`.** See section 5.

**The bootstrap harness.** See section 4.

## 7. The 22 entries

Every first failing line below comes from each entry's own run in "Listed tests still fail" on the macOS run of e700693 (run 45556839604, job 139010822380). The list did not change after e700693, so these results still describe it.

I read the log from the writer's copy (`31-evidence/macos-run45556839604-job139010822380.log`, sha256 `460ced19…0b6f`). I checked that copy against GitHub: `get_job_logs` reports the same length (1,971 lines, the copy's 1,970 plus the final newline), and its last 45 lines equal the copy's last 45 lines byte for byte.

| Group in the list | Entries | First failure on the runner | Holds? |
|---|---|---|---|
| No `ds` account | `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal` (whole), `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody` (whole), `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`, `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`, `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`, `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap` | `reason=caller_identity_unproved` in the witness output; `KeyError: "getpwnam(): name not found: 'ds'"` for the three P0t tests; "staged_leaf_check_reached failed" / "correct failed" for the stage tests | yes; unchanged since audit 30 |
| `/var` is a link | `TestRemoteAlphaESBinaryDeploymentCheckOnlyIsDefaultAndNonMutating`, `TestRemoteAlphaESConfigTLSPrepRecordsDSSecurityWarningsWithoutFailing`, `TestRemoteAlphaESConfigTLSPrepRejectsPreexistingBroadPrepAccount`, `TestRemoteAlphaVaultServiceUserMigrationApplyRequiresReadyPreflight`, `TestRemoteAlphaOutputDirRefusesASharedStickyFolderAsTheArtifactFolder`, `TestRemoteAlphaVaultServiceUserMigrationPlanRefusesPathsOutsideVault/log_file_in_a_shared_system_directory` | "remote alpha output folder: /var is not a directory or is a symbolic link"; the apply summary was not written (the helper checks `/var/tmp/…` first, as audit 30 traced in the code); "refusal missing "/var/tmp""; a `log_access` blocker that names the `/var` link instead of "/var/log is a shared system directory" | yes. The group text now says "the last two" instead of naming the four `/tmp` tests, which are gone from it |
| No `O_PATH` | `TestRemoteAlphaOutputDirChecksFoldersItCannotRead`, `TestRemoteAlphaOperatorPrepareSummaryPathHandsOverAnUnreadableFolder` | "… is not a directory or is a symbolic link (Permission denied)", the second at `/private/tmp/es-ra-bootstrap-…/var/tmp/execution-substrate-remote-alpha` with `summary_parent_unsafe` | yes. `remote_alpha_output_dir.sh:41` falls back to `O_RDONLY`, and the second test's folder is mode 0000 |
| BSD `chmod` and `--` in the box command | `TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSummaryPathUsesBoundedRemoteCommand`, `TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareRunsBeforeHelperExecution` | `chmod: --: No such file or directory`, `error_classification=summary_parent_chmod_failed` | yes. `scripts/remote_alpha_operator.sh:997` is `chmod 0750 -- "${summary_dir}"`, inside the remote prepare command (heredoc at 958-1030), which runs on the box |
| GNU `stat -c` in the box helper | the two raft entries of section 5 | `stat: illegal option -- c` | yes |
| LibreSSL form | `TestRemoteAlphaESServiceTLSStatusOpenSSLGrammar`, `TestRemoteAlphaESServiceTLSStatusCollectionTypedFailures/malformed_cert` | `unexpected_openssl_grammar` from `cert_metadata`, `remote_alpha_es_tls_status.py:2401` | yes; unchanged (O30-3 still applies) |
| Mach-O | `TestRemoteAlphaUpgradeESReadsGoBuildInfoLikeGoVersion` | `go_build_info …/esconfigcheck: exit status 1` at `remote_alpha_upgrade_es_host_test.go:633` | yes; unchanged |

Counts: 7 + 6 + 2 + 2 + 2 + 2 + 1 = 22. The runner's summary line names the same 22 ("all 22 listed tests still fail on this host, each in a run of its own and in the run of its package").

The writer's claim that none of the 22 shows a fault in code that runs on the operator's Mac holds. The two new groups both fail inside the summary-path prepare command, which the route sends over ssh to the box. Only the tests' fake ssh runs it on the host.

The 80 self-skip lines did not change in the delta. The runner's summary line still says "80 tests skipped themselves, all of them listed".

## 8. The gate still fails when a listed test passes or an unlisted one fails

`go_test_gate.py` did not change in this delta apart from #61's `-timeout` and one comment. The rules that audit 30 proved still hold, and three pieces of evidence show it on these bytes:

1. **An unlisted failure fails the run, on the real runner.** The macOS run of 17f6abe (run 45554489204, job 139003154275) failed in "Test" with `##[error]test gate failed: execution-substrate/scripts`. The cause was three tests that the list did not name then: `…PrepareSummaryPathUsesBoundedRemoteCommand`, `…PrepareRunsBeforeHelperExecution` and `…PrepareSummaryPathHandsOverAnUnreadableFolder`. I read the end of that log from GitHub.
2. **A listed test that passes fails the run, on the real tree with the real list.** I ran `go_test_gate.py still-failing .github/ci/environment-only-tests-macos.txt ./scripts/...` on Linux, as `ci`, on the 7fb88b8 tree (`probe-still-failing-macos-list-on-linux-7fb88b8.txt`). On Linux, 15 of the 22 entries pass. The step exited 1 and named each of those 15 twice: "listed test no longer fails on this host (it passes)" for its own run, and "listed test does not fail in the run of its package (it passes)" for the package run. The 7 `ds` entries still failed, as they should. Every `go test` it started carried `-timeout=20m`.
3. **The self-test passes.** It ran 145 tests, OK, on the 7fb88b8 tree (#61 added one; 144 on e700693).

## 9. PR #61 and the macOS margin

The question: does #61's gate-wide 20-minute `go test` limit cover the macOS workflow's scripts package (600 s default, 351.3 s observed)? **Yes, now that #59 is merged with it.**

- #61 puts the limit in `go_test_json` (`go_test_gate.py`: `command = ["go", "test", "-json", "-timeout=" + TIME_LIMIT] + arguments`, `TIME_LIMIT = "20m"`).
- Every `go test` that runs tests in either mode goes through `go_test_json`. In the gate at 7fb88b8, those are the calls at lines 733, 832, 867, 987, 993 and 1053. The only other `go test` is `go test -list`, which runs no test.
- go-macos.yml calls the same `go_test_gate.py`. So the macOS scripts package now gets 1,200 s. The whole-package runs I read in the runner's logs took 321.5 s to 495.8 s (the slowest on 17f6abe), at most 41% of the new limit.
- `docs_contract_test.go` pins both lines. The self-test's `time_limited` holds every gate run of every `GateCase` to `-timeout=20m`. The `PACKAGES` cases that this PR adds (`GateCoversOnlyTheNamedPackages`) do not check the limit themselves, but they reach `go test` only through `go_test_json`, which adds it unconditionally.
- My still-failing probe on 7fb88b8 shows `-timeout=20m` on every run (section 8). Section 10 has the macOS run's own commands.

**The job limit had to follow, and 7fb88b8 does that.** #61 raised go.yml's job limit to 90 minutes so that a hung test binary reaches the 20-minute limit inside the job, even in the last step that runs tests. go-macos.yml still had 60. I recomputed the writer's figures:

- the slowest passing macOS job took 25:00 (run 45545850686, job 138975158821, 04:18:19 to 04:43:19);
- on a runner half as fast, that is about 38 minutes;
- a binary that hangs in "Listed tests still fail" adds up to 20 minutes, so about 58 minutes against a limit of 60.

90 minutes leaves room, and matches go.yml. The baseline doc sentence and the docs-contract pins say the same. With 90, the per-binary limit stops a hang before the job limit does, so the log shows where it hung. A job limit stopping it first would also fail closed, but without that information.

So I raise no finding on the margin.

## 10. CI on 7fb88b8

Both runs are green, and both checked out merge commit `958a4b2b2729b69270b06946a0763665ef642316` (parents `e2af4b2` and `7fb88b8`). I fetched it: its tree is `630bdaa9…`, the head's tree. At 07:37Z, `refs/pull/59/head`, `refs/pull/59/merge` and trunk_dev were still `7fb88b8`, `958a4b2` and `e2af4b2`.

I read both logs in full through `get_job_logs` and saved them to the evidence folder.

**"test on macOS"**, run 45563767720, job 139033467344, image macos-26-arm64 20261117.0516.1, 06:51:59 to 07:13:04 (21 minutes). Log sha256 `133d1a33…b814`, 1,972 lines.

- self-check: "Ran 145 tests", OK;
- "Test": `ok execution-substrate/scripts 370.536s`, then the observed run `ok … 325.055s` and "go test skipped exactly the listed tests of this package (22), each once";
- "test gate passed: 2 packages, 1 of them with skipped entries (22 entries); 80 tests skipped themselves, all of them listed";
- "Listed tests still fail": the whole-package run took 343.277 s, then "all 22 listed tests still fail on this host, each in a run of its own and in the run of its package". The 22 names in its "still fails:" lines equal the list's 22 entries (`cmp`). The first failures are the same as on e700693: `chmod: --: No such file or directory` and `summary_parent_chmod_failed`, `stat: illegal option -- c`, `caller_identity_unproved`, `getpwnam(): name not found: 'ds'`, the `/var` link, `(Permission denied)`, `unexpected_openssl_grammar` and `remote_alpha_upgrade_es_host_test.go:633`;
- all 26 `go test -json` commands in the log carry `-timeout=20m`. So #61's limit reaches the macOS job.

**"build, vet and test"**, run 45563767801, job 139033467754, 06:52:00 to 07:34:07 (42 minutes). Log sha256 `36250522…54b0`, 1,402 lines.

- self-check: "Ran 145 tests", OK;
- root package `ok execution-substrate 3.940s`. That covers the docs contract test with the new pins and the repo-wide docs tests on the committed tree;
- `es/app` took 410.8 s and 386.1 s in "Test" and 421.9 s in "still fail", now against 1,200 s;
- "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed";
- "all 17 listed tests still fail on this host, each in a run of its own and in the run of its package";
- "tests as root passed: 9 of execution-substrate/scripts";
- all 25 `go test -json` commands carry `-timeout=20m`.

## 11. Findings

```
AUDIT FINDING
ID / Type / Severity: L32-1 / artifact gap (stale projection) / low. RESOLVED at 07:35:59Z
Current contract: provenance-and-audit-evidence.md §13: "PR descriptions should carry the target identity (base SHA,
  audited commit SHA, manifest SHA-256, audit verdict) so the merge gate can be checked from GitHub."
Path and line: PR #59 description, sections "Validation" and "Before merge" (read 07:05Z)
Evidence: it still names e700693, merge commit 7c878f6, base bf5a760 and manifest 23f08e1e…9d99, and asks for a delta
  audit of "c506156..e700693". It does not mention the 90-minute macOS job limit or the merge with #61.
Impact: whoever checks the merge gate from GitHub would read a superseded target. No repo bytes are affected.
Required correction: before the merge gate, update the description to 7fb88b8, base e2af4b2, manifest
  cec31620…962e, the green runs on 7fb88b8 and this audit; and add the job limit to "Changes".
Uncertainty: none.
Patch defect or pre-existing: patch (PR text).
Resolution: the writer edited the description at 07:35:59Z (PR updated_at). Read again at 07:37Z: it names 7fb88b8,
  merge commit 958a4b2 with the head's tree, manifest cec31620…962e, both green runs on 7fb88b8, the 90-minute job
  limit under "Changes", and asks for the delta audit of c506156..7fb88b8.
```

**Carried over, not fixed in the repo:**

- **A30-3 (low, operating model): open.** "test on macOS" is still not a required check (the PR shows only the two checks, and trunk_dev's ruleset requires "build, vet and test", per project memory). Until David changes the ruleset, the merge gate must check a green macOS run on the exact final head. Note for David: a required check named "test on macOS" would also run on PRs that do not touch `scripts`, about 20 to 25 minutes each, at no cost on a public repository.
- **O30-1 (gate design): unchanged.** A listed test that keeps failing for a new reason stays hidden.
- **O30-3 (product follow-up): unchanged.** The LibreSSL pin is fragile.

**Observations (no correction required):**

- **O32-1, the planted-folder test still asserts generic text.** It now reaches its check because the harness path holds no link, and an unlisted sibling (`…RefusesASummaryLink`) would fail on the runner if that ever changed (section 4). Pinning the refused path's suffix, as the staging test at `remote_alpha_output_dir_test.go:541` does ("execution-substrate-remote-alpha is not a directory or is a symbolic link"), would make the test show it on any host by itself. That would be optional hardening.
- **O32-2, merge order with #60 (updates O30-6).** `git merge-tree` of 7fb88b8 and #60's head `dfb2873` is clean. #60 adds a `stat -c '%a'` at `scripts/70_linux_setup.sh:335`. Unknown whether any scripts test runs that line on macOS; #60's own macOS run will show it once #59 has merged. Whichever PR merges second still needs a green macOS run on its updated head.

I found no critical, high or medium finding, and no other low finding in the delta. No finding in the patch is open.

## 12. Validation assessment

**Re-run by me on the exact bytes** (Linux container, Go 1.26.5 from proxy.golang.org, as user `ci`):

| Check | Tree | Result |
|---|---|---|
| Gate self-test | e700693 | Ran 144 tests, OK |
| Gate self-test | 7fb88b8 | Ran 145 tests, OK |
| `go test -count=1 -v -run '^TestGo1265ToolchainBaselineDocsAndBuildContract$' .` | 7fb88b8 | `--- PASS` |
| `go vet ./scripts/...` (linux/amd64 and darwin/arm64), `go vet .` | 7fb88b8 | clean |
| still-failing with the macOS list on Linux | 7fb88b8 | exit 1, the 15 passing entries named in both runs, `-timeout=20m` on every run (section 8) |
| A30-1 simulation and mutants (16 package runs) | 6c40bd8, e700693 and two mutants | as in section 4 |
| Stage-folder "open" mutant | e700693 | all six `open/*` subtests fail with the mutant, pass without it |
| Fake sshd, old against new | 6c40bd8 and e700693 fakes | 62 cases, 0 differences |
| Independent conflict resolution | e2af4b2 + e700693 | tree `91abaea8`, equal to 37402ed's |

The ported test files are byte-identical in e700693 and 7fb88b8, so the e700693 results stand for them.

**Read from GitHub, not re-run:** the macOS and Linux runs of e700693 (section 7), the macOS run of 17f6abe (section 8), the job times of run 45545850686, and the runs on 7fb88b8 (section 10), read in full.

**Not run:**

- anything on macOS (I have no Mac);
- Bash 3.2 (its source download is refused here);
- the full Linux gate and the whole root package in the container (CI runs them on the committed tree, and the container lacks tools such as `uuidgen`, so it would not be a clean comparison);
- a whole-package `/tmp`-link simulation.

## 13. Coverage, handling and confidence

**Inspected:**

- the whole delta 6c40bd8..7fb88b8, all 11 paths, and the interdiff before and after the merge;
- the source behind every one of the 22 entries' groups, and the helper lines cited in the list;
- the gate's call sites of `go test`;
- #61's diff, as far as it meets #59.

**Not inspected:** #61 on its own merits (audited elsewhere); the self-test beyond the groups this delta touches (it passes).

**Sensitive material:** none read or copied. The saved logs and evidence hold repo paths, test names and runner paths only.

**Side effects, all inside this container:**

- the audit clone `/opt/audit/es`, unchanged as the closing manifest shows;
- a trial-merge worktree, tree exports and mutant copies under `/opt/audit`, and a chroot skeleton `/simroot` with private mounts only;
- a local user `ci`.

Nothing was pushed, and nothing was posted on GitHub.

**Confidence:**

- provenance 0.99: both manifests reproduced, open = close, the CI merge trees checked, the merge resolution reproduced;
- validation 0.9: every local check ran on the exact bytes. The macOS results are GitHub's, read in full on the exact merge tree, not re-run by me;
- implementation 0.93: the residuals are the gate's design (O30-1), Bash 3.2 seen only through the runner, and a bounded rather than exhaustive search for vacuous passes.

**Effect status:** REPAIR_NOT_PERFORMED · COMMIT_NOT_PERFORMED · PUSH_NOT_PERFORMED · PR_NOT_MODIFIED · NO_COMMENT_POSTED · MERGE_NOT_PERFORMED.

## 14. For the merge gate

- The PR head must still be `7fb88b8`, with tree `630bdaa9…`, and trunk_dev must still be `e2af4b2`.
- Both "test on macOS" and "build, vet and test" must be green on that head (section 10).
- L32-1 is done: the PR description names this target (read at 07:37Z). GitHub reports the PR as `mergeable_state: clean`.
- A30-3 stays with David.
- If trunk_dev moves again before the merge, the updated head needs a new manifest and green runs of both workflows. It also needs the merge-queue sync check, or an auditor delta check if the merge needs a hand edit.

**Final verdict: ACCEPT** (7fb88b8, tree 630bdaa9, base e2af4b2; no open finding in the patch; A30-3 open for David).
