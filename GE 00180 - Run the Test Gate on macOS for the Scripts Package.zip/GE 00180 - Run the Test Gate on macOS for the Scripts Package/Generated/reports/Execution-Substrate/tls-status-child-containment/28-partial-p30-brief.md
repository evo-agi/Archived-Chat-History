# Partial P30 rerun brief: trunk_dev bf5a760 (PR #58 merged)

Prepared 2026-11-25 ~03:40Z by the writer thread "Contain TLS status collector child processes", for the box turn the coordinator handed out at 03:20Z. It reruns only what PR #58 can change, as `23-box-run.md` and `27-merge-58.md` planned: Mac A4, and on the box B3b, B4 and B5c (the remote collector's sum changed). The root collector is unchanged, so B5 and B5b are not rerun. The `old` (eed4c9b) runs are not repeated: the old collectors did not change, and their results stand in `23-box-run.md`.

**Commit.** `bf5a760a2276f5d8b7600d7b64523e4ee32410d0`, tree `9a4cf0943d5ec7c147ce78580fc9321fd77db13c`. New remote collector `b4722c837949239c14067495ee6e67e281a7c759f646e79198b8634aa2d11138`.

**Pass criteria.**

1. Mac A4: exit 0. The four tests that failed at fd0529a pass (`…NoninteractiveDescendantRunCommand`, `…NoninteractiveRemoteCollectorPureFunctions`, `…HardBounds`, `…LifecycleOrdering`). No failure, no `AttributeError`. The 14 skips of `23-box-run.md` section 1 are expected (the eleven real-kernel and anchor tests, and the three `/proc` tests); any other skip is reported.
2. B3b: every sum as listed; folders 700 and files 600.
3. B4 (login user): `"process limit of the fixed child": 0`; the descendant probe `"verdict": "accepted"`, `"flag": true`; the fork attempt `"returncode": 0`, `"stdout": "EAGAIN"`, `"runtime_failed": false`, `"process left after return": false`; both `sudo -n` commands `"returncode": 0`, `"runtime_failed": false`, with `"stdout": "0"` and `"stdout": "644:0:0:regular file"`.
4. B5c (`new` only): each of the five probes `"capability": true`, exit 0, `"failed cases": []`, no timeout.
5. B7: no process line, the folder gone, services as in B1.

**Rehearsal in the cloud container at bf5a760** (Linux 6.18, Python 3.13, unprivileged user with `sudo -n`):

- The dump patch (`e540169e…4d9d`, unchanged) applies at bf5a760, and all ten probe sums are unchanged from brief 22.
- A4 on Linux: exit 0, 1,042 PASS lines, 5 skips (the PID-namespace tests, EPERM), 0 failures. On the Mac, P30 counted 1,029 pass + 14 skip + 4 fail; inference: about 1,033 pass, 14 skip, 0 fail now.
- B3b sums and modes as listed; B4 lines exactly as in criterion 3; B5c: 10, 2, 4, 3 and 2 cases, none failed.

The Mac session gets the text below as its instructions.

---

## Instructions for the Mac session

Run a partial rerun of a test check of one Execution-Substrate commit on this Mac and on the Remote Alpha box (ssh alias [test box name withheld]), and report the complete output. The commit, bf5a760, holds pull request 58: the noninteractive remote TLS status collector now takes the fixed child's parent-death request from its descendant backend, so the four tests that failed on this Mac in the run of 2026-11-25 01:06Z should now pass. On the box only the new remote collector is checked again.

Rules on the Mac:
- Create exactly one new folder: T=$(mktemp -d /Users/ds/Repositories/Playground/es-p30b-run.XXXXXX) and print it. Then: touch "$T/start-marker".
- Keep /Users/ds/Repositories/Playground as your working directory for the whole run. Never cd into "$T" or below it, not even briefly. Use git -C "$T/es" or a subshell such as ( cd "$T/es" && … ).
- Do not change, stage, commit or delete anything in any existing folder. You may read the origin URL of the existing clone with: git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin. Run no other command in that folder.
- Do not run sudo on the Mac. No git push. No installs and no downloads other than the git clone and fetch.
- For every go command set:
    export GOTOOLCHAIN=go1.26.5 GOPROXY=off GOFLAGS=-mod=readonly GOCACHE="$T/gocache"
  Inside the clone go version must print go1.26.5. If it does not, skip A4 and A7, report, and go on with part B without the probes (then skip B3b and B5c).
- If a go command fails because a module is missing, report the exact error; do not download.
- If a test fails, do not fix any code. Record the output and go on.
- Shell variables may not survive from one of your commands to the next. After you print T (and later D), use their literal values wherever the steps say "$T" or "$D".

Rules on the box:
- Reach it only with: ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] '<command>'. Below this is written BOX '<command>'; BOX is shorthand, so type the full ssh command each time. Do not open an interactive shell.
- Create exactly one folder there (step B3), write only inside it, and remove it in step B7.
- Use sudo on the box only in the exact commands below. Do not start, stop, restart or reconfigure any service. Do not install anything, do not reboot, do not touch Vault, Nomad, Docker, the firewall or any file outside that folder.
- If an ssh command fails with "No route to host" or a timeout (the box is on Wi-Fi, which may drop), run: route -n get [home network address withheld]; ping -c 2 [home network address withheld]; nc -vz -w 5 [home network address withheld] 22. Then wait five minutes and try the same command once more. If it still fails, stop part B: run no further box step except B7, try B7 once more after another five minutes if a box folder was created, report the diagnostics and the folder's path, and go on with part C. Never retry a box step more than once.

A0. The box firewall accepts SSH only from [home network address withheld]. Print:
      for i in en0 en1 en2; do printf '%s %s\n' "$i" "$(ipconfig getifaddr "$i" 2>/dev/null)"; done
    If no interface shows [home network address withheld], do part A, skip part B entirely, do part C, and report the addresses.

Part A, on the Mac:
A1. Print: sw_vers, uname -m, whoami. Clone:
      git clone "$(git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin)" "$T/es"
A2. git -C "$T/es" fetch origin trunk_dev
    Print: git -C "$T/es" rev-parse origin/trunk_dev
    (expected bf5a760a2276f5d8b7600d7b64523e4ee32410d0, trunk_dev when this brief was written. If it differs, say so and still test bf5a760.)
A3. git -C "$T/es" checkout --detach bf5a760a2276f5d8b7600d7b64523e4ee32410d0
    Confirm git -C "$T/es" rev-parse HEAD 'HEAD^{tree}' (expected tree 9a4cf0943d5ec7c147ce78580fc9321fd77db13c).
    Inside the clone print: go version, and go env GOVERSION GOROOT GOTOOLCHAIN GOPROXY GOCACHE.
A4. R='^(TestRemoteAlphaESServiceTLSStatus.*|TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractive.*|.*Doc.*)$'
    K='^(TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal|TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody|TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution)$'
    ( cd "$T/es" && go test -count=1 -v -timeout 30m -run "$R" -skip "$K" . ./scripts/ ) > "$T/head.log" 2>&1; echo "exit $?"
    Report:
    - the exit status;
    - the package result lines (grep -E '^(ok|FAIL|PASS)' "$T/head.log");
    - the number of lines matching each of '^ *--- PASS', '^ *--- SKIP' and '^ *--- FAIL';
    - the result line of each of these four tests: grep -E '^--- (PASS|FAIL|SKIP): TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractive(DescendantRunCommand|RemoteCollectorPureFunctions|RemoteCollectorHardBounds|RemoteCollectorLifecycleOrdering) ' "$T/head.log"
    - every '--- SKIP' line with the two lines after it (grep -E -A2 '^ *--- SKIP');
    - every line containing 'panic:' or 'AttributeError';
    - for each failed test, its complete output from its "=== RUN" line through its "--- FAIL" line and the indented lines after it.
A7. The probes of the five remote collector real-kernel tests, written out by a throwaway copy of the tests (never committed, never pushed):
      git -C "$T/es" worktree add --detach "$T/dump" HEAD
    Write the patch at the end of these instructions into "$T/pr30-probe-dump.patch", exactly the text between its BEGIN and END marker lines (a quoted heredoc such as cat > "$T/pr30-probe-dump.patch" <<'PR30_EOF' keeps tabs and text unchanged). Check:
      shasum -a 256 "$T/pr30-probe-dump.patch"    (expected e540169e776b30514c3bea2f792fac25ca1d74e1f67d85dfc5c2dff790604d9d. The patch holds tab characters, and the sum depends on them. If it differs, rewrite it once. If it still differs, go on with --ignore-whitespace added to both apply commands below; the probe sums decide.)
      git -C "$T/dump" apply --check "$T/pr30-probe-dump.patch" && git -C "$T/dump" apply "$T/pr30-probe-dump.patch"
    (If the patch does not apply, skip the rest of A7 and steps B3b and B5c.)
      mkdir "$T/probes"
      ( cd "$T/dump" && PR30_PROBE_DUMP="$T/probes" go test -count=1 -run '^TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantReal.*$' ./scripts/ ); echo "exit $?"
      ls "$T/probes"; shasum -a 256 "$T/probes"/*.py
    Expected: exit 0 (every one of these tests skips itself on macOS), and exactly these five files with these sums:
      d0a03105193616aa483e38fd53c501459a25fbcc9f8c8179f623195eade9cd62  TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantRealCollectorDeath.py
      6e817c3f1b6419d2364552d9662fb5d49c0dd0a588594f2389ef421bfb2e1a85  TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantRealCrowd.py
      955bd7ba937da6c76c0433eb7d7718c33e00037e1bba1ce496f51b333efc5dac  TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantRealKernel.py
      114fa25f9b0941967d131ccac3482c839dd5539f341c3e568e9c183a95dd89f5  TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantRealProbeRefusesAChild.py
      994307b450360a29d8f9353926d37271b931822c34466558f31d9110c51d982f  TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantRealProcessLimit.py
    If any sum differs or a file is missing, say which, skip steps B3b and B5c, and go on.

Part B, on the box (only if A0 showed [home network address withheld]):
B1. Baseline, read only:
      BOX 'hostname; uname -r; id -un; id -u; sudo -n true && echo "sudo -n: ok"; systemctl is-active es ags ars egs nomad vault spire-agent spire-server docker'
B3. Stage. Write the script at the end of these instructions into "$T/pr30_box_probe.py", exactly the text between its BEGIN and END marker lines, with a quoted heredoc as in A7. Check:
      shasum -a 256 "$T/pr30_box_probe.py"    (expected cf6dcadec4662c709ffe14503c0b05c0b23624422dfec3dedd18f30fb79aeb75. If it differs, rewrite it once; if it still differs, skip the rest of part B and report the sum.)
    Create the box folder and print it:
      D=$(BOX 'mktemp -d /tmp/pr30-box.XXXXXX'); printf '%s\n' "$D"
    It must match ^/tmp/pr30-box\.[A-Za-z0-9]{6}$; if not, stop part B.
      BOX "umask 077 && mkdir '$D/new' '$D/probes'"
    Copy (every file is written with umask 077):
      put() { ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] "umask 077 && cat > '$D/$2'" < "$1"; }
      put "$T/es/scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py" new/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py
      put "$T/pr30_box_probe.py" pr30_box_probe.py
B3b. Copy the probes (only if A7 succeeded):
      for f in "$T/probes"/*.py; do put "$f" "probes/$(basename "$f")"; done
    Check everything (also when B3b was skipped):
      BOX "cd '$D' && sha256sum new/* probes/* *.py; stat -c '%a %U %n' '$D' '$D'/* '$D'/*/*"
    Expected: new/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py b4722c837949239c14067495ee6e67e281a7c759f646e79198b8634aa2d11138, pr30_box_probe.py cf6dcadec4662c709ffe14503c0b05c0b23624422dfec3dedd18f30fb79aeb75, and the five sums of A7. Every folder is 700 and every file 600, all owned by the login user. If any sum differs, go to B7.
B4. The noninteractive remote collector as the login user, in its real launch shape (the script goes on standard input):
      ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o RequestTTY=no [test box name withheld] "exec /usr/bin/python3 -I -S -B - r2 '$D'" < "$T/pr30_box_probe.py"; echo "exit $?"
B5c. The five remote collector tests' probes as the login user, against the new collector only (only if B3b was done):
      for n in RealKernel RealProbeRefusesAChild RealCrowd RealProcessLimit RealCollectorDeath; do BOX "/usr/bin/python3 -I -B '$D/pr30_box_probe.py' probe TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendant$n new '$D'"; echo "exit $?"; done
B7. Leftovers and cleanup on the box (run this whenever a box folder was created):
      BOX "ps -eo pid,ppid,user,stat,args | grep -F '$D' | grep -v grep"
    If any process line appears, run once: BOX "sudo -n pkill -KILL -f '$D/'", wait five seconds and list again; report both lists. Then:
      BOX "sudo -n rm -rf '$D'; ls -ld '$D' 2>&1; systemctl is-active es ags ars egs nomad vault spire-agent spire-server docker"
    Expected: no process line, "No such file or directory" for the folder, and the same service states as in B1.

Part C, on the Mac:
C1. ps -axo pid,ppid,stat,command | grep -E '\.test|remote_alpha|es-p30b-run' | grep -v grep    (expected: no output)
C2. git -C "$T/es" status --porcelain    (expected: empty; the throwaway copy of step A7 is a separate worktree)
C3. find /Users/ds/go/pkg/mod -newer "$T/start-marker" -print | head -5    (expected: no output)
C4. git -C "$T/es" worktree remove --force "$T/dump" (if A7 created it), then rm -rf "$T", then confirm "$T" is gone and /Users/ds/Repositories/Playground still exists. If the removal is refused, do not retry; say so and give David the one-line command.

Report back:
- the A0 addresses, the environment lines, the commit and tree hashes, and the go version lines;
- for A4 and A7, the items asked above;
- for B1 to B7, the complete output of every command, with every JSON line verbatim and every exit status.
Say plainly what passed and what failed. Do not summarize a failure away.

## Files to write (exact text between the marker lines)

----- BEGIN pr30-probe-dump.patch -----
diff --git a/scripts/pr30_probe_dump_test.go b/scripts/pr30_probe_dump_test.go
new file mode 100644
index 0000000..d938159
--- /dev/null
+++ b/scripts/pr30_probe_dump_test.go
@@ -0,0 +1,19 @@
+package scripts_test
+
+import (
+	"os"
+	"path/filepath"
+	"testing"
+)
+
+// For the PR #30 box run only, never committed: writes the probe of each
+// real-kernel test to $PR30_PROBE_DUMP/<test name>.py before it runs.
+func pr30DumpProbe(t *testing.T, argv []string) {
+	dir := os.Getenv("PR30_PROBE_DUMP")
+	if dir == "" {
+		return
+	}
+	if err := os.WriteFile(filepath.Join(dir, t.Name()+".py"), []byte(argv[3]), 0o600); err != nil {
+		t.Fatal(err)
+	}
+}
diff --git a/scripts/remote_alpha_es_service_tls_status_process_identity_test.go b/scripts/remote_alpha_es_service_tls_status_process_identity_test.go
index 188d4ec..1bcc6c5 100644
--- a/scripts/remote_alpha_es_service_tls_status_process_identity_test.go
+++ b/scripts/remote_alpha_es_service_tls_status_process_identity_test.go
@@ -18,6 +18,7 @@ func runRemoteAlphaESProcessIdentityProbe(t *testing.T, probe string, args ...st
 	ctx, cancel := context.WithTimeout(context.Background(), 120*time.Second)
 	defer cancel()
 	argv := append([]string{"-I", "-B", "-c", probe, remoteAlphaESServiceTLSStatusCollectorPath()}, args...)
+	pr30DumpProbe(t, argv)
 	cmd := exec.CommandContext(ctx, "/usr/bin/python3", argv...)
 	cmd.Dir = executionSubstrateRepoRoot
 	cmd.Env = append(os.Environ(), "PYTHONDONTWRITEBYTECODE=1")
diff --git a/scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go b/scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go
index 90da4f3..a3554ea 100644
--- a/scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go
+++ b/scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go
@@ -55,6 +55,7 @@ func runRemoteCollectorDescendantProbe(t *testing.T, probe string, args ...strin
 	ctx, cancel := context.WithTimeout(context.Background(), 120*time.Second)
 	defer cancel()
 	argv := append([]string{"-I", "-B", "-c", probe, p0vRemoteCollectorPath()}, args...)
+	pr30DumpProbe(t, argv)
 	cmd := exec.CommandContext(ctx, "/usr/bin/python3", argv...)
 	cmd.Dir = executionSubstrateRepoRoot
 	cmd.Env = append(os.Environ(), "PYTHONDONTWRITEBYTECODE=1")
----- END pr30-probe-dump.patch -----

----- BEGIN pr30_box_probe.py -----
# PR #30 box probe: child containment of both Remote Alpha TLS status collectors.
# It loads the collectors from DIR, as staged from the pull request head (new/)
# and from eed4c9b (old/), and writes only below DIR. It starts and ends its
# own processes only.
#
#   root DIR  as root through sudo -n: facts, the root collector's whole
#             capability probe, one real "openssl version" through run_fixed,
#             and four stand-in fixed commands (an escaped descendant, an
#             escaped descendant that keeps an ended child unreaped in the
#             group, the same descendant while the fixed command still runs
#             at a time limit of one second, and a command that runs for one
#             second).
#   r2 DIR    as the SSH user, started as `exec /usr/bin/python3 -I -S -B - r2 DIR`
#             with this file on standard input: facts, the noninteractive
#             remote collector's descendant probe, and one fixed command whose
#             escaped descendant would ignore TERM, and two fixed commands
#             through sudo -n, all under the fixed child's process limit.
#   probe NAME VARIANT DIR
#             runs DIR/probes/NAME.py, the probe of one real-kernel test of the
#             pull request head, against the collector in DIR/VARIANT (new or
#             old), with the arguments that the test gives it, and reports its
#             JSON. As root through sudo -n for the TLS status collector's
#             tests, as the SSH user for the remote collector's tests.
import importlib.util, json, os, resource, signal, subprocess, sys, time

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def status_fields(*names):
    found = {}
    with open("/proc/self/status") as handle:
        for line in handle:
            key, _, value = line.partition(":")
            if key in names:
                found[key] = value.strip()
    return found

def proc_value(path):
    try:
        with open(path) as handle:
            return handle.read().strip()
    except OSError as exc:
        return "unreadable: " + type(exc).__name__

def watch(path):
    os.mkfifo(path, 0o600)
    return os.open(path, os.O_RDONLY | os.O_NONBLOCK)

def drain(reader):
    # Everything written so far, and whether a writer is still there.
    data = b""
    while True:
        try:
            chunk = os.read(reader, 65536)
        except BlockingIOError:
            return data, True
        if chunk == b"":
            return data, False
        data += chunk

def say(report):
    print(json.dumps(report, sort_keys=True), flush=True)

FIXED_CHILD = r'''#!/usr/bin/python3 -I
import os, signal, sys, time
mode, fifo, release = sys.argv[1:4]
out = os.open(fifo, os.O_WRONLY)
os.write(out, b"fixed\n")
def stay():
    end = time.monotonic() + 30
    while time.monotonic() < end and not os.path.exists(release):
        time.sleep(0.02)
if mode == "slow":
    time.sleep(1.0); sys.stdout.write("fixed"); sys.stdout.flush(); sys.exit(0)
ready_r, ready_w = os.pipe()
if os.fork() == 0:
    for fd in (0, 1, 2, ready_r):
        os.close(fd)
    if mode in ("zombie", "zombie-run"):
        held = os.fork()
        if held == 0:
            os.write(out, b"held\n"); os._exit(0)
        os.waitid(os.P_PID, held, os.WEXITED | os.WNOWAIT)
    os.setsid()
    signal.signal(signal.SIGTERM, signal.SIG_IGN); signal.signal(signal.SIGHUP, signal.SIG_IGN)
    os.write(out, b"escaped\n"); os.write(ready_w, b"r"); os.close(ready_w)
    stay()
    if not os.path.exists(release):
        os.write(out, b"lapsed\n")
    os._exit(0)
os.close(ready_w); os.read(ready_r, 1)
if mode == "zombie-run":
    stay()
sys.stdout.write("fixed"); sys.stdout.flush()
'''

def root_part(base):
    work = os.path.join(base, "root-work")
    os.mkdir(work, 0o700)
    say({"part": "root facts", "uid": os.getuid(), "euid": os.geteuid(), "python": sys.version.split()[0],
         "cpus": os.cpu_count(), "kernel.pid_max": proc_value("/proc/sys/kernel/pid_max"),
         "kernel.yama.ptrace_scope": proc_value("/proc/sys/kernel/yama/ptrace_scope"),
         "os.unshare": hasattr(os, "unshare"), "os.setns": hasattr(os, "setns"),
         "pid_for_children": os.path.exists("/proc/self/ns/pid_for_children"),
         "status": status_fields("NoNewPrivs", "Seccomp", "CapEff", "Threads"),
         "user.max_pid_namespaces": proc_value("/proc/sys/user/max_pid_namespaces"),
         "kernel.apparmor_restrict_unprivileged_userns": proc_value("/proc/sys/kernel/apparmor_restrict_unprivileged_userns")})
    module = load(os.path.join(base, "new", "remote_alpha_es_tls_status.py"), "pr30_root_collector")
    try:
        module.validate_process_capability()
        verdict = "accepted"
    except BaseException as exc:
        verdict = "refused: %r" % (exc,)
    say({"part": "root capability probe (both parts)", "verdict": verdict,
         "unproved": bool(module.WITNESS_DISPOSITION_UNPROVED)})
    if verdict != "accepted":
        return
    module.PROCESS_CAPABILITY_READY = True
    try:
        result = module.run_fixed((module.OPENSSL, "version"))
        say({"part": "real openssl version in its own PID namespace", "returncode": result[0],
             "stdout": result[1].decode("ascii", "replace").strip(), "stderr_bytes": len(result[2])})
    except BaseException as exc:
        say({"part": "real openssl version in its own PID namespace", "raised": repr(exc)})
    child = os.path.join(work, "fixed-openssl")
    with open(child, "w") as handle:
        handle.write(FIXED_CHILD)
    os.chmod(child, 0o700)
    fixed, module.OPENSSL = module.OPENSSL, child
    limit = module.CHILD_TIMEOUT
    for mode in ("setsid", "zombie", "zombie-run", "slow"):
        module.CHILD_TIMEOUT = 1.0 if mode == "zombie-run" else limit
        fifo = os.path.join(work, "events-" + mode)
        release = os.path.join(work, "release-" + mode)
        reader = watch(fifo)
        started = time.monotonic()
        try:
            result = module.run_fixed((module.OPENSSL, mode, fifo, release)); raised = None
        except BaseException as exc:
            result = None; raised = repr(exc)
        took = round(time.monotonic() - started, 3)
        data, alive = drain(reader)
        if alive:
            open(release, "w").close()
            time.sleep(1.0)
        os.close(reader)
        say({"part": "stand-in fixed command, mode " + mode, "result": repr(result), "raised": raised,
             "seconds": took, "reports": data.decode().split(), "process left after return": alive})
    module.OPENSSL, module.CHILD_TIMEOUT = fixed, limit
    say({"part": "root end", "unproved": bool(module.WITNESS_DISPOSITION_UNPROVED)})

def r2_part(base):
    work = os.path.join(base, "r2-work")
    os.mkdir(work, 0o700)
    module = load(os.path.join(base, "new", "remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py"),
                  "pr30_remote_collector")
    tid = os.listdir("/proc/self/task")
    cgroup = proc_value("/proc/self/cgroup")
    unified = [line[3:] for line in cgroup.splitlines() if line.startswith("0::")]
    say({"part": "r2 facts", "uid": os.getuid(), "python": sys.version.split()[0],
         "sigchld": str(signal.getsignal(signal.SIGCHLD)),
         "children file": proc_value("/proc/self/task/%s/children" % tid[0]) if len(tid) == 1 else tid,
         "status": status_fields("NoNewPrivs", "Seccomp", "Threads"),
         "RLIMIT_NPROC": resource.getrlimit(resource.RLIMIT_NPROC),
         "cgroup": cgroup, "pids.max": proc_value("/sys/fs/cgroup%s/pids.max" % unified[0]) if unified else "no cgroup v2",
         "pids.current": proc_value("/sys/fs/cgroup%s/pids.current" % unified[0]) if unified else "no cgroup v2",
         "process limit of the fixed child": module.FIXED_CHILD_PROCESS_LIMIT})
    try:
        module.validate_descendant_capability()
        verdict = "accepted"
    except BaseException as exc:
        verdict = "refused: %r" % (exc,)
    say({"part": "r2 descendant probe", "verdict": verdict, "flag": module.DESCENDANT_CAPABILITY_READY})
    if verdict != "accepted":
        return
    fifo = os.path.join(work, "events")
    reader = watch(fifo)
    # Under the process limit an unprivileged fixed child cannot fork, and it
    # says so; a fixed child that the limit does not bind (root) forks a
    # descendant that ignores TERM, which the drain must end.
    body = ("import errno,os,signal,time\nw=os.open(%r,os.O_WRONLY);os.write(w,b'x')\n"
            "signal.signal(signal.SIGTERM,signal.SIG_IGN)\n"
            "try:pid=os.fork()\nexcept OSError as exc:print(errno.errorcode[exc.errno]);raise SystemExit(0)\n"
            "if pid==0:\n    os.setsid();os.close(1);os.close(2);time.sleep(30);os._exit(0)\n"
            "print('forked')\n" % fifo)
    result = module.run_command(("/usr/bin/python3", "-I", "-c", body))
    time.sleep(0.2)
    data, alive = drain(reader)
    os.close(reader)
    say({"part": "r2 fixed command that tries to start a descendant that ignores TERM",
         "returncode": result.returncode, "stdout": result.stdout.decode("ascii", "replace").strip(),
         "runtime_failed": result.runtime_failed, "bytes from stand-ins": len(data),
         "process left after return": alive, "flag": module.DESCENDANT_CAPABILITY_READY})
    # The fixed sudo path runs sudo under the same process limit.
    for command in (("/usr/bin/sudo", "-n", "/usr/bin/id", "-u"),
                    ("/usr/bin/sudo", "-n", "/usr/bin/stat", "-c", "%a:%u:%g:%F", "/etc/hostname")):
        if not module.DESCENDANT_CAPABILITY_READY:
            break
        result = module.run_command(command)
        say({"part": "r2 fixed command through sudo -n under the process limit: " + " ".join(command[2:]),
             "returncode": result.returncode, "stdout": result.stdout.decode("ascii", "replace").strip(),
             "stderr": result.stderr.decode("ascii", "replace").strip()[-300:],
             "runtime_failed": result.runtime_failed, "flag": module.DESCENDANT_CAPABILITY_READY})

COLLECTORS = {"ESServiceTLSStatus": "remote_alpha_es_tls_status.py",
              "OperatorHealthcheckTLSStatus": "remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py"}

def probe_part(name, variant, base):
    # The arguments that the test gives its probe: the collector, then a new
    # empty directory, except for the namespace kernel test, which takes none.
    collector = os.path.join(base, variant, [f for k, f in COLLECTORS.items() if name.startswith("TestRemoteAlpha" + k)][0])
    argv = ["/usr/bin/python3", "-I", "-B", "-c", open(os.path.join(base, "probes", name + ".py")).read(), collector]
    if not name.startswith("TestRemoteAlphaESServiceTLSStatusChildNamespaceRealKernel"):
        work = os.path.join(base, "w-%s-%s" % (name, variant))
        os.mkdir(work, 0o700)
        argv.append(work)
    started = time.monotonic()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    try:
        done = subprocess.run(argv, cwd=base, env=env, stdin=subprocess.DEVNULL, capture_output=True, timeout=150)
        code, out, err = done.returncode, done.stdout, done.stderr
    except subprocess.TimeoutExpired as exc:
        code, out, err = "timed out after 150 s", exc.stdout or b"", exc.stderr or b""
    took = round(time.monotonic() - started, 2)
    try:
        answer = json.loads(out)
    except ValueError:
        answer = {"unparsed stdout": out.decode("utf-8", "replace")[-2000:]}
    failed = sorted(label for label, passed in answer.get("cases", {}).items() if not passed)
    say({"part": "probe %s on %s" % (name[len("TestRemoteAlpha"):], variant), "exit": code, "seconds": took,
         "capability": answer.get("capability"), "reason": answer.get("reason"),
         "cases": len(answer.get("cases", {})), "failed cases": failed, "detail": answer.get("detail"),
         "unparsed stdout": answer.get("unparsed stdout"), "stderr tail": err.decode("utf-8", "replace")[-1500:]})

if __name__ == "__main__":
    if sys.argv[1] == "probe":
        probe_part(sys.argv[2], sys.argv[3], sys.argv[4])
    else:
        part, base = sys.argv[1], sys.argv[2]
        {"root": root_part, "r2": r2_part}[part](base)
----- END pr30_box_probe.py -----
