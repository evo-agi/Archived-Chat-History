# 25. macOS CI job: PR #59, ready for audit

STATUS: PR #59 https://github.com/evo-agi/Execution-Substrate/pull/59 is ready for audit at head `6c40bd8fa4f054472761a1f923455387ef3b961f`, tree `20375972635f50e9cde48e73d55f4a186547e235`, base trunk_dev `bf5a760a2276f5d8b7600d7b64523e4ee32410d0`. It is marked ready (not a draft), and both workflows are green on the head. It changes CI, tests and docs only, so it merges after audit and the merge gate.

Written by the writer thread "Contain TLS status collector child processes", on the coordinator's request of 2026-11-25 01:20Z ("check whether a macOS GitHub Actions job running the host-portable ./scripts tests is feasible and cheap; if it is, put it in a separate CI PR") and "For PR 59, proceed as planned" (03:20Z).

## Answer to the question

The job is feasible and cheap.

- Cost: the repository is public, so standard GitHub-hosted macOS runner minutes cost nothing.
- Time: a run takes about 25 minutes (04:18Z to 04:43Z on the head), less than the Linux job (about 44 minutes).
- What it catches: all tests of `./scripts/...` that are not on its list run on macOS 26, on every pull request and on every push to trunk_dev. The list has 38 entries and 80 self-skip lines. Inference: the four failures that P30 found after #30 would have failed this job, because the `prctl` lookup failed in every test that uses the shared stand-in. The job does not test the macOS build of other packages.

## Head and provenance

| Item | Value |
|---|---|
| Head | `6c40bd8` (4 commits on bf5a760: 6454361, 537eace, 0ad447a, 6c40bd8) |
| Files | 7, +635 −31 |
| Manifest v2 | `a11fa1cc5681a5d6d11cf0344ed2b4545ab9aa70c1d71f1c35259b67d2e63b98`, against `bf5a760`. Taken twice, byte-identical, and the recipe sum was checked first. Stored as `25-evidence/manifest-6c40bd8-vs-bf5a760.json` |
| Textual diff | `270d7924035701a09d639c587725ff51b78f2815a438601e3fef93a8df3db290` |
| CI on the head | "test on macOS", run 45545850686, success. "build, vet and test", run 45545850585, success |
| Up to date | trunk_dev is still `bf5a760`, an ancestor of the head |
| Codex review | None. It was started when the PR was marked ready, and stopped at Codex's usage limit (PR comments 7153413221 and 7153413758) |

File sums at the head (from the manifest):

- `.github/workflows/go-macos.yml` `fc7edc60…4bc0` (new);
- `.github/ci/environment-only-tests-macos.txt` `be18e99e…5b7a` (new);
- `.github/ci/go_test_gate.py` `e8834233…76b0`;
- `.github/ci/go_test_gate_selftest.py` `cf4253a1…c118`;
- `.docs/system_overview/go_toolchain_baseline.md` `d56561ee…80aa`;
- `docs_contract_test.go` `2861fbe6…e78d`;
- `README.md` `5e9ddbd0…b1b`.

## What changed

1. **`go-macos.yml`.** A new workflow on the same events as `go.yml`, on `macos-26`.
   - It uses the same Go setup as `go.yml`: `GOTOOLCHAIN=local`, `-mod=readonly`, no cache, actions pinned by SHA.
   - It runs `go mod download` and `go mod verify`, then three steps with `TESTED_PACKAGES: ./scripts/...`: the gate self-check, "Test" and "Listed tests still fail".
   - It calls no `sudo`, and it has no root step.
2. **`go_test_gate.py`: optional third argument `PACKAGES`.** This is a package pattern: `./...`, or `./dir[/dir...]` with an optional `/...`.
   - Both modes work on the packages that `go list PACKAGES` prints.
   - Every line of the list must name one of those packages.
   - Without the argument, the gate covers the whole module, as before.
   - A malformed pattern is refused before any go command runs.
3. **Self-test, now 144 tests** (132 before):
   - checks of `PACKAGES`;
   - a group that holds `go-macos.yml` by its SHA-256 and checks:
     - its gate commands;
     - `runs-on: macos-26`;
     - the list and the packages;
     - `cache: false`;
     - that it calls no `sudo`.
4. **`environment-only-tests-macos.txt`.** Entries and self-skips are grouped by reason, as in the next section.
5. **Docs.** `go_toolchain_baseline.md` §10 gets a paragraph on the second workflow and what a green run shows. `README.md` gets one sentence. `docs_contract_test.go` pins both, the workflow's contents and its hash.

## Why macos-26

David's Mac runs macOS 26.6.2. GitHub-hosted `macos-26` runners have been generally available since 2026-02-26 ([GitHub changelog](https://github.blog/changelog/2026-02-26-macos-26-is-now-generally-available-for-github-hosted-runners/)). The first run, on `macos-15`, showed that tools that ship with macOS matter to these tests. So the job runs the operator's major version.

My guess that the two OpenSSL grammar tests would pass on `macos-26`, as they do on David's Mac, was wrong. The next section explains why.

## The list, by reason

None of the 38 entries is a fault in code that runs on the operator's Mac. Each comes from a difference of the host, or of a test's own fake. All the helpers below run only on the box.

**Entries (tests that fail on the runner):**

| Count | Reason | Tests |
|---|---|---|
| 7 | The runner has no account named `ds`. The first two are listed whole, for the reason that the Linux list gives | FailureWitnessBootstrapOwnedTerminal, RootLoadedStageCustody, StageFIFOSubstitution, RecoverySessionESTLSStatusStageFIFORefusal, the three P0tGrammarDiagnostic tests |
| 10 | `/var` and `/tmp` are links to `/private/...` on macOS, and the box helpers' output folder check refuses a link on the path | 4 use a default under `/var/tmp`. 2 expect a refusal that names `/var/tmp` or `/var/log` and get the `/var` link refusal first; one of these is a single subtest. 4 put their fake host under `/tmp` (`os.MkdirTemp("/tmp", …)`) |
| 1 | macOS has no `O_PATH`, so the check opens with `O_RDONLY` and cannot open a folder that it may not read | OutputDirChecksFoldersItCannotRead |
| 8 | The fake sshd (`#!/bin/bash`) uses `declare -A` and `${x,,}`, which need Bash 4. `/bin/bash` on macOS is 3.2 | the 8 HostFirewall tests that use fakes |
| 3 | The tests call `stat -c %U`, which is GNU stat | ResetDisposableVaultNeverFollowsALinkAboveTheRaftDirectory, and 2 subtests of …RefusesUnsafeRaftStates |
| 6 | The fake scp of the "open" subtests runs `chmod 0755 -- "$stage"`. BSD chmod reads options only before the mode, so it takes `--` for a file name, fails, and the fake copy fails before the run step. The 6 "linked" subtests pass | RoutesRefuseAStageFolderThatIsNoLongerPrivate/open/* |
| 2 | The collector accepts the LibreSSL malformed-PEM refusal only in the exact form that one macOS build prints, with its source path included (`LIBRESSL_PEM_ERROR_PATH`). The runner's `/usr/bin/openssl` does not print that form, on macOS 15 or on macOS 26 | OpenSSLGrammar, CollectionTypedFailures/malformed_cert |
| 1 | `go_build_info` reads only 64-bit little-endian ELF files, and the host build of esconfigcheck is Mach-O | UpgradeESReadsGoBuildInfoLikeGoVersion |

**Self-skip lines (80):**

- 16 need interfaces that only Linux has:
  - 5 need PID namespaces;
  - 4 read `/proc`;
  - 5 need `os.waitid`;
  - 2 firewall subtests read `/proc/net/tcp`.
- 4 firewall real-kernel and real-sshd tests need root, as on Linux.
- 4 tests need a real SPIRE or a real Vault, which only `go.yml` installs.
- 56 Vault workload-auth bootstrap tests skip themselves because the helper needs `prctl` to make its process not dumpable, and macOS has no `prctl`.

The full list with skip reasons is in `25-evidence/macos26-self-skips-run45544226152.tsv`.

## How the list was built

| Run | Commit | Result |
|---|---|---|
| 45539288584 (`macos-15`) | 6454361, empty list | The self-check passed 144/144 on macOS. 32 tests failed. Each was classified from its output and its source |
| 45542402817 (`macos-26`) | 537eace, 36 entries | The 36 entries held. The two OpenSSL grammar tests still failed, so they were listed (0ad447a) |
| 45544226152 | 0ad447a, 38 entries | No unlisted failure. 80 tests skipped themselves, and each got a line (6c40bd8) |
| 45545850686 | 6c40bd8 | Green. "all 38 listed tests still fail on this host, each in a run of its own and in the run of its package" |

Also checked in the cloud container on Linux:

- self-test 144/144;
- root package tests pass;
- `go vet` is clean;
- the list passes the gate's own `read_entries` and `check_list` checks against `./scripts/...`.

## Product follow-up to queue: the collector's LibreSSL grammar

Added 2026-11-25 ~05:20Z, on the coordinator's request of 05:05Z.

**Problem.** `_known_malformed_pem` in `scripts/internal/remote_alpha_es_tls_status.py` decides whether a non-zero `openssl x509` or `openssl pkey` run means "malformed certificate" or "malformed key". It accepts two forms:

- the OpenSSL 3 form (`target3013`), which the box prints;
- one LibreSSL form, `unable to load certificate\n<n>:error:09FFF06C:PEM routines:CRYPTO_internal:no start line:<LIBRESSL_PEM_ERROR_PATH>:Expecting: TRUSTED CERTIFICATE\n`.

`LIBRESSL_PEM_ERROR_PATH` is the full source path inside one Apple build of `/usr/bin/openssl`: `/AppleInternal/Library/BuildRoots/4~CVR0…/…/libressl-3.3/crypto/pem/pem_lib.c:694`. A build with another build root, LibreSSL version or line number prints another path, and the collector then raises `unexpected_openssl_grammar`.

**Effect today:**

- On GitHub's `macos-15` and `macos-26` runners, `TestRemoteAlphaESServiceTLSStatusOpenSSLGrammar` and `TestRemoteAlphaESServiceTLSStatusCollectionTypedFailures/malformed_cert` fail. They are entries in `environment-only-tests-macos.txt`.
- Inference: a macOS update on David's Mac that rebuilds LibreSSL would make the same two tests fail there, for example in a Mac A4 run.
- The box is not affected, because it prints the OpenSSL 3 form.

**Proposed fix (product PR, collector change, needs audit).** Match the source location by its structure, not by one build: a path ending in `/crypto/pem/pem_lib.c:<digits>`, with no newline or `:` inside it. Keep every part that carries meaning exact:

- exit code 1;
- empty stdout;
- the first line;
- the error code `09FFF06C`;
- `PEM routines:CRYPTO_internal:no start line`;
- `Expecting: TRUSTED CERTIFICATE` or `ANY PRIVATE KEY`;
- one trailing newline.

First step: make the grammar test print the real `/usr/bin/openssl` result (code, stdout, stderr) whenever the collector does not recognise it. Then the first macOS CI run of the PR shows the runner's exact form, and confirms that only the path differs (inference: today's failure says only that the form does not match).

**Doc to align in the same PR** (audit 30, O30-3): `.docs/system_overview/remote_supported_host_alpha.md`, around lines 4004 to 4011, says the collector accepts a "fixed Apple LibreSSL build-path suffix `/Sources/libressl/libressl-3.3/crypto/pem/pem_lib.c:694:Expecting:`". The code pins the whole path, build hash included. The doc and the code have to say the same thing after the fix.

**Tests the fix PR adds:** a pure test of `_known_malformed_pem` with synthetic stderr.

- Accepted: today's pinned path; another Apple build root; another `libressl-x.y` folder; another line number.
- Refused:
  - another error code;
  - another function or reason;
  - a missing `Expecting:`;
  - an extra line;
  - a path that does not end in `crypto/pem/pem_lib.c:<n>`;
  - a path holding a newline or a `:`.

**Concrete triggers:**

1. Until the fix lands, the two entries in `environment-only-tests-macos.txt` are the machine record. The step "Listed tests still fail" of go-macos fails as soon as the collector accepts the runner's form, so the fix PR has to delete both lines, and it cannot pass CI otherwise.
2. After the fix, both tests run unlisted in the macOS gate on every PR. So a macOS image whose LibreSSL prints a form the collector does not accept fails CI at once, instead of surfacing later in a run on David's Mac. This is the "test that fails when the matched form is absent".

## Things the coordinator may want to weigh (none blocks this PR)

1. **The LibreSSL pin may break David's own runs.** It is written up above as a product follow-up, with its triggers.
2. **Ports of four test fakes are prepared** (added ~05:40Z, on the coordinator's request of 05:05Z). They are local commit `c506156` on top of `6c40bd8`, saved as `../macos-ci/02-ports-c506156.patch`, and not pushed, so the audited head is unchanged. The changes, all in tests:
   - the fake sshd is rewritten to run under Bash 3.2, with an indexed array in place of `declare -A` and `tr` in place of `${x,,}`;
   - the "open" fake copy drops `--` from `chmod`;
   - the bootstrap harness makes its short fake root under the real path of `/tmp`;
   - the raft tests read the owner with `stat -f %Su` on macOS.

   The patch drops 19 lines from the macOS list. The earlier estimate of 21 was wrong: two raft tests stay listed, because the box helper `require_vault_owned_raft_dir` itself calls GNU `stat -c %U`, and their reason now says so. On Linux every changed test passes. Inference: the 19 pass on macOS. That holds for the chmod, `/tmp` and stat ports. For the 8 firewall tests it is a guess, because the firewall script runs further on macOS once the fake works, and I could not run Bash 3.2 here. The first macOS run will settle it: the gate fails on a test that is not listed and still fails, and on a listed test that passes. Where it goes: into PR #59 if the audit sends it back, otherwise as a follow-up PR once #59 merges (this thread may push only PR #59's branch).

   **Update 05:58Z:** the audit (report 30) asked for it in PR #59, so it was pushed there. The firewall guess held. Three of the 19 still fail on macOS, for host differences in a box command that they reach once they are past `/tmp`, so they are listed again with those reasons. The list has 22 entries at e700693. See `31-pr59-foldin.md`.
3. **Required check.** Making "test on macOS" a required check is a ruleset change that only the repository owner can make.
