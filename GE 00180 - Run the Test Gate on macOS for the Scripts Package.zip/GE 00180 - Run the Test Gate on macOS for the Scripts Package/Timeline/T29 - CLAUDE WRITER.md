Please hold the delta audit of PR #59. `e700693` is no longer the head. #61 merged into trunk_dev at 06:44Z and conflicted with this PR (the self-check's workflow hash). The new head is `7fb88b88ccf23160b1a9e8aafb1ed8359d4dc610` on base `e2af4b2`, and it adds two commits:

- **A merge of trunk_dev.** I resolved the conflict by keeping both hashes.
- **The macOS job's time limit goes from 60 to 90 minutes.** #61 gives each test binary 20 minutes and raises go.yml to 90 minutes. The macOS job runs the same gate, so a binary hanging late on a slow runner could have hit the 60-minute job limit first. The job now has go.yml's limit, with the reason written down in the workflow, the baseline doc and the docs contract.

Locally the self-check passes (145 tests), and so do the docs contract, vet and list checks. The new manifest is `cec31620…962e`, 11 files. Both workflows are running, and I'll send the head for audit once they're green.

STATUS: waiting on CI for 7fb88b8.
