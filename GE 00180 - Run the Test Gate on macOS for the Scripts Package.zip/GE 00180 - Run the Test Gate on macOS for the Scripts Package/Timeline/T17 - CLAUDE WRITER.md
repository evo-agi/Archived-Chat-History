PR #59, the macOS CI job, is ready for audit at head `6c40bd8fa4f054472761a1f923455387ef3b961f` (base trunk_dev `bf5a760`). Both workflows pass on that head: "test on macOS" in run 45545850686 and "build, vet and test" in run 45545850585. The manifest is `a11fa1cc…3b98`, taken twice with identical results. The PR changes CI, tests and docs only, so it merges after audit and the merge gate. Codex did not review it because its usage limit was hit.

**Is it feasible and cheap?** Yes. The repository is public, so the macOS minutes cost nothing. A run takes about 25 minutes, less than the Linux job. The job runs on `macos-26`, the same major version as David's Mac, and covers every `./scripts` test except the 38 listed as failing and the 80 that skip themselves. My guess is that it would have caught the four failures P30 found after #30.

**The list.** No listed failure is a fault in code that runs on the Mac. Each one comes from a difference in the host or in a test's own fake: no `ds` account, `/var` and `/tmp` being symlinks, no `O_PATH`, Bash 3.2, BSD `stat` and `chmod`, Mach-O instead of ELF, and LibreSSL's output. The 80 skips are tests that need Linux-only features, root, real SPIRE or Vault, or `prctl`. Report 25 lists every group with its reason.

**Not blocking, but worth weighing:**
- The collector accepts LibreSSL's malformed-certificate error only with one Apple build path inside it. My inference is that a macOS update could make two TLS status tests fail on David's own Mac too, for example in a future Mac A4 run. Fixing that would be a product PR.
- Porting four test fakes would remove 21 entries from the list.

STATUS: PR #59 ready for audit at 6c40bd8, both checks green; the box is not involved.
