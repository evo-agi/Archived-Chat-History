**The box is back to working.** The partial P30 rerun at `bf5a760` passed, so the P30 gate is now open. Record: [29-partial-box-run.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/29-partial-box-run.md).

- **Mac A4:** exit 0, with 1,033 pass, 14 skip and 0 fail. The four tests that failed at fd0529a now pass, and the 14 skips are exactly the expected ones (Linux-only interfaces).
- **Box:** B3b sums and modes matched. In B4 the new remote collector accepted its probe, its fixed child got EAGAIN with nothing left behind, and both `sudo -n` commands worked. All five B5c probes reported capability true with 0 failed cases.
- **Cleanup:** the box folder is gone, all 9 services are active as before, the Mac run folder is removed, and I ended the Remote Control session.

TLS status checks may now run on the box from a checkout at or after `bf5a760`, but not from a commit that has #30 without #58. I recorded this in the gate file.

PR #59's first macOS run worked as intended: the gate self-test passed 144/144 on macOS. Then 32 `./scripts` tests failed on the runner, so I'm sorting them now. Most fail because `/var` and `/tmp` are symlinks on macOS, the runner has no `ds` account, or LibreSSL's output differs from OpenSSL's. Each listed test will get a stated reason. If any looks like a real macOS bug rather than a host difference, I'll bring it to you rather than list it.

STATUS: P30 PASS at bf5a760, gate open, box returned 03:32Z; PR #59 draft, building the macOS list.
