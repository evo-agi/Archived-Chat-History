Both follow-ups are done. The ports are ready but not pushed, so the audit of PR #59 still sees the same head, 6c40bd8.

- **LibreSSL write-up:** it is a new section of report 25, "Product follow-up to queue". It covers the fix and the tests the fix PR should add. It also names two triggers:
  - Until the fix lands, the two macOS list entries are the record. The macOS check fails as soon as the collector accepts the runner's output, so the fix PR has to delete them.
  - After the fix, those two tests run on macOS on every PR, so a macOS change in the output fails CI right away.
- **Ports:** local commit `c506156`. It changes test fakes only and removes 19 lines from the macOS list. My earlier count of 21 was wrong: two raft tests have to stay listed because the box helper itself uses GNU `stat`. On Linux, every changed test passes, and the whole scripts package fails only the same 10 known container failures as before.
- **Not yet confirmed:** that the 8 firewall tests pass on macOS. I couldn't run Bash 3.2 here, so the first macOS run will tell.

If the audit sends #59 back, I'll add `c506156` to it. Otherwise it becomes a follow-up PR after #59 merges, because this thread can only push #59's branch.

STATUS: PR #59 in audit at 6c40bd8; ports ready as c506156, waiting on the audit result.
