The macOS CI job's fixes ([PR 59](https://github.com/evo-agi/Execution-Substrate/pull/59)) are going to a fresh auditor.
