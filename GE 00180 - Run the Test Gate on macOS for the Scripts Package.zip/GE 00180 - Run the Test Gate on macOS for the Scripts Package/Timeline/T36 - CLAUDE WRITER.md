PR #59 is merged. The squash commit is `819f712cde8fd83f5b73b2154263afa18cf29623` on trunk_dev, merged at 07:38:53Z (2:38 AM Eastern), and its tree is the audited head tree of 7fb88b8. The merge gate passed first: the branch was up to date with trunk_dev `e2af4b2`, the head was still 7fb88b8, and both "build, vet and test" and "test on macOS" were green on it.

**The LibreSSL follow-up is written up but not started.** It is a product change to `scripts/internal/remote_alpha_es_tls_status.py`, so it needs its own PR, audit and red-team. The write-up is in report 25 under "Product follow-up to queue":

- **The fix:** match the LibreSSL source path by its structure, ending in `crypto/pem/pem_lib.c:<n>`, and keep the error code, reason, `Expecting:` line and exit code exact.
- **In the same PR:** first make the grammar test print the runner's real openssl output, and align `remote_supported_host_alpha.md` around lines 4004 to 4011.
- **The machine triggers are live now:** the two macOS list entries make "Listed tests still fail" go red as soon as the collector accepts the runner's form. After the fix, both tests run unlisted on every PR.
- **Risk until then (inference):** a macOS update on David's Mac will likely make the same two tests fail in a Mac A4 run.

This thread can start it once you queue it.

STATUS: PR #59 is done. The LibreSSL follow-up waits for you to queue it.
