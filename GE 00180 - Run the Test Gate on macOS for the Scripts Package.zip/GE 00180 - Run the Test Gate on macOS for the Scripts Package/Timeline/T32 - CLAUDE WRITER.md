PR #59 is ready for the delta audit at head `7fb88b88ccf23160b1a9e8aafb1ed8359d4dc610`, on base `e2af4b2`. Both workflows are green on that head, and CI tested the exact head tree. The audit covers `c506156..7fb88b8`.

- macOS: 22 entries still fail as listed, 80 tests skip themselves, all listed, and every `go test` carries #61's `-timeout=20m`.
- Linux: the gate passes with 17 entries, and the root step passes.

The new manifest is `cec31620…962e`, 11 files. Report 31 now has a section 7 on the trunk_dev merge and the 90-minute job limit.

The merge-gate notes still hold. "test on macOS" must be green on the final head (A30-3), and whichever of #59 and #60 merges second needs a fresh green macOS run.

STATUS: PR #59 waits for the delta audit and the merge gate. Nothing else is open on my side.
