PR #59 is ready for the delta audit at head `e7006931dec92be35d67d64e2fa1fa160d561ef7`. Both workflows are green on that head, and CI tested the exact head tree. The changes since the audited `6c40bd8` are c506156, 17f6abe and e700693, all tests, CI list and wording.

- **A30-1 is fixed.** The planted-folder test now reaches the planted link on macOS, and it fails when nothing is planted.
- **A30-2 is fixed.** The stat entries now cite `remote_alpha_reset_disposable_vault.sh:410`. Both O30-4 nits are fixed too.
- **The ports cleared 16 entries, not 19.** Three tests got past `/tmp` and then hit two host differences in the box's prepare command: BSD `chmod --` at `remote_alpha_operator.sh:997`, and no `O_PATH`. I listed those three again with those reasons, so the list has 22 entries.
- **The firewall guess held:** all 8 firewall tests pass on Bash 3.2.
- **A30-3 still applies.** "test on macOS" must be green on the final head. Whichever of #59 and #60 merges second needs a fresh green macOS run.
- **The timeout margin is unchanged (O30-2).** The scripts package took 351 s against the 600 s limit. A gate-wide `-timeout` fix would be its own small CI PR, and it's your call whether to queue it.

Manifest v2: `23f08e1e…9d99`, 11 files. The full record is in report 31.

STATUS: PR #59 waits for the delta audit and the merge gate. Nothing else is open on my side.
