The macOS CI job is ready as [PR 59](https://github.com/evo-agi/Execution-Substrate/pull/59), and its independent audit is starting.
