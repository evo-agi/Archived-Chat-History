PR 59 head 7fb88b8 now has both workflows green on the exact head tree (writer's report 31 section 7 covers the merge and the 90-minute limit). You can give your verdict now.
