# 28-audit-pr19-a26-1 evidence (ES PR #19, head f7dd85d)

Written by the independent audit thread "Audit bring-up running as the operator", 2026-11-23, 11:15Z to 11:36Z.
Every file here was produced in the audit's cloud container. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../28-audit-pr19-a26-1.md`.

## Setup

- Same container, toolchain (Go 1.26.5, `GOTOOLCHAIN=local`), kernel (6.18.44) and test users as `26-audit-pr19-o24-1`:
  - `ci` = 1500:1600, groups cigrp (1600) and docker (996), passwordless sudo;
  - `ci2` = 1700:1700, groups docker and cigrp, no sudo.
- Trees come from `git archive f7dd85d`: `/home/ci/es27` (ci) and `/home/ci2/es27` (ci2). Their `scripts/` equal the ab1fadb tree's.
- Every test run starts with `env -i` and sources `ci-env.sh.txt` or `ci2-env.sh.txt`.

## Files

| File | What |
| --- | --- |
| manifest-v2-open-f7dd85d-run1.json, -run2.json, manifest-v2-close-f7dd85d-run1.json, -run2.json | Base-pinned manifest (base bc9fe36, upstream origin/trunk_dev), taken first (11:15Z) and last (11:32Z): 28ff8942…62ec all four times, byte-identical to the writer's |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start and the end (branch f7dd85d, trunk_dev bc9fe36 both times) |
| ci-check-runs-pr19-f7dd85d.txt | PR #19's check run on f7dd85d (success), and what its job log shows about the es/app run |
| delta-f109af4-f7dd85d.diff | `git diff f109af4 f7dd85d`, byte-identical to the writer's patch |
| mutants25.py.txt, fix-vs-f7dd85d.diff | Audit 26's `fix_test` applied to f109af4's test file, diffed against f7dd85d's: only comment lines differ |
| unit27.sh.txt, unit-tests-f7dd85d-uid1500-gid1600.log, unit-tests-f7dd85d-uid1700-gid1700.log | vet, gofmt, `bash -n`, the launcher, bring-up, storage-check and stop tests, and `go test . -run Doc`. ci: 111 pass. ci2: 105 pass, 6 sudo skips. Fan-out count 535 and 536 |
| mutants27.py.txt, mutants27-uid1500-gid1600.log, mutants27-uid1700-gid1700.log | P and V rows as both users: per-directory work caught on the count; both ways of missing the namespace (V01 to V03) caught by the new record check |
| mutants27-wrap-uid1500-gid1600.log | W00 and W01 as ci, with the helper's namespace `pid_max` lowered to 32,768: the real check passes; a wrapped per-directory walk is caught by the guard |
| ci-env.sh.txt, ci2-env.sh.txt | The environment of every test run |

## Sensitive material

The tests and fixtures are synthetic. No key, certificate body, token or config file is copied here.
A pattern scan for private-key headers, certificates, and Vault, JWT, GitHub, Anthropic and AWS token shapes
found nothing.
