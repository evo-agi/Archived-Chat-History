# PR #19 repair of audit 24's O24-1: the full fan-out test counts processes instead of timing the check

Report 25 of the CI Nomad/Vault track. It answers the coordinator's request of 2026-11-23 09:37Z: replace the fixed 30 s limit of `TestARSStorageCheckScalesToARSFullFanOut` with a structural check now, then a narrow re-audit by the same auditor, the gate, and a merge without David's review (scripts, tests and docs only).

Date: 2026-11-23. Repository: `evo-agi/Execution-Substrate`, draft PR #19. Evidence: `25-repair-pr19-o24-1-evidence/` next to this file, with `SHA256SUMS.txt`.

## 1. Outcome

| Item | Result |
| --- | --- |
| O24-1, a 30 s wall-clock limit with under 2x headroom | **Closed.** The test no longer has a time limit. It counts the processes the check's probe starts at ARS's full fan-out (65,794 directories, a blob in each) and requires fewer than one per 32 directories (at most 2,056). The real check starts **535 to 537**. One `ls` or one subshell per directory starts **66,329 to 66,330** and fails. The time is only logged. |
| A pitfall found on the way | This kernel (6.18) keeps `pid_max` per PID namespace (since Linux 6.14): 32,768 on this host, 4,194,304 inside a container. The test reads it inside the probe's namespace, not on the host (section 3.2). |
| Product scripts | **Unchanged.** `ab1fadb..f109af4` touches only the test file, one sentence of `PLANS.md` and the docs contract. |
| Branch | One commit, `f109af4`, on `ab1fadb`. No merge was needed: trunk_dev is still `bc9fe36`. No rebase, no force-push. |
| Manifest | **`e3f8032cc62f9a62f3c11c5d50453439d4b8e9774b9474439f9007e0e7eeb58c`** (`f109af4` against `bc9fe36`, 13 files) |
| CI | [run 45151423109](https://github.com/evo-agi/Execution-Substrate/actions/runs/45151423109) green on `f109af4` (09:55Z to 10:19Z). The gate fails on any test that skips without a list entry, and the list has none for this PR's tests, so the fan-out test ran and passed on the runner. Its log line is not printed: the gate shows output only for failing tests. |

## 2. Target identity

| Field | Value |
| --- | --- |
| Branch | `claude/project-thread-a9tcoa-services-nonroot` |
| Head | `f109af49d50c6c281c5b1cef0d56bbe287dbd338` |
| Audited head | `ab1fadb1109469a44509544b48312b14f1e2d75d` (audit 24, ACCEPT) |
| Commit since `ab1fadb` | `f109af4` "Pin the full fan-out check's cost by counting its processes, not by time" |
| Base | `bc9fe3619823245faf550db4bf1bc3e782fbd5a5` (trunk_dev, checked at 09:56Z), upstream `origin/trunk_dev` |
| Manifest tool | `governed_execution_audit_patch_manifest_v2.py`, sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Manifest of `f109af4` against `bc9fe36` | `e3f8032cc62f9a62f3c11c5d50453439d4b8e9774b9474439f9007e0e7eeb58c`, 13 files, textual diff sha256 `7330c07bd4f337003da42deccb89305cbe080e3779299298878063987b56a3dd` |
| Previous manifest (`ab1fadb`) | `7c0727f4b76933d60791cfcc98348b8069bad4f24a121d455a8a52ed3dc39364` |

Taken twice by the v2 recipe in one fresh clone (umask 022, HEAD and trunk_dev checked, `git reset --mixed` to the base, upstream re-pinned to `origin/trunk_dev`, the tool with `python3 -I`). Both runs are byte-identical.

`git diff --stat ab1fadb f109af4`:

```
 PLANS.md                                        |   2 +-
 docs_contract_test.go                           |   9 +-
 es/app/service_launchers_container_user_test.go | 172 ++++++++++++++++++++++--
 3 files changed, 168 insertions(+), 15 deletions(-)
```

## 3. The repair

### 3.1 What the test measures

The property the old limit stood for is that the walk starts no process per directory. ARS's layout `sha256/xx/yy/<digest>` gives 65,794 directories, so any per-directory process, whether an external command or a `$(...)` subshell, starts over 65,794 processes. The real probe starts two (`xargs` and `rm`) per 256 directories for its batched removal, 258 batches or 516 processes, and about 20 more for its fixed steps (`mktemp`, `cat`, `chmod`, `mv` and the like) and its container's start. The eight runs of the real check in this repair (five on `f109af4`, three on the tree before it) counted 535, 536 or 537; I did not trace the one-process spread, which is noise against a bound of 2,056.

How the test counts:

1. It starts a helper container from the check's image that only sleeps (`docker run -d --rm --network none --entrypoint /bin/sleep … 3600`).
2. It puts a `docker` wrapper first in the check's `PATH`. The wrapper adds `--pid container:<helper>` to the probe's `docker run`, recognised by its `ars-storage-probe` argument, and passes every other call, and every other argument, to the real Docker unchanged. The production command is not changed; the probe still runs with its image, `--user`, mounts, name and `--network none`.
3. Before and after the check it runs `docker exec <helper> /bin/sh -c 'echo $$'`. A new namespace hands out PIDs one after another, so the difference, minus the second sample's own PID, is the number of processes started in that namespace during the check, all of them the probe's.
4. It requires `started * 32 < directories`, so at most 2,056 processes.

The time is only logged. The test still requires the check to pass and the index to be rewritten the way ARS writes it, as before.

### 3.2 The wrap guard, and per-namespace `pid_max`

A namespace's PIDs wrap around at its `pid_max`. Where that is 32,768, a walk that starts 66,330 processes wraps twice and could end near its starting PID, so the difference alone could pass a per-directory walk. The test therefore also reads the kernel's global fork counter (`processes` in `/proc/stat`) before and after, and fails unless fewer processes than `pid_max − PID before` were started on the whole kernel meanwhile, and unless the PID after is above the PID before. Every PID in the namespace comes from a fork on that kernel, so this bounds the namespace's allocations and rules out a wrap.

Two conditions make that sound, and the test checks both:

- **`pid_max` is read inside the helper's namespace.** My first version read `/proc/sys/kernel/pid_max` on the host. On this kernel that is 32,768, but inside a container it is 4,194,304, because Linux 6.14 made `pid_max` per namespace. The first F01 run showed it: the namespace reached PID 66,339, above the host's limit, and the guard fired with the wrong reason. The test now reads it with `docker exec <helper> /bin/cat /proc/sys/kernel/pid_max`. Before 6.14 every namespace sees the kernel's single value there, so the read is right on both.
- **The daemon runs on the test's own kernel.** `/proc/stat` counts this kernel's forks only. The same `docker exec` reads `/proc/sys/kernel/random/boot_id`, which every namespace on one kernel shares, and the test fails with a clear message if it differs from the host's (for example a daemon in a VM). The other storage-check tests already need a local daemon for their bind mounts.

### 3.3 Docs

- `PLANS.md`: "(`TestARSStorageCheckScalesToARSFullFanOut` requires under 30 s)" becomes "`TestARSStorageCheckScalesToARSFullFanOut` pins that cost by structure, not by time: it counts the processes the check starts at that size, about 540 with removal in batches of 256 directories, and requires fewer than one per 32 directories."
- `docs_contract_test.go`, `TestARSStorageCheckDocsContract`: requires the new sentence's two parts and lists "requires under 30 s" as stale.
- The runbook and the configuration page say "takes seconds" and name no test bound, so they are unchanged.

## 4. Validation

### 4.1 The count discriminates

`mutants23.py` F series, run with only `TestARSStorageCheckScalesToARSFullFanOut`, on `f109af4`, as ci:

| Mutant | Result | Processes counted |
| --- | --- | --- |
| F00, unmutated | pass | 536 (14.9 s) |
| F01, one `ls -A` per directory | **fails**, "started 66330 processes for 65794 directories, one per 32 directories or more" | 66,330 (67.4 s) |
| F02, one `: "$(printf x)"` subshell per directory (new) | **fails**, same message | 66,329 (43.8 s) |

Log: `fanout-count-mutants-f109af4.log`. F02 is new in `mutants23.py`, which now also prints the test's log lines for the F series.

### 4.2 The wrap guard is needed and sufficient

`gmut.py` lowers the helper namespace's `pid_max` to 32,768 (the helper is started `--privileged` and writes its own namespace's limit, which Linux 6.14+ allows), so a per-directory walk really wraps:

| Case | Result | What it shows |
| --- | --- | --- |
| G00, the real check | pass, 537 processes | The guard does not fire on the real check: 676 forks on the whole kernel against 32,768 − 19. |
| G01, one `ls` per directory | **fails** through the guard: "66471 processes were started on this kernel during the storage check, enough for the PIDs of the probe's namespace to wrap around at its pid_max 32768 … (PIDs 19 before and 1415 after)" | The guard catches a walk whose PIDs wrapped. |
| G02, as G01 with the guard removed | **passes**: "started 1394 processes" | Without the guard, the PID difference alone would accept a per-directory walk after a wrap, so the guard is needed. |

Log: the first half of `fanout-count-mutants-f109af4.log`; the runner is `gmut.py`. `pid-max-per-namespace.txt` records the host's 32,768, a container's 4,194,304, a privileged container lowering its own to 32,768 while the host's stays, and the shared boot ID. `first-f01-run-host-pid-max.txt` holds, copied from the session transcript, the first F run, in which the test still read the host's value and the namespace passed PID 66,339.

### 4.3 The PR's tests as three identities

The same script as for `78bcce6` (`final-tests-f109af4.sh.txt`) ran in a fresh clone of `f109af4` per identity, each in its own mount namespace: `gofmt`, `go vet` (linux, and darwin/arm64) of `./es/app` and the root package, `bash -n` of the launchers, the PR's tests plus `TestSupportedLocalExecutionRoot.*`, and the docs tests.

| Identity | Result | Fan-out count |
| --- | --- | --- |
| 30033:30033, groups 30033 996, sudo | 111 pass, 0 fail, 0 skip; docs ok | 535 (14.6 s) |
| 31500:31600, groups 31600 996, no sudo | 105 pass, 0 fail, 6 skip (the sudo rows); docs ok | 537 (11.5 s) |
| 0:0 | 88 pass, 3 fail, 17 skip; docs ok | 536 (14.9 s) |

As root, the 3 failures are the known `TestSupportedLocalExecutionRoot*` ones, which fail the same way on trunk_dev, and the set of skips and failures is identical to the `78bcce6` run of report 23 (compared by name). `gofmt`, both `go vet` runs and `bash -n` are clean for every identity. Logs: `final-tests-f109af4-*.log`.

## 5. Audit items

- **O24-1:** closed by 3.1 and 3.2.
- No other item of audit 24 is touched. The scripts are byte-identical to `ab1fadb`, so the comparison with ARS (58 layouts), the stop tests, the full fan-out bring-up and the mutant results of reports 23 and 24 hold unchanged.

## 6. Limits

- The count needs a Docker daemon on the test's own kernel. A daemon in a VM (Docker Desktop) fails the test with that reason; the test already skips off Linux, and CI's runner has a local daemon.
- The bound allows up to one process per 32 directories. A walk that started a process per first-level shard directory (256 more) would still pass; that costs well under a second and is not the cost the audit was about.
- The count includes threads (each takes a PID). BusyBox's `sh`, `xargs` and `rm` start none.

## 7. Handover

Narrow re-audit of `ab1fadb..f109af4` by the audit-24 auditor. Then, if it accepts and the gate passes (CI green on the head, trunk_dev still `bc9fe36` or merged without conflict and re-gated), squash-merge PR #19 without David's review (test, script and doc changes only, per his messages of 2026-11-22 20:18Z and 20:22Z).
