# 28: Narrow re-audit of the PR #19 A26-1 fix (f109af4..f7dd85d)

Written by the independent audit thread "Audit bring-up running as the operator", 2026-11-23, 11:15Z to 11:36Z.
Read-only. Nothing was pushed, commented, reviewed, merged or changed on GitHub.

Target: the writer's `27-repair-pr19-a26-1.md`, which applies the fix that my audit 26 proposed for A26-1. A26-1 was that the full fan-out test could pass without counting anything when the probe missed the helper's PID namespace.

Evidence: `28-audit-pr19-a26-1-evidence/` (README and `SHA256SUMS.txt` there).

## 1. Verdict: ACCEPT

**A26-1 is closed.** The test now fails unless the probe really ran in the counted namespace, exactly once.
- f7dd85d's code is my tested fix, byte for byte. Only comment lines differ.
- Both ways of missing the namespace that passed at f109af4 now fail, as both of my users: renaming the probe's argument (V01, V02) and calling Docker by its full path (V03). They fail with "the probe did not run in the helper's PID namespace exactly once".
- A per-directory `ls`, subshell or pipeline still fails on the count (P01 to P03), and the wrap guard still catches a wrapped walk (W01).
- The real check still passes: 535 to 537 processes against a limit of 2,056.

**O26-1 is addressed.** The comment above `started` now says that Docker takes 5 or 6 PIDs per container start and per `docker exec`, which matches my measurement.

**Nothing else changed.**
- The commit touches only the test file.
- The scripts, `PLANS.md`, the docs contract and every other file have the same manifest entries as at f109af4 and ab1fadb.
- So audits 24 and 26 still hold for everything outside this test.

**Gate.**
- Manifest `28ff8942…62ec` against base `bc9fe36`, taken at the start and the end. It is byte-identical to the writer's, and trunk_dev is still `bc9fe36`.
- CI run 45160099898 is green, and its `es/app` run skipped nothing.
- Tests pass as ci (111/111) and as ci2 (105, plus 6 sudo skips).

No findings and no open observations.

## 2. Gate data

| Item | Result |
| --- | --- |
| Recipe `/opt/audit/v2.py` | sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every manifest run |
| Head | `f7dd85db6b72c23975abe75feae1a81c1a137fd2`, one commit on `f109af4` (audit 26) |
| Base | `bc9fe3619823245faf550db4bf1bc3e782fbd5a5` = `refs/heads/trunk_dev` at the start (11:15:05Z) and the end (11:32:24Z) |
| Upstream | re-pinned to `origin/trunk_dev` |
| Opening manifest (11:15Z) | `28ff89422330eac67e293511adf728173b5bb0feb7bf4095fd67cc80aa9562ec`, 13 files. Taken twice, byte-identical to each other and to the writer's `manifest-f7dd85d/m1.json`. Against f109af4's manifest, only the entry for `es/app/service_launchers_container_user_test.go` differs |
| Textual diff hash | `7330c07b…a3dd`, unchanged from f109af4, as the writer says. The tool's textual diff covers only tracked files, and this test file is new in the PR (`untracked` against the base), so its change shows only in its manifest entry |
| Closing manifest (11:32Z) | `28ff89422330eac67e293511adf728173b5bb0feb7bf4095fd67cc80aa9562ec` again, twice, byte-identical to the opening runs. `git ls-remote` at 11:32:24Z: the branch is `f7dd85d`, trunk_dev is `bc9fe36` |
| Writer's report | `27-repair-pr19-a26-1.md` sha256 `7026875e1ddda4381e47d874af325851d2a571b07e2d3f10854a00d29f204141`, as stated |
| Writer's evidence | `SHA256SUMS.txt` checks out (14 files) |
| CI on f7dd85d | "build, vet and test", run 45160099898, job 137642995023: success, 10:53:34Z to 11:10:16Z. It is the only check run, and there are no legacy statuses. The gate's `es/app` run "with nothing skipped" failed only on its two listed tests |
| Kind of change | test only: `es/app/service_launchers_container_user_test.go`, +23/−12 |

## 3. What I checked

### 3.1 The delta is my fix

- `git diff f109af4 f7dd85d` is byte-identical to the writer's `diff-f109af4-f7dd85d.patch`.
- I applied my own `fix_test` from `mutants25.py` (audit 26) to f109af4's test file and diffed the result against f7dd85d's file (`fix-vs-f7dd85d.diff`). Every differing line is a comment. The code is the same:
  - the wrapper records `x` in `$TEST_PID_NAMESPACE_JOINED` just before it execs the probe's `docker run`;
  - `joinProbe` sets `TEST_PID_NAMESPACE_JOINED=<bin>/joined`;
  - the test fails unless that file is exactly `x` and the count is at least 1.
- The new comments are accurate:
  - `joinProbe`'s comment names A26-1 and both ways a probe can miss the namespace;
  - the comment above `started` gives the 5-or-6 PID overhead (O26-1);
  - the test's header now says the test "also requires that the probe really ran there".
- The check fails closed. If the record is missing, for example because the variable is empty and the redirect fails, the test fails.
- If the probe ran twice, the record is `xx`, and the test fails as well. That would also break the launcher rows of `TestServiceLaunchersContainerUser`, which compare the exact sequence of Docker calls.
- The writer did not add the optional `PLANS.md` clause. That is fine: `PLANS.md` describes what the test pins, and this is a guard inside the test.

### 3.2 Tests on exact bytes

Trees from `git archive f7dd85d`, whose `scripts/` equal the ab1fadb tree's. `unit27.sh` is `unit25.sh` with only its header comment changed.

| User | Result | Fan-out count |
| --- | --- | --- |
| ci 1500:1600 (sudo) | 111 pass, 0 skip, 0 fail. vet, gofmt and `bash -n` clean. Docs: ok | 535 processes, 1,119 forks on the whole kernel, 10.2 s |
| ci2 1700:1700 (no sudo) | 105 pass, 6 skip (the sudo rows), 0 fail. vet, gofmt and `bash -n` clean. Docs: ok | 536 processes, 1,235 forks, 10.4 s |

### 3.3 My mutants on f7dd85d (`mutants27.py`)

`mutants27.py` is `mutants25.py` without the T rows, because those applied the fix that f7dd85d now contains. Only the fan-out test runs. The P and V rows ran as both users; the W rows ran as ci.

| Mutant | ci | ci2 | Logged (ci) | Audit 26 at f109af4 |
| --- | --- | --- | --- | --- |
| P00 unmutated | pass | pass | 537 processes (ci2: 536) | pass |
| P01 one `ls -A` per directory | caught | caught | 66,330, "one per 32 directories or more" | caught |
| P02 one subshell per directory | caught | caught | 66,330 (ci2: 66,329) | caught |
| P03 one pipeline per directory | caught | caught | 132,123 (ci2: 132,124) | caught |
| V01 the probe's `$0` renamed | **caught** | **caught** | "the probe did not run in the helper's PID namespace exactly once (wrapper record \"\", 5 processes counted)" | passed (count 5) |
| V02 V01 plus one `ls` per directory | **caught** | **caught** | same message, 5 counted | **survived** (A26-1) |
| V03 Docker by `/usr/bin/docker` plus one `ls` per directory | **caught** | **caught** | same message, 4 counted (ci2: 5) | **survived** (A26-1) |
| W00 helper `pid_max` lowered to 32,768, unmutated | pass | | 536 (671 forks) | pass |
| W01 W00 plus one `ls` per directory | caught by the guard | | "66471 processes were started on this kernel … (PIDs 19 before and 1415 after)" | caught by the guard |

The V rows' counts of 4 or 5 are only the second sample's own overhead, which is why the check needs the wrapper's record and not just a positive count. The writer's own run of these rows (`mutants25-pv-f7dd85d-*.log`) agrees, including a V03 count of 6.

## 4. Evidence

Listed in `28-audit-pr19-a26-1-evidence/README.md`. No key, certificate body, token or config file is included, and all fixtures are synthetic. A pattern scan for private-key headers, certificates, and Vault, JWT, GitHub, Anthropic and AWS token shapes found nothing.
