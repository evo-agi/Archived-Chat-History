# ES PR #19 audit addendum: narrow audit of head 07a422b

Addendum to `11-audit-pr19.md` (BLOCK `b98740e` on A11-1), which is left unchanged.
Requested by the coordinator on 2026-11-22 23:20Z. Written by the independent audit thread "Audit bring-up running as the operator", 23:21Z to about 00:50Z on 2026-11-23.
Evidence: `11-audit-pr19-addendum-evidence/` beside this file (`SHA256SUMS.txt` lists every file).

**Verdict for `07a422b`: BLOCK, on two low findings (A12-1, A12-2) that the requested kernel comparison found.**
- The manifest reproduces exactly. The delta is the repair plus a merge of `trunk_dev` `f9537a8`, which brought only PR #14's nine files.
- A11-1 is closed for the case I reported. Storage usable only through the `docker` group is now refused, both by the check alone and in bring-up, before ARS starts.
- The three new edge-case tests kill my survivors P32, P42 and P43. Of my 78 mutants, 72 are caught as ci and 70 as ci2. The survivors change only a message, cannot be reached through the scripts, or show four small test gaps (O-12-2).
- The new ACL, macOS and unreachable-path refusals are correct.
- On 24 layouts, the check agrees with the kernel's view of `1500:1600` with no supplementary groups, or is stricter, on 22. It passes two layouts where ARS cannot use its storage, and a third layout fails only inside the container:
  - **A12-1:** a directory between the index directory and a deeper storage root, which the container identity cannot search, while the caller reaches it through a supplementary group. This is the A11-1 pattern one level up. It contradicts the documented contract "can write every storage directory".
  - **A12-2:** an index file that someone else owns, in a sticky directory, where ARS's rename over the index fails. Also an index that is a symlink to a file outside its directory, which the container cannot see.
- All three fail closed, at ARS start or at the first index write, and grant nothing. They need non-default layouts: default bring-up and supported-local setup put the index next to the storage root. Each fix is small and stays in scope (section 6).

## 1. Audit target

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate`, draft PR #19 into `trunk_dev` |
| Topic branch | `claude/project-thread-a9tcoa-services-nonroot` |
| Head | `07a422b4afd124710bc0320df7029a853459ac3f`, also `refs/pull/19/head` (`git ls-remote` at the start and at the end) |
| Head tree | `c5c7365c9e0914aee2791afa317a059575b5b0e0`; parent `199305c` (merge of `63e1d34` and `f9537a8`) |
| Manifest base | `f9537a8680c24bf2108b95ed20ac3724e8939d3a` (PR #14) |
| `trunk_dev` now | `f62d0245e95e2b411be16511fc1bf9e1da727ce5` (PR #16, parent `f9537a8`); the branch update comes after this verdict, per the coordinator |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` before each run |
| Canonical manifest | `f259b876696a49417ca953e15381c97adabcbc9aaa7cf4f32c788d6db02fe3af`, upstream `origin/trunk_dev`, 11 paths, textual diff `da384acfc7827c0718186c4a7f4e9a3ae58271f82bc2a3c24dabb634624125da` |
| Writer report | `13-repair-pr19-a11-1.md`, SHA-256 `06482016da527581073423f23e97f092cf725dbc4201745da5ad3c35bfa10e83` (matches the coordinator's prefix and suffix); `13-evidence/SHA256SUMS.txt` checks OK |
| CI | PR #19 check run "build, vet and test" (run 45081257893) completed with success on this head |

Posture: read-only. No push, PR comment, review, edit or merge. No subagents.

## 2. Provenance

I took the manifest first, before reading the delta, following provenance §5.3. I used a clean clone with HEAD reset to `f9537a8`, the tip's bytes in the tree, and upstream `origin/trunk_dev`.
- Two opening and two closing runs are byte-identical: `f259b876…e3af`.
- They equal the reported value and the writer's copy `13-evidence/manifest-v2-services-07a422b.json`.
- The 11 paths are the PR's own: `01_bringup.sh`, the four launchers `02` to `05`, `control_plane.sh`, two test files, the runbook, `PLANS.md` and `configuration.md`.

## 3. Delta `b98740e..07a422b`

Three commits:
- `63e1d34` checks storage for the exact container identity.
- `199305c` merges `trunk_dev` `f9537a8`.
- `07a422b` refuses unreachable paths with a message.

**Scope.**
- The merge brought exactly PR #14's nine files: `.github/ci/*`, `.github/workflows/go.yml`, `go_toolchain_baseline.md`, `docs_contract_test.go` and three test files. All nine are byte-identical to `f9537a8`, and none overlaps the PR's 11 paths.
- No non-test Go file differs from `3a5f257` to `07a422b`.
- The writer's repair-diff hash `6c23f863…9f71` reproduces.

**What changed.** Seven files: `control_plane.sh`, `01_bringup.sh`, `02_start_ars.sh`, one test file and three docs.
- `verify_ars_storage_for_operator CONFIG UID:GID` takes the identity, which must match `^[0-9]+:[0-9]+$` (`re.fullmatch`). `02_start_ars.sh` passes `CONTAINER_USER`. `01_bringup.sh up` derives it through `control_plane_operator_user ARS` right after its trap, before `mkdir`, Docker, the image or storage.
- Access is now decided from each entry's `stat`, not `os.access`, in this order:
  1. UID 0 is allowed.
  2. If the UID owns the entry, the owner bits decide.
  3. If the entry is not owned and has an access ACL, it is refused. It is also refused when `os.getxattr` is missing, or when reading the ACL fails with anything other than ENODATA or ENOTSUP.
  4. Otherwise the group bits decide if the GID matches, and the other bits if not.

  Directories need write and search; files need read. The hint now names the identity and "shared through another group".
- A path the caller cannot reach or create is refused with its path, instead of a traceback. An index that is a directory is refused too.

## 4. The coordinator's questions

### 4.1 A11-1 is closed for the reported case

- **The check alone** (`storage-check-supplementary-group-07a422b.log`): storage `root:docker`, directories 0775, files 0640, and ci (1500:1600) is in `docker`.
  - As ci with its groups, the check refuses with "directory is not writable and searchable by your UID and primary group … hand it back with: sudo chown -R 1500:1600 …".
  - As 1500:1600 with `--clear-groups`, it refuses in the same way. At `b98740e`, the first of these runs passed.
  - Control: the same tree as `root:cigrp` (the primary group) passes, and the identity can read and write there.
- **In bring-up** (`bringup-group-storage-07a422b.log`, watcher log): the same `root:docker` 0775/0640 change was applied to the test's ARS storage before the check ran.
  - `01_bringup.sh up` stopped with that refusal and the `chown -R 1500:1600` hint, after the image step and before any service.
  - The container poller saw no service container (an empty containers log).
  - At `b98740e`, this run passed the check, ARS came up, and bring-up then failed on an HTTP 500.
- **The writer's new test** "storage usable only through a supplementary group refused" runs as ci, using `docker` as the supplementary group, and passes. It skips as ci2, which has no passwordless sudo.

### 4.2 The edge-case tests kill P32, P42 and P43

Each is now killed by exactly the new row aimed at it, as both users:
- P32 (relative index allowed) by "ARS relative index file refused".
- P42a (root-is-a-directory check removed) by "ARS storage root that is a file refused".
- P43 (walk errors ignored) by "ARS storage directory the check cannot list refused".

The repair added a second "is not a directory" branch, for an ancestor of the root that is a file. My P42b removes that branch and survives. The path is still refused, but as "cannot reach storage.root_dir as you: … (Not a directory)". This is message-only (O-12-2).

### 4.3 ACL and macOS refusals

- **ACL.**
  - `getxattr(path, "system.posix_acl_access")` is read only for entries the identity does not own, and any ACL leads to a refusal. The ACL's owner entry is the owner mode bits, so deciding owned entries by their owner bits matches the kernel.
  - Kernel layouts:
    - C12: an owned entry with an ACL passes, and the kernel allows it.
    - C13: an owned entry at 0555 with a named-user rwx entry and mask rwx is refused, and the kernel denies the write.
    - C11: an unowned entry with an ACL deny is refused, and the kernel denies it.
    - C10: an unowned entry with an ACL grant is refused. The kernel allows it, so this refusal is by design and documented.
  - ENODATA means no ACL. ENOTSUP/EOPNOTSUPP means the filesystem has no POSIX ACLs, so the mode bits rule. Any other error, such as EACCES through the test's hook, refuses.
  - Mutants Q17 to Q22 cover these branches (section 5).
- **macOS.**
  - Python's `os.getxattr` exists only on Linux, so on macOS every entry the identity does not own is refused with "this host cannot show whether it has an access ACL". This matches the docs.
  - The test "storage the identity does not own refused where ACLs cannot be read" simulates this by deleting `os.getxattr` through a `sitecustomize`. Mutant Q20 shows the test holds.
  - The fake-identity tests now pick the macOS refusal text off Linux (`testForeignIdentityDirectoryRefusal`), and the cases that need ACL reads skip there.
  - Not run on macOS. Inference: macOS extended ACLs on entries the operator owns are not read. Under Docker Desktop's file sharing, the Docker Desktop process does the access as the macOS user anyway.

### 4.4 Unreachable-path refusals

Each path case gives a one-line refusal with the path, and no traceback:
- A root the caller cannot reach (parent 0000).
- A missing root the caller cannot create (parent 0555).
- An index the caller cannot reach (directory 0600).
- An index that is a directory.
- A root that is a file.
- An entry the caller cannot reach (directory 0644).
- An unlistable directory (0300).

The writer's tests cover each case. Mutants Q23 to Q26 turn each case back into a traceback or a skip, and kernel layouts C14 and C15 agree.

All of these are evaluated as the caller, so they are stricter than needed when the caller cannot reach a path that the container could (see O-12-1). The message says so ("as you"), and following the hint fixes it.

### 4.5 Kernel comparison

`kernel_compare12.py` builds each layout. It runs the check the way bring-up does: as ci with its groups, for identity `1500:1600` (C17 runs as root for `0:0`). It then probes as `setpriv --reuid U --regid G --clear-groups`. The probe creates and removes a file in the index directory and in every directory under the root, reads the index and every file, and replaces the index the way ARS does (a temporary file renamed over it).

| Result | Layouts |
| --- | --- |
| Check passes, kernel allows | C01 owned; C02 primary-group share; C05 other class grants; C12 owned with ACL; C17 root identity; C22 index directory through the primary group; C23 setgid root with an inherited group (closes O-11-2 at the check level); C24 sticky index directory, index owned |
| Check refuses, kernel denies | C03 supplementary-group share (A11-1); C04 root-written leftover; C06 owner without write; C07 primary group class denies while other allows; C09 owner class denies while group allows; C11 ACL deny; C13 owner bits deny despite the ACL; C14 unreachable index; C15 root is a file; C16 root-owned index; C20 index readable only through a supplementary group; C21 index directory writable only through a supplementary group |
| Check stricter | C10 ACL grant (by design); C08 `root:docker` 0707/0604: the caller's `docker` group class denies the listing, while the identity gets the other class |
| **Check passes, ARS cannot use storage** | **C19** (A12-1): index `<base>/index.json`, root `<base>/data/ars-storage`, `<base>/data` `root:docker` 0770. Bring-up mounts only `<base>`; the identity cannot reach the root. **C18** (A12-2): index directory `root:root` 1777, index `root:root` 0644. The identity can create files and read the index, but renaming over the index fails with EPERM |

`container-probe-C18-C19-C25.log` repeats C18 and C19 inside a container from the audit image, with ARS's exact mounts from `control_plane_mount_specs` and `--user 1500:1600`:
- C19: `stat` of the storage root fails with "Permission denied".
- C18: `mv` over the index fails with "Operation not permitted".
- In both, the check passed.

It adds C25: an index that is a symlink to a file outside its directory. The check passes. In the container the index is "No such file or directory", because only the index directory is mounted.

### 4.6 `up` ordering (O-11-3)

Addressed: `01_bringup.sh up` derives the identity before `mkdir`, Docker or the image. The new bring-up test case "non-numeric identity refused before any effect" requires no Docker call, no bring-up directory and no storage root. Mutants Q28 and Q29 show it holds.

### 4.7 Docs

- The runbook, `PLANS.md` `GENERIC-SERVICE-LAUNCHER-USER-01` and `configuration.md` match the code for every entry the check evaluates, including:
  - root's exemption;
  - the ACL and non-Linux refusals;
  - "shared through another group";
  - unreachable paths.
- The exception is `configuration.md`'s statement that the check refuses unless the container's identity "can write every storage directory", which C19 contradicts (A12-1).

### 4.8 Bring-up on `07a422b` as ci (1500:1600)

| Run | Result |
| --- | --- |
| With `down` | PASS (62.5 s) |
| Keeping the workspace | PASS (23.2 s) |
| ARS, EGS, AGS and ES in both runs | every sample of PID 1 shows Uid 1500, Gid 1600, Groups 1600, and `Config.User` `1500:1600` |
| Kept workspace | 125 entries, all `1500:1600`, 0 root-owned |

## 5. Validation

| Check | Result |
| --- | --- |
| `go vet ./es/app`, `gofmt -l es/app scripts`, `bash -n` on each of the six scripts, as ci and ci2 | clean |
| `TestServiceLaunchersContainerUser`, `TestBringupUpChecksARSStorageBeforeStartingServices`, `TestESLauncherContainerUser`, `TestSupportedLocalExecutionRoot*` | ci (1500:1600, passwordless sudo, `setfacl` installed): 77 of 77 pass, 0 skips. ci2 (1700:1700, no sudo): 74 pass, 3 skips (the three sudo cases) |
| `go test . -run Doc` | ok as both users (intact trees) |
| A11-1 statically, and in bring-up | refused (4.1) |
| Kernel comparison, 24 layouts, plus 3 in a container | 22 agree or are stricter; C18, C19 and C25 pass the check but fail for ARS (4.5) |
| 78 mutants (`mutants12.py.txt`), each on a fresh copy, as ci and as ci2 | unmutated passes as both. ci: 72 caught, 6 survived. ci2: 70 caught, 8 survived; Q14 and Q17 die only in the sudo cases (O-12-2) |
| Bring-up as ci, 2 runs | PASS, 0 root-owned entries (4.8) |

Mutant coverage:
- **P01 to P43:** mutants11's intent, re-targeted at the new strings. P30, P35 and P42 are split into a and b.
- **Q01 to Q04:** identity parsing.
- **Q05 to Q07:** the root bypass.
- **Q08 to Q16:** permission classes.
- **Q17 to Q22:** ACL handling.
- **Q23 to Q27:** reachability.
- **Q28 to Q32:** identity wiring and the hint.

## 6. Findings

```text
AUDIT FINDING A12-1
Type / Severity: correctness of the storage check against its documented contract; low
Patch defect or pre-existing: patch defect. The gap existed at b98740e too. The A11-1 repair leaves it,
  because reaching the storage root is still decided with the caller's credentials.
Current contract: configuration.md: "refuses, before starting ARS, unless … the operator's UID and primary
  GID, without supplementary groups (the container's identity), can write every storage directory and the
  index directory and read every stored file"; report 13 §3 (the check matches the kernel).
Path: scripts/internal/control_plane.sh, verify_ars_storage_for_operator, os.stat(root) at the start, and
  the walk, which starts at the root. Also control_plane_mount_specs, which collapses the two read-write
  mounts into one when the index directory is an ancestor of the root.
Evidence: kernel-comparison-07a422b.log C19 and container-probe-C18-C19-C25.log. Index <base>/index.json,
  root <base>/data/ars-storage, root and index owned by 1500:1600, <base>/data root:docker 0770.
  ARS's only read-write mount is <base>. The check, run as ci (in docker), prints nothing and exits 0.
  In the container, as 1500:1600: "stat: can't stat '<base>/data/ars-storage': Permission denied".
  ARS's NewFilesystemStore stats the root at startup, so ARS exits there. That last step is from code
  reading; I did not start ARS on this layout.
Impact: a storage root nested two or more levels below the index directory, behind a directory that only
  a supplementary group (or a group ACL entry) lets the caller through, passes the check. ARS then fails at
  startup instead of the check's refusal and hint. Fails closed; no privilege. Default bring-up and
  supported-local layouts put the index next to the root and are not affected.
Required correction (in scope, scripts and tests only): when the index directory is an ancestor of the
  root, require search for the identity, with the same unusable() rules, on every directory strictly
  between them. Or refuse that layout outright. Add a test without sudo, for example fake identity
  4242:4343, an intermediate directory 0700 owned by the caller, a root 0777, files 0644, an index
  directory 0777 and an index 0644: refused.
Uncertainty: none on the check or the container. ARS's own failure is from code reading.
```

```text
AUDIT FINDING A12-2
Type / Severity: completeness of the storage check for what ARS does with the index; low
Patch defect or pre-existing: patch defect (the check was added in this PR); present since b98740e
Current contract: the runbook's "Before any service starts, bring-up checks ARS's storage and refuses
  unless: … the index file already exists, and your UID and primary group can write to its directory and
  read the file"; report 13 §3. ARS writes the index by renaming a temporary file over it
  (ars/index/fileindex.go), and reads it at startup through the index-directory mount only.
Evidence:
  (a) C18: index directory root:root 1777 (sticky), index root:root 0644. The check passes. The identity
      can create files there and read the index, but rename over the index fails with EPERM, both under
      setpriv and in the container ("mv: can't rename …: Operation not permitted"). C24 (same directory,
      index owned by the identity) passes and the rename works.
  (b) C25: the index is a symlink to a file outside the index directory. The check follows it and passes.
      In the container the index is "No such file or directory".
Impact: (a) ARS starts and reads the index. Its first index write then fails, an opaque runtime failure
  like A11-1, in a shared sticky directory where a colleague's file sits in place of the index. (b) ARS
  fails at startup with "open artifact index". Both fail closed; no privilege; non-default layouts.
Required correction (in scope): (a) when the index directory has the sticky bit, refuse unless the
  identity is UID 0 or owns the index file or the directory, as the kernel's sticky rule does. (b) refuse
  an index that is not a regular file under lstat, since ARS replaces it with a regular file anyway. One
  test row each; neither needs sudo (fake identity 4242:4343 with a caller-owned 1777 directory and a
  0644 index for (a); a symlinked index for (b)). Mention both in the runbook.
Uncertainty: none on the behaviour.
```

```text
OBSERVATION O-12-1 (stricter than needed; report only)
The check reaches and lists entries as the caller, so a path the caller cannot reach or list is refused
even when the container could use it. C08: root:docker 0707/0604. The caller's docker group class denies
listing, while 1500:1600 without docker gets the other class. C10: an ACL grant on an entry the identity
does not own (by design). The messages say "as you", and the printed chown fixes both.
```

```text
OBSERVATION O-12-2 (mutant survivors; test coverage)
Survive as both users:
  P42b  The ancestor-is-a-file branch removed. The refusal text changes to "cannot reach … (Not a
        directory)"; it is still a refusal with the path. Message only.
  Q01   re.match instead of re.fullmatch on the identity.
  Q04   The identity refusal removed, so a bad identity ends in a traceback.
        Q01 and Q04 cannot be reached through the scripts, because control_plane_operator_user
        validates the identity first. They match the writer's S44.
  Q07   The root bypass keyed on GID 0. No test pairs a nonzero UID with GID 0. An operator whose
        primary group is 0 would pass root-only storage under this mutant. A no-sudo row would pin it:
        fake 4242:0, caller-owned storage 0700, refused.
  Q22   The ACL read from the parent. The ACL test's root has children, so the refusal arrives one
        level down with the same text and hint. A row with an ACL on one blob file only would pin it.
  Q27   Walk directories with lstat. Only the root can be a symlink there, and no test uses a symlinked
        storage root. Bring-up allows one, because Docker resolves a bind source.
Survive as ci2 only:
  Q14 (always the other class) and Q17 (ACL ignored). Only the sudo cases kill them. PR CI runs those
  (the writer reports 0 skips on the runner). A no-sudo row would pin the group class on any host:
  fake 4242:<caller GID>, caller-owned storage 0770/0640, accepted.
Suggested, not blocking: add these rows in the A12 repair.
```

Status of earlier items:

| Item | Status at `07a422b` |
| --- | --- |
| A11-1 | Closed for the reported layout (4.1). A12-1 is a residual layout of the same pattern. |
| O-11-1 (P32, P42, P43 survived) | Closed: all three are caught (4.2) |
| O-11-2 (setgid storage not run) | The check passes and the kernel allows it (C23). Bring-up on setgid storage was not run. |
| O-11-3 (`up` ordering) | Closed (4.6) |

## 7. Sensitive material

The tests and fixtures are synthetic. No key, certificate body, token or config file is in the evidence. Private service logs stayed in the container, outside the evidence folder. A pattern scan of the evidence found nothing. It covered private-key headers, and Vault, JWT, GitHub, Anthropic and AWS token shapes.

## 8. Cleanup and effect status

- **Container-only artifacts** the audit created:
  - the trees `/home/ci/es12`, `/home/ci2/es12` and `/home/ci/es12g`. The failed group-storage run's workspace was gone by the end, because ci could delete it through its `docker` group. No root-owned entry is left in the three trees;
  - the fixtures under `/home/ci/kc12`;
  - the `acl` package, installed so the writer's ACL tests run.
- **Containers:** the kept run's services were removed with `docker rm -f`. No test container is left.
- **Effects:** no push, comment, review, edit, merge or branch change.
- **dockerd** had stopped again before the bring-up runs, and I restarted it.

## 9. Confidence and merge gate

| Area | Confidence | Basis |
| --- | --- | --- |
| Provenance | high | |
| A11-1 closure for the reported case | high | statically and in bring-up |
| ACL, macOS and reachability refusals | high | code, tests and mutants; macOS by simulation only |
| A12-1 and A12-2 | high on the check and the container; ARS's failure point from code reading | |

To reach ACCEPT:
1. Repair A12-1 and A12-2, with the test rows above.
2. Take a new base-pinned manifest. `trunk_dev` has moved to `f62d024`, so the branch update needs it anyway.
3. Run a narrow audit of that delta.

Final verdict: BLOCK
