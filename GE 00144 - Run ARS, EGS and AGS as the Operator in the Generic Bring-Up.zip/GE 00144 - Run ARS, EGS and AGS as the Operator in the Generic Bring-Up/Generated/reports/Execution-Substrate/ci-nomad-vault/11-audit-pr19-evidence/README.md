# 11-audit-pr19 evidence (ES PR #19, head b98740e)

Written by the independent audit thread "Audit bring-up running as the operator", 2026-11-22 22:12Z to about 22:35Z.
Every file here was produced in the audit's cloud container. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../11-audit-pr19.md`.

## Setup

- Same container, toolchain, pinned Nomad/Vault/SPIRE and audit image as `../05-audit-evidence/README.md`. The image is
  valid here because no non-test Go file differs between bede334, 3a5f257 and b98740e.
- Test users: `ci` = 1500:1600 (UID different from GID; groups cigrp, docker), `ci2` = 1700:1700 (also in cigrp).
- Trees from `git archive`: `/home/ci/es11` and `/home/ci2/es11` (b98740e), `/home/ci/es11base` (3a5f257),
  `/home/ci/es11i` (b98740e, intact, used for the docs test and the last two bring-up runs), and `/home/ci/es11sg` (copy for the
  group-only storage run). `/home/ci/es11` and `/home/ci/es11base` had their `.out` folder removed before the runs, which
  drops the tracked `.out/Dockerfile`. The bring-up path does not read it under the CONTROL_PLANE_DOCKERFILE override (the
  intact-tree runs pass the same way); only the root docs tests need it.
- `bringup_run11.sh` sets EXECUTION_PLATFORM_KEEP_TEST_WORKSPACE=1, so the test skips `down` and the services stay up after
  the run. Its `-containers.log` files therefore also list the still-running containers of earlier kept runs (different
  name hashes). Each run's `-ownership.txt` scans that run's kept workspace. `bringup_run11b.sh` keeps nothing and runs `down`.

## Files

| File | What |
| --- | --- |
| manifest-v2-open-b98740e.json, manifest-v2-close-b98740e.json | Base-pinned manifest at the start and the end: e3b956e9…02ac, equal to the reported value and the writer's copy |
| unit-tests-b98740e-ci.log, unit-tests-b98740e-ci2.log | vet, gofmt, `bash -n` on six scripts, the launcher/storage/up/ES/supported-local tests, and `go test . -run Doc`. The ci docs failure is the removed `.out/Dockerfile`; see docs-test-b98740e-ci-intact-tree.log |
| docs-test-b98740e-ci-intact-tree.log | `go test . -run Doc` as ci on the intact tree: ok |
| mutants11.py.txt, mutants11-uid1500-gid1600.log, mutants11-uid1700-gid1700.log | 43 mutants as ci and ci2: 40 caught, P32/P42/P43 survive |
| pr19_runs.sh.txt, bringup_run11.sh.txt, bringup_run11b.sh.txt | Bring-up runners |
| bringup-head-b98740e-run{1,2,3}*, bringup-head-b98740e-intact-{kept,with-down}* | Head: 5 of 5 PASS; ARS/EGS/AGS/ES PID 1 1500:1600 Groups 1600; kept workspaces all 1500:1600, 0 root-owned |
| bringup-base-3a5f257* | Base: PASS; ARS/EGS/AGS PID 1 Uid 0; 16 root-owned ARS entries (index, 5 blobs, 10 directories) |
| storage_check_groups.sh.txt, storage-check-supplementary-group.log | A11-1 statically: the check passes as ci (via group docker), refuses as 1500:1600 with no supplementary groups; that identity cannot read or write the storage |
| group_storage_watcher.sh.txt, group-storage-watcher.log, bringup-group-storage-b98740e*, ars-log-excerpt-group-storage.txt | A11-1 end to end: ARS storage made root:docker 0775/0640; no storage-check refusal; ARS healthy as 1500:1600; then HTTP 500 on the Vault blob and bring-up stops |
| ci-env.sh.txt | Environment of every run (`env -i` plus this file) |

## Sensitive material

The bring-up tests use synthetic fixtures. No key, certificate body, token or config file is copied here. The private service
logs stayed in the container. A pattern scan for private-key headers and Vault, JWT, GitHub, Anthropic and AWS token shapes
found nothing.
