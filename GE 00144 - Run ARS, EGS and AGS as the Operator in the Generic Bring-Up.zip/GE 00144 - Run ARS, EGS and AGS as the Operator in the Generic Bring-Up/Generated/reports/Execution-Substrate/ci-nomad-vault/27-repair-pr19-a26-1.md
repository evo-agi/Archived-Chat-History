# PR #19 repair of audit 26's A26-1: the fan-out test requires that the probe ran where it is counted

Report 27 of the CI Nomad/Vault track. It answers the coordinator's request of 2026-11-23 10:51Z: fix A26-1 in PR #19 with the auditor's tested change from `26-audit-pr19-o24-1.md`, push, get CI green, ask the same auditor for a narrow re-audit, then gate and merge.

Date: 2026-11-23. Repository: `evo-agi/Execution-Substrate`, draft PR #19. Evidence: `27-repair-pr19-a26-1-evidence/` next to this file, with `SHA256SUMS.txt`.

## 1. Outcome

| Item | Result |
| --- | --- |
| A26-1, the count can pass without measuring anything | **Closed with the auditor's change, unaltered in behaviour.** The `docker` wrapper appends one `x` to `<bin>/joined` just before it moves the probe into the helper's PID namespace. The test fails unless that file holds exactly `x` and the count is positive: "the probe did not run in the helper's PID namespace exactly once (wrapper record %q, %d processes counted), so the count measures nothing". |
| O26-1, the comment on the second sample | **Done.** The comment now says the count includes a few PIDs Docker takes in the namespace for the probe's container start and for the second sample (5 or 6 each with this runc). |
| Scope | One commit, `f7dd85d`, on `f109af4`. It changes only `es/app/service_launchers_container_user_test.go` (+23/−12): the wrapper line, the environment variable, the check, and comments. Scripts, `PLANS.md` and the docs contract are unchanged. I did not add the optional `PLANS.md` clause; the plan's sentence stays accurate without it. |
| Manifest | **`28ff89422330eac67e293511adf728173b5bb0feb7bf4095fd67cc80aa9562ec`** (`f7dd85d` against `bc9fe36`, 13 files). |
| CI | [run 45160099898](https://github.com/evo-agi/Execution-Substrate/actions/runs/45160099898) green on `f7dd85d` (10:53Z to 11:10Z). |

## 2. Target identity

| Field | Value |
| --- | --- |
| Branch | `claude/project-thread-a9tcoa-services-nonroot` |
| Head | `f7dd85db6b72c23975abe75feae1a81c1a137fd2` |
| Audited head | `f109af49d50c6c281c5b1cef0d56bbe287dbd338` (audit 26, ACCEPT with A26-1) |
| Commit since `f109af4` | `f7dd85d` "Require that the counted probe ran in the helper's PID namespace" |
| Base | `bc9fe3619823245faf550db4bf1bc3e782fbd5a5` (trunk_dev), upstream `origin/trunk_dev` |
| Manifest tool | `governed_execution_audit_patch_manifest_v2.py`, sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Manifest of `f7dd85d` against `bc9fe36` | `28ff89422330eac67e293511adf728173b5bb0feb7bf4095fd67cc80aa9562ec`, 13 files, textual diff sha256 `7330c07bd4f337003da42deccb89305cbe080e3779299298878063987b56a3dd` |
| Previous manifest (`f109af4`) | `e3f8032cc62f9a62f3c11c5d50453439d4b8e9774b9474439f9007e0e7eeb58c` |

Taken twice by the v2 recipe in one fresh clone; both runs byte-identical. Only the entry for `es/app/service_launchers_container_user_test.go` differs from the `f109af4` manifest. **The textual diff hash is unchanged, as expected:** the tool hashes `git diff HEAD` after `git reset --mixed` to the base, which covers tracked files only, and this test file is new in the PR, so it is untracked there. Its change is carried by its own entry (path, mode, sha256, size).

## 3. The change

`git diff f109af4 f7dd85d` (in the evidence as `diff-f109af4-f7dd85d.patch`) makes the auditor's three edits from `mutants25.py`'s `fix_test`, byte for byte:

1. In the wrapper, before `exec "$TEST_REAL_DOCKER" run --pid "container:$TEST_PID_NAMESPACE" "$@"`: `printf x >> "$TEST_PID_NAMESPACE_JOINED"`.
2. In `joinProbe`, the environment gets `TEST_PID_NAMESPACE_JOINED=<namespace.bin>/joined`.
3. Right after `started := pidAfter - pidBefore - 1`: fail unless `<namespace.bin>/joined` is exactly `x` and `started >= 1`.

Comments only, besides: the test's header says the test also requires that the probe really ran in the namespace; `joinProbe`'s comment says what it records and why (A26-1); the comment above `started` is the O26-1 correction.

## 4. Validation

### 4.1 The auditor's own rows on `f7dd85d`

The auditor's `mutants25.py` (copied unchanged from `26-audit-pr19-o24-1-evidence/mutants25.py.txt`) ran its P and V rows on a fresh clone of `f7dd85d`. The fix is now part of the tree, so the V rows test it directly; the T rows, which apply the fix themselves, no longer apply.

| Row | 30033:30033 (sudo) | 31500:31600 (no sudo) |
| --- | --- | --- |
| P00, unmutated | pass, 535 processes | pass, 536 processes |
| P01, one `ls -A` per directory | caught on the count (66,331) | caught on the count (66,330) |
| P02, one subshell per directory | caught on the count (66,330) | caught on the count (66,330) |
| V01, probe argument renamed | **caught**: "wrapper record \"\", 5 processes counted" | **caught**, same |
| V02, V01 plus one `ls` per directory | **caught**: "wrapper record \"\", 5 processes counted" | **caught**, same |
| V03, Docker by absolute path plus one `ls` per directory | **caught**: "wrapper record \"\", 6 processes counted" | **caught**: same, 5 counted |

Logs: `mutants25-pv-f7dd85d-uid30033-gid30033.log`, `mutants25-pv-f7dd85d-uid31500-gid31600.log`.

### 4.2 The PR's tests

The writer's per-identity script (`final-tests-f7dd85d.sh.txt`) ran as 30033:30033 on a fresh clone of `f7dd85d`: `gofmt`, `go vet` (linux, and darwin/arm64) of `./es/app` and the root package, `bash -n` of the launchers, the PR's tests plus `TestSupportedLocalExecutionRoot.*`, and the docs tests. **111 pass, 0 fail, 0 skip**; the docs tests pass; the fan-out test counted 536 (15.6 s). Log: `final-tests-f7dd85d-uid30033-gid30033.log`.

I did not repeat the whole set as 31500:31600 and as root. The commit changes only `TestARSStorageCheckScalesToARSFullFanOut`, which ran and passed as 31500:31600 in P00 above, and the rest of the file is byte-identical to `f109af4`, where both identities ran in report 25.

**A note on a wasted run.** My first attempt at 4.1 and 4.2, at 10:53Z, found the Docker daemon in this container stopped; it stops on its own here. Every Docker-backed test then skipped, and the runner reported the P and V rows as "survived". I discarded that run, restarted the daemon, and re-ran everything with a daemon check before each step. The logs in the evidence are from the re-run only.

## 5. Handover

Narrow re-audit of `f109af4..f7dd85d` by the audit-26 auditor. Then, if it accepts and the gate passes (CI green on the head, trunk_dev still `bc9fe36`, or merged without conflict and re-gated), mark PR #19 ready and squash-merge it without David's review (test, script and doc changes only, per his messages of 2026-11-22 20:18Z and 20:22Z).
