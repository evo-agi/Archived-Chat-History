# 11-audit-pr19 addendum evidence (ES PR #19, head 07a422b)

Written by the independent audit thread "Audit bring-up running as the operator", 2026-11-22 from 23:21Z.
Every file here was produced in the audit's cloud container. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../11-audit-pr19-addendum.md`.

## Setup

- Same container, toolchain (Go 1.26.5, `GOTOOLCHAIN=local`), audit image `execution-substrate/control-plane:audit-bede334`
  (still valid: no non-test Go changed from `3a5f257` to `07a422b`) and test users as in `11-audit-pr19.md`.
  - `ci` = 1500:1600 (groups cigrp 1600, docker 996). `ci` has passwordless sudo, so the writer's sudo cases run as ci.
  - `ci2` = 1700:1700 (groups docker, cigrp). `ci2` has no passwordless sudo, so those three cases skip as ci2.
  - Group `proj` = 1800, no members.
- The `acl` package (setfacl/getfacl) was installed for this audit so that the writer's ACL cases run.
- Trees from `git archive 07a422b`, with `.out` intact:
  - `/home/ci/es12` (ci);
  - `/home/ci2/es12` (ci2);
  - `/home/ci/es12g`, for the group-storage bring-up run.
- Every run starts with `env -i` and sources `ci-env.sh.txt` (ci) or `ci2-env.sh.txt` (ci2).
- dockerd was restarted at about 23:25Z.

## Files

| File | What |
| --- | --- |
| manifest-v2-open-07a422b-run1.json, -run2.json, manifest-v2-close-07a422b-run1.json, -run2.json | Base-pinned manifest (base f9537a8, upstream origin/trunk_dev) at the start and the end: f259b876…e3af |
| delta-b98740e-07a422b-scripts-docs.diff, delta-b98740e-07a422b-test.diff | The repair: scripts and docs, then the launcher test file |
| unit12.sh.txt, unit-tests-07a422b-uid1500-gid1600.log, unit-tests-07a422b-uid1700-gid1700.log | vet, gofmt, `bash -n` per script, the four launcher/bring-up test groups, `go test . -run Doc`: ci 77/77, 0 skips; ci2 74 pass + 3 sudo skips |
| storage_check_groups12.sh.txt, storage-check-supplementary-group-07a422b.log | A11-1 statically: `root:docker` storage refused as ci and as 1500:1600 without groups; `root:cigrp` control passes |
| group_storage_watcher.sh.txt, group-storage-watcher-07a422b.log, bringup-group-storage-07a422b*.log | A11-1 in bring-up: the test's ARS storage made `root:docker` 0775/0640; `up` refuses at the storage check, no service container |
| bringup_run12.sh.txt, bringup_run12b.sh.txt, pr19_runs12.sh.txt, pr19_runs12.out | Bring-up runner (with a container and ownership poller; 12 keeps the workspace, 12b runs `down`) and the orchestration script |
| bringup-head-07a422b-with-down*.log, bringup-head-07a422b-kept*.{log,txt} | Two ordinary bring-up runs as ci: PASS; PID 1 of all four services 1500:1600 with Groups 1600; kept workspace 125 entries, 0 root-owned |
| kernel_compare12.py.txt, kprobe12.py.txt, kernel-comparison-07a422b.log | 24 layouts: check (as ci for 1500:1600) against what `setpriv --reuid 1500 --regid 1600 --clear-groups` can do, including ARS's rename over the index |
| container_probe12.sh.txt, container-probe-C18-C19-C25.log | C18, C19 and C25 repeated in a container from the audit image with ARS's exact mounts and `--user 1500:1600` |
| mutants12.py.txt, mutants12-uid1500-gid1600.log, mutants12-uid1700-gid1700.log | 78 mutants (P01-P43 re-targeted, with P30, P35 and P42 split; Q01-Q32 for the repair), as ci and ci2: ci 72 caught, ci2 70 caught |
| ci-env.sh.txt, ci2-env.sh.txt | Environment of every run |

## Sensitive material

The tests and fixtures are synthetic. No key, certificate body, token or config file is copied here.
The private service logs stayed in the container. A pattern scan for private-key headers and Vault,
JWT, GitHub, Anthropic and AWS token shapes found nothing.
