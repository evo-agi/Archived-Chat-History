# PR #20 audit-16 repair: the owner rule's mode half is gated, and startup's mode requirement is stated (A16-1, A16-2)

Report 17 of the CI Nomad/Vault track. It answers three coordinator requests of 2026-11-23:
- 02:38Z: audit 16 of `b5cc7cb` is BLOCK. "Please repair the missing-test finding now (two surviving mutants change a directory's mode before the owner check; add tests that kill them, and review the other 10 survivors listed)… Report as 17-repair-pr20.md."
- 02:40Z: David picked "Keep refusing to start, and say so" for A16-2. "Docs + a test stating it, no product behaviour change; fold it into the same repair with the missing-test fix."
- 02:49Z, the specifics: a gating test for O10 to O12 (A16-1); PLANS.md, `capability_probing.md` and the runbook say that startup requires every mode, including the governed-mount modes, and that such a file system is refused although mount-free submissions would work; correct "every submission" at `PLANS.md:803-804` and `capability_probing.md:155-157`; pin it with a `bindfs --perms=o-rwx` test; name A16-3 in the same passage; take along A16-8 and A16-7; no product code change; new provenance; the narrow audit goes back to the same auditor thread.

Date: 2026-11-23. Repository: `evo-agi/Execution-Substrate`, draft PR #20. Evidence: `17-repair-pr20-evidence/` next to this file. `README.md` there names every file, and `SHA256SUMS.txt` lists them.

## 1. Outcome

| Item | Result |
| --- | --- |
| A16-1 (the mode half of the owner rule had no gating test) | Fixed by a test. Each case of `TestDirectoriesOpenedByNameNeverChangeOwningUser` now also runs in a child process under the mask `0077`, where ES creates the directory as `0700`, and requires `0700` after the refusal. A mode change before the owner check leaves `0750` and fails the test. O10, O11 and O12 are each caught at their own place, without a race (section 3.1). |
| The other 10 survivors | Reviewed one by one (section 3.2). Three are now killed by new tests: F2 and R9 (the owner check after an ignored owner change, for both kinds of probe file) and R13 (the link count of a retained file). The other 7 (F6, D1, R1, R2, R5, R6, R15) are checks that no fixture can reach on Linux without a race or a seam in product code. |
| A16-2 (David's decision: keep refusing to start, and say so) | Done, with no product change. PLANS.md, `capability_probing.md`, `implementation.md` and the bring-up runbook now say that the startup probe stages every mode a submission can need, including the governed-mount modes, and that ES therefore refuses a staging file system that cannot keep them although submissions without governed mounts would work there. The "every submission" claims are corrected. A new bindfs test pins the refusal and also shows a run without governed mounts staging on the same mount (section 3.3). |
| A16-3 | Named in the same PLANS.md passage (section 3.4). |
| A16-5 | Report 15's observation 3 is corrected here (section 3.4). No docs change was needed. |
| A16-7 | The swap stress test's header says its nested target is no longer reached. |
| A16-8 | PR #20's description no longer claims a re-observation before every effect (section 3.5). |
| Docs contract | `TestStartupProbeUseAgreementDocsContract` holds the new statements and keeps the two old "every submission" claims out. 8 docs mutants, 8 caught. |
| Product code | None. The delta changes tests, docs and the docs contract only (section 2). |
| Mutants | The auditor's own 55 mutants, rerun on the head: 44 of 55 caught by behaviour tests (38 at `b5cc7cb`), 4 more only by the typed inventories (R11, R12, B1, B2), and 7 survive (F6, D1, R1, R2, R5, R6, R15), each reviewed in section 3.2; the control O9 survives as it should (section 6.2). |
| CI | Run [45102745583](https://github.com/evo-agi/Execution-Substrate/actions/runs/45102745583) on `29254b1`: success. In `es/admission` only the two listed opt-in tests skipped, so the four new and changed tests ran, including every sudo and bindfs case (section 6.4). |
| Head | `29254b16dcacab051a9007377083881a2c1e9d7f` on `claude/project-thread-a9tcoa-setgid-probe`, draft [PR #20](https://github.com/evo-agi/Execution-Substrate/pull/20). Tree `63c71fac6d7c289187e10d486ce7e850e3707c94`. |
| Manifest | `acc563391546918df6ea945aaea4a03a43034cfe4dedcbf49c6e870e405acc7b`, against base `f62d024`, upstream `origin/trunk_dev`, 19 files. Taken twice from one fresh clone; the two runs are byte-identical. |

Nothing was merged.

## 2. Target identity

| | Value |
| --- | --- |
| Branch | `claude/project-thread-a9tcoa-setgid-probe` |
| Head | `29254b16dcacab051a9007377083881a2c1e9d7f` |
| Head tree | `63c71fac6d7c289187e10d486ce7e850e3707c94` |
| Parent | `b5cc7cb78d3e9f14b015403fcad5451da5957f75` (audit 16: BLOCK on A16-1, A16-2) |
| Base | `f62d0245e95e2b411be16511fc1bf9e1da727ce5` (trunk_dev, PR #16), unchanged since report 15 |
| Commits since `b5cc7cb` | one: `29254b1` "Tests and docs for the audit of the startup probe repair (A16-1, A16-2)" |
| Manifest tool | `governed_execution_audit_patch_manifest_v2.py`, sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Manifest recipe | umask 022; fresh `git clone --branch claude/project-thread-a9tcoa-setgid-probe`; HEAD checked to be `29254b1`; `git fetch origin trunk_dev`, checked to be `f62d024`; `git reset --mixed f62d024`; `git branch --set-upstream-to=origin/trunk_dev`; `python3 -I` the tool twice; `cmp` of the two outputs |
| Manifest | `acc563391546918df6ea945aaea4a03a43034cfe4dedcbf49c6e870e405acc7b` (`manifest-v2-pr20-29254b1.json`), 19 files, textual diff sha256 `2c2c9fe8571e821e44b8800f8616df272cb111ca6d39b33e1d49e6a6f5145d93` |

The manifest has 19 files, one more than report 15's 18: the new `es/admission/execution_roots_probe_file_checks_test.go`.

The delta for the narrow audit is `b5cc7cb..29254b1` (`delta-b5cc7cb-29254b1.diff`): 9 files, 257 insertions, 14 deletions.

| File | Change |
| --- | --- |
| `es/admission/execution_roots_owner_check_test.go` | A16-1: the masked child process and the `0700` requirement |
| `es/admission/execution_roots_probe_file_checks_test.go` | new: the retained-file identity table (R9, R13) |
| `es/admission/execution_roots_probe_refusal_reasons_linux_test.go` | two new bindfs tests: the ignored owner change (F2, R9) and A16-2 |
| `es/admission/execution_roots_probe_swap_stress_linux_test.go` | A16-7: comment only |
| `PLANS.md` | A16-2 and A16-3 |
| `.docs/system_overview/capability_probing.md` | A16-2 |
| `.docs/execution_lifecycle/implementation.md` | A16-2 |
| `.runbooks/system/v1_bringup.md` | A16-2, in the operator's terms |
| `docs_contract_test.go` | pins for the new statements, and the two old claims kept out |

No file under `es/admission` other than `_test.go` files changed, and no script or workflow changed.

## 3. The repair

### 3.1 A16-1: the mode half of the owner rule

The rule (`PLANS.md`, `STARTUP-PROBE-USE-AGREEMENT-01`) is that the startup probe, the claim of a run staging root and `stagingCustody.ensureDirectory` refuse a directory whose owning user is not already the roots' owning user, "before any owner or mode change". The test checked the owner and the error text only. A mutant that moves the `Fchmod` in front of the owner check, and leaves the `Fchown` behind it, passed.

The directory each case refuses is one ES has just created with mode `0750` (`stableStageDirMode`). Under the usual mask `022`, that creation gives `0750`, which is also the mode the `Fchmod` would set, so the test could not tell. Under the mask `0077`, the creation gives `0700`, and only an `Fchmod` can turn it into `0750`. So the test now requires mode `0700` after the refusal, and runs under that mask.

The mask is process-wide, so it is set only in a child process:
- `rerunTestUnderOwnerOnlyProcessMask(t)` re-executes the test binary for exactly this subtest (`-test.run '^Test…$/^subtest$'`), with `ES_TEST_OWNER_ONLY_PROCESS_MASK=1`. The child sets `umask(0077)` and runs the subtest's body. The parent returns once the child has finished.
- The parent fails if the child fails, and also if the child's output lacks `--- PASS: <the subtest's name>`, so a pattern that matches nothing cannot pass silently.
- The staging-directory case already reruns itself as root through `sudo`, which drops the environment. The root process therefore re-executes itself once more under the mask. Both levels show in the logs ("the same test as root:", then "the same test under the process mask 0077:").
- `requireCreatorOwned` became `requireUntouched`: it now requires the creator's owner and mode `0700`.

Each case still checks what it checked before: the refusal and its message, and that the owner did not change.

Proof that it gates (section 6.2, and `log-mutants-one-by-one-uid30033.log`): with O10, O11 or O12 applied, the test fails at the matching case with "has mode 0750 after the refusal, want 0700". The auditor's audit-only test did the same; I kept the auditor's approach (a mask), written into the existing test so that it runs in the gate as `runner` and, through `sudo`, as root.

### 3.2 The other survivors

Audit 16 counted 55 mutants (plus the control O9): 38 caught by behaviour tests, 5 more only by the typed source guardrails (O11, R11, R12, B1, B2), and 12 survivors. Two survivors were A16-1 (O10, O12). The other 10, each with what happened to it:

| Mutant | What it does | Now | Why |
| --- | --- | --- | --- |
| F2 | removes the owner re-check after the staged file's `Fchown` | **caught** | New `TestStartupProbeFileChecksRefuseAnOwnerTheFileSystemIgnores` calls `probeStagedFile` on a bindfs mount with `--chown-ignore --chgrp-ignore` and requires "staged file ownership is unavailable" |
| R9 | removes the owner check on retained files | **caught** | The same test calls `probeRetainedResultFile` and requires "retained result file ownership is unavailable"; the table test below checks owner and group too |
| R13 | removes the link-count check on retained files | **caught** | New `TestRetainedResultFileIdentityErrorNamesEachCheck`, a table over `retainedResultFileIdentityError` with crafted identities: a second link, a directory, a symbolic link, another device, another owning user, another group, another mode |
| F6 | removes the link-count check on staged files | survives | The check is inline in `probeStagedFile`. A file just created with `O_EXCL` has one link unless something links it in between. Killing it needs a seam or a race; I added neither to product code, which the request ruled out |
| D1 | removes the staged directory's device check | survives | The directory is opened with `RESOLVE_NO_XDEV`, so a directory on another device never opens. Unreachable without a mount race |
| R1, R2 | the collision rename accepts any error, or any outcome | survive | On Linux the kernel answers a no-replace rename onto an existing name with `EEXIST` before it asks the file system (A16-4). The free-name rename that follows refuses the same file systems, so the outcome is the same |
| R5, R6, R15 | no same-object check, no identity re-check, or neither, after the free-name rename | survive | They need a file system that changes a file's identity on rename. No fixture here does |

The 5 that only the typed guardrails caught: O11 is now caught by the behaviour test of A16-1 as well. R11, R12, B1 and B2 still are not, and cannot be: R11 drops the `Fchown` of a retained file, which already has ES's owner, and the roots' owner check refuses other owners first; R12 drops the `Fchmod`, and `0600` and `0640` are created exactly under the mask `022`; B1 and B2 drop one batch re-observation, and the next batch re-observes anyway. The control O9 moves the owner check after the first re-observation, still before any change, which is the order the rule asks for, so it survives as it should.

Why F2 and R9 needed a direct call: in a whole probe, the owner check of the probe directories refuses a file system that ignores owner changes before any file is created, so the file checks are never reached. The new test therefore calls the two file probes directly, in a directory on such a mount. The owner it asks for is one the file system will ignore: as root, `54321:54321`; as a non-root user, the user's UID with a supplementary group, because the kernel passes a group change on to the file system only for a group the owner is in. It skips as a non-root user without a supplementary group; the runner has one (`docker`).

### 3.3 A16-2: startup requires every staged mode, and the docs say so

David chose to keep the refusal. The bytes now say what was chosen:

- `PLANS.md` (`STARTUP-PROBE-USE-AGREEMENT-01`): "Startup therefore refuses an overlay whose layers are on different file systems, a file system that does not keep a mode staging or retention can need, and a results file system whose rename accepts no flags, instead of reporting ready while submissions or retentions fail. The staged modes include the `0755` directories and the `0644` and `0755` files that only submissions with governed mounts use, so ES also refuses to start on a staging file system that cannot keep those modes although submissions without governed mounts would work there. That is deliberate: ES starts only where every submission it accepts can be staged, rather than reporting ready and failing the submissions that have governed mounts."
- `capability_probing.md`: "refuses startup instead of failing submissions. Those modes include the ones only governed mounts use (`0755` directories, `0644` and `0755` files), so a staging file system that cannot keep them refuses startup even though submissions without governed mounts would work there."
- `implementation.md`: "The lists include the governed-mount modes (`0755` directories, `0644` and `0755` files), so startup refuses a staging file system that cannot keep them even when no submission would use governed mounts."
- The bring-up runbook (`v1_bringup.md`, what ES refuses to start on): "ES refuses such a file system even if your submissions never use governed mounts, because staging a governed mount needs `0755` directories and `0644` and `0755` files".

The two claims the audit quoted are gone: `PLANS.md` "instead of reporting ready while every submission, or every retention, fails" and `capability_probing.md` "refuses startup instead of failing every submission". The docs contract now forbids both strings and requires the new statements in all four files.

The new test, `TestStartupRefusesStagingThatCannotHoldGovernedMountModes`, uses the audit's fixture: staging on `bindfs --perms=o-rwx`, results in an ordinary temporary directory. It requires:
1. the startup probe to refuse with "staged 0755 directory mode is unavailable";
2. on the same roots, a run without governed mounts to work: re-observe the roots, claim a run staging root, stage the payload, the runtime-support binary and the workload trust material, and pass `revalidateBeforeHandoff`;
3. the first governed-mount directory (`mounts/00/contents`, mode `0755`) to fail in `ensureDirectory`.

So the test states both halves of the decision: ES refuses there, and a submission without governed mounts would have worked there. If the probe stopped staging the governed-mount modes, part 1 fails. If staging stopped needing them, part 3 fails.

### 3.4 A16-3 and A16-5

**A16-3** (a root ES whose staging file system gives new entries to another user, for example `bindfs --create-for-user`, worked before and is refused now). `PLANS.md` names it in the passage that states the owner rule: "Entries ES creates must therefore already belong to the roots' owning user, as retained result directories always required, so a root ES whose staging file system gives new entries to another user, for example a bindfs mount with `--create-for-user`, is refused although it started before this rule". The docs contract holds the sentence.

**A16-5** (report 15, observation 3, gave the wrong cause). Correction: with staging local and owned by another user, and results on a bindfs that forces that owner, a root ES started before the repair, and retention then failed at the rename (`invalid argument`, the no-replace rename on bindfs), not at the natural result directory as report 15 said. The audit's inference stands: on a forced-owner file system that supports the no-replace rename, that setup would have worked, and it is refused now. It is the case "a root ES on roots owned by another user is refused at startup", which `PLANS.md` already states, with its message. No docs change was needed for it.

### 3.5 A16-7 and A16-8

**A16-7.** The header of `execution_roots_probe_swap_stress_linux_test.go` now says: "Since the repair, the probe refuses roots that belong to another user at its first directory, before any owner or mode change. The "probe" target still races that directory. The "nested" target is no longer reached, so it passes without exercising the race." The test itself is unchanged and stays opt-in.

**A16-8.** PR #20's description said `probeNestedStagingDirectory` "re-observes the roots before each effect". It now says what the head does: the probe re-observes both roots once per batch of effects, 15 times per start; the effects inside a batch go through descriptors of directories the probe has just created and checked; `NewService` re-observes once more at the end. Report 15's same claim is corrected by this paragraph. The description also had "Refused now, instead of ES reporting ready while every Submit fails"; it now says "while submissions fail there", and names the governed-mount case and the owner rule's newly refused setup. The squash message is usually taken from the description, so this matters for the merge.

### 3.6 Audit items not changed here

- **A16-4** (no Linux test reaches the existing-name rename): unchanged. A seam around the rename call would be product code. A macOS run would reach it; none ran (section 8).
- **A16-6** (the bindfs pin is a version pin): not in this repair; the request did not include it, and the workflow is unchanged. The hardening the audit describes (download, compare a SHA-256 kept in the workflow, install; the same for `libfuse2t64`) fits a later CI change.
- **A16-9** (retention's modes have no list and guard like staging's): unchanged; a follow-up item.
- **A16-10**: covered by section 3.2.
- **A16-11** (model trailers): for the coordinator. This repair changes no product code; its commit carries the standard trailer of the model that wrote it.

## 4. Tests

| Test | File | What it pins | Runs where |
| --- | --- | --- | --- |
| `TestDirectoriesOpenedByNameNeverChangeOwningUser` (changed) | `execution_roots_owner_check_test.go` | A16-1: no owner and no mode change before the refusal, at the probe, the claim and `ensureDirectory` | every host; the staging-directory case needs root or passwordless `sudo` |
| `TestRetainedResultFileIdentityErrorNamesEachCheck` (new) | `execution_roots_probe_file_checks_test.go` | each check of a retained file's identity, by its message (R9, R13) | every host, every OS |
| `TestStartupProbeFileChecksRefuseAnOwnerTheFileSystemIgnores` (new) | `execution_roots_probe_refusal_reasons_linux_test.go` | the owner check after the owner change, for staged and retained probe files (F2, R9) | Linux with bindfs and passwordless `sudo` |
| `TestStartupRefusesStagingThatCannotHoldGovernedMountModes` (new) | same | A16-2: the refusal, the mount-free run that works, the governed-mount directory that fails | Linux with bindfs and passwordless `sudo` |

The runner has bindfs (installed by the workflow since report 15) and passwordless `sudo`, so all four run in the gate, and the gate fails if any of them skips itself, because none is listed.

## 5. Docs

`PLANS.md`, `.docs/system_overview/capability_probing.md`, `.docs/execution_lifecycle/implementation.md` and `.runbooks/system/v1_bringup.md`, as quoted in 3.3 and 3.4. `docs_contract_test.go`: `TestStartupProbeUseAgreementDocsContract` requires 6 new phrases (3 in PLANS.md, one in each other file) and forbids the two old claims, with a comment that names A16-2.

## 6. Validation

### 6.1 Container: three identities

All runs used trees archived from `29254b1` (`git archive`), checked identical to each other.

| Identity | New and changed tests | Whole `es/admission` | Docs contract | Static |
| --- | --- | --- | --- | --- |
| `ci` 30033:30033, groups 30033 996, passwordless sudo | all pass; each masked child passes, and the staging-directory case passes as root under the mask (`log-clean-run-uid30033.log`) | `ok`, 2 skips: the opt-in stress test and its helper | the three docs tests pass | `gofmt` clean; `go vet` and `GOOS=darwin GOARCH=arm64 go vet` clean for `es/admission` and the root package |
| `ci3` 31500:31600, groups 31600 996, no sudo | the table test and two owner cases pass; the staging-directory case and the two bindfs tests skip, as they say ("needs passwordless sudo") (`log-tests-uid31500.log`) | `ok`, 11 skips (sudo and opt-in) | pass | same |
| root | all pass, with the masked children (`log-tests-uid0.log`) | `ok`, 6 skips (non-root-only and opt-in) | not run as root | not run as root |

The `ci` run was taken inside a private mount namespace (`unshare --mount --propagation private`, then `su ci`), because PR #19's mutant run was starting Docker containers on the same host at the same time. Red-team O-1 and audit 16 both saw ES refuse when the host's mount table changes during a test; a private namespace keeps the host's later mounts out of the table ES re-observes, while the tests' own bindfs mounts (made through `sudo` in the namespace) are seen as usual. A first, earlier `ci` run outside such a namespace overlapped with other runs and showed two extra catches that I could trace to that noise (`log-mutants-targeted-noisy-uid30033.log`, kept, not counted).

### 6.2 Mutants

The auditor's `mutants.py.txt` (audit 16 evidence), unchanged, run by `mut17.py` as `ci` on fresh copies of the head tree, in the same private mount namespace. "Targeted" is the auditor's own list of behaviour tests plus the three new tests. The survivors were then run against the whole `es/admission` package, which includes the typed inventories.

The unmutated tree passes in both stages (`log-clean-run-uid30033.log`).

| Group (audit 16's names) | Mutants | At `b5cc7cb` (audit 16) | At `29254b1` |
| --- | --- | --- | --- |
| Owner check removed, moved after the owner change, or comparing with the wrong user | O1 to O8 | caught | caught |
| Mode change moved before the owner check | O10, O11, O12 | O10, O12 survived; O11 only by a typed guardrail | **all caught** by `TestDirectoriesOpenedByNameNeverChangeOwningUser` |
| Probe skips a staged mode; mode guards and lists | P1 to P7, G1, G2, L1 to L7 | caught | caught |
| Staged file and directory checks | F1 to F6, D1 to D5 | F2, F6, D1 survived | **F2 caught**; F6, D1 survive |
| Free-name rename, evidence file, collision target, device and mode checks on retained files | R3, R4, R7, R8, R10, R14 | caught | caught |
| Collision rename accepts any error or outcome | R1, R2 | survived | survive |
| Checks after the free-name rename | R5, R6, R15 | survived | survive |
| Owner and link-count checks on retained files | R9, R13 | survived | **both caught** |
| No `Fchown` or `Fchmod` on retained files; a batch re-observation removed | R11, R12, B1, B2 | only the typed inventories | the same: survive the behaviour tests, caught in the whole package by `TestAdmissionProductionHasOneResolverAndOneMaterializationPath` |
| Control | O9 | survived, as it should | survives, as it should |

Totals: 44 of the 55 mutants are caught by behaviour tests, 4 more by the typed inventories, 7 survive. Against the whole package, the 7 survivors and O9 still pass (`R15` was run on its own after the main run; the same log holds it).

One by one (`log-mutants-one-by-one-uid30033.log`, run on a tree whose `es/admission` files are the head's; it was synced before the docs edits), each new test against the mutant it is meant to kill:
- O10, O11, O12 against `TestDirectoriesOpenedByNameNeverChangeOwningUser`: each fails at its own case with "has mode 0750 after the refusal, want 0700";
- F2 against `TestStartupProbeFileChecksRefuseAnOwnerTheFileSystemIgnores`: "staged file probe = <nil>";
- R9 and R13 against the table test (R9 also against the bindfs test): the matching rows fail.

### 6.3 Docs mutants (`docmut17.py.txt`, `log-docs-mutants.log`)

8 mutants, each removing or reverting one new statement in the four docs, against `TestStartupProbeUseAgreementDocsContract`. The unmutated tree passes; all 8 are caught: restoring either "every submission" claim (D01, D05), dropping the governed-mount sentence from each of the four files (D02, D06, D07, D08), dropping "That is deliberate" (D03), and dropping the A16-3 clause (D04).

### 6.4 GitHub runner

Run [45102745583](https://github.com/evo-agi/Execution-Substrate/actions/runs/45102745583), job 137457076512, on `29254b1`: **success** (`ci-pr20-45102745583-job137457076512.log`).
- go1.26.5; "Build", "Vet" and "Vet for macOS" passed.
- "Install bindfs" installed `bindfs 1.14.7-1.1build2`, as pinned since report 15.
- "Check the test gate" (the gate's self-test) passed; the workflow did not change, so its SHA-256 in the self-test did not either.
- "Test": `ok execution-substrate/es/admission 59.363s`. Only the two listed tests skipped themselves in that package: the opt-in stress test and its attacker helper. So `TestDirectoriesOpenedByNameNeverChangeOwningUser` (with its masked children, and its staging-directory case as root through `sudo`), the table test and both new bindfs tests ran and passed as `runner`. The root package, which holds the docs contract, passed. The gate reported "41 tests skipped themselves, all of them listed".
- "Listed tests still fail": all 15 listed tests still fail on the runner, as the gate requires.

## 7. Observations for the narrow audit

1. **The child process re-runs one subtest.** Its pattern is built from `t.Name()` with each `/` turned into `$/^`, so special characters in a subtest name would need escaping. The three subtest names are plain words with underscores. The parent also requires the child to print `--- PASS:` for that exact name, so a pattern that matched nothing would fail, not pass.
2. **Under the mask, each case still checks what it checked.** For example `claimStagingCustody` creates the run staging root with `0750`, which is `0700` under `0077`, and then refuses it because its owner is not the foreign owner the case asks for, as before. The mask changes only what a mode change before the refusal would leave behind.
3. **The bindfs owner test calls internal functions directly.** It holds the file checks on their own, as the audit's survivors list asked, rather than through a whole probe that never reaches them (3.2).
4. **The A16-2 test keeps results on an ordinary directory.** That isolates the staging mode requirement. The audit's 8 cells crossed four results file systems; the docs statement does not depend on the results side.
5. **No product code changed**, so the probe's behaviour on every audited matrix cell is the same as on `b5cc7cb`.

## 8. Not run, limits

| Not covered | What stood in |
| --- | --- |
| macOS | `GOOS=darwin GOARCH=arm64 go vet`; the table test has no build tag and runs on any OS; the Darwin no-replace rename still was not exercised (A16-4) |
| A seam or race to reach F6, D1, R1, R2, R5, R6, R15 | the reasons in 3.2; adding a seam is product code, which the request ruled out |
| File systems other than bindfs that cannot keep `0755` or `0644` | the bindfs fixture; how common they are is unknown, as the audit says |
| The audit's matrices against this head | not needed for correctness: no product code changed |
| Remote Alpha host | nothing; excluded in this track |

## 9. Effects

Commit `29254b1`, pushed to `claude/project-thread-a9tcoa-setgid-probe` only. No force-push and no rebase. PR #20 stays draft; its description is updated (A16-8, the RT-1 wording, and an audit-16 section with the new head, manifest and CI). Nothing was merged, no live service was contacted, and the Linux box was not used. Scratch mounts and trees live in this container.

## 10. Handover

- Head `29254b16dcacab051a9007377083881a2c1e9d7f`, manifest `acc563391546918df6ea945aaea4a03a43034cfe4dedcbf49c6e870e405acc7b`, base `f62d024`, upstream `origin/trunk_dev`.
- Next: the narrow audit of `b5cc7cb..29254b1`, back to the auditor thread of audit 16, as the coordinator asked. Then David's review of PR #20, the first product merge.
- A16-6 (bindfs hash pin) and A16-9 (a retention mode list) are left as follow-ups; neither is in this delta.
