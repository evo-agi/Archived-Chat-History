# PR #20 repair: the startup probe agrees with staging and retention (RT-1, RT-2, RT-3)

Report 15 of the CI Nomad/Vault track. It answers the coordinator's request of 2026-11-23 00:29Z: report 14 says HOLDS WITH CAVEATS; "repair the race's new instance in this PR. Also fix the three older probe weaknesses in PR 20, since it's the same probe and the tests already exist, rather than carrying them over. Adopt the red-team's tests as permanent regression tests, with the red-team thread credited in the report. Merge trunk_dev f62d024 in (no rebase), get CI green, take the manifest with upstream pinned, report as 15-repair-pr20.md, and give me the head. A fresh audit of the delta follows, then David's review."

Date: 2026-11-23. Repository: `evo-agi/Execution-Substrate`. Evidence: `15-repair-pr20-evidence/` next to this file. `README.md` there names every file, and `SHA256SUMS.txt` lists them.

## 1. Outcome

| Item | Result |
| --- | --- |
| RT-1 (no file or other mode probed) | Fixed. Inside `nested`, startup now stages one entry of every mode staging uses: files `0600`, `0640`, `0750`, `0644`, `0755`, and a `0755` directory beside the `0750` ones. Each entry is held to staging's own checks (section 3.1). Staging refuses any mode outside that list, so a new mode cannot skip the probe. |
| RT-2 (no-replace rename not really probed) | Fixed. Startup renames a bundle-mode file twice with the no-replace rename: onto a name that exists, which must fail with `EEXIST`, and onto a free name, which must succeed and keep the same file. Only the second rename reaches the file system (section 3.2). |
| RT-3 (root ES gives away a directory opened by name), with the new instance | Fixed by rule, not by narrowing the window. Before any owner or mode change, ES requires that a directory it created and then opened by name already belongs to the roots' owning user. The rule covers both probe directories, which includes PR 20's new instance, and also the claim of each run staging root and `stagingCustody.ensureDirectory` (section 3.3). |
| Red-team tests | Adopted as permanent regression tests, unchanged except for their header comments. They were written by the red-team thread "Red-team the staging ownership check", on branch `claude/project-thread-suv0zx`, commit `93a0833`. I cherry-picked them as `c27c689`. All five pass on the head, and the stress test finds 0 swaps in 1000 rounds for each window. Before the repair the probe window was hit 20 times in 1000 (section 6.3). |
| New tests | `TestExecutionRootProbeNamesTheCheckThatRefuses` checks seven file-system setups. Each row requires the probe to refuse with the message of the check that should catch it, and also requires use to fail there. Before the repair, 6 of the 7 setups started ES and then failed at use. Two more tests run on every host without sudo or bindfs: one for the mode list and one for the owner rule (section 4). |
| trunk_dev | `f62d024` (PR #16) merged in, with no rebase, as `c50f36a`. |
| CI | Run [45094162628](https://github.com/evo-agi/Execution-Substrate/actions/runs/45094162628) on `b5cc7cb`: success. The runner now installs `bindfs` 1.14.7 (pinned), so the sudo and bindfs tests run with no unlisted skip (section 6.5). |
| Mutants | 33 mutants of the repair. 24 are caught by behaviour tests alone. The 9 survivors are equivalent, unreachable, or are caught only by the typed inventory guardrails (section 6.2). |
| Product code | Yes: `es/admission/execution_roots.go` and `es/admission/staging_custody.go`. This counts toward David's review, as PR 20 already did. |
| Head | `b5cc7cb78d3e9f14b015403fcad5451da5957f75` on `claude/project-thread-a9tcoa-setgid-probe`, draft [PR #20](https://github.com/evo-agi/Execution-Substrate/pull/20). Tree `9de2a9338f328704642b14d58a0b73a08385ab3c`. |
| Manifest | `9d277408770cc0cc07d9082ca8d36f1be981b9191dbd492872fb6faa1e571b4a`, against base `f62d024`, upstream `origin/trunk_dev`, 18 files. Taken twice from fresh clones; the two runs are byte-identical (section 2). |

Nothing was merged.

## 2. Target identity

| | Value |
| --- | --- |
| Branch | `claude/project-thread-a9tcoa-setgid-probe` |
| Head | `b5cc7cb78d3e9f14b015403fcad5451da5957f75` |
| Head tree | `9de2a9338f328704642b14d58a0b73a08385ab3c` |
| Base | `f62d0245e95e2b411be16511fc1bf9e1da727ce5` (trunk_dev, PR #16) |
| Previous audited head | `eb6eea9` (audit 13: ACCEPT; red-team 14: HOLDS WITH CAVEATS) |
| Commits since `eb6eea9` | `c27c689` red-team tests (cherry-pick of `93a0833`); `c50f36a` merge of trunk_dev `f62d024`; `259480a` the repair; `91a9865` group-check row and docs pin; `b5cc7cb` workflow comment |
| Manifest tool | `governed_execution_audit_patch_manifest_v2.py`, sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Manifest recipe | umask 022; fresh `git clone --branch claude/project-thread-a9tcoa-setgid-probe`; HEAD checked; `git fetch origin trunk_dev`; `git reset --mixed f62d024…`; `git branch --set-upstream-to=origin/trunk_dev` before each of two runs; `python3 -I` the tool; `cmp` of the two outputs |
| Manifest | `9d277408770cc0cc07d9082ca8d36f1be981b9191dbd492872fb6faa1e571b4a` (`manifest-v2-pr20-b5cc7cb.json`) |

For the delta audit, the diff that matters is `c50f36a..b5cc7cb`, which is the repair on top of the merge: 17 files changed, 923 insertions(+), 139 deletions(-). The diff `eb6eea9..c50f36a` is the red-team's tests plus trunk_dev's PR #16, and PR #16 touches no file of PR 20.

## 3. The repair

All three findings have the same root cause: the startup probe did less than use does. The probe now stages and renames the way staging and retention do, and holds each result to the checks that staging and retention themselves apply. The probe keeps its existing order, using descriptors, no-follow opens and a re-observation of both roots before every effect. It still runs 15 re-observations per start, as on `eb6eea9`, so the mount-churn rate (red-team O-1) does not get worse.

### 3.1 RT-1: one entry of every staged mode, with staging's checks

- `staging_custody.go` now has one list of the modes staging gives its entries (`stagedFileModes`, `stagedDirectoryModes`): files `0600` (payload), `0640`, `0750` (runtime-support binary), `0644` and `0755` (governed mounts); directories `0750` and `0755`. These are functions rather than package variables, because the post-freeze closure guardrail forbids mutable package globals.
- `writeFileWithHookAndParentMode` and `ensureDirectory` refuse any mode outside the list, with `staging file mode %04o is not proved by the startup probe` or `staging directory mode %04o is not proved by the startup probe`. A mode added to staging later fails that change's own tests until it is also in the list, and the probe reads the same list. This is the machine-enforced trigger the project's rule asks for.
- The probe (`probeStagedEntries`) creates a `directory-0755` directory and `file-0600` through `file-0755` inside `nested`. Each directory goes through `probeStagedDirectory`, which is the same create, open, owner check, chown, chmod and verify sequence as the staging probe directory and `nested` itself. Each file goes through `probeStagedFile`, which creates it with `O_EXCL`, changes owner and mode, and then applies staging's check (`staging_custody.go`, the per-file identity check): a regular file with one link, on the staging root's device, with the roots' owner and group, and the exact mode.
- Each refusal names the check that failed: `staged files report another device than the staging root`, `staged file mode 0750 is unavailable`, `staged 0755 directory mode is unavailable`, `staged file ownership is unavailable`. The nested directory's own refusal now names it the same way (`nested staging directory ownership is unavailable` / `mode is unavailable`), which also answers audit A13-5 and red-team O-4.

### 3.2 RT-2: the no-replace rename both ways, with retention's checks

- The old results-root probe file and its collision rename are gone. Retention's files are probed where retention puts them: inside the natural result directory that the probe already creates (`probeRetainedResultFiles`).
- It creates `bundle` (`0600`) and `evidence` (`0640`) through `probeRetainedResultFile`. That function applies retention's check: regular, one link, results device, roots' owner and group, and permission bits equal, compared the way retention compares them.
- It then creates `collision` and renames `bundle` onto it with the no-replace rename. A success is refused, as before. Any error other than `EEXIST` is now refused too: `no-replace rename onto an existing result name did not report it as existing`.
- Then it renames `bundle` onto the free name `renamed`. A failure is refused: `no-replace rename to a free result name is unavailable: <errno>`. This is the step that catches RT-2. Linux answers `EEXIST` for an existing destination before it asks the file system, so the first rename can never show whether the file system supports the flag (red-team 6, RT-2).
- Finally, the held descriptor and `renamed` must be the same object (`sameCustodyObject`), and `renamed` must still pass retention's check.

### 3.3 RT-3: never change the owning user of a directory opened by name

There is no system call that creates a directory and opens it in one step. Between `mkdirat` and the open by name, a user who may rename entries of the parent can put somebody else's directory in its place. A root ES then `fchown`s that directory to the roots' owner (red-team 6, RT-3; audit 13, A13-P1).

The repair removes the owner change for any directory ES did not create as the roots' owner. ES only ever needs to change the group of a directory it created, because the entries it creates must already belong to the roots' owning user. The startup probe requires that, and retained result directories, which ES never chowns, have always required it. So `requireOpenedDirectoryOwnedByRootsUser` runs after the open and before any `Fchown` or `Fchmod`, and refuses unless the directory's UID is already the roots' owning UID:

| Call site | Directory | Message |
| --- | --- | --- |
| `probeStagedDirectory` | staging probe directory (older window), `nested` (PR 20's new window), `directory-0755` | `<label> does not belong to the execution roots' owning user` |
| `claimStagingCustodyFromQualifiedRoot` | each claimed run staging root | `claimed staging root does not belong to the execution roots' owning user` |
| `stagingCustody.ensureDirectory` | each staging directory | `staging directory does not belong to the execution roots' owning user` |

The last two are beyond the red-team's two windows. The red-team named `ensureDirectory` as having RT-3's pattern without attacking it (red-team 8). The claim has the same create-then-open-by-name shape. With the owner rule in place, a swapped-in directory owned by anyone else is refused before ES touches it.

What is left is narrower. A swapped-in directory that the roots' owner already owns would still get the roots' group and the staged mode. That needs a parent the attacker may write to, plus a directory of the roots' owner that the attacker can move into it. The sticky rule stops that move out of a sticky directory, and a rename cannot cross file systems. The attacker gains no ownership from it. The precondition is roots writable by other users, which ES accepts today (red-team O-3, the custody design, outside this change). Observation 8 in section 7 records it.

The group may still change, as A6-3 needs. The kernel only lets a non-root process give a group it is in to a file it owns, and a root ES gives the roots' group only to a directory the roots' owner already owns.

### 3.4 What changes for an operator

Setups that now refuse at startup instead of failing later:

| Setup | Before | Now |
| --- | --- | --- |
| Staging on an overlay whose layers are on different file systems, without `xino` | ES ready; every Submit fails staging | `staged files report another device than the staging root` |
| Staging on a file system that fixes directory modes (for example `0750` for all) | ES ready; staging fails | `staged 0755 directory mode is unavailable` |
| Staging on a file system that strips execute bits from files | ES ready; runtime-support staging fails | `staged file mode 0750 is unavailable` |
| Roots on a file system that ignores group changes | refused at `nested` | refused one step earlier: `staging probe directory ownership is unavailable` |
| Results on a split-layer overlay | ES ready; every retention fails | `retained result files report another device than the results root` |
| Results on a file system that fixes file modes (for example `0640`) | ES ready; every retention fails | `retained result file mode 0600 is unavailable` |
| Results on a file system whose rename accepts no flags (FUSE without `RENAME_NOREPLACE`; by kernel source also NFS, CephFS, 9p, eCryptfs) | ES ready; every retention fails | `no-replace rename to a free result name is unavailable: invalid argument` |
| A root ES whose roots belong to another user | refused at the natural result directory, after chowning probe directories by name | `staging probe directory does not belong to the execution roots' owning user`, before any owner change |
| Staging local, results on a file system that forces the owner, root ES | ES ready; retention refuses at the natural directory | refused at startup at the same check |

No setup that works is newly refused. The red-team's prototype, which takes the same direction, kept all 638 of its AGREE-OK cells (red-team 7). I did not rerun the red-team's 2,048-cell matrix against this repair (section 8).

`.runbooks/system/v1_bringup.md` lists the new refusals for operators.

### 3.5 Leftovers

Fixtures stay retained under the existing no-uncertain-unlink rule. That means 13 entries per start instead of 6: 9 under the staging root (the probe directory, the symlink probe, `nested`, `directory-0755` and five files) and 4 under the results root (the natural directory, plus `evidence`, `collision` and `renamed` inside it). Each start uses a fresh random token, as before. `TestExecutionRootCapabilityProbeCoversBothConfiguredRoots` now checks the whole layout, including each mode.

## 4. Tests

Adopted from the red-team (header comment changed to say "written by the red-team and adopted with the repair"; the bodies are unchanged):

| Test | Finding | Needs | Before repair (`c27c689`) | Head |
| --- | --- | --- | --- | --- |
| `TestExecutionRootProbeAgreesWithStagingOnOverlayWithSeparateLayerFileSystems` | RT-1 | sudo | fails | passes |
| `TestExecutionRootProbeAgreesWithStagingWhenTheFileSystemFixesModes` (2 subtests) | RT-1 | sudo, bindfs, setfacl | fails | passes |
| `TestExecutionRootProbeAgreesWithRetentionWhenRenameRejectsNoReplace` | RT-2 | sudo, bindfs | fails | passes |
| `TestExecutionRootProbeHandsNoDirectoryToAnotherUser` | RT-3 | sudo | fails | passes |
| `TestExecutionRootProbeDirectorySwapStress` (opt-in) | RT-3 | root, `ES_PROBE_SWAP_STRESS_ROUNDS` | 20 of 1000 (probe), 0 of 1000 (nested) | 0 and 0 of 1000 |

New:

| Test | What it pins | Needs |
| --- | --- | --- |
| `TestExecutionRootProbeNamesTheCheckThatRefuses` (7 rows) | each setup in 3.4 is refused by the probe with that check's message, and use fails there too | sudo, bindfs |
| `TestStagingRefusesModesTheStartupProbeDoesNotProve` | `0700` directory, file and parent modes are refused with nothing created; every listed mode is accepted | nothing |
| `TestDirectoriesOpenedByNameNeverChangeOwningUser` (3 subtests) | the claim, `ensureDirectory` and the probe directory refuse a directory owned by another UID, with its owner unchanged | the `ensureDirectory` case reruns itself as root through sudo; the other two need nothing |

The red-team's agreement tests accept either direction: the probe may refuse the setup, or use may work in it. The new reasons test also requires the refusal to come from the check that should catch it. That matters for mutants: 9 of the 24 caught mutants are caught only by the reasons test (section 6.2).

Changed: the leftover test (full layout), the staging-conflict test (uses a listed mode), the typed inventory guardrails (new functions, call counts and the post-freeze closure), and the docs contracts.

CI (`.github`):
- `go.yml` installs `bindfs=1.14.7-1.1build2` before the test gate. The pin matters because the no-flags-rename fixture needs a bindfs without `RENAME_NOREPLACE`. The gate self-test holds the new workflow SHA-256.
- `environment-only-tests.txt` lists the opt-in stress test and its attacker helper as `skips-itself`, with the reason. `TestExecutionRootProbeHandsNoDirectoryToAnotherUser` gates the same rule without a race.

## 5. Docs

- `PLANS.md`: new `STARTUP-PROBE-USE-AGREEMENT-01` (bounded slice rule) after `NESTED-STAGING-OWNER-PROBE-01`.
- `.docs/system_overview/capability_probing.md`: the startup paragraph and the Tranche A list. The list keeps the pinned phrase "refuse the results no-replace publication primitive", now followed by the free-name half.
- `.docs/execution_lifecycle/implementation.md`: names `probeStagedEntries`, `probeRetainedResultFiles` and `requireOpenedDirectoryOwnedByRootsUser`.
- `.runbooks/system/v1_bringup.md`: the roots bullet lists the new refusals.
- `docs_contract_test.go`: new `TestStartupProbeUseAgreementDocsContract`, which also forbids the old one-sided rename sentence. The `NESTED-STAGING-OWNER-PROBE-01` contract's code pins follow the new call.

## 6. Validation

### 6.1 Container: three identities

The container runs and the mutants used trees archived from `91a9865`. The head `b5cc7cb` changes only the comment on the workflow's bindfs step and the self-test's SHA-256 of the workflow. No Go file changed, so those results carry over. The self-test's workflow group passes in the container on `b5cc7cb`; its other groups need go1.26.5, which the container lacks, and they pass on the runner (6.5). The stress test binary was built from `b5cc7cb`.

| Identity | `es/admission` targeted | Whole `es/...` | Root package |
| --- | --- | --- | --- |
| root | all pass; the two setgid tests skip because they need a non-root caller; the stress test is opt-in (`log-tests-uid0.log`) | not run as root | not run as root |
| `ci` 30033:30033, groups 30033 996, passwordless sudo | all pass, including every sudo and bindfs test (`log-tests-uid30033.log`) | fails only on the listed environment tests: 2 reliablesubmit historical probes and the es/app SPIRE/Vault setup | 32 failures, the same 32 tests as a clean `f62d024` in the same container as the same user (`log-rootpkg-base-f62d024-uid30033.log`); they depend on the host (Remote Alpha operator, retired tombstones, and generated-artifact hygiene, which needs `.git`, absent from an archived tree), and the docs contracts pass |
| `ci3` 31500:31600, no sudo | all pass; sudo tests skip, as listed (`log-tests-uid31500.log`) | same as `ci` | same 32 as `ci` |

`gofmt`, `go vet`, and `GOOS=darwin GOARCH=arm64 go vet` are clean for `es/admission` and the root package as both users.

### 6.2 Mutants (`mutants_pr20r.py.txt`, `log-mutants-uid30033.log`)

There are 33 mutants, each on a fresh copy, run as `ci`. The tests are the behaviour tests of the repair. The typed inventory guardrails are left out on purpose, so a mutant counts as caught only if behaviour changes. The unmutated tree passes.

Caught (24): M01 to M11, M14 to M16, M18 to M23, M27, M28, M30, M31. They cover every owner-rule site, removing each probe step, each device and mode check, each mode-list entry, each staging guard, the free-name rename, and the evidence file.

Survivors (9):

| Mutant | Why it survives |
| --- | --- |
| M12 staged-file owner check removed | Equivalent here: the probe has just chowned the file and checks the result. Kept as a guard against file systems that accept and ignore a chown; the directory row with a group-ignoring bindfs pins the same check for directories (M16, caught). |
| M13 staged-file link count check removed | A fresh `O_EXCL` file has one link; no fixture can give it two |
| M17 staged-directory device check removed | Unreachable: the open uses `RESOLVE_NO_XDEV`, so a directory on another device never opens |
| M24 collision rename accepts any error | No fixture returns an error other than `EEXIST` there; Linux answers `EEXIST` before the file system |
| M25, M26 no identity checks after the free-name rename | No fixture moves another file into place or changes it during a rename |
| M29 retained-file owner check removed | The natural result directory's owner check runs first and refuses every owner case a fixture can make |
| M32 no `Fchmod` on retained files | Equivalent under umask 022: `0600` and `0640` are created exactly |
| M33 the batch re-observation in `probeStagedEntries` removed | Only the typed re-observation inventory catches it; it changes no outcome a test can see |

Survivors M12, M13, M17, M24, M25, M26 and M29 are defensive checks that mirror staging's or retention's own checks, so that the probe accepts nothing that use would refuse.

### 6.3 Directory swap stress (RT-3)

`TestExecutionRootProbeDirectorySwapStress` was run as root with 1000 rounds.

| Tree | Probe directory window | `nested` window |
| --- | --- | --- |
| Before repair (`c27c689`, the red-team's tests on `eb6eea9`'s code plus trunk_dev) | 20 of 1000: "root gave another user's directory to the roots' owner" (`log-stress-1000-before-repair.log`) | 0 of 1000 in this run (the red-team measured 2 to 6 per 1000) |
| Head `b5cc7cb` | 0 of 1000 | 0 of 1000 (`log-stress-1000.log`) |

The deterministic form, `TestExecutionRootProbeHandsNoDirectoryToAnotherUser` and the three subtests of `TestDirectoriesOpenedByNameNeverChangeOwningUser`, gate the rule on every run without a race.

### 6.4 The gaps before the repair

The new reasons test was run against `c27c689`, the code before the repair (`log-reasons-before-repair-c27c689.log`). In 6 of its 7 rows the probe passed and use failed. In the seventh, the group-ignoring file system, it refused at `nested` rather than at the probe directory. Three of the six setups are beyond the red-team's matrix: results on a split-layer overlay, results with files fixed at `0640`, and staging files that lose execute bits.

### 6.5 GitHub runner

Run [45094162628](https://github.com/evo-agi/Execution-Substrate/actions/runs/45094162628), job 137430212947, on `b5cc7cb`: success (`ci-pr20-45094162628-job137430212947.log`).
- "Install bindfs" installed `bindfs 1.14.7-1.1build2` and `libfuse2t64`.
- "Check the test gate" passed. That step runs the gate self-test, which holds the new workflow SHA-256, on go1.26.5.
- "Test": `ok execution-substrate/es/admission 93.632s`. Only the two listed tests skipped themselves in that package: the opt-in stress test and its attacker helper. So every sudo and bindfs test ran and passed as `runner`, including the seven-row reasons test and the four adopted agreement tests. The gate reported "41 tests skipped themselves, all of them listed".
- "Listed tests still fail": all 15 listed tests still fail on the runner, as the gate requires.

The runs on `259480a` (45092683145) and `91a9865` (45093235465) were cancelled by the next push. The container showed `259480a` failing one docs pin, which `91a9865` fixed.

## 7. Observations for the delta audit

1. **Scope beyond the request.** The owner rule also covers the claim of each run staging root and `ensureDirectory` (3.3). The red-team named `ensureDirectory` as having the pattern; the claim has the same shape. Fixing only the two probe windows would have left the same race at submission time.
2. **Newly refused: a root ES on roots owned by another user, at startup.** It was already refused later at the natural result directory, after the race window. It is now refused before any owner change. A root ES with roots owned by root is unaffected.
3. **Newly refused: staging local with results on a forced-owner file system, under a root ES.** This used to start, and then retention refused.
4. **Leftovers grow from 6 to 13 entries per start** (3.5).
5. **`probeStagingCustodyCapabilities` still has the old one-sided collision rename.** It lives in `staging_custody.go`, but only tests call it, so it is not on a production path. I left it alone so the delta stays bounded; it can follow the probe if the auditor wants that.
6. **Darwin.** The repair uses the same platform wrappers on both systems. The Darwin build is vetted, but the Darwin no-replace rename (`renamex_np` with `RENAME_EXCL`) was not run (section 8).
7. **`EEXIST` only.** The collision rename now requires exactly `EEXIST`. A file system that reports something else for an existing destination, while honouring the flag, would be refused. I know of none on Linux, because the VFS answers before the file system. On Darwin, the wrapper uses `renameatx_np` with `RENAME_EXCL`, which documents `EEXIST`.
8. **The residual of RT-3 under roots writable by other users** (end of 3.3). It is the same residual any process has when it works in a directory others can write to, and it gives the attacker no ownership. Refusing such roots would be a custody-design change, red-team O-3.

## 8. Not run, limits

| Not covered | What stood in |
| --- | --- |
| macOS | `GOOS=darwin go vet`; the Darwin wrappers are unchanged |
| Remote Alpha host | nothing; excluded in this track |
| The red-team's 2,048-cell matrix against this repair | the red-team's prototype result for the same direction, plus the 7-row reasons test and the 5 adopted tests |
| Real NFS, CephFS, 9p, CIFS | bindfs fixtures |
| SELinux, quotas, full file systems | nothing |
| Nomad, Docker, Vault with a real workload | hermetic Submit and retention in the tests |

All rates come from one machine.

## 9. Effects

Commits `c27c689`, `c50f36a`, `259480a`, `91a9865` and `b5cc7cb`, pushed to `claude/project-thread-a9tcoa-setgid-probe` only. No force-push and no rebase. PR #20 stays draft; its body is updated with a red-team repair section. Nothing was merged, no live service was contacted, and the Linux box was not used. The red-team's branch `claude/project-thread-suv0zx` was read, not changed. Scratch mounts and trees live in this container.

## 10. Handover

- Head `b5cc7cb78d3e9f14b015403fcad5451da5957f75`, manifest `9d277408770cc0cc07d9082ca8d36f1be981b9191dbd492872fb6faa1e571b4a`, base `f62d024`, upstream `origin/trunk_dev`.
- Next: a fresh audit of the delta `c50f36a..b5cc7cb` (Fable, per the model rule for ES product code), then David's review, the first product merge.
- Credit: the red-team thread "Red-team the staging ownership check" found RT-1 to RT-3 and wrote the five adopted tests and the stress harness (report 14, branch `claude/project-thread-suv0zx`, commit `93a0833`).
