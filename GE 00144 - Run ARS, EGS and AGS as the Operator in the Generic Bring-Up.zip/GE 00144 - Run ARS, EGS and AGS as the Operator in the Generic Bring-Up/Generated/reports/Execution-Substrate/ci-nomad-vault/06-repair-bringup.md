# ES PR #18: repair of audit findings A5-1 to A5-3, and update onto trunk_dev

Report 06 of the CI Nomad/Vault track. Follows the PR #18 audit `05-audit.md` (ACCEPT for `bede334` with three low findings, SHA-256 `bfce8f15626ccf4c850a65be01cd84d093f03d7c06a5488b11504369d5a44bb8`) and the coordinator's request of 2026-11-22 20:43Z: fix A5-1, A5-2 and A5-3, update the branch onto trunk_dev `b8d6bc3` by merge, show it green on the runner, write a new manifest, then hand over for a narrow audit.

Date: 2026-11-22. Repository: `evo-agi/Execution-Substrate`. Evidence: `06-evidence/` beside this file (`SHA256SUMS.txt` lists every file).

## 1. Outcome

| Item | Result |
| --- | --- |
| A5-1 (test blind to a UID/GID mix-up when UID equals GID) | **Fixed.** The launcher test also runs the launcher with a fake `id` that prints UID 4242 and GID 4343. M05, M06 and M07 of the audit now fail the test on a host whose UID equals its GID (30033:30033) as well as on one where they differ (31500:31600), and on the GitHub runner (1001:1001) the test passes. |
| A5-2 (docs named the wrong gate on remapped daemons) | **Fixed** in the script comment, `PLANS.md`, `contracts.md`, `capability_probing.md` and the runbook. Checked on a `--userns-remap=default` daemon: Docker refuses `docker run --network host` with "cannot share the host's network namespace when user namespaces are enabled", and bring-up's own host-loopback check, which runs before any service, fails on it. Rootless is now called untested and unsupported for bring-up, with no claim about which check refuses. |
| A5-3 (runbook ownership requirement incomplete) | **Fixed.** The runbook lists the three things ES needs as the operator: roots owned by the UID and the primary group, the retained-result key owned by the operator (mode `0400` or `0600`, outside both roots), and every file the ES config names readable without supplementary groups. `contracts.md` and `PLANS.md` say the same in one sentence each. |
| Also fixed | O-2: the launcher now refuses unless `id -u` and `id -g` print numeric IDs, so an empty UID can no longer turn into `--user :GID`, which Docker runs as root. O-4 ("ES's startup checks", not "the natural-directory probe alone"). O-5 (the profile sentence in `contracts.md` names `service-root-v1` and no longer sits after the generic-launcher text). O-7 is corrected in section 6 of this report; `04-bringup.md` is left unchanged because the audit recorded its hash. |
| Update onto trunk_dev | Merge commit `f5510db` (parents `008f4d7` and `b8d6bc3`), no rebase, no force-push. No conflicts: #17 touched three other files. |
| Runner | Probe run 45069185789 on `31ddbfd` (= `f5510db` plus one workflow file): see section 4. |
| New manifest | `4d6d2c1c9008dda3bfa93fec17d46b61d3a8a5f0780ee0c1a36d42b95c2e16d1`, base `b8d6bc3`, 8 files (section 2). |

Nothing was merged. PR #18 stays a draft.

## 2. Target identity

| Field | Value |
| --- | --- |
| Base | `trunk_dev` at `b8d6bc3abb8c8c38481c7835824bd79ba26e467b` (PR #17's squash merge) |
| Topic branch | `claude/project-thread-a9tcoa-bringup` |
| Tip | `f5510dbbeb9ee4cb4af21347fa3dac8c1d00b65f` (`git ls-remote` after the push) |
| Commits since the audited `bede334` | `008f4d7` (the repair, parent `bede334`) and `f5510db` (merge of `b8d6bc3`) |
| Tree | `e3149ba15200e2c97433235c857df76fd0aadf82`, equal to `git merge-tree --write-tree 008f4d7 b8d6bc3` |
| Draft PR | [#18](https://github.com/evo-agi/Execution-Substrate/pull/18) into `trunk_dev`; GitHub reports 8 files, +289 −7, mergeable state clean |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` before the runs |
| Base-relative manifest | `4d6d2c1c9008dda3bfa93fec17d46b61d3a8a5f0780ee0c1a36d42b95c2e16d1`, HEAD `b8d6bc3`, upstream `origin/trunk_dev`, 8 files (7 `tracked_modified`, 1 `untracked`: the launcher test), textual diff `101630ff4be58499207e29e8c38c41d946e068e204ec95cf37f9586c75e6d85f`. Taken twice in a fresh clone from GitHub after the push (`git reset --mixed b8d6bc3` from the tip), byte-identical (`cmp`). Copy: `06-evidence/manifest-v2-bringup-f5510db.json` |

**What the merge changed in the PR's bytes: nothing.** For each of the 8 paths, the blob at `b8d6bc3` equals the blob at `ae326b0` (the new test file is absent in both), and the blob at `f5510db` equals the blob at `008f4d7`. So the PR diff against the new base is exactly the audited `bede334` content plus the repair commit `008f4d7`. The narrow audit therefore needs only `git diff bede334 008f4d7` (7 files, +127 −47; copy `06-evidence/repair-bede334-008f4d7.diff.txt`).

## 3. The repair (`008f4d7`)

### 3.1 A5-1 and O-2: script and launcher test

`scripts/05_start_es.sh`:

- The identity block moved above `ensure_control_plane_image`, so the IDs are read before any image build, root creation or container call.
- It reads `ES_CONTAINER_UID="$(id -u)"` and `ES_CONTAINER_GID="$(id -g)"` as two plain assignments, so a failing `id` stops the script under `set -e`.
- It refuses with "cannot run ES as the operator: id -u and id -g must print numeric IDs, got %q and %q" unless both match `^[0-9]+$`. Bash 3.2 handles the unquoted `=~` pattern the same way.
- The comment now says "UID and GID", "effective UID and primary GID", "no supplementary groups", and the A5-2 wording (section 3.2).

`es/app/es_launcher_container_user_test.go`, now six subtests:

| Subtest | What it pins |
| --- | --- |
| generic path with the caller's IDs | the real `id`, as before |
| generic path with a UID different from the GID | fake `id`: `--user 4242:4343` in the executed and in the printed command |
| service-root-v1 profile | no `--user`, and no `id` call at all |
| empty UID refused | refusal text, no `docker` call, no container, no roots created |
| group name with a digit refused | `staff1` as the GID: catches an unanchored pattern |
| failing id refused | `id -u` exits 1: the launcher stops after that one call |

The fake `id` logs every call to the same event file as the fake Docker daemon, so each subtest pins the exact sequence: `id -u`, `id -g`, `docker image`, `docker rm`, `docker run` for the generic path. That also pins "IDs before any effect". It answers only `-u` and `-g` and exits 96 for anything else, as the audit suggested.

**Mutants** (`06-evidence/mutants.py.txt`): the audit's 18, adapted to the repaired script, plus 9 new ones (M05b, M07b, M19 to M25) for the numeric check and the ordering. Each was run against a fresh copy as two users:

| Result | As `ci` 30033:30033 (UID = GID, like the runner) | As `ci3` 31500:31600 |
| --- | --- | --- |
| Caught | 25: M01 to M16, M05b, M07b, M19 to M25 | the same 25 |
| Survived | M17 (profile tested by value, equivalent because every other value is refused first), M18 (unquoted expansion, equivalent because the words have no spaces or glob characters) | the same 2 |

M05, M06 and M07, which survived at UID = GID in the audit, are caught by the 4242:4343 subtest on both hosts (`mutants-uid30033-gid30033.log`, `mutants-uid31500-gid31600.log`). M08 (`id -ru`) was equivalent in the audit and is now caught, because the fake `id` answers only `-u` and `-g`; I accept that strictness, like the test's fixed argument order. M24 (identity block after root creation) is caught by both the event order and the refusal subtests' "no roots created" check. M25 (`id -u` failure ignored and only the GID checked, the `--user :GID` root path) is caught.

### 3.2 A5-2, O-4, O-5: docs

All five places now say the same thing: on a user-namespace-remapped daemon, Docker refuses the host networking that bring-up needs, so ES does not start, and rootless Docker is untested and unsupported for bring-up.

- `scripts/05_start_es.sh` comment.
- `PLANS.md` `GENERIC-ES-LAUNCHER-USER-01`: also "bring-up stops at its host-loopback check", and "ES's behavioral startup checks stay the only capability gate".
- `.docs/execution_lifecycle/contracts.md`: the profile sentences stay together and the second one now begins "The `service-root-v1` profile does not alter ..." (O-5); the generic-launcher paragraph follows them. This is the one pre-existing sentence the repair edits ("This profile" became "The `service-root-v1` profile").
- `.docs/system_overview/capability_probing.md`: "ES's startup checks, not the launcher, decide whether that identity owns the roots and can read the files its config names" (O-4), plus the remapped-daemon sentence.
- `.runbooks/system/v1_bringup.md`: the remapped-daemon note moved to the host-loopback bullet, where bring-up actually stops, with Docker's message quoted.
- `.docs/execution_lifecycle/implementation.md`: "with no supplementary groups", and "roots that carry another group fail it".

**Evidence for the claim** (`06-evidence/userns-remap.log`, script `userns_check.sh.txt`): Docker 29.10.0 restarted with `--userns-remap=default` (security options `name=seccomp,profile=builtin name=userns`), alpine 3.20 pulled by digest, then as `ci3` (31500:31600): `docker run --rm --network host --user 31500:31600 … id` exits 125 with "cannot share the host's network namespace when user namespaces are enabled", and `probe_control_plane_host_loopback` from the repaired tree exits 1 with "slice-0 requires Docker host networking that can reach host loopback from a container; current host does not provide that capability". `scripts/01_bringup.sh up` calls that probe before `verify_es_staging_invariant` and before starting ARS (`scripts/01_bringup.sh:223`). The remapped daemon was stopped afterwards.

### 3.3 A5-3: runbook

The ES bullet of `.runbooks/system/v1_bringup.md` now says ES runs as "your numeric UID and primary GID (what `id -u` and `id -g` print), with no supplementary groups", and that ES refuses to start unless:

- the staging and results roots are owned by your UID and your primary group (a shared project group or the group a setgid parent hands down is refused), which is `es/admission/execution_roots.go:575` comparing both IDs;
- the retained-result key file is owned by you, has mode `0400` or `0600` and sits outside both roots (`es/admission/result_auth.go:45-59` for the parent, `:106-111` for the file; `es/config/config.go:536` for outside the roots);
- the ES config file and every other `*_file` it names are readable by your UID or primary group (the launcher mounts each read-only, `scripts/internal/control_plane.sh:165-174`).

The last point is reasoned from file permissions and Docker's behaviour, as in the audit; I did not run a root-only TLS key case.

## 4. Runner run

Probe branch `claude/project-thread-a9tcoa-bringup-probe`, recreated (the earlier probe branches are gone from GitHub) as `31ddbfd` = `f5510db` plus `.github/workflows/probe-bringup.yml` (copy `06-evidence/probe-workflow-31ddbfd.yml.txt`; `git diff --stat f5510db 31ddbfd` lists only that file). GitHub-hosted `ubuntu-24.04`, pinned Nomad 2.1.1, Vault 2.2.2, SPIRE 1.14.4, images by digest, `AWS_EC2_METADATA_DISABLED=true`.

Overall: **success** (job 137352085131, runner image `ubuntu-24.04` 20261116.376.1; log `06-evidence/runner-run-45069185789-job-137352085131.log`).

| Step | Result |
| --- | --- |
| `gofmt -l es/app`, `go vet ./es/app`, `bash -n scripts/05_start_es.sh` | clean |
| `TestESLauncherContainerUser` and the 7 `TestSupportedLocalExecutionRoot*` tests as `runner` 1001:1001 | all pass |
| `TestBringupScriptUpCheckDownFullProfile` as `runner` 1001:1001, 3 runs | **3 of 3 pass** (63 s, 20 s, 21 s); each run's `es.log` has `--user 1001:1001` |
| A second operator created on the runner, `op` 2500:2600 (UID ≠ GID, groups `opgrp` and `docker` only), tree from `git archive HEAD` | `TestESLauncherContainerUser` passes; `TestBringupScriptUpCheckDownFullProfile` **passes** (96 s) and its `es.log` has `--user 2500:2600`. This is the GID half the runner user alone cannot show. |
| Docs tests (`go test . -run Doc`) | ok |
| Root package with PR #14's 11 environment-only skips (informational) | one failure, `...SudoVisibleInspection`, the harness `stat` bug that PR #14 fixes; same as at the base in run 45062879872 |
| Whole `es/app` package (informational) | 3 failures, all expected: the two "local build path rejects missing Go" subtests that PR #14 lists, and the installed-source witness. #17's three repaired tests pass here. |

## 5. Container checks (cloud container, Docker not running, Go 1.26.5)

| Check | `ci` 30033:30033 | `ci3` 31500:31600 |
| --- | --- | --- |
| `gofmt -l es/app scripts`, `go vet ./es/app`, `bash -n scripts/05_start_es.sh` on `f5510db` | clean | clean |
| `TestESLauncherContainerUser` on `f5510db` | 6/6 subtests pass | 6/6 subtests pass |
| `go test . -run Doc` on `f5510db` | ok | ok |
| 27 mutants on `008f4d7`'s script | 25 caught, 2 equivalent | 25 caught, 2 equivalent |

Log: `06-evidence/container-final-f5510db.log`. The bring-up integration test needs an image build with egress, which this container lacks, so it ran only on the runner.

## 6. Correction to `04-bringup.md` section 4 (O-7)

That table's last rows should read:

| Daemon | Before (`ae326b0`) | After |
| --- | --- | --- |
| Rootless | Untested | Untested and unsupported for bring-up; which check refuses, if any, is unknown |
| User-namespace remapped | Docker refuses `--network host`, bring-up stops at its host-loopback check | Same; ES never starts |

## 7. Not changed

- `scripts/internal/control_plane.sh`, the profile path, ES product code: untouched.
- ARS, EGS and AGS still run as root in this PR. The coordinator asked for them as a separate tranche on a new branch; that work is under way and is not part of this PR or this audit target.

## 8. Effects

- Pushed: `claude/project-thread-a9tcoa-bringup` (`bede334` to `f5510db`, fast-forward) and the new probe branch `claude/project-thread-a9tcoa-bringup-probe` (`31ddbfd`). The probe branch should be deleted after the narrow audit; this session cannot delete remote branches.
- PR #18 body updated to describe the repair and the new manifest. PR still a draft.
- Container only: test users `ci3` and a temporary `--userns-remap` dockerd (stopped).
- No merge, no change to any other repository or service.

## 9. Request

Narrow audit of `bede334..008f4d7` plus the provenance check of the merge (`f5510db`, manifest above).
