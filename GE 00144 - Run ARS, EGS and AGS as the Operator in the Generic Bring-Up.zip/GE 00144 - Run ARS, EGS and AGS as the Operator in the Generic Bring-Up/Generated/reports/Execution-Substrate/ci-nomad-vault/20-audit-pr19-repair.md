# 20: Narrow audit of the PR #19 structural repair (07a422b..be71f84)

Written by the independent audit thread "Audit bring-up running as the operator", 2026-11-23, from 03:21Z.
Read-only. Nothing was pushed, commented, reviewed, merged or changed on GitHub.

Evidence: `20-audit-pr19-repair-evidence/` (README and `SHA256SUMS.txt` there).

## 1. Verdict: BLOCK on A20-1 and A20-2

The repair does what it set out to do for my audit's findings.

- A12-1 (an unsearchable directory between the mounts) is closed: layout C19 is refused at the directory ARS cannot search.
- A12-2 (the index rewrite) is closed: C18 (sticky index directory) and C25 (symlinked index) are refused.
- A11-1 (storage usable only through a supplementary group) stays closed: C03 is refused.
- The check now runs as ARS runs: same image, identity, mounts and container name.

On 50 storage layouts, each built three times (the check, an independent reference in ARS's mounts, and the real ARS binary), the check agrees in 40 and is stricter in 5. The new tests pass as both test users, and the merge gate's CI is green on be71f84.

Two things still block.

- **A20-1 (Medium): the check is looser than ARS for storage paths that are not in normal form.** It strips and normalizes `storage.root_dir` and `storage.index_file` before checking, and ARS's mounts use the normalized form too. ARS itself stats and opens the configured strings exactly as written. Five layouts pass the check and then stop ARS at startup:
  - `..` in the root;
  - `..` in the index;
  - a trailing space;
  - a leading space;
  - a trailing slash on the index.

  This defect has been there since the check was introduced. My earlier audits did not test it.
- **A20-2 (Medium): bring-up fails on valid storage once the storage has enough directories.** The new probe starts three processes for every storage directory, which costs about 1.7 ms per directory here. `02_start_ars.sh` runs the check inside `01_bringup.sh up`'s ARS readiness wait (30 s by default). ARS's layout `sha256/xx/yy/` grows to 65,794 directories, not "a few hundred" as the repair report says.
  - Measured: with 49,410 directories, a real bring-up failed at ARS readiness even with the test's 60 s wait, and ARS never started.
  - With 24,834 directories, ARS started 39.5 s after its launcher. That passes the test's 60 s wait and is past the default 30 s.

One low finding, A20-3, is a component named `-` in a storage path. It gives a wrong refusal with a misleading message. It should be fixed in the same repair.

Both blockers are narrow and deterministic to fix (section 6). Nothing in the repair weakens what audits 11 and 11-addendum accepted.

## 2. Provenance (taken first)

| Item | Result |
| --- | --- |
| Recipe `/opt/audit/v2.py` | sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before both manifest runs |
| Head | `be71f84743bd247aef642726b6e8cc45a2f844cb` (`refs/pull/19/head` at the start and the end) |
| Base | `f62d024` (trunk_dev when the branch last merged it) |
| Upstream | re-pinned to `origin/trunk_dev` |
| Opening manifest | `cf8e81bea474e568bb90823217b5a088a5d3f9e686c81771a1867d0e4ebfdea5`, twice, byte-identical. Equal to the writer's `manifest-v2-pr19-be71f84.json` |
| Closing manifest | `cf8e81bea474e568bb90823217b5a088a5d3f9e686c81771a1867d0e4ebfdea5` again, twice, at 04:15Z after the recipe hash check and a fresh fetch (`refs/pull/19/head` still `be71f84`) |
| Writer's report | `14-repair-pr19.md` sha256 `3eeeee8f6b7a0e5bf51d07f44c7a5fea5bd2c00c385b88d58f2893ea60da9ffb`, as stated |
| Writer's evidence | `SHA256SUMS.txt` checks out |
| Merge-gate CI on be71f84 | "build, vet and test" run 45101384405, job 137452785872: success, 02:38:42Z to 02:51:39Z |

**trunk_dev has moved.** It is now `110d377` (PR #21: one test file, `remote_alpha_es_service_tls_status_test.go`, with no overlap). GitHub reports PR #19 as "behind". The branch update needs a fresh manifest before any merge (provenance §5.4).

## 3. What I checked

### 3.1 Delta

- `88d5f61` merged `f62d024`, which brought only `sqlite_physical_test.go`. That file is identical at head.
- My scripts-and-docs diff of `07a422b..be71f84` (422 lines) is byte-identical to the writer's `delta-07a422b-be71f84-scripts-docs.diff`.
- `generate_control_plane_dockerfile.sh` gains only a comment, so the image is unchanged and the audit image `execution-substrate/control-plane:audit-bede334` still applies. There is no non-test Go change from `bede334` to `be71f84`.
- `01_bringup.sh` changes a comment only.
- `02_start_ars.sh` now removes ARS's container before the check.
- `control_plane.sh` replaces the emulating Python walk with a host part plus a BusyBox probe run by `docker run` with ARS's name, `--network none`, `--user`, ARS's mounts and ARS's image.

### 3.2 Tests on exact bytes

- Trees come from `git archive be71f84`.
- The runs were: `go vet`, `gofmt`, `bash -n` on every changed script, the three launcher and bring-up test functions, and `go test . -run Doc`.

| User | Result |
| --- | --- |
| ci 1500:1600 (groups cigrp, docker; passwordless sudo) | 91 pass, 0 skip, 0 fail |
| ci2 1700:1700 (groups docker, cigrp; no sudo) | 87 pass, 4 skip (the four sudo rows: supplementary group, primary group, ACL grant, ACL deny), 0 fail |

### 3.3 Comparison with what ARS can do: 50 layouts

`kernel_compare14.py` builds each layout three times:

- **check:** `verify_ars_storage_for_operator` from the be71f84 tree, run as ci for identity 1500:1600, or as root for 0:0, with the audit image;
- **ops reference:** `python:3.13-alpine` with `--user` and exactly ARS's mounts. It creates and removes a file in every directory, reads every file, and replaces the index the way ARS does;
- **real ARS:** the ARS binary from the audit image, with ARS's mounts and a synthetic config whose TLS files are junk. "storage ok" means ARS got past its storage startup and failed at "load tls key pair".

Result: 40 agree, 5 stricter, **5 looser**.

| Group | Layouts | Result |
| --- | --- | --- |
| The addendum's 25 (C01-C25), including A11-1 (C03), A12-1 (C19), A12-2 a (C18) and A12-2 b (C25) | 25 | all agree |
| chattr +i/+a on blob directories and the index (D01-D04, D19), a read-only bind submount (D05), the index inside storage (D06), ACL masks and named groups (D07-D09), a sticky blob directory with a foreign blob (D17), a setgid index directory with a foreign group (D18) | 15 with D22-D24 | all agree |
| `..` in the root (D23) or a trailing slash on the root (D24) where ARS can still use the path, and a root whose last component is `-` (D22) | 3 | agree |
| Stricter: a shard link (D15) and a FIFO (D16), refused by design; a 0300 directory the check cannot list (D20), by design; a host directory above the mounts that the caller cannot search (D14), by the host part's design; a component named `-` (D13), **A20-3** | 5 | check stricter |
| **Looser: storage paths not in normal form (D10, D11, D12, D21, D25), A20-1** | 5 | check passes, ARS fails at startup |

The writer's 34 layouts (31 agree, 3 stricter) are consistent with mine where they overlap. None of them uses a path that is not in normal form.

### 3.4 Mutants (my own, written independently of the writer's)

`mutants14.py` has 63 mutants plus the unmutated baseline. They cover:

- the identity helper and launchers (P01-P21);
- the wiring in `01_bringup.sh` and `02_start_ars.sh`, including the check moved back before `docker rm -f` (P23-P31);
- the host part (R01-R06);
- the docker command (R07-R15);
- each probe step (R16-R38);
- refusal parsing (R39-R45).

They ran as ci and as ci2.

| User | Caught | Survived |
| --- | --- | --- |
| ci 1500:1600 (sudo) | 60 of 63 | R06, R34, R38 |
| ci2 1700:1700 (no sudo) | 59 of 63 | R06, R28, R34, R38 |

- R06 (the `strip()` removed): no test row uses a storage path with surrounding whitespace. This is part of A20-1.
- R34 (no `chmod 600` before the rename): equivalent, because BusyBox `mktemp` creates `0600`. This is the writer's M25.
- R38 (`cd` without `--`): equivalent unless a path component starts with `-`, and no row has one. See A20-3.
- R28, as ci2 only (`[ -r ]` instead of a real read): caught only by the sudo-and-ACL rows, which skip without sudo and run on CI. This is the writer's M17.

Everything else is caught as both users, including:

- the check moved back before `docker rm -f` (P25);
- each docker flag;
- each probe step;
- links skipped or followed;
- special files ignored;
- the index rewrite removed or done in place;
- exit 42 treated as a pass.

### 3.5 Cost of the check on realistic storage

`check_timing14.sh` times one check, as ci, on ARS's layout `sha256/xx/yy/` with 256 first-level shards and N second-level shards, one blob each:

| Directories | One check |
| --- | --- |
| 1,282 | 2.4 s |
| 4,354 | 7.6 s |
| 16,642 | 28.4 s |
| 65,794 (every shard ARS can create) | 112.2 s |

That is linear at about 1.7 ms per directory. The writer timed only a small tree (0.30 to 0.35 s).

`bringup_large_store14.sh` runs the real bring-up test (`TestBringupScriptUpCheckDownFullProfile`, which sets `READY_TIMEOUT_SECONDS=60`) as ci. It fills the test's ARS storage with empty shard directories as soon as the test creates it, and changes nothing else.

| Directories | Outcome |
| --- | --- |
| 24,834 | PASS. ARS's container started 39.5 s after its launcher, that is, after the readiness wait began. `01_bringup.sh`'s default wait is 30 s. |
| 49,410 | **FAIL**: "artifact-registry: health request failed". `up` stopped the launcher while the launcher's own check was still running, and no ARS container ever started. |

## 4. Findings

### A20-1 (Medium, blocking): the check is looser than ARS for storage paths that are not in normal form

**Where.**
- The host part strips both strings and uses `os.path.normpath` (`scripts/internal/control_plane.sh:244-245`, `:267-268`). The probe receives the normalized paths (`:375`).
- ARS's mounts come from `control_plane_mount_specs`, which strips and normalizes too (`:452-463`). That part is unchanged from trunk_dev.
- ARS uses the configured strings as written:
  - `store.NewFilesystemStore(cfg.Storage.RootDir)` calls `os.Stat(rootDir)` (`ars/store/filesystem.go:26`);
  - `index.Load(cfg.Storage.IndexFile)` calls `os.Open(path)` (`ars/index/fileindex.go:27`);
  - the config only checks that the strings are not blank (`ars/config/config.go:116-120`).

**Failure.** Each row below was run as ci (1500:1600) with the real ARS binary:

| Layout | Check | Real ARS |
| --- | --- | --- |
| D10 `root_dir` = `<base>/data/../ars-storage`, `<base>/data` on the host only | PASS | `stat storage root: stat …/data/../ars-storage: no such file or directory` |
| D11 `root_dir` with a trailing space | PASS | `stat …/ars-storage : no such file or directory` |
| D12 `index_file` = `<base>/foo/../ars-index/index.json` | PASS | `open artifact index: … no such file or directory` |
| D21 `index_file` with a leading space (relative for ARS) | PASS | ARS fails at storage startup |
| D25 `index_file` with a trailing slash | PASS | `open artifact index: open …/index.json/: not a directory` |

`ARS_CONFIG` is the operator's own file (`01_bringup.sh` takes it from the environment), so these strings are operator input. The check then also rewrites the index, as it does on any pass. ARS then exits at startup with its own error. No blob data is touched, which is why this is Medium and not High.

It still fails the property this PR claims, and that I was asked to hunt: "it is never looser". The writer's 34 layouts had no such path.

**Fix.** The fix must be deterministic. Either of these works:

- **(recommended)** Refuse in the host part any `storage.root_dir` or `storage.index_file` that is not exactly its normal form. That means `value != value.strip()` or `os.path.normpath(value) != value` is refused, with a message that names the normalized path to use. The mounts are built from the normalized path, so only that form makes ARS's view match its mounts. A trailing slash on the root (D24), which ARS tolerates, would then be refused too, which is strict but harmless.
- Or pass the configured strings unchanged to the probe and resolve them physically (`cd -P`) the way the kernel does for ARS.

Either way, add test rows for:

- `..` in each path;
- leading and trailing whitespace;
- a trailing slash on the index.

### A20-2 (Medium, blocking): the probe's per-directory cost makes `up` fail on valid storage

**Where.**
- `walk` runs `mktemp`, `rm` and `ls -A` for every directory (`control_plane.sh:332-344`).
- `02_start_ars.sh:34` runs the whole check before it execs ARS.
- `01_bringup.sh` starts the launcher in the background (`start_managed_service`, `:129-157`). It then calls `wait_for_service_ready … "${READY_TIMEOUT_SECONDS}"` (`:234`), whose deadline starts at once (`scripts/internal/bringup.sh:266`). The default is 30 s (`01_bringup.sh:16`).
- So the launcher's check counts against ARS's readiness, and `up` pays for the full walk twice: once in `01_bringup.sh:231`, then again in the launcher.

**Failure.**
- **Measured (section 3.5).** At 49,410 directories, `up` failed at ARS readiness even with the test's 60 s, and ARS never started. At 24,834 directories, ARS started 39.5 s after its launcher.
- **Inference from the measured rate.** With the default 30 s, `up` fails here from roughly 17,000 directories.
  - ARS creates one directory per new `sha256/xx/yy` shard, so that is roughly 20,000 blobs.
  - At ARS's full fan-out, each check takes about 112 s.
  - Guess: on macOS Docker Desktop file sharing, which the supported-local proof also uses, each fork and file operation costs more, so the threshold would be lower. Nothing ran on macOS.

**Root cause in the report.** The repair report says "ARS's two-level `sha256/xx/` layout gives at most a few hundred directories in practice" (`14-repair-pr19.md`, Costs). ARS's path is `filepath.Join(rootDir, "sha256", sum[:2], sum[2:4], digest)` (`ars/store/filesystem.go:174`): two hex levels below `sha256`, so up to 256 + 65,536 shard directories. The PR body's "about 0.3 s" holds only for a nearly empty store. 07a422b's host-side Python walk did not start processes per directory.

**Fix.** The design is the writer's choice. It must keep the check's guarantees and must not add a way to skip it. Acceptable shapes include:

- a probe whose work does not start processes per directory (for example, one `find`-style pass and shell built-ins, while each step is still the kernel's decision);
- and/or not counting the launcher's check against ARS's readiness wait. For example, start ARS's readiness deadline when the check has passed, or have `up` run the check once and the launcher reuse that result only through a mechanism that cannot be used to skip the check.

Add a test or measured row with tens of thousands of directories under the default `READY_TIMEOUT_SECONDS`, and correct the cost statements in the report and the PR body.

### A20-3 (Low): a path component named `-` gives a wrong refusal with a misleading message

- `reach` runs `cd -- "$component"` (`control_plane.sh:326`). For a component `-`, BusyBox `cd -- -` changes to `$OLDPWD` and prints it on stdout.
- In D13 (`<base>/-/ars-storage`, which ARS can use) the next `cd` fails in the wrong directory. The REFUSE record then no longer starts stdout, and the host part reports `could not run the check container as 1500:1600 (exit 42): /home/ci/kc14`.
- D22 shows it never wrongly passes, because every later step uses absolute paths. Even so, the refusal is wrong for D13 and the message is wrong for both.
- Fix: `cd -- "./$component"`, or `cd -P -- "$path"` with the absolute prefix. Add a row for a `-` component.

## 5. Notes (not blocking)

- The "index replace" refusal always says "in a directory with the sticky bit, only the owner of the file or of the directory may". In D02, D03 and D19 the cause is `chattr +a`/`+i` on the index. Suggest neutral wording.
- Structural damage is out of the check's scope: a regular file named `sha256` or `sha256/ab` passes, because it is readable. ARS's `MkdirAll` would then fail at the first blob write in that shard. This is by reading ARS's code; not run.
- Inference: if the launcher is stopped while the probe runs (as `up` did in the 49,410 run), the probe may not reach its EXIT trap and may leave a `.ars-storage-check.*` or `.artifact-index-check.*` file. The next check reads such a file as an ordinary file, so it is harmless. Not verified.
- Inference, as in the addendum: two bring-ups with different `BRINGUP_DIR` (different container names) sharing one storage could lose an index update. Sharing storage between two ARS is unsafe anyway.
- A FIFO swapped in between the probe's `[ -f ]` test and its read would block the check (denial of service only). It needs a concurrent writer in storage.
- A refusal in `02_start_ars.sh` now leaves the previous ARS container removed. That is intended, and the code comment says so.
- The SELinux row in the writer's claims ("exactly as ARS") was not testable here. No `:z`/`:Z` is passed, the same as for ARS.

## 6. What a repair must show

1. A20-1: the five looser layouts (D10, D11, D12, D21, D25) refused, with test rows, and no new stricter layout beyond the documented trailing slash on the root.
2. A20-2: `01_bringup.sh up` with the default `READY_TIMEOUT_SECONDS` passes on a valid store with ARS's full fan-out (65,794 directories), or the repair states a measured bound and a test pins it. Correct the report's and the PR body's cost statements.
3. A20-3: a `-` component row.
4. The 50-layout comparison re-run with no looser row, the tests passing as a user with and without sudo, and a fresh manifest on a branch that has taken trunk_dev `110d377`.

## 7. Evidence

Listed in `20-audit-pr19-repair-evidence/README.md`. No key, certificate body, token or config file is included. All fixtures are synthetic. A pattern scan for private-key headers, certificates, and Vault, JWT, GitHub, Anthropic and AWS token shapes found nothing.
