# 20-audit-pr19-repair evidence (ES PR #19, head be71f84)

Written by the independent audit thread "Audit bring-up running as the operator", 2026-11-23, 03:21Z to 04:16Z.
Every file here was produced in the audit's cloud container. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../20-audit-pr19-repair.md`.

## Setup

- Same container and toolchain as `11-audit-pr19-addendum` (Go 1.26.5, `GOTOOLCHAIN=local`).
- The audit image is `execution-substrate/control-plane:audit-bede334`. It is still valid because there is no non-test Go change from `bede334` to `be71f84`, and the Dockerfile generator gained only a comment.
- Test users:
  - `ci` = 1500:1600, groups cigrp (1600) and docker (996), passwordless sudo;
  - `ci2` = 1700:1700, groups docker and cigrp, no sudo;
  - group `proj` = 1800, with no members.
- The `acl` package is installed.
- Trees come from `git archive be71f84`: `/home/ci/es14` (ci) and `/home/ci2/es14` (ci2).
- Every test run starts with `env -i` and sources `ci-env.sh.txt` or `ci2-env.sh.txt`.

## Files

| File | What |
| --- | --- |
| manifest-v2-open-be71f84-run1.json, -run2.json, manifest-v2-close-be71f84-run1.json, -run2.json | Base-pinned manifest (base f62d024, upstream origin/trunk_dev), taken first and last: cf8e81be…dea5 all four times |
| ls-remote-close.txt, ci-check-runs-pr19-be71f84.txt | Remote refs at the end (trunk_dev 110d377); PR #19's check run on be71f84 (success) |
| delta-07a422b-be71f84-scripts-docs.diff, delta-07a422b-be71f84-test.diff | The repair: scripts and docs (identical to the writer's diff), then the tests |
| unit14.sh.txt, unit-tests-be71f84-uid1500-gid1600.log, unit-tests-be71f84-uid1700-gid1700.log | Runs vet, gofmt, `bash -n` on each script, the launcher and bring-up tests, and `go test . -run Doc`. ci: 91 pass, 0 skip. ci2: 87 pass, 4 sudo skips |
| kernel_compare14.py.txt, kprobe12.py.txt, kernel-comparison-be71f84.log | 50 layouts. Each runs the check, an ops reference in ARS's mounts, and the real ARS binary's storage startup. Result: 40 agree, 5 stricter, 5 looser (D10, D11, D12, D21, D25, which are paths not in normal form) |
| check_timing14.sh.txt, check-timing-large-store.log | One check on ARS's `sha256/xx/yy` layout with 1,282 to 65,794 directories. Cost is linear, about 1.7 ms per directory |
| bringup_large_store14.sh.txt, bringup-large-store-n2-96*.{log,txt}, bringup-large-store-n2-192*.{log,txt}, bringup-large-store-notes.txt | The real bring-up test as ci, with the test's ARS storage filled with shard directories. At 24,834 directories it passed, with ARS starting 39.5 s after its launcher. At 49,410 it failed at ARS readiness and ARS never started |
| mutants14.py.txt, mutants14-uid1500-gid1600.log, mutants14-uid1700-gid1700.log | 63 mutants plus the baseline, written independently of the writer's. ci: 60 caught. ci2: 59 caught |
| ci-env.sh.txt, ci2-env.sh.txt | The environment of every test run |

## Sensitive material

The tests and fixtures are synthetic. No key, certificate body, token or config file is copied here.
The private service logs stayed in the container. A pattern scan for private-key headers, certificates, and Vault,
JWT, GitHub, Anthropic and AWS token shapes found nothing.
