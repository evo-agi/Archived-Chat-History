# ES bring-up: ARS, EGS and AGS run as the operator

Report 07 of the CI Nomad/Vault track. The next tranche the coordinator asked for on 2026-11-22 20:43Z, after the PR #18 repair: "make ARS, EGS and AGS run non-root in bring-up as well, applying the same least-privilege fix rather than leaving them as root. Stop and report if that turns out to need a product change."

Date: 2026-11-22. Repository: `evo-agi/Execution-Substrate`. Evidence: `07-evidence/` beside this file (`SHA256SUMS.txt` lists every file). Files named `9eb593e`, and the two mutant logs without a commit in their name, are from the first version of the change and are kept for the record; the final evidence names `81b7dc5`, `b98740e` or run 45074957888.

## 1. Outcome

| Item | Result |
| --- | --- |
| Product change needed? | **No.** ARS, EGS and AGS contain no `chown`, `Geteuid`/`Getuid` or other root assumption (`grep` over `ars`, `egs`, `ags`, `internal`, `cmd`), and the bring-up ports 8442 to 8445 are unprivileged. EGS and AGS write nothing; they read their config and TLS files. ARS writes only its blob store and index, with no `chown` (so a setgid storage directory does not break it, unlike ES staging, A6-3). |
| Change | Branch `claude/project-thread-a9tcoa-services-nonroot`, head `b98740e`, based on trunk_dev `3a5f257` (PR #18's squash). Scripts, tests and docs only. PR: [#19](https://github.com/evo-agi/Execution-Substrate/pull/19) (draft) |
| Runner | Run 45074957888 on probe `4667d92` (`81b7dc5`, same tree as `b98740e`, plus the probe workflow): **success**. Launcher tests 31/31 and 9/9; bring-up 3 runs as 1001:1001 and 1 as 2500:2600, all passed, four service logs with the operator's `--user` each time, 0 root-owned entries left (section 6) |
| Manifest | `e3b956e995d86f953f4b90ba98078e118cb16eeaf41ad5340cee96d5936f02ac`, base `3a5f257`, upstream `origin/trunk_dev`, 11 files (section 2) |
| Mutants | 30 script mutants, all caught, as a user whose UID equals its GID and as one whose UID differs (section 4) |

Nothing was merged.

## 2. Target identity

| Field | Value |
| --- | --- |
| Base | `trunk_dev` at `3a5f25776274b3e9ada3e2d489c9bfe0e8bf8a28` (PR #18's squash merge) |
| Topic branch and tip | `claude/project-thread-a9tcoa-services-nonroot` at `b98740e48526a14c2d0661b49deca3938f67c441`, tree `ba108a055649941770ab20a2d3ea2dce4dac1724` |
| Commits | `9eb593e` (the change, on PR #18's `f5510db`), `b346634` (merge of PR #18's `c291503`), `2439766` (trailing-characters rows), `4a9557b` (merge of PR #18's `d6aded1`), `81b7dc5` (user-name row), `b98740e` (merge of trunk_dev `3a5f257`). The last merge had textual conflicts in `PLANS.md`, the runbook and `scripts/05_start_es.sh`, because the squash is not an ancestor; `3a5f257`'s tree equals `d6aded1`'s, which the branch already contained, so each was resolved to the branch's version and the merged tree equals `81b7dc5`'s tree. |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` |
| Base-relative manifest | `e3b956e995d86f953f4b90ba98078e118cb16eeaf41ad5340cee96d5936f02ac`. `umask 022`, fresh clone from GitHub after the push, `git reset --mixed 3a5f257`, `git branch --set-upstream-to=origin/trunk_dev` before each of the two runs, byte-identical. 11 files (10 `tracked_modified`, 1 `untracked`: the new test file), textual diff `d429452637cc62f110beeb9a576d4350301664a8e8d1d3227433007e78ad9ca2`. Copy: `07-evidence/manifest-v2-services-b98740e.json` |
| Files | `scripts/internal/control_plane.sh`, `scripts/01_bringup.sh`, `scripts/02_start_ars.sh`, `scripts/03_start_egs.sh`, `scripts/04_start_ags.sh`, `scripts/05_start_es.sh`, `es/app/service_launchers_container_user_test.go` (new), `es/app/operator_scripts_integration_test.go`, `PLANS.md`, `.docs/system_overview/configuration.md`, `.runbooks/system/v1_bringup.md` |

## 3. What each service needs, and the change

| Service | Before | Reads | Writes | After |
| --- | --- | --- | --- | --- |
| ARS | root (image default) | config, TLS cert, key, client CA | `storage.root_dir` (blobs, `0600`, temp file then rename, `ars/store/filesystem.go:124-153`), `storage.index_file` (`0600`, temp file then rename in its directory, `ars/index/fileindex.go:158-187`) | operator UID:GID, after a storage check |
| EGS | root | config, TLS cert, key, client CA (signing key is inline hex in the config) | nothing | operator UID:GID |
| AGS | root | config, TLS cert, key, client CA, ARS client cert, key, root CA | nothing | operator UID:GID |
| ES | operator since #18 | | | unchanged; now uses the shared helper |

**Shared identity helper** (`scripts/internal/control_plane.sh`, `control_plane_operator_user`): prints `$(id -u):$(id -g)` after checking both are numeric (`^[0-9]+$`), refusing otherwise with "cannot run <SERVICE> as the operator: id -u and id -g must print numeric IDs, got … and …". Each `id` call carries `|| return 1`, because command substitutions do not inherit `errexit`. All four launchers call it before `ensure_control_plane_image`, so the identity is settled before any image, storage or container effect. ES's launcher keeps its exact behaviour and message; its launcher test from #18 (9 subtests) passes unchanged.

**ARS storage check** (`verify_ars_storage_for_operator`, run by `02_start_ars.sh` after the image check and before `docker rm`, and by `01_bringup.sh up` right after the ES root check, before any service starts). Static resource checks, which AGENTS.md section 12 allows; no label branching, no repair:

1. `storage.root_dir` and `storage.index_file` must be absolute (a relative path is never mounted into the container today, so ARS could not work with it anyway).
2. A missing storage root is created as the operator. Before, Docker created a missing bind source as root, which a non-root ARS could not write.
3. The index file must already exist as a regular file; ARS refuses to start without it (`ars/index/fileindex.go:27`). Refusing first also stops Docker from creating a root-owned index directory.
4. The index directory and every directory under the storage root must be writable and searchable (`os.access(W_OK|X_OK)`), and the index and every regular file under the root readable, by the operator.
5. A failure names the path and prints the exact command to hand it back: `sudo chown -R UID:GID <storage root>` for anything under the root, and a non-recursive `sudo chown UID:GID <path>` for the index file or its directory, because in the supported-local layout the index sits in the proof directory, next to ES's `0:0` roots, which must not be chowned.

**Why the check matters.** ARS's own startup only checks that the root exists and that the index opens (`ars/app/app.go:37-46`). A store that an earlier root-run bring-up wrote holds root-owned `0600` blobs: a non-root ARS would start, then fail on the first read or write of those blobs. The check turns that into a refusal at bring-up time, with the fix in the message.

**Migration for existing operators.** Anyone who ran bring-up before this change with a persistent ARS store has root-owned blobs and index. The first bring-up after the change refuses with the `sudo chown` line; after running it, bring-up proceeds. The runbook says so.

**Also least-privilege:** in the supported-local layout ARS's index directory is the proof directory, which ARS mounts read-write; as root, ARS could write anywhere in it, including ES's `0:0` roots. As the operator it cannot.

## 4. Tests

`es/app/service_launchers_container_user_test.go` (new):

- `TestServiceLaunchersContainerUser`, 31 subtests, fake `docker` and fake `id` as in #18's launcher test:
  - For each of ARS, EGS and AGS (8 each): the caller's real IDs; UID 4242 with GID 4343 (exact `docker run` arguments, `--user` in the executed and in the printed command); and refusals before any container call for an empty UID, a user name with a digit as UID, a group name with a digit as GID, a UID and a GID with trailing characters, and a failing `id`.
  - For ARS also (7): missing storage root created as the caller (owner checked); missing index refused; relative root refused (and not created); unwritable storage directory, unreadable blob, unwritable index directory and unreadable index refused, each with its exact `chown` hint. The four permission cases skip when run as root, which bypasses the mode bits.
- `TestBringupUpChecksARSStorageBeforeStartingServices`: drives `01_bringup.sh up` with fakes and a missing ARS index; it must refuse after the host-loopback probe, with no service container removed or started and no service log written.

`es/app/operator_scripts_integration_test.go`: the bring-up test now calls `assertBringupServicesRunAsOperator` after the execution loop. It requires each of the `ars`, `egs`, `ags` and `es` launcher logs to show `--user UID:GID`, and every entry under ARS's storage plus the index to be owned by the operator's UID and GID, with at least one file besides the blob the test wrote (so ARS itself stored something).

**Mutants** (`07-evidence/mutants_services.py.txt`), 30, each on a fresh copy of `81b7dc5` (same tree as `b98740e`), run as two users:

| Target | Mutants | `ci` 30033:30033 | `ci3` 31500:31600 |
| --- | --- | --- | --- |
| Identity helper | S01 swap UID and GID, S02 UID twice, S03 no numeric check, S04 UID only, S05 GID only, S06 ignore `id` failure, S07 fixed `0:0`, S26 both end anchors missing, S27 UID end anchor, S28 GID end anchor, S29 UID start anchor, S30 GID start anchor | 12 caught | 12 caught |
| Launchers | S08 ARS exec without `--user`, S09 EGS printed line without it, S10 AGS `--user` after the image, S11 EGS exec without it, S12 AGS identity after the image check, S13 ARS storage check after `docker rm`, S14 ARS no storage check, S24 ES without the helper's check | 8 caught | 8 caught |
| Storage check | S15 no mkdir, S16 skip directory checks, S17 skip file checks, S18 skip index read check, S19 non-recursive storage hint, S20 accept a relative root, S21 allow a missing index, S22 recursive index hint, S25 skip the index directory check | 9 caught | 9 caught |
| `01_bringup.sh up` | S23 no early storage check | caught | caught |

Logs: `mutants-services-81b7dc5-uid30033-gid30033.log`, `mutants-services-81b7dc5-uid31500-gid31600.log`. S25 survived a first run on the original commit; the "unwritable index directory" subtest was added for it before the first push.

## 5. Docs

- `PLANS.md`: new bullet `GENERIC-SERVICE-LAUNCHER-USER-01` (bounded slice rule); the ES bullet's last sentence now points to it instead of "Other bring-up services are unchanged".
- `.docs/system_overview/configuration.md`, ARS section: one line on the bring-up identity and the storage check.
- `.runbooks/system/v1_bringup.md`: the ARS bullet lists the storage requirements and the `sudo chown` hint; the EGS/AGS bullet says they run as you; a new bullet says that every `*_file` must be readable by your UID or primary group and that ports must be 1024 or higher unless the host allows lower unprivileged binds.

## 6. Runner

GitHub-hosted `ubuntu-24.04`, pinned Nomad 2.1.1, Vault 2.2.2, SPIRE 1.14.4, images by digest, `AWS_EC2_METADATA_DISABLED=true`, probe branch `claude/project-thread-a9tcoa-bringup-probe` (the branch under test merged into the earlier probe, plus `.github/workflows/probe-bringup.yml`; copy `07-evidence/probe-workflow-24c29a6.yml.txt`). The workflow runs the launcher tests, the bring-up test 3 times as `runner` (1001:1001) and once as a second operator created on the runner (2500:2600), and after each bring-up checks that the four service logs show `--user` with that operator's IDs and counts root-owned entries left in the workspace.

Final run: [45074957888](https://github.com/evo-agi/Execution-Substrate/actions/runs/45074957888), job 137370038426, on `4667d92` (its parent `81b7dc5` has the same tree as the final head `b98740e`; the only other file is the workflow). Log: `runner-45074957888-job137370038426.log`.

| Step | Result |
| --- | --- |
| `gofmt`, `go vet ./es/app`, `bash -n` | clean |
| Launcher and supported-local script tests as `runner` 1001:1001 | pass; `TestServiceLaunchersContainerUser` 31/31, `TestESLauncherContainerUser` 9/9, no skips |
| Bring-up test as `runner`, 3 runs | 3 passed (50 s, 20 s, 45 s); each workspace's ARS, EGS, AGS and ES logs show `--user 1001:1001`; 0 root-owned entries left in each workspace |
| Launcher test as `op` 2500:2600 | pass, 9/9 |
| Bring-up test as `op`, 1 run | passed (54 s); all four logs show `--user 2500:2600`; 0 root-owned entries |
| Docs tests (`go test . -run Doc`) | ok |
| Root package with the gate's 11 skips (informational) | only `…WithSudoVisibleInspection`, the known pre-existing failure that PR #14 fixes |
| Whole `es/app` (informational) | only the known three: the two `ExactGoPreflight` subtests and `…InstalledSourceIdentity`, the same set as on the earlier runs |

Earlier runs on this branch: [45071045211](https://github.com/evo-agi/Execution-Substrate/actions/runs/45071045211) (probe `24c29a6`, the first version of the change) and [45073578498](https://github.com/evo-agi/Execution-Substrate/actions/runs/45073578498) (probe `186fedb`, with `2439766`), both green with 0 root-owned entries; logs `runner-45071045211-job137357826050.log` and `runner-45073578498-job137365755271.log`. Before this change, bring-up left root-owned ARS files in the workspace (audit 05 observation O-9).

## 7. Container checks

On `81b7dc5` (same tree as the final head):

| Check | `ci` 30033:30033 | `ci3` 31500:31600 |
| --- | --- | --- |
| `gofmt`, `go vet ./es/app`, `bash -n` on the five launchers and `control_plane.sh` | clean | clean |
| `TestServiceLaunchersContainerUser` (31), `TestBringupUpChecksARSStorageBeforeStartingServices`, `TestESLauncherContainerUser` (9), `TestSupportedLocalExecutionRoot*` | pass | pass |
| `go test . -run Doc` | ok | ok |

Logs: `container-final-81b7dc5-uid30033.log`, `container-final-81b7dc5-uid31500.log`. The bring-up integration test needs an image build with egress, so it ran only on the runner.

## 8. Not run, limitations

- The supported-local proof on the Mac (`scripts/73_supported_local_proof.sh`), which uses the same launchers. Its setup creates the ARS storage with plain `mkdir` and writes its TLS files without `sudo` (`scripts/72_supported_local_setup.sh:1417`; the only `sudo` calls are the root helper and two installs), so the operator who runs bring-up owns them; but it has not run with this change.
- A rootless or remapped daemon: unchanged from #18 (unsupported; Docker refuses host networking on a remapped daemon).
- A real operator store left root-owned by an earlier bring-up: covered by the launcher test's permission cases, not by a live run.

## 9. Effects

- Pushed branch `claude/project-thread-a9tcoa-services-nonroot` (fast-forwards only), head `b98740e`.
- Probe branch `claude/project-thread-a9tcoa-bringup-probe` fast-forwarded to `4667d92` (merge commits only, no force). It can be deleted after the runner run in section 6; this session cannot delete branches.
- Draft PR [#19](https://github.com/evo-agi/Execution-Substrate/pull/19) opened into `trunk_dev`, assigned to SeritArbores. No merge.

## 10. Request

Audit of `3a5f257..b98740e` (scripts, tests and docs only). Red-team: coordinator's call; the change lowers three containers' identity and adds a read-only storage check; it touches no product code.
