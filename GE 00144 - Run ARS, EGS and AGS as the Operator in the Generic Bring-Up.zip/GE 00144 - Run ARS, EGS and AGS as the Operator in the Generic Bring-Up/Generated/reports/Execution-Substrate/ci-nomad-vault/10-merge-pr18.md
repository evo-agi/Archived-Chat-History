# ES PR #18: merge report

Report 10 of the CI Nomad/Vault track. Merge gate per `claude-conversion/claude-operating-protocol.md` §15 and `claude-conversion/provenance-and-audit-evidence.md` §5.4. Date: 2026-11-22, about 22:00Z.

```text
MERGE REPORT
Repository: evo-agi/Execution-Substrate
Accepted audit target: claude/project-thread-a9tcoa-bringup at d6aded1747903013745cc897b2c2d13df53612c6,
  base trunk_dev at b8d6bc3abb8c8c38481c7835824bd79ba26e467b,
  manifest v2 77017ca39f453e2ea9eb477b73518edf2cb957c743c4d98883b0cda32a435786 (upstream origin/trunk_dev)
Audit reports: ci-nomad-vault/05-audit.md (ACCEPT bede334); 05-audit-addendum.md (BLOCK f5510db);
  05-audit-addendum-2.md (AUDIT_PROVENANCE_MISMATCH c291503);
  05-audit-addendum-3.md (ACCEPT d6aded1, no findings),
  SHA-256 e62be46b635130fc95306ba257b44401d8d36bacb01cac79a67cfae98f3de773
Implementation reports: 04-bringup.md, 06-repair-bringup.md, 08-repair-bringup-a6.md, 09-repair-bringup-a7.md
PR: https://github.com/evo-agi/Execution-Substrate/pull/18
PR head before the merge: d6aded1747903013745cc897b2c2d13df53612c6 (git ls-remote refs/pull/18/head
  immediately before the merge call); equal to the audited commit: yes. The merge call carried
  expectedHeadSha = that SHA.
Branch update performed: no. trunk_dev was still b8d6bc3 (git ls-remote immediately before the merge),
  the audit base; GitHub mergeable_state "clean".
Go: David 2026-11-22 20:22Z (no review of doc and script changes), relayed by the coordinator with
  the merge request at 21:57Z. Red-team: none, coordinator's judgment (privilege reduction, no
  product code, UID/GID paths mutation-tested by the audit).
Codex bot review: marking the PR ready started it at 21:58:16Z; completed 21:59:09Z with no
  findings, before the merge.
Merge: squash, title "Run ES as the operator in the generic bring-up (#18)".
Merge commit and resulting trunk_dev: 3a5f25776274b3e9ada3e2d489c9bfe0e8bf8a28,
  parent b8d6bc3abb8c8c38481c7835824bd79ba26e467b.
Post-merge byte check: for each of the 8 manifest paths, the blob in origin/trunk_dev has the
  manifest's SHA-256, size and mode (100755 for scripts/05_start_es.sh, 100644 for the rest).
  The merged tree 9be504588d946443defcf476100453e5ca7e92c1 equals the audited head's tree.
Unauthorized effects: none. The PR was marked ready, then squash-merged. GitHub deleted the source
  branch claude/project-thread-a9tcoa-bringup on merge (repository setting).
Deviation: the squash message ends with "Co-Authored-By: Claude [model withheld] <noreply@anthropic.com>",
  which names the model. The request said no model name in the message; PR #17's merge used
  "Co-Authored-By: Claude <noreply@anthropic.com>". Correcting it would need a rewrite of
  trunk_dev history (force-push), which needs David's go; I did not do that. Later merge and
  commit messages in this track use "Claude" without a model name.
Remaining limitations: trunk_dev has no CI workflow until PR #14 lands, so no check ran on the
  merge; the runner evidence is the probe runs in 06-repair-bringup.md and 07-services-nonroot.md.
Branches for David to delete: claude/project-thread-a9tcoa-bringup-probe at
  4667d92eed25cad49a27dacde3dd1595e4598d2e. It is still in use: the services-nonroot runner run
  on that SHA is in progress (expected to finish about 22:20Z). It can be deleted after that run;
  if a later repair needs the runner again, I recreate it.
Report delivery: ci-nomad-vault/10-merge-pr18.md (this file).
```
