# 26-audit-pr19-o24-1 evidence (ES PR #19, head f109af4)

Written by the independent audit thread "Audit bring-up running as the operator", 2026-11-23, 10:22Z to 10:55Z.
Every file here was produced in the audit's cloud container. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../26-audit-pr19-o24-1.md`.

## Setup

- Same container, toolchain (Go 1.26.5, `GOTOOLCHAIN=local`) and test users as `24-audit-pr19-repair2`:
  - `ci` = 1500:1600, groups cigrp (1600) and docker (996), passwordless sudo;
  - `ci2` = 1700:1700, groups docker and cigrp, no sudo.
- Kernel 6.18.44. The host's `pid_max` is 32,768; a container's PID namespace has 4,194,304.
- Trees come from `git archive f109af4`: `/home/ci/es25` (ci) and `/home/ci2/es25` (ci2). Their `scripts/` equal the ab1fadb tree's.
- Every test run starts with `env -i` and sources `ci-env.sh.txt` or `ci2-env.sh.txt`.
- The test's check image is its own `execution-substrate/ars-storage-check-test:alpine-3.20` (Alpine 3.20, BusyBox 1.36.1).

## Files

| File | What |
| --- | --- |
| manifest-v2-open-f109af4-run1.json, -run2.json, manifest-v2-close-f109af4-run1.json, -run2.json | Base-pinned manifest (base bc9fe36, upstream origin/trunk_dev), taken first (10:22Z) and last (10:49Z): e3f8032c…b58c all four times, byte-identical to the writer's |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start and the end (branch f109af4, trunk_dev bc9fe36 both times) |
| ci-check-runs-pr19-f109af4.txt | PR #19's check run on f109af4 (success), and what its job log shows about the es/app run |
| delta-ab1fadb-f109af4.diff | `git diff ab1fadb f109af4`, byte-identical to the writer's patch |
| unit25.sh.txt, unit-tests-f109af4-uid1500-gid1600.log, unit-tests-f109af4-uid1700-gid1700.log | vet, gofmt, `bash -n`, the launcher, bring-up, storage-check and stop tests, and `go test . -run Doc`, keeping the fan-out test's count line. ci: 111 pass. ci2: 105 pass, 6 sudo skips. Count 536 for both |
| mutants25.py.txt, mutants25-uid1500-gid1600.log, mutants25-uid1700-gid1700.log | P, V and T rows as both users: per-directory work caught (P01 to P03); a probe that misses the counted namespace passes (V02, V03: A26-1); the proposed fix catches both and keeps the real check passing (T00 to T03) |
| mutants25-wrap-uid1500-gid1600.log | W rows as ci: the helper's namespace `pid_max` lowered to 32,768; the guard passes the real check (W00), catches a wrapped per-directory walk (W01), and is needed (W02 passes without it) |
| pid_cost25.sh.txt, pid-cost-docker-exec-and-join.log | Each `docker exec` and each container joining the helper's namespace takes 5 or 6 of its PIDs (O26-1); the helper's `pid_max` and boot ID |
| ci-env.sh.txt, ci2-env.sh.txt | The environment of every test run |

## Sensitive material

The tests and fixtures are synthetic. No key, certificate body, token or config file is copied here.
A pattern scan for private-key headers, certificates, and Vault, JWT, GitHub, Anthropic and AWS token shapes
found nothing.
