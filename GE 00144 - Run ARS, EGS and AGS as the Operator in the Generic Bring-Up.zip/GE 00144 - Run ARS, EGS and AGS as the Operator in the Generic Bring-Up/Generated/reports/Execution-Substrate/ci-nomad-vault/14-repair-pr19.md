# PR #19 repair: the ARS storage check does what ARS does, as ARS (A12-1, A12-2)

Report 14 of the CI Nomad/Vault track. It answers the coordinator's request of 2026-11-23 00:41Z: "The PR 19 narrow audit of 07a422b is BLOCK on A12-1 and A12-2 (low) … Before patching these two, check whether the storage check can become structural. Instead of emulating permissions, perform the real operations ARS needs (traverse, read, create a temp file, rename over the index, remove) as the exact identity ARS runs with, through the same mount layout. For example, run a short probe container with the same --user and mounts as ARS, or use setpriv --clear-groups on the host. Prefer that if it's feasible and portable to the supported hosts. Otherwise fix A12-1 and A12-2 directly and explain why. Either way, keep the existing tests, add tests for both findings, merge trunk_dev f62d024 in, pin the manifest upstream, and report as 14-repair-pr19.md."

Date: 2026-11-23. Repository: `evo-agi/Execution-Substrate`, draft PR #19. Evidence: `14-repair-pr19-evidence/` next to this file. `README.md` there names every file, and `SHA256SUMS.txt` lists them.

## 1. Outcome

| Item | Result |
| --- | --- |
| Structural check | **Feasible and done.** The emulation is gone. The check now runs a short-lived container exactly as ARS will run: the same image, the same `--user UID:GID`, the same mounts and ARS's container name. In it, a BusyBox shell does what ARS does with its storage, and the kernel decides every step. |
| Why a container and not `setpriv` | `setpriv --clear-groups` runs on the host. It sees the host's directories above the mounts, which ARS never sees, and it does not exist on macOS. Only the container sees what ARS sees (section 3.2). |
| A12-1 | Closed. The probe changes into every directory on the way to the storage root and the index directory, inside the container. A directory between the index directory's mount and a deeper root that the identity cannot search is refused with its path. |
| A12-2 (a), sticky index directory | Closed. After every other step passed, the check writes the index the way ARS does: a new `0600` file with the index's content, renamed over it. In a sticky directory where the identity owns neither the index nor the directory, the kernel refuses the rename, and so does the check. |
| A12-2 (b), symlinked index | Closed. An index that is a symbolic link is refused on the host, before any container, because ARS replaces it with a regular file at its first write. |
| O-12-1 (stricter than needed) | Closed for both layouts: C08 (a supplementary group class that denies the caller) and C10 (an ACL that grants a non-owned entry) now pass, as the kernel allows. One stricter case remains, on purpose (section 3.6). |
| O-12-2 (test gaps) | Rows added for GID 0 (Q07), a symlinked root (Q27) and the group class without sudo (Q14). Q01, Q04, Q22 and Q17 targeted emulation code that no longer exists. |
| Existing tests | Kept: 25 ARS storage rows at `07a422b`. 21 stand unchanged, 4 had their expected outcome changed because the kernel now decides (section 4.2). 14 rows are new, so there are 39. |
| Links and special files in storage | **Refused** (new in `be71f84`). ARS never creates them. My first version skipped them, and my own mutant run showed that a skipped link can lead ARS to a directory it cannot use: layout C34 passed the check at `08180e7` while ARS's container was denied (section 3.6). |
| Comparison | On the audit's 24 layouts plus 10 new ones, the check matches what the identity can do in ARS's own container in 31 of 34. It is stricter in 3: C27 on purpose, and C32 and C33 (a link and a FIFO inside storage) by design. It is looser in none (section 6.3). |
| Head | `be71f84743bd247aef642726b6e8cc45a2f844cb` |
| Base | `f62d0245e95e2b411be16511fc1bf9e1da727ce5` (trunk_dev, PR #16), merged in, no rebase |
| Manifest | `cf8e81bea474e568bb90823217b5a088a5d3f9e686c81771a1867d0e4ebfdea5`, 12 files |
| CI | PR CI [run 45101384405](https://github.com/evo-agi/Execution-Substrate/actions/runs/45101384405) green; runner probe [run 45101395402](https://github.com/evo-agi/Execution-Substrate/actions/runs/45101395402) green (section 6) |

## 2. Target identity

| Field | Value |
| --- | --- |
| Branch | `claude/project-thread-a9tcoa-services-nonroot` |
| Head | `be71f84743bd247aef642726b6e8cc45a2f844cb` |
| Commits since `07a422b` | `88d5f61` (merge of trunk_dev `f62d024`, PR #16; no file overlap, no conflict), `08180e7` (the structural check) and `be71f84` (links and special files in storage refused) |
| Base | `f62d024`, upstream `origin/trunk_dev` |
| Manifest tool | `governed_execution_audit_patch_manifest_v2.py`, sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Manifest | `cf8e81bea474e568bb90823217b5a088a5d3f9e686c81771a1867d0e4ebfdea5` (`manifest-v2-pr19-be71f84.json`) |

The manifest was taken twice by the v2 recipe: umask 022, a fresh clone of the branch, HEAD checked to be `be71f84`, trunk_dev fetched and checked to be `f62d024`, `git reset --mixed f62d024`, `git branch --set-upstream-to=origin/trunk_dev`, then the tool with `python3 -I`. Both runs are byte-identical (`manifest-run1.out.txt`, `manifest-run2.out.txt`). It lists 12 files with textual diff sha256 `f3f66526b7cf364bce88e69b83bcd137a69f23667b1dee59280b76f47ba01d44`, the same 12 files GitHub shows for the PR against trunk_dev:

| File | Change |
| --- | --- |
| `.docs/system_overview/configuration.md` | modified |
| `.runbooks/system/v1_bringup.md` | modified |
| `PLANS.md` | modified |
| `es/app/operator_scripts_integration_test.go` | modified (unchanged since `07a422b`) |
| `es/app/service_launchers_container_user_test.go` | new |
| `scripts/01_bringup.sh` | modified |
| `scripts/02_start_ars.sh` | modified |
| `scripts/03_start_egs.sh`, `scripts/04_start_ags.sh`, `scripts/05_start_es.sh` | modified (unchanged since `07a422b`) |
| `scripts/generate_control_plane_dockerfile.sh` | modified (new in this repair: a comment) |
| `scripts/internal/control_plane.sh` | modified |

The delta for the narrow audit is in two files: `delta-07a422b-be71f84-scripts-docs.diff` (scripts and docs, `07a422b..be71f84`, without PR #16's file) and `delta-88d5f61-be71f84-test.diff` (the test file, from the merge to the head). `delta-08180e7-be71f84.diff` shows the last commit on its own.

## 3. The repair

### 3.1 What the check does now

`verify_ars_storage_for_operator CONFIG UID:GID` (`scripts/internal/control_plane.sh`) has two parts.

**On the host, as the caller.** It only reads the config and prepares the bind sources:
- `storage.root_dir` and `storage.index_file` must be absolute.
- A missing storage root is created as the caller. Otherwise Docker would create the bind source as root.
- The index must already exist as a regular file, under `lstat`. ARS refuses to start without it, and replaces it with a regular file at its first write, so a symbolic link is refused (A12-2 b).
- A root or index the caller cannot reach is refused with its path, as before.

**In a container, as ARS's identity.** `docker run --rm --name <ARS's container name> --network none --user UID:GID -v <ARS's mounts> --entrypoint /bin/sh <control-plane image> -c <probe> ars-storage-probe ROOT INDEX`. The mounts come from `control_plane_mount_specs ars`, the same function `02_start_ars.sh` uses for ARS. The probe, in order:
1. changes into every directory on the way to the storage root, and then on the way to the index directory, from `/`;
2. creates and removes a file in the index directory, and reads the index;
3. walks the storage root: in every directory it changes into it, creates and removes a file, and lists it; it opens every regular file for reading; a symbolic link or a special file is refused (kind `entry`), because ARS never creates one there and a link could lead ARS somewhere it cannot write (section 3.6);
4. last, only when everything above passed, writes the index the way ARS does (`ars/index/fileindex.go:162-187`): a new `0600` file with the index's current content, renamed over it.

Every step is an operation ARS performs: ARS stats and opens its root and index at startup, and writes blobs and the index as a temp file plus a rename (`ars/store/filesystem.go:128-153`). The probe never asks for a permission decision. It does not use `test -r`, `-w` or `-x`, because BusyBox decides those from mode bits itself and ignores ACLs (mutant M17, section 6.4, shows this). `cd`, `mktemp`, `rm`, `ls`, `<` redirection, `cat`, `chmod` and `mv` are system calls the kernel decides.

A refusal is one record on the probe's stdout, `REFUSE<TAB>kind<TAB>message<TAB>path`, and exit code 42. The host part formats it exactly as before: the message, "as UID:GID", the path, and the `sudo chown` hint (`-R` for the storage root, plain for the index or its directory). A directory above the storage gets "give that identity search permission on this directory, or choose a path it can reach" instead, because a `chown` there would be wrong. A link or special file inside the storage gets "ARS creates only directories and regular files there; replace a link with what it points to, or move the entry out of storage.root_dir", again without a `chown` hint and without "as UID:GID", because no identity could use it. Any other failure of the container is reported with Docker's own message.

### 3.2 Why a container, not `setpriv`

The coordinator offered both. I chose the container for three reasons:
- **It sees what ARS sees.** ARS sees only its bind mounts. The directories above a mount point are Docker's own, in the image. `setpriv` on the host would walk the host's directories above the storage, which ARS never touches. Comparison layout C30 shows the difference: storage that ARS can use below a host directory with an ACL that denies the identity. `setpriv` refuses it, ARS's container allows it, and the check passes, correctly. A12-1 itself is the opposite case: ARS reaches the root through its one mount and an intermediate directory, and only a check through the same mount sees that directory the way ARS does.
- **It is portable to the supported hosts.** Bring-up runs ARS in Docker on Linux and macOS. `setpriv` is util-linux and does not exist on macOS; there, Docker Desktop's file sharing decides access to bind mounts, not the Mac's own permission rules. A container through the same Docker decides it the same way for the check and for ARS.
- **Nothing is emulated.** Owners, groups, modes, POSIX ACLs and their masks, the sticky rule, setgid directories, `CAP_DAC_OVERRIDE` for UID 0, read-only mounts and SELinux labels all reach the check exactly as they reach ARS.

What it needs:
- **Docker and the image.** Both are already required: the check runs right after `ensure_control_plane_image`, in both callers.
- **A shell in the image.** The probe needs `/bin/sh` with `mktemp`, `ls`, `cat`, `chmod` and `mv`. The generated control-plane image is `alpine:3.20`, whose BusyBox provides them. The supported-local setup builds its image from the same generator. A comment in `scripts/generate_control_plane_dockerfile.sh` now says so, and the PLANS entry states the requirement.

### 3.3 Exclusivity and the index rewrite

The check writes the index (step 4), so it must not run while ARS runs.
- **The container uses ARS's name.** Docker refuses to create a second container with that name, so the check cannot start while an ARS container exists, running or not. The refusal says "ARS's container still exists, so stop it first, for example with scripts/01_bringup.sh down". `01_bringup.sh down` removes the container even when its PID file is gone.
- **`02_start_ars.sh` removes the container it replaces before the check** (it removed it right after the check before). It always replaced a running ARS; now the check runs between the removal and the new start.
- **`01_bringup.sh up`** runs the check before starting any service, as before. If an ARS container is left from an earlier `up` without `down`, `up` now stops at the check with that message. Before, it replaced the container silently, or stopped later with "ars is already running" when the PID was alive.

The rewrite has the same effect as ARS's own first write: the index keeps its content, becomes a new inode owned by the identity with mode `0600`, and its old inode goes away. Nothing else changes. A refusal before step 4 leaves storage as it was, except a root created in the host part. The probe's temp files are removed on every path; a trap removes the last one if a step after its creation fails. The test rows check both: an untouched index after a refusal, a rewritten index after a pass, and no leftover in either case.

### 3.4 What changes for an operator

| Storage | `07a422b` | This repair |
| --- | --- | --- |
| Owned by the operator (setup and bring-up create it this way) | accepted | accepted; the index is rewritten as `0600` |
| Shared through the operator's primary group | accepted | accepted |
| Shared only through a supplementary group (A11-1) | refused | refused |
| Root-owned and private (an earlier root bring-up) | refused with the hint | refused with the hint |
| Root below the index directory, behind a directory ARS cannot search (A12-1) | **accepted, ARS fails at start** | **refused**, with the directory |
| Index in a sticky directory, owned by someone else (A12-2 a) | **accepted, ARS's first index write fails** | **refused** with the index `chown` hint |
| Index that is a symbolic link (A12-2 b) | **accepted, ARS fails at start** | **refused** before any container |
| Not owned, with an ACL that grants the operator | refused (could not evaluate ACLs) | accepted |
| Not owned, with an ACL that denies the operator | refused | refused |
| A group class that denies a supplementary group of the caller, other class allows (C08) | refused | accepted |
| macOS | every entry had to be owned by the operator | whatever Docker Desktop lets ARS do |
| An ARS container from an earlier `up` still exists | `up` replaced it | `up` refuses; run `down` first |
| A symbolic link or special file inside the storage | not looked at | refused, with the entry's path |

### 3.5 Cost

- One more container start per check, about 0.3 to 0.35 seconds in the cloud container on a small storage tree (`check-timing.log`, five runs on `be71f84`). `01_bringup.sh up` checks twice, once before any service and once in `02_start_ars.sh`.
- The walk starts three short processes per storage directory (`mktemp`, `rm`, `ls`). ARS's two-level `sha256/xx/` layout gives at most a few hundred directories in practice.

### 3.6 Remaining differences from ARS's view

- **The host part runs as the caller.** It needs to see the index and the root, to refuse a symbolic link or create a missing root. The caller is ARS's identity plus supplementary groups, so it reaches at least what ARS reaches, except where a group class or ACL entry for one of the caller's supplementary groups denies more than the other class. Then the check is stricter and says "as you". Comparison layout C27 shows it with a synthetic identity that is not the caller. I kept this rather than letting Docker create missing bind sources as root.
- **Symbolic links and special files inside the storage are refused, not followed.** ARS creates only directories and regular files there: it never enumerates its storage (no `Walk`, `ReadDir` or `Lstat` in `ars/`), and it writes a blob with `MkdirAll`, `CreateTemp` and `Rename` by path (`ars/store/filesystem.go`). So it never makes a link, but it would pass through one that someone else put there. A shard directory that is a link to a directory ARS cannot write makes ARS fail at its next blob write in that shard. My first version (`08180e7`) skipped links, and layout C34 shows the gap: a shard linked to a `root:root 0700` directory in the index directory, which ARS also mounts. `08180e7`'s check passed it, and ARS's container is denied (`kernel-comparison-08180e7-c32-c34.log`). Following links instead would mean deciding where each link leads, inside or outside ARS's mounts, which is the kind of emulation the container exists to avoid. Refusing them is simple and loses nothing ARS made. The cost is two stricter layouts: C32, a link to a directory inside storage that ARS could use, and C33, a FIFO, which ARS never opens.
- **The check proves what ARS does at its first write, not later.** Storage that changes after the check, or a disk that fills, is out of scope, as before.

## 4. Tests

`es/app/service_launchers_container_user_test.go`. Every row that reaches the container part runs it in real Docker, as the identity the row names, with the image tagged `execution-substrate/ars-storage-check-test:alpine-3.20` from `alpine:3.20` (pulled if missing). Only ARS's own container is faked. Those rows skip on hosts other than Linux and when no Docker daemon answers; the GitHub runner has Docker, so PR CI runs them, and its gate fails any unlisted skip.

### 4.1 New pins for every row that reaches the container

The fake Docker records the check container's arguments. The test requires them to be exactly `run --rm --name <ARS's container name> --network none --user <the row's identity>`, then ARS's mounts as the launcher passes them to ARS, then `--entrypoint /bin/sh <the configured image> -c <probe> ars-storage-probe <root> <index>`. So "the same identity, mounts, name and image as ARS" is a tested property, not a comment.

### 4.2 Rows whose expected outcome changed

| Row at `07a422b` | Now | Why |
| --- | --- | --- |
| storage the identity does not own refused where ACLs cannot be read | storage shared through the identity's GID accepted where Python cannot read ACLs | The check reads no ACLs. The Python hook stays, so a host without ACL reads is still covered; the fixture now shares the storage through the identity's group (the audit's Q14 row, without sudo). |
| storage whose access ACL cannot be read refused | storage shared through the identity's GID accepted where reading an ACL fails | Same. |
| storage entry the check cannot reach refused (root identity, caller cannot search) | storage entry the caller cannot reach accepted for a root identity | The walk runs as root in the container, which may search it (O-12-1). |
| storage with an access ACL that the identity does not own refused | storage with an access ACL that grants the identity accepted, plus the new row storage with an access ACL that denies the identity refused | The kernel decides ACLs now. |

The other 21 rows are unchanged in fixture and outcome. Some refusal messages changed wording (for example "ARS cannot search this directory as UID:GID: PATH"), and their expected text with them.

### 4.3 New rows

| Row | Pins |
| --- | --- |
| storage root behind a directory the identity cannot search refused | A12-1 (the audit's suggested fixture: 4242:4343, intermediate directory 0700 owned by the caller) |
| storage root below the index directory accepted | the same layout with a searchable intermediate directory |
| index in a sticky directory the identity owns neither of refused | A12-2 (a), and the index is left untouched |
| index the identity owns in a sticky directory accepted | the sticky rule's other side (audit C24) |
| index that is a symbolic link refused | A12-2 (b) |
| identity with GID 0 refused on storage only its owner may use | O-12-2 Q07 |
| symlinked storage root accepted | O-12-2 Q27 |
| passing check rewrites the index like ARS and leaves nothing behind | step 4: same content, new inode, `0600`, owned by the caller, no temp files |
| check refused while an ARS container exists | exclusivity, with the `down` hint, index untouched |
| storage with an access ACL that denies the identity refused | the kernel's ACL decision |
| hidden storage file the caller cannot read refused | the walk covers names that start with a dot |
| unreadable index refused before the storage walk | the order of steps 2 and 3 |
| storage holding a symbolic link refused | a shard directory that is a link (3.6); the index is left untouched |
| storage holding a special file refused | a FIFO in a shard directory; the index is left untouched |

Every row that expects no `chown` hint now also fails if the output contains `chown`, so the hint cannot leak into a refusal where it would be wrong.

The bring-up test's second scenario now runs the check container in real Docker as 4242:4343 and requires `up` to stop at it, once, after the host-loopback probe and before any service. Its expected refusal is the probe's ("ARS cannot create files in this directory as 4242:4343") instead of the emulation's.

## 5. Docs

- `PLANS.md` `GENERIC-SERVICE-LAUNCHER-USER-01`: the check's description, the image requirement, the exclusivity, the index rewrite, and the refusal of links and special files inside storage ("ARS never creates one").
- `.docs/system_overview/configuration.md` (ARS section) and `.runbooks/system/v1_bringup.md` (what bring-up checks before any service): the same, in the operator's terms, including "run `scripts/01_bringup.sh down` first" and the refusal of links and special files.
- `scripts/01_bringup.sh`, `scripts/02_start_ars.sh` and `scripts/generate_control_plane_dockerfile.sh`: comments.
- No docs contract test pins the changed text; the docs tests pass.

## 6. Validation

### 6.1 PR #19's own CI

PR #14's gate on `be71f84`, [run 45101384405](https://github.com/evo-agi/Execution-Substrate/actions/runs/45101384405), job "build, vet and test": **success**. Log: `ci-pr19-45101384405-job137452785872.log`.
- `ok execution-substrate/es/app 83.109s`; the root package `ok` in 117.9 s.
- "test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed", then "all 15 listed tests still fail on this host, each in a run of its own and in the run of its package".
- The 37 `es/app` tests that skipped themselves are the listed Nomad tests, as before. None of this PR's tests skipped, so every ARS storage row ran its check container in the runner's real Docker, including the sudo, supplementary-group and `setfacl` rows. The gate would have failed on any unlisted skip.

### 6.2 Runner probe

**Run [45101395402](https://github.com/evo-agi/Execution-Substrate/actions/runs/45101395402) on `be71f84`** (probe commit `f1c626e`, whose tree is the head plus `.github/workflows/probe-services-repair.yml`): **success**. Log: `runner-45101395402-job137452822544.log`; workflow: `probe-services-repair.yml.txt`. GitHub-hosted ubuntu-24.04, rootful Docker, pinned Nomad, Vault and SPIRE.
- Launcher tests (`TestESLauncherContainerUser`, `TestServiceLaunchersContainerUser`, `TestBringupUpChecksARSStorageBeforeStartingServices`) as `runner` (1001:1001; passwordless sudo, supplementary groups, `setfacl`): exit 0, 75 subtests passed, **0 skipped**. The step fails on any skip.
- `TestBringupScriptUpCheckDownFullProfile` as `runner`: passed in 63 s. The ARS, EGS, AGS and ES logs all show `--user 1001:1001`, and 0 root-owned entries were left. So the check passed twice on real bring-up storage (in `up` and in `02_start_ars.sh`), and ARS then started on the rewritten index and served the execution loop.
- A second operator 2500:2600 (supplementary group `docker`, no sudo): launcher tests exit 0 with the 4 sudo rows skipped (report 13's three plus the new ACL-deny row); bring-up passed in 63 s, all four logs show `--user 2500:2600`, 0 root-owned entries.
- The docs tests pass. Whole `es/app` (informational) fails only the three known pre-existing tests: `TestSupportedLocalSetupExactGoPreflightBeforeMutation`, `TestSupportedLocalProofExactGoPreflightBeforeMutation` and `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`.

### 6.3 Comparison with what ARS's identity can do

`kernel_compare14.py` (with the Go probe `kprobe14`, source `kprobe14-main.go.txt`) adapts the audit's `kernel_compare12.py`. For each layout it builds a fresh fixture three times and asks:
- **the host reference**: `kprobe14` under `setpriv --reuid U --regid G --clear-groups` on the host paths (the audit's reference);
- **the container reference**: `kprobe14` in a container from the same image with `--user U:G` and ARS's exact mounts (`control_plane_mount_specs ars`), the view ARS itself gets;
- **the check**: `verify_ars_storage_for_operator` from the head tree, run as bring-up runs it (as the `ci` user 30033:30033 with supplementary group 996, or as root for identity 0:0).

Each reference creates and removes a file in the index directory and every storage directory, reads the index and every file, and replaces the index the way ARS does. The references follow symbolic links to directories when they list storage, because ARS passes through them. Three layouts are new since `08180e7`: C32 (a shard directory that is a link to an owned directory inside storage), C33 (a FIFO in a shard directory) and C34 (a shard directory that is a link to a `root:root 0700` directory in the index directory, which ARS also mounts). Log: `kernel-comparison-be71f84.log` (one JSON line per case, then the table).

| Result | Cases |
| --- | --- |
| Check agrees with ARS's view (container reference) | 31 of 34: C01–C26, C28–C31, C34 |
| Check stricter than ARS's view | 3: C27 (identity 4242:0 on storage `root:0 0770`; the host part runs as `ci`, who is not in group 0; on purpose), C32 and C33 (a link and a FIFO inside storage; by design). Section 3.6 |
| Check looser than ARS's view | 0 |

C34 is the case that made me change the walk. On `08180e7`, whose walk skipped links, the same comparison gives "CHECK PASSES, ARS FAILS" for C34, and C32 and C33 agree (`kernel-comparison-08180e7-c32-c34.log`, run with `KC_CASES=C32,C33,C34`). On the head, C34 agrees: the check refuses and ARS's container is denied.

The two references differ in C25 and C30, and the check follows the container in both:
- C25 (A12-2 b, symlinked index): the host follows the link; in ARS's container the link points outside the mount and dangles. The check refuses on the host side before any container.
- C30 (an ACL that denies the identity on a host directory above the storage): `setpriv` on the host is denied; ARS's container never sees that directory and is allowed. The check passes, as ARS would work.

The audit's red cases now refuse: C03 (A11-1), C18 (A12-2 a), C19 (A12-1), C25 (A12-2 b). The audit's stricter cases C08 and C10 (O-12-1) now pass, as the kernel allows.

### 6.4 Mutants

`mutants14.py` applies each mutant to a fresh copy of the head tree and runs `TestServiceLaunchersContainerUser` and `TestBringupUpChecksARSStorageBeforeStartingServices` as the invoking user. A mutant is caught when the tests fail. 43 mutants cover how the check container runs (user, mounts, name, image, network), each step of the probe, the refusal record and exit code, the host part and its hints, both callers' order, and the link and special-file refusal (M16 skips links again, M38 follows them, M39 skips special files, M44 drops the `entry` kind's message, M45 gives it the storage `chown` hint).

Logs: `log-mutants-uid30033.log`, `log-mutants-uid31500.log` (unmutated tree first: it passes in both).

| Identity | Caught | Survive |
| --- | --- | --- |
| 30033:30033, passwordless sudo | 42 of 43 | M25 |
| 31500:31600, no sudo | 41 of 43 | M17, M25 |

- **M25** (no `chmod 600` before the index rename) is equivalent: BusyBox `mktemp` creates the file with mode `0600` already.
- **M17** (a stored file checked with BusyBox `[ -r ]` instead of a real read) is caught only by the row with an ACL that grants the identity, which needs `setfacl` and sudo to give the storage away; there BusyBox's mode-bit answer refuses what the kernel allows. Without sudo that row skips, so M17 survives as `ci3`. The runner has sudo and runs that row (6.1, 6.2).
- The finding mutants are all caught as `ci`: M18 and M34 (A12-1, the reach steps), M19 (index directory reach), M23 and M37 (A12-2 a, the index rewrite and its message kind), M31 (A12-2 b, `stat` instead of `lstat`).
- The link and special-file mutants are caught by both users: M16 (links skipped again, the `08180e7` behaviour), M38 (links followed), M39 (special files skipped), M44 (the `entry` kind loses its message) and M45 (the `entry` kind gets the storage `chown` hint).

An interim run on `08180e7` (`log-mutants-interim-08180e7-uid30033.log`, 39 mutants) was what showed the gap: the old M16 ("walk follows links") survived there, and building the layout behind it (C34) showed storage that passed the check while ARS's container was denied. That led to `be71f84`.

### 6.5 Cloud container, three identities

The two test functions, `gofmt -l es/app`, `go vet ./es/app` (linux and `GOOS=darwin GOARCH=arm64`) and `bash -n` on the launchers and `control_plane.sh`, on trees whose 12 changed files match `be71f84` byte for byte:

| Identity | Result | Log |
| --- | --- | --- |
| 30033:30033, supplementary group 996 (`docker`), passwordless sudo | gofmt, vet (both), `bash -n` clean; 63 + 3 subtests pass, 0 skipped | `log-tests-uid30033.log` |
| 31500:31600, supplementary group 996, no sudo | clean; 62 pass, 4 skipped (the sudo rows: "needs passwordless sudo to give the storage to another owner") | `log-tests-uid31500.log` |
| 0:0 | 50 pass, 16 skipped ("root bypasses the permission bits this case relies on") | `log-tests-uid0.log` |

### 6.6 Red on `07a422b`

The head's test file on `07a422b`'s scripts (`log-red-be71f84-tests-on-07a422b-uid30033.log`): 41 of 63 launcher subtests and 1 of 3 bring-up subtests fail. This red is not sharp row by row, because `07a422b` runs no check container, so every row that reaches one fails at the check-arguments pin. The finding rows are among the failures (the symbolic-link index, the root behind a directory the identity cannot search, both sticky rows), but the evidence that each finding is closed is the comparison (C18, C19 and C25 refuse now; the audit showed them passing at `07a422b`) and the mutants that reopen each one (M18, M19, M23, M31, M34, M37).

The two new rows on `08180e7`'s script (`log-red-new-rows-on-08180e7-uid30033.log`): both fail, because the check passes and the launcher goes on to start ARS (a second `docker run`).

### 6.7 Whole root package and the SPIRE setup test (informational)

- Root package as 30033:30033, on `08180e7`: it fails 29 tests, all of which also fail on the base `f62d024` in the same container (32 failures there; the head adds none). They need the Remote Alpha host's `ds` user, a writable `/var/tmp/execution-substrate-remote-alpha` and the repository's git metadata. On the runner the root package passes on `be71f84` (6.1). `be71f84` changes, within the root package's reach, only `PLANS.md` and two docs, whose docs tests pass in the container and on the runner. Logs: `log-rootpkg-08180e7-uid30033.log`, `log-rootpkg-base-f62d024-uid30033.log`.
- `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` fails identically on base and head here ("SPIRE server admin socket did not appear"); it passes on the runner. Log: `log-spire-setup-test-base-and-head-uid30033.log`.

### 6.8 Cost

`check-timing.log`, `check-timing.sh.txt`: five runs of `verify_ars_storage_for_operator` on a small storage tree as 30033:30033, on the `be71f84` tree, with the machine otherwise idle: 0.30 to 0.35 seconds each, one container start included.

## 7. Audit items

| Item | Status |
| --- | --- |
| A12-1 | Closed (3.1 step 1; row "storage root behind a directory the identity cannot search refused"; C19) |
| A12-2 (a) | Closed (step 4; sticky rows; C18, C24, C26) |
| A12-2 (b) | Closed (host `lstat`; symlink row; C25) |
| O-12-1 | C08 and C10 now agree with the kernel. The host part keeps one stricter case (3.6). |
| O-12-2 | Q07, Q27 and Q14 have rows. Q22, Q17, Q01 and Q04 targeted removed code; the identity validation that Q01 and Q04 touched is unchanged and still unreachable through the scripts. |
| O-11-2 (setgid storage) | C23 passes in the check and in both references. A bring-up on setgid storage was not run. |
| Links inside storage (found by this repair's own mutants, not by the audit) | Refused in `be71f84` (3.6; two new rows; C32 to C34) |

## 8. Not run, limits

- **macOS.** Nothing ran on macOS. By construction, Docker Desktop decides the check's access the same way it decides ARS's, but that is reasoning, not a run. The supported-local proof on the Mac (`scripts/73_supported_local_proof.sh`) has not run with PR #19.
- **Rootless Docker and user-namespace remapping** stay unsupported for bring-up (PR #18's PLANS text). Under them the check would still decide as ARS's container would.
- **A live ARS on the A12 layouts.** ARS's own failure on C18, C19 and C25 is from the audit's container runs and code reading. Here the reference probe in ARS's container shows the same denials (6.3).
- **The A12 layouts in a live bring-up.** The unit rows run the real launcher, the real check container and real Docker on those layouts; the bring-up test runs the check on real bring-up storage and then ARS on the rewritten index (6.2). A full bring-up that stops at an A12 refusal was not run separately; `TestBringupUpChecksARSStorageBeforeStartingServices` shows `up` stopping at a check refusal before any service.
- **A live ARS on C34.** ARS's failure there is the container reference's denial plus code reading of `ars/store/filesystem.go`; no ARS binary was run on that layout.
- **SPIRE setup test in the cloud container.** `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` fails here identically on the base `f62d024` and on `08180e7` (the SPIRE admin socket never appears in this container). It passes on the runner, where it is not listed and ran (6.1).

## 9. Effects

- Pushed `88d5f61` (the merge of `f62d024`), `08180e7` and `be71f84` to `claude/project-thread-a9tcoa-services-nonroot`, the draft PR #19. No force-push, no rebase.
- Probe branch `claude/project-thread-a9tcoa-bringup-probe`: `39dbd2a` to `8db22d9` (for `08180e7`), then `f1c626e`, a merge of `8db22d9` and `be71f84` whose tree is the head plus `.github/workflows/probe-services-repair.yml` (verified with `git diff`). This session cannot delete the branch; David can delete it when the audits no longer need it.
- PR #19's description updated to describe the structural check and the link refusal.
- Nothing was merged. No live service was touched.

## 10. Handover

Narrow audit of `07a422b..be71f84` on the PR's files, against `11-audit-pr19-addendum.md` (A12-1, A12-2, O-12-1, O-12-2) and this report. The merge `88d5f61` brings in PR #16 only, which touches `es/admission/internal/reliablesubmit/sqlite_physical_test.go` and nothing in this PR. The change is scripts, tests and docs only, so by the project rule no red-team is needed and David does not review it. Points worth the auditor's attention:
- the probe's script (`ARS_STORAGE_PROBE` in `scripts/internal/control_plane.sh`): the order of the steps, the trap, the `REFUSE` record, and that nothing in it asks BusyBox for a permission decision;
- the exclusivity argument (section 3.3): the check writes the index, so it relies on ARS's container name and on `02_start_ars.sh` removing the old container first;
- the refusal of links and special files inside storage (3.6), stricter than ARS in C32 and C33 by design;
- the one stricter case left on purpose in the host part (3.6, C27);
- M25 (equivalent).

The manifest is `cf8e81be…dea5` against `f62d024`, with upstream `origin/trunk_dev`.
