# ES PR #18: repair of narrow-audit findings A6-1 and A6-2

Report 08 of the CI Nomad/Vault track. Follows the narrow audit addendum `05-audit-addendum.md` (BLOCK for `f5510db` on A6-1, SHA-256 `e8003d31…8b51`) and the coordinator's request of 2026-11-22 21:29Z: correct the docs to state the real behaviour, kill the surviving missing-anchor mutant A6-2 with a test, push, and hand over the new head. A6-3, the ES readiness gap, is product code and goes into its own draft PR to trunk_dev; it is not part of this change.

Date: 2026-11-22. Repository: `evo-agi/Execution-Substrate`. Evidence: `08-evidence/` beside this file (`SHA256SUMS.txt` lists every file).

## 1. Outcome

| Item | Result |
| --- | --- |
| A6-1 (runbook said setgid-inherited roots are refused) | **Fixed.** The runbook, `implementation.md` and `capability_probing.md` now say what happens: roots whose group was set directly to another group are refused at startup; roots that inherit another group from a setgid parent are not refused, ES reports ready, and every submission fails with `stage artifact payload failed`, reported as a substrate failure. The runbook tells operators to keep the bring-up workspace out of setgid directories whose group is not their primary group. |
| A6-2 (mutant N12, missing end anchor, survived) | **Fixed.** Two refusal subtests: a UID of `4242x` and a GID of `4343x`. N12 is now caught, and so are two new single-sided mutants, N25 (UID end anchor only) and N26 (GID end anchor only). 26 mutants plus the unmutated run, as two users: all caught. |
| Change | One commit `c291503` on top of `f5510db`. Docs and one test file only; no script or product change. |
| New head | `c29150366dcf063fc68f86a92b8c4ecf9a6d4a5d` (`git ls-remote` after the push) |
| New manifest | `ecde9a9758af1a7fb966c386b6247d6712d68662e0d68205ce1994d5a5b12735` (file SHA-256), base `b8d6bc3`, 8 files, textual diff `0aed15a156ad2aae7c1c3a5e94f85755771b14b0d020afe976480f6edab81656` (section 2) |

Nothing was merged. PR #18 stays a draft.

## 2. Target identity

| Field | Value |
| --- | --- |
| Base | `trunk_dev` at `b8d6bc3abb8c8c38481c7835824bd79ba26e467b` |
| Topic branch and tip | `claude/project-thread-a9tcoa-bringup` at `c29150366dcf063fc68f86a92b8c4ecf9a6d4a5d`, tree `54bbd9c599885e7f7701595b5f26873c4186aedb`, parent `f5510db` |
| Delta since the audited `f5510db` | 4 files, +13 −4: `.docs/execution_lifecycle/implementation.md`, `.docs/system_overview/capability_probing.md`, `.runbooks/system/v1_bringup.md`, `es/app/es_launcher_container_user_test.go`. Full diff: `08-evidence/delta-f5510db-c291503.diff` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` |
| Manifest | Fresh clone from GitHub after the push, `git reset --mixed b8d6bc3`, upstream `origin/claude/project-thread-a9tcoa-bringup`, taken twice into a `0700` directory, byte-identical. 8 files: 7 `tracked_modified`, 1 `untracked` (the launcher test). Copy: `08-evidence/manifest-v2-c291503.json` |

## 3. Changes

### 3.1 A6-1: docs

- `.runbooks/system/v1_bringup.md`, the first item under "ES refuses to start unless": "roots whose group was set directly to another group, for example a shared project group, are refused. Roots that inherit another group from a setgid parent directory are not refused: ES passes its startup checks and reports ready, and then every submission fails with `stage artifact payload failed`, reported as a substrate failure. Keep the bring-up workspace out of setgid directories whose group is not your primary group".
- `.docs/execution_lifecycle/implementation.md` (natural result directory probe): a root whose group was set to another group fails the probe; a setgid root with another group passes it, because the new directory inherits the root's group; staging then clears the setgid bit on the run directory and cannot give a nested directory that group, so ES reports ready but every submission fails to stage.
- `.docs/system_overview/capability_probing.md`: it said ES's startup checks decide whether the operator's identity owns the roots. It now adds that those checks do not yet catch roots that inherit another group from a setgid parent, and that ES then reports ready and staging fails at the first submission.

The wording follows the auditor's required correction. The mechanism is the auditor's (kernel reproduction in `05-audit-addendum-evidence/setgid-kernel-semantics.log`): the run directory gets the root's group from the setgid parent, `Fchmod(0750)` clears the setgid bit, the payload directory gets ES's egid, and `Fchown` back to the root's group fails with `EPERM` because ES has no supplementary groups. "Every submission" follows from that mechanism, as the audit notes, since each submission creates its run directory the same way.

When A6-3 lands, these sentences change again in that PR: ES will refuse the case at startup.

**Correction to `06-repair-bringup.md` §3.3.** That section mapped "the group a setgid parent hands down is refused" to `es/admission/execution_roots.go:575`. That was wrong. Line 575 refuses a natural result directory whose GID differs from the roots' GID. A setgid root hands its own GID to the new directory, so the check passes. Only roots whose group was set directly are refused there. Report 06 is left unchanged because its hash was handed over.

`PLANS.md` and `contracts.md` state the requirement ("the roots must carry the caller's UID and primary GID") and not a refusal claim, so they are unchanged.

### 3.2 A6-2: test

`es/app/es_launcher_container_user_test.go` gains two rows in the existing refusal table:

- "UID with trailing characters refused": fake `id` prints `4242x` and `4343`; the launcher must refuse with "id -u and id -g must print numeric IDs, got 4242x and 4343", having called only `id -u` and `id -g`, with no `docker run`, no run-arguments file and no roots.
- "GID with trailing characters refused": the same with `4242` and `4343x`.

## 4. Checks

| Check | `ci` 30033:30033 | `ci3` 31500:31600 |
| --- | --- | --- |
| `gofmt -l es/app scripts`, `go vet ./es/app`, `bash -n scripts/05_start_es.sh` | clean | clean |
| `TestESLauncherContainerUser`, 8 subtests | pass | pass |
| `go test . -run Doc` | ok | not run (docs tests do not depend on the user) |
| Mutants: the audit's 24 (`N01` to `N24`, with `N00` the unmutated run) plus N25 and N26, each on a fresh copy | 26 caught, unmutated passes | 26 caught, unmutated passes |

Logs: `launcher-test-c291503.log`, `docs-test-c291503.log`, `mutants8-uid30033-gid30033.log`, `mutants8-uid31500-gid31600.log`. Mutant runner: `mutants8.py.txt` is the audit's `mutants6.py` with N25 and N26 added; nothing else changed.

Which subtests catch the anchor mutants: N12 is caught by both new subtests, N25 by the UID one, and N26 by the GID one.

**Runner.** I did not start a separate runner run for `c291503`: the delta is docs and two table rows of a test that needs no Docker, and the test passed as two users here. The GitHub runner runs these two subtests in the next run on the probe branch, because the services tranche (report 07) merges `c291503` before its next runner run. Report 07 records that run.

## 5. Not run, limitations

- The setgid case itself was not re-run. The docs now describe the behaviour the auditor observed. A6-3 will add a regression test for it.

## 6. Effects

- Pushed `c291503` to `claude/project-thread-a9tcoa-bringup` (fast-forward from `f5510db`).
- PR #18 description updated for the new head.
- No merge.

## 7. Request

Narrow audit of `f5510db..c291503` (docs and one test file).
