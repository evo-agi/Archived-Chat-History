# 24-audit-pr19-repair2 evidence (ES PR #19, head ab1fadb)

Written by the independent audit thread "Audit bring-up running as the operator", 2026-11-23, 08:12Z to 09:40Z.
Every file here was produced in the audit's cloud container. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../24-audit-pr19-repair2.md`.

## Setup

- Same container and toolchain as `20-audit-pr19-repair` (Go 1.26.5, `GOTOOLCHAIN=local`).
- Test users:
  - `ci` = 1500:1600, groups cigrp (1600) and docker (996), passwordless sudo;
  - `ci2` = 1700:1700, groups docker and cigrp, no sudo.
- Trees come from `git archive ab1fadb`: `/home/ci/es23` (ci) and `/home/ci2/es23` (ci2).
- Every test run starts with `env -i` and sources `ci-env.sh.txt` or `ci2-env.sh.txt`.
- **Audit image** `execution-substrate/control-plane:audit-ab1fadb` (image id `sha256:6f1d509e…92a8`):
  - its binaries were built from the ab1fadb tree on the container's host toolchain (Go 1.26.5), with `CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build ./cmd/<service>`;
  - es and es-runtime-support were built as ci, because root's module cache lacked their modules;
  - `img23-binaries.sha256.txt` has the hashes;
  - `img23-Dockerfile.txt` is the Dockerfile. Its comment saying the binaries were built in a golang container is carried over from an earlier audit image; this time they were built on the host, as above;
  - `img23-Dockerfile.test.txt` is the one-line test Dockerfile (`FROM` the audit image).

## Files

| File | What |
| --- | --- |
| manifest-v2-open-ab1fadb-run1.json, -run2.json, manifest-v2-close-ab1fadb-run1.json, -run2.json | Base-pinned manifest (base bc9fe36, upstream origin/trunk_dev), taken first (08:13Z) and last (09:31Z): 7c0727f4…9364 all four times |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start and the end (branch ab1fadb, trunk_dev bc9fe36 both times) |
| ci-check-runs-pr19-ab1fadb.txt | PR #19's check run on ab1fadb (success) |
| delta-eda9f7c-e7c8f40-scripts-docs.diff, delta-eda9f7c-e7c8f40-tests.diff | The repair commit: scripts and docs, then tests (byte-identical to the writer's) |
| delta-640e0a1-ab1fadb-scripts-docs.diff, delta-640e0a1-ab1fadb-tests.diff | The stop fix and the cost statement (byte-identical to the writer's) |
| unit23.sh.txt, unit-tests-ab1fadb-uid1500-gid1600.log, unit-tests-ab1fadb-uid1700-gid1700.log | vet, gofmt, `bash -n`, the launcher, bring-up, storage-check and stop tests, and `go test . -run Doc`. ci: 111 pass, 0 skip. ci2: 105 pass, 6 sudo skips |
| kernel_compare23.py.txt, kprobe12.py.txt, kernel-comparison-ab1fadb.log | 59 layouts. Each runs the check, an ops reference in ARS's mounts, and the real ARS binary's storage startup. Result: 51 agree, 8 stricter, 0 looser |
| check_timing23.sh.txt, check-timing-full-fanout.log | One check on ARS's `sha256/xx/yy` layout at full fan-out (65,794 directories, a blob in every shard), four runs: 9.4 to 16.5 s |
| bringup_large_store23.sh.txt, bringup-default-timeout-test.diff, bringup-large-store-full-fanout-in-test-default-timeout.log, -timeline.txt | The real bring-up test as ci, with the audit copy of the test filling ARS's storage to full fan-out before `up` and with `READY_TIMEOUT_SECONDS` unset (default 30 s). PASS; `up` took 34.2 s |
| mutants23.py.txt, mutants23-uid1500-gid1600.log, mutants23-uid1700-gid1700.log | 46 mutants plus the baseline, written independently of the writer's. ci: 39 caught. ci2: 37 caught |
| mutants23-cost-uid1500-gid1600.log, mutants23-cost-uid1700-gid1700.log | The F series against the 30 s fan-out test, run alone: F00 control passes, F01 and F02 caught, as both users |
| c04_sigint_pid1.sh.txt, c04-sigint-pid1.log | Why mutant C04 is equivalent: BusyBox ash as PID 1 with only an EXIT trap runs it on SIGINT and exits 130 |
| ci-env.sh.txt, ci2-env.sh.txt | The environment of every test run |
| img23-Dockerfile.txt, img23-Dockerfile.test.txt, img23-binaries.sha256.txt | The audit image (see Setup) |

## Sensitive material

The tests and fixtures are synthetic. No key, certificate body, token or config file is copied here.
The private service logs stayed in the container. A pattern scan for private-key headers, certificates, and Vault,
JWT, GitHub, Anthropic and AWS token shapes found nothing.
