# 24: Narrow re-audit of the PR #19 audit-20 repair (be71f84..ab1fadb)

Written by the independent audit thread "Audit bring-up running as the operator", 2026-11-23, 08:12Z to 09:40Z.
Read-only. Nothing was pushed, commented, reviewed, merged or changed on GitHub.

Evidence: `24-audit-pr19-repair2-evidence/` (README and `SHA256SUMS.txt` there).

## 1. Verdict: ACCEPT

All three findings of `20-audit-pr19-repair.md` are closed on the exact bytes.

- **A20-1** (paths not in normal form): closed. D10, D11, D12, D21 and D25 are refused on the host, before any container, and the refusal names the form to write.
- **A20-2** (cost on large storage): closed.
  - One check at ARS's full fan-out of 65,794 directories, with a blob in every shard, took 9.4 to 16.5 s in four runs here, where it took 112 s at be71f84.
  - A real `01_bringup.sh up` at full fan-out passed with the default `READY_TIMEOUT_SECONDS`: `up` took 34.2 s, and ARS's readiness wait started only after the launcher's check passed.
- **A20-3** (a `-` component): closed. D13 passes, and D22 is refused at the right directory with the right message.

**Comparison.** On 59 storage layouts against the real ARS binary built from ab1fadb, the check agrees in 51, is stricter in 8 and is **never looser**. The layouts are the 50 of audit 20 plus 9 new ones aimed at the new walk and the normal-form rule.

**The stop and cleanup change** (`78bcce6`, the writer's own find) holds up on review and under my mutants.

**Tests and gate.**
- The tests pass as a user with sudo (111 of 111) and without (105, plus 6 sudo skips).
- CI is green on ab1fadb.
- The manifest is `7c0727f4…9364` at the start and the end, against base `bc9fe36`, which is still trunk_dev.

**The coordinator's two questions:**
- **D23 (report 3.1)**, a second ARS-usable path form that is now refused: stricter than ARS, acceptable and documented (section 4.1).
- **The 65,794-directory timing claim** (10 to 20 s): confirmed here at 9.4 to 16.5 s (section 4.2).

There is one non-blocking observation, O24-1: the 30 s wall-clock bound in the fan-out test is a possible CI flake. Any non-blocking notes are in section 5.

## 2. Gate data

| Item | Result |
| --- | --- |
| Recipe `/opt/audit/v2.py` | sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every manifest run |
| Head | `ab1fadb1109469a44509544b48312b14f1e2d75d` (`refs/pull/19/head` and the branch at the start and the end) |
| Base | `bc9fe3619823245faf550db4bf1bc3e782fbd5a5` = `refs/heads/trunk_dev` at the start and the end |
| Upstream | re-pinned to `origin/trunk_dev` |
| Opening manifest (08:13Z) | `7c0727f4b76933d60791cfcc98348b8069bad4f24a121d455a8a52ed3dc39364`, 13 files, textual diff `80c71855…34e7`, twice, byte-identical. Equal to the writer's `manifest-v2-pr19-ab1fadb-run1.json` |
| Closing manifest (09:31Z) | `7c0727f4b76933d60791cfcc98348b8069bad4f24a121d455a8a52ed3dc39364` again, twice, byte-identical to the opening runs. `git ls-remote` at 09:31:59Z: the branch is `ab1fadb`, trunk_dev is `bc9fe36` |
| Writer's report | `23-repair-pr19.md` sha256 `a835706d6813cf81eec32f0343f454a20b9dc2b0b56df24b1dd0cfc80ec9a117`, as stated |
| Writer's evidence | `SHA256SUMS.txt` checks out (72 files) |
| CI on ab1fadb | "build, vet and test" run 45126395110, job 137531591153: success, 06:46:34Z to 07:07:04Z. It is the only check run. There are no legacy statuses |
| Kind of change | scripts, tests and docs only. No non-test Go change from this PR: the only Go outside tests that changed since be71f84 is PR #20's, merged in from trunk_dev |

## 3. What I checked

### 3.1 Delta and merges

| Commit | What it is | My check |
| --- | --- | --- |
| `eda9f7c` | merge of trunk_dev `110d377` (PR #21) | Adds exactly `remote_alpha_es_service_tls_status_test.go`, byte-identical to trunk_dev's. Nothing else differs from be71f84 |
| `e7c8f40` | the repair | `git diff eda9f7c e7c8f40` (8 files): scripts-and-docs and tests diffs byte-identical to the writer's `delta-eda9f7c-e7c8f40-*.diff` |
| `640e0a1` | merge of trunk_dev `bc9fe36` (PR #20) | `git diff e7c8f40 640e0a1` has the same 19 files as `git diff 110d377 bc9fe36`. Patch-ids are equal for all except the runbook, whose +/- lines are identical, so only context differs. No script or launcher test of this PR changes. PR #20 touches no `ars/` and no `scripts/` |
| `78bcce6`, `ab1fadb` | the stop fix and the cost statement | `git diff 640e0a1 ab1fadb` (6 files): byte-identical to the writer's `delta-640e0a1-ab1fadb-*.diff` |

### 3.2 Tests on exact bytes

The trees come from `git archive ab1fadb`. The runs were:
- `go vet ./es/app .`;
- `gofmt` on the test files and scripts;
- `bash -n` on every changed script;
- all launcher, bring-up, ARS storage-check and stop tests, plus `TestSupportedLocalExecutionRoot*`, with no timing changes;
- `go test . -run Doc`, which includes the new docs contract.

| User | Result |
| --- | --- |
| ci 1500:1600 (groups cigrp and docker; passwordless sudo) | 111 pass, 0 skip, 0 fail. Docs: ok |
| ci2 1700:1700 (groups docker and cigrp; no sudo) | 105 pass, 6 skip, 0 fail. Docs: ok. The skips are the sudo rows: supplementary group, primary group, ACL grant, ACL deny, and two `chattr +a` rows |

### 3.3 Comparison with what ARS can do: 59 layouts

`kernel_compare23.py` is my `kernel_compare14.py` from audit 20 with three changes:
- the check is taken from the ab1fadb tree;
- the image is my `execution-substrate/control-plane:audit-ab1fadb`, whose binaries are built from ab1fadb with the generator's `CGO_ENABLED=0 go build ./cmd/<service>`, so the real ARS binary matches the PR's bytes;
- there are 9 new layouts.

Each layout is built three times:
- **check:** the check, as ci or as root;
- **ops reference:** an independent reference container with ARS's mounts;
- **real ARS:** the ARS binary's own storage startup.

Result: 51 agree, 8 stricter, **0 looser**.

| Group | Layouts | Result |
| --- | --- | --- |
| C01-C25: A11-1, A12-1, A12-2 and the addendum's layouts | 25 | all agree |
| D01-D09, D17-D19: chattr, read-only submount, ACL masks and named groups, sticky and setgid | 12 | all agree. The append-only blob directory (D04) now gets the `remove` refusal |
| **A20-1: D10, D11, D12, D21, D25** | 5 | **all agree now**: refused with the normal form to write, and ARS fails at storage startup |
| **A20-3: D13** (usable path through `-`) and D22 (unusable `-`) | 2 | **both agree now**. D22 is refused at `<base>/-` with "ARS cannot search this directory" |
| New: F01 (a file named `*`), F02 (a directory name with a newline and a tab), F09 (a sticky `root:root 1777` storage root) | 3 | agree (usable) |
| New: F03 (`...` holding a root 0700 directory), F04 (append-only index directory), F05 (immutable root), F06 (40-deep chain ending in root 0700) | 4 | agree (unusable). F04 is refused as `remove` in the index directory, and ARS's index replace fails there too |
| Stricter by design, as in audit 20: D14 (a host directory above the mounts that the caller cannot search), D15 (shard link), D16 (FIFO), D20 and F08 (0300 directories the check cannot list) | 5 | check stricter |
| **Stricter from the normal-form rule: D23, D24, F07** | 3 | check stricter (section 4.1) |
| D23 (`..` through a real directory) and D24 (trailing slash on the root) | | ARS can use these |
| F07 (`..` through a symbolic link) | | ARS gets past startup, but stats and writes different directories (4.1) |

The writer's 58 layouts (51 agree, 7 stricter, 0 looser, on `78bcce6`) are consistent with mine where they overlap.

### 3.4 Cost and readiness (A20-2)

- **One check at full fan-out** (`check_timing23.sh`, as ci): 65,794 directories, a blob in every second-level shard. Four runs took 9.4, 14.6, 14.7 and 16.5 s. After each pass, no `.ars-storage-check.*` file was left, and the index was `1500:1600 0600`. At be71f84 the same layout took 112.2 s.
- **Real bring-up at full fan-out with the default timeout** (`bringup_large_store23.sh`, with the audit copy of the bring-up test described in `bringup-default-timeout-test.diff`):
  - The audit copy fills ARS's storage with `writeTestARSShards(…, 256)` before `up` and drops the test's `READY_TIMEOUT_SECONDS=60`. It also logs how long `up` took. Nothing else changes.
  - Result: PASS. "ARS storage filled with 65794 directories". `up` took 34.2 s, with `READY_TIMEOUT_SECONDS` unset, so the default of 30 s applied.
  - The two check containers ran from 08:31:02.8 to 08:31:26.2. ARS's container started at 08:31:26.8, then EGS, AGS and ES. The log shows "waiting for the ARS launcher's storage check", then "ARS launcher storage check passed", then "artifact-registry: … ready=true", and ends with `submit-ready: true`.
  - The `filled 7969 directories` line in that run's timeline is the poller counting the test's own fill in progress (the poller's fill was off, n2=0). It is not a fill of its own.

### 3.5 Mutants (my own, written independently of the writer's)

`mutants23.py` has 46 mutants plus the baseline. Each run uses `-failfast` and an 8-minute go test timeout, with all of this PR's launcher, bring-up and stop tests except the 30 s fan-out test, which runs alone for the cost mutants. The mutants cover:

- K (kept): the check's `--user` and mounts; exit 42; the order of check and `docker rm -f`; `./component`;
- N (normal form);
- W (walk);
- B (batch removal);
- C (the probe's traps and cleanup);
- S (the host part's signal handling);
- L (the launcher's traps and report file);
- U (`up`'s readiness order);
- F (cost).

The main set ran as both users side by side, 08:56Z to 09:24Z. The F series ran alone afterwards, one user at a time, because the fan-out test has a 30 s bound. Both controls (K00 and F00) pass for both users.

| User | Main set (46) | F series (2) |
| --- | --- | --- |
| ci 1500:1600 (sudo) | 39 caught, 7 survived | F01 and F02 caught. F00 control: check 10.0 s |
| ci2 1700:1700 (no sudo) | 37 caught, 9 survived: the same 7 plus B02 and B04 | F01 and F02 caught. F00 control: check 16.0 s |

**The cost mutants.** These are the ones that matter for A20-2, and the 30 s bound catches each of them:
- F01 adds one `ls` per directory (one process per directory, as at be71f84). The walk took 65.9 s as ci and 64.6 s as ci2.
- F02 removes the walk files after every directory instead of every 256. The walk took 120.6 s as ci and 113.5 s as ci2.

**The survivors, one by one:**
- **N05** (`configured_path` returns `normpath(value.strip())` instead of the raw value): equivalent. A value gets past the normal-form test only if it already equals that form.
- **W04** (no `set -C`): a guard. It matters only if the random marker name collides with an existing entry. This is the writer's W12.
- **B05** (the walk list is appended to instead of started again): equivalent except cost, because paths already removed are removed again. This is the writer's B03.
- **B06** (removal after every directory): cost only. The main set leaves out the fan-out test, and F02, which is the same edit, is caught by it.
- **C01** (the cleanup does not first ignore further signals): defence in depth. The host part passes on only one signal. This is the writer's P41.
- **C04** (no INT trap in the probe): equivalent. `c04-sigint-pid1.log` shows why. BusyBox `ash` as the container's PID 1, with only an EXIT trap, catches SIGINT itself, runs the EXIT trap (which is the cleanup) and exits 130 within about 0.1 s. That is the same outcome the INT trap gives. The TERM trap is not equivalent: C03, which removes it, is caught.
- **S08** (the client starts even though a signal already arrived): race-only. The writer's S08 is the same mutant.
- **B02 and B04, ci2 only** (a failed removal is ignored; the left-behind search is skipped): only the `chattr +a` row "ARS storage directory where ARS cannot remove its own file refused" catches them. That row needs sudo, so it skips as ci2. It runs on CI and as ci, where both mutants are caught.

**Stop-fix mutants that were caught:**
- C03 and L01 (no probe or launcher TERM trap), by `TestARSLauncherStoppedDuringItsCheckEndsAfterTheCheck`;
- S01, S04, S05, S06 and S07, by the interrupt test;
- S02 and S03, by the repeated-interrupt test;
- W03 (the marker recorded after it is created), by an interrupt test hitting the window between the two: the repeated-interrupt test as ci, the single-interrupt test as ci2;
- B01 (no removal during the walk), by the kill test;
- L02, L03, U01, U02 and U04, by the readiness-order test;
- U03 and L04, by the test where the launcher stops before its check passes.

## 4. The coordinator's questions

### 4.1 D23: a second ARS-usable path form refused

**Verdict: acceptable, and documented.** Keep the rule as it is.

- **It is my own recommended rule.**
  - Audit 20 recommended refusing any value where `value != value.strip()` or `os.path.normpath(value) != value`. That rule refuses every `.` and `..` component, including a `..` that happens to resolve to a usable directory (D23).
  - My section 6 line "no new stricter layout beyond the documented trailing slash on the root" was imprecise. The rule I recommended necessarily also refuses D23. The writer flagged this correctly instead of quietly diverging.
- **Accepting `..` would not be safe, as F07 shows.**
  - ARS uses the configured string in two different ways:
    - at startup it calls `os.Stat(rootDir)` (`ars/store/filesystem.go:26`), which the kernel resolves physically;
    - for every blob it uses `filepath.Join(rootDir, "sha256", …)` (`:174`), which Go cleans lexically.
  - With `..` after a symbolic link (F07: `<base>/lnk/../ars-storage`, `lnk` → `<base>/sub/x`), ARS stats `<base>/sub/ars-storage` and then writes blobs under `<base>/ars-storage`.
  - The check cannot tell D23 from F07 without resolving the path inside ARS's mount namespace. Refusing every non-normal form is the only rule that keeps one path for ARS's startup, ARS's writes, the mounts and the check.
  - The suggested form in the refusal (`<base>/ars-storage` for F07) is the directory ARS's blob writes would actually use.
- **It is documented.**
  - The runbook (`.runbooks/system/v1_bringup.md:247`) says "absolute paths written in normal form: no `.` or `..` component, no repeated or trailing slash, no leading or trailing whitespace (the form Python's `os.path.normpath` writes)".
  - `configuration.md:134` and `PLANS.md` state the rule too.
  - The refusal message names the form to write.
  - The cost to an operator is one edit of the config.

### 4.2 The 65,794-directory timing claim

**Confirmed.** The writer claims 10 to 20 s here and a 30 s test bound. I measured 9.4 to 16.5 s in four runs of my own harness on ab1fadb (section 3.4), on the same `sha256/xx/yy` layout with a blob in every shard. As ci, the fan-out test passed within the run's total of 28.0 s; as ci2 the total, including building the fixture, was 45.4 s.

The real bring-up at full fan-out with the default timeout passed, and A20-2 also no longer depends on the check's speed: `up` now starts ARS's readiness wait only after the launcher's check passed (`01_bringup.sh`, `wait_for_ars_storage_check`).

## 5. Observations and notes (not blocking)

- **O24-1 (Low): the fan-out test's 30 s wall-clock bound is a possible flake on a slow or busy runner.**
  - Here the check takes 9 to 17 s (10.0 s as ci and 16.0 s as ci2 when run alone), and CI passed with it. The bound catches a per-directory process: the writer's F01 took 49.6 s for one `rm` per directory, and my F01 took 65.9 s for one `ls`.
  - The margin as ci2, the slower user here, is under 2x.
  - A20-2's real protection is now structural (readiness starts after the check), so the bound only guards the walk's design.
  - If the test ever flakes, replace the bound with a structural assertion (for example, count the processes the probe starts) rather than raising it. This project already removed timing dependence from tests in PR #16 and PR #21.
- **The survivors** are listed in 3.5. Each is equivalent, a guard, cost only (and caught by the fan-out test), defence in depth, race-only, or caught only by a sudo row that CI runs. The writer's 9 survivors fall in the same classes, and none of mine shows a gap the writer's tests leave open.
- A storage path with an embedded NUL byte ends in a Python traceback (exit 1) instead of a formatted refusal. It is still a refusal, and ARS would refuse such a path too. Cosmetic only.
- **The stop design** (sections 3.4 and 3.5 of the writer's report) is sound on review:
  - `01_bringup.sh`'s `pkill -TERM -P` reaches the host part, which is the launcher's direct child, but not the docker client in its own session.
  - The host part passes on only the first signal.
  - The probe's EXIT cleanup ignores further signals.
  - The launcher's deferred traps keep it alive until the check returns.
  - Remaining limits are documented by the writer:
    - a check container killed outright leaves at most one batch of markers;
    - the 10 s grace in `stop_managed_service`;
    - no timeout on the check, as before.
- `wait_for_ars_storage_check` has no timeout of its own, like `up`'s own check. A hung check, such as the FIFO-swap note in audit 20, hangs `up`, as before.

## 6. Evidence

Listed in `24-audit-pr19-repair2-evidence/README.md`. No key, certificate body, token or config file is included. All fixtures are synthetic. A pattern scan for private-key headers, certificates, and Vault, JWT, GitHub, Anthropic and AWS token shapes found nothing.
