# PR #19 repair of audit 20: paths in normal form, a walk that scales, a "-" component, and a check that cleans up when stopped (A20-1, A20-2, A20-3)

Report 23 of the CI Nomad/Vault track. It answers the coordinator's request of 2026-11-23 04:17Z to repair all three findings of `20-audit-pr19-repair.md` properly, merge trunk_dev without a rebase, take a new manifest, run CI, report, and hand back to the same auditor.

Date: 2026-11-23. Repository: `evo-agi/Execution-Substrate`, draft PR #19 (scripts, tests and docs only). Evidence: `23-repair-pr19-evidence/` next to this file. Its `README.md` names every file, and `SHA256SUMS.txt` lists them.

## 1. Outcome

| Item | Result |
| --- | --- |
| A20-1, paths not in normal form | **Closed.** `storage.root_dir` and `storage.index_file` must be written in normal form. Any other form is refused on the host, before any container, with the form to write. D10, D11, D12, D21 and D25 are refused, each with a test row. |
| A20-2, cost on large storage | **Closed, both ways the audit allowed.** The walk starts no process per directory. At ARS's full fan-out, 65,794 directories with a blob in each, the check took 10 to 20 s here on the final code instead of 112 s, and a test pins 30 s. `up` now starts ARS's readiness wait only after ARS's launcher reports that its own check passed. A real `up` at full fan-out passed with the default `READY_TIMEOUT_SECONDS`, on the final code. |
| A20-3, a component named `-` | **Closed.** Components are entered as `./component`. D13 now agrees, and two test rows cover it. |
| **Found by my own mutants: a stopped or killed check left files behind** | **Fixed in `78bcce6`** (section 3.4). Bring-up stops ARS's launcher by signalling the launcher's child processes and then removes ARS's container by name; during the check that container is the probe's, so the probe was killed mid-walk and left thousands of empty files in storage. Now the host part passes the first signal on and waits, the probe removes its files every 256 directories, and the launcher ends only after its check. Four tests fail on `640e0a1` and pass on the fix. |
| Notes of audit 20 | The index-replace message is neutral now. A check interrupted with Ctrl-C, once or repeatedly, leaves nothing behind. A storage or index directory where ARS cannot remove its own file is refused with the right cause. |
| Comparison with ARS | 58 layouts: the audit's 50 plus 8 new ones, re-run on `78bcce6`. **No looser row.** Stricter in 7: D14, D15, D16 and D20 as before, E08 (the D20 class), and **D23 and D24, both from the normal-form rule** (section 6.2). |
| Mutants | 104 on `78bcce6`, as both users: 95 caught with sudo, 88 without (the 7 more survivors are caught only by sudo rows, which CI runs). The 9 survivors are equivalent, defence in depth, race-only or a policy choice (6.4). |
| Cost statements | "A few hundred directories", "about 0.3 s" and "about 9 s" were wrong; corrected in the PR body, `PLANS.md` and here (section 8). |
| Branch | `110d377` merged as `eda9f7c`, the repair is `e7c8f40`, trunk_dev `bc9fe36` (PR #20) merged as `640e0a1`, the stop fix is `78bcce6`, the cost statement `ab1fadb`. No rebase, no force-push. |
| Manifest | **`7c0727f4b76933d60791cfcc98348b8069bad4f24a121d455a8a52ed3dc39364`** (`ab1fadb` against `bc9fe36`, 13 files) |
| CI | `ab1fadb`: [run 45126395110](https://github.com/evo-agi/Execution-Substrate/actions/runs/45126395110) green. Also green: `78bcce6` (run 45124513106), `640e0a1` (run 45118091091), `e7c8f40` (run 45116442717). |

## 2. Target identity

| Field | Value |
| --- | --- |
| Branch | `claude/project-thread-a9tcoa-services-nonroot` |
| Head | `ab1fadb1109469a44509544b48312b14f1e2d75d` |
| Commits since `be71f84` | `eda9f7c` (merge of trunk_dev `110d377`, PR #21: one root-package test file, no overlap), `e7c8f40` (the repair), `640e0a1` (merge of trunk_dev `bc9fe36`, PR #20), `78bcce6` (stopped, interrupted or killed check, 3.4), `ab1fadb` (the measured cost in `PLANS.md` and a test comment, 8) |
| Base | `bc9fe3619823245faf550db4bf1bc3e782fbd5a5` (trunk_dev after PR #20, still its head at 08:08Z), upstream `origin/trunk_dev` |
| Manifest tool | `governed_execution_audit_patch_manifest_v2.py`, sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Manifest of `ab1fadb` against `bc9fe36` | `7c0727f4b76933d60791cfcc98348b8069bad4f24a121d455a8a52ed3dc39364`, 13 files, textual diff sha256 `80c718559cd1dfc224857c95f215a4918c06fd947e601839a9f14c9d66d434e7` |
| Kept for the record | `78bcce6`: `9961aa0ba15983cf1f4c0db2e278259ee5ac63f7731cb6810b9061faac4ddc03`; `640e0a1`: `1d31a62590d7d7a6a1de9720846d4b815604fd3335065d40a4e1e904dba91713`; `e7c8f40` against `110d377`: `016661ed99cd650b124872aa435065a231ec269091e8cd9fb1d678271273328b` |

Each manifest was taken twice by the v2 recipe in one fresh clone: umask 022, HEAD and trunk_dev checked, `git reset --mixed` to the base, upstream re-pinned to `origin/trunk_dev`, the tool with `python3 -I`. Both runs are byte-identical each time.

**`ab1fadb` against `78bcce6`** changes two files: one sentence of `PLANS.md` and one comment in the test file (section 8). All runs in section 6 that name `78bcce6` therefore hold for `ab1fadb`; on `ab1fadb` I re-ran the docs contract tests and `go vet ./es/app`, both pass.

**The merge of `bc9fe36` (PR #20).** PR #20 merged while this repair was under way, and trunk_dev requires an up-to-date branch, so `640e0a1` merges it in.
- `git merge` resolved it automatically; there was no conflict. PR #20 also touches `docs_contract_test.go`, `PLANS.md` and `.runbooks/system/v1_bringup.md`, in other sections.
- `git diff e7c8f40 640e0a1` is exactly PR #20's 19 files (+2246/−92). No file of this PR's scripts or `es/app` tests changes.
- The PR's patch-id is unchanged for `PLANS.md` and `docs_contract_test.go`. For the runbook it differs only in context lines: PR #20's new roots bullet sits next to this PR's lines (`merge-640e0a1-runbook-context.txt`).
- The full-profile bring-up test, which runs ES with PR #20's stricter startup probe, passed on `640e0a1` as 30033:30033 and as 31500:31600 (6.6).

The narrow audit's delta: `be71f84..e7c8f40` (`delta-eda9f7c-e7c8f40-*.diff`; `eda9f7c` adds only PR #21's file, `merge-eda9f7c-files.txt`), then `640e0a1..ab1fadb` (`delta-640e0a1-ab1fadb-scripts-docs.diff`, `delta-640e0a1-ab1fadb-tests.diff`).

## 3. The repair

### 3.1 A20-1: paths must be in normal form

ARS opens `storage.root_dir` and `storage.index_file` exactly as written, while the mounts it gets (`control_plane_mount_specs`) and, before this repair, the check, used the stripped and normalized form. I took the audit's recommended fix.
- The host part no longer strips or normalizes. `configured_path` refuses a value when `value != value.strip()` or `os.path.normpath(value) != value`, before the absolute-path check and before any container (`scripts/internal/control_plane.sh`, `configured_path`). The refusal says why and names the form to write, for example: `storage.root_dir must be written in normal form, because ARS opens it exactly as written and its mounts use the normal form: '/srv/ars/data/../ars-storage'; write '/srv/ars/ars-storage'`.
- Only a path in normal form names the same file for ARS, for its mounts and for the check. So the check, its mounts and ARS now see one path.
- POSIX keeps a leading `//` in normal form, and so does `normpath`. Such a path passes and works end to end (E01).
- `control_plane_mount_specs` is unchanged. It still normalizes, which is now a no-op for any path that got past the check.

This is stricter than ARS in two ways, and I flag both (section 6.2):
- **D24, a trailing slash on the root.** ARS tolerates it. The audit named this case as accepted.
- **D23, a `..` that resolves to a directory ARS can use.** For example, `<base>/data/../ars-storage` where `<base>/data` exists and is visible inside a mount. ARS would open it, and before this repair the check agreed. The audit's section 6 asked for "no new stricter layout beyond the documented trailing slash on the root". D23 is a second one. It is the same rule's consequence: a `..` path is only safe when the directory before it exists in ARS's mount namespace, and the check cannot tell that apart from D10 without resolving paths the way the kernel does in ARS's container. That is the audit's second option, which I did not take, because it would keep two spellings of one path alive between the check and the mounts. Harm: none beyond a refusal that names the normal form to write. If the auditor wants D23 to pass, the fix is to resolve the configured string with `cd -P` in the probe and require it to land on the normalized path. I have not done that.

### 3.2 A20-2: the walk starts no process per directory, and ARS's readiness starts after the check

**The walk.** Audit 20 measured 1.7 ms per directory, from three processes per directory (`mktemp`, `rm`, `ls -A`). The probe's walk now uses only the shell's own built-ins and patterns:
- It enters each directory with `cd -P`.
- It records the path of its file to a list on descriptor 3, and only then creates the file with a redirection, under `set -C` (noclobber). Recording first means a check stopped between the two still removes the file.
- It lists the directory with the shell's patterns (`"$d"/* "$d"/.*`) and must find its own file there. A directory the kernel does not let ARS list expands no pattern, so the file is not found, and the directory is refused as before.
- It reads each regular file with a redirection, recurses into directories, and refuses links and special files as before.
- It removes the recorded files with `xargs -0 rm -f --` every 256 walked directories and once more when the walk is done (`remove_walk_files`), then starts the list again. If a removal fails, it searches the tree for the first directory that still holds the file (`left_behind`) and refuses that directory as one where ARS cannot remove its own file. The cause it names is an append-only or immutable attribute, the usual reason removal fails where creation worked. (Until `78bcce6` the removal ran only once, after the whole walk; 3.4 says why that changed.)

The marker name is one random name per run, from `mktemp -u`. The index directory still gets the full create-and-remove step, and the index rewrite is unchanged.

Measured at ARS's full fan-out (256 first-level and 65,536 second-level shard directories, one blob in each, 65,794 directories with the root):

| Walk | One check |
| --- | --- |
| audit 20's probe, three processes per directory | 112.2 s (audit 20) |
| one `rm` process per directory, as a lower bound for any per-directory process (`one-process-per-directory.log`, 04:52Z) | 49.6 s |
| final code `78bcce6`, test runs as one identity at a time (`final-tests-78bcce6-*.log`) | 10.4 s (30033), 15.0 s (31500), 11.6 s (root) |
| final code `78bcce6`, three runs with nothing else running (`quiet-timing-78bcce6.log`) | 16.6 s, 17.6 s, 20.0 s |
| `e7c8f40`, three identities at once (`final-tests-*.log`) | 11.9 s (30033), 14.6 s (31500), 18.7 s (root) |

This container's disk speed varies from run to run: the runs with nothing else running were the slowest. So the docs give the range, 10 to 20 s, and the bound stays at 30 s, under the 49.6 s that even one process per directory costs. `TestARSStorageCheckScalesToARSFullFanOut` pins it. It builds that full fan-out, runs the check as the caller's identity, and requires a pass within 30 s, the index rewritten the way ARS does it, and no file left behind. Mutant F01 (one `ls` per directory) shows the bound catches a per-directory process (6.4).

**ARS's readiness wait.** Audit 20 found that the launcher's check counted against `wait_for_service_ready`, which started its deadline as soon as the launcher started. Now:
- `01_bringup.sh up` removes any old report file and starts the ARS launcher with `ARS_STORAGE_CHECK_PASSED_FILE` set.
- `02_start_ars.sh` writes that file after its own check passed, just before it starts ARS.
- `up` waits for the file (`wait_for_ars_storage_check`), removes it, and only then calls `wait_for_service_ready` with `READY_TIMEOUT_SECONDS`.
- If the launcher stops before writing the file, for example because its check refused, `up` fails at once with the last 20 lines of the launcher's log, and starts no ARS.
- Like the check that `up` runs itself, this wait has no timeout of its own: the check's cost grows with the store, and `READY_TIMEOUT_SECONDS` bounds ARS's own start. The script's comment says so. A wiring mistake that never writes the file would hang `up`; mutant U02 shows the readiness test catches that.

`up` still runs the walk twice before ARS starts: once itself, before any service, and once in the launcher. At full fan-out that is about 20 to 40 s here, outside the readiness wait.

**A real bring-up at full fan-out, on the final code** (`bringup-full-fanout-78bcce6.log`): `TestBringupScriptUpCheckDownFullProfile` as 30033:30033, with a control-plane image built from `78bcce6`, its storage filled with all 65,794 directories and a blob in each, and with the test's own `READY_TIMEOUT_SECONDS=60` removed, so `up` used the default 30 s. Only those evidence lines differ from the committed test (`bringup-full-fanout-78bcce6-evidence-test.diff`, identical to the one used on `e7c8f40`). It passed: `up` took 38.3 s; the two storage check containers, `up`'s and the launcher's, ran from 06:43:40.6 to 06:44:08.1 (`bringup-full-fanout-78bcce6-timeline.txt`, `docker ps` polled about every 0.4 s); ARS started at 06:44:08.5; ARS, EGS, AGS, ES and Nomad reached ready with `submit-ready: true`. The same run on `e7c8f40` (`bringup-full-fanout.log`) also passed, with `up` at 40.7 s while mutants ran.

### 3.3 A20-3: a component named `-`

`reach` now enters each component as `cd -P -- "./$component"`. BusyBox `cd -- -` meant `$OLDPWD`; `./-` is the directory named `-`. D13 (`<base>/-/ars-storage`, usable) passes as ARS does, and D22 is refused at the right directory with the right message. Two rows pin it, an accepted and a refused one, and E05 adds a `-` directory inside storage.

### 3.4 A check that is stopped, interrupted or killed (`78bcce6`)

**How I found it.** My mutant run on `640e0a1` (`mutants-640e0a1-*.log`) had W13 survive: removing the probe's signal traps changed no test outcome. The interrupt test sends SIGINT to the check's process group, as a terminal does, and BusyBox `ash -c` handles SIGINT itself, so the traps were not needed there. But two other ways to stop the check had no test, and both were broken:
- **Bring-up stopping ARS's launcher.** When `up` fails or is interrupted, `stop_managed_service` in `01_bringup.sh` sends SIGTERM to the launcher's child processes and to the launcher, waits for the launcher to end, and then runs `docker rm -f` on ARS's container name. During the check, that container is the probe's. The host part (Python) died at SIGTERM without passing it on, the docker client was never signalled, the launcher ended at once, and `docker rm -f` killed the probe mid-walk. Every file it had created so far stayed in storage, because the removal ran only after the whole walk: **4,225 empty `.ars-storage-check.*` files** on a 16,705-directory store in the test on `640e0a1`. The next check reads them as ordinary files, so nothing breaks, but storage is littered and, at full fan-out, could hold tens of thousands of them.
- **Ctrl-C pressed again.** The docker client stops waiting for its container once it has received three SIGINT or SIGTERM signals and exits with "got 3 SIGTERM/SIGINTs, forcefully exiting" (`docker-client-three-signals.log`, Docker 29.10.0). In `640e0a1`, the client was in the terminal's process group, so a third Ctrl-C ended it while the probe was still cleaning up, and Python's `subprocess.run` itself waits only 0.25 s after the first Ctrl-C before it kills the client.

A probe killed outright (`docker rm -f`, `docker kill`) can never clean up, so the only fix there is to leave less behind.

**The fix.**
- **The host part passes the first signal on and waits.** It runs the docker client with `start_new_session=True`, so only the host part signals it; it handles SIGHUP, SIGINT and SIGTERM, passes the first one it receives on to the client, which passes it on to the probe, and waits until the client ends, which with `--rm` is after the container is removed. Then it prints "ARS storage check interrupted" and exits with 128 plus that signal's number. It passes on only the first signal because the client gives up after three; the probe ignores later ones anyway. A one-item list taken with `list.pop` decides who passes it on, so a signal handler running in the middle of the main path cannot pass it on twice. A signal that the host part was started to ignore stays ignored: inside `up`, the launcher is a background job, so Ctrl-C does not reach the check directly; `up`'s own stop does.
- **The probe removes its files every 256 walked directories** (3.2), so a probe killed outright leaves at most one batch, plus the files of the few directories it was still in. Its signal traps and its EXIT cleanup first ignore further SIGHUP, SIGINT and SIGTERM, so a second signal cannot cut the cleanup short.
- **ARS's launcher defers SIGTERM and SIGHUP until its check has returned** (`trap 'exit 143' TERM`, `trap 'exit 129' HUP` around the check, reset after it). Bash runs those traps only once the foreground check has ended, so the launcher ends only after the check's container is gone, and `up`'s `docker rm -f` finds nothing of the check's to kill. `up` waits up to 10 s for the launcher, then kills what is left and removes the container; the cleanup after a signal is one batch removal of at most 256 directories' files.

**Tests, written first** (`stop-tests-on-640e0a1.log`, `repeated-interrupt-fix-and-variants.log`):

| Test | `640e0a1` | Fix |
| --- | --- | --- |
| `TestARSLauncherStoppedDuringItsCheckEndsAfterTheCheck`: runs `02_start_ars.sh` with the probe in real Docker, stops it as `up` does, and requires the check's container to be gone when the launcher ends, exit 143, the "interrupted" message, the index untouched and no ARS started | **fails**: "the stopped launcher ended while its storage check container … still existed" | passes |
| `TestARSStorageCheckStoppedByBringupLeavesNothingBehind`: SIGTERM to the check shell's children, then to the shell | **fails**: the host part died by the signal, no message | passes |
| `TestARSStorageCheckKilledLeavesAtMostOneBatch`: `docker kill --signal KILL` once the walk has passed shard `sha256/40`, at most 256 + 4 files left | **fails**: 4,225 left | passes: 196, 169, 249 and 162 left in four runs |
| `TestARSStorageCheckInterruptedRepeatedlyStillWaitsForItsProbe`: five SIGINTs to the process group 5 ms apart | **fails 3 of 3** | passes 3 of 3; the variant that passes every signal on fails 3 of 3 |
| `TestBringupUpInterruptedDuringLauncherCheckLeavesNothingBehind`: SIGINT to `up`'s process group while the launcher's check runs in real Docker | passes | passes |
| `TestARSStorageCheckInterruptedLeavesNothingBehind`, now also requiring exit 130 | passes | passes |

The `up` test passes on `640e0a1` too, because there the docker client sat in `up`'s process group and got Ctrl-C directly. With the client now in its own session, the test pins the whole path through `up`'s stop. Every stop test now also requires the check to end only after its container has gone (`requireStoppedLeavingNothingBehind`), since `up` removes ARS's container by name as soon as the launcher has ended.

### 3.5 Found while repairing, earlier

- **Ctrl-C during the check** (audit note). The probe runs as PID 1 in its container, which gets no default action for SIGHUP and SIGTERM, so it traps them; a file created but not yet recorded would have been missed, which is why the path is recorded first. The host part prints "ARS storage check interrupted" and exits 130 instead of a Python traceback. 3.4 extends this.
- **A misleading hint.** A directory where ARS could create but not remove its file (append-only) used to get the `chown` hint. It now gets its own kind, `remove`, whose message names the append-only or immutable attribute. Rows for a storage directory and an index directory, both `chattr +a`, need sudo and run on CI.
- **The index-replace message** (audit note) now names the sticky rule and an immutable or append-only attribute, not the sticky rule alone.
- **A stale report file.** A report file that an earlier bring-up left behind must not count as this launcher's pass. `up` removes it first, and the readiness test plants one.
- **The refusal path of the launcher's check** had no test. `TestBringupUpFailsWhenARSLauncherStopsBeforeItsCheckPassed` lets `up`'s own check pass and the launcher's refuse, as when storage changes in between. It requires `up` to fail with the launcher's log tail, start no ARS, and not wait.

### 3.6 What changes for an operator

- A storage path written with `..`, `.`, a repeated or trailing slash, or surrounding whitespace is refused with the form to write. Writing it that way fixes it.
- Large stores no longer make `up` fail at ARS's readiness. On a full store, `up` spends 20 to 40 s more before ARS starts and prints "waiting for the ARS launcher's storage check" while it does.
- A launcher whose check refuses fails `up` with its log tail, instead of a readiness timeout.
- Ctrl-C during the check or during `up`, once or repeatedly, leaves the storage as it was. Only a check container killed outright, for example with `docker rm -f`, can leave up to 256 empty `.ars-storage-check.*` files, which the next check reads as ordinary files and which may be deleted.

## 4. Tests

All in `es/app/service_launchers_container_user_test.go` unless named.

New rows of `TestServiceLaunchersContainerUser`:
- refused on the host: storage root with a `..` component, a trailing space, a trailing slash, a repeated slash; index file with a `..` component, a leading space, a trailing slash;
- storage root behind a directory named `-`, accepted, and the same with that directory unsearchable for the identity, refused at it;
- storage directory and index directory where ARS cannot remove its own file (`chattr +a`, sudo), refused with the `remove` message, the index untouched and exactly one file left in the append-only directory.

New test functions:
- `TestBringupUpStartsARSReadinessWaitWhenItsLauncherCheckedStorage`: the launcher's check, in real Docker, is held for 6 s while `READY_TIMEOUT_SECONDS` is 3, with a stale report file planted; `up` must get past ARS's readiness.
- `TestBringupUpFailsWhenARSLauncherStopsBeforeItsCheckPassed` (3.5).
- `TestARSStorageCheckScalesToARSFullFanOut` (3.2), bound 30 s.
- `TestARSStorageCheckInterruptedLeavesNothingBehind` (3.5, exit 130 since `78bcce6`).
- `TestARSStorageCheckInterruptedRepeatedlyStillWaitsForItsProbe`, `TestARSLauncherStoppedDuringItsCheckEndsAfterTheCheck`, `TestARSStorageCheckStoppedByBringupLeavesNothingBehind`, `TestARSStorageCheckKilledLeavesAtMostOneBatch`, `TestBringupUpInterruptedDuringLauncherCheckLeavesNothingBehind` (3.4).
- `TestARSStorageCheckDocsContract` in `docs_contract_test.go`: requires the normal-form rule, the cost, the readiness order and the stop behaviour in `PLANS.md`, the bring-up runbook and the configuration page. It forbids "few hundred", "lists every storage directory", "lists every such directory" and the old tool list "`mktemp`, `ls`, `cat`".

Every existing row is kept with its expected outcome.

## 5. Docs

- `PLANS.md` (`GENERIC-SERVICE-LAUNCHER-USER-01`): the normal-form rule and why, the batch removal, "starts no process per directory", the cost at 65,794 directories (10 to 20 s here, bound 30 s), the readiness order, that a refusal before the index step leaves storage as it was, except for a root created in the host step and a file the check could not remove, and that a stopped check passes the first signal on and waits for its probe, while a probe killed outright leaves at most one batch of 256 directories' files.
- `.runbooks/system/v1_bringup.md`: what normal form means in operator terms, the cost, that `READY_TIMEOUT_SECONDS` starts after the launcher's check, and what Ctrl-C and a killed check container leave.
- `.docs/system_overview/configuration.md`: the same, shorter.
- `scripts/internal/control_plane.sh`'s comments: the tools the image must provide (`mktemp`, `xargs`, `rm`, `cat`, `chmod` and `mv`), the batch removal, and the signal handling of both parts; `02_start_ars.sh`'s comment on its traps.

## 6. Validation

### 6.1 CI

The gate fails on any skip without a line in `.github/ci/environment-only-tests.txt`, and this PR adds no line there, so every test of this PR runs on the runner, including the sudo, `setfacl` and `chattr` rows, and the stop tests with real Docker.
- `ab1fadb`: [run 45126395110](https://github.com/evo-agi/Execution-Substrate/actions/runs/45126395110), job 137531591153, success, 06:46:31Z to 07:07:04Z.
- `78bcce6`: [run 45124513106](https://github.com/evo-agi/Execution-Substrate/actions/runs/45124513106), job 137525681516, success, 06:30:09Z to 06:44:48Z. The gate and the test step passed, so the stop tests ran on the runner with real Docker.
- `640e0a1`: [run 45118091091](https://github.com/evo-agi/Execution-Substrate/actions/runs/45118091091), job 137505431823, success, 05:29:26Z to 05:43:54Z.
- `e7c8f40`: [run 45116442717](https://github.com/evo-agi/Execution-Substrate/actions/runs/45116442717), job 137500276999, success, 05:13:48Z to 05:28:09Z. All 15 listed tests still fail there.

### 6.2 Comparison with what ARS can do: 58 layouts

`kernel_compare23.py` is audit 20's `kernel_compare14.py` with the check taken from this tree and 8 new layouts (E01 to E08). Each layout is built three times:
- **check**: `verify_ars_storage_for_operator` from the tree;
- **ops reference**: a container with `--user` and exactly ARS's mounts that creates and removes a file in every directory, reads every file and replaces the index the way ARS does;
- **real ARS**: the ARS binary with ARS's mounts and junk TLS files; "storage ok" means it got past its storage startup.

The image is `comparison-image.Dockerfile.txt`. Run on `78bcce6` (`kernel-comparison-78bcce6.log`) and earlier on `e7c8f40` (`kernel-comparison-e7c8f40.log`). Result both times: **51 agree, 7 stricter, 0 looser**, and on `78bcce6` every verdict and every refusal message is the same as on `e7c8f40`.

| Group | Rows | Result |
| --- | --- | --- |
| The addendum's 25 (C01 to C25) | 25 | all agree |
| D01 to D09, D17 to D19, D22 | 13 | all agree |
| **The five looser rows of A20-1**: D10, D11, D12, D21, D25 | 5 | **now agree**: refused, and ARS fails at storage startup |
| D13 (a `-` component, A20-3) | 1 | **now agrees**: passes, as ARS does |
| New: E01 `//` paths, E02 a shard named `[ab]*`, E03 `.cache` and `..x`, E04 a space in a component, E05 a `-` directory inside storage, E06 a file left by an interrupted check, E07 root identity with an append-only blob directory | 7 | all agree |
| Stricter as in audit 20: D14 (a host directory above the mounts that the caller cannot search; the host part runs as the caller), D15 (a shard link) and D16 (a FIFO), by design; D20 (a 0300 directory the check cannot list), by design | 4 | check stricter |
| New stricter, D20's class: E08 (the storage root itself 0300) | 1 | check stricter |
| **New stricter from the normal-form rule: D24 (trailing slash on the root, named by the audit) and D23 (a `..` that resolves to a usable directory, not named by the audit)** | 2 | check stricter (3.1) |

### 6.3 Cost

See 3.2: the table, the 30 s bound, and the real bring-up at full fan-out with the default `READY_TIMEOUT_SECONDS`.

### 6.4 Mutants

`mutants23.py.txt` applies each mutant to a fresh copy of `78bcce6` and runs this PR's launcher, bring-up and stop tests with `-failfast` (the F series runs the full fan-out test instead). It keeps audit 20's names where the code still exists and adds series for this repair: N (normal form), W (the walk and its removal), U (the readiness order), X (the `remove` refusal), F (the 30 s bound), and for the stop fix B (removal every 256 directories), S (the host part's signal handling), P40/P41 (the probe's traps) and L (the launcher's traps). 104 mutants plus two unmutated controls, run as both users side by side (`mutants-78bcce6-*.log`, 06:45Z to 08:07Z):

| Identity | Caught | Survived |
| --- | --- | --- |
| 30033:30033 (sudo) | 95 | 9 |
| 31500:31600 (no sudo) | 88 | 16: the same 9, plus R28, W07, W08, W09, X01, X02 and X03, which only the sudo rows (`setfacl`, `chattr +a`) catch, and those run on CI |

Both controls pass for both users. The 9 survivors:
- **R34** (no `chmod 600` before the index rename): equivalent, because BusyBox `mktemp` creates `0600`.
- **W12** (no noclobber): reachable only if the random marker name collided with an existing file; kept as a guard.
- **B03** (the list appended to instead of started again): equivalent except cost; already removed paths are removed again.
- **S04** (handlers installed even for a signal the host part was started to ignore): a policy choice. Inside `up`, the launcher's check inherits SIGINT ignored; handling it anyway would pass Ctrl-C on to the probe, which also cleans up, so no test outcome differs. Keeping an ignored signal ignored is the convention for background jobs and `nohup`.
- **S07** (no forward right after the client starts) and **S08** (the client started although a signal already arrived): race-only; the signal would have to arrive within the few milliseconds of starting the client. A test would need a seam in the host part.
- **P40** and **P41** (the probe's traps and its cleanup do not ignore further signals): defence in depth. Since the host part passes on only the first signal, the probe gets one; only someone signalling the container directly a second time would reach it.
- **L02** (the launcher keeps its traps after the check): equivalent; the launcher then writes the report file and `exec`s `docker run`, which resets them, so only the exit status of a launcher stopped in between changes.

What the stop tests catch: W13 (no probe traps) and L01 (no launcher traps) by the launcher test; S01 (no forwarding), S03 (no handlers) and S05 (exit status 1) by the interrupt test; S02 (client in the caller's session) and S06 (every signal passed on) by the repeated-interrupt test; B01 and B02 (no removal during the walk, or every 65,536 directories) by the kill test; W05 (path recorded after the file is created) by a stop test hitting the window between the two (the repeated-interrupt test as 30033, the bring-up stop test as 31500); F01 (one `ls` per directory) by the 30 s bound.

On `640e0a1`, before the fix, the earlier runner (`mutants23-640e0a1.py.txt`, `mutants-640e0a1-*.log`) had R34, W05, W12 and W13 survive as 30033; W13 is what led to 3.4, and W05 is now caught.

### 6.5 Cloud container, three identities, on `78bcce6`

`final-tests-78bcce6.sh.txt`, run one identity after another on `git archive 78bcce6`: 30033:30033 (groups 30033, docker; passwordless sudo), 31500:31600 (groups 31600, docker; no sudo) and root. It runs `gofmt`, `go vet` of `es/app` and the root package for linux and darwin, `bash -n` of every script, this PR's tests with `TestSupportedLocalExecutionRoot*`, and the docs tests.

| Identity | `gofmt`, `vet` (linux, darwin), `bash -n` | This PR's tests and `TestSupportedLocalExecutionRoot*` | Docs |
| --- | --- | --- | --- |
| 30033:30033 | clean | 111 pass, 0 skip, 0 fail | pass |
| 31500:31600 | clean | 105 pass, 6 skip (the sudo rows: supplementary group, primary group, two ACL rows, two `chattr +a` rows), 0 fail | pass |
| root | clean | 88 pass, 17 skip (rows that need a non-root caller), 3 fail | pass |

The 3 root failures are `TestSupportedLocalExecutionRootFailedProvisionEmitsNoEvidence`, `…PrivilegeGateBeforeMutation` and `…SharedPreflightProfileAndGeneric`. They fail identically as root on `110d377` (`base-110d377-supported-local-uid0.log`) and are not in this PR. The same set on `e7c8f40` gave 106, 100 and 83 passes with the same skips and failures (`final-tests-uid*.log`).

### 6.6 On the merged head `640e0a1`

- `gofmt`, `go vet` (linux and darwin) of `es/app` and the root package, `go build ./...`, `bash -n` and the docs tests pass.
- `TestBringupScriptUpCheckDownFullProfile`, unmodified, with a control-plane image built from `640e0a1`, so ES runs PR #20's startup probe on bring-up's roots: passed as 30033:30033 (34.2 s) and as 31500:31600 (33.4 s) (`bringup-640e0a1-uid30033-gid30033.log`, `bringup-640e0a1-uid31500-gid31600.log`).

## 7. Audit items (audit 20, section 6)

| Item | Status |
| --- | --- |
| 1. D10, D11, D12, D21, D25 refused with test rows; no new stricter layout beyond D24 | Refused, rows in section 4. **One more stricter layout, D23**, from the same rule (3.1). |
| 2. `up` passes at 65,794 directories with the default `READY_TIMEOUT_SECONDS`, or a measured bound pinned by a test; cost statements corrected | Both: the real `up` passed with the default on the final code (3.2), and the check's cost is pinned at 30 s by a test. Statements corrected (section 8). |
| 3. A `-` component row | Two rows, plus E05. |
| 4. 50-layout comparison with no looser row; tests as users with and without sudo; fresh manifest on a branch that took `110d377` | 58 layouts on the final code, no looser row (6.2); tests as both users and root (6.5); manifest on `ab1fadb` against `bc9fe36` (section 2). |
| Note: index-replace message | Neutral (3.5). |
| Note: interrupted check | Fixed, and extended to a check stopped by bring-up, interrupted repeatedly or killed outright (3.4). |
| Note: structural damage (a regular file named `sha256`) | Unchanged, out of the check's scope. |
| Note: FIFO swapped in during the check | Unchanged: denial of service only, needs a concurrent writer in storage. |

## 8. Corrections of earlier statements

- `14-repair-pr19.md` said "ARS's two-level `sha256/xx/` layout gives at most a few hundred directories in practice". Wrong. ARS stores at `sha256/xx/yy/<digest>` (`ars/store/filesystem.go:174`), so up to 1 + 256 + 65,536 directories below the root.
- PR #19's body said the check "costs one container start (about 0.3 s)". That held only for a nearly empty store. The body now gives the full fan-out cost and the readiness order.
- The body's "creating and removing a file and listing each directory" is replaced by what the walk does now.
- `e7c8f40`'s commit message and `PLANS.md` said the full fan-out check takes "about 9 s" here. That was one development run. On the final code it took 10 to 20 s in eight runs of the same walk, six of them on `78bcce6` (3.2); `ab1fadb` corrects `PLANS.md` and the test's comment, and its commit message says "eight runs" on "the current head", where six were on the head and two on the uncommitted tree that became it.
- `78bcce6`'s commit message says the probe could also "rewrite the index after up had failed". In bring-up that needs the walk to finish in the moment between the launcher's end and `docker rm -f`; the files left behind are the effect that matters. Without `up`'s `docker rm -f`, as in `TestARSStorageCheckStoppedByBringupLeavesNothingBehind` on `640e0a1`, the probe did go on unsupervised.
- `e7c8f40`'s commit message said "Ctrl-C during the check leaves nothing behind". That held for Ctrl-C in a terminal, but not for the way bring-up stops ARS's launcher, nor for a third Ctrl-C (3.4).

## 9. Not run, limits

- **macOS.** Nothing of PR #19 ran on macOS. By construction, Docker Desktop decides the check's access as it decides ARS's. The check's speed on Docker Desktop's file sharing is not measured; it starts no process per directory, but each file operation crosses the file sharing. The docker client there is the same program; the host part's signal handling does not depend on the platform.
- **A probe killed outright** leaves up to 256 directories' files (3.4). Nothing can clean up after SIGKILL; the files are empty, named `.ars-storage-check.*`, and the next check reads them as ordinary files.
- **The 10 s grace in `up`'s stop.** `stop_managed_service` waits up to 10 s for the launcher before `docker rm -f`. The check's cleanup after a signal is one batch removal; if a very slow file system made that take longer than 10 s, the probe would be killed with at most one batch left.
- **D23 with a live operator.** The refusal is by the rule; its message names the path to write.
- **Rootless Docker and user-namespace remapping** stay unsupported for bring-up.
- **The check has no timeout**, as before; a FIFO swapped into storage during the check would block it (audit note, unchanged).

## 10. Effects

- Pushed `eda9f7c`, `e7c8f40`, `640e0a1`, `78bcce6` and `ab1fadb` to `claude/project-thread-a9tcoa-services-nonroot` (draft PR #19). No force-push, no rebase.
- PR #19's description updated (section 8).
- Nothing of PR #19 was merged. No live service was touched. Mac: nothing of PR #19 ran there.

## 11. Handover

Re-audit of `be71f84..ab1fadb` by the audit-20 thread, against section 6 of `20-audit-pr19-repair.md` and this report. Scripts, tests and docs only, so by the project rule no red-team and no review by David. Points for the auditor:
- **D23** (3.1): a second stricter layout from the normal-form rule, beyond the D24 the audit named. Whether to keep it is the auditor's call; the alternative is in 3.1.
- the walk (3.2): record before create, `set -C`, the `seen` check, removal every 256 directories and at the end, and `left_behind`;
- the readiness file: written only after the launcher's check passed, removed by `up` before and after, and no timeout on the wait;
- **the stop fix (3.4)**: the host part's first-signal forwarding with the client in its own session, the probe's traps, the launcher's deferred traps, and the five stop tests;
- the merge `640e0a1` of PR #20 (section 2).

The manifest is `7c0727f4…9364` against `bc9fe36`, with upstream `origin/trunk_dev`.
