# Evidence for 15-repair-pr20.md

Head `b5cc7cb78d3e9f14b015403fcad5451da5957f75`, base `f62d024`. Container runs used trees archived from `91a9865`, which differs from the head only in a workflow comment and the self-test's hash of the workflow.

| File | What it is |
| --- | --- |
| `log-tests-uid0.log` | targeted `es/admission` tests as root, in the worktree |
| `log-tests-uid30033.log` | `container-test-script.sh.txt` as `ci` 30033:30033 with passwordless sudo: gofmt, vet (linux, darwin), targeted tests, docs contracts, whole `es/...`, root package failures |
| `log-tests-uid31500.log` | the same as `ci3` 31500:31600 without sudo |
| `log-rootpkg-base-f62d024-uid30033.log` | root package failures on a clean `f62d024` as `ci` (`rootpkg.sh.txt`); the same 32 tests as on the head |
| `log-mutants-uid30033.log` | 33 mutants of the repair (`mutants_pr20r.py.txt`, started by `mut_pr20r.sh.txt`) as `ci` |
| `log-stress-1000.log` | `TestExecutionRootProbeDirectorySwapStress`, 1000 rounds, as root, binary built from `b5cc7cb` |
| `log-stress-1000-before-repair.log` | the same on `c27c689`, the red-team's tests on the code before the repair |
| `log-reasons-before-repair-c27c689.log` | `TestExecutionRootProbeNamesTheCheckThatRefuses` (7 rows) against the code before the repair |
| `ci-pr20-45094162628-job137430212947.log` | GitHub Actions job log of run 45094162628 on `b5cc7cb` |
| `manifest-v2-pr20-b5cc7cb.json` | provenance manifest v2, base `f62d024`, upstream `origin/trunk_dev`; sha256 9d277408770cc0cc07d9082ca8d36f1be981b9191dbd492872fb6faa1e571b4a |
| `manifest-run1.out.txt`, `manifest-run2.out.txt` | output of the two manifest runs from fresh clones; the two JSON files were byte-identical |
| `run-as-user.py.txt` | the wrapper the per-user scripts run under (default signals, no proxy variables) |
