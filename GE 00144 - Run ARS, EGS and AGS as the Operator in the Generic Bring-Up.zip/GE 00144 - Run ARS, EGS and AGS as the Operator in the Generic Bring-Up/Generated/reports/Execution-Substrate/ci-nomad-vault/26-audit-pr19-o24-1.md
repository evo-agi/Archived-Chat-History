# 26: Narrow re-audit of the PR #19 O24-1 repair (ab1fadb..f109af4)

Written by the independent audit thread "Audit bring-up running as the operator", 2026-11-23, 10:22Z to 10:55Z.
Read-only. Nothing was pushed, commented, reviewed, merged or changed on GitHub.

Target: the writer's `25-repair-pr19-o24-1.md`, which replaces the 30 s limit of `TestARSStorageCheckScalesToARSFullFanOut` (O24-1 of my audit 24) with a count of the processes the check's probe starts.

Evidence: `26-audit-pr19-o24-1-evidence/` (README and `SHA256SUMS.txt` there).

## 1. Verdict: ACCEPT, with one Low finding to fix in this PR

**O24-1 is closed.** The new test measures what the 30 s limit stood for: the walk starts no process per directory.
- The real check starts 535 or 536 processes at full fan-out, as both my users, in every run here. The limit is 2,056.
- A per-directory `ls`, `$(…)` subshell or pipeline starts 66,330 or more and fails.
- The wrap guard and the boot-ID premise are sound (sections 3.3 and 4). I reproduced the guard's need and effect myself.
- The scripts are byte-identical to ab1fadb, so everything audit 24 established still holds.

**A26-1 (Low, test only): the count can pass without measuring anything.** Nothing checks that the probe actually ran in the helper's PID namespace. If it does not, only the samples' own overhead is counted (5 here), and that passes.
- Two plausible edits make the probe miss the namespace:
  - renaming the probe's `ars-storage-probe` argument in `control_plane.sh` without updating this test's wrapper;
  - the host part calling Docker by an absolute path instead of through `PATH`.
- With either edit and a per-directory `ls`, the test passes, as both users (mutants V02 and V03). It logs "started 5 processes": the 5 are only the second sample's own Docker overhead, so even a check that the count is above zero would not notice.
- Both edits would first break other tests, so neither can happen silently. The launcher rows of `TestServiceLaunchersContainerUser` pin the check container's exact arguments, including `ars-storage-probe`, through a fake `docker` first on `PATH`. That is why this is Low.
- **Fix:** have the wrapper record each probe run it moves into the namespace, and require exactly one such run. A positive count alone is not enough, because the samples' overhead makes the count positive anyway. I tested this fix on an audit copy of the test (T rows in 3.4): about five lines in the test, nothing in the scripts. With it, both evasions fail, a per-directory `ls` still fails on the count, and the real check passes with 535 or 536.
- I recommend fixing it in PR #19 before the merge, as A3-1 was fixed inside PR #23. The re-check is one test run.

**Gate.**
- Manifest `e3f8032c…b58c` against base `bc9fe36`, at the start and the end. It is byte-identical to the writer's, and trunk_dev is still `bc9fe36`.
- CI run 45151423109 is green, and its `es/app` run skipped nothing.
- Tests pass as ci (111/111) and as ci2 (105, plus 6 sudo skips).

## 2. Gate data

| Item | Result |
| --- | --- |
| Recipe `/opt/audit/v2.py` | sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every manifest run |
| Head | `f109af49d50c6c281c5b1cef0d56bbe287dbd338`, one commit on `ab1fadb` (audit 24, ACCEPT) |
| Base | `bc9fe3619823245faf550db4bf1bc3e782fbd5a5` = `refs/heads/trunk_dev` at the start (10:22:16Z) and at the end (10:49:33Z) |
| Upstream | re-pinned to `origin/trunk_dev` |
| Opening manifest (10:22Z) | `e3f8032cc62f9a62f3c11c5d50453439d4b8e9774b9474439f9007e0e7eeb58c`, 13 files, textual diff `7330c07b…a3dd`. Taken twice, byte-identical to each other and to the writer's `manifest-f109af4/m1.json` and `m2.json` |
| Closing manifest (10:49Z) | `e3f8032cc62f9a62f3c11c5d50453439d4b8e9774b9474439f9007e0e7eeb58c` again, twice, byte-identical to the opening runs. `git ls-remote` at 10:49:33Z: the branch is `f109af4`, trunk_dev is `bc9fe36` |
| Writer's report | `25-repair-pr19-o24-1.md` sha256 `d9c5a016136fbbb78f04eb4aded1d0ec909d7d4ed1f4b605840ff36a9075dc07`, as stated |
| Writer's evidence | `SHA256SUMS.txt` checks out (17 files) |
| CI on f109af4 | "build, vet and test", run 45151423109, job 137613482592: success, 09:55:49Z to 10:19:17Z. It is the only check run, and there are no legacy statuses. The gate's `es/app` run "with nothing skipped" failed only on its two listed tests, so the fan-out test ran on the runner and passed |
| Kind of change | tests and docs only: the test file, one sentence of `PLANS.md`, and the docs contract. In the manifest, every script's hash equals its hash in the ab1fadb manifest |

## 3. What I checked

### 3.1 Delta

- `git diff ab1fadb f109af4` touches 3 files (+168/−15). It is byte-identical to the writer's `diff-ab1fadb-f109af4.patch`.
- `scripts/` in a `git archive` of f109af4 is identical to the ab1fadb tree's (`diff -r`).
- `PLANS.md` replaces "(`TestARSStorageCheckScalesToARSFullFanOut` requires under 30 s)" with how the test pins the cost by counting processes. The 10 to 20 s timing sentence is unchanged and still true here: 9.8 to 15.5 s for the real check across this audit's runs.
- `TestARSStorageCheckDocsContract` now requires both parts of the new sentence and lists "requires under 30 s" as stale.
- The commit message carries the standard `Co-Authored-By` trailer, which ES keeps (O13-5).

### 3.2 Tests on exact bytes

The trees come from `git archive f109af4`. `unit25.sh` is my `unit23.sh`, extended to keep the fan-out test's count line. It runs:
- `go vet ./es/app .`;
- `gofmt`;
- `bash -n` on every script;
- the launcher, bring-up, storage-check and stop tests, plus `TestSupportedLocalExecutionRoot*`;
- `go test . -run Doc`.

| User | Result | Fan-out count |
| --- | --- | --- |
| ci 1500:1600 (sudo) | 111 pass, 0 skip, 0 fail. Docs: ok | 536 processes, 1,113 forks on the whole kernel, 9.8 s |
| ci2 1700:1700 (no sudo) | 105 pass, 6 skip (the sudo rows), 0 fail. Docs: ok | 536 processes, 1,214 forks, 10.1 s |

### 3.3 How the count works, attacked point by point

These are the points the writer asked me to attack.

**The wrapper's argument handling.**
- The wrapper acts only on `docker run` whose arguments include the word `ars-storage-probe`. The host part passes that word as the probe shell's `$0`, as its own list element (`control_plane.sh:475`).
- It drops the leading `run` and execs `docker run --pid container:<helper> <all the original arguments>`, so every original argument is kept in order.
- Every other Docker call passes through unchanged.
- `[ "$arg" = ars-storage-probe ]` is the three-argument form of `test`, so an argument such as `!` or `(` cannot confuse it.
- Mounts and paths cannot equal the bare word `ars-storage-probe`, because the check refuses relative paths before any Docker call.
- **But nothing confirms that the wrapper fired** (A26-1).

**Threads.**
- Every task the kernel creates takes a PID in each PID namespace it belongs to, threads included.
- The kernel's `processes` counter in `/proc/stat` counts every task too, threads included.
- So threads can only raise the count, which errs on the side of failing. The real probe has none: BusyBox `sh`, `xargs` and `rm` are single-threaded.

**The `docker exec` samples.**
- The test subtracts 1 for the second sample's own PID. With this runc, each `docker exec` and each container that joins the namespace takes 5 or 6 PIDs, not 1 (`pid-cost-docker-exec-and-join.log`). Inference: these are runc's setup processes and threads inside the namespace.
- So the count of 536 includes about 10 PIDs of runc overhead (the probe container's start and the second sample).
- Inference: the 5-or-6 variation explains the writer's spread of 535 to 537.
- This is constant overhead, which is noise against a margin of 1,520. The test's comment "One PID went to the second sample itself" is imprecise but harmless (O26-1).

**Sequential PIDs.**
- A PID namespace hands out PIDs cyclically, one after another, skipping PIDs still in use. Skipping can only raise the count.
- After the namespace's `pid_max`, numbering restarts at 300. The writer's G01 shows exactly that: PID 19 before and 1,415 after a per-directory walk, which fits about 66,330 allocations wrapping twice (32,748 + 32,468 + 1,116).

**The wrap guard.**
- Every PID allocated in the helper's namespace comes from a task created on the kernel that `/proc/stat` counts.
- So if the kernel created fewer than `pid_max − PID before` tasks, the namespace cannot have wrapped, and `PID after − PID before` is exact up to the runc overhead.
- The guard fails closed: a busy kernel fails the test rather than passing it.
- Reading `pid_max` inside the helper's namespace is right before Linux 6.14, where it is global, and after, where it is per namespace. Here: 32,768 on the host and 4,194,304 in the helper.
- I reproduced the writer's G rows myself (W rows in 3.4) by lowering the helper namespace's `pid_max` to 32,768.

**The boot-ID premise.**
- `boot_id` is generated once per boot and is not namespaced, so equal boot IDs mean the daemon runs on the test's own kernel. Here they are equal.
- A daemon in a VM, or on another host, fails the test with a clear message. Non-Linux hosts skip it, as all storage-check tests do (`requireTestStorageCheckDocker`), so macOS runs are unaffected.
- Failing rather than skipping on Linux with a remote daemon is consistent with the other storage-check tests: they need a local daemon for their bind mounts anyway.

**PLANS and the contract.**
- "About 540" and "fewer than one per 32 directories" match the code (`started*32 >= directories` fails) and the measurements.
- The contract's stale phrase catches the old sentence.

### 3.4 My mutants (`mutants25.py`)

Only the fan-out test runs. P, V and T ran as both users; the W rows ran as ci.

| Mutant | ci | ci2 | Count logged (ci) | What it shows |
| --- | --- | --- | --- | --- |
| P00 unmutated | pass | pass | 536 (ci2: 535) | the real check |
| P01 one `ls -A` per directory | caught | caught | 66,330 | an external command per directory fails on the count |
| P02 one `: "$(printf x)"` subshell per directory | caught | caught | 66,330 | a subshell per directory fails |
| P03 one `printf x \| :` pipeline per directory | caught | caught | 132,123 | two processes per directory fail |
| V01 the probe's `$0` renamed to `ars-storage-walk` | pass | pass | 5 | the probe misses the namespace; the count is only sample overhead |
| **V02** V01 plus one `ls` per directory | **survived** | **survived** | 5 | **A26-1**: a per-directory walk passes when the wrapper does not fire |
| **V03** the host part runs `/usr/bin/docker` plus one `ls` per directory | **survived** | **survived** | 5 | **A26-1**, second path |
| T00 the proposed fix, unmutated | pass | pass | 535 (ci2: 536) | the fix keeps the real check passing |
| T01 the fix plus one `ls` per directory | caught | caught | 66,331 | the count still catches it |
| T02 the fix plus V02 | caught | caught | — | "the probe did not run in the helper's PID namespace exactly once (wrapper record \"\", 5 processes counted)" |
| T03 the fix plus V03 | caught | caught | — | same message |
| W00 helper `pid_max` lowered to 32,768, unmutated | pass | | 536 (668 forks) | the guard does not fire on the real check |
| W01 W00 plus one `ls` per directory | caught by the guard | | — | "66472 processes were started on this kernel … pid_max 32768 … (PIDs 18 before and 1413 after)" |
| W02 W01 with the guard removed | survived | | 1,394 | without the guard, a wrapped namespace would pass a per-directory walk, so the guard is needed |

The W rows reproduce the writer's G00 to G02 independently, with the same outcome and nearly the same numbers (writer: PIDs 19 and 1,415, count 1,394). For W, the helper starts `--privileged` and writes 32,768 to its own namespace's `pid_max` before it sleeps. The test then reads that value as it would on a host whose limit is 32,768.

## 4. The writer's questions, answered

- **Wrapper argument handling:** correct for every argument shape the check can produce. It is missing a confirmation that it fired (A26-1).
- **Count soundness:** sound. Threads and skipped PIDs can only raise the count. `docker exec` costs 5 to 6 PIDs, not 1, which is constant noise (O26-1). The wrap guard is necessary and sufficient, and I reproduced both halves.
- **Boot-ID premise:** sound. It is the right test for "same kernel", and the test fails closed when it does not hold.
- **PLANS and contract wording:** accurate. If A26-1 is fixed, a clause such as "and requires that the probe ran in the counted namespace" would document the new check, but this is optional.

## 5. Observations (not blocking)

- **O26-1 (cosmetic):** the comment "One PID went to the second sample itself" should say that the count includes a few PIDs of Docker's own per `docker exec` and per container start (5 or 6 each here). The constant does not matter.
- **O26-2 (by design):** the test now pins processes, not time. A future walk that stays within built-ins but costs more per directory, for example one that rereads its whole list file every time, would not be caught. That trade-off is the one I recommended in O24-1:
  - since audit 24, ARS's readiness wait no longer includes the check;
  - the measured cause of A20-2 was processes per directory;
  - the time is still logged.

## 6. Evidence

Listed in `26-audit-pr19-o24-1-evidence/README.md`. No key, certificate body, token or config file is included, and all fixtures are synthetic. A pattern scan for private-key headers, certificates, and Vault, JWT, GitHub, Anthropic and AWS token shapes found nothing.
