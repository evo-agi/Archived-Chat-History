# PR #19 repair: the ARS storage check decides for the exact container identity (A11-1)

Report 13 of the CI Nomad/Vault track. It answers the coordinator's request of 2026-11-22 22:28Z: "The PR 19 audit of b98740e is BLOCK on A11-1 (low): /mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/11-audit-pr19.md (sha256 182c0311…a39d). The ARS storage check evaluates access with all of the operator's groups, but ARS runs with the primary group only. Make the check use exactly the UID and primary GID the container runs as, add a test for storage that's usable only through a supplementary group, and add the three edge-case tests whose mutants survived (report section on mutants). Pin the manifest upstream to origin/trunk_dev and give me the new head for a narrow audit."

Date: 2026-11-22. Repository: `evo-agi/Execution-Substrate`. Evidence: `13-evidence/` next to this file. `SHA256SUMS.txt` lists every file in it.

## 1. Outcome

| Item | Result |
| --- | --- |
| A11-1 | Fixed. The check gets the UID:GID that `control_plane_operator_user` printed, the same value `docker run --user` gets. It decides every entry from the entry's owner, group and mode, as the kernel does for that one UID and GID with no supplementary groups (section 3). |
| Supplementary-group test | `ARS storage usable only through a supplementary group refused`. Root owns the storage, with a supplementary group of the caller at `0770`/`0660`. The test fails on `b98740e`, where the launcher started ARS, and passes on the head. |
| O-11-1 (three surviving mutants) | Each one now has a refusal case: `relative index file refused` (P32), `storage root that is a file refused` (P42), and `storage directory the check cannot list refused` (P43). Their mutants S46, S47 and S48 are caught. |
| Found and fixed during the repair | 1. A storage root, index file or entry that the caller cannot reach made the check exit with a Python traceback. It now refuses with the path (section 3.4). A kernel comparison found this. 2. The fake-identity tests would have failed on macOS, where Python cannot read ACLs. They now hold there (section 3.5). 3. O-11-3: `01_bringup.sh up` now derives the identity before any image or storage effect. |
| Product code | None. Only scripts, tests and docs changed, so per the merge policy David does not review it. |
| Head | `07a422b4afd124710bc0320df7029a853459ac3f` on `claude/project-thread-a9tcoa-services-nonroot`, draft [PR #19](https://github.com/evo-agi/Execution-Substrate/pull/19). It merges trunk_dev `f9537a8` (PR #14). |
| Manifest | `f259b876696a49417ca953e15381c97adabcbc9aaa7cf4f32c788d6db02fe3af`, against base `f9537a8`, upstream `origin/trunk_dev`, 11 files. Taken twice, byte-identical (section 2). |
| Tests | In the container, all pass as two users: 66 subtests as 30033:30033 with sudo, and 63 plus 3 sudo skips as 31500:31600. On the GitHub runner, at `07a422b` (run 45081256107) and earlier at `199305c` (run 45080548048), the launcher tests ran with 0 skips as `runner`, and the real bring-ups as 1001:1001 and 2500:2600 passed with every service's `--user` checked and no root-owned file left (section 6.4). |
| Kernel agreement | Nine storage layouts, two identities. The check's verdict matched `setpriv --clear-groups` in every case except ACL grants, which the check refuses on purpose (section 6.3). |
| Mutants | 56 in total. As the user with sudo, 54 of the 55 mutants are caught. S44 survives: the identity regex is unreachable, because the helper validates the identity first (section 6.2). |

Nothing was merged.

## 2. Target identity

| Field | Value |
| --- | --- |
| Base | `trunk_dev` at `f9537a8680c24bf2108b95ed20ac3724e8939d3a` (PR #14) |
| Topic branch and tip | `claude/project-thread-a9tcoa-services-nonroot` at `07a422b4afd124710bc0320df7029a853459ac3f` |
| Commits since the audited `b98740e` | `63e1d34`: exact-identity check, tests, docs. `199305c`: merge of trunk_dev `f9537a8`. No file overlaps PR #14, and there were no conflicts. `07a422b`: refusals instead of tracebacks for unreachable paths, plus tests. |
| Repair diff | `b98740e..07a422b` on the PR's own files: 7 files, +566/−56: `control_plane.sh` +101/−27, `01_bringup.sh` +7/−1, `02_start_ars.sh` +1/−1, the launcher test +451/−23, runbook +4/−2, `PLANS.md` and `configuration.md` +1/−1 each. `git diff b98740e 07a422b -- scripts .runbooks PLANS.md .docs/system_overview/configuration.md es/app/service_launchers_container_user_test.go` has sha256 `6c23f863241bc6e112fc62002cbdae626010fb7df7a36733a9c823213299e71f`. |
| Recipe | `governed-execution.audit-patch-manifest.v2`. Source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c`. |
| Base-relative manifest | `f259b876696a49417ca953e15381c97adabcbc9aaa7cf4f32c788d6db02fe3af`. Taken with `umask 022` in a fresh clone from GitHub after the push. The clone was checked to be at `07a422b`, then `git reset --mixed f9537a8`, with `git branch --set-upstream-to=origin/trunk_dev` immediately before each of the two runs. The two runs are byte-identical. 11 files: 10 `tracked_modified` and 1 `untracked`, the launcher test. Textual diff `da384acfc7827c0718186c4a7f4e9a3ae58271f82bc2a3c24dabb634624125da`. Copy: `13-evidence/manifest-v2-services-07a422b.json`. |
| Files | `scripts/internal/control_plane.sh`, `scripts/01_bringup.sh`, `scripts/02_start_ars.sh`, `scripts/03_start_egs.sh`, `scripts/04_start_ags.sh`, `scripts/05_start_es.sh`, `es/app/service_launchers_container_user_test.go` (new), `es/app/operator_scripts_integration_test.go`, `PLANS.md`, `.docs/system_overview/configuration.md`, `.runbooks/system/v1_bringup.md` |

## 3. The repair

### 3.1 The decision

`verify_ars_storage_for_operator CONFIG CONTAINER_USER` takes the identity as an argument:

- `02_start_ars.sh` passes the `CONTAINER_USER` it gives `docker run --user`.
- `01_bringup.sh up` passes `control_plane_operator_user ARS`, which it derives the same way.

The embedded Python refuses anything but `^[0-9]+:[0-9]+$`. For each entry it decides access as the kernel would for that UID and GID with no supplementary groups:

1. UID 0 may use anything, because the kernel lets root.
2. If the UID owns the entry, the owner bits apply. This is exact even with a POSIX ACL, because the ACL's owner entry is the owner mode bits.
3. If the UID does not own the entry and it carries `system.posix_acl_access`, the check refuses. It does not evaluate ACLs, and a named user or group entry, or the mask, can grant or deny differently from the mode bits. If the host cannot show ACLs (no `os.getxattr`, which is every host but Linux), or reading the ACL fails with anything but ENODATA, ENOTSUP or EOPNOTSUPP, the check also refuses.
4. Otherwise the group bits apply if the entry's group is the GID, and the other bits apply if it is not.

Directories need write and search, and files need read. That is the same requirement as before. ARS writes blobs and the index as a temp file plus a rename (`ars/store/filesystem.go:128,153`, `ars/index/fileindex.go:162,187`), so the index needs read, and its directory needs write and search.

The message names the identity and gives the fix: "ARS runs as U:G, your UID and primary group, with no supplementary groups; if an earlier bring-up wrote this storage as root, or it is shared through another group, hand it back with: sudo chown [-R] U:G PATH".

Why mode bits rather than a throwaway `docker run --user U:G` probe, the audit's alternative:

- The check runs before ARS starts. It must work without a container round trip, as the rest of bring-up's static checks do.
- A behavioural probe inside a container would also have to mirror ARS's bind mounts exactly.
- The mode-bit decision is exact for everything except ACLs, and those it refuses.

### 3.2 What changes for an operator

| Storage | `b98740e` | `07a422b` |
| --- | --- | --- |
| Owned by the operator (setup and bring-up create it this way) | accepted | accepted |
| Root-owned, shared through the operator's primary group | accepted | accepted |
| Root-owned, shared only through a supplementary group (A11-1) | **accepted, then ARS returns HTTP 500** | **refused with the chown hint** |
| Root-owned and private (an earlier root bring-up) | refused, sometimes with a **traceback** | refused with the path or the chown hint |
| Not owned, with an ACL that grants the operator | accepted | refused (fails closed; the message says why) |
| On macOS, an entry the operator does not own | accepted if the caller can use it | refused: macOS has no `os.getxattr`. The supported-local setup creates all storage as the operator, so the real path stays on the owner branch. |

### 3.3 `up` ordering (O-11-3)

`cmd_up` now derives `ars_container_user` right after its trap, before `mkdir`, the Docker readiness check, the image and the storage check. This matches the launchers' rule of "derived before any image build, storage change or container change". A non-numeric `id` now stops `up` before Docker is called. A new `up` scenario pins this: no events file, no bring-up directory and no storage root.

### 3.4 Clean refusals for unreachable paths (found during the repair)

The kernel comparison (section 6.3) showed that the check, at `b98740e` and in my first repair commit, exited with a Python traceback when the caller could not search the index's directory. pathlib's `is_file`, `exists` and `is_dir` raise on EACCES. Bring-up still stopped, but with no path and no fix. Commit `07a422b` changes the check as follows:

- It stats the storage root itself. A missing root is created as the caller; if that fails, it refuses with "cannot create storage.root_dir as you". A root that is not a directory gets "is not a directory". Any other error gets "cannot reach storage.root_dir as you: PATH (strerror); you need search permission on every directory above it".
- It stats the index itself. Missing, or not a directory along the path, gets "must be an existing regular file". A directory gets the same message. Any other error gets "cannot reach storage.index_file as you".
- In the walk, it refuses an entry the caller cannot stat with "cannot reach this entry as you", plus the recursive chown hint.

### 3.5 Tests that hold on hosts without ACL reads

Python has no `os.getxattr` on macOS, so the check refuses entries there that the identity does not own. The test changes:

- `UID different from the GID` now keeps the caller's UID and uses a GID distinct from both of the caller's IDs (`testDistinctGID`). The storage the caller owns then passes on every host, and the old `0777` chmod workaround is gone.
- The fake-identity refusal cases expect a platform-dependent message (`testForeignIdentityDirectoryRefusal`): the access refusal on Linux, and the "cannot show whether it has an access ACL" refusal elsewhere.
- The three cases that decide non-owned entries by their mode bits (supplementary group, primary group, ACL not owned) are marked `needsACLReads` and skip off Linux. The new case `storage the identity does not own refused where ACLs cannot be read` covers that branch on every host.
- Two cases run the launcher's `python3` with a `sitecustomize`. One removes `os.getxattr`. The other makes it fail with EACCES. Both branches are therefore tested on Linux.

I simulated a non-Linux host on Linux. Every storage check ran without `os.getxattr`, and the test's platform switch was forced. All cases passed or skipped as designed: 49 pass, 3 skip (`svcsim-07a422b-ci.log`, patch `sim-patch.txt`). I did not run it on a Mac.

## 4. Tests

`es/app/service_launchers_container_user_test.go`, by area:

- **Identity.** The ARS check and `up` follow the container identity:
  - `storage the caller can use but the container identity cannot refused` (fake 4242:4343).
  - `index directory the container identity cannot search refused` (`0772`: other class write, no search).
  - `root identity accepted without permission bits`.
  - `up`: `storage the container identity cannot use`, and `non-numeric identity refused before any effect`.
- **A11-1 and groups.** These need passwordless sudo, and skip without it:
  - `storage usable only through a supplementary group refused`.
  - `storage shared through the primary group accepted`.
- **ACLs.**
  - `storage with an access ACL that the identity does not own refused` (sudo and setfacl).
  - `storage the identity owns with an access ACL accepted` (setfacl).
  - `storage the identity does not own refused where ACLs cannot be read` (python hook).
  - `storage whose access ACL cannot be read refused` (python hook).
- **O-11-1.** `relative index file refused`, `storage root that is a file refused`, and `storage directory the check cannot list refused` (`0300`). Also `storage directory the caller cannot search refused` (`0600`).
- **Reachability** (section 3.4). `index that is a directory refused`, `index the check cannot reach refused`, `storage root the check cannot reach refused`, `missing storage root the caller cannot create refused`, and `storage entry the check cannot reach refused`.
- **Existing cases.** Unchanged, except that the "missing storage root" case now uses the real `id` and checks that the root was created as the caller.

**Red on `b98740e`** (`svcred2-b98740e-ci.log`): this test file against `b98740e`'s scripts, run as `ci` with sudo, fails 16 storage subtests and both new `up` scenarios.

- **Behavioural failures, where b98740e started ARS or crashed:**
  - The caller-can-use and identity-cannot cases.
  - The index-directory-search case.
  - The supplementary-group case.
  - The ACL cases.
  - Both python-hook cases.
  - The five reachability cases.
  - Both `up` scenarios.
- **Wording-only failures:** the rest, whose refusal text changed from "by you" to "by your UID and primary group".

## 5. Docs

- `PLANS.md` `GENERIC-SERVICE-LAUNCHER-USER-01` covers the container identity, the kernel-style decision, root, the ACL refusal, the macOS consequence, and `up` deriving the identity first.
- `.runbooks/system/v1_bringup.md`, ARS bullet: "your UID and primary group can …". It adds that the decision is exact for the UID and GID ARS runs as, with no supplementary groups. It says an ACL on an entry you do not own is refused, that on hosts other than Linux every entry must be yours, that storage shared through another group fails with the hint, and that an unreachable root or index is refused with its path.
- `.docs/system_overview/configuration.md` ARS line: the same rule in one sentence.

## 6. Validation

### 6.1 Container (two non-root users)

On the final tree `07a422b` (`svcfinal-07a422b-uid30033.log`, `…-uid31500.log`):

- `gofmt` clean, `go vet ./es/app` passes, `GOOS=darwin GOARCH=arm64 go vet ./es/app` passes, and `bash -n` passes on all launchers.
- Launcher, `up`, ES launcher and supported-local root tests all pass: 66 subtests as 30033:30033 (groups 30033, 996, with sudo), and 63 plus 3 sudo skips as 31500:31600 (groups 31600, 996, no sudo).
- The docs tests (`go test . -run Doc`) pass as both users.

### 6.2 Mutants (`mutants_services_v3.py.txt`)

56 mutants:

- the 30 from report 07, with updated strings where the check changed;
- 20 new ones for the identity decision, ACLs, root, `up` ordering, and the three O-11-1 refusals;
- 5 for the unreachable-path refusals.

Each mutant ran against `TestServiceLaunchersContainerUser`, `TestBringupUpChecksARSStorageBeforeStartingServices` and `TestESLauncherContainerUser`. Every mutant was checked first to apply, and to pass `bash -n` and Python compilation.

| Run | Caught | Survived |
| --- | --- | --- |
| 30033:30033, sudo | 54 of 55 | S44 |
| 31500:31600, no sudo | 52 of 55 | S44, plus S33 (group class never used) and S35 (ACL refusal removed). Their only catching cases need sudo and skip for this user. The runner has passwordless sudo, and PR #14's gate fails the PR if those cases skip there. |

Selected catches:

| Mutant | Caught by |
| --- | --- |
| S31 decide with the caller's access (the A11-1 regression) | the fake-identity cases, supplementary group |
| S32 decide for the process identity | the fake-identity cases |
| S33 group class never used / S34 always used | primary group accepted / supplementary group, index-directory search |
| S35 ACL refusal removed / S36 ACL refused on owned entries | ACL not owned / ACL owned |
| S37 root bypass removed | root identity, unreachable entry |
| S41 `up` identity after the image / S42 fixed `0:0` | `up` non-numeric before any effect / `up` identity |
| S46 / S47 / S48 (audit P32 / P42 / P43) | relative index / root is a file / unlistable directory |
| S49 ACL read error ignored / S50 no `getxattr` treated as no ACL | the two python-hook cases |
| S51 to S55 index directory allowed, tracebacks for unreachable index, root, creation and entries | the five reachability cases |

S44 changes `re.fullmatch` on the identity to `re.match`, which accepts a numeric prefix such as `1:2x`. It is unreachable: both callers pass `control_plane_operator_user`'s output, which has already refused anything but two numeric IDs. The `TestServiceLaunchersContainerUser` identity cases pin that. I kept the check as defence in depth and did not add a test that calls the function directly with a malformed identity.

### 6.3 Kernel agreement (`agree.sh`, `agree-*.log`)

As root in the container, nine storage layouts were built: index directory plus index, storage root plus a subdirectory plus a blob. For each, the check's verdict (run as the caller, with identity U:G) was compared with the kernel's verdict for U:G with no supplementary groups. The kernel verdict comes from `setpriv --reuid U --regid G --clear-groups`, creating and removing a file in every directory and reading every file.

| Layout | Kernel | `b98740e` check | `07a422b` check |
| --- | --- | --- | --- |
| owned `0755`/`0644` | ok | accept | accept |
| root, primary group `0770`/`0640` | ok | accept | accept |
| root, supplementary group `0770`/`0640` | **denied** | **accept (A11-1)** | refuse |
| root private `0700`/`0600` | denied | refuse (traceback) | refuse with path |
| root `0777`/`0644` (other class) | ok | accept | accept |
| owned `0577`/`0444` (owner class without write) | denied | refuse | refuse |
| root, primary group `0707`/`0604` (group class denies, other allows) | denied | refuse (traceback) | refuse with path |
| root `0700` with ACL `u:U:rwx` | ok | accept | **refuse (by design)** |
| root `0777` with ACL `u:U:---` | denied | refuse (traceback) | refuse with path |

The identities were 30033:30033 (caller `ci`, supplementary 996) and 31500:31600 (caller `ci3`, supplementary 996). The `07a422b` check agrees with the kernel in 8 of 9 layouts for both. The ninth is the ACL grant it refuses on purpose. The `b98740e` check differs on the supplementary-group layout. That is A11-1, the same result the audit observed live.

### 6.4 GitHub runner

The probe workflow is `probe-services-repair.yml.txt`, pushed on the probe branch, which only fast-forwards.

**Run [45080548048](https://github.com/evo-agi/Execution-Substrate/actions/runs/45080548048) on `199305c`** (probe commit `0392dc0`). Success. Log: `runner-45080548048-job137387503101.log`.

- Host: passwordless sudo, `/usr/bin/setfacl`, `os.getxattr: True`.
- Launcher tests as `runner` (1001:1001): 56 subtests passed, **0 skipped**.
- Bring-up test as `runner`: passed in 65 s. The ARS, EGS, AGS and ES logs all show `--user 1001:1001`, and 0 root-owned entries were left.
- Second operator 2500:2600 (supplementary group `docker`): launcher tests pass with the 3 sudo cases skipped. The bring-up test passed, all four logs show `--user 2500:2600`, and 0 root-owned entries were left.
- The docs tests pass. Whole `es/app` (informational) fails only the three known pre-existing tests: `TestSupportedLocalSetupExactGoPreflightBeforeMutation`, `TestSupportedLocalProofExactGoPreflightBeforeMutation` and `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`.

**Run [45081256107](https://github.com/evo-agi/Execution-Substrate/actions/runs/45081256107) on the final head `07a422b`** (probe commit `39dbd2a`). Success. Log: `runner-45081256107-job137389703870.log`.

- Launcher tests as `runner`: 61 subtests passed, **0 skipped**.
- Bring-up as `runner`: passed in 54 s, all four logs show `--user 1001:1001`, and 0 root-owned entries were left.
- As 2500:2600: launcher tests pass with 3 sudo skips. The bring-up passed, all four logs show `--user 2500:2600`, and 0 root-owned entries were left.
- The docs tests pass. Whole `es/app` again fails only the same three known pre-existing tests.

**PR #19's own CI** on `07a422b` (PR #14's gate, [run 45081257893](https://github.com/evo-agi/Execution-Substrate/actions/runs/45081257893)): success. Build, vet, macOS vet, the gate self-check, Test and Listed tests still fail all passed. That gate fails on any test that skips itself on the runner without a `skips-itself` line, so the sudo, supplementary-group and setfacl cases ran there. Log: `ci-pr19-45081257893-job137389788918.log`.

## 7. Audit observations

- **O-11-1:** closed (section 6.2).
- **O-11-2:** a setgid storage directory does not break ARS. I did not run this. Code reading agrees with the audit: there is no chown in `ars/`, and writes are a temp file plus a rename. Under the new check, setgid storage whose group is not the operator's primary group is still accepted when the operator owns every entry. Entries ARS creates inherit the directory's group, but ARS owns them. The integration test's ownership assertion would flag inherited-group storage, as the audit noted.
- **O-11-3:** addressed (section 3.3).

## 8. Not run, limits

- I did not run anything on macOS. The non-Linux branch was simulated on Linux (section 3.5), and `GOOS=darwin go vet` passes. The supported-local proof on the Mac (`scripts/73_supported_local_proof.sh`) has not run with PR #19.
- The check does not evaluate POSIX ACLs. It refuses non-owned entries that have one, which fails closed. An operator who shares storage through an ACL must hand it to their own UID instead.
- I did not run a live bring-up with storage shared only through a supplementary group, the audit's red. The unit case runs the real launcher with the real `id` on the runner, which has supplementary groups and sudo. The kernel comparison shows that verdict matches the kernel.
- Rootless Docker and user-namespace remapping are out of scope. They are unsupported for bring-up, per PR #18's PLANS text.

## 9. Effects

- Pushed `63e1d34`, `199305c` and `07a422b` to `claude/project-thread-a9tcoa-services-nonroot`, the draft PR #19. No force-push.
- Probe branch `claude/project-thread-a9tcoa-bringup-probe` was fast-forwarded to `0392dc0` and then to `39dbd2a`. Each is a merge whose tree is the services head plus `.github/workflows/probe-services-repair.yml`. This session cannot delete the branch; David can delete it when the audits no longer need it.
- Nothing was merged.

## 10. Handover

Narrow audit of `b98740e..07a422b`, on the PR's files, against `11-audit-pr19.md`. The merge `199305c` brings in PR #14 only, with no file overlap. This is scripts, tests and docs only, so no red-team is needed by the project rule and David does not review it. The manifest is `f259b876…e3af` against `f9537a8`, with upstream `origin/trunk_dev`.
