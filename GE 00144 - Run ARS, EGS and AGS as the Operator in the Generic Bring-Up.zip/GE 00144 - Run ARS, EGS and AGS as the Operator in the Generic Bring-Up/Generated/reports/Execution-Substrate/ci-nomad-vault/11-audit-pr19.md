# ES PR #19 audit: ARS, EGS and AGS run as the operator in bring-up

Independent correctness audit, requested by the coordinator on 2026-11-22 22:12Z. Written by the audit thread "Audit bring-up running as the operator", 22:12Z to about 22:35Z.
Evidence: `11-audit-pr19-evidence/` beside this file (`SHA256SUMS.txt` lists every file).

**Final verdict for `b98740e`: BLOCK, on one low finding (A11-1).**

What holds:
- The change narrows privilege as intended. ARS, EGS, AGS and ES all ran as 1500:1600 with no other groups in every bring-up run.
- The workspace was left with 0 root-owned entries. The base run left 16 root-owned ARS files and directories.
- Non-numeric IDs are refused before any effect.
- The scope is scripts, tests and docs only.
- 40 of my 43 mutants are caught.

What blocks:
- **A11-1.** The new ARS storage check tests access with the operator's full group list, while ARS runs with the primary group only. Storage usable only through a supplementary group therefore passes the check, and ARS then fails. I reproduced that in bring-up: the check passed, ARS reported healthy, and bring-up then stopped on an HTTP 500 for the Vault blob, instead of the check's clear refusal with its `chown` hint.
- The PR's own docs say the check refuses storage that ARS cannot use, so this is the same class as A6-1 on PR #18. The fix is small and in scope.

## 1. Audit target

| Field | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate`, draft PR #19 into `trunk_dev` |
| Topic branch | `claude/project-thread-a9tcoa-services-nonroot` |
| Head | `b98740e48526a14c2d0661b49deca3938f67c441`, also `refs/pull/19/head` (`git ls-remote` at the start and at the end) |
| Head tree | `ba108a055649941770ab20a2d3ea2dce4dac1724`, equal to `81b7dc5`'s tree, as the writer says |
| Base | `trunk_dev` at `3a5f25776274b3e9ada3e2d489c9bfe0e8bf8a28` (PR #18's squash), unchanged at the end. Its tree equals `d6aded1`'s (`9be50458…`), the head that addendum 3 accepted. |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` before each run |
| Canonical manifest | `e3b956e995d86f953f4b90ba98078e118cb16eeaf41ad5340cee96d5936f02ac`, upstream `origin/trunk_dev`, 11 paths (10 `tracked_modified`, 1 `untracked`), textual diff `d429452637cc62f110beeb9a576d4350301664a8e8d1d3227433007e78ad9ca2` |
| Writer report | `07-services-nonroot.md`, SHA-256 `8753b79913a2475f825b47013e0617836ebed0d6d9b19f5aa8de6c01d7663acb`; `07-evidence/SHA256SUMS.txt` checks OK |

Posture: read-only. No push, PR comment, review, edit or merge. No subagents.

## 2. Provenance

I took the manifest first, before reading the diff, per provenance §5.3. It was taken in a clean clone, with HEAD reset to `3a5f257`, the tip bytes in the tree and upstream `origin/trunk_dev`.
- Two opening and two closing runs are byte-identical: `e3b956e9…02ac`.
- They equal the reported value and the writer's copy `07-evidence/manifest-v2-services-b98740e.json`.

## 3. Scope

The 11 paths are:
- `scripts/internal/control_plane.sh`
- `scripts/01_bringup.sh`
- `scripts/02_start_ars.sh`, `03_start_egs.sh`, `04_start_ags.sh`, `05_start_es.sh`
- `es/app/service_launchers_container_user_test.go` (new)
- `es/app/operator_scripts_integration_test.go`
- `PLANS.md`
- `.docs/system_overview/configuration.md`
- `.runbooks/system/v1_bringup.md`

No non-test Go file changed. The audit image (binaries built offline from `bede334` sources, see `05-audit-evidence/README.md`) is therefore valid for both base and head. Neither PR #17 nor PR #18 changed non-test Go.

## 4. Review

**Privilege.** Each of `02`, `03` and `04` gains `--user "${CONTAINER_USER}"` on both the printed and the executed `docker run`. Nothing else in those command lines changed: no new mounts, capabilities or flags. ARS, EGS and AGS contain no `chown`, `Geteuid`/`Getuid` or `Setuid` call (`grep` over `ars egs ags internal cmd`, non-test). ARS's startup only opens the store and the index (`ars/app/app.go:37-46`, `ars/index/fileindex.go:27`). So running them as the operator removes root from three containers and adds nothing. Under the supported-local layout, ARS mounts its index directory (the proof directory) read-write. As the operator it can no longer write ES's `0:0` roots there.

**UID/GID handling.** `control_plane_operator_user` (`control_plane.sh:159-172`):
- reads `id -u` and `id -g`, each with `|| return 1`;
- checks both against `^[0-9]+$`;
- prints `UID:GID`.

Each launcher assigns it at top level, or inside the `if` body for ES, under `set -euo pipefail`, so a non-zero return stops the launcher. The ID call comes before `ensure_control_plane_image` in all four launchers. ES keeps its exact refusal text, and its 9-subtest launcher test passes unchanged. `--user :GID` and `UID` alone cannot be produced: mutants P09, P10 and P22 are caught.

**ARS storage check.** `verify_ars_storage_for_operator` (`control_plane.sh:182-256`):
- refuses relative paths;
- creates a missing root as the caller;
- requires an existing index file;
- checks `W_OK|X_OK` on the index directory and every directory under the root;
- checks `R_OK` on the index and every regular file;
- prints a recursive `chown -R` hint for the root, and a non-recursive one for the index or its directory.

Running it as the operator cannot widen privilege: it only reads, refuses, or makes one directory as the caller. Symlinked entries are not followed by the walk, and the regular-file test uses `lstat`. It is, however, evaluated with the caller's full credentials. See A11-1.

**Ordering.** In `02_start_ars.sh` the order is identity, image check, storage check, then `docker rm`. In `01_bringup.sh up`, the storage check runs after the ES root check and before any service starts (`01_bringup.sh:225`), which the new up test pins. Note: in `up`, the image build and the storage-root `mkdir` come before any launcher's ID check. That matches PR #18's ES roots and is harmless, because `mkdir` runs as the caller (O-11-3).

**Docs.** `PLANS.md` `GENERIC-SERVICE-LAUNCHER-USER-01`, `configuration.md` and the runbook describe the identity, the storage requirements and the port rule correctly. The one exception is their implicit claim that passing the check means ARS can use the storage (A11-1).

## 5. Validation

All runs used `env -i` plus `ci-env.sh` (umask 022, `AWS_EC2_METADATA_DISABLED=true`, `GOTOOLCHAIN=local`), Go 1.26.5, Nomad 2.1.1, Vault 2.2.2, SPIRE 1.14.4 and Docker 29.10.0. Test users:
- `ci` = 1500:1600, UID different from GID, groups cigrp and docker;
- `ci2` = 1700:1700.

| Check | Result |
| --- | --- |
| `go vet ./es/app`, `gofmt -l es/app scripts`, `bash -n` on the six scripts, as `ci` and `ci2` | clean (`unit-tests-b98740e-ci.log`, `-ci2.log`) |
| `TestServiceLaunchersContainerUser`, `TestBringupUpChecksARSStorageBeforeStartingServices`, `TestESLauncherContainerUser`, `TestSupportedLocalExecutionRoot*`, as `ci` and as `ci2` | all pass, no skips (as non-root, the permission subtests run) |
| `go test . -run Doc` | ok (`ci2`, and `ci` on an intact tree: `docs-test-b98740e-ci-intact-tree.log`; see the harness note below) |
| 43 mutants (`mutants11.py.txt`), as `ci` and as `ci2` | **40 caught, 3 survived** (O-11-1), identical for both users |
| Bring-up on `b98740e` as `ci` (1500:1600), 3 runs keeping the workspace, plus 2 runs on an intact tree (one with `down`, one keeping the workspace) | **5 of 5 PASS**. Every sample of ARS, EGS, AGS and ES PID 1: Uid 1500, Gid 1600, Groups 1600, `Config.User` `1500:1600`. Kept workspaces: 125 or 126 entries, **all 1500:1600, 0 root-owned**. |
| Bring-up on base `3a5f257` as `ci`, keeping the workspace | PASS. ARS, EGS and AGS PID 1 have Uid 0 with root's groups; ES has 1500:1600. **16 root-owned entries**: the index file, 5 ARS blobs (`0:0 600`) and 10 blob directories (`0:0 755`). This is the leftover the PR removes. |
| Bring-up on `b98740e` with ARS storage usable only through the `docker` group | **FAIL after the check passed** (A11-1) |

The 43 mutants cover:
- **Identity helper:** swap, GID=UID, UID only, no check, each anchor, `||` turned into `&&`, `*`, no `return` after the refusal, a swallowed `id` failure, fixed `0:0`, `-ru`/`-rg`.
- **Launchers:** `--user` dropped from the executed or printed line for each service, `--user` after the image, a swallowed helper, identity after the image or after the storage check, ES without `--user`, ES with `:GID`.
- **Wiring:** storage check removed, ignored or moved after `docker rm`, in both `02_start_ars.sh` and `01_bringup.sh up`.
- **Storage check logic:** 15 variants.

Harness notes:
- With `EXECUTION_PLATFORM_KEEP_TEST_WORKSPACE=1` the test skips `down`, so the services of the kept runs stayed up until I removed them. One run on an intact tree exercised `down` normally.
- I had removed the audit copy's `.out` folder, which holds the tracked generated `.out/Dockerfile`. The bring-up path does not read that file under the `CONTROL_PLANE_DOCKERFILE` override: runs on an intact `git archive` tree passed in the same way. Only the root docs tests need it, and they pass on the intact tree.
- The same removal happened to the `f5510db` tree in addendum 1. Those bring-up results are unaffected for the same reason.

## 6. Findings

```text
AUDIT FINDING A11-1
Type / Severity: correctness of the new storage check / docs claim; low
Patch defect or pre-existing: patch defect (new in b98740e)
Current contract: the runbook's ARS bullet ("ARS runs in its container as your numeric UID and primary
  GID, with no supplementary groups. Before any service starts, bring-up checks ARS's storage and
  refuses unless: … you can write to and search every directory under the storage root, and read
  every file there"); PLANS.md GENERIC-SERVICE-LAUNCHER-USER-01; report 07 §3 "The check turns that
  into a refusal at bring-up time, with the fix in the message."
Path: scripts/internal/control_plane.sh:234, 236, 249, 253, where os.access(...) is evaluated with the
  calling process's real UID, real GID and all its supplementary groups.
Evidence:
  (1) storage-check-supplementary-group.log: storage root:docker, directories 0775, files 0640; ci is
      in group docker. The PR's check run as ci prints "storage check: PASSED". The same check run as
      1500:1600 with no supplementary groups (setpriv --clear-groups, the identity docker run --user
      1500:1600 gives ARS) refuses. That identity cannot read the blob or create a file there.
  (2) bringup-group-storage-b98740e*.log, group-storage-watcher.log: the bring-up test's ARS storage
      was made root:docker 0775/0640 after the test wrote its blob. `up` printed no storage-check
      refusal, ARS ran as 1500:1600 (Groups 1600) and reported "status=healthy ready=true". Then
      "curl: (22) The requested URL returned error: 500 / workload-zone vault blob read failed",
      ARS logged GET /v1/blobs/… server_error, and bring-up stopped.
Impact: storage shared through a group, or a root-written store that an operator "fixes" with
  `chgrp -R <team>` and g+rw instead of the printed `chown`, passes the check. ARS then fails with an
  opaque HTTP 500 instead of the refusal and hint the check exists to give. Fails closed: no
  privilege, no data change.
Required correction (in scope, scripts and tests only): evaluate access for the container identity,
  not the caller's process. For example, decide by mode bits for UID `id -u` and GID `id -g` only
  (owner bits if the UID matches, otherwise group bits if the GID matches, otherwise other bits).
  Note that ACL grants would then be refused. A behavioural alternative is a throwaway
  `docker run --user UID:GID` probe on the mounted storage, like the host-loopback probe. Add a
  test case with storage usable only through a supplementary group of the caller. The test needs
  a fixture group, and can skip without one.
  Optionally, the runbook can say "by your UID or primary group", as it already does for *_file.
Uncertainty: none on the behaviour. The fix design is the writer's choice.
```

```text
OBSERVATION O-11-1 (test coverage)
Three storage-check mutants survive as both users:
  P32: the isabs check on storage.index_file removed. No test gives a relative index path. Such a
       path is never mounted, because control_plane_mount_specs skips relative paths, so ARS would fail.
  P42: the "storage.root_dir is not a directory" refusal removed. No test gives a file as the root.
  P43: walk errors ignored (os.walk without onerror). No test has an unlistable directory
       under the root.
All three fail closed at ARS start or first use. Suggested: one refusal case each, in the A11-1 repair.
```

```text
OBSERVATION O-11-2 (report claim not run)
Report 07 §1 says a setgid storage directory does not break ARS, because ARS does no chown.
Code reading agrees: there is no chown in ars/, and blobs are written as temp file plus rename.
I did not run it. Note that the integration test's ownership assertion
(assertBringupServicesRunAsOperator) would fail on inherited-group storage. That is a test
expectation, not an ARS failure.
```

```text
OBSERVATION O-11-3 (ordering, report only)
In `01_bringup.sh up`, ensure_control_plane_image and verify_ars_storage_for_operator (which may mkdir
the storage root) run before any launcher derives the identity. The launchers' comments ("derived
before any image build, storage change or container change") hold per launcher. The mkdir runs as
the caller, so this is harmless, and it is consistent with PR #18's ES roots.
```

Report only:
- The writer's 30 mutants are all caught, by the writer's run. I did not reuse that runner.
- A6-3 (ES does not catch setgid-inherited roots) is unrelated to this PR and has its own branch.

## 7. Sensitive material

The bring-up tests use synthetic fixtures. No key, certificate body, token or config file is in the evidence. Private service logs stayed in the container. The ARS excerpt contains event, route and status, with digests and IDs masked. A pattern scan of the evidence (private-key headers; Vault, JWT, GitHub, Anthropic and AWS token shapes) found nothing.

## 8. Cleanup and effect status

- The audit created container-only artifacts:
  - trees under `/home/ci/es11*` and `/home/ci2/es11`;
  - the kept workspaces, which were removed;
  - the service containers of the kept runs, which were removed;
  - a temporary `/home/ci/sgtest`, which was removed.
- dockerd was restarted twice during the session after stopping on its own.
- No push, comment, review, edit, merge or branch change.

## 9. Confidence and what turns this into ACCEPT

Confidence:
- Provenance: high.
- Privilege and identity handling: high (code, 43 mutants, 7 bring-up runs).
- A11-1: high (reproduced statically and end to end).

To reach ACCEPT:
1. A repair of A11-1 in `verify_ars_storage_for_operator`, plus a test for group-only access.
2. Optionally, the three O-11-1 test cases.
3. A new base-pinned manifest, then a narrow audit of that delta.

Final verdict: BLOCK
