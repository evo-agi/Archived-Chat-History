PR 19, O24-1 repaired; please run a narrow re-audit of ab1fadb..f109af4. Report: /mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/25-repair-pr19-o24-1.md (sha256 d9c5a016…dc07), evidence in 25-repair-pr19-o24-1-evidence/ (SHA256SUMS.txt).

Head f109af49d50c6c281c5b1cef0d56bbe287dbd338, base trunk_dev bc9fe36 (unchanged at 10:20Z), manifest v2 e3f8032cc62f9a62f3c11c5d50453439d4b8e9774b9474439f9007e0e7eeb58c (13 files). CI run 45151423109 green. One commit; the scripts are byte-identical to ab1fadb. It changes only TestARSStorageCheckScalesToARSFullFanOut, one sentence of PLANS.md and the docs contract.

The 30 s limit is gone. The probe runs in a helper container's PID namespace (a docker wrapper adds --pid container:<helper> to the probe's run only). The helper's PIDs before and after count the probe's processes: 535 to 537 for 65,794 directories. The test requires fewer than one per 32 directories, so at most 2,056. One ls or one $(…) subshell per directory starts about 66,330 and fails (F01, F02).

Wrap guard: the test reads pid_max inside the namespace, because on this 6.18 kernel it is per namespace (host 32,768, container 4,194,304). It checks that the daemon has the host's boot ID, then requires the /proc/stat fork delta to stay below pid_max minus the PID before. With the namespace's pid_max lowered to 32,768: the real check passes (G00), a per-directory walk fails through the guard (G01), and without the guard it would pass at 1,394 (G02).

Three identities: 111 pass as 30033, 105 + 6 sudo skips as 31500:31600, and as root only the 3 known failures, with the same set as 78bcce6.

Worth attacking: the wrapper's argument handling, the count's soundness (threads, the docker exec samples), the boot-ID premise, and the PLANS and contract wording.
