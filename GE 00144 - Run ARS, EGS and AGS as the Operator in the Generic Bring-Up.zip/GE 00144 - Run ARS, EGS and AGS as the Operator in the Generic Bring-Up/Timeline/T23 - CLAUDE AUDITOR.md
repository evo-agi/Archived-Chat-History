**Verdict: BLOCK on PR 19 at be71f84 (A20-1 and A20-2).** The report is [20-audit-pr19-repair.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/20-audit-pr19-repair.md), sha256 `5f6af224a913def0179890ef0787e0e3956391cbc214c2b62ce6d533ec148095`. Number 19 was taken while I worked, so it went to 20.

**What the repair fixes.** A11-1, A12-1 and A12-2 are closed, and the check now runs exactly as ARS runs. Against the real ARS binary on 50 layouts, the check agrees in 40 and is stricter in 5. The tests pass as both test users. CI is green. The manifest is cf8e81be…dea5 at the start and the end.

**What still blocks:**
- **A20-1 (Medium): 5 layouts where the check is looser than ARS.** The check cleans up the storage paths before using them (it trims spaces and resolves `..` on paper), and ARS's mounts use the cleaned paths too. ARS opens the configured text exactly as written. Five such paths pass the check, then ARS fails at startup: `..` in either path, a leading or trailing space, and a trailing slash on the index. The fix is to refuse any path that is not already in its cleaned form.
- **A20-2 (Medium): bring-up fails on valid storage once it has many directories.** The check starts three processes for every storage directory, about 1.7 ms each. The launcher runs it inside the 30 s wait for ARS to become ready. ARS's storage can grow to 65,794 directories, not "a few hundred" as the repair report says. A real bring-up with 49,410 directories failed even with the test's 60 s wait.
- **A20-3 (Low):** a folder named `-` in a storage path gets a wrong refusal with a garbled message.

**Before merging.** trunk_dev is now 110d377, so the branch update will need a fresh manifest.

Evidence: [20-audit-pr19-repair-evidence/](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/20-audit-pr19-repair-evidence/README.md), 29 files, with checksums verified after the write.

STATUS: READY
