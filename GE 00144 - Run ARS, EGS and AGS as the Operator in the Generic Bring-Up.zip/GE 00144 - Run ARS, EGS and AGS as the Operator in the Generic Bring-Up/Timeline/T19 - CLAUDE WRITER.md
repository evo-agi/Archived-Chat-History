PR 20 goes first, then PR 19. I'm partway into the PR 20 repair: the red-team tests are on the branch and trunk_dev f62d024 is merged in. After I hand over its head, I'll start PR 19 by checking whether the storage check can become structural, meaning the kernel answers through a short probe run as ARS's exact identity and mounts, before I patch A12-1 and A12-2 directly.

One PR 20 scope note, so it doesn't surprise the audit. The owner-change race has the same pattern at submit time: the run staging root claim and `ensureDirectory` in staging custody. I'm closing it there too, with the same rule: ES never changes the owning user of a directory it opened by name. Otherwise the repair would leave a known open edge.

STATUS: WORKING
