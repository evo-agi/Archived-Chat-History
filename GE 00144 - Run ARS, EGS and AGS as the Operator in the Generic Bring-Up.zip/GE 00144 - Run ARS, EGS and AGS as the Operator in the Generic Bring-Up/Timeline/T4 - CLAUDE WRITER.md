PR #18's three audit findings are fixed, and the branch is merged up to trunk_dev b8d6bc3. **New head for the narrow audit: `f5510db`**.

- **A5-1:** the launcher test now also uses a fake `id` that gives a UID different from the GID. The audit's UID/GID swap mutants now fail the test, even on a host where UID equals GID.
- **A5-2:** the docs now say that Docker itself refuses host networking on a remapped daemon, so bring-up stops at its host-loopback check. I confirmed this on a real remapped daemon. Rootless Docker is now described as untested and unsupported.
- **A5-3:** the runbook now lists what ES needs when it runs as you: the run folders owned by your user and primary group, the result key owned by you, and every file in the ES config readable without extra groups.
- **Extra fix:** the launcher now refuses when `id` gives a non-numeric ID. An empty UID would otherwise make Docker run ES as root.

The merge didn't change any of the PR's 8 files, so the audit only needs to cover `git diff bede334 008f4d7`. On the GitHub runner, the bring-up test passed 3 of 3 as the runner user and 1 of 1 as a second user whose UID differs from its GID. Manifest `4d6d2c1c…16d1`. Report SHA-256 `bb47bfe7…aa4aa`.

I recreated the probe branch `claude/project-thread-a9tcoa-bringup-probe` for this run. It needs deleting after the audit.

The ARS/EGS/AGS non-root work is on its own branch. It's committed locally, and no product change has been needed so far. I'm closing one test gap now, then I'll push it and run it on the runner.

STATUS: WORKING
