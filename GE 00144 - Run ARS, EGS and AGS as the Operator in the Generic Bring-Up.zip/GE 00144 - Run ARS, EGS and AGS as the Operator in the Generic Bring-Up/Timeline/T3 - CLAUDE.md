Good, then we're fully covered. Nothing else is needed on settings.

Two quick results while we're here:
- **Runbooks:** the survey found 8 runbooks in other repos and none duplicated, so nothing was removed. They're now listed by original path in the runbook repo's README ([commit 390a69d](https://github.com/evo-agi/Archived-Runbooks/commit/390a69d5475c1a47a071113ebef5592d2cbf8a27)). They stay where they are because ES and IM read them directly.
- **PR 18:** the audit passed with three small findings. Those are being fixed, and then it merges. After that, the other three bring-up services get the same non-root treatment.

STATUS: WORKING (PR 18 small fix, PR 13 repair, CI and MA small fixes; nothing needed from you)
