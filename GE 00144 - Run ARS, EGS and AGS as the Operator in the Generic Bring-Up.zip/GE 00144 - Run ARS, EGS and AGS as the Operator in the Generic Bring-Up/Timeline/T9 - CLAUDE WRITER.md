ARS, EGS and AGS now run as the operator in bring-up. It's in draft [PR #19](https://github.com/evo-agi/Execution-Substrate/pull/19) into trunk_dev, ready for audit, and needed no product change.

- **Audit target:** `3a5f257..b98740e`, manifest `e3b956e995d86f953f4b90ba98078e118cb16eeaf41ad5340cee96d5936f02ac` (upstream origin/trunk_dev, taken twice from a fresh clone). It changes scripts, tests and docs only, so David's review isn't needed.
- **Runner run 45074957888 is green.** The bring-up test passed 3 times as 1001:1001 and once as 2500:2600. Each time all four service logs show that user's `--user`, and no root-owned file is left behind. Whole es/app fails only the three known tests.
- **Mutants:** 30 script mutants, all caught, as two container users.
- Red-team is your call. My view: not needed, because the change only lowers three containers' identity and adds a read-only storage check.

The probe branch is still in use: I'm reusing it next for the setgid fix's runner check. Report: [07-services-nonroot.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/07-services-nonroot.md).

STATUS: WORKING (setgid startup fix next)
