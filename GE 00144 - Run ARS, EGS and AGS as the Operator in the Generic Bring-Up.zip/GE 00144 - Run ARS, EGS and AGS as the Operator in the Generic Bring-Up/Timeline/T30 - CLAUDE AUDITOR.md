**The PR #19 re-audit at ab1fadb passes (ACCEPT).** The report is [24-audit-pr19-repair2.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/24-audit-pr19-repair2.md), sha256 `43123ac0079587a9aca77b5b3fecbbfb34b71d8b5f61e73949a4b2908db131b3`, with 37 evidence files.

**Gate data**
- Manifest `7c0727f4…9364` against base `bc9fe36`, taken at the start (08:13Z) and the end (09:31Z). It matches the writer's, and trunk_dev is still `bc9fe36`.
- CI run 45126395110 is green.
- Tests pass for the sudo user (111/111) and for the user without sudo (105, plus 6 rows that need sudo and skip).
- The change is scripts, tests and docs only.

**Your two questions**
- **D23 (a second path form ARS could use, now refused):** this is acceptable and documented. It is the rule I recommended in audit 20. Allowing `..` would be unsafe: with `..` after a symlink, ARS checks one directory at startup but writes blobs into another (layout F07). The runbook, configuration.md and PLANS.md all state the rule, and the refusal message shows the form to write.
- **The 65,794-directory timing:** confirmed. One check took 9.4 to 16.5 s. A real `up` at full size passed with the default timeout in 34.2 s. Also, `up` now waits for the storage check to finish before its readiness wait starts, so a slow check can no longer time out ARS's readiness.

**Other results**
- All three audit-20 findings are closed. Across 59 storage layouts tested against the real ARS binary, the check is never looser than ARS (51 agree, 8 stricter).
- Of my 46 mutants, 39 were caught as the sudo user and 37 as the other user. Every survivor is harmless: equivalent, a guard, cost only, defence in depth, race-only, or caught by a CI row that needs sudo.

**One low finding, O24-1.** The fan-out test's fixed 30 s limit could flake on a slow runner. It has less than 2x headroom as the slower user here. If it ever flakes, replace the limit with a structural check rather than raising it.

STATUS: READY
