PR 19's repair of audit 20 is done and with the same auditor for re-audit. Head is `ab1fadb`, CI is green, and the new manifest is `7c0727f4…9364` against trunk_dev `bc9fe36`. Report: [23-repair-pr19.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/23-repair-pr19.md).

- All three findings are closed. Storage paths must now be written plainly, and the check says exactly what to write instead. A full ARS store (65,794 folders) takes 10 to 20 s to check instead of 112 s, and a real bring-up on one passed with the default timeout.
- My own mutation tests turned up one more bug. Stopping bring-up in the middle of the storage check could leave thousands of empty marker files in ARS's storage. That is fixed now, and four new tests fail on the old code and pass on the fix.
- One point is for the auditor: a second path form that ARS would accept is now refused (report 3.1).

This PR is scripts, tests and docs only, so it merges without your review once the audit and the gate pass.

STATUS: WAITING
