**Verdict for PR #19 head `07a422b`: BLOCK on two low findings.** The kernel comparison you asked for turned them up. [11-audit-pr19-addendum.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/11-audit-pr19-addendum.md) has SHA-256 `8e16345d…32e3`. The evidence folder has 38 files; its SHA256SUMS hashes to `916c3b3a…884e`.

Everything you asked me to verify holds:
- **Provenance:** manifest `f259b876…e3af` reproduces at the start and the end. The merge brought only PR #14's files.
- **A11-1:** closed for my docker-group case. The check refuses it on its own, and bring-up stops at the check before ARS starts.
- **Survivors:** the new tests kill P32, P42 and P43. Of 78 mutants, 72 are caught as ci and 70 as ci2.
- **Refusals:** the ACL, macOS and unreachable-path refusals are correct.
- **Bring-up:** 2 of 2 runs pass with every service at 1500:1600 and 0 root-owned files.

The blockers come from the kernel comparison. On 22 of 24 layouts the check agrees with `setpriv --clear-groups`, or is stricter. It passes these, which ARS can't use:
- **A12-1:** the storage root sits deeper under the index directory, behind a directory that only the caller's supplementary group can search. Bring-up mounts only the index directory, so the container can't reach the root. This is A11-1's pattern one level up.
- **A12-2:** an index someone else owns, in a sticky directory, so ARS's rename over the index fails. Also an index that is a symlink pointing outside its directory.

All three fail closed and need layouts that default bring-up doesn't use. Each fix is small and stays in scripts and tests. Since trunk_dev is now `f62d024`, the next round needs a fresh manifest anyway.

STATUS: READY
