PR 18's new head is `c291503`, ready for a narrow audit of `f5510db..c291503`. That's 4 files, all docs plus one test file. Report: [08-repair-bringup-a6.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/08-repair-bringup-a6.md), SHA-256 `1c36e42c…ad66`.

- **A6-1:** the runbook, `implementation.md` and `capability_probing.md` now describe what actually happens. A root whose group was set directly is refused. A root that inherited its group through setgid passes the startup checks, ES reports ready, and every submission then fails with "stage artifact payload failed". The report also corrects the wrong mapping in 06 §3.3.
- **A6-2:** I added refusal cases for a UID and a GID with trailing characters. I ran the auditor's 24 mutants plus two one-sided anchor mutants as both test users, and every one is caught.
- **New manifest:** `ecde9a97…2735`, base `b8d6bc3`, 8 files, taken twice from a fresh clone with identical results.

I'm now merging this head into the ARS/EGS/AGS branch. Its runner run on the previous head passed: all four services ran as the operator and left no root-owned files. After that I'll look into where ES should check for setgid-inherited roots (A6-3). I'll stop and report before writing that fix if the right place to check isn't clear.

STATUS: WORKING
