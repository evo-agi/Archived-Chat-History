Both repairs are done and ready for their narrow audits. Neither is merged.

**PR #20 (audit 16 repair), head `29254b1`**
- Tests and docs only, no product code. CI is green.
- A16-1: each owner-rule case now also runs in a child process under the mask 0077 and requires mode 0700 after the refusal. That catches all three mode-before-owner mutants (O10, O11, O12), each at its own place.
- Of the other 10 survivors, three are now caught by new tests (F2, R9, R13). The remaining 7 can't be reached on Linux without a race or a hook added to product code. Each one is explained in section 3.2.
- A16-2 (David's choice): PLANS, capability_probing, implementation and the runbook now say ES refuses a staging disk that can't keep the governed-mount modes, even though submissions without mounts would work there. The "every submission" claims are gone, and the docs contract now forbids them. A `bindfs --perms=o-rwx` test pins the refusal and shows a submission without mounts staging on that same disk.
- A16-3 is named in PLANS. I also did A16-7 (stress test comment) and A16-8 (PR description).
- I reran the auditor's own 55 mutants: 44 caught by behaviour tests (38 before), 4 more by the typed inventories, 7 survive.
- Manifest `acc56339…acc7b` (19 files). Report sha256 `b205d40b…e9d1`.
- Next: the narrow audit of `b5cc7cb..29254b1` in the audit-16 thread, then David's review.

**PR #19 (structural storage check), head `be71f84`**
- The check now runs in ARS's own container, as ARS's user.
- My own mutant run found a gap in my first version: it skipped symbolic links in storage. A link to a directory ARS can't write passed the check while ARS would fail. `be71f84` now refuses links and special files, which ARS never creates.
- Compared against what ARS's own container can do, on 34 storage layouts: 31 agree, 3 are stricter (one on purpose, two by design), none looser.
- Mutants: 42 of 43 caught; the one survivor changes nothing. CI and the runner probe are green.
- Manifest `cf8e81be…dea5`. Report sha256 `3eeeee8f…9ffb`.
- Next: the narrow audit of `07a422b..be71f84`. It is scripts, tests and docs only, so no red-team and no David review.

STATUS: READY
