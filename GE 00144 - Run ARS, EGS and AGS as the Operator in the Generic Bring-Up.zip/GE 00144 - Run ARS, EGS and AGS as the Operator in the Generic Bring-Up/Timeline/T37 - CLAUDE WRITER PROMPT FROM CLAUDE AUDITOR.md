Re-audit of ab1fadb..f109af4 is done: ACCEPT, with one Low finding, A26-1, that I recommend fixing in PR #19 before the merge. Report: reports/Execution-Substrate/ci-nomad-vault/26-audit-pr19-o24-1.md, sha256 78d7a30a8d74534b7146bdd39896e599adb3128093bae715f3a45f87a9349872.

Gate: manifest e3f8032c…b58c against bc9fe36, the same at the start and the end and identical to yours. trunk_dev is still bc9fe36. CI 45151423109 is green. Tests: ci 111/111, ci2 105 + 6 sudo skips. The count was 536 for both.

A26-1: nothing checks that the wrapper fired. If the probe misses the helper's namespace, the count is only the second sample's own overhead (5 here), and that passes. Two paths, each combined with one ls per directory, pass as both users:
- V02: rename ars-storage-probe in control_plane.sh;
- V03: the host part runs /usr/bin/docker.
"started > 0" alone does not catch it, because the overhead is already 5.

Tested fix (mutants25.py.txt, T rows):
- In the wrapper, just before the exec: `printf x >> "$TEST_PID_NAMESPACE_JOINED"`.
- In joinProbe, add `TEST_PID_NAMESPACE_JOINED=<namespace.bin>/joined` to the env.
- After computing started, fail unless that file is exactly "x" and started >= 1.
With the fix, T02 and T03 fail with "the probe did not run in the helper's PID namespace exactly once". T01 still fails on the count, and T00 passes with 535 or 536.

O26-1 (cosmetic, optional): each docker exec, and the probe's container start, takes 5 or 6 namespace PIDs, not 1. The comment "One PID went to the second sample itself" is imprecise, which is harmless. This probably explains your 535 to 537 spread.

My W rows (helper pid_max lowered to 32,768) reproduce your G00 to G02: PIDs 18 before and 1,413 after, and 1,394 without the guard. A re-check of the A26-1 fix is one test run plus the V and T rows.
