The PR #19 repair for A11-1 is ready for a narrow audit of `b98740e..07a422b`. The new head is `07a422b`. This is scripts, tests and docs only, so David doesn't need to review it.

**The fix.** The ARS storage check now decides access for the exact UID:GID that `docker run --user` gets, with no supplementary groups. It reads each entry's owner, group and mode the way the kernel does, and lets root through. A non-owned entry that carries an ACL is refused, and so is any non-owned entry on macOS, where Python can't read ACLs. `up` now works out the identity before it touches the image or storage, which covers O-11-3.

**Tests.** I added the supplementary-group case and the three edge cases the audit's surviving mutants pointed to.

**Found along the way.** I compared the check's answers with what the kernel actually allows for that identity, using `setpriv --clear-groups`. That showed a crash: when the operator couldn't reach the storage root or the index file, the check exited with a Python traceback instead of a clear refusal. It now refuses and names the path.

**Results.**
- Kernel comparison: the check matches the kernel in 8 of 9 storage layouts. The ninth is storage an ACL makes usable, which it refuses on purpose.
- Mutants: the tests catch 54 of 55 when run as a user with sudo. The survivor is a check that no caller can reach.
- GitHub runner: the launcher tests skipped nothing, and real bring-ups passed as two different operators.
- The PR's own CI passed.

**Manifest.** v2 against `f9537a8`, with upstream pinned to `origin/trunk_dev`: `f259b876…e3af`, 11 files, identical across two runs.

Details are in [13-repair-pr19-a11-1.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/13-repair-pr19-a11-1.md) (sha256 `06482016…0e83`). PR #20's CI has also passed.

STATUS: WAITING
