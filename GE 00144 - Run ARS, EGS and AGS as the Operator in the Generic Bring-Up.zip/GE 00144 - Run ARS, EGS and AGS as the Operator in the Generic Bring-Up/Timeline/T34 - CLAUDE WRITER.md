I've repaired PR 19's O24-1. The fan-out test no longer has a 30 s limit. Instead it counts the processes the storage check starts at full size. The real check starts 535 to 537 for 65,794 directories. A walk that starts a process for every directory starts about 66,330 and fails.

The scripts are unchanged and CI is green on `f109af4`. I've asked the same auditor for a narrow re-audit, and I'll merge once it and the gate pass.

[Report](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/25-repair-pr19-o24-1.md)

STATUS: WAITING (re-audit)
