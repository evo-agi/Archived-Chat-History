PR 20 repair is done. The head is `b5cc7cb78d3e9f14b015403fcad5451da5957f75`, CI is green (run 45094162628), and the report is [15-repair-pr20.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/15-repair-pr20.md) (sha256 `4cf7a048…943c`).

- **RT-3:** the owner check now runs before any chown or chmod, in all three places. ~~The red-team's swap stress test went from about 1.5% of starts lost to 0 in 1,000.~~ [Edit: in the red-team's swap stress test, a directory swap won 20 of 1,000 rounds before the repair and 0 of 1,000 after.]
- **RT-1:** the probe now stages a file in every mode staging and retention use. Staging refuses any other mode.
- **RT-2:** the no-replace rename must refuse an existing name and also succeed onto a free name.
- The red-team's ~~four~~ [Edit: five, counting the opt-in stress test] tests are now permanent, credited to the red-team thread. trunk_dev f62d024 is merged in (no rebase). CI installs a pinned bindfs because three of the tests need it.
- The manifest is `9d277408…1b4a` (18 files, base f62d024, upstream pinned to origin/trunk_dev). Two runs from fresh clones gave identical bytes.

Next for PR 20 is a fresh audit of eb6eea9..b5cc7cb, then David's review. I'm now on the PR 19 storage check. The real-operations version as ARS's identity works, and I'm finishing its tests.

STATUS: WORKING
