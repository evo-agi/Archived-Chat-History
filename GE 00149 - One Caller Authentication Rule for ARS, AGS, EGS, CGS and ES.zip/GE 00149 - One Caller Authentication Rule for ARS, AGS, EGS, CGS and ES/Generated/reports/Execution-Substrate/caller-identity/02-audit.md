# FULL CORRECTNESS AUDIT: Execution-Substrate PR #27 at `6e2d2dc` (one caller authentication rule in `internal/callerauth`)

**Verdict: ACCEPT, with one low finding (A2-1) to fix before the merge.**

The shared check is correct for every rule it states. All five services use it, and no other copy remains. For every certificate the new rule accepts, the services authorize the same caller with the same path and ID as before. The CGS any-domain closure is drift, as the writer judged.

The finding is this: the check does not do the leaf validation that the X.509-SVID standard requires of every validator. Over a real mutual-TLS connection, a CA certificate that carries an ES identity authenticates as that caller. The fix is three lines. A variant with the fix changes none of the module's 6,580 test verdicts.

The change is security-sensitive product code, so the separate red-team still follows. This audit was read-only, at the coordinator's request of 16:14Z. No subagents were used. Evidence: `02-audit-evidence/`.

## 1. Provenance

| Check | Result |
|---|---|
| Remote state (16:16Z and 16:43Z) | topic `claude/project-thread-i9yve2` and `refs/pull/27/head` are `6e2d2dcd5938b01a8c9d6837dbbe16519e6264a2`; `trunk_dev` is `036d50724b499b020c5149c55ad902cfcb1482c0` |
| Shape | four commits on `792f17c` (`ce55a75`, `4633946`, `9b05063`, `6e2d2dc`); tip tree `88429063786116a03e8f2d263c8e8ca85ef810ea`; 32 paths. `merge-base(tip, trunk_dev)` is `792f17c` |
| `trunk_dev` since the writer's base | one commit, `036d507` (PR #25, SPIRE download pin), 10 paths. No path is changed on both sides |
| Trial merge onto `036d507` | `git merge-tree --write-tree` is clean: tree `8eb9bf43a8a2ade3c72b38b7ac65781afa6c4008`. The PR patch, without `@@` and `index` lines, is identical before and after the move (`8b62026c…`) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before use |
| Manifest A (tip on `792f17c`) | two runs byte-identical: **`faf35459f1340245045a0041dae9eebf5c3aeb29a053b1626ac05131516ba638`**, 32 paths, textual diff `cf107734…9971`. **Byte for byte the writer's `manifest-v2-6e2d2dc.json`** |
| Manifest B (trial merge on `036d507`) | two runs byte-identical: `351e2222306fd3e3bedab669dd042f7375580601065fb49bfa82ed1bdb45ad17`. The same 32 entries; only the top-level `head` differs. A clean merge of `036d507` into the topic should reproduce this value |
| Writer's evidence | `01-evidence/SHA256SUMS.txt`: 28 of 28 files verify. `01-implementation.md` is still `4fd035cb…0e18` |
| Build and vet | head, base and trial merge, as user `ci`, Go 1.26.5: `go build ./...`, `go vet ./...` and `GOOS=darwin GOARCH=arm64 go vet ./...` all pass. `gofmt -l` on the PR's Go files is clean |
| CI | run 45204507396 on `6e2d2dc` (pull_request event), job "build, vet and test", success, 15:22:35Z to 15:50:54Z. Its tail shows the 16 listed expected failures still failing, and nothing else |
| Merge state | GitHub reports the PR **behind** `trunk_dev`. The ruleset requires branches to be up to date, so the topic needs `036d507` merged in, and then a provenance re-check |

## 2. The shared check against the SPIFFE standards and go-spiffe

I read `internal/callerauth/callerauth.go` line by line. I compared it with the SPIFFE ID and X.509-SVID standards, fetched today (excerpts and hashes in `spec-excerpts.txt`), and with go-spiffe v2.4.0 from the module cache.

| Rule | Standard | `callerauth` | Pinned by |
|---|---|---|---|
| No verified chain, empty first chain, nil leaf | – | `ErrNoVerifiedCertificate`, 401 | refused list (`no_TLS`, `no_verified_chain`, `empty_verified_chain`, `nil_leaf`) |
| Leaf of the first verified chain | Go's TLS server builds every verified chain from `PeerCertificates[0]`, so all chains share the leaf | `VerifiedChains[0][0]` | writer's unit test; see O2-3 for a test gap that does not matter in practice |
| Exactly one URI SAN | X.509-SVID §2 and §5.2: "Validators encountering an SVID containing more than one URI SAN MUST reject the SVID" | 0 gives `ErrNoURISAN`, 2 or more give `ErrMultipleURISANs`, both 401 | five two-SAN cases, including the same ID twice and ours behind a foreign one |
| Scheme `spiffe`, non-root path | X.509-SVID §5.2; SPIFFE-ID §2 | prefix `spiffe://`, path required | `trust_domain_ID_only`, `root_path_only` |
| Trust domain: not empty, no user or port, lowercase `[a-z0-9.-_]`, no percent encoding | SPIFFE-ID §2.1 | `validTrustDomainName`, then exact equality with `execution.internal` | six domain cases, including prefix, suffix, port, user and upper case |
| Path: no percent encoding, no empty, `.` or `..` segment, no trailing `/`, segments `[a-zA-Z0-9.-_]` | SPIFFE-ID §2.2 | `validPathSegment` on every segment | sixteen path cases |
| No query or fragment | SPIFFE-ID §2 | refused by the character rule | four cases |
| Scheme case | SPIFFE-ID §2.4: the scheme is case-insensitive | Go's certificate parser lower-cases it before the check, as go-spiffe's `IDFromCert` sees it | writer's test |
| **Leaf is not a CA: `cA` false, no `keyCertSign`, no `cRLSign`** | **X.509-SVID §5.2: "the validator MUST ensure that the `cA` field ... is set to `false`, and that `keyCertSign` and `cRLSign` are not set"**; go-spiffe's `x509svid.Verify` checks all three (`verify.go:51-56`) | **not checked** | **A2-1** |
| Bootstrap issuer | ES-specific | issuer CN of the leaf, compared exactly with the trimmed configured value, after the identity rules; 403 | writer's tests; see O2-2 |

**My own differential checks** (audit-only tests in `audit-tests/`, run against a copy of the head):

- **Fuzz, one URI SAN, 120 s, 1,279,985 runs.** The input is raw SAN bytes inside a certificate that goes through `x509.ParseCertificate`, exactly as the TLS stack sees it. Every time, the new rule and go-spiffe's `x509svid.IDFromCert` (restricted to `execution.internal` with a path) agreed, with the same ID. Every certificate the new rule accepted was also accepted by both old readers from `792f17c`, with the same path and ID. The ID always equals the parsed URI.
- **Fuzz, two URI SANs, 120 s, 1,295,934 runs.** Never accepted.
- **The writer's string fuzz target, re-run for 60 s, 4,567,907 runs.** No disagreement.
- **22 hand-picked seeds** (`audit-seeds.log`), each with its outcome. Among them: `?` and `#` endings, `%6C`, `%2F`, an empty port, an empty user, a trailing dot, an IPv6 host and `spiffe:///`. The parser refuses two of them. The rule refuses everything else except the plain ID, the upper-case scheme and the empty fragment, and all three of those name the same ID.

## 3. Every call site switched; no sixth copy

- **All five services switched.** `ars/api`, `ags/api`, `egs/api`, `cgs/api` and `es/api` each build `callerauth.NewAuthenticator(bootstrapIssuerCN)` and call `s.callers.Authenticate(w, r)`. The old readers are deleted. Every route that checked a caller before still does: ARS (4 read and 2 writer routes), AGS publish, EGS trust model, CGS authorize, and all 7 ES route kinds. The route tables are unchanged.
- **No other code reads a caller.** In non-test Go outside `internal/callerauth` there is no `.URIs`, `VerifiedChains`, `PeerCertificates` or `Issuer.CommonName`. The only TLS listeners are the five service apps. All five use `RequireAndVerifyClientCert`, TLS 1.2 minimum and their configured client CA bundle. The two outgoing clients (`es/admission`, `ags/publish`) authenticate servers by DNS name, which is outside this PR. I found no Python or shell server that checks client certificates.
- **Only the five service binaries link the new package.** `go list -deps` shows that `cmd/{ars,ags,egs,cgs,es}` link `internal/callerauth`, and no binary links `callerauthtest` or `testing`.
- **Empty bootstrap issuer.** All five `config.Validate` functions refuse an empty bootstrap issuer CN, and `Load` calls `Validate`. So the new "no issuer means refuse everything" rule cannot be reached through configuration. That rule replaces CGS's old "no issuer means skip the 403", which configuration could not reach either.
- **The root guard.** `TestCallerIdentityIsReadOnlyByCallerauth` failed, as it should, on three probes I added: `r.TLS.PeerCertificates` in `es/api`, `.URIs` in a new package, and `.Issuer.CommonName` in a new package. It passed on three ways around it: parsing the SAN extension from raw bytes, reflection, and reading the verified chain outside the five API packages (`guard/`). That is reasonable for a hygiene guard (O2-4).

## 4. Per-route authorization unchanged

**The argument.** When `ParseSPIFFEID(s)` accepts, `s` is exactly `spiffe://execution.internal/` plus the path. `String()` returns `s`, and `Path()` returns the path. The old ARS, AGS, EGS and ES readers returned `TrimPrefix(uri.String(), prefix)` and `uri.String()` for the first matching SAN. The old CGS reader returned `uri.String()` for the first SPIFFE SAN with a host. With exactly one SAN, all of these are the same values. So every caller the new rule accepts reaches the same allowlist, writer path, AGS binding and CGS match as before. Only callers the old code should not have accepted now get 401.

The fuzz property in section 2 checks this over 1.28 million parsed certificates. These mutants check the authorization code paths themselves (section 7): A08 (ARS write route under the read rule), A09 (ES allows every authenticated caller), A10 (EGS the same), A11 (CGS caller/workload match removed), A12 (AGS fixed ID) and A14 (AGS matching on the full ID). The tests killed all six.

**Whole module, head against base.** As user `ci`: 5,429 shared verdicts, none different. The 1,151 verdicts that exist only on the head all pass. Both trees fail the same 16 top-level tests: the 14 root-package tests this container cannot run, and the 2 CI-listed `reliablesubmit` tests. No existing test was edited by the PR.

## 5. Contract §3A and the CGS any-domain closure

**§3A.** Every factual sentence matches the code:

- the listener mode, including on `/health`;
- leaf of the first chain;
- exactly one URI SAN;
- the character rules;
- the parser's lower-casing of the scheme and dropping of an empty `#`;
- the order of 401 and then 403;
- the trimmed exact issuer comparison;
- the startup refusal of an empty issuer;
- authorization on the canonical path or ID.

The service sections, the lifecycle contract §4, `boundaries.md` §11, `architecture.md` and PLANS.md point to it. `TestCallerAuthenticationContractIsDocumentedOnce` pins the key sentences. One sentence needs a qualifier: "These are the SPIFFE ID rules of the SPIFFE standard" is true of the ID rules, but the section also cites X.509-SVID, and §5.2 of that standard is incomplete here (A2-1).

**CGS any-domain closure.** I checked the writer's judgment that CGS accepting any trust domain was never a contract. It holds.

- **Docs.** The base contract says "CGS requires authenticated SPIFFE caller identity" and gives the grammar `principal: "spiffe://..."`. Neither names another domain. No document in the tree mentions federation, foreign or other trust domains.
- **Tests and configs.** Every CGS test, policy test and the checked-in `cgs/policy/id.conf` use `execution.internal`. Apart from `execution.internal`, the tree names only `synthetic.test` (reliable-submit test fixtures), `governed-execution.local` (the outside-observer constants, section 6) and the `spiffe://...` placeholder of the CGS grammar.
- **No caller.** Nothing outside CGS's own server and tests sends `POST /v1/credential/authorize`. `scripts/01_bringup.sh:320` starts `nomad es ags egs ars`, and the runbook confirms that CGS is only bundled in the image. The configurable `SUPPORTED_LOCAL_SPIRE_TRUST_DOMAIN` feeds SPIRE's JWT-SVIDs for Vault. It does not feed service mTLS, whose client certificates hard-code `execution.internal`.
- **Other repositories.** Infrastructure-Manager, Maintenance-Agent and Archived-Runbooks name only `execution.internal`. No repository calls CGS (`closure/org-search.txt`).
- **History.** ES history starts with an import of 48,190 lines (`8a5e166`, 2026-04-19), so no commit explains the CGS reader.
- **The Python POC.** The POC's `CredentialGovernanceServer` inherits the shared `commons/web/server/HttpServer.py`. Its single parser accepted only `spiffe://{IDENTITY_TRUST_DOMAIN}/` (`monolith.internal`), the same as every other POC service (`closure/poc-cgs-caller-identity.txt`). The any-domain acceptance came with the Go rewrite.

The new `id.conf` rule is a narrowing, not a widening. The contract forbids only widening the v1 surface in place. One behaviour change to note is in O2-6.

## 6. Outside-observer protocol and `governed-execution.local`

`es/internal/outsideobserverprotocol/validate.go:20-21` pins `spiffe://governed-execution.local/es/r6j/{outsideobserver,receiver}` as literal message field values. They are not checks of a caller.

- **Inert today.** The package has no production importer, and `outside_observer_docs_contract_test.go` enforces that. The protocol document says that a SPIFFE literal there "is not an authenticated peer".
- **Under §3A.** Both IDs are syntactically conforming and return `ErrForeignTrustDomain` (`TestAuditObserverIDsAreForeign`), so they would get 401 at any of the five services.
- **If a later stage authenticates an observer over mTLS.** The root guard forces it through `callerauth`, which refuses the domain, so it fails closed at the first test.

The conflict is recorded only in the PR body and in the writer's report, not in the repository (O2-5).

## 7. Tests on old code, race, mutants

- **The PR's tests on the head:** 13 packages, 60 top-level tests and 1,128 subtests pass in 7 s. On the trial merge, the same counts pass.
- **Race detector:** the same 60 top-level tests pass in 62 s, with no data race.
- **On old code.** I built the head with the five old `server.go` files and the old `cgs/policy/idfile.go` from `792f17c`. 13 top-level tests fail: the five per-service rule tests, the CGS self-naming foreign-domain test, the `id.conf` refusal test, all five mTLS tests and the root guard. The failing cases per route match the writer's table exactly: ARS 25, AGS 24, EGS 24, CGS 30 and ES 24. The empty-chain panic shows only on ARS. The tests that describe unchanged behaviour pass on old code, as they should.
- **My own mutants (A01 to A16, distinct from the writer's 57): 15 of 16 killed.**
  - A01: the 403 is written but the request continues.
  - A02: several identical URI SANs are accepted.
  - A03: extra non-SPIFFE SANs are ignored.
  - A04: the domain and path are split at the last `/`.
  - A05: the path is case-folded.
  - A06: the certificate's issuer CN is trimmed.
  - A07: `id.conf` accepts foreign principals.
  - A08 to A12 and A14: authorization (section 4).
  - A13: CGS gets a zero authenticator.
  - A15: `.` is accepted while `..` is still refused.
  - **A16 survived:** it reads the last certificate the client sent instead of the verified leaf (O2-3).
- **A2-1 fix variant:** with the leaf check added, the whole module gives 6,580 verdicts, none different from the head.

## 8. Findings and observations

**A2-1 (low, fix before merge): no X.509-SVID leaf validation.**

- **What is missing.** X.509-SVID §5.2 says that a validator authenticating a caller MUST make sure the leaf has `cA` false and neither `keyCertSign` nor `cRLSign`. go-spiffe's `x509svid.Verify` does this. `callerauth` does not. The writer lists it as residual R3, with no trigger, and reasons that "Go's verifier already requires the client-auth EKU through the chain". It does not stop a CA certificate: Go treats a certificate without an extended key usage extension as valid for any usage, and CA certificates usually have none. The demonstration below is such a certificate.
- **Demonstration** (`audit_leaf_ca_test.go.txt`, `runs/leafca-*.log`). The setup is a real TLS server with `RequireAndVerifyClientCert` and a trusted root. The client presents an intermediate CA certificate (`cA` true, `keyCertSign` and `cRLSign`, URI SAN `spiffe://execution.internal/operator/local`) and its key. On the head the answer is `200 "accepted spiffe://execution.internal/operator/local isCA=true"`. With the check it is 401.
- **Impact.** Inference: low. Someone holding the key of a trusted CA can usually mint leaves anyway, and SPIFFE §3.2 forbids a signing certificate from carrying a path-bearing ID, which SPIRE never issues. Inference: the check still matters for an intermediate that carries name constraints, because a CA's own constraints bind only the certificates below it (RFC 5280 §4.2.1.10), not its own SAN. It is also exactly what the standard cited in §3A requires.
- **Fix.**
  - Code: after the nil-leaf check in `CallerFromConnectionState`, refuse when `leaf.IsCA || leaf.KeyUsage&(x509.KeyUsageCertSign|x509.KeyUsageCRLSign) != 0`. Use a new error, still a plain 401.
  - Tests: add `CA_leaf`, `keyCertSign_leaf` and `cRLSign_leaf` to `callerauthtest.RefusedCallers`, so all five services pin it.
  - Contract: add one invariant sentence to §3A.
- **Do not also require `digitalSignature`.** That is an issuer rule (§4.3), and go-spiffe does not check it either.
- **No legitimate caller breaks.** Repo-issued client leaves set `CA:FALSE` and `digitalSignature` (`72_supported_local_setup.sh:315-316`, `remote_alpha_es_service_tls_renew.sh:952-953`), and so do SPIRE SVIDs.

**Observations (no change required for the merge):**

- **O2-1. The topic must take `036d507` before the merge** (it is "behind"). There is no path overlap, and manifest B gives the expected value. Then re-run provenance.
- **O2-2. The bootstrap issuer is still recognized by its CN string (R2).**
  - What it means: a leaf issued by an intermediate under the bootstrap root carries a different issuer CN and is not refused with 403.
  - This is unchanged from all five old copies, and §3A records it as a temporary compatibility edge, but nothing machine-enforced will trigger its replacement.
  - It is inert in supported-local, whose client CA bundle is `runtime-ca.pem` only.
  - A follow-up could match the bootstrap CA by key anywhere in the verified chain.
- **O2-3. No test presents a client chain with an intermediate.** That is why A16 survives. Go guarantees that the verified leaf is the first certificate the client sent, so the risk is small. One mTLS case with leaf plus intermediate (the intermediate carrying the bare trust-domain SAN, as SPIRE's do) would pin "the leaf is read".
- **O2-4. Guard limits** (probes P4 to P6): raw-extension parsing, reflection, and TLS state read outside the five API packages are not caught. This is acceptable for a hygiene guard, and reviewers should know it.
- **O2-5. The outside-observer protocol pins IDs in a foreign trust domain.** One sentence in `outside_observer_protocol.md` (or among the §3A reopened seams) would keep that fact in the repository, not only in the PR body.
- **O2-6. CGS now fails at startup on an `id.conf` principal that is not canonical.** An example is a value with spaces inside the quotes. Before, such a principal loaded as dead policy that could never match. The only `id.conf` in the repository conforms. Inference: a private `id.conf` outside the repository could stop CGS from starting after an upgrade. That fails closed, with a clear message.
- **O2-7. Spec nuance.** SPIFFE-ID §2.4 calls the trust domain case-insensitive, while §2.1 requires it in lower case. The PR refuses upper case, as go-spiffe does. That is consistent.

## 9. Housekeeping

All trees were exported with `git archive` and run as user `ci` with a clean environment and `GOPROXY=off`. The audit-only tests ran in copies, never in the PR tree. The mutation copy was compared with the head afterwards and is identical. No leftover processes remain. Leak scan of this note and its evidence, including the decompressed `.gz` files and the mutant log archive: 4 hits in the diff and the old-code log, all the same synthetic test value: the repository's own SPIFFE user-information test case (user name `user`, host `execution.internal`). There is no personal data. If the topic or `trunk_dev` moves before the merge, run the provenance check again.
