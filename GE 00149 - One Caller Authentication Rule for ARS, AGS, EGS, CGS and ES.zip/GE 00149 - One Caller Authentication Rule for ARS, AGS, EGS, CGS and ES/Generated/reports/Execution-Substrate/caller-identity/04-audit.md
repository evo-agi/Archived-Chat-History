# NARROW RE-AUDIT: Execution-Substrate PR #27 repair `cad8c7e..1572c17` (A2-1, CA certificate as caller)

**Verdict: ACCEPT. A2-1 is closed, and the repair adds no new finding.**

The new check is exactly the X.509-SVID §5.2 leaf rule, the same three conditions go-spiffe's `x509svid.Verify` applies, and nothing more. Over all 6,144 combinations of key usage, basic constraints and URI SANs I tried, it agrees with go-spiffe. Without the check, 9 of the PR's tests fail. With it, the whole module gives the same verdicts as the merge commit, plus 106 new passing ones. `cad8c7e` is my trial merge: same tree, same manifest.

The change is security-sensitive product code, so the separate red-team on `1572c17` still follows, then David's review. This re-audit was read-only, at the coordinator's request of 17:31Z. No subagents were used. Evidence: `04-audit-evidence/`.

## 0. In plain words

The first audit found that a CA certificate (one allowed to sign other certificates) could stand in for a caller's own certificate. The writer added the check the SPIFFE standard asks for. I confirmed four things:

- The repair is exactly that check and some tests. Nothing else changed.
- The check refuses what it should and nothing more.
- Every test I ran passes. Removing the check makes the right tests fail.
- The merge of `trunk_dev` underneath it is byte for byte the one I checked in the first audit.

On the bootstrap-issuer question (O2-2), I agree with doing it in a separate PR, and section 8 explains why. One caveat: the real protection is which CAs each service trusts, not the name check, and the follow-up should be judged against that.

## 1. Provenance

| Check | Result |
|---|---|
| Remote state (17:33Z, re-checked 17:59Z and 18:09Z) | topic `claude/project-thread-i9yve2` and `refs/pull/27/head` are `1572c171859d373733f6ee7329ecc66efac8ce78` (tree `df58f9f66df3956803a186179f53d6a65e2ca9fb`). `trunk_dev` is still `036d50724b499b020c5149c55ad902cfcb1482c0` |
| Shape | `6e2d2dc` (audited head) → `cad8c7e` (merge, parents `6e2d2dc` and `036d507`) → `11a54cd` → `1572c17`. Both repair commits have a single parent |
| **`cad8c7e` = my trial merge** | **tree `8eb9bf43a8a2ade3c72b38b7ac65781afa6c4008`, the tree of my 02 trial merge. A fresh `git merge-tree` of `6e2d2dc` and `036d507` gives the same tree again** |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2…a3ca`, verified before use. HEAD reset to `036d507`, upstream `origin/trunk_dev`, each manifest run twice |
| Manifest of `cad8c7e` | two runs byte-identical: `351e2222306fd3e3bedab669dd042f7375580601065fb49bfa82ed1bdb45ad17`, 32 paths. **Byte for byte my manifest B of 02** and the writer's `manifest-v2-cad8c7e.json` |
| **Manifest of `1572c17`** | two runs byte-identical: **`d08a04ab7b6714118381bacc04baedeeeb4816dfea323a007e6014b484aaf704`**, textual diff `52a793c1…cd8d`, 33 paths. **Byte for byte the writer's value and file** |
| Tip manifest compared with the merge manifest | one new path (`internal/callerauth/callerauth_mtls_test.go`); 6 entries differ (the 6 changed repair paths); 26 identical; at top level only `textual_diff_sha256` differs |
| Repair diff `cad8c7e..1572c17` | 7 files, +318 −32, SHA-256 `d215742736ae2c0c1abf22802c07564596e413cc33c589967f680f3796a945d8`, **byte for byte the writer's `repair-diff-cad8c7e-1572c17.diff`**. None of its paths is touched by `trunk_dev` since the base |
| Writer's evidence | `03-evidence/SHA256SUMS.txt`: 22 of 22 files verify |
| CI | check run "build, vet and test" on `1572c17` (workflow run 45221791182, pull_request event, `head_sha` `1572c17`): success, 16:54:55Z to 17:30:07Z. PR `mergeable_state` is `clean` |

## 2. The fix against X.509-SVID §5.2 and go-spiffe

The only production change is in `internal/callerauth/callerauth.go`: the `crypto/x509` import, one exported error, doc comments and this check, right after the nil-leaf check:

```go
if leaf.IsCA || leaf.KeyUsage&(x509.KeyUsageCertSign|x509.KeyUsageCRLSign) != 0 {
    return Caller{}, ErrNotEndEntity
}
```

- **It is the standard's rule, no more and no less.** X.509-SVID §5.2 names `cA` true, `keyCertSign` and `cRLSign`. go-spiffe v2.4.0 `x509svid.Verify` checks the same three (`verify.go:50-57`, excerpt in `runs/go-source-excerpts.txt`). `digitalSignature` is not required, as §4.3 makes it an issuer rule. The code is my 02 fix variant (`lc27`) except for the new error value, and that variant left all of the module's 6,580 verdicts unchanged.
- **Go's parser** sets `IsCA` from the basic constraints extension without consulting its critical flag, and sets `BasicConstraintsValid` with it (`parser.go:684-690`). So a non-critical `CA:TRUE` is refused, and a leaf with `CA:FALSE` or with no basic constraints passes. This confirms the writer's claim.
- **Same 401.** `Authenticate` answers every `CallerFromConnectionState` error with the same plain `401 Authenticated caller identity required`, so the response does not reveal which rule refused. Mutant B08 shows the tests would catch a `403` here.
- **Order.** The check runs before the URI SAN rules and before the bootstrap rule, so "identity failures 401, then bootstrap 403" still holds. A CA certificate issued by the bootstrap CA gets 401, not 403. Moving the check after the URI rules (mutant B05) changes only which internal error a CA certificate with a bad URI gets. The HTTP answer is identical, so that mutant is equivalent.
- **Exhaustive comparison with go-spiffe** (audit-only test `audit-tests/audit_end_entity_matrix_test.go.txt`, `runs/matrix-1572c17.log`):
  - Setup: every combination of the 9 key usage bits (including no key usage extension), 3 basic constraints states (absent, `CA:FALSE`, `CA:TRUE`) and 4 URI SAN sets (valid, root path, foreign domain, two SANs). That is 6,144 certificates, each issued and parsed by Go.
  - Result: `CallerFromConnectionState` accepts exactly when go-spiffe's `Verify` passes the leaf with an `execution.internal` ID with a path. That happens for 256 certificates: the valid ID, without `CA:TRUE`, and with neither signing usage. It returns `ErrNotEndEntity` exactly when `cA` is true or a signing usage is set.
  - Without the check (`runs/matrix-nofix.log`), 1,280 certificates are accepted that go-spiffe refuses.

## 3. Is the first verified chain's leaf always the certificate the client sent first?

The writer asked this, for cross-signed intermediates and several chains. **Yes, by construction**, from the Go 1.26.5 sources (`runs/go-source-excerpts.txt`):

- `tls/handshake_server.go:967-979`: the server verifies `certs[0]`, the client's first certificate, and adds every other certificate the client sent as an intermediate.
- `x509/verify.go:596-600`: every candidate chain begins as `[]*Certificate{c}`, or as `{c}` when `c` is itself in the roots.
- `x509/verify.go:663-668` and `:774-777`: chains only grow by copying the prefix and appending a parent.
- So every chain Go returns, however many and through whichever cross-signed parent, has the client's first certificate at index 0. The FIPS filter (`tls/common.go:1830-1847`) only drops whole chains.
- On session resumption (`handshake_server.go:515-555`), Go restores the chains verified in the original handshake. They begin with the same leaf, and Go checks them again against the current client CAs. `callerauth` runs on every request, so the end-entity rule applies to resumed connections too.
- Parents are found only under the child's issuer name (`x509/cert_pool.go:132-160`). This matters for section 8: the leaf's issuer CN is always the subject CN of the CA that actually signed it.

The writer's new test `TestAuthenticateReadsTheLeafOfAClientChainWithAnIntermediate` pins the plain SPIRE shape over a real listener: leaf plus an intermediate with only `spiffe://execution.internal`. It kills my surviving 02 mutant A16. I added no cross-signed test, because the source shows the leaf position does not depend on chain shape.

## 4. Tests

All trees exported with `git archive` (the `1572c17` export checked file by file against the commit: 492 files, 0 mismatches) and run as user `ci` in a clean environment, Go 1.26.5, `GOPROXY=off`, `-mod=readonly`.

| Run | Result |
|---|---|
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...`, `gofmt -l internal/callerauth caller_authentication_docs_contract_test.go` (`runs/build-vet-1572c17.log`) | all pass, gofmt clean |
| The PR's tests (`runs/pr-tests-h27b.log`): `./internal/callerauth/...`, the five `*/api`, `./cgs/policy`, the five `*/app` mutual-TLS tests, the root docs contract test and root guard | 13 packages ok, 1,293 passes, 0 failures |
| Same with `-race` (`runs/pr-tests-race-h27b.log`) | all ok, no data race |
| Same with the check removed (`nf27b`: the `if` block replaced by a no-op, `scripts/no-fix-variant.diff`; `runs/pr-tests-nf27b.log`) | **9 top-level tests fail** (111 failing lines). In `callerauth`: the CA-certificate mutual-TLS test, the refused-list unit and 401 tests, and the go-spiffe agreement test. The rule tests of ARS, AGS, EGS, CGS and ES fail for all three new refused cases on every route. The two regression pins (`…LeafOfAClientChainWithAnIntermediate`, `…AcceptsAnEndEntityLeafWithCAFalse`) pass there too, as expected for pins. This matches the writer's M47 count of 9 tests |
| Whole module, `go test -count=1 -v ./...`, on `1572c17` and on the merge `cad8c7e` (`runs/full-*.log.gz`, `runs/verdicts-full-m27-vs-h27b.txt`) | both fail the same 16 top-level tests: the 16 known container-only failures (14 root-package Remote Alpha/hygiene tests, 2 reliablesubmit old-binary tests). **6,622 shared verdicts, 0 different.** 1 verdict only in `cad8c7e`: the renamed `…AgreesWithTheSPIFFEReferenceReader`, which passed. 106 only in `1572c17`, all PASS: the new refused cases and `allowed_caller_CA_false` on every route, and the four new top-level tests |
| GitHub CI on `1572c17` | success (section 1) |

## 5. Mutants

Audit-only, my own set (`scripts/mutants27b.py.txt`, `mutants/results.json`, per-mutant logs in `mutants/mutant-logs.tar.gz`), run against the PR's tests in a copy of `1572c17`. The copy was compared with the export afterwards: identical. **23 of 25 killed.**

| Set | Result |
|---|---|
| A01–A15 (my 02 mutants of the check, call sites and `id.conf`, rerun on the new head) | all killed, as in 02 |
| **A16** (leaf taken from the last peer certificate) | **now killed** by `TestAuthenticateReadsTheLeafOfAClientChainWithAnIntermediate` (02 survivor, O2-3 closed) |
| B01 only `IsCA`; B02 only the key usages; B03 `cRLSign` dropped; B04 `keyCertSign` dropped | all killed (8 tests each, all five services) |
| B06 any basic constraints extension treated as CA | killed (7 tests: the `allowed_caller_CA_false` route cases of all five services, the `CA:FALSE` unit test and the intermediate test) |
| B07 `digitalSignature` required when a key usage extension is present | killed (`…AcceptsAnEndEntityLeafWithCAFalse`, `keyEncipherment` alone) |
| B08 `ErrNotEndEntity` answered with the 403 bootstrap refusal | killed (7 tests) |
| B05 check moved after the URI SAN rules | survives: **equivalent** (section 2) |
| B09 check skipped when the client also sent an intermediate | survives. **Contrived**: it needs an added condition the code has no reason for. No test presents a CA certificate together with an intermediate (O4-1) |

## 6. Contract, plan and docs test

- §3A gains the end-entity invariant, worded as in the code. It says `digitalSignature` is an issuer rule and is not checked. It also gains a reopened-seam sentence on the outside-observer `governed-execution.local` IDs (O2-5 closed).
- `caller_authentication_docs_contract_test.go` pins both new sentences.
- `PLANS.md`: the status entry and the current-state fact name the CA-leaf drift and the end-entity rule. The text is accurate.
- The package and function doc comments match the code.

## 7. Overlap with other open PRs (re-checked now)

| Trial merge with `1572c17` | Result |
|---|---|
| PR #12 / PR #28 head `2c8bf35` | conflicts only in `PLANS.md` (both add a first `## Status` entry); `boundaries.md` auto-merges |
| PR #29 head, **now `89da53d`** (moved past the `f8c1a73` the writer checked) | clean |

`overlap/merge-tree-*.txt` holds the outputs. Whichever PR merges second keeps both `PLANS.md` entries.

## 8. View on O2-2 (bootstrap issuer matched by its CN)

**Short answer:** I agree with the coordinator's 17:32Z decision, a separate PR right after PR 27 lands. It should not block PR 27. The follow-up should start from the CA bundles, not from the matching rule. Neither a CN rule nor a key rule is a security boundary while the bootstrap root stays trusted.

**Why it need not block PR 27.** The rule is unchanged in meaning from all five old copies, which compared `leaf.Issuer.CommonName` the same way. PR 27 moves it into one function and lists it in §3A, which makes it easier to replace, not weaker. In supported-local it is inert: the client CA bundle is `runtime-ca.pem` only, and the configured name `Bootstrap Root CA Example` matches nothing.

**What the CN rule really does.** Go finds a certificate's parent by the child's issuer name (section 3). So the rule refuses exactly the leaves signed directly by a trusted-chain CA whose subject CN is the configured string. Three consequences:

- **It misses anything one level down.** The holder of the bootstrap root key can mint an intermediate with any other CN and sign leaves under it, and those leaves get past the 403. So can an intermediate the bootstrap PKI already has.
- **It fails closed on a name clash.** A CA that happens to have the same CN is refused.
- **It is a label on honest issuance, not a boundary.** The cryptographic boundary is the content of each service's `client_ca_file`. Any CA in that bundle, or any CA that chains to it, can issue every ES identity.

**On my own 02 suggestion** (match the bootstrap CA by key anywhere in the verified chain): the writer is right that it is only correct if no SPIRE chain runs through the bootstrap root. I would add two points:

- **Check every certificate in the chain.** A key rule must look at every non-leaf certificate (`VerifiedChains[i][1:]`), not just the leaf's issuer, or it has the CN rule's one-level-down gap. With several chains, refuse when any chain runs through the bootstrap key.
- **If SPIRE's upstream CA is the bootstrap root, no rule inside `callerauth` can tell the two apart.** The bootstrap key holder can mint a SPIRE-shaped intermediate too. In that case the fix belongs in infrastructure: give SPIRE its own upstream root.

**What the inventory must answer, and what each answer implies:**

| Box fact | Right follow-up |
|---|---|
| Bootstrap root is in no service's `client_ca_file` | The rule is dead code. Bootstrap leaves already fail the TLS handshake. Remove the rule and `security.bootstrap_issuer_common_name` from all five configs and scripts. This is the simplest and strongest end state, and it fits "ES as unprivileged and simple as possible" |
| Bootstrap root is trusted, SPIRE has its own upstream, bootstrap callers still exist | Interim: match by the bootstrap CA's key over the whole chain (needs the bootstrap CA certificate in each service's config). Exit: remove the bootstrap root from the bundles once the last bootstrap caller moves to SPIRE, then delete the rule as in the row above |
| SPIRE's upstream CA is the bootstrap root | A key rule would refuse every SPIRE caller, and nothing in `callerauth` can separate them cryptographically. Re-root SPIRE (its own upstream CA), then continue as in the row above. Inference: a weaker positive rule ("the leaf's issuer must be a SPIFFE signing certificate of `execution.internal`", the shape SPIRE's CAs have and the new intermediate test uses) would block accidental bootstrap use, but not a bootstrap key holder |

**Trigger.** The project rule wants a machine-enforced trigger for any remaining temporary edge. Today the edge has a label in §3A and a planned PR, but no machine check. Suggestion for the follow-up, depending on what the inventory finds:

- Add a read-only check to the existing Remote Alpha health check that reports, per service, whether the bootstrap root is in `client_ca_file` and whether SPIRE's upstream is the bootstrap root. Make it fail once the bootstrap PKI is declared retired but still trusted. That turns "retire the bootstrap PKI" into a check that cannot be forgotten.
- Record the open item in `PLANS.md` with that exit condition.

This is a recommendation for the coordinator, not a finding against PR 27.

## 9. Findings and observations

**A2-1: closed.** The code, tests and §3A sentence are as the 02 fix proposed. Every route of the five services refuses the three cases with 401. The 02 demonstration is now a test.

**New findings: none.**

**Observations (no change required for the merge):**

- **O4-1. No test presents a CA certificate together with an intermediate.** That is why B09 survives. The code applies the rule to the leaf whatever the chain, and section 3 shows the leaf position cannot vary, so this is optional. One more case in `callerauth_mtls_test.go` would close it.
- **O4-2. The rule's order relative to the URI rules is not pinned** (B05). It only affects which internal error value a CA certificate with a bad URI gets. The HTTP outcome is the same. No action.
- **O4-3. The bootstrap-CN edge still has no machine-enforced trigger.** It predates this PR. See section 8 for the follow-up and a suggested trigger.
- **O4-4. PR #29's head moved to `89da53d`.** It still merges cleanly with `1572c17`.
- 02 observations O2-1, O2-3 and O2-5 are closed. O2-2 stays open, as decided. O2-4, O2-6 and O2-7 stand as written in 02. The writer made no change for them and gives reasons in 03 §5, which I agree with.

## 10. Housekeeping

- All runs used exported copies as user `ci`. The audit-only test ran in separate copies (`f27b`, `fnf27b`), never in the PR tree. The mutation copy is identical to the export afterwards. No processes are left over.
- A build script from the 02 run was started by mistake at 17:33Z. It hung on a nested `su` and wrote nothing, and I stopped it. Every result above comes from the scripts in `scripts/`.
- Leak scan of this note and its evidence, including the decompressed `.gz` files and the extracted mutant log archive: 0 findings.
- If the topic or `trunk_dev` moves before the merge, run the provenance check again. The PR then also needs a fresh red-team on `1572c17` and David's review (third product review).

**Evidence (`04-audit-evidence/`, `SHA256SUMS.txt`):**

| Path | What |
|---|---|
| `provenance/` | `provenance-r27b.sh.txt` and its log, the two manifest runs for `cad8c7e` (`merge-*.json`) and `1572c17` (`tip-*.json`), and the repair diff |
| `runs/` | build/vet, PR tests (head, race, no-fix), whole-module logs (gz) and verdict comparison, matrix logs, Go and go-spiffe source excerpts, CI record |
| `mutants/` | `results.json`, `run.log`, per-mutant logs (tar.gz) |
| `audit-tests/` | the exhaustive matrix test (audit-only, not for the PR) |
| `scripts/` | every script used, the mutant definitions and the no-fix variant diff |
| `overlap/` | trial merges with PR #12, #28 and #29 |
