# PR #27 repair: refuse a CA certificate presented as the caller's leaf (A2-1)

**Verdict: REPAIRED. Draft PR [#27](https://github.com/evo-agi/Execution-Substrate/pull/27) at `1572c17`, up to date with `trunk_dev` `036d507`. Needs the narrow re-audit by the same auditor, then a fresh red-team on this head, then David's review (product code).**

```text
REPAIR REPORT
Finding:          A2-1 (low) of 02-audit.md (sha256 70f9cba5…72f3): no X.509-SVID leaf validation;
                  a CA certificate carrying an ES identity authenticated as that caller over mTLS
Repository:       evo-agi/Execution-Substrate
Base ref and SHA: origin/trunk_dev 036d50724b499b020c5149c55ad902cfcb1482c0
Topic branch:     claude/project-thread-i9yve2
Audited head:     6e2d2dcd5938b01a8c9d6837dbbe16519e6264a2
New head SHA:     1572c171859d373733f6ee7329ecc66efac8ce78 (pushed; refs/pull/27/head is the same)
Tree SHA:         df58f9f66df3956803a186179f53d6a65e2ca9fb
Commits added:    cad8c7e  merge of trunk_dev 036d507 (tree 8eb9bf43…, the auditor's trial-merge tree)
                  11a54cd  Refuse a CA certificate presented as the caller's leaf
                  1572c17  Pin that end-entity leaves with CA:FALSE stay accepted
Repair diff:      cad8c7e..1572c17, 7 files, +318 -32, sha256 d2157427…45d8 (03-evidence/)
v2 manifest:      manifest_sha256 d08a04ab7b6714118381bacc04baedeeeb4816dfea323a007e6014b484aaf704
                  textual_diff_sha256 52a793c1e8cf77cceccb895dd61299d83746ebde61dfb8e422618c32de46cd8d
                  33 files, upstream origin/trunk_dev, HEAD reset to 036d507 (tool sha256 c08597e2…a3ca verified)
Effect status:    TOPIC_BRANCH_PUSHED | DRAFT_PR_UPDATED | MERGE_NOT_PERFORMED |
                  RE_AUDIT_NOT_PERFORMED | RED_TEAM_NOT_PERFORMED
```

## 0. In plain words

The audit showed that a CA certificate (a certificate that may sign other certificates) could stand in as a caller's own certificate and be accepted as that caller, as long as it carried an ES identity. The SPIFFE standard for X.509 identities says every checker must refuse that. `internal/callerauth` now refuses it with the usual `401`, the rule is one more sentence in contract section 3A, and all five services' tests send three such certificates and expect `401`. Real callers are unaffected: SPIRE and the repository's scripts issue end-entity client certificates, and a new test pins that such certificates stay accepted.

My first report was wrong on this point: its residual R3 said Go's verifier already stops such certificates through the client-auth key usage. It does not, because Go treats a certificate without an extended key usage as valid for any use, and CA certificates usually have none. The audit's demonstration is now a test.

## 1. Merge of `trunk_dev` (O2-1) and provenance

- `cad8c7e` merges `036d507` into `6e2d2dc` with no conflict. Its parents are `6e2d2dc` and `036d507`.
- Its tree is `8eb9bf43a8a2ade3c72b38b7ac65781afa6c4008`, the auditor's trial-merge tree.
- Its v2 manifest is `351e2222306fd3e3bedab669dd042f7375580601065fb49bfa82ed1bdb45ad17`, byte for byte the auditor's manifest B (`03-evidence/manifest-v2-cad8c7e.json`).
- So everything after `cad8c7e` is the repair, and the re-audit can read `cad8c7e..1572c17` (`03-evidence/repair-diff-cad8c7e-1572c17.diff`).
- The manifest of the new head (`03-evidence/manifest-v2-1572c17.json`) has 33 entries: the 32 audited paths plus the new `internal/callerauth/callerauth_mtls_test.go`.

## 2. The fix

`internal/callerauth/callerauth.go`, after the nil-leaf check in `CallerFromConnectionState`:

```go
if leaf.IsCA || leaf.KeyUsage&(x509.KeyUsageCertSign|x509.KeyUsageCRLSign) != 0 {
    return Caller{}, ErrNotEndEntity
}
```

- `ErrNotEndEntity` is a new exported error. `Authenticate` answers it with the same plain `401` as every other identity failure, so the response still does not say which rule refused the request.
- The check runs before the URI SAN rules and before the bootstrap-issuer rule, so the order "identity failures `401`, then bootstrap `403`" is unchanged.
- `digitalSignature` is not required. It is an issuer rule in X.509-SVID §4.3, and go-spiffe's `x509svid.Verify` does not check it either, as the audit advised.
- Go sets `IsCA` only when the basic constraints extension is present and marks a CA, so a leaf with `CA:FALSE` (SPIRE SVIDs, the repository's client leaves) and a leaf with no basic constraints both pass.

Contract and plan:

- `.docs/system_overview/contracts.md` §3A has a new invariant: "The leaf must be an end-entity certificate. A leaf whose basic constraints mark it as a CA, or whose key usage includes `keyCertSign` or `cRLSign`, has no caller identity…. The `digitalSignature` key usage is an issuer rule and is not checked."
- §3A also gains the reopened-seam sentence on the outside-observer protocol's `governed-execution.local` IDs (O2-5).
- `PLANS.md` (status entry and Current-State Facts) names the drift and the end-entity rule.
- `caller_authentication_docs_contract_test.go` pins both new §3A sentences.

## 3. Tests

| Test | What it pins | Fails without the fix |
|---|---|---|
| `callerauthtest.RefusedCallers`: `CA_leaf`, `keyCertSign_leaf`, `cRLSign_leaf` (now 40 cases), each carrying the allowed ID | every route test of ARS, AGS, EGS, CGS and ES expects `401` for all three | yes: the five per-service rule tests and the unit mapping test (mutant M47) |
| `callerauthtest.CheckRoute`: allowed caller sent twice, once without basic constraints and once with `CA:FALSE` plus `digitalSignature|keyEncipherment` | the allowed caller still passes every route at all five services when the leaf looks like a real SVID | kills M48 (any basic constraints treated as CA) |
| `TestAuthenticateRefusesACACertificatePresentedAsTheClientCertificate` (new file `callerauth_mtls_test.go`) | the auditor's A2-1 case over a real TLS listener with `RequireAndVerifyClientCert`: an intermediate CA with `spiffe://execution.internal/operator/local` presented as the client certificate gets `401` | yes (M44, M47) |
| `TestAuthenticateReadsTheLeafOfAClientChainWithAnIntermediate` (same file) | SPIRE-style chain: root, intermediate CA carrying only `spiffe://execution.internal`, leaf with the caller's ID; the client sends leaf and intermediate; the answer is `200` with the leaf's ID (O2-3) | kills M50, the auditor's surviving mutant A16 |
| `TestCallerFromConnectionStateAgreesWithTheSPIFFEReferenceValidator` (renamed from the go-spiffe ID comparison) | for every accepted and refused case, the rule agrees with go-spiffe's `x509svid.Verify` given no bundles: go-spiffe checks the leaf rules before it looks up a bundle, so "failed only at the bundle lookup" means "leaf acceptable" | yes for the three new cases |
| `TestCallerFromConnectionStateAcceptsAnEndEntityLeafWithCAFalse` | `CA:FALSE` leaves with `digitalSignature`, `digitalSignature|keyEncipherment` and `keyEncipherment` alone are accepted | kills M49 (`digitalSignature` also required) |

The audit's own test file (`02-audit-evidence/audit-tests/audit_leaf_ca_test.go.txt`) was adapted into the first mutual-TLS test: same certificate shape, same listener mode, the repository's `401` body instead of the audit's echo handler.

## 4. Validation on `1572c17`

All runs in this cloud container, Go 1.26.5, as user `esci` with `GOPROXY=off` and `-mod=readonly`, except where noted.

| Check | Result |
|---|---|
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...` (`targeted-1572c17.log`) | pass |
| `gofmt -l` on the PR's Go files | clean |
| Targeted (`targeted-1572c17.log`): `./internal/callerauth/...`, the five `*/api`, `./cgs/policy`, the five `*/app` mutual-TLS tests, the root docs test and root guard, the `internal/testtmpdir` guard | pass |
| Race: unit packages above (`r-race-unit.log`) and the five app mutual-TLS tests (`r-race-app.log`) | exit 0, no data race |
| Root package, all tests (`root-all-1572c17.log`, `root-all-failing-top-level.txt`) | 8 top-level tests fail, all 8 among the 11 root-package tests listed in `.github/ci/environment-only-tests.txt` (host reasons); the other 3 listed tests pass here; nothing unlisted fails |
| Root package with the CI list skipped (`root-skip-1572c17.log`), including the docs contract test and the root guard | `ok execution-substrate 189.152s` |
| Bring-up `TestBringupScriptUpCheckDownFullProfile` with the PR's binaries (offline image `es-offline-cp:1572c17`) | PASS, 34.9 s |
| Mutants (`mutants2-summary.txt`, `mutants2.log`, `mutants2.log.json`; M47 rerun in `mutants2-m47*`) | 64 mutants (M01 to M50 of the check, S01 to S14 of the call sites and `id.conf`): 63 killed, M03 survives as before (equivalent: an empty path is an empty segment, refused by the segment rule). The seven new ones, M44 to M50, are all killed. M47 (rule removed) did not compile in the main run because the `crypto/x509` import became unused; rerun as `if false && (…)`, it is killed by 9 tests: the 4 unit tests and the rule tests of all five services |
| GitHub CI, job "build, vet and test" (`ci.txt`) | success, run 45221791182, 16:54:55Z to 17:30:07Z; the 16 listed host-caused failures still fail and nothing else does |

The bring-up proves that the services still start and accept the repository's own client certificates after the change. Not shown here: a live SPIRE-issued SVID on the Remote Alpha box.

## 5. Audit observations

| Observation | Disposition |
|---|---|
| O2-1 merge `036d507` | done, `cad8c7e`; manifest B reproduced (section 1) |
| O2-2 bootstrap issuer recognized by its CN string | **open item, decided by the coordinator at 17:32Z:** separate PR right after PR 27 lands (below) |
| O2-3 no client chain with an intermediate | done, second mutual-TLS test; M50 (= A16) killed |
| O2-4 guard limits | no change; the guard is a tripwire for copies, as the first report said |
| O2-5 outside-observer IDs only in the PR body | done, §3A reopened-seam sentence, pinned by the docs test |
| O2-6 CGS fails at startup on a non-canonical `id.conf` principal | no change; fails closed with a clear message, and the only `id.conf` in the repository conforms. Worth one line in the release notes if CGS is ever deployed |
| O2-7 trust-domain case wording | no change; consistent with go-spiffe |

**O2-2, open item.** The bootstrap issuer is still recognized by the leaf's issuer common name, exactly as in all five old copies. Section 3A lists it under "Temporary compatibility edges", and the project rule says such an edge needs a machine-enforced trigger, which it does not have. I did not change it in this repair, for two reasons:

- The right rule depends on a deployment fact the repository does not hold. Matching the bootstrap CA by key anywhere in the verified chain (the audit's suggestion) is correct only if no SPIRE chain runs through the bootstrap root. If SPIRE's upstream CA on the Remote Alpha box is the bootstrap root, that rule would refuse every SPIRE caller. In supported-local the configured name (`Bootstrap Root CA Example`) matches nothing and the client CA bundle is `runtime-ca.pem` only, so the rule is inert there.
- Key matching needs each service to load the bootstrap CA certificate, which is a configuration change in five services and their scripts. That is more than the narrow repair the re-audit is scoped to.

Decision (coordinator, 17:32Z): a separate follow-up PR right after PR 27 lands, started with a read-only inventory of the Remote Alpha client CA bundles and SPIRE's upstream CA. The inventory script goes through the coordinator, because the infrastructure audit may need the same inventory. The follow-up replaces the CN string with the bootstrap CA's key and removes the "temporary" label, or, if the box shows the bootstrap PKI is about to be retired, removes the rule together with the PKI. Until then the edge is no weaker than before this PR, and it lives in one function.

## 6. Overlap with other open PRs (re-checked)

- PR 12 / PR 28 (both `2c8bf35`): `git merge-tree` with `1572c17` conflicts only in `PLANS.md`, because both add a new first entry under `## Status`. Whichever merges second keeps both entries. No Go file overlaps.
- PR 29 (`f8c1a73`): merges cleanly.

## 7. Residuals after the repair

- R1 (duplicate `loadTLSConfig` and prefix matchers), R4 (federation is a reopened seam) and R5 (outside-observer IDs, now also in §3A) stand as in the first report.
- R2 is O2-2 above: open item, follow-up PR after PR 27 lands, starting with the read-only CA-bundle inventory on the box.
- R3 is withdrawn: it was wrong, and the rule is now enforced.

## 8. For the re-audit and red-team

What I checked myself, by reading the sources:

- X.509-SVID §5.2 and go-spiffe v2.4.0 `svid/x509svid/verify.go:50-57` name exactly three leaf rules: `cA` true, `keyCertSign`, `cRLSign`. The fix checks the same three.
- Go's certificate parser (`crypto/x509/parser.go:684-690`, Go 1.26.5) sets `IsCA` from the basic constraints extension whether or not it is marked critical, so a non-critical `CA:TRUE` is refused too. The parser also refuses a certificate with duplicate extensions.
- A certificate with no extensions at all (for example X.509 v1) has no URI SAN, so it was already refused with `401`.

Suggested angles, not a limit:

- Is "leaf of the first verified chain" still the certificate the client sent first, for every chain shape Go builds (cross-signed intermediates, several chains)? The new intermediate-chain test covers the plain SPIRE shape only.
- Does any client CA bundle on the Remote Alpha box hold a CA that could issue a leaf which passes these rules but should not be a caller (O2-2)?

## 9. Evidence (`03-evidence/`, `SHA256SUMS.txt`)

| File | What |
|---|---|
| `provenance.txt` | SHAs, trees, manifest values, remote refs |
| `manifest-v2-cad8c7e.json`, `manifest-v2-1572c17.json` | v2 manifests of the merge and of the new head |
| `repair-diff-cad8c7e-1572c17.diff` | the repair as one diff |
| `targeted-1572c17.log` | gofmt, build, vet (linux and darwin), targeted tests |
| `repair.sh.txt`, `repair.out.txt`, `r-race-unit.log`, `r-race-app.log` | the run script, its exit codes, race runs |
| `root-all-1572c17.log`, `root-all-failing-top-level.txt`, `root-skip.sh.txt`, `root-skip-1572c17.log` | root package, all tests and with the CI list skipped |
| `bringup-1572c17.log` | bring-up |
| `mutants.py.txt` (with the corrected M47), `mutants2-summary.txt`, `mutants2.log`, `mutants2.log.json`, `mutants2-m47-summary.txt`, `mutants2-m47.log`, `mutants2-m47.log.json` | mutation run and the M47 rerun |
| `ci.txt` | the GitHub CI run on `1572c17` |
