# NARROW RE-AUDIT: Execution-Substrate PR #27 repair `1572c17..30549d6` (red-team R2 and R5, re-audit O4-1)

**Verdict: ACCEPT. R2, R5 and O4-1 are closed, and the repair adds no new finding.**

There is one thing to do before the merge, which is not a defect: `trunk_dev` moved to `8ba1edb` at 19:10Z (PR #26, test-only). PR 27 must merge it, and then provenance must be checked again. The trial merge is clean, and the expected manifest is in section 1.

The audited delta is three commits on top of my 04 baseline (`1572c17`):

- `9792cbf` (R5): the operator status tools now pass only with exactly one URI SAN.
- `62d31c8` (R2): `callerauth` checks the validity period on every request.
- `30549d6`: a test for my O4-1.

Everything I checked holds:

- An expired certificate on a busy connection now gets `401`.
- The status tools now agree with ES on the four certificates the red-team reported.
- Removing either fix makes the right tests fail.
- Across the whole module, the 6,728 verdicts shared with `1572c17` are unchanged, and the 88 new ones all pass. CI is green.

I checked the red-team addendum (05 §9) myself, as asked: I agree with it, and its nit N1 reproduces. I found one more input of the same kind (O7-1). This re-audit was read-only, at the writer's request of 19:06Z and the coordinator's of 19:12Z. No subagents were used. Evidence: `07-audit-evidence/`.

## 0. In plain words

Two things were fixed after the red-team.

- **R2.** A client whose certificate expired could keep using an open connection. Now every request checks the certificate dates, so the client is refused from its first request after expiry.
- **R5.** The operator's status tools said "fine" for a certificate that ES refuses because it carries two identities. Now they say "not fine" in that case.

I confirmed both fixes, ran all the tests, and broke the new code on purpose 16 ways to check that the tests notice. 15 of the 16 were caught. The one that was not makes no difference a caller can see.

One small, older weakness remains in the status tools. They read OpenSSL's printed text, and an oddly made certificate can fool that text. ES itself is not fooled, so this only affects how accurate a diagnostic is.

## 1. Provenance

| Check | Result |
|---|---|
| Remote state (19:07Z, re-checked 19:17Z) | topic and `refs/pull/27/head` are `30549d646d438a9c17142e84149cdb432b7a7f19`, tree `87d3d769f976ad84270483966694c27863c45a8b`, the writer's tree |
| Shape | `9792cbf` → `62d31c8` → `30549d6` on `1572c17`, three single-parent commits, no merge. Merge-base with `trunk_dev` was `036d507` |
| Delta `1572c17..30549d6` | 15 files, +484 −59, SHA-256 `448170b251637bca2c599f6ef168188e1fdef4b8e699b96f3fbb0acbf1cf2c2f`. **Byte for byte the writer's `delta-diff-1572c17-30549d6.diff`** |
| v2 manifest (tool `c08597e2…a3ca` verified; HEAD reset to `036d507`, upstream `origin/trunk_dev`) | two runs byte-identical: **`41090e09521d68c02c39af40ee9df3648dccddde50e68d5bf131b94c5359d108`**, textual diff `b2c78c1f…6470`, 41 files. **Byte for byte the writer's file** |
| Compared with my 04 manifest of `1572c17` | 8 new paths (the delta's added or newly touched files); 7 entries differ (the changed callerauth, docs and plan paths); 26 identical |
| Writer's evidence | `06-evidence/SHA256SUMS.txt` (refreshed, `1841d757…7887`): 22 of 22 files verify. Red-team `05-redteam-evidence/SHA256SUMS.txt`: 45 of 45 verify |
| CI | job "build, vet and test" (workflow run 45241862055, job 137928307746) on `30549d6`: success, 18:46:10Z to 19:14:13Z. Every step succeeded, including "Listed tests still fail" |
| **`trunk_dev` moved** | at 19:17Z it is **`8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce`**: PR #26 merged at 19:10:13Z, 4 test files in `es/admission`, none of them a PR 27 path |
| Trial merge onto `8ba1edb` (local only, never pushed) | `git merge-tree` is clean, tree `8396590b03fe37d768f09f627ac193ded9008ba4`. Build and vet pass. `es/admission`, the caller-auth packages, the root guard and the docs test pass (`runs/trial-merge-8ba1edb.log`). **Expected v2 manifest after a clean merge: `4e99edfed96f75052cb9775bce8704b743a26ed4077bc6f4e3b8ce5c78633ebe`.** Two runs were identical. All 41 entries and the textual diff equal `30549d6`'s; only the `head` field differs |

## 2. R2: the validity period on every request

**The code** (`internal/callerauth/callerauth.go`):

- `CallerFromConnectionState(state, now)` refuses with `ErrOutsideValidity` unless some verified chain starts with the leaf and has every certificate within `NotBefore`..`NotAfter` at `now`.
- `Authenticate` passes `time.Now()` read on every request. The test-only clock override is in `export_test.go`.

| Question | Answer (how checked) |
|---|---|
| Same rule as Go's handshake? | Yes. `crypto/x509` `isValid` (`verify.go:455-465`) refuses `now.Before(NotBefore)` and `now.After(NotAfter)`, so both ends are valid, and it applies to every certificate of the chain, root included. The new check uses the same comparisons over the same certificates. None of the five `tls.Config` literals (`{ars,ags,egs,cgs,es}/app/app.go`) sets `Time`, so the handshake and the request use the same clock (Read) |
| "At least one chain that starts with the leaf" right? | Yes. Go's handshake needs one chain to verify, and 04 §3 showed that every chain Go returns starts with the client's first certificate. So chain 0 always qualifies by its start, and a cross-signed path that is still valid keeps working. The extra start check (`chain[0] != leaf && !chain[0].Equal(leaf)`) only matters for hand-built states. `Equal` is nil-safe (`x509.go:913-918`) (Read) |
| Any path to authorization without the time check? | No. The only production caller of `CallerFromConnectionState` is `Authenticate` (grep), and every checking route calls `Authenticate` (02/04, root guard). Mutant C07 (clock ignored) and C08 (clock frozen at startup) are killed (section 5) |
| How long after expiry can a caller still act? | At most one request that was admitted before `NotAfter`. That request is bounded by the service's `WriteTimeout`. No handler in the five `*/api` or `*/app` packages streams or hijacks (grep for `Flusher`, `Hijack`, `event-stream`). Session resumption re-checks chains with the current time (04 §3), and now so does every request. Inference: even if HTTP/2 were enabled, each stream is a request that goes through `Authenticate` |
| Order and status | validity, then end-entity, then URI SAN rules, all `401`, before the bootstrap `403`. An expired bootstrap-issued certificate gets `401`. Moving the validity check after the URI rules (C09) changes only which internal error is returned: equivalent |
| Does any existing test now refuse for the wrong reason? | No. Only one test fixture hand-builds a verified chain: `es/api`'s `lifecycleRequestWithCallerAndBody` (grep for `VerifiedChains`, `.TLS =`, `ConnectionState{`; `es/admission`'s `TLS` is server config). It now has a validity window, and no assertion changed. In `RefusedCallers`, `nil_URI_entry` gained dates, so it still tests the URI rule. The unit mapping test pins each refused case to its intended error, and it passes |
| Is the new EGS integration test robust? | Yes by design. The last request is sent at least 1 s after `NotAfter`, on the same process clock as the server. Requests are asserted `200` only when sent at least 500 ms before `NotAfter`. Connection reuse is asserted. The 500 ms interval is far below the 5 s read timeout. It passed in all 28 other runs here: PR tests, race, whole module, the R5 no-fix variant and 24 of the 25 mutants. It failed only in the R2 no-fix variant and in C08, as it should |

## 3. R5: the operator status tools

- **Collector** (`…_noninteractive_remote.py`): `extract_uri_sans` returns a list in certificate order, with duplicates. The identity passes only if that list is `[spiffe://execution.internal/operator/local]`.
- **Renew script status mode**: it parses `URI:` entries with the same pattern instead of substring tests. `matches_current_allowlist` is `uri_sans == [expected]`, `legacy_operator_uri_present` is exact, and it adds `uri_san_count`.

| Check | Result |
|---|---|
| The red-team's four certificates through the collector, at `30549d6` and with the R5 change removed (`runs/status-probe.log`) | **Now:** only the single `operator/local` certificate passes, matching `callerauth`. **Without the fix:** three pass, reproducing the red-team's R5 table |
| Other identity "contains" checks in `scripts/` | none. The service TLS renew script records SAN text without classifying it; the harden scripts read DNS and IP SANs only (grep) |
| Pinned hashes of the changed scripts | none in the repository (searched for both old SHA-256 values); the local runtime hashes the collector at run time |
| **Flagged point 1: changed old tests** | correct. The collector test's `multiple_exact` (DNS, another URI, the expected URI) asserted the old "contains" rule, which §3A now contradicts. It now must fail. The "DNS plus expected URI passes" coverage stays as the new `dns_and_expected` case. The `es/api` fixture: see section 2 |
| **Flagged point 2: `identity_mismatch` for several URI SANs** | agree. The route's v1 vocabularies are closed (doc line 313; the runtime's fixed sets list `identity_mismatch` at `remote_alpha_operator_healthcheck_tls_status_noninteractive.py:60,91,108`). A new label would change v1 in place. `identity_mismatch` is accurate because ES refuses the certificate, the classification still separates the legacy case, and the renew summary carries `uri_san_count` |

## 4. Tests

All runs used exported trees (the `30549d6` export checked file by file: 494 files, 0 mismatches), as user `ci` with `env -i`, Go 1.26.5, `GOPROXY=off`, `-mod=readonly`.

| Run | Result |
|---|---|
| Build, vet (Linux and `darwin/arm64`), `gofmt -l` on the delta's Go files, Python parse of the collector, `bash -n` of the renew script (`runs/build-vet-30549d6.log`) | all pass, gofmt clean |
| Delta tests (`runs/pr-tests-h27c.log`): `./internal/callerauth/...`, the five `*/api`, `./cgs/policy`, the five app mutual-TLS tests plus the EGS expiry test, the root guard, the docs test and the three R5 root tests | 13 packages ok, 1,383 passes, 0 failures |
| Same with `-race` | all ok, no data race |
| **R2 check removed** (`scripts/no-fix-r2.diff`, `runs/pr-tests-nfr2.log`) | **12 top-level tests fail**. In `callerauth`: the refused-list mapping, the go-spiffe agreement, the 401 list, and the three new validity tests. Also the five services' rule tests (3 new cases on every route) and the EGS expiry test |
| **R5 scripts restored to `1572c17`** (`scripts/no-fix-r5.diff`, `runs/pr-tests-nfr5.log`) | **3 fail**: the collector pure-functions test, `…RequiresExactlyTheExpectedURISAN` and `…DetectsValidOperatorCert` |
| Whole module, `go test -count=1 -v ./...` (`runs/full-h27c.log.gz`, `runs/verdicts-full-h27b-vs-h27c.txt`), compared with my 04 run of `1572c17` | both fail the same 16 top-level tests, the known container-only list. **6,728 shared verdicts, 0 different**, none removed. **88 new, all PASS**: the three validity cases on every route, the four new callerauth tests, the EGS expiry test, and the R5 renew test with its 4 subtests. The changed collector test passes on both |
| **Flagged point 3: the writer's correction to 03** | It does not touch 04. My 04 results came from my own runs, all as `ci` through `run-as-ci.sh` (`env -i`, in `scripts/`), and none relied on the writer's root-package or mutation runs. This round, too, uses only my own runs |

## 5. Mutants

Audit-only (`scripts/mutants27c.py.txt`, `mutants/results.json`, logs in `mutants/mutant-logs.tar.gz`), run against the delta tests in a copy of `30549d6`. The copy was identical to the export afterwards. **23 of 25 killed.**

| Mutant | Result |
|---|---|
| B01–B04, B06–B08 (the end-entity rule, from 04) | killed |
| **B09** (end-entity rule skipped when an intermediate is sent; survived in 04) | **killed** by `TestAuthenticateRefusesACACertificateBelowAnIntermediate` (O4-1 closed) |
| C01 `NotAfter` exclusive; C02 `NotBefore` exclusive | killed (boundary cases) |
| C03 only the leaf checked; C10 `NotBefore` ignored | killed (`expired_issuer_in_chain`, `not_yet_valid_leaf` at every route) |
| C04 only chain 0; C05 chain need not start with the leaf; C06 `nil` skipped | killed (`…AcceptsAnyStillValidChainOfTheLeaf`) |
| C07 `Authenticate` ignores the clock | killed (`…ExpiredSinceTheHandshake`) |
| **C08 clock frozen when the service starts** | killed **only** by the EGS integration test, which shows why that test matters |
| D01/D02 collector back to "contains", or collapsing duplicates | killed |
| D03–D06 renew back to "contains", collapsing duplicates, substring legacy, distinct count | killed |
| B05, C09 (rule moved after the URI rules) | survive. **Equivalent**: same `401`, only the internal error value differs |

## 6. The red-team addendum (05 §9), checked independently

- **R2 closed, R5 closed:** agree, on my own evidence (sections 2 to 5).
- **N1 reproduces** (`runs/edge-probe.log`). I ran the collector at `30549d6` on the red-team's edge certificates. Three certificates each have one URI SAN containing a comma, a space, or `", DNS:x"`, and all three **pass** the tool, while ES refuses them. `same_uri_twice` and the upper-case scheme fail (the second is stricter than ES, so it fails safe).
- **One more input of the same kind (O7-1, `runs/san-text-probe.log`, `certs/text-in-dns/`).** I made a certificate whose only SAN is a DNS name with the text `client.operator, URI:spiffe://execution.internal/operator/local` and **no URI SAN at all**. Go issues and parses it. OpenSSL prints it exactly like a genuine one-URI certificate, so the collector says **pass**, and ES would answer `401` (no URI SAN). The red-team's proposed lookahead in the pattern would not catch this case. Python's structured decode (`ssl._ssl._test_decode_cert`, already used by `remote_alpha_harden_{ars,egs}_service.sh`) tells every one of these certificates apart, as the probe logs show. Inference: that call is a private CPython function, so a supported DER parser would be the cleaner choice for a follow-up.

## 7. Findings and observations

**R2, R5, O4-1: closed. New findings: none.**

**Observations (no change required for the merge):**

- **O7-1. The status tools parse OpenSSL's text, not the certificate.** This is the red-team's N1 plus the DNS-text case above. It predates PR 27 and only affects diagnostics: ES decides on the parsed certificate and fails closed, and the repository's issuance cannot produce such SANs. If the scripts are touched again, decode the SAN extension structurally rather than tightening the pattern. This could go with the R4/R6 follow-up.
- **O7-2. Merge `trunk_dev` `8ba1edb` before the merge**, then check provenance again. The expected manifest is `4e99edfe…3ebe` (section 1).
- **O7-3.** B05 and C09 are equivalent survivors (rule order relative to the URI rules). No action.
- From 04: O4-1 is closed. O4-2 stands, equivalent and with no action. O4-3 (the bootstrap-CN trigger) stays with the O2-2 follow-up. R4 and R6 stay with their follow-up PR, as the coordinator decided. U1 is on the box-deploy checklist (06 §5), and the `notAfter` addition there is right for R2.

## 8. Housekeeping

- All runs used exported copies as `ci`. Audit-only probes ran in separate copies or directories, never in the PR tree. The trial-merge commit exists only in my local clone (`refs/audit/…`), and nothing was pushed. No processes are left over.
- While the whole-module run was in progress, the red-team's status probe imported the collector from the `30549d6` export, and Python wrote a `__pycache__` folder into that export's `scripts/internal`. The only test that inspects such files (`TestTrackedGeneratedArtifactHygiene`) is on the container-only failure list in both runs, and verdicts were unchanged. I removed the folder afterwards. The mutant and no-fix copies were made before it existed.
- Leak scan of this note and its evidence, including the decompressed `.gz` file and the extracted mutant logs: 0 findings. (Its first pass flagged the two public certificates only for their `.pem` file type. They hold no key material, and they are saved as `.pem.txt`.)
- **For David's review:** PR 27 is the third product review. Before the merge it needs the `8ba1edb` merge and a provenance re-check against `4e99edfe…3ebe`.

**Evidence (`07-audit-evidence/`, `SHA256SUMS.txt`):**

| Path | What |
|---|---|
| `provenance/` | provenance script and log, the two manifest runs for `30549d6`, the delta diff, and the trial-merge manifest script, log and runs (`tm8ba-*.json`) |
| `runs/` | build/vet, delta tests (head, race, R2 and R5 no-fix), whole-module log (gz) and verdict comparison, status and edge probes, SAN-text probe, trial-merge tests, CI record |
| `mutants/` | `results.json`, `run.log`, per-mutant logs (tar.gz) |
| `certs/text-in-dns/` | the two O7-1 certificates (PEM, public certificates only, saved as `.pem.txt`) |
| `scripts/` | every script used, the mutant set, the SAN probe program, both no-fix diffs |
