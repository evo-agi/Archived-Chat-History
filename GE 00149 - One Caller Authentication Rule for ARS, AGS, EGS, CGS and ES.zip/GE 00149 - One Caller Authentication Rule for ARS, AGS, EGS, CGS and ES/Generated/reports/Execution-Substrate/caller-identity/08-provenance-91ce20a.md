# PROVENANCE RE-CHECK: Execution-Substrate PR #27 at `91ce20a` (merge of `trunk_dev` `8ba1edb`)

**Result: PASS.**

`91ce20a` is exactly the trial merge I checked in `07-audit.md` §1. It has the same tree, and its v2 manifest is the value I gave there.

The merge adds only PR #26's four `es/admission` test files. Nothing that 07 audited changed. 07's verdict (ACCEPT) carries over to `91ce20a`.

This check was read-only, at the writer's request of 19:26Z. No subagents were used. Evidence: `08-provenance-evidence/`.

| Check | Result |
|---|---|
| Remote state (19:26Z) | topic `claude/project-thread-i9yve2` and `refs/pull/27/head` are `91ce20a85cb254946f63069eadfbb51e4cdee151`. `trunk_dev` is `8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce` |
| Shape | one merge commit, "Merge trunk_dev 8ba1edb into the caller authentication branch". Its parents are `30549d6` (the head audited in 07) and `8ba1edb` |
| **Tree** | **`8396590b03fe37d768f09f627ac193ded9008ba4`, my 07 trial-merge tree**. A fresh `git merge-tree` of `30549d6` and `8ba1edb` gives the same tree again |
| What the merge adds over `30549d6` | `es/admission/producercontract_test.go` and `workstream_{a,b,c}_guardrails_test.go`, PR #26's files. None of them is a PR 27 path |
| PR diff | `git diff 8ba1edb 91ce20a` is byte-identical to `git diff 036d507 30549d6`, the diff 07 audited |
| **v2 manifest** (tool `c08597e2…a3ca` verified; HEAD reset to `8ba1edb`, upstream `origin/trunk_dev`) | two runs byte-identical: **`4e99edfed96f75052cb9775bce8704b743a26ed4077bc6f4e3b8ce5c78633ebe`**, textual diff `b2c78c1f…6470`, 41 files. **Byte for byte my 07 trial-merge manifest (`tm8ba-1.json`), and the writer's value** |
| Tests | Not rerun, because the tree is identical to the trial merge I already tested in 07 (`07-audit-evidence/runs/trial-merge-8ba1edb.log`). There, build and vet passed, and `es/admission`, the caller-auth packages, the root guard and the docs test passed. The whole-module results of 07 (same 16 container-only failures, 0 changed verdicts) apply to the PR's own content, which is unchanged |
| CI on `91ce20a` | run 45248632968, job 137951999596, started 19:24:38Z, still in progress at 19:27Z. CI on `30549d6`, the same PR content, was green |

The PR is ready for David's product review (third product review). Before the merge, the provenance must be checked again only if the topic or `trunk_dev` moves again.
