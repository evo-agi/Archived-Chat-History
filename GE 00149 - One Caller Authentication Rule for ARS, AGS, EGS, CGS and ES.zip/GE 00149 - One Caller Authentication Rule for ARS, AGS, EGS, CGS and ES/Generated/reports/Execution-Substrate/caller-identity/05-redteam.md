# RED-TEAM: Execution-Substrate PR #27 at `1572c17` (one caller authentication rule in `internal/callerauth`)

**Verdict: ACCEPT, with one small scripts change in this PR (R5) and one recommended product change (R2).**

No attack got a caller accepted under an identity it does not hold, and no repo-issued legitimate caller is refused, through anything PR 27 adds or changes. The new rule agrees with go-spiffe on 1,159,616 raw URI SANs. A leaf key cannot act as an issuer. Every route that checks a caller goes through the one function.

What must or should change:

- **R5 (Low, introduced by this PR, fix in this PR, scripts only).** The repo's operator status tool still says "pass" for an operator certificate with two URI SANs. ES now refuses that certificate with 401. Before PR 27 the two agreed for the main case.
- **R2 (Medium, pre-existing, not made worse).** A caller is authenticated once per TLS connection. A client that keeps its connection busy stays authenticated after its certificate expires: 20 requests were accepted up to 38 s after expiry. Base `036d507` does the same. Now that `callerauth` is the one place for the rule, the fix is a few lines there. I recommend doing it in this PR. If it stays out, it needs its own PR before short-lived SPIRE SVIDs become callers (workload identity WI-1..WI-5).
- **R4, R6 (Low, no change required for the merge).** The root guard misses two more spellings of a sixth copy (this confirms audit O2-4). ARS and AGS accept allowlist prefixes that ES refuses and that can never match a canonical caller path.
- **One Unknown before the box deployment (U1).** Whether the box's live client certificates each carry exactly one URI SAN. The repo's own issuance does. The operator certificate's issuance is not in the repo.

This red-team was read-only on the PR: nothing was pushed, no live service or box was touched, and no subagents were used. All probes ran in a local worktree of `1572c17` (and of base `036d507` where stated) and were removed afterwards. The worktree was clean at the end. Evidence: `05-redteam-evidence/`. I read the PR, design and code first and formed my own attack list before reading 02/03/04; section 7 maps my results to theirs.

## 0. In plain words

PR 27 moves "who is calling" into one function that all five services (ARS, AGS, EGS, CGS, ES) use. I tried to make it accept the wrong caller, or refuse a right one:

- **Odd certificate text.** I wrote over a million odd URI texts into real certificates. The new check answers exactly like the SPIFFE reference library every time. The only texts it rewrites are the two that the contract already lists.
- **Odd certificate chains.** A caller who holds a normal certificate cannot use it to sign a certificate for someone else. Go's TLS layer refuses that before the check runs.
- **Old certificates.** A certificate that has expired is refused on a new connection. But a connection opened before expiry keeps working for as long as the client keeps it busy. This is old behaviour, not new, and the fix now fits in one place.
- **Tools that disagree.** The operator status script still treats "contains the right ID" as good. The services now require "exactly one ID". The script should match the services.

## 1. Provenance and setup

| Item | Value |
|---|---|
| PR head | `claude/project-thread-i9yve2` = `refs/pull/27/head` = `1572c171859d373733f6ee7329ecc66efac8ce78` (fetched 18:12Z) |
| Base | `trunk_dev` = `036d50724b499b020c5149c55ad902cfcb1482c0`; merge-base of head and `trunk_dev` is `036d507` |
| Diff | `git diff --stat origin/trunk_dev...1572c17`: 33 files, +2387 −220 (same 33 paths as the 04 manifest) |
| Toolchain | Go 1.26.5 (auto-downloaded `toolchain@v0.0.1-go1.26.5.linux-amd64`, as `go.mod` requires), go-spiffe v2.4.0 from `go.mod`, OpenSSL 3.0.13 |
| Build | `go build ./...` and `go vet` on the five `*/api` packages, `internal/callerauth/...` and the five apps: pass |
| PR's own tests (Ran) | `go test -race` on `./internal/callerauth/... ./ars/api ./ags/api ./egs/api ./cgs/api ./cgs/policy ./es/api`: all ok; root guard and docs contract test: ok |
| Other open PRs fetched | #12 = #28 `2c8bf35`, #26 `a88467f`, #29 `89da53d`, #30 `0b8b9c0` |

## 2. Attack surface (my own map, before reading the audits)

- **Listeners.** The only network listeners in production Go are the five service apps (`{ars,ags,egs,cgs,es}/app/app.go`), each `tls.NewListener` with `ClientAuth: tls.RequireAndVerifyClientCert`, its own `ClientCAs` and TLS 1.2 minimum, served by `http.Server` (HTTP/1.1 only: no `h2` in `NextProtos`). `es/runtimehelper` and `cmd/es-workload-api-mock` listen on Unix sockets and do not identify SPIFFE callers. (Read.)
- **Routes.** Every non-`/health` route of all five services calls `s.callers.Authenticate(w, r)` before any service work: ARS 4 read and 2 writer routes (`ars/api/server.go:47-190`), AGS publish, EGS trust model, CGS authorize, ES contract, prepare, submit and lifecycle GET/POST. ARS and Go's mux answer 404/405 for unknown routes or methods before authentication; that reveals only route shape to a holder of a CA-verified certificate. (Read.)
- **Identity reads.** In production Go, only `internal/callerauth/callerauth.go:122-156` reads `VerifiedChains`, `.URIs` or `Issuer.CommonName`. No production code uses go-spiffe's `spiffeid` or `x509svid`. (Read, `grep`.)
- **Downstream use of the identity.** Authorization gets only the canonical `Path()` or `String()`: ARS/AGS/ES `matchesAuthorizedPathPrefix` (three byte-identical copies, SHA-256 `08e3f65b…4700`), EGS exact list, AGS publication binding (`ags/publish/service.go:311-313`), CGS exact compare with `workload_identity_id` (`cgs/api/server.go:71`). (Read.)

## 3. Findings

### R1. URI parsing differential: no finding (Ran)

**Probe** (`probes/zz_redteam_uri_differential_test.go.txt`). Each candidate URI text is written byte for byte into a URI SAN of a real certificate, which goes through `x509.CreateCertificate` and `x509.ParseCertificate`. Then three readers are compared: `callerauth.CallerFromConnectionState`, go-spiffe `x509svid.IDFromCert` (restricted to `execution.internal` with a path), and `callerauth.ParseSPIFFEID` on the raw text.

Candidates: a grammar product of 8 schemes × 8 separators × 18 authorities × 51 paths × 17 suffixes (959,616), plus 200,000 random strings over a 70-character alphabet (seed 20261123). Total **1,159,616**.

| Result | Count |
|---|---|
| Refused by Go's certificate parser | 341,721 |
| Refused by `callerauth` | 815,817 |
| Accepted by `callerauth` | 2,078 |
| **`callerauth` and go-spiffe disagree (accept/refuse, or different ID)** | **0** |
| Canonical ID does not round-trip through `ParseSPIFFEID` | 0 |
| Accepted by the certificate path but refused by the raw-text rule | 112: every one is a scheme letter-case variant and/or one trailing empty `#`; both are documented in §3A |
| Two raw texts naming the same ID outside those two normalizations | 0 |

The rerun log is `logs/uri-differential.log`; the 112 cases are listed in `logs/normalized.txt`.

### R2. An expired client certificate stays authenticated on a busy connection (Medium, pre-existing; Ran)

**Probe** (`probes/zz_redteam_expiry_test.go.txt`, in `egs/app`): the real EGS app, started by the package's own `startTestApp` with its real TLS config. The client leaf is `spiffe://execution.internal/service/execution`, issued by the fixture's runtime CA, with `NotAfter` 4 s ahead. The client sends `GET /v1/trust-model` every 2 s on one keep-alive connection, and `httptrace` records whether the connection was reused.

| Tree | Result |
|---|---|
| PR head `1572c17` (`logs/expiry-1572c17.log`) | `NotAfter` 18:22:23Z. **20 requests answered 200 on the reused connection after expiry, the last at 18:23:01.791Z (38 s after `NotAfter`).** Then a new connection, with session resumption allowed by a client session cache, fails the handshake: `remote error: tls: expired certificate` |
| Base `036d507` (`logs/expiry-base-036d507.log`) | same behaviour (6 accepted in a 12 s window after expiry), so not introduced by PR 27 |

**Why (Read).** Go verifies the client chain once, during the handshake. `callerauth` runs on every request but reads `VerifiedChains` from the connection without checking the time. None of the five `http.Server` values sets `IdleTimeout`, `ConnState` or any maximum connection age (`{ars,ags,egs,cgs,es}/app/app.go`; `grep` for `SetKeepAlivesEnabled|ConnState|IdleTimeout` finds nothing). With `IdleTimeout` zero, Go closes a connection only after `ReadTimeout` idle (5 s in every repo config, for example `scripts/72_supported_local_setup.sh:1221-1278`). A client that sends one request every few seconds keeps its connection, and its identity, indefinitely. Resumption is not a way around it (Ran: refused), so the gap is only the live connection.

**Impact (Inference).** In SPIFFE, short certificate lifetime is the revocation mechanism: to cut off a workload, you stop renewing its SVID. Under R2, a caller that keeps one connection busy keeps every permission it had, ES submit or CGS authorize included, past that point. Today's Remote Alpha callers use long-lived openssl-issued certificates (`REMOTE_ALPHA_CERT_DAYS` in `scripts/internal/remote_alpha_es_service_tls_renew.sh:957-969`), so the practical impact today is low. It becomes material once SPIRE-issued, short-lived SVIDs are callers, which is the approved workload identity direction.

**Fix (recommended, in `callerauth`).**

- In `CallerFromConnectionState`, return a new error (still the same 401) unless at least one verified chain has every certificate within `NotBefore`/`NotAfter` at the current time. Checking every chain, not only chain 0, keeps a cross-signed chain that is still valid working.
- §3A sentence: "the verified chain must still be within its validity period at the time of each request, not only at the handshake".
- Tests: a unit test with an injectable clock on `Authenticator`, plus one mutual-TLS test with a short-lived leaf (the probe shape, about 6 s).
- This closes R2 for HTTP/1.1, because every request is checked.

If the coordinator keeps R2 out of this PR, the project's no-"later" rule needs a machine trigger. The simplest is to make it a prerequisite PR of WI-1 in the workload identity plan.

### R3. Chain-shape attacks: no finding (Ran)

**Probe** (`probes/zz_redteam_chain_test.go.txt`, real mutual TLS, `logs/chain-shapes.log`). An attacker holds a legitimate end-entity certificate (`service/deployment`) issued by the trusted root. It uses that certificate's key to sign a new leaf for `spiffe://execution.internal/operator/local`, then presents `[forged leaf, legitimate cert]`. Three shapes of the legitimate certificate:

- `CA:FALSE` with `digitalSignature`;
- no basic constraints, no key usage and no EKU;
- no basic constraints with `digitalSignature`.

In all three, the legitimate certificate alone authenticates as its own ID (200), and the forged chain fails the TLS handshake with `unknown certificate authority`. Go does not accept a non-CA certificate as an intermediate, so `callerauth` never sees the forged leaf.

The same probe shows that a leaf whose issuer CN differs from the configured bootstrap CN only by surrounding white space, letter case or a no-break space gets 200, not 403. That is exactly the exact comparison §3A documents, and it is O2-2 territory (out of scope). It is listed here only as one more input for the CA-bundle inventory: the 04 audit already says the real boundary is the content of each `client_ca_file`.

### R4. The root guard misses two more spellings of a sixth copy (Low; Ran; confirms O2-4)

**Probe** (`probes/rtprobe.go.txt`, `probes/zz_rtprobe.go.txt`, `logs/guard-evasion.log`). I added two production files:

- a new package `internal/rtprobe` that reads `r.TLS.PeerCertificates[0]` and calls go-spiffe `x509svid.IDFromCert`, then reads the issuer through a variable (`issuer := cert.Issuer; issuer.CommonName`);
- a file in `ars/api` that calls it and reads `issuer.CommonName` the same way.

`TestCallerIdentityIsReadOnlyByCallerauth` **passes**. The guard is syntactic: it matches the selector names `URIs`, `Issuer.CommonName`, and `TLS`/`VerifiedChains`/`PeerCertificates` inside the five API packages only (`caller_authentication_contract_test.go:57-68`). The 02 audit found three other evasions (raw extension bytes, reflection, TLS state outside the API packages) and judged the guard acceptable as hygiene. I agree that this does not block the merge.

**Optional strengthening** (if the writer touches the PR anyway). Make the guard type-aware with `go/types`:

1. Flag any read of `(*http.Request).TLS` in production code outside `internal/callerauth`. This targets server-side caller identity, and it does not catch PR #12's client-side `VerifyConnection` in `es/admission/reliable_submit_operational_provider.go`, which reads a `tls.ConnectionState` of an outgoing Nomad connection.
2. Forbid imports of `github.com/spiffe/go-spiffe/v2/svid/x509svid` and `.../spiffeid` outside `internal/callerauth`. `es/runtimehelper` uses only `jwtsvid` and `workloadapi`, so nothing breaks today.
3. Flag `x509.Certificate.URIs` and the `CommonName` of a `pkix.Name` reached from `Certificate.Issuer` by type, not by name.

### R5. The operator status tool says "pass" for operator certificates ES now refuses (Low, introduced by this PR; Ran + Read)

**Probe** (`probes/status_probe.py.txt`, `logs/status-probe.out`, `probes/zz_redteam_opcert_test.go.txt`, `logs/opcert-mtls.log`). Four operator client certificates were made with OpenSSL the way the repo's mint scripts make them (`CA:FALSE`, `digitalSignature,keyEncipherment`, `clientAuth`, `DNS:client.operator` plus the URIs below). The repo's own `classify_identity` (`scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py:719-775`, run unmodified with its real `run_command` and `openssl`) and `callerauth` over real mutual TLS judged each one:

| Certificate URI SANs | status tool | `callerauth` (PR 27) | old ES code at `036d507` (Read) |
|---|---|---|---|
| `operator/local` | pass | 200 | 200 |
| `operator` + `operator/local` | **pass** (`legacy_operator_uri_present: true`) | **401** | 403 (first matching URI was `operator`, outside the allowlist) |
| `operator/local` + `service/execution` | **pass** | **401** | 200 (first matching URI) |
| `operator/local-evil` | fail | 200 at authentication (ES authorization then refuses it with 403) | 403 |

The status tool accepts when the expected URI is *in the set* of URI SANs (`:752-753`). §3A now requires *exactly one* URI SAN. For the third row, PR 27 turns an agreement (pass, 200) into a disagreement (pass, 401).

The renew script's status mode has the same rule, and a weaker one (Read): `scripts/internal/remote_alpha_operator_healthcheck_tls_renew.sh:400-401` uses Python substring tests on the OpenSSL SAN text. So `matches_current_allowlist` is also true for `…/operator/local-evil`, and `legacy_operator_uri_present` is true whenever `…/operator/local` is present, because `…/operator` is a prefix of it. Its blocker text says "SAN must include" (`:458`).

**Impact.** Diagnostics only, but on exactly the path a box deployment of PR 27 would use. If the live operator certificate has two URI SANs (U1), ES refuses it after the upgrade, while the status tool keeps saying the identity is fine.

**Fix (in this PR, scripts and their tests only):**

- `classify_identity`: pass only when the set of URI SANs equals `{EXPECTED_OPERATOR_URI}`, and count duplicates too (parse the list, not a set). Classify several URI SANs as a failure of their own.
- The renew script's identity block: parse the `URI:` entries the same way instead of substring tests.
- Tests: add a two-URI case and an `operator/local-evil` case to `remote_alpha_operator_healthcheck_tls_status_noninteractive_test.go` and `remote_alpha_operator_healthcheck_tls_renew_test.go`.

### R6. ARS and AGS accept allowlist prefixes that ES refuses and that never match (Low, pre-existing, authorization; Ran)

**Probe** (`probes/zz_redteam_prefix_test.go.txt`, `logs/prefix-validation.log`): the example configs from `.examples/config/`, with one prefix swapped in, loaded through each service's own `config.Load`.

| Prefix | ARS | AGS | ES |
|---|---|---|---|
| `operator/local` | loads | loads | loads |
| `service` | loads | loads | refused (at least two segments) |
| `spiffe://execution.internal/operator/local` | loads | loads | refused |
| `operator//local`, `operator/./local`, `/operator/local/` | loads | loads | refused |
| ` operator/local` (leading space) | loads | loads | refused |
| `operator/lo cal` | loads | loads | loads |

ES has `validateAllowedSPIFFEPathPrefix` (`es/config/config.go:299-320`). ARS and AGS refuse only blank values (`ars/config/config.go:107-114`, `ags/config/config.go:124-131`).

Since PR 27, every caller path that reaches authorization is canonical. So a full SPIFFE ID, a leading space, an empty segment or a space inside a segment can never match: the legitimate caller gets a silent 403, the "dead policy" case the PR already closes for CGS `id.conf`. And a one-segment ARS/AGS prefix such as `service` authorizes every `service/*` identity, which ES would refuse at startup. Repo configs use only canonical two-segment prefixes, so nothing is wrong today.

**Fix (follow-up, not required for this merge):** one shared prefix validator applied by ARS, AGS and ES, which requires a canonical path under `callerauth`'s segment rules and ES's two-segment minimum. This is authorization, which PR 27 deliberately leaves per service, so it fits better in its own small PR than here.

## 4. Unknowns

**U1. Live box client certificates.** Unknown: whether every client certificate presented to an ES service on the box has exactly one URI SAN and is an end-entity certificate. The repo's own issuance does this:

- `remote_alpha_es_service_tls_renew.sh:940-1036` issues `ags-client`, `es-client` and `es-governance-client` with one URI SAN, `CA:FALSE` and `digitalSignature,keyEncipherment`;
- `72_supported_local_setup.sh:1473-1477` does the same.

But the operator certificate's issuance is not in the repo: the renew path stops with `unsupported_signing_topology` (`remote_alpha_operator_healthcheck_tls_renew.sh:829-832`). Confirm before deploying PR 27 to the box, read-only, in the box session. For each client certificate file:

```sh
openssl x509 -noout -ext subjectAltName,basicConstraints,keyUsage -in "$f"
```

The files are `/etc/execution-substrate/tls/operator-client-cert.pem`, plus `ags-client-cert.pem`, `artifact-registry-client-cert.pem` and `execution-governance-client-cert.pem` under the TLS directories named at `remote_alpha_es_service_tls_renew.sh:30-50`. Each must show exactly one `URI:` and no `CA:TRUE`, `Certificate Sign` or `CRL Sign`.

**U2. Coverage the environment could not provide.** No run against the box or a live SPIRE: SPIRE-issued SVIDs were modelled by their documented shape, not issued by SPIRE. No macOS run. HTTP/2 was not attacked because no listener enables it.

## 5. Interaction with other open PRs

- **PR #12 / #28 (`2c8bf35`).** Trial merge onto `1572c17`: one conflict, `PLANS.md` (both add a first `## Status` entry), resolved by keeping both. Then `go build ./...`, the root guard and docs contract tests, and the caller-auth packages all pass (`logs/trial-merge-pr12.log`). PR 12 adds no caller-facing route. Its only TLS-state read is client-side (`es/admission/reliable_submit_operational_provider.go`, `VerifyConnection` pinning the Nomad server key), which the current guard allows and the R4 strengthening would also allow.
- **PR #29 (`89da53d`), #26, #30.** No changes to identity, TLS state or API routes (`git diff` scan). PR #29 does not interact with any finding here.

## 6. What I tried that held (no finding)

- Every route of all five services authenticates before service work, including body decoding (Read; the PR's `CheckRoute` tables pin it per route).
- A CA certificate, or `keyCertSign`/`cRLSign`, as the leaf: refused (the PR's own tests, and the 04 matrix).
- A legitimate leaf under an intermediate (SPIRE shape): accepted (the PR's mTLS test, rerun green).
- A leaf key used as an issuer, in three shapes: refused by Go (R3).
- An expired certificate on a new connection, or through session resumption: refused (R2 probe).
- Two URI SANs, foreign trust domains, user information, ports, percent encoding, dot segments, queries, fragments: 401, identical to go-spiffe over 1.16 million parsed certificates (R1).
- CGS: the caller ID compared to `workload_identity_id` is canonical, and `id.conf` principals must be canonical, so neither side can be non-canonical (Read, `cgs/api/server.go:71`, `cgs/policy/idfile.go:323-332`).
- Empty bootstrap issuer: unreachable through any of the five `config.Validate` functions (Read).

## 7. Cross-check with the audits (read after the attacks)

| My item | 02 / 03 / 04 |
|---|---|
| R1 | Independent repeat of 02 §2's fuzz (1.28 M runs, different generator) with the same result |
| R2 | New. 04 §3 covers resumption (chains re-checked against current CAs), not a live connection past expiry |
| R3 | New probe; consistent with 04 §3 (parents found by issuer name) and 04 §8 (the boundary is `client_ca_file`) |
| R4 | Extends O2-4 with two more evasions |
| R5, R6 | New |
| U1 | New; 02 checked repo-issued certificates only (`A2-1`, "No legitimate caller breaks") |

## 8. Evidence

`05-redteam-evidence/` (`SHA256SUMS.txt` lists every file):

- `probes/`: every probe as `.txt`, including `status_probe.py.txt` and the guard-evasion files;
- `logs/`: the outputs cited above;
- `opcerts/`: the four operator certificates and the test CA certificate, public parts only. No private keys were kept.

Leak scan of this note and the evidence: only synthetic test identities and `127.0.0.1` addresses; no personal data and no key material.

## 9. Addendum (19:25Z): re-check of the repair at `30549d6`

**R2 and R5 are closed at `30549d6`.** I found no new finding, only one optional nit (N1). This re-check covers only the two findings the coordinator put in this PR (18:34Z); R4 and R6 stay with the follow-up PR, and U1 stays on the box-deploy checklist.

**Provenance.** `claude/project-thread-i9yve2` = `refs/pull/27/head` = `30549d646d438a9c17142e84149cdb432b7a7f19`, tree `87d3d769f976ad84270483966694c27863c45a8b`. Delta from `1572c17` is three commits: `9792cbf` (R5), `62d31c8` (R2) and `30549d6` (O4-1 test). That is 15 files, +484 −59. `trunk_dev` is still `036d507`. Evidence: `05-redteam-evidence/recheck-30549d6/`.

**R2: closed (Ran + Read).**

- **Code (Read).** `CallerFromConnectionState(state, now)` refuses with `ErrOutsideValidity` unless some verified chain starts with the leaf and has every certificate within `NotBefore`..`NotAfter` at `now`, both ends included as in `crypto/x509`. `Authenticate` reads `time.Now` on every request. The only production caller of `CallerFromConnectionState` is `Authenticate` (`git grep`). The clock override exists only in `export_test.go`. A `nil` entry invalidates its chain. That is what section 3 R2 asked for, including "any still-valid chain".
- **My unchanged probe** against the real EGS app (`expiry-30549d6.log`): with `NotAfter` 19:07:41Z, the reused connection got `200` before expiry and **`401` on all 6 requests from 19:07:41.578Z to 19:07:51.584Z**. A new connection fails the handshake (`expired certificate`). The same probe on `1572c17` gave `200` up to 38 s after expiry.
- **The PR's own tests (Ran, `pr-tests-30549d6.log`).** `go build ./...` passed. `go test -race` passed on `internal/callerauth/...`, the five `*/api` packages and `cgs/policy`; their route tables now include `expired_leaf`, `not_yet_valid_leaf` and `expired_issuer_in_chain`. The writer's `egs/app` regression test `TestTrustModelRefusesARequestOnAConnectionWhoseClientCertificateHasExpired` passed. The root guard and docs contract tests passed.

**R5: closed for every case I reported (Ran).** Both tools were run at `30549d6` on nine operator-shaped certificates, and the same certificates were presented to `callerauth` over real mutual TLS:

- the four original certificates;
- five new ones minted with raw SAN bytes (`mint_edge_certs.go.txt`): the same URI twice, an upper-case scheme, a comma inside the URI, a space inside the URI, and `", DNS:x"` inside the URI.

The noninteractive collector is `status-probe-30549d6.out`. The renew script's identity block is `renew-probe-30549d6.out`, with its regex and comparisons extracted verbatim and its `cert_ext` reproduced. The mutual-TLS run is `opcert-mtls-30549d6.log`.

| Certificate URI SANs | collector | renew | `callerauth` |
|---|---|---|---|
| `operator/local` | pass | pass, count 1 | 200 |
| `operator` + `operator/local` | fail (`legacy_operator_identity`) | fail, count 2, legacy true | 401 |
| `operator/local` + `service/execution` | fail (`identity_mismatch`) | fail, count 2 | 401 |
| `operator/local-evil` | fail | **fail** (substring bug gone) | 200, then 403 at ES authorization |
| `operator/local` twice | fail | fail, count 2 | 401 |
| `SPIFFE://…/operator/local` | fail | fail | 200 (tool stricter than ES: fails safe) |
| `…/operator/local,evil` (one URI) | **pass** | **pass** | 401 (N1) |
| `…/operator/local evil` (one URI) | **pass** | **pass** | 401 (N1) |
| `…/operator/local, DNS:x` (one URI) | **pass** | **pass** | 401 (N1) |

`TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveRemoteCollectorPureFunctions` (it holds the new collector assertions) and `TestRemoteAlphaOperatorHealthcheckTLSStatusRequiresExactlyTheExpectedURISAN` pass here. Eight other root `…StatusNoninteractive…` runtime tests fail in this container on both `1572c17` and `30549d6`, the same eight, with exit code 2. This container has no `ssh`, `uuidgen` or `setfacl`, so those failures are environmental (`root-operator-healthcheck-*.txt`). The writer reports the root package passing in a prepared container (06 §4). I did not rerun it there.

**N1 (nit, optional, no security impact).** When a URI SAN itself contains a comma, a space or `", "`, both tools pass while ES refuses with 401. ES fails closed, and no repo issuance can produce such a URI: an OpenSSL config cannot even express a comma inside a URI SAN. So this only matters as diagnostic accuracy.

- A lookahead in the shared pattern, `(?:^|[\s,])URI:([^,\s]+)(?=,\s|$)`, makes the comma and space cases fail (`renew-probe-tightened-regex.out`).
- The `", DNS:x"` case cannot be told apart from a real extra DNS SAN in OpenSSL's text output; only parsing the DER would.
- I would leave N1 as it is, or take the lookahead if the writer touches the scripts again.

**The `identity_mismatch` label.** I agree with keeping it. The noninteractive route's v1 vocabulary is closed. Adding a label would widen v1 in place, which the project's contract rules forbid without a version change. `identity_mismatch` is accurate, because ES refuses the certificate. The renew summary's `uri_san_count` gives the detail where no closed vocabulary applies.

**U1.** The writer's box-deploy checklist (06 §5) carries the check, with `notAfter` added. That suits R2, since an expiring certificate now fails at once, not at the next handshake.

**CI (Read, GitHub API at about 19:20Z).** Run 45241862055, job 137928307746 on `30549d6`: steps 1 to 15 succeeded, including "Test" (18:50:06Z to 19:05:56Z). "Listed tests still fail" was still in progress.

`05-redteam-evidence/recheck-30549d6/` holds the probe outputs, the edge-certificate mint program (`mint_edge_certs.go.txt`; it contains the PEM label string "EC PRIVATE KEY" but no key material) and the five new certificates, public parts only. `SHA256SUMS.txt` of `05-redteam-evidence/` was regenerated to include them.
