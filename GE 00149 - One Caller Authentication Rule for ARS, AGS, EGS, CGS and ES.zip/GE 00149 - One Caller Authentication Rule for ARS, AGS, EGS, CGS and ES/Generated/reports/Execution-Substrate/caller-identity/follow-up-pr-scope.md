# Caller identity follow-up PR: scope

The PR after [#27](https://github.com/evo-agi/Execution-Substrate/pull/27). The PR 27 writer thread starts it as soon as #27 merges into `trunk_dev`, as the coordinator decided at 18:34Z and 19:16Z on 2026-11-23. The items come from the PR 27 red-team (`05-redteam.md`) and re-audit (`07-audit.md`).

| Item | What to do | Source |
|---|---|---|
| R4 | Make the root guard type-aware with `go/types`. Flag `(*http.Request).TLS` reads outside `internal/callerauth`. Forbid importing go-spiffe `x509svid` and `spiffeid` outside that package. Match `Certificate.URIs` and `Issuer.CommonName` by type, so a read through a variable is caught too. | `05-redteam.md` R4 |
| R6 | Write one shared allowlist-prefix validator for ARS, AGS and ES. It should take canonical paths under `callerauth`'s segment rules, with at least two segments. ARS and AGS then refuse at startup prefixes that can never match, as ES already does. | `05-redteam.md` R6 |
| N1 | Make both operator healthcheck TLS status tools read the URI SANs from the certificate's DER bytes instead of OpenSSL's `subjectAltName` text. Today a single URI SAN that contains a comma, a space or `, DNS:x` passes both tools, while ES refuses it with `401`. The tools are the noninteractive collector and the renew script's status mode. The red-team's lookahead regex handles the comma and space cases but not `, DNS:x`, so it is not the fix. There is no security impact: ES fails closed. Add tests built from raw SAN bytes, like the red-team's `mint_edge_certs.go.txt`. | `05-redteam.md` §9 N1 |
| O7-1 | This is the same fix as N1. One more input of that kind: a certificate with **no URI SAN at all**, whose only SAN is a DNS name containing the text `client.operator, URI:spiffe://execution.internal/operator/local`. It passes both status tools today, while ES refuses it with `401`. Decoding the SAN extension from DER handles this case and every N1 case. Tightening the regex does not. Add these certificates as test cases too. | `07-audit.md` O7-1, `07-audit-evidence/certs/text-in-dns/` |

Not in this PR: O2-2, matching the bootstrap issuer by key instead of common name. That is its own PR after #27, starting with a read-only CA-bundle inventory on the box, as `03-repair.md` and `06-repair.md` record.
