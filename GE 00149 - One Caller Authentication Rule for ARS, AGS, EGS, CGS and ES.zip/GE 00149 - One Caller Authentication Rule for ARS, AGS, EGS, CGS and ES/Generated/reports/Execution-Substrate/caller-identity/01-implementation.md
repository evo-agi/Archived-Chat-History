# One caller authentication rule for the five ES services (PR #27)

**Verdict: IMPLEMENTED, product code. Draft PR [#27](https://github.com/evo-agi/Execution-Substrate/pull/27) at `6e2d2dc`. Needs a fresh independent audit and a red-team, then David's review (product code, counts toward his first three).**

```text
IMPLEMENTATION REPORT
Objective:        one shared, contract-documented caller identity check used by ARS, AGS, EGS,
                  CGS and ES, refusing foreign trust domains and multi-identity certificates,
                  with tests per call site that fail on the old code
Repository:       evo-agi/Execution-Substrate
Base ref and SHA: origin/trunk_dev 792f17c7c56ca4a9c00d34aeb59524d898aeb58c
                  (work started on 200fd60; rebased onto 792f17c after PR #22 merged, no conflict)
Topic branch:     claude/project-thread-i9yve2
Topic head SHA:   6e2d2dcd5938b01a8c9d6837dbbe16519e6264a2 (4 commits on 792f17c)
Tree SHA:         88429063786116a03e8f2d263c8e8ca85ef810ea
v2 manifest:      manifest_sha256 faf35459f1340245045a0041dae9eebf5c3aeb29a053b1626ac05131516ba638
                  textual_diff_sha256 cf107734cd7562cdbbe3bdbdd2f1779903ed2af98095f8768b27b59953789971
                  32 files, upstream origin/trunk_dev, HEAD reset to 792f17c (tool sha256 c08597e2…a3ca verified)
Effect status:    TOPIC_BRANCH_PUSHED | DRAFT_PR_OPENED https://github.com/evo-agi/Execution-Substrate/pull/27 |
                  MERGE_NOT_PERFORMED | INDEPENDENT_AUDIT_NOT_PERFORMED | RED_TEAM_NOT_PERFORMED
```

## 0. In plain words

Every request to an ES service arrives over mutual TLS, and the service decides who is calling from the caller's client certificate. ARS, AGS, EGS, CGS and ES each had their own copy of that code, and the copies had drifted. CGS accepted callers from any SPIFFE trust domain, no service refused a certificate carrying two identities (each took the first one it liked), and malformed spellings of an identity (a trailing slash, a `..` segment, a query) reached the allowlist at three services and passed it. Now one package, `internal/callerauth`, does it for all five, the rule is written once in the system contract (section 3A), and a test fails if production code anywhere else reads a certificate's identity again.

For real callers nothing changes: every caller identity the repo's scripts and configs issue is one plain `spiffe://execution.internal/...` ID. Inference: the drift was a latent weakness, not an open door, because a caller needs a certificate from a CA the service already trusts, and SPIRE only issues conforming single-URI SVIDs. It mattered for any other CA in a client bundle, and it made the five services disagree about who a caller is.

## 1. Was CGS's any-domain acceptance a documented contract? (stop condition)

The brief said to stop and report if it was. Finding: **it was not**, so I proceeded and closed it. Evidence at `200fd60`:

- `.docs/system_overview/contracts.md` said the same sentence for AGS, ES and CGS: "requires authenticated SPIFFE caller identity and rejects bootstrap-PKI callers". The ARS and EGS sections named their allowed callers only (EGS as full `execution.internal` IDs). No section stated a trust-domain rule for one service, and none said CGS accepts other domains.
- The CGS `id.conf` grammar shows `principal: "spiffe://..."` with the domain elided. Every `id.conf` in the repo (`cgs/policy/id.conf`, test fixtures, scripts) uses `spiffe://execution.internal/...`.
- No test pinned foreign-domain acceptance. Existing CGS tests use `execution.internal` only.
- `PLANS.md` calls caller authentication plus "narrow SPIFFE allowlist authorization" a current invariant for the slice-0 hot path and has no CGS exception.

This is a judgment call (Inference), flagged here and in the PR for the audit and David: if anyone relied on CGS federation, this PR breaks it, and the contract now says federation needs an explicit contract change (section 3A "Reopened seams").

## 2. Drift found at the base

Old code, measured by running the new per-service handler tests against `200fd60` with only the new test files and the new package added (`01-evidence/old-code-handler-outcomes.txt`, `old-code-handler-cases.txt`). "old 200/202/404/500" means the request passed authentication and authorization and reached the service; "old 403" means it was authenticated and then refused by authorization; PANIC means the handler panicked (Go's HTTP server recovers it per request and drops the connection).

| Refused credential | ARS | AGS | EGS | CGS | ES |
|---|---|---|---|---|---|
| two URI SANs, allowed ID first / same ID twice / second not SPIFFE | reached store | reached publish (200) | reached signer (200) | authenticated (200) | reached service (200/202) |
| two URI SANs, foreign ID first | reached store | 200 | 200 | 403 | 200/202 |
| two URI SANs, allowed ID second | 403 | 403 | 403 | 403 | 403 |
| foreign trust domain, or `execution.internal` as prefix/suffix, with port, user, upper case, ID without path | 401 | 401 | 401 | **authenticated** (403 on mismatch; 200 when the workload names itself) | 401 |
| trailing slash, leading empty segment, `.`/`..` segments, `/..` back into the path, query or fragment after a slash, `+ ~ : @` in a segment | reached store | 200 | 403 | 403 | 200/202 |
| query, fragment, empty query, inner empty segment, percent encoding, root path only | 403 | 403 | 403 | 403 | 403 (some 200/202 on the exact-prefix routes) |
| empty verified chain | **PANIC** | 401 | 401 | 401 | 401 |
| nil URI entry (crafted state; real TLS cannot produce it) | PANIC | PANIC | PANIC | 401 | PANIC |

Worst case found (`01-evidence/cgs-old-foreign-allow-probe.log`): old CGS with an `id.conf` principal `spiffe://other.internal/service/execution` and a caller presenting that ID answered `200 {"allowed":true, ... "role":"worker"}`.

## 3. The change

Four commits on `792f17c`:

1. `ce55a75` **Document one caller authentication contract for the five services.** New `.docs/system_overview/contracts.md` section "3A. Caller Authentication Contract" (purpose, public surface, current invariants, ownership, temporary compatibility edge, reopened seam). The AGS, ARS, EGS, ES and CGS sections point at it; CGS adds the foreign-domain `401` and the `id.conf` principal rule. `.docs/execution_lifecycle/contracts.md` §4 defines "authenticated caller identity" by reference; `boundaries.md` §11 and `architecture.md` list `internal/callerauth`; `PLANS.md` gets a Status entry (classified as a *Current invariant refinement*, explicitly not a Workstream D redesign) and a current-state fact. `caller_authentication_docs_contract_test.go` pins those sentences.
2. `4633946` **Add internal/callerauth.** `ParseSPIFFEID` (strict text rule), `CallerFromConnectionState` (leaf of the first verified chain, exactly one URI SAN), `Authenticator.Authenticate` (401 for identity failures, then 403 for the bootstrap issuer). `callerauthtest` holds one list of 37 refused credentials and a `CheckRoute` helper every service test uses.
3. `9b05063` **Authenticate callers of all five services through internal/callerauth.** Each service keeps only its authorization; `NewServer` signatures are unchanged. Per-service handler tests, one real mutual-TLS test per service, and the root guard `caller_authentication_contract_test.go`.
4. `6e2d2dc` **Refuse CGS id.conf principals that no authenticated caller can present.** `validateSubject` runs `callerauth.ParseSPIFFEID` on the principal as written.

The rule (section 3A):

1. Read the leaf of the first verified chain. None: `401`.
2. Exactly one URI SAN. None or several: `401`. DNS, IP and e-mail SANs are not read.
3. The URI must be `spiffe://execution.internal/<segment>[/<segment>...]`, segments of `A-Z a-z 0-9 . - _`, not `.` or `..`. These are the SPIFFE standard's ID rules plus "a path is required". Anything else: `401`.
4. Then the bootstrap issuer common name (configured value, surrounding white space trimmed, compared exactly): `403`.
5. Services authorize the canonical identity only: `ID().Path()` for prefix and exact-path lists (ARS, AGS, ES, EGS), `ID().String()` where whole IDs are compared (AGS publish caller binding, CGS caller equals `workload_identity_id`).

Why my own parser and not go-spiffe's `spiffeid.FromString` (already in `go.mod`, v2.4.0, used only in tests): go-spiffe widens its character set under the build tag `spiffeid_charset_backcompat`, and it accepts the trust-domain ID without a path. The tests compare both directions against go-spiffe instead (section 5).

Go's certificate parser lower-cases the URI scheme and drops an empty trailing `#` before the code sees it; `x509svid.IDFromCert` behaves the same. Section 3A states this and a test pins it.

## 4. What changes for callers

| Caller | Before | After |
|---|---|---|
| SPIRE or script-issued certificate, one conforming `execution.internal` ID | accepted | accepted, same authorization |
| bootstrap-issuer certificate | `403` | `403` (unchanged) |
| several URI SANs | first matching one used | `401` everywhere |
| other trust domain | `401` at four, authenticated at CGS | `401` everywhere |
| malformed ID (see section 2) | reached authorization, `403`, or panic | `401` everywhere |
| CGS `id.conf` with a principal outside `execution.internal` or not in canonical form | loaded, could never match (or matched a foreign caller) | startup error naming the subject |

The response texts are unchanged. The CGS request and response shape is unchanged. Bodies stay plain text.

## 5. Tests and what each pins

New tests: 38 test and fuzz functions in 17 files.

- `internal/callerauth/callerauth_test.go`: accepted and refused ID tables with the exact error (`ErrMalformedSPIFFEID` vs `ErrForeignTrustDomain`); differential test and fuzz target against go-spiffe `spiffeid.FromString` (in our trust domain, with a path); differential test against `x509svid.IDFromCert` on real certificates; leaf-of-first-chain; Go parser normalization; 401 for every refused credential; 403 for the bootstrap issuer including a padded configured value; exact issuer comparison; identity before issuer; empty authenticator refuses all.
- `{ars,ags,egs,cgs,es}/api/caller_authentication_test.go`: every route that checks a caller, run over the whole shared list: `401` with the exact body and `text/plain; charset=utf-8`, the handler not reached (counters on the store, publisher, signer, policy JSON writer or lifecycle service), `403` for the bootstrap issuer, the allowed caller reached. Plus authorization-stays-local tests (AGS also checks the caller handed to the publish service: path and full ID).
- `{ars,ags,egs,cgs,es}/app/caller_authentication_integration_test.go`: real TLS listeners with real client certificates carrying the URIs verbatim (raw SAN extension), so the Go certificate parser is in the loop.
- `cgs/api`: a foreign caller naming itself as the workload gets `401`; matching caller allowed, mismatch `403`.
- `cgs/policy/principal_trust_domain_test.go`: 16 principals refused at load (foreign, prefix, suffix, port, user, upper case, scheme case, trailing slash, empty segments, dot segment, query, fragment, percent, leading or trailing space); conforming principals still load.
- `caller_authentication_contract_test.go` (root): parses every production `.go` file outside `internal/callerauth` and fails on a read of `.URIs` or `.Issuer.CommonName`, and on `.TLS`, `.VerifiedChains` or `.PeerCertificates` in the five API packages; each API `server.go` must import the package, build its authenticator from `bootstrapIssuerCN` and call `.callers.Authenticate(w, r)`. It walks at least 100 files and must reach all five API packages. On `200fd60` it reports 58 findings.
- `caller_authentication_docs_contract_test.go` (root): pins section 3A and the service references.

On the old code (`200fd60` + only the new tests and package): every service's handler test fails (ARS 25 of 39 cases on each of its 6 routes, AGS 24, EGS 24 on both caller paths, CGS 30, ES 24 on all 14 route variants); every real mutual-TLS test fails (`01-evidence/old-code-mtls-tests.log`); `cgs/policy` loads all 16 bad principals; the root guard fails.

## 6. Validation

All on head `6e2d2dc` unless stated. Environment in `01-evidence/environment.txt`.

| Check | Result | Evidence |
|---|---|---|
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...` | OK | (run before commit, and by CI) |
| GitHub Actions "build, vet and test" (the merge gate) | **success**, run [45204507396](https://github.com/evo-agi/Execution-Substrate/actions/runs/45204507396), 15:22-15:50Z | PR checks |
| Full CI test gate in the cloud container (`go_test_gate.py gate`, Nomad/Vault/SPIRE/bindfs/images as in CI, unprivileged user) on head **and** on base `792f17c` | Both red only for host reasons, and **identically**: the same 48 failing test lines (8 top-level tests) on both, none only on head; same 4 self-skips. 25 packages ok on head vs 20 on base (the 5 extra are the new test packages). The 8: `TestBringupScriptUpCheckDownFullProfile` (image build needs egress, run separately below), `TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup` (Guess: a host difference in its fake environment), and 6 root-package tests that need `/usr/bin/uuidgen` | `gate-head-6e2d2dc.log`, `gate-base-792f17c.log`, `gate-compare-…txt`, `compare_gate.py.txt` |
| Bring-up with the PR's own service binaries (`TestBringupScriptUpCheckDownFullProfile`, image built offline from `6e2d2dc`) | **PASS** (51 s). ARS, EGS, AGS, ES run as containers with test-issued mutual TLS certificates; Inference from the test config: ES's startup calls to EGS and ARS use the `service/execution` client certificate and the check's ARS read uses `operator/local`, so real handshakes go through the new code | `bringup-head-6e2d2dc.log` |
| Race detector: `internal/callerauth`, the 5 API packages, `cgs/policy`, and the 5 mutual-TLS tests | all ok | `race-6e2d2dc.log` |
| Fuzz `FuzzParseSPIFFEIDAgreesWithTheSPIFFEReferenceParser`, 60 s | 3,338,331 executions, no disagreement with go-spiffe (an earlier 60 s run before the rebase: 3,254,479) | `fuzz-60s-6e2d2dc.log` |
| Unit tests `internal/callerauth -v` | 150 PASS lines, 0 FAIL | `callerauth-unit-v.log` |
| Mutation run: 43 mutants of `callerauth.go`, 14 of the call sites and the `id.conf` rule | **56 of 57 killed**. The survivor M03 is equivalent: an ID without a path has the empty path, which the segment check refuses anyway. 13 mutants are killed only by the package's own tests (exact error kinds, issuer comparison details, identity-before-issuer order, upper case in a path, the last-chain variant), because a service only sees `401`/`403`; every call-site mutant is killed by its service's tests | `mutants.py.txt`, `mutants.log`, `mutants-summary.txt`, `mutants.log.json` |
| Old code fails the new tests | yes, every service (section 5) | `old-code-*` |
| Trial merge with PR 13 (`e060449`) | builds and vets; callerauth, API and `cgs/policy` tests ok; `es/admission` guardrails ok; root guard passes on PR 13's production files | `pr13-trial-merge-tests.txt`, `pr12-pr13-trial-merge.txt` |
| v2 manifest | `faf35459…a638`, tool hash `c08597e2…a3ca` checked first; fresh clone, `git reset --mixed origin/trunk_dev`, upstream re-pinned to `origin/trunk_dev` | `manifest-v2-6e2d2dc.json` |

Not run: the Mac (coordinator: not for this thread), the Remote Alpha box, a red-team. The `uuidgen` root tests were not re-run with `uuid-runtime` installed; CI ran them green on the runner.

## 7. PR 12 / PR 13 and other open work

- Shared files with PR 12 (`8058561`) and PR 13 (`e060449`): only `PLANS.md` (both) and `.docs/system_overview/boundaries.md` (PR 13). Neither PR edits the five `*/api/server.go` files or any other Go file of this PR. Trial merges with `git merge-tree` (`01-evidence/pr12-pr13-trial-merge.txt`): `boundaries.md` merges cleanly; this PR adds exactly one conflict to each, in `PLANS.md`, because both add a new first entry under `## Status`. Whichever merges second keeps both entries. (Both PRs already conflict with current trunk_dev in `docs_contract_test.go`; that conflict is not from this PR.)
- PR 13 adds `es/admission/reliable_submit_operational_provider.go`, which reads `VerifiedChains` and `PeerCertificates` of an outgoing connection to the local Nomad server. The root guard only forbids those reads in the five API packages, so it does not fire on PR 13. The guard forbids `.URIs` and `.Issuer.CommonName` anywhere outside `internal/callerauth`; at `e060449` the only such reads are the five old copies in `*/api/server.go` that this PR removes (grep), so PR 13's own files pass the guard.
- The guardrail tests that pin `es/api/server.go` submit lines (`es/admission/reliable_submit_guardrails_test.go`) and `es/app` App fields (`workstream_c_guardrails_test.go`) pass unchanged.
- D3 (reliable submit wiring) needs the exact canonical SPIFFE URI of the caller from the verified client certificate (`submit_idempotency_correlation_and_recovery.md` §4). `caller.ID().String()` is that value; the old ES code only extracted a path.
- New test packages (`ars/api`, `ags/api`, `egs/api`, `cgs/api`, `internal/callerauth`) have the `testtmpdir` `TestMain` file (PR 23 rule); the guard in `internal/testtmpdir` passes.

## 8. Residuals, follow-ups and confidence

Not done here, on purpose (outside the brief):

- **R1.** Five copies of `loadTLSConfig` (server TLS setup) and three of `matchesAuthorizedPathPrefix` remain. The design scan's ES-1 covers them; a follow-up PR can move them next to `callerauth` without touching the identity rule.
- **R2.** The bootstrap issuer is recognized by the issuer common name string of the leaf, not by key. A bootstrap root that signs an intermediate with another common name would not be recognized. Recorded in section 3A as a temporary compatibility edge; now one place to change.
- **R3.** The leaf's own `IsCA` or key usage is not checked by `callerauth`; Go's verifier already requires the client-auth EKU through the chain. Inference: no gap for the current CAs.
- **R4.** Federation (other trust domains) is a reopened seam, not configuration.
- **R5.** The only other trust domain in the repo is `governed-execution.local`, in the fixed IDs of the inert outside-observer protocol (`es/internal/outsideobserverprotocol/validate.go:20-21`, a proposed contract that nothing outside its package imports; `01-evidence/spiffe-ids-in-repo.txt`). It is not a caller of the five services today. If that observer is ever wired as an HTTPS caller of an ES service, section 3A refuses it until the contract is changed on purpose. Worth a line in the observer's design when it is picked up.

Confidence:

- High that all five services now apply one rule: the root guard, the shared test list and the per-route tests all pass, and the old code fails them.
- High that conforming callers are unaffected: bring-up with the PR's binaries passes, CI is green, the gate fails nothing new, and every SPIFFE ID that the repo's scripts, configs and code give a caller of the five services is a conforming `execution.internal` ID (grep, `spiffe-ids-in-repo.txt`; the one other domain is R5). Not shown here: a live SPIRE-issued SVID on the Remote Alpha box.
- Medium-high on the parser's agreement with the SPIFFE standard: table and fuzz agreement with go-spiffe; residual risk is a rule both implementations get wrong the same way.
- Judgment call on CGS federation (section 1).

## 9. For the audit and red-team

Suggested angles, not a limit:

- Can any input reach a service's authorization with an identity that `ParseSPIFFEID` would refuse as text? (`CallerFromConnectionState` parses `uri.String()` of the certificate parser's URL; section 3A documents the two normalizations found.)
- Is "leaf of the first verified chain" right for every way Go builds `VerifiedChains` (several chains, cross-signed intermediates)?
- The bootstrap rule (R2): does the client CA bundle of any service ever contain a CA that can mint a non-bootstrap issuer name?
- The CGS judgment call (section 1) and the `id.conf` principal rule.
- The root guard: can production code read the identity without the selectors it looks for (reflection, a helper in another package, `tls.ConnectionState` passed through)? It is a tripwire for copies, not a proof.

## 10. Evidence (`01-evidence/`, `SHA256SUMS.txt`)

| File | What |
|---|---|
| `environment.txt` | container, tools, users, how bring-up was built offline |
| `gate-head-6e2d2dc.log`, `gate-base-792f17c.log`, `gate-compare-head-6e2d2dc-vs-base-792f17c.txt`, `compare_gate.py.txt` | the compared gate runs |
| `gate-head-6e2d2dc-run1-before-host-tools.log` | first gate run, before `setfacl`, `ip`, the locale and `ssh` were installed |
| `rungate.sh.txt`, `runall.sh.txt`, `race.sh.txt` | the run scripts |
| `bringup-head-6e2d2dc.log` | bring-up with the PR's binaries |
| `race-6e2d2dc.log`, `fuzz-60s-6e2d2dc.log`, `callerauth-unit-v.log` | race, fuzz, unit |
| `mutants.py.txt`, `mutants.log`, `mutants-summary.txt`, `mutants.log.json` | mutation run |
| `old-code-handler-tests.json` (go test -json), `old-code-handler-summary.txt`, `old-code-handler-cases.txt`, `old-code-handler-outcomes.txt` | new handler tests on the old code |
| `old-code-mtls-tests.log` | new mutual-TLS tests on the old code |
| `cgs-old-foreign-allow-probe.log`, `cgs_old_foreign_allow_probe_test.go.txt` | old CGS allowing a foreign caller |
| `pr12-pr13-trial-merge.txt`, `pr13-trial-merge-tests.txt` | overlap and trial merge |
| `spiffe-ids-in-repo.txt` | SPIFFE IDs in non-test files |
| `manifest-v2-6e2d2dc.json` | v2 manifest |
