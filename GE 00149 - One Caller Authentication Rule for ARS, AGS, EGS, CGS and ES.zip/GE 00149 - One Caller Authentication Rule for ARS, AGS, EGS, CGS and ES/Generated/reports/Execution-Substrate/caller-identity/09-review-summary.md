# PR #27 in five minutes: one caller check for all five ES services

**What I need from you:** approve merging [PR #27](https://github.com/evo-agi/Execution-Substrate/pull/27) into `trunk_dev`, or ask about anything below. This is your third and last product review. The audits, the red-team and CI have all passed. Head `91ce20a`, up to date with `trunk_dev` `8ba1edb`.

## What it does

When something calls one of the five ES services (ARS, AGS, EGS, CGS and ES itself), the service reads the caller's client certificate to find out who is calling. Each service had its own copy of that check, and the five copies had drifted apart. This PR replaces all five with one shared check, `internal/callerauth`, and writes the rule down once in the contracts document (section 3A). A test fails if anyone copies the check again.

## What was wrong before

- **CGS accepted callers from any trust domain**, not only ours (`execution.internal`).
- **No service refused a certificate carrying two identities.** It took whichever one it liked.
- **Odd spellings of an identity got through**, such as a trailing slash or a `..` in the path.
- **A CA certificate could pose as a caller** (found by the audit).
- **An expired certificate kept working on an open connection** (found by the red-team, older than this PR). Go checks the certificate only when the connection opens, so a caller that kept the connection busy was never cut off. Now every request checks the certificate's dates.
- **The operator status tools said "pass"** for a certificate that ES now refuses, one with two identities (found by the red-team). They now agree with ES.

## What changes for real callers

Nothing, for a caller with a normal certificate: one identity in our trust domain, not a CA, not expired. Every certificate our scripts and SPIRE issue is like that. Callers with any of the problems above now get a plain "401 not authenticated" from every service. Who may use which route is unchanged.

## Three decisions to know about

1. **CGS's "any trust domain" was treated as a bug, not a feature.** No document or test promised it, and every config uses our domain. The audit agreed.
2. **Expired certificates are now cut off mid-connection.** That is the point of short-lived certificates, but it has one practical effect. Before this goes onto the box, someone checks that the box's client certificates have one identity each and are not about to expire. The read-only command is in `06-repair.md` §5.
3. **One temporary rule stays.** Certificates from the temporary bootstrap certificate authority are still recognised, and refused, by that authority's name rather than its key, as before. A separate PR right after this one fixes that, starting with a read-only look at the box's certificate bundles.

## How it was checked

- **Three audits:**
  - The first found one problem (the CA posing as a caller), which was fixed.
  - The second accepted with no findings.
  - The third, after the red-team fixes, accepted with no findings.
- **One red-team:** it found two things to fix in this PR (expired certificates and the status tools). Both were fixed, and the red-team confirmed it. It also attacked all five services with tricky identity spellings and odd certificate chains. Those attacks failed.
- **Tests:** every new test fails on the old code and passes on the new.
  - Each service is tested against the same list of 43 bad credentials.
  - The expired-certificate test runs against the real EGS service.
- **Deliberate breakage:** I broke the new check on purpose in 74 ways, and the tests caught 73. The one they missed makes no difference anyone can see.
- **Final check:** after the last update from `trunk_dev`, the auditor confirmed that the PR's content is byte for byte what was audited (`08-provenance-91ce20a.md`).
- **CI:** green on the final head.

## Size

41 files.

- **Product code:** one new 272-line package plus small edits to six files. The five services each lose about 40 lines of their old copy.
- **Rest:** tests (about 2,300 lines), the contract docs (about 170 lines) and two operator scripts.

## What comes after

- **Follow-up PR**, started once this merges. All three items are low severity, and none of them lets a wrong caller in:
  - a stricter version of the "don't copy the check" test;
  - one shared rule for the services' route allowlists;
  - the status tools reading certificates directly instead of OpenSSL's printed text.
- **The bootstrap PR** in decision 3.

Full detail: `01-implementation.md` to `08-provenance-91ce20a.md` in this folder.
