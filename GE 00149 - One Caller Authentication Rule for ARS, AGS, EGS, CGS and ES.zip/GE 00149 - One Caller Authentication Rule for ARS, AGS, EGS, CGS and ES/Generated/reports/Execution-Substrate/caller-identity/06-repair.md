# PR #27 repair after the red-team: R2 (expired certificates on busy connections) and R5 (operator status tools)

**Verdict: REPAIRED. Draft PR [#27](https://github.com/evo-agi/Execution-Substrate/pull/27) at `30549d6`, still up to date with `trunk_dev` `036d507`. Needs the narrow re-audit of `1572c17..30549d6` by the same auditor, the red-team's confirmation that R2 and R5 are closed, then David's review (product code).**

Validation on `30549d6` in this cloud container: build, vet (Linux and macOS), race, the four service apps, the root package and the bring-up with this head's binaries all pass; 73 of 74 mutants killed (the survivor is the known equivalent one); the new tests fail on the red-teamed code. GitHub CI on `30549d6` is green (run 45241862055, completed 19:14Z).

**Update 19:15Z.** The red-team re-checked `30549d6` and confirms R2 and R5 closed (`05-redteam.md` section 9, sha256 `86bfcb7b…a436`), with one optional nit N1 for the scripts: a single URI SAN that itself contains a comma or a space passes both status tools while ES refuses it with `401`. ES fails closed, and the red-team does not ask for a change in this PR. The red-team also agrees with keeping the closed v1 label `identity_mismatch`. The narrow re-audit is still open.

```text
REPAIR REPORT
Findings:         05-redteam.md R5 (Low, scripts, fix in PR 27) and R2 (Medium, pre-existing; fix in PR 27),
                  as the coordinator decided at 18:34Z; plus re-audit observation O4-1 (optional test)
Repository:       evo-agi/Execution-Substrate
Base ref and SHA: origin/trunk_dev 036d50724b499b020c5149c55ad902cfcb1482c0 (merge-base unchanged)
Topic branch:     claude/project-thread-i9yve2
Red-teamed head:  1572c171859d373733f6ee7329ecc66efac8ce78
New head SHA:     30549d646d438a9c17142e84149cdb432b7a7f19 (pushed; refs/pull/27/head is the same)
Tree SHA:         87d3d769f976ad84270483966694c27863c45a8b
Commits added:    9792cbf  Fail the operator TLS status on more than one URI SAN, as ES does (R5)
                  62d31c8  Check the client certificate's validity period on every request (R2)
                  30549d6  Refuse a CA certificate below an intermediate over mutual TLS (O4-1)
Delta diff:       1572c17..30549d6, 15 files, +484 -59, sha256 448170b2…2c2f (06-evidence/)
v2 manifest:      manifest_sha256 41090e09521d68c02c39af40ee9df3648dccddde50e68d5bf131b94c5359d108
                  textual_diff_sha256 b2c78c1ffadcf243b5c5fca09057b1f1a274e72bdeb1df9ed20077d537ff6470
                  41 files (33 before + 8 new paths), two runs byte-identical, upstream origin/trunk_dev,
                  HEAD reset to 036d507 (tool sha256 c08597e2…a3ca verified)
Effect status:    TOPIC_BRANCH_PUSHED | DRAFT_PR_UPDATED | MERGE_NOT_PERFORMED |
                  RE_AUDIT_NOT_PERFORMED | RED_TEAM_CONFIRMED_R2_R5_CLOSED (19:12Z)
```

## 0. In plain words

The red-team found two things to fix in this PR.

- **R2: expired certificates on long-lived connections.** Go checks a client certificate once, when the TLS connection opens. A client that kept its connection busy stayed authenticated after its certificate expired. In SPIFFE, letting a short-lived certificate expire is how you cut a workload off, so this matters once SPIRE certificates become callers. Now every request checks that the certificate chain is still valid at that moment. An expired one gets the usual `401`. The red-team's probe, run against the real EGS app, is now a regression test. It fails on the old code and passes now.
- **R5: the operator status tools.** They said "pass" for an operator certificate that merely contained the expected identity among others. ES now refuses any certificate with more than one identity. Both tools now pass only when the expected identity is the certificate's only one. The renew script also stopped matching by substring, so `operator/local-evil` no longer counts as `operator/local`.

Nothing changes for a caller with a valid, normal certificate.

## 1. R2: the validity period is checked on every request

**Code** (`internal/callerauth/callerauth.go`):

- `CallerFromConnectionState(state, now)` now takes the time explicitly. After the "leaf exists" checks and before the end-entity rule, it requires that at least one verified chain starts with the leaf and has every certificate within `NotBefore`..`NotAfter` at `now`. Both ends count as valid, as in Go's verifier. Otherwise it returns the new `ErrOutsideValidity`, which `Authenticate` answers with the same plain `401` as every other identity failure.
- **Every chain, not only chain 0.** A cross-signed client chain that is still valid along one path keeps working. That was the red-team's advice.
- **The chain must start with the leaf.** In real TLS every verified chain starts with the same leaf. The rule does not rely on that: a still-valid chain of some other certificate does not count. A `nil` entry makes its chain invalid.
- **`Authenticator`** keeps a clock, `time.Now` from `NewAuthenticator`. Only this package's tests replace it, through `export_test.go` (`WithClock`), which is compiled only with the tests. The zero `Authenticator` still refuses every request before the clock is read.
- **Order.** Identity failures, this one included, still return `401` before the bootstrap-issuer `403`.

**Coverage.** HTTP/1.1 is the only protocol the five listeners serve (no `h2` in `NextProtos`, per the red-team's map). So every request is checked, and that closes R2.

**Contract** (`.docs/system_overview/contracts.md` §3A), a new invariant after the first-chain bullet: "The verified chain must still be within its validity period at the time of each request, not only at the TLS handshake. A request has a caller identity only if at least one verified chain that starts with the leaf has every certificate between its `notBefore` and `notAfter` at the time the request is authenticated. …" `PLANS.md` (status entry and Current-State Facts) names the rule. The docs test pins both §3A sentences.

**Tests:**

| Test | What it pins | Old code |
|---|---|---|
| `egs/app` `TestTrustModelRefusesARequestOnAConnectionWhoseClientCertificateHasExpired` (the red-team's probe) | The real EGS app with its real TLS config, and a client leaf with `NotAfter` 2 to 3 s ahead. One keep-alive connection sends a request every 500 ms across `NotAfter`. The test requires the connection to be reused, `200` before expiry, `401 Authenticated caller identity required` on the same connection after expiry, and a failed handshake on a new connection. About 4.3 s | **fails**: `200` on the reused connection after expiry (`old-code-new-tests.log`) |
| `callerauthtest.RefusedCallers`: `expired_leaf`, `not_yet_valid_leaf`, `expired_issuer_in_chain` (43 cases now), each with the allowed ID | every route test of ARS, AGS, EGS, CGS and ES expects `401` | fail (mutant M51) |
| `TestCallerFromConnectionStateChecksTheValidityPeriodAtTheGivenTime` | accepted at `NotBefore`, inside and at `NotAfter`; refused 1 ns outside either end; refused when the issuer in the chain is expired or not yet valid | M51 to M54, M57, M58 |
| `TestCallerFromConnectionStateAcceptsAnyStillValidChainOfTheLeaf` | expired first chain plus valid second chain of the same leaf: accepted. Valid chain of another leaf: refused. Second chain with a `nil` entry: refused | M55, M56, M60 |
| `TestAuthenticateRefusesACallerWhoseCertificateHasExpiredSinceTheHandshake` | same TLS state, `Authenticator` clock moved: accepted inside, `401` after `NotAfter` and before `NotBefore` | M59 |
| `TestCallerFromConnectionStateAgreesWithTheSPIFFEReferenceValidator` | go-spiffe checks validity inside chain verification, after the bundle lookup the comparison stops at, so the reference now includes the leaf's validity period | no change in agreement |

**Existing test fixture changed.** One fixture that predates this PR had to change: `es/api/server_test.go`'s `lifecycleRequestWithCallerAndBody`. It hand-builds a "verified" leaf without times, so its `NotAfter` was year 1. Under the new rule that is an expired certificate. The helper now gives the leaf a validity window of now ± 1 h. No assertion changed. I found no other hand-built verified chain in the module's tests (`grep` for `ConnectionState{` and `.TLS =`).

## 2. R5: the operator healthcheck TLS status tools require exactly one URI SAN

**Noninteractive status collector** (`scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py`):

- `extract_uri_sans` returns a list in certificate order, duplicates included.
- `classify_identity` passes only when that list is exactly `[spiffe://execution.internal/operator/local]`. Any other set fails with failure class `identity_mismatch`. `legacy_operator_uri_present` is still reported.
- The local runtime computes the collector's SHA-256 at run time, so no pinned hash changes.

**Renew script, status mode** (`scripts/internal/remote_alpha_operator_healthcheck_tls_renew.sh`):

- It parses the `URI:` entries of the OpenSSL SAN text with the collector's pattern, instead of substring tests.
- `matches_current_allowlist` means "the only URI SAN is the expected one". `legacy_operator_uri_present` means an exact entry.
- The summary gains `identity.uri_san_count`.
- The blocker now says "operator certificate must carry exactly one URI SAN, spiffe://execution.internal/operator/local".

**One deliberate difference from the red-team's suggestion.** The red-team suggested a classification of its own for several URI SANs. In the noninteractive status tool I kept the existing `identity_mismatch` label. That route's v1 schema has closed enum vocabularies, checked by the local runtime and by the docs (`execution-substrate.remote-alpha.operator-healthcheck-tls-status-noninteractive.v1`). A new label would widen v1 in place. `identity_mismatch` is accurate, because ES refuses the certificate. The renew summary has no closed vocabulary, so it reports the count. A distinct label in the noninteractive route would need a v2 schema. I do not think that is worth it for a diagnostic.

**Contract** (`.docs/remote_alpha_operator_healthcheck_noninteractive_status.md`):

- Identity rule: "The identity passes only when the certificate carries exactly one URI SAN and that URI is `spiffe://execution.internal/operator/local`, because the caller authentication contract (…section 3A) refuses a certificate with more than one URI SAN. A certificate with several URI SANs, including the same URI twice, fails with `identity_mismatch` even when one of them is the expected URI."
- Failure mapping: "…legacy-only identity, or more than one URI SAN: `identity_mismatch`."
- Both sentences are pinned in `caller_authentication_docs_contract_test.go`. The existing pin "extracts exact URI SAN entries" still holds.

**Tests:**

| Test | Cases | Old scripts |
|---|---|---|
| `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveRemoteCollectorPureFunctions` | **changed:** `multiple_exact` (DNS, another URI and the expected URI) used to be asserted to pass; it now fails as `identity_mismatch`. New: legacy plus expected (fails, legacy present), expected twice (fails), DNS plus expected (passes) | **fails** at `multiple_exact` |
| `TestRemoteAlphaOperatorHealthcheckTLSStatusRequiresExactlyTheExpectedURISAN` (renew script, real certificates and OpenSSL) | expected plus another identity, legacy plus expected, expected twice, `operator/local-evil`; each fails with the right classification, count and blocker | **all four fail** |
| `TestRemoteAlphaOperatorHealthcheckTLSStatusDetectsValidOperatorCert` | adds `identity.uri_san_count = 1` | fails (no such field) |

The one changed assertion is the old test's statement of the "contains" rule that §3A now contradicts. The contract text changed with it. Test helper: `setupRemoteAlphaOperatorHealthcheckTLSFixture` and `remoteAlphaGenerateOperatorClientLeaf` now take several URIs. Existing callers pass one, as before.

## 3. O4-1 (re-audit, optional): CA certificate below an intermediate

`TestAuthenticateRefusesACACertificateBelowAnIntermediate` (`callerauth_mtls_test.go`) runs over a real mutual-TLS listener. A CA certificate with `spiffe://execution.internal/operator/local`, signed by an intermediate, is presented together with that intermediate. It gets `401`. This kills the re-audit's surviving mutant B09 by construction (the leaf rule must hold whatever the chain). Mutants M44 and M47 confirm it fails without the end-entity rule.

## 4. Validation on `30549d6`

All in this cloud container, Go 1.26.5, `GOTOOLCHAIN=local`, `GOFLAGS=-mod=readonly`, `GOPROXY=off`. "As `esci`" means `runuser -u esci -- env -i <script>`: no variable of my session reaches the tests (section 4.1 says which runs were not like that).

| Check | Result | Log |
|---|---|---|
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...` (as `esci`) | pass | `static-30549d6.log` |
| `gofmt -l` | the 33 `.go` files PR 27 changes: all formatted. Six files elsewhere are unformatted on `trunk_dev` `036d507` too, untouched here | `gofmt-30549d6.txt` |
| Race detector: `internal/callerauth/...`, the five API packages, `cgs/policy` (as `esci`) | pass | `race-unit-30549d6.log` |
| Race detector: the five mutual-TLS tests and the new expiry test, five app packages (as `esci`) | pass | `race-app-30549d6.log` |
| `ars/app`, `ags/app`, `egs/app`, `cgs/app` in full (as `esci`) | pass (`egs/app` includes the expiry test) | `apps-30549d6.log` |
| Root package, CI list of environment-only tests skipped (as `esci`) | pass, 151 s | `root-skip-30549d6.log` |
| Bring-up `TestBringupScriptUpCheckDownFullProfile` with this head's six service binaries (image `es-offline-cp:30549d6`, built offline; as `esci`) | **PASS** (35 s, not skipped) | `bringup-30549d6.log` |
| Mutants (`mutants.py`, 74: M01 to M60 of the check, S01 to S14 of the call sites and `id.conf`) | 73 killed. M03 survives as before (equivalent: an empty path is an empty segment, refused by the segment rule). The ten new ones, M51 to M60, are all killed, by the tests named in section 1 | `mutants5-summary.txt`, `mutants5.log`, `mutants5.log.json` |
| New tests on the old code (`1572c17` plus the three new test files) | the expiry test and the five operator-status tests named in sections 1 and 2 fail | `old-code-new-tests.log` |
| GitHub CI, this PR, head `30549d6` | **green**: run 45241862055, job 137928307746, every step success, completed 19:14Z; "all 16 listed tests still fail on this host" | `ci-30549d6.txt` |
| v2 manifest | `41090e09…d108`, two runs byte-identical | `manifest-v2-30549d6.json` |
| Trial merges | section 6 | `trial-merges.txt` |

### 4.1 How the runs were made, and a correction to 03-repair.md

- **First run of this validation was not clean.** I first started `repair5.sh` with `su esci -c`, which kept my session's environment. The bring-up then **skipped**: Nomad's AWS fingerprinter read `AWS_CA_BUNDLE` and could not open a root-only file. I threw that run away and reran everything with `runuser -u esci -- env -i`. All results in the table above come from the clean rerun. The thrown-away run's summary and skipped bring-up log are in `invalid-su-run/` so that nothing is hidden.
- **Correction to 03-repair.md.** Section 4 of that report says all runs were as `esci` "except where noted". Two were not, and were not noted. Its root-package run (`root-skip-1572c17.log`) was started with `su`, so my session's environment reached it (it passed). Its mutation run, like this one and the one in 01, ran as root in my session's shell. This report's old-code run did too. These are in-process unit and handler tests that start no containers and make no network calls.
- **Leak scan.** I scanned every file in `06-evidence/`, the thrown-away run and `03-evidence/` for the values of my session's credential variables and for common token patterns. No credential appears. The only match is my scratch directory's name, which contains the session's ID, inside file paths in the two mutation logs. That ID is not a credential.

## 5. Red-team items not fixed here, and the box check

| Item | Disposition (coordinator, 18:34Z) |
|---|---|
| R1, R3 | no finding |
| R2 | **fixed** (section 1) |
| R4: root guard misses `x509svid` reads and `Issuer` read through a variable | **follow-up PR**, not here. Suggested shape (red-team): type-aware guard with `go/types`. Flag `(*http.Request).TLS` reads outside `internal/callerauth`, forbid go-spiffe `x509svid` and `spiffeid` imports outside it, and match `Certificate.URIs` and `Issuer.CommonName` by type |
| R5 | **fixed** (section 2) |
| R6: ARS and AGS accept allowlist prefixes that ES refuses and that can never match | **follow-up PR**, not here: one shared prefix validator for ARS, AGS and ES (canonical path under `callerauth`'s segment rules, at least two segments) |
| N1 (red-team re-check, optional): a single URI SAN that itself contains a comma or a space passes both status tools; ES refuses it with `401` | **same follow-up PR as R4 and R6** (coordinator, 19:16Z): the tools read the URI SANs from the certificate's DER bytes instead of OpenSSL's text, not a regex patch. No security impact, ES fails closed. Scope recorded in `follow-up-pr-scope.md` |
| O2-2: bootstrap issuer matched by CN | open item, as recorded in 03-repair.md: separate PR after PR 27 lands, starting with the CA-bundle inventory |
| U1: live box client certificates | **box-deploy checklist**, below |

**Box-deploy checklist for PR 27 (U1).** Before PR 27's binaries are deployed to the Remote Alpha box, run this read-only check in the box session. For each client certificate file presented to an ES service, run:

```sh
openssl x509 -noout -ext subjectAltName,basicConstraints,keyUsage -in "$f"
```

- **Files:** `/etc/execution-substrate/tls/operator-client-cert.pem`, plus `ags-client-cert.pem`, `artifact-registry-client-cert.pem` and `execution-governance-client-cert.pem` in the TLS directories named at `scripts/internal/remote_alpha_es_service_tls_renew.sh:30-50`.
- **Pass:** each shows exactly one `URI:` and none of `CA:TRUE`, `Certificate Sign` or `CRL Sign`.
- **Also look at `notAfter`** (`openssl x509 -noout -enddate`). After this PR, a client whose certificate expires is refused on its next request, even on an open connection, where before it kept working until it reconnected. A certificate close to expiry should be renewed before the deployment.
- **Who runs it:** the same CA-bundle inventory session that O2-2 needs can collect this. The coordinator owns that script.

## 6. Overlap with other open PRs (re-checked on `30549d6`)

`git merge-tree` (`trial-merges.txt`):

- PR 12 and PR 28 (`2c8bf35`): one conflict, `PLANS.md`, unchanged in kind. Both add a first `## Status` entry; keep both.
- PR 26 (`a88467f`), PR 29 (`89da53d`), PR 30 (`0b8b9c0`): clean.

## 7. For the narrow re-audit and the red-team's confirmation

- **Read:** `1572c17..30549d6` (`delta-diff-1572c17-30549d6.diff`).
- **R2 checks:**
  - Does any request reach authorization without the time check? `Authenticate` is the only path, and the root guard keeps it that way.
  - Is "at least one chain that starts with the leaf" the right condition next to Go's handshake rules?
  - Is the inclusive `NotAfter` right? It matches `crypto/x509`'s `isValid`.
- **R5 checks:** does any other operator tool still read "contains" for the identity? I found only these two classification sites (`grep` for `URI:` and `matches_current_allowlist` in `scripts/`).
- **Rerun:** the red-team's `zz_redteam_expiry_test.go.txt` and `status_probe.py.txt` against `30549d6`.

## 8. Evidence (`06-evidence/`, `SHA256SUMS.txt`)

| File | What it is |
|---|---|
| `provenance.txt` | base, heads, trees, commits, manifest and delta digests, remote refs |
| `delta-diff-1572c17-30549d6.diff` | the delta to read (sha256 `448170b2…2c2f`) |
| `manifest-v2-30549d6.json` | v2 audit manifest of the head |
| `static-30549d6.log`, `static5.sh.txt` | build and vet (Linux and macOS), and the script |
| `gofmt-30549d6.txt` | gofmt, with the six pre-existing unformatted files traced to `trunk_dev` |
| `race-unit-30549d6.log`, `race-app-30549d6.log`, `apps-30549d6.log`, `root-skip-30549d6.log`, `bringup-30549d6.log`, `repair5.out`, `repair5.sh.txt` | the clean validation run and its script |
| `mutants.py.txt`, `mutants5-summary.txt`, `mutants5.log`, `mutants5.log.json` | mutation run |
| `old-code-new-tests.log` | new tests against the red-teamed head's code |
| `trial-merges.txt` | merge-tree results against PRs 12, 26, 28, 29 and 30 |
| `ci-30549d6.txt` | GitHub CI run, job and the end of its log |
| `invalid-su-run/repair5.out`, `invalid-su-run/bringup-skipped.log` | the thrown-away first run (section 4.1) |
