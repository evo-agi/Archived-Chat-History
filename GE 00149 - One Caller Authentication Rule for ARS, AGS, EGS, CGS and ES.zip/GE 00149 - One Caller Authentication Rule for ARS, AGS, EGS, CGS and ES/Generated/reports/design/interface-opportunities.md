# Where shared interfaces and patterns would simplify the code

Written 2026-11-23 by the thread "Find where shared interfaces would simplify code", at David's request of 14:40Z and the coordinator's brief. Read-only design review: no repository was changed, no branch or PR exists, no test was run, no subagent was used. Every size below is an estimate (Inference), not a measurement of a finished change.

## Plain-language summary for David

An "interface" here means one agreed shape for a job (for example "check who is calling", or "describe an agent runtime"), with the variants plugged in behind it. It pays off when the same job is hand-copied in several places and the copies have started to drift, or when adding one more variant means editing many files. It is over-engineering when there is only ever one variant.

What I found, best first:

1. **The five ES services each carry their own copy of "who is calling me?"** (reading the caller's certificate and its SPIFFE identity), and their own copy of the server's TLS setup. The copies have already drifted: one service accepts identities from any trust domain while the other four only accept `execution.internal`, one skips a safety check the others make, and no service rejects a certificate that names two identities. One shared module for *authentication* (who is calling), with *authorization* (what they may do) staying in each service, would remove the drift. It also lands exactly where the next big step (wiring reliable submit into the real submit path) needs it, because reliable submit wants the caller's full identity and today's code only extracts part of it. Security code, so it needs an audit and a red-team.
2. **Adding a new kind of agent runtime to ES means editing at least five Go files plus the config shape.** Today there are two hard-coded runtimes, and one of them is Codex-specific (64 "Codex" references in ES code, including fixed slots in the new reliable-submit storage formats). Your product thesis is "any vendor's agent". A small, code-defined catalogue of runtime profiles, with the config only switching them on and filling in their settings (the same shape you chose for the Maintenance Agent's notification channels), would make "add a vendor" one reviewable unit. This should be designed together with the reliable-submit integration, after PR 12/13 merge, because those PRs bake the Codex slot into storage formats.
3. **After PR 12 merges, ES will have two separate Nomad clients** with different security (the new one is pinned to one certificate on the local machine; the old one has no TLS settings at all). The fix is to retire the old one when reliable submit becomes the live path, not to put an interface over both.
4. **Found on the way, not an interface question:** on the live path ES does not re-check that the program bytes it gets from the artifact store match the fingerprint in the signed evidence. It trusts the store to have checked. By the current contract that is allowed, but it means a compromised store could swap what runs. One "fetch and verify" helper would close it. This is a contract decision for you and the coordinator.
5. **Maintenance Agent:** besides the channel work already under way, its box checks are wired by hand in three places that must stay in step. A small check catalogue would make that impossible to get wrong. Best done when Phase B (bounded restarts) starts, not in the PR under audit.

Where I recommend **not** to build anything: merging the three near-identical service-hardening scripts (one-shot scripts already run, with pinned outputs), merging the two signing packages (deliberately kept separate by the redesign rules), and anything in Infrastructure Manager (no commits since July, built for the retired Control Plane).

## 1. What was read

| Repository | Ref | SHA |
|---|---|---|
| Execution-Substrate | `origin/trunk_dev` | `200fd6097b43981ffae86e69500d1ab41b49a94c` |
| Execution-Substrate PR #12 head | `codex/reliable-submit-operational-handoff-v1` | `8058561edc08356c46680c204586b3c7796c0ff3` |
| Execution-Substrate PR #13 head | `claude/project-thread-sqldt7` | `d314590dad6f6e132a20c62e9fff671311e286fe` |
| Execution-Substrate PR #22 head | `claude/project-thread-k69qcw-collector-process-names` | `8ce6b739fa5f097e39dd73bd93a9ccac6c6b8811` |
| Execution-Substrate PR #25 head | `claude/project-thread-a9tcoa-spire-pin` | `a1623ac914f2f996d64eb2e8fd7d424d882b1dac` |
| Maintenance Agent | `origin/trunk_dev` (v1, being replaced) | `d60e0d27cab62a57453fb8f56027bbdea4601e6d` |
| Maintenance Agent PR #2 head (v2, reviewed instead of v1) | `claude/project-thread-jehrvw` | `69a710e2cbaebab0bd58f99bfc7514241e00639b` |
| Infrastructure-Manager | `origin/trunk_dev` | `e6080caf631cc22113f675068cf4335b321fa56d` |
| Governed-Execution-Coordinator (quick scan only) | `origin/trunk_dev` | `aa8104f5e152e322a0dbc0de11349f085b1d5c71` |

Unless a row says otherwise, ES paths and line numbers are at `200fd60`, MA paths at `69a710e`, IM paths at `e6080ca`.

Governing files read: ES `AGENTS.md` (whole), ES `PLANS.md` sections "Architecture-Defining Redesign Scope", Workstreams A and E, "Ordered Execution Plan", "Current Decision Rules", "Remote Alpha Hardening History and Current Retirement"; ES `.docs/system_overview/boundaries.md` section 11, `shared_kernel.md` (grep), `artifact_publication_storage.md` and `contracts.md` (grep for integrity and cross-check); MA `PLANS.md` (top 140 lines); IM `README.md` (top). The containment proposal and handoff under `reports/Execution-Substrate/tls-status-child-containment/`.

Where inspection stopped: ES non-test Go was read where candidates pointed (app, api, config of all five services; `es/admission` service, submit, lifecycle, runtimeprofile, producercontract, policy, policy_payload, mounts, authorityhandoff, reliable_submit_binding and its encoding); ES tests only by grep (121k lines not read); ES shell scripts measured, not read; ES Python collectors read in their process-supervision parts. MA v2 source read in checks, diagnose, runner, cycle, export, transport, deliver, config, install script. IM measured and grepped. Coordinator: one grep only. MA PART 20 (Channel interface) was not reviewed, by design.

## 2. Ranked recommendations

| Rank | ID | What | Pattern | Value | Risk | Size (Inference) | When |
|---|---|---|---|---|---|---|---|
| 1 | ES-1 | One caller-authentication and server-TLS module for ARS, AGS, EGS, CGS, ES | Shared concrete helper (not an interface) | High: removes drift in security code; D3 needs it | Medium: security code, guardrail tests pin `es/app` shape | Medium | Now, in parallel with PR 12/13 (no file overlap), or as D3's first step |
| 2 | ES-5 | Shared test certificate fixture for the five services' integration tests | Shared test helper (like `internal/testtmpdir`) | Medium: negative auth cases tested once for all | Low: tests only | Small | With or just before ES-1 |
| 3 | ES-2 | Runtime-profile catalogue (compiled-in profiles; config enables and parameterizes) | Strategy + registry, config-selected | High for the "any vendor's agent" thesis | Medium-high: preserved compatibility edge, durable formats | Medium-large | Designed with D3, after PR 12/13 merge |
| 4 | ES-4 | Verified fetch-by-digest for every ARS blob read | Shared helper; contract decision first | High (security) if the contract is changed | Low code risk; contract change | Small | Decide now; implement with or right after D3 |
| 5 | ES-3 | One Nomad client | Consolidation, no interface | Medium | Low if done inside D3 | Medium | Part of D3 |
| 6 | MA-1 | Box check catalogue | Registry of ordered check descriptors | Medium: closes a "keep three places in step" trap | Low | Small-medium | In the Phase B brief |
| 7 | ES-6 | Parity guard for the copied process-supervision code in the TLS collectors | Drift test, not a shared module | Medium (security hygiene) | Low | Small | After the containment PR lands |
| - | ES-7, MA-2..4, IM | Not recommended (section 5) | | | | | |

## 3. Execution-Substrate

### ES-1. One caller-authentication and server-TLS module

**Where (facts, at `200fd60`):**

- Caller identity from the client certificate, five copies: `ars/api/server.go:581-620`, `ags/api/server.go:120-162`, `egs/api/server.go:118-146`, `cgs/api/server.go:152-177`, `es/api/server.go:320-359`.
- Bootstrap-issuer rejection with the same response text, five copies: `ars/api/server.go:547-549` and `:568-570`, `ags/api/server.go:81-83`, `egs/api/server.go:82-84`, `cgs/api/server.go:41-43`, `es/api/server.go:272-274`.
- `matchesAuthorizedPathPrefix`, three identical copies: `ars/api/server.go:611-620`, `ags/api/server.go:153-162`, `es/api/server.go:350-359`.
- Server mTLS config `loadTLSConfig`, five identical copies (TLS 1.2 minimum, client cert required): `ars/app/app.go:124-146`, `ags/app/app.go:109-131`, `egs/app/app.go:126-148`, `cgs/app/app.go:96-118`, `es/app/app.go:111-133`. `Start`, `Shutdown`, `Addr`, `Started` near-identical in all five.
- Config: identical `HTTPConfig`, `TLSConfig`, `SecurityConfig` structs and the same strict `Load` (unknown fields refused, trailing data refused) in `ars/config/config.go:47-74`, `cgs/config/config.go:41-68`, `ags/config/config.go:66-92`, `egs/config/config.go:49-76`, `es/config/config.go:180-207`. The same strict decode already exists once as `internal/httpx/httpx.go:12-23`.
- `cmd/{ars,ags,cgs,egs}/main.go` are identical after renaming the service (63 lines each); `cmd/es/main.go` differs only in using `log.Fatalf`.

**Drift already present (facts):**

| Drift | Where | Effect |
|---|---|---|
| CGS accepts a SPIFFE ID from **any trust domain**; the other four accept only `spiffe://execution.internal/` | `cgs/api/server.go:170-177` vs e.g. `es/api/server.go:337-348` | Inference: bounded today, because CGS then requires the ID to equal the request's workload ID and to pass `id.conf` (`cgs/api/server.go:63-87`, `cgs/policy/idfile.go:336-354`), and the TLS client-CA pool limits issuers. Only EGS has a wrong-trust-domain test (`egs/app/app_integration_test.go:230`). |
| ARS does not check that the first verified chain is non-empty before indexing it | `ars/api/server.go:582-586` vs `ags/api/server.go:121`, `egs/api/server.go:119`, `cgs/api/server.go:153`, `es/api/server.go:321` | Inference: unreachable with Go's `crypto/tls` server, whose verified chains always start with the leaf. Still a copy that differs. |
| CGS skips the bootstrap check when its configured issuer CN is empty | `cgs/api/server.go:41` | None in practice: CGS config refuses an empty value (`cgs/config/config.go:101-103`). |
| No service refuses a certificate with more than one URI SAN; each takes the first URI with the right prefix | all five extractors | Inference from the SPIFFE X.509-SVID standard (one URI SAN per SVID; not verified in this repo): a non-conforming certificate would be read as whichever identity comes first. Needs a trusted CA to issue such a certificate. No test covers it. |
| The bootstrap CA is recognized by its issuer Common Name string | all five | Observation: if the bootstrap CA were reissued under another CN while still in the client-CA pool, bootstrap callers would pass. One shared place is where a stronger rule (issuer key) would go. |

**Why it matters now (fact + Inference):** PR 12/13's reliable submit derives its claim references from a full canonical caller URI (`es/admission/reliable_submit_identity.go:24-61` at `d314590`, `deriveReliableSubmitClaimRefs(canonicalSPIFFEURI, …)`). Today's HTTP layer extracts only the path after `spiffe://execution.internal/` (`es/api/server.go:337-348`). Inference: D3, wiring reliable submit into the real submit route, has to add a canonical full-URI extractor to `es/api/server.go`. If ES-1 exists first, D3 uses it; otherwise D3 adds a sixth variant.

**Proposed shape:** a small support package beside `internal/httpx` (name to be chosen, e.g. `internal/mtlsauth`) with plain functions, not an interface, because there is one implementation:

- `ServerTLSConfig(certFile, keyFile, clientCAFile) (*tls.Config, error)`;
- `CallerFromRequest(r) (Caller, error)` returning the canonical URI, trust domain, path and issuer, refusing zero or several URI SANs and any trust domain other than the configured one;
- `RejectBootstrapIssuer`, `PathHasPrefix`, and the exact current response texts as constants.

What stays service-local, on purpose: who may do what. ARS's writer path (`ars/api/server.go:23`, `:573`), EGS's fixed caller list (`egs/api/server.go:109-116`), CGS's `id.conf` match, ES's prefix list. That keeps authorization authority where `boundaries.md` puts it.

**Risks and costs:**

- Governance (fact): ES `AGENTS.md:74`, `:100`, `:150` and `PLANS.md:4183` ("Shared code requires explicit ownership and a concrete cross-service reason"). The reason here is concrete (one identity rule for one trust domain). Doc-first: add the package to the "Cross-cutting packages that are not service boundaries" table (`.docs/system_overview/boundaries.md:943-955`) before code.
- Frozen tests (fact): `es/admission/workstream_c_guardrails_test.go:2482-2512` counts field accesses inside `es/app/app.go:App.Start/Shutdown/Addr/Started`, and the same test keeps an inventory of production synchronization fields. Moving the server lifecycle changes both; the PR must update them deliberately, which is the point of those guards. `es/admission/reliable_submit_guardrails_test.go:860-864` pins three lines of `es/api/server.go`'s submit path; keep them. The exact 401/403 bodies are pinned by integration tests (e.g. `ars/app/app_integration_test.go:1114-1124`, `es/app/app_integration_test.go:243-252`).
- Behaviour changes (pinning CGS to the trust domain, refusing several URI SANs) must be separate, named commits with their own tests, not hidden in a refactor. Inference: the CGS change could affect callers whose `id.conf` entries use another trust domain; check `id.conf` examples first.
- Security code: product code into `trunk_dev`, so a fresh audit and a red-team under the project rules, and it counts toward David's first three product reviews.

**Size (Inference):** about 300 to 400 production lines removed across 15 files, 150 to 250 added, plus tests. One PR, or two (refactor with identical behaviour, then the two behaviour fixes).

**In-flight overlap (fact):** `git diff --name-only` of PR 12/13 (`d314590`), PR 22 (`8ce6b73`) and PR 25 (`a1623ac`) against `trunk_dev` touches none of `*/app/*.go` (non-test), `*/api/*.go`, `*/config/*.go` or `cmd/`. PR 25 adds only `es/app/spire_release_pin_test.go`. So ES-1 can run in parallel; it should merge before D3 starts.

### ES-2. Runtime-profile catalogue

**Where (facts):** the selection is a hand-written switch, `es/admission/runtimeprofile.go:33-72`, with two profiles: `static-script/default` and `control-plane-normal-shell/v1`. Adding a third touches at least:

- `es/admission/runtimeprofile.go` (switch, constants, env keys; the env keys are Codex-specific, `:15-19`);
- `es/config/config.go:122-138` and `:554-589` (one named struct field per profile, `runtime_profiles.control_plane_normal_shell`);
- `es/admission/producercontract.go:53-58` (hand-listed declarations);
- `es/admission/reliable_submit_binding.go:265-273` (allowlist of the two names);
- `es/admission/policy.go:231-237` and `es/admission/authorityhandoff.go:50-55` (default-name fallbacks);
- the authority handoff's Codex credential projection (`authorityhandoff.go`, `types.go:108`, `:143-156`).

`grep -i codex` finds 64 lines in 9 non-test files under `es/`. Two of them are durable formats: the reliable-submit binding has a dedicated `bindingCodexRecord` (`reliable_submit_binding_encoding.go:42`, `:321-332`) and the replay format stores five Codex credential fields at fixed positions (`reliable_submit_replay_format.go:254-258`, read back at `reliable_submit_replay_hydration.go:509-525`). Outside Go, 25 test files, 22 docs and 10 scripts name `control-plane-normal-shell`.

**Proposed shape:** each profile is one compiled-in descriptor (a Go interface or a struct of functions) that owns: its name, its config section and startup validation, `Resolve(artifact, config) → image, env, credential location`, its producer-contract declaration, and its binding-validity rule. A fixed list in code is the registry. **Config only enables and parameterizes a profile; it can never define a new one, its image, its env keys or its privileges.** That keeps the authority in reviewed code. It is the same shape David chose for the Maintenance Agent's channels (compiled-in implementations, a config list selects and parameterizes them).

**Why:** the product thesis (memo `strategy/es-coordinator-direction.md`, D1) is admitting any vendor's agent. Today "a vendor" is spread over the admission code and over two durable formats. Inference: the vendor-specific credential slot (`codexCredential`) is the part that will hurt most later, because durable formats need a version change to generalize.

**Risks:**

- Preserved compatibility edge (fact): `PLANS.md:3606` (A0 "does not change the runtime path, runtime-profile selection mechanism") and `PLANS.md:4192` (preserve `execution_substrate.runtime_profile` and `control-plane-normal-shell/v1` unless a coordinated plan is documented first). A catalogue that keeps every wire byte identical is a refactor, but it changes the selection mechanism's code, so it is doc-first under `AGENTS.md` section 7.
- Durable formats: generalizing the Codex slot is a format change (binding record and replay fields). That is a product decision, not a refactor.
- Config JSON key `runtime_profiles.control_plane_normal_shell` must stay accepted.

**Size (Inference):** medium to large. The refactor alone is medium; the vendor-neutral credential slot is a separate format decision.

**When:** after PR 12/13 merge, designed in the D3 brief. Both PRs change `reliable_submit_binding.go` and the replay format family, and PR 12 adds a durable operational-handoff schema. **Decision point for the coordinator and David, before D3 makes these formats live state:** should the authority handoff carry a vendor-neutral "agent credential location" tagged by profile, instead of a Codex slot? Changing it before live data exists is cheaper than a migration after.

### ES-3. One Nomad client (consolidate; no interface)

**Facts:** `trunk_dev` has one Nomad client, `nomadClient` (`es/admission/submit.go:26-30`, `:237-287`; `lifecycle.go:271-444`), configured only by `base_url`, `datacenter`, `timeout_seconds` (`es/config/config.go:108-112`; no TLS settings). PR 12 adds a second one, `operationalProvider` (`es/admission/reliable_submit_operational_provider.go:333-354` at `d314590`), loopback-only, with a certificate pool and a pinned server key (`:342-353`, `:469`). After PR 12 merges, ES will have two Nomad clients with different security postures. Nomad-shaped types (`nomadAllocationDetail`) also reach `results.go:83`.

**Recommendation:** when D3 makes reliable submit the live path, retire the legacy submit client and route status, logs, cancel and results through the pinned client. Candid: do **not** add an "execution backend" interface now. There is one scheduler, and Unknown whether a second is planned; an interface over one implementation adds indirection without a second user. If a second scheduler is ever chosen, the seam is where the operational provider's `project`/`register`/`observe` methods already are.

**When:** inside D3. Doing it earlier would collide with PR 12/13.

### ES-4. Verified fetch-by-digest (security observation, then a helper)

**Facts:**

- ARS serves raw bytes for both `:bytes` and `:json` with a `Content-Digest` header (`ars/api/server.go:282-333`) and re-verifies on read (contract: `.docs/system_overview/contracts.md:345`).
- On the live path ES does not hash what it fetched: primary payload (`es/admission/submit.go:129-166`), mount payloads (`mounts.go:239-251`), the admission-policy payload (`policy_payload.go:77-93`) and the workload-zone Vault config blob, which carries the Vault address and CA bundle (`service.go:662-697`). The only hashing sites outside reliable-submit code are listed by `grep -n 'Sum256\|sha256.New\|digestBytes('`; none is on these reads.
- The reliable-submit binding does hash the primary and mount payloads (`reliable_submit_binding.go:279-282`, `:351-362`), but it is "deliberately runtime-unwired" on `trunk_dev` (`:132-133`).
- The contract places byte integrity with ARS: "ARS stores and re-verifies those bytes by digest, and ES later consumes payload bytes only through an explicit payload reference and cross-check" (`.docs/system_overview/artifact_publication_storage.md:135`); the cross-check is of references, not bytes (`contracts.md:748`). The evidence record itself is signature-checked; the payload digest is inside it.

**Inference:** the signed chain ends at `payload_digest`; the last hop, bytes for that digest, rests on ARS. A compromised ARS (its own service user, `ars:ars`, per `PLANS.md` Remote Alpha section) could hand ES different bytes for a signed digest, and ES would stage and run them. Guess on likelihood: needs ARS compromise; not tested.

**Proposed shape:** one helper, `fetchVerifiedBlob(ctx, digest, limit)`, that reads within the limit, hashes, and refuses a mismatch; every ARS blob read goes through it. D3 will route the primary and mount payloads through the binding check anyway, but the policy payload and the Vault config blob would stay unverified without this.

**Risk:** a contract change ("ES verifies bytes end to end"), so doc-first; small code. **This is a decision for the coordinator and David**, flagged separately from the interface work.

### ES-5. Shared test certificate fixture (tests only)

**Facts:** `newTLSFixture`, `createCertificateAuthority`, `createLeafCertificate` exist in each of the five `*/app/app_integration_test.go` files, in 5, 3 and 5 differing variants; `mustReadBody` has 5 copies in 4 variants; `startTestApp` 3 copies in 3 variants. A shared test-only package has a precedent: `internal/testtmpdir`.

**Value:** with ES-1, the negative cases (foreign trust domain, two URI SANs, no URI SAN, bootstrap issuer) can be one table run against all five services. Today only EGS tests a wrong trust domain.

**Policy:** a tests-only PR merges without David's review under the merge policy, after audit and gate.

### ES-6. Process-supervision code copied across the TLS collectors

**Facts:** `run_fixed`, `reap_child`, `read_pipe_chunk` and `PipeReadResult` exist in two or three of `scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive.py`, `scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py` and `scripts/internal/remote_alpha_es_tls_status.py`; only `PipeReadResult` is identical, the functions differ (e.g. `run_fixed` is 25 lines in one and 164 in the other). A shared Python module is not possible as things are: each remote collector is shipped as one file whose digest is checked, or streamed over SSH stdin (`scripts/remote_alpha_operator.sh:298`, `:676`, `:1866`, `:1882`).

**The open question:** the containment decision (own PID namespace with an anchor, handoff `reports/Execution-Substrate/tls-status-child-containment/02-handoff.md`) changes only `remote_alpha_es_tls_status.py`. The noninteractive remote collector runs its fixed children with `start_new_session=True` (`..._noninteractive_remote.py:236`) and cleans up by process-group signals (`:125-181`), the method the proposal measured as escapable by a child that leaves the group. Unknown whether that matters for this collector's fixed commands (`openssl`, `sha256sum`, `stat`, `sudo -n`); the containment thread is the right one to say.

**Proposed shape:** not a library. A small drift test (Go, like the other script tests) that extracts the named supervision functions from each collector and either asserts they match or asserts a declared list of intended differences. That is a machine-enforced trigger: a security fix made in one copy fails the test until the others are fixed or the difference is declared.

**When:** after the containment PR merges, since it rewrites these functions.

## 4. Maintenance Agent (v2, PR #2 head `69a710e`)

Context (fact): PR #2 replaces v1 wholesale (161 files changed against `d60e0d2`), is at checkpoint 17 "audit of the fifth repair" (`PLANS.md:62-92`), and the notification Channel interface (PART 20) is being built in it by another thread. I did not review or duplicate that.

### MA-1. Box check catalogue (for Phase B)

**Facts:** each check's name is a string that must agree in several places: the guarded call in `take_snapshot` (`src/maintenance_agent/box/checks.py:501-560`), the error-prefix to incident-class map `_unknown_from_errors` (`box/diagnose.py:444-460`), the per-check failure counter and severity (`diagnose.py:411-442`), and the findings builder called by hand in `diagnose` (`diagnose.py:462-517`). The tests enumerate the names by hand (`tests/test_audit_findings.py:353-361`, `tests/test_repair_findings.py:404-405`). If a new check's errors are not mapped in `_unknown_from_errors`, Inference: a check that cannot run would not protect its open incidents, the "unknown is not healthy" rule the audits fixed (B50-B54).

**Proposed shape:** an ordered list of check descriptors (name, run function, the incident classes it protects, findings builder), with one parametrized test over the list so every registered check is proven to protect its classes. Keep it ordered and explicit: the Vault check depends on the unit findings (`diagnose.py:486-490`) and the certificate scan runs last on purpose (`checks.py:543-552`), so a flat plug-in registry would be wrong.

**When:** in the Phase B brief (bounded restarts add per-class recovery actions, which fit the same descriptor). Not in PR #2: any change re-opens its audit.

## 5. Not recommended, with reasons

| Candidate | Facts | Why not |
|---|---|---|
| ES: one parameterized script for `remote_alpha_harden_{ags,ars,egs}_service.sh` | 1,030 / 1,401 / 1,774 lines; after renaming the service, 515 to 770 shared unique lines per pair (about 80%) | They are landed one-shot hardening scripts whose host-local summary and evidence shapes must be preserved (`PLANS.md` "Remote Alpha Hardening History and Current Retirement"), each pinned by its own test file. `PLANS.md:4163` puts script cleanup after the core contracts. High risk for little gain. |
| ES: merge `ags/sign` and `egs/sign` | Same Ed25519 key loading in both | Workstream A deliberately excised the historical shared signing kernel (`PLANS.md` Workstream A; `shared_kernel.md`). Sharing key parsing would re-open that question for no functional gain. |
| ES: error helpers | 82 `&Error{…}` literals in `es/admission` | Codes and messages are public contract; a helper saves typing, not risk. |
| ES: an "execution backend" interface | One scheduler | See ES-3: consolidate, do not abstract. |
| MA-2: box/Mac wire constants in one place | `EXPORT_SCHEMA` in `box/export.py:20` and `mac/transport.py:24`; `MAX_KEY_CHARS` in `box/diagnose.py:64` and `mac/transport.py:46` | Duplicated on purpose: the Mac install ships only `__init__.py`, `common.py` and `mac/` (`deploy/mac/install.sh:73-76`). Already guarded: a parity test (`tests/test_repair2_findings.py:1081`) and real box-export-to-Mac round trips (`tests/test_redteam_findings.py:142`). |
| MA-3: one subprocess runner | Three wrappers: `box/runner.py:105-135`, `mac/transport.py:173-231`, `mac/deliver.py:98-122` | Each has a different policy (allowlisted fixed shapes on the box, streaming bound for SSH, app environment for the notifier). Observation: the box runner reads all output then truncates (`runner.py:115-135`); harmless for its four allowlisted commands (`:78-93`). |
| MA-4: shared config validators | `_int` and the unknown-key check in both `box/config.py:100-165` and `mac/config.py:172-208` | A few lines; the two configs ship to different machines. |
| IM: shared coercion helpers | `_mapping` 8 identical copies; `_string` 5 copies in 3 variants (some return `""`, some `None`); `_cp_check_statuses` 2 copies | IM has had no commit since 2026-07-26 (`e6080ca`), and it serves the retired Control Plane flow. If IM gets new work, start with a `util/coerce.py`. Its adapters have one implementation each, so no interface. |
| Cross-repo shared library (ES, MA, IM) | Each repo has its own bounded command runner | Separate deployment units with their own custody rules (single-file collectors, Mac-only install set). Share patterns, not code. |
| Coordinator | Pattern-heavy value types (`__post_init__` 197 definitions, `__reduce__` 42) | Deprioritized; one grep only; nothing egregious seen at that depth. Not assessed. |

## 6. Order against in-flight work

| Item | Conflicts with | Order |
|---|---|---|
| ES-1, ES-5 | None by file (checked) | Can start now; merge before D3 starts |
| ES-2 | PR 12/13 (binding, durable formats) | Decide the credential-slot question before D3; build in or right after D3 |
| ES-3 | PR 12 (adds the second client) | Inside D3 |
| ES-4 | PR 13 touches `service.go`, `resolved_execution_plan.go` | Contract decision now; code with D3 |
| ES-6 | Containment PR (rewrites `run_fixed`) | After it merges; ask that thread now about the second collector |
| MA-1 | MA PR #2 under audit | Phase B brief |

## 7. Items for the coordinator to route

1. ES-4 is a contract question (ES verifies blob bytes end to end, or keeps trusting ARS). Recommendation: verify, because admission under the D1 thesis should hold even if the store is compromised.
2. ES-2's credential slot: decide before D3 whether the durable formats keep a Codex-specific slot or carry a vendor-neutral one.
3. ES-6: ask the containment thread whether `scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py` needs the same containment.

## 8. Confidence

- Facts (paths, line numbers, counts, SHAs): high; each was read or grepped at the SHAs in section 1.
- Drift effects and the ES-4 threat: Inference, stated as such; not tested.
- Sizes: Inference from line counts; no change was attempted.
- Not covered: ES tests beyond grep, ES shell scripts beyond measurement, the MA Channel design, the Coordinator.
