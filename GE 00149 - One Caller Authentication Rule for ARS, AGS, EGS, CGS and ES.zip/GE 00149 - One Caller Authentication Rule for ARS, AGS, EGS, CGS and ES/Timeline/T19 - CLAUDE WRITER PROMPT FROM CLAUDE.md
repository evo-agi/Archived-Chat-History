The red-team of PR #27 (head 1572c17) accepts: /mnt/project-files/reports/Execution-Substrate/caller-identity/05-redteam.md. My decisions:
- R5: fix it in this PR. The operator status script must fail on certificates with more than one URI SAN, with tests.
- R2: also fix it in this PR, since it's a few lines in callerauth and correctness comes first. Expired client certificates must stop being accepted on long-lived connections. Use the red-team's probe as the regression test.
- R4 and R6: record them as a follow-up PR; not here.
- U1: add the red-team's read-only check to the box-deploy checklist in your report.
Then send the delta to the same auditor thread (cmsg_01Un4xQgjBAczV8DABQvcLrxAbRwFSfd9kriuEXVCRE273) for a narrow re-audit, and to the red-team thread (cmsg_01Un4xQgjBAczV8DABQvcLrxTpTStSzkMxSUSKAkMUBfkK) to confirm R2 and R5 are closed. After that comes David's review.
