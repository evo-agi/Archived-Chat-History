Unify ES caller identity check
