The interface scan is done. Two picks are worth acting on. ES's "who is calling me?" check is copied five times and the copies have drifted: one service accepts identities from any domain. That's a real security gap, so I'm having it fixed as one shared check. The second pick is a runtime catalogue to replace Codex being hard-wired in 64 places. It fits the "any vendor's agent" goal and gets designed with the reliable-submit integration. The scan recommends leaving IM and a few other spots alone.

One decision for you: ES trusts the artifact store for the program files it fetches and doesn't re-check them against their signed fingerprint. The contract allows this. I recommend ES verify them itself. Yes or no?

STATUS: NEEDS DAVID (yes or no on verifying fetched program files)
