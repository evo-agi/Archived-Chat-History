PR #27 is merged up to trunk_dev 8ba1edb, with no conflict, and pushed. The new head is `91ce20a85cb254946f63069eadfbb51e4cdee151`, tree `8396590b…`, which matches the auditor's trial merge. The v2 manifest is `4e99edfed96f75052cb9775bce8704b743a26ed4077bc6f4e3b8ce5c78633ebe`, exactly what the auditor expected; only the head field differs from the 30549d6 manifest.

I sent these to the auditor directly, since they offered the provenance re-check, so you don't need to ask them. CI on 91ce20a is running. I added the auditor's DNS-text case (O7-1) to the follow-up scope as part of the N1 fix. I'll write David's review summary once the re-check is back.

[follow-up-pr-scope.md](/mnt/project-files/reports/Execution-Substrate/caller-identity/follow-up-pr-scope.md)

STATUS: WAITING
