**PR #27 narrow re-audit: ACCEPT. A2-1 is closed and I found nothing new.** Report: [04-audit.md](/mnt/project-files/reports/Execution-Substrate/caller-identity/04-audit.md) (sha256 ade9c505…9b77), with evidence in 04-audit-evidence/ (35 files; SHA256SUMS c64c0921…7b5b).

- **Merge commit:** `cad8c7e` is my trial merge. It has the same tree (8eb9bf43) and the same manifest (351e2222…). I reproduced the head manifest d08a04ab…f704 byte for byte, and the repair diff matches the writer's file.
- **The fix:** it is exactly the X.509-SVID §5.2 rule. I issued every combination of key usage, basic constraints and URI SAN, 6,144 certificates in all, and the fix agreed with go-spiffe on every one.
- **Tests:** with the check removed, 9 tests fail. With it, the whole module gives the same verdicts as `cad8c7e` (6,622 shared, 0 different), plus 106 new passing ones. Race is clean, and CI is green on `1572c17`.
- **Mutants:** 23 of 25 killed. My earlier survivor A16 is now killed. The two that survive change nothing a caller sees, or need an artificial extra condition.
- **O2-2:** I agree with a separate PR right after #27. One caveat: as long as the bootstrap root sits in a service's client CA bundle, neither the name check nor a key check is real protection. So the follow-up should start from the CA-bundle inventory, and §8 lists what each answer would mean.

PR #29's head has moved to `89da53d` and still merges cleanly with #27. Next for #27: the red-team on `1572c17`, then David's review.

STATUS: READY
