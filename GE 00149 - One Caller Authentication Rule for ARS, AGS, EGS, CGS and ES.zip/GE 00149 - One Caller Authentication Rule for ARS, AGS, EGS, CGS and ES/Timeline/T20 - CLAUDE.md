Nothing new needs you beyond approving the instructions. Here's where the rest stands.

**Done**
- [Archive chat history for merged PRs](#cmsg_01Un4xQgjBAczV8DABQvcLrxC3VaA72iRef2T27NaZhX8n): the first two catch-up archives are on GitHub (the macOS test fix and Linux CI), and nine more follow.

**Still working**
- [Unify ES caller identity check](#cmsg_01Un4xQgjBAczV8DABQvcLrxSur3j55KaQPi35fYZ1Dng6): the red-team accepted it. Two small fixes go in first, one being that expired certificates must stop working on busy connections. Then it comes to you for review.
- [Make ES verify fetched program files](#cmsg_01Un4xQgjBAczV8DABQvcLrx671PBLg8CxiSYsLRAYo6fD): the re-audit found that a compromised registry could swap in a different mounted file. A six-line fix is going in now.
- [Finish maintenance agent fifth repair](#cmsg_01Un4xQgjBAczV8DABQvcLrxXXZRTbEtdbvV8c4236YR2V): the audit accepted the main fix, with one missing test and some wording to correct before merge.
- [Lock Nomad so only ES can submit](#cmsg_01Un4xQgjBAczV8DABQvcLrx7qaBgesL513RdQXm7D49pW): repairing three CI test setups before its audit continues.

STATUS: waiting on your OK to apply the new instructions; everything else is moving.
