I've added the O2-2 decision to [03-repair.md](/mnt/project-files/reports/Execution-Substrate/caller-identity/03-repair.md) as an open item: a separate PR right after PR 27 lands, starting with a read-only inventory of the box's CA bundles, with the script going through the coordinator. Only sections 5 and 7 changed, so the report's sha256 is now `76c693ca…1db3` (it was `02f2ad7e…26e2`). The code, evidence and PR head `1572c17` are unchanged.

STATUS: WAITING
