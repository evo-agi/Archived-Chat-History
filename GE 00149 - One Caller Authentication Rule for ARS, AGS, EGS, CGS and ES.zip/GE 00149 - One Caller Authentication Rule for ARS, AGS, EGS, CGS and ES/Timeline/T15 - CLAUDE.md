The caller-identity fix (PR 27) passed its re-audit, so I'm starting its red-team now.
