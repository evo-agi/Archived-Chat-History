The caller identity check is now one shared package used by all five ES services. Draft [PR #27](https://github.com/evo-agi/Execution-Substrate/pull/27) targets trunk_dev at `6e2d2dc` with green CI. The report is [01-implementation.md](/mnt/project-files/reports/Execution-Substrate/caller-identity/01-implementation.md).

**What it fixes.** On the old code, every service accepted a certificate carrying two identities and used the first one it liked. CGS accepted callers from any trust domain; in one test, old CGS answered `allowed:true` to a caller from `other.internal`. Malformed IDs, such as a trailing slash or `..`, got past the allowlist at ARS, AGS and ES. ARS panicked on an empty certificate chain. All of these now get `401` everywhere. Callers with normal certificates are not affected, and the response texts are the same. Each service still decides on its own who may use which route.

**The CGS question.** Accepting any trust domain was not a documented contract: the docs don't say it, no test pinned it, and every `id.conf` in the repo uses `execution.internal`. So I closed it instead of stopping. This is my judgment, and the report flags it for the audit and for David.

**Validation:**
- The new per-service tests fail on the old code at all five services.
- The full test gate in the cloud failed the same 48 cases on this head and on trunk_dev. All 48 come from missing tools in the container. Nothing new fails.
- Bring-up passes with this PR's own service binaries.
- Race detector is clean, and a 60-second fuzz run against go-spiffe found no disagreement.
- Mutation testing caught 56 of 57 changes. The one that survived makes no difference to behaviour.
- The v2 audit fingerprint of this head is `faf35459…a638`.

**Overlap with PR 12/13:** the only conflict is in `PLANS.md`, where both add a new Status entry. A trial merge with PR 13 builds, and its tests and guardrails pass.

**Found along the way:** an outside-observer protocol, written but not yet wired, uses identities in another trust domain (`governed-execution.local`). If it ever calls an ES service, the new rule will refuse it until the contract is changed on purpose.

Next: a fresh audit and a red-team, then David's review, since this is product code. I'm watching the PR.

STATUS: WAITING
