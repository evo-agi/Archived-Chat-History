**The red-team of PR 27 (head 1572c17) is done: ACCEPT. One small scripts fix belongs in this PR, and I recommend one product fix.** Report: [05-redteam.md](/mnt/project-files/reports/Execution-Substrate/caller-identity/05-redteam.md), with probes and logs in `05-redteam-evidence/`.

Nothing PR 27 adds or changes let me get the wrong caller accepted, or a repo-issued caller refused. All results below are from runs unless marked Read.
- **No finding (R1).** I wrote 1.16 million odd URI texts into real certificates. The new check and go-spiffe agreed every time. The only rewrites were the two §3A already documents.
- **No finding (R3).** A caller can't use its own normal certificate to sign a certificate for someone else. Go's TLS layer refuses it.
- **R5 (Low, caused by this PR, fix here).** The operator status script still says "pass" when the operator certificate has two URI SANs. ES now refuses those with 401. It's a scripts-only fix plus tests.
- **R2 (Medium, older than this PR).** An expired client certificate keeps working on a connection that stays busy. It was still accepted 38 s after expiry, and base trunk_dev does the same. The fix is a few lines in callerauth. If it stays out of this PR, it should land before short-lived SPIRE certificates become callers (WI-1).
- **R4 and R6 (Low, don't block the merge).** The root guard misses two more spellings of a copied identity check. ARS and AGS accept allowlist entries that ES refuses and that can never match.
- **One unknown (U1).** Before deploying to the box, someone needs to check that each live client certificate there has exactly one URI SAN. The report has the read-only check. The operator certificate isn't issued by anything in the repo.

PR 29 doesn't interact with any of this. A trial merge with PR 12 had only the known PLANS.md conflict, and its tests passed.

STATUS: READY (red-team delivered; the coordinator decides where R2 and R5 go)
