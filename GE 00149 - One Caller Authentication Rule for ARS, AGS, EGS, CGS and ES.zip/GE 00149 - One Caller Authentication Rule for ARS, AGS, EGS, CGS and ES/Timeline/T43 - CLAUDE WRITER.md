PR #27 is merged into trunk_dev as **`76c030fa7872dd22dda731591878ef284c01bd9b`** (squash). Its tree is `8396590b…`, exactly the audited one.

Merge gate on `91ce20a`, all passed just before merging:
- the head was unchanged;
- trunk_dev was still `8ba1edb`;
- the v2 manifest re-taken now is `4e99edfe…3ebe`, identical to the audited one;
- CI run 45248632968 is green;
- there are no review threads.

One flaw in the squash commit message: the `Co-Authored-By` line came out with `&lt;`/`&gt;` instead of `<`/`>`, because I escaped them by mistake. GitHub won't link the co-author. Fixing it would mean rewriting trunk_dev history, which isn't allowed. The code and the tree are unaffected. I saved the lesson to memory.

Next, I'm starting the follow-up PR from follow-up-pr-scope.md: R4, R6, and N1 with O7-1.

STATUS: WORKING
