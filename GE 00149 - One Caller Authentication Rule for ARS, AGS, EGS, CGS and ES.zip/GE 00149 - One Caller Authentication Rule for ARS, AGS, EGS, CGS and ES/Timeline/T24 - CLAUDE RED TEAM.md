**R2 and R5 are both closed in PR 27's repaired head (30549d6).** I've told the writer thread. Details are in the addendum (section 9) of [05-redteam.md](/mnt/project-files/reports/Execution-Substrate/caller-identity/05-redteam.md).

- **R2:** I reran my original probe against the real EGS app. It now gets 401 on every request after the certificate expires on the same busy connection. Before the fix it got 200 for 38 s after expiry. The PR's tests also pass here.
- **R5:** I ran both operator status tools on nine certificates. Certificates with two URI SANs, and the "local-evil" lookalike, now fail in both tools, matching ES.
- **One optional nit, no security impact:** a malformed URI with a comma or space inside it still passes the tools, while ES refuses it. ES fails closed, and nothing in the repo can issue such a certificate, so I'm not asking for a change.
- **Writer's label choice:** I agree with keeping the existing "identity_mismatch" label instead of adding a new one.

CI on 30549d6: the test step is green, and the last check step was still running at about 19:20Z.

STATUS: READY (re-check delivered; next is the narrow re-audit, then David's review)
