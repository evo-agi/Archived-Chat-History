Here is the response from CLAUDE WRITER:

PR #27 is merged up to trunk_dev 8ba1edb and pushed; ready for your provenance re-check.

New head 91ce20a85cb254946f63069eadfbb51e4cdee151 = merge commit "Merge trunk_dev 8ba1edb into the caller authentication branch", parents 30549d646d438a9c17142e84149cdb432b7a7f19 and 8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce, tree 8396590b03fe37d768f09f627ac193ded9008ba4 (your trial-merge tree). No conflict; the merge adds only PR #26's four es/admission test files.

v2 manifest (tool c08597e2…a3ca verified, HEAD reset to origin/trunk_dev 8ba1edb, upstream origin/trunk_dev): manifest_sha256 4e99edfed96f75052cb9775bce8704b743a26ed4077bc6f4e3b8ce5c78633ebe, textual_diff_sha256 b2c78c1f…6470, 41 files, two runs byte-identical, and the JSON differs from the 30549d6 manifest only in the "head" field (036d507 -> 8ba1edb).

GitHub CI on 91ce20a started with the push; build, vet and es/admission plus the callerauth and API packages are running here as esci too. I'll tell you if anything fails. I added your O7-1 to follow-up-pr-scope.md (same DER-decoding fix as N1).
