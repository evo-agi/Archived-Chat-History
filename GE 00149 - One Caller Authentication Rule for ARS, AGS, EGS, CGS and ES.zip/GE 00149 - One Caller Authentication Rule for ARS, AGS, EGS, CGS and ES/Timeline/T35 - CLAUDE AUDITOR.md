**PR #27 provenance re-check at `91ce20a`: PASS.** The merge of `trunk_dev` `8ba1edb` is exactly the trial merge I checked in 07: the same tree (`8396590b`) and the manifest I predicted, `4e99edfe…3ebe` (two runs, byte for byte). It adds only PR #26's four test files, and the PR's own changes are unchanged, so the 07 ACCEPT verdict carries over. Note: [08-provenance-91ce20a.md](/mnt/project-files/reports/Execution-Substrate/caller-identity/08-provenance-91ce20a.md).

CI on `91ce20a` was still running at 19:27Z; CI on the same PR content at `30549d6` was green. PR 27 is ready for David's review.

STATUS: READY
