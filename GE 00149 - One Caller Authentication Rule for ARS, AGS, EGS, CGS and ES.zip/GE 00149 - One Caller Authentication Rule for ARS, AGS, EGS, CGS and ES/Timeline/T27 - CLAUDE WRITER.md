R2 and R5 are fixed in PR #27, now at `30549d6`, and the red-team has confirmed both are closed. GitHub CI is green and every check I ran here passes. The narrow re-audit is still running. After that, David reviews.

- **R2:** callers are now checked on every request, not only when the connection opens. Once a client certificate expires, the next request on an already open connection gets `401`. The red-team's probe is now a regression test against the real EGS app. It fails on the old code and passes now.
- **R5:** both operator status tools now pass only when the expected identity is the certificate's only one. The renew script also stopped matching by substring, so `operator/local-evil` no longer passes.
- **U1:** the red-team's read-only `openssl` check is now the box-deploy checklist in the report (§5). I added a check for certificates close to expiry, since after this PR those get cut off mid-connection.
- **R4 and R6:** recorded as a follow-up PR.

**Your call: the red-team's optional nit N1.** If a certificate's single identity contains a comma or a space, both status tools say "pass" while ES refuses it. ES is the safe side, and OpenSSL configs can't produce such a certificate. The regex tweak the red-team suggests doesn't fix every case. A full fix means reading the certificate's raw bytes. I recommend adding that to the R4/R6 follow-up PR rather than patching the regex here.

Correction to my 03 report: its root-package run and mutation run did not have a clean environment, though it said they did. The report explains this in §4.1. No secrets reached any log.

[06-repair.md](/mnt/project-files/reports/Execution-Substrate/caller-identity/06-repair.md)

STATUS: WAITING
