[PR 27](https://github.com/evo-agi/Execution-Substrate/pull/27) is ready for your third and last product review. It replaces five drifted copies of ES's "who is calling?" check with one shared check. That closes gaps that let through foreign-domain callers, certificates with two identities, a CA posing as a caller, and expired certificates on open connections. Three audits and a red-team passed, all findings are fixed, and CI is green. The five-minute summary is attached. Approve the merge, or ask anything first.

Also done: PR 12 is back in sync with trunk_dev, and its Fable red-team has started.

STATUS: NEEDS DAVID (approve the PR 27 merge)
