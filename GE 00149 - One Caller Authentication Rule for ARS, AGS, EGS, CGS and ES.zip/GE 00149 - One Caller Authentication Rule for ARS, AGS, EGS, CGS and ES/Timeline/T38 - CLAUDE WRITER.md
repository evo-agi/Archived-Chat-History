**David, PR #27 is ready for your approval to merge into trunk_dev.** This is your third and last product review. The five-minute summary is attached. Here is the short version.

**What it does:** the five ES services (ARS, AGS, EGS, CGS and ES itself) each had their own copy of the "who is calling?" check, and the copies had drifted apart. Now there is one shared check, written down once in the contracts.

**What it fixes:** the drifted copies let these through:
- callers from a foreign trust domain (CGS only);
- certificates carrying two identities;
- oddly spelled identities;
- a CA certificate posing as a caller;
- an expired certificate on a connection kept open.

The operator status tools also said "pass" for certificates that ES refuses. Normal callers see no change.

**How it was checked:**
- three audits, all accepted (the one problem found was fixed);
- one red-team, whose two findings were fixed and confirmed;
- tests that fail on the old code and pass now;
- 73 of 74 deliberate breakages caught (the miss makes no visible difference);
- CI green on the final head `91ce20a`.

**Deferred:** a follow-up PR with three low-severity items, none of which lets a wrong caller in. Then a PR to recognise the bootstrap certificate authority by its key instead of its name.

**One thing before box deployment:** a read-only check of the box's client certificates.

Reply "approve PR 27" or ask anything. I won't merge before your go.

[09-review-summary.md](/mnt/project-files/reports/Execution-Substrate/caller-identity/09-review-summary.md)

STATUS: NEEDS DAVID
