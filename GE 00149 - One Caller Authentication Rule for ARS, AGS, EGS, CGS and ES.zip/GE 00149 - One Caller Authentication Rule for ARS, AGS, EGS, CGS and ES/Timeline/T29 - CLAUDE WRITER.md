N1 is now part of the follow-up PR's scope, recorded in three places. There is a new scope file listing R4, R6 and N1 together. The 06 report's §5 table has an N1 row. PR #27's description lists the follow-up PR with all three items. I'll start that PR as soon as #27 merges. Nothing in #27 changed, and the narrow re-audit is still running.

[follow-up-pr-scope.md](/mnt/project-files/reports/Execution-Substrate/caller-identity/follow-up-pr-scope.md) · [06-repair.md](/mnt/project-files/reports/Execution-Substrate/caller-identity/06-repair.md)

STATUS: WAITING
