David merged #43. Go ahead and sync #42 and merge it.
