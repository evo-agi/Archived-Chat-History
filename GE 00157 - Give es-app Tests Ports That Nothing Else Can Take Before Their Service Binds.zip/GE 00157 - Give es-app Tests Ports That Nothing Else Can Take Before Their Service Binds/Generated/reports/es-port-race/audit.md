# Audit: ES PR #42, port allocator for es/app tests

Auditor: read-only audit thread, 2026-11-24 00:09Z to 00:20Z. Nothing pushed, no PR comment.

**Verdict: ACCEPT.** No findings. Merge after CI is green. The bring-up test that failed on #37 runs only in CI, and run job 138112101466 on `9696b93` was in progress at 00:11Z.

## Target

- PR: evo-agi/Execution-Substrate #42.
- Base and head: base trunk_dev `42db33920d9a402e28f4f7c2344c66d8f1115215`, head `9696b93264a490db5b521f5655d2fd19de52d813`. That is one commit, and the base is its ancestor.
- Files: `es/app/test_ports_test.go` (new, 224 lines), `es/app/operator_scripts_integration_test.go` (+62 −2), `es/app/submit_integration_test.go` (−19).
- Provenance: the writer reported no manifest. I took a base-relative v2 manifest from a fresh clone, with the recipe hash verified first. I took it twice and got identical results: `ea34b27c4b74c783ed57c516a7c4a325fa4878d40e08b3709c813ce7037244a4`, textual_diff `32397d0c…0ff0`, 3 entries. Every committed blob matches its entry (`audit-evidence/manifest-9696b93.json`).

## Allocator (`test_ports_test.go`)

| Check | Result |
| --- | --- |
| Range 10000–19999 | Correct. `[10000, 20000)` lies below Linux's default ephemeral range (32768–60999, which is also this container's), below macOS/Windows (49152–65535), and below Nomad's default dynamic task ports (20000–32000). Nothing in `es/app` tests or `scripts/` hard-codes a port in this range, and nothing changes Nomad's dynamic range |
| Each port handed out once per process | Correct. A mutex-guarded `handedOut` map (`:37-40`, `:91-101`). The scan starts at a random offset and wraps, so it covers all 10000 ports before it gives up with a clear error |
| Free over TCP and UDP | Correct. `tcp4` and `udp4` binds on `0.0.0.0:port` (`:106-119`). On Linux, a listener on `127.0.0.1:port`, or a dual-stack `[::]:port`, makes the `0.0.0.0` bind fail, so both are detected |
| Linux ephemeral-range guard | Correct. It reads `/proc/sys/net/ipv4/ip_local_port_range` on each call (`:53-61`). The overlap test `first < high && last >= low` (`:81`) is right for `[low, high)` against an inclusive `[first, last]`. Malformed text is refused. The error names the sysctl to change |

Mutation probes (`audit-evidence/mutations.log`). Each mutation is on a scratch copy, followed by a run of the allocator tests:

```text
P1 UDP check removed                       exit 1  (SkipsPortsInUse/udp4)
P2 TCP check removed                       exit 1  (SkipsPortsInUse/tcp4)
P3 handed-out check removed                exit 1  (DistinctPorts and NeverHandsOutAPortTwice)
P4 overlap check "last > low"              exit 1  ("1024 10000" case)
P5 overlap check "first <= high"           exit 1  ("20000 60999" case)
P6 ephemeral guard call skipped            exit 0  (see O1)
P7 range moved to 40000-49999              exit 1  (the guard refuses it)
```

## Callers and test strength

- **Callers.** All three callers use the new allocator unchanged, through the same function names:
  - the bring-up test, 7 ports (`operator_scripts_integration_test.go:62-68`);
  - the Nomad harness, 3 ports (`submit_integration_test.go:2709-2717`);
  - the supported-local setup test, 1 port (`supported_local_proof_validation_test.go:59`).
  
  Only the old helper's body was removed (`submit_integration_test.go`, 19 lines). The one other `127.0.0.1:0` listener in `es/app` tests (`operator_scripts_integration_test.go:3812`) keeps its socket open and serves on it, so it has no race.
- **Nothing weakened.** No assertion, skip or timeout changed. The only edits to existing tests add the log tails to two `t.Fatalf` messages (`:366`, `:389`).
- **Log tails.** `bringupLogTails` prints the last 40 lines of each `*.log` under `bringup-state/logs`. Bring-up writes those logs for ARS, EGS, AGS, ES and Nomad, plus an image-build log. It starts no Vault, and `scripts/70_diagnostics.sh` already reads the same logs. So this adds no secret to CI output beyond test fixtures.

## Runs (cloud container, Go 1.26.5)

- `go vet ./es/app` (linux) and with `GOOS=darwin GOARCH=arm64`: exit 0. `gofmt -l es/app`: clean.
- The 5 new tests PASS. The allocator tests PASS with `-count=20` in one process.
- The writer's reproduction, rebuilt from `portrace-repro.go` and run for 1000 trials:
  - old helper: 2 duplicate-port trials and 54 trials where a reserved port was taken;
  - new allocator: 0 and 0 (`audit-evidence/repro-1000.txt`).
  
  This matches the writer's 3000-trial result.
- Not run: the bring-up test, the Nomad harness and the supported-local setup test. They need Docker, Nomad, Vault, SPIRE and bindfs, and CI runs them.

## Observations (no action needed)

- **O1. No test fails when the guard's call is removed (P6), because the default range never trips it.** The property it protects is still pinned. The 200-port test asserts directly that no port falls inside the kernel's ephemeral range. P7 shows the guard fires when the ranges overlap.
- **O2. Limits of the design, both outside CI.**
  - Two `es/app` test processes running at the same time on one host could still pick the same port. The random offset and the free check make this unlikely.
  - An IPv6-only (`v6only`) listener on `[::1]:port` is not seen. Every service in these tests binds IPv4.

## Report fields

- Touched files: none in any repo. Wrote this report and `audit-evidence/`.
- Assumptions: "single issue per process" means "handed out at most once per test process".
- Inferences: none beyond the PR's own (which race hit run 45282710398).
- Skipped validation: the CI-only integration tests (see Runs).
- Authority or security widening: none. Test files only.
- Confidence: high for the allocator and caller coverage. Medium that this removes the CI flake, because the failing run's Nomad log was not captured. The new log tails will show it if the failure recurs.

## Re-check 1: head `0efa117` (2026-11-24 00:21Z to 00:26Z)

**Verdict: still ACCEPT.** The new guard logic is right, and nothing outside it changed. Merge after green CI. Run job 138115051271 on `0efa117` was in progress at 00:23Z. The `9696b93` run was cancelled by the push, so it did not fail.

- **Scope.** `0efa1173faebd74e9e1d11d92f516f1a688308fd` is one commit on `9696b93` and touches only `es/app/test_ports_test.go` (+175 −36). trunk_dev is unchanged at `42db339`.
  - I took a fresh-clone v2 manifest twice and got identical results: `e0320314ec1f2e2e1945024fdcb4778f02fd4900b20062d1585f5531c30988c4`, 3 entries.
  - Compared with `9696b93`'s manifest, only that file's entry changed. The other two blobs are identical, and every blob matches.
- **Logic.**
  - **Shared guard.** `reserveTestPort` refuses the reservation when the range read fails, or when the range overlaps the test range. Only then does it allocate.
  - **Where the range comes from.** `readEphemeralPortRange` uses the procfs file when it exists, and runs `sysctl -n net.inet.ip.portrange.first net.inet.ip.portrange.last` only when the file does not exist (`os.IsNotExist`). Any other read error, or malformed procfs text, fails without falling back. A sysctl failure or malformed output also fails.
  - **Parsing.** `parsePortRange` needs exactly two integers, with first ≤ last.
  - **Caching.** The result, including an error, is cached once per process with `sync.OnceValues`.
  - **Overlap check.** Unchanged. It now reports which source the range came from.
  - **Per platform.** Linux reads procfs. macOS reads sysctl (default 49152–65535, which passes). FreeBSD's default of 10000–65535 is refused with a clear message, which is correct. A host with neither procfs nor sysctl is refused (fail closed). These are the right outcomes.
- **Runs.**
  - `go vet ./es/app` passes for linux and for darwin/arm64, and `gofmt -l` is clean.
  - All allocator tests pass, including the 6 subtests of the new read test, and also pass at `-count=20`.
  - The live test logs `ephemeral port range 32768-60999 from /proc/sys/net/ipv4/ip_local_port_range`.
- **Mutations** (`audit-evidence/r1-mutations.log`; the log's first Q1 line did not compile and is re-run at the end):

```text
Q1 overlap check skipped in reserveTestPort (was O1)   exit 1
Q2 range-read error ignored in reserveTestPort         exit 1
Q3 fall back to sysctl on any procfs error             exit 1
Q4 sysctl failure treated as a default range           exit 1
Q5 first > last accepted                               exit 1
Q6 reserveTCPPortValue calls the allocator directly    exit 0
```

- **O1: closed at the guard.** Q1 and Q2 now fail. **What is left (Q6):** the one-line wiring in `reserveTCPPortValue` (`return reserveTestPort(ephemeralPortRange)`) is still not pinned. Replacing it with a direct allocator call passes on a default host.
  - This is the same no-action status as before. The 200-port test still checks the outcome against the real range.
  - Optional pin: `ephemeralPortRange` is a package variable, so a test could swap in an overlapping fake and assert that `reserveTCPPortValue` refuses. That is about five lines.
