Nothing needs you while you're away. Everything is moving through checks:

**Still working**
- PRs 66 and 67 (Nomad lock and box upgrade): fixes are in, and paired re-checks are running.
- PR 70 (user identities): fixes are in, and a fresh audit, Sonnet shadow and red-team are running.
- PR 74 (caller injection): one last fix, three more gcc settings to block.
- PRs 75 and 76 (signing keys): fixes are in. 75 is in its re-check, and the rewritten rotation script in 76 has a fresh audit and red-team running.
- PR 77 (PLANS.md cleanup): one more test fix, now being re-checked.
- New governance PRs: 78 (revocation runbook), 79 (the upper-case digest fix) and 80 (the tested requirement to cut off a single workload) are all being audited.

STATUS: WAITING on nothing from you.
