CI passed on both required jobs at `827686a`, so the ACCEPT on PR #75 now has its CI result. "build, vet and test" finished at 3:00 AM ET and "test on macOS" at 2:46 AM ET, and the PR head is still `827686a`. I updated the report's CI section (new SHA-256 `7cfc103f…f9a3`) and the trial row. The not-blocking recommendation still stands: a small CI-only PR for P16-1, a CI step that runs tests in a `git archive` copy.

STATUS: READY (re-check done; nothing running)
