The fixes for the signing-key PR 75 are in, so I'm starting its final paired re-check.
