The read-only box check is done, and the box is affected. AGS and EGS on the test box sign with the two keys anyone can read in the repository, and ES trusts exactly those keys. So anyone who can get a record into the box's artifact store could pose as any publisher. Nothing on the box or your Mac changed, and the session on your Mac is closed.

What follows: the fix for new installs is written and its tests pass. Next, a rotation script gives the box its own keys. ES will also stop trusting the 164 records already in the box's artifact store, because nobody can tell who signed them, so the script re-publishes the ones we still need. Evidence: [01-box-key-check.md](/mnt/project-files/reports/Execution-Substrate/signing-keys/01-box-key-check.md)

STATUS: WORKING (finishing the new-install fix and its draft PR, next update by about 10:30 PM Eastern)
