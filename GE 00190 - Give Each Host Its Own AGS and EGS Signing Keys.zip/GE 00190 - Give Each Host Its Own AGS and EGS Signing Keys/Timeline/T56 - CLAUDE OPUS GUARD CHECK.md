**ACCEPT on PR #75 at 827686a. R15-1 is fixed, and the delta adds nothing else.** CI was still running when I finished, so the gate still has to see both jobs green.

- **The fix works.** The guard now accepts the exact value `.git` and still refuses `.git/HEAD`, and its self-test checks both. I ran the tests as a normal user in a `git archive` copy: `./internal/testutil ./internal/knownkeys` fails at `ec9a5b9` and passes at `827686a`. Both also pass in a git checkout, and `go vet` and `gofmt` are clean.
- **Mutants:** 4 of 5 are killed. The survivor (M4, comparing the cleaned path) only lets an archive tree accept spellings a git checkout already accepts, so it is not a gap.
- **Provenance:** the recipe hash matches the pinned value. The v2 manifest is `cddd3cca…e85c` with 39 paths, and the closing run matched the opening run. Compared with the `ec9a5b9` manifest, the only difference is `internal/testutil/testutil_test.go`. The writer had not delivered a manifest for this head, so I had nothing to compare against.
- **Pre-existing gap (P16-1), not blocking:** no CI step runs any tests in a tree without `.git`. That is why R15-1 got through CI and four review rounds. I recommend a small CI-only PR that runs these packages and the root package in a `git archive` copy.

CI on `827686a` started at 07:14Z, and the last full run took about 46 minutes. I'll check it at 3:03 AM ET (08:03Z) and update the report then. I logged the trial row, and I didn't read the paired Sonnet report.

Report: [16-pr75-recheck-opus.md](/mnt/project-files/reports/Execution-Substrate/signing-keys/16-pr75-recheck-opus.md) (SHA-256 `2dae5190…c8e5`).

STATUS: WORKING (waiting on CI for 827686a; next update about 3:03 AM ET)
