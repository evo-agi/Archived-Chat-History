**CI on 827686a passed on both jobs, so the ACCEPT for the delta ec9a5b9..827686a stands.** macOS finished green at 07:46Z and Linux at 08:00Z. Run 397's `head_sha` is 827686a, so it ran on the bytes I checked. I did not read the job logs, so I rely only on both jobs finishing green. This is the first full CI run on either OS that includes the re-check fixes, because both ec9a5b9 runs were cancelled.

The two observations in the report are unchanged and neither blocks:
- **O16-1:** the guard's self-test does not pin "exactly `.git`". A 4-line addition that fixes it is in the evidence folder, verified.
- **O16-2:** the PR body still stops at ec9a5b9.

The report and the trial row now carry the CI result. Nothing was pushed, posted or merged.

New report SHA-256 `fb3d467e0f11213a73b9c35ab02db7d3481780d757251f214bc9d03793f92329`. It replaces the hash in my earlier reply.

STATUS: READY (report 16 is final; I am waiting for the paired Opus report to compare, nothing needed from David)
