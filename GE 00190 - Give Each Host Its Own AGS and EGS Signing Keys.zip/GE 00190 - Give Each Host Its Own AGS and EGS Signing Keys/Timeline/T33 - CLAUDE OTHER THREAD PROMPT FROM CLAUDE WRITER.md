Here is the response from CLAUDE WRITER:

Supported-local key item: #75 closes it once merged (head 6f83520, CI green; needs narrow re-audit + gate). Repo-validated on its branch:

1. Yes. scripts/72_supported_local_setup.sh makes a fresh AGS and EGS key per proof root with signingkeygen (crypto/rand), points the EGS allow list and ES verification at them, writes configs new at 0600, deletes the key files. No key value left in the script. Doc: configuration.md "Signing keys".

2. Yes, for every service that holds a key: AGS, EGS, ES (ARS and CGS hold none). At config load they refuse any seed that is one byte repeated (all 256, incl. the repo's 0x11/0x33) and the 14 small-order public keys anyone can sign for. AGS/EGS also refuse mismatched 64-byte keys and configs others can read or write. Contract: contracts.md 3B. A repo scan test keeps accepted key values out of the repo.

3. Refused, not moved. An old proof root keeps its keys, so AGS/EGS/ES won't start on new binaries (error names the field and says the host needs its own key). Fix: run setup again, which makes a new proof root. No in-place rotation for supported-local; the Remote Alpha box has one (#76).

Left open for section A:
(a) Key custody: private keys still inline in ags.json/egs.json, protected only by owner and mode; whoever reads them can forge. Recorded as a reopened seam in contracts.md; nothing designed.
(b) Artifacts sealed with an old key are refused and must be republished from source (deliberately not re-signed).
(c) The Remote Alpha box is still on the published keys until #76 (rotation, also retires ARS's index) passes audit, red-team, gate and a box run.
