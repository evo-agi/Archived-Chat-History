The box check came back: the test box does sign with the two published keys, so anyone who could get a record into its artifact store could pose as any publisher. Nothing changed on the box. The fix for new installs is written, and a rotation script will give the box its own keys and re-publish the records we still need.

STATUS: WORKING (signing key fix, plus the PR audits)
