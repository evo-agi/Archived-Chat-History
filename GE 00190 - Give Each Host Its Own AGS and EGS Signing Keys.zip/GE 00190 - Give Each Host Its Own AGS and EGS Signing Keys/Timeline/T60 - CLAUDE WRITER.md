#75 is merged into trunk_dev as `be20ffc` (squash). Both CI jobs were green on `827686a`. The merge gate passed: head and base were unchanged, there were no open findings, and trunk_dev's tree now matches the audited tree byte for byte. All of that is checked in the repo.

No other PR had to land first. #70, #73, #74, #77 and #78 each need trunk_dev merged in before their own gates, and #73 will conflict with #75.

I've merged trunk_dev into #76 with no file changes and pushed `c9c1e40` so CI starts early. That isn't the head to re-check yet: the mutant run and the root tests are still going. I'll report the final head with the fixes report.

STATUS: WORKING
