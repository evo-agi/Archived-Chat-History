Both PRs are fixed and pushed. #75 is at `6f83520`, CI green on Linux and macOS. #76 is at `e75c804`, CI still running.

**#75:** audit F1–F3 and red-team RT75-1..4 fixed, and trunk_dev #69 merged in (docs only, no conflict). Needs a narrow re-audit, then the gate.

**#76:** the rotation script is rewritten. Every audit 05 and red-team 07 finding is fixed.
- **RT76-1, repair 1:** the rotation moves ARS's index into its backup in the same step, and rollback puts it back. The blobs and the ARS contract are unchanged.
- **Regression test:** the red-team's e2e subtest, turned around. Republish and prepare now both give 200.
- **ES binary deployment:** it now runs the ES, AGS and EGS config checks before it installs anything.
- **Mutants:** all 28 one-change mutants of the script fail the tests (re-run against the final tests).
- **Full suite:** fails only the same 55 container tests as trunk_dev.
- **CI at `5b79beb`:** Linux passed. macOS failed on two of my new tests, which assumed Linux paths. `e75c804` fixes both, and I'll fix and report if CI goes red.
- **Next:** because the script was rewritten, it needs a fresh audit and red-team, then the gate, then a box turn.

Each report maps every finding to its fix and test.

STATUS: READY
