**PR #75 does what it set out to do, with four gaps to close before it merges: one Medium and three Low.** I found no way to make a setup-built install sign with a known or predictable key, and no spelling that gets a published key past AGS, EGS or ES.

- **RT75-1, Medium:** ES and the upgrade check accept 14 verification keys that anyone can sign for, 64 zeros among them. With zeros as the provenance key, ES registered a run nobody signed. No shipped config has such a key; it takes a hand-written placeholder.
- **RT75-2, Low:** AGS and EGS accept a 64-byte private key whose halves do not match, which can later give the key away.
- **RT75-3, Low:** no test fails if every install gets the same key again.
- **RT75-4, Low:** only setup keeps the key-holding configs private. AGS and EGS load them world-readable.

Each finding has a probe, a tested repair and a regression test in [06-pr75-redteam.md](/mnt/project-files/reports/Execution-Substrate/signing-keys/06-pr75-redteam.md). Everything ran in my container on the first head efc97e6 and again on the new head 4fb447d, after the branch merged trunk_dev mid-pass. Setup as a whole could not run here (no Docker or Nomad). Nothing needs David.

STATUS: READY
