David, the card above asks to start a session on your Mac for one read-only check of the test box. It tells us whether the box signs with the two keys anyone can read in the repository. It prints only public keys and file settings, never a private key, and changes nothing. Approving it is the only thing I need from you. Meanwhile I'm writing the fix: each install gets its own keys, and the services refuse the published ones.

STATUS: NEEDS DAVID (approve the card so the read-only box check can run)
