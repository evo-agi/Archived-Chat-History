Catch-up: nothing needs you.

**Done**
- [PR 68](https://github.com/evo-agi/Execution-Substrate/pull/68) merged as `a5861b7`, so the ES service layouts are now consistent.
- The signing key fix is up in two parts, [PR 75](https://github.com/evo-agi/Execution-Substrate/pull/75) (new installs get their own keys) and [PR 76](https://github.com/evo-agi/Execution-Substrate/pull/76) (rotates the box's keys), and both are in audit and red-team. The box rotation will need a box run once they merge.

**Still working**
- Caller-keyed network grants (PR 73) and the code injection fix (PR 74) both passed their red-teams with no way through, and are fixing small test gaps. PRs 66, 67, 69 and 70 are working through audit fixes.

STATUS: WORKING (audits and fixes on PRs 66, 67, 69, 70 and 73 to 76)
