The fix for new installs is up as [PR #75](https://github.com/evo-agi/Execution-Substrate/pull/75). It's ready for the fresh audit and red-team, and CI is running.

In plain words: every new install now makes its own two signing keys when it is set up, and AGS, EGS and ES refuse to start with the keys that are published in the repo (or any key built the same easy-to-guess way). Tests pass in my container. The only failures also fail on trunk_dev there, and I checked that test by test (repo-validated, details in the report).

Three things to know:
- **Once this merges, the box can't be upgraded until it gets new keys.** That stop is deliberate, so the box can't be forgotten. The rotation PR is next and I'm starting it now. Any box upgrade waits on it, including the identity run and the workload grants test.
- **The 164 artifacts already on the box will not be re-signed.** Anyone could have signed them with the published key, so re-signing would vouch for possible forgeries. Artifacts that are still needed get published again from their source.
- I told the [workload grants thread](#cmsg_01Un4xQgjBAczV8DABQvcLrxFX2CN6RozHmusrBEzLRt86) what it has to change. Whichever PR lands second makes that change.

STATUS: WORKING (writing the box rotation PR, next update when it is up)
