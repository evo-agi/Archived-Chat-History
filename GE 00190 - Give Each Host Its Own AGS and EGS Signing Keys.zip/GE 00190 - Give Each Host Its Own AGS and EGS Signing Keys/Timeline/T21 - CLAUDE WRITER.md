The box rotation is up as [PR #76](https://github.com/evo-agi/Execution-Substrate/pull/76), stacked on #75. It's ready for its audit and red-team.

What it does: one command on the box (`check` first, then `apply`) makes new AGS and EGS keys with the box's own openssl. It backs up the three configs, writes the new keys in, and restarts EGS, AGS and ES. Then it checks that they answer. If anything fails, it puts the backup back on its own. Its tests cover the success path, 10 kinds of box it refuses, and 4 kinds of failure that roll back. I also broke the script 9 different ways by hand, and the tests caught every one.

Nothing has touched the box yet. The box run needs #75 and #76 merged and a box turn from the coordinator. After the run come a smoke test with a freshly published artifact and deleting the backup, since the backup holds the old keys. The plan is in the report.

Next I'll update #75 for the workload grants change once #73 merges.

STATUS: WAITING (on the #75 and #76 audits, #73 merging, and a box turn)
