One quick approval needed, everything else is moving.

**Needs you**
- [Give each host its own signing key](#cmsg_01Un4xQgjBAczV8DABQvcLrxRwuRkgErADF4kML5ruQ5xP): please approve the Remote Control prompt on your Mac. It runs one read-only check of the test box, showing only public keys and file settings, to see whether the box signs with the two keys that are published in the repo.

**Done**
- [PR 72](https://github.com/evo-agi/Execution-Substrate/pull/72) merged as `fbfd100`: no service accepts a workload identity as a caller anymore. It passed audit and red-team.

**Still working**
- [Stop callers injecting code into runs](#cmsg_01Un4xQgjBAczV8DABQvcLrx93JRRrFog4xi5XahM22UXL): [PR 74](https://github.com/evo-agi/Execution-Substrate/pull/74) is up. A caller can now set only the variables and mount only the folders that the signed package lists. It's in audit and red-team.
- Caller-keyed network grants ([PR 73](https://github.com/evo-agi/Execution-Substrate/pull/73)) are in a fresh audit and red-team. PRs 66 to 70 are working through audit fixes, and PR 68 merges once its CI finishes.

STATUS: NEEDS DAVID (approve the read-only box check on your Mac)
