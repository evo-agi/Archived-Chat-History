CI on #76 (`e75c804`) passed on both Linux and macOS, so both heads are green and ready for their audits. I updated the CI section of the #76 report to match.

STATUS: READY
