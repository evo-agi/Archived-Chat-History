#75 is now at `827686a` with R15-1 fixed. The Sonnet re-check of `ec9a5b9` was ACCEPT, so I didn't wait any longer.

- **The fix:** the test-path guard now accepts exactly `.git`, the one root name a checkout has and a `git archive` tree doesn't. Its self-test requires that, and it still refuses `.git/HEAD`.
- **Before:** in a `git archive` tree of `ec9a5b9`, run as a normal user, `internal/testutil` fails on the `.git` lookup in `internal/knownkeys`.
- **After:** `internal/testutil` and `internal/knownkeys` pass in the same tree. In the checkout, `internal/testutil`, `internal/knownkeys` and the root docs tests pass. vet and gofmt are clean.
- **Self-test:** it fails on the old guard, and also on a looser guard that would accept anything under `.git/`.

#76 will pick this up in my next push. That push also carries the fixes for both #76 audits (S76-1..3 and F1..F5), which are still in progress. CI is running on `827686a`.

STATUS: WORKING
