The signing-key PRs (75 and 76) have all their fixes in, so I'm starting their re-checks, plus a fresh audit and red-team of the rewritten rotation script.
