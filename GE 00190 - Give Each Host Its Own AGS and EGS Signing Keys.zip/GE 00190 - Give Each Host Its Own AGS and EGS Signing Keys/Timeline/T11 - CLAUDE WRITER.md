This request or connection for a folder on your computer ended.
