**BLOCK on PR #75 at `ec9a5b9`: one Low (S15-1).** Read-only; I pushed and posted nothing, and the box is untouched.

- **Fixed and verified:** R75-1, R75-2, R75-3 and O75-1, plus the writer's claims for Opus O1, O2, O5, O6 and R1. 37 mutants: 31 killed as a normal user, 29 as root. The survivors are equivalent, or CI's normal-user step kills them. The writer's manifests for #75 and for #76 at `aba3fe6` reproduce byte for byte.
- **S15-1 Low:** since `efc97e6`, `go test ./internal/testutil` fails in a source tree with no `.git`, because `internal/knownkeys/repository_test.go:25` joins `.git` to the root. It passes at the parent and at base. CI can't see it, and #76 carries the same file. I wrote a repair and ran it in both kinds of tree.
- **Not blind, and I only found S15-1 with a hint.** The tail of the shared trial log showed me 260 characters of the Opus row naming it, and later the harness showed me the full Opus memory note. I reproduced S15-1 myself. Count it as a Sonnet miss. Details and the log row are in the report.
- **The head moved.** `827686a` (07:14Z, guard change, one file) cancelled CI on `ec9a5b9`, so no CI completed for it. I haven't reviewed `827686a`; it needs a delta check and its own CI.

Report SHA-256 `aa966232c1550b62f6199693229be29f4de340176b2559a47fdbdd427b48b24d`. Evidence is in `15-pr75-recheck-sonnet-evidence/`, beside the report.

STATUS: READY (re-check done; send the delta check of `827686a` when you want it)
