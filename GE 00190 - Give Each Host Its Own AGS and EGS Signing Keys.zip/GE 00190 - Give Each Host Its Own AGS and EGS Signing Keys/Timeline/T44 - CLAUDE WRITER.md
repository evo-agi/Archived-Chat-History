PR 75's re-check findings are fixed. The new head is `ec9a5b9`, and #76 is at `aba3fe6`, which merges it in. CI is running on both and started at 06:50Z.

- **R75-1:** contracts.md now counts all 14 small-order keys.
- **R75-2 / Opus O2:** the config test now checks two things. A link is judged by the file it points to, so a link to a 0600 config loads and a link to a 0644 one is refused. A folder with mode 0700 is refused as "not a regular file".
- **R75-3 / Opus R1:** the generator's folder check now takes the effective user ID, and a new test covers a folder that another user owns.
- **Opus O1 and O75-1:** comment and docs wording only. **O5 and O6:** the two changes report 08 left out are now listed, and writer manifests are attached for both heads.
- **Mutants**, re-run on the exact head (repo-validated): 8 of 8 killed as a normal user, 7 of 8 as root. The one root survivor is killed by CI's normal-user runs.

#76's own change is unchanged by the merge: the same 19 paths and identical hunks. So the audit and red-team running on `e75c804` still apply. I'm now starting on the Sonnet shadow audit of #76 (S76-1 to S76-3).

[14-pr75-recheck-fixes-report.md](/mnt/project-files/reports/Execution-Substrate/signing-keys/14-pr75-recheck-fixes-report.md)

STATUS: WORKING
