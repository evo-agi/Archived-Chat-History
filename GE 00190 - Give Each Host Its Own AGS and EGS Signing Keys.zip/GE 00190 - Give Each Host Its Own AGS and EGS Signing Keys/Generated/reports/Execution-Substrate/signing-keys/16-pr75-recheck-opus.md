# ES PR #75: Opus narrow re-check 16 of the R15-1 fix (ec9a5b9 to 827686a)

```text
INDEPENDENT AUDIT REPORT (narrow re-check)
Repository:      evo-agi/Execution-Substrate, PR #75 "Give each host its own AGS and EGS signing keys"
Audit target:    base trunk_dev 0b9278ca74404b46b5e9f0e1701874b52687f5e8
                 topic claude/project-thread-ljwd16 @ 827686a28dcb8d5e01465a401d96dc1ba61557a6, tree 8c9a9b2b789f10de01bd6a0ffdc552ac686cd82e
                 recipe governed-execution.audit-patch-manifest.v2, source SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified)
                 canonical manifest SHA-256 cddd3cca7cde2eded655c50b9015cd4d7cb65bcd939ac2cb7e3728bec89fe85c, 39 changed paths
Scope:           delta ec9a5b9..827686a (1 commit, 1 file, +7/-1): the fix for R15-1 from report 15
Model:           [model withheld] (paired run; the paired Sonnet report for this head was not read)
Date:            2026-11-27, about 07:15Z to 07:25Z
Audit posture:   read-only; no subagents; nothing pushed, committed or posted
Final verdict:   ACCEPT (no finding in the delta; R15-1 fixed; CI on 827686a green on both required jobs)
```

## Verdict in plain words

R15-1 is fixed. In a source tree made with `git archive`, `go test ./internal/testutil ./internal/knownkeys` fails at `ec9a5b9` and passes at `827686a`, run as a normal user. The guard now accepts exactly the value `.git` and nothing else under it. Its self-test checks both sides: `.git` must be accepted, `.git/HEAD` must still be refused. The delta changes one file and nothing beyond the fix and its self-test. Four of five mutants of the new clause are killed. The one survivor only accepts more spellings in an archive tree, never more than a git checkout already accepts, so it is not a gap. CI on `827686a` passed on both required jobs.

## Provenance reproduction

- Recipe bytes: `sha256sum` of `/mnt/project-files/operating-protocol/tools/governed_execution_audit_patch_manifest_v2.py` equals the pinned `c08597e2…a1ca`, checked at the start and again before the closing run.
- Target identity: `origin/claude/project-thread-ljwd16` = `827686a…57a6` and `origin/trunk_dev` = `0b9278c…f5e8`, equal to PR #75's head and base in the GitHub API (`pull_request_read get`, about 07:19Z). The base is an ancestor of the tip. `827686a`'s only parent is `ec9a5b9`.
- Two runs (HEAD at the base, upstream `origin/trunk_dev`) gave identical bytes: manifest SHA-256 `cddd3cca…e85c`, 39 paths, textual diff SHA-256 `17985d34…bb2e`. No mode-bit differences.
- Against report 15's manifest for `ec9a5b9` (`05f70f34…ea19`, 38 paths), the only difference is one new entry: `internal/testutil/testutil_test.go` (0644, SHA-256 `6a6b1df1…54a0`). That file is the same blob (`19c3113`) at `0b9278c` and at `ec9a5b9`, so it joins the PR's changed set only now. The other 38 entries are byte-identical (`provenance/manifest-compare-vs-ec9a5b9.txt`).
- No writer manifest for `827686a` was in `signing-keys/` at 07:18Z, so there was none to compare.
- Closing run after the tests and mutants: identical to the opening run. Tests ran in a separate worktree and in `git archive` copies; the provenance clone's working tree was not touched, and the worktree's `git status` was empty after the mutants.
- Commands: `16-pr75-recheck-opus-evidence/provenance/commands.txt`.

## Fix verification (delta ec9a5b9..827686a)

Source labels: **R** means repo-validated at `827686a` (path:line).

The whole delta is three parts of `internal/testutil/testutil_test.go`:

| Part | What it does | Check |
|---|---|---|
| `:683-686` | `anchoredProblem` returns no problem when `known == ".git"`, with a comment naming why (`internal/knownkeys` tells a checkout from an archive). | R. `known` is the full value for a non-partial path (`knownElements`, `:593-596`), so only the exact string `.git` matches. A partial value ends in `/` (`:597-598`) and never equals `.git`. Before, in a checkout, `.git` was already accepted because the root holds it (`atRoot`); the clause makes an archive tree agree with a checkout for this one value. It also skips the "package directory holds it too" check for `.git`, which no package directory holds. |
| `:385` (self-test, `good` source) | `os.Lstat(filepath.Join(testutil.Root, ".git"))` must give no problem. | R. The self-test's root (`:198-218`) is a temp folder without `.git`, so only the new clause accepts it. Mutants M1 and M5 below fail here. |
| `:327` and `:462` (self-test, `bad` source) | `filepath.Join(testutil.Root, ".git/HEAD")` must still be refused with "which holds no such name". | R. Mutants M2 and M3 (accepting anything under `.git`) fail here. |

R15-1 itself (`tests/no-git-tree-ci.txt`, user `ci`, uid 30033, `git archive` copies, no proxy variables, `GOPROXY=off`):

```text
ec9a5b9: FAIL TestImportersNameRepositoryPathsFromTheRoot
         internal/knownkeys/repository_test.go:25: filepath.Join resolves ".git" against the repository root, which holds no such name
         ok internal/knownkeys
827686a: ok internal/testutil
         ok internal/knownkeys
```

In a git checkout (worktree at `827686a`, root): `TestImportersNameRepositoryPathsFromTheRoot` and `TestRepoPathCheckFindsEachKindOfProblem` pass, `./internal/testutil` and `./internal/knownkeys` pass, `go vet ./internal/testutil` is clean and `gofmt -l internal/testutil/` prints nothing (`tests/checkout-root.txt`). `TestImportersNameRepositoryPathsFromTheRoot` passing in the archive tree also shows that no other test names a `.git/...` path against the root.

Mutants of the new clause (`mutants/mutants.py.txt`, each applied alone and restored; `mutants/checkout-root.txt`):

| Mutant | Result |
|---|---|
| M0 no change (baseline) | passes |
| M1 drop `known == ".git"` | killed: `good.go:44` (the `:385` line) refused |
| M2 `first == ".git"` (anything under `.git`) | killed: `bad.go:108` no longer reported |
| M3 `strings.HasPrefix(known, ".git")` (also `.gitignore`, `.git/HEAD`) | killed: `bad.go:108` |
| M4 `filepath.Clean(known) == ".git"` | survives (O16-1) |
| M5 accept `.git` only for a partial value | killed: `good.go:44` |

Rest of the delta: nothing else. `git diff --stat ec9a5b9 827686a` lists only this file, and the commit message matches the change (see O16-2 on one phrase).

## Findings

None in the delta.

Observations (no action required):

- **O16-1: M4 survives, and is wider only where a checkout is already wide.** Comparing the cleaned value also accepts `./.git`, `.git/` and a partial value starting `.git/` (such as `".git/" + name`). In a git checkout all three are already accepted, because the root holds `.git`. So M4 widens only archive-tree behavior, and only up to what CI accepts. The shipped exact match is the stricter choice. No change.
- **O16-2: "still refuses `.git/HEAD`" holds in the self-test's root and in archive trees, not in a checkout.** The commit message says the self-test "still refuses `.git/HEAD`". That is true for the self-test (its root has no `.git`) and in a `git archive` tree. In a real checkout the guard judges against the actual root, which holds `.git`, so it accepts `.git/HEAD` there. This is unchanged by the delta and correct for what the guard checks. It means the guard catches a test that reads under `.git` only when it runs in an archive tree.
- **O16-3: PR body not yet updated for `827686a`.** The Validation section ends at `ec9a5b9` and does not mention the R15-1 fix. It makes no claim that is now false. The writer may add one line.

Pre-existing issue (not a patch defect, outside this scope):

- **P16-1: nothing in CI runs tests in a tree without `.git`.** `.docs/system_overview/artifact_hygiene.md:242-248` says the docs tests still run in such a tree, but CI's checkout always has `.git`. R15-1 passed CI and four review rounds for this reason, and the next archive-only regression would too. Under the rule that a temporary edge needs a machine-enforced trigger, the fix is a CI step that runs at least `./internal/testutil`, `./internal/knownkeys` and the root package in a `git archive` copy. I recommend the coordinator track it as its own small CI PR. It does not block #75.

Minority findings or disagreements: none (single reviewer, no subagents).

## Validation assessment

- Re-run at the exact bytes of `827686a` (Go 1.26.5 linux/amd64, umask 022): the two package sets above, in a git checkout as root and in a `git archive` copy as user `ci`; `go vet` and `gofmt -l` on the changed package; five mutants plus a baseline. Control: the same archive run at `ec9a5b9` reproduces R15-1.
- Not re-run: the full suite (narrow scope; the delta touches one test file of one package); macOS; the mutants of report 15 (signingkeygen and the AGS/EGS config checks are unchanged in this delta); #76.
- Runner: `tests/run.sh.txt` (no proxy variables, offline module cache, `GOTOOLCHAIN=local`).

## CI

Updated 2026-11-27 08:05Z (GitHub API `get_check_runs` for PR #75; `get_status` confirms the head is still `827686a`): both required jobs on `827686a` completed with conclusion `success`. "build, vet and test" (job 140366037954, run 45957080014) ran 07:14:40Z to 08:00:16Z. "test on macOS" (job 140366072462, run 45957080008) ran 07:14:47Z to 07:46:31Z. The runs on `ec9a5b9` were cancelled when this head was pushed, so `ec9a5b9` never had a green run. CI checks out with `.git`, so it does not exercise the archive-tree case (P16-1).

## Sensitive-material handling

No secrets were read or copied. Nothing touched the box.

## Remaining uncertainty and stop conditions

- None for the delta. CI is green on `827686a`. If the head moves, this verdict does not carry over.

## Confidence

- Provenance: high. Manifest reproduced twice, closing run equals opening, and the difference from report 15's manifest is exactly the one file the delta changes.
- Validation: high for the delta: exact bytes, git checkout and archive tree, two users, a control on the previous head, five mutants.
- Implementation: high. The fix is the minimal one report 15 proposed, with the self-test cases it asked for.

## Effect status

Read-only. No repair, commit, push, PR, merge or post. Scratch clone, worktree and `git archive` copies exist only in this container, where a local user `ci` was used.

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/signing-keys/16-pr75-recheck-opus.md`, evidence in `16-pr75-recheck-opus-evidence/` (SHA256SUMS inside). The report's own SHA-256 is given in the thread reply.
