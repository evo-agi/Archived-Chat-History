# INDEPENDENT AUDIT REPORT: ES PR #75, per-host AGS and EGS signing keys

Auditor: fresh read-only audit thread "Audit the per-host signing key PR" (started by the coordinator 2026-11-27 01:55Z). Report written 2026-11-27 ~02:45Z.

**Verdict: BLOCK (low findings only).** The product code is correct for what it claims: AGS, EGS and ES refuse every repeated-byte key at config load, before any signer or verifier exists. Setup generates fresh keys from crypto/rand, derives key IDs from the public keys, and writes 0600 configs with no key in the repository or the logs. Nothing is widened. I found no correctness or security defect in product code. The block covers two low test gaps (F2, F3) and one wrong statement in the writer's report and PR body (F1). The standing rule "Low nits fixed in-PR" means these are fixed before merge. A narrow delta re-audit is enough after that.

## Repository / audit target

- Repository: evo-agi/Execution-Substrate
- Base: origin/trunk_dev `fbfd100946d2cb8f25232bac182b94fb299c66da`
- Topic branch: `claude/project-thread-ljwd16`, topic commit `efc97e668174e26aab1c555843321b442aade686`, tree `6b4d09ece87617c882a8416e2f68cd2a54cfbc64`, one commit on the base
- Recipe: `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified with `sha256sum -c` on the project copy and on my working copy, before the opening and before the closing run)
- Canonical-manifest SHA-256 `74400b3c3e15b4b6a794b0631b4631c2fdffc52ce4a038d8e19cb11a9c0143ef`, textual-diff SHA-256 `9486b14c58d58978186da22d31feb540a6408d5e559387a98f5515cfc6e94a54`, 26 paths
- Moved during the audit (coordinator note at 02:25Z): the PR head is now `4fb447d`, a merge of trunk_dev `a5861b7` (#68) into efc97e6. As the coordinator asked, I finished on efc97e6. What bears on the merge is under "Bearing on the merge 4fb447d".

## Audit posture

Read-only. I worked in my own clone (`/opt/audit`, in this thread's container). I ran tests as an unprivileged user `ci` with umask 022, Go 1.26.5 and HUP/INT/QUIT/TERM reset. I used no subagents: I read the change myself, and the protocol's subagent step was not needed for a change of this size. I pushed nothing, posted nothing on GitHub, and touched neither the box nor David's Mac. Mutants and probes ran only in throwaway copies, which I deleted.

## Provenance reproduction (Ran)

- `git fetch origin trunk_dev claude/project-thread-ljwd16`: pushed tip = efc97e6 (= reported); base fbfd100 is an ancestor; the tip's tree = 6b4d09ec (= reported).
- I followed §5.3 exactly: `checkout -f -B` the topic at the tip, checked for a clean status, `reset --mixed` to the base, pinned the upstream to origin/trunk_dev, then ran v2 twice into a fresh 0700 folder outside the repo. The two outputs are byte-identical, and both are byte-identical (`cmp`) to the writer's `02-manifest-v2.json`, SHA-256 74400b3c…43ef. There were no mode-bit differences.
- Closing run after all audit work: byte-identical to the opening manifest (SHA-256 74400b3c…43ef).

## Coverage

Read in full: the whole diff (26 files), `internal/knownkeys/*`, `scripts/internal/signingkeygen/*`, `internal/testutil` (helper and test), the setup changes in `scripts/72_supported_local_setup.sh`, the render test in `es/admission/service_direct_test.go`, and the doc changes (configuration.md "Signing keys", contracts.md 3B and §12, the examples README, PLANS.md, the bring-up runbook).

Traced in unchanged code:
- every use of `PrivateKeyHex`/`PublicKeyHex` and `ed25519` in non-test code (`ags/sign`, `egs/sign`, `ags/publish/service.go:62-71`, `egs/app/app.go:33-45`, `es/admission/service.go:206-234`, `:1015`, `reliable_submit_operational_admission.go:166`)
- every `config.Load` caller (`cmd/{ags,egs,es,ars,cgs}`, `scripts/internal/esconfigcheck`)
- the CGS and ARS configs (they hold no signing keys)
- how services run in supported-local and read 0600 configs (`scripts/internal/control_plane.sh:159`, `scripts/05_start_es.sh`)
- the Mac/Lima path (`scripts/73_supported_local_proof.sh:654-656`: setup and bring-up run as the same guest user, and `EXECUTION_SUBSTRATE_REPO_ROOT` points at an extracted, writable snapshot)
- the safe-evidence collector (an allowlist that copies no config)
- the Remote Alpha upgrade (`remote_alpha_upgrade_es.py`) and deploy (`remote_alpha_deploy_es_binaries.sh`) paths
- the hardening scripts (they read configs and print no key)

Not inspected: CP, IM, MA (the writer did not check them either). I did not read Archived-Runbooks or Archived-Chat-History on their live branches. My local clones of the other project repos (on main) show no labelled key values.

## Checks the coordinator asked for

| Check | Result | Evidence |
|---|---|---|
| Key generation | Holds. `ed25519.GenerateKey(crypto/rand)`. A known-key check guards against a broken source. No key in argv, env or stdout. | `signingkeygen/main.go:73-118`; mutants G05 and G06 killed |
| Storage: ownership and 0600 | Holds. Key file: `O_CREATE\|O_EXCL\|O_NOFOLLOW` 0600 plus fchmod. Configs: 0600 and `O_EXCL\|O_NOFOLLOW`, owned by the setup user. Signing folder: `umask 077 mkdir`, no `-p`, removed after rendering. Services run as the same UID (operator) or as root. | setup `:1234`, `:1348-1370`, `:1529`; mutants G02b, G03, R04, R06 killed (R01-R03, R05, R08 survive: F3) |
| No key in logs or repo | Holds. Setup sends `go run` stdout to /dev/null. Refusal messages carry the field and the repeated byte, never key material. No service logs its config (grep). Labelled key values in trunk_dev/main history: only seeds 0x11 and 0x33 were ever committed (`git log -p -G private_key_hex` over both branches). | test `TestCommandPrintsOnlyThePublicPart`; history scan output in this report |
| Key IDs from public keys | Holds. Role + "-" + first 16 hex of SHA-256(public). Pinned by the keygen test and the render test. | `main.go:67-70`; G04 and R11 killed |
| All six example templates | Holds. ags, ags.operator_and_control_plane, egs, es, es.operator_and_control_plane, es.configured_literal_policy_demo are each refused as they are, with exactly the known-key error, and accepted with fresh keys. `TestEveryExampleWithKeysIsChecked` keeps the list complete. `.examples/config` holds no other file with keys. | `examples_test.go`; K01, K05, A01, E01, S01 killed |
| Setup paths | Holds. The only writer of AGS/EGS/ES configs with keys in the repo is the supported-local renderer. The Remote Alpha scripts only read existing configs. The real end-to-end setup test `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` ran and passed on the CI runner at efc97e6 (see Validation). | grep of `scripts/`; CI log |
| Refusal complete and placed before any use | Holds. AGS checks the signer seed (32-byte), both halves of a 64-byte key, and the public key. EGS does the same. ES checks all four `verification` entries. Every check runs inside `config.Load`/`Validate`, before `sign.NewEd25519Signer` (AGS publish, EGS app) and `newEd25519Verifier` (ES `NewService` calls `cfg.Validate()` first). Probes: padded, upper-case, 64-byte known-seed-with-fresh-public, and seed 0x00 variants are all refused. | probe test (evidence), all six refused; K02-K04, A02, E02, S02 killed |
| Tests do not depend on the constants | Holds. The rule test covers all 256 seeds. Tests that need an accepted config call `WithFreshSigningKeys`, which keeps key IDs and generates keys. The constants appear only in tests that assert refusal. | K02 killed; T01 killed |
| Deliberate refusal of the box's current keys at esconfigcheck | Holds for esconfigcheck itself. The probe built esconfigcheck from base and from head and ran it on the example es.json, whose `verification` block is the box's (same keys per `01-box-key-check-out.txt`). Base accepts. Head refuses with `verification.trust_model.public_key_hex is a known key … 0x33`. With fresh keys, both accept. The upgrade script does not run this check on the box today: see F1. | `esconfigcheck-probe-out.txt`; S03 killed |
| No widening | Holds. Only refusals were added. Configs went from umask-default (0644) to 0600. No API, DTO or wire change. The `egs.json` example reshape (`trust_model` to `runtime_trust` plus `publication`) matches the current EGS struct and the box's real egs.json top-level keys. | diff; `egs/config` struct |

## Findings

### F1: The box's migration trigger is the startup refusal, not the upgrade's esconfigcheck

- Type / Severity: report-only inaccuracy (writer report and PR body; no code defect) / **low**
- Current contract: contracts.md 3B (head `:303-306`) says esconfigcheck is one tool that refuses the same keys, "which the Remote Alpha upgrade runs on the migrated es.json". That sentence is accurate as scoped.
- Evidence: the writer's report ("Machine-enforced migration trigger … esconfigcheck (run by the Remote Alpha upgrade in inspect and before atomic_replace in install_es…) refuses the box until its keys rotate") and the PR body ("`scripts/internal/esconfigcheck`, which the Remote Alpha upgrade runs before it changes anything, refuses a host still on the published keys") present the upgrade check as what stops the box. But:
  - `remote_alpha_upgrade_es.py:1198-1201` runs esconfigcheck only in `inspect_start`, for shape "locked-http".
  - The box has been shape "https" since PR #60's box run (state.md, 2026-11-25 10:40Z), and `inspect_migrated` runs no config check.
  - For any new commit, `binaries_shape` (`:1080-1100`) returns None, because the box's binaries come from 7e27168, which is neither `BOX_ES_COMMIT` nor the new commit. `inspect_host` then refuses the host as an "unknown" shape before keys are looked at. So on the box this script never reaches esconfigcheck.
  - Separately, `scripts/internal/remote_alpha_deploy_es_binaries.sh` (embedded Python, `:926`) replaces ES binaries and runs `systemctl restart` with no `config.Load` pre-check. Inference: if it were used on the box after this PR, ES would fail to start and the box would stay down until rollback.
- Impact: no security impact (every path fails closed). The planning risk is that the coordinator or the rotation work relies on "the upgrade refuses first" when what actually happens is "the service refuses to start". Also, esconfigcheck has no counterpart for ags.json or egs.json.
- Required correction: in the replacement report and the PR body, name the startup refusal of AGS, EGS and ES on new binaries as the machine-enforced trigger, and drop the claim that the upgrade's esconfigcheck stops the box today. Follow-up for the rotation PR (#76) or any box redeploy path, not this PR: run the config checks for es.json, ags.json and egs.json before replacing binaries.
- Uncertainty: I did not run either script against a box. The shape conclusion comes from the code plus state.md.
- Patch defect or pre-existing: the report text is a patch-report defect. The deploy helper's missing pre-check is pre-existing.

### F2: Nothing checks that the generator makes a fresh EGS key on each run

- Type / Severity: test gap / **low**
- Evidence: mutant G07 makes `generate` return a fixed, non-repeated EGS key (seed `00…07`). It survives the whole `scripts/internal/signingkeygen` package. `TestGenerateWritesAFreshKeyOnlyItsOwnerCanRead` (`main_test.go:50`) generates the roles `ags, egs, ags`, so its "two runs generated the same key" check only sees repeats of the AGS key. The render test checks only that AGS ≠ EGS within one install.
- Impact: a regression that pins the EGS key, the "anyone can sign a trust policy" key, would pass every test.
- Required correction: generate each role at least twice in the uniqueness test (for example `ags, egs, ags, egs`), or keep a set per role.
- Patch defect.

### F3: The renderer's key-file and config-write defenses have no tests

- Type / Severity: test gap / **low**
- Evidence: all of these mutants survive the render test plus the `internal/knownkeys` tests:
  - R01: key-file mode check (`info.st_mode & 0o077`, setup `:1356`) dropped
  - R02: owner check dropped
  - R03: `O_NOFOLLOW` on the key-file read dropped
  - R05: config writes without `O_EXCL|O_NOFOLLOW` (`:1529`)
  - R08: signing folder made without `umask 077`, even as 0777 (`:1234`)
  - R10: the `key_id` format check (`:1367`) dropped

  The code at efc97e6 is correct on each of these. Only the tests are missing.
- Impact: these are defense-in-depth checks around private keys, and nothing would notice if they were weakened or removed.
- Required correction: add cases to the render test (or a small sibling test that sources the setup) for:
  - a key file with mode 0640: refused
  - a key file that is a symbolic link: refused
  - a malformed `key_id`: refused
  - a pre-existing `es.json` at the destination: refused, existing file unchanged
  - a signing folder whose mode is not 0700 after `generate_supported_local_signing_keys`: asserted

  The owner check (R02) needs a second UID. Test it where root is available, or say in the report why it is left untested.
- Patch defect.

### F4: The contract sentence on repository keys claims more than the scan checks

- Type / Severity: test/doc gap / **observation**
- Evidence: contracts.md 3B (`:308`) says "every signing key value the repository holds is a known key". `TestRepositoryShipsNoSigningKeyAServiceAccepts` checks only hex values assigned to fields spelled `private_key_hex`/`public_key_hex` (its regex). An unlabelled constant later copied into a config would not be seen. Mitigation I checked: the history of trunk_dev and main has only seeds 0x11 and 0x33 in labelled form.
- Suggested correction (optional): scope the sentence to "every value given to a signer or verification key field".

### F5: Equivalent encodings of a known key are not refused

- Type / Severity: report-only uncertainty / **observation**, no action
- Evidence: `knownkeys.Check` compares encoded public keys byte for byte. The negated point (the published public key with its sign bit flipped) has a private scalar anyone can compute from the published seed, and it is not refused. Non-canonical encodings exist only for points with y < 19, so they are not a concern for these keys. Nobody gets the negated point by copying an example, and the rule's stated scope is keys copied from the repository. Someone who can write a host's config can already install any key they like.
- No change requested. Recorded so a red-team does not rediscover it as new.

There is no critical, high or medium finding. I disagree with nothing else in the writer's report: its failing-set comparison is consistent with mine, though our environments differ (I ran as `ci`, the writer as root).

## Validation assessment

Ran, on the exact bytes (efc97e6 checkout, tree 6b4d09ec) and on base fbfd100, as `ci`, `GOPROXY=off`, proxies unset:

- `go test -count=1 -json ./...` on head: 02:04:12Z-02:13:23Z. On base: 02:13:23Z-02:21:22Z.
  - Head: 10,148 passed, 45 failed, 135 skipped, 51 packages.
  - Base: 10,115 passed, 45 failed, 135 skipped, 49 packages.
  - **The failing sets are identical** (`diff` empty; lists in evidence). They are 3 in `es/admission/internal/reliablesubmit`, 2 in `es/app`, and 40 in `scripts`, all the same failures with or without this change.
  - Every new and changed test passes, including `TestRetainedResultAuditF1RenderedConfigConstructsConfiguredService`, which runs `generate_supported_local_signing_keys` and the renderer for real.
- Mutants: 33 in all, listed in `mutants.py` and `mutant-results.txt`.
  - Killed: 25.
  - Equivalent: 1. G01 drops `file.Chmod`; with `O_CREATE` 0600 the umask can only clear bits.
  - Survived: 7 (G07, R01, R02, R03, R05, R08, R10), which are F2 and F3.
  - Not real mutants: S01 and S03 failed first only because of an unused import, so I redefined them; both are killed. G02 left `Chmod` in place, so G02b removes it too, and it is killed.
- Probes: the spelling variants (6 cases) are all refused. esconfigcheck base/head on box-style keys behaves as shown above.

CI (read, not rerun):
- "build, vet and test" for efc97e6 (run 45925155434) passed Build, Vet, Vet for macOS and the test-gate self-check (145 tests). In the Test step, `scripts` passed, and both `es/app` runs passed. The gate allows no unlisted self-skip in `es/app`, so the real supported-local setup test ran on the runner.
- The run was then **cancelled at 02:25:51Z** while `reliablesubmit` was running, because the 4fb447d push superseded it. The remaining packages, including `internal/knownkeys` and `signingkeygen`, did not run on CI for efc97e6.
- "test on macOS" for efc97e6 (run 45925155535, `TESTED_PACKAGES: ./scripts/...`, which includes `scripts/internal/signingkeygen`) **passed**: test gate, Test and "Listed tests still fail" all succeeded, completed 02:24:48Z.
- CI on 4fb447d is the authoritative run for the merge re-check.

Not run by me: the full supported-local setup in this container (no Vault or Nomad; it skips here, and CI covered it), macOS (CI covered `./scripts/...`), and the box.

## Bearing on the merge 4fb447d (for the narrow re-check)

- My independent trial merge of efc97e6 onto trunk_dev a5861b7 had one conflict, in `egs/config/config.go`, limited to the import block. I resolved it as `egs/contract` plus `internal/knownkeys`. The resulting tree is **5937c39a8d567e4c65b52cd1c5453806b33e0fe5, identical to the tree of the writer's 4fb447d.** Its parents are efc97e6 and a5861b7. No `egs/model` import remains in Go code; the only mention is a string in the layout guard's own test case.
- On that merged tree and on a5861b7 alone, I ran: `.` (root, which includes the new `service_layout_test.go` guard), `./internal/...`, `./egs/...`, `./ags/...`, `./ars/...`, `./es/config`, `./es/admission`, `./scripts/internal/...`, and `./scripts -run 'ESConfigCheck|UpgradeES'`.
  - Merged: 31 packages pass. Trunk alone: 29 packages pass. The two new packages account for the difference.
  - The scripts subset fails only `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor[/the_payload_directory_belongs_to_another_group]`, on both trees. It fails on fbfd100 in this container too.
  - Lists are in the evidence folder (`trial-merge-*`).
- So the layout guard of #68 accepts `internal/knownkeys` and `scripts/internal/signingkeygen`, and the conflict resolution is the minimal one. What remains for the re-check: CI on 4fb447d, and the merge commit's own provenance.

## Sensitive-material handling

No secret was printed or copied. Keys generated by probes and mutants were throwaway test keys, removed with their folders. The published keys quoted here are public by definition. The box was not contacted.

## Remaining uncertainty and stop conditions

- The F1 shape reasoning is from code plus state.md (no box run).
- CI "build, vet and test" for efc97e6 is partial (cancelled after `scripts` and `es/app`).
- No stop condition hit.

## Confidence

- Provenance: high (≈1.0 for efc97e6: reproduced byte for byte, closing equals opening).
- Validation: high for Linux (full suite on exact bytes vs base, identical failing sets, CI `scripts` and `es/app` pass including real setup). macOS: CI passed `./scripts/...` (signingkeygen included); I did not run macOS myself.
- Implementation: high for the refusal rule, the generator and the renderer's happy path. Medium-high for the renderer's defensive branches, which are correct by reading but not tested (F3).

## Effect status

AUDIT_PERFORMED | REPAIR_NOT_PERFORMED | COMMIT_NOT_PERFORMED | PUSH_NOT_PERFORMED | GITHUB_POST_NOT_PERFORMED | MERGE_NOT_PERFORMED

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/signing-keys/04-pr75-audit.md` (SHA-256 in the thread reply), evidence in `04-pr75-audit-evidence/`.

**Final verdict: BLOCK** (F1, F2, F3 low; F4, F5 observations; no critical, high or medium).
