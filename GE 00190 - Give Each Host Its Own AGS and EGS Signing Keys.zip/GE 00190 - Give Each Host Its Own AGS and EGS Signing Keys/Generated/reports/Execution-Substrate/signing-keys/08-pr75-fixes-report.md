# ES PR #75: fixes for audit 04 and red-team 06

STATUS: READY for a narrow re-audit of the fix delta, then the gate.

- Repository: evo-agi/Execution-Substrate, branch `claude/project-thread-ljwd16`, base `trunk_dev`.
- Audited head: `efc97e6` (merged with trunk_dev #68 as `4fb447d`).
- Fix commits: `b9c80e1` (product and tests), `ab43fd2` (one README sentence).
- Head after this report: `6f83520` (merge of trunk_dev `0b9278c`, #69, docs only; clean merge, no conflict).
- Review delta: `git diff 4fb447d ab43fd2` (24 files). The merge `6f83520` brings only #69's files.

## Finding to fix map

| Finding | Severity | Fix | Proof |
|---|---|---|---|
| RT75-1: ES accepts verification keys anyone can sign for (all-zero among them) | Medium | `internal/knownkeys` also refuses the 14 encodings `crypto/ed25519` decodes to a point of small order (eight points; the two with x = 0 also with the sign bit set; y = p and y = p + 1). AGS and EGS check their `signer`, ES every `verification` key, at config load. Error names the family. | `internal/knownkeys/smallorder_test.go` derives the eight points from the curve, enumerates every encoding under which a keyless signature verifies, and requires the list to equal it; each encoding forged and refused in every public key field of the examples. Removing or changing any entry fails it (repo-validated). |
| RT75-2: AGS/EGS accept a 64-byte private key whose halves do not match | Low | `ags/sign` and `egs/sign` refuse a 64-byte `private_key_hex` whose second half is not the public key of its first half. | `ags/sign/signer_test.go`, `egs/sign/signer_test.go`; fail without the fix (repo-validated). |
| RT75-3 / F2: nothing notices if every install gets the same key again | Low | Test only. | `scripts/internal/signingkeygen/main_test.go` runs the built command several times per role and requires different keys; the audit's mutant G07 (same EGS key every time) and a fixed random source both fail it (repo-validated). |
| RT75-4: only setup keeps signer configs private; AGS/EGS load any mode | Low | `ags/config` and `egs/config` refuse a config that is not a regular file or that other users can read or write (checked on the opened file; 0640 for the service's group is fine). README and the ES bring-up runbook say 0600 or 0640. | `internal/knownkeys/signer_config_mode_test.go` (modes, links, folders); fails without the fix (repo-validated). |
| F3: renderer key-file and config-write defenses untested | Low | Test only. | `scripts/supported_local_signing_keys_test.go`: key folder 0700, key files 0600, refusal of key files others can reach, links, a folder in place of a file, other formats, a config already there, and (as root) a key file another user owns. The audit's six surviving renderer mutants (R01, R02, R03, R05, R08, R10) each fail it (repo-validated). The root-only case has a `skips-itself` line in both CI lists. |
| F1: the box's migration trigger is the startup refusal, not the upgrade's esconfigcheck | Low (wording) | PR body and contracts.md now say AGS, EGS and ES refusing to start is what stops the box; the Remote Alpha ES upgrade does not reach `esconfigcheck` on the box today; the older ES binary deployment had no config check, and #76 adds the ES, AGS and EGS checks to it. | PR #75 body updated 2026-11-27 (thread-reported). |
| F4: contract sentence on repository keys claims more than the scan checks | Observation | contracts.md now says "every value given to a signer or verification key field (`private_key_hex`, `public_key_hex`) in the repository is a known key", which is what the scan checks. | Doc only. |
| F5: negated point of a known key is not refused | Observation, no action | None, per the audit. | Recorded so it is not rediscovered as new. |

## Merge with trunk_dev

trunk_dev moved from `a5861b7` to `0b9278c` (#69: PLANS.md standing-rule sections moved out, claim ledger cites ES docs by section, heading-link contract test). It is merged into the branch as `6f83520` (no rebase; no conflict). After the merge, the root package (docs contract tests including the new heading-link test), `internal/knownkeys` (the repository key scan) and `internal/testutil` pass. PLANS.md is 131205 bytes (cap 150000).

## Validation (Linux cloud container, as root)

- `gofmt -l` and `go vet` on the changed packages: clean.
- `go test -count=1 ./...` at `b9c80e1`: every package passes except 55 tests that fail the same way on `trunk_dev` in this container (`es/app` 14, `scripts` 38, `es/admission/internal/reliablesubmit` 3); the failing set was compared test by test with a `trunk_dev` run in the same container. They come from this container (root, the HTTPS proxy, no Nomad leader or kernel firewall); CI is the check that counts for them.
- The root-only renderer test passes under `env -i PATH=/usr/bin:/bin` as root, as the CI root step runs it.

## Not done here

- No box run. The box stays on the published keys until #76's rotation runs on a box turn.
- Private keys stay inline in the configs (reopened seam in contracts.md).
