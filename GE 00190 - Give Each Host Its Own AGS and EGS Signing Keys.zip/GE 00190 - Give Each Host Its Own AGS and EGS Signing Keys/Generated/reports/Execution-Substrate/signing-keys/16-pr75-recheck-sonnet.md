# Narrow re-check of ES PR #75 at 827686a (delta ec9a5b9..827686a): the test-path guard accepts `.git` ([model withheld])

**Verdict: ACCEPT for the delta, with two observations and no Low or higher finding. CI on 827686a passed on both jobs (read at 08:03Z; see "CI").**

The fix works and is the right size. At `ec9a5b9` I reproduced R15-1 in a tree made with `git archive`; at `827686a` the same tree, and a git clone, pass. The delta is one file and adds nothing else. The guard's self-test kills the four natural ways to get the change wrong (revert it, accept the first element `.git`, accept any `.git` prefix, accept everything). It does not pin that the exception is *exactly* `.git`: four narrower-than-nothing widenings survive (O16-1). A four-line addition that kills them is written and verified, if you want the "exactly" claim pinned.

**Not blind.** This is the real run of a paired check, and I was shown more than I should have been. Details in "Trial status". I did not open Opus reports 12 or 15.

| Field | Value |
| --- | --- |
| Model | `[model withheld]`, trial category R-S (security PR, test-only delta), real run, paired with an Opus run |
| Subagents | None |
| Posture | Read-only. Nothing pushed, posted or merged. The box and other machines untouched |
| Report | `reports/Execution-Substrate/signing-keys/16-pr75-recheck-sonnet.md`; evidence in `16-pr75-recheck-sonnet-evidence/` (`SHA256SUMS` inside) |

## Target and scope

| Item | Value |
| --- | --- |
| Repository, PR | evo-agi/Execution-Substrate #75, branch `claude/project-thread-ljwd16`, open, not draft; head read through the GitHub tool at 07:15Z and again at 07:24Z |
| Head | `827686a28dcb8d5e01465a401d96dc1ba61557a6`, tree `8c9a9b2b789f10de01bd6a0ffdc552ac686cd82e` |
| Previous head | `ec9a5b947e0335590c8dc1311153180702fe26a1`, tree `a74868bfc8d3738a2e000e6e92978ffa7a50abac` (the head of the earlier re-checks 15) |
| Base | `trunk_dev` `0b9278ca74404b46b5e9f0e1701874b52687f5e8` (unchanged) |
| Scope | The delta only: whether `internal/testutil`'s test-path guard now accepts exactly `.git` (R15-1), whether its self-test pins that, whether the rest of the delta adds anything, and CI. The earlier findings (R75-1..3, O1..O6) were verified by re-checks 13 to 15 and are not re-judged here |
| Delta | One commit, parent `ec9a5b9`, one file: `internal/testutil/testutil_test.go`, +7 −1, mode `100644`, blob `19c3113…` → `026ed93…`. Commit message names R15-1 |

## Provenance (v2 recipe, hash `c08597e2…a1ca` verified before every run)

Manifests were taken with HEAD at the base, the topic bytes in the working tree, the branch checked out under its own name `claude/project-thread-ljwd16`, upstream pinned to `origin/trunk_dev`, each run twice into a mode-0700 folder outside the repo (identical), then a third run after the work (closing = opening).

| Head | Paths | `manifest_sha256` | `textual_diff_sha256` |
|---|---|---|---|
| `ec9a5b9` | 38 | `05f70f34869e25d1d3e4ccc0dd93aa2d32f41b1ac2edbe9fd95e55bebbfcea19` | `a8d2b7c853fa170b8b6ff04d72da19f8c54c03309ebac63461061eef33a870de` |
| `827686a` | 39 | `cddd3cca7cde2eded655c50b9015cd4d7cb65bcd939ac2cb7e3728bec89fe85c` | `17985d340ffc38c6630f48679f8edb303f6fc2d0e03825aa2c777b739558bb2e` |

- The `ec9a5b9` row equals the writer's report 14 byte for byte (its Manifests table), so my reproduction matches theirs.
- **No writer manifest exists yet for `827686a`** (none in the project files at 07:24Z, none in the PR body), so I could not compare the new row to a writer value. What I can show: the 38 shared records are identical between the two heads (path, kind, mode, size, SHA-256), and the only change to the path set is the added `internal/testutil/testutil_test.go` (it was not in the PR's changed set before, because the PR had not touched it). `provenance/manifest-delta.txt`.
- Committed blobs: for all 39 records, SHA-256, size and exec bit of `git show 827686a:PATH` equal the record. 0 mismatches.
- The manifest records the branch name. My first run used a scratch branch name and gave other hashes (`8901efa1…`, `13eae018…`); I discarded them and reran under the PR's branch name.

## Findings

None of Low or higher.

### O16-1 Observation (test strength): the self-test does not pin "exactly `.git`"

`internal/testutil/testutil_test.go` `anchoredProblem`, the new clause `known == ".git"` (line 686), and the self-test `TestRepoPathCheckFindsEachKindOfProblem`. The commit message says the guard "accepts exactly `.git`; its self-test requires that and still refuses `.git/HEAD`". The self-test requires `.git` accepted (new line 385 of the accepted fixture) and `.git/HEAD` refused (new line 327, expected `bad.go:108`). That pins the two ends. Mutants of the clause, run against `827686a` as pushed (`mutants/run1-827686a-as-pushed.txt`, own `mutants.py.txt`):

| Mutant | Result as pushed | With the proposed addition |
|---|---|---|
| G1 revert (no `.git` clause) | killed (`TestRepoPathCheckFindsEachKindOfProblem`, and `TestImportersNameRepositoryPathsFromTheRoot` in a tree without `.git`) | killed |
| G2 first element `.git` (accepts `.git/HEAD`) | killed | killed |
| G3 `HasPrefix(known, ".git")` | killed | killed |
| G4 accept everything | killed | killed |
| G5 any single name starting `.git` (`.gitx`, `.github`) | **survives** | killed |
| G6 also a partial `.git/` + unknown | **survives** | killed |
| G7 `filepath.Clean(known) == ".git"` (accepts `./.git`, `.git/`, `.git/.`) | **survives** | killed |
| G9 also the whole value `.git/` | **survives** | killed |
| G8 `v.text == ".git"` instead of `known` | survives, **equivalent** (when `known` is ok and the value is partial, the text has a "/"; when whole, `known` is the text) | survives (equivalent) |

Why I rate it an observation and not a Low: every survivor only widens the exception, none touches product code, and the widenings matter only for names that do not exist at the root (`.gitx`) or for spellings of one that does (`./.git`); a test that then looked for a missing name would fail or find nothing on its own. G5 is the only one that weakens the guard's purpose (a mistyped root name starting `.git` would pass in CI clones too). If you want the claim pinned (the project's habit for guard exceptions), add two lines to the bad fixture and two expected lines; `mutants/proposed-selftest-addition.diff`, verified: passes on `827686a` in a tree without `.git` and in a clone, and kills G5, G6, G7, G9.

```
	filepath.Join(testutil.Root, ".gitx")
	filepath.Join(testutil.Root, ".git/"+unknown)
	...
		`bad.go:109: filepath.Join resolves ".gitx" against the repository root, which holds no such name`,
		`bad.go:110: filepath.Join resolves ".git/" against the repository root, which holds no such name`,
```

### O16-2 Observation (PR body)

The PR body (read 07:24Z) ends its validation at `ec9a5b9` and does not name `827686a` or the guard exception. Its "Tests" list says nothing about `internal/testutil`'s guard, and the PR now changes a file that `trunk_dev` owns. Nothing in it is false: "Security widening: None" still holds and no claim is made about `827686a`. One sentence in "Tests" and one line in "Validation" would fix it. The writer needs to do this before the audit trail is read from GitHub.

## What I verified

1. **R15-1 reproduces at `ec9a5b9`** (control). A `git archive` copy of `ec9a5b9` (no `.git`), run as a normal user (`ci`, umask 022, clean env): `go test ./internal/testutil ./internal/knownkeys` → `TestImportersNameRepositoryPathsFromTheRoot` fails with `internal/knownkeys/repository_test.go:25: filepath.Join resolves ".git" against the repository root, which holds no such name`; `internal/knownkeys` passes. `tests/control-archive-ec9a5b9-testutil-knownkeys.txt`.
2. **Fixed at `827686a`.** Same kind of tree: both packages pass (20 of 20 tests in the two packages, `-v`). A real clone (`.git` present, so `knownkeys` takes the `git ls-files` path): both pass.
3. **Wider set, as in the earlier rounds.** `.`, `./internal/...`, `./ags/...`, `./egs/...`, `./es/config`, `./scripts/internal/...` in a `git archive` tree: `ec9a5b9` has exactly one failing test (the one above) and `827686a` none. `tests/archive-*-wider-set.txt`. This is the check that finds `.git` dependence the CI clones hide.
4. **The code is the claimed change.** `known` is the whole text for a whole value, and for a partial value the text up to and including its last "/" (`knownElements`), so `known == ".git"` can only hold for the whole value `.git`. `.git/HEAD`, `.git/` and `./.git` are not accepted. `first == "."` and `first == ".."` are unchanged. Only `anchoredProblem` changed: `pathProblem` and `commandProblem` (package-relative checks) are untouched, so a bare `.git` as a package-relative path is still judged by the tree as before.
5. **The self-test cannot be fooled by the tree it runs in.** It builds its own root in `t.TempDir()` with no `.git`, so the same fixture and expectations hold in a clone and in an archive tree (checked: it passes in both).
6. **The rest of the delta adds nothing.** One file, 7 insertions and 1 deletion: a 4-line comment and the clause in the guard, one line in the refused fixture, one in the accepted fixture, one expected line. `git diff --check` clean; `gofmt -l` and `go vet ./internal/testutil` clean; no new files, no mode change, no binary or build artifacts in the PR's path set (the three `.tar.gz` fixtures under `.examples/` are `trunk_dev`'s, not in the PR).
7. **No other `.git` dependence found.** `grep` over all Go files: the other uses are `artifact_hygiene_test.go` at the root (skipped by the guard, and it handles a missing `.git` and passes in the archive tree), directory walkers that skip a `.git` name (`es/admission` guardrails, `reliablesubmit`), and docs text. None joins `.git` to the root in a package the guard scans.

## Limit of the guard, not a finding

The guard asks the tree it runs in whether a root name exists. In a clone `.git/HEAD` therefore passes (the root holds `.git`); the self-test's refusal of `.git/HEAD` comes from its own root without `.git`. So CI cannot catch a future test that reads `.git/…` unconditionally; only a run in an archive tree can. That is how the guard was designed and is not changed here; it is the reason a `git archive` run belongs in every such check.

## CI on 827686a (the point of the brief)

| Job | Run | State (first read 07:24Z, final read 08:03Z) |
|---|---|---|
| build, vet and test | `go` run 397 (`…/actions/runs/45957080014`), started 07:14:20Z | **success**, completed 08:00:16Z (head `827686a`) |
| test on macOS | `go-macos` run 144 (`…/actions/runs/45957080008`), started 07:14:20Z | **success**, completed 07:46:31Z |

Earlier Linux runs on this PR took 45 to 46 minutes (runs 365 and 374), and this one ended at 08:00Z (Linux) and 07:46Z (macOS). **CI has never completed on `ec9a5b9`'s content:** the Linux run 392 and the macOS run 139 on `ec9a5b9` were both cancelled (07:14:37Z and 07:14:43Z) when `827686a` was pushed, so this is the first full run on either OS that includes the re-check fixes (the folder-owner test, the config-mode tests). The macOS jobs of the earlier heads took about 40 minutes. The CI result is therefore worth reading, not just a formality. Final read at 08:03Z: both jobs completed with conclusion success on head `827686a28dcb8d5e01465a401d96dc1ba61557a6` (checked on the PR's check runs and on run 397's `head_sha`). I did not read the job logs, so I can not say which tests ran; that both finished green is what I rely on, and it includes the root step and the macOS job that I could not run here.

CI result: **success on both jobs**

## Validation assessment

- Re-run by me, on the exact bytes: items 1 to 3 and the mutant runs, as a normal user (not root), Go 1.26.5, with the module cache filled once through the proxy.
- Not re-run: the full suite (`./...`), `es/admission`, `es/app`, `scripts` (container-only failures as in earlier rounds), and anything as root. The delta touches no code those packages use.
- Container-only: the Linux box and Nomad/Vault/SPIRE paths are out of scope for this delta.

## Trial status (blind or not)

- I did not open `12-pr75-recheck-opus.md`, `15-pr75-recheck-opus.md` or their evidence folders.
- The harness put into my context, before I started, memory notes that summarise the Opus re-checks of this PR, including re-check 15's R15-1 and its prototype repair (accept `.git` in the guard's `anchoredProblem`, plus a self-test case). That is the shape the writer then pushed.
- The coordinator's brief names R15-1, the file and the fix.
- I read the whole shared trial log as part of the procedure, so I saw the Opus pair row for `ec9a5b9` (R15-1 and what it verified fixed) and the Sonnet row S15-1.
- I read the first 25 lines of the sibling Sonnet report 15, for layout.
- When I appended my trial row, my script printed the first 90 characters of the Opus pair's row for `827686a` (added minutes before): its category (`R-S`, test-only delta) and head, no finding. I took its category label for mine.
- Consequence: I was never in a position to find R15-1 myself, so it is not a test of that. What this check does test independently: that the fix works (control reproduced, own runs), and the mutant analysis (O16-1), which I wrote and ran myself; I never opened a comparison report.

## Confidence

| | |
|---|---|
| Provenance | 0.9. Both manifests reproduced and stable; the `ec9a5b9` one equals the writer's; no writer value yet for `827686a`, so that head is bound by my reproduction and the blob check only |
| Validation | 0.85. The exact bytes ran in the tree types that matter; wider suites not run by me; CI is green on both jobs |
| Implementation | 0.9 for the delta, and it does not extend to the rest of the PR |

## Effect status

Repair, commit, push, PR change, comment and merge: not performed. I wrote this report, its evidence folder, and one row in the shared trial log. In this container only: created a local user `ci` and a copy of the Go 1.26.5 toolchain under `/opt`, and ran the tests in throwaway trees under `/home/ci/w`.
