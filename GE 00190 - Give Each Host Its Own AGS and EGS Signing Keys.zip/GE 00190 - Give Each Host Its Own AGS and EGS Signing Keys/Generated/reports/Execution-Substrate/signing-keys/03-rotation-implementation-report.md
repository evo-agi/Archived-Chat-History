# IMPLEMENTATION REPORT: Remote Alpha signing key rotation (ES PR #76)

Thread: "Give each host its own signing key". Date: 2026-11-27 (UTC).

- Objective: a scripted, reversible rotation that gives the Remote Alpha box its own AGS and EGS keys and points EGS and ES at them (the box is on the published keys, which #75 makes every service refuse).
- Repository: evo-agi/Execution-Substrate
- Base ref and SHA: PR #75 head, origin/claude/project-thread-ljwd16 efc97e668174e26aab1c555843321b442aade686 (stacked PR; the coordinator asked for a separate follow-up PR on a new claude/* branch, 01:56Z). When #75 merges, GitHub retargets #76 to trunk_dev.
- Topic branch: claude/signing-key-rotation
- Topic commit SHA: e423ad650050a1c2b535a8cc22b706e7f86b4006
- Tree SHA: 9d8c39e3d7977152a84647a27e71325744c19d71
- PR: https://github.com/evo-agi/Execution-Substrate/pull/76 (ready for review, assigned SeritArbores)
- Final working-tree status: clean after the one commit.
- Diff:  7 files changed, 1618 insertions(+), 1 deletion(-)

## Reconnaissance (repo-validated at efc97e6 unless marked)

- ES fetches and verifies EGS's trust policy with verification.trust_model in Service.Initialize before it listens (es/app/app.go Start -> es/admission/service.go Initialize/fetchVerifiedTrustModel), so ES answering after the restart proves the EGS key and ES agree.
- ES checks each artifact's evidence seal against verification.provenance (es/admission/service.go:680) and EGS's allowed/revoked signers (enforceTrustModel, service.go:765-797).
- Box layout (thread-reported, 01-box-key-check.md): ags.json root:ags 0640, egs.json root:egs 0640, es.json root:es 0640; EGS allowed ["ags-key-1"], revoked []; ES verification entries equal the AGS/EGS signer keys; ARS index 164 entries.
- Conventions copied from scripts/internal/remote_alpha_upgrade_es.py (host root for tests, read_regular_file, atomic_replace, backup manifest, interrupt handling, health URLs from healthcheck.env, summary.json). Copied rather than imported: the upgrade module is under active change in PRs #63, #67, #73.
- PR #73 (claude/wi-2-network-grants de4ade8) adds admission_policy.workload_grants rules with signer_key_id = verification.provenance.key_id, and its ES upgrade refuses an admission_policy other than "today's grants". The rotation updates every rule's signer_key_id, so either order (rotation before or after an upgrade with grants) stays consistent.

## Implementation decision

- Bounded slice rule (documented in remote_supported_host_alpha.md "Remote Signing Key Rotation"): check / apply / rollback, root only, configs only.
- Keys from the host's /usr/bin/openssl (genpkey ED25519, pkey -pubout; strict 48/44-byte DER prefixes), not from a binary built from the checkout, so no build/payload provenance step is needed and nothing user-built runs as root. Key ID and signer object identical to signingkeygen (tested).
- EGS: new AGS key ID replaces the old in allowed_signers, old added to revoked_signers (defense in depth), publication.update_revision + 1.
- Restart order: stop es, restart egs, restart ags, start es; wait <= 60 s for units active and ES /health, ES /v1/executions:contract, AGS /health 200.
- Rollback on any failure or SIGTERM/SIGHUP/SIGINT after the backup.
- Old artifacts not re-signed (would launder possible forgeries); needed ones are re-published from source. Backup holds old private keys: docs say delete it after the smoke test.
- Not changed: binaries, unit files, TLS, ARS.

## Files touched (7)

| Path | Classification | Summary |
|---|---|---|
| scripts/remote_alpha_rotate_signing_keys.sh | script (new) | wrapper, python3 -I -B |
| scripts/internal/remote_alpha_rotate_signing_keys.py | script (new) | check/apply/rollback |
| scripts/remote_alpha_rotate_signing_keys_test.go | test (new) | host-shaped folder, fake systemctl/curl/openssl, real openssl test |
| .docs/system_overview/remote_supported_host_alpha.md | docs | new section "Remote Signing Key Rotation" |
| .docs/system_overview/configuration.md, contracts.md, PLANS.md | docs | pointers |

## Validation (Linux cloud container, root, Go 1.26.5)

| Command | Result |
|---|---|
| gofmt -l scripts/*.go; go vet ./scripts | clean |
| go test -count=1 -v ./scripts -run TestSigningKeyRotation | 7 tests and 14 subtests, all PASS |
| 9 hand mutants of the helper (revoked append, restart order, restore, known-seed check, grant update, health wait, grant check, mode check, key ID length) | each FAILs the rotation tests; helper restored byte-identical |
| go test -count=1 ./scripts (after all edits) | 38 failures, identical to the trunk_dev base set in this container (02-test-logs/cmp-base-scripts.fails vs rotation-head-scripts.fails: no difference) |
| go test -count=1 . ./internal/knownkeys (after all edits) | ok |

## Failed or skipped validation

- TestSigningKeyRotationKeysFromOpenSSL uses /usr/bin/openssl. It passes here (OpenSSL 3.0.13, as on the box). On the macOS CI runner /usr/bin/openssl is LibreSSL, which may lack Ed25519 genpkey (inference); if it fails there it goes on the macOS environment-only list with that reason.
- Not run on the box (separate box turn after audit).
- es/app and other packages not re-run: this PR touches only scripts and docs.

## Dependencies changed / Artifact hygiene

None. __pycache__ removed before the manifest.

## Authority/security/protocol widening

None. Replaces keys only; same trust topology; old AGS key ID revoked. Private keys never in argv, env or output; only in the rewritten configs (0640 root:<service>, as before) and the root-only backup.

## Provenance

- Recipe: governed-execution.audit-patch-manifest.v2, source SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified)
- HEAD at base efc97e6, upstream pinned to origin/claude/project-thread-ljwd16 (the stacked base), nothing staged; run twice, byte-identical
- Textual-diff SHA-256: 502894fa5ed34a88c9d2170735e4e047071f023ada53140ae1faf7aeecbcc432
- Canonical-manifest SHA-256: 0954c8decb9f0e1a25a0bb1d8f559e24b83c99819f8ea79483702a59829de4a7
- File count 7; staged set equals manifest set; one commit; clean status
- Manifest file: 03-rotation-manifest-v2.json; full JSON:

```json
{"branch":"claude/signing-key-rotation","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/configuration.md","sha256":"d5cfb3199aea8f6a2a16906be17bb127fc7a3b098d4ab856f4a3f8874b62426f","size":135407},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/contracts.md","sha256":"c5beaa308fc1a340424c88acd6a083efec3b7900b5d95d4dd153bc5a91b1a1a7","size":93559},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/remote_supported_host_alpha.md","sha256":"f809049f35198b0161f41fa66c18b98c3d92af5d15ead232216d5e7e83689933","size":412731},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"928534b206092bdceda930d2871433ec392efcd9aa983ea13dd773043c139373","size":149981},{"file_type":"regular","kind":"untracked","mode":"0644","path":"scripts/internal/remote_alpha_rotate_signing_keys.py","sha256":"9b4f94636b4bfe221d43dd205d27cca37092d160f16008a7abe8b2930c6e0e8f","size":30158},{"file_type":"regular","kind":"untracked","mode":"0755","path":"scripts/remote_alpha_rotate_signing_keys.sh","sha256":"f2f74fb740a523ad9ef6935c7f3a2f167439096612a0f7d607b5b98509ebc249","size":740},{"file_type":"regular","kind":"untracked","mode":"0644","path":"scripts/remote_alpha_rotate_signing_keys_test.go","sha256":"b3fea51cb516002f9dd41685dac3978268f4e40d608a3d70e4b90523ee92bd22","size":26859}],"head":"efc97e668174e26aab1c555843321b442aade686","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"502894fa5ed34a88c9d2170735e4e047071f023ada53140ae1faf7aeecbcc432","upstream":"origin/claude/project-thread-ljwd16"}
```

## Box run plan (needs the coordinator's box turn after audit, and #75 + #76 merged)

1. Fresh clone at the merged trunk_dev commit, chown -R root:root.
2. sudo scripts/remote_alpha_rotate_signing_keys.sh check: expect result ready, current keys ags-key-1/egs-key-1 with private_seed_is_one_byte_repeated true, ars_index_entries 164.
3. sudo systemd-run --unit=signing-key-rotation -p KillMode=mixed -p TimeoutStopSec=300 --wait --collect <clone>/scripts/remote_alpha_rotate_signing_keys.sh apply; read summary.json in the backup folder (result rotated).
4. Smoke: a fresh publish, prepare and submit with the operator certificate (scripts/60_execute_loop.sh on the box), proving the new AGS key verifies at ES.
5. Delete the backup folder (holds the old private keys).
6. Then the ES upgrade may run; its config check no longer refuses the box.
7. Archived-Runbooks history line.

## Assumptions / unresolved seams

- Box ES verification entries carry algorithm ed25519 (ES config validation requires it; check confirms before apply).
- Healthcheck operator cert can reach ES /health and AGS /health (the ES upgrade uses the same URLs).
- Reopened seam unchanged: inline key custody (contracts.md 3B, section 12).

## Confidence

- Provenance: high. Validation: high for the script logic (tests + mutants); medium for the box until the box run. Implementation: high.

## Effect status

TOPIC_BRANCH_PUSHED | PR_OPENED https://github.com/evo-agi/Execution-Substrate/pull/76 (ready, stacked on #75) | MERGE_NOT_PERFORMED | INDEPENDENT_AUDIT_NOT_PERFORMED | BOX_NOT_TOUCHED

## Follow-up commit c73b499 (2026-11-27 02:40Z)

The macOS CI job failed `TestSigningKeyRotationKeysFromOpenSSL` with "Algorithm ED25519 not found": the runner's `/usr/bin/openssl` is LibreSSL (repo-validated from the job log, run 45927862331). The rotation runs only on the Linux box, whose openssl is OpenSSL, so the test now skips itself when `runtime.GOOS != "linux"` and `.github/ci/environment-only-tests-macos.txt` names it under the tests that skip themselves, with that reason. On Linux a missing or unfit openssl still fails it. Checked: gofmt, `go vet ./scripts` (linux and darwin), rotation tests pass. No helper change. PR #76 head is now c73b499.
