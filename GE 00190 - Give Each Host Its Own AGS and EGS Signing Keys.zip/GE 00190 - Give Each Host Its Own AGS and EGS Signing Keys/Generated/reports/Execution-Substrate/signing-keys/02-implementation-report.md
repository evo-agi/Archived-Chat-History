# IMPLEMENTATION REPORT: give each host its own signing key (ES PR #75)

Thread: "Give each host its own signing key". Writer: implementation thread. Date: 2026-11-27 (UTC).

- Objective: supported-local installs and the Remote Alpha box signed with the AGS and EGS keys published in the repo; make each host use its own keys, make services refuse the published keys, and plan the migration.
- Repository: evo-agi/Execution-Substrate
- Base ref and SHA: origin/trunk_dev fbfd100946d2cb8f25232bac182b94fb299c66da (moved from 39e19de during the work; rebased by stash, one PLANS.md conflict resolved by keeping upstream's two bullets and adding this change's bullet after them)
- Topic branch: claude/project-thread-ljwd16
- Topic commit SHA: efc97e668174e26aab1c555843321b442aade686
- Tree SHA: 6b4d09ece87617c882a8416e2f68cd2a54cfbc64
- PR: https://github.com/evo-agi/Execution-Substrate/pull/75 (opened as draft, marked ready for review; assigned SeritArbores; review request refused by GitHub because SeritArbores is the PR author)
- Final working-tree status: clean after the one commit (`git status --porcelain` empty).

## Reconnaissance

No subagents. Facts confirmed directly (repo-validated at 39e19de, still true at fbfd100):

- Published AGS key seed 0x11 x32 (key ID ags-key-1, public d04ab232...8737) and EGS key seed 0x33 x32 (egs-key-1, public 17cb79fb...80ce) in .examples/config/{ags,ags.operator_and_control_plane,egs,es,es.operator_and_control_plane,es.configured_literal_policy_demo}.json and in the config renderer of scripts/72_supported_local_setup.sh (lines 1363-1431 at fbfd100).
- ES verifies each artifact's evidence seal against verification.provenance (es/admission/service.go:680 at fbfd100) and the EGS trust policy against verification.trust_model (service.go:748-760).
- Box [home network address withheld] (thread-reported, read-only check 2026-11-27 01:23Z, 01-box-key-check.md): AGS, EGS and ES all on the published keys; EGS allowed_signers ["ags-key-1"]; ARS index 164 records.

## Implementation decision

- Contract/invariant (new, contracts.md 3B): AGS, EGS, ES refuse at config load any Ed25519 key whose 32-byte seed is one byte repeated (256 keys). One shared package internal/knownkeys; each service keeps its own config.
- Supported-local setup generates a fresh AGS and EGS key per proof root (scripts/internal/signingkeygen, crypto/rand), wires EGS allowed_signers and the 4 ES verification entries, writes all 4 configs O_EXCL|O_NOFOLLOW 0600, removes the key files and folder. Setup already requires Go at preflight (supported_local_setup_requires_local_go returns 0), and refuses an existing proof root (mkdir without -p), so it never reuses old keys.
- Key ID = role + "-" + first 16 hex of SHA-256(public key).
- Examples keep the known keys as refused templates (decision: a copied example must fail loudly rather than look valid). egs.json reshaped from stale trust_model to current runtime_trust + publication (stale shape fix, keys unchanged).
- Machine-enforced migration trigger: the refusal sits in config loading, so scripts/internal/esconfigcheck (run by the Remote Alpha upgrade in inspect and before atomic_replace in install_es, scripts/internal/remote_alpha_upgrade_es.py:1222 and :1426) refuses the box until its keys rotate. Test case "published signing keys" in scripts/remote_alpha_upgrade_es_config_check_test.go pins it.
- Current-contract treatment: no API, wire or DTO change. Strategic-target treatment: none. Compatibility edges: none (the rule keeps no old key working).
- Reopened seam (recorded in contracts.md 3B and section 12): private keys inline in AGS/EGS config files; separate key file or custody service and rotation as a service operation not designed.

## Files touched (26; 1402+/35-)

| Path | Classification | Summary |
|---|---|---|
| internal/knownkeys/knownkeys.go | product (new) | Check / CheckPrivate for the 256 known keys |
| ags/config/config.go, egs/config/config.go | product | signer refused when known (seed or 64-byte key, both halves, and public key) |
| es/config/config.go | product | every verification key refused when known |
| scripts/internal/signingkeygen/main.go | script (new) | per-host key generator, 0600 new file, prints public part only |
| scripts/72_supported_local_setup.sh | script | generates keys per proof root, renderer reads them strictly, configs 0600, key files removed |
| internal/testutil/testutil.go | test helper | WithFreshSigningKeys (per-test key per key ID, mutex-guarded) |
| internal/knownkeys/*_test.go (4) | test (new) | rule, all examples, per-field table, repo scan for acceptable key values outside Go tests |
| internal/testutil/signingkeys_test.go | test (new) | helper keeps IDs, shares keys per ID within a test, differs across tests |
| scripts/internal/signingkeygen/*_test.go (2) | test (new) | mode under umask 0, pair, ID, refusals, stdout public only, usage exit 2 |
| es/admission/service_direct_test.go | test | render test runs key generation and checks rendered configs |
| es/config/config_test.go, internal/callerallowlist/caller_allowlist_contract_test.go, scripts/remote_alpha_upgrade_es{,_host,_config_check}_test.go | test | use fresh keys; config check case for published keys |
| .examples/config/egs.json, README.md | example | egs.json shape fix; README says keys are refused templates |
| .docs/system_overview/configuration.md, contracts.md, PLANS.md, .runbooks/system/Governed Execution ES System Bring-Up.md | docs | Signing keys section, 3B, seam line, plan fact, runbook step |

## Validation (Linux cloud container, root, Go 1.26.5 via $(go env GOROOT)/bin)

| Command | Result |
|---|---|
| gofmt -l on changed packages | empty |
| go build ./... | exit 0 |
| go vet ./... | exit 0 |
| go test -count=1 ./... (on fbfd100 + change, before two late edits) | exit 1: failures only in es/admission (18), es/admission/internal/reliablesubmit (3), es/app (14), internal/callerauth (2), scripts (38). Log: 02-test-logs/test-all2.txt |
| go mod download, then the 18 es/admission failures re-run | ok (they were darwin modules missing from the module cache, GOPROXY=off guards) |
| failing tests of es/app, internal/callerauth, scripts, reliablesubmit re-run on a clean fbfd100 worktree and on head | identical failing sets (es/app 14/14, scripts 38/38, reliablesubmit 3/3; callerauth 0/0 after module download). Lists: 02-test-logs/cmp-*.fails |
| go test -count=1 . ./internal/knownkeys ./internal/testutil ./scripts/internal/signingkeygen ./es/config ./internal/callerallowlist (after late edits) | all ok |
| go test -count=1 ./scripts -run 'ESConfigCheck\|UpgradeES' (after late edits) | ok, 17 pass, 1 skip (TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS, needs real Nomad) |
| go test -count=1 -v ./es/admission -run TestRetainedResultAuditF1RenderedConfigConstructsConfiguredService | PASS |

Late edits after the full run: configuration.md migration/re-publish sentences, contracts.md section 12 line, testutil mutex, new internal/testutil/signingkeys_test.go. Every package they touch was re-run as above.

## Failed or skipped validation

- 55 tests fail in this container on base and head alike (14 on .github/ci/environment-only-tests.txt; the rest inferred to be container limits: root user, curl through the container HTTPS proxy, no Nomad leader, no kernel firewall). CI on PR #75 is the authoritative run for them.
- Full supported-local setup on a real Linux host not run. The render step with key generation is covered by the es/admission render test.
- macOS not run locally (CI "test on macOS" covers it).
- Box not touched by this PR.

## Dependencies changed

None (go.mod, go.sum unchanged; new code uses only the standard library).

## Artifact hygiene

Removed scripts/internal/__pycache__/ (created by this thread's test runs, gitignored) and the temporary base worktree. No build output, caches or databases in the commit.

## Authority/security/protocol widening

None. The change only adds refusals; new installs hold keys only their host knows. Private keys never reach stdout, stderr, argv or environment (signingkeygen), and the setup renderer refuses a key file that is not a regular 0600-class file owned by the running user.

## Cross-repo impact

None in other repos. Same-repo: PR #73 (workload grants) setup line provenance_key_id = "ags-key-1" must take the generated AGS key ID, and its tests that load example es.json need testutil.WithFreshSigningKeys; whichever lands second ports.

## Provenance

- Recipe ID: governed-execution.audit-patch-manifest.v2
- Recipe source SHA-256: c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified with sha256sum -c)
- Textual-diff SHA-256: 9486b14c58d58978186da22d31feb540a6408d5e559387a98f5515cfc6e94a54
- Canonical-manifest SHA-256: 74400b3c3e15b4b6a794b0631b4631c2fdffc52ce4a038d8e19cb11a9c0143ef
- File count: 26
- Run twice to two absent paths in a fresh 0700 directory outside the repo: byte-identical. HEAD at base, upstream pinned to origin/trunk_dev, nothing staged.
- Staged-set check: git diff --cached --name-only --no-renames equals the manifest's 26 paths.
- Clean status after the one commit: yes.
- Complete canonical manifest: 02-manifest-v2.json in this folder (SHA-256 above), reproduced here:

```json
{"branch":"claude/project-thread-ljwd16","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/configuration.md","sha256":"0371b1fcd940413ae65e875a8313d2b03de5cbfe77ea167e282758b404255b91","size":135178},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/contracts.md","sha256":"fa5c1e73744c3efe857bb84887c5b5670f2b4afdb48b878c48682dad24622db8","size":93387},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".examples/config/README.md","sha256":"03cbf8d08442b18dcde3268f04d9c4573f9bece955654f9ae817a24d47fe9dd9","size":2040},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".examples/config/egs.json","sha256":"7b053b097fefe9d8c522db147db445627bdcb64f3e2ae737afbe370ebb59cc54","size":953},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".runbooks/system/Governed Execution ES System Bring-Up.md","sha256":"158ccabd420b4f3d34decc82766f1bd2a092a98682779a214c0bb3c4248f88a7","size":45878},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"fe0fe2a497bd0c39aafeadcbfec95bfd53840be9b76336a329b51d19fde3ce47","size":149781},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"ags/config/config.go","sha256":"686f457d03b40678a73c814a3d8a54f9c0a43d8b791a5780f894c7e3f8474f53","size":6649},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"egs/config/config.go","sha256":"da29e4d7fc26bf4e64f2b539fb78ba44aea25a48a322841907ca14e1659f9721","size":4963},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/service_direct_test.go","sha256":"dce95b972b424650d60e84425230ec874fe35785f1fdd4bb5624fddfea54f0c0","size":44335},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/config/config.go","sha256":"be57f44bf604e1653cca8dd3f948cd95d590ff5817596afa29772c2e38c48851","size":28436},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/config/config_test.go","sha256":"ee2c5c3aa2da698735d063571299842cbc2d06373f5ed795463d5ec86bd4e0e8","size":50490},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"internal/callerallowlist/caller_allowlist_contract_test.go","sha256":"48e20e06d717f7435de7fd668a5a50cad431beb44c9df18090104c6e9cafc9ce","size":4466},{"file_type":"regular","kind":"untracked","mode":"0644","path":"internal/knownkeys/examples_test.go","sha256":"84c35973776e0b9620ad15cb1ff1e706c16f5b3c8e264a1ef17ee870d0b3992f","size":6163},{"file_type":"regular","kind":"untracked","mode":"0644","path":"internal/knownkeys/knownkeys.go","sha256":"6b223edd07c8f058f5deb90819cc1b50c7b85c77f457184120d18024be31f7fd","size":3026},{"file_type":"regular","kind":"untracked","mode":"0644","path":"internal/knownkeys/knownkeys_test.go","sha256":"3b5a8305abdaab3f2be82e1a94663df46ea52f24fab0e20157d0348ef3bae8ff","size":4085},{"file_type":"regular","kind":"untracked","mode":"0644","path":"internal/knownkeys/repository_test.go","sha256":"5f355141ad882f1f5c38c4b9624292f1a80d055297cd250af767814bafac8200","size":5065},{"file_type":"regular","kind":"untracked","mode":"0644","path":"internal/knownkeys/testtmpdir_main_test.go","sha256":"8f655d9b7835db3ceaf2faa1f7a819209bc4a7e9ec6f0f8c579251d4adb39f23","size":290},{"file_type":"regular","kind":"untracked","mode":"0644","path":"internal/testutil/signingkeys_test.go","sha256":"ccc0290657ddd99efcb373e32bbbc60b932b53725a5b376fc8da47c65db558b1","size":4775},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"internal/testutil/testutil.go","sha256":"03128afd192c53dce66d8e8858fb73a7ea2aa7bddf01fe0920a01708f9c745cb","size":6483},{"file_type":"regular","kind":"tracked_modified","mode":"0755","path":"scripts/72_supported_local_setup.sh","sha256":"110b8505d55883d9282fd5a07c6600735d797bf7912c71ff49925774646a1766","size":66166},{"file_type":"regular","kind":"untracked","mode":"0644","path":"scripts/internal/signingkeygen/main.go","sha256":"bbca4983504a7dd01841260dabf9a1448d99fcd426b523cdff072bc418cde680","size":4298},{"file_type":"regular","kind":"untracked","mode":"0644","path":"scripts/internal/signingkeygen/main_test.go","sha256":"8ea789dfef014d83e30a531409b7f986e662ac220d77795fc49d6db06898563d","size":5689},{"file_type":"regular","kind":"untracked","mode":"0644","path":"scripts/internal/signingkeygen/testtmpdir_main_test.go","sha256":"f68028edcb1d6c3d1ba33db1f02bb6e1b31e9fe62bb6be1700e234f5f1945460","size":280},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"scripts/remote_alpha_upgrade_es_config_check_test.go","sha256":"c21cef1cc88d23dc813e3f488cc98b69356b62b72ca06d4d92cc391f74b49408","size":7874},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"scripts/remote_alpha_upgrade_es_host_test.go","sha256":"2f40428419ca221cc938ac61ecbc2b2a8a179ab65de4fd7884e8ba462a5dcb2b","size":95132},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"scripts/remote_alpha_upgrade_es_test.go","sha256":"c77d668b9a4652cedbae47dca9470ff3b489329a39d7429a928bf1bfa98b89e5","size":15362}],"head":"fbfd100946d2cb8f25232bac182b94fb299c66da","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"9486b14c58d58978186da22d31feb540a6408d5e559387a98f5515cfc6e94a54","upstream":"origin/trunk_dev"}
```

## Migration plan

1. Supported-local: nothing to migrate in place. A proof root made before this change keeps the old keys and its services refuse to start; re-run setup, which makes a new proof root with its own keys (documented in configuration.md).
2. Remote Alpha box (next PR, then a box turn from the coordinator): generate new AGS and EGS keys on the box (signingkeygen built from a clean checkout and shipped like esconfigcheck), back up ags.json/egs.json/es.json, write the new signer into AGS and EGS configs (root:<service group> 0640), set EGS allowed_signers to the new AGS key ID, set the 4 ES verification entries, update any workload grant's signer_key_id, restart EGS, AGS, ES in order, check health, roll back from the backup on failure. Runbook plus an Archived-Runbooks history line.
3. Already-published ARS artifacts (164 records on the box): not re-signed. Anyone could have sealed evidence with the published key, so re-signing would vouch for possible forgeries. ES refuses their old seals after the rotation; artifacts still needed are published again from source through AGS by the run that needs them.

## Assumptions / unresolved seams / uninspected areas

- Assumption: supported-local service containers run as the operator UID (control_plane_operator_user) or root (service-root-v1 ES profile), so 0600 configs stay readable (scripts/internal/control_plane.sh:159, scripts/05_start_es.sh:36-40).
- Unresolved seam: key custody (inline private keys), documented in contracts.md 3B and section 12.
- Inference: the 41 container-only failures not on the environment-only list are host limits; they match base exactly.
- Uninspected: CP repo, IM, MA (no signing keys expected there; not checked).

## Confidence

- Provenance: high (recipe verified, two identical runs, staged set matches, one commit, clean status, pushed tip equals topic commit).
- Validation: medium-high (all new/changed tests pass; full suite matches base in this container; CI pending).
- Implementation: high for the refusal rule and generator; medium-high for setup end to end until CI and a real supported-local run.

## Effect status

TOPIC_BRANCH_PUSHED | DRAFT_PR_OPENED https://github.com/evo-agi/Execution-Substrate/pull/75 (now ready for review) | MERGE_NOT_PERFORMED | INDEPENDENT_AUDIT_NOT_PERFORMED
