# RE-CHECK REPORT (narrow re-audit, Opus): ES PR #75 at 6f83520

Thread "Opus re-check of signing key PR 75", started by the coordinator 2026-11-27 06:05Z. Report written 2026-11-27 about 06:35Z (1:35 AM Eastern). Blind pair with a Sonnet re-check of the same head: I did not read it. Model: [model withheld] (read from this session's own record). Category R-M, security.

**Verdict: BLOCK, on one Low finding (R1).** Every finding of audit 04 (F1, F2, F3) and red-team 06 (RT75-1 to RT75-4) is fixed at 6f83520, and each fix has a test that fails without it: 25 of 28 mutants were killed, among them all seven that survived audit 04 (G07, R01, R02, R03, R05, R08, R10) and red-team 06's mutants A and B. Provenance reproduces, the trunk_dev #69 merge is git's own clean merge and changes none of the PR's bytes, and CI on 6f83520 passed on Linux and macOS. The block is R1: the fix delta also added a product change no finding asked for, a folder check in `signingkeygen`, and its owner branch has no test. That branch is the only thing that stops a write into a sticky folder another user owns, and a probe shows the other user replacing the key when the branch is removed. Under the standing rule that Low findings are fixed in the PR, R1 needs one test. Six observations need no change.

PR #75 closes the backlog item "supported-local installs sign published code with a fixed key committed in the repo" for every supported-local proof root made with this code (details under "Backlog item").

## Target

| Item | Value |
|---|---|
| Repository | evo-agi/Execution-Substrate |
| Base | origin/trunk_dev `0b9278ca74404b46b5e9f0e1701874b52687f5e8` (#69), current trunk_dev at the start and at the end of this re-check |
| Topic | `claude/project-thread-ljwd16`, tip `6f835204d560494e3855c93855ec65130618e547`, tree `1a02fd22616f4ec770b1e0f31591394ca14b88e4`; equals the PR head (GitHub API, read 06:10Z and `git ls-remote` 06:29Z) |
| Commits since audit 04 / red-team 06 | `4fb447d` (merge of #68, covered by red-team 06 and audit 04's trial merge) → `b9c80e1` (fixes) → `ab43fd2` (one README sentence) → `6f83520` (merge of trunk_dev #69) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` on the project copy and my copy, before the opening and before the closing run |
| Manifest | canonical-manifest SHA-256 `e104d4b4cf841801f590c5ddfdbf5ccc77738b7c4616da9c72d280d6236712c8`, textual-diff SHA-256 `d0026c621b9e1602d7a6386e889917750edc362e7f3f56a7e2ce2be910dba46d`, 38 paths (26 audited in 04 plus 12 new) |
| Review delta | `git diff 4fb447d ab43fd2`: 24 files, +1167 / -52 |

## Posture

Read-only. Own clone in this thread's container. Tests ran as an unprivileged user `ci` with umask 022, Go 1.26.5 (the version `go.mod` names), `GOTOOLCHAIN=local`, `GOPROXY=off` after `go mod download`, no proxy variable in the test environment, and HUP/INT/QUIT/TERM reset to default. The root-only test ran as root the way CI runs it (`env -i PATH=/usr/bin:/bin`, test binary only). Two local accounts (`ci`, `u2`) were created in this container for probes. No subagents. Nothing pushed, nothing posted on GitHub, no box, no Mac. Mutants and probes ran in throwaway copies, deleted afterwards.

## Provenance (ran)

- §5.3 exactly, in a fresh clone: pushed tip = 6f83520; base 0b9278c is an ancestor; `checkout -f -B` the topic at the tip, status clean, `reset --mixed` to the base, upstream pinned to origin/trunk_dev, v2 twice into a fresh 0700 folder outside the repo. The two outputs are byte-identical. No mode-bit differences.
- Committed-blob check: the manifest's path set equals `git diff --name-only 0b9278c 6f83520` (38 paths), and every record equals the blob at 6f83520 (SHA-256, size, executable bit): 0 differences.
- There was no writer manifest to compare with: report 08 delivers none for the new head (observation O6). This manifest is now the canonical one for the gate.
- Closing run after all re-check work: 06:29Z, recipe re-verified, audit worktrees removed first; two runs identical and byte-identical to the opening manifest (`e104d4b4…12c8`); `git ls-remote` unchanged (tip 6f83520, trunk_dev 0b9278c).
- Files: `provenance/` in the evidence folder.

## The trunk_dev #69 merge, separated from the fixes (ran)

- `6f83520` has parents `ab43fd2` and `0b9278c`. `git merge-tree --write-tree ab43fd2 0b9278c` gives tree `1a02fd22…`, the tree of 6f83520: git's own merge, no hand edit, no conflict.
- The merge brought exactly #69's 13 files (`a5861b7..0b9278c`): AGENTS.md, PLANS.md, README.md, six `.docs/` files and four root-package docs contract tests. So "docs only" in the brief is close but not exact: #69 also adds and changes root-package tests (`heading_links_docs_contract_test.go` is new). They pass on the head (see Validation).
- The only file both sides touch is PLANS.md. The PR's PLANS.md hunk (one added current-fact line) is identical before and after the merge. Every other PR file has the same blob at `ab43fd2` and `6f83520`.
- Every PR file outside the fix delta has the same blob at `4fb447d` (the head red-team 06 tested) and at `6f83520`, PLANS.md aside.
- Evidence: `merge/merge-and-delta-checks.txt`.

So the review surface is `git diff 4fb447d ab43fd2`, and nothing else in the PR changed.

## Prior findings: status at 6f83520

| Finding | Severity | Status | Evidence (all ran at 6f83520 unless marked read) |
|---|---|---|---|
| F1: the box's trigger is the startup refusal, not the upgrade's `esconfigcheck` | Low (wording) | **Fixed.** The PR body now says the startup refusal of AGS, EGS and ES stops the box and that the Remote Alpha ES upgrade does not reach `esconfigcheck` on the box today. contracts.md 3B and configuration.md "Signing keys" say the same; the old sentence ("which the Remote Alpha upgrade runs on the migrated es.json before it changes anything") is gone, and no other `.md` file repeats it (`git grep`). | read: PR body (GitHub, 06:10Z), `.docs/system_overview/contracts.md` 3B, `configuration.md` "Signing keys" |
| F2: no test that the generator makes a fresh EGS key per run | Low | **Fixed.** The uniqueness test generates `ags, egs, ags, egs`; `TestCommandWritesADifferentKeyOnEveryRun` runs the built command four times per role. | mutant G07 killed by both tests |
| F3: renderer key-file and config-write defenses untested | Low | **Fixed.** `scripts/supported_local_signing_keys_test.go` covers mode, link, folder-in-place-of-file, format (key ID forms, 64-byte key, extra field, algorithm), existing config (file and link), and as root a key file another user owns. | R01, R03, R05, R08, R10 killed as `ci`; R02 survives as `ci` and is killed by the root-only test run as CI runs it (`mutants/R02-root-run.txt`); the unmutated head passes that root test |
| F4: repository-key contract sentence broader than the scan | Observation | **Done.** contracts.md now scopes it to values given to `private_key_hex`/`public_key_hex` and says an unlabelled constant is not seen. | read |
| F5: negated point of a known key not refused | Observation, no action | Unchanged, as agreed. See O4 for the wider family it belongs to. | read |
| RT75-1: ES accepts the 14 small-order verification keys | Medium | **Fixed.** `knownkeys.Check` refuses the 14 encodings; AGS/EGS check their signer, ES every `verification` key, at config load. I checked the list independently: 8 points of small order; Go's decoder accepts y ≥ p, which adds y = p and y = p + 1 (only y = 0 and y = 1 have such a spelling in 255 bits), each with both sign bits, and a set sign bit on the two points with x = 0. 8 + 2 + 4 = 14, the same 14 values. The test derives them from the curve and forges under each. `es/config` tests no longer use 64 zeros. | K1 (check removed), K2, K3 (an entry dropped), K4 (an entry changed) all killed |
| RT75-2: AGS/EGS accept a 64-byte key with mismatched halves | Low | **Fixed** in both signers: the key is derived from the seed and a mismatch refused. | S1, S2 (raw 64 bytes again) and S3, S4 (derive but do not refuse) all killed |
| RT75-3: nothing notices if every install gets the same key | Low | **Fixed.** The render test keeps the generated seeds and requires `ags.json`/`egs.json` to hold them; the built command must differ on every run. | red-team mutants A (renderer writes fixed keys) and B (fixed random source) killed |
| RT75-4: AGS/EGS load signer configs with any mode | Low | **Fixed.** `ags/config.Load` and `egs/config.Load` refuse, on the opened file, a non-regular file or any "other" permission bit; README, runbook and configuration.md give 0600 / 0640. | C1, C2 (check removed), C3 (other-write allowed), C4 (other-execute allowed) killed; C5, C6 survive, see O2 |

## New findings

### R1: The folder check added to `signingkeygen` has an owner branch no test reaches

- Type / Severity: test gap / **Low**. Patch defect (new in the fix delta).
- Code: `scripts/internal/signingkeygen/main.go`, `checkFolder` (@6f83520). It refuses a folder owned by another user other than root, and a folder group or others can write without the sticky bit. No finding asked for it; it answers the inference at the end of RT75-4. Report 08 does not list it (O5); the PR body does.
- Evidence: mutant N1 removes the owner branch and survives `./scripts/internal/signingkeygen` (no test in the repository mentions it: `git grep 'belongs to another user'` finds only `main.go`). The mode branch is covered (N2, N3, N4 killed).
- Why the branch matters (ran, `probes/sticky-folder-owner-probe.sh`): `u2` makes a folder with mode 1777. The sticky bit keeps others from replacing files there, but not the folder's owner. The head's binary refuses the folder ("belongs to another user"). The N1 binary writes `ci`'s key there; `u2` then deletes it and puts its own key at the same path, and `ci` reads `u2`'s key (`ags-56ca34d6…` became `ags-875a77c0…`, owner `u2`). The owner branch is the only defense for that case, and it could be removed with every test still passing.
- Required correction: a test that makes a folder owned by another account (needs root, like `TestSupportedLocalRendererRefusesASigningKeyFileAnotherUserOwns`) and requires the refusal, run where CI runs root tests. Note: CI's root step runs only `execution-substrate/scripts` (`go.yml`, "Listed tests pass as root"), so either the test lives in that package and runs the built command, or the root step gains the package. A test seam for the effective UID is the other option.
- Uncertainty: none on the survival or the probe; the probe ran in this container only.

### Observations (no change required; listed so they are not rediscovered)

- **O1: `checkFolder` judges only the folder itself.** Its comment says it refuses "a folder in which another user could replace the key file". A user who can write the folder above can rename the operator's own 0700 folder away and put another in its place (same-parent rename needs no write permission on the moved folder). Ran, `probes/folder-swap-probe.sh`: `ci` generates into its 0700 folder inside `u2`'s 0777 folder; `u2` swaps the folder; `ci` reads `u2`'s key at the same path. This is the manual path only, needs the operator to pick a path under another user's folder, and the same binary refuses `u2`'s folder when it is named directly. Setup is not affected: its renderer refuses key files another user owns (F3). configuration.md's sentence ("a folder that no other user can write (or that has the sticky bit)") is accurate for the folder itself. Optional: say "the folder itself" in the comment, or check each folder up to the root.
- **O2: the "not a regular file" refusal is not what the folder case tests.** Mutants C5/C6 drop `IsRegular` from AGS/EGS config load and survive. The test's folder case passes through the mode branch instead, because `t.TempDir()` is mode 0755 here (ran, `probes/knownkeys-probes-out.txt`). The behaviour does not change: a 0700 folder is still refused, by the JSON decoder ("is a directory"), and a FIFO blocks in `open` before either check runs. Optional: `chmod 0700` the folder in the test so it reaches the branch it names.
- **O3: group bits are not judged.** A config with mode 0660 or 0620 loads (`Perm()&0o007`, read). The documented modes are 0600 and 0640; the contract's "other users" matches the POSIX "other" class. Not a key-secrecy gap on today's hosts, where the group is the service's own (`root:<service group>` on Remote Alpha). Recorded only so the reading is explicit.
- **O4: keys derived from public secrets are an open family, of which the PR refuses two members.** Beyond F5's negated point, the published key plus any of the seven non-identity small-order points is a key anyone can sign for (one try in two to eight), and `Check` accepts it. Ran, `probes/zz_mixed_order_probe_test.go.txt`: seed 0x11's public key plus the order-2 point (`1db54dcd…78c8`) passes `Check`, and a signature made from the published seed verifies under it after 3 tries; a one-bit change of the key fails the same signature. Nobody gets such a key by copying an example, and whoever can write a host's config can install any key. A prime-order subgroup check on public keys would close this family together with the 14 small-order values (not the negated point). No change requested in this PR; the contracts.md purpose sentence is broad, but the invariants list exactly what is refused.
- **O5: report 08's finding map leaves out two product changes in the delta**: the `signingkeygen` folder check (R1, O1) and the split of `read_signer`'s open errors into "missing" and "cannot be opened without following a link" (tested: RS1 killed). Both are in the diff and the folder check is in the PR body.
- **O6: no writer manifest for the new head.** Provenance §5.5 asks the writer to take a base-relative v2 manifest after repair. Report 08 has none; I took one (above) and verified it against the committed blobs.
- PLANS.md's new current-fact line names only the repeated-byte family. It is accurate and points at contracts.md 3B, which has the full list; no change needed.

## Backlog item: "Supported-local installs sign published code with a fixed key committed in the repo"

Closed by #75 for supported-local, with two limits.

- Each proof root gets its own keys: `generate_supported_local_signing_keys` runs `signingkeygen` for AGS and EGS (crypto/rand), the renderer writes exactly those keys into `ags.json`/`egs.json` (render test; mutant A killed), points the EGS allow list and the four ES `verification` entries at them, and removes the key files.
- The fixed keys can no longer be used: AGS, EGS and ES refuse the 256 repeated-byte keys and the 14 small-order values at config load, and no value given to a key field in the repository outside Go tests is one a service would accept (repository scan test). A non-test search for `ags-key-1`, `egs-key-1` and the two repeated seeds outside `.examples/config` finds only reliable-submit test vectors (read).
- Limit 1: a proof root made before #75 keeps the old keys; its services refuse to start, and setup must be run again (configuration.md says so).
- Limit 2: the item's second half, that grants keyed on a publisher are no boundary, is about #73's grants, which are not in this tree. Inference (from the signing-keys thread's notes, not checked here): when #73 and #75 meet, #73's renderer must take `provenance_key_id` from the generated AGS key. That is a merge step for whichever lands second, not something #75 can show.
- The Remote Alpha box is a separate item (still on the published keys; rotation is #76).

## Validation

Ran, on exact bytes (ci-owned clones at 6f83520 and 0b9278c), as `ci`, sequentially:

- `go test -count=1 -timeout=25m -json ./...`. Head 06:12:22Z to 06:21:26Z; base 06:21:26Z to 06:28:45Z.
  - Head: 10,111 passed, 248 failed, 136 skipped, 52 packages. Base: 9,981 passed, 248 failed, 135 skipped, 50 packages. (Counts include subtests.)
  - **The failing sets are identical** (`diff` empty): 34 top-level tests, 3 in `es/admission/internal/reliablesubmit`, 2 in `es/app`, 29 in `scripts` (243 entries with their subtests). All are the same on base, so none comes from this PR. Inference from their messages: they need what this container lacks (the account `ds`, `/private/tmp`, ssh, a Nomad leader, a second Go at `/usr/bin/go`, the reliable-submit production-source probes). CI is the check that counts for them, and it passed. Lists: `tests/failing-head-6f83520.txt`, `tests/failing-base-0b9278c.txt`.
  - Every new and changed test of the PR passes on the head (`tests/new-tests-on-head.txt`): `internal/knownkeys` 13 of 13, `ags/sign` 1, `egs/sign` 1, `signingkeygen` 6, `internal/testutil` 7, `es/config` 55, the root package 188 (with #69's new heading-link test), `TestSupportedLocalRendererKeepsTheSigningKeysPrivate` and the render test. `TestSupportedLocalRendererRefusesASigningKeyFileAnotherUserOwns` skips as `ci` by design and passes as root (`mutants/R02-root-run.txt`).
  - My numbers differ from report 08's (55 failing, run as root): environment, not bytes. The comparison that counts is head against base in one environment.
  - The mutant runs overlapped the head run for a few minutes; the failing sets still match base exactly.

Mutants: 28, all in `mutants/` (definitions, runner, per-mutant logs, root run).

| Group | Killed | Survived |
|---|---|---|
| RT75-1 small order | K1, K2, K3, K4 | none |
| RT75-2 64-byte halves | S1, S2, S3, S4 | none |
| RT75-4 config mode | C1, C2, C3, C4 | C5, C6 (O2: same refusal, other message) |
| F2 / RT75-3 fresh keys | G07, MA, MB | none |
| F3 renderer defenses | R01, R02 (root run), R03, R05, R08, R10 | none |
| New in the delta | RS1, N2, N3, N4 | N1 (R1) |

Also ran: `go vet` on the changed packages and `gofmt -l` on the changed Go files: clean.

CI (read, not rerun), both on head SHA 6f83520 (run records checked):
- "build, vet and test" run 45938895727: success, 04:15:37Z to 05:01:46Z. The Test step's gate allows no unlisted self-skip, so `TestSupportedLocalRendererKeepsTheSigningKeysPrivate` ran (it is not a listed skip on Linux). "Listed tests pass as root" ran 10 tests including `TestSupportedLocalRendererRefusesASigningKeyFileAnotherUserOwns`: all passed (log read).
- "test on macOS" run 45938895770: success, 04:15:37Z to 04:55:38Z.

Not run: full supported-local setup (no Vault, Nomad or SPIRE here; CI covered the parts its gate runs), macOS (CI), the box.

## Coverage

Read in full: the whole fix delta (24 files), `internal/knownkeys/knownkeys.go` and its new tests, both signers and both config loaders, `signingkeygen/main.go` and its test, the renderer's `read_signer` and its new test, the render-test change, the doc and CI-list changes, the PR body. Traced: every caller of `knownkeys.Check`/`CheckPrivate` (`ags/config`, `egs/config`, `es/config`), and how CI's root step selects its tests. Not re-inspected: the parts of the PR audit 04 and red-team 06 covered and that did not change (byte-identical, above), CP, IM, MA, the other repositories.

## Sensitive-material handling

No secret printed or copied. Keys generated by tests, probes and mutants were throwaway keys, deleted with their folders. The published keys are public by definition. The box was not contacted.

## Remaining uncertainty

- R1's probe and O1's probe ran in this container only.
- CI's Linux Test step log was read only in part (the end of the log, including the root step); the pass of the other new tests on CI is inferred from the job's success and the gate's documented rules.
- The completeness of the 14 small-order values rests on the curve argument above plus the test's derivation; a test cannot show that no fifteenth spelling exists in some other decoder.

## Confidence

- Provenance: high (about 1.0: reproduced twice, committed blobs equal, merge reproduced, closing equals opening).
- Validation: high on Linux (full suite on head and base, identical failing sets, 28 mutants, root test as CI runs it, CI green on both systems).
- Implementation: high that every prior finding is fixed and tested; high that the folder check is correct for the folder itself (R1 is a test gap, O1 a scope note).

## Effect status

RECHECK_PERFORMED | REPAIR_NOT_PERFORMED | COMMIT_NOT_PERFORMED | PUSH_NOT_PERFORMED | GITHUB_POST_NOT_PERFORMED | MERGE_NOT_PERFORMED

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/signing-keys/12-pr75-recheck-opus.md` (SHA-256 in the thread reply); evidence in `12-pr75-recheck-opus-evidence/` with `SHA256SUMS`.

**Final verdict: BLOCK** (R1 Low; O1 to O6 observations; every audit 04 and red-team 06 finding fixed).

## Trial row

| Date | Category | PR @ head | Scope | Model | Verdict | Findings | Later outcome |
|---|---|---|---|---|---|---|---|
| 2026-11-27 | R-M (security) | ES #75 @ 6f83520 | narrow re-check (pair) | [model withheld] | BLOCK | R1 Low (signingkeygen folder-owner branch untested; sticky-folder probe shows the swap); obs O1 ancestor-folder swap, O2 IsRegular branch untested (C5/C6), O3 group bits, O4 torsion-shifted known keys, O5 report omits 2 product changes, O6 no writer manifest; all F1-F3, RT75-1..4 verified fixed (25/28 mutants killed) | paired with the Sonnet re-check of the same head (not read by this thread) |
