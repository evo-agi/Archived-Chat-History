# Evidence for the red-team of ES PR #75 (report 06-pr75-redteam.md)

Target: `evo-agi/Execution-Substrate` PR #75, branch `claude/project-thread-ljwd16`.

- Most of the work ran on the first head, `efc97e668174e26aab1c555843321b442aade686` on `trunk_dev` at `fbfd100946d2cb8f25232bac182b94fb299c66da`.
- At 02:23Z on 2026-11-27 the writer merged `trunk_dev` (`a5861b7c0e2199a77b489d25e6b3fc02e6448c20`, PR #68, the service layout) into the branch. The head is now `4fb447df73d9bd69290ce12ffd91e4823e6c0abb`. Every probe, mutant and regression test here was run again on that head.

Go 1.26.5, 4 CPUs, a cloud container without Docker, Nomad, Vault or SPIRE. Nothing here was pushed or posted, and no Linux box or live service was used.

Every probe, mutant and candidate repair is a scratch file. The probes are not meant for the repository: a probe passes while its weakness is there. The files in `regressions/` are proposed permanent tests.

No file here holds a private key that any install uses. The keys in the probes are made at test time, and the two-user scripts print the length of a key they read, never the key.

## Layout

| Folder | Holds |
| --- | --- |
| `probes/es_admission/` | RT75-1 (`zz_rt75_small_order_test.go`) and RT75-2 (`zz_rt75_inconsistent_key_test.go`). Copy into `es/admission/`. They import `internal/testutil`, which a guard test in that package refuses for `es/admission`; that is one more reason they are probes only. |
| `probes/internal_knownkeys/` | RT75-4 (`zz_rt75_manual_path_test.go`) and the refusal sweep that held (`zz_rt75_refusal_sweep_test.go`). Copy into `internal/knownkeys/`. |
| `mutants/` | A and B are the two mutants no test of the PR notices (RT75-3). C, D and E are power checks for the refusal sweep. All are `git apply` diffs that apply to both heads. |
| `candidate-repair/` | A: refuse the 14 small-order keys in `knownkeys.Check`, refuse a 64-byte private key whose halves do not belong together, and stop using 64 zeros as the valid key in `es/config` tests (RT75-1, RT75-2). B: AGS and EGS refuse a config file other users can read or write (RT75-4). Suggestions that were tested, not patches for the PR. Both apply to `4fb447d`. |
| `regressions/` | Proposed permanent tests, by target package. `es_admission/` is a diff to the PR's own render test. `ags_sign/` and `egs_sign/` have no test files today, so each comes with the `testtmpdir_main_test.go` every package needs. |
| `tools/` | `keyscan` (finds hex key pairs and predictable seeds in trees), `ziptokens/` (lists hex tokens and private-key fields inside zip archives without extracting them), `forge` (a signature for a small-order key without any private key), `dblpub` (recovers a private scalar from two signatures), `fixedkey` (made the fixed keys of mutant A). Each Go tool is one `main.go` using the standard library only. |
| `scripts/` | `run-probes.sh.txt` reruns sections 1 to 8 below in throwaway worktrees. `install-regressions.sh.txt` copies the regression tests into a worktree. |
| `outputs/at-4fb447d/` | What `run-probes.sh` printed on the current head. |
| `outputs/at-efc97e6/` | The same on the first head, plus the long package runs, which were made on that head only. The candidate repair A used there is the same change with `egs/sign/signer.go` indented as on that head; its probe run was not kept as a file. |
| `outputs/` | The key scans (they cover both heads). |

## Reproduce

```sh
E=/mnt/project-files/reports/Execution-Substrate/signing-keys/06-pr75-redteam-evidence
cp $E/scripts/run-probes.sh.txt /tmp/run-probes.sh
bash /tmp/run-probes.sh /path/to/Execution-Substrate $E /tmp/rt75-out
```

The script makes its worktrees under `/var/tmp/rt75-run.*` and touches nothing else in the clone. Sections:

| Section | Shows | Output file |
| --- | --- | --- |
| 1 | The probes pass on the head: RT75-1 for all 14 small-order keys and end to end, RT75-2 for EGS and AGS, RT75-4 for modes 0644 and 0666. The refusal sweep: 181,760 cases, no known key accepted. | `1-probes-*.txt` |
| 2 | `esconfigcheck`, the upgrade gate, accepts an `es.json` whose four verification keys are 64 zeros, and refuses the example `es.json`. | `2-esconfigcheck-zero-key.txt` |
| 3 | The sweep fails on mutants C and D. Mutant E changes nothing a service accepts (the sweep still passes) and the PR's own unit test fails on it. | `3-power-check-mutant-*.txt` |
| 4 | Mutant A passes the PR's tests and fails the proposed render-test lines. | `4-mutant-A-*.txt` |
| 5 | Mutant B passes the PR's tests, writes the same key twice, and fails the proposed test. | `5-mutant-B-*.txt` |
| 6 | The proposed tests on the head (three fail, as they should before a repair), with candidate repair A, and with candidate repair B. The probes fail with "WEAKNESS CLOSED" on repair A. | `6-*.txt` |
| 7 | An operator (uid 1001, umask 022) follows the runbook's manual steps; another user (uid 1002) reads the private key out of `ags.json`. | `7-manual-steps-two-users.txt` |
| 8 | Held: while setup's key generation runs as root, uid 1002 tries in a loop to read the keys or plant entries, and gets nothing. | `8-setup-keygen-two-users.txt` |

Long runs, made on `efc97e6` only (commands run in a worktree of that commit; the 38 failures of `./scripts`, the 15 of `es/app` and the 3 of `reliablesubmit` are the ones this container gives on the clean head):

```sh
F='^(--- FAIL|ok|FAIL|panic)'
go test -count=1 -timeout 40m . ./scripts ./es/admission ./es/config ./internal/... 2>&1 | grep -E "$F"
#   clean head: outputs/at-efc97e6/wider-packages-clean-head.txt
#   mutant A:   outputs/at-efc97e6/wider-packages-mutant-A.txt        (same 38 failing names)
go test -count=1 -timeout 40m ./es/app ./es/api ./ags/... ./egs/... ./ars/... ./cgs/... ./scripts/internal/... 2>&1 | grep -E "$F"
#   clean head: outputs/at-efc97e6/remaining-packages-clean-head.txt
go test -count=1 -timeout 40m . ./es/... ./ags/... ./egs/... ./ars/... ./cgs/... ./internal/... ./scripts/internal/... 2>&1 | grep -E "$F"
#   candidate repair A with the regression tests: outputs/at-efc97e6/all-packages-but-scripts-candidate-repair-A.txt
#   (the same 15 es/app names, plus 3 in reliablesubmit that also fail on the clean head:
#    outputs/at-efc97e6/reliablesubmit-three-tests-clean-head.txt)
go test -count=1 -timeout 40m . ./ags/... ./egs/... ./ars/... ./cgs/... ./internal/... ./es/app ./es/api ./scripts/internal/... 2>&1 | grep -E "$F"
#   candidate repair B: outputs/at-efc97e6/packages-candidate-repair-B.txt
```

Key scans (trees at the commits named in the report; the chat archive is read in memory):

```sh
cd $E/tools/keyscan && go build -o /tmp/keyscan . && cd -
/tmp/keyscan <ES at 4fb447d> <ES at efc97e6> <ES at fbfd100> <six other repositories>      # outputs/keyscan-seven-repos.txt
python3 -I $E/tools/ziptokens/ziptokens.py /path/to/Archived-Chat-History /tmp/chat-tokens && /tmp/keyscan /tmp/chat-tokens   # outputs/keyscan-chat-archives.txt
python3 -I $E/tools/ziptokens/privatekeyfields.py <all eight>                                # outputs/private-key-fields-eight-repos.txt
```

## Traps met

- The clone's own checkout may name an older Go in `go.mod`. The setup script wants go1.26.5 as `go` on `PATH`, so the script takes `GOROOT` from inside a worktree of the head.
- A file written through a heredoc or an editor may turn `\u` escapes in Go source into raw characters. The probes are plain ASCII.
- `gofmt -l` lists `ags/sign/signer.go` on both heads; that is the file as the PR has it, not the candidate repair.
