# ES PR #75: Opus narrow re-check 15 of the fix delta (6f83520 to ec9a5b9)

```text
INDEPENDENT AUDIT REPORT (narrow re-check)
Repository:      evo-agi/Execution-Substrate, PR #75 "Give each host its own AGS and EGS signing keys"
Audit target:    base trunk_dev 0b9278ca74404b46b5e9f0e1701874b52687f5e8
                 topic claude/project-thread-ljwd16 @ ec9a5b947e0335590c8dc1311153180702fe26a1, tree a74868bfc8d3738a2e000e6e92978ffa7a50abac
                 recipe governed-execution.audit-patch-manifest.v2, source SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified)
                 canonical manifest SHA-256 05f70f34869e25d1d3e4ccc0dd93aa2d32f41b1ac2edbe9fd95e55bebbfcea19, 38 changed paths
Scope:           delta 6f83520..ec9a5b9 (1 commit, 6 files, +85/-18) and regressions
Model:           [model withheld] (paired run; the paired Sonnet report for this head was not read)
Date:            2026-11-27, about 06:58Z to 07:15Z
Final verdict:   BLOCK (one Low, R15-1: a regression from the PR that is outside the delta; every fix in the delta holds)
```

## Verdict in plain words

All nine items this round was asked to verify are fixed or answered correctly, and the delta adds no regression. Every mutant aimed at the three Lows is now killed: 12 of my 13 mutants are killed when both runs (normal user and root) are counted together, and the 13th only differs inside a race. The block comes from one new Low that is older than the delta. Since efc97e6, PR #75 makes `internal/testutil` fail in a source tree without `.git` (for example, one made with `git archive`), and trunk_dev passes there. The repository documents that such trees are supported. CI does not see this failure, because its checkout has `.git`. The repair is test-only and small (a prototype is below). The coordinator may rule it outside this round's scope. I counted it because of the rule that Low nits are fixed in the PR.

## Provenance reproduction

- Recipe bytes: `sha256sum` of `/mnt/project-files/operating-protocol/tools/governed_execution_audit_patch_manifest_v2.py` equals the pinned `c08597e2…a1ca`. It was checked again before the closing run.
- Target identity: `origin/claude/project-thread-ljwd16` = `ec9a5b9…26a1` and `origin/trunk_dev` = `0b9278c…f5e8`. Both equal the PR's head and base in the GitHub API (PR #75 `get`, 07:0xZ). The base is an ancestor of the tip, and the checkout at the tip is clean.
- Two runs (HEAD at the base, upstream `origin/trunk_dev`) gave identical bytes: manifest SHA-256 `05f70f34…ea19`, 38 paths, textual diff SHA-256 `a8d2b7c8…70de`. The result is byte-identical to the writer's `14-pr75-recheck-fixes-evidence/manifest-75-ec9a5b9-v2.json`. There were no mode-bit differences.
- Closing run after all tests and mutants: identical to the opening run. Tests ran in a separate worktree and in `git archive` copies. The provenance clone's working tree was not touched. The worktree showed `git status` empty after the mutants.
- Commands: `15-pr75-recheck-opus-evidence/provenance/commands.txt`.

## Fix verification (delta 6f83520..ec9a5b9)

Source labels: **R** means repo-validated at `ec9a5b9` (path:line). **T** means a thread-reported fact that I did not re-derive.

| Item | Result | Evidence |
|---|---|---|
| Sonnet R75-1: contracts.md small-order count | **Fixed** | R: `.docs/system_overview/contracts.md:299-303` now reads "the eight such points, the two whose x is 0 also written with the sign bit set, and the four written with y = p or y = p + 1, each with either sign bit". That is 8 + 2 + 4 = 14, matching the 14 entries at `internal/knownkeys/knownkeys.go:58-71`. Encodings with y = p decode to the order-4 points with y = 0 (two x values). Encodings with y = p + 1 decode to the identity (x = 0, accepted with either sign bit). No other text states a count or the old "two" (searched `y = p`, `p + 1` and `small order` in *.md and non-test *.go). `configuration.md:276-278` says "14 values", which is consistent. The derivation test in `internal/knownkeys` passes (root and normal user). |
| Sonnet R75-2 / Opus O2: config-mode test does not pin "regular file" or "judged by the file" | **Fixed** | R: `internal/knownkeys/signer_config_mode_test.go:59-90`. A link to a 0600 config must load, the same link after `chmod 0644` must be refused, and a 0700 folder (explicit `chmod`) must be refused with "must be a regular file". Mutants C5/C6 (drop `IsRegular` in `ags/config/config.go:88` / `egs/config/config.go:69`) and C8a/C8e (`os.Lstat(path)` in place of `file.Stat()`, :84 / :65) are each killed by `TestAGSAndEGSRefuseASignerConfigOtherUsersCanReadOrWrite`, both as user `ci` and as root. |
| Sonnet R75-3 / Opus R1: generator's folder-owner branch untested (GF2 / N1) | **Fixed** | R: `scripts/internal/signingkeygen/main.go:131,140` (`checkFolder(dir, euid)`), caller `:76` passes `os.Geteuid()`. That caller is the only one at `ec9a5b9`, and at #76's `aba3fe6` too (`git grep`). New test `main_test.go:240-281`. N1 (branch removed, my R1 mutant), N2 (new: root may use a folder another user owns), N3 (root exception removed, GF3) and N4 (comparison inverted) are each killed by `TestCheckFolderRefusesAFolderAnotherUserOwns` as `ci` and as root. The test needs no root, so it runs in CI's normal test step: `.github/workflows/go.yml:161-162` runs every package through the gate, and the gate fails on any skip that is not listed. The test is not listed in `.github/ci/environment-only-tests*.txt` (grep found nothing). This removes the "CI root step runs only `scripts`" limit from report 12. |
| Opus O1: `checkFolder` judges only the folder itself | **Answered (documented, no ancestor walk)** | R: comment at `main.go:123-130` says it judges the folder itself and why the key belongs under the user's own folders or root's. `configuration.md:254-256` adds only "that the user running it or root owns". See O15-3 on the fix report's wording. Not walking the ancestors is acceptable for an observation-level item: setup writes into its own 0700 signing folder (`scripts/72_supported_local_setup.sh:1224-1238`). |
| Opus O5: report 08 omitted two product changes | **Answered** | Report 14 lists both. I confirmed both are in `git diff 0b9278c 6f83520`: the signingkeygen folder check (new file, 144 lines), and `read_signer`'s `O_NOFOLLOW` open with a separate `FileNotFoundError` message (`72_supported_local_setup.sh` diff hunk lines 65-67). |
| Opus O6: no writer manifest | **Fixed** | Writer's v2 manifest for `ec9a5b9` is delivered and reproduced byte for byte (above). |
| Sonnet O75-1: test comment says the box stops at `esconfigcheck` | **Fixed** | R: `scripts/remote_alpha_upgrade_es_config_check_test.go:180-184`. The comment matches `scripts/internal/remote_alpha_upgrade_es.py:1198-1201`: shape `locked-http` goes to `inspect_start`, which runs `esconfigcheck` (`:1222`); shape `https` goes to `inspect_migrated`, which runs no config check. T: the box is shape `https` (audit 04 F1). Not checked here; no box access. |

Regressions in the delta: none found. The `checkFolder` signature change has one caller. `go vet` on `signingkeygen` and `knownkeys` is clean, and `gofmt -l` is clean on the changed Go files. The `scripts` package compiles, and its targeted tests pass, including `TestESConfigCheckAgreesWithConfigLoad`, whose comment changed.

## Findings

```text
AUDIT FINDING
ID / Type / Severity: R15-1 / test bug (regression against trunk_dev) / low
Current contract: .docs/system_overview/artifact_hygiene.md:242-248 (at ec9a5b9): in a source tree
  without .git, "such as one exported with git archive", "the docs tests that read every repository
  file ... still run in such a tree". The PR's own internal/knownkeys/repository_test.go:19-22 says
  it supports "a tree unpacked from a source archive".
Path and line: internal/knownkeys/repository_test.go:25 (os.Lstat(filepath.Join(testutil.Root, ".git")))
  as judged by internal/testutil/testutil_test.go:153-192 / :666-689 (anchoredProblem).
Evidence: in git-archive copies run as user ci (tests/no-git-tree-testutil-guard.txt):
  base 0b9278c: ok execution-substrate/internal/testutil
  6f83520 and ec9a5b9: FAIL TestImportersNameRepositoryPathsFromTheRoot,
    "internal/knownkeys/repository_test.go:25: filepath.Join resolves ".git" against the repository
    root, which holds no such name"
  In a git checkout (worktree, root) internal/testutil passes (tests/root-packages.txt).
  internal/knownkeys itself passes in the archive tree; only the guard fails.
Failing test: execution-substrate/internal/testutil TestImportersNameRepositoryPathsFromTheRoot
Impact: go test ./... from a source archive fails where trunk_dev passes; CI unaffected (checkout
  has .git). No product effect.
Required correction (test-only): let the guard accept ".git", the one root name a checkout has and an
  archive does not, and add a selftest case for it. Alternatively, have repository_test.go detect git
  metadata in a way the guard accepts. Prototype, tried in the archive copy and then restored: in
  anchoredProblem, `case first == "." || first == ".." || known == ".git": return ""` makes
  internal/testutil pass there (tests/no-git-tree-guard-prototype.txt). The selftest case and a run of
  ./internal/testutil and ./internal/knownkeys in a git-archive tree should come with the fix.
Uncertainty: none on the failure. Whether this round's scope covers it is the coordinator's call:
  the defect predates the delta (introduced with repository_test.go at efc97e6).
Patch defect or pre-existing issue: patch defect of PR #75 (not of the 6f83520..ec9a5b9 delta).
  It is not reported in 12 (my previous re-check) or in 14. The project-memory summaries of 04, 06
  and 13 do not mention it.
```

Observations (no action required):

- **O15-1: generate's refusal of another user's folder is tested only as root.** Mutant N7 (generate passes the folder owner's own UID, so the owner rule always passes) survives as a normal user. Only the root branch of the new test kills it, and CI does not run `signingkeygen` as root. The likely wrong arguments are killed as a normal user: N5 (passes 0) and N6 (passes euid+1). N7 has to compute the folder owner, so it is contrived. A normal user cannot portably get a sticky folder owned by another non-root user, so root is the only way to test this. I recommend no change.
- **O15-2: "judged on the opened file" is a race property, not something the test can pin.** C9a (`os.Stat(path)` in place of `file.Stat()`) survives. It differs only if the path changes between open and stat. The test pins "judged by the file the link names" (C8 killed), and the comment gives the opened-file check as the reason, not as a tested claim. No change.
- **O15-3: report-accuracy notes on report 14 (not repo defects).** (a) Report 14 says configuration.md now states the check is judged "on the folder itself" with the reason. At `ec9a5b9` only the code comment (`main.go:123-130`) and the PR body say so; configuration.md gains only the owner clause. (b) Report 14's reason for not walking ancestors ("would refuse ordinary macOS paths under /private links") is unverified. Inference: a walk using the same rule (folders owned by the user or root, never writable by others unless sticky) would accept the root-owned `/private` and the sticky `/private/tmp`. Not tested. The decision itself is fine for an observation-level item.

Minority findings or disagreements: none (single reviewer, no subagents).

## Validation assessment

Re-run at the exact bytes of `ec9a5b9` (Go 1.26.5 linux/amd64, umask 022, `GOFLAGS=-buildvcs=false`):

- As root in a worktree at `ec9a5b9`: `internal/knownkeys`, `scripts/internal/signingkeygen`, `ags/sign`, `egs/sign` and `internal/testutil` pass, with 29 tests reporting PASS (`tests/root-packages.txt`). The root package (docs tests) passes. `scripts -run 'TestESConfigCheckAgreesWithConfigLoad|SigningKey|SignerConfig'` passes 3 tests. `go vet` is clean and `gofmt -l` is clean (`tests/root-docs-scripts-vet.txt`).
- As user `ci` (uid 30033) in a `git archive` copy: `internal/knownkeys`, `signingkeygen`, `ags/sign` and `egs/sign` pass, including `TestAGSAndEGSRefuseASignerConfigOtherUsersCanReadOrWrite` and `TestCheckFolderRefusesAFolderAnotherUserOwns`. `internal/testutil` fails `TestImportersNameRepositoryPathsFromTheRoot`, which is R15-1 (`tests/ci-packages.txt`).
- Mutants (`mutants/mutants.py.txt`, each applied alone and restored):
  - As `ci`: 11 of 13 killed. N7 and C9a survive (`mutants/ci.txt`).
  - As root: 10 of 13 killed. N5 survives because it is equivalent when euid is 0. N6 survives because root's temp folders belong to root. C9a survives (`mutants/root.txt`).
  - Both runs together: 12 of 13 killed. Only C9a survives (race-only, O15-2). The writer's eight mutants are covered by N1/N3/N4/N6/C5/C6/C8a/C8e with the same results as the writer's `mutants-ubuntu.txt` and `mutants-root.txt`.
- Not re-run: the full suite (narrow scope); macOS; the sticky-folder probe from report 12 (it shows a kernel property the new test now relies on, unchanged); #76 at `aba3fe6` (outside this scope; the writer reports a clean merge).
- CI on `ec9a5b9`: both jobs ("build, vet and test", "test on macOS") were still `in_progress` at about 07:12Z (started 06:50Z). This report does not depend on them. The gate must see both green.

## Sensitive-material handling

No secrets were read or copied. The keys in the tests are generated fresh per run, and the only fixed keys are the published example keys. Nothing was touched on the box.

## Remaining uncertainty and stop conditions

- The verdict depends on counting R15-1 against this round. If the coordinator rules it out of scope and tracks it on its own, everything this round was asked to verify holds, and no other blocking finding is open.
- The box shape (`https`) is a thread-reported fact.

## Confidence

- Provenance: high. I reproduced the manifest twice, it matches the writer's byte for byte, and the closing run equals the opening run.
- Validation: high for the delta: exact bytes, two users, 13 mutants. Medium overall: no full suite, and CI was pending.
- Implementation: high. The fixes are correct and minimal, and no widening was found.

## Effect status

Read-only. Nothing pushed, committed, opened, merged or posted. No box contact. Scratch clone, worktree and `git archive` copies live only in this container. A local user `ci` was used in the container.

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/signing-keys/15-pr75-recheck-opus.md` with evidence in `15-pr75-recheck-opus-evidence/` (SHA256SUMS inside). The report's own SHA-256 is given in the thread reply.

Final verdict: **BLOCK** (R15-1 Low)
