# Red-team of ES PR #75 (each host its own signing key): 06-pr75-redteam

Date: 2026-11-26, about 9:45 PM Eastern (02:45Z on 11-27). Thread: "Red-team the per-host signing key PR". This thread did not write or audit PR #75, and I did not read the audit report (`04-pr75-audit.md`) before finishing this one. Posture: read-only. Nothing was pushed, nothing was posted on GitHub, and no Linux box or live service was used. Evidence: `06-pr75-redteam-evidence/` (its `README.md` has the commands, and `scripts/run-probes.sh.txt` reruns everything below in about 4 minutes).

Source labels: "ran" means I ran it in this container on the exact commit named. "Read" means I read the code and did not run it. "Inference:" and "Guess:" mark the rest.

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #75, branch `claude/project-thread-ljwd16` |
| Head now | `4fb447df73d9bd69290ce12ffd91e4823e6c0abb`, tree `5937c39a8d567e4c65b52cd1c5453806b33e0fe5`. It is the merge, made at 02:23Z, of `trunk_dev` at `a5861b7c0e2199a77b489d25e6b3fc02e6448c20` (PR #68, the service layout) into the first head. |
| First head | `efc97e668174e26aab1c555843321b442aade686`, tree `6b4d09ece87617c882a8416e2f68cd2a54cfbc64`, on `trunk_dev` at `fbfd100946d2cb8f25232bac182b94fb299c66da`. Most of this pass ran here. |
| The PR's own change | `git diff a5861b7 4fb447d`: 26 files, +1402 / -35, SHA-256 `e857724de712a777474a6754fbe2f432c50bc04be5039b03b04f92c649f19a10`. On the first head, `git diff fbfd100 efc97e6`: 26 files, +1402 / -35, SHA-256 `729ee4810017c5065e3d8ea9889962137eb9d6c2ec76336bf39bff0094987581`. Ran: the two diffs add and remove exactly the same lines. |
| What the merge changed on the key surface | Ran (`git diff efc97e6 4fb447d`): the import `egs/model` became `egs/contract` in `egs/config/config.go` and `egs/sign/signer.go`, `egs/sign/signer.go` was re-indented, and one list in a guard test of `internal/testutil` grew by a name. Nothing else under `internal/knownkeys`, `ags/`, `es/config`, `scripts/72_supported_local_setup.sh`, `scripts/internal` or the examples changed. |
| Checked before writing | `git ls-remote` at 02:44Z: PR head `4fb447d`, `trunk_dev` `a5861b7`. |
| CI on `4fb447d` (GitHub, read at 02:44Z) | "build, vet and test" and "test on macOS" were both still running. |

**The head moved during this pass.** I found the four results below on `efc97e6`. Then I ran every probe, mutant, candidate repair and regression test again on `4fb447d`: all results are the same (`outputs/at-4fb447d/` and `outputs/at-efc97e6/`). The long package runs (12 minutes each) were made on `efc97e6` only; each place below says so.

## Outcome

**I found no way to make an install that supported-local setup builds sign with a key an attacker knows or can predict, and no spelling that gets one of the 256 repeated-byte keys past AGS, EGS or ES.** The refusal held for 181,760 spellings, setup's key files stayed unreadable to a second local user through 2,550 attempts during generation, and the only signing keys in the eight repositories are the two published ones the PR now refuses.

Four findings remain. None of them breaks an install that setup made. Two are keys the new refusal should also stop and does not. One is a test gap on the PR's central promise. One is a documented protection that only setup provides.

| ID | Severity | Type | In one line |
| --- | --- | --- | --- |
| RT75-1 | Medium | security risk | ES and the upgrade gate accept 14 verification keys for which anyone can make a valid signature with no private key. 64 zeros is one of them, and it is the value the repository's own ES tests use as the valid key. With it as `verification.provenance`, ES registered a run for an artifact nobody signed. |
| RT75-2 | Low | security risk | AGS and EGS accept a 64-byte private key whose second half is not the public key of its first half. Its signatures verify under no key, and they give the private key away once the mistake is corrected and the same bytes are signed again. |
| RT75-3 | Low | test gap | No test fails if every install gets the same key again, as long as it is not a repeated-byte key. Two mutants show it: one in the setup renderer, one in the generator's random source. |
| RT75-4 | Low | doc and enforcement gap | `configuration.md` says the config that holds a private key is readable only by the service account and root. Only setup makes that true. AGS and EGS load such a file with mode 0644 or 0666, and the runbook's manual steps leave it 0644 under the usual umask. |

My view for the gate: RT75-1 should be fixed in this PR. It is the same harm the PR exists to stop (a key anyone can sign for), the repair is one more refusal in the shared rule, and it comes with a test. RT75-2 and RT75-3 are small and tested, so the standing rule (Low findings are fixed in the PR) covers them. RT75-4 has one choice for the writer: enforce the mode in AGS and EGS (candidate repair B, which broke no existing test in the packages I ran), or state the mode in the runbook and say in `configuration.md` who enforces it. I recommend the first. None of this needs David.

Confidence: high for the four findings and both mutants (each has a run on both heads). High that setup's key handling is sound on Linux for what ran here. Medium for the whole install, because setup itself cannot run in this container (see "Coverage this environment could not give").

## RT75-1 (Medium): ES accepts verification keys that anyone can sign for, the all-zero value among them

**What.** Contract section 3B gives the purpose of the new rule: no service may sign or verify with a key "because anyone can know their private halves", since "a key whose private half is public proves nothing" (`.docs/system_overview/contracts.md:263-267`). The rule then defines a known key as one of the 256 keys with a repeated-byte seed. There is a second family with the same effect that needs no private half at all: the eight points of small order on the curve. For such a public key, a signature that Go's `ed25519.Verify` accepts can be computed by anyone with a short loop. Go decodes 14 different 32-byte values to those eight points. One of them is 32 zero bytes.

ES checks a verification key in `SignerVerifierConfig.Validate` (`es/config/config.go:696-715`): algorithm, key ID, hex, a length of 32 bytes, then `knownkeys.Check`. Nothing there refuses these values, and ES verifies with `ed25519.Verify` directly (`es/admission/service.go:1038`, `internal/contracts/evidence/v1/record.go:83`).

**Proof.** All ran on both heads (`outputs/at-4fb447d/1-probes-es-admission-on-head.txt`, `2-esconfigcheck-zero-key.txt`).

- `TestZZRT75SmallOrderVerificationKeysLoadAndAcceptForgedSignatures`: for each of the 14 values, the example `es.json` with that value as its verification keys loads through `es/config.Load`. A forged evidence seal is then accepted by `prepareArtifactFromEvidenceRecord`, and a forged trust policy is accepted by `verifyTrustModelEnvelope`. Each forgery took between 1 and 20 tries of a loop that uses only the standard library and no secret.
- `TestZZRT75AllZeroProvenanceKeySubmitsAnArtifactNobodySigned`: with 64 zeros as `verification.provenance`, `Service.Submit` registered a job with the test's Nomad for an artifact whose evidence record no key ever sealed ("run run-3c59ba71044b7947 registered with Nomad from evidence sealed without any private key").
- Power check, `TestZZRT75ForgeryIsRefusedUnderAGeneratedKey`: the same forgery under a generated key is refused.
- The upgrade gate: `scripts/internal/esconfigcheck` on the example `es.json` with 64 zeros in the four entries prints "es config accepted" and exits 0. On the unchanged example it exits 1 with the known-key error, as the PR intends.

**Why it matters.** No config the repository ships and no script in it writes such a key (ran: the key scan below, and the PR's guard test). The precondition is a person or a later template that fills a verification entry with a placeholder. Three things make that less remote than it sounds:

- The repository itself treats 64 zeros as the valid verification key: `es/config/config_test.go:1102-1117` and `:1141`. The example `es.json` uses 64 zeros as the placeholder for `nomad.server_spki_sha256` (`.examples/config/es.json:74`).
- After this PR the examples no longer load, so every manual bring-up now edits the four `verification` entries by hand.
- Read: ES builds the verifiers for `derivation_attestation` and `workload_identity_binding` and discards them (`es/admission/service.go:229-234`). An entry nothing uses is where a placeholder goes. It is harmless today and becomes live on the day a check starts to use it.

With such a value as `provenance`, whoever can make ARS hand ES an evidence record of their choosing runs an artifact AGS never sealed. With it as `trust_model`, whoever can answer ES as EGS allows any signer. Both need a second foothold, which is why this is Medium and not High. Counting only paths the repository ships, it would be Low. The upgrade gate saying "accepted" to such a file is the part I would not leave.

**Candidate repair (ran).** `candidate-repair/candidate-repair-A-refuse-small-order-and-mismatched-keys.diff`: `internal/knownkeys.Check` also refuses the 14 values, so AGS, EGS, ES and `esconfigcheck` refuse them through the one shared rule, and the `es/config` tests use a generated key in place of zeros. With it, the probes above fail with "WEAKNESS CLOSED" (`6-probes-on-candidate-repair-A.txt`). On `efc97e6`, `go test . ./es/... ./ags/... ./egs/... ./ars/... ./cgs/... ./internal/... ./scripts/internal/...` with the repair fails only the 18 tests that fail on the clean head in this container (15 in `es/app`, 3 in `es/admission/internal/reliablesubmit`); `./scripts` was not run on it. Contract 3B would need one more sentence for the second family.

Inference: the list of 14 is complete. It follows from the curve (eight points of small order, plus the non-canonical spellings Go accepts: `y = p`, `y = p + 1`, and a set sign bit where `x` is 0). Each of the 14 is proven by a forgery that `ed25519.Verify` accepted; that no fifteenth exists is not something a test can show.

**Proposed regression test.** `regressions/internal_knownkeys/small_order_regression_test.go`, `TestCheckRefusesEveryPublicKeyAnyoneCanSignFor`. For each of the 14 values it first forges a signature and requires `ed25519.Verify` to accept it, so the list in the test is proven and not assumed. It then requires `knownkeys.Check` to refuse the value and ES to refuse a config that has it in any of the four entries. Ran: fails on the head in all 14 subtests, passes with candidate repair A.

## RT75-2 (Low): AGS and EGS accept a 64-byte private key whose halves do not belong together

**What.** A 64-byte Ed25519 private key is the seed followed by its public key. `ags/sign/signer.go:38-39` and `egs/sign/signer.go:47-48` take the 64 bytes as they are. Go signs with the seed half and hashes the stored second half into every signature, and `PrivateKey.Public()` returns the stored half without deriving it. So `private_key_hex` = seed followed by some other public key, with `public_key_hex` = that other key, passes the "public key matches the private key" comparison, passes the known-key check, loads, and signs.

The PR knows this paste mistake exists. `knownkeys.CheckPrivate` checks both halves because "an operator may have pasted a known seed beside another public key" (`internal/knownkeys/knownkeys.go:58-61`). It checks each half against the known keys, but not that the halves match.

**Proof.** Ran on both heads: `TestZZRT75InconsistentSixtyFourByteKeyLeaksTheEGSKey` and `...LeaksTheAGSKey`. `config.Load` and `NewEd25519Signer` accept the key. Its signature verifies under neither public key. The operator then corrects the key (same seed, right public key) and the service signs the same bytes again. From the two signatures the probe computes the private scalar with one subtraction and one division, signs a trust policy and an evidence seal of its own choosing, and the ES verifier accepts both. A scalar that is off by one is refused, so the probe can fail.

**Why it matters.** It needs three things: a hand-made 64-byte key (`signingkeygen` writes 32-byte seeds, and setup never makes one), a correction that keeps the seed, and someone who sees both signatures over the same bytes. Read: EGS's signed policy is only the signer policy and the artifact policy, with no time, revision or nonce in the signed bytes (`egs/contract/trustmodel.go:15-18`), and AGS seals the same claim bytes when a publisher repeats a publish. That makes it Low. The fix is three lines per signer, and it also turns the silent state "the service runs and nothing it signs verifies" into a startup error.

**Proposed regression test.** `regressions/ags_sign/signer_test.go` and `regressions/egs_sign/signer_test.go`, `TestNewEd25519SignerRefusesA64ByteKeyWhoseHalvesDoNotBelongTogether`. Both honest spellings of a key (seed, and seed with its own public key) are accepted; the seed with another public key is refused whichever key `public_key_hex` names. Ran: fails on the head in both packages, passes with candidate repair A, which derives the key from the seed and refuses a mismatch.

## RT75-3 (Low): no test notices if every install gets the same key again

**What.** The PR's promise is that each host has its own key. Its tests check the shape of what setup writes: a 32-byte seed, a public key that matches it, a key ID derived from the public key, not a repeated-byte key, AGS and EGS different, and ES and EGS pointing at them. None checks that the keys in the configs are the ones generated in this run, or that two runs of the generator differ.

**Proof.** Two mutants, ran on both heads (`4-mutant-A-*.txt`, `5-mutant-B-*.txt`).

- Mutant A (`mutants/mutant-A-setup-writes-fixed-keys.diff`): after the setup renderer reads the generated keys, it replaces them with one fixed pair per role, a pair that is not a repeated-byte key. Every install would sign with keys that sit in the repository.
- Mutant B (`mutants/mutant-B-generator-fixed-random-source.diff`): the `signingkeygen` command hands `generate` a fixed random source. Two runs wrote the same AGS key file, key ID `ags-a555aefcfae4b91c`.

Both pass `go test ./internal/knownkeys ./internal/testutil ./scripts/internal/signingkeygen` and the render test `TestRetainedResultAuditF1RenderedConfigConstructsConfiguredService`. Read (grep on both heads): those are the only three test files that name the generator or setup's key function. On `efc97e6`, mutant A also ran through `go test . ./scripts ./es/admission ./es/config ./internal/...`: the failing names are the same 38 in `./scripts` that fail on the clean head in this container, and nothing else (`outputs/at-efc97e6/wider-packages-*.txt`).

Why they survive: the guard test `TestRepositoryShipsNoSigningKeyAServiceAccepts` looks for values assigned to a field named like `private_key_hex`, and mutant A holds its keys in a table. The generator's tests call `generate` with a random source of their own, and the one test that runs the built command runs it once.

**Why it matters.** This mutation is the bug the PR fixes, coming back with keys the refusal does not know. The refusal cannot catch it, so a test has to.

**Proposed regression tests.** Both pass on the head and fail on their mutant (ran).

- `regressions/es_admission/render-test-uses-generated-keys.diff`: the render test keeps the seeds the generator wrote and requires `ags.json` and `egs.json` to sign with exactly those. On mutant A: "ags.json does not sign with the key setup generated for this install".
- `regressions/scripts_internal_signingkeygen/fresh_per_run_test.go`, `TestCommandWritesADifferentKeyOnEveryRun`: runs the built command eight times and requires eight different private keys. On mutant B: "the command's random source repeats".

## RT75-4 (Low): only setup keeps the signer configs private; AGS and EGS load them with any mode

**What.** The PR adds this sentence: "The config file that holds a private key is readable only by the account that runs the service and by root: mode 0600 for supported-local, and `root:<service group>` mode 0640 for the Remote Alpha services" (`.docs/system_overview/configuration.md:263-265`). Setup creates the files 0600, and the Remote Alpha scripts set 0640. Nothing checks it anywhere else. The bring-up runbook's new manual steps say to generate each key "into a new file only you can read" and to copy it into the `signer` object of `ags.json` and `egs.json`; they give no mode for those two files.

**Proof.** Ran on both heads.

- `TestZZRT75ServicesLoadASigningKeyFromAConfigEveryUserCanRead`: `ags/config.Load` and `egs/config.Load` accept a config that holds a private signing key with mode 0644 and with mode 0666.
- `7-manual-steps-two-users.txt`: an operator (uid 1001, umask 022) follows the manual steps. The key file is 0600 and `ags.json` is 0644. A second user (uid 1002) is refused the key file and reads the private key out of `ags.json`.

**Why it matters.** It is the manual path only, and it needs a second local user on the host. The repository already refuses loose secret files at load in other places: ES refuses to start unless its Nomad token file is owned by its user with mode 0400 or 0600 (`configuration.md:772-776`, `es/admission/nomad_access.go:112`). Since this PR moves the trust of the whole publisher check onto these two files, the same treatment fits. Read: `signingkeygen` also does not look at the folder it writes into. Its own file is 0600 and created with `O_EXCL`, so this matters only in a folder another user can write without the sticky bit, where that user could swap the file before the operator copies it. Inference, not run.

**Candidate repair B and proposed regression test (ran).** `candidate-repair/candidate-repair-B-refuse-signer-configs-others-can-read.diff`: `ags/config.Load` and `egs/config.Load` refuse a file that is not regular or has any permission bit for other users, checked on the opened file. `regressions/internal_knownkeys/signer_config_mode_regression_test.go`, `TestAGSAndEGSRefuseASignerConfigOtherUsersCanReadOrWrite`: modes 0600, 0640, 0400 and 0440 load; 0644, 0604, 0602, 0601, 0666, 0646 and 0777 are refused, also through a symbolic link. It fails on the head and passes with repair B. On `efc97e6`, repair B broke no existing test in `go test . ./ags/... ./egs/... ./ars/... ./cgs/... ./internal/... ./es/app ./es/api ./scripts/internal/...` (the 15 `es/app` failures are the clean head's). `./scripts`, `es/admission` and `es/config` were not run on it. If the writer prefers documentation only, the runbook needs the mode in its manual steps and the sentence above needs to say that setup and the Remote Alpha scripts are what enforce it.

## What held

| Attack | Result | Source |
| --- | --- | --- |
| Other weak or published keys in the eight repositories | Only the two published pairs (seeds `0x11` and `0x33` repeated). Seven trees (ES at both heads and the first base, and six other repositories): 1,157 distinct 32-byte hex values against 66,769 predictable seeds (repeated, counting and alternating bytes, small integers, hashes and paddings of 54 likely words, the RFC 8032 vectors). The 73 archives of Archived-Chat-History, read in memory: 9,869 members, 19,372 distinct values, the same two pairs. Fields named like a private key, seed or signing key hold three distinct values in all: the two known seeds and one document hash in a review note (read in context, value masked). | ran: `outputs/keyscan-*.txt`, `outputs/private-key-fields-eight-repos.txt` |
| Getting a known key past the refusal by spelling or key form | 181,760 cases, none accepted: each of the 256 known keys, as seed, as 64-byte key, as either half of a mixed 64-byte key, as public key only, as private key only, each in ten spellings (case, spaces, tabs, line ends, Unicode spaces, a byte order mark, a `0x` prefix, an inner space), through AGS's and EGS's real config check and signer and ES's verifier check. | ran: `1-probes-knownkeys-on-head.txt` |
| Is the sweep able to fail | Yes. Without AGS's private-key check it reports 12,544 acceptances, and with only the stored half checked 25,088. A third mutant (only the seed half checked) changes nothing a service accepts, and the PR's own `TestCheckPrivateChecksBothHalvesOfA64BytePrivateKey` fails on it. | ran: `3-power-check-mutant-*.txt` |
| Verification-key lists, extra entries | ES has exactly four verification entries, each one key; unknown fields are refused. There is no list to append a second key to. | read, and the PR's tests |
| EGS allowed signers | The list holds key IDs, which are names. ES verifies the key itself with `verification.provenance`, so naming `ags-key-1` again gives nothing without the key. | read |
| Read or plant setup's key files as another local user | During `generate_supported_local_signing_keys` as root, uid 1002 looped 2,550 times: no read, no folder created, no link planted. Afterwards the proof root is 0755, `signing/` 0700 and both key files 0600, and uid 1002 can neither list nor read. The renderer also checks owner and mode before it reads, creates every config with `O_EXCL` and `O_NOFOLLOW` as 0600, and removes the key files. | ran: `8-setup-keygen-two-users.txt`; renderer read, and run through the PR's render test |
| A proof root planted in advance | Setup creates the root with a plain `mkdir` (`scripts/72_supported_local_setup.sh:1648`) and stops if it exists, so a planted root stops setup; it is not used. | read |
| Key in output, arguments, environment or logs | `signingkeygen` takes a role and a path, prints only the public part, and setup sends even that to `/dev/null`. The renderer reads the key files itself; no key passes through `argv` or the environment. The evidence collector's allowlist leaves the configs out, and each container mounts only its own config. | read; the public-only output also ran |
| Rerun or upgrade keeps an old key | Setup refuses an existing proof root, so it cannot reuse an old `ags.json`. `esconfigcheck` refuses the example `es.json` (exit 1). All four services load only through their validating `config.Load`. | read; `esconfigcheck` ran |

## Notes outside this target

- **PR #76 (the box rotation)** is not covered here. Two things for its own audit or red-team. Read at Archived-Runbooks `8d99aa0`: the recovery runbook copies and tars `ags.json`; after rotation such a copy holds the box's real private key. Inference from ES at `efc97e6` (I did not read #76's tree): rotation changes what ES checks from then on, and runs already admitted under the published key (running jobs, retained results) are not looked at again.
- **The port onto PR #73.** Grants keyed on `signer_key_id` are not in this tree. After the port, rerun `run-probes.sh` and check that the grant's key ID is the ID of a key that passed the same load check.

## Coverage this environment could not give

- Supported-local setup as a whole did not run: there is no Docker, Nomad, Vault or SPIRE here. Its key generation function ran for real, and its renderer ran through the PR's render test.
- No macOS, no Linux box, no real mTLS submit. The end-to-end proof of RT75-1 is `Service.Submit` against the test's own ARS and Nomad.
- The long package runs were made on `efc97e6` and not repeated on `4fb447d`. The merge changed no file that generates, renders or checks keys beyond the rename listed under "Target".
- `./scripts` was not run on either candidate repair, and `es/admission` and `es/config` were not run on repair B.
- The key scan reads hex. A search for base64 near key words found nothing, and PEM appears only in tests and in a redaction check; a key stored in some other encoding would not be seen.
- That the 14 small-order values are all of them is an inference (see RT75-1).

## For the writer, in order

1. RT75-1: refuse the 14 small-order values in `internal/knownkeys` (candidate repair A, first part), replace the zeros in `es/config/config_test.go`, add the regression test, and add the second family to contract 3B and to `configuration.md`, "Signing keys".
2. RT75-2: derive a 64-byte key from its seed and refuse a mismatch in `ags/sign` and `egs/sign` (candidate repair A, second part), with the two signer tests.
3. RT75-3: add the render-test lines and `TestCommandWritesADifferentKeyOnEveryRun`.
4. RT75-4: choose candidate repair B with its test, or the documentation change. If B, run `./scripts`, `es/admission` and `es/config` with it, which I did not.
5. Candidate repair A leaves `ags/sign/signer.go` as `gofmt` already reports it on the head; that file's indentation is not from the repair.
