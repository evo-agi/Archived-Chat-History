# ES PR #75: fixes for the paired re-checks ([model withheld], [model withheld])

STATUS: READY for a narrow re-check of the fix delta, then the gate.

- Repository: evo-agi/Execution-Substrate, branch `claude/project-thread-ljwd16`, base `trunk_dev` `0b9278c` (unchanged).
- Re-checked head: `6f83520`. Fix commit and new head: `ec9a5b9`.
- Review delta: `git diff 6f83520 ec9a5b9` (6 files, +85/-18).
- PR #76 (`claude/signing-key-rotation`): `ec9a5b9` merged in as `aba3fe6` (clean merge). #76's own change is unchanged (see "PR #76" below).
- Evidence: `14-pr75-recheck-fixes-evidence/` (manifests, commands, mutant runs, test runs, SHA256SUMS).

## Finding to fix map

| Finding | Severity | Fix | Proof |
|---|---|---|---|
| Sonnet R75-1: contracts.md counts the small-order keys as 12; the rule refuses 14 | Low | contracts.md 3B now lists the 14: the eight points, the two with x = 0 also written with the sign bit set, "and the four written with y = p or y = p + 1, each with either sign bit". | Doc only. `internal/knownkeys/smallorder_test.go` (unchanged) already requires the list to equal the 14 encodings derived from the curve. |
| Sonnet R75-2 / Opus O2: the config-mode test does not pin "regular file" or "judged by the file" (CM5, CM8 / C5, C6 survive) | Low | `internal/knownkeys/signer_config_mode_test.go`: a link to a 0600 config must load, and the same link after `chmod 0644` is refused (the check is on the opened file, not the link); a folder made 0700 (explicit `chmod`, so umask cannot change it) must be refused with "must be a regular file", which the other-users clause alone would let through. | CM5 and CM8 for AGS and EGS (drop `IsRegular`; `Lstat(path)` in place of the opened file's `Stat`) each fail the test, as a normal user and as root (`mutants-ubuntu.txt`, `mutants-root.txt`). |
| Sonnet R75-3 / Opus R1: no test for the generator's "another user owns the folder" branch (GF2 / N1 survive) | Low | `scripts/internal/signingkeygen/main.go`: `checkFolder(dir, euid)` takes the effective user ID (the caller passes `os.Geteuid()`), so the branch is testable without root. New `TestCheckFolderRefusesAFolderAnotherUserOwns`: on a sticky 1777 folder (the case Opus's probe showed: the sticky bit does not stop the folder's owner), `checkFolder(dir, owner)` passes, and `owner+1` and `0` (root judging a folder another user owns) are refused with "belongs to another user"; `checkFolder("/", owner+1)` passes (root's folders are fine). As root it first gives the folder to uid 65534 and requires `generate` to refuse it and write no file. | GF2 (branch removed), GF3 (root exception removed) and GF-inv (comparison inverted) fail it, as a normal user and as root. GF-call (caller passes another UID) fails as a normal user; as root it survives, because the folder then belongs to root and root's folders are allowed. CI's Linux and macOS test steps run as a normal user and kill it. |
| Opus O1: `checkFolder` judges only the folder itself | Observation | Comment and configuration.md now say what is checked: a folder that the user running it or root owns and that no other user can write (or that has the sticky bit), judged on the folder itself, with the reason the key belongs under folders of the user's own or root's (setup's are). No ancestor walk: both re-checks called it optional; setup is not affected (its renderer refuses key files another user owns, F3), and a walk would refuse ordinary macOS paths under `/private` links without a gain for setup. | Doc/comment only. |
| Sonnet O75-1: a test comment says the box's upgrade stops at `esconfigcheck` | Observation | `scripts/remote_alpha_upgrade_es_config_check_test.go` comment now says a host of the shape the upgrade checks is refused there, and the Remote Alpha box has another shape and is stopped by AGS, EGS and ES refusing to start. | Comment only. |
| Opus O5: report 08's map leaves out two product changes | Observation | Listed here: (1) `signingkeygen` refuses a folder another user could use to replace the key file (now `checkFolder(dir, euid)`, covered above); (2) the renderer's `read_signer` tells a missing key file apart from one that cannot be opened without following a link (tested, Opus mutant RS1 killed). Both were in the diff and the PR body. | Read. |
| Opus O6: no writer manifest for the head | Observation | Base-relative v2 manifests for both heads, each taken twice (identical) and checked against the committed blobs. | See "Manifests". |

## Observations kept as they are

These were judged in the re-checks as needing no change; listed so they are not rediscovered.

- Opus O3 / Sonnet O75-2: group bits are not judged (0660 loads). The documented modes are 0600 and 0640 and the group is the service's own on today's hosts. Tightening to `&0o027` would be a rule change; not made in this PR.
- Opus O4: keys derived from public secrets (a published key plus a small-order point, the negated point of F5) are an open family; #75 refuses the repeated-byte seeds and the 14 small-order values. A prime-order subgroup check would close most of it; not requested in this PR.
- Sonnet O75-3: equivalent or stricter survivors (CM7, GF7, GF8, G01). GF3 is now killed by the R75-3 test.
- Sonnet O75-4: red-team 06 regression files collide with the PR's adopted copies; the PR's copies run in the suite.

## PR #76

`aba3fe6` merges `ec9a5b9` into the rotation branch. `git diff --name-only 6f83520 e75c804` and `git diff --name-only ec9a5b9 aba3fe6` list the same 19 paths. 16 files are byte-identical at `e75c804` and `aba3fe6`. The other three (configuration.md, contracts.md, `scripts/remote_alpha_upgrade_es_config_check_test.go`) also carry #75's new lines, and #76's own hunks in them are identical in both comparisons. Work on #76 at `e75c804` (the audit and red-team under way) therefore applies to `aba3fe6` unchanged.

## Manifests (writer, v2 recipe, sha256 `c08597e2…a1ca` verified)

| PR | Tip | Base / upstream | Paths | manifest_sha256 | textual_diff_sha256 |
|---|---|---|---|---|---|
| #75 | `ec9a5b9` | `0b9278c` / `origin/trunk_dev` | 38 | `05f70f34869e25d1d3e4ccc0dd93aa2d32f41b1ac2edbe9fd95e55bebbfcea19` | `a8d2b7c853fa170b8b6ff04d72da19f8c54c03309ebac63461061eef33a870de` |
| #76 | `aba3fe6` | `ec9a5b9` / `origin/claude/project-thread-ljwd16` | 19 | `dd19d7bd7f1424a61e2157d3fa07f7f08df3050c6a85bd43e4ce3f659645faf3` | `a96ec5c60b371b0f31e577051b57893724f294bd7dd9b4eb35c7775b72c641b7` |

For each: path set equals `git diff --name-only BASE TIP`, and every record equals the blob at the tip (SHA-256, size, exec bit): 0 differences (`blobcheck.py`). Commands: `commands.txt`.

## Validation (Linux cloud container)

At exact bytes of `ec9a5b9`:

- As a normal user (umask 022): `internal/knownkeys`, `scripts/internal/signingkeygen`, `ags/sign`, `egs/sign` pass (`tests-ubuntu.txt`).
- As root: the root package (docs contract tests), `internal/knownkeys`, `scripts/internal/signingkeygen` (with the root-only part of the new test) and `internal/testutil` pass; `go vet` on `scripts`, `signingkeygen`, `knownkeys` clean; `gofmt -l` clean on the changed files (`tests-root.txt`).
- Mutants (`mutants.py`): 8 of 8 killed as a normal user; 7 of 8 as root (GF-call, explained above).

At `aba3fe6` as root: the root package, `internal/knownkeys`, `signingkeygen`, `internal/testutil` pass (`tests-root-aba3fe6.txt`).

CI on `ec9a5b9` and `aba3fe6` (Linux and macOS) started 06:50Z; it is the check that counts for the container-only failures listed in reports 08 and 09.

## Not done here

- No box run (unchanged: #76's rotation runs on a box turn after its gate).
- The #73 port (`provenance_key_id` from the generated AGS key) waits for #73 to merge.
