# Final re-check of ES PR #75 at ec9a5b9: per-host AGS and EGS signing keys ([model withheld])

**Verdict: BLOCK (one Low, S15-1).** All three of my earlier Lows (R75-1, R75-2, R75-3) and my observation O75-1 are fixed, and where a test is the fix, it kills the mutants it should, as a normal user and as root. The writer's six claims about the Opus items (O1, O2, O5, O6, O75-1, R1) hold, with one wording nit about report 14 (N75-1). The block is a defect outside the delta: since the PR's first commit (`efc97e6`), `go test ./internal/testutil` fails in a source tree that has no `.git` (a `git archive` export, or a tree unpacked from a source archive), because `internal/knownkeys/repository_test.go` builds the path `<root>/.git`, which that tree does not hold, and `testutil`'s own guard refuses such a path. The repository supports such trees on purpose, CI cannot see the failure (it always checks out with `.git`), and every earlier pass on this PR, mine included, ran in a git clone. The repair is a few lines in the one test file, which I ran in both kinds of tree (below). It fails closed and touches no product code, but the standing rule is that Lows are fixed in the PR.

**How I found S15-1, which you need to know for the trial.** I did not find it by my own method. When I went to append my trial row, I printed the tail of the shared trial log, and the last row there was the Opus pair's; the first 260 characters of it, which my terminal showed, named this very failure (test name, no-`.git` tree, since `efc97e6`). I stopped reading there and did not open the Opus report. I then reproduced the failure myself at `efc97e6`, `6f83520` and `ec9a5b9`, showed `fbfd100` and `0b9278c` pass, found the cause, and wrote and ran a repair. So the finding is verified independently, but this run **would have missed it without the hint**, as my re-check 13 did. Count it as a Sonnet miss, found with help, when you compare. This is a second leak of the pair's content into my run (the first is below), both through shared places that I did not expect to hold it; I would suggest the trial log and the memory index not carry a pair's findings before both runs are in.

**A third leak, after the findings were written.** While I was saving notes, the harness showed me, unprompted, the full text of the Opus memory note for this head (`es-pr75-recheck-opus`, updated 07:09Z). It gives its R15-1 with a prototype repair (a change to the `testutil` guard, not to the test), a note that report 14 overstates what `configuration.md` says, and two mutant observations. By then S15-1, its cause, my repair, N75-1 and my CM7 survivor were already in this report from my own work, so I did not change any finding because of it. The one thing I took from it, after checking the file myself, is the citation of `artifact_hygiene.md:242-248`. I am telling you so you can judge how much of the overlap between the two runs is independent: S15-1 only through the first hint; N75-1, the survivors and everything verified above, from my own reading and runs.

**The PR head moved while I worked.** At 07:14:13Z the writer pushed `827686a` ("Test-path guard: accept .git, so a tree made with git archive passes"; one file, `internal/testutil/testutil_test.go`, +7/-1, parent `ec9a5b9`). That is a repair of S15-1 by changing the guard instead of the test, as far as its title says. **I have not reviewed it**; I only read its stat and message. It cancelled CI on `ec9a5b9` at 07:14:34Z and started CI on `827686a` at 07:14:40Z. So this report is about `ec9a5b9` and its verdict stands for that head, and the new head needs its own delta check and CI. CI cannot show S15-1 on any head, because it always runs in a checkout with `.git`.

**Effect status:** read-only. I pushed, posted and merged nothing, and I did not touch the box or any other machine. All work ran in throwaway clones in this container. (The one write outside it: this report, its evidence folder, and one row appended to the shared trial log, as the brief asked.)

| Field | Value |
| --- | --- |
| Model | `[model withheld]`, trial category R-M (security), real run, paired with an Opus run |
| Blind pair | **Not blind, in three ways.** I did not open `12-pr75-recheck-opus.md`, `15-pr75-recheck-opus.md` or their evidence. (1) The memory index injected a one-paragraph summary of the earlier Opus re-check (note `es-pr75-recheck-opus`, about report 12) into my context at the start of the thread. It named R1, O1 to O6, and that the verdict was BLOCK on R1. (2) The trial log's last row was the Opus pair's for this head, and the first 260 characters of it were shown to me (see the headline); they named the no-`.git` failure. I judged items R75-1 to R75-3, O75-1 and O1 to O6 from the code and report 14, not from either summary, (3) After I had written the findings, the harness showed me the Opus memory note in full (see the third leak, in the headline). I judged items from the code and report 14, not from any of them, but the coordinator should weigh this run's independence accordingly. |
| Subagents | None |

## Target and scope

| Item | Value |
| --- | --- |
| Repository, PR | evo-agi/Execution-Substrate #75, branch `claude/project-thread-ljwd16`, open, not draft, head read through the GitHub tool |
| Head | `ec9a5b947e0335590c8dc1311153180702fe26a1`, tree `a74868bfc8d3738a2e000e6e92978ffa7a50abac` (the writer's reported tree) |
| Base | `trunk_dev` `0b9278ca74404b46b5e9f0e1701874b52687f5e8` (unchanged since the last re-check) |
| Delta checked | `git diff 6f83520 ec9a5b9`: 6 files, +85 / -18, SHA-256 `a1c6613e90deb8b7f859b1123d0ffae389fe8a496eda58ceca698c8bd95ab783` (in the evidence folder). It matches the writer's "6 files, +85/-18". |
| What the delta touches | Two docs (`configuration.md`, `contracts.md`), one test (`internal/knownkeys/signer_config_mode_test.go`), one comment-only test edit (`scripts/remote_alpha_upgrade_es_config_check_test.go`), and `scripts/internal/signingkeygen/` (`main.go`: `checkFolder(dir)` becomes `checkFolder(dir, euid)` with one call site; `main_test.go`: one new test). No other product code changed. |
| Earlier reports | `13-pr75-recheck-sonnet.md` (mine), `14-pr75-recheck-fixes-report.md` (the writer's fix map). I read reports 13 and 14 and did not read report 12. |

## Provenance reproduction (Ran)

- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`. Checked with `sha256sum -c` before the first run: OK. I did not edit it.
- Pushed tip equals the reported tip; base is an ancestor of the tip; clean checkout, `git status --porcelain` empty; tip tree equals the writer's. Then `HEAD` reset to `0b9278c`, upstream pinned to `origin/trunk_dev`, v2 run twice to two absent paths in a fresh 0700 folder outside the repo.
- Result: the two runs are byte-identical. `manifest_sha256` `05f70f34869e25d1d3e4ccc0dd93aa2d32f41b1ac2edbe9fd95e55bebbfcea19`, `textual_diff_sha256` `a8d2b7c853fa170b8b6ff04d72da19f8c54c03309ebac63461061eef33a870de`, 38 files. **The manifest file is byte-identical to the writer's `manifest-75-ec9a5b9-v2.json`** (closes Opus O6 for #75).
- PR #76: `aba3fe6` has parents `e75c804` (the rotation branch's own tip) and `ec9a5b9`. Same recipe and procedure with base `ec9a5b9` and upstream `origin/claude/project-thread-ljwd16`: two identical runs, `manifest_sha256` `dd19d7bd7f1424a61e2157d3fa07f7f08df3050c6a85bd43e4ce3f659645faf3`, 19 files, equal to the writer's `manifest-76-aba3fe6-on-ec9a5b9-v2.json`. Tree `d65788d3…`, as reported.
- #76's claim that the merge changed nothing of its own: `git diff --name-only 6f83520 e75c804` and `git diff --name-only ec9a5b9 aba3fe6` list the same 19 paths; 16 of them have the same blob at `e75c804` and `aba3fe6`; the other three (`configuration.md`, `contracts.md`, `scripts/remote_alpha_upgrade_es_config_check_test.go`) have identical `+`/`-` lines in both comparisons. And `git diff --stat e75c804 aba3fe6` is byte-for-byte the same as the #75 delta's stat (same SHA-256). So the merge brought in exactly the six-file delta and nothing else. This is a check of the merge claim only; I did not audit #76.
- Closing state: my clones are clean again (`git status --porcelain` is empty for the audit clone, the two mutant clones and the #76 clone).

## Fix-by-fix result (delta 6f83520 to ec9a5b9)

| ID | Was | Result at ec9a5b9 | How I checked |
| --- | --- | --- | --- |
| R75-1 (Low, contract wording) | contracts.md 3B said "the two written with y = p and y = p + 1", which adds to 12; the rule refuses 14 | **Fixed.** Now "the eight such points, the two whose x is 0 also written with the sign bit set, and the four written with y = p or y = p + 1, each with either sign bit": 8 + 2 + 4 = 14. | Read `contracts.md:299-304` and counted the 14 entries of `smallOrder` in `internal/knownkeys/knownkeys.go:58-71` by hand against the comment on each line (8 canonical, 2 with the sign bit on x = 0, 4 for y = p and y = p + 1). `configuration.md:277` says "the 14" and agrees. `smallorder_test.go` (unchanged) derives the set from the curve and requires equality with the list; it passes as `ci` and as root. No other text in docs, PLANS.md or the runbook gives another count. |
| R75-2 / Opus O2 (Low, test gap) | CM5 (regular-file clause dropped) and CM8 (`Lstat(path)` for `file.Stat()`) survived for AGS and EGS | **Fixed.** `TestAGSAndEGSRefuseASignerConfigOtherUsersCanReadOrWrite` now loads a link to a 0600 config (must load), the same link after `chmod 0644` (must be refused), and a folder made 0700 by an explicit `chmod` (must be refused with "must be a regular file", which the other-users clause cannot produce for 0700). | Mutants CM5-ags, CM5-egs, CM8-ags, CM8-egs each killed by this test, as `ci` and as root. The mode-clause mutants CM1 to CM4 and CM6 for both services stay killed (regression). Ran. |
| R75-3 / Opus R1 (Low, test gap) | The "another user owns the folder" branch of `checkFolder` had no test (GF2, GF3 survived) | **Fixed.** `checkFolder(dir, euid)`; `generate` passes `os.Geteuid()`. `TestCheckFolderRefusesAFolderAnotherUserOwns` uses a sticky 1777 folder (only the owner rule can refuse it): own folder passes; `owner+1` and `0` are refused with "belongs to another user"; `/` passes for `owner+1`; as root it first gives the folder to uid 65534 and requires `generate` itself to refuse it and write no file. | GF2, GF3, GF-inv killed by this test as `ci`; as root GF2, GF3 and GF-inv killed. Extra mutants I added: owner test with `>`, `<`, `||`, `st.Uid == 0`, and a changed message: all killed (`GF-gt`, `GF-lt`, `GF-or`, `GF-rooteq`, `GF-msg`). The permission clauses (GF1, GF4, GF5, GF6) and the earlier generator mutants G07 and G08 stay killed. |
| O75-1 (observation, mine) | A test comment said the Remote Alpha box's upgrade stops at `esconfigcheck` | **Fixed.** The comment now says a host of the shape the upgrade checks is refused there and the box has another shape and is stopped by AGS, EGS and ES refusing to start. | Read the comment (`remote_alpha_upgrade_es_config_check_test.go:180-184`). Checked it against the upgrade script: `esconfigcheck` is called only in `inspect_start` (shape `locked-http`, `remote_alpha_upgrade_es.py:1198-1222`) and in the apply step; the shape-`https` path runs `inspect_migrated`, which has no config check. The comment is accurate. |
| Opus O1 (observation) | `checkFolder` judges only the folder itself | **Handled as the writer says**, with one wording nit (N75-1). The code comment now states the limit and the reason (`main.go:128-130`); `configuration.md:254-255` states the rule on the folder (owned by the running user or root, no other user can write unless sticky); the PR body says "judged on itself". | Read all three. The ancestor-swap case stays an accepted limit, as both earlier re-checks said it could. |
| Opus O5 (observation) | report 08's map left out two product changes | **Done in report 14.** Both changes are in the PR and tested. | (1) the folder rule: now tested (R75-3). (2) `read_signer` telling a missing key file from one that cannot be opened without following a link (`72_supported_local_setup.sh:1348-1356`): I changed that message and then removed `O_NOFOLLOW`, in a throwaway copy; `TestSupportedLocalRendererKeepsTheSigningKeysPrivate` failed both times. |
| Opus O6 (observation) | no writer manifest for the head | **Done.** The writer's manifests for #75 at `ec9a5b9` and #76 at `aba3fe6` are byte-identical to the ones I produced independently (see Provenance). | Ran. |

## Findings

No Critical, High or Medium finding. One Low:

### S15-1: `internal/testutil` fails in a source tree without `.git`, since `efc97e6`

- Type / Severity: bug in a test (test and docs gap against the repository's own support for such trees) / **Low**
- Evidence (Ran, as `ci`, `tests/no-git-tree-runs.txt`): in a tree made with `git archive` (no `.git`), `go test ./internal/testutil` fails with `internal/knownkeys/repository_test.go:25: filepath.Join resolves ".git" against the repository root, which holds no such name` (`TestImportersNameRepositoryPathsFromTheRoot`). It passes at `fbfd100` (the PR's base before `efc97e6`) and at `0b9278c`, and fails at `efc97e6`, `b9c80e1`, `6f83520` and `ec9a5b9`. So the PR introduced it, in its first commit, outside the delta of this re-check. The cause is `repositoryFiles` in `internal/knownkeys/repository_test.go` (line 25 at `ec9a5b9`): `os.Lstat(filepath.Join(testutil.Root, ".git"))` is how it tells a git checkout from a source tree, and the guard in `internal/testutil` (`testutil_test.go:153`) refuses a repository path built from a name the root does not hold, for every package whose tests import `testutil`. The test's own comment says it handles "a tree unpacked from a source archive", and `.docs/system_overview/artifact_hygiene.md:242-248` says the tests that read every repository file "still run in such a tree" (one exported with `git archive`), and the root package's `artifact_hygiene_test.go:26-31` and its subtest "source tree without .git" implement that, so the repository supports such trees on purpose; the new package's no-`.git` branch passes on its own (`internal/knownkeys` is ok in the no-`.git` tree). Nothing else the PR added fails there: `scripts/internal/signingkeygen`, `ags/sign`, `egs/sign`, `es/config`, the root package, the renderer tests, `TestESConfigCheckAgreesWithConfigLoad` and the `es/admission` render test all pass in the no-`.git` tree.
- Impact: none on product behavior. `go test ./...` in an exported source tree fails one test that is not about that tree, hiding real failures there. CI cannot see it: both jobs run in a checkout with `.git`. All earlier passes on this PR (audit 04, red-team 06, my re-check 13, the writer's runs) ran in git clones, which is why it was not found before.
- Required correction (proposed and run, `delta/s15-1-proposed-repair.diff`): look for the name in a listing of the root instead of joining it to the root (`os.ReadDir(testutil.Root)` and compare entry names to `.git`), which the guard does not flag and which means the same thing. With it, `internal/testutil` and `internal/knownkeys` pass in the no-`.git` tree and in a git clone (where the `git ls-files` branch runs); `gofmt -l` is clean. If you want the class kept closed, a CI step that runs `go test ./internal/testutil` (about 0.2 s) in a `git archive` export would catch the next one; that is a CI change with its own gate, so I list it as an option, not a requirement.
- Also applies to PR #76: `aba3fe6` contains the same `repository_test.go` byte for byte (the merge brought it in and #76's own diff does not touch it), so the repair has to reach #76 too.
- Patch defect or pre-existing: patch defect (added by `efc97e6`, outside this re-check's delta).

### Observations (no action required, not blocking)

- **N75-1 (nit about report 14, not about the PR).** Report 14's row for O1 says configuration.md now says the check is "judged on the folder itself, with the reason". It does not: configuration.md says what the generator requires of the folder, and the "judged on the folder itself, and why the key belongs under folders of your own or root's" part is only in the code comment (and "judged on itself" in the PR body). The operator-facing text is accurate as far as it goes. If you want the limit in the doc as well, one clause in `configuration.md` after line 255 would do it; I would not hold the merge for it.
- **O75-5. Survivors of my 37 mutants, with the reason each is acceptable.**
  - `CM7-ags`, `CM7-egs` (`os.Stat(path)` before the open): a race only on a path whose folder only its owner should control. Same as my earlier O75-3.
  - `CM9-ags`, `CM9-egs` (new, mine: the regular-file clause narrowed to `info.IsDir()`): the folder case is the one non-regular file a portable test can feed the clause. Inference, not run: `os.Open` on a FIFO blocks until a writer opens it, before `Stat` is reached; a socket cannot be opened; a device node with an owner-only mode would fail the JSON decode. So I do not see a portable test that kills it, and I do not see a security effect.
  - `GF7` (`!info.IsDir()` dropped), `GF8` (`Lstat` instead of `Stat`): equivalent or stricter, as in O75-3.
  - `GF-call`, `GF-call0` (the call site passes another user ID): survive **as root only**. As root, the folders the tests make belong to root, and `checkFolder` accepts a root-owned folder whatever ID it is given, so the wrong ID changes nothing the tests can see. As a normal user they are killed by `TestGenerateWritesAFreshKeyOnlyItsOwnerCanRead`, `TestGenerateRefusesAKnownKeyFromABrokenRandomSource` and `TestCommandPrintsOnlyThePublicPart`. CI's Test steps on Linux and macOS run as the job's normal user (`go.yml`, `go-macos.yml`; the only root step runs the `scripts` package), so CI kills them. The writer said the same about GF-call.
- Kept as they are, and I agree with leaving them: Opus O3 / my O75-2 (group bits are not judged; 0640 is a documented mode), Opus O4 (a known key plus a small-order point is an open family; prime-order subgroup check not requested), my O75-4 (red-team 06 regression files collide with the PR's adopted copies).
- A small cosmetic thing, not worth a change on its own: in `contracts.md` 3B the sentence "Anyone can make a signature" now sits alone on a short line after the edit. The docs tests pass.

## Validation

**Normal user `ci` (uid 30033, umask 022, Go 1.26.5, clean environment, `GOPROXY=off`), clean clone at the exact tip (Ran):**

| Command | Result |
| --- | --- |
| `go test -count=1 ./internal/knownkeys ./scripts/internal/signingkeygen ./ags/... ./egs/... ./internal/testutil ./es/config` | all ok (`ags/app` 21.9 s, `egs/app` 9.1 s) |
| same packages with `-v`, plus the root package `.` (the docs contract tests) | all `--- PASS`, no FAIL, no SKIP (`tests/tests-as-ci.txt` in the evidence folder) |
| `go test -count=1 -v -run TestSupportedLocalRenderer ./scripts` | `TestSupportedLocalRendererKeepsTheSigningKeysPrivate` PASS; `...RefusesASigningKeyFileAnotherUserOwns` SKIP (it needs root; as `ci` it skips itself, and CI's root step runs it) |
| `go test -count=1 -v -run TestRetainedResultAuditF1RenderedConfigConstructsConfiguredService ./es/admission` | PASS (the render test that runs key generation) |
| `go test -count=1 -v -run TestESConfigCheckAgreesWithConfigLoad ./scripts` | PASS, all 10 subtests including "published signing keys" |
| `go vet ./...` | exit 0 |
| `GOOS=darwin GOARCH=arm64 go vet` on `internal/knownkeys`, `scripts/internal/signingkeygen`, `ags/config`, `egs/config` | clean |
| `gofmt -l` on the four changed Go files | empty |

Totals for everything run as `ci` (the log `tests/tests-as-ci.txt`): 274 `--- PASS`, 0 FAIL, 1 SKIP (the root-only renderer test).

**Root, clean clone at the exact tip (Ran):** the same list as above, with the root-only renderer test running: 275 `--- PASS`, 0 FAIL, 0 SKIP (`tests/tests-as-root.txt`). `TestSupportedLocalRendererRefusesASigningKeyFileAnotherUserOwns` PASS; `TestCheckFolderRefusesAFolderAnotherUserOwns` PASS through its root branch (the folder given to uid 65534).

**Failing test names:** none in anything I ran. I did **not** re-run the whole suite (about 9 minutes, and 262 failing names at the base and at `6f83520`, all container-only). The delta changes no product code outside one function's signature, `go vet ./...` compiles every package and test, and the packages the delta can affect pass as listed. That is a narrower claim than "the whole suite matches the base", and I am not making the wider one for this head. CI is the check for the rest.

**Mutants (Ran, `mutants/mut.py`, one mutant at a time on a clean clone, restored and checked clean after each):**

| Run | Mutants | Killed | Survived |
| --- | --- | --- | --- |
| as `ci` | 37 | 31 | 6 (CM7 x2, CM9 x2, GF7, GF8) |
| as root | 37 | 29 | 8 (the same six, GF-call, GF-call0) |

The 37: the config-mode family for both services (CM1 to CM9, 18), the folder-owner and permission family (GF1 to GF8, GF-inv, GF-call, GF-call0, GF-gt, GF-lt, GF-or, GF-rooteq, GF-msg, 16), generator controls G07 and G08, and one known-key control (K-ctl). The writer's 8 re-check mutants are all among them and give the writer's results: 8 of 8 killed as `ci`, 7 of 8 as root (GF-call).

**Source trees without `.git` (Ran, as `ci`, `git archive` of each commit, `tests/no-git-tree-runs.txt`):** `internal/testutil` passes at `fbfd100` and `0b9278c`, fails at `efc97e6`, `b9c80e1`, `6f83520` and `ec9a5b9` (S15-1). At `ec9a5b9` the other packages the PR added or changed pass in such a tree (list under S15-1). With the proposed repair applied, `internal/testutil` and `internal/knownkeys` pass in the no-`.git` tree and in a git clone.

## CI on the exact head

None completed for `ec9a5b9`. Runs 45954413126 (Linux "build, vet and test", job 140357460539) and 45954413193 (macOS "test on macOS", job 140357460594) started 06:50Z and were cancelled at 07:14:34Z when `827686a` was pushed. Before that: on macOS the "Check the test gate" and "Test" steps had succeeded (Test 06:56:59Z to 07:13:44Z) and the "Listed tests still fail" step was the one cancelled; on Linux the steps up to "Check the test gate" had succeeded and "Test" was cancelled. A cancelled run is not a result, so I do not count either job for or against `ec9a5b9`. CI on `827686a` (runs 45957080014 Linux and 45957080008 macOS) started at 07:14Z.

## Coverage this pass did not give

- No box, no macOS run of mine, no full suite (above). No red-team: this was a delta check.
- I did not open report 12, report 15 (Opus) or their evidence (see the pair note above).
- Source trees without `.git`: I ran the packages the PR added or changed, the root package and the two `scripts`/`es/admission` tests that read repository files. I did not run the whole `scripts`, `es/app` or `es/admission` packages in such a tree, so other tests there may fail for reasons that have nothing to do with this PR.
- I did not re-run the red-team 06 probes: nothing in the delta touches the code they probe (`internal/knownkeys`, `sign`, the config `Load` functions are byte-identical to `6f83520`; checked with `git diff --stat`).
- ACLs, SELinux and filesystem types were not exercised.

## Sensitive-material handling

The repository's published seeds are public and appear only as the rule's subject. The tests and mutants made fresh keys in throwaway folders in this container; none was printed or kept. The evidence holds only manifests, diffs, mutant results and test logs. I scanned the evidence for repeated-byte seeds and 64-hex private-key assignments and found none.

## Confidence

- Provenance: very high (both manifests reproduced byte for byte, matching the writer's).
- Validation: high for the delta (every changed behavior run as `ci` and root, 37 mutants); no completed CI for this head, and CI cannot show S15-1.
- Implementation: high that the six files do what report 14 says and that nothing is widened; the delta is a doc count, tests, a comment, and a parameter that carries `os.Geteuid()` at its only call site. Medium-high that the PR has no other defect of the S15-1 kind: I found S15-1 by a hint, so my own method did not cover that class, and I checked the no-`.git` case only for the packages the PR added or changed.

## Effect status and delivery

Read-only; nothing pushed, posted, merged or deployed; the box and the Mac untouched. Evidence (no secrets): `15-pr75-recheck-sonnet-evidence/` in this folder, see its README.

**Trial row for the coordinator:**

`| 2026-11-27 | R-M (security) | ES #75 @ ec9a5b9 | final re-check (real) | [model withheld] | BLOCK | S15-1 Low (internal/testutil TestImportersNameRepositoryPathsFromTheRoot fails in a source tree without .git since efc97e6: knownkeys/repository_test.go:25 joins ".git" to the root; repair written and run in both kinds of tree). Found only after the first 260 characters of the Opus pair's row in this log were shown to me; reproduced and root-caused independently. R75-1, R75-2, R75-3, O75-1 and the Opus items O1, O2, O5, O6, R1 verified fixed (37 mutants: 31 killed as ci, 29 as root; survivors equivalent or killed by CI's normal-user step) | NOT blind: a memory note on the earlier Opus re-check and a truncated Opus log row were visible; Opus report 15 not opened. Count S15-1 as a Sonnet miss found with a hint. Also missed by my re-check 13 (all runs in git clones). Report signing-keys/15-pr75-recheck-sonnet.md |`

**Final verdict: BLOCK** (S15-1 Low; N75-1 and O75-5 observations). Everything else in the delta is accepted. The writer's `827686a` looks like the repair for S15-1 (one file); it needs a fresh delta check limited to that file, run in a tree without `.git` as well as in a clone, and CI green on that head.
