# ES PR #75: R15-1 fix and merge into trunk_dev

STATUS: READY. #75 is merged into `trunk_dev`.

## R15-1 fix (`827686a`)

- Finding: re-check 15 (Opus), R15-1 Low, test bug against `trunk_dev`: `internal/testutil` `TestImportersNameRepositoryPathsFromTheRoot` failed in a source tree without `.git` (a `git archive` tree), because the test-path guard refused `filepath.Join(root, ".git")` in `internal/knownkeys/repository_test.go:25` as a name the root does not hold.
- Fix: `internal/testutil/testutil_test.go` (+7/-1). The guard accepts the root name `.git` itself, and exactly that value. Where the root holds no `.git` (an archive tree, or the guard's self-test root) it still refuses a path under it, such as `.git/HEAD`; the self-test requires both.
- Proof (`17-pr75-merge-evidence/`): in a `git archive` tree, run as a normal user, `go test ./internal/testutil ./internal/knownkeys` fails at `ec9a5b9` (`r15-archive-tree-before.txt`) and passes at `827686a` (`r15-archive-tree.txt`).
- Re-checked: paired re-checks 16 (Opus `16-pr75-recheck-opus.md`, Sonnet `16-pr75-recheck-sonnet.md`) both ACCEPT `827686a`. O16-2 and O16-3 (PR body) are done: the PR body's Validation covers `827686a` and its "Review" section names the audits and the manifest. O16-1 needs no change.

## MERGE REPORT

```text
MERGE REPORT
Repository / accepted audit target / audit report path and SHA-256
  evo-agi/Execution-Substrate; base trunk_dev 0b9278ca74404b46b5e9f0e1701874b52687f5e8,
  topic 827686a28dcb8d5e01465a401d96dc1ba61557a6, tree 8c9a9b2b789f10de01bd6a0ffdc552ac686cd82e,
  v2 manifest cddd3cca7cde2eded655c50b9015cd4d7cb65bcd939ac2cb7e3728bec89fe85c (39 paths)
  reports/Execution-Substrate/signing-keys/16-pr75-recheck-opus.md
    sha256 2dae5190ebeaffbf00722dbae3ed5a105ecd00e0df75847dda0fa0392b57c8e5 (ACCEPT)
  reports/Execution-Substrate/signing-keys/16-pr75-recheck-sonnet.md
    sha256 e918a6e2c960e382b9fe25165c2d8f577b83804d1227298bb882414b06aeb629 (ACCEPT)
  Earlier rounds: audit 04, red-team 06, re-checks 12 to 15 (findings fixed in 08, 14 and 827686a).
PR link and head SHA; equality with audited commit
  https://github.com/evo-agi/Execution-Substrate/pull/75, head 827686a28dcb8d5e01465a401d96dc1ba61557a6; equal to the audited commit: EQUAL
Branch update performed? range-diff result; re-check or re-audit reference
  No. trunk_dev was 0b9278ca74404b46b5e9f0e1701874b52687f5e8 at the merge, the audited base; 0b9278c is an ancestor of 827686a.
CI on 827686a
  "build, vet and test" success (07:14:40Z to 08:00:16Z); "test on macOS" success (07:14:47Z to 07:46:31Z).
Open findings
  None blocking. GitHub review threads: 0. Codex: no findings (efc97e6).
David's go: message reference
  Standing policy, decisions.md #7 (David 2026-11-22, amended 20:18Z and 20:22Z): after his first
  three product PRs, the coordinator merges after audit, red-team where required and the merge gate.
  The coordinator delegated this merge to the signing-keys thread on 2026-11-27 07:26Z.
Merge commit and resulting trunk_dev SHA; post-merge byte check
  Squash merge be20ffc8a5f82a35c4ce9064594a081f419c1ef5; trunk_dev = be20ffc8a5f82a35c4ce9064594a081f419c1ef5. Tree of be20ffc8a5f82a35c4ce9064594a081f419c1ef5 = 8c9a9b2b789f10de01bd6a0ffdc552ac686cd82e,
  equal to the audited tree 8c9a9b2b789f10de01bd6a0ffdc552ac686cd82e: EQUAL (post-merge-byte-check.txt).
Unauthorized effects: none
Remaining limitations:
  No box run (the box still signs with the published keys; #76 rotates them on a box turn).
  P16-1 (re-check 16): a CI step that runs the tests in a git archive tree would catch R15-1's
  kind of failure. O16-1 ([model withheld]): the guard's self-test does not pin "exactly .git"
  (G5, G6, G7, G9 survive; a four-line fixture addition kills them). Both fit one small
  tests/CI-only PR on trunk_dev, not part of #75 or #76.
Report delivery: this file; SHA-256 in the thread reply
```

## Effect on the other open PRs

- #76 (stacked on #75): GitHub moved its base to `trunk_dev` when #75's branch was deleted. Its branch already holds `827686a` (merged in at `2f455c5`), and `trunk_dev`'s tree equals that commit's, so `trunk_dev` is merged in with git's `ours` strategy (`c9c1e40`, local until the #76 push): the branch's tree does not change. A content merge conflicts in five files only because the squash gives git the old merge base `0b9278c`. No rebase, no force-push.
- PRs branched from `trunk_dev` before this merge (#70, #73, #74, #77, #78) need `trunk_dev` merged in before their own gates. #73 conflicts with #75 (port notes in this thread: the workload grant's `provenance_key_id` must come from the generated AGS key).
