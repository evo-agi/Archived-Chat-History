#!/usr/bin/env bash
# Read-only check: does the Remote Alpha box sign and verify with the signing
# keys the Execution-Substrate repository publishes? (ES thread "Give each
# host its own signing key", 2026-11-27.)
#
# Run from a Remote Control session on David's Mac:
#   ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] 'bash -s' < 01-box-key-check.sh > out.txt 2>&1
#
# What it does: reads /etc/execution-substrate/{ags,egs,es}.json with sudo -n
# and prints, for each signing or verification key, its key_id, its PUBLIC
# key (public by definition), and whether it is one of the keys the
# repository publishes (private seed 0x11 or 0x33 repeated, public keys
# d04ab232...8737 and 17cb79fb...80ce). It also prints each file's owner and
# mode, EGS's allowed and revoked signer IDs, and how many records ARS's
# index holds (a count only).
# What it never does: print a private key or any part of one, change a file,
# restart a service, or write anywhere but its own scratch folder under /tmp,
# removed at exit.

set -u
export LC_ALL=C
SCRATCH="$(mktemp -d /tmp/es-keycheck-ro.XXXXXX)"
trap 'rm -rf -- "$SCRATCH"' EXIT
SUDO="sudo -n"

echo "host: $(hostname) at $(date -u +%Y-%m-%dT%H:%M:%SZ)"
for f in ags egs es ars; do
  p=/etc/execution-substrate/$f.json
  printf '%s: ' "$p"; $SUDO stat -c '%U:%G %a %s bytes, modified %y' "$p" 2>&1 || true
done

cat > "$SCRATCH/keys.py" <<'PY'
import json, sys
PUBLISHED_PUBLIC = {
    "d04ab232742bb4ab3a1368bd4615e4e6d0224ab71a016baf8520a332c9778737": "the repository's AGS example key (seed 0x11 repeated)",
    "17cb79fb2b4120f2b1ec65e4198d6e08b28e813feb01e4a400839b85e18080ce": "the repository's EGS example key (seed 0x33 repeated)",
}
def verdict(pub):
    pub = (pub or "").strip().lower()
    return PUBLISHED_PUBLIC.get(pub, "not a repository key")
def repeated_byte(hexstr):
    s = (hexstr or "").strip().lower()
    if len(s) not in (64, 128):
        return "unexpected length %d" % len(s)
    return "yes (%s repeated)" % s[:2] if s == s[:2] * (len(s) // 2) else "no"
def load(name):
    try:
        return json.loads(sys.stdin.read() if name == "-" else open(name).read())
    except Exception as e:
        print("  unreadable: %s" % e.__class__.__name__)
        return None
which = sys.argv[1]
doc = load("-")
if doc is None:
    sys.exit(0)
if which in ("ags", "egs"):
    s = doc.get("signer") or {}
    print("  signer.key_id = %r" % s.get("key_id"))
    print("  signer.public_key_hex = %s -> %s" % (s.get("public_key_hex"), verdict(s.get("public_key_hex"))))
    print("  signer.private_key_hex is one byte repeated: %s" % repeated_byte(s.get("private_key_hex")))
    if which == "egs":
        print("  top-level keys = %r" % sorted(doc))
        for group in ("runtime_trust", "trust_model"):
            if group in doc:
                sp = (doc.get(group) or {}).get("signer_policy") or {}
                print("  %s.signer_policy.allowed_signers = %r" % (group, sp.get("allowed_signers")))
                print("  %s.signer_policy.revoked_signers = %r" % (group, sp.get("revoked_signers")))
elif which == "es":
    v = doc.get("verification") or {}
    for part in ("trust_model", "provenance", "derivation_attestation", "workload_identity_binding"):
        e = v.get(part) or {}
        print("  verification.%s: key_id=%r public_key_hex=%s -> %s" % (part, e.get("key_id"), e.get("public_key_hex"), verdict(e.get("public_key_hex"))))
    print("  admission_policy present: %s" % ("admission_policy" in doc))
elif which == "ars":
    st = doc.get("storage") or {}
    print("  storage.index_file = %r" % st.get("index_file"))
    print(st.get("index_file") or "")
PY

for f in ags egs es; do
  echo "== $f.json"
  $SUDO cat /etc/execution-substrate/$f.json 2>/dev/null | python3 -I "$SCRATCH/keys.py" $f || echo "  (unavailable)"
done

echo "== ARS index (record count only)"
idx="$($SUDO cat /etc/execution-substrate/ars.json 2>/dev/null | python3 -I "$SCRATCH/keys.py" ars | tail -n 1)"
if [ -n "$idx" ]; then
  $SUDO cat "$idx" 2>/dev/null | python3 -I -c 'import json,sys
d=json.load(sys.stdin)
print("  index top-level type:", type(d).__name__, "entries:", len(d))' || echo "  (index unreadable)"
else
  echo "  (no index_file in ars.json)"
fi
echo "done"
