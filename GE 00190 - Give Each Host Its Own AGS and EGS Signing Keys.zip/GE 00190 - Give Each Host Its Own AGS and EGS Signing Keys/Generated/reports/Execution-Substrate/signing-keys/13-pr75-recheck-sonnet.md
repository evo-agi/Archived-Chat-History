# Re-check of ES PR #75 at 6f83520: per-host AGS and EGS signing keys ([model withheld])

**Verdict: BLOCK (Low findings only).** Every fix the two earlier passes asked for is in and works: audit 04 F1, F2, F3 and red-team 06 RT75-1 to RT75-4 are fixed, F4 is fixed, F5 needs nothing. The product code is correct and nothing is widened. Three Low items remain, and the standing rule is that Lows are fixed in the PR: R75-1 (the contract counts the small-order keys as 12, the rule refuses 14), R75-2 (the config-mode test does not pin two clauses of the rule it guards), R75-3 (the new folder-owner check in the key generator has no test). Each has a repair I ran. A short delta check after that is enough.

**The trunk_dev #69 merge is separate from the fixes.** It is a clean git merge of 13 docs and root-package test files. It touches one file the PR also touches (PLANS.md) and changes nothing in the PR's patch except one hunk offset in that file.

**Backlog item "supported-local installs sign with a fixed repo key": closed for every install set up after this change.** What stays open is listed under "The backlog item", the main one being the Remote Alpha box, which keeps the published keys until #76 and a box run.

**Effect status:** read-only. I pushed, posted and merged nothing, and I did not touch the box or any other machine. All work ran in throwaway copies in this container.

| Field | Value |
| --- | --- |
| Model | `[model withheld]`, trial category R-M (security), real run |
| Blind pair | An Opus re-check of the same head exists in this folder (`12-pr75-recheck-opus.md`). I saw its file name in the folder listing and did not open it or its evidence. |
| Subagents | None |

## Repository / audit target

| Item | Value |
| --- | --- |
| Repository, PR | evo-agi/Execution-Substrate #75, branch `claude/project-thread-ljwd16`, open, not draft, `mergeable_state` clean (read through the GitHub tool) |
| Head | `6f835204d560494e3855c93855ec65130618e547`, tree `1a02fd22616f4ec770b1e0f31591394ca14b88e4`, a merge commit (committed 04:15Z) |
| Base | `trunk_dev` `0b9278ca74404b46b5e9f0e1701874b52687f5e8` (PR #69), also the second parent of the head |
| Commits | 5: `efc97e6` the change, `4fb447d` merge of #68, `b9c80e1` fixes, `ab43fd2` README sentence, `6f83520` merge of #69 |
| The PR's change | `git diff 0b9278c 6f83520`: 38 files, +2529 / -47, SHA-256 `f350bf74d01459f8092051629317fa44516b1456cfc690c3871508c323749932` |
| Audit 04 target | `efc97e6`: 26 files, +1402 / -35. The fix commit `b9c80e1` adds 23 files, +1164 / -51, and `ab43fd2` adds +3 / -1 (README) |
| Earlier reports | `04-pr75-audit.md` (F1-F5), `06-pr75-redteam.md` (RT75-1..4), `08-pr75-fixes-report.md` (the writer's claims) |

## Audit posture

Read-only. I worked in my own clones under `/opt/audit75`, ran tests as an unprivileged user `ci` (umask 022, Go 1.26.5, clean environment, `GOPROXY=off`), and used root only for the root-only tests and for the proposed-test checks. Mutants and probes ran in two throwaway trees (`mut`, `mut2`) and a red-team tree (`rt`); I checked each tree is clean again after use. I read the code and the three earlier reports myself.

## Provenance reproduction (Ran)

- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`. I checked it before the opening run and again just now: it matches. I did not edit it.
- Working tree: `HEAD` reset to `0b9278c`, upstream pinned to `origin/trunk_dev`, files of `6f83520` in the tree. Two runs gave byte-identical output, SHA-256 `e104d4b4cf841801f590c5ddfdbf5ccc77738b7c4616da9c72d280d6236712c8`.
- Manifest: 38 files (21 `tracked_modified`, 17 `untracked`), `textual_diff_sha256` `d0026c62...ba46` (full value in the manifest). The 38 paths are the 38 files of `git diff 0b9278c 6f83520`. The two diffs are different artefacts (the recipe's includes untracked files as additions), so their hashes differ by design.
- `.github` workflow files, the build files and `go.mod` are not in the change. The two CI list files are.

## The #69 merge, separated from the fixes (Ran)

- `6f83520` has parents `ab43fd2` (the PR's own tip) and `0b9278c` (trunk_dev with #69). #69 itself (`git diff a5861b7 0b9278c`) is 13 files: six `.docs` files, `AGENTS.md`, `PLANS.md`, `README.md`, and four root-package docs tests. No Go product code and no script.
- The PR's patch before the merge (`git diff a5861b7 ab43fd2`, SHA-256 `017cee44...9e47`) and after it (`git diff 0b9278c 6f83520`) differ only in the `index` line and one hunk header (PLANS.md, line 303 became 301, because #69 moved text out above it). 38 files and +2529 / -47 on both sides. So #69 changed none of the fixes and none of the key surface.
- The root package and `internal/knownkeys` pass at the head (and the whole suite matches the base, below). The PR body's last sentence about the merge is accurate.

## Fix-by-fix result

| ID | Was | Result at 6f83520 | How I checked |
| --- | --- | --- | --- |
| F1 (Low, report) | The report and PR body named the upgrade's `esconfigcheck` as what stops the box. On the box it never runs, so the trigger is the startup refusal. | **Fixed.** The PR body ("What this does not do yet") names the startup refusal, says the upgrade does not reach `esconfigcheck` on the box's shape, and says #76 adds the config checks to the deploy. | Read the PR body; read `scripts/internal/remote_alpha_deploy_es_binaries.sh` at #76's head `e75c804` (it now runs `es/ags/egsconfigcheck` before it installs); ran the built binaries (below). One leftover in a test comment: O75-1. |
| F2 (Low, test gap) | Nothing noticed a generator that wrote the same EGS key every time. | **Fixed.** `TestCommandWritesADifferentKeyOnEveryRun` runs the built command for roles ags, egs, ags, egs; `TestGenerateWritesAFreshKeyOnlyItsOwnerCanRead` and others. | Mutants G07 (fixed EGS key) and G08 (fixed AGS key) killed; G03, G04, G05, G06 killed. |
| F3 (Low, test gap) | The renderer's key-file and config-write defences had no tests. | **Fixed.** `TestSupportedLocalRendererKeepsTheSigningKeysPrivate` (subtests: reachable by others, link, not a file, other format, config already there) and the root-only `TestSupportedLocalRendererRefusesASigningKeyFileAnotherUserOwns`. | R01, R03, R04, R05, R06, R08, R10, R12, R13, R14, R01b, R01c killed. R02 (owner check) survives as `ci` by design and is killed as root (R02-root). CI's root step ran that test: `tests as root passed: 10 of execution-substrate/scripts`, which includes it (log line 05:01:42Z). |
| F4 (observation, doc) | contracts.md said every signing key value in the repository is a known key; the scan checks only labelled fields. | **Fixed.** The sentence is now scoped to values given to a signer or verification key field (contracts.md 3B). | Read it against `TestRepositoryShipsNoSigningKeyAServiceAccepts`. |
| F5 (observation) | Equivalent encodings of a known key (the negated point) are not refused. | **No action, unchanged.** Still true and still out of the stated scope. | Reading. |
| RT75-1 (Medium) | ES, AGS and EGS accepted 14 public keys that anyone can sign for, 32 zero bytes among them. | **Fixed.** `knownkeys.Check` refuses all 14; it runs in `ags/config`, `egs/config` and `es/config` for the signer and all four `verification` entries; `esconfigcheck` shares it through `es/config.Load`. `smallorder_test.go` derives the points from the curve and requires the forgeable set to equal the list. | All 14 list entries removed one at a time (SO-00 ... SO-8bs), a flipped byte (SO-flip), and the check itself (SO-check): all killed. Each of the four `verification` entries and `esconfigcheck` skipped one at a time (S01, S02-x4, S03): killed. Red-team probes re-run on the head: 17 report "WEAKNESS CLOSED", none reports a weakness present, and its 181,760-case sweep accepted 0 known keys. Startup probe of built binaries (below): zeros refused by ES and by `esconfigcheck`. |
| RT75-2 (Low) | A 64-byte private key whose second half was not its seed's public key was accepted. | **Fixed.** `ags/sign` and `egs/sign` derive the key from the seed and refuse a mismatch (`bytes.Equal` of the whole key). | SG1-SG4 for ags and egs killed (8 of 8); `CheckPrivate` checks both halves (K03, K04, K05 killed). |
| RT75-3 (Low, test gap) | No test noticed every install getting one key again. | **Fixed.** Same tests as F2, plus the render test asserting the generated seeds, and `testutil.WithFreshSigningKeys` (T01 killed). | G07, G08 killed; the red-team's own mutants A (setup writes fixed keys) and B (fixed random source) re-applied to the head: both fail the PR's tests (`probes/rtout/3-mutant-A.txt`, `-B.txt`); C, D, E (checks skipped or one half checked) fail too. |
| RT75-4 (Low) | AGS and EGS loaded a config holding the private key with any mode. | **Fixed in the code, two clauses untested (R75-2).** Both `Load` functions `Stat` the opened file and refuse `!IsRegular() \|\| Perm()&0o007 != 0`. 0600 and 0640 load; 0644, 0604, 0602, 0601, 0666, 0646, 0777 and a folder do not. Documented in configuration.md, the examples README and the runbook. | CM1-CM4 and CM6 killed for both services. CM5 and CM8 survive: R75-2. |

## What the built binaries do (Ran)

Built `ags`, `egs`, `es`, `esconfigcheck` and `signingkeygen` from the head as `ci` and ran them on copies of the example configs (output: `probes/startup-probe.out`; `exit=` lines after a pipe show the pipe's status):

- AGS and EGS with the published keys, mode 0600: refused at config load with "is a known key: its private seed is the byte 0x11 (0x33) repeated".
- AGS with the same file at 0644: refused for the mode, before the key.
- ES and `esconfigcheck` on the example `es.json`: refused ("verification.trust_model.public_key_hex is a known key ... 0x33"). With 64 zeros in the four `verification` keys: refused as "a key anyone can sign for".
- With keys from `signingkeygen`: `esconfigcheck` says "es config accepted"; AGS and EGS get past the key and mode checks (mode 0600 and 0640) and stop later on the example's missing TLS files, as expected; mode 0666 is refused.

This is the startup refusal the PR names as the box's migration trigger: it works on the built binaries.

## The backlog item: "Supported-local installs sign published code with a fixed key committed in the repo"

**Closed for new installs.** `scripts/72_supported_local_setup.sh` now makes a key pair per proof root with `signingkeygen` (crypto/rand, new 0600 file, role-and-hash key ID), reads each back without following a link, refuses a file others can reach, another owner, or another format, writes the configs new at 0600, points the EGS allow list and the four ES `verification` entries at the new public keys, and deletes the key files. The script holds no key value any more. The example configs keep the published keys on purpose and every service refuses them with a clear message. A repository scan and the render test show no accepted key left.

What stays open, so nobody reads "closed" as more than it is:

1. **The Remote Alpha box** is not a supported-local install. It stays on the published keys until #76 is merged and a box run rotates them; until binaries from this change run there, nothing changes, and once they do, AGS, EGS and ES refuse to start. That is the intended stop.
2. **Existing supported-local proof roots** rendered before this change hold the published keys in their configs. Their services will refuse to start on new binaries. The recovery is a new proof root (setup refuses a config that is already there, and re-signing old records is rightly not offered).
3. **Keys sit inline in `ags.json` and `egs.json`**, guarded by owner and mode. contracts.md records key custody as a reopened seam. A key file or key service is not designed.
4. Inference: in supported-local the same operator account runs ARS, AGS and EGS, so anyone who can act as that account can read `ags.json` and sign. The change moves the boundary from "anyone who has the repository" to "anyone who can read the operator's config", which is what the backlog item asked for, but it is not a boundary against the operator account itself.

## Findings

No Critical, High or Medium finding.

### R75-1: contracts.md counts the small-order keys as 12; the rule refuses 14

- Type / Severity: contract wording wrong in one number / **Low**
- Evidence: contracts.md 3B (head `:299-304`) says the 14 values are "the eight such points, the two whose x is 0 also written with the sign bit set, and the two written with y = p and y = p + 1". That adds to 12. The list in `internal/knownkeys/knownkeys.go` has 14, and each of the four `y = p` and `y = p + 1` encodings, with either sign bit, matters: mutants SO-p, SO-ps, SO-p1 and SO-p1s each fail the derivation test (so 8 + 2 + 4 = 14). The code comment (`knownkeys.go:45-54`) and configuration.md:277 do not enumerate and are not wrong.
- Impact: none on behaviour. A reader who rebuilds the list from the contract gets 12, with two of the four non-canonical spellings missing, and a forged signature verifies under those two as well (each removal fails the derivation test).
- Required correction: say "and the four written with y = p or y = p + 1, each with either sign bit".
- Patch defect or pre-existing: patch defect (added by the RT75-1 fix).

### R75-2: the config-mode test does not pin "regular file" or "judged by the file"

- Type / Severity: test gap / **Low**
- Evidence (Ran): mutants CM5 (`if info.Mode().Perm()&0o007 != 0 {`, the regular-file clause dropped) and CM8 (`os.Lstat(path)` in place of `file.Stat()`) survive in both `ags/config` and `egs/config`, four survivors. Why: `TestAGSAndEGSRefuseASignerConfigOtherUsersCanReadOrWrite` makes its "folder" with `t.TempDir()`, mode 0755 under the usual umask, so the other-users clause refuses it with the same message prefix; and its link case points at a 0644 file, so refusal by the link or by the file looks the same. Under CM5 a folder with mode 0700 loads past the check and fails later with a decode error; under CM8 a link to a private config is refused. Neither mutant weakens security, but the rule the test claims to guard ("regular file", and contracts.md 3B's "the check is on the opened file") is half pinned. This is the same class as audit 04 F3.
- Repair (Ran, `proposed-tests/r75_config_regular_file_test.go`): `TestAGSAndEGSConfigIsJudgedAsAnOpenedRegularFile` loads a 0700 folder (must say "must be a regular file") and a link to a 0600 config (must load), for ags and egs. It passes on the head and kills CM5 and CM8 for both services (4 of 4). CM7 (`os.Stat(path)` before the open, a race only) stays unpinned: O75-3.
- Patch defect or pre-existing: patch defect.

### R75-3: `checkFolder`'s "another user owns the folder" branch has no test

- Type / Severity: test gap / **Low**
- Evidence (Ran): `checkFolder` in `scripts/internal/signingkeygen/main.go` is new in the fix commit. Mutant GF2 (`if false && int(st.Uid) != os.Geteuid() && st.Uid != 0`) survives all tests: the generator would write a key into a folder another account owns, and that account could replace the file. The group-or-other-write branch is tested (GF4, GF5, GF6 killed) and so is the generator calling `checkFolder` at all (GF1 killed). GF3 (drop the "root-owned is fine" allowance) survives for the same reason.
- Repair, either of:
  - **(b) Preferred, no CI change (Ran, `proposed-tests/checkFolder-euid-parameter.diff` and `r75_folder_owner_unit_test.go`):** give `checkFolder` the effective user ID as a parameter (`checkFolder(dir, os.Geteuid())` at the one call site). The test asks about a folder it owns with its own ID (accepted), with another ID (refused, "belongs to another user"), and about `/`, which root owns and nobody else can write (accepted). It runs as any non-root user, skips itself as root (root owns every folder it makes, so the rule cannot be shown), and kills GF2, GF3 and an inverted owner test (3 of 3). `gofmt` and `go vet` clean.
  - **(a)** a root-only test that chowns a folder to uid 65534 (`proposed-tests/r75_folder_owner_test.go`; passes as root and kills GF2, but not GF3). CI's root step runs one package only, `execution-substrate/scripts` (`go_test_as_root.py LIST PACKAGE`), so a test in `signingkeygen` would also need `skips-itself` lines in both CI lists and a second invocation of that step in `go.yml`, and go.yml's comment calls that step the only use of root. I do not recommend it.
- Patch defect or pre-existing: patch defect (the branch came in with the fix).

## Observations (no action required, not blocking)

- **O75-1.** The comment at `scripts/remote_alpha_upgrade_es_config_check_test.go:180-181` ("A box still on the repository's published keys is refused here, so the upgrade stops before apply until its keys are rotated") is true only for hosts the upgrade checks (shape locked-http). The Remote Alpha box is shape https and never reaches `esconfigcheck`; its stop is the startup refusal. This is the audit-04 F1 point again, in a comment. One line, best fixed in the same push as R75-1 to R75-3: say "an upgrade of a host in this shape stops".
- **O75-2.** The mode rule is `Perm()&0o007`, so group bits are never judged: a config with group-write (0660, 0620) loads. The wording ("other users cannot read or write") and the documented modes (0600, and 0640 for the service's group) agree with that, but a member of the service group could replace a 0660 config. If that matters, `&0o027` would refuse group-write and keep 0640 (the tests already require 0640 to load, which is why CM4, the `&0o077` reading, is killed); no test pins group-write either way. Inference, not run: ACLs are not examined. With a POSIX ACL the group bits show the ACL mask, and this check ignores group bits, so a named-user entry would not be seen. Mode 0600 with no ACL, what setup writes, is robust.
- **O75-3.** Unpinned survivors that are equivalent or only stricter: CM7 (the config is statted by path before the open, a race on a path that only its owner should control), GF7 (`!info.IsDir() || !ok` reduced to `!ok`: a parent that is a file fails at the create with ENOTDIR), GF8 (`Lstat` on the folder refuses a symlinked folder, stricter), G01 (`Chmod(0600)` after create is redundant under every umask, which can only clear bits; it fixes the mode only where umask removed owner bits). The preferred R75-3 repair also kills GF3.
- **O75-4.** The red-team 06 regression files could not be copied into the PR's packages: they declare the same test names and `TestMain` the PR now carries (the writer adopted them), so the build failed. I did not re-run them; the PR's copies run in the full suite and pass, and the red-team probes (the `zz_` files) ran and show every weakness closed.

## Validation

**Whole suite, head against base (Ran, as `ci`, `go test -json ./...`; head took 9 minutes, base 8).**

| | Packages | Failing top-level tests | Failing test names, subtests included | Passing test events, subtests included |
| --- | --- | --- | --- | --- |
| Base `0b9278c` | 50 | 35 | 262 | 9,967 |
| Head `6f83520` | 52 | 35 | 262 | 10,097 |

The failing names are identical, one by one (the diff of the two sorted lists is empty): `es/app` 16, `es/admission/internal/reliablesubmit` 3, `scripts` 243, the same three packages on both sides. They fail the same way on the base, so the PR did not cause them. I did not diagnose each one; the PR body and audit 04 attribute them to this kind of container (proxy, no Nomad leader, no kernel firewall). The head adds two packages, `internal/knownkeys` and `scripts/internal/signingkeygen`, both passing, and gives `ags/sign` and `egs/sign` their first tests. It has 130 more passing test events and one more skip (the root-only owner test, skipped as `ci`). The PR's new case "published signing keys" lives in `TestESConfigCheckAgreesWithConfigLoad`, which passes. `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor` fails on both sides and is on the macOS environment-only list.

**Static checks (Ran).** `gofmt -l` on the PR's Go files: empty. `go vet` on the changed packages and `./scripts`: clean. `GOOS=darwin go vet` for `internal/knownkeys`, `scripts/internal/signingkeygen`, `ags/...`, `egs/...`: clean. `bash -n` on the setup script: ok.

**CI on the exact head (GitHub, run 374, attempt 1, head `6f83520`).** "build, vet and test" succeeded (04:15:41Z to 05:01:45Z) and "test on macOS" succeeded (04:26:17Z to 04:55:37Z). In the Linux log tail: `tests as root passed: 10 of execution-substrate/scripts`, with `TestSupportedLocalRendererRefusesASigningKeyFileAnotherUserOwns` passing. I could not read the Test step's per-package output (the log tool returns the last 64 KB only); I rely on the job conclusion for that step.

**Mutants.** 84 distinct mutants of the PR's own code (85 runs, R02 run twice, as `ci` and as root): 73 killed, 11 survive. By area:

| Area | Killed |
| --- | --- |
| Known-key rule (K01-K05) | 5 of 5 |
| Call sites and verification fields (A01, A02, E01, E02, S01, S02 x4, S03) | 10 of 10 |
| Small-order list and check (SO-check, 14 entries, SO-flip) | 16 of 16 |
| `ags/sign` and `egs/sign` (SG1-SG4 each) | 8 of 8 |
| Config mode (CM1-CM8 for each service) | 10 of 16 (CM5, CM7, CM8 survive for both) |
| Generator key writing (G01, G03-G08) | 6 of 7 (G01 survives) |
| Generator folder check (GF1-GF8) | 4 of 8 (GF2, GF3, GF7, GF8 survive) |
| Renderer (R01-R14 and variants; R02 counted as killed in the root run) | 13 of 13 |
| Test helper (T01) | 1 of 1 |

The 11 survivors are the four of R75-2 (CM5, CM8 x2), GF2 of R75-3, and six equivalent or stricter changes under O75-3 (CM7 x2, GF3, GF7, GF8, G01). The proposed tests kill CM5 and CM8 for both services, and GF2 and GF3. Table: `mutants/mutant-table.tsv`.

**Red-team 06 probes on the head (Ran).** Every probe reports its weakness closed; `probes/rtout/`.

## Coverage this pass did not give

- No box, no Linux host beyond this container, no macOS run of mine (CI's macOS job passed). No real full setup (`72_supported_local_setup.sh` end to end) ran here; CI's renderer tests and the `es/admission` render test cover it, and the PR says so.
- I did not read the macOS or Linux Test step output, only the job conclusions and the root-step lines.
- The writer's own manifest for 6f83520 does not exist in the folder (the manifests there are for earlier heads), so the provenance above is mine, not a comparison.
- The red-team regression files were not re-run in tree (O75-4).
- ACLs, SELinux and filesystem types were not exercised (O75-2).

## Sensitive-material handling

The repository's published seeds (0x11 and 0x33 repeated) are public and appear only as the rule's subject. The probes made fresh keys in throwaway folders under `/home/ci/tmp` and deleted them; none was printed or kept. The evidence holds only public values: small-order encodings and public keys. I scanned the evidence for repeated-byte seeds and 64-hex private-key assignments and found none.

## Uncertainty and confidence

- The three findings are reproduced with mutants and repairs I ran. High.
- "Closed for new installs" rests on the renderer and the generator tests plus reading; the real full setup was not run here. Medium-high.
- The backlog item's same-account point (4) is inference from the supported-local layout.
- Confidence that no further Critical, High or Medium issue is in the key surface: medium-high. I read every changed product file and ran the earlier red-team's probes, but I did not red-team anew.

## Effect status

Read-only. Nothing pushed, posted, merged or deployed; the box and the user's Mac untouched. The trees under `/opt/audit75` stay in this container.

## Delivery

Evidence (no secrets): `13-pr75-recheck-sonnet-evidence/` in this folder. See its README for what each file is.

**Trial row for the coordinator:**

`| 2026-11-27 | R-M (security) | ES #75 @ 6f83520 | narrow re-check (real) | [model withheld] | BLOCK | R75-1 Low (contracts.md counts 12 small-order keys, rule has 14), R75-2 Low (config regular-file and link semantics untested: CM5, CM8), R75-3 Low (checkFolder owner branch untested: GF2); F1-F3 and RT75-1..4 verified fixed | paired Opus run not read; report signing-keys/13-pr75-recheck-sonnet.md |`

**Final verdict: BLOCK** (R75-1, R75-2, R75-3 Low; O75-1..4 observations; no Critical, High or Medium).
