# ES PR #76: fixes for audit 05 and red-team 07, and the deployment's config checks

STATUS: READY for a fresh audit and red-team of the new head (the script was rewritten), then the gate.

- Repository: evo-agi/Execution-Substrate, branch `claude/signing-key-rotation`, stacked on #75 (`claude/project-thread-ljwd16`).
- Audited / red-teamed head: `c73b499`.
- New head: `e75c804` = fix commit `c2e386f` (on `5069f85`, the merge of #75's fixes) + merge of #75's head `6f83520` (`5b79beb`; trunk_dev #69, docs only; no conflict) + `e75c804` (two tests made to pass on macOS, see "CI").
- Review delta: `git diff 6f83520 5b79beb` (the rotation and the deployment change against #75's head), or `git diff c73b499 c2e386f` minus #75's fixes.
- Coordinator decisions applied: RT76-1 repair 1 (the rotation retires ARS's index in the same transaction; blobs stay; the ARS contract is unchanged); RT76-2..10 and all audit findings fixed; the ES binary deployment checks all three configs before installing.

## What changed, in one paragraph

`scripts/internal/remote_alpha_rotate_signing_keys.py` is rewritten. It now stops ES, AGS and ARS, moves ARS's index into the backup and leaves an empty one, then starts ARS (and waits), restarts EGS (and waits), starts AGS and ES, and waits for all four. It reads configs strictly, checks the config folder chain, `healthcheck.env`, the units' `ExecStart`, and the index's owner and folder, refuses to run from a clone another account could change, detects unfinished rotations, turns the four interrupting signals into a rollback, rechecks each config before writing it, and reports `rolled_back`, `rolled_back_unhealthy` or `rollback_failed` precisely. The ES binary deployment (`scripts/internal/remote_alpha_deploy_es_binaries.sh`) now builds, stages and runs `esconfigcheck`, `agsconfigcheck` and `egsconfigcheck` on the three configs before installing anything.

## Finding to fix map

### Red-team 07

| Finding | Fix | Test (mutant killed) |
|---|---|---|
| RT76-1 (Medium): an old artifact cannot be published again after the rotation | Repair 1: index moved into the backup (`ars-index.json` + manifest) and replaced with `{}` while ARS is stopped, keeping owner and mode; ARS restarted first; rollback restores the index. Blobs and the ARS contract unchanged. | `ags/app/signing_key_rotation_e2e_test.go` (the red-team's subtest turned around): republish of X gives 200 and prepare gives 200; old-key records 403; new artifact works; ES refuses an EGS on its old key; rollback restores index bytes and the old key, X prepares 200. Script tests check the retired index and its backup (M15, M22). |
| RT76-2: a differently spelled key group survives | Strict JSON reader: refuses non-ASCII keys, case-only variants, duplicates, NaN/Infinity, non-UTF-8, deep nesting. | `TestSigningKeyRotationRefuses` cases (M17). |
| RT76-3: an unknown `verification` entry keeps the old key | ES `verification` must have exactly its four entries. | `TestSigningKeyRotationRefuses`. |
| RT76-4: `rollback` accepts a stale backup | Rollback only while every config is the one the backup's rotation wrote or replaced. | `TestSigningKeyRotationRollbackRefusesABackupThatIsNotTheLatest` (M18). |
| RT76-5: SIGKILL and SIGQUIT do not roll back | SIGQUIT joins SIGTERM/SIGHUP/SIGINT (recorded, rollback at the next step). SIGKILL: unfinished-rotation detection in `check`/`apply`, `rollback` settles it; docs give `systemd-run -p KillMode=mixed -p TimeoutStopSec=300`. | `TestSigningKeyRotationSignalsRollBack` (M1, M9), `TestSigningKeyRotationAfterAKill` (M19, M27). |
| RT76-6: an error while the rollback waits loses the report | Wait errors recorded in the report. | `TestSigningKeyRotationRollbackWaitErrorKeepsTheReport` (M8). |
| RT76-7: the index count can stop the rotation | Count is advisory. | `TestSigningKeyRotationIndexCountIsAdvisory`. |
| RT76-8: config folder and `healthcheck.env` not checked | Folder chain `/` to `/etc/execution-substrate` root's, not group/other writable, no links; `healthcheck.env` root's, one link, not group/other writable. | `TestSigningKeyRotationRefuses` (M20, M21). |
| RT76-9: nothing proves the services run on the files written | Each unit must have exactly one `ExecStart` with the expected binary and `-config` path. | `TestSigningKeyRotationCheckChangesNothing` / `Refuses` (M16). |
| RT76-10: 10 of 14 mutants survive | 28 mutants, all killed (below). | See "Mutants". |

### Audit 05

| Finding | Fix | Test (mutant killed) |
|---|---|---|
| A76-1 (Medium): root runs code from a clone others can change | Each command first refuses a clone another account could change (as the ES upgrade does). | `TestSigningKeyRotationRefusesACheckoutOthersCanChange` (M25). |
| A76-2: SIGTERM between close and rename | Signals recorded and acted on at step boundaries; temp files created exclusively without following links; leftovers detected and removed by rollback. | `SignalsRollBack`, `AfterAKill`, `TempFileRefusesAPlantedLink` (M1, M5, M9, M27). |
| A76-3: a failed summary write hides the result | Report printed before `summary.json`; failure said on its own line; `check` names the backup unfinished until the report is saved. | `TestSigningKeyRotationReportsWhenItsSummaryCannotBeWritten`. |
| A76-4: rollback stops at the first failure | Rollback tries every step; result says what state the host is in. | `TestSigningKeyRotationRollbackTriesEveryStep`, `RollbackNamesAFailedStepEvenWhenTheServicesAnswer` (M28). |
| A76-5: nothing waits for EGS before ES | Wait for ARS and EGS to accept connections before starting AGS and ES. | `TestSigningKeyRotationWaitsForEGSBeforeES`, `HealthWaitsForSlowServices`. |
| A76-6: 14 of 21 audit mutants survive | Covered by the 28-mutant set. | See "Mutants". |
| A76-7: manifest with wrong types | Manifest fields type-checked; copies checked by digest and size; folder mode and owner checked. | `TestSigningKeyRotationRollbackRefusesABrokenBackup` (M3, M4). |
| A76-8: check-then-act on the configs | Each config rechecked against what `check` read at the end of the backup and again before it is written. | `TestSigningKeyRotationRechecksEachConfigBeforeWritingIt` (new; M24). |
| A76-9: `--host-root //`, `/.`, `/etc/..` enter test mode on the real host | A host root whose real path is `/` is the host. | `TestSigningKeyRotationOnTheRealHostNeedsRoot` (M10). |
| A76-10: timeout kills only the child | Children run in their own session; a timeout kills the whole group. | Read (no mutant). |
| A76-11: rollback ignores later ES-upgrade changes; docs silent on ES-upgrade backups | Stale-backup check (as RT76-4); docs list the other config copies that hold keys and say none is a rollback target after the rotation. | `RollbackRefusesABackupThatIsNotTheLatest` (M18). |
| O1: docs lack the `KillMode` line | Added. | Doc. |
| O3: grants test uses minimal rules, no real loader | The base has no grants loader, so the port waits for #73. Tripwire: `TestSigningKeyRotationUpdatesWorkloadGrants` fails as soon as `es/config/workload_grants.go` (#73's loader) is in the tree, until the test uses rules of that shape and `esconfig.Load`. | Machine-enforced: the test itself. |

### Coordinator addition: the ES binary deployment checks all three configs

The older ES binary deployment restarted ES without a config check. It now builds `esconfigcheck`, `agsconfigcheck` and `egsconfigcheck` from the payload's tree, stages and uploads them, and runs them in check-only and apply before anything is installed. A refused config is the blocker `es_config_check`, `ags_config_check` or `egs_config_check`; apply then installs and restarts nothing. Tests: `TestAGSAndEGSConfigChecksOnlyCallConfigLoad` (AST: thin wrappers), `TestAGSAndEGSConfigChecksAgreeWithConfigLoad` (same answer and reason as `config.Load` on 7 cases each), `TestRemoteAlphaESBinaryDeploymentStopsOnAConfigTheNewBinariesRefuse`, and updated staging tests. `service_layout_test.go` lists the two new cross-service imports.

## Mutants

28 one-change mutants of the rotation script, run with the rotation tests as a normal user (`ubuntu`), each applied alone, script restored byte-identical after each run (checked with `cmp`):

| Mutant | Killed by |
|---|---|
| M1 no signal handlers | SignalsRollBack |
| M2 backup root any owner, no chmod | ApplyRotatesAllThreeConfigs |
| M3 restore skips copy digest | RollbackRefusesABrokenBackup |
| M4 restore skips folder mode/owner | RollbackRefusesABrokenBackup |
| M5 temp file without O_EXCL/O_NOFOLLOW | TempFileRefusesAPlantedLink |
| M6 children inherit the environment | ApplyRotatesAllThreeConfigs |
| M7 no private DER shape check | Refuses |
| M8 rollback does not wait | RollbackWaitErrorKeepsTheReport |
| M9 check_stop never stops | SignalsRollBack |
| M10 no root requirement | OnTheRealHostNeedsRoot |
| M11 config owner not checked | Refuses |
| M12 backup copies 0644 | ApplyRotatesAllThreeConfigs |
| M13 records 0644 | ApplyRotatesAllThreeConfigs |
| M14 grants not required to name AGS | UpdatesWorkloadGrants |
| M15 index not retired | ApplyRotatesAllThreeConfigs |
| M16 ExecStart not checked | CheckChangesNothing |
| M17 case-variant keys accepted | Refuses |
| M18 rollback stale check skipped | RollbackRefusesABackupThatIsNotTheLatest |
| M19 unfinished rotation not reported | Refuses |
| M20 config folder chain not checked | Refuses |
| M21 healthcheck.env not checked | Refuses |
| M22 rollback does not restore the index | RollsBack |
| M23 ARS stop not required | RollsBack ("ARS still runs after a stop that succeeded", new) |
| M24 config not rechecked before write | RechecksEachConfigBeforeWritingIt (new) |
| M25 checkout guard skipped | RefusesACheckoutOthersCanChange |
| M26 public DER shape not checked | Refuses ("openssl gives something other than an Ed25519 public key", new) |
| M27 leftovers not found | Refuses |
| M28 a failed service step still `rolled_back` | RollbackNamesAFailedStepEvenWhenTheServicesAnswer (new) |

Run history: M2 and M5 survived run 1 and were killed in run 2 after tests were added; M23, M24, M26 and M28 survived run 2 and are killed in run 3 by the four new tests. A final run of all 28 against the final tests and script (11-27 04:37-04:50Z, as `ubuntu`, `-test.failfast`, so each line names the first test that failed) killed all 28; the script was restored byte for byte (`09-pr76-evidence/mutants-final.txt`). The table names a test that kills each mutant; in a failfast run the first failing test can differ (M8 fell first to `RollbackNamesAFailedStepEvenWhenTheServicesAnswer` in the final run). The runner (`09-pr76-evidence/mutants.py`) lists each snippet; `mutant-runs.txt` holds runs 1 to 3.

New test hooks (test host root only): `SIGNING_KEY_ROTATION_TEST_PAUSE_AT` / `_PAUSE_MARKER` (wait at a named point while a marker file exists), fake `systemctl` marker `stop-leaves-running-<unit>-once`, fake `openssl` marker `openssl-bad-pub-der`.

## Validation

In a Linux cloud container, as root unless noted:

- `gofmt -l` and `go vet ./scripts`: clean.
- `go test -count=1 ./...` on the fix tree (`c2e386f` before two test-only edits named below): every package passes except the 55 tests that fail the same way on `trunk_dev` in this container (`es/app` 14, `scripts` 38, `es/admission/internal/reliablesubmit` 3; lists in `09-pr76-evidence/`), plus one new failure, `internal/testutil` `TestImportersNameRepositoryPathsFromTheRoot`, which flagged two `exec.Command` calls in the rotation test without a working directory. Both now set `Dir`; the guard passes. The O3 tripwire was added in the same edit (it does not fire on this tree).
- Rotation, deployment, staging and config-check tests (`TestSigningKeyRotation|TestRemoteAlphaESBinaryDeployment|TestAGSAndEGSConfigChecks|TestESConfigCheck|TestRemoteAlphaStageESBinaries`): pass as root, and as `ubuntu` with umask 022. As `ubuntu` the container needs a readable copy of the Go toolchain and module cache and `GOFLAGS=-buildvcs=false` (the clone is root's). Under umask 002 the existing deployment tests refuse their group-writable output folders (the shared output-folder check, unchanged here); CI runs with umask 022.
- `TestSigningKeyRotationKeepsOwnersAndGroupsAsRoot` passes under `env -i PATH=/usr/bin:/bin` as root, as the CI root step runs it.
- `ags/app` (with the end-to-end test) passes.
- After merging #75's head (`5b79beb`): the root package, `internal/knownkeys` and `internal/testutil` pass; the `scripts` package fails exactly the 38 `trunk_dev` container tests (`09-pr76-evidence/scripts-5b79beb-failures.txt`).
- Secrets: no key value in the diff other than the published example seeds (0x11, 0x33); no box IP or local path.

CI on the PR is the reference for the container failures and for macOS.

## CI

- `5b79beb`: Linux "build, vet and test" passed. macOS "test on macOS" failed on two new tests, both from Linux-only path assumptions in the tests, not in the script:
  - `TestSigningKeyRotationOnTheRealHostNeedsRoot` used `/etc/..` as a path naming the real root; on macOS `/etc` links to `/private/etc`, so `/etc/..` is `/private` and the script rightly treated it as a test root. The test now uses each dotted path (`/etc/..`, `/usr/..`) only where it resolves to `/`, and fails if none does.
  - `TestRemoteAlphaESBinaryDeploymentStopsOnAConfigTheNewBinariesRefuse` ran check-only with the default summary path under `/var/tmp`, which macOS reaches through a link that the shared output-folder check refuses (the reason `TestRemoteAlphaESBinaryDeploymentCheckOnlyIsDefaultAndNonMutating` is on the macOS list). Both modes now get a summary path in the test's folder.
  - Fixed in `e75c804`; both pass locally (the first as `ubuntu`, since it skips as root). Neither change weakens what the test checks on Linux.
- `e75c804`: Linux "build, vet and test" and macOS "test on macOS" both passed (completed 06:25Z).
- #75 `6f83520`: Linux and macOS passed.

## Not done here

- No box run. The rotation runs on the box on a coordinator-assigned box turn after audit, red-team and the gate, then a smoke test (fresh publish, prepare, submit) and deletion of the backup.
- The #73 port (O3 and the items in the port notes) waits for #73 to merge.
