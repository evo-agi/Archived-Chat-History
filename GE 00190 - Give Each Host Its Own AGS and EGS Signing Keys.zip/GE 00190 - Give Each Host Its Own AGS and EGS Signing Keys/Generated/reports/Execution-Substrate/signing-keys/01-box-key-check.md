# Remote Alpha box signing keys: read-only check, 2026-11-27 01:23Z

Thread "Give each host its own signing key" (ES). Run through Remote Control on
David's Mac (on [home network address withheld]), `ssh [test box name withheld] 'bash -s' < 01-box-key-check.sh`.
Script sha256 `7522b8fe…2b39` (checked on the Mac before the run), exit 0.
Output 2070 bytes, sha256 `f19ddbf3…afbb7` as the Mac reported it; the copy
in `01-box-key-check-out.txt` has the same size and sha256. Nothing on the box
changed; the script's own /tmp scratch folder and the Mac's temp folder were
removed.

## Result (Ran)

- The box is affected. AGS signs with seed 0x11 repeated (key_id `ags-key-1`,
  public `d04ab232…8737`) and EGS with seed 0x33 repeated (`egs-key-1`,
  `17cb79fb…80ce`): the keys in `.examples/config` and in
  `scripts/72_supported_local_setup.sh`. All four ES `verification` entries
  trust exactly those two public keys.
- EGS: `runtime_trust.signer_policy.allowed_signers = ["ags-key-1"]`, none
  revoked; top-level groups are the current shape (`runtime_trust`,
  `publication`).
- Files: `ags.json` root:ags 0640, `egs.json` root:egs 0640, `es.json` root:es
  0640, `ars.json` root:ars 0640. `es.json` has no `admission_policy` yet.
- ARS index: a JSON object with 164 entries. Their AGS signatures prove nothing
  about who published them, since anyone could have made them.

## Meaning (Inference)

Anyone who can reach the box's ARS write path, or who can get a record into
its storage, can seal evidence for any publisher principal and ES admits it;
anyone who can answer as EGS can sign a trust policy allowing any signer. The
box needs new AGS and EGS keys (rotation), and the 164 records signed with the
old AGS key must be re-published under the new key or dropped, because ES must
stop trusting the old key.

Note from the run: the script's "one byte repeated" line prints the repeated
byte. For a repeated-byte key that byte is the whole key; here those are the
published seeds, so nothing secret came out. For any other key it prints only
"no".
