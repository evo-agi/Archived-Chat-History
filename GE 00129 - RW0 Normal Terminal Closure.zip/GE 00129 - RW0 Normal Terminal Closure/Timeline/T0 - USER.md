Chat 00105 unfortunately got way too long. We will resume the work here.

Please review the zip I've attached. It contains the chat history for the latest tranche we were working on in Chat 00105.

- README.md describes how to make use of the zip.
