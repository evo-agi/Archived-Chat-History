Chat GE 00105 needed a "nudge" from me to continue after T66 of chat `GE 00105 - RW0-C2 Physical Admission and Progression`, hence `Timeline/T0 - USER.md`. That's not a first, and it's rather annoying.

I hate `Timeline/T7 - CODEX PROMPT FROM CHATGPT.md` so much.

Wow. `Timeline/T15 - CODEX PROMPT FROM CHATGPT.md`. Why tf would we need to attach prompts? I hate this so much, man...

`Timeline/T28 - USER.md`... :/

Woah. `Timeline/T100 - USER.md` already?

Somewhere around `Timeline/T119 - CODEX PROMPT FROM CHATGPT.md`, the split between (regular) Codex project and "neutral" Codex project, for Coordinator, is becoming ambiguous in the ChatGPT instruction.

`Timeline/T131 - CHATGPT.md`... WTF.

`GE 00105 - RW0 Normal Terminal Closure/Timeline/T137 - CHATGPT.md` requested a snapshot!? Woah. Last tranche did not even request one. What fixed it, I wonder?
