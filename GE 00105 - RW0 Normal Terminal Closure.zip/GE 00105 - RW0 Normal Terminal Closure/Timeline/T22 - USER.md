Here is Codex's response:

# RW0 normal-terminal cumulative audit

**Verdict:** `RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE`

The sealed candidate was authenticated as the 327-path tree `4691af58ae0ee3107b4e2e9b6b1508032944e357`. This audit establishes its artifact identity and reconciles the retained records. It does **not** accept the candidate or establish a new candidate defect.

## Process and execution boundary

My first tool call ran `git status --short --branch` in the excluded live Coordinator checkout while I was still reading the mandate. It returned a branch name and modified/untracked path list. The same call listed metadata for the three exact named inputs, including two in Downloads. I excluded those observations from candidate evidence. I make no claim that live state was preserved or mutated during that interval. The mandate says an out-of-scope action bars compliant acceptance.

I subsequently used only the named inputs and an owned neutral audit directory. No subagent, further live Git command, remote query, or candidate repair was used. A strict default-deny sandbox exited 134 without calibration output; even `/usr/bin/true` exited 134 under that profile. Parent, child, filesystem, and loopback denial therefore were not established. I stopped before importing candidate code or running candidate SQL, fixtures, or pytest. The required independent direct and selector-free FULL gates have **zero execution credit**.

## Provenance established

All three named inputs matched their stated sizes and SHA-256 hashes. The outer ZIP passed its bounded pre-extraction directory gate: 573 safe regular members, 183,558,511 declared expanded bytes, and exact self-excluding manifest coverage of 572 members by CRC/readability, size, hash, and mode. The four nested archives passed equivalent bounded checks. Their cumulative declared expansion with the outer archive was 533,521,257 bytes.

Every current source payload matched its size, raw SHA-256, Git blob, Git mode, and numeric mode. The owned source copy has 327 paths and no extras: 326 OS `0644`, one OS `0600`, and all Git `100644`. Rebuilding Git trees from payload bytes yielded:

| Stage | Paths | Reconstructed tree |
| --- | ---: | --- |
| Integrated baseline | 315 | `44c7dee402d46b3e16dc389ae0824b4297dfec1f` |
| Original candidate | 325 | `648d332b3ba847deb257a2bb1892a76e4c442675` |
| S01/A03 | 327 | `011f76542a77b2a766a46ac08df102b4de4c09c6` |
| F01 | 327 | `5c44721183f660032b6468d2c1f5a1d0dc3e6acb` |
| Current | 327 | `4691af58ae0ee3107b4e2e9b6b1508032944e357` |

The immediate change is exactly five modifications, with no additions or deletions. The cumulative baseline change is 67 modified and 12 added paths. The other 322 immediate-predecessor paths, including SQL 0001–0008, the migration catalog, controller, writer session, and terminal contracts/rows/plan/SQLite owner, are byte-identical. SQL 0008 remains 30,178 bytes with SHA-256 `a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254`.

An audit-authored data-only parser replayed all five immediate patch sections and 14 hunks, and all 79 cumulative sections and 140 hunks, including additions. Every endpoint matched the authenticated current bytes. Independently reconstructed patch manifests matched their retained bytes. One retained manifest per kind cannot prove two historical writer runs.

## Contract review

The current [terminal owner document](/Users/ds/.codex/rw0-independent-audit-a0covndn/source_master/.docs/rw0-terminal-outcome-physical-closure.md:177) and [SQLite operations owner](/Users/ds/.codex/rw0-independent-audit-a0covndn/source_master/.docs/sqlite-operations-and-recovery.md:722) explicitly preserve the prior failed whole-operation zero-stop-SELECT result while adopting the two-layer rule.

Source inspection confirms that the shared [controller](/Users/ds/.codex/rw0-independent-audit-a0covndn/source_master/src/ge_nwp_coordinator/sqlite_transition_transaction.py:2759) validates the bound managed database before fencing. The unchanged [managed-state verifier](/Users/ds/.codex/rw0-independent-audit-a0covndn/source_master/src/ge_nwp_coordinator/sqlite_migration.py:2477) SELECTs `global_stop_current` to check singleton shape; the schema owner permits valid active and clear states. The [terminal owner](/Users/ds/.codex/rw0-independent-audit-a0covndn/source_master/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:318) separately reconstructs historical families from saved witnesses and predecessors, while its fresh path reads current heads and stop. This supports the documented distinction **at source level**. No independent current-byte authorizer run established the complete operation or its transitive readers.

The repaired [witness constructor](/Users/ds/.codex/rw0-independent-audit-a0covndn/source_master/src/ge_nwp_coordinator/_rw0_terminal_head_witness.py:48) visibly checks canonical bytes, exact tuple/dict/scalar components, five full owner rows and compact projections, then returns detached mapping views. Direct-constructor positives, hostile-equality negatives, alias mutation, and downstream behavior were **not independently executed**. The earlier constructor failure is historical; the present repair is not yet an audited pass. SQL 0008 visibly contains four STRICT terminal tables, eight immutable guards, and three recorded-at calendar predicates, but no independent SQL/admin control ran.

## Retained records

I independently parsed the archived writer collection observers, execution records, setup/call/teardown reports, explicit JUnit `nodeid` properties, combined logs, warnings, and source captures **as data**:

| Retained gate | Cases | Ordered-ID SHA-256 | Warnings |
| --- | ---: | --- | ---: |
| Direct | 60 | `229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467` | 0 |
| Connected | 6 | `81e14e3fa1b85a7be2ea6fafac85974839145bbcb6397e6da0bb1feeba060aac` | 0 |
| Focused | 8,266 | `419d37ff399689788123583f614a1d8b107ef712e2368ca179cd6e65fbec5104` | 3 |
| FULL | 9,568 | `25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9` | 3 |

The counts overlap: connected ⊂ direct ⊂ focused ⊂ FULL. The retained records reconcile internally with zero reported failures, errors, skips, xfails, or xpasses. The three broad-gate warnings are the stated writer-session fork warnings. All sixteen retained source captures match the final source rows. Direct JUnit phase properties contain, for each accept/replan case, six operation connections, 60 managed-stop **column callbacks**, and six intentional denied-head calibrations. Callback counts are not SQL-statement counts, and phase labels alone do not prove shape-only use. The active writer observer source and a launch-bound digest are absent, so archived results cannot supply independent execution credit.

## A01–A18 disposition

The full report gives exact archive-relative coordinates for every row. This register distinguishes inspected source and test design from retained records; none substitutes for the required current-byte causal runs.

| ID | Artifact-only observation | Mandatory gap |
| --- | --- | --- |
| A01 | Five private normal pairs and non-effect scope are stated. | No independent authority-boundary run. |
| A02 | Shared integration and frozen predecessor bytes were inspected. | P0/P1 preservation behavior not rerun. |
| A03 | Constructor repair and value grammar are visible. | Direct types, hostile equality, aliasing, F01/O1 unrun. |
| A04 | Identity domains, order, and graph code inspected. | Vectors and collisions unrun. |
| A05 | Exact original P1 operand is required in source. | Private replan mismatch matrix unrun. |
| A06 | Checked predecessor chain inspected. | Distinct forged V22 ref and source reseals unrun. |
| A07 | Accept path references an existing acceptance fact. | Legitimate unrelated fact coexistence and full negative matrix unrun. |
| A08 | Five-row witness and layered admission inspected. | Actual later heads/stop and managed-stop denial unrun. |
| A09 | Receipt-last and controller commit structure inspected. | Insert, readback, commit-fault matrix unrun. |
| A10 | Historical source path and disclosure order inspected. | Same-connection read/replay observation unrun. |
| A11 | Route and winner logic inspected. | All 17 physical occupancies and resealed winners unrun. |
| A12 | Error and cleanup branches inspected. | Process-control and uncertainty faults unrun. |
| A13 | SQL/catalog hashes and static constraints checked. | Eight-literal SQL/admin execution and prefix/refusal matrix unrun. |
| A14 | Connected fixture design inspected. | Independent five normals, cancel/profile, child/contact controls unrun. |
| A15 | Amendment and assurance successor inspected. | Assurance tests unrun. |
| A16 | Safe-row grammar inspected. | Independent privacy canaries unrun. |
| A17 | Writer records reconcile as retained data. | Active observer source absent; no independent gate credit. |
| A18 | Required test and SQL surfaces identified. | Independent direct and selector-free FULL unrun. |

The prior audit’s failed whole-operation stop criterion is superseded **only as an acceptance requirement**, not relabeled passed. Its interrupted FULL and process deviations remain historical limits. F03/F05 remain inherited nonblocking observations. No current production finding is asserted from an unreached predicate.

## Delivery and next state

The standalone [full report](/Users/ds/.codex/rw0-independent-audit-a0covndn/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_AUDIT_INCOMPLETE_20261028_a0covndn.md) was written before sealing. The [safe evidence ZIP](/Users/ds/.codex/rw0-independent-audit-a0covndn/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_AUDIT_INCOMPLETE_20261028_a0covndn.zip) was reopened; all 94 covered members matched its self-excluding manifest, and its embedded report equals the standalone bytes. The [adjacent receipt](/Users/ds/.codex/rw0-independent-audit-a0covndn/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_AUDIT_INCOMPLETE_20261028_a0covndn.receipt.json) records:

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| Report | 20,998 | `a93df092fa7947f10e1a246c302f5be8744a7b3a2586b9cbf790e5070768fc24` |
| ZIP manifest | 23,153 | `37a9d07aa5a6d81366bb454eff8b2ea02c7a79bf92bda2777acff09287081081` |
| ZIP | 3,531,883 | `5a07f202e2cf14a59674c34f8ca0cfc37664ea4082d925664416dab7cee1337c` |

No candidate source or `.docs` file was changed. No staging, commit, push, PR, merge, publication, deployment, or product effect was requested or observed. The excluded first Git-status interval carries no live-state preservation claim.

**The candidate remains unaccepted.** A new clean artifact-only audit with effective isolation and the mandatory current-byte controls is required before a separately governed exact-byte commit gate can be considered.
