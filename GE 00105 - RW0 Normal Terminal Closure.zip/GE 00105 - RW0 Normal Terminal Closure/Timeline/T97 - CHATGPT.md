## Engineering disposition

**The RT archive authenticates. The five claimed predicate closures are supported at their stated scopes. Preserve them, the existing WA1+QtcM runner, and W’s complete regression passes.**

The candidate remains **uncommitted and unaccepted** at:

```text
4691af58ae0ee3107b4e2e9b6b1508032944e357
```

The carried audit chain consistently binds that same 327-file subject and preserves the nonaccepting boundary. Pasted text

The next critical path is **one minimal, same-store second-phase prefix through the real private owners**. It is not automatically a second complete D2 → Section 41 → C1 → V22 → terminal chain. Use the minimal prefix to close the ten physical-route cases and the three remaining SQL-constraint rows. Build the full second source-coherent chain only where `C1B05` or `C2A20` actually requires it.

## Authentication and reporting correction

| Item | Verified result |
|---|---|
| Uploaded ZIP | **75,808,728 bytes** |
| SHA-256 | `c4d689950dbd1d4424ea56ed048d141333f20d8f92db568dfd9625026b921cf7` |
| Actual archive inventory | **179 regular members** |
| Self-excluding manifest | **178 rows**, covering every other member |
| Expanded bytes | **85,560,674** |
| Embedded report | **9,407 bytes**; SHA-256 `cde36ebb953c35faa914b9e58543d347b8057d782599ab003e6fa02d3db9a959` |
| Manifest | **42,940 bytes**; SHA-256 `789f0b49d756e455e7192f8da499fa78f967d896f549bd44de05227693e63274` |
| Current 56-row ledger | SHA-256 `4466735ce87c1fa1728be9a878e01a0ae3c86212c57f1f52fb3366f630baf48d` |
| Embedded RS archive | Exact **66,432,954-byte** predecessor with expected SHA-256 |

The inline Codex closeout said **181 members**. The archive actually contains **179 regular members: 178 manifest-covered payloads plus `MANIFEST.json`**. This is a **nonblocking reporting/count error**, not a provenance mismatch. There are no missing manifest members, unsafe paths, duplicate or case-fold collisions, unsupported file types, encrypted entries, CRC failures, mode mismatches, or unaccounted payloads.

All five source roles—master, causal, direct, smoke, and full—contain the same 327 rows and reconstruct the expected candidate tree. Eleven launches were admitted, one readiness attempt was safely refused before spawn, and the source and policy identities remained fixed throughout the recorded interval.

:chatgpt-content-reference{index="4"}[Detailed receiving inspection](sandbox:/mnt/data/Coordinator_RW0_RT3804_Receiving_Review.md)

## Closure judgment

| ID | Judgment and retained limit |
|---|---|
| **C1B03** | **Supported closed.** The command constructor rejects missing, reordered, and duplicate owner roles. Separate complete, FK-valid synthetic families alter the graph digest for the missing/reordered/duplicate cases, reseal the committed result and receipt, and reach the historical graph/receipt comparison. Record/read fail as integrity and recovery remains unresolved; valid counterparts pass. This does not claim a freely persisted graph-role-list column. |
| **C1B04** | **Supported closed.** An unrelated checked P1 decision is built in the same store through real P0, initialization, author-effect, and P1 owners. A resealed, FK-valid receipt points to that unrelated decision while preserving context/outcome/result parents. Historical comparison rejects it without movement. A supplemental collision record identifies the actual probe order; its raw result retained the conflict type but not its textual reason, so the exact reason remains source-grounded supplemental evidence rather than the sole closure basis. |
| **C2A19** | **Supported closed.** A complete `[1,1,1,1]` synthetic family is constructed with one deliberately invalid context self-digest; all child relations are resealed and foreign-key valid. Record/read refuse with integrity, recovery remains unresolved, and a competing command reaches the damaged route. This is synthetic damaged state, not a claim that the normal writer committed it. |
| **C2B11** | **Supported closed.** The probe closes the actual in-memory operation lease immediately before real mutation-lease acquisition. It records exactly one lease-acquire attempt, no terminal-row lookup, safe record/read refusal, unresolved recovery, unchanged terminal state, and a passing fault-removal counterpart. |
| **C2B13** | **Supported closed.** Faults reach the actual rollback and mutation-lease-close seams after real cleanup. Each has one counted hit, one recovery call, unresolved classification, no automatic retry, unchanged state, and a clean positive after fault removal. |

RT also contributes **nine useful literal foreign-key negatives** across context and outcome state. They remain partial evidence within `C3A02`, `C3A03`, and `C3A05`; those rows stay open only for their genuinely unproved uniqueness or remaining constraint seams.

## Exact remaining backlog

```text
C1B05

C2A04 C2A05 C2A06 C2A07 C2A08
C2A10 C2A11 C2A12 C2A13 C2A14

C2A20

C3A02 C3A03 C3A05
```

The evidence model must remain stratified:

- **L1:** literal SQLite constraint, using valid referenced parents, an isolated negative, a paired positive, enabled guards and foreign keys, and exact rollback.
- **L2:** individually checked, self-digest-valid, foreign-key-valid synthetic rows with one deliberate repeated-field, route, or source inconsistency.
- **L3:** a legitimate complete source-coherent history or competing winner through all required private owners.

L1 and L2 cannot substitute for L3. Conversely, a second complete terminal chain is not a default prerequisite for an L1 or L2 control. The earlier mandate already requires constructing only the actual minimum owner-valid prerequisite and continuing independent work rather than turning one unfinished fixture into a global stop. Coordinator_RW0_Normal_Terminal… Coordinator_RW0_Normal_Terminal…

## Selected construction path

RT’s `C1B04` fixture already supplies a distinct owner-built P0, initialized program, author effect, and checked P1 decision in the same managed store. The missing reusable parent is a **second phase**.

The continuation directs Codex to:

1. Construct **Phase B** in that same store through the real private pre-execution proposal/disposition and `_establish_rw0_phase` owners.
2. Preserve the original selected terminal chain unchanged.
3. Save and reopen a substantive Phase-B checkpoint before expanding the route and uniqueness fixtures.
4. Use Phase B and P1 B to construct FK-valid L2 terminal rows for the ten route predicates.
5. Use the same minimum parents for the three remaining SQL rows.
6. Expand to a complete second Section 41/C1/V22/terminal chain only where `C1B05` or `C2A20` proves that those predecessors are genuinely required.

The route controls require actual SQLite rows and the real terminal writer path. For each target, every earlier A-side selector must miss, the named selector must be the first checked match, the outward conflict must be `route_collision`, recovery must remain unresolved, and terminal state must not move.

The SQL work first maps every remaining constraint to carried RS/RT evidence or a genuinely unproved case. It must then exercise only the missing non-primary unique constraints with exact errors and paired valid insertions—not repeat already supported foreign-key or calendar cases.

`C1B05` receives a finite association matrix beyond the carried `source3` controls. `C2A20` remains the likely L3 case: a legitimate foreign complete winner and original-absence classification without disclosure, repair, or retry.

## Validation treatment

Do **not** automatically rerun:

```text
4 representatives
99 previously failing cases
60-case direct suite
9,568-case selector-free FULL
```

Those remain supported W v5 executions on the exact source under the explicit carry-forward rule. The operative guidance already separates mapped, source-bound carried evidence from automatic repetition after every new audit fixture or immutable registration. Coordinator_RW0_Normal_Terminal…

A rerun is required only if the new work changes candidate bytes, QtcM, runtime selection, an accepting WA1 branch, or another execution-relevant component in a way that concretely invalidates the historical run. Ordinary audit-only fixture and observer versions do not automatically invalidate it.

## Codex handoff

| Field | Instruction |
|---|---|
| **CURRENT STATE** | Five RT closures supported; exact candidate unaccepted with fifteen substantive predicates open. |
| **RECIPIENT** | The **same neutral independent reviewer conversation** that produced `rt-3804c351df`. |
| **ATTACHMENTS** | **None required.** RT and the carried chain remain at the exact retained paths in the prompt. |
| **AUTHORIZED EFFECTS** | Audit-owned same-store fixture, observer, registration and ledger work; unchanged-candidate execution through current WA1 plus exact QtcM; protected audit evidence only. |
| **EXPECTED RETURN** | One cumulative disposition, exact closed/open IDs, fixture-level evidence, corrected package accounting, complete report and reopened evidence ZIP. |
| **PROJECT SNAPSHOT** | **None requested.** |
| **NEXT ACTION** | Return the cumulative audit result here before any candidate repair or live commit gate. |

Send **only this complete replacement prompt**:

:chatgpt-content-reference{index="5"}[RW0 normal terminal closure — minimal second-phase prefix and fifteen residual closure](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Minimal_Second_Phase_And_Fifteen_Residuals_Prompt.txt)

```text
Prompt bytes:
47,119

SHA-256:
68555a2f3f2b85886270e26b9b40d8f94fddd7615ecce76e50fb3a1dddbc5d13
```

Supporting records:

- :chatgpt-content-reference{index="6"}[Receiving review](sandbox:/mnt/data/Coordinator_RW0_RT3804_Receiving_Review.md)
- :chatgpt-content-reference{index="7"}[Machine-readable verification](sandbox:/mnt/data/Coordinator_RW0_RT3804_Receiving_Verification.json)
- :chatgpt-content-reference{index="8"}[Handoff identity record](sandbox:/mnt/data/Coordinator_RW0_RT3804_Handoff_Check.json)

Keep the implementation conversation idle. No candidate edit, policy expansion, assertion relaxation, installation, staging, commit, publication, deployment, or new Project snapshot is authorized.

**Sources:** Uploaded RT evidence ZIP and its authenticated carried chain; operative twenty-residual mandate and carried-evidence rules cited above.  
**Confidence:** artifact/source identity and package reconciliation **0.99**; five scoped closures **0.98**; minimal second-phase construction strategy **0.96**. The fifteen remaining predicates, sufficiency of the Phase-B fixture, candidate acceptance, and commit-gate eligibility remain unestablished.
