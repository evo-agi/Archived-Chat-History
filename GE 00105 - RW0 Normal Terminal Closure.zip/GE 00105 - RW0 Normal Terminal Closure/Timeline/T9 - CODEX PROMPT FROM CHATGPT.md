ENGAGEMENT ENVELOPE

CURRENT STATE — PR #17 is the integrated Coordinator baseline. Normal terminal
closure remains uncommitted. The original 325-file candidate was BLOCKED on S01
(full closure-head witness and historical binding) with bounded A03 type defects.
This new 327-file repair has writer validation, not independent acceptance.
Keep the implementation writer idle.

RECIPIENT — A FRESH independent Codex precommit audit conversation, not the
implementation conversation. The parent owns one cumulative audit disposition.
No live-repository access, source repair, staging, commit or publication.

ATTACHMENTS — Exactly three actual files, identified in section 1. The two
implementation mandates are requirements evidence, NOT instructions to perform
their authoring, live-Git or cleanup actions. No chat history, Downloads lookup,
other conversation, standalone implementation report or extra source ZIP.

AUTHORIZED EFFECTS — Inert artifact/source inspection; audit-authored scripts;
isolated execution of authenticated candidate tests and bounded synthetic
controls; task-owned SQLite/process/fixture state; safe external audit evidence.
No supplied archived helper execution, network, live target, installation,
candidate-byte edit or product effect.

EXPECTED RETURN — One complete inline audit disposition/report and one reopened,
manifest-covered safe audit-evidence ZIP. Separate static inspection, retained
writer evidence, independent execution, inference and remaining uncertainty.

PROJECT SNAPSHOT — None requested. PR #17 remains the integrated baseline.

NEXT ACTION — Return the result to ChatGPT. ACCEPT supplies eligibility only for
a separately governed live exact-byte commit gate. BLOCKED supplies findings,
not repair authorization. Missing required capability yields INCOMPLETE.

OBJECTIVE

Audit the ENTIRE cumulative normal-terminal candidate, including the S01/A03
repair, against its actual requirements. This is not a repair-only acceptance.
Authenticate all inputs and source, inspect the cumulative contracts/SQL/
source/tests/assurance/privacy changes, independently close S01 and A03 with
discriminating controls, complete the unfinished A01–A18 obligations, and run
independent selector-free collection/FULL when no material blocker remains.

This is authorized defensive correctness work on owned artificial offline
fixtures. No live repository, service, credentials, provider, host or product
database is a target.

1. AUTHENTICATION AND SCOPED PROVENANCE

Actual input files:

A. RW0_NORMAL_TERMINAL_CLOSURE_S01_A03_REPAIR_UNCOMMITTED_REVIEW_F99A8B9B.zip
   bytes: 25,334,611
   SHA-256:
   f06d97a0becddec07e30676b3988dfcde9d4a79cb6b77a41c23fe4b9d429dd90

B. Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt
   bytes: 38,100
   SHA-256:
   9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f

C. Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt
   bytes: 29,145
   SHA-256:
   7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd

Use attachment locations actually exposed to this conversation. Never substitute
a same-named Downloads file. The operative effect ceiling is THIS audit mandate.
B remains the original acceptance requirement; C explicitly refines the selected
context-v2 repair and its compatibility treatment. Candidate documents cannot
silently narrow either requirement. Report any unresolved contradiction.

Before semantic judgment:
- Hash all three exact inputs.
- Inspect A's central directory: 1,131 unique normalized relative regular
  unencrypted members, distinct after case folding; no traversal, absolute or
  ambiguous path, link/special type. Bound each expanded member to 150 MB and
  each inspected archive's total expansion to 300 MB. The current outer
  expansion is 131,058,990 bytes.
- Verify all 1,130 rows of package/member-manifest.json by path, size, SHA-256
  and numeric ZIP mode, with exact self-exclusion and no uncovered member.
- Its authenticated embedded report is evidence/IMPLEMENTATION_REPORT.md:
  22,590 bytes, SHA-256
  0bbd1d73016e9b4593e14dd85743dad5ad1080f8892e4e5879a2f2b3f24107a5.
  Read it in full. No separate standalone copy/equality gate is required.
- Authenticate all source/ endpoints, Git blobs/modes, numeric OS modes and
  full path inventory against identity/final-manifest-A.json.
- Final manifest: 109,923 bytes, SHA-256
  45f6716d16522cecb21c046c302893624ab30e8094b15d7f93e628681e00dcbc.
  Require final A/B/postcleanup manifest bytes equal.
- Independently construct the Git-compatible trees FROM BYTES, not only reported
  manifest OIDs. No staging or git write-tree is authorized.

Required source chain:
  integrated baseline: 315 paths
    44c7dee402d46b3e16dc389ae0824b4297dfec1f
  original blocked candidate: 325 paths
    648d332b3ba847deb257a2bb1892a76e4c442675
  repaired subject: 327 paths
    011f76542a77b2a766a46ac08df102b4de4c09c6

The reported branch is codex/rw0-normal-terminal-closure-v1; reported HEAD is
61d0330aba1160f7f5e7d9c541a325222d1c61e5, whose recorded tree is the integrated
baseline. Branch/ref/index/config observations are retained records, not live
Git observations by this audit.

Immediate repair: 18 modified, 2 added, 0 deleted, 307 unchanged.
Cumulative from integrated baseline: 67 modified, 12 added, 0 deleted,
248 unchanged. No mode change.
Use identity/repair-delta.json, evidence/preservation.json and patch/recipe.json
as inspected data, then independently derive both changed-path sets.

Verify all immediate before/addition endpoints under patch/repair-before/ and
patch/repair-additions/. Reconstruct the baseline using
patch/cumulative-before/ and patch/cumulative-additions/. Independently replay
patch/cumulative.patch: 134,264 bytes, SHA-256
c8d27d1a8e81663ec3ec143eccc40bbc767e272b6b979cf4e0876b2405ec6b92;
67 tracked sections and all 12 addition payloads must yield exact final bytes.

Mode namespaces:
- final source: 326 OS-0644/Git-100644 rows;
- sole exception: tests/test_c2b3_private_atomic_program_initialization.py,
  OS 0600 / Git 100644.
Current source ZIP wrappers retain numeric OS mode. Authenticate that metadata
separately from the Git mode used in tree construction. Nested historical
archives may encode wrapper modes differently; follow their explicit records
rather than imposing one wrapper convention across all generations.
No current live checkout-mode claim follows.

Nested inputs, all mandatory:
- inputs/original-candidate.zip:
  11,648,876 bytes; SHA-256
  bf26189fd12b2b27fee847e0c0a1808cfeb568c9255bf48bc1f23ff14e728b0e
  938 regular members / 937 covered rows.
- inputs/independent-audit.md:
  22,955 bytes; SHA-256
  1fffe41981025295b92fe2c6bff00cd0c2e6d5f95b6b8f565b54f2610934dd7d
- inputs/independent-audit-evidence.zip:
  92,001 bytes; SHA-256
  e1fd90b32e1987307ba4f8e194d9a1c574a59a6e0de25e9e2a1100edc095331f
  44 regular members / 43 covered rows; AUDIT_REPORT.md equals the separately
  embedded full audit report.
Safely authenticate nested directories/manifests before relying on them.
Read the prior S01 probe, A03 probe, field inventory, full A01–A18 register,
SQL results and stopped coverage as evidence; execute none of their scripts.

Authenticate checkpoint/ source and manifest separately:
  327 paths; tree 23ec79a6a49c7821dcbc62f01bf4c04ea4a13aac
  manifest SHA-256
  85258843afd2815cf56506fb4b0f62fbc15741d091e6e41c613205a695bf9b20
Its retained 42-case result does not validate later final bytes.

Preserve the original BLOCKED verdict. Its 34 independent direct cases INCLUDED
the six connected cases, and its SQL/probe work was bounded; it ran no independent
selector-free FULL. No historical result accepts changed context/SQL/runtime
bytes. Failed/superseded attempts remain separately attributed.

2. SUBSTANTIVE REVIEW AND PERMITTED LOCAL VALIDATION

Read authenticated AGENTS.md, the current terminal owner and relevant
P0/P1/C1/Section41/SQLite contracts together with B and C. Inspect the whole
79-path cumulative change, not merely the 20-path repair. No candidate import
or execution occurs until input/source authentication and execution isolation
have passed.

2.1 S01 — REQUIRED REPAIR DETERMINATION

The blocked finding was historical underbinding, not an observed unsafe normal
fresh commit. The old unmodified fresh writer refused valid head drift; a
test-only bypass seeded self-consistent incompatible history that the old
historical path then accepted.

Independently determine whether the new source actually closes BOTH defects:
A. complete observed five-row retention;
B. repeated immutable-predecessor compatibility on every historical path.

Material inspection coordinates (relative to source/):
- _rw0_terminal_head_witness.py:14-125;
- _rw0_terminal_outcome_plan.py:54-112,115-227;
- _rw0_terminal_outcome_rows.py:90-140;
- _sqlite_rw0_terminal_outcome.py:216-259,318-445.
Python basenames are under src/ge_nwp_coordinator/.

Require:
- context schema governed-execution.nwp-rw0-terminal-context.v2;
- witness-set schema
  governed-execution.nwp-rw0-terminal-closure-head-witness-set.v1;
- exactly program/work/selection/effect/delivery entries in that order;
- each entry has exactly role and FULL canonical typed owner postimage, with
  all 8/9/41/9/8 fields, including valid nulls and own digest;
- exact owner adapters recheck all fields and self-digests;
- fixed 32,768-byte witness ceiling justified from actual supported field
  budgets, including supported maximal values, canonical depth/node/string/
  cardinality bounds; no truncation or accidental supported-input rejection;
- command and outcome compact coordinates are checked projections/assertions,
  never substitutes for the stored full rows;
- context digest binds full witness transitively through outcome/result/graph/
  receipt; no context-v1 or compact-only fallback or live-head backfill;
- fresh witness comes from real fenced typed reads, not desired plan/caller rows;
- one compatibility rule used by fresh record/planning, exact read/replay,
  original recovery and complete competing-winner verification;
- full program equals P1's retained program postimage; replan work equals P1's
  retained work postimage; other work and selection/effect/delivery are checked
  against immutable phase/reached-owner identities, digests and cross-links;
- historical checks neither query nor require equality with today's five heads
  or stop; later legitimate movement cannot erase valid history;
- original-route absence requires no invented closure witness;
- valid fresh drift -> no-write stale_currentness; malformed/failed reads or
  incompatible saved history -> integrity/uncertainty, not stale/definite absence.

Independently reproduce the old counterexample semantically on new bytes.
Use audit-authored synthetic family seeding/resealing outside candidate source.
Rebuild own-row, context, outcome, result, graph and receipt digests so an early
digest error does NOT mask the compatibility predicate. Include a valid family
built by the same seeding mechanism. Restore normal production paths before
read/replay/recovery. No candidate edit, exported bypass or supported-mutation
claim is authorized.

Exercise each of five heads separately for:
- every saved field equal to its actual closure read;
- bad own digest;
- valid own digest but wrong immutable predecessor;
- actual changed mutable row, not just caller expectation;
- wrong owner/program/work/effect/fence/delivery linkage;
- valid historical replay after later row movement, with transitive mutable
  head/stop query prohibition observed at a sufficient seam.

Test COMPLETE incompatible competing-winner history, not only original-family
mismatch or a monkeypatch making the winner verifier raise. It must not certify
definitely_not_committed. Keep valid complete-winner and exhaustive-absence
positives. Inspect the supplied tests for actual predicate credit and add
independent discriminating controls for missing obligations.

2.2 A03 AND RECEIVING OBSERVATION O1

Verify exact built-in strings BEFORE equality/membership for incoming head role,
externally supplied role argument, conflict reason, recovery classification,
new witness schemas/roles and directly related new terminal enums.
Reject subclasses/equality-spoof objects without coercion or serializing them
away first. Preserve valid built-in positives and valid finite vocabularies.
committed_exact must carry exact TerminalCommittedV1; both other classes carry
None. Inspect directly constructed values as well as canonical decoding.

O1, a bounded test-oracle observation, must receive an explicit decision:
tests/test_rw0_terminal_outcome_values.py:111-116 increments self.calls inside
EqualitySpy.__eq__, but :133 checks EqualitySpy.calls on the CLASS. An equality
call can shadow the class attribute on the instance, leaving the checked class
counter zero. That assertion alone does not prove noninvocation.
The visible production type-first checks are not thereby disproved.

Use an audit-authored shared mutable/per-instance counter or equivalent
discriminating probe. Establish rejection and noninvocation independently at
the exact boundaries. Do not modify the candidate test, silently credit its
class counter, or automatically turn a low test weakness into a runtime defect.
Record whether O1 remains nonblocking or exposes an actual material defect.

2.3 COMPLETE A01–A18 REGISTER

For each row give exact archive-relative path:line evidence, severity and
evidence class (contract/current implementation/bounded proof/compatibility/
target/retained record/independent execution/inference/limit). Cover the full
original scope and repaired bytes; "unchanged from earlier audit" alone does
not discharge unfinished coverage.

A01 Authority: terminal fact distinct from P1 decision/acceptance, policy grants,
source facts and executable permission. Exactly five normal outcomes; cancel,
gate-B supplier, RW0-E/live contact, ES/Bridge/Git effects/autonomy excluded.

A02 Preservation: terminal-V1/four validators, P0/P1 meanings/owners, WorkSpec,
Decision Basis/command-digest v2, preassignments, D1/D2 source behavior, original
operand requirement, package/public StateStore and generic receipt unchanged.
Inspect cumulative shared writer/controller/catalog edits, even though those
writers are byte-equal to the blocked candidate during this repair.

A03 Grammar/types: all new commands/values/rows/results/recovery; exact types,
closed keys, duplicate handling, canonical UTF-8/JSON, bool-as-int, safe refs,
digest/time grammar, bounds; independently resolve A03/O1.

A04 Identity graph: sibling refs/route, independent domains, acyclic transcripts,
assertions in command identity but outside preassignments, graph roles,
cardinality, self-digest exclusion and duplicate-column consistency.

A05 Original transient P1 command and private replan operand: authenticate whole
persisted predecessor family; missing/mismatched operand cannot prove certainty.
No template reconstruction from digest, persistent template store or private
content leakage.

A06 Actual P0/phase/Section41 A/C1 rank15/V22/P1 source association. Completeness
comes from owning checked readers, not supplied digest equality or membership
count. Transitive validation/review/proposal observation and result-set binding.

A07 Existing immutable acceptance fact bound only for accept, never inserted,
mutated or replenished; unrelated legitimate facts do not prevent other branches.
No historical unclaimed-scope eligibility recheck.

A08 Complete observed closure heads and stop; full S01 witness/binding decision.
P1 replan postimages distinguished from phase entry. Changed correctly expected
stop is a recordable fact, not new effect permission.

A09 Transaction: existing fenced lease/capability/controller; one time,
receipt-first protected posture, predecessor/current/route checks,
context/outcome/result writes and readback, receipt last, capability invalidation,
one commit attempt and cleanup. No application head/stop/decision/effect update.

A10 Replay/read: original immutable result/time/graph, source reauthentication
and full historical witness compatibility; no current-head/stop dependency,
new cognition/process, recording permission or acceptance-eligibility requirement.

A11 Recovery: exact full family, exhaustive original absence/exclusion or
complete compatible winner only; partial/foreign/damaged/aliased/incompatible
history unresolved. No winner disclosure, automatic retry or fragment repair.

A12 Error/cleanup: failed reads and malformed owners stay integrity/operational
failures; actual valid drift stays currentness. New terminal entry's stale
issuance, closed/fenced session, commit/cleanup uncertainty and all three
process-control exception boundaries causally checked.

A13 Schema: uncommitted 0008 context-v2/bound correction; four STRICT immutable
normal-only tables, composite FKs, phase/decision/mutation/route uniqueness,
nullable pairs, zero seeds, guards, exact catalog/checksum, generation 2,
fresh/prefix migrations and old-0008/old-binary/partial/unknown refusal.

A14 Five actual source-coherent connected normals through P0/D1/D2/Section41/
C1/V22/P1/terminal/read/replay/recovery. Vary fixture content BEFORE capsule
sealing/checker execution. Detached resealed disposition is a negative, not a
normal positive produced by relabelling a passing checker.

A15 Whole cumulative docs/assurance change: exact source/hash/AST/import/schema
consumers and preserved historical markers; fixed current/predecessor guards,
no dynamic oracle, skip/xfail, broad stripping or weakened test for new source.

A16 Privacy/artifacts: new full postimages remain safe owner metadata; no raw
private replan text, prompts, capsule/process results, PID/path/handles,
credentials/user state in durable rows or errors. Review grammar, not just
sample canaries. Classify checkpoint/failed attempts and Finder exclusion.

A17 Retained evidence: authenticate observers/logs/argv/env/JUnit/IDs and source
binding; preserve overlap, per-gate warning identity and superseded-run noncredit.
A causal register is not an independently reached predicate.

A18 Independent validation: source-bound probes/direct suite/SQL and completed
selector-free collection/FULL, complete node/outcome/warning/source reconciliation.
Unperformed work remains explicit; no live-state or production-readiness claim.

2.4 ADDITIONAL MANDATORY CAUSAL COVERAGE

Alongside S01/A03, independently establish the original unfinished boundaries:
- five normal connected positives, three cancel shapes and unsupported-profile
  no-write refusal;
- transitive, correctly resealed detached validation/review/proposal/source
  evidence; wrong/missing/foreign acceptance fact; no acceptance/head/stop/P1
  family movement from terminal recording or history;
- required original replan operands on record/read/replay/recovery, including
  privately inconsistent operands sharing a safe claimed identity;
- changed optional assertions alter command digest but not sibling refs;
  command reuse cannot obtain original protected result or false recovery;
- fresh recording+disclosure versus historical disclosure-only; truthful
  claimed False/None after P1 acceptance; denied/expired/negative/malformed/
  foreign posture and protected absence;
- active/changed correctly expected stop versus genuine head drift, failed
  SELECT and malformed row discrimination;
- row insertion/readback/receipt-last rollback, exactly one commit, before-commit
  failure, applied commit/lost return, postcommit cleanup uncertainty, recovery
  cleanup uncertainty, no hidden retry;
- complete winner, wrong/partial/foreign/damaged winner, all creation/alias
  routes; no competitor-result disclosure;
- stale lease/fence/closed session and KeyboardInterrupt/SystemExit/
  GeneratorExit at meaningful new terminal boundaries.

Use candidate fixtures only after inspecting them. Independently authored
controls may reuse known setup, but their oracle, fault seam and reached
predicate must be independently stated. A bad digest cannot prove a later
semantic relation, and a monkeypatched verifier exception cannot prove that the
real verifier rejects a fully formed incompatible family.

Independently apply the eight authenticated SQL resources ONLY to disposable
audit-owned state. Required cumulative counts:
  0006: 68 tables / 122 triggers / 5 explicit indexes
  0007: 74 / 134 / 5
  0008: 78 / 142 / 5
0008 SHA-256:
  5bd540def9028d09c4e2100f61f449acfb3a5c914fa554f47975d8c773d4cd20
Verify unchanged earlier schema objects/resources, zero seeds, immutability,
FK/unique/normal/pair and payload bounds, fresh initialization, supported
explicit-prefix migration and old checksum/schema/binary/unknown/partial
refusal. The old uncommitted 0008 is NOT a deployed format to backfill.
The frozen schemas/sqlite/coordinator-state-v1.sql remains historical 0001
evidence, not a cumulative regenerated schema.

2.5 RETAINED EVIDENCE AND INDEPENDENT EXECUTION

Reconcile final writer records, as retained evidence only:
  direct: 46 cases, 0 warnings
  connected: 6 cases, 0 warnings (included in direct)
  focused: 126 complete modules, 8,252 cases, 3 warnings
  FULL: 9,554 cases, 3 warnings
Within every gate: unique ordered collection = execution collection = calls =
JUnit, all pass, zero failure/error/skip/xfail/xpass and noncall failure.
All narrower IDs occur in retained FULL. Do not sum overlapping counts.

Source-preservation scope: the archived run_gate helper verifies full inventory
before collection and after execution, retaining source-binding summaries; it
does not retain a separate full snapshot at the intervening phase boundary.
Describe that evidence honestly. Do not execute supplied tooling/run_gate.py,
gate_observer.py, capture_source.py, original audit scripts or other archive
helpers. Inspect them as data and author your own observation mechanism.

If no material blocker remains:
1. Independently run all five complete direct terminal modules, in this order:
   tests/test_rw0_terminal_outcome_values.py
   tests/test_rw0_terminal_head_witness_regression.py
   tests/test_sqlite_rw0_terminal_controls.py
   tests/test_sqlite_rw0_terminal_migration_0008.py
   tests/test_sqlite_rw0_terminal_connected.py
   Expected 46 unique passing candidate cases including six connected.
   Keep audit-authored additional probes separately counted.
2. From a fresh exact 327-file audit copy, perform one selector-free collection
   and one selector-free repository FULL execution. Expected 9,554 unique IDs
   are in validation/full/collection/observer.json. Audit probes must remain
   outside candidate discovery and must not change this inventory.
3. Require exact independent collected/executed/JUnit identity and order;
   reconcile against the retained final inventory rather than counts alone.
   All 46 direct, six connected and 8,252 focused IDs must be represented.
   A separate 8,252-case focused run is unnecessary when FULL inclusion is
   proven; do not claim it ran separately.
4. Require zero failures, errors, skips, xfails/xpasses or failed setup/teardown.
   Independently inventory warnings. The three known FULL warnings are the
   writer-session multithreaded-fork DeprecationWarnings:
   test_operation_guard_close_waits_and_retains_authority_until_exit
   test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
   test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
   Investigate any new class/node/text difference; no warning suppression.
5. Independently capture FULL before/after raw source bytes, Git-compatible
   identity, numeric modes and extra-file inventory around both collection
   and execution. Require all 327 source endpoints unchanged.

Use the existing comparable Python 3.13.4 / pytest 8.4.1 / SQLite 3.49.1 runtime.
No installation. Verify effective network denial with a bounded synthetic
sandbox check before candidate execution. Restrictive umask, task-owned
HOME/TMPDIR/basetemps/JUnit/logs, deterministic locale/timezone, -B,
PYTHONDONTWRITEBYTECODE=1, PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, empty PYTEST_ADDOPTS,
-p no:cacheprovider; no inherited selection or warning suppression.
Read pyproject/config/conftest first; keep audit-owned observer separate and
non-selecting. Never import from a live checkout.

Command forms, from each authenticated audit-copy root:
  <python> -B -m pytest -q -p no:cacheprovider [audit-only observer]
    --collect-only --basetemp=<owned collection path> <complete module list>
  <python> -B -m pytest -q -p no:cacheprovider [audit-only observer]
    --basetemp=<owned execution path> --junitxml=<owned XML>
    <same complete module list>
For FULL, omit ALL module/path/node selectors. Preserve exact argv, cwd,
allowlisted environment, versions, exits, output, IDs, JUnit, warnings and
source inventories. Combined stdout/stderr is acceptable only when explicitly
labelled; never invent separately retained stderr.

Required unavailable isolation/runtime capability means INCOMPLETE, not permission
to run against live state, install dependencies, weaken the ceiling or fabricate
a pass. Candidate failures remain failures. An audit-helper error may be
corrected transparently on fresh owned state, with original evidence retained;
it must not be converted into candidate blame or silent retry credit.
On a material finding, stop broad FULL work and preserve the exact completed/
unperformed coverage. No broad pass is required merely to restate a blocker.

3. FINAL FINDINGS AND ACCEPTANCE LIMITS

Return exactly one primary disposition:

RW0_NORMAL_TERMINAL_CLOSURE_S01_A03_REPAIRED_CUMULATIVE_ARTIFACT_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
RW0_NORMAL_TERMINAL_CLOSURE_S01_A03_REPAIRED_CUMULATIVE_ARTIFACT_AUDIT_BLOCKED
AUDIT_PROVENANCE_MISMATCH
RW0_NORMAL_TERMINAL_CLOSURE_S01_A03_REPAIRED_CUMULATIVE_ARTIFACT_AUDIT_INCOMPLETE

ACCEPT requires exact final tree
011f76542a77b2a766a46ac08df102b4de4c09c6, closure of S01 and A03 at the
required scope, explicit O1 treatment, cumulative A01–A18 completion, all
mandatory causal/SQL controls and independent 9,554-case selector-free FULL
with identity/outcome/warning/source reconciliation. Explain any nonblocking
observation rather than silently treating it as repaired. F03/F05 stay inherited
nonblocking observations.

Acceptance is only eligibility for a later live exact-byte commit gate. It
does not stage, commit, push, open a PR, merge, publish, deploy, authorize live
terminal/cancel execution or establish autonomy.

Return one complete inline report and one reopened audit-evidence ZIP, with:
- exact inputs, reconstructed source chain, deltas, modes, patches, migration
  and checkpoint identities;
- S01 full-field and historical-path determination; A03 and O1 decisions;
- A01–A18 table with paths/lines, evidence classes, findings and limits;
- exact independent causal outcomes and their actually reached predicates;
- direct/connected/FULL overlaps, SQL/admin results, warning reconciliation;
- retained versus independently executed evidence, all unperformed coverage,
  errors/superseded attempts and cleanup/preservation record;
- artifact-only/live-state limitations and explicit effect record;
- exact report/ZIP/member-manifest sizes and hashes, verified after reopening.

No secrets, live paths/credentials, raw user/product databases, bytecode/cache,
or unclassified binary state in evidence. Synthetic probe source/logs are
evidence, never production authority.

PROHIBITED: live repo/.git/index/ref/config/cache access; candidate source/test/
doc/schema/mode edits; archived helper execution; network/provider/ES/Bridge/
service contact; user/product databases; dependency installation; staging,
commit, push, PR, merge, publication, deployment, cancellation implementation,
supplier qualification, or product effect.

A platform refusal or missing audit capability is not a candidate defect or
acceptance. Preserve completed findings and identify exact missing coverage.
Do not automatically retry an access refusal or ask another reviewer to take
over. The next recipient is ChatGPT, not a live commit or repair operation.
