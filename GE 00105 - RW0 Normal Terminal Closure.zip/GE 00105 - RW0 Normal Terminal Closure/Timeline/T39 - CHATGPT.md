## Engineering disposition

**The neutral-directory routing problem is resolved for this reported attempt. Environment qualification is still incomplete. Do not change the candidate or repeat the failed sandbox launch yet.**

There are now two distinct issues:

| Issue | What the closeout establishes |
|---|---|
| **Startup sequence** | Codex reports reading the exact pasted request in the neutral directory before declaring its directory and attachment bindings. That violates the mandate’s ordering rule, but is **not the earlier live-checkout access violation**. |
| **Execution boundary** | The newly authored policy failed its first positive control: the `sandbox-exec … /usr/bin/true` launch terminated with signal 6. No Python marker or containment matrix ran. |

The reported directory was `/private/tmp/rw0-audit-entry.daLWIE`, and Codex reports no live-checkout inspection. **There is no reason to repeat project selection, create another directory, or alter Coordinator’s settings.**

## Do not turn the declaration-order lapse into another restart loop

The existing mandate explicitly required the two bindings to be stated before the first shell command, so this attempt cannot be relabelled compliant under that rule. Coordinator_RW0_Normal_Terminal…

However, my handoff made a declaration-order requirement more brittle than necessary when the operative request itself may need to be opened from a supplied file. **Reading that exact instruction file, from the correct neutral directory, is materially different from running Git or discovering repository files.**

For the next continuation, I select this **prospective procedural amendment**, subject to confirming the recorded first action:

> Permit a necessary read of the exact host-exposed instruction file to load the mandate. Require the directory, input bindings, and effect boundary to be stated before any qualification probe or other operational command. Prohibit repository discovery and all other incidental reads.

This does not erase the latest `INCOMPLETE` result, backdate a clean interval, or relax containment. It means we should be able to continue in the **same neutral reviewer conversation**, rather than restarting solely over that declaration sequence. **No continuation is being issued yet.**

## The substantive blocker is still the launch failure

The reported runtime versions match the requested versions, and the synthetic sentinels were accessible outside containment. Those are useful preparatory observations. They do not establish that Python, SQLite, fork/exec, filesystem restrictions, or network restrictions work **inside** the proposed boundary.

Similarly, unchanged sentinel bytes after an aborted launch do not prove denial: the probe never reached the operations that would test it.

The latest attempt is better evidenced than the earlier one because Codex says it retained the exact launcher and policy. But their hashes alone cannot establish why the launch aborted. **I have not inspected those bytes or the raw invocation records**, and will not infer a missing permission, operating-system defect, or nested-sandbox conflict from this closeout.

The existing mandate already allows bounded correction of audit-owned launchers and policies and explicitly makes **effective containment—not default-deny syntax—the acceptance property**. It does not authorize unrestricted execution merely to get past startup. Coordinator_RW0_Normal_Terminal…

Accordingly, the next engineering decision should come from the retained policy and launch records—not another guessed profile or a blind rerun.

## Next action: upload the small qualification evidence ZIP

Upload **only this existing archive here**:

```text
RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_INCOMPLETE_20261028.zip

Bytes:
43,553

SHA-256:
ec71fd70ce2cf90a819ae4175593bf8691dd80753e01990bd260a187a418d3ef
```

Its reported location is:

```text
/private/tmp/rw0-qualification-gx644o3v/
RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_INCOMPLETE_20261028.zip
```

**No separate report, old evidence archive, candidate package, or screenshot is needed.** The ZIP should contain the 10,676-byte report and the new launcher, policy, probe, and execution records. It is not currently attached here.

The receiving inspection will establish whether the recorded first action supports prospective re-entry, examine the actual launch and policy, and determine the smallest justified diagnostic or correction. Missing evidence will remain a stated limit; it will not be filled by assumptions about the host.

Keep the current neutral reviewer conversation parked and the implementation conversation idle. Do not rerun qualification, install anything, change host protections, or execute candidate code while that inspection is pending.

The candidate remains unaccepted at tree `4691af58ae0ee3107b4e2e9b6b1508032944e357`. This qualification failure adds no candidate defect or independent test credit. The earlier audit established artifact identity, not acceptance. Pasted text All substantive audit obligations and the complete containment calibration remain required. Coordinator_RW0_Normal_Terminal…

**Sources:** Your latest Codex closeout; the operative qualification mandate and prior candidate-audit record cited above.  
**Confidence:** High on the separation of the two blockers and the evidence-first next step. The new archive’s identity, the reported first-command scope, and the abort’s cause remain unverified here.
