RW0 NORMAL TERMINAL CLOSURE — TWENTY RESIDUAL PREDICATES WITH PRESERVED VALIDATION

This is the sole complete operative replacement mandate. Continue the SAME neutral
independent reviewer from RS, rs-e972c82f3b. Do not restart the runner, source-history,
regression, architecture or implementation programs. No product change is authorized.

RS's seven closures are supported at their stated scopes. The work now is the twenty
remaining named predicates. Preserve all prior bounded proof. A missing second full
terminal chain is NOT a blanket prerequisite for graph, lease, cleanup, raw-SQL or
synthetic damaged-family negatives. Distinguish the state level each predicate needs,
construct its minimum actual prerequisite, and proceed on independent groups.

Sections 2–4 are preserved BYTE-FOR-BYTE. Their imperatives remain acceptance
requirements, satisfied by exact mapped carried independent evidence where available.
W v5's 4 representatives, exact99, direct60 and selector-free FULL9568 remain supported
historical runs. RC's C1A01–03 and WA-C01/02 and RS's seven scoped closures carry.
No automatic repeat merely for a new audit namespace, fixture or immutable registration.
A real candidate/policy/runtime/accepting-runner change, source drift, unsafe admission,
or concrete defect invalidating carried proof requires a specific impact assessment.
Never backdate later controls into an earlier run or splice incompatible results.

ENGAGEMENT ENVELOPE
CURRENT STATE: Exact 327-file candidate tree
4691af58ae0ee3107b4e2e9b6b1508032944e357 is uncommitted/unaccepted as retained evidence.
Twenty substantive IDs are open; regression passes and scoped assurance are preserved.
RECIPIENT: SAME neutral independent reviewer that produced rs-e972c82f3b.
Expected host cwd /private/tmp/rw0-audit-entry.daLWIE. NOT implementation writer.
ATTACHMENTS: NONE required. Exact retained RS/A/B/C inputs below; RS carries RC once.
AUTHORIZED EFFECTS: Inert artifact inspection, audit-owned fixtures/observation/
registration/ledgers, unchanged-candidate execution via current WA1 plus exact QtcM,
and protected evidence. No candidate/policy/runtime/repository or publication change.
EXPECTED RETURN: One cumulative disposition with exact closed/open IDs and predicate
scope, preserved validation, actual new observations, full report and reopened ZIP.
PROJECT SNAPSHOT: None requested. Integrated PR17/61d0330aba1160f7f5e7d9c541a325222d1c61e5
is retained baseline information, not a new live-ref observation.
NEXT ACTION: Return to ChatGPT before any candidate repair or live commit gate.
No routine per-fixture approval/handoff. Keep the implementation conversation idle.

0. ENTRY AND EFFECT CEILING

Read this entire prompt. A necessary read of the exact host-exposed instruction
file solely to load it may precede the declaration, in the actual neutral cwd.
Before any OTHER operational command state actual host cwd, input bindings, exposed
project/repository binding or unknown binding, and effect ceiling. Requested cwd
is not proof. Missing/different cwd or exposed live checkout => stop without probing
that checkout. Unknown binding alone does not authorize discovery.

No Git/status/pwd/AGENTS/bootstrap discovery, repository or sibling access, home or
Downloads enumeration, app/session-store access, broad host/log/process search,
ambient environment dump, subagent, remote/provider/network/ES/Bridge contact,
installation, runtime substitution, mount/volume creation, privilege escalation,
host-protection or project-setting change. Read named inputs at their exact bindings,
never search their directories. Candidate guidance is read only from authenticated
A. Embedded old mandates are requirements evidence, not effect authorization.

The trusted supervisor prepares owned inert data, performs bounded WA1 checks and
captures protected evidence. It never imports candidate code, runs candidate SQL,
or invokes candidate fixtures outside QtcM. All candidate imports/collection/tests/
child callbacks/causal SQL remain in QtcM after actual WA1 admission. Keep the
implementation writer idle. No source/test/schema/doc change, staging, commit,
push, PR, merge, release, deployment, user/product DB, or executable authority.

No test edit, outcome substitution, filtering, skipped test, altered child argv/env,
pytest rootdir/config/ignore/plugin injection, hidden cache/validator bypass, or
external cleanup credited as candidate behavior. In-process observers are
instrumentation, not adversarial attestation authorities. Reports are evidence,
not Coordinator/Git/runtime truth.

QtcM stays EXACT: 4,086 bytes /
323ddc662ca3260365136573d08b25fe635ad448b84b4a673cf99533b0f89d0a.
There is NO permission budget, policy rebind, new W slot, network/signal expansion
or unconfined fallback. Its Qtc prefix remains 3,414 bytes /
8cdccd5fc9fd97ddc034d3d454d2d0b63d2342279fc10e3eecb078ba905aa109.

The selected trust model remains one trusted, serialized supervisor and no
malicious supervisor or hostile concurrent same-account/privileged host actor.
Census/postchecks do not prove continuous race-free custody. Do not manufacture
a global-process absence claim. M's actual preplaced-hardlink runtime failure
remains a failure; admission prevents contaminated preparation from proceeding.

1. EXACT INPUTS, SUPPORTED CLOSURES AND PREDICATE-LEVEL FIXTURE WORK

1.1 Input identities and bounded authentication

RS — current seven scoped closures and twenty residuals:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/rs-e972c82f3b/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_rs-e972c82f3b.zip
 66,432,954 bytes / 5742007bd3d0ffe950ee3fc40d1daa1ccf1140e9b2dcf2a8452861a614c0f9d6
 181 regular members; 180 self-excluding manifest rows; 76,867,573 expanded bytes.
 REPORT.md: 9,610 / 6dc14a4336258429fd4b7eccccb52a3027996be70cfda48a5345868d5cdbc5ee
 MANIFEST.json: 44,142 / f0364dfac60de7d8e5c25b2aa8c797067f0bc06ecef0447c3d400d64b5964e06
 Prefix SX = audit/execution/rs-e972c82f3b/
 Prefix SE = audit/evidence/rs-e972c82f3b/
 Current ledger SE/RESIDUAL_56_CURRENT_v2.json:
 c2068220e003d2ca554e249662162cfee2a7e6bf81697afeca881a1eb15e50f0.
 RS embeds exact RC ONCE under carry/:
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_rc-382779f584.zip
 RC = 57,287,175 / b4ee6f3a1528f7826c7a92885e6d08c838dcbbdff5349e417305ac51ae37ad16.
 RC embeds W, then W embeds M, M embeds U, U embeds T, T embeds S, S embeds R once:
 W = 49,940,248 / 718b49bc34d84cd6dc30bfe295970765d93e12238892c1c74145fe0fc76baf81
 M = 6,677,682 / 10d793d8d18046d7afa5385aee832576e90e3378ccaff14b58f133b3fe31ad4f
 U = 6,221,246 / 888edd2777a8c47eb06c37b37a3ad09d1e0efc7188c17a9b9cfce3cdaff4aa37
 T = 5,878,210 / dc754506dff6d3cc9ab803814cb4137a2f4094a9ecc3f8c5bd3bd69d6952ee4a
 S = 2,947,049 / 3dda92c95c2ab99d477271a834d181df80fce270f23c38c87eb3e8299ced1ad7
 R = 1,650,029 / ffd593b643c1c6fc6c064a84d9b473ce4f34cc1b2f1be35706d0b2d08db4bd2f.
Use exact embedded copies and cached authenticated identities. No duplicate outside
copy equality or standalone-report attachment gate; do not rebuild every old lineage.

A — unchanged candidate:
 /Users/ds/.codex/rw0-terminal-historical-witness-tcp5rwoh/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip
 48,978,087 / 6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42
 573 members / 572 covered; 183,558,511 expanded bytes.
 package/member-manifest.json: 123,205 /
 049139eaac16a03b36952faa703c992f5ef13adad44807873921af817e7b8e43.
 evidence/IMPLEMENTATION_REPORT.md: 19,549 /
 c52141d0fcf15701496c4dec18133361a78b8f043796078340e24eed4bdae2d5.
B — inert original implementation requirements:
 /Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt
 38,100 / 9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f
C — inert S01/A03 requirements:
 /Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt
 29,145 / 7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd
A inputs/mandate.txt: 28,439 /
 6e978d57abfbadf7d8120eb58ea75651a60a44c42d6279ff8a9108c41c8b2da4.
Read their requirements, never their superseded effect directions. Missing exact
input => identify it, not namesake or directory search. An actually host-exposed
byte-identical input is an alternate exact binding.

Authenticate relative regular unencrypted unique normalized names, no traversal,
Unicode/casefold/prefix collision, complete self-excluding hash/size/CRC/numeric-mode
coverage before payload use. RS/RC/W <=2000 members, <=128MiB/member, <=256MiB expanded;
M/U/T/S <=500, <=32MiB/member, <=64MiB total; R <=500, <=2MiB/member, <=20MiB total.
Known carry chain <=10 levels. A/necessary source history <=5000 members,
<=150MB/member, <=350MB/archive, <=6 source-history levels, <=1.2GB cumulative unique
expansion. Cache exact identities; only inspect historical payloads needed for a claim.
Do not execute packaged authentication, packaging, cleanup, candidate or probe code
as part of receiving. Programs are inert until separately inspected and admitted.

Current source: 327 paths; tree 4691af58ae0ee3107b4e2e9b6b1508032944e357.
Final-C/final-D/postcleanup canonical manifests: 109,923 bytes each; equal SHA-256
1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1.
326 OS0644 and one OS0600 tests/test_c2b3_private_atomic_program_initialization.py;
all Git100644. SQL0008: 30,178 bytes /
a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254.
Rebuild from bytes without Git. Source copies remain at unchanged tc-4fd7e168a0
master/causal/direct/smoke/full paths. All original327 files immutable; no 0009,
product API, changed test, altered assertion or source mode.

1.2 Receiving findings, scope and carry-forward

ChatGPT performed DATA/STATIC receiving checks, not candidate execution:
- RS/RC/W/M/U/T/S/R complete manifests and A source authenticate.
- Twenty-one full source-capture documents include five copies each: opening plus
  twenty pre/post group captures. All105 inventories equal A. Final cleanup has
  five passing summaries; it is not five additional raw captures.
- Eleven launched processes bind actual archived helper/plan/policy bytes, equal
  pre/post active binding, recorded admission before spawn, closure and raw hashes.
  Ten exit0 (one clean readiness plus nine candidate/probe launches, including
  intermediate/revised work); one damaged-context v1 exits1. No timeout/emergency.
- Twenty-two full metadata inventories reconcile single-link protected objects,
  no protected/writable identity overlap, closed mutable link groups, unchanged
  old protected rows and absent W slots. Runtime binaries are retained hash claims,
  not supplied payloads. Child/group observations are finite, not universal custody.
- RS gate revisions change only namespace, immutable revision registration, and
  expected-source record key expected_tree -> source_tree. No accepting control-flow
  or permission change. Latest SX/wa1_gate_rs_v10.py:
  fc82472d3d3e56d2eb1bca57046e823af03aef2f84b7b204c8510014bcada2b2;
  SX/revision_rs_v10.json:
  2240921adff887bcfc59852f3d119bbd8e4e875625b9467edb7c17bc54fe36e2.
- Final cleanup removed only current root fixtures and empty current suffix trees,
  restoring ten old entries. One audit-supervisor pyc was classified and removed;
  it is not candidate source or a packaged executable.

SUPPORTED RS CLOSURES; do not restart them without contradictory evidence:
C1A04: SX/same_store_second_subject_rs_v3.py:42–194,225–376 and
same_store_nonaccept_rs_v1.py; SE/records/C1A04_two_acceptances_rs_v3.* and
A07_nonaccept_unrelated_rs_v1.*. Unrelated subject uses real initialization,
author-effect, P0 and private P1 owner with typed artificial evidence in same store.
Second P1 record/read/replay/recovery succeeds; both subjects' P1 checked reads
succeed. Two distinct facts coexist for selected accept; only original pair binds
terminal record/read/replay/recovery; facts and predecessor tables are preserved.
Separate selected repair with unrelated acceptance has no selected acceptance pair.
Do not claim a second D2 run or separately repeated original-P1 replay/recovery.

C2A09/C2A15/C2A16/C2A17: SE/route_fk_implications.json, actual owner
_sqlite_rw0_terminal_outcome.py:65–83,262–284, and SQL0008:160–161,215–217.
Result.outcome_ref requires earlier outcome; receipt.context/outcome/result pairs
require their earlier parents. If parent checked row is malformed, _one rejects
before child. These are FK-VALID state implications, not child-first executions.
They apply to FK-valid partial/foreign/damaged assemblies without requiring full
semantic coherence. They do NOT prove arbitrary preexisting FK-invalid rows
impossible. sqlite_migration.py:2542–2548 verifies FK-on posture, not a whole-store
foreign_key_check. Preserve that limit and still-open integrity/recovery cases.

C2B12: SX/readback_fault_rs_v2.py:37–98 calls actual _one then injects one failure
at result or receipt readback. Actual inserts3/4, zero real commit-attempt calls,
outward mutation_failed, terminal rollback, only writer_ownership bookkeeping
changes, fault-removal record/read/replay/recovery passes. Not SQL SELECT denial.
Preserve raw outcome scope, not just the helper pass flag.

C3A04: SX/sql_constraints_rs.py:25–42,62–94 supplies two result composite-FK
negatives with paired valid prefixes and exact FOREIGN KEY errors; result_unique_rs_v1.py
:53–80 supplies a sealed fresh result ref sharing valid outcome, exact UNIQUE(outcome)
rejection, nonmovement/savepoint rollback. SQL0008:157–161: PK(result_ref) makes
composite UNIQUE(result_ref,result_digest) redundant. Real writer positive passes.
Raw SQL is synthetic state, not a second legitimate terminal transition.

RS PARTIAL credit to preserve within OPEN rows:
- C3A02/03/05: fifteen other enumerated literal-SQL negatives among17 total, with
  valid-prefix positives, actual FKs/guards, correct errors and identical78-table
  baseline after rollback. Their unsatisfied unique/parent cases remain open.
- C2A19: corrected v2 physically inserts FK-valid [1,0,0,0] with bad context self-digest;
  actual record/read integrity failure and unresolved recovery; terminal unchanged
  and only writer_ownership changed. Positive is valid four-row insertion/rollback,
  not a successful real writer on corrupted state. Full damaged exact/winner remains.
  v1's all-table assertion erroneously included session bookkeeping; preserve its
  exit1 and do not count it as a candidate defect or successful probe.

Carry RC C1A01–03 checked-P1 invariant plus selected-return faults, WA-C01/02 finite
later controls, corrected cumulative account, S replan2/source3/time/admin/C4,
R connected/disclosure/fault and T SQL/route/current-owner controls at exact scope.
Do not replace stronger earlier actual stop-shape/C4 proof with a later broad label.

W suite revision SHA-256:
97e63c9e0f439c6d123a710814b5d429183111f57076c442d0d85f1bc0aefac5.
Preserve W v5: 4/99/60/9568 all passes; direct180/FULL28704 phases; direct0 warnings,
FULL exactly3 permitted B2c fork warnings; no skips/failures or noncall errors.
Ordered compact-JSON direct digest:
229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467;
FULL digest 25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9;
exact99 f242e64dd779abab8a7ff39c64a69e852524b51b85ee1d61b3f0228b0a178224.
No new suite is needed solely for registration/current admission or new probes.
M runtime hardlink FAIL and T Qs FULL failure retain original scope, never rewritten.

1.3 Exact remaining20 and state-class fixture discipline

Stable56-row inventory SHA-256:
fffc8d2f50046c1fa8df3b0f1d63c1c16348e2f628d5c07dd3d6c6d0b4bbcd56.
Current RS ledger preserves all IDs/history. Only these20 remain mandatory:
 C1B03 C1B04 C1B05
 C2A04 C2A05 C2A06 C2A07 C2A08 C2A10 C2A11 C2A12 C2A13 C2A14
 C2A19 C2A20 C2B11 C2B13 C3A02 C3A03 C3A05.

Their scope stays the exact frozen named predicate, not every imaginable combination.
Source grounding:
 graph/alias: _rw0_terminal_outcome_contracts.py:201–320;
 _rw0_terminal_outcome_rows.py:90–180; _rw0_terminal_outcome_plan.py:115–285;
 source/historical: _sqlite_rw0_terminal_outcome.py:129–207,318–445;
 routes: same :262–305; SQL: sqlite_migrations/0008_rw0_terminal_outcome.sql;
 actual terminal controller: sqlite_transition_transaction.py:1381–1467;
 private entry: sqlite_writer_session.py:6860–6866 plus actual operation/lease owner.
Bare filenames are under A/source/src/ge_nwp_coordinator.

Before each NEW fixture group, record the specific predicate, the state level it
requires, actual prerequisite keys/constraints, already available parents, missing
ones, paired positive, expected first rejecting seam and observation. This is a
small inline/internal execution plan, not a broad mapping tranche or another freeze
artifact requiring a user handoff. Construct and execute in this same engagement.

Distinguish THREE evidence levels; never use one as stronger proof than it is:
L1 — literal DDL constraint: valid actually referenced parents and enabled guards,
  fresh/unoccupied target, paired positive insertion and isolated negative. A raw
  tuple can intentionally violate the tested grammar without being an owner-valid
  terminal transition. No assertion that SQL alone enforces semantic identity.
L2 — individually checked/self-digest-valid and FK-valid row family with deliberately
  inconsistent repeated/source relations: an admitted negative fixture for actual
  read/replay/recovery. Do not call it a legitimate normal writer outcome. Insert
  freshly prepared owned rows; no guard bypass, disabled FK, or live data tampering.
L3 — source-coherent positive complete history/legitimate foreign winner: real checked
  predecessor families and required physical/semantic lineage. L1/L2 cannot replace
  L3; a second P1 by itself is not a second full terminal source chain.

Do NOT impose a second full D2 chain on every L1/L2 case. Conversely never omit a
real owner prerequisite from L3 simply because building it is inconvenient. For
additional parents construct the minimum real owner-valid prefix in fresh owned
state. Existing B P1 can serve a decision parent where that is the actual FK;
it is not a substitute for phase/Section41/C1/V22 when those are actually checked.
No new product multirun API, donor-database transplant, whole-row blind replacement,
source edits, owner-success stub, hidden validator skip, or disabled tested guard.

Concrete construction directions (PROPOSED, NOT prior executed credit):
A. C1B03 can start from the EXISTING coherent terminal subject. Manifest role/order/
   cardinality checks are command constructor :272–291; graph members are a local
   constructed list at plan :240–252, not a stored arbitrary role-list column.
   Independently derive expected canonical graph and committed digests. Test finite
   missing/reordered/duplicate-role alternatives at reachable boundaries; where
   only their digest is stored, reseal a receipt with that changed calculated graph
   digest and keep other physical constraints valid. Reach actual historical
   recomputation/receipt comparison :318–343. Verify self-digest and receipt-field
   exclusion independently, not by demanding a circular fixed point or new column.
B. C1B04 can exploit EXISTING checked parents: receipt.p1_decision_ref is repeated
   data without its own decision FK (0008:178,207–217). A newly seeded synthetic
   receipt can name RS's unrelated checked P1 decision while keeping context/outcome/
   result FKs valid and resealing its own digest. The normal reader must compare it
   with the actual reconstructed plan; prove that exact seam with paired valid state.
   This example is not whole-row closure; enumerate the genuinely missing alias
   predicates without rerunning already supported ones or inventing new matrix axes.
C. C2A19's full damaged control need not add a SECOND coherent source chain by default.
   Capture a real checked four-row plan before insertion with the established safe
   no-commit technique, then use a FRESH synthetic store state. Keep one intended
   self-digest defect and update affected child FK pairs/reseal the other rows so the
   COMPLETE [1,1,1,1] family is FK-valid and no unrelated early grammar failure masks
   the intended check. Never update immutable existing rows or disable guards.
   A valid full counterpart must pass. Distinguish exact-command and competing-winner
   probes with actual commands; no forged query occupancy or claim that a normal
   writer committed the damaged family. Observe no disclosure/repair/retry and the
   exact unresolved classification. RS's partial case remains carried partial proof.
D. C2B13 uses the existing coherent subject and actual terminal recovery controller.
   Inspect :1381–1467, especially rollback-resolution :1423–1424, lease close
   :1440–1449 and recovery outcome :1457–1463. Inject at the precise real seam with
   counted hit and no hidden retry; remove fault for a normal positive. Do not assume
   legacy generic recovery coordinates are the terminal call path. C2B11 similarly
   targets the actual in-memory lease validation, distinct from already proved closed
   session or durable issuance. No second semantic source chain is a default prerequisite.

For remaining C3A02/03/05 and physical C2A routes, list actual UNIQUE/FK columns and
which valid parent identities must differ. Preserve all17 RS SQL controls, including
C3A04 already closed. Reach only the missing constraints, with paired actual positives
and exact SQLite error/site. Identify redundant composite uniqueness by exact proof,
not by demanding impossible isolated duplicate-PK insertions. For routes, raw query
occupancy is physical only if actual SQLite rows exist and checked _one is reached.
Complete-family field equality is not automatically a DDL constraint on inconsistent
partial/foreign rows. Named FK-valid implications may delimit child-first cases;
state the excluded FK-invalid scope explicitly.

A full second phase/Section41/C1/V22 chain may be needed for particular L3 specimens
or genuinely distinct physical parents. Derive an audit-owned finite builder from
actual owner contracts/call sites, accept the existing store only where supported,
use distinct typed identities and bottom-up digests, and record all actual guarded
owner writes/reads. Retain original transient operands. Do not turn the hardcoded
one-shot convenience D2 wrapper into product multirun implementation. If its wrapper
is unsuitable, inspect the owning lower-level APIs instead of declaring impossibility.
If a real owner prerequisite/contract blocks construction, retain exact command,
state, error and source implication, then continue independent ready predicates.

1.4 Dependency-aware work order and stopping discipline

After current-source/layout authentication and one small admission readiness if
needed, begin a genuinely OPEN predicate. Recommended order:
 1. C1B03, C1B04 and C2A19, using existing checked chain and fresh paired negative
    state as above; C1B05 only missing associations beyond carried source3.
 2. C2B11 and C2B13 with exact lease/controller fault evidence, not broad session resets.
 3. Remaining C3A02/03/05 predicates already reachable with current parents; do not
    repeat completed17 cases instead of their missing unique/FK relations.
 4. Actual missing parent-prefix construction for the remaining ten route IDs and
    C2A20; use exact implication where justified. Reuse this finite fixture across
    genuinely dependent cases, preserving isolation and per-predicate reach.

All twenty remain acceptance requirements until properly closed; the ordering does
not narrow them. Save/reopen internal checkpoints as completed groups advance;
there is no routine user relay. One unfinished parent fixture is not a global stop
for graph or lease/cleanup work. Continue other safe independent cases when a fixture
needs further ordinary correction. No subagents, concurrent writers or parallel
unsafe operations are authorized.

Close only with actual independent expectation + valid positive + reached negative
or precise scoped invariant + result/nonmovement/disclosure binding. An exit0,
green full suite, earlier mixed-column occupancy, or generic ValueError alone is
not the missing proof. Preserve raw failures and actual reached earlier predicates.
If a practical limit prevents completion, retain code and the actual attempted
construction, exact reason, last successful checkpoint, and independent cases still
possible; do not rebrand an unattempted fixture as an authority or architecture block.
A material candidate defect, unsafe runtime, failed admission, source drift or true
authority conflict still stops the affected work with the correct classification.

2. SUBSTANTIVE REVIEW — THE EXPLICIT TWO-LAYER AMENDMENT

The earlier whole-operation zero-current-stop-SELECT criterion failed under the
old mandate. That blocked result remains true. The engineering decision is to
preserve mandatory shared storage safety, not to skip it to satisfy a terminal
history test. The current candidate is judged against the following amendment:

Layer 1: existing operational admission remains mandatory. Session/process/thread/
lease validity, database binding/custody, BEGIN IMMEDIATE, exact managed schema,
history/catalog/posture and invariants, writer ownership/fencing, and current
protected disclosure remain intact. The existing global_stop_current singleton
shape validator may read that current row only for managed-store validity.
Valid active/clear status, version, timestamp and directive identifiers must not
be compared with saved terminal stop or turned into current effect permission.
Denied/unreadable/malformed managed state may prevent disclosure or leave recovery
unresolved. It must not be misclassified as stale terminal history or definitely
absent original execution. No cache, successful-assessment stub, invariant-skip
flag, alternate connection/controller, or production validator weakening.

Layer 2: historical checked read, receipt-present replay and recovery use saved
full postimages/stop and checked immutable predecessors after admission/fencing.
The five current-head tables are not consulted during the historical operation.
Current-stop reads are permitted only at the existing shared invariant check,
not as a general table-read exemption or later semantic terminal query. Receipt
is first TERMINAL-FAMILY lookup, not first SQL statement. Exact original result,
time, graph, receipt, source associations, protected disclosure, immutable
acceptance binding, complete competing-winner/absence proof and uncertainty
classifications remain required. Historical operations do not require recording
permission or renewed acceptance-unclaimed eligibility. Fresh receipt-miss
recording retains actual current five-head/stop checks unchanged.

This amends only the overbroad current-stop-query requirement. It is not a waiver
of the constructor defect, five-head independence, disclosure, SQL grammar,
transaction safety, audit isolation, or other cumulative acceptance controls.
Verify the two owning documents state the distinction and preserve the old
failure as history; do not create another silent interpretation of either layer.

Inspect at minimum the complete changed witness module, changed tests and docs,
full terminal contracts/rows/plan/SQLite owner, and actual shared admission call
chain (not only wrapper names). Current anchors:
  sqlite_transition_transaction.py:2759–2779,4753–4773
  sqlite_migration.py:2477–2523
  .docs/rw0-terminal-outcome-physical-closure.md:177–220
  .docs/sqlite-operations-and-recovery.md:722–730.
Python basenames are under source/src/ge_nwp_coordinator/; docs under source/.

2.1 Independently test the repaired constructor and mutable aliasing

TerminalHeadWitness at _rw0_terminal_head_witness.py:48–96 must validate ordinary
construction, not only checked factories. Independently test valid direct/factory
triples for accept and replan and all five typed owner roles (8/9/41/9/8 fields,
valid nulls, self-digests). Exact bytes, outer tuples, dictionaries, keys and
scalar types precede hostile comparison/coercion. Bytes, full rows and compact
coordinates must match rather than silently replacing invalid supplied parts.

Require negative controls for the previous malformed type triple and b'{}'/empty
postimages, bytes/list/tuple/dict/string/int subclasses, bool-as-int, wrong arity,
missing/extra/reordered roles or fields, wrong schema/digest, noncanonical and
oversize bytes, and valid canonical bytes paired with DIFFERENT valid rows or
projections. Calibrate a shared/per-instance hostile equality counter, clear it,
and verify zero hostile calls per invalid construction. Preserve built-in
positives and process-control propagation.

Mutate caller-owned maps and separately returned maps, then re-read both views
and canonical bytes and run normal downstream verification. They must remain
checked and unchanged. No unvalidated object token/factory escape or recursion.
Do not demand security against arbitrary reflection/object.__setattr__; that is
not the selected boundary. Verify unchanged wire fields/schema/digest domains
and valid consumer behavior, including exact original P1 replan operands.

2.2 Independently prove complete-operation phase behavior

Use real private WriterSession read, receipt-present record/replay and recovery,
not just a terminal helper. Trace and attach observation/denial at the actual
acquisition/controller opener aliases and account for every operation connection.
The candidate observer labels the full managed wrapper; independently establish
which SQL is genuinely in _verify_global_stop_current_shape. A phase label alone
does not prove shape-only use or permit arbitrary managed-phase stop semantics.

Observe real unchanged validator, ownership-read and issuance/fencing functions;
observation wrappers must call the real function and return its actual result.
Do not replace admission with a successful assessment or patch the predicate
being proved. Capture connection, phase, table/column and allow/deny results.
Calibrate each attached authorizer with owned allowed and intentionally denied
queries. Trace acquisition separately, including any connection work before the
observer attachment, and prove it cannot hide a five-head/later-stop lookup.
A zero-callback claim at the wrong alias is invalid. Column callback counts are
not SQL-statement counts or a fixed product invariant.

Required current-byte controls:
- real fenced accept and replan commits, then coherent later movement of every
  head and valid active/clear stop fixtures; under the layered denial policy,
  exact read/replay/recovery preserve original result/time/witness/graph/receipt
  and acceptance facts without new terminal or protected-row movement;
- original absence with positive/negative old-execution exclusion; complete
  compatible and incompatible competing winners under that same policy;
- deny the ACTUAL managed-stop read during admission: safe operational refusal
  before protected terminal-family handling, recovery unresolved where the
  unchanged controller so classifies; no no-write mislabel as stale history,
  definite absence, hidden retry, committed result or protected disclosure;
- malformed actual stop row or real query-return tuple, with validators intact:
  integrity failure rather than ordinary currentness; fault removal restores
  valid operation; bound process-control behavior remains unchanged;
- fresh receipt miss reads all five actual heads and stop. Stale expectations
  conflict without writes; correctly expected valid changed stop follows the
  current normal-record rule without conferring executable permission;
- denied/expired/foreign/malformed disclosure, closed/stale/fenced session and
  unavailable managed store remain non-disclosing. Fresh recording permission
  stays separate from historical protected disclosure and stop shape.

All synthetic later states/fault seams must be described as such. Do not call
a direct fixture UPDATE a newly supported product operator transition.

3. COMPLETE CUMULATIVE A01–A18 REGISTER AND CAUSAL OBLIGATIONS

Review the entire baseline-to-current terminal change, not only the five-file
repair. Supply exact archive-relative source/doc/test/SQL coordinates, severity,
and evidence class for every row: contract/current code, inspected test design,
retained record, independent execution, inference or limit. Unchanged bytes and
prior passes do not automatically discharge current mandatory controls.

A01 Authority: exactly five private normal terminal facts, separate from P1
 decision/acceptance, standing-policy grants, source facts and executable
 permission. No cancel closure, live supplier/contact, ES/Bridge/Git effect,
 service/scheduler/autonomy or publication authority.
A02 Preservation: legacy terminal V1/four validators, P0/P1 meaning, WorkSpec,
 Decision Basis/command-digest v2, preassignments, D1/D2, generic receipt, public
 StateStore/package exports unchanged. Audit original shared catalog/controller/
 writer-session terminal integration even though this immediate repair froze it.
A03 Grammar/types: closed command/context/outcome/row/result/recovery/witness
 schemas, exact built-ins before equality, canonical UTF-8/JSON and duplicate
 rejection, bool-as-int, safe refs/digests/calendar time, budgets and null pairs.
 Include direct constructors, factory consistency and aliasing; resolve A03/O1.
A04 Identity graph: independent domains/acyclic preimages, four sibling refs and
 route, optional assertions bound in command digest but not preassignments,
 graph role/cardinality/order, self-digest exclusion and repeated-column equality.
A05 Original operands: original P1 command and private replan operand transient;
 complete checked predecessor association required. Missing/inconsistent private
 content cannot be reconstructed from a safe digest or yield false certainty.
A06 Source association: actual checked P0/phase/Section41 A/C1 rank15/V22/P1
 chain and validation/review/proposal/result-set/observation relationships;
 membership counts or digest strings do not independently establish ownership.
A07 Acceptance: bind existing immutable acceptance only for accept; never create,
 mutate or replenish it. Wrong/missing/foreign facts reject. Legitimate unrelated
 facts must coexist without preventing another allowed terminal branch. No
 historical acceptance-unclaimed recheck.
A08 Heads/stop: observed full five-row witness, source/adapters/digests/links,
 replan historical P1 postimages, fresh actual currentness and stop facts; prove
 the precise two-layer amendment, not the withdrawn zero-stop-read property.
A09 Transaction: existing fenced lease/capability/controller; receipt-first
 terminal lookup; one captured time; protected posture/source/current/route
 ordering; context/outcome/result readback, receipt last, capability invalidation,
 one commit attempt, rollback/cleanup uncertainty. No application-head/stop/
 decision/effect update by terminal closure.
A10 Read/replay: original complete result/time/graph/receipt and source/witness
 reauthentication; current protected disclosure with mandatory store admission;
 no five-current-head or later semantic stop query, cognition/process rerun,
 fresh recording permission or acceptance-eligibility requirement.
A11 Recovery: complete exact original family or exhaustive original absence and
 exclusion, or complete compatible winner, only. Partial/foreign/damaged/aliased/
 incompatible families unresolved. No winner result disclosure, hidden retry,
 fragment repair or durable private-template fallback.
A12 Error/cleanup: failed or malformed reads stay operational/integrity, valid
 actual drift stays currentness. Stale/closed/fenced sessions, pre/postcommit,
 applied-commit/lost-return and cleanup uncertainty, KeyboardInterrupt/SystemExit/
 GeneratorExit propagation at the actual fresh/read/recovery/cleanup seams.
A13 Schema/admin: four STRICT immutable normal-only tables/eight guards;
 timestamp grammar, FK/unique/composite links/phase/decision/route occupancy,
 nullable pairs, blob bounds, zero seeds, current catalog/checksum/generation 2;
 exact fresh/prefix migration and old-binary/obsolete-0008/partial/unknown refusal.
A14 Connected normals: actual preseal source variations through real P0/D1/D2/
 Section41/C1/V22/P1/terminal owners; five distinct normal positives and detached
 negative; read/replay/recovery and no forbidden contact or protected-row change.
A15 Docs/assurance: cumulative current-versus-historical status, explicit amendment
 and private scope; fixed source/hash/AST/import/schema consumers and predecessor
 reconstruction retained; no dynamic oracle, skip/xfail or broad guard stripping.
A16 Privacy/artifacts: complete postimages remain safe owner metadata; no private
 replan text, raw capsule/prompts/process results, handles/PIDs/credentials in
 terminal rows or unsafe errors. Grammar review plus independently observed
 canaries; classify raw-index metadata, checkpoints and failed artifacts.
A17 Retained evidence: exact input/source/patch/commands/env/observer outputs/
 JUnit/IDs/warnings/captures and overlapping counts; limits in section 4 below.
 No writer record or causal-register label is independent execution.
A18 Independent validation: reached current-source causal probes and direct
 suite, independent SQL/admin controls, selector-free collection/FULL completed
 with exact IDs, outcomes, warnings and source-mode preservation. No live-state
 or production-readiness inference.

The following controls remain mandatory, including previously unfinished ones:

(a) S01 full-witness family: for EACH role, check complete field capture, valid
 nullable values, supported maximum witness bound, bad owner self-digest, valid
 self-digest with wrong immutable predecessor, wrong owner/link, and actual fresh
 head movement versus changed caller expectations. Use fully resealed synthetic
 histories so owner/context/outcome/result/graph/receipt digests are internally
 valid and the real relationship predicate is reached. Pair every resealer with
 a valid family built the same way. Restore ordinary verification for the actual
 read/replay/recovery. Prior program-only evidence is not five-role proof.
 No truncated witness, v1 fallback, desired-row synthesis or current-row backfill.

(b) Source/operand/acceptance: fully resealed detached validation, review,
 source-invocation and proposal associations, including a DISTINCT forged V22
 proposal reference rather than only a proposal digest; wrong/missing/foreign
 acceptance; LEGITIMATE unrelated acceptance-fact coexistence; inconsistent
 private replan content sharing a claimed safe identity across record/read/
 replay/recovery; no new process or private-text persistence. The single-chain
 fixture's inability to construct an unrelated fact is not proof of impossibility.
 Build coherent independent synthetic state through checked owners, or document
 exact invariant proof and the remaining limitation. Do not credit an incoherent
 split-reader or early FK/digest failure as the intended relationship test.

(c) Disclosure/recording: all selected finite posture predicates, including
 positive, denied, expired, malformed, foreign-bound and absent protected subject;
 old-execution-excluded True/False; truthful claimed False/None after accepted
 P1. Fresh write needs recording AND disclosure, historical operations disclosure
 only; command reuse/assertion mismatch cannot disclose a protected result.
 Complete the expired/malformed/foreign/protected-absence matrix rather than
 inheriting earlier positive/negative permission examples.

(d) Physical routes: derive all original occupancy routes from the checked
 code (the preceding audit identified 17). Seed EACH route physically in a
 separate owned coherent scenario, with valid positives and relevant partial,
 foreign or damaged family states. Mocking query return values alone is not
 physical occupancy evidence. Check exact/winner/absence classifications and
 no winner disclosure or retry. If a route is not representable under an owner
 invariant, prove that with exact schema/contract and record the scope; do not
 invent an invalid row as a legitimate winner or silently drop the obligation.

(e) Transaction and error matrix: faults after each of the four inserts,
 result/receipt readback, receipt-last boundaries, precommit rejection,
 one applied commit with lost return, postcommit and recovery cleanup uncertainty;
 stale lease/issuance, closed and fenced sessions; actual denied SELECT versus
 malformed selected rows across current owners; all three process-control
 exceptions at meaningful fresh/read/recovery/cleanup seams. Assert target
 rows, committed bytes, protected-state nonmovement, and actual injection hits.
 No hidden second commit or automatic retry.

(f) F01/O1 regression: independently exercise raw SQL and row construction,
 not only planner success. Use otherwise valid parent/related state, paired
 valid inserts, independent negative self-digests and the repaired existing
 _time owner. Cover invalid month/day/leap-century/year-zero/time overflow,
 canonical-format deviations, Unicode digits, embedded NUL/whitespace/nontext,
 NULL handling and valid year endpoints. Reach all three recorded_at columns;
 outcome has no timestamp. Verify failed predicates are zero/not permissive
 NULL and high-level invalid row/time behavior stays integrity/unresolved.
 Reproduce the old invalid-month predicate only in owned predecessor synthetic
 state as a grammar comparison, never claim an ordinary writer exploit.
 Recalibrate O1 independently before claiming no hostile equality calls.

(g) Five connected normals plus three unsupported cancel shapes and unsupported
 profile. Source variations occur BEFORE real artificial worker/checker/capsule
 sealing, not by relabelling passed evidence afterward. Use inspected fixtures
 for setup only; independent expected branches/facts/errors are required.
 Observe artificial local process/contact limits and privacy canaries.

Run bounded causal controls before a long FULL launch. Do not start/continue
FULL while a known material blocker already prevents acceptance. Independent
controls must state setup validity, actual reached seam, expected result/no-write
predicate, source identity and limits. Candidate tests passing are not separate
independent oracles. Any mandatory control not established remains explicit and
prevents complete acceptance unless an exact supported invariant makes the case
inapplicable; fixture difficulty alone is not such an invariant.

Independent SQL/admin expectations:
  after 0006: 68 tables / 122 triggers / 5 explicit indexes
  after 0007: 74 / 134 / 5
  after 0008: 78 / 142 / 5, application generation 2.
Execute all eight authenticated literals in disposable owned state. Preserve
pre-0008 object SQL/shape; check exact prefix upgrades, no seeds, immutable
update/delete guards, FK/unique/pair/profile/normal/blob/time constraints, and
refusal of old binary, original and S01-era 0008 checksums, old SQL with current
history, missing guard, foreign object and partial/unknown/checksum divergence.
No current schema/contract change, 0009 or product database upgrade is allowed.

4. RETAINED EVIDENCE AND INDEPENDENT VALIDATION

4.1 Reconcile the current writer records as DATA

Paths: evidence/validation/<direct|connected|focused|full>/, gate-summary.json,
phase-read-map.json, supersession-record.json and current source captures.
Require independent parsing of collection observer, execution collection,
setup/call/teardown records, explicit JUnit nodeid properties, actual launch/exit,
stdout/stderr as actually retained, warnings, and four complete source captures
per gate. Do not invent a separate stderr file for a combined log.

Expected current retained gates:
  direct: five complete modules / 60 cases / zero warnings
  connected: one complete module / six cases / zero warnings, inside direct
  focused: 126 complete modules / 8,266 cases / three known warnings
  FULL: selector-free / 9,568 cases / three known warnings.
All narrower sets must be included in FULL; totals overlap and do not add.

Ordered-ID SHA-256 uses UTF-8 JSON array, ensure_ascii=False,
separators=(',', ':'), with NO trailing LF:
 direct 229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467
 connected 81e14e3fa1b85a7be2ea6fafac85974839145bbcb6397e6da0bb1feeba060aac
 focused 419d37ff399689788123583f614a1d8b107ef712e2368ca179cd6e65fbec5104
 FULL 25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9.

All sixteen source captures have the same 105,550-byte envelope, SHA-256
0c0b4017371a798731a63825ac63922c361189e37f5a713f5c4f7ec06e9b32cb.
Require full row equality to the different canonical source-manifest envelope,
its embedded canonical hash, correct final tree and no extra/missing paths.

The retained direct JUnit phase maps report six operation connections, 60
managed-stop column callbacks and six intentional head-denial calibrations
for EACH accept/replan scenario. Independently parse the raw properties. Do not
substitute those counts for actual phase/call-chain verification, or label them
SQL-statement counts. Acquisition has separate test observations.

4.2 Known retained-evidence limits — do not silently fill them

The active external gate_observer source and a launch-bound helper digest are
not retained in the current outer ZIP. Old nested helpers cannot prove that
current code's identity. Writer records can be internally reconciled but their
observer's nonselecting implementation is not thereby inspected. The independent
runs below must use newly audit-authored, retained, inspected and calibrated
observers. Independent fresh evidence can establish current behavior; it does
not retroactively establish the missing writer helper.

The seven-case checkpoint has receipt/JUnit evidence and a different declared
tree 85c9fea24f4f74f358f9cc59a5d323d836a04041; it lacks a complete checkpoint
source payload here. Its historical save/reopen/source-binding claim stays
qualified and supplies no final-byte credit. Similarly, one retained patch
manifest per kind is not proof of two writer runs; independently reconstruct
current endpoint/patch identity rather than invent that history.

These are disclosed retained-evidence/process limits, not automatic production
findings. Determine their actual acceptance impact. Complete current independent
source/runtime evidence must not be replaced with writer claims. Any unmet
mandatory evidence requirement is INCOMPLETE, not a pass by wording change.
Preserve failed/superseded source/test results separately. The prior audit's
live-status/path probes and interrupted FULL remain historical limits.

4.3 Required independent execution gates

Under the explicit prospective section 1.3 scheduling amendment: after current
source inspection/reauthentication, exact final QtcM readiness and observer calibration,
and with no known material candidate defect or unsafe dependency, execute these
complete regression gates BEFORE additional residual custom-fixture work.
All outstanding causal/admin obligations remain required for final ACCEPT:

1. On a fresh exact source copy, collect and run these five COMPLETE modules in
   this order (no node selector):
   tests/test_rw0_terminal_outcome_values.py
   tests/test_rw0_terminal_head_witness_regression.py
   tests/test_sqlite_rw0_terminal_controls.py
   tests/test_sqlite_rw0_terminal_migration_0008.py
   tests/test_sqlite_rw0_terminal_connected.py
   Expected 60 ordered unique passes, including six connected cases.
2. On another fresh exact 327-file copy, independently collect and run the
   repository selector-free FULL. Expected 9,568 ordered unique IDs and passes
   in the retained FULL order. No path, module, node, -k or -m selection.
3. Record collection/execution-collected/call/JUnit identities, explicit JUnit
   nodeid properties from the start, all setup/call/teardown results, warnings
   and real process exits. Require exact ordered agreement and zero failure,
   error, skip, xfail/xpass or failed noncall phase. An invertible JUnit mapping
   is useful supplementary evidence, not a silent substitute for the required
   explicit-property observation.
4. Independently inventory warnings. Direct has none; FULL may have only the
   three known DeprecationWarning multithreaded-fork nodes in
   tests/test_sqlite_b2c_writer_session.py:
   test_operation_guard_close_waits_and_retains_authority_until_exit
   test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
   test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock.
   Owned paths/PIDs may differ; other class/node/message differences require
   investigation, not filtering or suppression.
5. Capture complete raw bytes/modes/extra-file inventory immediately before and
   after collection AND before and after execution, with source-tree rebuilds.
   All 327 endpoints and modes must remain unchanged. At every boundary capture there must be no generated extras; only the prospective, exact-path transient fixture exception in section 5 is allowed during the inspected D1 test.
6. Audit probes remain outside candidate discovery and separately counted. An
   independent focused 8,266-case rerun is unnecessary if exact FULL inclusion
   is proven; do not claim one ran. No writer FULL or earlier audit count can
   replace the independent completed FULL.

Use recorded equivalents of:
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --collect-only --basetemp=<owned-collect> <complete-direct-modules>
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --basetemp=<owned-run> --junitxml=<owned-junit> <same-direct-modules>
For FULL remove all module/path/node selectors from BOTH commands. Inspect
pytest config, conftest and setup/child-launch seams before import. The observer
may record IDs/outcomes/warnings and add JUnit nodeid properties, but must not
select, reorder, skip, change assertions/results or suppress warnings. Keep its
exact source/digest in the evidence and bind every launch to it.

Do not edit candidate source/tests to get green results. Correct audit-only
parser/fixture/observer mistakes transparently on fresh owned state, retaining
failed attempts. A genuine candidate failure triggers findings, not retries with
weakened oracles. An interrupted FULL gets no complete-pass credit; preserve
actual partial records and absence of final JUnit/observer rather than infer
completion from displayed percentages.

5. PRESERVED RUNNER, CURRENT ADMISSION AND RESIDUAL EXECUTION

No missing general qualification tranche remains. This section preserves the actual
admission/effect boundary; it does not order repetition of supported W/RC controls.
WA-C01 and WA-C02 carry forward at their exact measured scope. Registration-only
new fixtures need current authentication/admission and limited readiness, not the
whole old suite or all previous synthetic controls.

5.1 Layout, preserved files, and fixture lifecycle

ROOT is exactly:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz
Existing source copies:
 ROOT/mock_source/tc-4fd7e168a0/{master,causal,direct,smoke,full}
Existing immutable policy:
 ROOT/execution/md-812d7d86be/QtcM.sb
Source/test W exceptions, and NO other source write slots:
 ROOT/mock_source/tc-4fd7e168a0/smoke/src/ge_nwp_coordinator/_rw0_d1_probe_temp.py
 ROOT/mock_source/tc-4fd7e168a0/full/src/ge_nwp_coordinator/_rw0_d1_probe_temp.py

Choose one fresh unique rt-<nonce> suffix under ROOT's existing execution/scratch/
home/tmp/evidence/denied and, for noncandidate calibration sentinels only,
mock_source. Preserve every W helper/revision/report/source copy; do not overwrite
a historical path, link-copy, rename old output into the new protected namespace,
or clear an unexplained object. New probes remain outside candidate test discovery.

Reuse the five active source copies only after full current-byte/mode/extras and WA1
checks. A present mismatch is a binding stop, not authorization to repair or reset.
If a required copy is absent, independently recreate from authenticated A into the
same previously permitted slot, exclusive/no-follow with the recorded modes and no
hardlinks; record that as new copy custody, not historical preservation. New
provisional DB/process/output state is always in freshly owned writable locations.

RS cleanup removed only its approved prospective calibration fixtures. The exact two already
authorized immediate-root metadata fixtures may be recreated after lstat proves
absence and the ten preserved root members authenticate:
 ROOT/rw0_meta_plain_md812d7d86be.txt
 ROOT/rw0_meta_dir_md812d7d86be/inside.txt
Use exclusive independently created safe non-code regular bytes, owner-private modes,
new dev/ino/nlink/hash records, and no source/test/config names. No new immediate root
entry. Record the new twelve-entry census and freeze its identities in the NEW
runner binding; never overwrite W's original root-preparation record or claim
the old fixture inodes were restored. Unknown present fixture/type stops.
QtcM's bytes and exact permissions remain unchanged.

5.2 Enforced WA1 invariant; no relaxation of trusted preparation

Before EACH actual launch, inventory the entire artificial owned root, not only the
new namespace. The writable footprint is ALL scratch/home/tmp, including old
reachable namespaces, plus the two exact W slots. Protected audit regular files
are all remaining source/helper/evidence/denied/root files.

Require:
- ordinary owned protected regular files, nlink1 and distinct nonzero dev/ino;
- no protected identity reachable through the writable footprint;
- closed regular-file hardlink groups within that entire writable footprint, with
  path count equal to nlink and an explicit audit origin for preexisting files;
- immutable current source/helper/policy/runtime bindings and expected root membership;
- no source/evidence/protected descriptors inherited by the workload;
- the sole trusted supervisor introduces no protected-to-writable alias and no
  concurrent protected preparation mutation while a workload runs.

A protected nlink>1 cannot be excused because its other path is not found in the
new suffix. Reject; no host-wide alias search. Same-byte distinct files must admit.
Directories are not subject to the regular-file nlink1 rule. Known internal writable
hardlink/symlink fixtures created by unchanged tests are not product defects, but
must be classified and group-closed after child closure. Unknown preexisting
writable aliases/data cannot be admitted solely because their UID matches.

Authorized supervisor census is bounded no-follow metadata only inside ROOT's
seven existing subtrees and immediate regular files/two W slots: <=100,000 entries,
depth<=64, no mount crossing or directory-symlink traversal. Fresh descriptor-relative
stat/readlink/identity checks, with active-path ancestry bound to ordinary directories,
not cached path strings. No recursive content reads or scans outside ROOT.
Protected content reads remain limited to named inputs, active source/helpers/
policy, selected carried evidence and synthetic targets.

Existing guard code and policy are trusted only after source inspection and current
identity checks. Use one actual launch_if_admitted path. Known contaminated layouts
must emit refusal before target spawn/candidate import. Do not call an isolated
checker while leaving a bypass route to actual sandbox-exec.

The root expectation and new probe registry are new bindings, not new accepting
semantics. Namespace/registry-only revisions must retain a complete exact diff
against RS's inspected wa1_gate_rs_v10.py algorithm, frozen helper maps, source/expected-root
identities and runtime. No code import from a mutable helper path. Do not overwrite
the v5 revision to pretend it included later probes.

RC's rejecting-only early metadata refusal, retained in RS, is already implemented and supported.
Preserve it; no new algorithm correction is requested or authorized by default.
Changes may register immutable new probe/helper/fixture identities and the owned
namespace only, preserving clean admission, rejection, copying and closure logic.
A newly established substantive gate defect requires explicit impact assessment
and a precise stop, not silent weakening or a new runner platform.

5.3 Current readiness and repeat decision

Inspect the RS gate/revision/source before deriving a new audit-owned registration.
Retain exact diff, old/new helper bytes, namespace and source/root fixture identities.
Preserve the RC rejecting-only correction already carried in RS without adding an accepting branch or changing QtcM.

Before new candidate work:
1. Authenticate RS/A and required carried evidence; verify the actual complete owned
   layout, source copies, empty W slots and recreated permitted root fixtures.
2. Freeze the new immutable probe registration and full active binding. Run one small
   clean marker/SQLite readiness through the actual admitted launch path if current
   layout/revision needs it. Distinguish readiness from candidate proof.
3. Use targeted controls only for a specifically changed execution assumption. Do not
   automatically repeat the four-role matrix, hardlink suite, active-helper negatives,
   representatives/fixed99 or direct/FULL. Every candidate launch still performs
   mandatory WA1 and source before/after/closure checks.
4. Correct ledger attempted-versus-reached fields and begin the genuinely open groups
   in section1.4. No qualification-only closeout after readiness succeeds.

W's regression remains source/revision-bound history. RC supplements, preserved in RS, establish the
later finite assurance scopes; they never become events in W's earlier interval.
If the accepting path, candidate bytes, policy or runtime truly changes, or evidence
shows a historical admission/preservation flaw, explicitly identify the invalidated
results and required revalidation. Preserve the original record. Registration-only
changes or a new synthetic probe name do not automatically invalidate old suites.

5.4 Candidate residual execution

Fixed interpreter entry:
 /Library/Frameworks/Python.framework/Versions/3.13/bin/python3
Expected Python3.13.4 / pytest8.4.1 / SQLite3.49.1. Rehash requested/resolved/native
runtime and the exact selected /usr/share/terminfo/64/dumb resource at named bindings.
Their retained host identities are not supplied executable payloads. No runtime
replacement or new terminal lookup permission.

Actual candidate launch, always admitted:
 /usr/bin/sandbox-exec -f <exact-QtcM> <fixed-python> -I -B <frozen-audit-probe-or-bootstrap> <mode>

Explicit owned cwd, umask077, core limit0, null stdin, close_fds=True, pass_fds=(),
credential-free environment allowlist, C locale/UTC, owned HOME/TMPDIR/basetemp/output,
PYTHONDONTWRITEBYTECODE=1, PYTHONNOUSERSITE=1,
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, PYTEST_ADDOPTS="", -p no:cacheprovider where pytest
is used. No ambient import roots. Bootstrap adds only authenticated candidate
root/src/tests as needed and frozen read-only probe/observer roots. Candidate
children retain their existing unmodified source-specified arguments and environment.

Ordinary audit-only fixture/parser/observer errors may be corrected in new versioned
files and fresh owned state. They are not candidate defects unless the actual owner
contract fails at a properly reached predicate. Retain the failure and correction;
do not weaken the expected result to get a pass. All product path faults must reach
the real owner/controller with counted injection and ordinary fault-removal positive.

Do not reproduce W's unnecessary qualification repetition for every probe revision.
An added immutable probe body, no change to admission/transfer/runtime semantics,
and an exact registered digest requires static inspection and actual current
admission/closure, not another full suite or all forty boundary controls. Bind each
probe's actual helper revision separately. The old v5 suites remain v5 runs.
No silently changing dispatch code after launch or retrospectively assigning the
final helper's bytes to an earlier digest.

Freeze complete expected identities and error/recovery/nonmovement predicates before
execution. Use exact built-in/type/graph/row relations; do not infer whole-family
failure from an unrelated first rejection. For a raw-SQL synthetic partial state,
record that it is an audit fixture and not a supported production transition. Keep
FKs/immutable guards active for the constraint being tested. Never use fake query
returns as physical occupancy or a product validator bypass to manufacture success.

Observe all phases, selected causal IDs, raw outcomes and warnings without selecting/
reordering/altering candidate results. Causal selections are labelled as causal,
not FULL. Standalone assertions emit exact independent expected/actual records.
Observer source and bootstrap/plan/gate/policy/fixture digests must bind every launch.

Capture all327 bytes/modes/extras before and after each candidate import/causal
execution group as required by the invocation, with exact source reconstruction.
Admission inventories supplement, never replace these captures. Existing W slots
may appear only for the previously inspected unchanged D1 test, not arbitrary
audit-source writing; both must be absent at every boundary capture.

Track actual owned children, groups, sessions and bounded waits. Emergency cleanup
touches only owned tracked subjects and never counts as candidate cleanup success.
Observe closure before publication; state initial-group/known-child limits without
a universal unknown-descendant claim. Do not continue after known source drift,
material candidate defect, unsafe dependency or invariant/containment violation.

5.5 Evidence publication, preservation and cleanup

Only newly and independently created protected records are written by the supervisor
during a workload, not protected alias installation or provisional-file promotion.
After observed closure:
- recheck full source, protected identities/link counts, root membership and mutable
  group closure; retain any failed postcheck without acceptance credit;
- read provisional data through no-follow ordinary-file descriptors bound by fstat
  around the bounded read; reject unsafe type, unstable identity, protected alias or
  unclassified symlink/special return;
- independently write exclusive no-follow protected destination bytes; never rename
  or hardlink mutable output into evidence; record different identities/nlink1 and
  equal bytes/hashes;
- retain true stdout/stderr, actual return codes, timeouts and every failed attempt.
No sanitized text is called raw evidence and no in-process output self-certifies
an adversarial result. No raw private templates/capsules, credential values,
unclassified databases/sidecars or executable outputs in delivery.

A new helper may retain records under the new protected namespace with fixed limits,
without scanning unrelated content. Existing historic source/evidence remains intact.
After current evidence protection remove only exact newly owned transient objects,
with recorded identities and classifications. Unknown old paths are not cleared to
satisfy admission. Recreated root fixture instances may be removed only after identity
and byte checks; record the return to ten old entries, not persistent readiness after
fixture removal. Future re-entry must establish new fixture identities again.
6. CUMULATIVE ADJUDICATION AND DELIVERY

The sole subject is 4691af58ae0ee3107b4e2e9b6b1508032944e357. Preserve RS seven scoped
closures, RC three selected-fact closures/WA supplements, W v5 suite passes and all
valid earlier causal evidence. Old blocked/incomplete/failed intervals keep their
truthful scope. No current candidate acceptance or commit gate follows from this task
unless EVERY mandatory requirement is actually supported and the exact accepted
disposition is issued; that disposition still authorizes no live commit or publication.

Produce corrected A01–A18 and all56 stable residual rows. Each predicate distinguishes
carried independent execution, new execution, source/DDL implication, writer/data
records, historical evidence gaps and mandatory unresolved scope. Do not assign
blanket gaps to every row or erase partial proof when a larger row remains open.
Separate fixture attempted, exact predicate reached, and complete predicate closure.
Every closed row binds source/helper/policy/admission revision, independent expected
result, paired setup, actual seam/hit/output/nonmovement/disclosure and limitation.
Specific lineage or FK-valid-state assumptions are retained, never generalized.
The proposed fixture examples in section1.3 earn no credit until executed/adjudicated.

Disposition options:
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED
 AUDIT_PROVENANCE_MISMATCH
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE

ACCEPT requires exact candidate/modes, compliant effects, supported composite WA1+
QtcM with declared trusted-host limits, complete substantive A01–A18/F01/O1/S01/A03/
two-layer proof, and supported complete regression evidence carried under the explicit
repeat rule or genuinely required replacement execution. No mandatory case becomes
nonblocking by wording. F03/F05 and historical provenance gaps retain original scopes.
Candidate failure => BLOCKED, no audit-side repair. Runner/binding/authority/evidence
limit => precise INCOMPLETE, with impact on carried proof stated, no automatic redesign.

Write full report BEFORE sealing ONE evidence ZIP. Include exact RS ONCE (it carries
RC/W/M/U/T/S/R); no A source/history duplication or additional ancestor copies.
Include current source/input authentication, policy and admission revision/diffs,
all new versioned probe code and expectations, actual raw launch/phase/outcome/warning
records, source/identity/closure/publication captures, all56 corrected ledger rows,
exact20 predicate dispositions, failed/superseded attempts and cleanup/non-effects.
Do not discard real observations to shrink the bundle or duplicate snapshots only
for filenames. Index exact immutable included records where already present.
No filesystem-hardlink deduplication, private templates/capsules/credentials, unclassified
DB/pyc/special-file payloads or mutable output masquerading as executable authority.

Next outer limits: <=2000 regular members, <=128MiB/member, <=256MiB expanded. The
one exact66,432,954-byte RS member is expected. These are bounded archive-capacity
limits only, not runtime permissions. Preserve nested bounds/cached identities above.
Verify safe names/types/coverage and every size/hash/CRC/numeric mode after reopening.
Adjacent receipt gives actual ZIP/report/manifest identities; no outer self-hash
inside ZIP and no separate report attachment/equality prerequisite next time.

Return inline: exact verdict/tree; newly closed IDs with evidence classes and limits;
exact remaining IDs and actual stop reason; carried W suites versus new runs; any
candidate defect; actual next dependency/independent work status; report/ZIP/manifest
bytes and SHA-256; recipient ChatGPT. No routine per-case approval, new Project snapshot,
Git command, implementation, staging, commit, PR, merge, deployment or publication.
