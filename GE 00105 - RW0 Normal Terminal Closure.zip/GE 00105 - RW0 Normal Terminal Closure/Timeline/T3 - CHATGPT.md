## Engineering disposition

```text
RW0_POST_P1_NORMAL_TERMINAL_CLOSURE_READY_FOR_IMPLEMENTATION
```

**I accept the standalone program, explicitly limited to the five normal terminal outcomes.** The next step is direct source/schema implementation—not another broad reconnaissance or a standalone semantic-contract tranche.

Codex’s selection is appropriately bounded: a separate terminal fact follows the existing P1 decision; the three cancellation shapes remain unsupported by the selected writer. This must be described as **normal terminal closure**, not complete RW0 terminal coverage or readiness for live execution. Pasted text Pasted text

I checked the material contracts and implementation dependencies against the integrated checkpoint and tightened the handoff in several places.

## Selected program

The implementation will add a private `artificial_offline_normal.v1` terminal writer for:

```text
accept
repair
replan
terminal_reject
block
```

It will bind the corresponding **already committed P1 decision**, guarded result, receipt, and—only for acceptance—the existing immutable acceptance fact. It must create no replacement decision, program version, acceptance fact, execution permission, or successor launch. The terminal family remains a separate transaction under the existing fenced writer controller. Pasted text

The proposed physical representation is four immutable tables in additive migration `0008_rw0_terminal_outcome.sql`, keeping application generation 2. The expected cumulative schema is **78 tables, 142 triggers, and five explicit indexes**, to be established from actual SQL during implementation. Migrations 0001–0007 remain byte-exact. Codex correctly identified that `schemas/sqlite/coordinator-state-v1.sql` is the frozen 0001 fixture, not the current cumulative schema; it must remain unchanged. Pasted text

The new private V2 terminal value separates historical phase-entry evidence from the closure-time heads and stop. The existing V1 terminal value and its legacy `latch_postimage_*` representation remain unchanged and are not promoted into durable acceptance proof. Pasted text

## Implementation conditions I tightened

### 1. Replan replay cannot reconstruct private content from a safe digest

The report allows “the original closed P1 command or its reconstructible safe selector.” Those are **not interchangeable under the current implementation**. Pasted text

In the checkpoint:

- `_sqlite_rw0_c2_progression.py:399–467` reconstructs the P1 family through its write plan.
- `_rw0_c2_progression_plan.py:193–228` binds the replan WorkSpec.
- `_rw0_c2_progression_contracts.py:410–446` requires the original template’s private objective, requirements, and exclusions.

For this bounded program, I selected **the exact original P1 command as a transient caller-supplied operand**, including the replan proposal where required. Terminal storage retains only its safe association and required historical evidence—not the private template.

Missing or mismatched original operands must not be replaced with invented templates or treated as recoverable from a hash. Recovery remains unresolved when the required operand is unavailable. This is an explicit availability limit, not a claim of autonomous restart recovery.

The prompt also prevents reuse of pre-P1 current-owner readers as historical readers after replan. Historical predecessor verification and fresh closure-head sampling must remain separate.

### 2. All five connected positives must have matching source evidence

The existing P1 connected test deliberately changes typed validation dispositions after an actual passing D2 run:

```text
tests/test_sqlite_rw0_c2_connected.py:115–126
```

That is retained bounded P1 proof evidence. It is **not sufficient by itself** for the new terminal owner’s stronger claim that the reached source observations, result sets, dispositions, memberships, proposal, and decision all match.

The terminal tests must instead vary artificial fixture content **before capsule sealing and checker invocation**, allowing the existing fake validator, reviewer, and model to produce the corresponding evidence through the actual owner chain. Their current finite behaviors already support the relevant failure and inconclusive cases:

```text
src/ge_nwp_coordinator/_rw0_d2a_fake_validator.py:27–43
src/ge_nwp_coordinator/_rw0_d2a_fake_reviewer.py:27–44
src/ge_nwp_coordinator/_rw0_d2b_fake_review_model.py:12–48
```

This strengthens the new connected proof without reopening the accepted P1 implementation. A resealed but detached disposition must also become a terminal no-write negative control.

### 3. Terminal recording and protected disclosure have distinct requirements

The report correctly separates terminal closure from fresh acceptance eligibility. A truthful current claimed status of `False` must not prevent closing an already accepted P1 decision. Pasted text

The implementation mandate makes the permissions explicit:

- A **fresh terminal write** requires recording posture and permission to disclose its protected predecessor facts.
- **Exact terminal replay, checked read, and recovery** require disclosure posture, not renewed recording permission.
- None reevaluates whether the acceptance scope is still unclaimed.
- Closure records the actual permitted closure-time stop; it does not pretend that stop is unchanged since phase entry.
- Later head or stop changes must not invalidate exact historical replay.

Existing P1 permission behavior stays unchanged.

### 4. The first checkpoint must prove the difficult physical bindings

I strengthened the proposed first checkpoint. It must include **real fenced terminal acceptance and replan**, with checked read, replay, and recovery—not just values, tables, and row adapters.

That checkpoint must demonstrate the existing acceptance fact remains unchanged, replan historical heads remain verifiable, and the original P1 command dependency does not leak private text into terminal storage. The same implementation engagement then completes the remaining branches, causal controls, focused validation, and selector-free FULL run.

Ordinary in-scope development failures may be diagnosed and repaired within this implementation mandate. They must be retained and receive no final credit, but they do not automatically require another user-mediated continuation.

### 5. Independent audit remains before commit

The reconnaissance’s phrase “independent committed-artifact audit” does not change the established sequence. Pasted text

The operative sequence is:

```text
uncommitted implementation and validation
→ ChatGPT artifact inspection
→ fresh independent audit of exact uncommitted bytes
→ separately governed commit/publication gates
```

No commit is authorized by this handoff.

## Codex handoff

| Item | Operative instruction |
|---|---|
| **CURRENT STATE** | P0/P1 is merged and closed. Normal terminal closure remains unimplemented. |
| **RECIPIENT** | The **same Codex conversation that produced this reconnaissance**, now given the bounded workspace-write mandate. |
| **ATTACHMENTS** | **None.** No Downloads or old evidence-package lookup is required. |
| **AUTHORIZED EFFECTS** | New local branch from the integrated squash; bounded docs/source/schema/tests edits; isolated synthetic validation and external review artifacts. |
| **EXPECTED RETURN** | One uncommitted implementation candidate, uniquely named report, and self-contained review ZIP. |
| **PROJECT SNAPSHOT** | No new snapshot now. |
| **NEXT ACTION** | Return the implementation result here for inspection and preparation of the independent audit. |

Send **only this complete prompt**:

:chatgpt-content-reference{index="10"}[**RW0 normal terminal-closure implementation mandate**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt)

The mandate creates the new branch from the integrated squash—not from the preserved, unsquashed P0/P1 topic merely because its tree is identical:

```text
New branch:
codex/rw0-normal-terminal-closure-v1

Base commit:
61d0330aba1160f7f5e7d9c541a325222d1c61e5

Base tree:
44c7dee402d46b3e16dc389ae0824b4297dfec1f
```

Expected successful disposition:

```text
RW0_NORMAL_TERMINAL_CLOSURE_IMPLEMENTED_VALIDATED_PENDING_AUDIT
```

The prompt authorizes no staging, commit, network access, push, PR, merge, deployment, or product effect.

## Remaining boundary

Completing this program will **not** complete cancellation closure. The pre-effect cancel decision, distinct cancel effect, request/acknowledgement/signal/exit/teardown facts, and source-native reconciliation remain a separate physical program. The report correctly identifies that P1, D1/D2, C1, and Wire do not currently implement that entire causal chain. Pasted text

Concrete supplier qualification may proceed separately, but neither this reconnaissance nor the implementation mandate starts that work or satisfies supplier gate B. Pasted text

**Inspection limits:** I authenticated the checkpoint’s manifest and 315-file Git tree and inspected the critical contract, reader, replan, fixture, and transaction paths. I did not execute repository code, tests, migrations, or live Git operations. The physical design remains proposed until implemented and validated.

**Sources:** Attached reconnaissance report, cited above; rw0-c2-p0-p1-pr17-squash-source-checkpoint.zip[integrated PR #17 checkpoint](sandbox:/mnt/data/rw0-c2-p0-p1-pr17-squash-source-checkpoint.zip), including the exact source coordinates identified in this response.

**Confidence:** baseline provenance **0.99**; bounded program selection and implementation constraints **0.96**. Implementation correctness, runtime validation, and independent acceptance remain unestablished.
