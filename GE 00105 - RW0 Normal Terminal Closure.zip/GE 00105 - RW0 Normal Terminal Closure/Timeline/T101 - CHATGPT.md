## Engineering disposition

**The RU archive authenticates. It does not establish a candidate defect. Its historical `BLOCKED` verdict remains truthful for the mandate it executed, but that mandate imposed an incorrect C2A11 outcome. A second residual, C2A20, was also being held open by an unnecessarily strong fixture assumption.**

The exact subject remains the uncommitted, unaccepted 327-file tree:

```text
4691af58ae0ee3107b4e2e9b6b1508032944e357
```

The earlier cumulative audit likewise identified that exact tree as uncommitted and unaccepted. Pasted text

### Authentication

| Item | Verified result |
|---|---|
| RU ZIP | **87,897,841 bytes** |
| RU SHA-256 | `0a9db9e6ac62ddb6975c5aee613175deafe79833beb87b7bf7aa6d88c95a289b` |
| RU inventory | **237 regular members; 236 complete manifest rows** |
| Expanded bytes | **101,475,416** |
| RU report | 14,407 bytes; `6e8bf814646b453c7532bcde09e733d9731336bdad2f431241fb7d627f615d58` |
| RU manifest | 56,698 bytes; `54741d53b954bd445015e3c22baefc8a98e059c91de608d4f783e2b83cbf44db` |
| Embedded RT | Exact predecessor ZIP; **179 regular members**, correcting the earlier reported 181 |
| Candidate reconstruction | 327 paths; exact expected tree; all bytes, blobs, and recorded modes reconcile |

All archive names passed path, normalization, collision, type, encryption, CRC, hash, size, and numeric-mode checks.

## C2A11 is not a candidate failure

The source order is unambiguous:

```text
receipt lookup by mutation_ref
→ if present, verify the historical family
→ only if absent, proceed to currentness and route scanning
```

The later route inventory includes the same `rw0_terminal_receipts.mutation_ref`. Therefore, in the same fenced operation, a receipt cannot both be present at the first lookup and later become the first matching route in `_route_occupied`.

RU’s actual execution confirms that exact ordering:

- the receipt lookup hit;
- `_route_occupied` was called **zero** times;
- the deliberately inconsistent but checked, self-digest-valid, foreign-key-valid family was refused as `database_integrity_failure`;
- read refused similarly;
- recovery was `unresolved`;
- terminal rows did not move;
- a separate fault-free record/read/replay/recovery counterpart passed.

The correct closure is:

```text
receipt_first_supersession_invariant_plus_admitted_execution
```

It must **not** claim that route 11 physically returned `route_collision`.

RU remains historically `BLOCKED` under its old literal mandate. A fresh cumulative adjudication can close C2A11 without changing the candidate.

## C2A20 is already supported by carried evidence

The earlier continuation also over-specified C2A20 by suggesting a distinct second phase and complete second source chain. That is not how the recovery owner recognizes a competing winner.

Recovery searches for a winner by the **original command’s `phase_basis_ref`**. A terminal family on an unrelated phase cannot prove the original command absent.

The carried R execution already establishes the relevant boundary:

1. With no terminal family and positive `old_execution_excluded`, recovery returns `definitely_not_committed`.
2. With the same absence but `old_execution_excluded=False`, recovery returns `unresolved`.
3. The real writer records a complete, source-coherent terminal family for command A.
4. Command B uses the same checked phase/P1 source route but has a different terminal mutation and command identity.
5. Recovery for B finds and fully verifies A’s persisted family, reaches the command-reuse distinction, finds no other original alias route, and returns `definitely_not_committed`.
6. Noncommitted recovery carries no committed result. No winner result is returned, and no repair or retry occurs.

The representable “foreign winner” is therefore **foreign to the competing terminal command**, not an arbitrary unrelated phase.

The correct closure is:

```text
complete_compatible_winner_plus_original_absence_classification
```

A new second D1/D2/Section 41/C1/V22 chain is not required for this predicate.

## RU’s other twelve closures are supported

The nine physical route cases are supported at the stated L2 scope:

```text
C2A04 C2A05 C2A06 C2A07 C2A08
C2A10 C2A12 C2A13 C2A14
```

Each has actual earlier misses, the named first hit, `route_collision`, unresolved recovery, nonmovement, and a separate exact positive.

The three SQL rows are supported at their L1 constraint scope:

```text
C3A02 C3A03 C3A05
```

Their combined RS/RT/RU evidence reaches the outstanding uniqueness and primary-key implications with enabled foreign keys and guards, paired valid insertions, exact SQLite errors, rollback, and nonmovement.

The current RU ledger contains accounting drift rather than evidence gaps: several rows are marked closed while stale fields still say the named predicate was not attempted or reached. The successor ledger must correct those fields without rewriting the historical reports.

## Only C1B05 remains

After prospective correction of C2A11 and C2A20, the sole substantive residual is C1B05’s finite cross-owner association matrix:

```text
PHASE_01
SECTION41_01
C1_01 C1_02 C1_03
P1_01 P1_02 P1_03 P1_04 P1_05
PLAN_01 PLAN_02 PLAN_03
```

The continuation does **not** require another broad workflow or regression run. It requires, for each relationship:

- the real producer and consumer;
- an independently derived expected relation;
- all earlier checks kept valid;
- one deliberately isolated mismatch;
- the actual first rejecting seam;
- a source-coherent positive;
- row nonmovement, disclosure limit, and recovery result where applicable.

Where owner, foreign-key, self-digest, or immutability rules make a malformed durable state impossible, the audit may combine that precise invariant with a counted return fault **after the real checked owner executes**. It may not represent the result as a malformed family committed by the writer.

W v5’s four representatives, exact-99 replay, **60/60 direct**, and **9,568/9,568 selector-free FULL** remain carried independent execution. No automatic rerun is indicated.

## Handoff

| Field | Instruction |
|---|---|
| **CURRENT STATE** | Twelve RU closures supported; C2A11 and C2A20 eligible for corrected closure; only C1B05 needs new execution. |
| **RECIPIENT** | The **same neutral independent reviewer conversation** that produced `ru-a8116dc584`. |
| **ATTACHMENTS** | **None required.** The prompt names exact retained paths and identities. |
| **AUTHORIZED EFFECTS** | Audit-owned relation fixtures, observation, helper registration, ledger correction, and protected evidence under unchanged WA1+QtcM. |
| **EXPECTED RETURN** | One final cumulative disposition, corrected ledgers, C1B05 matrix/results, report, and reopened evidence ZIP. |
| **PROJECT SNAPSHOT** | None requested. |
| **NEXT ACTION** | Return the cumulative verdict here before any live commit gate. |

Send **only this complete replacement prompt**:

:chatgpt-content-reference{index="1"}[RW0 normal terminal closure — final C1B05 association closure and cumulative adjudication](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Final_C1B05_And_Cumulative_Adjudication_Prompt.txt)

```text
Prompt bytes:
20,210

SHA-256:
17bb0f14a4b6fc95e03687efc7bfc1791dba6de5010b3149834058151a2f4211
```

Supporting inspection records:

- :chatgpt-content-reference{index="2"}[Receiving review](sandbox:/mnt/data/Coordinator_RW0_RUA811_Receiving_Review.md)
- :chatgpt-content-reference{index="3"}[Machine-readable verification](sandbox:/mnt/data/Coordinator_RW0_RUA811_Receiving_Verification.json)
- :chatgpt-content-reference{index="4"}[Handoff identity record](sandbox:/mnt/data/Coordinator_RW0_RUA811_Handoff_Check.json)

Keep the implementation conversation idle. No candidate edit, policy expansion, regression reset, staging, publication, or new Project snapshot is authorized.

**Sources:** Uploaded RU archive and authenticated carried chain; receiving review and verification linked above; prior exact candidate status cited inline.  
**Confidence:** artifact/source authentication **0.99**; C2A11 corrected closure **0.99**; C2A20 carried-evidence closure **0.97**; C1B05 completion strategy **0.96**.
