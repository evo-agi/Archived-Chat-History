## Engineering disposition

**The archive authenticates. The 60-case direct pass is supported, and FULL is a completed failing run: 9,469 passed, 99 failed. The observed failures support a bounded correction to the audit runner—not a candidate-source repair.**

The next assignment makes three explicit, limited runner amendments, verifies the affected tests, and then resumes complete validation and residual audit closure. It does **not** assume that resolving the first failure in each test will reveal no further defect.

The candidate remains unaccepted at:

```text
4691af58ae0ee3107b4e2e9b6b1508032944e357
```

## Authenticated evidence and suite results

| Item | Verified result |
|---|---|
| Uploaded ZIP | **5,878,210 bytes** |
| SHA-256 | `dc754506dff6d3cc9ab803814cb4137a2f4094a9ecc3f8c5bd3bd69d6952ee4a` |
| Archive inventory | **218 regular files; 217 verified manifest rows** |
| Expanded size | **53,313,415 bytes** |
| Embedded report | **27,839 bytes**, matching its reported identity |
| Candidate | All **327 source files** authenticated and independently reconstructed to the fixed tree |
| Policy | Exact previously selected **Qs**, unchanged |

All covered archive members passed path, uniqueness, type, encryption, size, CRC, SHA-256, and numeric-mode checks. The embedded S and R archives also match their previously reviewed identities and manifests.

Independent parsing of the observer, JUnit, launch records, and raw outputs gives:

| Gate | Unique ordered collection/call/JUnit IDs | Passed calls | Failed calls | Setup/teardown failures | Warnings |
|---|---:|---:|---:|---:|---:|
| Direct | 60 | **60** | 0 | 0 | 0 |
| FULL | 9,568 | **9,469** | **99** | 0 | 3 |

The three FULL warnings are the specified writer-session fork deprecations. There were no skipped cases, missing calls, or recorded timeouts. Direct exited 0; FULL exited 1. Their ordered identities match the required inventories.

All **22 complete source-row captures**—four initial copies and eighteen launch before/after captures—match the candidate. The four postcleanup observations are consistent **summaries**, not four additional complete captures. Installed runtime identities remain retained host observations, not binaries inspected here.

:chatgpt-content-reference{index="3"}[Detailed receiving inspection](sandbox:/mnt/data/Coordinator_RW0_FINAL77_Receiving_Review.md)

## The 99 failures separate into four first-failure groups

| First failing assertion or operation | Cases | Supported attribution |
|---|---:|---|
| Generated **mutant** helper: child collection fails at `test_c2b0_durable_state_contract.py:8351` | **93** | One representative diagnostic exposes a denied directory scan; the shared explanation for the others remains an inference. |
| Generated **checker** helper: child collection fails at `:8447` | **4** | A different helper with the same collection symptom; no separate scan-denial trace is retained for these four. |
| Successful child collection, followed by empty-stderr assertion at `:16749` | **1** | The exact terminal-database notice violates the unchanged assertion. |
| Temporary module creation at `test_rw0_d1_process_supervisor.py:120` | **1** | `EPERM` writing a test-generated file beside the package source. |

**The 97 collection failures do not all come from one helper.** The report’s common-cause conclusion needs separate confirmation for the checker-helper group. I have retained a per-node map covering all 99 failure-text hashes and their actual first-failure sites.

:chatgpt-content-reference{index="4"}[Complete failure map](sandbox:/mnt/data/Coordinator_RW0_FINAL77_Failure_Map.json)

### 1. Nested pytest needs to enumerate an owned common ancestor

The representative diagnostic records `os.scandir` receiving `EPERM` at:

```text
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz
```

The unchanged test launches pytest from its source copy while naming a generated test under scratch. Qs permits reads within those descendant subtrees, but grants only metadata access to their common ancestor. The raw failure appears in:

```text
audit/evidence/launches/causal_residual_nested/nested_stdout.bin
```

Pytest 8.4.1’s published setup code corroborates the mechanism: configuration discovery can select a common ancestor of the invocation directory and test argument. That supports the diagnostic direction; it does not independently establish the cause of all 97 failures. [GitHub](https://raw.githubusercontent.com/pytest-dev/pytest/8.4.1/src/_pytest/config/findpaths.py)

The selected correction permits **literal directory enumeration of that one owned ancestor**, not recursive access to protected evidence, denied content, repositories, or user files.

Both generated helpers also assert empty child stderr **after** collection succeeds. Correcting the scan alone may therefore expose the next incompatibility.

### 2. The terminal notice must be fixed at its cause—not filtered

The dedicated oracle successfully collects its expected tests, then fails because stderr contains:

```text
Cannot read termcap database;
using dumb terminal settings.
```

Its child replaces the environment with five explicit variables. It does **not** inherit the outer runner’s `TERM` or `HOME`. Setting another variable only in the parent therefore is not a demonstrated solution.

Apple’s published libedit source defaults an absent terminal type to `dumb` and emits these lines when `tgetent` reports a database-read failure. This corroborates a terminal-data dependency, **not the exact missing resource on the installed host**. [GitHub](https://raw.githubusercontent.com/apple-oss-distributions/libedit/main/src/terminal.c)

The continuation permits a bounded runtime-only diagnosis and a minimal, evidence-confirmed read allowance for installed terminal-capability data. It prohibits stripping stderr, changing the assertion, intercepting subprocess results, altering the test-owned child environment, replacing readline, or installing anything.

### 3. The D1 test requires a temporary file—not modification of sealed source

The authenticated test creates:

```text
src/ge_nwp_coordinator/_rw0_d1_probe_temp.py
```

It uses that generated module to check child arguments, environment, working directory, and descriptor inheritance, then unlinks it in `finally`. **That path is absent from the 327-file candidate inventory.**

My blanket prohibition on all source-area additions was too broad for this unchanged test. The correction is an explicit prospective exception for that **exact transient filename in disposable audit copies**, while every existing candidate file remains immutable.

This is not authorization to edit source or make the package directory generally writable. The temporary slot must be absent before and after each validation phase, and alias/nearby-path controls must establish that its allowance does not enable writes to protected files.

The exact helper, test, policy, and launch coordinates supporting these three findings are in the Coordinator_RW0_FINAL77_Receiving_Review\.md[receiving inspection](sandbox:/mnt/data/Coordinator_RW0_FINAL77_Receiving_Review.md).

## Selected runner treatment

The successor policy, called **Qtc** in the handoff, is a new prospective identity. Its hash cannot be assigned until its actual paths and successful minimal data allowance are frozen.

| Amendment | Authorized extent |
|---|---|
| **Owned-directory enumeration** | Read directory entries at the one common audit root; no recursive content grant. |
| **Temporary test module** | At most two exact transient slots: one diagnostic source copy and one final FULL source copy. All 327 sealed files remain protected. |
| **Terminal-capability data** | At most two exact existing, system-owned data-file reads, with necessary literal ancestor metadata, supported by paired diagnostic evidence. No broad system subtree or user-home grant. |

Every original Qs byte remains preserved as the base. **No network or signal permission changes.** There is no unrestricted fallback or open-ended policy search.

The new boundary must pass the original containment controls and the changed-path controls. Then the auditor tests representatives from **both** generated-helper families, the dedicated stderr oracle, and the temporary-module test. After those succeed, it reruns the **exact 99 failed node IDs** as a diagnostic set.

Only then does it run fresh complete direct and selector-free FULL gates under the final policy. The 99-case diagnostic set is not FULL, and a changed error message is not a successful repair.

## The residual ledger is smaller than the headline suggests—but still mandatory

The 33 open rows comprise **three runner-compatibility rows, G01–G03, plus 30 substantive audit rows**:

| Substantive group | Open rows |
|---|---:|
| Route/family distinctions | 16 |
| Acceptance relationships | 4 |
| SQL constraints | 4 |
| Graph predicates | 2 |
| Transaction failures | 2 |
| Source association | 1 |
| Session behavior | 1 |

The new bounded proofs should carry forward. In particular, the previously masked receipt result-pair foreign key was reached with intact guards; actual first route matches at ordinals 1–3 were recorded; and the current-owner probe distinguished five denied SELECTs from five malformed-row cases. These are three causal launches, not eighteen independent tests merely because they support eighteen ledger entries.

T marks twelve cases unattempted after the FULL incompatibility. That status establishes neither impossibility nor a candidate defect. C4’s completed normalized historical observations remain carried evidence at their existing scope.

**Fixing G01–G03 does not close the other 30 rows.** The continuation completes the regression gates, then the remaining substantive ledger; acceptance requires both. Coordinator_RW0_FINAL77_Receiving_Verification.json[Residual and execution reconciliation](sandbox:/mnt/data/Coordinator_RW0_FINAL77_Receiving_Verification.json)

## Codex handoff

| Field | Instruction |
|---|---|
| **CURRENT STATE** | Direct pass supported; FULL failed with the four first-failure groups above. Candidate remains unaccepted. |
| **RECIPIENT** | The **same neutral independent reviewer conversation** that produced `final-77be0d42f6`. |
| **ATTACHMENTS** | **None required.** Exact retained input paths and identities are included. |
| **AUTHORIZED EFFECTS** | The bounded runner amendments and diagnostics above, recalibration, unchanged-candidate validation, and residual synthetic audit work. |
| **EXPECTED RETURN** | One cumulative disposition, full report, complete failure/closure ledgers, and reopened evidence ZIP. |
| **PROJECT SNAPSHOT** | None requested. |
| **NEXT ACTION** | Return the cumulative result here before any candidate repair or commit gate. |

Send **only this complete replacement prompt**:

:chatgpt-content-reference{index="7"}[**RW0 normal terminal closure — test/runtime compatibility and audit completion**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Test_Runtime_Compatibility_And_Audit_Completion_Prompt.txt)

Its substantive sections 2–3 are preserved byte-for-byte. The execution changes are explicit: narrowly scoped runtime compatibility, a transient test-file exception, representative and failed-set verification, then complete suites and residual closure. No earlier prompt fragments need to be assembled.

```text
Prompt size:
61,964 bytes

SHA-256:
434411b8e0c3fec612890c9c7115c9a457ab854534e90e25192c8dde029348b8
```

:chatgpt-content-reference{index="8"}[Handoff identity record](sandbox:/mnt/data/Coordinator_RW0_FINAL77_Handoff_Check.json)

Keep the implementation conversation idle. No candidate edit, test relaxation, staging, commit, publication, or deployment is authorized.

**Inspection limits:** I performed data-only archive verification, source reconstruction, retained-record reconciliation, and static source/policy inspection. I executed no supplied helper, candidate code, SQL, tests, sandbox policy, Git command, or host diagnostic. The proposed runner correction has not been executed or shown sufficient.

**Sources:** Coordinator_RW0_FINAL77_Receiving_Review\.md[Receiving inspection](sandbox:/mnt/data/Coordinator_RW0_FINAL77_Receiving_Review.md), RW0_Normal_Terminal_FINAL77_Report_From_Sealed_ZIP.md[exact embedded audit report](sandbox:/mnt/data/RW0_Normal_Terminal_FINAL77_Report_From_Sealed_ZIP.md), Coordinator_RW0_FINAL77_Receiving_Verification.json[verification record](sandbox:/mnt/data/Coordinator_RW0_FINAL77_Receiving_Verification.json), and the primary pytest/libedit sources cited above.

**Confidence:** Artifact identity and suite reconciliation **0.99**; bounded compatibility diagnosis and selected direction **0.96**. The exact installed terminal-data dependency, success of the amended boundary, and complete candidate acceptance remain unestablished.
