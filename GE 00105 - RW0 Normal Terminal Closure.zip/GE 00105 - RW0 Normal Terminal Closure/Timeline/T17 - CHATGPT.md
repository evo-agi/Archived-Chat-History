## Engineering disposition

```text
RW0_NORMAL_TERMINAL_CLOSURE
HISTORICAL_ADMISSION_CONTRACT_RECONCILIATION_AND_WITNESS_REPAIR_REQUIRED
CANDIDATE_REMAINS_UNACCEPTED
```

**Proceed with one bounded continuation in the implementation conversation: preserve shared managed-state validation, explicitly correct the overbroad historical-read requirement, and repair direct `TerminalHeadWitness` construction. Do not repeat the audit against unchanged bytes.**

The latest audit reports that **F01’s timestamp repair and O1’s calibrated counter passed**. Its new findings concern a different layer: current-stop access during shared database admission, and an unchecked private constructor. The process violations independently prevent compliant acceptance. Pasted text Pasted text

I reauthenticated the supplied candidate ZIP, all 854 manifest-covered members, and all 327 source endpoints, reconstructing:

```text
5c44721183f660032b6468d2c1f5a1d0dc3e6acb
```

I then traced the implicated admission, historical-reader, witness, and governing-document paths. I have **not** received or reopened the latest auditor’s separate 1,370,071-byte evidence ZIP; its runtime results remain attributed to the report.

## 1. Preserve the shared preflight; amend the historical guarantee explicitly

The audit correctly found that the **whole operation** reads `global_stop_current`, even though the terminal-specific historical code does not.

The source makes the distinction clear:

```text
sqlite_transition_transaction.py:2759–2770
    begin transaction
    validate database binding
    validate managed connection
    fence writer

sqlite_migration.py:2477–2523
    validate current global-stop singleton shape
    validate writer-ownership shape
```

These are existing storage-admission requirements. The schema owner requires a valid current-stop singleton and active/clear field consistency, and the writer-session owner requires managed validation before fencing and domain disclosure:

```text
.docs/sqlite-schema-v1.md:343–353
.docs/writer-session-authority.md:489–527
```

**My earlier audit mandate conflated historical reconstruction independence with independence from all current database-integrity checks. That was too broad.** Removing or bypassing the common invariant check would weaken an existing safety boundary to satisfy a terminal-specific test.

I am therefore making this explicit contract decision:

| Layer | Selected requirement |
|---|---|
| **Common operational admission** | Existing database binding, schema/history, managed invariants, session validity, and writer fencing remain mandatory. The current-stop **shape-validation read remains permitted**. |
| **Historical terminal verification** | After admission and fencing, reconstruct from saved full postimages and immutable predecessors—not today’s five heads or stop. Preserve the original result, timestamp, graph, and receipt. |
| **Fresh terminal recording** | Continue reading actual current heads and stop and applying the existing currentness checks. No relaxation. |

The resulting guarantee is precise: **later valid head or stop changes must not invalidate recorded terminal history, but accessing that history still requires a readable, valid managed store and current protected-disclosure permission.** An unreadable or malformed stop row may prevent admission; that must remain an operational/integrity failure or unresolved recovery—not a claim that the historical terminal fact is stale or absent.

This is a **change to the acceptance requirement**, not proof that the old requirement passed. The previous blocked verdict remains intact. The audit itself identifies this contract conflict and distinguishes its successful phase-scoped control from the failed whole-operation obligation. Pasted text

The continuation will update the owning documentation and tests together. It prohibits production changes to the migration validator, transaction controller, or writer session.

## 2. Repair the direct witness constructor

The second finding is a concrete private value-contract defect.

At:

```text
src/ge_nwp_coordinator/_rw0_terminal_head_witness.py:44–49
```

`TerminalHeadWitness` is a three-field dataclass without constructor validation. Its factories check their inputs, but ordinary direct construction does not enforce those checks. The audit accepted malformed direct objects while the factories rejected equivalent invalid inputs. **No production persistence or authority bypass was demonstrated.** Pasted text

The selected correction is local:

- Constructor and factories must share one nonrecursive validation relation.
- Canonical bytes, complete typed postimages, and compact coordinates must agree.
- Exact built-in types must be checked before hostile equality or coercion.
- Canonical bytes remain the internal source of truth; caller-owned or returned dictionaries must not be mutable aliases to supposedly checked internal state.

Valid wire bytes, schema identifiers, digest domains, row meanings, and owner adapters remain unchanged. **No migration change or new schema version is needed.** The only production file authorized to change is `_rw0_terminal_head_witness.py`.

This also avoids a superficial fix that validates three representations at construction but leaves them independently mutable afterward. The mandate does not claim protection against arbitrary Python reflection or hostile same-process memory modification.

## 3. Replace the misleading zero-read oracle with a calibrated phase-aware test

The earlier terminal-local tests patched `_current` and related terminal helpers. They could establish that those helpers were not called; they could not establish that the shared controller never read current stop state.

The latest auditor also withdrew one zero-attempt claim after finding that its denial control patched the wrong imported opener alias. The corrected experiment observed the preflight dependency. Pasted text

The new controls must exercise the actual `WriterSession` entry points and observe the real operation connections. They must establish both sides:

**Admission remains enforced.** Observe the real current-stop invariant read; deny it in a separate control and verify safe failure before terminal-family processing, with no writes or protected result disclosure.

**Historical reconstruction remains independent.** Permit that existing invariant read only in its identified phase, then deny current-stop reads during terminal historical verification. Deny the five current-head reads throughout the historical operation. Later coherent head and active/clear stop changes must preserve exact historical results.

The observers must call the real validators, not replace them with successful assessments. Their attachment must be calibrated by actual owned queries that reach—and can be denied by—the authorizer.

## 4. Keep audit-process failures separate from candidate findings

The live-checkout status read and attempted unrelated-path reads violated the audit’s effect ceiling. An `ENOENT` result is not evidence that an isolation boundary denied access. Those actions cannot be converted into a clean artifact-only engagement by excluding their outputs afterward. The report appropriately withholds both mutation and preservation claims about that interval. Pasted text

The archive-backed findings remain useful for engineering, but **this engagement cannot supply compliant acceptance**.

After the repair, the next audit should start in a neutral artifact-only workspace rather than an attached live repository workspace. Isolation calibration must use owned synthetic sentinels—not actual excluded checkout or home paths.

The validation record also remains bounded: the auditor completed 51 direct cases and a selector-free 9,559-ID collection, but interrupted FULL execution. **There is no independent FULL pass.** The missing direct JUnit-property observation and the expressly unfinished causal controls remain outstanding. Pasted text Pasted text

## Codex handoff

| Field | Instruction |
|---|---|
| **CURRENT STATE** | Tree `5c447211…` is authenticated, uncommitted, and blocked. |
| **RECIPIENT** | The **same write-enabled normal-terminal implementation Codex conversation**. |
| **ATTACHMENTS** | One original audit-evidence ZIP, identified below. |
| **AUTHORIZED EFFECTS** | Private witness constructor repair, bounded contract/test updates, isolated validation, and external review artifacts. Shared admission code and SQL remain frozen. |
| **EXPECTED RETURN** | A new cumulative uncommitted candidate and self-contained review package. |
| **PROJECT SNAPSHOT** | None requested; PR #17 remains the integrated baseline. |
| **NEXT ACTION** | Return the repair result here, then obtain a fresh cumulative independent precommit audit. |

Send this **one complete operative prompt**:

:chatgpt-content-reference{index="9"}[**RW0 normal terminal closure — historical-admission reconciliation and witness repair**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Closure_Historical_Admission_Witness_Repair_Prompt.txt)

Attach this original file from the **audit conversation**:

```text
RW0_NORMAL_TERMINAL_F01_CUMULATIVE_AUDIT_BLOCKED_EVIDENCE.zip

Bytes:
1,370,071

SHA-256:
16b4098f63cbb1fe68d4e7079711565624fe1412aaf28af70413f4d5f8518970
```

Its reported retained location is:

```text
/private/tmp/rw0-audit-cjUBsqCa/
RW0_NORMAL_TERMINAL_F01_CUMULATIVE_AUDIT_BLOCKED_EVIDENCE.zip
```

**No separate `AUDIT_REPORT.md`, `Pasted text.txt`, or source-package attachment is needed.** The evidence ZIP contains the full report, and the implementation conversation already retains the candidate package. The prompt authenticates the embedded report against its fixed 32,236-byte identity. Pasted text

The mandate requires fresh direct, connected, focused, and selector-free FULL validation on final bytes, with complete before/after captures around collection and execution. It preserves all outstanding cumulative audit obligations rather than treating these two corrections as the entire acceptance scope.

It authorizes **no staging, commit, push, PR, merge, publication, deployment, or product effect**. Do not send it to the audit conversation or reuse the previous audit mandate unchanged.

**Sources:** Latest audit cited above; authenticated candidate source at the exact coordinates identified here; Coordinator_RW0_Normal_Terminal_Closure_Historical_Admission_Witness_Handoff_Check.json[receiving verification and handoff identities](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Closure_Historical_Admission_Witness_Handoff_Check.json).

**Confidence:** source/package identity **0.99**; bounded constructor repair and admission-contract decision **0.97**. Latest raw audit execution evidence has not been reopened here; repaired runtime correctness and independent acceptance remain unestablished.
