RW0 NORMAL TERMINAL CLOSURE — PR #18 HEAD-PINNED SQUASH INTEGRATION AND SOURCE CHECKPOINT

This is the sole complete operative integration mandate. Continue in the SAME write-enabled Coordinator implementation conversation that created and pushed PR #18. Do not use the neutral audit conversation. Do not implement, repair, restage, amend, or rerun tests.

ENGAGEMENT ENVELOPE

CURRENT STATE
- Repository: /Users/ds/Repositories/Governed Execution Coordinator/
- Expected current branch and HEAD:
  codex/rw0-normal-terminal-closure-v1
  ff784eab00bb1f73784e8fa34da7890878fc8075
- Expected HEAD tree:
  bc10382edd1b2c097fc729e4e168d72e710391fe
- Expected topic upstream:
  origin/codex/rw0-normal-terminal-closure-v1
- Expected implementation commit:
  d3fd741c872b26aa2dfe927ab6dccc638cdcf356
- Expected fixed trunk_dev base:
  61d0330aba1160f7f5e7d9c541a325222d1c61e5
- Expected PR: #18, “RW0: normal terminal closure”, open, non-draft, unmerged, auto-merge disabled.
- Expected PR commit order:
  d3fd741c872b26aa2dfe927ab6dccc638cdcf356
  ff784eab00bb1f73784e8fa34da7890878fc8075
- Expected accepted source tree: bc10382edd1b2c097fc729e4e168d72e710391fe.
- The implementation and status commits are pushed but not merged. No deployment or product effect exists.

RECIPIENT
- Same write-enabled terminal-closure implementation Codex conversation.
- One repository writer. Spawn no subagents.

ATTACHMENT
- Attach exactly the existing publication-gate evidence ZIP:
  RW0_NORMAL_TERMINAL_CLOSURE_STATUS_PUBLICATION_GATE_EVIDENCE.zip
  1,106,920 bytes
  SHA-256 7cc73960e2c0769daa2fb592f20b87041934f83871294a0861aed804fc333640
- No other attachment is required if this ZIP and the exact live/remote state authenticate.

AUTHORIZED EFFECTS
- Read the exact matching live checkout and attached evidence.
- Perform fresh read-only local and GitHub premerge checks.
- Issue exactly one synchronous, head-pinned squash-merge request for PR #18.
- Perform exactly one scoped fetch of remote trunk_dev after a confirmed merge.
- Advance local trunk_dev exactly once with compare-and-swap from the fixed base to the verified squash commit.
- Create task-owned external integration evidence and one complete source checkpoint ZIP from the fetched squash Git blobs.

PROHIBITED EFFECTS
- No source, documentation, test, schema, migration, configuration, index-content, or worktree edit.
- No staging, local commit, amend, rebase, cherry-pick, local merge, force push, ordinary push, pull, branch switch, reset, clean, stash, branch deletion, PR edit, auto-merge enablement, deployment, release, service contact, user/product database, or product effect.
- Do not rerun candidate tests, focused validation, selector-free FULL, migrations, or packaged helpers. Prior validation remains historical accepted evidence.
- Do not delete local or remote topic branches. Keep HEAD on the topic branch.
- Do not repeat the merge request. If its result is uncertain, use read-only remote/PR readback to determine whether it took effect; never issue a second merge request.

EXPECTED RETURN
- RW0_NORMAL_TERMINAL_CLOSURE_PR18_SQUASH_MERGED_AND_SOURCE_CHECKPOINTED
- Or a precise BLOCKED/INCOMPLETE result naming the exact changed precondition or uncertain effect.

PROJECT SNAPSHOT
- Do not create a snapshot in this gate.
- On successful integration, return to ChatGPT and explicitly request a new Coordinator Project-source snapshot of integrated trunk_dev.

NEXT ACTION
- Return to ChatGPT for integration review and snapshot request. Do not begin the next Coordinator implementation tranche.

0. ENTRY, ATTACHMENT AUTHENTICATION, AND STOP CONDITIONS

Read this whole mandate before any effect-bearing command. Authenticate the attached ZIP before using any contained claim:

- safe, normalized, unique relative regular-member names;
- complete 88-row self-excluding manifest plus manifest member;
- exact ZIP bytes and SHA-256;
- retained staged/committed 327-row source inventory;
- status commit object, tree, parent and exact message;
- fixed PR #18 base/head/commit list/tree;
- accepted staged 5,655-ID validation record;
- prior process error and its no-effect classification.

The attachment’s retained state is evidence, not current remote truth. Before merge, freshly authenticate all live and remote conditions below.

Stop before any merge request if any of these differs:

1. live checkout path, branch, HEAD, HEAD tree, topic upstream, clean worktree/index, source inventory, or classified OS-0600/Git-100644 test mode;
2. local trunk_dev or local origin/trunk_dev is not exactly 61d0330aba1160f7f5e7d9c541a325222d1c61e5;
3. local topic or local remote-tracking topic is not exactly ff784eab00bb1f73784e8fa34da7890878fc8075;
4. remote trunk_dev is not exactly 61d0330aba1160f7f5e7d9c541a325222d1c61e5;
5. remote topic is not exactly ff784eab00bb1f73784e8fa34da7890878fc8075;
6. PR #18 is missing, closed without merge, draft, already merged, has auto-merge enabled, has a changed title/base/head, or has any commit outside the exact two-commit order;
7. the remote head tree is not exactly bc10382edd1b2c097fc729e4e168d72e710391fe;
8. the current PR file inventory is not the exact cumulative 83-path implementation-plus-status delta retained by the publication gate;
9. any review, review thread, unresolved thread, check run, or commit status has appeared since the accepted publication readback;
10. the PR is not currently mergeable/clean;
11. repository settings would automatically delete the topic branch on merge;
12. the active branch rules or applicable ruleset no longer permit squash as the sole merge method, no longer require thread resolution, require an approval/check not satisfied by this exact PR, expose a bypass actor for this effect, or otherwise differ materially from the accepted rule posture;
13. a concurrent Git writer, index lock, ref lock, merge/rebase state, unmerged entry, staged path, unstaged path, or untracked source path exists;
14. the attached evidence or live/remote commit/tree identities fail to reconcile.

Do not reset, repair, rewrite, refresh away, or normalize a mismatch. Return a precise blocked report.

The fresh premerge check must inspect and retain:

- branch, HEAD, tree, upstream, worktree, index, source modes, local refs and Git config;
- exact local raw commit objects for d3fd741... and ff784e...;
- remote trunk and topic refs;
- repository delete-branch-on-merge setting;
- PR object, exact two commits, cumulative files, reviews, review threads, checks, statuses, mergeability and auto-merge;
- applicable branch rules and the full ruleset identified by the branch-rules endpoint, including bypass actors and required checks/reviews;
- opening authoritative and qualified diagnostic ref inventories.

Zero checks is permitted only because the freshly authenticated active rules require none. Record it as zero checks, not a CI pass.

1. FIXED INTEGRATION SUBJECT

The only authorized source is the exact PR #18 head:

- implementation commit:
  d3fd741c872b26aa2dfe927ab6dccc638cdcf356
- status commit:
  ff784eab00bb1f73784e8fa34da7890878fc8075
- accepted final tree:
  bc10382edd1b2c097fc729e4e168d72e710391fe
- fixed base:
  61d0330aba1160f7f5e7d9c541a325222d1c61e5

The PR’s current remote commit objects must independently establish:

- d3fd741... has sole parent 61d0330... and tree 4691af58...;
- ff784e... has sole parent d3fd741... and tree bc10382...;
- all 327 head-tree blobs and Git modes equal the accepted publication manifest.

Do not accept only aggregate tree equality if any path/mode/blob row differs.

2. EXACT SQUASH REQUEST

Prepare this exact squash title:

feat: add RW0 normal terminal closure

Prepare this exact squash body, including the line breaks below and one terminal LF in the prepared local file:

Squash-integrate the independently accepted private artificial-offline RW0
normal terminal closure and its accepted current-status successor.

Source commits:
- d3fd741c872b26aa2dfe927ab6dccc638cdcf356 — feat: add RW0 normal terminal closure
- ff784eab00bb1f73784e8fa34da7890878fc8075 — docs: record RW0 normal terminal closure status

Accepted source tree:
bc10382edd1b2c097fc729e4e168d72e710391fe

Validation and review:
- implementation staged-tree gate: 9,568 / 9,568 passed
- status staged-tree focused gate: 5,655 / 5,655 passed
- independent artifact review accepted the exact status tree
- the accepted 9,597-test selector-free FULL record is carried evidence and was not rerun during integration

Authority limits:
- P0, P1, and terminal closure remain separate private fenced facts
- terminal closure supports only accept, repair, replan, terminal reject, and block
- no active-cancel terminal family
- no live supplier/custody, worker/provider, ES/Bridge, product Git-effect, service,
  queue, scheduler, deployment, or autonomous runtime authority
- no tests were run during integration

Record the exact prepared title/body bytes and SHA-256.

Issue exactly one synchronous GitHub squash request for PR #18 with:

- merge method `squash`;
- expected head SHA `ff784eab00bb1f73784e8fa34da7890878fc8075`;
- the exact title and body above.

Use a request form that sends the head SHA as GitHub’s merge precondition. Do not rely only on an earlier readback. Retain the exact request argv/body, timestamps, exit, stdout and stderr.

If the request reports failure or the transport result is uncertain, do not repeat it. Perform read-only PR, remote-ref and commit readback to determine whether a merge occurred, then return the truthful result.

GitHub may omit only the prepared terminal LF from the committed message. No other title/body difference is acceptable.

3. REMOTE MERGE AND SQUASH-COMMIT VERIFICATION

After a reported successful merge, before changing local refs, independently verify through fresh GitHub readback:

- PR #18 is closed and merged;
- merged head/base remain the fixed values;
- merge request count is one;
- the resulting squash commit SHA is identified;
- remote trunk_dev points to that squash commit;
- remote topic still points to ff784eab00bb1f73784e8fa34da7890878fc8075;
- the squash commit has exactly one parent, 61d0330aba1160f7f5e7d9c541a325222d1c61e5;
- its tree is exactly bc10382edd1b2c097fc729e4e168d72e710391fe;
- its title/body match the prepared message, allowing only omission of the terminal LF;
- all 327 remote tree paths, Git modes and blob OIDs equal the accepted inventory;
- GitHub signature/verification fields are retained as an observation, not source or test evidence;
- reviews, threads, checks and statuses are reported accurately after merge;
- auto-merge remained disabled and no branch deletion occurred.

A merge commit with the wrong parent, tree, message, or source inventory is a blocking integration failure. Do not attempt repair or a second merge.

4. ONE SCOPED FETCH AND LOCAL REF UPDATE

Only after remote verification succeeds:

1. Reauthenticate that local HEAD is still the status topic commit, the worktree/index remain clean, local trunk_dev and origin/trunk_dev still equal the fixed base, and no writer/lock appeared.
2. Perform exactly one scoped, no-tags fetch of only remote `refs/heads/trunk_dev` into local `refs/remotes/origin/trunk_dev`. Do not fetch all branches, tags, pull refs, or topic refs. Record the exact command and output.
3. Verify the fetched raw commit object, parent, tree, message, signature payload where present, and complete 327-row tree against the remote readback and accepted inventory.
4. Advance local `refs/heads/trunk_dev` exactly once using compare-and-swap from:
   61d0330aba1160f7f5e7d9c541a325222d1c61e5
   to the verified squash commit.
5. Do not check out trunk_dev. Keep HEAD on `codex/rw0-normal-terminal-closure-v1` at `ff784e...`, with its upstream unchanged.
6. Do not delete or retarget the local topic, remote-tracking topic, or remote topic.

The only expected authoritative local ref changes in this gate are:

- `refs/remotes/origin/trunk_dev` from the fixed base to the squash commit;
- `refs/heads/trunk_dev` from the fixed base to the squash commit.

Record every authoritative and qualified diagnostic ref delta. Do not attribute diagnostic variation without evidence.

5. COMPLETE SOURCE CHECKPOINT

Create one task-owned external checkpoint from the fetched squash Git object database, not from the working tree.

Required checkpoint name:

RW0_NORMAL_TERMINAL_CLOSURE_PR18_SQUASH_SOURCE_CHECKPOINT.zip

The checkpoint must include:

- all 327 source file bytes read from the squash commit’s Git blobs;
- each path’s Git mode, blob OID, byte count and raw SHA-256;
- an independently reconstructed tree equal to bc10382edd1b2c097fc729e4e168d72e710391fe;
- the raw squash commit object and parsed parent/tree/message/signature observations;
- the exact publication-gate evidence ZIP once;
- premerge and postmerge PR/ruleset/check/review/thread/status readbacks;
- merge request and response;
- scoped-fetch and local compare-and-swap records;
- opening, postmerge, postfetch, post-CAS and final ref/config/index/worktree observations;
- a report, machine result, self-excluding package manifest, delivery receipt, and cleanup/final-preservation records.

The checkpoint’s `source/` wrappers may use ordinary 0644 packaging mode while recording Git mode 100644. Record the historical live-checkout OS-0600 exception separately; do not claim that the fetched commit determines a future checkout’s POSIX mode.

Reopen the completed checkpoint and verify every member’s safe name, type, bytes, CRC, SHA-256 and numeric archive mode. Reconstruct the source tree from the archived source bytes and Git modes alone.

Do not include `.git`, credentials, private templates/capsules, user databases, caches, bytecode, validation scratch, mutable runtime state, or unclassified logs.

6. VALIDATION AND EFFECT ACCOUNTING

Do not run tests during integration.

Carry these as historical accepted evidence only:

- implementation staged-tree selector-free 9,568-pass gate;
- status staged-tree 5,655-pass focused gate;
- accepted status-tree 9,597-pass selector-free FULL record.

Report exactly:

```text
TESTS_NOT_RUN_DURING_INTEGRATION
AUTO_MERGE_NOT_ENABLED
TOPIC_BRANCH_NOT_DELETED
DEPLOYMENT_NOT_PERFORMED
PRODUCT_EFFECT_NOT_PERFORMED
```

The squash integration establishes Git object/ref truth on `trunk_dev`. It does not establish live supplier/custody, remote worker/provider execution, ES/Bridge routing, product Git effects, deployment, cancellation support, service, queue, scheduler, or autonomy.

7. DELIVERY AND FINAL RETURN

Write the complete final report before sealing the checkpoint/evidence package. Return exactly one primary success disposition:

RW0_NORMAL_TERMINAL_CLOSURE_PR18_SQUASH_MERGED_AND_SOURCE_CHECKPOINTED

Or return a precise blocked/incomplete disposition with no misleading integration claim.

The success report must include:

- exact premerge PR/base/head/commit list/tree and live local opening;
- current ruleset and repository delete-branch setting;
- exact one-time squash request and response;
- actual squash commit SHA, parent, tree, message bytes/hash and signature observation;
- full 327-path blob/mode/source reconciliation;
- remote PR/ref state after merge;
- scoped fetch and local compare-and-swap details;
- final local HEAD/topic/upstream, local trunk_dev, origin/trunk_dev, remote trunk/topic, clean index/worktree and config/ref deltas;
- checkpoint/report/result/manifest/receipt byte counts and SHA-256 values;
- process errors, unavailable steps, cleanup and nonclaims;
- next recipient ChatGPT for integration review and a new Coordinator Project-source snapshot request.

Do not begin any next implementation or status tranche.
