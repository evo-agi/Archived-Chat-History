RW0 NORMAL TERMINAL CLOSURE — EXACT-BYTE STATUS COMMIT, PUSH, AND PR GATE

This is the sole complete operative publication-gate mandate. Continue in the SAME
write-enabled Coordinator implementation conversation that owns the live checkout and
produced local implementation commit d3fd741c872b26aa2dfe927ab6dccc638cdcf356.
Do not use the neutral audit conversation. Do not repair or edit source during this gate.

ENGAGEMENT ENVELOPE

CURRENT STATE
- Repository: /Users/ds/Repositories/Governed Execution Coordinator/
- Expected branch: codex/rw0-normal-terminal-closure-v1
- Expected HEAD: d3fd741c872b26aa2dfe927ab6dccc638cdcf356
- Expected sole parent of HEAD: 61d0330aba1160f7f5e7d9c541a325222d1c61e5
- Expected committed HEAD tree: 4691af58ae0ee3107b4e2e9b6b1508032944e357
- Expected upstream: absent
- Expected local trunk_dev and origin/trunk_dev: 61d0330aba1160f7f5e7d9c541a325222d1c61e5
- Expected working-source tree: bc10382edd1b2c097fc729e4e168d72e710391fe
- Expected source-manifest SHA-256: 52db9e528529d5085aa0ac6c7546fabebafe4d2bd1fd2dec08ba1bb8337d9985
- Expected source inventory: 327 regular paths; every Git mode 100644; observed OS mode
  0600 only for tests/test_c2b3_private_atomic_program_initialization.py and 0644 for
  the other 326 paths.
- Expected cumulative delta against HEAD: exactly 32 modified existing paths, zero added,
  deleted, renamed, untracked-source, staged, or unmerged paths; no Git-mode change.
- Expected raw opening index SHA-256 before the first Git command:
  cda85858934e4da9db5b5f17e8d4940f66c38b69246ec8e79a8ca5730f9a1b36.
- The implementation commit and accepted status source are private artificial-offline
  evidence only. Nothing is merged, deployed, product-effective, or live-authoritative.

RECIPIENT
- Same write-enabled terminal-closure implementation Codex conversation.
- One repository writer only. Spawn no subagent during mutation, staging, commit, push,
  or PR creation.

ATTACH EXACTLY THESE SIX FILES
1. RW0_NORMAL_TERMINAL_CLOSURE_LOCAL_COMMIT_STATUS_SUCCESSOR_CURRENT_DRIFT_REPAIR_UNCOMMITTED_REVIEW.zip
   17,824,131 bytes
   SHA-256 2e797bde1ae3c7394c973ee6e39482e997f9d354d61c7d856a4b6be9e18a2e1f
2. RW0_NORMAL_TERMINAL_CLOSURE_LOCAL_COMMIT_STATUS_SUCCESSOR_CURRENT_DRIFT_REPAIR_IMPLEMENTATION_REPORT.md
   12,615 bytes
   SHA-256 968fff63ab69898d885966e9145b32cbc706f319791d4fdc042ee886399f0721
3. RW0_NORMAL_TERMINAL_CLOSURE_LOCAL_COMMIT_STATUS_SUCCESSOR_CURRENT_DRIFT_REPAIR_VALIDATION_SUPPLEMENT_EVIDENCE.zip
   18,578,745 bytes
   SHA-256 c3ef501d5747c2890ced98b175edb204dc3875ae99e9b6803c03ff6b52e83f16
4. RW0_NORMAL_TERMINAL_CLOSURE_LOCAL_COMMIT_STATUS_SUCCESSOR_CURRENT_DRIFT_REPAIR_VALIDATION_SUPPLEMENT_COMPLETION_REPORT.md
   18,924 bytes
   SHA-256 e30bbe214e65ac18a868171645e3969fd7049b5932031e63851f628178cb3d76
5. RW0_NORMAL_TERMINAL_CLOSURE_LOCAL_COMMIT_STATUS_SUCCESSOR_CURRENT_DRIFT_REPAIR_INDEPENDENT_ARTIFACT_REVIEW.md
   17,800 bytes
   SHA-256 eff2e36d6bf2829df0d53c8215338373ffe68251359454e246d6ee52f61696e1
6. RW0_NORMAL_TERMINAL_CLOSURE_LOCAL_COMMIT_STATUS_SUCCESSOR_CURRENT_DRIFT_REPAIR_AUDIT_EVIDENCE.zip
   66,984 bytes
   SHA-256 a6bac1d8471f71cf958a951149101d954b1744894a7d5fbe3e2124dd50053540

The exact independent disposition is:
RW0_NORMAL_TERMINAL_CLOSURE_LOCAL_COMMIT_STATUS_SUCCESSOR_CURRENT_DRIFT_REPAIR_ARTIFACT_REVIEW_ACCEPTED

AUTHORIZED EFFECTS
- Authenticate the exact live checkout and all six fixed inputs.
- Stage exactly the accepted 32 existing paths and no others.
- Build and validate an external source copy solely from the staged Git tree.
- Create exactly one local status commit with the exact message below.
- Push the existing topic branch once with a plain push and establish its upstream.
- Open one non-draft PR against the fixed trunk_dev base.
- Create task-owned external evidence, a closeout report, result, evidence ZIP, manifest,
  receipt, and cleanup record.

PROHIBITED EFFECTS
- No source, document, test, mode, configuration, index-normalization, or status repair.
- No amend, rebase, squash, cherry-pick, reset, clean, branch switch, force push, tag,
  merge, auto-merge, branch deletion, deployment, service/runtime contact, user/product
  database, ES/Bridge/provider contact, or product effect.
- No test skip, xfail, selector reduction, warning suppression, dynamic expectation, or
  validation against unstaged working-tree bytes.
- No claim that zero GitHub checks is a CI pass.

EXPECTED SUCCESS RESULT
RW0_NORMAL_TERMINAL_CLOSURE_STATUS_SUCCESSOR_COMMITTED_PUSHED_AND_PR_OPENED

PROJECT SNAPSHOT
- Do not request or create a Project-source snapshot. Request the next Coordinator snapshot
  only after eventual squash integration onto trunk_dev.

NEXT ACTION
- Return to ChatGPT for integration review and a separately governed squash-merge gate.

0. ENTRY, AUTHENTICATION, AND STOP CONDITIONS

Read this mandate completely before mutation. Before the first Git command, copy the raw
.git/index to a task-owned external evidence root and verify its exact byte identity.
Then authenticate:

1. repository root, branch, HEAD, sole parent, HEAD tree, absent upstream, local trunk_dev,
   origin/trunk_dev, worktree, index, configuration, authoritative refs, and qualified
   diagnostic refs;
2. absence of a concurrent Git writer and absence of index/ref lock files;
3. all 327 live working-source bytes, Git blobs/modes, observed OS modes, source count, and
   reconstructed working tree bc10382edd1b2c097fc729e4e168d72e710391fe;
4. the exact 32-path delta and absence of every added/deleted/renamed/untracked/staged/
   unmerged source path;
5. all six input identities, safe archive central directories, complete self-excluding
   manifests, embedded/standalone report equality, nested predecessor identities, accepted
   source/tree, patch manifests, consumer inventories, validation evidence, audit report,
   and audit evidence manifest;
6. the accepted audit's exact tree, verdict, 32-path list, no-mode-change classification,
   and the corrected 13-direct / 43-focused consumer sets;
7. opening remote state: origin/trunk_dev must equal
   61d0330aba1160f7f5e7d9c541a325222d1c61e5; the remote topic branch and an open PR for
   this topic must be absent. Do not overwrite or reuse an unexpected remote branch or PR.

Stop before staging on any mismatch. Do not normalize the classified 0600 checkout mode,
substitute another checkout or namesake input, rewrite refs, or absorb unrelated work.
Diagnostic turn-diff ref variation may be classified only under the exact retained policy;
it must not select source or conceal an authoritative-ref mismatch.

1. EXACT ACCEPTED PATH SET

Stage exactly these 32 existing paths, and no other path:

.docs/architecture.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/c2b-durable-development-state.md
.docs/c2b2-migration-0002.md
.docs/durable-state-model.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-c2-durable-progression-decision-semantic-contract.md
.docs/rw0-c2-first-live-proof-posture.md
.docs/rw0-c2-physical-p0-p1-implementation.md
.docs/rw0-c2-private-value-versioning.md
.docs/rw0-c2-scope-admission-provisioning-contract.md
.docs/rw0-d1-offline-process-and-capsule-spine.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/rw0-terminal-outcome-physical-closure.md
.docs/software-development-progression-boundary.md
.docs/sqlite-bootstrap-and-migrations.md
.docs/sqlite-operations-and-recovery.md
.docs/sqlite-schema-v1.md
.docs/sqlite-state-backend-adr.md
.docs/worker-execution-boundary.md
.docs/writer-session-authority.md
AGENTS.md
README.md
tests/test_architecture_contracts.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b3c_author_effect_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py

Perform one explicit staging operation over this fixed list. Require:
- no additional staged entry;
- no unstaged difference remaining in the accepted list;
- no unrelated worktree difference;
- no deletion, rename, path creation, or Git-mode change;
- `git diff --cached --check` passes;
- every staged blob, size, and Git mode equals the accepted final source manifest;
- the one successful `git write-tree` returns exactly
  bc10382edd1b2c097fc729e4e168d72e710391fe.

If a staged byte or mode differs, stop. Do not repair it in this gate.

2. STAGED-TREE VALIDATION

Construct a fresh external validation copy solely from the staged tree's 327 Git blobs.
Set numeric OS modes from the accepted source manifest: 0600 only for
`tests/test_c2b3_private_atomic_program_initialization.py`, 0644 for the other 326 files.
Never import or test the live checkout.

Use the installed Python 3.13.4 / pytest 8.4.1 / SQLite 3.49.1 only if they match the
accepted records. Use task-owned HOME, TMPDIR, basetemp, JUnit, logs, and source captures;
restrictive umask; `PYTHONDONTWRITEBYTECODE=1`; `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
empty `PYTEST_ADDOPTS`; `-p no:cacheprovider`; deterministic locale and UTC; and the same
local network-denial posture, with one explicit bind-denial calibration before tests.

Run exactly one collection and one execution of this frozen 43-complete-module selection:

tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_b2a_writer_session_contract.py
tests/test_b3_coherent_transition_fixture.py
tests/test_b3a_persistence_contracts.py
tests/test_b3b1_pure_row_contracts.py
tests/test_b3b2a_read_scope_and_query_contracts.py
tests/test_b3b2b_select_readers.py
tests/test_b3b_reader_prerequisite_contracts.py
tests/test_b3c0a_transition_authority_contract.py
tests/test_b3c1_prerequisite_contract.py
tests/test_b3c3_prerequisite_contract.py
tests/test_b3c4a_transition_write_contracts.py
tests/test_b3c4c_prerequisite_contract.py
tests/test_b4c_public_global_stop_delegation.py
tests/test_c2a_nonimplementation.py
tests/test_c2b0_durable_state_contract.py
tests/test_c2b2_development_reader_contracts.py
tests/test_c2b2_field_level_contract.py
tests/test_c2b3_private_atomic_program_initialization.py
tests/test_c2b3_program_initialization_contract.py
tests/test_c2b3c_author_effect_contract.py
tests/test_c2b3d_author_effect_establishment_contracts.py
tests/test_c2b_pre_io_vs1a_shared_cleanup_foundation.py
tests/test_post_execution_pure_owner_boundaries.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_b2_wire_cancellation_control_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_c2_first_live_proof_posture_contract.py
tests/test_rw0_c2_private_value_versioning_contract.py
tests/test_rw0_c2_scope_admission_provisioning_contract.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_section41_cognitive_proposal_semantic_values.py
tests/test_software_development_progression_boundary.py
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_c2b2_migration_0002.py
tests/test_sqlite_rw0_terminal_migration_0008.py
tests/test_worker_execution_semantic_boundaries.py

Required result:
- exactly 5,655 unique collected IDs;
- collection, execution-call, and explicit JUnit node IDs equal in exact order;
- ordered-ID SHA-256 exactly
  5744b429b031531b5a8c5341c938a3e499e838ba6e9f1f5ddd4238162135e352;
- 5,655 passed setup, call, and teardown phases;
- zero failures, errors, skips, xfails, xpasses, warnings, duplicate or missing IDs;
- no test-node, `-k`, `-m`, inherited addopts, or hidden selector;
- every staged-source byte and accepted numeric mode unchanged before and after collection
  and execution.

The accepted 9,597-test selector-free FULL record is carried audit evidence and is not
rerun in this gate. Do not describe the focused run as FULL or as CI.

Stop if validation fails. Do not edit source, tests, environment expectations, or policy.

3. EXACT LOCAL STATUS COMMIT

After successful staged validation, create exactly one commit with this exact message:

```
docs: record RW0 normal terminal closure status

Record the independently accepted status successor for the locally committed
RW0 normal-terminal closure implementation.

The private artificial-offline owner remains normal-only. This status commit
adds no live supplier, worker/provider, ES/Bridge, product Git, deployment,
cancellation, service, scheduler, or autonomous runtime authority.
```

The commit must:
- have sole parent d3fd741c872b26aa2dfe927ab6dccc638cdcf356;
- have tree bc10382edd1b2c097fc729e4e168d72e710391fe;
- contain exactly the accepted 32-path delta relative to its parent;
- have no signature requirement unless the environment supplies one automatically;
- be created once, with no amend or replacement commit.

After commit, verify every one of the 327 committed blobs and Git modes against the
accepted source manifest. Require a clean worktree and index. The observed checkout mode
exception must remain 0600 without changing its Git mode.

4. PLAIN PUSH AND PR CREATION

Confirm remote trunk_dev still equals the fixed base
61d0330aba1160f7f5e7d9c541a325222d1c61e5 immediately before publication.

Perform one plain push only:

```
git push -u origin codex/rw0-normal-terminal-closure-v1
```

No force option and no additional refspec. Verify local topic, remote topic, and
remote-tracking topic all resolve to the new status commit; remote trunk_dev must remain
at the fixed base. The only ordinary configuration additions may be the topic branch's
`remote=origin` and `merge=refs/heads/codex/rw0-normal-terminal-closure-v1` entries.

Open one non-draft PR:
- repository: evo-agi/Governed-Execution-Coordinator
- base: trunk_dev
- head: codex/rw0-normal-terminal-closure-v1
- title: `RW0: normal terminal closure`
- body:

```
Implements the private artificial-offline RW0 normal terminal closure and records
its independently accepted current status.

Commits:
- d3fd741c872b26aa2dfe927ab6dccc638cdcf356 — feat: add RW0 normal terminal closure
- <STATUS_COMMIT> — docs: record RW0 normal terminal closure status

Validation:
- implementation staged-tree gate: 9,568 / 9,568 passed
- status staged-tree focused gate: 5,655 / 5,655 passed
- accepted status audit also reconciled the 9,597-test selector-free FULL record on
  the exact status tree; this PR creation gate does not claim that as a new CI run

Scope and limits:
- P0, P1, and terminal closure remain separate private fenced facts
- normal-only terminal outcomes: accept, repair, replan, terminal reject, and block
- no active-cancel terminal family
- no live supplier/custody, worker/provider, ES/Bridge, product Git-effect, service,
  queue, scheduler, deployment, or autonomous runtime authority
- no merge or auto-merge requested
```

Replace `<STATUS_COMMIT>` with the actual new commit ID before creating the PR.

Before PR creation, inspect the active trunk_dev ruleset and current remote state. After
creation, verify:
- PR is open, non-draft, unmerged, and auto-merge is off;
- base is exactly 61d0330aba1160f7f5e7d9c541a325222d1c61e5;
- head is exactly the new status commit;
- commit list is exactly d3fd741c872b26aa2dfe927ab6dccc638cdcf356 followed by the
  new status commit;
- the remote PR tree is bc10382edd1b2c097fc729e4e168d72e710391fe;
- reviews, review threads, commit statuses, and check runs are reported accurately;
- zero checks is reported as zero checks, not as a CI pass;
- no merge, auto-merge, branch deletion, deployment, or product effect occurred.

5. PROVENANCE, EVIDENCE, AND CLEANUP

Retain under one task-owned external root:
- all six input identities and authentication results;
- opening/final branch, HEAD, parent/tree, upstream, refs, config, raw and semantic index,
  source/mode, staged and committed inventories;
- exact accepted 32-path classification;
- staged tree, sole write-tree result, commit object/message/tree/parent records;
- complete validation argv, cwd, allowlisted environment, runtime versions, network probe,
  collection/execution logs, ordered IDs, JUnit, warnings, phase reports, and source
  before/after captures;
- push command/exit and remote ref readback;
- ruleset, PR request/body, PR/commit-list/tree/check/review/thread/mergeability readbacks;
- all process errors or unavailable steps, with no hidden retry;
- cleanup and non-effect records.

Write the complete closeout report before sealing one evidence ZIP. Reopen and verify every
member against a complete self-excluding manifest. Produce an adjacent receipt. Remove
only task-owned validation copies and scratch after evidence retention; do not clean the
repository or prior evidence.

6. FINAL RETURN

On success return:

RW0_NORMAL_TERMINAL_CLOSURE_STATUS_SUCCESSOR_COMMITTED_PUSHED_AND_PR_OPENED

Include:
- opening and final branch/HEAD/tree/upstream/index status;
- new status commit ID, parent, tree, exact message identity, and 32-path inventory;
- staged-tree validation counts, ordered-ID digest, warnings, source preservation;
- push/ref/config effects;
- PR number/URL/title/base/head/commit list/tree/draft/merge/check/review/thread status;
- evidence ZIP/report/result/manifest/receipt identities;
- process errors, skipped/unavailable validation, and authority/security widening
  (expected: none);
- next recipient ChatGPT for integration review and a separate squash-merge gate.

End with:
MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
DEPLOYMENT_NOT_PERFORMED
PRODUCT_EFFECT_NOT_PERFORMED

If any opening identity, accepted byte, staged tree, validation result, remote base, or PR
condition differs, stop with a precise BLOCKED result. Do not repair during this gate.
