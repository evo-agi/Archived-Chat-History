**The directory was created, but Codex’s thread is still bound to Coordinator. This time, the entry check stopped correctly without tools—so this is a clean refusal to begin, not another reported audit-process violation.**

Your supplied results establish:

```text
Created directory:
 /private/tmp/rw0-audit-entry.daLWIE

Codex-reported working directory:
 /Users/ds/Repositories/Governed Execution Coordinator
```

They do **not** establish whether the application retained the old project, the folder was added without becoming primary, or the selection failed. No sandbox qualification has started.

## The missing distinction: attached folder versus primary folder

Current OpenAI documentation says that **new chats start in the project’s primary folder**. Adding another folder does not necessarily change that default, and secondary folders remain accessible to the project. The documented setting is **project menu → Edit project → Make primary**. [ChatGPT Learn](https://learn.chatgpt.com/docs/projects?utm_source=chatgpt.com)

My previous instructions should have required checking that setting before starting the thread. **Do not change Coordinator’s primary folder or edit its `AGENTS.md`. Use a separate audit project with only the neutral folder attached.**

## Next action—no more Terminal commands

1. **Create or select a separate local project for the audit.** Use **Add new project / `Cmd+O`** and select the directory you already created:
   ```text
   /private/tmp/rw0-audit-entry.daLWIE
   ```
   OpenAI documents this folder-selection route for Codex. Do not resume the Coordinator thread. [OpenAI Help Center](https://help.openai.com/en/articles/20001615-prism-to-codex-migration-guide?utm_source=chatgpt.com)

2. **Inspect that new project’s folder settings before sending a message.** Under **Edit project**, the neutral directory must be the **only attached folder** and the **primary folder**. Use **Make primary** there if needed. Leave the existing Coordinator project untouched. This is project-context configuration, not proof of filesystem isolation. [ChatGPT Learn](https://learn.chatgpt.com/docs/projects?utm_source=chatgpt.com)

3. **Start a new local chat from that separate project**, then send this exact entry check with no attachments:

```text
SESSION ENTRY CHECK ONLY. No tools or commands are authorized.

Expected working directory:
/private/tmp/rw0-audit-entry.daLWIE

Use only host-supplied session metadata already visible to you.
Do not inspect files, run pwd or Git, list directories, discover instructions,
or launch subagents.

Report the actual host-supplied working directory and any exposed project
or repository binding. Do not infer either from the expected path above.

If the actual directory differs, is unavailable, or the session remains
bound to a live repository, return RW0_AUDIT_ENTRY_NOT_ESTABLISHED and stop.

Otherwise return RW0_AUDIT_ENTRY_METADATA_MATCH, state the actual directory
and any binding information that remains unknown, then stop.

No environment qualification or candidate audit is authorized by this message.
```

Only a matching, no-tool response permits moving on to the **existing environment-qualification prompt and its single evidence ZIP**. Do not send those inputs to the currently mismatched thread.

**If the separate project already shows that exact directory as its sole primary folder, or the described controls are absent, do not repeat the launch again. Send one cropped screenshot showing the project’s folder settings and the new-chat project selector, with unrelated details hidden.** That would let us distinguish an interface mismatch from a binding failure instead of continuing blind retries.

The candidate remains unaccepted; this entry check adds no implementation defect or audit coverage. Pasted text

**Sources:** Your directory output and Codex’s metadata-only response; official project/folder documentation cited above.  
**Confidence:** High on the reported working-directory mismatch and clean stop; the application-level cause remains unverified.
