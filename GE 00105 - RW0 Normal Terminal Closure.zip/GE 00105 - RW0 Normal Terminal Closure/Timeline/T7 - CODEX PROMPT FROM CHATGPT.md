ENGAGEMENT ENVELOPE

CURRENT STATE — The normal-terminal candidate is uncommitted and unaccepted.
The independent audit BLOCKED exact tree
648d332b3ba847deb257a2bb1892a76e4c442675 on S01 (historical witness/binding)
and recorded A03 (bounded exact-type defects). PR #17 remains the integrated
baseline; no terminal candidate has commit eligibility.

RECIPIENT — SAME write-enabled implementation Codex conversation that produced
RW0_NORMAL_TERMINAL_CLOSURE_UNCOMMITTED_REVIEW.zip. The parent is the sole
writer; no subagents. Do not perform this repair in the audit conversation.

ATTACHMENTS — Exactly the original full audit report and audit-evidence ZIP
identified in section 1. The report summary or an engineering relay is not a
substitute for those records. No chat-history export or Downloads search.

AUTHORIZED EFFECTS — Bounded private terminal code, its uncommitted 0008
resource/catalog, owner documentation, directly affected assurance, isolated
synthetic validation, and external review artifacts. No staging, commit,
network, publication, or product effects.

EXPECTED RETURN — A newly identified, uncommitted cumulative repair candidate,
full validation records, one self-contained review ZIP, and its implementation
report. Implementation validation is not independent acceptance.

PROJECT SNAPSHOT — None requested. The integrated PR #17 checkpoint remains the
current committed baseline.

NEXT ACTION — Return the implementation result to ChatGPT. Changed bytes then
require a fresh independent precommit audit, including all outstanding original
A01–A18 obligations and independent selector-free FULL validation.

OBJECTIVE

Repair S01 and A03 together without another broad reconnaissance or a standalone
semantic-contract tranche. Restore the original full closure-time witness
requirement rather than weakening it. Implement the concrete representation and
historical verifier below, revise the governing owner and tests with code,
complete the internal checkpoint, and continue through final validation in this
engagement.

This is authorized defensive correctness work on private synthetic local state.
It does not authorize an attack on a live target, database, service, or provider.

1. INPUTS, EXACT OPENING, AND PRESERVATION

Repository:
  /Users/ds/Repositories/Governed Execution Coordinator/

Require these two audit attachments from this message:
A. RW0_NORMAL_TERMINAL_CLOSURE_INDEPENDENT_AUDIT_MGET70Ie.md
   22,955 bytes
   SHA-256:
   1fffe41981025295b92fe2c6bff00cd0c2e6d5f95b6b8f565b54f2610934dd7d
B. RW0_NORMAL_TERMINAL_CLOSURE_INDEPENDENT_AUDIT_EVIDENCE_DELIVERY_MGET70Ie.zip
   92,001 bytes
   SHA-256:
   e1fd90b32e1987307ba4f8e194d9a1c574a59a6e0de25e9e2a1100edc095331f

Use actual attachment locations, not inferred filenames in Downloads. Inspect
the ZIP safely and authenticate its 44 regular members / 43 self-excluding
manifest entries. Read the full report, the S01 synthetic probe and records,
A03 type probe, A01–A18 register, and stopped-coverage record. Read archived
programs as evidence; port the relevant regression into authorized tests rather
than blindly executing an archived audit helper.

The implementation's retained source root is:
  /Users/ds/.codex/rw0-normal-terminal-closure-ffcda2291fad44ed83515988503a6dd2/

Require its original:
  RW0_NORMAL_TERMINAL_CLOSURE_UNCOMMITTED_REVIEW.zip
  11,648,876 bytes
  SHA-256:
  bf26189fd12b2b27fee847e0c0a1808cfeb568c9255bf48bc1f23ff14e728b0e

Its embedded evidence/IMPLEMENTATION_REPORT.md is 24,543 bytes, SHA-256:
  37ebe55c39739d7440e008d22a9362baed6f01e50dba9e5390be19cdb819b090

Do not require a redundant standalone implementation report. Preserve the
original package, audit inputs, failed attempts and report bytes unchanged.

Exact live opening:
  branch: codex/rw0-normal-terminal-closure-v1
  HEAD: 61d0330aba1160f7f5e7d9c541a325222d1c61e5
  HEAD parent: 4519630d0db967066beb21b4ace5004e76827716
  HEAD tree: 44c7dee402d46b3e16dc389ae0824b4297dfec1f
  upstream: absent
  index: 315 stage-zero entries equal to HEAD; no staged/unmerged entries
  working source: 325 regular paths
  working tree: 648d332b3ba847deb257a2bb1892a76e4c442675
  source-manifest SHA-256:
  3668ca9563f8c818538f2ebf1500421e54ff942ce007a10a40ab57469377f580
  cumulative delta: 67 modified, 10 added, 0 deleted, 248 unchanged
  tracked patch: 134,105 bytes
  tracked patch SHA-256:
  4dfdc30c9674f4629e6ca5ee220bae4b4fddf6eec8ff0387e794526de83ff711

Read root guidance and establish a prospective opening. Before ordinary Git
observations, retain raw index identity externally. Compare safe configuration
identities and complete authoritative-ref maps to the original closeout; keep
semantic index, source identity, raw metadata, and ref observations distinct.
Historical raw-index metadata drift with exact semantic/source anchors is an
explicit limit, not permission to reset anything. Freeze the actual opening
metadata prospectively; block semantic, source, authoritative-ref, configuration,
or source-selection drift. Preserve the ordinary observed origin/HEAD alias.

Qualified diagnostic namespaces remain only:
  refs/codex/turn-diffs/captures/
  refs/codex/turn-diffs/checkpoints/
Retain complete inventories/deltas; additions/removals alone do not replace a
source identity. Surviving-name retarget, invalid target, or dependency on a
diagnostic ref blocks. Do not attribute historical changes to an actor.

Preserve the sole live POSIX-0600/Git-100644 source:
  tests/test_c2b3_private_atomic_program_initialization.py
All other opening source modes remain exact. Never chmod the checkout into
compliance. Do not switch branches, restore, reset, clean, rebase, change refs,
or absorb unrelated edits.

2. FINDINGS AND CLAIM BOUNDARY

S01 is both a representational and a historical-binding defect.
- Current _head accepts only role/owner_ref/revision/digest.
- _current reads full typed rows and drops their other fields.
- Context and outcome persist that projection.
- _historical_exact rebuilds self-consistent terminal rows without independently
  applying the fresh P1/phase head-compatibility predicate.

The audit's UNMODIFIED fresh writer refused a valid later program head as
stale_currentness. A synthetic test-only bypass of the fresh predicate seeded
incompatible but self-consistent history; after restoring normal code, historical
read returned the committed result and recovery returned committed_exact.
Do not describe this as an observed unsafe normal fresh commit or a live attack.

A03 demonstrated allowed str subclasses at _head.role,
TerminalConflictV1.reason, and TerminalRecoveryV1.classification. No authority
or persistence bypass was established. Repair these exact-type boundaries in
the same candidate, not in a separate program.

Prior independent credit is bounded: 34 direct tests passed, INCLUDING the six
connected cases; SQL/admin checks and the stated probes ran. Do not add those
overlapping counts. No independent selector-free FULL collection/execution ran.
All old credit remains tied to the blocked bytes and cannot accept this repair.

3. SELECTED S01 REPRESENTATION — FULL OBSERVED ROWS

Use a versioned complete five-head witness in the TERMINAL CONTEXT.

Keep:
- RecordRW0TerminalOutcomeCommandV1 and its five compact expected-head selectors;
- their exact ordered role/ref/revision/digest grammar and preassignment meaning;
- RW0TerminalOutcomeV2 and its compact five closure coordinates;
- artificial_offline_normal.v1, its five normal outcome pairs and cancel refusal;
- the four existing terminal tables and single phase-unique terminal anchor.

Those compact coordinates remain assertions/projections, NOT the retained full
historical witness.

Replace the blocked context schema with:
  governed-execution.nwp-rw0-terminal-context.v2

In that context's existing closure_heads_bytes field, persist canonical bytes
of this closed envelope:
  schema_id:
    governed-execution.nwp-rw0-terminal-closure-head-witness-set.v1
  heads:
    exactly five entries in program, work, selection, effect, delivery order
    each entry has exactly:
      role: exact built-in role string
      postimage: complete canonical mapping of its actual typed owner row

Each postimage contains ALL fields, including its own schema, identities,
revision, state, updated_at, and self-digest; preserve valid nulls explicitly.
Use the existing closed owner column inventories/adapters:
- program: all 8 DevelopmentProgramHeadRowValue fields;
- work: all 9 DevelopmentWorkItemHeadRowValue fields;
- selection: all 41 DevelopmentPreExecutionSelectionHeadRowValue fields;
- effect: all 9 DevelopmentEffectHeadRowValue fields;
- delivery: all 8 DevelopmentDeliveryHeadRowValue fields.

Inspect the exact owner definitions, not just these counts. Do not discard
fields, replace values with refs/digests, copy a desired plan, or reconstruct
purported observed rows from expectations. Do not use an arbitrary table query,
extension bag, or generic object serialization. Row schemas and digest domains
remain those of their existing owners.

The outer role is not sufficient: verify each postimage's owner identities,
including program/work/effect linkage, against authenticated predecessor facts.
Derive the command/outcome compact coordinates from checked full postimages and
cross-check every duplicated coordinate.

Context v2's digest binds the entire witness bytes. Outcome V2, result, graph,
and receipt must bind that exact context digest transitively. Preserve the
existing graph roles and unaffected schema/digest domains. A context v1 or
projection-only payload cannot qualify as repaired history; do not implement a
fallback that fills its omissions from today's heads or desired plans.

Keep the complete existing closure-stop witness and its closure-time meaning.
Do not equate it to phase-entry/P1-time stop or make terminal recording a new
productive-effect authorization.

Define and test one finite full-witness byte ceiling from the actual closed
field budgets, plus canonical nesting/node/string/cardinality limits. Align
SQL, parser, row adapter, plan, and readback limits. The old 4,096-byte ceiling
must not silently truncate or reject supported maximal five-row witnesses.
Freeze concrete fields/limits/vectors in docs/tests before the first checkpoint;
this is in-scope implementation, not a new handoff.

4. FRESH CAPTURE AND HISTORICAL VERIFICATION

Separate predecessor authentication from closure-head capture. Recovery of
exhaustive absence has no committed closure snapshot and must not fabricate one
merely to satisfy a TerminalFacts constructor.

Fresh terminal record:
- retain receipt-first and existing recording+disclosure gates;
- authenticate the original P0/phase/Section 41/C1/V22/P1 family with the CURRENT
  fenced capability and exact transient original commands;
- read actual current typed program/work/selection/effect/delivery rows;
- capture full postimages directly from those checked reads;
- compare derived coordinates and complete stop to the caller assertions;
- verify normal compatibility with independently authenticated predecessor facts;
- pass the ACTUAL captured witnesses, not a copy of the caller's expected-head
  list, to the plan and immutable context;
- keep the existing context/outcome/result readback, receipt-last, capability
  invalidation, one-commit-attempt, and cleanup semantics.

Create one complete snapshot-compatibility verifier used by BOTH fresh planning
and historical exact-family reconstruction. It must not consult current mutable
heads when used historically. It operates on checked full snapshots plus
checked immutable P1/phase/reached-owner facts:
- program matches P1's complete retained program postimage;
- replan work matches P1's complete retained work postimage;
- nonreplan work matches the proper phase/P1 immutable work identity, revision
  and digest and checked row relationships;
- selection/effect/delivery match independently owned phase/reached-chain
  identities, revisions, and digests, not their own echoed owner_ref;
- use existing row adapters to recompute/validate all own-row digests and field
  constraints; opaque digest strings without a full checked row are insufficient;
- check all program, work, effect-fence, selection, delivery-attempt, and other
  cross-owner bindings required by the existing normal profile.

Use the established owner rules to check references; do not invent a stronger
state machine, chronology, or cancel policy. Do not require reconstructing a
predecessor snapshot from a digest; the full observed row is the retained witness.

Historical record retry, checked read, original recovery, and competing-winner
verification must all:
1. enforce fresh protected disclosure;
2. authenticate persisted context v2 and the full witness grammar;
3. recreate typed rows and verify full own-row digests;
4. reauthenticate immutable predecessor facts with exact transient operands;
5. enforce the SAME normal compatibility rule on saved snapshots;
6. cross-check command assertions, outcome projections, context/row/graph/
   receipt bindings and complete family;
7. only then disclose the original result or classify committed_exact.
A competing winner with an incompatible witness cannot prove definite noncommit.

Do not reread today's five heads or stop for historical compatibility. Later
legitimate movement must not invalidate valid recorded history. No current-head
CAS/update is introduced by terminal recording or replay.

Preserve error discrimination:
- valid fresh current-state drift -> existing no-write stale_currentness;
- missing/malformed rows, failed reads, damaged/incompatible persisted witnesses
  -> safe integrity failure at record/read, not stale_currentness;
- historical reconstruction failure -> recovery unresolved, never committed_exact
  or definitely_not_committed;
- denied disclosure -> existing safe failure/unresolved behavior;
- process-control exceptions propagate through cleanup; no broad swallowing.

5. A03 EXACT-TYPE REPAIR

Before enum membership or equality, require type(value) is str for:
- incoming head role (and any externally supplied role argument);
- TerminalConflictV1.reason;
- TerminalRecoveryV1.classification;
- new witness role/schema fields and adjacent directly exposed terminal enums.

Do not normalize with str(), serialize away a hostile subclass first, or rely
on equality to an allowed literal. Exercise direct Python-value boundaries as
well as canonical decoding. Preserve finite vocabularies.

Require committed_exact to contain an exact TerminalCommittedV1; the other
recovery classes contain None. Do not admit arbitrary non-None objects.

Recheck adjacent NEW terminal value/row boundaries for the same exact-type
pattern; repair only directly related occurrences. Do not refactor unrelated
legacy owners under A03. Include simple str subclasses, equality-spoof objects,
and controls proving hostile equality was not invoked before rejection.

6. MIGRATION AND COMPATIBILITY DECISION

This corrects an UNCOMMITTED migration-0008 candidate. Update that resource in
place for context.v2 and the bounded full witness. Update its literal checksum,
catalog-derived cumulative manifest, and directly affected tests/docs together.
No migration 0009 and no new table family are authorized.

Preserve migrations 0001–0007 byte-for-byte against the authenticated source.
Preserve the frozen schemas/sqlite/coordinator-state-v1.sql fixture.
Keep application generation 2, four terminal tables, eight immutable guards,
zero seeds, unique routes, composite FK bindings, and expected 78/142/5 totals.
Do not remove an integrity constraint to meet a count.

The blocked context.v1/old-0008 schema is historical candidate evidence, not a
supported deployed format. Do not backfill witnesses or silently accept an old
0008 database under the new checksum. All execution uses fresh disposable state.
Verify old-checksum/schema refusal, fresh initialization, explicit supported
prefix migration, exact prior schema preservation, and new payload bounds.
No user/product database or live administrative migration is authorized.

7. GOVERNING FILES AND CHANGE CEILING

Reopen AGENTS.md and relevant owning documentation. Material anchors in the
blocked source:
- _rw0_terminal_outcome_contracts.py:53,114–120,376–414;
- _sqlite_rw0_terminal_outcome.py:141–296,355–483;
- _rw0_terminal_outcome_plan.py:28–39,55–163;
- _rw0_terminal_outcome_rows.py:87–167;
- .docs/rw0-terminal-outcome-physical-closure.md;
- existing program/effect/selection row adapters;
- P1 complete historical reader and retained program/replan-work witnesses.
Python basenames resolve under src/ge_nwp_coordinator/.

Primary authorized edits:
- the four new terminal Python modules;
- 0008_rw0_terminal_outcome.sql and sqlite_migration.py's directly dependent
  catalog/checksum/schema information;
- the terminal physical owner doc and exact directly affected current
  cross-reference/version/status/checksum consumers;
- tests/test_rw0_terminal_outcome_values.py;
- tests/test_sqlite_rw0_terminal_controls.py;
- tests/test_sqlite_rw0_terminal_connected.py;
- tests/test_sqlite_rw0_terminal_migration_0008.py;
- directly affected assurance tests identified before mutation.

Prefer existing modules. One adjacent private no-I/O terminal-head-witness
module and one dedicated terminal regression test module are allowed if needed
to keep responsibilities clear; declare them before creation. Freeze final path
count from actual inventory, not the old 325 count.

Preserve the shared writer/controller mechanics byte-for-byte from the blocked
candidate unless a narrowly necessary delegation-only adjustment is proved.
No change to lease/fencing/COMMIT/cleanup semantics, connection ownership, public
API, or package exports is permitted.

Freeze existing P0/P1 production modules, V1 terminal module/four validators,
WorkSpec, original-command availability rule, Decision Basis v2, P1 acceptance,
D1/D2 child behavior, Section 41/C1 mutators and existing row-value meanings.
Do not widen cancellation, supplier gate B, RW0-E, ES/Bridge, Git effects,
service, scheduler, or autonomy.

Scan all candidate files for affected schema strings, head payload assumptions,
digest/length literals, SQL catalog/counts and status consumers. Record the
dependency map. Preserve fixed current/predecessor assurance; no dynamic oracle,
skip/xfail, arbitrary normalization, or weakening a governing test. Preserve
historical marker blocks and the four-owner shared architecture-map body.

8. REQUIRED REPAIR CONTROLS AND INTERNAL CHECKPOINT

Save and reopen the first substantive checkpoint only after it proves:
- real fenced accept AND replan record/read/replay/recovery on context v2;
- all five persisted full row postimages equal the actual closure-time reads;
- original acceptance fact, P1 family, five mutable heads and stop are unchanged
  by terminal persistence;
- the audit S01 historical counterexample is rejected by unmodified historical
  read/replay/recovery after the test-only seeding bypass is removed;
- all three reported A03 inputs are rejected, with built-in positives preserved.

If strengthened plan validation prevents the old seed helper from creating the
incompatible family, construct that specimen through test-only synthetic SQL/
row sealing. Keep it internally self-consistent with recomputed row, context,
outcome, result, graph and receipt digests so the semantic compatibility predicate
is reached. Do not weaken production checks to permit seeding. Include a valid
history built by the same test mechanism as a discriminating positive. Record
that this is a synthetic historical-corruption control, not a supported fresh
write or a live exploitation claim.

Required finite regression matrix:
A. Five complete source-coherent normal connected positives, plus the detached
   disposition negative and all three cancel-shaped no-write cases.
B. For EACH of five heads: compare every saved field to actual typed reads;
   mutate an omitted-in-old-version field without updating its digest; and
   create a valid-digest but wrong-predecessor row in an otherwise consistently
   resealed terminal family. Historical verification must reject at the intended
   row or relationship predicate; recovery cannot claim committed_exact.
C. Wrong role, owner ref, program/effect/work linkage, revision, schema, state,
   timestamp, nullability, missing/extra/duplicate/reordered field or role;
   old four-coordinate payload; old context v1; noncanonical/malformed/oversize
   payloads; command/outcome projection disagreement.
D. Advance each actual mutable head and stop separately after a valid closure,
   then all together, while preserving immutable predecessors. Exact read/replay
   and committed_exact recovery retain the original snapshots/time and cause no
   movement. Use real owner transitions where supported; otherwise explicitly
   labeled test-only later-state fixtures with valid row digests/relationships.
   They prove historical independence, not a new product transition. Assert no
   current-head/current-stop query is needed by the terminal historical path.
E. Fresh ACTUAL head drift for each role, not just changed caller assertions:
   unmodified fresh writer refuses without terminal rows; malformed/failed
   owner reads stay integrity errors. Active/changed matched stop remains valid
   for fact recording, never execution permission.
F. Complete valid competing winner retains its bounded noncommit proof;
   incompatible/partial/foreign/damaged winner is unresolved. Original exhaustive
   absence still works without inventing a closure snapshot.
G. Receipt-last/readback rollback, one commit attempt, before-commit failure,
   applied commit/lost return, cleanup uncertainty, protected disclosure,
   permission separation, operand absence/mismatch, acceptance nonmutation,
   route/alias collisions, privacy canaries and process-control propagation.
H. A03 direct constructors, helpers, canonical-value boundaries, true builtin
   positives and enum/committed-slot invalid combinations.

Give separate causal credit only when the stated predicate is reached. A digest
failure before a relationship check does not prove the latter; a changed
expectation does not prove an actual owner drift control. Persist a compact
control-to-test/source/reached-predicate register.

Ordinary in-scope development failures may be diagnosed, repaired and rerun
within this mandate. Retain failed/superseded records without final credit.
Do not turn every normal test failure into another user handoff. Stop for scope,
authority, provenance or unsupported evidence requirements, or inability to
complete validation—not merely because an in-scope defect was found.

9. FINAL IMPLEMENTATION VALIDATION

No candidate imports/tests run from the live checkout. Build fresh authenticated
external copies, use task-owned SQLite/filesystem/process state, existing
Python 3.13.4 / pytest 8.4.1 / SQLite 3.49.1, restrictive umask and a verified
network-denial sandbox. No installations. Use -B, disabled bytecode/plugin
autoload, cleared PYTEST_ADDOPTS, -p no:cacheprovider, owned HOME/TMPDIR/
basetemps/JUnit, deterministic locale/timezone, and no warning suppression.

After final bytes are frozen:
1. git diff --check on the repository; no staging.
2. Direct complete terminal modules including all new regressions.
3. Connected complete terminal module, preserving actual pre-capsule source
   variations rather than relabeling D2 outcomes.
4. Focused selector containing all prior 125 complete modules plus every newly
   affected module from the consumer scan. Deduplicate and freeze the order.
5. One successful selector-free repository collection and FULL execution pair
   on the final bytes. No test path/node filter.

Exact command forms from each isolated source-copy cwd:
  <python> -B -m pytest -q -p no:cacheprovider --collect-only
    --basetemp=<owned-collect-dir> <frozen-complete-modules>
  <python> -B -m pytest -q -p no:cacheprovider
    --basetemp=<owned-execute-dir> --junitxml=<owned-junit.xml>
    <same-frozen-complete-modules>
For FULL omit the module list entirely. Record any observational inventory
plugin separately; it must not select, skip, mutate or normalize test outcomes.

Freeze ACTUAL final counts; do not retain 9,542 or other old counts by deleting
tests. Require unique exact collected/executed/JUnit identities and order within
each gate, zero failures/errors/skips/xfails/xpasses, and complete warnings.
Preserve the three known fork-warning records where they occur; investigate and
report any different warning without suppression. Source bytes and numeric
modes must be identical before/after every final gate.

Independently verify SQL/catalog prefix preservation, zero seeds, immutable/FK/
unique/shape guards, fresh and supported-prefix migration, wrong old-0008
refusal, generated cumulative schema and exact-mode preservation.

10. PROVENANCE, DELIVERY, AND AUDIT CONTINUATION

Retain separate exact deltas:
- blocked candidate 648d332... -> repaired candidate;
- integrated tree 44c7dee... -> cumulative repaired candidate.
Capture all source endpoints, bytes/SHA-256, Git blobs/modes and POSIX modes;
independently reconstruct trees without staging or git write-tree. Produce
deterministic final manifests twice from fresh reads and again after bounded
cleanup. Preserve safe index/config/authoritative-ref observations and diagnostic
sidecars, without claiming historical gaps are repaired.

Retain the original report and audit verdict for their exact bytes. A newly
passing implementation run cannot turn the old BLOCKED verdict into ACCEPT.

Produce one report before sealing and embed its exact bytes at
evidence/IMPLEMENTATION_REPORT.md. One self-contained cumulative review ZIP
must contain final complete source, immediate before endpoints, baseline
linkage/deltas, fixed original candidate package or equivalently complete
authenticated predecessor bytes, the two audit inputs, changed contract/vectors,
S01/A03 regressions, reopened checkpoint, control register, full final validation,
source/mode/provenance records, and explicit limits. Preserve failed/superseded
attempts with source bindings; do not credit them to final bytes.

No secrets, private replan text, user state, raw synthetic databases, bytecode,
cache/build artifacts or unclassified OS metadata in delivery. Retain the known
earlier .DS_Store exclusion as history; do not fabricate its absent raw bytes.

Reopen all deliverables and verify the member manifest, embedded report,
source tree and exact bytes. Return ZIP/report size/SHA-256 and an adjacent
delivery receipt. Do not impose a redundant standalone-report gate when the
same report is already authenticated inside the fixed ZIP.

Carry forward the independent audit's unfinished coverage explicitly:
A01–A18 cumulative review, full grammar/relationship/collision/private-operand
matrices, every transitive source reseal, all five-head/stop historical controls,
winner/absence and uncertainty/error boundaries, full privacy/assurance scan,
and independent selector-free collection/FULL on the repaired bytes.
Prior independent direct/SQL execution is historical, not acceptance of changed
context, SQL or runtime bytes.

11. STOP CONDITIONS AND RETURN

Stop and preserve the current candidate/evidence if required input or live
source identity differs; a new authority/owner/profile is required; full safe
row capture cannot meet the owner/privacy contract; fixing the witness needs
changes to frozen P0/P1/row meanings, earlier migrations or runtime ownership;
or validation cannot be completed. Do not normalize source/refs/index, weaken
the witness obligation, fabricate omitted evidence, or issue a partial pass.

Allowed: the bounded edits and isolated validation above, external evidence.
Prohibited: new branch/switch, staging, commit, push, PR, merge, deployment,
network/service/provider/ES/Bridge calls, user/product databases, cancellation
implementation, template store, autonomous retry, or product execution.

Return one:
  RW0_NORMAL_TERMINAL_CLOSURE_S01_A03_REPAIR_IMPLEMENTED_VALIDATED_PENDING_AUDIT
  RW0_NORMAL_TERMINAL_CLOSURE_S01_A03_REPAIR_BLOCKED_<PRECISE_REASON>

Include exact opening/final identity and deltas; complete touched paths; full
witness/version/bound decisions; shared fresh/historical compatibility checks;
S01 discriminating results; A03 exact-type results; migration/checksum/
compatibility changes; checkpoint; exact final commands/counts/ordered IDs/
warnings; mode/source preservation; failed/superseded attempts and limits;
ZIP/report/receipt identities; and:
  INDEPENDENT_AUDIT_NOT_PERFORMED
  STAGING_NOT_PERFORMED
  COMMIT_NOT_PERFORMED
  PUSH_NOT_PERFORMED
  PR_NOT_CREATED
  MERGE_NOT_PERFORMED
  PUBLICATION_NOT_PERFORMED
  DEPLOYMENT_NOT_PERFORMED
  PRODUCT_EFFECT_NOT_PERFORMED

F03/F05 remain inherited nonblocking observations. No independent acceptance,
live terminal/cancel coverage, supplier gate B, RW0-E, runtime permission or
autonomy follows from this repair.
