## Disposition

**Stop this qualification attempt. Do not repair the candidate, retry the sandbox, or ask this session to inspect the checkout again.**

Codex reports another prohibited repository-bootstrap command before qualification began. Reading the request and listing 95 archive members does not establish input authentication or a qualified execution boundary. No qualification report or evidence ZIP exists for this attempt.

This is **not another demonstrated sandbox failure**: the latest response reports no sandbox calibration. The earlier exit-134 problem remains unresolved separately.

The candidate’s acceptance state is unchanged: tree `4691af58ae0ee3107b4e2e9b6b1508032944e357` remains the preserved, unaccepted review subject. This latest command supplies no fresh source/index preservation claim. The preceding incomplete audit likewise established artifact identity, not acceptance or a new candidate defect. Pasted text

## Change the launch procedure—not the audit requirements

My previous handoff stated the right starting constraint but did not make the launch procedure concrete enough. **Another new thread still bound to Coordinator is not the required new environment.**

For this attempt, use a **fresh Codex CLI session launched from an explicitly created neutral directory**, rather than another thread under the Coordinator project. OpenAI documents `--cd` as setting the working directory **before the agent processes the request**. The CLI also accepts an initial prompt, so its first task can be limited to checking already-visible session metadata. [OpenAI Developers](https://developers.openai.com/codex/cli/reference)

This does not prove isolation. It separates two questions that have repeatedly been conflated:

- **Entry:** Did the reviewer actually start in the intended neutral context?
- **Qualification:** Can its eventual parent and child execution be confined as required?

The existing qualification mandate still governs the second question.

## Concrete next action

Run the following yourself in an ordinary macOS Terminal window—not as a command submitted to the failed Codex conversation. It creates one private empty directory and launches the already-installed CLI. It performs no repository operation, installation, configuration edit, or cleanup.

```bash
(
  set -eu
  umask 077
  cd /private/tmp

  if ! command -v codex >/dev/null 2>&1; then
    printf '%s\n' \
      'Codex CLI is not on PATH. Stop here; do not install or substitute a repository-bound session.'
    exit 1
  fi

  audit_dir="$(mktemp -d /private/tmp/rw0-audit-entry.XXXXXX)"
  cd "$audit_dir"
  printf 'Requested audit working directory: %s\n' "$audit_dir"

  codex \
    --cd "$audit_dir" \
    --sandbox workspace-write \
    --ask-for-approval never \
"SESSION ENTRY CHECK ONLY. This is not an audit or environment qualification.

Use no tools and execute no commands. Do not read files, list directories,
inspect Git, discover AGENTS files, open attachments, or launch subagents.

The launcher requested this working directory:
$audit_dir

Using only host-supplied session metadata already visible to you, report:
1. The actual working directory exposed by the host.
2. Any exposed project/repository binding.
3. Any already-loaded instruction that would require repository bootstrap.

Do not treat the requested path above as proof of the actual binding.
Do not inspect the filesystem to fill a metadata gap.

If the host directory is absent, differs, or the session is bound to a live
repository, return RW0_AUDIT_ENTRY_NOT_ESTABLISHED and stop without tools.

Otherwise return RW0_AUDIT_ENTRY_METADATA_MATCH, state any remaining unknown
binding information, explicitly state that no isolation qualification has run,
and stop without tools. Do not start the qualification task."
)
```

The sandbox and approval flags are documented CLI controls; neither is a substitute for the required containment qualification. Do not add a sandbox-bypass flag or expand permissions to make this entry check succeed. [OpenAI Developers](https://developers.openai.com/codex/cli/reference)

**The first response must contain no tool call.** `RW0_AUDIT_ENTRY_METADATA_MATCH` means only that the exposed starting metadata matches—not that filesystem isolation, repository absence, or descendant containment has been proved.

Codex can load global instructions in addition to directory-specific guidance. That is why the entry check asks about already-loaded instructions without authorizing more discovery. The current report does not establish that global guidance caused the prohibited command; that remains unknown. [OpenAI Developers](https://developers.openai.com/codex/guides/agents-md)

## Then continue in that same clean session

Once the metadata-only response matches the generated directory and shows no conflicting repository binding, submit the **existing qualification prompt unchanged** and supply the **same single evidence ZIP**:

:chatgpt-content-reference{index="5"}[Environment-qualification prompt](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Audit_Environment_Qualification_Prompt.txt)

RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_AUDIT_INCOMPLETE_20261028_a0covndn.zip[Authenticated incomplete-audit evidence ZIP](sandbox:/mnt/data/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_AUDIT_INCOMPLETE_20261028_a0covndn.zip)

No additional ChatGPT approval is needed between the entry check and that already-defined qualification task. Do not supply the candidate source or implementation mandates yet. If file attachment is unavailable in the CLI, provide the exact absolute path of the downloaded ZIP; the qualification mandate already permits reading that named file, not searching its containing directory.

If entry metadata is unavailable or contradictory, stop at that specific limitation. If another repository command appears, the attempt has again failed the entry condition; changing directories afterward cannot repair its history.

**No acceptance requirement changes:** the complete qualification controls, amended historical-access contract, outstanding A01–A18 obligations, and independent candidate validation remain required. Keep the implementation conversation idle; no new Project snapshot, source repair, staging, or publication is warranted.

**Sources:** Latest Codex response supplied inline; preceding incomplete-audit record cited above; current OpenAI CLI and instruction-discovery documentation.

**Confidence:** process-state classification **high**; explicit-directory launch is a better-controlled next step, but its actual starting context and effective containment remain to be established.
