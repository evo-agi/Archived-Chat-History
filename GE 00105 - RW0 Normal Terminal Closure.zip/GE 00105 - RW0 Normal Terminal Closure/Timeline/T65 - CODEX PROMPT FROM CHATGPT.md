RW0 NORMAL TERMINAL CLOSURE — CUMULATIVE AUDIT COMPLETION ON FROZEN Qs

This is the sole complete operative replacement mandate. Finish the existing
independent cumulative precommit audit. Do NOT restart architecture, package
history, runner design or implementation. Prior independent results retain their
exact predicate/source scope; missing proof remains missing. The substantive
sections 2–4 below are preserved from the previous mandate so no prompt fragments
must be assembled.

ENGAGEMENT ENVELOPE
CURRENT STATE: Candidate 4691af58ae0ee3107b4e2e9b6b1508032944e357 remains
uncommitted/unaccepted. The latest audit R qualified Qs and performed 13 passing
causal launches / 51 call occurrences, but left required causal/admin cases and
the complete direct/FULL gates unfinished. No current candidate defect was
established. R's INCOMPLETE disposition stays historical.
RECIPIENT: SAME neutral independent reviewer conversation that produced
auditqs-78f604b32c, expected host cwd /private/tmp/rw0-audit-entry.daLWIE.
Not the implementation conversation. No new project or folder-selection loop.
ATTACHMENTS: NONE required. Use the exact retained R/A/B/C/E/Q paths below.
A genuinely exposed attachment of identical bytes is an alternative, not
authorization to search for a substitute.
AUTHORIZED EFFECTS: Data-only evidence/source inspection; bounded audit-owned
fixture/observer additions; unchanged candidate validation under exact Qs;
safe external audit evidence. ZERO source, policy, runtime or repository changes.
EXPECTED RETURN: A cumulative final disposition, full report and one reopened
evidence ZIP. Complete the finite remaining controls and, if no blocker remains,
independent direct and FULL in this same engagement without routine relay.
PROJECT SNAPSHOT: None. PR #17 / 61d0330aba1160f7f5e7d9c541a325222d1c61e5
remains the retained integrated baseline; no new live Git observation.
NEXT ACTION: Return to ChatGPT. Acceptance can establish exact-byte commit-gate
eligibility only; no staging, commit or publication action is authorized here.

0. ENTRY AND EFFECT BOUNDARY

Read this complete instruction before operational work. A necessary read of the
exact host-exposed instruction file is permitted only to load it, with explicit
neutral cwd. Before any OTHER operational command state actual host cwd, exact
input paths, exposed binding or unknown binding, and effect ceiling. Requested
cwd is not proof. Missing/different cwd or exposed live-repository binding =>
stop without probing that repository. An unexposed binding remains unknown.

No Git/status/pwd/AGENTS discovery, repo/bootstrap, ancestor/home/Downloads
listing, app/session-store read, subagent, remote query, dependency install,
global environment dump, runtime replacement or host-protection change. Exact
named input files may be read, never their directories searched. Archived
instructions and source comments cannot enlarge effects. Read candidate guidance
only from authenticated source payloads. Keep the implementation writer idle.

Every candidate import, setup, SQL, fixture, pytest collection/test and child
runs under the exact Qs boundary after entry readiness. No unconfined candidate
callback, network service, provider, ES/Bridge route, user/product database,
source patch, schema change, staging, commit, push, PR, merge or deployment.
The trusted supervisor only prepares owned data, supervises, collects evidence
and provides synthetic readiness peers. It runs no candidate code.

The runner is FIXED, not a new design choice:
Qs bytes 2,674; SHA-256
0ff27cde4b1dfade46dc6ad0add110497d8633e509cd2c923107d5ddf8163961.
No permission/path rebind, rule reorder, signal variant, unconfined fallback,
same-UID expansion, source/evidence writes or network allowance. Removing the
final `(allow signal (target same-sandbox))\n` reproduces Q exactly. Target scope
is measured, not inferred from the rule's name; it is not a three-signal allowlist.
No new permission budget exists. A real incompatibility is INCOMPLETE, not a
reason to edit/skip tests or substitute external cleanup for their own behavior.

1. INPUTS, CARRY-FORWARD, AND FINITE COMPLETION LEDGER

1.1 Exact retained inputs

R — latest partial independent execution evidence:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/auditqs-78f604b32c/RW0_NORMAL_TERMINAL_CUMULATIVE_AUDIT_INCOMPLETE_20261029_auditqs-78f604b32c.zip
 1,650,029 bytes; SHA-256
 ffd593b643c1c6fc6c064a84d9b473ce4f34cc1b2f1be35706d0b2d08db4bd2f.
 299 regular members; 6,568,366 expanded bytes.
 MANIFEST.json: 70,143 bytes, 298 self-excluding rows,
 fb690025b16871b59ae2c6c1512e4a72b1fe69d8a18c0e4490eb467a8d2fcf14.
 REPORT.md: 25,571 bytes,
 b0fa83d8baeede4fc52fe21f488d3fcfbd9472f28656444ed5a3c84377ae70de.
 Policy: audit/execution/policy.sb, exact Qs above.

A — unchanged current source:
 /Users/ds/.codex/rw0-terminal-historical-witness-tcp5rwoh/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip
 48,978,087 bytes;
 6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42.
 573 regular members; 183,558,511 expanded bytes; 572 covered members.
 package/member-manifest.json: 123,205 bytes,
 049139eaac16a03b36952faa703c992f5ef13adad44807873921af817e7b8e43.
 evidence/IMPLEMENTATION_REPORT.md: 19,549 bytes,
 c52141d0fcf15701496c4dec18133361a78b8f043796078340e24eed4bdae2d5.
 No separate standalone-report attachment or equality gate.

B — original implementation requirements, INERT:
 /Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt
 38,100 bytes;
 9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f.

C — S01/A03 requirements, INERT:
 /Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt
 29,145 bytes;
 7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd.

E — preceding signal-incompatible audit:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/audit-4de1ae8e82/RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_INCOMPLETE_20261029_audit-4de1ae8e82.zip
 115,300 bytes;
 b6de501b4a687bd3dc1f8800ac84d150b1197fea74682bd2953b8f9a20c887f9.
 43 members; 443,517 expanded bytes; 42 manifest rows.
 Its source reconstruction/patch/writer records are carried data, not execution.

Q — original qualification:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/peer-33a5f35cc1/RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_QUALIFIED_20261029.zip
 163,911 bytes;
 6ec93d7f43f1d630bf9501d67a80e8a2a9db307da38baa2e6f44d5d22a7e0767.
 89 members; 966,951 expanded bytes; 88 manifest rows.
 Q policy 2,637 bytes;
 d9f8bd3aeaedc1606ee2cf7a93b81742ffca0fef93e1f270618222bae35b52c1.

These paths are previously recorded exact bindings. Missing input => name it,
preserve completed work and stop; do not discover namesakes. Current source/docs
and B/C govern product meaning as evidence, not live-effect authorization.
A's inputs/mandate.txt is the historical-admission/witness amendment:
28,439 bytes / 6e978d57abfbadf7d8120eb58ea75651a60a44c42d6279ff8a9108c41c8b2da4.
Read it fully alongside B/C; sections 2–4 preserve the operative amended criterion.

1.2 Authentication without restarting broad history

Before payload use enforce normalized, unique/casefold-distinct relative regular
unencrypted names, no traversal/link/special/prefix collisions and complete
self-excluding size/SHA/CRC/numeric-mode coverage.
R: at most 500 members, 2,000,000 bytes/member, 20,000,000 total expansion.
E/Q: at most 200 members, 2,000,000 bytes/member, 5,000,000 expanded.
A/necessary nested evidence: at most 5,000 members, 150,000,000 bytes/member,
350,000,000 expanded/archive, depth six, 1,200,000,000 cumulative unique expansion.
Cache identical archive identities. Do not re-expand history without a purpose.

Reauthenticate inputs and rebuild CURRENT source from raw A bytes:
- 327 source paths, tree 4691af58ae0ee3107b4e2e9b6b1508032944e357;
- final-C/final-D/postcleanup manifests byte-identical, 109,923 bytes each,
  SHA-256 1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1;
- 326 OS 0644 and one OS 0600 at
  tests/test_c2b3_private_atomic_program_initialization.py; all Git 100644;
- SQL 0008 stays 30,178 bytes,
  a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254.

Capture any reused source copy before use, including extras; preserve modes.
No Git command is needed. E's lineage/patch and R's corresponding four carried
payloads retain evidence class after exact input/record binding; do not recreate
all earlier source checkpoints merely because this is another engagement.
Historical POSIX null observations are not failures against current source modes.

Read R's complete report, gate summary, launch reconciliation, observer/bootstrap/
launcher versions, causal probe source/details, Qs signal/readiness data, source
captures, process mistakes and cleanup. Retain R unchanged and treat scripts as
inert until inspected and explicitly copied/adapted into audit-owned new files.
Do not blindly execute archived verifiers or cleanup scripts.

1.3 Credit completed work precisely

ChatGPT receiving checks authenticated all R members, reconstructed current A
source and matched R source rows, reconciled all twenty launch records and their
raw outputs/hashes, selected collection/call/JUnit IDs, phase outcomes and source
captures. They found:
- thirteen successful causal launches / 51 call occurrences / zero pytest warnings;
- 44 distinct recorded node-ID strings, with repeated history runs and one debug
  subset; neither this nor nested control counts is a complete-suite count;
- one successful separate synthetic observer calibration, intentionally with a
  warning; six earlier nonpassing/superseded attempts retain no final credit;
- all successful launch-bound audit-helper versions are present in R;
- four copied E data records match E byte-for-byte;
- complete Qs signal controls and original four-role 40-control records reconcile.

This is receiving/data inspection of independent execution records, not execution
by ChatGPT or blanket candidate acceptance. Installed binary hashes, host action
sequence, and filesystem captures remain retained observations, not new host reads.
No complete direct/FULL collection or execution occurred in R.

R may discharge an obligation only through explicit mapping:
requirement → source identity → exact probe/helper version → reached setup/
predicate → raw launch/JUnit/detail evidence → scope/limitation.
Classify as carried independent proof, carried static/data only, new proof needed,
or a reasoned invariant makes the particular scenario inapplicable. A blanket
"R passed" is insufficient. Do not erase completed proof or repeat all 51 calls
without a reason. Prefer refined causal_historical6 for actual stop-shape binding;
historical5 and the debug subset have their narrower scopes.

The imperative controls in sections 2–4 are complete acceptance obligations,
NOT orders to rerun a valid R proof automatically. Complete genuinely missing
coverage; retain any material inconsistency or source finding as such.
All final direct and FULL gates in section 4.3 remain new and mandatory.

Carry-forward groups:
- Constructor/factory/exact-type/alias and nested process-control checks:
  causal_constructor, plus its retained exact source/details.
- Real historical accept/replan, managed-stop denial/malformed/fresh miss:
  causal_historical6; real validators and actual shape wrapper, no successful stub.
- Five-role fresh drift and paired good/bad historical reseals: causal_witness.
- Five preseal normal chains, selected fresh/historical posture, cancel/profile
  exclusion and terminal-row canaries: causal_connected and causal_connected2.
- Four insert/two readback rollback, selected process-control exceptions and
  one applied-commit/lost-return recovery: causal_fault and causal_fault2.
- Seventeen physically occupied columns with disclosed overlap and one [1,1,1,0]
  partial family: causal_routes and causal_routes2, NO isolated-later-route claim.
- Eight literal SQL resources, inventories/prefixes, calendar and selected
  administrative refusals/row controls: causal_sql and causal_sql2.

The generic fresh-posture exception allowance in test_audit_connected_probe.py:
44–50 proves bounded refusal/nonmovement, not every exact error classification.
The generic Exception assertions in test_audit_sql_probe.py:97–100,122–125,135–138
likewise do not establish all error vocabulary. The invalid-time loop at
test_audit_sql2_probe.py:44–48 uses seal_row; its direct checked tuple examples
exercise bad self-digest. Do not overcredit a correctly digested invalid timestamp
checked-row case that did not run.

R's in-process observer is calibrated and nonselecting. Causal bootstrap -k
selection is deliberate for independent probes, never permitted on direct/FULL.
All passing stderr contains the exact classified 60-byte termcap notice; do not
claim empty stderr or suppress novel warnings/errors.

1.4 Finish the finite remaining work — no new architecture or runner tranche

Create one working completion ledger from all A01–A18 rows and the finite controls
in section 3. R's gate_summary is a minimum list, not a waiver of other O rows.
Close remaining cases in the following integration order; combine cases safely
when one coherent fixture proves several predicates.

C1 — source, operand, graph and acceptance relationships
- Finish sibling/domain/assertion/graph/cardinality/repeated-column/alias negatives.
- Independently reseal detached validation/review/source-invocation/proposal
  relationships so the intended owner relation is reached, including a DISTINCT
  forged V22 proposal REF, not only its digest.
- Wrong/missing/foreign selected acceptance facts and a LEGITIMATE unrelated fact
  coexist in the same owned managed STORE. Do not invent a "same hardcoded
  phase/chain" requirement: the original obligation is noninterference.
  Read _sqlite_rw0_terminal_outcome.py:193–199 and
  _rw0_terminal_outcome_plan.py:148–162; selected branch/fact lookup is specific.
  Use coherent checked-owner fixtures/rows and actual FKs/history. No new product
  multirun API, implementation or bypass follows from synthetic setup.
- Complete original transient replan operand mismatch handling across applicable
  fresh/read/replay/recovery entry points. "Same claimed safe identity" does not
  require finding a cryptographic collision. Source _rw0_c2_progression_contracts.py:
  268–313,333–384 validates private text's template_digest and safe projection.
  Supply mismatched claims at genuinely reachable interfaces, preserve real checks
  and distinguish early owner rejection from deeper historical relation proof.
  If exact owner invariants make one desired deeper state unreachable, show the
  dependency and actual boundary result; do not patch hash/validators or call
  an unrelated early digest/FK failure the intended deeper predicate.

C2 — route/family and operational failure completion
- R's physical column probes all populate multiple columns; _route_occupied uses
  short-circuit any at _sqlite_rw0_terminal_outcome.py:262–284. Establish genuinely
  isolatable physical routes and foreign/damaged families with valid paired state.
- Where a later isolated first match is impossible under stated FK/identity
  invariants, document the exact implication: state class, earlier forced route,
  queried value relations, and what physical/invariant proof covers the refusal.
  Do not force impossible valid rows, fake query returns as occupancy evidence,
  demand a digest collision, or silently count overlap as isolated branch credit.
- Complete closed/stale/fenced sessions, stale lease/issuance, real denied SELECTs
  versus malformed tuples across the remaining current owners, cleanup uncertainty,
  precommit/postcommit and recovery variants. Use real controller/owner paths,
  actual injection-hit records, exact error/classification and no writes/disclosure.
  Supplement R's selected process-control seams rather than claim all were covered.

C3 — schema/admin, F01/O1 and evidence precision
- Finish old 0008 SQL paired with current history, unknown/partial/checksum divergence
  and all remaining literal guard/FK/unique/pair/profile/budget checks in section 3.
  Enumerate the exact stored object SQL and history mismatch, not label one missing
  trigger as every divergence. Literal older SQL comes only from authenticated A
  nested predecessors. No product database, runtime swap or 0009.
- Close direct correctly digested malformed timestamp row controls at checked_row
  as well as seal_row where not independently reached. Three actual timestamp
  columns; outcome has none. Keep otherwise-valid parents/self-digests and named
  expected error, not only a generic raises check. Preserve F01's supported scope.
- Complete raw-index/checkpoint/failed-artifact and canary classification without
  dumping private content. Do not retrospectively certify unavailable writer code.

C4 — retain normalized historical-operation observations
- R's test_audit_historical_probe.py:43–185 constructs events/traces and asserts
  their content, but historical_details.json saves summaries, not full arrays.
  Carry its executed assertions; do not claim a supplied complete raw SQL trace.
- As one focused evidence-completion run, reuse/extend the corrected six-case
  historical design to RETAIN safe normalized raw records: connection ID, opener/
  phase, table/column, allow/deny, actual shape-function entry/exit, issuance/
  disclosure events and preattachment SQL verb/mentioned-table classifications.
  Never dump expanded SQL/private fixture literal values.
- Preserve actual unchanged validators, actual operation aliases, calibrated
  authorizers, and raw per-event ordering. Use live real predicate results, not
  successful admission stubs. This does not require repeating unrelated passed
  constructor, signal or calendar cases.
- Reconcile the normalized arrays with summaries and asserts. Any observed
  contradiction becomes a finding/limit; an absence cannot be fabricated.

C5 — complete independent final suites
After C1–C4 and all other mandatory rows are supported, with no material blocker:
run new complete direct collection/execution and selector-free FULL exactly as
section 4.3. Do not rerun the writer-focused 8,266 selection needlessly; FULL
inclusion can cover it. No candidate change or selector waiver.

Fixture difficulty is not a new authority decision. Work through ordinary
audit-only fixture/parser/observer errors in this engagement, preserving earlier
versions/results. Do not stop merely because a remaining-case list exists.
If a genuine dependency, contract ambiguity, protection restriction or practical
execution limit prevents completion, record the specific blocked predicate,
attempted construction, retained checkpoint and unperformed effects honestly.
Do not declare impossible coverage from one unsuitable fixture. Do not produce
acceptance with an unresolved mandatory gap or redefine the task to get a pass.

No routine user relay is needed between C1–C5. A material candidate defect is
BLOCKED and stops acceptance work; an unmet evidence capability is INCOMPLETE.
No background continuation or future-result promise is implied.

2. SUBSTANTIVE REVIEW — THE EXPLICIT TWO-LAYER AMENDMENT

The earlier whole-operation zero-current-stop-SELECT criterion failed under the
old mandate. That blocked result remains true. The engineering decision is to
preserve mandatory shared storage safety, not to skip it to satisfy a terminal
history test. The current candidate is judged against the following amendment:

Layer 1: existing operational admission remains mandatory. Session/process/thread/
lease validity, database binding/custody, BEGIN IMMEDIATE, exact managed schema,
history/catalog/posture and invariants, writer ownership/fencing, and current
protected disclosure remain intact. The existing global_stop_current singleton
shape validator may read that current row only for managed-store validity.
Valid active/clear status, version, timestamp and directive identifiers must not
be compared with saved terminal stop or turned into current effect permission.
Denied/unreadable/malformed managed state may prevent disclosure or leave recovery
unresolved. It must not be misclassified as stale terminal history or definitely
absent original execution. No cache, successful-assessment stub, invariant-skip
flag, alternate connection/controller, or production validator weakening.

Layer 2: historical checked read, receipt-present replay and recovery use saved
full postimages/stop and checked immutable predecessors after admission/fencing.
The five current-head tables are not consulted during the historical operation.
Current-stop reads are permitted only at the existing shared invariant check,
not as a general table-read exemption or later semantic terminal query. Receipt
is first TERMINAL-FAMILY lookup, not first SQL statement. Exact original result,
time, graph, receipt, source associations, protected disclosure, immutable
acceptance binding, complete competing-winner/absence proof and uncertainty
classifications remain required. Historical operations do not require recording
permission or renewed acceptance-unclaimed eligibility. Fresh receipt-miss
recording retains actual current five-head/stop checks unchanged.

This amends only the overbroad current-stop-query requirement. It is not a waiver
of the constructor defect, five-head independence, disclosure, SQL grammar,
transaction safety, audit isolation, or other cumulative acceptance controls.
Verify the two owning documents state the distinction and preserve the old
failure as history; do not create another silent interpretation of either layer.

Inspect at minimum the complete changed witness module, changed tests and docs,
full terminal contracts/rows/plan/SQLite owner, and actual shared admission call
chain (not only wrapper names). Current anchors:
  sqlite_transition_transaction.py:2759–2779,4753–4773
  sqlite_migration.py:2477–2523
  .docs/rw0-terminal-outcome-physical-closure.md:177–220
  .docs/sqlite-operations-and-recovery.md:722–730.
Python basenames are under source/src/ge_nwp_coordinator/; docs under source/.

2.1 Independently test the repaired constructor and mutable aliasing

TerminalHeadWitness at _rw0_terminal_head_witness.py:48–96 must validate ordinary
construction, not only checked factories. Independently test valid direct/factory
triples for accept and replan and all five typed owner roles (8/9/41/9/8 fields,
valid nulls, self-digests). Exact bytes, outer tuples, dictionaries, keys and
scalar types precede hostile comparison/coercion. Bytes, full rows and compact
coordinates must match rather than silently replacing invalid supplied parts.

Require negative controls for the previous malformed type triple and b'{}'/empty
postimages, bytes/list/tuple/dict/string/int subclasses, bool-as-int, wrong arity,
missing/extra/reordered roles or fields, wrong schema/digest, noncanonical and
oversize bytes, and valid canonical bytes paired with DIFFERENT valid rows or
projections. Calibrate a shared/per-instance hostile equality counter, clear it,
and verify zero hostile calls per invalid construction. Preserve built-in
positives and process-control propagation.

Mutate caller-owned maps and separately returned maps, then re-read both views
and canonical bytes and run normal downstream verification. They must remain
checked and unchanged. No unvalidated object token/factory escape or recursion.
Do not demand security against arbitrary reflection/object.__setattr__; that is
not the selected boundary. Verify unchanged wire fields/schema/digest domains
and valid consumer behavior, including exact original P1 replan operands.

2.2 Independently prove complete-operation phase behavior

Use real private WriterSession read, receipt-present record/replay and recovery,
not just a terminal helper. Trace and attach observation/denial at the actual
acquisition/controller opener aliases and account for every operation connection.
The candidate observer labels the full managed wrapper; independently establish
which SQL is genuinely in _verify_global_stop_current_shape. A phase label alone
does not prove shape-only use or permit arbitrary managed-phase stop semantics.

Observe real unchanged validator, ownership-read and issuance/fencing functions;
observation wrappers must call the real function and return its actual result.
Do not replace admission with a successful assessment or patch the predicate
being proved. Capture connection, phase, table/column and allow/deny results.
Calibrate each attached authorizer with owned allowed and intentionally denied
queries. Trace acquisition separately, including any connection work before the
observer attachment, and prove it cannot hide a five-head/later-stop lookup.
A zero-callback claim at the wrong alias is invalid. Column callback counts are
not SQL-statement counts or a fixed product invariant.

Required current-byte controls:
- real fenced accept and replan commits, then coherent later movement of every
  head and valid active/clear stop fixtures; under the layered denial policy,
  exact read/replay/recovery preserve original result/time/witness/graph/receipt
  and acceptance facts without new terminal or protected-row movement;
- original absence with positive/negative old-execution exclusion; complete
  compatible and incompatible competing winners under that same policy;
- deny the ACTUAL managed-stop read during admission: safe operational refusal
  before protected terminal-family handling, recovery unresolved where the
  unchanged controller so classifies; no no-write mislabel as stale history,
  definite absence, hidden retry, committed result or protected disclosure;
- malformed actual stop row or real query-return tuple, with validators intact:
  integrity failure rather than ordinary currentness; fault removal restores
  valid operation; bound process-control behavior remains unchanged;
- fresh receipt miss reads all five actual heads and stop. Stale expectations
  conflict without writes; correctly expected valid changed stop follows the
  current normal-record rule without conferring executable permission;
- denied/expired/foreign/malformed disclosure, closed/stale/fenced session and
  unavailable managed store remain non-disclosing. Fresh recording permission
  stays separate from historical protected disclosure and stop shape.

All synthetic later states/fault seams must be described as such. Do not call
a direct fixture UPDATE a newly supported product operator transition.

3. COMPLETE CUMULATIVE A01–A18 REGISTER AND CAUSAL OBLIGATIONS

Review the entire baseline-to-current terminal change, not only the five-file
repair. Supply exact archive-relative source/doc/test/SQL coordinates, severity,
and evidence class for every row: contract/current code, inspected test design,
retained record, independent execution, inference or limit. Unchanged bytes and
prior passes do not automatically discharge current mandatory controls.

A01 Authority: exactly five private normal terminal facts, separate from P1
 decision/acceptance, standing-policy grants, source facts and executable
 permission. No cancel closure, live supplier/contact, ES/Bridge/Git effect,
 service/scheduler/autonomy or publication authority.
A02 Preservation: legacy terminal V1/four validators, P0/P1 meaning, WorkSpec,
 Decision Basis/command-digest v2, preassignments, D1/D2, generic receipt, public
 StateStore/package exports unchanged. Audit original shared catalog/controller/
 writer-session terminal integration even though this immediate repair froze it.
A03 Grammar/types: closed command/context/outcome/row/result/recovery/witness
 schemas, exact built-ins before equality, canonical UTF-8/JSON and duplicate
 rejection, bool-as-int, safe refs/digests/calendar time, budgets and null pairs.
 Include direct constructors, factory consistency and aliasing; resolve A03/O1.
A04 Identity graph: independent domains/acyclic preimages, four sibling refs and
 route, optional assertions bound in command digest but not preassignments,
 graph role/cardinality/order, self-digest exclusion and repeated-column equality.
A05 Original operands: original P1 command and private replan operand transient;
 complete checked predecessor association required. Missing/inconsistent private
 content cannot be reconstructed from a safe digest or yield false certainty.
A06 Source association: actual checked P0/phase/Section41 A/C1 rank15/V22/P1
 chain and validation/review/proposal/result-set/observation relationships;
 membership counts or digest strings do not independently establish ownership.
A07 Acceptance: bind existing immutable acceptance only for accept; never create,
 mutate or replenish it. Wrong/missing/foreign facts reject. Legitimate unrelated
 facts must coexist without preventing another allowed terminal branch. No
 historical acceptance-unclaimed recheck.
A08 Heads/stop: observed full five-row witness, source/adapters/digests/links,
 replan historical P1 postimages, fresh actual currentness and stop facts; prove
 the precise two-layer amendment, not the withdrawn zero-stop-read property.
A09 Transaction: existing fenced lease/capability/controller; receipt-first
 terminal lookup; one captured time; protected posture/source/current/route
 ordering; context/outcome/result readback, receipt last, capability invalidation,
 one commit attempt, rollback/cleanup uncertainty. No application-head/stop/
 decision/effect update by terminal closure.
A10 Read/replay: original complete result/time/graph/receipt and source/witness
 reauthentication; current protected disclosure with mandatory store admission;
 no five-current-head or later semantic stop query, cognition/process rerun,
 fresh recording permission or acceptance-eligibility requirement.
A11 Recovery: complete exact original family or exhaustive original absence and
 exclusion, or complete compatible winner, only. Partial/foreign/damaged/aliased/
 incompatible families unresolved. No winner result disclosure, hidden retry,
 fragment repair or durable private-template fallback.
A12 Error/cleanup: failed or malformed reads stay operational/integrity, valid
 actual drift stays currentness. Stale/closed/fenced sessions, pre/postcommit,
 applied-commit/lost-return and cleanup uncertainty, KeyboardInterrupt/SystemExit/
 GeneratorExit propagation at the actual fresh/read/recovery/cleanup seams.
A13 Schema/admin: four STRICT immutable normal-only tables/eight guards;
 timestamp grammar, FK/unique/composite links/phase/decision/route occupancy,
 nullable pairs, blob bounds, zero seeds, current catalog/checksum/generation 2;
 exact fresh/prefix migration and old-binary/obsolete-0008/partial/unknown refusal.
A14 Connected normals: actual preseal source variations through real P0/D1/D2/
 Section41/C1/V22/P1/terminal owners; five distinct normal positives and detached
 negative; read/replay/recovery and no forbidden contact or protected-row change.
A15 Docs/assurance: cumulative current-versus-historical status, explicit amendment
 and private scope; fixed source/hash/AST/import/schema consumers and predecessor
 reconstruction retained; no dynamic oracle, skip/xfail or broad guard stripping.
A16 Privacy/artifacts: complete postimages remain safe owner metadata; no private
 replan text, raw capsule/prompts/process results, handles/PIDs/credentials in
 terminal rows or unsafe errors. Grammar review plus independently observed
 canaries; classify raw-index metadata, checkpoints and failed artifacts.
A17 Retained evidence: exact input/source/patch/commands/env/observer outputs/
 JUnit/IDs/warnings/captures and overlapping counts; limits in section 4 below.
 No writer record or causal-register label is independent execution.
A18 Independent validation: reached current-source causal probes and direct
 suite, independent SQL/admin controls, selector-free collection/FULL completed
 with exact IDs, outcomes, warnings and source-mode preservation. No live-state
 or production-readiness inference.

The following controls remain mandatory, including previously unfinished ones:

(a) S01 full-witness family: for EACH role, check complete field capture, valid
 nullable values, supported maximum witness bound, bad owner self-digest, valid
 self-digest with wrong immutable predecessor, wrong owner/link, and actual fresh
 head movement versus changed caller expectations. Use fully resealed synthetic
 histories so owner/context/outcome/result/graph/receipt digests are internally
 valid and the real relationship predicate is reached. Pair every resealer with
 a valid family built the same way. Restore ordinary verification for the actual
 read/replay/recovery. Prior program-only evidence is not five-role proof.
 No truncated witness, v1 fallback, desired-row synthesis or current-row backfill.

(b) Source/operand/acceptance: fully resealed detached validation, review,
 source-invocation and proposal associations, including a DISTINCT forged V22
 proposal reference rather than only a proposal digest; wrong/missing/foreign
 acceptance; LEGITIMATE unrelated acceptance-fact coexistence; inconsistent
 private replan content sharing a claimed safe identity across record/read/
 replay/recovery; no new process or private-text persistence. The single-chain
 fixture's inability to construct an unrelated fact is not proof of impossibility.
 Build coherent independent synthetic state through checked owners, or document
 exact invariant proof and the remaining limitation. Do not credit an incoherent
 split-reader or early FK/digest failure as the intended relationship test.

(c) Disclosure/recording: all selected finite posture predicates, including
 positive, denied, expired, malformed, foreign-bound and absent protected subject;
 old-execution-excluded True/False; truthful claimed False/None after accepted
 P1. Fresh write needs recording AND disclosure, historical operations disclosure
 only; command reuse/assertion mismatch cannot disclose a protected result.
 Complete the expired/malformed/foreign/protected-absence matrix rather than
 inheriting earlier positive/negative permission examples.

(d) Physical routes: derive all original occupancy routes from the checked
 code (the preceding audit identified 17). Seed EACH route physically in a
 separate owned coherent scenario, with valid positives and relevant partial,
 foreign or damaged family states. Mocking query return values alone is not
 physical occupancy evidence. Check exact/winner/absence classifications and
 no winner disclosure or retry. If a route is not representable under an owner
 invariant, prove that with exact schema/contract and record the scope; do not
 invent an invalid row as a legitimate winner or silently drop the obligation.

(e) Transaction and error matrix: faults after each of the four inserts,
 result/receipt readback, receipt-last boundaries, precommit rejection,
 one applied commit with lost return, postcommit and recovery cleanup uncertainty;
 stale lease/issuance, closed and fenced sessions; actual denied SELECT versus
 malformed selected rows across current owners; all three process-control
 exceptions at meaningful fresh/read/recovery/cleanup seams. Assert target
 rows, committed bytes, protected-state nonmovement, and actual injection hits.
 No hidden second commit or automatic retry.

(f) F01/O1 regression: independently exercise raw SQL and row construction,
 not only planner success. Use otherwise valid parent/related state, paired
 valid inserts, independent negative self-digests and the repaired existing
 _time owner. Cover invalid month/day/leap-century/year-zero/time overflow,
 canonical-format deviations, Unicode digits, embedded NUL/whitespace/nontext,
 NULL handling and valid year endpoints. Reach all three recorded_at columns;
 outcome has no timestamp. Verify failed predicates are zero/not permissive
 NULL and high-level invalid row/time behavior stays integrity/unresolved.
 Reproduce the old invalid-month predicate only in owned predecessor synthetic
 state as a grammar comparison, never claim an ordinary writer exploit.
 Recalibrate O1 independently before claiming no hostile equality calls.

(g) Five connected normals plus three unsupported cancel shapes and unsupported
 profile. Source variations occur BEFORE real artificial worker/checker/capsule
 sealing, not by relabelling passed evidence afterward. Use inspected fixtures
 for setup only; independent expected branches/facts/errors are required.
 Observe artificial local process/contact limits and privacy canaries.

Run bounded causal controls before a long FULL launch. Do not start/continue
FULL while a known material blocker already prevents acceptance. Independent
controls must state setup validity, actual reached seam, expected result/no-write
predicate, source identity and limits. Candidate tests passing are not separate
independent oracles. Any mandatory control not established remains explicit and
prevents complete acceptance unless an exact supported invariant makes the case
inapplicable; fixture difficulty alone is not such an invariant.

Independent SQL/admin expectations:
  after 0006: 68 tables / 122 triggers / 5 explicit indexes
  after 0007: 74 / 134 / 5
  after 0008: 78 / 142 / 5, application generation 2.
Execute all eight authenticated literals in disposable owned state. Preserve
pre-0008 object SQL/shape; check exact prefix upgrades, no seeds, immutable
update/delete guards, FK/unique/pair/profile/normal/blob/time constraints, and
refusal of old binary, original and S01-era 0008 checksums, old SQL with current
history, missing guard, foreign object and partial/unknown/checksum divergence.
No current schema/contract change, 0009 or product database upgrade is allowed.

4. RETAINED EVIDENCE AND INDEPENDENT VALIDATION

4.1 Reconcile the current writer records as DATA

Paths: evidence/validation/<direct|connected|focused|full>/, gate-summary.json,
phase-read-map.json, supersession-record.json and current source captures.
Require independent parsing of collection observer, execution collection,
setup/call/teardown records, explicit JUnit nodeid properties, actual launch/exit,
stdout/stderr as actually retained, warnings, and four complete source captures
per gate. Do not invent a separate stderr file for a combined log.

Expected current retained gates:
  direct: five complete modules / 60 cases / zero warnings
  connected: one complete module / six cases / zero warnings, inside direct
  focused: 126 complete modules / 8,266 cases / three known warnings
  FULL: selector-free / 9,568 cases / three known warnings.
All narrower sets must be included in FULL; totals overlap and do not add.

Ordered-ID SHA-256 uses UTF-8 JSON array, ensure_ascii=False,
separators=(',', ':'), with NO trailing LF:
 direct 229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467
 connected 81e14e3fa1b85a7be2ea6fafac85974839145bbcb6397e6da0bb1feeba060aac
 focused 419d37ff399689788123583f614a1d8b107ef712e2368ca179cd6e65fbec5104
 FULL 25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9.

All sixteen source captures have the same 105,550-byte envelope, SHA-256
0c0b4017371a798731a63825ac63922c361189e37f5a713f5c4f7ec06e9b32cb.
Require full row equality to the different canonical source-manifest envelope,
its embedded canonical hash, correct final tree and no extra/missing paths.

The retained direct JUnit phase maps report six operation connections, 60
managed-stop column callbacks and six intentional head-denial calibrations
for EACH accept/replan scenario. Independently parse the raw properties. Do not
substitute those counts for actual phase/call-chain verification, or label them
SQL-statement counts. Acquisition has separate test observations.

4.2 Known retained-evidence limits — do not silently fill them

The active external gate_observer source and a launch-bound helper digest are
not retained in the current outer ZIP. Old nested helpers cannot prove that
current code's identity. Writer records can be internally reconciled but their
observer's nonselecting implementation is not thereby inspected. The independent
runs below must use newly audit-authored, retained, inspected and calibrated
observers. Independent fresh evidence can establish current behavior; it does
not retroactively establish the missing writer helper.

The seven-case checkpoint has receipt/JUnit evidence and a different declared
tree 85c9fea24f4f74f358f9cc59a5d323d836a04041; it lacks a complete checkpoint
source payload here. Its historical save/reopen/source-binding claim stays
qualified and supplies no final-byte credit. Similarly, one retained patch
manifest per kind is not proof of two writer runs; independently reconstruct
current endpoint/patch identity rather than invent that history.

These are disclosed retained-evidence/process limits, not automatic production
findings. Determine their actual acceptance impact. Complete current independent
source/runtime evidence must not be replaced with writer claims. Any unmet
mandatory evidence requirement is INCOMPLETE, not a pass by wording change.
Preserve failed/superseded source/test results separately. The prior audit's
live-status/path probes and interrupted FULL remain historical limits.

4.3 Required independent execution gates

After source review, new constructor/two-layer controls, the complete cumulative
finite causal matrix and SQL/admin controls reveal no material blocker:

1. On a fresh exact source copy, collect and run these five COMPLETE modules in
   this order (no node selector):
   tests/test_rw0_terminal_outcome_values.py
   tests/test_rw0_terminal_head_witness_regression.py
   tests/test_sqlite_rw0_terminal_controls.py
   tests/test_sqlite_rw0_terminal_migration_0008.py
   tests/test_sqlite_rw0_terminal_connected.py
   Expected 60 ordered unique passes, including six connected cases.
2. On another fresh exact 327-file copy, independently collect and run the
   repository selector-free FULL. Expected 9,568 ordered unique IDs and passes
   in the retained FULL order. No path, module, node, -k or -m selection.
3. Record collection/execution-collected/call/JUnit identities, explicit JUnit
   nodeid properties from the start, all setup/call/teardown results, warnings
   and real process exits. Require exact ordered agreement and zero failure,
   error, skip, xfail/xpass or failed noncall phase. An invertible JUnit mapping
   is useful supplementary evidence, not a silent substitute for the required
   explicit-property observation.
4. Independently inventory warnings. Direct has none; FULL may have only the
   three known DeprecationWarning multithreaded-fork nodes in
   tests/test_sqlite_b2c_writer_session.py:
   test_operation_guard_close_waits_and_retains_authority_until_exit
   test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
   test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock.
   Owned paths/PIDs may differ; other class/node/message differences require
   investigation, not filtering or suppression.
5. Capture complete raw bytes/modes/extra-file inventory immediately before and
   after collection AND before and after execution, with source-tree rebuilds.
   All 327 endpoints and modes must remain unchanged, without generated extras.
6. Audit probes remain outside candidate discovery and separately counted. An
   independent focused 8,266-case rerun is unnecessary if exact FULL inclusion
   is proven; do not claim one ran. No writer FULL or earlier audit count can
   replace the independent completed FULL.

Use recorded equivalents of:
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --collect-only --basetemp=<owned-collect> <complete-direct-modules>
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --basetemp=<owned-run> --junitxml=<owned-junit> <same-direct-modules>
For FULL remove all module/path/node selectors from BOTH commands. Inspect
pytest config, conftest and setup/child-launch seams before import. The observer
may record IDs/outcomes/warnings and add JUnit nodeid properties, but must not
select, reorder, skip, change assertions/results or suppress warnings. Keep its
exact source/digest in the evidence and bind every launch to it.

Do not edit candidate source/tests to get green results. Correct audit-only
parser/fixture/observer mistakes transparently on fresh owned state, retaining
failed attempts. A genuine candidate failure triggers findings, not retries with
weakened oracles. An interrupted FULL gets no complete-pass credit; preserve
actual partial records and absence of final JUnit/observer rather than infer
completion from displayed percentages.

5. EXECUTION CONTINUITY — FROZEN Qs, NO FURTHER POLICY PROGRAM

5.1 Owned layout, current identity and same-policy entry readiness

Expected host cwd remains /private/tmp/rw0-audit-entry.daLWIE.
All prospective files stay under the existing policy root:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz

Use one fresh unique completion suffix under its already permitted execution,
mock_source, scratch, home, tmp, evidence and denied subtrees. Do not alter Qs
absolute roots or any policy byte. Preserve all earlier namespaces and inputs;
R's old scratch/home/tmp/denied were cleaned, so do not assume fixtures survived.

Rehash active Qs and installed runtime around launches. Fixed entry:
 /Library/Frameworks/Python.framework/Versions/3.13/bin/python3
Expected Python 3.13.4 / pytest 8.4.1 / SQLite 3.49.1. Distinguish requested
symlink, resolved wrapper and native interpreter. Preserve the existing
process-local __CF_USER_TEXT_ENCODING treatment without editing host settings.
Runtime mismatch is a binding limit, not permission to install or change it.

Trust only current artifact bytes and newly captured copies, not presumed prior
filesystem presence. Source copies in mock_source/<id>/master,/causal,/direct,
/full are all exact 327-file A with numeric modes preserved. Execution/observer
code is read-only by policy, provisional output/DB/test state under scratch/home/
tmp, final protected evidence under evidence. Do not put source, helper code or
governing inputs in candidate-writable paths. No .git, user DB or credentials.

Inspect R's active bootstrap/observer/supervisor/probes and their launch-bound
versions before adapting. Explicitly permitted: copy inspected audit-authored
source into a new versioned helper, adapt ONLY owned paths, additional finite
probes and evidence retention, retain before/after identity and every failed
attempt. Do not run archived packaging/provenance/cleanup or historical candidate
helpers wholesale. No framework/platform rewrite is requested.

Carry R's Qs policy review and scoped signal results as independently executed
evidence at their measured scope. New layout entry readiness stays inside THIS
audit, not a separate qualification tranche: exercise trusted marker/SQLite,
the original four-role forty-control matrix and scoped signal readiness using
the inspected existing designs, under exact Qs and newly owned synthetic state.
No historical failed-policy search, OS-log hunt, policy variant or permission
budget. If readiness passes, immediately proceed with completion. If it fails,
separate correctable new-helper error from actual boundary failure and preserve
precise evidence. Do not ask for routine approval to continue.

Preserve all original controls and target discipline:
- actual permitted source/launcher reads and scratch round trip;
- ordinary outside-inner accessibility first; actual permission denials for
  source/launcher/evidence/denied writes, replacement/deletion/creation and aliases;
- a same owned, externally functioning nonce-handshaken listener before/after all
  roles; actual bind/connect EPERM/EACCES, never unavailable peer or errno42 credit;
- no peer/socket FD inheritance, no external address/DNS/service/user path probes;
- handshaken owned direct/fork/exec/descendant/session/group signaling and reaping,
  TERM-ignore/KILL before release, no emergency-supervisor substitution;
- live outside and independently instantiated identical-Qs nonmember targets
  remain responsive after denied PID/group attempts. Record actual semantics,
  not claims about rule names, whole user identity or all possible descendants.

Any emergency external termination is confined to explicitly created/tracked
synthetic PIDs/groups; it is never candidate success. Reap/close all synthetic
subjects and peer before candidate gates. Source tests may signal only their own
workload as enforced by Qs; no tests are skipped or monkeypatched to fit the runner.

5.2 Candidate launch, nonselecting observer and final evidence

Every import/SQL/fixture/collection/test launch uses:
 /usr/bin/sandbox-exec -f <exact-Qs> <fixed-python> -I -B <audit-bootstrap> <mode>

Record exact argv/cwd/environment, pre/post helper/policy/requested/resolved/native
runtime identities, source manifest/tree, wall+monotonic times, PIDs/groups,
timeouts, raw separate stdout/stderr, exit/signal and tracked closure.
Use umask 077, zero core size, null stdin, close_fds=True, empty pass_fds,
owned HOME/TMPDIR/basetemp/output, C locale, UTC, credential-free allowlist,
PYTHONDONTWRITEBYTECODE=1, PYTHONNOUSERSITE=1,
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, PYTEST_ADDOPTS="", and -p no:cacheprovider.
No ambient import roots or unrecorded selector/warning suppression.

Retain an inspected -I bootstrap adding only exact authenticated source root,
source/src and read-only audit-observer roots. Candidate-owned children without
-I may use frozen PYTHONPATH to those same roots only. Do not edit candidate
imports or assertions. Inspect any new executable/signal/file dependency before
running it; exact Qs remains the ceiling.

The observer records emitted/final collection, setup/call/teardown, warnings,
actual exits and explicit JUnit node-ID properties. `rw0_audit_nodeid` is the
established property name. It must not select/reorder/skip, transform a failure,
suppress a warning or alter a product assertion. Recalibrate retained/adapted
observer source on independent synthetic cases before candidate collection,
including intentional warning recording. Bound every launch to exact observer
bytes. Causal -k selection is confined to audit-authored finite probes; never
carry it into the complete direct/FULL commands.

Use frozen complete direct module order and FULL/no selector from section 4.3.
Freeze the final-suite inventory from actual collection; 60/9,568 and ordered
digests are expected anchors, not permission to drop unexpected cases. Any drift
requires explanation, not count adjustment. Record all actual attempts. Do not
start or continue a long FULL when a material candidate blocker prevents acceptance.
Choose and record a bounded timeout appropriate to the retained workload, not the
synthetic readiness timeout. If interrupted, keep partial records without FULL credit.

Capture all 327 bytes/modes/extras immediately before/after collection and before/
after execution, rebuilding the tree each time. Four captures per gate, not only
a closing hash. Audit-owned probes stay outside candidate discovery and separately
counted. Preserve failed parser/fixture/observer attempts without test credit.

Provisional JUnit/observer output remains candidate-writable scratch until the
trusted supervisor captures actual stdout/stderr and exits, observes/reaps owned
children, hashes and transfers outputs into protected evidence. The in-process
observer is instrumentation, not an adversarial attestation service. Independent
expected outcomes, source review and protected supervisor records remain required.
Classify the fixed termcap stderr exactly without suppressing different output.

For every new causal case retain:
source/fixture/code identity, independent expected predicate, setup validity,
actual injection or query hit, stage reached, outcome/error classification,
target/protected row counts and identity, disclosure/nonmovement, and limits.
Raw normalized trace events must match their summaries when C4 applies.
No private template/capsule text, raw DB/sidecars, credentials or unclassified
logs in delivery. Safe nonsecret canary labels/hashes are sufficient.

6. FINAL ADJUDICATION AND DELIVERY

The old R INCOMPLETE verdict remains unchanged. Assemble one explicit cumulative
evidence ledger separating:
- carried independent executed proof on this exact candidate;
- carried static/source/provenance and writer records;
- new independent proof;
- exact supported invariant/inapplicability arguments;
- unresolved mandatory gaps and nonblocking observations.

Do not report R's execution as newly rerun, add overlapping counts, silently
upgrade generic error assertions or reconstruct missing raw streams. Include the
exact R input itself in the new evidence ZIP so carried proof is inspectable;
do not embed A's large source/history packages or all old qualification archives.
New package checks may account for that one 1.65 MB R member explicitly.

Return one primary verdict:
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED
 AUDIT_PROVENANCE_MISMATCH
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE

Acceptance requires exact current source authentication, compliant effects,
supported complete A01–A18/causal/admin coverage, F01/O1/S01/A03 and amended
historical relation, and completed new independent direct/FULL under Qs with
exact IDs/outcomes/warnings and source/mode preservation. A proven invariant
may delimit an impossible proposed specimen; it cannot erase an untested
reachable obligation. No mandatory gap becomes "nonblocking" to obtain acceptance.

Findings identify severity/type, owning contract, current source path:line,
observed/reached predicate, positive pairing, uncertainty and source-vs-audit
status. No unsafe fresh commit claim without an actual ordinary fresh-path
demonstration. F03/F05 remain inherited nonblocking observations, not repaired.
Earlier blocked bytes, failed predicates, procedural deviations, missing writer
observer, checkpoint limits and interrupted validation stay historically scoped.

Save a full unique report BEFORE sealing ONE compact safe evidence ZIP. Include
the report byte-for-byte, self-excluding member manifest, frozen Qs and authored
helpers/observer/probes, exact R carry-forward plus index, input/source/capture
checks, full closure ledger, actual new causal/SQL results, raw invocations/
stdout/stderr/exits/JUnit/IDs/warnings/normalized traces, process mistakes and
precise unfinished coverage, and owned cleanup/non-effects. Reopen every member.
Return actual report/ZIP/manifest byte sizes and SHA-256 values, with an adjacent
delivery receipt; the ZIP does not contain its own final hash as an obligation.

After evidence transfer remove only explicitly created prospective transient
probe state; preserve old namespaces, source copies, governing inputs and
protected records. Report actual process cleanup without claiming universal
unobserved descendant custody.

The exact subject for any eventual acceptance is only
4691af58ae0ee3107b4e2e9b6b1508032944e357.
No live exact-byte gate, staging, commit, push, PR, merge, publication, release,
deployment or product effect follows in this conversation. Return to ChatGPT.
