RW0 AUDIT ENVIRONMENT — PEER-CALIBRATION HELPER CORRECTION AND FINAL QUALIFICATION

This is the sole complete operative replacement instruction. Read it fully before
operational work. This is authorized defensive qualification using owned synthetic
state only. It is NOT a candidate audit, repository task, policy-expansion program,
or instruction to execute any archived helper.

ENGAGEMENT ENVELOPE
CURRENT STATE: The last interval returned
RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_INCOMPLETE_LOOPBACK_PEER_UNAVAILABLE.
Restrictive true and Python entry succeeded; parent/fork/exec/fork-then-exec
records each contain 39/40 passes. Connect was not attempted because the peer
helper raised an unlocalized OSError(42). No final containment verdict exists.
RECIPIENT: The SAME neutral qualification conversation that produced
rw0-ancestor-ts3q9uuz. Expected host cwd: /private/tmp/rw0-audit-entry.daLWIE.
Do not start another conversation/project or use the implementation conversation.
ATTACHMENTS: None required. The exact retained ZIP below is the sole input.
AUTHORIZED EFFECTS: Inert input inspection, new audit-owned calibration/supervision
code, fresh synthetic filesystem/loopback state and evidence. ZERO policy changes.
EXPECTED RETURN: One inline result and one compact reopened evidence ZIP.
PROJECT SNAPSHOT: None.
NEXT ACTION: Return to ChatGPT before candidate execution, including on success.

1. ENTRY AND EXACT INPUT

A necessary read of exactly this host-exposed instruction file is permitted solely
to load the mandate, with explicit neutral cwd. Before any other operational
command state the actual host cwd, exact input path, exposed project binding or
unknown binding, and effect ceiling. The requested directory is not proof of the
actual host directory. A missing/mismatched directory or exposed live-repository
binding is a stop. No pwd/Git/AGENTS discovery, ancestor search, home/Downloads
listing, app/session-store read, subagent or global environment dump.

Retained input:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_INCOMPLETE_LOOPBACK_PEER_UNAVAILABLE_20261029.zip
Bytes: 148,210
SHA-256: 76e33ec28c3468d44987aae4cf27ab06675ae00df21c50fc998cc68140ea569f

A genuinely host-exposed attachment of the exact bytes is an alternative only if
supplied. Do not search for substitutes. Missing input => precise incomplete stop.

Check the central directory before payload use: at most 200 members, 2 MB/member,
5 MB total expansion; relative normalized unique and casefold-distinct regular
unencrypted files, no traversal/link/special/prefix collision. Expected:
118 members, 667,857 expanded bytes, 117 self-excluding MANIFEST.json rows.
Verify every row's bytes, SHA-256, CRC/readability and numeric mode.

Fixed payloads:
- QUALIFICATION_REPORT.md: 14,749 bytes;
  a6aad94483ea1dff818ec4039073bca179ab3785df54d605ead9b41497c58b88
- MANIFEST.json: 25,705 bytes;
  82c8b6f069b558de31f2de6bef325da00a7f38eb5edfd1594dfa8f7444899b80
- execution/policy_ancestor_complete.sb: 2,637 bytes;
  d9f8bd3aeaedc1606ee2cf7a93b81742ffca0fef93e1f270618222bae35b52c1
- execution/launch.py: 12,406 bytes;
  9c6f0f4ee70273f9acdbf40ede4f555b36b451bde34608c7bebaab19cf9d2da4
- evidence/launch_before_peer_failure.py.txt: 11,772 bytes;
  2c68269d4065038c3a0c2da61a1d34337bbd8e74820d5c00eaa8ff004479cb2f
- execution/synthetic_matrix.py: 14,323 bytes;
  669009265b226fb452ca79310372c7c86fce2abb1090afe8d50674fb98556613

Read the report, POLICY_REVIEW.md, runtime/ancestor ledger, launcher, original and
repaired matrix sources, actual run records/raw outputs, sentinel and cleanup
records as DATA. No recursive historical reconstruction or old helper execution.
Preserve all old files, outcomes and incomplete verdicts.

2. FINDINGS AND SELECTED METHOD CORRECTION

Source finding P01:
execution/launch.py:88-104 creates, binds and listens on a socket; then connects
an owned client and accepts it; then calls
listener.getsockopt(socket.SOL_SOCKET, socket.SO_ACCEPTCONN) at :101 BEFORE
returning the peer. The same query is used again at :151 during cleanup.
The :113-119 OSError catch stores no failed stage or traceback. Therefore the
recorded peer=null / errno42 does not establish that bind/listen/connect/accept
never succeeded. The old report's "no listener established" is not proved.

Separate external corroboration, not local reproduction:
Apple's errno definitions associate 42 with ENOPROTOOPT; the getsockopt reference
describes that error as an unknown option at the given level. SO_ACCEPTCONN is a
specific suspect, not a demonstrated historical failed call. No web access or
new platform probe beyond this mandate is needed.

Source finding P02:
setup_peer lacks unconditional cleanup for partially constructed sockets, and a
failed setup leaves the caller's peer variable None. Old supervisor exit is
recorded; no claim of a socket surviving that exit is made. The new helper must
record ownership and close every acquired socket on all paths.

Engineering selects:
- actual owned connect/accept plus bounded nonce exchange as the peer-readiness
  oracle, before and after the contained matrix;
- stage-specific socket/error records;
- no SO_ACCEPTCONN dependency in readiness, qualification or cleanup;
- optional ONE explicitly separate SO_ACCEPTCONN diagnostic after successful
  readiness, with the exact returned value/error recorded, not a required gate;
- complete rerun of the original qualification matrix, not connect-only credit.

This changes the calibration method, not the required network-denial property.
No prior unperformed control is relabeled passed; no local error cause is invented.
Do not change the sandbox, OS settings, runtime or host/tool protections.

3. EXACT POLICY FREEZE AND OWNED LAYOUT

Use the SAME 2,637-byte policy, SHA-256
d9f8bd3aeaedc1606ee2cf7a93b81742ffca0fef93e1f270618222bae35b52c1.
No added permission, reduction, path rebinding, changed rule order, allow-default
control, or policy trial is authorized in this task. Reinspect its actual surface
and previous ledger; if it cannot support the required safe proof, report incomplete
rather than repair it here.

Existing policy root:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz

Prospective owned-state amendment: unlike the prior fresh-root instruction, create
a new unique continuation namespace UNDER the already authorized subtrees so the
policy bytes need not change. Use the same unique suffix in fresh child locations:
execution/<suffix>, mock_source/<suffix>, scratch/<suffix>, home/<suffix>,
tmp/<suffix>, evidence/<suffix>, denied/<suffix>.
Create only these owned descendants, with a manifest of exact paths. Do not reuse
or overwrite old sentinel/helper/output names, revive old probe results, enumerate
unrelated directories, or remove prior evidence. The previous cleanup removed
old sentinels; new state gets new identities. The policy's existing execution and
mock_source reads and scratch/home/tmp writes cover these descendants. Evidence
and denied content remain ungranted. If an unexpected path/permission dependency
arises, stop instead of editing the policy.

Read policy bytes from the authenticated archive as inert input, inspect them,
then freeze a byte-identical copy at a new execution path. The active supervisor,
peer helper and matrix must be newly authored and inspected, not executions of
archived scripts. Their designs may reuse understood bounded logic.

Retain the inherited policy review limits: root-directory entry exposure from the
literal "/" read and broader installed Python/system runtime read subtrees;
process-fork/process-exec but no unrestricted signal; sysctl-read; source/input
read-only; scratch/home/tmp writes; evidence/denied content ungranted; deny network*.
Finite sentinel passes alone do not prove all possible OS behavior.

4. RUNTIME AND SUPERVISION

Existing runtime only:
Python 3.13.4 / pytest 8.4.1 / SQLite 3.49.1.
Required external entry:
/Library/Frameworks/Python.framework/Versions/3.13/bin/python3
Recheck narrowly using stdlib and installed metadata, never candidate imports or
pytest collection. Record requested symlink, resolved wrapper and actual framework
image distinctly. No installation, runtime replacement or native-image shortcut.
If sys.executable differs, cover its actual descendant launch as well.

All commands: explicit neutral/owned cwd, umask 077, C locale, UTC, bytecode
suppression, owned HOME/TMP, allowlisted credential-free environment, null stdin,
closed incidental descriptors, no core dumps. Preserve the process-local handling
of __CF_USER_TEXT_ENCODING; do not change host settings or dump ambient state.

Keep separate:
- trusted external driver/supervisor/owned loopback peer under unchanged host/tool
  protections, without the ADDITIONAL restrictive policy;
- confined synthetic target and all its tested descendants under the exact policy.

The trusted side is authorized only to prepare owned state, supervise, collect
records and provide this synthetic loopback peer. No candidate or real service
may execute there. Do not route a host refusal around another tool or permission
profile.

Use bounded wall and monotonic deadlines at socket, child and supervisor levels.
Bind actual argv/cwd/environment, helper/policy/executable pre/post hashes, driver/
supervisor/target PIDs, raw binary outputs, exits/signals and marker identities.
Close/reap only owned sockets/processes/groups on success, failure and timeout.
No peer or accepted socket FD may enter the confined target: record non-inheritable
state, close_fds=True and empty pass_fds. Do not rely on garbage collection for
explicit socket cleanup. No thread is required; keep supervision compatible with
the tested fork seams and fully close any owned peer thread if one is used.

5. STAGED PEER CALIBRATION — SAME ENGAGEMENT

Do not launch the full contained matrix until readiness succeeds. Newly author a
small peer helper with a separate before/after event for EVERY socket operation:
socket creation, timeout setting, bind, listen, getsockname, client creation,
connect, accept, nonce send/receive, close, and the optional option query.
Include actual numeric family/type/protocol/option constants, loopback endpoint,
socket handle/ownership, monotonic/UTC time, return value, exception class, errno,
errno-name mapping and a safe owned-code traceback for any exception.

Bind ONLY AF_INET/SOCK_STREAM on literal 127.0.0.1 and an OS-assigned ephemeral port.
No DNS, IPv6 fallback, wildcard bind, fixed existing port, external host, real
service/provider/ES/Bridge endpoint or alternative network technology.

Positive readiness:
a. Create the listener, bind 127.0.0.1:0, listen with enough backlog for all finite
   controls, and record its assigned host/port and valid descriptor.
b. From a second owned socket under the SAME outer protections, connect to that
   exact endpoint, accept on the listener, verify both endpoint identities, and
   exchange a short unique nonsecret nonce. Bound every wait and byte length.
c. Close this accepted/client pair explicitly; keep the SAME listener open.
d. Optionally query SO_ACCEPTCONN once solely to localize the suspected unsupported
   option. Record its result independently. Do not make successful option querying
   a precondition for listening when actual nonce-based connect/accept succeeded.
   Unsupported option is not a network-denial pass or listener failure. If the
   option is unavailable, record that without seeking another option or API.
e. Ensure subsequent behavioral readiness still succeeds if needed to resolve
   contradictory observations, within the same small owned helper. An unexpected
   error in a REQUIRED call is a stop, not something to ignore.

If bind/listen/connect/accept/nonce exchange is actually denied or unavailable
under the existing outer protections, record the exact stage and stop INCOMPLETE.
Do not loosen the inner policy (it does not govern this external peer), alter host
permissions, use a real endpoint, or claim environmental denial from an unlocalized
exception. Historical cause may remain unproved even if new calibration succeeds.

Ordinary demonstrable audit-helper bugs may be corrected and rerun on fresh
synthetic state within this engagement; retain failed source/results without
credit. No open-ended network diagnosis or permission experimentation.
Once readiness succeeds, proceed directly to section 6 without another handoff.

6. COMPLETE MATRIX UNDER THE UNCHANGED POLICY

Rerun restrictive true and the fixed Python -I -B marker with the final newly
authored helpers, then the full matrix on fresh synthetic state. No success may
be borrowed from an earlier helper/source run. Preserve every original 40-control
semantic assertion per parent/fork/exec/fork-then-exec form. Do not narrow to the
formerly missing connect check, remove a filesystem control, hide a failed result,
or reuse the unperformed-peer fallback as a passing state.

Runtime positives:
- true exits 0; Python emits unique nonce/PID/version/sys.executable and exits 0;
- owned standard-library SQLite create/transaction/readback/removal;
- distinct parent, fork, exec, fork-then-exec markers and reaping;
- sys.executable child variant when different from the fixed entry.

Filesystem:
- Before contained runs, demonstrate ordinary read/write/create accessibility of
  every owned source, launcher, evidence and denied sentinel and relevant alias;
  capture bytes/modes. Use ordinary sufficient modes so chmod is not the denial.
- In every tested form: permitted source/launcher reads and scratch
  create/read/update/remove; deny source/launcher/evidence/denied append, truncation,
  replacement, deletion, creation; deny evidence/denied content reads.
- Cover canonical and audit-owned symlink aliases, including allowed-to-denied.
- Preserve allowed ancestor-metadata control without enumerating host directories.
- Credit only the intended EPERM/EACCES boundary, not missing path, malformed API,
  unsupported call, arbitrary exception or wrong OS mode.
- Do not probe any real excluded checkout/home/credential path, even a nonexistent
  child. Judge general exclusion from policy review as well as finite controls.

Network:
- The supervisor keeps its calibrated listener open at the SAME assigned endpoint
  throughout all four role attempts; do not close/rebind between them or pass its
  descriptor into the contained process.
- Each contained form must reach the bind and actual connect calls while its entry
  marker is valid. Require EPERM/EACCES at those respective stages.
- Connect targets only that live owned listener. Socket creation/timeout failure,
  refused connection, timeout, unreachable peer, errno42, or peer-port sentinel is
  NOT connect-denial credit.
- Record actual endpoints/errnos and all unexpected connection successes. Enough
  backlog/draining and finite attempt bounds must prevent a full queue from
  masquerading as denial.
- After matrix completion, while the original listener is still owned and open,
  perform another external connect/accept/nonce handshake to the SAME endpoint.
  This verifies continued readiness independently of SO_ACCEPTCONN.
- Explicitly close all connected and listening sockets afterward and record
  descriptor closure. Failure of final readiness or closure is an incomplete
  result; preserve any established partial controls.

One final-policy complete run must pass all mandatory controls. Compare ordered
control-name inventories to the authenticated previous matrix, with any added
calibration checks listed separately. Bind raw role records to expected PID,
nonce, interpreter, policy, source and endpoint. Distinguish valid entry identity
from overall control success; driver exit 0 is not target success.

Review all retained policy rules; disclose bounded root/runtime breadth. If policy
adequacy remains unresolved, do not issue QUALIFIED from count totals alone.
No OS-log search, new crash collection, debugger, privileged tracing or new policy
variant is authorized here; staged helper observations are the selected diagnostic.

7. PRESERVATION AND DELIVERY

Before and after every run retain active helper/policy/probe/runtime identities,
actual invocation, all raw outputs and result records. Capture sentinel bytes,
modes, symlink targets and forbidden-output absence; record SQLite summaries only,
not raw databases/sidecars. Keep evidence outside contained writable locations.

Remove only explicitly created prospective probe state after capturing evidence.
Never clean prior roots or archives. Preserve the final helper/policy/layout for a
later separately governed candidate-audit continuation. There is no requirement
to recover the old peer port or reconstruct an unavailable old socket trace.

Write a full report before sealing ONE compact evidence ZIP. Include:
- exact input authentication and immutable old disposition;
- new entry bindings, effect/cleanup record;
- full new helper/peer/matrix sources and exact unchanged policy;
- optional-option observation separately from mandatory behavioral calibration;
- complete staged peer log, raw exceptions and before/after nonce readiness;
- full matrix, control inventories, raw stdout/stderr and distinct exits;
- runtime/descriptor/process ownership and reaping;
- pre/post identity/sentinel records and exact skipped/unperformed coverage;
- self-excluding path/size/SHA-256/CRC/mode member manifest.
Reopen every member and return report/ZIP bytes and SHA-256. Do not embed old large
archives, candidate code, databases, bytecode, cores, credentials or unrelated logs.

8. EFFECT CEILING, DEFERRED SUBJECT AND VERDICT

No candidate extraction/import/SQL/fixture/pytest collection/tests. No repository
or Git/index/refs/config/AGENTS discovery, source repair, installation, host/app
settings change, outer-protection bypass, network grant, remote provisioning,
publication, deployment or product effect. No subagents or general runner platform.

Candidate identity only:
tree 4691af58ae0ee3107b4e2e9b6b1508032944e357; 327 paths;
manifest 1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1;
candidate ZIP 48,978,087 bytes /
6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42;
integrated commit 61d0330aba1160f7f5e7d9c541a325222d1c61e5.

All A01-A18, two-layer admission/history, witness construction/alias safety,
F01/O1/S01/A03, routes/physical aliases/proposal/acceptance/posture, SQL/admin,
causal/privacy, independent observer and source/mode controls remain. Required
independent 60-case direct and 9,568-case selector-free FULL are not satisfied by
qualification. F03/F05 and all historical process/validation limits remain.

Return exactly one primary disposition:
RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_QUALIFIED
RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_INCOMPLETE_<PRECISE_REASON>
RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_BLOCKED_<PRECISE_REASON>

QUALIFIED requires a clean prospective interval, authenticated input, reviewed
unchanged policy, runtime positives, explicit peer readiness before/after, complete
filesystem/network/descendant matrix and closure under one final source set.
It is bounded to observed seams, not universal OS security or candidate acceptance.

Return to ChatGPT with the complete result and evidence. Even on QUALIFIED, stop
before candidate execution. Keep the implementation conversation idle.
