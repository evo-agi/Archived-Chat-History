## Engineering disposition

**The archive authenticates. The next correction belongs in the peer-calibration helper—not the sandbox policy or the candidate.**

The report does **not** establish that loopback listening is unavailable. Its helper can raise the recorded error **after successfully listening, connecting, and accepting**, but it collapses all those stages into one “peer unavailable” result. A specific socket-option query is the leading suspect; the historical failing call remains unproved.

Continue in the **same neutral qualification conversation**, with the restrictive policy unchanged.

## Authenticated evidence

| Item | Verified result |
|---|---|
| Archive size | **148,210 bytes** |
| SHA-256 | `76e33ec28c3468d44987aae4cf27ab06675ae00df21c50fc998cc68140ea569f` |
| Inventory | **118 regular files; 117 verified self-excluding manifest rows** |
| Expanded size | 667,857 bytes |
| Embedded report | 14,749 bytes; SHA-256 `a6aad94483ea1dff818ec4039073bca179ab3785df54d605ead9b41497c58b88` |

I verified safe paths, uniqueness, types, encryption flags, complete manifest coverage, CRCs, sizes, hashes, and numeric modes. All **27 copied historical payloads** match the preceding archive. The uploaded ZIP remained unchanged. Coordinator_RW0_Audit_Qualification_TS3Q9UUZ_Receiving_Review\.md[Receiving inspection](sandbox:/mnt/data/Coordinator_RW0_Audit_Qualification_TS3Q9UUZ_Receiving_Review.md)

## The peer failure is not where the summary implies

At `execution/launch.py:88–104`, `setup_peer()` performs this sequence:

```text
create socket
→ bind to 127.0.0.1:0
→ listen
→ obtain assigned port
→ create client
→ connect
→ accept
→ close accepted/client sockets
→ getsockopt(SOL_SOCKET, SO_ACCEPTCONN)
→ return the listener and successful calibration record
```

The caller catches an `OSError` from **that entire sequence** and retains only its type, errno, and text. It records neither the failing stage nor a traceback. The `peer` variable remains `None` whenever the helper fails before returning—even if the earlier connection succeeded. The same `SO_ACCEPTCONN` query appears again during finalization at `:150–153`. Coordinator_RW0_Audit_Qualification_TS3Q9UUZ_Receiving_Review\.md[Exact source analysis](sandbox:/mnt/data/Coordinator_RW0_Audit_Qualification_TS3Q9UUZ_Receiving_Review.md)

Apple’s published errno definitions identify **42 as `ENOPROTOOPT`**; its `getsockopt` documentation describes that error as an option unknown at the indicated level. That makes the option query a concrete suspect rather than evidence that TCP or loopback is unavailable. **It does not prove which call failed on this host.** [GitHub](https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/bsd/sys/errno.h)

The helper also lacks unconditional cleanup for partially constructed sockets. The records show that its supervisor exited; I am **not** claiming a socket survived that exit. The narrower defect is that explicit socket ownership and cleanup are not reliably recorded on intermediate failure.

**The historical conclusion should therefore remain: “no calibrated peer was returned; setup failed at an unrecorded stage.”** It should not be strengthened into “no listening socket was ever established.”

## The reported 39-of-40 results reconcile

Independent parsing of the raw matrix output, nested child records, outputs, and identities reproduced:

| Process form | PID | Passing controls | Missing control |
|---|---:|---:|---|
| Parent | 51122 | 39/40 | Peer-backed connect |
| Fork | 51123 | 39/40 | Peer-backed connect |
| Exec | 51124 | 39/40 | Peer-backed connect |
| Fork-then-exec | 51125 | 39/40 | Peer-backed connect |

Each role has 40 unique control names. The 33 recorded negative operations per role—32 filesystem/alias checks and one bind check—returned `EPERM`. The connect result explicitly says **unperformed**, not passed. The separate SQLite positive, role-marker identities, child-reaping records, and preservation records for 24 synthetic files also reconcile. Coordinator_RW0_Audit_Qualification_TS3Q9UUZ_Receiving_Verification.json[Verification record](sandbox:/mnt/data/Coordinator_RW0_Audit_Qualification_TS3Q9UUZ_Receiving_Verification.json)

All four launches used the same restrictive policy:

```text
2,637 bytes
SHA-256:
d9f8bd3aeaedc1606ee2cf7a93b81742ffca0fef93e1f270618222bae35b52c1
```

Its source narrows the earlier process and signal permissions, keeps source/launcher read-only, leaves evidence and denied content ungranted, and retains explicit network denial. The disclosed root-directory-entry and runtime-subtree allowances remain policy-review limits; passing synthetic probes are not an exhaustive security proof. Coordinator_RW0_Audit_Qualification_TS3Q9UUZ_Receiving_Review\.md[Policy assessment](sandbox:/mnt/data/Coordinator_RW0_Audit_Qualification_TS3Q9UUZ_Receiving_Review.md)

These are **authenticated retained execution records**. I did not independently execute the probes.

## Selected correction: behavioral peer calibration, unchanged policy

The replacement mandate makes actual behavior—not socket-option introspection—the readiness test:

1. **Record each socket operation separately**, including its arguments, outcome, errno, and any owned-code traceback.
2. Establish an owned listener and prove readiness with a bounded **connect → accept → nonce exchange**.
3. Keep that **same listener** open throughout the contained matrix, with no socket descriptor inherited by the contained processes.
4. Prove it still works with another external connect/accept exchange afterward, then close every socket explicitly.
5. Remove `SO_ACCEPTCONN` from mandatory readiness and cleanup. One separate diagnostic query is permitted after successful readiness, but an unsupported option cannot erase a successful behavioral control.

This does **not** waive network-denial evidence. Each contained process must still reach the actual connect call against that functioning owned peer and receive the required permission denial. A missing listener, refused connection, timeout, socket-option error, or unavailable-peer placeholder remains insufficient.

After successful peer calibration, Codex must rerun the **complete matrix** under the unchanged policy in the same engagement. The old 39/40 results remain historical partial coverage; they are not combined with a new connect-only result to manufacture a complete pass.

If a required socket operation actually fails under the existing outer protections, the task stops with its exact stage. **No new permission allowance is authorized.**

## Codex handoff

| Field | Instruction |
|---|---|
| **RECIPIENT** | The **same neutral qualification conversation** that produced `rw0-ancestor-ts3q9uuz`. |
| **ATTACHMENTS** | **None required.** The exact retained archive path and identity are in the prompt. |
| **AUTHORIZED EFFECTS** | Audit-owned helper correction, fresh synthetic controls, and external evidence. The restrictive policy stays byte-identical. |
| **EXPECTED RETURN** | One inline result and one reopened qualification-evidence ZIP. |
| **PROJECT SNAPSHOT** | None requested. |
| **NEXT ACTION** | Return the result here before candidate execution. |

Send **only this complete replacement prompt**:

:chatgpt-content-reference{index="7"}[**RW0 audit environment — peer-calibration correction and final qualification**](sandbox:/mnt/data/Coordinator_RW0_Audit_Environment_Peer_Calibration_Completion_Prompt.txt)

The prompt creates uniquely named prospective files beneath the existing policy-authorized owned subtrees, preserving prior evidence. That avoids another policy rebinding or permission experiment. It contains the full qualification requirements and does not require assembling earlier prompt fragments.

The expected successful disposition remains:

```text
RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_QUALIFIED
```

Successful peer setup alone cannot produce that verdict. The full runtime, SQLite, filesystem, alias, network, and descendant matrix—and policy review—must complete.

## Candidate state and limits

The candidate remains unaccepted at:

```text
4691af58ae0ee3107b4e2e9b6b1508032944e357
```

Its earlier audit established artifact identity, not acceptance, and supplied no independent direct or selector-free FULL execution credit. This qualification evidence adds none. Pasted text Keep the implementation conversation idle; all substantive A01–A18 obligations remain outstanding.

**Inspection limits:** I performed data-only archive verification, retained-record reconciliation, and static helper/policy inspection. I executed no supplied helper, policy, probe, candidate code, SQL, test, Git command, or host diagnostic.

**Sources:** Coordinator_RW0_Audit_Qualification_TS3Q9UUZ_Receiving_Review\.md[Receiving inspection](sandbox:/mnt/data/Coordinator_RW0_Audit_Qualification_TS3Q9UUZ_Receiving_Review.md), RW0_Audit_Qualification_TS3Q9UUZ_Report_From_Sealed_ZIP.md[exact embedded report](sandbox:/mnt/data/RW0_Audit_Qualification_TS3Q9UUZ_Report_From_Sealed_ZIP.md), Coordinator_RW0_Audit_Qualification_TS3Q9UUZ_Receiving_Verification.json[verification record](sandbox:/mnt/data/Coordinator_RW0_Audit_Qualification_TS3Q9UUZ_Receiving_Verification.json), and Apple’s socket references cited above.

**Confidence:** artifact identity and record reconciliation **0.99**; helper-correction direction **0.97**. The historical failing socket call and completed containment qualification remain unestablished.
