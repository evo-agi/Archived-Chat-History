## Engineering disposition

**This is a runner–test-suite compatibility gap, not a newly established candidate defect. Accept the `INCOMPLETE` verdict, preserve the candidate, and correct the audit execution boundary—not the tests.**

Codex stopped at the condition the mandate required: a mandatory test needs an operation that the frozen policy prohibits. The candidate test was **not launched**; its predicted failure is an inference from authenticated test source and the reported synthetic signal probe. Pasted text

There is no reported return to the earlier project-routing or live-checkout problem. This engagement reports the correct neutral directory and no live repository access. Pasted text

## The source supports the incompatibility

I independently inspected the cited test and the qualified policy from the already-supplied archives. The test is not merely using signals as optional emergency cleanup:

```text
tests/test_b3c2_transition_event_readers.py:605–641
```

Its child ignores `SIGTERM` and blocks on a pipe. The parent must time out, terminate and reap that child, and verify descriptor closure **before** releasing the blocking pipe. The helper at `:501–519` attempts `SIGTERM`, then `SIGKILL`, and polls for reaping. A denied signal cannot satisfy that required behavior.

The qualified policy permits `process-fork` and `process-exec` but contains no signal allowance. Its own review explicitly assigned timeout termination to the **external supervisor**. That was sufficient for the cooperative synthetic matrix, but not for tests that require the contained process to perform its own termination and cleanup. Coordinator_RW0_Normal_Terminal_Audit_Signal_Compatibility_Receiving_Note.md[Static source and policy inspection](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Audit_Signal_Compatibility_Receiving_Note.md)

**I should have included signal-based teardown in qualification before freezing that policy for the mandatory FULL suite.** The earlier 40/40 qualification remains valid for its measured controls; it never established this additional capability.

The latest audit’s `EPERM` observation for live children is consistent with the source-level gap. Its later `ESRCH` observations after exit and reaping provide no successful signal-delivery credit. I have not yet inspected the raw probe that produced those results. Pasted text

## The correction must cover process groups, not just this one test

A bounded static scan found related dependencies in six packaged files. In particular, the existing production supervisor uses:

```text
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py:
123–142   process-group liveness and signaling
208–222   cancellation/deadline termination
255–299   forced cleanup and group-clear checks
```

That includes `os.killpg(pgid, 0)`, `SIGTERM`, and `SIGKILL`. Other test helpers use direct-child termination and kill operations. These are inspected dependencies, **not claims that every branch has run or failed**. Coordinator_RW0_Normal_Terminal_Audit_Signal_Compatibility_Receiving_Note.md[Verified source excerpts](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Audit_Signal_Compatibility_Receiving_Note.md)

Therefore, adding an allowance tailored only to the reported B3C2 test would be an inadequate response. The next runner decision must account for the finite PID, process-group, and cleanup operations the authenticated suite actually needs.

## Selected direction

**Use a narrowly scoped audit-workload signaling capability, if the installed boundary can enforce it. Do not grant unrestricted host or same-user signaling.**

The continuation must establish successful signaling and reaping of the intended owned targets, including the relevant process-group cases, while preserving exclusion of targets outside that workload. Negative controls should use separately owned synthetic nonmember processes—not real unrelated processes.

This is an explicit proposed **runner-permission amendment**, not a candidate-contract change. Its exact policy rule is not selected yet. A changed policy would require a new identity and complete recalibration of the original controls plus the signal controls before candidate execution.

Three shortcuts remain unacceptable:

- Skipping, filtering, or modifying the mandatory test.
- Patching the candidate’s signal calls or assertions to accommodate the runner.
- Having the external supervisor perform the candidate’s required cleanup and crediting that as candidate success.

External supervision remains emergency containment; it cannot substitute for the behavior under test.

**After successful recalibration, the same engagement should proceed directly into the cumulative audit.** Another qualification-only handoff should not be the default. The existing authentication and static findings can retain their bounded credit, but all required current-byte execution evidence must still be produced. The latest report explicitly records zero candidate imports, SQL executions, causal scenarios, direct runs, or FULL runs. Pasted text

## Next action: supply the existing audit evidence ZIP

The attached file is the closeout, not the complete evidence package. Upload **only this existing ZIP**:

```text
RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_INCOMPLETE_20261029_audit-4de1ae8e82.zip

Bytes:
115,300

SHA-256:
b6de501b4a687bd3dc1f8800ac84d150b1197fea74682bd2953b8f9a20c887f9
```

Its reported location is:

```text
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/
evidence/audit-4de1ae8e82/
RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_INCOMPLETE_20261029_audit-4de1ae8e82.zip
```

The archive reportedly includes the full 23,692-byte report and 42 manifest-covered evidence members. No standalone report, candidate package, or qualification archive needs to be uploaded again. Pasted text

Inspection will check the exact signal probe, live-child identity and synchronization, actual syscall outcomes, cleanup, and the full compatibility assessment before a permission amendment is issued. **Do not rerun the unchanged audit or modify the policy now.**

Keep the same neutral reviewer conversation parked and the implementation conversation idle. Candidate tree `4691af58ae0ee3107b4e2e9b6b1508032944e357` remains unaccepted. All A01–A18 execution obligations and the independent 60-case direct and 9,568-case FULL gates remain required; no new Project snapshot, source repair, staging, or publication is indicated.

**Sources:** Attached audit closeout, cited above; Coordinator_RW0_Normal_Terminal_Audit_Signal_Compatibility_Receiving_Note.md[targeted static inspection of the sealed test, supervisor, and Q policy](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Audit_Signal_Compatibility_Receiving_Note.md). No candidate code or probe was executed here.

**Confidence:** High on the source-level compatibility gap and the need to preserve the tests. The latest raw signal evidence and an enforceable narrowly scoped replacement permission remain unverified.
