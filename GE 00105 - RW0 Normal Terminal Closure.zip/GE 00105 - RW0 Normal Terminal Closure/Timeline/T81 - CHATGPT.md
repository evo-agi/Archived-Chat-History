## Engineering disposition

**The archive authenticates. The preplaced-hardlink control genuinely failed, and that result stands. I have selected a prospective workspace-admission layer around byte-identical QtcM—not another permission expansion or a candidate repair.**

The new boundary must **reject a contaminated workspace before launching candidate code**, then demonstrate that the contained workload cannot create the prohibited protected-to-writable links itself. Successful qualification leads directly into the unfinished cumulative audit in the same reviewer conversation.

This is an explicit change to the runner’s assurance model. **It does not turn the old runtime-denial failure into a pass.**

## Authenticated evidence

| Item | Verified result |
|---|---|
| Uploaded ZIP | **6,677,682 bytes** |
| SHA-256 | `10d793d8d18046d7afa5385aee832576e90e3378ccaff14b58f133b3fe31ad4f` |
| Inventory | **45 regular files; 44 verified manifest rows** |
| Expanded size | **8,428,372 bytes** |
| Embedded report | **27,025 bytes**, matching its reported identity |
| QtcM | **4,086 bytes**, exact Qtc prefix plus five metadata rules |

Every covered member passed path, uniqueness, type, encryption, size, CRC, SHA-256, and numeric-mode checks. The embedded U, T, S, and R archives also authenticate against their retained identities.

I separately reauthenticated all **327 current candidate source files** and reconstructed the fixed tree from their bytes:

```text
4691af58ae0ee3107b4e2e9b6b1508032944e357
```

All **fifteen complete source captures**—five initial, five after the synthetic controls, and five after cleanup—match those source rows. These establish artifact and recorded-copy identity, not current live-checkout state or continuous filesystem custody.

:chatgpt-content-reference{index="3"}[Detailed receiving inspection](sandbox:/mnt/data/Coordinator_RW0_MD812_Receiving_Review.md)

## What the hardlink evidence proves

The inspected supervisor calls `os.link` to place the alias in scratch **before** launching the contained probe. The raw output and parsed results agree:

| Operation against the same synthetic sentinel | Recorded result |
|---|---|
| Canonical-path data read | `EPERM` |
| Canonical-path write-open | `EPERM` |
| Symlink-path read and write-open | `EPERM` |
| **Preplaced-hardlink data read** | **Succeeded** |
| **Preplaced-hardlink write-open** | **Succeeded** |
| Separate in-sandbox creation of another hardlink | `EPERM`; destination remained absent |

Two details sharpen the interpretation.

**The read consumed the complete 37-byte safe sentinel.** The helper uses `Path.read_bytes()` and then retains only the first byte, `0x72`. It was not merely a metadata check or a one-byte read.

**The write operation opened with `O_WRONLY | O_APPEND`, then closed.** It used neither truncation nor creation flags and made no write call through that descriptor. The recorded target hashes, sizes, types, and modes remain equal before and after. Thus the evidence establishes write-open capability, **not a demonstrated byte modification**.

The exact source locations are:

```text
audit/execution/metadata_calibration_m.py:43–46,68–84,94–107
audit/execution/hardlink_reach_m.py:24–30
```

Seventeen of the nineteen intended negative operations denied access; the two preplaced-hardlink operations did not. The synthetic process’s exit 0 means its observations were recorded successfully. Its aggregate qualification result is correctly **false**. Coordinator_RW0_MD812_Receiving_Review\.md[Probe reconciliation](sandbox:/mnt/data/Coordinator_RW0_MD812_Receiving_Review.md)

### Two limits must remain visible

The archive records the root target’s device/inode before link creation, but **does not retain the alias’s measured device/inode pair or link count**. The cleanup code checks identity equality and the cleanup receipt reports success. That supports the genuine-hardlink interpretation, but is not a complete numeric identity transcript.

There is also **no predecessor-versus-QtcM comparison of this preplaced-link probe**. We cannot conclude that the five metadata rules introduced the behavior. The earlier hardlink-creation denial was never proof of access denial through an existing link.

The governing mandate required alias protection and explicitly distinguished these cases, so stopping before candidate execution was correct. Coordinator_RW0_Normal_Terminal…

## Selected boundary: WA1 admission plus unchanged QtcM

**The requirement changes at one specific layer:**

| Previous requirement | Prospective requirement |
|---|---|
| Deny access at runtime even after the trusted supervisor places a protected inode under a writable name. | **Reject that prepared workspace before launch**, and demonstrate that the workload cannot establish the prohibited relation from an admitted state. |

The failed historical control remains recorded. No contaminated workspace may be admitted merely because its contents are synthetic or the supervisor promises not to exploit the alias.

The admission layer, **WA1**, must enforce three things.

### 1. Check file identities across the actual writable footprint

Admission must cover **all** policy-writable scratch, home, and temporary directories—including historical namespaces—and the two exact temporary-module slots. Checking only the newly created suffix would leave reachable paths outside the gate.

Protected audit-owned regular files must have one hardlink and distinct recorded device/inode identities. Their identities must not appear in writable locations. Preexisting writable files must have a classified audit origin and a complete accounted-for hardlink group; an unexplained alias outside that footprint causes refusal, not a host-wide search.

Python exposes device, inode, and hardlink-count fields separately; content hashes alone do not supply that identity information. This is supplementary interface documentation, **not evidence that the proposed gate works on the user’s host**. [Python documentation](https://docs.python.org/3.13/library/os.html)

### 2. Make contaminated-layout refusal part of the real launch path

The same `launch_if_admitted` path used for candidate validation must reject deliberately contaminated synthetic layouts **before any candidate import or subprocess launch**.

The controls must retain both endpoints’ identities and link counts, demonstrate zero launches on rejection, and include clean paired positives. Two independently created files with identical bytes must not be mistaken for a hardlink.

The supervisor must also publish provisional results by **independent byte copies into newly created protected files**, not by moving or hardlinking candidate-writable files into evidence.

### 3. Demonstrate that the workload cannot break the admitted invariant

The runtime checks must cover protected **readable source/helper targets**, not only unreadable root or evidence sentinels, and each writable destination class. The earlier single root-to-scratch denial is insufficient for that broader claim.

Protected-to-writable link and move attempts must actually be denied. Existing canonical, symlink, source/evidence, network, and process controls remain required. Legitimate hardlinks entirely within writable test state remain permitted where the unchanged tests need them; this is not a blanket ban on hardlinks.

**If these runtime checks fail, admission alone is insufficient and candidate execution must not proceed.**

### The trust assumption is explicit

This composite boundary relies on a trusted, serialized supervisor and excludes malicious or concurrent hostile same-account host mutation. Before/after scans are not protection against such an actor, and the prompt prohibits claiming otherwise.

That limitation is now part of the selected prospective assurance model—not an unstated assumption introduced to obtain a pass. A stronger hostile-host guarantee would require a different execution boundary; this engagement does not authorize installing or inventing one.

## QtcM does not change

The policy remains exactly:

```text
Bytes:
4,086

SHA-256:
323ddc662ca3260365136573d08b25fe635ad448b84b4a673cf99533b0f89d0a
```

There is no new filesystem, network, signal, or runtime permission.

The report records removal of the two root calibration fixtures and restoration of the original ten root entries. The continuation therefore expressly permits recreating **only those two exact fixture paths after fresh absence checks**, with new identities and independent bytes. It does not overwrite old artifacts or claim continuity with their former inodes. Source-copy locations and the existing temporary-module permissions stay fixed.

The new gate and qualification have **not** been executed here or shown sufficient.

## Candidate and audit state

The stable ledger still has **31 mandatory-open rows: G01 plus the same 30 substantive cases**. Only G01’s runner-limitation status changed in this package. No new candidate representative, exact 99-case replay, complete suite, or substantive causal probe ran under QtcM.

Earlier independently executed causal evidence, the Qs **60/60 direct pass**, and the completed Qs **9,469-pass/99-fail FULL** retain their original scopes. They are neither erased nor upgraded.

The remaining sequence is unchanged after runner admission succeeds:

```text
Four unchanged representatives
→ exact 99 previously failing node IDs
→ fresh complete 60-case direct suite
→ fresh selector-free 9,568-case FULL
→ remaining substantive audit closure
```

A green regression run still cannot replace the thirty missing substantive predicates. Coordinator_RW0_MD812_Receiving_Verification.json[Verified ledger and source records](sandbox:/mnt/data/Coordinator_RW0_MD812_Receiving_Verification.json)

## Codex handoff

| Field | Instruction |
|---|---|
| **CURRENT STATE** | Candidate remains unaccepted; preplaced-hardlink runtime containment failed at its measured scope. |
| **RECIPIENT** | The **same neutral independent reviewer conversation** that produced `md-812d7d86be`. |
| **ATTACHMENTS** | **None required.** Exact retained paths and identities are included. |
| **AUTHORIZED EFFECTS** | Audit-owned admission/launch/publication helpers, bounded owned-workspace checks, synthetic qualification, then conditional unchanged-candidate audit. |
| **EXPECTED RETURN** | One cumulative disposition, full report, admission and closure ledgers, and reopened evidence ZIP. |
| **PROJECT SNAPSHOT** | None requested. |
| **NEXT ACTION** | Return the cumulative result here before any candidate repair or commit gate. |

Send **only this complete replacement prompt**:

:chatgpt-content-reference{index="6"}[**RW0 normal terminal closure — workspace admission and audit completion**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Workspace_Admission_And_Audit_Completion_Prompt.txt)

It contains the complete assignment. **Substantive sections 2–4 are preserved byte-for-byte.** The prospective admission amendment, trust assumptions, lifecycle treatment, qualification controls, and execution sequence are explicit. No earlier prompt fragments need to be assembled, and no routine handoff is required between successful stages.

```text
Prompt size:
74,426 bytes

SHA-256:
da76e47880c9ca00669648dc08c08c273b06aaad82e866c9467f636c948d8ea3
```

:chatgpt-content-reference{index="7"}[Handoff identity record](sandbox:/mnt/data/Coordinator_RW0_MD812_Handoff_Check.json)

Keep the implementation conversation idle. No candidate edit, test relaxation, installation, staging, commit, publication, or deployment is authorized.

**Inspection limits:** Data-only archive verification, source reconstruction, retained-record reconciliation, and static inspection. No supplied helper, policy, candidate code, SQL, test, Git operation, or host probe was executed. Historical host actions remain retained evidence rather than independently observed live events.

**Sources:** Coordinator_RW0_MD812_Receiving_Review\.md[Receiving inspection](sandbox:/mnt/data/Coordinator_RW0_MD812_Receiving_Review.md), RW0_Normal_Terminal_MD812_Report_From_Sealed_ZIP.md[exact embedded report](sandbox:/mnt/data/RW0_Normal_Terminal_MD812_Report_From_Sealed_ZIP.md), Coordinator_RW0_MD812_Receiving_Verification.json[verification record](sandbox:/mnt/data/Coordinator_RW0_MD812_Receiving_Verification.json), and the separately identified Python interface documentation.

**Confidence:** Artifact/source identity **0.99**; interpretation of the retained hardlink observations **0.98**. WA1 enforcement, completed candidate validation, and commit-gate eligibility remain unestablished.
