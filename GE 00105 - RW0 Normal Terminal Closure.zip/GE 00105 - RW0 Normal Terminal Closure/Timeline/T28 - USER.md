The Bash script returned

```
Codex CLI is not on PATH. Stop here; do not install or substitute a repository-bound session.

Saving session...shell_session_save:9: shell_session_save_user_state_functions: parameter not set
```
