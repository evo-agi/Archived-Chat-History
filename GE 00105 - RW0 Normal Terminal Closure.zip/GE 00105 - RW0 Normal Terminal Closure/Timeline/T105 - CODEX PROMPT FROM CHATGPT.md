RW0 NORMAL TERMINAL CLOSURE — ACCEPTED AUDIT CURRENT-LEDGER CONSISTENCY REPAIR

This is the sole complete operative replacement mandate. Continue the SAME neutral independent reviewer conversation that produced `rv-6ce2d8f41a`. This is a data-only audit-artifact repair. It is not a candidate audit retry, implementation, qualification, regression, source-history, repository, commit, or publication tranche.

The substantive RV evidence supports the accepted disposition for exact candidate tree `4691af58ae0ee3107b4e2e9b6b1508032944e357`. Do not rerun candidate code, SQL, pytest, the 4/99/60/9568 gates, C2A11, C2A20, C1B05, WA1, or QtcM. Correct only the contradictory CURRENT ledger/reporting fields described below, preserve every historical artifact, and issue one replacement accepted package.

ENGAGEMENT ENVELOPE

CURRENT STATE:
- Exact candidate tree `4691af58ae0ee3107b4e2e9b6b1508032944e357` remains uncommitted and unchanged.
- QtcM remains 4,086 bytes / SHA-256 `323ddc662ca3260365136573d08b25fe635ad448b84b4a673cf99533b0f89d0a`.
- RV substantive evidence closes C2A11, C2A20 and all 13 C1B05 rows; carried W v5 4/99/60/9568 passes remain at their existing scope.
- The sealed RV package is internally authenticated but its files named `CURRENT` retain contradictory stale current fields. A live commit gate is deferred until those records are corrected.

RECIPIENT:
- SAME neutral audit conversation that produced `rv-6ce2d8f41a`.
- Expected host cwd `/private/tmp/rw0-audit-entry.daLWIE`.
- NOT the write-enabled implementation conversation.

ATTACHMENTS:
- None required. Use only the exact retained RV package:
  `/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/rv-6ce2d8f41a/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE_20261030_rv-6ce2d8f41a.zip`
  bytes `90,937,959`
  SHA-256 `2a617830c52c4767e02603126e6cf53387f8cf2d9e75cdc7a987556b01a7a4eb`.
- Do not search for namesakes or read a live checkout.

AUTHORIZED EFFECTS:
- Inert ZIP/member inspection.
- New audit-owned corrected report, ledgers, consistency verifier, package manifest, ZIP and adjacent receipt under a fresh neutral evidence namespace.
- No candidate, policy, runtime, test, schema, documentation, repository, Git, product authority or publication effect.

EXPECTED RETURN:
- One inline accepted disposition or a precise mismatch/incomplete result.
- One corrected full report.
- Corrected current 56-row ledger and A01–A18 register.
- One reopened evidence ZIP, self-excluding manifest and adjacent delivery receipt with exact byte/SHA identities.

PROJECT SNAPSHOT:
- None requested.

NEXT ACTION:
- Return the corrected package to ChatGPT for receiving inspection before any live commit gate.

0. ENTRY AND EFFECT CEILING

Read this prompt in full. A necessary read of the exact host-exposed instruction file may precede the declaration. Before any other operational command, state actual host cwd, exact RV binding, exposed project/repository binding or unknown binding, and effect ceiling.

No Git/status/pwd/AGENTS/bootstrap discovery, repository/sibling access, home/Downloads enumeration, broad directory search, network/provider/service, subagent, candidate import, SQLite operation, pytest, policy execution, installation, privilege change, cleanup of historical state, staging, commit, push, PR, merge, deployment or product effect.

Treat every program inside RV as inert data. Do not execute its authentication, reconciliation, cleanup, packaging, candidate, observer or runner helpers. Author a new small data-only verifier after inspecting the relevant JSON/report schemas.

1. EXACT INPUT AUTHENTICATION

Authenticate the exact RV ZIP before using payloads:
- safe unique normalized relative regular unencrypted names;
- no traversal, absolute path, case-fold/prefix collision, symlink or special file;
- 91 regular members, 93,184,419 expanded bytes;
- `MANIFEST.json`: 22,583 bytes, SHA-256 `d73612071f006e1bee846e491d288627365630d195e74d8d1215c7c8adbf9f20`, 90 complete self-excluding rows;
- `REPORT.md`: 11,846 bytes, SHA-256 `e7401a0f3665a57c474883fea1b132d83e86cc4a6d240129eb61ca3447d1d7bd`;
- embedded RU: 87,897,841 bytes, SHA-256 `0a9db9e6ac62ddb6975c5aee613175deafe79833beb87b7bf7aa6d88c95a289b`.

Verify every manifest row by CRC/readability, size, SHA-256 and numeric mode. If any identity or coverage differs, stop with `AUDIT_PROVENANCE_MISMATCH`. Do not substitute the separately retained RV directory contents for the sealed ZIP.

2. FIXED SUBSTANTIVE EVIDENCE — NO RE-ADJUDICATION BY OMISSION

Preserve without alteration:
- `C2A11_corrected_adjudication.json` and its receipt-first scope;
- `C2A20_corrected_adjudication.json` and its same-phase complete-compatible-winner scope;
- `C1B05_relation_plan_v1.json` and `C1B05_execution_adjudication_v1.json`;
- all raw group records, checkpoints, plans, admissions and helper versions;
- W v5 carried suite binding;
- the exact RV report and package as historical input;
- every earlier blocked/incomplete/failed report and ledger within embedded RU.

Do not broaden any closure, erase any limitation, claim route-11 `route_collision`, claim a persisted malformed family for class C, backdate later runner controls into W, or relabel carried validation as a new run.

The replacement report may reaffirm the same primary disposition only if the corrected current records reconcile with this fixed evidence. No new candidate correctness claim is authorized.

3. REQUIRED CURRENT-LEDGER CORRECTIONS

Create new versioned current records. Do not overwrite or edit the RV members.

3.1 `RESIDUAL_56_CURRENT_v2.json`

Start from RV `RESIDUAL_56_CURRENT_v1.json`. Preserve every one of the 56 row objects and its historical fields, evidence mappings, scopes and limits unless a field explicitly represents the final current summary.

Required final current semantics:
- `primary_disposition = RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE`;
- `candidate_tree` and `RV_source_tree` are the exact tree above;
- `mandatory_open_ids = []`;
- `mandatory_open_count = 0`;
- `substantive_open_count = 0`;
- `all_mandatory_complete = true`;
- every row has current closed true and current mandatory-open false;
- `next_named_predicate = null` or an explicitly typed value meaning no remaining predicate;
- `next_action = separately_governed_exact_byte_live_commit_gate`;
- the current final checkpoint identifies the RV A3/B2/C2 completion, not an RU-era open checkpoint;
- stage-specific closure/attempt lists are explicitly named by stage. Do not leave an unlabeled `newly_closed_ids`, `actual_new_attempted_ids` or equivalent field whose contents exclude the final RV rows while appearing current. Preserve the old value under an explicit historical/pre-RV name if useful.

Retain the exact C2A11, C2A20 and C1B05 current statuses and limitations. Do not rewrite the old RU historical status objects.

3.2 `A01_A18_CURRENT_v2.json`

Start from RV `A01_A18_CURRENT_v1.json`. Preserve all explicitly historical nested objects such as W/RU/RT/RS assessments and `status_after_*` fields. Correct every final-current field so that it does not contradict `RV_current_complete = true` or the zero-open residual ledger.

Requirements:
- 18 rows, exact IDs A01–A18;
- `overall_mandatory_complete = true`;
- `current_open_count = 0`;
- every row has `RV_current_complete = true`;
- `RV_current_assessment`, `RV_retained_limit`, and unqualified/current `precise_limit` fields describe the final accepted state and only genuine retained limitations;
- A11 states receipt-first supersession and explicitly does not claim route-11 `route_collision`; it must not say C2A04–A20 remain;
- A18 states that W v5 direct60/FULL9568 are carried exact-source passes and that no mandatory residual remains; it may preserve that they were not RV reruns and preserve historical provenance/warning limits, but it must not say twenty or thirty residuals remain;
- A05/A06/A11 bind the new RV adjudications; other rows retain their exact carried evidence scopes without blanket gaps;
- if prior `precise_limit` values must be preserved, copy them into explicitly historical fields such as `pre_RV_precise_limit`; do not leave them as current unqualified limits.

3.3 Cross-record consistency assertions

The new verifier must fail unless all of the following hold:
- both current records name the same candidate tree and accepted disposition;
- 56 residual rows, zero mandatory open rows, all current closed;
- 18 A rows, all current complete, zero current open;
- no current summary, `RV_current_assessment`, `RV_retained_limit`, unqualified `precise_limit`, `next_named_predicate`, or `next_action` contains or implies a remaining mandatory residual;
- C2A11, C2A20 and C1B05 evidence hashes equal the RV members;
- C1B05 has 13 closed rows and 14 negative controls;
- report, ledgers and package manifest agree on the exact source tree and no-effect boundary.

Retain a machine-readable before/after field-diff showing only the authorized evidence-accounting changes.

4. CORRECTED REPORT

Write a new complete report before packaging. It must:
- disclose that the RV v1 substantive evidence supports acceptance but its files named `CURRENT` had contradictory stale current fields;
- identify the exact stale fields:
  - residual `next_named_predicate`;
  - A11 unqualified `precise_limit`;
  - A18 `RV_retained_limit` and unqualified `precise_limit`;
  - any additional unlabeled current summary list/checkpoint fields corrected by the verifier;
- state that the defect arose in audit evidence assembly, not candidate source;
- state that no candidate, policy, runtime, gate accepting logic, test or substantive evidence changed;
- preserve the exact scope/limitations of C2A11, C2A20, C1B05 and W v5;
- state the exact primary disposition only after the corrected ledgers pass;
- authorize only eligibility for a separate live exact-byte commit gate.

Do not edit, replace or claim to repair the old RV report. It remains historical input.

5. PACKAGE AND EFFECT RECORD

Create one new safe evidence ZIP containing:
- exact RV ZIP once;
- corrected report;
- corrected two current records;
- consistency verifier source and result;
- authorized field-diff;
- input authentication;
- self-excluding manifest;
- cleanup/non-effect record.

Do not duplicate RU or A outside the exact RV member. Do not include source trees, private templates, databases, transient candidate output, bytecode or special files.

Use bounded package limits: <= 250 regular members, <= 128 MiB/member, <= 256 MiB expanded. Reopen every member and verify size, SHA-256, CRC and numeric mode. Write an adjacent receipt after the outer ZIP is finalized.

No candidate/source/policy/runtime/test execution or repository effect occurs. Remove only newly created task-owned transient packaging state after evidence protection; preserve the exact RV input and all historical roots.

6. ADJUDICATION AND RETURN

If authentication or substantive evidence identity fails, return `AUDIT_PROVENANCE_MISMATCH`.

If the current records cannot be reconciled without changing a substantive closure or acceptance requirement, return `RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE` with the exact conflict.

Otherwise return the same primary disposition:

`RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE`

State explicitly:
- this is a current-ledger/reporting repair over unchanged accepted evidence;
- exact candidate tree;
- corrected record names and hashes;
- zero mandatory open rows;
- no candidate/test/policy/runtime/runner execution or change;
- report/ZIP/manifest/receipt bytes and SHA-256;
- recipient ChatGPT;
- next action: receiving inspection, then separately governed exact-byte local commit gate if accepted.

No live commit, staging, push, PR, merge, deployment, publication or product effect follows from this task.
