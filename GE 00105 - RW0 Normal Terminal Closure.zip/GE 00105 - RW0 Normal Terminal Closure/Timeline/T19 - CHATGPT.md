## Engineering disposition

```text
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_REPAIR
REPORTED_COMPLETE_PENDING_PACKAGE_INSPECTION
```

**The reported repair matches the selected scope. Preserve the candidate unchanged and proceed to sealed-package inspection before issuing the fresh cumulative audit. No further implementation change is indicated by this closeout alone.**

The new review ZIP is **not attached here**. Codex’s links identify files on its local filesystem; I have compared the closeout with the repair mandate, but have not authenticated the new source or execution records.

## Report-level assessment

The five reported changes fit the authorized boundary: two governing documents, the private witness value, and two assurance/test files. The report says the other 322 paths and all modes remain unchanged, including migration `0008`, the shared controller, writer session, and terminal SQLite owner.

Two distinctions are correctly preserved.

**Historical access:** the old whole-operation zero-stop-SELECT requirement is superseded as a requirement—not retrospectively declared satisfied. Common managed-state validation and fencing remain mandatory. Current-stop access is permitted only for the existing invariant check; terminal historical verification must then use saved witnesses and immutable predecessors, without consulting current heads or performing a later semantic stop query.

**Witness construction:** direct construction is reported to enforce the same canonical-byte, exact-type, owner-digest, and projection checks as the factories, with detached returned mappings. The package must establish both constructor correctness and resistance to ordinary mutable aliasing; a validating factory alone would not close the finding.

The predecessor audit remains blocked for its original findings and its separately disclosed process violations. Neither the contract amendment nor the new implementation report changes that historical verdict. Pasted text

### New reported subject

| Identity | Codex-reported value |
|---|---|
| Integrated HEAD | `61d0330aba1160f7f5e7d9c541a325222d1c61e5` |
| Integrated tree | `44c7dee402d46b3e16dc389ae0824b4297dfec1f` |
| Immediate predecessor | `5c44721183f660032b6468d2c1f5a1d0dc3e6acb` |
| Repaired uncommitted tree | **`4691af58ae0ee3107b4e2e9b6b1508032944e357`** |
| Source inventory | 327 paths |
| Final manifest SHA-256 | `1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1` |

The reported final gates are **60 direct, six connected, 8,266 focused, and 9,568 selector-free FULL passes**. Their counts overlap. The earlier fixed-document-identity failures and seven-case checkpoint remain separate evidence; they must not receive final-byte credit.

## What the receiving inspection must establish

The decisive question is whether the new tests observe the **actual operation connections and real admission phases**, rather than creating a permissive test substitute. The reported managed-stop READ callbacks are useful observations, but callback counts alone do not establish that boundary.

Inspection must verify that the observers call the unchanged validators and fencing functions, that authorizer attachment is calibrated, and that stop reads are allowed only during the invariant phase. Separate denial and malformed-stop controls must fail safely before protected terminal disclosure. Historical positives must preserve exact results after coherent later head and stop changes.

For the witness value, inspection must check direct/factory equivalence, invalid-type rejection before hostile comparisons, consistency among bytes and projections, and mutation of both caller-owned and returned mappings. It must also verify preservation of F01’s timestamp checks and O1’s calibrated oracle.

**The later audit remains cumulative.** These reported corrections do not discharge the unfinished A01–A18 controls or supply an independent FULL pass. The new mandate must carry the two-layer amendment explicitly rather than reuse the previous audit prompt unchanged.

## Next action

Upload **only this existing sealed ZIP here**:

```text
RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip

Bytes:
48,978,087

SHA-256:
6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42
```

Its reported location is:

```text
/Users/ds/.codex/rw0-terminal-historical-witness-tcp5rwoh/
RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip
```

Do not regenerate it. **No separate report or historical package is needed**: the mandate requires the current report, explicit amendment, predecessor material, and prior audit evidence inside the cumulative archive.

Keep the implementation conversation idle. Do not stage or commit tree `4691af58…`. No new Project-source snapshot is requested; PR #17 remains the integrated baseline.

**Sources:** Codex closeout supplied in this turn; Coordinator_RW0_Normal_Terminal_Closure_Historical_Admission_Witness_Repair_Prompt.txt[historical-admission and witness repair mandate](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Closure_Historical_Admission_Witness_Repair_Prompt.txt); predecessor audit cited above.

**Confidence:** reported scope alignment **0.98**. New-package provenance, constructor correctness, phase-observer adequacy, and validation reconciliation remain unverified pending the archive.
