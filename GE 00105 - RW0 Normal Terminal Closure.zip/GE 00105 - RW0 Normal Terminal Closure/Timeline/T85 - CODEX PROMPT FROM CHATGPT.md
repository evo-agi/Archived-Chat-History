RW0 NORMAL TERMINAL CLOSURE — PRESERVED SUITE EVIDENCE, TARGETED ASSURANCE, AND RESIDUAL CLOSURE

This is the sole complete operative replacement mandate. Continue the SAME neutral
independent reviewer from W, wa-09da07307c. The exact current candidate and QtcM
DO NOT change. This is not another architecture, platform, broad reconnaissance,
implementation, qualification-only, or commit tranche.

The current complete direct60 and selector-free FULL9568 are supported executed
passes on exact source under suite WA1 v5. Preserve them. The next work is:
(1) correct cumulative evidence accounting;
(2) close the specifically missing runner-control scopes defined below, without
    a general qualification reset;
(3) finish the existing thirty named substantive predicates and adjudicate once.
Do not warm up by rerunning already supported constructor/calendar/five-normal/
historical programs while every named open row stays unattempted.

EXPLICIT PROSPECTIVE CARRY-FORWARD / REPEAT RULE:
Sections 2–4 below remain the complete substantive acceptance requirements, preserved
verbatim from the preceding mandate. Their execution imperatives are satisfied by
mapped, source-bound carried independent proof where that proof actually exists.
Section 4.3's complete current-source gates are satisfied by W's supported v5
direct/FULL records unless a concrete binding, outcome, admission or preservation
defect invalidates them. This replaces automatic fresh-suite repetition at each new
engagement or audit-probe registration. It does NOT waive a predicate, assert that
old runs used a later runner, or backdate complete qualification before those runs.

Registration-only, new-owned-namespace/fixture-identity binding, or the specifically
authorized rejecting-only admission correction may receive targeted qualification
without automatically rerunning direct/FULL. Prove the clean accepting path and
actual W admission conditions unchanged. Actual policy/runtime/candidate changes,
a new accepting branch, weakened protection, or an identified unsafe historical
admission require an explicit impact assessment and the genuinely invalidated
validation. Do not splice incompatible outcomes into a fictitious single run.

ENGAGEMENT ENVELOPE
CURRENT STATE: Candidate tree 4691af58ae0ee3107b4e2e9b6b1508032944e357 remains
uncommitted/unaccepted. W's four representatives, exact99, direct60 and FULL9568
passed. Thirty named substantive rows remain open. Two limited runner-assurance
scopes and cumulative report accounting require completion; no current candidate
defect or successful new runtime escape was established by the receiving review.
RECIPIENT: SAME neutral independent reviewer that produced wa-09da07307c.
Expected host cwd /private/tmp/rw0-audit-entry.daLWIE. NOT the implementation writer.
ATTACHMENTS: NONE required. Use the exact retained W/A/B/C bindings below.
AUTHORIZED EFFECTS: Inert inspection; new audit-owned helper/ledger/fixture work;
the narrow rejecting-only admission correction if needed; unchanged-candidate
residual validation under byte-identical QtcM plus admitted WA1; protected evidence.
NO candidate, policy, repository, runtime, product authority or publication change.
EXPECTED RETURN: One cumulative disposition, corrected coverage and assurance
ledgers, full report, and one reopened evidence ZIP. No routine user relay between
internal checkpoints or ordinary fixture corrections.
PROJECT SNAPSHOT: None requested. PR #17 / 61d0330aba1160f7f5e7d9c541a325222d1c61e5
is retained integrated baseline evidence, not a fresh Git observation.
NEXT ACTION: Return to ChatGPT before any candidate repair or live commit gate.

0. ENTRY AND EFFECT CEILING

Read this entire prompt. A necessary read of the exact host-exposed instruction
file solely to load it may precede the declaration, in the actual neutral cwd.
Before any OTHER operational command state actual host cwd, input bindings, exposed
project/repository binding or unknown binding, and effect ceiling. Requested cwd
is not proof. Missing/different cwd or exposed live checkout => stop without probing
that checkout. Unknown binding alone does not authorize discovery.

No Git/status/pwd/AGENTS/bootstrap discovery, repository or sibling access, home or
Downloads enumeration, app/session-store access, broad host/log/process search,
ambient environment dump, subagent, remote/provider/network/ES/Bridge contact,
installation, runtime substitution, mount/volume creation, privilege escalation,
host-protection or project-setting change. Read named inputs at their exact bindings,
never search their directories. Candidate guidance is read only from authenticated
A. Embedded old mandates are requirements evidence, not effect authorization.

The trusted supervisor prepares owned inert data, performs bounded WA1 checks and
captures protected evidence. It never imports candidate code, runs candidate SQL,
or invokes candidate fixtures outside QtcM. All candidate imports/collection/tests/
child callbacks/causal SQL remain in QtcM after actual WA1 admission. Keep the
implementation writer idle. No source/test/schema/doc change, staging, commit,
push, PR, merge, release, deployment, user/product DB, or executable authority.

No test edit, outcome substitution, filtering, skipped test, altered child argv/env,
pytest rootdir/config/ignore/plugin injection, hidden cache/validator bypass, or
external cleanup credited as candidate behavior. In-process observers are
instrumentation, not adversarial attestation authorities. Reports are evidence,
not Coordinator/Git/runtime truth.

QtcM stays EXACT: 4,086 bytes /
323ddc662ca3260365136573d08b25fe635ad448b84b4a673cf99533b0f89d0a.
There is NO permission budget, policy rebind, new W slot, network/signal expansion
or unconfined fallback. Its Qtc prefix remains 3,414 bytes /
8cdccd5fc9fd97ddc034d3d454d2d0b63d2342279fc10e3eecb078ba905aa109.

The selected trust model remains one trusted, serialized supervisor and no
malicious supervisor or hostile concurrent same-account/privileged host actor.
Census/postchecks do not prove continuous race-free custody. Do not manufacture
a global-process absence claim. M's actual preplaced-hardlink runtime failure
remains a failure; admission prevents contaminated preparation from proceeding.

1. EXACT INPUTS, RECEIVING FINDINGS AND FINITE WORK

1.1 Inputs and safe authentication

W — current suite passes and partial WA1/residual evidence:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/wa-09da07307c/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_wa-09da07307c.zip
 49,940,248 bytes /
 718b49bc34d84cd6dc30bfe295970765d93e12238892c1c74145fe0fc76baf81
 817 regular files; 102,549,472 expanded bytes; 816 self-excluding manifest rows.
 REPORT.md: 23,084 bytes /
 fe1dc567e94cd97a963423d42741c1c31dda253883ec125714fe3cbc7aca6022
 MANIFEST.json: 204,233 bytes /
 67a353ff7188b70659a23c29cae94108f47dfdfb7f6d93fefb5f1dc215a9a826.
 Prefixes:
   WX = audit/execution/wa-09da07307c/
   WE = audit/evidence/wa-09da07307c/
 W embeds exact M once under carry/:
  RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_md-812d7d86be.zip
  6,677,682 bytes /
  10d793d8d18046d7afa5385aee832576e90e3378ccaff14b58f133b3fe31ad4f.
 M embeds U, which embeds T, then S, then R. No redundant outside copy required.
 U: 6,221,246 / 888edd2777a8c47eb06c37b37a3ad09d1e0efc7188c17a9b9cfce3cdaff4aa37
 T: 5,878,210 / dc754506dff6d3cc9ab803814cb4137a2f4094a9ecc3f8c5bd3bd69d6952ee4a
 S: 2,947,049 / 3dda92c95c2ab99d477271a834d181df80fce270f23c38c87eb3e8299ced1ad7
 R: 1,650,029 / ffd593b643c1c6fc6c064a84d9b473ce4f34cc1b2f1be35706d0b2d08db4bd2f.

A — unchanged candidate:
 /Users/ds/.codex/rw0-terminal-historical-witness-tcp5rwoh/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip
 48,978,087 bytes /
 6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42.
 573 regular members / 572 covered; 183,558,511 expanded bytes.
 package/member-manifest.json: 123,205 bytes /
 049139eaac16a03b36952faa703c992f5ef13adad44807873921af817e7b8e43.
 evidence/IMPLEMENTATION_REPORT.md: 19,549 bytes /
 c52141d0fcf15701496c4dec18133361a78b8f043796078340e24eed4bdae2d5.
 No new standalone-report equality prerequisite.

B — inert original implementation requirements:
 /Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt
 38,100 / 9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f.
C — inert S01/A03 requirements:
 /Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt
 29,145 / 7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd.
A inputs/mandate.txt is the historical-admission/witness amendment:
 28,439 / 6e978d57abfbadf7d8120eb58ea75651a60a44c42d6279ff8a9108c41c8b2da4.
Read requirements and owning current docs; do not execute old implementation directions.

An actually host-exposed identical copy is a permissible exact binding. Missing
named input => identify it, not a namesake search. Inspect archival programs as data
before any separately authorized copying/adaptation; never run archived verifiers,
cleanup/packaging scripts or candidate imports opportunistically.

W bounds: 1,000 members, 64 MiB/member, 256 MiB total expansion.
M/U/T/S: 500, 32 MiB/member, 64 MiB total; R: 500, 2 MiB/member, 20 MiB total.
A and necessary nested history: 5,000, 150 MB/member, 350 MB/archive, depth6,
1.2 GB cumulative unique expansion. Cache identities. Authenticate complete
self-excluding manifest size/hash/CRC/numeric modes, normalized relative regular
unencrypted names, Unicode/casefold uniqueness, no traversal/link/special/prefix
collisions before payload use. Do not unnecessarily re-expand source history.

Reauthenticate current A and reconstruct source without Git:
 327 paths; tree 4691af58ae0ee3107b4e2e9b6b1508032944e357;
 final-C/final-D/postcleanup manifest encodings identical, 109,923 bytes /
 1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1;
 326 OS0644 and one OS0600 tests/test_c2b3_private_atomic_program_initialization.py,
 all Git100644. SQL0008 30,178 bytes /
 a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254.
All 327 endpoints stay immutable. No 0009 or extra product module.

1.2 Supported W execution and exact revision binding

Read W REPORT.md, WE/RESIDUAL_RESULTS_CURRENT.json, A01_A18_CURRENT.json,
WA1_CONTROL_LEDGER.json, runtime/admission records, current source binding, raw
suite observers/JUnit/output, exact helper/revision code, incidents and cleanup.

Receiving inspection authenticated W/M/U/T/S/R/A and rebuilt all current source
payloads. W's five opening full-row source copies and twenty-four standalone
captures match A. One after-labelled phase-probe capture occurred before closure;
use the separately closed capture, never the early label as closure proof.

Suite revision:
 WX/revision_v5_frozen.json SHA-256
 97e63c9e0f439c6d123a710814b5d429183111f57076c442d0d85f1bc0aefac5.
 WX/wa1_gate.py: 23,072 bytes /
 65724bcfe02a3e598c84781caa38d67aea79342ddabc0290cabf6303c7fcb368.
 All thirteen active helper payloads match the recorded revision.
 WX/bootstrap_wa.py SHA-256
 e628fe9175186c82e384e941b630cc84f7426248e1fd738895cab04c4c5ff605.
 Observer code SHA-256
 22e2f2af60801d0ecab2b6fe11cbae0b6a3268c6bc5c73d7c4fa02bbb23b1b71.

Raw independent parsing reconciled:
 - smoke_representatives_v5: 4 exact IDs, 12 passed phases, zero warnings;
 - smoke_fixed99_v5: 99 exact IDs, 297 passed phases, zero warnings;
 - direct_collect_v5/direct_run_v5: 60 exact ordered IDs, 180 passed phases,
   zero warnings, ordered compact-JSON digest
   229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467;
 - full_collect_v5/full_run_v5: 9568 exact ordered IDs, 28704 passed phases,
   exactly the three permitted B2c warnings, ordered digest
   25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9.
 - exact99 digest
   f242e64dd779abab8a7ff39c64a69e852524b51b85ee1d61b3f0228b0a178224.
All six main processes exited0, no timeout/emergency, empty raw stderr, and actual
observer/JUnit outcomes match. FULL has no selector. Final suites have no child
tracer. Every explicit JUnit audit-node property is correct; other legitimate
candidate properties remain. W's reviewer-v1 sole-property mistake was corrected
against the same run outputs, not by another test execution.

All six actual admission/postclosure records pass at their measured scope. Receiving
recomputation found no protected-to-writable inode overlap, single-link protected
identities, closed mutable hardlink groups, empty W slots, unchanged old protected
rows, and only the two expected per-launch protected record additions. Every output
copy binds equal bytes to a distinct exclusively created protected inode. Direct-
child reaping and empty tracked initial groups are recorded, not a universal
unknown-descendant-custody claim.

These are carried independent execution records, not tests run by ChatGPT. Preserve
the prior Qs failed FULL and old M runtime failure at their own scopes.

1.3 Correct the cumulative-accounting regression BEFORE new product fixture work

W's broad A01–A18 prose is not an authority to reopen completed independent predicates.
Its embedded M_row_unchanged objects and older raw payloads survive exactly.

Concrete contradictory summaries:
 - W REPORT.md:54 calls the private replan mismatch untested, but S
   causal_completion_replan2 contains two passing fresh-absent/persisted cases
   reaching record/read/replay/recovery. Scope: hostile post-construction replacement
   with a valid alternate private template under an unchanged claimed safe identity;
   not a second ordinary valid command or a cryptographic collision.
 - W REPORT.md:55 relists the distinct V22 ref control, but S
   causal_completion_source3 has the positive plus four detached claims, including
   distinct_proposal_ref, each with actual checked-projection reach.
 - W REPORT.md:62-63,106 broadly relists calendar/admin/connected work already partly
   supplied by R/S/T. S causal_completion_time has 23 correctly digested malformed
   and three valid timestamps per time-bearing row; outcome has none. R's five
   source-coherent normals and selected negative/rollback controls retain their scope.
 - C4 remains COMPLETE in its normalized scope: S's seven blocks, 28,910 actual
   authorizer/wrapper events and 28,388 normalized SQL classifications. Do not
   replace its actual stop-shape binding with W's broader managed-wrapper label.

WX/assemble_current_ledgers_wa.py:121-132 hardcodes mandatory_coverage_gap for every
A row and generic new gap text. Correct the cumulative register as DATA:
 requirement/predicate -> source identity -> exact earlier/new helper version ->
 actual reached seam -> raw record -> limit -> still genuinely missing part.
Do not overwrite old reports or clear the entire A row by extrapolation. Do not
describe the absence of a NEW rerun as absence of independent proof. No requirement
reduction or new trust in writer records follows.

W's three new probes (sql_admin, constructor, phase_boundary) passed under separately
identified probe revisions. They supplement earlier work, but the stable results
record all thirty named open predicates as NOT ATTEMPTED at their precise target.
Do not repeat those warm-up probes instead of starting residual work. The new phase
probe labels a broad managed wrapper and scans SELECT literals in four function
bodies; it is not a stronger replacement for R's actual shape-function observation
or S's C4. A generic denial is not an exact error-class proof.

1.4 Two narrow runner-assurance evidence completions, not a design reset

Create separate assurance rows WA-C01 and WA-C02. Preserve the 56 product/residual
IDs and G01's actual compatibility evidence. Do not pretend these two runner rows
are two more product defects or replace the thirty product rows with them.

WA-C01: WX/runtime_link_wa.py:65-109 runs the added hardlink/move probes only in ONE
contained process. WX/control_matrix_wa.py's four roles cover original symbolic-alias
operations, not this new hardlink matrix. Complete the previously required fork,
exec and fork-then-exec scope using the same finite source/destination classes.

Two other exact weaknesses must be corrected in this small supplement:
 - At :92-94, rename adds '_moved' to the two W basenames, producing NONWRITABLE
   sibling paths. Use the exact actually permitted empty W destination for those
   rename attempts. Do not call denial at a forbidden sibling proof of a protected
   move into an allowed slot.
 - At :41-51, descriptor opens and os.link share one OSError wrapper. Record each
   opened descriptor/stage, positive reach and actual link syscall outcome. An
   earlier descriptor-open denial cannot count as os.link denial.
No full Cartesian explosion: retain the five selected source/destination classes
and the three valid descriptor forms; cover the required four process forms and
paired within-writable link/move positives. Use disposable sentinels only. No
destructive test against the 327 sealed files or real evidence.

WA-C02: the six real-hardlink refusals and their paired clean launches are supported.
No active-helper symlink/special-path refusal is supplied. Add that actual-gate
control using a NEW synthetic registered marker/helper, never an existing source
or historical helper. The ordinary valid counterpart must admit and execute.
Reject a symlink or nonregular special-file counterpart without following content,
before any candidate import or target spawn. Use an external bounded timeout;
a timeout is not a passing refusal.

Static concern: WX/wa1_gate.py:289-315 invokes active content binding even when
validate_layout has already returned rejection reasons; bound_read at :101-106
opens before checking regular type. The narrow audit-only defensive correction
authorized here, IF needed, is to emit the same explicit ADMISSION_REFUSED outcome
from a known-rejected metadata snapshot BEFORE active content reads. Preserve
complete rejection reasons/records and every admissible-layout verification. Do not
add a new accepting branch, allowlist a poisoned fixture, or weaken any check.
Keep exact predecessor/successor bytes/diff and prove the clean accepted branch
unchanged. This is a rejecting-only audit-helper correction, not a policy/source
change. An unexpected broader defect is a specific stop, not general rewrite scope.

Complete these two scopes before NEW candidate execution. Preserve W suite results
as observed passes; do not claim that their old interval had these missing controls.
If the same policy and algorithm's admitted states remain sound, the prospective
cumulative assessment may use the targeted supplement plus those exact-source
passes under the repeat rule above. An actual flaw affecting historical admitted
states requires explicit invalidation/impact treatment, not silent carry-forward.

1.5 Exact thirty-row product backlog and work order

Frozen ledger (56 rows), WE/RESIDUAL_LEDGER_FROZEN.json:
 fffc8d2f50046c1fa8df3b0f1d63c1c16348e2f628d5c07dd3d6c6d0b4bbcd56.
Preserve every ID/history. The open IDs are:
 C1A01 C1A02 C1A03 C1A04
 C1B03 C1B04 C1B05
 C2A04 C2A05 C2A06 C2A07 C2A08 C2A09 C2A10 C2A11 C2A12 C2A13 C2A14 C2A15 C2A16 C2A17
 C2A19 C2A20 C2B11 C2B12 C2B13
 C3A02 C3A03 C3A04 C3A05.

After targeted assurance, begin with a genuinely outstanding selected-acceptance
predicate, not broad constructor/schema revalidation. Complete the following
coherent batches in one engagement, saving/reopening internal checkpoints:
 A. C1A01–04: wrong selected reference, missing selected fact, foreign selected
    lineage/decision/digest, legitimate unrelated same-managed-store coexistence.
    Governing lookup: _sqlite_rw0_terminal_outcome.py:193-199. Relation:
    _rw0_terminal_outcome_plan.py:148-160. Build checked-owner-valid parents and
    record exact reachable lookup/plan rejection and nonmovement. If a desired
    deeper specimen is precluded by an owner/FK invariant, prove that implication
    and exercise the reachable boundary; do not substitute arbitrary bad bytes.
    Two legitimate subjects in one owned managed STORE need not use the same
    hardcoded fixture chain. No new product multirun API or weakened owner.
 B. C1B03–05: graph roles/cardinality/order/self-digest; repeated-column/alias
    disagreement; source associations beyond the exact source3 cases already passed.
    Reuse the positive coherent owners, independently reseal the intended fault,
    and name the first rejecting predicate. Avoid early unrelated error masking.
 C. C3A02–05: exact still-uncovered context/outcome/result/receipt FK, unique,
    nullable-pair, composite/profile/blob predicates. Use fresh unoccupied targets
    with valid parents, real FKs/guards, paired insertion rollback/savepoints, exact
    intended SQLite error and nonmovement. T's isolated receipt-result-pair FK is
    carried, not reopened. S's calendar/admin matrix is carried at its exact scope.
 D. C2A04–17 plus C2A19–20: literal seventeen-route sequence and family classification.
    Source _sqlite_rw0_terminal_outcome.py:262-284 short-circuits. For each later row
    provide physical first-match proof where representable OR exact earlier-match
    implication (state class, field equalities, owner/FK constraints, earlier route).
    Complete-family implications alone do not settle damaged/partial/foreign state.
    Never fake query return occupancy, disable the tested guard, demand a digest
    collision, or label one unsuitable fixture impossibility. Retain routes1–3 and
    seventeen-column occupancy at their existing narrower scope. Complete damaged
    self-digest exact/winner refusals and foreign/absence recovery without disclosure
    or fragment repair/retry.
 E. C2B11–13: remaining in-memory lease versus durable issuance/closed session;
    receipt-last/second-readback fault rollback; recovery cleanup uncertainty and
    no automatic retry. Use real owner/controller injection-hit counts, exact error
    and recovery classes, protected snapshots and fault-removal positive. Carry
    earlier closed/stale/cleanup2 proof; do not rerun every exception cross-product.

At each checkpoint close individual predicates only through source + independent
expectation + valid paired setup + real hit/result + nonmovement/disclosure evidence
or a precise supported invariant. Keep the source/fixture/privacy limits. A candidate
test pass alone is not an independent expected-outcome derivation.

Save results for completed rows before expanding the next batch. Do not return
another generic C1–C3 list if a practical limit occurs: name the exact attempted
predicate, what was built/reached, the real constraint, and restart point. Honest
partial completion is allowed; inventing a blocker or repeating only already
proved warm-ups is not. No routine user relay, background work, or future promise.

The sections below state all substantive requirements. Use mapped carried proof
where specifically supported; no coverage reset and no silent requirement removal.

2. SUBSTANTIVE REVIEW — THE EXPLICIT TWO-LAYER AMENDMENT

The earlier whole-operation zero-current-stop-SELECT criterion failed under the
old mandate. That blocked result remains true. The engineering decision is to
preserve mandatory shared storage safety, not to skip it to satisfy a terminal
history test. The current candidate is judged against the following amendment:

Layer 1: existing operational admission remains mandatory. Session/process/thread/
lease validity, database binding/custody, BEGIN IMMEDIATE, exact managed schema,
history/catalog/posture and invariants, writer ownership/fencing, and current
protected disclosure remain intact. The existing global_stop_current singleton
shape validator may read that current row only for managed-store validity.
Valid active/clear status, version, timestamp and directive identifiers must not
be compared with saved terminal stop or turned into current effect permission.
Denied/unreadable/malformed managed state may prevent disclosure or leave recovery
unresolved. It must not be misclassified as stale terminal history or definitely
absent original execution. No cache, successful-assessment stub, invariant-skip
flag, alternate connection/controller, or production validator weakening.

Layer 2: historical checked read, receipt-present replay and recovery use saved
full postimages/stop and checked immutable predecessors after admission/fencing.
The five current-head tables are not consulted during the historical operation.
Current-stop reads are permitted only at the existing shared invariant check,
not as a general table-read exemption or later semantic terminal query. Receipt
is first TERMINAL-FAMILY lookup, not first SQL statement. Exact original result,
time, graph, receipt, source associations, protected disclosure, immutable
acceptance binding, complete competing-winner/absence proof and uncertainty
classifications remain required. Historical operations do not require recording
permission or renewed acceptance-unclaimed eligibility. Fresh receipt-miss
recording retains actual current five-head/stop checks unchanged.

This amends only the overbroad current-stop-query requirement. It is not a waiver
of the constructor defect, five-head independence, disclosure, SQL grammar,
transaction safety, audit isolation, or other cumulative acceptance controls.
Verify the two owning documents state the distinction and preserve the old
failure as history; do not create another silent interpretation of either layer.

Inspect at minimum the complete changed witness module, changed tests and docs,
full terminal contracts/rows/plan/SQLite owner, and actual shared admission call
chain (not only wrapper names). Current anchors:
  sqlite_transition_transaction.py:2759–2779,4753–4773
  sqlite_migration.py:2477–2523
  .docs/rw0-terminal-outcome-physical-closure.md:177–220
  .docs/sqlite-operations-and-recovery.md:722–730.
Python basenames are under source/src/ge_nwp_coordinator/; docs under source/.

2.1 Independently test the repaired constructor and mutable aliasing

TerminalHeadWitness at _rw0_terminal_head_witness.py:48–96 must validate ordinary
construction, not only checked factories. Independently test valid direct/factory
triples for accept and replan and all five typed owner roles (8/9/41/9/8 fields,
valid nulls, self-digests). Exact bytes, outer tuples, dictionaries, keys and
scalar types precede hostile comparison/coercion. Bytes, full rows and compact
coordinates must match rather than silently replacing invalid supplied parts.

Require negative controls for the previous malformed type triple and b'{}'/empty
postimages, bytes/list/tuple/dict/string/int subclasses, bool-as-int, wrong arity,
missing/extra/reordered roles or fields, wrong schema/digest, noncanonical and
oversize bytes, and valid canonical bytes paired with DIFFERENT valid rows or
projections. Calibrate a shared/per-instance hostile equality counter, clear it,
and verify zero hostile calls per invalid construction. Preserve built-in
positives and process-control propagation.

Mutate caller-owned maps and separately returned maps, then re-read both views
and canonical bytes and run normal downstream verification. They must remain
checked and unchanged. No unvalidated object token/factory escape or recursion.
Do not demand security against arbitrary reflection/object.__setattr__; that is
not the selected boundary. Verify unchanged wire fields/schema/digest domains
and valid consumer behavior, including exact original P1 replan operands.

2.2 Independently prove complete-operation phase behavior

Use real private WriterSession read, receipt-present record/replay and recovery,
not just a terminal helper. Trace and attach observation/denial at the actual
acquisition/controller opener aliases and account for every operation connection.
The candidate observer labels the full managed wrapper; independently establish
which SQL is genuinely in _verify_global_stop_current_shape. A phase label alone
does not prove shape-only use or permit arbitrary managed-phase stop semantics.

Observe real unchanged validator, ownership-read and issuance/fencing functions;
observation wrappers must call the real function and return its actual result.
Do not replace admission with a successful assessment or patch the predicate
being proved. Capture connection, phase, table/column and allow/deny results.
Calibrate each attached authorizer with owned allowed and intentionally denied
queries. Trace acquisition separately, including any connection work before the
observer attachment, and prove it cannot hide a five-head/later-stop lookup.
A zero-callback claim at the wrong alias is invalid. Column callback counts are
not SQL-statement counts or a fixed product invariant.

Required current-byte controls:
- real fenced accept and replan commits, then coherent later movement of every
  head and valid active/clear stop fixtures; under the layered denial policy,
  exact read/replay/recovery preserve original result/time/witness/graph/receipt
  and acceptance facts without new terminal or protected-row movement;
- original absence with positive/negative old-execution exclusion; complete
  compatible and incompatible competing winners under that same policy;
- deny the ACTUAL managed-stop read during admission: safe operational refusal
  before protected terminal-family handling, recovery unresolved where the
  unchanged controller so classifies; no no-write mislabel as stale history,
  definite absence, hidden retry, committed result or protected disclosure;
- malformed actual stop row or real query-return tuple, with validators intact:
  integrity failure rather than ordinary currentness; fault removal restores
  valid operation; bound process-control behavior remains unchanged;
- fresh receipt miss reads all five actual heads and stop. Stale expectations
  conflict without writes; correctly expected valid changed stop follows the
  current normal-record rule without conferring executable permission;
- denied/expired/foreign/malformed disclosure, closed/stale/fenced session and
  unavailable managed store remain non-disclosing. Fresh recording permission
  stays separate from historical protected disclosure and stop shape.

All synthetic later states/fault seams must be described as such. Do not call
a direct fixture UPDATE a newly supported product operator transition.

3. COMPLETE CUMULATIVE A01–A18 REGISTER AND CAUSAL OBLIGATIONS

Review the entire baseline-to-current terminal change, not only the five-file
repair. Supply exact archive-relative source/doc/test/SQL coordinates, severity,
and evidence class for every row: contract/current code, inspected test design,
retained record, independent execution, inference or limit. Unchanged bytes and
prior passes do not automatically discharge current mandatory controls.

A01 Authority: exactly five private normal terminal facts, separate from P1
 decision/acceptance, standing-policy grants, source facts and executable
 permission. No cancel closure, live supplier/contact, ES/Bridge/Git effect,
 service/scheduler/autonomy or publication authority.
A02 Preservation: legacy terminal V1/four validators, P0/P1 meaning, WorkSpec,
 Decision Basis/command-digest v2, preassignments, D1/D2, generic receipt, public
 StateStore/package exports unchanged. Audit original shared catalog/controller/
 writer-session terminal integration even though this immediate repair froze it.
A03 Grammar/types: closed command/context/outcome/row/result/recovery/witness
 schemas, exact built-ins before equality, canonical UTF-8/JSON and duplicate
 rejection, bool-as-int, safe refs/digests/calendar time, budgets and null pairs.
 Include direct constructors, factory consistency and aliasing; resolve A03/O1.
A04 Identity graph: independent domains/acyclic preimages, four sibling refs and
 route, optional assertions bound in command digest but not preassignments,
 graph role/cardinality/order, self-digest exclusion and repeated-column equality.
A05 Original operands: original P1 command and private replan operand transient;
 complete checked predecessor association required. Missing/inconsistent private
 content cannot be reconstructed from a safe digest or yield false certainty.
A06 Source association: actual checked P0/phase/Section41 A/C1 rank15/V22/P1
 chain and validation/review/proposal/result-set/observation relationships;
 membership counts or digest strings do not independently establish ownership.
A07 Acceptance: bind existing immutable acceptance only for accept; never create,
 mutate or replenish it. Wrong/missing/foreign facts reject. Legitimate unrelated
 facts must coexist without preventing another allowed terminal branch. No
 historical acceptance-unclaimed recheck.
A08 Heads/stop: observed full five-row witness, source/adapters/digests/links,
 replan historical P1 postimages, fresh actual currentness and stop facts; prove
 the precise two-layer amendment, not the withdrawn zero-stop-read property.
A09 Transaction: existing fenced lease/capability/controller; receipt-first
 terminal lookup; one captured time; protected posture/source/current/route
 ordering; context/outcome/result readback, receipt last, capability invalidation,
 one commit attempt, rollback/cleanup uncertainty. No application-head/stop/
 decision/effect update by terminal closure.
A10 Read/replay: original complete result/time/graph/receipt and source/witness
 reauthentication; current protected disclosure with mandatory store admission;
 no five-current-head or later semantic stop query, cognition/process rerun,
 fresh recording permission or acceptance-eligibility requirement.
A11 Recovery: complete exact original family or exhaustive original absence and
 exclusion, or complete compatible winner, only. Partial/foreign/damaged/aliased/
 incompatible families unresolved. No winner result disclosure, hidden retry,
 fragment repair or durable private-template fallback.
A12 Error/cleanup: failed or malformed reads stay operational/integrity, valid
 actual drift stays currentness. Stale/closed/fenced sessions, pre/postcommit,
 applied-commit/lost-return and cleanup uncertainty, KeyboardInterrupt/SystemExit/
 GeneratorExit propagation at the actual fresh/read/recovery/cleanup seams.
A13 Schema/admin: four STRICT immutable normal-only tables/eight guards;
 timestamp grammar, FK/unique/composite links/phase/decision/route occupancy,
 nullable pairs, blob bounds, zero seeds, current catalog/checksum/generation 2;
 exact fresh/prefix migration and old-binary/obsolete-0008/partial/unknown refusal.
A14 Connected normals: actual preseal source variations through real P0/D1/D2/
 Section41/C1/V22/P1/terminal owners; five distinct normal positives and detached
 negative; read/replay/recovery and no forbidden contact or protected-row change.
A15 Docs/assurance: cumulative current-versus-historical status, explicit amendment
 and private scope; fixed source/hash/AST/import/schema consumers and predecessor
 reconstruction retained; no dynamic oracle, skip/xfail or broad guard stripping.
A16 Privacy/artifacts: complete postimages remain safe owner metadata; no private
 replan text, raw capsule/prompts/process results, handles/PIDs/credentials in
 terminal rows or unsafe errors. Grammar review plus independently observed
 canaries; classify raw-index metadata, checkpoints and failed artifacts.
A17 Retained evidence: exact input/source/patch/commands/env/observer outputs/
 JUnit/IDs/warnings/captures and overlapping counts; limits in section 4 below.
 No writer record or causal-register label is independent execution.
A18 Independent validation: reached current-source causal probes and direct
 suite, independent SQL/admin controls, selector-free collection/FULL completed
 with exact IDs, outcomes, warnings and source-mode preservation. No live-state
 or production-readiness inference.

The following controls remain mandatory, including previously unfinished ones:

(a) S01 full-witness family: for EACH role, check complete field capture, valid
 nullable values, supported maximum witness bound, bad owner self-digest, valid
 self-digest with wrong immutable predecessor, wrong owner/link, and actual fresh
 head movement versus changed caller expectations. Use fully resealed synthetic
 histories so owner/context/outcome/result/graph/receipt digests are internally
 valid and the real relationship predicate is reached. Pair every resealer with
 a valid family built the same way. Restore ordinary verification for the actual
 read/replay/recovery. Prior program-only evidence is not five-role proof.
 No truncated witness, v1 fallback, desired-row synthesis or current-row backfill.

(b) Source/operand/acceptance: fully resealed detached validation, review,
 source-invocation and proposal associations, including a DISTINCT forged V22
 proposal reference rather than only a proposal digest; wrong/missing/foreign
 acceptance; LEGITIMATE unrelated acceptance-fact coexistence; inconsistent
 private replan content sharing a claimed safe identity across record/read/
 replay/recovery; no new process or private-text persistence. The single-chain
 fixture's inability to construct an unrelated fact is not proof of impossibility.
 Build coherent independent synthetic state through checked owners, or document
 exact invariant proof and the remaining limitation. Do not credit an incoherent
 split-reader or early FK/digest failure as the intended relationship test.

(c) Disclosure/recording: all selected finite posture predicates, including
 positive, denied, expired, malformed, foreign-bound and absent protected subject;
 old-execution-excluded True/False; truthful claimed False/None after accepted
 P1. Fresh write needs recording AND disclosure, historical operations disclosure
 only; command reuse/assertion mismatch cannot disclose a protected result.
 Complete the expired/malformed/foreign/protected-absence matrix rather than
 inheriting earlier positive/negative permission examples.

(d) Physical routes: derive all original occupancy routes from the checked
 code (the preceding audit identified 17). Seed EACH route physically in a
 separate owned coherent scenario, with valid positives and relevant partial,
 foreign or damaged family states. Mocking query return values alone is not
 physical occupancy evidence. Check exact/winner/absence classifications and
 no winner disclosure or retry. If a route is not representable under an owner
 invariant, prove that with exact schema/contract and record the scope; do not
 invent an invalid row as a legitimate winner or silently drop the obligation.

(e) Transaction and error matrix: faults after each of the four inserts,
 result/receipt readback, receipt-last boundaries, precommit rejection,
 one applied commit with lost return, postcommit and recovery cleanup uncertainty;
 stale lease/issuance, closed and fenced sessions; actual denied SELECT versus
 malformed selected rows across current owners; all three process-control
 exceptions at meaningful fresh/read/recovery/cleanup seams. Assert target
 rows, committed bytes, protected-state nonmovement, and actual injection hits.
 No hidden second commit or automatic retry.

(f) F01/O1 regression: independently exercise raw SQL and row construction,
 not only planner success. Use otherwise valid parent/related state, paired
 valid inserts, independent negative self-digests and the repaired existing
 _time owner. Cover invalid month/day/leap-century/year-zero/time overflow,
 canonical-format deviations, Unicode digits, embedded NUL/whitespace/nontext,
 NULL handling and valid year endpoints. Reach all three recorded_at columns;
 outcome has no timestamp. Verify failed predicates are zero/not permissive
 NULL and high-level invalid row/time behavior stays integrity/unresolved.
 Reproduce the old invalid-month predicate only in owned predecessor synthetic
 state as a grammar comparison, never claim an ordinary writer exploit.
 Recalibrate O1 independently before claiming no hostile equality calls.

(g) Five connected normals plus three unsupported cancel shapes and unsupported
 profile. Source variations occur BEFORE real artificial worker/checker/capsule
 sealing, not by relabelling passed evidence afterward. Use inspected fixtures
 for setup only; independent expected branches/facts/errors are required.
 Observe artificial local process/contact limits and privacy canaries.

Run bounded causal controls before a long FULL launch. Do not start/continue
FULL while a known material blocker already prevents acceptance. Independent
controls must state setup validity, actual reached seam, expected result/no-write
predicate, source identity and limits. Candidate tests passing are not separate
independent oracles. Any mandatory control not established remains explicit and
prevents complete acceptance unless an exact supported invariant makes the case
inapplicable; fixture difficulty alone is not such an invariant.

Independent SQL/admin expectations:
  after 0006: 68 tables / 122 triggers / 5 explicit indexes
  after 0007: 74 / 134 / 5
  after 0008: 78 / 142 / 5, application generation 2.
Execute all eight authenticated literals in disposable owned state. Preserve
pre-0008 object SQL/shape; check exact prefix upgrades, no seeds, immutable
update/delete guards, FK/unique/pair/profile/normal/blob/time constraints, and
refusal of old binary, original and S01-era 0008 checksums, old SQL with current
history, missing guard, foreign object and partial/unknown/checksum divergence.
No current schema/contract change, 0009 or product database upgrade is allowed.

4. RETAINED EVIDENCE AND INDEPENDENT VALIDATION

4.1 Reconcile the current writer records as DATA

Paths: evidence/validation/<direct|connected|focused|full>/, gate-summary.json,
phase-read-map.json, supersession-record.json and current source captures.
Require independent parsing of collection observer, execution collection,
setup/call/teardown records, explicit JUnit nodeid properties, actual launch/exit,
stdout/stderr as actually retained, warnings, and four complete source captures
per gate. Do not invent a separate stderr file for a combined log.

Expected current retained gates:
  direct: five complete modules / 60 cases / zero warnings
  connected: one complete module / six cases / zero warnings, inside direct
  focused: 126 complete modules / 8,266 cases / three known warnings
  FULL: selector-free / 9,568 cases / three known warnings.
All narrower sets must be included in FULL; totals overlap and do not add.

Ordered-ID SHA-256 uses UTF-8 JSON array, ensure_ascii=False,
separators=(',', ':'), with NO trailing LF:
 direct 229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467
 connected 81e14e3fa1b85a7be2ea6fafac85974839145bbcb6397e6da0bb1feeba060aac
 focused 419d37ff399689788123583f614a1d8b107ef712e2368ca179cd6e65fbec5104
 FULL 25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9.

All sixteen source captures have the same 105,550-byte envelope, SHA-256
0c0b4017371a798731a63825ac63922c361189e37f5a713f5c4f7ec06e9b32cb.
Require full row equality to the different canonical source-manifest envelope,
its embedded canonical hash, correct final tree and no extra/missing paths.

The retained direct JUnit phase maps report six operation connections, 60
managed-stop column callbacks and six intentional head-denial calibrations
for EACH accept/replan scenario. Independently parse the raw properties. Do not
substitute those counts for actual phase/call-chain verification, or label them
SQL-statement counts. Acquisition has separate test observations.

4.2 Known retained-evidence limits — do not silently fill them

The active external gate_observer source and a launch-bound helper digest are
not retained in the current outer ZIP. Old nested helpers cannot prove that
current code's identity. Writer records can be internally reconciled but their
observer's nonselecting implementation is not thereby inspected. The independent
runs below must use newly audit-authored, retained, inspected and calibrated
observers. Independent fresh evidence can establish current behavior; it does
not retroactively establish the missing writer helper.

The seven-case checkpoint has receipt/JUnit evidence and a different declared
tree 85c9fea24f4f74f358f9cc59a5d323d836a04041; it lacks a complete checkpoint
source payload here. Its historical save/reopen/source-binding claim stays
qualified and supplies no final-byte credit. Similarly, one retained patch
manifest per kind is not proof of two writer runs; independently reconstruct
current endpoint/patch identity rather than invent that history.

These are disclosed retained-evidence/process limits, not automatic production
findings. Determine their actual acceptance impact. Complete current independent
source/runtime evidence must not be replaced with writer claims. Any unmet
mandatory evidence requirement is INCOMPLETE, not a pass by wording change.
Preserve failed/superseded source/test results separately. The prior audit's
live-status/path probes and interrupted FULL remain historical limits.

4.3 Required independent execution gates

Under the explicit prospective section 1.3 scheduling amendment: after current
source inspection/reauthentication, exact final QtcM readiness and observer calibration,
and with no known material candidate defect or unsafe dependency, execute these
complete regression gates BEFORE additional residual custom-fixture work.
All outstanding causal/admin obligations remain required for final ACCEPT:

1. On a fresh exact source copy, collect and run these five COMPLETE modules in
   this order (no node selector):
   tests/test_rw0_terminal_outcome_values.py
   tests/test_rw0_terminal_head_witness_regression.py
   tests/test_sqlite_rw0_terminal_controls.py
   tests/test_sqlite_rw0_terminal_migration_0008.py
   tests/test_sqlite_rw0_terminal_connected.py
   Expected 60 ordered unique passes, including six connected cases.
2. On another fresh exact 327-file copy, independently collect and run the
   repository selector-free FULL. Expected 9,568 ordered unique IDs and passes
   in the retained FULL order. No path, module, node, -k or -m selection.
3. Record collection/execution-collected/call/JUnit identities, explicit JUnit
   nodeid properties from the start, all setup/call/teardown results, warnings
   and real process exits. Require exact ordered agreement and zero failure,
   error, skip, xfail/xpass or failed noncall phase. An invertible JUnit mapping
   is useful supplementary evidence, not a silent substitute for the required
   explicit-property observation.
4. Independently inventory warnings. Direct has none; FULL may have only the
   three known DeprecationWarning multithreaded-fork nodes in
   tests/test_sqlite_b2c_writer_session.py:
   test_operation_guard_close_waits_and_retains_authority_until_exit
   test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
   test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock.
   Owned paths/PIDs may differ; other class/node/message differences require
   investigation, not filtering or suppression.
5. Capture complete raw bytes/modes/extra-file inventory immediately before and
   after collection AND before and after execution, with source-tree rebuilds.
   All 327 endpoints and modes must remain unchanged. At every boundary capture there must be no generated extras; only the prospective, exact-path transient fixture exception in section 5 is allowed during the inspected D1 test.
6. Audit probes remain outside candidate discovery and separately counted. An
   independent focused 8,266-case rerun is unnecessary if exact FULL inclusion
   is proven; do not claim one ran. No writer FULL or earlier audit count can
   replace the independent completed FULL.

Use recorded equivalents of:
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --collect-only --basetemp=<owned-collect> <complete-direct-modules>
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --basetemp=<owned-run> --junitxml=<owned-junit> <same-direct-modules>
For FULL remove all module/path/node selectors from BOTH commands. Inspect
pytest config, conftest and setup/child-launch seams before import. The observer
may record IDs/outcomes/warnings and add JUnit nodeid properties, but must not
select, reorder, skip, change assertions/results or suppress warnings. Keep its
exact source/digest in the evidence and bind every launch to it.

Do not edit candidate source/tests to get green results. Correct audit-only
parser/fixture/observer mistakes transparently on fresh owned state, retaining
failed attempts. A genuine candidate failure triggers findings, not retries with
weakened oracles. An interrupted FULL gets no complete-pass credit; preserve
actual partial records and absence of final JUnit/observer rather than infer
completion from displayed percentages.

5. FROZEN POLICY, TARGETED ASSURANCE COMPLETION, AND RESIDUAL EXECUTION

This section supplies the complete runner/effect requirements. It is not an order
to repeat every already supported W control. Section1.4 identifies the ONLY missing
assurance scopes that require new synthetic execution, alongside present-layout
admission and a small positive readiness check before new candidate work.

5.1 Layout, preserved files, and fixture lifecycle

ROOT is exactly:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz
Existing source copies:
 ROOT/mock_source/tc-4fd7e168a0/{master,causal,direct,smoke,full}
Existing immutable policy:
 ROOT/execution/md-812d7d86be/QtcM.sb
Source/test W exceptions, and NO other source write slots:
 ROOT/mock_source/tc-4fd7e168a0/smoke/src/ge_nwp_coordinator/_rw0_d1_probe_temp.py
 ROOT/mock_source/tc-4fd7e168a0/full/src/ge_nwp_coordinator/_rw0_d1_probe_temp.py

Choose one fresh unique rc-<nonce> suffix under ROOT's existing execution/scratch/
home/tmp/evidence/denied and, for noncandidate calibration sentinels only,
mock_source. Preserve every W helper/revision/report/source copy; do not overwrite
a historical path, link-copy, rename old output into the new protected namespace,
or clear an unexplained object. New probes remain outside candidate test discovery.

Reuse the five active source copies only after full current-byte/mode/extras and WA1
checks. A present mismatch is a binding stop, not authorization to repair or reset.
If a required copy is absent, independently recreate from authenticated A into the
same previously permitted slot, exclusive/no-follow with the recorded modes and no
hardlinks; record that as new copy custody, not historical preservation. New
provisional DB/process/output state is always in freshly owned writable locations.

W cleanup removed only its approved calibration fixtures. The exact two already
authorized immediate-root metadata fixtures may be recreated after lstat proves
absence and the ten preserved root members authenticate:
 ROOT/rw0_meta_plain_md812d7d86be.txt
 ROOT/rw0_meta_dir_md812d7d86be/inside.txt
Use exclusive independently created safe non-code regular bytes, owner-private modes,
new dev/ino/nlink/hash records, and no source/test/config names. No new immediate root
entry. Record the new twelve-entry census and freeze its identities in the NEW
runner binding; never overwrite W's original root-preparation record or claim
the old fixture inodes were restored. Unknown present fixture/type stops.
QtcM's bytes and exact permissions remain unchanged.

5.2 Enforced WA1 invariant; no relaxation of trusted preparation

Before EACH actual launch, inventory the entire artificial owned root, not only the
new namespace. The writable footprint is ALL scratch/home/tmp, including old
reachable namespaces, plus the two exact W slots. Protected audit regular files
are all remaining source/helper/evidence/denied/root files.

Require:
- ordinary owned protected regular files, nlink1 and distinct nonzero dev/ino;
- no protected identity reachable through the writable footprint;
- closed regular-file hardlink groups within that entire writable footprint, with
  path count equal to nlink and an explicit audit origin for preexisting files;
- immutable current source/helper/policy/runtime bindings and expected root membership;
- no source/evidence/protected descriptors inherited by the workload;
- the sole trusted supervisor introduces no protected-to-writable alias and no
  concurrent protected preparation mutation while a workload runs.

A protected nlink>1 cannot be excused because its other path is not found in the
new suffix. Reject; no host-wide alias search. Same-byte distinct files must admit.
Directories are not subject to the regular-file nlink1 rule. Known internal writable
hardlink/symlink fixtures created by unchanged tests are not product defects, but
must be classified and group-closed after child closure. Unknown preexisting
writable aliases/data cannot be admitted solely because their UID matches.

Authorized supervisor census is bounded no-follow metadata only inside ROOT's
seven existing subtrees and immediate regular files/two W slots: <=100,000 entries,
depth<=64, no mount crossing or directory-symlink traversal. Fresh descriptor-relative
stat/readlink/identity checks, with active-path ancestry bound to ordinary directories,
not cached path strings. No recursive content reads or scans outside ROOT.
Protected content reads remain limited to named inputs, active source/helpers/
policy, selected carried evidence and synthetic targets.

Existing guard code and policy are trusted only after source inspection and current
identity checks. Use one actual launch_if_admitted path. Known contaminated layouts
must emit refusal before target spawn/candidate import. Do not call an isolated
checker while leaving a bypass route to actual sandbox-exec.

The root expectation and new probe registry are new bindings, not new accepting
semantics. Namespace/registry-only revisions must retain a complete exact diff
against W's v5/probe2 gate algorithm, frozen helper maps, source/expected-root
identities and runtime. No code import from a mutable helper path. Do not overwrite
the v5 revision to pretend it included later probes.

The only potential algorithm correction authorized here is section1.4's early
metadata-rejection handling. Evaluate it explicitly, retain failed attempts and
a new digest if used, and test the actual rejecting and clean paths. Do not change
path-policy rules or admit preplaced cross-boundary aliases. Any broader protection
or successful-launch change is out of scope and requires a specific incomplete
finding and impact assessment, not a silent rewrite.

5.3 Targeted qualification and repeat decision

Carry W's six source/evidence/helper/root/denied hardlink refusals, historical scratch
case, six paired clean positives, same-byte-distinct positive, 160 original role
controls, seven scoped-signal records, live-peer controls, and observer calibration
at their measured scope. Their retained code must be inspected, not executed blindly.

Before new candidate work:
1. Reconstruct clean current layout and verify the entire invariant and source.
2. Implement only WA-C01's missing per-role link/move/destination/stage observations.
   Use the five existing policy-class pairs. Record child process form and actual
   PIDs/PGIDs/SIDs, target/destination identities and nlink, syscall-entry markers,
   errno, destination absence/nonmovement and complete reaping.
   At descriptor-relative seams, distinguish directory-open refusal from link refusal.
   At W seams, use the actual allowed empty slot, not a forbidden sibling.
   Keep an actual internal-writable positive, correct one syscall at a time, and never
   send bytes through a successful forbidden link/move. Any such success stops new
   candidate work immediately with preserved evidence.
3. Implement WA-C02 against the actual launch gate and a newly registered synthetic
   helper. Retain ordinary positive, symlink negative and nonregular special-file
   negative, exact pre/post identities, no-follow access and zero target spawn.
   Do not alter any of the 327 source files or old active helpers. Do not open unsafe
   special content while deciding refusal. A bounded supervisor timeout is a limit,
   not refusal credit. Apply the narrowly authorized rejecting-only correction
   if needed; retain exact code and decision equivalence for admitted clean states.
4. Record limited same-policy runtime readiness and current source/admission evidence.
   No blanket rerun of every original control is needed simply for new probe registration.
   If a changed assumption affects a particular control, name it and rerun only the
   affected proof. Preserve the old measured results and the remaining limits.
5. Freeze the new probe registry/helper binding, then immediately begin C1A01–04 and
   remaining product work. No qualification-only return when these checks succeed.

Do not claim full qualification was completed before W's suites. The selected
prospective acceptance treatment permits exact W regression evidence plus these
same-boundary supplements, provided receiving inspection finds no unsafe historical
admitted layout or change to the successful execution path. This is evidence
completion, not retrospective process attestation. No repeat of the 4/99/60/9568
gates is default. Rerun a genuinely invalidated gate only after preserving the reason,
corrected runner identity and its affected assurance; never use selective green
tests to replace the required complete regression gate.

5.4 Candidate residual execution

Fixed interpreter entry:
 /Library/Frameworks/Python.framework/Versions/3.13/bin/python3
Expected Python3.13.4 / pytest8.4.1 / SQLite3.49.1. Rehash requested/resolved/native
runtime and the exact selected /usr/share/terminfo/64/dumb resource at named bindings.
Their retained host identities are not supplied executable payloads. No runtime
replacement or new terminal lookup permission.

Actual candidate launch, always admitted:
 /usr/bin/sandbox-exec -f <exact-QtcM> <fixed-python> -I -B <frozen-audit-probe-or-bootstrap> <mode>

Explicit owned cwd, umask077, core limit0, null stdin, close_fds=True, pass_fds=(),
credential-free environment allowlist, C locale/UTC, owned HOME/TMPDIR/basetemp/output,
PYTHONDONTWRITEBYTECODE=1, PYTHONNOUSERSITE=1,
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, PYTEST_ADDOPTS="", -p no:cacheprovider where pytest
is used. No ambient import roots. Bootstrap adds only authenticated candidate
root/src/tests as needed and frozen read-only probe/observer roots. Candidate
children retain their existing unmodified source-specified arguments and environment.

Ordinary audit-only fixture/parser/observer errors may be corrected in new versioned
files and fresh owned state. They are not candidate defects unless the actual owner
contract fails at a properly reached predicate. Retain the failure and correction;
do not weaken the expected result to get a pass. All product path faults must reach
the real owner/controller with counted injection and ordinary fault-removal positive.

Do not reproduce W's unnecessary qualification repetition for every probe revision.
An added immutable probe body, no change to admission/transfer/runtime semantics,
and an exact registered digest requires static inspection and actual current
admission/closure, not another full suite or all forty boundary controls. Bind each
probe's actual helper revision separately. The old v5 suites remain v5 runs.
No silently changing dispatch code after launch or retrospectively assigning the
final helper's bytes to an earlier digest.

Freeze complete expected identities and error/recovery/nonmovement predicates before
execution. Use exact built-in/type/graph/row relations; do not infer whole-family
failure from an unrelated first rejection. For a raw-SQL synthetic partial state,
record that it is an audit fixture and not a supported production transition. Keep
FKs/immutable guards active for the constraint being tested. Never use fake query
returns as physical occupancy or a product validator bypass to manufacture success.

Observe all phases, selected causal IDs, raw outcomes and warnings without selecting/
reordering/altering candidate results. Causal selections are labelled as causal,
not FULL. Standalone assertions emit exact independent expected/actual records.
Observer source and bootstrap/plan/gate/policy/fixture digests must bind every launch.

Capture all327 bytes/modes/extras before and after each candidate import/causal
execution group as required by the invocation, with exact source reconstruction.
Admission inventories supplement, never replace these captures. Existing W slots
may appear only for the previously inspected unchanged D1 test, not arbitrary
audit-source writing; both must be absent at every boundary capture.

Track actual owned children, groups, sessions and bounded waits. Emergency cleanup
touches only owned tracked subjects and never counts as candidate cleanup success.
Observe closure before publication; state initial-group/known-child limits without
a universal unknown-descendant claim. Do not continue after known source drift,
material candidate defect, unsafe dependency or invariant/containment violation.

5.5 Evidence publication, preservation and cleanup

Only newly and independently created protected records are written by the supervisor
during a workload, not protected alias installation or provisional-file promotion.
After observed closure:
- recheck full source, protected identities/link counts, root membership and mutable
  group closure; retain any failed postcheck without acceptance credit;
- read provisional data through no-follow ordinary-file descriptors bound by fstat
  around the bounded read; reject unsafe type, unstable identity, protected alias or
  unclassified symlink/special return;
- independently write exclusive no-follow protected destination bytes; never rename
  or hardlink mutable output into evidence; record different identities/nlink1 and
  equal bytes/hashes;
- retain true stdout/stderr, actual return codes, timeouts and every failed attempt.
No sanitized text is called raw evidence and no in-process output self-certifies
an adversarial result. No raw private templates/capsules, credential values,
unclassified databases/sidecars or executable outputs in delivery.

A new helper may retain records under the new protected namespace with fixed limits,
without scanning unrelated content. Existing historic source/evidence remains intact.
After current evidence protection remove only exact newly owned transient objects,
with recorded identities and classifications. Unknown old paths are not cleared to
satisfy admission. Recreated root fixture instances may be removed only after identity
and byte checks; record the return to ten old entries, not persistent readiness after
fixture removal. Future re-entry must establish new fixture identities again.

6. CUMULATIVE ADJUDICATION AND DELIVERY

Produce corrected A01–A18 and the exact stable56-row ledger, plus separate WA-C01/
WA-C02 assurance results. Each row distinguishes:
 carried independent execution on this exact source;
 carried static/data and writer evidence;
 new independent execution;
 precise supported invariant/inapplicability;
 genuinely unresolved mandatory predicate;
 historically unavailable evidence that cannot be retroactively reconstructed.
Do not assign every A row a blanket gap or repeatedly count the same test as new.
G01 compatibility is not the thirty substantive closures. Correct RV-01's accounting
without retroactively altering W/M/R/S/T reports or their policy scopes.

A completed predicate must point to actual source/helper identity, paired setup,
real reached check, exact result/nonmovement/disclosure record and its limitation.
A source invariant may delimit a truly impossible deeper specimen, not excuse
ordinary fixture difficulty or an untested reachable seam. No broad "all relations
proved" inference from one resealed row or a green FULL.

Primary verdict options remain:
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED
 AUDIT_PROVENANCE_MISMATCH
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE.

ACCEPT requires exact source and modes, compliant prospective effects and supported
composite admission/runtime/publication assurance under QtcM with its explicit
trusted-host assumptions; complete substantive A01–A18/F01/O1/S01/A03/two-layer proof;
and the supported independent complete regression records, carried or genuinely
rerun according to this mandate. No mandatory gap becomes nonblocking by wording.
Do not claim a new suite ran when using W. Do not call the old v5 launch interval
fully qualified retroactively. This is cumulative evidence adjudication under the
explicit repeat rule, not historical rewriting.

A material candidate failure stops with BLOCKED and no audit-side source repair.
An actually unmet runner/evidence predicate remains INCOMPLETE with its precise
ownership, evidence, constraint and minimum next action. No new broad platform or
semantic-contract tranche. Historical F03/F05, raw-index/ref/checkpoint/writer-observer
limits retain their original nonblocking or data-uncertainty scopes.

If a real practical limit prevents finishing, save the actual incomplete fixture,
last successful internal checkpoint and next named predicate, plus why execution
stopped. State which cases were attempted, not merely which remain. Do not produce
another full report saying thirty remain while executing only unrelated warm-ups.
No future/background-work promise or routine per-case approval request.

Write full report BEFORE sealing one safe evidence ZIP. Include:
 - exact W ZIP once (W already contains M/U/T/S/R), no duplicated A tree or ancestors;
 - source/input authentication and bounded manifests;
 - exact old/new gate and registration diffs, any rejecting-only correction;
 - narrow assurance-control raw records and actual source/policy/revision bindings;
 - corrected carry-forward map, all thirty residual rows, new probes/fixtures,
   expected predicates, raw invocations/outputs/exits/phase/warning records;
 - protected output-copy checks, source/inventory captures and exact cleanup;
 - all superseded attempts/process mistakes and their no-credit classifications.
No redundant standalone report attachment or outside copy equality gate next time.

Next outer package limits: <=2,000 regular members, <=64 MiB/member, <=256 MiB total
expansion. One exact49,940,248-byte W member is expected. Existing nested limits
remain as above; cache identities and expand only needed records. Retain complete
actual observations; do not create duplicate snapshots merely for a new filename.
Archive-level indexing to exact already included payloads is allowed; filesystem
hardlink materialization or invented repeated observations is not.

Reopen and verify every new archive member, complete self-excluding hash/size/CRC/
numeric-mode manifest and report equality. Return inline:
 primary verdict and exact source; newly CLOSED residual IDs; exact open IDs and
 actual stop reason; carried suite IDs/revision (and separately any new runs);
 targeted assurance results and limits; report/ZIP/manifest bytes and SHA-256;
 actual recipient and next action. Include an adjacent delivery receipt without
 making the ZIP contain its own final hash.

Only source tree 4691af58ae0ee3107b4e2e9b6b1508032944e357 is eligible for eventual
acceptance here. Return to ChatGPT. No live commit, staging, publication, deployment
or product effect follows. The implementation writer remains idle.
