## Engineering disposition

**The archive authenticates. The evidence supports one narrowly scoped signal-permission amendment to the audit runner—not a candidate repair. Recalibrate that amended runner, then continue directly into the cumulative audit in the same reviewer conversation.**

The candidate remains unchanged and unaccepted. The new permission is **selected for testing, not yet established as correctly enforced on this host**.

## Authenticated evidence

| Item | Verified result |
|---|---|
| Audit ZIP | **115,300 bytes** |
| SHA-256 | `b6de501b4a687bd3dc1f8800ac84d150b1197fea74682bd2953b8f9a20c887f9` |
| Inventory | **43 regular files; 42 verified manifest entries** |
| Expanded size | **443,517 bytes** |
| Embedded report | **23,692 bytes**, matching its reported identity |

Every covered member passed path, uniqueness, type, encryption, size, CRC, SHA-256, and numeric-mode checks. I also reauthenticated the separately supplied candidate and qualification archives, reconstructed the current **327-file tree**, and verified that the audit’s source-capture rows equal the candidate manifest:

```text
4691af58ae0ee3107b4e2e9b6b1508032944e357
```

The archived policy is byte-identical to the previously qualified policy. No live-checkout, index, or ref observation was made here. Coordinator_RW0_Audit_4DE1AE8E82_Receiving_Review\.md[Detailed receiving inspection](sandbox:/mnt/data/Coordinator_RW0_Audit_4DE1AE8E82_Receiving_Review.md)

## What the signal evidence actually proves

The final probe records:

| Target | While the child was awaiting normal completion | After recorded exit and reaping |
|---|---|---|
| Child PID | Signal 0 and `SIGTERM`: **`EPERM`** | Signal 0: **`ESRCH`** |
| Child’s process group | Signal 0 and `SIGTERM`: **`EPERM`** | Signal 0: **`ESRCH`** |

Its retained stdout reproduces the parsed result exactly; policy/helper hashes and the parent PID agree. Both children ultimately exited normally, with no recorded timeout. **No successful signal delivery occurred.**

The probe is narrower than the predicted suite failure:

- It did **not** attempt `SIGKILL`.
- It launched children through `Popen(start_new_session=True)`, not an explicit fork fixture.
- It used a 0.1-second sleep rather than a child-ready handshake, and did not retain each target’s PID/PGID/SID and handler-ready state.

These limitations do not erase the recorded denials. They mean the replacement permission needs stronger positive and exclusion controls than this compatibility probe supplies. Exact locations are `audit/scripts/signal_compat.py:27–47`, `audit/scripts/run_signal.py:26–48`, and `audit/evidence/signal_compat_result.json`. Coordinator_RW0_Audit_4DE1AE8E82_Receiving_Review\.md[Probe reconciliation and limits](sandbox:/mnt/data/Coordinator_RW0_Audit_4DE1AE8E82_Receiving_Review.md)

### The candidate dependency is real

The authenticated B3C2 test deliberately blocks a child that ignores `SIGTERM`. It requires termination and reaping **before** releasing the blocking pipe. Its helper escalates to `SIGKILL`. Separately, the D1 supervisor uses process-group signal 0, `SIGTERM`, and `SIGKILL` for deadline/cancellation and cleanup:

```text
tests/test_b3c2_transition_event_readers.py:501–519,605–641
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py:123–142,208–222,255–299
```

A runner that permits fork/exec but denies those operations cannot demonstrate the required behavior by substituting external-supervisor cleanup. The test itself was not launched, so its predicted failure remains a **source-supported inference**, not an observed candidate-test failure. Coordinator_RW0_Audit_4DE1AE8E82_Receiving_Review\.md[Authenticated dependency inspection](sandbox:/mnt/data/Coordinator_RW0_Audit_4DE1AE8E82_Receiving_Review.md)

## Selected runner amendment

Append exactly one line to the existing policy:

```scheme
(allow signal (target same-sandbox))
```

No existing byte, path, filesystem rule, network rule, IPC permission, runtime allowance, or process-information permission changes.

The proposed successor policy is fully identified:

```text
Bytes:
2,674

SHA-256:
0ff27cde4b1dfade46dc6ad0add110497d8633e509cd2c923107d5ddf8163961
```

**External corroboration, separate from local evidence:** OpenAI’s published Seatbelt base policy uses this exact target-restricted signal rule alongside fork/exec. That establishes a concrete policy approach—not the installed host’s behavior or the adequacy of our boundary. No other upstream permission is adopted. [raw.githubusercontent.com](https://raw.githubusercontent.com/openai/codex/main/codex-rs/sandboxing/src/seatbelt_base_policy.sbpl)

Two qualifications are explicit in the new mandate:

**This is not unrestricted signaling, but neither is it a signal-number allowlist.** The rule restricts targets; it does not permit *only* signal 0, `SIGTERM`, and `SIGKILL`.

**“Same sandbox” must not be assumed to mean “our intended workload.”** The new controls must establish the actual target boundary, including separately launched owned processes. A familiar rule name is not sufficient evidence of exclusion.

## Required controls—and what happens afterward

The continuation uses ready-handshaken synthetic targets with retained identities, group/session membership, handler state, actual syscall outcomes, delivery evidence, and wait statuses. It covers the required direct-child and process-group operations, ignored-TERM-to-KILL escalation, and descendant/session relationships.

It also tests live, disposable **nonmember** targets outside the workload, including a separately instantiated identical-profile cohort. If those targets are reachable contrary to the selected workload boundary, the audit stops. It may not silently redefine them as acceptable members or replace the rule with a broader grant.

After those controls pass, Codex must rerun the **complete original containment matrix under the new policy**, including filesystem, aliases, SQLite, parent/fork/exec behavior, and live-peer bind/connect denial. The old policy’s 40/40 results cannot supply execution credit for the changed policy.

**Successful recalibration leads directly to the substantive cumulative audit in that same assignment.** No further qualification-only handoff is required. The complete A01–A18, causal, SQL/admin, independent **60-case direct**, and **9,568-case selector-free FULL** obligations remain unchanged.

The previous report records zero candidate imports, SQL executions, causal scenarios, collections, or test runs. Those gaps remain open until actual independent execution completes. Pasted text

## Codex handoff

| Field | Instruction |
|---|---|
| **RECIPIENT** | The **same neutral independent reviewer conversation** that produced `audit-4de1ae8e82`. |
| **ATTACHMENTS** | **None required.** Exact retained paths and identities for the audit evidence, qualification, candidate, and requirements files are included. |
| **AUTHORIZED EFFECTS** | One exact runner-policy amendment, owned synthetic calibration, then conditional cumulative candidate audit. |
| **EXPECTED RETURN** | One cumulative audit disposition, full report, and reopened evidence ZIP—or a precisely scoped incomplete result if the new boundary fails. |
| **PROJECT SNAPSHOT** | None requested. |
| **NEXT ACTION** | Return the cumulative result here before any repair or commit gate. |

Send **only this complete replacement prompt**:

:chatgpt-content-reference{index="6"}[**RW0 normal terminal closure — scoped signaling and cumulative audit continuation**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Scoped_Signal_Cumulative_Audit_Continuation_Prompt.txt)

Do not resend the previous mandate as an operative instruction or attach this receiving review. The replacement contains the complete task; **its substantive review, causal-control, and validation sections are preserved byte-for-byte from the preceding mandate**. It changes the runner authorization and readiness procedure explicitly.

The prompt permits no second signal-policy variant, unrestricted signaling, candidate-test modification, skipped test, external cleanup substituted for candidate behavior, installation, host-protection change, or unconfined candidate execution. A missing retained input must be named—not searched for broadly.

:chatgpt-content-reference{index="7"}[Handoff identities](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Scoped_Signal_Audit_Handoff_Check.json)

## Limits

The fresh audit’s original 40-control readiness records reconcile, and its cleanup records identify 32 aliases and 32 synthetic targets removed. Those observations remain environment evidence, not candidate correctness. The new signal rule has **not** been executed here or qualified.

Keep the implementation conversation idle. Candidate tree `4691af58…` remains unaccepted; no source repair, staging, publication, or new Project snapshot is authorized.

**Inspection scope:** data-only archive verification, source-tree reconstruction, retained-record reconciliation, and static source/policy inspection. No supplied helper, policy, candidate code, SQL, test, Git command, or host probe was executed.

**Sources:** Coordinator_RW0_Audit_4DE1AE8E82_Receiving_Review\.md[Receiving inspection](sandbox:/mnt/data/Coordinator_RW0_Audit_4DE1AE8E82_Receiving_Review.md), RW0_Normal_Terminal_Audit_4DE1AE8E82_Report_From_Sealed_ZIP.md[exact embedded audit report](sandbox:/mnt/data/RW0_Normal_Terminal_Audit_4DE1AE8E82_Report_From_Sealed_ZIP.md), Coordinator_RW0_Audit_4DE1AE8E82_Receiving_Verification.json[verification record](sandbox:/mnt/data/Coordinator_RW0_Audit_4DE1AE8E82_Receiving_Verification.json), and the primary policy source cited above.

**Confidence:** artifact/source identity and record reconciliation **0.99**; source-supported runner correction **0.97**. Installed target-scope enforcement, candidate compatibility, and independent acceptance remain unestablished.
