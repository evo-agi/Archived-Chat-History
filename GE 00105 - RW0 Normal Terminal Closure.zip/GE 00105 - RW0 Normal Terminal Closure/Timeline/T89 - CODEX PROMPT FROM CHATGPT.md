RW0 NORMAL TERMINAL CLOSURE — INDEPENDENT RESIDUAL WORK WITH PRESERVED VALIDATION

This is the sole complete operative replacement mandate. Continue the SAME neutral
independent reviewer from RC, rc-382779f584. Candidate tree, policy, product contracts,
test assertions and acceptance requirements DO NOT change. Do not restart runner
design, regression qualification, source-history mapping or product implementation.

RC's C1A01–C1A03 closures are supported at the stated checked-P1 invariant plus
counted selected-lookup fault seam. Its WA-C01 and WA-C02 supplements are supported
at their finite prospective scopes. W's exact v5 representatives4/fixed99/direct60/
selector-free FULL9568 remain supported historical independent executions, NOT RC
runs and NOT retrospectively run under later gate revisions.

The work is to close the remaining 27 substantive IDs. Do NOT make C1A04's unfinished
two-subject fixture a serial prerequisite for the other26. Proceed with independent
SQL, graph/source, route/family and session/transaction groups while preserving that
fixture's specific limit. The new fixture direction below uses the existing checked
P1 owner for the unrelated acceptance, not a new multirun production API and not a
mandatory second execution of the one-shot D1/D2 wrapper.

Substantive sections 2–4 are preserved byte-for-byte. Their execution imperatives
are satisfied by exact mapped carried independent proof where it actually exists.
This is the same explicit no-automatic-repeat rule: do not rerun W's 4/99/60/9568,
C1A01–03, WA-C01/02, completed C4, or earlier calendar/constructor/connected work
merely because another engagement begins. Current-source/layout admission and
source-bound new residual execution remain mandatory. A concrete defect that
invalidates earlier evidence requires an explicit impact assessment, never silent
carry-forward. A green FULL never substitutes for an open causal predicate.

ENGAGEMENT ENVELOPE
CURRENT STATE: Exact candidate 4691af58ae0ee3107b4e2e9b6b1508032944e357 remains
uncommitted/unaccepted as the retained review subject. No live Git state is observed.
C1A01–03 and WA-C01/02 have scoped supported closure; 27 product residual IDs remain.
RECIPIENT: SAME neutral independent reviewer that produced rc-382779f584, expected
host cwd /private/tmp/rw0-audit-entry.daLWIE; NOT the implementation writer.
ATTACHMENTS: NONE required. Exact retained RC/A/B/C paths below; RC contains W once.
AUTHORIZED EFFECTS: Audit-owned fixture/observer/registration/ledger work, unchanged
candidate execution under admitted existing WA1+QtcM, protected audit evidence only.
No candidate, policy, successful-launch semantics, repository or publication change.
EXPECTED RETURN: One cumulative disposition with exact closed/open IDs, corrected
current-versus-historical ledger fields, source-bound proof and reopened evidence ZIP.
PROJECT SNAPSHOT: None requested. Integrated PR17 / 61d0330aba1160f7f5e7d9c541a325222d1c61e5
is retained baseline evidence, not a new current-ref observation.
NEXT ACTION: Return to ChatGPT before any candidate repair or live commit gate.
No routine handoff between successful internal checkpoints; implementation stays idle.

0. ENTRY AND EFFECT CEILING

Read this entire prompt. A necessary read of the exact host-exposed instruction
file solely to load it may precede the declaration, in the actual neutral cwd.
Before any OTHER operational command state actual host cwd, input bindings, exposed
project/repository binding or unknown binding, and effect ceiling. Requested cwd
is not proof. Missing/different cwd or exposed live checkout => stop without probing
that checkout. Unknown binding alone does not authorize discovery.

No Git/status/pwd/AGENTS/bootstrap discovery, repository or sibling access, home or
Downloads enumeration, app/session-store access, broad host/log/process search,
ambient environment dump, subagent, remote/provider/network/ES/Bridge contact,
installation, runtime substitution, mount/volume creation, privilege escalation,
host-protection or project-setting change. Read named inputs at their exact bindings,
never search their directories. Candidate guidance is read only from authenticated
A. Embedded old mandates are requirements evidence, not effect authorization.

The trusted supervisor prepares owned inert data, performs bounded WA1 checks and
captures protected evidence. It never imports candidate code, runs candidate SQL,
or invokes candidate fixtures outside QtcM. All candidate imports/collection/tests/
child callbacks/causal SQL remain in QtcM after actual WA1 admission. Keep the
implementation writer idle. No source/test/schema/doc change, staging, commit,
push, PR, merge, release, deployment, user/product DB, or executable authority.

No test edit, outcome substitution, filtering, skipped test, altered child argv/env,
pytest rootdir/config/ignore/plugin injection, hidden cache/validator bypass, or
external cleanup credited as candidate behavior. In-process observers are
instrumentation, not adversarial attestation authorities. Reports are evidence,
not Coordinator/Git/runtime truth.

QtcM stays EXACT: 4,086 bytes /
323ddc662ca3260365136573d08b25fe635ad448b84b4a673cf99533b0f89d0a.
There is NO permission budget, policy rebind, new W slot, network/signal expansion
or unconfined fallback. Its Qtc prefix remains 3,414 bytes /
8cdccd5fc9fd97ddc034d3d454d2d0b63d2342279fc10e3eecb078ba905aa109.

The selected trust model remains one trusted, serialized supervisor and no
malicious supervisor or hostile concurrent same-account/privileged host actor.
Census/postchecks do not prove continuous race-free custody. Do not manufacture
a global-process absence claim. M's actual preplaced-hardlink runtime failure
remains a failure; admission prevents contaminated preparation from proceeding.

1. EXACT INPUTS, RECEIVING FINDINGS AND RESIDUAL PLAN

1.1 Exact inputs and bounded authentication

RC — current scoped closures and partial coexistence fixture:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/rc-382779f584/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_rc-382779f584.zip
 57,287,175 bytes /
 b4ee6f3a1528f7826c7a92885e6d08c838dcbbdff5349e417305ac51ae37ad16
 159 regular members; 158 MANIFEST rows; 61,128,241 expanded bytes.
 REPORT.md: 14,074 bytes /
 dcf20746954ae7417156dfcbe40f6f3cf5474db82e70a89b1a936ed77c3b638e
 MANIFEST.json: 38,876 bytes /
 79429136cb552486f69a1c7c6e47fee90aec5b8d0feaa96b30eac17c6546d3e1
 Prefix RX = audit/execution/rc-382779f584/
 Prefix RE = audit/evidence/rc-382779f584/
 RC carries W ONCE at carry/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_wa-09da07307c.zip.

W:
 49,940,248 bytes / 718b49bc34d84cd6dc30bfe295970765d93e12238892c1c74145fe0fc76baf81
 817 regular members; 816 MANIFEST rows; 102,549,472 expanded bytes.
 WX = audit/execution/wa-09da07307c/
 WE = audit/evidence/wa-09da07307c/
 W contains M, then M contains U, then T, then S, then R, each exactly once:
 M: 6,677,682 / 10d793d8d18046d7afa5385aee832576e90e3378ccaff14b58f133b3fe31ad4f
 U: 6,221,246 / 888edd2777a8c47eb06c37b37a3ad09d1e0efc7188c17a9b9cfce3cdaff4aa37
 T: 5,878,210 / dc754506dff6d3cc9ab803814cb4137a2f4094a9ecc3f8c5bd3bd69d6952ee4a
 S: 2,947,049 / 3dda92c95c2ab99d477271a834d181df80fce270f23c38c87eb3e8299ced1ad7
 R: 1,650,029 / ffd593b643c1c6fc6c064a84d9b473ce4f34cc1b2f1be35706d0b2d08db4bd2f.
Use embedded exact copies. No duplicate outside-copy equality prerequisite.

A — unchanged candidate:
 /Users/ds/.codex/rw0-terminal-historical-witness-tcp5rwoh/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip
 48,978,087 bytes / 6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42
 573 members / 572 covered; 183,558,511 expanded bytes.
 package/member-manifest.json: 123,205 bytes /
 049139eaac16a03b36952faa703c992f5ef13adad44807873921af817e7b8e43.
 evidence/IMPLEMENTATION_REPORT.md: 19,549 bytes /
 c52141d0fcf15701496c4dec18133361a78b8f043796078340e24eed4bdae2d5.
 No separate report attachment/equality gate.

B — original implementation requirements, INERT:
 /Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt
 38,100 / 9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f
C — S01/A03 requirements, INERT:
 /Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt
 29,145 / 7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd
A inputs/mandate.txt:
 28,439 / 6e978d57abfbadf7d8120eb58ea75651a60a44c42d6279ff8a9108c41c8b2da4.
Read their requirements, not their old implementation/effect directions.

Authenticate normalized relative regular unencrypted archive members, bounds,
Unicode/casefold uniqueness, prefix safety and complete self-excluding mode/size/
hash/CRC coverage before use. RC/W <=2000 members, <=64MiB/member, <=256MiB expanded;
M/U/T/S <=500, <=32MiB/member, <=64MiB total; R <=500, <=2MiB/member, <=20MiB total.
A and necessary nested source history <=5000 members, <=150MB/member, <=350MB/archive,
depth6, <=1.2GB cumulative unique expansion. Cache identical verified inputs; do not
reconstruct every old source lineage again without a specific unproved dependency.
Some historical CRCs are hex text; compare numerical values, not mismatched encodings.

An actual host-exposed identical copy is an alternative binding, not permission for
namesake search. If a named input is missing, identify it. Do not invent paths or
search Downloads/home. Never run archived authentication/packaging/cleanup programs
blindly. New audit helpers are inspected/derived source under this mandate.

All327 current source payloads must authenticate to:
 tree 4691af58ae0ee3107b4e2e9b6b1508032944e357
 final-C/final-D/postcleanup manifest, 109,923 bytes /
 1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1.
326 OS0644, one OS0600 tests/test_c2b3_private_atomic_program_initialization.py;
all Git100644. SQL0008 remains 30,178 bytes /
a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254.
Rebuild from bytes without Git. No 0009, changed test, source mode, or product API.

1.2 Supported current evidence and preserved regression

Receiving inspection is DATA/STATIC review, not another host execution:
- RC/W/M/U/T/S/R/A authenticate. Every A source payload/mode reconstructs the tree.
- RC opening plus six pre/post group captures each contain all five copies, all327
  rows equal to A. These35 recorded copy inventories are not continuous custody.
- Ten successful launches reconcile: six clean marker controls, one four-role
  runtime matrix, two selected-acceptance versions, one partial C1A04 fixture.
  All have exact helper/plan/policy/runtime pre/post bindings, exit0, empty stderr,
  no timeout/emergency, observed child closure and initial-group emptiness.
- Full inventories independently support single-link protected files, no protected/
  writable inode overlap, closed mutable groups, absent W slots and unchanged
  previously observed protected rows. Runtime hashes remain retained observations.
- WA-C01: actual parent/fork/exec/fork_exec records support20 ordinary link denials,
  20 rename denials to ACTUAL allowed destinations,12 descriptor-relative link
  denials after successful prerequisite opens, and8 internal-writable positives.
  Descendant PIDs and wait records agree; no generic host isolation claim follows.
- WA-C02: active registered synthetic symlink and FIFO each refuse in the real gate
  BEFORE active content binding or target spawn, exit2, no timeout. Clean paired
  positives pass after exact original helper identity/bytes are restored.
- The gate delta is independently replayed: namespace/registration bindings plus
  guarding BOTH active-content verification calls when metadata reasons already
  require refusal. It changes rejecting behavior only. No new admitting branch.
- A wrong-relative-plan clean invocation refused before target spawn and receives
  no clean-positive credit. A separate correctly invoked positive passed.
- The v1 selected-fact output mislabeled a late snapshot; v2 is the credited timing.
  Do not rerun v1 or silently relabel its JSON.

RC latest registered gate:
 RX/wa1_gate_rc_probe_v3.py SHA-256
 740a75ac5f1427c6ad0c76bef31b52a59edc58565b1da3d65e22eaa8f3743082
 RX/revision_probe_v3.json SHA-256
 6f2bdef7faf7f51f16158df63474e32dd803e1a165966efb8d4838493d1bbde0
The base RC gate (before registration-only probe revisions):
 RX/wa1_gate_rc.py SHA-256
 4a7346b92fbccbd0ccb58c1ebbdd8b2425605cd0e6df2343c2d30b616b1cf9b9.

W suite revision:
 WX/revision_v5_frozen.json SHA-256
 97e63c9e0f439c6d123a710814b5d429183111f57076c442d0d85f1bc0aefac5.
Carry EXACT W v5 runs, not a new RC run:
 representatives4 /12 passed phases /0 warnings;
 fixed99 /297 phases /0 warnings, ordered compact-JSON digest
 f242e64dd779abab8a7ff39c64a69e852524b51b85ee1d61b3f0228b0a178224;
 direct60 /180 phases /0 warnings, ordered digest
 229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467;
 FULL9568 /28704 phases /3 permitted B2c warnings, ordered digest
 25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9.
All six principal W processes (including separate direct/FULL collections) exit0.
The full execution is selector-free, final suites have no child tracer, and explicit
JUnit IDs, all phases, source preservation and output-copy identities reconcile.
No repeated suite run is needed for registration-only changes and current admission.
M's preplaced-hardlink runtime failure and T's Qs failed FULL remain historical.

Carry S replan2, source3, time/admin and normalized C4; R connected/disclosure/fault
proof; T's valid SQL/route/current-owner results at their EXACT previously reviewed
predicate scopes. C4 remains7 blocks/28910 events/28388 normalized SQL classifications.
Do not replace these with broader later wrapper labels or reset every A row to a gap.
RC carry_forward_map.json supplies exact earlier members and limits; use raw records
when a particular closure needs confirmation, not generic report totals.

1.3 C1A01–03 closure and minor current-ledger repair

Credit RX/selected_acceptance_rc_v2.py, 9275 bytes /
3003c18f31e72ea31b911d48ea242295d6c7e70fb41811c182c5ac3f85ea9470,
and RE/records/C1A01_C1A03_selected_v2_rc.*.

Five actual selected-lookup faults each call the real checked SELECT first, then
substitute missing, wrong reference, foreign lineage, resealed digest, or other
existing decision parent. Exactly one hit each; outward database_integrity_failure;
acceptance plus all four terminal-table snapshots unchanged; terminal rows0; FK check0.
The physical guarded DELETE refuses immutable_rw0_c2_bootstrap_acceptance_facts.
After fault removal, accept/read/replay are equal and recovery is committed_exact.

Source implication:
 _rw0_c2_progression_plan.py:437–470,544–558 includes selected acceptance before receipt;
 _sqlite_rw0_c2_progression.py:298–316,399–468 reconstructs and compares every row;
 _sqlite_rw0_terminal_outcome.py:144–207 checks P1 BEFORE selected lookup;
 _rw0_terminal_outcome_plan.py:148–162 checks selected ref/digest/decision/lineage/scope;
 0007_rw0_c2_progression_decision.sql:152–185,218–222 supplies FK/uniqueness/immutability.
Under the selected single transaction/trusted-host conditions a durable malformed
selected fact cannot survive the checked-P1 prerequisite. Inconsistent subsequent
lookup results refuse at the terminal boundary. C1A01–03 are closed on that exact
invariant plus reachable fault evidence, NOT on a claimed physically persisted
malformed family or an injected fault executed in every historical operation.
Do not reopen these rows solely because the faults were returns rather than SQL rows.

RC's56-row ledger preserves IDs/history, but C1A01–04 retain
current_named_predicate_attempted=false alongside RC_new_attempted=true. Correct
the next CURRENT field/meaning, preserving RC unchanged. Distinguish:
  fixture attempted; exact coexistence predicate reached; predicate closed.
C1A04's fixture was attempted but full coexistence not reached. This is ledger
normalization, not a new test or reason for reopening C1A01–03.

1.4 C1A04 construction decision — no new production multirun path

RC RX/same_store_second_p0_rc.py:31–62 only records P0 B and then first-subject
terminal accept/read. Its actual counts are P0 act/fact/receipt1→2, acceptance1,
terminal receipt0→1, FK check0. It NEVER attempts a second P1 command. Thus no
second-P1 rejection or product-level impossibility is observed.

The unchanged prepared_normal_case at
 tests/test_sqlite_rw0_terminal_connected.py:213–256
uses a one-shot D2 wrapper that owns a new store and unqualified single-head reads.
That convenience fixture is not the owning store's multifact contract.

SELECTED AUDIT FIXTURE DIRECTION (proposed, not executed here):
Keep the SELECTED terminal subject's full checked P0/D1/D2/Section41/C1/V22/P1
chain. For the UNRELATED acceptance fact use the existing private P1 owner and
ALL prerequisites actually required by it in the SAME managed store. Do not
add a second full D2 workflow as an extra requirement solely because RC named it.

Grounding:
 .docs/rw0-c2-physical-p0-p1-implementation.md:179–221,223–250;
 _sqlite_rw0_c2_progression.py:167–237,675–758;
 tests/test_sqlite_rw0_c2_progression.py:45–130,156–179;
 tests/test_c2b3d_private_atomic_author_effect_establishment.py:75–226;
 sqlite_writer_session.py:5676–5685,5815–5845.
The existing standalone P1 test builds a checked acceptance via initialization,
author-effect establishment, P0 and typed artificial P1 evidence without running
the terminal-connected D2 wrapper. This supports the fixture approach, NOT an
already executed second-fact coexistence proof or a production multirun feature.

Build an audit-owned fixture function accepting the EXISTING location:
a. Leave the selected graph/command intact. Derive a distinct second subject from
   typed factories and owner-canonical values, with disjoint lineage, scope, P0 act/
   admission, program/work/version/intent/attempt/fence/candidate, basis, mutation,
   decision and derived sibling identities where the actual owners require them.
   Recompute dependent digests bottom-up; never blind text-replace sealed blobs.
b. Reuse existing private initialization and author-effect commands with that
   distinct subject, using real guarded writer/controller operations on the existing
   store. Do not call initialize_database on it again, transplant an independent DB,
   inject handback success, or monkeypatch an owner/checker to approve a fake graph.
c. Record/recheck the distinct P0 subject. Construct coherent typed basis-v2,
   dispositions and artificial current guard evidence bound to this subject using
   the actual supported P1 grammar. Preserve actual currentness, unclaimed-scope,
   continuity, sole-active and all FK/immutable guards. An artificial evidence value
   is labelled artificial; it is not a claim of real external authority.
d. Call real _record_progression_decision, then its checked read/replay/recovery.
   Require candidate_acceptance, matching complete family and committed_exact.
   Use explicit subject-keyed source queries, not old table-wide fetchone/count1
   assumptions. Do NOT edit the original test helpers; derive a new audit fixture.
e. Verify both required facts actually coexist when testing a selected ACCEPT
   subject, their separate complete parent families validate, and neither is
   mutated/replenished by terminal record/read/replay/recovery. The selected terminal
   must bind only its correct immutable fact; primary protected rows stay exact.
   To close A07's "another allowed terminal branch" noninterference, retain evidence
   for a coherent nonaccept selected subject with an unrelated checked acceptance
   present if that distinction is not already supplied. A nonaccept selected subject
   must not acquire an acceptance fact. Do not turn this into all outcome cross-products.

No raw acceptance-row insert or checked-owner substitution is a positive proof.
No production schema/API/multirun implementation, patch to candidate tests, disabled
constraint or invented owner semantics is authorized. If real owner prerequisites
block a construction, capture the exact command/state/error and owning source,
rather than inferring impossibility from the one-shot D2 wrapper. If independently
inspected contracts require additional predecessors, construct them legitimately;
do not discard a genuine requirement based on this fixture-direction note.

1.5 Remaining27 IDs and dependency-aware execution order

Stable56-row inventory remains SHA-256
 fffc8d2f50046c1fa8df3b0f1d63c1c16348e2f628d5c07dd3d6c6d0b4bbcd56.
Only these27 current mandatory residuals are open:
 C1A04
 C1B03 C1B04 C1B05
 C2A04 C2A05 C2A06 C2A07 C2A08 C2A09 C2A10 C2A11 C2A12 C2A13 C2A14 C2A15 C2A16 C2A17
 C2A19 C2A20 C2B11 C2B12 C2B13
 C3A02 C3A03 C3A04 C3A05.

Their definitions remain RC's frozen rows. Preserve all earlier56 IDs and historical
scopes, plus separate WA-C01/02 assurance records. No new generic matrix or automatic
Cartesian expansion.

PROSPECTIVE WORK-ORDER AMENDMENT ONLY:
After current admission/readiness and ledger correction, execute independent groups
without waiting for C1A04. Prefer the following order, with internal saved/reopened
checkpoints and immediate per-predicate evidence:
 1. C3A02–05: remaining actual context/outcome/result/receipt FK/unique/composite/
    nullable-pair/profile/blob constraints. Valid parents, fresh unoccupied targets,
    real enabled guards/FKs, paired valid insertion rolled back to the same starting
    state, exact intended SQLite constraint, nonmovement. Preserve T's isolated
    receipt-result FK and S calendar/admin proof; do not repeat them by default.
 2. C2A04–17: map all later route predicates to actual short-circuit order
    _sqlite_rw0_terminal_outcome.py:262–284. Physical first-match where representable;
    otherwise precise implication naming state class, FK/owner equality and earlier
    route. State separately valid complete, partial, damaged and foreign families.
    Complete-family overlap alone does not settle other classes. No fake query
    occupancy, disabled guards, forced digest collisions, or invented impossibility.
 3. C1B03–05 and C2A19–20: actual graph role/cardinality/order/self-digest exclusions,
    repeated-column/alias disagreement, remaining source associations beyond S source3;
    damaged self-digest family refuses exact/winner and remains unresolved; foreign
    complete winner and original-absence classification without disclosure/retry.
    Independently reseal the intended fault and show its first true rejecting seam.
 4. C2B11–13: remaining stale in-memory lease versus durable issuance/closed session,
    receipt-last/second-readback rollback, recovery cleanup uncertainty and no
    automatic retry. Count actual injected calls; use fault-removal positives and
    exact outward errors/recovery/nonmovement. Carry earlier closed/stale/cleanup2.
 5. Complete C1A04 using section1.4. Preparing this fixture earlier is allowed, but
    it must NOT prevent progress on independent ready rows. Retain its intermediate
    construction and actual failed predicate, then continue other groups when safe.

No subagents or concurrent processes outside the owned validation design. These are
independent WORK GROUPS, not authorization for parallel unsafe writers. Routine
fixture/parser mistakes may be corrected in new audit-owned versions without
another user relay. Save successes before expanding fixtures.

The first substantive new checkpoint must concern a genuinely OPEN predicate,
not an already closed constructor/calendar/normal-branch or C1A01–03 warm-up.
A practical limit may produce an honest partial result, but it must name the actual
resource/constraint and which independent cases were attempted or unattempted.
One incomplete coexistence fixture alone is not a global stop condition. A real
candidate defect, source drift, unsafe runtime, failed admission or authority
conflict still stops affected execution with correct classification.

2. SUBSTANTIVE REVIEW — THE EXPLICIT TWO-LAYER AMENDMENT

The earlier whole-operation zero-current-stop-SELECT criterion failed under the
old mandate. That blocked result remains true. The engineering decision is to
preserve mandatory shared storage safety, not to skip it to satisfy a terminal
history test. The current candidate is judged against the following amendment:

Layer 1: existing operational admission remains mandatory. Session/process/thread/
lease validity, database binding/custody, BEGIN IMMEDIATE, exact managed schema,
history/catalog/posture and invariants, writer ownership/fencing, and current
protected disclosure remain intact. The existing global_stop_current singleton
shape validator may read that current row only for managed-store validity.
Valid active/clear status, version, timestamp and directive identifiers must not
be compared with saved terminal stop or turned into current effect permission.
Denied/unreadable/malformed managed state may prevent disclosure or leave recovery
unresolved. It must not be misclassified as stale terminal history or definitely
absent original execution. No cache, successful-assessment stub, invariant-skip
flag, alternate connection/controller, or production validator weakening.

Layer 2: historical checked read, receipt-present replay and recovery use saved
full postimages/stop and checked immutable predecessors after admission/fencing.
The five current-head tables are not consulted during the historical operation.
Current-stop reads are permitted only at the existing shared invariant check,
not as a general table-read exemption or later semantic terminal query. Receipt
is first TERMINAL-FAMILY lookup, not first SQL statement. Exact original result,
time, graph, receipt, source associations, protected disclosure, immutable
acceptance binding, complete competing-winner/absence proof and uncertainty
classifications remain required. Historical operations do not require recording
permission or renewed acceptance-unclaimed eligibility. Fresh receipt-miss
recording retains actual current five-head/stop checks unchanged.

This amends only the overbroad current-stop-query requirement. It is not a waiver
of the constructor defect, five-head independence, disclosure, SQL grammar,
transaction safety, audit isolation, or other cumulative acceptance controls.
Verify the two owning documents state the distinction and preserve the old
failure as history; do not create another silent interpretation of either layer.

Inspect at minimum the complete changed witness module, changed tests and docs,
full terminal contracts/rows/plan/SQLite owner, and actual shared admission call
chain (not only wrapper names). Current anchors:
  sqlite_transition_transaction.py:2759–2779,4753–4773
  sqlite_migration.py:2477–2523
  .docs/rw0-terminal-outcome-physical-closure.md:177–220
  .docs/sqlite-operations-and-recovery.md:722–730.
Python basenames are under source/src/ge_nwp_coordinator/; docs under source/.

2.1 Independently test the repaired constructor and mutable aliasing

TerminalHeadWitness at _rw0_terminal_head_witness.py:48–96 must validate ordinary
construction, not only checked factories. Independently test valid direct/factory
triples for accept and replan and all five typed owner roles (8/9/41/9/8 fields,
valid nulls, self-digests). Exact bytes, outer tuples, dictionaries, keys and
scalar types precede hostile comparison/coercion. Bytes, full rows and compact
coordinates must match rather than silently replacing invalid supplied parts.

Require negative controls for the previous malformed type triple and b'{}'/empty
postimages, bytes/list/tuple/dict/string/int subclasses, bool-as-int, wrong arity,
missing/extra/reordered roles or fields, wrong schema/digest, noncanonical and
oversize bytes, and valid canonical bytes paired with DIFFERENT valid rows or
projections. Calibrate a shared/per-instance hostile equality counter, clear it,
and verify zero hostile calls per invalid construction. Preserve built-in
positives and process-control propagation.

Mutate caller-owned maps and separately returned maps, then re-read both views
and canonical bytes and run normal downstream verification. They must remain
checked and unchanged. No unvalidated object token/factory escape or recursion.
Do not demand security against arbitrary reflection/object.__setattr__; that is
not the selected boundary. Verify unchanged wire fields/schema/digest domains
and valid consumer behavior, including exact original P1 replan operands.

2.2 Independently prove complete-operation phase behavior

Use real private WriterSession read, receipt-present record/replay and recovery,
not just a terminal helper. Trace and attach observation/denial at the actual
acquisition/controller opener aliases and account for every operation connection.
The candidate observer labels the full managed wrapper; independently establish
which SQL is genuinely in _verify_global_stop_current_shape. A phase label alone
does not prove shape-only use or permit arbitrary managed-phase stop semantics.

Observe real unchanged validator, ownership-read and issuance/fencing functions;
observation wrappers must call the real function and return its actual result.
Do not replace admission with a successful assessment or patch the predicate
being proved. Capture connection, phase, table/column and allow/deny results.
Calibrate each attached authorizer with owned allowed and intentionally denied
queries. Trace acquisition separately, including any connection work before the
observer attachment, and prove it cannot hide a five-head/later-stop lookup.
A zero-callback claim at the wrong alias is invalid. Column callback counts are
not SQL-statement counts or a fixed product invariant.

Required current-byte controls:
- real fenced accept and replan commits, then coherent later movement of every
  head and valid active/clear stop fixtures; under the layered denial policy,
  exact read/replay/recovery preserve original result/time/witness/graph/receipt
  and acceptance facts without new terminal or protected-row movement;
- original absence with positive/negative old-execution exclusion; complete
  compatible and incompatible competing winners under that same policy;
- deny the ACTUAL managed-stop read during admission: safe operational refusal
  before protected terminal-family handling, recovery unresolved where the
  unchanged controller so classifies; no no-write mislabel as stale history,
  definite absence, hidden retry, committed result or protected disclosure;
- malformed actual stop row or real query-return tuple, with validators intact:
  integrity failure rather than ordinary currentness; fault removal restores
  valid operation; bound process-control behavior remains unchanged;
- fresh receipt miss reads all five actual heads and stop. Stale expectations
  conflict without writes; correctly expected valid changed stop follows the
  current normal-record rule without conferring executable permission;
- denied/expired/foreign/malformed disclosure, closed/stale/fenced session and
  unavailable managed store remain non-disclosing. Fresh recording permission
  stays separate from historical protected disclosure and stop shape.

All synthetic later states/fault seams must be described as such. Do not call
a direct fixture UPDATE a newly supported product operator transition.

3. COMPLETE CUMULATIVE A01–A18 REGISTER AND CAUSAL OBLIGATIONS

Review the entire baseline-to-current terminal change, not only the five-file
repair. Supply exact archive-relative source/doc/test/SQL coordinates, severity,
and evidence class for every row: contract/current code, inspected test design,
retained record, independent execution, inference or limit. Unchanged bytes and
prior passes do not automatically discharge current mandatory controls.

A01 Authority: exactly five private normal terminal facts, separate from P1
 decision/acceptance, standing-policy grants, source facts and executable
 permission. No cancel closure, live supplier/contact, ES/Bridge/Git effect,
 service/scheduler/autonomy or publication authority.
A02 Preservation: legacy terminal V1/four validators, P0/P1 meaning, WorkSpec,
 Decision Basis/command-digest v2, preassignments, D1/D2, generic receipt, public
 StateStore/package exports unchanged. Audit original shared catalog/controller/
 writer-session terminal integration even though this immediate repair froze it.
A03 Grammar/types: closed command/context/outcome/row/result/recovery/witness
 schemas, exact built-ins before equality, canonical UTF-8/JSON and duplicate
 rejection, bool-as-int, safe refs/digests/calendar time, budgets and null pairs.
 Include direct constructors, factory consistency and aliasing; resolve A03/O1.
A04 Identity graph: independent domains/acyclic preimages, four sibling refs and
 route, optional assertions bound in command digest but not preassignments,
 graph role/cardinality/order, self-digest exclusion and repeated-column equality.
A05 Original operands: original P1 command and private replan operand transient;
 complete checked predecessor association required. Missing/inconsistent private
 content cannot be reconstructed from a safe digest or yield false certainty.
A06 Source association: actual checked P0/phase/Section41 A/C1 rank15/V22/P1
 chain and validation/review/proposal/result-set/observation relationships;
 membership counts or digest strings do not independently establish ownership.
A07 Acceptance: bind existing immutable acceptance only for accept; never create,
 mutate or replenish it. Wrong/missing/foreign facts reject. Legitimate unrelated
 facts must coexist without preventing another allowed terminal branch. No
 historical acceptance-unclaimed recheck.
A08 Heads/stop: observed full five-row witness, source/adapters/digests/links,
 replan historical P1 postimages, fresh actual currentness and stop facts; prove
 the precise two-layer amendment, not the withdrawn zero-stop-read property.
A09 Transaction: existing fenced lease/capability/controller; receipt-first
 terminal lookup; one captured time; protected posture/source/current/route
 ordering; context/outcome/result readback, receipt last, capability invalidation,
 one commit attempt, rollback/cleanup uncertainty. No application-head/stop/
 decision/effect update by terminal closure.
A10 Read/replay: original complete result/time/graph/receipt and source/witness
 reauthentication; current protected disclosure with mandatory store admission;
 no five-current-head or later semantic stop query, cognition/process rerun,
 fresh recording permission or acceptance-eligibility requirement.
A11 Recovery: complete exact original family or exhaustive original absence and
 exclusion, or complete compatible winner, only. Partial/foreign/damaged/aliased/
 incompatible families unresolved. No winner result disclosure, hidden retry,
 fragment repair or durable private-template fallback.
A12 Error/cleanup: failed or malformed reads stay operational/integrity, valid
 actual drift stays currentness. Stale/closed/fenced sessions, pre/postcommit,
 applied-commit/lost-return and cleanup uncertainty, KeyboardInterrupt/SystemExit/
 GeneratorExit propagation at the actual fresh/read/recovery/cleanup seams.
A13 Schema/admin: four STRICT immutable normal-only tables/eight guards;
 timestamp grammar, FK/unique/composite links/phase/decision/route occupancy,
 nullable pairs, blob bounds, zero seeds, current catalog/checksum/generation 2;
 exact fresh/prefix migration and old-binary/obsolete-0008/partial/unknown refusal.
A14 Connected normals: actual preseal source variations through real P0/D1/D2/
 Section41/C1/V22/P1/terminal owners; five distinct normal positives and detached
 negative; read/replay/recovery and no forbidden contact or protected-row change.
A15 Docs/assurance: cumulative current-versus-historical status, explicit amendment
 and private scope; fixed source/hash/AST/import/schema consumers and predecessor
 reconstruction retained; no dynamic oracle, skip/xfail or broad guard stripping.
A16 Privacy/artifacts: complete postimages remain safe owner metadata; no private
 replan text, raw capsule/prompts/process results, handles/PIDs/credentials in
 terminal rows or unsafe errors. Grammar review plus independently observed
 canaries; classify raw-index metadata, checkpoints and failed artifacts.
A17 Retained evidence: exact input/source/patch/commands/env/observer outputs/
 JUnit/IDs/warnings/captures and overlapping counts; limits in section 4 below.
 No writer record or causal-register label is independent execution.
A18 Independent validation: reached current-source causal probes and direct
 suite, independent SQL/admin controls, selector-free collection/FULL completed
 with exact IDs, outcomes, warnings and source-mode preservation. No live-state
 or production-readiness inference.

The following controls remain mandatory, including previously unfinished ones:

(a) S01 full-witness family: for EACH role, check complete field capture, valid
 nullable values, supported maximum witness bound, bad owner self-digest, valid
 self-digest with wrong immutable predecessor, wrong owner/link, and actual fresh
 head movement versus changed caller expectations. Use fully resealed synthetic
 histories so owner/context/outcome/result/graph/receipt digests are internally
 valid and the real relationship predicate is reached. Pair every resealer with
 a valid family built the same way. Restore ordinary verification for the actual
 read/replay/recovery. Prior program-only evidence is not five-role proof.
 No truncated witness, v1 fallback, desired-row synthesis or current-row backfill.

(b) Source/operand/acceptance: fully resealed detached validation, review,
 source-invocation and proposal associations, including a DISTINCT forged V22
 proposal reference rather than only a proposal digest; wrong/missing/foreign
 acceptance; LEGITIMATE unrelated acceptance-fact coexistence; inconsistent
 private replan content sharing a claimed safe identity across record/read/
 replay/recovery; no new process or private-text persistence. The single-chain
 fixture's inability to construct an unrelated fact is not proof of impossibility.
 Build coherent independent synthetic state through checked owners, or document
 exact invariant proof and the remaining limitation. Do not credit an incoherent
 split-reader or early FK/digest failure as the intended relationship test.

(c) Disclosure/recording: all selected finite posture predicates, including
 positive, denied, expired, malformed, foreign-bound and absent protected subject;
 old-execution-excluded True/False; truthful claimed False/None after accepted
 P1. Fresh write needs recording AND disclosure, historical operations disclosure
 only; command reuse/assertion mismatch cannot disclose a protected result.
 Complete the expired/malformed/foreign/protected-absence matrix rather than
 inheriting earlier positive/negative permission examples.

(d) Physical routes: derive all original occupancy routes from the checked
 code (the preceding audit identified 17). Seed EACH route physically in a
 separate owned coherent scenario, with valid positives and relevant partial,
 foreign or damaged family states. Mocking query return values alone is not
 physical occupancy evidence. Check exact/winner/absence classifications and
 no winner disclosure or retry. If a route is not representable under an owner
 invariant, prove that with exact schema/contract and record the scope; do not
 invent an invalid row as a legitimate winner or silently drop the obligation.

(e) Transaction and error matrix: faults after each of the four inserts,
 result/receipt readback, receipt-last boundaries, precommit rejection,
 one applied commit with lost return, postcommit and recovery cleanup uncertainty;
 stale lease/issuance, closed and fenced sessions; actual denied SELECT versus
 malformed selected rows across current owners; all three process-control
 exceptions at meaningful fresh/read/recovery/cleanup seams. Assert target
 rows, committed bytes, protected-state nonmovement, and actual injection hits.
 No hidden second commit or automatic retry.

(f) F01/O1 regression: independently exercise raw SQL and row construction,
 not only planner success. Use otherwise valid parent/related state, paired
 valid inserts, independent negative self-digests and the repaired existing
 _time owner. Cover invalid month/day/leap-century/year-zero/time overflow,
 canonical-format deviations, Unicode digits, embedded NUL/whitespace/nontext,
 NULL handling and valid year endpoints. Reach all three recorded_at columns;
 outcome has no timestamp. Verify failed predicates are zero/not permissive
 NULL and high-level invalid row/time behavior stays integrity/unresolved.
 Reproduce the old invalid-month predicate only in owned predecessor synthetic
 state as a grammar comparison, never claim an ordinary writer exploit.
 Recalibrate O1 independently before claiming no hostile equality calls.

(g) Five connected normals plus three unsupported cancel shapes and unsupported
 profile. Source variations occur BEFORE real artificial worker/checker/capsule
 sealing, not by relabelling passed evidence afterward. Use inspected fixtures
 for setup only; independent expected branches/facts/errors are required.
 Observe artificial local process/contact limits and privacy canaries.

Run bounded causal controls before a long FULL launch. Do not start/continue
FULL while a known material blocker already prevents acceptance. Independent
controls must state setup validity, actual reached seam, expected result/no-write
predicate, source identity and limits. Candidate tests passing are not separate
independent oracles. Any mandatory control not established remains explicit and
prevents complete acceptance unless an exact supported invariant makes the case
inapplicable; fixture difficulty alone is not such an invariant.

Independent SQL/admin expectations:
  after 0006: 68 tables / 122 triggers / 5 explicit indexes
  after 0007: 74 / 134 / 5
  after 0008: 78 / 142 / 5, application generation 2.
Execute all eight authenticated literals in disposable owned state. Preserve
pre-0008 object SQL/shape; check exact prefix upgrades, no seeds, immutable
update/delete guards, FK/unique/pair/profile/normal/blob/time constraints, and
refusal of old binary, original and S01-era 0008 checksums, old SQL with current
history, missing guard, foreign object and partial/unknown/checksum divergence.
No current schema/contract change, 0009 or product database upgrade is allowed.

4. RETAINED EVIDENCE AND INDEPENDENT VALIDATION

4.1 Reconcile the current writer records as DATA

Paths: evidence/validation/<direct|connected|focused|full>/, gate-summary.json,
phase-read-map.json, supersession-record.json and current source captures.
Require independent parsing of collection observer, execution collection,
setup/call/teardown records, explicit JUnit nodeid properties, actual launch/exit,
stdout/stderr as actually retained, warnings, and four complete source captures
per gate. Do not invent a separate stderr file for a combined log.

Expected current retained gates:
  direct: five complete modules / 60 cases / zero warnings
  connected: one complete module / six cases / zero warnings, inside direct
  focused: 126 complete modules / 8,266 cases / three known warnings
  FULL: selector-free / 9,568 cases / three known warnings.
All narrower sets must be included in FULL; totals overlap and do not add.

Ordered-ID SHA-256 uses UTF-8 JSON array, ensure_ascii=False,
separators=(',', ':'), with NO trailing LF:
 direct 229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467
 connected 81e14e3fa1b85a7be2ea6fafac85974839145bbcb6397e6da0bb1feeba060aac
 focused 419d37ff399689788123583f614a1d8b107ef712e2368ca179cd6e65fbec5104
 FULL 25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9.

All sixteen source captures have the same 105,550-byte envelope, SHA-256
0c0b4017371a798731a63825ac63922c361189e37f5a713f5c4f7ec06e9b32cb.
Require full row equality to the different canonical source-manifest envelope,
its embedded canonical hash, correct final tree and no extra/missing paths.

The retained direct JUnit phase maps report six operation connections, 60
managed-stop column callbacks and six intentional head-denial calibrations
for EACH accept/replan scenario. Independently parse the raw properties. Do not
substitute those counts for actual phase/call-chain verification, or label them
SQL-statement counts. Acquisition has separate test observations.

4.2 Known retained-evidence limits — do not silently fill them

The active external gate_observer source and a launch-bound helper digest are
not retained in the current outer ZIP. Old nested helpers cannot prove that
current code's identity. Writer records can be internally reconciled but their
observer's nonselecting implementation is not thereby inspected. The independent
runs below must use newly audit-authored, retained, inspected and calibrated
observers. Independent fresh evidence can establish current behavior; it does
not retroactively establish the missing writer helper.

The seven-case checkpoint has receipt/JUnit evidence and a different declared
tree 85c9fea24f4f74f358f9cc59a5d323d836a04041; it lacks a complete checkpoint
source payload here. Its historical save/reopen/source-binding claim stays
qualified and supplies no final-byte credit. Similarly, one retained patch
manifest per kind is not proof of two writer runs; independently reconstruct
current endpoint/patch identity rather than invent that history.

These are disclosed retained-evidence/process limits, not automatic production
findings. Determine their actual acceptance impact. Complete current independent
source/runtime evidence must not be replaced with writer claims. Any unmet
mandatory evidence requirement is INCOMPLETE, not a pass by wording change.
Preserve failed/superseded source/test results separately. The prior audit's
live-status/path probes and interrupted FULL remain historical limits.

4.3 Required independent execution gates

Under the explicit prospective section 1.3 scheduling amendment: after current
source inspection/reauthentication, exact final QtcM readiness and observer calibration,
and with no known material candidate defect or unsafe dependency, execute these
complete regression gates BEFORE additional residual custom-fixture work.
All outstanding causal/admin obligations remain required for final ACCEPT:

1. On a fresh exact source copy, collect and run these five COMPLETE modules in
   this order (no node selector):
   tests/test_rw0_terminal_outcome_values.py
   tests/test_rw0_terminal_head_witness_regression.py
   tests/test_sqlite_rw0_terminal_controls.py
   tests/test_sqlite_rw0_terminal_migration_0008.py
   tests/test_sqlite_rw0_terminal_connected.py
   Expected 60 ordered unique passes, including six connected cases.
2. On another fresh exact 327-file copy, independently collect and run the
   repository selector-free FULL. Expected 9,568 ordered unique IDs and passes
   in the retained FULL order. No path, module, node, -k or -m selection.
3. Record collection/execution-collected/call/JUnit identities, explicit JUnit
   nodeid properties from the start, all setup/call/teardown results, warnings
   and real process exits. Require exact ordered agreement and zero failure,
   error, skip, xfail/xpass or failed noncall phase. An invertible JUnit mapping
   is useful supplementary evidence, not a silent substitute for the required
   explicit-property observation.
4. Independently inventory warnings. Direct has none; FULL may have only the
   three known DeprecationWarning multithreaded-fork nodes in
   tests/test_sqlite_b2c_writer_session.py:
   test_operation_guard_close_waits_and_retains_authority_until_exit
   test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
   test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock.
   Owned paths/PIDs may differ; other class/node/message differences require
   investigation, not filtering or suppression.
5. Capture complete raw bytes/modes/extra-file inventory immediately before and
   after collection AND before and after execution, with source-tree rebuilds.
   All 327 endpoints and modes must remain unchanged. At every boundary capture there must be no generated extras; only the prospective, exact-path transient fixture exception in section 5 is allowed during the inspected D1 test.
6. Audit probes remain outside candidate discovery and separately counted. An
   independent focused 8,266-case rerun is unnecessary if exact FULL inclusion
   is proven; do not claim one ran. No writer FULL or earlier audit count can
   replace the independent completed FULL.

Use recorded equivalents of:
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --collect-only --basetemp=<owned-collect> <complete-direct-modules>
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --basetemp=<owned-run> --junitxml=<owned-junit> <same-direct-modules>
For FULL remove all module/path/node selectors from BOTH commands. Inspect
pytest config, conftest and setup/child-launch seams before import. The observer
may record IDs/outcomes/warnings and add JUnit nodeid properties, but must not
select, reorder, skip, change assertions/results or suppress warnings. Keep its
exact source/digest in the evidence and bind every launch to it.

Do not edit candidate source/tests to get green results. Correct audit-only
parser/fixture/observer mistakes transparently on fresh owned state, retaining
failed attempts. A genuine candidate failure triggers findings, not retries with
weakened oracles. An interrupted FULL gets no complete-pass credit; preserve
actual partial records and absence of final JUnit/observer rather than infer
completion from displayed percentages.

5. PRESERVED RUNNER, CURRENT ADMISSION AND RESIDUAL EXECUTION

No missing general qualification tranche remains. This section preserves the actual
admission/effect boundary; it does not order repetition of supported W/RC controls.
WA-C01 and WA-C02 carry forward at their exact measured scope. Registration-only
new fixtures need current authentication/admission and limited readiness, not the
whole old suite or all previous synthetic controls.

5.1 Layout, preserved files, and fixture lifecycle

ROOT is exactly:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz
Existing source copies:
 ROOT/mock_source/tc-4fd7e168a0/{master,causal,direct,smoke,full}
Existing immutable policy:
 ROOT/execution/md-812d7d86be/QtcM.sb
Source/test W exceptions, and NO other source write slots:
 ROOT/mock_source/tc-4fd7e168a0/smoke/src/ge_nwp_coordinator/_rw0_d1_probe_temp.py
 ROOT/mock_source/tc-4fd7e168a0/full/src/ge_nwp_coordinator/_rw0_d1_probe_temp.py

Choose one fresh unique rs-<nonce> suffix under ROOT's existing execution/scratch/
home/tmp/evidence/denied and, for noncandidate calibration sentinels only,
mock_source. Preserve every W helper/revision/report/source copy; do not overwrite
a historical path, link-copy, rename old output into the new protected namespace,
or clear an unexplained object. New probes remain outside candidate test discovery.

Reuse the five active source copies only after full current-byte/mode/extras and WA1
checks. A present mismatch is a binding stop, not authorization to repair or reset.
If a required copy is absent, independently recreate from authenticated A into the
same previously permitted slot, exclusive/no-follow with the recorded modes and no
hardlinks; record that as new copy custody, not historical preservation. New
provisional DB/process/output state is always in freshly owned writable locations.

RC cleanup removed only its approved prospective calibration fixtures. The exact two already
authorized immediate-root metadata fixtures may be recreated after lstat proves
absence and the ten preserved root members authenticate:
 ROOT/rw0_meta_plain_md812d7d86be.txt
 ROOT/rw0_meta_dir_md812d7d86be/inside.txt
Use exclusive independently created safe non-code regular bytes, owner-private modes,
new dev/ino/nlink/hash records, and no source/test/config names. No new immediate root
entry. Record the new twelve-entry census and freeze its identities in the NEW
runner binding; never overwrite W's original root-preparation record or claim
the old fixture inodes were restored. Unknown present fixture/type stops.
QtcM's bytes and exact permissions remain unchanged.

5.2 Enforced WA1 invariant; no relaxation of trusted preparation

Before EACH actual launch, inventory the entire artificial owned root, not only the
new namespace. The writable footprint is ALL scratch/home/tmp, including old
reachable namespaces, plus the two exact W slots. Protected audit regular files
are all remaining source/helper/evidence/denied/root files.

Require:
- ordinary owned protected regular files, nlink1 and distinct nonzero dev/ino;
- no protected identity reachable through the writable footprint;
- closed regular-file hardlink groups within that entire writable footprint, with
  path count equal to nlink and an explicit audit origin for preexisting files;
- immutable current source/helper/policy/runtime bindings and expected root membership;
- no source/evidence/protected descriptors inherited by the workload;
- the sole trusted supervisor introduces no protected-to-writable alias and no
  concurrent protected preparation mutation while a workload runs.

A protected nlink>1 cannot be excused because its other path is not found in the
new suffix. Reject; no host-wide alias search. Same-byte distinct files must admit.
Directories are not subject to the regular-file nlink1 rule. Known internal writable
hardlink/symlink fixtures created by unchanged tests are not product defects, but
must be classified and group-closed after child closure. Unknown preexisting
writable aliases/data cannot be admitted solely because their UID matches.

Authorized supervisor census is bounded no-follow metadata only inside ROOT's
seven existing subtrees and immediate regular files/two W slots: <=100,000 entries,
depth<=64, no mount crossing or directory-symlink traversal. Fresh descriptor-relative
stat/readlink/identity checks, with active-path ancestry bound to ordinary directories,
not cached path strings. No recursive content reads or scans outside ROOT.
Protected content reads remain limited to named inputs, active source/helpers/
policy, selected carried evidence and synthetic targets.

Existing guard code and policy are trusted only after source inspection and current
identity checks. Use one actual launch_if_admitted path. Known contaminated layouts
must emit refusal before target spawn/candidate import. Do not call an isolated
checker while leaving a bypass route to actual sandbox-exec.

The root expectation and new probe registry are new bindings, not new accepting
semantics. Namespace/registry-only revisions must retain a complete exact diff
against RC's inspected probe_v3 gate algorithm, frozen helper maps, source/expected-root
identities and runtime. No code import from a mutable helper path. Do not overwrite
the v5 revision to pretend it included later probes.

RC's rejecting-only early metadata refusal is already implemented and supported.
Preserve it; no new algorithm correction is requested or authorized by default.
Changes may register immutable new probe/helper/fixture identities and the owned
namespace only, preserving clean admission, rejection, copying and closure logic.
A newly established substantive gate defect requires explicit impact assessment
and a precise stop, not silent weakening or a new runner platform.

5.3 Current readiness and repeat decision

Inspect the RC gate/revision/source before deriving a new audit-owned registration.
Retain exact diff, old/new helper bytes, namespace and source/root fixture identities.
Use RC's corrected rejecting path without adding an accepting branch or changing QtcM.

Before new candidate work:
1. Authenticate RC/A and required carried evidence; verify the actual complete owned
   layout, source copies, empty W slots and recreated permitted root fixtures.
2. Freeze the new immutable probe registration and full active binding. Run one small
   clean marker/SQLite readiness through the actual admitted launch path if current
   layout/revision needs it. Distinguish readiness from candidate proof.
3. Use targeted controls only for a specifically changed execution assumption. Do not
   automatically repeat the four-role matrix, hardlink suite, active-helper negatives,
   representatives/fixed99 or direct/FULL. Every candidate launch still performs
   mandatory WA1 and source before/after/closure checks.
4. Correct ledger attempted-versus-reached fields and begin the genuinely open groups
   in section1.5. No qualification-only closeout after readiness succeeds.

W's regression remains source/revision-bound history. RC supplements establish the
later finite assurance scopes; they never become events in W's earlier interval.
If the accepting path, candidate bytes, policy or runtime truly changes, or evidence
shows a historical admission/preservation flaw, explicitly identify the invalidated
results and required revalidation. Preserve the original record. Registration-only
changes or a new synthetic probe name do not automatically invalidate old suites.

5.4 Candidate residual execution

Fixed interpreter entry:
 /Library/Frameworks/Python.framework/Versions/3.13/bin/python3
Expected Python3.13.4 / pytest8.4.1 / SQLite3.49.1. Rehash requested/resolved/native
runtime and the exact selected /usr/share/terminfo/64/dumb resource at named bindings.
Their retained host identities are not supplied executable payloads. No runtime
replacement or new terminal lookup permission.

Actual candidate launch, always admitted:
 /usr/bin/sandbox-exec -f <exact-QtcM> <fixed-python> -I -B <frozen-audit-probe-or-bootstrap> <mode>

Explicit owned cwd, umask077, core limit0, null stdin, close_fds=True, pass_fds=(),
credential-free environment allowlist, C locale/UTC, owned HOME/TMPDIR/basetemp/output,
PYTHONDONTWRITEBYTECODE=1, PYTHONNOUSERSITE=1,
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, PYTEST_ADDOPTS="", -p no:cacheprovider where pytest
is used. No ambient import roots. Bootstrap adds only authenticated candidate
root/src/tests as needed and frozen read-only probe/observer roots. Candidate
children retain their existing unmodified source-specified arguments and environment.

Ordinary audit-only fixture/parser/observer errors may be corrected in new versioned
files and fresh owned state. They are not candidate defects unless the actual owner
contract fails at a properly reached predicate. Retain the failure and correction;
do not weaken the expected result to get a pass. All product path faults must reach
the real owner/controller with counted injection and ordinary fault-removal positive.

Do not reproduce W's unnecessary qualification repetition for every probe revision.
An added immutable probe body, no change to admission/transfer/runtime semantics,
and an exact registered digest requires static inspection and actual current
admission/closure, not another full suite or all forty boundary controls. Bind each
probe's actual helper revision separately. The old v5 suites remain v5 runs.
No silently changing dispatch code after launch or retrospectively assigning the
final helper's bytes to an earlier digest.

Freeze complete expected identities and error/recovery/nonmovement predicates before
execution. Use exact built-in/type/graph/row relations; do not infer whole-family
failure from an unrelated first rejection. For a raw-SQL synthetic partial state,
record that it is an audit fixture and not a supported production transition. Keep
FKs/immutable guards active for the constraint being tested. Never use fake query
returns as physical occupancy or a product validator bypass to manufacture success.

Observe all phases, selected causal IDs, raw outcomes and warnings without selecting/
reordering/altering candidate results. Causal selections are labelled as causal,
not FULL. Standalone assertions emit exact independent expected/actual records.
Observer source and bootstrap/plan/gate/policy/fixture digests must bind every launch.

Capture all327 bytes/modes/extras before and after each candidate import/causal
execution group as required by the invocation, with exact source reconstruction.
Admission inventories supplement, never replace these captures. Existing W slots
may appear only for the previously inspected unchanged D1 test, not arbitrary
audit-source writing; both must be absent at every boundary capture.

Track actual owned children, groups, sessions and bounded waits. Emergency cleanup
touches only owned tracked subjects and never counts as candidate cleanup success.
Observe closure before publication; state initial-group/known-child limits without
a universal unknown-descendant claim. Do not continue after known source drift,
material candidate defect, unsafe dependency or invariant/containment violation.

5.5 Evidence publication, preservation and cleanup

Only newly and independently created protected records are written by the supervisor
during a workload, not protected alias installation or provisional-file promotion.
After observed closure:
- recheck full source, protected identities/link counts, root membership and mutable
  group closure; retain any failed postcheck without acceptance credit;
- read provisional data through no-follow ordinary-file descriptors bound by fstat
  around the bounded read; reject unsafe type, unstable identity, protected alias or
  unclassified symlink/special return;
- independently write exclusive no-follow protected destination bytes; never rename
  or hardlink mutable output into evidence; record different identities/nlink1 and
  equal bytes/hashes;
- retain true stdout/stderr, actual return codes, timeouts and every failed attempt.
No sanitized text is called raw evidence and no in-process output self-certifies
an adversarial result. No raw private templates/capsules, credential values,
unclassified databases/sidecars or executable outputs in delivery.

A new helper may retain records under the new protected namespace with fixed limits,
without scanning unrelated content. Existing historic source/evidence remains intact.
After current evidence protection remove only exact newly owned transient objects,
with recorded identities and classifications. Unknown old paths are not cleared to
satisfy admission. Recreated root fixture instances may be removed only after identity
and byte checks; record the return to ten old entries, not persistent readiness after
fixture removal. Future re-entry must establish new fixture identities again.
6. CUMULATIVE ADJUDICATION, DELIVERY AND STOP CONDITIONS

The only candidate is 4691af58ae0ee3107b4e2e9b6b1508032944e357. RC supports three new
selected-acceptance closures and two prospective assurance supplements, not candidate
acceptance. Preserve M's hardlink failure, T's failed Qs FULL, W's green v5 suites,
and all prior truthful partial/blocked records at their original scopes.

Produce a corrected current A01–A18 register and stable56-row residual ledger:
 carried independent execution; carried static/data/writer evidence; new independent
 execution; precise owner/FK implication; actual mandatory gap; historically missing
 evidence that cannot be recreated. Correct stale current attempt booleans without
 rewriting old RC. The 27 IDs remain mandatory until their actual predicates close.
No automatic requirement expansion, blanket missing-proof prose, or contraction
of predicates to fit available fixtures.

Every closure maps source/helper/policy/revision identity, independent expectation,
valid paired setup, actual reached check, raw result, nonmovement/disclosure and limit.
An exact owner invariant can delimit an unreachable specimen; ordinary fixture
difficulty and unexecuted plans cannot. Fault-injected rows are not durable facts.
An unrelated checked P1 acceptance fixture is not a second D2 process run; state its
construction and actual owner checks explicitly. Root causes and limits remain honest.

Primary verdicts:
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED
 AUDIT_PROVENANCE_MISMATCH
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE

ACCEPT requires exact327 source/modes, compliant effects, supported composite
WA1+QtcM admission/runtime/publication with the same declared trusted-host limits,
all substantive A01–A18/F01/O1/S01/A03/two-layer predicates, and the preserved
supported complete regression evidence or genuinely required replacement execution.
A material candidate failure is BLOCKED with no audit-side source repair.
A runner/binding/authority failure is INCOMPLETE with its exact cause and impact.
No source acceptance, staging, commit or publication authority follows from partial
progress or from this prompt. F03/F05 and historical provenance limits stay scoped.

If a genuine practical limit prevents finishing, preserve each completed row, the
actual partial fixture/code/state description, failed source-bound attempts, last
successful checkpoint, concrete reason and independent work still possible. Do not
say merely "27 remain" or stop all work because the one-shot D2 wrapper is unsuitable.
Do not promise future/background work; perform the current engagement's safe work.

Write a unique full report BEFORE sealing ONE evidence ZIP. Include:
 - exact RC once (RC already carries W/M/U/T/S/R), not A or duplicate ancestors;
 - current source/input authentication, policy/admission/helper registration bindings;
 - corrected cumulative carry map, all56 current rows and exact27 residual treatment;
 - new probe source, expectations, raw launch/results, real calls/hit counts, source
   and protected/mutable identity captures, safe output-copy and closure evidence;
 - actual failures, superseded helpers, process corrections and their credit limits;
 - source-preserving cleanup, non-effects and next continuation only if needed.
Retain independent evidence; do not embed private templates/capsules/credentials,
unclassified database/bytecode/special-state payloads or mutable executable output.
No generic new evidence framework or duplicated full snapshots solely for names.

Outer next package bounds: <=2000 regular files, <=64MiB/member, <=256MiB expanded.
The exact57,287,175-byte RC is the expected one large carried member. Preserve nested
bounds and cache verified identities. Index already included immutable payloads
instead of duplicating them; no filesystem-hardlink deduplication or invented repeated
observations. Full self-excluding path/size/hash/CRC/numeric-mode manifest, safe
normalized unique members, report embedded byte-identical. Reopen every member.
Adjacent delivery receipt gives actual report/ZIP/manifest identities; no requirement
that the ZIP contain its own hash or that a standalone report be attached next time.

Return inline: verdict and exact subject; newly closed IDs and exact open IDs;
what actually ran versus preserved W suites; any new material finding; actual
stopping cause and independent work status; report/ZIP/manifest bytes+SHA256; next
recipient ChatGPT. No per-case approval request, new Project snapshot, source edit,
Git command, staging, commit, push, PR, merge, deployment or publication.
