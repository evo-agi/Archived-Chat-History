ENGAGEMENT ENVELOPE

CURRENT STATE: Normal-terminal tree 5c44721183f660032b6468d2c1f5a1d0dc3e6acb
is uncommitted and unaccepted. The latest cumulative audit is BLOCKED. F01 and
O1 have reported bounded independent passes; whole-operation historical access
and direct TerminalHeadWitness construction require the treatment below.
RECIPIENT: The SAME write-enabled normal-terminal implementation Codex
conversation. One parent writer; no subagents. This is not an audit retry.
ATTACHMENTS: Exactly one original audit-evidence ZIP, identified below. The
implementation conversation already retains the source package. No separate
standalone report, Downloads search, or historical-package reconstruction.
AUTHORIZED EFFECTS: One private witness-value repair, bounded contract and
assurance updates, isolated synthetic tests, and external review artifacts.
No staging, commit, push, PR, merge, publication, deployment, or product effect.
EXPECTED RETURN: One cumulative uncommitted candidate, report and sealed ZIP.
PROJECT SNAPSHOT: None requested. PR #17 remains the integrated baseline.
NEXT ACTION: Return the result to ChatGPT, then obtain a fresh independent
cumulative precommit audit. No acceptance is issued by this engagement.

1. OBJECTIVE AND EXPLICIT ARCHITECTURAL DECISION

Resolve two different matters together without weakening shared storage safety.

A. HISTORICAL ADMISSION: retain the existing common managed-state validation,
writer fencing and error behavior unchanged. Explicitly replace the former
whole-operation prohibition on SELECTing global_stop_current with the two-layer
contract in section 3. This is an engineering amendment of the earlier audit
requirement, NOT proof that the old requirement passed and NOT a retrospective
change to any BLOCKED verdict. No shared-preflight bypass is authorized.

B. WITNESS CONSTRUCTION: make direct TerminalHeadWitness construction enforce
the same closed, exact-type, canonical, owner-digest and projection consistency
contract as its checked factories. Preserve its wire format and valid values.

The original implementation and repair requirements remain in force except
for the precisely identified historical SELECT obligation replaced here.
Do not reopen the five-normal-outcome program, cancellation scope, authority
split, original private P1 operand dependency, migration shape, or F01 repair.
Do not start another standalone design/reconnaissance tranche.

2. EXACT INPUTS AND OPENING AUTHENTICATION

Repository:
/Users/ds/Repositories/Governed Execution Coordinator/

Require before edits:
- branch: codex/rw0-normal-terminal-closure-v1
- HEAD: 61d0330aba1160f7f5e7d9c541a325222d1c61e5
- committed tree: 44c7dee402d46b3e16dc389ae0824b4297dfec1f
- upstream: absent
- semantic index: 315 stage-zero entries equal to HEAD, no staged/unmerged entries
- working source: 327 regular paths
- working tree: 5c44721183f660032b6468d2c1f5a1d0dc3e6acb
- final source-manifest SHA-256:
  d0b74c46d2aad8cb1ba9d151770146e09150038b46c895f47608cbe074c8bae6
- cumulative delta: 67 modified, 12 added, no deleted or mode-changed paths
- classified test tests/test_c2b3_private_atomic_program_initialization.py:
  OS 0600 / Git 100644; the other 326 source paths OS 0644 / Git 100644.

Retained source input:
/Users/ds/.codex/rw0-terminal-f01-repair-i9qu11j7/
RW0_NORMAL_TERMINAL_CLOSURE_F01_TIMESTAMP_REPAIR_UNCOMMITTED_REVIEW.zip
- bytes: 36,160,973
- SHA-256: ca1a42d3165809887b4d837232cf9a45ff18e1c643921c5eef7b0a42d2737844
- 855 members; package/member-manifest.json covers the other 854
- member-manifest SHA-256:
  dd5d2dfcdcd56970a7cc6a7064634dd642bf1f25d8017ab2697014c1c9c9692a
- evidence/IMPLEMENTATION_REPORT.md: 17,269 bytes; SHA-256:
  77a4cfa1c6fbdfb7da986d751dad7ce69a3b4e28d5fa169bfd476d23fecf82ec
- identity/final-manifest-A.json, final-manifest-B.json and
  postcleanup-manifest.json are byte-identical, 109,923 bytes each.

Use the exact retained path above or its actual previously exposed attachment;
if unavailable, stop for that exact input. Do not substitute a namesake or
search the user's home, Downloads, or unrelated temporary roots.

New attached evidence input:
RW0_NORMAL_TERMINAL_F01_CUMULATIVE_AUDIT_BLOCKED_EVIDENCE.zip
- bytes: 1,370,071
- SHA-256: 16b4098f63cbb1fe68d4e7079711565624fe1412aaf28af70413f4d5f8518970
- expected 160 regular members; member-manifest.json covers 159
- manifest bytes: 26,844; SHA-256:
  ec2122008323981f7cedd9ff4d48e36101d7f487eadaf3942df29746559f4127
- embedded AUDIT_REPORT.md: 32,236 bytes; SHA-256:
  67f2a2ae24e2871e2befe2e4fc35b753d7bebcbc3bcba7444a7b3a92ae21430a.

Authenticate outer inputs, safe central directories, bounded expansion,
self-excluding manifests, embedded reports, source endpoints/modes and tree.
Read the full audit report, root/s01_a03/AUDIT_FINDINGS.md, its original probe
sources/results, and the relevant admission/isolation notes as inert evidence.
Do not execute archived audit or implementation helpers as a shortcut. Write
new tests/controls in owned synthetic state using inspected setup fixtures.

Read this mandate completely before repository operations. Read AGENTS.md and
the relevant owners before authoring. Preserve a raw index copy and metadata
outside the repo before ordinary Git reads. Use GIT_OPTIONAL_LOCKS=0,
GIT_NO_REPLACE_OBJECTS=1 and deterministic locale. Reuse the retained source
identity recipe after inspecting it, without silently changing serialization.
Compare source, semantic index, branch, HEAD, config and authoritative refs
separately from volatile metadata. An unexplained raw-index-only transition
with exact semantic HEAD index must be disclosed and prospectively anchored;
it is not permission to reset the index or infer continuous past preservation.

Use the existing qualified diagnostic-ref distinction: only direct refs under
refs/codex/turn-diffs/captures/ and refs/codex/turn-diffs/checkpoints/ may be
classified diagnostic after checking commit/tree targets and no input-selection
role. Record complete maps/deltas; surviving names must not retarget. Do not
freeze a volatile full-ref aggregate as candidate source identity. Any actual
source, semantic index, configuration or authoritative-ref ambiguity blocks.
No checkout, reset, restore, clean, rebase, fetch, or ref repair is authorized.

3. HISTORICAL CONTRACT RECONCILIATION — FROZEN DECISION

Source-backed conflict:
- sqlite_transition_transaction.py:2759-2770 runs binding/managed-state
  validation before issuing the fenced capability, for terminal operations too.
- sqlite_migration.py:790-803,2106-2128,2477-2523 validates current schema and
  managed invariants, including the global_stop_current singleton and its shape.
- .docs/sqlite-schema-v1.md:343-353 requires that invariant, while permitting
  valid active and clear states rather than forcing bootstrap state.
- .docs/writer-session-authority.md:489-527 requires managed validation before
  fencing and domain/idempotency disclosure.
- _sqlite_rw0_terminal_outcome.py:318-356 reconstructs terminal history using
  saved rows and immutable predecessors; that is a different phase.

The earlier F01 cumulative audit mandate's section 2.3 and A08/A10 wording
required transitive whole-operation zero current-head/stop SELECTs. The latest
audit correctly found that this property fails. Preserve that historical result.
This mandate selects semantic historical independence SUBJECT TO existing
managed-store admission and protected-disclosure prerequisites, not access to
history despite an unreadable or invalid managed store.

The current owning contract and tests must express BOTH layers:

Layer 1 — existing operational admission, unchanged in production:
- session/process/thread/lease validity, database identity and custody,
  BEGIN IMMEDIATE, exact schema/history/catalog/posture, managed invariant
  validation, writer-ownership read and fencing remain mandatory;
- existing _verify_global_stop_current_shape may SELECT the current singleton
  only to establish its managed-state shape. This is NOT comparison with the
  saved terminal stop, current effect permission, or a fresh terminal decision;
- valid later active/clear state, version, timestamp and directive identifiers
  must not change the historical committed result once admission and current
  protected-disclosure posture succeed;
- denied/unreadable/malformed managed state can still prevent access. Preserve
  existing operational versus integrity failure and recovery-unresolved behavior.
  Do not call an admission failure stale terminal history or definite absence;
- no cached/fabricated successful assessment, flag to skip an invariant,
  alternative connection/controller, or weakened validator is permitted.

Layer 2 — terminal historical verification, unchanged semantics:
- once a proper fenced capability is issued, historical checked read, exact
  receipt-present replay and recovery use stored full postimages and checked
  immutable predecessor families, not today's five heads or current stop;
- the five current-head tables must not be consulted anywhere in the historical
  operation, and current-stop access is allowed only in the existing common
  managed-state invariant phase. No broad table-read exemption or later
  semantic stop query is allowed;
- original command association, complete source/graph/witness compatibility,
  protected disclosure, original timestamp/result, acceptance nonmutation,
  complete winner/absence proof and uncertainty classification remain required;
- fresh receipt-miss recording still reads actual five heads/stop and performs
  its currentness checks; this amendment does not relax that path;
- fresh disclosure permission remains separate from current stop-row shape.

Update the terminal owner with this distinction, including that receipt-first
means first TERMINAL-FAMILY lookup after common admission/fencing, not first
SQL operation. Add a narrow corroborating section in the SQLite operations
owner. Preserve historical source packages; do not label the former broad claim
as if it had passed. This is an explicit assurance/property change, not a
production availability improvement or retroactive process exception.

4. DIRECT WITNESS VALUE — SELECTED IMPLEMENTATION

The current frozen dataclass at _rw0_terminal_head_witness.py:44-49 has no
validating constructor. The audit's malformed direct objects therefore exist
even though witness_from_bytes and witness_from_typed reject equivalent bad
inputs. This is a private value-contract defect, not a demonstrated production
persistence or authority bypass.

Keep TerminalHeadWitness as the exact private class and preserve normal
constructor use with canonical_bytes, postimages and coordinates. All successful
construction paths must satisfy one no-I/O validation relation:
- canonical_bytes is exact built-in bytes and obeys the existing size, UTF-8,
  duplicate-key, closed-shape, schema, role-order, JSON-type and canonical rules;
- postimages and coordinates are exact tuples with exactly five exact builtin
  dict mappings, with exact builtin keys/scalars before equality/membership;
- the 8/9/41/9/8 owner inventories, null semantics, self-digests and owner
  adapters remain the semantic authorities;
- supplied postimages equal the independently decoded and owner-checked full
  rows, and supplied coordinates equal their checked compact projections;
- unequal, reordered, missing/extra, subclassed, malformed or inconsistent
  representations reject rather than normalize or silently replace bad inputs.

Use nonrecursive component validation shared by constructor and factories. Do
not implement __post_init__ by calling a factory that recursively constructs
another TerminalHeadWitness. Do not use an unvalidated construction token or
object.__new__ factory shortcut to leave ordinary direct construction unchecked.

Canonical immutable bytes are the value's internal source of truth. Preserve
canonical_bytes/postimages/coordinates access, but derive projection mappings
as detached builtin values from that checked representation (or from immutable
checked internal scalars). Caller input dictionaries or returned projection
dictionaries must not be live mutable aliases to supposedly checked internal
state. Preserve valid factory and direct-construction equality/behavior and
existing typed consumers; no new wire field, schema version, digest domain,
durable row, public export, or dependency is required. Reflection such as
object.__setattr__ is not an authenticity boundary and must not be advertised
as defeated; ordinary construction and mapping aliasing are the tested scope.

Exact builtin validation must precede hostile equality, iteration/coercion
where relevant, and comparisons with allowed strings. Reuse existing owner
validators; do not rederive permissive alternatives. Preserve ValueError-style
private input rejection, process-control exception propagation, privacy-safe
messages, and no raw witness/private text in logs or exception payloads.

5. FILE CEILING AND REQUIRED SOURCE READING

Read the named source before changing it and inspect relevant tests/configs:
- AGENTS.md and terminal owner;
- .docs/sqlite-schema-v1.md integrity section;
- .docs/sqlite-bootstrap-and-migrations.md managed-state definition;
- .docs/writer-session-authority.md lifecycle/admission/fencing sections;
- .docs/sqlite-operations-and-recovery.md;
- _rw0_terminal_head_witness.py, _rw0_terminal_outcome_rows.py,
  _rw0_terminal_outcome_plan.py, _sqlite_rw0_terminal_outcome.py;
- the controller, writer-session and migration paths cited above;
- existing owner row adapters and terminal witness regression fixtures;
- test_b3c1b_rollback_only_writer_fencing.py managed-validation controls and
  the current migration-framework invariant/recovery tests;
- all direct path/hash/AST/shape/status consumers and validation configuration.
Python production basenames resolve under src/ge_nwp_coordinator/.

Only production file authorized to change:
  src/ge_nwp_coordinator/_rw0_terminal_head_witness.py

Required document updates:
  .docs/rw0-terminal-outcome-physical-closure.md
  .docs/sqlite-operations-and-recovery.md
Other existing current owner passages may receive only necessary bounded
clarifications of this exact contract where a source-grounded scan proves a
contradictory current claim. Preserve historical blocks, marker bodies and
predecessor reconstruction; do not undertake a general status rewrite.

Tests: existing terminal value, witness regression and terminal controls
modules; existing direct assurance consumers proven by the dependency scan.
No new repository path, deletion, rename or mode change is authorized. Add
bounded controls within existing test modules. Do not relax a shared validator
or replace exact historical guards with broad normalization/dynamic oracles.

Freeze byte-for-byte from the authenticated opening candidate:
- all SQL 0001–0008 and schema fixture; application generation and catalog;
- sqlite_migration.py, sqlite_transition_transaction.py, sqlite_writer_session.py;
- terminal contracts, row adapter, plan and SQLite owner;
- P0/P1/Section41/C1/D1/D2/WorkSpec owners, legacy terminal V1, package/public API;
- F01 total timestamp predicates/_time calls and calibrated O1 counter.
In particular 0008 remains 30,178 bytes, SHA-256:
  a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254.
No 0009, context/witness version bump or terminal-record backfill is selected.

If this selected local repair genuinely requires another production file or a
schema/authority change, stop with its exact dependency before widening scope.
Do not reopen the whole architecture or amend shared safety just to pass a test.

6. CAUSAL CONTROLS AND FIRST SUBSTANTIVE CHECKPOINT

A. Constructor/factory equivalence:
- direct valid triples for all five roles, including replan/null-valued fields;
- the audit's malformed type triple, b'{}'/empty collections and bytes subclass;
- tuple/list/dict/string/bytes subclasses, hostile equality values, bad arities,
  missing/extra keys, role reordering, bool-as-int, wrong schema/self-digest;
- valid canonical bytes paired with different valid postimages or coordinates;
- malformed/noncanonical/oversize bytes independently of projection mismatch;
- shared-counter calibration proves hostile equality would be observed, then
  rejected type inputs produce zero hostile calls at each actual boundary;
- mutate caller-owned mappings and separately returned projections: future
  witness views/bytes remain checked and unchanged; do not claim reflection
  or hostile same-process isolation;
- checked factories, direct valid instances and stored v2 witness reconstruction
  preserve exact canonical bytes, valid equality and historical compatibility.

B. Complete-operation admission versus historical use:
- invoke actual private WriterSession methods, not only _historical_exact or
  a patched terminal helper, for read, receipt-present record/replay and recovery;
- attach an observing/denying SQLite authorizer at the ACTUAL connection opener
  aliases used by the controller. Account for acquisition and every operation
  connection; separate acquisition observations rather than hiding them;
- label phase with test-only observers that call the real unchanged validation
  and fencing functions and return their real results. No positive assessment
  stub, no skipped validator, no monkeypatch of the predicate under proof;
- prove authorizer attachment using owned calibration SELECTs that really hit
  it, and an intentionally forbidden query that is actually denied. The prior
  wrong-import-alias zero-attempt claim is not a valid oracle;
- record all READ callbacks with connection/phase/table/column. Do not equate
  column-level callbacks to a fixed count of SQL statements;
- the actual managed preflight stop SELECT is observed and allowed solely in
  its invariant phase; after that phase it is denied. Deny all five head-table
  reads for historical operations throughout the observed call;
- move all five actual heads and stop to coherent later values, including a
  valid active stop and a later clear state using owned fixtures/actual owners;
  original result, time, witness, graph and receipt stay exact. Distinguish
  supported product transitions from expressly synthetic later-state fixtures;
- test complete compatible/incompatible winners and original absence routes
  under this same layered read policy. Keep all historical relationship checks;
- separately deny current-stop SELECT DURING managed preflight: read/replay
  fail safely before terminal-family processing; recovery is unresolved where
  its current controller maps this failure. No row write, commit, false
  stale_currentness, definite-absence claim or protected result disclosure;
- independently supply malformed current stop shape at the real validation
  query-return seam, so the unchanged validator determines failure. Preserve
  integrity versus operational distinctions and process-control propagation;
- after removing faults, valid operations again succeed. Closed/stale sessions,
  current disclosure denial/expiry/foreign binding still deny normally;
- fresh receipt-miss recording still observes actual heads and stop; stale
  expectations conflict without writes, correct valid changed-stop expectation
  behaves under the existing terminal rule. No semantic global-stop bypass.

C. Frozen repairs and cumulative behavior:
- rerun F01 SQL/checked-row matrix and O1 calibrated test;
- preserve full five-role S01 actual-drift, own-digest, compatible/incompatible
  predecessor, all-link reseal, later-history and acceptance-nonmutation controls;
- preserve five source-coherent connected normal cases plus detached negative;
- all three cancel-shaped branches and unsupported profiles remain rejected;
- terminal facts still grant no executable/live/publication authority.

Save and reopen the FIRST SUBSTANTIVE checkpoint after constructor tests and
real fenced accept/replan read/replay/recovery plus the admission/semantic
independence controls pass. Record its exact tree/manifest and which controls
reached which phase. It is an internal checkpoint, not a separately accepted
contract tranche. Then complete the remaining controls and final gates within
this same engagement. Ordinary in-scope development failures may be corrected
and rerun; preserve failed/superseded attempts and never give them final credit.

7. FINAL VALIDATION AND PROVENANCE

Never import or execute from the live checkout. Build fresh external copies of
the final candidate, using the 327-file identity and exact numeric modes. Use
the existing installed Python 3.13.4, pytest 8.4.1, SQLite 3.49.1 without installs.
Keep restrictive umask, task-owned HOME/TMPDIR/basetemps/JUnit/logs, deterministic
locale/UTC, bytecode and plugin autoload disabled, empty pytest addopts, and
-p no:cacheprovider. Effective network and unrelated-file access isolation must
apply to parent and synthetic children; test only owned sentinel paths. Never
probe real excluded paths to see whether the sandbox denies them.

Freeze direct modules:
- tests/test_rw0_terminal_outcome_values.py
- tests/test_rw0_terminal_head_witness_regression.py
- tests/test_sqlite_rw0_terminal_controls.py
- tests/test_sqlite_rw0_terminal_migration_0008.py
- tests/test_sqlite_rw0_terminal_connected.py
Also run the six existing connected cases as their own reconciled subset, and
all new whole-operation/constructor controls. State overlaps rather than adding
counts. Retain the prior 126-module focused selector and add every complete
module affected by the fresh dependency scan, notably shared-preflight and
direct document/AST assurance consumers. Deduplicate; never remove a failing
module, skip/xfail a case, or derive fixed expected values from the tested file.

From each exact copy use recorded equivalent commands:
  python3 -B -m pytest -q -p no:cacheprovider --collect-only \
    --basetemp=<owned-collect> <frozen-complete-module-selection>
  python3 -B -m pytest -q -p no:cacheprovider \
    --basetemp=<owned-run> --junitxml=<owned-junit> \
    <same-frozen-complete-module-selection>
Resolve Python and required PYTHONPATH from inspected repo/test configuration,
use absolute recorded interpreter paths, and retain exact argv/cwd/allowlisted
environment. For FULL remove every path/module/node selector from both commands.
Use a nonselecting observational hook for exact call and JUnit nodeid records;
it must not change collection, ordering, outcomes, warnings or test behavior.

Run final direct, connected, focused and selector-free collection/FULL.
Counts must come from fresh collection, not be forced to the predecessor's
51/6/8,257/9,559. Require unique and exactly ordered collected/execution-collected/
call/JUnit identities; all setup/call/teardown outcomes pass, no error, skip,
xfail or xpass. Record all warnings separately by gate; only the existing three
writer-session multithreaded-fork warnings are expected in broad runs that
include those nodes. Do not suppress unexpected warnings; investigate them.

Capture complete source payload/mode inventories immediately before and after
BOTH collection and execution for each gate, plus zero-extra-source-file checks.
Reconcile alternate JSON envelope formats by their complete rows, not by
assuming different serialization hashes imply source drift. Final candidate
manifest must be generated twice and again after cleanup from fresh reads.
Run git diff --check without changing source; retain exact command/result.

Preserve prospective live source/index/config/authoritative-ref observations
through closeout. Do not backdate preservation across the auditor's prohibited
live status operation. No new historical refs/metadata claim is authorized.

8. AUDIT COVERAGE AND PROCESS RECORDS THAT MUST SURVIVE

The latest report is useful evidence but is not compliant acceptance. It
reports an excluded live git-status read and unrelated-path probes; no source
mutation or live preservation is inferred. Do not erase that record, waive it
by narrative, or reassign the same engagement a clean artifact-only verdict.

Retain separately:
- F01/O1 bounded independent successes on the predecessor;
- full-witness and five-role compatibility evidence;
- old whole-operation zero-stop-SELECT failure, explicitly superseded only as
  an acceptance REQUIREMENT by section 3;
- direct-witness constructor failure requiring production repair;
- 51 direct cases with the stated missing direct JUnit-property observation;
- successful independent 9,559-ID collection, interrupted FULL execution with
  zero full-pass credit, and no independent 8,257 focused execution;
- F03/F05 as inherited nonblocking observations;
- A01–A18 unfinished cumulative audit obligations.

Do not silently discharge the report's remaining independent controls:
individual physical occupancy of all 17 aliases, distinct forged V22 proposal
ref, legitimate unrelated acceptance-fact coexistence, full expired/malformed/
foreign/protected-absence posture matrix, exact observer/JUnit-property seam,
and a completed independent selector-free FULL. A07's single-chain fixture
limitation is not proof that a valid unrelated acceptance fact cannot exist.
Future independent review must evaluate these or state exact blocking limits.

9. DELIVERY

Preserve all inputs and old verdicts unchanged. Retain exact immediate and
cumulative before/addition endpoints, both patches, two fresh deterministic
patch manifests, final source manifest/tree and frozen-file comparisons. The
source format and SQL versions stay unchanged; only source-tree identity moves.

Write one implementation report BEFORE sealing. Include:
- original versus amended historical requirement, rationale and exact scope;
- no shared-validator/controller/session/migration production changes;
- constructor invariants, mutable-alias treatment and source proof;
- complete-operation phase/READ map and calibrated controls with actual results;
- exact changed paths, tests, failure/supersession history, source preservation;
- every final gate, warnings, coverage overlaps and unperformed obligations;
- raw-index/ref/process limits, no-effects and current authority nonclaims.

Package one cumulative review ZIP with complete final source, exact historical
inputs, this mandate, original audit evidence, report, patches/endpoints,
classification/consumer map, source/validation/cleanup/provenance evidence and
self-excluding manifest. No credentials, databases/sidecars, bytecode, caches,
raw private template/capsule/process output, or unclassified host data. The
embedded report is sufficient; no distinct standalone-report equality gate is
required, but a uniquely named identical standalone copy may be supplied.
Reopen and verify every member, reconstruct the source tree from payloads, and
write an adjacent receipt with ZIP/report/manifest sizes and hashes.

10. STOP CONDITIONS AND RETURN

Stop before further effect if opening source or semantic Git identity cannot
be established; an input differs; a missing original operand is required; a
new production file, migration, authority meaning or common-admission bypass
would be needed; protected source/modes drift; tests require weaker assertions,
skips, fabricated facts or unsupported isolation. Ordinary in-scope test
failures during implementation may be repaired without a new user handoff;
no success disposition until final bytes satisfy every required gate.

Return one primary disposition:
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_REPAIR_IMPLEMENTED_VALIDATED_PENDING_AUDIT
or
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_REPAIR_BLOCKED_<PRECISE_REASON>

Report exact opening/final tree and 327-path manifest, HEAD/branch/upstream,
touched files, amendment, constructor/phase controls, checkpoint, all final
gates and warning/ID reconciliation, frozen production/SQL preservation,
artifacts and their hashes, errors/limits and explicit:
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
MERGE_NOT_PERFORMED
PUBLICATION_NOT_PERFORMED
DEPLOYMENT_NOT_PERFORMED
PRODUCT_EFFECT_NOT_PERFORMED

No audit/publication authority follows. Next recipient: ChatGPT for receiving
inspection and a fresh cumulative audit handoff that carries THIS explicit
contract amendment. Do not reuse the prior audit prompt unchanged.
