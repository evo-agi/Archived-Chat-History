Here is Codex's response:

**RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE**

QtcM’s five metadata rules resolved the measured immediate-entry denial. A separate required containment control failed: a hardlink placed by the trusted supervisor in writable scratch let the sandboxed probe read a protected root sentinel and open it for writing. The probe wrote no bytes. Creating that hardlink *inside* the sandbox was denied. This establishes a runner limitation at the preplaced-hardlink scope, not a candidate defect.

I stopped before candidate execution. The four representatives, exact 99-node replay, direct and FULL suites, and 30 substantive residual probes remain unrun under QtcM. The 327-file candidate tree is unchanged. The smallest restart point is a decision on the required preplaced-hardlink boundary, followed by qualification of a compliant runner.

The package was reopened and all 45 members verified:

| Artifact                                                                                                                                                                                                         | Bytes     | SHA-256                                                            |
| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------------ |
| [Report](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/md-812d7d86be/REPORT.md)                                                                                                             | 27,025    | `f4b71165723c1a63cc9da5a8c8c044c165b60d0cb6c2c1c26339efef197c5377` |
| [Evidence ZIP](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/md-812d7d86be/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_md-812d7d86be.zip) | 6,677,682 | `10d793d8d18046d7afa5385aee832576e90e3378ccaff14b58f133b3fe31ad4f` |
| [Manifest](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/md-812d7d86be/MANIFEST.json)                                                                                                       | 10,167    | `bb4126e6e992e095919df92ecc0205a724b1ec523910024a2fdd13ea2f50e879` |

The [receipt](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/md-812d7d86be/delivery_receipt.json) records the reopened package identities.
