ENGAGEMENT ENVELOPE

CURRENT STATE
The normal-terminal candidate remains uncommitted and unaccepted. Its S01
full-witness and selected A03 exact-type repair predicates passed bounded
independent checks, but the cumulative audit is BLOCKED by F01 timestamp
validation. The independent selector-free FULL run and remaining cumulative
controls were not completed. The audit also disclosed a preliminary prohibited
live-checkout read; preserve that process deviation separately from F01.

RECIPIENT
The SAME write-enabled normal-terminal implementation Codex conversation that
produced tree 011f76542a77b2a766a46ac08df102b4de4c09c6. The parent is the sole
writer. Do not spawn subagents or perform an independent audit here.

ATTACHMENTS
Exactly one new evidence input:
RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_BLOCKED_EVIDENCE.zip
151,261 bytes; SHA-256:
b81f4713d4bfaa4c4c943727f1db007907e560d90432cb06b31545ced21235e5
The complete 26,456-byte audit report is inside that ZIP; a separate report
attachment, Pasted text.txt, Downloads search, or prior-chat lookup is unnecessary.

AUTHORIZED EFFECTS
Bounded terminal SQL/row validation, direct tests and dependent catalog/docs
updates; isolated synthetic validation; external review artifacts. No staging,
commit, push, PR, merge, deployment, live services, or product effect.

EXPECTED RETURN
One cumulative uncommitted repaired candidate, complete report, self-contained
review ZIP and adjacent delivery receipt, all bound to exact source bytes.

PROJECT SNAPSHOT
None requested. Integrated PR #17 remains the committed baseline.

NEXT ACTION
Return the result to ChatGPT for artifact inspection and a fresh independent
precommit audit. Do not begin that audit, a commit gate, or a new program here.

OBJECTIVE

Repair F01 at BOTH independent validation layers: the physical timestamp
constraints in migration 0008 and the private terminal checked-row adapter.
Also correct the already identified O1 test-counter oracle in the same narrow
patch. O1 is nonblocking in the audit; this is a deliberate test-quality fix,
not a newly asserted production defect.

Do not redesign terminal closure or revisit the selected five-normal-outcome
program. Preserve the S01 complete-witness implementation and historical
compatibility predicate, A03 type-first checks, P0/P1 ownership, and all
unimplemented cancellation/live-effect boundaries. Do not run another broad
reconnaissance or a standalone semantic-contract tranche.

REPOSITORY AND EXACT STARTING SUBJECT

Repository:
/Users/ds/Repositories/Governed Execution Coordinator/

Require before editing:
- branch: codex/rw0-normal-terminal-closure-v1
- HEAD: 61d0330aba1160f7f5e7d9c541a325222d1c61e5
- HEAD tree: 44c7dee402d46b3e16dc389ae0824b4297dfec1f
- upstream: absent
- semantic index: all 315 stage-zero baseline entries equal HEAD;
  no staged or unmerged change
- current uncommitted source: 327 regular files
- current tree: 011f76542a77b2a766a46ac08df102b4de4c09c6
- current canonical source manifest: 109,923 bytes; SHA-256:
  45f6716d16522cecb21c046c302893624ab30e8094b15d7f93e628681e00dcbc
- cumulative source delta: 67 modified, 12 added, 0 deleted; no mode changes
- current tracked patch: 134,264 bytes; SHA-256:
  c8d27d1a8e81663ec3ec143eccc40bbc767e272b6b979cf4e0876b2405ec6b92
- exactly 326 source files OS 0644 / Git 100644, and:
  tests/test_c2b3_private_atomic_program_initialization.py
  OS 0600 / Git 100644.

Retained implementation root:
/Users/ds/.codex/rw0-terminal-s01-a03-repair-f99a8b9b377f/

Authenticate its existing files without regeneration:
1. RW0_NORMAL_TERMINAL_CLOSURE_S01_A03_REPAIR_UNCOMMITTED_REVIEW_F99A8B9B.zip
   25,334,611 bytes; SHA-256:
   f06d97a0becddec07e30676b3988dfcde9d4a79cb6b77a41c23fe4b9d429dd90
2. RW0_NORMAL_TERMINAL_CLOSURE_S01_A03_REPAIR_IMPLEMENTATION_REPORT.md
   22,590 bytes; SHA-256:
   0bbd1d73016e9b4593e14dd85743dad5ad1080f8892e4e5879a2f2b3f24107a5

The prior package supplies exact final source, manifests, original integrated
baseline bytes, original blocked candidate/audit, S01/A03 repair controls,
current 126-module selector, and retained validation. Use it as the immutable
opening candidate, not as an executable helper or source of new authority.

Read the present mandate completely before Git operations. Read AGENTS.md and
the governing terminal/SQLite owners before authoring. Copy the raw index and
record its identity outside the repository before ordinary Git reads. Use
GIT_OPTIONAL_LOCKS=0, GIT_NO_REPLACE_OBJECTS=1 and deterministic locale for
observations. Do not reset, clean, restore, switch branch, fetch or rewrite refs.

Reuse the source/patch recipe in the retained package, inspecting it before use.
Do not silently change its serialization. Authenticate package/member manifest
coverage, all source payloads and modes, and tree identity from actual bytes.
Capture current source twice. Compare config, HEAD, authoritative refs and
semantic index with retained observations. Qualified direct diagnostic refs
under refs/codex/turn-diffs/captures/ and refs/codex/turn-diffs/checkpoints/ are
separate evidence, never source selectors. Record additions/removals; a surviving
name retarget or an authoritative discrepancy blocks. Do not use a volatile
all-ref aggregate as the candidate identity.

A pre-opening raw-index byte difference with an exactly equal semantic HEAD
index is a disclosed historical metadata limit, not permission to reset it.
Classify it, preserve the observed raw bytes, and freeze the prospective anchor.
Any staged/unmerged/source/config/authoritative-ref ambiguity blocks. The
previous auditor's preliminary read proves no continuous live preservation.

AUDIT INPUT AUTHENTICATION

Use only the actual attached ZIP path. Verify its 151,261-byte outer identity
above, then its central directory, bounded expansion, safe unique regular
members, and self-excluding manifest. Expected: 38 members, 37 covered rows.
The 8,161-byte member-manifest.json has SHA-256:
55254d64093327646b7a70571037d752397fabdf2b669fddc119fb5bb3369618

Locate the unique full report by its authenticated bytes, recording its actual
member path rather than guessing:
26,456 bytes; SHA-256:
32d697f4bfceaa08d97338af30cc40258be4643d385f6e8f418e3be6ee2a9612

Read the full report, F01 fixtures/results, S01/A03/O1 results and A01-A18
coverage register. Archived audit scripts are inert evidence; do not execute
them wholesale. Author the repair's own regressions from their documented
counterexamples. If the ZIP, embedded report or decisive record is unavailable
or inconsistent, stop before mutation with the exact missing dependency.
Do not substitute the 19,542-byte pasted summary for the full audit report.

The original candidate 648d332b3ba847deb257a2bb1892a76e4c442675 and current
011f76542a77b2a766a46ac08df102b4de4c09c6 retain their historical BLOCKED verdicts.
S01/A03's successful selected predicates are bounded evidence, not acceptance.
The audit's live-checkout read remains a process deviation; no retrospective
index-preservation or compliant artifact-only claim may be made.

F01 — SOURCE-SUPPORTED DEFECT AND LIMIT

Migration 0008 has three recorded_at columns:
- rw0_terminal_contexts, source SQL line 44;
- rw0_terminal_results, line 121;
- rw0_terminal_receipts, line 154.

Their CHECKs compare strftime('%Y-%m-%dT%H:%M:%SZ', recorded_at) to the original
text but do not reject a NULL function result. The audit's impossible date
2026-13-27T12:00:00Z passed the three SQL insert boundaries on SQLite 3.49.1.
SQLite CHECK rejects zero, not NULL; a column NOT NULL does not cure a NULL
computed predicate.

The existing row adapter already imports _time but does not call it for
recorded_at at _rw0_terminal_outcome_rows.py:90-155. Correctly resealed result
and receipt rows with invalid recorded_at passed seal_row and checked_row.
The owning document requires canonical UTC whole-second timestamps.

The plan already calls _time at _rw0_terminal_outcome_plan.py:124 and
historical reconstruction reaches that planner. The audit did NOT demonstrate
an invalid normal-writer commit or unsafe committed_exact. Repair physical
schema/row grammar without claiming such an exploit or changing error
classification to an ordinary stale-currentness conflict.

FROZEN REPAIR STRATEGY

1. SQL: a total, fail-closed calendar predicate in all three columns.

Preserve ANY/NOT NULL, exact text type, exact ASCII whole-second form,
YYYY-MM-DDTHH:MM:SSZ, and all existing unrelated constraints. Make an invalid
calendar conversion evaluate to rejection, never NULL acceptance. An explicit
non-NULL guard or a total CASE/COALESCE predicate is required if date functions
remain involved; that is necessary but not by itself sufficient.

Validate real calendar semantics and canonical form, not only the one bad month:
month/day and leap-year validity; hour 00-23; minute/second 00-59; no year 0000;
no rollover, offset, fractional second, leap second, whitespace, embedded NUL,
Unicode-digit substitution, or alternative representation. Use deterministic
component/calendar checks and/or a demonstrated canonical round trip. Do not
normalize invalid input into a valid stored time. Do not rely on current time,
localtime, a user-defined SQLite function, extension, locale, or connection-
installed callback. Literal migration SQL must enforce its own boundary.

Keep the terminal owner's existing supported calendar domain. Test documented
endpoint years against the existing _time parser on the supported runtime;
do not silently widen that domain or invent a new global timestamp policy.
A formatting/library discrepancy must be reported with its exact scope rather
than hidden by coercion or a broad parser change.

2. Row adapter: enforce the existing _time owner directly.

In checked_row, explicitly apply the existing _time validation to every actual
recorded_at column: context, result and receipt. It must run before a valid
TerminalRow can be returned, regardless of whether the self-digest is correct.
Reject wrong built-in types/subclasses before hostile comparison/coercion.
Both seal_row and direct checked_row construction must reject invalid times.
Do not add a timestamp field to the outcome table, which has no recorded_at.
Keep nested stop/head timestamp checks delegated to their existing owners.
No new parser, timestamp canonicalization, broad exception catch, safe-value
schema version, digest domain, graph role, or row column is needed.

3. Migration treatment: correct the still-uncommitted 0008 in place.

Current 0008: 27,856 bytes; SHA-256:
5bd540def9028d09c4e2100f61f449acfb3a5c914fa554f47975d8c773d4cd20

Update its literal catalog checksum and exact direct consumers. Preserve SQL
0001-0007 and schemas/sqlite/coordinator-state-v1.sql byte-for-byte. No 0009,
new table, new trigger, column, index, seed or application-generation bump.
Cumulative shape remains 78 tables / 142 triggers / 5 explicit indexes,
application generation 2. Earlier schema objects remain exact. Preserve
context.v2, the 32,768-byte complete witness bound and compact outcome fields.

Old uncommitted 0008 databases are historical test artifacts, not deployed
compatible stores. Checksum/schema mismatch must refuse; do not recognize both
0008 variants as current, backfill invalid timestamps or repair a real database.

4. O1: repair the test oracle, without changing production type semantics.

In tests/test_rw0_terminal_outcome_values.py:111-116,133, EqualitySpy increments
self.calls but the test asserts the class attribute. Replace that mismatch with
an actually observed shared/per-instance counter. Keep references to every
probe instance or use a shared counter; check after each relevant production
boundary. Include a positive calibration that intentionally invokes equality
and proves the counter changes. Then prove production rejection occurs with
zero calls. Do not relabel O1 as an authority bypass. No production enum/type
change is authorized by this test correction.

PRESERVATION AND AUTHORIZED SURFACES

Primary edits:
- src/ge_nwp_coordinator/sqlite_migrations/0008_rw0_terminal_outcome.sql
- src/ge_nwp_coordinator/_rw0_terminal_outcome_rows.py
- src/ge_nwp_coordinator/sqlite_migration.py: only dependent 0008 catalog data
- tests/test_sqlite_rw0_terminal_migration_0008.py
- tests/test_rw0_terminal_outcome_values.py, including O1
- tests/test_sqlite_rw0_terminal_controls.py: bounded timestamp read/write controls
- .docs/rw0-terminal-outcome-physical-closure.md: grammar/repair/checksum alignment

The inspected old-0008 literal also occurs in these direct test consumers:
- tests/test_rw0_c2_durable_progression_decision_semantic_contract.py:994
- tests/test_sqlite_b1_migrations.py:179
- tests/test_sqlite_section41_migration_0003.py:280
Update those fixed expectations only as justified by actual new SQL bytes.

Before editing, scan all 327 source paths for exact SQL checksums, schema/row
identities, owner text and all changed-file consumers. Existing direct
assurance consumers beyond the list may change only when the dependency is
recorded. Do not merely replace every occurrence of an old hash: preserve
historical anchors, endpoint payloads and predecessor reconstructions.
Do not change all current-status owners just to announce another repair.

No new repository path is needed; retain 327 source paths. Extend existing
terminal test modules. Freeze these production bytes from the opening subject:
- _rw0_terminal_head_witness.py
- _rw0_terminal_outcome_contracts.py, including _time and all A03 checks
- _rw0_terminal_outcome_plan.py, including snapshot_compatible
- _sqlite_rw0_terminal_outcome.py
- sqlite_transition_transaction.py and sqlite_writer_session.py
- P0/P1, C1, Section 41, D1/D2, WorkSpec, V1 terminal/four validators,
  generic receipt, public StateStore/package APIs and SQL 0001-0007.
Their transitive behavior is regressed through the corrected row adapter, not
rewritten. If another production change is genuinely required, stop with exact
source evidence rather than expanding this mandate.


REGRESSION AND CAUSAL EVIDENCE

Do not rely on the planner to demonstrate SQL or row rejection. Test the three
layers separately. Define fixed input/expected cases before implementation.

A. SQL boundary, all three timestamp columns.
- Reproduce the exact invalid-month counterexample on original 0008 in owned
  synthetic state as historical evidence; the repaired literal must reject it.
- Apply literal authenticated SQL using ordinary SQLite, without the candidate
  row sealer. Exercise each of the three INSERT targets independently.
- For each negative, supply valid unrelated fields/parents/keys; a paired valid
  timestamp must insert successfully under the same arrangement. Use fresh
  state/savepoints so duplicate keys, foreign keys, unrelated checks or immutable
  triggers cannot supply false causal credit for timestamp rejection.
- Test non-leap February 29, February 30, April 31, month/day zero and overflow,
  hour 24/25, minute/second 60, year 0000, noncanonical text, NUL and wrong types.
- Include ordinary dates, valid month ends, leap days (including 2000/2024),
  year-end 23:59:59, and supported endpoint years as positive controls.
- Test Gregorian century behavior (1900/2100 invalid February 29, 2000 valid).
- Verify actual byte-length/ASCII rejection; SQLite text length alone must not
  accidentally admit trailing NUL data.
- Preserve FK, uniqueness, pair, profile, immutability, STRICT and zero-seed
  controls; do not turn them off to make the final product tests pass.

B. Row boundary, all three recorded_at-bearing tables.
- Use otherwise-valid context/result/receipt mappings, with canonical blobs and
  correct self-digests, and replace only the timestamp plus dependent digests.
- Exercise direct checked_row tuples and seal_row with both blank and supplied
  digests. Build correctly recomputed invalid-row digests in test-owned code
  from the documented digest preimage; do not require the corrected sealer to
  manufacture the negative specimen.
- Cover impossible and noncanonical times, None, integers, booleans, bytes and
  str subclasses. Rejection must reach the time/type predicate, not fail only
  at a digest, foreign-key or unrelated field check.
- Compare valid supported inputs with _time and TerminalCommittedV1; positive
  rows and existing valid canonical/digest vectors must retain their semantics.
- Do not infer SQL rejection from Python rejection, or vice versa.

C. Higher-level no-regression controls.
- A real fresh writer still records valid accept and replan families with one
  canonical recording time; all five connected normal outcomes remain valid.
- An invalid captured recording time cannot persist any terminal family or
  receipt. Establish the actual injection site and absence of target writes;
  a wrapper refusal alone is not a SQL-boundary proof.
- Fault-inject a malformed persisted result or receipt at the actual selected
  row-return seam, or seed isolated test-only corrupt state. Run the unmodified
  terminal reader/replay/recovery. Require integrity failure/no protected result
  and unresolved recovery, no write, no normalization and no hidden retry.
- An invalid or incomplete competing family must not prove definite noncommit
  or reveal a winner. Preserve the exact valid-family positive.
- Corrupt-state fixtures must be confined to disposable test databases and
  explicitly identified as such. Never weaken production checks or leave test
  bypasses active during the tested reader/recovery call.
- Preserve process-control propagation and distinguish malformed timestamp
  integrity from ordinary stale state or valid clock/currentness behavior.

D. Preserve S01/A03 credit on changed bytes.
- Run the complete existing head-witness regression module and A03 values tests.
- Preserve full witness/currentness/immutable predecessor controls, original
  and competing-family recovery, and historical replay after later head/stop
  movement. Use real compatible and incompatible families, not only mocked
  verifier exceptions. Do not claim independent execution credit here.
- Fix and calibrate O1 as specified. Do not remove old exact-type negatives.

FIRST CHECKPOINT AND DEVELOPMENT WORK

Save and reopen a substantive checkpoint before broad validation. It must bind
the exact candidate bytes, SQL/row F01 negative and positive matrix, corrected
O1 counter, S01 regressions, and real accept/replan record/read/replay/recovery
positives. Include code, exact invocations and source/ID results sufficient to
reconstruct this checkpoint's scope. It is not final validation for later edits.

Normal in-scope failures may be diagnosed, repaired and rerun within this
engagement. Preserve failed/superseded attempts and exact source bindings; grant
no final credit to them. Do not stop merely because the first test exposes a
fixable in-scope bug. Stop for identity/authority/scope conflict, unavailable
required capability, or a new defect requiring changes to frozen owners.

FINAL VALIDATION — FINAL BYTES ONLY

Use installed Python 3.13.4 / pytest 8.4.1 / SQLite 3.49.1 on the supported host,
without installation. Record actual executable and versions. Build fresh exact
external source copies, never import/run tests from the live checkout. Use
restrictive umask, owned HOME/TMPDIR/basetemps/JUnit/logs, bytecode/user-site and
plugin-autoload suppression, cleared PYTEST_ADDOPTS, deterministic locale/UTC,
and verified network denial. No provider, ES/Bridge or user database.

Run final collection and execution for:
1. Direct: the complete existing five terminal modules, including S01/O1/F01.
2. Connected: all six existing connected cases, including five real source-
   coherent normal positives and detached-disposition negative.
3. Focused: preserve the prior 126 complete modules, adding every newly affected
   complete module found in the consumer scan; deterministic deduplication.
4. FULL: one successful final selector-free repository collection and execution.

Underlying forms, from the isolated source copy:
  <python> -B -m pytest -q -p no:cacheprovider --collect-only \
    --basetemp=<owned_collection_dir> <frozen_selection>
  <python> -B -m pytest -q -p no:cacheprovider \
    --basetemp=<owned_execution_dir> --junitxml=<owned_junit> <same_selection>
For FULL, <frozen_selection> is empty: no path, node, -k or -m selector.
A nonselecting observer may record exact call IDs and warnings; retain its source
and prove it neither skips/selects cases nor changes outcomes.

Freeze ACTUAL final counts and ordered inventories. Do not force 46, 8,252 or
9,554 by dropping tests. Require unique collected = execution-collected =
executed calls = JUnit IDs in order, all passing, no failures/errors/skips/
xfails/xpasses or hidden noncall failures. Retain unsuppressed warnings. The
three known fork deprecations are scoped evidence, not six distinct findings or
permission to suppress unexpected warnings. Direct/connected remain warning-free
unless an explicitly explained change establishes otherwise; do not hide drift.

Capture complete source byte/mode manifests immediately BEFORE and AFTER BOTH
collection and execution for every final gate (four captures per gate). Earlier
writer evidence had only outer captures; this requirement supplies the missing
intervening observations prospectively and does not backdate them. Require no
source changes or unclassified extra files. Preserve the one OS-0600 source.

Independently apply all eight literal SQL resources to owned state. Check
68/122/5 at 0006, 74/134/5 at 0007, 78/142/5 at 0008, exact older objects, zero
new application rows, FKs/immutable guards, fresh initialization and explicit
0006/0007-prefix upgrades. Exercise refusal of old-binary, unknown, partial and
old-uncommitted-0008 checksum/schema states. No live-database migration.

A green implementation FULL does not replace the outstanding independent FULL.
The next independent review must preserve A01-A18, including unfinished
fully-resealed five-role predecessor checks, original-private-operand/source
association, acceptance variants, assertion/reuse identity, posture/error and
stop distinctions, transaction/cleanup/process-control faults, damaged/partial/
foreign winner routes and aliases, and all normal/cancel-boundary controls.
Record exact coverage and gaps; do not mark these discharged by suite totals.

PROVENANCE AND DELIVERY

Preserve the preceding source ZIP and all blocked audit records unchanged. Use
the existing provenance machinery; extend its version narrowly only if a changed
inventory requires it, never introduce a general evidence framework.

Retain exact opening/final source and mode manifests, Git-compatible trees,
immediate and cumulative path inventories, before/after endpoints, full-index
patches, inherited addition payloads, frozen-owner comparisons, new SQL/catalog
identities, consumer map, checkpoint, and every final command/ID/JUnit/warning/
source capture. Generate deterministic source/patch identities twice from fresh
reads and repeat after bounded cleanup. Preserve failed/superseded runs with
source attribution and no final credit. Record index/config/authoritative-ref
preservation and classified diagnostic changes without backdating old gaps.

Create one self-contained cumulative review ZIP: complete final source, exact
immediate before endpoints and cumulative baseline reconstruction material,
requirements, complete new validation, the prior candidate archive once, and
the new audit evidence ZIP once. Do not flatten or multiply historical archives.
Exclude credentials/config dumps, user data, runtime SQLite/sidecars, bytecode,
caches, build output and OS metadata; classify exclusions explicitly.

Write RW0_NORMAL_TERMINAL_CLOSURE_F01_TIMESTAMP_REPAIR_IMPLEMENTATION_REPORT.md
before sealing; include identical bytes at evidence/IMPLEMENTATION_REPORT.md
and keep a standalone reading copy. Use a self-excluding member manifest.
Reopen and verify every member and source reconstruction. Issue an adjacent
receipt with ZIP/report/manifest byte counts and SHA-256 values. A separate
standalone report is not an independent witness or mandatory future attachment.

Report F01/O1 as implementation repairs pending fresh independent review.
Attribute prior S01/A03 evidence to its prior source, and new regressions to the
new tree. Preserve F03/F05 and all cancellation/live/product nonclaims.

STOP CONDITIONS AND EFFECT CEILING

Stop before the next effect for a source/input identity mismatch, unsafe
artifact, semantic-index or protected-state ambiguity, required frozen-owner
change, source/test weakening, unclassified generated/sensitive material,
unavailable required validation, or boundary widening. Retain completed findings
and explicit unperformed coverage. Do not repair state/ref identities by reset.

Authorized: the narrow source/schema/docs/test changes above, local owned
synthetic execution, and external evidence. Not authorized: subagents,
staging, commit, branch switch, push, fetch/pull, PR/merge, provider/network
service contact, ES/Bridge access, dependency installation, a real database,
cancellation implementation, live supplier/contact, deployment or product effect.

REQUIRED RETURN

One primary disposition:
RW0_NORMAL_TERMINAL_CLOSURE_F01_TIMESTAMP_REPAIR_IMPLEMENTED_VALIDATED_PENDING_AUDIT
or
RW0_NORMAL_TERMINAL_CLOSURE_F01_TIMESTAMP_REPAIR_BLOCKED_<PRECISE_REASON>

Return the complete source/patch identities and touched paths, timestamp
predicate and boundary results, calibrated O1 result, preserved S01/A03 proof,
SQL/catalog results, checkpoint and all final validation/ID/warning/source
records, failed or skipped work, provenance limits, and report/ZIP/receipt
identities. Clearly label implementation execution versus retained independent
evidence. State that independent audit, staging, commit, push, PR, merge,
publication, deployment and product effects were NOT performed.

Return to ChatGPT. Do not perform the fresh independent audit or a commit gate.
