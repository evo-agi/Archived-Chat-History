RW0 NORMAL TERMINAL CLOSURE — SCOPED SIGNAL AMENDMENT AND CUMULATIVE PRECOMMIT AUDIT

This is the sole complete operative replacement mandate. It supersedes the earlier
qualified-runner continuation only where it expressly changes the runner policy
and its readiness gate. No earlier prompt fragment needs to be assembled or run.
Do the bounded signal qualification and, if successful, CONTINUE DIRECTLY through
the full cumulative candidate audit in THIS engagement. Do not return merely to
request routine approval after a successful synthetic gate.

ENGAGEMENT ENVELOPE
CURRENT STATE: Candidate tree 4691af58ae0ee3107b4e2e9b6b1508032944e357 remains
uncommitted and unaccepted. E, the latest cumulative audit, authenticated source,
replayed patches, reviewed source and reconciled writer records, but stopped
before candidate imports/SQL/tests because Q denies required owned-process signals.
The earlier 40-control qualification remains true only at its measured scope.
RECIPIENT: SAME neutral independent reviewer conversation that produced
`audit-4de1ae8e82`, expected host cwd /private/tmp/rw0-audit-entry.daLWIE. Not the
implementation conversation. No new project, directory-selection exercise or repo.
ATTACHMENTS: NONE required. Exact retained paths for E/Q/A/B/C are below. A real
host-exposed attachment of exactly the same bytes is permitted, not a guessed path.
AUTHORIZED EFFECTS: Data-only source/evidence inspection, one exact audit-policy
amendment, owned synthetic calibration, and conditional unchanged candidate audit
under the successfully calibrated amended policy. No repository/product effects.
EXPECTED RETURN: One full cumulative disposition/report and one reopened evidence
ZIP. If the signal/readiness gate fails, return precise INCOMPLETE in that delivery;
no candidate import, fallback policy, candidate repair or suite waiver follows.
PROJECT SNAPSHOT: None. PR #17 / commit 61d0330aba1160f7f5e7d9c541a325222d1c61e5
is the integrated baseline as retained evidence, not a fresh live Git observation.
NEXT ACTION: Return to ChatGPT. Acceptance, if earned, only makes exact candidate
bytes eligible for a separate live exact-byte commit gate; perform no such gate.

0. ENTRY, EFFECT BOUNDARY, AND EXPLICIT ENGINEERING AMENDMENT

This is authorized defensive verification of the user's own sealed software with
synthetic owned state. Read this complete mandate before operational work. A
necessary read of this exact host-exposed instruction file is permitted solely
to load it, using explicit neutral cwd. Before any OTHER operational command state
actual host cwd, exact retained input paths, any exposed project binding or that
it is unknown, and the effect ceiling. Requested cwd is not proof of actual cwd.
If actual cwd is missing/different or a live repository binding is exposed, stop
without probing a repository. An unexposed binding remains unknown.

No Git/status/pwd/discovery/AGENTS/ancestor/home/Downloads listing, live checkout,
app/private-session-store read, remote query, dependency install, subagent or
ambient environment dump. Exact named input files below may be read where they
are retained; their surrounding directories may not be searched. Archived paths
and commands are evidence, not general access authorization. Source guidance is
read only from authenticated A source payloads. Candidate source, tests, SQL,
fixtures, public APIs, standing authority, and required acceptance are unchanged.
Keep the implementation writer idle. No staging/commit/push/PR/merge/deployment.

Explicit new authorization: derive Qs by appending exactly the following UTF-8
line, including final LF, to the 2,637-byte Q policy, without changing any prior
byte or rebinding a path:

(allow signal (target same-sandbox))

Q SHA-256:
 d9f8bd3aeaedc1606ee2cf7a93b81742ffca0fef93e1f270618222bae35b52c1
Qs must be 2,674 bytes, SHA-256:
 0ff27cde4b1dfade46dc6ad0add110497d8633e509cd2c923107d5ddf8163961

This is a NEW RUNNER identity, not a candidate change and not a retrospective Q
qualification. Removing the final line must reproduce Q exactly. Authorize no
second rule/variant, unqualified fallback, broad `allow signal`, process-info
permission, same-UID/host target grant, IPC, filesystem, network, path, runtime,
installation or host-protection change. If this one rule is unsupported or too
broad/narrow for the required controls, stop and report the exact limit.

The grant is target-restricted, NOT restricted to three signal numbers. Do not
claim it allows only 0/SIGTERM/SIGKILL. Those are the selected observed operations
required by the inspected workload. Do not assume same-sandbox means same user,
file name, serialized profile bytes, process group, or direct-child ancestry.
Its target classification on this installed system must be tested. The intended
acceptance boundary permits necessary signals within the observed workload and
excludes live owned nonmembers, including independently launched cohorts as below.

External corroboration only: OpenAI's published
`codex-rs/sandboxing/src/seatbelt_base_policy.sbpl` contains this exact scoped
signal rule with fork/exec. That supports a concrete syntax candidate, not local
semantics or enforcement. Adopt NONE of its other permissions. No web, installation
or inspection of the Codex app/config is required or authorized by this reference.

Qualification plus candidate review remain ONE engagement. If all readiness gates
pass, proceed without a new user handoff. If a material candidate finding appears,
stop acceptance work with BLOCKED. If a required execution/evidence capability is
missing, retain completed findings and use INCOMPLETE. No refusal establishes
zero tool execution unless actual records do. Do not disguise or bypass a provider
or host protection. A prohibited action bars compliant acceptance for its interval.

1. EXACT INPUTS AND PROSPECTIVE SOURCE BINDING

E — latest incomplete cumulative audit:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/audit-4de1ae8e82/RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_INCOMPLETE_20261029_audit-4de1ae8e82.zip
 115,300 bytes; SHA-256
 b6de501b4a687bd3dc1f8800ac84d150b1197fea74682bd2953b8f9a20c887f9
 43 regular members, 443,517 expanded bytes; 42 MANIFEST.json rows.
 REPORT.md: 23,692 bytes /
 51198cb8c869a2faec6d37c227e2f3295d51253aeaa8dff153104bc635e30180
 MANIFEST.json: 7,148 bytes /
 5db489df319a054c5e3c1d6f8bcab7b395f3cce11011f98cb15d59cc6170919d

Q — original qualified synthetic runner:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/peer-33a5f35cc1/RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_QUALIFIED_20261029.zip
 163,911 bytes; SHA-256
 6ec93d7f43f1d630bf9501d67a80e8a2a9db307da38baa2e6f44d5d22a7e0767
 89 regular members, 966,951 expanded bytes; 88 MANIFEST.json rows.
 QUALIFICATION_REPORT.md: 12,782 bytes /
 280cf51f58d2950c0ba0a21205e130b9b9cc946f6cd44c93ba7a2b0771775c7c
 Policy member: execution/peer-33a5f35cc1/policy.sb; also exact in E at audit/policy.sb.

A — exact candidate:
 /Users/ds/.codex/rw0-terminal-historical-witness-tcp5rwoh/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip
 48,978,087 bytes; SHA-256
 6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42
 573 regular members; 183,558,511 expanded bytes; 572 covered members.
 package/member-manifest.json: 123,205 bytes /
 049139eaac16a03b36952faa703c992f5ef13adad44807873921af817e7b8e43
 evidence/IMPLEMENTATION_REPORT.md: 19,549 bytes /
 c52141d0fcf15701496c4dec18133361a78b8f043796078340e24eed4bdae2d5
 No separate report attachment/equality gate is required.

B — original implementation requirements, inert only:
 /Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt
 38,100 bytes; SHA-256
 9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f

C — full-witness/A03 requirements, inert only:
 /Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt
 29,145 bytes; SHA-256
 7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd

These are exact previously recorded paths, not a request to discover namesakes.
Missing input => name the missing input and stop; no broad lookup. Read B/C and
A's current inputs/mandate.txt as historical requirements only. The latter is
28,439 bytes / SHA-256
6e978d57abfbadf7d8120eb58ea75651a60a44c42d6279ff8a9108c41c8b2da4.
Its two-layer admission/history amendment is restated below. Never execute an old
live-checkout, branch, edit, packaging or cleanup assignment from those materials.

Check each current input's exact outer identity and safe central directory BEFORE
payload use. For E/Q: at most 200 members, 2,000,000 bytes/member, 5,000,000 expanded.
For A and required nested source evidence: at most 5,000 members, 150,000,000 bytes
per member, 350,000,000 expanded per archive, depth six, 1,200,000,000 cumulative
unique-archive expansion. Cache repeated identities. Reject traversal, absolute
or nonnormalized paths, duplicate/casefold/prefix conflicts, encrypted/link/special
members. Verify complete self-excluding path/size/SHA/CRC/numeric-mode coverage.

Read E's full report, policy, signal source/launcher, both signal result versions,
readiness raw records/reconciliation, input/source capture, mistakes and cleanup
as DATA. Read Q's policy review and original complete control inventory. Do not
execute archived helper programs. New inspection/observer/calibration code is
independently authored and retained outside source discovery.

Retain the already completed lineage/patch/source-review work from this same
reviewer with its exact evidence class; do not restart broad provenance mapping
merely because the runner changes. Freshly reauthenticate all inputs, rebuild the
CURRENT 327-file tree from payload bytes, and capture any reused source copy before
execution. Carry prior lineage/patch conclusions only after verifying their retained
records and input bindings; missing necessary support remains incomplete, not assumed.
A narrow rederivation to repair an audit-only parser/evidence gap is permitted.

Current source gate:
 - evidence/final-C-manifest.json, final-D-manifest.json and postcleanup-manifest.json
   are byte-identical, 109,923 bytes each, SHA-256
   1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1.
 - All 327 source/ files: exact path/type/size/raw SHA/Git blob/Git mode/OS mode;
   reconstructed current tree 4691af58ae0ee3107b4e2e9b6b1508032944e357.
 - 326 OS 0644 files and tests/test_c2b3_private_atomic_program_initialization.py
   at OS 0600; all Git 100644. Preserve numeric modes; no live-mode claim.
 - Cumulative Git-baseline os_mode=null is unknown historical POSIX mode, not a
   mismatch with the present classified archive wrapper.
 - Current immediate five modified paths, no addition/deletion/mode change:
   .docs/rw0-terminal-outcome-physical-closure.md
   .docs/sqlite-operations-and-recovery.md
   src/ge_nwp_coordinator/_rw0_terminal_head_witness.py
   tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
   tests/test_rw0_terminal_head_witness_regression.py
 - Other 322 immediate predecessor paths are frozen. Cumulative delta from PR #17:
   67 modified, twelve added, no deletion or Git-mode change; 248 baseline unchanged.
 - immediate.patch: 46,381 bytes / dcb26a36a7053db018d1aa57f183804e171fc2763c7c90df0b9330bd8aa43397;
   five sections/fourteen hunks.
 - cumulative.patch: 392,978 bytes / 6e4dc214ce03585322da33a42497640f420aa49b00ffc596682996371b70e5ff;
   79 sections/140 hunks including additions.
 - Full chain: baseline 315 paths 44c7dee402d46b3e16dc389ae0824b4297dfec1f;
   original 325 paths 648d332b3ba847deb257a2bb1892a76e4c442675;
   S01/A03 327 paths 011f76542a77b2a766a46ac08df102b4de4c09c6;
   F01 327 paths 5c44721183f660032b6468d2c1f5a1d0dc3e6acb;
   current 327 paths 4691af58ae0ee3107b4e2e9b6b1508032944e357.
 - SQL 0008: 30,178 bytes / a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254.
   All SQL 0001–0008, fixture, catalog, controller, writer session, terminal
   contracts/rows/plan/SQLite owner and F01/O1 repairs are immediate-predecessor
   exact, but their original cumulative changes STILL require audit. No 0009.

Nested historical inputs remain available inside A when source predicates or old
findings need comparison; no new attachments are needed:
 inputs/retained-source.zip (F01), 36,160,973 bytes /
 ca1a42d3165809887b4d837232cf9a45ff18e1c643921c5eef7b0a42d2737844;
 inputs/latest-audit.zip, 1,370,071 bytes /
 16b4098f63cbb1fe68d4e7079711565624fe1412aaf28af70413f4d5f8518970.
 Within F01, requirements/ENGAGEMENT_ENVELOPE.txt is 26,064 bytes /
 e158b7c3bb61905ccc2e4c83b8fb59c8b7806ba9b5c5fe21d56a8fd429f088d6;
 inputs/prior-candidate.zip (S01/A03), 25,334,611 bytes /
 f06d97a0becddec07e30676b3988dfcde9d4a79cb6b77a41c23fe4b9d429dd90;
 within that, inputs/original-candidate.zip, 11,648,876 bytes /
 bf26189fd12b2b27fee847e0c0a1808cfeb568c9255bf48bc1f23ff14e728b0e.

E's signal probe is narrower than its predicted suite consequence: it uses two
Popen(start_new_session=True) sleepers; it observes signal 0 and SIGTERM EPERM,
then normal wait/reap and ESRCH. It does NOT exercise SIGKILL or explicit os.fork,
uses sleep rather than a readiness handshake, omits target PID/PGID/SID rows, and
hashes active source after launch. Retain these limits. It did not run the cited
candidate test. Its normal child exits are not successful signal-delivery evidence.
E reports zero candidate imports/SQL/causal/direct/FULL launches. No new independent
candidate credit exists; the former 40/40 runs apply only to Q, not to Qs.

2. SUBSTANTIVE REVIEW — THE EXPLICIT TWO-LAYER AMENDMENT

The earlier whole-operation zero-current-stop-SELECT criterion failed under the
old mandate. That blocked result remains true. The engineering decision is to
preserve mandatory shared storage safety, not to skip it to satisfy a terminal
history test. The current candidate is judged against the following amendment:

Layer 1: existing operational admission remains mandatory. Session/process/thread/
lease validity, database binding/custody, BEGIN IMMEDIATE, exact managed schema,
history/catalog/posture and invariants, writer ownership/fencing, and current
protected disclosure remain intact. The existing global_stop_current singleton
shape validator may read that current row only for managed-store validity.
Valid active/clear status, version, timestamp and directive identifiers must not
be compared with saved terminal stop or turned into current effect permission.
Denied/unreadable/malformed managed state may prevent disclosure or leave recovery
unresolved. It must not be misclassified as stale terminal history or definitely
absent original execution. No cache, successful-assessment stub, invariant-skip
flag, alternate connection/controller, or production validator weakening.

Layer 2: historical checked read, receipt-present replay and recovery use saved
full postimages/stop and checked immutable predecessors after admission/fencing.
The five current-head tables are not consulted during the historical operation.
Current-stop reads are permitted only at the existing shared invariant check,
not as a general table-read exemption or later semantic terminal query. Receipt
is first TERMINAL-FAMILY lookup, not first SQL statement. Exact original result,
time, graph, receipt, source associations, protected disclosure, immutable
acceptance binding, complete competing-winner/absence proof and uncertainty
classifications remain required. Historical operations do not require recording
permission or renewed acceptance-unclaimed eligibility. Fresh receipt-miss
recording retains actual current five-head/stop checks unchanged.

This amends only the overbroad current-stop-query requirement. It is not a waiver
of the constructor defect, five-head independence, disclosure, SQL grammar,
transaction safety, audit isolation, or other cumulative acceptance controls.
Verify the two owning documents state the distinction and preserve the old
failure as history; do not create another silent interpretation of either layer.

Inspect at minimum the complete changed witness module, changed tests and docs,
full terminal contracts/rows/plan/SQLite owner, and actual shared admission call
chain (not only wrapper names). Current anchors:
  sqlite_transition_transaction.py:2759–2779,4753–4773
  sqlite_migration.py:2477–2523
  .docs/rw0-terminal-outcome-physical-closure.md:177–220
  .docs/sqlite-operations-and-recovery.md:722–730.
Python basenames are under source/src/ge_nwp_coordinator/; docs under source/.

2.1 Independently test the repaired constructor and mutable aliasing

TerminalHeadWitness at _rw0_terminal_head_witness.py:48–96 must validate ordinary
construction, not only checked factories. Independently test valid direct/factory
triples for accept and replan and all five typed owner roles (8/9/41/9/8 fields,
valid nulls, self-digests). Exact bytes, outer tuples, dictionaries, keys and
scalar types precede hostile comparison/coercion. Bytes, full rows and compact
coordinates must match rather than silently replacing invalid supplied parts.

Require negative controls for the previous malformed type triple and b'{}'/empty
postimages, bytes/list/tuple/dict/string/int subclasses, bool-as-int, wrong arity,
missing/extra/reordered roles or fields, wrong schema/digest, noncanonical and
oversize bytes, and valid canonical bytes paired with DIFFERENT valid rows or
projections. Calibrate a shared/per-instance hostile equality counter, clear it,
and verify zero hostile calls per invalid construction. Preserve built-in
positives and process-control propagation.

Mutate caller-owned maps and separately returned maps, then re-read both views
and canonical bytes and run normal downstream verification. They must remain
checked and unchanged. No unvalidated object token/factory escape or recursion.
Do not demand security against arbitrary reflection/object.__setattr__; that is
not the selected boundary. Verify unchanged wire fields/schema/digest domains
and valid consumer behavior, including exact original P1 replan operands.

2.2 Independently prove complete-operation phase behavior

Use real private WriterSession read, receipt-present record/replay and recovery,
not just a terminal helper. Trace and attach observation/denial at the actual
acquisition/controller opener aliases and account for every operation connection.
The candidate observer labels the full managed wrapper; independently establish
which SQL is genuinely in _verify_global_stop_current_shape. A phase label alone
does not prove shape-only use or permit arbitrary managed-phase stop semantics.

Observe real unchanged validator, ownership-read and issuance/fencing functions;
observation wrappers must call the real function and return its actual result.
Do not replace admission with a successful assessment or patch the predicate
being proved. Capture connection, phase, table/column and allow/deny results.
Calibrate each attached authorizer with owned allowed and intentionally denied
queries. Trace acquisition separately, including any connection work before the
observer attachment, and prove it cannot hide a five-head/later-stop lookup.
A zero-callback claim at the wrong alias is invalid. Column callback counts are
not SQL-statement counts or a fixed product invariant.

Required current-byte controls:
- real fenced accept and replan commits, then coherent later movement of every
  head and valid active/clear stop fixtures; under the layered denial policy,
  exact read/replay/recovery preserve original result/time/witness/graph/receipt
  and acceptance facts without new terminal or protected-row movement;
- original absence with positive/negative old-execution exclusion; complete
  compatible and incompatible competing winners under that same policy;
- deny the ACTUAL managed-stop read during admission: safe operational refusal
  before protected terminal-family handling, recovery unresolved where the
  unchanged controller so classifies; no no-write mislabel as stale history,
  definite absence, hidden retry, committed result or protected disclosure;
- malformed actual stop row or real query-return tuple, with validators intact:
  integrity failure rather than ordinary currentness; fault removal restores
  valid operation; bound process-control behavior remains unchanged;
- fresh receipt miss reads all five actual heads and stop. Stale expectations
  conflict without writes; correctly expected valid changed stop follows the
  current normal-record rule without conferring executable permission;
- denied/expired/foreign/malformed disclosure, closed/stale/fenced session and
  unavailable managed store remain non-disclosing. Fresh recording permission
  stays separate from historical protected disclosure and stop shape.

All synthetic later states/fault seams must be described as such. Do not call
a direct fixture UPDATE a newly supported product operator transition.

3. COMPLETE CUMULATIVE A01–A18 REGISTER AND CAUSAL OBLIGATIONS

Review the entire baseline-to-current terminal change, not only the five-file
repair. Supply exact archive-relative source/doc/test/SQL coordinates, severity,
and evidence class for every row: contract/current code, inspected test design,
retained record, independent execution, inference or limit. Unchanged bytes and
prior passes do not automatically discharge current mandatory controls.

A01 Authority: exactly five private normal terminal facts, separate from P1
 decision/acceptance, standing-policy grants, source facts and executable
 permission. No cancel closure, live supplier/contact, ES/Bridge/Git effect,
 service/scheduler/autonomy or publication authority.
A02 Preservation: legacy terminal V1/four validators, P0/P1 meaning, WorkSpec,
 Decision Basis/command-digest v2, preassignments, D1/D2, generic receipt, public
 StateStore/package exports unchanged. Audit original shared catalog/controller/
 writer-session terminal integration even though this immediate repair froze it.
A03 Grammar/types: closed command/context/outcome/row/result/recovery/witness
 schemas, exact built-ins before equality, canonical UTF-8/JSON and duplicate
 rejection, bool-as-int, safe refs/digests/calendar time, budgets and null pairs.
 Include direct constructors, factory consistency and aliasing; resolve A03/O1.
A04 Identity graph: independent domains/acyclic preimages, four sibling refs and
 route, optional assertions bound in command digest but not preassignments,
 graph role/cardinality/order, self-digest exclusion and repeated-column equality.
A05 Original operands: original P1 command and private replan operand transient;
 complete checked predecessor association required. Missing/inconsistent private
 content cannot be reconstructed from a safe digest or yield false certainty.
A06 Source association: actual checked P0/phase/Section41 A/C1 rank15/V22/P1
 chain and validation/review/proposal/result-set/observation relationships;
 membership counts or digest strings do not independently establish ownership.
A07 Acceptance: bind existing immutable acceptance only for accept; never create,
 mutate or replenish it. Wrong/missing/foreign facts reject. Legitimate unrelated
 facts must coexist without preventing another allowed terminal branch. No
 historical acceptance-unclaimed recheck.
A08 Heads/stop: observed full five-row witness, source/adapters/digests/links,
 replan historical P1 postimages, fresh actual currentness and stop facts; prove
 the precise two-layer amendment, not the withdrawn zero-stop-read property.
A09 Transaction: existing fenced lease/capability/controller; receipt-first
 terminal lookup; one captured time; protected posture/source/current/route
 ordering; context/outcome/result readback, receipt last, capability invalidation,
 one commit attempt, rollback/cleanup uncertainty. No application-head/stop/
 decision/effect update by terminal closure.
A10 Read/replay: original complete result/time/graph/receipt and source/witness
 reauthentication; current protected disclosure with mandatory store admission;
 no five-current-head or later semantic stop query, cognition/process rerun,
 fresh recording permission or acceptance-eligibility requirement.
A11 Recovery: complete exact original family or exhaustive original absence and
 exclusion, or complete compatible winner, only. Partial/foreign/damaged/aliased/
 incompatible families unresolved. No winner result disclosure, hidden retry,
 fragment repair or durable private-template fallback.
A12 Error/cleanup: failed or malformed reads stay operational/integrity, valid
 actual drift stays currentness. Stale/closed/fenced sessions, pre/postcommit,
 applied-commit/lost-return and cleanup uncertainty, KeyboardInterrupt/SystemExit/
 GeneratorExit propagation at the actual fresh/read/recovery/cleanup seams.
A13 Schema/admin: four STRICT immutable normal-only tables/eight guards;
 timestamp grammar, FK/unique/composite links/phase/decision/route occupancy,
 nullable pairs, blob bounds, zero seeds, current catalog/checksum/generation 2;
 exact fresh/prefix migration and old-binary/obsolete-0008/partial/unknown refusal.
A14 Connected normals: actual preseal source variations through real P0/D1/D2/
 Section41/C1/V22/P1/terminal owners; five distinct normal positives and detached
 negative; read/replay/recovery and no forbidden contact or protected-row change.
A15 Docs/assurance: cumulative current-versus-historical status, explicit amendment
 and private scope; fixed source/hash/AST/import/schema consumers and predecessor
 reconstruction retained; no dynamic oracle, skip/xfail or broad guard stripping.
A16 Privacy/artifacts: complete postimages remain safe owner metadata; no private
 replan text, raw capsule/prompts/process results, handles/PIDs/credentials in
 terminal rows or unsafe errors. Grammar review plus independently observed
 canaries; classify raw-index metadata, checkpoints and failed artifacts.
A17 Retained evidence: exact input/source/patch/commands/env/observer outputs/
 JUnit/IDs/warnings/captures and overlapping counts; limits in section 4 below.
 No writer record or causal-register label is independent execution.
A18 Independent validation: reached current-source causal probes and direct
 suite, independent SQL/admin controls, selector-free collection/FULL completed
 with exact IDs, outcomes, warnings and source-mode preservation. No live-state
 or production-readiness inference.

The following controls remain mandatory, including previously unfinished ones:

(a) S01 full-witness family: for EACH role, check complete field capture, valid
 nullable values, supported maximum witness bound, bad owner self-digest, valid
 self-digest with wrong immutable predecessor, wrong owner/link, and actual fresh
 head movement versus changed caller expectations. Use fully resealed synthetic
 histories so owner/context/outcome/result/graph/receipt digests are internally
 valid and the real relationship predicate is reached. Pair every resealer with
 a valid family built the same way. Restore ordinary verification for the actual
 read/replay/recovery. Prior program-only evidence is not five-role proof.
 No truncated witness, v1 fallback, desired-row synthesis or current-row backfill.

(b) Source/operand/acceptance: fully resealed detached validation, review,
 source-invocation and proposal associations, including a DISTINCT forged V22
 proposal reference rather than only a proposal digest; wrong/missing/foreign
 acceptance; LEGITIMATE unrelated acceptance-fact coexistence; inconsistent
 private replan content sharing a claimed safe identity across record/read/
 replay/recovery; no new process or private-text persistence. The single-chain
 fixture's inability to construct an unrelated fact is not proof of impossibility.
 Build coherent independent synthetic state through checked owners, or document
 exact invariant proof and the remaining limitation. Do not credit an incoherent
 split-reader or early FK/digest failure as the intended relationship test.

(c) Disclosure/recording: all selected finite posture predicates, including
 positive, denied, expired, malformed, foreign-bound and absent protected subject;
 old-execution-excluded True/False; truthful claimed False/None after accepted
 P1. Fresh write needs recording AND disclosure, historical operations disclosure
 only; command reuse/assertion mismatch cannot disclose a protected result.
 Complete the expired/malformed/foreign/protected-absence matrix rather than
 inheriting earlier positive/negative permission examples.

(d) Physical routes: derive all original occupancy routes from the checked
 code (the preceding audit identified 17). Seed EACH route physically in a
 separate owned coherent scenario, with valid positives and relevant partial,
 foreign or damaged family states. Mocking query return values alone is not
 physical occupancy evidence. Check exact/winner/absence classifications and
 no winner disclosure or retry. If a route is not representable under an owner
 invariant, prove that with exact schema/contract and record the scope; do not
 invent an invalid row as a legitimate winner or silently drop the obligation.

(e) Transaction and error matrix: faults after each of the four inserts,
 result/receipt readback, receipt-last boundaries, precommit rejection,
 one applied commit with lost return, postcommit and recovery cleanup uncertainty;
 stale lease/issuance, closed and fenced sessions; actual denied SELECT versus
 malformed selected rows across current owners; all three process-control
 exceptions at meaningful fresh/read/recovery/cleanup seams. Assert target
 rows, committed bytes, protected-state nonmovement, and actual injection hits.
 No hidden second commit or automatic retry.

(f) F01/O1 regression: independently exercise raw SQL and row construction,
 not only planner success. Use otherwise valid parent/related state, paired
 valid inserts, independent negative self-digests and the repaired existing
 _time owner. Cover invalid month/day/leap-century/year-zero/time overflow,
 canonical-format deviations, Unicode digits, embedded NUL/whitespace/nontext,
 NULL handling and valid year endpoints. Reach all three recorded_at columns;
 outcome has no timestamp. Verify failed predicates are zero/not permissive
 NULL and high-level invalid row/time behavior stays integrity/unresolved.
 Reproduce the old invalid-month predicate only in owned predecessor synthetic
 state as a grammar comparison, never claim an ordinary writer exploit.
 Recalibrate O1 independently before claiming no hostile equality calls.

(g) Five connected normals plus three unsupported cancel shapes and unsupported
 profile. Source variations occur BEFORE real artificial worker/checker/capsule
 sealing, not by relabelling passed evidence afterward. Use inspected fixtures
 for setup only; independent expected branches/facts/errors are required.
 Observe artificial local process/contact limits and privacy canaries.

Run bounded causal controls before a long FULL launch. Do not start/continue
FULL while a known material blocker already prevents acceptance. Independent
controls must state setup validity, actual reached seam, expected result/no-write
predicate, source identity and limits. Candidate tests passing are not separate
independent oracles. Any mandatory control not established remains explicit and
prevents complete acceptance unless an exact supported invariant makes the case
inapplicable; fixture difficulty alone is not such an invariant.

Independent SQL/admin expectations:
  after 0006: 68 tables / 122 triggers / 5 explicit indexes
  after 0007: 74 / 134 / 5
  after 0008: 78 / 142 / 5, application generation 2.
Execute all eight authenticated literals in disposable owned state. Preserve
pre-0008 object SQL/shape; check exact prefix upgrades, no seeds, immutable
update/delete guards, FK/unique/pair/profile/normal/blob/time constraints, and
refusal of old binary, original and S01-era 0008 checksums, old SQL with current
history, missing guard, foreign object and partial/unknown/checksum divergence.
No current schema/contract change, 0009 or product database upgrade is allowed.

4. RETAINED EVIDENCE AND INDEPENDENT VALIDATION

4.1 Reconcile the current writer records as DATA

Paths: evidence/validation/<direct|connected|focused|full>/, gate-summary.json,
phase-read-map.json, supersession-record.json and current source captures.
Require independent parsing of collection observer, execution collection,
setup/call/teardown records, explicit JUnit nodeid properties, actual launch/exit,
stdout/stderr as actually retained, warnings, and four complete source captures
per gate. Do not invent a separate stderr file for a combined log.

Expected current retained gates:
  direct: five complete modules / 60 cases / zero warnings
  connected: one complete module / six cases / zero warnings, inside direct
  focused: 126 complete modules / 8,266 cases / three known warnings
  FULL: selector-free / 9,568 cases / three known warnings.
All narrower sets must be included in FULL; totals overlap and do not add.

Ordered-ID SHA-256 uses UTF-8 JSON array, ensure_ascii=False,
separators=(',', ':'), with NO trailing LF:
 direct 229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467
 connected 81e14e3fa1b85a7be2ea6fafac85974839145bbcb6397e6da0bb1feeba060aac
 focused 419d37ff399689788123583f614a1d8b107ef712e2368ca179cd6e65fbec5104
 FULL 25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9.

All sixteen source captures have the same 105,550-byte envelope, SHA-256
0c0b4017371a798731a63825ac63922c361189e37f5a713f5c4f7ec06e9b32cb.
Require full row equality to the different canonical source-manifest envelope,
its embedded canonical hash, correct final tree and no extra/missing paths.

The retained direct JUnit phase maps report six operation connections, 60
managed-stop column callbacks and six intentional head-denial calibrations
for EACH accept/replan scenario. Independently parse the raw properties. Do not
substitute those counts for actual phase/call-chain verification, or label them
SQL-statement counts. Acquisition has separate test observations.

4.2 Known retained-evidence limits — do not silently fill them

The active external gate_observer source and a launch-bound helper digest are
not retained in the current outer ZIP. Old nested helpers cannot prove that
current code's identity. Writer records can be internally reconciled but their
observer's nonselecting implementation is not thereby inspected. The independent
runs below must use newly audit-authored, retained, inspected and calibrated
observers. Independent fresh evidence can establish current behavior; it does
not retroactively establish the missing writer helper.

The seven-case checkpoint has receipt/JUnit evidence and a different declared
tree 85c9fea24f4f74f358f9cc59a5d323d836a04041; it lacks a complete checkpoint
source payload here. Its historical save/reopen/source-binding claim stays
qualified and supplies no final-byte credit. Similarly, one retained patch
manifest per kind is not proof of two writer runs; independently reconstruct
current endpoint/patch identity rather than invent that history.

These are disclosed retained-evidence/process limits, not automatic production
findings. Determine their actual acceptance impact. Complete current independent
source/runtime evidence must not be replaced with writer claims. Any unmet
mandatory evidence requirement is INCOMPLETE, not a pass by wording change.
Preserve failed/superseded source/test results separately. The prior audit's
live-status/path probes and interrupted FULL remain historical limits.

4.3 Required independent execution gates

After source review, new constructor/two-layer controls, the complete cumulative
finite causal matrix and SQL/admin controls reveal no material blocker:

1. On a fresh exact source copy, collect and run these five COMPLETE modules in
   this order (no node selector):
   tests/test_rw0_terminal_outcome_values.py
   tests/test_rw0_terminal_head_witness_regression.py
   tests/test_sqlite_rw0_terminal_controls.py
   tests/test_sqlite_rw0_terminal_migration_0008.py
   tests/test_sqlite_rw0_terminal_connected.py
   Expected 60 ordered unique passes, including six connected cases.
2. On another fresh exact 327-file copy, independently collect and run the
   repository selector-free FULL. Expected 9,568 ordered unique IDs and passes
   in the retained FULL order. No path, module, node, -k or -m selection.
3. Record collection/execution-collected/call/JUnit identities, explicit JUnit
   nodeid properties from the start, all setup/call/teardown results, warnings
   and real process exits. Require exact ordered agreement and zero failure,
   error, skip, xfail/xpass or failed noncall phase. An invertible JUnit mapping
   is useful supplementary evidence, not a silent substitute for the required
   explicit-property observation.
4. Independently inventory warnings. Direct has none; FULL may have only the
   three known DeprecationWarning multithreaded-fork nodes in
   tests/test_sqlite_b2c_writer_session.py:
   test_operation_guard_close_waits_and_retains_authority_until_exit
   test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
   test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock.
   Owned paths/PIDs may differ; other class/node/message differences require
   investigation, not filtering or suppression.
5. Capture complete raw bytes/modes/extra-file inventory immediately before and
   after collection AND before and after execution, with source-tree rebuilds.
   All 327 endpoints and modes must remain unchanged, without generated extras.
6. Audit probes remain outside candidate discovery and separately counted. An
   independent focused 8,266-case rerun is unnecessary if exact FULL inclusion
   is proven; do not claim one ran. No writer FULL or earlier audit count can
   replace the independent completed FULL.

Use recorded equivalents of:
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --collect-only --basetemp=<owned-collect> <complete-direct-modules>
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --basetemp=<owned-run> --junitxml=<owned-junit> <same-direct-modules>
For FULL remove all module/path/node selectors from BOTH commands. Inspect
pytest config, conftest and setup/child-launch seams before import. The observer
may record IDs/outcomes/warnings and add JUnit nodeid properties, but must not
select, reorder, skip, change assertions/results or suppress warnings. Keep its
exact source/digest in the evidence and bind every launch to it.

Do not edit candidate source/tests to get green results. Correct audit-only
parser/fixture/observer mistakes transparently on fresh owned state, retaining
failed attempts. A genuine candidate failure triggers findings, not retries with
weakened oracles. An interrupted FULL gets no complete-pass credit; preserve
actual partial records and absence of final JUnit/observer rather than infer
completion from displayed percentages.

5. ONE SCOPED SIGNAL POLICY, COMPLETE READINESS, THEN CANDIDATE AUDIT

5.1 Static dependency map and owned layout

Before candidate import, finish the bounded authenticated source scan for fork,
exec, subprocess, PID/group signals, sessions, timeout cleanup and file dependencies.
Do not reconstruct a new architecture or edit any test to fit the boundary. Known
signal call sites, under A source/:
 src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py:123–142,208–222,255–299
 tests/test_b3c2_transition_event_readers.py:501–519,605–641
 tests/test_rw0_d1_offline_integration.py:303–320
 tests/test_sqlite_b2c_writer_session.py:219–237
 tests/test_sqlite_writer_hot_journal_recovery.py:82–99
 tests/test_state_authority_lock.py:528–542,618–624.
The D2 integration test additionally asserts start_new_session; do not label that
an independently exercised signal. Map source-required vs contingency cleanup,
actual required signal numbers and target relationships. No runtime credit from a
lexical scan. Record a genuinely different required operation as a boundary limit;
no policy class beyond the one selected rule is authorized.

Use ONE fresh unique audit namespace under the unchanged root:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz
 execution/<id>/ for newly authored/frozen policy/bootstrap/observer/probes;
 mock_source/<id>/{master,causal,direct,full,predecessor} for exact source copies;
 scratch/<id>/, home/<id>/, tmp/<id>/ for writable synthetic state and provisional output;
 evidence/<id>/ for supervisor captures/input verification/final evidence;
 denied/<id>/ for synthetic noncontent-access controls.
Preserve all earlier namespaces and sources, including audit-4de1ae8e82. Do not
rebind Q's paths. Verify Qs is exactly Q plus the selected final line. Record the
textual delta and both identities. Source, observer, policy, controls and protected
final evidence never reside in candidate-writable directories.

Runtime remains Python 3.13.4 / pytest 8.4.1 / SQLite 3.49.1 on the installed Mac.
Use /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 as requested
entry. Distinguish requested symlink, resolved wrapper and framework image; preserve
process-local __CF_USER_TEXT_ENCODING treatment. Recheck installed metadata narrowly,
not candidate imports, broad discovery or environment dumps. No native-entry
shortcut, install, runtime replacement, app/OS-setting change or outer bypass.

New helpers must retain actual argv/cwd/allowlisted environment, umask 077, C/UTC,
-B, owned HOME/TMP, zero core limit, null stdin, close_fds=True, empty incidental
pass_fds, wall/monotonic bounds, PIDs/groups/sessions, pre/post source/policy/runtime
identities, raw outputs and distinct supervisor/target results. Control pipes
created deliberately inside the synthetic process tree are allowed and recorded;
no privileged peer or unrelated descriptor is inherited by a contained process.
No shell=True, arbitrary process discovery, existing host service or user content.

5.2 New signal positive and exclusion controls — synthetic only

Run trusted preparation, external supervisory watchdogs and disposable nonmember
fixtures under existing host/tool protections, outside the ADDITIONAL inner policy.
They execute only newly authored synthetic code or data-only input/evidence work,
never candidate imports/SQL/tests/callbacks. This limited supervisor scope is not an
unconfined candidate alternative. Never signal a real unrelated process, the app,
the auditor process, or an untracked PID/group; use disposable, positively owned
fixtures for every target and negative. No broad kill(-1,...) or unowned group.

First establish restrictive true and the fixed Python marker under Qs. Then author
an independent synchronous readiness protocol for all signal subjects. Each target
must report nonce, PID/PPID/PGID/SID, executable identity and signal-handler setup
through a bounded pipe before its targeting phase. No fixed sleep as the liveness
oracle. Keep it alive awaiting explicit release; retain evidence of live-before,
call, delivery-or-denial, live-after/exit, actual wait status, reaping and descriptor
closure. Acquire and revalidate targets by owned handles/handshake, not discovered
or stale numeric PIDs. Bound all waits; arm an external emergency supervisor that
can clean up only its tracked synthetic workload. Emergency cleanup is not a
positive target-operation result.

Positive signal matrix on Qs:
 - Signal 0 to a live in-workload direct child must succeed; SIGTERM must actually
   terminate/reap a default-handler target or demonstrably reach a declared handler.
 - A distinct child installs SIGTERM ignore, acknowledges readiness, and remains
   blocked on an owned pipe. Send TERM, establish it remains live, then SIGKILL;
   observe signal-9 wait status and reap before releasing the blocking pipe. This
   independently matches the meaningful B3C2 seam, not a call to its test/helper.
 - Repeat relevant behavior for fork, exec and fork-then-exec targets using the
   requested and actual sys.executable forms. Use real operations; no monkeypatch.
 - Exercise a coherent new-session/process-group fixture and real killpg(PGID,0),
   SIGTERM and SIGKILL with owned members. Include a member deeper than an immediate
   child and the cross-session group-target relationship used by D1. Use proper
   parents to reap their children and retain that ownership chain; do not claim
   waitpid of a nonchild or all-descendant isolation from group disappearance alone.
 - After positive reaping/group closure, a tightly timed stale-target check may
   observe ESRCH as cleanup evidence, not successful delivery. Avoid PID-reuse
   assumptions and stop if identity can no longer be safely attributed.
 - Self/within-cohort signaling is allowed by the selected target class; demonstrate
   harmless self signal-0 and any additional source-required self behavior only
   in a sacrificial owned process. Do not misdescribe the rule as child-only.

Negative signal matrix:
 - The trusted supervisor creates a fresh live same-user sentinel with NO Qs inner
   policy, in an owned isolated session/group. The contained sender attempts only
   its precisely supplied PID/group. Require EPERM/EACCES for signal 0, TERM and KILL
   and confirm the sentinel remains responsive/alive after each denied attempt.
   An absent/dead target, ESRCH, failed creation or unsupported API is not exclusion.
 - Use a separate disposable same-user cohort independently launched with identical
   Qs bytes. Do not ASSUME an independent application has a different sandbox identity.
   Observe PID and group targeting from the first cohort. The required cross-workload
   exclusion must hold; if independent cohorts can signal one another, stop before
   candidate execution with that actual scope. Do not silently redefine them as
   acceptable members or attempt a unique-policy marker/new rule workaround here.
 - Include nonmember exclusion from a descendant sender after exec/fork inheritance,
   not only the initial parent. Outside sentinels report fresh nonces before/after;
   use benign SIGTERM handling and separate sacrificial KILL specimens. An unexpected
   success is a boundary finding; clean up only owned processes and stop.
 - Validate the ordinary outside-inner-policy signaling relationship with a SEPARATE
   owned positive, so a Unix credential/handler/target setup problem cannot masquerade
   as sandbox exclusion. No escalation and no true host target is used for that test.

Record actual known UID relationship without enumerating other processes. Run no
unrelated same-user process scan to select sentinels. Freeze the finite signal
case inventory and expected outcomes before launch. A parser/compiler error or
positive/exclusion failure of Qs is INCOMPLETE; there is no authorized fallback
(target children, broad allow signal, different profile, outer policy bypass,
unconfined test or external signal-proxy). Ordinary defects in newly authored
synthetic code may be corrected and rerun on fresh state, retaining failed source
and results. Do not call a permission mismatch a helper bug to evade the stop.

5.3 Recalibrate every original boundary control under Qs

Signals are an additional tested capability, not a replacement for filesystem or
network confinement. After the signal gate, rerun the original 40-control inventory
per parent/fork/exec/fork-then-exec on ONE frozen Qs with fresh synthetic state. Do
not borrow Q's 40/40 totals. Reuse understood designs as new inspected code, not
archived execution. Keep active helper/observer/policy identity binding complete.

Required controls:
 - true and fixed -I -B Python marker, correct version and actual sys.executable;
 - standard-library SQLite create/transaction/readback/removal on owned state;
 - distinct parent/fork/exec/fork-then-exec markers and all owned children reaped;
 - allowed source/launcher reads, scratch create/read/update/remove;
 - source/launcher/evidence/denied append/truncate/replace/delete/create refusals,
   denied evidence/denied content reads, canonical and owned symlink alias forms,
   allowed ancestor metadata separately from content access;
 - ordinary outside-inner-policy accessibility of synthetic sentinels first, correct
   OS modes, pre/post bytes/modes/alias targets; only EPERM/EACCES denial credit;
 - actual contained bind and connect calls in every role against the SAME owned
   live 127.0.0.1 ephemeral listener, with successful nonce connect/accept handshakes
   before/after under unchanged outer protections and explicit socket closure.
   The listening descriptor is noninheritable, never passed into contained targets.
   No SO_ACCEPTCONN dependency, absent-peer fallback, real service, DNS or external host.

Policy review remains required in addition to control totals. Disclose retained
literal-root-directory-entry and installed-runtime read breadth. Candidate source
and trusted evidence stay unwritable; outside target signaling stays denied.
The external supervisor provides emergency containment only. It must NOT perform
candidate-required signal/reap behavior or transform candidate failures into passes.
Close peers and synthetic signal sentinels before candidate execution. Preserve
this new readiness evidence without rewriting Q or E verdicts.

Complete compatibility inspection of candidate setup, subprocess/cleanup and import
paths before running it. If Qs is still incompatible with a DIFFERENT required
operation, stop with the exact gap; no additional permission class is authorized.
Once signals and all original controls pass, CONTINUE DIRECTLY to the cumulative
source/causal/SQL/direct/FULL work below in this engagement. Do not return solely
with a new qualification verdict or ask for another routine handoff.

5.4 Candidate launch and evidence binding AFTER Qs qualification

All candidate work, including collection/import, historical comparison code and
literal SQL execution, goes through:
 /usr/bin/sandbox-exec -f <exact-Qs-policy> <fixed-python> <recorded-args>
with explicit owned cwd, umask 077, null stdin, close_fds=True, empty pass_fds,
owned HOME/TMPDIR/basetemp/output, C locale, UTC, zero core limit and allowlisted
credential-free environment. Preserve process-local treatment of the framework
text-encoding hint; no host settings change. Use -B, PYTHONDONTWRITEBYTECODE=1,
PYTHONNOUSERSITE=1, PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, empty PYTEST_ADDOPTS,
-p no:cacheprovider, no unrecorded selector, no warning suppression.

The freshly Qs-qualified marker used -I; that alone does not set the candidate import graph.
For the audit use a newly authored, inspected -I -B bootstrap in execution/<id>/
that adds ONLY the authenticated source root, its src/ directory, and the frozen
read-only observer directory to sys.path, sets the explicit pytest argv, and calls
pytest without altering selection or outcomes. The controlled source mapping must
match pyproject's src path. For candidate-owned children that launch without -I,
any PYTHONPATH is frozen to those same authenticated source/setup roots only, with
no ambient directory. Do not rewrite candidate code to add isolation, disable
checks, fix imports or change semantics. Record bootstrap/source/helper identity,
real argv and environment at every boundary. This import-binding adaptation does
not alter filesystem/network policy; exercise it during contained readiness and
observer calibration before candidate collection.

The independently authored observer may record ordered collection, execution
collection, setup/call/teardown, warnings and explicit JUnit nodeid properties only.
Calibrate on separate synthetic tests before candidate collection; retain its full
source and launch-bound digest. It must not select, reorder, skip, weaken assertions,
transform failures, or suppress warnings. Keep audit probes outside source pytest
discovery. Counts and exact inventories in section 4.3 remain mandatory.

Source/observer code is policy-read-only. Candidate-produced observer/JUnit files
must be written to a fresh scratch output directory, NOT protected evidence.
The trusted external supervisor captures raw stdout/stderr directly to protected
evidence, records exits, and after all tracked children close hashes and copies
those output files into evidence. Never treat writable scratch output as protected
before that transfer. The observer runs in the test process; it is observed test
instrumentation, not a separate adversarial attestation authority. Independent
oracles, source review and protected supervisor records remain necessary.

Bind every launch to pre/post hashes of Qs policy, supervisor/bootstrap/observer/probe,
requested interpreter/wrapper/native executable, exact source manifest/tree,
argv/cwd/env, wall and monotonic times, PIDs/process groups, timeout, raw stdout/
stderr, signal/exit and all actual outcomes. Supervisor exit 0 is never sufficient.
Freeze a documented timeout appropriate to the FULL workload, not the synthetic
matrix's 55-second limit. Do not impose an arbitrary short deadline then infer a
candidate failure. An interrupted or externally stopped FULL is incomplete.

Track/reap owned children and record process closure before artifact transfer and
source after-capture. External termination is permitted only for PIDs/groups
created and tracked by this audit. Do not claim a process-group-empty observation
is a theorem about every possible escaped descendant. Preserve the supported-local
process assumptions and existing inherited observations. If child containment or
closure cannot be established for a required control, report that precise limit.

Capture full source bytes, numeric modes and extra-file inventories immediately
before/after collection and execution, reconstructing the exact tree each time.
Never put raw source private content, runtime databases/sidecars, credentials or
unclassified logs in delivery evidence. Synthetic SQL corruption and fault injection
are permitted only within the finite defensive matrix; no host crash, product DB,
live grant, real runtime contact or product effect.

No source/edit/format/stage/commit/push/PR/merge/branch/config/ref action, installation,
repository cleanup, remote provisioning, release/deployment or product effect.
After evidence retention remove only newly created audit-owned transient state;
preserve all qualification roots and authoritative inputs. Do not make the user
assemble more prompt fragments between source review, causal controls and FULL.

6. FINDINGS, ACCEPTANCE AND DELIVERY

Return one primary verdict:
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED
 AUDIT_PROVENANCE_MISMATCH
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE

Acceptance requires authenticated exact current bytes, compliant effect scope,
the new Qs signal/exclusion AND full original containment gates,
all substantive A01–A18 obligations, independently validated amended historical
admission/direct-constructor/F01/O1/S01 relations, the completed required causal
matrix, SQL/admin checks and independent direct/selector-free FULL. Classify any
remaining low observation/evidence limit with rationale; do not relabel a missing
mandatory check as a nonblocking observation to obtain acceptance.

Findings must identify severity/type, owner contract, current source path:line,
actual observation/reached predicate, impact, counterexample/positive pairing,
uncertainty, and whether candidate, pre-existing, report-only, or process-only.
Differentiate historical requirement amendment from implementation repair and
from independent runtime evidence. Do not claim an unsafe fresh commit unless
ordinary fresh writing actually demonstrated one.

The older F01 audit's 51 direct cases, 9,559-ID collection and interrupted
FULL remain predecessor evidence; the old zero-stop-read requirement remains
failed and superseded only as an acceptance criterion. Prior process deviations
are not inherited into this fresh engagement if it complies, but are not erased.
F03/F05 remain inherited nonblocking observations, not repaired findings.
E's new-policy compatibility stop remains INCOMPLETE and has zero candidate
execution credit. Qs readiness does not retroactively qualify Q for signals.

Return a complete inline report and save a uniquely named standalone full report
BEFORE sealing one safe evidence ZIP. Include the report byte-for-byte in the
ZIP and a self-excluding member manifest; reopen all members and record exact
ZIP/report/manifest sizes and hashes in the final response and adjacent receipt.
Do not make an outer ZIP self-hash a member obligation. Retain audit-authored
scripts/observer/policy, input and endpoint verification, source/patch checks,
A01–A18 register, actual causal/SQL results, invocations/exits/logs/JUnit/IDs/
warnings, source captures, process mistakes/withdrawn claims, unperformed scope,
and cleanup/non-effects. Exclude databases/sidecars, bytecode, credentials,
unclassified binary state and private product/capsule/template contents.

Final acceptance, if earned, is only for tree
4691af58ae0ee3107b4e2e9b6b1508032944e357 and supplies eligibility for a separate
live exact-byte commit gate. It authorizes no mutation, staging, commit, push,
PR, merge, publication, release, deployment or product effect. Return to ChatGPT;
do not initiate a repair or publication gate in this audit conversation.
