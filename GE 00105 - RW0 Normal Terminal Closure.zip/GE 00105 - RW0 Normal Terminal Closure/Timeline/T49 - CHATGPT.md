## Engineering disposition

**The archive authenticates. The Python failure is now tied to a concrete pathname-resolution problem: the restrictive policy permits the runtime subtree but omits metadata access to its parent directories. One finite, batched correction is justified before abandoning this approach.**

The environment remains **unqualified**. The candidate remains unchanged and unaccepted. The next mandate explicitly authorizes the new correction; it does not silently extend the exhausted two-change allowance.

## Authenticated evidence

| Item | Verified result |
|---|---|
| Archive size | **168,921 bytes** |
| SHA-256 | `4a4dde0c6ef81d8ddcbeeb65c06cf7a0a5739d57b0b1eeae341b210b64bd92cb` |
| Inventory | **197 regular files; 196 verified self-excluding manifest rows** |
| Expanded size | 410,742 bytes |
| Embedded report | 11,052 bytes; matches the reported identity |

Every manifest-covered payload passed size, CRC/readability, SHA-256, and numeric-mode checks. Names passed path, uniqueness, type, encryption, and prefix-collision checks. All **36 copied historical payloads** match their counterparts in the previously authenticated archive. The uploaded ZIP remained unchanged.

:chatgpt-content-reference{index="3"}[Detailed receiving inspection](sandbox:/mnt/data/Coordinator_RW0_Audit_Qualification_EK73VTKC_Receiving_Review.md)

## What the evidence establishes

### The diagnostic repair succeeded in its bounded scope

The corrected queries use explicit UTC bounds that independently round-trip to their recorded epoch values. The synthetic logger marker was retrieved with its exact nonce, PID, executable, and bounded timestamp.

The reporter-side queries also recovered the two earlier denials:

```text
Sandbox: true(3563) deny(1) file-read-data /
Sandbox: true(3651) deny(1) file-read-data /
```

Those events fall within the authorized padded intervals. The kernel’s emitting PID is correctly distinguished from the affected child PID. This supplies information that the old subject-PID-only empty results missed; it does **not** make log retrieval exhaustive. Coordinator_RW0_Audit_Qualification_EK73VTKC_Receiving_Review\.md[Diagnostic reconciliation](sandbox:/mnt/data/Coordinator_RW0_Audit_Qualification_EK73VTKC_Receiving_Review.md)

The first policy correction added only:

```text
(allow file-read-data (literal "/"))
```

Restrictive `true` subsequently passed. That supports the correction’s relevance in the tested configuration—not a claim that it explains every historical abort.

### Python’s error is specific, not merely “exit 1”

Both restrictive Python attempts retained exactly this stderr:

```text
python3: realpath: /Library/Frameworks/Python.framework/Versions/3.13/bin/: Operation not permitted
```

The associated diagnostics distinguish the two attempts:

| Policy | Relevant observed metadata denial | Python result |
|---|---|---|
| v2 | `/` | Exit 1 before marker |
| v3, after allowing root metadata | **`/Library`** | Same error; no marker |

The final `/Library` denial is recorded inside the Python child’s actual execution interval:

```text
evidence/python_final_failure_reporter_stdout.bin:4
```

The policy grants access below:

```text
/Library/Frameworks/Python.framework/Versions/3.13
```

but does not grant metadata access to its strict ancestors outside that subtree. That gives us a specific missing dependency class rather than another arbitrary permission guess. Coordinator_RW0_Audit_Qualification_EK73VTKC_Receiving_Review\.md[Policy and failure analysis](sandbox:/mnt/data/Coordinator_RW0_Audit_Qualification_EK73VTKC_Receiving_Review.md)

Separate primary-source corroboration: CPython 3.13.4’s macOS framework launcher calls `realpath` on its executable directory and emits this exit-1 error on failure, before launching the framework interpreter. This matches the records; it is **not binary-to-source authentication of the installed executable**. [GitHub](https://raw.githubusercontent.com/python/cpython/v3.13.4/Mac/Tools/pythonw.c)

The logs also contain `/etc` metadata and named Mach-lookup denials. **Their presence does not establish that those permissions are necessary or appropriate.** The selected correction does not grant them.

### All six launch records reconcile—but none qualifies containment

The raw child and supervisor outputs, hashes, PIDs, environments, timings, and pre/post identity records reconcile:

| Launch | Supervisor exit | Child exit |
|---|---:|---:|
| Plain `true` | 0 | 0 |
| Diagnostic-only policy + `true` | 0 | 0 |
| Restrictive v2 + `true` | 0 | 0 |
| Restrictive v2 + Python marker | 0 | 1 |
| Restrictive v3 + `true` | 0 | 0 |
| Restrictive v3 + Python marker | 0 | 1 |

The supplied helper, policy, and marker hashes also match their archived source bytes. Host executable identities remain retained observations because their binary payloads are not supplied.

No contained Python marker, SQLite, fork/exec, filesystem, alias, or network matrix passed. Unchanged sentinels after these launches provide no denial credit. Coordinator_RW0_Audit_Qualification_EK73VTKC_Receiving_Verification.json[Verified launch records](sandbox:/mnt/data/Coordinator_RW0_Audit_Qualification_EK73VTKC_Receiving_Verification.json)

## Selected correction: complete the ancestor metadata set once

**Do not proceed one directory component per handoff.** The next assignment freezes the complete finite set of parent directories for the runtime paths already permitted by the policy, then adds only literal metadata allowances.

For Python, that set includes:

```text
/Library
/Library/Frameworks
/Library/Frameworks/Python.framework
/Library/Frameworks/Python.framework/Versions
```

The same derivation covers the existing named system-runtime and newly owned execution paths. Each addition must identify its triggering path and purpose. Exact `lstat`/`readlink` inspection is permitted to establish those components; directory discovery and recursive host inspection are not.

**This is an explicit new authorization for one change class.** It permits no new parent-directory content access, subtree-wide metadata grant, Mach service, device, runtime replacement, source/evidence write permission, or network allowance. It also does not automatically approve the broad runtime/process rules inherited from the unqualified policy; those still require review.

The assignment then runs restrictive `true` and the fixed framework-entry Python marker. If both succeed, Codex completes the entire original qualification matrix **in the same engagement**. If a different permission class is required, it stops with that precise dependency instead of expanding permissions.

The proposed correction is supported, but **has not been executed or shown sufficient**.

## Codex handoff

| Field | Instruction |
|---|---|
| **RECIPIENT** | The **same neutral qualification conversation** that produced `rw0-diagnostic-ek73vtkc`. |
| **ATTACHMENTS** | **None required.** The exact retained archive path and identity are in the prompt. |
| **AUTHORIZED EFFECTS** | Bounded ancestor-metadata correction, synthetic qualification controls, and external evidence. No candidate or repository work. |
| **EXPECTED RETURN** | One inline result and one reopened qualification-evidence ZIP. |
| **PROJECT SNAPSHOT** | None requested. |
| **NEXT ACTION** | Return the result here before candidate execution. |

Send **only this complete replacement prompt**:

:chatgpt-content-reference{index="7"}[**RW0 audit environment — runtime-ancestor metadata completion and qualification**](sandbox:/mnt/data/Coordinator_RW0_Audit_Environment_Runtime_Ancestor_Metadata_Qualification_Prompt.txt)

Do not resend the previous mandate as an operative instruction. The replacement contains the complete requirements, the finite authorization amendment, and the stop conditions. It uses the existing artifact at:

```text
/private/tmp/rw0-audit-entry.daLWIE/rw0-diagnostic-ek73vtkc/
RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_INCOMPLETE_RESTRICTIVE_POLICY_CAUSE_UNRESOLVED_20261029.zip
```

The successful disposition remains:

```text
RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_QUALIFIED
```

A successful Python marker alone cannot produce it. Qualification still requires policy review and the complete runtime, parent/fork/exec, filesystem, alias, and owned-network controls on one final policy.

## Candidate state and inspection limits

The preserved candidate remains unaccepted at:

```text
4691af58ae0ee3107b4e2e9b6b1508032944e357
```

Its previous artifact authentication did not establish acceptance, and the incomplete candidate audit supplied no independent direct or FULL execution credit. Pasted text All A01–A18 obligations remain outstanding. Keep the implementation conversation idle.

**I performed data-only archive checks, record reconciliation, timestamp calculations, and static source/policy inspection.** I executed no supplied helper, sandbox policy, probe, candidate code, SQL, tests, Git command, or host diagnostic. The prospective sequence is supported by retained records—not a complete independently observed tool trace.

**Sources:** Coordinator_RW0_Audit_Qualification_EK73VTKC_Receiving_Review\.md[Receiving inspection](sandbox:/mnt/data/Coordinator_RW0_Audit_Qualification_EK73VTKC_Receiving_Review.md), RW0_Audit_Qualification_EK73VTKC_Report_From_Sealed_ZIP.md[exact embedded report](sandbox:/mnt/data/RW0_Audit_Qualification_EK73VTKC_Report_From_Sealed_ZIP.md), Coordinator_RW0_Audit_Qualification_EK73VTKC_Receiving_Verification.json[verification record](sandbox:/mnt/data/Coordinator_RW0_Audit_Qualification_EK73VTKC_Receiving_Verification.json), and CPython’s versioned source cited above.

**Confidence:** artifact identity and record reconciliation **0.99**; identified ancestor-metadata gap **0.98**. Successful correction and effective containment remain unestablished.
