## Engineering disposition

```text
RW0_NORMAL_TERMINAL_CLOSURE_F01_TIMESTAMP_REPAIR_REQUIRED
CANDIDATE_REMAINS_UNACCEPTED
```

**Accept the timestamp finding and repair it in the existing implementation conversation. Preserve the S01/A03 work; do not restart the terminal design or retry acceptance against unchanged bytes.**

The auditor independently exercised the selected S01 historical-witness and A03 exact-type repairs successfully. The new blocker is distinct: invalid timestamps can pass the physical schema and checked-row boundary. No independent selector-free FULL run was completed. Pasted text

I reauthenticated the supplied 25,334,611-byte candidate archive, its 1,130 manifest-covered members, all 327 source endpoints, and tree:

```text
011f76542a77b2a766a46ac08df102b4de4c09c6
```

Targeted source inspection supports F01. I have **not** received or reopened the latest auditor’s separate 151,261-byte evidence ZIP, so its execution results remain attributed to the audit report.

## F01 is a two-layer defect

The SQL checks for `recorded_at` in the **context, result, and receipt tables** compare a `strftime` result with the supplied text without rejecting a NULL function result. The auditor’s `2026-13-27T12:00:00Z` specimen was accepted by all three insert boundaries. Separately, the row adapter imports `_time` but does not invoke it for those fields; correctly resealed invalid result and receipt rows passed its validation. Pasted text

SQLite’s documented rule confirms the mechanism: a `CHECK` expression evaluating to NULL does not violate the constraint. Declaring the **column** `NOT NULL` does not make a computed predicate non-NULL. [SQLite](https://www.sqlite.org/lang_createtable.html)

**The demonstrated scope matters.** Fresh planning already validates the timestamp, and historical reconstruction reaches that planner. The audit did not establish an invalid normal-writer commit or an unsafe `committed_exact` result. Nevertheless, the schema and checked-row interfaces admit values forbidden by their owning contract, so acceptance remains blocked. Pasted text

The inspected source locations are:

```text
src/ge_nwp_coordinator/sqlite_migrations/0008_rw0_terminal_outcome.sql:44,121,154
src/ge_nwp_coordinator/_rw0_terminal_outcome_rows.py:90–155
src/ge_nwp_coordinator/_rw0_terminal_outcome_contracts.py:84–93
src/ge_nwp_coordinator/_rw0_terminal_outcome_plan.py:115–124
```

## Selected repair

| Surface | Required treatment |
|---|---|
| **SQL** | Make all three timestamp predicates fail closed, including NULL conversion results, and enforce genuine calendar validity and canonical UTC whole-second form. |
| **Checked rows** | Apply the existing `_time` validator directly to each actual `recorded_at` field. Correct self-digests must not bypass semantic validation. |
| **Migration/catalog** | Correct the still-uncommitted `0008` in place, updating its checksum and direct consumers. Preserve migrations 0001–0007, application generation 2, schema shape, and existing schema identifiers. |
| **Tests** | Exercise raw SQL and direct row construction separately, with valid controls that exclude unrelated constraint failures. Include calendar, formatting, type, and higher-level no-regression cases. |

A fix limited to the reported bad month would be too narrow. The mandate also requires invalid month/day combinations, leap-year boundaries, hour/minute/second overflow, year zero, noncanonical forms, and embedded-NUL cases—alongside valid calendar positives. It prohibits normalizing bad input into a valid timestamp or changing the repository’s broader timestamp policy.

The full witness module, terminal contracts and `_time`, plan, historical verifier, transaction controller, and writer-session implementation remain frozen. This repair should strengthen their row-validation dependency, not rewrite their semantics.

### Include the small O1 oracle correction

The audit confirmed that the equality-spy test increments an **instance** counter but asserts the **class** counter. Its separate shared-counter probe established the production type-first behavior, so O1 remains nonblocking. Pasted text

Since the value tests are already in scope, the repair will correct that counter and include a calibration proving it detects an intentional equality call. This is a test-quality correction, not a new production defect.

## Preserve the audit’s progress—and its limits

The S01 evidence is materially stronger now. A complete incompatible competing winner was rejected through the real verifier, and historical read, replay, and recovery succeeded after all five heads and the stop moved while reads of those mutable tables were denied. The independently resealed wrong-predecessor case directly covered the program head; the other roles retained candidate-authored regression coverage. That distinction must survive the next handoff. Pasted text

The independent direct run passed **46 cases, including the six connected cases**. The retained **9,554-case FULL** was writer evidence and was not independently executed. The broader causal matrix remains unfinished; neither the direct total nor the previous writer FULL closes it. Pasted text

There is also a separate **process deviation**: the auditor made a preliminary live-checkout Git/status and filename read before reading the full effect ceiling. I am retaining the archive-backed finding and attributed execution results for engineering decisions, **not treating that engagement as fully compliant artifact-only acceptance** or inferring preservation of an unobserved index interval. The next changed candidate needs a fresh, correctly bounded audit. Pasted text

## Codex handoff

| Field | Instruction |
|---|---|
| **CURRENT STATE** | Exact tree `011f765…` is uncommitted and blocked by F01. |
| **RECIPIENT** | The **same write-enabled normal-terminal implementation Codex conversation**. |
| **ATTACHMENTS** | One original audit-evidence ZIP, identified below. |
| **AUTHORIZED EFFECTS** | Bounded timestamp/schema/row/test repair, dependent catalog/docs updates, isolated synthetic validation, and external review artifacts. |
| **EXPECTED RETURN** | A newly identified cumulative uncommitted candidate and self-contained review package. |
| **PROJECT SNAPSHOT** | None requested; PR #17 remains the integrated baseline. |
| **NEXT ACTION** | Return the implementation result here, followed by a fresh independent precommit audit. |

Send this **one complete operative prompt**:

:chatgpt-content-reference{index="10"}[**RW0 normal terminal closure — F01 timestamp-grammar repair mandate**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Closure_F01_Timestamp_Grammar_Repair_Prompt.txt)

Attach this existing file from the **audit conversation**:

```text
RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_BLOCKED_EVIDENCE.zip

Bytes:
151,261

SHA-256:
b81f4713d4bfaa4c4c943727f1db007907e560d90432cb06b31545ced21235e5
```

Its reported retained location is:

```text
/tmp/rw0-terminal-audit.DMliIJ/delivery/
RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_BLOCKED_EVIDENCE.zip
```

**No separate `AUDIT_REPORT.md` or `Pasted text.txt` attachment is needed.** The evidence ZIP already contains the complete 26,456-byte report, and the prompt authenticates that embedded report by its fixed hash. The implementation conversation already retains the candidate source package. Pasted text

The expected successful result is:

```text
RW0_NORMAL_TERMINAL_CLOSURE_F01_TIMESTAMP_REPAIR_IMPLEMENTED_VALIDATED_PENDING_AUDIT
```

The mandate permits ordinary in-scope debugging and reruns without another handoff, retaining failed attempts without final credit. It requires fresh direct, connected, focused, and selector-free FULL validation, with complete source snapshots immediately before and after **both** collection and execution. Counts must come from the repaired collection rather than be forced to remain 9,554.

It authorizes **no staging, commit, push, PR, merge, publication, deployment, or product effect**.

**Sources:** Attached cumulative audit, cited above; Coordinator_RW0_Normal_Terminal_F01_Receiving_Check.json[data-only candidate verification](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_F01_Receiving_Check.json); official SQLite constraint semantics.

**Confidence:** source/package identity **0.99**; F01 diagnosis and bounded repair direction **0.98**. Latest raw audit execution evidence has not been reopened here; repaired correctness and independent acceptance remain unestablished.
