## Engineering disposition

**The archive authenticates. The evidence supports closing C1A01–C1A03 at their stated invariant-and-fault scope, and supports the two targeted runner-assurance supplements. Preserve W’s complete regression passes; no runner redesign or automatic suite rerun is indicated.**

The candidate remains **unaccepted**, with **27 mandatory substantive predicates open**.

The next assignment changes the work order: **C1A04’s unfinished coexistence fixture must not block the other 26 independent cases.** It also supplies a source-grounded alternative to trying to run the one-shot D2 fixture twice.

## Authenticated evidence

| Item | Verified result |
|---|---|
| Uploaded ZIP | **57,287,175 bytes** |
| SHA-256 | `b4ee6f3a1528f7826c7a92885e6d08c838dcbbdff5349e417305ac51ae37ad16` |
| Inventory | **159 regular files; 158 verified manifest rows** |
| Expanded size | **61,128,241 bytes** |
| Embedded report | **14,074 bytes**, matching its reported identity |
| Candidate | All **327 source files** authenticated and reconstructed to the fixed tree |

Every covered member passed path, uniqueness, type, encryption, size, CRC, SHA-256, and numeric-mode checks. The embedded W/M/U/T/S/R archives authenticate, as does the separately supplied current candidate archive.

The opening source binding and six before/after group captures each contain five complete source copies: **all 35 recorded copy inventories match the candidate**. They establish recorded-copy identity, not continuous custody or current live Git state.

The preserved review subject is:

```text
4691af58ae0ee3107b4e2e9b6b1508032944e357
```

:chatgpt-content-reference{index="1"}[Detailed receiving inspection](sandbox:/mnt/data/Coordinator_RW0_RC382_Receiving_Review.md)

## 1. C1A01–C1A03 closures are supported—with their limits intact

The credited v2 probe first calls the **real checked selected-acceptance lookup**, then injects five inconsistent returns: missing fact, wrong reference, foreign lineage, resealed foreign digest, and another existing decision parent.

Each case records exactly one lookup hit and returns:

```text
SQLiteMutationStoreError(database_integrity_failure)
```

The acceptance table and all four terminal-table snapshots remain unchanged, with zero terminal rows and no foreign-key violations. The separate physical DELETE attempt is rejected by the immutable acceptance trigger. After removing the injections, the valid counterpart records `accept`, reads and replays the same result, and recovers `committed_exact`.

The source supports the accompanying invariant:

```text
_rw0_c2_progression_plan.py:437–470,544–558
    The acceptance branch includes its selected fact before the receipt.

_sqlite_rw0_c2_progression.py:298–316,399–468
    Checked P1 history reconstructs the plan and compares its actual rows.

_sqlite_rw0_terminal_outcome.py:144–207
    That checked P1 history precedes the terminal selected-fact lookup.

_rw0_terminal_outcome_plan.py:148–162
    The selected reference, digest, decision, lineage and scope must agree.
```

**The combined closure is valid:** a durable inconsistent selected fact cannot survive the checked-P1 prerequisite under the stated transaction and trust conditions; an inconsistent later lookup result also refuses at the actual terminal boundary.

This does **not** claim that malformed facts were durably committed, that fault injection reproduced physical corruption, or that each injection was independently run through every historical operation. Those distinctions remain part of the accepted evidence scope.

The first probe’s mislabeled post-deletion snapshot receives no timed-snapshot credit. The corrected v2 execution supplies that evidence. Coordinator_RW0_RC382_Receiving_Verification.json[Closure analysis and raw-record reconciliation](sandbox:/mnt/data/Coordinator_RW0_RC382_Receiving_Verification.json)

## 2. WA-C01 and WA-C02 supply the missing runner evidence

| Supplement | Independently reconciled observations |
|---|---|
| **WA-C01** | Parent, fork, exec, and fork-then-exec; **20 ordinary link denials**, **20 rename denials**, **12 descriptor-relative link denials**, and **8 within-writable positives** |
| **WA-C02** | Actual-gate refusal of the registered helper’s symlink and FIFO counterparts before target spawn, followed by clean paired positives |

For WA-C01, the rename controls now use the **actual permitted temporary-module destinations**, not forbidden sibling names. Descriptor openings succeed before the recorded link calls, so an earlier directory-open failure is no longer being credited as link denial. The child identities and wait/reaping records agree.

For WA-C02, the exact gate diff confirms the authorized correction: when metadata already requires refusal, the gate no longer attempts active-helper content binding. Both negative admissions retain `active_binding=null`, exit 2, no timeout, and no target output. The restored ordinary helper then admits and executes.

The initial wrong-relative-plan clean invocation remains a no-credit process error; its later correctly invoked counterpart is separate.

**These are finite prospective supplements, not controls retroactively performed during W’s suites.** QtcM is unchanged, and the inspected correction does not add an accepting branch. W’s **60/60 direct and 9,568/9,568 FULL** remain attributed to W v5; RC did not rerun them. Coordinator_RW0_RC382_Receiving_Review\.md[Runner findings](sandbox:/mnt/data/Coordinator_RW0_RC382_Receiving_Review.md)

## 3. C1A04 stopped before a second P1 attempt—not at a demonstrated owner restriction

The retained coexistence helper does exactly this:

```text
Construct the first accepted subject
→ commit a second P0 admission
→ record/read the first terminal outcome
```

Its P0 act, fact, and receipt counts rise from one to two. The acceptance-fact count stays **one**. **The helper never constructs or submits a second P1 decision**, so the package contains no second-P1 rejection to diagnose.

The report identifies the one-shot `prepared_normal_case`/D1/D2 wrapper as the fixture limitation. That is not an invariant of the managed store. The existing mandate already distinguishes legitimate same-store coexistence from forcing two subjects through one hardcoded fixture chain. Coordinator_RW0_Normal_Terminal…

### Selected fixture direction

**Keep the selected terminal subject’s complete checked P0/D1/D2/Section 41/C1/V22/P1 chain. Construct the unrelated acceptance through its actual private P1 owner and all prerequisites that owner requires, in the same store.**

There is a concrete source basis for that approach:

- `tests/test_sqlite_rw0_c2_progression.py:45–130,156–179` constructs and verifies a standalone artificial P1 acceptance.
- `tests/test_c2b3d_private_atomic_author_effect_establishment.py:75–226` separates new-store setup from typed initialization and author-effect construction.
- The existing private writer exposes those initialization and author-effect operations; P1’s own current-state and predecessor checks are explicit in `_sqlite_rw0_c2_progression.py:167–237,675–758`.

The audit-owned builder should accept the **existing location**, derive a distinct typed subject and its dependent digests, and call the real owners. It must not reinitialize the store, transplant donor rows, insert a raw acceptance fact, or weaken checks. Its observations must use explicit subject keys rather than inherited table-wide `fetchone()` assumptions.

This is a **proposed fixture construction, not an executed coexistence proof or a new production multirun capability**. The unrelated fact must pass its real P1 read/replay/recovery checks. The selected terminal must then demonstrate correct behavior with that fact present, including the required nonaccept noninterference distinction where it is not already proved.

No second full D2 workflow is imposed merely because the current convenience helper uses one. Any genuine owner prerequisite still applies. Coordinator_RW0_RC382_Receiving_Review\.md[Source-grounded construction rationale](sandbox:/mnt/data/Coordinator_RW0_RC382_Receiving_Review.md)

## 4. Change sequencing, not acceptance requirements

The remaining groups are:

| Group | Open IDs |
|---|---:|
| Acceptance coexistence | 1 |
| Graph and source associations | 3 |
| Routes and recovery families | 16 |
| Session and transaction failures | 3 |
| Physical SQL constraints | 4 |
| **Total** | **27** |

The replacement assignment prioritizes the independently constructible SQL constraints and route implications, then the remaining graph/source and transaction cases, while preserving and completing the coexistence fixture. **One unfinished fixture is no longer a global stop condition.** A real candidate defect, unsafe runner, source drift, or actual authority conflict still is.

There is one minor ledger correction: C1A01–C1A04 have `RC_new_attempted=true` while retaining `current_named_predicate_attempted=false`. The evidence and explicit statuses are clear, but the successor ledger should distinguish **fixture attempted**, **exact predicate reached**, and **predicate closed**. Correcting those fields requires no rerun and does not reopen the three supported closures.

Completed C4, earlier causal proofs, and W’s suites retain their exact scopes. The next engagement is not permission to replace them with blanket “unproved” summaries again.

## Codex handoff

| Field | Instruction |
|---|---|
| **CURRENT STATE** | Three substantive closures and both runner supplements are supported. Candidate remains unaccepted with 27 open predicates. |
| **RECIPIENT** | The **same neutral independent reviewer conversation** that produced `rc-382779f584`. |
| **ATTACHMENTS** | **None required.** Exact retained RC/A/B/C paths and identities are included. |
| **AUTHORIZED EFFECTS** | Audit-owned fixture, observation, registration, and ledger work; unchanged-candidate execution under the preserved admitted runner. |
| **EXPECTED RETURN** | One cumulative disposition, exact closed/open IDs, coverage records, full report, and reopened evidence ZIP. |
| **PROJECT SNAPSHOT** | None requested. |
| **NEXT ACTION** | Return the cumulative result here before any candidate repair or commit gate. |

Send **only this complete replacement prompt**:

:chatgpt-content-reference{index="5"}[**RW0 normal terminal closure — independent residual groups and completion**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Independent_Residual_Groups_Completion_Prompt.txt)

**Substantive sections 2–4 remain byte-identical.** The changes are the supported carry-forward, corrected current ledger, alternative coexistence-fixture strategy, and dependency-aware execution order. There is no new permission budget or automatic qualification/regression reset.

```text
Prompt size:
68,042 bytes

SHA-256:
9c4f6cb0a5dcc5dbfaf5a59db5b7e6d123475bdcbbfb98fdd0de4da64d727e5f
```

:chatgpt-content-reference{index="6"}[Handoff identity record](sandbox:/mnt/data/Coordinator_RW0_RC382_Handoff_Check.json)

Keep the implementation conversation idle. No candidate edit, policy expansion, assertion relaxation, installation, staging, commit, publication, or deployment is authorized.

**Inspection limits:** Data-only archive verification, source reconstruction, retained-record reconciliation, and static inspection. No supplied helper, candidate code, SQL, test, policy, Git operation, or host probe was executed here.

**Sources:** Coordinator_RW0_RC382_Receiving_Review\.md[Receiving inspection](sandbox:/mnt/data/Coordinator_RW0_RC382_Receiving_Review.md), RW0_Normal_Terminal_RC382_Report_From_Sealed_ZIP.md[exact embedded report](sandbox:/mnt/data/RW0_Normal_Terminal_RC382_Report_From_Sealed_ZIP.md), Coordinator_RW0_RC382_Receiving_Verification.json[verification record](sandbox:/mnt/data/Coordinator_RW0_RC382_Receiving_Verification.json), and the operative requirement cited above.

**Confidence:** Artifact/source identity and record reconciliation **0.99**; scoped closures and continuation direction **0.97**. The coexistence positive, complete residual closure, candidate acceptance, and commit-gate eligibility remain unestablished.
