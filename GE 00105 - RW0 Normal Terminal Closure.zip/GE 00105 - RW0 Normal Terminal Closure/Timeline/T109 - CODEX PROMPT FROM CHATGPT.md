RW0 NORMAL TERMINAL CLOSURE — EXACT-BYTE LOCAL COMMIT GATE

This is the sole complete operative mandate. Execute it in the SAME write-enabled Coordinator implementation conversation that owns the live RW0 normal-terminal working tree. The implementation and independent cumulative audit are complete. This is an exact-byte local commit gate only.

Do not repair, refactor, reformat, regenerate, or otherwise edit candidate source, tests, migrations, schemas, documents, configuration, or status wording. Do not perform a status successor in this gate.

ENGAGEMENT ENVELOPE

CURRENT STATE
- Integrated baseline commit: `61d0330aba1160f7f5e7d9c541a325222d1c61e5`.
- Integrated baseline tree: `44c7dee402d46b3e16dc389ae0824b4297dfec1f`.
- Expected live branch: `codex/rw0-normal-terminal-closure-v1`.
- Expected upstream: absent.
- Accepted uncommitted source: 327 regular paths, Git-compatible tree `4691af58ae0ee3107b4e2e9b6b1508032944e357`.
- Expected cumulative delta from HEAD: 67 modified existing paths, 12 created paths, 0 deletions, 0 renames, 248 unchanged baseline paths, and no Git-mode change.
- Expected source modes: all 327 Git modes `100644`; 326 live POSIX modes `0644`; `tests/test_c2b3_private_atomic_program_initialization.py` live POSIX mode `0600`.
- Exact candidate source manifest SHA-256: `1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1`.
- Migration 0008: 30,178 bytes; SHA-256 `a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254`.
- Accepted audit disposition: `RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE`.

RECIPIENT
- The write-enabled implementation conversation for `/Users/ds/Repositories/Governed Execution Coordinator/`.
- Not the neutral audit conversation.

ATTACHMENTS AND RETAINED INPUTS
Attach exactly one file to this gate:
- `RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE_CURRENT_LEDGER_REPAIRED_20261031_rx-6e3a9c2d41.zip`
- 90,995,153 bytes
- SHA-256 `82cd3ab60170aed1fbc1738bb37e48624d9b237c72f4f7a9e17ac1147e6a8138`

Use these exact retained implementation inputs at their named paths; do not search for namesakes:
- Candidate ZIP:
  `/Users/ds/.codex/rw0-terminal-historical-witness-tcp5rwoh/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip`
  48,978,087 bytes
  SHA-256 `6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42`
- Candidate implementation report:
  `/Users/ds/.codex/rw0-terminal-historical-witness-tcp5rwoh/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_IMPLEMENTATION_REPORT.md`
  19,549 bytes
  SHA-256 `c52141d0fcf15701496c4dec18133361a78b8f043796078340e24eed4bdae2d5`

If the attachment or either retained implementation input is unavailable at the exact binding, stop and name the missing input. Do not search Downloads, home, sibling repositories, old task roots, or chat caches.

AUTHORIZED EFFECTS
- Read and authenticate the exact live Coordinator checkout and named evidence inputs.
- Stage exactly the accepted candidate paths.
- Run staged-tree validation from an external copy built only from staged Git blobs.
- Create exactly one local implementation commit with the exact message below.
- Produce external gate evidence and a status-successor dependency inventory.

NOT AUTHORIZED
- Any repository source, document, test, schema, migration, configuration, mode, or status edit.
- Branch switch, reset, restore, clean, stash, rebase, merge, cherry-pick, amend, or commit retry that obscures the first result.
- Fetch, pull, push, remote mutation, PR creation, auto-merge, merge, release, deployment, service contact, provider contact, ES/Bridge contact, product database access, product effect, or new implementation tranche.
- Dependency installation, runtime substitution, test filtering, skipped tests, assertion changes, warning suppression, or source cleanup.
- Running any packaged implementation/audit helper as authority. Inspect package programs as inert data only.

EXPECTED RETURN
One inline closeout with:
- primary disposition;
- opening and closing branch/HEAD/tree/upstream/index/worktree identities;
- exact staged path classification;
- staged-tree validation commands and complete results;
- new local commit ID, parent, tree, exact raw message identity, blob/mode verification;
- ref/config/index effects and diagnostic-ref accounting;
- status-successor dependency inventory summary;
- report, result, evidence ZIP, manifest, cleanup receipt, and exact byte/SHA identities;
- explicit no-push/no-PR/no-merge/no-publication/no-deployment/no-product-effect statements.

PROJECT SNAPSHOT
- No new Project snapshot is requested by this gate.
- Request the next Coordinator snapshot only after eventual integration onto `trunk_dev`.

NEXT ACTION
- On success, return to ChatGPT for a separately governed status-successor implementation and review sequence.
- Do not begin that successor in this engagement.

0. ENTRY, FIRST OBSERVATION, AND STOP RULES

Use repository path exactly:
`/Users/ds/Repositories/Governed Execution Coordinator/`

Before the first Git command:
1. create a unique task-owned external evidence root;
2. copy `.git/index` by direct filesystem read into that root and record bytes, SHA-256, size, mode, device/inode and timestamps;
3. record the repository directory identity without traversing unrelated contents;
4. record the exact attached RX path and the two retained input paths;
5. state the effect ceiling above.

Do not run `git status`, `git diff`, `git rev-parse`, or any other Git command before the raw-index copy.

Stop before staging if any of these occurs:
- branch, HEAD, HEAD tree, parent, local `trunk_dev`, local `origin/trunk_dev`, or upstream state differs from the fixed baseline;
- index has staged or unmerged entries, or its semantic stage-zero inventory differs from HEAD;
- live working source does not equal the accepted candidate bytes and modes;
- an unexpected tracked, untracked, deleted, renamed, special, linked, or mode-changed source path exists;
- candidate or RX input authentication fails;
- Git replacement refs, grafts, alternate object databases, unexpected worktrees, or source-selection dependencies are present;
- a source, status, authority, security, or mode change would be needed;
- another active Git writer is observed;
- any required validation or evidence operation is unavailable.

A stop is not permission to repair. Preserve evidence and return an exact blocking disposition.

1. AUTHENTICATE THE ACCEPTED INPUTS

1.1 Candidate implementation package
- Authenticate the candidate ZIP and standalone report at the exact identities above.
- Require safe unique normalized relative regular unencrypted members, bounded expansion, complete self-excluding manifest coverage, CRC/readability, size, SHA-256 and numeric-mode equality.
- Require the standalone report to equal its embedded copy byte-for-byte.
- Authenticate all 327 final source endpoints and their Git/OS modes.
- Independently rebuild tree `4691af58ae0ee3107b4e2e9b6b1508032944e357` from source bytes and Git modes without using the live index.
- Authenticate the exact cumulative baseline-to-final classification: 67 modified, 12 created, 0 deleted, 0 renamed, 248 unchanged.
- Authenticate all historical inputs and manifest endpoints required by the candidate package, but do not execute packaged programs.

1.2 Accepted RX audit package
- Authenticate the attached RX ZIP exactly: 90,995,153 bytes and SHA-256 `82cd3ab60170aed1fbc1738bb37e48624d9b237c72f4f7a9e17ac1147e6a8138`.
- Require 13 safe regular members, 91,312,812 expanded bytes, and 12 complete self-excluding manifest rows.
- Require its embedded RV ZIP exactly once: 90,937,959 bytes, SHA-256 `2a617830c52c4767e02603126e6cf53387f8cf2d9e75cdc7a987556b01a7a4eb`.
- Require:
  - `REPORT.md`: 8,252 bytes, SHA-256 `36820d68b81e5914d9c7e7c5ddeebe6434bcc9ae1872e43d4d536e1061aae463`;
  - `RESIDUAL_56_CURRENT_v2.json`: 182,392 bytes, SHA-256 `fbba9809f0f46bca10befb5e4300f4793e5e77446bacb6be9324740e4e755cd4`;
  - `A01_A18_CURRENT_v2.json`: 103,436 bytes, SHA-256 `d557c22d4a7f1ff44696b8b74e3c2838b88882c5e434684406d040142c0741e4`;
  - `MANIFEST.json`: 3,032 bytes, SHA-256 `35f951b9ae5403eabe5b98c18fd1d600eca8876b71ac06b7191a2f49bf6ea76f`.
- Confirm 56 residual rows, all current closed, zero mandatory/substantive opens, `next_named_predicate=null`, and next action `separately_governed_exact_byte_live_commit_gate`.
- Confirm A01–A18 exactly once, all current complete, zero current opens.
- Confirm C2A11, C2A20 and all 13 C1B05 rows retain their accepted bounded scopes and evidence identities.
- Treat historical row fields and earlier blocked/incomplete reports as historical evidence; do not rewrite them.

2. AUTHENTICATE THE LIVE OPENING

Require all of the following before staging:
- current branch `codex/rw0-normal-terminal-closure-v1`;
- HEAD `61d0330aba1160f7f5e7d9c541a325222d1c61e5`;
- HEAD tree `44c7dee402d46b3e16dc389ae0824b4297dfec1f`;
- HEAD sole parent `4519630d0db967066beb21b4ace5004e76827716`;
- local `trunk_dev` and local `origin/trunk_dev` both equal HEAD;
- no upstream for the topic branch;
- one expected worktree only;
- no replace refs, grafts, alternate object database, or source-selecting environment/config;
- 315 stage-zero index entries equal HEAD, no staged or unmerged entry;
- live source consists of exactly 327 accepted paths and no extras;
- live bytes, sizes, SHA-256, Git blobs, Git modes and POSIX modes equal the accepted candidate manifest;
- classified test mode remains POSIX `0600` / Git `100644`; every other accepted source path remains POSIX `0644` / Git `100644`;
- exact candidate tree reconstructed independently from live bytes is `4691af58ae0ee3107b4e2e9b6b1508032944e357`;
- tracked full-index diff and untracked additions match the candidate package exactly;
- `git diff --check` passes;
- no unaccepted ignored/generated artifact is consumed as source or evidence.

Capture:
- complete authoritative ref map;
- complete `refs/codex/turn-diffs/` diagnostic map separately;
- configuration bytes/hash and source-selection-relevant settings;
- raw and semantic index identities;
- exact opening source manifest;
- opening process/writer observation.

Qualified diagnostic refs may differ from historical packages before this formal opening. Preserve their complete opening/closing names and OIDs, classify additions/removals/retargets, and prove no source or validation selection depends on them. Do not silently absorb a non-diagnostic authoritative ref change.

3. STATUS-SUCCESSOR DEPENDENCY INVENTORY — READ ONLY

Before staging, scan the exact 327 accepted source files for current candidate-era wording and direct consumers that will require a later status successor after this commit. At minimum classify:
- current passages saying the terminal implementation is uncommitted, pending audit, or awaiting a commit gate;
- historical candidate/blocked passages that must remain byte-exact and attributable;
- current docs that name tree `4691af58...`, the accepted audit, migration 0008, terminal closure status, or no-publication state;
- exact literal, whole-file hash, prefix/suffix, AST, source-manifest, predecessor-reconstruction, or marker consumers in tests;
- other-scope passages that must not be rewritten.

Produce `STATUS_SUCCESSOR_DEPENDENCY_INVENTORY.md` with exact path:line anchors and consumer classifications. Do not edit any repository file in this gate.

4. EXACT STAGING

Stage exactly the accepted 79 paths in one bounded staging operation derived from the authenticated candidate manifest:
- 67 existing modified paths;
- 12 created paths;
- 0 deletions;
- 0 renames;
- 0 Git-mode changes.

Require:
- every staged blob and Git mode equals the accepted manifest;
- all 248 other baseline entries remain equal to HEAD;
- no path outside the accepted manifest is staged;
- no unmerged entry;
- no unstaged source difference remains after staging;
- `git diff --cached --check` passes.

Run `git write-tree` exactly once after staging. It must return:
`4691af58ae0ee3107b4e2e9b6b1508032944e357`.

If it differs, stop before validation and commit. Do not normalize or restage source to make it match.

5. STAGED-TREE VALIDATION

Construct a fresh external validation copy solely from the staged index's 327 Git blobs. Do not copy source from the live worktree.

Modes in the validation copy:
- `tests/test_c2b3_private_atomic_program_initialization.py`: POSIX `0600`;
- all other source files: POSIX `0644`;
- all Git modes remain `100644`.

Use:
- `/Library/Frameworks/Python.framework/Versions/3.13/bin/python3`;
- expected Python 3.13.4, pytest 8.4.1, SQLite 3.49.1;
- restrictive umask `0077`;
- task-owned `HOME`, `TMPDIR`, basetemp, JUnit and log paths;
- `PYTHONDONTWRITEBYTECODE=1`;
- `PYTHONNOUSERSITE=1`;
- `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
- `PYTEST_ADDOPTS=`;
- `-p no:cacheprovider`;
- null stdin, bounded waits and no core dumps;
- local sandboxing that denies network but otherwise permits the unchanged suite's required signals, subprocesses, SQLite state, hardlinks and exact temporary module behavior.

Do not use `-k`, `-m`, a module/path/node selector, xdist, adaptive selection, warning suppression, or result filtering.

Run exactly:
1. one selector-free collection;
2. one selector-free FULL execution.

Required results:
- collection: 9,568 unique ordered IDs;
- compact ordered-ID SHA-256: `25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9`;
- execution calls and JUnit IDs: the same 9,568 IDs in the same order;
- 9,568 passed;
- zero failures, errors, skips, xfails or xpasses;
- exactly the three accepted Python 3.13 multithreaded-fork deprecation warnings identified by the RX/W evidence, and no other warning;
- collection and execution exit 0;
- all 327 source bytes and numeric modes unchanged before and after each phase;
- staged tree, live source and index unchanged throughout validation.

Retain exact argv, cwd, allowlisted environment, runtime versions, starts/ends/durations, PIDs, exits, raw stdout/stderr, ordered IDs, JUnit, phase outcomes, warnings, and before/after source inventories.

Any collection drift, failure, unexpected warning, source/mode change, timeout, environment incompatibility, or unavailable required operation stops the gate before commit. Do not repair or rerun a changed candidate. Preserve the failed evidence.

6. ONE LOCAL COMMIT

Only after all prior gates pass, create exactly one local commit with this exact raw message:

```text
feat: add RW0 normal terminal closure
```

The raw message is 38 bytes including the terminal LF and has SHA-256:
`5c4636b720b089644377d7b55e995cb94535a5ecec062929f927685c48ea19c5`.

The commit must have:
- sole parent `61d0330aba1160f7f5e7d9c541a325222d1c61e5`;
- tree `4691af58ae0ee3107b4e2e9b6b1508032944e357`;
- exact subject `feat: add RW0 normal terminal closure`.

Do not amend. Do not make a second commit.

After commit, verify independently:
- all 327 committed blobs and Git modes equal the accepted manifest;
- raw commit message bytes match the fixed message;
- worktree and index are clean;
- branch remains `codex/rw0-normal-terminal-closure-v1`;
- upstream remains absent;
- local `trunk_dev` and local `origin/trunk_dev` remain `61d0330aba1160f7f5e7d9c541a325222d1c61e5`;
- configuration is unchanged;
- only HEAD and the local topic authoritative ref moved to the new commit;
- every other non-diagnostic authoritative ref is unchanged;
- all diagnostic-ref changes are fully recorded and no surviving name silently retargeted;
- classified POSIX `0600` source mode remains preserved in the live checkout;
- no network or remote effect occurred.

7. RETAINED EVIDENCE AND CLEANUP

Produce a unique external gate root and retain at minimum:
- `CLOSEOUT_REPORT.md`;
- `RESULT.json`;
- exact input identities and package-authentication records;
- raw opening/final index identities and semantic inventories;
- opening/final config and ref classifications/deltas;
- accepted 79-path stage classification;
- staged and committed blob/mode inventories;
- exact write-tree output;
- commit raw object/message verification;
- complete collection/FULL commands, environments, logs, ordered IDs, JUnit and warnings;
- complete validation source-before/source-after inventories;
- `STATUS_SUCCESSOR_DEPENDENCY_INVENTORY.md`;
- cleanup and preservation receipts;
- self-excluding retained-artifact manifest;
- one compact evidence ZIP and adjacent delivery receipt.

Do not include credentials, private templates, product databases, raw repository index bytes in user-visible text, unrelated caches, bytecode, build output, or unclassified special files. Raw index bytes may remain private within the external task-owned evidence root if classified safe repository metadata.

Remove only task-owned validation copies and temporary test state after the retained evidence is protected and reopened. Do not remove or alter candidate evidence, repository ignored state, historical audit roots, refs, or unrelated temporary state.

8. PRIMARY DISPOSITIONS

On success return exactly:
`RW0_NORMAL_TERMINAL_CLOSURE_COMMITTED_LOCALLY_NOT_PUBLISHED`

If any precommit condition fails, return a precise `RW0_NORMAL_TERMINAL_CLOSURE_COMMIT_GATE_BLOCKED_*` disposition, preserve evidence, and do not commit.

Always state explicitly:
`PUSH_NOT_PERFORMED`
`PR_NOT_CREATED`
`MERGE_NOT_PERFORMED`
`PUBLICATION_NOT_PERFORMED`
`DEPLOYMENT_NOT_PERFORMED`
`PRODUCT_EFFECT_NOT_PERFORMED`

This local commit establishes no live custody, external authority, worker/provider readiness, ES/Bridge route, product Git authority, service, scheduler, autonomous loop, release, deployment, or production execution.
