## Engineering disposition

**The archive authenticates, and the reported 60/60 direct and 9,568/9,568 FULL passes are supported by the retained execution records. Preserve those passes. Do not restart the regression or runner-design programs.**

I found **a cumulative-reporting error and two bounded runner-assurance gaps**, not a demonstrated candidate defect. The next assignment corrects the evidence accounting, completes those specifically missing controls, and then addresses the existing thirty substantive residuals. It does not automatically repeat the representatives, 99-case replay, direct suite, FULL, or already supported causal work.

The candidate remains unaccepted at:

```text
4691af58ae0ee3107b4e2e9b6b1508032944e357
```

## Authenticated evidence and regression results

| Item | Verified result |
|---|---|
| Uploaded ZIP | **49,940,248 bytes** |
| SHA-256 | `718b49bc34d84cd6dc30bfe295970765d93e12238892c1c74145fe0fc76baf81` |
| Archive inventory | **817 regular files; 816 verified manifest rows** |
| Expanded size | **102,549,472 bytes** |
| Embedded report | **23,084 bytes**, matching its reported identity |
| Candidate source | All **327 files** authenticated and independently reconstructed to the fixed tree |
| Policy | Exact, unchanged **4,086-byte QtcM** |

Every covered member passed path, uniqueness, type, encryption, size, CRC, SHA-256, and numeric-mode checks. The embedded M, U, T, S, and R archives also authenticate.

Independent parsing of the raw observer, JUnit, launch, and output records gives:

| Execution | Exact ordered collection/call/JUnit IDs | Passing phases | Warnings |
|---|---:|---:|---:|
| Four representatives | 4 | 12 | 0 |
| Exact failed-case replay | 99 | 297 | 0 |
| Complete direct suite | **60** | **180** | **0** |
| Selector-free FULL | **9,568** | **28,704** | **3** |

Direct and FULL each have separate successful collection records matching execution order. There are no failed setup/teardown phases, failures, errors, skips, xfails, or xpasses. The three FULL warnings match the permitted B2c fork-deprecation cases. The inspected FULL bootstrap contains no test selector, and the representative-only child tracer is absent from the final suites.

All six principal launches bind the same v5 WA1 revision, exact policy, and authenticated helper bytes. Their source captures match the candidate. Independent inventory comparison found no protected-to-writable inode overlap, no changed previously observed protected records, closed writable hardlink groups, and both temporary-module slots absent at the recorded boundaries.

**These are authenticated independent execution records; I did not rerun the tests.** T’s earlier failed Qs FULL remains a historical failure, not a result rewritten by these later passes.

:chatgpt-content-reference{index="2"}[Detailed receiving inspection](sandbox:/mnt/data/Coordinator_RW0_WA09_Receiving_Review.md)

## 1. Correct the report’s cumulative accounting—not the candidate

The new report overstates what remains unproved. Its embedded historical records preserve evidence that its current summary describes as missing.

| New report’s remaining-proof statement | Evidence still present in the authenticated chain |
|---|---|
| Private replan mismatch remains untested across record/read/replay/recovery | S’s `causal_completion_replan2` has two passing fresh-absent/persisted cases exercising those operations. Its scope is hostile post-construction operand mutation—not a second ordinary valid command. |
| Distinct V22 proposal reference and detached associations remain | S’s `causal_completion_source3` has one positive and four detached cases, including the distinct proposal reference, reaching the actual checked projection. Other associations remain open. |
| Calendar/admin/connected work is broadly unproved | R/S/T retain their previously reviewed calendar, administrative, five-normal, and selected fault proofs. These are bounded results, not blanket closure—but they are not zero evidence. |

The new ledger-generation helper assigns `mandatory_coverage_gap` to every A01–A18 row and supplies broad replacement gap text. **Absence of a new rerun is being confused with absence of earlier independent proof.** The raw older payloads have not been lost; the error is in the cumulative interpretation.

The continuation requires a predicate-by-predicate carry-forward map. It must preserve the stronger earlier historical observation: W’s new phase probe labels the broad managed wrapper, whereas the earlier refined probe and C4 records bind the actual stop-shape function and normalized operation stream. A newer, narrower probe must not displace stronger retained evidence.

This does **not** close the thirty outstanding rows by fiat. It prevents completed work from becoming an expanding repeat backlog. Coordinator_RW0_WA09_Receiving_Review\.md[Accounting findings and exact member coordinates](sandbox:/mnt/data/Coordinator_RW0_WA09_Receiving_Review.md)

## 2. WA1’s supported results are real—but two prescribed scopes remain incomplete

The six hardlink-contamination cases are supported. Each records the source and alias with matching device/inode identities and link count two, refusal before target launch, restoration to one link, and a successful clean counterpart. One case uses an older reachable scratch namespace.

The original four-role forty-control matrix also reconciles. Successful output publication records independently created protected files with identities distinct from their provisional sources. The failed historical preplaced-hardlink runtime test remains failed; none of this turns QtcM alone into inode-based protection.

However, the previous mandate separately required descendant link/move coverage and active nonregular-path refusal. Those obligations were not discharged by the six contamination cases or the original forty controls. Coordinator_RW0_Normal_Terminal…

### WA-C01 — complete the added link/move controls’ actual scope

The new `runtime_link_wa.py` executes its controls in **one contained process**. The separately executed parent/fork/exec/fork-then-exec matrix tests the older symbolic-alias operations; it does not run these added hardlink cases.

Two details also limit the thirteen reported negative rows:

**The two W-slot rename attempts use the wrong destinations.** The helper appends `_moved` to the allowed filenames. Those siblings are not writable under the policy, so denial there does not independently prove refusal to move a protected file into an **allowed** W slot.

**The descriptor-relative wrapper combines directory opening and `os.link` into one exception result.** A permission error must be attributed to its actual stage before it can count as a link denial.

The supplement retains the same finite source/destination classes, adds the missing process-form observations, uses the actual allowed W destinations, and records syscall reach. It authorizes **no permission change**.

### WA-C02 — prove active-helper symlink/special-file refusal

The archive contains no actual-gate control for an active helper replaced by a symlink or nonregular special file.

Static inspection also identifies a precise concern: the gate collects layout-rejection reasons but still performs active content binding before returning refusal; its byte reader opens the file before checking that the opened object is regular. **This is a source-level refusal-path concern, not a reproduced hang or unsafe launch.** The reconciled candidate runs contained no such malformed active object.

The continuation permits the smallest defensive audit-helper correction if needed: **return the existing refusal from a known-rejected metadata snapshot before active content reads**, without changing any accepting branch or weakening any invariant. It then tests the real gate with a synthetic registered helper and a clean counterpart.

Neither gap establishes that candidate execution escaped containment. They do prevent describing the runner’s entire prescribed qualification as complete. Coordinator_RW0_WA09_Receiving_Review\.md[Runner-control findings](sandbox:/mnt/data/Coordinator_RW0_WA09_Receiving_Review.md)

## 3. Preserve the suite passes while closing the gaps

**There is no automatic FULL rerun in the replacement assignment.**

The prospective evidence rule is explicit: the exact v5 suite passes may support cumulative acceptance alongside the targeted same-boundary supplement and later residual proofs. Registration-only changes, new owned evidence locations, or a demonstrated **rejection-only** admission correction do not automatically invalidate execution on the recorded clean layouts.

This does not claim that the older runs used a later helper or that every qualification control had already run. If the supplement discovers an actual defect affecting historical admitted states—or changes candidate bytes, policy, runtime, or successful-launch behavior—the auditor must assess and rerun the genuinely invalidated evidence. It cannot silently preserve an invalid pass or combine incompatible runs.

The old preplaced-hardlink failure and the trusted-supervisor/no-hostile-concurrent-host-actor limitation remain explicit.

## 4. The thirty substantive predicates are still the main completion task

The stable 56-row ledger preserves every prior row. Its thirty open predicates are unchanged:

| Group | Open rows |
|---|---:|
| Selected and unrelated acceptance facts | 4 |
| Remaining graph and source associations | 3 |
| Later route matches, damaged and foreign families | 16 |
| Remaining session and transaction failures | 3 |
| Remaining physical SQL constraints | 4 |

W records **all thirty as not attempted at their exact named predicate**. Its three new probes passed, but largely revisit broader constructor, schema, and phase behavior; none closes a new named residual. The report supplies restart suggestions but does not identify a specific practical constraint explaining that stop. I have not invented one.

After the narrow assurance supplement, the next assignment starts with an actually outstanding acceptance-fact case and proceeds through coherent fixture groups. It preserves existing positives and precise invariant arguments; it does not demand impossible first-match states, cryptographic collisions, or an artificial “same hardcoded chain” restriction.

Completed C4 and supported R/S/T controls carry forward. The mandate already required their reuse rather than a full causal reset. Coordinator_RW0_Normal_Terminal…

## Codex handoff

| Field | Instruction |
|---|---|
| **CURRENT STATE** | Exact-source regression passes are supported. Candidate acceptance remains unavailable pending the limited assurance supplement and thirty substantive residuals. |
| **RECIPIENT** | The **same neutral independent reviewer conversation** that produced `wa-09da07307c`. |
| **ATTACHMENTS** | **None required.** Exact retained W/A/B/C paths and identities are included. |
| **AUTHORIZED EFFECTS** | Audit-owned accounting, targeted controls, the narrowly bounded refusal-path correction if needed, and unchanged-candidate residual validation. |
| **EXPECTED RETURN** | One cumulative disposition, corrected coverage/assurance ledgers, full report, and reopened evidence ZIP. |
| **PROJECT SNAPSHOT** | None requested. |
| **NEXT ACTION** | Return the cumulative result here before any candidate repair or commit gate. |

Send **only this complete replacement prompt**:

:chatgpt-content-reference{index="5"}[**RW0 normal terminal closure — preserved validation and residual closure**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Preserved_Validation_And_Residual_Closure_Prompt.txt)

It contains the complete assignment. **Substantive sections 2–4 remain byte-identical to the previous mandate.** The carry-forward rule, narrowly missing assurance work, defensive correction allowance, and residual execution order are explicit. No earlier prompt fragments need to be assembled.

```text
Prompt size:
68,135 bytes

SHA-256:
d459412dcb72eb91249f658810c0f46db3fed9957376dfa4a370330c734066aa
```

:chatgpt-content-reference{index="6"}[Handoff identity record](sandbox:/mnt/data/Coordinator_RW0_WA09_Handoff_Check.json)

Keep the implementation conversation idle. No candidate edit, policy expansion, assertion relaxation, installation, staging, commit, publication, or deployment is authorized.

**Inspection limits:** Data-only archive verification, source reconstruction, retained-record reconciliation, and static inspection. No supplied helper, candidate code, SQL, test, policy, Git command, or host probe was executed here.

**Sources:** Coordinator_RW0_WA09_Receiving_Review\.md[Receiving inspection](sandbox:/mnt/data/Coordinator_RW0_WA09_Receiving_Review.md), RW0_Normal_Terminal_WA09_Report_From_Sealed_ZIP.md[exact embedded report](sandbox:/mnt/data/RW0_Normal_Terminal_WA09_Report_From_Sealed_ZIP.md), Coordinator_RW0_WA09_Receiving_Verification.json[machine-readable verification](sandbox:/mnt/data/Coordinator_RW0_WA09_Receiving_Verification.json), and the operative mandate cited above.

**Confidence:** Artifact/source identity and suite reconciliation **0.99**; scoped coverage and accounting findings **0.97**. Complete runner assurance, candidate acceptance, and commit-gate eligibility remain unestablished.
