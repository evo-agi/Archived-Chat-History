**Codex never started. The first message is the launcher’s deliberate stop; the second is a separate shell shutdown error. Do not install anything or change your shell configuration.**

### What happened

`Codex CLI is not on PATH` means the shell could not resolve the command `codex`. It does **not** establish that the desktop app—or a bundled executable—is absent. In the script I supplied, this check came **before** directory creation and the Codex launch, so neither was reached.

The `shell_session_save…parameter not set` message is consistent with `set -u` encountering an unset variable in your shell’s session-saving hook. **My block did not actually force Bash:** parentheses start a subshell of the current shell. I should have made the interpreter explicit instead of describing it as a Bash script. The exact hook failure is not established from this output alone. [zsh.sourceforge.io](https://zsh.sourceforge.io/Doc/Release/Shell-Grammar.html)

There is no reason here to edit `.zshrc`, disable session saving, or alter the repositories.

## Use the existing desktop app—without the CLI

The CLI was a means of selecting a neutral starting directory, **not an audit requirement**. OpenAI’s current desktop guidance supports opening a local folder through **Add new project / `Cmd+O`** and starting a **Local / This computer** chat; Git is optional. That provides a no-installation alternative. [OpenAI Help Center](https://help.openai.com/en/articles/20001615-prism-to-codex-migration-guide?utm_source=chatgpt.com)

**First, create one empty directory** by running this single command in Terminal:

```sh
/usr/bin/mktemp -d /private/tmp/rw0-audit-entry.XXXXXX
```

This command does not change shell options or invoke Codex. Copy the directory path it prints.

**Then, in the desktop Codex interface**, use **Add new project / `Cmd+O`** to select that exact directory. Start a **new Local / This computer chat under that folder**—not another chat under Governed Execution Coordinator, not a resumed conversation, and not a Git worktree. [OpenAI Help Center](https://help.openai.com/en/articles/20001615-prism-to-codex-migration-guide?utm_source=chatgpt.com)

Before attaching anything, send this entry check, replacing the one placeholder with the printed path:

```text
SESSION ENTRY CHECK ONLY. No tools or commands are authorized.

Expected working directory:
<exact directory path printed by mktemp>

Using only host-supplied session metadata already visible to you, report:
- the actual working directory;
- any exposed project or repository binding;
- any already-loaded instruction requiring repository bootstrap.

Do not run pwd, Git, a directory listing, file reads, instruction discovery,
or subagents. Do not infer the actual directory from the expected path above.

If the host directory is missing, differs, or the session is bound to a live
repository, return RW0_AUDIT_ENTRY_NOT_ESTABLISHED and stop without tools.

Otherwise return RW0_AUDIT_ENTRY_METADATA_MATCH, report the actual path and
any remaining unknown binding information, and stop without tools.

No isolation qualification or candidate audit has begun.
```

**Proceed only when the response reports the exact generated directory without a conflicting repository binding and makes no tool call.** Then submit the existing environment-qualification prompt and the same incomplete-audit evidence ZIP in that conversation. No replacement audit mandate or candidate attachment is needed at this stage.

If the app cannot select the neutral folder, or its reported binding still points to Coordinator, stop there rather than creating another repository-bound attempt.

The candidate remains unaccepted; this launcher failure adds neither a candidate defect nor audit coverage. Pasted text

**Sources:** Your terminal output and the supplied launcher; official zsh and OpenAI desktop documentation cited above.  
**Confidence:** High that the launcher stopped before Codex execution; moderate on the precise session-hook cause.
