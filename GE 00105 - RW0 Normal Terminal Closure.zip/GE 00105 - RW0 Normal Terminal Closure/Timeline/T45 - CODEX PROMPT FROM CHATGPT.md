RW0 AUDIT ENVIRONMENT — TIME-BOUND DIAGNOSTIC REPAIR AND LAUNCH DISCRIMINATION

This is the sole operative replacement mandate. Complete it in the SAME neutral
qualification conversation that produced the nt9otbe5 archive. Do not repeat
project setup, start a new conversation, or touch the Coordinator checkout.
This is authorized defensive qualification using owned synthetic state only.

ENGAGEMENT ENVELOPE
CURRENT STATE: The current terminal candidate remains uncommitted/unaccepted at
4691af58ae0ee3107b4e2e9b6b1508032944e357. Paired trusted no-inner-policy controls
passed; restrictive policy v0 and v1 each aborted with SIGABRT. Their log queries
have an unestablished timezone binding. No effective containment is established.
RECIPIENT: Same neutral reviewer; expected host cwd
/private/tmp/rw0-audit-entry.daLWIE. No implementation conversation.
ATTACHMENTS: None required. Authenticate the exact retained ZIP below.
AUTHORIZED EFFECTS: Inert evidence inspection; new audit-owned diagnostic and
qualification code/policies; narrowly scoped owned-process logging; one explicitly
bounded no-op diagnostic exception. No candidate/repository/host-protection work.
EXPECTED RETURN: One inline result and one compact, reopened evidence ZIP.
PROJECT SNAPSHOT: None.
NEXT ACTION: Return to ChatGPT. Even QUALIFIED stops before candidate execution.

1. ENTRY AND FIXED INPUT

A necessary read of exactly this host-exposed instruction file is permitted only
to load the mandate, with an explicit neutral cwd. Before any other operational
command state the actual host directory, exact input path, exposed project binding
or unknown binding, and effect ceiling. Do not infer actual cwd from this text.
An absent/different host cwd or live repository binding is a stop; do not use pwd,
Git, AGENTS discovery, directory searches or a settings database to investigate.
No subagents. Preserve previous incomplete results and their actual limits.

Exact retained input:
/private/tmp/rw0-audit-entry.daLWIE/rw0-prospective-nt9otbe5/RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_INCOMPLETE_STARTUP_UNRESOLVED_20261028.zip
Bytes: 58,511
SHA-256: 7638da291bf898dc8f0bf61fd0ad40be754674e2cd172f186733e71d5187f91a
A genuinely host-exposed attachment of these same bytes is an alternative, not a
reason to search Downloads. If unavailable, report the exact missing input.

Before payload reads verify regular unencrypted relative normalized unique names,
no traversal/link/special member/casefold or prefix collision, at most 100 members,
10,000,000 bytes per member and 10,000,000 total expansion. Expected 67 members,
139,138 expanded bytes, 66 complete self-excluding manifest rows. Check every
row's path, size, SHA-256, CRC and numeric mode.
Report: QUALIFICATION_REPORT.md, 10,701 bytes,
186d001c84ed15511f941724c5f70b5e49717c02d02990124214f7b0e8f8c588.
Manifest: package/member-manifest.json, 14,343 bytes,
c2e827d938d2146343b1892eaaf98c5f787ff4143392e47d347e5f87d71d583e.
Read the report and relevant sources/results fully as DATA. Do not execute an
archived supervisor, policy, helper or probe. No candidate-history reconstruction.

2. FINDINGS TO PRESERVE AND EXPLICIT METHOD AMENDMENTS

The four retained child outcomes are 0, 0, -6, -6, separate from four supervisor
exits of 0. No failed run establishes target entry or policy installation. The
six per-run pre/post identity entries reconcile. v1 added only the literal
sandbox-exec read allowance; it did not fix startup. Sentinels were not exercised
inside containment. No root cause or effective boundary follows.

D01: sources/own_run_log.py:17-22 calls datetime.fromtimestamp without a timezone,
formats no offset, then invokes log with TZ=UTC. Recorded pairs are:
- PID 3563: 1793242988561345000..1793242988568086000 ns since epoch.
  UTC: 2026-10-29 03:03:08.561345..03:03:08.568086 +00:00.
  Old query: 2026-10-28 23:03:08..23:03:09, no offset, TZ=UTC.
- PID 3651: 1793243029885868000..1793243029893305000 ns since epoch.
  UTC: 2026-10-29 03:03:49.885868..03:03:49.893305 +00:00.
  Old query: 2026-10-28 23:03:49..23:03:50, no offset, TZ=UTC.
The archive does not establish how the installed log command interpreted those
naive arguments. Do not announce a proved four-hour missed query or SIGABRT cause.
The temporal binding is unproved and must be corrected/calibrated.

D02: processID-only predicates are not proof that every causal diagnostic uses
the affected child's PID as its emitting process PID. Empty arrays remain literal
results, not a complete negative OS observation.

This mandate explicitly amends diagnostic scope, NOT acceptance requirements:
A. Corrected reads of the two precisely identified retained owned-run intervals
   are allowed, in addition to new owned-run diagnostics. No other historical
   process/incident search is allowed.
B. One newly authored synthetic OS-log marker and strictly nonce-bound readback
   are allowed to calibrate the diagnostic path. This is a small local OS-logging
   effect, not contact with a product/service/provider endpoint.
C. Exactly one additional-policy no-op control may use this diagnostic-only text:
   (version 1)
   (allow default)
   (deny network*)
   ONLY with the fixed /usr/bin/true target. This is a narrow exception to the
   earlier blanket prohibition of allow-default audit policies. It does not
   disable or override any host/tool protection, adds no privilege, and has no
   candidate, fixture, Python marker, test or qualification credit. Never reuse
   this policy as the execution boundary. Its purpose is to separate the
   sandbox-exec/application path from restrictive-profile dependencies, just as
   the earlier no-inner-policy controls did for trusted targets.
No other protection reduction is authorized. If host policy forbids a diagnostic,
record the refusal; do not route around it or claim that it ran.

3. FRESH OWNED STATE AND RECORDING

Use a new unique task-owned root under the neutral entry directory. Keep prior
roots and ZIPs unchanged. Separate read-only launcher/mock-source, writable
scratch/HOME/TMP, protected evidence and denied-sentinel areas. No candidate files.
Use only existing Python 3.13.4 / pytest 8.4.1 / SQLite 3.49.1; recheck narrowly
with installed metadata, never pytest collection. No dependency installation or
runtime replacement. Preserve host/tool settings. Do not read private Codex state.

All commands use explicit neutral/owned cwd, umask 077, locale C, UTC, credential-
free allowlisted environment, bytecode suppression, null stdin and closed incidental
FDs. Author/inspect new code; retain source and prelaunch SHA-256 for every active
helper, policy and executable, compare after launch. Record argv/cwd/environment,
wall+monotonic instants, parent/supervisor/child PIDs, binary stdout/stderr, deadlines,
exit/signal, target-entry markers, process closure and before/after sentinels.
A supervisor's exit 0 is not a child pass. A timed-out supervisor must not leave
an owned target running; retain PID/group tracking and reap all owned processes.
No core dumps, debugger attachment, global trace or privilege elevation.

4. FIX AND CALIBRATE DIAGNOSTIC TIME BINDING BEFORE POLICY CHANGES

Author a new data-only time helper using integer POSIX seconds/nanoseconds and
explicit timezone-aware UTC values. Never call naive fromtimestamp to generate
query bounds. A formatter/parser round trip must recover the original interval
at its stated precision, with floor/ceiling padding recorded explicitly.

Narrow read-only /usr/bin/log help show (and help for the selected existing OS
logging tool) is allowed to establish INSTALLED syntax. Use explicit offset input
syntax supported by that tool. An output --timezone switch alone is not proof of
input parsing. If offset syntax is unavailable, demonstrate an equivalent
unambiguous conversion with a calibrated local method; otherwise stop that query
path. Do not silently change the clock, timezone settings, environment of the app,
or host logging configuration.

Emit exactly one short, unique, nonsecret audit-owned log marker using an existing
ordinary-user logging facility from a new trusted process. Record actual nonce,
PID, executable, start/end epoch times and stdout marker. This trusted calibration
runs under unchanged host/tool protections, not a claimed qualified inner policy.
It reads no user content and invokes no candidate code. At most one corrected
helper retry is allowed for a specific recorded code defect; no open-ended logging
search. Retain failed attempts without credit.

Retrieve only that nonce in its bounded interval, filtering before output. If the
logging facility reports via another emitting PID, require the exact nonce and
subject association; do not equate emitter and subject without evidence. Verify
timestamps against epoch bounds. No successful query with [] qualifies negative
log evidence. If the calibration marker cannot be retrieved, record that the
negative-query oracle is unavailable; do not compensate with global log collection.

Then issue at most one corrected subject-specific query per retained PID 3563
and 3651 and its exact recorded interval. Bound padding to at most one second
before and two seconds after, with rationale. Use explicit offsets and query
levels needed for diagnostics if the installed tool supports them. Limit output.
An enforcement-reporter query is permitted only if filtered BEFORE output to the
exact subject PID AND known executable (true or sandbox-exec) AND the bounded
interval using supported fields or an explicit delimited message representation.
A global reporter/category query followed by local filtering is prohibited.
Admit causal records only with defensible subject/image/time association; PID
reuse, unreadable/deleted records or empty output must remain limits. Do not search
crash-report directories, read broad archives or reopen the old wrong interval.

Preserve both old [] results as historical data. No new result retroactively
makes the old helper calibrated or identifies which image reached entry.

5. ONE LAUNCHER-PATH DISCRIMINATOR AND AT MOST TWO CAUSAL CORRECTIONS

Run the diagnostic-only policy from section 2C exactly once with /usr/bin/true,
using the same owned cwd/environment/supervision as one fresh no-inner-policy true
baseline. No shell wrapper inside the target, no extra arguments, Python import,
file probe, network probe or candidate payload may use the diagnostic-only policy.
Review and freeze its exact three lines before use. Record both outcomes.

- If the no-inner-policy baseline fails: stop at its exact new runtime failure.
- If sandbox-exec plus diagnostic-only policy also aborts or fails: stop custom
  permission variants. Return INCOMPLETE_ADDITIONAL_POLICY_LAUNCH_UNAVAILABLE,
  reporting what remains unknown. This does not prove universal OS infeasibility
  or authorize bypassing host controls, a different runtime, installation or VM.
- If the diagnostic-only path succeeds: it establishes only that tested launch
  path's viability. It is NOT filesystem/descendant containment or acceptance.
  Return immediately to restrictive policies for any qualification work.

Do not consume variants merely because an allowance exists. Permit at most TWO
new substantive restrictive-profile changes, one named, narrowly bounded runtime
need at a time, supported by an admitted own-run diagnostic or a demonstrable
local dependency. No arbitrary permission guesses. Preserve v0/v1 history and
record each new diff, rationale, exact identity and outcome. Never grant blanket
root/home/tmp content read, whole-/usr/bin read, arbitrary mach*, source/evidence
write or network to make qualification pass. The exception in 2C applies only
to its one inert control, not to these restrictive changes.

If there is no justified correction, close with
INCOMPLETE_RESTRICTIVE_POLICY_CAUSE_UNRESOLVED. Do not issue another indistinguishable
true retry. If the corrected restrictive boundary starts, run the trusted Python
marker under that SAME restrictive boundary, then finish section 6 in this same
engagement without another routine handoff. Preserve actual failures and distinguish
probe defects, startup defects and genuine containment failures.

6. COMPLETE QUALIFICATION ON ONE FINAL RESTRICTIVE BOUNDARY

Qualification still requires policy inspection AND the full observed matrix.
Default-deny spelling alone and named sentinels alone are insufficient.

Runtime/process positives:
- true exits 0; the same installed Python reaches its unique marker and exits 0;
- standard-library SQLite create/transaction/readback using owned synthetic SQL;
- parent, fork child, exec child and fork-then-exec forms relevant to deferred
  tests emit unique markers and are reaped; never claim unobserved descendants.

Filesystem positives and negatives in parent and tested descendants:
- Before containment demonstrate ordinary read/write/create accessibility of
  owned mock-source and denied sentinels. Capture actual bytes/modes first.
- Read allowed source; create/read/update/remove permitted scratch.
- Deny writes to source/launcher and protected evidence; deny content read/write
  of the existing denied sentinel and file creation in its owned denied directory.
- Cover canonical paths and owned symlink/alias forms.
- Distinguish policy/permission errno from ENOENT, bad syntax, OS-mode errors and
  generic exceptions. No real excluded repository/home/credential path probes.
- Review the policy to exclude unrelated content generally, not only a blacklisted
  sentinel. Justify runtime content grants separately from ancestor metadata and
  review process/signal/runtime-IPC permissions. Current broad allowances are not
  automatically accepted by prior passes of trusted targets.

Network in parent and tested descendants:
- Demonstrably executing probes must observe denied loopback bind and connect
  against only owned synthetic endpoints; no external addresses, DNS or host
  services. Use an owned listening peer to discriminate connect denial from an
  absent listener. Any necessary peer setup is confined to this synthetic test.
- Preserve actual errno and policy binding. A refused/absent peer is not a denial
  pass. If existing protections prohibit calibration setup, retain the missing
  control; do not enable networking or substitute a weaker assertion.

Record all sources and pre/post identities, exact invocations, outputs, child
closure and sentinel captures. If effective policy changes during controls, rerun
the entire matrix under its final frozen bytes. Ordinary audit-owned probe defects
may be repaired on new state with prior failures retained. Remove only explicitly
created probe state after evidence retention; preserve all prior roots/inputs.
No generic runner platform/framework is requested.

7. CANDIDATE AND EFFECT CEILING

No candidate ZIP, imports, source extraction, SQL, fixtures, pytest collection or
tests. No live repository/Git/index/refs/config, AGENTS discovery, app settings,
private session stores, installation, privilege escalation, host-protection change,
remote provisioning, real service/provider/ES/Bridge contact, staging, commit,
push, PR, merge, publication, deployment, release or product effect.

Candidate identity only: 4691af58ae0ee3107b4e2e9b6b1508032944e357, 327 paths,
manifest 1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1;
ZIP 48,978,087 bytes / 6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42.
The integrated commit is 61d0330aba1160f7f5e7d9c541a325222d1c61e5.
All A01-A18, two-layer admission/history, witness constructor/alias safety,
F01/O1/S01/A03, physical aliases/proposal/acceptance/posture, SQL/admin, causal,
privacy, independent observer and source/mode controls remain required. Independent
60-case direct and 9,568-case selector-free FULL remain separate unperformed
acceptance gates. Historical writer counts overlap and grant no independent credit.
F03/F05 and all historical process/validation limits remain recorded.

8. RETURN

Return one primary verdict:
RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_QUALIFIED
RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_INCOMPLETE_<PRECISE_REASON>
RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_BLOCKED_<PRECISE_REASON>

Report exact initial bindings and actions; input authentication; UTC query round
trips and calibration; old/new diagnostic results with supported causal scope;
separate no-inner/diagnostic-only/restrictive launch outcomes; every change and
rationale; full final matrix or exact unperformed coverage; runtime, process and
sentinel preservation; cleanup and next boundary. A nonconfining no-op control can
never be called QUALIFIED. Preserve the preceding verdict; no retrospective pass.

Write a complete report before sealing ONE compact safe evidence ZIP containing
its self-excluding member manifest, newly authored helpers and policies, exact
commands, raw outputs and results, source/target/policy identities, UTC calculations,
filtered diagnostics, nonce calibration, captures and effect/cleanup record. Exclude
candidate payloads, databases/sidecars, credentials, core files and unrelated logs.
Reopen and verify all members and return report/ZIP sizes and SHA-256.

On success preserve the workspace and final restrictive runner. Return to ChatGPT
before candidate execution. On failure stop this finite diagnostic branch; do not
expand permissions, restart project setup, or run candidate code without protection.
