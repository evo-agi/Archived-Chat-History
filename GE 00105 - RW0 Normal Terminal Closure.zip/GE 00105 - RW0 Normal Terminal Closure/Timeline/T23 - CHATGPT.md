## Engineering disposition

```text
RW0_NORMAL_TERMINAL_AUDIT_EXECUTION_ENVIRONMENT_REQUIRES_QUALIFICATION
CANDIDATE_UNCHANGED_AND_UNACCEPTED
```

**Do not change the implementation. The next task is to qualify a clean audit workspace and execution boundary—not repeat the full audit immediately.**

The `INCOMPLETE` verdict is appropriate. This engagement authenticated the candidate and reconciled retained records, but established **no new candidate defect and no independent execution credit**. Its first live-checkout read independently prevented compliant acceptance. Pasted text

The preserved subject remains:

```text
Source tree:
4691af58ae0ee3107b4e2e9b6b1508032944e357

Source paths:
327

Source-manifest SHA-256:
1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1
```

## What this result establishes

**Artifact work completed.** The auditor reports authenticating the outer and nested archives, reconstructing the five-stage source lineage, verifying the five-file immediate repair, and replaying both patches. Those observations remain useful evidence; they are not runtime acceptance. Pasted text

**The repair has source-level support, not an independent behavioral pass.** The report confirms that the documents express the two-layer admission/history rule and that the witness constructor visibly checks its representations and returns detached mappings. It did not independently exercise the constructor, aliasing controls, actual connection authorizers, or SQL constraints. Pasted text

**The execution gate never opened.** Even `/usr/bin/true` exited 134 under the selected default-deny profile. The auditor stopped before importing candidate code or running candidate SQL, fixtures, or pytest. The 60 direct and 9,568 FULL results remain reconciled **writer records**, not independent runs. Pasted text Pasted text

That does not establish that the candidate is defective—or that a conforming execution environment is impossible. It establishes that **this particular launch/profile combination did not qualify**. The closeout alone does not establish why it failed.

## Two separate audit problems need different treatment

### 1. The reviewer must start outside the live repository

The first action was again `git status --short --branch` in the expressly excluded Coordinator checkout. Changing directories afterward and excluding its output from candidate evidence cannot make that engagement artifact-only. Nor does the report justify claiming that the live index or source was either preserved or mutated during that interval. Pasted text

The previous mandate already prohibited that exact bootstrap behavior. Repeating the same warning in another full audit is not an adequate corrective action.

**The next conversation must be launched with an empty, neutral, non-repository working folder selected from the outset.** It must not begin with Coordinator selected and then change `cwd`. If the tool surface cannot provide that starting context, the qualification should stop before probing the repository.

Reading metadata for the **three specifically supplied input files** is a separate matter; that is not equivalent to broad Downloads discovery. The excluded live Git read is the demonstrated process violation.

### 2. Effective isolation must be demonstrated before candidate work

The required property is effective filesystem, network, and descendant-process containment—not a particular spelling of a default-deny profile.

A bounded correction to **audit-owned** launcher or policy files is reasonable, provided it preserves the same restrictions and is calibrated. A neutral directory, relocated `HOME`, network-only denial, missing-file error, or process that aborts before entering the probe is not sufficient.

The next task must inspect the actual retained profile and invocation before diagnosing exit 134. It must then establish ordinary execution and meaningful positive/negative controls using **only owned synthetic sentinels and loopback denial probes**. No real excluded checkout, home, credential, or unrelated temporary path should be probed.

I have read the complete supplied closeout and the prior mandate’s entry and isolation requirements. **I have not received or reopened the latest 3,531,883-byte audit-evidence ZIP**, so I am not attributing a specific technical cause to the sandbox failure.

## Next Codex handoff

This is one bounded **environment-qualification task**, not another source reconnaissance, implementation repair, or candidate audit.

| Field | Instruction |
|---|---|
| **RECIPIENT** | A **new independent Codex conversation**, launched in an empty non-repository working folder. |
| **ATTACHMENTS** | Only the incomplete-audit evidence ZIP identified below. |
| **AUTHORIZED EFFECTS** | Inert evidence inspection and minimal audit-owned runtime/isolation probes. No candidate execution or repository action. |
| **EXPECTED RETURN** | One inline qualification result and one compact evidence ZIP containing the actual policy, launcher, probes, commands, and results. |
| **PROJECT SNAPSHOT** | None requested. |
| **NEXT ACTION** | After qualification, continue the cumulative audit in that **same clean reviewer conversation and workspace**, with the unchanged source inputs and complete acceptance obligations. |

Send this **single operative prompt**:

:chatgpt-content-reference{index="8"}[**RW0 normal-terminal audit environment qualification**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Audit_Environment_Qualification_Prompt.txt)

Attach this existing artifact from the **incomplete audit conversation**:

```text
RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_AUDIT_INCOMPLETE_20261028_a0covndn.zip

Bytes:
3,531,883

SHA-256:
5a07f202e2cf14a59674c34f8ca0cfc37664ea4082d925664416dab7cee1337c
```

Its reported location is:

```text
/Users/ds/.codex/rw0-independent-audit-a0covndn/
RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_AUDIT_INCOMPLETE_20261028_a0covndn.zip
```

The archive reportedly contains the full report and 94 manifest-covered members. The qualification prompt authenticates the embedded report by its exact identity; **no separate report, `Pasted text.txt`, candidate ZIP, or historical implementation mandate is needed for this task**. Pasted text

The expected successful disposition is:

```text
RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_QUALIFIED
```

That result would qualify the runner only. It would **not** accept the candidate, close a substantive finding, or authorize candidate execution before the cumulative audit handoff.

## Acceptance requirements remain unchanged

The subsequent audit must still independently address the amended historical-access boundary, witness construction and alias safety, F01/O1/S01/A03, the outstanding A01–A18 controls, SQL/admin behavior, and the complete direct and selector-free FULL gates. The latest report explicitly leaves those execution obligations open. Pasted text

The old whole-operation zero-stop-SELECT criterion remains failed and superseded **only as a requirement**. The historical audit-process deviations remain recorded. Nothing in this runner qualification weakens those distinctions.

Keep the implementation conversation idle. No candidate repair, staging, commit, publication, or new Project snapshot is warranted by this result.

**Sources:** Attached cumulative-audit closeout, cited above; Coordinator_RW0_Normal_Terminal_Historical_Admission_Witness_Independent_Cumulative_Audit_Prompt.txt[previous operative audit mandate](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Historical_Admission_Witness_Independent_Cumulative_Audit_Prompt.txt), particularly its first-action and execution-isolation requirements.

**Confidence:** audit-state classification **0.99**; environment-first sequencing **0.97**. The specific sandbox failure cause and feasibility of the proposed runner remain unverified until qualification.
