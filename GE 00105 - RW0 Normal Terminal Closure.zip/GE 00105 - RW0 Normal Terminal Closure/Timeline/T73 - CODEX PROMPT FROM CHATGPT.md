RW0 NORMAL TERMINAL CLOSURE — TEST/RUNTIME COMPATIBILITY AND CUMULATIVE AUDIT COMPLETION

This is the sole complete operative replacement prompt. Continue the SAME neutral
independent audit from T, final-77be0d42f6. Do not restart repository reconnaissance,
source-history mapping, implementation or general sandbox design. This task makes
three EXPLICIT, FINITE prospective audit-boundary amendments below. No source,
product-contract, test assertion, suite inventory or acceptance obligation changes.

ENGAGEMENT ENVELOPE
CURRENT STATE: Candidate 4691af58ae0ee3107b4e2e9b6b1508032944e357 is uncommitted and
unaccepted. T proves direct 60/60, FULL 9469/9568 with 99 failed calls, and preserves
R/S causal evidence. Its 56-row ledger has 33 open rows: G01-G03 plus 30 substantive
rows. Old INCOMPLETE results remain historical. No candidate defect is established
by the currently observed three classes of first failure.
RECIPIENT: SAME neutral independent reviewer conversation that produced
final-77be0d42f6. Expected host cwd /private/tmp/rw0-audit-entry.daLWIE.
ATTACHMENTS: NONE required. Exact retained T/A/B/C/E/Q paths are below. T embeds S,
which embeds R; use those copies rather than demanding duplicate attachments.
AUTHORIZED EFFECTS: Artifact inspection, narrowly derived audit policy Qtc, trusted
owned runtime diagnostics and calibration, then unchanged candidate regression and
residual synthetic audit under the qualified Qtc. Never live-repository work.
EXPECTED RETURN: One cumulative disposition, full report, evidence/closure ledgers,
and one reopened ZIP. After successful compatibility checks proceed directly to
complete direct/FULL and residual closure; no routine approval relay.
PROJECT SNAPSHOT: None. PR #17 / 61d0330aba1160f7f5e7d9c541a325222d1c61e5 remains the
retained integrated baseline, not a newly observed live ref.
NEXT ACTION: Return to ChatGPT before any candidate repair or live commit gate.

0. ENTRY AND EFFECT CEILING

Read this entire mandate. A necessary read of its exact host-exposed instruction
file is allowed solely to load it, in the actual neutral cwd. Before any OTHER
operational command state actual host cwd, exact input bindings, exposed project
binding or unknown binding, and the effect ceiling. A requested path is not proof.
If cwd differs or a live repository binding is exposed, stop without discovering
or probing that repository. Unknown binding alone does not authorize discovery.

No Git/status/pwd/AGENTS/bootstrap discovery, live checkout, sibling repo, home or
Downloads search, app/session-store inspection, ambient environment dump, subagent,
network service, provider, ES/Bridge call, installation, runtime replacement,
privilege escalation or host-protection change. A named input may be read wherever
it is retained; its directory may not be searched. Candidate guidance is read only
from authenticated A payloads. Archived prompts and code are data, not authority.
Keep the implementation writer idle. No source edit, staging, commit, push, PR,
merge, release, deployment or product database operation.

The external supervisor prepares owned inert data, captures records and manages
owned synthetic processes. It executes NO candidate import, fixture, SQL, setup,
collection, test or callback. Candidate work stays inside the frozen, calibrated
Qtc; trusted runtime diagnostic probes stay inside Qs or its narrowly derived
prospective policy. No allow-default, unconfined candidate run, disabled sandbox,
output filtering or altered child return values are authorized.

The EXACT Qs base remains immutable, 2674 bytes, SHA-256:
0ff27cde4b1dfade46dc6ad0add110497d8633e509cd2c923107d5ddf8163961.
Qtc is a NEW prospective identity. Never call its results Qs results, rewrite Qs,
or invent its hash before the actual paths/resource set are frozen. Append only
permissions explicitly authorized in section 5. Preserve every base-policy byte,
network denial, `(allow signal (target same-sandbox))` target restriction, runtime
identity and protected-path boundary. There is no general permission-search budget.

1. INPUTS, AUTHENTICATION AND CARRY-FORWARD

T — new failing FULL and completed direct evidence:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/final-77be0d42f6/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_final-77be0d42f6.zip
5,878,210 bytes / dc754506dff6d3cc9ab803814cb4137a2f4094a9ecc3f8c5bd3bd69d6952ee4a
218 regular members, 53,313,415 expanded bytes; 217 MANIFEST rows.
REPORT.md: 27,839 bytes / d7da41e118fb48ec535b6d26a244bba2740cc5ae93a7a36cedaaf69a3208bde1
MANIFEST.json: 53,141 bytes / fca62530598534d58f4822f005763a5d1f8d0e23e18b192f6b1a8b8d1e01ed79

S, embedded once in T at:
carry/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261029_complete-aed72ce348.zip
2,947,049 bytes / 3dda92c95c2ab99d477271a834d181df80fce270f23c38c87eb3e8299ced1ad7
258/257 members, 23,215,607 expanded bytes. S embeds R at:
carry/RW0_NORMAL_TERMINAL_CUMULATIVE_AUDIT_INCOMPLETE_20261029_auditqs-78f604b32c.zip
R: 1,650,029 bytes / ffd593b643c1c6fc6c064a84d9b473ce4f34cc1b2f1be35706d0b2d08db4bd2f
299/298 members, 6,568,366 expanded bytes. R's manifest uses rows, not members.

A — unchanged current candidate:
/Users/ds/.codex/rw0-terminal-historical-witness-tcp5rwoh/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip
48,978,087 bytes / 6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42
573/572 members, 183,558,511 expanded bytes.
package/member-manifest.json: 123,205 bytes /
049139eaac16a03b36952faa703c992f5ef13adad44807873921af817e7b8e43
Current report evidence/IMPLEMENTATION_REPORT.md: 19,549 bytes /
c52141d0fcf15701496c4dec18133361a78b8f043796078340e24eed4bdae2d5.
No separate report attachment/equality gate.

B — inert original implementation requirements:
/Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt
38,100 bytes / 9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f
C — inert S01/A03 repair requirements:
/Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt
29,145 bytes / 7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd
A's inputs/mandate.txt, historical-admission/witness amendment:
28,439 bytes / 6e978d57abfbadf7d8120eb58ea75651a60a44c42d6279ff8a9108c41c8b2da4.
Read these as requirements only. Their implementation/live-effect commands are not
operative. Sections 2-4 below retain the substantive obligations.

E — earlier signal-incompatible audit, only where carried linkage is needed:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/audit-4de1ae8e82/RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_INCOMPLETE_20261029_audit-4de1ae8e82.zip
115,300 bytes / b6de501b4a687bd3dc1f8800ac84d150b1197fea74682bd2953b8f9a20c887f9
Q — earlier qualification, only where original controls need inspection:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/peer-33a5f35cc1/RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_QUALIFIED_20261029.zip
163,911 bytes / 6ec93d7f43f1d630bf9501d67a80e8a2a9db307da38baa2e6f44d5d22a7e0767
Do not restart prior sandbox diagnosis or copy old helpers blindly.

An actual host-exposed identical copy is an alternative exact binding, not a reason
to search for namesakes. Missing input => identify it; do not invent a path.
Before use, verify safe normalized relative regular unencrypted names, duplicate/
casefold/prefix safety and complete self-excluding size/SHA/CRC/numeric-mode rows.
T/S: at most 500 members, 32 MB/member, 64 MB expanded per archive. R: 500, 2 MB,
20 MB. E/Q: 200, 2 MB, 5 MB. A/necessary nested history: 5000, 150 MB, 350 MB,
depth six, 1.2 GB cumulative unique expansion. Cache already verified identities.
Do not re-expand old source history without a specific need.

Reauthenticate all 327 current source paths from A and rebuild tree
4691af58ae0ee3107b4e2e9b6b1508032944e357 without Git. Final-C/final-D/postcleanup
canonical manifests are byte-identical, 109,923 bytes each, SHA-256
1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1.
Preserve 326 OS 0644 rows and tests/test_c2b3_private_atomic_program_initialization.py
at OS 0600; all Git 100644. SQL 0008 is 30,178 bytes /
a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254.
The test-created src/ge_nwp_coordinator/_rw0_d1_probe_temp.py is NOT in A's inventory.
All 327 existing files stay policy-read-only. No 0009 or product fixture repair.

1.1 Receiving findings that must not be lost

ChatGPT data-only inspection authenticated T/S/R/A, rebuilt A and reconciled T's
four initial plus eighteen complete launch before/after source captures. The four
postcleanup observations are summaries, NOT four extra full-row captures. All nine
launch helper bindings are represented by archived exact bytes; runtime binaries
are recorded host observations, not supplied payloads.

Direct: 60 collected/called/JUnit IDs in exact order, 60 passed calls, all 180
phases passed, zero warnings, exit 0. FULL: 9568 exact ordered IDs, 9469 passed,
99 failed calls, all setups/teardowns passed, only the three specified fork warnings,
exit 1 and no timeout. Preserve this completed FAIL; do not relabel interruption,
no-execution, or an accepted pass. Direct retains its Qs scope.

Independent first-failure grouping from the actual JUnit:
- 93 cases at tests/test_c2b0_durable_state_contract.py:8351, generated mutant helper.
- FOUR cases at :8447, a different generated checker helper.
- ONE at :16749, successful child collection but nonempty stderr.
- ONE at tests/test_rw0_d1_process_supervisor.py:120, denied temporary-module write.
The same terminal notice occurs in both generated-helper groups and is independently
asserted absent after collection. Fixing collection alone can expose the next
stderr assertion; do not declare all 97 resolved from a changed error message.

T's one representative nested diagnostic observed EPERM in os.scandir of the owned
policy root. The common-path explanation for the other 96 is still inference,
including all four checker-helper cases. Preserve individual original observations;
exercise at least one case from EACH helper before generalizing. Do not execute
T's diagnostic with its old absolute GENERATED path: T cleanup removed the scratch
fixtures. Reconstruct specimens through the unchanged actual tests in new state.

The dedicated oracle's env at :16711-16717 and generated helpers' env at :8340-8345
(and checker equivalent) replace the environment with five explicit keys. Outer
TERM/HOME additions do not automatically reach them. No stderr filtering, monkeypatch
of the child's env/CompletedProcess, disabled readline/pdb plugin, PYTEST_ADDOPTS
injection, altered rootdir arguments or candidate-source edits are permitted.

R/S proof carries at its exact predicates. C4 remains complete at normalized scope:
seven blocks, 28,910 wrapper/authorizer events and 28,388 SQL classifications.
Do not automatically rerun C4 or the whole causal program. T adds three bounded
causal probes (one call each) and one diagnostic; eighteen ledger rows gain bounded
proof, not eighteen uniquely executed pytest cases. Map every claimed closure to
actual setup, reached predicate, versioned helper and result. Retained writer
passes are DATA, not replacements for independent validation.

1.2 Residual ledger: preserve exact IDs and resolve without scope inflation

T/audit/evidence/RESIDUAL_LEDGER.json: 56 rows, SHA-256
fffc8d2f50046c1fa8df3b0f1d63c1c16348e2f628d5c07dd3d6c6d0b4bbcd56.
T/audit/evidence/RESIDUAL_RESULTS.json has 33 mandatory-open rows: G01-G03 are the
three runtime/test-compatibility rows; the following THIRTY are substantive.
- C1A01: wrong selected acceptance reference [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C1A02: missing selected acceptance fact [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C1A03: foreign selected acceptance lineage/decision/digest [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C1A04: legitimate unrelated acceptance fact coexists in the same owned managed store [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C1B03: graph role/cardinality/order and self-digest exclusion [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C1B04: repeated-column equality and alias disagreement [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C1B05: remaining P0/phase/Section41/C1/V22/P1 observation and evidence associations beyond source3 [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C2A04: first physical match or exact earlier-match implication for rw0_terminal_contexts.p1_decision_ref [prior: carried_occupancy_only_first_match_open].
- C2A05: first physical match or exact earlier-match implication for rw0_terminal_outcomes.outcome_value_ref [prior: carried_occupancy_only_first_match_open].
- C2A06: first physical match or exact earlier-match implication for rw0_terminal_outcomes.phase_basis_ref [prior: carried_occupancy_only_first_match_open].
- C2A07: first physical match or exact earlier-match implication for rw0_terminal_outcomes.decision_ref [prior: carried_occupancy_only_first_match_open].
- C2A08: first physical match or exact earlier-match implication for rw0_terminal_results.result_ref [prior: carried_occupancy_only_first_match_open].
- C2A09: first physical match or exact earlier-match implication for rw0_terminal_results.outcome_value_ref [prior: source_schema_implication_only].
- C2A10: first physical match or exact earlier-match implication for rw0_terminal_receipts.receipt_ref [prior: carried_occupancy_only_first_match_open].
- C2A11: first physical match or exact earlier-match implication for rw0_terminal_receipts.mutation_ref [prior: carried_occupancy_only_first_match_open].
- C2A12: first physical match or exact earlier-match implication for rw0_terminal_receipts.family_route [prior: carried_occupancy_only_first_match_open].
- C2A13: first physical match or exact earlier-match implication for rw0_terminal_receipts.phase_basis_ref [prior: carried_occupancy_only_first_match_open].
- C2A14: first physical match or exact earlier-match implication for rw0_terminal_receipts.p1_decision_ref [prior: carried_occupancy_only_first_match_open].
- C2A15: first physical match or exact earlier-match implication for rw0_terminal_receipts.context_ref [prior: source_schema_implication_only].
- C2A16: first physical match or exact earlier-match implication for rw0_terminal_receipts.outcome_value_ref [prior: source_schema_implication_only].
- C2A17: first physical match or exact earlier-match implication for rw0_terminal_receipts.result_ref [prior: source_schema_implication_only].
- C2A19: damaged self-digest family refuses exact/winner and stays unresolved [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C2A20: foreign complete winner and original absence exclusion classifications [prior: carried_independent_partial].
- C2B11: stale in-memory lease versus durable issuance and closed session [prior: carried_independent_partial].
- C2B12: receipt-last boundary and second readback failure/rollback [prior: carried_independent_partial].
- C2B13: recovery cleanup uncertainty and no automatic retry [prior: carried_independent_partial].
- C3A02: remaining context FK and unique route predicates with independent unoccupied targets [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C3A03: remaining outcome FK, unique and nullable pair predicates [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C3A04: remaining result FK/composite and route predicates [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C3A05: remaining receipt FK/unique/composite/profile/blob predicates [prior: open_not_attempted_after_fixed_FULL_incompatibility].

Preserve all 56 rows and their history. Do not reset supported rows to open merely
because the runner changes, expand finite predicates into an arbitrary Cartesian
matrix, or close a reachable missing case using FULL alone. Make exact invariant
arguments for genuinely impossible first-match specimens; constraints that imply
an earlier match in a complete family do not automatically settle damaged/partial
families. Unrelated acceptance means a legitimate distinct subject in the SAME
owned managed STORE, not the same hardcoded helper chain. A replan mismatch does
not require a cryptographic collision. Ordinary audit-fixture difficulty is not
an architecture decision or permission to skip work.

T's new isolated receipt result-pair FK succeeds under intact guards and FK ON;
C3A01 no longer needs the formerly masked fixture. Routes 1-3, exact disclosure/
assertion/preassignment cases, and ten actual current-owner SELECT-denial versus
malformed-row cases carry within their stated scope. Raw-index/checkpoint/failed
artifact classifications remain data-only; do not dump their private contents or
certify missing historical writer-observer code.

1.3 Execution order for this engagement

(1) Reauthenticate and inspect. (2) Resolve only the three known compatibility seams
within section 5's explicit authorization. (3) Freeze/review/calibrate one final
Qtc, then run representative actual tests and the exact 99-failure diagnostic set.
(4) If compatible, complete fresh direct and selector-free FULL under that SAME
policy before further custom residual authoring. (5) Finish residual substantive
rows; reconcile cumulative A01-A18 and final suites for the verdict.

No further routine relay follows a successful gate. Do not rerun a long FULL with
a known unsafe dependency, containment failure, source drift or material candidate
defect. A remaining coverage row alone is not such a defect. A real new candidate
failure is BLOCKED; an unmet runner/evidence requirement is INCOMPLETE. All previous
results stay attributed to their actual source/policy/time scopes.

2. SUBSTANTIVE REVIEW — THE EXPLICIT TWO-LAYER AMENDMENT

The earlier whole-operation zero-current-stop-SELECT criterion failed under the
old mandate. That blocked result remains true. The engineering decision is to
preserve mandatory shared storage safety, not to skip it to satisfy a terminal
history test. The current candidate is judged against the following amendment:

Layer 1: existing operational admission remains mandatory. Session/process/thread/
lease validity, database binding/custody, BEGIN IMMEDIATE, exact managed schema,
history/catalog/posture and invariants, writer ownership/fencing, and current
protected disclosure remain intact. The existing global_stop_current singleton
shape validator may read that current row only for managed-store validity.
Valid active/clear status, version, timestamp and directive identifiers must not
be compared with saved terminal stop or turned into current effect permission.
Denied/unreadable/malformed managed state may prevent disclosure or leave recovery
unresolved. It must not be misclassified as stale terminal history or definitely
absent original execution. No cache, successful-assessment stub, invariant-skip
flag, alternate connection/controller, or production validator weakening.

Layer 2: historical checked read, receipt-present replay and recovery use saved
full postimages/stop and checked immutable predecessors after admission/fencing.
The five current-head tables are not consulted during the historical operation.
Current-stop reads are permitted only at the existing shared invariant check,
not as a general table-read exemption or later semantic terminal query. Receipt
is first TERMINAL-FAMILY lookup, not first SQL statement. Exact original result,
time, graph, receipt, source associations, protected disclosure, immutable
acceptance binding, complete competing-winner/absence proof and uncertainty
classifications remain required. Historical operations do not require recording
permission or renewed acceptance-unclaimed eligibility. Fresh receipt-miss
recording retains actual current five-head/stop checks unchanged.

This amends only the overbroad current-stop-query requirement. It is not a waiver
of the constructor defect, five-head independence, disclosure, SQL grammar,
transaction safety, audit isolation, or other cumulative acceptance controls.
Verify the two owning documents state the distinction and preserve the old
failure as history; do not create another silent interpretation of either layer.

Inspect at minimum the complete changed witness module, changed tests and docs,
full terminal contracts/rows/plan/SQLite owner, and actual shared admission call
chain (not only wrapper names). Current anchors:
  sqlite_transition_transaction.py:2759–2779,4753–4773
  sqlite_migration.py:2477–2523
  .docs/rw0-terminal-outcome-physical-closure.md:177–220
  .docs/sqlite-operations-and-recovery.md:722–730.
Python basenames are under source/src/ge_nwp_coordinator/; docs under source/.

2.1 Independently test the repaired constructor and mutable aliasing

TerminalHeadWitness at _rw0_terminal_head_witness.py:48–96 must validate ordinary
construction, not only checked factories. Independently test valid direct/factory
triples for accept and replan and all five typed owner roles (8/9/41/9/8 fields,
valid nulls, self-digests). Exact bytes, outer tuples, dictionaries, keys and
scalar types precede hostile comparison/coercion. Bytes, full rows and compact
coordinates must match rather than silently replacing invalid supplied parts.

Require negative controls for the previous malformed type triple and b'{}'/empty
postimages, bytes/list/tuple/dict/string/int subclasses, bool-as-int, wrong arity,
missing/extra/reordered roles or fields, wrong schema/digest, noncanonical and
oversize bytes, and valid canonical bytes paired with DIFFERENT valid rows or
projections. Calibrate a shared/per-instance hostile equality counter, clear it,
and verify zero hostile calls per invalid construction. Preserve built-in
positives and process-control propagation.

Mutate caller-owned maps and separately returned maps, then re-read both views
and canonical bytes and run normal downstream verification. They must remain
checked and unchanged. No unvalidated object token/factory escape or recursion.
Do not demand security against arbitrary reflection/object.__setattr__; that is
not the selected boundary. Verify unchanged wire fields/schema/digest domains
and valid consumer behavior, including exact original P1 replan operands.

2.2 Independently prove complete-operation phase behavior

Use real private WriterSession read, receipt-present record/replay and recovery,
not just a terminal helper. Trace and attach observation/denial at the actual
acquisition/controller opener aliases and account for every operation connection.
The candidate observer labels the full managed wrapper; independently establish
which SQL is genuinely in _verify_global_stop_current_shape. A phase label alone
does not prove shape-only use or permit arbitrary managed-phase stop semantics.

Observe real unchanged validator, ownership-read and issuance/fencing functions;
observation wrappers must call the real function and return its actual result.
Do not replace admission with a successful assessment or patch the predicate
being proved. Capture connection, phase, table/column and allow/deny results.
Calibrate each attached authorizer with owned allowed and intentionally denied
queries. Trace acquisition separately, including any connection work before the
observer attachment, and prove it cannot hide a five-head/later-stop lookup.
A zero-callback claim at the wrong alias is invalid. Column callback counts are
not SQL-statement counts or a fixed product invariant.

Required current-byte controls:
- real fenced accept and replan commits, then coherent later movement of every
  head and valid active/clear stop fixtures; under the layered denial policy,
  exact read/replay/recovery preserve original result/time/witness/graph/receipt
  and acceptance facts without new terminal or protected-row movement;
- original absence with positive/negative old-execution exclusion; complete
  compatible and incompatible competing winners under that same policy;
- deny the ACTUAL managed-stop read during admission: safe operational refusal
  before protected terminal-family handling, recovery unresolved where the
  unchanged controller so classifies; no no-write mislabel as stale history,
  definite absence, hidden retry, committed result or protected disclosure;
- malformed actual stop row or real query-return tuple, with validators intact:
  integrity failure rather than ordinary currentness; fault removal restores
  valid operation; bound process-control behavior remains unchanged;
- fresh receipt miss reads all five actual heads and stop. Stale expectations
  conflict without writes; correctly expected valid changed stop follows the
  current normal-record rule without conferring executable permission;
- denied/expired/foreign/malformed disclosure, closed/stale/fenced session and
  unavailable managed store remain non-disclosing. Fresh recording permission
  stays separate from historical protected disclosure and stop shape.

All synthetic later states/fault seams must be described as such. Do not call
a direct fixture UPDATE a newly supported product operator transition.

3. COMPLETE CUMULATIVE A01–A18 REGISTER AND CAUSAL OBLIGATIONS

Review the entire baseline-to-current terminal change, not only the five-file
repair. Supply exact archive-relative source/doc/test/SQL coordinates, severity,
and evidence class for every row: contract/current code, inspected test design,
retained record, independent execution, inference or limit. Unchanged bytes and
prior passes do not automatically discharge current mandatory controls.

A01 Authority: exactly five private normal terminal facts, separate from P1
 decision/acceptance, standing-policy grants, source facts and executable
 permission. No cancel closure, live supplier/contact, ES/Bridge/Git effect,
 service/scheduler/autonomy or publication authority.
A02 Preservation: legacy terminal V1/four validators, P0/P1 meaning, WorkSpec,
 Decision Basis/command-digest v2, preassignments, D1/D2, generic receipt, public
 StateStore/package exports unchanged. Audit original shared catalog/controller/
 writer-session terminal integration even though this immediate repair froze it.
A03 Grammar/types: closed command/context/outcome/row/result/recovery/witness
 schemas, exact built-ins before equality, canonical UTF-8/JSON and duplicate
 rejection, bool-as-int, safe refs/digests/calendar time, budgets and null pairs.
 Include direct constructors, factory consistency and aliasing; resolve A03/O1.
A04 Identity graph: independent domains/acyclic preimages, four sibling refs and
 route, optional assertions bound in command digest but not preassignments,
 graph role/cardinality/order, self-digest exclusion and repeated-column equality.
A05 Original operands: original P1 command and private replan operand transient;
 complete checked predecessor association required. Missing/inconsistent private
 content cannot be reconstructed from a safe digest or yield false certainty.
A06 Source association: actual checked P0/phase/Section41 A/C1 rank15/V22/P1
 chain and validation/review/proposal/result-set/observation relationships;
 membership counts or digest strings do not independently establish ownership.
A07 Acceptance: bind existing immutable acceptance only for accept; never create,
 mutate or replenish it. Wrong/missing/foreign facts reject. Legitimate unrelated
 facts must coexist without preventing another allowed terminal branch. No
 historical acceptance-unclaimed recheck.
A08 Heads/stop: observed full five-row witness, source/adapters/digests/links,
 replan historical P1 postimages, fresh actual currentness and stop facts; prove
 the precise two-layer amendment, not the withdrawn zero-stop-read property.
A09 Transaction: existing fenced lease/capability/controller; receipt-first
 terminal lookup; one captured time; protected posture/source/current/route
 ordering; context/outcome/result readback, receipt last, capability invalidation,
 one commit attempt, rollback/cleanup uncertainty. No application-head/stop/
 decision/effect update by terminal closure.
A10 Read/replay: original complete result/time/graph/receipt and source/witness
 reauthentication; current protected disclosure with mandatory store admission;
 no five-current-head or later semantic stop query, cognition/process rerun,
 fresh recording permission or acceptance-eligibility requirement.
A11 Recovery: complete exact original family or exhaustive original absence and
 exclusion, or complete compatible winner, only. Partial/foreign/damaged/aliased/
 incompatible families unresolved. No winner result disclosure, hidden retry,
 fragment repair or durable private-template fallback.
A12 Error/cleanup: failed or malformed reads stay operational/integrity, valid
 actual drift stays currentness. Stale/closed/fenced sessions, pre/postcommit,
 applied-commit/lost-return and cleanup uncertainty, KeyboardInterrupt/SystemExit/
 GeneratorExit propagation at the actual fresh/read/recovery/cleanup seams.
A13 Schema/admin: four STRICT immutable normal-only tables/eight guards;
 timestamp grammar, FK/unique/composite links/phase/decision/route occupancy,
 nullable pairs, blob bounds, zero seeds, current catalog/checksum/generation 2;
 exact fresh/prefix migration and old-binary/obsolete-0008/partial/unknown refusal.
A14 Connected normals: actual preseal source variations through real P0/D1/D2/
 Section41/C1/V22/P1/terminal owners; five distinct normal positives and detached
 negative; read/replay/recovery and no forbidden contact or protected-row change.
A15 Docs/assurance: cumulative current-versus-historical status, explicit amendment
 and private scope; fixed source/hash/AST/import/schema consumers and predecessor
 reconstruction retained; no dynamic oracle, skip/xfail or broad guard stripping.
A16 Privacy/artifacts: complete postimages remain safe owner metadata; no private
 replan text, raw capsule/prompts/process results, handles/PIDs/credentials in
 terminal rows or unsafe errors. Grammar review plus independently observed
 canaries; classify raw-index metadata, checkpoints and failed artifacts.
A17 Retained evidence: exact input/source/patch/commands/env/observer outputs/
 JUnit/IDs/warnings/captures and overlapping counts; limits in section 4 below.
 No writer record or causal-register label is independent execution.
A18 Independent validation: reached current-source causal probes and direct
 suite, independent SQL/admin controls, selector-free collection/FULL completed
 with exact IDs, outcomes, warnings and source-mode preservation. No live-state
 or production-readiness inference.

The following controls remain mandatory, including previously unfinished ones:

(a) S01 full-witness family: for EACH role, check complete field capture, valid
 nullable values, supported maximum witness bound, bad owner self-digest, valid
 self-digest with wrong immutable predecessor, wrong owner/link, and actual fresh
 head movement versus changed caller expectations. Use fully resealed synthetic
 histories so owner/context/outcome/result/graph/receipt digests are internally
 valid and the real relationship predicate is reached. Pair every resealer with
 a valid family built the same way. Restore ordinary verification for the actual
 read/replay/recovery. Prior program-only evidence is not five-role proof.
 No truncated witness, v1 fallback, desired-row synthesis or current-row backfill.

(b) Source/operand/acceptance: fully resealed detached validation, review,
 source-invocation and proposal associations, including a DISTINCT forged V22
 proposal reference rather than only a proposal digest; wrong/missing/foreign
 acceptance; LEGITIMATE unrelated acceptance-fact coexistence; inconsistent
 private replan content sharing a claimed safe identity across record/read/
 replay/recovery; no new process or private-text persistence. The single-chain
 fixture's inability to construct an unrelated fact is not proof of impossibility.
 Build coherent independent synthetic state through checked owners, or document
 exact invariant proof and the remaining limitation. Do not credit an incoherent
 split-reader or early FK/digest failure as the intended relationship test.

(c) Disclosure/recording: all selected finite posture predicates, including
 positive, denied, expired, malformed, foreign-bound and absent protected subject;
 old-execution-excluded True/False; truthful claimed False/None after accepted
 P1. Fresh write needs recording AND disclosure, historical operations disclosure
 only; command reuse/assertion mismatch cannot disclose a protected result.
 Complete the expired/malformed/foreign/protected-absence matrix rather than
 inheriting earlier positive/negative permission examples.

(d) Physical routes: derive all original occupancy routes from the checked
 code (the preceding audit identified 17). Seed EACH route physically in a
 separate owned coherent scenario, with valid positives and relevant partial,
 foreign or damaged family states. Mocking query return values alone is not
 physical occupancy evidence. Check exact/winner/absence classifications and
 no winner disclosure or retry. If a route is not representable under an owner
 invariant, prove that with exact schema/contract and record the scope; do not
 invent an invalid row as a legitimate winner or silently drop the obligation.

(e) Transaction and error matrix: faults after each of the four inserts,
 result/receipt readback, receipt-last boundaries, precommit rejection,
 one applied commit with lost return, postcommit and recovery cleanup uncertainty;
 stale lease/issuance, closed and fenced sessions; actual denied SELECT versus
 malformed selected rows across current owners; all three process-control
 exceptions at meaningful fresh/read/recovery/cleanup seams. Assert target
 rows, committed bytes, protected-state nonmovement, and actual injection hits.
 No hidden second commit or automatic retry.

(f) F01/O1 regression: independently exercise raw SQL and row construction,
 not only planner success. Use otherwise valid parent/related state, paired
 valid inserts, independent negative self-digests and the repaired existing
 _time owner. Cover invalid month/day/leap-century/year-zero/time overflow,
 canonical-format deviations, Unicode digits, embedded NUL/whitespace/nontext,
 NULL handling and valid year endpoints. Reach all three recorded_at columns;
 outcome has no timestamp. Verify failed predicates are zero/not permissive
 NULL and high-level invalid row/time behavior stays integrity/unresolved.
 Reproduce the old invalid-month predicate only in owned predecessor synthetic
 state as a grammar comparison, never claim an ordinary writer exploit.
 Recalibrate O1 independently before claiming no hostile equality calls.

(g) Five connected normals plus three unsupported cancel shapes and unsupported
 profile. Source variations occur BEFORE real artificial worker/checker/capsule
 sealing, not by relabelling passed evidence afterward. Use inspected fixtures
 for setup only; independent expected branches/facts/errors are required.
 Observe artificial local process/contact limits and privacy canaries.

Run bounded causal controls before a long FULL launch. Do not start/continue
FULL while a known material blocker already prevents acceptance. Independent
controls must state setup validity, actual reached seam, expected result/no-write
predicate, source identity and limits. Candidate tests passing are not separate
independent oracles. Any mandatory control not established remains explicit and
prevents complete acceptance unless an exact supported invariant makes the case
inapplicable; fixture difficulty alone is not such an invariant.

Independent SQL/admin expectations:
  after 0006: 68 tables / 122 triggers / 5 explicit indexes
  after 0007: 74 / 134 / 5
  after 0008: 78 / 142 / 5, application generation 2.
Execute all eight authenticated literals in disposable owned state. Preserve
pre-0008 object SQL/shape; check exact prefix upgrades, no seeds, immutable
update/delete guards, FK/unique/pair/profile/normal/blob/time constraints, and
refusal of old binary, original and S01-era 0008 checksums, old SQL with current
history, missing guard, foreign object and partial/unknown/checksum divergence.
No current schema/contract change, 0009 or product database upgrade is allowed.

4. RETAINED EVIDENCE AND INDEPENDENT VALIDATION

4.1 Reconcile the current writer records as DATA

Paths: evidence/validation/<direct|connected|focused|full>/, gate-summary.json,
phase-read-map.json, supersession-record.json and current source captures.
Require independent parsing of collection observer, execution collection,
setup/call/teardown records, explicit JUnit nodeid properties, actual launch/exit,
stdout/stderr as actually retained, warnings, and four complete source captures
per gate. Do not invent a separate stderr file for a combined log.

Expected current retained gates:
  direct: five complete modules / 60 cases / zero warnings
  connected: one complete module / six cases / zero warnings, inside direct
  focused: 126 complete modules / 8,266 cases / three known warnings
  FULL: selector-free / 9,568 cases / three known warnings.
All narrower sets must be included in FULL; totals overlap and do not add.

Ordered-ID SHA-256 uses UTF-8 JSON array, ensure_ascii=False,
separators=(',', ':'), with NO trailing LF:
 direct 229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467
 connected 81e14e3fa1b85a7be2ea6fafac85974839145bbcb6397e6da0bb1feeba060aac
 focused 419d37ff399689788123583f614a1d8b107ef712e2368ca179cd6e65fbec5104
 FULL 25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9.

All sixteen source captures have the same 105,550-byte envelope, SHA-256
0c0b4017371a798731a63825ac63922c361189e37f5a713f5c4f7ec06e9b32cb.
Require full row equality to the different canonical source-manifest envelope,
its embedded canonical hash, correct final tree and no extra/missing paths.

The retained direct JUnit phase maps report six operation connections, 60
managed-stop column callbacks and six intentional head-denial calibrations
for EACH accept/replan scenario. Independently parse the raw properties. Do not
substitute those counts for actual phase/call-chain verification, or label them
SQL-statement counts. Acquisition has separate test observations.

4.2 Known retained-evidence limits — do not silently fill them

The active external gate_observer source and a launch-bound helper digest are
not retained in the current outer ZIP. Old nested helpers cannot prove that
current code's identity. Writer records can be internally reconciled but their
observer's nonselecting implementation is not thereby inspected. The independent
runs below must use newly audit-authored, retained, inspected and calibrated
observers. Independent fresh evidence can establish current behavior; it does
not retroactively establish the missing writer helper.

The seven-case checkpoint has receipt/JUnit evidence and a different declared
tree 85c9fea24f4f74f358f9cc59a5d323d836a04041; it lacks a complete checkpoint
source payload here. Its historical save/reopen/source-binding claim stays
qualified and supplies no final-byte credit. Similarly, one retained patch
manifest per kind is not proof of two writer runs; independently reconstruct
current endpoint/patch identity rather than invent that history.

These are disclosed retained-evidence/process limits, not automatic production
findings. Determine their actual acceptance impact. Complete current independent
source/runtime evidence must not be replaced with writer claims. Any unmet
mandatory evidence requirement is INCOMPLETE, not a pass by wording change.
Preserve failed/superseded source/test results separately. The prior audit's
live-status/path probes and interrupted FULL remain historical limits.

4.3 Required independent execution gates

Under the explicit prospective section 1.3 scheduling amendment: after current
source inspection/reauthentication, exact final Qtc readiness and observer calibration,
and with no known material candidate defect or unsafe dependency, execute these
complete regression gates BEFORE additional residual custom-fixture work.
All outstanding causal/admin obligations remain required for final ACCEPT:

1. On a fresh exact source copy, collect and run these five COMPLETE modules in
   this order (no node selector):
   tests/test_rw0_terminal_outcome_values.py
   tests/test_rw0_terminal_head_witness_regression.py
   tests/test_sqlite_rw0_terminal_controls.py
   tests/test_sqlite_rw0_terminal_migration_0008.py
   tests/test_sqlite_rw0_terminal_connected.py
   Expected 60 ordered unique passes, including six connected cases.
2. On another fresh exact 327-file copy, independently collect and run the
   repository selector-free FULL. Expected 9,568 ordered unique IDs and passes
   in the retained FULL order. No path, module, node, -k or -m selection.
3. Record collection/execution-collected/call/JUnit identities, explicit JUnit
   nodeid properties from the start, all setup/call/teardown results, warnings
   and real process exits. Require exact ordered agreement and zero failure,
   error, skip, xfail/xpass or failed noncall phase. An invertible JUnit mapping
   is useful supplementary evidence, not a silent substitute for the required
   explicit-property observation.
4. Independently inventory warnings. Direct has none; FULL may have only the
   three known DeprecationWarning multithreaded-fork nodes in
   tests/test_sqlite_b2c_writer_session.py:
   test_operation_guard_close_waits_and_retains_authority_until_exit
   test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
   test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock.
   Owned paths/PIDs may differ; other class/node/message differences require
   investigation, not filtering or suppression.
5. Capture complete raw bytes/modes/extra-file inventory immediately before and
   after collection AND before and after execution, with source-tree rebuilds.
   All 327 endpoints and modes must remain unchanged. At every boundary capture there must be no generated extras; only the prospective, exact-path transient fixture exception in section 5 is allowed during the inspected D1 test.
6. Audit probes remain outside candidate discovery and separately counted. An
   independent focused 8,266-case rerun is unnecessary if exact FULL inclusion
   is proven; do not claim one ran. No writer FULL or earlier audit count can
   replace the independent completed FULL.

Use recorded equivalents of:
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --collect-only --basetemp=<owned-collect> <complete-direct-modules>
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --basetemp=<owned-run> --junitxml=<owned-junit> <same-direct-modules>
For FULL remove all module/path/node selectors from BOTH commands. Inspect
pytest config, conftest and setup/child-launch seams before import. The observer
may record IDs/outcomes/warnings and add JUnit nodeid properties, but must not
select, reorder, skip, change assertions/results or suppress warnings. Keep its
exact source/digest in the evidence and bind every launch to it.

Do not edit candidate source/tests to get green results. Correct audit-only
parser/fixture/observer mistakes transparently on fresh owned state, retaining
failed attempts. A genuine candidate failure triggers findings, not retries with
weakened oracles. An interrupted FULL gets no complete-pass credit; preserve
actual partial records and absence of final JUnit/observer rather than infer
completion from displayed percentages.

5. FINITE TEST/RUNTIME COMPATIBILITY AMENDMENTS AND EXECUTION

5.1 Owned layout and exactly authorized policy delta

Root remains:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz
Create one new unique suffix under execution, mock_source, scratch, home, tmp,
evidence and denied. Preserve old namespaces and exact inputs. T's old transient
scratch/home/tmp/denied were cleaned; do not assume generated fixtures survived.
New source copies: master, causal, direct, smoke, full, all exact 327-file A.
Sources and helper/observer code are read-only; candidate-produced state/output
is scratch/home/tmp. Protected evidence is not granted to candidate code.

Prospective policy Qtc may append ONLY the following three permission classes to
byte-identical Qs. These are explicit amendments to the former frozen-Qs ceiling.
All other ceilings and substantive tests remain unchanged.

D — Owned common-ancestor directory enumeration:
(allow file-read-data (literal "/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz"))
This allows listing this already owned directory, not recursive reads of evidence,
denied, host home, repository, or unrelated ancestor contents. No subpath read grant
on the policy root; no rootdir/config/test-command rewrite. No new root-level
conftest/pytest.ini/plugin to intercept child collection. Confirm actual child
collection can traverse its selected path while protected sibling contents remain
denied. Directory names are an explicit diagnostic disclosure of audit-owned layout.

W — Two exact transient fixture slots, one in smoke and one in full copy:
<root>/mock_source/<new-id>/smoke/src/ge_nwp_coordinator/_rw0_d1_probe_temp.py
<root>/mock_source/<new-id>/full/src/ge_nwp_coordinator/_rw0_d1_probe_temp.py
Only literal file-write permission on these two absent paths may be appended.
Use the narrow create/data/unlink operation set supported by the boundary; literal
file-write* is the maximum authorized operation family if needed for the existing
test. Never grant a parent/package/source subtree writes, chmod existing sources,
copy source to globally writable scratch, or remap an existing candidate file.
Freeze actual canonical paths before policy construction. Each slot must be absent
from A and absent before/after every collection/execution boundary. The existing
unmodified test alone writes its generated module and unlinks it in finally. The
327 protected files/modes remain immutable throughout; their byte/mode/extras
checks remain exact. Do not precreate the test module, substitute its execution,
or patch Path.write_text, source __file__, or the test's assertions to get a pass.
This is test-produced temporary state, not a new repository file or product module.
Synthetic qualification may use these same owned empty slots, closing/removing
its own fixtures before any candidate operation. Preserve that provenance.

R — Evidence-confirmed installed terminal DATA read, not output suppression:
The exact termcap cause is not yet established. Authorize a bounded diagnostic of
this one runtime seam, and at most TWO read-only terminal-resource policy trials.
All probes run under Qs or a profile containing only D/W and this permitted data
read. No unconfined runtime/candidate execution or installation is necessary.

Start with fixed -I -B Python and a tiny audit-owned script importing standard
readline (and, only if needed to reproduce the same output, pdb). Use owned cwd,
null stdin, bounded wait, raw stdout/stderr and a credential-free environment with
TERM/HOME absent where the unchanged child omits them. Confirm the exact symptom
without source/test imports. Inspect only exact installed runtime modules required
to identify this call chain; do not discover user settings or load candidate code.
A separately authored synthetic pytest file/collection inside owned state may be
used when the minimal stdlib import alone does not reproduce the notice.

Read-only metadata checks are permitted for the exact candidate data paths
/usr/share/terminfo/64/dumb and /usr/share/terminfo/d/dumb and their strict ancestors.
These are hypotheses, not assertions that either exists. If a literal path is a
symlink, inspect the link and canonical target without recursively searching.
Any selected data target must be an existing system-owned, non-user-writable regular
terminal-capability data file within /usr/share/terminfo or its OS Cryptex equivalent,
OR an exact installed terminal data file already under the allowed Python framework.
Do not grant whole /usr/share, /etc, /private/etc, or a user home. Do not fabricate
or install terminal data, modify .editrc/.inputrc, set hidden child environment,
change TERM to bypass behavior, suppress stdout/stderr, disable a pytest component,
or replace readline. The selected final profile may add at most TWO exact existing
terminal data-file reads plus necessary literal ancestor metadata. No recursive
system-terminal subtree or directory-enumeration grant is authorized.

If the exact data dependency cannot be established from those bounded checks,
permit one narrowly filtered OS-log read for newly launched owned runtime probe
PIDs and their actual time interval only: explicit UTC round-trippable bounds,
short startup/shutdown padding, subject PID matching even when the reporter is
kernel/sandbox service, and bounded output. No historical/global log hunt, privileged
trace, user-process probing or unrelated event payloads. A log event is a clue,
not proof until a paired restricted-profile experiment changes the actual symptom.
A named terminal data resource outside the authorized family is a precise stop;
do not extend the grant or search arbitrary host paths.

Require paired raw evidence: old Qs reproduces the notice; the one final minimal
resource delta makes the same runtime import/collection work without the notice,
with actual module/interpreter identities and environment captured. If no supported
solution is found in the finite trials, return INCOMPLETE with the exact attempted
resource, error, and next unresolved fact. Do not consume a generic new permission
budget or call it a candidate defect. Do not run the 99-test/full gate while the
required child stderr assertion is still known incompatible.

External source context only, not installed-binary attestation: Apple's published
libedit terminal_set defaults absent TERM to dumb and emits the notice for a failed
tgetent. Pytest 8.4.1 determine_setup can choose the cwd/test common ancestor;
Dir.collect scans it. These support the diagnostic direction, not a grant to use
web/network or assume the installed code/data is identical to public sources.

5.2 Freeze and qualify the FINAL combined policy

Construct Qtc only after the actual namespace and successful minimal resource set
are known. Retain original Qs, exact appendix/diff, permission rationale, canonical
path/type/owner/mode metadata and system-data hashes, Qtc bytes/hash, and every
failed trial. The Qs prefix must be exact. No additional rule or runtime change.
All candidate diagnostic, direct, FULL and residual launches use the SAME final
Qtc identity; never splice passes from different trial policies into a final pass.

Re-run the original four-role forty-control matrix under Qtc, plus scoped signal
readiness, runtime/SQLite and the changed-seam controls. Reuse inspected calibrated
designs; do not design a new runner framework. Retain actual bind/connect denial
against the same owned nonce-handshaken listener before/after all roles, real
outside and identical-profile nonmember signal exclusions, role/PID/group/session
bindings and observed reaping. No socket-option readiness dependency. No network
or signal permission changed; still prove these boundaries on the final profile.

Keep original source/launcher/evidence/denied write and alias negatives. The new
slot is a separate positive, NOT a waiver of any one of the old forty negatives.
Demonstrate create/write/read/remove only at the two named empty slots. Demonstrate
EPERM/EACCES for writes to actual protected-source sentinels, sibling filenames,
protected evidence, denied content and symlink/hardlink routes into protected
owned targets. Do not probe real repositories or user paths. If the literal slot
rule enables mutation of a protected alias target or requires a parent-wide write
grant, stop rather than widen it. The directory-read addition must not make evidence
or denied content readable. Verify adjacent runtime data outside the selected exact
resource grant remains governed by unchanged policy; no arbitrary system probing.
After calibration both slots are absent and all source rows still match A.

5.3 Diagnose representative tests, then replay the exact failed set

Before a long FULL, run unchanged representative candidate tests for:
- generated mutant helper (:8351), using a node from T's 93-member class;
- generated checker helper (:8447), using a node from T's four-member class;
- dedicated real-oracle empty-stderr assertion (:16749);
- D1 temporary-module sanitized-environment/FD test (:111-145).
Use independent observer binding, complete raw child outcomes and fresh owned state.
Capture actual child collection/execute argv, cwd, environment and stdout/stderr
without changing their values. For diagnostic-only observation, a transparent
subprocess boundary wrapper may call the original with unchanged args and return
the exact original CompletedProcess or exception, retaining safe copies of results.
No altered environment, rootdir, stdout, stderr, return code, test state or assertion.
Retain the wrapper and remove it before final direct/FULL; final gates use only the
nonselecting phase/JUnit observer. Do not pass on a changed but still failing predicate.

Then run the exact 99 failed node IDs, derived from authenticated T JUnit, with no
omission or param expansion changes. This is a fixed diagnostic/regression subset,
not FULL and not an adaptive green selection. Reconcile every original node to its
new outcome and identify any secondary candidate failure exposed after collection.
If a material genuine candidate finding appears, stop acceptance with BLOCKED.
A novel out-of-scope environment dependency stops with INCOMPLETE. Do not broaden
policy, patch candidate tests, substitute ordinary helper success or alter counts.

Only after all compatibility checks and the fixed failing set pass, run fresh
complete direct and selector-free FULL under Qtc per section 4.3. Direct's old Qs
pass remains valid at that scope; the new run binds the corrected runner. Use the
separate fresh direct/full source copies, newly owned state and frozen suite helpers.
The exact ephemeral module exists only during the existing test, never at source
captures or as a sealed source endpoint. No other source-area extra is permitted.
No selective collection, -k/-m, skip, xfail, custom outcome substitution or known
failure filtering in final gates. Expected 60/9568 are identity anchors, not a way
to delete unexpected cases. Retain every actual attempt and stderr without filters.

After these suites, finish all thirty substantive residual rows and other genuinely
open A01-A18 obligations. Preserve supported R/S/T cases; do not repeat all old probes.
A green FULL does not close untested acceptance/source/route/constraint predicates.
Ordinary fixture/observer errors may be corrected in owned state with failed records
retained. Exact invariant arguments can delimit unreachable specimens, never erase
reachable requirements. No routine handoff is needed between these stages.

5.4 Runtime, launch, observer, evidence and cleanup requirements

Fixed entry /Library/Frameworks/Python.framework/Versions/3.13/bin/python3;
expected Python 3.13.4 / pytest 8.4.1 / SQLite 3.49.1. Rehash requested/resolved/native
runtime, policy and exact helper/observer versions before/after launches; classify
runtime changes as a binding limit, not permission to install. Distinguish recorded
binary observations from supplied code. Preserve process-local text-encoding hint
handling; do not modify host settings or secretly inject it into test-owned child env.

Candidate command shape:
/usr/bin/sandbox-exec -f <frozen-Qtc> <fixed-python> -I -B <inspected-bootstrap> <mode>
with explicit owned cwd, umask077, core limit0, null stdin, close_fds=True, pass_fds=(),
owned HOME/TMPDIR/basetemp/output, C locale, UTC, credential-free allowlist,
PYTHONDONTWRITEBYTECODE=1, PYTHONNOUSERSITE=1, PYTEST_DISABLE_PLUGIN_AUTOLOAD=1,
PYTEST_ADDOPTS empty, -p no:cacheprovider. No ambient import roots or suppression.
Bootstrap adds only authenticated source root/src and frozen read-only observer
roots. Candidate-owned children receive exactly their existing source-specified
environment; permitted PYTHONPATH for children is frozen to authenticated roots.

Inspect T's bootstrap/supervisor/observer and actual launch-bound versions before
copying/adapting into new audit-owned helpers. Archived verifiers, packaging and
cleanup scripts must not run wholesale. Preserve the final-suite helper freeze
separately from later causal versions. The observer records, never selects/reorders/
skips/transforms outcomes. Recalibrate it with an intentional synthetic warning.
Use explicit rw0_audit_nodeid properties from the start; record every phase and all
warnings. Standalone selected diagnostic tests are labelled separately from suites.

Choose a bounded FULL timeout from retained successful workload and diagnostic
cost, not the short synthetic timeout or the fast failed subset. Record the limit
before launch. No full pass is inferred from progress percentages. Any interruption
retains actual partial coverage. Do not continue a long FULL with a known material
candidate defect, source drift, containment failure or unsafe dependency.

Capture complete 327-file rows, modes and extras immediately before/after each
collection and each execution; rebuild the fixed tree. Keep final full-row closing
captures as well as summaries. The only transient extra exception is W above and
must be absent at EVERY boundary capture. Runtime/observer manifests and raw outputs
remain source-bound. Candidate-produced provisional JUnit/observer files are scratch,
not protected evidence until the trusted supervisor observes child closure, hashes
and transfers them. The supervisor directly captures raw stdout/stderr and real
exit/signal. In-process instrumentation is not an adversarial attestation authority.

Emergency external termination only for PIDs/groups created/tracked by this audit;
it cannot substitute for a candidate cleanup success. Track/reap/close owned children
and synthetic peers before evidence transfer and source after-capture. Retain exact
cleanup effects without a universal unobserved-descendant claim. Preserve old roots,
inputs, source copies and protected evidence. Remove only newly owned transient state
after record retention; classify actual pyc/DB sidecars/FIFOs before cleanup without
dumping sensitive content. No live product state or broad filesystem inventory.

6. DISPOSITION, FULL LEDGER AND DELIVERY

Preserve the exact earlier failing FULL and direct pass. T's claims are not silently
upgraded by a corrected runner. Build one cumulative A01-A18 and 56-row ledger with
carried independent proof, carried data/static inspection, new proof, exact invariant
arguments, and unresolved gaps. After resolving G01-G03, thirty substantive rows
still require closure; do not count a policy fix as a product proof.

Primary verdict options:
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED
AUDIT_PROVENANCE_MISMATCH
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE

Acceptance requires exact source, compliant effects, enforced final Qtc, complete
supported substantive A01-A18/causal/admin/F01/O1/S01/A03 requirements and corrected
historical relation, plus complete zero-failure independent direct/FULL with exact
IDs, phases, warnings and source/mode preservation. No new candidate publication,
terminal live-authority or production-readiness claim. F03/F05 stay inherited
nonblocking observations, not repaired. Historic missing observers/provenance gaps
retain their scopes; do not rewrite old audit results or erase failures.

If incomplete, identify the exact remaining predicate/resource/constraint, attempted
construction or not-attempted status, and smallest continuation point. Do not return
only a category list. Practical limits may be reported honestly; no fabricated pass
or future/background-work promise. A material source finding stops acceptance but
authorizes no audit-side repair.

Save a uniquely named full report BEFORE sealing one evidence ZIP. Include it byte
identical, a complete self-excluding size/hash/mode manifest, exact T once (which
already includes S/R), policy base/appendix/final identity and review, runtime-data
observations, synthetic and representative control evidence, all 99 outcome mappings,
new suite/raw observer/JUnit/IDs/warnings/source captures, residual results, full
closure ledger, versioned helpers, failed attempts, cleanup and explicit non-effects.
Do not duplicate A or entire history. State safe archive expansion bounds for the
new package, accounting for nested T. No credential, private template/capsule text,
unclassified binary/database state or output redaction disguised as raw evidence.
Reopen every member and verify; return report/ZIP/manifest byte counts and SHA-256
in the inline closeout and adjacent receipt. The ZIP need not contain its own hash.

Return to ChatGPT. Only tree 4691af58ae0ee3107b4e2e9b6b1508032944e357 can eventually
be accepted here, solely for eligibility for a separate live exact-byte commit gate.
No staging, commit, push, PR, merge, release, deployment or product effect is authorized.
