ENGAGEMENT ENVELOPE

CURRENT STATE
The preceding P0/P1 program is merged and closed. The selected next program is
private artificial-offline NORMAL terminal closure, not complete cancellation
closure or RW0-E readiness. The reconnaissance is complete; its READY result is
planning evidence, not implementation or acceptance.

RECIPIENT
The SAME Coordinator Codex conversation that returned
RW0_POST_P1_TERMINAL_CLOSURE_RECONNAISSANCE_READY, now authorized for the bounded
workspace-write implementation below. Parent is sole writer; close any earlier
explorers and spawn no subagents during this engagement.

ATTACHMENTS
None. Use the matching repository and this complete mandate. No Downloads,
checkpoint-package, old /tmp evidence, or other-chat lookup is required.

AUTHORIZED EFFECTS
One new local development branch from the fixed integrated squash; bounded
Coordinator docs/source/schema/tests edits; task-owned isolated synthetic
validation; external evidence/checkpoint/review-package creation. No staging,
commit, network, push, PR, merge, deployment, or product effect.

EXPECTED RETURN
One uncommitted complete implementation candidate, one uniquely named standalone
implementation report, and one self-contained review ZIP. Return the operative
result and exact identities inline. Implementation validation is not audit.

PROJECT SNAPSHOT
No new Project snapshot now. The baseline remains PR #17 squash 61d0330... with
tree 44c7dee.... A later integrated program will justify a new snapshot.

NEXT ACTION
Return to ChatGPT for artifact inspection and a separate fresh independent
precommit audit mandate. Do not audit, stage, commit, or publish this candidate
in the implementation conversation.

1. OBJECTIVE AND ENGINEERING DECISIONS

Implement one private, versioned terminal writer that closes the five normal
P1 outcomes, separately from the prior decision and acceptance fact:

  candidate_acceptance          -> terminal accept
  candidate_repair              -> terminal repair
  attempt_selecting_replan      -> terminal replan
  program_terminal_reject       -> terminal terminal_reject
  post_execution_program_block  -> terminal block

Profile: artificial_offline_normal.v1. All supported terminal values have
branch=normal. Reject active_cancel_reconciled, active_cancel_unresolved, and
pre_effect_cancel_basis_unusable, and any unsupported profile, before terminal
writes. A preexisting P1 decision, process cancellation, exit, or cleanup is
never sufficient to fabricate a cancel-shaped terminal fact.

This is one source/schema implementation program. Update the governing contract
and assurance WITH code. Do not return a separate semantic-only or schema-only
tranche; do not perform another broad reconnaissance. Freeze concrete ordered
fields, bounds, role sets, digest domains, row tuples, SQL keys, and vectors in
the owner doc and matching contract tests as part of this implementation before
building its writer. Ordinary representation details within the frozen scope
are implementation work, not grounds for another user handoff.

The following decisions refine the reconnaissance and are operative:

A. Preserve existing RW0TerminalOutcomeV1, its pure semantics, canonical bytes,
   budgets, and four shape validators. Add a private normal-profile V2 in an
   adjacent private module. Do not reinterpret latch_postimage_ref/digest as
   durable guard proof. The V2 uses actual acceptance_fact_ref/digest.

B. Replan predecessor verification uses the EXACT original
   RecordProgressionDecisionCommandV1 as a transient operand, including its
   original replan proposal when required. A safe projection or digest cannot
   reconstruct private objective/requirements/exclusions. Do not invent such a
   reconstruction or persist that private text. The safe selector binds the
   transient operand to persisted P1 evidence; it does not replace that operand
   at an API that requires it. See section 5.

C. The new terminal writer consumes protected predecessor facts. A fresh terminal
   record therefore requires BOTH current terminal recording posture and
   protected predecessor-disclosure posture. Historical terminal replay/read
   and recovery require disclosure, not renewed recording permission. NONE of
   these paths reevaluates fresh P1 acceptance eligibility or requires an
   unclaimed acceptance scope. Existing P1 permission semantics stay unchanged.

D. The current connected P1 test changes typed validation values after an actual
   passing D2 run (tests/test_sqlite_rw0_c2_connected.py:115-126). Retain its
   bounded historical credit, but do not promote that overlay to evidence of a
   source-coherent terminal chain. New five-branch terminal positives must use
   actual matching observations, result sets, dispositions, proposal evidence,
   memberships and P1 basis. See section 9.

E. The first substantive saved/reopened checkpoint must include real fenced
   accept AND replan terminal writes, checked read, replay and recovery, not
   merely values/schema/row adapters. This brings the difficult predecessor and
   historical-head bindings into the first proof.

F. Independent audit is of the final UNCOMMITTED candidate and precedes any
   commit gate. The reconnaissance phrase 'independent committed-artifact audit'
   does not change that order or authorize a commit.

G. Completing this normal profile does not complete the three cancellation
   branches, close supplier gate B, or authorize RW0-E. A later cancellation
   physical-closure program remains necessary before claiming full terminal
   coverage. Supplier qualification is a separate possible read-only track, not
   an assignment in this mandate.

2. REPOSITORY, BASELINE, AND PROSPECTIVE PRESERVATION

Repository: /Users/ds/Repositories/Governed Execution Coordinator/

Fixed integrated base:
  commit: 61d0330aba1160f7f5e7d9c541a325222d1c61e5
  sole parent: 4519630d0db967066beb21b4ace5004e76827716
  tree: 44c7dee402d46b3e16dc389ae0824b4297dfec1f
  source paths: 315

Reconnaissance observed the clean preserved topic:
  branch: codex/rw0-c2-p0-p1-physical-program-v1
  HEAD: 3263bc25e4a9f5558065fc7eb68125029d578bda
  tree: the same fixed integrated tree
  local trunk_dev: the fixed integrated squash.
These are reported opening anchors, not permission to assume present state or
remote state. Authenticate source, commits and refs separately.

Read root guidance before mutation. Establish a prospective opening, including
raw index copy/hash before ordinary Git observations, semantic index, safe
configuration identity, complete source bytes/Git modes/OS modes, and complete
ref maps. Prior read-only reconnaissance is not retroactive preservation and
is not itself a reason to reject a new prospective opening.

Require a clean worktree/index and the exact base tree. Either the reported
preserved topic or trunk_dev at the fixed squash is an eligible starting
checkout; record which. No staged/unmerged/unrelated source changes may be
absorbed. Validate the squash raw object/parent/tree and all 315 paths before
creating the branch.

Create and switch exactly once to the previously absent local branch:
  codex/rw0-normal-terminal-closure-v1
from commit 61d0330aba1160f7f5e7d9c541a325222d1c61e5, with --no-track.
Do not base it on the unsquashed topic merely because the trees are equal.
Stop if that new branch already exists or the opening differs; do not reset,
restore, rebase, clean, rewrite a ref, or overwrite another candidate.

The allowed Git changes are the new branch and HEAD checkout only. Thereafter
HEAD remains the base commit, index equals it, no upstream, and no staged entry.
Preserve the former topic, trunk refs, configuration and unrelated state.

Qualified diagnostic ref namespaces are only:
  refs/codex/turn-diffs/captures/
  refs/codex/turn-diffs/checkpoints/
Retain lossless inventories and deltas separately from canonical source
identity. Do not infer their actor or harmlessness. Qualified additions/removals
are reportable; surviving-name retargets, source-selection dependencies or
unexpected authoritative changes block. Recognize the ordinary origin/HEAD
alias as an observed alias, not automatically a hostile source indirection.
No replacement refs, grafts, alternate source selection, or unrelated worktree
manipulation is authorized.

Preserve the classified live POSIX 0600 / Git 100644 file:
  tests/test_c2b3_private_atomic_program_initialization.py
Other existing source modes remain unchanged. Record real opening modes; do not
chmod the live checkout to make a gate pass. Explicitly classify new source
files, normally POSIX 0644 / Git 100644.

3. GOVERNING FILES AND IMMUTABLE BASELINE

Use the reconnaissance's source map, not another broad survey. Reopen the
material owners and the exact call sites before changing them:
  AGENTS.md; README.md
  .docs/autonomous-software-development-operating-model.md
  .docs/authority-boundaries.md
  .docs/rw0-remote-worker-contact-phase-entry.md (normal/cancel/terminal order)
  .docs/rw0-b1-pure-phase-values.md (especially :439-463 legacy pair)
  .docs/rw0-c2-durable-progression-decision-semantic-contract.md (:503-512)
  .docs/rw0-c2-private-value-versioning.md
  .docs/rw0-c2-physical-p0-p1-implementation.md
  .docs/rw0-c1-durable-evidence.md
  .docs/section41-post-execution-proposal-family.md
  .docs/rw0-c2-first-live-proof-posture.md
  .docs/writer-session-authority.md and SQLite migration/recovery owners.

Decisive existing implementation seams:
  _rw0_phase_entry_semantic_values.py:746-766,1055-1073,2190-2241
  _rw0_c2_progression_contracts.py:273-384,410-466,637-687,760-810
  _sqlite_rw0_c2_progression.py:399-502,572-784
  _rw0_c2_progression_plan.py:193-260,459-540
  _sqlite_rw0_c1.py:177-215,462-510,5111-5217
  _sqlite_section41_post_execution_proposal.py:278 onward
  sqlite_transition_transaction.py:1273-1369
  sqlite_writer_session.py private P0/P1 delegation
  tests/test_sqlite_rw0_c2_connected.py:44-180.
Python paths above are under src/ge_nwp_coordinator/ unless prefixed tests/.

Preserve migrations 0001-0007 byte-for-byte. Their fixed SHA-256 values are:
0001_initial.sql
  1a3af0f4dc3a9df8fe0a745a68a98590e56dd6f9dc7aeeced3aa975839543148
0002_development_program_and_effect_state.sql
  5859f49994b1467db71911fb60db4f1cfc562af7517dc6e4d81b5b29ca44d56c
0003_cognitive_proposal_and_selection_state.sql
  b5c7cac8e074b77ab369579f1f8015f547f1a2776b4b09d612e56280f16c1579
0004_rw0_c1_durable_evidence.sql
  967b9c2deb43da625f9ce82d43c9538bfd2fa27c02f3abdfcb12eb3a2aef8cec
0005_section41_post_execution_proposal_family.sql
  583c14e2018c84a942e2e72bbb57d24ae39b2470dc4c286c5f775afe1ef9ea87
0006_rw0_c2_scope_admission.sql
  58b2731d52e8e199c010b309a29aa831ffb16d4db4e755d20adb694ce0a7305f
0007_rw0_c2_progression_decision.sql
  505d72c9c54f68e248bebab928e76564d45b853068b8b4021ebc708b640e430c

Preserve P0 production modules, P1 mutation/branch/acceptance semantics,
Decision Basis v2, guarded-command-digest v2, six P1 preassignments, WorkSpecV1,
existing generic receipts, and the original V1 terminal module. No reallocation
of 0006/0007, guard mutation, new P1 decision, or original-family repair.

schemas/sqlite/coordinator-state-v1.sql is a frozen non-authoritative 0001
fixture, NOT the current cumulative schema. Leave it unchanged. Update the
actual catalog-derived schema manifest/tests, not that old fixture.

4. VERSIONED FAMILY AND REPRESENTATION

Add migration 0008_rw0_terminal_outcome.sql, application generation 2.
Four new immutable STRICT tables:
  rw0_terminal_contexts
  rw0_terminal_outcomes
  rw0_terminal_results
  rw0_terminal_receipts
Eight update/delete immutability triggers, zero seeds. Expected cumulative
inventory is 78 tables / 142 triggers / 5 explicit indexes, derived from the
actual catalog. Use needed PRIMARY KEY/UNIQUE indexes and composite FKs; do not
omit an integrity relation to achieve a numeric count.

The table family is a private NORMAL terminal family. Constrain its profile,
branch and five outcome/decision combinations in both values and SQL. Do not
add reachable cancel rows, generic extension bags, speculative cancel receipts,
or unimplemented future profiles. Future cancellation must preserve the single
phase-unique terminal anchor through an explicit version/migration decision,
not create a competing terminal-truth store.

Create a closed RecordRW0TerminalOutcomeCommandV1 and RW0TerminalOutcomeV2,
plus closed context, result, receipt, conflict and recovery values. Use exact
built-in types; reject bool-as-int, subclass equality tricks, duplicate keys,
unknown keys, unsafe refs, noncanonical digests/times, invalid UTF-8, overlarge
or deeply nested inputs. Define finite limits, canonical encoding, ordered
preimages and fixed vectors in the owner/tests. Do not derive test expectations
from the value currently under test.

The command's safe selector must bind:
- profile, mutation ref, exact phase ref/digest;
- original P1 command digest and admitted-relation identity, original assertion,
  basis identity, prior mutation/decision/result/receipt selectors and replan
  SAFE projection where present;
- exact Section 41 post-execution command/receipt/context/proposal/evidence-set
  selectors and C1 rank-15 admission selector;
- a CLOSED, ordered reached-owner locator manifest and digest;
- expected five current head identities/revisions/digests and stop identity,
  version, state and authoritative timestamp coordinates;
- expected P1 branch/outcome assertions with finite optional vocabularies;
- preassigned context_ref, outcome_value_ref, result_ref, receipt_ref and
  family_route.
The original P1 command is also a transient typed operand, not private JSON to
copy into the terminal rows. Its safe selector is deterministically extracted
and equality checked. Expectations are assertions, never branch selectors.

Precisely fix the preassignment ambiguity in the report: there are FOUR
preassigned row refs (context, outcome, result, receipt) plus a separate family
route. Derive each in its own domain from the same ordered stable selector
transcript, excluding all derived refs/digests, transaction time and optional
outcome/branch assertions. The complete command digest includes those refs,
route AND all assertions. Changed assertions must not qualify as exact replay.

Persist the canonical safe command association and exact historical binding
material required for replay, not a digest-only claim of reconstructibility.
Use normalized key columns plus bounded closed canonical safe payloads where
consistent with existing bounded-hybrid conventions. Every duplicate coordinate
must cross-check; a self-digest is not proof of an owner relationship.

Context retains:
- exact phase identity and historical phase-entry witness;
- program/lineage/scope, P0 act/fact anchors;
- Section 41 A context/proposal/receipt and its EXISTING evidence-set pair;
- checked C1 membership/receipt and reached-owner bindings, including the
  source evidence on which P1's typed dispositions actually depend;
- P1 basis, decision/ref/digest/kind, guarded result/relation and generic
  receipt command/graph/row anchors;
- canonical actual closure-time postimages of all five heads and current stop;
- actual acceptance-fact pair only for accept;
- one whole-second transaction recording time.
Do not mint a duplicate source evidence set or treat C1 membership as intrinsic
completeness. Resolve a finite role/rank inventory through exact owning readers,
not caller-selected arbitrary table/column queries.

Outcome V2 binds context, phase, normal branch, exact same-kind prior decision,
guarded result and receipt, five closure head coordinates, closure stop,
evidence-set pair and actual acceptance-fact pair. Reconciliation/mismatch
pairs, if retained as reserved fields, are exactly null in this profile.

Result is an immutable projection from that family. Receipt binds exact command,
profile, mutation/family route, phase and all new row identities, graph profile
and graph digest, committed result digest and original time. It is terminal-
specific; do NOT widen or repurpose migration-0002's generic receipt grammar.

Identity order:
  safe primitive selectors -> row refs/route -> command digest
  -> checked predecessor facts + actual closure snapshot/time -> context digest
  -> outcome digest -> result digest -> closed role graph digest -> receipt.
Exclude self-digests and later receipt digest from earlier hashes. A fresh/replay
presentation tag is not committed-result identity. Any canonical digest of an
existing 0002 receipt used as a new anchor must be explicitly domain-tagged as
such, not misrepresented as a preexisting receipt field.

Enforce a single terminal claim per phase and prior P1 decision, unique mutation,
row refs and route. Probe every meaningful original route/alias before writes.
Do not equate same-string refs across unrelated domains without an owner rule.
Freeze the closed graph roles, ordering, cardinalities, optional acceptance role
and exact typed row adapters before writer authoring. No arbitrary evidence bag.

5. ORIGINAL P1 OPERAND AND HISTORICAL RECONSTRUCTION

Current P1 _historical_exact calls build_p1_write_plan; for replan this calls
bind_replan_work_spec using the original private template. A safe template digest
alone cannot reproduce those private bytes. This implementation must not pretend
otherwise.

Use the exact original P1 command as a caller-supplied transient dependency for
terminal record, checked read/replay and recovery in this bounded profile.
Verify it against persisted relation/basis/command/receipt and complete P1
historical family using existing owner semantics. Store only its safe selector
and required safe binding evidence; no objective, requirement/exclusion text,
raw WorkSpec/template, prompt, transcript, output, path, PID or credential data.
Do not synthesize empty/dummy private templates to satisfy constructors.

Unavailable or mismatched original operands cannot produce committed_exact;
record/read must use safe failure semantics and recovery must remain unresolved.
State this operand-availability limitation plainly: this program does not add a
durable private-template store or autonomous restart recovery service.

All predecessor checks must use the CURRENT terminal controller's fenced
capability. Do not nest a second WriterSession/transaction or use an unfenced
connection inside terminal verification. Reuse private after-fencing helpers
where correct. A narrowly additive checked-reader adapter is allowed when
needed; it may not weaken or change existing P0/P1/C1/Section 41 mutators.

Both fresh terminal predecessor authentication and historical terminal replay
must avoid a reader that silently rechecks today's heads against old phase-entry
heads. In particular, _sqlite_rw0_c1._read_phase_development_owner_rows reads a
current work head with the phase-entry revision (:462-480); do not assume that
pre-P1 current-owner resolver remains a valid historical reader after replan.
Separate immutable-owner verification from fresh closure-current-owner reads. Use P1's retained program/work postimages and
the terminal context's actual sampled head postimages for their respective
historical purposes; never construct a purportedly observed head from a desired
plan and call that checked readback.

For a competing terminal winner, verify the COMPLETE family and all predecessor
bindings before using it as a proof of original noncommit. A same-phase/same-P1
winner with a different mutation can be checked using the shared original P1
operand and persisted safe selector. A winner needing unavailable/different
private evidence, or partial/foreign/ambiguous rows, remains unresolved. Do not
return the competitor's protected result or authorize another attempt.

6. FRESH TRANSACTION, DISCLOSURE, AND ERROR SEMANTICS

Use the existing guarded WriterSession operation lease, writer fencing and
BEGIN IMMEDIATE controller; one captured transaction/read timestamp per call.
Private methods only. No new public StateStore/package export or connection
owner.

Receipt lookup is first after local command validation and fencing. Before
revealing a hit, digest comparison or protected occupancy, check current
positive disclosure posture. A receipt-present exact record retry uses
DISCLOSURE only, not renewed recording permission or acceptance eligibility.
Read/recovery also require disclosure before an absence claim.

On a receipt miss for fresh record:
1. Require current recording posture and disclosure posture, both scope-bound
   to the original P1 basis. Reuse ArtificialDecisionGuardSourceV1's universal
   checks without changing it; do not invoke checked_acceptance_eligibility_for.
2. Verify P0, phase, Section 41 A, checked C1 rank-15/V22 and the reached-owner
   manifest, then the complete persisted P1 family from the original operand.
3. Compare every P1 typed validation/review/proposal binding with the actual
   checked source owners. A caller-resealed but detached disposition must fail.
4. For accept verify the exact already-existing P1 acceptance fact and its
   decision, lineage, scope, result and digest. Other branches have no acceptance
   member in THEIR P1/terminal family; do not globally demand no acceptance
   exists anywhere or treat another legitimate lineage's fact as this fact.
5. Read actual current program/work/selection/effect/delivery heads and stop.
   Require exact caller expectations. Program/work must match applicable P1
   postimages (replan work postimage differs from phase entry); other current
   heads must match the selected normal reached-owner chain. Any normal-path
   drift is a no-write currentness conflict, not fabricated cancellation.
6. Persist the ACTUAL closure stop, including an active/changed stop where the
   caller expectation matches and universal recording posture permits fact
   recording. Closing an existing decision is not starting a productive phase.
   Do not require the stop still equal phase-entry or P1-time stop, reinterpret
   the prior decision, or revoke its acceptance fact. Later replay ignores later
   stop/head changes.
7. Resolve route conflicts with no target writes. Insert context/outcome/result,
   check exact typed readback and all bindings, insert receipt LAST, verify its
   association, invalidate capability, and attempt COMMIT exactly once.
8. Return committed only under the existing commit-and-cleanup resolution rules.

There are NO application mutable-head writes or CAS in the terminal family.
Existing writer fencing bookkeeping remains its existing mechanism. Explicitly
prove terminal code makes no program/work/selection/effect/delivery/stop update,
no new decision/version/effect and no acceptance insertion/update/delete.

Preserve exception distinctions. Failed SELECT, corrupt/malformed owner family,
wrong readback and unexpected internal errors must not become ordinary stale
currentness or definite absence. Use existing safe SQLite integrity/uncertainty
vocabulary. KeyboardInterrupt, SystemExit, GeneratorExit propagate with proper
rollback/cleanup. Do not leak raw SQL, exception text or private operand content.

7. REPLAY AND RECOVERY

Exact replay/read returns the original committed terminal projection/time after:
  receipt -> fresh disclosure -> exact command association
  -> full immutable family/graph/predecessor validation.
No cognition or child rerun, current-head equality, acceptance eligibility,
fragment repair, new time-stamped family or hidden retry.

Read-only recovery under fresh fencing/disclosure yields only:
- committed_exact: complete exact original terminal family;
- definitely_not_committed: original operation routes exhaustively absent with
  positive continuity/sole-active posture and old-execution exclusion, or a
  completely verified competing family excludes the original operation;
- unresolved: denied/unavailable posture, unavailable original operand,
  incomplete/foreign/malformed/contradictory family, ambiguous alias/competitor,
  unprovable old-execution exclusion or cleanup.
A missing receipt alone is never definite absence. A row count alone is never
complete-family proof. No recovery class grants retry, execution or publication.

8. MIGRATION AND COMPATIBILITY

Update sqlite_migration.py's actual packaged catalog, checksum, expected
cumulative schema and zero-seed checks. Prove fresh initialization at 0008;
explicit administrative upgrade from exact supported prefixes; old 0007 binary
refusal of 0008; unknown/partial/checksum-mismatched/schema-divergent refusal.
Ordinary inspect/acquire/record does not implicitly migrate.

Independently apply the authenticated SQL catalog in isolated test state:
  after 0006: 68 tables / 122 triggers / 5 explicit indexes
  after 0007: 74 / 134 / 5
  after 0008: expected 78 / 142 / 5, application generation 2.
Verify exact preservation of every prior schema object, foreign-key integrity,
STRICT typing, unique routes, pair nullability, finite normal profile, update/
delete guards and empty fresh application tables. Do not enforce old current-
tip counters as immutable historical facts: preserve old-prefix tests and add
current-tip successors rather than blanket 0007-to-0008 substitutions.

9. CONNECTED PROOF AND FIRST CHECKPOINT

Use disposable task-owned databases and actual private owners:
  P0 -> actual D1/D2 -> Section 41 A -> C1 rank-15 B -> V22 -> P1
  -> terminal record -> checked read -> exact replay -> recovery.

For all five normal outcomes, the validation/review observations, result sets,
supports, dispositions, Section 41 projection and P1 basis must agree. Vary
artificial fixture content BEFORE capsule sealing/checker invocation so actual
fake validator/reviewer/model observations flow through actual owner admission.
Existing fake validator supports VALIDATION-TERMINAL / VALIDATION-REPLAN /
VALIDATION-UNCLASSIFIED and repairable content; fake reviewer supports corresponding
finite cases. Configure test inputs through existing supported fixture seams,
not by modifying observation values after real evidence was admitted.

Do not modify production fake processes or D1/D2 frames to force new positives.
No private provider/live client is authorized. A test-only artificial input
builder is permitted within existing validated fixture grammar. Preserve old
P1 connected tests at their original proof scope; new terminal tests must not
claim the old overlaid nonaccept values were independent source observations.
Include a negative using such a resealed detached disposition and show refusal
before any of the four terminal tables receives a row.

First substantive checkpoint, within the SAME program:
- frozen V2/command/context/result/receipt grammar, graph and fixed vectors;
- 0008 applied and prior schemas/resources preserved;
- real connected terminal accept AND replan, with actual compatible owner data;
- exact read/replay/recovery of both, including truthful current claimed=False;
- observed acceptance bytes/count nonmutation;
- original replan command dependence and no private text in terminal storage;
- negative changed assertion, denied disclosure and detached-source evidence;
- complete source identity, safe records, and checkpoint save/reopen verification.
Then finish all remaining branches and controls; do not request an intervening
user handoff to move from checkpoint to the rest of the same program.

Required final causal register:
- all five normal positives and three cancel-shape no-write rejections;
- accept only binds the exact existing fact; missing/foreign/tampered fact;
- matching rows but mismatched P0 lineage, C1 membership, Section 41/V22 or source
  dispositions rejected; bool/subclass/null/unknown-key/bounds cases;
- expected-assertion digest separation; same operation/changed command conflict;
- stale program/work/selection/effect/delivery expectation and stop expectation;
- changed but matched closure stop, including active stop without new effect;
- protected record replay with recording=False/disclosure=True;
- fresh record rejects either missing required permission;
- claimed=False/None does not suppress legitimate historical disclosure;
- SELECT failure stays integrity failure; process-control propagation;
- rollback on each insert/readback/receipt fault; no mutable-head writes;
- one COMMIT, before-commit failure, applied-commit/lost-return, cleanup uncertainty;
- original-route absence versus partial/foreign/malformed/alias families;
- complete competing same-P1 terminal winner versus unverifiable winner;
- later mutable-head/stop advance followed by exact historical replay/recovery;
- schema/prefix/old-binary cases and privacy canaries.
Each control must name the reached predicate, injection point, expected state,
actual state and test ID. Rejection at an earlier predicate earns no later
causal credit. Report controlled artificial observations as such.

10. TOUCHED SURFACES AND ASSURANCE

Expected new private modules under src/ge_nwp_coordinator/:
  _rw0_terminal_outcome_contracts.py (including adjacent normal V2)
  _rw0_terminal_outcome_rows.py
  _rw0_terminal_outcome_plan.py
  _sqlite_rw0_terminal_outcome.py
  sqlite_migrations/0008_rw0_terminal_outcome.sql
New owner: .docs/rw0-terminal-outcome-physical-closure.md
New direct tests for values/rows/plan, 0008, record/read/recovery faults and
connected normal closure; test-only fixture/support modules as necessary.

Expected existing production edits:
  sqlite_migration.py
  sqlite_transition_transaction.py
  sqlite_writer_session.py
Only narrowly additive private checked-read adapters in existing P1/C1/Section
41 owners may be added if an exact dependency proves necessary. Record that
reason BEFORE editing. Preserve all existing writer behavior/digests/row grammar.
Do not import new terminal code into old pure leaf owners to create a cycle.

Update current governing status and compatibility/versioning language together
with implementation. Relevant owner surfaces include the remote phase-entry,
B1, C2 physical/semantic/private-value, C1/Section 41 only where directly affected,
C2B durable-state owner, architecture/authority/operating model/software-
development boundary/durable-state/worker boundary, SQLite owners, README and
AGENTS. Inspect all direct doc/source/schema consumers, including Section 41
consumers that read a document tail to EOF. Expected surfaces are not permission
for unrelated prose churn.

The new governing text explicitly authorizes this normal V2 as the separately
versioned terminal-consumer successor inside this combined implementation.
It supersedes only the deferred normal physical boundary, not historical V1
bytes or cancellation/live contracts. Preserve historical checkpoints and
status blocks; add bounded current successors OUTSIDE shared historical markers.
Do not weaken the four-owner architecture-map equality test. Pin new complete
current doc identities plus exact predecessor reconstruction where existing
assurance uses raw bytes. A historical hash is evidence, not a permanent ban on
an explicitly authorized current successor.

Perform a complete source/consumer scan before final selector freeze, classify
current-tip versus historical checks, and include every affected complete test
module. A named implementation file list is not permission to omit an affected
assurance consumer. Keep package-root exports/public StateStore, security,
process supervision, live worker/transport/provider, ES/Bridge, Git effects,
services/schedulers and all other repositories outside scope.

11. VALIDATION COMMANDS AND ITERATION

Use installed Python 3.13.4 / pytest 8.4.1 / SQLite 3.49.1 when available as in
the accepted baseline. Record actual versions; stop on an unavailable required
runtime instead of installing or silently substituting. All execution uses
fresh authenticated EXTERNAL source copies, never imports from the live checkout.
Use restrictive umask, task-owned HOME/TMPDIR/basetemps/JUnit, bytecode/cache and
pytest plugin-autoload suppression, and network denial. Clear inherited pytest
selection/filter settings. Any audit-authored instrumentation plugin is explicit,
observation-only and retained.

From the authenticated external copy, the underlying pytest command form is:
  python3 -B -m pytest -q -p no:cacheprovider --collect-only \
    --basetemp=<owned-collection-path> <complete-module-list>
  python3 -B -m pytest -q -p no:cacheprovider \
    --basetemp=<owned-execution-path> --junitxml=<owned-junit-path> \
    <same-complete-module-list>
Set PYTHONDONTWRITEBYTECODE=1 and PYTEST_DISABLE_PLUGIN_AUTOLOAD=1;
record exact absolute executable, argv, cwd and allowlisted environment, not
only a wrapper-script name.

Required gates: direct causal controls, connected five-normal-branch proof,
complete affected focused modules, then repository selector-free collection and
FULL using the forms above with NO module/path/node selector. Run live read-only
`git diff --check` separately. Do not infer the new total from the old 9,502.

Before final execution freeze exact source and each ordered collected inventory.
Require unique IDs and exact collected/execution-collected/call/JUnit agreement,
all passing with zero errors/skips/xfails/xpasses; retain unsuppressed warnings.
Known multithreaded-fork warnings remain classified evidence, not failures or
universal platform guarantees. Before/after byte and numeric-mode snapshots
must match the tested source.

Normal implementation debugging is authorized within this scope. A development
failure is not an automatic request for another user mandate: retain the failed
attempt, fix the in-scope cause, freeze new bytes and rerun affected gates. Do not
weaken guards, hide failures, combine results across source identities or call
partial runs final. Stop for a genuine authority/operating-model conflict,
out-of-scope dependency, provenance drift, unsafe effect or unavailable required
coverage. Once the final candidate is sealed, further changes require a new
identified candidate and validation, not silent replacement.

12. PROVENANCE AND DELIVERY

Use a narrow, exact, recoverable external provenance recipe rather than a new
general framework. Record base commit/tree, allowed branch creation, all new/
modified paths, before/after bytes, sizes, SHA-256, Git blobs/modes and numeric
OS modes; include untracked additions. Preserve historical ref/index limitations
without claiming that current observations resolve them.

Keep canonical source/patch identity separate from volatile timestamps and
diagnostic refs. Generate two byte-identical final source/patch captures from
fresh reads and a post-cleanup capture. Record all authoritative-ref deltas and
safe configuration/index observations. No staging/commit/publication.

Deliver one self-contained review ZIP with:
- complete final source, baseline/final manifests, exact touched before bytes;
- full tracked patch plus all new-file bytes and exact patch-manifest recipe;
- machine contract, vectors, SQL/resource hashes and schema manifests;
- direct/connected/focused/FULL invocation, ID, JUnit, warning and source-binding
  records; causal register, failed/superseded attempt inventory and limits;
- substantive checkpoint identity and sufficient retained contents to verify it;
- safe opening/closing provenance, cleanup and effect records;
- evidence/IMPLEMENTATION_REPORT.md, written before sealing.
Preserve existing evidence inputs but do not recursively embed unrelated old
tranche bundles. Reconstruct baseline and final trees from exact manifests and
payloads without needing the writer's live checkout.

Provide the same report bytes as a uniquely named standalone file:
  RW0_NORMAL_TERMINAL_CLOSURE_IMPLEMENTATION_REPORT.md
Reopen the ZIP, verify safe member inventory, complete self-excluding manifest,
source hashes/modes/tree, and embedded/standalone equality. Report ZIP bytes and
SHA-256 in an adjacent delivery receipt, not a circular outer self-hash inside
the embedded report. Exclude secrets, .git, config contents, user databases,
SQLite sidecars, caches, .pyc, build output and unclassified process artifacts.
Clean only task-owned validation state after evidence is retained/reopened.

13. STOP BOUNDARIES AND FINAL RETURN

Stop without staging when exact baseline cannot be authenticated; a required
historical/private operand is unavailable; terminal closure requires weakening
an owner check, fabricating source/acceptance/cancel evidence, changing 0001-
0007, redefining WorkSpec/P0/P1 authority or adding a live route; immutable phase
uniqueness cannot be maintained; no safe same-capability reader composition
exists; or final required validation cannot complete. Report the precise source
path/contract conflict and the exact retained partial state. Do not restore or
discard partial work without authorization or claim it is accepted.

Return one primary disposition:
  RW0_NORMAL_TERMINAL_CLOSURE_IMPLEMENTED_VALIDATED_PENDING_AUDIT
or
  RW0_NORMAL_TERMINAL_CLOSURE_BLOCKED_<PRECISE_REASON>

Include the exact opening/final source trees and branch/HEAD; all touched paths
and classifications; frozen field/role/digest graph and vectors; 0008 checksum
and derived schema inventory; original-P1 operand/privacy treatment; guarded
fresh/read/replay/recovery algorithms; connected five-branch evidence and cancel
no-write controls; checkpoint; exact commands/results/IDs/warnings; source/mode
and migration preservation; artifacts and reopened identities; assumptions,
process errors, residual F03/F05 and other inherited limits; and precise missing
coverage.

State explicitly:
  INDEPENDENT_AUDIT_NOT_PERFORMED
  STAGING_NOT_PERFORMED
  COMMIT_NOT_PERFORMED
  PUSH_NOT_PERFORMED
  PR_NOT_CREATED
  MERGE_NOT_PERFORMED
  PUBLICATION_NOT_PERFORMED
  DEPLOYMENT_NOT_PERFORMED
  PRODUCT_EFFECT_NOT_PERFORMED

Do not claim full terminal cancellation closure, live readiness, autonomous
recovery, effect permission or publication authority. Return to ChatGPT; the
next review is a separate fresh independent audit of the uncommitted bytes.
