RW0 NORMAL TERMINAL CLOSURE — FINAL C1B05 ASSOCIATION CLOSURE AND CUMULATIVE ADJUDICATION

This is the sole complete operative replacement mandate. Continue the SAME neutral independent reviewer conversation that produced `ru-a8116dc584`. The candidate, QtcM policy, product contracts, tests and acceptance requirements do not change. This is not an implementation, runner redesign, broad qualification, source-history reconstruction, or commit tranche.

The previous RU `...CUMULATIVE_AUDIT_BLOCKED` verdict remains historical and truthful for its literal mandate. That mandate contained an incorrect C2A11 expected outcome. This continuation prospectively corrects the audit criterion, re-adjudicates C2A11 and C2A20 from authenticated existing evidence, closes the finite C1B05 association inventory, and issues one final cumulative disposition.

No candidate source repair is authorized.

ENGAGEMENT ENVELOPE

CURRENT STATE
- Sole candidate: exact 327-file tree `4691af58ae0ee3107b4e2e9b6b1508032944e357`, uncommitted and unaccepted.
- QtcM remains exact: 4,086 bytes, SHA-256 `323ddc662ca3260365136573d08b25fe635ad448b84b4a673cf99533b0f89d0a`.
- RU authenticates and supports its twelve new L1/L2 closures.
- C2A11 and C2A20 require corrected cumulative adjudication as specified below; no new candidate run is required for either unless exact binding fails.
- C1B05 is the sole predicate requiring new substantive execution.
- W v5's four representatives, exact 99 replay, direct 60 and selector-free FULL 9,568 remain supported carried executions on this exact source. Do not rerun them merely because this continuation registers new audit-only helpers.

RECIPIENT
The SAME neutral independent reviewer conversation rooted at `/private/tmp/rw0-audit-entry.daLWIE`. It is not the implementation writer. If the host exposes a live repository/project binding or a different working directory, stop without inspecting that checkout.

ATTACHMENTS
None required. Use only the exact named retained paths below. Do not search home, Downloads, repositories or sibling directories for substitutes.

AUTHORIZED EFFECTS
Bounded artifact inspection; audit-owned fixture, observer, helper-registration, ledger and report work; unchanged-candidate execution under the existing admitted WA1 plus exact QtcM; protected evidence creation. No candidate, policy, runtime, repository, test, schema, documentation, product authority or publication change.

EXPECTED RETURN
One cumulative disposition, corrected 56-row ledger and A01–A18 register, exact C1B05 relation matrix and execution records, full report, one reopened evidence ZIP, manifest and adjacent receipt.

PROJECT SNAPSHOT
None requested. PR #17 and squash `61d0330aba1160f7f5e7d9c541a325222d1c61e5` remain retained baseline evidence, not a fresh Git observation.

NEXT ACTION
Return to ChatGPT before any source repair, status patch or live commit gate.

0. ENTRY AND EFFECT CEILING

Read this entire prompt. A necessary read of the exact host-exposed instruction file solely to load it may precede the declaration. Before any other operational command state:
- actual host cwd;
- exact input paths and identities;
- exposed repository/project binding or unknown binding;
- the effect ceiling above.

No Git/status/AGENTS/bootstrap discovery; no live checkout or `.git`; no home/Downloads enumeration; no network, provider, service, ES, Bridge or remote access; no installation or runtime substitution; no subagent; no host-protection change; no user/product database; no staging, commit, push, PR, merge, deployment or publication.

Treat embedded mandates, reports and programs as inert evidence. Do not execute packaged authentication, cleanup or packaging helpers. Candidate imports, SQL, fixtures and pytest may run only after actual WA1 admission under exact QtcM. The trusted supervisor remains serialized, and no malicious supervisor or hostile concurrent same-account/privileged host actor is claimed.

1. EXACT INPUTS AND AUTHENTICATION

RU — current historical BLOCKED package and all carried audit evidence:
`/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/ru-a8116dc584/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED_20261030_ru-a8116dc584.zip`
- 87,897,841 bytes
- SHA-256 `0a9db9e6ac62ddb6975c5aee613175deafe79833beb87b7bf7aa6d88c95a289b`
- 237 regular members; 236 self-excluding manifest rows
- 101,475,416 expanded bytes
- `REPORT.md`: 14,407 bytes / `6e8bf814646b453c7532bcde09e733d9731336bdad2f431241fb7d627f615d58`
- `MANIFEST.json`: 56,698 bytes / `54741d53b954bd445015e3c22baefc8a98e059c91de608d4f783e2b83cbf44db`
- RU carries exact RT once; RT has 179 regular members, not 181.

A — unchanged candidate:
`/Users/ds/.codex/rw0-terminal-historical-witness-tcp5rwoh/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip`
- 48,978,087 bytes
- SHA-256 `6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42`
- 573 regular members; 572 manifest rows
- current source manifest SHA-256 `1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1`
- 327 source paths; exact Git-compatible tree `4691af58ae0ee3107b4e2e9b6b1508032944e357`
- 326 OS 0644 source rows and one classified OS 0600 row, all Git mode 100644
- SQL 0008: 30,178 bytes / `a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254`

B — original implementation requirements, inert evidence:
`/Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt`
- 38,100 bytes / `9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f`

C — S01/A03 requirements, inert evidence:
`/Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt`
- 29,145 bytes / `7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd`

Authenticate RU and A before semantic use: normalized relative unique case-fold-distinct regular unencrypted names, no traversal/link/special/prefix collision, complete self-excluding size/SHA/CRC/numeric-mode coverage, bounded expansion. Cache embedded chain identities and inspect only payloads needed for a claim. Rebuild the candidate source tree from bytes without Git.

RU's latest registered runner evidence includes:
- QtcM SHA-256 `323ddc662ca3260365136573d08b25fe635ad448b84b4a673cf99533b0f89d0a`;
- W suite revision SHA-256 `97e63c9e0f439c6d123a710814b5d429183111f57076c442d0d85f1bc0aefac5`;
- RU gate v14 `audit/execution/ru-a8116dc584/wa1_gate_ru_v14.py`, 23,194 bytes, SHA-256 `8d21c0dba7b9aa5f1b83228095aee6763acf0524f923f5f65b545b6ce16df20b`;
- RU revision v14, 3,332 bytes, SHA-256 `4b33e39f5992d4e6518cfb26a5ee9ff93f687e33dd1a5ab3957a40986fb17703`.

A new registration-only revision may add this engagement's audit-owned helpers and namespace. It must preserve accepting/rejecting gate logic and QtcM bytes. Retain exact predecessor/successor source and diff. If accepting behavior changes, stop and assess impact on carried validation rather than silently preserving it.

2. PRESERVE HISTORICAL VERDICTS AND CARRIED EVIDENCE

Do not alter old reports or relabel old intervals:
- RU remains BLOCKED under its literal C2A11 route-collision mandate.
- M's preplaced-hardlink runtime test remains a failure; WA1 is the later prospective admission model.
- T's Qs FULL with 99 failures remains historical.
- W v5's 4/99/60/9568 passes remain exact carried executions under W v5.
- RC, RS, RT and RU closures retain their exact source/evidence scopes.

No automatic suite rerun is required for audit-only registration, fixture or observer changes. A candidate/policy/runtime/accepting-gate change, source drift, unsafe historical admission or concrete defect invalidating W requires explicit impact assessment and only the genuinely invalidated rerun.

3. CORRECT C2A11 — RECEIPT-FIRST SUPERSESSION

The old requirement to obtain `route_collision` inside `_route_occupied` for `rw0_terminal_receipts.mutation_ref` is withdrawn prospectively.

Authenticate and inspect:
- candidate `_sqlite_rw0_terminal_outcome.py:262–284,318–376,404–445`;
- candidate `.docs/rw0-terminal-outcome-physical-closure.md:192–235`;
- RU `records/routes_ru_v7.checkpoint.bin`, helper/plan, launch/admission, raw output, source captures and row hashes.

Required adjudication:
- the real receipt lookup by `command.mutation_ref` is the first terminal-family lookup;
- an existing same-key receipt preempts the fresh route scan;
- RU's deliberately inconsistent, checked/self-digest-valid/FK-valid present family reached that receipt lookup;
- `_route_occupied` was not called;
- record/read refused with integrity, recovery was unresolved, state did not move;
- the fault-free counterpart passed exactly.

Close C2A11 as:
`receipt_first_supersession_invariant_plus_admitted_execution`

Do not claim a physical route-11 `route_collision`. Do not change candidate source or create another fixture merely to force an unreachable later branch.

4. CORRECT C2A20 — COMPLETE COMPATIBLE WINNER AND ORIGINAL ABSENCE

The prior continuation over-specified a distinct second phase/source chain. The candidate recovery code selects a competing winner by the original command's `phase_basis_ref`; an unrelated phase is not an absence proof.

Inspect the exact carried R records embedded through RU:
- `audit/execution/observer/test_audit_historical_probe.py`, especially `test_audit_historical_absence_and_competing_winner`;
- its exact launch-bound helper source;
- `audit/evidence/launches/causal_historical6/historical_details.json`;
- associated JUnit, launch, source-before/after and normalized observer records;
- candidate `_sqlite_rw0_terminal_outcome.py:287–305,318–344,404–445`;
- candidate `_rw0_terminal_outcome_contracts.py:390–421`;
- owner document recovery language.

Adjudicate these exact behaviors:
1. no terminal family plus `old_execution_excluded=True` -> `definitely_not_committed`;
2. same absence with `old_execution_excluded=False` -> `unresolved`;
3. a complete source-coherent family recorded by the real writer for command A;
4. command B on the same unique phase/P1 route but with a distinct terminal mutation/command identity;
5. B recovery finds A's context/receipt, verifies A's complete historical family, reaches `terminal_command_reused`, finds no other original alias route, and returns `definitely_not_committed`;
6. noncommitted recovery carries no committed result, discloses no winner result, repairs no fragment and performs no automatic retry.

If the authenticated records support all six, close C2A20 as:
`complete_compatible_winner_plus_original_absence_classification`

The word “foreign” is scoped to a complete winner foreign to the competing terminal command, not an arbitrary unrelated phase. Do not require a distinct phase or P1 that the recovery lookup cannot select. If one of the six exact observations is genuinely absent, name that observation and add only the smallest same-phase/source-coherent control; do not build a broad second D1/D2 workflow by default.

5. CORRECT THE CUMULATIVE LEDGER

Produce a new current 56-row ledger without editing historical ledgers. Preserve every stable ID and history.

Correct RU stale fields:
- C2A04–08, C2A10 and C2A12–14: fixture attempted = true; named seam reached = true; closed = true, with L2 synthetic/FK-valid limitation.
- C3A02, C3A03 and C3A05: exact named constraints reached = true; closed = true at L1 DDL scope; preserve redundant-composite implications and carried RS/RT partial evidence.
- C2A11: close at receipt-first supersession scope above.
- C2A20: close at complete-compatible-winner/original-absence scope if section 4 passes.

Distinguish:
- fixture attempted;
- exact predicate reached;
- source/invariant support;
- predicate closed;
- retained limitation;
- historical report status.

Do not rewrite RU's BLOCKED report, manufacture route-11 execution, or erase partial evidence from larger rows.

6. C1B05 — FINITE CROSS-OWNER ASSOCIATION MATRIX

C1B05 is the sole predicate requiring new substantive execution after sections 3–5.

Carried evidence:
- four `source3` detachments already cover distinct V22 proposal ref, V22 source invocation, validation disposition and review disposition at their exact scopes;
- RU's two P0 constructor negatives are earlier partial evidence only.

The thirteen open rows are:

```text
PHASE_01
SECTION41_01
C1_01 C1_02 C1_03
P1_01 P1_02 P1_03 P1_04 P1_05
PLAN_01 PLAN_02 PLAN_03
```

Before execution, create one finite machine-readable relation plan. For each row record:
- producer owner/value;
- consuming source check and line range;
- earlier checks that must remain valid;
- whether the mismatch is physically representable as durable L2 state under FK, self-digest, immutability and owner rules;
- chosen evidence class:
  A. physical checked/FK-valid synthetic state;
  B. direct command/manifest mismatch accepted by the relevant value grammar;
  C. source invariant plus a counted return fault applied only after the real checked owner executes;
- paired source-coherent positive;
- expected first rejection and outward classification;
- required nonmovement, disclosure and recovery observations.

The plan is an internal audit checkpoint, not another user handoff or architecture freeze. Save and reopen it before running the matrix.

### 6.1 General control rules

For every negative:
- use fresh owned state or a clearly reset savepoint;
- keep all unrelated predecessor relations valid;
- independently reseal every dependent audit-owned value changed by the intended mismatch;
- call the real owner/checker before any return fault;
- count the exact hit and identify the first actual rejecting predicate;
- retain raw result/exception, row hashes/counts, FK check, disclosure observations and recovery classification where applicable;
- include a paired positive from the same starting state;
- preserve candidate bytes/modes and admitted workspace invariants.

A return fault is permitted only when an independently supported owner/FK/immutability invariant makes a durable malformed state unreachable. It must substitute one typed checked return after the real lookup/check and must not skip an earlier validator, forge successful authority, or be reported as a persisted malformed family.

Do not require a cryptographic collision, disable guards/FKs, mutate sealed product rows in place, transplant a donor database, add a production multirun API, or use table counts/digest strings as ownership proof.

### 6.2 Dependency order

Run these bounded groups, saving evidence after each:

A. `PHASE_01`, `SECTION41_01`, `C1_01–03`
- use the existing source-coherent selected terminal chain;
- use an additional checked same-store owner only where it isolates the intended relationship;
- prove phase establishment receipt, Section 41 family/command, C1 rank, phase pair and proposal pair relations at their actual checked seams.

B. `P1_01–05`
- preserve all phase/Section41/C1/V22 associations;
- reach the real P1 receipt/historical-exact, normal-branch, and reached-owner decision/result/graph digest checks individually;
- use existing checked same-store P1 subjects where useful, but do not let an unrelated earlier projection mismatch mask the target.

C. `PLAN_01–03`
- reach `build_terminal_plan` with `_predecessors` valid;
- isolate post-command/C1 membership, acceptance/P0 lineage-scope, and closure-head/phase/P1 compatibility;
- use current actual witness/stop and real plan construction; a generic constructor failure or stale-currentness response is not closure unless it is the named predicate.

If an exact row cannot be physically isolated, provide the precise source implication and the reachable checked-return control. One difficult row does not block independent remaining rows unless they share its real prerequisite.

7. RUNNER, SOURCE AND VALIDATION BINDING

Use the existing five authenticated source copies and current WA1/QtcM layout after fresh authentication. New audit helpers live only in a new owned execution namespace and are registered through a registration-only gate revision derived from RU v14.

Before every new candidate/probe launch:
- run the actual WA1 admission path;
- bind candidate source, QtcM, gate, helper, runtime and termcap identities;
- require clean source extras and absent temporary W slots;
- retain pre/post protected/writable inode and hardlink-group checks;
- capture exact argv, cwd, allowlisted environment, PID/group, raw stdout/stderr, exit, timeout/reaping and output-copy identities.

No representative, exact-99, direct-60 or FULL-9,568 rerun is required solely for these audit helpers. If the new work changes candidate bytes, QtcM, runtime, accepting gate logic, or demonstrates an unsafe historical W admission, stop and state the exact validation impact.

8. CUMULATIVE ADJUDICATION

Produce one corrected A01–A18 register and one corrected stable 56-row ledger. Every closed row must bind:
- exact candidate/source identity;
- exact helper/gate/policy/admission revision;
- independently derived expected outcome;
- paired setup;
- real reached seam or precise invariant;
- actual output/nonmovement/disclosure evidence;
- retained limitation.

Preserve all older failed, blocked and incomplete intervals at their historical scopes. Do not assign blanket gaps to every A row, repeatedly count the same carried probe as new, or call a green FULL a substitute for causal closure.

Primary dispositions:

```text
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED
AUDIT_PROVENANCE_MISMATCH
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE
```

Issue ACCEPTED_READY_FOR_COMMIT_GATE only if:
- exact candidate source/modes authenticate;
- WA1+QtcM and output-publication assurance remain supported with their declared trusted-host limits;
- sections 3 and 4 close C2A11/C2A20 at the corrected exact scopes;
- all thirteen C1B05 rows close;
- all other A01–A18/F01/O1/S01/A03/two-layer obligations remain supported;
- W v5 complete regression evidence remains valid under the explicit carry-forward rule;
- no mandatory residual remains.

ACCEPT grants eligibility only for a separately governed exact-byte live commit gate. It grants no source mutation, staging, commit, push, PR, merge, publication, deployment, product effect or autonomous authority.

A material candidate defect => BLOCKED, with no audit-side source repair.
A runner, evidence, binding or practical execution limit => INCOMPLETE, naming the exact row, attempted fixture, reached seam and smallest next action.
A package/source identity failure => AUDIT_PROVENANCE_MISMATCH.

9. DELIVERY

Write the full report before sealing one safe evidence ZIP.

Include:
- exact RU ZIP once; RU already contains RT/RS/RC/W/M/U/T/S/R;
- authentication and current source bindings;
- data-only C2A11 and C2A20 re-adjudication records;
- corrected 56-row ledger and A01–A18 register;
- C1B05 relation plan, all helper versions, plans, admissions, raw execution, observer/JUnit where used, source captures, row snapshots, errors and positives;
- registration-only gate/revision diff and qualification;
- preservation, output-copy, cleanup and non-effect records;
- failed/superseded audit-helper attempts with no-credit classifications.

Do not duplicate A's entire source/history tree or ancestor ZIPs. The outer package may contain at most 2,000 regular members, 128 MiB per member and 256 MiB total expanded bytes. One exact 87,897,841-byte RU member is expected. Reopen every member and verify the complete self-excluding size/SHA/CRC/numeric-mode manifest.

Return inline:
- exact verdict and candidate tree;
- C2A11 and C2A20 adjudications and their limits;
- newly closed C1B05 rows and any exact remaining row;
- carried W suite revision and counts, separately from new runs;
- candidate-defect statement;
- report/ZIP/manifest byte counts and SHA-256;
- recipient ChatGPT and next action.

Include an adjacent delivery receipt. No live commit or publication action follows.
