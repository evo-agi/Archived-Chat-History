Here is Codex's response:

# RW0 normal terminal closure — cumulative precommit audit

**Primary verdict: `RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE`**

The exact 327-file candidate tree is `4691af58ae0ee3107b4e2e9b6b1508032944e357`. It remains uncommitted and unaccepted. The completed probes found no current candidate source defect, but mandatory causal and administrative cases remain unproved. The required independent direct and selector-free FULL gates therefore were not launched.

The host supplied `/private/tmp/rw0-audit-entry.daLWIE` as the working directory. No project or repository binding was exposed, so that binding remains unknown. This audit used one new owned namespace, `auditqs-78f604b32c`. It did not use Git, a live repository, network services, subagents, or a product database, and made no candidate source or `.docs` changes.

## Provenance and audit boundary

A, B, C, E and Q passed fresh input authentication. A’s final-C, final-D and postcleanup source manifests were byte-identical; four rebuilt source copies matched all 327 paths, bytes, Git blobs, modes and the candidate tree. E’s baseline and patch reconstruction and its reconciled writer records were carried as **prior data**, not credited as fresh candidate execution. PR #17 and commit `61d0330aba1160f7f5e7d9c541a325222d1c61e5` remain retained baseline claims; no live Git observation was made.

Qs was exactly Q’s policy plus `(allow signal (target same-sandbox))` and a newline: 2,674 bytes, SHA-256 `0ff27cde4b1dfade46dc6ad0add110497d8633e509cd2c923107d5ddf8163961`. Synthetic tests demonstrated signal delivery and reaping for owned direct, fork, exec, descendant and cross-session group targets, including the TERM-ignore/KILL case. Live outside and independently launched identical-Qs cohorts remained responsive after denied PID and group signals. The original 40 controls then passed in each of four roles, **160 role/control results** in total. The prior Q and E verdicts are unchanged.

Every candidate probe ran through exact Qs with the fixed Python `-I -B` bootstrap and the calibrated, nonselecting audit observer. The supervisor retained actual launch arguments, environment, raw outputs, exits, helper hashes, JUnit properties and complete source captures. Across **13 passing causal launches, 51 selected calls passed**, with passing setup/call/teardown, zero warnings and unchanged 327-row source captures. Earlier failed calibration and historical observer attempts are retained as audit-helper mistakes, not candidate defects.

## Reached findings

The two owning `.docs` files state the amended contract: common managed admission may shape-check today’s `global_stop_current` before fencing; receipt-present terminal history then uses saved five-head postimages, saved stop and immutable predecessors. Fresh receipt miss still reads all five actual heads and stop. The historical probe traced the real acquisition and operation opener aliases and wrapped the unchanged validator, ownership, issuance and disclosure functions. Its refined run showed managed-stop callbacks inside the actual `_verify_global_stop_current_shape` function, no five-current-head lookup during receipt-present history, and no protected content lookup before observer attachment. Callback totals count columns, not SQL statements. Denying the actual managed-stop read refused the operation before terminal-family handling; malformed stop state failed as integrity, and valid behavior returned after fault removal. Synthetic later movement of all five heads and valid active/clear stop states preserved exact accept and replan history.

The direct `TerminalHeadWitness` constructor and factories passed valid five-role accept/replan cases and 80 invalid or process-control controls. The prior malformed type triple, empty postimages, subclasses, bool-as-int, field/role errors, noncanonical bytes, oversize bytes and mismatched valid components were rejected before hostile equality calls. Caller-owned and returned map mutations did not change the retained checked witness.

Each of the five current-head roles separately produced a no-write stale-currentness result when moved against old caller expectations. For each role, a valid resealed historical family first read, replayed and recovered exactly; an internally resealed family with a wrong immutable predecessor then failed as integrity, with unresolved recovery. These head movements and resealing steps were owned test fixtures, not product operator transitions.

Five source-coherent branches varied before artificial fixture sealing and reached P0/D1/D2, Section 41, C1, V22, P1 and terminal owners: **accept, repair, replan, terminal reject and block**. Each produced its distinct normal outcome, exact read/replay/recovery, four terminal rows and no protected-row movement. Thirty fresh posture denials left zero terminal rows. Historical operations remained exact without recording permission or renewed acceptance eligibility; denied, expired, malformed, foreign-bound and absent disclosure sources did not reveal committed results. Three cancel-shaped branches and an unsupported live profile were rejected before write. Three private replan text canaries were absent from the observed terminal rows.

Seventeen separate owned, FK-valid scenarios physically occupied the 17 indexed route columns. A competing mutation received `route_collision`; a compatible complete winner established original absence without disclosing the winner. **Each complete family also occupied other route columns**, so these runs do not isolate every later probe as the first match. A separate physical `[context,outcome,result,receipt]=[1,1,1,0]` family gave nondisclosing read refusal, unresolved recovery and no fragment repair.

Faults hit after each of four inserts and both readback boundaries and left no terminal rows. KeyboardInterrupt, SystemExit and GeneratorExit propagated at fresh insert, read, recovery and read-cleanup seams without state movement. One real commit was applied with its return deliberately lost: the outward result was `commit_outcome_unknown`, four rows existed once, and later recovery found the exact original commit.

All eight authenticated current SQL literals ran in owned SQLite. Inventories after 0006, 0007 and 0008 were respectively **68/122/5**, **74/134/5** and **78/142/5** tables/triggers/explicit indexes. Fresh and prefix migrations reached generation 2; selected old-binary, obsolete-checksum and divergent-schema states were refused. Raw SQL checks reached all three `recorded_at` columns with nine valid and 26 invalid values each; high-level row construction rejected bad self-digests and malformed times. A synthetic malformed stored time produced integrity failure and unresolved recovery. In an owned predecessor-only table, F01’s old `strftime(...) = recorded_at` predicate evaluated NULL and admitted an invalid month. The current explicit month guard rejected it. This is a grammar comparison, not a claim of an ordinary writer exploit.

## A01–A18 cumulative register

Coordinates are relative to A’s `source/`, except paths beginning `evidence/`. **S** means authenticated code or docs inspected; **T** inspected candidate test design; **R** retained prior data; **X** fresh independent causal execution; **O** mandatory validation still open. An `O` is an acceptance evidence gap, not an established product defect.

| ID | Owner coordinates | Disposition |
| --- | --- | --- |
| A01 Authority | `.docs/rw0-terminal-outcome-physical-closure.md:3-23`; `_rw0_terminal_outcome_contracts.py:201-320` | Five private normal outcomes visible; cancel shapes and live profile rejected. Broader scope regression open. **S,T,X,O** |
| A02 Preservation | `sqlite_writer_session.py:6860-6941`; `sqlite_transition_transaction.py:2759-2785`; `sqlite_migration.py:790-803,2477-2523` | Shared admission and fencing reached; full legacy and public-export regression awaits complete gates. **S,R,X,O** |
| A03 Grammar/types | `_rw0_terminal_outcome_contracts.py:71-114,201-421`; `_rw0_terminal_outcome_rows.py:90-180`; `_rw0_terminal_head_witness.py:49-197` | Constructor, hostile-equality, row and calendar controls passed; full graph-negative inventory open. **S,T,X,O** |
| A04 Identity graph | `_rw0_terminal_outcome_contracts.py:201-320`; `_rw0_terminal_outcome_plan.py:115-285`; migration `0008:1-223` | Original graph and resealed family checked; complete independent sibling/domain/alias negatives open. **S,T,X,O** |
| A05 Original operands | `_sqlite_rw0_terminal_outcome.py:144-207,318-344,404-445` | Original transient P1/replan use inspected; inconsistent private content under a shared claimed safe identity open. **S,T,X,O** |
| A06 Source association | `_sqlite_rw0_terminal_outcome.py:129-207`; `_rw0_d2_post_execution_continuation.py:152-225,273-405` | Five coherent chains passed; separately resealed detached associations and distinct forged V22 proposal **reference** open. **S,T,X,O** |
| A07 Acceptance | `_sqlite_rw0_terminal_outcome.py:193-199,359-401`; `_rw0_terminal_outcome_plan.py:148-162` | Existing accept fact preserved; a legitimate unrelated fact coexisting in the same owned chain remains unproved. **S,T,X,O** |
| A08 Heads/stop | `_rw0_terminal_head_witness.py:19-197`; `_rw0_terminal_outcome_plan.py:54-112`; `_sqlite_rw0_terminal_outcome.py:216-259,318-383`; owning `.docs:177-220` | Two-layer phase, five-role drift/reseal and fresh actual currentness passed within tested scope. **S,T,R,X** |
| A09 Transaction | `sqlite_writer_session.py:6860-6941`; `sqlite_transition_transaction.py:1381-1467,3158-3250` | Four inserts, receipt-last readback, rollback and applied/lost-return commit passed; remaining lease and cleanup uncertainty open. **S,T,X,O** |
| A10 Read/replay | `_sqlite_rw0_terminal_outcome.py:318-356`; `sqlite_migration.py:2477-2523` | Saved history and current protected disclosure passed after later heads/stop; actual shape function isolated. **S,T,R,X** within tested scope |
| A11 Recovery | `_sqlite_rw0_terminal_outcome.py:262-306,404-445` | Exact, absence, compatible winner, 17 physical columns and one partial family reached; foreign/damaged family and isolated later-route causality open. **S,T,X,O** |
| A12 Error/cleanup | `_sqlite_rw0_terminal_outcome.py:65-113,404-445`; `sqlite_writer_session.py:6860-6941`; `sqlite_transition_transaction.py:4753-4773` | Selected denial, malformed, fault and process-control cases passed; closed/stale/fenced and remaining cleanup cases open. **S,T,X,O** |
| A13 Schema/admin | migration `0008:1-223`; `sqlite_migration.py:512-523,790-803` | Eight literals, inventories, calendar, prefix and selected refusals passed; old SQL/current-history and remaining divergences open. **S,T,R,X,O** |
| A14 Connected normals | `_rw0_d2_post_execution_continuation.py:273-405`; `tests/test_sqlite_rw0_terminal_connected.py:214-475` | Five preseal normal branches and privacy canaries passed; complete direct module unrun. **S,T,R,X,O** |
| A15 Docs/assurance | two owning `.docs` sections; `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:1999` | Amendment present; static binding and selected runtime checked; full consumer regression unrun. **S,T,R,X,O** |
| A16 Privacy/artifacts | `_rw0_terminal_outcome_rows.py:90-180`; `_rw0_terminal_outcome_plan.py:115-285`; migration `0008:1-223` | Terminal-row canaries absent in reached replan; raw index, checkpoints and failed-artifact scope incomplete. **S,T,X,O** |
| A17 Retained evidence | `evidence/validation/{direct,connected,focused,full}/`; `evidence/gate-summary.json`; `evidence/final-C-manifest.json` | E writer records remain data; new observer/JUnit and source captures reconcile 51 causal calls, while direct/FULL are absent. **R,X,O** |
| A18 Independent validation | `pyproject.toml:1-20`; terminal values, migration and connected test modules | Qs, causal and selected SQL/admin reached; independent direct 60 and selector-free FULL 9,568 were not launched. **S,T,R,X,O** |

## Remaining gate and disposition

The finite matrix still lacks the coherent unrelated acceptance and detached proposal-reference cases, inconsistent private replan content under a claimed safe identity, additional foreign/damaged route families, closed/stale/fenced session and current-owner denial cases, remaining cleanup uncertainty, and old-SQL/current-history administrative divergence. The operative mandate requires the complete causal/admin matrix before the direct and FULL launches. **Independent direct collection: 0; direct execution: 0; FULL collection: 0; FULL execution: 0.** The retained writer gates and earlier interrupted predecessor FULL receive no independent-run credit.

Early audit-only parser, calibration and opener-alias errors were retained and corrected. They do not establish a candidate defect. Following protected evidence transfer, only this audit namespace’s transient scratch, home, tmp and denied directories were removed. Earlier namespaces, authoritative inputs, exact source copies and protected evidence were preserved. No staging, commit, push, PR, merge, release, deployment or publication was performed or authorized.

## Deliverables and verification

The standalone report was saved **before** sealing the ZIP. The ZIP contains that report byte-for-byte, a self-excluding manifest, audit-authored policy/scripts/observer, input and source checks, classified raw logs, launch captures, JUnit records, causal results, retained-data labels, cleanup record and gate summary. All **299 ZIP members** were reopened and verified; the adjacent receipt records the same identities.

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| [Full report](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/auditqs-78f604b32c/RW0_NORMAL_TERMINAL_CUMULATIVE_AUDIT_INCOMPLETE_20261029_auditqs-78f604b32c.md) | 25,571 | `b0fa83d8baeede4fc52fe21f488d3fcfbd9472f28656444ed5a3c84377ae70de` |
| [Reopened evidence ZIP](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/auditqs-78f604b32c/RW0_NORMAL_TERMINAL_CUMULATIVE_AUDIT_INCOMPLETE_20261029_auditqs-78f604b32c.zip) | 1,650,029 | `ffd593b643c1c6fc6c064a84d9b473ce4f34cc1b2f1be35706d0b2d08db4bd2f` |
| ZIP `MANIFEST.json` | 70,143; 298 rows | `fb690025b16871b59ae2c6c1512e4a72b1fe69d8a18c0e4490eb467a8d2fcf14` |
| [Adjacent receipt](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/auditqs-78f604b32c/RW0_NORMAL_TERMINAL_CUMULATIVE_AUDIT_INCOMPLETE_20261029_auditqs-78f604b32c.receipt.json) | Records the reopened identities | — |

The exact tree remains **unaccepted and ineligible for a live exact-byte commit gate** on this evidence.
