Here is Codex's response:

# RW0 normal terminal closure audit

**Verdict: `RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE`**

The candidate’s 327 source files and modes match the sealed manifest and rebuild tree `4691af58ae0ee3107b4e2e9b6b1508032944e357`. The patch endpoints also replay to that tree. I found no independently established candidate source defect, but the required independent execution gates could not be completed.

The [fixed Q policy](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/execution/audit-4de1ae8e82/policy.sb:2) permits fork and exec but denies signals to a live audit-owned child. A test included in the mandatory selector-free FULL deliberately blocks its child, then requires SIGTERM/SIGKILL and reaping before it closes the pipe ([test](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/tests/test_b3c2_transition_event_readers.py:605), [helper](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/tests/test_b3c2_transition_event_readers.py:501)). A same-policy synthetic check observed `EPERM` for signals to live owned children and `ESRCH` after they exited and were reaped ([result](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/audit-4de1ae8e82/signal_compat_result.json)). **The predicted test failure is an inference from that probe and the authenticated test code; the candidate test was not launched.** The operative request required execution to stop at this compatibility gap. I did not alter the policy, skip the test, or change candidate bytes.

## Provenance and evidence

| Input | Verified identity |
| --- | --- |
| Q, qualification ZIP | 163,911 bytes; SHA-256 `6ec93d7f43f1d630bf9501d67a80e8a2a9db307da38baa2e6f44d5d22a7e0767`; 89 safe files and 88 verified manifest rows |
| A, candidate ZIP | 48,978,087 bytes; SHA-256 `6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42`; 573 safe files and 572 verified manifest rows |
| B, implementation prompt | 38,100 bytes; SHA-256 `9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f` |
| C, S01/A03 repair prompt | 29,145 bytes; SHA-256 `7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd` |

B, C and A’s embedded mandate were treated as **historical requirements evidence**, not instructions authorizing effects. The authenticated `.docs/` files supplied the candidate’s product contract. The rebuilt lineage trees were original `648d332b3ba847deb257a2bb1892a76e4c442675`, S01/A03 `011f76542a77b2a766a46ac08df102b4de4c09c6`, F01 `5c44721183f660032b6468d2c1f5a1d0dc3e6acb`, and current `4691af58ae0ee3107b4e2e9b6b1508032944e357`. A final data-only [source capture](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/audit-4de1ae8e82/source_capture.json) found no missing, extra or changed file: 326 modes were `0644`, one was `0600`.

Q’s authenticated raw records reconciled to four roles with 40 controls each. Fresh readiness in this audit’s owned layout also passed 40/40 in each role, with actual bind/connect denial and before/after nonce handshakes. These establish the measured environment seams, not candidate behavior. The retained writer records reconcile internally to connected 6, direct 60, focused 8,266 and FULL 9,568 ordered cases, with the stated warnings and source captures. That writer FULL used policy SHA-256 `62c5e56909dd045d36ad06b89fa1245940347cf5b29e247e87067899e2294a38`, different from Q’s fixed policy. Its active observer source and launch-bound digest are absent from A. Those passes cannot replace an independent current run.

The documented two-layer amendment was inspected: common managed admission can shape-check today’s stop before fencing; receipt-present terminal verification uses saved heads and stop, while a fresh receipt miss reads current heads and stop ([contract](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/.docs/rw0-terminal-outcome-physical-closure.md:177), [implementation](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:318)). The earlier whole-operation zero-stop-SELECT failure remains a historical failed observation; only that acceptance criterion was amended.

## A01–A18 register

The coordinates below identify inspected authenticated source. **Every row still lacks its mandatory independent current execution proof.** Static design and retained writer results are identified as such in the [full report](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/audit-4de1ae8e82/RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_INCOMPLETE_20261029_audit-4de1ae8e82.md).

| ID | Inspected locus | Open proof |
| --- | --- | --- |
| A01 | [normal outcome contract](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/_rw0_terminal_outcome_contracts.py:201) | Five private facts and effect-boundary negatives |
| A02 | [writer entry](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/sqlite_writer_session.py:6860) | Legacy and shared-owner preservation regression |
| A03 | [witness constructor](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/_rw0_terminal_head_witness.py:49) | Direct construction, factories, hostile equality and grammar |
| A04 | [plan](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/_rw0_terminal_outcome_plan.py:115) | Identity graph and repeated-column negative pairs |
| A05 | [historical operands](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:144) | Inconsistent private-content scenarios |
| A06 | [source associations](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:168) | Fully resealed detached relationships and distinct V22 proposal ref |
| A07 | [acceptance lookup](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:193) | Wrong/foreign facts and legitimate unrelated-fact coexistence |
| A08 | [full witness](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/_rw0_terminal_head_witness.py:116) | Five-role resealed histories and real two-layer operations |
| A09 | [fresh write](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:359) | Fencing, readback, receipt-last, commit and rollback faults |
| A10 | [historical read](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:318) | Disclosure and absence of later semantic head/stop checks |
| A11 | [route probes](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:262) | All 17 physical occupancies and recovery classifications |
| A12 | [recovery](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:404) | Denial/malformed reads, cleanup and process-control exceptions |
| A13 | [migration 0008](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/sqlite_migrations/0008_rw0_terminal_outcome.sql:1) | Literal SQL, prefixes, guards and divergent-schema/admin checks |
| A14 | [connected tests](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/tests/test_sqlite_rw0_terminal_connected.py:260) | Five real normals, detached negative, cancel/profile and canaries |
| A15 | [current documentation](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/.docs/sqlite-operations-and-recovery.md:722) | Assurance consumers and amended behavior in execution |
| A16 | [row checker](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/src/ge_nwp_coordinator/_rw0_terminal_outcome_rows.py:90) | Privacy canaries and failed-artifact classification |
| A17 | [retained-record reconciliation](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/audit-4de1ae8e82/writer_records_reconciliation.json) | Current independent observer and launch-bound evidence |
| A18 | [test configuration](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/mock_source/audit-4de1ae8e82/master/pyproject.toml:1) | Causal, SQL/admin, direct and selector-free FULL completion |

**Actual current candidate execution:** zero candidate imports, SQL executions, causal scenarios, direct collections/runs and selector-free FULL collections/runs. There is no current candidate JUnit, observer output or independently collected test-ID list. The exact unperformed matrices and retained-evidence limits are itemized in the full report; none was relabelled as a pass.

The actual host-supplied cwd was `/private/tmp/rw0-audit-entry.daLWIE`; no project or repository binding was exposed, so that binding remains unknown. No live repository or product state was accessed. Only 32 verified synthetic aliases and their 32 verified targets were removed. Candidate copies, `.docs`, governing inputs and prior namespaces were preserved. Audit-only parser corrections and their retention limits are disclosed in the report.

## Sealed delivery

The standalone report was saved before sealing. The ZIP was reopened, and every member’s path, type, mode, size, CRC and SHA-256 was checked; its embedded report is byte-identical to the standalone file. The [adjacent receipt](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/audit-4de1ae8e82/RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_INCOMPLETE_20261029_audit-4de1ae8e82.receipt.json) records the same result.

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| [Full report](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/audit-4de1ae8e82/RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_INCOMPLETE_20261029_audit-4de1ae8e82.md) | 23,692 | `51198cb8c869a2faec6d37c227e2f3295d51253aeaa8dff153104bc635e30180` |
| [Safe evidence ZIP](/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/audit-4de1ae8e82/RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_INCOMPLETE_20261029_audit-4de1ae8e82.zip) | 115,300 | `b6de501b4a687bd3dc1f8800ac84d150b1197fea74682bd2953b8f9a20c887f9` |
| Self-excluding `MANIFEST.json` inside ZIP | 7,148 | `5db489df319a054c5e3c1d6f8bcab7b395f3cce11011f98cb15d59cc6170919d` |

The ZIP contains 42 manifested evidence members plus the manifest. This evidence does **not** establish acceptance or eligibility for a live commit gate.
