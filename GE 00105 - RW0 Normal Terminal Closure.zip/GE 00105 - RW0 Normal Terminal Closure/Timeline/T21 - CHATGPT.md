## Engineering disposition

```text
RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR
STATICALLY_READY_FOR_FRESH_CUMULATIVE_AUDIT
```

**The package authenticates. The inspected repair enforces direct witness construction and records the two-layer historical-access amendment without changing shared admission code. No new blocking production defect was established in this receiving pass.**

Preserve exact uncommitted tree:

```text
4691af58ae0ee3107b4e2e9b6b1508032944e357
```

Keep the implementation conversation idle. This is readiness for independent audit—not acceptance or commit eligibility.

## Authenticated subject

| Item | Verified result |
|---|---|
| Review ZIP | **48,978,087 bytes** |
| ZIP SHA-256 | `6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42` |
| Archive | **573 regular members; 572 verified manifest entries** |
| Final source | **327 files** |
| Final manifest SHA-256 | `1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1` |
| Immediate repair | **Five modifications; no additions, deletions, or mode changes** |
| Cumulative terminal change | **67 modifications and twelve additions; no deletions or Git-mode changes** |

I reconstructed the complete source lineage from archived payloads, through the integrated baseline, original terminal candidate, S01/A03 repair, F01 repair, and current candidate. Independent data-only replay reproduced all **five immediate patch sections / fourteen hunks** and **79 cumulative sections / 140 hunks**, including the twelve additions.

The final C/D/postcleanup manifests are byte-identical. Both patch-manifest encodings also reproduce from the authenticated endpoint bytes. The cumulative Git-baseline endpoints correctly leave historical POSIX modes unspecified; that is distinct from the current archive’s **326 `0644` files and one classified `0600` file**.

The latest prior audit’s full report and evidence ZIP are now authenticated inside this package. Its failed whole-operation requirement and its process deviations remain historical facts, not retrospective passes. Pasted text

:chatgpt-content-reference{index="2"}[Detailed receiving inspection](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Historical_Admission_Witness_Receiving_Review.md)

## Static repair judgment

### Direct construction now validates the witness

The production change is confined to:

```text
src/ge_nwp_coordinator/_rw0_terminal_head_witness.py
```

The constructor independently decodes canonical bytes, obtains owner-checked full postimages and compact projections, checks the supplied tuple/dictionary/scalar types, and rejects inconsistent representations. Both factories reach that same constructor; there is no unchecked construction token or recursive factory shortcut.

Canonical bytes and immutable scalar tuples are retained internally. The `postimages` and `coordinates` properties return newly constructed dictionaries, so ordinary mutation of caller-owned or returned mappings does not change the checked internal value.

The relevant implementation is at `:48–171`, with factory entry points at `:174–193`. The new regression cases at `tests/test_rw0_terminal_head_witness_regression.py:702–839` cover direct/factory equivalence, malformed and subclassed components, differing valid witnesses, hostile-equality calibration, and mapping mutation. These are inspected code and test designs; I did not execute them. Coordinator_RW0_Normal_Terminal_Historical_Admission_Witness_Receiving_Review\.md[Source-grounded inspection](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Historical_Admission_Witness_Receiving_Review.md)

### Historical access is amended explicitly—not weakened through a bypass

The two governing documents now distinguish the intended layers:

**Operational admission remains mandatory.** Managed-store validation may read the current stop singleton to validate its shape before writer fencing. An unreadable or malformed managed store can still prevent disclosure or leave recovery unresolved.

**Historical terminal verification remains independent of current semantic state.** Once admitted and fenced, read, receipt-present replay, and recovery reconstruct the saved result, timestamp, graph, receipt, full heads, and stop from stored witnesses and immutable predecessors. They must not consult today’s five heads or perform a later semantic stop query.

The documents also clarify that “receipt-first” means the first **terminal-family** lookup, not the first SQL statement. Fresh receipt-miss recording retains its current-head and stop checks.

The shared migration validator, transaction controller, writer session, and terminal SQLite owner are byte-identical to the immediate predecessor. This is a documented acceptance-requirement amendment, not a new availability mechanism or a production preflight bypass. The earlier audit had correctly exposed the conflict between the stronger whole-operation requirement and shared managed-state validation. Pasted text

### The new phase tests use real validators, with an important audit qualification

The observer wraps the actual acquisition and controller opener aliases and calls the real managed validator and ownership-read functions. It calibrates attachment using actual allowed and intentionally denied queries. The tests then exercise real `WriterSession` read, replay, and recovery after later head and active/clear stop changes, plus managed-stop denial, malformed-stop failure, competing winners, absence, and fresh recording.

However, **the test labels the whole managed-validation wrapper**, rather than the individual stop-shape function. The independent auditor must trace that unchanged call chain and verify that every permitted stop read really serves the existing shape invariant. A phase label alone cannot authorize arbitrary semantic stop reads.

Acquisition observations are also separate from the operation-only JUnit maps. The fresh audit must account for acquisition and every operation connection rather than infer whole-call coverage from those maps alone.

Exact test anchors:

```text
tests/test_rw0_terminal_head_witness_regression.py:
69–167       observer and calibration
878–1000     historical positives and admission failures
1003–1078    absence/winners and fresh-currentness controls
```

## Retained validation reconciles

Independent parsing of the archived observers, launch/exit records, phase outcomes, JUnit properties, warnings, and source captures gives:

| Gate | Unique collected = execution-collected = calls = JUnit = passed | Warnings |
|---|---:|---:|
| Direct, five complete modules | 60 | 0 |
| Connected | 6 | 0 |
| Focused, 126 complete modules | 8,266 | 3 |
| Selector-free FULL | 9,568 | 3 |

Every final setup, call, and teardown outcome passed. Explicit JUnit `nodeid` properties match the ordered inventories. The six connected cases are included in direct, direct in focused, and focused in FULL; **the counts are not additive**.

All sixteen source captures are byte-identical and their complete source rows match the canonical manifest. The two direct JUnit phase-map properties reproduce six operation connections and 60 managed-stop **column READ callbacks** per accept/replan scenario, with no unexpected operation current-head or later-stop callback. Those callbacks are not SQL-statement counts.

These remain **inspected implementation execution records**, not tests independently run here. RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPORT_FROM_SEALED_ZIP.md[Exact implementation report extracted from the sealed ZIP](sandbox:/mnt/data/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPORT_FROM_SEALED_ZIP.md)

### Retained-evidence limits remain explicit

The current launches load an external `gate_observer`, but its active source bytes and a launch-bound helper digest are not included in the current outer archive. Consequently, the records reconcile, but I cannot inspect that helper’s claimed nonselecting behavior. The new audit must author, retain, calibrate, and use its **own** observer for independent execution.

The first seven-case checkpoint is represented by a receipt and matching JUnit, rather than a complete reconstructible checkpoint source payload. It receives no final-byte credit. Similarly, reproducing the provided patch manifests does not establish two historical writer executions when only one encoding per kind was retained.

These are evidence qualifications, not established production defects. They are carried into the audit; any mandatory proof left unavailable must remain incomplete rather than be supplied by inference.

## Next Codex handoff

Use a **fresh independent Codex precommit-audit conversation in a neutral artifact-only workspace**, not the implementation conversation or the live repository workspace.

Send this **one operative prompt**:

:chatgpt-content-reference{index="5"}[**Normal terminal closure — historical-admission/witness cumulative independent audit**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Historical_Admission_Witness_Independent_Cumulative_Audit_Prompt.txt)

Attach exactly these **three evidence inputs**:

1. RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW\.zip[**Current historical-admission/witness review ZIP**](sandbox:/mnt/data/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip)
2. :chatgpt-content-reference{index="7"}[**Original terminal-closure implementation mandate**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt)
3. :chatgpt-content-reference{index="8"}[**S01/A03 repair mandate**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt)

**The two older mandates are requirements evidence only. The new audit prompt is the sole operative instruction.** The current two-layer amendment is authenticated inside the ZIP at `inputs/mandate.txt`; the F01 requirements and historical source/audit packages are nested inside it.

No separate implementation report, prior audit ZIP, receiving review, or chat history is needed.

The mandate requires authentication, cumulative source review and isolated validation, then findings and acceptance limits within one engagement. It explicitly carries:

- the amended admission/history boundary and direct-constructor repair;
- all outstanding **A01–A18** obligations, including the remaining physical-alias, proposal-reference, unrelated-acceptance, and posture controls;
- independent SQL and causal checks;
- an independent **60-case direct run** and completed selector-free **9,568-case FULL**, with explicit JUnit identities and unchanged source/mode captures.

It prohibits preliminary live-checkout discovery and excluded-path isolation probes. A provider or environment limitation must produce an accurately scoped incomplete result—not weakened acceptance or an assumption about execution.

:chatgpt-content-reference{index="9"}[Handoff identities](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Historical_Admission_Witness_Audit_Handoff_Check.json)

**No new Project snapshot is requested.** PR #17 remains the integrated baseline; the terminal candidate remains uncommitted and unaccepted.

**Inspection limits:** No candidate code, tests, SQL, migrations, supplied helpers, live Git operations, or network calls were executed. This pass establishes artifact identity, retained-record consistency, and targeted static judgments.

**Sources:** Coordinator_RW0_Normal_Terminal_Historical_Admission_Witness_Receiving_Review\.md[Receiving inspection with source coordinates](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Historical_Admission_Witness_Receiving_Review.md), RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPORT_FROM_SEALED_ZIP.md[authenticated implementation report](sandbox:/mnt/data/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPORT_FROM_SEALED_ZIP.md), and Coordinator_RW0_Normal_Terminal_Historical_Admission_Witness_Receiving_Verification.json[machine-readable verification](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Historical_Admission_Witness_Receiving_Verification.json).

**Confidence:** artifact identity and retained-record reconciliation **0.99**; targeted static repair assessment **0.97**. Independent runtime correctness and commit eligibility remain unestablished.
