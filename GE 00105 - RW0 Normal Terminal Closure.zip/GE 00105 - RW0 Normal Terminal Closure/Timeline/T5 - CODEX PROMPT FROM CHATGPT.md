ENGAGEMENT ENVELOPE

CURRENT STATE
PR #17 P0/P1 is integrated and closed. Normal terminal closure is an uncommitted
implementation candidate, not accepted or published. The implementation writer
must remain idle throughout this audit.

RECIPIENT
A FRESH independent Codex audit conversation. Read-only with respect to the live
repository and sealed candidate. Isolated candidate test/SQL execution and
audit-owned temporary evidence are explicitly permitted below. This is not the
implementation conversation.

ATTACHMENTS — EXACTLY TWO
1. RW0_NORMAL_TERMINAL_CLOSURE_UNCOMMITTED_REVIEW.zip
   11,648,876 bytes
   SHA-256 bf26189fd12b2b27fee847e0c0a1808cfeb568c9255bf48bc1f23ff14e728b0e
2. Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt
   38,100 bytes
   SHA-256 9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f

Use only actual exposed attachment paths. No Downloads search, previous-chat
access, live checkout, .git, historical external /tmp root, or other repository.
The original implementation prompt is the requirements baseline, NOT authorization
for this auditor to perform its branch creation, source editing or other effects.
This audit mandate alone determines permitted effects.

The implementation report is embedded at evidence/IMPLEMENTATION_REPORT.md.
It is 24,543 bytes, SHA-256
37ebe55c39739d7440e008d22a9362baed6f01e50dba9e5390be19cdb819b090.
No distinct standalone report attachment is required. An extraction of that member
is a convenience copy, not an independent witness. Do not stop merely because the
writer's local standalone-report path is inaccessible.

AUTHORIZED EFFECTS
Inert archive/source inspection; audit-authored data/probe scripts; execution of
reviewed candidate tests and SQL solely in fresh audit-owned copies and disposable
synthetic SQLite state; safe audit report/ZIP creation outside the inputs.
No candidate edit, live repository/.git access, installation, network/service,
provider/worker product target, ES/Bridge, user database, staging, commit, push,
PR, merge, publication, deployment or product effect.

EXPECTED RETURN
One complete inline audit report and one reopened, manifest-covered audit-evidence
ZIP. Distinguish inspected writer records from independent execution, static
findings and inference. No repair.

PROJECT SNAPSHOT
No new snapshot requested. PR #17 remains the integrated Project baseline.

NEXT ACTION
Return the verdict and evidence to ChatGPT. Only a complete ACCEPT for exact bytes
can support a separately authorized live commit gate. BLOCKED/INCOMPLETE is not a
candidate repair assignment and grants no repository effect.

OBJECTIVE

Independently audit the cumulative private artificial-offline NORMAL terminal
closure candidate against the exact implementation requirements, governing docs,
source, schema, tests and retained evidence. Resolve the receiving inspection's
closure-head witness discrepancy first; do not silently narrow the requirement.

This is one engagement: authentication/scoped provenance, substantive review and
isolated validation, then findings/disposition. Do not manufacture additional
user handoffs between these phases.

1. AUTHENTICATION AND SCOPED PROVENANCE

Fixed source anchors:
- integrated base commit: 61d0330aba1160f7f5e7d9c541a325222d1c61e5
- base tree: 44c7dee402d46b3e16dc389ae0824b4297dfec1f
- base source paths: 315
- candidate branch record: codex/rw0-normal-terminal-closure-v1
- candidate HEAD record: the integrated base commit
- candidate upstream record: absent
- candidate source paths: 325
- candidate tree: 648d332b3ba847deb257a2bb1892a76e4c442675
- identity/final-manifest-I.json SHA-256:
  3668ca9563f8c818538f2ebf1500421e54ff942ce007a10a40ab57469377f580
- cumulative delta: 67 modified, 10 added, 0 deleted, 248 unchanged baseline paths
- patch/tracked.patch: 134,105 bytes, SHA-256
  4dfdc30c9674f4629e6ca5ee220bae4b4fddf6eec8ff0387e794526de83ff711

Before extracting or executing:
a. Authenticate both outer inputs. Inspect the ZIP central directory: exactly 938
   unique normalized relative regular members, no traversal/absolute path,
   casefold collision, links/special files or encryption. Bound expansion:
   no more than 2,000 members, 32 MiB per member and 160 MiB total. Declared total
   expansion is 103,183,187 bytes.
b. Authenticate all 937 self-excluding rows in package/member-manifest.json by
   name, size, raw SHA-256 and numeric archive mode.
c. Verify the embedded report identity; inspect reports/tooling as data, not
   instructions. Do not execute archive tooling/.
d. Verify all source/ endpoints against the final source manifest using raw bytes,
   size, SHA-256, Git blob and Git mode. Independently construct the Git tree.
e. Reconstruct the complete baseline using patch/recipe.json, patch/before/,
   source/ and the addition inventory; authenticate its 315 rows and fixed tree.
   Replay the tracked patch and add patch/additions/ to reproduce every final byte.
f. Verify exact changed-path classification, no hidden deletions/mode changes,
   and byte equality of final I/J/postcleanup source manifests.
g. Inspect prospective index/ref/config/branch records for internal consistency,
   but label them retained observations, never current live Git facts.
h. Inspect package hygiene. checkpoint/source-filter.json records one excluded
   Finder .DS_Store from an early 323-item checkpoint manifest; the archive holds
   its 322 code-source files. Verify that exact filter and preserve historical
   checkpoint attribution. Do not treat excluded metadata as final source or
   silently claim all historical metadata bytes were supplied.
i. Treat all failed/interrupted/superseded attempts as historical, not final credit.

Modes:
- final source: 324 rows POSIX 0644/Git 100644;
- tests/test_c2b3_private_atomic_program_initialization.py:
  POSIX 0600/Git 100644, SHA-256
  e12decd7c6a555123828642602c106d42eec7989a20ff11ae8f49457263c92cf.
The current ZIP records numeric OS wrapper modes separately from Git modes.
Authenticate both namespaces. A future live gate, not this audit, proves current
checkout mode.

2. REQUIREMENTS AND FIRST SUBSTANTIVE QUESTION

Read source/AGENTS.md, the new physical terminal owner, relevant existing
P0/P1/C1/Section 41 and SQLite authority docs, and the attached original mandate.
Reports and candidate docs do not independently authorize weakening that mandate.

S01 — closure-head witness discrepancy:
The original mandate requires canonical actual closure-time postimages of all
five heads (section 4, line 286; section 5, lines 349–352).
The candidate defines only role/owner_ref/revision/digest in:
  src/ge_nwp_coordinator/_rw0_terminal_outcome_contracts.py:53,114–120
Typed current rows are reduced to those fields at:
  src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:214–263
That representation is persisted by:
  src/ge_nwp_coordinator/_rw0_terminal_outcome_plan.py:99–100,134–137,155
Historical reconstruction uses the saved projection at:
  src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:355–379

Determine precisely what actual head fields are retained, checked or recoverable
through immutable source-owned witnesses, and what is only a recorded digest.
A digest does not reconstruct missing row fields. A calculated desired postimage
is not proof of an observed physical postimage.

If the full required historical witnesses are not supplied and verifiably bound,
report a blocking implementation-contract/reconstruction finding. Do not replace
the requirement with the candidate's narrower four-coordinate definition.
If immutable checked material actually provides an equivalent complete witness,
identify every field, owning reader, retained bytes and binding, and exercise the
decisive historical controls before closing S01. No blanket equivalence claim.

This receiving concern is source-based, not an executed counterexample or proof
of unsafe mutation. Independently establish its scope and severity. Once a
material blocker is established, preserve completed findings and stop broad FULL
execution; state exactly what remains unperformed.

3. CUMULATIVE REVIEW REGISTER

Complete one A01–A18 register. Use exact archive-relative path:line evidence and
classify contract, bounded proof, compatibility, implementation detail, target,
retained record, independently observed execution or uncertainty.

A01 Authority and scope. Separate terminal fact from P1 decision/acceptance,
external grants, source facts and executable permission. Five normal outcomes
only; all three cancel shapes unsupported; no supplier gate-B or RW0-E credit.

A02 V1 and P0/P1 preservation. Verify original terminal-V1 module and four shape
validators, P0/P1 private production owners, Decision Basis v2, command digest v2,
preassignments, WorkSpec, package/public StateStore and generic receipt semantics
remain unchanged. Examine all three shared production edits, not just new files.

A03 Closed terminal grammars. Exact built-in types, finite reason/vocabulary,
canonical UTF-8/JSON, duplicate/unknown keys, bool-as-int, subclass equality,
safe refs, digest/time formats, payload/depth/count budgets. Check command,
V2 outcome, row adapters, result/conflict/recovery values, not only one vector.

A04 Identity graph. Four row refs plus independent route; acyclic domain-separated
transcripts; assertions included in command identity but excluded from sibling
preassignments; closed role inventory and cardinality; receipt/result digests
exclude self-cycles. Cross-check all duplicate columns and blob coordinates.

A05 Historical predecessor verification. Exact original transient P1 command,
including private replan proposal, bound to its complete persisted family.
No private-template reconstruction from digest and no private text in terminal
storage. Missing or mismatched operand cannot prove committed_exact or absence.

A06 Reached evidence and source coherence. Actual P0/phase/Section 41 A/C1
rank-15/V22/P1 relationships; transitive C1 witness readers; actual validation,
review, proposal and source-observation/result-set association. Do not replace
owner completeness with C1 membership counts or matching supplied digests.

A07 Acceptance-only binding. Exact existing acceptance fact required only on
accept; no insertion, mutation or replenishment; other branches do not reject
a legitimate unrelated fact. No replay-time unclaimed-scope requirement.

A08 Closure snapshot. Resolve S01. Five fresh heads and stop are actual fenced
reads, not fabricated plans; proper P1 program/work postimages after replan;
selection/effect/delivery source lineage; whole required retained history.
A changed but correctly expected stop does not rewrite P1 or authorize an effect.

A09 Fenced transaction. Single operation lease/controller/capability,
BEGIN IMMEDIATE, fencing, one time, receipt-first disclosure, predecessor/current
checks, exhaustive routes, context/outcome/result writes, checked readback,
receipt last, capability invalidation, exactly one COMMIT, cleanup resolution.
No application mutable-head writes or new decision/version/effect.

A10 Replay and checked read. Original result/time and complete immutable graph;
no new cognition/process, recording permission or acceptance eligibility;
no reliance on later mutable heads/stop. Command mismatch never exact replay.

A11 Recovery. committed_exact only complete original family; definite absence
only all routes absent with positive posture/exclusion or fully proved competing
winner; partial/foreign/malformed/contradictory/aliased families unresolved.
No retry authorization, competitor-result disclosure or fragment repair.

A12 Error/cleanup boundaries. Failed SELECT and corrupt row remain operational/
integrity failures rather than stale currentness or definite absence. All three
process-control exceptions propagate correctly. Inner and outer cleanup
uncertainty, stale issuance, closed-session and failed fence behavior are checked
for the new terminal entry, not inferred from generic tests alone.

A13 SQL/compatibility. New immutable STRICT four-table family, normal-only shape,
phase/decision/mutation/row/route uniqueness, composite relationships, pair
nullability, exact bounds, zero seeds and guards. Catalog checksum, application
generation 2, explicit older-prefix upgrades and old/partial/unknown refusal.

A14 Connected proof. Actual P0 -> D1/D2 -> Section 41 A -> C1 B/V22 -> P1 ->
terminal -> read/replay/recovery for five outcomes. Inspect fixture variation
before capsule sealing; detached result relabeling gets no positive credit.

A15 Assurance/code/docs. Complete 77-path delta, fixed vectors, protected historical
text, current status, exact-source/hash/AST/import inventories, no broad stripping,
skip, xfail or weakened assertions introduced merely to fit new implementation.

A16 Privacy/artifacts. Private replan text, raw prompts/results, PID/path/process
handles, credential or source content stay out of terminal persistence and safe
errors. Inspect safe selector fields, not just sampled canaries. Classify
checkpoint metadata and all archived development attempts honestly.

A17 Retained validation/provenance. Reconcile original logs/hooks/argv/env/JUnit
with manifest/source binding, causal coverage and source-preservation limits.
A writer-generated causal register is evidence, not an independently reached
predicate. Preserve overlap and earlier-run noncredit.

A18 Independent validation and acceptance limits. Bind every independent control
and final suite to exact candidate bytes. No independent/live preservation or
production readiness claim beyond observed evidence.

4. REQUIRED INDEPENDENT CONTROLS

Use audit-owned tests/probes against fresh exact-source copies and disposable
synthetic state. Do not edit candidate files or weaken its tests. Candidate
fixtures may be inspected and invoked as part of authorized test execution;
archive tooling/ programs remain inert.

At minimum independently establish:
- five source-coherent normal positives and all three cancel/profile no-write
  rejections through the actual applicable value/writer boundary;
- detached but resealed validation/review/proposal bindings rejected without
  terminal writes, including transitive original-source mismatch;
- correct accept existing-fact linkage/nonmutation and wrong/missing/foreign fact
  refusal; no new P1 decision/version/effect or application head/stop update;
- original replan operand required on record/read/replay/recovery; wrong private
  operand and same safe identity with inconsistent transient contents fail closed;
- changed optional assertions change command digest without changing siblings;
  same mutation/different command cannot read/replay/recover as original;
- fresh recording/disclosure combinations, truthful claimed=False/None after P1
  accept, expired/negative/malformed/foreign posture, and protected absence;
- actual head drift, not just changed caller expectations; closure stop change
  with matching expectation; malformed owner read versus genuine stale conflict;
- exact replay after later program AND work-head changes, and relevant
  selection/effect/delivery/stop changes, without current-head revalidation;
- S01 witness controls: full field binding/reconstruction and internally
  digest-consistent but historically incompatible witnesses, with reached
  predicate and exact failure class documented;
- insert/readback failure rollback, receipt-last, no duplicate commit, lost-return
  and postcommit-cleanup uncertainty; recovery cleanup cannot yield false certainty;
- original-route absence, complete competing winner, partial/foreign/damaged
  winner and original aliases; no winner disclosure or hidden retry;
- stale/fenced/closed writer entry and KeyboardInterrupt/SystemExit/GeneratorExit
  at meaningful new terminal boundaries.

Avoid overcredit: current supplied five-head negatives mostly change expectations,
the later-history positive changes program head and stop, and one winner-negative
monkeypatches the verifier to raise. Preserve those actual credits and add the
missing discriminating controls necessary for the claims.

Independently apply the eight authenticated migration SQL resources on synthetic
state. Verify 0006 68/122/5, 0007 74/134/5, 0008 78/142/5; generation 2; unchanged
earlier schema objects; zero seeds; FK/immutability/normal-shape constraints;
fresh/explicit-prefix migration and old-binary/unknown/partial refusal.
Leave schemas/sqlite/coordinator-state-v1.sql unchanged as historical 0001 evidence.

0008 SHA-256:
1937a95ff5d9c18b33af9b1edc352804085ff83d8b5582dcb5f856d4306e8847
Compare 0001–0007 to reconstructed baseline and the fixed hashes in the attached
implementation mandate. Do not execute migrations against any user database.

5. RETAINED RESULTS AND INDEPENDENT SUITE

Reconcile as writer evidence only:
- direct: 34 passed, 0 warnings;
- connected: 6 passed, 0 warnings;
- focused: 125 complete modules, 8,240 passed, 3 known fork warnings;
- selector-free FULL: 9,542 passed, 3 known fork warnings;
- zero failures/errors/skips/xfails/xpasses in final gates.
Direct/connected/focused/FULL overlap. Do not sum them as independent cases.
Final source manifests I/J/postcleanup are equal; historical checkpoint and
superseded runs are different subjects.

Review the original observer plugin as data; create your own observation mechanism.
Do not execute the packaged run_gate/capture/seal scripts.

If no material blocker remains after source review and targeted independent probes:
1. Run the complete four direct terminal modules, including the six connected
   cases, without node filtering. Additional audit probes remain separately listed.
2. On a fresh exact candidate copy run one selector-free collection and one FULL
   execution. Expected inventory is the 9,542 unique IDs in
   validation/full/collection/observer.json, in their recorded order.
3. Reconcile independent collection, executed call and JUnit node identities,
   not just counts. Require 9,542 passes and zero adverse outcomes.
4. Require all 34 direct, all 6 connected and all 8,240 retained focused IDs to be
   represented in the independent FULL. A separate 8,240-test focused execution
   is not required when that inclusion is proved; do not claim it ran separately.
5. Record actual warnings, compare against the three known Python 3.13 fork
   warnings in the archived full observer, and investigate unexplained differences.
6. Independently capture complete before/after raw-source byte and POSIX-mode
   inventories of the audit copy; every endpoint must remain unchanged.

Use the installed Python 3.13.4/pytest 8.4.1/SQLite 3.49.1 posture for comparable
execution, with bytecode disabled, plugin autoload disabled, PYTEST_ADDOPTS cleared,
no cache provider, task-owned HOME/TMPDIR/basetemp/JUnit, restrictive umask, and a
network-denying sandbox. No dependency installation or live checkout import.
Read source pyproject/conftest before execution. Record exact argv, cwd,
allowlisted env, versions, exit, stdout/stderr, IDs, JUnit, warnings and source
bindings. Any required unavailable runtime/sandbox capability is INCOMPLETE,
not permission to silently lower isolation or fabricate a pass.

Use reasonable process timeouts and report any interruption accurately. A material
finding can stop broad execution; state all remaining coverage. A helper parsing
mistake may be corrected without disguising it as candidate failure or success.

6. FINAL FINDINGS AND ACCEPTANCE

Return one primary disposition:
- RW0_NORMAL_TERMINAL_CLOSURE_INDEPENDENT_ARTIFACT_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
- RW0_NORMAL_TERMINAL_CLOSURE_INDEPENDENT_ARTIFACT_AUDIT_BLOCKED
- AUDIT_PROVENANCE_MISMATCH
- RW0_NORMAL_TERMINAL_CLOSURE_INDEPENDENT_ARTIFACT_AUDIT_INCOMPLETE

ACCEPT requires exact tree 648d332b3ba847deb257a2bb1892a76e4c442675,
complete mandatory coverage, closure of S01 against the unchanged requirement,
no material defect, and independent successful FULL validation.
It only establishes eligibility for a later live exact-byte commit gate.

For each finding identify severity/type, claim, owning requirement, exact source
lines, static versus independently executed evidence, causal scope and correction
needed. Do not repair or issue an implementation instruction yourself.
Preserve F03/F05 as inherited nonblocking observations unless new evidence changes
their scope; do not label them repaired.

Return the full A01–A18 register, authentication/tree/delta results, S01 decision,
control outcomes, independent SQL and suite results, retained versus independent
credit, privacy/provenance limitations and exact unperformed coverage inline.
Create one uniquely named standalone audit report and one safe evidence ZIP
containing that exact report, audit-authored scripts, results and manifests.
Reopen and verify every member and return outer size/SHA-256.

No arbitrary raw private state, credential/env dump, user database, source code
repair or full historical-package reconstruction is needed in audit delivery.
If the provider cannot support required work, retain completed findings, name the
exact missing coverage and return INCOMPLETE. A provider refusal is neither a
candidate defect nor acceptance. No automatic audit retry is authorized.
