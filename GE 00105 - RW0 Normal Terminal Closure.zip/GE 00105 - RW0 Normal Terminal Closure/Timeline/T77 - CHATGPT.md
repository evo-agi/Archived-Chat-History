## Engineering disposition

**The archive authenticates. The remaining generated-helper failure is a specific metadata-permission gap. I have selected one batched, metadata-only runner amendment—not a candidate repair and not another general sandbox-design task.**

The terminal-data correction and temporary-module allowance have supported representative passes. Preserve them unchanged. The next assignment completes metadata access for the **immediate entries of the owned audit root**, recalibrates that boundary, and proceeds directly through the representative tests, exact 99-case replay, complete suites, and residual audit.

The candidate remains unaccepted at:

```text
4691af58ae0ee3107b4e2e9b6b1508032944e357
```

## Authenticated evidence

| Item | Verified result |
|---|---|
| Uploaded ZIP | **6,221,246 bytes** |
| SHA-256 | `888edd2777a8c47eb06c37b37a3ad09d1e0efc7188c17a9b9cfce3cdaff4aa37` |
| Archive inventory | **125 regular files; 124 verified manifest rows** |
| Expanded size | **9,070,230 bytes** |
| Embedded report | **34,851 bytes**, matching its reported identity |
| Candidate | All **327 source files** authenticated and independently reconstructed to the fixed tree |
| Frozen Qtc | **3,414 bytes**, with the exact Qs prefix and authorized appendix |

Every covered member passed path, uniqueness, type, encryption, size, CRC, SHA-256, and numeric-mode checks. The embedded T, S, and R archives also authenticate against their previously reviewed identities.

All **fourteen complete source captures** match the candidate: five initial copies, five after-compatibility copies, and four launch before/after captures. The five postcleanup observations are summaries, not additional complete captures. No live checkout, index, or ref state was observed here.

:chatgpt-content-reference{index="2"}[Detailed receiving inspection](sandbox:/mnt/data/Coordinator_RW0_TC4FD7_Receiving_Review.md)

## The failure is now established in both generated helpers

The raw child trace—not merely the parent assertion—shows the same sequence in both representatives:

```text
pytest_ignore_collect
→ collection_path.is_dir()
→ pathlib.stat()
→ os.stat(...)
→ PermissionError: errno 1
```

The denied entry is:

```text
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/POLICY_REVIEW.md
```

The directory itself can now be listed. The failure occurs when the collector asks whether one of its entries is a directory.

The four actual outcomes reconcile as follows:

| Unchanged representative | Verified retained result |
|---|---|
| Generated-mutant helper | Import succeeds; collection exits **4** at the metadata denial. |
| Separate generated-checker helper | Import succeeds; collection exits **4** at the same metadata denial. |
| Dedicated import/collection/execution oracle | Passes; its three children exit **0**, with empty stderr. |
| D1 sanitized-environment/descriptor test | Passes; the real owner returns `ok`, and the generated module is unlinked. |

All four collected and received explicit JUnit identities. Setup and teardown passed, there were no pytest warnings, and the outer run exited 1 without a timeout. The retained helper hashes and raw child-output hashes reconcile; source bytes and modes remain exact.

**The two generated tests have not reached a successful collection under Qtc.** Their changed failure location is progress in diagnosis, not a pass. The other 95 generated cases were not run under this policy.

### Why the fix must cover the access pattern

As separate external corroboration, pytest 8.4.1’s published collector examines directory entries and calls `pytest_ignore_collect` before the session narrows collection to the explicitly requested descendant. That hook performs `Path.is_dir()`. This explains why metadata for an unselected sibling can matter. It does not authenticate the complete installed collector; the continuation requires its exact source to be inspected and hashed. [GitHub](https://raw.githubusercontent.com/pytest-dev/pytest/8.4.1/src/_pytest/main.py)

The current archive retains only **a root-entry count of ten**, not the complete names and types. Therefore, neither a complete literal permission set nor its successor-policy hash can honestly be fixed here.

## What can carry forward unchanged

**The termcap correction is supported.** The same retained runtime probe emits the 60-byte notice under Qs and has empty stderr with the selected terminal-data read. The dedicated unchanged test independently reaches successful child import, collection, and execution with empty stderr. The recorded resource is the single 308-byte `/usr/share/terminfo/64/dumb` file; no further terminal-resource search is indicated.

**The temporary-module correction is supported at its tested scope.** The unchanged D1 test creates and removes its exact permitted filename. That filename is absent from the 327 sealed endpoints and every boundary capture. No package-directory write permission was added.

**The original containment records reconcile.** Parent, fork, exec, and fork-then-exec each have the original ordered 40 controls, including actual bind/connect denials against the functioning owned peer. The scoped-signal records remain bound to Qtc’s actual hash. These are measured controls, not universal isolation claims.

These conclusions come from authenticated records and inspected helper source; I did not rerun the probes. Coordinator_RW0_TC4FD7_Receiving_Verification.json[Machine-readable reconciliation](sandbox:/mnt/data/Coordinator_RW0_TC4FD7_Receiving_Verification.json)

## Selected amendment: one frozen set of immediate-entry metadata permissions

Call the successor **QtcM**. It must preserve every Qtc byte and append only literal `file-read-metadata` rules derived from a **single bounded, one-level census** of the exact owned root.

| Permitted change | Still prohibited |
|---|---|
| Record immediate entry names and `lstat` metadata; freeze the admissible regular-file/directory set together. | Recursive discovery, file-content reads, following unclassified links, or inspecting user/repository directories. |
| Add literal metadata permissions for that finite set. | Root-subtree, wildcard, recursive metadata, or additional data/write permissions. |
| Test metadata success separately from content and deeper-path denial. | Treating directory enumeration as content authority, or accepting `ENOENT` as a denial proof. |

**This avoids permitting `POLICY_REVIEW.md` alone and waiting for another sibling to fail.** It also avoids granting all metadata recursively merely because one stat was denied.

The change explicitly exposes metadata for those immediate owned entries. It does not expose their contents. Existing evidence/denied content restrictions, source protection, network denial, scoped signaling, terminal-data access, and the two temporary-module slots remain unchanged.

The prompt reuses the preserved source-copy locations after fresh authentication, so the existing temporary-module paths need no rebinding. New helpers and evidence receive a new suffix within the already permitted subtrees. It prohibits deleting or relocating old artifacts, changing pytest arguments/configuration, filtering output, or modifying tests to bypass collection.

**The amendment is selected, not yet demonstrated sufficient.** A requirement for another access class must remain an explicit limitation—not permission to broaden the rule.

## The ledger is exactly G01 plus thirty substantive gaps

The stable 56-row ledger reconciles. Only G01–G03 changed status:

- **G02:** bounded D1 representative pass.
- **G03:** bounded dedicated-oracle pass.
- **G01:** still open at immediate-root metadata.

All **30 substantive open rows** retain their previous status. The exact 99-node list matches T’s failed JUnit identities in order, but it was not executed under Qtc. No new complete direct/FULL or substantive residual probe ran in this engagement.

T’s earlier **60/60 direct pass** and completed **9,469-pass/99-fail FULL** remain Qs-scoped history. Neither is upgraded by the new representative results. RW0_Normal_Terminal_TC4FD7_Report_From_Sealed_ZIP.md[Exact embedded report](sandbox:/mnt/data/RW0_Normal_Terminal_TC4FD7_Report_From_Sealed_ZIP.md)

## Codex handoff

| Field | Instruction |
|---|---|
| **CURRENT STATE** | Candidate remains unaccepted. Qtc has two supported representative passes and the defined metadata incompatibility. |
| **RECIPIENT** | The **same neutral independent reviewer conversation** that produced `tc-4fd7e168a0`. |
| **ATTACHMENTS** | **None required.** Exact retained paths and identities are included. |
| **AUTHORIZED EFFECTS** | The finite metadata amendment, audit-owned calibration, unchanged-candidate validation, and residual synthetic audit. |
| **EXPECTED RETURN** | One cumulative disposition, full report, closure ledgers, and reopened evidence ZIP. |
| **PROJECT SNAPSHOT** | None requested. |
| **NEXT ACTION** | Return the cumulative result here before any candidate repair or commit gate. |

Send **only this complete replacement prompt**:

:chatgpt-content-reference{index="5"}[**RW0 normal terminal closure — owned-root metadata and audit completion**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Owned_Root_Metadata_And_Audit_Completion_Prompt.txt)

It requires, in the same engagement: metadata-set freeze and recalibration, all four unchanged representatives, the exact 99-case replay, fresh complete **60-case direct** and **9,568-case selector-free FULL** gates, then residual substantive closure. No routine handoff is required between successful stages.

Substantive sections 2–3 remain byte-identical to the previous mandate. Section 4 changes only the final policy name; the new permission and execution treatment are explicit elsewhere.

```text
Prompt size:
66,323 bytes

SHA-256:
ff68a20c97957d6fe8be9baeca17cf682e318fdf462199683b62e8b779a3fa56
```

:chatgpt-content-reference{index="6"}[Handoff identity record](sandbox:/mnt/data/Coordinator_RW0_TC4FD7_Handoff_Check.json)

Keep the implementation conversation idle. No candidate edit, assertion relaxation, installation, staging, commit, publication, or deployment is authorized.

**Inspection limits:** This pass performed data-only archive verification, source reconstruction, retained-record reconciliation, and static inspection. It executed no supplied helper, candidate code, SQL, tests, policy, Git command, or host diagnostic. Historical host execution remains retained evidence, not a live observation here.

**Sources:** Coordinator_RW0_TC4FD7_Receiving_Review\.md[Receiving inspection](sandbox:/mnt/data/Coordinator_RW0_TC4FD7_Receiving_Review.md), RW0_Normal_Terminal_TC4FD7_Report_From_Sealed_ZIP.md[authenticated report](sandbox:/mnt/data/RW0_Normal_Terminal_TC4FD7_Report_From_Sealed_ZIP.md), Coordinator_RW0_TC4FD7_Receiving_Verification.json[verification record](sandbox:/mnt/data/Coordinator_RW0_TC4FD7_Receiving_Verification.json), and the separately identified pytest source.

**Confidence:** Artifact/source identity and record reconciliation **0.99**; bounded metadata-treatment direction **0.97**. Success of QtcM and complete candidate acceptance remain unestablished.
