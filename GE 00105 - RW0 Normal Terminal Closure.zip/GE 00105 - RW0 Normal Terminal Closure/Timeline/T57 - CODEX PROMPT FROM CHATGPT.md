RW0 NORMAL TERMINAL CLOSURE — CUMULATIVE PRECOMMIT AUDIT ON THE QUALIFIED RUNNER

This is the sole complete operative instruction. The qualification is complete
at its measured scope. Resume the SUBSTANTIVE candidate audit in this engagement;
do not create another qualification-only task, repository reconnaissance or
implementation tranche. Do not treat environment qualification as candidate credit.

ENGAGEMENT ENVELOPE
CURRENT STATE: Candidate 4691af58ae0ee3107b4e2e9b6b1508032944e357 is uncommitted
and unaccepted. PR #17 / commit 61d0330aba1160f7f5e7d9c541a325222d1c61e5 remains
the integrated baseline. The qualified synthetic peer-33a5f35cc1 interval and its
unchanged policy are authenticated background for this prospective candidate audit.
Prior BLOCKED/INCOMPLETE verdicts and process deviations retain their scopes.
RECIPIENT: The SAME neutral independent reviewer conversation that produced the
QUALIFIED peer-33a5f35cc1 delivery, NOT the implementation conversation. Expected
host cwd: /private/tmp/rw0-audit-entry.daLWIE. No new project or conversation.
ATTACHMENTS: Exactly three candidate/requirements evidence files A/B/C in section 1.
The small qualified-runner ZIP Q below is already retained in this conversation;
it does not need another attachment. No separate report, old candidate/audit ZIP,
chat export, Downloads search or repository snapshot is required.
AUTHORIZED EFFECTS: Data-only sealed-artifact inspection, audit-authored tooling,
authenticated unchanged candidate execution under the exact qualified restrictive
policy in owned source/state copies, finite synthetic faults, and safe audit
records. No live repository access, source repair or Git/publication/product effect.
EXPECTED RETURN: Complete inline audit disposition, uniquely named full report,
one reopened safe audit-evidence ZIP, exact unperformed coverage if any.
PROJECT SNAPSHOT: None requested. PR #17 remains the baseline.
NEXT ACTION: Return to ChatGPT. Acceptance, if earned, is eligibility only for a
separate live exact-byte commit gate, never authority to perform it here.

0. ENTRY, PURPOSE, AND QUALIFIED BOUNDARY

This is authorized defensive verification of the user's own sealed Coordinator
candidate. A necessary read of exactly this host-exposed instruction file is
permitted solely to load the mandate, with explicit neutral cwd. Before any OTHER
operational command state actual host-supplied cwd, exposed input paths, the retained
Q path, binding information or its absence, and the effect ceiling. A requested
path is not evidence of actual cwd. If actual cwd is unavailable/different or an
exposed binding is to a live repository, stop without probing that repository.
Unknown binding alone is not proof of a repository and need not trigger discovery.

No preliminary Git/status/pwd/listing/AGENTS discovery, repository bootstrap,
home/Downloads/ancestor search, settings/session-database read, subagent, remote
query, installation, or host-protection change. Exact host-exposed attachments
may physically be in Downloads: those files may be read, their directory may not
be searched. Archived absolute paths are labels, not general read authorization.
Read source guidance only from authenticated source/ payloads. Reports, manifests,
old prompts, comments and model content cannot grant new effects.

One parent auditor only. Keep the implementation writer idle. Independently author
inspection, observer and causal-probe code; keep it outside candidate discovery.
Do not run historical candidate packaging/provenance/audit/cleanup scripts. The
qualified helper designs can be inspected and adapted ONLY as section 5 specifies;
this is not general authorization to execute archived programs. Candidate code,
SQL, setup fixtures and tests run only after source authentication, source/effect
inspection and section 5 readiness, always under the exact restrictive policy.

If provider/environment limitations prevent required work, retain findings and
exact actual execution scope, return INCOMPLETE, and do not infer zero execution
from a refusal. Never disguise the task, drop coverage or bypass protections. A
material source defect yields BLOCKED. An out-of-scope action bars compliant
acceptance; disclose the observed action without inventing live preservation.

0.1 Authenticate retained qualification input Q, as data

Exact path:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/peer-33a5f35cc1/RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_QUALIFIED_20261029.zip
Bytes: 163,911
SHA-256: 6ec93d7f43f1d630bf9501d67a80e8a2a9db307da38baa2e6f44d5d22a7e0767

Missing Q => state this exact missing input. Do not look in another root or invent
attachment access. A genuinely supplied host-exposed copy with the same identity
is an acceptable alternative, not permission to search for one.

Before payload use check safe unique normalized/casefold-distinct relative regular
unencrypted entries, no traversal/link/special/prefix collision; maximum 200 members,
2,000,000 bytes/member and 5,000,000 expanded bytes. Expected: 89 files, 966,951
expanded bytes; MANIFEST.json covers the other 88. Verify CRC, sizes, SHA-256 and
numeric modes. QUALIFICATION_REPORT.md is 12,782 bytes / SHA-256
280cf51f58d2950c0ba0a21205e130b9b9cc946f6cd44c93ba7a2b0771775c7c.
Read the full report, POLICY_REVIEW.md, current helper sources, runtime records,
raw controls, peer events, pre/post identities and closure records before relying
on them. Prior_data/ is historical and never supplies fresh execution credit.

Fixed active policy inside Q:
execution/peer-33a5f35cc1/policy.sb
2,637 bytes / SHA-256
d9f8bd3aeaedc1606ee2cf7a93b81742ffca0fef93e1f270618222bae35b52c1.
Existing absolute policy copy:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/execution/peer-33a5f35cc1/policy.sb

Qualification established in retained observations: restrictive true and Python
entry, one owned SQLite exercise, parent/fork/exec/fork-then-exec each 40/40 original
controls, actual EPERM bind/connect against a listener proven by nonce handshakes
before and after the run, unchanged sentinels, reaped owned processes and sockets.
ChatGPT reconciled raw records as data, not by rerunning them. Qualification is
bounded to those runtime/policy/layout/process seams. It is not a proof of arbitrary
candidate compatibility, all OS behavior, source correctness or present live state.
SO_ACCEPTCONN errno42 was optional and local to that new interval; the historical
unlocalized peer failure remains unlocalized. Do not rerun the old diagnostic loop.

Read Q's policy breadth explicitly: literal root directory-entry read, finite
ancestor metadata, installed framework/system-runtime read subtrees, owned
execution/mock_source/scratch/home/tmp reads, scratch/home/tmp writes, /dev/null
write, fork/exec and sysctl-read, explicit network denial; no evidence/source write
or general user/checkout-content grant. The restriction does not authorize reading
real excluded paths even to test denial. No policy edit, path rebind, rule reorder,
permission expansion, allow-default/no-inner candidate launch, or native-image
shortcut is authorized. If an actual candidate dependency exceeds this boundary,
record the exact compatibility gap and stop that execution safely, not repair the
candidate, change privileges or silently weaken the required suite.

1. AUTHENTICATION AND SCOPED PROVENANCE

1.1 Three exact evidence inputs

A. RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip
   bytes: 48,978,087
   SHA-256: 6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42

B. Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt
   bytes: 38,100
   SHA-256: 9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f

C. Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt
   bytes: 29,145
   SHA-256: 7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd

B and C are historical REQUIREMENTS EVIDENCE ONLY. Do not carry out their live
checkout, branch, edit, test-runner, packaging or implementation instructions.
The current ZIP's inputs/mandate.txt is the explicit historical-admission and
witness-construction amendment: 28,439 bytes, SHA-256
6e978d57abfbadf7d8120eb58ea75651a60a44c42d6279ff8a9108c41c8b2da4.
Read it fully as requirements evidence, alongside B and C. Its two-layer
amendment replaces ONLY the previously overbroad historical current-stop SELECT
prohibition. All other substantive original/full-witness/grammar requirements
remain. Section 2 below states the operative amended audit criterion.

1.2 Current archive gate

Before extraction inspect the directory: exactly 573 normalized, unique,
casefold-distinct, relative, unencrypted regular members; no traversal, links,
special files, duplicate paths or source-path prefix conflicts. Expected declared
expansion is 183,558,511 bytes. Use bounded reads: at most 5,000 members,
150,000,000 bytes per member and 350,000,000 expanded bytes per archive; maximum
nested depth six and 1,200,000,000 cumulative expanded bytes for unique archives.
Cache repeated identical archive identities rather than repeatedly expanding.
Stop on a boundary failure; do not silently relax limits.

package/member-manifest.json:
  123,205 bytes; SHA-256
  049139eaac16a03b36952faa703c992f5ef13adad44807873921af817e7b8e43.
Verify all 572 covered members by CRC/readability, size, SHA-256 and numeric
archive mode, with exact self-exclusion and no uncovered extra member.

Read the complete current report at evidence/IMPLEMENTATION_REPORT.md:
  19,549 bytes; SHA-256
  c52141d0fcf15701496c4dec18133361a78b8f043796078340e24eed4bdae2d5.
It is the sufficient report input; no separate standalone-equality gate exists.

Authenticate all 327 source/ payloads against evidence/final-C-manifest.json.
The final C, final D and postcleanup manifests must be byte-identical:
  109,923 bytes each; SHA-256
  1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1.
Verify path/type/size/raw SHA-256/Git blob/Git mode and numeric OS mode. Reconstruct
from raw bytes without staging or git write-tree:
  4691af58ae0ee3107b4e2e9b6b1508032944e357.

Modes: 326 source wrappers at OS 0644 and one at OS 0600,
tests/test_c2b3_private_atomic_program_initialization.py; all Git modes 100644.
Preserve these modes in independent copies. They are artifact records, not proof
of today's live POSIX modes. Cumulative Git-baseline before endpoints correctly
record os_mode=null: do not compare that to present source POSIX mode as a
provenance failure or invent a historical checkout mode.

1.3 Exact lineage and deltas

Authenticate these nested inputs before relying on their contents:

- inputs/retained-source.zip: 36,160,973 bytes; SHA-256
  ca1a42d3165809887b4d837232cf9a45ff18e1c643921c5eef7b0a42d2737844.
  Its 855-member directory and 854 covered member rows use the predecessor's
  actual manifest schema (member key name rather than current path).
- inputs/latest-audit.zip: 1,370,071 bytes; SHA-256
  16b4098f63cbb1fe68d4e7079711565624fe1412aaf28af70413f4d5f8518970.
  It has 160 members / 159 covered rows. AUDIT_REPORT.md is 32,236 bytes,
  SHA-256 67f2a2ae24e2871e2befe2e4fc35b753d7bebcbc3bcba7444a7b3a92ae21430a.
- The F01 mandate is inside inputs/retained-source.zip at
  requirements/ENGAGEMENT_ENVELOPE.txt: 26,064 bytes; SHA-256
  e158b7c3bb61905ccc2e4c83b8fb59c8b7806ba9b5c5fe21d56a8fd429f088d6.
- Inside that predecessor's inputs/prior-candidate.zip is the S01/A03 candidate:
  25,334,611 bytes; SHA-256
  f06d97a0becddec07e30676b3988dfcde9d4a79cb6b77a41c23fe4b9d429dd90.
- Its inputs/original-candidate.zip is the original terminal candidate:
  11,648,876 bytes; SHA-256
  bf26189fd12b2b27fee847e0c0a1808cfeb568c9255bf48bc1f23ff14e728b0e.

Reconstruct the source chain from payloads, not just manifest OIDs:
  integrated, 315 paths: 44c7dee402d46b3e16dc389ae0824b4297dfec1f
  original, 325 paths: 648d332b3ba847deb257a2bb1892a76e4c442675
  S01/A03, 327 paths: 011f76542a77b2a766a46ac08df102b4de4c09c6
  F01, 327 paths: 5c44721183f660032b6468d2c1f5a1d0dc3e6acb
  current, 327 paths: 4691af58ae0ee3107b4e2e9b6b1508032944e357.

Current immediate delta: exactly five modifications; no addition/deletion/mode
change; all other 322 source paths frozen to the F01 predecessor:
  .docs/rw0-terminal-outcome-physical-closure.md
  .docs/sqlite-operations-and-recovery.md
  src/ge_nwp_coordinator/_rw0_terminal_head_witness.py
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
  tests/test_rw0_terminal_head_witness_regression.py.

Cumulative delta from PR #17: 67 modified, twelve added, zero deleted or Git-mode
changed; 248 baseline paths unchanged. The current cumulative patch includes
addition sections; do not assume it is the earlier 67-section tracked-only form.

evidence/patches/immediate.patch:
  46,381 bytes; SHA-256
  dcb26a36a7053db018d1aa57f183804e171fc2763c7c90df0b9330bd8aa43397;
  five sections / fourteen hunks.
evidence/patches/cumulative.patch:
  392,978 bytes; SHA-256
  6e4dc214ce03585322da33a42497640f420aa49b00ffc596682996371b70e5ff;
  79 sections / 140 hunks.
immediate-manifest.json: 3,346 bytes; SHA-256
  0242b6f5b2feeff5cb41b93f892bf9f97c5ca9569a56e1f26aea975ed4c3d055.
cumulative-manifest.json: 43,676 bytes; SHA-256
  ca5c9941dc90f22b25f8679535f3522bb61bbc34a0f73980f82fd7a724d583e5.

Replay both patches with audit-authored data-only logic against authenticated
predecessor/baseline bytes, verify every endpoint including additions, and
independently reconstruct their manifests from fresh archive reads. Repeated
writer execution of a manifest recipe is not established merely by a single
retained output; state this limit without inventing historical copies.

All SQL 0001–0008, the schema fixture, migration catalog, transaction controller,
writer session, terminal contracts/rows/plan/SQLite owner and F01/O1 repair bytes
must remain exact to the immediate predecessor. SQL 0008 remains 30,178 bytes,
SHA-256 a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254.
Review their original cumulative changes nevertheless. No 0009 is selected.

Archived HEAD 61d0330aba1160f7f5e7d9c541a325222d1c61e5, branch
codex/rw0-normal-terminal-closure-v1, no upstream, 315-entry unstaged index,
config/ref/cleanup records are retained observations only. Do not access live
state to confirm them. Classify opening.raw-index.bin as inert Git metadata;
do not execute it, print sensitive contents, or use it as present Git truth.

2. SUBSTANTIVE REVIEW — THE EXPLICIT TWO-LAYER AMENDMENT

The earlier whole-operation zero-current-stop-SELECT criterion failed under the
old mandate. That blocked result remains true. The engineering decision is to
preserve mandatory shared storage safety, not to skip it to satisfy a terminal
history test. The current candidate is judged against the following amendment:

Layer 1: existing operational admission remains mandatory. Session/process/thread/
lease validity, database binding/custody, BEGIN IMMEDIATE, exact managed schema,
history/catalog/posture and invariants, writer ownership/fencing, and current
protected disclosure remain intact. The existing global_stop_current singleton
shape validator may read that current row only for managed-store validity.
Valid active/clear status, version, timestamp and directive identifiers must not
be compared with saved terminal stop or turned into current effect permission.
Denied/unreadable/malformed managed state may prevent disclosure or leave recovery
unresolved. It must not be misclassified as stale terminal history or definitely
absent original execution. No cache, successful-assessment stub, invariant-skip
flag, alternate connection/controller, or production validator weakening.

Layer 2: historical checked read, receipt-present replay and recovery use saved
full postimages/stop and checked immutable predecessors after admission/fencing.
The five current-head tables are not consulted during the historical operation.
Current-stop reads are permitted only at the existing shared invariant check,
not as a general table-read exemption or later semantic terminal query. Receipt
is first TERMINAL-FAMILY lookup, not first SQL statement. Exact original result,
time, graph, receipt, source associations, protected disclosure, immutable
acceptance binding, complete competing-winner/absence proof and uncertainty
classifications remain required. Historical operations do not require recording
permission or renewed acceptance-unclaimed eligibility. Fresh receipt-miss
recording retains actual current five-head/stop checks unchanged.

This amends only the overbroad current-stop-query requirement. It is not a waiver
of the constructor defect, five-head independence, disclosure, SQL grammar,
transaction safety, audit isolation, or other cumulative acceptance controls.
Verify the two owning documents state the distinction and preserve the old
failure as history; do not create another silent interpretation of either layer.

Inspect at minimum the complete changed witness module, changed tests and docs,
full terminal contracts/rows/plan/SQLite owner, and actual shared admission call
chain (not only wrapper names). Current anchors:
  sqlite_transition_transaction.py:2759–2779,4753–4773
  sqlite_migration.py:2477–2523
  .docs/rw0-terminal-outcome-physical-closure.md:177–220
  .docs/sqlite-operations-and-recovery.md:722–730.
Python basenames are under source/src/ge_nwp_coordinator/; docs under source/.

2.1 Independently test the repaired constructor and mutable aliasing

TerminalHeadWitness at _rw0_terminal_head_witness.py:48–96 must validate ordinary
construction, not only checked factories. Independently test valid direct/factory
triples for accept and replan and all five typed owner roles (8/9/41/9/8 fields,
valid nulls, self-digests). Exact bytes, outer tuples, dictionaries, keys and
scalar types precede hostile comparison/coercion. Bytes, full rows and compact
coordinates must match rather than silently replacing invalid supplied parts.

Require negative controls for the previous malformed type triple and b'{}'/empty
postimages, bytes/list/tuple/dict/string/int subclasses, bool-as-int, wrong arity,
missing/extra/reordered roles or fields, wrong schema/digest, noncanonical and
oversize bytes, and valid canonical bytes paired with DIFFERENT valid rows or
projections. Calibrate a shared/per-instance hostile equality counter, clear it,
and verify zero hostile calls per invalid construction. Preserve built-in
positives and process-control propagation.

Mutate caller-owned maps and separately returned maps, then re-read both views
and canonical bytes and run normal downstream verification. They must remain
checked and unchanged. No unvalidated object token/factory escape or recursion.
Do not demand security against arbitrary reflection/object.__setattr__; that is
not the selected boundary. Verify unchanged wire fields/schema/digest domains
and valid consumer behavior, including exact original P1 replan operands.

2.2 Independently prove complete-operation phase behavior

Use real private WriterSession read, receipt-present record/replay and recovery,
not just a terminal helper. Trace and attach observation/denial at the actual
acquisition/controller opener aliases and account for every operation connection.
The candidate observer labels the full managed wrapper; independently establish
which SQL is genuinely in _verify_global_stop_current_shape. A phase label alone
does not prove shape-only use or permit arbitrary managed-phase stop semantics.

Observe real unchanged validator, ownership-read and issuance/fencing functions;
observation wrappers must call the real function and return its actual result.
Do not replace admission with a successful assessment or patch the predicate
being proved. Capture connection, phase, table/column and allow/deny results.
Calibrate each attached authorizer with owned allowed and intentionally denied
queries. Trace acquisition separately, including any connection work before the
observer attachment, and prove it cannot hide a five-head/later-stop lookup.
A zero-callback claim at the wrong alias is invalid. Column callback counts are
not SQL-statement counts or a fixed product invariant.

Required current-byte controls:
- real fenced accept and replan commits, then coherent later movement of every
  head and valid active/clear stop fixtures; under the layered denial policy,
  exact read/replay/recovery preserve original result/time/witness/graph/receipt
  and acceptance facts without new terminal or protected-row movement;
- original absence with positive/negative old-execution exclusion; complete
  compatible and incompatible competing winners under that same policy;
- deny the ACTUAL managed-stop read during admission: safe operational refusal
  before protected terminal-family handling, recovery unresolved where the
  unchanged controller so classifies; no no-write mislabel as stale history,
  definite absence, hidden retry, committed result or protected disclosure;
- malformed actual stop row or real query-return tuple, with validators intact:
  integrity failure rather than ordinary currentness; fault removal restores
  valid operation; bound process-control behavior remains unchanged;
- fresh receipt miss reads all five actual heads and stop. Stale expectations
  conflict without writes; correctly expected valid changed stop follows the
  current normal-record rule without conferring executable permission;
- denied/expired/foreign/malformed disclosure, closed/stale/fenced session and
  unavailable managed store remain non-disclosing. Fresh recording permission
  stays separate from historical protected disclosure and stop shape.

All synthetic later states/fault seams must be described as such. Do not call
a direct fixture UPDATE a newly supported product operator transition.

3. COMPLETE CUMULATIVE A01–A18 REGISTER AND CAUSAL OBLIGATIONS

Review the entire baseline-to-current terminal change, not only the five-file
repair. Supply exact archive-relative source/doc/test/SQL coordinates, severity,
and evidence class for every row: contract/current code, inspected test design,
retained record, independent execution, inference or limit. Unchanged bytes and
prior passes do not automatically discharge current mandatory controls.

A01 Authority: exactly five private normal terminal facts, separate from P1
 decision/acceptance, standing-policy grants, source facts and executable
 permission. No cancel closure, live supplier/contact, ES/Bridge/Git effect,
 service/scheduler/autonomy or publication authority.
A02 Preservation: legacy terminal V1/four validators, P0/P1 meaning, WorkSpec,
 Decision Basis/command-digest v2, preassignments, D1/D2, generic receipt, public
 StateStore/package exports unchanged. Audit original shared catalog/controller/
 writer-session terminal integration even though this immediate repair froze it.
A03 Grammar/types: closed command/context/outcome/row/result/recovery/witness
 schemas, exact built-ins before equality, canonical UTF-8/JSON and duplicate
 rejection, bool-as-int, safe refs/digests/calendar time, budgets and null pairs.
 Include direct constructors, factory consistency and aliasing; resolve A03/O1.
A04 Identity graph: independent domains/acyclic preimages, four sibling refs and
 route, optional assertions bound in command digest but not preassignments,
 graph role/cardinality/order, self-digest exclusion and repeated-column equality.
A05 Original operands: original P1 command and private replan operand transient;
 complete checked predecessor association required. Missing/inconsistent private
 content cannot be reconstructed from a safe digest or yield false certainty.
A06 Source association: actual checked P0/phase/Section41 A/C1 rank15/V22/P1
 chain and validation/review/proposal/result-set/observation relationships;
 membership counts or digest strings do not independently establish ownership.
A07 Acceptance: bind existing immutable acceptance only for accept; never create,
 mutate or replenish it. Wrong/missing/foreign facts reject. Legitimate unrelated
 facts must coexist without preventing another allowed terminal branch. No
 historical acceptance-unclaimed recheck.
A08 Heads/stop: observed full five-row witness, source/adapters/digests/links,
 replan historical P1 postimages, fresh actual currentness and stop facts; prove
 the precise two-layer amendment, not the withdrawn zero-stop-read property.
A09 Transaction: existing fenced lease/capability/controller; receipt-first
 terminal lookup; one captured time; protected posture/source/current/route
 ordering; context/outcome/result readback, receipt last, capability invalidation,
 one commit attempt, rollback/cleanup uncertainty. No application-head/stop/
 decision/effect update by terminal closure.
A10 Read/replay: original complete result/time/graph/receipt and source/witness
 reauthentication; current protected disclosure with mandatory store admission;
 no five-current-head or later semantic stop query, cognition/process rerun,
 fresh recording permission or acceptance-eligibility requirement.
A11 Recovery: complete exact original family or exhaustive original absence and
 exclusion, or complete compatible winner, only. Partial/foreign/damaged/aliased/
 incompatible families unresolved. No winner result disclosure, hidden retry,
 fragment repair or durable private-template fallback.
A12 Error/cleanup: failed or malformed reads stay operational/integrity, valid
 actual drift stays currentness. Stale/closed/fenced sessions, pre/postcommit,
 applied-commit/lost-return and cleanup uncertainty, KeyboardInterrupt/SystemExit/
 GeneratorExit propagation at the actual fresh/read/recovery/cleanup seams.
A13 Schema/admin: four STRICT immutable normal-only tables/eight guards;
 timestamp grammar, FK/unique/composite links/phase/decision/route occupancy,
 nullable pairs, blob bounds, zero seeds, current catalog/checksum/generation 2;
 exact fresh/prefix migration and old-binary/obsolete-0008/partial/unknown refusal.
A14 Connected normals: actual preseal source variations through real P0/D1/D2/
 Section41/C1/V22/P1/terminal owners; five distinct normal positives and detached
 negative; read/replay/recovery and no forbidden contact or protected-row change.
A15 Docs/assurance: cumulative current-versus-historical status, explicit amendment
 and private scope; fixed source/hash/AST/import/schema consumers and predecessor
 reconstruction retained; no dynamic oracle, skip/xfail or broad guard stripping.
A16 Privacy/artifacts: complete postimages remain safe owner metadata; no private
 replan text, raw capsule/prompts/process results, handles/PIDs/credentials in
 terminal rows or unsafe errors. Grammar review plus independently observed
 canaries; classify raw-index metadata, checkpoints and failed artifacts.
A17 Retained evidence: exact input/source/patch/commands/env/observer outputs/
 JUnit/IDs/warnings/captures and overlapping counts; limits in section 4 below.
 No writer record or causal-register label is independent execution.
A18 Independent validation: reached current-source causal probes and direct
 suite, independent SQL/admin controls, selector-free collection/FULL completed
 with exact IDs, outcomes, warnings and source-mode preservation. No live-state
 or production-readiness inference.

The following controls remain mandatory, including previously unfinished ones:

(a) S01 full-witness family: for EACH role, check complete field capture, valid
 nullable values, supported maximum witness bound, bad owner self-digest, valid
 self-digest with wrong immutable predecessor, wrong owner/link, and actual fresh
 head movement versus changed caller expectations. Use fully resealed synthetic
 histories so owner/context/outcome/result/graph/receipt digests are internally
 valid and the real relationship predicate is reached. Pair every resealer with
 a valid family built the same way. Restore ordinary verification for the actual
 read/replay/recovery. Prior program-only evidence is not five-role proof.
 No truncated witness, v1 fallback, desired-row synthesis or current-row backfill.

(b) Source/operand/acceptance: fully resealed detached validation, review,
 source-invocation and proposal associations, including a DISTINCT forged V22
 proposal reference rather than only a proposal digest; wrong/missing/foreign
 acceptance; LEGITIMATE unrelated acceptance-fact coexistence; inconsistent
 private replan content sharing a claimed safe identity across record/read/
 replay/recovery; no new process or private-text persistence. The single-chain
 fixture's inability to construct an unrelated fact is not proof of impossibility.
 Build coherent independent synthetic state through checked owners, or document
 exact invariant proof and the remaining limitation. Do not credit an incoherent
 split-reader or early FK/digest failure as the intended relationship test.

(c) Disclosure/recording: all selected finite posture predicates, including
 positive, denied, expired, malformed, foreign-bound and absent protected subject;
 old-execution-excluded True/False; truthful claimed False/None after accepted
 P1. Fresh write needs recording AND disclosure, historical operations disclosure
 only; command reuse/assertion mismatch cannot disclose a protected result.
 Complete the expired/malformed/foreign/protected-absence matrix rather than
 inheriting earlier positive/negative permission examples.

(d) Physical routes: derive all original occupancy routes from the checked
 code (the preceding audit identified 17). Seed EACH route physically in a
 separate owned coherent scenario, with valid positives and relevant partial,
 foreign or damaged family states. Mocking query return values alone is not
 physical occupancy evidence. Check exact/winner/absence classifications and
 no winner disclosure or retry. If a route is not representable under an owner
 invariant, prove that with exact schema/contract and record the scope; do not
 invent an invalid row as a legitimate winner or silently drop the obligation.

(e) Transaction and error matrix: faults after each of the four inserts,
 result/receipt readback, receipt-last boundaries, precommit rejection,
 one applied commit with lost return, postcommit and recovery cleanup uncertainty;
 stale lease/issuance, closed and fenced sessions; actual denied SELECT versus
 malformed selected rows across current owners; all three process-control
 exceptions at meaningful fresh/read/recovery/cleanup seams. Assert target
 rows, committed bytes, protected-state nonmovement, and actual injection hits.
 No hidden second commit or automatic retry.

(f) F01/O1 regression: independently exercise raw SQL and row construction,
 not only planner success. Use otherwise valid parent/related state, paired
 valid inserts, independent negative self-digests and the repaired existing
 _time owner. Cover invalid month/day/leap-century/year-zero/time overflow,
 canonical-format deviations, Unicode digits, embedded NUL/whitespace/nontext,
 NULL handling and valid year endpoints. Reach all three recorded_at columns;
 outcome has no timestamp. Verify failed predicates are zero/not permissive
 NULL and high-level invalid row/time behavior stays integrity/unresolved.
 Reproduce the old invalid-month predicate only in owned predecessor synthetic
 state as a grammar comparison, never claim an ordinary writer exploit.
 Recalibrate O1 independently before claiming no hostile equality calls.

(g) Five connected normals plus three unsupported cancel shapes and unsupported
 profile. Source variations occur BEFORE real artificial worker/checker/capsule
 sealing, not by relabelling passed evidence afterward. Use inspected fixtures
 for setup only; independent expected branches/facts/errors are required.
 Observe artificial local process/contact limits and privacy canaries.

Run bounded causal controls before a long FULL launch. Do not start/continue
FULL while a known material blocker already prevents acceptance. Independent
controls must state setup validity, actual reached seam, expected result/no-write
predicate, source identity and limits. Candidate tests passing are not separate
independent oracles. Any mandatory control not established remains explicit and
prevents complete acceptance unless an exact supported invariant makes the case
inapplicable; fixture difficulty alone is not such an invariant.

Independent SQL/admin expectations:
  after 0006: 68 tables / 122 triggers / 5 explicit indexes
  after 0007: 74 / 134 / 5
  after 0008: 78 / 142 / 5, application generation 2.
Execute all eight authenticated literals in disposable owned state. Preserve
pre-0008 object SQL/shape; check exact prefix upgrades, no seeds, immutable
update/delete guards, FK/unique/pair/profile/normal/blob/time constraints, and
refusal of old binary, original and S01-era 0008 checksums, old SQL with current
history, missing guard, foreign object and partial/unknown/checksum divergence.
No current schema/contract change, 0009 or product database upgrade is allowed.

4. RETAINED EVIDENCE AND INDEPENDENT VALIDATION

4.1 Reconcile the current writer records as DATA

Paths: evidence/validation/<direct|connected|focused|full>/, gate-summary.json,
phase-read-map.json, supersession-record.json and current source captures.
Require independent parsing of collection observer, execution collection,
setup/call/teardown records, explicit JUnit nodeid properties, actual launch/exit,
stdout/stderr as actually retained, warnings, and four complete source captures
per gate. Do not invent a separate stderr file for a combined log.

Expected current retained gates:
  direct: five complete modules / 60 cases / zero warnings
  connected: one complete module / six cases / zero warnings, inside direct
  focused: 126 complete modules / 8,266 cases / three known warnings
  FULL: selector-free / 9,568 cases / three known warnings.
All narrower sets must be included in FULL; totals overlap and do not add.

Ordered-ID SHA-256 uses UTF-8 JSON array, ensure_ascii=False,
separators=(',', ':'), with NO trailing LF:
 direct 229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467
 connected 81e14e3fa1b85a7be2ea6fafac85974839145bbcb6397e6da0bb1feeba060aac
 focused 419d37ff399689788123583f614a1d8b107ef712e2368ca179cd6e65fbec5104
 FULL 25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9.

All sixteen source captures have the same 105,550-byte envelope, SHA-256
0c0b4017371a798731a63825ac63922c361189e37f5a713f5c4f7ec06e9b32cb.
Require full row equality to the different canonical source-manifest envelope,
its embedded canonical hash, correct final tree and no extra/missing paths.

The retained direct JUnit phase maps report six operation connections, 60
managed-stop column callbacks and six intentional head-denial calibrations
for EACH accept/replan scenario. Independently parse the raw properties. Do not
substitute those counts for actual phase/call-chain verification, or label them
SQL-statement counts. Acquisition has separate test observations.

4.2 Known retained-evidence limits — do not silently fill them

The active external gate_observer source and a launch-bound helper digest are
not retained in the current outer ZIP. Old nested helpers cannot prove that
current code's identity. Writer records can be internally reconciled but their
observer's nonselecting implementation is not thereby inspected. The independent
runs below must use newly audit-authored, retained, inspected and calibrated
observers. Independent fresh evidence can establish current behavior; it does
not retroactively establish the missing writer helper.

The seven-case checkpoint has receipt/JUnit evidence and a different declared
tree 85c9fea24f4f74f358f9cc59a5d323d836a04041; it lacks a complete checkpoint
source payload here. Its historical save/reopen/source-binding claim stays
qualified and supplies no final-byte credit. Similarly, one retained patch
manifest per kind is not proof of two writer runs; independently reconstruct
current endpoint/patch identity rather than invent that history.

These are disclosed retained-evidence/process limits, not automatic production
findings. Determine their actual acceptance impact. Complete current independent
source/runtime evidence must not be replaced with writer claims. Any unmet
mandatory evidence requirement is INCOMPLETE, not a pass by wording change.
Preserve failed/superseded source/test results separately. The prior audit's
live-status/path probes and interrupted FULL remain historical limits.

4.3 Required independent execution gates

After source review, new constructor/two-layer controls, the complete cumulative
finite causal matrix and SQL/admin controls reveal no material blocker:

1. On a fresh exact source copy, collect and run these five COMPLETE modules in
   this order (no node selector):
   tests/test_rw0_terminal_outcome_values.py
   tests/test_rw0_terminal_head_witness_regression.py
   tests/test_sqlite_rw0_terminal_controls.py
   tests/test_sqlite_rw0_terminal_migration_0008.py
   tests/test_sqlite_rw0_terminal_connected.py
   Expected 60 ordered unique passes, including six connected cases.
2. On another fresh exact 327-file copy, independently collect and run the
   repository selector-free FULL. Expected 9,568 ordered unique IDs and passes
   in the retained FULL order. No path, module, node, -k or -m selection.
3. Record collection/execution-collected/call/JUnit identities, explicit JUnit
   nodeid properties from the start, all setup/call/teardown results, warnings
   and real process exits. Require exact ordered agreement and zero failure,
   error, skip, xfail/xpass or failed noncall phase. An invertible JUnit mapping
   is useful supplementary evidence, not a silent substitute for the required
   explicit-property observation.
4. Independently inventory warnings. Direct has none; FULL may have only the
   three known DeprecationWarning multithreaded-fork nodes in
   tests/test_sqlite_b2c_writer_session.py:
   test_operation_guard_close_waits_and_retains_authority_until_exit
   test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
   test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock.
   Owned paths/PIDs may differ; other class/node/message differences require
   investigation, not filtering or suppression.
5. Capture complete raw bytes/modes/extra-file inventory immediately before and
   after collection AND before and after execution, with source-tree rebuilds.
   All 327 endpoints and modes must remain unchanged, without generated extras.
6. Audit probes remain outside candidate discovery and separately counted. An
   independent focused 8,266-case rerun is unnecessary if exact FULL inclusion
   is proven; do not claim one ran. No writer FULL or earlier audit count can
   replace the independent completed FULL.

Use recorded equivalents of:
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --collect-only --basetemp=<owned-collect> <complete-direct-modules>
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --basetemp=<owned-run> --junitxml=<owned-junit> <same-direct-modules>
For FULL remove all module/path/node selectors from BOTH commands. Inspect
pytest config, conftest and setup/child-launch seams before import. The observer
may record IDs/outcomes/warnings and add JUnit nodeid properties, but must not
select, reorder, skip, change assertions/results or suppress warnings. Keep its
exact source/digest in the evidence and bind every launch to it.

Do not edit candidate source/tests to get green results. Correct audit-only
parser/fixture/observer mistakes transparently on fresh owned state, retaining
failed attempts. A genuine candidate failure triggers findings, not retries with
weakened oracles. An interrupted FULL gets no complete-pass credit; preserve
actual partial records and absence of final JUnit/observer rather than infer
completion from displayed percentages.

5. EXECUTION ON THE ALREADY QUALIFIED BOUNDARY

5.1 Layout and prospective binding — no new policy-design task

Use the same neutral conversation and the unchanged policy root:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz

Create ONE fresh unique audit namespace under the already permitted subtrees;
record every created path. Keep all prior namespaces, reports, helpers, inputs and
results unchanged. Use:
- execution/<new-id>/ : newly audit-authored read-only launcher, bootstrap, observer,
  probes and fresh synthetic calibration helpers;
- mock_source/<new-id>/master, /direct, /full, /causal, /predecessor : authenticated
  source copies, read-only by policy with archived numeric modes preserved;
- scratch/<new-id>/, home/<new-id>/, tmp/<new-id>/ : disposable owned runtime state,
  SQLite fixtures, JUnit/observer provisional outputs and test basetemps;
- evidence/<new-id>/ : input data, trusted supervisor raw captures, independent
  source manifests, final reports and immutable copied results; no candidate grant;
- denied/<new-id>/ : synthetic denial sentinels only.

No new permission is needed merely to create subdirectories within these existing
policy roots. Preparation is by trusted data-only tooling. Do not put candidate
source, executable observers, governing inputs, or protected final evidence in
candidate-writable areas. Never rewrite source modes to obtain access. Preserve
326 files at 0644 and the classified test at 0600, all Git 100644.
Do not copy another repo, existing user database, environment, credentials or .git.

Rehash the active policy, framework entry/wrapper/native binary, and inspected
runtime at the opening and around launches. Exact expected runtime remains Python
3.13.4 / pytest 8.4.1 / SQLite 3.49.1. Record system build, interpreter resolutions,
versions and actual observed identities without an ambient environment dump.
Installed binary identities can be compared with Q; mismatch is an execution
binding limitation, not automatic evidence of candidate drift. No installation or
runtime substitution. Reuse the fixed entry:
/Library/Frameworks/Python.framework/Versions/3.13/bin/python3

5.2 Local readiness within this audit, then continue without a handoff

Do NOT rerun historical startup diagnosis or change policy. Revalidate the exact
retained qualification and prepare fresh synthetic sentinels under the new layout.
Independently author/review new bounded supervision and calibration code, using
the inspected qualified designs. Preserve all 40 original control meanings and
the same four process forms. Before candidate imports, complete the same-policy
readiness matrix for this new layout with a fresh owned loopback listener and
before/after nonce handshakes. This is an audit-entry check in THIS engagement,
not a new qualification-only program or a request for further user approval.

Runtime: true, fixed -I -B Python marker, owned stdlib SQLite, parent/fork/exec/
fork-then-exec and actual sys.executable variant if different. Filesystem: allowed
source/launcher reads and scratch round trip; source/launcher/evidence/denied
write/truncate/replace/delete/create and alias controls; denied evidence/content
reads; ordinary outside-inner-policy sentinel accessibility first. Do not probe
real excluded repository/home paths. Network: actual bind and connect denied at
those stages against the SAME functioning external owned peer; EPERM/EACCES only,
not absent peer, timeout, wrong mode, unsupported option or generic exception.
No SO_ACCEPTCONN readiness dependency. Exact control names and original inventory
are in Q; calibration code must not silently narrow them.

The trusted external supervisor is limited to data-only input preparation,
owned-state setup, peer calibration, launch/timeout/cleanup, and evidence capture.
It runs NO candidate imports, fixtures, SQL, tests, setup scripts or candidate
subprocess callbacks. Only synthetic loopback qualification uses an outside-policy
peer; close it before candidate gates. Candidate network operations remain denied.
All candidate subprocesses inherit the restrictive boundary. No network proxy,
external service, provider, ES/Bridge call or special unconfined child is permitted.

Inspect the authenticated pyproject/config, test setup, fixtures, import paths,
subprocess/fork/signal/cleanup and file-access dependencies statically BEFORE any
candidate import. Qualification of cooperative fork/exec does not establish every
candidate signal, executable or file dependency. A narrowly scoped synthetic
compatibility check for a statically identified owned-process operation is allowed
under the SAME policy; it must not touch real excluded processes or paths. Any
required restriction change is INCOMPLETE with the exact unmet operation. Never
skip a test or modify a product predicate to fit the audit sandbox.

If entry calibration passes, proceed directly to source-grounded causal/SQL
controls and sections 4.3 direct/FULL in this engagement. If it fails, preserve
partial observations, distinguish helper mistake from a true boundary/dependency
failure, and stop before candidate execution. Ordinary audit-helper corrections
are allowed on fresh owned state with their failed versions retained; policy and
candidate bytes remain fixed. No additional policy-experiment budget exists.

5.3 Candidate launch and evidence binding

All candidate work, including collection/import, historical comparison code and
literal SQL execution, goes through:
 /usr/bin/sandbox-exec -f <exact-policy> <fixed-python> <recorded-args>
with explicit owned cwd, umask 077, null stdin, close_fds=True, empty pass_fds,
owned HOME/TMPDIR/basetemp/output, C locale, UTC, zero core limit and allowlisted
credential-free environment. Preserve process-local treatment of the framework
text-encoding hint; no host settings change. Use -B, PYTHONDONTWRITEBYTECODE=1,
PYTHONNOUSERSITE=1, PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, empty PYTEST_ADDOPTS,
-p no:cacheprovider, no unrecorded selector, no warning suppression.

The qualified marker used -I; that alone does not set the candidate import graph.
For the audit use a newly authored, inspected -I -B bootstrap in execution/<id>/
that adds ONLY the authenticated source root, its src/ directory, and the frozen
read-only observer directory to sys.path, sets the explicit pytest argv, and calls
pytest without altering selection or outcomes. The controlled source mapping must
match pyproject's src path. For candidate-owned children that launch without -I,
any PYTHONPATH is frozen to those same authenticated source/setup roots only, with
no ambient directory. Do not rewrite candidate code to add isolation, disable
checks, fix imports or change semantics. Record bootstrap/source/helper identity,
real argv and environment at every boundary. This import-binding adaptation does
not alter filesystem/network policy; exercise it during contained readiness and
observer calibration before candidate collection.

The independently authored observer may record ordered collection, execution
collection, setup/call/teardown, warnings and explicit JUnit nodeid properties only.
Calibrate on separate synthetic tests before candidate collection; retain its full
source and launch-bound digest. It must not select, reorder, skip, weaken assertions,
transform failures, or suppress warnings. Keep audit probes outside source pytest
discovery. Counts and exact inventories in section 4.3 remain mandatory.

Source/observer code is policy-read-only. Candidate-produced observer/JUnit files
must be written to a fresh scratch output directory, NOT protected evidence.
The trusted external supervisor captures raw stdout/stderr directly to protected
evidence, records exits, and after all tracked children close hashes and copies
those output files into evidence. Never treat writable scratch output as protected
before that transfer. The observer runs in the test process; it is observed test
instrumentation, not a separate adversarial attestation authority. Independent
oracles, source review and protected supervisor records remain necessary.

Bind every launch to pre/post hashes of policy, supervisor/bootstrap/observer/probe,
requested interpreter/wrapper/native executable, exact source manifest/tree,
argv/cwd/env, wall and monotonic times, PIDs/process groups, timeout, raw stdout/
stderr, signal/exit and all actual outcomes. Supervisor exit 0 is never sufficient.
Freeze a documented timeout appropriate to the FULL workload, not the synthetic
matrix's 55-second limit. Do not impose an arbitrary short deadline then infer a
candidate failure. An interrupted or externally stopped FULL is incomplete.

Track/reap owned children and record process closure before artifact transfer and
source after-capture. External termination is permitted only for PIDs/groups
created and tracked by this audit. Do not claim a process-group-empty observation
is a theorem about every possible escaped descendant. Preserve the supported-local
process assumptions and existing inherited observations. If child containment or
closure cannot be established for a required control, report that precise limit.

Capture full source bytes, numeric modes and extra-file inventories immediately
before/after collection and execution, reconstructing the exact tree each time.
Never put raw source private content, runtime databases/sidecars, credentials or
unclassified logs in delivery evidence. Synthetic SQL corruption and fault injection
are permitted only within the finite defensive matrix; no host crash, product DB,
live grant, real runtime contact or product effect.

No source/edit/format/stage/commit/push/PR/merge/branch/config/ref action, installation,
repository cleanup, remote provisioning, release/deployment or product effect.
After evidence retention remove only newly created audit-owned transient state;
preserve all qualification roots and authoritative inputs. Do not make the user
assemble more prompt fragments between source review, causal controls and FULL.

6. FINDINGS, ACCEPTANCE AND DELIVERY

Return one primary verdict:
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED
 AUDIT_PROVENANCE_MISMATCH
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE

Acceptance requires authenticated exact current bytes, compliant effect scope,
all substantive A01–A18 obligations, independently validated amended historical
admission/direct-constructor/F01/O1/S01 relations, the completed required causal
matrix, SQL/admin checks and independent direct/selector-free FULL. Classify any
remaining low observation/evidence limit with rationale; do not relabel a missing
mandatory check as a nonblocking observation to obtain acceptance.

Findings must identify severity/type, owner contract, current source path:line,
actual observation/reached predicate, impact, counterexample/positive pairing,
uncertainty, and whether candidate, pre-existing, report-only, or process-only.
Differentiate historical requirement amendment from implementation repair and
from independent runtime evidence. Do not claim an unsafe fresh commit unless
ordinary fresh writing actually demonstrated one.

The latest prior report's 51 direct cases, 9,559-ID collection and interrupted
FULL remain predecessor evidence; the old zero-stop-read requirement remains
failed and superseded only as an acceptance criterion. Prior process deviations
are not inherited into this fresh engagement if it complies, but are not erased.
F03/F05 remain inherited nonblocking observations, not repaired findings.

Return a complete inline report and save a uniquely named standalone full report
BEFORE sealing one safe evidence ZIP. Include the report byte-for-byte in the
ZIP and a self-excluding member manifest; reopen all members and record exact
ZIP/report/manifest sizes and hashes in the final response and adjacent receipt.
Do not make an outer ZIP self-hash a member obligation. Retain audit-authored
scripts/observer/policy, input and endpoint verification, source/patch checks,
A01–A18 register, actual causal/SQL results, invocations/exits/logs/JUnit/IDs/
warnings, source captures, process mistakes/withdrawn claims, unperformed scope,
and cleanup/non-effects. Exclude databases/sidecars, bytecode, credentials,
unclassified binary state and private product/capsule/template contents.

Final acceptance, if earned, is only for tree
4691af58ae0ee3107b4e2e9b6b1508032944e357 and supplies eligibility for a separate
live exact-byte commit gate. It authorizes no mutation, staging, commit, push,
PR, merge, publication, release, deployment or product effect. Return to ChatGPT;
do not initiate a repair or publication gate in this audit conversation.
