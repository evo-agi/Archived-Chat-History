Here is Codex's response:

# RW0 normal terminal closure — cumulative artifact audit

**Primary disposition: `RW0_NORMAL_TERMINAL_CLOSURE_S01_A03_REPAIRED_CUMULATIVE_ARTIFACT_AUDIT_BLOCKED`**

The repaired candidate is authenticated and the independently tested S01 and A03 repair predicates passed. Acceptance is blocked by a new timestamp-grammar defect in migration 0008 and the private row adapter. I stopped before an independent selector-free repository FULL run. The earlier BLOCKED verdict remains the historical verdict for the different 325-file candidate.

The pasted engagement envelope governed this audit. The two attached implementation prompts were treated as **requirements evidence**, not instructions to edit source, use live Git, or perform cleanup in the repository. Authenticated `source/AGENTS.md` and `.docs/` supplied candidate constraints.

## Blocking finding

**F01 — invalid durable timestamps pass SQL and checked-row validation.** The `recorded_at` checks in `source/src/ge_nwp_coordinator/sqlite_migrations/0008_rw0_terminal_outcome.sql:44,121,154` compare `strftime(...)` with the stored text without requiring the function result to be non-NULL. On SQLite 3.49.1, the impossible date `2026-13-27T12:00:00Z` makes `strftime` return NULL; SQLite permits the resulting NULL `CHECK`. Audit-owned inserts accepted that value in the context, result, and receipt tables.

`source/src/ge_nwp_coordinator/_rw0_terminal_outcome_rows.py:90-155` also omits the existing `_time` validation for `recorded_at`. Independently constructed result and receipt rows with recomputed valid self-digests passed both `seal_row` and `checked_row`. This violates the UTC whole-second requirement at `source/.docs/rw0-terminal-outcome-physical-closure.md:32-39`.

Fresh planning does call `_time`, and historical reconstruction reaches that planner; the inspected higher-level paths reject the invalid value or classify recovery as `unresolved`. I did **not** demonstrate an invalid normal-writer commit or an unsafe `committed_exact` result. The physical schema and checked-row grammar nevertheless admit a value their contract forbids, so A03 and A13 cannot pass.

## Authentication and provenance

| Attached input | Bytes | SHA-256 |
|---|---:|---|
| Repair review ZIP | 25,334,611 | `f06d97a0becddec07e30676b3988dfcde9d4a79cb6b77a41c23fe4b9d429dd90` |
| Original implementation prompt | 38,100 | `9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f` |
| S01/A03 repair prompt | 29,145 | `7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd` |

The outer ZIP had **1,131** unique normalized, case-fold-distinct, regular unencrypted members, **131,058,990** expanded bytes, and no traversal or special-file entry. All **1,130** member-manifest rows matched path, size, SHA-256, and numeric ZIP mode, with exact manifest self-exclusion. The embedded implementation report was read in full: 22,590 bytes, SHA-256 `0bbd1d73016e9b4593e14dd85743dad5ad1080f8892e4e5879a2f2b3f24107a5`.

The nested original candidate ZIP authenticated at 11,648,876 bytes, SHA-256 `bf26189fd12b2b27fee847e0c0a1808cfeb568c9255bf48bc1f23ff14e728b0e`, with 938 members and 937 covered rows. The prior independent report authenticated at 22,955 bytes, SHA-256 `1fffe41981025295b92fe2c6bff00cd0c2e6d5f95b6b8f565b54f2610934dd7d`; its evidence ZIP authenticated at 92,001 bytes, SHA-256 `e1fd90b32e1987307ba4f8e194d9a1c574a59a6e0de25e9e2a1100edc095331f`, with 44 members and 43 covered rows. Their scripts were inspected as data, never executed.

All 327 final `source/` endpoints matched the final manifest in bytes, blob IDs, paths, Git modes, and OS modes. The final A/B/postcleanup manifests were byte-identical: 109,923 bytes, SHA-256 `45f6716d16522cecb21c046c302893624ab30e8094b15d7f93e628681e00dcbc`. Git-compatible trees independently constructed **from bytes**, without staging or `git write-tree`, were:

| State | Paths | Tree |
|---|---:|---|
| Integrated baseline | 315 | `44c7dee402d46b3e16dc389ae0824b4297dfec1f` |
| Original blocked candidate | 325 | `648d332b3ba847deb257a2bb1892a76e4c442675` |
| Repaired subject | 327 | `011f76542a77b2a766a46ac08df102b4de4c09c6` |

The independently derived immediate delta was **18 modified, 2 added, 0 deleted**; the cumulative delta was **67 modified, 12 added, 0 deleted**, with no Git-mode changes. All repair and cumulative before/addition endpoints matched. Applying the 67 sections of `patch/cumulative.patch` plus 12 addition payloads to an independent audit-owned baseline copy reproduced every final byte. The patch was 134,264 bytes, SHA-256 `c8d27d1a8e81663ec3ec143eccc40bbc767e272b6b979cf4e0876b2405ec6b92`.

Final ZIP wrappers held 326 OS 0644 / Git 100644 files and one OS 0600 / Git 100644 file, `source/tests/test_c2b3_private_atomic_program_initialization.py`. The separate checkpoint had 327 paths, tree `23ec79a6a49c7821dcbc62f01bf4c04ea4a13aac`, manifest SHA-256 `85258843afd2815cf56506fb4b0f62fbc15741d091e6e41c613205a695bf9b20`. Its retained 42-case result gives no credit to later final bytes. The reported branch and HEAD were treated only as archived observations, not live Git facts.

## S01, A03, and O1

**S01:** `source/src/ge_nwp_coordinator/_rw0_terminal_head_witness.py:14-125` retains full checked program, work, selection, effect, and delivery postimages in order, with **8/9/41/9/8** fields and owner self-digests. The context uses `governed-execution.nwp-rw0-terminal-context.v2`; the witness set uses `governed-execution.nwp-rw0-terminal-closure-head-witness-set.v1`. Compact coordinates are checked projections. The full witness is bound through context, outcome, result, graph, and receipt. Fresh and historical paths reach the same immutable-predecessor compatibility rule at `source/src/ge_nwp_coordinator/_rw0_terminal_outcome_plan.py:54-112` and `source/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:216-259,318-445`. A maximal physical witness probe was 6,893 bytes; the conservative supported-field bound was 21,071 bytes, below the 32,768-byte ceiling.

An audit-authored complete valid competing winner yielded `definitely_not_committed`. A complete incompatible winner with an **actually changed program head** and resealed own-row, context, outcome, result, graph, and receipt digests yielded `unresolved` through the real verifier. After all five later heads and stop moved, an SQLite authorizer denied reads of those six mutable tables: historical read, replay, and recovery succeeded with **zero attempted denied SELECTs**. The candidate’s ten S01 regression cases also passed. The independent fully resealed wrong-predecessor control directly reached the program case; the other four roles rely on executed candidate-authored regression oracles.

**A03:** Thirty-four audit-authored direct-construction probes rejected string subclasses and equality-spoof objects at the selected head-role, supplied-role, stop, conflict, outcome, recovery, schema, row, and witness boundaries **before equality was invoked**. Valid built-in values remained accepted. `committed_exact` required exact `TerminalCommittedV1`; both other recovery classes carried `None`. This closes the selected exact-type repair predicates, while F01 leaves the broader grammar blocked.

**O1:** The assertion at `source/tests/test_rw0_terminal_outcome_values.py:111-116,133` checks a class counter even though `EqualitySpy.__eq__` increments `self.calls`. The audit reproduced an equality call with instance count 1 and class count 0. That assertion alone is a weak oracle. A separate shared-counter probe observed zero hostile equality calls at the production boundaries, so O1 remains **nonblocking**.

## Cumulative A01–A18 register

Evidence coordinates below are **relative to the authenticated outer archive**. “Bounded” identifies a limit in proof, not an acceptance claim.

| Row | Archive-relative path:line | Finding, class, and limit |
|---|---|---|
| A01 authority | `source/.docs/rw0-terminal-outcome-physical-closure.md:7-20,197-205` | Contract and current implementation limit terminal facts to five private normal outcomes. P1 decision, acceptance, executable permission, cancel, live supplier/contact, ES/Bridge/Git effects, and autonomy remain separate. No independent runtime contact matrix. |
| A02 preservation | `source/src/ge_nwp_coordinator/sqlite_migration.py:508-523,2433-2436`; `source/src/ge_nwp_coordinator/sqlite_transition_transaction.py:1381-1467,4158-4201`; `source/src/ge_nwp_coordinator/sqlite_writer_session.py:6856-6947` | Byte comparison and static inspection found additive catalog/controller/writer edits. P0/P1, WorkSpec, Decision Basis/command digest v2, D1/D2, package/public surfaces, generic receipt, and SQL 0001–0007 source bytes matched baseline. |
| A03 grammar/types | `source/src/ge_nwp_coordinator/_rw0_terminal_outcome_contracts.py:62-98,200-314`; `source/src/ge_nwp_coordinator/_rw0_terminal_outcome_rows.py:90-175` | **Blocking F01.** Exact-type probes passed; closed fields, canonical JSON, refs, digests, and bounds were inspected. Row timestamps fail the required grammar. |
| A04 identity graph | `source/src/ge_nwp_coordinator/_rw0_terminal_outcome_plan.py:239-285`; `source/src/ge_nwp_coordinator/sqlite_migrations/0008_rw0_terminal_outcome.sql:46-59,94-105,156-166` | Static and SQL controls found independent refs/domains, graph ordering, uniqueness, and pair constraints. Independent optional-assertion digest versus sibling-ref differential remains open. |
| A05 original operands | `source/.docs/rw0-terminal-outcome-physical-closure.md:21-28`; `source/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:176-206,318-344` | Contract/current code retains the original transient P1 command and private replan operand; no persisted template reconstruction found. A same-safe-identity private-content inconsistency was not independently forced. |
| A06 checked source | `source/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:129-175`; `source/src/ge_nwp_coordinator/_rw0_d2_post_execution_continuation.py:152-225` | Owning P0/phase/Section41/C1/V22/P1 readers are used. Fully resealed detached validation/review/proposal/source evidence was not independently exhausted. |
| A07 acceptance | `source/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:193-199,396-400`; `source/src/ge_nwp_coordinator/_rw0_terminal_outcome_plan.py:148-162` | Existing acceptance is read only for accept; terminal recording writes only its four rows. Wrong/missing/foreign and unrelated-fact interactions lack a separate complete control. |
| A08 heads/stop | `source/src/ge_nwp_coordinator/_rw0_terminal_head_witness.py:14-125`; `source/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:216-259,378-383` | S01 independent program-winner and later-movement controls passed. Independent fully resealed wrong-predecessor tests for every role remain incomplete. |
| A09 transaction | `source/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:347-401`; `source/src/ge_nwp_coordinator/sqlite_transition_transaction.py:1381-1467,3158-3262` | Static path and executed candidate tests show fenced controller, receipt-first lookup, row readback, receipt-last insertion, and one commit attempt. Independent exhaustive write/commit/cleanup faults remain open. |
| A10 replay/read | `source/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:318-356`; `source/src/ge_nwp_coordinator/_rw0_terminal_outcome_plan.py:163-285` | Independent historical no-current-head/stop control passed. Original-operand and detached-source variations were not exhausted. |
| A11 recovery | `source/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:404-445`; `source/tests/test_sqlite_rw0_terminal_connected.py:304-310` | Independent **complete** valid and incompatible winner controls passed. The candidate’s monkeypatched verifier exception is insufficient by itself; partial/foreign/damaged winner and every alias route remain open. |
| A12 errors/cleanup | `source/src/ge_nwp_coordinator/_sqlite_rw0_terminal_outcome.py:65-83,144-259`; `source/src/ge_nwp_coordinator/sqlite_transition_transaction.py:1431-1449` | Static code distinguishes valid drift from malformed/failed reads. Stale/closed/fenced sessions and all three process-control exception boundaries were not independently forced. |
| A13 schema/admin | `source/src/ge_nwp_coordinator/sqlite_migrations/0008_rw0_terminal_outcome.sql:1-166`; `source/src/ge_nwp_coordinator/sqlite_migration.py:508-523,2433-2436` | **Blocking F01.** Independent SQL controls passed table/guard, FK, unique, pair, blob, zero-seed, migration, and refusal cases, but three timestamp CHECKs admit impossible dates. |
| A14 connected normals | `source/tests/test_sqlite_rw0_terminal_connected.py:44-49,259-301,316-425,427-473` | Independently executed candidate-authored tests covered five source-coherent normal cases and a detached negative; the six are included in direct 46. No separate audit-authored end-to-end five-positive oracle. |
| A15 docs/assurance | `source/tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:1983-2057`; `source/tests/test_architecture_contracts.py:317-329` | Cumulative static review found preserved historical markers and exact source/hash/API guards, without new skip/xfail or broad oracle stripping. Independent FULL stopped at F01. |
| A16 privacy/artifacts | `source/src/ge_nwp_coordinator/_rw0_terminal_outcome_contracts.py:136-152,200-259`; `source/src/ge_nwp_coordinator/_rw0_terminal_outcome_plan.py:163-204` | Grammar inspection found safe owner metadata rather than raw private replan text, prompts, capsule/process results, or handles. Full independent private-content canary matrix remains open. |
| A17 retained evidence | `validation/direct/collection/observer.json`; `validation/full/execution/observer.json`; `validation/full/execution/junit.xml`; `tooling/run_gate.py:1-170` | Retained records reconciled as data. The archived helper captured source before collection and after execution, without a separate full intervening snapshot. Failed/superseded attempts and checkpoint earn no final credit. |
| A18 independent validation | `source/tests/test_sqlite_rw0_terminal_controls.py:1-420`; `validation/full/collection/observer.json`; `source/src/ge_nwp_coordinator/sqlite_migrations/0008_rw0_terminal_outcome.sql:44,121,154` | Direct 46, S01/A03 probes, and SQL/admin controls completed. Independent selector-free FULL and remaining causal matrix stopped at F01. |

## Execution, retained evidence, and limits

Isolation was checked before candidate execution. The existing Python **3.13.4**, pytest **8.4.1**, and SQLite **3.49.1** were used without installation. A bounded synthetic sandbox check denied network bind/connect and user-home access. Candidate runs used an exact audit-owned copy, task-owned HOME/TMPDIR/JUnit/logs, empty inherited environment, UTC, `-B`, disabled user site/plugin autoload/cacheprovider, empty addopts, and a separate nonselecting observer.

The independent five-module direct gate collected and ran **46 unique passing cases**, including six connected cases, with **zero warnings**. Ordered collection IDs, execution collection, call reports, and JUnit IDs matched each other and the retained final direct inventory. There were no failed, error, skipped, xfail/xpass, or failed noncall outcomes. Four source inventory captures around collection and execution matched all **327** endpoints, numeric modes, tree `011f76542a77b2a766a46ac08df102b4de4c09c6`, and zero extra files. The 46 IDs are present in retained FULL. Audit-authored probes are separately counted.

The independent disposable-state SQL audit made **87 assertions**, including three that confirmed F01. Literal SQL 0001–0007 matched baseline bytes; 0008 was 27,856 bytes, SHA-256 `5bd540def9028d09c4e2100f61f449acfb3a5c914fa554f47975d8c773d4cd20`. Cumulative tables/triggers/explicit indexes were **68/122/5** at 0006, **74/134/5** at 0007, and **78/142/5** at 0008. Earlier schema objects were byte-identical after 0008; its four STRICT tables and eight guards were the only additions. Immutability, FK, uniqueness, normal/pair/blob bounds, zero seeds, fresh and explicit-prefix migration, and old-binary/partial/unknown/checksum refusal controls passed. The old uncommitted 0008 was not treated as deployed.

The writer’s **retained** gates reconciled at direct 46, connected 6 **within direct**, focused 126 modules / 8,252 cases, and FULL 9,554 cases. All retained ordered IDs and pass outcomes matched within their gates; narrower sets occurred in retained FULL. Direct/connected had zero warnings. Focused/FULL each had the same three known Python 3.13 multithreaded-fork `DeprecationWarning` test nodes: `test_operation_guard_close_waits_and_retains_authority_until_exit`, `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`, and `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`. **The 9,554-case FULL was not independently run.** The prior independent 34 direct cases included its six connected cases and no independent FULL. F03 and F05 remain inherited nonblocking observations.

F01 stopped the requested broader causal matrix. Unfinished independent controls include all five fully resealed wrong-predecessor roles, three cancel shapes and unsupported profile, detached source chains, acceptance-fact variants, inconsistent private replan operands, assertion/command-reuse differentials, posture and stop/read-fault distinctions, exhaustive transaction and cleanup faults, partial/foreign/damaged winner aliases, and stale/closed session plus process-control exceptions. Candidate-authored tests cover portions of that space, with their oracle limits stated above. An initial audit-owned S01 helper assumption was corrected on fresh owned state and was not counted as a candidate failure.

No candidate source, mode, test, schema, or documentation was edited. No staging, commit, push, PR, merge, publication, deployment, provider, ES, Bridge, service, or product-database effect occurred. Task-owned runtime SQLite/HOME directories and bytecode cache were removed after evidence capture; no database or bytecode is in the delivered ZIP. **Process deviation:** before I had read the full envelope, I accidentally ran one read-only live-checkout `git status --short --branch` and file-name search. It made no mutation, supplied no audit evidence, and was followed by no further live-repository access. This disposition relies on authenticated archive bytes and isolated controls; it makes no live-state or production-readiness claim and grants no repair or commit authority.

## Reopened deliverables

The [complete report](/tmp/rw0-terminal-audit.DMliIJ/AUDIT_REPORT.md), [safe evidence ZIP](/tmp/rw0-terminal-audit.DMliIJ/delivery/RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_BLOCKED_EVIDENCE.zip), and [delivery receipt](/tmp/rw0-terminal-audit.DMliIJ/delivery/DELIVERY_RECEIPT.json) are available. I reopened the ZIP and verified CRC, every covered member’s path, size, SHA-256 and numeric mode, manifest self-exclusion, and report equality.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `AUDIT_REPORT.md` | 26,456 | `32d697f4bfceaa08d97338af30cc40258be4643d385f6e8f418e3be6ee2a9612` |
| ZIP `member-manifest.json` — 37 covered rows | 8,161 | `55254d64093327646b7a70571037d752397fabdf2b669fddc119fb5bb3369618` |
| Evidence ZIP — 38 members | 151,261 | `b81f4713d4bfaa4c4c943727f1db007907e560d90432cb06b31545ced21235e5` |
