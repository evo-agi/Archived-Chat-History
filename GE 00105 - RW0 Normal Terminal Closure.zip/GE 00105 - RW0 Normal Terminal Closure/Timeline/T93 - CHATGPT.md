## Engineering disposition

**The archive authenticates. All seven claimed closures are supported at their stated scopes. Preserve them, the unchanged runner, and W’s complete regression passes. Twenty mandatory substantive predicates remain open; the candidate is still unaccepted.**

The next assignment distinguishes three kinds of fixture: a literal SQL constraint case, a deliberately inconsistent but foreign-key-valid family, and a complete source-coherent terminal history. **A second complete terminal chain must not become a blanket prerequisite for tests that need only one of the first two.**

The exact review subject remains:

```text
4691af58ae0ee3107b4e2e9b6b1508032944e357
```

## Authenticated evidence

| Item | Verified result |
|---|---|
| Uploaded ZIP | **66,432,954 bytes** |
| SHA-256 | `5742007bd3d0ffe950ee3fc40d1daa1ccf1140e9b2dcf2a8452861a614c0f9d6` |
| Archive inventory | **181 regular files; 180 verified manifest rows** |
| Expanded size | **76,867,573 bytes** |
| Embedded report | **9,610 bytes**, matching its manifest identity |
| Candidate | All **327 source files** authenticated and independently reconstructed to the fixed tree |

Every covered member passed path, uniqueness, type, encryption, size, CRC, SHA-256, and numeric-mode checks. The embedded RC/W/M/U/T/S/R archives also authenticate.

The opening binding and twenty before/after source captures each contain five complete copies: **all 105 recorded copy inventories match the candidate**. The final cleanup supplies five passing summaries, not five additional complete inventories.

All eleven launch records bind their actual archived helpers and unchanged policy. Ten exit successfully; the first damaged-context probe fails an audit assertion and receives no passing credit. The retained admission, output, process-closure, and preservation records reconcile. No source, policy, or accepting-runner behavior change was found.

These are artifact and retained-record findings—not observations of the current live checkout or tests executed here.

:chatgpt-content-reference{index="2"}[Detailed receiving inspection](sandbox:/mnt/data/Coordinator_RW0_RSE972_Receiving_Review.md)

## 1. C1A04 now demonstrates actual same-store coexistence

The successful fixture goes beyond RC’s second-P0-only attempt. It constructs the unrelated subject in the **existing managed store** through real initialization, author-effect establishment, P0, and the private P1 writer. It does not reinitialize the database, insert an acceptance fact directly, transplant another store, or replace an owner check with success.

The retained execution establishes:

- Acceptance facts increase from **one to two**, with distinct subject and parent identities.
- The second P1 acceptance has checked read, exact replay, and `committed_exact` recovery.
- The selected terminal records `accept`, binds only its original acceptance fact, and reads/replays/recovers exactly.
- Both acceptance-row hashes and the checked predecessor state remain unchanged by terminal closure.

A **separate repair case** supplies the required nonaccept distinction: an unrelated checked acceptance exists, but the selected repair terminal has a null acceptance binding and does not create a selected acceptance fact.

This supports **C1A04 closure**. It is not an all-outcome cross-product or evidence of a new production multirun feature. Both P1 families receive checked reads; the helper separately exercises replay/recovery for the second P1 and for the selected terminal—not an additional standalone first-P1 replay/recovery program.

The two cases satisfy the mandate’s coexistence and nonaccept distinction without imposing an unnecessary second D2 workflow on the unrelated fact. Coordinator_RW0_Normal_Terminal…

Exact evidence and source coordinates are in the Coordinator_RW0_RSE972_Receiving_Review\.md[receiving review](sandbox:/mnt/data/Coordinator_RW0_RSE972_Receiving_Review.md).

## 2. The four route closures are valid, scoped implications

The source and SQL support these relationships:

| Closed predicate | Occupied child field | Necessarily earlier parent probe |
|---|---|---|
| **C2A09** | Result’s `outcome_value_ref` | Outcome’s `outcome_value_ref` |
| **C2A15** | Receipt’s `context_ref` | Context’s `context_ref` |
| **C2A16** | Receipt’s `outcome_value_ref` | Outcome’s `outcome_value_ref` |
| **C2A17** | Receipt’s `result_ref` | Result’s `result_ref` |

The composite foreign keys require the corresponding parent key to exist. The actual route reader checks that parent first: a valid row produces an earlier match; a malformed row raises integrity failure before the later child probe is reached.

**These are invariant closures, not physical child-first executions.** They apply to foreign-key-valid complete, partial, or foreign assemblies; they do not require the whole family to be semantically coherent.

One boundary remains important: the managed-state code checks that `PRAGMA foreign_keys` is enabled. That is **not a historical whole-store foreign-key scan** and does not establish that preexisting FK-invalid rows are impossible. RS expressly excludes those states from its implication. The damaged and foreign-family recovery obligations remain separate.

There is no reason to manufacture an impossible child-first specimen to replace a valid implication—but no reason to extend that implication beyond its actual assumptions either. This follows the existing audit requirement. Coordinator_RW0_Normal_Terminal…

## 3. C2B12 and C3A04 reach their intended boundaries

### C2B12 — receipt-last and readback rollback

The corrected probe calls the real checked lookup, then injects one `OperationalError` at the selected result or receipt readback.

The two cases record **three and four successful inserts**, respectively, exactly one fault hit, and **zero calls to the actual commit method**. Each returns `mutation_failed`; all four terminal tables return to zero. Only writer-ownership bookkeeping changes elsewhere.

After removing the fault, normal record/read/replay agree, recovery is `committed_exact`, and each terminal table contains one row.

That supports the named readback and receipt-last closure. It is **an error after a successful checked lookup**, not a denied SQL SELECT, and it does not close the recovery-cleanup obligation C2B13.

### C3A04 — result constraints

The literal-SQL probe pairs each negative with a valid insertion into the same starting state, uses enabled foreign keys and guards, retains the actual SQLite error, and verifies rollback.

The result cases reach both mismatched composite foreign keys. A separate case reseals a distinct result reference against the same valid outcome and reaches exactly:

```text
UNIQUE constraint failed: rw0_terminal_results.outcome_value_ref
```

The result primary key also makes the composite uniqueness declaration on `(result_ref, result_digest)` redundant for duplicate-reference rows. The reached controls and that source implication support C3A04’s stated scope.

**Useful partial work must also carry forward:** fifteen other SQL negatives contribute to still-open C3A02/C3A03/C3A05. Their parent rows remain open, but those executed predicates are not “unperformed.”

Likewise, the corrected C2A19 probe establishes integrity refusal and unresolved recovery for a physical **one-context damaged prefix**. It does not establish behavior for a complete damaged exact or competing-winner family, so C2A19 properly remains open.

:chatgpt-content-reference{index="4"}[Execution and constraint reconciliation](sandbox:/mnt/data/Coordinator_RW0_RSE972_Receiving_Verification.json)

## 4. The remaining construction work needs three distinct fixture levels

The reported stop identifies an unfinished fixture, not a reproduced owner rejection or proven product limitation. Some remaining collision or uniqueness cases may genuinely need additional coherent parents. That does not make every graph mutation, damaged-family negative, lease fault, or cleanup case dependent on a second complete workflow.

The replacement prompt makes the distinction explicit:

| Evidence being sought | Required fixture |
|---|---|
| **Literal SQL constraint** | Valid referenced parents and an isolated, reachable constraint; not necessarily a complete successful terminal workflow for every deliberately invalid tuple |
| **Historical rejection of inconsistent state** | Individually valid or deliberately targeted invalid rows, with required FK relationships intact; clearly labeled synthetic damaged/foreign state |
| **Legitimate complete history or competing winner** | All actual checked predecessor families and owner relationships; the first two fixture types cannot substitute for this |

This is a construction strategy, **not a reduction in acceptance requirements**.

There are concrete single-chain directions for the next work:

**Graph and repeated-field negatives.** The graph member list is constructed by the plan; it is not a freely stored role-list column. The auditor can independently recompute it, test the actual grammar, and reseal a receipt with an incorrect calculated graph digest to reach historical comparison. For one repeated-field case, the already checked unrelated P1 decision can supply the deliberately inconsistent receipt decision reference while preserving the actual context/outcome/result FKs. Neither requires inventing a second normal terminal outcome.

**Complete damaged-family behavior.** Capture a genuine four-row plan, then construct a fresh, explicitly synthetic family with the intended self-digest error and consistently bound child FK pairs. That can reach the complete-family refusal predicate without updating immutable rows or disabling guards. It must not be represented as something the normal writer successfully committed.

**Lease and recovery cleanup.** These require the actual session/controller path, counted fault injection, exact outward classification, and a fault-removal positive. The current evidence does not establish that a second source lineage is a prerequisite.

These are **proposed controls, not newly executed proofs**. The prompt requires the auditor to verify their reach and limitations. Where a complete second phase/Section 41/C1/V22 chain is genuinely necessary, it must be built through the real owners with distinct typed identities. Other independent cases continue meanwhile.

## Twenty predicates remain—not a regression reset

| Group | Open predicates |
|---|---:|
| Graph and source associations | 3 |
| Later route matches | 10 |
| Damaged and foreign-family recovery | 2 |
| Lease and recovery cleanup | 2 |
| Context, outcome, and receipt SQL constraints | 3 |
| **Total** | **20** |

All 56 stable ledger IDs and their historical objects remain intact. Exactly seven mandatory-open flags changed to closed.

W’s previously reviewed **60/60 direct and 9,568/9,568 FULL** passes remain attributed to W v5. The RC assurance supplements and the seven RS closures retain their separate scopes. No evidence in this receiving pass invalidates them or calls for an automatic rerun.

The next assignment starts with the open graph and recovery cases that can use existing checked subjects, then reaches the additional-parent work according to each predicate’s actual dependencies. It does not reopen completed C4, selected-acceptance controls, runner qualification, or calendar and normal-branch programs merely to establish another checkpoint.

## Codex handoff

| Field | Instruction |
|---|---|
| **CURRENT STATE** | Seven RS closures are supported; exact candidate remains unaccepted with twenty substantive predicates open. |
| **RECIPIENT** | The **same neutral independent reviewer conversation** that produced `rs-e972c82f3b`. |
| **ATTACHMENTS** | **None required.** Exact retained input paths and identities are included. |
| **AUTHORIZED EFFECTS** | Audit-owned fixture, observation, registration, and ledger work; unchanged-candidate execution under the preserved admitted runner. |
| **EXPECTED RETURN** | One cumulative disposition, exact closed/open IDs, coverage records, full report, and reopened evidence ZIP. |
| **PROJECT SNAPSHOT** | None requested. |
| **NEXT ACTION** | Return the cumulative result here before any candidate repair or commit gate. |

Send **only this complete replacement prompt**:

:chatgpt-content-reference{index="5"}[**RW0 normal terminal closure — twenty residuals and audit completion**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Twenty_Residuals_Completion_Prompt.txt)

**Substantive sections 2–4 remain byte-identical.** The changes are supported carry-forward, the twenty-row backlog, precise fixture-level distinctions, and dependency-aware execution order. No earlier prompt fragments need to be assembled.

```text
Prompt size:
68,017 bytes

SHA-256:
fa0def55311c833befd63e34a6697f142d23f554f6dd18c4b2a4194c5ccc128a
```

:chatgpt-content-reference{index="6"}[Handoff identity record](sandbox:/mnt/data/Coordinator_RW0_RSE972_Handoff_Check.json)

Keep the implementation conversation idle. No candidate edit, policy expansion, assertion relaxation, installation, staging, commit, publication, or deployment is authorized.

**Inspection limits:** Data-only archive verification, source reconstruction, retained-record reconciliation, and static inspection. No supplied helper, candidate code, SQL, test, policy, Git operation, or host probe was executed here. Historical host actions remain retained observations, not independently observed live events.

**Sources:** Coordinator_RW0_RSE972_Receiving_Review\.md[Receiving inspection](sandbox:/mnt/data/Coordinator_RW0_RSE972_Receiving_Review.md), RW0_Normal_Terminal_RSE972_Report_From_Sealed_ZIP.md[exact embedded RS report](sandbox:/mnt/data/RW0_Normal_Terminal_RSE972_Report_From_Sealed_ZIP.md), and Coordinator_RW0_RSE972_Receiving_Verification.json[verification record](sandbox:/mnt/data/Coordinator_RW0_RSE972_Receiving_Verification.json).

**Confidence:** Artifact/source identity **0.99**; retained-record reconciliation and the seven scoped closures **0.98**. The twenty remaining predicates, proposed fixture sufficiency, complete candidate acceptance, and commit-gate eligibility remain unestablished.
