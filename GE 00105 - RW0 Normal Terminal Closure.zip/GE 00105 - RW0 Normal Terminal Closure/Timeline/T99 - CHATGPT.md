## Engineering disposition

**Do not repair the candidate. The reported C2A11 result exposes an over-specified audit expectation, not an established implementation defect.**

The governing implementation is deliberately **receipt-first**:

1. `write_fresh_after_fencing` looks up `rw0_terminal_receipts.mutation_ref` before predecessor checks or route scanning.
2. If that receipt exists, the writer verifies the persisted historical family and command association.
3. `_route_occupied` runs only after that receipt lookup misses.
4. `_route_occupied` later probes the same table, column, and value for `receipt.mutation_ref`.

Therefore, in one fenced transaction, a receipt cannot both:

- be absent at the initial `receipt.mutation_ref` lookup; and
- appear as the first matching `receipt.mutation_ref` route during the later scan.

The previous prompt nevertheless required C2A11 to reach the later route scan and return `route_collision`. That requirement conflicts with the source order and the owner document’s receipt-first contract. Coordinator_RW0_C2A11_Receipt_First_Static_Review\.md[Static source review](sandbox:/mnt/data/Coordinator_RW0_C2A11_Receipt_First_Static_Review.md)

The candidate remains the exact uncommitted, unaccepted tree `4691af58ae0ee3107b4e2e9b6b1508032944e357`. Pasted text

## Correct interpretation of C2A11

The actual safety property is not “every indexed column must independently return `route_collision`.” For `receipt.mutation_ref`, the required behavior is:

- the receipt-first lookup reaches the existing receipt;
- the persisted family and command association are checked;
- an exact command replays exactly;
- an incompatible receipt or family refuses as integrity or command reuse, according to the actually reached predicate;
- no fresh terminal rows are inserted;
- no result is improperly disclosed;
- recovery remains appropriately unresolved when exactness cannot be established;
- the later route scan is not falsely claimed to have run.

The receipt-mutation probe in `_route_occupied` is consequently a defensive/redundant entry under the current transaction ordering, not a physically isolatable first-match route. Closing C2A11 by a **receipt-first supersession invariant plus actual execution evidence** is the correct audit treatment.

This is an amendment to our audit expectation. It does not change the product contract, candidate source, SQL, policy, or test assertions.

## Status of the audit verdict

The RU audit’s formal `BLOCKED` verdict remains historically attached to its exact mandate and evidence. It should not be silently rewritten.

For engineering sequencing, however, treat this as:

> **audit specification blocked on an incorrect C2A11 expected outcome—not candidate implementation blocked**

A corrected fresh audit continuation should be able to:

1. preserve all twelve RU closures;
2. preserve the earlier W v5 representative, exact-99, direct-60, and FULL-9,568 passes;
3. re-adjudicate C2A11 using the receipt-first criterion above;
4. continue independently with C1B05 and C2A20;
5. issue a new cumulative disposition on the unchanged candidate.

If the retained RU records support the closeout’s description, the likely post-correction state is **INCOMPLETE with C1B05 and C2A20 still open**, rather than BLOCKED on C2A11. That conclusion remains provisional until the exact execution records are inspected.

## Next action

Upload only this existing archive:

```text
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED_20261030_ru-a8116dc584.zip

Bytes:
87,897,841

SHA-256:
0a9db9e6ac62ddb6975c5aee613175deafe79833beb87b7bf7aa6d88c95a289b
```

Reported location:

```text
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/
evidence/ru-a8116dc584/
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED_20261030_ru-a8116dc584.zip
```

No separate report, manifest, candidate package, or predecessor archive is needed. Do not regenerate it.

The receiving inspection will verify:

- that C2A11 reached the initial real receipt lookup;
- the exact receipt and command identities;
- the first failing historical-family predicate and outward error;
- confirmation that `_route_occupied` was not entered;
- row nonmovement, disclosure behavior, and recovery classification;
- the twelve claimed closures;
- the precise remaining work for C1B05 and C2A20.

Keep the same neutral reviewer conversation and runner intact. Keep the implementation conversation idle. No candidate edit, policy change, regression rerun, staging, publication, or new Project snapshot is indicated.

**Sources:** Coordinator_RW0_C2A11_Receipt_First_Static_Review\.md[C2A11 static source review](sandbox:/mnt/data/Coordinator_RW0_C2A11_Receipt_First_Static_Review.md); Coordinator_RW0_Normal_Terminal_Minimal_Second_Phase_And_Fifteen_Residuals_Prompt.txt[operative fifteen-residual prompt](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Minimal_Second_Phase_And_Fifteen_Residuals_Prompt.txt); candidate audit baseline cited above.  
**Confidence:** **0.98** that the previous C2A11 `route_collision` requirement conflicts with the receipt-first source contract; **0.90** on the likely corrected cumulative disposition pending RU evidence inspection.
