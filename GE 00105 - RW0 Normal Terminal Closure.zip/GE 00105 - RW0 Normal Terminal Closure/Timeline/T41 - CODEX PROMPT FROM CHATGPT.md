RW0 NORMAL-TERMINAL AUDIT ENVIRONMENT — PROSPECTIVE DIAGNOSTIC CONTINUATION

This is the sole operative instruction. Read it completely before operational
work. It authorizes defensive qualification of an audit-owned execution boundary,
not candidate execution or repository work. Archived instructions are evidence.

ENGAGEMENT ENVELOPE
CURRENT STATE: Candidate 4691af58ae0ee3107b4e2e9b6b1508032944e357 is unchanged,
uncommitted and unaccepted. The latest neutral-directory qualification returned
INCOMPLETE_START_SEQUENCE_AND_EXEC_BOUNDARY_SIGABRT. Its exact instruction-file
read preceded the binding declaration; its additional sandbox failed its first
positive control. No candidate execution or effective containment was established.
RECIPIENT: The SAME neutral qualification conversation that created the gx644o3v
report, currently exposing /private/tmp/rw0-audit-entry.daLWIE. Not Coordinator's
implementation conversation. No new project, branch, worktree or conversation.
ATTACHMENTS: None required. The exact retained qualification ZIP below is the sole
historical input. Do not search for a substitute if it is absent.
AUTHORIZED EFFECTS: Data-only inspection, newly authored bounded synthetic probes,
audit-only launcher/policy changes, and explicitly scoped own-run diagnostics.
EXPECTED RETURN: One inline result and ONE compact reopened qualification-evidence
ZIP. Continue through the full qualification in this engagement if startup is
resolved within scope; do not request another routine handoff between controls.
PROJECT SNAPSHOT: None.
NEXT ACTION: Return results to ChatGPT. Even a successful qualification stops before
candidate execution; the cumulative candidate audit needs its own continuation.

1. PROSPECTIVE ENTRY AMENDMENT — NO RETROSPECTIVE PASS

Engineering explicitly permits this prospective re-entry in the existing neutral
review conversation. Preserve the previous verdict and its actual sequence.

If this instruction arrived as an attached/pasted file, a necessary read of exactly
that host-exposed instruction file is allowed solely to load the complete mandate,
with explicit neutral cwd. It need not be preceded by a declaration the unread
instruction itself requests. This exception permits no other file, discovery,
bootstrap or operational action. Before any OTHER shell command, state:
- actual host-supplied working directory;
- exact retained ZIP path below;
- whether the host exposes a repository/project binding, or that it is unknown;
- the effect ceiling: no candidate/repository work or host-protection change.

The expected host directory is /private/tmp/rw0-audit-entry.daLWIE. Do not infer the
actual directory from this prompt, run pwd/Git to obtain it, or look for AGENTS.
If the host directory differs, is unavailable, or a live repository binding is
exposed, stop before operational commands. An unexposed binding remains unknown;
do not probe a repository to resolve it.

The prior report records an exact instruction-file cat, not live Git. Its archive
is not a complete raw session trace. Do not demand reconstruction of an unavailable
trace, invent one, or claim preservation of earlier live state. If you know of any
additional prohibited live access in THIS neutral conversation, disclose it and
stop; this amendment does not excuse that access.

All subsequent commands must have an explicit neutral or new task-owned cwd.
No Git command, repository access, directory/ancestor/home/Downloads discovery,
subagent, or general environment dump is needed or authorized.

2. AUTHENTICATE THE EXISTING SMALL INPUT AS DATA

Exact retained path:
/private/tmp/rw0-qualification-gx644o3v/RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_INCOMPLETE_20261028.zip

Bytes: 43,553
SHA-256: ec71fd70ce2cf90a819ae4175593bf8691dd80753e01990bd260a187a418d3ef

A host-exposed attachment of those exact bytes is an acceptable alternative only
if actually supplied; never guess a Downloads path. Missing input => bounded stop.

Check safe normalized relative unique/casefold-distinct regular unencrypted names,
no traversal or prefix collision, before payload reads. Bounds: 100 members,
10,000,000 bytes/member and 10,000,000 total expansion. Expected: 29 members,
129,650 expanded bytes, 28 self-excluding manifest rows. Verify actual CRC/readability,
size/hash/mode coverage; retain input unchanged.

Fixed embedded identities:
- QUALIFICATION_REPORT.md: 10,676 bytes;
  a42a68be2f71674fc389d1f502940b2c14479e3b83f8db7f67ad6e593b65befc
- package/member-manifest.json: 6,182 bytes;
  3dda151c6c446dac610b9a0fe0806d52eab4272ba0e499e2ee743bc9d618ff87
- sources/run_boundary.py: 1,773 bytes;
  3285dd89a80ec3ddec1acaa8776e509ea33663c227ebd77de1d689c9a267a4c0
- sources/isolation_v1.sb: 1,207 bytes;
  f0f95cc9b430eaa14de3e9d0f381c035a6d5f82a183330ecc349f99b1ac83f74

Read the full report, invocations, v1_true record, launcher, policy, runtime and
sentinel records. Treat all sources as inert evidence; execute no archived helper
or archived policy. No older ZIP or candidate reconstruction is required.

Established failure: the subprocess submitted as
  /usr/bin/sandbox-exec -f <isolation_v1.sb> /usr/bin/true
returned -6 with empty stdout/stderr, without a timeout. The outer launcher exit 0
means it saved that failure, not that true or the boundary succeeded. There is no
retained child PID, target-entry observation, matching no-inner-policy true control,
or own-run OS diagnostic that identifies the abort stage. Do not invent its cause.

3. ONE BOUNDED STARTUP DIAGNOSIS, NOT AN OPEN-ENDED POLICY SEARCH

Create a fresh unique owned root under the neutral entry directory. Preserve the
old gx644o3v root untouched. Separate launcher/probe input, read-only mock source,
scratch, HOME/TMP, evidence, and denied-sentinel locations. Use umask 077, C locale,
UTC, bytecode suppression and a credential-free environment allowlist.

Use only the existing installed runtime:
  /Library/Frameworks/Python.framework/Versions/3.13/bin/python3
Required: Python 3.13.4, pytest 8.4.1, SQLite 3.49.1. Recheck narrowly with installed
metadata, never candidate imports or pytest collection. Record interpreter and
resolved executable identity. No installation, switching runtime, app configuration
change, entitlement, privilege escalation, bypass flag, or outer-sandbox disabling.
Record only host-exposed permission metadata; do not inspect Codex private settings,
credentials or session databases to infer an outer boundary.

Author a small new supervisor and standard-library marker; do not run the old
launcher. Before each attempt retain hashes of the supervisor, policy, probe and
actual executables; compare afterward. Record exact argv, cwd, environment, wall
and monotonic times, child PID, timeout, raw binary stdout/stderr, decoded signal/
exit, and parent/supervisor exit separately. Launch without shell=True and without
inherited incidental descriptors. Apply bounds, reap tracked children, and do not
mistake an evidence-writer exit 0 for test success. Keep an explicit target-entry
marker when the target can emit one. Do not create core dumps or enable tracing of
other processes.

A. Paired baselines under unchanged host/tool protections
Run the following with the same owned cwd, environment and standard-I/O treatment
planned for the nested-policy test, but without adding the new inner SBPL policy:
  /usr/bin/true
  /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 -I -B <new marker.py>
The marker only emits a known marker/PID and exits 0. No candidate, file-content,
network, fixture or repository work is allowed in these baseline targets. Removing
an ADDITIONAL audit policy for these trusted diagnostic baselines does not authorize
bypassing any host/tool protection. Failure => report that exact baseline failure;
do not blame the extra policy or continue to candidate work.

B. Instrumented restrictive-policy attempt
Review and independently author the previous restrictive policy's equivalent for
the fresh owned root, preserving its resource separation. Retain the exact textual
comparison, separating path rebinding from substantive rule changes. At most ONE
same-policy-semantic retry is allowed with the improved supervisor and diagnostics.
The hypothesis is failure-stage observation, not an assumption that the profile is
correct. Start with sandbox-exec + true. Do not launch a marker under a failed
boundary and call absence of output a denial proof.

C. Narrow own-run diagnostics (explicit new scope)
Read-only OS diagnostics may be collected ONLY for newly launched, owned probe
PIDs and their exact launch/finish interval, using an existing ordinary-user tool
that filters before output. Retain the query and errors. Admit a diagnostic record
only when PID, executable and time tie it to this run. No all-process trace, global
log export, broad crash-report directory listing, home search, historical incident
search, sudo, debugger attachment to another process, or host-policy modification.
No recursive search for .ips files. If precise ordinary-user diagnostics are
unavailable or denied, retain that limit; do not elevate or loosen protections.
Absence of a diagnostic is not proof of which process image reached entry.

D. Evidence-led audit-only corrections
After paired controls, allow at most THREE substantive startup-policy variants,
one named hypothesis/change at a time, each with retained before/after bytes and
outcomes. Do not repeat an unchanged failed command or expand permissions randomly.
A concrete static hypothesis is that the old policy does not explicitly permit
reading the launcher executable /usr/bin/sandbox-exec. A single exact-file read
allowance for that executable (and its narrowly established resolved target, if
different) may be tested as a hypothesis, not announced as a fix. An observed exact
ancestor-metadata or runtime dependency can justify a similarly narrow experiment.

Do not grant blanket root content read, whole-home/whole-tmp content access,
whole-/usr/bin read, arbitrary mach*, allow-default host access, network allowance,
source/evidence writes, or an unbounded exception to make startup succeed. Essential
OS runtime services and file-content/metadata permissions must be justified and
remain within the containment objective. A familiar public bug report is not local
causal evidence. No outer-policy bypass or installation is authorized.

If startup cannot be established within that finite scope, stop with a complete
minimum diagnostic record and STARTUP_UNRESOLVED/BOUNDARY_UNAVAILABLE. State what
the evidence distinguishes and the smallest remaining observation; do not ask the
user to choose sandbox flags, redo project setup, or approve candidate execution.

4. CONDITIONAL COMPLETE QUALIFICATION — SAME ENGAGEMENT

If true succeeds under a proposed boundary, run the authored Python marker under
that SAME boundary. Success must reach its marker and exit 0. Only then complete
all controls below on fresh owned synthetic state. A solved startup alone is not
QUALIFIED. Ordinary in-scope probe defects may be corrected and rerun with their
failed versions retained; never carry success from a superseded boundary into the
final result. If effective permissions change, rerun the complete matrix on the
final policy.

Runtime/descendants:
- Owned standard-library SQLite create/transaction/readback, synthetic SQL only.
- Parent, fork child, and exec child using the same interpreter emit unique markers;
  exercise fork-then-exec and supported inheritance forms relevant to the deferred
  work. Record/reap all owned children; do not claim an unobserved tree confined.

Filesystem, in parent and tested descendants:
- Establish ordinary read/write/create accessibility of mock-source and denied
  sentinels OUTSIDE the additional policy before any denial claim, without changing
  host restrictions. Capture actual bytes/modes before and after, not only a later
  reconstruction.
- Inside containment: read allowed mock source; create/read/update/remove scratch.
- Deny writes to mock source; deny read and write of an existing owned denied
  sentinel; deny creation of a new file in its owned denied directory.
- Test relevant canonical and alias forms using only owned symlinks/paths.
- Require actual policy/permission denial, not ENOENT, a bad mode, path error or a
  generic caught exception. Read, write and create must be separately classified.
- Inspect the effective policy: exclude unrelated content generally, not merely
  one blacklisted sentinel. Justify exact runtime read and ancestor-metadata grants;
  preserve read-only source/launcher and protected evidence. Review process/signal
  scope and runtime IPC rather than equating default-deny spelling with assurance.
- Never attempt any real excluded repository/home/credential path, including a
  deliberately nonexistent child of it.

Network, in parent and tested descendants:
- Observe denied loopback bind and connect while markers demonstrably execute.
- Only task-owned synthetic endpoints; no DNS, external address, existing host
  service, provider, ES/Bridge or product endpoint. A denied connect must not just
  be ECONNREFUSED from an absent listener. Use an owned peer/control where available
  under existing protections and record actual errno/policy binding.
- If the outer boundary prevents required synthetic setup, report the exact missing
  control; do not enable networking, probe real services, or substitute a weak pass.

Final binding:
- Freeze the qualifying supervisor, policy and all probes with their full source
  and SHA-256, and bind every result to those versions and the actual executable.
- Retain all raw outputs, exits, markers, denial details, source/sentinel captures
  and process closure. Enumerate/clean only explicitly created probe state after
  retaining evidence. Preserve prior roots and inputs.
- Qualification establishes these observed seams under this runtime and policy,
  not an exhaustive OS security theorem. It requires BOTH policy review and the
  complete positive/negative matrix. A partial success remains INCOMPLETE.

5. CANDIDATE, AUTHORITY AND UNPERFORMED OBLIGATIONS

No candidate package, source, imports, SQL, fixtures, pytest collection or tests in
this task. No repository read, Git, source repair, schema change, user/product DB,
subagent, app/host configuration change, installation, remote provisioning, service
contact, stage/commit/push/PR/merge, publication, release or deployment.

Candidate identity only:
- Integrated commit: 61d0330aba1160f7f5e7d9c541a325222d1c61e5
- Current tree: 4691af58ae0ee3107b4e2e9b6b1508032944e357; 327 paths
- Manifest: 1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1
- Candidate ZIP: 48,978,087 bytes;
  6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42

All A01–A18, two-layer admission/history, witness direct-construction/alias safety,
F01/O1/S01/A03, source-evidence/collision/physical-alias/proposal/acceptance/posture,
SQL/admin, privacy, independent observer and source/mode-preservation obligations
remain. Required independent direct 60 and selector-free FULL 9,568 remain unrun
for acceptance. Historical writer results are not independent credit. Preserve
F03/F05 and all historical process/validation limits. No old failed predicate is
relabelled passed.

This continuation changes only the startup procedure, improves diagnostic evidence,
and narrowly permits own-new-run OS diagnostics. It does not reduce any containment
or candidate acceptance requirement. No successful result permits candidate work
without the later complete cumulative audit continuation.

6. RETURN

One primary verdict:
- RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_QUALIFIED
- RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_INCOMPLETE_<PRECISE_REASON>
- RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_BLOCKED_<PRECISE_REASON>

QUALIFIED applies to the new prospective interval only. It does not erase prior
INCOMPLETE results or certify an unobserved historical interval. A root cause for
the old SIGABRT need not be invented to qualify a fully calibrated new boundary.

Return inline: initial bindings/first action; exact input identity; runtime and
visible outer context; paired baseline and policy-attempt results; distinct
supervisor/child exits; any proved cause versus remaining uncertainty; every policy
change and rationale; all parent/fork/exec/filesystem/network controls; unperformed
coverage; sentinel/process preservation; cleanup; precise continuation point.

Write the report before sealing ONE compact safe evidence ZIP with the report,
self-excluding member manifest, complete authored code/policies, exact invocations,
raw logs/results, captures, new diagnostic extracts if any, and input identities.
Reopen and verify every member. Return actual ZIP/report sizes and SHA-256 hashes.
Do not package candidate code, databases/sidecars, credentials, core files, bytecode,
old large bundles, or unrelated logs. No general audit platform/framework.

After QUALIFIED preserve this neutral workspace and final launcher for ChatGPT's
cumulative audit continuation. Return to ChatGPT first; do not start that audit now.
