ENGAGEMENT ENVELOPE

CURRENT STATE
The private normal-terminal program is uncommitted and unaccepted. The original
candidate was blocked by S01/A03. Its full-witness/type repair passed bounded
independent predicates but the next cumulative audit found F01 timestamp grammar;
that audit did not complete the causal matrix or independent FULL and disclosed
a preliminary prohibited live-checkout read. The latest ten-file F01/O1 repair
is a NEW exact subject. No preceding verdict accepts these bytes.

RECIPIENT
A FRESH independent Codex audit conversation. The implementation writer remains
idle. This is an authorized defensive correctness/authority/durable-state audit
of the user's supplied private software, using only sealed artifacts and
isolated synthetic state. It is not a live repository, service, or host audit.

ATTACHMENTS
Exactly three evidence inputs:
1. RW0_NORMAL_TERMINAL_CLOSURE_F01_TIMESTAMP_REPAIR_UNCOMMITTED_REVIEW.zip
   36,160,973 bytes; SHA-256:
   ca1a42d3165809887b4d837232cf9a45ff18e1c643921c5eef7b0a42d2737844
2. Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt
   38,100 bytes; SHA-256:
   9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f
3. Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt
   29,145 bytes; SHA-256:
   7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd

The current F01 repair mandate is already inside input 1 at
requirements/ENGAGEMENT_ENVELOPE.txt:
26,064 bytes; SHA-256:
e158b7c3bb61905ccc2e4c83b8fb59c8b7806ba9b5c5fe21d56a8fd429f088d6

These older mandates are REQUIREMENTS EVIDENCE ONLY. Do not execute their
implementation, live-Git, cleanup or publication instructions. This new mandate
is the SOLE operative instruction. Use actual attachment paths; do not infer a
Downloads namesake. No separate report, old ZIP or prior-chat context is needed.

AUTHORIZED EFFECTS
Inert archive/source inspection, audit-authored data-only inspection scripts,
then isolated candidate tests and synthetic SQL/causal controls after
authentication and isolation gates. Task-owned reports/evidence are allowed.
No candidate edits, live checkout/.git access, network, user/product database,
dependencies, staging, commit or publication.

EXPECTED RETURN
One complete inline report and one reopened safe audit-evidence ZIP, with the
complete report embedded and exact identities. No independent acceptance until
all mandatory obligations are completed on the exact subject.

PROJECT SNAPSHOT
None requested. PR #17, commit 61d0330aba1160f7f5e7d9c541a325222d1c61e5,
tree 44c7dee402d46b3e16dc389ae0824b4297dfec1f remains the integrated baseline.

NEXT ACTION
Return the audit result to ChatGPT. ACCEPT establishes only eligibility for a
separately governed live exact-byte commit gate. BLOCKED/INCOMPLETE must retain
completed findings and exact outstanding coverage. Do not repair or commit.

FIRST-ACTION BOUNDARY

Read this complete operative mandate before any filesystem discovery or command.
Do not perform a customary initial repository listing, git status, pwd/rg in
a checkout, AGENTS lookup in a live repo, or metadata capture from .git.
Repository rules are read ONLY from authenticated source/ inside the ZIP.
The known operator checkout is expressly OUT OF SCOPE:
  /Users/ds/Repositories/Governed Execution Coordinator/
So are other repos, Downloads searches, user home/config/credentials, previous
/tmp roots, Git remotes and connectors. Existing attachment paths are read
only as supplied inputs; use a new neutral task-owned audit root for work.
No live source is needed to authenticate the archive or run isolated tests.

If an accidental forbidden action occurs, disclose the actual action and
observed effects; do not infer either mutation or preservation. Preserve
artifact findings but do not certify compliant acceptance. A provider or
capability refusal is an execution limit, not a candidate defect; preserve
finished work and report INCOMPLETE rather than lowering required coverage.

OBJECTIVE

Independently determine whether the complete normal-terminal candidate satisfies
its governing contracts after S01/A03 and F01/O1 repairs. This is cumulative
A01–A18 review, not a timestamp-only approval or a repetition of writer suite
totals. Perform the following three phases in ONE engagement.

1. AUTHENTICATION AND SCOPED PROVENANCE

1.1 Exact current subject
- Final source: 327 regular paths.
- Final source tree: 5c44721183f660032b6468d2c1f5a1d0dc3e6acb.
- Canonical final source manifest:
  identity/final-manifest-A.json
  109,923 bytes; SHA-256:
  d0b74c46d2aad8cb1ba9d151770146e09150038b46c895f47608cbe074c8bae6.
- identity/final-manifest-B.json and identity/postcleanup-manifest.json must
  equal final A byte-for-byte.
- Immediate predecessor tree: 011f76542a77b2a766a46ac08df102b4de4c09c6.
- Original terminal tree: 648d332b3ba847deb257a2bb1892a76e4c442675.
- Integrated baseline tree: 44c7dee402d46b3e16dc389ae0824b4297dfec1f.
- Retained HEAD: 61d0330aba1160f7f5e7d9c541a325222d1c61e5;
  branch codex/rw0-normal-terminal-closure-v1; upstream absent.
These HEAD/ref/index/config fields are archived observations, NOT live facts.

Immediate change: exactly 10 modified paths; no addition/deletion/mode change.
Cumulative change: 67 modifications, 12 additions, 248 unchanged baseline paths;
no deletion or mode change. The subject is 327 files, not the original 325.

1.2 Package gate
Verify outer input hashes, then central directories before extraction or trust.
Current ZIP: 855 unique normalized casefold-distinct relative regular members;
106,826,768 expanded bytes. No absolute/traversal/backslash ambiguity, duplicate,
file/ancestor conflict, encryption, link or special file. Use bounded expansion
(at most 2,000 members, 150 MB/member and 500 MB/archive); inspect nested archives
before reading their contents and bound total work.

package/member-manifest.json covers exactly the other 854 members:
SHA-256 dd5d2dfcdcd56970a7cc6a7064634dd642bf1f25d8017ab2697014c1c9c9692a.
Require path, size, SHA-256, numeric ZIP mode, CRC readability and exact
self-exclusion/coverage. Verify the manifest's actual encoding, not a guessed
generic schema.

Read the unique current report in full:
evidence/IMPLEMENTATION_REPORT.md
17,269 bytes; SHA-256:
77a4cfa1c6fbdfb7da986d751dad7ce69a3b4e28d5fa169bfd476d23fecf82ec.
No distinct standalone-report equality gate is required.

1.3 Source and patches
Authenticate every current source byte/size/hash/Git blob/Git mode/OS mode.
Independently construct Git-compatible tree identity from actual archived
payloads; no live Git, staging or git write-tree.

Reconstruct the immediate predecessor by overlaying patch/immediate-before/
on source/. Authenticate identity/immediate-before-manifest.json and opening
A/B against the nested predecessor source.
Reconstruct integrated baseline by removing patch/cumulative-additions/ and
overlaying patch/cumulative-before/.
Verify all endpoint bytes and modes, not just supplied blob IDs or tree labels.

Replay exact hunks using audit-authored data-only logic:
- patch/immediate.patch: 34,721 bytes; 10 sections/19 hunks; SHA-256
  cc4b49d04a75a3d73a7c118ee49ace5e81915a2160d5d01fb9cf72c3937f4993.
- patch/cumulative.patch: 134,264 bytes; 67 sections/128 hunks; SHA-256
  19e7834a23c8e6918110bd7c5157404d1c26704c29ac7da88a90cf7083d1af1e.
The cumulative patch covers tracked modifications; authenticate all twelve
addition payloads separately. Immediate diff headers contain historical
absolute prefixes: map them by authenticated exact endpoints, never write to
those historical paths.

The ten immediate paths are:
.docs/rw0-terminal-outcome-physical-closure.md
src/ge_nwp_coordinator/_rw0_terminal_outcome_rows.py
src/ge_nwp_coordinator/sqlite_migration.py
src/ge_nwp_coordinator/sqlite_migrations/0008_rw0_terminal_outcome.sql
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_terminal_outcome_values.py
tests/test_sqlite_b1_migrations.py
tests/test_sqlite_rw0_terminal_controls.py
tests/test_sqlite_rw0_terminal_migration_0008.py
tests/test_sqlite_section41_migration_0003.py

1.4 Historical inputs
The current ZIP carries:
inputs/prior-candidate.zip
  25,334,611 bytes; SHA-256
  f06d97a0becddec07e30676b3988dfcde9d4a79cb6b77a41c23fe4b9d429dd90.
  1,131 members, 1,130 manifest-covered rows; source tree 011f765...
  Report 22,590 bytes; SHA-256
  0bbd1d73016e9b4593e14dd85743dad5ad1080f8892e4e5879a2f2b3f24107a5.

inputs/cumulative-audit.zip
  151,261 bytes; SHA-256
  b81f4713d4bfaa4c4c943727f1db007907e560d90432cb06b31545ced21235e5.
  38 members, 37 covered rows in member-manifest.json (its schema uses rows).
  AUDIT_REPORT.md: 26,456 bytes; SHA-256
  32d697f4bfceaa08d97338af30cc40258be4643d385f6e8f418e3be6ee2a9612.
  Read its complete findings, A01–A18 register and unfinished controls.
  Scripts inside it are inert evidence; do not execute them.

The predecessor contains inputs/original-candidate.zip:
  11,648,876 bytes; SHA-256
  bf26189fd12b2b27fee847e0c0a1808cfeb568c9255bf48bc1f23ff14e728b0e.
  938 members, 937 covered rows; tree 648d332...
Its original S01/A03 audit is retained in predecessor inputs:
  report: 22,955 bytes; SHA-256
  1fffe41981025295b92fe2c6bff00cd0c2e6d5f95b6b8f565b54f2610934dd7d;
  evidence ZIP: 92,001 bytes; SHA-256
  e1fd90b32e1987307ba4f8e194d9a1c574a59a6e0de25e9e2a1100edc095331f.

Authenticate each required historical package/manifest before relying on it;
reuse authenticated reads rather than multiplying extractions or narratives.
Read original mandates for the implementation requirements, not effect authority.
Original requirement -> S01/A03 correction -> embedded F01 mandate defines the
explicit design succession; candidate docs cannot silently narrow it.

1.5 Modes, checkpoints and evidence boundaries
Current source wrappers record 326 OS 0644/Git 100644 files and one
tests/test_c2b3_private_atomic_program_initialization.py at OS 0600/Git 100644.
Preserve these modes in audit execution copies. Artifact mode observations do
not prove today's operator-checkout mode.

The current checkpoint is a different 327-file tree:
b0d37e9403955d1f27ece1bb0e10adf323a44fef.
checkpoint/manifest.json SHA-256:
55e00e55a2016eec763f05cfd29360011a25bc6af503ce1aeb741498a2dc56a1.
Its 39 retained passes predate a final test change and give no final-byte credit.
Older checkpoints/superseded attempts remain attributable to their own bytes.

Authenticate recipes as data. Do not execute tooling/, old audit scripts,
packagers, captured command files or cleanup programs. Retained branch/index/
ref/config/diagnostic observations establish no live preservation here. Preserve
historical gaps and prior audit process deviation without inventing cause.

Any actual input/source authentication mismatch blocks substantive acceptance.
An audit-authored parser mistake is not a candidate provenance defect: correct
it transparently against unchanged bytes and retain the failed attempt.

2. SUBSTANTIVE REVIEW AND PERMITTED ISOLATED VALIDATION

2.1 Scope and order
Read authenticated AGENTS.md, governing architecture/authority/operating-model
owners, normal-terminal physical owner, original implementation requirements and
both repair requirements. Inspect source, tests, cumulative shared
controller/writer/catalog edits, literal SQL, configs and retained artifacts
together. Do not substitute hash identity for correctness.

First decide F01/O1 and the previously material S01/A03 predicates, then complete
the cumulative matrix and independent execution. A material finding may stop
broad FULL execution; retain exact completed and unperformed coverage.
This ordering reduces wasted execution; it does not narrow acceptance.

2.2 F01 — SQL and row grammar must pass independently
Prior F01 was admission of impossible recorded_at text by raw SQL and checked
rows. It was NOT an observed invalid ordinary writer commit or unsafe
committed_exact. Preserve that distinction.

Inspect source coordinates:
- sqlite_migrations/0008_rw0_terminal_outcome.sql:44–61,138–155,188–205;
- _rw0_terminal_outcome_rows.py:90–100,160–167;
- unchanged _rw0_terminal_outcome_contracts.py:84–93;
- tests/test_sqlite_rw0_terminal_migration_0008.py:196–286;
- tests/test_sqlite_rw0_terminal_controls.py:30–41,438–550.
Python basenames are under source/src/ge_nwp_coordinator/. Confirm actual
coordinates independently rather than relying solely on these hints.

A. Literal SQL:
Independently apply the authenticated literal, without a candidate sealer.
Exercise each of context/result/receipt recorded_at INSERTs separately, with
valid parents/other fields, foreign keys enabled, fresh savepoints/keys and a
paired valid insertion under the identical arrangement. Distinguish timestamp
CHECK failure from unrelated FK, uniqueness, digest-shape, trigger or NOT NULL
rejection. Record actual outcomes and target row counts.

Reproduce the original 2026-13-27T12:00:00Z specimen using preserved old SQL in
audit-owned historical state, then prove repaired rejection at all three
targets. Do not promote that synthetic raw insert into a normal-writer exploit.

Establish the supported calendar and representation domain, not just bad month:
year zero; month/day zero/overflow; nonleap Feb 29; Feb 30; Apr 31; 1900/2100
versus 2000; hour 24/25; minute/second 60; offsets/fractions/alternate case;
whitespace, embedded/trailing NUL, Unicode digits, nontext storage classes.
Include ordinary dates, valid month ends, leap days, year-end 23:59:59 and
supported endpoint years. Identify 20-byte ASCII and no-normalization enforcement.
Inspect why predicate results cannot become NULL acceptance.
Verify all three predicates identical and the SQL diff limited to those three
replacements; do not weaken other constraints to isolate them.

B. Exact row boundary:
Test direct checked_row tuples and seal_row with empty and supplied self-digests
for context/result/receipt. Recompute serializable negative self-digests in
audit-owned code from the documented preimage, not with a rejecting sealer.
Require rejection at the timestamp/type boundary, with positive otherwise-equal
rows. Cover invalid calendar/form, None/bool/int/bytes/str subclass/equality
objects; verify type-first behavior without coercion. Nonserializable type
negatives receive type-boundary, not valid-digest credit.
The outcome table has no recorded_at and must gain none.

Compare SQL, _time and TerminalCommittedV1 on valid supported endpoints and
calendar values on the required runtime. The parser is deliberately unchanged;
a platform formatting discrepancy must be identified, not normalized away or
silently broadened into a new global time policy.

C. Higher-level behavior:
Use real fenced accept/replan positives and all five connected normal outcomes.
An invalid captured time cannot create any terminal row/receipt. State the
actual reached seam: holding disclosure positive to reach plan/row validation
is a test-only injection, not proof that an ordinary writer bypasses disclosure.
Exercise malformed selected result/receipt at the real row-return seam and
unmodified read/replay/recovery: integrity/no protected result, unresolved
original and competing recovery, no write/normalization/retry. Restore the fault
and prove the valid family positive. A row-return injection is not automatically
an all-link historical resealing proof; complete the distinct winner/source
obligations below independently.

D. Catalog and compatibility:
New 0008 is 30,178 bytes; SHA-256
a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254.
Only this uncommitted resource, its current checksum consumers and row grammar
change. SQL 0001–0007 and frozen schema-0001 fixture must remain byte-exact;
no 0009, generation bump, new columns/tables/triggers/indexes/seeds/domains.
Old 0008 variants are rejected test history, not deployed formats to backfill.
Check both obsolete checksums and schema/checksum divergence, not only a
hardcoded hash literal in a report.

2.3 S01 — full witness and historical compatibility
The original finding combined incomplete observed postimages and a missing
historical compatibility check. Prior selected success is predecessor evidence,
not current cumulative acceptance. Independently establish:
- context.v2 and witness-set.v1; exactly ordered program/work/selection/effect/
  delivery full typed postimages with 8/9/41/9/8 fields, valid nulls and
  self-digests, using existing owner adapters;
- canonical full witness within the justified 32,768-byte limit, including
  supported maximum fields and depth/cardinality; no truncation;
- compact command/outcome coordinates derived and checked as projections,
  never substituted for the full historical witness;
- context/outcome/result/graph/receipt bind the witness without digest cycles;
  no v1 fallback, desired-row synthesis or later-live-head backfill;
- actual fenced fresh reads supply stored rows;
- one compatibility relation is reached in fresh planning/recording, checked
  read/replay, original recovery and complete competing-winner verification;
- program equals retained P1 postimage; replan work equals retained P1 work
  postimage; other work/selection/effect/delivery match immutable predecessor
  identities, digests and owner cross-links;
- fresh genuine drift is no-write stale_currentness, while malformed/failed
  reads and incompatible history stay integrity/unresolved;
- later changes to all five heads and global stop do not invalidate valid
  history or cause historical paths to read those current mutable tables.

Complete independently authored controls for EACH of five roles: all fields
captured, bad self-digest, valid self-digest but wrong immutable predecessor,
actual current-row movement (not just changed expectation), wrong owner/link
and exact later historical replay. Use fully resealed synthetic families:
own-row/context/outcome/result/graph/receipt digests internally valid so the
relationship predicate is reached. Pair every corrupt resealer with a valid
family produced by the same construction. Restore ordinary production
verification before the tested call. Do not infer full coverage from an early
digest failure or a monkeypatch making the verifier raise.

Test complete compatible and complete incompatible competing winners, original
routes, exhaustive absence and partial/foreign/damaged aliases. An incompatible
complete winner must not prove definitely_not_committed or disclose its result.
Use an observed transitive SELECT-denial seam to establish historical
independence from the five current heads and stop. Prior independent program
role control is not a substitute for the other four roles.

2.4 A03 and O1
Require exact built-in types before equality/membership at all selected head
role, supplied-role, stop, schema, conflict/outcome/recovery and witness
boundaries. Direct construction as well as decoded values is in scope.
Preserve valid built-in positives. committed_exact carries exact
TerminalCommittedV1; other classifications carry None.

O1's current test at tests/test_rw0_terminal_outcome_values.py:111–141 uses a
shared mutable list, intentional equality calibration, clearing and per-boundary
zero-call assertions. Verify that behavior with an audit-authored shared or
per-instance counter. Do not automatically credit the repaired test or relabel
the predecessor's nonblocking oracle flaw as a production bypass.

2.5 COMPLETE A01–A18 ACCEPTANCE REGISTER

For each row supply archive-relative path:line evidence, finding severity and
class (contract/current implementation/bounded proof/retained record/independent
execution/inference/limit). Inspect the full cumulative candidate, not only the
ten-file repair. Unchanged code does not discharge unfinished controls.

A01 Authority: terminal fact distinct from P1 decision/acceptance, policy grants,
source facts and executable permission. Exactly five normal outcomes; cancel,
gate-B supplier, RW0-E/live contact, ES/Bridge/Git effects/autonomy excluded.

A02 Preservation: terminal-V1/four validators, P0/P1 meanings/owners, WorkSpec,
Decision Basis/command-digest v2, preassignments, D1/D2 source behavior, original
operand requirement, package/public StateStore and generic receipt unchanged.
Inspect cumulative shared writer/controller/catalog edits, even though those
writers are byte-equal to the blocked candidate during this repair.

A03 Grammar/types: all new commands/values/rows/results/recovery; exact types,
closed keys, duplicate handling, canonical UTF-8/JSON, bool-as-int, safe refs,
digest/time grammar, bounds; independently resolve A03/O1 and F01 at SQL and row layers.

A04 Identity graph: sibling refs/route, independent domains, acyclic transcripts,
assertions in command identity but outside preassignments, graph roles,
cardinality, self-digest exclusion and duplicate-column consistency.

A05 Original transient P1 command and private replan operand: authenticate whole
persisted predecessor family; missing/mismatched operand cannot prove certainty.
No template reconstruction from digest, persistent template store or private
content leakage.

A06 Actual P0/phase/Section41 A/C1 rank15/V22/P1 source association. Completeness
comes from owning checked readers, not supplied digest equality or membership
count. Transitive validation/review/proposal observation and result-set binding.

A07 Existing immutable acceptance fact bound only for accept, never inserted,
mutated or replenished; unrelated legitimate facts do not prevent other branches.
No historical unclaimed-scope eligibility recheck.

A08 Complete observed closure heads and stop; full S01 witness/binding decision.
P1 replan postimages distinguished from phase entry. Changed correctly expected
stop is a recordable fact, not new effect permission.

A09 Transaction: existing fenced lease/capability/controller; one time,
receipt-first protected posture, predecessor/current/route checks,
context/outcome/result writes and readback, receipt last, capability invalidation,
one commit attempt and cleanup. No application head/stop/decision/effect update.

A10 Replay/read: original immutable result/time/graph, source reauthentication
and full historical witness compatibility; no current-head/stop dependency,
new cognition/process, recording permission or acceptance-eligibility requirement.

A11 Recovery: exact full family, exhaustive original absence/exclusion or
complete compatible winner only; partial/foreign/damaged/aliased/incompatible
history unresolved. No winner disclosure, automatic retry or fragment repair.

A12 Error/cleanup: failed reads and malformed owners stay integrity/operational
failures; actual valid drift stays currentness. New terminal entry's stale
issuance, closed/fenced session, commit/cleanup uncertainty and all three
process-control exception boundaries causally checked.

A13 Schema: uncommitted 0008 context-v2/bound correction; F01 timestamp grammar plus four STRICT immutable
normal-only tables, composite FKs, phase/decision/mutation/route uniqueness,
nullable pairs, zero seeds, guards, exact catalog/checksum, generation 2,
fresh/prefix migrations and old-0008/old-binary/partial/unknown refusal.

A14 Five actual source-coherent connected normals through P0/D1/D2/Section41/
C1/V22/P1/terminal/read/replay/recovery. Vary fixture content BEFORE capsule
sealing/checker execution. Detached resealed disposition is a negative, not a
normal positive produced by relabelling a passing checker.

A15 Whole cumulative docs/assurance change: exact source/hash/AST/import/schema
consumers and preserved historical markers; fixed current/predecessor guards,
no dynamic oracle, skip/xfail, broad stripping or weakened test for new source.

A16 Privacy/artifacts: new full postimages remain safe owner metadata; no raw
private replan text, prompts, capsule/process results, PID/path/handles,
credentials/user state in durable rows or errors. Review grammar, not just
sample canaries. Classify checkpoint/failed attempts and Finder exclusion.

A17 Retained evidence: authenticate observers/logs/argv/env/JUnit/IDs and source
binding; preserve overlap, per-gate warning identity and superseded-run noncredit.
A causal register is not an independently reached predicate.

A18 Independent validation: source-bound probes/direct suite/SQL and completed
selector-free collection/FULL, complete node/outcome/warning/source reconciliation.
Unperformed work remains explicit; no live-state or production-readiness claim.


2.6 Complete the unfinished discriminating controls
Alongside F01, S01, A03 and O1, independently establish:
- five source-coherent connected normal positives; three cancel shapes and
  unsupported profile rejected before any terminal write;
- fully resealed detached validation/review/proposal/source bindings;
  wrong/missing/foreign acceptance fact, unrelated legitimate facts, and no
  acceptance/head/stop/P1 family movement from terminal operations;
- original transient replan operands for record/read/replay/recovery, including
  private-content inconsistency sharing a claimed safe identity; no invented
  template from digest or durable private payload;
- optional assertions change command digest, not sibling preassignments;
  reuse cannot obtain a protected result or false recovery classification;
- recording plus disclosure for fresh writes versus disclosure-only for
  historical read/replay/recovery, including truthful claimed False/None after
  prior acceptance; denied/expired/negative/malformed/foreign posture and
  protected absence;
- changed/active correctly expected closure stop versus actual head drift,
  failed SELECT and malformed-row classification across roles;
- every terminal insert/readback/receipt-last boundary and rollback; exactly
  one commit attempt; failure before commit, applied commit with lost return,
  postcommit cleanup uncertainty and recovery cleanup uncertainty; no hidden
  retry or fragment repair;
- complete compatible/incompatible winners, partial/foreign/damaged winners
  and every original creation/alias route, without winner-result disclosure;
- stale issuance/lease/fence/closed session and KeyboardInterrupt, SystemExit,
  GeneratorExit at meaningful fresh/read/recovery/cleanup boundaries;
- independently observed normal contact/noncontact and private-content canaries
  consistent with the closed grammar and artificial offline scope.

Candidate fixtures may be reused after inspection, but additional independent
oracles must state what is varied, why the setup is valid, the actual reached
predicate and expected no-write/result/error. Do not count candidate assertions,
a wrapper refusal or a mocked final verifier as separate independent causal
proof. Extra probes remain outside candidate pytest discovery.

2.7 Independent SQL administration
Apply all eight authenticated literals only to owned synthetic state:
0006 -> 68 tables / 122 triggers / 5 explicit indexes;
0007 -> 74 / 134 / 5;
0008 -> 78 / 142 / 5; application generation 2.
Verify exact prior schema objects/resources, four immutable STRICT tables and
eight guards, zero new application rows, FK/unique/pair/profile/normal-only and
payload bounds, supported maximum witness, fresh initialization, explicit
0006/0007-prefix upgrades and old-binary/unknown/partial/foreign/checksum/schema
refusal. Include both older uncommitted 0008 variants.
schemas/sqlite/coordinator-state-v1.sql is frozen 0001 evidence, not a cumulative
schema generation target. No real-store migration or repair is authorized.

2.8 Retained record reconciliation and independent test gates
Inspect writer records as data only:
direct: five complete terminal modules, 51 cases, zero warnings;
connected: 6 cases, zero warnings, included in direct;
focused: 126 complete modules, 8,257 cases, 3 warnings;
FULL: no selector, 9,559 cases, 3 warnings.
Unique ordered collection = execution collection = calls = JUnit; every
call/setup/teardown passed, no failure/error/skip/xfail/xpass.
All narrower IDs must be in FULL; do not sum overlapping totals.

Ordered-ID digests use UTF-8 compact JSON array serialization:
json.dumps(ids, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
with NO trailing newline:
direct 5457915aecc5df6a08d3b41fd02111dbd2c8cb6a33eb97008f850ff54f180248
connected 81e14e3fa1b85a7be2ea6fafac85974839145bbcb6397e6da0bb1feeba060aac
focused 2f8e8d68f309f7b9dda512ec7a1b217b4c50e074e1d660aca7501da21f3d19c4
FULL 768793f8faef7a43942c9d71d1bbc863d281e879886d04d8d9e3181abeaa9da6

All sixteen validation/<gate>/<collection|execution>/source-<before|after>.json
records must agree exactly. Their encoding is 105,559 bytes, SHA-256:
703b5c466b6e1c02b51815aed8d1a1c6e43a43e6a0940b1ce16f2d6956b0e6d8.
This differs intentionally from the canonical manifest envelope. Require
field-for-field source-row equality, correct final tree, embedded canonical
manifest hash and no extra/missing paths. Do not compare distinct envelopes as
though they were the same byte format or backdate earlier missing captures.

Read tooling/run_gate.py, gate_observer.py and summarize_validation.py only as
data. The observer must not select, skip or change outcomes. Combined
stdout/stderr is acceptable only if labelled; no invented separate stderr.
Inspect failed/superseded attempts, checkpoint, smoke and cleanup records at
their stated scope, not as final pass credit.

If no material blocker remains, independently run:
1. All five complete modules in this order:
   tests/test_rw0_terminal_outcome_values.py
   tests/test_rw0_terminal_head_witness_regression.py
   tests/test_sqlite_rw0_terminal_controls.py
   tests/test_sqlite_rw0_terminal_migration_0008.py
   tests/test_sqlite_rw0_terminal_connected.py
   Expected 51 unique passes including six connected cases.
2. On a fresh exact 327-file copy, a selector-free repository collection and
   complete FULL execution. Expected 9,559 unique IDs in the retained order.
3. Independent collected/execution-collected/call/JUnit identity and order must
   match each other and the final retained inventories. Audit probes remain
   separately counted and outside candidate discovery.
4. No failures/errors/skips/xfails/xpasses or failed noncall outcomes.
5. Independently inventory warnings. FULL's three known warning nodes, all
   DeprecationWarning in tests/test_sqlite_b2c_writer_session.py:
   test_operation_guard_close_waits_and_retains_authority_until_exit
   test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
   test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
   Process IDs and owned paths may differ. New class/node/message differences
   require investigation, not suppression.
6. Four complete raw source/mode/extra-file captures immediately before/after
   collection and before/after execution for each independent gate. Reconstruct
   the final tree and verify all 327 endpoints unchanged.
A separate 8,257-case focused execution is unnecessary if exact FULL inclusion
is proven; do not claim one ran. Independent FULL is mandatory for acceptance,
not discharged by writer FULL or previous bounded audit tests.

2.9 Runtime and isolation gate
Use the existing supported comparable Python 3.13.4 / pytest 8.4.1 /
SQLite 3.49.1 runtime without installation. Record actual platform and versions.
If unavailable, identify that exact coverage limit and report INCOMPLETE; do
not claim comparable validation from a different platform without qualification.

Before candidate import/execution:
- inspect pyproject/config/conftest and all selected fixture/child-launch seams;
- create a neutral owned audit root and exact source copies, never a live repo;
- enforce no network and no live-repository or unrelated user-home access for
  parent and children; allow only required runtime resources and owned state;
- verify effective restrictions with bounded synthetic denial probes, not
  merely socket construction or a printed policy;
- use restrictive umask, task-owned HOME/TMPDIR/basetemps/JUnit/logs;
- deterministic locale/UTC, -B, PYTHONDONTWRITEBYTECODE=1, PYTHONNOUSERSITE=1,
  PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, empty PYTEST_ADDOPTS, -p no:cacheprovider;
- no inherited selectors, xdist, warning suppression, plugin auto-installation
  or access to credentials and product databases;
- use an independently authored nonselecting observer outside source for
  call IDs/warnings/JUnit properties.

Underlying command forms from the exact audit-copy root:
  <python> -B -m pytest -q -p no:cacheprovider [audit observer]
    --collect-only --basetemp=<owned collection> <complete module list>
  <python> -B -m pytest -q -p no:cacheprovider [audit observer]
    --basetemp=<owned execution> --junitxml=<owned XML> <same list>
For FULL omit ALL test-path/module/node/-k/-m selectors.
Retain exact argv/cwd/allowlisted environment, exits, logs, durations, IDs,
JUnit, warnings and complete inventories. No archived helpers may run.

Audit-authored temporary monkeypatches, SELECT fault seams and synthetic
corrupt-family construction are permitted only in owned state and only to reach
the explicitly stated predicate; restore ordinary checked paths before testing
their rejection. Do not edit candidate files, leave a bypass in production,
or touch a live database. Failures remain failures. A helper error may be
corrected transparently on fresh owned state; it supplies no candidate failure
or silent retry/pass credit.

3. FINAL FINDINGS AND ACCEPTANCE LIMITS

Return exactly one primary disposition:
RW0_NORMAL_TERMINAL_CLOSURE_F01_REPAIRED_CUMULATIVE_ARTIFACT_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
RW0_NORMAL_TERMINAL_CLOSURE_F01_REPAIRED_CUMULATIVE_ARTIFACT_AUDIT_BLOCKED
AUDIT_PROVENANCE_MISMATCH
RW0_NORMAL_TERMINAL_CLOSURE_F01_REPAIRED_CUMULATIVE_ARTIFACT_AUDIT_INCOMPLETE

ACCEPT requires exact source tree
5c44721183f660032b6468d2c1f5a1d0dc3e6acb,
F01 SQL AND checked-row closure, explicit calibrated O1 decision, preserved and
independently established S01/A03 predicates, completed A01–A18 and mandatory
causal/admin controls, independent 51-case direct and 9,559-case selector-free
FULL with identity/outcome/warning/source reconciliation. Scope every
nonblocking observation honestly. F03/F05 remain inherited nonblocking
observations. No suite total can replace an unperformed required predicate.

The original and predecessor BLOCKED results remain historical. Their earlier
execution may guide control design but cannot silently close changed-source
obligations. The preceding auditor's live-checkout read remains a separate
process deviation, not current compliance or a candidate timestamp defect.

Acceptance grants eligibility only for a separately governed live exact-byte
commit gate. It authorizes no staging, commit, push, PR, merge, publication,
deployment, live terminal/cancellation/contact capability or autonomy.

Return one complete inline report and one reopened safe audit-evidence ZIP:
- exact inputs, source chain, immediate/cumulative deltas, modes, patch
  reconstructions, migration/checkpoint identities;
- F01 SQL/row and O1 determinations, S01 full-witness/historical controls, A03
  exact-type results;
- A01–A18 table with exact path:line, severity, evidence class, result and limits;
- audit-authored probes and actual reached predicates, including any early
  masking, overlapping coverage or candidate-authored oracle reliance;
- retained versus independently executed tests, SQL/admin controls, all
  ordered IDs, warning/source reconciliation and unperformed coverage;
- process deviations, helper errors, skipped/interrupted work and safe cleanup;
- no-live-state/effect attestation based on actual observations;
- exact report/ZIP/member-manifest sizes and SHA-256 after reopening.

Reports/probes/manifests are evidence only, never Coordinator or Git truth.
Exclude credentials, user/product data, runtime SQLite/sidecars, bytecode/cache
and unclassified binary state from delivery. Preserve synthetic text evidence
and safe probe source.

PROHIBITED THROUGHOUT: live repo/.git/index/ref/config/cache access; candidate
source/test/doc/schema/mode edits; executing archived helpers; network/provider/
ES/Bridge/service contact; real databases; dependency installation; staging,
commit, push, PR, merge, publication, deployment, cancellation implementation,
supplier qualification and new-tranche work.
