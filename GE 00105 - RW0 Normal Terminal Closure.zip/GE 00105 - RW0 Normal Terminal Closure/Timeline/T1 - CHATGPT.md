## Engineering disposition

```text
RW0_P0_P1_PROGRAM_CLOSED
NEXT_CRITICAL_PATH = DURABLE_RW0_TERMINAL_OUTCOME_PHYSICAL_CLOSURE
```

The integrated Coordinator baseline is now:

```text
trunk_dev:
61d0330aba1160f7f5e7d9c541a325222d1c61e5

sole parent:
4519630d0db967066beb21b4ace5004e76827716

tree:
44c7dee402d46b3e16dc389ae0824b4297dfec1f

source paths:
315
```

After re-grounding on the checkpoint, my provisional architecture judgment is that the next program should **not** begin with live worker contact, a supplier implementation, ES routing, or product Git effects.

The next program should physically implement the **separate durable RW0 terminal-outcome owner**.

### Why terminal closure comes next

The merged source now has:

- durable P0 scope-admission history;
- durable P1 five-branch progression decisions;
- an immutable acceptance fact created only by the acceptance branch;
- exact replay, readback, and three-way recovery;
- pure terminal-outcome values and relation validators;
- a detailed target terminal-outcome causal contract.

But it still lacks the durable fact that closes an RW0 run. A P1 acceptance fact is deliberately **not terminal truth**, and an unresolved terminal outcome must prohibit a successor, Git effect, or publication effect.

The first-live contract also keeps three gates distinct:

1. contract validity;
2. concrete supplier/custody conformance;
3. separately authorized RW0-E execution.

It explicitly requires the relevant terminal contracts and implementation before RW0-E. Selecting a live supplier or worker route first would force an unselected external platform into the Coordinator’s durable design.

## Program sequencing

The recommended critical path is:

```text
durable RW0 terminal-outcome physical closure
    → independent audit and integration
    → concrete supplier/custody gate-B qualification
    → separately authorized RW0-E live proof
```

Supplier/custody qualification can proceed as a **parallel read-only external evidence track**, but it should not yet cause Coordinator source, schema, provider, host, transport, or credential work.

The reconnaissance must still resolve several physical questions before implementation:

- whether terminal closure is one standalone program;
- whether normal and active-cancel terminal families belong in the same migration and writer;
- whether the next additive migration is `0008`;
- the exact terminal basis, row, result, graph, receipt, replay, and recovery family;
- how the current `RW0TerminalOutcomeV1` pure contract maps to durable rows;
- whether every cancellation branch can be causally proved offline without inventing live process facts;
- the exact boundary between terminal closure and later RW0-E source/custody mechanics.

Those are implementation-defining questions, so the next step is one final read-only mapping pass—not an implementation prompt.

## Codex handoff

Send this prompt to a **fresh read-only Coordinator Codex conversation**:

:chatgpt-content-reference{index="0"}[**RW0 post-P1 terminal-closure reconnaissance prompt**](sandbox:/mnt/data/Coordinator_RW0_Post_P1_Terminal_Closure_Reconnaissance_Prompt.txt)

**Attachments:** none.

The prompt requires Codex to use only the matching live Coordinator repository. It must not inspect Downloads, prior checkpoint packages, `/tmp` evidence, chat history, or another snapshot.

It compares three program shapes:

1. standalone durable terminal closure;
2. terminal closure as the first checkpoint of a combined terminal-to-RW0-E program;
3. live supplier/contact work before terminal closure.

The provisional recommendation is the first, but Codex must verify or overturn that from current repository evidence.

A READY result must freeze:

- the program shape;
- the authority split;
- the exact durable family;
- migration and application-generation treatment;
- normal and cancel branch scope;
- transaction, replay, and recovery ordering;
- connected artificial-offline proof;
- exact touched surfaces;
- validation and independent-audit acceptance criteria.

It must not return another generic recommendation for more reconnaissance.

Expected successful disposition:

```text
RW0_POST_P1_TERMINAL_CLOSURE_RECONNAISSANCE_READY
```

After that report returns here, the next handoff will be a direct source/schema implementation prompt to the same Codex conversation.

```text
Prompt bytes:
16,728

SHA-256:
d0f990241d82a3aaedb5dc7bf353e8914eada92f026ec0d7ee5b3eda195f982f
```

:chatgpt-content-reference{index="1"}[Handoff identity record](sandbox:/mnt/data/Coordinator_RW0_Post_P1_Terminal_Closure_Reconnaissance_Check.json)

No new Project snapshot is requested. The PR #17 squash checkpoint is now the current Coordinator baseline.

### Sources

- rw0-c2-p0-p1-pr17-squash-source-checkpoint.zip[Integrated Coordinator PR #17 checkpoint](sandbox:/mnt/data/rw0-c2-p0-p1-pr17-squash-source-checkpoint.zip)
- `source/AGENTS.md:58–62, 91–114`
- `source/.docs/rw0-c2-physical-p0-p1-implementation.md:274–307`
- `source/.docs/rw0-c2-first-live-proof-posture.md:187–218`
- `source/.docs/rw0-remote-worker-contact-phase-entry.md:304–342, 417–438, 472–527`
- `source/.docs/rw0-b1-pure-phase-values.md:16–27, 148–204`
- `source/src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:746–760, 1055–1073, 2190–2240`

**Confidence:** integrated baseline **0.999**; next-program sequencing **0.97**; exact terminal physical design remains the reconnaissance obligation.
