ENGAGEMENT ENVELOPE

CURRENT STATE
- The preceding RW0-C2 P0→P1 architecture program is merged, integrated, and
  closed.
- Authoritative integrated Coordinator baseline:
  - repository: `/Users/ds/Repositories/Governed Execution Coordinator/`
  - `trunk_dev`: `61d0330aba1160f7f5e7d9c541a325222d1c61e5`
  - sole parent: `4519630d0db967066beb21b4ace5004e76827716`
  - exact tree: `44c7dee402d46b3e16dc389ae0824b4297dfec1f`
  - source paths: `315`
  - merged PR: `#17`
- The live checkout may still be on the preserved topic commit
  `3263bc25e4a9f5558065fc7eb68125029d578bda`; that commit has the same exact
  source tree. Do not switch branches merely to inspect source. Git/ref truth and
  source-tree truth must be recorded separately.
- P0 and P1 are current private artificial-offline durable implementations.
  P0 records admission history without current authority. P1 records one
  five-branch decision and creates an acceptance fact only on acceptance.
  Neither is RW0 terminal truth or executable permission.

RECIPIENT
- Fresh read-only Codex reconnaissance conversation for the Coordinator repo.
- The parent may use bounded read-only explorer subagents if available, but the
  parent must reconcile all findings and return one report.
- No implementation or independent audit is part of this engagement.

ATTACHMENTS
- None.
- Do not inspect Downloads, prior checkpoint ZIPs, `/tmp` evidence roots, pasted
  chat history, or another repository snapshot.
- Use only the exact matching live Coordinator repository checkout and its Git
  objects/refs as current truth.

AUTHORIZED EFFECTS
- Read-only repository and Git inspection.
- Read-only source, docs, tests, SQL, schema, config, and committed-history
  inspection.
- Read-only static scripts outside the repository only when necessary to map
  source/test/schema dependencies.
- No test execution, imports, SQLite execution, network, fetch, branch switch,
  worktree creation, source edit, formatting, cleanup, staging, commit, push,
  PR, merge, artifact generation, or publication.

EXPECTED RETURN
- One complete operative reconnaissance report inline.
- No external report artifact, ZIP, freeze package, checkpoint, or Downloads
  file.
- One primary verdict and one recommended next program.
- Exact repo-relative path:line evidence for material claims.

PROJECT SNAPSHOT
- No new snapshot is requested by this reconnaissance. The current Project
  baseline is the verified PR #17 squash checkpoint at commit
  `61d0330aba1160f7f5e7d9c541a325222d1c61e5`, tree
  `44c7dee402d46b3e16dc389ae0824b4297dfec1f`.

NEXT ACTION
- Return the report to ChatGPT.
- If READY, ChatGPT will issue a direct source/schema implementation prompt for
  the selected program to the same Codex conversation.
- Do not insert another standalone semantic-contract or general-design tranche.
- If not READY, identify the single minimum authority/operating-model decision
  that blocks implementation.

OBJECTIVE

Perform the final broad physical-architecture mapping pass after integrated
P0→P1.

Determine the next Coordinator architecture program by comparing:

A. `STANDALONE_RW0_TERMINAL_OUTCOME_PHYSICAL_CLOSURE`
   - implement the separate durable RW0 terminal-outcome owner over the current
     P0/P1 artificial-offline composition;
   - preserve all live worker, supplier, custody, transport, ES, Git-effect, and
     publication boundaries as future.

B. `TERMINAL_OUTCOME_FIRST_CHECKPOINT_IN_ONE_TERMINAL_TO_RW0_E_PROGRAM`
   - use durable terminal outcome as the first saved/reopened checkpoint;
   - continue in the same implementation candidate into concrete first-live
     supplier/custody and worker-contact mechanics.

C. `RW0_E_SUPPLIER_OR_CONTACT_FIRST`
   - select a concrete enrollment/custody supplier or live worker-contact path
     before terminal-outcome persistence.

The provisional engineering judgment is:

- A is the likely critical path.
- Concrete first-live supplier/custody conformance is a parallel, external,
  read-only qualification track until a supplier passes gate B.
- B risks coupling an internal durable fact owner to an unselected platform and
  live-effect boundary.
- C appears to violate the current first-live prerequisite order because the
  repository already freezes terminal closure as a required RW0-C durable fact
  while supplier gate B blocks live source/runtime work.

Verify or overturn that judgment from current repository evidence. Do not accept
it merely because this prompt says so.

This reconnaissance must end either:

1. READY for direct implementation of one coherent program; or
2. PARTIAL/BLOCKED with one exact unresolved authority or data-model decision.

Do not recommend another broad reconnaissance after this one.

GOVERNING REALITY TO RECONCILE

The report must distinguish:

1. **Integrated current contracts**
   - PR #17 source and Git truth;
   - P0 scope-admission family, receipt, replay, and recovery;
   - P1 five-branch decision family, acceptance-only fact, replay, and recovery;
   - RW0-C1 durable phase/evidence;
   - Section 41/C1/V22 post-D2 continuation;
   - RW0-B1 pure phase-entry and terminal-outcome values/relations;
   - D1/D2 artificial-offline process/capsule/evidence proofs.

2. **Historical status text**
   - candidate-stage, local-commit, prepublication, and earlier “future”
     statements that are intentionally retained as stage snapshots;
   - do not treat those historical paragraphs as current implementation facts
     when later owner-local successors exist.

3. **Current reopened seams**
   - no durable RW0 terminal-outcome owner;
   - no concrete live enrollment/custody supplier or gate-B evidence;
   - no live provider/worker or physical remote contact;
   - no ES route, reliable submit adapter, result ingest, or cancellation
     reconciliation;
   - no product Git-effect handler, publication executor, service, queue,
     scheduler, or autonomous loop.

4. **Strategic target**
   - Coordinator owns durable semantic progression and terminal closure;
   - external standing policy owns grants;
   - source owners own physical observations;
   - ES owns execution admission/runtime/lifecycle/cancellation/results;
   - Git owns object/ref truth;
   - evidence, reports, model output, Bridge, IM, MA, and CP are not hidden
     program truth.

REQUIRED INSPECTION

Read completely where named as an owner, and inspect all directly dependent
source/tests:

Repository guidance and composition:
- `AGENTS.md`
- `README.md`
- `.docs/architecture.md`
- `.docs/authority-boundaries.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/software-development-progression-boundary.md`
- `.docs/durable-state-model.md`
- `.docs/worker-execution-boundary.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`

Current P0/P1 and C2 owners:
- `.docs/rw0-c2-physical-p0-p1-implementation.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-scope-admission-provisioning-contract.md`
- `.docs/rw0-c2-first-live-proof-posture.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-b2-wire-protocol.md`
- `.docs/rw0-b2-capability.md`
- `.docs/rw0-d1-offline-process-and-capsule-spine.md`
- `.docs/rw0-d2-offline-evidence-and-review.md`
- `.docs/section41-post-execution-proposal-family.md`

Physical source and migrations:
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_c2_progression_contracts.py`
- `src/ge_nwp_coordinator/_rw0_c2_progression_plan.py`
- `src/ge_nwp_coordinator/_rw0_c2_progression_rows.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c2_progression.py`
- `src/ge_nwp_coordinator/_rw0_c2_scope_admission_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c2_scope_admission.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py`
- `src/ge_nwp_coordinator/_sqlite_section41_post_execution_proposal.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
- `src/ge_nwp_coordinator/sqlite_writer_session.py`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- all seven current SQL migrations and the generated schema snapshot
  `schemas/sqlite/coordinator-state-v1.sql`.

Direct tests and assurance:
- all `tests/test_rw0_b1_*`
- all `tests/test_rw0_c1_*`
- all `tests/test_rw0_c2_*`
- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- `tests/test_sqlite_rw0_c2_scope_admission.py`
- `tests/test_sqlite_rw0_c2_progression.py`
- `tests/test_sqlite_rw0_c2_migration_0006.py`
- `tests/test_sqlite_rw0_c2_migration_0007.py`
- `tests/test_sqlite_rw0_c2_connected.py`
- directly affected Section 41, D1/D2, transaction-controller,
  writer-session, migration, architecture, operating-model, and
  software-development-boundary tests.

Inspect imports, exact-source/hash/status consumers, migration inventories,
schema counters, examples/fixtures, and package exports that a physical terminal
owner would affect. State where inspection stopped.

QUESTIONS THAT MUST BE FROZEN

1. Program shape
- Is terminal-outcome persistence one standalone implementation program?
- Should it include both normal and active-cancel physical families now?
- If a checkpoint split is needed, define the internal checkpoint and prove it
  does not harden a partial public or durable contract by inertia.
- Decide whether combining live supplier/contact is necessary or unsafe.

2. Authority split
- Identify the single durable terminal-outcome writer.
- Preserve the P1 decision as the prior decision fact, not terminal truth.
- Preserve the immutable acceptance fact without mutation or replenishment.
- Keep source reconciliation, process exit, teardown, validation, review, model
  proposal, and Git effects as distinct facts.
- State which facts are Coordinator-owned, source-owned, ES-owned, Git-owned,
  and externally authorized.

3. Exact semantic scope
- Reconcile `RW0TerminalOutcomeV1` and its four pure shape validators with the
  remote-contact owner.
- Decide the supported physical branch inventory:
  - normal accept;
  - normal repair;
  - normal replan;
  - normal terminal reject;
  - normal block;
  - active cancel reconciled → cancel;
  - active cancel unresolved → block;
  - pre-effect cancel basis unusable → block.
- If any branch must remain unimplemented, identify why, version the boundary,
  and explain why that does not create false terminality or migration inertia.

4. Durable family
Freeze the proposed closed physical family at field/identity level:
- command or selector;
- immutable terminal basis/context;
- terminal-outcome row;
- evidence/reconciliation/mismatch bindings;
- result projection;
- mutation graph/roles;
- receipt;
- readback;
- replay;
- collision and alias routes;
- recovery selector and exact three-way classifier.

Do not write SQL, but be precise enough that implementation does not need
another semantic-design tranche.

5. Migration and compatibility
- Decide whether terminal closure requires additive migration `0008`.
- If not, identify the exact existing canonical representation and prove that
  reuse preserves ownership and replay/recovery.
- Preserve migrations 0001–0007 byte-for-byte unless a source-grounded
  contradiction makes that impossible.
- Decide application-generation treatment.
- Define historical-prefix compatibility, old-binary refusal, partial/unknown
  schema refusal, zero seeds, immutable guards, indexes, catalog checks, and
  generated schema/test updates.

6. Transaction and currentness
Freeze the exact fenced transaction order:
- receipt-first replay;
- protected disclosure/current posture;
- immutable prior decision and acceptance-fact read;
- current program/work/selection/effect/delivery heads and global stop;
- evidence/reconciliation/mismatch verification;
- branch/shape/binding validation;
- route and collision probes;
- immutable writes;
- current-head CAS or proof that no mutable-head update belongs here;
- checked readback;
- receipt-last;
- capability invalidation;
- one commit attempt;
- uncertain-commit recovery.

Decide what is historical immutable evidence and what must be sampled freshly.
Do not make terminal replay depend on later mutable heads.

7. Normal versus cancel sequencing
- Determine whether the current artificial-offline composition can causally
  exercise every terminal branch without introducing live worker/contact
  mechanics.
- For cancel branches, map the exact existing C2B cancel decision/effect,
  request/ack/signal/exit/teardown/reconciliation owners and identify what is
  implemented versus target-only.
- Do not infer process exit, cleanup, cancellation, or terminality from one
  another.
- Do not create a second C2B cancel or block decision where the target forbids
  it.

8. Connected proof
Define the smallest real-owner artificial-offline connected proof:
- existing P0 admission;
- D1/D2;
- Section 41 A;
- C1 rank 15 B;
- V22;
- P1 decision;
- terminal-outcome transaction;
- checked readback/replay/recovery.

For each terminal branch, identify the exact source evidence or controlled
variation and the expected durable rows/effects. No live supplier, network,
provider, ES route, Git effect, or product database is allowed in this proof.

9. Validation and audit acceptance
Specify:
- first substantive checkpoint;
- direct causal controls;
- branch matrix;
- stale/current-head and global-stop controls;
- acceptance-fact binding and nonmutation;
- cancel/reconciliation/mismatch controls;
- CAS/readback rollback;
- receipt-last and one-commit-attempt faults;
- before/after/lost-return/cleanup uncertainty;
- collisions, aliases, partial/foreign/malformed families;
- second replay after later head changes;
- migration/schema tests;
- connected proof;
- focused selector;
- selector-free collection and FULL;
- source/mode preservation;
- independent artifact-audit obligations.

10. Live-entry boundary
- Identify the minimum repository facts terminal closure would make available to
  a later RW0-E live proof.
- Identify what still requires a concrete gate-B supplier.
- Do not choose a supplier, host technology, provider, credential format,
  transport, Codex protocol, ES adapter, or deployment mechanism here.
- State whether supplier qualification can proceed in parallel as a separate
  non-mutating external evidence track.

11. Touched surfaces and status
Produce the exact expected source/doc/test/schema surface map.
Identify current status passages that are historical versus current and the
direct assurance consumers that implementation would need to update.
Do not propose a generic status rewrite.

12. Non-goals
At minimum:
- no live enrollment/custody supplier;
- no live worker/provider/Codex invocation;
- no physical network/remote contact;
- no ES/Bridge route;
- no Git effect, push, PR, merge, or publication executor;
- no service, queue, scheduler, reconciler, or autonomous loop;
- no terminal outcome used as executable permission;
- no guard replenishment or mutation;
- no public `StateStore`/package API unless current source proves it mandatory.

VERDICT

Return exactly one:

- `RW0_POST_P1_TERMINAL_CLOSURE_RECONNAISSANCE_READY`
- `RW0_POST_P1_TERMINAL_CLOSURE_RECONNAISSANCE_PARTIAL_<PRECISE_REASON>`
- `RW0_POST_P1_TERMINAL_CLOSURE_RECONNAISSANCE_BLOCKED_<PRECISE_REASON>`

READY requires all of the following:

- one selected program shape;
- frozen authority split;
- implementation-ready durable family;
- migration decision;
- transaction/replay/recovery order;
- normal/cancel scope decision;
- exact touched surfaces;
- validation and independent-audit plan;
- no unresolved operating-model decision that implementation would have to
  invent.

REQUIRED INLINE REPORT

Return:

1. primary verdict;
2. authenticated checkout and inspection boundary;
3. current-contract / integrated-fact / historical-status / reopened-seam /
   strategic-target ledger;
4. comparison of program shapes A/B/C;
5. selected program and rejection rationale for the alternatives;
6. exact authority table;
7. exact proposed durable family and identity dependency order;
8. migration/schema decision;
9. normal and cancel transaction/replay/recovery algorithms;
10. connected proof and causal-control matrix;
11. touched docs/source/tests/schema and direct consumer map;
12. validation/audit acceptance plan;
13. live-entry boundary and parallel supplier track;
14. risks, assumptions, open observations, and nonclaims;
15. exact expected next recipient and action.

Do not create an implementation prompt, edit the repo, run tests, or generate an
external artifact.
