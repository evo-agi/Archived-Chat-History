RW0 NORMAL TERMINAL CLOSURE — MINIMAL SECOND-PHASE PREFIX AND FIFTEEN RESIDUAL CLOSURE

This is the sole complete operative replacement mandate. Continue the SAME neutral
independent reviewer from RT, rt-3804c351df. Candidate tree, QtcM policy, product
contracts, test assertions and acceptance requirements do not change. Do not restart
runner design, regression qualification, source-history mapping or implementation.

RT's C1B03, C1B04, C2A19, C2B11 and C2B13 closures are supported at their stated
bounded scopes. RS/RC/W and earlier mapped proof retain their exact scopes. W v5's
four representatives, exact99, direct60 and selector-free FULL9568 remain supported
historical independent executions; they are not RT runs and are not retrospectively
run under later audit helper revisions.

EXPLICIT WORK-ORDER DECISION:
The next critical path is one same-store SECOND PHASE PREFIX through actual private
owners. It is not automatically a second complete D2/Section41/C1/V22/terminal chain.
Use that minimum parent for the ten remaining route probes and three SQL-constraint
rows. Build a complete second source-coherent chain only where C1B05 or C2A20 truly
requires it. This changes fixture sequencing only; no requirement is reduced.

EXPLICIT REPORTING CORRECTION:
RT's uploaded ZIP is exactly 75,808,728 bytes / SHA-256
c4d689950dbd1d4424ea56ed048d141333f20d8f92db568dfd9625026b921cf7.
It contains 179 regular members: 178 self-excluding MANIFEST rows plus MANIFEST.json,
with 85,560,674 expanded bytes. The earlier inline statement "181 members" is a
nonblocking count error. Preserve the package and correct the successor accounting;
do not alter RT or invent two missing members.

ENGAGEMENT ENVELOPE
CURRENT STATE: Exact 327-file candidate tree
4691af58ae0ee3107b4e2e9b6b1508032944e357 remains uncommitted/unaccepted.
Fifteen substantive IDs remain. Preserved regression and scoped closure evidence are
available under the explicit carry-forward rule.
RECIPIENT: SAME neutral independent reviewer that produced rt-3804c351df. Expected
host cwd /private/tmp/rw0-audit-entry.daLWIE. NOT the implementation writer.
ATTACHMENTS: NONE required. Use the exact retained RT/A/B/C bindings below; RT carries
RS once, which carries RC/W/M/U/T/S/R.
AUTHORIZED EFFECTS: Inert artifact inspection; audit-owned same-store fixture,
observer, registration and ledger work; unchanged-candidate execution through current
WA1 plus exact QtcM; protected audit evidence only. No candidate/policy/runtime/
repository/publication change.
EXPECTED RETURN: One cumulative disposition with exact closed/open IDs, fixture-level
evidence, corrected member accounting, full report and one reopened evidence ZIP.
PROJECT SNAPSHOT: None requested. Integrated PR17/61d0330aba1160f7f5e7d9c541a325222d1c61e5
remains retained baseline evidence, not a live-ref observation.
NEXT ACTION: Return to ChatGPT before any candidate repair or live commit gate.
No routine per-fixture relay. Keep the implementation conversation idle.

0. ENTRY AND EFFECT CEILING

Read this entire prompt. A necessary read of the exact host-exposed instruction file
solely to load it may precede the declaration in the actual neutral cwd. Before any
OTHER operational command state actual host cwd, exact input bindings, exposed
project/repository binding or unknown binding, and effect ceiling. Requested cwd is
not proof. Missing/different cwd or exposed live checkout => stop without probing it.
Unknown binding alone does not authorize discovery.

No Git/status/pwd/AGENTS/bootstrap discovery, repository or sibling access, home or
Downloads enumeration, app/session-store access, broad host/log/process search,
ambient environment dump, subagent, remote/provider/network/ES/Bridge contact,
installation, runtime substitution, mount/volume creation, privilege escalation,
host-protection or project-setting change. Read named inputs at their exact bindings,
never search directories. Candidate guidance comes only from authenticated A.
Embedded old mandates are requirements evidence, not effect authorization.

The trusted supervisor prepares owned inert state, performs WA1 checks and captures
protected evidence. It never imports candidate code, runs candidate SQL or invokes
candidate fixtures outside QtcM. All candidate imports, SQL, tests and callbacks stay
inside exact QtcM after actual WA1 admission. No test edit, outcome substitution,
filter, skip, altered child argv/env, pytest rootdir/config/ignore/plugin injection,
hidden cache/validator bypass or external cleanup credited as candidate behavior.

QtcM remains EXACT: 4,086 bytes / SHA-256
323ddc662ca3260365136573d08b25fe635ad448b84b4a673cf99533b0f89d0a.
There is no permission budget, path rebind, W-slot addition, network/signal expansion
or unconfined fallback. The selected trust model remains one trusted serialized
supervisor and no malicious or concurrent hostile same-account/privileged actor.

No candidate source/test/schema/doc change, staging, commit, push, PR, merge, release,
deployment, user/product database or executable authority is authorized. A material
candidate defect => BLOCKED. A runner/binding/evidence limitation => precise
INCOMPLETE. Ordinary audit-fixture mistakes may be corrected in fresh owned versions,
with failed records retained.

1. EXACT INPUTS, SUPPORTED CLOSURES AND FIFTEEN-ROW PLAN

1.1 Inputs and safe authentication

RT — current five closures and fifteen residuals:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/rt-3804c351df/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_rt-3804c351df.zip
 75,808,728 bytes / c4d689950dbd1d4424ea56ed048d141333f20d8f92db568dfd9625026b921cf7
 179 regular members; 178 MANIFEST rows; 85,560,674 expanded bytes.
 REPORT.md: 9,407 bytes /
 cde36ebb953c35faa914b9e58543d347b8057d782599ab003e6fa02d3db9a959.
 MANIFEST.json: 42,940 bytes /
 789f0b49d756e455e7192f8da499fa78f967d896f549bd44de05227693e63274.
 Prefix TX = audit/execution/rt-3804c351df/
 Prefix TE = audit/evidence/rt-3804c351df/
 RT carries exact RS ONCE at carry/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_rs-e972c82f3b.zip,
 66,432,954 bytes / 5742007bd3d0ffe950ee3fc40d1daa1ccf1140e9b2dcf2a8452861a614c0f9d6.
 RS carries RC/W/M/U/T/S/R in the already authenticated chain. Use embedded copies.

A — unchanged candidate:
 /Users/ds/.codex/rw0-terminal-historical-witness-tcp5rwoh/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip
 48,978,087 bytes / 6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42
 573 members / 572 covered; 183,558,511 expanded bytes.
 package/member-manifest.json: 123,205 bytes /
 049139eaac16a03b36952faa703c992f5ef13adad44807873921af817e7b8e43.
 evidence/IMPLEMENTATION_REPORT.md: 19,549 bytes /
 c52141d0fcf15701496c4dec18133361a78b8f043796078340e24eed4bdae2d5.

B — inert original implementation requirements:
 /Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt
 38,100 bytes / 9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f.
C — inert S01/A03 requirements:
 /Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt
 29,145 bytes / 7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd.
A inputs/mandate.txt remains the historical-admission/witness amendment. Read all
requirements as evidence; do not execute superseded implementation directions.

Authenticate safe normalized relative regular unencrypted names, bounds, Unicode/
casefold and prefix safety, and complete self-excluding size/hash/CRC/numeric-mode
coverage. Cache verified ancestors; do not rebuild unrelated history. Missing exact
input => name it, not a directory or namesake search. Programs are inert until separately
inspected and authorized as new audit-owned helpers.

Reauthenticate all 327 source payloads and rebuild tree
4691af58ae0ee3107b4e2e9b6b1508032944e357 without Git. Preserve 326 OS0644 rows and
one OS0600 tests/test_c2b3_private_atomic_program_initialization.py; all Git100644.
All original endpoints remain immutable. No 0009, product API, changed test or mode.

1.2 Supported current evidence; do not restart it

Preserve:
- W v5 representatives4, exact99, direct60 and selector-free FULL9568 with exact IDs,
  phases, source captures and three permitted B2c FULL warnings;
- RC C1A01–03 and WA-C01/02;
- RS C1A04, C2A09, C2A15–17, C2B12 and C3A04;
- RT C1B03, C1B04, C2A19, C2B11 and C2B13;
- completed C4 and earlier mapped constructor/calendar/replan/source/connected proof.

RT's five closures retain these limits:
- C1B03 binds constructor role/cardinality/order and historical graph/receipt digest
  recomputation; no free persisted role-list column is claimed.
- C1B04 binds an FK-valid receipt decision alias to the reconstructed plan. Its additional
  conflict reason is source-grounded supplemental evidence where the raw result retained
  only the TerminalConflictV1 type.
- C2A19 is a synthetic complete FK-valid family with one context self-digest defect,
  not a normal-writer commit.
- C2B11/C2B13 are bounded in-process seam faults with real hit counts, no movement and
  fault-removal positives, not hostile-state or all-cleanup proofs.

RT's nine new C3 FK negatives carry as partial proof. Do not repeat them or RS's seventeen
SQL cases unless a specific missing relation requires the same setup. Correct the outer
member count in new ledgers/reports while preserving RT unchanged.

1.3 Exact fifteen open IDs

Stable56 history remains fixed. The only mandatory-open IDs are:
 C1B05
 C2A04 C2A05 C2A06 C2A07 C2A08 C2A10 C2A11 C2A12 C2A13 C2A14
 C2A20
 C3A02 C3A03 C3A05.

Keep three evidence levels distinct:
L1 literal DDL constraint; L2 individually checked/self-digest-valid and FK-valid
synthetic inconsistent family; L3 legitimate complete source-coherent history/winner.
L1/L2 cannot replace L3. A second full source chain is not a default prerequisite for
L1/L2. Conversely, never omit an actual owner prerequisite from L3.

1.4 Minimum same-store second phase prefix

The existing RT C1B04 fixture already supplies a distinct, owner-built P0, program
initialization, author effect and checked P1 decision in the same managed store. It does
not supply a second phase. Build one audit-owned SAME-STORE PHASE-B prefix:

1. Use the actual private pre-execution proposal/disposition and `_establish_rw0_phase`
   owners on the existing location. Derive distinct typed identities bottom-up. Do not
   call initialize_database again, attach/transplant another database, reuse a one-shot
   helper's new location, raw-insert the phase or stub an owner success.
2. Use the second subject's existing program/work/author-effect state and real checked
   selection/disposition prerequisites. Record exact guarded writes, checked read/replay/
   recovery where supported, and all phase/program/work identities.
3. Preserve the original selected terminal chain. Phase B is an audit prerequisite for
   L1/L2 synthetic state, not a claim of a second D2/Section41/C1/V22 terminal history.
4. Save and reopen a substantive Phase-B checkpoint before expanding routes/uniques.
   An actual owner rejection must retain command/state/error/source and must not be
   generalized into an architecture prohibition.

1.5 Ten physical first-match route controls

Use one original valid command A and fresh states containing synthetic FK-valid B rows.
Build B context/outcome/result/receipt rows with real valid parents and valid self-digests.
For each case, make only the named A selector collide while every earlier A route is
absent. Invoke the real terminal writer path; observe actual `_one` calls without faking
returns. Require exact earlier misses, named first non-None checked row, outward
`TerminalConflictV1` reason `route_collision`, unresolved recovery, no row movement and
a fault-free positive.

Finite target matrix:
- C2A04 context.p1_decision_ref=A; context ref/mutation/phase distinct B.
- C2A05 outcome.outcome_value_ref=A; B context/phase/decision.
- C2A06 outcome.phase_basis_ref=A; parent context phase=B; outcome ref/decision distinct.
- C2A07 outcome.decision_ref=A; parent context/outcome phase and decision B.
- C2A08 result.result_ref=A; parent context/outcome B.
- C2A10 receipt.receipt_ref=A; parent context/outcome/result B.
- C2A11 receipt.mutation_ref=A while B context mutation is distinct.
- C2A12 receipt.family_route=A with all earlier selectors distinct.
- C2A13 receipt.phase_basis_ref=A while B context/outcome phase is distinct.
- C2A14 receipt.p1_decision_ref=A while B context/outcome decision is distinct.

These are L2 physical collision controls, not normal-writer commits. Keep actual FKs and
immutable guards enabled; do not fake occupancy or disable checked-row validation.

1.6 Remaining SQL uniqueness controls

First produce a literal inventory mapping every C3A02/C3A03/C3A05 constraint to carried
RS/RT evidence or a genuinely missing case. Then close only the missing non-primary
unique routes using phase B/P1 B and fresh unoccupied parents:

- context: UNIQUE mutation_ref, phase_basis_ref and p1_decision_ref;
- outcome: UNIQUE context_ref, phase_basis_ref and decision_ref;
- receipt: UNIQUE mutation_ref, family_route, phase_basis_ref, p1_decision_ref,
  context_ref, outcome_value_ref and result_ref.

Each negative has one paired valid insertion from the same starting state, enabled FKs
and guards, exact SQLite error/site, savepoint rollback and nonmovement. Where composite
uniqueness is logically redundant with a primary key, close it by exact DDL implication
and a reachable primary-key control; do not demand an impossible isolated duplicate.

1.7 C1B05 finite association closure

Inventory the actual `_predecessors` and terminal-plan associations. Mark the four
carried `source3` cases as already covered: distinct V22 proposal ref, source invocation,
validation disposition and review disposition. Enumerate only remaining P0/phase/
Section41/C1/V22/P1 relations. For each remaining relation, independently reseal the
intended value before the relevant owner seals its dependent value, reach the real checked
owner/projection/plan seam, retain exact first rejection and nonmovement, and provide a
source-coherent positive. Do not use table counts or digest strings as ownership proof.

1.8 C2A20 legitimate foreign winner

After Phase B and the L1/L2 work, build a complete second source-coherent chain only if
required: distinct phase, Section41 proposal family, C1 rank15 admission, V22 projection,
P1 and complete terminal family through real owners in the SAME store. Then prove:
- a complete foreign winner causes the original command's safe classification without
  disclosing the winner's committed result;
- original-route absence plus the required positive exclusion yields
  `definitely_not_committed` only at the exact complete boundary;
- partial, damaged or contradictory state remains unresolved; no fragment repair or retry.

Do not use donor database transplantation, raw owner rows, disabled constraints, a new
product multirun API or hidden validator bypass. If a real owner prerequisite blocks the
full chain, retain the exact failure and continue any independent ready C1B05 case.

1.9 Work order and stop discipline

1. Authenticate current source/layout and correct current ledger/member accounting.
2. Construct and checkpoint Phase B.
3. Close C3A02/C3A03/C3A05 and C2A04–08/C2A10–14 using the shared finite L1/L2 parent set.
4. Close the finite C1B05 relation inventory.
5. Build the minimum L3 second chain and close C2A20.

Save/reopen internal checkpoints after each group. Routine fixture/parser mistakes may be
corrected in new audit-owned versions without user relay. A practical limit must name the
exact predicate, attempted state, actual error and smallest restart point. One unfinished
L3 chain is not a reason to stop independent L1/L2 or association work. A real candidate
defect, source drift, failed admission, unsafe runtime or authority conflict still stops
the affected work with the correct classification.

2. SUBSTANTIVE REVIEW — THE EXPLICIT TWO-LAYER AMENDMENT

The earlier whole-operation zero-current-stop-SELECT criterion failed under the
old mandate. That blocked result remains true. The engineering decision is to
preserve mandatory shared storage safety, not to skip it to satisfy a terminal
history test. The current candidate is judged against the following amendment:

Layer 1: existing operational admission remains mandatory. Session/process/thread/
lease validity, database binding/custody, BEGIN IMMEDIATE, exact managed schema,
history/catalog/posture and invariants, writer ownership/fencing, and current
protected disclosure remain intact. The existing global_stop_current singleton
shape validator may read that current row only for managed-store validity.
Valid active/clear status, version, timestamp and directive identifiers must not
be compared with saved terminal stop or turned into current effect permission.
Denied/unreadable/malformed managed state may prevent disclosure or leave recovery
unresolved. It must not be misclassified as stale terminal history or definitely
absent original execution. No cache, successful-assessment stub, invariant-skip
flag, alternate connection/controller, or production validator weakening.

Layer 2: historical checked read, receipt-present replay and recovery use saved
full postimages/stop and checked immutable predecessors after admission/fencing.
The five current-head tables are not consulted during the historical operation.
Current-stop reads are permitted only at the existing shared invariant check,
not as a general table-read exemption or later semantic terminal query. Receipt
is first TERMINAL-FAMILY lookup, not first SQL statement. Exact original result,
time, graph, receipt, source associations, protected disclosure, immutable
acceptance binding, complete competing-winner/absence proof and uncertainty
classifications remain required. Historical operations do not require recording
permission or renewed acceptance-unclaimed eligibility. Fresh receipt-miss
recording retains actual current five-head/stop checks unchanged.

This amends only the overbroad current-stop-query requirement. It is not a waiver
of the constructor defect, five-head independence, disclosure, SQL grammar,
transaction safety, audit isolation, or other cumulative acceptance controls.
Verify the two owning documents state the distinction and preserve the old
failure as history; do not create another silent interpretation of either layer.

Inspect at minimum the complete changed witness module, changed tests and docs,
full terminal contracts/rows/plan/SQLite owner, and actual shared admission call
chain (not only wrapper names). Current anchors:
  sqlite_transition_transaction.py:2759–2779,4753–4773
  sqlite_migration.py:2477–2523
  .docs/rw0-terminal-outcome-physical-closure.md:177–220
  .docs/sqlite-operations-and-recovery.md:722–730.
Python basenames are under source/src/ge_nwp_coordinator/; docs under source/.

2.1 Independently test the repaired constructor and mutable aliasing

TerminalHeadWitness at _rw0_terminal_head_witness.py:48–96 must validate ordinary
construction, not only checked factories. Independently test valid direct/factory
triples for accept and replan and all five typed owner roles (8/9/41/9/8 fields,
valid nulls, self-digests). Exact bytes, outer tuples, dictionaries, keys and
scalar types precede hostile comparison/coercion. Bytes, full rows and compact
coordinates must match rather than silently replacing invalid supplied parts.

Require negative controls for the previous malformed type triple and b'{}'/empty
postimages, bytes/list/tuple/dict/string/int subclasses, bool-as-int, wrong arity,
missing/extra/reordered roles or fields, wrong schema/digest, noncanonical and
oversize bytes, and valid canonical bytes paired with DIFFERENT valid rows or
projections. Calibrate a shared/per-instance hostile equality counter, clear it,
and verify zero hostile calls per invalid construction. Preserve built-in
positives and process-control propagation.

Mutate caller-owned maps and separately returned maps, then re-read both views
and canonical bytes and run normal downstream verification. They must remain
checked and unchanged. No unvalidated object token/factory escape or recursion.
Do not demand security against arbitrary reflection/object.__setattr__; that is
not the selected boundary. Verify unchanged wire fields/schema/digest domains
and valid consumer behavior, including exact original P1 replan operands.

2.2 Independently prove complete-operation phase behavior

Use real private WriterSession read, receipt-present record/replay and recovery,
not just a terminal helper. Trace and attach observation/denial at the actual
acquisition/controller opener aliases and account for every operation connection.
The candidate observer labels the full managed wrapper; independently establish
which SQL is genuinely in _verify_global_stop_current_shape. A phase label alone
does not prove shape-only use or permit arbitrary managed-phase stop semantics.

Observe real unchanged validator, ownership-read and issuance/fencing functions;
observation wrappers must call the real function and return its actual result.
Do not replace admission with a successful assessment or patch the predicate
being proved. Capture connection, phase, table/column and allow/deny results.
Calibrate each attached authorizer with owned allowed and intentionally denied
queries. Trace acquisition separately, including any connection work before the
observer attachment, and prove it cannot hide a five-head/later-stop lookup.
A zero-callback claim at the wrong alias is invalid. Column callback counts are
not SQL-statement counts or a fixed product invariant.

Required current-byte controls:
- real fenced accept and replan commits, then coherent later movement of every
  head and valid active/clear stop fixtures; under the layered denial policy,
  exact read/replay/recovery preserve original result/time/witness/graph/receipt
  and acceptance facts without new terminal or protected-row movement;
- original absence with positive/negative old-execution exclusion; complete
  compatible and incompatible competing winners under that same policy;
- deny the ACTUAL managed-stop read during admission: safe operational refusal
  before protected terminal-family handling, recovery unresolved where the
  unchanged controller so classifies; no no-write mislabel as stale history,
  definite absence, hidden retry, committed result or protected disclosure;
- malformed actual stop row or real query-return tuple, with validators intact:
  integrity failure rather than ordinary currentness; fault removal restores
  valid operation; bound process-control behavior remains unchanged;
- fresh receipt miss reads all five actual heads and stop. Stale expectations
  conflict without writes; correctly expected valid changed stop follows the
  current normal-record rule without conferring executable permission;
- denied/expired/foreign/malformed disclosure, closed/stale/fenced session and
  unavailable managed store remain non-disclosing. Fresh recording permission
  stays separate from historical protected disclosure and stop shape.

All synthetic later states/fault seams must be described as such. Do not call
a direct fixture UPDATE a newly supported product operator transition.

3. COMPLETE CUMULATIVE A01–A18 REGISTER AND CAUSAL OBLIGATIONS

Review the entire baseline-to-current terminal change, not only the five-file
repair. Supply exact archive-relative source/doc/test/SQL coordinates, severity,
and evidence class for every row: contract/current code, inspected test design,
retained record, independent execution, inference or limit. Unchanged bytes and
prior passes do not automatically discharge current mandatory controls.

A01 Authority: exactly five private normal terminal facts, separate from P1
 decision/acceptance, standing-policy grants, source facts and executable
 permission. No cancel closure, live supplier/contact, ES/Bridge/Git effect,
 service/scheduler/autonomy or publication authority.
A02 Preservation: legacy terminal V1/four validators, P0/P1 meaning, WorkSpec,
 Decision Basis/command-digest v2, preassignments, D1/D2, generic receipt, public
 StateStore/package exports unchanged. Audit original shared catalog/controller/
 writer-session terminal integration even though this immediate repair froze it.
A03 Grammar/types: closed command/context/outcome/row/result/recovery/witness
 schemas, exact built-ins before equality, canonical UTF-8/JSON and duplicate
 rejection, bool-as-int, safe refs/digests/calendar time, budgets and null pairs.
 Include direct constructors, factory consistency and aliasing; resolve A03/O1.
A04 Identity graph: independent domains/acyclic preimages, four sibling refs and
 route, optional assertions bound in command digest but not preassignments,
 graph role/cardinality/order, self-digest exclusion and repeated-column equality.
A05 Original operands: original P1 command and private replan operand transient;
 complete checked predecessor association required. Missing/inconsistent private
 content cannot be reconstructed from a safe digest or yield false certainty.
A06 Source association: actual checked P0/phase/Section41 A/C1 rank15/V22/P1
 chain and validation/review/proposal/result-set/observation relationships;
 membership counts or digest strings do not independently establish ownership.
A07 Acceptance: bind existing immutable acceptance only for accept; never create,
 mutate or replenish it. Wrong/missing/foreign facts reject. Legitimate unrelated
 facts must coexist without preventing another allowed terminal branch. No
 historical acceptance-unclaimed recheck.
A08 Heads/stop: observed full five-row witness, source/adapters/digests/links,
 replan historical P1 postimages, fresh actual currentness and stop facts; prove
 the precise two-layer amendment, not the withdrawn zero-stop-read property.
A09 Transaction: existing fenced lease/capability/controller; receipt-first
 terminal lookup; one captured time; protected posture/source/current/route
 ordering; context/outcome/result readback, receipt last, capability invalidation,
 one commit attempt, rollback/cleanup uncertainty. No application-head/stop/
 decision/effect update by terminal closure.
A10 Read/replay: original complete result/time/graph/receipt and source/witness
 reauthentication; current protected disclosure with mandatory store admission;
 no five-current-head or later semantic stop query, cognition/process rerun,
 fresh recording permission or acceptance-eligibility requirement.
A11 Recovery: complete exact original family or exhaustive original absence and
 exclusion, or complete compatible winner, only. Partial/foreign/damaged/aliased/
 incompatible families unresolved. No winner result disclosure, hidden retry,
 fragment repair or durable private-template fallback.
A12 Error/cleanup: failed or malformed reads stay operational/integrity, valid
 actual drift stays currentness. Stale/closed/fenced sessions, pre/postcommit,
 applied-commit/lost-return and cleanup uncertainty, KeyboardInterrupt/SystemExit/
 GeneratorExit propagation at the actual fresh/read/recovery/cleanup seams.
A13 Schema/admin: four STRICT immutable normal-only tables/eight guards;
 timestamp grammar, FK/unique/composite links/phase/decision/route occupancy,
 nullable pairs, blob bounds, zero seeds, current catalog/checksum/generation 2;
 exact fresh/prefix migration and old-binary/obsolete-0008/partial/unknown refusal.
A14 Connected normals: actual preseal source variations through real P0/D1/D2/
 Section41/C1/V22/P1/terminal owners; five distinct normal positives and detached
 negative; read/replay/recovery and no forbidden contact or protected-row change.
A15 Docs/assurance: cumulative current-versus-historical status, explicit amendment
 and private scope; fixed source/hash/AST/import/schema consumers and predecessor
 reconstruction retained; no dynamic oracle, skip/xfail or broad guard stripping.
A16 Privacy/artifacts: complete postimages remain safe owner metadata; no private
 replan text, raw capsule/prompts/process results, handles/PIDs/credentials in
 terminal rows or unsafe errors. Grammar review plus independently observed
 canaries; classify raw-index metadata, checkpoints and failed artifacts.
A17 Retained evidence: exact input/source/patch/commands/env/observer outputs/
 JUnit/IDs/warnings/captures and overlapping counts; limits in section 4 below.
 No writer record or causal-register label is independent execution.
A18 Independent validation: reached current-source causal probes and direct
 suite, independent SQL/admin controls, selector-free collection/FULL completed
 with exact IDs, outcomes, warnings and source-mode preservation. No live-state
 or production-readiness inference.

The following controls remain mandatory, including previously unfinished ones:

(a) S01 full-witness family: for EACH role, check complete field capture, valid
 nullable values, supported maximum witness bound, bad owner self-digest, valid
 self-digest with wrong immutable predecessor, wrong owner/link, and actual fresh
 head movement versus changed caller expectations. Use fully resealed synthetic
 histories so owner/context/outcome/result/graph/receipt digests are internally
 valid and the real relationship predicate is reached. Pair every resealer with
 a valid family built the same way. Restore ordinary verification for the actual
 read/replay/recovery. Prior program-only evidence is not five-role proof.
 No truncated witness, v1 fallback, desired-row synthesis or current-row backfill.

(b) Source/operand/acceptance: fully resealed detached validation, review,
 source-invocation and proposal associations, including a DISTINCT forged V22
 proposal reference rather than only a proposal digest; wrong/missing/foreign
 acceptance; LEGITIMATE unrelated acceptance-fact coexistence; inconsistent
 private replan content sharing a claimed safe identity across record/read/
 replay/recovery; no new process or private-text persistence. The single-chain
 fixture's inability to construct an unrelated fact is not proof of impossibility.
 Build coherent independent synthetic state through checked owners, or document
 exact invariant proof and the remaining limitation. Do not credit an incoherent
 split-reader or early FK/digest failure as the intended relationship test.

(c) Disclosure/recording: all selected finite posture predicates, including
 positive, denied, expired, malformed, foreign-bound and absent protected subject;
 old-execution-excluded True/False; truthful claimed False/None after accepted
 P1. Fresh write needs recording AND disclosure, historical operations disclosure
 only; command reuse/assertion mismatch cannot disclose a protected result.
 Complete the expired/malformed/foreign/protected-absence matrix rather than
 inheriting earlier positive/negative permission examples.

(d) Physical routes: derive all original occupancy routes from the checked
 code (the preceding audit identified 17). Seed EACH route physically in a
 separate owned coherent scenario, with valid positives and relevant partial,
 foreign or damaged family states. Mocking query return values alone is not
 physical occupancy evidence. Check exact/winner/absence classifications and
 no winner disclosure or retry. If a route is not representable under an owner
 invariant, prove that with exact schema/contract and record the scope; do not
 invent an invalid row as a legitimate winner or silently drop the obligation.

(e) Transaction and error matrix: faults after each of the four inserts,
 result/receipt readback, receipt-last boundaries, precommit rejection,
 one applied commit with lost return, postcommit and recovery cleanup uncertainty;
 stale lease/issuance, closed and fenced sessions; actual denied SELECT versus
 malformed selected rows across current owners; all three process-control
 exceptions at meaningful fresh/read/recovery/cleanup seams. Assert target
 rows, committed bytes, protected-state nonmovement, and actual injection hits.
 No hidden second commit or automatic retry.

(f) F01/O1 regression: independently exercise raw SQL and row construction,
 not only planner success. Use otherwise valid parent/related state, paired
 valid inserts, independent negative self-digests and the repaired existing
 _time owner. Cover invalid month/day/leap-century/year-zero/time overflow,
 canonical-format deviations, Unicode digits, embedded NUL/whitespace/nontext,
 NULL handling and valid year endpoints. Reach all three recorded_at columns;
 outcome has no timestamp. Verify failed predicates are zero/not permissive
 NULL and high-level invalid row/time behavior stays integrity/unresolved.
 Reproduce the old invalid-month predicate only in owned predecessor synthetic
 state as a grammar comparison, never claim an ordinary writer exploit.
 Recalibrate O1 independently before claiming no hostile equality calls.

(g) Five connected normals plus three unsupported cancel shapes and unsupported
 profile. Source variations occur BEFORE real artificial worker/checker/capsule
 sealing, not by relabelling passed evidence afterward. Use inspected fixtures
 for setup only; independent expected branches/facts/errors are required.
 Observe artificial local process/contact limits and privacy canaries.

Run bounded causal controls before a long FULL launch. Do not start/continue
FULL while a known material blocker already prevents acceptance. Independent
controls must state setup validity, actual reached seam, expected result/no-write
predicate, source identity and limits. Candidate tests passing are not separate
independent oracles. Any mandatory control not established remains explicit and
prevents complete acceptance unless an exact supported invariant makes the case
inapplicable; fixture difficulty alone is not such an invariant.

Independent SQL/admin expectations:
  after 0006: 68 tables / 122 triggers / 5 explicit indexes
  after 0007: 74 / 134 / 5
  after 0008: 78 / 142 / 5, application generation 2.
Execute all eight authenticated literals in disposable owned state. Preserve
pre-0008 object SQL/shape; check exact prefix upgrades, no seeds, immutable
update/delete guards, FK/unique/pair/profile/normal/blob/time constraints, and
refusal of old binary, original and S01-era 0008 checksums, old SQL with current
history, missing guard, foreign object and partial/unknown/checksum divergence.
No current schema/contract change, 0009 or product database upgrade is allowed.

4. RETAINED EVIDENCE AND INDEPENDENT VALIDATION

4.1 Reconcile the current writer records as DATA

Paths: evidence/validation/<direct|connected|focused|full>/, gate-summary.json,
phase-read-map.json, supersession-record.json and current source captures.
Require independent parsing of collection observer, execution collection,
setup/call/teardown records, explicit JUnit nodeid properties, actual launch/exit,
stdout/stderr as actually retained, warnings, and four complete source captures
per gate. Do not invent a separate stderr file for a combined log.

Expected current retained gates:
  direct: five complete modules / 60 cases / zero warnings
  connected: one complete module / six cases / zero warnings, inside direct
  focused: 126 complete modules / 8,266 cases / three known warnings
  FULL: selector-free / 9,568 cases / three known warnings.
All narrower sets must be included in FULL; totals overlap and do not add.

Ordered-ID SHA-256 uses UTF-8 JSON array, ensure_ascii=False,
separators=(',', ':'), with NO trailing LF:
 direct 229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467
 connected 81e14e3fa1b85a7be2ea6fafac85974839145bbcb6397e6da0bb1feeba060aac
 focused 419d37ff399689788123583f614a1d8b107ef712e2368ca179cd6e65fbec5104
 FULL 25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9.

All sixteen source captures have the same 105,550-byte envelope, SHA-256
0c0b4017371a798731a63825ac63922c361189e37f5a713f5c4f7ec06e9b32cb.
Require full row equality to the different canonical source-manifest envelope,
its embedded canonical hash, correct final tree and no extra/missing paths.

The retained direct JUnit phase maps report six operation connections, 60
managed-stop column callbacks and six intentional head-denial calibrations
for EACH accept/replan scenario. Independently parse the raw properties. Do not
substitute those counts for actual phase/call-chain verification, or label them
SQL-statement counts. Acquisition has separate test observations.

4.2 Known retained-evidence limits — do not silently fill them

The active external gate_observer source and a launch-bound helper digest are
not retained in the current outer ZIP. Old nested helpers cannot prove that
current code's identity. Writer records can be internally reconciled but their
observer's nonselecting implementation is not thereby inspected. The independent
runs below must use newly audit-authored, retained, inspected and calibrated
observers. Independent fresh evidence can establish current behavior; it does
not retroactively establish the missing writer helper.

The seven-case checkpoint has receipt/JUnit evidence and a different declared
tree 85c9fea24f4f74f358f9cc59a5d323d836a04041; it lacks a complete checkpoint
source payload here. Its historical save/reopen/source-binding claim stays
qualified and supplies no final-byte credit. Similarly, one retained patch
manifest per kind is not proof of two writer runs; independently reconstruct
current endpoint/patch identity rather than invent that history.

These are disclosed retained-evidence/process limits, not automatic production
findings. Determine their actual acceptance impact. Complete current independent
source/runtime evidence must not be replaced with writer claims. Any unmet
mandatory evidence requirement is INCOMPLETE, not a pass by wording change.
Preserve failed/superseded source/test results separately. The prior audit's
live-status/path probes and interrupted FULL remain historical limits.

4.3 Required independent execution gates

Under the explicit prospective section 1.3 scheduling amendment: after current
source inspection/reauthentication, exact final QtcM readiness and observer calibration,
and with no known material candidate defect or unsafe dependency, execute these
complete regression gates BEFORE additional residual custom-fixture work.
All outstanding causal/admin obligations remain required for final ACCEPT:

1. On a fresh exact source copy, collect and run these five COMPLETE modules in
   this order (no node selector):
   tests/test_rw0_terminal_outcome_values.py
   tests/test_rw0_terminal_head_witness_regression.py
   tests/test_sqlite_rw0_terminal_controls.py
   tests/test_sqlite_rw0_terminal_migration_0008.py
   tests/test_sqlite_rw0_terminal_connected.py
   Expected 60 ordered unique passes, including six connected cases.
2. On another fresh exact 327-file copy, independently collect and run the
   repository selector-free FULL. Expected 9,568 ordered unique IDs and passes
   in the retained FULL order. No path, module, node, -k or -m selection.
3. Record collection/execution-collected/call/JUnit identities, explicit JUnit
   nodeid properties from the start, all setup/call/teardown results, warnings
   and real process exits. Require exact ordered agreement and zero failure,
   error, skip, xfail/xpass or failed noncall phase. An invertible JUnit mapping
   is useful supplementary evidence, not a silent substitute for the required
   explicit-property observation.
4. Independently inventory warnings. Direct has none; FULL may have only the
   three known DeprecationWarning multithreaded-fork nodes in
   tests/test_sqlite_b2c_writer_session.py:
   test_operation_guard_close_waits_and_retains_authority_until_exit
   test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
   test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock.
   Owned paths/PIDs may differ; other class/node/message differences require
   investigation, not filtering or suppression.
5. Capture complete raw bytes/modes/extra-file inventory immediately before and
   after collection AND before and after execution, with source-tree rebuilds.
   All 327 endpoints and modes must remain unchanged. At every boundary capture there must be no generated extras; only the prospective, exact-path transient fixture exception in section 5 is allowed during the inspected D1 test.
6. Audit probes remain outside candidate discovery and separately counted. An
   independent focused 8,266-case rerun is unnecessary if exact FULL inclusion
   is proven; do not claim one ran. No writer FULL or earlier audit count can
   replace the independent completed FULL.

Use recorded equivalents of:
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --collect-only --basetemp=<owned-collect> <complete-direct-modules>
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --basetemp=<owned-run> --junitxml=<owned-junit> <same-direct-modules>
For FULL remove all module/path/node selectors from BOTH commands. Inspect
pytest config, conftest and setup/child-launch seams before import. The observer
may record IDs/outcomes/warnings and add JUnit nodeid properties, but must not
select, reorder, skip, change assertions/results or suppress warnings. Keep its
exact source/digest in the evidence and bind every launch to it.

Do not edit candidate source/tests to get green results. Correct audit-only
parser/fixture/observer mistakes transparently on fresh owned state, retaining
failed attempts. A genuine candidate failure triggers findings, not retries with
weakened oracles. An interrupted FULL gets no complete-pass credit; preserve
actual partial records and absence of final JUnit/observer rather than infer
completion from displayed percentages.

5. PRESERVED RUNNER, CURRENT ADMISSION AND RESIDUAL EXECUTION

No general qualification or regression reset is authorized. Use the same neutral root,
exact QtcM and admitted WA1 model. Reauthenticate current source, QtcM, active gate,
observer, supervisor and source-copy identities. Recreate only explicitly owned current
fixtures after absence/identity checks. Unknown historical writable state is not deleted
to make admission pass.

Freeze every new audit helper/revision before launch. Registration-only or rejecting-only
changes do not invalidate W v5. Any accepting-path, policy, runtime, candidate or source
change requires an explicit impact assessment and genuinely invalidated reruns; do not
splice incompatible evidence. New candidate execution uses the current admitted gate,
exact argv/environment/cwd, close_fds=True/pass_fds=(), raw stdout/stderr, wall and
monotonic times, PIDs/groups, bounded waits, reaping, and complete before/after source
and WA1 inventories.

Run the Phase-B builder, L1/L2 route/SQL groups, C1B05 matrix and C2A20 L3 group in fresh
owned states. Candidate probes remain separately counted and outside candidate discovery.
Preserve every failed/superseded helper attempt with no false credit. Do not repeat W's
4/99/60/9568, RT's completed controls, C4 or earlier mapped causal programs merely to
establish a checkpoint.

For each completed residual row bind:
- source/helper/policy/admission revision;
- independent expected result;
- valid paired setup and actual checked seam;
- exact observed result/error/classification and call/order evidence;
- nonmovement/disclosure/repair/retry evidence;
- limitation and state-class assumptions.

After each child closes, repeat source bytes/modes/extras and WA1 protected/writable
identity checks. Provisional output is published only by stable no-follow read and
independent protected copy after closure. No rename/hardlink publication. Remove only
newly created prospective transient objects after their evidence is protected.

6. CUMULATIVE ADJUDICATION AND DELIVERY

Produce corrected A01–A18 and all 56 stable residual rows. Preserve all old verdicts,
policy scopes and historical failures. Distinguish carried independent execution, new
execution, source/DDL implication, writer/data record, historical unavailable evidence
and genuinely unresolved mandatory scope. Do not reset partial proof to unattempted.

Primary disposition options:
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED
 AUDIT_PROVENANCE_MISMATCH
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE

ACCEPT requires exact candidate/modes, compliant effects, supported composite WA1+QtcM
under its declared trusted-host limits, complete substantive A01–A18/F01/O1/S01/A03/
two-layer proof, all fifteen residuals closed, and supported complete regression evidence
under the explicit carry-forward rule. No mandatory gap becomes nonblocking by wording.
F03/F05 and historical provenance limits retain their exact prior scopes.

Candidate failure => BLOCKED, with no audit-side source repair. Runner/binding/evidence
limit => precise INCOMPLETE, including impact on carried proof and smallest restart point.
Do not invent a new platform, policy tranche or semantic-contract program.

Write the full report before sealing ONE evidence ZIP. Include exact RT once (RT already
contains RS/RC/W/M/U/T/S/R); do not duplicate A's large source/history tree. Include:
- current source/input authentication and corrected 179-member RT accounting;
- exact helper/revision bindings, Phase-B checkpoint and construction evidence;
- route first-hit matrices, SQL constraint inventory, C1B05 association matrix and C2A20 records;
- raw invocations/outputs/exits, source/WA1 captures, ledgers, failures and cleanup;
- preserved W suite references without claiming a new suite run.

Next outer package: <=2,500 regular members, <=128 MiB/member, <=384 MiB expanded.
One exact 75,808,728-byte RT member is expected. Preserve nested limits and cached
identities. Reopen every member and verify a complete self-excluding hash/size/CRC/
numeric-mode manifest. The adjacent receipt records actual ZIP/report/manifest bytes and
SHA-256; do not make the ZIP contain its own outer hash.

Return inline: exact verdict/tree; newly closed IDs with evidence classes and limits;
exact remaining IDs and actual stop reason; carried W runs versus any genuinely required
new run; candidate defect status; report/ZIP/manifest bytes and SHA-256; actual recipient
ChatGPT and next action. Correct the prior 181-member statement explicitly.

Only source tree 4691af58ae0ee3107b4e2e9b6b1508032944e357 is eligible. No live Git,
staging, commit, publication, deployment or product effect follows. Implementation writer
remains idle.
