## Engineering disposition

```text
RW0_NORMAL_TERMINAL_CLOSURE_S01_A03_REPAIR_REQUIRED
CANDIDATE_REMAINS_UNACCEPTED
```

**I accept the blocked verdict. Repair S01 and A03 together in the existing implementation conversation; do not retry the audit against unchanged bytes.**

This is not a provenance failure. The auditor authenticated exact candidate tree `648d332b3ba847deb257a2bb1892a76e4c442675`, including all 325 source files and the 67-modification/10-addition delta. The block concerns historical reconstruction and a bounded exact-type defect. Pasted text

I reauthenticated the supplied candidate archive and source tree and inspected the relevant contracts, plan, row adapters, fresh reader, historical reader, and recovery path. Those source checks support the findings. I have **not** received or independently reopened the auditor’s separate 92,001-byte evidence ZIP; its execution results remain attributed to the audit report.

## What the findings establish

### S01 requires both a complete witness and historical compatibility checks

The implementation retains only `role`, `owner_ref`, `revision`, and `digest` for each head. That does not satisfy the original requirement to retain the **actual complete closure-time postimages of all five heads**. More importantly, historical reconstruction does not repeat the corresponding compatibility check against the immutable P1/phase evidence. Pasted text

The synthetic probe isolates that second problem:

- The **unmodified fresh writer correctly refused** the changed program head.
- A test-only bypass of the fresh predicate seeded an internally consistent but incompatible terminal history.
- After restoring normal code, historical read returned the committed result and recovery returned `committed_exact`.

That demonstrates **historical underbinding**, not an observed unsafe normal fresh commit. The repair must preserve that distinction in its tests and report. Pasted text

**Storing more fields alone is insufficient.** Those fields must be reconstructed as checked typed rows and verified against the proper immutable predecessor facts on every historical path.

### A03 belongs in the same repair

The audit reproduced acceptance of string subclasses at the head-role, conflict-reason, and recovery-classification boundaries. It classifies this as a moderate, bounded value-contract defect, with no demonstrated authority or persistence bypass. The correction is exact built-in type checking **before** enum membership or equality—not coercion or serialization that silently removes the subclass. Pasted text

## Selected repair

I have made the representation decision explicit rather than leaving another architectural choice for implementation.

**Use a versioned terminal context containing all five complete observed row postimages.** The command’s compact head expectations and the outcome’s compact head coordinates may remain unchanged as assertions and projections. They are not the historical witness.

The repair mandate specifies:

| Surface | Required treatment |
|---|---|
| Terminal context | Introduce `governed-execution.nwp-rw0-terminal-context.v2`, retaining a closed, versioned full five-head witness in `closure_heads_bytes`. |
| Fresh recording | Capture the full typed rows from actual fenced reads and pass those observed values—not caller expectations—to the plan. |
| Historical verification | Use one shared compatibility verifier for fresh recording, exact replay/read, original recovery, and complete competing-winner verification. |
| Historical independence | Validate saved snapshots against immutable P1/phase evidence without comparing them to today’s mutable heads or stop. |
| Outcome and command | Preserve their compact coordinate forms, deriving and cross-checking them against the full checked witness. |
| Migration | Correct the **uncommitted** `0008` resource and its checksum/catalog consumers. Preserve migrations 0001–0007; introduce no `0009`. |
| A03 | Reject non-built-in strings at the identified boundaries and enforce the recovery value’s permitted classification/result combinations. |

The new context version prevents the blocked projection-only representation from being silently accepted as repaired history. No fallback may manufacture omitted fields from current rows or desired plans. Existing old-0008 candidate databases are historical test subjects, not a deployed format requiring inferred backfill.

The implementation remains limited to the five normal outcomes. P0/P1 semantics, acceptance-fact immutability, transient original-P1-command availability, cancellation exclusion, disclosure permissions, and all live/product boundaries remain unchanged.

## Validation must distinguish the two defects

The first saved and reopened checkpoint must prove real fenced **accept and replan** closure with complete snapshots, plus rejection of the audit’s incompatible-history specimen and all three A03 subclass cases.

The final regression set must also cover each of the five heads separately: full-field capture, malformed or wrong-digest witnesses, valid-digest but wrong-predecessor witnesses, actual fresh head drift, and exact historical replay after later head movement. A consistently resealed incompatible family must reach the relationship check; an earlier digest failure cannot receive credit for that predicate.

The audit’s completed work remains useful but bounded: **34 independently executed direct tests, including the six connected cases**, and independent SQL/admin controls passed. There was no independent selector-free FULL collection or execution. The original writer’s 9,542-pass result is separate evidence, not an independent pass or acceptance. Pasted text

The repair therefore requires new direct, connected, focused, and selector-free FULL validation on its final bytes. Counts must come from the new collection, not be forced to remain 9,542. The later independent audit must retain all unfinished A01–A18 obligations.

## Codex handoff

| Field | Instruction |
|---|---|
| **CURRENT STATE** | Exact tree `648d332…` is uncommitted and blocked. |
| **RECIPIENT** | The **same write-enabled normal-terminal implementation Codex conversation**. Not the audit conversation. |
| **ATTACHMENTS** | The two original audit artifacts identified below. |
| **AUTHORIZED EFFECTS** | Bounded terminal code/schema/docs/test repair, isolated synthetic validation, and external review artifacts. |
| **EXPECTED RETURN** | A newly identified cumulative uncommitted candidate and review ZIP. |
| **PROJECT SNAPSHOT** | None requested; PR #17 remains the committed baseline. |
| **NEXT ACTION** | Return the repair result here, then obtain a fresh independent precommit audit of the changed bytes. |

Send this **one complete operative prompt**:

:chatgpt-content-reference{index="6"}[**RW0 normal terminal-closure S01/A03 repair mandate**](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt)

Attach these two files downloaded from the **existing audit conversation**:

```text
RW0_NORMAL_TERMINAL_CLOSURE_INDEPENDENT_AUDIT_MGET70Ie.md
22,955 bytes
SHA-256:
1fffe41981025295b92fe2c6bff00cd0c2e6d5f95b6b8f565b54f2610934dd7d
```

```text
RW0_NORMAL_TERMINAL_CLOSURE_INDEPENDENT_AUDIT_EVIDENCE_DELIVERY_MGET70Ie.zip
92,001 bytes
SHA-256:
e1fd90b32e1987307ba4f8e194d9a1c574a59a6e0de25e9e2a1100edc095331f
```

These are the auditor’s original retained artifacts. **Do not substitute `Pasted text.txt` for the full 22,955-byte audit report.** Their identities are provided in the attached closeout. Pasted text The implementation conversation already retains the source package; no additional source-package attachment or new reconnaissance is needed.

The expected successful result is:

```text
RW0_NORMAL_TERMINAL_CLOSURE_S01_A03_REPAIR_IMPLEMENTED_VALIDATED_PENDING_AUDIT
```

The mandate permits normal in-scope debugging and reruns without another handoff, while retaining failed attempts without final credit. It authorizes **no staging, commit, push, PR, merge, publication, deployment, or product effect**. The old blocked candidate and verdict remain preserved.

**Sources:** Attached independent audit closeout, cited above; Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt[original implementation mandate](sandbox:/mnt/data/Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt); authenticated sealed candidate source.

**Confidence:** artifact identity **0.99**; source-supported repair design **0.96**. The auditor’s raw execution evidence has not been reopened here; repaired correctness and independent acceptance remain unestablished.
