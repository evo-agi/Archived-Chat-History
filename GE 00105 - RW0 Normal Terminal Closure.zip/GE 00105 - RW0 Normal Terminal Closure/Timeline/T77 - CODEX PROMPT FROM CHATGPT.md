RW0 NORMAL TERMINAL CLOSURE — OWNED-ROOT METADATA AND CUMULATIVE AUDIT COMPLETION

This is the sole complete operative replacement mandate. Continue the SAME neutral
independent reviewer from U, tc-4fd7e168a0. Make the ONE explicit metadata-only
runner amendment in section 5, recalibrate, then proceed directly through both
actual generated helpers, the exact 99-node replay, complete direct/FULL, and
residual audit closure in THIS engagement. No routine relay between those stages.
Do not restart architecture, repository/source-history mapping or general sandbox
design. This changes the audit runner only; all substantive product requirements,
candidate bytes, test assertions, suite inventories and acceptance conditions remain.
Sections 2–3 below preserve the prior substantive text exactly; section 4 changes
only the final policy name from Qtc to QtcM. No earlier prompt fragments are needed.

ENGAGEMENT ENVELOPE
CURRENT STATE: Source tree 4691af58ae0ee3107b4e2e9b6b1508032944e357 is uncommitted
and unaccepted. U authenticates the candidate, qualifies tested Qtc synthetic seams,
and runs four unchanged representatives: generated-mutant/checker fail at metadata
of one immediate owned-root entry; dedicated oracle and D1 temporary-module pass.
There are 31 mandatory-open residual rows: G01 plus the same 30 substantive rows.
The old Qs direct 60/60 and completed FULL 9469 pass / 99 fail stay historical.
RECIPIENT: SAME neutral independent reviewer conversation that produced U,
expected host cwd /private/tmp/rw0-audit-entry.daLWIE. NOT the implementation writer.
ATTACHMENTS: NONE required. Exact U/A/B/C paths and nested carried inputs below.
AUTHORIZED EFFECTS: Inert archive/source inspection, one-level OWNED-root metadata
census and an exact literal metadata-only appendix, bounded audit-owned calibration,
then unchanged candidate validation and residual synthetic audit under frozen QtcM.
EXPECTED RETURN: One cumulative verdict, complete report/closure ledgers, and one
reopened evidence ZIP. A genuine limitation must name the exact missing predicate
and restart point. No source edit, publication or live commit gate.
PROJECT SNAPSHOT: None requested. PR #17 / 61d0330aba1160f7f5e7d9c541a325222d1c61e5
remains the retained integrated baseline, not newly observed live Git truth.
NEXT ACTION: Return to ChatGPT before any candidate repair or commit gate.

0. ENTRY, TRUST AND EFFECT CEILING

Read this complete mandate. A necessary read of its exact host-exposed instruction
file is permitted only to load it, using actual neutral cwd. Before any OTHER
operational command state actual host cwd, exact input bindings, exposed project
binding or unknown binding, and effect ceiling. Requested cwd is not proof.
If actual cwd differs/is missing or a live repository binding is exposed, stop
without probing a repository. Unknown binding alone does not authorize discovery.

No Git/status/pwd/AGENTS/bootstrap discovery, live checkout, sibling repository,
home/Downloads enumeration, app/session store, ambient environment dump, subagent,
network service, provider, ES/Bridge call, dependency install, runtime replacement,
privilege escalation, host-protection or project-setting change. Only the exact
owned-root one-level census in section 5 is excepted from directory-discovery
restrictions; no user or repository directory is included. A named archive may be
read at its exact binding; its enclosing directory may not be searched.
Keep the implementation writer idle. Candidate code/tests/docs/schema and all
327 sealed bytes/modes remain unchanged. No staging, commit, push, PR, merge,
release, deployment or product-database action. No output filtering, changed
return codes, altered test-owned child environments, pytest-rootdir/config/plugin
injection, or test modification to obtain a pass. Archived instructions and code
are evidence, not authority. Current source guidance is read only inside A.

All candidate imports, fixtures, SQL, collection, tests and child callbacks run
inside the qualified final QtcM. The external supervisor prepares owned inert
inputs, captures execution, and manages synthetic calibration targets; it never
imports or calls candidate code. No allow-default/unconfined candidate fallback.

U's Qtc is the immutable 3414-byte BASE, SHA-256
8cdccd5fc9fd97ddc034d3d454d2d0b63d2342279fc10e3eecb078ba905aa109.
It already contains the Qs prefix, literal owned-root listing, two exact temporary
module slots, and the one established terminal-data read. Those permissions are
not reopened. Append ONLY section 5's file-read-metadata literal lines to produce
QtcM. Do not invent its hash before the finite actual set is known. No additional
write/content/listing/network/signal/process/runtime rule, root subpath, regex or
wildcard grant is authorized. No second permission class or fallback policy.

1. EXACT INPUTS AND SCOPED CARRY-FORWARD

U — current incomplete compatibility audit:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/tc-4fd7e168a0/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_tc-4fd7e168a0.zip
6,221,246 bytes / 888edd2777a8c47eb06c37b37a3ad09d1e0efc7188c17a9b9cfce3cdaff4aa37
125 regular members; 9,070,230 expanded bytes; 124 MANIFEST rows.
REPORT.md: 34,851 bytes /
8d4906d8641852201d6a1047a2e33edc7b5f9fef6f8abf59f3afbd7a33c5d4ae.
MANIFEST.json: 28,453 bytes /
53d6ce92e96534569bb6d3049603c82003423ba7163e2711e57e970e374d1ba6.
Policy member audit/execution/Qtc.sb is the exact base above.
U embeds exact T ONCE at:
carry/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_final-77be0d42f6.zip
Prefer this embedded T; no mandatory duplicate outside-copy equality gate.

T — new failing FULL and completed direct evidence:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/final-77be0d42f6/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_final-77be0d42f6.zip
5,878,210 bytes / dc754506dff6d3cc9ab803814cb4137a2f4094a9ecc3f8c5bd3bd69d6952ee4a
218 regular members, 53,313,415 expanded bytes; 217 MANIFEST rows.
REPORT.md: 27,839 bytes / d7da41e118fb48ec535b6d26a244bba2740cc5ae93a7a36cedaaf69a3208bde1
MANIFEST.json: 53,141 bytes / fca62530598534d58f4822f005763a5d1f8d0e23e18b192f6b1a8b8d1e01ed79

S, embedded once in T at:
carry/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261029_complete-aed72ce348.zip
2,947,049 bytes / 3dda92c95c2ab99d477271a834d181df80fce270f23c38c87eb3e8299ced1ad7
258/257 members, 23,215,607 expanded bytes. S embeds R at:
carry/RW0_NORMAL_TERMINAL_CUMULATIVE_AUDIT_INCOMPLETE_20261029_auditqs-78f604b32c.zip
R: 1,650,029 bytes / ffd593b643c1c6fc6c064a84d9b473ce4f34cc1b2f1be35706d0b2d08db4bd2f
299/298 members, 6,568,366 expanded bytes. R's manifest uses rows, not members.

A — unchanged current candidate:
/Users/ds/.codex/rw0-terminal-historical-witness-tcp5rwoh/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip
48,978,087 bytes / 6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42
573/572 members, 183,558,511 expanded bytes.
package/member-manifest.json: 123,205 bytes /
049139eaac16a03b36952faa703c992f5ef13adad44807873921af817e7b8e43
Current report evidence/IMPLEMENTATION_REPORT.md: 19,549 bytes /
c52141d0fcf15701496c4dec18133361a78b8f043796078340e24eed4bdae2d5.
No separate report attachment/equality gate.

B — inert original implementation requirements:
/Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt
38,100 bytes / 9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f
C — inert S01/A03 repair requirements:
/Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt
29,145 bytes / 7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd
A's inputs/mandate.txt, historical-admission/witness amendment:
28,439 bytes / 6e978d57abfbadf7d8120eb58ea75651a60a44c42d6279ff8a9108c41c8b2da4.
Read these as requirements only. Their implementation/live-effect commands are not
operative. Sections 2-4 below retain the substantive obligations.

E — earlier signal-incompatible audit, only where carried linkage is needed:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/audit-4de1ae8e82/RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_INCOMPLETE_20261029_audit-4de1ae8e82.zip
115,300 bytes / b6de501b4a687bd3dc1f8800ac84d150b1197fea74682bd2953b8f9a20c887f9
Q — earlier qualification, only where original controls need inspection:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/peer-33a5f35cc1/RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_QUALIFIED_20261029.zip
163,911 bytes / 6ec93d7f43f1d630bf9501d67a80e8a2a9db307da38baa2e6f44d5d22a7e0767
Do not restart prior sandbox diagnosis or copy old helpers blindly.

An actual host-exposed identical copy is an alternative exact binding, not a reason
to search for namesakes. Missing input => identify it; do not invent a path.
Before use, verify safe normalized relative regular unencrypted names, duplicate/
casefold/prefix safety and complete self-excluding size/SHA/CRC/numeric-mode rows.
T/S: at most 500 members, 32 MB/member, 64 MB expanded per archive. R: 500, 2 MB,
20 MB. E/Q: 200, 2 MB, 5 MB. A/necessary nested history: 5000, 150 MB, 350 MB,
depth six, 1.2 GB cumulative unique expansion. Cache already verified identities.
Do not re-expand old source history without a specific need.

Reauthenticate all 327 current source paths from A and rebuild tree
4691af58ae0ee3107b4e2e9b6b1508032944e357 without Git. Final-C/final-D/postcleanup
canonical manifests are byte-identical, 109,923 bytes each, SHA-256
1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1.
Preserve 326 OS 0644 rows and tests/test_c2b3_private_atomic_program_initialization.py
at OS 0600; all Git 100644. SQL 0008 is 30,178 bytes /
a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254.
The test-created src/ge_nwp_coordinator/_rw0_d1_probe_temp.py is NOT in A's inventory.
All 327 existing files stay policy-read-only. No 0009 or product fixture repair.

1.1 Authentication and receiving conclusions

For U use at most 500 regular members, 32 MB per member, 64 MB total expansion.
Validate path normalization, traversal/link/special/encryption/duplicate/casefold/
prefix safety before payload use, complete self-excluding bytes/SHA/CRC/numeric
mode coverage, and exact outer identities. U->T->S->R are inert carried evidence;
verify each once and cache identities, not repeated broad history reconstruction.
A's fixed current source is reauthenticated and rebuilt from bytes without Git.
Preserve all immutable inputs. Named missing input => identify and stop, not search.

Read U's entire report, actual policy/trials, compatibility gate, raw child trace,
observer/JUnit/source captures, terminal-resource records, synthetic controls,
scoped signals, residual/closure ledgers, process errors and cleanup. Read its
operative mandate as HISTORY, not a permission source. Inspect exact helper source
before copying/adapting into newly owned, versioned files. Never blindly execute
archived authentication, packaging, cleanup or provenance programs.

ChatGPT receiving inspection is DATA/STATIC inspection, not new host execution:
- U and embedded T/S/R authenticate. All A source bytes/modes reconstruct the fixed
  327-file tree. Five initial plus five after-compatibility complete captures and
  four candidate-launch before/after captures match all source rows. Five closing
  cleanup observations are summaries, not extra complete captures.
- Qtc is exactly Qs plus its 740-byte appendix. U/Qtc_candidate1.sb equals Qtc.sb.
- Old Qs runtime import emits the 60-byte termcap notice. The paired literal
  /usr/share/terminfo/64/dumb read with necessary ancestor metadata removes it.
  The resource was recorded as UID/GID 0, mode 0644, 308 bytes, SHA-256
  123c85a2812a517d967db5f31660db0e6aded4a0b95ed943c5ab435368e7a25c.
  These are retained installed-file observations, not embedded binary payloads.
- The four-role original 40-control records reconcile under actual Qtc hashes;
  scoped signal results carry at their measured owned-target/nonmember boundary.
  Some inherited signal label strings still say Qs; actual argv/policy digests bind
  Qtc. Do not infer execution identity from a stale label.
- Observer calibration: two synthetic cases / six passing phases / one intentional
  warning. Actual representatives: four collected/called/explicit JUnit IDs,
  two pass/two fail; all setup/teardown pass; zero warnings; outer exit 1, no timeout,
  empty outer stderr, exact source before/after. Calibration is not candidate credit.
- Child trace has eight Popen records, seven run returns (0,4,0,4,0,0,0), and one
  real D1 result. Recorded raw text sizes/hashes match. Both failing generated
  collection children have unchanged argv/env and actual EPERM at os.stat via
  Path.is_dir in installed _pytest/main.py pytest_ignore_collect. Exact first
  denied entry is root/POLICY_REVIEW.md. Both import-only child phases succeed.
  No metadata/collection success for the other 95 generated cases is inferred.
- The dedicated oracle completes import, 94-node collection and child execution
  with empty stderr. The D1 test completes actual generated-module use and finally
  unlink at the smoke W slot. These close G03/G02 at representative scope only.
- U's fixed99 list exactly matches failed T JUnit IDs, count 99, ordered compact-JSON
  SHA-256 f242e64dd779abab8a7ff39c64a69e852524b51b85ee1d61b3f0228b0a178224.
- U's one-level listing records COUNT=10 only, not all names/types. Receiving review
  therefore has not guessed the actual finite child permission set.
- U ran no fixed99, complete direct/FULL, or new substantive causal probe. All 56
  residual IDs are preserved; only G01-G03 statuses changed. Open count 31 means
  G01 plus THIRTY substantive rows. No candidate defect follows from the stat denial.

A launch pass can carry only by mapping requirement -> exact source/helper/policy
identity -> setup/reached predicate -> raw outcome -> limit. R/S/T causal proof,
T direct pass and failed FULL, and S's completed normalized C4 retain those scopes.
Do not repeat them merely to rename cases, conflate repeated node counts with unique
acceptance obligations, or turn writer retained runs into independent execution.
The earlier failed/incomplete verdicts stay truthful. C4 remains seven normalized
blocks / 28,910 events / 28,388 SQL classifications, not raw expanded SQL.
No new complete-suite pass exists under U's Qtc.

1.2 Frozen residual ledger and sequencing

U/audit/evidence/RESIDUAL_LEDGER.json equals T's 56-row frozen ledger exactly:
SHA-256 fffc8d2f50046c1fa8df3b0f1d63c1c16348e2f628d5c07dd3d6c6d0b4bbcd56.
Preserve every ID/history. U/audit/evidence/RESIDUAL_RESULTS.json leaves G01 plus
the following substantive rows open; the bracketed labels below are retained T
statuses, not claims of a new attempt in U:
- C1A01: wrong selected acceptance reference [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C1A02: missing selected acceptance fact [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C1A03: foreign selected acceptance lineage/decision/digest [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C1A04: legitimate unrelated acceptance fact coexists in the same owned managed store [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C1B03: graph role/cardinality/order and self-digest exclusion [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C1B04: repeated-column equality and alias disagreement [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C1B05: remaining P0/phase/Section41/C1/V22/P1 observation and evidence associations beyond source3 [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C2A04: first physical match or exact earlier-match implication for rw0_terminal_contexts.p1_decision_ref [prior: carried_occupancy_only_first_match_open].
- C2A05: first physical match or exact earlier-match implication for rw0_terminal_outcomes.outcome_value_ref [prior: carried_occupancy_only_first_match_open].
- C2A06: first physical match or exact earlier-match implication for rw0_terminal_outcomes.phase_basis_ref [prior: carried_occupancy_only_first_match_open].
- C2A07: first physical match or exact earlier-match implication for rw0_terminal_outcomes.decision_ref [prior: carried_occupancy_only_first_match_open].
- C2A08: first physical match or exact earlier-match implication for rw0_terminal_results.result_ref [prior: carried_occupancy_only_first_match_open].
- C2A09: first physical match or exact earlier-match implication for rw0_terminal_results.outcome_value_ref [prior: source_schema_implication_only].
- C2A10: first physical match or exact earlier-match implication for rw0_terminal_receipts.receipt_ref [prior: carried_occupancy_only_first_match_open].
- C2A11: first physical match or exact earlier-match implication for rw0_terminal_receipts.mutation_ref [prior: carried_occupancy_only_first_match_open].
- C2A12: first physical match or exact earlier-match implication for rw0_terminal_receipts.family_route [prior: carried_occupancy_only_first_match_open].
- C2A13: first physical match or exact earlier-match implication for rw0_terminal_receipts.phase_basis_ref [prior: carried_occupancy_only_first_match_open].
- C2A14: first physical match or exact earlier-match implication for rw0_terminal_receipts.p1_decision_ref [prior: carried_occupancy_only_first_match_open].
- C2A15: first physical match or exact earlier-match implication for rw0_terminal_receipts.context_ref [prior: source_schema_implication_only].
- C2A16: first physical match or exact earlier-match implication for rw0_terminal_receipts.outcome_value_ref [prior: source_schema_implication_only].
- C2A17: first physical match or exact earlier-match implication for rw0_terminal_receipts.result_ref [prior: source_schema_implication_only].
- C2A19: damaged self-digest family refuses exact/winner and stays unresolved [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C2A20: foreign complete winner and original absence exclusion classifications [prior: carried_independent_partial].
- C2B11: stale in-memory lease versus durable issuance and closed session [prior: carried_independent_partial].
- C2B12: receipt-last boundary and second readback failure/rollback [prior: carried_independent_partial].
- C2B13: recovery cleanup uncertainty and no automatic retry [prior: carried_independent_partial].
- C3A02: remaining context FK and unique route predicates with independent unoccupied targets [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C3A03: remaining outcome FK, unique and nullable pair predicates [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C3A04: remaining result FK/composite and route predicates [prior: open_not_attempted_after_fixed_FULL_incompatibility].
- C3A05: remaining receipt FK/unique/composite/profile/blob predicates [prior: open_not_attempted_after_fixed_FULL_incompatibility].

G01 now names the actual root-child metadata incompatibility. G02 and G03 have
bounded U representative passes; rerun the same four representatives under QtcM
rather than upgrading their old policy scope. After compatibility, all 30 substantive
rows above still require closure. No whole-ledger reset or scope inflation.

Execution sequence in THIS engagement:
1. Reauthenticate U and current A, inspect actual installed collector code as data,
   freeze the one-level finite metadata set and final QtcM; recalibrate changed
   seams and the original boundary using inspected existing designs.
2. Rerun all four exact unchanged representatives with transparent result capture.
3. If all pass, replay the exact 99 failed T IDs without omission/expansion changes.
4. If compatible, complete new direct and selector-free FULL gates under the SAME
   final QtcM before further residual fixture authoring. The original suites are
   not altered and a diagnostic subset never supplies FULL credit.
5. Complete the 30 residual substantive rows and all remaining A01-A18 obligations;
   reconcile the conjunction for disposition. A green FULL is necessary, not sufficient.

No new routine user relay between steps. A genuinely known material source defect,
unsafe dependency, source drift or containment failure stops affected execution;
a merely unfinished residual row does not bar safe complete-suite regression.
Correct ordinary audit-owned parser/observer/fixture mistakes on fresh owned state
with all versions/results retained. If a practical limit prevents completion, name
an exact attempted/unattempted predicate and smallest restart point, not a vague
'C1-C3 remain open' category. No background-work promise or automatic future task.

For residual fixtures, retain the selected bounded meanings: unrelated acceptance
is same STORE, not same hardcoded fixture chain; private-operand mismatch is not
a cryptographic collision search; short-circuit route coverage distinguishes
physical occupancy from first match and exact earlier-match invariants; impossible
valid states need source/schema proof, not false exceptions or invalid positives.
Use unoccupied raw-SQL targets with intact FKs/guards and paired positives for
independent constraints. T's receipt-result FK and routes 1-3 already carry proof.
No new product multirun API, weak validation, fixture loophole or source patch.

2. SUBSTANTIVE REVIEW — THE EXPLICIT TWO-LAYER AMENDMENT

The earlier whole-operation zero-current-stop-SELECT criterion failed under the
old mandate. That blocked result remains true. The engineering decision is to
preserve mandatory shared storage safety, not to skip it to satisfy a terminal
history test. The current candidate is judged against the following amendment:

Layer 1: existing operational admission remains mandatory. Session/process/thread/
lease validity, database binding/custody, BEGIN IMMEDIATE, exact managed schema,
history/catalog/posture and invariants, writer ownership/fencing, and current
protected disclosure remain intact. The existing global_stop_current singleton
shape validator may read that current row only for managed-store validity.
Valid active/clear status, version, timestamp and directive identifiers must not
be compared with saved terminal stop or turned into current effect permission.
Denied/unreadable/malformed managed state may prevent disclosure or leave recovery
unresolved. It must not be misclassified as stale terminal history or definitely
absent original execution. No cache, successful-assessment stub, invariant-skip
flag, alternate connection/controller, or production validator weakening.

Layer 2: historical checked read, receipt-present replay and recovery use saved
full postimages/stop and checked immutable predecessors after admission/fencing.
The five current-head tables are not consulted during the historical operation.
Current-stop reads are permitted only at the existing shared invariant check,
not as a general table-read exemption or later semantic terminal query. Receipt
is first TERMINAL-FAMILY lookup, not first SQL statement. Exact original result,
time, graph, receipt, source associations, protected disclosure, immutable
acceptance binding, complete competing-winner/absence proof and uncertainty
classifications remain required. Historical operations do not require recording
permission or renewed acceptance-unclaimed eligibility. Fresh receipt-miss
recording retains actual current five-head/stop checks unchanged.

This amends only the overbroad current-stop-query requirement. It is not a waiver
of the constructor defect, five-head independence, disclosure, SQL grammar,
transaction safety, audit isolation, or other cumulative acceptance controls.
Verify the two owning documents state the distinction and preserve the old
failure as history; do not create another silent interpretation of either layer.

Inspect at minimum the complete changed witness module, changed tests and docs,
full terminal contracts/rows/plan/SQLite owner, and actual shared admission call
chain (not only wrapper names). Current anchors:
  sqlite_transition_transaction.py:2759–2779,4753–4773
  sqlite_migration.py:2477–2523
  .docs/rw0-terminal-outcome-physical-closure.md:177–220
  .docs/sqlite-operations-and-recovery.md:722–730.
Python basenames are under source/src/ge_nwp_coordinator/; docs under source/.

2.1 Independently test the repaired constructor and mutable aliasing

TerminalHeadWitness at _rw0_terminal_head_witness.py:48–96 must validate ordinary
construction, not only checked factories. Independently test valid direct/factory
triples for accept and replan and all five typed owner roles (8/9/41/9/8 fields,
valid nulls, self-digests). Exact bytes, outer tuples, dictionaries, keys and
scalar types precede hostile comparison/coercion. Bytes, full rows and compact
coordinates must match rather than silently replacing invalid supplied parts.

Require negative controls for the previous malformed type triple and b'{}'/empty
postimages, bytes/list/tuple/dict/string/int subclasses, bool-as-int, wrong arity,
missing/extra/reordered roles or fields, wrong schema/digest, noncanonical and
oversize bytes, and valid canonical bytes paired with DIFFERENT valid rows or
projections. Calibrate a shared/per-instance hostile equality counter, clear it,
and verify zero hostile calls per invalid construction. Preserve built-in
positives and process-control propagation.

Mutate caller-owned maps and separately returned maps, then re-read both views
and canonical bytes and run normal downstream verification. They must remain
checked and unchanged. No unvalidated object token/factory escape or recursion.
Do not demand security against arbitrary reflection/object.__setattr__; that is
not the selected boundary. Verify unchanged wire fields/schema/digest domains
and valid consumer behavior, including exact original P1 replan operands.

2.2 Independently prove complete-operation phase behavior

Use real private WriterSession read, receipt-present record/replay and recovery,
not just a terminal helper. Trace and attach observation/denial at the actual
acquisition/controller opener aliases and account for every operation connection.
The candidate observer labels the full managed wrapper; independently establish
which SQL is genuinely in _verify_global_stop_current_shape. A phase label alone
does not prove shape-only use or permit arbitrary managed-phase stop semantics.

Observe real unchanged validator, ownership-read and issuance/fencing functions;
observation wrappers must call the real function and return its actual result.
Do not replace admission with a successful assessment or patch the predicate
being proved. Capture connection, phase, table/column and allow/deny results.
Calibrate each attached authorizer with owned allowed and intentionally denied
queries. Trace acquisition separately, including any connection work before the
observer attachment, and prove it cannot hide a five-head/later-stop lookup.
A zero-callback claim at the wrong alias is invalid. Column callback counts are
not SQL-statement counts or a fixed product invariant.

Required current-byte controls:
- real fenced accept and replan commits, then coherent later movement of every
  head and valid active/clear stop fixtures; under the layered denial policy,
  exact read/replay/recovery preserve original result/time/witness/graph/receipt
  and acceptance facts without new terminal or protected-row movement;
- original absence with positive/negative old-execution exclusion; complete
  compatible and incompatible competing winners under that same policy;
- deny the ACTUAL managed-stop read during admission: safe operational refusal
  before protected terminal-family handling, recovery unresolved where the
  unchanged controller so classifies; no no-write mislabel as stale history,
  definite absence, hidden retry, committed result or protected disclosure;
- malformed actual stop row or real query-return tuple, with validators intact:
  integrity failure rather than ordinary currentness; fault removal restores
  valid operation; bound process-control behavior remains unchanged;
- fresh receipt miss reads all five actual heads and stop. Stale expectations
  conflict without writes; correctly expected valid changed stop follows the
  current normal-record rule without conferring executable permission;
- denied/expired/foreign/malformed disclosure, closed/stale/fenced session and
  unavailable managed store remain non-disclosing. Fresh recording permission
  stays separate from historical protected disclosure and stop shape.

All synthetic later states/fault seams must be described as such. Do not call
a direct fixture UPDATE a newly supported product operator transition.

3. COMPLETE CUMULATIVE A01–A18 REGISTER AND CAUSAL OBLIGATIONS

Review the entire baseline-to-current terminal change, not only the five-file
repair. Supply exact archive-relative source/doc/test/SQL coordinates, severity,
and evidence class for every row: contract/current code, inspected test design,
retained record, independent execution, inference or limit. Unchanged bytes and
prior passes do not automatically discharge current mandatory controls.

A01 Authority: exactly five private normal terminal facts, separate from P1
 decision/acceptance, standing-policy grants, source facts and executable
 permission. No cancel closure, live supplier/contact, ES/Bridge/Git effect,
 service/scheduler/autonomy or publication authority.
A02 Preservation: legacy terminal V1/four validators, P0/P1 meaning, WorkSpec,
 Decision Basis/command-digest v2, preassignments, D1/D2, generic receipt, public
 StateStore/package exports unchanged. Audit original shared catalog/controller/
 writer-session terminal integration even though this immediate repair froze it.
A03 Grammar/types: closed command/context/outcome/row/result/recovery/witness
 schemas, exact built-ins before equality, canonical UTF-8/JSON and duplicate
 rejection, bool-as-int, safe refs/digests/calendar time, budgets and null pairs.
 Include direct constructors, factory consistency and aliasing; resolve A03/O1.
A04 Identity graph: independent domains/acyclic preimages, four sibling refs and
 route, optional assertions bound in command digest but not preassignments,
 graph role/cardinality/order, self-digest exclusion and repeated-column equality.
A05 Original operands: original P1 command and private replan operand transient;
 complete checked predecessor association required. Missing/inconsistent private
 content cannot be reconstructed from a safe digest or yield false certainty.
A06 Source association: actual checked P0/phase/Section41 A/C1 rank15/V22/P1
 chain and validation/review/proposal/result-set/observation relationships;
 membership counts or digest strings do not independently establish ownership.
A07 Acceptance: bind existing immutable acceptance only for accept; never create,
 mutate or replenish it. Wrong/missing/foreign facts reject. Legitimate unrelated
 facts must coexist without preventing another allowed terminal branch. No
 historical acceptance-unclaimed recheck.
A08 Heads/stop: observed full five-row witness, source/adapters/digests/links,
 replan historical P1 postimages, fresh actual currentness and stop facts; prove
 the precise two-layer amendment, not the withdrawn zero-stop-read property.
A09 Transaction: existing fenced lease/capability/controller; receipt-first
 terminal lookup; one captured time; protected posture/source/current/route
 ordering; context/outcome/result readback, receipt last, capability invalidation,
 one commit attempt, rollback/cleanup uncertainty. No application-head/stop/
 decision/effect update by terminal closure.
A10 Read/replay: original complete result/time/graph/receipt and source/witness
 reauthentication; current protected disclosure with mandatory store admission;
 no five-current-head or later semantic stop query, cognition/process rerun,
 fresh recording permission or acceptance-eligibility requirement.
A11 Recovery: complete exact original family or exhaustive original absence and
 exclusion, or complete compatible winner, only. Partial/foreign/damaged/aliased/
 incompatible families unresolved. No winner result disclosure, hidden retry,
 fragment repair or durable private-template fallback.
A12 Error/cleanup: failed or malformed reads stay operational/integrity, valid
 actual drift stays currentness. Stale/closed/fenced sessions, pre/postcommit,
 applied-commit/lost-return and cleanup uncertainty, KeyboardInterrupt/SystemExit/
 GeneratorExit propagation at the actual fresh/read/recovery/cleanup seams.
A13 Schema/admin: four STRICT immutable normal-only tables/eight guards;
 timestamp grammar, FK/unique/composite links/phase/decision/route occupancy,
 nullable pairs, blob bounds, zero seeds, current catalog/checksum/generation 2;
 exact fresh/prefix migration and old-binary/obsolete-0008/partial/unknown refusal.
A14 Connected normals: actual preseal source variations through real P0/D1/D2/
 Section41/C1/V22/P1/terminal owners; five distinct normal positives and detached
 negative; read/replay/recovery and no forbidden contact or protected-row change.
A15 Docs/assurance: cumulative current-versus-historical status, explicit amendment
 and private scope; fixed source/hash/AST/import/schema consumers and predecessor
 reconstruction retained; no dynamic oracle, skip/xfail or broad guard stripping.
A16 Privacy/artifacts: complete postimages remain safe owner metadata; no private
 replan text, raw capsule/prompts/process results, handles/PIDs/credentials in
 terminal rows or unsafe errors. Grammar review plus independently observed
 canaries; classify raw-index metadata, checkpoints and failed artifacts.
A17 Retained evidence: exact input/source/patch/commands/env/observer outputs/
 JUnit/IDs/warnings/captures and overlapping counts; limits in section 4 below.
 No writer record or causal-register label is independent execution.
A18 Independent validation: reached current-source causal probes and direct
 suite, independent SQL/admin controls, selector-free collection/FULL completed
 with exact IDs, outcomes, warnings and source-mode preservation. No live-state
 or production-readiness inference.

The following controls remain mandatory, including previously unfinished ones:

(a) S01 full-witness family: for EACH role, check complete field capture, valid
 nullable values, supported maximum witness bound, bad owner self-digest, valid
 self-digest with wrong immutable predecessor, wrong owner/link, and actual fresh
 head movement versus changed caller expectations. Use fully resealed synthetic
 histories so owner/context/outcome/result/graph/receipt digests are internally
 valid and the real relationship predicate is reached. Pair every resealer with
 a valid family built the same way. Restore ordinary verification for the actual
 read/replay/recovery. Prior program-only evidence is not five-role proof.
 No truncated witness, v1 fallback, desired-row synthesis or current-row backfill.

(b) Source/operand/acceptance: fully resealed detached validation, review,
 source-invocation and proposal associations, including a DISTINCT forged V22
 proposal reference rather than only a proposal digest; wrong/missing/foreign
 acceptance; LEGITIMATE unrelated acceptance-fact coexistence; inconsistent
 private replan content sharing a claimed safe identity across record/read/
 replay/recovery; no new process or private-text persistence. The single-chain
 fixture's inability to construct an unrelated fact is not proof of impossibility.
 Build coherent independent synthetic state through checked owners, or document
 exact invariant proof and the remaining limitation. Do not credit an incoherent
 split-reader or early FK/digest failure as the intended relationship test.

(c) Disclosure/recording: all selected finite posture predicates, including
 positive, denied, expired, malformed, foreign-bound and absent protected subject;
 old-execution-excluded True/False; truthful claimed False/None after accepted
 P1. Fresh write needs recording AND disclosure, historical operations disclosure
 only; command reuse/assertion mismatch cannot disclose a protected result.
 Complete the expired/malformed/foreign/protected-absence matrix rather than
 inheriting earlier positive/negative permission examples.

(d) Physical routes: derive all original occupancy routes from the checked
 code (the preceding audit identified 17). Seed EACH route physically in a
 separate owned coherent scenario, with valid positives and relevant partial,
 foreign or damaged family states. Mocking query return values alone is not
 physical occupancy evidence. Check exact/winner/absence classifications and
 no winner disclosure or retry. If a route is not representable under an owner
 invariant, prove that with exact schema/contract and record the scope; do not
 invent an invalid row as a legitimate winner or silently drop the obligation.

(e) Transaction and error matrix: faults after each of the four inserts,
 result/receipt readback, receipt-last boundaries, precommit rejection,
 one applied commit with lost return, postcommit and recovery cleanup uncertainty;
 stale lease/issuance, closed and fenced sessions; actual denied SELECT versus
 malformed selected rows across current owners; all three process-control
 exceptions at meaningful fresh/read/recovery/cleanup seams. Assert target
 rows, committed bytes, protected-state nonmovement, and actual injection hits.
 No hidden second commit or automatic retry.

(f) F01/O1 regression: independently exercise raw SQL and row construction,
 not only planner success. Use otherwise valid parent/related state, paired
 valid inserts, independent negative self-digests and the repaired existing
 _time owner. Cover invalid month/day/leap-century/year-zero/time overflow,
 canonical-format deviations, Unicode digits, embedded NUL/whitespace/nontext,
 NULL handling and valid year endpoints. Reach all three recorded_at columns;
 outcome has no timestamp. Verify failed predicates are zero/not permissive
 NULL and high-level invalid row/time behavior stays integrity/unresolved.
 Reproduce the old invalid-month predicate only in owned predecessor synthetic
 state as a grammar comparison, never claim an ordinary writer exploit.
 Recalibrate O1 independently before claiming no hostile equality calls.

(g) Five connected normals plus three unsupported cancel shapes and unsupported
 profile. Source variations occur BEFORE real artificial worker/checker/capsule
 sealing, not by relabelling passed evidence afterward. Use inspected fixtures
 for setup only; independent expected branches/facts/errors are required.
 Observe artificial local process/contact limits and privacy canaries.

Run bounded causal controls before a long FULL launch. Do not start/continue
FULL while a known material blocker already prevents acceptance. Independent
controls must state setup validity, actual reached seam, expected result/no-write
predicate, source identity and limits. Candidate tests passing are not separate
independent oracles. Any mandatory control not established remains explicit and
prevents complete acceptance unless an exact supported invariant makes the case
inapplicable; fixture difficulty alone is not such an invariant.

Independent SQL/admin expectations:
  after 0006: 68 tables / 122 triggers / 5 explicit indexes
  after 0007: 74 / 134 / 5
  after 0008: 78 / 142 / 5, application generation 2.
Execute all eight authenticated literals in disposable owned state. Preserve
pre-0008 object SQL/shape; check exact prefix upgrades, no seeds, immutable
update/delete guards, FK/unique/pair/profile/normal/blob/time constraints, and
refusal of old binary, original and S01-era 0008 checksums, old SQL with current
history, missing guard, foreign object and partial/unknown/checksum divergence.
No current schema/contract change, 0009 or product database upgrade is allowed.

4. RETAINED EVIDENCE AND INDEPENDENT VALIDATION

4.1 Reconcile the current writer records as DATA

Paths: evidence/validation/<direct|connected|focused|full>/, gate-summary.json,
phase-read-map.json, supersession-record.json and current source captures.
Require independent parsing of collection observer, execution collection,
setup/call/teardown records, explicit JUnit nodeid properties, actual launch/exit,
stdout/stderr as actually retained, warnings, and four complete source captures
per gate. Do not invent a separate stderr file for a combined log.

Expected current retained gates:
  direct: five complete modules / 60 cases / zero warnings
  connected: one complete module / six cases / zero warnings, inside direct
  focused: 126 complete modules / 8,266 cases / three known warnings
  FULL: selector-free / 9,568 cases / three known warnings.
All narrower sets must be included in FULL; totals overlap and do not add.

Ordered-ID SHA-256 uses UTF-8 JSON array, ensure_ascii=False,
separators=(',', ':'), with NO trailing LF:
 direct 229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467
 connected 81e14e3fa1b85a7be2ea6fafac85974839145bbcb6397e6da0bb1feeba060aac
 focused 419d37ff399689788123583f614a1d8b107ef712e2368ca179cd6e65fbec5104
 FULL 25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9.

All sixteen source captures have the same 105,550-byte envelope, SHA-256
0c0b4017371a798731a63825ac63922c361189e37f5a713f5c4f7ec06e9b32cb.
Require full row equality to the different canonical source-manifest envelope,
its embedded canonical hash, correct final tree and no extra/missing paths.

The retained direct JUnit phase maps report six operation connections, 60
managed-stop column callbacks and six intentional head-denial calibrations
for EACH accept/replan scenario. Independently parse the raw properties. Do not
substitute those counts for actual phase/call-chain verification, or label them
SQL-statement counts. Acquisition has separate test observations.

4.2 Known retained-evidence limits — do not silently fill them

The active external gate_observer source and a launch-bound helper digest are
not retained in the current outer ZIP. Old nested helpers cannot prove that
current code's identity. Writer records can be internally reconciled but their
observer's nonselecting implementation is not thereby inspected. The independent
runs below must use newly audit-authored, retained, inspected and calibrated
observers. Independent fresh evidence can establish current behavior; it does
not retroactively establish the missing writer helper.

The seven-case checkpoint has receipt/JUnit evidence and a different declared
tree 85c9fea24f4f74f358f9cc59a5d323d836a04041; it lacks a complete checkpoint
source payload here. Its historical save/reopen/source-binding claim stays
qualified and supplies no final-byte credit. Similarly, one retained patch
manifest per kind is not proof of two writer runs; independently reconstruct
current endpoint/patch identity rather than invent that history.

These are disclosed retained-evidence/process limits, not automatic production
findings. Determine their actual acceptance impact. Complete current independent
source/runtime evidence must not be replaced with writer claims. Any unmet
mandatory evidence requirement is INCOMPLETE, not a pass by wording change.
Preserve failed/superseded source/test results separately. The prior audit's
live-status/path probes and interrupted FULL remain historical limits.

4.3 Required independent execution gates

Under the explicit prospective section 1.3 scheduling amendment: after current
source inspection/reauthentication, exact final QtcM readiness and observer calibration,
and with no known material candidate defect or unsafe dependency, execute these
complete regression gates BEFORE additional residual custom-fixture work.
All outstanding causal/admin obligations remain required for final ACCEPT:

1. On a fresh exact source copy, collect and run these five COMPLETE modules in
   this order (no node selector):
   tests/test_rw0_terminal_outcome_values.py
   tests/test_rw0_terminal_head_witness_regression.py
   tests/test_sqlite_rw0_terminal_controls.py
   tests/test_sqlite_rw0_terminal_migration_0008.py
   tests/test_sqlite_rw0_terminal_connected.py
   Expected 60 ordered unique passes, including six connected cases.
2. On another fresh exact 327-file copy, independently collect and run the
   repository selector-free FULL. Expected 9,568 ordered unique IDs and passes
   in the retained FULL order. No path, module, node, -k or -m selection.
3. Record collection/execution-collected/call/JUnit identities, explicit JUnit
   nodeid properties from the start, all setup/call/teardown results, warnings
   and real process exits. Require exact ordered agreement and zero failure,
   error, skip, xfail/xpass or failed noncall phase. An invertible JUnit mapping
   is useful supplementary evidence, not a silent substitute for the required
   explicit-property observation.
4. Independently inventory warnings. Direct has none; FULL may have only the
   three known DeprecationWarning multithreaded-fork nodes in
   tests/test_sqlite_b2c_writer_session.py:
   test_operation_guard_close_waits_and_retains_authority_until_exit
   test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
   test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock.
   Owned paths/PIDs may differ; other class/node/message differences require
   investigation, not filtering or suppression.
5. Capture complete raw bytes/modes/extra-file inventory immediately before and
   after collection AND before and after execution, with source-tree rebuilds.
   All 327 endpoints and modes must remain unchanged. At every boundary capture there must be no generated extras; only the prospective, exact-path transient fixture exception in section 5 is allowed during the inspected D1 test.
6. Audit probes remain outside candidate discovery and separately counted. An
   independent focused 8,266-case rerun is unnecessary if exact FULL inclusion
   is proven; do not claim one ran. No writer FULL or earlier audit count can
   replace the independent completed FULL.

Use recorded equivalents of:
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --collect-only --basetemp=<owned-collect> <complete-direct-modules>
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --basetemp=<owned-run> --junitxml=<owned-junit> <same-direct-modules>
For FULL remove all module/path/node selectors from BOTH commands. Inspect
pytest config, conftest and setup/child-launch seams before import. The observer
may record IDs/outcomes/warnings and add JUnit nodeid properties, but must not
select, reorder, skip, change assertions/results or suppress warnings. Keep its
exact source/digest in the evidence and bind every launch to it.

Do not edit candidate source/tests to get green results. Correct audit-only
parser/fixture/observer mistakes transparently on fresh owned state, retaining
failed attempts. A genuine candidate failure triggers findings, not retries with
weakened oracles. An interrupted FULL gets no complete-pass credit; preserve
actual partial records and absence of final JUnit/observer rather than infer
completion from displayed percentages.

5. FINITE OWNED-ROOT METADATA AMENDMENT AND AUDIT EXECUTION

5.1 Stable layout and input policy

Let ROOT be exactly:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz
The historical U namespace is tc-4fd7e168a0. Its five exact source copies were
preserved and its complete suites were not run. Reuse these source copies after
fresh full authentication, so that the two W slot paths DO NOT change:
ROOT/mock_source/tc-4fd7e168a0/{master,causal,direct,smoke,full}

For all new helpers, provisional output/state and protected evidence choose one
fresh unique suffix md-<nonce> UNDER ROOT/{execution,scratch,home,tmp,evidence,denied}.
Do not overwrite old U helpers, source payloads, logs or ledgers. All prospective
launcher/observer/causal code stays in the existing read-only execution subtree.
Only scratch/home/tmp hold candidate-produced state/output. Evidence stays protected.
Missing source copies may be rebuilt from authenticated A into exactly these already
permitted slots ONLY when absent and without overwriting an existing unverified
file or deleting an old source/evidence tree. Verify all 327 bytes/modes and extras.
A mismatched present copy is a source-binding limit, not authority to repair it.
The direct/full copies that were never used for complete suites serve as fresh
exact inputs after current full-row verification; no stale database state is reused.

Qtc must equal its U payload, 3414 bytes and hash above. Keep its two literal W
rules, termcap data rule, Qs prefix, absolute roots, signal scope and network denial
byte-identical. QtcM = those exact bytes plus ONLY the finite metadata lines below.
No path rebinding/new W slot, directory content read, recursive metadata/read,
regex/subpath/wildcard permission or installed-runtime change.

5.2 Inspect the actual collector and freeze ALL immediate-entry metadata together

The actual U trace establishes Path.is_dir -> stat on ROOT/POLICY_REVIEW.md in
pytest_ignore_collect. The public pytest 8.4.1 code corroborates that Dir.collect
examines entries before Session prunes to an explicitly named descendant. That is
external source context, not installed-source identity. Under the existing runtime
read allowance inspect/hash the exact installed _pytest/main.py and _pytest/pathlib.py,
and directly referenced installed _pytest/python.py/config implementation only if
necessary to establish this finite path. Read code as data, not imported candidate.
Record exact functions/lines, exception handling, symlink following, entry type
checks and the difference between stat and content/recursive traversal. Do not
replace installed code or reinterpret one caught optional venv-marker lookup as
an authorization to read a protected subtree. No web access is needed/authorized.

NEW EXPLICIT AUTHORIZATION, trusted supervisor only:
- Enumerate ROOT itself ONCE for a current complete immediate-child census, with
  bounded at most 128 entries. A second census may verify stability. This is an
  owned artificial root, not the host root, user home, repo or Downloads.
- Use lstat on each immediate entry; retain name, exact lexical path, type, mode,
  UID/GID and identity fields needed to freeze the set. No recursive walk, file
  content reads or enumeration inside evidence/denied. No loading root documents.
- Include ALL immediate regular-file/directory children in the frozen metadata set,
  not just POLICY_REVIEW.md or the first error. Omit already permitted redundant
  metadata lines after proving the existing allowance. Bound every added path to
  exactly one direct ROOT child, with normalized name and no slash/control escape.
- Root symlinks/special files or an unexplained nonowned entry are not silently
  admitted. lstat records the condition without following outside targets; stop
  on such an unsafe/unclassified entry, preserving all old artifacts. Do not
  delete/move/rename old entries or change their bytes/types to make pytest pass.
- Do not create root conftest/pytest.ini/tox.ini/setup.cfg/pyproject.toml or any
  collection-control file. No changes to rootdir, ignored paths or child argv/env.

Before the census/freeze, the supervisor may create at most TWO uniquely named
non-code root calibration entries: one plain safe text sentinel and one directory
with one safe child sentinel, both audit-owned, non-link, non-test/config names.
They solely prove metadata-vs-content and depth separation. Record their bytes,
metadata and ownership; no candidate code is placed there. Their presence is an
explicit calibration effect, not a product change. Remove only those two owned
entries after final evidence transfer. Do not add any other root entry later;
all report/helper/output creation uses the already existing subtrees.

Freeze one deterministic sorted unique JSON list of authorized paths and actual
root entry membership/types. Freeze policy appendix once as exact lines:
(allow file-read-metadata (literal "<exact immediate ROOT child>"))

No literal may name a descendant of a child, target reached by a symlink, external
path, absent hypothetical resource, or a newly selected runtime family. Strict
ancestors already have metadata access; no further ancestor grant is needed. This
amendment explicitly permits disclosure of the immediate entries' metadata, NOT
content. State that tradeoff. The policy does not become a filesystem data reader.
No need to authorize both PATH and guessed aliases: use exact actual paths only.

Record Qtc prefix, finite census/list, line-by-line delta, actual QtcM bytes/hash,
installed-collector source identities and rationale. Its identity cannot be known
in advance because U retains only a root-list COUNT=10. Do not assume that count
is the present inventory. Check root membership/type stability before each candidate
launch; ordinary mtime/size changes on writable subdirectories are not unexpected
membership changes. New child names or unexpected type changes invalidate the
freeze; stop without automatically adding another line or masking them.

No iterative per-filename policy experiment is needed: construct the entire finite
set before the first trial. Correct an audit-only quoting/serialization mistake
within this SAME frozen path set if needed, keeping all attempts; authorize no
second permission class or new set to chase later failures. If nested collection
needs file CONTENT, deeper protected metadata, recursive listing or another effect,
return the precise unmet operation and source call chain; do not widen by inference.
Do not certify sufficiency from static code alone.

5.3 Calibrate the changed boundary before candidate execution

Use independently inspected/adapted owned synthetic helpers under final QtcM,
never a supplied script blindly executed. Current data, not historical presence,
establishes fixtures. Reuse U's terminal-resource and D/W designs; do not repeat
termcap path hunting or old SIGABRT diagnoses. Rehash installed terminal data and
runtime at their exact existing bindings. The one selected terminal data file
read stays the same. No suppression/substitution of the notice or child environment.

Changed metadata controls must demonstrate:
- Actual ROOT enumeration and stat/lstat/type classification for every admitted
  immediate child, including the plain-file and directory calibration entries.
  The intended collector metadata exception succeeds without reading their contents.
- Data read and writes of the new plain-file root sentinel remain EPERM/EACCES;
  enumeration of the new root directory and metadata/data access to its child
  remain denied, proving depth/content are not silently widened.
- Existing evidence/denied data and recursive directory enumeration remain denied;
  canonical and owned alias routes do not obtain content or write permissions.
  Exact source/launcher/evidence sentinels remain protected. Use ONLY owned targets.
- No wildcard/recursive metadata entitlement is inferred from successful direct
  stats. Genuine EPERM/EACCES is denial credit; ENOENT, ENOTDIR, timeout, parse
  error or missing peer is not. The supervisor establishes existence/accessibility
  of denied owned targets outside the inner policy first, without candidate code.
- Both original exact W slots still permit create/write/read/unlink and are absent
  afterward. Existing 327 files, sibling filenames and protected alias targets
  remain nonwritable. Retain the exact route tested: refusal to create a hardlink
  does not claim a write was attempted through a successfully created hardlink.

Rerun the original parent/fork/exec/fork-exec forty-control inventory under final
QtcM, plus scoped signal readiness, marker/SQLite, and these changed-seam controls.
Use the same owned, noninherited listening peer with before/after nonce handshakes;
all four forms must reach actual bind/connect denial. Keep live owned outside and
independently instantiated identical-policy nonmember signal exclusions; actual
successful own-workload signaling/reaping includes relevant TERM-ignore/KILL and
group cases. No external cleanup credited as candidate success. Preserve measured
scope; do not claim universal host or arbitrary-descendant isolation.

Freeze final observer/bootstrap/supervisor source and pre/post hashes; calibrate
nonselecting observer on synthetic cases with an intentional warning, explicit
rw0_audit_nodeid properties and all phase outcomes. No selection/reordering/skip/
warning suppression/outcome rewriting by the observer. Label synthetic calibration
separately from candidate execution. Qualification of U does not qualify QtcM by name.

5.4 Actual compatibility, exact failed-set replay, complete suites and residual work

All operations below use ONE frozen QtcM. Copy/adapt U's audited launch helpers
only into new execution files, changing permitted owned output paths/policy binding
and evidence capture, not candidate semantics. Root entries/policy cannot vary per
node. Preserve original unchanged child argv/cwd/environment and raw streams.

First run the exact four representative node IDs in U/audit/execution/rep4_ids.json,
including BOTH generated-helper families, dedicated oracle and D1 module test.
U's two passes retain old Qtc scope; do not splice them into new runner success.
A representative-only transparent subprocess wrapper may call original run/Popen
with identical arguments, record actual raw outcomes, and return the original
objects/exceptions unchanged. Do not monkeypatch pathlib, stat/scandir, import,
pytest hooks, test-owned env, rootdir, output or assertions to hide a failure.
The wrapper is removed for final suites. Retain raw nested collection errors,
not merely the parent assertion stderr. A changed failing assertion is NOT a pass.

If all four succeed, replay the EXACT 99 failed T IDs, in the frozen order already
verified in U. Derive/reconcile from T JUnit or authenticate U's exact list:
compact UTF-8 JSON array, ensure_ascii=False, separators=(',', ':'), no LF,
SHA-256 f242e64dd779abab8a7ff39c64a69e852524b51b85ee1d61b3f0228b0a178224.
No dropped node, extra parameter expansion, green-only selection or test alteration.
Retain per-node old first failure -> new phase/outcome relation. This is a diagnostic
set, not FULL. A materially new candidate defect stops with BLOCKED; a novel
out-of-scope execution dependency is INCOMPLETE with exact causal evidence.

If compatible, immediately run fresh COMPLETE direct collection/execution and
selector-free FULL per section 4.3 under the same QtcM, without another handoff.
Use verified never-suite-used U direct/full copies with fresh provisional state.
No path/module/node/-k/-m selectors on FULL; direct uses exactly five full modules.
Expected 60/9568 and their ordered digests are anchors, not a means to force counts.
Unexpected inventory drift is investigated, not deleted. No candidate code or test
mutation, skip/xfail, assertion weakening, rootdir rewrite or plugin injection.
All final-suite helper versions are frozen separately from later causal additions.

The smoke/full transient module path is the only allowed source-area extra DURING
the unchanged D1 test; it is absent at every boundary capture. Never permit it in
source manifests, leave it for another run, or make the package directory writable.
All 327 sealed files/modes remain immutable. On failure preserve exact evidence;
do not silently delete a leftover fixture before claiming a clean boundary.

Then close all 30 substantive residual rows and any remaining A01-A18 obligations.
Reuse supported prior proof by exact source/predicate mapping; no full causal reset.
The acceptance/source/route/schema/private-state obligations are not discharged by
a green suite. All unchanged requirements in sections 2–4 remain operative.
Ordinary new fixture/parser mistakes may be corrected transparently on fresh owned
state, with previous attempts retained. No new architecture/standing-authority
choice is needed for routine fixture construction. Exact invariants can delimit
unreachable specimens, never erase reachable unique predicates.

5.5 Runtime, evidence and cleanup

Fixed entry:
/Library/Frameworks/Python.framework/Versions/3.13/bin/python3
Expected Python 3.13.4 / pytest 8.4.1 / SQLite 3.49.1. Record requested/resolved/native
identities around launches and distinguish retained host hashes from supplied code.
No installation or binary substitution. Existing process-local text-encoding hint
stays unchanged; test-owned child env remains exactly its source-defined mapping.

Launch shape:
/usr/bin/sandbox-exec -f <frozen-QtcM> <fixed-python> -I -B <inspected-bootstrap> <mode>
Use explicit owned cwd, umask 077, core limit 0, null stdin, close_fds=True,
pass_fds=(), task-owned HOME/TMPDIR/basetemp/output, C locale/UTC, credential-free
allowlist, PYTHONDONTWRITEBYTECODE=1, PYTHONNOUSERSITE=1,
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, PYTEST_ADDOPTS empty, -p no:cacheprovider.
No ambient import roots or suppression. -I bootstrap adds only exact authenticated
source root/src and frozen read-only observer root. Do not secretly amend child env.

Record exact argv/cwd/env, pre/post helper/runtime/resource/policy identities,
source tree, wall/monotonic times, PIDs/groups/session, bounded workload-appropriate
timeout, raw stdout/stderr, actual exits, child closure and any emergency cleanup.
Distinguish child from supervisor exits. Retain every attempted version and failure.
A long FULL must not continue after a known material candidate finding, unsafe
dependency, source drift or containment failure. Missing residual proof alone is
not such a finding. Interrupted runs receive only actual partial credit.

Capture full 327-row bytes/modes/extras before/after collection AND execution,
with tree reconstruction, plus full closing captures. Do not label summaries full
captures. In-process observer/JUnit data remains provisional scratch until the
trusted supervisor captures exits/raw streams and transfers/hashes it into protected
evidence. Observation is not a hostile-code attestation authority. Record all
warnings and termcap output exactly; do not hide an unexpectedly returned notice.

Emergency termination only for explicitly owned/tracked targets, never a product
cleanup pass. Reap and close owned child/socket controls. After protected transfer,
remove only prospectively created transient scratch/home/tmp/denied state and the
two new root calibration entries with recorded identities. Preserve old namespaces,
U source copies, inputs and protected evidence. No broad cleanup. Report actual
scope rather than universal unobserved-descendant custody. Classify actual pyc,
database/sidecars or special artifacts without dumping private contents.

6. DISPOSITION AND DELIVERY

Keep every earlier candidate and policy verdict historically scoped. QtcM is a new
observed runner identity, not retroactive Qs/Qtc validation. Build one complete
A01-A18 ledger and the unchanged 56-row residual ledger separating carried
independent execution, carried static/data/writer records, new proof, exact invariant
arguments and remaining mandatory gaps. G01 closure is runner compatibility, not
30 substantive proofs. All 99 failures keep their old actual results.

Primary disposition, exactly one:
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED
AUDIT_PROVENANCE_MISMATCH
RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE

ACCEPT requires exact candidate source, compliant effects, enforced final QtcM,
complete supported A01-A18/causal/admin/F01/O1/S01/A03 and two-layer historical
requirements, and complete zero-failure independent direct/FULL with exact ordered
IDs/phases/warnings and source/mode preservation. No unresolved mandatory case is
called nonblocking to obtain acceptance. F03/F05 remain inherited nonblocking
observations, not repairs. Prior failed predicates, provenance/process limits,
missing writer observer and incomplete checkpoint evidence stay truthful.

Each finding names severity/type, owning source/contract coordinates, reached
predicate, paired positive, scope and uncertainty, and distinguishes candidate
from audit-tool/runner failures. Do not claim an unsafe fresh write without actual
ordinary-path proof. If incomplete, identify the specific operation/predicate,
attempted or unattempted construction, and smallest restart point. Do not merely
return another category-only list. No background or future-result promise.

Save full unique report BEFORE sealing ONE compact safe evidence ZIP. Include it
byte-for-byte, complete self-excluding manifest, exact U ONCE (U already contains
T/S/R), current policy base/appendix/census/collector review and qualification,
raw representative/fixed99/suite/causal results, all helper/observer versions, launch
records, full source captures, closure/residual ledgers, failed attempts, classified
artifacts and cleanup. Do not duplicate A or all prior archives separately. Account
for the one 6,221,246-byte U member and bounded nested carry expansion. No raw user
DB, credential, private capsule/template text or redaction disguised as raw evidence.
Reopen/hash every member and report exact report/ZIP/manifest sizes/hashes and an
adjacent receipt. The ZIP is not required to contain its own final outer hash.

Return the result to ChatGPT. Only exact tree
4691af58ae0ee3107b4e2e9b6b1508032944e357
can be accepted, solely for a separately governed live exact-byte commit gate.
No repository mutation, staging, commit, push, PR, merge, publication, deployment,
release, live authority or product effect is authorized by this audit.
