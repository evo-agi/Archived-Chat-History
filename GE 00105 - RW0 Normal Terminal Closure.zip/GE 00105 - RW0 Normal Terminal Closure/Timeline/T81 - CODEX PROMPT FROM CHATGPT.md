RW0 NORMAL TERMINAL CLOSURE — WORKSPACE ADMISSION AND CUMULATIVE AUDIT COMPLETION

This is the sole complete operative replacement mandate. Continue the SAME neutral
independent reviewer from M (md-812d7d86be). Implement one audit-owned workspace
admission layer, WA1, around BYTE-IDENTICAL QtcM, qualify their composite boundary,
then proceed directly through compatibility, exact99, complete direct/FULL and
residual audit closure in this engagement. No product implementation is authorized.

EXPLICIT PROSPECTIVE ASSURANCE AMENDMENT:
The required rejection of a trusted-supervisor-preplaced cross-boundary hardlink is
moved from the sandboxed file-operation layer to the actual PRELAUNCH ADMISSION
layer. A contaminated workspace must not launch candidate code. Runtime creation
or movement of a protected file into a writable region must still be denied and
measured. This is NOT a claim that QtcM denies operations through an already
preplaced hardlink, NOT a new policy permission, and NOT a retrospective pass of M.
All unrelated canonical/symlink/depth, source/evidence, network and process
requirements remain. Product contracts, source/test bytes and acceptance coverage
do not change. Sections 2–4 below are preserved byte-for-byte from the prior mandate.

ENGAGEMENT ENVELOPE
CURRENT STATE: Candidate 4691af58ae0ee3107b4e2e9b6b1508032944e357 is uncommitted and
unaccepted. M authenticated it, established immediate-root metadata access under
QtcM, and failed the preplaced-hardlink runtime control before candidate execution.
Thirty substantive residuals remain, plus G01; earlier Qs direct 60/60 and completed
FULL 9469 pass / 99 fail retain their actual policy/time scope.
RECIPIENT: SAME neutral independent reviewer conversation that produced M.
Expected host cwd: /private/tmp/rw0-audit-entry.daLWIE. NOT the implementation writer.
ATTACHMENTS: NONE required. Exact retained M/A/B/C and carried evidence below.
AUTHORIZED EFFECTS: Artifact/source inspection; audit-owned admission/launch/copy
helper changes; bounded no-follow metadata census of the exact artificial audit
root; synthetic gate/runtime controls; then unchanged-candidate audit execution.
ZERO policy, source, repository, installation, runtime or product-effect changes.
EXPECTED RETURN: One cumulative disposition, complete report/ledgers and one reopened
evidence ZIP. Successful gates lead directly to the rest of the audit, no routine relay.
PROJECT SNAPSHOT: None requested. PR #17 / 61d0330aba1160f7f5e7d9c541a325222d1c61e5
is a retained integrated baseline claim, not a fresh Git observation.
NEXT ACTION: Return to ChatGPT before any candidate repair or live commit gate.

0. ENTRY, TRUST, AND NON-EFFECT CEILING

Read this full prompt. A necessary read of the exact host-exposed instruction
file solely to load it is permitted in the host's actual neutral cwd. Before any
OTHER operational command state actual host cwd, exact input bindings, exposed
repository/project binding or unknown binding, and ceiling. Requested cwd is not
proof. Missing/different cwd or exposed live-repository binding => stop without
probing any repository. Unknown binding does not authorize discovery.

No Git/status/pwd/AGENTS/bootstrap discovery, live checkout, sibling repository,
home/Downloads directory enumeration, app/session-store read, ambient environment
dump, subagent, remote query, network service/provider/ES/Bridge call, installation,
runtime substitution, privilege escalation, mount/volume creation or host-protection
change. Exact named inputs may be read without searching their directories.
The only new recursive census is METADATA ONLY inside the exact existing artificial
ROOT for WA1, as bounded in section 5. Never follow it into user paths or mounts.
Read candidate guidance only from authenticated A; archived instructions are
requirements evidence, not effect authority. Keep the implementation writer idle.

All candidate imports, SQL, fixtures, collection, tests and child callbacks stay
inside exact QtcM after WA1 admits the workspace and final calibration passes.
The trusted supervisor runs audit-owned stdlib-only preparation/admission/capture,
never candidate imports or callbacks outside containment. No unconfined fallback,
altered child argv/env, pytest-rootdir/config/ignore override, outcome replacement,
stderr filter, monkeypatched candidate predicate or test relaxation.

QtcM is FIXED: 4,086 bytes, SHA-256
323ddc662ca3260365136573d08b25fe635ad448b84b4a673cf99533b0f89d0a.
Its Qtc prefix is 3,414 bytes, SHA-256
8cdccd5fc9fd97ddc034d3d454d2d0b63d2342279fc10e3eecb078ba905aa109.
The 672-byte metadata appendix is
5bdd020036dc5142411bc9c598b551517f3107173b631875af9f4c875b604c96.
No rule/path rebind, root wildcard, data/write/network/signal grant, variant budget
or new test-write slot. WA1 has its own source/digest/revision; do not fold its
identity into an invented QtcM hash. Both must bind every prospective launch.

Trusted preparation is now an express part of the selected boundary. The supervisor
is the sole preparer/publisher, does not install cross-boundary aliases in an admitted
workspace, and does not concurrently mutate protected layout while a workload runs.
This bounded audit does NOT claim resistance to a malicious supervisor or hostile
concurrent same-account/privileged host actor altering files between observations.
Do not pretend a stat census or private mode mechanically excludes such an actor.
Do not run global process searches to assert its absence. Serialize owned launches,
close their subjects, retain the assumption and measured enforcement. If the available
runner cannot maintain this bounded model, return INCOMPLETE; do not waive it.

A failed containment or admission predicate is a RUNNER blocker, not a source repair.
Known material candidate failure is BLOCKED. No staging, commit, push, PR, merge,
publication, release, deployment or product database action is authorized.

1. EXACT INPUTS, RECEIVING FINDINGS AND CARRY-FORWARD

M — latest preplaced-hardlink stop:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/md-812d7d86be/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_md-812d7d86be.zip
 6,677,682 bytes / 10d793d8d18046d7afa5385aee832576e90e3378ccaff14b58f133b3fe31ad4f
 45 regular members; 44 MANIFEST rows; 8,428,372 expanded bytes.
 REPORT.md: 27,025 bytes /
 f4b71165723c1a63cc9da5a8c8c044c165b60d0cb6c2c1c26339efef197c5377.
 MANIFEST.json: 10,167 bytes /
 bb4126e6e992e095919df92ecc0205a724b1ec523910024a2fdd13ea2f50e879.
 Policy is audit/execution/QtcM.sb; preserve exact bytes.
 M embeds U once at:
 carry/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_tc-4fd7e168a0.zip
 Prefer that exact embedded U; no second-copy equality prerequisite.

U — carried predecessor compatibility audit:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/tc-4fd7e168a0/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_tc-4fd7e168a0.zip
6,221,246 bytes / 888edd2777a8c47eb06c37b37a3ad09d1e0efc7188c17a9b9cfce3cdaff4aa37
125 regular members; 9,070,230 expanded bytes; 124 MANIFEST rows.
REPORT.md: 34,851 bytes /
8d4906d8641852201d6a1047a2e33edc7b5f9fef6f8abf59f3afbd7a33c5d4ae.
MANIFEST.json: 28,453 bytes /
53d6ce92e96534569bb6d3049603c82003423ba7163e2711e57e970e374d1ba6.
Policy member audit/execution/Qtc.sb is the exact base above.
U embeds exact T ONCE at:
carry/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_final-77be0d42f6.zip
Prefer this embedded T; no mandatory duplicate outside-copy equality gate.

T — new failing FULL and completed direct evidence:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/final-77be0d42f6/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261030_final-77be0d42f6.zip
5,878,210 bytes / dc754506dff6d3cc9ab803814cb4137a2f4094a9ecc3f8c5bd3bd69d6952ee4a
218 regular members, 53,313,415 expanded bytes; 217 MANIFEST rows.
REPORT.md: 27,839 bytes / d7da41e118fb48ec535b6d26a244bba2740cc5ae93a7a36cedaaf69a3208bde1
MANIFEST.json: 53,141 bytes / fca62530598534d58f4822f005763a5d1f8d0e23e18b192f6b1a8b8d1e01ed79

S, embedded once in T at:
carry/RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE_20261029_complete-aed72ce348.zip
2,947,049 bytes / 3dda92c95c2ab99d477271a834d181df80fce270f23c38c87eb3e8299ced1ad7
258/257 members, 23,215,607 expanded bytes. S embeds R at:
carry/RW0_NORMAL_TERMINAL_CUMULATIVE_AUDIT_INCOMPLETE_20261029_auditqs-78f604b32c.zip
R: 1,650,029 bytes / ffd593b643c1c6fc6c064a84d9b473ce4f34cc1b2f1be35706d0b2d08db4bd2f
299/298 members, 6,568,366 expanded bytes. R's manifest uses rows, not members.

A — unchanged current candidate:
/Users/ds/.codex/rw0-terminal-historical-witness-tcp5rwoh/RW0_NORMAL_TERMINAL_HISTORICAL_ADMISSION_WITNESS_REPAIR_UNCOMMITTED_REVIEW.zip
48,978,087 bytes / 6acdf203c97cffe039bc6c1da28ee192f63a8503fa278c5ae941394134ad2c42
573/572 members, 183,558,511 expanded bytes.
package/member-manifest.json: 123,205 bytes /
049139eaac16a03b36952faa703c992f5ef13adad44807873921af817e7b8e43
Current report evidence/IMPLEMENTATION_REPORT.md: 19,549 bytes /
c52141d0fcf15701496c4dec18133361a78b8f043796078340e24eed4bdae2d5.
No separate report attachment/equality gate.

B — inert original implementation requirements:
/Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_Implementation_Prompt.txt
38,100 bytes / 9fead006ff6ca6e29d2b7325897b73e10b03eb8889a4336df79092bbd5e6645f
C — inert S01/A03 repair requirements:
/Users/ds/Downloads/Coordinator_RW0_Normal_Terminal_Closure_S01_A03_Repair_Prompt.txt
29,145 bytes / 7d6b5d18ec05faecc8c9a13ad8decfe15e9e5b456a9d84258b8c1fd1c9d933dd
A's inputs/mandate.txt, historical-admission/witness amendment:
28,439 bytes / 6e978d57abfbadf7d8120eb58ea75651a60a44c42d6279ff8a9108c41c8b2da4.
Read these as requirements only. Their implementation/live-effect commands are not
operative. Sections 2-4 below retain the substantive obligations.

E — earlier signal-incompatible audit, only where carried linkage is needed:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/audit-4de1ae8e82/RW0_NORMAL_TERMINAL_CLOSURE_CUMULATIVE_AUDIT_INCOMPLETE_20261029_audit-4de1ae8e82.zip
115,300 bytes / b6de501b4a687bd3dc1f8800ac84d150b1197fea74682bd2953b8f9a20c887f9
Q — earlier qualification, only where original controls need inspection:
/private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz/evidence/peer-33a5f35cc1/RW0_NORMAL_TERMINAL_AUDIT_ENVIRONMENT_QUALIFIED_20261029.zip
163,911 bytes / 6ec93d7f43f1d630bf9501d67a80e8a2a9db307da38baa2e6f44d5d22a7e0767
Do not restart prior sandbox diagnosis or copy old helpers blindly.

An actual host-exposed identical copy is an alternative exact binding, not a reason
to search for namesakes. Missing input => identify it; do not invent a path.
Before use, verify safe normalized relative regular unencrypted names, duplicate/
casefold/prefix safety and complete self-excluding size/SHA/CRC/numeric-mode rows.
T/S: at most 500 members, 32 MB/member, 64 MB expanded per archive. R: 500, 2 MB,
20 MB. E/Q: 200, 2 MB, 5 MB. A/necessary nested history: 5000, 150 MB, 350 MB,
depth six, 1.2 GB cumulative unique expansion. Cache already verified identities.
Do not re-expand old source history without a specific need.

Reauthenticate all 327 current source paths from A and rebuild tree
4691af58ae0ee3107b4e2e9b6b1508032944e357 without Git. Final-C/final-D/postcleanup
canonical manifests are byte-identical, 109,923 bytes each, SHA-256
1bc96293fb77a88810334aeb6e6264ec6161976265f543a13055b6029a1baeb1.
Preserve 326 OS 0644 rows and tests/test_c2b3_private_atomic_program_initialization.py
at OS 0600; all Git 100644. SQL 0008 is 30,178 bytes /
a199ea64b4546d441cde00d8c7def62405ed28a89841a181dc6ba93871845254.
The test-created src/ge_nwp_coordinator/_rw0_d1_probe_temp.py is NOT in A's inventory.
All 327 existing files stay policy-read-only. No 0009 or product fixture repair.


1.1 Authentication and exact present evidence

Authenticate M, embedded U/T/S/R and current A before payload use. M/U/T/S: at most
500 regular members, 32 MB per member, 64 MB expanded each; R: 500, 2 MB, 20 MB.
E/Q only when needed for a specifically missing carried proof. For A use the bound
limits above. Validate normalized safe relative regular unencrypted names, Unicode/
casefold uniqueness, no traversal/link/special/prefix collisions, complete self-
excluding size/hash/CRC/numeric-mode rows. Cache identical archives and do not
restart source-history reconstruction unnecessarily. Missing named input => identify
it; no namesake search, inferred attachment path or new standalone-report gate.

Read M's full report, policy, census/freeze, baseline/calibration/reach raw data,
construction/cleanup helper code, current source rows, readiness/closure/residual
ledgers, process mistakes and cleanup. Read U's representative/runtime/containment
source and logs, and relevant T/S/R proof. Inspect programs as data before adapting
into new audit-owned helpers. Never execute archived packaging/provenance/cleanup
or supplied source by accident.

Reauthenticate all A source payloads and rebuild the exact 327-file tree without
Git. Compare all fresh/reused master/causal/direct/smoke/full copies, numeric modes,
and extras. No candidate repair if a present copy differs; stop on binding failure.
All 327 existing endpoints remain immutable. Only the two already permitted,
initially absent _rw0_d1_probe_temp.py slots may be created by their unchanged test.

ChatGPT receiving checks are DATA/STATIC checks, not another live execution:
- M and nested U/T/S/R authenticate; current A bytes reconstruct the exact tree.
- All fifteen complete M captures equal A: five initial, five post-synthetic, five
  postcleanup. These are byte/mode/source-tree records, NOT hardlink-free custody.
- QtcM equals U/Qtc plus exactly five metadata lines. Baseline stat/lstat denied
  five entries; final stat/lstat admitted all twelve. No extra content/write rule.
- metadata_calibration stdout has 46 distinct rows. Seventeen of nineteen negative
  operations deny with EPERM; only preplaced-hardlink data and write-open succeed.
  Both W slots round-trip and disappear. Parent synthetic exit0 records observation;
  aggregate qualification FALSE is the decisive result.
- The read is Path.read_bytes() of the WHOLE 37-byte safe sentinel, retaining first
  byte 0x72. The open is O_WRONLY|O_APPEND, then close, no O_TRUNC/O_CREAT/write call.
  Canonical and symlink routes both deny. Captured hashes/size/type/mode remain equal.
- Separate inner os.link to a new scratch path returns EPERM, destination absent.
  This is only one source/destination class; it does not qualify a general link gate.
- Raw separate stdout/stderr and recorded helper/policy hashes match archive bytes.
  Helper/policy hashes were calculated after the subprocess, not a separate prelaunch
  source freeze. The records lack a full PID/reaping/monotonic trace.
- Root target dev/ino is recorded before alias creation; alias rows contain no dev,
  ino or nlink. Cleanup code checks dev/ino equality, receipt reports aggregate
  success. Do not invent absent raw numbers. New controls MUST retain them.
- No Qtc-vs-QtcM preplaced-alias comparison occurred; do not attribute the behavior
  to the metadata additions or universally to every Seatbelt configuration.
- Cleanup removed eleven named own paths, restored original ten root entries and
  preserved source copies. It removed the two md root sentinels; current identity
  cannot be inferred from their former names.
- No original forty-control rerun, scoped-signal requalification, observer calibration,
  candidate representative/99/direct/FULL or substantive probe ran under QtcM in M.
- Only G01's status changes from U; all 56 IDs persist, 31 mandatory-open = G01 + 30
  substantive. No earlier verdict becomes acceptance.

R/S/T/U executed evidence carries only through exact requirement -> source/policy/
helper -> valid setup and reached predicate -> actual raw outcome -> stated limit.
Do not discard it because M stopped, or upgrade it to WA1 proof. S C4 remains complete
in its normalized scope: seven blocks, 28,910 events and 28,388 SQL classifications;
not expanded private SQL, and no automatic rerun. T's Qs direct passed all60; its
complete FULL has9469 passes and99 failures. U's dedicated oracle and D1 representatives
passed; both generated helpers failed on stat of an immediate root entry. These are
not a new complete-suite pass under QtcM. The writer's missing observer/checkpoint
limits remain as section4 states.

1.2 Stable remaining substantive predicates

The frozen 56-row ledger is unchanged:
audit/evidence/RESIDUAL_LEDGER.json SHA-256
fffc8d2f50046c1fa8df3b0f1d63c1c16348e2f628d5c07dd3d6c6d0b4bbcd56.
Preserve every row, history and exact scope. Add separate WA1 assurance records rather
than silently changing the product acceptance inventory. G01 includes the runner
limitation, but its final compatibility closure still needs the unchanged actual tests.

The following thirty substantive rows remain mandatory:
- C1A01: wrong selected acceptance reference.
- C1A02: missing selected acceptance fact.
- C1A03: foreign selected acceptance lineage/decision/digest.
- C1A04: legitimate unrelated acceptance fact coexists in the same owned managed store.
- C1B03: graph role/cardinality/order and self-digest exclusion.
- C1B04: repeated-column equality and alias disagreement.
- C1B05: remaining P0/phase/Section41/C1/V22/P1 observation and evidence associations beyond source3.
- C2A04: first physical match or exact earlier-match implication for rw0_terminal_contexts.p1_decision_ref.
- C2A05: first physical match or exact earlier-match implication for rw0_terminal_outcomes.outcome_value_ref.
- C2A06: first physical match or exact earlier-match implication for rw0_terminal_outcomes.phase_basis_ref.
- C2A07: first physical match or exact earlier-match implication for rw0_terminal_outcomes.decision_ref.
- C2A08: first physical match or exact earlier-match implication for rw0_terminal_results.result_ref.
- C2A09: first physical match or exact earlier-match implication for rw0_terminal_results.outcome_value_ref.
- C2A10: first physical match or exact earlier-match implication for rw0_terminal_receipts.receipt_ref.
- C2A11: first physical match or exact earlier-match implication for rw0_terminal_receipts.mutation_ref.
- C2A12: first physical match or exact earlier-match implication for rw0_terminal_receipts.family_route.
- C2A13: first physical match or exact earlier-match implication for rw0_terminal_receipts.phase_basis_ref.
- C2A14: first physical match or exact earlier-match implication for rw0_terminal_receipts.p1_decision_ref.
- C2A15: first physical match or exact earlier-match implication for rw0_terminal_receipts.context_ref.
- C2A16: first physical match or exact earlier-match implication for rw0_terminal_receipts.outcome_value_ref.
- C2A17: first physical match or exact earlier-match implication for rw0_terminal_receipts.result_ref.
- C2A19: damaged self-digest family refuses exact/winner and stays unresolved.
- C2A20: foreign complete winner and original absence exclusion classifications.
- C2B11: stale in-memory lease versus durable issuance and closed session.
- C2B12: receipt-last boundary and second readback failure/rollback.
- C2B13: recovery cleanup uncertainty and no automatic retry.
- C3A02: remaining context FK and unique route predicates with independent unoccupied targets.
- C3A03: remaining outcome FK, unique and nullable pair predicates.
- C3A04: remaining result FK/composite and route predicates.
- C3A05: remaining receipt FK/unique/composite/profile/blob predicates.

Do not expand finite predicates into an unbounded Cartesian matrix. Exact FK/owner
implications may delimit impossible first-match specimens; overlap in complete
families does not automatically settle damaged/partial/foreign cases. An unrelated
acceptance fact must legitimately coexist in the SAME managed store, not necessarily
the same hardcoded fixture chain. A replan mismatch requires no hash collision.
Ordinary audit-fixture difficulty is not a new architecture or authority decision.

1.3 Single-engagement sequencing

1. Authenticate source/evidence and prepare WA1, fresh owned data and current layout.
2. Prove contaminated-workspace refusal, clean admission, runtime noncreation/move
   protection, and all unchanged controls under exact QtcM. Freeze WA1/helper revision.
3. Rerun all four unchanged U representatives, then the EXACT99 failed T IDs in their
   frozen order. A changed but failing predicate is not a pass.
4. Once compatible, run fresh complete direct and selector-free FULL BEFORE more
   residual custom-fixture authoring, under that same WA1+QtcM revision.
5. Finish the thirty substantive residuals and genuinely open A01–A18 obligations;
   reconcile all old/new/invariant proof and final-suite outcomes for disposition.

This continues the prior explicit regression-before-residual launch-order decision.
Existing R/S/T bounded causal work satisfies the need to inspect and probe before a
long suite; unperformed coverage alone does not make launching regression unsafe.
A known material source defect, source drift, unsafe dependency, containment failure
or broken WA1 precondition does bar execution. Correct ordinary audit-only errors on
fresh owned state with failed records retained. No routine user relay between stages.
If a practical execution limit prevents completion, retain the exact attempted or
unattempted predicate and smallest restart point, not only category names.

2. SUBSTANTIVE REVIEW — THE EXPLICIT TWO-LAYER AMENDMENT

The earlier whole-operation zero-current-stop-SELECT criterion failed under the
old mandate. That blocked result remains true. The engineering decision is to
preserve mandatory shared storage safety, not to skip it to satisfy a terminal
history test. The current candidate is judged against the following amendment:

Layer 1: existing operational admission remains mandatory. Session/process/thread/
lease validity, database binding/custody, BEGIN IMMEDIATE, exact managed schema,
history/catalog/posture and invariants, writer ownership/fencing, and current
protected disclosure remain intact. The existing global_stop_current singleton
shape validator may read that current row only for managed-store validity.
Valid active/clear status, version, timestamp and directive identifiers must not
be compared with saved terminal stop or turned into current effect permission.
Denied/unreadable/malformed managed state may prevent disclosure or leave recovery
unresolved. It must not be misclassified as stale terminal history or definitely
absent original execution. No cache, successful-assessment stub, invariant-skip
flag, alternate connection/controller, or production validator weakening.

Layer 2: historical checked read, receipt-present replay and recovery use saved
full postimages/stop and checked immutable predecessors after admission/fencing.
The five current-head tables are not consulted during the historical operation.
Current-stop reads are permitted only at the existing shared invariant check,
not as a general table-read exemption or later semantic terminal query. Receipt
is first TERMINAL-FAMILY lookup, not first SQL statement. Exact original result,
time, graph, receipt, source associations, protected disclosure, immutable
acceptance binding, complete competing-winner/absence proof and uncertainty
classifications remain required. Historical operations do not require recording
permission or renewed acceptance-unclaimed eligibility. Fresh receipt-miss
recording retains actual current five-head/stop checks unchanged.

This amends only the overbroad current-stop-query requirement. It is not a waiver
of the constructor defect, five-head independence, disclosure, SQL grammar,
transaction safety, audit isolation, or other cumulative acceptance controls.
Verify the two owning documents state the distinction and preserve the old
failure as history; do not create another silent interpretation of either layer.

Inspect at minimum the complete changed witness module, changed tests and docs,
full terminal contracts/rows/plan/SQLite owner, and actual shared admission call
chain (not only wrapper names). Current anchors:
  sqlite_transition_transaction.py:2759–2779,4753–4773
  sqlite_migration.py:2477–2523
  .docs/rw0-terminal-outcome-physical-closure.md:177–220
  .docs/sqlite-operations-and-recovery.md:722–730.
Python basenames are under source/src/ge_nwp_coordinator/; docs under source/.

2.1 Independently test the repaired constructor and mutable aliasing

TerminalHeadWitness at _rw0_terminal_head_witness.py:48–96 must validate ordinary
construction, not only checked factories. Independently test valid direct/factory
triples for accept and replan and all five typed owner roles (8/9/41/9/8 fields,
valid nulls, self-digests). Exact bytes, outer tuples, dictionaries, keys and
scalar types precede hostile comparison/coercion. Bytes, full rows and compact
coordinates must match rather than silently replacing invalid supplied parts.

Require negative controls for the previous malformed type triple and b'{}'/empty
postimages, bytes/list/tuple/dict/string/int subclasses, bool-as-int, wrong arity,
missing/extra/reordered roles or fields, wrong schema/digest, noncanonical and
oversize bytes, and valid canonical bytes paired with DIFFERENT valid rows or
projections. Calibrate a shared/per-instance hostile equality counter, clear it,
and verify zero hostile calls per invalid construction. Preserve built-in
positives and process-control propagation.

Mutate caller-owned maps and separately returned maps, then re-read both views
and canonical bytes and run normal downstream verification. They must remain
checked and unchanged. No unvalidated object token/factory escape or recursion.
Do not demand security against arbitrary reflection/object.__setattr__; that is
not the selected boundary. Verify unchanged wire fields/schema/digest domains
and valid consumer behavior, including exact original P1 replan operands.

2.2 Independently prove complete-operation phase behavior

Use real private WriterSession read, receipt-present record/replay and recovery,
not just a terminal helper. Trace and attach observation/denial at the actual
acquisition/controller opener aliases and account for every operation connection.
The candidate observer labels the full managed wrapper; independently establish
which SQL is genuinely in _verify_global_stop_current_shape. A phase label alone
does not prove shape-only use or permit arbitrary managed-phase stop semantics.

Observe real unchanged validator, ownership-read and issuance/fencing functions;
observation wrappers must call the real function and return its actual result.
Do not replace admission with a successful assessment or patch the predicate
being proved. Capture connection, phase, table/column and allow/deny results.
Calibrate each attached authorizer with owned allowed and intentionally denied
queries. Trace acquisition separately, including any connection work before the
observer attachment, and prove it cannot hide a five-head/later-stop lookup.
A zero-callback claim at the wrong alias is invalid. Column callback counts are
not SQL-statement counts or a fixed product invariant.

Required current-byte controls:
- real fenced accept and replan commits, then coherent later movement of every
  head and valid active/clear stop fixtures; under the layered denial policy,
  exact read/replay/recovery preserve original result/time/witness/graph/receipt
  and acceptance facts without new terminal or protected-row movement;
- original absence with positive/negative old-execution exclusion; complete
  compatible and incompatible competing winners under that same policy;
- deny the ACTUAL managed-stop read during admission: safe operational refusal
  before protected terminal-family handling, recovery unresolved where the
  unchanged controller so classifies; no no-write mislabel as stale history,
  definite absence, hidden retry, committed result or protected disclosure;
- malformed actual stop row or real query-return tuple, with validators intact:
  integrity failure rather than ordinary currentness; fault removal restores
  valid operation; bound process-control behavior remains unchanged;
- fresh receipt miss reads all five actual heads and stop. Stale expectations
  conflict without writes; correctly expected valid changed stop follows the
  current normal-record rule without conferring executable permission;
- denied/expired/foreign/malformed disclosure, closed/stale/fenced session and
  unavailable managed store remain non-disclosing. Fresh recording permission
  stays separate from historical protected disclosure and stop shape.

All synthetic later states/fault seams must be described as such. Do not call
a direct fixture UPDATE a newly supported product operator transition.

3. COMPLETE CUMULATIVE A01–A18 REGISTER AND CAUSAL OBLIGATIONS

Review the entire baseline-to-current terminal change, not only the five-file
repair. Supply exact archive-relative source/doc/test/SQL coordinates, severity,
and evidence class for every row: contract/current code, inspected test design,
retained record, independent execution, inference or limit. Unchanged bytes and
prior passes do not automatically discharge current mandatory controls.

A01 Authority: exactly five private normal terminal facts, separate from P1
 decision/acceptance, standing-policy grants, source facts and executable
 permission. No cancel closure, live supplier/contact, ES/Bridge/Git effect,
 service/scheduler/autonomy or publication authority.
A02 Preservation: legacy terminal V1/four validators, P0/P1 meaning, WorkSpec,
 Decision Basis/command-digest v2, preassignments, D1/D2, generic receipt, public
 StateStore/package exports unchanged. Audit original shared catalog/controller/
 writer-session terminal integration even though this immediate repair froze it.
A03 Grammar/types: closed command/context/outcome/row/result/recovery/witness
 schemas, exact built-ins before equality, canonical UTF-8/JSON and duplicate
 rejection, bool-as-int, safe refs/digests/calendar time, budgets and null pairs.
 Include direct constructors, factory consistency and aliasing; resolve A03/O1.
A04 Identity graph: independent domains/acyclic preimages, four sibling refs and
 route, optional assertions bound in command digest but not preassignments,
 graph role/cardinality/order, self-digest exclusion and repeated-column equality.
A05 Original operands: original P1 command and private replan operand transient;
 complete checked predecessor association required. Missing/inconsistent private
 content cannot be reconstructed from a safe digest or yield false certainty.
A06 Source association: actual checked P0/phase/Section41 A/C1 rank15/V22/P1
 chain and validation/review/proposal/result-set/observation relationships;
 membership counts or digest strings do not independently establish ownership.
A07 Acceptance: bind existing immutable acceptance only for accept; never create,
 mutate or replenish it. Wrong/missing/foreign facts reject. Legitimate unrelated
 facts must coexist without preventing another allowed terminal branch. No
 historical acceptance-unclaimed recheck.
A08 Heads/stop: observed full five-row witness, source/adapters/digests/links,
 replan historical P1 postimages, fresh actual currentness and stop facts; prove
 the precise two-layer amendment, not the withdrawn zero-stop-read property.
A09 Transaction: existing fenced lease/capability/controller; receipt-first
 terminal lookup; one captured time; protected posture/source/current/route
 ordering; context/outcome/result readback, receipt last, capability invalidation,
 one commit attempt, rollback/cleanup uncertainty. No application-head/stop/
 decision/effect update by terminal closure.
A10 Read/replay: original complete result/time/graph/receipt and source/witness
 reauthentication; current protected disclosure with mandatory store admission;
 no five-current-head or later semantic stop query, cognition/process rerun,
 fresh recording permission or acceptance-eligibility requirement.
A11 Recovery: complete exact original family or exhaustive original absence and
 exclusion, or complete compatible winner, only. Partial/foreign/damaged/aliased/
 incompatible families unresolved. No winner result disclosure, hidden retry,
 fragment repair or durable private-template fallback.
A12 Error/cleanup: failed or malformed reads stay operational/integrity, valid
 actual drift stays currentness. Stale/closed/fenced sessions, pre/postcommit,
 applied-commit/lost-return and cleanup uncertainty, KeyboardInterrupt/SystemExit/
 GeneratorExit propagation at the actual fresh/read/recovery/cleanup seams.
A13 Schema/admin: four STRICT immutable normal-only tables/eight guards;
 timestamp grammar, FK/unique/composite links/phase/decision/route occupancy,
 nullable pairs, blob bounds, zero seeds, current catalog/checksum/generation 2;
 exact fresh/prefix migration and old-binary/obsolete-0008/partial/unknown refusal.
A14 Connected normals: actual preseal source variations through real P0/D1/D2/
 Section41/C1/V22/P1/terminal owners; five distinct normal positives and detached
 negative; read/replay/recovery and no forbidden contact or protected-row change.
A15 Docs/assurance: cumulative current-versus-historical status, explicit amendment
 and private scope; fixed source/hash/AST/import/schema consumers and predecessor
 reconstruction retained; no dynamic oracle, skip/xfail or broad guard stripping.
A16 Privacy/artifacts: complete postimages remain safe owner metadata; no private
 replan text, raw capsule/prompts/process results, handles/PIDs/credentials in
 terminal rows or unsafe errors. Grammar review plus independently observed
 canaries; classify raw-index metadata, checkpoints and failed artifacts.
A17 Retained evidence: exact input/source/patch/commands/env/observer outputs/
 JUnit/IDs/warnings/captures and overlapping counts; limits in section 4 below.
 No writer record or causal-register label is independent execution.
A18 Independent validation: reached current-source causal probes and direct
 suite, independent SQL/admin controls, selector-free collection/FULL completed
 with exact IDs, outcomes, warnings and source-mode preservation. No live-state
 or production-readiness inference.

The following controls remain mandatory, including previously unfinished ones:

(a) S01 full-witness family: for EACH role, check complete field capture, valid
 nullable values, supported maximum witness bound, bad owner self-digest, valid
 self-digest with wrong immutable predecessor, wrong owner/link, and actual fresh
 head movement versus changed caller expectations. Use fully resealed synthetic
 histories so owner/context/outcome/result/graph/receipt digests are internally
 valid and the real relationship predicate is reached. Pair every resealer with
 a valid family built the same way. Restore ordinary verification for the actual
 read/replay/recovery. Prior program-only evidence is not five-role proof.
 No truncated witness, v1 fallback, desired-row synthesis or current-row backfill.

(b) Source/operand/acceptance: fully resealed detached validation, review,
 source-invocation and proposal associations, including a DISTINCT forged V22
 proposal reference rather than only a proposal digest; wrong/missing/foreign
 acceptance; LEGITIMATE unrelated acceptance-fact coexistence; inconsistent
 private replan content sharing a claimed safe identity across record/read/
 replay/recovery; no new process or private-text persistence. The single-chain
 fixture's inability to construct an unrelated fact is not proof of impossibility.
 Build coherent independent synthetic state through checked owners, or document
 exact invariant proof and the remaining limitation. Do not credit an incoherent
 split-reader or early FK/digest failure as the intended relationship test.

(c) Disclosure/recording: all selected finite posture predicates, including
 positive, denied, expired, malformed, foreign-bound and absent protected subject;
 old-execution-excluded True/False; truthful claimed False/None after accepted
 P1. Fresh write needs recording AND disclosure, historical operations disclosure
 only; command reuse/assertion mismatch cannot disclose a protected result.
 Complete the expired/malformed/foreign/protected-absence matrix rather than
 inheriting earlier positive/negative permission examples.

(d) Physical routes: derive all original occupancy routes from the checked
 code (the preceding audit identified 17). Seed EACH route physically in a
 separate owned coherent scenario, with valid positives and relevant partial,
 foreign or damaged family states. Mocking query return values alone is not
 physical occupancy evidence. Check exact/winner/absence classifications and
 no winner disclosure or retry. If a route is not representable under an owner
 invariant, prove that with exact schema/contract and record the scope; do not
 invent an invalid row as a legitimate winner or silently drop the obligation.

(e) Transaction and error matrix: faults after each of the four inserts,
 result/receipt readback, receipt-last boundaries, precommit rejection,
 one applied commit with lost return, postcommit and recovery cleanup uncertainty;
 stale lease/issuance, closed and fenced sessions; actual denied SELECT versus
 malformed selected rows across current owners; all three process-control
 exceptions at meaningful fresh/read/recovery/cleanup seams. Assert target
 rows, committed bytes, protected-state nonmovement, and actual injection hits.
 No hidden second commit or automatic retry.

(f) F01/O1 regression: independently exercise raw SQL and row construction,
 not only planner success. Use otherwise valid parent/related state, paired
 valid inserts, independent negative self-digests and the repaired existing
 _time owner. Cover invalid month/day/leap-century/year-zero/time overflow,
 canonical-format deviations, Unicode digits, embedded NUL/whitespace/nontext,
 NULL handling and valid year endpoints. Reach all three recorded_at columns;
 outcome has no timestamp. Verify failed predicates are zero/not permissive
 NULL and high-level invalid row/time behavior stays integrity/unresolved.
 Reproduce the old invalid-month predicate only in owned predecessor synthetic
 state as a grammar comparison, never claim an ordinary writer exploit.
 Recalibrate O1 independently before claiming no hostile equality calls.

(g) Five connected normals plus three unsupported cancel shapes and unsupported
 profile. Source variations occur BEFORE real artificial worker/checker/capsule
 sealing, not by relabelling passed evidence afterward. Use inspected fixtures
 for setup only; independent expected branches/facts/errors are required.
 Observe artificial local process/contact limits and privacy canaries.

Run bounded causal controls before a long FULL launch. Do not start/continue
FULL while a known material blocker already prevents acceptance. Independent
controls must state setup validity, actual reached seam, expected result/no-write
predicate, source identity and limits. Candidate tests passing are not separate
independent oracles. Any mandatory control not established remains explicit and
prevents complete acceptance unless an exact supported invariant makes the case
inapplicable; fixture difficulty alone is not such an invariant.

Independent SQL/admin expectations:
  after 0006: 68 tables / 122 triggers / 5 explicit indexes
  after 0007: 74 / 134 / 5
  after 0008: 78 / 142 / 5, application generation 2.
Execute all eight authenticated literals in disposable owned state. Preserve
pre-0008 object SQL/shape; check exact prefix upgrades, no seeds, immutable
update/delete guards, FK/unique/pair/profile/normal/blob/time constraints, and
refusal of old binary, original and S01-era 0008 checksums, old SQL with current
history, missing guard, foreign object and partial/unknown/checksum divergence.
No current schema/contract change, 0009 or product database upgrade is allowed.

4. RETAINED EVIDENCE AND INDEPENDENT VALIDATION

4.1 Reconcile the current writer records as DATA

Paths: evidence/validation/<direct|connected|focused|full>/, gate-summary.json,
phase-read-map.json, supersession-record.json and current source captures.
Require independent parsing of collection observer, execution collection,
setup/call/teardown records, explicit JUnit nodeid properties, actual launch/exit,
stdout/stderr as actually retained, warnings, and four complete source captures
per gate. Do not invent a separate stderr file for a combined log.

Expected current retained gates:
  direct: five complete modules / 60 cases / zero warnings
  connected: one complete module / six cases / zero warnings, inside direct
  focused: 126 complete modules / 8,266 cases / three known warnings
  FULL: selector-free / 9,568 cases / three known warnings.
All narrower sets must be included in FULL; totals overlap and do not add.

Ordered-ID SHA-256 uses UTF-8 JSON array, ensure_ascii=False,
separators=(',', ':'), with NO trailing LF:
 direct 229f470747840136304192b16bcd440704333967dd4edffc0830b77f6230e467
 connected 81e14e3fa1b85a7be2ea6fafac85974839145bbcb6397e6da0bb1feeba060aac
 focused 419d37ff399689788123583f614a1d8b107ef712e2368ca179cd6e65fbec5104
 FULL 25fbc4ed5094b809e8702ef8f6f10c6f9a76782a952b0ba141123b3441facdd9.

All sixteen source captures have the same 105,550-byte envelope, SHA-256
0c0b4017371a798731a63825ac63922c361189e37f5a713f5c4f7ec06e9b32cb.
Require full row equality to the different canonical source-manifest envelope,
its embedded canonical hash, correct final tree and no extra/missing paths.

The retained direct JUnit phase maps report six operation connections, 60
managed-stop column callbacks and six intentional head-denial calibrations
for EACH accept/replan scenario. Independently parse the raw properties. Do not
substitute those counts for actual phase/call-chain verification, or label them
SQL-statement counts. Acquisition has separate test observations.

4.2 Known retained-evidence limits — do not silently fill them

The active external gate_observer source and a launch-bound helper digest are
not retained in the current outer ZIP. Old nested helpers cannot prove that
current code's identity. Writer records can be internally reconciled but their
observer's nonselecting implementation is not thereby inspected. The independent
runs below must use newly audit-authored, retained, inspected and calibrated
observers. Independent fresh evidence can establish current behavior; it does
not retroactively establish the missing writer helper.

The seven-case checkpoint has receipt/JUnit evidence and a different declared
tree 85c9fea24f4f74f358f9cc59a5d323d836a04041; it lacks a complete checkpoint
source payload here. Its historical save/reopen/source-binding claim stays
qualified and supplies no final-byte credit. Similarly, one retained patch
manifest per kind is not proof of two writer runs; independently reconstruct
current endpoint/patch identity rather than invent that history.

These are disclosed retained-evidence/process limits, not automatic production
findings. Determine their actual acceptance impact. Complete current independent
source/runtime evidence must not be replaced with writer claims. Any unmet
mandatory evidence requirement is INCOMPLETE, not a pass by wording change.
Preserve failed/superseded source/test results separately. The prior audit's
live-status/path probes and interrupted FULL remain historical limits.

4.3 Required independent execution gates

Under the explicit prospective section 1.3 scheduling amendment: after current
source inspection/reauthentication, exact final QtcM readiness and observer calibration,
and with no known material candidate defect or unsafe dependency, execute these
complete regression gates BEFORE additional residual custom-fixture work.
All outstanding causal/admin obligations remain required for final ACCEPT:

1. On a fresh exact source copy, collect and run these five COMPLETE modules in
   this order (no node selector):
   tests/test_rw0_terminal_outcome_values.py
   tests/test_rw0_terminal_head_witness_regression.py
   tests/test_sqlite_rw0_terminal_controls.py
   tests/test_sqlite_rw0_terminal_migration_0008.py
   tests/test_sqlite_rw0_terminal_connected.py
   Expected 60 ordered unique passes, including six connected cases.
2. On another fresh exact 327-file copy, independently collect and run the
   repository selector-free FULL. Expected 9,568 ordered unique IDs and passes
   in the retained FULL order. No path, module, node, -k or -m selection.
3. Record collection/execution-collected/call/JUnit identities, explicit JUnit
   nodeid properties from the start, all setup/call/teardown results, warnings
   and real process exits. Require exact ordered agreement and zero failure,
   error, skip, xfail/xpass or failed noncall phase. An invertible JUnit mapping
   is useful supplementary evidence, not a silent substitute for the required
   explicit-property observation.
4. Independently inventory warnings. Direct has none; FULL may have only the
   three known DeprecationWarning multithreaded-fork nodes in
   tests/test_sqlite_b2c_writer_session.py:
   test_operation_guard_close_waits_and_retains_authority_until_exit
   test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
   test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock.
   Owned paths/PIDs may differ; other class/node/message differences require
   investigation, not filtering or suppression.
5. Capture complete raw bytes/modes/extra-file inventory immediately before and
   after collection AND before and after execution, with source-tree rebuilds.
   All 327 endpoints and modes must remain unchanged. At every boundary capture there must be no generated extras; only the prospective, exact-path transient fixture exception in section 5 is allowed during the inspected D1 test.
6. Audit probes remain outside candidate discovery and separately counted. An
   independent focused 8,266-case rerun is unnecessary if exact FULL inclusion
   is proven; do not claim one ran. No writer FULL or earlier audit count can
   replace the independent completed FULL.

Use recorded equivalents of:
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --collect-only --basetemp=<owned-collect> <complete-direct-modules>
  <absolute-python> -B -m pytest -q -p no:cacheprovider -p <audit_observer> \
    --basetemp=<owned-run> --junitxml=<owned-junit> <same-direct-modules>
For FULL remove all module/path/node selectors from BOTH commands. Inspect
pytest config, conftest and setup/child-launch seams before import. The observer
may record IDs/outcomes/warnings and add JUnit nodeid properties, but must not
select, reorder, skip, change assertions/results or suppress warnings. Keep its
exact source/digest in the evidence and bind every launch to it.

Do not edit candidate source/tests to get green results. Correct audit-only
parser/fixture/observer mistakes transparently on fresh owned state, retaining
failed attempts. A genuine candidate failure triggers findings, not retries with
weakened oracles. An interrupted FULL gets no complete-pass credit; preserve
actual partial records and absence of final JUnit/observer rather than infer
completion from displayed percentages.

5. WA1 WORKSPACE ADMISSION, UNCHANGED RUNTIME POLICY, AND EXECUTION

5.1 Stable policy and layout; narrow fixture-lifecycle authorization

ROOT is exactly:
 /private/tmp/rw0-audit-entry.daLWIE/rw0-ancestor-ts3q9uuz
Source copies stay:
 ROOT/mock_source/tc-4fd7e168a0/{master,causal,direct,smoke,full}
The ONLY source-area W slots remain:
 ROOT/mock_source/tc-4fd7e168a0/smoke/src/ge_nwp_coordinator/_rw0_d1_probe_temp.py
 ROOT/mock_source/tc-4fd7e168a0/full/src/ge_nwp_coordinator/_rw0_d1_probe_temp.py

Use fresh wa-<nonce> namespaces under existing execution, scratch, home, tmp, evidence
and denied roots. A separate calibration-sentinel namespace under mock_source is
also permitted, OUTSIDE the five 327-file source copies. Never place audit probes
in candidate discovery. Do not overwrite historical evidence/helpers or reset source.

Two exact md root calibration paths were removed by M. Sole prospective lifecycle
exception: after lstat proves both ABSENT and ROOT has the recorded original ten
regular/directory entries, recreate exactly:
 ROOT/rw0_meta_plain_md812d7d86be.txt
 ROOT/rw0_meta_dir_md812d7d86be/inside.txt
with independently created safe non-code bytes, exclusive/no-follow creation, owner
private modes, and new dev/ino/nlink/hash records. Directory creation is exclusive.
These are NEW fixture instances, not restored old identity or historical continuity.
QtcM already names their metadata; its bytes remain EXACT. Do not add another immediate
ROOT name, change root pytest configuration, relocate old files, or rewrite child
arguments to avoid the collector. If a path is unexpectedly present, record type/
identity without following it and stop; do not overwrite or unlink an unknown object.

Record a new twelve-entry membership/type census and compare before candidate launches.
Admitted immediate metadata success, protected content/deeper denial and policy
identity still require current controls. M's former pass is not current readiness.

5.2 Selected composite assurance contract WA1

A protected audit file is any regular file under ROOT outside the policy-writable
regions and two exact W slots. This includes all source copies, execution/helpers,
protected evidence/archives/ledgers, denied sentinels and root regular files.
The writable footprint is ALL of ROOT/scratch, ROOT/home and ROOT/tmp, including
historical namespaces, plus the two exact W slots when they exist. Checking only
wa-<nonce> would leave allowed historical paths outside admission and is insufficient.

The selected invariant on each ADMITTED launch:
- protected regular files are ordinary, owned, non-symlink files with st_nlink == 1;
- their current nonzero (st_dev, st_ino) identities do not appear anywhere in the
  policy-writable footprint;
- the five active source copies, installed exact runtime bindings, policy and
  active audit helper bytes/modes satisfy their separate authentication requirements;
- source/active helper/evidence ancestry and root membership are stable and not
  writable by the workload except at expressly admitted scratch/home/tmp/W paths;
- no source/evidence/protected file descriptor is inherited by the candidate;
- the trusted supervisor creates no cross-boundary alias or in-place promotion while
  an admitted workload is alive, and serializes all owned launches/publication.

A protected file with nlink>1 is not excused merely because its second pathname is
not found in the new scratch suffix. Reject before launch; no filesystem-wide link
hunt is authorized. Duplicate protected identities also reject under this bounded
single-link preparation model.

For EVERY preexisting regular file reachable in the ENTIRE writable footprint,
also require an explicit owned-audit construction/origin classification and a closed
hardlink group: the number of distinct ordinary paths with its (dev,ino) inside
that footprint must equal its actual st_nlink, and its identity must not occur in
the protected set. This detects a writable alias of an outside file without reading
or searching that outside file. nlink1 is the ordinary single-path case. At a clean
prelaunch boundary, unknown historical writable data is NOT admitted merely because
its UID matches. Use already named safe creation/evidence records or stop with the
unclassified entry; do not inspect arbitrary content or delete old state to proceed.
During tests, legitimate internal writable groups may change; after closure check
group closure again and preserve any unexplained mismatch. No need to reject valid
within-writable hardlink fixtures that the unchanged source deliberately creates. Directory nlink is not subjected to a regular-file
nlink==1 rule. Device/inode uniqueness is scoped to actual file objects at this
observation, not a permanent global object identifier.

This deliberately changes the old supervisor-preplaced hardlink fixture's required
result from 'contained file operation denied' to 'launch refused by WA1'. Record the
old actual read/open and the new ADMISSION_REFUSED separately. Never give denial
credit to nonexistent paths, a hidden fixture deletion, posthoc hash equality, or a
workload that was never admitted for an unrelated reason.

A workload may create ordinary internal hardlinks/symlinks among its OWN writable
test state where the unchanged tests require them. WA1 does not impose a product
no-hardlink rule or force st_nlink==1 on every temporary test file during execution.
The forbidden relation is protected-to-writable identity sharing. Protected single-
link checks plus no protected move/link runtime permission must maintain it.

This is bounded trusted-workspace assurance, not security against hostile same-UID
external file races or a malicious supervisor. An external actor can violate a
snapshot assumption; do not describe before/after scans as continuous enforcement.
Mechanical admission, measured runtime denial and serialized trusted preparation
are all required. If any is unestablished, stop before candidate execution.

5.3 Implement the gate only in newly authored audit-owned helper code

Inspect the inherited stdlib-only supervisor/capture designs first. Put the new WA1
code in read-only execution/wa-<nonce>. Retain exact helper bytes/digests; no repository
component, generic service or installation. A single launch_if_admitted path must
perform admission immediately before the actual sandbox-exec call. No candidate
launch may have a bypass path or rely on a human assertion that the layout is clean.

New narrow observation authorization:
- The trusted supervisor may make a bounded recursive METADATA census of ROOT's
  seven existing subtrees execution/mock_source/evidence/denied/scratch/home/tmp,
  the immediate root regular files, and the two exact W paths.
- At most 100,000 entries and depth64, sufficient for this owned artifact layout.
  Record counts; a genuine bound excess is a specific limit, not a silent omission.
- No following symlink directories, mount crossing, device/FIFO/socket read, remote
  directory, user-home, repository, Downloads or system-runtime tree scan.
  Record link text with readlink and lstat only when classifying a known owned link;
  do not chase its target for data. Active launch ancestors cannot be links.
- Classify known inherited synthetic aliases and temporary state before use. Unknown
  object/type/ownership or unavailable scope is not cleared by deletion. Preserve
  old namespaces. A scan may safely record known symlink metadata without following
  it; their runtime effects are tested separately, never treated as hardlinks.
- Metadata-only inspection of old evidence does NOT authorize reading all historical
  contents. Byte reads stay confined to named inputs, active source/helpers/policy,
  explicitly selected carried evidence and owned synthetic targets.
- Fresh fstat/lstat, not stale cached DirEntry attributes, supplies dev/ino/nlink/type/
  mode/UID/GID and size/mtime_ns/ctime_ns where recorded. Use no-follow/descriptor-
  relative operations and stable directory handles for active paths where supported.
  Bind opened source/helper bytes to the same fstat identity. Do not rely on a
  pathname string, equal content hash, or file permissions alone to distinguish aliases.
- Protect a complete inventory epoch. The gate helper/record itself is covered:
  create new evidence records exclusively, not by overwriting a possibly aliased
  path. Log the exact prepare->admit->spawn interval and gate/source/policy identities.

Source/helper/evidence materialization must write independently created regular files
from authenticated raw bytes, using exclusive no-follow creation. No os.link,
link-copy/reflink assumption, archive hardlink extraction or rename from candidate-
writable paths into protected provenance. Use no-copy alias deduplication nowhere.
Verify resulting distinct inode identities and source modes. Existing correct source
copies may be reused only if they pass current WA1 and full byte/mode inventory;
do not silently rebuild a mismatched present copy or break a discovered old link.

Before launch, the supervisor closes its preparation writers, checks protected
identities/link counts and the entire allowed mutable footprint, checks active source/
helpers/policy and empty W slots, and records ADMITTED or named ADMISSION_REFUSED.
Record that refused attempts spawned zero candidate/import/pytest processes. Admission
failure does not authorize 'repairing' historical files. Synthetic negative-fixture
cleanup alone is allowed after its refusal evidence is retained.

No candidate or contained child runs concurrently with trusted preparation changes.
The supervisor's continuing actions while one runs are limited to process/pipe
supervision and writing NEW independently created protected records. It must not
copy/move candidate output to protection or create path aliases until owned children
are closed. Newly created protected records must also have link count one.

After child closure:
- repeat full candidate bytes/modes/extras and protected identity/link-count checks;
- reconcile mutable entries against protected identities, retaining any violation;
- distinguish postcheck detection from prevention; a postcheck failure invalidates
  the launch's acceptance credit even if pytest is green;
- transfer bounded provisional output by reading a no-follow ordinary owned file,
  binding it with fstat (identity stable around read), and writing independent bytes
  into an exclusively created protected evidence file. Reject special files, source/
  evidence aliases, unclassified symlink returns, unstable identities or unexpected
  protected targets. Never rename/hardlink provisional files into protected evidence.
- candidate output may be internal test data, not trusted executable authority; no
  supplied packaging/helper program may be run to publish it.
- preserve raw stdout/stderr captured by the supervisor, actual exits and all failed
  attempts. No sanitized text masquerading as the raw run.

Do not scan global processes or runtime libraries to manufacture a hostile-host
guarantee. Exact selected runtime identities and prior protected runtime permissions
stay separately bound. WA1's inode census concerns audit-owned files, not every
system inode or an arbitrary user's storage.

5.4 Admission calibration and runtime preservation — finite, decisive controls

Qualify the ACTUAL gate/launcher revision, not a separate checker never called by it.

A. Clean positive:
- own regular sentinel bytes under protected source-like/mock_source, execution,
  evidence/denied and root-metadata-only locations, plus independent writable data;
- record both pathname identities, fstat/lstat and link counts. Identical bytes in
  two distinct independently created files MUST NOT be mistaken for a hardlink;
- admit a clean layout, launch trusted marker/SQLite under QtcM, retain actual
  marker and process result, and pass closing checks.

B. Contaminated PRELAUNCH negatives:
- trusted supervisor places a REAL hardlink from one disposable protected sentinel
  into a mutable location; save both dev/ino/nlink records before/after os.link;
- invoke the same launch_if_admitted path used for candidate work. It must refuse
  BEFORE sandbox-exec/candidate imports, not run the marker and reject afterward;
- cover root/evidence-unreadable and source/helper-readable protected classes, and
  the three writable trees plus the two W slots, batched using the same finite design;
- include an allowed HISTORICAL writable namespace in one controlled case, not only
  the new suffix. Use a fresh explicitly owned calibration directory beneath that
  existing allowed root; do not modify any old contents;
- retain target unchanged identities and gate reason. Remove only the exact newly
  installed synthetic alias after refusal evidence; restore nlink1 and re-admit a
  clean paired positive. No automatic cleanup of an unexpected real artifact link.
- a same-byte independent-file control must admit; a symlink/special active source
  or launcher path must refuse without following content outside owned fixtures.

These are admission results, NOT sandbox EPERM results. The old preplaced-hardlink
observation remains an acknowledged QtcM limitation. No contaminated layout proceeds
to a candidate run merely because the trusted supervisor promises not to exploit it.

C. Runtime noncreation/nonmovement from an ADMITTED layout:
- actual contained os.link attempts from disposable protected readable source/helper
  and protected unreadable root/evidence/denied targets into scratch/home/tmp and
  both exact W slots must fail with EPERM/EACCES. Include supported descriptor-relative
  forms when the child can legitimately obtain the directory descriptors; do not
  pass it protected descriptors from the supervisor.
- observe source/destination dev/ino/nlink, attempted operation, errno and absence/
  nonmovement. The prior root->scratch denial does not cover every class above.
- actual rename/relabel attempts moving a disposable protected sentinel into an
  allowed mutable path must deny. Use synthetic targets only, never sealed source
  or governing evidence for destructive-negative controls.
- revalidate before/after identities and no protected link-count increase. If any
  link/move succeeds, preserve the result, send no data write through it, and stop
  before candidate work; no policy variant, silent waiver or second permission budget.
- ordinary hardlink creation between independent owned WRITABLE files may succeed
  as the positive demonstrating that the kernel operation was actually reachable;
  contain and remove only that fixture. Do not blanket-disable filesystem functions
  or alter tests that intentionally use valid within-scratch aliases.
- preserve actual canonical and symbolic-alias data/write denials, and W create/
  write/read/unlink positives with both W paths absent afterward. Runtime hardlink
  controls use real link creation, not simulated return values.
- batch the distinct policy source/destination classes in the existing parent/fork/
  exec/fork-then-exec design. Do not multiply unrelated product test combinations or
  create a new runner platform.

D. Complete inherited boundary:
- all original forty ordered controls in each of the four process forms; keep every
  canonical/symlink/source/helper/evidence/denied/depth predicate. The new WA1 rejection
  controls are additional and separately named; never relabel an old pass.
- scoped signal readiness with actual delivery/reaping and live outside plus separately
  instantiated identical-profile nonmember exclusions, original owned PID/group/session
  scope, no unrestricted/same-UID signaling change.
- same owned, noninherited live listening peer with before/after nonce handshakes;
  actual bind/connect EPERM/EACCES for each role, no absent peer/errno42 success.
- fixed true, Python marker, SQLite; old termcap resource identity rechecked at its
  exact bound path, no new search, suppression or child environment modification.
- all twelve immediate ROOT metadata controls, canonical protected root content,
  deeper child metadata/data and recursive-listing denials. Root census stable.
- zero source byte/mode drift. Existing temporary test slots absent at boundaries.

Use transparent source-bound observation. No candidate code appears in these controls.
Known synthetic symlink fixtures needed by the inherited forty controls can be precisely
allowlisted as calibration data, without following them during trusted scanning;
their target/runtime denials remain mandatory. Preplaced cross-boundary hardlinks are
NEVER an admitted calibration exception. Remove all poisoned fixtures before clean
runtime controls and all temporary W fixture contents before candidate execution.

No new boundary is qualified by counts alone. Review gate logic, complete policy,
actual outputs, descriptor inheritance and publication path together. The final
bundle must state the conditional trust model and no-hostile-concurrent-actor limit.
If WA1 coverage or runtime maintenance cannot be established, return INCOMPLETE at
that exact predicate; do not choose a VM, install software, broaden QtcM or waive
the boundary automatically. No additional user approval is needed if it passes.

5.5 Actual compatibility, complete suites, residual closure

Freeze WA1, policy, bootstrap, nonselecting observer and external supervisor bytes.
Recalibrate the observer on independent synthetic cases with its intentional warning
and explicit rw0_audit_nodeid properties. Reuse inspected designs; instrumenting a
run is not an adversarial attestation authority. No selection/reordering/skip/filter.

Run all four exact unchanged representatives from U/audit/execution/rep4_ids.json
under the composite final runner:
- both generated mutant and generated checker helper families;
- dedicated import/collect/execute empty-stderr oracle;
- D1 temporary-module sanitized-environment/FD test.
Record unchanged real child argv/cwd/env and raw outputs. A representative-only
transparent wrapper may call original run/Popen with identical arguments and return
its exact original result/exception; remove it before final suites. Do not intercept
pathlib/stat/scandir, rootdir, ignore hooks, child environment or return code.

If all four pass, replay the EXACT99 failed T IDs in their frozen order. U's list
and T JUnit must agree; compact UTF-8 JSON array ensure_ascii=False,
separators=(',', ':'), no LF, SHA-256
f242e64dd779abab8a7ff39c64a69e852524b51b85ee1d61b3f0228b0a178224.
No omission/parameter expansion or adaptive green selection. Preserve old first
failure -> new reached predicate/outcome for each. This selected diagnostic is not FULL.

Then, without routine relay, run new complete direct60 and selector-free FULL9568
collection/execution per section4 under the SAME final WA1+QtcM. Use fresh provisional
state and the authenticated direct/full source copies at unchanged W paths. Unexpected
collection drift is investigated, not filtered to hit an expected count. No -k/-m,
node, module or path selector on FULL; direct uses exactly five complete modules.
Do not continue a long FULL after a known material candidate defect, source drift,
unsafe dependency, admission violation or containment failure. A residual coverage
row alone is not a source defect. An interrupted FULL has only actual partial credit.

Only the unchanged D1 test may temporarily create its source-area W filename during
the complete FULL. It is absent before/after collection and execution; no other
source extra is permitted. Do not remove an unexpected leftover before reporting
a failed boundary. All327 original source endpoints stay immutable throughout.

After the suites, close the thirty substantive residual rows and other genuine
A01–A18 gaps, reusing valid R/S/T proof at exact scope. No full causal reset, new
semantic-contract tranche, requirement reduction, fake query occupancy, impossible
hash-collision demand or 'same hardcoded chain' restriction. Preserve old failed/
incomplete results. A green FULL does not replace independent missing causal evidence.

5.6 Runtime and evidence details

Fixed Python entry:
 /Library/Frameworks/Python.framework/Versions/3.13/bin/python3
Expected Python3.13.4 / pytest8.4.1 / SQLite3.49.1. Rehash requested/resolved/native
runtime and exact termcap file, distinguishing retained installed-binary observations
from supplied payloads. Preserve process-local encoding-hint handling without
changing host settings or secretly adding keys to test-owned child environments.

Candidate launch shape, always through real WA1:
 /usr/bin/sandbox-exec -f <exact-QtcM> <fixed-python> -I -B <frozen-bootstrap> <mode>

Explicit owned cwd, umask077, core limit0, null stdin, close_fds=True, pass_fds=(),
credential-free allowlist, C locale/UTC, owned HOME/TMPDIR/basetemp/output,
PYTHONDONTWRITEBYTECODE=1, PYTHONNOUSERSITE=1,
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, PYTEST_ADDOPTS="", -p no:cacheprovider.
Only authenticated root/src/read-only audit-observer imports in bootstrap.
Candidate children receive their unmodified source-specified environment.
Admission/root handles stay non-inheritable and are not leaked.

Retain exact command/env/cwd, immutable source/helper/policy/admission identities
BEFORE and AFTER, wall+monotonic times, PIDs/groups, bounded waits, raw separate
stdout/stderr, actual exits/signals and observed reaping. Use a FULL timeout
appropriate to the retained workload, not a synthetic-probe timeout. No full pass
inferred from percentages. Freeze exact final-suite helper versions separately
from subsequent audit-fixture changes. If admission helper/runner revision changes
for a real correction, qualify it and bind required new final evidence accordingly;
do not splice passes across revisions to invent one accepted run.

Complete source byte/mode/extras captures before/after EACH collection and execution,
with independent tree rebuilding. Full WA1 prelaunch identity and postclosure
records supplement, not replace, these source captures. Keep exact case/JUnit/call/
phase/warning order and expected digests from section4. All probes separately counted.

Supervisor emergency termination touches only its explicitly owned/tracked subjects
and receives no candidate-cleanup success credit. Transfer provisional output only
after observed closure via the safe independent-copy path above. Retain hashes/
metadata/classification of actual synthetic pyc/DB/FIFO/sidecar state without dumping
private material. Remove only newly created prospective transient fixtures AFTER
their evidence is protected. Preserve inputs, source copies, old roots and records.

At final cleanup the two explicitly recreated root sentinel instances may be removed
after comparing their new recorded identity and content; this is not deleting any
old artifact or claiming persistent runner readiness after fixture removal.
Do not claim universal unknown-descendant custody.

6. ADJUDICATION, DELIVERY AND CONTINUATION POINT

Keep M's actual containment FAIL and every old candidate/policy verdict unchanged.
Record WA1 as a new PROSPECTIVE assurance revision with the SAME QtcM bytes.
The two requirements are not interchangeable:
 OLD: runtime denial on an already contaminated supervisor-prepared layout — FAILED.
 NEW: reject that layout before launch and preserve the admitted no-cross-boundary
      invariant by measured runtime constraints and trusted supervisor discipline.
Do not report that QtcM alone now supplies inode-based protection or that the new
gate was active during earlier runs.

Assemble one A01–A18 ledger and the stable56-row residual ledger with carried
independent execution, carried static/data/writer records, new proof, exact supported
invariants and unresolved gaps. Add the WA1 control ledger separately; do not count
gate rejection as a source-association, migration or product authority proof.
G01 closure is not thirty substantive closures.

Return one primary disposition:
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_ACCEPTED_READY_FOR_COMMIT_GATE
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_BLOCKED
 AUDIT_PROVENANCE_MISMATCH
 RW0_NORMAL_TERMINAL_CLOSURE_HISTORICAL_ADMISSION_WITNESS_CUMULATIVE_AUDIT_INCOMPLETE

Acceptance requires exact candidate bytes/modes, compliant effects, supported WA1
admission/runtime/publication boundary under exact QtcM with its disclosed trusted-
host assumptions, complete substantive A01–A18/F01/O1/S01/A03/two-layer obligations,
and new complete zero-failure direct/FULL evidence with exact IDs/phases/warnings
and preservation. No mandatory gap becomes nonblocking by wording or by passing FULL.
F03/F05 remain inherited nonblocking observations, not repairs. Missing historical
writer observer/checkpoint/provenance data retain their exact limits.

A finding states severity/type, source or runner ownership, exact member/path:line,
valid paired setup, reached predicate, actual effect, limit and smallest next action.
No candidate source fix or further policy change is authorized by a finding.
A practical completion limit identifies exact attempted/not-attempted case and
checkpoint; no vague list, fabricated finish, or future/background promise.

Save the full unique report BEFORE sealing ONE safe evidence ZIP. Include exact M
ONCE (M already contains U/T/S/R), not A's large source/history tree or duplicate
old archives. Include full self-excluding size/SHA/CRC/numeric-mode manifest,
WA1 source/revision, unchanged policy, current workspace inventories, actual
contaminated rejection/clean launch/runtime controls, final suite and causal
observer/JUnit/IDs/warnings/raw execution/source captures, versioned helpers,
all failures, closure/residual ledgers, safe publication checks, cleanup and non-effects.
The M report alone is not its payload evidence; retain the actual M ZIP.

State actual package counts/expansion and validate it within bounded limits
(1000 members, 64 MB/member, 256 MB total for the new outer, existing nested limits
unchanged; one exact6,677,682-byte M member expected). Reopen every member, and
return report/ZIP/manifest bytes/SHA plus an adjacent receipt; no requirement that
the ZIP contain its own final hash or that a separate report be attached next time.

The only candidate subject is:
 4691af58ae0ee3107b4e2e9b6b1508032944e357
Return the complete operative result inline plus actual artifact paths/identities
to ChatGPT. No live commit/publication/production action follows from this audit.
