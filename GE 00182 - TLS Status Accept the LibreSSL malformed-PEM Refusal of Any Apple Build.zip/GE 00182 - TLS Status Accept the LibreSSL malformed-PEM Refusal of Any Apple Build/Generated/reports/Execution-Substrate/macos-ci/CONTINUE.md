# macOS CI PR: continue here

STATUS (2026-11-25 07:40Z): PR #59 merged at 07:38:53Z. The squash commit is 819f712cde8fd83f5b73b2154263afa18cf29623 on trunk_dev, and its tree 630bdaa9 is the audited head tree of 7fb88b8. The audits are reports 30 and 32, and the record is ../tls-status-child-containment/25-macos-ci-pr59.md and 31-pr59-foldin.md.

What follows from it:
- "test on macOS" now runs on every ES PR. Until David makes it a required check (A30-3), the merge gate requires it green on the final head.
- A PR that adds or changes scripts tests may need lines in .github/ci/environment-only-tests-macos.txt, or ports. The rule is in that file's header.
- The product follow-up for the TLS status collector's LibreSSL grammar, PR #62, merged at 15:52:10Z as ae9aa65322954be16d5d3e354dd0aeec5d87723d on trunk_dev (audit 34, diff checks 35 to 39, no red-team by the coordinator's decision). The two LibreSSL tests now run unlisted on macOS; with #60 the list has 26 entries and 81 skips. Record: ../tls-status-child-containment/33-libressl-grammar-pr62.md, section 13.
