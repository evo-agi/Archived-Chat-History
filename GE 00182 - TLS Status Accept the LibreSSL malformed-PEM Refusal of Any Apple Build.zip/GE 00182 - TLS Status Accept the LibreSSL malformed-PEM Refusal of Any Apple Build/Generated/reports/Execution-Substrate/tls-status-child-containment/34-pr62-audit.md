# 34. Independent audit of ES PR #62: the LibreSSL malformed-PEM location matched by form

```
INDEPENDENT AUDIT REPORT
Repository:      evo-agi/Execution-Substrate, PR #62 "TLS status: accept the LibreSSL malformed-PEM refusal of any Apple build"
Audit target:    base trunk_dev 819f712cde8fd83f5b73b2154263afa18cf29623
                 topic claude/project-thread-wbmulu, commit 72eecb2ed0e74000f17c7e012868c1f9a5a94560,
                 tree bb72a78c2a950fc31b8301e7af375f0ac3a183b0
Recipe:          governed-execution.audit-patch-manifest.v2, source SHA-256
                 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified before each run)
Manifest:        beeecf25e23b524afcbbeaff3d2d1bd961a3315ed62e322b28597bb8a3126629, 5 changed paths,
                 textual_diff_sha256 6cd2a97301365282eb50e3add2a35ef0bc65023a14f3926ed9f4109c270b6398
Writer report:   33-libressl-grammar-pr62.md, SHA-256 84e4275f0210c0770de732d30dfafd2fedf110db70e1f1f7abbe561e0937be5c
Audit posture:   read-only. No subagents. Nothing pushed, no PR edit, no GitHub comment, box not touched.
Verdict:         BLOCK (two Low findings, both test or doc; the product change itself is correct)
```

All times are UTC on 2026-11-25. Audit ran 08:43Z to about 09:00Z in a fresh cloud container.

## 1. Verdict in short

The collector change is correct. `LIBRESSL_PEM_ERROR_LOCATION` matches exactly what its comment, the doc and report 33 say. A match still yields only `certificate_malformed` or `key_malformed`, both `status: fail`, and never a pass. I checked this against an independent implementation of the stated rule (400,000 fuzzed inputs, no disagreement), with targeted crafted inputs, with a timing probe, and through the real consumer functions. No finding touches security.

It is BLOCK because two stated parts of the PR are not pinned or not current:

- **A34-1 (Low, test gap):** the new test pins only some of the refusal rules the PR states. Four mutants that loosen a stated rule pass every test: control characters other than NUL, CR and LF; DEL; a relative path with a prefix; an unescaped `.`.
- **A34-2 (Low, doc gap):** the doc paragraph the PR edited still begins "The admitted malformed-material response is the fixture-proven LibreSSL 3.3.6 tuple". The code and the PR's own test now admit forms that no fixture produced, such as a `libressl-4.1` folder.

Both fixes are test or doc only. A diff check of the repair should be enough (protocol §14: fresh check of the new tip, pointed at the delta).

**Red-team scope (asked by the coordinator):** in my judgment this PR does not need a red-team. Reasons in §7. The final call is the coordinator's.

## 2. Provenance reproduction

Repo-validated, commands run in a fresh clone at `/opt/audit/es` under `umask 022`:

- `sha256sum` of both recipes in `/mnt/project-files/operating-protocol/tools/`: v2 = `c08597e2…a3ca`, v1 = `db21f2b6…60bc`. Both equal the pins.
- `git fetch origin trunk_dev claude/project-thread-wbmulu`: topic tip = `72eecb2…`, trunk_dev = `819f712…`. Base is an ancestor of the tip. One commit in `819f712..72eecb2`.
- Provenance §5.3 sequence: checkout of the tip, clean status, `git reset --mixed 819f712`, upstream `origin/trunk_dev`, v2 twice into a fresh 0700 directory. Both outputs are byte-identical, and byte-identical (`cmp`) to the writer's `33-evidence/manifest-72eecb2-vs-819f712.json`. Canonical-manifest SHA-256 `beeecf25…6629`, 5 files, all `tracked_modified`, mode 0644. No mode-bit difference.
- `git diff | sha256sum` = `a0ae126e…ce68`, equal to the writer's `33-evidence/pr62-72eecb2.diff`.
- Closing manifest after all probes (08:58Z): byte-identical to the opening one. One audit artifact, `scripts/internal/__pycache__/remote_alpha_es_tls_status.cpython-313.pyc` (created 08:50:24Z by my probe), was removed first. Nothing else was created in the audited tree. Probes and mutants ran in separate copies.
- GitHub at about 08:58Z: PR #62 head = `72eecb2…`, base = `819f712…`, `mergeable_state: clean`, one commit. `git ls-remote` gives the same two SHAs.

## 3. Coverage

Read in full: the diff (5 files); `_known_malformed_pem` and its constant (`scripts/internal/remote_alpha_es_tls_status.py:1893-1912` at 72eecb2); both call sites (`:2401-2406` in `cert_metadata`, `:2517-2522` in `key_pair`); what follows a malformed certificate (`:2504-2505` and `:2534-2535`, both `certificate_unavailable`); `run_fixed` and its argv check (`:1555-1640`, `argv[0] != OPENSSL` at `:1581`); the stream bounds (`MAX_ERROR = 8192` at `:34`); the grammar diagnostic predicate for the two negative sites (`:2026-2035`, which reads only exit code and stdout emptiness, never stderr content); the new test and the changed grammar test (`scripts/remote_alpha_es_service_tls_status_test.go:912-1076`); the Target3013 probe change; the doc section (`.docs/system_overview/remote_supported_host_alpha.md:3990-4064`); the routes doc mention (`.docs/standing_rules/remote_alpha_operator_routes.md:1095-1110`); the root docs pins (`docs_contract_test.go:9864-9869`); the macOS list; report 25's "Product follow-up to queue"; report 33 and its CI logs.

`git grep` for `LIBRESSL_PEM_ERROR`, `pem_lib`, `09FFF06C` and `LibreSSL` over the whole tree: no other copy of the matcher, no leftover use of the removed `LIBRESSL_PEM_ERROR_PATH`, no Go port.

Not inspected: the macOS runner itself. I could not run anything on macOS, so the macOS result rests on the CI run (§6).

## 4. Findings

### A34-1

```
AUDIT FINDING
ID / Type / Severity: A34-1 / test gap / low
Current contract: the PR's own statement of the rule, in the code comment (remote_alpha_es_tls_status.py:1893-1897),
  the doc (remote_supported_host_alpha.md:4011-4014) and report 33 §2: the location is "absolute, ending in
  /crypto/pem/pem_lib.c, with no colon or control character in it" (report 33: control character = NUL to US, and DEL).
Path and line: scripts/remote_alpha_es_service_tls_status_test.go:1022-1050 (the 27 cases)
```

**Evidence.** I ran 8 mutants of `LIBRESSL_PEM_ERROR_LOCATION` against `…LibreSSLMalformedPEMLocation`, `…OpenSSLGrammar`, `…CollectionTypedFailures`, the four `…Target3013…` tests and `…X509TextSignatureTails` (`34-pr62-audit-evidence/mutants.py`, `run-mutants.sh`, `mutants-out.txt`). Four were killed by the new test and four survived:

| Mutant | What it loosens | Result |
|---|---|---|
| `M_ctl_only_nl_cr_nul`: class `[^/:\n\r\x00]` | TAB, ESC, VT, FF, the other C0 bytes and DEL are admitted | **survived** |
| `M_no_del`: class `[^/:\x00-\x1f]` | DEL is admitted | **survived** |
| `M_relative_prefix_allowed`: `[^:\x00-\x1f\x7f]*/crypto/pem/pem_lib\.c:[0-9]+` | `build/crypto/pem/pem_lib.c:694`, `../crypto/…`, `//crypto/…` are admitted, so the location is no longer "absolute" | **survived** |
| `M_dot_unescaped`: `pem_lib.c` with `.` unescaped | `/crypto/pem/pem_libXc:1` is admitted | **survived** |
| `M_empty_components`: `+` becomes `*` | `//` is admitted. The doc does not state this rule, so it is optional | survived |
| `M_old_pinned_path` | the pre-PR pin | killed (5 accepted cases) |
| `M_any_file_in_pem` | any `.c` file in `crypto/pem` | killed (`other_source_file`) |
| `M_line_optional` | no `:<n>` | killed (`missing_line`) |

The test's control-character cases are NUL, CR and LF only. Its one relative case, `crypto/pem/pem_lib.c:694`, has no prefix, so it is refused by the literal `/crypto` alone and does not test "absolute".

**Impact.** None today: the product code is right (§5). But a later edit could loosen three of the stated refusal rules with every test green, which is the kind of unpinned refusal check that blocked PR #60 (A20-2).

**Required correction.** Add refused cases to `…LibreSSLMalformedPEMLocation`, then confirm that the surviving mutants above are killed:
- a TAB, an ESC (or `\x1f`) and a DEL in the path;
- a relative path with a prefix, such as `build/crypto/pem/pem_lib.c:694`, and `../crypto/pem/pem_lib.c:694`;
- `pem_libXc` in place of `pem_lib.c`;
- optional: `//` in the path, if refusing empty components is intended. If it is, say so in the comment and the doc too.

**Uncertainty.** None on the mutant results; they are reproducible with the scripts in the evidence folder. **Patch defect** (the test is new in this PR).

### A34-2

```
AUDIT FINDING
ID / Type / Severity: A34-2 / doc gap (stale claim) / low
Current contract: procedures.md "Docs and READMEs": a PR that changes behaviour updates the affected docs in the same
  PR; audits treat stale docs as a test/doc gap. This PR's purpose included making doc and code agree (O30-3).
Path and line: .docs/system_overview/remote_supported_host_alpha.md:4004-4005 at 72eecb2
```

**Evidence.** The paragraph the PR edited still opens: "The admitted malformed-material response is the fixture-proven LibreSSL 3.3.6 tuple: …". After the change, the admitted set is a family of locations matched by form. The PR's own test asserts that it accepts `other_libressl_folder` (a `libressl-4.1` path) and `short_absolute_path` (`/crypto/pem/pem_lib.c:694`). No fixture produced either of them, and neither is tied to 3.3.6. There is no retained LibreSSL fixture in the repo (`testdata/remote_alpha_es_tls_status/` holds only OpenSSL 3 material).

**Impact.** A reader takes "fixture-proven 3.3.6" as a statement about where the admitted grammar comes from. For this one family, that statement is no longer true. The rest of the paragraph is accurate.

**Required correction.** Reword the opening, for example: "The admitted malformed-material response has the shape first observed with LibreSSL 3.3.6 on macOS: …", leaving the rest of the paragraph as it is. The root docs pins (`docs_contract_test.go:9864-9869`) do not pin that sentence.

**Uncertainty.** Low. Whether "fixture-proven" was meant as a name rather than a claim cannot be settled from the repo. Read literally, it is a claim. **Patch defect** (the sentence sits in the paragraph the PR rewrote).

### Observations (non-blocking)

- **O34-1, the runner's exact form is not retained.** Report 25 planned to make the grammar test print the host's result first, so that the first macOS run would show the runner's exact stderr. The PR shipped that step together with the fix, so the first run passed and printed nothing (report 33 §6 says so). What the pass does prove, given what the pattern fixes: the runner's tuple has exit 1, empty stdout, the exact first line, a decimal thread id, the exact error code, function and reason, a location of the stated form, the exact `Expecting:` object and one newline. Unproved inference: the location is an Apple path. Nothing depends on that inference. Recording it, for example with a one-off CI run on a throwaway branch, is optional.
- **O34-2, what the form admits beyond ASCII paths.** The class is a byte class, so it admits any byte from 0x80 up: valid non-ASCII (é, U+2028, U+0085, a fullwidth colon, a division slash), invalid UTF-8 and an overlong `/` encoding. It also admits spaces, `.` and `..` components, leading zeros and line numbers up to the 8 KiB stderr bound. All of this is harmless. The matched stderr is never stored, logged, published, opened as a path or decoded: the result is a boolean, and "Raw child output never enters evidence" (`remote_supported_host_alpha.md:4064`). No action needed.
- **O34-3, refusal cases cover only the certificate kind.** All 20 refused cases use `kind="certificate"`. The key kind shares the pattern construction, and my consumer probe shows that the certificate refusal given to `key_pair` stays `Incomplete("unexpected_openssl_grammar")`. A key-kind refused case would close the other direction. This is optional, and the structure predates the PR.
- **O34-4, box effect.** The collector's bytes change, so a box TLS status run from a commit with #62 stages new bytes. Inference: behaviour on the box is unchanged. The box's OpenSSL 3.0.13 forms are untouched exact strings (`:1904-1907`), and the real box binary does not print the LibreSSL form. I see no need for a new box turn. Any brief that pins collector sums needs the new value.

No finding was rejected. No disagreement to preserve (single auditor).

## 5. The claim "a looser match can only turn incomplete into a typed failure, never a pass"

**Holds.** Repo-validated at 72eecb2, plus probes:

1. **Only two callers**, both inside `if code != 0:` (`:2401`, `:2517`). On a match they return `{"status": "fail", "code": "certificate_malformed"}` with metadata and raw bytes `None` (`:2403`), or `{"status": "fail", "code": "key_malformed", "matches": False}` (`:2519`). Otherwise they raise `Incomplete("unexpected_openssl_grammar")`. A zero exit never reaches the matcher.
2. **Downstream of a malformed certificate** everything is a failure: `key_pair` returns `certificate_unavailable` (`:2504-2505`), and `verify_chain` returns `certificate_unavailable` (`:2534-2535`). The record validator requires all metadata to be `None` for `certificate_malformed` (`:2745-2748`).
3. **Consumer probe** (`consumers.py`, `consumers-out.json`): with a non-pinned path (another build folder with a space in it, line 702), the outcomes are as follows:
   - `cert_metadata` gives `("fail", "certificate_malformed", raw None, public_key_sha256 None, sha256 None)`;
   - `key_pair` gives `("fail", "key_malformed", False)`;
   - `key_pair` after that certificate gives `("fail", "certificate_unavailable")`, and so does `verify_chain`;
   - the key refusal given to `cert_metadata`, and the certificate refusal given to `key_pair`, both stay `Incomplete:unexpected_openssl_grammar`.
4. **The only behavioural difference** between the two outcomes: a typed failure publishes a new `fail` generation, while `Incomplete` publishes none and leaves the prior generation unchanged. To move a host from pass to fail this way, an attacker would have to make root's fixed `/usr/bin/openssl` (`:31`, enforced at `:1581`) exit 1 with that stderr. The location is a compile-time path, so input bytes cannot shape it, and the box's OpenSSL 3 does not print the form at all. Inference: there is no reachable widening on the box.

**Adversarial probe of the pattern** (`adversarial.py`, `adversarial-out.json`; head collector against base collector):

- **Independent implementation:** I wrote the doc's rule without a regex, so it does not share the PR's code. On 88 targeted inputs (44 crafted locations, each for both kinds) and 400,000 fuzzed inputs (seed 62; mutations of valid tuples, plus random locations built from `/ : \n \r \0 \t DEL ESC`, non-ASCII, and fragments of the refusal itself), the PR's matcher and my implementation never disagree.
- **Only the path widened:** every tuple base accepts, head accepts (0 violations). For every tuple head accepts (25,181 in the fuzz run), putting the old pinned path back in its place gives a tuple that base accepts (0 violations). So everything except the location is exactly as strict as before.
- **Crafted locations refused** (both kinds):
  - newline, CR, NUL, TAB, ESC, DEL, VT, FF, colon;
  - relative paths, with or without a prefix, `../`, a bare `pem_lib.c`;
  - `//`; a component appended after `pem_lib.c`; `pem_lib.cc`; `xcrypto`; changed case; an unescaped-dot form;
  - line numbers `-1`, `+1`, `0x2b6`, an Arabic-Indic digit, ` 1`, `1:2`, empty;
  - a location carrying a second embedded refusal.
- **Whole-tuple changes refused**, with a new valid location: exits 0, 2 and −15; stdout `\n`; a leading or extra trailing newline; CRLF; an empty, negative, hex or Unicode thread id; lowercase error code; two error lines; lowercase `Expecting` object; kind `x509`.
- **Timing:** linear. At the 8 KiB stderr bound, every pathological input (8,192 slashes, `/a` repeated, `/crypto/pem` repeated, `/crypto/pem/pem_lib.c` repeated with no colon, a long component, long digits then a bad byte) takes under 1 ms. At 1 MiB the slowest takes 0.075 s.

## 6. Validation assessment

**Re-run by me** on Linux (Ubuntu container, OpenSSL 3.0.13, Python 3.13.18, Go 1.26.5), as unprivileged user `ci` (uid 1500, gid 1600), `env -i`, `umask 022`, with HUP, INT, QUIT and TERM reset. Host packages openssh-client, uuid-runtime, acl and iproute2 were added, and the en_US.UTF-8 locale was generated.

- **Targeted run on head:** these pass:
  - `TestRemoteAlphaESServiceTLSStatusLibreSSLMalformedPEMLocation`;
  - `TestRemoteAlphaESServiceTLSStatusOpenSSLGrammar`;
  - `TestRemoteAlphaESServiceTLSStatusCollectionTypedFailures`;
  - `TestRemoteAlphaESServiceTLSStatusTarget3013MalformedResponses`, `…Target3013VerifyFailureResponses`, `…Target3013NativeReplay` and `…Target3013FailurePublicationSemantics`;
  - `TestRemoteAlphaESServiceTLSStatusX509TextSignatureTails`.
- **`go test -count=1 -json ./scripts/...` on head and on base** (base = clean checkout of 819f712, same container):
  - the non-pass lists are byte-identical (`head-scripts-nonpass.txt` = `base-scripts-nonpass.txt`, SHA-256 `f38b909a…65c1`): 41 failing and 20 skipping test paths;
  - the only test head adds is the new one, and it passes;
  - the failing top-level tests on both trees, all environment-only here (several are lines in the CI lists):
    - `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`;
    - `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`;
    - `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`;
    - `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`;
    - `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`;
    - `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`;
    - `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`;
    - `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`;
    - `TestRemoteAlphaUpgradeESApply`;
    - `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`.

  Subtests and skips are in the evidence files.
- **Root package `go test -count=1 .`:** head 618 pass, base 618 pass, 0 fail. The docs pins hold with the edited paragraph.
- **Other checks:**
  - `go vet .` in `scripts`: clean;
  - `gofmt -l scripts/`: nothing;
  - the macOS list through the gate's own `read_entries`, `by_package` and `check_list` against `./scripts/...`: 20 entries, 80 self-skip lines, OK, and neither removed test is listed.

**Not re-run, evidence only:** macOS. GitHub check runs on head `72eecb2`, read by API at about 08:58Z:
- "test on macOS": job 139055674059, run 45570499116, success, completed 08:11:10Z;
- "build, vet and test": job 139055674952, run 45570499348, success, completed 08:40:17Z.

The writer's macOS log (`33-evidence/`, SHA-256 `9c3a6676…51aa`) shows "test gate passed … (20 entries)" and "all 20 listed tests still fail". Inference: so `TestRemoteAlphaESServiceTLSStatusOpenSSLGrammar` and `…CollectionTypedFailures/malformed_cert` ran unlisted and passed on macos-26. The gate fails on any unlisted failure. Codex did not review (out of credits, PR comments of 08:42Z).

**Limits:** I ran no macOS host and no box. The root CI step's 9 tests were not re-run, and the PR touches nothing they test.

## 7. Red-team scope

Rule (procedures.md "Red-team scope and method"): red-team for "non-trivial PRs into `trunk_dev` or `main`, first and foremost in ES"; "Everything else gets the fresh correctness audit but no red-team, unless the coordinator judges a change security-critical and says why."

**My judgment: not in scope.** The product change is trivial in the sense that matters:

1. **Size and kind.** One regex constant in one function: 5 product lines, no new process, filesystem, publication, authority or I/O code.
2. **Outcome space.** The widened match can only turn `Incomplete` into one of two typed failures. It cannot produce a pass, and it cannot affect a zero-exit path (§5).
3. **Reachability.** The input is the bounded (8 KiB) stderr of root's fixed `/usr/bin/openssl`, and the location in it is a compile-time constant. On the box the real binary never prints this form. In practice the widened branch runs only on macOS, in tests.
4. **Coverage.** The attack classes a red-team would bring to this surface were run in this audit, with results in §5:
   - malformed and crafted bytes: newline, colon, control characters, relative paths and traversal, Unicode, invalid UTF-8;
   - catastrophic backtracking;
   - differential fuzzing against an independent implementation of the rule;
   - cross-kind replay;
   - the outcome through the real consumers.

**Against my view:** the change sits in a collector that runs as root on the box. It widens an acceptance grammar, the class of change red-teams exist for. The writer and the PR body both say "needs audit, red-team". Under the quota rule, Fable runs only for red-teams that merges need, so I recommend the coordinator record "no red-team: trivial security surface, adversarial coverage in audit 34 §5", or say why it judges otherwise.

## 8. Sensitive-material handling

No secrets, keys or certificates were read or written. All probe inputs are synthetic. No failing or skipped test name contains a user@host (checked: 0 `@` in the published lists).

## 9. Confidence

- **Provenance: 1.0.** Manifest reproduced byte for byte, opening and closing manifests equal, PR head equals the audited commit, CI ran on that head.
- **Validation: 0.95.** Linux re-run complete on the exact bytes, with head and base compared by test names. macOS rests on green CI, not on a run of mine.
- **Implementation: 0.95.** The product change is correct and its safety claim holds. The remaining doubt is A34-1 (rules not pinned) and A34-2 (stale doc), not the code.

## 10. Effect status and next step

Effects: no repair, commit, push, PR edit, comment, merge or box contact. The scratch trees are in this container only.

**Next step:** the writer adds the A34-1 cases and rewords A34-2 (test and doc only), takes a new manifest, and gets a green "test on macOS" and "build, vet and test" on the new head. Then a fresh diff check verifies that the four surviving mutants are killed and that the product bytes of `remote_alpha_es_tls_status.py` are unchanged from `326c8d12…4f94057`.

## 11. Evidence

`34-pr62-audit-evidence/` (SHA-256):

| File | What it is | SHA-256 |
|---|---|---|
| `manifest-72eecb2-vs-819f712-audit.json` | my v2 manifest | `beeecf25…6629` |
| `adversarial.py` | the pattern probe | `000222f0…03ae4` |
| `adversarial-out.json` | its output | `5443ec0b…374c` |
| `mutants.py` | the mutant generator | `05844f50…d9693` |
| `run-mutants.sh` | the mutant runner | `ba8316ab…75d9` |
| `mutants-out.txt` | mutant results | `816625e9…076ff` |
| `consumers.py` | the consumer probe | `927dd910…7ef1197` |
| `consumers-out.json` | its output | `a78a7b69…b2e8` |
| `head-scripts-nonpass.txt`, `base-scripts-nonpass.txt` | non-pass test names on each tree | `f38b909a…65c1` (identical) |

```
Final verdict: BLOCK
```
