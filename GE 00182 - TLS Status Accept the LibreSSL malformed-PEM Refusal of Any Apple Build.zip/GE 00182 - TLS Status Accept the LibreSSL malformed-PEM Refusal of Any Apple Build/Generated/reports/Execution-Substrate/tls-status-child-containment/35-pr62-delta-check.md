# 35. Delta check of ES PR #62, 72eecb2 to f2cc70f: the repair of audit 34

```
INDEPENDENT AUDIT REPORT
Repository:      evo-agi/Execution-Substrate, PR #62 "TLS status: accept the LibreSSL malformed-PEM refusal of any Apple build"
Audit target:    base trunk_dev 819f712cde8fd83f5b73b2154263afa18cf29623
                 topic claude/project-thread-wbmulu, commit f2cc70f0369b45ad8387c8a30004b515cde656f7,
                 tree 1338fa21ec7652ae41ea04e642973c97bfc11944
                 delta under review: 72eecb2 (audit 34, BLOCK) to f2cc70f, one commit
Recipe:          governed-execution.audit-patch-manifest.v2, source SHA-256
                 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified before each run)
Manifest:        59bef4277635100383357c9f7830386f1455a49abcf25d69fc893375955ecbd7, 5 changed paths,
                 textual_diff_sha256 b0ca36bef31721db521eafde157707cbe87d9f62538196d1ac200d82915a8a99
Writer report:   33-libressl-grammar-pr62.md §7, SHA-256 8e4cd0fa58e6399635f3b67e449918b5b99b6fecf12afbb4b3025a066e04fe3b
Audit posture:   read-only. No subagents. Nothing pushed, no PR edit, no GitHub comment, box not touched.
                 I had not audited PR #62 before (protocol §14).
Verdict:         BLOCK (one Low test gap, patch defect; the product bytes and everything else hold)
```

All times are UTC on 2026-11-25. Check ran 09:48Z to about 10:05Z in a fresh cloud container.

## 1. Verdict in short

The repair does what audit 34 asked, and every claim of the writer that I could check holds:

- **The collector is unchanged.** `scripts/internal/remote_alpha_es_tls_status.py` is `326c8d12…4f94057` at both `72eecb2` and `f2cc70f`. The repair touches only the test file and the doc (Ran).
- **The manifest reproduces.** Byte for byte, the writer's `59bef427…ecbd7`, twice at opening and twice at closing (Ran).
- **The 8 new refused cases are there and work.** The test now has 35 cases (7 accepted, 28 refused, no repeated label). Audit 34's four surviving mutants are now killed, each by the new case written for it (Ran).
- **A34-2 is fixed.** The paragraph now opens "has the shape first observed with LibreSSL 3.3.6 on macOS". The root package's docs pins pass (Ran, Read).
- **The `//` survivor is not a finding** (§4). No stated rule refuses an empty path component. Here the code is stricter than its statement, and that is the safe direction.
- **Both workflows are green on the exact head tree** (Read). Both ran merge commit `a5d6c99`, whose tree `1338fa21` is the head's tree. I fetched both job logs myself, and they equal the writer's copies.

It is still BLOCK, for the same reason as A34-1, on clauses that audit 34 did not try:

- **A35-1 (Low, test gap):** three clauses of the location rule still have no refused case. Those clauses are stated in the code comment, the doc, report 33 §2 and the PR body.
  - The line number must be decimal.
  - The fixed suffix must start at a path component (`/crypto/…`, not `/xcrypto/…`).
  - The suffix must be exact in case.

  Five mutants that loosen these clauses pass every test. Each one admits a location that the audited collector refuses.

The fix is four refused cases in the same test, test only. With them, every clause of the stated location rule has at least one refused case (§3.3), so the list of rules to pin is closed and this does not reopen. A diff check of that change and green CI should then be enough.

## 2. Provenance reproduction

Ran, in a fresh clone under `umask 022`:

- **Recipe:** v2 `sha256sum -c` against the pin: OK, before each run.
- **Fetch:** `git fetch origin trunk_dev claude/project-thread-wbmulu` gives the topic tip `f2cc70f…` and trunk_dev `819f712…`. The base is the merge-base. There are two commits in `819f712..f2cc70f`: `72eecb2` (audited in 34) and `f2cc70f` (the repair, parent `72eecb2`).
- **Sequence:** provenance §5.3: checkout of the tip, clean status, `git reset --mixed 819f712`, upstream `origin/trunk_dev`. Then v2 twice into a fresh 0700 directory (09:49Z). The two outputs are byte-identical, and `cmp`-identical to the writer's `33-evidence/manifest-f2cc70f-vs-819f712.json`. 5 files, all `tracked_modified`, mode 0644. No mode-bit difference.
- **Closing run** (09:59Z): two runs, identical to the opening ones. Remote tip and trunk_dev unchanged (`git ls-remote`).
- **GitHub (API, about 10:00Z):** PR #62 head `f2cc70f…`, base `819f712…`, `mergeable_state: clean`, 2 commits, not a draft.
- **Against audit 34's manifest of `72eecb2`** (`34-pr62-audit-evidence/manifest-72eecb2-vs-819f712-audit.json`): the same 5 paths.
  - 3 records are byte-identical: the collector, `scripts/remote_alpha_es_service_tls_openssl3013_test.go` and `.github/ci/environment-only-tests-macos.txt`.
  - 2 changed: `scripts/remote_alpha_es_service_tls_status_test.go` and `.docs/system_overview/remote_supported_host_alpha.md`.
- `git diff 72eecb2 f2cc70f | sha256sum` = `2b068a60…1557`, equal to the writer's `33-evidence/repair-72eecb2-to-f2cc70f.diff`. 2 files, +12/−4.

## 3. Coverage

### 3.1 The repair diff (Read)

- **Test** (`scripts/remote_alpha_es_service_tls_status_test.go`, lines 1037-1056 at `f2cc70f`). 8 new refused cases, and the expected count goes from 27 to 35:
  - `certificate_refusal_for_a_key`;
  - `relative_path_with_a_folder` (`build/crypto/pem/pem_lib.c:694`);
  - `relative_path_from_the_parent` (`../crypto/pem/pem_lib.c:694`);
  - `other_character_for_the_dot` (`pem_libXc`);
  - `tab_in_path`, `escape_in_path` (`\x1b`), `unit_separator_in_path` (`\x1f`), `delete_in_path` (`\x7f`).

  The probe is a Go raw string, so the escapes reach Python as written. The count check (35) guards against a repeated label: the results map is keyed by label, and I found no duplicates (Ran).
- **Doc** (`.docs/system_overview/remote_supported_host_alpha.md:4004-4006`): the new opening wording; the rest of the paragraph is unchanged apart from one line break. The paragraph still states the rules the code applies: "a colon and a decimal line number", "absolute, ending in `/crypto/pem/pem_lib.c`, with no colon or control character in it" (lines 4011-4014).

### 3.2 Mutants (Ran, `35-pr62-delta-check-evidence/`)

**Setup.**
- I built one test binary from tree `1338fa21` in a copy of the tree. For each mutant I rewrote the collector constant in the copy and ran the audit 34 test set: `…LibreSSLMalformedPEMLocation`, `…OpenSSLGrammar`, `…CollectionTypedFailures`, `…Target3013.*`, `…X509TextSignatureTails`.
- The first 8 mutants are audit 34's table, line for line (checked by script).
- For every mutant, `witness.py` loads the original and the mutated collector and shows one input on which the two disagree. So no surviving mutant is equivalent.
- The copy was restored at the end (`cmp` against the audited bytes).
- Baseline: the same tests pass unmutated on `f2cc70f` here.

| Mutant | Rule it loosens | 72eecb2 (audit 34) | f2cc70f (here) |
|---|---|---|---|
| `M_ctl_only_nl_cr_nul` | control characters | survived | **killed**: `tab_in_path`, `escape_in_path`, `unit_separator_in_path`, `delete_in_path` |
| `M_no_del` | DEL | survived | **killed**: `delete_in_path` |
| `M_relative_prefix_allowed` | absolute | survived | **killed**: `relative_path_with_a_folder`, `relative_path_from_the_parent` |
| `M_dot_unescaped` | `.c` exact | survived | **killed**: `other_character_for_the_dot` |
| `M_old_pinned_path` | (tightens) | killed | killed (5 accepted cases) |
| `M_any_file_in_pem` | `pem_lib.c` | killed | killed (`other_source_file`) |
| `M_line_optional` | a colon and a line number | killed | killed (`missing_line`) |
| `M_empty_components` | none stated (§4) | survived | survived |
| `X_line_any_text`: `:[^:\x00-\x1f\x7f]+` | decimal line number | not tried | **survived** (admits `:abc`) |
| `X_line_hex`: `:[0-9A-Fa-fx]+` | decimal line number | not tried | **survived** (admits `:0x2b6`) |
| `X_line_trailing_text`: `:[0-9]+[^:\x00-\x1f\x7f]*` | the line number ends the location | not tried | **survived** (admits `:694x`) |
| `X_no_boundary_before_crypto`: `…/[^/:…]*crypto/pem/pem_lib\.c…` | ending in `/crypto/pem/pem_lib.c` | not tried | **survived** (admits `/xcrypto/pem/pem_lib.c`) |
| `X_suffix_any_case`: `/(?i:crypto/pem/pem_lib\.c)` | ending in `/crypto/pem/pem_lib.c` | not tried | **survived** (admits `/CRYPTO/PEM/PEM_LIB.C`) |
| `X_thread_id_any_text`: `[^:\n]+:error:` | decimal thread identifier | not tried | survived (admits `0x1a2b:error:`); pre-existing rule, see A35-2 |

The writer's own run of audit 34's 8 mutants (`33-evidence/mutants-a34-1-after-repair.txt`) gives the same results as my first 8 rows.

### 3.3 Each clause of the stated rule, and the case that pins it

The location clauses come from the doc (lines 4011-4014), the comment (`remote_alpha_es_tls_status.py:1893-1897`), report 33 §2 and the PR body: "the path of `crypto/pem/pem_lib.c` …, a colon and a decimal line number … absolute, ending in `/crypto/pem/pem_lib.c`, with no colon or control character in it".

| Clause | Refused case at f2cc70f |
|---|---|
| the file is `pem_lib.c` in `crypto/pem` | `other_source_file`, `other_source_folder`, `other_character_for_the_dot` |
| a colon before the line number | `missing_line` |
| a line number is present | `missing_line_number` |
| **the line number is decimal (and ends the location)** | **none** (A35-1) |
| absolute | `relative_path`, `relative_path_with_a_folder`, `relative_path_from_the_parent` |
| **ending in `/crypto/pem/pem_lib.c`: at a component boundary, exact case** | **none** (A35-1) |
| no colon in the path | `colon_in_path` |
| no control character (NUL to US, DEL) | `nul_in_path`, `newline_in_path`, `carriage_return_in_path`, `tab_in_path`, `escape_in_path`, `unit_separator_in_path`, `delete_in_path` |

With the four cases in A35-1's correction, every clause has a refused case.

### 3.4 Other checks (Ran)

On `f2cc70f`, in a clean clone as root (Go 1.26.5, Python 3.13.18, OpenSSL 3.0.13):

- the audit 34 test set passes;
- root package `go test -count=1 .`: ok (the docs pins hold with the reworded paragraph);
- `go vet` of `scripts`: clean;
- `gofmt -l scripts/`: nothing.

Not re-run: the whole `scripts` package. The repair adds only cases to one test, and audit 34 compared the whole package on head and base for `72eecb2`.

## 4. Is the surviving `//` mutant a finding? No.

`M_empty_components` changes `+` to `*`, so the mutant admits an empty component (`/Library//Caches/`). The audited code refuses it.

- **No stated rule refuses `//`.** A location like `/a//crypto/pem/pem_lib.c:1` is absolute, ends in `/crypto/pem/pem_lib.c`, and has no colon and no control character. By the doc's own words it is admissible. So this mutant brings the code closer to its statement, not further away. A test that pinned the refusal would pin behaviour that no rule states. That is not what A34-1 asked for: it asked to pin the stated rules.
- **The difference is in the safe direction.** A refused location yields `Incomplete("unexpected_openssl_grammar")`, never a pass (audit 34 §5). No Apple build path seen has an empty component.
- **The code is a little stricter than the doc describes** (non-empty components). That is O35-1, an observation. Stating it would mean changing the collector's comment, which is product bytes, for a case that does not occur. I do not recommend it now.

## 5. Findings

### A35-1

```
AUDIT FINDING
ID / Type / Severity: A35-1 / test gap / low
Current contract: the location rule as the PR states it: code comment remote_alpha_es_tls_status.py:1893-1897
  ("absolute, ending in /crypto/pem/pem_lib.c, with no colon or control character in it"); doc
  remote_supported_host_alpha.md:4011-4014 ("a colon and a decimal line number", same form clause); report 33 §2
  ("then a colon and a decimal line number"); PR body (same). Audit 34's A34-1 asked that the PR's stated
  refusal rules be pinned by tests.
Path and line: scripts/remote_alpha_es_service_tls_status_test.go:1022-1059 at f2cc70f (the 35 cases)
Evidence: five mutants of LIBRESSL_PEM_ERROR_LOCATION pass every test in the audit 34 set, and each admits an input
  the audited collector refuses (witness.py, mutants-out.txt):
    X_line_any_text, X_line_hex, X_line_trailing_text (":abc", ":0x2b6", ":694x"): the decimal line number;
    X_no_boundary_before_crypto ("/xcrypto/pem/pem_lib.c"): the suffix starts at a component;
    X_suffix_any_case ("/CRYPTO/PEM/PEM_LIB.C"): the suffix is exact.
  The decimal line number is new in this PR: on base 819f712 the line ":694" was part of the pinned path
  (LIBRESSL_PEM_ERROR_PATH, remote_alpha_es_tls_status.py:1893 at 819f712). Audit 34's adversarial probe showed
  the product refuses all of these, but no test holds it there.
Impact: none today; the product code is right. A later edit could loosen these three clauses with every test
  green: the same class as A34-1 and PR #60's A20-2.
Required correction: add refused cases to …LibreSSLMalformedPEMLocation (and raise the count from 35 to 39), for example:
    ("non_decimal_line_number",False,"certificate",1,b"",refusal("certificate",apple.replace(b":694",b":0x2b6"))),
    ("text_after_line_number",False,"certificate",1,b"",refusal("certificate",apple.replace(b":694",b":694x"))),
    ("prefix_on_the_crypto_folder",False,"certificate",1,b"",refusal("certificate",apple.replace(b"/crypto/pem/",b"/xcrypto/pem/"))),
  ("other_case_of_the_suffix",False,"certificate",1,b"",refusal("certificate",apple.replace(b"/crypto/pem/pem_lib.c",b"/CRYPTO/PEM/PEM_LIB.C"))),
  then rerun run-mutants.sh: all five X_ location mutants should be killed. With these, every clause of the stated
  location rule has a refused case (§3.3).
Uncertainty: none on the results; they are reproducible with the scripts in the evidence folder.
Patch defect or pre-existing: patch defect (the test and the pattern are new in this PR).
```

### A35-2

```
AUDIT FINDING
ID / Type / Severity: A35-2 / test gap / low
Current contract: doc remote_supported_host_alpha.md:4007 "a decimal thread identifier"; code
  remote_alpha_es_tls_status.py:1910 rb"[0-9]+:error:…".
Evidence: X_thread_id_any_text ([^:\n]+ for the thread id) passes every test and admits "0x1a2b:error:…".
Impact: none today. The rule and its regex are unchanged from base 819f712 (:1905 there), so this gap is older than the PR.
Required correction: one refused case in the same test, for example
    ("non_decimal_thread_id",…) built with b"0x1a2b" in place of b"4336234112".
  Recommended in the same repair as A35-1: it is one line in the same table, and leaving it would be a
  deferral with no trigger.
Patch defect or pre-existing: pre-existing.
```

### Observations (non-blocking)

- **O35-1:** the code also refuses empty path components (`+`), which the doc and comment do not state (§4). This is the safe direction, and no real path has one. No action recommended.
- **O35-2:** the writer's two `33-evidence/*job139093*.log` files equal the API's log text exactly. The macOS file just lacks a final newline. I fetched both logs independently.
- **O35-3, carried from audit 34 and still true:** the runner's exact LibreSSL stderr is not recorded (O34-1). Refused cases cover the key kind only through `certificate_refusal_for_a_key`, which is enough for the cross-kind direction (O34-3 is closed).

No finding rejected. No disagreement to preserve (single auditor). I did not re-judge audit 34's findings beyond the delta. Its product verdict ("the collector change is correct") binds the same collector bytes.

## 6. CI on the head (Read; logs fetched with `get_job_logs`)

Both runs checked out `a5d6c9964d3eac7524343534152ae824607723d2`, "Merge f2cc70f… into 819f712…". Its tree `1338fa21…` equals the head's tree (Ran: `git fetch refs/pull/62/merge`). So CI tested the audited bytes.

- **"test on macOS", run 45581831353, job 139093520190, 09:03:50Z to 09:34:01Z, success.** macos-26-arm64 image 20261117.0516.1, go1.26.5 darwin/arm64.
  - Self-check: "Ran 145 tests".
  - `execution-substrate/scripts` ok in 524.5 s ("Test") and 454.9 s (observed run). The observed run skipped exactly the 20 entries, each once.
  - "test gate passed: 2 packages, 1 of them with skipped entries (20 entries); 80 tests skipped themselves, all of them listed".
  - "all 20 listed tests still fail on this host". So the new test and `…OpenSSLGrammar` ran unlisted and passed on macOS.
- **"build, vet and test", run 45581831329, job 139093519550, 09:03:51Z to 09:46:31Z, success.** go1.26.5 linux/amd64.
  - Self-check: "Ran 145 tests".
  - "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed".
  - "all 17 listed tests still fail"; "tests as root passed: 9 of execution-substrate/scripts".

Extracts: `macos-job139093520190-extract.txt`, `linux-job139093519550-extract.txt`.

## 7. Red-team

The coordinator recorded no separate red-team for #62 (report 33 §7). The repair changes no product byte, so nothing in this delta changes that basis.

## 8. Sensitive-material handling

No secrets, keys or certificates read or written. All mutant inputs are synthetic. The extracts hold test-gate summary lines only.

## 9. Confidence

- **Provenance: 1.0.** Manifest reproduced byte for byte, opening equals closing, PR head equals the audited commit, CI ran on the head's tree.
- **Validation: 0.95.** The mutants and tests were re-run on the exact bytes. macOS rests on the runner's log, which I read.
- **Implementation: 0.95.** The collector is unchanged and was judged correct in audit 34. The remaining doubt is the unpinned clauses (A35-1, A35-2), not the code.

## 10. Effect status and next step

No repair, commit, push, PR edit, comment, merge or box contact.

Next: the writer adds the four A35-1 cases (and the A35-2 case), test only, with the collector unchanged. Then a new manifest, `run-mutants.sh` showing all five `X_` location mutants (and `X_thread_id_any_text`) killed, and green "test on macOS" and "build, vet and test" on the new head. A diff check of that change then closes it.

## 11. Evidence

`35-pr62-delta-check-evidence/`, with `SHA256SUMS.txt`:

- `manifest-f2cc70f-vs-819f712-opening.json` and `…-closing.json`: my v2 manifests, `59bef427…ecbd7`;
- `mutants.py`: audit 34's table plus the `X_` mutants;
- `witness.py`: a disagreeing input for each mutant;
- `run-mutants.sh`: the runner;
- `mutants-out.txt`: the results;
- `macos-job139093520190-extract.txt` and `linux-job139093519550-extract.txt`: the CI summary lines.

```
Final verdict: BLOCK
```
