# 38. Diff check of ES PR #62, a34e339 to d31043d: the two line-position cases of O37-1

```
INDEPENDENT AUDIT REPORT
Repository:      evo-agi/Execution-Substrate, PR #62 "TLS status: accept the LibreSSL malformed-PEM refusal of any Apple build"
Audit target:    base trunk_dev 7e271681b63e33891f287ca0f745d45cebeee4f5 (#60)
                 topic claude/project-thread-wbmulu, commit d31043dadb3174fbf60b5b145ecd48dfca146117,
                 tree 552211d55f6d2c5586443bded32d51cc749c7193
                 delta under review: a34e339 (diff check 37, ACCEPT) to d31043d (one commit, parent a34e339)
Recipe:          governed-execution.audit-patch-manifest.v2, source SHA-256
                 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified before each run)
Manifest:        f8a43fadf353c39b7a2011a0a031c65318419be2ac887582de75ade5235f5560, 5 changed paths,
                 textual_diff_sha256 99f04a0e4b09ab5a34609026543a264466f93afe9d474e3ddd33d63235a0a271
Writer report:   33-libressl-grammar-pr62.md §11, SHA-256 05b19b44c5e0bfb912bc304db29db80bbce02dcb57da37f8e04c2bf6d4eadeb4
Prior audit:     37-pr62-diff-check.md, SHA-256 67060ee92167900a909810115ed2aedc11c5cbfb5eb881801d61f65db24b518a
Audit posture:   read-only. No subagents. Nothing pushed, no PR edit, no GitHub comment, box not touched.
                 I had not audited PR #62 before (protocol §14).
Verdict:         ACCEPT (O37-1 is closed as asked; no finding under the recorded standard; one position of the
                 same line-count rule is still open under the stricter reading, O38-1, with a recommendation)
```

All times are UTC on 2026-11-25. The check ran from 13:30Z to 14:18Z in a fresh cloud container.

## 1. Verdict in short

Every claim in the writer's §11 holds on the exact bytes:

- **The manifest reproduces** byte for byte: the writer's `f8a43fad…5560`, twice at opening (13:31Z) and twice at closing (14:14Z) (Ran).
- **Only the status test changed.** `git diff a34e339 d31043d` touches only `scripts/remote_alpha_es_service_tls_status_test.go`, +3/−1, and equals the writer's `repair-a34e339-to-d31043d.diff` byte for byte (sha256 `e4183b41…94f4`). The other four manifest records equal audit 37's records for `a34e339`. The collector is still `326c8d12…4f94057` (Ran).
- **The two cases are exactly audit 37's** (§4 of report 37, and `o37-1-cases.py`), and the count went from 46 to 48: 7 accepted, 41 refused, no repeated label, all 48 checks true on the audited collector (Ran).
- **All four line-position mutants of O37-1 are killed**: `P_leading_line_allowed`, `P_any_prefix` and `P_search_end_anchored` by `leading_line`, `P_line_between_allowed` by `line_between_the_two`. All 47 mutants of audits 35, 36 and 37 and the writer give exactly the writer's kill sets: 38 killed, the same 9 survivors (Ran).
- **Both workflows are green on the head's tree** (Read). Both checked out merge commit `01a2ded`, whose tree is `552211d5`, the head's tree (§5).
- **The PR body** has the new counts (48; 7 accepted, 41 refused) and mutant totals (47; 38 killed, 9 survivors), and both O37-2 slips are fixed (Read).

**Failing tests: none on this head.** The audit 34 test set passes (8 of 8), the root package passes, and both workflows' gates pass. The only `--- FAIL` lines in the CI logs come after the step "Listed tests still fail" started, which must show the listed tests failing (§5). In my container, 29 top-level tests of the `scripts` package fail for environment reasons, the same 29 in all four package runs (§3.3); none of them is a test this delta touches.

One observation and two notes:

- **O38-1:** "exactly two stderr lines" now has a case at every position where an extra line can sit, and a case with no first line, but no case with only the first line. Two of my mutants that admit `unable to load certificate\n` alone survive the whole `scripts` package. Under the recorded standard (one isolating case per stated clause) this is not a finding, because `missing_first_line` already breaks "no fewer" on its own. Under the stricter reading the coordinator took for O37-1 at 13:17Z, it is the one position of that rule still open. I give a verified case and recommend adding it, together with a second one for no stderr at all (O38-2 note), so that the line-count rule is closed in one step (§4).
- **Notes (§4):** a pre-existing test gap for exit 1 with no output at the malformed-PEM call sites; two wording points in the PR body and report 33.

## 2. Provenance reproduction

Ran, in a fresh clone under `umask 022`:

- **Recipe:** `sha256sum -c` of the shared-folder file against the pin: OK. I copied it to `/opt/audit/v2.py` and checked that copy against the pin before each run.
- **Fetch:** `git fetch origin trunk_dev claude/project-thread-wbmulu` gives the topic tip `d31043d…` and trunk_dev `7e27168…`. The base is an ancestor of the tip. The head's tree is `552211d5…`.
- **Sequence:** provenance §5.3: checkout of the tip, clean status, `git reset --mixed 7e27168`, upstream set to `origin/trunk_dev`, v2 twice into a fresh 0700 directory. The two outputs are byte-identical and `cmp`-identical to the writer's `33-evidence/manifest-d31043d-vs-7e27168.json`. 5 files, all `tracked_modified`, mode 0644, so there is no mode-bit difference.
- **Closing run** (14:14Z): two runs, identical to the opening ones. `git ls-remote` at 14:14Z: the branch and `refs/pull/62/head` are still `d31043d`, trunk_dev still `7e27168`.
- **GitHub (API, about 13:37Z):** PR #62 has head `d31043d…`, base `7e27168…`, 6 commits, not a draft, `mergeable_state: blocked` while the checks were running. No reviews. The only two comments are Codex's (a failed review of `72eecb2`, and the note that it is out of credits).
- **Against audit 37's manifest** of `a34e339` against the same base (per-file records compared by script): the doc, the macOS list, the collector and `…openssl3013_test.go` are byte-identical. Only the status test differs (`b4d97dd3…` to `596ebca3…`).
- **The commit:** `d31043d` has one parent, `a34e339`, the commit audit 37 accepted, so the branch only gained a commit (no force push). Its message describes the repair of the writer's §11.

## 3. Coverage

### 3.1 The delta (Read and Ran)

The diff adds two tuples after `extra_line` (lines 1047-1048 at `d31043d`) and changes `len(results) != 46` to `!= 48` (line 1089). The added tuples are identical to report 37 §4 and to `o37-1-cases.py` (`diff` of the tuples: empty; only the indentation and the closing `)` of the script's tuple differ).

I extracted the probe's case table from the test file and ran it against the audited collector (`cases-38.py`, the logic of audit 37's `cases-37.py`; output `cases-38-out.txt`). Each line-count case differs from the accepted pinned certificate refusal (313 bytes) in one place only:

| Case | Where it differs | Stderr lines |
|---|---|---|
| `leading_line` | `warning\n` inserted at byte 0, before the first line | 3 |
| `line_between_the_two` | `warning\n` inserted at byte 27, between the two lines | 3 |
| `extra_line` (existing) | `warning\n` appended at byte 313, after the second line | 3 |
| `missing_first_line` (existing) | the first line (27 bytes) removed | 1 |

Exit code 1 and empty stdout stay as in the accepted cases. The collector refuses all four. At `a34e339` the same script gives 46 cases, 7 accepted and 39 refused, all true. So the delta is exactly these two refused cases.

### 3.2 Mutants (Ran; `run-mutants-38.sh`, `mutants-38-out.txt`, `compare-38.py`, `compare-38-out.txt`)

**Setup.** As in audit 37: one test binary built as user `ci` (uid 1500, gid 1600, `env -i`, `umask 022`, Go 1.26.5) from a ci-owned clone at `d31043d`; for each mutant the runner rewrites the collector in that clone and runs the audit 34 test set (`…LibreSSLMalformedPEMLocation`, `…OpenSSLGrammar`, `…CollectionTypedFailures`, `…Target3013.*`, `…X509TextSignatureTails`). The unmutated run passes all 8. The collector was restored and `cmp`-checked at the end, sha256 `326c8d12…`. The mutant scripts of audits 35, 36 and 37 were copied from their evidence folders with the hashes in those folders' `SHA256SUMS.txt` checked (all OK); the writer's two `W_` mutants come from `33-evidence/mut35-extra.py.txt` (sha256 `45efb79e…c101`). Every mutant except the two `W_` has a witness input on which it and the audited collector disagree.

**The 47 earlier mutants.** With timings removed, my kill sets equal the writer's `33-evidence/mutants-a37-after-repair.txt` for every one of the 47 (`compare-38-out.txt`: "differing: none"). 38 killed, 9 survive: `M_empty_components` (O35-1), `E_kind_guard_dropped` (O36-3), the five `F_` (O36-2), and `N_first_line_optional_for_key`, `N_key_object_any_optional` (report 37 §3.2). The four of O37-1:

| Mutant | a34e339 (audit 37) | d31043d (this check) |
|---|---|---|
| `P_leading_line_allowed` | survived | killed: `leading_line` |
| `P_any_prefix` | survived | killed: `leading_line` |
| `P_search_end_anchored` | survived | killed: `leading_line` |
| `P_line_between_allowed` | survived | killed: `line_between_the_two` |

`E_search` is now killed by `extra_line` and `leading_line`.

**14 mutants of my own** (`mutants-38.py`, witnesses in `witness-38.py`), group Q: other ways to loosen "exactly two stderr lines" at each position, so the two new cases are judged against the rule and not only against audit 37's mutants of it.

| Mutant | What it loosens | Result |
|---|---|---|
| `Q_leading_lines_any_count`: `(?:[^\n]*\n)*` before the first line | no line before | killed: `leading_line` |
| `Q_line_anchor_search`: `re.search((?m)^ + pattern + \Z)` | no line before | killed: `leading_line` |
| `Q_last_two_lines`: match only the last two lines | no line before | killed: `leading_line` |
| `Q_between_line_not_a_digit`: an optional line not starting with a digit between the two | no line between | killed: `line_between_the_two` |
| `Q_other_lines_anywhere`: any lines before, between and after | all three positions | killed: `extra_line`, `leading_line`, `line_between_the_two` |
| `Q_blank_line_before`: `\n?` before the first line | no line before, empty line only | survived (no case needed: a narrower form at a pinned position) |
| `Q_blank_line_between`: `\n?` between the two | no line between, empty line only | survived (same) |
| `Q_first_line_repeated`: `(?:first)+` | no line between, first line only | survived (same) |
| `Q_leading_line_for_key_only` | no line before, pkey only | survived (no case needed: a pkey-only form of a rule stated once for both kinds, as report 37 §3.2) |
| `Q_line_between_for_key_only` | no line between, pkey only | survived (same) |
| `Q_two_lines_either_order`: the two lines in either order | first-line literal and position together | survived (no case needed: a swapped refusal is `missing_first_line` plus `extra_line`, each already refused on its own) |
| `Q_first_line_alone`: also admit the first line alone | no fewer: the second line | **survived** (O38-1) |
| `Q_second_line_optional`: the whole second line optional | no fewer: the second line | **survived** (O38-1) |
| `Q_empty_stderr`: also admit empty stderr | no fewer: zero lines; "no generic nonzero failure" | **survived** (O38-2 note) |

So the two new cases pin their positions against every broader form of loosening I tried. The survivors are narrower forms at a pinned position, pkey-only forms, a combination of two pinned breaks, and the three in bold.

### 3.3 The whole `scripts` package against the bold survivors (Ran; `run-package-38.sh`, `package-38-out.txt`)

Audit 36 §3.2 found that only the status test feeds refused LibreSSL forms. Empty stderr is not a LibreSSL form, so I did not rely on that and ran the whole package, one run at a time and alone on the machine, as `ci` with HUP/INT/QUIT/TERM reset: unmutated (13:49Z to 13:55Z), then with `Q_second_line_optional`, `Q_empty_stderr` and `Q_two_lines_either_order`.

- All four runs fail the same 243 `--- FAIL` lines (29 top-level tests; `package-failing-tests-unmutated.txt`). They are environment failures of this container: operator wrapper tests (exit 127, ssh stubs), root-or-sudo tests, root-loaded custody tests and P0t diagnostics. Every test of the audit 34 set passes in each run.
- No mutant adds or removes a failing line. So the three survive every test that can pass in this container.
- **Unknown:** whether any of the 29 tests would kill them where they pass (CI, as root). Inference: unlikely, since they exercise the wrapper, custody and diagnostics paths, not the malformed-PEM call sites; a CI run of a mutant would confirm it.
- `Q_first_line_alone` admits exactly the inputs `Q_second_line_optional` admits beyond the audited collector (the first line alone, per kind), so I did not run it separately.

### 3.4 Other checks (Ran)

As user `ci` under `env -i`, `umask 022`, Go 1.26.5, Python 3.13.18, OpenSSL 3.0.13, in a git clone at `d31043d` (`other-checks-out.txt`):

- the audit 34 test set: 8 of 8 pass (unmutated line of `mutants-38-out.txt`, and in the unmutated package run);
- root package `go test -count=1 .`: `ok execution-substrate 2.965s`;
- `go vet ./scripts/ .`: clean;
- `gofmt -l scripts/ *.go`: nothing;
- the clone's `git status` was clean before and after;
- the macOS list is byte-identical to the one audits 36 and 37 checked (same manifest record), so I did not re-run `check_list`.

## 4. Observations (non-blocking)

### O38-1: no case with only the first line

- **Evidence:** `Q_first_line_alone` and `Q_second_line_optional` pass the audit 34 test set and every test of the `scripts` package that passes in this container (§3.3). Each admits `unable to load certificate\n` alone (or `unable to load key\n` for pkey), which the audited collector refuses.
- **The rule:** the doc says "exactly two stderr lines" (`remote_supported_host_alpha.md:4005`). Audit 36 split it into "no more" and "no fewer". With `d31043d`, "no more" has a case at all three positions (`leading_line`, `line_between_the_two`, `extra_line`). "No fewer" has a case for the first line missing (`missing_first_line`) but none for the second line missing.
- **Under the recorded standard** (one isolating case per stated clause; audit 36 O36-2), "no fewer" is pinned by `missing_first_line`, so this is another position of a pinned clause and not a finding. That is how audit 37 judged O37-1.
- **Under the stricter reading** the coordinator took for O37-1 at 13:17Z (each position of the clause gets its case), this is the one position of the same rule still open.
- **Impact:** as for O37-1, a match yields only `certificate_malformed` or `key_malformed`, never a pass (audit 34 §5). A collector change of this kind could misclassify a failed `openssl` run as malformed material; it could not admit material.
- **Patch defect or pre-existing:** pre-existing. The matcher's first line, the start of the second line and the `re.fullmatch` call are unchanged from base `7e27168` (Ran: `git diff 7e27168 d31043d` of the collector changes only the location constant and its use), and no test at base or head feeds the first line alone (Ran: `git grep` at both commits). Inference: the two mutants also pass every test at base; I did not run them there.
- **Verified cases** (`o38-1-cases.py`, `o38-1-cases-out.txt`):

  ```
  ("missing_second_line",False,"certificate",1,b"",b"unable to load certificate\n"),
  ("no_stderr",False,"certificate",1,b"",b""),
  ```

  With both added to the table at `d31043d`, there are 50 cases (7 accepted, 43 refused), no repeated label, and all 50 checks are true on the audited collector. `missing_second_line` kills `Q_first_line_alone` and `Q_second_line_optional`; `no_stderr` kills `Q_empty_stderr`. The count would go from 48 to 50.
- **My recommendation:** add both before the merge gate. The coordinator has already chosen the position reading for this rule; leaving the "fewer" side half covered makes the standard inconsistent inside one clause, and the next auditor would find this same gap. With `missing_second_line`, every position of "exactly two lines" has its case, so the line-count rule is closed: narrower forms at a pinned position, pkey-only forms and combinations of pinned breaks (the other Q survivors) need no case, by the reasoning audits 36 and 37 used. The follow-up diff check is mechanical (two tuples and a count).

### O38-2 (note): exit 1 with no output at the malformed-PEM call sites

`Q_empty_stderr` survives the whole package. The doc states "No generic nonzero failure is admitted" (`remote_supported_host_alpha.md:4024-4025`), and exit 1 with empty stdout and empty stderr is the plainest generic failure. The only test my search found that feeds `(1, b"", b"")` is in `…X509TextRoleCompatibility` (`remote_alpha_es_service_tls_status_test.go:1279`). It passes with the mutant, so it does not bring that tuple to `_known_malformed_pem`, whose only callers are `cert_metadata` and `key_pair` (`remote_alpha_es_tls_status.py:2402` and `:2518`). This is pre-existing and wider than the LibreSSL rule, but the cheapest place to pin it is the same table, which is why `no_stderr` is in the O38-1 pair. If the coordinator adds only `missing_second_line`, this gap needs its own tracked item, not a prose note.

### Wording notes (no byte change)

- **PR body:** "On `d31043d` … both workflows started at 13:28Z" is now stale. Both are green (§5); the writer should update that line before the merge gate.
- **Report 33 §11:** "I ran all 47 mutants of audits 35, 36 and 37 and my own two" reads as 49. The run has 47 in all (audits' 45 plus the writer's 2), which is what the PR body says ("the auditors' 45 and 2 of my own, 47 in all").

### Carried

- **O36-4 (from audits 34 and 35):** the runner's exact LibreSSL stderr is still not recorded, because the tests pass there.

No finding rejected. No disagreement with the writer or with audit 37.

## 5. CI on the head (Read; logs fetched with `get_job_logs`)

Both runs have `head_sha` `d31043d…`, event `pull_request`, attempt 1, conclusion success. Both checked out `refs/remotes/pull/62/merge`, "HEAD is now at 01a2ded Merge d31043d… into 7e27168…". I fetched `refs/pull/62/merge` myself: `01a2ded7c86e48baa08b42d70290c6fa7b5bbe3f`, parents `7e27168` and `d31043d`, tree `552211d5`, the head's tree; `git merge-tree --write-tree 7e27168 d31043d` gives the same tree. So CI tested the audited bytes. Both logs are in the evidence folder (decoded `logs_content` plus one final newline).

- **"test on macOS" (workflow go-macos), run 45623905093, job 139238946071, 13:28:15Z to 13:59:34Z, success.**
  - Image macos-26-arm64, version 20261117.0516.1, go1.26.5 darwin/arm64.
  - Self-check: "Ran 145 tests", OK.
  - `ok execution-substrate/scripts` in 420.072 s and 406.626 s.
  - "test gate passed: 2 packages, 1 of them with skipped entries (26 entries); 81 tests skipped themselves, all of them listed".
  - "all 26 listed tests still fail on this host, each in a run of its own and in the run of its package".
  - 144 `--- FAIL` lines; the first is at line 541, after the step "Listed tests still fail" started (line 522).
- **"build, vet and test" (workflow go), run 45623905063, job 139238945413, 13:28:15Z to 14:13:08Z, success.**
  - Image ubuntu-24.04, version 20261116.133.1, go1.26.5 linux/amd64. Build, vet and vet for macOS passed.
  - Self-check: "Ran 145 tests", OK.
  - `ok execution-substrate/scripts 357.129s`; root package `ok execution-substrate 4.124s`.
  - "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed".
  - "all 17 listed tests still fail on this host"; "tests as root passed: 9 of execution-substrate/scripts".
  - 98 `--- FAIL` lines; the first is at line 802, after the step "Listed tests still fail" started (line 779).

Extract: `ci-extract.txt`.

## 6. Red-team

The coordinator recorded no separate red-team for #62 (report 33 §7, restated in §11). This delta changes no product byte; the collector has the same bytes as at `72eecb2`, which audit 34 judged. Nothing here changes that basis.

## 7. Sensitive-material handling

No secrets, keys or certificates were read or written. All case and mutant inputs are synthetic. The CI logs are public runner logs of this repository; the extract holds only checkout lines, image and toolchain versions and gate summaries. The Go toolchain came from the Go module proxy; the container's proxy CA was copied to `/opt/audit` only to let `ci` download modules.

## 8. Confidence

- **Provenance: 1.0.** The manifest reproduced byte for byte, the opening run equals the closing one, the PR head equals the audited commit, and CI ran on the head's tree.
- **Validation: 0.95.** I re-ran the test set, the root package, 61 mutants and four whole-package runs on the exact bytes. The macOS result rests on the runner's log, which I read. 29 environment-only tests could not run here (§3.3).
- **Implementation: 0.95.** The collector is unchanged and was judged correct in audit 34. The remaining doubt is O38-1, a review-standard question about the tests, not the code.

## 9. Effect status and next steps

No repair, commit, push, PR edit, comment, merge or box contact. Audit-created files were only in `/opt/audit` and `/home/ci` of this container.

1. The coordinator decides O38-1. My recommendation: the writer adds `missing_second_line` and `no_stderr` (48 to 50), then a mechanical diff check of that delta. If the coordinator keeps the recorded standard instead, `d31043d` is ready for the merge gate as it is, and O38-2 needs a tracked item.
2. Either way, the writer updates the PR body's CI line for the final head.
3. Merge gate: the PR head must equal the accepted commit, trunk_dev must still be `7e27168` or be handled per provenance §5.4, and both workflows, "test on macOS" included, must be green on the final head.

## 10. Evidence

`38-pr62-diff-check-evidence/`, with `SHA256SUMS.txt`:

- `manifest-d31043d-vs-7e27168-opening.json` and `…-closing.json`: my v2 manifests, `f8a43fad…5560`;
- `delta-a34e339-to-d31043d.diff`: the delta, equal to the writer's;
- `cases-38.py` and `cases-38-out.txt`: the case table, its counts on `d31043d` and `a34e339`, and where each line-count case differs;
- `mutants-38.py` and `witness-38.py`: my 14 mutants, each with a witness input;
- `run-mutants-38.sh`, `asci.sh` and `mutants-38-out.txt`: the runner (audit 35's 14, the writer's 2, audit 36's 17, audit 37's 14 and my 14) and its results at `d31043d`;
- `compare-38.py` and `compare-38-out.txt`: my kill sets against the writer's;
- `run-package-38.sh`, `package-38-out.txt`, `package-failing-tests-unmutated.txt`, `package-failing-lines-unmutated.txt`: the whole-package runs;
- `o38-1-cases.py` and `o38-1-cases-out.txt`: the two cases of O38-1 and their check;
- `other-checks-out.txt`: root package, vet, gofmt;
- `ci-extract.txt`, `macos-run45623905093-job139238946071.log`, `linux-run45623905063-job139238945413.log`: CI.

```
Final verdict: ACCEPT
```
