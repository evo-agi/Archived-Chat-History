# 36. Delta check of ES PR #62, f2cc70f to 4cacbff: the repair of diff check 35 and the merge of #60

```
INDEPENDENT AUDIT REPORT
Repository:      evo-agi/Execution-Substrate, PR #62 "TLS status: accept the LibreSSL malformed-PEM refusal of any Apple build"
Audit target:    base trunk_dev 7e271681b63e33891f287ca0f745d45cebeee4f5 (#60)
                 topic claude/project-thread-wbmulu, commit 4cacbff2ef6fae35172aff9308792e7dc7d7222b,
                 tree 7ccf99968f63d18b66b843820e38e736c150b663
                 delta under review: f2cc70f (diff check 35, BLOCK) to 4cacbff: f56ed54 (test repair) and
                 4cacbff (merge of trunk_dev 7e27168)
Recipe:          governed-execution.audit-patch-manifest.v2, source SHA-256
                 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified before each run)
Manifest:        f95103b11c2df6939a9289534a6e52934d479227f1096ec5dbd631b15d8b56c0, 5 changed paths,
                 textual_diff_sha256 052f43b288b2ab96d75ae8bdc02690560ac3448df536084519bfacca4e73344a
Writer report:   33-libressl-grammar-pr62.md §8-9, SHA-256 d887b791d5c5418b32a864fc656d1f0b03587e9942aa37630d128fdf29a78dc5
Audit posture:   read-only. No subagents. Nothing pushed, no PR edit, no GitHub comment, box not touched.
                 I had not audited PR #62 before (protocol §14).
Verdict:         BLOCK (one Low test gap; the product bytes, the merge and every claim of the writer that I checked hold)
```

All times are UTC on 2026-11-25. The check ran from 11:22Z to about 11:55Z in a fresh cloud container.

## 1. Verdict in short

Every claim in the writer's §8-9 holds on the exact bytes:

- **The manifest reproduces** byte for byte: the writer's `f95103b1…b56c0`, twice at opening and twice at closing (Ran).
- **The collector is unchanged.** `scripts/internal/remote_alpha_es_tls_status.py` is `326c8d12…4f94057` at `4cacbff`, the same as at `72eecb2` and `f2cc70f` (Ran).
- **The repair is test only.** `f56ed54` touches only `scripts/remote_alpha_es_service_tls_status_test.go`, +10/−3. Its diff equals the writer's `repair-f2cc70f-to-f56ed54.diff` (Ran).
- **The test has 42 cases, 7 accepted and 35 refused, with no repeated label** (Ran). The 7 new refused cases are the 5 that audit 35 asked for and the writer's 2.
- **The six target mutants are killed**, each by the case written for it: the five `X_` location mutants and `X_thread_id_any_text`. So are the writer's two `W_` mutants. `M_empty_components` still survives, as audit 35 allowed (O35-1) (Ran).
- **#60 merged in cleanly.** `4cacbff` is git's own merge of `f56ed54` and `7e27168`: `git merge-tree --write-tree` gives the head's tree `7ccf9996`. `git range-diff` shows all three PR commits unchanged (Ran).
- **The macOS list has 26 entries and 81 skips.** The gate's own `check_list` passes on it (Ran).
- **Both workflows are green on the head's tree** (Read). Both checked out merge commit `73bd18d`, whose tree is `7ccf9996`. I fetched both job logs myself, and they equal the writer's copies byte for byte.

It is still BLOCK, on a gap that neither audit 34 nor audit 35 looked at. Those audits mapped the clauses of the source location. I mapped every clause of the whole LibreSSL refusal (§3.3):

- **A36-1 (Low, test gap):** four rules that the doc states have no refused case of their own. The rules are older than this PR, but the PR body says the 35 refused cases cover "each clause of the stated rule". That claim is not true for these four:
  - "exactly two stderr lines": nothing refuses a stderr that has lost its first line;
  - "for `pkey`, it is `unable to load key`": no key case changes only the first line;
  - "respectively `TRUSTED CERTIFICATE` or `ANY PRIVATE KEY`": no case changes only the expected object, for either kind.

  Four mutants that loosen these rules pass every test. Each admits an input that the audited collector refuses. They also pass every TLS test on base `7e27168`, so this PR did not lose any coverage.

The fix is four refused cases in the same test, test only (§5). I checked that they pass on the audited collector and kill all four mutants. With them, every stated clause of the whole matcher has a refused case of its own (§3.3). That makes the list closed, so another diff check should not find a next layer.

## 2. Provenance reproduction

Ran, in a fresh clone under `umask 022`:

- **Recipe:** v2 `sha256sum -c` against the pin: OK, before each run.
- **Fetch:** `git fetch origin trunk_dev claude/project-thread-wbmulu` gives the topic tip `4cacbff…` and trunk_dev `7e27168…`. The base is an ancestor of the tip. The head's tree is `7ccf9996…`.
- **Sequence:** provenance §5.3, as follows:
  - checkout of the tip, then a check that the status is clean;
  - `git reset --mixed 7e27168`, with the upstream set to `origin/trunk_dev`;
  - v2 twice, into a fresh 0700 directory, at 11:23:49Z.

  The two outputs are byte-identical. They are also `cmp`-identical to the writer's `33-evidence/manifest-4cacbff-vs-7e27168.json`. The manifest has 5 files, all `tracked_modified` with mode 0644, so there is no mode-bit difference.
- **Closing run** (11:51:49Z): two runs, identical to the opening ones. The remote tip and trunk_dev were unchanged (`git fetch`, then `git ls-remote`).
- **GitHub (API, about 11:25Z):** PR #62 has head `4cacbff…`, base `7e27168…`, `mergeable_state: clean`, 4 commits, and is not a draft.
- **Against earlier manifests** (per-file records compared by script):
  - against audit 35's `f2cc70f`/`819f712` manifest: the collector and `…openssl3013_test.go` are byte-identical. The status test differs, which is the repair. The doc and the macOS list differ, because trunk_dev's versions of those two files changed under #60;
  - against the writer's `f56ed54`/`819f712` manifest: all three code files are byte-identical.
- **Diffs:**
  - `git diff f2cc70f f56ed54 | sha256sum` = `15637527…c346`, equal to `33-evidence/repair-f2cc70f-to-f56ed54.diff`;
  - `git diff 7e27168 4cacbff | sha256sum` = `a500b0c5…f350`, equal to `33-evidence/pr62-4cacbff-vs-7e27168.diff`;
  - `git diff 819f712 f56ed54` and `git diff 7e27168 4cacbff` are the same apart from their `index` and `@@` lines, and that includes the context lines.

## 3. Coverage

### 3.1 The delta (Read)

**`f56ed54`** (test only, lines 1015-1020, 1031-1033, 1050-1055 and 1083 at `4cacbff`):

- `refusal()` takes a new `thread` argument whose default is the old literal `b"4336234112"`, so every earlier case builds the same bytes as before;
- 7 new refused cases:
  - `non_decimal_thread_id` (`0x1a2b`) and `missing_thread_id` (empty);
  - `other_word_for_error` (`:warning:`);
  - `prefix_on_the_crypto_folder` (`/xcrypto/pem/`) and `other_case_of_the_suffix` (`/CRYPTO/PEM/PEM_LIB.C`);
  - `non_decimal_line_number` (`:0x2b6`) and `text_after_line_number` (`:694x`);
- the expected count goes from 35 to 42.

Each new case changes one part of the accepted `pinned_build_certificate` refusal, and only that part. Each `replace` anchor occurs once in the base string. `:error:` appears once in a refusal, and `/crypto/pem/` and `:694` appear once in `apple`.

**`4cacbff`** (merge): no conflict, no hand edit (§2). #60 edits other parts of `remote_supported_host_alpha.md`, and its own groups of the macOS list. The PR's added and removed lines are unchanged.

### 3.2 Mutants (Ran; `36-pr62-delta-check-evidence/`)

**Setup.**

- I built one test binary as user `ci`, from a copy of tree `7ccf9996`.
- For each mutant, I rewrote the collector in the copy and ran the audit 34 test set:
  - `…LibreSSLMalformedPEMLocation`, `…OpenSSLGrammar`, `…CollectionTypedFailures`;
  - `…Target3013.*` and `…X509TextSignatureTails`.
- The unmutated run passes all 8 tests.
- For every mutant, a witness input shows that it and the audited collector disagree, so none is equivalent.
- The copy was restored at the end, `cmp`-checked against the audited bytes, sha256 `326c8d12…`.

**The 16 mutants of audit 35 and the writer** (tables copied from `35-pr62-delta-check-evidence/` and `33-evidence/`, sha256 equal):

| Mutant | Result at `4cacbff` |
|---|---|
| `M_ctl_only_nl_cr_nul` | killed: `tab_in_path`, `escape_in_path`, `unit_separator_in_path`, `delete_in_path` |
| `M_no_del` | killed: `delete_in_path` |
| `M_relative_prefix_allowed` | killed: `relative_path_with_a_folder`, `relative_path_from_the_parent` |
| `M_old_pinned_path` | killed: the 5 accepted non-pinned cases |
| `M_any_file_in_pem` | killed: `other_source_file` |
| `M_line_optional` | killed: `missing_line` |
| `M_dot_unescaped` | killed: `other_character_for_the_dot` |
| `X_line_any_text`, `X_line_hex`, `X_line_trailing_text` | killed: `non_decimal_line_number`, `text_after_line_number` |
| `X_no_boundary_before_crypto` | killed: `prefix_on_the_crypto_folder` |
| `X_suffix_any_case` | killed: `other_case_of_the_suffix` |
| `X_thread_id_any_text` | killed: `non_decimal_thread_id` |
| `W_thread_id_optional` | killed: `missing_thread_id` |
| `W_any_word_for_error` | killed: `other_word_for_error` |
| `M_empty_components` | survived (O35-1: no stated rule) |

These are the same results as the writer's `33-evidence/mutants-a35-after-repair.txt`.

**17 mutants of my own**, over the rest of `_known_malformed_pem` (`remote_alpha_es_tls_status.py:1901-1912`). Audits 34 and 35 covered the location pattern. These cover the first line, the expected object, the guard and the call:

| Mutant | What it loosens | Result |
|---|---|---|
| `C_object_either_kind`: either object for either kind | "respectively `TRUSTED CERTIFICATE` or `ANY PRIVATE KEY`" | **survived** (admits `…:Expecting: ANY PRIVATE KEY` for x509) |
| `C_key_object_any`: `[A-Z ]+` as the key's object | the key's object `ANY PRIVATE KEY` | **survived** (admits `…:Expecting: PRIVATE KEY` for pkey) |
| `C_key_first_line_either`: either first line for a key | "for `pkey`, it is `unable to load key`" | **survived** (admits `unable to load certificate` for pkey) |
| `C_first_line_optional`: the first line made optional | "exactly two stderr lines" | **survived** (admits a one-line stderr) |
| `C_first_line_any_text`: any first line | the first line for x509 | killed: `other_first_line` |
| `E_ignorecase`: `re.IGNORECASE` | exact case | killed: `other_case_of_the_suffix` |
| `E_match_prefix_only`: `re.match` | whole stderr | killed: `extra_line` |
| `E_search`: `re.search` | whole stderr | killed: `extra_line` |
| `E_final_newline_optional` | one newline | killed: `missing_newline` |
| `E_any_nonzero_exit`: `code == 0` in the guard | exit 1 | killed: `other_exit_code`, and `…Target3013MalformedResponses` |
| `E_stdout_ignored` | empty stdout | killed: `stdout_output`, and `…Target3013MalformedResponses` |
| `E_kind_guard_dropped` | none stated | survived (O36-3: no caller can reach it) |
| `F_library_any`: `[^:\n]+` for `PEM routines` | a part of the fixed text | survived (O36-2) |
| `F_error_word_case_blind` | a part of the fixed text | survived (O36-2) |
| `F_colon_before_location_optional` | a part of the fixed text | survived (O36-2) |
| `F_expecting_label_any`: `[A-Za-z]+` for `Expecting` | a part of `:Expecting: ` | survived (O36-2) |
| `F_first_line_case_blind` | a part of the first line | survived (O36-2) |

**On base `7e27168`** I ran the four `C_` survivors against every `TestRemoteAlphaESServiceTLS…` test, with a test binary built from base. Each gives the same three failures as the unmutated run, and those three fail only because this is a container (`…FailureWitnessBootstrapOwnedTerminal`, `…RootLoadedStageCustody`, `…StageFIFOSubstitution`). So no base test killed them either: the gap is older than the PR, and the PR lost no coverage (`base-survivors-out.txt`).

Only two test files hold the LibreSSL text: the status test and `…openssl3013_test.go`. `git grep 09FFF06C` over the whole tree at `4cacbff` finds those two, the collector and the doc. The openssl3013 test feeds only accepted LibreSSL forms (`legacy_cert`, `legacy_key`). No other test can feed a LibreSSL refusal, because the collector runs only the fixed `/usr/bin/openssl`. So I did not run the whole `scripts` package for each mutant.

### 3.3 Every stated clause of the LibreSSL refusal, and the case that pins it

The clauses come from the doc (`.docs/system_overview/remote_supported_host_alpha.md:4004-4014`), the code comment (`remote_alpha_es_tls_status.py:1893-1897`) and the PR body. A clause counts as pinned when at least one refused case breaks that clause alone. One exact literal counts as one clause (see O36-2).

| # | Clause | Refused case at `4cacbff` |
|---|---|---|
| 1 | exit 1 | `other_exit_code` |
| 2 | empty stdout | `stdout_output` |
| 3a | exactly two stderr lines: no more | `extra_line` |
| **3b** | **exactly two stderr lines: no fewer** | **none** (A36-1) |
| 4 | for x509, the first line is `unable to load certificate` | `other_first_line` |
| **5** | **for pkey, the first line is `unable to load key`** | **none** (A36-1); `certificate_refusal_for_a_key` also changes the object, which refuses it by itself |
| 6 | a decimal thread identifier | `non_decimal_thread_id`, `missing_thread_id` |
| 7 | the fixed text `:error:09FFF06C:PEM routines:CRYPTO_internal:no start line:` | `other_word_for_error`, `other_error_code`, `other_function`, `other_reason` |
| 8 | the source location (audit 35 §3.3, 8 clauses) | all pinned now: `non_decimal_line_number`, `text_after_line_number`, `prefix_on_the_crypto_folder` and `other_case_of_the_suffix` close audit 35's gaps |
| 9 | `:Expecting: ` | `missing_expecting` |
| 10a | for x509, the object is exactly `TRUSTED CERTIFICATE` | `other_expected_object` |
| **10b** | **for x509, not the key's object** ("respectively") | **none** (A36-1); `key_refusal_for_a_certificate` also changes the first line |
| **11** | **for pkey, the object is `ANY PRIVATE KEY`** | **none** (A36-1) |
| 12 | one newline at the end | `missing_newline` |
| 13 | the whole stderr matches, nothing before or after | `extra_line` (kills `re.match` and `re.search`) |

With the four cases in A36-1's correction, every row has a refused case of its own.

### 3.4 Other checks (Ran)

All of these were run as user `ci` (uid 1500, gid 1600), under `env -i` and `umask 022`, with Go 1.26.5, Python 3.13.18 and OpenSSL 3.0.13. The tree was a git clone at `4cacbff`:

- the audit 34 test set passes (8 of 8);
- root package `go test -count=1 .`: `ok execution-substrate 3.069s`, so the docs pins hold with #60's text merged in;
- `go vet ./scripts/ .`: clean;
- `gofmt -l scripts/ *.go`: nothing;
- the gate's own `check_list`:
  - `.github/ci/environment-only-tests-macos.txt` against `./scripts/...`: OK, 26 entries and 81 `skips-itself` lines;
  - `.github/ci/environment-only-tests.txt` against `./...`: OK, 17 and 14;
- entry counts of the macOS list by commit:

  | Commit | Entries | Skips |
  |---|---|---|
  | `819f712` | 22 | 80 |
  | `f56ed54` | 20 | 80 |
  | `7e27168` | 28 | 81 |
  | `4cacbff` | 26 | 81 |

  So the head is #60's list minus the PR's two LibreSSL entries;
- neither list names `…LibreSSLMalformedPEMLocation`, `…OpenSSLGrammar` or `…CollectionTypedFailures`.

Not re-run: the whole `scripts` package. Both workflows ran it on the head's tree (§6). Locally, the delta is cases added to one test.

## 4. The surviving mutants that are not findings

- **`M_empty_components`:** O35-1, unchanged. No stated rule refuses `//`, and the code is stricter than its statement, which is the safe direction.
- **The `F_` mutants (O36-2):** each loosens one part inside an exact literal, for example the library name `PEM routines`, the word `Expecting`, the case of `error` or of the first line, or the colon before the location.
  - The doc states each literal as one exact text, and each literal already has a refused case that changes it. The fixed text of clause 7 has four.
  - A literal of n bytes can be loosened at any of its n positions in many ways, so no finite list of cases can refuse every such loosening. The workable line, and the one audits 34 and 35 drew (for example, `pem_lib.c` is pinned by three cases, not one per letter), is one refused case per stated clause.
  - Holding PR #62 to a per-byte standard would reopen the review every round.
  - A match yields only `certificate_malformed` or `key_malformed`, never a pass (audit 34 §5).
- **`E_kind_guard_dropped` (O36-3):** both call sites pass a literal kind (`:2402` `"certificate"`, `:2518` `"key"`), so no caller can reach the guard. No rule states it. It is unchanged from base.

## 5. Findings

### A36-1

```
AUDIT FINDING
ID / Type / Severity: A36-1 / test gap / low
Current contract: doc remote_supported_host_alpha.md:4004-4014: "exit 1, empty stdout, and exactly two stderr lines.
  For x509, the first is `unable to load certificate`; for pkey, it is `unable to load key`. ... and respectively
  `TRUSTED CERTIFICATE` or `ANY PRIVATE KEY`, then one newline." Code remote_alpha_es_tls_status.py:1908-1912.
  The PR body says the 35 refused cases give "one or more for each clause of the stated rule".
Path and line: scripts/remote_alpha_es_service_tls_status_test.go:1022-1066 at 4cacbff (the 42 cases), :1083 (the count)
Evidence: four mutants of _known_malformed_pem pass every test of the audit 34 set at 4cacbff, and every
  TestRemoteAlphaESServiceTLS… test on base 7e27168. Each admits an input that the audited collector refuses
  (witness-36.py, mutants-out.txt, base-survivors-out.txt):
    C_first_line_optional: a stderr without its first line ("exactly two stderr lines");
    C_key_first_line_either: "unable to load certificate" as the first line of a pkey refusal;
    C_object_either_kind: ":Expecting: ANY PRIVATE KEY" in an x509 refusal ("respectively");
    C_key_object_any: ":Expecting: PRIVATE KEY" in a pkey refusal.
  The cross-kind cases key_refusal_for_a_certificate and certificate_refusal_for_a_key change the first line and
  the object together. So for a certificate, other_first_line pins the first line alone, but no case pins the
  object alone for either kind, or the first line alone for a key.
Impact: none today; the product code is right. A later edit could loosen these four rules with every test green:
  the same class as A34-1, A35-1 and A35-2.
Required correction: add four refused cases to …LibreSSLMalformedPEMLocation and raise the count from 42 to 46.
  The cases below were checked against the audited collector and the mutants (proposed-cases.diff,
  proposed-cases-check.txt):
    ("missing_first_line",False,"certificate",1,b"",refusal("certificate",line=b"")),
    ("certificate_first_line_for_a_key",False,"key",1,b"",refusal("key",line=b"unable to load certificate\n")),
    ("key_object_for_a_certificate",False,"certificate",1,b"",refusal("certificate",expecting=b":Expecting: ANY PRIVATE KEY\n")),
    ("certificate_object_for_a_key",False,"key",1,b"",refusal("key",expecting=b":Expecting: TRUSTED CERTIFICATE\n")),
  All four are refused by the audited collector, which keeps 46 of 46 checks true. They kill C_first_line_optional,
  C_key_first_line_either, C_object_either_kind (two cases) and C_key_object_any. Then update the PR body's count
  (35 refused becomes 39). Test only; the collector stays unchanged.
Uncertainty: none on the results; they are reproducible with the scripts in the evidence folder.
Patch defect or pre-existing: the four rules and their code are unchanged from base 819f712. The gap is in this PR's
  new test, which, with the PR body, claims to pin every clause. Same standing as A35-2: fix it in this PR,
  because leaving it would be a deferral with no trigger.
```

### Observations (non-blocking)

- **O36-1:** the writer's statement that the merge left the PR's change unchanged is exact. The patch is identical apart from hunk positions, including the context lines.
- **O36-2:** the `F_` survivors (§4). No action recommended.
- **O36-3:** the unreachable kind guard (§4). No action recommended.
- **O36-4, carried from audits 34 and 35:** the runner's exact LibreSSL stderr is still not recorded, because the tests pass there (O34-1).
- **O36-5:** the macOS job's log has 144 `--- FAIL` lines, from 10:57:09Z to 11:10:26Z. All of them are in the step "Listed tests still fail", which started at 10:56:32Z. That step is required to show the 26 entries failing. The step "Test" itself passed.

No finding rejected. No disagreement to preserve (single auditor). I did not re-judge findings of audits 34 or 35 beyond this delta. Audit 34's product verdict, "the collector change is correct", binds the same collector bytes.

## 6. CI on the head (Read; logs fetched with `get_job_logs`)

Both runs have `head_sha` `4cacbff…`. Both checked out `73bd18d20bc06025f166205fccdc48f08bd643e2`, "Merge 4cacbff… into 7e27168…", with parents `7e27168`, `4cacbff` and tree `7ccf9996…`, which is the head's tree (Ran: `git fetch refs/pull/62/merge`). So CI tested the audited bytes. My copies of both logs equal the writer's `33-evidence/*run4559609*` files byte for byte.

- **"test on macOS", run 45596092894, job 139142614519, 10:33:45Z to 11:10:33Z, success.**
  - Image macos-26-arm64, go1.26.5 darwin/arm64.
  - Self-check: "Ran 145 tests", OK.
  - `ok execution-substrate/scripts` in 523.9 s ("Test") and 501.2 s (observed run).
  - "test gate passed: 2 packages, 1 of them with skipped entries (26 entries); 81 tests skipped themselves, all of them listed".
  - "all 26 listed tests still fail on this host, each in a run of its own and in the run of its package".
  - So the new test and `…OpenSSLGrammar` ran unlisted on macOS and passed.
- **"build, vet and test", run 45596092762, job 139142571789, 10:33:40Z to 11:19:47Z, success.**
  - Image ubuntu-24.04, go1.26.5 linux/amd64.
  - Self-check: "Ran 145 tests", OK.
  - Root package `ok execution-substrate 4.574s`.
  - "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed".
  - "all 17 listed tests still fail on this host"; "tests as root passed: 9 of execution-substrate/scripts".

Extracts: `macos-job-extract.txt`, `linux-job-extract.txt`. The PR's two other comments are Codex's: a failed review of `72eecb2`, and the note that it is out of credits.

## 7. Red-team

The coordinator recorded no separate red-team for #62 (report 33 §7). This delta changes no product byte, so nothing in it changes that basis.

## 8. Sensitive-material handling

No secrets, keys or certificates were read or written. All mutant inputs are synthetic. The CI extracts hold only gate summary lines and checkout lines.

## 9. Confidence

- **Provenance: 1.0.** The manifest reproduced byte for byte, the opening run equals the closing one, the PR head equals the audited commit, and CI ran on the head's tree.
- **Validation: 0.95.** I re-ran the tests and mutants on the exact bytes. The macOS result rests on the runner's log, which I read. I did not run the whole `scripts` package locally.
- **Implementation: 0.95.** The collector is unchanged and was judged correct in audit 34. The remaining doubt is the four unpinned rules (A36-1), not the code.

## 10. Effect status and next step

No repair, commit, push, PR edit, comment, merge or box contact.

Next steps:

1. The writer adds the four cases of A36-1, test only, with the collector unchanged, and fixes the count in the PR body.
2. The writer takes a new manifest and runs `run-mutants.sh`. All four `C_` mutants should then be killed, and the other results should stay as in §3.2.
3. "test on macOS" and "build, vet and test" go green on the new head.

A diff check of that change is then mechanical. §3.3 maps every stated clause, so no further clause is left to find.

## 11. Evidence

`36-pr62-delta-check-evidence/`, with `SHA256SUMS.txt`:

- `manifest-4cacbff-vs-7e27168-opening.json` and `…-closing.json`: my v2 manifests, `f95103b1…b56c0`;
- `mutants-36.py`: my 17 mutants, each with a witness input;
- `witness-36.py`: shows the disagreement for each of them;
- `run-mutants.sh` and `mutants-out.txt`: the runner (audit 35's 14, the writer's 2 and my 17) and its results at `4cacbff`;
- `base-survivors-out.txt`: the four `C_` mutants on base `7e27168`;
- `proposed-cases.diff` and `proposed-cases-check.txt`: the four cases of A36-1 and their check;
- `checklist.py`: the call of the gate's `check_list`;
- `macos-job-extract.txt` and `linux-job-extract.txt`: the CI summary lines.

```
Final verdict: BLOCK
```
