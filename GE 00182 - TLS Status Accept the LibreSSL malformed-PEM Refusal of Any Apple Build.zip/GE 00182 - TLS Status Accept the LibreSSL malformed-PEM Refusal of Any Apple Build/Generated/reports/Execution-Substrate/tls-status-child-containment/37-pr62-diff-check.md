# 37. Diff check of ES PR #62, 4cacbff to a34e339: the four test cases of A36-1

```
INDEPENDENT AUDIT REPORT
Repository:      evo-agi/Execution-Substrate, PR #62 "TLS status: accept the LibreSSL malformed-PEM refusal of any Apple build"
Audit target:    base trunk_dev 7e271681b63e33891f287ca0f745d45cebeee4f5 (#60)
                 topic claude/project-thread-wbmulu, commit a34e339da1576408343e188b4d5e7a5e78b56e14,
                 tree 695643a3e65b058a29430fc2a5a6b1e7ef2c68e5
                 delta under review: 4cacbff (diff check 36, BLOCK on A36-1) to a34e339 (one commit, parent 4cacbff)
Recipe:          governed-execution.audit-patch-manifest.v2, source SHA-256
                 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified before each run)
Manifest:        8913a07140b87d5c640f0e1d166fc3df55fe697c2bdbffc6434397057cf6f3fb, 5 changed paths,
                 textual_diff_sha256 c6186aaccc71439c7af9ebfca1f39cce3d8f654d88d61194a768dbeb4bc4121e
Writer report:   33-libressl-grammar-pr62.md §10, SHA-256 9010513d2ddc3bf74c392a7be51e5afedaa1a0c43fe2a2b1676bce1b995a7364
Prior audit:     36-pr62-delta-check.md, SHA-256 36cde3b52fd40702242c7a91b5384e82d68722caa9c82cecdf0bfbfd29a9b5a2
Audit posture:   read-only. No subagents. Nothing pushed, no PR edit, no GitHub comment, box not touched.
                 I had not audited PR #62 before (protocol §14).
Verdict:         ACCEPT (A36-1 is closed; no new finding; two non-blocking observations, O37-1 and O37-2)
```

All times are UTC on 2026-11-25. The check ran from 12:55Z to about 13:20Z in a fresh cloud container.

## 1. Verdict in short

Every claim in the writer's §10 holds on the exact bytes, and A36-1 is closed:

- **The manifest reproduces** byte for byte: the writer's `8913a071…f3fb`, twice at opening (12:56:55Z) and twice at closing (13:14:36Z) (Ran).
- **Only the status test changed.** `git diff 4cacbff a34e339` touches only `scripts/remote_alpha_es_service_tls_status_test.go`, +5/−1, and equals the writer's `repair-4cacbff-to-a34e339.diff` byte for byte (sha256 `9413c2f4…9941`). The other four manifest records equal audit 36's records for `4cacbff`. The collector is still `326c8d12…4f94057` (Ran).
- **The four cases are exactly audit 36's proposal** (`proposed-cases.diff`), and the count went from 42 to 46. The test now has 46 cases, 7 accepted and 39 refused, no repeated label, and all 46 checks are true on the audited collector (Ran).
- **Each new case changes one part, and only that part,** of the accepted pinned refusal of its kind (§3.1) (Ran).
- **All four `C_` mutants of A36-1 are killed**, each by the case written for it. All 33 mutants of audits 35 and 36 and the writer give exactly the writer's kill sets: 26 killed, the same 7 survivors (Ran).
- **Eight of my own 14 mutants are killed** (§3.2) (Ran), most of them other ways to loosen the four rules of A36-1. Of the six survivors, two loosen pkey-only forms that the recorded standard does not require a case for, and four are O37-1.
- **The audit 34 test set passes** (8 of 8), the root package passes, `go vet` is clean and `gofmt` lists nothing (Ran).
- **Both workflows are green on the head's tree** (Read). Both checked out merge commit `f3f66d5`, whose tree is `695643a3`, the head's tree. I fetched both job logs myself, and they equal the writer's copies apart from one final newline (§5).
- **The PR body** has the new counts (46; 7 accepted, 39 refused) and the new mutant totals (33; 26 killed, 7 survivors), and they match what I ran (Read).

Failing tests: none. No test of the audit 34 set, of the root package or of either workflow's gate fails on this head. The only `--- FAIL` lines in the CI logs are in the step "Listed tests still fail", which must show the listed tests failing (§5).

Two observations, neither a finding under the standard recorded for this PR (one refused case per stated clause; one exact literal is one clause; audit 36 O36-2):

- **O37-1:** a third stderr line *before* the first line, or *between* the two lines, is not refused by any case. Four mutants that allow it survive. Audit 36's clause map says `extra_line` pins "nothing before or after" (its §3.3, row 13), but `extra_line` only appends a line after. The stated rule "exactly two stderr lines" already has its isolating case (`extra_line`), so under the recorded standard this is another position of a pinned clause, not a gap. I give two verified cases in case the coordinator reads it the stricter way (§4).
- **O37-2:** two wording slips in the PR body, which a body edit fixes with no byte change (§4).

## 2. Provenance reproduction

Ran, in a fresh clone under `umask 022`:

- **Recipe:** `sha256sum -c` of the shared-folder file against the pin: OK. I copied it to `/opt/audit/v2.py` and checked that copy against the pin before each run.
- **Fetch:** `git fetch origin trunk_dev claude/project-thread-wbmulu` gives the topic tip `a34e339…` and trunk_dev `7e27168…`. The base is an ancestor of the tip. The head's tree is `695643a3…`.
- **Sequence:** provenance §5.3: checkout of the tip, clean status, `git reset --mixed 7e27168`, upstream set to `origin/trunk_dev`, v2 twice into a fresh 0700 directory. The two outputs are byte-identical, and `cmp`-identical to the writer's `33-evidence/manifest-a34e339-vs-7e27168.json`. 5 files, all `tracked_modified` with mode 0644, so there is no mode-bit difference.
- **Closing run:** two runs, identical to the opening ones. `git ls-remote` at 13:14Z: the branch and `refs/pull/62/head` are still `a34e339`, trunk_dev still `7e27168`.
- **GitHub (API, about 13:00Z):** PR #62 has head `a34e339…`, base `7e27168…`, `mergeable_state: clean`, 5 commits, not a draft. No reviews. The only two comments are Codex's (a failed review of `72eecb2`, and the note that it is out of credits).
- **Against audit 36's manifest** of `4cacbff` against the same base (per-file records compared by script): the doc, the macOS list, the collector and `…openssl3013_test.go` are byte-identical. Only the status test differs.
- **The commit:** `a34e339` has one parent, `4cacbff`, the commit audit 36 checked. So the branch only gained a commit (no force push). Its message describes the repair of the writer's §10.

## 3. Coverage

### 3.1 The delta (Read and Ran)

The diff adds four tuples after `other_first_line` (lines 1042-1045 at `a34e339`) and changes `len(results) != 42` to `!= 46` (line 1087). The added lines are identical to audit 36's `proposed-cases.diff`.

I extracted the probe's case table from the test file and ran it against the audited collector (`cases-37.py`, `cases-37-out.txt`). For each new case, the part of its stderr that differs from the accepted pinned refusal of the same kind (`refusal(kind)`) is:

| Case | Kind | Pinned part | Case part | Rule it pins alone (audit 36 §3.3) |
|---|---|---|---|---|
| `missing_first_line` | certificate | `unable to load certificate\n` | nothing (one stderr line) | 3b, exactly two lines: no fewer |
| `certificate_first_line_for_a_key` | key | `key` (of `unable to load key`) | `certificate` | 5, the pkey first line |
| `key_object_for_a_certificate` | certificate | `TRUSTED CERTIFICATE` | `ANY PRIVATE KEY` | 10b, the x509 object is not the key's |
| `certificate_object_for_a_key` | key | `ANY PRIVATE KEY` | `TRUSTED CERTIFICATE` | 11, the pkey object |

Exit code 1 and empty stdout stay as in the accepted cases. The collector refuses all four.

At `4cacbff` the same script gives 42 cases, 7 accepted and 35 refused, all true. So the delta is exactly these four refused cases.

### 3.2 Mutants (Ran; `run-mutants-37.sh`, `mutants-37-out.txt`)

**Setup.**

- I built one test binary as user `ci` (uid 1500, gid 1600, `env -i`, `umask 022`, Go 1.26.5) from a ci-owned clone at `a34e339`.
- For each mutant, the runner rewrote the collector in that clone and ran the audit 34 test set: `…LibreSSLMalformedPEMLocation`, `…OpenSSLGrammar`, `…CollectionTypedFailures`, `…Target3013.*` and `…X509TextSignatureTails`.
- The unmutated run passes all 8 tests.
- For every mutant, a witness input shows that it and the audited collector disagree, so none is equivalent.
- At the end the collector was restored, `cmp`-checked, sha256 `326c8d12…`.
- The mutant scripts of audits 35 and 36 were copied from their evidence folders, with the hashes in those folders' `SHA256SUMS.txt` checked (OK). The writer's two `W_` mutants come from `33-evidence/mut35-extra.py.txt`.

**The 33 mutants of audits 35 and 36 and the writer.** With timings removed, my kill sets equal the writer's `33-evidence/mutants-a36-after-repair.txt` line for line. The four of A36-1:

| Mutant | 4cacbff (audit 36) | a34e339 (this check) |
|---|---|---|
| `C_first_line_optional` | survived | killed: `missing_first_line` |
| `C_key_first_line_either` | survived | killed: `certificate_first_line_for_a_key` |
| `C_object_either_kind` | survived | killed: `key_object_for_a_certificate`, `certificate_object_for_a_key` |
| `C_key_object_any` | survived | killed: `certificate_object_for_a_key` |

The other 22 killed mutants are killed by the same cases as in audit 36 §3.2 (`C_first_line_any_text` now also by `certificate_first_line_for_a_key`). The 7 survivors are those audit 36 judged not findings: `M_empty_components` (O35-1), `E_kind_guard_dropped` (O36-3) and the five `F_` (O36-2). Each of the 26 killed mutants fails `…LibreSSLMalformedPEMLocation`. So the PR body's "26 are killed by the new test" holds.

**14 mutants of my own** (`mutants-37.py`, witnesses in `witness-37.py`). Group N tries other ways to loosen the four rules of A36-1, so the new cases are judged against the rule and not only against audit 36's mutant of it. Group P tries the anchors of the whole match.

| Mutant | What it loosens | Result |
|---|---|---|
| `N_first_line_repeatable`: `(?:first)*` | 3b, no fewer lines | killed: `missing_first_line` |
| `N_key_first_line_any_word`: `unable to load [a-z]+` for pkey | 5 | killed: `certificate_first_line_for_a_key` |
| `N_first_line_of_either_kind`: either first line for both kinds | 4 and 5 | killed: `other_first_line`, `certificate_first_line_for_a_key` |
| `N_cert_object_either`: either object for x509 only | 10b | killed: `key_object_for_a_certificate` |
| `N_key_object_either`: either object for pkey only | 11 | killed: `certificate_object_for_a_key` |
| `N_cert_object_trusted_optional`: `(?:TRUSTED )?CERTIFICATE` | 10a | killed: `other_expected_object` |
| `N_kind_ignored`: either whole refusal for either kind | 4, 5, 10, 11 together | killed: `key_refusal_for_a_certificate`, `certificate_refusal_for_a_key` |
| `P_trailing_line_allowed`: an optional line after the second | 3a, after | killed: `extra_line` |
| `N_first_line_optional_for_key`: the first line optional for pkey only | 3b, for one kind | survived (O37-1 below; 3b is stated once for both kinds, and `missing_first_line` pins it) |
| `N_key_object_any_optional`: `(?:ANY )?PRIVATE KEY` | inside the literal `ANY PRIVATE KEY` | survived (O36-2 class: one literal, already pinned by `certificate_object_for_a_key`) |
| `P_leading_line_allowed`: an optional line before the first | 3a, before | **survived** (O37-1) |
| `P_any_prefix`: `fullmatch(rb"(?s:.*)" + pattern)` | the start anchor | **survived** (O37-1) |
| `P_search_end_anchored`: `re.search(pattern + rb"\Z")` | the start anchor | **survived** (O37-1) |
| `P_line_between_allowed`: an optional line between the two | 3a, between | **survived** (O37-1) |

So the four new cases pin their rules against every other form of loosening I tried, apart from a pkey-only form of 3b and a loosening inside the pkey object's literal. Both are inside the recorded standard. I give the two pkey forms here only so the coordinator sees them; I recommend no case for them.

Only two test files hold the LibreSSL text, and only the status test feeds refused LibreSSL forms (audit 36 §3.2, which I did not re-derive). So I did not run the whole `scripts` package for each mutant.

### 3.3 Other checks (Ran)

All as user `ci` under `env -i`, `umask 022`, with Go 1.26.5, Python 3.13.18 and OpenSSL 3.0.13, in a git clone at `a34e339`:

- the audit 34 test set: 8 of 8 pass (`ok execution-substrate/scripts 11.781s`);
- root package `go test -count=1 .`: `ok execution-substrate 3.539s`;
- `go vet ./scripts/ .`: clean;
- `gofmt -l scripts/ *.go`: nothing;
- neither environment-only list names `…LibreSSLMalformedPEMLocation`, `…OpenSSLGrammar` or `…CollectionTypedFailures`;
- the macOS list is byte-identical to the one audit 36 checked with the gate's own `check_list` (26 entries, 81 skips), so I did not re-run `check_list`.

Not re-run locally: the whole `scripts` package. Both workflows ran it on the head's tree (§5). Locally, the delta is four tuples and a count in one test.

## 4. Observations (non-blocking)

### O37-1: no case puts a line before the first line, or between the two

- **Evidence:** `P_leading_line_allowed`, `P_any_prefix`, `P_search_end_anchored` and `P_line_between_allowed` pass the whole audit 34 test set at `a34e339`. Each admits an input the audited collector refuses: `warning\n` plus a valid refusal, or a valid refusal with `warning\n` between its two lines.
- **Audit 36's map:** its §3.3 row 13 reads "the whole stderr matches, nothing before or after | `extra_line` (kills `re.match` and `re.search`)". That is true for "after" only. `re.search` is killed because it also admits a trailing line; a search anchored at the end survives.
- **Why it is not a finding here:** the doc states "exactly two stderr lines" (`remote_supported_host_alpha.md:4005`), not where an extra line may sit. `extra_line` breaks that rule on its own, so under the standard recorded for this PR (one refused case per stated clause), the rule is pinned and these survivors are other positions of it. That is the same reasoning audits 35 and 36 used for `pem_lib.c` and for the `F_` survivors.
- **Impact:** a match yields only `certificate_malformed` or `key_malformed`, never a pass (audit 34 §5, PR body). A loosening of this kind could misclassify a failed `openssl` run as malformed material, not admit material.
- **The stricter reading:** audit 36 split "exactly two lines" into "no more" and "no fewer" and required a case for each. Reading "nothing before or after" the same way, the start anchor and the middle position would each need a case. That is a choice about the review standard, which is the coordinator's to make, not a defect in the bytes. If the coordinator takes that reading, two cases close it. I checked them against the audited collector and the survivors (`o37-1-cases.py`, `o37-1-cases-out.txt`):

  ```
  ("leading_line",False,"certificate",1,b"",b"warning\n"+refusal("certificate")),
  ("line_between_the_two",False,"certificate",1,b"",refusal("certificate",line=b"unable to load certificate\nwarning\n")),
  ```

  With them, all 48 checks are true on the audited collector. `leading_line` kills the three start-anchor mutants and `line_between_the_two` kills `P_line_between_allowed`. The count would go from 46 to 48.
- **My recommendation:** no change in this PR. The rule has its isolating case, the impact is bounded to a failure classification, and taking the stricter reading here would reopen the review for a fifth round on a test-only point.
- **Patch defect or pre-existing:** pre-existing. The matcher's first line and its `re.fullmatch` call are unchanged from base `7e27168` (Ran: `git diff 7e27168 a34e339` of the collector changes only the location constant and its use). Inference: the four survivors also pass every test on base `7e27168`, because no base test feeds a refused LibreSSL form (audit 36 §3.2). I did not run them on base.

### O37-2: two wording slips in the PR body

- Under "39 refused", the group "the first line:" lists "a hexadecimal or missing thread identifier; another word for `error`". Both are parts of the second line, not the first.
- Under "Validation", the PR body says "The 7 survivors loosen no stated rule", then "Five loosen a part inside an exact literal that already has a refused case". The second sentence is the accurate one (O36-2): the five `F_` survivors loosen a stated literal that already has a refused case.

The PR body is not part of the audited bytes, so a body edit needs no re-audit. I recommend the writer fix both before the merge gate.

### Carried

- **O36-4 (from audits 34 and 35):** the runner's exact LibreSSL stderr is still not recorded, because the tests pass there.

No finding rejected. No disagreement with the writer. One disagreement with audit 36, factual and narrow: its row 13 overstates what `extra_line` pins (O37-1). I did not re-judge audit 34's product verdict ("the collector change is correct"). It binds the same collector bytes.

## 5. CI on the head (Read; logs fetched with `get_job_logs`)

Both runs have `head_sha` `a34e339…`, event `pull_request`, attempt 1. Both checked out `refs/remotes/pull/62/merge`, "HEAD is now at f3f66d5 Merge a34e339… into 7e27168…". I fetched `refs/pull/62/merge` myself: `f3f66d5aaa544b4af762e1ca41abbf5c46b6ecce`, parents `7e27168` and `a34e339`, tree `695643a3`, the head's tree. `git merge-tree --write-tree 7e27168 a34e339` gives the same tree. So CI tested the audited bytes.

My copies of both logs equal the writer's `33-evidence/*run4561007*` files byte for byte, plus one final newline, which the writer's copies leave out.

- **"test on macOS" (workflow go-macos), run 45610077110, job 139191003378, 12:03:13Z to 12:41:27Z, success.**
  - Image macos-26-arm64, version 20261117.0516.1, go1.26.5 darwin/arm64.
  - Self-check: "Ran 145 tests", OK.
  - `ok execution-substrate/scripts` in 528.164 s and 549.659 s.
  - "test gate passed: 2 packages, 1 of them with skipped entries (26 entries); 81 tests skipped themselves, all of them listed".
  - "all 26 listed tests still fail on this host, each in a run of its own and in the run of its package".
  - The log has 144 `--- FAIL` lines. The first is at line 541, after the step "Listed tests still fail" started (line 522). That step must show the 26 entries failing. The step "Test" itself passed.
- **"build, vet and test" (workflow go), run 45610076995, job 139191002438, 12:03:12Z to 12:52:28Z, success.**
  - Image ubuntu-24.04, version 20261116.376.1, go1.26.5 linux/amd64.
  - Self-check: "Ran 145 tests", OK.
  - `ok execution-substrate/scripts 379.665s`; root package `ok execution-substrate 4.123s`.
  - "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed".
  - "all 17 listed tests still fail on this host"; "tests as root passed: 9 of execution-substrate/scripts".
  - The log has 98 `--- FAIL` lines. The first is at line 802, after the step "Listed tests still fail" started (line 779).

Extract: `ci-extract.txt`.

## 6. Red-team

The coordinator recorded no separate red-team for #62 (report 33 §7). This delta changes no product byte, so nothing in it changes that basis.

## 7. Sensitive-material handling

No secrets, keys or certificates were read or written. All mutant and case inputs are synthetic. The CI extract holds only checkout lines, image and toolchain versions, and gate summary lines.

## 8. Confidence

- **Provenance: 1.0.** The manifest reproduced byte for byte, the opening run equals the closing one, the PR head equals the audited commit, and CI ran on the head's tree.
- **Validation: 0.95.** I re-ran the test set, the root package and 47 mutants on the exact bytes. The macOS result rests on the runner's log, which I read. I did not run the whole `scripts` package locally.
- **Implementation: 0.95.** The collector is unchanged and was judged correct in audit 34. The test now pins every stated clause under the recorded standard. The remaining doubt is the review-standard question in O37-1, not the code.

## 9. Effect status and next step

No repair, commit, push, PR edit, comment, merge or box contact.

Next steps:

1. The writer edits the PR body for O37-2. No byte change, so no re-audit.
2. The coordinator decides O37-1. My recommendation is no change. If the coordinator takes the stricter reading instead, the writer adds the two cases in §4 (46 to 48), and a diff check of that is mechanical.
3. Merge gate: the PR head must still be `a34e339`, and trunk_dev must still be `7e27168` or be handled per provenance §5.4.

## 10. Evidence

`37-pr62-diff-check-evidence/`, with `SHA256SUMS.txt`:

- `manifest-a34e339-vs-7e27168-opening.json` and `…-closing.json`: my v2 manifests, `8913a071…f3fb`;
- `cases-37.py` and `cases-37-out.txt`: the case table, its counts on `a34e339` and `4cacbff`, and the part each new case changes;
- `mutants-37.py` and `witness-37.py`: my 14 mutants, each with a witness input;
- `run-mutants-37.sh`, `asci.sh` and `mutants-37-out.txt`: the runner (audit 35's 14, the writer's 2, audit 36's 17 and my 14) and its results at `a34e339`;
- `o37-1-cases.py` and `o37-1-cases-out.txt`: the two cases of O37-1 and their check;
- `ci-extract.txt`: the CI checkout and summary lines.

```
Final verdict: ACCEPT
```
