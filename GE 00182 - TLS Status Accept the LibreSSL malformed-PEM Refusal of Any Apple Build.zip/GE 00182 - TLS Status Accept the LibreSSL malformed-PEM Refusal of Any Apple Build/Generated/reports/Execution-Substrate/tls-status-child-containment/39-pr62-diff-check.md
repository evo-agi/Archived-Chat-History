# 39. Final diff check of ES PR #62, d31043d to 7e892d6: the two "fewer" cases of O38-1

```
INDEPENDENT AUDIT REPORT
Repository:      evo-agi/Execution-Substrate, PR #62 "TLS status: accept the LibreSSL malformed-PEM refusal of any Apple build"
Audit target:    base trunk_dev 7e271681b63e33891f287ca0f745d45cebeee4f5 (#60)
                 topic claude/project-thread-wbmulu, commit 7e892d6cd5cc939fa2d9b1c4112b2665b4eed99f,
                 tree f5abc1b796921ba06971ec7d06d84da75c94ed9f
                 delta under review: d31043d (diff check 38, ACCEPT) to 7e892d6 (one commit, parent d31043d)
Recipe:          governed-execution.audit-patch-manifest.v2, source SHA-256
                 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified before each run)
Manifest:        5c72d8cb017fce211c9b07fc9a6441133cde5dfd450f429d39bac7acfcb908b0, 5 changed paths,
                 textual_diff_sha256 667e3034f4dbe4ec200ca5cce8d48374cee1d8d799d4ff2d9c9e256d0355c68a
Writer report:   33-libressl-grammar-pr62.md §12, SHA-256 0386effb073d2c320fcaeb92442e1f7e6bf4a7ddd8b8d667ab81099c7d3b4362
Prior audit:     38-pr62-diff-check.md (ACCEPT at d31043d; O38-1 recommended these two cases)
Audit posture:   read-only, mechanical scope as briefed. No subagents. Nothing pushed, no PR edit, no GitHub comment,
                 box not touched. I had not audited PR #62 before (protocol §14).
Verdict:         ACCEPT
```

All times are UTC on 2026-11-25. The check ran from 15:32Z to 15:52Z in a fresh cloud container.

## 1. Verdict in short

Every claim the writer makes in report 33 §12 and the coordinator's brief holds on the exact bytes. No finding, no new observation.

- **Provenance reproduces** (Ran): my v2 manifest of `7e892d6` against `7e27168` is `5c72d8cb…08b0`, twice at opening and twice at closing, `cmp`-identical to the writer's `33-evidence/manifest-7e892d6-vs-7e27168.json`. 5 files, all `tracked_modified`, mode 0644.
- **Status test only, +3/−1** (Ran): `git diff d31043d 7e892d6` touches only `scripts/remote_alpha_es_service_tls_status_test.go`, and equals the writer's `repair-d31043d-to-7e892d6.diff` byte for byte (sha256 `e380c4ef…6e9e`). The other four manifest records equal audit 38's records for `d31043d`.
- **Exactly those two cases, 48 to 50** (Ran): the added tuples are `missing_second_line` and `no_stderr`, identical to audit 38's `o38-1-cases.py` apart from indentation and the trailing comma. The table has 50 cases, 7 accepted and 43 refused, no repeated label, no case removed or reordered, and all 50 checks are true on the audited collector. At `d31043d` the same script gives 48 (7/41). The count check moved from `!= 48` to `!= 50`.
- **Collector unchanged** (Ran): `scripts/internal/remote_alpha_es_tls_status.py` is `326c8d12…4f94057` at `7e892d6`, as at `d31043d` and `72eecb2`.
- **Targeted mutants killed** (Ran): `Q_first_line_alone` and `Q_second_line_optional` are killed by `missing_second_line`; `Q_empty_stderr` by `no_stderr`. All 61 mutants give exactly the writer's kill sets (46 killed, 15 survivors), and against audit 38's run at `d31043d` only those three changed.
- **CI green on the head's tree** (Read; logs fetched myself): both workflows have `head_sha` `7e892d6`, both checked out merge commit `cf94bcd`, whose tree is `f5abc1b7`, the head's tree.
- **PR body** (Read): the CI line now names `7e892d6`'s two green runs and `cf94bcd`; the counts (50; 7 accepted, 43 refused), the mutant totals (61; 46 killed, 15 survivors, with the right breakdown) and the manifest hash are correct.

**Failing tests: none on this head.** The audit 34 test set passes (8 of 8), the root package passes, and both workflows' gates pass. The only `--- FAIL` lines in the CI logs come after the step "Listed tests still fail" started, which must show the listed tests failing (§4).

## 2. Provenance reproduction (Ran)

- **Recipe:** the shared-folder file checks against the pin (`sha256sum -c`: OK). I copied it to `/opt/audit/v2.py` and checked the copy against the pin before the opening and the closing run.
- **Fresh clone** under `umask 022`; `git fetch origin trunk_dev claude/project-thread-wbmulu` gives tip `7e892d6…` and trunk_dev `7e27168…`. The base and `d31043d` are both ancestors of the tip. `7e892d6` has one parent, `d31043d`, the commit audit 38 accepted, so the branch only gained a commit (no force push).
- **Sequence:** provenance §5.3 exactly: checkout of the tip under its branch name, clean status, `git reset --mixed 7e27168`, upstream set to `origin/trunk_dev`, v2 twice into a fresh 0700 directory. The two outputs are byte-identical and equal the writer's file.
- **Closing (15:49Z):** two more runs, identical to the opening ones. `git ls-remote` at 15:49Z: the branch and `refs/pull/62/head` are `7e892d6`, trunk_dev is `7e27168`.
- **Against audit 38's manifest** of `d31043d` (per-file records compared by script): the doc, the macOS list, the collector and `…openssl3013_test.go` are byte-identical. Only the status test differs (`596ebca3…` to `7abb4acc…`).
- **GitHub (API, about 15:37Z):** PR #62 head `7e892d6`, base `7e27168`, 7 commits, not a draft, `mergeable_state: clean`, 2 comments (Codex's, both older). Commit message: "TLS status: refuse a LibreSSL refusal with only its first line, or no stderr", describing a test-only change from 48 to 50 cases.

## 3. Coverage (Ran)

### 3.1 The delta

Two tuples added after `missing_first_line` (lines 1043-1044 at `7e892d6`) and the count changed at line 1091:

```
("missing_second_line",False,"certificate",1,b"",b"unable to load certificate\n"),
("no_stderr",False,"certificate",1,b"",b""),
```

Running audit 38's `cases-38.py` (unchanged; hashes in its evidence folder checked OK) against the test file and collector at `7e892d6` (`cases-out.txt`): `missing_second_line` is the accepted pinned certificate refusal with the whole second line removed (1 stderr line), `no_stderr` has both lines removed (0 lines). Both keep exit code 1 and empty stdout, and the collector refuses both.

### 3.2 Mutants (`run-mutants-39.sh`, `mutants-39-out.txt`, `compare-39-out.txt`)

Same setup as audit 38: one test binary built as user `ci` (uid 1500, gid 1600, `env -i`, `umask 022`, Go 1.26.5) from a ci-owned clone at `7e892d6` (tree `f5abc1b7`, clean before and after). The runner is audit 38's `run-mutants-38.sh` with only its header comment changed; it rewrites the collector per mutant and runs the audit 34 test set (`…LibreSSLMalformedPEMLocation`, `…OpenSSLGrammar`, `…CollectionTypedFailures`, `…Target3013.*`, `…X509TextSignatureTails`). The mutant scripts of audits 35, 36, 37 and 38 come from their evidence folders (each folder's `SHA256SUMS.txt` checked OK) and the writer's two from `33-evidence/mut35-extra.py.txt` (sha256 `45efb79e…c101`). The unmutated run passes 8 of 8. At the end the collector was restored and `cmp`-checked, sha256 `326c8d12…`.

- **Against the writer's run at `7e892d6`** (`33-evidence/mutants-a38-after-repair.txt`): with timings removed, every one of the 61 kill sets is equal ("differing: none"). 46 killed, 15 survive.
- **Against audit 38's run at `d31043d`:** only `Q_first_line_alone`, `Q_second_line_optional` and `Q_empty_stderr` differ, each now killed by the case named above and by nothing else. Every other mutant has the same kill set as at `d31043d`.
- **All 46 kills include `…LibreSSLMalformedPEMLocation`**, so the PR body's "46 are killed by the new test" is exact.
- **The 15 survivors** are the ones audit 38 and earlier audits already judged as needing no case: `M_empty_components` (O35-1, `//`), `E_kind_guard_dropped` (O36-3), the five `F_` (O36-2), `N_first_line_optional_for_key` and `N_key_object_any_optional` (report 37 §3.2), and six `Q_` (report 38 §4: `Q_blank_line_before`, `Q_blank_line_between`, `Q_first_line_repeated`, `Q_leading_line_for_key_only`, `Q_line_between_for_key_only`, `Q_two_lines_either_order`).
- **Witnesses:** each of the 59 mutants with a witness disagrees with the audited collector on it (58 admit what the collector refuses; `M_old_pinned_path` refuses what it admits). The two `W_` mutants have no witness script, as in audit 38.

With these two cases, "exactly two stderr lines" has a refused case at every position audit 38 listed: a line before, between and after, the first line missing, the second line missing, and no lines. O38-1 is closed, and O38-2's gap (exit 1 with no output at the malformed-PEM call sites) is pinned by `no_stderr`, so it needs no tracked item.

### 3.3 Other checks

As `ci` under `env -i`, Go 1.26.5, Python 3.13.18, OpenSSL 3.0.13, in the clone at `7e892d6` (`other-checks-out.txt`, `unmutated-test-set-out.txt`):

- the audit 34 test set: 8 of 8 pass;
- root package `go test -count=1 .`: `ok execution-substrate 3.381s`;
- `go vet ./scripts/ .`: clean; `gofmt -l scripts/ *.go`: nothing;
- `git status` clean before and after.

**Not run here:** the whole `scripts` package (CI ran it green on both platforms, §4; in a container 29 tests fail for environment reasons, audit 38 §3.3), and the macOS list check (the list's bytes are unchanged since audits 36 to 38 checked it).

## 4. CI on the head (Read; logs fetched with `get_job_logs`)

Both runs: event `pull_request`, attempt 1, `head_sha` `7e892d6…`, conclusion success, "HEAD is now at cf94bcd Merge 7e892d6… into 7e27168…". I fetched `refs/pull/62/merge` myself: `cf94bcde…`, parents `7e27168` and `7e892d6`, tree `f5abc1b7`; `git merge-tree --write-tree 7e27168 7e892d6` gives the same tree. So CI tested the audited bytes. My decoded logs equal the writer's `33-evidence` copies byte for byte apart from one final newline I added.

- **"test on macOS" (go-macos), run 45635004681, job 139277968680, 14:31:35Z to 14:56:09Z, success.** macos-26-arm64, image 20261117.0516.1, go1.26.5 darwin/arm64. Self-check "Ran 145 tests", OK. `ok execution-substrate/scripts` in 317.574 s and 305.747 s. "test gate passed: 2 packages, 1 of them with skipped entries (26 entries); 81 tests skipped themselves, all of them listed". "all 26 listed tests still fail on this host, each in a run of its own and in the run of its package". 144 `--- FAIL` lines; the first is at line 541, after the step "Listed tests still fail" started (line 522).
- **"build, vet and test" (go), run 45635004670, job 139277970935, 14:31:36Z to 15:30:35Z, success.** ubuntu-24.04, image 20261116.376.1, go1.26.5 linux/amd64. Self-check "Ran 145 tests", OK. `ok execution-substrate/scripts 446.076s`; root package `ok execution-substrate 6.094s`. "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed". "all 17 listed tests still fail on this host". "tests as root passed: 9 of execution-substrate/scripts". 98 `--- FAIL` lines; the first is at line 802, after the step "Listed tests still fail" started (line 779).
- The Linux run took 59 minutes against 45 to 49 for earlier heads, as the writer noted; it stayed within the job's limit. Inference (the writer's, which I share): a slower runner, since the delta is two rows of one test's table.

Extract: `ci-extract.txt`.

## 5. Findings

None. No observation opened; the brief limited this check to mechanical verification, and I found no defect. No finding rejected, no disagreement with the writer or with audit 38.

Carried, unchanged: O36-4 (the runner's exact LibreSSL stderr is still not recorded, because the tests pass there).

## 6. Red-team

The coordinator recorded no separate red-team for #62 (report 33 §7 and §11). This delta changes no product byte; the collector has the bytes audit 34 judged.

## 7. Sensitive-material handling

No secrets, keys or certificates were read or written. All case and mutant inputs are synthetic. The CI logs are public runner logs of this repository. The container's proxy CA was copied to `/opt/audit` only so `ci` could download Go modules.

## 8. Confidence

- **Provenance: 1.0.** The manifest reproduced byte for byte, opening equals closing, the PR head equals the audited commit, and CI ran on the head's tree.
- **Validation: 0.95.** I re-ran the test set, the root package, vet, gofmt and all 61 mutants on the exact bytes. The whole-package and macOS results rest on the runner logs, which I fetched and read.
- **Implementation: 0.95.** Test-only delta, collector unchanged since audit 34.

## 9. Effect status and next steps

No repair, commit, push, PR edit, comment, merge or box contact. Audit-created files are only in `/opt/audit` and `/home/ci` of this container.

`7e892d6` is ready for the merge gate: the PR head must still equal `7e892d6`, trunk_dev must still be `7e27168` (it was at 15:49Z) or be handled per provenance §5.4, and both workflows are green on this head.

## 10. Evidence

`39-pr62-diff-check-evidence/`, with `SHA256SUMS.txt` and a `README.txt` naming the reused scripts:

- `manifest-7e892d6-vs-7e27168-opening.json`, `…-closing.json`: my v2 manifests, `5c72d8cb…08b0`;
- `delta-d31043d-to-7e892d6.diff`: the delta, equal to the writer's;
- `cases-out.txt`, `cases-d31043d-out.txt`: the case table at `7e892d6` (50) and `d31043d` (48);
- `run-mutants-39.sh`, `mutants-39-out.txt`, `compare-39-out.txt`: the 61 mutants and the comparison with the writer's and audit 38's runs;
- `unmutated-test-set-out.txt`, `other-checks-out.txt`: test set, root package, vet, gofmt;
- `ci-extract.txt`, `linux-run45635004670-job139277970935.log`, `macos-run45635004681-job139277968680.log`: CI.

```
Final verdict: ACCEPT
```
