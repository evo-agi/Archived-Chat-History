# 33. PR #62: the TLS status collector accepts the LibreSSL malformed-PEM refusal of any Apple build

```
Repository: evo-agi/Execution-Substrate, PR #62 "TLS status: accept the LibreSSL malformed-PEM refusal of any Apple build"
Head:       7e892d6cd5cc939fa2d9b1c4112b2665b4eed99f, tree f5abc1b796921ba06971ec7d06d84da75c94ed9f
            (72eecb2, audited in report 34; repair f2cc70f, section 7, checked in report 35; repair f56ed54, section 8;
            merge of trunk_dev 7e27168, section 9, checked with f56ed54 in report 36; repair a34e339, section 10,
            accepted in report 37; two cases d31043d, section 11, accepted in report 38; two cases 7e892d6, section 12)
Base:       trunk_dev 7e271681b63e33891f287ca0f745d45cebeee4f5 (#60), unchanged at 14:32Z. Before 10:32Z: 819f712 (#59).
Branch:     claude/project-thread-wbmulu, restarted from trunk_dev after #59 merged
Manifest:   v2 of 7e892d6 against 7e27168: 5c72d8cb017fce211c9b07fc9a6441133cde5dfd450f429d39bac7acfcb908b0,
            5 files, textual_diff_sha256 667e3034f4dbe4ec200ca5cce8d48374cee1d8d799d4ff2d9c9e256d0355c68a,
            taken twice, byte-identical (33-evidence/manifest-7e892d6-vs-7e27168.json).
            Superseded: d31043d against 7e27168, f8a43fad…5560 (33-evidence/manifest-d31043d-vs-7e27168.json);
            a34e339 against 7e27168, 8913a071…f3fb (33-evidence/manifest-a34e339-vs-7e27168.json);
            4cacbff against 7e27168, f95103b1…56c0 (33-evidence/manifest-4cacbff-vs-7e27168.json);
            f56ed54 against 819f712, c1bafff1…6ee7 (33-evidence/manifest-f56ed54-vs-819f712.json);
            f2cc70f against 819f712, 59bef427…ecbd7 (33-evidence/manifest-f2cc70f-vs-819f712.json);
            72eecb2 against 819f712, beeecf25…6629 (33-evidence/manifest-72eecb2-vs-819f712.json).
CI:         7e892d6: both green, both on merge commit cf94bcd (parents 7e27168, 7e892d6), whose tree is the head's
            tree f5abc1b7: "test on macOS" run 45635004681, "build, vet and test" run 45635004670 (section 12).
            d31043d: both green, both on merge commit 01a2ded (parents 7e27168, d31043d), whose tree is the head's
            tree 552211d5: "test on macOS" run 45623905093, "build, vet and test" run 45623905063 (section 11).
            a34e339: both green, both on merge commit f3f66d5 (parents 7e27168, a34e339), whose tree is the head's
            tree 695643a3: "test on macOS" run 45610077110, "build, vet and test" run 45610076995 (section 10).
            4cacbff: both green, both on merge commit 73bd18d (parents 7e27168, 4cacbff), whose tree is the head's
            tree 7ccf9996: "test on macOS" run 45596092894, "build, vet and test" run 45596092762 (section 9).
            f56ed54: runs 45592381550 (macOS) and 45592382168 (Linux), superseded by the merge (section 8).
            f2cc70f: both green, both on merge commit a5d6c99 (parents 819f712, f2cc70f), whose tree is the head's
            tree 1338fa21: "test on macOS" run 45581831353, "build, vet and test" run 45581831329 (section 7).
            72eecb2: both green, both on merge commit 3f1612b (parents 819f712, 72eecb2), whose tree is the head's
            tree bb72a78c: "test on macOS" run 45570499116, "build, vet and test" run 45570499348.
Scope:      the follow-up written up in 25-macos-ci-pr59.md, "Product follow-up to queue", queued by the coordinator
            at 07:40Z. Product change in the collector: audit (report 34) and the merge gate. No separate red-team,
            by the coordinator's recorded decision of 08:59Z (section 7).
Collector:  scripts/internal/remote_alpha_es_tls_status.py sha256 326c8d12cf553ce9dd3e248ffeb10d77a130e79922ca1f38a2eb9c1894f94057,
            the same at 72eecb2, f2cc70f, f56ed54, 4cacbff, a34e339, d31043d and 7e892d6.
```
All times are UTC on 2026-11-25.

## 1. In short

`_known_malformed_pem` in `scripts/internal/remote_alpha_es_tls_status.py` used to accept the malformed-PEM refusal of LibreSSL only with the full source path of one Apple build, build hash included (`LIBRESSL_PEM_ERROR_PATH`). It now fixes the form of the path instead, with `LIBRESSL_PEM_ERROR_LOCATION`. Every other part of the refusal stays exact.

The macOS runner's `/usr/bin/openssl` prints a path of that form. The two tests that #59 listed for this reason now pass on macos-26 unlisted, and their two list lines are gone. This is the first of report 25's triggers firing as designed.

## 2. The change

| File | Change |
|---|---|
| `scripts/internal/remote_alpha_es_tls_status.py` | `LIBRESSL_PEM_ERROR_LOCATION = rb"(?:/[^/:\x00-\x1f\x7f]+)*/crypto/pem/pem_lib\.c:[0-9]+"`, with a comment, in place of the pinned path. `_known_malformed_pem` uses it in the same place. |
| `scripts/remote_alpha_es_service_tls_status_test.go` | New `TestRemoteAlphaESServiceTLSStatusLibreSSLMalformedPEMLocation`. `…OpenSSLGrammar` now stops with the host's real result when the collector does not know it. |
| `scripts/remote_alpha_es_service_tls_openssl3013_test.go` | The pinned Apple path becomes a literal in the probe, so the old form is still checked through `cert_metadata` and `key_pair`. |
| `.docs/system_overview/remote_supported_host_alpha.md` | The second stderr line is described with the source location by its form. It used to say "fixed Apple LibreSSL build-path suffix", which did not match the code (O30-3). |
| `.github/ci/environment-only-tests-macos.txt` | The LibreSSL group and its two entries are removed, which leaves 20 entries. |

**What stays exact**, unchanged from before:

- exit code 1 and empty stdout;
- the first line (`unable to load certificate` or `unable to load key`);
- a decimal thread identifier;
- `:error:09FFF06C:PEM routines:CRYPTO_internal:no start line:`;
- `:Expecting: TRUSTED CERTIFICATE` or `ANY PRIVATE KEY`;
- one trailing newline, matched with `re.fullmatch`.

The OpenSSL 3.0.13 forms that the box prints are separate exact strings, and untouched.

**What the location pattern admits:** an absolute path, made of components that hold no `/`, no `:` and no control character (NUL to US, and DEL). It ends in `/crypto/pem/pem_lib.c`, then a colon and a decimal line number. The components are separated by `/`, which no component can hold, so the match runs in linear time.

## 3. Why the looser match is safe

- **A match only ever produces a failure code.** It returns `certificate_malformed` or `key_malformed`, both `status: fail` (lines 2402-2403 and 2518-2519 at 72eecb2). It can never produce a pass. The other outcome is `Incomplete("unexpected_openssl_grammar")`. So a wider match can turn an "incomplete" run into a typed failure, but never into a pass.
- **Only the fixed binary is matched.** The text comes from `OPENSSL = "/usr/bin/openssl"` (line 31), run through `run_fixed`. Changing that stderr means controlling root's `/usr/bin/openssl`.
- **Every part that carries meaning is still exact:** the error code, the function, the reason, the expected object and the line structure. Only the build's file path, which carries no meaning, is matched by form.
- **On the box nothing changes.** It prints the OpenSSL 3 form. The Linux job's `…Target3013…` tests replay the box's native tuples and pass.

## 4. Tests

`TestRemoteAlphaESServiceTLSStatusLibreSSLMalformedPEMLocation` calls `_known_malformed_pem` with 27 synthetic refusals at 72eecb2 (35 at f2cc70f, section 7; 42 at f56ed54, section 8; 46 at a34e339, section 10; 48 at d31043d, section 11; 50 at 7e892d6, section 12):

- **Accepted (7):**
  - the pinned build, for a certificate and for a key;
  - another build root, for a certificate and for a key;
  - another `libressl-x.y` folder;
  - another line number;
  - the short absolute path `/crypto/pem/pem_lib.c:694`.
- **Refused (20):**
  - another error code, function, reason or expected object;
  - the key refusal given for a certificate;
  - another first line;
  - an extra line, or a missing final newline;
  - another source file (`pem_info.c`) or folder (`crypto/x509`);
  - a relative path;
  - a missing line number, or no line part at all;
  - a newline, colon, NUL or CR in the path;
  - exit code 2;
  - output on stdout.

**Mutants**, run in a copy of the tree as user `ci`:

| Mutant | Result |
|---|---|
| M1: the old pinned path | 5 accepted cases fail: both other build roots, the other folder, the other line number, the short path |
| M2: a loose `[\s\S]*pem_lib\.c:[0-9]*` | 7 refused cases fail: newline, colon, NUL, CR, relative path, missing line number, other source folder |
| M3: the host's form unknown (target3013 certificate string changed) | `…OpenSSLGrammar` stops with "the collector does not recognise this result of /usr/bin/openssl for a malformed certificate: exit 1, stdout b'', stderr b'Could not read certificate from /dev/stdin\nUnable to load certificate\n'" |

All three were restored afterwards (`cmp`).

## 5. Validation

**Cloud container** (Linux, OpenSSL 3.0.13, Go 1.26.5, as `ci`, copy of tree bb72a78c):

- these tests pass:
  - `…LibreSSLMalformedPEMLocation`;
  - `…OpenSSLGrammar`;
  - `…CollectionTypedFailures`;
  - `…Target3013MalformedResponses`, `…Target3013VerifyFailureResponses`, `…Target3013NativeReplay` and `…Target3013FailurePublicationSemantics`;
  - `…X509TextSignatureTails`;
- root package `go test -count=1 .`: ok;
- `go vet` of the root and scripts packages: clean;
- `gofmt -l scripts/`: nothing;
- the macOS list against `./scripts/...` with the gate's own checks: 20 entries, 80 skips, OK.

**GitHub, on 72eecb2** (merge commit 3f1612b, tree = head tree):

- **"test on macOS", run 45570499116, job 139055674059, green 08:11Z:**
  - self-check: "Ran 145 tests", OK;
  - "test gate passed: 2 packages, 1 of them with skipped entries (20 entries); 80 tests skipped themselves, all of them listed";
  - "all 20 listed tests still fail on this host, each in a run of its own and in the run of its package";
  - so `TestRemoteAlphaESServiceTLSStatusOpenSSLGrammar` and `…CollectionTypedFailures/malformed_cert` ran unlisted and passed on macos-26. The runner's form fits the pattern;
  - the scripts package took 484.9 s ("Test") and 422.6 s (observed run), under the gate's 20-minute limit.
- **"build, vet and test", run 45570499348, job 139055674952, green 08:40Z:**
  - self-check 145 OK;
  - root package ok;
  - "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed";
  - "all 17 listed tests still fail";
  - "tests as root passed: 9 of execution-substrate/scripts".
- Full logs and the diff are in `33-evidence/`, with these sha256 values:
  - macOS log: 9c3a6676…51aa;
  - Linux log: 14fe5abd…f01d;
  - diff: a0ae126e…ce68.

## 6. Open points

- **The runner's exact stderr is not in the log**, because the tests pass. Inference: it is an Apple path of the same shape, with another build root. The pattern is what the test fixes, and the runner passing is the evidence that its form fits.
- **David's Mac:** its form (the pinned path) is still accepted (case `pinned_build_*`, and the Target3013 legacy checks). A later macOS update that changes only the build path no longer breaks a Mac run. One that changes anything else still does, and `…OpenSSLGrammar` now prints the new form.
- **Trigger 2 of report 25 is now live.** Both tests run unlisted in the macOS gate on every PR, so a macOS image whose LibreSSL prints a form the collector does not accept fails CI at once.

## 7. Repair after audit 34, and the red-team decision

Audit 34 (`34-pr62-audit.md`) gave BLOCK on 72eecb2 with two Lows, both test or doc only. The coordinator asked at 08:59Z for both to be fixed, with the collector file unchanged, both workflows green, and then a fresh diff check.

**A34-1, refusal rules not pinned.** Four patterns that loosen a rule the PR states passed every test. f2cc70f adds 8 refused cases to `TestRemoteAlphaESServiceTLSStatusLibreSSLMalformedPEMLocation`, so it now has 35 (7 accepted, 28 refused):

- `tab_in_path`, `escape_in_path` (ESC), `unit_separator_in_path` (US, 0x1f) and `delete_in_path` (DEL);
- `relative_path_with_a_folder` (`build/crypto/pem/pem_lib.c:694`) and `relative_path_from_the_parent` (`../crypto/pem/pem_lib.c:694`);
- `other_character_for_the_dot` (`pem_libXc`);
- `certificate_refusal_for_a_key`, the other direction of the cross-kind case (O34-3).

I ran the auditor's 8 mutants against f2cc70f, using the same `MUT` table as `34-pr62-audit-evidence/mutants.py` (the `diff` of the two tables is empty). The runner and output are in `33-evidence/run-mut34.sh.txt`, `mut34.py.txt` and `mutants-a34-1-after-repair.txt`:

| Mutant | 72eecb2 (audit 34) | f2cc70f |
|---|---|---|
| `M_ctl_only_nl_cr_nul` | survived | killed: `tab_in_path`, `escape_in_path`, `unit_separator_in_path`, `delete_in_path` |
| `M_no_del` | survived | killed: `delete_in_path` |
| `M_relative_prefix_allowed` | survived | killed: `relative_path_with_a_folder`, `relative_path_from_the_parent` |
| `M_dot_unescaped` | survived | killed: `other_character_for_the_dot` |
| `M_old_pinned_path` | killed | killed (5 accepted cases) |
| `M_any_file_in_pem` | killed | killed (`other_source_file`) |
| `M_line_optional` | killed | killed (`missing_line`) |
| `M_empty_components` | survived (optional) | survived (optional) |

`M_empty_components` (`//` in the path) still survives, as the auditor allowed. The stated rules (code comment, doc, report 33 §2) do not say that empty path components are refused. Pinning that would mean stating it in the collector's comment, and the collector must stay unchanged in this repair. Today's pattern refuses `//`, but no test holds it there.

**A34-2, stale doc claim.** `remote_supported_host_alpha.md` now opens the paragraph with "The admitted malformed-material response has the shape first observed with LibreSSL 3.3.6 on macOS: exit 1, empty stdout, and exactly two stderr lines." That is the auditor's suggested wording. The rest of the paragraph is unchanged apart from one line break.

**The collector is unchanged.** `scripts/internal/remote_alpha_es_tls_status.py` has sha256 `326c8d12…4f94057` at both 72eecb2 and f2cc70f. The repair diff (`33-evidence/repair-72eecb2-to-f2cc70f.diff`, sha256 2b068a60…1557) touches only the test file and the doc.

**Checks on f2cc70f** (cloud container, as `ci`, copy of tree 1338fa21):

- the new test, `…OpenSSLGrammar`, `…CollectionTypedFailures`, the four `…Target3013…` tests and `…X509TextSignatureTails`: pass;
- root package: ok;
- `go vet`: clean;
- `gofmt`: nothing;
- macOS list: 20 entries, 80 skips, OK.

**CI on f2cc70f:** both green, both on merge commit a5d6c99 (parents 819f712, f2cc70f), whose tree is the head's tree 1338fa21.

- "test on macOS", run 45581831353, job 139093520190, green 09:34Z:
  - self-check "Ran 145 tests", OK;
  - "test gate passed: 2 packages, 1 of them with skipped entries (20 entries); 80 tests skipped themselves, all of them listed";
  - "all 20 listed tests still fail on this host, each in a run of its own and in the run of its package";
  - the scripts package took 524.5 s ("Test"), under the 20-minute limit.
- "build, vet and test", run 45581831329, job 139093519550, green 09:46Z:
  - self-check 145 OK;
  - root package `ok execution-substrate 4.107s`;
  - gate passed with 17 entries;
  - "all 17 listed tests still fail";
  - "tests as root passed: 9 of execution-substrate/scripts".
- Logs: `33-evidence/macos-run45581831353-job139093520190.log` (sha256 826c36e3…02a0) and `33-evidence/linux-run45581831329-job139093519550.log` (sha256 88b1a44c…7f49).

**Red-team: none, by the coordinator's decision.** The coordinator decided at 08:59Z, and recorded it, that PR #62 gets no separate red-team. The reasons it gave:

- the product change is 5 lines;
- it can only turn "incomplete" into a failure result, never a pass (section 3; audit 34 §5 confirmed this with a consumer probe);
- the audit already fuzzed the pattern adversarially, with 400k inputs.

## 8. Repair after diff check 35

Diff check 35 (`35-pr62-delta-check.md`) gave BLOCK on f2cc70f with two Lows, both test gaps. The coordinator asked at 10:02Z for the cases in §5 of that report, test only, with the collector unchanged, the five location mutants killed and both workflows green.

**A35-1, three clauses of the location rule not pinned.** The decimal line number, the suffix starting at a path component, and the exact case of the suffix had no refused case. f56ed54 adds the four cases the audit names:

- `non_decimal_line_number` (`:0x2b6`);
- `text_after_line_number` (`:694x`);
- `prefix_on_the_crypto_folder` (`/xcrypto/pem/pem_lib.c`);
- `other_case_of_the_suffix` (`/CRYPTO/PEM/PEM_LIB.C`).

**A35-2, the decimal thread identifier not pinned** (pre-existing). f56ed54 adds `non_decimal_thread_id` (`0x1a2b:error:…`). `refusal()` takes a new `thread` argument for it, defaulting to the old literal `4336234112`, so every earlier case builds the same bytes as before.

**Two more of my own**, so that the rest of the first stderr line is pinned too and does not come back as a next finding:

- `missing_thread_id` (`:error:…` with nothing before it);
- `other_word_for_error` (`:warning:` in place of `:error:`).

The test now has 42 cases (7 accepted, 35 refused). I first wrote the count as 43, and the test failed with "LibreSSL location checks missing"; the table has 42 labels with no duplicate, so the count is 42. That failure is the count check doing its job.

**Mutants.** I ran the auditor's 14 mutants against f56ed54, with `mutants.py` and `witness.py` copied unchanged from `35-pr62-delta-check-evidence/` (sha256 equal). The runner and output are `33-evidence/run-mut35.sh.txt` and `33-evidence/mutants-a35-after-repair.txt`. Every mutant has a witness input on which it and the collector disagree, so none is equivalent.

| Mutant | f2cc70f (audit 35) | f56ed54 |
|---|---|---|
| `M_ctl_only_nl_cr_nul`, `M_no_del`, `M_relative_prefix_allowed`, `M_old_pinned_path`, `M_any_file_in_pem`, `M_line_optional`, `M_dot_unescaped` | killed | killed, by the same cases as before |
| `X_line_any_text` | survived | killed: `non_decimal_line_number`, `text_after_line_number` |
| `X_line_hex` | survived | killed: `non_decimal_line_number`, `text_after_line_number` |
| `X_line_trailing_text` | survived | killed: `non_decimal_line_number`, `text_after_line_number` |
| `X_no_boundary_before_crypto` | survived | killed: `prefix_on_the_crypto_folder` |
| `X_suffix_any_case` | survived | killed: `other_case_of_the_suffix` |
| `X_thread_id_any_text` | survived | killed: `non_decimal_thread_id` |
| `M_empty_components` | survived | survived (O35-1: no stated rule, no action) |

Two extra mutants check my own two cases (`33-evidence/run-mut35x.sh.txt`, `mut35-extra.py.txt`, output at the end of `mutants-a35-after-repair.txt`):

| Mutant | f56ed54 |
|---|---|
| `W_thread_id_optional`: `[0-9]*:error:` | killed: `missing_thread_id` |
| `W_any_word_for_error`: `[0-9]+:[a-z]+:` | killed: `other_word_for_error` |

The collector was restored after each run (`cmp`), and its sha256 is `326c8d12…4f94057` before and after.

**The collector is unchanged.** The repair diff (`33-evidence/repair-f2cc70f-to-f56ed54.diff`, sha256 15637527…c346) touches only `scripts/remote_alpha_es_service_tls_status_test.go`, +10/−3. In the manifest, the other four records are byte-identical to those of f2cc70f.

**Checks on f56ed54** (cloud container, as `ci`, copy of tree 15fb0945):

- the new test, `…OpenSSLGrammar`, `…CollectionTypedFailures`, the four `…Target3013…` tests and `…X509TextSignatureTails`: pass;
- `go vet ./scripts/`: clean;
- `gofmt`: nothing;
- macOS list: 20 entries, 80 skips, OK.

The full scripts package was not run locally: the change is one test function, and both workflows run the whole package.

**CI on f56ed54:** runs 45592381550 (macOS) and 45592382168 (Linux), started 10:10Z. Superseded by the merge in section 9, which CI tests on the current base.

## 9. Merge of trunk_dev (#60)

PR #60 merged into trunk_dev as 7e27168 before 10:32Z. It edits two of this PR's five files, the macOS list and `remote_supported_host_alpha.md`. The coordinator asked at 10:32Z for a trunk_dev merge folded into this repair, so that CI runs on the current base.

**Merge commit 4cacbff** (parents f56ed54 and 7e27168, tree 7ccf9996), no conflicts. No force push: the branch only gains commits.

**This PR's change is the same as before:**

- `git diff 7e27168 4cacbff` touches the same five files, +114/−22, as `git diff 819f712 f56ed54` (`33-evidence/pr62-4cacbff-vs-7e27168.diff`, sha256 a500b0c5…f350).
- The three code files are byte-identical to f56ed54: the collector (`326c8d12…`), the openssl3013 test and the status test. #60 does not touch them.
- The added and removed lines in the doc and the list are identical to those of `git diff 819f712 f56ed54` (Ran: `diff` of the `+`/`−` lines is empty). Their manifest records differ only because trunk_dev's versions of those two files changed.
- In the manifest against 7e27168, the records of the three code files are byte-identical to those of f56ed54 against 819f712.

**The merged macOS list** has 26 entries and 81 skips: #60's 6 entries and 1 skip, plus the 20 and 80 left after this PR removes its 2 LibreSSL entries. The gate's own `check_list` passes on it.

**Checks on 4cacbff** (cloud container, as `ci`, copy of tree 7ccf9996):

- the new test, `…OpenSSLGrammar`, `…CollectionTypedFailures`, the four `…Target3013…` tests and `…X509TextSignatureTails`: pass;
- root package: ok;
- `go vet ./scripts/`: clean;
- `gofmt -l scripts/`: nothing;
- macOS list: 26 entries, 81 skips, OK.

The mutant results of section 8 carry over: the collector and the test file are the same bytes.

**CI on 4cacbff:** both green, both on merge commit 73bd18d (parents 7e27168, 4cacbff), whose tree is the head's tree 7ccf9996 (Ran: `git fetch refs/pull/62/merge`). So CI tested this PR's bytes on the current base.

- "test on macOS", run 45596092894, job 139142614519, 10:33Z to 11:10Z, success. macos-26-arm64 image 20261117.0516.1, go1.26.5 darwin/arm64:
  - self-check "Ran 145 tests", OK;
  - `ok execution-substrate/scripts` in 523.9 s and 501.2 s, under the 20-minute limit;
  - "test gate passed: 2 packages, 1 of them with skipped entries (26 entries); 81 tests skipped themselves, all of them listed";
  - "all 26 listed tests still fail on this host, each in a run of its own and in the run of its package".

  So the new test and `…OpenSSLGrammar` ran unlisted on macOS and passed, alongside #60's new entries.
- "build, vet and test", run 45596092762, job 139142571789, 10:33Z to 11:19Z, success. ubuntu-24.04, go1.26.5 linux/amd64:
  - self-check "Ran 145 tests", OK;
  - root package `ok execution-substrate 4.574s`;
  - "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed";
  - "all 17 listed tests still fail";
  - "tests as root passed: 9 of execution-substrate/scripts".
- Logs: `33-evidence/macos-run45596092894-job139142614519.log` (sha256 be809489…2531) and `33-evidence/linux-run45596092762-job139142571789.log` (sha256 92ddf818…81fa).

At 11:21Z the branch was still 4cacbff and trunk_dev still 7e27168 (`git ls-remote`).

## 10. Repair after diff check 36

Diff check 36 (`36-pr62-delta-check.md`) gave BLOCK on 4cacbff with one Low, A36-1: four stated rules of the refusal had no case that broke them alone. The coordinator asked at 11:55Z for the four cases of §5 of that report, the count raised from 42 to 46, the PR body's count updated, and the new head.

**The four cases**, copied from `36-pr62-delta-check-evidence/proposed-cases.diff` (Ran: `diff` of the added lines against that file is empty):

| Case | Rule it pins alone (audit 36 §3.3) |
|---|---|
| `missing_first_line` | 3b, exactly two stderr lines: no fewer |
| `certificate_first_line_for_a_key` | 5, for pkey the first line is `unable to load key` |
| `key_object_for_a_certificate` | 10b, for x509 the object is not the key's |
| `certificate_object_for_a_key` | 11, for pkey the object is `ANY PRIVATE KEY` |

The test now has 46 cases (7 accepted, 39 refused), with no repeated label. With these, every row of audit 36's clause table has a refused case of its own.

**Mutants.** I ran all 33 mutants of audits 35 and 36 and my own two against a34e339. The scripts are copied unchanged: `mutants-36.py` and `witness-36.py` from `36-pr62-delta-check-evidence/` (sha256 equal), and audit 35's `mutants.py` and `witness.py`. The runner and output are `33-evidence/run-mut36.sh.txt` and `33-evidence/mutants-a36-after-repair.txt`.

| Mutant | 4cacbff (audit 36) | a34e339 |
|---|---|---|
| `C_first_line_optional` | survived | killed: `missing_first_line` |
| `C_key_first_line_either` | survived | killed: `certificate_first_line_for_a_key` |
| `C_object_either_kind` | survived | killed: `key_object_for_a_certificate`, `certificate_object_for_a_key` |
| `C_key_object_any` | survived | killed: `certificate_object_for_a_key` |
| the 14 `M_`/`X_` mutants except `M_empty_components`, the 2 `W_`, `C_first_line_any_text` and the 6 killed `E_` | killed | killed, by the same cases as before (`C_first_line_any_text` now also by `certificate_first_line_for_a_key`) |
| `M_empty_components`, `E_kind_guard_dropped`, the 5 `F_` | survived | survived: audit 36 §4 (O35-1, O36-2, O36-3), no action |

Every mutant has a witness input on which it and the collector disagree. The collector was restored after the run (`cmp`), sha256 `326c8d12…4f94057`.

**The collector is unchanged.** The repair diff (`33-evidence/repair-4cacbff-to-a34e339.diff`, sha256 9413c2f4…9941) touches only the status test, +5/−1. In the manifest against 7e27168, the other four records are byte-identical to those of 4cacbff.

**Checks on a34e339** (cloud container, as `ci`, copy of tree 695643a3):

- the audit 34 test set (the new test, `…OpenSSLGrammar`, `…CollectionTypedFailures`, the four `…Target3013…` tests, `…X509TextSignatureTails`): pass;
- root package: ok;
- `go vet ./scripts/ .`: clean;
- `gofmt -l scripts/`: nothing;
- macOS list: 26 entries, 81 skips, OK.

**CI on a34e339:** both green, both on merge commit f3f66d5 (parents 7e27168, a34e339), whose tree is the head's tree 695643a3 (Ran: `git fetch refs/pull/62/merge`).

- "test on macOS", run 45610077110, job 139191003378, 12:03Z to 12:41Z, success. macos-26-arm64 image 20261117.0516.1, go1.26.5 darwin/arm64:
  - self-check "Ran 145 tests", OK;
  - `ok execution-substrate/scripts` in 528.2 s and 549.7 s, under the 20-minute limit;
  - "test gate passed: 2 packages, 1 of them with skipped entries (26 entries); 81 tests skipped themselves, all of them listed";
  - "all 26 listed tests still fail on this host, each in a run of its own and in the run of its package".
- "build, vet and test", run 45610076995, job 139191002438, 12:03Z to 12:52Z, success. ubuntu-24.04, go1.26.5 linux/amd64:
  - self-check "Ran 145 tests", OK;
  - root package `ok execution-substrate 4.123s`;
  - "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed";
  - "all 17 listed tests still fail";
  - "tests as root passed: 9 of execution-substrate/scripts".
- Logs: `33-evidence/macos-run45610077110-job139191003378.log` (sha256 fdb91784…0e4d) and `33-evidence/linux-run45610076995-job139191002438.log` (sha256 ab3a8004…5802).

At 12:54Z the branch was still a34e339 and trunk_dev still 7e27168 (`git ls-remote`).

## 11. Two more cases after diff check 37, and the red-team question

Diff check 37 (`37-pr62-diff-check.md`) gave ACCEPT on a34e339, with two non-blocking observations. At 13:17Z the coordinator took the stricter reading of O37-1, asked for the two cases the audit verified (46 to 48) and the two PR body slips of O37-2 fixed, then a short diff check of the test-only delta.

**O37-1, a line before or between the two lines.** "Exactly two stderr lines" was pinned only by `extra_line`, which appends a line after the refusal. d31043d adds the audit's two cases (§4 of report 37; the added lines match it apart from indentation):

- `leading_line`: `warning\n` before a valid certificate refusal;
- `line_between_the_two`: `warning\n` between the first line and the error line.

The test now has 48 cases (7 accepted, 41 refused), with no repeated label.

**Mutants.** I ran 47 mutants against d31043d: the auditors' 45 (14 of audit 35, 17 of audit 36, 14 of audit 37) and my own 2. `mutants-37.py` and `witness-37.py` are copied unchanged from `37-pr62-diff-check-evidence/` (sha256 equal); the others are those of section 10. The runner and output are `33-evidence/run-mut37.sh.txt` and `33-evidence/mutants-a37-after-repair.txt`. 38 are killed and 9 survive.

| Mutant | a34e339 (audit 37) | d31043d |
|---|---|---|
| `P_leading_line_allowed` | survived | killed: `leading_line` |
| `P_any_prefix` | survived | killed: `leading_line` |
| `P_search_end_anchored` | survived | killed: `leading_line` |
| `P_line_between_allowed` | survived | killed: `line_between_the_two` |
| the other 8 of audit 37's own mutants (except the two below) and the 26 killed before | killed | killed, by the same cases as before |
| `N_first_line_optional_for_key`, `N_key_object_any_optional` | survived | survived: key-only forms of rules 3b and 11, each already pinned by a case (`missing_first_line`, `certificate_object_for_a_key`); audit 37 §3.2 needs no case for them |
| `M_empty_components`, `E_kind_guard_dropped`, the 5 `F_` | survived | survived: audit 36 §4, no action |

Every mutant has a witness input on which it and the collector disagree. The collector was restored after the run (`cmp`), sha256 `326c8d12…4f94057`.

**The collector is unchanged.** The repair diff (`33-evidence/repair-a34e339-to-d31043d.diff`, sha256 e4183b41…94f4) touches only the status test, +3/−1. In the manifest against 7e27168, the other four records are byte-identical to those of a34e339.

**Checks on d31043d** (cloud container, as `ci`, copy of tree 552211d5):

- the audit 34 test set: pass (8 of 8);
- root package: ok;
- `go vet ./scripts/ .`: clean;
- `gofmt -l scripts/`: nothing;
- macOS list: 26 entries, 81 skips, OK.

**O37-2, PR body.** Both slips are fixed in the body: the thread identifier and the word `error` now sit under the second line, and the survivors sentence no longer says they loosen no stated rule. The body is not part of the audited bytes.

**Red-team.** No red-team has run on PR #62. The coordinator decided at 08:59Z, and recorded it, that #62 gets none (section 7): the product change is 5 lines, a match can only turn "incomplete" into a failure result, never a pass, and audit 34 fuzzed the pattern with 400k inputs. Every change since audit 34 is test, doc or merge only. The collector has the same bytes as at 72eecb2, and report 37 §6 says nothing in the deltas changes that basis. So under that decision, PR #62 needs no red-team before the merge gate. The gate itself still needs both workflows, "test on macOS" included, green on the final head.

**CI on d31043d:** both green, both on merge commit 01a2ded (parents 7e27168, d31043d), whose tree is the head's tree 552211d5 (Ran: `git fetch refs/pull/62/merge`).

- "test on macOS", run 45623905093, job 139238946071, 13:28Z to 13:59Z, success. macos-26-arm64 image 20261117.0516.1, go1.26.5 darwin/arm64:
  - self-check "Ran 145 tests", OK;
  - `ok execution-substrate/scripts` in 420.1 s and 406.6 s, under the 20-minute limit;
  - "test gate passed: 2 packages, 1 of them with skipped entries (26 entries); 81 tests skipped themselves, all of them listed";
  - "all 26 listed tests still fail on this host, each in a run of its own and in the run of its package".
- "build, vet and test", run 45623905063, job 139238945413, 13:28Z to 14:13Z, success. ubuntu-24.04, go1.26.5 linux/amd64:
  - self-check "Ran 145 tests", OK;
  - root package `ok execution-substrate 4.124s`;
  - "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed";
  - "all 17 listed tests still fail";
  - "tests as root passed: 9 of execution-substrate/scripts".
- Logs: `33-evidence/macos-run45623905093-job139238946071.log` (sha256 6561c665…b1f6) and `33-evidence/linux-run45623905063-job139238945413.log` (sha256 ca9ef3f0…3e69).

At 14:15Z the branch was still d31043d and trunk_dev still 7e27168 (`git ls-remote`).

## 12. Two last cases after diff check 38

Diff check 38 (`38-pr62-diff-check.md`) gave ACCEPT on d31043d. At 14:18Z the coordinator asked, for consistency with the stricter reading of O37-1, for the two cases audit 38 verified under O38-1 (48 to 50), and for the PR body's stale CI line to be fixed. After CI is green on the new head, one last mechanical diff check, then the merge gate. No further test-strictness rounds after this one.

**O38-1 and O38-2, the "fewer" side of "exactly two stderr lines".** 7e892d6 adds the audit's two cases (§4 of report 38; the added lines match it apart from indentation):

- `missing_second_line`: `unable to load certificate\n` alone;
- `no_stderr`: an empty stderr, the plainest generic failure (exit 1, empty stdout).

The test now has 50 cases (7 accepted, 43 refused), with no repeated label. With these, "exactly two stderr lines" has a refused case at every position: a line before, between or after (`leading_line`, `line_between_the_two`, `extra_line`), the first line missing, the second line missing, and no lines at all.

**Mutants.** I ran 61 mutants against 7e892d6: the auditors' 59 (14 of audit 35, 17 of audit 36, 14 of audit 37, 14 of audit 38) and my own 2. `mutants-38.py` and `witness-38.py` are copied unchanged from `38-pr62-diff-check-evidence/` (sha256 equal); the others are those of section 11. The runner and output are `33-evidence/run-mut38.sh.txt` and `33-evidence/mutants-a38-after-repair.txt`. 46 are killed and 15 survive.

| Mutant | d31043d (audit 38) | 7e892d6 |
|---|---|---|
| `Q_first_line_alone` | survived | killed: `missing_second_line` |
| `Q_second_line_optional` | survived | killed: `missing_second_line` |
| `Q_empty_stderr` | survived | killed: `no_stderr` |
| the other 5 killed of audit 38's 14, and the 38 killed before | killed | killed, by the same cases as before |
| `Q_blank_line_before`, `Q_leading_line_for_key_only`, `Q_blank_line_between`, `Q_first_line_repeated`, `Q_line_between_for_key_only`, `Q_two_lines_either_order` | survived | survived: narrower forms at a pinned position, key-only forms, or combinations of pinned breaks; report 38 §4 needs no case for them |
| the 9 survivors of section 11 | survived | survived: no action (audits 36 and 37) |

Every mutant has a witness input on which it and the collector disagree. The collector was restored after the run (`cmp`), sha256 `326c8d12…4f94057`.

**The collector is unchanged.** The repair diff (`33-evidence/repair-d31043d-to-7e892d6.diff`, sha256 e380c4ef…e9e) touches only the status test, +3/−1. In the manifest against 7e27168, the other four records are byte-identical to those of d31043d.

**Checks on 7e892d6** (cloud container, as `ci`, copy of tree f5abc1b7):

- the audit 34 test set: pass (8 of 8);
- root package: ok;
- `go vet ./scripts/ .`: clean;
- `gofmt -l scripts/`: nothing;
- macOS list: 26 entries, 81 skips, OK.

**PR body.** The CI line for d31043d was updated to the green results at about 14:16Z, after audit 38 read the body. It now names 7e892d6's green results, along with the new counts.

**CI on 7e892d6:** both green, both on merge commit cf94bcd (parents 7e27168, 7e892d6), whose tree is the head's tree f5abc1b7 (Ran: `git fetch refs/pull/62/merge`).

- "test on macOS", run 45635004681, job 139277968680, 14:31Z to 14:56Z, success. macos-26-arm64 image 20261117.0516.1, go1.26.5 darwin/arm64:
  - self-check "Ran 145 tests", OK;
  - `ok execution-substrate/scripts` in 317.6 s and 305.7 s, under the 20-minute limit;
  - "test gate passed: 2 packages, 1 of them with skipped entries (26 entries); 81 tests skipped themselves, all of them listed";
  - "all 26 listed tests still fail on this host, each in a run of its own and in the run of its package".
- "build, vet and test", run 45635004670, job 139277970935, 14:31Z to 15:30Z, success. ubuntu-24.04 image 20261116.376.1, go1.26.5 linux/amd64. This run took 59 minutes, against 45 to 49 for the earlier heads: step "Test" took 35 min and "Listed tests still fail" 18 min. It stayed inside the job's 90-minute limit, and each go test inside the 20-minute limit. Inference: a slower runner, since the delta is two table rows.
  - self-check "Ran 145 tests", OK;
  - `ok execution-substrate/scripts 446.076s`; root package `ok execution-substrate 6.094s`;
  - "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed";
  - "all 17 listed tests still fail";
  - "tests as root passed: 9 of execution-substrate/scripts".
- Logs: `33-evidence/macos-run45635004681-job139277968680.log` (sha256 075bda93…9898) and `33-evidence/linux-run45635004670-job139277970935.log` (sha256 4ebd67b6…90c8).

At 15:30Z the branch was still 7e892d6 and trunk_dev still 7e27168 (`git ls-remote`).

## 13. Merge

Diff check 39 (`39-pr62-diff-check.md`) gave ACCEPT on 7e892d6 with no findings. At 15:51Z the coordinator gave the go to run the merge gate and merge into trunk_dev.

**Merge gate on 7e892d6** (checked at about 15:52Z):

- head 7e892d6 and trunk_dev 7e27168, both unchanged (`git ls-remote` and the API);
- both required checks green on the head: "build, vet and test" (run 45635004670) and "test on macOS" (run 45635004681);
- `mergeable_state: clean`;
- no open blocking finding: audit 39 ACCEPT; audits 34 to 38 closed by the repairs in sections 7 to 12;
- red-team: none, by the coordinator's recorded decision (section 7).

**Merged** by squash, pinned to the expected head SHA, at 15:52:10Z, as **`ae9aa65322954be16d5d3e354dd0aeec5d87723d`** on trunk_dev. Its parent is 7e27168, and its tree is `f5abc1b7…`, the tree of the audited head 7e892d6 (Ran: `git fetch origin trunk_dev`; `git diff 7e892d6 ae9aa65` is empty). The merge call returned HTTP 502, but the merge had gone through: the PR shows `merged: true`, `merged_at` 15:52:10Z.

**Branch.** `claude/project-thread-wbmulu` was not deleted automatically, perhaps because of the 502. This session cannot delete it: `git push origin --delete` gets HTTP 403 from the session's git proxy, and the GitHub tools have no branch delete. The branch's commits stay reachable as `refs/pull/62/head`. David can delete the branch from the PR page.
