FYI: PR 60 merged into trunk_dev as 7e27168 and edits the macOS list too. Fold a trunk_dev merge into your A35 repair for PR 62 so CI runs on the current base.
