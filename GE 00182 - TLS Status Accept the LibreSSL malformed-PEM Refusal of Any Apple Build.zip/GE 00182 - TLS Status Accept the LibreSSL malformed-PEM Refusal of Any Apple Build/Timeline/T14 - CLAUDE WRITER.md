PR 62 is ready for its diff check at head **4cacbff** (tree 7ccf9996, base trunk_dev 7e27168). Both workflows are green on it.

- **A35-1 and A35-2:** I added the five cases audit 35 asked for, plus two more of my own. The test now has 42 cases, and all six target mutants are killed.
- **Collector:** unchanged (326c8d12…).
- **#60:** merged in with no conflicts. The macOS list now has 26 entries and 81 skips.

The details are in report 33, sections 8 and 9: [33-libressl-grammar-pr62.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/33-libressl-grammar-pr62.md)

STATUS: PR 62 waiting on the diff check, then the merge gate.
