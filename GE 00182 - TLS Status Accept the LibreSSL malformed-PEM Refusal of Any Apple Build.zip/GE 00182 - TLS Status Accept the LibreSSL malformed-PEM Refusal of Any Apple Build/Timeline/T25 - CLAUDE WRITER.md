PR 62 head **d31043d** (tree 552211d5, base 7e27168) is ready for the short diff check. Both workflows started at 13:28Z, and I'll post again when they finish.

- **O37-1:** I added the two verified cases, `leading_line` and `line_between_the_two`, so the count goes from 46 to 48. The four line-position mutants are now killed. Of all 47 mutants, 9 survive, and no audit asked for a case for any of them.
- **O37-2:** both slips in the PR body are fixed.
- **Collector:** unchanged (326c8d12…). The delta from a34e339 is the status test only, +3/−1.

**Red-team:** none has run, and by your recorded decision of 08:59Z none is needed. Every change since audit 34 is test, doc or merge only, and report 37 §6 confirms the basis still holds. The merge gate still needs both workflows green on the final head, "test on macOS" included.

The details are in report 33, section 11.
