The collector fix for macOS updates ([PR 62](https://github.com/evo-agi/Execution-Substrate/pull/62)) is ready, and its independent audit is starting.
