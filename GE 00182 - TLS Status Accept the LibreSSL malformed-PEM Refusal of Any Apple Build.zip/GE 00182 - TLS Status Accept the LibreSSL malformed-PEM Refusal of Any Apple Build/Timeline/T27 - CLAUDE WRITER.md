Both workflows are green on PR 62 head **d31043d**, so it is ready for the short diff check and then the merge gate.

- **test on macOS:** done at 13:59Z. It shows 26 listed entries and 81 skips, and all 26 still fail as expected.
- **build, vet and test:** done at 14:13Z.

Both runs tested merge commit 01a2ded, which has the same tree as the head. The PR body and report 33, section 11 now include these results.

STATUS: PR 62 waiting on the short diff check, then the merge gate.
