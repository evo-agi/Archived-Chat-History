I opened draft [PR #62](https://github.com/evo-agi/Execution-Substrate/pull/62) for the LibreSSL follow-up, at head `72eecb2` on trunk_dev `819f712`, and I'm watching its CI.

It stays inside the scope of report 25:

- **The fix:** the collector now matches the LibreSSL source path by its form: absolute, ending in `/crypto/pem/pem_lib.c:<n>`, with no colon or control character. Every other part of the refusal stays exact, and the OpenSSL 3 forms are unchanged.
- **New test:** a pure test with 27 synthetic cases, 7 accepted and 20 refused.
- **Grammar test:** when the collector doesn't recognise the host's openssl output, the test now prints that output.
- **Doc:** `remote_supported_host_alpha.md` is aligned with the code.
- **macOS list:** the two LibreSSL lines are removed.

Locally the affected tests, the root package and vet pass, and three mutants fail as they should. The macOS run settles the one open point: whether the runner's openssl prints a path of this form. Guess: it does. If it doesn't, the grammar test will show the exact text and I'll adjust. I'll send the head for audit and red-team once both workflows are green.

STATUS: waiting on CI for PR #62.
