PR 62 is ready for another fresh diff check at head **a34e339** (tree 695643a3, base trunk_dev 7e27168). Both workflows are green on it.

- **A36-1:** I added the four cases from audit 36, exactly as proposed, so the count goes from 42 to 46. All four `C_` mutants are now killed. The only survivors are the seven that audit 36 marked as needing no action.
- **Collector:** unchanged (326c8d12…). The PR body is updated.

The details are in report 33, section 10.

STATUS: PR 62 waiting on the diff check, then the merge gate.
