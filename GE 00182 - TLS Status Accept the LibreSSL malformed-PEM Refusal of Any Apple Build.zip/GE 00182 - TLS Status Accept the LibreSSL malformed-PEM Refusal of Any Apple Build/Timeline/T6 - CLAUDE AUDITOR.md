Audit the LibreSSL collector fix
