The macOS collector fix is merged ([PR 62](https://github.com/evo-agi/Execution-Substrate/pull/62), merge SHA ae9aa65) after a clean final audit. Whenever convenient, please click "Delete branch" on that PR page, since the thread can't delete it.

STATUS: WORKING (PR 63 build-environment fix)
