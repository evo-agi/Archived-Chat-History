## Verdict

Codex stopped correctly. This is a **one-file stale protected-content identity**, not another production, migration, or authority defect.

`test_rw0_b2_capability_boundaries.py` deliberately preserves P09 through layered exact identities. It authenticates the current C2B2 boundary-test bytes, removes the normal-terminal consumer-map addition, then reconstructs the older P1 and original protected-content identities. The active-cancel consumer-inventory edit creates one legitimate new layer above that chain. The repair must add a new exact successor—not replace `_RW0_NORMAL_TERMINAL_P09_IDENTITY` or weaken the reconstruction. 

The correct final history is:

```text
active-cancel consumer-inventory successor
    ↓ exact removal
normal-terminal P09 successor
    ↓ exact removal
RW0-C2 P1 successor
    ↓ exact removal
original protected P09 identity
```

No independent audit should begin yet. The full suite has not passed and there is no stable final 83-path manifest. Implementation closeout requires completed validation and reproducible final provenance; any changed repair bytes then require a fresh independent audit. Governed Execution Provenance G… Governed Execution Codex Subage…

## Next action

Execute this prompt in the **same workspace-write Codex implementation conversation**:

`RW0_ACTIVE_CANCEL_P09_PROTECTED_CONTENT_SUCCESSOR_REPAIR_PROMPT.md`

RW0_ACTIVE_CANCEL_P09_PROTECTED_CONTENT_SUCCESSOR_REPAIR_HANDOFF.zip[Download the complete P09 successor-repair handoff ZIP](sandbox:/mnt/data/RW0_ACTIVE_CANCEL_P09_PROTECTED_CONTENT_SUCCESSOR_REPAIR_HANDOFF.zip)

ZIP SHA-256:

```text
fc7f4d48feece376cf3452765ecbe0182e7e094a80c9abab5a37f4fd25aa24e5
```

The handoff authorizes exactly one newly changed path:

```text
tests/test_rw0_b2_capability_boundaries.py
```

It requires Codex to:

1. Reproduce and bind the exact current 82-path candidate.
2. Prove that all 81 prior records remain exact and that the sole existing addition is the C2B2 inventory test.
3. Verify that its change is one exact insertion in `expected_consumers`.
4. Add a strict active-cancel P09 identity and peel layer above the normal-terminal identity.
5. Preserve every older P09 identity and exact addition byte.
6. Add positive reconstruction and negative missing, duplicate, moved, mutated, predecessor-mutation, and trailing-byte cases.
7. Run the complete focused groups and unrestricted full suite.
8. Generate stable final v2 provenance with exactly 83 paths.
9. Stop for a fresh provenance-first independent audit.

If the inventory edit is not one exact insertion, another path is implicated, or a production defect appears, Codex must stop rather than loosen the protected-content oracle.

**Confidence:** stale-successor diagnosis 0.99; one-file repair scope 0.98; overall active-cancel implementation correctness remains unassessed until full validation and independent audit.
