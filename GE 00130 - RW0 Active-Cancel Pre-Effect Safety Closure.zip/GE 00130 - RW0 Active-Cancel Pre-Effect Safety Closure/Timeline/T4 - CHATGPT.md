## Verdict

Codex stopped correctly with `IMPLEMENTATION_SCOPE_REPLAN_REQUIRED`.

This is a **one-file test-scope correction**, not an authority, schema, migration, or implementation-plan contradiction. The candidate legitimately changes `sqlite_transition_transaction.py`; the failing test still pins the prior normal-terminal controller hash as the current identity. Its existing structure already preserves a sequence of historical controller hashes and selects one exact current successor, so the correct repair is to add the active-cancel controller hash as the next successor—not replace or weaken the historical checks.  

The repair must:

- add `tests/test_b3c4c_prerequisite_contract.py` to scope;
- preserve the existing normal-terminal hash  
  `faf30aea7e748f7631e06fd6704970c69dab5b7b311c1b9864bcd338be03ac00`
  as historical;
- make the active-cancel candidate hash  
  `a090e024ed52305ce75535d35551f73854e89aae61f52753cb6d407d812ce544`
  the exact current controller identity;
- reject regression to the previous normal-terminal hash;
- leave all 80 current candidate records byte-for-byte unchanged.

The reported manifest `38df0c07…16c58d6` is useful as the **opening repair baseline**, but it is not an audit-ready target because final validation has not passed. After the one-file repair, the expected candidate is 81 paths. Codex must complete the focused groups and unrestricted full suite, then produce a new stable v2 manifest.

No fresh independent audit should begin before that repair and final validation. Once the test byte changes, the final 81-path candidate requires a fresh read-only audit; a prior audit or pre-repair manifest cannot bind changed bytes. Governed Execution Codex Subage… V2 remains the correct recipe for this active new chain and must be run twice to distinct private external outputs. Governed Execution Provenance G…

## Handoff

**Prompt to execute in the same workspace-write Codex implementation conversation:**

`RW0_ACTIVE_CANCEL_PRE_EFFECT_SAFETY_CLOSURE_SCOPE_REPAIR_PROMPT.md`

RW0_ACTIVE_CANCEL_PRE_EFFECT_SAFETY_CLOSURE_SCOPE_REPAIR_HANDOFF.zip[Download the complete scope-repair handoff ZIP](sandbox:/mnt/data/RW0_ACTIVE_CANCEL_PRE_EFFECT_SAFETY_CLOSURE_SCOPE_REPAIR_HANDOFF.zip)

ZIP SHA-256:

```text
273dafdfc22b385f6bb1625f3e6e4f21b26e867a1ed82958c087a9d42abd7217
```

The handoff requires Codex to reproduce the exact 80-file opening candidate before editing, modify only the newly authorized frozen-source test, prove that all original 80 manifest records remain identical, run the complete validation sequence, generate the final 81-file v2 provenance, and stop for independent audit.

It prohibits production, migration, documentation, schema, or runtime changes during this repair. If another frozen-source owner or implementation defect appears after this test is repaired, Codex must stop with the exact path or defect rather than widening scope again in the same turn.

**Confidence:** scope diagnosis 0.99; repair design 0.98; opening-candidate binding 0.97; implementation correctness remains unassessed until the full suite passes and the 81-path candidate receives independent audit.
