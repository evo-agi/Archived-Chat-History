# Disclaimer

- Before you use the timeline, please look out for gaps, e.g. missing events and/or messages; and make sure the contents from each file are unique, because I manually copied and pasted them from the MacOS ChatGPT app.
- ChatGPT's UI automatically converts long text into attachment. If the content is not captured in time, it would be skipped, and you can tell, based on the "T\<ID\> -" prefix in the filename. For example, "Timeline/T3 - CHATGPT.md" is immediately before "Timeline/T4 - USER.md"
- `Generated/` stores some of the attachments. Its coverage is not guaranteed to be complete, and, for each filename, only the first copy noticed by me is attached. For example, if file with name A is returned multiple times at T1, T2, T3, and I notice it at T2, I will only attach the copy from T2. If the file contents are different in T1 and T3, compared to T2, that difference is not captured.
