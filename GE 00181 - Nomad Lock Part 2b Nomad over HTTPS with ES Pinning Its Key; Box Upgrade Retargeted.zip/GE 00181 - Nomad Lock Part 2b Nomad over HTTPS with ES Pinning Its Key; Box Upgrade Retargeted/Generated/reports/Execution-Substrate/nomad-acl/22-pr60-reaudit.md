# Re-audit of ES PR #60 (Nomad lock part 2b: Nomad over HTTPS) at dfb2873

Verdict: **BLOCK**, on one new Low in the PR's own code (A22-1). Every
finding from audits 20 and 21 is fixed.

- **The repairs hold** (Ran):
  - A20-1: the CA-file loader now refuses text before, between or after the
    certificates, a corrupt block, a block without an END line and a private
    key. It accepts certificates with white space around them. A probe of 17
    files shows this.
  - A20-2 (a), (b), (c) and audit 21's A23-3: each check now has a test.
  - I reran 13 mutants at the repaired sites, the 9 survivors of audits 20
    and 21 plus 4 new ones on the loader. A test kills all 13, and each is
    killed by the case written for it.
- **A22-1 (Low, in the diff, new).** On a host the upgrade already moved
  to HTTPS, `check` and `apply` report "nothing to do" even when Nomad
  holds an anonymous policy that lets anyone submit jobs into ES's
  namespace `es-submit-v1`. The only lock proof on that path is a 403 for
  an anonymous `GET /v1/jobs`. That request asks about the `default`
  namespace, so it stays 403 when the anonymous policy covers only
  `es-submit-v1`. On real Nomad 2.1.1 with such a policy, the anonymous job
  list answered 403, an anonymous plan in `es-submit-v1` answered 200, and
  `GET /v1/acl/policy/anonymous` answered 200 instead of 404 (Ran). ES's own
  per-submit gate makes that last request and would refuse every submit,
  so ES fails closed. But the upgrade calls a host verified that is not
  locked against other local submitters. The fix is about five lines plus
  one fake-host case.
- **The full suite matches base** (Ran). On head `dfb2873` and base
  `bf5a760`, the same 13 top-level tests fail (43 with subtests), each for
  the same reason, and the same 14 skip themselves. The names are under
  "Validation assessment". With passwordless sudo for the test user, the
  real-Nomad upgrade test ran and passed.
- **CI on `dfb2873`.** Run 45555027151 has the old 10-minute limit, because
  #61 has not merged. Its step "Test" passed: `es/app` stayed under 10
  minutes this time. The job passed in 45.1 minutes (Read: 05:38:59 to 06:24:04Z in `ci/job-139004900291.log`).
- **The rest of the delta.** I read the whole base-to-tip diff again. I
  found nothing else that changes the conclusions of audits 20 and 21.

Every statement is marked **Ran** (I executed it and saw the output),
**Read** (I read code, docs or logs) or **Inference** (reasoned from cited
facts, not observed directly). Evidence paths are relative to
`22-pr60-reaudit-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Repository / audit target

- Repository: evo-agi/Execution-Substrate, draft PR #60 into `trunk_dev`,
  branch `claude/project-thread-9slgp8`.
- Base: `bf5a760a2276f5d8b7600d7b64523e4ee32410d0` (trunk_dev and the
  merge-base; trunk_dev had not moved at 06:30Z).
- Topic: `dfb2873edf724466e18715e3a8dc7afb4dc1d08c`, tree
  `e9c9ca7b714f9ade80a0c9108a369354649bd851`, 12 commits. It is the PR head
  (Ran: `git fetch`, and the GitHub API at 05:50Z and again at
  06:40Z).
- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`
  (verified against the project copy before use).
  - manifest_sha256
    `b091699aeabefea43286596f31540d68504f572d95517ef9888ee5804e8fb0df`
  - textual_diff_sha256
    `5277305adcc30a9605912f18dbe6566fd03d51b0bbaa3c3119f2d9eb7d8e38ba`
  - 58 paths, the same as at `f505f72`, none under `.github/`
- Scope, from the coordinator: a fresh, read-only re-audit of `dfb2873`.
  - Verify each fix for A20-1, A20-2 (a) (b) (c), audit 21's A23-3 and the
    CI item A20-3/A23-1.
  - Rerun the mutants.
  - Audit the full delta, not only the fixes.
  - #60 should merge after #61, so check #60's CI after #61 lands, if it has.
  - This thread had not audited #60 before (protocol §14).
- Writer's report: `11-part2b-nomad-https.md`, section 13 (repairs),
  sha256 `e4d5c9e5f4460af723cebc13de5f0bacd7f31e1c2402025e1fc0ace86c0debdd`.

## Audit posture

- Read-only. Nothing was committed, pushed or commented on GitHub, and
  neither PR was edited. No subagents were used. I did not touch the box or
  any live service.
- Tests ran in this container as user `ci` (uid 1500, gid 1600, groups
  docker), with Go 1.26.5, `GOTOOLCHAIN=local`, `GOFLAGS=-mod=readonly`,
  `GOPROXY=off` and an emptied environment.
  - `ci` has passwordless sudo, as the CI runner's user has, so the tests
    that use `sudo -n` ran instead of skipping.
  - Nomad 2.1.1, Vault 2.2.2 and SPIRE 1.14.4 were checked against the
    workflow's SHA-256 pins. Nomad 2.0.0 was checked against HashiCorp's
    SHA256SUMS file, not its signature. Docker 29.9.3 had the CI images,
    pulled by digest.
- Mutants ran one at a time in a scratch clone (`/home/ci/mut`). It was
  restored with `git checkout` after each one, and its tree was clean at the
  end (Ran).
- The audit tree `/home/user/Execution-Substrate` was used only for the
  manifest and for reading.

## Provenance reproduction (Ran, `provenance/`)

- The pushed tip equals the reported tip, and `bf5a760` is the merge-base.
- Setup: branch `claude/project-thread-9slgp8` checked out at the tip, then
  `reset --mixed` to the base, upstream `origin/trunk_dev`, `umask 022`.
  - Two opening runs of the recipe are byte-identical. They also equal the
    writer's `11-evidence/manifest-v2-dfb2873.json`.
  - Two closing runs after all tests and mutants (06:35:04Z)
    are byte-identical to the opening ones.
- No mode-bit difference was tolerated.

## Coverage

- Read in full, the repair delta `f505f72..dfb2873` (5 files, +111/-10):
  - `nomad_tls.go`;
  - the new cases in `nomad_tls_test.go`, `nomad_tls_identity_test.go`,
    `supported_local_proof_boundary_test.go` and
    `remote_alpha_upgrade_es_host_test.go`, including the fake curl's new
    `https-jobs-open` marker.
- Read again, review depth, the whole base-to-tip product diff:
  - `nomad_tls.go`, `submit.go`, `nomad_access.go` (every sender of
    `X-Nomad-Token` goes through the pinned client), the reliable-submit
    provider and `es/config/config.go`;
  - the `nomad_tls` region and the bootstrap helpers of
    `70_linux_setup.sh`;
  - `nomad_acl.sh`, `nomad_acl.py` and `nomad_tls_identity.py` (in full);
  - the proof projection, `bringup.sh`, `01_bringup.sh` and
    `10_health_check.sh`;
  - `remote_alpha_upgrade_es.py`: shapes, `inspect_host`, `inspect_start`,
    `inspect_migrated`, `apply_nomad_tls`, `install_es`, `verify_after`,
    `restore_host`, `cmd_apply` and the curl helpers;
  - the docs: `configuration.md` "Nomad HTTPS", `contracts.md`, the
    upgrade section of `remote_supported_host_alpha.md`, and `PLANS.md`.
- Read: audits 20 and 21 and their evidence lists; the writer's section 13;
  the PR body; CI runs 45555027151 (#60) and 45555695320 (#61) through the
  GitHub API.
- Not read line by line again: the parts of the upgrade, setup and test
  harnesses that `f505f72..dfb2873` does not touch and that audits 20 and
  21 read in full. I relied on their reading there and say so.

## Findings

### Patch defects

```text
AUDIT FINDING
ID / Type / Severity: A22-1 / verification gap (contract drift) / low
Current contract or strategic target:
  - PLANS.md (this PR): "a box it already moved is only verified and left unchanged".
  - The lock's own contract (PLANS.md current facts, contracts.md): ES submits "only while
    Nomad enforces ACLs with no anonymous policy". ES's per-submit gate
    (es/admission/nomad_access.go verifyAccessControl) and the shell helpers
    (nomad_acl.sh nomad_acl_state_check) both require an anonymous
    GET /v1/acl/policy/anonymous to answer 404.
  - The repair's own test comment (remote_alpha_upgrade_es_host_test.go:1377): "On the migrated
    host the anonymous job list is the only proof that Nomad still enforces its ACLs".
Path and line: scripts/internal/remote_alpha_upgrade_es.py:1252-1263 (inspect_migrated);
  cmd_check :1546 and cmd_apply :1569-1574 return "nothing to do" on it.
Evidence:
  (Read) On an https host, inspect_migrated runs only three checks: a named leader over HTTPS,
  nomad_tls_identity.py check, and an anonymous GET /v1/jobs that must answer 403. It does
  not run nomad_acl_setup.sh check (which verify_after runs) and makes no anonymous-policy
  request.
  (Ran, probes/anon-policy-probe.sh and -output.txt) Real Nomad 2.1.1, ACLs on,
  namespace es-submit-v1. With no anonymous policy: anonymous GET /v1/jobs 403,
  GET /v1/acl/policy/anonymous 404. After a management token creates the policy
  "anonymous" with namespace "es-submit-v1" { capabilities = ["submit-job","list-jobs","read-job"] }:
    - anonymous GET /v1/jobs still answers 403 (it asks about namespace "default");
    - anonymous GET /v1/jobs?namespace=es-submit-v1 answers 200;
    - an anonymous plan in es-submit-v1 answers 200;
    - GET /v1/acl/policy/anonymous answers 200.
  So all three of inspect_migrated's checks pass on that host, and check and apply exit 0
  with "nothing to do". (Inference from the code and the probe; no fake-host case pins it.)
Impact: ES itself fails closed. Its gate makes the anonymous-policy request before every
  submit and refuses with 503. But the lock's purpose is that only ES can submit, and on that
  host any local process can register jobs in ES's namespace without a token. The upgrade's
  in-place verification would call such a host migrated and sound. Only someone holding the
  root-only management token can create the policy, so this is drift or operator error that
  the check exists to catch, not a way in for an unprivileged attacker. The box run plan
  (report section 11, step 4) also runs nomad_acl_setup.sh check separately, so the planned
  box run would catch it. A later rerun of check as a health or verification step would not.
Required correction: in inspect_migrated, also require an anonymous
  GET <https addr>/v1/acl/policy/anonymous to answer 404, with the same curl options. That is
  the request ES's gate and nomad_acl_state_check already make, and it is read-only. Block
  otherwise, with a message such as "Nomad holds an anonymous ACL policy (HTTP <code>)".
  Add one fake-host case: a migrated host whose Nomad answers 200 there while the job list
  still answers 403. check and apply must block, only read, and change nothing.
  Optionally make verify_after do the same; its acl_setup("check") already covers it.
  (The other way out is to narrow PLANS.md, the docs and the test comment to "Nomad enforces
  ACLs in the default namespace". I do not recommend it: the lock's contract is "no anonymous
  policy".)
Uncertainty: none on Nomad's behaviour (Ran on 2.1.1; Inference that 2.0.0 is the same, since
  the anonymous policy is Nomad's long-standing mechanism). Severity is my judgement: I
  rate it Low, not Info, because the PR says the migrated path verifies the box and this is the
  one lock property that path misses.
Patch defect or pre-existing issue: patch defect (inspect_migrated is new in this PR).
Minority note: audit 20 (A20-2(a), Impact) read the 403 as showing that Nomad "holds no
  anonymous policy". The probe shows it does not.
```

### Pre-existing issues

None new. A20-3/A23-1 (the gate's missing `-timeout`) is outside this PR's
paths and is PR #61. See "CI" below.

### Observations

- **O22-1, the loader's "white space" is Unicode white space.** The loader
  trims with `unicode.IsSpace`, so a no-break space (U+00A0) between two
  certificates is accepted (Ran, probe case 4). `bytes.TrimSpace` at base
  did the same. The docs do not say ASCII, and no trust is added.
  Recorded only.
- **O22-2, the repairs' tests are specific.** Each mutant fails the case
  written for it, not some unrelated assertion (Ran, `mutants/*.log`). For
  example, A12b fails "NOMAD_CACERT empty" because `SSL_CERT_FILE` points
  the system store at Nomad's CA. Without that line, Python would trust it,
  and the fetch would succeed.
- **O22-3, CI timing on this head.** Run 45555027151's step "Test" ran from
  05:42:46Z to 06:09:17Z and passed under the old 10-minute limit. By go test's own times, `es/app` took 452.1 s in the gated run, 441.1 s in the observed run and 428.5 s in the still-failing run, the longest at 75% of the old limit. `reliablesubmit` took 34.7 s and the job 45.1 min: a normal-speed runner (Read, `ci/job-139004900291.log`).
  That is one run on one runner. The margin finding stands, and #61
  addresses it.
- **O22-4, the known limits hold as audits 20 and 21 described them**
  (Read):
  - ES follows a symbolic link for `nomad.root_ca_file`;
  - `base_url` may name any loopback IP;
  - the upgrade does not roll the ACL policies back;
  - a new certificate needs its pin in `es.json` and an ES restart.

## Fix verification (Ran)

| Finding | Repair in `dfb2873` | My check | Result |
| --- | --- | --- | --- |
| A20-1 CA loader | prefix and one-block checks in `loadNomadRootCAs`; 3 refusal cases plus 1 accepted case | probe of 17 files (`probes/ca-loader-probe.txt`); mutants L1 to L6 | refuses leading, between and trailing text, corrupt blocks, a block without END, junk on BEGIN or END lines, private keys, empty and white-space-only files, and a BOM; accepts 1 or 2 certificates with white space or CRLF around them; all 6 mutants killed |
| A20-2 (a) / A23-2 / O20-1 upgrade 403 | fake curl marker `https-jobs-open`; a migrated-host case and a rollback case | mutants A7 and A7b | both killed, by "check of a migrated host whose Nomad lists jobs to anyone" and by the subtest "Nomad lists jobs to anyone over HTTPS" |
| A20-2 (b) identity tool loopback | case "non-loopback IP address" | mutant A8 | killed by that case |
| A20-2 (c) proof fetch `NOMAD_CACERT` | three cases: empty, relative, symbolic link | mutants A12, A12b, A12c | each killed by its own case |
| A23-3 identity tool linked CA | `check` case and `pin` subtest | mutant G7 | killed by both |
| A20-3 / A23-1 CI timeout | separate PR #61 | CI run on `dfb2873`; PR #61 audit (report 02 in `ci-gate-time-limit/`) | see O22-3 and "CI" |

## Validation assessment

All runs: user `ci`, Go 1.26.5, `-count=1`, Nomad 2.1.1, in this container
(4 CPUs). Evidence is in `tests/`, `mutants/` and `probes/`, and the method
scripts are in `method/`.

| Run | Result |
| --- | --- |
| `go test -json ./...` on head `dfb2873` (`-timeout 45m`), 05:54Z to 06:05Z | 1905 pass, 13 fail, 14 skip (top level); 10134 / 43 / 15 with subtests; `es/app` 642.0 s, `es/admission` 414.2 s, `scripts` 470.7 s |
| `go test -json ./...` on base `bf5a760`, 06:06Z to 06:16Z | 1890 pass, 13 fail, 14 skip; 9986 / 43 / 15 with subtests |
| Head against base | the same 43 failing tests and subtests, and the same 15 skips. The first failure lines match for 12 of 13 tests. For the 13th, the bring-up, only the line number moved (369 to 372), and both runs failed on the image build's `apk add` from dl-cdn.alpinelinux.org (`tests/failure-reasons-head-vs-base.txt`) |
| New tests on head | 16 top-level tests that base lacks, all pass. One base test, `TestRemoteAlphaUpgradeESNomadLockMatchesSupportedConfig`, is replaced by `TestRemoteAlphaUpgradeESNomadShapesMatchTheBoxAndTheSupportedConfig` (the retarget) |
| Repaired tests on head | `TestNewNomadClientRefusesWithoutAUsableRootCAOrPin`, `TestNomadTLSIdentityChecksWhatESChecks`, `TestSupportedLocalProofNodeDetailLoopbackAdmission`, `TestRemoteAlphaUpgradeESApply`, `TestRemoteAlphaUpgradeESApplyRollsBackOnFailure`: pass |
| `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` (real Nomad, real `nomad_acl_setup.sh` through `sudo -n`) | pass, 13.8 s |
| 13 mutants (`mutants/results.jsonl`) | 13 killed |
| CA-loader probe, anonymous-policy probe | as above |

The 13 tests that fail on both head and base. Each is an entry in
`.github/ci/environment-only-tests.txt` unless marked:

- `es/admission/internal/reliablesubmit`:
  - `TestOperationalHandoffSchema4BinaryRefusesSchema5`
  - `TestSQLiteV3OldBinaryRefusesWithoutMutation`
  - `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`
- `es/app`:
  - `TestBringupScriptUpCheckDownFullProfile`. **Not listed**: it fails
    here only because its image build cannot reach the internet. Audit 20
    ran it with an offline image at `f505f72` and it passed. The repair
    does not touch bring-up, and CI runs it.
  - `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`
- `scripts`:
  - `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`
  - `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`
  - `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`
  - `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`
  - `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`
  - `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`
  - `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`
  - `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`

These are the same 13 names as audits 20 and 21 found at `f505f72` and on
base.

The 14 tests that skip themselves, on head and base alike:

- `es/admission`:
  - `TestExecutionRootProbeDirectorySwapStress`
  - `TestExecutionRootProbeDirectorySwapStressAttacker`
  - `TestOperationalHandoffChildProcess`
- `reliablesubmit`:
  - `TestPrivateReplayObjectAllocatorHelperProcess`
  - `TestSQLiteClaimStoreLockHelperProcess`
- `scripts`, the nine root-only tests:
  - `TestRemoteAlphaESServiceTLSStatusChildNamespaceReal{CollectorDeath,DeafAnchor,Descendants,Kernel,Siblings}`
  - `TestRemoteAlphaHostFirewallRealKernel{ApplyConfirmRollback,BridgeIsolation,Traffic}`
  - `TestRemoteAlphaHostFirewallSSHDDropInWithRealSSHD`

Not run:
- `-race`;
- Nomad 2.0.0 (the repair touches no Nomad-facing code path; audits 20 and
  21 ran 2.0.0 at `f505f72`);
- the bring-up with an offline image;
- the nine root-only `scripts` tests;
- `go vet` locally (CI's Build, Vet and macOS Vet passed on `dfb2873`);
- a CI rerun;
- anything on the box.

## CI

- Run 45555027151 on `dfb2873` (pull request): "build, vet and test"
  passed in 45.1 min (Read). Every step passed: build, vet, macOS vet, the
  gate self-check, "Test", "Listed tests still fail" and the root tests.
- It ran the old gate: none of its 25 `go test -json` lines carries
  `-timeout` (Ran: grep), so each test binary had go test's 10-minute
  default. `es/app` used 75% of it (O22-3).
- #61 had not merged at 06:40Z, and trunk_dev was still `bf5a760`
  (Ran: `git ls-remote`; Read: the GitHub API). So I could not check #60's
  CI after #61 lands, as the coordinator asked. #61's own run 45555695320
  passed with the new limits, and its audit (report 02 in
  `ci-gate-time-limit/`) accepts it.
- A trial merge of `dfb2873` with #61's head `af266dc` is clean
  (Ran: `git merge-tree`, tree `50b77c5`). The two PRs change no file in
  common: none of #61's 5 paths is among #60's 58 (Ran: the two path lists
  compared).
- After #61 merges, #60 needs: an update merge of trunk_dev; a new manifest
  and a provenance-only re-check of that merge (protocol §5.4); and a green
  "build, vet and test" with `-timeout=20m` on every `go test` line.

## Sensitive-material handling

- All TLS material, Nomad tokens and ACL secrets were generated by the
  tests or by the probe in temporary directories, and removed afterwards.
- The probe never prints a token: it holds the bootstrap secret in a shell
  variable.
- The evidence holds test names, results and durations, first failure
  lines (temporary paths replaced), mutant logs, the probe's HTTP status
  codes and public CI step times.
- A scan of the evidence (Ran) is under "Report delivery".

## Remaining uncertainty and stop conditions

- A22-1's Nomad behaviour was observed on 2.1.1 only. 2.0.0 is Inference.
- The bring-up was not rerun with an offline image on this head (CI covers
  it).
- PR #61 had not merged at 06:40Z. When it merges, #60 needs
  an update merge of trunk_dev (the ruleset requires an up-to-date branch).
  That gives a new head, which needs a new manifest, a provenance-only
  re-check (§5.4) if the merge has no conflicts, and a green CI run with
  #61's limits.

## Confidence

- Provenance: high.
- Validation: high for the repairs (13 of 13 mutants, a probe, full suite
  equal to base) and for A22-1 (real Nomad). Medium for CI timing.
- Implementation: high that the HTTPS lock and the pin hold, as before.
  The one gap is in the upgrade's migrated-host verification.

## Effect status

No repair, commit, push, PR edit, PR comment, review, merge or CI rerun.
Nothing outside this container changed. A disposable Nomad agent on
127.0.0.1:24646 to 24648 ran for the probe and was stopped, and its data
folder was removed. A `nomad logmon` process that the full suite left
behind in this container was stopped.

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/nomad-acl/22-pr60-reaudit.md`;
its sha256 is in the delivery message. Evidence checksums are in
`22-pr60-reaudit-evidence/SHA256SUMS.txt`.

Before publishing, I scanned the evidence for these (Ran):
- email addresses and user@host names;
- IP addresses other than 127.0.0.1 and 192.0.2.1;
- Nomad SecretIDs and tokens;
- private keys and certificates;
- UUID-shaped values.

What it found:
- the UUIDs are GitHub's runner temp-folder names and worker ID in the
  public CI log;
- the checkout's credential header, which GitHub prints as `***`;
- the bootstrap secret's variable name in the probe script, which never
  prints its value;
- PEM markers in the CA-loader probe's source, which makes its keys at run
  time and holds no key material.

Nothing needed redacting. The full-suite summary lists only failing and
skipped tests, so it holds no subtest named after a user or host.

## Final verdict

**BLOCK**

To close it:

- A22-1: the anonymous-policy request in `inspect_migrated`, with one
  fake-host case (or narrow the contract text, which I do not recommend).
- Then a diff-only check of that commit. A full re-audit is not needed.
- Before the merge: #61 merged, #60 updated onto it, and a green "build,
  vet and test" on that head.

The Fable red-team can start on `dfb2873` now. A22-1 does not touch the TLS
design, and the red-team should cover the fixed head's migrated path too.
