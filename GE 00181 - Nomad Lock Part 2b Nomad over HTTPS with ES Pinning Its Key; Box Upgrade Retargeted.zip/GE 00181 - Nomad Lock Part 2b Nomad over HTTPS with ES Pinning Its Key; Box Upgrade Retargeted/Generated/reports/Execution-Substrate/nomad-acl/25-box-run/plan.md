# PR #60 box run: Nomad over HTTPS on the Remote Alpha box (plan, ready at merge)

Written 2026-11-25 ~09:00Z by the part 2b writer thread, on the coordinator's
08:33Z note ("Plan the #60 box run now so it's ready when the merge lands").
It replaces the outline in `../11-part2b-nomad-https.md` section 11.

## 1. When

After #60 merges into `trunk_dev`, in a box turn the coordinator hands out,
under David's bundled box-run approval (2026-11-24 04:23Z). Through a Remote
Control session on David's Mac, as for #54 (`es-box-upgrade/07-box-run/`).

The box must still be in the `locked-http` shape: ES `16cbf73` (#54's run,
2026-11-24 19:33Z), `nomad.hcl` after the host-network repair (22:17Z,
SHA-256 `ea333055…5163`), no `/etc/nomad.d/tls`. Any box change to
`nomad.hcl`, `es.json` or the ES binaries before this run makes the check
refuse, naming the part, and nothing changes.

## 2. Files

| File | What |
|---|---|
| `box-2b-run.sh.in` | the orchestration script, with `@COMMIT@` for the merge commit |
| `brief.txt.in` | the Remote Control brief, same rules as the #54 brief |
| `make-brief.py` | `python3 -I -B make-brief.py <merge sha> <new folder>` writes `box-2b-run.sh` and `brief.txt` with the commit, the script's SHA-256 and size |
| `local-harness/` | the stand-ins the script was tested against (section 5) and their outputs |

At merge: run `make-brief.py` with the merge commit into `run-<short>/`,
then start Remote Control with that `brief.txt` as the instructions.

## 3. Phases

One SSH call per phase, `bash -s -- <phase> [dir]`, each ending with
`===== done =====` (a phase runs in a subshell, so `done` follows even a
refusal; the script on standard input is never read by a phase).

| Phase | Changes the box? | What it shows |
|---|---|---|
| `build` | no (a new `/tmp/es-upgrade.XXXXXX`) | fresh clone at the merge commit, clean; the upgrade's unprivileged `build` with go1.26.5 |
| `check <dir>` | hands `<dir>` to root | **refuses unless nobody but root can change the checkout** (red-team RT60-2): `/tmp` root:root 1777, `<dir>` root:root 0700, every entry root:root and not group- or other-writable, no symbolic link under `scripts/`. Then box-checks row 6, the Vault ownership find, and the upgrade's read-only `check` (expect `shape: locked-http`, `result: ready`, five changes, no blocker) |
| `apply <dir>` | **yes, once** | the same root-only refusal, then the upgrade's `apply` under `systemd-run` (survives a dropped SSH session), waits up to 8 minutes, prints the unit's journal and `summary.json` |
| `status [unit]` | no | after a drop: waits for the unit (or any `es-upgrade-*`) and prints the same |
| `verify <dir>` | no (the ACL check's probe tokens only) | healthcheck steps 1, 2 and 4; the upgrade's `check` again with a one-line result (expect `shape=https result=nothing to do blockers=0 exit=0`); anonymous HTTPS answers (leader 200, `/v1/jobs` 403, `/v1/acl/policy/anonymous` 404, `/v1/agent/self` 403); plain HTTP refused; a TLS 1.2-only client refused (curl exit 35); `nomad_tls_identity.py check` (ES's own handshake: TLS 1.3, name, pin, days left); `nomad_acl_setup.sh check` and `placement` over HTTPS with `NOMAD_CACERT`; the TLS folder's owners and modes, the certificate's subject, SANs and end date, `openssl verify`, the key's SHA-256 on disk against `es.json`'s pin; `nomad.hcl`'s hash and `tls` block; `es.json`'s Nomad keys; the installed binaries' build info against the commit; journals (redacted) |
| `submit <dir>` | one ordinary ES run | AGS publish of a tiny static script, one ES submit, terminal status with exit 0, the argument in the log; the observer token listing ES's jobs before and after over HTTPS (the `list-jobs` fix live: 200 both times, exactly one new job). Reads Nomad's address and CA from `es.json`, so it also works on a rolled-back box |
| `rollback <dir>` | yes, only when needed | refuses on a healthy box (all ten services active and ES/AGS answering 200), refuses unless the newest backup is this commit's and its `summary.json` says `applied`; then the upgrade's own `rollback` under `systemd-run` and the health again |

Tokens never reach a command line: the observer token goes from its
root-only file into the Python's environment inside a root shell. Journal
output has UUIDs and token-shaped strings redacted.

## 4. Decision rules in the brief

- Step 4 (`check`): go on only on `check exit=0` with `"result": "ready"`;
  `"result": "nothing to do"` skips the apply; anything else stops the run
  with nothing changed.
- Step 5 (`apply`): once, never again, even after a drop; `status` until
  `finished: no matching unit is running`.
- Steps 6 and 7 (`verify`, `submit`) run whenever the check passed.
- Step 8 (`rollback`) only if the apply said `applied` **and** verify shows
  a service not active or an ES/AGS endpoint not answering 200. The phase
  checks the same itself. A failed submit on a healthy box is reported, not
  rolled back: the apply's own checks (ES's handshake, the lock, placement)
  passed, so a submit failure needs diagnosis first. Alpha testing is
  paused, so a box that answers but does not run jobs for a few hours costs
  nothing; a later box turn can roll back with
  `rollback --backup-dir <backup>` if the diagnosis says so.

Why an automatic rollback at all: Remote Control on the Mac takes follow-up
instructions only while answering a message David wrote in the thread, so
every fallback has to be in the first brief, and the box must be returned
to a working state.

## 5. Tested here (Ran, 2026-11-25 ~08:45Z)

Against local stand-ins in the cloud container (`local-harness/`), with the
box's IP on loopback, the script's `SUDO` replaced by `env` (the only
change), fake `systemctl`, `journalctl` and `systemd-run` on `PATH`, a fake
checkout with stub `remote_alpha_upgrade_es.sh` and `nomad_acl_setup.sh`
and the **real** `nomad_tls_identity.py`, Nomad's TLS material issued by the
setup's own `nomad_tls_issue`, and `mock.py` serving a TLS 1.3-only Nomad
with that material plus mTLS ES and AGS stand-ins that unpack the published
tar and run its script:

- `check`: chown and chmod, root-only line, upgrade check, `check exit=0`.
- `apply` refuses before `systemd-run` for a file another user owns, a
  symbolic link under `scripts/`, and a 0755 folder; a bad folder argument
  is refused. On success it runs the upgrade's `apply` through
  `systemd-run`; `wait_unit` waits for a running unit (15 s) and reports
  `finished`.
- `verify`: every line as expected, among them
  `upgrade check: shape=https result=nothing to do blockers=0 exit=0`,
  the five HTTPS answers, TLS 1.2 refused (curl exit 35), the real identity
  check `key=pinned`, `pin: equal`; with a wrong pin in `es.json` the
  identity check exits 1 and the script prints `pin: DIFFERENT`.
- `submit`: publish, submit, terminal exit 0, the argument's bytes in the
  log, the observer list 200 before and after with one new job; the token
  appears in no log or call record.
- `rollback`: refuses on a healthy box, on a `rolled_back` summary, and when
  the newest backup belongs to another commit; on an unhealthy box with an
  `applied` summary it runs the upgrade's `rollback --backup-dir <that
  backup>` through `systemd-run`.
- Real `sudo -n bash -c '... exec python3 -I -' <<'PY'` inside a subshell
  whose input is `/dev/null`: the heredoc reaches Python and the exported
  variable is set.
- `make-brief.py`: the embedded script equals the written one byte for
  byte, no placeholder left, a short commit refused.

Not tested here: the real upgrade (its own tests cover it, the real-Nomad
one included), systemd and the journal, the box's own `sudo` policy, and the
build on the box (same as #54's, which passed).

## 6. After the run

- Report: `run-<short>/` with the Mac session's outputs and a short
  `box-run-report.md` (what changed, backup folder, every end check).
- Archived-Runbooks PR: a History line in "Governed Execution Remote Alpha
  Claude Access", and the note that Nomad's API on the box is now
  `https://127.0.0.1:4646` with `NOMAD_CACERT=/etc/nomad.d/tls/ca.pem`; any
  later box procedure that calls Nomad (PR 12's live checks among them) must
  set both. The Healthcheck runbook reads no Nomad address, so it needs no
  change.
- Box state line in `project-context/state.md`.

## 7. Follow-ups from the red-team (24-pr60-redteam.md)

- **RT60-2** (the upgrade trusts its own checkout): for this run the
  orchestration enforces it (section 3, `check`, `apply`, `rollback`). The
  upgrade itself gets the same refusal in **its own small PR, started right
  after #60 merges** (my call: it is independent of the box run and of
  RT60-1, and small enough to audit alone): `check`, `apply` and `rollback`
  refuse unless the upgrade's checkout (its own file, `scripts/`, every
  script it runs and the folders above them up to the clone) is root-owned
  and not group- or other-writable, with tests for each refusal.
- **RT60-1** (Nomad gossip unencrypted, a local phantom raft member): its
  own PR **after #60 merges and this box run passes**: a Nomad gossip
  encryption key issued by the setup (root-only), referenced from the
  managed `nomad.hcl`, the example config and every real Nomad in the
  tests, and moved onto the box by the upgrade path (a new shape after
  `https`), with a regression test that the managed config carries a key.
