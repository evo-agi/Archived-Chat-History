# Nomad lock, part 2b: Nomad over HTTPS, ES pins its server key

Branch `claude/project-thread-9slgp8`, draft PR #60 into `trunk_dev`
(base `bf5a760`; the work was done on `2ca76cd`, section 10). Part 1 and part 2a of the lock merged as PR #31
(`0842983`). This is part 2b of the infra audit item D2: Nomad's API on
loopback moves from plain HTTP to HTTPS (TLS 1.3 only), and ES sends its
Nomad token only to the server whose certificate key it pins. It closes the
known limit #31 recorded ("Nomad's API stays plain HTTP on loopback until
part 2b": a local process that binds `127.0.0.1:4646` while Nomad is down
could receive ES's token), which the whole-trunk red-team listed as RT-4
(#48 added the interim port-holder guard, which stays as a second guard).

Since the pause on 2026-11-24 the branch also carries, at the coordinator's
direction (2026-11-25 01:47Z and 01:56Z):

- the merge of `trunk_dev` `2ca76cd` (#48 to #57), with the placement check
  of #57 working over HTTPS (section 2, "Merge");
- the observer token's `list-jobs` fix, with a real-Nomad test (section 7);
- the Remote Alpha box upgrade (`scripts/remote_alpha_upgrade_es.py`, #54)
  retargeted from the pre-lock box to this change: it takes the box from
  "locked, plain HTTP" to "HTTPS", detects the host's shape and refuses
  anything else, is a no-op on a migrated box, and is tested against a real
  Nomad with the real `nomad_acl_setup.sh` (section 8);
- PR 12's reliable-submit Nomad provider held to TLS 1.3, like ES's own
  client (section 4);
- the two findings from the automated review of #31 (section 6).

Every statement is **Ran** (executed, output seen), **Read** or
**Inference**.

## 0. Commits

| Commit | What |
|---|---|
| `6f23f9a` | Part 2b. Written and validated on the #31 branch, carried onto `0842983`. One conflict, in `es/app/nomad_supported_config_test.go`: both #31's agent-version check and part 2b's TLSConfig check kept. |
| `9545fc2` | The two review findings (section 6). |
| `3ef8a75` | Merge of trunk_dev `6dbeaeb` (PR #38). No conflicts; the PR's `^[-+]` lines were unchanged by it (Ran). Pushed; the branch stopped here on 2026-11-24. |
| `0b3e913` | Merge of trunk_dev `2ca76cd` (#48 to #57), 15 conflicts resolved (section 2, "Merge"). |
| `ae2bff7` | Observer token may list ES's jobs (section 7). |
| `d43eafb` | Box upgrade retargeted to HTTPS (section 8). |
| `d9d0570` | The upgrade refuses a build of the named commit that is not the payload's on a migrated box (closes the one surviving mutant, section 8). |
| `2db651d` | PR 12's operational Nomad provider requires TLS 1.3 (section 4). |
| `d834f73` | Part 2b's code meets three guards that came with the merge (section 9). |
| `d8fd9d2` | Docs: what the observer policy means for the old checkout after a rollback (section 8). |
| `f505f72` | Merge of trunk_dev `bf5a760` (#58), no conflicts (section 10). |
| `dfb2873` | Audit 20 and 21 repairs: strict CA-file loader in ES, tests for five refusal checks no test pinned (section 13). |
| `fe5119b` | Audit 22 repair (A22-1): the upgrade's check of a migrated host, and its verification after apply, refuse an anonymous Nomad policy (section 14). |
| `977b172` | Merge of trunk_dev `e2af4b2` (#61, the gate's 20-minute time limit), no conflicts, no file in common (section 14). |

## 1. Outcome

- **Nomad serves HTTPS and RPC over TLS 1.3 only.** The supported setup
  (`scripts/70_linux_setup.sh`) writes a `tls` block into the managed
  `/etc/nomad.d/nomad.hcl` and issues the certificate. The example config
  and every real Nomad the tests start use the same block, byte for byte (a
  test compares them).
- **The certificate can only come from setup.** Setup issues a P-256 server
  certificate for `server.global.nomad`, `localhost`, `127.0.0.1` and `::1`
  (825 days) from a CA with path length 0 whose key is deleted right after
  signing, so nothing else can ever chain to `ca.pem`. It keeps sound
  material with at least 30 days left and reissues otherwise.
- **ES trusts only that CA, verifies the name, and pins the key.** New ES
  config fields `nomad.server_name`, `nomad.root_ca_file` and
  `nomad.server_spki_sha256`; `nomad.base_url` must be
  `https://<loopback IP>:<port>`. ES connects with TLS 1.3 only, verifies the
  chain against the configured CA alone for the configured name, and then
  requires the pinned SubjectPublicKeyInfo hash. A certificate the same CA
  signed with any other key fails the handshake before ES sends anything.
- **Scripts and the ACL tool trust only `NOMAD_CACERT`.** Every curl call
  goes through one helper (`nomad_curl`: `--proto =https --tlsv1.3 --cacert
  "$NOMAD_CACERT" --capath /dev/null --noproxy '*'`); the Python openers use
  a TLS 1.3 context built from that CA only. All refuse an `http://` address
  and a missing or symlinked CA file.
- **Readiness makes ES's checks against the running Nomad.** New
  `scripts/internal/nomad_tls_identity.py check` (called by submit
  readiness once Nomad is ready) does the same handshake ES does, requires
  `nomad.base_url` to be `NOMAD_ADDR`, and refuses a certificate with fewer
  than 14 days left.
  The posture check also requires the agent to report HTTP and RPC TLS, TLS
  1.3, server-name verification and no RPC upgrade mode.
- **Supported-local setup observes the pin before any effect** and writes
  it into `es.json`; the renderer refuses to write `es.json` without one.
- **The observer token can list ES's jobs** (`list-jobs` in `es-submit-v1`),
  which the PR 12 box run needed; it still cannot register, plan, stop or
  scale a job, or list jobs in another namespace (real Nomad, section 7).
- **The placement check of #57 runs over HTTPS**, with `--ca-file`, from
  `nomad_acl_setup.sh placement` too, and passes against a real HTTPS Nomad
  on the supported client config.
- **The box can be moved to this change by one tested script.** The #54
  upgrade now goes from the box's current shape (ES `16cbf739`, Nomad
  locked on plain HTTP) to the target shape (ES at the named commit, Nomad on
  HTTPS, `es.json` pinned). It recognises exactly those two shapes from four
  parts read separately, refuses anything else naming each part's state,
  does nothing (and verifies in place) on a migrated box, and rolls itself
  back on any failure. A test runs it against a real Nomad started on the
  box's own `nomad.hcl`, with the real `nomad_acl_setup.sh` run as root.
- **Every Nomad caller in ES speaks TLS 1.3 only**, including PR 12's
  reliable-submit provider (not yet constructed outside tests).

## 2. What changed

**Nomad configuration** (setup heredoc, `.examples/config/nomad.hcl`, test
harness `supportedNomadTLSBlock`):

```hcl
tls {
  http = true
  rpc  = true

  ca_file   = "<dir>/ca.pem"
  cert_file = "<dir>/server.pem"
  key_file  = "<dir>/server-key.pem"

  verify_server_hostname = true
  verify_https_client    = false
  tls_min_version        = "tls13"
}
```

**Issuance** (`scripts/70_linux_setup.sh`, region `# BEGIN nomad_tls` …
`# END nomad_tls`, which the tests run on their own):

- `nomad_tls_issue <dir>`: in a private work directory, a P-256 CA
  (`basicConstraints=critical,CA:TRUE,pathlen:0`, `keyUsage=keyCertSign`,
  825 days) signs a P-256 server certificate (`CA:FALSE`,
  `digitalSignature`, EKU `serverAuth,clientAuth`, SAN
  `DNS:server.global.nomad,DNS:localhost,IP:127.0.0.1,IP:::1`, 128-bit
  random serial). The CA key is removed, the chain verified for
  `sslserver`, then the key, certificate and CA are moved into place in that
  order (a reader that sees the new CA finds the certificate it signed).
  Every step stops the subshell on failure; the work directory is always
  removed.
- `nomad_tls_material_ok <dir>`: all three files regular, not symbolic
  links and owned by the caller; key mode 0600; chain verifies; at least
  `NOMAD_TLS_RENEW_DAYS` (30) left; each of the four names matches (one
  `openssl x509 -checkhost`/`-checkip` per name, because openssl honours
  only the last `-checkip`); the certificate's public key is the key's.
- `nomad_tls_spki_sha256 <cert>`: the pin, `openssl x509 -pubkey | openssl
  pkey -pubin -outform DER | openssl dgst -sha256`.
- `nomad_tls_as_root <function> <args>`: runs one of them with `sudo bash
  -c`, so the key is created and read only by root.
- `install_nomad_tls_material` (outside the region): keep or reissue;
  reissue marks the Nomad config changed, so Nomad restarts. `/etc/nomad.d/tls`
  is root:root 0755.
- Next steps print all four ES values with the pin; a run that issued new
  material says so and asks for the pin update and an ES restart.

**ES** (`es/config/config.go`, new `es/admission/nomad_tls.go`,
`es/admission/submit.go`):

- `NomadConfig` gains `ServerName`, `RootCAFile`, `ServerSPKISHA256`.
  Validation: `base_url` https with an IP literal that is loopback, explicit
  port 1 to 65535 without leading zeros, no user, path, query, fragment or
  zone; `server_name` a lowercase DNS name that is not an IP;
  `root_ca_file` a clean absolute path; the pin 64 lowercase hex characters.
  Any of the three new fields makes submit "configured".
- `newNomadTLSConfig`: `MinVersion` TLS 1.3, `RootCAs` from the CA file only
  (regular file, at most 1 MiB, only PEM `CERTIFICATE` blocks without
  headers, at least one, nothing else but white space), `ServerName` from
  config, and `VerifyConnection` comparing SHA-256 of the leaf's
  `RawSubjectPublicKeyInfo` with the pin (after Go verified chain and name).
  It is built once in `newNomadClient`, so startup refuses an unusable CA
  file or pin.
- `newNomadTransport(tlsConfig)`: the existing no-proxy clone of the default
  transport, now with that TLS config. Redirects stay refused.
- A TLS failure is a transport failure: the per-submit access check refuses
  with `503 execution_runtime_unavailable` ("execution runtime is
  unavailable") before any token leaves ES.

**Scripts**:

- `scripts/internal/nomad_acl.sh`: `nomad_curl` (above); `nomad_api_get` and
  `nomad_acl_state_check` use it. `nomad_runtime_posture_check` also requires
  `TLSConfig.EnableHTTP`, `EnableRPC`, `TLSMinVersion == "tls13"`,
  `VerifyServerHostname` and `RPCUpgradeMode == false`; its line ends
  ` tls=1.3`.
- `scripts/internal/nomad_acl.py`: `Nomad(address, ca_file)` requires
  `https://127.0.0.1:<port>` or `https://[::1]:<port>` and a regular CA
  file; new required `--ca-file` for `provision` and `check`.
- `scripts/nomad_acl_setup.sh`: `NOMAD_ADDR` defaults to
  `https://127.0.0.1:4646`, `NOMAD_CACERT` to `/etc/nomad.d/tls/ca.pem`;
  every tool call passes `--ca-file`.
- `scripts/internal/nomad_tls_identity.py` (new, standard library only):
  `check <es-config> <nomad-addr>` and `pin <nomad-addr> <ca-file>
  <server-name>`; both only complete a handshake, neither sends a request.
  A small DER walker extracts the SPKI (Python's `ssl` exposes the
  certificate only as DER).
- `scripts/internal/bringup.sh`: leader and readiness requests through
  `nomad_curl`; the readiness Python takes `NOMAD_CACERT`; the ES submit
  config check requires the three new fields and an https `base_url`. New
  `check_es_nomad_identity_once` runs `nomad_tls_identity.py check`;
  `scripts/10_health_check.sh` calls it after Nomad readiness (so a Nomad
  that is still starting is waited for first, and a stopped Nomad still
  reports `nomad: leader request failed`) and before the Docker checks.
- `scripts/01_bringup.sh`, `scripts/10_health_check.sh`: full profile
  requires a readable `NOMAD_CACERT`; the ACL provision passes `--ca-file`.
- `scripts/72_supported_local_setup.sh`: `SUPPORTED_LOCAL_NOMAD_CACERT`
  (default `/etc/nomad.d/tls/ca.pem`); the preflight refuses a missing or
  symlinked CA, then observes the pin with `nomad_tls_identity.py pin`
  (before the ACL state check and before any effect); `es.json` gets
  `server_name`, `root_ca_file` and the pin; `env.sh` exports
  `NOMAD_CACERT`. The renderer refuses an empty or malformed pin.
- `scripts/internal/supported_local_proof_projection.py`
  (`fetch-node-details`): https only, TLS 1.3, CA from `NOMAD_CACERT`.
- `remote_alpha_runtime_security_boundary_check.sh` and
  `remote_alpha_normal_shell_runtime_image_check.sh`: https address and CA
  defaults. `remote_alpha_runtime_identity_helper_summary.sh` is unchanged:
  it uses the operator's environment and sends no token.
- `.examples/config/es*.json`: https `base_url`, `server_name`,
  `root_ca_file`, and a 64-zero pin placeholder (it matches no key, so a
  copied example fails readiness with the observed pin printed, rather than
  passing).

**Merge with `trunk_dev` `2ca76cd`** (`0b3e913`; Read and Ran):

- `scripts/internal/nomad_acl.py`: trunk's tool (leader wait, bootstrap
  retry, #48's port-holder guard, #57's `placement`) over part 2b's HTTPS.
  The port-holder guard stays as a second guard and runs before the TLS
  handshake, so a holder of Nomad's port sees no ClientHello, let alone a
  token; the opener refuses `http://` as well. `--ca-file` is required on
  `provision`, `check` and `placement`.
- `scripts/nomad_acl_setup.sh`: `NOMAD_CACERT` passed to every tool call,
  `placement` included; the next-steps text names ES's `root_ca_file`.
- `scripts/70_linux_setup.sh`: `nomad_curl` (TLS 1.3, Nomad's CA only) and
  #48's `require_nomad_listener` (now for `https://127.0.0.1:<port>`) both
  kept.
- Bootstrap, placement, supported-config and wrapper tests moved to TLS
  stand-ins; the port-holder stand-in counts TLS ClientHellos, so the tests
  show a holder sees no handshake. `TestRealNomadOffersOnlyTheLimitedDockerDriver`
  runs `placement` against a real HTTPS Nomad on the supported client
  config and requires `nomad placement: ok (host-mode network on …`.
- PLANS.md: trunk's structure kept. The TLS fact is edited in place under
  "Current-State Facts To Preserve During Redesign", and the existing
  bullet about the Remote Alpha upgrade is rewritten in place for the
  retarget. No dated entry; the closed `.docs/history/plans-record.md` is
  untouched. PLANS.md is 145,466 bytes (cap 150,000).
- `configuration.md`: the port-holder guard is described as the second
  guard behind HTTPS.

**Docs**: `configuration.md` (new "Nomad HTTPS" section; field lists;
requirements; the plain-HTTP known limit replaced), host qualification
(requirement and procedure; the procedure's node listing now uses the
observer token, which it needed since part 1), lifecycle contract (TLS
bullet, and a correction: a transport failure in the access check refuses
as "execution runtime is unavailable", not with the access-control message,
which part 1's text claimed), the three runbooks, PLANS.md (in place), and
`remote_supported_host_alpha.md` (the upgrade, section 8).

## 3. Why these choices

- **CA and pin together.** The CA's key no longer exists, so the CA alone
  already admits one certificate. The pin makes ES independent of how the
  CA file is managed (a CA file replaced by root with another CA still
  cannot impersonate Nomad to ES), and the CA lets the scripts and the nomad
  CLI verify Nomad without knowing the pin. ES checks both.
- **Name, not IP, for ES.** Nomad's RPC with `verify_server_hostname`
  requires `server.<region>.nomad` in the certificate, so that name is
  always there; ES verifies it and dials the IP in `base_url`, so ES never
  resolves a name. The scripts and the ACL tool verify the loopback IP they
  dial, which is why the certificate also names `127.0.0.1` and `::1`.
- **`clientAuth` in the EKU**: Nomad uses the same certificate when its
  client agent dials its server over RPC. Checked: with `serverAuth` alone
  (mutant X8) the server refuses its own client ("x509: certificate
  specifies an incompatible key usage") and no node ever becomes ready.
- **`verify_https_client = false`**: HTTP callers authenticate with ACL
  tokens (part 1). Client certificates for ES, the scripts and operators
  would add a second credential to provision without closing anything the
  pin and ACLs leave open on loopback.
- **TLS 1.3 only** everywhere: Nomad's `tls_min_version`, ES's
  `MinVersion`, curl `--tlsv1.3`, Python `minimum_version`.
- **14 and 30 days.** Readiness refuses below 14 days so an expiring
  certificate shows up while the operator can still rerun setup, which
  reissues below 30 days.

## 4. PR 12's reliable-submit Nomad provider

When part 2b was written, PR 12 was unmerged, and this report listed what
its Nomad client would need. PR 12 merged (`a60c216`); its operational
provider (`es/admission/reliable_submit_operational_provider.go`,
`prepareExchange`) already dials only the loopback target, follows no
redirect, uses no proxy, verifies Nomad's chain against its own root pool
for the realm's host name and requires the realm's SPKI pin, and its
constructor refuses a missing pin, root pool or host (Read). It accepted
TLS 1.2, though.

- `2db651d` raises its floor to TLS 1.3, the one version the supported Nomad
  serves and every other Nomad caller uses. The supported Nomad never
  offered less, so nothing that worked changes (Inference from the config:
  `tls_min_version = "tls13"`).
- New test `TestOperationalProviderSendsItsTokenOnlyOverTLS13`: against a
  Nomad stand-in with the pinned key that offers only TLS 1.2, the exchange
  fails as `OperationalIO` and the stand-in receives no request, so neither
  token nor body leaves ES; the same stand-in offering TLS 1.3 receives the
  request with the token over TLS 1.3. With the floor put back to TLS 1.2
  the test fails (`requests=1`, Ran).
- The provider is still constructed only by tests (Read: no other caller of
  `newOperationalLoopbackProvider`). Whoever wires it to configuration must
  hand it a host, a pin and roots, or the constructor refuses; the natural
  source is `nomad.server_name`, `nomad.server_spki_sha256` and
  `nomad.root_ca_file`, which this PR adds.

## 5. Tests

New:

| Test | Shows |
|---|---|
| `TestSetupIssuesNomadTLSMaterialAsSupported` | every certificate property above; CA key gone (work directory empty); only the three files, modes 0755/0644/0600; verifies for all four names; shell pin equals ES's; a reissue changes the key and CA |
| `TestSetupIssuesNomadTLSMaterialAsRoot` | `nomad_tls_as_root` writes root:root files, key unreadable by others, root keeps it, another user does not |
| `TestSetupReissuesNomadTLSMaterialThatIsNotSound` | key mode, symlink, missing CA, CA or key from other material, renewal window, and each missing name (with a control holding every name) make setup reissue |
| `TestNomadTLSIdentityChecksWhatESChecks` | `check` and `pin` against a TLS stand-in: success line; another key, malformed pin, another CA, missing CA, another name, http or host-name address, address other than `NOMAD_ADDR`, TLS 1.2-only Nomad, a 10-day certificate; no request is ever sent |
| `TestSupportedLocalFullReadinessChecksNomadsPinnedIdentity` | `10_health_check.sh` prints the identity line after Nomad readiness; it refuses an ES config with another key, CA, name or address before any Docker check, without `submit-ready: true` |
| `TestSubmitRefusesANomadOtherThanThePinnedOne` | real Nomad, real ES: another pin, CA or name refuses the submit with 503 and registers no job |
| `TestNomadACLToolTrustsOnlyNomadsCA` | the ACL tool refuses http, a host name, no/missing/symlinked/non-certificate CA, another CA, TLS 1.2, each before any request |
| `TestNomadShellHelpersTrustOnlyNomadsCA` | the same for the shell helpers, plus the token arriving with the right CA |
| es/admission `TestNomadClientSendsItsTokenOnlyToThePinnedNomadOverTLS13`, `TestNewNomadClientRefusesWithoutAUsableRootCAOrPin`; es/config `TestNomadConfigRequiresHTTPSOnLoopbackWithAPinnedServerKey`, `TestNomadTLSFieldsAloneMakeSubmitConfigured` | ES's client and config rules |

Changed: supported-local setup refuses a missing or symlinked CA and a
certificate from another CA before any effect (real handshake against a TLS
stand-in); the posture check has seven new TLS refusal cases; the
proof-capture node fetch refuses missing CA, another CA and TLS 1.2; the
redirect and proxy tests now run against TLS stand-ins whose redirect target
presents a certificate from the same CA, so only the refusal to follow keeps
the token from it. Every real Nomad in es/app runs HTTPS with setup-issued
material, and every fake Nomad is a TLS stand-in with such material; the
`nomadHarness` raw-request helpers trust only the CAs of Nomads the process
started.

### Mutants

25 mutants against the part 2b code at `6f23f9a` (on `0842983`), each applied alone
to the test copy, run against the tests named, then reverted. All 25 were
killed by an
assertion failure (the runner marks a build or setup failure as invalid; none
was). Runner: `11-evidence/mutants2b.py`; output: `11-evidence/run-p2b-main.out`; logs: `11-evidence/logs/mutant-logs-6f23f9a.tar.gz`.

| Mutant | Change | Killed by |
|---|---|---|
| E1 | ES skips the key pin (`!= pin && false`) | `TestNomadClientSendsItsTokenOnlyToThePinnedNomadOverTLS13` |
| E1-e2e | same | `TestSubmitRefusesANomadOtherThanThePinnedOne` (real Nomad) |
| E2 | ES allows TLS 1.2 | `TestNomadClientSendsItsTokenOnlyToThePinnedNomadOverTLS13` |
| E3 | ES ignores `server_name` | `TestSubmitRefusesANomadOtherThanThePinnedOne` |
| C1 | config accepts `http` | `TestNomadConfigRequiresHTTPSOnLoopbackWithAPinnedServerKey` |
| S1 | shell helpers accept `http` | `TestNomadShellHelpersTrustOnlyNomadsCA` |
| S2 | posture check ignores TLSConfig | `TestNomadRuntimePostureCheckRefusesLoosenedDockerLimits` |
| T1 | ACL tool accepts `http` | `TestNomadACLToolTrustsOnlyNomadsCA` |
| I1 | identity check ignores the pin | `TestNomadTLSIdentityChecksWhatESChecks`, `TestSupportedLocalFullReadinessChecksNomadsPinnedIdentity` |
| I2 | identity check ignores expiry | `TestNomadTLSIdentityChecksWhatESChecks` |
| I3 | identity check ignores the address | both of the above |
| R1b | health check drops the identity check | `TestSupportedLocalFullReadinessChecksNomadsPinnedIdentity` |
| R2 | identity check before Nomad readiness | same |
| R3 | identity failure ignored | same |
| X8 | certificate without `clientAuth` | `TestRealNomadOffersOnlyTheLimitedDockerDriver` (no ready node) |
| L1 | supported-local preflight skips the pin | `TestSupportedLocalSetupLocksNomadBeforeProofEffects` |
| L2 | renderer accepts a missing pin | `TestRetainedResultAuditF1RenderedConfigConstructsConfiguredService` |
| X1 | material check ignores names | `TestSetupReissuesNomadTLSMaterialThatIsNotSound` |
| X2 | material check ignores the owner | `TestSetupIssuesNomadTLSMaterialAsRoot` |
| X3 | material check allows a symlink | `TestSetupReissuesNomadTLSMaterialThatIsNotSound` |
| X4 | material check ignores the renewal window | same |
| X5 | CA key kept | `TestSetupIssuesNomadTLSMaterialAsSupported` |
| X6 | no `::1` in the SAN | same |
| X7 | material check ignores the key mode | `TestSetupReissuesNomadTLSMaterialThatIsNotSound` |
| P1 | proof node fetch allows TLS 1.2 | `TestSupportedLocalProofNodeDetailLoopbackAdmission` |

Two mutants first survived and led to test changes: E1 initially did not
compile (an unused variable), so the runner now reports build failures as
invalid instead of killed; X2 (owner check removed) survived because the
non-root case already failed on the unreadable key, so the root test now
also checks that root does not keep material another user owns.

The round 04 repair's 9 mutants (A4 set, `11-evidence/mutantsA4.py`) give
the same results on this code as in report 05: 8 killed, A1c equivalent
(Ran, `run-p2b-main.out`).

## 6. Two findings from the automated review of #31

Marking #31 ready started an automated review of `d6fa837` that posted two
P2 comments after the merge. I checked both against the code (Read) and
both are real. Neither weakens the lock; both could leave setup stuck.

**R31-1: the setup script's leader wait accepted an empty leader**
(`scripts/70_linux_setup.sh`, `bootstrap_nomad_acl`).

- Before: `nomad_curl … /v1/status/leader | grep -q '"'`. Any quoted answer
  passed, including `""`, which Nomad returns while raft knows no leader
  (Inference: from the review, and bring-up's `wait_for_nomad_leader`
  already parses for a nonempty leader for this reason). A bootstrap sent
  then fails ("no cluster leader"), so setup stops; a rerun recovers,
  because the script resubmits its saved secret.
- I did not see `""` on a single-node Nomad 2.1.1: polling every 20 ms
  from start, and again after a restart, the first answer was already the
  leader (Ran). Multi-server clusters and leader loss are where it shows.
- Now: the answer must match `^"[^"]+"$`, the same check as bring-up's.

**R31-2: a bootstrap that never took effect blocked every rerun of the
tool** (`scripts/internal/nomad_acl.py`, `bootstrap_or_load_management`).

- Before: the tool writes its secret to the management token file, then
  calls bootstrap. If that call failed before Nomad installed the secret
  (no leader yet, a lost response), the file stayed, and every later
  `provision` read it, found no management token and refused. Its own
  message said "a rerun can finish or reuse it", which was not true; only
  deleting the file by hand recovered.
- Now: when the saved secret is not a working management token, the tool
  offers it to `/v1/acl/bootstrap` again. Nomad accepts a bootstrap secret
  only while its ACLs are not bootstrapped, or after an operator's reset
  procedure (Ran: a bootstrapped Nomad answers the retry with "bootstrap
  already done"; the reset case is Inference from Nomad's documented
  procedure). At that point anyone on loopback could bootstrap, so
  resubmitting a secret that never left the root-only file opens nothing.
  If Nomad answers "bootstrap already done", the tool refuses and keeps the
  file, which is the operator's; it removes the file only in the existing
  case where it wrote a fresh secret in this run. The setup script already
  behaved this way.
- Docs: the management token bullet in `configuration.md` now says both
  scripts bootstrap only once Nomad names a leader, that a rerun finishes a
  bootstrap that never took effect, and that a refusal leaves an existing
  file alone.

**Tests** (new file `es/app/nomad_acl_bootstrap_test.go`). The setup
script's `nomad_curl`, `nomad_token_curl` and `bootstrap_nomad_acl` now sit
between `# BEGIN nomad_acl_bootstrap` and `# END nomad_acl_bootstrap`, so a
test runs them on their own, as part 2b's TLS tests do for `nomad_tls`.
Until now nothing tested that bootstrap.

| Test | Shows |
|---|---|
| `TestLinuxSetupBootstrapsNomadACLOnlyOnceNomadNamesALeader` | against a TLS stand-in: while Nomad answers `""`, the bounded wait gives up with "no leader within 2s", sends nothing but leader requests and saves no secret; when the third answer names a leader, the requests are exactly leader, leader, leader, token/self, bootstrap, and the bootstrap carries the saved secret |
| `TestLinuxSetupBootstrapFinishesWithItsSavedSecret` | real Nomad with ACLs on and not bootstrapped, holding a saved secret Nomad never saw: setup bootstraps with it (Nomad then reports it as management) and a rerun keeps it; with another saved secret on that bootstrapped Nomad, setup refuses and leaves the file unchanged |
| `TestNomadACLToolRetriesABootstrapThatNeverTookEffect` | the same two cases for the tool's `provision` |

All three pass on Nomad 2.1.1 and 2.0.0 (Ran). So do `TestNomadACL*`,
`TestSupportedLocalSetupLocks*`, `TestRealNomadRefuses*` and
`TestSubmitRefusesANomadThatDoesNot*`, which run the tool's normal
bootstrap, and the static guard and docs tests (Ran).

**Mutants**: 6 of 6 killed (Ran; `11-evidence/mutantsCX.py`,
`mutants-cx.txt`, logs in `11-evidence/logs/`).

| Mutant | Change | Killed by |
|---|---|---|
| CX1 | leader wait back to `grep -q '"'` | `TestLinuxSetupBootstrapsNomadACLOnlyOnceNomadNamesALeader` |
| CX2 | leader pattern `[^"]*` (empty allowed) | same |
| CX3 | setup removes a loaded file on "already done" | `TestLinuxSetupBootstrapFinishesWithItsSavedSecret` |
| CX4 | tool refuses a saved secret without retrying (the old code) | `TestNomadACLToolRetriesABootstrapThatNeverTookEffect` |
| CX5 | tool removes a loaded file on "already done" | same |
| CX6 | tool retries with a new secret, replacing the file | same |

## 7. The observer token may list ES's jobs

The PR 12 box run found that the observer token gets 403 on
`GET /v1/jobs?namespace=es-submit-v1` (coordinator note, 2026-11-24 20:27Z).
Nomad's `list-jobs` is its own capability and `read-job` does not imply it.
No doc or design note says listing was meant to be refused; every consumer
at the time read one job by ID (Inference: an omission).

- `scripts/internal/nomad_acl.py`: `OBSERVER_POLICY_RULES` grants
  `list-jobs`, `read-job` and `read-logs` in `es-submit-v1`, with agent and
  node read as before. `provision` writes the rules on every run and keeps
  the tokens; `check` demands these exact rules, so a host provisioned
  before this change fails `check` until `provision` runs again
  (`configuration.md` says so).
- New `TestRealNomadObserverListsButCannotChangeESJobs` (real Nomad over
  HTTPS): the observer token lists and reads ES's job through the API and
  through `nomad job status`, and gets 403 for listing jobs in `default`,
  registering, planning, stopping and scaling; ES's job is the only job in
  any namespace afterwards; `check` passes. Without `list-jobs` it fails
  with HTTP 403 (Ran). Passes on Nomad 2.1.1 and 2.0.0 (Ran).

## 8. The box upgrade, retargeted to HTTPS

**Why in this PR.** After part 2b, `trunk_dev`'s ES refuses an `http://`
`nomad.base_url`, and `nomad_acl_setup.sh` defaults to HTTPS. The #54
script, written to take the box from its pre-lock state to "locked on plain
HTTP", would no longer have worked: its lock step targets a state the box
has left, it ran the ACL setup over plain HTTP, and the `es.json` it wrote
would be refused by the ES it installs. Its tests used a stub ACL setup and
would have kept passing. The coordinator decided (01:56Z) to retarget it
here, on two conditions: (1) it detects the host's current shape and refuses
anything it does not recognise, naming the shape, and the migrated state is
a clean no-op; (2) at least one test drives the real `nomad_acl_setup.sh`
against real Nomad over HTTPS. The full contract is in
`.docs/system_overview/remote_supported_host_alpha.md`, section "Remote ES
Upgrade And Nomad HTTPS", rewritten for this.

**Shapes (condition 1).** `check` and `apply` read four parts, each with its
own detector, and name a shape only when all four agree:

| Part | `locked-http` (the box now) | `https` (after apply) |
|---|---|---|
| `nomad.hcl` | the box's file after the lock and the 2026-11-24 host-network repair, by SHA-256 (`ea333055…5163`) | that file plus the setup's `tls` block, byte for byte |
| `/etc/nomad.d/tls` | absent | root:root 0755, exactly the three files, `nomad_tls_material_ok` passes |
| `es.json` | the box build's 49 key paths plus #54's four, `base_url` `http://127.0.0.1:4646` | the same plus `server_name`, `root_ca_file` and a pin equal to the key of the certificate on disk, `base_url` https |
| `es`, `es-runtime-support` | clean builds of `16cbf739` (by their Go build info) | the verified payload's builds of the named commit (build info and SHA-256) |

Anything else is refused and the refusal lists every part's state, for
example `pre-lock (Remote Alpha 0.7's config: ES PR #54's upgrade has not
run)` for the old `nomad.hcl`, `unknown (SHA-256 …)`, an `es.json` whose pin
does not match the certificate on disk, or binaries built from two commits.
TLS material left by an `apply` that was cut off before its rollback makes
the parts disagree, so it is refused rather than reused. On `https` for the
named commit, `check` and `apply` verify in place (leader over HTTPS,
`nomad_tls_identity.py check` with the installed `es.json`, anonymous job
list 403), write no backup, touch no service and report `nothing to do`.

**Root-path care.** The red-team will read this as root-path code. What it
keeps from #54: payload ownership, provenance and Go build-info checks; every
command in its own process group, ended and drained on timeout or signal;
signals during `apply` turn into a rollback; output loss never stops it.
New here:

- `nomad config validate` exits 0 with warnings when TLS files are
  unreadable or TLS is not configured; `apply` refuses those warnings.
- Running allocations block the run, checked without a Nomad token
  (`docker ps --filter label=com.hashicorp.nomad.alloc_id`).
- Every Nomad request after the restart goes over `--proto =https
  --tlsv1.3 --cacert <ca> --capath /dev/null`.
- `created.json` in the backup records the one path `apply` creates
  (`/etc/nomad.d/tls`); rollback refuses a backup whose `created.json` names
  anything else, and verifies the whole backup before it stops any service.
- The TLS material is issued by the setup's own `nomad_tls` functions,
  extracted from `scripts/70_linux_setup.sh` and run with `bash`; nothing
  reimplements them.

**Apply** (after a clean check of `locked-http`): back up `es.json`, both
binaries and `nomad.hcl`, record `created.json`; stop ES; issue the TLS
material and read the pin; validate the new `nomad.hcl`, stop Nomad, write
it, start Nomad, wait 90 s for a leader over HTTPS; run the real
`nomad_acl_setup.sh provision` (keeps the tokens, rewrites the policies, so
the observer gains `list-jobs`) and `placement` (120 s, both ES job shapes);
write `es.json` with the TLS keys after the new ES's `config.Load` accepts
it; install the binaries; start ES and verify (health, identity check, 403,
ACL `check`). Rollback puts every file back, removes `/etc/nomad.d/tls`,
starts Nomad and ES and requires a leader at the address the restored config
serves (plain HTTP). It does not change the ACL policies back: after a
rollback, the old checkout's `check` refuses the observer policy until its
own `provision` rewrites it, while this script accepts the rolled-back host
as `locked-http` (docs, `d8fd9d2`; the real-Nomad test runs `check` after
its rollback).

**Tests.** `scripts/remote_alpha_upgrade_es_host_test.go` was rewritten.
The fake-host tests run `check`, `apply`, the migrated no-op, automatic
rollback at each step (7 failure points), an interrupted apply, and damaged
backups, with fake `systemctl`, `curl`, `nomad`, `docker`, ACL setup and
identity check, and the real `nomad_tls_issue`. The refusal test has about
40 cases, among them every refused shape with each part named.
`scripts/remote_alpha_upgrade_es_test.go` covers `migrate_config` (the exact
keys added, their order, nothing else changed, rerun no-op, another pin
refused, and what it was not written for).

`TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` (condition 2) starts a real
Nomad agent on the box's own `nomad.hcl` (with `-config` overrides for the
data folder, free ports and TLS paths under the test folder), set up the way
#54 left the box: ACLs bootstrapped over plain HTTP, the token files in a
root-owned folder, the management token root's, and the observer policy
without `list-jobs`. It runs `check`, `apply`, the migrated `check` and
`apply`, and `rollback`, with `apply` running the real
`scripts/nomad_acl_setup.sh` through `sudo -n` as root and the real
`nomad_tls_identity.py`. It then shows that Nomad answers only over HTTPS,
that an anonymous job list gets 403, that the kept observer token now lists
ES's jobs, that the token files are unchanged, and after the rollback that
Nomad serves plain HTTP again and `check` sees `locked-http`. It skips only
off Linux, without `nomad`, or without passwordless `sudo`; CI has all
three, and CI fails any skip it does not list. Passes on Nomad 2.1.1 (14 s)
and 2.0.0 (13 s), with no agent left running (Ran).

**Mutants** (Ran; runner `11-evidence/upgrade-mutants.py`, output
`11-evidence/upgrade-mutants.txt`). Each applied alone to the test copy,
the named tests run, then reverted.

| Mutant | Change | Killed by |
|---|---|---|
| M1 | `nomad config validate` warnings ignored | `ApplyRollsBackOnFailure` |
| M2 | pre-lock `nomad.hcl` read as `locked-http` | `CheckRefusesWhatItWasNotWrittenFor` |
| M3 | shape taken from `nomad.hcl` alone | same |
| M4 | no no-op on `https` | `Apply` |
| M5 | rollback keeps `/etc/nomad.d/tls` | `Apply`, `ApplyRollsBackOnFailure` |
| M6 | no `provision` | `Apply` |
| M7 | ACL setup over plain HTTP | `Apply` |
| M8 | backup verified only after stopping services | `RollbackFailuresAreReported` |
| M9 | no identity check on `https` | `Apply` |
| M10 | pin not compared with the certificate on disk | `CheckRefusesWhatItWasNotWrittenFor` |
| M11 | running allocations ignored | same |
| M12 | `es.json` migrated with a wrong pin | `Apply` |
| M13 | a build of the named commit that is not the payload's accepted | `Apply` (after `d9d0570`) |
| M14 | TLS folder mode not checked | `CheckRefusesWhatItWasNotWrittenFor` |

M13 first survived in an equivalent form (box binaries read as `https`,
which the commit check already refuses). I replaced it with the real gap,
which also survived, and `d9d0570` adds the test case that kills it.

Real-only mutants show what condition 2 buys: each passes the stub-based
`TestRemoteAlphaUpgradeESApply` and fails
`TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` (Ran; runner
`11-evidence/upgrade-real-mutants.py`, output in the same `.txt`).

| Mutant | Change |
|---|---|
| R1 | observer rules without `list-jobs` |
| R2 | `placement` given the default CA path instead of `NOMAD_CACERT` |
| R3 | `provision` skips rewriting the observer policy |

## 9. Validation

All in the cloud container (Go 1.26.5, Nomad 2.1.1 and 2.0.0, Vault 2.2.2,
SPIRE 1.14.4, tests as an unprivileged user with passwordless `sudo`), Ran.
Runners and outputs: `11-evidence/run-p2bx.sh`/`.out` (full pass at
`d9d0570`) and `run-p2by.sh`/`.out` (second pass at the tip's bytes, with
base `2ca76cd` beside it); logs in
`11-evidence/logs/validation-logs-d8fd9d2.tar.gz`.

First pass, tree of `d9d0570`:

- Bring-up (`TestBringupScriptUpCheckDownFullProfile`, offline image): pass
  on Nomad 2.1.1 and on 2.0.0.
- Real-Nomad tests on Nomad 2.0.0 (`TestRealNomad|TestNomadACL|
  TestSubmitRefuses|TestSupportedLocalProofValidation|
  TestSubmitFlowUsesPlatformOwnedIdentity|TestSupportedNomad|TestNomadTLS|
  TestLinuxSetupBootstrap`): pass.
- Whole `es/app`: everything passes except three: the bring-up test
  (passes in its own run with the offline image above; the whole-package
  run has no such image), `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`
  (fails the same way on every base in this container), and
  `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget`
  ("Vault dev/test HTTPS listener did not appear" under full-suite load,
  after Nomad's TLS steps had passed; it passed 3 of 3 alone afterwards).
- Three guards that came with the merge failed on part 2b's code and are
  fixed in `d834f73`: `TestScriptsStartPythonInIsolatedMode` (#52: the new
  `nomad_tls_identity.py` shebang lacked `-I`),
  `TestRootScriptByNameOwnershipChangesStayCounted` (red-team item 5: three
  by-name mode changes for the TLS material, now counted with the reason the
  paths are root's) and `internal/testutil`'s
  `TestImportersNameRepositoryPathsFromTheRoot` (seven commands in the
  upgrade host tests without an absolute working directory).
  `TestStandingRulesKeepPlansAuthority` failed only because the container
  copy's git index was stale (it lists files through git); it passes with a
  current index.
- `es/admission/internal/reliablesubmit`: three failures, all on base too
  (second pass). `es/admission`: `TestOperationalRetainedAdmissionInputs`
  failed once under full-suite load (8 s); it passes 3 of 3 alone on head
  and on base, and in the second pass's whole-package run.
- `go vet ./...` for linux and darwin: clean.
- `-race` over whole `es/admission` exceeded 30 minutes (timed out in the
  PR 12 test `TestOperationalAdmissionDenialUnderAnEndedContextAnswersDenied`).
  That test alone under `-race` takes 55 s on head and 56 s on base
  (Inference: the package has outgrown the timeout on both; the whole base
  package was not run under `-race`). CI does not run `-race`.

Second pass, tree of `d8fd9d2` (fixes in; the container copies given a
current git index; base `2ca76cd` checked out beside it):

- Root package: pass. `internal/testutil`: pass. `go vet` linux and darwin:
  clean.
- `scripts`: 28 failures on head, every one also failing on base (base: 31;
  its 3 extra are mode-sensitive tests that see 0664 files in the base copy,
  an artifact of how it was extracted). All 16 upgrade tests pass, the
  real-Nomad one included, and so do the three guards above.
- Whole `es/admission`: pass (402 s), including
  `TestOperationalProviderSendsItsTokenOnlyOverTLS13`.
- `reliablesubmit`: the same three failures on head and base
  (`TestOperationalHandoffSchema4BinaryRefusesSchema5`,
  `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`,
  `TestSQLiteV3OldBinaryRefusesWithoutMutation`: production-source probes
  this container cannot provide).
- `-race`: `es/admission` tests matching `Nomad|TLS|TestOperationalProvider`
  pass (29 s); `es/config` passes.

Earlier, on the part 2b code alone (`6f23f9a`, report sections 5 and 6):
the same suites on Nomad 2.1.1 and 2.0.0, 25 of 25 TLS mutants and 6 of 6
review-fix mutants killed (`11-evidence/run-p2b-main.out`, `mutants-cx.txt`).

## 10. Identity

| | |
|---|---|
| PR head | `977b172a70604e78cd12c21998114888a766ebd9` (A22-1 repair `fe5119b` and the merge of trunk_dev `e2af4b2`, section 14) |
| tree | `0391c6fca4961f4f21593dbd0005f73eef4d73ee` |
| base (trunk_dev, merge-base) | `e2af4b27ad8ab443084c90bb9113ed1204fbdf69` |
| manifest v2 sha256 | `85b129642926ee51297cdaf339f74cf98c7efb7ac9363962d5ae5225d7c58251` |
| textual diff sha256 | `7b179f84987b3a6465e007a305dda2b9f0a2707370e7974a7ad464730da8d238` |
| files | 58 (the same paths as at `f505f72` and `dfb2873`) |

The re-audited head before that was `dfb2873` (tree `e9c9ca7b…`, base
`bf5a760`, manifest `b091699aeabefea43286596f31540d68504f572d95517ef9888ee5804e8fb0df`,
textual diff `5277305a…38ba`). The `977b172` manifest was taken the same way
as the ones below, against base `e2af4b2`: twice, byte-identical, with the
staged path set equal to its 58 paths (Ran). Evidence:
`11-evidence/manifest-v2-977b172.json`.

The audited head before the repairs was `f505f72` (tree `91745199…`,
manifest `e3904b35be2a3fdc6caea1360d7dbc33783ebccd7ce2c912466a5f72e2ac1d5e`,
textual diff `8823dbcd…c209`, +4681/-1094). The paragraphs below describe
how that manifest was taken. The `dfb2873` manifest was taken the same way:
twice, byte-identical, with the staged path set equal to its 58 paths (Ran).
Evidence: `11-evidence/manifest-v2-dfb2873.json`.

Manifest tool sha256 `c08597e2…a3ca` (verified against the project's copy),
run twice with HEAD reset to the base, the tip's bytes in the working tree,
upstream pinned to `origin/trunk_dev`; the two outputs are byte-identical.
The path set equals `git diff --name-only --no-renames bf5a760 f505f72`, and
every file's SHA-256 matches the tip's blob (Ran). Evidence:
`11-evidence/manifest-v2-f505f72.json`.

trunk_dev moved to `bf5a760` (#58, the TLS status collector: three files,
none of them this PR's) while this PR was being opened. The merge had no
conflicts; this PR's `^[-+]` lines are identical before and after it, and the
file list and every file hash equal the manifest taken at `d8fd9d2` on
`2ca76cd` (`11-evidence/manifest-v2-d8fd9d2.json`, sha256 `24dbde40…5db6`;
only its `head` field differs). The validation in section 9 ran on the
`d8fd9d2` bytes; CI runs on `f505f72`.

## 11. Box run plan

The full plan, the script, the brief and the generator that fills them with
the merge commit are in `25-box-run/` (`plan.md`, written 2026-11-25 on the
coordinator's 08:33Z note; it replaces the outline that stood here). In
short: after the merge, in a box turn, through Remote Control on the Mac,
one SSH call per phase as for #54, with `wait_unit` fixed:

1. **build** (unprivileged): fresh clone of the merge commit, the upgrade's
   `build` with go1.26.5.
2. **check**: hand the folder to root, then refuse unless nobody but root
   can change the checkout (red-team RT60-2, enforced by the orchestration
   for this run), then the upgrade's `check`. Expect `locked-http`,
   `ready`, five changes, no blocker.
3. **apply**, once, under `systemd-run`.
4. **verify** (read-only): healthcheck steps 1, 2 and 4; the upgrade's
   `check` again (`https`, `nothing to do`); Nomad's anonymous HTTPS
   answers, plain HTTP and TLS 1.2 refused; ES's own handshake
   (`nomad_tls_identity.py check`); `nomad_acl_setup.sh check` and
   `placement` over HTTPS; the certificate and the pin against `es.json`;
   binaries' build info.
5. **submit**: one ordinary ES run end to end, and the observer token
   listing ES's jobs before and after (the `list-jobs` fix live).
6. **rollback**, only if the apply said `applied` and ES or AGS is
   unhealthy; the phase checks that itself.

The script was tested against local stand-ins, with the real
`nomad_tls_identity.py` against a TLS 1.3 Nomad stand-in (plan section 5).

Afterwards: an Archived-Runbooks PR with a History line in "Governed
Execution Remote Alpha Claude Access" and the note that Nomad's API on the
box is `https://127.0.0.1:4646` with `NOMAD_CACERT=/etc/nomad.d/tls/ca.pem`.

Rollback by hand, if a later diagnosis calls for it: `sudo
scripts/remote_alpha_upgrade_es.sh rollback --backup-dir <backup>` from the
same build folder (root-only in `/tmp` until a reboot), then `provision`
from the `16cbf73` checkout if the old `check` is needed (section 8).

## 12. Not done here

- INF-02 stays open (Docker socket; job shape within the Docker limits).
- ES accepts a symbolic link as `nomad.root_ca_file` (it reads the target),
  while the scripts refuse one for `NOMAD_CACERT`. The CA is public; whoever
  can change the link can change the file. Recorded, not changed.
- `nomad.base_url` may name any loopback IP (for example `127.0.0.2`);
  ES verifies the name, so that works for ES, but the scripts verify the IP
  and the certificate names only `127.0.0.1` and `::1`. The supported setup
  binds `127.0.0.1`.
- The readiness Python's own TLS 1.3 minimum is not separately tested: it
  runs only after `nomad_curl` (TLS 1.3) has reached the same Nomad.
- Rotating the certificate needs the new pin in ES's config and an ES
  restart; setup says so when it reissues. The upgrade script does not
  rotate; on a migrated box it only verifies.
- The upgrade does not roll the ACL policies back (section 8).
- Other ES dependency clients (ARS, EGS) and the services' own listeners
  keep TLS 1.2 as their floor; they are not Nomad and not in this PR's
  scope.

## 13. Audit 20 and 21 repairs (`dfb2873`)

Two independent audits of `f505f72` returned BLOCK:

- `20-pr60-audit.md`, from the thread "Audit Nomad over HTTPS";
- `21-pr60-audit.md`, from the thread "Audit the Nomad lock", which maps its findings to audit 20.

Both found the HTTPS lock and the pin sound. Their findings and what `dfb2873` does:

| Finding | What | Repair |
|---|---|---|
| A20-1 | ES's `nomad.root_ca_file` loader accepted text before or between certificates and skipped a corrupt PEM block, though its comment, `configuration.md` and this report say "PEM CERTIFICATE blocks and nothing else but white space". | `loadNomadRootCAs` now trims white space, requires `-----BEGIN CERTIFICATE-----` where it ends, and requires `pem.Decode` to consume only that one block (one `-----BEGIN` in the bytes it consumed). New cases: text before, text between, corrupt block first (refused); two certificates with white space around and between them (accepted). |
| A20-2 (a), audit 21's A23-2, O20-1 | Nothing tested the upgrade's anonymous-job-list 403 check, either on a migrated host (`inspect_migrated`) or after apply (`verify_after`). | The fake curl gains a marker `https-jobs-open`: over HTTPS, Nomad lists jobs to anyone. On the migrated host in `TestRemoteAlphaUpgradeESApply`, check and apply block with "Nomad answers an anonymous job list over HTTPS with 200, not 403", only read and change nothing. A new case in `TestRemoteAlphaUpgradeESApplyRollsBackOnFailure` makes `verify_after` refuse it, and the apply rolls back. |
| A20-2 (b) | The TLS identity tool's loopback-IP check was not tested. | A case in `TestNomadTLSIdentityChecksWhatESChecks`: base_url and address `https://192.0.2.1:<port>`, refused with "must be https://<loopback IP>:<port>". |
| A20-2 (c) | The proof fetch's `NOMAD_CACERT` check was not tested. Without it, an empty value makes Python trust the system store. | In `TestSupportedLocalProofNodeDetailLoopbackAdmission`, three settings are each refused before any request and publish nothing: `NOMAD_CACERT` empty with `SSL_CERT_FILE` pointing the system store at Nomad's CA, a relative path to Nomad's CA, and a symbolic link to it. |
| audit 21's A23-3 (G7) | `nomad_tls_identity.py` refuses a CA file that is a symbolic link, but nothing tested it. | `check` and `pin` with a linked CA are both refused with "is not a readable CA certificate file". |
| A20-3, audit 21's A23-1 | CI failed: es/app reached go test's default 10-minute limit. Pre-existing, outside this PR's paths. | Separate CI-only PR #61 (`claude/ci-gate-time-limit`): the gate gives each test binary 20 minutes and the job 90 minutes. Report: `reports/Execution-Substrate/ci-gate-time-limit/01-pr61-gate-time-limit.md`. |

### Mutants (Ran)

Each mutant ran against the named test on the `dfb2873` bytes, in a copy run as the test user. Each one fails a test that passes without it:

| Mutant | Site | Killed by |
|---|---|---|
| no prefix check | `loadNomadRootCAs` | text before, text between |
| no one-block check | `loadNomadRootCAs` | corrupt block first |
| A8 | identity tool, `or not host.is_loopback` removed | non-loopback IP address |
| A12 | proof fetch, `os.lstat` to `os.stat` | `TestSupportedLocalProofNodeDetailLoopbackAdmission` |
| A12b | proof fetch, the `NOMAD_CACERT` line removed | same |
| A12c | proof fetch, the absolute-path test removed | same |
| G7 | identity tool `_context`, the regular-file check removed | CA file is a symbolic link; pin refuses a linked CA |
| A7/V5 | `inspect_migrated` 403 check removed | `TestRemoteAlphaUpgradeESApply` |
| A7b/V12 | `verify_after` 403 check removed | `TestRemoteAlphaUpgradeESApplyRollsBackOnFailure` (Nomad lists jobs to anyone over HTTPS) |

With the loader of `f505f72`, the three new refusal cases fail (Ran).

### Validation of `dfb2873` (Ran)

All in a container copy as the test user, Nomad 2.1.1, Docker up:

- `./internal/testutil`: ok.
- `./es/admission`: ok, 351 s.
- Root package: ok.
- All 16 `TestRemoteAlphaUpgradeES*` tests: ok, the real-Nomad one included (through sudo).
- The three touched es/app tests: ok.
- `go vet` of both packages and gofmt: clean.

### es/app timing (Ran)

Whole es/app as the gate runs it (`-json`, its three skips, `-timeout 60m`), Docker up, one after the other on the same container:

- 591.7 s at `2ca76cd` (es/app is the same at `bf5a760`);
- 625.4 s at `f505f72`;
- the 9 tests this PR adds took 21.7 s;
- the largest growth in an existing test was 4.9 s.

Base and head alike sit at the default limit here, so the repair for A20-3 belongs in the gate (PR #61), not in this PR's tests.

## 14. Audit 22 repair (`fe5119b`) and the merge of #61 (`977b172`)

Re-audit `22-pr60-reaudit.md` of `dfb2873` confirmed every audit 20 and 21
repair (13 of 13 mutants killed) and blocked on one new Low:

| Finding | What | Repair |
|---|---|---|
| A22-1 | On a host the upgrade already moved, `check` and `apply` proved the lock only with an anonymous `GET /v1/jobs` answering 403. That request asks about the namespace `default`, so an anonymous policy that opens only `es-submit-v1` leaves it at 403 while anyone may submit there. The host was reported as having nothing to do. | A new `anonymous_nomad_problems()` makes two requests without a token over HTTPS: the job list must answer 403, and `GET /v1/acl/policy/anonymous` must answer 404, the request ES makes before each submit and `nomad_acl_state_check` makes too. `inspect_migrated` blocks on each problem, and `verify_after` refuses on them before `nomad_acl_setup.sh check`. The docs (`remote_supported_host_alpha.md`, the no-op paragraph and step 7) say so. |

Why not run `nomad_acl_setup.sh check` on the migrated path too: `check` of the
upgrade is read-only, and the ACL tool's `check` creates and deletes
short-lived probe tokens (`grants_in_namespace`). The policy request is read-only
and is the fact the lock's contract names ("no anonymous policy") (Read).

Tests:

- The fake curl answers `/v1/acl/policy/anonymous` with 404 on a locked Nomad, 200 with the marker `anonymous-policy`, and 400 when ACLs are off.
- `TestRemoteAlphaUpgradeESApply`: on the migrated host with that marker, check exits 1 with exactly one blocker, "Nomad answers a request without a token for its anonymous ACL policy over HTTPS with 200, not 404", and no job-list blocker; apply refuses with "nothing was changed"; only reads; the host is unchanged. Check and apply of the clean migrated host each make the policy request, and apply makes it after the job list and before `acl-setup check`.
- `TestRemoteAlphaUpgradeESApplyRollsBackOnFailure`: a new case, "Nomad holds an anonymous policy", fails `verify_after` and rolls back.
- `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS`: after the migrated no-op, a management token creates the policy `anonymous` with `namespace "es-submit-v1" { capabilities = ["submit-job", "list-jobs", "read-job"] }`. Anonymous `GET /v1/jobs?namespace=es-submit-v1` answers 200 and anonymous `GET /v1/jobs` still 403 (the auditor's probe, now in a test). Check exits 1 with the one policy blocker, apply refuses, only reads, and the host is unchanged. After the policy is deleted, check passes again. The new steps take about 1.3 s.

### Mutant (Ran)

`anonymous_nomad_problems` with the policy check disabled fails all three:
the migrated-host case in `TestRemoteAlphaUpgradeESApply` (exit 0, no blockers),
the rollback case (apply exits 0), and the real-Nomad test (check exits 0).

### Validation of `977b172` (Ran)

In the container copy as the test user, Nomad 2.1.1, Docker up, `-timeout=20m`:

- `./internal/testutil`: ok. `./es/admission`: ok, 326 s. Root package: ok, before and after the merge of `e2af4b2`.
- All 16 `TestRemoteAlphaUpgradeES*` tests: ok, the real-Nomad one included (through sudo). With Docker down, its `placement` step fails as it should, after 120 s.
- Whole `scripts`: 28 tests fail. The same 28 fail on base `2ca76cd` in the same container: this container has no `ssh` or `scp`, which the operator tests need, and the rest are entries of `.github/ci/environment-only-tests.txt`.
- gofmt and `go vet ./scripts/`: clean. `py_compile` of the upgrade script: ok.

### The merge of #61

#61 merged into trunk_dev as `e2af4b2` (squash, tree `c9d2d6b3…`, equal to
its audited head `af266dc`'s tree). Its 5 paths and this PR's 58 have none in
common, so the merge `977b172` had no conflicts, and this PR's file set is
unchanged (Ran). CI on `977b172` is the first run of #60 with the gate's
20-minute limit.

### CI on `977b172` (Read, job log)

Run 45565423373, job 139038913119 ("build, vet and test"): passed, 07:05:27 to
07:51:48Z (46.4 minutes, under the new 90).

- Build, vet and macOS vet (`GOOS=darwin GOARCH=arm64 go vet ./...`) passed. The workflow has no macOS test job: that is PR #59, not merged.
- All 25 `go test -json` lines of the gate carry `-timeout=20m -count=1`.
- Gate: 49 packages; 14 tests skipped themselves, all listed (the 9 root-only `scripts` tests, 2 in `reliablesubmit`, 3 in `es/admission`). So `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` ran and passed there.
- es/app: 458.6 s gated, 426.6 s observed, 455.8 s still-failing, by go test's own times. `scripts` 354.2 s; `es/admission` 257.3 s.
- "Listed tests still fail": all 17 listed tests still fail. Root step: 9 tests of `scripts` passed.

## 15. The macOS test gate (`c951578`, `d01ec38`, `4795a4f`, `c492cb9`)

- `c951578` merges trunk_dev `819f712` (#59, workflow `go-macos.yml`, "test
  on macOS", which gates `./scripts/...` with
  `.github/ci/environment-only-tests-macos.txt`). No conflicts.
- `d01ec38`: `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` skips itself
  off Linux (the box's `nomad.hcl` has Linux client settings); a
  `skips-itself` line lists it.
- `4795a4f`: the macOS run of `d01ec38` (run 45572903953) failed six upgrade
  tests with "its material fails the setup's nomad_tls_material_ok": that
  function reads the key's mode with GNU `stat -c '%a'`, which macOS's stat
  lacks. The setup and the upgrade run only on the Linux box, so they are
  listed as Linux-only with that reason (porting would change product code
  under review and need LibreSSL checks of uncertain support). CI on
  `4795a4f`: both workflows green (runs 45575231725 and 45575231690).
- `c492cb9` (delta check A26-1, coordinator 09:15Z): the upgrade check test
  is listed whole instead of its subtest "TLS material was issued but
  nothing else moved", because its subtest "the TLS key is readable by
  others" expects a refusal and so passed on macOS without reaching the
  key-mode check it is named for (`stat -c` fails first). Same pattern as
  the two TLS status tests listed whole for the "ds" account. The list
  parses to 28 entries and 81 skips (Ran). No product code.
  CI on `c492cb9`: both workflows green (runs 45584152191 and 45584152117,
  finished 10:04Z and 09:50Z).
