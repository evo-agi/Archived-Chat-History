# 27. Diff-only check of ES PR #60 (Nomad lock part 2b), 4795a4f to c492cb9: the upgrade check test listed whole on macOS

Verdict: **ACCEPT**. A26-1 is fixed the way report 26 recommended, the delta is that one list change and nothing else, and both workflows are green on the exact head tree. No finding.

Every statement is marked **Ran** (I executed it and saw the output), **Read** (code, docs or logs) or **Inference** (reasoned from cited facts, not observed). Evidence paths are relative to `27-pr60-list-diff-check-evidence/`.

```text
INDEPENDENT AUDIT REPORT (diff-only check)
Repository:     evo-agi/Execution-Substrate, PR #60 into trunk_dev, branch claude/project-thread-9slgp8
Base:           trunk_dev 819f712cde8fd83f5b73b2154263afa18cf29623 (also the merge-base and the PR's base)
Previous head:  4795a4f3ce5c1c5135de83e73181e3b0e12e47d1 (delta check 26: BLOCK on A26-1)
Head checked:   c492cb9cec10de0ce76638605d22b27d6fa9619a, tree 50e7bf98f2333321212921953fe390cefadd63f6
Recipe:         governed-execution.audit-patch-manifest.v2, source SHA-256
                c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified before each run)
Manifest:       b4cd83a0e194a5c84249f01fc554d09d28563c0759718a00adb9579d38cc00ff, 59 paths,
                textual_diff_sha256 f593f46a3cdbf8afe9a61d044f013ca2761150013f204c411f2f10003c55b334
Posture:        read-only; no subagents; nothing pushed, no PR edit, no GitHub comment, box not touched
Verdict:        ACCEPT
```

Times are UTC on 2026-11-25. The check ran from about 10:07Z to 10:30Z. I had not audited PR #60 before (protocol §14).

## 1. What the delta is

`4795a4f..c492cb9` is one commit, `c492cb9` "macOS test list: list the upgrade check test whole (delta check A26-1)". It changes one file, `.github/ci/environment-only-tests-macos.txt`: 5 lines in, 4 out (Ran: `git diff --stat`; the diff is `provenance/delta-4795a4f-c492cb9.diff`).

- The entry `…TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor/TLS_material_was_issued_but_nothing_else_moved` becomes `…TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor` (the whole test).
- The comment above it now says the test is listed whole because its subtest "the TLS key is readable by others" expects the check to refuse, so on macOS it passes without reaching the key-mode check, since `stat -c` fails first. That is report 26's A26-1 and its option 1, word for word in substance (Read).

No product code, test code, gate code or workflow changed.

## 2. Provenance (Ran, `provenance/`)

- `git ls-remote` and the GitHub API: the PR head is `c492cb9`, the branch tip is `c492cb9`, trunk_dev is `819f712`. `819f712` is an ancestor of `c492cb9` and the merge-base. `4795a4f` is its parent.
- Provenance §5.3 in a fresh clone: tip checked out clean, `reset --mixed 819f712`, upstream `origin/trunk_dev`, `umask 022`, v2 twice. The two runs are byte-identical: `b4cd83a0…00ff`, 59 paths.
- Against audit 26's opening manifest for `4795a4f` (`26-pr60-macos-delta-check-evidence/provenance/manifest-v2-4795a4f-vs-819f712-opening.json`, SHA-256 `4f8e0b50…8b54`): same 59 paths, same metadata apart from `textual_diff_sha256`. **58 records are byte-identical**, every product path among them. The one changed record is `.github/ci/environment-only-tests-macos.txt` (19783 to 19780 bytes, SHA-256 `7440f5d0…1149` to `8642211e…061b`, the blob of `c492cb9`).
- So the product bytes are those that audits 22 and 23 accepted and report 24 red-teamed (via report 26's record-by-record trace from `977b172`).
- No writer manifest for `c492cb9` exists. Report 11 §15 describes the commit but gives no manifest (O26-3 still applies). The manifest above can be the reference.
- Closing manifest: two runs at 10:26Z are byte-identical to the opening ones (`provenance/manifest-v2-c492cb9-vs-819f712-closing.json`). The branch tip, `refs/pull/60/head` and trunk_dev had not moved at 10:27Z (Ran: `git ls-remote`). I created nothing in the manifest clone. The gate runs used separate clones.

## 3. The list parses (Ran)

The gate's own functions at `c492cb9`, run as an unprivileged user: `read_entries` on the macOS list gives **28 entries and 81 self-skip lines**, and `check_list(by_package(entries), by_package(skips), go list ./scripts/..., "./scripts/...")` passes. The only entry for this test is the whole test. The only upgrade self-skip is `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS`, as before.

The gate files have the same blob ids at `c492cb9`, `4795a4f` and trunk_dev `819f712` (Ran: `git rev-parse <rev>:<path>`):
- `.github/ci/go_test_gate.py` `bf7f17d4`;
- `.github/ci/go_test_gate_selftest.py` `57e1b452`;
- `.github/workflows/go-macos.yml` `8524a80a`;
- `.github/workflows/go.yml` `06183ab6`;
- `.github/ci/environment-only-tests.txt` `7c718cf2`.

So the gate that audits 30 and 32 checked for #59, and that report 26 exercised, is the gate that runs here.

## 4. The gate still fails on a passing listed test or an unlisted failure

The gate code is byte-identical to what report 26 exercised (§3), so the question is how it treats the one changed entry. I ran `go_test_gate.py still-failing` at `c492cb9` with a list holding only the new whole-test entry (`gate/list-new1.txt`). Each run went in its own clone, as an unprivileged user under `env -i` with HUP, INT, QUIT and TERM reset (`gate/sf.sh`).

- **Plain Linux, where the test passes (Ran, `gate/still-failing-plain-summary.txt`): exit 1.** It gives two errors naming the entry: "listed test no longer fails on this host (it passes)" and "listed test does not fail in the run of its package (it passes)". So a listed test that passes still fails the gate.
- **With a macOS-like `stat` first on `PATH` (Ran, `gate/still-failing-bsd-summary.txt`): exit 0.** The tool says "still fails: … TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor (its subtests: 41 pass, 1 fail)" and "all 1 listed tests still fail on this host, each in a run of its own and in the run of its package". That is the runner's line word for word (§5). The stand-in is report 26's `bsdstat-stat.sh`, read before use: it refuses `-c` as macOS's `stat` does and passes every other call to GNU `stat`.
- **The whole test alone (Ran, `gate/whole-test-*-verdicts.txt`):**
  - plain: 42 subtests pass, exit 0;
  - macOS-like: 41 pass, and only `TLS_material_was_issued_but_nothing_else_moved` fails.

  So the whole test fails on the runner for the stated reason, and its key-mode subtest no longer stands in the gate as coverage.
- **Unlisted failure (Read).** The gate code, its self-check and both workflows have the same blobs as trunk_dev. Its self-check ("Ran 145 tests", OK) passed in both jobs on this head. On `d01ec38`, before the upgrade entries existed, the unlisted upgrade failures failed the step "Test" (report 26, run 45572903953). This delta only widens one existing entry from a subtest to its whole test, so it adds no new way for a failure elsewhere to go unlisted. Inside this one test, macOS now hides its subtests (O27-1).
- **Setup note (Ran, `gate/first-attempt-without-supplementary-group.txt`):** my first attempt used a test user with no supplementary group. The subtest `the_payload_directory_belongs_to_another_group` then failed on plain Linux ("the test user has no supplementary group …", `remote_alpha_upgrade_es_host_test.go:1126`), so the entry "still failed" for that reason. After `usermod -aG users ci` the results are as above. The GitHub runner's user has supplementary groups, and `go.yml` passed this test (§5).

## 5. CI on the exact head tree (Read, Ran)

`refs/pull/60/merge` is `2a83dc3f3f0941a39dc42296678820377bc0985a`, parents `819f712` and `c492cb9`, tree `50e7bf98…63f6`, which is the head's tree (Ran: `git fetch`, `git rev-parse`). Both jobs checked out that commit: "HEAD is now at 2a83dc3 Merge c492cb9… into 819f712…" (Read: the job logs). Both runs record `head_sha` `c492cb9` (Read: GitHub API).

- **"test on macOS"**: run 45584152117, job 139101345812, 09:18:32Z to 09:50:06Z, success. Image macos-26-arm64 20261117.0516.1, go1.26.5 darwin/arm64 (Read: `ci/macos-c492cb9-job139101345812-extract.txt`).
  - Self-check: "Ran 145 tests", OK.
  - "Test": "test gate passed: 2 packages, 1 of them with skipped entries (28 entries); 81 tests skipped themselves, all of them listed". The observed run "skipped exactly the listed tests of this package (28), each once". `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` skips itself with its stated reason (`remote_alpha_upgrade_es_host_test.go:1738`).
  - "Listed tests still fail": "all 28 listed tests still fail on this host, each in a run of its own and in the run of its package". Among them: "still fails: execution-substrate/scripts TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor (its subtests: 41 pass, 1 fail)". The one failing subtest is `TLS_material_was_issued_but_nothing_else_moved`, the same as at `4795a4f`. `the_TLS_key_is_readable_by_others` still passes there, but it is no longer counted as coverage.
- **"build, vet and test"**: run 45584152191, job 139101345763, 09:18:33Z to 10:04:33Z, success, go1.26.5 linux/amd64 (Read: `ci/linux-c492cb9-job139101345763-extract.txt`).
  - Self-check "Ran 145 tests"; "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed"; "all 17 listed tests still fail"; "tests as root passed: 9 of execution-substrate/scripts".
  - The Linux list is unchanged and names no upgrade test, so the whole upgrade check test, the key-mode subtest included, ran and passed on Linux (Inference from the gate's rule plus the green step, as in report 26).
  - At job end the runner ended 2 orphan `nomad` processes (pids 145329 and 145417): O23-5 again, unchanged by this delta.

## 6. Findings

None blocking. Observations:

- **O27-1, cost of listing the whole test.** On macOS the gate no longer counts the 41 passing subtests of `…CheckRefusesWhatItWasNotWrittenFor`. A new macOS-only failure in any of them would be hidden there. That cost is the one report 26 named for option 1. It fits the list's rule (box-only code, and `go.yml` runs every subtest on Linux). No action.
- **O27-2, merge order with PR #62.** Both PRs edit `.github/ci/environment-only-tests-macos.txt`, in different places. `git merge-tree --write-tree c492cb9 f56ed54` (PR #62's head at about 10:15Z) is clean, and its list holds 26 entries and 81 self-skip lines (Ran). Whichever PR merges second needs an update merge and green `go` and `go-macos` runs on the new head. Its list must not keep the two LibreSSL entries once #62 is in: git's merge drops them.
- **O26-3 carries over:** report 11 §15 covers `c492cb9` in prose but gives no manifest. Use `b4cd83a0…00ff` from this check as the reference at the merge gate.

## 7. Validation assessment

Re-run here (Ran): v2 manifest twice at opening and twice at closing; record-by-record comparison with audit 26's manifest; the gate's list parse and `check_list`; `go_test_gate.py still-failing` with the new entry, plain and with a macOS-like `stat`, and the whole test alone in both modes (§4); trial merge with PR #62.

Read, not re-run: the two CI runs on `c492cb9`. I had no macOS host, so the macOS verdicts come from the runner's log.

Not re-run: the whole `scripts` package outside the gate runs, and the rest of #60's tests. Every product and test file is byte-identical to `4795a4f`, which report 26 checked.

## 8. Sensitive-material handling

No secrets read or printed. The published extracts hold test names, step summaries and refusal text only. Checked for `@`: none. Full job logs stay on GitHub.

## 9. Confidence

- Provenance: 1.0. Manifest stable and traced record by record to the previously checked head. CI ran on the head's tree.
- Validation: high. Both CI runs green on the exact tree, the gate's behaviour on the new entry reproduced here.
- Implementation: high. List-only change that does what A26-1 asked.

## 10. Effect status and delivery

No repair, commit, push, PR edit, comment or merge. The box was not touched.

Report: `/mnt/project-files/reports/Execution-Substrate/nomad-acl/27-pr60-list-diff-check.md`, SHA-256 in the thread reply. Evidence: `27-pr60-list-diff-check-evidence/` with `SHA256SUMS.txt`.

Final verdict: **ACCEPT**
