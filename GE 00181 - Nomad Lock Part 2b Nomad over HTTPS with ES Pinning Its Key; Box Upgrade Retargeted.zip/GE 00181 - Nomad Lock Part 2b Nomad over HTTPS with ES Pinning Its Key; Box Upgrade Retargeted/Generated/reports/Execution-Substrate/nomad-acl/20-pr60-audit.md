# Audit of ES draft PR #60 (Nomad lock part 2b: Nomad over HTTPS) at f505f72

Verdict: **BLOCK**. Three findings are in the PR's own diff or block its gate:
two Lows in the diff (A20-1, A20-2) and the PR's own CI run, which is red (A20-3).

Nomad over HTTPS with ES pinning its key works as designed. ES, the scripts, the ACL tool and the
upgrade all refuse plain HTTP, other CAs, other keys, other names and TLS 1.2 where the
PR says they do. I checked this on real Nomad 2.1.1 and 2.0.0 and with 20 audit mutants
that the tests kill. Nothing I found lets a token leave over plain HTTP or reach a Nomad
other than the pinned one.

- **A20-1 (Low, in the diff).** ES's CA-file loader is looser than its own comment, the
  configuration doc and the writer's report. It accepts text before the first certificate,
  text between certificates, and a corrupt PEM block, which it skips without a word (Ran,
  probe). This fails closed and adds no trust, but the documented contract does not hold
  and no test pins it.
- **A20-2 (Low, in the diff).** No test pins three new refusal checks. A mutant that removes
  each one passes every test that reaches its code (Ran):
  - the upgrade `check` on an already-migrated host refuses a Nomad that answers an
    anonymous job list;
  - the TLS identity tool refuses a non-loopback IP;
  - the proof's node-detail fetch requires an absolute, non-symlink `NOMAD_CACERT`. Without
    that line, an unset `NOMAD_CACERT` makes the fetch trust the system CA store.
- **A20-3 (Medium, pre-existing, outside the diff).** The required check "build, vet and test"
  failed on `f505f72`: `es/app` hit Go's default 10-minute test timeout. The gate passes no
  `-timeout`. On the two other runs that day (trunk_dev bf5a760 and PR #59), `es/app`
  took 393 to 432 s. PR #60's runner was 15 to 48% slower on packages the PR does not
  touch, and the PR adds about 20 s of `es/app` tests. Rerunning CI might pass this time,
  but the margin is thin for every PR.
- **The author's failure claim holds here** (Ran). On head and on base `bf5a760`, the same
  13 top-level tests fail (43 counting subtests), for the same reasons, and the same 14
  tests skip themselves. Names are in "Validation assessment". 12 of the 13 are entries
  in CI's environment-only list. The 13th, the full-profile bring-up, fails here only
  because its image build needs the internet. With an offline image of the same commit's
  binaries, it passes on Nomad 2.1.1 and 2.0.0.

Every statement is marked **Ran** (I executed it and saw the output), **Read** (I read
code, docs or logs) or **Inference** (reasoned from cited facts, not observed directly).
Evidence paths are relative to `20-pr60-audit-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Repository / audit target

- Repository: evo-agi/Execution-Substrate, draft PR #60 into `trunk_dev`, branch
  `claude/project-thread-9slgp8`.
- Base: `bf5a760a2276f5d8b7600d7b64523e4ee32410d0` (trunk_dev and the merge-base).
- Topic: `f505f7236c5ce5ca8c7eef40330da70bfb2c4c10`, tree
  `9174519916bdbbfeb8d32dc1b15cc359bd4328f0`, 11 commits. It is the PR head (Ran, GitHub
  API and `git fetch`).
- Recipe `governed-execution.audit-patch-manifest.v2`, source sha256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before
  each use).
  - textual_diff_sha256 `8823dbcd5af47c23c5c9d084501cc0645e41a9fc1a89a67c4fda10f9ec93c209`
  - manifest_sha256 `e3904b35be2a3fdc6caea1360d7dbc33783ebccd7ce2c912466a5f72e2ac1d5e`
  - 58 paths, none under `.github/`
- Scope (from the coordinator): a fresh, read-only, independent correctness audit of the
  whole PR:
  - Nomad over HTTPS with ES pinning the server key;
  - the observer token may list ES's jobs;
  - the reliable-submit provider is held to TLS 1.3;
  - the upgrade is retargeted from locked-http to https;
  - and verification of the author's claim that every remaining test failure also fails
    on trunk_dev, with failing test names published.

  A Fable red-team follows separately.
- Writer's report: `11-part2b-nomad-https.md`, sha256
  `8f9f1c350b30937f4873ca3d000b0223519641d35ff5186321eb07e32b5f163f`.

## Audit posture

Read-only. Nothing was committed, pushed or commented on GitHub. No subagents were used.
Nothing on the box or any live service was touched.

Everything ran in this container, all as user `ci` with Go 1.26.5 and
`GOTOOLCHAIN=local`:
- local clones of head and base;
- disposable Nomad agents (2.1.1 and 2.0.0) on loopback;
- Docker with the CI images pulled by digest;
- the PR's own test harness.

Mutants ran one at a time in a scratch clone, which I restored after each one and checked
clean at the end. The audit tree `/home/user/Execution-Substrate` was used only for the
manifest and for reading.

## Provenance reproduction (Ran)

- The pushed tip equals the reported tip, and `bf5a760` is the merge-base.
  `git diff --name-only --no-renames bf5a760 f505f72` lists 58 paths, none under `.github/`.
- Setup: branch `claude/project-thread-9slgp8` checked out at the tip, `reset --mixed` to
  the base, upstream `origin/trunk_dev`, `umask 022`.
  - Two opening runs of the recipe are byte-identical, and equal to the writer's
    `11-evidence/manifest-v2-f505f72.json`.
  - Two closing runs after all tests and mutants (05:18Z) are byte-identical to the
    opening ones.
  - No mode-bit differences were tolerated. Commands and outputs are in `provenance/`.

## Coverage

- Read, the whole product diff:
  - `es/admission/nomad_tls.go`;
  - the `submit.go` client and transport;
  - the reliable-submit provider change;
  - `es/config/config.go` validation (base URL, server name, pin, CA path, the
    "configured" rule);
  - the `nomad_tls` region and readiness of `70_linux_setup.sh`;
  - `nomad_acl.sh` and `nomad_acl.py` (TLS connection, port-holder order, CA handling,
    observer policy);
  - `nomad_tls_identity.py` (in full);
  - the bring-up, health-check, supported-local setup and proof scripts;
  - `supported_local_proof_projection.py`;
  - `remote_alpha_upgrade_es.py` (in full: shapes, apply, verify, restore, rollback);
  - the docs (`configuration.md` "Nomad HTTPS", `contracts.md`, the Remote Alpha upgrade
    section, host qualification, runbooks, `PLANS.md` line, examples).
- Read, tests: the new TLS harness and tests; the CA-file cases; the upgrade fake host and
  its real-Nomad test; the bring-up assertion of the `nomad tls:` line.
- Read: the writer's report and PR body; CI runs 45546737121 (PR #60), 45539140560
  (trunk_dev bf5a760) and 45545850585 (PR #59), through the GitHub API.
- Ran: the provenance; whole-module tests on head and base; targeted runs on Nomad 2.0.0;
  the bring-up with an offline image on both Nomad versions; a CA-file probe; a Python
  `ssl` probe; 28 mutants (one also on base).
- Not inspected in depth: unchanged code that the PR only reaches through calls, and the
  9 tests in the `scripts` package that skip themselves as non-root here and in CI
  (namespaces, firewall, sshd).

## Findings

### Patch defects

```text
AUDIT FINDING
ID / Type / Severity: A20-1 / contract and test gap / low
Current contract or strategic target: nomad.root_ca_file is "a regular file of at most 1 MiB
  holding only PEM certificates" (configuration.md:641); loadNomadRootCAs "holding one or more
  PEM CERTIFICATE blocks and nothing else but white space" (nomad_tls.go:61-63); the writer's
  report says the same (11-part2b-nomad-https.md:155-156).
Path and line: es/admission/nomad_tls.go:84-101 (the pem.Decode loop); es/admission/nomad_tls_test.go:270-296
Evidence: pem.Decode skips any text before a block and any block it cannot decode, and
  returns the next good block. The loop checks only the type, the headers and the trailing
  rest. Probe, loadNomadRootCAs on 10 files (Ran, probes/ca-loader-probe.txt): accepted
  "leading text", "text between blocks", "corrupt block first" and "corrupt block between";
  refused trailing text, PEM headers and a PRIVATE KEY block, as documented. The tests
  cover trailing data, headers, garbage DER and size, but no leading text, interleaved text
  or skipped block.
Impact: fails closed. The pool holds exactly the certificates that parse, so the skipped
  bytes add no trust. If an operator's intended CA is in a corrupt block, the handshake
  fails and submit refuses with 503. The documented strictness does not hold, and nothing
  would catch a further loosening.
Required correction: make the loader refuse any non-white-space byte outside a block and
  any block that pem.Decode skips. For example, before each pem.Decode, trim leading white
  space and require the rest to begin with "-----BEGIN CERTIFICATE-----", and require that
  the call consumed only that one block. Add three cases to
  TestNewNomadClientRefusesWithoutAUsableRootCAOrPin: text before the certificate, text
  between two certificates, and a corrupt block before a good one. (The other way out is to
  narrow the comment, docs and report to what the code enforces. I recommend the code fix,
  because the docs and the report promise the stricter rule.)
Uncertainty: none on behaviour (Ran). The severity is my judgement.
Patch defect or pre-existing issue: patch defect (new file).
```

```text
AUDIT FINDING
ID / Type / Severity: A20-2 / test gap / low
Current contract or strategic target: the PR's refusal checks are pinned by tests (the
  writer reports 25/25, 6/6 and 14/14 mutants killed); the project fixes Low test gaps in-PR.
Path and line:
  (a) scripts/internal/remote_alpha_upgrade_es.py:1261-1263, inspect_migrated: on an https
      host, check blocks unless an anonymous GET /v1/jobs over HTTPS answers 403
  (b) scripts/internal/nomad_tls_identity.py:101, _loopback_endpoint: "or not host.is_loopback"
  (c) scripts/internal/supported_local_proof_projection.py:535, fetch_node_details:
      require(ca_file.startswith("/") and stat.S_ISREG(os.lstat(ca_file).st_mode))
Evidence (Ran, mutants/round1.txt, round2.txt, logs/):
  (a) A7 ("if False") survives Apply, CheckChangesNothing and CheckRefuses. A7w survives all
      16 TestRemoteAlphaUpgradeES* tests, the real-Nomad one included. The fake curl answers
      403 whenever nomad.hcl has an acl block, and a migrated nomad.hcl always has one.
      Real Nomad always answers 403. No test makes Nomad answer an anonymous job list.
  (b) A8 survives TestNomadTLSIdentityChecksWhatESChecks. A8w survives every *NomadTLS*
      and *Readiness* test and TestSubmitRefusesANomadOtherThanThePinnedOne. The cases
      cover http, a host name and another port, but not a non-loopback IP.
  (c) A12/A12w (lstat to stat) and A12b (the line removed) survive
      TestSupportedLocalProofNodeDetail*, TestSupportedLocalProofHostObservation*,
      TestRealNomad* and TestNomadACL*. With the line removed, an unset NOMAD_CACERT
      reaches ssl.create_default_context(cafile=""), which loads the system CA store
      (Ran: 120 CAs, probes/python-empty-cafile.txt).
Impact: each check fails closed today. In (a), on a migrated host, this 403 is the only
  check in check's read-only path that Nomad enforces ACLs and holds no anonymous policy.
  If it regressed, check would call such a host migrated and change nothing. (b) and (c) are
  second guards: ES refuses a non-loopback base_url itself, and the proof scripts get
  NOMAD_CACERT from supported-local setup, which refuses a symlink (A19 killed). If (c)
  regressed, the fetch would no longer trust "only Nomad's CA", as configuration.md says.
Required correction: one test case per check, each failing on its mutant:
  (a) a migrated fake host on which Nomad answers the anonymous job list with 200: check
      must block with "Nomad answers an anonymous job list over HTTPS with 200, not 403";
  (b) a case in TestNomadTLSIdentityChecksWhatESChecks with base_url and the address both
      a non-loopback IP (for example https://192.0.2.1:<port>), refused with "must be
      https://<loopback IP>:<port>" before any connection;
  (c) fetch-node-details with NOMAD_CACERT unset, relative, and a symlink to the right CA,
      each refused before any request.
Uncertainty: none on survival (Ran).
Patch defect or pre-existing issue: patch defect. (a) and (b) are new code. (c) is a new
  line. The matching check in verify_after has the same gap on base (O20-1).
```

### Pre-existing issues

```text
AUDIT FINDING
ID / Type / Severity: A20-3 / CI reliability (the required gate) / medium
Current contract or strategic target: "build, vet and test" is the required check on
  trunk_dev; a red result should mean a real failure.
Path and line: .github/ci/go_test_gate.py (its go test calls pass no -timeout, so Go's
  default 10m per test binary applies); not in this PR's diff.
Evidence (Read, ci/ci-runs.txt):
  - Run 45546737121 on f505f72, step "Test": "FAIL execution-substrate/es/app 600.011s",
    "panic: test timed out after 10m0s", with
    TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget running for 3 s. The
    gate stopped there, so "Listed tests still fail" and "Listed tests pass as root" were
    skipped. Build, vet, vet for macOS and the gate self-check passed. The scripts package
    passed with only its 9 listed skips, so the real-Nomad upgrade test ran and passed
    (Inference: the gate fails any unlisted skip).
  - The same job on trunk_dev bf5a760 (03:19Z) and on PR #59 (04:18Z, which does not touch
    es/app) ran es/app in 432 and 426 s, and the observed reruns in 393 and 421 s.
  - On PR #60's runner, packages the PR does not touch were slower: reliablesubmit 51.4 s
    against 34.5 to 34.7 s, callerauth 65 against 49 to 54 s, ags/app 31 against 26 to 27 s.
  - Locally: the 9 es/app tests the PR adds took 19.5 s; es/app took 596 s on head and
    522 s on base (Ran).
Impact: es/app uses about 72% of the 10-minute limit on a normal runner. A slow runner
  fails the required check with a timeout panic that names whatever test happened to be
  running. That blocks merges that have nothing wrong with them, and each new es/app test
  narrows the margin.
Required correction: (1) for this PR, a new CI run on the head that follows the A20-1 and
  A20-2 fixes, which happens anyway. (2) Separately, a CI-only PR that passes an explicit
  -timeout to the gate's go test calls, sized from the slowest observed runs, or splits
  es/app. That is the coordinator's call, and it is outside this PR's 58 paths.
Uncertainty: Inference that a normal-speed runner passes es/app at f505f72: about 432 s
  plus about 20 s of new tests, scaled by the CI to container ratio. I did not rerun CI,
  because that would be a GitHub effect.
Patch defect or pre-existing issue: pre-existing. The PR adds about 20 s.
```

### Observations

- **O20-1, the verify step's anonymous-403 check has never been pinned.** Mutant A7b
  (`remote_alpha_upgrade_es.py:1454`) survives all 16 upgrade tests on head, and the same
  mutant survives on base `bf5a760` (Ran, `mutants/A7b-on-base.txt`). In verify_after it
  is followed by `acl_setup("check")`, which refuses a Nomad without ACLs, so it is
  redundant there. The test for A20-2(a) can pin both.
- **O20-2, the writer's known limits hold as described** (Read):
  - ES accepts a symlink as `nomad.root_ca_file`. `os.Open` follows it and the file must
    still be regular.
  - `nomad.base_url` may name any loopback IP.
  - Rollback does not restore Nomad's ACL policies.
  - A new certificate needs its pin in `es.json` and an ES restart. Setup prints the pin.

  None of these weakens the pin.
- **O20-3, issuance replaces three files with three renames** (`nomad_tls_issue`, key,
  then certificate, then CA). A Nomad started between renames would load a mismatched
  pair and fail to start, which fails closed. Setup issues before it writes the config and
  restarts Nomad afterwards. The upgrade issues while Nomad still runs the locked-http
  config, which does not read the TLS directory. So no supported flow opens that window
  (Inference from Read).
- **O20-4, who reads `ca.pem` on the box.** The upgrade's own TLS identity check runs as
  root. The upgrade learns that user `es` can read `/etc/nomad.d/tls/ca.pem` under
  `es.service` only through ES health in `verify_after`, which would fail and roll back
  (fails closed). I found no sandbox directives for `es.service` in the repository. The
  box unit is outside the repository, so this stays Unknown until the box run.
- **O20-5, the author's failure counts were taken in another environment.** The writer
  counted 28 `scripts` failures on head (base 31) on base `2ca76cd`. I see 8 on head and
  the same 8 on base `bf5a760`. The difference is in the environment (user, host
  accounts, paths), not in the code. The claim itself holds (below).

## Validation assessment

All runs: user `ci`, Go 1.26.5, `-count=1`, in this container (4 CPUs). Nomad 2.1.1
unless noted. Evidence is in `tests/`, `mutants/`, `probes/` and `ci/`; method scripts are
in `method/`.

| Run | Result |
| --- | --- |
| `go test ./...` on head `f505f72` (`-timeout 45m`) | 1905 pass, 13 fail, 14 skip (top level); packages `es/app`, `scripts`, `reliablesubmit` fail (`tests/head-f505f72-nomad211-results.tsv`) |
| `go test ./...` on base `bf5a760` | 1890 pass, 13 fail, 14 skip; the same 13 failing names (43 with subtests), the same 14 skips, the same first failure lines (`tests/failing-and-skipped-names.txt`, `tests/failure-reasons-head-vs-base.txt`) |
| `TestBringupScriptUpCheckDownFullProfile`, head, offline image of head's binaries | pass on Nomad 2.1.1 (30.4 s) and 2.0.0 (30.9 s) |
| `TestRemoteAlphaUpgradeES*`, head, Nomad 2.0.0 | 16 of 16 pass, `MovesARealNomadToHTTPS` included (12.2 s) |
| whole `es/app`, head, Nomad 2.0.0 | 220 pass, 2 fail: the bring-up (image build needs the internet) and the mount-witness test (CI environment-only list) |
| CA-file probe, `python3 -I` empty-cafile probe | A20-1, A20-2(c) |
| CI run 45546737121 on `f505f72` | **failed**: `es/app` timeout (A20-3) |

The 13 tests that fail on both head and base. Each is an entry in
`.github/ci/environment-only-tests.txt` unless marked:

- `es/admission/internal/reliablesubmit`:
  - `TestOperationalHandoffSchema4BinaryRefusesSchema5` ("authenticated schema-4 opener is required")
  - `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation` ("authenticated schema-3 production-source probe is required")
  - `TestSQLiteV3OldBinaryRefusesWithoutMutation` ("old PB1 production-source probe is required")
- `es/app`:
  - `TestBringupScriptUpCheckDownFullProfile`. **Not listed**: it fails here only because
    the control-plane image build cannot reach dl-cdn.alpinelinux.org, and it passes with
    the offline image (above) and on CI at trunk.
  - `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` ("mount witness: source envelope is incomplete")
- `scripts`:
  - `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`
  - `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`
  - `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`
  - `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`
  - `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap` (macOS `/private/tmp`)
  - `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition` (needs a host account
    named after the operator's Mac user)
  - `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression` (same)
  - `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap` (same)

The 14 tests that skip themselves are the same 14 that CI lists as skipping itself
(`tests/failing-and-skipped-names.txt`).

Mutants (Ran; each alone in a scratch clone, then restored; the runner is in `mutants/mutants.py`):

| Mutant | Tests run | Result |
| --- | --- | --- |
| A1 config: base_url loopback check removed | es/config | killed |
| A2 config: server_name may be an IP | es/config | killed |
| A25 config: http base_url accepted | es/config | killed |
| A3 CA loader: PEM headers accepted | es/admission | killed |
| A21 ES pin comparison disabled | es/admission (same CA, another key) | killed |
| A21b the same | es/app, real Nomad and real ES | killed |
| A20 reliable-submit provider back to TLS 1.2 | es/admission | killed |
| A4 ACL tool: port-holder check after the TLS handshake | es/app | killed |
| A18 ACL tool: CA symlink followed | es/app | killed |
| A5 posture: RPC upgrade mode not checked | es/app | killed |
| A11 shell helpers: `--tlsv1.3` dropped | es/app | killed |
| A19 supported-local setup: CA symlink accepted | es/app | killed |
| A9 setup: CA without `pathlen:0` | es/app | killed |
| A23 setup: renewal window ignored | es/app | killed |
| A24 observer policy without `list-jobs` | es/app, real Nomad | killed |
| A22 identity tool: pin not compared | es/app | killed |
| A8c identity tool: TLS 1.2 allowed | es/app | killed |
| A12c proof fetch: TLS 1.2 allowed | es/app | killed |
| A6 upgrade: TLS directory file set not checked | scripts | killed |
| A13 upgrade: backup's created list not checked | scripts | killed |
| A7, A7w upgrade check: migrated host's anonymous 403 not checked | scripts, all 16 upgrade tests | **survived** (A20-2a) |
| A8, A8w identity tool: loopback not checked | es/app | **survived** (A20-2b) |
| A12, A12w, A12b proof fetch: CA symlink followed / CA check removed | es/app | **survived** (A20-2c) |
| A7b upgrade verify: anonymous 403 not checked | scripts; also on base | **survived on head and base** (O20-1) |

The first A21 did not compile (an unused variable). I rewrote it as `&& false` and it was
killed. Altogether 28 distinct mutants: 20 killed, 8 survived, covering 4 sites.

Not run:
- `-race`;
- `go build` and `go vet` locally (CI's Build, Vet and macOS Vet steps passed on `f505f72`);
- the 9 root-only `scripts` tests and CI's "Listed tests pass as root" step (skipped on
  the PR run);
- a CI rerun;
- anything on the box.

## Sensitive-material handling

All TLS material, Nomad tokens and ACL secrets were test-generated in temporary
directories that the tests removed. The evidence holds:
- test names, results and durations;
- first failure lines, with one host account name replaced;
- mutant logs;
- public CI log excerpts.

A scan of the evidence for UUID-shaped strings, "SecretID" values and token headers found
none (the only matches are test names). No personal data left the container.

## Remaining uncertainty and stop conditions

- A20-3: whether a normal-speed runner passes `es/app` at `f505f72` is Inference. The next
  CI run settles it.
- O20-4: the box's `es.service` sandbox is Unknown until the box run.
- Root ownership on the box and the root-only tests were not reproduced here. CI's root
  step did not run on the PR.
- No multi-server Nomad, and no certificate rotation on a running ES (out of scope).

## Confidence

- Provenance: high.
- Validation: high for the claims checked: same failing names on head and base, real
  Nomad on both versions, bring-up with an offline image. Medium for CI timing (A20-3).
- Implementation: high that the HTTPS lock and the pin hold. 20 mutants on the security
  checks are killed, and the surviving ones are second guards or fail-closed checks.

## Effect status

No repair, commit, push, PR comment, review, merge or CI rerun. Nothing outside this
container changed.

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/nomad-acl/20-pr60-audit.md`; its sha256 is
in the delivery message. Evidence checksums are in `20-pr60-audit-evidence/SHA256SUMS.txt`.

## Final verdict

**BLOCK**

To close it:

- A20-1: make the CA loader refuse text and skipped blocks, with the three test cases
  (or narrow the comment, the docs and the report to the code).
- A20-2: one test case per check (a), (b) and (c), each failing on its mutant. The test
  for (a) can also pin the verify step's check (O20-1).
- A20-3: green "build, vet and test" on the new head. A CI-only PR for an explicit gate
  timeout is recommended, separately.
- Then a diff-only check of the new commits. The Fable red-team can run on the current
  head in parallel, since none of these changes touch the TLS design.
