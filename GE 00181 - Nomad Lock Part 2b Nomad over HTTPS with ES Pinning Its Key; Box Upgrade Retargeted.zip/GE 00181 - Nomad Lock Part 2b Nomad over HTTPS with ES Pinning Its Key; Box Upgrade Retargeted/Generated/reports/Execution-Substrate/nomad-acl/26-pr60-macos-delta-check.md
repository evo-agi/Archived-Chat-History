# Delta check of ES PR #60 (Nomad lock part 2b), 977b172 to 4795a4f: the merge of #59 and the macOS list lines

Verdict: **BLOCK** on one Low finding, A26-1. Everything the coordinator asked
me to verify holds. The repair is one line of the macOS list (or a port), then
a diff-only check and green `go` and `go-macos` runs.

- **A26-1 (Low, false coverage on macOS).** The subtest "the TLS key is
  readable by others" of `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`
  stays in the macOS gate and passes there without reaching the key-mode check
  it is named for. The list's own comment says so (lines 104-106). The rule
  that the macOS list adopts says such a subtest must not stay in the gate,
  and audit 30 already rated the same pattern Low (A30-1). I reproduced it: a
  copy of the test that never makes the key readable passes under a
  macOS-like `stat` and fails on plain Linux.
- **No product code changed since `977b172`** (Ran, Read). The 11 delta paths
  are CI files, docs, the README and test files. 57 of the 58 manifest records
  that audits 22 and 23 accepted are byte-identical at `4795a4f`. The 58th is
  the test file that #59 and #60 both touch. All the product code is identical,
  so the red-team of `977b172` (report 24) covers this head's product bytes.
- **The merge is clean** (Ran). `c951578` is git's own merge of `977b172` and
  `819f712`: `git merge-tree` gives exactly its tree. What it adds is #59's
  patch, and #60's own patch is unchanged. The only differences are blob ids
  and one hunk offset in the shared test file.
- **Each list entry's first failure on the macOS runner is the stated reason**
  (Read, Ran). On the runner, all 21 failing tests and subtests fail at
  `nomad_tls_material_ok` (`scripts/70_linux_setup.sh:327-345`). Its first
  check that can fail on macOS is GNU `stat -c '%a'` at line 335, before any
  `openssl` call. I then ran the six tests on Linux with a stand-in `stat` that
  only refuses `-c`, as macOS's does. It reproduces the runner exactly: all 67
  pass/fail verdicts and all 21 first failure lines (file:line and message).
- **The gate still fails on a passing listed test or an unlisted failure**
  (Read, Ran). The gate files are byte-identical to trunk_dev, which audits 30
  and 32 checked. On `d01ec38`, before these lines, the unlisted failures failed
  the step "Test". With the six new entries on Linux (where they pass),
  `still-failing` exits 1 and names each one twice. With the macOS-like `stat`
  it exits 0.
- **CI on the exact head tree** (Read). Both runs checked out merge ref
  `ef65c13`, whose tree `d61cd804` is the tree of `4795a4f`.
  - "test on macOS" (run 45575231690) succeeded. 28 entries, all still failing;
    81 self-skips, all listed, among them `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS`
    with its stated reason. The observed run skipped exactly the 28 entries.
  - "build, vet and test" (run 45575231725) succeeded. Every step passed,
    the real-Nomad upgrade test included: the Linux list names no upgrade
    test, and the gate accepts no unlisted skip.

Every statement is marked **Ran** (I executed it and saw the output),
**Read** (I read code, docs or logs) or **Inference** (reasoned from cited
facts, not observed directly). Evidence paths are relative to
`26-pr60-macos-delta-check-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Repository / audit target

- Repository: evo-agi/Execution-Substrate, draft PR #60 into `trunk_dev`,
  branch `claude/project-thread-9slgp8`.
- Base: `819f712cde8fd83f5b73b2154263afa18cf29623` (#59). It is trunk_dev, the
  merge-base and the PR's base on GitHub (Ran: `git fetch` at 08:34Z,
  `git ls-remote` at 09:01Z; Read: GitHub API at 08:35Z).
- Topic: `4795a4f3ce5c1c5135de83e73181e3b0e12e47d1`, tree
  `d61cd804d1493fcc4130eea674232e19a467a3d8`. It is the PR head on GitHub and
  the pushed tip, unchanged from 08:34Z to 09:01Z (Ran, Read).
- Delta under review: `977b172` (accepted by diff check 23, red-teamed in
  report 24) to `4795a4f`. That is 3 commits and 11 paths:
  - `c951578`, the merge of trunk_dev `819f712` (#59);
  - `d01ec38`, 6 lines in `.github/ci/environment-only-tests-macos.txt`: the
    real-Nomad upgrade test skips itself on macOS;
  - `4795a4f`, 18 lines in the same file: one subtest and five whole upgrade
    tests listed as failing on macOS.
- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked
  against the project copy before each use (Ran).
  - manifest_sha256
    `4f8e0b5071d088817cae28a0543a21e39f6f74c34f112e9c102c14f8500c8b54`
  - textual_diff_sha256
    `d1fb6203eb4534570ed22e9fce1201520f4e0621f65722c361d60da1913a9b8b`
  - 59 paths: #60's 58 and `.github/ci/environment-only-tests-macos.txt`
- No writer manifest or report section for `4795a4f` exists to compare against
  (O26-3). The comparison below is against the accepted `977b172` manifest
  `85b12964…8251` (`23-pr60-diff-check-evidence/provenance/manifest-v2-977b172-opening.json`).
- Scope, from the coordinator: a fresh, read-only delta audit. I had not
  audited #60 before (protocol §14). The asks: no product code changed vs
  `977b172`; the merge is clean; each list entry's first failure on the macOS
  runner is the stated reason; the gate still fails on a passing listed test or
  an unlisted failure; "build, vet and test" and "test on macOS" are green on
  the exact head tree.
- Writer's account: the thread messages of 08:03Z and 08:19Z and the commit
  messages. Report 11 ends at section 14 (`977b172`).

## Audit posture

- Read-only. I committed, pushed and commented nothing on GitHub, and edited
  no PR. No subagents. I did not touch the box or any live service.
- Three trees, all my own: a clone used only for the manifests
  (`prov`), a reading and test clone at `4795a4f` (`es`), and an extracted copy
  for one mutant (`mut`). Both clones had a clean `git status` at the end (Ran).
- Tests ran in this container as root, with Go 1.26.5 (from the Go module
  proxy's toolchain module, which `go` checks against the checksum database),
  `GOTOOLCHAIN=go1.26.5`, `GOFLAGS=-mod=readonly`, OpenSSL 3.0.13. The six
  listed tests pass here as root without any stand-in (Ran, 66 s).

## Provenance reproduction (Ran, `provenance/`)

- The pushed tip equals the head on GitHub. `819f712` is an ancestor of it and
  is the merge-base.
- Setup as in provenance §5.3: branch checked out at the tip, clean;
  `reset --mixed` to the base; upstream pinned to `origin/trunk_dev`;
  `umask 022`.
- Two opening runs (08:38Z) are byte-identical. Two closing runs (09:01Z)
  equal them. The remote tip and trunk_dev had not moved.
- Against the accepted `977b172` manifest:
  - 57 records are byte-identical, among them every product path
    (`es/admission/*.go`, `es/config/config.go`, `scripts/*.sh`,
    `scripts/internal/*.py` and `.sh`, docs, examples, runbooks, PLANS.md);
  - `scripts/remote_alpha_root_service_paths_test.go` differs (63394 to
    63570 bytes): #59 also changed it, and the merge holds both changes;
  - `.github/ci/environment-only-tests-macos.txt` is new to the path set: it
    exists on the base and the PR now changes it.
- No mode-bit difference needed to be tolerated.

## Coverage

### No product code changed (Ran, Read)

`git diff --stat 977b172 4795a4f` names 11 paths:
`.docs/system_overview/go_toolchain_baseline.md`,
`.github/ci/environment-only-tests-macos.txt`, `.github/ci/go_test_gate.py`,
`.github/ci/go_test_gate_selftest.py`, `.github/workflows/go-macos.yml`,
`README.md`, `docs_contract_test.go`, `scripts/remote_alpha_host_firewall_test.go`,
`scripts/remote_alpha_operator_stage_folders_test.go`,
`scripts/remote_alpha_operator_test.go`,
`scripts/remote_alpha_root_service_paths_test.go`. None is product code.

At `4795a4f`, `go_test_gate.py`, `go_test_gate_selftest.py`, `go-macos.yml`,
`go.yml` and `environment-only-tests.txt` have the same blob ids as on
trunk_dev `819f712` (Ran: `git rev-parse <rev>:<path>`). So the gate that
audits 30 and 32 checked for #59 is the gate that runs here.

### The merge (Ran)

- Merge-base of `977b172` and `819f712` is `e2af4b2`.
  `git merge-tree --write-tree 977b172 819f712` = `b4f97a35…` = tree of
  `c951578`. So the merge is git's own, with no hand edit.
- `git diff 977b172 c951578` equals `git diff e2af4b2 819f712` (#59's patch)
  except in `scripts/remote_alpha_root_service_paths_test.go`: the `index`
  line and one hunk header (`@@ -1050,13 +1060,7` against `@@ -1040,13 +1050,7`),
  10 lines further down because #60 added 10 lines above it.
- `git diff e2af4b2 977b172` (#60's own patch before) equals
  `git diff 819f712 c951578` (after) except the same file's `index` line and
  one hunk header (`@@ -850,9 +850,19` against `@@ -860,9 +860,19`).
- `git diff 977b172 4795a4f` equals #59's patch plus the 24 list lines of
  `d01ec38` and `4795a4f`, with the same two differences.

### The list entries, one by one (Read, Ran)

The upgrade checks the TLS material it issues, and the material on a host it
reads, with the setup's `nomad_tls_material_ok`
(`scripts/internal/remote_alpha_upgrade_es.py:1048-1049`, which runs
`scripts/70_linux_setup.sh:327-345`). That function checks, in order: three
files present, not links and owned by the caller (lines 332-334); the key's
mode through `stat -c '%a'` (line 335); then the `openssl` checks (lines
336-342) and the key match (343-344). macOS's `stat` has no `-c` (the same
host difference as the base list's `stat -c %U` group, audit 30's A30-2). It
is the only `stat -c` on the upgrade's path: none in
`remote_alpha_upgrade_es.py`, `remote_alpha_upgrade_es.sh`, the host test,
`nomad_acl_setup.sh`, `nomad_acl.sh` or `nomad_tls_identity.py` (Ran: grep).

First failures on the runner (Read: run 45572903953, job 139063663532, head
`d01ec38`, image macos-26-arm64 20261117.0516.1; `ci/macos-d01ec38-job139063663532-extract.txt`):

- `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor/TLS_material_was_issued_but_nothing_else_moved`:
  `remote_alpha_upgrade_es_host_test.go:1164`, the shape says "Nomad's TLS
  directory: present, but its material fails the setup's nomad_tls_material_ok"
  where the test expects `https (`. Its 41 sibling subtests passed.
- `TestRemoteAlphaUpgradeESApply`: `:1239` apply exited 1, `Refusal("Nomad's
  new TLS directory is present, but its material fails the setup's
  nomad_tls_material_ok"); rolling back`.
- `TestRemoteAlphaUpgradeESApplyRollsBackOnFailure`: all 9 subtests fail.
  Eight at `:1495` with that refusal as the rollback's cause, where each
  expects a later step's failure. `ES_does_not_start` at `:1487`, with the same
  refusal in its output.
- `TestRemoteAlphaUpgradeESApplyRollsBackWhenInterrupted`: all 3 subtests at
  `:1534`, "apply never reached validating" or "acl-running", with the same
  refusal in the output.
- `TestRemoteAlphaUpgradeESRollbackFailuresAreReported`: all 5 subtests, at
  `:1583`, `:1594` and `:1609`. The log shows the refusal only as "apply
  failed; result rolled_back". The simulation below gives the same lines.
- `TestRemoteAlphaUpgradeESApplySurvivesALostSession`: both subtests at
  `:2228`, `session driver: {"reached": false, "exit": 1}`. The log does not
  show the cause. The simulation gives the same line.

Simulation (Ran, `sim/`): the six tests on Linux at `4795a4f` with
`sim/bsdstat-stat.sh` first on `PATH`. That stand-in refuses `-c` with
macOS's message and passes every other call to GNU `stat`. The tests' fake
host keeps the caller's `PATH` after its own fakes
(`remote_alpha_upgrade_es_host_test.go:598`).
- Verdicts: 67 pass/fail lines for these six tests and their subtests,
  identical to the runner's (`sim/linux-bsdstat-upgrade-test-verdicts.txt`,
  `ci/macos-d01ec38-upgrade-test-verdicts.txt`, `diff` empty).
- First failure line of each of the 21 failing tests and subtests: same file,
  line and message as on the runner, temporary paths masked
  (`sim/first-failure-macos-vs-linux-bsdstat.tsv`, 21 of 21 equal).
- Without the stand-in, the six pass here.

So on the runner every listed test fails at `stat -c` in
`nomad_tls_material_ok`, as the list says (Inference from the order of checks
in the function plus the exact match of the simulation; the runner's log does
not print the function's own error).

The `skips-itself` line for `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS`:
the test calls `t.Skip("the box's Nomad client config is Linux's")` when
`runtime.GOOS != "linux"`, before it looks for `nomad` or `sudo`
(`remote_alpha_upgrade_es_host_test.go:1736-1739`, Read). The `4795a4f` run
shows `skips itself: … remote_alpha_upgrade_es_host_test.go:1738: the box's
Nomad client config is Linux's` (Read).

### Does the gate still fail on a passing listed test or an unlisted failure? (Read, Ran)

- **Unlisted failure.** On `d01ec38` (before the six entries) the step "Test"
  failed with `##[error]test gate failed: execution-substrate/scripts`, and
  "Listed tests still fail" did not run (Read).
- **Passing listed test.** `go_test_gate.py still-failing` with only the six
  new entries (`sim/list-new6.txt`), on Linux at `4795a4f`:
  - plain Linux, where they pass: exit 1, 12 errors. Each entry is named as
    "listed test no longer fails on this host (it passes)" and as "listed
    test does not fail in the run of its package (it passes)" (Ran,
    `sim/still-failing-plain-summary.txt`, 08:54-09:01Z);
  - with the macOS-like `stat`: exit 0, "all 6 listed tests still fail on
    this host, each in a run of its own and in the run of its package" (Ran,
    `sim/still-failing-bsdstat-summary.txt`, 08:45-08:54Z).
- **The subtest entry stands for itself alone.** On the `4795a4f` runner the
  observed run passed and "go test skipped exactly the listed tests of this
  package (28), each once" (Read).
- **What the list cannot catch** is a test that passes for the wrong reason.
  That is A26-1.

### Docs and other surfaces

- The list's comments for the new lines (lines 96-106 and 165-169 of the file
  at `4795a4f`) give the reasons that the evidence above supports, with the
  box code's path. They mention only `stat -c`, not `openssl` (O26-1).
- `.docs/system_overview/go_toolchain_baseline.md` and `docs_contract_test.go`
  come byte for byte from #59. No doc names the upgrade tests, so none goes
  stale (Read).

## Findings

```text
AUDIT FINDING
ID / Type / Severity: A26-1 / test/doc gap (false coverage on macOS) / low
Current contract: .github/ci/environment-only-tests-macos.txt:5-6 adopts "the format and the rules" of
  environment-only-tests.txt, whose lines 71-75 say: "The first two tests are listed whole on purpose,
  although some of their subtests pass on the runner. [...] a subtest that expects a refusal passes there
  without reaching the custody check it is named for. Keeping those subtests in the gate would claim a check
  that does not happen." go_toolchain_baseline.md:195-197: "A green macOS run is validation evidence that the
  tests of those packages that its list does not name pass on that runner image." Audit 30 rated the same
  pattern Low (A30-1), and #59 fixed it before merging.
Path and line: scripts/remote_alpha_upgrade_es_host_test.go:1037-1040 (subtest "the TLS key is readable by
  others"); .github/ci/environment-only-tests-macos.txt:104-107 at 4795a4f.
Evidence: the subtest makes the issued key mode 0644 and asserts only the generic shape text "Nomad's TLS
  directory: present, but its material fails the setup's nomad_tls_material_ok". On macOS that function
  fails at stat -c (scripts/70_linux_setup.sh:335) for any material, sound or not. The list's own comment
  (lines 104-106) says the subtest "passes on macOS, though not for the reason it is named for". Reproduced
  (sim/key-mode-subtest-runs.txt, mutant sim/key-mode-subtest-mutant.diff removes only the chmod):
    A. audited bytes, plain Linux: PASS;
    B. audited bytes, macOS-like stat: PASS;
    C. mutant, plain Linux: FAIL at :1163, the mutant's line for :1164 (the material is accepted, as it should be);
    D. mutant, macOS-like stat: PASS.
  So on the macOS runner the subtest passes whether or not the key is readable by others.
Impact: the green macOS job counts a key-mode refusal that does not happen there. No production impact: the
  check is box-side and go.yml tests it for real on Linux.
Required correction (either):
  1. Replace line 107 with the whole test, as the list does for the two "ds" tests:
       execution-substrate/scripts TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor
     and reword lines 103-106 to say why it is listed whole. The whole test fails on the runner (its
     TLS_material subtest does), so "Listed tests still fail" holds. Cost: macOS no longer runs its other
     41 subtests, which all exercise box-only code that go.yml runs. No product code changes.
  2. Or make the key-mode check in nomad_tls_material_ok portable. That keeps macOS coverage but changes
     product code that report 24 red-teamed, and the openssl checks after it are unproven on macOS (O26-1),
     so it may take more than one macOS run.
  I recommend 1.
Uncertainty: none for this subtest. No other test in ./scripts expects the material check to refuse: the
  only other callers of issueTLS are the two sibling subtests at :1031 (listed) and :1033 (refused earlier,
  by the directory's mode at remote_alpha_upgrade_es.py:1043-1044, so it reaches its own check on macOS).
  Every other path to the check goes through apply, and those tests are listed whole.
Patch defect or pre-existing: patch (this delta's list lines; the subtest itself is from #60).
```

Observations (none blocking):

- **O26-1: `openssl -checkhost`/`-checkip` on macOS is Unknown.** The
  coordinator's brief and the writer's 08:19Z message name it as a possible
  reason. On the runner it is never reached, because `stat -c` at line 335
  fails first. The list text names only `stat -c`, which is accurate.
  Inference: the runner's `openssl` did issue the material (`genpkey`,
  `req -addext`, `x509 -req`, `verify`), because `nomad_tls_issue` creates the
  directory only after every `openssl` step succeeds, and the runner reports
  the directory "present". What would settle it: a macOS run with the mode
  check ported.
- **O26-2: macOS no longer runs any of the upgrade's apply path.** The writer
  states this cost. It fits the list's rules, because the code is box-only and
  `go.yml` runs it. A port of the mode check (A26-1 option 2) would show
  whether more of it can run on macOS.
- **O26-3: no implementation report covers this delta.** Report 11 ends at
  section 14 (`977b172`), and no manifest for `4795a4f` was delivered. The PR
  description's history ends at "trunk_dev merged (`977b172`)" and does not
  mention the #59 merge or the macOS list lines. Protocol §14 and provenance
  §13 expect both before the merge gate. The manifest above can serve as the
  reference: `4f8e0b50…8b54`.
- **O26-4:** the `go` run on `d01ec38` (45572903906) was cancelled when
  `4795a4f` was pushed (the workflow's concurrency rule). So `d01ec38` has no
  Linux result. That does not matter, because `4795a4f` is the head.

## Validation assessment

Re-run here (Ran):
- the six listed tests on Linux at `4795a4f`, plain: pass (66 s);
- the same with the macOS-like `stat`: the runner's 67 verdicts and 21 first
  failure lines, exactly;
- the key-mode subtest, four runs (A26-1);
- `go_test_gate.py still-failing` with the six entries, plain (exit 1) and
  with the macOS-like `stat` (exit 0);
- v2 manifest, twice at opening and twice at closing.

Read, not re-run:
- macOS run 45572903953 on `d01ec38` (failure; the 21 failures above);
- macOS run 45575231690 on `4795a4f` (success);
- Linux run 45575231725 on `4795a4f` (success).

Not done: no macOS host here, so the macOS verdicts come from the runner's
logs, and the cause of each failure from the simulation plus the order of
checks in the code. I did not re-run the whole `scripts` package except inside
the two `still-failing` runs, and I did not re-run any part of #60 outside the
upgrade tests: the product bytes are identical to the head that audits 22 and
23 and the red-team checked.

## CI on the head (Read)

- Both runs checked out `ef65c13fd9ea96b579d3b67273be5913df4f6fd4`, "Merge
  4795a4f… into 819f712…". Its tree `d61cd804…` equals the tree of `4795a4f`
  (Ran: `git fetch refs/pull/60/merge`). So CI tested the audited bytes.
- "test on macOS", run 45575231690, job 139071418401, 08:19:14Z to 08:48:45Z,
  success. macOS image macos-26-arm64 20261117.0516.1, go1.26.5 darwin/arm64.
  - "Check the test gate": success.
  - "Test": `execution-substrate/scripts` ok (386 s, and 399 s in the observed
    run); "test gate passed: 2 packages, 1 of them with skipped entries (28
    entries); 81 tests skipped themselves, all of them listed".
  - "Listed tests still fail": "all 28 listed tests still fail on this host,
    each in a run of its own and in the run of its package". The six new
    entries each appear as "still fails".
  - Extract: `ci/macos-4795a4f-job139071418401-extract.txt`.
- "build, vet and test", run 45575231725, job 139071550884, 08:19:14Z to
  09:05:29Z, success. go1.26.5 linux/amd64.
  - Build, Vet and "Vet for macOS": success.
  - "Test": "test gate passed: 49 packages, 3 of them with skipped entries
    (17 entries); 14 tests skipped themselves, all of them listed". Every
    `go test` line carries `-timeout=20m`. `execution-substrate/scripts` took
    410.7 s and `es/app` 451.9 s (38% of the limit).
  - The Linux list (`environment-only-tests.txt`, unchanged) names no
    upgrade test, so `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` and the
    six macOS entries ran and passed on Linux; a skip of the real-Nomad test
    would have failed the gate (Inference from the gate's rule plus the
    green step).
  - "Listed tests still fail": "all 17 listed tests still fail on this host".
    "Listed tests pass as root": success.
  - At job end the runner ended 2 orphan `nomad` processes (pids 240694 and
    240777). This is O23-5 again, unchanged by this delta.

## Sensitive-material handling

No secrets were read or printed. The published extracts hold test names, file
lines and refusal text only. I checked them for `@` (a scripts subtest name
holds a user@host) and private addresses: none. Full job logs stay on GitHub.

## Remaining uncertainty and stop conditions

- Unknown whether the `openssl` checks of `nomad_tls_material_ok` pass on
  macOS (O26-1). It matters only for option 2 of A26-1.
- If the head or trunk_dev moves before the repair, the next head needs its
  own check. A repair that touches only the macOS list needs a diff-only check
  and green `go-macos` and `go` runs. A port of the mode check (option 2) is a
  product change and needs a fresh correctness audit of that change. Whether
  it also needs a red-team is the coordinator's call.

## Confidence

- Provenance: high. Manifest stable twice at opening and closing; the PR's
  bytes are traced to the accepted manifest record by record; CI ran on the
  head's tree.
- Validation: high. The macOS claims rest on the runner's logs plus an exact
  simulation; both CI runs on the head tree are green; I ran the six tests
  and the gate's `still-failing` mode here.
- Implementation: high. The delta changes no product code; the list lines are
  correct apart from A26-1.

## Effect status

No repair, commit, push, PR edit, comment or merge performed. The box was not
touched.

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/nomad-acl/26-pr60-macos-delta-check.md`,
SHA-256 in the thread reply. Evidence:
`26-pr60-macos-delta-check-evidence/` with `SHA256SUMS.txt`.

Final verdict: **BLOCK** (A26-1, Low; standing rule: Low findings are fixed
in the PR).
