# Diff-only check of ES PR #60 (Nomad lock part 2b: Nomad over HTTPS), dfb2873 to 977b172

Verdict: **ACCEPT** for the delta `dfb2873..977b172` (the A22-1 repair and the
merge of trunk_dev `e2af4b2`). No finding at Low or above. Five observations,
none blocking.

**Before #60 can merge, trunk_dev has moved.** #59 (a macOS test gate for
`./scripts/...`) merged at 07:38:57Z as `819f712`, after this head's CI
started. #60 needs another update merge:
- It is clean in a trial (`git merge-tree`), but it touches one of #60's 58
  paths, so the sync-only shortcut does not apply as it stands.
- #60's new `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` skips itself on
  macOS and is not in #59's macOS list. So the first `go-macos` run on #60
  should fail until the list names it (Inference from the gate's rule).

So the next head needs an auditor delta check and green `go` and `go-macos`
runs. Details are under "Remaining uncertainty and stop conditions".

- **A22-1 is fixed** (Read, Ran). On a host already moved to HTTPS, `check` and
  `apply` now also require a request without a token for
  `GET /v1/acl/policy/anonymous` to answer 404. That is the request that ES's
  own gate, `nomad_acl.sh` and `nomad_acl.py` already make. `verify_after`
  makes it too, after `apply` and before `nomad_acl_setup.sh check`. The docs
  say what the in-place check does and does not run.
- **The three new tests fail when the check is removed** (Ran). I ran 8
  mutants against the three tests, on real Nomad 2.1.1 where a test needs it.
  The mutant that removes the check (M1) fails all three. A stricter one (M1b)
  still makes the request but ignores the answer. It also fails all three, and
  each test fails at the assertion written for this repair. 7 of 8 mutants are
  killed. The survivor turns the 404 allowlist into a "200 is bad" denylist.
  On this path it behaves the same, because other checks catch every other
  answer (O23-1).
- **The trunk_dev merge brings in nothing else** (Ran). `977b172` is git's own
  clean merge of `fe5119b` and `e2af4b2`: `git merge-tree` gives exactly its
  tree. What the merge adds to the PR is byte for byte #61's patch. #60's own
  patch against its base is byte for byte the same before and after the merge.
  `e2af4b2`'s tree equals the tree of #61's audited head `af266dc`.
- **The writer's "28 scripts tests fail identically on base" holds** (Ran). On
  head `977b172` and on the real base `e2af4b2`, the same 28 top-level tests
  fail in this container, with the same first failure line and line number.
  The names are under "Validation assessment". The writer compared against
  `2ca76cd`, which is not the PR's base (O23-2). I then installed what CI's
  runner has: `openssh-client`, `uuid-runtime`, `acl`, `iproute2` and the
  `en_US.UTF-8` locale. After that only the 8 tests listed in
  `.github/ci/environment-only-tests.txt` still fail, on head and base alike.
- **Nomad 2.0.0, the box's version** (Ran). The real-Nomad upgrade test passes
  on Nomad 2.0.0 too, including the new anonymous-policy steps. A logging
  wrapper shows that the 2.0.0 binary ran. Audit 22 could only infer this
  (O23-3).
- **CI is green** (Read). Run 45565423373 on `977b172` succeeded from
  07:05:27Z to 07:51:48Z.
  - It is #60's first run with #61's 20-minute limit, and every `go test`
    line carries it.
  - `es/app` took 458.6 s, 38% of the limit.
  - At this head there was no macOS test job to wait for: `go.yml` has only
    the "Vet for macOS" step, which passed.
  - The runner ended 3 orphan `nomad` processes at job end, where trunk_dev's
    runs end none. I could not reproduce or locate this here (O23-5).

Every statement is marked **Ran** (I executed it and saw the output),
**Read** (I read code, docs or logs) or **Inference** (reasoned from cited
facts, not observed directly). Evidence paths are relative to
`23-pr60-diff-check-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Repository / audit target

- Repository: evo-agi/Execution-Substrate, draft PR #60 into `trunk_dev`,
  branch `claude/project-thread-9slgp8`.
- Base: `e2af4b27ad8ab443084c90bb9113ed1204fbdf69`. It is trunk_dev (#61), the
  merge-base, and the PR's base on GitHub (Ran: `git fetch` at 07:09Z and
  07:37Z; Read: GitHub API at 07:12Z).
- Topic: `977b172a70604e78cd12c21998114888a766ebd9`, tree
  `0391c6fca4961f4f21593dbd0005f73eef4d73ee`. It is the PR head on GitHub and
  the pushed tip (Ran, Read).
- Delta under review: `dfb2873` (re-audited in report 22) to `977b172`. That
  is 2 commits and 8 paths:
  - `fe5119b`, the A22-1 repair, 3 paths:
    - `scripts/internal/remote_alpha_upgrade_es.py`;
    - `scripts/remote_alpha_upgrade_es_host_test.go`;
    - `.docs/system_overview/remote_supported_host_alpha.md`.
  - `977b172`, the merge of trunk_dev `e2af4b2` (#61), 5 paths, none of them
    among #60's 58.
- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`. I
  checked it against the project copy before each use (Ran).
  - manifest_sha256
    `85b129642926ee51297cdaf339f74cf98c7efb7ac9363962d5ae5225d7c58251`
  - textual_diff_sha256
    `7b179f84987b3a6465e007a305dda2b9f0a2707370e7974a7ad464730da8d238`
  - 58 paths, the same set as at `dfb2873`
- Scope, from the coordinator: a fresh, read-only, diff-only audit of
  `dfb2873..977b172`. I had not audited #60 before (protocol §14). The asks:
  - verify the A22-1 fix;
  - show that the three new tests fail when the check is removed;
  - show that the trunk_dev merge brought in nothing else;
  - check the writer's claim about 28 `scripts` failures, and list the names;
  - wait for CI run 45565423373, and a macOS test if one runs.
- Writer's report: `11-part2b-nomad-https.md`, section 14.

## Audit posture

- Read-only. I committed, pushed and commented nothing on GitHub, and edited
  no PR. I used no subagents. I did not touch the box or any live service.
- Tests ran in this container as user `ci` (uid 1500, gid 1600, group docker),
  with passwordless sudo as the CI runner's user has. The environment was
  emptied (`env -i`), with Go 1.26.5, `GOTOOLCHAIN=local`,
  `GOFLAGS=-mod=readonly`, `GOPROXY=off` and umask 022 (`method/rungo.sh`).
  - Go 1.26.5 came through the Go module proxy's toolchain module, which the
    `go` command checks against the checksum database. go.dev's own download
    was refused by this container's proxy.
  - Nomad 2.1.1 was checked against the workflow's SHA-256 pin. Nomad 2.0.0
    was checked against HashiCorp's SHA256SUMS file, not its signature.
  - Docker 29.9.3 had `alpine:3.20` and `python:3.13-alpine`, pulled by the
    workflow's digests.
- Each tree was a separate clone of my own: `/home/ci/es-head` at `977b172`,
  `/home/ci/es-base` at `e2af4b2`, and `/home/ci/mut` for the mutants. The
  mutants ran one at a time. The file was restored with `git checkout` after
  each, and the tree was clean at the end (Ran). The audit tree
  `/home/user/Execution-Substrate` was used only for the manifests and for
  reading.

## Provenance reproduction (Ran, `provenance/`)

- The pushed tip equals the reported tip. `e2af4b2` is an ancestor of it and
  is the merge-base.
- Setup as in provenance §5.3:
  - branch `claude/project-thread-9slgp8` checked out at the tip, clean;
  - `reset --mixed` to the base;
  - upstream pinned to `origin/trunk_dev`;
  - `umask 022`.
- Two opening runs (07:09Z) are byte-identical. They also equal the writer's
  `11-evidence/manifest-v2-977b172.json`.
- Two closing runs after all tests and mutants (07:37:06Z) are byte-identical
  to the opening ones. The remote tip and trunk_dev had not moved.
- No mode-bit difference needed to be tolerated.

## Coverage

- Read in full: the delta `dfb2873..fe5119b` (`delta/fix-dfb2873-fe5119b.diff`):
  - `anonymous_nomad_problems`, `inspect_migrated` and `verify_after`;
  - the fake curl's new `/v1/acl/policy/anonymous` branch and its
    `anonymous-policy` marker;
  - the new cases in `TestRemoteAlphaUpgradeESApply` and
    `TestRemoteAlphaUpgradeESApplyRollsBackOnFailure`, and the new
    real-Nomad steps in `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS`;
  - both doc edits.
- Read for context:
  - the helpers that the repair calls: `curl_status`, `nomad_curl_args`,
    `nomad_https_addr`, `run`, `tls_identity_check`, and the `onlyReads` test
    helper;
  - the three places that already make the same request: ES's gate
    `es/admission/nomad_access.go:196-207`, `scripts/internal/nomad_acl.sh:110-111`
    and `scripts/internal/nomad_acl.py:585-593`. Each refuses unless the answer
    is 404.
- The merge: the 5 #61 paths, read as a diff against `fe5119b`. Their
  correctness is #61's audit (`ci-gate-time-limit/02-pr61-audit.md`). I
  checked only that they arrived byte for byte.
- Read: audit 22 (report and finding); the writer's section 14; the PR body;
  CI run 45565423373 through the GitHub API.
- Not read again: the rest of the base-to-tip range. Audits 20, 21 and 22
  covered it, and this check is diff-only by brief. The provenance above
  still covers all 58 paths.

## Findings

### Patch defects

None at Low or above.

### Pre-existing issues

None new.

### Observations

```text
AUDIT FINDING
ID / Type / Severity: O23-1 / test gap / observation
Current contract or strategic target: the lock's contract "no anonymous policy" (PLANS.md,
  contracts.md); the upgrade's migrated path must refuse anything but a 404.
Path and line: scripts/internal/remote_alpha_upgrade_es.py:821-823 (anonymous_nomad_problems)
Evidence: (Ran, mutants/M5.json.gz) Mutant M5 changes `if code != "404":` to `if code == "200":`.
  All three tests still pass. No case gives the policy request an answer other than 200 or 404
  over HTTPS. The fake answers 400 when ACLs are off, but the job-list check blocks that host
  too.
Impact: none today (Inference). On the migrated path, other checks already block every other
  answer:
  - ACLs off: 400 here, and the job list answers 200, which the job-list check blocks.
  - TLS or connection failure: the leader check and nomad_tls_identity.py check block.
  - Nomad without a leader: the leader check blocks.
  On real Nomad, a request without a token for the policy named `anonymous` answers 200 or
  404 (Ran, on 2.1.1 and 2.0.0 through the real-Nomad test). The allowlist in the code is
  the right form, and ES's gate and both ACL tools use the same one. Only a future edit to a
  denylist would go unnoticed.
Required correction: none required. Optional: a fake-curl marker that answers 500 to the policy
  request on a migrated host, with check expected to block.
Uncertainty: none.
Patch defect or pre-existing issue: patch (new code); observation only.
```

```text
AUDIT FINDING
ID / Type / Severity: O23-2 / report-only uncertainty (writer's report accuracy) / observation
Current contract or strategic target: the writer's section 14, "Whole scripts: 28 tests fail.
  The same 28 fail on base 2ca76cd in the same container: this container has no ssh or scp,
  which the operator tests need, and the rest are entries of environment-only-tests.txt."
Path and line: 11-part2b-nomad-https.md section 14; the PR body's "Tests" item.
Evidence: (Ran) The count and the set hold against the real base e2af4b2. 2ca76cd is two
  trunk merges older (#58 and #61), and #58 changed TLS-collector files in the scripts
  package. The cause list is incomplete:
  - PostContactRefusals fails on a missing /usr/bin/uuidgen (package uuid-runtime);
  - the two ByteStable matrix tests fail for lack of the en_US.UTF-8 locale. With
    ssh, scp and uuidgen installed they still fail; with the locale generated they pass,
    on head and base.
  After installing what CI's runner has, only the 8 listed entries fail.
Impact: none on the PR. The writer's conclusion (no failure caused by #60) is right.
Required correction: none. Name the right base in later reports.
Uncertainty: none.
Patch defect or pre-existing issue: report only.
```

- **O23-3, Nomad 2.0.0 confirmed.** Audit 22 observed A22-1 on Nomad 2.1.1
  only. `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` passes against Nomad
  2.0.0 as well. A logging wrapper recorded `agent -config` and
  `config validate` going to the 2.0.0 binary (Ran,
  `tests/real-nomad200w.json.gz`, `tests/nomad200-calls.log`). Its new steps
  showed on 2.0.0 that an anonymous policy for `es-submit-v1`:
  - opens `GET /v1/jobs?namespace=es-submit-v1` to requests without a token;
  - leaves `GET /v1/jobs` at 403;
  - makes the policy request answer 200;
  - and that `check` passes again once the policy is deleted.
- **O23-4, the in-place check is narrower than the ACL tool's check, and now
  says so.** On a migrated host, `check` verifies:
  - a named leader;
  - ES's TLS identity check;
  - the anonymous job list (403) and the anonymous policy (404).

  It does not run `nomad_acl_setup.sh check`, which creates and deletes
  short-lived probe tokens. That tool's checks of other policies, tokens and
  auth methods therefore do not run on this path. The doc paragraph now says
  this in words (Read: `remote_supported_host_alpha.md`, "These requests only
  read: `nomad_acl_setup.sh check` is not run here"). That keeps `check`
  read-only, as its contract says. The box run plan (report 11, section 11,
  step 4) runs the ACL tool's `check` separately. Recorded, not a defect.

```text
AUDIT FINDING
ID / Type / Severity: O23-5 / test/artifact gap (test hygiene), source unknown / observation
Current contract or strategic target: tests clean up what they start (no leftover agents).
Path and line: unknown; somewhere in what CI runs on #60.
Evidence:
  (Read) At the end of the job, the runner's "Cleaning up orphan processes" ended 3 `nomad`
  processes in run 45565423373 at 977b172 (pids 90820, 90903, 202273). It ended 2 in run
  45555027151 at dfb2873. It ended none in the trunk_dev runs 45539140560 (bf5a760) and
  45562856874 (e2af4b2), whose logs end at that line.
  (Ran) I could not reproduce it in this container. No `nomad` process was left after any of:
  - the whole scripts package on head and base;
  - the 16 upgrade tests;
  - the real-Nomad upgrade test on 2.1.1 and 2.0.0, and the 8 mutants;
  - the 18 es/app tests matching NomadACL|NomadTLS|NomadSupported|Placement|LoosenedNomad|
    NomadBootstrap on head, with Docker up;
  - the listed witness test TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity
    on head and base, with Docker up.
  The log names only the pid and the process name.
Impact: none on CI: the job is green, and the runner ends them. On a developer machine or the
  Mac, where `scripts` tests also run, a leftover Nomad could hold a port or keep a data folder
  busy. Unknown whether that happens.
Required correction: none as a merge condition from this check. Suggest that the red-team, or
  the writer's next round, run the gate's steps in a CI-like container and list `pgrep -a nomad`
  after each package (the whole es/app package, the "Listed tests still fail" reruns and the
  root step are the ones not yet ruled out here).
Uncertainty: the source; and whether it shows on every run (2 samples each side).
Patch defect or pre-existing issue: Inference: introduced by #60 at some head up to dfb2873,
  not by this delta (the count was already 2 at dfb2873).
```

## Fix verification (Ran)

| What | Result |
| --- | --- |
| Code | `anonymous_nomad_problems()` makes two token-less requests over HTTPS with the same curl options as before (TLS 1.3, only Nomad's CA, `--noproxy '*'`, 5 s): `/v1/jobs` must answer 403 and `/v1/acl/policy/anonymous` 404. `inspect_migrated` blocks once per problem; `verify_after` refuses with both joined, before `acl_setup("check")` (Read) |
| Same rule as the rest of the lock | ES's gate, `nomad_acl.sh` and `nomad_acl.py` each require 404 for the same request (Read, lines cited under Coverage) |
| All 16 `TestRemoteAlphaUpgradeES*` tests on head, Nomad 2.1.1, real Nomad through `sudo -n` | 16 pass, 0 skip; the real-Nomad test 15.9 s (`tests/head-upgrade.json.gz`) |
| Real-Nomad test on Nomad 2.0.0 | pass, 15.2 s (O23-3) |
| gofmt of the two changed Go files, Python parse of the upgrade script | clean |

Mutants. Each was run against `TestRemoteAlphaUpgradeESApply`,
`...ApplyRollsBackOnFailure` and `...MovesARealNomadToHTTPS`
(`method/mutants.py`, `method/run_mutants.sh`, `mutants/`):

| ID | Mutant | Apply | Rollback | Real Nomad | Where it fails |
| --- | --- | --- | --- | --- | --- |
| M1 | the policy check removed (the coordinator's "check removed") | fail | fail | fail | Apply at the call-order check `:1339`; Rollback case "Nomad holds an anonymous policy" `:1487` apply exited 0; Real `:1985` check exit 0, no blockers |
| M1b | the request still made, its answer ignored | fail | fail | fail | Apply `:1416` the new migrated-host case (exit 0, no blockers); Rollback `:1487`; Real `:1985` |
| M2 | `inspect_migrated` back to `dfb2873` (job list only) | fail | pass | fail | Apply `:1381` (no policy request on the migrated host); Real `:1985` |
| M2b | `inspect_migrated` makes both requests but ignores the policy problem | fail | pass | fail | Apply `:1416`; Real `:1985` |
| M3 | `verify_after` back to `dfb2873` (job list only) | fail | fail | pass | Apply `:1339` call order; Rollback `:1487` |
| M4 | the policy check also accepts 200 | fail | fail | fail | as M1 |
| M5 | denylist: only 200 is a problem | pass | pass | pass | survives (O23-1) |
| M6 | the policy request over plain HTTP | fail | fail | fail | apply refused: "Empty reply from server" |

So each new case catches the repair's intent at its own assertion (M1b, M2b).
The Rollback case covers `verify_after` and the other two cover
`inspect_migrated`, as the writer said. The writer's own mutant matches M1.

## The trunk_dev merge (Ran, `delta/merge-checks.txt`)

- Parents of `977b172`: `fe5119b` (the repair) and `e2af4b2` (trunk_dev, #61).
- `git merge-tree --write-tree fe5119b e2af4b2` gives
  `0391c6fc…`, which is `977b172`'s tree. So there was no hand edit and no
  conflict resolution.
- `git diff fe5119b 977b172` is byte-identical to `git diff bf5a760 e2af4b2`,
  which is #61's whole patch: 5 paths, +80/-8.
- `git diff bf5a760 fe5119b` is byte-identical to `git diff e2af4b2 977b172`.
  So #60's patch is the same before and after the merge, 58 paths both times.
- `e2af4b2`'s tree `c9d2d6b3…` equals the tree of #61's audited head
  `af266dc`.
- `dfb2873..977b172` touches 8 paths: the 3 of the repair and the 5 of #61.

## Validation assessment

All runs: user `ci`, Go 1.26.5, `-count=1`, in this container (4 CPUs).

| Run | Result |
| --- | --- |
| `go test -json -timeout 45m ./scripts/` on head `977b172`, 07:21Z to 07:28Z, no ssh, scp, uuidgen or en_US locale | 420 pass, 28 fail, 13 skip (top level); 2080 / 241 / 14 with subtests; 418.4 s |
| The same on base `e2af4b2`, 07:28Z to 07:34Z | 419 pass, 28 fail, 13 skip; 2052 / 241 / 14 with subtests; 347.5 s |
| Head against base | The same 28 failures and the same 13 skips, and no test changes verdict. The first failure lines match test for test, line numbers included. The only difference is the checkout path, `es-head` against `es-base` (`tests/reasons-*.txt`). The tests only on head are `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` and `TestRemoteAlphaUpgradeESNomadShapesMatchTheBoxAndTheSupportedConfig` (both pass). The one only on base is `TestRemoteAlphaUpgradeESNomadLockMatchesSupportedConfig`, which the retarget replaced |
| The 28 again on head and base after `apt-get install openssh-client uuid-runtime acl iproute2` | 18 pass, 10 fail, the same 10 on both |
| The 2 ByteStable matrix tests after generating `en_US.UTF-8` | pass on head and base |
| What is left | the 8 entries of `.github/ci/environment-only-tests.txt` for `scripts` |
| For O23-5 only: `go test ./es/app/ -run 'NomadACL\|NomadTLS\|NomadSupported\|Nomad.*Placement\|LoosenedNomad\|NomadBootstrap'` on head, Docker up | 18 pass (103 with subtests), 47.5 s; no `nomad` process left |
| For O23-5 only: the listed witness test on head and on base, Docker up | fails on both, as listed; no `nomad` process left |

The 28 tests that fail on head and on base in the bare container. **L** marks
an entry of the environment-only list; **S** passes once ssh, scp, uuidgen,
acl and iproute2 are installed; **U** passes once the `en_US.UTF-8` locale is
generated:

- `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal` (L)
- `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody` (L)
- `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution` (L)
- `TestRemoteAlphaOperatorByteStableFalsePositiveMatrix` (U)
- `TestRemoteAlphaOperatorByteStableUnicodeDelimiterMatrix` (U)
- `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDoesNotInvokeGit` (S)
- `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveFinalEmitterInvariantFailureNoJSON` (S)
- `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveLocalRuntimeFailureIsTyped` (S)
- `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveLocalRuntimePipeReadSemantics` (S)
- `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveRuntimeExactSSHArgvAndSuccessSchema` (S)
- `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveRuntimeFailureMapping` (S)
- `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveRuntimeKeepsEachIdentityClassification` (S)
- `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveRuntimeRejectsSecretLikeTargetsBeforeContact` (S)
- `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveStructuredTargetPrivacyAllowsVocabularyAliases` (S)
- `TestRemoteAlphaOperatorP0vFacadeAllowsOrdinarySHostShape` (S)
- `TestRemoteAlphaOperatorP0vFacadeDoesNotRequireLocalTTY` (S)
- `TestRemoteAlphaOperatorP0vFacadeExecsOnlyFixedPythonRuntime` (S)
- `TestRemoteAlphaOperatorRecoverySessionESGovernanceTLSStatusStagesOnlyCollector` (S)
- `TestRemoteAlphaOperatorRecoverySessionESServiceTLSStatusStagesOnlyCollector` (S)
- `TestRemoteAlphaOperatorRecoverySessionESTLSStatusInteractivePromptAndFailureResidue` (S)
- `TestRemoteAlphaOperatorRecoverySessionESTLSStatusPostContactRefusals` (S; its first failure names a missing `/usr/bin/uuidgen`)
- `TestRemoteAlphaOperatorRecoverySessionESTLSStatusPreCollectorStageCleanup` (S)
- `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap` (L)
- `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal` (L)
- `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition` (L)
- `TestRemoteAlphaP0tGrammarDiagnosticCustodyAndEffects` (S)
- `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression` (L)
- `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap` (L)

The 13 top-level skips on both are the nine root-only tests and four others
that skip themselves (`tests/scripts-*-summary.txt`). CI runs the root-only
tests as root.

Not run:
- other packages (the delta touches only `scripts` among the Go packages,
  apart from `docs_contract_test.go`, which came with #61's audited patch;
  CI ran everything);
- `-race`;
- the nine root-only tests;
- `go vet` locally (CI's Vet and macOS Vet passed on `977b172`);
- anything on the box.

## CI

Run 45565423373, job 139038913119 ("build, vet and test"), on `977b172`
(pull request): **success**, from 07:05:27Z to 07:51:48Z (46.4 min) (Read:
GitHub API; `ci/job-139038913119.log`, fetched with `get_job_logs`).

| Step | Result | Time (UTC) |
| --- | --- | --- |
| Build, Vet, Vet for macOS | success | 07:05:44 to 07:06:43 |
| Check the test gate | success | 07:07:21 to 07:09:12 |
| Test | success: "test gate passed: 49 packages, 3 of them with skipped entries (17 entries); 14 tests skipped themselves, all of them listed" | 07:09:12 to 07:35:20 |
| Listed tests still fail | success | 07:35:20 to 07:50:49 |
| Listed tests pass as root | success: "tests as root passed: 9 of execution-substrate/scripts" | 07:50:49 to 07:51:45 |

- This is the first run of #60 with #61's limits. All 25 `go test -json`
  lines in the log carry `-timeout=20m`; none lacks it (Ran: grep).
- Package times (Read):
  - `scripts`: 354.2 s;
  - `es/app`: 458.6 s in the gated run and 426.6 s in the observed run, that
    is 38% and 36% of the 20-minute limit;
  - `es/admission`: 257.3 s;
  - `reliablesubmit`: 34.7 s.
- `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` is not in the list, and
  the gate passes only when every test that skips itself is listed. So it ran
  and passed on the runner (Inference from the gate's rule and its "all of
  them listed" line).
- **macOS.** `go.yml`, the only workflow at `977b172` and at its base
  `e2af4b2`, has no macOS test job, only the "Vet for macOS" step (success).
  So there was no macOS test run on this head to wait for. A macOS workflow
  landed on trunk_dev after this run started (see "Remaining uncertainty and
  stop conditions").
- **Orphan Nomad processes at job end** (O23-5). The runner ended 3 orphan
  `nomad` processes after the job. On the dfb2873 run it ended 2. On the last
  two trunk_dev runs (`bf5a760`, `e2af4b2`) it ended none.

## Sensitive-material handling

- The tests generated all TLS material, Nomad tokens and ACL secrets in
  temporary folders, and removed them.
- The evidence holds test names, verdicts and durations, first failure lines,
  mutant logs, commit and tree IDs, the method scripts and public CI step
  times.
- A scan of the evidence (Ran) found:
  - no email address;
  - no IP address other than 127.0.0.1;
  - no PEM block;
  - no Nomad SecretID or token.

  The only UUID-shaped values were these:
  - node, cluster and keyring IDs that a throwaway Nomad agent logged in
    mutant M6's output. They are not secrets, and I replaced them with
    `<uuid>` in the published copy anyway;
  - in the public CI log, GitHub's runner worker and temp-folder IDs.

  GitHub prints the checkout's credential header in that log as `***`.

## Remaining uncertainty and stop conditions

- **trunk_dev moved after this run started.** PR #59, the macOS gate for
  `./scripts/...`, merged at 07:38:57Z as `819f712`. `977b172` is now behind
  it, and the ruleset requires an up-to-date branch. What the update needs
  (Ran, Read):
  - A trial merge of `977b172` with `819f712` is clean (`git merge-tree`,
    tree `b4f97a35`). But #59 changes
    `scripts/remote_alpha_root_service_paths_test.go`, which is one of #60's
    58 paths. So that file's manifest entry will change, and the sync-only
    shortcut (byte-identical file entries) does not apply as it stands.
  - #59 adds `go-macos.yml`. It runs on `pull_request` against the merge
    commit and holds `./scripts/...` to the list
    `.github/ci/environment-only-tests-macos.txt`, whose "skips-itself" lines
    must equal the tests that skip themselves.
    `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` skips itself on darwin
    (`remote_alpha_upgrade_es_host_test.go:1737-1738`, "the box's Nomad client
    config is Linux's"), and the list does not name it. So the first macOS
    run of #60 will fail unless that list gains a "skips-itself" line for it
    (Inference from the gate's rule as `go-macos.yml` describes it).
  - Whether #60's other `scripts` tests (the 16 upgrade tests were rewritten
    by the retarget) pass on macOS is **Unknown**. At `e2af4b2` the macOS list
    names one upgrade test, `TestRemoteAlphaUpgradeESReadsGoBuildInfoLikeGoVersion`,
    as failing there.
  - So the update merge plus any list edit gives new bytes. They need a delta
    check by an auditor, not the sync-only route, plus green runs of both
    `go` and `go-macos`.
- This is a diff-only check. The rest of the 58-path patch rests on audits
  20, 21 and 22 (Read), with provenance over all of it (Ran).
- Nothing on the box was run. The box run follows the red-team and the merge
  (report 11, section 11).
- The Fable red-team is separate and still to come.

## Confidence

- Provenance: high (manifest byte-identical twice at opening and closing;
  merge = git's own; patch unchanged).
- Validation: high for the repair: three tests, 7 of 8 mutants with the
  survivor explained, real Nomad 2.1.1 and 2.0.0, and the scripts package
  equal to base. CI as stated above.
- Implementation: high that the migrated path now proves the lock's "no
  anonymous policy" property, as ES's gate does.

## Effect status

No repair, commit, push, PR edit, PR comment, review, merge or CI rerun.
Nothing outside this container changed. Inside it:
- packages installed with apt (`openssh-client`, `uuid-runtime`, `acl`,
  `iproute2`, `locales`);
- a `ci` user;
- a dockerd. It stopped on its own at some point after 07:36Z, the time of
  the last run whose real-Nomad placement step needs Docker. I restarted it
  for the O23-5 runs. Inference that Docker was up for the earlier
  real-Nomad runs: they passed in about 15 s, and with Docker down the
  placement step fails after 120 s (writer's section 14).

The tests started and stopped their own Nomad agents. No `nomad` process is
left (Ran: `ps`).

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/nomad-acl/23-pr60-diff-check.md`.
Its SHA-256 is in the delivery message. Evidence checksums are in
`23-pr60-diff-check-evidence/SHA256SUMS.txt`.

## Final verdict

**ACCEPT**, for `977b172` against `dfb2873`.

- A22-1 is closed.
- The merge of `e2af4b2` adds only #61's audited bytes.
- With audit 22's other conclusions, the PR's correctness audit chain is
  complete at `977b172`.

What the merge still needs, for the coordinator's gate:
- The Fable red-team. Its target should be the head after the update below,
  or `977b172` with a delta check after.
- An update merge of trunk_dev `819f712` (#59). That merge touches
  `scripts/remote_alpha_root_service_paths_test.go`. It most likely also needs
  a "skips-itself" line in `.github/ci/environment-only-tests-macos.txt` for
  `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS`. After that:
  - a new manifest;
  - a delta check by an auditor (not the sync-only route);
  - green `go` and `go-macos` runs on that head.
- The PR head at merge time equal to the head those checks accepted.
