# Audit of ES PR #60 at f505f72 (Nomad lock part 2b, Nomad over HTTPS)

Verdict: **BLOCK**.

- **A23-1 (gate):** CI fails on the PR head.
  - CI run 45546737121 on `f505f72` stopped in `es/app` at go test's
    default 10-minute timeout.
  - On base `bf5a760`, CI's `es/app` took 393.6 s.
- **A23-2 (Low):** no test covers the upgrade script's anonymous-job-list
  check, the 403. On a migrated host's "nothing to do" path it is the only
  proof that Nomad is still locked.
- **A23-3 (Low):** `nomad_tls_identity.py` refuses a CA file that is a
  symbolic link, as the docs say, but no test covers it.

**A second, independent audit of the same head** was published at
05:21Z as `20-pr60-audit.md`, also BLOCK. I found it only when I came to
publish, so this report is numbered 21. I did not use it for my own
findings; the cross-check is in "Relation to audit 20". In short:

- A23-1 is its A20-3, and the V5 part of A23-2 is its A20-2(a).
- A23-3 is new: audit 20 did not mutate that check.
- Its A20-1, A20-2(b) and A20-2(c) are checks I did not mutate. I read
  the code for each and agree with them (Read).

The fixes the PR needs are the union of both lists ("Final verdict").

The rest of what I was asked to check holds (Ran, Read):

- ES sends its token only inside a TLS 1.3 connection to the pinned key.
- The ACL tool still checks the port holder before the handshake. A
  mutant that swaps the two is killed.
- The scripts trust only `NOMAD_CACERT`.
- Setup's issuance matches the report.
- The retargeted upgrade meets both of the coordinator's conditions:
  - It reads the host's shape from four parts. It refuses anything else and
    names every part's state, and a migrated host is a verified no-op.
  - Its real-Nomad test drives the real `nomad_acl_setup.sh` against real
    Nomad over HTTPS. It passes as root on Nomad 2.1.1 and 2.0.0. The box
    runs 2.0.0.

Outside `es/app`, the full suite fails exactly where base fails. 19 of my
24 mutants are killed: the three survivors behind A23-2 and A23-3, plus two
Info items.

Statements are marked **Ran**, **Read** or **Inference**. Evidence paths
are relative to `21-pr60-audit-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Target

- Repository: evo-agi/Execution-Substrate, PR #60 (draft), branch
  `claude/project-thread-9slgp8`, into trunk_dev.
- Head `f505f7236c5ce5ca8c7eef40330da70bfb2c4c10`, tree `91745199…28f0`.
- Base and merge-base `bf5a760a2276f5d8b7600d7b64523e4ee32410d0`.
- Recipe v2 (source sha256 `c08597e2…a3ca`, verified):
  - manifest_sha256
    `e3904b35be2a3fdc6caea1360d7dbc33783ebccd7ce2c912466a5f72e2ac1d5e`;
  - textual_diff_sha256 `8823dbcd…c209`.

  Both equal the writer's brief.
- 58 paths, +4681/−1094. No `.github` path.
- Scope: the brief `11-wip/audit-brief-60.md` and the writer's request of
  04:27Z. It covers the whole base-to-tip range: part 2b, the merge of
  `2ca76cd`, observer `list-jobs`, the two #31 review fixes, PR 12's TLS
  1.3 floor and the retargeted box upgrade. The writer's report is
  `11-part2b-nomad-https.md`.

## Provenance (Ran, `provenance/`)

- I ran the recipe twice at the start and twice after all the tests, on a
  local branch with the PR's name, HEAD reset to the base and upstream
  `origin/trunk_dev`. All four outputs are identical.
- The manifest's path set equals
  `git diff --name-only --no-renames bf5a760 f505f72`. Every file's SHA-256
  equals the tip's blob.

## A23-1 (gate, Ran): CI fails, es/app exceeds the 10-minute test timeout

CI run 45546737121 on `f505f72` (`ci/runs.txt`):

- Its Test step failed with `panic: test timed out after 10m0s` in `es/app`
  at 600.0 s.
- `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` had
  been running for 3 s when the timer fired.
- CI runs `es/app` without `-timeout`, so Go's default of 10 minutes
  applies.
- The PR's only other run, on `d8fd9d2`, was cancelled by the push.

| `es/app` | Base `bf5a760` | Head `f505f72` |
| --- | --- | --- |
| CI | 393.6 s (run 45539140560) | over 600 s, timed out |
| My container, alone (`tests/es-app-timing-*.txt`) | 545.3 s | 569.3 s |
| My container, inside the full `./...` run | 577.3 s | timed out at 600.0 s |
| #57's `ea6d277` on CI, for scale | | 574 s |

- In my container, the PR's 9 new `es/app` tests add 21.1 s, and existing
  tests grew by 2.9 s in all. The largest new one is
  `TestSubmitRefusesANomadOtherThanThePinnedOne`, at 11.2 s.
- The head's runner was slower than the base's on packages the PR does
  not touch (Read, `ci/runs.txt`):
  - `internal/callerauth` took 65.3 s against 49.0 s (+33%);
  - `ags/app` took 31.2 s against 27.2 s (+15%);
  - `ars/app` took 22.1 s against 17.4 s (+27%).
- Base's 393.6 s scaled by 15 to 33%, plus about 21 s of new tests, gives
  roughly 475 to 545 s. That is under 600 s, so runner speed and the new
  tests together explain most of the jump but not all of it (Inference).
  Tests that skip in my container (bring-up full profile, supported-local
  SPIRE/Vault, the sudo cases) run on CI and may account for the rest.
- Either way, `es/app` sits close to the 10-minute default: 574 s on CI
  for #57, and 545 to 577 s here on base. This head went over it. A rerun
  might pass, but the margin is thin for every PR.
- **Fix:**
  - a CI run green on the final head;
  - an explicit `-timeout` for the gate's `go test` calls, or a split of
    `es/app`. That file, `.github/ci/go_test_gate.py`, is outside this
    PR's 58 paths, so a separate CI-only PR fits (audit 20's A20-3 says
    the same).

## A23-2 (Low, Ran): the upgrade's anonymous-403 checks are untested

The upgrade script runs `GET /v1/jobs` without a token over HTTPS and
requires 403 in two places:

- `inspect_migrated` (`remote_alpha_upgrade_es.py:1261`), which `check`
  and `apply` run on an `https` host;
- `verify_after` (`:1453`), after `apply`.

Mutants V5 (the first check removed) and V12 (the second removed) both
survive the whole `TestRemoteAlphaUpgradeES*` set (`mutants/mut23.txt`,
`mutants/mut23-v12.txt`).

- The real-Nomad test cannot kill them, because a real locked Nomad always
  answers 403.
- V12 matters less: `verify_after` then runs `nomad_acl_setup.sh check`,
  which also refuses anonymous plans (V11, which drops that check, is
  killed). Base `bf5a760` already has the same check over plain HTTP
  (`remote_alpha_upgrade_es.py:1186` there, Read), and audit 20 shows its
  mutant survives on base too (O20-1). So V12's gap is pre-existing; the
  check at `inspect_migrated` is new code, which makes A23-2 a Low in the
  diff.
- V5 matters: on the migrated path, `check` and `apply` report "nothing to
  do" after the leader, identity and 403 checks only. The 403 is the only
  one of them that shows Nomad is still locked. This is the in-place
  verification of the coordinator's condition 1.
- **Fix:** the fake host's curl already returns 200 for `/v1/jobs` when
  `$s/locked` is absent (host test, line 259). An `https`-shape case
  without that file should expect the blocker "Nomad answers an anonymous
  job list over HTTPS with 200, not 403". An `apply` case after the
  restart could do the same for V12.

## A23-3 (Low, Ran): the identity check's symbolic-link refusal is untested

- `configuration.md` ("Scripts") says the shell helpers and the Python
  tools refuse a CA file that is missing or a symbolic link.
- `nomad_tls_identity.py` `_context` does refuse one (`os.lstat`, then
  `S_ISREG`).
- Mutant G7 removes that check, and it survives
  `TestNomadTLSIdentityChecksWhatESChecks` and
  `TestSupportedLocalFullReadinessChecksNomadsPinnedIdentity`.
- The same refusal is tested for the ACL tool (G2 killed) and the shell
  helpers (G9 killed).
- **Fix:** one case with a linked CA for `check` and for `pin`.

## What holds (Read, Ran)

### ES pins Nomad's key

- `newNomadTLSConfig` (`es/admission/nomad_tls.go`) sets:
  - `MinVersion` TLS 1.3;
  - `RootCAs` from `nomad.root_ca_file` only;
  - `ServerName` from config;
  - a `VerifyConnection` that compares SHA-256 of the leaf's
    `RawSubjectPublicKeyInfo` with the pin.
- It is built once in `newNomadClient`, which `service.go` calls at
  startup. That client is ES's only sender of the Nomad token (Read: no
  other `X-Nomad-Token` user outside tests).
- The transport is the no-proxy clone, and redirects are still refused.
- The CA file must be a regular file of at most 1 MiB, holding only PEM
  CERTIFICATE blocks without headers.
- Config validation requires all of these:
  - `https://<loopback IP literal>:<port>`, with no user, path, query or
    zone;
  - a lowercase DNS `server_name`;
  - a clean absolute `root_ca_file`;
  - a 64-hex pin.
- PR 12's operational provider moves from TLS 1.2 to TLS 1.3. It already
  pinned the key.
- Mutants:
  - G10 (non-CERTIFICATE blocks accepted) and G11 (any IP accepted) are
    killed;
  - the writer's E1 to E3 and C1 cover the pin, the version, the name and
    the scheme.

### The ACL tool, the shell helpers and the scripts

- **ACL tool.** `_NomadsConnection.connect` (`nomad_acl.py:196-207`) makes
  the TCP connection, then runs `require_nomads_socket`, then the TLS
  wrap.
  - G1 swaps the last two, and `TestNomadACLToolSendsNothingToAPortHolder`
    kills it: that test counts ClientHellos at the holder.
  - `_NoPlainHTTP` replaces urllib's http handler.
  - The context trusts only `--ca-file` (`create_default_context(cafile=…)`
    loads no system CAs) and requires TLS 1.3. G2 and G3 are killed.
- **Shell helpers.** `nomad_curl` uses `--proto =https --tlsv1.3 --cacert
  "$NOMAD_CACERT" --capath /dev/null --noproxy '*'` and refuses an `http`
  address or a missing or linked CA. G8 and G9 are killed.
- **Identity check.** `nomad_tls_identity.py`:
  - completes a handshake only;
  - checks the name (G5 killed);
  - requires TLS 1.3 (G4 killed);
  - pins the SPKI its DER walker extracts (G6 killed);
  - requires `nomad.base_url` to equal `NOMAD_ADDR`.

  The walker reads `version`, `serialNumber`, `signature`, `issuer`,
  `validity` and `subject`, then the SPKI, with bounds checks.
- **Merge resolution of `2ca76cd`.** It keeps #48's guard: in the tool as
  above, and in setup as `require_nomad_listener`, now for
  `https://127.0.0.1:<port>`. #57's `placement` runs with `--ca-file`
  everywhere, including the wrapper.
- **PLANS.md.** The existing bullet was edited in place and one fact
  bullet added: no dated entry, 145,466 bytes (Read).

### Setup's TLS material

`nomad_tls_issue` (`scripts/70_linux_setup.sh`, region `nomad_tls`) works
as follows:

- It creates a P-256 CA (`CA:TRUE, pathlen:0`, `keyCertSign`) and a P-256
  server certificate:
  - `CA:FALSE`;
  - `digitalSignature`;
  - `serverAuth,clientAuth`;
  - SANs `server.global.nomad`, `localhost`, `127.0.0.1` and `::1`;
  - a 128-bit random serial.

  This happens in a private work folder. The CA key is removed before the
  verification, and the files are moved into place in key, certificate,
  CA order.
- `nomad_tls_material_ok` checks:
  - the owner;
  - that nothing is a link;
  - key mode 0600;
  - the chain;
  - at least 30 days left;
  - each name, one per call;
  - that the key matches the certificate.
- G12 (no `pathlen:0`) is killed, and so are the writer's X1 to X8.

### The retargeted upgrade (root path)

- **Condition 1, the shape.** Four detectors, each read on its own
  (`host_shape`, `:1086`). The host has a shape only when all four agree.

  | Part | `locked-http` | `https` |
  | --- | --- | --- |
  | `nomad.hcl` | the box's file by SHA-256 `ea333055…5163` | that file plus the setup's `tls` block |
  | TLS directory | absent | root:root 0755, exactly the three files, material sound |
  | `es.json` | the 53 key paths, `base_url` plain HTTP | plus the three TLS keys, with the pin equal to the certificate on disk |
  | Binaries | clean builds of `16cbf739` | the payload's builds of the named commit |

  - Any other combination blocks, and the message names each part's state.
  - On `https`, `check` and `apply` verify in place: leader, identity,
    403. They write no backup and touch no service (`cmd_apply`
    `:1569-1574`).
  - My mutants are killed: V1 (material not checked), V2 (extra files),
    V4 (modified builds). So are the writer's M2 to M4, M10 and M14.
- **The shapes match the box** (Read, against the box evidence):
  - The 53 paths in `START_ES_PATHS` are the 49 the preflight listed
    (`es-box-upgrade/01-preflight/03-findings.md`) plus #54's four.
  - `ea333055…5163` is the box's `nomad.hcl` since the 22:17Z repair
    (`09-nomad-network/box-run/3-verify.txt`).
  - `16cbf739` is the build the 19:33Z run installed.
- **Root-path care** (Read):
  - Every command runs in its own process group, which is drained on a
    timeout or a signal.
  - ES is stopped before the TLS material is issued.
  - `nomad config validate` warnings about TLS are refused.
  - Running allocations block, found without a token.
  - `created.json` names only `/etc/nomad.d/tls`, and `backup_host`
    refuses if that path exists already.
  - `restore_host` verifies the whole backup and `created.json` before it
    stops anything. V3 (any path accepted) is killed.
  - The restore stops Nomad before writing (V6 killed) and requires a
    leader at the restored address (V10 killed).
  - The test-only hooks act only under a non-`/` `--host-root`, an option
    the help hides.
  - The ACL setup runs with `ES_USER=es` and `OBSERVER_USER=root`, as #57's
    docs require.
- **Condition 2, the real test.**
  `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` passes as root, where
  `sudo -n` works:
  - on Nomad 2.1.1 in 35.6 s (`tests/root-tests.txt`);
  - on Nomad 2.0.0 in 17.3 s (`tests/real-upgrade-root-nomad200.txt`).

  No root Nomad agent was left running. As `ci` it skips, because `ci` has
  no passwordless sudo. CI runs it: it fails any skip it does not list.

### Observer `list-jobs` and the #31 review fixes

- `OBSERVER_POLICY_RULES` gains `list-jobs` only.
- `TestRealNomadObserverListsButCannotChangeESJobs` passes on both Nomad
  versions (`tests/es-app-*.txt`).
- The bootstrap tests pass:
  - as `ci`, where they need no sudo;
  - `TestLinuxSetupBootstrapFinishesWithItsSavedSecret` and
    `TestNomadACLToolRetriesABootstrapThatNeverTookEffect` also as root.

## Observations (Info)

- **I23-1, V7 and V9 survive.**
  - `apply_nomad_tls` rereads `nomad.hcl` against the locked hash.
  - `install_es` rechecks the ES token file's owner and mode.
  - Both recheck what `check` refused seconds earlier, in root-only paths,
    so only a change between `check` and `apply` reaches them.
  - They are fine to keep; a test would need such a change.
- **I23-2, the writer's own limits** (report section 12, Read). These are
  recorded, not new:
  - ES follows a link for `root_ca_file`, while the scripts refuse one;
  - a `base_url` may name another loopback IP;
  - the readiness Python's own TLS 1.3 floor is not tested on its own;
  - the upgrade leaves the ACL policies as provision wrote them after a
    rollback.
- **I23-3, after the box run.** Any box procedure that calls Nomad's API
  needs `NOMAD_ADDR=https://127.0.0.1:4646` and
  `NOMAD_CACERT=/etc/nomad.d/tls/ca.pem`. That includes PR 12's live
  checks. The report's section 11 says so.
- **I23-4, the CA key.** The CA key is deleted with `rm`, in a 0700 work
  folder of root's, so its bytes may stay on disk until overwritten. Only
  root could ever read them (Inference).

## Validation (Ran; as `ci` unless noted)

| Run | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...`, `gofmt -l` on the 25 changed Go files | pass, nothing listed (`tests/build-vet.txt`) |
| `es/config`; `es/admission` `Nomad\|TLS\|TestOperationalProvider` | pass (`tests/es-config-admission-targeted.txt`) |
| targeted `es/app` set (real Nomad, TLS, ACL, setup, readiness), Nomad 2.1.1 and 2.0.0 | pass, 71 each; only the two sudo tests skip (`tests/es-app-211.txt`, `tests/es-app-200.txt`) |
| `TestRemoteAlphaUpgradeES*` | pass; the real-Nomad test skips as `ci` (`tests/upgrade-tests.txt`) |
| root package, `./internal/testutil/`, all of `./es/admission/` | pass (`tests/guards.txt`) |
| as root: the real-Nomad upgrade test, `TestSetupIssuesNomadTLSMaterialAsRoot`, the wrapper test, two bootstrap tests | pass; on Nomad 2.0.0 too for the upgrade test (`tests/root-tests.txt`, `tests/real-upgrade-root-nomad200.txt`) |
| full `go test ./...`, head vs base | the same failing tests and subtests on both, except that `es/app` at head timed out at 600 s (A23-1) (`tests/full-suite-*.txt`) |
| whole `es/app` alone, `-timeout 45m`, head vs base | 569.3 s vs 545.3 s; the same two environment failures (bring-up without offline image, witness) (`tests/es-app-timing-*.txt`) |
| my mutants G1–G12, V1–V12 | 19 of 24 killed; G7, V5 and V12 survive (A23-2, A23-3), and V7 and V9 survive (I23-1) (`mutants/`) |
| CI | run 45546737121 on `f505f72` failed (A23-1) (`ci/runs.txt`) |

In my container, the `reliablesubmit` and `scripts` failures and the two
`es/app` failures are the same on base. They are environment-only; the
writer's section 9 lists the same sets.

## Relation to audit 20 (`20-pr60-audit.md`, Read)

Both audits target `f505f72` with the same recipe hashes, and both give
BLOCK.

| This audit | Audit 20 | Note |
| --- | --- | --- |
| A23-1 CI timeout | A20-3 (Medium, pre-existing) | same run; audit 20 also saw PR #59's run at 426 s |
| A23-2, V5 (`inspect_migrated` 403) | A20-2(a), mutants A7 and A7w | same gap, same fix |
| A23-2, V12 (`verify_after` 403) | O20-1, mutant A7b | pre-existing (above) |
| A23-3, G7 (identity tool: CA symlink) | not covered | its symlink mutants were the ACL tool (A18), supported-local setup (A19) and the proof fetch (A12) |
| not covered | A20-1 (CA loader skips text and corrupt blocks) | agree (Read): `pem.Decode` skips any bytes before a block, and the loop at `nomad_tls.go:84-101` checks only type, headers and the trailing rest; my G10 covered the type only |
| not covered | A20-2(b) (identity tool: non-loopback IP) | agree (Read): no case in `TestNomadTLSIdentityChecksWhatESChecks` uses a non-loopback IP |
| not covered | A20-2(c) (proof fetch: CA check) | agree (Read): no proof test passes an unset, relative or linked `NOMAD_CACERT` |

What I ran that audit 20 did not: the root-only tests, including
`TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` on Nomad 2.1.1 and
2.0.0, and the setup and bootstrap tests as root. Audit 20 lists those as
not run.

## Red-team

The coordinator has set a Fable red-team after this audit. Nothing here
changes that. It should cover the fixed head, and the root path of the
upgrade.

## Sensitive material

- The tests use generated certificates, random tokens and fixtures.
- A scan of the evidence (Ran) found no e-mail address, no names and no
  real token. What it did find:
  - UUID-shaped strings and `hvs.abcdefghijklmnopqrstuvwxyz` are the
    tests' fake constants;
  - `SecretID` appears only in code and test names;
  - `[home network address withheld]` appears once in `provenance/pr60.diff`, as the PR's own
    example of a non-loopback address in `es/config`'s tests;
  - one existing `scripts` subtest is named after a user and a host. I
    replaced that name with `<user>@<host>` in the two `tests/full-suite-*`
    files. The name is in the repository already; the placeholder cleanup
    in the backlog covers that.

## Effect status

- No commit, push, PR comment, review or merge.
- I did not touch the box.
- Temporary changes, all undone:
  - mutants were applied in my mutant clone, and its tree was clean after
    each batch;
  - the root copy is a local `git archive` with a local commit, and its
    tree was clean afterwards.
- The local audit branch was deleted. All clones were clean.

## Final verdict

**BLOCK**

To accept, the union of both audits:

- A23-2 / A20-2(a): a migrated fake host whose Nomad answers the
  anonymous job list with 200, refused by `check` (the fake curl already
  does this when `$s/locked` is absent). It can pin `verify_after`'s
  check too.
- A23-3: a linked CA refused by the identity tool, for `check` and `pin`.
- A20-1, A20-2(b) and A20-2(c), as audit 20 describes them.
- A23-1 / A20-3: CI green on the final head.
- A diff check of the fix commit, which can serve both audits.
