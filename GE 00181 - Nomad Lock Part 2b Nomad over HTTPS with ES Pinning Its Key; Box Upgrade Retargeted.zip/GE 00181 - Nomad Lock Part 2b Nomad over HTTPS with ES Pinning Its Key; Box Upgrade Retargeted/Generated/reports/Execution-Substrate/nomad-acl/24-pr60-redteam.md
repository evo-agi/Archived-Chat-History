# Red-team of ES PR #60 — Nomad over HTTPS, ES pins the server key

Fresh, read-only Fable red-team of the Nomad-lock part 2b change, separate
from the writer thread and from the three correctness audits (reports 20, 21,
22 and the diff-only check 23). Only job: break the change — submit to Nomad
without ES, defeat the key pin, downgrade TLS, or make the root-run box
upgrade script do damage or leave the box weaker.

**Verdict: ACCEPT.** No way found for a caller, a container, a local non-root
user, or a LAN peer to submit to Nomad without ES, defeat the SPKI pin, or
downgrade TLS; no way found to make the root-run upgrade do damage or leave
the box in a weaker-than-locked state while reporting success. The migration
genuinely closes RT-4 (the raft-log / port-holder token theft that still
works on the box's current plain-HTTP shape). Two non-blocking items for the
backlog (one Low observation, one assumption to record); neither blocks the
merge.

## 1. Target identity

| | |
|---|---|
| Repo | Execution-Substrate |
| Head reviewed | `977b172a70604e78cd12c21998114888a766ebd9` |
| Base (merge-base, trunk_dev) | `e2af4b27ad8ab443084c90bb9113ed1204fbdf69` |
| Manifest v2 sha256 (from report 11/§10, audited) | `85b129642926ee51297cdaf339f74cf98c7efb7ac9363962d5ae5225d7c58251` |
| Files | 58 |
| Current PR head at report time | `4795a4f3ce5c1c5135de83e73181e3b0e12e47d1` |

**Head advance.** As the brief warned, the writer merged `trunk_dev` (the
macOS CI work, #59) into the PR after I started: head moved `977b172` →
`4795a4f`. I diffed the two: the delta touches only `.github/` (the macOS CI
gate workflow, `go_test_gate.py`/`go_test_gate_selftest.py`, the macOS
environment-only test list), `*_test.go` files, `README.md` and a new doc
`.docs/system_overview/go_toolchain_baseline.md`. **No part-2b product code
changed** (no `es/admission`, `es/config`, `scripts/internal/*.py`,
`scripts/*.sh`, or the upgrade script). `go_test_gate.py` is CI-harness, not
ES runtime. So this red-team of the product behaviour at `977b172` holds for
`4795a4f` unchanged (Ran: `git diff --name-only 977b172 4795a4f`).

Posture: read-only. Nothing was pushed, no PR was edited, the box was never
touched. All live testing was against local throwaway Nomad agents in the
cloud container.

## 2. Method and rig

Nomad 2.1.1 (the CI-pinned build, sha256 `073084f7…3f39`, Revision
`d0f21042`), Go 1.26.5, openssl 3.0.13, Python 3.13. I issued Nomad's TLS
material with the PR's **own** `nomad_tls` functions (extracted from
`scripts/70_linux_setup.sh` exactly as `remote_alpha_upgrade_es.py` does),
started a real Nomad on a `nomad.hcl` byte-equal to the supported `tls` block,
bootstrapped ACLs and provisioned ES's namespace/policies/tokens with the real
`scripts/nomad_acl_setup.sh provision`, and then attacked it as an
unprivileged local user (`mallory`) and as a rogue local Nomad server. I also
reproduced the box's **current** `locked-http` shape (ACLs on, plain HTTP, no
RPC TLS) to confirm what the migration actually buys. Full command log and
outputs: `24-pr60-redteam-evidence/commands-and-results.md` and
`gossip-raft-summary.txt`.

Every statement below is **Ran** (executed, output seen), **Read**, or
**Inference**.

## 3. Attacks that failed (the lock holds)

### 3.1 Submit / reach Nomad without ES — refused (Ran)

As `mallory`, against the real HTTPS Nomad with the ACLs provisioned:

- **Plain HTTP to the API port** → `400 Client sent an HTTP request to an
  HTTPS server`. No plaintext API.
- **TLS 1.2 (`--tls-max 1.2`)** → `tlsv1 alert protocol version`. The server
  offers only TLS 1.3, so a downgrade cannot even be negotiated.
- **Anonymous GET sweep, ~50 endpoints over HTTPS**: only the
  unauthenticated-by-design endpoints answer (`status/leader`,
  `status/peers`, `agent/health`, `metrics`, `regions`, `namespaces`→`[]`,
  `acl/policies`→`[]`, `jwks.json`, `ui`). Every job- or namespace-scoped
  read, every operator-mutating endpoint → **403**.
  `/v1/acl/policy/anonymous` → **404** (no anonymous policy).
- **Anonymous writes** (`PUT /v1/jobs`, `/plan`, `/validate/job`, job
  register) in both `es-submit-v1` and `default` → **403 Permission denied**.
- **Raw RPC port (4647)**: plain RpcNomad/Raft bytes → connection reset
  (`non-TLS connection attempted with RequireTLS set`); an RpcTLS handshake
  with no client cert → `certificate required`; with the attacker's *own* CA
  cert for `server.global.nomad` → `unknown ca`. A local caller cannot speak
  RPC without a cert the destroyed-key CA signed.

So a local non-root user cannot submit, read ES's jobs, or reach the control
plane. A LAN peer is further out: Nomad binds `127.0.0.1` only and the host
firewall (AR #10) drops external access to 4646–4648, so a LAN peer cannot
reach Nomad at all (Read + the firewall work).

### 3.2 Defeat the SPKI pin — refused (Ran)

The pin's whole point is that even a certificate the *same* CA signed with a
*different* key is rejected. I confirmed both the mechanism and that the four
readers agree on the pinned value:

- `es/admission` `TestNomadClientSendsItsTokenOnlyToThePinnedNomadOverTLS13`
  passes on the exact bytes, including the sub-cases *same CA/another key*,
  *another CA*, *self-issued*, *another server name*, *expired*, *TLS 1.2
  only*, *plain HTTP* — each refuses before the token is sent (Ran).
- `TestNewNomadClientRefusesWithoutAUsableRootCAOrPin` passes: the CA-file
  loader refuses text before/between certificates, a corrupt first block, PEM
  headers, a key instead of a cert, an oversized file, and a non-lowercase or
  short pin (Ran).
- The pin is **read identically** by all four readers for one issued
  certificate (`8c60b55c…a85a`): openssl via the setup's
  `nomad_tls_spki_sha256`, the Python DER walker in `nomad_tls_identity.py
  pin`, openssl directly, and Go's `crypto/x509` `RawSubjectPublicKeyInfo`
  (Ran). There is no reader disagreement that could make ES pin a value a
  tool computes differently.
- The server key file is `root:root 0600` and the CA key is destroyed at
  issuance (work dir empty afterwards, Ran), so a non-root attacker can
  neither read the key nor mint a new cert that chains to `ca.pem`. The only
  certificate that satisfies chain + name + pin is the real one.

`ServerSPKISHA256` was correctly added to `SubmitConfigured()`, so a
half-configured Nomad (e.g. `base_url` without a pin) fails `config.Validate`
rather than building a client without the pin (Read, `es/config/config.go`
294, 760).

### 3.3 The migration closes RT-4; the box's current shape is still exposed (Ran)

A rogue local Nomad server started by an unprivileged user and pointed at
serf:

- **HTTPS shape (this PR):** it joins gossip and is recorded as a raft
  *Nonvoter*, but every raft/RPC heartbeat to it **fails TLS verification**
  (`certificate signed by unknown authority`); it never replicates;
  autopilot marks it unhealthy; it is removed when it leaves. No log, no
  token, no takeover. The real node stays leader and keeps placing jobs.
- **`locked-http` shape (the box *now*):** the same rogue joins, is added as
  a Nonvoter, and raft replication **succeeds** (`pipelining replication`);
  the rogue's own `raft.db` then contains Nomad's management token and the
  ES client token (confirmed by SHA-256 match and by using them against the
  victim). This is exactly RT-4 / the known #31 plain-HTTP limit.

So part 2b is the fix for a real, currently-live local token-theft path, and
it works: moving RPC to TLS 1.3 with `verify_server_hostname` stops the
replication that leaked the tokens. (Evidence: `gossip-raft-summary.txt`.)

### 3.4 Make the root-run upgrade do damage or leave the box weaker — not found

- **Shape confusion.** `host_shape` names a shape only when all four parts
  (`nomad.hcl` by SHA-256, the TLS dir, `es.json` keys+pin, the two binaries
  by Go build info) agree; any disagreement → refused, naming each part's
  state (Read). The migrated no-op path additionally runs
  `nomad_tls_identity.py check` and `anonymous_nomad_problems` (anonymous job
  list = 403 **and** `/v1/acl/policy/anonymous` = 404) before reporting
  "nothing to do" (Read; the A22-1 fix). I confirmed on a real Nomad that the
  anonymous policy endpoint returns 404 when absent and 200 when an anonymous
  policy exists (Ran), so the migrated-host proof cannot be fooled by a policy
  that opens only `es-submit-v1`.
- **Silent TLS downgrade via `nomad config validate`.** With a valid server
  block but unreadable TLS files, `nomad config validate` **exits 0** and
  prints `Configuration is valid!` plus `WARNING: Error when parsing TLS
  configuration…`; with no `tls` block it prints `WARNING: mTLS is not
  configured`. The upgrade refuses **both** strings
  (`NOMAD_VALIDATE_REFUSED`), so it will not write a `nomad.hcl` whose TLS
  Nomad would silently ignore. The guard is load-bearing and its strings
  match Nomad 2.1.1 (Ran).
- **Rollback / arbitrary deletion.** `load_created` allows only
  `/etc/nomad.d/tls` in `created.json`; `remove_created` lstats and refuses to
  recurse a symlink; backups are verified in full (SHA-256) before any service
  is stopped; `atomic_replace` uses `O_NOFOLLOW` (Read). No path to deleting
  or overwriting an arbitrary file through a tampered backup.
- **TOCTOU.** `apply` re-runs the full `inspect_host`, and `apply_nomad_tls`
  re-reads `nomad.hcl` and refuses if its SHA-256 changed after the check
  (Read).
- **Tests on the exact bytes.** The fake-host upgrade tests (check, apply,
  rollback at each step, interrupted apply, damaged backups, migrated no-op,
  ~40 refusal cases) pass, and the real-Nomad end-to-end migration test
  `TestRemoteAlphaUpgradeESMovesARealNomadToHTTPS` — which runs the real
  `nomad_acl_setup.sh` through `sudo` and the real `nomad_tls_identity.py` —
  passes in 14.3 s once Docker is up (Ran). The earlier failures in this
  container were the environment's AWS-IMDS fingerprinter and a stopped
  Docker, not the PR.

## 4. Findings

Two items, neither blocking. They become permanent regression tests / backlog
items only if the coordinator agrees they are in scope; I recommend recording
both and fixing neither in this PR.

### RT60-1 (Low, observation) — Nomad serf gossip is unencrypted, so a local non-root user can add a phantom non-voting peer and degrade autopilot health

**What (Ran).** On the migrated HTTPS Nomad, an unprivileged local user who
starts their own `nomad` server process and `retry_join`s `127.0.0.1:4648`
gets their node recorded by the real server as a raft **Nonvoter** and listed
in `agent/members`, and drives `autopilot` to `Healthy:false`,
`FailureTolerance:0`. Serf has no gossip-encryption key, so the join is not
authenticated.

**Why it is only Low.** RPC is TLS-pinned, so the phantom peer never
replicates any raft log, reads nothing, and casts no vote; on a single-node
cluster `FailureTolerance` is already 0 and the real node stays leader and
keeps placing jobs. Reach is a **local** process on the box only — Nomad binds
loopback and the host firewall drops external 4648, so no container and no LAN
peer can do this. The impact is a monitoring/▲health-endpoint nuisance that
self-heals when the rogue leaves. It is **not** a path to submit, to defeat
the pin, or to downgrade TLS — the four things this red-team was asked to
break.

**Not introduced by this PR.** Gossip was unencrypted on the box's
`locked-http` shape too (no `gossip` key in the box `nomad.hcl`); on that
shape the same join was far worse (full raft replication → token theft,
§3.3). Part 2b strictly improves the situation. Setting a Nomad gossip
encryption key is outside this PR's stated scope (HTTP/RPC TLS).

**Recommendation (backlog).** Either add a Nomad `gossip`/serf encryption key
to the managed `nomad.hcl` in a follow-up, or record explicitly in
`configuration.md` that serf integrity on the box rests on loopback bind + the
host firewall + RPC TLS, and that a local account can add a non-replicating
phantom member. A regression test could assert the managed `nomad.hcl`
carries a gossip key once that is adopted.

### RT60-2 (observation / assumption to record) — the upgrade trusts its own checkout (the scripts it runs as root), not just the payload

**What (Read).** `remote_alpha_upgrade_es.py` verifies the **payload**
(binaries + `provenance.json`, root-owned, SHA-256, Go build info) before
installing it, but it reads and executes its sibling scripts from the
**checkout** as root — `70_linux_setup.sh` (its `nomad_tls` region is run via
`bash -c`), `nomad_acl_setup.sh`, `nomad_tls_identity.py`, and the upgrade
script itself. These are not re-verified to be root-owned or unmodified by the
tool; integrity rests on the documented operator step `chown -R root:root` the
clone before `check`/`apply` (contract in `remote_supported_host_alpha.md`).

**Why it is not a finding against the PR.** After the documented
`chown -R root:root`, a non-root user cannot alter the checkout, and the box
clone lives in a root-created `/tmp/es-upgrade.XXXXXX`. Re-verifying one's own
running code from itself is circular, and the split (verify the installed
payload, trust the run-as-root checkout) is a reasonable boundary. I record it
so the box-run procedure keeps the `chown` as a hard precondition and the
clone's parent stays root-only. No change recommended.

### Confirmed non-issues

- **ACL tool / nomad CLI verify via the CA, not the SPKI pin.** Acceptable:
  the CA signs exactly one certificate (its key is destroyed), ES holds the
  extra pin, and a port-holder while Nomad is down cannot present any cert
  chaining to the CA (handshake fails before the token is sent — Ran, §3.2).
  The interim uid-of-listener guard (`require_nomads_socket`,
  `require_nomad_listener`) is kept as a second guard that runs *before* the
  TLS handshake (Read).
- **ES accepts a symlink `nomad.root_ca_file`** (report §12). Harmless: the CA
  file is public, ES also pins the key, and the CA's key is destroyed, so
  swapping the CA file cannot impersonate Nomad to ES.
- **`nomad.base_url` may name any loopback IP** (report §12). The supported
  setup binds `127.0.0.1`, which the certificate names.

## 5. Coverage and limits

- All live testing was in a cloud container against throwaway Nomad agents,
  per the brief (no box access). Box behaviour is inferred from the real
  `nomad.hcl`/`nomad_acl_setup.sh`/`nomad_tls` the box will run, exercised
  here unchanged.
- I did not re-reproduce the provenance manifest (that is the audits' job;
  reports 20–23 did it). I reviewed the PR worktree bytes directly and
  confirmed the head advance `977b172`→`4795a4f` is CI/test/docs only.
- The real-Nomad migration test needs Docker and a non-AWS fingerprint
  environment; both were satisfied for the passing run (Ran).
- Nomad version: 2.1.1 only here. The writer reports the suites passing on
  2.0.0 too; I did not re-run on 2.0.0.

## 6. Effect status

Read-only: no repair, no commit, no push, no PR edit, no merge, box untouched.
Rig processes stopped and evidence written to the shared folder.

## 7. Evidence

`24-pr60-redteam-evidence/`:
- `commands-and-results.md` — the full command log and results (A–F).
- `gossip-raft-summary.txt` — the HTTPS-vs-locked-http raft/gossip observations.
- `extracted-nomad_tls.sh` — the `nomad_tls` region as the upgrade runs it.
- `upgrade-tests-fakehost-plus-realnomad-envfail.txt` — the first upgrade test
  run (fake-host PASS; real-Nomad env failure before Docker was started).

**Final verdict: ACCEPT.** The HTTPS move and the SPKI pin close RT-4 and hold
against local, container and LAN attacks on submission, the pin and TLS
version; the root-run upgrade refuses every shape it was not written for and
cannot be driven into a silent downgrade or an arbitrary-file rollback. RT60-1
(Low) and RT60-2 (assumption) are backlog items, not merge blockers.
