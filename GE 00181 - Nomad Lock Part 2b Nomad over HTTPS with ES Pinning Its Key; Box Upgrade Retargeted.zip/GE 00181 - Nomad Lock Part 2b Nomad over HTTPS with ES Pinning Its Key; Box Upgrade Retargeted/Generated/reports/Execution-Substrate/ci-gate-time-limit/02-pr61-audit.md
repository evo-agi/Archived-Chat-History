# Audit of ES PR #61 (CI: a 20-minute limit for each test binary, 90 minutes for the job) at af266dc

Verdict: **ACCEPT**. No patch defect.

- **There is ample headroom** (Read, Ran):
  - The slowest `es/app` run that finished on a CI runner took 577.9 s
    (trunk_dev `8129b82`). One runner went past 600 s and timed out
    (`f505f72`). In this container, under the load of the full suite,
    `es/app` took 642.0 s at `dfb2873`.
  - The new limit of 1200 s for each test binary is 1.9 to 2.1 times those
    times.
  - The slowest job that passed took 57.1 min. The new 90-minute job limit
    is 1.58 times that.
  - If a test hangs in the step "Test", it still panics with its goroutine
    stacks well inside the job's limit, and the later steps are skipped. In
    "Listed tests still fail", the limit's first panic comes at most 20
    minutes after the step starts. On the slowest runner seen, that is
    39 + 20 = 59 minutes. O61-1 covers a listed test that hangs on a slow
    runner.
- **No failure is masked** (Ran, Read):
  - Every `go test` that the gate starts to run tests passes
    `-timeout=20m`. The self-check now holds every checked run of every case
    to that, and a new case counts exactly 3 such runs.
  - A run that the time limit cuts short still fails the step. The
    self-check's case for that passes with a 5-second stand-in for the
    limit.
  - One behaviour changes: a test binary that takes between 10 and 20
    minutes now passes instead of panicking. That is the point of the PR, and
    no doc or test treats slowness itself as a failure.
- **Mutants** (Ran): 4 of 5 are killed by a failing assertion, and the
  fifth by time.
  - These fail a self-check case, the docs contract, or both:
    - removing the flag;
    - setting the limit to 10m;
    - putting the flag after the arguments;
    - setting the job limit back to 60.
  - With the stand-in's rewrite removed, the time-limit case hangs. It would
    wait for the real 20-minute limit.
- **Self-check and docs contract** (Ran):
  - `python3 -I -B .github/ci/go_test_gate_selftest.py` at `af266dc`: 133
    tests OK in 199 s.
  - `go test -count=1 .`: ok.
- **CI** (Read, Ran):
  - Run 45555695320 on `af266dc` passed in 43.5 minutes.
  - All 25 `go test -json` lines in its log carry `-timeout=20m -count=1`.
- **Merge order** (Ran):
  - A trial merge of #61 with PR #59 (macOS gate, head `e700693`) conflicts
    in `.github/ci/go_test_gate_selftest.py`, as the writer said it would.
  - Whichever PR merges second needs a merge of trunk_dev, and its new
    self-check cases need checking against the `-timeout=20m` form.
  - This is not a defect of #61.

Every statement is marked **Ran**, **Read** or **Inference**. Evidence paths
are relative to `02-pr61-audit-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Repository / audit target

- Repository: evo-agi/Execution-Substrate, PR #61 into `trunk_dev`, branch
  `claude/ci-gate-time-limit`.
- Base: `bf5a760a2276f5d8b7600d7b64523e4ee32410d0` (trunk_dev and the
  merge-base).
- Topic: `af266dc441f6512d99db82e99395f3374899164b`, tree
  `c9d2d6b3ee322c6b723b467db3b3e203330cda15`, one commit.
  - It is the PR head (Ran: `git ls-remote` at 06:36Z and the GitHub API at
    06:40Z).
- Recipe v2, source SHA-256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`
  (verified).
  - manifest_sha256
    `61a59a7d117aefb352413f6583c38782ef0570b899f79bcc777f3e92d088a4c2`
  - textual_diff_sha256
    `dea42c3885de84429ffed3a13df6e51f6c54b676ac5811b16fdca9249feb4b94`
  - 5 paths, +80/-8:
    - `.docs/system_overview/go_toolchain_baseline.md`
    - `.github/ci/go_test_gate.py`
    - `.github/ci/go_test_gate_selftest.py`
    - `.github/workflows/go.yml`
    - `docs_contract_test.go`
- Kind: CI configuration, its tests and its doc only. It needs the audit and
  the gate, not David's review, and no red-team.
- Scope, from the coordinator: a fresh, read-only audit. Judge the headroom
  and check that no failure is masked. This thread had not audited #61
  before.
- Writer's report: `01-pr61-gate-time-limit.md`, sha256
  `2ea4e648d066515f93cefef40034825cc2f1442389ce40525e06144fd38c9e24`.
  This version has the "CI on af266dc" section.

## Audit posture

- Read-only:
  - nothing was committed, pushed or commented on GitHub;
  - no subagents were used.
- The self-check, the root package and the mutants ran in this container:
  - as user `ci`;
  - with Go 1.26.5 first on PATH (`/opt/go1.26.5`);
  - with `GOTOOLCHAIN=local`, `GOFLAGS=-mod=readonly`, `GOPROXY=off` and an
    emptied environment (`method/ci-env.sh`, `method/run61.sh`).
- Each mutant ran in a fresh copy of the tip, which was deleted afterwards
  (`method/mutants61.py`).

## Provenance reproduction (Ran, `provenance/`)

- The pushed tip equals the reported tip, and `bf5a760` is the merge-base.
- I took the manifest in a separate clone:
  - branch `claude/ci-gate-time-limit` at the tip;
  - then `reset --mixed` to the base;
  - upstream `origin/trunk_dev`.
- Results:
  - The two opening runs are byte-identical. They also equal the writer's
    `manifest-v2-af266dc.json`.
  - The two closing runs (06:35:04Z) are byte-identical to the opening
    runs.

## Coverage

- Read in full: the diff of all 5 files.
- Read, the parts of `go_test_gate.py` that the limit touches:
  - Every `go` call in the gate:
    - Every `go test` that runs tests goes through `go_test_json` (`:418`,
      command line at `:427`). That covers the gated run, the observed run,
      the run of the packages without entries, and the still-failing package
      and entry runs (`:700`, `:799`, `:834`, `:954`, `:960`, `:1020`).
    - `go list` and `go test -list` run no tests.
  - The step "Test" (`gated_runs`, `:786-857`).
  - How the still-failing step handles a run that stops early
    (`in_the_run_of_its_package` and `still_failing`, `:924-1083`).
- Read: `go_test_as_root.py`, which keeps its own `TIME_LIMIT = "10m"`
  (`:56`, `:169`) for the root-only tests.
- Searched the whole tree for statements of the old limits ("60 minutes",
  "10-minute", "default of 10", `timeout-minutes`). Only the new text
  remains.
- Read through the GitHub API, the CI job and step times of these runs:
  - 45539140560 (`bf5a760`), 45493398780 (`8129b82`) and 45546737121
    (`f505f72`), as audits 20 and 21 and the writer cite them;
  - 45555695320 (#61);
  - 45555027151 (#60 at `dfb2873`).
- The job logs of the last two are saved in `ci/`.

## Findings

### Patch defects

None.

### Pre-existing issues

None new.

### Observations

- **O61-1: how the per-binary limit fits inside the job** (Read: the gate
  code and the CI logs; Inference: the sums).
  - In "Test", the gate starts its `go test` processes one after another:
    - one for each of the three packages with entries;
    - an observed run for `es/app`, only after its gated run passed;
    - one for all the packages without entries.

    A hang costs at most 20 minutes in the run that meets it. The step then
    fails, and the later steps are skipped, as in run 45546737121.
  - In "Listed tests still fail", only listed tests are left to hang. A
    listed test that hangs is met twice: in the run of its package, which
    then has no listed failure to account for the stop and is not repeated,
    and in its own run.
  - The step started:
    - 30.3 min into the `dfb2873` run;
    - 29.1 min into #61's own run;
    - about 39 min into the slowest run the writer cites.
  - One listed `es/app` test that hangs adds at most
    (20 min minus that package run's normal time) plus 20 min.
    - On the slowest run seen (package run 521.3 s, job 57.1 min), that
      brings the job to about 88 minutes. Both panics land inside the
      90-minute limit, with about 2 minutes to spare.
    - For a listed `scripts` test on that runner, I have no package-run time.
      It could land a minute or two on either side of 90.
    - On a normal-speed runner like #61's (job 43.5 min, `es/app` package
      run 418.4 s), the job would end at about 77 minutes.
  - Past 90 minutes, GitHub cancels the job.
    - The required check still fails.
    - The first panic, with its goroutine stacks, is already in the log.
    - Only the step's closing summary would be lost.
  - Listed tests fail for host reasons within seconds, so a hang there is
    unlikely (Inference).
  - Recorded, not a finding:
    - no failure is masked;
    - the writer's claim that the limit can fire inside the job holds.
- **O61-2: slowness is no longer flagged until 20 minutes.**
  - A package that grows from 7 to 15 minutes now passes silently.
  - The gate's log prints each package's time, so the trend stays visible,
    but nothing fails on it.
  - If that matters later, a separate check could warn above a threshold.
    It is not needed for this PR.
- **O61-3: the root step keeps 10 minutes.** Its tests take seconds, so that
  limit is not a margin risk. (Read: on the runs cited, the step took about a
  minute.)

## Validation assessment

| Run | Result |
| --- | --- |
| Gate self-check `python3 -I -B .github/ci/go_test_gate_selftest.py` at `af266dc` | 133 tests, OK, 199.3 s (`tests/selftest-af266dc.log`) |
| Root package `go test -count=1 .` at `af266dc` (holds the docs contract) | ok, 2.9 s (`tests/root-package-af266dc.log`) |
| Mutants (`mutants/results.jsonl`) | 5 of 5 killed: 4 by failing assertions, 1 by time (see the table) |
| Trial merge with #59 `e700693` (`git merge-tree`) | conflict in `go_test_gate_selftest.py` only |
| CI run 45555695320 on `af266dc` (Read: `ci/job-139007081830.log`) | see below |

CI run 45555695320 on `af266dc`:
- It passed in 43.5 min (05:44:53 to 06:28:22Z).
- Each of the 25 `go test -json` lines carries `-timeout=20m -count=1`, and
  none lacks it (Ran: grep).
- `es/app`, by go test's own times:
  - 452.7 s gated;
  - 401.9 s observed;
  - 418.4 s still-failing.
- That is a normal-speed runner.

Mutants, each in a fresh copy of the tip:

| Mutant | Change | Result |
| --- | --- | --- |
| T1 | `go_test_json` without `-timeout=` | killed (see below) |
| T2 | `TIME_LIMIT = "10m"` | killed (see below) |
| T3 | the flag after the arguments | killed by `GateGivesEveryTestBinaryItsTimeLimit.test_every_run_of_the_gate_has_the_time_limit` |
| T4 | the 5-second stand-in no longer rewrites `-timeout=` | killed by time only (see below) |
| T5 | `timeout-minutes: 60` | killed (see below) |

What killed each one:

- **T1**:
  - `GateGivesEveryTestBinaryItsTimeLimit.test_every_run_of_the_gate_has_the_time_limit`;
  - 26 `ListedTestsMustStillFail` tests, including
    `test_passes_when_every_listed_test_fails`, as the writer reported. The
    names are in `mutants/T1-failing-tests.txt`;
  - the docs contract `TestGo1265ToolchainBaselineDocsAndBuildContract`.
- **T2**:
  - `test_every_run_of_the_gate_has_the_time_limit`;
  - `TestGo1265ToolchainBaselineDocsAndBuildContract`, which wants
    `TIME_LIMIT = "20m"`.
- **T4**:
  - `ListedTestsMustStillFail.test_run_of_the_package_that_the_time_limit_of_go_test_stops`
    hung until my 600 s cap.
  - Without the rewrite, that case waits for the real 20-minute limit.
  - This shows the rewrite is in effect. It is not an assertion that fails.
- **T5**:
  - `WorkflowKeepsWhatTheGateDependsOn.test_the_workflow_file_is_the_text_that_was_reviewed`;
  - `TestGo1265ToolchainBaselineDocsAndBuildContract`.

Not run:
- the gate's "Test" and "Listed tests still fail" steps locally on the real
  module (CI ran them on `af266dc`; see above);
- macOS;
- a CI rerun.

## Sensitive-material handling

- Nothing sensitive was involved. The self-check builds throwaway modules in
  temporary directories.
- The evidence holds:
  - logs of test names and results;
  - two public CI job logs, in which GitHub masks the checkout's
    credential as `***`;
  - public CI step times.
- A scan of the evidence (Ran) is under "Report delivery".

## Remaining uncertainty and stop conditions

- The 20- and 90-minute values rest on the 5 CI runs I read (one of them
  timed out at 600 s) and on two containers. A runner more than twice as slow
  as the slowest seen could still reach them (Inference, as the writer says).
- If trunk_dev moves before the merge (for example, if #59 merges first), the
  new head needs a new manifest and a sync check.

## Confidence

- Provenance: high.
- Validation: high (self-check, mutants, CI on the PR's own bytes).
- Implementation: high.

## Effect status

- No repair, commit, push, PR comment, review, merge or CI rerun.
- Nothing outside this container changed.

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/ci-gate-time-limit/02-pr61-audit.md`;
its sha256 is in the delivery message. Evidence checksums are in
`02-pr61-audit-evidence/SHA256SUMS.txt`.

Before publishing, I scanned the evidence for these (Ran):
- email addresses and user@host names;
- IP addresses other than 127.0.0.1;
- tokens and private keys;
- UUID-shaped values.

What it found:
- the UUIDs are GitHub's runner temp-folder names and worker IDs in the two
  public CI logs;
- the checkout's credential header, which GitHub prints as `***`.

Nothing needed redacting.

## Final verdict

**ACCEPT**

#61 can merge once "build, vet and test" is green on its head and the
branch is up to date with trunk_dev. That check is already green on
`af266dc`, and trunk_dev has not moved.
