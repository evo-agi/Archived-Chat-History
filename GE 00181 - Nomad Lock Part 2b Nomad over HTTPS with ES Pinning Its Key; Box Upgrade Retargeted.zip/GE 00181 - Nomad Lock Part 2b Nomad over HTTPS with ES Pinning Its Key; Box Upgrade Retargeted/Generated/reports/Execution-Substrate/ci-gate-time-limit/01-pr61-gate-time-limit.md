# CI: a 20-minute time limit for each test binary, 90 minutes for the job (ES PR #61)

Writer: the thread "Lock Nomad so only ES can submit", 2026-11-25. This is audit 20's finding A20-3 on PR #60 (audit 21 calls it A23-1). The coordinator asked for a separate CI-only PR.

## Identity

- Repository: evo-agi/Execution-Substrate. PR #61, branch `claude/ci-gate-time-limit`, into `trunk_dev`.
- Base: `bf5a760a2276f5d8b7600d7b64523e4ee32410d0`.
- Tip: `af266dc441f6512d99db82e99395f3374899164b`. Tree: `c9d2d6b3ee322c6b723b467db3b3e203330cda15`.
- Manifest v2 (recipe SHA-256 `c08597e2…a1e3ca`, verified):
  - canonical manifest `61a59a7d117aefb352413f6583c38782ef0570b899f79bcc777f3e92d088a4c2`;
  - textual diff `dea42c3885de84429ffed3a13df6e51f6c54b676ac5811b16fdca9249feb4b94`;
  - 5 files, +80/-8.
  - It was taken twice with identical bytes, and the staged path set equals the manifest's.
  - The manifest is saved as `manifest-v2-af266dc.json` beside this report.

## Why

The gate's `go test` calls passed no `-timeout`, so `go test`'s default of 10 minutes applied to each test binary. The job's limit was 60 minutes.

| Run | Commit | es/app gated run | Job |
|---|---|---|---|
| 45539140560 (push) | trunk_dev `bf5a760` | 432.3 s (observed rerun 393.0 s; still-failing run 393.6 s) | 42.1 min |
| 45545850585 (PR #59) | `6c40bd8` | 426 s (per audit 20) | |
| 45493398780 (push) | trunk_dev `8129b82` | 577.9 s (observed rerun 534.4 s; still-failing run 521.3 s) | 57.1 min |
| 45546737121 (PR #60) | `f505f72` | timeout panic at 600.0 s | stopped at 27.9 min |

- On #60's runner, packages that #60 does not touch were slower than on the bf5a760 run:
  - scripts 398 s against 326 s;
  - es/admission 315 s against 241 s;
  - callerauth 65 s against 49 s;
  - reliablesubmit 51 s against 35 s.
- In the writer's container, with Docker up and the gate's skips, es/app took 591.7 s at `2ca76cd` (es/app is the same at `bf5a760`) and 625.4 s at `f505f72`.
  - The 9 tests #60 adds took 21.7 s.
  - Per-test times are in `time-head.json` and `time-base.json` (go test -json) in the writer's container. They are not copied here.

## What changed

- `.github/ci/go_test_gate.py`:
  - `TIME_LIMIT = "20m"`;
  - `go_test_json` runs `go test -json -timeout=20m ...`, so every go test of the gate that runs tests carries it: the gated run, the observed run, the run of the packages without entries, and each still-failing package run and entry run;
  - `go test -list` is not changed.
  - Why 20 minutes: about twice the slowest whole-package run seen (about 10 minutes on the slowest runner), which holds a runner spread of up to half with room for growth. A hung test binary still panics with its goroutine stacks.
- `.github/workflows/go.yml`:
  - `timeout-minutes: 90`, up from 60, with a comment;
  - the slowest passing job seen took 57 minutes;
  - the per-binary limit must be able to fire inside the job even in "Listed tests still fail". On the slowest runner seen, that step started at about minute 39, so 39 + 20 = 59 is under 90.
- `.github/ci/go_test_gate_selftest.py`:
  - `WORKFLOW_SHA256` updated;
  - `GateCase.check` calls the new `time_limited`, which requires every `go test -json` line of every checked run to start `-timeout=20m -count=1`;
  - the new `GateGivesEveryTestBinaryItsTimeLimit` case requires exactly 3 such runs (gated, observed, unlisted package), so the check is not vacuous;
  - the regexes of `package_runs`, `observed` and the per-entry runs include the flag;
  - `SHORT_TIME_LIMIT_GO` replaces any `-timeout=` argument with `-timeout=5s`, because a command-line flag wins over `GOFLAGS`. Without that, the test of a run that the time limit stops would wait 20 minutes.
- `.docs/system_overview/go_toolchain_baseline.md` (section 10): one paragraph stating both limits and why.
- `docs_contract_test.go`:
  - pins the two doc sentences, `timeout-minutes: 90` in the workflow, and the gate's `TIME_LIMIT` constant and command line;
  - the existing check still requires the selftest to hold the workflow's SHA-256.

Not changed: `go_test_as_root.py` keeps its own 10-minute limit for the few root-only tests of `scripts`, each of which takes seconds.

## Tests (Ran)

- Gate selftest, with go1.26.5 copied outside the module cache (`/opt/go1.26.5`), `GOTOOLCHAIN=local GOFLAGS=-mod=readonly GOPROXY=off`:
  - `python3 -I -B .github/ci/go_test_gate_selftest.py` passes, 133 tests in 204 s and 216 s (two runs, the second after a comment-only edit).
- Mutant: with the gate's `-timeout` removed, `GateGivesEveryTestBinaryItsTimeLimit` and `ListedTestsMustStillFail.test_passes_when_every_listed_test_fails` both fail.
- Root package `go test -count=1 .` (the docs contract tests): ok.

## Limits

- The 20-minute and 90-minute values are judgement from 4 runs and one container. Inference: a runner more than twice as slow as the slowest seen could still reach them.
- Splitting es/app or the job would shorten wall time. It would also change the required check's name, which is a ruleset change and not part of this PR.
- PR #59 (macOS gate) edits the gate and the selftest too. Whichever merges second needs a merge of trunk_dev. Its new workflow would get the same per-binary limit through the gate.

## CI on af266dc (Ran)

- Run 45555695320, job 139007081830 ("build, vet and test"): passed, 05:44:52 to 06:28:23Z (43.5 minutes).
- All 25 `+ ... go test -json` lines in the job log carry `-timeout=20m -count=1`: the gated runs, the observed run, the unlisted-package run, the still-failing package runs and every per-entry run. None lacks it.
- es/app on this runner, from the log's timestamps (each includes the build): gated run about 453 s, observed run about 404 s, still-failing run about 419 s. That is the normal-speed runner class, like the bf5a760 run above.
