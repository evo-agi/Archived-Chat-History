Overnight update: nothing needs you until morning.

**Done**
- The macOS CI job merged ([PR 59](https://github.com/evo-agi/Execution-Substrate/pull/59), merge SHA 819f712). CI now runs every script test on a Mac runner too.

**Still working**
- Nomad over HTTPS ([PR 60](https://github.com/evo-agi/Execution-Substrate/pull/60)) is in its final check, then the red-team and the box run.
- A small collector fix ([PR 62](https://github.com/evo-agi/Execution-Substrate/pull/62)) heads off a likely break on your Mac after a macOS update. It's waiting on CI, then audit and red-team.

**For the morning:** please make "test on macOS" a required check in the trunk_dev branch rules.

STATUS: WORKING (PR 60 final check; PR 62 CI)
