**Red-team of PR #60 (Nomad over HTTPS): ACCEPT — no blocking findings.**

I attacked a real Nomad 2.1.1 built from the PR's own scripts, as an unprivileged local user and a rogue local Nomad server. Nothing let a caller, container, or local user submit without ES, defeat the key pin, or downgrade TLS, and the root-run upgrade couldn't be driven into damage or a silent downgrade.

What held (all run, not just read):
- **No submit without ES:** anonymous API and writes → 403; `/v1/acl/policy/anonymous` → 404; plain HTTP → 400; raw RPC without a CA-signed cert → refused.
- **Pin holds:** a cert the same CA signs with another key is refused; the pin is read identically by openssl, the Python DER walker, and Go. The CA key is destroyed and the server key is root-only, so no one can mint an accepted cert.
- **No downgrade:** TLS 1.3 only, both ends; `--tls-max 1.2` is rejected.
- **The migration is the real fix for RT-4:** on the box's *current* plain-HTTP shape a local user can still stand up a rogue Nomad, join raft, and read Nomad's management + ES tokens out of the replicated log (I reproduced this). Over HTTPS that same join can't replicate — TLS blocks it. So this PR closes a currently-live local token-theft path.
- **Upgrade script:** refuses every shape it wasn't written for; the `nomad config validate` warning-guard is load-bearing and matches 2.1.1's wording (an unreadable-TLS config validates "valid" with only a warning); rollback can only remove `/etc/nomad.d/tls`. The real-Nomad end-to-end migration test passes (earlier failures here were Docker/AWS-fingerprint env, not the PR).

Two backlog items, neither a blocker:
- **RT60-1 (Low):** Nomad's serf gossip has no encryption key, so a *local* user can add a non-replicating phantom raft member and make autopilot report unhealthy. No read, no vote, no submit — RPC-TLS blocks replication; loopback-bind + the host firewall keep containers and LAN peers out. Pre-existing (gossip was unencrypted before too) and outside this PR's HTTP/RPC-TLS scope. Suggest a follow-up gossip key or a doc note.
- **RT60-2 (assumption to record):** the upgrade runs its sibling scripts from the checkout as root; integrity rests on the documented `chown -R root:root` before check/apply. Keep that as a hard box-run precondition.

Head note: the PR advanced to `4795a4f` after I started (the #59 macOS-CI merge) — I diffed it; the delta is CI, test files and docs only, no part-2b product code, so the review at `977b172` stands.

Report: [24-pr60-redteam.md](/mnt/project-files/reports/Execution-Substrate/nomad-acl/24-pr60-redteam.md) (SHA-256 `9ad3c160bf176ad87fd86c780a4c570c94650416ff6d7028533a905b78116b80`), evidence in `24-pr60-redteam-evidence/`. Read-only throughout; nothing pushed, box untouched.

STATUS: READY — red-team done, ACCEPT. Merge gate is yours; RT60-1/RT60-2 are for the backlog.
