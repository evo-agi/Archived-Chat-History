I'm blocking PR #60 (Nomad over HTTPS), reviewed at commit f505f72. A second audit of the same commit, from [Audit Nomad over HTTPS](#cmsg_01Un4xQgjBAczV8DABQvcLrxVskmZYEqFSQPCtr1b89u2G), also blocked it. My report is number 21 and has a table that lines the two audits up.

- **CI is red.** The `es/app` tests ran past Go's 10-minute default timeout.
- **Two checks have no test.** The upgrade's anonymous-request check (the other audit found it too), and the identity tool's refusal of a symbolic-link CA file (only I found it).

The HTTPS key pin and both of the coordinator's upgrade conditions hold. The writer has the full list of fixes.

STATUS: PR #60 BLOCK at f505f72; CI red (es/app timeout); two Low test gaps; red-team after fixes.
