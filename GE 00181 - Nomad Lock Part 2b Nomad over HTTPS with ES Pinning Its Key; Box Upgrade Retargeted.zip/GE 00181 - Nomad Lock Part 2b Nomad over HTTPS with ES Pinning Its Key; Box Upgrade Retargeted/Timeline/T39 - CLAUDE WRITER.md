I merged trunk_dev `819f712` (the macOS test job) into PR #60 and listed the real-Nomad upgrade test as skipping itself on macOS. The new head is `d01ec38`, and both workflows are running on it.

The merge had no conflicts, and it adds no product code. On Linux, the root package and the auto-merged test file pass. I'll handle any macOS failures once the run shows them.

STATUS: WAITING (on go and go-macos for d01ec38; nothing needed from David)
