The Nomad HTTPS red-team found no way around it, so a last check of its CI-only changes is starting.
