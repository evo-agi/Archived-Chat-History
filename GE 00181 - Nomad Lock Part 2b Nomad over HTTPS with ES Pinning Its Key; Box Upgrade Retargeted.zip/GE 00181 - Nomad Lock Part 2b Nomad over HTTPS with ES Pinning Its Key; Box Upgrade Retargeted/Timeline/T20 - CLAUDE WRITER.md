CI on [PR #60](https://github.com/evo-agi/Execution-Substrate/pull/60) passed on the repaired head `dfb2873` ([run 45555027151](https://github.com/evo-agi/Execution-Substrate/actions/runs/45555027151)). That run landed on a normal-speed runner, so a slow one could still hit the 10-minute limit until #61 merges. #61's own CI is still running.

STATUS: WAITING (on the re-audit of #60 and an audit of #61; nothing needed from David)
