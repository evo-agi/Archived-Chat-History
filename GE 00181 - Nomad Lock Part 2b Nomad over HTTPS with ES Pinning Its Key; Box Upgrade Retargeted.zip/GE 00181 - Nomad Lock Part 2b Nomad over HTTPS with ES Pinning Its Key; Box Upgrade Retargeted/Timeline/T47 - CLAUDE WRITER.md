The PR 60 box run is planned and ready to go as soon as the merge lands. Everything is in [plan.md](/mnt/project-files/reports/Execution-Substrate/nomad-acl/25-box-run/plan.md). At merge time one command fills in the merge commit and writes the Remote Control brief, so the run can start in the next box turn.

- **Phases:** build, check, apply once, verify, then one real ES run end to end. The real run also has the observer token list ES's jobs before and after, which shows the list-jobs fix working.
- **Root-owned checkout (RT60-2):** the run's own script already enforces this. It refuses to check, apply or roll back unless nobody but root can change the checkout.
- **Rollback:** if ES or AGS is unhealthy after an "applied" result, the brief rolls back automatically, and the phase checks the health again itself first. A failed submit on a healthy box is reported for diagnosis, not rolled back.
- **Testing:** I ran every phase against local stand-ins of the box (a TLS 1.3 Nomad with setup-issued material, plus ES and AGS), with the real identity check. The refusals and the rollback guards behave as intended.

**Follow-ups:** RT60-2 gets its own small PR right after PR 60 merges, putting the same refusal into the upgrade itself. RT60-1 (the gossip key) follows once the box run passes. Both are in state.md.

CI on 4795a4f: test on macOS is green, and the Linux run is still going.

STATUS: PR 60 waits for the final delta check and your word to merge; box run ready at merge.
