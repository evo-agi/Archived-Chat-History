The macOS run on PR #60 failed, and all its failures have one cause. I listed those tests as Linux-only with the reason, rather than porting the code. The new head is `4795a4f`, and both workflows are running on it.

**The cause:** after the upgrade issues Nomad's TLS material, it checks it with the setup's `nomad_tls_material_ok`, which reads the key's mode with GNU `stat -c`. macOS `stat` has no `-c`, so on macOS every apply rolls back and `check` reports the material as failing. That accounts for every failure: one subtest and five whole tests, all in the upgrade.

**Why Linux-only rather than portable:**
- The setup script and the upgrade only run on the Linux box.
- Replacing `stat` is cheap, but the same check also runs `openssl x509 -checkhost`/`-checkip`, written for the box's OpenSSL 3. I'm not sure macOS LibreSSL supports those, and I can't test macOS here, so porting could take several macOS runs.
- Porting would also change product code that the red-team is reviewing now.
- The macOS list already handles other box-only helpers that use GNU tools this way.

The cost is that macOS no longer covers the upgrade's apply path. Linux CI still runs all of these tests.

STATUS: WAITING (on go and go-macos for 4795a4f; nothing needed from David)
