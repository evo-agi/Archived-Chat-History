I pushed the A22-1 fix to PR #60, together with the merge of trunk_dev. The new head is `977b172`, which is ready for the diff-only check once CI is green.

Locally, `testutil`, `es/admission`, the root package and all 16 upgrade tests pass, the real-Nomad one included. The whole `scripts` package fails 28 tests, and the same 28 fail on base here. This container has no `ssh` or `scp`, which those tests need, and 8 of them are known environment-only tests.

CI run 45565423373 is now running. It is #60's first run with the 20-minute limit. Section 14 of the report covers the fix and the new head.

STATUS: WAITING (on CI for 977b172, then the diff-only check and the red-team; nothing needed from David)
