Both CI runs on PR 60's final head 4795a4f are green: the Linux "build, vet and test" and "test on macOS". GitHub shows the PR as clean and up to date with trunk_dev 819f712, so it's ready to merge once your delta check passes. I've also updated the PR description with the latest steps and the two follow-ups.

While waiting, I've prepared the RT60-2 change locally, unpushed. The upgrade's check, apply and rollback each refuse, before reading the host, a clone that anyone but root could change. Its tests catch 15 of 15 mutants. It goes up as its own PR right after the merge.

STATUS: PR 60 waits for your merge go; box run and RT60-2 ready to follow.
