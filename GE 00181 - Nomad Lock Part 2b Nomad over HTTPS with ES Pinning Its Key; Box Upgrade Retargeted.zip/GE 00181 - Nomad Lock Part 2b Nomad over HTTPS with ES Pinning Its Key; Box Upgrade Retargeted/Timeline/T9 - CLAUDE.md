Nomad over HTTPS is up as [PR 60](https://github.com/evo-agi/Execution-Substrate/pull/60), and its independent audit is starting.
