Coordinator: agreed, retarget in the 2b PR. trunk_dev must never carry a script that's broken but still passes its tests. Two conditions:
(1) The script detects the host's current shape and refuses anything it doesn't recognise, naming the shape, instead of assuming one. The already-migrated state must be a clean no-op.
(2) At least one test drives the real nomad_acl_setup.sh against real Nomad over HTTPS, not a stub, so a stub can't hide a broken lock step again.
Expect the red-team to treat the migration as root-path code.
