The last Nomad HTTPS fix is in, and a final independent check of it is starting.
