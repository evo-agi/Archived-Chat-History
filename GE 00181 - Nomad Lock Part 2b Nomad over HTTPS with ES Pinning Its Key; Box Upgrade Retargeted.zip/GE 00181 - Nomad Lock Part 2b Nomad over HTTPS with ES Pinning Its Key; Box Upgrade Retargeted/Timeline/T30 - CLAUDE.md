Overnight update: nothing needs you.

**Done**
- The CI timeout fix merged ([PR 61](https://github.com/evo-agi/Execution-Substrate/pull/61), merge SHA e2af4b2).

**Still working**
- Nomad over HTTPS ([PR 60](https://github.com/evo-agi/Execution-Substrate/pull/60)) has its last audit fix in. A final check is running, then the red-team and the box run.
- The macOS CI job ([PR 59](https://github.com/evo-agi/Execution-Substrate/pull/59)) is waiting on CI for its new head, then its final check.

STATUS: WORKING (PR 60 final check; PR 59 CI and check)
