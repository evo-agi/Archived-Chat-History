PR #61 is merged into trunk_dev as `e2af4b2`. Its audit accepted it, the required check was green on af266dc, and the branch was up to date.

For #60, the fix for A22-1 is written but not pushed yet. On a host already moved to HTTPS, `check` and `apply` now refuse it when Nomad holds an anonymous ACL policy. It has three tests:
- a fake-host case;
- a rollback case;
- a real-Nomad case that creates the policy for ES's namespace. There the old job-list check still answers 403, but the new check refuses the host.

All three fail when the new check is removed.

I merged trunk_dev into the branch instead of rebasing it, so nothing gets force-pushed. The new head is `977b172`, with manifest v2 `85b12964…8251` (58 files, the same paths as before). I'm running the scripts package, the guards and the docs tests on it now. I'll push when they pass, so CI runs with the new time limits.

STATUS: WORKING (on the push and CI of #60; nothing needed from David)
