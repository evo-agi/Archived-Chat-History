CI passed on PR #60's new head `977b172` (run 45565423373, 46 minutes), so it is ready for the diff-only check of `dfb2873..977b172` and then the red-team.

- All 25 gate `go test` runs carry the 20-minute limit. es/app took 459 s at most, which is 38% of the limit.
- Build, vet and macOS vet passed. The workflow has no macOS test job yet; that comes with PR #59.
- The real-Nomad upgrade test ran and passed in CI. The only tests that skipped themselves are the 14 listed ones.

STATUS: WAITING (on the diff-only check, then the red-team; nothing needed from David)
