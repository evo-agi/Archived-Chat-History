**Verdict: BLOCK** on PR #60 at `f505f72`. The HTTPS lock and the key pin themselves hold. What blocks it is two Low gaps in the PR's own code and its red CI run.

**Findings**
- **A20-1 (Low, in the diff).** ES's CA-file loader is looser than its comment, `configuration.md` and the writer's report say. It accepts text before or between the certificates, and it silently skips a corrupt PEM block. I ran a probe to confirm this. It fails closed and adds no trust, but no test pins the contract. The fix is a stricter loop plus three test cases.
- **A20-2 (Low, in the diff).** No test pins three new refusal checks. Removing each one passes every test that reaches it:
  - the upgrade `check`'s anonymous-403 check on an already-migrated host. A mutant removing it survived all 16 upgrade tests, the real-Nomad one included.
  - the TLS identity tool's loopback-IP check.
  - the proof fetch's `NOMAD_CACERT` check. Without it, an unset variable makes Python trust the system CA store.
- **A20-3 (Medium, not caused by this PR).** CI run 45546737121 on the head failed. `es/app` hit Go's default 10-minute test timeout, because the gate passes no `-timeout`. On the other runs today `es/app` took 393 to 432 s, and this runner was 15 to 48% slower even on packages the PR doesn't touch. The PR adds about 20 s. I recommend a separate CI-only PR that gives the gate an explicit timeout.

**The author's failure claim holds** (Ran). Head and trunk_dev `bf5a760` fail the same 13 tests here (43 counting subtests), for the same reasons. The same 14 tests skip themselves on both.
- `reliablesubmit`: TestOperationalHandoffSchema4BinaryRefusesSchema5, TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation, TestSQLiteV3OldBinaryRefusesWithoutMutation
- `es/app`: TestBringupScriptUpCheckDownFullProfile, TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity
- `scripts`: TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal, TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody, TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution, TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal, TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap, TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition, TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression, TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap

12 of the 13 are on CI's environment-only list. The bring-up test fails here only because its image build needs the internet. With an offline image of the same commit it passes on Nomad 2.1.1 and 2.0.0.

**Other checks I ran**
- On Nomad 2.0.0, all 16 upgrade tests pass, and `es/app` has only its 2 environment-only failures.
- 28 mutants: 20 killed. The 8 survivors sit at the 3 sites in A20-2 plus one gap that already exists on trunk.

**Provenance and effects.** I verified the recipe hash. The opening and closing manifests are identical, `e3904b35…1d5e`, 58 paths. I pushed, commented and reran nothing, and didn't touch the box.

Report: [20-pr60-audit.md](/mnt/project-files/reports/Execution-Substrate/nomad-acl/20-pr60-audit.md), SHA-256 `5f4a0d5d521f25f5ddacee5689dcad284201724d84e0de9eb647ad1fe10226e2`. Evidence and checksums are in `20-pr60-audit-evidence/`.

STATUS: audit done, BLOCK on A20-1 and A20-2 (Low, in the diff) plus the red CI run (A20-3); to close it, fix those, get CI green on the new head, then a diff-only recheck. The red-team can start now.
