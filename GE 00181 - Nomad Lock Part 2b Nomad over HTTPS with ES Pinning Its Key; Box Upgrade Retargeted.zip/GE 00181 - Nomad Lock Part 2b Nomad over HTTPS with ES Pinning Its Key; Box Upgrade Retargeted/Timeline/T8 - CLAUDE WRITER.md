Part 2b is up for audit as draft [ES PR #60](https://github.com/evo-agi/Execution-Substrate/pull/60): Nomad now runs over HTTPS and ES pins its server key. The PR also lets the observer list ES's jobs and retargets the box upgrade script to this change. That script refuses any box shape it doesn't recognise and is tested against a real Nomad. Every remaining test failure also fails on trunk_dev here. Report attached.

STATUS: waiting on CI and the auditor; Fable red-team and box run come after.
