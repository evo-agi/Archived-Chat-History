Understood. I'll leave PR #60 at `977b172` until the diff-only check returns, then merge trunk_dev `819f712` along with any fixes.

A trial merge with `819f712` has no conflicts. The macOS job will probably need work on #60, though, and I can't run macOS here, so the first macOS run after the merge will show how much:
- The real-Nomad upgrade test skips itself on macOS by design, so it needs a "skips-itself" line in the macOS list.
- The upgrade tests now issue TLS material with the setup's `nomad_tls` functions. Those use GNU `stat -c` and OpenSSL options, which macOS's BSD `stat` and LibreSSL may not support. If they fail there, I'll either make those functions portable or list those tests as Linux-only with the reason, since the upgrade itself only runs on the Linux box. I'll recommend one once I see the run.

STATUS: WAITING (on the diff-only check of 977b172; nothing needed from David)
