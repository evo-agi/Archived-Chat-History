Nomad over HTTPS ([PR 60](https://github.com/evo-agi/Execution-Substrate/pull/60)) passed its final check, and its red-team is starting.
