Re-audit Nomad HTTPS and CI timeout
