Check Nomad HTTPS macOS CI delta
