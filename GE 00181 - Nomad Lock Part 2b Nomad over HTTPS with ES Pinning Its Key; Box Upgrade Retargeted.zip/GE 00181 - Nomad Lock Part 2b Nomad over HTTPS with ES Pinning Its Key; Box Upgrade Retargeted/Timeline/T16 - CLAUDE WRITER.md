The audit repairs are pushed to [PR #60](https://github.com/evo-agi/Execution-Substrate/pull/60) at `dfb2873` (manifest `b091699a…0df`). The separate CI-only fix is [PR #61](https://github.com/evo-agi/Execution-Substrate/pull/61).

- **#60:** ES now refuses a CA file with stray text or a corrupt block (A20-1). The five unpinned checks now have tests (A20-2, plus audit 21's linked-CA item). All 9 mutants that survived the audits now fail a test, and the guards pass.
- **#61:** es/app takes 592 s on base here, right at go test's 10-minute default. The gate now gives each test binary 20 minutes and the job 90.

Both need an audit. #60 should merge after #61 so its CI is reliable.

STATUS: WAITING (on the re-audit of #60 and an audit of #61; nothing needed from David)
