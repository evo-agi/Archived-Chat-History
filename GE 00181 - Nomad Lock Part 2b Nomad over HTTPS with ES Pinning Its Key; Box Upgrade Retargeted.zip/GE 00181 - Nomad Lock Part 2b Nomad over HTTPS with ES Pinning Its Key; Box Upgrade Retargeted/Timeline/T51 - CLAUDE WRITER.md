A26-1 is fixed in head c492cb9, and CI is green on it: both "build, vet and test" and "test on macOS". It's ready for the diff-only check. The only change since 4795a4f is one entry in the macOS test list. The upgrade check test is now listed whole instead of just one subtest, and the comment says why. There's no product code in the change. The list still parses (28 entries, 81 skips) and the gate self-test passes. The report's section 15 records it.

STATUS: PR 60 at c492cb9 waits for the diff-only check and your merge go.
