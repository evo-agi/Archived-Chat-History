PR #60 is merged into trunk_dev as `7e27168` (7e271681b63e33891f287ca0f745d45cebeee4f5). The gate held on the final head `c492cb9`: it was up to date with trunk_dev `819f712`, and both "build, vet and test" and "test on macOS" were green. The merge tree is identical to `c492cb9`'s.

I'm starting the box run on the Mac now, using the planned brief built for `7e27168`. I'll report when the box is back and working.

STATUS: #60 merged; box run starting.
