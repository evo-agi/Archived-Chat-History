PR #68 has fallen behind trunk_dev again, so 8e056aa won't be the head that merges. #72 landed on trunk_dev at 8:18 PM Eastern (as fbfd100).

- **The next sync is already covered.** Git's own merge of 8e056aa with fbfd100 gives tree 5620646f. That is the exact tree my #72 trial merge built, vetted and ran the root and `internal/testutil` tests on, and they passed (`05-evidence/trial-merge-pr72.txt`). If the writer's sync produces that tree, no auditor round is needed under the merge-queue rule.
- **CI on 8e056aa so far:** macOS passed at 8:02 PM Eastern; Linux is still running. Syncing now would supersede that run, and the merge needs green CI on the synced head anyway.

STATUS: WAITING (on Linux CI for 8e056aa; next check 8:42 PM Eastern)
