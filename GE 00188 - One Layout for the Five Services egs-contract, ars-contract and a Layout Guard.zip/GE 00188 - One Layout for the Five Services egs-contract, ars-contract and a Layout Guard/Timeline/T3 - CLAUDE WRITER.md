I'm comparing the service directories on origin/trunk_dev and tracing where es/internal and egs/model came from.
