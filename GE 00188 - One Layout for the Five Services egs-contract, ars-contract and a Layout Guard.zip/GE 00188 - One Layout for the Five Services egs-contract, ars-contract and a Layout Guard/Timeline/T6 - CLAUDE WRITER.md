Asked the project to choose an option

Which layout should all five ES services follow?

1. Same rules, two small moves (recommended): egs/model becomes egs/contract, ARS gets ars/contract, es/internal stays, plus a guard test and README rules. About 30 files, no behaviour change, normal audit.
2. Everything under <svc>/internal/: Identical folders everywhere, compiler-enforced. Moves es/admission (994 references in 74 files) and needs new test-harness packages.
3. Document only: Explain the current layout in the README. No code moves; model keeps its name and ES keeps compiling the ARS server.

Why recommended: It makes every service follow one written, test-enforced rule for a small behaviour-free diff, and it also stops ES and AGS from compiling ARS's server.
