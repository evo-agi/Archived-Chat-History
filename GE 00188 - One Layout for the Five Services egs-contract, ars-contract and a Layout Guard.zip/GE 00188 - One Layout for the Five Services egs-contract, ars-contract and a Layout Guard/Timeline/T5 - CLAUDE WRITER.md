Both folders are there on purpose. The bigger layout inconsistency is actually in ARS. The full write-up is [es-service-layout.md](/mnt/project-files/reports/design/es-service-layout.md), read at `trunk_dev` 923e9c3.

**Why `es/internal/`:** ES is the only service whose own packages share code. The admission service and the runtime helper both use `ownershipnorm` and `staticarchive`, so those need a home above both. Go's `internal/` rule makes that home importable only from inside `es/`. The third package there, `outsideobserverprotocol`, is switched off on purpose, and the standing rules call it "ES-private". The other four services are small and share nothing between their own packages, so they don't need it.

**Why `egs/model/`:** it holds the trust policy plus the exact bytes EGS signs. ES recomputes those bytes to check EGS's signature, so both services have to run the same code. A small package with no server code lets ES use it without importing EGS's HTTP server. The docs call it an EGS-owned contract that is deliberately kept out of the shared `internal/contracts/`. "Model" is just a vague name. Why it was chosen is unknown, because the history before April 2026 was squashed.

**The real outlier is ARS.** Its wire types sit next to its HTTP server, so the ES and AGS programs both compile in ARS's server and blob store. EGS's split is the better pattern.

**Would `internal/` help the other services?** Not much today. It would break in-process integration tests without catching any current problem. A guard test protects production code just as well.

**My recommendation:** keep the shape all five services already share. Rename `egs/model` to `egs/contract` and give ARS the same kind of `ars/contract` package. Keep `es/internal/`. Add a guard test so services can only import each other through `contract`, and write the rules into the README. I tried the two moves in a scratch copy:
- 30 Go files changed, and the build and vet are clean.
- After the moves, ES compiles in only the two `contract` packages from other services.
- The tests match unmodified `trunk_dev`, except for one expected failure: a guard pins a hash of a reviewed reliable-submit file whose import line changes, so the real PR updates that pin.

Nothing is pushed. The card below has the alternatives.

STATUS: NEEDS DAVID (pick a layout on the card; low priority, nothing waits on it)
