> The egs rename goes ahead, and es stays as it is. ARS is an outlier because the request and response types that ES and A…


Hmm... If `ars/contract` resolves the issue you are describing, then sure.
