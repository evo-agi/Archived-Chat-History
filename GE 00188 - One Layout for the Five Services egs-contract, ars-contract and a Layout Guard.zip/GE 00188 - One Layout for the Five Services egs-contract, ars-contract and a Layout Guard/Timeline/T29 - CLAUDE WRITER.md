PR #68 is ready for a fresh check at **8e056aa**, on `trunk_dev` 39e19de. R68-1 and R68-2 are fixed in e760c67, and CI passed there on Linux and macOS. #71 then landed and the PR fell behind, so I merged `trunk_dev` in without a rebase. The merge was clean and the PR's own diff didn't change. The root tests pass, and CI on 8e056aa is running. The PR #70 overlap is settled: whichever PR lands second adds four exception lines.

STATUS: WAITING (on the fresh check of PR #68 at 8e056aa; nothing needed from David)
