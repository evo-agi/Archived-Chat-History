Some low-priority style-related queries about ES:

* Why does es/ have a internal/ package, when other services don't?
* Why does egs/ have a model/ package, when other services don't?
