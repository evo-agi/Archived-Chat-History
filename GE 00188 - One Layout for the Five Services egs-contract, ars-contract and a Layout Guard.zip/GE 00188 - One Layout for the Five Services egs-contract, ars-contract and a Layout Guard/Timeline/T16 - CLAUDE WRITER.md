I opened draft [PR #68](https://github.com/evo-agi/Execution-Substrate/pull/68). It renames `egs/model` to `egs/contract`, moves ARS's wire types into a new `ars/contract`, and leaves `es/` as it is.

**Your ARS condition holds.** `go list -deps` shows that the ES program now compiles only `ars/contract` and `egs/contract` from other services. Before, it compiled `ars/api`, `ars/index`, `ars/store` and `egs/model`. AGS now compiles only `ars/contract`. The result is the same on Linux and macOS builds.

The PR also adds a test that keeps the layout consistent. It fails if a service is missing `api/`, `app/` or `config/`, if a package gets a vague name like `model`, or if one service reaches into another except through its `contract` package. Run against today's `trunk_dev`, it flags exactly the old layout. The README now states these rules.

**One small change to your earlier root-folder rule:** the repo root now also keeps this new test, as a repo-wide check next to `artifact_hygiene_test.go`.

The full test suite gives the same results as unmodified `trunk_dev`, with no new failures. The tests that fail on both need Nomad or a non-root user, which this container doesn't have. The PR's CI covers them. Next come the audit and merge gate.

STATUS: WAITING (on PR #68's CI and its audit; nothing needed from you)
