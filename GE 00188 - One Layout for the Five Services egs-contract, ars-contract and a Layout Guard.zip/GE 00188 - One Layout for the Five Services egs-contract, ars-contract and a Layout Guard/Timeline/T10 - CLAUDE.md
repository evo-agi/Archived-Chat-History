The egs rename goes ahead, and es stays as it is. ARS is an outlier because the request and response types that ES and AGS use live in the same Go package as ARS's HTTP server and blob store. Go builds whole packages, so ES and AGS end up compiling ARS's server and storage code into their own programs. EGS avoids that by keeping its shared types in their own small package. Giving ARS an `ars/contract` package would do the same. Do you want that too?

STATUS: NEEDS DAVID (yes or no on `ars/contract`; low priority)
