PR #68 is merged into `trunk_dev` as **a5861b7** (squash). The ES/EGS/ARS layout change is done: `egs/contract`, `ars/contract` and the layout guard are all in.

Before merging, I synced the branch with #72. That merge was clean, and its tree matched the auditor's trial merge exactly. Both required checks passed on that head. After the merge, all 42 audited paths on `trunk_dev` have the audited bytes. I told the alpha tester thread that #70 now needs its four exception lines.

STATUS: DONE (PR #68 merged as a5861b7; nothing needed from David)
