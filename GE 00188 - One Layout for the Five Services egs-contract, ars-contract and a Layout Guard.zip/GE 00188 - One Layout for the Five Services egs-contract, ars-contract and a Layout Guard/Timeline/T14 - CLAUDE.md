It will go in. The PR will include proof that ES and AGS no longer build in ARS's server.

STATUS: WAITING (on the layout PR, and the fixes to PRs 66 and 67; nothing needed from you)
