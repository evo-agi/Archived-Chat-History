> Both folders are deliberate. es/internal holds code the ES programs share and keeps it private to ES. egs/model is the c…


Hmm... egs change makes sense. es can remain untouched. As for ars, not sure why it's an outlier.
