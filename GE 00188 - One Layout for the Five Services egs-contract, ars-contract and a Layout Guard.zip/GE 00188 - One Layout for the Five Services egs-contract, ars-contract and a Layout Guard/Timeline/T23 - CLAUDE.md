The service layout PR fixed its audit findings and passed CI, so a fresh re-check is starting.
