I'll find out why es/ and egs/ differ from the other services, and propose one consistent layout.
