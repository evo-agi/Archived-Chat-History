> Some low-priority style-related queries about ES:


I mean, it's a matter of personal preference and consistency, about the layouts.
