Both folders are deliberate. `es/internal` holds code the ES programs share and keeps it private to ES. `egs/model` is the contract ES uses to check EGS's signatures, kept apart from EGS's server. The real outlier is ARS, because ES and AGS end up compiling in its whole server.

Which layout should all five services follow?
1. **Same rules, two small moves (recommended):** `egs/model` becomes `egs/contract`, ARS gets `ars/contract`, `es/internal` stays, and a guard test plus README rules enforce it. That's about 30 files with no behaviour change.
2. **Everything under `<svc>/internal/`:** identical folders everywhere, enforced by the compiler. It moves `es/admission` (994 references) and needs new test packages.
3. **Document only:** the README explains today's layout, and no code moves.

Reply here with a number. This is low priority.

STATUS: NEEDS DAVID (pick a layout; low priority)
