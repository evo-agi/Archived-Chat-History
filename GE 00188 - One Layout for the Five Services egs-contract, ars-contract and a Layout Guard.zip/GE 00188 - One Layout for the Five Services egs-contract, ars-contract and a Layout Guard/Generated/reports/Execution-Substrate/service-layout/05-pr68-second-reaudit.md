# Second re-audit of ES PR #68 at 8e056aa: R68-1 and R68-2 fixes, and the trunk_dev merge

INDEPENDENT AUDIT REPORT

- Repository: evo-agi/Execution-Substrate
- PR: https://github.com/evo-agi/Execution-Substrate/pull/68 (draft), branch `claude/project-thread-t608v3`
- Base: `origin/trunk_dev` 39e19defb0ea6c0bda30a14f88452b24f9bd9cdf (PR #71 squash, single parent 923e9c3). Still the trunk_dev head when fetched at about 00:30Z and when the trial clone fetched it at about 00:35Z.
- Topic commit: 8e056aaefc96071ebf94acc9d425adf995c9f89f, a merge of 39e19de into e760c67. e760c67 is one commit on 1e3ec7c, the head re-audit 03 checked.
- Tree SHA: 52018ca5333727aedeae96bab0639c872217e24a
- Recipe: `governed-execution.audit-patch-manifest.v2`, source SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified before the opening runs and again before the closing runs)
- Canonical manifest SHA-256: 5226eed67a4d41dba4426f198125644c70ddf259ee489ead9b80ce69af6fd791; textual diff SHA-256 81e0336e895ffc4494e5be7b0f7554cfe569066ca44c7cf7f49812bb0b36a111; 42 entries (37 modified, 2 deleted, 3 new; GitHub shows 40 files because the 2 renames count once each)
- Auditor: fresh read-only thread "Second re-check of service layout PR", started by the coordinator 2026-11-27 00:28Z. It did not write this PR and did not run audits 01 or 03. It read only their delivered reports and the writer's reports.
- Inputs: re-audit 03 `03-pr68-reaudit.md` (SHA-256 8af05b54…88d1), writer repair report `03-pr68-recheck-repair.md` (81102b21…04ce), writer merge report `04-pr68-trunk-merge.md` (24f11cc9…5b79), writer manifests `03-canonical-manifest-e760c67.json` (e5a08d09…b930) and `04-canonical-manifest-8e056aa.json` (5226eed6…d791), the PR description.
- Scope (coordinator brief): verify the R68-1 and R68-2 fixes; confirm the merge left the PR's own diff unchanged; rerun the root tests and the guard on exact bytes, naming failures against base; check CI on 8e056aa. No red-team (the coordinator decided: no runtime change).
- Written: 2026-11-27, about 00:45Z (19:45 Eastern, 2026-11-26).

**Final verdict: ACCEPT.** No open findings at any severity.

- R68-1 is fixed: README line 193 and the guard's header comment now carve out the root's repository-wide tests, and the root at 8e056aa holds exactly 13 Go files, all tests.
- R68-2 is fixed: the new `pkg/leak.go` subtest kills the depth mutant (`>= 2` → `>= 3`), which survived in audit 03. Rerunning audit 03's full mutant battery gives the same result for every other mutant and probe.
- The merge is git's own clean merge. The PR's own changes are byte-identical before and after it, hunk by hunk in the two files #71 also edited.
- Build, vet, the root package and `internal/testutil` pass on both base and tip. No test fails on either side, and none changed outcome.
- **CI on 8e056aa was still running when this was written** (both jobs started 00:26Z). CI on e760c67 was green on both jobs. The merge gate still needs both required checks green on 8e056aa, and branch protection enforces that anyway. I will add an addendum (05a) with the CI result.

For merge order (not defects of this PR): #70 still needs the four agreed exception lines. They are confirmed sufficient at #70's new head 77027f8. Separately, #67 and #70 each break the PLANS.md size cap on trunk_dev with or without #68, unless #69 lands first.

## 1. Audit posture

- Read-only toward GitHub and the repository. No commits, pushes, PR edits, comments or reviews. Writes went only to this thread's container (scratchpad, `/home/ci`, `/opt`) and to this report folder.
- No subagents. Inference: the delta since audit 03 is two files, plus a docs-only merge, so one reviewer with scripts covers it.
- Governing files read: project-context/INDEX.md, procedures.md, repos.md; operating-protocol/claude-operating-protocol.md and provenance-and-audit-evidence.md. I also read reports 03, 03-recheck-repair and 04, and audit 03's evidence README and mutant script.
- Toolchain: Go 1.26.5 (the version `go.mod` names), fetched as `golang.org/toolchain@v0.0.1-go1.26.5.linux-amd64`.

## 2. Provenance reproduction

Commands (provenance §5.3), in a fresh `git clone https://github.com/evo-agi/Execution-Substrate`, `umask 022`:

```
sha256sum -c   # v2 recipe c08597e2…a3ca: OK (shared copy and the copy run)
git fetch origin trunk_dev claude/project-thread-t608v3
test "$(git rev-parse origin/claude/project-thread-t608v3)" = 8e056aae…   # ok
git rev-parse origin/trunk_dev                                            # 39e19def…, the base
git merge-base --is-ancestor 39e19def… 8e056aae…                          # ok
git checkout -f -B claude/project-thread-t608v3 8e056aae…; git clean -fdxq; test -z "$(git status --porcelain)"
test "$(git rev-parse HEAD^{tree})" = 52018ca5…                           # ok
git reset --mixed 39e19def…; git branch --set-upstream-to=origin/trunk_dev
python3 -I v2.py OUT/open1.json && python3 -I v2.py OUT/open2.json && cmp OUT/open1.json OUT/open2.json   # identical
cmp OUT/open1.json 04-canonical-manifest-8e056aa.json                                                     # identical
```

- Opening runs: byte-identical to each other **and to the writer's 04 manifest**. All 42 entries have mode 0644, so no mode differences had to be tolerated. A copy is in `05-evidence/canonical-manifest-8e056aa.json`.
- Closing runs (after all tests, mutants and trial merges, which ran in separate clones and exports): byte-identical to each other and to the opening manifest. The recipe hash was re-verified first. HEAD was still 39e19de on `claude/project-thread-t608v3`, the upstream `origin/trunk_dev`, with no ignored files.
- **Writer's intermediate manifest 03 (e760c67) checked too.** All 42 file records in `03-canonical-manifest-e760c67.json` match the blobs at e760c67: SHA-256 and size for present files, absence for the two deleted ones.

## 3. The trunk_dev merge left the PR's own diff unchanged

Script `05-evidence/provenance_checks.sh.txt`, output `05-evidence/provenance-checks.txt`.

- **No hand edits.** `git merge-tree --write-tree e760c67 39e19de` exits 0 (no conflict) and yields tree 52018ca5, which is exactly 8e056aa's tree. So 8e056aa is git's own clean merge.
- **What trunk_dev brought:** one commit, #71 (923e9c3..39e19de). It changes 10 files, +927/−14: seven `.docs/` files, `PLANS.md`, `ars_blob_verification_docs_contract_test.go` and the new `workload_grants_docs_contract_test.go`. No production Go code.
- **The PR's net diff is unchanged.**
  - `git diff --name-status --no-renames` of 923e9c3..e760c67 and of 39e19de..8e056aa are identical (42 paths).
  - Both shortstats read 40 files, +879/−338.
- **Only two of the 42 paths have a different blob at 8e056aa than at e760c67:** `PLANS.md` and `.docs/execution_lifecycle/es_execution_admission_model.md`. Both were also edited by #71. In both, with line numbers stripped, at `-U0` and at `-U3`:
  - the PR side (923e9c3..e760c67 vs 39e19de..8e056aa) is identical;
  - the trunk side (923e9c3..39e19de vs e760c67..8e056aa) is identical.

  The hunks do not touch: the PR edits `PLANS.md` at lines 387, 425 and 680 and the model doc at 995, while #71 edits elsewhere.
- **Manifest chain 02 → 03 → 04.** The same 42 paths throughout.
  - 02 (1e3ec7c) → 03 (e760c67): only `README.md` and `service_layout_test.go` change, as the repair report says.
  - 03 → 04 (8e056aa): only the two #71-touched files above change.
- This confirms the writer's claim in report 04 by an independent route.

## 4. R68-1: README and guard comment (fixed)

- Delta `README.md:193` (1e3ec7c → e760c67, unchanged by the merge): "Apart from the repository-wide tests at the repository root, Go code lives only in the five service folders, `cmd/`, `internal/` and `scripts/`." `service_layout_test.go:27-32` says the same.
- **Checked against the tree at 8e056aa** (`git ls-tree`):
  - The root holds 13 Go files, all tests. They are the 9 `*_docs_contract_test.go` files (audit 03's 8 plus #71's `workload_grants_docs_contract_test.go`), `docs_contract_test.go`, `artifact_hygiene_test.go`, `service_layout_test.go` and `testtmpdir_main_test.go`.
  - Every other Go file sits under `ags`, `ars`, `cgs`, `egs`, `es`, `cmd`, `internal` or `scripts`. No `.go` file exists anywhere else, including dot directories.
  - The sentence is now true.
- The root's own rule is still held by `TestRootKeepsOnlyItsDocsTests` (`internal/testutil/testutil_test.go:65`), which passed on the tip.
- The new subtest "a test file at the repository root is allowed" (`service_layout_test.go:480-486`) pins the root carve-out. Mutant `len(segments) >= 2` → `>= 1` at `:139` (root files counted as a top-level directory):
  - killed by this subtest alone, running only `TestServiceLayoutRefusals`;
  - survives that run when the subtest is removed;
  - also killed on the real tree by `TestServiceLayout`.

  Evidence: `05-evidence/guard-mutants-extra-8e056aa.jsonl`.

## 5. R68-2: a Go file directly in a new top-level directory (fixed)

- New subtest "a Go file directly in a top-level directory that is not a service" (`service_layout_test.go:475-479`). It expects `pkg/leak.go: top-level directory pkg/ holds Go code`.
- Mutant `len(segments) >= 2` → `>= 3` at `:139`, which is audit 03's surviving mutant "top-level rule only for nested files":
  - **killed**, failing exactly this subtest;
  - with the subtest removed, it survives again.

  So the new subtest is what pins the rule.
- **Audit 03's full battery, rerun unchanged** (`03-evidence/guard_mutants2.py.txt`, SHA-256 0523e0b6…cdd7) on an export of 8e056aa. Results are in `05-evidence/guard-mutants-8e056aa.jsonl`. No mutant failed to build.

  | Kind | 1e3ec7c (audit 03) | 8e056aa |
  |---|---|---|
  | List mutants | 42 killed / 2 survived | 42 / 2 |
  | List mutants without the literal-copy check | 21 / 1 | 21 / 1 |
  | Logic mutants | 22 / 3 | **23 / 2** |
  | Probes as expected | 25 / 25 | 25 / 25 |

  The only change is the R68-2 mutant, now killed. The remaining survivors are the ones audit 03 already explained:
  - dropping `cmd` from `layoutOtherTopDirectories` (makes the guard stricter);
  - remapping `es-workload-api-mock` (O-R1);
  - the minimum-file-count sanity check;
  - the literal-copy check, which the behaviour loops cover for.

## 6. Tests on the exact bytes

- **Setup.**
  - Two `git clone --no-local` checkouts: 39e19de (tree 178defa9…) and 8e056aa (tree 52018ca5…). Both in git mode, owned by an unprivileged user `ci` (uid 1500).
  - Run under `runuser -u ci -- env -i` with HUP/INT/QUIT/TERM/PIPE reset to default (`sigdfl_exec.py.txt`).
  - `umask 022`, Go 1.26.5, `GOTOOLCHAIN=local`, `GOPROXY=off`, module cache downloaded beforehand, `-count=1`. Runner: `05-evidence/run_root.sh.txt`.
- **Commands, per tree:** `go build ./...`, `go vet ./...`, `go test -count=1 -json . ./internal/testutil`.
- **Results** (`05-evidence/root-run-*.txt`, `root-tests-compare.txt`):
  - Base, 00:32:09-00:32:53Z: build exit 0, vet exit 0, tests exit 0, 631 passing entries, 0 failures.
  - Tip, 00:33:23-00:33:30Z: build exit 0, vet exit 0, tests exit 0, 696 passing entries, 0 failures.
  - **No failing test on either side.** No test exists only on base, and no shared test changed outcome.
  - The 65 entries only on the tip are `TestServiceLayout`, `TestLayoutGoFileVisible`, `TestServiceLayoutRefusals` and its 62 subtests. Audit 03 counted 60 subtests; the two new ones come from e760c67. All pass, as do `TestRootKeepsOnlyItsDocsTests` and #71's new docs tests.
  - Both clones had a clean `git status` after their runs.
- **One run voided, caused by my harness, not by the code.** My first tip run, at 00:32:53Z, failed `TestGo1265ToolchainBaselineDocsAndBuildContract` with "go.sum SHA-256 changed". My own `go mod download all`, run in that clone to fill the module cache, had added 36 lines to `go.sum`. I restored `go.sum` with `git checkout` and reran the whole tip sequence (the results above). Record: `05-evidence/root-run-tip-VOID-go-sum.txt`.
- **gofmt:** all 34 changed or added Go files at the tip are clean (`gofmt -l` prints nothing), as are #71's two root test files.
- **Not run here:** the full suite. CI on e760c67 ran it green. Since e760c67, the only changes are #71's docs and root docs tests, which ran above. The Nomad, Vault, SPIRE and docker integration tests and the macOS job are covered by CI.

## 7. CI

- **e760c67** (the code the merge carries): "build, vet and test" (workflow `go`, run 45911905826) success, 23:36:08Z to 00:24:16Z. "test on macOS" (`go-macos`, run 45911905813) success, 23:36:08Z to 00:06:59Z.
- **8e056aa**: "build, vet and test" (run 45916717270, job 140237592743) and "test on macOS" (run 45916717236, job 140237592506), both `pull_request` and bound to head_sha 8e056aa. Both were **in progress** at 00:44Z, having started 00:26:24Z. Guess from the e760c67 timings: macOS done around 00:57Z, Linux around 01:15Z. Result to follow in addendum 05a.

## 8. Trial merges with every open ES PR

Script `05-evidence/trial_merges.sh.txt`, outputs `05-evidence/trial-merge-pr*.txt`. Each open PR head was merged into 8e056aa with `git merge-tree --write-tree`. On each merged export I ran `go build ./...`, `go vet ./...` and `go test -count=1 . ./internal/testutil`. Heads were read from GitHub at about 00:35Z.

| PR | Head | Merged tree | Conflict | build | vet | root + testutil |
|---|---|---|---|---|---|---|
| #63 | 59f1f56 | e05984a7 | none | ok | ok | ok |
| #66 | 08143bd | 48a721a1 | none | ok | ok | ok |
| #67 (stacked) | 69d53de | da75e8f9 | none | ok | ok | `TestPlansStaysWithinItsSizeCap` fails (150,157 B) |
| #69 | 1160f28 | bb48fca5 | none | ok | ok | ok |
| #70 | 77027f8 (new since audit 03's a0e86ea) | 73b34956 | none | ok | ok | `TestServiceLayout` (the four imports) and `TestPlansStaysWithinItsSizeCap` (150,179 B) fail |
| #72 | 553f1a0 | 5620646f | none | ok | ok | ok |
| #73 | affefc6 | 19fa5ab0 | none | ok | ok | ok |

- **#70 and the guard.** At 77027f8 the guard fails on the same four imports as before: `ags/api`, `ags/publish`, `es/admission` and `es/api` from `scripts/remote_alpha_user_identity_test.go`. I added the four `layoutCrossServiceExceptions` lines quoted in `03-pr68-recheck-repair.md` to that merged tree and ran gofmt. With them, `go vet .` is clean and `TestServiceLayout` and its refusal tests pass; only the PLANS cap still fails. Output and the exact diff: `05-evidence/trial-merge-pr70-with-four-exceptions.txt`.
- **PLANS.md cap** (`plansMaxBytes = 150000`): the failures are not caused by #68.
  - Merged with trunk_dev 39e19de alone, without #68, #67 reaches 150,133 bytes and #70 reaches 150,155. #68 adds 24 bytes on top.
  - Merged with #68, #69 brings PLANS.md down to 130,549.
  - This matches the merge-order note already raised in the #71 audit: #69 before #67 or #70.

## 9. Findings

None that require a change to this PR.

### Fixed since audit 03

- **R68-1 (Low, doc): fixed.** Section 4.
- **R68-2 (Low, test gap): fixed.** Section 5.

### Observations (no correction required)

- **O-S1. Audit 03's observations, unchanged.**
  - O-R1: the `es-workload-api-mock` mapping is never exercised, and dropping `cmd` makes the guard stricter.
  - O-R2: a `cmd/zz.go` with no service import passes.
  - O-R3: the refusal test writes a package-level map and restores it.
  - The service-layout code those concern did not change, apart from the comment and the two subtests.
  - The PR description's "Dropping an entry from a list fails the test" is true for every list except the `cmd` entry of `layoutOtherTopDirectories`, whose removal only makes the guard stricter.
- **O-S2. Optional README wording.** README line 193 is now true but does not name the root's guard (`internal/testutil`'s `TestRootKeepsOnlyItsDocsTests`). Audit 03's suggested wording included that pointer; the writer chose a shorter sentence. That is fine: nothing in it is inaccurate.
- **O-S3. Merge order** (coordinator's call):
  - Whichever of #68 and #70 lands second adds the four exception lines. They are confirmed sufficient at 77027f8 (section 8).
  - #69 must land before #67 or #70, or the PLANS cap fails on trunk_dev regardless of #68.
- **O-S4. Report hygiene.** `04-pr68-trunk-merge.md` says "Written … about 00:40Z", but the file was already in the shared folder at 00:27Z (mtime), before this thread started at 00:28Z. Its contents check out (sections 2 and 3). Only the stated time is off.

### Pre-existing (not patch defects)

- The five unformatted Go files outside this PR that audit 03 named. Unchanged here; I did not recheck them.

No contract or authority drift and no security finding. The PR changes no production code since audit 03; 8e056aa differs from 1e3ec7c only in `README.md`, `service_layout_test.go` and #71's docs and root docs tests.

## 10. Validation assessment

- **Re-run here, on exact bytes:**
  - manifest reproduction (opening and closing);
  - writer manifest 03 file records;
  - merge-tree equality;
  - PR-side and trunk-side hunk equality;
  - `go build ./...` and `go vet ./...` on both trees;
  - `go test . ./internal/testutil` on both trees;
  - gofmt on the changed files;
  - 6 targeted mutant runs and audit 03's 116 mutants and probes (plus its pristine baseline run);
  - trial merges of 7 open PRs, plus #70 with the four exceptions.
- **Not re-run:**
  - the full suite and the macOS job (CI; green on e760c67, running on 8e056aa);
  - audit 03's reverse-rename proof, `go list -deps` and the runtime probe. No production Go file changed since 1e3ec7c: the 02 → 04 manifest chain shows only README, the guard, and #71's two docs files changing.

## 11. Sensitive-material handling

Nothing sensitive was read or copied. The manifests hold paths, modes, sizes and hashes only. The evidence holds test output, mutant results and scripts.

## 12. Remaining uncertainty and stop conditions

- CI on 8e056aa is unfinished. If either job fails, this acceptance does not carry to the merge gate until the failure is explained. Addendum 05a will record the outcome.
- If any commit lands on the branch after 8e056aa (for example the four #70 exception lines, if #70 lands first), those are new bytes and need their own check.

## 13. Confidence

- Provenance: 0.99. The manifest was reproduced byte for byte; the merge is git's own; the hunks are identical.
- Validation: 0.9. Build, vet, root and testutil tests and the mutants ran on the exact bytes. The full suite rests on CI: green on e760c67, pending on 8e056aa.
- Implementation: 0.95. The delta is a doc sentence, a comment and two subtests, all checked by mutants. The rest of the PR is unchanged since audit 03.

## 14. Effect status

No repair, commit, push, PR edit, GitHub comment or review, and no merge. Red-team not run: the coordinator decided it is not required.

## 15. Report delivery

This file: `reports/Execution-Substrate/service-layout/05-pr68-second-reaudit.md`. Its SHA-256 is given in the thread reply. Evidence: `05-evidence/`, with `SHA256SUMS` inside.

**Final verdict: ACCEPT**
