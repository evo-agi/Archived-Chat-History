# Addendum 05a to the second re-audit of ES PR #68: CI on 8e056aa, and the #72 sync to 10f77ba

Addendum to `05-pr68-second-reaudit.md` (SHA-256 7e7d4a2a…0878), written by the same audit thread, 2026-11-27, about 01:45Z (8:45 PM Eastern, 2026-11-26).

## CI on 8e056aa, the audited head: both green

| Check | Workflow run / job | Head SHA | Result | Time (UTC) |
|---|---|---|---|---|
| build, vet and test | `go` 45916717270 / 140237592743 | 8e056aa | **success** | 00:26:24 to 01:21:02 |
| test on macOS | `go-macos` 45916717236 / 140237592506 | 8e056aa | **success** | 00:26:24 to 01:02:19 |

This closes the one open item of report 05 for 8e056aa. Verdict on 8e056aa stays **ACCEPT**.

## The branch moved after the audit: 10f77ba (sync with trunk_dev fbfd100, #72)

trunk_dev moved from 39e19de to fbfd100 (#72, "Workload identities are never callers", squash, committed 01:18:43Z). The writer then pushed 10f77bafda3074d92727738da7535dd5c0a7c5d5 at 01:22:12Z. The PR head is now 10f77ba, not 8e056aa.

Checks I ran on 10f77ba (provenance only, no new manifest):

- Parents: 8e056aa and fbfd100. It is a merge, with no rebase and no force-push.
- Tree 5620646fecd0338e1c6eab806d8aee3d8035f89d, which equals `git merge-tree --write-tree 8e056aa fbfd100`. So it is git's own clean merge, with no hand edits.
- The PR's net diff is unchanged:
  - `git diff --name-status --no-renames` of 39e19de..8e056aa and of fbfd100..10f77ba are identical (42 paths).
  - Both shortstats read 40 files, +879/−338.
- Only `PLANS.md` has a different blob at 10f77ba than at 8e056aa, and #72 also edited it. With line numbers stripped, at `-U0` and `-U3`, the PR-side and trunk-side hunks are both identical. PLANS.md is now 149,288 bytes, under the 150,000-byte cap.
- **Writer manifest `06-canonical-manifest-10f77ba.json`** (SHA-256 9b0dbfff…10c2; head fbfd100, upstream `origin/trunk_dev`, v2 recipe). It has the same 42 paths as the audited 8e056aa manifest, and only the `PLANS.md` entry differs. All 42 records match the blobs at 10f77ba: SHA-256 and size, and absence for the two deleted files. I did not rerun the recipe itself.
- **Tests already run on this exact tree.** Tree 5620646f is also the tree of my #72 trial merge in report 05 (`05-evidence/trial-merge-pr72.txt`). On it, `go build ./...`, `go vet ./...` and `go test -count=1 . ./internal/testutil` all passed, including the layout guard.
- **Not run here:** the full suite on 10f77ba. #72 changes production Go in `cgs/policy` and `internal/callerauth`/`internal/callerallowlist`, so the full CI run matters for this head. CI on 10f77ba was running when this was written: `go` run 45922189185 (job 140255248149) and `go-macos` run 45922189112 (job 140255247394), both started 01:22Z.

Reading under the ES merge-queue rule (procedures.md, "ES merge queue"): this is a sync-only update. It is git's own clean merge, and the PR's patch is byte-identical to the audited one, so it needs no further auditor round. What the merge gate still needs for 10f77ba: both required checks green on 10f77ba, and the writer's own sync check, which its commit message says it made.

## Effect status

Nothing pushed, posted, commented or merged by this thread.
