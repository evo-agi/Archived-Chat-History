# Independent re-audit of ES PR #68 at 1e3ec7c: one layout for the five services

INDEPENDENT AUDIT REPORT

- Repository: evo-agi/Execution-Substrate
- PR: https://github.com/evo-agi/Execution-Substrate/pull/68 (draft), branch `claude/project-thread-t608v3`
- Base: `origin/trunk_dev` 923e9c3366775664c8a85f19273e3dd4fc04eb22 (still the trunk_dev head at 23:05Z, re-checked)
- Topic commit: 1e3ec7c4f0c468807dd03f91ac2fac766d30cf77 (two commits on the base: 8dec404, the audited first commit, then the repair 1e3ec7c). Remote head re-checked at the start and at the end of this audit, unchanged.
- Tree SHA: db04e47fdf9ef8b6e7d01109be74d958d7d8f036
- Recipe: `governed-execution.audit-patch-manifest.v2`, source SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified before the opening and the closing runs)
- Canonical manifest SHA-256: 269a3a36a89b1c74d09bd8e316b8215f09ca205f23d1aa724c39cf9c2268dce9; textual diff SHA-256 8b745ced147374f967814bddaae3b30991ac15b2d312b0b2071351b595694e74; 42 entries (37 modified, 2 deleted, 3 new; GitHub shows 40 files because the 2 renames count as one file each)
- Auditor: fresh read-only thread "Re-check the service layout PR", started by the coordinator 2026-11-26 23:03Z. It did not write this PR, did not run audit 01, and did not see the writer's or the first auditor's session. It read their delivered reports only.
- Inputs: audit 01 `01-pr68-audit.md` (SHA-256 2d2968f8…ba4b), writer repair report `02-pr68-repair.md` (SHA-256 c9fc1a3c…a7c5), writer manifest `02-canonical-manifest-1e3ec7c.json` (SHA-256 269a3a36…dce9), the PR description.
- Written: 2026-11-26, about 23:40Z (18:40 Eastern).

**Final verdict: BLOCK**, on two Low findings, both introduced by the repair commit and both one-line fixes. The three findings of audit 01 are fixed (A68-1, A68-2, A68-3), the writer's manifest reproduces byte for byte, the rename still changes no behaviour, ES and AGS still link only ARS's and EGS's contract packages, the full suite fails the same 59 entries on base and tip (all environment, none touched by the PR), and both CI jobs are green on 1e3ec7c. What blocks:

- **R68-1 (Low, doc):** the new README sentence "Go code lives only in the five service folders, `cmd/`, `internal/` and `scripts/`" is false. The repository root holds 12 Go test files, and the guard deliberately skips the root.
- **R68-2 (Low, test gap):** the new top-level-directory rule is only shown refusing a nested file. A mutant that stops it refusing a Go file placed directly in a new top-level directory (`pkg/leak.go`) survives every test.

A narrow delta re-audit plus a provenance re-check should be enough after the fix.

One thing the coordinator needs for merge order, not a defect of this PR: draft PR #70 merged with #68 fails the new guard (`TestServiceLayout`), because #70's new `scripts/remote_alpha_user_identity_test.go` imports `ags/api`, `ags/publish`, `es/admission` and `es/api` (O-R5). The other six open PRs merge cleanly with #68 and pass build, vet and the guard.

## 1. Audit posture

- Read-only. No commits, pushes, PR edits, comments or reviews on GitHub. Writes went only to this thread's container (`/opt/reaudit68`, `/home/ci`) and to this report folder.
- No subagents. Inference: the delta is four files and the whole diff is mechanical apart from the guard test, so one reviewer with scripts covers it; the coordinator did not ask for subagents.
- Governing files read: project-context/INDEX.md, procedures.md (briefs and reports, labeling, audits, red-team scope, docs), state.md, repos.md, decisions.md, scheduling.md; operating-protocol/claude-operating-protocol.md and provenance-and-audit-evidence.md.
- Toolchain: Go 1.26.5 (the version `go.mod` names), downloaded as `golang.org/toolchain@v0.0.1-go1.26.5.linux-amd64`.

## 2. Provenance reproduction

Commands (provenance §5.3), in a fresh `git clone https://github.com/evo-agi/Execution-Substrate` under `umask 022`:

```
sha256sum -c   # v2 recipe = c08597e2…a3ca: OK
git fetch origin trunk_dev claude/project-thread-t608v3
test "$(git rev-parse origin/claude/project-thread-t608v3)" = 1e3ec7c4…   # ok
test "$(git rev-parse origin/trunk_dev)" = 923e9c33…                      # ok, base is the trunk_dev head
git merge-base --is-ancestor 923e9c33… 1e3ec7c4…                          # ok
git checkout -f -B claude/project-thread-t608v3 1e3ec7c4…; git clean -fdxq; test -z "$(git status --porcelain)"
test "$(git rev-parse HEAD^{tree})" = db04e47f…                           # ok
git reset --mixed 923e9c33…; git branch --set-upstream-to=origin/trunk_dev
python3 -I v2.py OUT/1.json && python3 -I v2.py OUT/2.json && cmp OUT/1.json OUT/2.json   # identical
cmp OUT/1.json 02-canonical-manifest-1e3ec7c.json                                          # identical
```

- Opening runs: byte-identical to each other **and to the writer's manifest**. manifest_sha256 269a3a36…dce9, textual_diff_sha256 8b745ced…4e74, 42 entries, all mode 0644 (no tolerated mode differences). A copy is in `03-evidence/canonical-manifest-1e3ec7c.json`.
- Closing runs (after all tests, probes, mutants and trial merges, which ran in separate clones and exports): byte-identical to the opening manifest. See section 9.
- This closes O68-2 from audit 01: the writer delivered a manifest and it matches.

## 3. The three findings of audit 01

| Finding | Status | Evidence |
|---|---|---|
| A68-1 stale `egsmodel` field type in `es_execution_admission_model.md:995` | **Fixed** | Line 995 now reads ``trustModel *egscontract.RuntimeTrustPolicy``, which equals `es/admission/service.go:121`. A grep of the whole tip tree outside `.docs/history/` for `egsmodel`, `egs/model`, `arsapi`, `model.RuntimeTrustPolicy` and `api.Artifact*` finds only a refusal-test literal (`service_layout_test.go:355`, intended) and a local variable named `model` (`es/admission/resolved_execution_plan.go:296-300`, unrelated). |
| A68-2 README and `boundaries.md` describe the exception list wrongly | **Fixed**, but the new README sentence next to it is wrong in a different way (R68-1) | README:193 now says the guard lists "some test files, and the ES upgrade script's config check"; this matches `layoutCrossServiceExceptions` (`service_layout_test.go:74-83`: 7 test-file entries plus `scripts/internal/esconfigcheck/main.go`). The `boundaries.md:973` row now says production cross-service imports go only through contract packages "apart from the exceptions it lists by file; tests may also start another service through its `app` and `config` packages", which matches `service_layout_test.go:166-176`. |
| A68-3 12 guard list entries unpinned | **Fixed** | `TestServiceLayoutRefusals` (`:394-479`) compares the three lists with literal copies and then shows every entry refusing what it names. My list mutants (section 5): every entry of `layoutServices`, `layoutRequiredPackages` and `layoutGenericPackageNames` is killed (19 of 19). With the literal-copy comparison switched off, the behaviour loops alone still kill all 19, so the pin does not rest only on the copy. Dropping a service also fails `TestServiceLayout` on the real tree. |

Observations from audit 01: O68-1 (decode-error texts name the new package) is now stated in the PR description, under "One visible text change". O68-2 is closed (section 2). O68-3 (the generic-name rule is a denylist) is unchanged, as the PR says; the probe `ars/pkg/x.go` still passes.

## 4. Whole-diff audit (923e9c3 → 1e3ec7c)

### 4.1 No behaviour change

- The delta 8dec404 → 1e3ec7c touches only `service_layout_test.go`, `README.md`, `boundaries.md` and `es_execution_admission_model.md` (4 files, +106/−7). No production Go file changed since audit 01. I still re-did the whole-diff checks myself rather than inherit them.
- **Moved files:** `ars/api/types.go`@923e9c3 → `ars/contract/types.go`@1e3ec7c and `egs/model/trustmodel.go` → `egs/contract/trustmodel.go` differ only in the package clause (`diff`: one line each).
- **Reverse-rename proof** (audit 01's `revsub.py`, rerun here on 923e9c3..1e3ec7c with Go 1.26.5 gofmt; output in `03-evidence/revsub-output.txt`): 29 of 34 changed Go files are identical to base after reversing the rename and running gofmt on both sides. The other 5 I read by hand: `egs/config/config.go` is the import and two field types, with gofmt realigning the struct tags; `ars_blob_fetch_test.go` drops the `../ars/api/server.go` expected site with a corrected comment; `workstream_c_guardrails_test.go` changes the reviewed-content pin; `internal/testutil/testutil_test.go` adds `service_layout_test.go` to the root's allowed files; `service_layout_test.go` is new.
- The rename proof replaces `contract.` with `model.` in `egs/`. That would hide a real change if an `egs/` file had a local identifier named `model` or `contract`. I grepped base and tip `egs/` Go code: none exists (only strings and comments).
- **Pin:** `sha256sum es/admission/internal/admissionstate/state.go` is e07fa2a0…5a48 at base and b1c96f34…158c1 at tip, exactly the old and new `operationalAdmissionStatePin` (`workstream_c_guardrails_test.go:5771`). `state.go` is in the 29 identical files above.
- **gofmt:** every changed Go file is clean at tip. The tree's only unformatted files are the five the PR names (`ags/sign/signer.go`, `ars/index/index.go`, `es/runtimehelper/main.go`, `es/runtimehelper/privilege_linux.go`, `internal/observability/observability.go`); at base `egs/sign/signer.go` was a sixth, which the PR fixed (whitespace only, covered by the rename proof).
- I did not rerun audit 01's byte-level runtime probe (canonical bytes, digests, a fixed-seed Ed25519 signature). Inference: it is not needed, because the moved files differ only in the package clause and every other production file is identical after the reverse rename; build and vet compile all of it.

### 4.2 Dependency claim: ES and AGS no longer link ARS's server, index or store

`go list -deps ./cmd/<x>`, `CGO_ENABLED=0`, packages of other services, for linux/amd64, linux/arm64, darwin/arm64 and darwin/amd64 (`03-evidence/golist-deps.txt`; `go list` exited 0 with no stderr on every tree and platform checked):

| Program | 923e9c3 (all 4 platforms) | 1e3ec7c (all 4 platforms) |
|---|---|---|
| `cmd/es` | `ars/store`, `ars/index`, `ars/api`, `egs/model` | `ars/contract`, `egs/contract` |
| `cmd/ags` | `ars/store`, `ars/index`, `ars/api` | `ars/contract` |
| `cmd/ars`, `cmd/egs`, `cmd/cgs`, `cmd/es-runtime-support`, `cmd/es-workload-api-mock` | none | none |

David's condition for `ars/contract` holds at the tip.

### 4.3 Docs

- README "Repo Structure": the `internal/` list matches `ls internal/` at tip (callerallowlist, callerauth, contracts, httpx, observability, testtmpdir, testutil). `es/internal/staticarchive` is imported by `es/admission/policy_payload.go:11` and `es/runtimehelper/supervisor.go:23`, as the README says. The exception sentence is correct (A68-2). The new first sentence of line 193 is not (R68-1).
- `boundaries.md` §9 path and §11 row, `shared_kernel.md`, `artifact_publication_storage.md:134`, `es_execution_admission_model.md:995` and `PLANS.md` name the new paths. `PLANS.md:425` still lists `ars/api/`, which still exists (ARS's server), next to the new `ars/contract/`.
- No `.md`, `.yml`, `.sh`, `.json` or `.toml` file outside `.docs/history/` names `egs/model`, `ars/api/types.go` or the old aliases. `.docs/history/` holds no `egs/model` mention either.

### 4.4 The guard (`service_layout_test.go`) after the repair

The repair adds two rules and the list pins:
- `:138-139` Go code in a top-level directory other than the services, `cmd/`, `internal/` and `scripts/` fails.
- `:189-193` a `cmd/` program mapped to a service that is not in `layoutServices` fails.
- `:394-479` the list pins and per-entry refusal subtests (60 subtests in `TestServiceLayoutRefusals` in total).

The two rules are correct on the real tree (it passes) and on every probe (section 5). What I checked beyond the mutants:
- Root-level files have one path segment, so `:138` (`len(segments) >= 2`) never applies to them. That is deliberate: the root's Go files are held by `TestRootKeepsOnlyItsDocsTests` (`internal/testutil/testutil_test.go:58-65`, `rootLayoutProblems` at :126-140). Probe: a root-level production file `zz_probe.go` with no imports passes `TestServiceLayout` and fails `TestRootKeepsOnlyItsDocsTests` ("the repository root keeps only the tests of its docs…"). So the tree is guarded, but the README describes it wrongly (R68-1).
- A Go file directly under `cmd/` (`cmd/zz.go`) is allowed by `:138` because `cmd` is in `layoutOtherTopDirectories` and `:132` needs three segments. With an import of `es/admission` it still fails (`:185`). With no service import it passes. Nothing like it exists today (O-R2).
- The subtest at `:474-479` writes the package-level `layoutCommandService` map and restores it with `defer`. No test in the root package calls `t.Parallel`, so this is safe today (O-R3).

## 5. Guard mutants and probes

Script `03-evidence/guard_mutants2.py.txt` (adapted from audit 01's, with the new rules added and with build failures recorded apart from kills); results `03-evidence/guard-mutants-1e3ec7c.jsonl`. Each mutant ran in a fresh copy of the 1e3ec7c export (no `.git`, so `repositoryFiles` walks the tree), with `go test -run '^(TestServiceLayout|TestServiceLayoutRefusals|TestLayoutGoFileVisible)$' .`. No mutant failed to build.

- **List mutants as committed: 42 killed, 2 survived.**
  - Killed: every generic name (11), every required package (3), every service (5), `internal` and `scripts` in `layoutOtherTopDirectories`, every `layoutCommandService` entry dropped (7), 6 of 7 `layoutCommandService` entries remapped to another service, and every exception dropped (8).
  - Survived: dropping `cmd` from `layoutOtherTopDirectories`. That entry only allows a Go file directly under `cmd/`; dropping it makes the guard stricter, not looser. Remapping `es-workload-api-mock` from `es` to `ars`: `cmd/es-workload-api-mock/main.go` imports no repository package, so the mapping is never exercised (O-R1).
- **The same 22 list mutants with the literal-copy comparison (`:414`) disabled: 21 killed, 1 survived** (`cmd` again). So the per-entry behaviour subtests pin every entry on their own.
- **Logic mutants: 22 of 25 killed.** Survivors:
  - `no min file count`: a sanity check, expected to survive on the real tree (audit 01 had the same).
  - `no literal-copy check`: a check inside the test itself; the row above shows the behaviour loops cover for it.
  - **`top-level rule only for nested files`** (`len(segments) >= 2` → `>= 3` at `:138`): survives every test. With it, `pkg/leak.go` would pass. This is R68-2.
  - Killed include the two new rules removed outright (`no top-level directory rule`, `no command-service-is-a-service check`) and all 21 logic mutants audit 01 ran.
- **Probes: 25 of 25 as expected.** Refused: a production or `//go:build ignore` import of `ars/store` from `es/admission`; a dot import of `ars/api`; an unlisted test import of `ars/store`; shared `internal/` production code importing `ars/contract`; a new top-level `pkg/zzleak/` package with or without a service import; **a Go file directly in a new top-level directory (`pkg/leak.go`)**; a new `tools/gen/main.go`; `cmd/zz.go` importing `es/admission`; a contract importing its own service's `sign`; `cmd/es` importing `ars/contract`; a service package named `types`; root-level production and test files importing `ars/store`; a `scripts/` program importing `es/app`. Allowed, as the rules say: a test importing `ars/app`; a contract importing `internal/httpx`; a `scripts/` program importing `egs/contract`; Go files only under `testdata/` or a dot directory (the go command ignores them too); `ars/pkg/` (not on the denylist); `cmd/zz.go` with no service import; a root-level production file with no imports (the service guard is silent there; the root guard in `internal/testutil` refuses it).

## 6. Tests on the exact bytes

Setup: `git clone --no-local` checkouts of 923e9c3 (tree ce8e199a…) and 1e3ec7c (tree db04e47f…), git mode so the root tests read tracked files, owned by an unprivileged user `ci` (uid 1500, gid 1600). `runuser -u ci -- env -i`, `umask 022`, Go 1.26.5, `GOTOOLCHAIN=local`, `GOPROXY=off`, module cache downloaded beforehand, `-count=1`. Host packages acl, iproute2, locales (en_US.UTF-8), openssh-client and uuid-runtime installed (as in audit 01). No nomad, vault, SPIRE or docker daemon. Base then tip, one after the other, with nothing else running. Both clones had a clean `git status` after their runs. Runner: `03-evidence/run_suite.sh.txt`.

- `go build ./...` and `go vet ./...`: clean on both trees.
- `go test -json -timeout 60m ./...`: base 23:08-23:17Z, tip 23:17-23:26Z.
  - Base: 9,977 pass, 59 fail, 135 skip. Tip: 10,040 pass, 59 fail, 135 skip.
  - **The failing sets are identical**: the same 59 entries by package and test name (`03-evidence/failing-tests-*.txt`). No test changed outcome.
  - The 63 extra passes on the tip are the new tests: `TestServiceLayout`, `TestServiceLayoutRefusals` and its 60 subtests, `TestLayoutGoFileVisible`. The only other name differences are the random-timing subtest names of `TestRedTeamPR12CombinedSIGKILLAtRandomInstants`, `TestRedTeamPR12HeadTwoSIGKILLsThenASurvivor` and `TestRedTeamPR12HeadLiveProcessesRaceForOneClaim` (44 names each side), which passed on both trees.
  - The packages that fail on both trees: `es/admission/internal/reliablesubmit`, `es/app`, `scripts`. 45 of the 59 entries are exactly audit 01's environment-only list (schema-probe builds, no `nomad` binary, Remote Alpha host tools).
  - The other 14 entries are `TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup` and 13 of its subtests in `es/app`. **My harness caused them:** I started the suite under `nohup`, which leaves SIGHUP ignored, and that test refuses a shell that starts with a signal disposition already set. Rerun on both trees with HUP, INT, QUIT, TERM and PIPE reset to default (`03-evidence/sigdfl_exec.py.txt`): `ok` on base and `ok` on tip (`03-evidence/goinstaller-rerun.txt`). The PR changes only an import alias in that test file (covered by the rename proof).
  - Every guard test in `es/admission`, the root package, `internal/...`, and all `ags`, `ars`, `cgs` and `egs` packages passed on the tip.
- Not run here: the Nomad, Vault, SPIRE and docker integration tests (they fail or skip the same way on both trees here; CI runs them) and the macOS job (CI ran it).

## 7. CI and trial merges

- **GitHub CI on 1e3ec7c** (both runs bound to head_sha 1e3ec7c4…, event `pull_request`):
  - "build, vet and test" (workflow `go`, run 45902525863): **success**, 22:06:07Z to 23:02:44Z.
  - "test on macOS" (workflow `go-macos`, run 45902525841): **success**, 22:14:48Z to 22:42:39Z.
  - The `go` run on 8dec404 (45898200572) was cancelled when 1e3ec7c was pushed; it is superseded.
- **Trial merges** with every open ES PR head (`git merge-tree --write-tree 1e3ec7c <head>`; all merge-bases are 923e9c3; heads read from GitHub at about 23:10Z). All seven merge without a textual conflict. On each merged tree I ran `go build ./...`, `go vet ./...` (which compiles every test file) and `go test . ./internal/testutil` (the guard and the root docs tests). Script `03-evidence/trial_merges.sh.txt`, outputs `03-evidence/trial-merge-pr*.txt`.

  | PR | Head | Merged tree | build | vet | root + testutil tests |
  |---|---|---|---|---|---|
  | #63 | 59f1f56 | cfc64afa | ok | ok | ok |
  | #66 | 84da2da | 28f898d4 | ok | ok | ok |
  | #67 (stacked on #63/#66 base branch) | 69d53de | 043f3058 | ok | ok | ok |
  | #69 | 4f4f597 | c665677c | ok | ok | ok |
  | **#70** (draft) | a0e86ea | 23bc5115 | ok | ok | **`TestServiceLayout` fails** |
  | #71 | 26cbd65 | a54af6c3 | ok | ok | ok |
  | #72 (stacked on #71) | a3710c0 | 4f6d45e8 | ok | ok | ok |

  #70 adds `scripts/remote_alpha_user_identity_test.go`, which imports `ags/api`, `ags/publish`, `es/admission` and `es/api`. Under this PR's rules a test outside a service may reach another service only through `contract`, `app` or `config`, so the guard reports four violations. This is not a defect of #68, which is correct against trunk_dev; it is a semantic merge conflict that whichever of the two lands second must resolve (O-R5).
- **PLANS.md size** (cap `plansMaxBytes = 150000`, `plans_docs_contract_test.go:49`): this PR adds 24 bytes (145,850 → 145,874). #70 plus #71 already reach 150,155 without #68 and 150,179 with it, so that pair needs #69 (which shrinks PLANS.md to about 127 KB) or an edit first, whatever #68 does (O-R4).

## 8. Findings

### R68-1 (Low, test/doc gap: inaccurate README rule). Patch defect, introduced by the repair.

- Paths: `README.md:193` (first sentence) and the guard's own comment, `service_layout_test.go:27-28`.
- Evidence: both say Go code lives only in the five service folders, `cmd/`, `internal/` and `scripts/`. The repository root holds 12 Go files at 1e3ec7c: the 8 `*_docs_contract_test.go` files plus `artifact_hygiene_test.go`, `docs_contract_test.go`, `service_layout_test.go` and `testtmpdir_main_test.go`. The guard skips root-level files on purpose (`:138` needs two path segments). The root's rule is held by `TestRootKeepsOnlyItsDocsTests` (`internal/testutil/testutil_test.go:58-65`), which the probe in 4.4 confirms. The PR description says it correctly ("a top-level directory other than…").
- Impact: the newcomer-facing README states a rule that the first `ls` of the repository contradicts, and points to the wrong guard for the root. Procedures ("Docs and READMEs") treat inaccurate docs as a finding.
- Correction, for example: README "Go code lives only in the five service folders, `cmd/`, `internal/` and `scripts/`, plus the repository-wide tests at the root (`internal/testutil` checks which ones)." Change the comment at `service_layout_test.go:27-28` to match.

### R68-2 (Low, test gap: the new top-level rule is pinned for one shape only). Patch defect, introduced by the repair.

- Path: `service_layout_test.go:138` (rule) and `:469-473` (its only refusal subtest).
- Evidence: the subtest adds `pkg/thing/thing.go` (three segments). The mutant `len(segments) >= 2` → `len(segments) >= 3` survives every test (section 5). Under that mutant, a Go file placed directly in a new top-level directory (`pkg/leak.go`) passes the guard. The committed code refuses it (probe), so the code is right; no test holds it there.
- Impact: same class as A68-3. A later edit can loosen the rule without failing any test, and the repair's commit message says every rule is shown failing.
- Correction: add `pkg/leak.go` (two segments) to the existing subtest, or a second subtest that expects "pkg/leak.go: top-level directory pkg/ holds Go code". That kills the mutant.

### O-R1 (observation: one program's mapping is never exercised). No correction required.

- `layoutCommandService["es-workload-api-mock"] = "es"` (`:60`) can be changed to any other listed service without failing a test, because `cmd/es-workload-api-mock/main.go` imports no repository package. It is equivalent on today's tree. Pinning the map against a literal copy, as the repair did for the other three lists, would close it if the writer wants to; it is not needed for this PR.
- Dropping `cmd` from `layoutOtherTopDirectories` also survives, but that makes the guard stricter. The commit message's "Dropping any entry from any list now fails the test" is true for the three lists it names, not for this one.

### O-R2 (observation: a Go file directly under `cmd/`). No correction required.

- `cmd/zz.go` passes the guard when it imports no service package (probe). The go command would build it as a package `cmd`. Nothing like it exists, and it cannot reach another service except through a contract package.

### O-R3 (observation: the test writes a package-level map). No correction required.

- `TestServiceLayoutRefusals` sets `layoutCommandService["es-workload-api-mock"] = "zz"` and restores it with `defer` (`:474-479`). Safe while nothing in the root package runs in parallel. Passing the map to `serviceLayoutViolations` would remove the shared state; optional.

### O-R4 (observation: PLANS.md headroom). No correction required in this PR.

- See section 7. This PR's share is 24 bytes. The merge order of #69, #70 and #71 decides whether the cap test fails; that is the coordinator's call.

### O-R5 (observation, integration: #70 breaks the new guard once both land). No correction required in this PR.

- Evidence: section 7. The trial merge of #70's head a0e86ea into 1e3ec7c builds and vets, but `TestServiceLayout` fails on `scripts/remote_alpha_user_identity_test.go`'s imports of `ags/api`, `ags/publish`, `es/admission` and `es/api`.
- Impact: if #68 lands first, #70 must either reach those services through allowed packages or add four entries, each with its reason, to `layoutCrossServiceExceptions`. If #70 lands first, #68 needs the same edit before it merges, and that edit changes #68's bytes (a fresh audit of the delta). Which way is the coordinator's call. Inference: adding listed exceptions is the smaller change, and the list exists for exactly this, but whether a script test should reach into `es/admission` and `ags/publish` at all is a question for #70's writer.

### Pre-existing (not patch defects)

- The five unformatted Go files named in 4.1, unchanged since audit 01.

No contract or authority drift, no security finding. The change narrows what ES and AGS link.

## 9. Closing provenance

- Recipe hash re-verified at 23:32Z, both the local copy and the project-files original (c08597e2…a3ca). The provenance clone was not used for anything else: HEAD 923e9c3, branch `claude/project-thread-t608v3`, upstream re-pinned to `origin/trunk_dev`. Two closing runs to a fresh `0700` directory: byte-identical to each other and to the opening manifest (manifest 269a3a36…dce9, textual diff 8b745ced…4e74, 42 entries).
- The remote head of `claude/project-thread-t608v3` was re-fetched at 23:32Z: still 1e3ec7c. `origin/trunk_dev` still 923e9c3.

## 10. Red-team need

The coordinator asked whether the red-team scope in procedures.md requires one.

- The rule (project instructions, "Roles", and procedures.md "Red-team scope and method"): reserved for "major PRs, meaning non-trivial PRs into `trunk_dev` or `main`, first and foremost in ES"; everything else gets the correctness audit only, "unless the coordinator judges a change security-critical and says why". decisions.md #5 records that the scope was set "to conserve Fable usage".
- "Non-trivial" is not defined. By size (40 files, product code in all five services) the PR can read as non-trivial. By effect it is trivial: nothing reachable at runtime changes. The signed bytes, digests, wire JSON and persisted state are unchanged (4.1). The only visible difference is the package name inside Go's JSON decode-error text on malformed startup input (O68-1). The linked attack surface of ES and AGS shrinks (4.2).
- My reading (inference, not a rule): **the scope does not require a red-team for this PR**, because a red-team's job is to break runtime behaviour, and none changed. The coordinator decides, since the word is undefined. If one runs anyway, the only surfaces worth its time are the guard's file selection (build tags, dot imports, testdata, root files, new top-level directories, all probed in section 5) and confirming that EGS's canonical bytes verify across the rename (audit 01's byte probe already did this at 8dec404, and no production byte changed since).

## 11. Sensitive-material handling

None was read or copied. No secrets, keys, env files or databases were touched. The tests used only the repository's own fixtures.

## 12. Remaining uncertainty

- The daemon-backed integration tests (Nomad, Vault, SPIRE, docker) did not run here. They behave the same on both trees here, and CI's Linux job, which ran them, is green.
- I did not compare compiled binaries. Equivalence rests on the rename proof and on unchanged moved files.
- "Non-trivial" in the red-team rule is undefined (section 10).

## 13. Confidence

- Provenance: 0.99. The writer's manifest was reproduced byte for byte from the pushed commit, opening and closing; commit and tree SHAs match.
- Validation: 0.96. Full suite on the exact bytes of both trees as an unprivileged user, identical failing sets, and the 14 harness-caused entries rerun clean on both. Both CI jobs are green on 1e3ec7c. Daemon-backed tests are covered only by CI.
- Implementation: 0.97 for "no behaviour change" and the dependency claim. 0.93 for the guard as a complete lock, because of R68-2.

## 14. Effect status

No repair, commit, push, PR edit, GitHub comment, review or merge was performed.

## 15. Report delivery

`/mnt/project-files/reports/Execution-Substrate/service-layout/03-pr68-reaudit.md`; its SHA-256 is given in the thread reply. Evidence: `03-evidence/` beside it, with `SHA256SUMS`.

**Final verdict: BLOCK** (R68-1 and R68-2, both Low, both from the repair commit). After the fix, a narrow delta re-audit (README line 193, the test comment, the subtest) plus a provenance re-check should suffice. The red-team scope does not require a red-team here, in my reading; the coordinator decides. Merge order with #70 needs a decision either way (O-R5).
