Evidence for 01-pr68-audit.md (ES PR #68 at 8dec404, base 923e9c3).

canonical-manifest-8dec404.json   v2 manifest (recipe c08597e2...a3ca); opening and closing runs byte-identical.
revsub.py.txt                     reverse-renames each changed .go file at the tip and compares gofmt output with the base file.
probe-output-*.txt                output of a throwaway test package (zzauditprobe, added to git-archive exports of
                                  each tree, then deleted) that prints CanonicalBytes, PayloadDigest, an Ed25519
                                  signature from egs/sign with a fixed seed, json.Marshal of every ARS wire type, and
                                  three JSON decode-error texts. Only the decode-error lines differ.
golist-deps.txt                   go list -deps ./cmd/<x> filtered to other services' packages, 4 platforms, both trees.
failing-tests-*.txt               go test -json ./... as an unprivileged user (uid 1500), env -i, GOPROXY=off; parsed by fails.py.
guard_mutants.py.txt / .jsonl     57 mutants (list entries and logic) and 16 bypass/allowance probes of service_layout_test.go.
                                  One logic mutant ("no contract-imports-service rule") did not compile in the script run;
                                  rerun by hand as `if _ = contract; false {`: killed by TestServiceLayoutRefusals
                                  (2 subtests).
trial-merge-pr*.txt               git merge-tree of PR #63/#66/#69 heads into 8dec404: go build, go vet ./..., go test . ./internal/testutil.
