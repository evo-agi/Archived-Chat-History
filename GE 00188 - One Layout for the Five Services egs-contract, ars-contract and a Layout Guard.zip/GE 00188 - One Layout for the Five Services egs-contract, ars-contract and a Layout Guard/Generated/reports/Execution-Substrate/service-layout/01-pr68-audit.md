# Independent audit of ES PR #68: one layout for the five services

INDEPENDENT AUDIT REPORT

- Repository: evo-agi/Execution-Substrate
- PR: https://github.com/evo-agi/Execution-Substrate/pull/68 (draft), branch `claude/project-thread-t608v3`
- Base: `origin/trunk_dev` 923e9c3366775664c8a85f19273e3dd4fc04eb22
- Topic commit: 8dec404697effeec8a3db47a12c8a6512616b5f4 (one commit on the base; remote head re-checked at 22:00Z, unchanged)
- Tree SHA: 29468e6106b066b0970136693b85c2a1196a6b1d
- Recipe: `governed-execution.audit-patch-manifest.v2`, source SHA-256 c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified before the opening and the closing run)
- Canonical manifest SHA-256: 5b3f64122c30f2c0267d5ee766392e6f78a4eccb37c96e6a744b3c18bf76a37c; textual diff SHA-256 eb62204013e6dc58d61f167db03440a4ef1a53702e76e1d9b9011b53ba156166; 41 manifest entries (39 GitHub files: 2 renames count as delete + add)
- Auditor: fresh read-only thread "Audit the ES service layout PR", started by the coordinator 2026-11-26 21:27Z. It did not write or see the writer's session.
- Written: 2026-11-26, about 22:05Z (17:05 Eastern).

**Final verdict: BLOCK.** The code change itself is correct: every moved type and every signed byte is unchanged, and ES and AGS no longer link ARS's server, index or store on any platform checked. Three Low findings need a fix in this PR (David's rule: Low nits are fixed in-PR): one governing doc line still names the old identifier (A68-1), the README and `boundaries.md` describe the guard's exception list slightly wrongly (A68-2), and 12 list entries in the new guard are not pinned by any test (A68-3). All three are small. A narrow re-audit of the delta should be enough.

## 1. Audit posture

- Read-only. No commits, pushes, PR edits, comments or reviews. The only writes were in this thread's container (`/opt/audit68`, `/home/ci`) and this report folder.
- No subagents were used. Inference: the PR is mechanical enough that one reviewer with scripts covers it; the coordinator did not ask for subagents.
- Governing files read: project-context/INDEX.md, procedures.md, state.md; operating-protocol/claude-operating-protocol.md and provenance-and-audit-evidence.md; the design write-up `reports/design/es-service-layout.md` (SHA-256 f1c5d948…0464); the PR description.
- Implementation report: none was delivered as a file. The PR description and the design write-up are the only writer reports, and neither carries a canonical manifest (see O68-2).

## 2. Provenance reproduction

Commands (provenance §5.3), run under `umask 022` in the container's clone:

```
test "$(git rev-parse origin/claude/project-thread-t608v3)" = 8dec404…   # ok
git merge-base --is-ancestor 923e9c3… 8dec404…                        # ok
git checkout -f -B claude/project-thread-t608v3 8dec404…; git clean -fdx; test -z "$(git status --porcelain)"
git reset --mixed 923e9c3…; git branch --set-upstream-to=origin/trunk_dev
python3 -I v2.py OUT/1.json && python3 -I v2.py OUT/2.json && cmp OUT/1.json OUT/2.json   # identical
```

- Opening runs: byte-identical, SHA-256 5b3f6412…a37c. The full manifest is in `01-evidence/canonical-manifest-8dec404.json`.
- Closing runs (after all tests, probes and mutants, which ran in separate copies): byte-identical to the opening manifest.
- No writer manifest exists to compare against, so the usual "equals the reported manifest" step could not be done. The target is bound by the commit SHA, the tree SHA and this manifest (O68-2).
- Mode bits: all 0644, no tolerated differences.

## 3. What was checked, and results

### 3.1 No behaviour change: wire types, JSON, signed bytes and digests

1. **The moved files differ only in the package clause.** `diff` of `ars/api/types.go`@923e9c3 against `ars/contract/types.go`@8dec404 shows only `package api` → `package contract`. `egs/model/trustmodel.go` → `egs/contract/trustmodel.go` shows only `package model` → `package contract`. So every struct, field, JSON tag, constant, `CanonicalBytes`, `PayloadDigest`, `Validate` and `Normalized` is byte-identical.
2. **Every other changed Go file is a pure rename.** `01-evidence/revsub.py.txt` takes each changed `.go` file at the tip, reverses the rename (`egs/contract`→`egs/model`, `egscontract`→`egsmodel`, `ars/contract`→`ars/api`, `arscontract`→`arsapi`, `contract.`→`model.` in `egs/`, and `contract.`→nothing in `ars/api/server.go` with the new import line dropped), runs gofmt on both sides and compares them. 29 of 34 files are identical. Of the other 5: `egs/config/config.go` differs only because the script also rewrote the comment word "contract." at line 127 (checked by hand: a pure rename); `service_layout_test.go` is new; the remaining three are the deliberate test edits in 3.4. This also covers the gofmt-only reindent of `egs/sign/signer.go`.
3. **Runtime probe on both trees.** A throwaway test package added to `git archive` exports of each tree (then deleted) printed `CanonicalBytes`, `PayloadDigest` and `json.Marshal` for three trust policies, an Ed25519 signature made by `egs/sign.NewEd25519Signer` with a fixed seed (Ed25519 is deterministic), `PublicationMetadata`, and `json.Marshal` of every ARS wire type, populated and zero. Base and tip outputs are identical line for line, apart from the decode-error texts in O68-1. Evidence: `01-evidence/probe-output-*.txt`.
4. No production code in the touched packages uses `%T`, `reflect` type names, or `encoding/gob` (grep of `ars/`, `egs/`, `es/admission/*.go`, `admissionstate/`, `ags/publish/`).

### 3.2 `go list -deps`: ES and AGS no longer link ARS's server, index or store

`go list -deps ./cmd/<x>` filtered to other services' packages, `CGO_ENABLED=0`, for linux/amd64, linux/arm64, darwin/arm64 and darwin/amd64 (`01-evidence/golist-deps.txt`):

| Program | 923e9c3 (all 4 platforms) | 8dec404 (all 4 platforms) |
|---|---|---|
| `cmd/es` | `ars/store`, `ars/index`, `ars/api`, `egs/model` | `ars/contract`, `egs/contract` |
| `cmd/ags` | `ars/store`, `ars/index`, `ars/api` | `ars/contract` |
| `cmd/ars`, `cmd/egs`, `cmd/cgs`, `cmd/es-runtime-support`, `cmd/es-workload-api-mock` | none | none |

This matches the PR's table. David's condition for `ars/contract` holds. No file outside `ars/` imports `ars/api`, `ars/index` or `ars/store` in production code at the tip. The remaining test-file reach-ins are exactly the guard's listed exceptions.

### 3.3 The layout guard (`service_layout_test.go`)

What it reads: every path from `repositoryFiles` (`git ls-files` when `.git` exists, otherwise a walk of the tree, `artifact_hygiene_test.go:36-86`), keeping `.go` files outside `testdata` and outside any `.`- or `_`-prefixed segment, which is what the go command builds. It parses imports only, so build constraints are ignored (stricter than the compiler, which is fine). There are no nested `go.mod` files and no `vendor/` directory at the tip.

Mutants and probes (`01-evidence/guard_mutants.py.txt`, results in `guard-mutants.jsonl`), each run in a fresh copy of the tip export:

- **Logic mutants: 20 of 21 killed** (one of them rerun by hand, see the evidence README). The survivor is `no min file count`, a sanity check that is expected to survive on the real tree.
- **Command map: 7 of 7 entries killed. Exceptions: 8 of 8 killed.** Each listed exception is in use, and removing any one fails `TestServiceLayout`.
- **Survivors among list entries: 12** (A68-3): generic names `common`, `helper`, `helpers`, `lib`, `misc`, `models`, `shared`, `types`, `utils` (only `model` and `util` are pinned); required packages `api` and `app` (only `config` is pinned); service `ags` (the other four are pinned).
- **Probes: 16 of 16 as expected.** Refused: a production import of `ars/store` from `es/admission`, the same under `//go:build ignore`, a dot import of `ars/api`, an unlisted test import of `ars/store`, shared `internal/` production code importing `ars/contract`, a new top-level `pkg/` package importing `ars/store`, a contract importing its own service's `sign`, `cmd/es` importing `ars/contract`, a root-level production file importing `ars/store`, and a service package named `types`. Allowed, as the rules say: a test importing `ars/app`, a contract importing shared `internal/httpx`, a `scripts/` program importing `egs/contract`, and a `testdata` file (the go command ignores it too). Not refused, because they are not on the denylist: `ars/pkg/` and `ars/core/` (O68-3).
- **On unmodified trunk_dev:** with only `service_layout_test.go` copied into a 923e9c3 export, `TestServiceLayout` reports `egs/model` as a generic name and 24 `ars/api`/`egs/model` imports from other services. That confirms the PR's claim that the guard flags the old layout.

Too loose or too strict? Within its stated scope it is neither, apart from A68-3. Indirect leaks are closed: a contract package may import no service package, and shared `internal/` code may import none. So everything a program can link from another service is a contract package. The only things stricter than the README wording are listed in O68-3, and nothing in the tree hits them.

### 3.4 The reviewed-content pin and the other deliberate test edits

- `operationalAdmissionStatePin` (`es/admission/workstream_c_guardrails_test.go:5771`) changes from `sha256:e07fa2a0…5a48` to `sha256:b1c96f34…158c1`. `sha256sum` of `state.go`: 923e9c3 = e07fa2a0…5a48, 8dec404 = b1c96f34…158c1, so both pins are exact. The `state.go` change is a pure rename (3.1 item 2: identical after reverse rename and gofmt; the word diff shows only `egsmodel`→`egscontract` in 8 lines). The pin update is justified.
- No other pin in the repo names a changed file: I grepped the base tree for each changed file's SHA-256 and git blob SHA, and found only this one.
- `es/admission/ars_blob_fetch_test.go:999-1004`: the expected site `../ars/api/server.go` (`/v1/blobs/` route literal) is removed. That is correct because ES no longer links `ars/api` (3.2). If someone re-adds the import, the literal comes back and the guard fails, so this change keeps the guard honest.
- `internal/testutil/testutil_test.go`: `service_layout_test.go` is added to `rootTestFiles` and to the self-test's good and bad lists. This is consistent, and `TestRootKeepsOnlyItsDocsTests` passes on the committed tree.

### 3.5 Docs and imports

- No `egs/model`, `egsmodel`, `arsapi`, or `ars/api` type reference remains in Go code outside `ars/` (only `ars/app` and `ars/api`'s own test import `ars/api`).
- One governing doc line is stale (A68-1).
- README "Repo Structure": the list of top-level `internal/` packages matches `ls internal/` at the tip (callerallowlist, callerauth, contracts, httpx, observability, testtmpdir, testutil). The sentence about exceptions is inaccurate (A68-2).
- `boundaries.md` §9 path, the new §11 row, the `shared_kernel.md` sentence, `artifact_publication_storage.md` and `PLANS.md` name the new paths correctly. The §11 row's last sentence has the same imprecision as A68-2.
- `.github/ci/` lists name no moved package. The other repos (Coordinator, IM, MA, Bridge-Core, Archived-Runbooks at their trunk_dev heads) contain no reference to `egs/model`, `ars/api` or `execution-substrate/(ars|egs)/`.
- gofmt: every changed `.go` file is clean. The five files the PR names (`ags/sign/signer.go`, `ars/index/index.go`, `es/runtimehelper/main.go`, `es/runtimehelper/privilege_linux.go`, `internal/observability/observability.go`) are the only unformatted files in the tree. This is pre-existing and outside the PR's scope.

### 3.6 Tests rerun on the exact bytes

Setup: clean `git clone --no-local` checkouts of 923e9c3 and 8dec404 (git mode, so the root tests list tracked files), owned by an unprivileged user `ci` (uid 1500, gid 1600). Go 1.26.5. `runuser -u ci -- env -i`, `umask 022`, `GOPROXY=off`, a full module cache, HUP/INT/QUIT/TERM/PIPE reset to default. Host packages acl, iproute2, locales (en_US.UTF-8), openssh-client and uuid-runtime were installed. No nomad, vault, SPIRE or docker daemon. Base and tip ran one after the other, with nothing else running on the machine.

- `go build ./...` and `go vet ./...`: clean on both trees.
- `go test -count=1 -json -timeout 60m ./...`: 923e9c3 ran 21:38-21:46Z, 8dec404 ran 21:46-21:56Z.
  - Base: 9,991 pass, 45 fail, 135 skip. Tip: 10,011 pass, 45 fail, 135 skip.
  - **The failing sets are identical** (45 entries, by package and test name). No test changed outcome.
  - The 20 extra passes on the tip are the new tests: `TestServiceLayout`, `TestServiceLayoutRefusals` with 17 subtests, and `TestLayoutGoFileVisible`. The other name differences are the random-timing subtest names of the `TestRedTeamPR12…` rounds, which passed on both trees.
  - Failing on both (environment only: no nomad, schema-probe builds, Remote Alpha host tools):
    - `es/admission/internal/reliablesubmit`: `TestOperationalHandoffSchema4BinaryRefusesSchema5`, `TestSQLiteV3OldBinaryRefusesWithoutMutation`, `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation`.
    - `es/app`: `TestLinuxSetupBootstrapFinishesWithItsSavedSecret`, `TestNomadACLToolRetriesABootstrapThatNeverTookEffect`.
    - `scripts`: `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`, `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`, `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`, `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`, `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`, `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`, `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`, `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`, plus 31 of their subtests. The full list is in `01-evidence/failing-tests-*.txt`.
  - Every guard test in `es/admission`, including all reliable-submit guardrails, the root package, `internal/...`, and all `ags`, `ars`, `cgs` and `egs` packages passed on the tip.
- **Trial merges with the other open PRs** (`git merge-tree --write-tree` of each head into 8dec404, all clean): #63 59f1f56, #66 84da2da, #69 a0c844e. On each merged tree, `go build ./...`, `go vet ./...` (which compiles every test file, including the `es/app` files #66 touches) and `go test . ./internal/testutil` (guard plus root docs tests) all passed with 0 failures. #67 is stacked on another base and was not trial-merged.
- **GitHub CI on 8dec404:** "test on macOS" completed successfully at 21:57:56Z. "build, vet and test" was still running at 22:00Z, so it is not judged here.
- Not run here: the Nomad/Vault/SPIRE integration tests (no daemons in this container) and the macOS job (CI covers it, and it passed).

## 4. Findings

### A68-1 (Low, test/doc gap: stale governing doc). Patch defect.

- Path: `.docs/execution_lifecycle/es_execution_admission_model.md:995` (at 8dec404).
- Evidence: the lock table row for `es/admission:Service.mu` still reads ``trustModel *egsmodel.RuntimeTrustPolicy``. The field is now `trustModel *egscontract.RuntimeTrustPolicy` (`es/admission/service.go:121`). At 923e9c3 the doc matched the code, so this PR made the line stale. No test pins this row.
- Impact: a governing doc names an identifier that no longer exists. Procedures ("Docs and READMEs") treat stale docs as a finding.
- Correction: change it to ``trustModel *egscontract.RuntimeTrustPolicy``.

### A68-2 (Low, test/doc gap: inaccurate description of the guard). Patch defect.

- Paths: `README.md:193`; `.docs/system_overview/boundaries.md:973` (last sentence of the new row).
- Evidence: README says `service_layout_test.go` "lists by file the few test imports that go further". But `layoutCrossServiceExceptions` also lists a production import, `{"scripts/internal/esconfigcheck/main.go", "es/config"}` (`service_layout_test.go:77`). The `boundaries.md` row says the guard "allows cross-service imports only through these packages". In fact, tests may also use `app/` and `config/`, and the listed exceptions are allowed too.
- Impact: a reader of the top-level README gets a slightly wrong picture of what is allowed.
- Correction, for example: README "…and lists by file the few imports that go further: some test files, and the ES upgrade script's config check (`scripts/internal/esconfigcheck`)". `boundaries.md`: "…allows production cross-service imports only through these packages, apart from the exceptions it lists by file".

### A68-3 (Low, test gap: unpinned guard list entries). Patch defect.

- Path: `service_layout_test.go:33, 36, 40-44`; the refusal test is at lines 255-393.
- Evidence: 12 list mutants survive every test (`01-evidence/guard-mutants.jsonl`):
  - dropping any of the generic names `common`, `helper`, `helpers`, `lib`, `misc`, `models`, `shared`, `types` or `utils`;
  - dropping `api` or `app` from `layoutRequiredPackages`;
  - dropping `ags` from `layoutServices`.

  The last one matters most. With `ags` gone from the list, an import of any `ags/...` package from another service is skipped by the guard (`service_layout_test.go:143`), and AGS is no longer held to the required-package or generic-name rules. For ES production code, the older `TestWorkstreamAESBoundaryImportsExcludeARSSupportAndAGSPublicationPackages` (`es/admission/workstream_a_guardrails_test.go:754`) still blocks `ags/`. ARS, EGS and CGS have no such backstop.
- Impact: a later edit can weaken the guard silently. The README states these rules, and the project asks for machine-enforced rules.
- Correction: in `TestServiceLayoutRefusals`, loop over every entry of each list. For each generic name, add a file under a directory with that name and expect the generic-name violation. For each required package, delete it from one service and expect "has no <pkg>/ package". For each service, have another service import `<svc>/store` (or any non-contract package) and expect the cross-service violation. That kills all 12.

### O68-1 (observation: diagnostic text changes). Not a defect; no correction required.

- Go's `json.UnmarshalTypeError` message includes the package-qualified type name, so decode errors for fields of the moved types now read `contract.SignerPolicy` where they read `model.SignerPolicy`, and `contract.ArtifactBlobRef` where they read `api.ArtifactBlobRef`. The probe output shows all three cases.
- Where these texts can surface: EGS config load (`egs/config/config.go:64`, `decode config: %w`) and ES startup trust load (`es/admission/service.go:355` → `Service.Initialize` → `es/app/app.go:73`). Both are operator-facing startup errors on malformed input. ARS answers decode failures with fixed messages (`ars/api/server.go:441, 718, 744`). ES's periodic operational confirmation discards the error (`es/admission/reliable_submit_operational_admission.go:320-323`). ES's ARS discovery decode returns a fixed message (`es/admission/service.go:538-543`).
- Nothing signed, digested, persisted, or sent over the wire changes. The PR's "no behaviour change" is accurate for those. It could say "error texts on malformed JSON name the new package" to be exact.

### O68-2 (observation, process: no writer manifest). No code change required.

- The full provenance gate expects the implementation report to carry the canonical manifest so the audit can compare bytes (provenance §5.2 step 8, §5.3 step 3). No such report or manifest was delivered. This audit bound the target by commit 8dec404, tree 29468e61… and its own reproduced manifest 5b3f6412…a37c. The merge gate can use that identity. Recommendation: the repair round's writer report should carry its manifest as usual.

### O68-3 (observation: guard scope limits). No correction required.

- The generic-name rule is a denylist, so names not on it pass (`ars/pkg/`, `ars/core/` probed). That is within the PR's stated scope ("`model`, `util`, `types`, …").
- The guard is stricter than the README sentence in two places. A `cmd/` program may not import another service's `contract` package (the PR description does state this rule). A test file under `cmd/` may not start another service through `app/` or `config/`. Neither case exists today.
- `ars/contract` holds the whole former `ars/api/types.go`, including health and error response types that only ARS uses. These are ARS wire shapes, so this is fine.

### Pre-existing (not patch defects)

- Five files are not gofmt-clean (3.5). The PR names them and leaves them out of scope.

No contract or authority drift and no security finding. The change narrows what ES and AGS link, which reduces their attack surface rather than widening it.

## 5. Red-team need

Inference, not observed: a red-team has little to attack here beyond what the 16 guard probes and the byte probe already cover, because nothing reachable at runtime changes. The project rule reserves red-teams for non-trivial PRs into `trunk_dev`, and whether this PR counts is the coordinator's call. If one runs, the guard's file selection and the 12 unpinned entries (A68-3) are the only surfaces worth its time.

## 6. Sensitive-material handling

None was read or copied. The probe used a synthetic Ed25519 seed (`sha256("audit-probe-seed")`) and printed only synthetic policies.

## 7. Remaining uncertainty

- The Linux CI job on 8dec404 had not finished at 22:00Z.
- The integration tests that need Nomad, Vault, SPIRE or docker were not run here. They failed or skipped identically on both trees, and CI runs them.
- I did not compare compiled binaries. Equivalence rests on the rename proof (3.1) and the runtime probe.

## 8. Confidence

- Provenance: 0.99. The commit and tree SHAs bind the bytes, and the manifest was reproduced twice at opening and twice at closing. There was no writer manifest to compare.
- Validation: 0.95. The full suite ran on the exact bytes of both trees as an unprivileged user, with identical failing sets. macOS CI is green. Linux CI and the daemon-backed integration tests are not covered here.
- Implementation: 0.95 for "no behaviour change" and the dependency claim. 0.85 for the guard as a complete lock, because of A68-3.

## 9. Effect status

No repair, commit, push, PR edit, comment, review or merge was performed.

## 10. Report delivery

`/mnt/project-files/reports/Execution-Substrate/service-layout/01-pr68-audit.md`. Its SHA-256 is given in the thread reply. Evidence: `01-evidence/` beside it.

**Final verdict: BLOCK** (A68-1, A68-2, A68-3, all Low. After the fixes, a narrow delta re-audit plus a provenance re-check should suffice).
