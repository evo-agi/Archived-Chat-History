# ES PR #68 repair after audit 01: writer report

Thread report from the writer thread "Make ES service layouts consistent". Written 2026-11-26, about 22:35Z.

- Repository: evo-agi/Execution-Substrate. PR #68 (draft), branch `claude/project-thread-t608v3`.
- Base: `origin/trunk_dev` 923e9c3366775664c8a85f19273e3dd4fc04eb22.
- Audited head: 8dec404697effeec8a3db47a12c8a6512616b5f4 (audit `01-pr68-audit.md`, BLOCK on A68-1, A68-2, A68-3, all Low).
- New head: **1e3ec7c4f0c468807dd03f91ac2fac766d30cf77**, tree db04e47fdf9ef8b6e7d01109be74d958d7d8f036. It is one commit on top of 8dec404. No rebase, no force-push.
- Canonical manifest (recipe `governed-execution.audit-patch-manifest.v2`, SHA-256 c08597e2…a3ca verified before the run): `02-canonical-manifest-1e3ec7c.json` beside this file.
  - manifest_sha256 269a3a36a89b1c74d09bd8e316b8215f09ca205f23d1aa724c39cf9c2268dce9
  - textual_diff_sha256 8b745ced147374f967814bddaae3b30991ac15b2d312b0b2071351b595694e74
  - 42 entries. The audit counted 41 at 8dec404; the extra entry is `es_execution_admission_model.md`.
  - Produced in a fresh clone by the audit's own procedure (checkout of the head, `git clean -fdx`, `git reset --mixed` to the base, upstream `origin/trunk_dev`, umask 022). Two runs were byte-identical.

## Delta 8dec404 → 1e3ec7c

Four files, 106 insertions, 7 deletions.

| Finding | Fix |
|---|---|
| A68-1 | `.docs/execution_lifecycle/es_execution_admission_model.md:995`: the field is now named `trustModel *egscontract.RuntimeTrustPolicy`. A grep of all `.md` files outside `.docs/history/` for `egsmodel`, `arsapi`, `model.RuntimeTrustPolicy` and `api.Artifact*` now finds nothing. |
| A68-2 | `README.md`: the guard "lists by file the few imports that go further: some test files, and the ES upgrade script's config check (`scripts/internal/esconfigcheck`)". `boundaries.md` §11 row: the guard "allows production cross-service imports only through these packages, apart from the exceptions it lists by file; tests may also start another service through its `app` and `config` packages". |
| A68-3 | `TestServiceLayoutRefusals` now compares `layoutServices`, `layoutRequiredPackages` and the keys of `layoutGenericPackageNames` with literal copies in the test, then loops over every entry. Each service is shown refused when another service's production code or test reaches its `store`, when it has a generic package name, and when it is missing each required package. Each generic name is shown refused. |

Two rule additions came out of A68-3:
- **Go code only in the services, `cmd/`, `internal/` and `scripts/`.** A Go file in any other top-level directory now fails, for example `pkg/`. Before this, dropping a service from `layoutServices` silently exempted it. Now the real tree fails `TestServiceLayout` too, independent of the copy in the test. README states the rule.
- **Every `cmd/` program maps to a listed service.** A value in `layoutCommandService` outside `layoutServices` fails.

## Commands and results (container, Go 1.26.5, running as root)

- `go vet . ./internal/testutil`: clean. gofmt: `service_layout_test.go` clean.
- `go test -count=1 . ./internal/testutil`: ok. `TestServiceLayoutRefusals` now has 60 subtests, all passing.
- List-removal mutants: each of the 11 generic names, 5 services and 3 required packages, plus `scripts` from the top-level set, was dropped one at a time from the list in a throwaway copy of the tree. Then `go test -run TestServiceLayout .` was run. Result: **20 of 20 killed.**
- Not rerun: the full suite. Only `service_layout_test.go` and three Markdown lines changed since the full-suite comparison at 8dec404. That comparison, and the auditor's own run, found the same failures on base and tip, all environment only. The root docs tests that read README and `boundaries.md` are in the root package, which was rerun.
- GitHub CI on 1e3ec7c: reported in the thread once it finishes.

## Observations from the audit

- O68-1 (decode error texts name the new package): the PR description now says so.
- O68-2 (no writer manifest): this report carries one.
- O68-3: no change. The generic-name list remains a denylist, as the PR states.

## Assumptions and guesses

- None about behaviour. The delta touches no production code.

## Authority or security widening

None. The guard got stricter.
