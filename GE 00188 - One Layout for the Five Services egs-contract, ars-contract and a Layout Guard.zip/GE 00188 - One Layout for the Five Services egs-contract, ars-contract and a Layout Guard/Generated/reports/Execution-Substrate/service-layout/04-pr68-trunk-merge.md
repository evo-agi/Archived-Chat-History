# ES PR #68 brought up to date with trunk_dev: writer report

Thread report from the writer thread "Make ES service layouts consistent". Written 2026-11-27, about 00:40Z.

- Repository: evo-agi/Execution-Substrate. PR #68 (draft), branch `claude/project-thread-t608v3`.
- **Head for the fresh check: 8e056aaefc96071ebf94acc9d425adf995c9f89f**, tree 52018ca5333727aedeae96bab0639c872217e24a.
- **Base: `origin/trunk_dev` 39e19defb0ea6c0bda30a14f88452b24f9bd9cdf** (PR #71, docs for named workload identities). It moved from 923e9c3 after the re-check repair.
- 8e056aa is a merge of trunk_dev 39e19de into e760c67 (the head reported in `03-pr68-recheck-repair.md`). No rebase, no force-push. GitHub had marked the PR "behind", and trunk_dev requires an up-to-date branch.
- CI on e760c67 (before the merge): "build, vet and test" and "test on macOS" both passed. CI on 8e056aa: reported in the thread once it finishes.

## Canonical manifest

`04-canonical-manifest-8e056aa.json` beside this file. Recipe v2, SHA-256 c08597e2…a3ca, verified before the run. Fresh clone, the audit's procedure (checkout of the head, `git clean -fdx`, `git reset --mixed` to the base, upstream `origin/trunk_dev`, umask 022). Two runs were byte-identical.

- manifest_sha256 5226eed67a4d41dba4426f198125644c70ddf259ee489ead9b80ce69af6fd791
- textual_diff_sha256 81e0336e895ffc4494e5be7b0f7554cfe569066ca44c7cf7f49812bb0b36a111
- 42 entries, the same paths as at e760c67.

Compared with the 03 manifest, only two entries changed: `PLANS.md` and `.docs/execution_lifecycle/es_execution_admission_model.md`. Both files were edited by #71 as well. The PR's own changed lines in them are identical before and after the merge (checked by comparing the `+`/`-` lines of `git diff 923e9c3 e760c67` with `git diff 39e19de 8e056aa`). The PR's net diff is still 40 files, 879 insertions, 338 deletions.

## What #71 brought in, and why nothing else had to change

#71 touches only docs and two root docs tests (`workload_grants_docs_contract_test.go`, new, and `ars_blob_verification_docs_contract_test.go`). The merge was clean.

- A grep of the merged tree (all `.go` and `.md` outside `.docs/history/`) for `egsmodel`, `arsapi`, `egs/model`, `model.RuntimeTrustPolicy`, `api.Artifact` and `ars/api.` finds only the intentional `egs/model/trustmodel.go` refusal case in `service_layout_test.go`.
- The new root test file is allowed by the existing root-layout rule, which accepts any `*_docs_contract_test.go`, so `internal/testutil` needed no change.

## Commands and results (container, Go 1.26.5)

- `go build ./...`: clean. `go vet . ./internal/testutil`: clean. gofmt on `service_layout_test.go` and the two #71 test files: clean.
- `go test -count=1 . ./internal/testutil`: ok. This covers the layout guard, its refusal tests and #71's new docs tests on the merged tree.
- Not rerun: the full suite. Since e760c67, only #71's docs and root docs tests changed, and the root package was rerun. CI runs the full suite on 8e056aa.

## Still open

- PR #70 overlap, unchanged from report 03: whichever of #68 and #70 lands second adds the four `scripts/remote_alpha_user_identity_test.go` entries to `layoutCrossServiceExceptions`.

## Authority or security widening

None. The merge brings in only trunk_dev's docs; the PR's own diff is unchanged.
