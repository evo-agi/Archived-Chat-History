# ES PR #68 repair after re-check 02: writer report

Thread report from the writer thread "Make ES service layouts consistent". Written 2026-11-26, about 23:40Z.

- Repository: evo-agi/Execution-Substrate. PR #68 (draft), branch `claude/project-thread-t608v3`.
- Base: `origin/trunk_dev` 923e9c3366775664c8a85f19273e3dd4fc04eb22 (re-checked unchanged at 23:38Z).
- Re-checked head: 1e3ec7c4f0c468807dd03f91ac2fac766d30cf77. The re-check thread "Re-check the service layout PR" returned BLOCK on R68-1 and R68-2, both Low.
- New head: **e760c6765bf8c054fb1bfb206c75c035d8965edf**, tree 6a336623bd52b80b4166a87f1b796a8df092515f. It is one commit on top of 1e3ec7c. No rebase, no force-push.
- Canonical manifest: `03-canonical-manifest-e760c67.json` beside this file. Recipe v2, SHA-256 c08597e2…a3ca, verified before the run. The audit's procedure was followed in a fresh clone, and two runs were byte-identical.
  - manifest_sha256 e5a08d09fa16f510863a4547c32601102f1dc4e3620d5182ebc4b7596cf6b930
  - textual_diff_sha256 2b817a85768f613445ec96e8fe6882a8bc4b45fcaffa87a6e9a9f6e09f18be83
  - 42 entries, the same paths as at 1e3ec7c.

## Delta 1e3ec7c → e760c67

Two files: `README.md` (one sentence) and `service_layout_test.go` (header comment and two refusal-test cases).

| Finding | Fix |
|---|---|
| R68-1 | README "Repo Structure" and the guard's header comment now read: "Apart from the repository-wide tests at the repository root, Go code lives only in the five service folders, `cmd/`, `internal/` and `scripts/`." A new refusal-test case shows that a test file at the root (`zz_docs_contract_test.go` importing `es/config`) is allowed. |
| R68-2 | A new refusal-test case shows that a Go file directly in a new top-level folder (`pkg/leak.go`) is refused with "top-level directory pkg/ holds Go code". Mutant check: changing the rule's `len(segments) >= 2` to `>= 3`, which would let that file through, fails this case. |

## Commands and results (container, Go 1.26.5)

- `go vet .`: clean. gofmt: `service_layout_test.go` clean.
- `go test -count=1 . ./internal/testutil`: ok. The two new subtests and the existing ones pass.
- The depth mutant above was run in a throwaway copy of the tree and was killed.
- GitHub CI on e760c67: reported in the thread once it finishes.

## The overlap with PR #70 (coordinator's request)

With #68 and #70 both merged, `TestServiceLayout` fails. `scripts/remote_alpha_user_identity_test.go` (in #70) imports `ags/api`, `ags/publish`, `es/admission` and `es/api`.

- Agreed with the "Plan Claude as ES alpha tester" thread (23:36Z): keep the rule, and list those four imports in `layoutCrossServiceExceptions`.
- Why: the test serves the minted identity through the real ES and AGS handlers with stub services behind them, and the handlers' interface types live in `es/admission` and `ags/publish`. Starting full stacks through `app/` would be much heavier and add nothing.
- The entries can't be added early, because the guard fails on an entry for a file that doesn't exist. Whichever PR lands second adds them.
- The alpha thread checked a trial merge of #68 at 1e3ec7c with #70 at a0e86ea. It failed on exactly those four imports, and with the entries added, the root package and `internal/testutil` passed.
- The four lines:

```go
{"scripts/remote_alpha_user_identity_test.go", "ags/api"}:      "serves the minted identity through the real AGS handlers",
{"scripts/remote_alpha_user_identity_test.go", "ags/publish"}:  "stubs the AGS publish service behind those handlers, whose types live in ags/publish",
{"scripts/remote_alpha_user_identity_test.go", "es/admission"}: "stubs the ES admission service behind the ES handlers, whose types live in es/admission",
{"scripts/remote_alpha_user_identity_test.go", "es/api"}:       "serves the minted identity through the real ES handlers",
```

## Authority or security widening

None. The delta touches no production code.
