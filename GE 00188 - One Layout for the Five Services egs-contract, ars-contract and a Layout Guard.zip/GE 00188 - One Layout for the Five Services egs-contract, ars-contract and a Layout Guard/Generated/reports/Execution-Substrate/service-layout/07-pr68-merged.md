# ES PR #68 merged: writer report

Written 2026-11-27, about 02:25Z, by the writer thread "Make ES service layouts consistent".

- **Merge commit on `trunk_dev`: a5861b7c0e2199a77b489d25e6b3fc02e6448c20** (squash, single parent fbfd100, PR #72).
- Merged head: 10f77bafda3074d92727738da7535dd5c0a7c5d5, tree 5620646fecd0338e1c6eab806d8aee3d8035f89d. It is 8e056aa (accepted by the second re-check, `05-pr68-second-reaudit.md`) plus a clean merge of `trunk_dev` fbfd100 (#72). That tree is exactly the one the auditor's trial merge covered (`05-evidence/trial-merge-pr72.txt`).
- Go to merge: coordinator, under David's standing merge policy (decisions.md #7).

## Merge gate (provenance §5.4)

1. PR head equalled the synced head 10f77ba when merged (`expectedHeadSha` pinned on the merge call).
2. `trunk_dev` moved from 39e19de to fbfd100 after the audit. The sync merge was clean. The PR's own changed lines are identical to those at 8e056aa (40 files, +879/−338). The merge tree equals the auditor's trial-merge tree. Manifest for 10f77ba against fbfd100: `06-canonical-manifest-10f77ba.json`, recipe v2 (c08597e2…a3ca verified), two runs byte-identical, manifest_sha256 9b0dbfffe9a746741159224f60f831df09a669c3a7bb364ab16098a84d7810c2, textual_diff_sha256 cdcbfbc06e2e6f5284339971c9774d0bb20e0119ccebc71ea407acc6e7a6a25f, 42 entries.
3. Both required checks passed on 10f77ba: "build, vet and test" (finished 02:20Z) and "test on macOS" (01:53Z). The branch was up to date with `trunk_dev` fbfd100 just before the merge.
4. After the merge, `trunk_dev`'s tree is 5620646f, identical to the merged head's tree. Every one of the 42 manifest paths on `trunk_dev` has the audited bytes, and the two deleted paths are gone.

## Follow-up for PR #70

`scripts/remote_alpha_user_identity_test.go` in #70 now needs the four agreed `layoutCrossServiceExceptions` entries (see `03-pr68-recheck-repair.md`). The "Plan Claude as ES alpha tester" thread has been told.
