# ES service layouts: why `es/internal/` and `egs/model/` exist, and one consistent layout

Status: DECIDED, being implemented. David 2026-11-26 21:06Z: rename `egs/model` to `egs/contract`, leave `es/` as it is. 21:07Z: add `ars/contract` too, on condition that it really stops ES and AGS from compiling ARS's server and blob store (shown with `go list -deps` in the PR). Implementation: ES branch `claude/project-thread-t608v3`, draft PR to `trunk_dev`. The text below is the proposal as written before the decision.
Written 2026-11-26 by the thread "Make ES service layouts consistent", for David's questions of 2026-11-26 20:18Z and 20:19Z ("Why does es/ have an internal/ package… Why does egs/ have a model/ package, when other services don't?" and "it's a matter of personal preference and consistency, about the layouts").
Base: Execution-Substrate `origin/trunk_dev` 923e9c3366775664c8a85f19273e3dd4fc04eb22 (2026-11-25, PR #64). Every path:line below is at this commit unless marked otherwise.

## Short answer

- **Why `es/internal/`:** ES is the only service with Go code that two of its own packages share. `ownershipnorm` and `staticarchive` are used by both the admission service (`es/admission`) and the runtime helper (`es/runtimehelper`), so they need a home above both, and Go's `internal/` rule makes that home importable only from inside `es/`. The third package, `outsideobserverprotocol`, is a proposed protocol that is deliberately switched off; a standing rule calls it "ES-private", and `internal/` stops any other service from importing it. The other four services are small (4 to 5 packages, about 700 to 1,800 lines of non-test code each) and have nothing shared between their own packages, so they have no need for it.
- **Why `egs/model/`:** it holds the one EGS type that another service must *compute with*, not just read: the runtime trust policy and the exact bytes EGS signs. ES recomputes those bytes to check EGS's signature, so both sides must use the same code. Putting it in a small package with no server code lets ES use it without pulling in EGS's HTTP server. The docs classify it as an EGS-owned contract that is deliberately *not* part of the shared kernel in top-level `internal/contracts/`. The name "model" is just generic; why it was chosen is unknown, because the history before 2026-04-19 was squashed.
- **The inconsistency is mostly elsewhere.** ARS has the same need but did not split its types out: its wire types sit in `ars/api` next to the ARS HTTP server, so the ES and AGS programs both compile in ARS's server, index and blob store. EGS's split is the better pattern, and ARS is the outlier.
- **Would the other services benefit from `internal/`?** Not much today. The compiler check only stops *direct* imports from other services. Today the only cross-service imports in production code are the two contract uses above. Everything else that reaches across services is in-process integration tests, which `internal/` would break rather than protect. A small guard test gives the same protection for production code and can list the test exceptions by name.
- **Recommendation (option A below):** keep the shape every service already shares (`api/`, `app/`, `config/`, plus packages named for what they do). Rename `egs/model` to `egs/contract`, and move ARS's wire types into a new `ars/contract`. Keep `es/internal/`, because it is the right Go tool there. Add a guard test that allows cross-service imports only through `<service>/contract`, and write the rules into the README. A trial of the two moves changed 30 Go files. It built and vetted cleanly, and the tests gave the same results as unmodified `trunk_dev` except for one expected failure: a guard pins the hash of a reviewed reliable-submit file whose import line the rename changes. After the moves, ES links only `ars/contract` and `egs/contract` from other services.

## What the five services look like today

Repo-validated (`go list` at 923e9c3). Line counts exclude tests.

| Service | HTTP adapter | Wiring | Config | Domain packages | Types another service's code imports | `internal/` |
|---|---|---|---|---|---|---|
| AGS | `ags/api` (145) | `ags/app` | `ags/config` | `publish` (580), `sign` (82) | none | none |
| ARS | `ars/api` (1,093: server 1,004 + types 89) | `ars/app` | `ars/config` | `index` (236), `store` (221) | `ars/api` types (ES, AGS) | none |
| CGS | `cgs/api` (214) | `cgs/app` | `cgs/config` | `policy` (362) | none | none |
| EGS | `egs/api` (149) | `egs/app` | `egs/config` | `sign` (106), `model` (154) | `egs/model` (ES) | none |
| ES | `es/api` (336) | `es/app` | `es/config` (773) | `admission` (16,695), `runtimehelper` (1,588) | none | `es/internal/` (3 packages), `es/admission/internal/` (2 packages) |

Top-level `internal/` holds code that several services share: `callerauth`, `callerallowlist`, `contracts/evidence/v1`, `contracts/runtimeconfig/v1`, `httpx`, `observability`, and the test-only `testtmpdir` and `testutil`. Each service also has `cmd/<service>/main.go`.

So the five services already share one skeleton (`api`, `app`, `config`, then domain packages). The two oddities David spotted are the only places that add to it. The table's "ARS" row shows the third oddity, which is less visible.

## `es/internal/` in detail

| Package | What it is | Imported by (non-test) | Added |
|---|---|---|---|
| `ownershipnorm` (191 lines) | Marker and ownership-normalization rules for ES's writable state | `es/admission/writablestate_preflight.go:10`, `es/runtimehelper/supervisor.go:22` | 3c9fdb3, 2026-04-25 |
| `staticarchive` (156 lines) | One tar/gzip reader and name normalizer for static-script archives | `es/admission/policy_payload.go:11`, `es/runtimehelper/supervisor.go:23` | 2478a24, 2026-11-18 (PR #8) |
| `outsideobserverprotocol` (1,457 lines) | Inert "Stage A" parsers for a proposed outside-observer protocol | nothing, by design | 68ec38c, 2026-10-27 |

- Repo-validated: the policy check and the runtime helper must read archives exactly the same way. A guard test pins that both go through the one `staticarchive.Open` (`es/admission/workstream_c_guardrails_test.go:10368-10405`). Code shared by two ES packages but meant for no other service is exactly what Go's `internal/` is for: `es/internal/x` can be imported only from inside `es/`.
- Repo-validated: `.docs/standing_rules/execution_admission_and_custody.md:23` allows "only the ES-private `es/internal/outsideobserverprotocol`" and says it "adds no active import". The root test `outside_observer_docs_contract_test.go:40-60, 132-158` fails if any production file imports it.
- `es/admission/internal/` follows the same rule one level down: `reliablesubmit` and `admissionstate` are private to `es/admission`. The admission docs cite those paths in many places.
- The commit messages don't explain the folder choice. Inference: these are the textbook reasons, and nothing in the code contradicts them.

## `egs/model/` in detail

- Repo-validated: `egs/model/trustmodel.go` defines `RuntimeTrustPolicy` (allowed signers, revoked signers, revoked artifacts), `PublicationMetadata` (version, update revision), and `CanonicalBytes`/`PayloadDigest`, which give the exact bytes that are signed (`trustmodel.go:13-25, 67-98`).
- EGS signs those bytes (`egs/sign/signer.go:76`). ES fetches `/v1/trust-model`, validates the policy, recomputes `CanonicalBytes` and checks the signature against them (`es/admission/service.go:339-370`). ES declares its own copy of the signed response wrapper (`service.go:159-166`) and takes only the policy type from EGS. So the type plus its canonical form is a contract both sides run, and keeping it in a package with no server code lets ES share it without importing `egs/api` and EGS's HTTP server.
- Repo-validated: `.docs/system_overview/shared_kernel.md:87` lists the "EGS runtime-trust payload" as a "service-owned contract" owned by EGS: "ES consumes that trust output but the EGS payload does not become part of the shared artifact kernel". That is why it lives under `egs/` and not in top-level `internal/contracts/`. `.docs/system_overview/boundaries.md:832` names `egs/model/trustmodel.go` as the home of that shape.
- History: `egs/model` has existed since the first Go code in the repo (8a5e166, 2026-04-19, the squash merge of PR #1). The earlier history is not in the repo, and the project's POC snapshot is the earlier Python monolith, so **why it was named "model" is unknown**. In Go, a name like `model`, `util` or `types` says nothing about the contents, which is why it looks out of place next to `index`, `store`, `policy` and `sign`.

### The ARS contrast

- Repo-validated: ARS's wire types (`ArtifactDiscovery`, `ArtifactIdentity`, `ArtifactBlobRef`, the schema-version constants, …) are in `ars/api/types.go` (89 lines), in the same package as the 1,004-line ARS server, which imports `ars/index` and `ars/store` (`ars/api/server.go:14-15`).
- ES (`es/admission/service.go:27`) and AGS (`ags/publish/service.go:24`) import `ars/api` for those types. As a result, `go list -deps ./cmd/es` includes `ars/api`, `ars/index` and `ars/store`, and so does `./cmd/ags`. ES's admission code *could* call ARS's blob store directly, and nothing would flag it. Severity: a layering inconsistency, not a bug. No such call exists today.

## Would the other services benefit from Go's `internal/`?

- What it enforces: a package under `x/internal/` can be imported only from inside `x/`. The whole repo is one module whose path (`execution-substrate`) can't be fetched, so no code outside the repo can import any of its packages anyway. Here, `internal/` matters only *between services in this repo*.
- Today's cross-service imports (repo-validated, `go list` with tests):
  - Production: `es/admission` → `ars/api`, `egs/model`; `es/admission/internal/admissionstate` → `egs/model`; `ags/publish` → `ars/api`. These are all contract uses. Moving domain packages under `internal/` would not stop the ARS server and store from being compiled into ES, because `internal/` checks only direct imports and `ars/api` (public) may import its own `ars/internal/store`. Only splitting the types out fixes that.
  - Tests only: `es/app` and `ags/app` integration tests start ARS, EGS and AGS in-process, and they write ARS's on-disk blob store and index directly (`es/app/submit_integration_test.go:2575-2596`, `ags/app/app_integration_test.go:943-949`, through `ars/store` and `ars/index`). `ags/app/app_integration_test.go:59, 852` uses ES's `admission.PrepareRequest`/`PrepareResult`. These tests would stop compiling if those packages moved under `internal/`, so each service would need a test-harness package.
- Conclusion: `internal/` everywhere would protect against *future* reach-ins between services, and it costs nothing to maintain once in place. But no current violation exists, it would break legitimate tests, and for ES it means moving `es/admission`, which is cited 994 times in 74 files, many of them governing docs. A guard test can enforce the same boundary for production code now.

## Options

### A. Same rules everywhere, two small moves, a guard test (recommended)

Target layout:

```
cmd/<svc>/                 main package
<svc>/api/                 HTTP adapter: handlers and their response shapes
<svc>/app/                 wiring (used by cmd and by in-process integration tests)
<svc>/config/              config file schema and loader
<svc>/contract/            only when another service's code needs this service's types:
                           wire types and their canonical form, no server/store imports
<svc>/<domain>/            packages named for what they do (publish, sign, index, store,
                           policy, admission, runtimehelper); no generic names
<svc>/internal/<pkg>/      only for packages private to the service: shared by several of
                           its packages, or deliberately unwired
internal/<pkg>/            code shared by several services (callerauth, contracts/…, …)
```

Changes:
1. `egs/model` → `egs/contract` (package `contract`; type names unchanged).
2. `ars/api/types.go` → `ars/contract/types.go`; `ars/api` imports it.
3. `es/internal/` and `es/admission/internal/` stay as they are.
4. A new root guard test (beside the existing repo-wide guards such as `artifact_hygiene_test.go`). It parses every Go file under the five services, `cmd/` and `scripts/`, and fails when:
   - production code imports another service's package other than `<svc>/contract`;
   - `cmd/<svc>` imports anything other than its own service (one listed exception outside `cmd/`: `scripts/internal/esconfigcheck` → `es/config`);
   - a service gains a top-level package with a generic name (`model`, `util`, `common`, `types`, `helpers`).

   Test files may reach across services only through an explicit list of (file, import) pairs. The test also fails when a listed pair no longer exists, so the list can only shrink.
5. Docs in the same PR: rewrite README "Repo Structure" (it is stale: `README.md:174-181` lists only `internal/contracts/` and `internal/observability/` and omits `cmd/`, `internal/callerauth`, `internal/callerallowlist`, `internal/httpx` and the test packages) with the rules above. Update `.docs/system_overview/boundaries.md:832` and the `egs/model/` entries in `PLANS.md:387, 680`. Add one line to `shared_kernel.md` mapping "service-owned contract" to `<svc>/contract/` and "shared kernel" to `internal/contracts/`.

Why `contract` and not a descriptive name such as `egs/trust` or `ars/discovery`: the same word in every service shows, from the tree alone, which package another service may import. It also matches the docs' own terms, "service-owned contract" versus the shared kernel in `internal/contracts/`, and keeps the guard rule to one line. Cost: Go style guides prefer names that describe contents, and `contract` is close to `internal/contracts`. The README rules address the second point. If David prefers descriptive names, swap them in; nothing else changes.

Cost and risk: about 30 Go files (mostly import lines) plus the guard test and about 5 docs. No behaviour changes. It also updates one reviewed-content pin (`state.go`, see the trial) and the expected-site list in the ARS blob guard. `egs/contract` carries the canonical bytes ES uses to verify EGS's signature, so the audit should use the full provenance gate. Inference: a pure move with unchanged test results probably doesn't need a red-team, but that is the coordinator's call. Open PRs #66 and #67 edit two of the ES test files whose import lines change (`es/app/operator_scripts_integration_test.go`, `es/app/submit_integration_test.go`). Any conflict is limited to import lines, so it is simplest to land A after them.

### B. Identical skeleton, everything private under `<svc>/internal/`

A, plus every domain package moves under its service's `internal/` (`es/admission` → `es/internal/admission`, `ars/store` → `ars/internal/store`, …). The trees look the same in every service, and the compiler enforces the boundaries with no custom test.

Cost: `es/admission` is cited 994 times in 74 files, including the governing reliable-submit and admission docs, root docs tests and `.github/ci/environment-only-tests.txt`. `es/runtimehelper` is cited 25 times in 5 files. The in-process integration tests in `es/app` and `ags/app` need new test-harness packages for ARS's store and index and for ES's admission request types. Merge conflicts with any future reliable-submit work are likely. All of that buys protection against reach-ins that don't exist today.

### C. Explain and document only

Write the current rules into the README and change no code. Cheapest, but `model` keeps its generic name, ES and AGS keep compiling ARS's server, and nothing machine-enforces the rules. The project instructions ask for exactly that kind of enforcement instead of prose.

## Trial of option A (evidence, not a PR)

Done in a scratch worktree at 923e9c3, then discarded. Moves 1 and 2 only; the guard test and docs edits were not written.
- `git diff --stat`: 30 files changed, 300 insertions, 299 deletions, all package moves, import lines and gofmt alignment.
- `go build ./...` and `go vet ./...`: clean.
- `go list -deps ./cmd/es`, packages from other services: only `ars/contract` and `egs/contract` (before: `ars/api`, `ars/index`, `ars/store`, `egs/model`). `./cmd/ags`: only `ars/contract`.
- `go test -count=1 ./egs/... ./ars/... ./ags/...`: all passed.
- `go test -count=1 ./es/... ./internal/... ./cgs/... .` (trial) compared with `./es/admission/... ./es/app ./internal/callerauth` (unmodified base, the four packages that failed in the trial): the base fails 40 tests in this container and the trial fails the same 40 plus one. All other packages passed in the trial.
  - The 40 are this container, not the move. 22 load package metadata for darwin/arm64, which needs modules that aren't in the offline module cache. 18 need a `nomad` binary, a non-root user, the operator-script environment, or the special schema-probe builds.
  - **The one extra failure is expected and matters:** `TestOperationalAdmissionStatePackageIsOneReviewedFile` (`es/admission/workstream_c_guardrails_test.go:5771, 5799`) pins the SHA-256 of `es/admission/internal/admissionstate/state.go`, a reviewed reliable-submit file. Renaming `egs/model` changes that file's import line, so the PR must update the pin, and the audit must confirm that the import line is the only change.
- Inference, not run here: two guards that this container can't run because of the darwin load will need deliberate edits in the PR. `es/admission/ars_blob_fetch_test.go:1000-1003` expects ES to link `../ars/api/server.go` ("ES imports ars/api for its wire types"); after the move ES no longer links it, so that expected site goes away. The guard tests that load typed package metadata may also list package paths. CI runs them all, so the PR's CI run is the real check.
- Existing related guard: `TestWorkstreamAESBoundaryImportsExcludeARSSupportAndAGSPublicationPackages` (`es/admission/workstream_a_guardrails_test.go:755-762`) already blocks ES production code from importing `ars/index`, `ars/store` and `ags/` directly. It checks only direct imports, which is why ES still links the ARS store through `ars/api`. Option A's new guard generalizes it to all five services, and that guard's ES rows can fold into it or stay.

## Other findings

- Six files on `trunk_dev` are not gofmt-clean: `ars/index/index.go`, `egs/sign/signer.go`, `es/runtimehelper/main.go`, `es/runtimehelper/privilege_linux.go`, `ags/sign/signer.go`, `internal/observability/observability.go`. CI doesn't check formatting. Low severity; a refactor PR touching `egs/sign/signer.go` would reformat it as a side effect, so it is cleaner to fix all six in their own commit.
- The README "Repo Structure" section is stale (above).

## Not checked or unknown

- Unknown: why `egs/model` was named so. The history before 8a5e166 is not in the repo, and the archived chats start later (Sep 2026).
- Other repos (MA, IM, Coordinator) were not compared; the question was about the ES services.
