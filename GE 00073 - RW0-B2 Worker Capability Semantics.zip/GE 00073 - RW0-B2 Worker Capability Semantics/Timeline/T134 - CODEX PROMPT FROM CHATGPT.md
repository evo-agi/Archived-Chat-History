PROMPT_ID

RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIR_V1

TITLE

Coordinator RW0-B2-Capability — close transient-Git-call guard gaps and make
every protected-content boundary assertion causally mutation-sensitive

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing Capability implementation
conversation.

Do not create subagents. The parent is the sole repository writer.

This is a one-test-file regression-adequacy repair. It is not reconnaissance,
registry redesign, production implementation, documentation editing, staging,
commit, push, PR, merge, release, deployment, provider/runtime work, database
work, or supporting-repository work.

Only the exact repository path below may change.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Repair exactly two findings from the latest fresh independent audit:

```text
High — no-status guard incompleteness
The guard misses constructed/prebuilt argv, shell strings, and aliased
attribute-based Git calls. Equivalent transient Git-state dependencies can
survive while all checked tests remain green.

Medium — protected-content mutation inadequacy
Weakening one protected-content assertion still leaves all seventeen Capability
boundary tests green in an external audit copy.
```

Preserve the audit's accepted conclusions:

- the actual implementation is state-independent;
- target checks pass in unstaged, alternate-index staged, and clean committed
  states;
- all three projections match;
- State-B/State-C tree is
  `52e32a55dc2e6b023b669810fb244301807f7618`;
- the V2 live and V3 neutral-path clean validation envelopes are valid;
- the 43-row stable projection architecture is accepted;
- production, documentation, registries, parser architecture, privacy, import,
  public, and authority boundaries are unchanged.

OPENING REPOSITORY IDENTITY

Before any edit require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644
```

Require:

- `git diff --check` clean;
- cached diff empty;
- no Git operation or lock;
- real source index unstaged;
- no candidate symlink or special file;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, recorder residue, or thirty-first changed
  path.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

OPENING FINAL CANDIDATE TARGET

Commit-compatibility repair evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe
```

Required repair evidence index:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe/evidence_index.jsonl

rows excluding itself:
938

size:
151566 bytes

SHA-256:
bdffdfd9757302a7940b803f0d5138fdf9f9b41e53d95fcae3209b0e35dae71d
```

Required opening candidate identities:

```text
canonical-manifest SHA-256:
0919e82038367f54defd36171a19550873f38acae714bd7398e5a56b2fb8d77a

pytest node count:
5057

ordered node-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

clean candidate tree:
52e32a55dc2e6b023b669810fb244301807f7618

dirty topology:
30/24/6/0/0
```

Required opening path identity:

```text
tests/test_rw0_b2_capability_boundaries.py
```

Recover its exact opening size and SHA-256 from the indexed canonical manifest.
Do not guess them.

LATEST INDEPENDENT AUDIT

Audit root:

```text
/private/tmp/g4.S4uFyK
```

Audit report:

```text
/private/tmp/g4.S4uFyK/final_report.md
```

Self-excluding evidence index:

```text
/private/tmp/g4.S4uFyK/evidence_index.jsonl

rows excluding itself:
72

SHA-256:
f4836712bfc0e55dda2bb489401dabc55958016fc3c1778f8ad40a33bc5cb5b9
```

Read and preserve the complete findings and external mutant evidence for:

```text
High no-status guard defect
Medium protected-content mutation defect
```

The audit found no implementation-state defect and intentionally withheld fresh
full suites after reproducing these deterministic test-adequacy blockers.

CREDITED VALIDATION ROOTS

Preserve and verify:

```text
V2 live suite:
/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset2.Udjr4a
index SHA-256:
a3abd5e9252da88623ab3285a6f560b7b71f151f672d25f6236c3779f806abe9

V3 clean suite:
/private/tmp/gv3.efmQ8X
index SHA-256:
cec6aba32a0243bf2b0b48d147df96ccb2b50ec5b9ec161dc1cc1c0d4f30eee1
```

Their old validation records become historical after this repository test
changes. A new complete live and clean validation sequence is required.

BEFORE MUTATION

Create one new neutral operator-owned, non-symlink, mode-0700 external repair
root:

```text
/private/tmp/g5.XXXXXX
```

Pre-screen every path visible to pytest with the exact retained path-safety
grammar. Use short neutral children only.

Then:

1. safely `lstat` and verify the repair, latest-audit, V2-live, and V3-clean
   evidence indexes;

2. record exact opening inventories for all roots;

3. locate and verify the exact retained provenance recipe source:

   ```text
   regular file
   mode 0400
   size 3945
   SHA-256
   db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
   ```

4. create and verify a root-local mode-0400 recipe copy before invocation;

5. reproduce the opening canonical manifest twice with safe redirection of only
   the external historical output sink;

6. require exact equality to the opening target;

7. verify every candidate path and every path outside the candidate;

8. collect the exact 5,057 opening nodes once and require the opening ordered
   SHA-256;

9. inspect completely:

   ```text
   tests/test_rw0_b2_capability_boundaries.py
   ```

10. inspect every local helper, constant, AST/call-graph guard, projection
    builder, expected literal, and mutation helper used by its seventeen tests;

11. recover from the audit evidence:
    - every surviving no-status mutant;
    - the exact weakened protected-content assertion;
    - the external audit-copy mutation procedure;
    - expected and observed results;

12. retain exact opening source, AST, helper-call graph, node source, projection
    inventory, and candidate fingerprint.

Stop before mutation on any mismatch.

ACCEPTED CONTRACT — DO NOT REOPEN

Preserve:

- every accepted production and documentation byte;
- both owner registries and parser architecture;
- the state-independent 43-row boundary projection;
- all stable path/type/mode/private/import/export/caller/dependency/schema/
  migration/protected-content/authority facts;
- A/B/C representation independence;
- all C2A, lineage, B1, Wire, and Capability production semantics;
- all public/import/privacy/authority boundaries;
- no source authentication, executable permission, semantic acceptance,
  persistence, provider/runtime/Git/publication authority;
- C/D/E and ES later/external owner seams.

Only regression-guard and protected-content causal adequacy are defective.

TEST-FIRST CAUSAL GATE

Modify only the authorized test file to add controls that fail on the opening
implementation.

The selected red gate must reproduce, at minimum:

### No-status surviving mutants

```text
constructed argv assigned before call
module-level/prebuilt argv tuple or list
shell command string
concatenated shell command string
callable alias assigned from subprocess.run
module alias attribute call
nested attribute alias
getattr-based subprocess call
wrapper function accepting prebuilt argv
callable passed as a default or closure
```

At least one mutant must match each exact survivor from the latest audit.

### Protected-content weakening

Reproduce the exact audit mutation that weakens/removes the protected-content
assertion while all seventeen opening boundary tests remain green.

Also enumerate every assertion in the same protected-content class and add a
one-predicate mutant for each.

The red gate must prove:

```text
opening no-status guard misses the listed command forms
opening boundary suite misses the exact protected-content weakening
canonical unmutated controls pass
no syntax/import/fixture/path/unrelated failure receives credit
```

Retain exact mutant source, document/source hashes, argv, environment, JUnit,
stdout/stderr, and candidate fingerprints.

REPAIR A — CLOSED REACHABLE-CALL SURFACE, NOT A GIT DENYLIST

Authorized path:

```text
tests/test_rw0_b2_capability_boundaries.py
```

Do not continue expanding a keyword/command denylist.

Replace the current no-status guard with a closed reachable-call contract for
the permanent boundary test and every local helper it directly or transitively
uses.

The final guard must:

1. start from the exact target test node and its finite local helper roots;

2. resolve the complete reachable local-function call graph;

3. require every reachable local helper to be explicitly listed in a literal
   test-owned call-surface inventory;

4. reject:
   - unknown local helper calls;
   - calls through arbitrary local variables;
   - calls through assigned callables;
   - calls through default arguments or closures;
   - dynamic dispatch through `getattr`, `globals`, `locals`, `vars`,
     `__import__`, `eval`, `exec`, or `compile`;
   - star imports;
   - unresolved aliases;
   - nested/attribute call chains outside the exact allowed surface;

5. define an exact finite external-call allowlist by fully qualified semantic
   target, not source spelling;

6. permit only the stable operations actually required, such as:
   - pure builtins from an exact allowlist;
   - `pathlib.Path` construction and exact read/stat methods;
   - AST/introspection methods needed by the guard;
   - pure data construction/comparison;
   - pytest assertion/support calls explicitly required;

7. reject all process/command/Git-capable primitives, including aliases and
   constructed arguments, without needing to recognize the words `git status`;

8. reject at least:
   - `subprocess.run`, `Popen`, `check_call`, `check_output`, `call`;
   - imported aliases of those callables;
   - module aliases and nested attribute aliases;
   - `os.system`, `os.popen`, spawn/exec families;
   - shell helpers;
   - GitPython/dulwich command execution or repository-status APIs;
   - arbitrary callable module globals not in the allowlist;

9. verify module-global names referenced by the reachable call graph have exact
   permitted types/identities and cannot hide an executable callable;

10. use finite content-free diagnostics identifying:
    - function;
    - call-site category;
    - unresolved/forbidden target class;
    without echoing arbitrary command strings.

A source-spelling denylist may remain only as defense-in-depth. The closed
allowlist is the authority.

REPAIR B — MUTATION-ADEQUATE CALL-SURFACE TESTS

Add independent test-owned mutants covering:

```text
direct subprocess call
constructed/prebuilt argv
shell string
concatenated shell string
imported callable alias
module alias attribute
nested attribute alias
getattr dispatch
wrapper accepting argv
callable default
callable closure
module-global executable callable
unknown local helper
dynamic import
GitPython-like status call
dulwich-like status call
```

For every mutant record:

```text
case ID
mutant source SHA-256
mutation class
expected finite diagnostic
actual finite diagnostic
```

Require unique source bytes and unique purpose.

Add kill controls proving a naive keyword/command denylist would miss the
constructed/aliased forms while the closed reachable-call contract rejects
them.

REPAIR C — LITERAL 43-ROW PROJECTION OWNERSHIP

Retain the 43-row state-independent projection, but make its oracle boundaries
explicit.

Require:

1. one literal test-owned expected row inventory and order;

2. no row generated from the projection builder under test;

3. no expected protected-content value derived by reading the same target
   source during expectation construction;

4. every row has:
   - unique row ID;
   - contract class;
   - source path or boundary subject;
   - exact expected stable value;
   - dedicated diagnostic;

5. exact classes include, as applicable:

   ```text
   required path
   regular file
   mode
   protected content
   private module/export
   production importer/caller
   dependency/schema/migration
   StateStore/WriterSession
   authority/non-effect
   ```

6. assert exactly 43 rows, unique row IDs, unique purposes, and no duplicate
   semantic target unless explicitly justified.

REPAIR D — EVERY PROTECTED-CONTENT ASSERTION MUST BE CAUSAL

Identify the exact protected-content row weakened by the audit and every row in
the same class.

For each protected-content row:

1. create a fresh external/in-memory fixture from canonical accepted bytes;

2. mutate exactly one protected predicate:
   - remove required literal;
   - replace one expected literal;
   - invert one required nonclaim;
   - insert one forbidden literal;
   as appropriate to the row;

3. leave every other row predicate unchanged;

4. require the permanent boundary checker to reject with that row's dedicated
   diagnostic;

5. prove a test-local mutant that disables only that row's assertion makes the
   causal test fail;

6. record:
   - row ID;
   - source/fixture SHA-256 before;
   - SHA-256 after;
   - exact one-predicate delta;
   - expected diagnostic;
   - actual diagnostic.

Do not satisfy this requirement by asserting only that the aggregate projection
changed. Prove the owning assertion is necessary.

The exact audit survivor must be included and killed.

REPAIR E — STABLE-CONTRACT MUTATION MATRIX

Retain and rerun the existing eight stable mutants.

Expand only when needed to cover every protected-content row.

The complete matrix must independently reject:

```text
missing required path
unexpected literal path
regular-to-symlink
wrong mode
package-root export
production importer/caller
dependency/schema/migration widening
protected-content weakening
```

No mutant may alter the source repository. Use external/in-memory fixtures.

EXACT REPOSITORY ALLOWLIST

Only this already-dirty path may change:

```text
tests/test_rw0_b2_capability_boundaries.py
```

The other 29 candidate entries must remain byte-identical.

No document or production source may change.

Final topology remains:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
all regular mode 0644
```

Stop if a second repository path, document change, source change, or
thirty-first dirty path is required.

THREE-STATE VALIDATION

After final test bytes are frozen, run the target in:

```text
A live unstaged
B alternate external index staged
C fully external clean committed
```

Requirements:

- no real source-index mutation;
- fully external clean object database;
- neutral pre-screened paths;
- exact final 30-file overlay;
- B/C prospective and committed tree equality;
- target passes all three;
- 43-row projection identical all three;
- source bytes/index/object database unchanged.

Record exact B/C final tree; do not predeclare it.

VALIDATION EVIDENCE ROOT

Use only the new neutral root:

```text
/private/tmp/g5.XXXXXX
```

Retained files mode 0400; directories mode 0700. Use a complete unconditional
attempt recorder and create a self-excluding index last.

VALIDATION ENVIRONMENT

For every pytest child:

```text
umask 022
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct neutral external PYTHONPYCACHEPREFIX
distinct neutral external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct neutral external --basetemp
distinct neutral external --junitxml
serial execution
```

Pre-screen every path visible to pytest with the exact path-safety grammar.

FINAL VALIDATION ORDER

After final repository bytes and external mutant ledgers are frozen:

1. selected causal:
   - closed call-surface mutants;
   - exact protected-content survivor;
   - every protected-content row mutant;
   - projection inventory/uniqueness;
   - three-state target controls;

2. Capability boundaries:
   ```text
   tests/test_rw0_b2_capability_boundaries.py
   ```

3. Capability complete:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   ```

4. B1/Wire compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```

5. architecture/status/static:
   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

6. final collection exactly once;

7. compare with opening 5,057 list and record every addition/removal/rename;

8. require all nodes outside the authorized test unchanged in identity/order;

9. final path/mode/protected/public/authority/operation/lock/residue guards;

10. complete live suite exactly once;

11. complete neutral-path external clean-commit suite exactly once;

12. cleanup;

13. two exact final provenance runs.

Do not predeclare final node count.

Every credited green run requires:

```text
return code 0
zero failures/errors/skips/xfails/warnings
empty stderr
parseable JUnit
zero duplicate/unmapped cases
matching caller/child umask
complete indexed run-local pre/post fingerprints
unchanged candidate/tree
```

FULL-SUITE POLICY

The live and clean suites are distinct required state validations.

Run each exactly once.

If either fails:

- preserve all evidence;
- do not retry in this engagement;
- return a stage-specific failure token;
- do not modify repository bytes further.

PROVENANCE CLOSEOUT

After validation and cleanup:

1. require source topology `30/24/6/0/0`;

2. prove exactly the sole authorized test path changed from the opening
   candidate;

3. prove the other 29 entries remain byte-identical;

4. prove every path outside the candidate equals HEAD;

5. run the exact retained recipe twice using a verified root-local mode-0400
   copy and safe sink redirection;

6. require byte-identical final manifests and complete outputs;

7. retain:
   - exact recipe source;
   - final manifests and outputs;
   - per-path identities;
   - opening/final node lists;
   - closed call-surface inventory;
   - all call-surface mutants/results;
   - literal 43-row projection;
   - protected-content causal ledger;
   - stable-contract mutant ledger;
   - A/B/C records;
   - all attempt envelopes;
   - live/clean full-suite evidence;
   - final guards and cleanup;

8. verify all pre-existing evidence roots unchanged;

9. create a self-excluding evidence index last.

Do not stage, commit, push, create a PR, or perform an independent audit.

STOP CONDITIONS

Stop without further mutation if:

- opening identity/provenance differs;
- a second repository path is required;
- the closed reachable-call surface cannot be expressed finitely;
- a legitimate stable helper requires arbitrary external command execution;
- protected-content expectations cannot be made independent/non-circular;
- a production/document/authority defect is discovered;
- three-state or suite behavior diverges;
- validation/provenance becomes unstable.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only when:

- all high-severity no-status mutants are killed;
- every protected-content assertion is causally mutation-sensitive;
- A/B/C behavior is green;
- live and clean complete suites are green;
- exact one-file provenance is stable;
- every stop condition is false.

FINAL REPORT

Include:

1. opening/final identity;
2. latest audit evidence verification;
3. opening target reproduction;
4. selected red evidence;
5. exact one-path delta and 29-path equality;
6. closed reachable-call architecture;
7. call-surface inventory and all mutant results;
8. exact 43-row projection;
9. protected-content causal ledger;
10. stable-contract mutant matrix;
11. A/B/C target and projection results;
12. node comparison;
13. every validation attempt;
14. live full-suite result;
15. clean full-suite result and tree equality;
16. final manifest and aggregate identities;
17. evidence index and cleanup;
18. protected/public/authority non-widening;
19. remaining C/D/E/ES seams;
20. separate provenance, validation, and implementation confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
