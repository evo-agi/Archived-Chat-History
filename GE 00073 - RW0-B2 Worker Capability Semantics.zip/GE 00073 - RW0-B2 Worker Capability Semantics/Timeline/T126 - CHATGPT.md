## Engineering disposition

**Do not repair the candidate. Perform one no-mutation validation-binding reset, then submit the unchanged bytes to a fresh independent audit.**

The diagnostic isolates the problem cleanly:

- Live repository bytes match the retained final manifest.
- The one-file repair, node list, three-state evidence, projection/mutant evidence, recipe replay, final guards, and evidence indexes all match.
- The live and clean-commit suites produced valid result artifacts.
- What is missing is the **run-local pre/post repository fingerprint** for each full-suite execution.
- Later closeout guards cannot prove the exact state immediately surrounding those historical runs.
- Validation binding is therefore **partial**, not invalid.

Repeating implementation or mutation probes would add noise and risk. The minimum sufficient continuation is:

```text
one live full-suite rerun
one fully external clean-commit full-suite rerun
complete indexed fingerprints immediately before and after each
no repository-byte or real-index changes
```

The clean repository must have a completely separate object database. The earlier clean-state setup wrote loose objects into the source object database even though candidate bytes were unaffected; the reset explicitly prevents that.

## Validation-binding reset handoff

Send this complete prompt to the **same write-enabled Capability implementation conversation**:

:chatgpt-content-reference{index="0"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Commit_Compatibility_Validation_Binding_Reset_Prompt.txt

Size:
19,783 bytes

SHA-256:
13ed5e78a4e7d2ae42c7e8f9a0ac88261d03a31872f1e546df6638c75740c6d2
```

It is bound to:

```text
Repository:
/Users/ds/Repositories/Governed Execution Coordinator/

Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Final manifest:
0919e82038367f54defd36171a19550873f38acae714bd7398e5a56b2fb8d77a

Final nodes:
5,057

Final node-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

Clean candidate tree:
52e32a55dc2e6b023b669810fb244301807f7618

Final repair evidence root:
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe

Provenance diagnostic root:
/private/tmp/ge-coordinator-rw0-b2-provenance-diagnostic.SsN1jd
```

### What the reset records

For both full-suite runs, the recorder must atomically retain:

```text
exact argv and environment
Python identity
caller and child umask
timing and PID
return code or signal
stdout, stderr, and JUnit identities
test counts and JUnit/node mapping
complete pre-run repository fingerprint
complete post-run repository fingerprint
candidate-mutated result
```

The source-repository fingerprint includes:

```text
HEAD, tree, parent, refs, and worktrees
porcelain status
tracked and cached binary diffs
real .git/index bytes and metadata
canonical candidate manifest
all candidate path hashes and modes
outside-candidate equality to HEAD
source .git/objects inventory and aggregate hash
operations, locks, and residue
```

For the clean suite, it additionally fingerprints the external repository and verifies:

```text
no object alternates
no hardlinks to source objects
no shared object inode
clean worktree and index
tree == 52e32a55dc2e6b023b669810fb244301807f7618
source index and object database unchanged
```

The prompt authorizes **exactly two suites**:

```text
Live candidate:
5,057 / 5,057

External clean commit:
5,057 / 5,057
```

It does not rerun:

```text
implementation
test-first red
mutation probes
node collection
focused test groups
historical failed attempts
```

The required result is:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_VALIDATION_BINDING_RESET_COMPLETE_READY_FOR_FRESH_REAUDIT
```

After that result, launch a fresh independent re-audit using the same repository bytes plus the new complete run-local evidence. The commit gate remains blocked until that audit returns `ACCEPT`.

### Source

- Codex provenance-mismatch diagnostic supplied in this turn.

**Confidence:** Very high that no implementation repair is needed; high that these two precisely fingerprinted suite reruns are the minimum sufficient continuation; acceptance remains unresolved until the new validation envelope is independently audited.
