PROMPT_ID

RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_VALIDATION_BINDING_RESET_V2

TITLE

Coordinator RW0-B2-Capability — retry the no-mutation validation-binding
reset after correcting the evidence-root recipe-copy mode preflight

ENGAGEMENT TYPE

Parent-only validation-evidence continuation in the same write-enabled
Capability implementation conversation.

Repository mutation is not authorized.

Do not edit, format, generate, delete, rename, chmod, stage, commit, push, open
a PR, merge, tag, release, deploy, contact a remote/service/provider/host,
invoke a product worker/model, mutate a database, install dependencies, or
inspect a supporting repository **inside the source repository or any
pre-existing evidence root**.

Inside the one new evidence root created by this engagement, creating files,
atomic renames, and setting retained files to mode `0400` and directories to
mode `0700` are explicitly authorized and required.

Do not rerun implementation, test-first red controls, parser/mutant probes,
focused test groups, or historical failed/superseded attempts.

This engagement reruns exactly:

```text
one live-candidate complete suite
one external clean-commit complete suite
```

and records complete indexed run-local fingerprints immediately before and
after each suite.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Close the exact evidence gap identified by the provenance diagnostic and retry
the reset after one procedural opening-gate failure.

The preceding reset attempt returned:

```text
VALIDATION_BINDING_RESET_PROVENANCE_MISMATCH
```

Preceding failed-reset evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset.dwDBSw
```

Preceding failed-reset evidence index:

```text
/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset.dwDBSw/evidence_index.jsonl

rows excluding itself:
51

size:
9824 bytes

SHA-256:
15144abc491fb349433810e8ab6324f2b3034b62706f8bc4377dce63e6f2a32f
```

The sole failed predicate was external evidence-root recipe-copy mode:

```text
required at invocation:
0400

observed at invocation:
0600
```

Both recipe invocations were refused before pytest, node collection, clean setup,
or suite execution. Source opening and closeout fingerprints were byte-identical.
The failed reset is historical procedural evidence only and must remain unchanged.

Close the exact evidence gap identified by the provenance diagnostic:

```text
MANDATORY_EVIDENCE_UNAVAILABLE

first failed predicate:
I.live_full_suite.before_after_fingerprint

same missing predicate:
J.clean_full_suite.before_after_fingerprint
```

The prior suite result artifacts exist and the current candidate bytes are
stable, but the old attempt envelopes omitted indexed pre/post fingerprints
binding:

```text
manifest
candidate tree
HEAD
real index
status
```

Later closeout guards cannot reconstruct those historical run-local states.

Create a new authoritative validation-binding envelope by running exactly one
live and one clean suite against the unchanged final candidate, with complete
atomic pre/post fingerprints.

The clean-state setup must use a fully external object database and must not
write loose objects, stat-cache updates, index bytes, or any other data into the
source repository.

OPENING REPOSITORY IDENTITY

Before creating the new evidence root require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644
```

Require:

- `git diff --check` clean;
- cached diff empty;
- no Git operation or lock;
- real source index unstaged;
- no candidate symlink or special file;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, recorder residue, or thirty-first changed
  path.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

FINAL CANDIDATE TARGET

Final repair evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe
```

Required final repair index:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe/evidence_index.jsonl

rows excluding itself:
938

size:
151566 bytes

SHA-256:
bdffdfd9757302a7940b803f0d5138fdf9f9b41e53d95fcae3209b0e35dae71d
```

Required final candidate identities:

```text
canonical-manifest SHA-256:
0919e82038367f54defd36171a19550873f38acae714bd7398e5a56b2fb8d77a

pytest node count:
5057

ordered node-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

clean staged/committed candidate tree:
52e32a55dc2e6b023b669810fb244301807f7618

dirty topology:
30/24/6/0/0
```

Required sole repaired path:

```text
tests/test_rw0_b2_capability_boundaries.py
```

The other 29 candidate entries must match the accepted opening target exactly.

PROVENANCE DIAGNOSTIC

Diagnostic root:

```text
/private/tmp/ge-coordinator-rw0-b2-provenance-diagnostic.SsN1jd
```

Diagnostic report:

```text
/private/tmp/ge-coordinator-rw0-b2-provenance-diagnostic.SsN1jd/final_report.md
```

Diagnostic self-excluding index:

```text
/private/tmp/ge-coordinator-rw0-b2-provenance-diagnostic.SsN1jd/evidence_index.jsonl

rows excluding itself:
6

size:
802 bytes

SHA-256:
10677d9d82b6fa342a5369b8768b38ed0c699f8f7ae547745a1bc685b170defa
```

The diagnostic established:

```text
live repository:
MATCH

final evidence index:
MATCH

final canonical manifest:
MATCH

exact one-path delta:
MATCH

recipe source/execution:
MATCH

node evidence:
MATCH

three-state evidence:
MATCH

projection/mutants:
MATCH

live full suite:
UNSUPPORTED_BY_RETAINED_EVIDENCE only because run-local pre/post fingerprints
were absent

clean full suite:
UNSUPPORTED_BY_RETAINED_EVIDENCE only because run-local pre/post fingerprints
were absent

final guards/cleanup:
MATCH

other evidence roots:
MATCH
```

Additional diagnostic observations:

- current bytes exactly equal the retained final canonical manifest;
- validation binding is partial, not invalid;
- the previous alternate-index digest predated a stat-cache refresh;
- a previous State-B setup wrote loose objects into the source object database;
- neither issue changed candidate bytes or candidate tree identity;
- the new clean-state setup must use a fully external object database.

PRE-EXISTING EVIDENCE ROOTS — READ ONLY

Safely verify and preserve at least:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe

/private/tmp/ge-coordinator-rw0-b2-provenance-diagnostic.SsN1jd

/private/tmp/ge-coordinator-rw0-b2-owner-oracle-independent-audit.T0I7mV

/private/tmp/ge-coordinator-rw0-b2-capability-commit-state-diagnostic.2SxEgB

/private/tmp/ge-coordinator-rw0-b2-capability-commit-gate.ECxUPx

/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset.dwDBSw
```

Required known indexes:

```text
commit-compat repair:
bdffdfd9757302a7940b803f0d5138fdf9f9b41e53d95fcae3209b0e35dae71d

provenance diagnostic:
10677d9d82b6fa342a5369b8768b38ed0c699f8f7ae547745a1bc685b170defa

accepted owner-oracle audit:
e09add54af9a8d6e48969fd06a0c0e57bc2bf9125229f1f811c6781303c2cb54

commit-state diagnostic:
54c0c7fadf3f44b10f6ec59c056c2f800abdf9d0c4baac911c48732dd5f9f2cb

failed commit gate:
a944cf428eb753b568864e313402088d40474d764a280d8a4bc88ca65ca13dc5

failed validation-binding reset:
15144abc491fb349433810e8ab6324f2b3034b62706f8bc4377dce63e6f2a32f
```

Safely `lstat` every path component. Record opening tree fingerprints for all
roots and require exact equality at closeout.

EXACT RECIPE SOURCE

Locate the exact retained recipe source through the final repair index.

Require:

```text
type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Do not decode or reconstruct recipe source from prompt text.

The retained source in the pre-existing evidence root is read-only and must
remain unchanged.

Before any recipe invocation, create the root-local execution copy using this
exact procedure in substance:

1. copy the retained 3,945 bytes to a temporary regular file beneath the new
   evidence root while `umask 077` is active;
2. fsync/close the temporary file;
3. atomically rename it to:
   `exact_recipe_source.py`;
4. set that root-local copy to exact mode `0400`;
5. `lstat` it and require:
   - regular file;
   - operator owner;
   - non-symlink;
   - mode exactly `0400`;
   - size exactly `3945`;
   - SHA-256 exactly
     `db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`;
6. retain a `recipe_copy_preflight.json` record containing the original and
   copied path/type/owner/mode/size/SHA-256 values;
7. launch the wrapper only after that preflight is sealed green.

The wrapper must execute the verified root-local `0400` copy. It must not chmod
the copy, repair its mode, or substitute the original retained path.

If the copy is not exact before launch, seal a complete preflight-failure
attempt envelope and stop. Do not invoke the recipe.

Use the exact recipe bytes unchanged. Safely redirect only its fixed external
historical output sink to evidence-root-local unique files.

NEW EVIDENCE ROOT

Create exactly one new top-level evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset2.XXXXXX
```

Requirements:

- operator-owned;
- non-symlink;
- mode 0700;
- all temporary files under this root;
- no repository-local evidence or temporary path;
- every executable/input evidence file that has a required mode is set to
  that mode before first use;
- the root-local recipe copy is mode 0400 before wrapper invocation;
- retained regular files mode 0400;
- retained directories mode 0700;
- no symlink, FIFO, socket, device, or special entry;
- self-excluding canonical JSONL index created last.

UNCONDITIONAL RECORDER

Create and retain one recorder before any suite execution.

Run one recorder self-test with a trivial external command.

The recorder must atomically seal an envelope even on:

```text
success
nonzero return
signal
preflight refusal
missing target
command not launched
JUnit missing or not applicable
wrapper/tooling failure
```

Each attempt envelope must include at least:

```text
schema_id
label
purpose
credit_classification
exact argv JSON array
working directory
environment allowlist
unset variables
Python executable path and realpath
Python version and implementation
platform
caller umask
child umask or explicit not-launched
wall start/end UTC
monotonic start/end ns
duration ns
child PID or not-launched
return code
terminating signal
stdout path/size/SHA-256
stderr path/size/SHA-256
JUnit applicability
JUnit path/size/SHA-256
JUnit parse status
collected/passed/failed/error/skipped/xfail/xpass/warning counts
duplicate JUnit identities
unmapped JUnit cases
ordered JUnit node-list path/count/SHA-256
retained expected node-list identity
complete pre fingerprint
complete post fingerprint
candidate-mutated boolean
notes
```

No evidence file may be added or changed after final index creation.

COMPLETE FINGERPRINT SCHEMA

Create one deterministic fingerprint implementation used identically for:

```text
source repository before live suite
source repository after live suite
source repository before clean suite
source repository after clean suite
external clean repository before clean suite
external clean repository after clean suite
```

Each source-repository fingerprint must include:

```text
physical root
branch
HEAD
HEAD tree
parent list
subject
upstream
ahead/behind
worktree inventory
git status --porcelain=v2 --untracked-files=all exact bytes and SHA-256
git diff --binary --no-ext-diff HEAD -- exact bytes and SHA-256
git diff --cached --binary --no-ext-diff HEAD -- exact bytes and SHA-256
real .git/index:
  path
  type
  mode
  size
  SHA-256
  inode/device
  mtime/ctime
candidate canonical manifest:
  path
  size
  SHA-256
  exact per-path entries
tracked textual-diff SHA-256
candidate path inventory:
  path
  classification
  type
  mode
  size
  SHA-256
outside-candidate equality-to-HEAD result
Git refs relevant to local branch/upstream
.git/objects inventory:
  no alternates
  exact relative path/type/mode/size/SHA-256 for regular files
  aggregate SHA-256
operation/lock inventory
repository residue inventory
```

Use:

```text
GIT_OPTIONAL_LOCKS=0
```

for read-only Git fingerprint queries when supported, and record it.

The post fingerprint must be created immediately after the suite child exits
and before cleanup or any other Git command that may refresh the real index.

For the external clean repository fingerprint include the same applicable
fields plus:

```text
external repository root
diagnostic commit OID
commit tree OID
clean status
object database root
absence of alternates
object inventory aggregate
```

A run is creditable only when its pre and post fingerprints are byte-identical
for the relevant repository state.

OPENING GATE

Before suite setup:

1. verify exact source-repository identity and topology;

2. verify all required evidence indexes;

3. verify current live candidate against the final canonical manifest;

4. reproduce the final manifest twice with the exact recipe;

5. require both recipe outputs equal retained final output;

6. verify the 5,057-node retained expected list;

7. capture source repository object-database inventory before any external
   clean-repository setup;

8. verify no object alternates in the source repository;

9. seal one complete opening-gate attempt envelope.

Stop on any mismatch.

LIVE SUITE — EXACTLY ONCE

Recover the exact final live full-suite argv and sanitized environment from the
indexed commit-compat repair evidence.

Do not approximate it.

Expected command in substance:

```text
python3 -B -m pytest -p no:cacheprovider -W error -q
```

with distinct external:

```text
PYTHONPYCACHEPREFIX
TMPDIR
--basetemp
--junitxml
```

and:

```text
umask 022
child umask 0022
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
PYTHONTRACEMALLOC unset
PYTHONWARNINGS unset
GIT_OPTIONAL_LOCKS=0
```

Procedure:

1. create and seal the complete source pre fingerprint immediately before
   launch;

2. launch exactly one live full suite;

3. create and seal the complete source post fingerprint immediately after child
   exit and before cleanup or additional Git queries;

4. require pre/post source fingerprints byte-identical;

5. require:

   ```text
   5057 collected
   5057 passed
   0 failures
   0 errors
   0 skipped
   0 xfailed
   0 warnings
   empty stderr
   ```

6. require parseable JUnit;

7. derive 5,057 unique JUnit node identities;

8. require exact byte mapping/order to the retained expected node list;

9. require no duplicate or unmapped case;

10. require candidate-mutated false.

No retry is authorized.

FULLY EXTERNAL CLEAN-REPOSITORY SETUP

The clean repository must have a fully external object database.

Do not use:

```text
GIT_INDEX_FILE against the source repo
git worktree from the source repo
shared object alternates
hardlinks into the source object database
a local clone that installs alternates
any command that writes source loose objects
```

Permitted setup:

1. create a new repository under the new evidence root;

2. initialize it independently with `git init`;

3. populate the accepted base commit/tree by one of these fully external
   methods:
   - copy a verified bundle/archive of Git objects into the external repository;
   - or copy all required source object bytes into the external object database
     without hardlinks and without alternates;
   - or use a local clone mode that is independently proven to create no
     hardlinks and no alternates;

4. verify:
   - `.git/objects/info/alternates` absent;
   - no inode is shared between source and external object files;
   - every object path is under the external repository;
   - source object inventory remains unchanged after setup;

5. checkout the accepted base:

   ```text
   deec37bf08fb903d8846aa2c3232aec52fa9866e
   ```

6. create branch:

   ```text
   codex/rw0-b2-capability-semantics-v1
   ```

7. overlay exactly the 30 final candidate files from the source repository;

8. verify every overlaid file against the final canonical manifest;

9. stage exactly the 30 paths;

10. create one local diagnostic commit inside the external repository;

11. require commit tree:

    ```text
    52e32a55dc2e6b023b669810fb244301807f7618
    ```

12. require clean worktree/index;

13. record commit/tree/parent/subject/body/author/committer/timestamps and object
    inventory;

14. verify source repository real index and source object inventory unchanged
    after setup.

The external commit is diagnostic-only and must not contact a remote.

CLEAN SUITE — EXACTLY ONCE

Recover the exact final clean-suite argv and sanitized environment from the
indexed commit-compat repair evidence.

Procedure:

1. create and seal:
   - source repository pre fingerprint;
   - external clean repository pre fingerprint;

2. run exactly one full suite in the external clean repository;

3. immediately create and seal:
   - external clean repository post fingerprint;
   - source repository post fingerprint;

4. require:
   - source pre/post fingerprints byte-identical;
   - external clean pre/post fingerprints byte-identical;
   - external tree remains
     `52e32a55dc2e6b023b669810fb244301807f7618`;

5. require:

   ```text
   5057 collected
   5057 passed
   0 failures
   0 errors
   0 skipped
   0 xfailed
   0 warnings
   empty stderr
   ```

6. require parseable JUnit;

7. require 5,057 unique JUnit identities exactly mapped to the retained node
   list;

8. require no duplicate or unmapped case;

9. require candidate-mutated false.

No retry is authorized.

VALIDATION-BINDING COMPARISON

Produce one exact comparison record proving:

```text
live suite pre == live suite post

clean suite external pre == clean suite external post

clean suite source pre == clean suite source post

all four source fingerprints describe the same final candidate manifest

live JUnit node list == retained expected node list

clean JUnit node list == retained expected node list

live JUnit node list == clean JUnit node list

live candidate manifest == external clean committed tree contents

external clean commit tree ==
52e32a55dc2e6b023b669810fb244301807f7618
```

Report any metadata that is intentionally state-specific separately from the
byte-stable candidate fingerprint; do not weaken the required source pre/post
identity.

FINAL GUARDS

After suite records are sealed:

1. verify source repository identity/topology/index/status/candidate manifest;

2. verify source object-database inventory equals opening;

3. verify all pre-existing evidence roots equal opening fingerprints;

4. run exact recipe twice with safe sink redirection;

5. require both manifests equal retained final manifest;

6. require both complete outputs equal retained final output;

7. verify no source operation/lock/residue;

8. remove only new evidence-root transient basetemps, caches, pycache roots, and
   the external clean repository after retaining:
   - its full manifest;
   - Git metadata;
   - object inventory;
   - commit/tree identities;
   - pre/post fingerprints;
   - suite outputs/JUnit;
   - setup command ledger;

9. retain a cleanup record.

Do not remove or alter source-repository data or pre-existing evidence.

CLOSEOUT REPORT

Generate a complete final report containing:

1. opening repository and evidence identities;
2. exact final candidate target;
3. preceding failed-reset verification and classification;
4. root-local recipe-copy preflight;
5. recorder self-test;
6. opening-gate envelope;
7. complete live-suite envelope;
8. external object-database setup and isolation proof;
9. complete clean-suite envelope;
10. run-local pre/post fingerprint comparisons;
11. JUnit/node mapping comparison;
12. source real-index and object-database invariance;
13. final guards and cleanup;
14. two final provenance runs;
15. statement that prior incomplete suite envelopes remain historical and are
    superseded for validation binding;
16. separate provenance, validation-binding, and implementation confidence.

SELF-EXCLUDING EVIDENCE INDEX

Create the index last.

Requirements:

- canonical JSONL;
- excludes itself;
- one row per retained file/directory;
- relative path, type, owner, group, mode, size;
- SHA-256 for regular files;
- no symlink or special entry;
- no file added, removed, modified, or chmodded after indexing;
- externally verify every indexed row;
- report row count, byte size, and SHA-256.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_VALIDATION_BINDING_RESET_COMPLETE_READY_FOR_FRESH_REAUDIT
```

only when:

- live suite passes 5,057/5,057 once;
- clean suite passes 5,057/5,057 once;
- every required run-local pre/post fingerprint exists and is indexed;
- source repository pre/post identities are exact;
- external clean repository uses a fully external object database;
- source real index and source object database remain unchanged;
- final provenance and evidence index are sealed.

FAILURE TOKENS

Use:

```text
VALIDATION_BINDING_RESET_PROVENANCE_MISMATCH
VALIDATION_BINDING_RESET_RECIPE_COPY_PREFLIGHT_FAILED
VALIDATION_BINDING_RESET_INPUT_INCOMPLETE
VALIDATION_BINDING_RESET_LIVE_SUITE_FAILED
VALIDATION_BINDING_RESET_CLEAN_SETUP_FAILED
VALIDATION_BINDING_RESET_CLEAN_SUITE_FAILED
VALIDATION_BINDING_RESET_SOURCE_MUTATION_DETECTED
VALIDATION_BINDING_RESET_EVIDENCE_SEAL_FAILED
```

Do not modify repository bytes in any failure case.

FINAL REQUIRED STATEMENTS

```text
REPOSITORY_MUTATION_NOT_PERFORMED
IMPLEMENTATION_NOT_RERUN
TEST_FIRST_RED_NOT_RERUN
MUTATION_PROBES_NOT_RERUN
NODE_COLLECTION_NOT_RERUN
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
