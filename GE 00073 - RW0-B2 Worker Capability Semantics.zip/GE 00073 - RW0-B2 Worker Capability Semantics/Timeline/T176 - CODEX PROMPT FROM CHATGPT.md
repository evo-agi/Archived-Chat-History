PROMPT_ID

RW0_B2_CAPABILITY_PR5_SQUASH_MERGE_GATE_V1

TITLE

Coordinator RW0-B2-Capability — squash-merge PR #5, verify the exact merge
commit and remote transition, synchronize local trunk_dev, and run bounded
post-merge validation

ENGAGEMENT TYPE

Authorized one-attempt squash-merge and local synchronization gate in the
existing Capability implementation conversation.

No implementation repair is authorized.

No direct trunk push, force push, amend, rebase, second commit, second push,
second PR, second merge attempt, auto-merge, review submission, self-approval,
thread resolution, feature-branch deletion, tag, release, deployment,
provider/live-host contact, product worker/model invocation, database mutation,
dependency installation, migration, or supporting-repository modification is
authorized.

The parent performs the gate. Do not create subagents.

CRITICAL INLINE RESPONSE RULE

Print the complete operative merge report inline in the Codex chat.

Do not return only:

- a success token;
- a short summary plus `/private/tmp` links;
- “see report”;
- paths that contain material results.

Evidence paths may be supplementary only after all identities, preflight
observations, the exact merge command, merge result, local synchronization,
validation result, final guards, and limitations have appeared inline.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Squash-merge the exact accepted PR #5 candidate into `trunk_dev`, verify the
result mechanically, synchronize local `trunk_dev` by fast-forward only, and
run one bounded post-merge validation over the changed test surfaces.

ACCEPTED FEATURE IDENTITY

```text
PR:
5

title:
feat: implement RW0-B2 Capability semantics

base:
trunk_dev

accepted base OID:
deec37bf08fb903d8846aa2c3232aec52fa9866e

head:
codex/rw0-b2-capability-semantics-v1

feature commit:
8168e40dd6e4ad9891f11142d6613f887cdbff20

feature tree:
727fb0ecf94680b64fed5e1bb2bccecccde38e4d

feature sole parent:
deec37bf08fb903d8846aa2c3232aec52fa9866e

feature subject:
feat: implement RW0-B2 Capability semantics

feature body:
empty

feature signature:
unsigned

feature shape:
24 modifications
6 additions
0 deletions
0 renames
0 copies
0 mode changes
30 files
all mode 100644
```

ACCEPTED VALIDATION

```text
collection:
5059 unique nodes
ordered SHA-256:
72ca14d20ff8e95384a8fa06b595227fb45bb7884aac295bbe4ae06ac761a0aa

complete suite:
5059 collected
5059 passed
0 failures/errors/skips/xfails/xpasses/warnings
empty stderr

accepted tree:
727fb0ecf94680b64fed5e1bb2bccecccde38e4d
```

COMMIT-GATE EVIDENCE

```text
root:
/private/tmp/g17.oCx5Dz

self-excluding index:
141 rows
24066 bytes

SHA-256:
6efad76370b48e53f2e1b83f442355b5e955c2fbf2fd1c63e66d34ca57e6d941
```

Read-only verify this evidence root and preserve it unchanged.

LIVE EXPECTED PR/POLICY STATE

Re-read every live fact immediately before merge. Do not rely only on this
prompt.

Expected PR state:

```text
open
non-draft
unmerged
mergeable true
merge state clean
base OID deec37bf...
head OID 8168e40d...
one commit
30 changed files
exact title
exact body
no auto-merge
```

Expected interaction state:

```text
requested reviewers:
0

reviews:
0

requested changes:
0

review threads:
0

issue comments:
0

review comments:
0

workflow runs:
0

commit status contexts:
0
```

A combined status of `pending` with total count `0` is synthetic and is not a
blocker only while the applicable rules require no status checks.

Expected active ruleset:

```text
ID:
18957283

name:
trunk_dev

enforcement:
active

target:
refs/heads/trunk_dev

allowed merge methods:
squash only

required approving reviews:
0

required status checks:
none

required review-thread resolution:
true

extra approval for unattributed changes:
true

bypass actors:
none

current user can bypass:
never
```

Expected repository settings:

```text
allow squash merge:
true

auto-merge:
disabled

delete branch on merge:
disabled
```

OPENING LOCAL IDENTITY

Require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
8168e40dd6e4ad9891f11142d6613f887cdbff20

tree:
727fb0ecf94680b64fed5e1bb2bccecccde38e4d

sole parent:
deec37bf08fb903d8846aa2c3232aec52fa9866e

upstream:
origin/codex/rw0-b2-capability-semantics-v1

ahead/behind:
0/0

worktrees:
1

worktree/index:
clean

Git operation/lock:
none

repository residue:
none
```

Do not fetch tags.

NEW MERGE-GATE EVIDENCE ROOT

Create one short neutral root:

```text
/private/tmp/g18.XXXXXX
```

Requirements:

- operator-owned;
- non-symlink;
- mode `0700`;
- all temporary paths beneath this root;
- every Python process uses:
  - `python3 -B`;
  - `PYTHONDONTWRITEBYTECODE=1`;
  - a unique never-reused `PYTHONPYCACHEPREFIX` beneath G18;
- every pytest-visible path passes the owning privacy/path checker;
- retained files mode `0400`;
- retained directories mode `0700`;
- no special entry at closeout;
- self-excluding index created last.

Record every formal action with exact argv/action, environment, time, return
code, stdout/stderr identity, and before/after repository/ref fingerprints.

LIVE PREFLIGHT

Before merge:

1. verify authenticated GitHub identity;

2. verify origin URL;

3. fetch exactly and only:
   - `refs/heads/trunk_dev`;
   - `refs/heads/codex/rw0-b2-capability-semantics-v1`;
   without tags;

4. require remote refs:

   ```text
   trunk_dev:
   deec37bf08fb903d8846aa2c3232aec52fa9866e

   feature:
   8168e40dd6e4ad9891f11142d6613f887cdbff20
   ```

5. verify local opening identity remains exact;

6. fetch and retain the complete live PR metadata;

7. require exact PR base/head/title/body/commit/file count;

8. inspect all reviews, requested reviewers, issue comments, review comments,
   review threads, checks, workflows, and commit statuses;

9. inspect the active ruleset and repository merge settings;

10. stop before merge if:
    - base or head changed;
    - PR is draft, closed, merged, or unmergeable;
    - merge state is not clean;
    - a review requests changes;
    - a material unresolved comment/thread exists;
    - a required check or approval is missing;
    - the ruleset no longer permits squash;
    - an extra commit or file exists;
    - remote/local identity differs.

No bypass may be used.

ACCEPTED EVIDENCE RECHECK

Read-only verify:

```text
G17 evidence index:
6efad76370b48e53f2e1b83f442355b5e955c2fbf2fd1c63e66d34ca57e6d941

commit:
8168e40dd6e4ad9891f11142d6613f887cdbff20

tree:
727fb0ecf94680b64fed5e1bb2bccecccde38e4d

parent:
deec37bf08fb903d8846aa2c3232aec52fa9866e

30 paths and committed blobs/modes:
exact
```

Do not rerun the complete suite before merge. The commit gate already executed
the staged collection and full suite exactly once.

MERGE COMMAND

Execute exactly once:

```text
gh pr merge 5 \
  --repo evo-agi/Governed-Execution-Coordinator \
  --squash \
  --match-head-commit 8168e40dd6e4ad9891f11142d6613f887cdbff20 \
  --subject "feat: implement RW0-B2 Capability semantics (#5)" \
  --body ""
```

No second merge attempt is authorized.

If the command fails:

- do not retry;
- preserve exact stdout/stderr/return code;
- inspect live PR/ref state read-only;
- stop.

VERIFIED SQUASH COMMIT

After a successful command, obtain the squash commit OID from live PR/event/ref
state.

Require:

```text
tree:
727fb0ecf94680b64fed5e1bb2bccecccde38e4d

sole parent:
deec37bf08fb903d8846aa2c3232aec52fa9866e

subject:
feat: implement RW0-B2 Capability semantics (#5)

body:
empty

GitHub signature:
verified, reason valid
```

Require:

- exactly one PR merge event;
- the event references the squash commit;
- the feature commit is not treated as a merge parent;
- all 30 squash-commit blobs and modes equal the accepted feature tree;
- shape remains 24 modifications and 6 additions.

REMOTE TRANSITION

Require:

```text
remote trunk_dev:
deec37bf... -> <squash OID>

remote feature:
8168e40d... -> 8168e40d...
```

Require PR #5:

```text
closed
merged
merge commit == squash OID
base == trunk_dev
head == feature branch
```

Do not delete the feature ref.

LOCAL SYNCHRONIZATION

Execute exactly:

1. one no-tags fetch of remote `trunk_dev` and the feature ref;

2. switch to the existing local `trunk_dev`;

3. run:

   ```text
   git merge --ff-only origin/trunk_dev
   ```

Do not reset, rebase, or merge the feature branch locally.

Require:

```text
local trunk_dev == remote trunk_dev == squash OID

local trunk_dev upstream:
origin/trunk_dev

divergence:
0/0

local and remote feature refs:
8168e40dd6e4ad9891f11142d6613f887cdbff20

worktree/index:
clean

one worktree
```

POST-MERGE FOCUSED VALIDATION

Run exactly one focused pytest invocation on synchronized local `trunk_dev`.

Files:

```text
tests/test_architecture_contracts.py
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_section41_pre_execution_plan_disposition_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_worker_execution_semantic_values.py
```

Environment:

```text
umask 022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
unique never-reused G18 PYTHONPYCACHEPREFIX
unique G18 TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error -q
unique G18 --basetemp
unique G18 --junitxml
serial execution
```

Do not predeclare the exact count. Report the collected and passed count.

Require:

```text
return code 0
all collected tests passed
0 failures/errors/skips/xfails/xpasses/warnings
empty stderr
parseable JUnit
zero duplicate/unmapped cases
caller/child umask 0022
repository/ref/index/tree unchanged before/after
```

Do not run the full 5,059-test suite again.

FINAL GUARDS

Require:

- PR #5 is merged exactly once;
- squash commit parent/tree/subject/body/signature exact;
- remote and local `trunk_dev` synchronized;
- remote base moved only by the squash commit;
- feature refs retained;
- worktree/index clean;
- no Git operation, lock, cache, bytecode, database, journal, archive, build,
  recorder, or generated-manifest residue;
- no auto-merge, review, thread-resolution, branch deletion, tag, release, or
  deployment effect;
- G17 and prior accepted evidence roots unchanged;
- focused validation ran exactly once.

CLOSEOUT

Retain:

```text
opening local identity
live PR preflight
ruleset/repository policy
reviews/comments/threads/checks/workflows/statuses
accepted commit/tree/blob verification
exact merge command and result
squash commit/event/ref verification
remote transition
local synchronization
focused validation
final guards
cleanup
complete inline report
```

Remove only G18-created transient validation paths after retaining records.

Seal G18:

```text
directories mode 0700
files mode 0400
no special entries
self-excluding canonical JSONL index
external read-only index verification
```

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_ASSURANCE_RESET_SQUASH_MERGED_AND_VERIFIED
```

only if merge, verification, local sync, focused validation, and closeout all
succeed.

FAILURE TOKENS

Use one exact primary token:

```text
MERGE_GATE_OPENING_IDENTITY_MISMATCH
MERGE_GATE_LIVE_PR_CHANGED
MERGE_GATE_POLICY_BLOCKED
MERGE_GATE_EVIDENCE_MISMATCH
MERGE_GATE_MERGE_FAILED
MERGE_GATE_SQUASH_VERIFICATION_FAILED
MERGE_GATE_REMOTE_TRANSITION_FAILED
MERGE_GATE_LOCAL_SYNC_FAILED
MERGE_GATE_FOCUSED_VALIDATION_FAILED
MERGE_GATE_CLOSEOUT_FAILED
```

For failure, print the complete operative diagnosis inline and state the exact
local/remote/PR state. Do not retry the merge.

FINAL INLINE REPORT

Use:

```text
# Outcome

# Accepted identities

# Opening local identity

# Live PR and policy preflight

# Merge command

# Verified squash commit

# Per-path blob and mode verification

# Remote transition

# Local synchronization

# Focused validation

# Final guards

# Evidence index

# Limitations and confidence
```

Required final statements:

```text
IMPLEMENTATION_REPAIR_NOT_PERFORMED
DIRECT_TRUNK_PUSH_NOT_PERFORMED
BYPASS_NOT_USED
FORCE_PUSH_NOT_PERFORMED
SECOND_COMMIT_NOT_PERFORMED
AMEND_NOT_PERFORMED
REBASE_NOT_PERFORMED
SECOND_MERGE_ATTEMPT_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
REVIEW_NOT_SUBMITTED
THREAD_NOT_RESOLVED
FEATURE_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
CAPABILITY_RUNTIME_IMPLEMENTATION_NOT_PERFORMED
```
