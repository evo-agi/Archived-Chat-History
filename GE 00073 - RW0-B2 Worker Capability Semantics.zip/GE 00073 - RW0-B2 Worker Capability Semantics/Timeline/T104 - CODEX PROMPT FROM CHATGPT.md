PROMPT_ID

RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_AUDIT_FINDINGS_REPAIR_CLOSEOUT_RECOVERY_V1

TITLE

Coordinator RW0-B2-Capability — recover the complete immutable closeout report
for the owner-oracle-reset audit-findings repair

ENGAGEMENT TYPE

Read-only report and provenance recovery in the existing write-enabled
Capability implementation conversation.

The preceding response returned only:

COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

The token alone is not a complete audit handoff. Recover and emit the exact
closeout report and retained evidence that support it.

Do not edit repository files. Do not rerun implementation. Do not rerun pytest,
node collection, cleanup, or mutation probes. Do not stage, commit, push, open
a PR, merge, tag, release, deploy, contact a remote, invoke a product
worker/model/provider, inspect another repository, or alter prior evidence.

If mandatory retained evidence is unavailable, stop with the exact token:

REPORT_EVIDENCE_INCOMPLETE

Do not regenerate missing validation evidence.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED REPOSITORY IDENTITY

Require the unchanged implementation branch and base:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

topology:
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644
```

Stop with:

REPORT_PROVENANCE_MISMATCH

if live identity or topology differs from the bytes that produced the success
token.

OPENING REPAIR TARGET

The repair began from this exact candidate:

```text
canonical manifest:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB/final_recipe_1/manifest.json

canonical-manifest SHA-256:
47ec8ecbd89aaa0924dc3d222f2292b9046d0faaabfadd4850411473aa33f51c

complete recipe-output SHA-256:
3777b40b27cc2e13513eb08c02d77064feea6263cfc56691517531cd0d4b39b7

tracked textual-diff SHA-256:
614568d397cf4eee772a25d588e31008731b326d7ac04988084018fcfc4da9aa

opening pytest nodes:
5002

opening ordered-node-list SHA-256:
11b13eebe8ff9631071da1f83a85d342b83ea4754a2c3765c0c227bf18f97a49
```

LATEST INDEPENDENT AUDIT

The repair answered findings from:

```text
root:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3

report:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3/audit_report.md

self-excluding index:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3/evidence_index.jsonl

index rows excluding itself:
71

index SHA-256:
26b69c39d083cd2096c8e2b47c6afbef7626d24cbd55093fcabe659be23a06bb
```

The four repaired findings were:

```text
B1-PARSER-001
B1-LOCATION-002
RW0-TEST-003
EVID-RENAME-004
```

EXACT AUTHORIZED REPOSITORY DELTA

Only these two paths were authorized to change from the opening repair target:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The other 28 candidate entries must remain byte-, type-, kind-, mode-, size-,
and classification-identical.

No path may become newly dirty or cease being dirty.

RETAINED EVIDENCE ROOT

Locate the new repair evidence root created by the implementation turn. Do not
guess its path. Derive it from retained conversation state or implementation
records.

Safely `lstat` every path component before reading it.

Report:

- absolute root path;
- owner/group/mode;
- symlink posture;
- retained file and directory counts;
- self-excluding evidence-index path;
- evidence-index row count, size, and SHA-256;
- whether every indexed entry verifies;
- whether retained files are regular, operator-owned, and mode 0400;
- whether any symlink, FIFO, socket, device, or unsafe entry exists.

Mandatory retained records include:

```text
final report
final canonical manifest
both final recipe outputs
aggregate identities
opening and final node lists
node delta
selected red/control evidence
focused validation summaries and JUnit
full-suite summary and JUnit
B1 parser-equivalence results
B1 bounded-H2 causal records
RW0 fence real/sensitivity ledger
corrected migration ledger
rename verification
final guards
cleanup record
```

If any mandatory record is missing or unsafe, return:

REPORT_EVIDENCE_INCOMPLETE

Do not recreate it.

PROVENANCE RECOVERY

Recover and report:

- exact retained recipe source path;
- recipe ID;
- recipe size;
- recipe SHA-256;
- final canonical-manifest path;
- final canonical-manifest byte size;
- final canonical-manifest SHA-256;
- final tracked textual-diff SHA-256;
- final complete recipe-output byte size;
- final complete-output SHA-256;
- file count;
- exact complete canonical manifest JSON.

Do not modify the recipe.

If the retained final recipe runs already prove byte-identical output, verify
those records. Do not rerun the recipe unless the implementation turn already
authorized and retained a read-only closeout rerun whose behavior can be
reproduced without touching candidate or prior evidence bytes.

EXACT TWO-PATH DELTA

Compare the opening target with the final target.

For each authorized path report:

- opening kind/type/mode/size/SHA-256;
- final kind/type/mode/size/SHA-256.

List the other 28 entries and prove they are exact.

Prove:

- no third repair path changed;
- no thirty-first path exists;
- no dirty path became clean;
- no mode, symlink, addition/deletion/rename/copy classification drift occurred.

FINDING-CLOSURE REPORT

For each finding report exact source/test/evidence closure.

### B1-PARSER-001

Report:

- the canonical B1 parser owner;
- how the cross-document projection test reuses it;
- exact import mechanism;
- proof of no copied fallback grammar;
- proof of no circular import, duplicate collection, or order sensitivity;
- bounded corpus equivalence results;
- fenced and commented earlier-H2 behavior through both primary and cross paths;
- exact finite diagnostics.

### B1-LOCATION-002

Report:

- exact bounded H2 recognizer;
- raw-line and visibility ordering;
- results for:
  - 0-space earlier H2;
  - 1-space earlier H2;
  - 2-space earlier H2;
  - 3-space earlier H2;
  - tab-delimited earlier H2;
  - four-space non-heading;
  - NBSP non-delimiter;
  - H3;
  - ordinary prose;
  - fenced H2;
  - commented H2;
- causal broken-control evidence.

### RW0-TEST-003

Report the complete fence-case causal ledger:

```text
case ID
document SHA-256
family
expected real result
actual real result
sensitivity mutant
expected mutated result
actual mutated result
diagnostic
```

Cover:

```text
valid closer before registry
invalid/non-closing closer before registry
non-opener before registry

backtick and tilde
run lengths
0–3 indentation
same/longer closer
opposite marker
shorter closer
ASCII suffix
text suffix
NBSP/EM SPACE suffix
four-space closer
unclosed fence
backtick info containing backtick
short opener
```

Prove registry visibility is the only deciding predicate. Prove all-visible,
closer-suppression, invalid-closer-as-valid, and overbroad-opener mutants are
killed.

### EVID-RENAME-004

Report the corrected external migration ledger and exact sole rename:

```text
old_node_id:
tests/test_rw0_b1_boundaries.py::test_owner_has_one_current_retrieval_maximum_and_one_current_consumer

new_node_id:
tests/test_rw0_b1_boundaries.py::test_b1_live_registry_projection
```

Prove:

- old appears exactly once opening and zero times final;
- new appears zero times opening and exactly once final;
- new appears exactly once among additions;
- one rename record targets new;
- no shared rename endpoints;
- every opening owner node has exactly one migration record;
- arithmetic reconciles.

Report the ledger path, size, SHA-256, and reconciliation-record identity.

B1 HYGIENE OBSERVATION

State whether the three formerly unused constants were removed or used
causally. Report exact path/lines and why no volume-only assertion was added.

TEST-FIRST AND DEVELOPMENT CHRONOLOGY

Report every attempt in exact order:

- opening provenance reproduction;
- opening collection;
- selected red/control gate;
- all developmental runs;
- final selected causal;
- final B1 owner;
- final RW0 owner;
- final B1 compatibility;
- final Capability/Wire compatibility;
- final architecture/status/static compatibility;
- final collection;
- full-suite attempts;
- final guards;
- cleanup;
- final double provenance.

For each attempt report:

```text
label
exact argv
environment
Python identity
caller/child umask
start/end/duration
return code
collected/passed/failed/error/skipped/xfail/warning counts
stdout size/SHA-256
stderr size/SHA-256
JUnit size/SHA-256
duplicate/unmapped cases
before/after candidate fingerprint
credit classification
```

Do not omit failed or superseded attempts.

NODE IDENTITY AND MIGRATION

Report:

- opening 5,002 node list path and hash;
- final node count and ordered-list hash;
- retained intersection;
- removals;
- additions;
- renames;
- additions by file;
- removals by file/category;
- outside-owner relative-order result;
- complete corrected migration ledger;
- any new nodes added by this repair;
- any nodes removed/renamed by this repair;
- proof of no unlisted loss or reparameterization.

Do not assume the final count equals 5,002. Report the literal result.

FULL-SUITE RESULT

Report:

- successful attempt number;
- whether another attempt ran;
- exact command;
- duration;
- collected/passed counts;
- failures/errors/skips/xfails/warnings;
- stderr;
- JUnit identity and mapping;
- final-byte fingerprint binding.

FINAL GUARDS

Report:

- `git diff --check`;
- status/topology/name-status/mode checks;
- protected-file comparison;
- package/export/import/public-caller checks;
- operation/lock checks;
- residue checks;
- evidence-root preservation;
- latest-audit evidence preservation;
- cleanup performed.

AUTHORITY AND NONCLAIMS

Confirm explicitly:

- no documentation changed in this repair;
- no production source changed;
- registry facts and authority ownership remain unchanged;
- no schema, migration, SQL, dependency, package export, `StateStore`,
  `WriterSession`, process, provider, network, Git, publication, or runtime
  authority widened;
- B1, Wire, and Capability remain private pure semantics;
- C/D/E and ES seams remain later/external owners.

OUTPUT

Return a complete report headed exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

The report must contain enough exact evidence to construct the next independent
audit prompt.

End with:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
