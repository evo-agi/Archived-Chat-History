PROMPT_ID

RW0_B2_CAPABILITY_G7_G6_TRANSIENT_BASETEMP_QUARANTINE_AMENDMENT_V1

TITLE

Coordinator RW0-B2-Capability — resume the stable G7 replay with a bounded,
source-derived quarantine for G6’s uncleaned pytest basetemp trees

ENGAGEMENT TYPE

Continuation in the same write-enabled Capability implementation conversation
that returned:

```text
STABLE_REPLAY_INPUT_INCOMPLETE
```

No G7 root was created. No candidate validation launched. Source repository,
G6, and all prior evidence remain unchanged.

This prompt amends only the treatment of the historical failed G6 replay root
inside the previously issued stable-provenance replay. All other requirements
of:

```text
RW0_B2_CAPABILITY_FINAL_REPAIR_COMPLETE_VALIDATION_REPLAY_V2_STABLE_PROVENANCE
```

remain in force.

Do not edit, delete, move, chmod, clean, or index G6. Do not modify repository
bytes. Do not treat this amendment as permission to exclude arbitrary unsafe
entries or arbitrary transient-looking directories.

DECISION

Yes: proceed by excluding only the exact documented G6 pytest basetemp trees
from G6’s canonical retained-evidence projection.

This is a historical-projection quarantine, not deletion, cleanup, repair,
validation credit, or a general unsafe-entry waiver.

G6 remains:

```text
historical failed replay
not authoritative for final validation or closeout
preserved byte-for-byte and path-for-path
not repaired
not resumed
not indexed retroactively
```

G7 remains the required new authoritative validation and closeout envelope.

HISTORICAL G6 ROOT

```text
/private/tmp/g6.4101bd
```

Known G6 condition:

```text
cleanup never ran
1152 symlinks
12 FIFOs
unsafe entries reported beneath uncleaned pytest basetemp trees
attempt 0182 stopped during evidence closeout
attempt 0183 is incomplete and noncreditable
```

AUTHORIZED EXCLUSION SOURCE

The exclusion roots must be derived mechanically and exclusively from retained
G6 attempt evidence.

Procedure:

1. Read the retained G6 `attempt_manifest.jsonl` and every complete attempt
   envelope.

2. For every launched pytest attempt, parse the exact argv array.

3. Extract only the absolute path supplied as:

   ```text
   --basetemp <path>
   ```

   or:

   ```text
   --basetemp=<path>
   ```

4. Normalize only lexical `.` and `..` components. Do not resolve symlinks.

5. Require every extracted path to:

   - be absolute;
   - be strictly beneath `/private/tmp/g6.4101bd`;
   - be a real directory under `lstat`;
   - not itself be a symlink;
   - correspond to exactly one retained attempt label/sequence, or have an
     explicit finite list of attempt labels when deliberately reused;
   - be unique after lexical normalization.

6. The quarantine root set is exactly the unique extracted basetemp paths.

Do not derive exclusions from:

```text
name patterns
directory age
file type alone
presence of symlinks/FIFOs
size
location outside retained argv
a guessed pytest directory layout
```

No `TMPDIR`, `PYTHONPYCACHEPREFIX`, external repository, evidence, output,
JUnit, fingerprint, report, or arbitrary scratch directory is excluded unless
it is itself the exact retained `--basetemp` argument of a launched pytest
attempt.

UNSAFE-ENTRY BOUNDARY PROOF

Before creating G7:

1. Inventory every G6 entry with `lstat`, without following symlinks or opening
   FIFOs.

2. Enumerate every symlink, FIFO, socket, device, or other special entry.

3. Require every unsafe entry to be a strict descendant of exactly one
   mechanically derived basetemp root.

4. Require zero unsafe entries outside the quarantine roots.

5. Require no quarantine root to overlap another except by exact equality,
   which must already have been deduplicated.

6. Require no quarantine root to be:
   - `/private/tmp/g6.4101bd` itself;
   - an ancestor of `a/`, the attempt-envelope root;
   - an ancestor of any retained report, manifest, recipe, fingerprint,
     mutation source, stdout, stderr, JUnit, node list, ledger, guard, or
     provenance record.

7. Parse every complete attempt envelope and mandatory G6 record. Require that
   no mandatory retained evidence path lies inside a quarantine root.

8. If any unsafe entry is outside the derived roots, or any mandatory record is
   inside a derived root, stop with:

   ```text
   STABLE_REPLAY_G6_TRANSIENT_BOUNDARY_FAILED
   ```

Do not widen the root set.

QUARANTINE INVENTORY

Create a read-only G7 record:

```text
g6_quarantine_inventory.jsonl
```

For every quarantined root record:

```text
relative root path
source attempt sequence(s)
source attempt label(s)
exact argv SHA-256
exact --basetemp token/value
root type/owner/group/mode
descendant counts by:
  directory
  regular file
  symlink
  FIFO
  socket
  block device
  character device
  other
total regular-file bytes
```

For every descendant record, using relative paths:

```text
relative path
quarantine root
type
owner UID/GID
mode
regular-file size or null
regular-file SHA-256 or null
symlink target string or null
```

Rules:

- use `lstat`;
- use `readlink` only for symlinks;
- never follow symlinks;
- never open/read FIFO, socket, or device content;
- directory size is always `null`;
- no atime, mtime, ctime, birthtime, inode, device number, link count, flags,
  or xattrs enter the canonical quarantine aggregate;
- sort by UTF-8 relative-path bytes.

Hash the complete canonical quarantine inventory and retain its row count,
byte size, and SHA-256.

This inventory is report-only historical quarantine evidence. It does not make
the contained unsafe nodes accepted retained evidence.

CANONICAL G6 RETAINED-EVIDENCE PROJECTION

Create one canonical G6 projection outside the quarantine roots.

Include every G6 path not strictly beneath a quarantine root.

Row schema:

```text
relative_path
type
owner_uid
owner_gid
mode
regular_file_size_or_null
regular_file_sha256_or_null
```

Rules:

- directories use null size/hash;
- regular files use exact size/SHA-256;
- no symlink or special entry may remain outside quarantine;
- use one implementation and identical schema at opening and closeout;
- sort by UTF-8 relative-path bytes;
- record row count, byte size, and SHA-256.

Require:

```text
opening retained projection == closing retained projection
opening quarantine inventory == closing quarantine inventory
```

Both comparisons use the same code and schema.

Do not compare G6 directory `st_size` or observation metadata.

G6 HISTORICAL CLASSIFICATION

The final G7 report must state:

```text
G6 cleanup never ran because the replay stopped before cleanup.
G6’s exact pytest basetemp roots were derived from retained launched argv.
Unsafe entries were confined to those roots.
No mandatory retained G6 evidence was inside the quarantined roots.
The roots were excluded only from the historical retained-evidence projection.
G6 was not modified, cleaned, repaired, resumed, or granted validation credit.
G7 is the authoritative complete validation and closeout envelope.
```

Do not state that G6 is “safe” as a whole. State that its retained evidence
outside the quarantined transient roots was projected and verified safely.

G7 REPLAY CONTINUATION

After the G6 boundary proof passes:

1. Create a new root:

   ```text
   /private/tmp/g7.XXXXXX
   ```

2. Execute the complete stable-provenance replay exactly as previously
   instructed.

3. Use:

   - the canonical content-stable evidence comparison for indexed historical
     roots;
   - the bounded G6 retained projection plus quarantine inventory defined in
     this amendment;
   - the normalized authoritative Git provenance model;
   - the unconditional all-attempt recorder;
   - the complete causal, focused, A/B/C, collection, live-suite, clean-suite,
     guard, cleanup, provenance, report, and index sequence.

4. Do not omit, shorten, or credit G6 validation because of this amendment.

5. Do not reuse any partial G7 root. The previous attempt created none.

OPENING/CLOSEOUT CONTINUITY FOR G6

At G7 opening retain:

```text
derived quarantine-root ledger
quarantine inventory
retained-evidence projection
unsafe-entry boundary proof
mandatory-evidence non-overlap proof
```

At G7 closeout rerun the same derivation from the unchanged G6 attempt
envelopes and compare:

```text
quarantine-root ledger equality
quarantine inventory equality
retained-evidence projection equality
unsafe-entry boundary result equality
mandatory-evidence non-overlap result equality
```

Any difference stops with:

```text
STABLE_REPLAY_EVIDENCE_CONTENT_DRIFT
```

Do not delete or normalize the G6 transients.

FAILURE TOKENS

In addition to the previously defined stable-replay failure tokens, use:

```text
STABLE_REPLAY_G6_TRANSIENT_BOUNDARY_FAILED
STABLE_REPLAY_G6_QUARANTINE_INVENTORY_FAILED
```

Do not create G7 validation records if the boundary proof fails before G7 root
creation. A small separate diagnostic record is permitted under one neutral
mode-0700 root.

SUCCESS TOKEN

The success token remains exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

It may be issued only after the entire G7 replay and closeout succeeds.

REQUIRED FINAL STATEMENTS

The previously required final statements remain unchanged, including:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
IMPLEMENTATION_NOT_RERUN
HISTORICAL_METADATA_NOT_RECONSTRUCTED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
