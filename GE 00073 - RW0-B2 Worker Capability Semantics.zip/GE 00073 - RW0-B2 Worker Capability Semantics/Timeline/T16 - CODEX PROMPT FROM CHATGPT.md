TITLE

Coordinator RW0-B2-Wire — implement the accepted private wire protocol,
worker-result relations, source claims, and pure process/result classifier

SUPERSESSION

This is the complete authoritative RW0-B2-Wire implementation prompt. It
supersedes any earlier unexecuted RW0-B2-Wire implementation draft. Do not
combine prompt fragments.

ENGAGEMENT TYPE

Bounded parent-only repository implementation in the existing RW0-B2 Codex
conversation.

Permission is workspace-write.

Do not create or resume subagents. You are the sole repository writer. The
read-only reconnaissance and schema-freeze turns are complete.

This is not an independent audit, commit gate, publication gate, Capability
implementation, process proof, or remote-host proof.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Implement the accepted `RW0-B2-Wire` contract as a private, deterministic,
no-I/O source layer and exact governing/contract-test surface.

The tranche makes locally observable:

- one canonical command-frame encoder/decoder carrying exact existing
  `WorkerCommandV1` and `DeliveryEnvelopeV1` records;
- one canonical worker-result-frame encoder/decoder carrying the frozen closed
  tuple of worker-authored `WorkerObservationV1` records;
- two safe, unauthenticated source-claim value families for:
  - cancellation request issuance;
  - resource-limit or signal process evidence;
- exact pure relations over supplied C2A objects and actual fences;
- one pure process/result classifier;
- one fixed safe Wire protocol profile mapping/ref/digest;
- finite content-free errors and exact hostile-input bounds.

The tranche implements no:

- source authentication;
- permission, acceptance, launch authority, or durable truth;
- process, worker, Codex, provider, CLI, App Server, credential, session,
  transport, host, filesystem, database, network, Git, Bridge, ES, or
  publication effect;
- RW0-C persistence, receipt, evidence membership, recovery, terminal fact, or
  acceptance-latch behavior;
- RW0-D/E concrete request delivery, process targeting, invocation, process
  mechanics, or proof;
- Capability declaration, observation, qualification, or implementation.

The provider-neutral Capability seam remains bounded but unimplemented.

OPENING BASELINE

Before any branch or file mutation, require exactly:

- physical root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- branch:
  `trunk_dev`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- subject:
  `feat: implement RW0-B1 pure phase-entry semantics (#3)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- worktree/index/untracked/unmerged:
  clean
- no Git operation or lock
- no repository-local cache, bytecode, database, journal, build, archive, or
  generated-manifest residue.

Do not fetch or contact a remote.

Stop on mismatch. Do not repair, reset, clean, switch away from unrelated work,
or absorb another branch.

FEATURE BRANCH

After the opening baseline passes:

1. require that local branch
   `codex/rw0-b2-wire-protocol-v1`
   does not already exist;
2. create it from the exact pinned HEAD;
3. set its upstream locally to `origin/trunk_dev` without remote contact;
4. require HEAD/tree/parent remain the pinned baseline;
5. require status remains clean.

No second branch is authorized.

ACCEPTED CONTRACTS AND INVARIANTS

Preserve byte-for-byte:

- all C2A classes, fields, schema IDs, digest domains, enums, canonical bytes,
  vectors, and six owning relations;
- all RW0-B1 classes, fields, schema IDs, digest domains, enums, relations,
  bounds, privacy rules, tests, and documentation;
- C2B3D and Section 41 identities and behavior;
- package-root exports and public protocols;
- dependencies and `pyproject.toml`;
- SQL, migrations, application generation, schemas, `StateStore`, and
  `WriterSession`;
- current production callers.

The dependency direction is:

```text
_rw0_wire_protocol_values.py -> existing private C2A semantic values/relations
```

Wire must not import B1. B1 and existing production modules must not import
Wire. No package-root export or production caller is permitted.

EXACT MAXIMUM TOUCHED-FILE ALLOWLIST

Exactly these 16 paths may become dirty:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

Expected final topology:

- 16 dirty paths;
- 10 tracked modifications;
- 6 untracked additions;
- 0 staged;
- 0 unmerged;
- every candidate path a regular mode-0644 file;
- no add/delete/rename/copy/mode/symlink drift beyond the six named untracked
  additions.

A seventeenth path is a mandatory stop. Do not hide imports, dynamically load a
module, weaken a static inventory, or alter an unrelated test to stay within
scope.

PROTECTED SURFACES

Explicitly protected from any byte change:

- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py`;
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`;
- every direct C2A and B1 test/vector;
- `src/ge_nwp_coordinator/__init__.py`;
- all row-value, SQLite, migration, transaction, writer-session, schema, package,
  fixture, script, config, and dependency files;
- every path outside the 16-path allowlist.

IMPLEMENTATION MODULE

Create:

```text
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
```

Required source order:

1. module docstring stating private/no-I/O/non-authority posture;
2. standard-library imports only;
3. precise direct imports from existing private C2A semantic values/relations;
4. `__all__: tuple[str, ...] = ()`;
5. fixed schema/domain/profile/frame/cap/privacy/field/enum/reason constants;
6. sealed error class;
7. exact scalar/privacy/canonicalization/parser/work helpers;
8. `RW0WireCancellationRequestObservationV1`;
9. `RW0WireProcessObservationV1`;
10. `RW0WireWorkerResultV1`;
11. `RW0WireProcessResultClassificationV1`;
12. fixed profile mapping;
13. value relations;
14. result relation;
15. command/result encoders and decoders;
16. process/result classifier.

Forbidden imports include filesystem, process, database, socket, network,
environment, provider, model, Bridge, ES, and public package modules. No ambient
clock or environment access is allowed.

Follow the repository's controlled custom slotted immutable-value idiom. Do not
use a mutable dataclass, `NamedTuple`, arbitrary caller mapping as encoder input,
or a generic helper module.

COMMON VALUE RULES

Every B2 value class must:

- be final, slotted, immutable, and non-pickleable;
- reject subclassing;
- have constant content-free `repr` and `str`;
- require exact built-in external types;
- defensively reconstruct immutable stored values;
- provide fresh safe `to_mapping()`;
- use a fixed ordered `_FIELDS` tuple;
- suppress foreign exception chains;
- echo no supplied value in an error;
- use exact C2A safe-ref syntax and forbidden prefixes;
- additionally reject IPv4-shaped refs;
- reject raw or disguised private material.

Locally reproduce—not import from B1—the private-key fragments:

```text
hostname
host_key
ip_address
endpoint
username
bearer
token
secret
signature
trust_root
prompt
transcript
stdout
stderr
provider
environment_value
absolute_path
workspace_path
store_path
```

Unknown-key handling:

1. exact built-in `dict` only;
2. perform an O(1) cardinality preflight before scanning keys;
3. permit scanning at most `_FIELDS` length plus one key;
4. a mapping larger than that fails `invalid_length_or_cardinality` before key
   iteration;
5. within the bounded scan, a private-fragment unknown key fails
   `privacy_forbidden_material`;
6. another unknown key fails `unknown_field`;
7. missing fields are checked afterward.

This preserves bounded direct construction while ensuring every isolated
private-key mutant receives the privacy reason.

Self-digest values must expose:

- `identity_mapping()`;
- canonical identity bytes;
- `computed_digest()`;
- exact validation of the caller-supplied final digest.

Canonical identity bytes are compact sorted-key UTF-8 JSON with
`ensure_ascii=False`, `allow_nan=False`, separators `(",", ":")`, and no Unicode
normalization. A self-digest is:

```text
SHA256(digest_domain UTF-8 || NUL || canonical identity bytes)
```

SAFE SCALARS

Use exact local validation compatible with C2A:

- `R`: exact string, 1–96 ASCII safe-ref syntax and forbidden-prefix rules,
  plus IPv4-shaped rejection;
- `H`: exact string, 64 lowercase hexadecimal characters;
- `T`: exact whole-second UTC `YYYY-MM-DDTHH:MM:SSZ`;
- framed integer:
  exact built-in `int`, not `bool` or subclass, owning lower bound respected,
  and no greater than `9_223_372_036_854_775_807`.

The integer cap is B2 Wire representability only. It does not modify C2A/B1,
grant allocation or transport permission, or become a `CeilingsV1` field.

SEALED ERROR ALGEBRA

Implement private sealed `RW0WireProtocolError`.

It exposes only closed `.reason`; `str`/`repr` are constant; foreign chains are
suppressed.

Decoder reasons, in exact priority order:

```text
invalid_outer_type
short_header
bad_magic
unsupported_version
unsupported_kind
declared_length_over_cap
truncated_payload
trailing_data
invalid_utf8
bom_forbidden
json_token_invalid
duplicate_key
invalid_root_or_scalar
unknown_field
missing_field
nested_record_invalid
noncanonical_payload
relation_mismatch
work_limit_exceeded
```

Construction/relation reasons:

```text
invalid_field_type
invalid_field_value
unknown_field
missing_field
invalid_length_or_cardinality
digest_mismatch
privacy_forbidden_material
relation_mismatch
```

Do not include a supplied key, value, path, JSON fragment, ref, digest, or
exception text in any error.

VALUE 1 — CANCELLATION REQUEST OBSERVATION

Class:

```text
RW0WireCancellationRequestObservationV1
```

Schema ID:

```text
governed-execution.nwp-rw0-wire-cancellation-request-observation.v1
```

Digest domain:

```text
governed-execution.nwp-rw0-wire-cancellation-request-observation.v1.identity
```

Exact ordered fields:

```text
schema_id
request_observation_ref
source_kind
source_ref
source_invocation_ref
evidence_ref
evidence_digest
program_ref
program_version_ref
accepted_intent_revision_ref
work_item_ref
work_item_revision_ref
semantic_attempt_ref
candidate_ref
command_ref
command_digest
attempt_fence_ref
attempt_fence_digest
cancellation_effect_intent_ref
cancellation_effect_fence_ref
cancellation_effect_fence_digest
cancellation_delivery_attempt_ref
cancellation_delivery_envelope_digest
target_effect_intent_ref
target_effect_fence_ref
target_effect_fence_digest
target_delivery_attempt_ref
target_delivery_envelope_digest
observed_at
request_observation_digest
```

Exact enum:

```text
source_kind = supervisor | execution_substrate
```

The final field is the sole self-digest.

`command_ref`/`command_digest` are the originating author-command lineage. Do
not mint a cancellation command identity.

No physical target process invocation field exists. `source_invocation_ref`
identifies the source invocation claiming to have issued the request. The
semantic target is the exact target effect/fence and known target delivery.

Required route/source relation:

```text
cancellation_delivery.adapter_kind == direct_local_bootstrap
    -> request.source_kind == supervisor

cancellation_delivery.adapter_kind == execution_substrate
    -> request.source_kind == execution_substrate
```

The request is source evidence only. It does not prove request delivery,
acknowledgement, rejection, signal, exit, teardown, reconciliation, semantic
cancellation, permission, or acceptance.

VALUE 2 — PROCESS OBSERVATION

Class:

```text
RW0WireProcessObservationV1
```

Schema ID:

```text
governed-execution.nwp-rw0-wire-process-observation.v1
```

Digest domain:

```text
governed-execution.nwp-rw0-wire-process-observation.v1.identity
```

Exact ordered fields:

```text
schema_id
process_observation_ref
source_kind
source_ref
source_invocation_ref
evidence_ref
evidence_digest
event_kind
program_ref
program_version_ref
accepted_intent_revision_ref
work_item_ref
work_item_revision_ref
semantic_attempt_ref
candidate_ref
command_ref
command_digest
attempt_fence_ref
attempt_fence_digest
effect_intent_ref
effect_fence_ref
effect_fence_digest
delivery_attempt_ref
delivery_envelope_digest
observed_at
process_observation_digest
```

Exact enums:

```text
source_kind = supervisor | operating_system
event_kind  = resource_limit_exceeded | signal_delivered
```

The final field is the sole self-digest.

No signal number, resource measurement, PID, host, path, endpoint, handle,
credential, bearer, log, stdout, stderr, provider, or session field exists.

VALUE 3 — WORKER RESULT

Class:

```text
RW0WireWorkerResultV1
```

Stored field:

```text
observations: exact tuple[WorkerObservationV1, ...]
```

It has no schema field, semantic ref, or self-digest. Header version/kind select
the payload schema.

Allowed tuples only:

```text
(worker_started, worker_completed)
(worker_started, candidate_captured, worker_completed)
```

Every observation must have:

- exact `source_kind=worker`;
- one common `source_ref`;
- one common `source_invocation_ref`;
- unique observation refs;
- unique observation digests;
- exact common command, delivery, program, version, intent, work, attempt,
  effect, attempt-fence, and effect-fence coordinates;
- a capture observation that binds the preassigned candidate;
- successful applicable existing C2A observation relations using separately
  supplied actual fences.

Tuple position is protocol order. Timestamps do not establish order.

VALUE 4 — CLASSIFICATION RESULT

Class:

```text
RW0WireProcessResultClassificationV1
```

Fields:

```text
classification
reason
```

It has no schema field, semantic ref, or self-digest.

Exact classifications:

```text
usable | unusable | invalid
```

Exact reasons:

```text
usable
invalid_input
unrelated_fact
duplicate_fact
conflicting_fact
cancellation_graph_mismatch
resource_limit_exceeded
deadline_elapsed
signal_delivered
cancellation_request_pending
cancellation_acknowledged
cancellation_rejected
process_result_contradiction
process_failed
result_missing
result_invalid
process_evidence_incomplete
```

Enforce the exact closed classification/reason matrix.

PUBLIC-IN-MODULE PRIVATE FUNCTIONS

Implement these exact signatures in substance. Keyword-only boundaries must be
preserved where shown.

```text
wire_profile_mapping() -> dict[str, object]

encode_wire_command_frame(
    *, command: WorkerCommandV1, delivery: DeliveryEnvelopeV1,
    attempt_fence: AttemptFenceV1, author_effect_fence: EffectFenceV1
) -> bytes

decode_wire_command_frame(
    frame: bytes, *, attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1
) -> tuple[WorkerCommandV1, DeliveryEnvelopeV1]

encode_wire_result_frame(
    *, result: RW0WireWorkerResultV1, command: WorkerCommandV1,
    delivery: DeliveryEnvelopeV1, attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1
) -> bytes

decode_wire_result_frame(
    frame: bytes, *, command: WorkerCommandV1,
    delivery: DeliveryEnvelopeV1, attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1
) -> RW0WireWorkerResultV1

validate_wire_result_relation(
    *, result: RW0WireWorkerResultV1, command: WorkerCommandV1,
    delivery: DeliveryEnvelopeV1, attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1
) -> None

validate_wire_cancellation_request_relation(
    *, request: RW0WireCancellationRequestObservationV1,
    author_command: WorkerCommandV1, attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1,
    target_effect_fence: EffectFenceV1,
    target_delivery: DeliveryEnvelopeV1,
    cancellation_effect_fence: EffectFenceV1,
    cancellation_delivery: DeliveryEnvelopeV1
) -> None

validate_wire_process_observation_relation(
    *, observation: RW0WireProcessObservationV1,
    author_command: WorkerCommandV1, attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1,
    target_effect_fence: EffectFenceV1,
    target_delivery: DeliveryEnvelopeV1
) -> None

classify_wire_process_result(
    *, command: WorkerCommandV1, delivery: DeliveryEnvelopeV1,
    attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1,
    result: RW0WireWorkerResultV1 | None,
    result_failure: RW0WireProtocolError | None,
    adapter_observations: tuple[WorkerObservationV1, ...],
    request: RW0WireCancellationRequestObservationV1 | None,
    process_observations: tuple[RW0WireProcessObservationV1, ...],
    cancellation_effect_fence: EffectFenceV1 | None,
    cancellation_delivery: DeliveryEnvelopeV1 | None
) -> RW0WireProcessResultClassificationV1
```

RELATIONS

Cancellation request relation:

- validate exact types and self-digest;
- validate target delivery/effect via existing C2A relation;
- validate cancellation delivery/cancel effect via existing C2A relation with
  the exact target effect fence supplied as cancellation target;
- require cancel effect class;
- require the cancel fence's immutable target tuple to equal the supplied
  target effect identity;
- bind every exposed program/version/intent/work/attempt/candidate/command/fence
  coordinate;
- bind request cancellation-delivery and target-delivery refs/digests;
- enforce route/source ownership above;
- treat source/evidence/invocation/timestamp as safe claim shape only.

A C2A acknowledgement or rejection may have adapter source kind/ref/invocation
different from the request source. Match request and response through the exact
cancellation graph, never source equality.

Process observation relation:

- validate exact types and self-digest;
- validate target delivery/effect relation;
- bind every safe target lineage coordinate;
- validate event/source/evidence/timestamp shape;
- infer no source authenticity, process action, semantic result, permission, or
  acceptance.

Result relation:

- validate exact result type and closed sequence;
- validate all shared coordinates;
- validate unique refs/digests;
- validate capture candidate;
- call applicable existing C2A observation relations with actual supplied
  fences;
- infer no process success or semantic decision.

FRAME AND PAYLOAD

Header is exactly eight bytes:

```text
offset  size  meaning
0       4     b"NWPF"
4       1     version 0x01
5       1     kind: 0x01 command | 0x02 worker_result
6       2     unsigned payload length, big-endian
```

Exactly one frame is accepted.

Command payload:

```json
{"command":<complete WorkerCommandV1 mapping>,"delivery":<complete DeliveryEnvelopeV1 mapping>}
```

Worker-result payload:

```json
{"observations":[<complete WorkerObservationV1 mappings>]}
```

No outer or root schema ID, ref, digest, checksum, signature, or competing
semantic identity is added.

Exact caps:

```text
max framed integer             9_223_372_036_854_775_807
command payload bytes          5_898
worker-result payload bytes    16_627
command/result whole frame     5_906 / 16_635
command/result depth           3 / 4
command/result containers      5 / 8
command/result key pairs       71 / 77
command/result scalar leaves   70 / 169
command/result hostile units   23_746 / 66_770
```

Reject a declared over-kind-cap length before payload slicing, allocation,
UTF-8 decoding, or JSON parsing.

CANONICAL JSON AND HOSTILE DECODING

Encoder input is exact constructed C2A/B2 objects and exact tuples only. Do not
accept arbitrary mappings.

Decoder input is exact built-in `bytes`.

Require:

- strict UTF-8;
- no BOM;
- one exact root object;
- duplicate-key tracking before ordinary dict construction;
- parse the bounded JSON document completely; a syntax/token failure outranks a
  duplicate observed earlier in an unfinished document;
- floats/constants rejected;
- integer digit/range validation before Python integer construction;
- exact built-in object/list/string/int/null types;
- no Unicode normalization;
- `ensure_ascii=False`;
- `allow_nan=False`;
- `sort_keys=True`;
- separators `(",", ":")`;
- canonical re-encoding equal byte-for-byte to the payload;
- no alternate whitespace, key order, number spelling, or escape spelling.

Exact decoder priority is the listed decoder error order.

Use the work meter as deterministic bounded accounting over attacker-controlled
variation:

```text
8 header units
+ 4 units per payload byte
+ 1 per parsed key pair
+ 1 per parsed container
+ 1 per parsed scalar leaf
```

The four payload passes are:

```text
utf8_decode
json_tokenize
canonical_reencode
canonical_compare
```

Depth counts object/list containers, root depth 1. A container list member is
charged as a container only. Scalar elements of evidence/path lists count as
scalar leaves.

Payload caps already bound physical parse work. `work_limit_exceeded` is for an
otherwise admissible operation whose private test-injected accounting exceeds
the exact limit; it must not mask an earlier syntax/structure error.

Encoder exact-object boundaries reject mapping/alias/cycle attempts by type.
Decoder JSON is a fresh tree. Fixed closed relation loops are mandatory but not
misrepresented as attacker-expandable graph work.

PROCESS/RESULT CLASSIFIER

Accepted existing adapter observation kinds are exactly:

```text
cancellation_acknowledged
cancellation_rejected
deadline_elapsed
process_exited
```

At most one of each. The three delivery-outcome kinds are not classifier facts.

Other cardinalities:

```text
worker result observations  0..3 under the closed result grammar
request                     0..1
process observations        0..2, one per event kind
total supplied fact units   at most 10
```

Reject before traversal:

- excess cardinality;
- duplicate refs/digests;
- repeated kinds;
- unrelated lineages;
- contradictory facts.

Acknowledgement and rejection are mutually exclusive and require one matching
request through the exact cancellation graph. They do not need equal source
kind/ref/invocation.

Exact precedence:

1. invalid type/cardinality, duplicate, unrelated lineage, graph mismatch, or
   contradiction -> `invalid` with the exact matching reason; tie order:
   `invalid_input`, `duplicate_fact`, `unrelated_fact`, `conflicting_fact`,
   `cancellation_graph_mismatch`;
2. resource supplement ->
   `unusable/resource_limit_exceeded`;
3. deadline observation ->
   `unusable/deadline_elapsed`;
4. signal supplement ->
   `unusable/signal_delivered`;
5. matching request plus acknowledgement ->
   `unusable/cancellation_acknowledged`;
6. matching request plus rejection ->
   `unusable/cancellation_rejected`;
7. matching request alone ->
   `unusable/cancellation_request_pending`;
8. response without request ->
   `invalid/cancellation_graph_mismatch`;
9. both responses ->
   `invalid/conflicting_fact`;
10. nonzero exit plus valid result ->
    `unusable/process_result_contradiction`;
11. nonzero exit without valid result ->
    `unusable/process_failed`;
12. exit zero plus no result ->
    `unusable/result_missing`;
13. result decoder/relation failure after higher conditions ->
    `unusable/result_invalid`;
14. valid result with no process exit ->
    `unusable/process_evidence_incomplete`;
15. valid related result plus exactly one exit code zero and no higher
    condition ->
    `usable/usable`.

C2A owns only exit-code range `-255..255`. B2 alone treats exact zero as
successful exit for this classifier.

No request/response/signal/exit/result implies teardown, reconciliation,
semantic cancellation, B1 terminal outcome, C2B decision, RW0-C durable fact,
permission, or acceptance.

FIXED WIRE PROFILE

Constants:

```text
profile_ref:
  rw0-wire-nwpf-v1

profile schema:
  governed-execution.nwp-rw0-wire-protocol-profile.v1

digest domain:
  governed-execution.nwp-rw0-wire-protocol-profile.v1.identity

canonical identity byte length:
  4_021

profile digest:
  470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
```

`wire_profile_mapping()` returns a fresh safe projection ordered:

```text
schema_id
profile_ref
manifest
profile_digest
```

The complete canonical identity mapping—excluding `profile_digest`—is exactly:

```json
{"manifest":{"authority":{"acceptance":false,"mechanism_neutral":true,"permission":false,"profile_in_frame":false,"provider_neutral":true},"classifier":{"ack_reject_exclusive":true,"adapter_kinds":["cancellation_acknowledged","cancellation_rejected","deadline_elapsed","process_exited"],"classifications":["usable","unusable","invalid"],"exit_success_code":0,"max_adapter_facts":4,"max_process_facts":2,"max_request_facts":1,"max_total_facts":10,"max_worker_result_facts":3,"precedence":[["invalid_input","duplicate_fact","unrelated_fact","conflicting_fact","cancellation_graph_mismatch"],["resource_limit_exceeded"],["deadline_elapsed"],["signal_delivered"],["cancellation_acknowledged","cancellation_rejected","cancellation_request_pending"],["process_result_contradiction","process_failed"],["result_missing","result_invalid"],["process_evidence_incomplete"],["usable"]],"reasons":["usable","invalid_input","unrelated_fact","duplicate_fact","conflicting_fact","cancellation_graph_mismatch","resource_limit_exceeded","deadline_elapsed","signal_delivered","cancellation_request_pending","cancellation_acknowledged","cancellation_rejected","process_result_contradiction","process_failed","result_missing","result_invalid","process_evidence_incomplete"],"response_requires_request":true},"decoder_errors":["invalid_outer_type","short_header","bad_magic","unsupported_version","unsupported_kind","declared_length_over_cap","truncated_payload","trailing_data","invalid_utf8","bom_forbidden","json_token_invalid","duplicate_key","invalid_root_or_scalar","unknown_field","missing_field","nested_record_invalid","noncanonical_payload","relation_mismatch","work_limit_exceeded"],"frame":{"header":[["magic",0,4],["version",4,1],["kind",5,1],["payload_length",6,2]],"kinds":{"command":1,"worker_result":2},"length_encoding":"uint16-big-endian","magic":"NWPF","one_frame":true,"semantic_identity":false,"version":1},"integer":{"json":"unsigned_decimal_no_sign_or_leading_zero","lower_bound":"owning_field","maximum":9223372036854775807,"preconversion_bounded":true,"type":"exact_builtin_int"},"json":{"allow_nan":false,"bom":false,"canonical_reencode_equals_payload":true,"constants":false,"duplicate_keys":false,"ensure_ascii":false,"floats":false,"normalization":"none","separators":[",",":"],"sort_keys":true,"utf8":"strict"},"payloads":{"command":{"max_bytes":5898,"max_containers":5,"max_depth":3,"max_hostile_units":23746,"max_key_pairs":71,"max_scalar_leaves":70,"records":["WorkerCommandV1","DeliveryEnvelopeV1"],"root_keys":["command","delivery"]},"worker_result":{"max_bytes":16627,"max_containers":8,"max_depth":4,"max_hostile_units":66770,"max_key_pairs":77,"max_scalar_leaves":169,"records":["WorkerObservationV1"],"root_keys":["observations"]}},"process":{"digest_domain":"governed-execution.nwp-rw0-wire-process-observation.v1.identity","event_kinds":["resource_limit_exceeded","signal_delivered"],"schema_id":"governed-execution.nwp-rw0-wire-process-observation.v1","source_authenticity":false,"source_kinds":["supervisor","operating_system"]},"request":{"digest_domain":"governed-execution.nwp-rw0-wire-cancellation-request-observation.v1.identity","schema_id":"governed-execution.nwp-rw0-wire-cancellation-request-observation.v1","source_authenticity":false,"source_kinds":["supervisor","execution_substrate"],"target":"author_candidate"},"result":{"graph":"supplied_exact_fences","order":"tuple","same_source_invocation_ref":true,"same_source_ref":true,"sequences":[["worker_started","worker_completed"],["worker_started","candidate_captured","worker_completed"]],"source_kind":"worker","unique_digests":true,"unique_refs":true},"work":{"classifier_fact":1,"container":1,"container_list_member":"container_only","fixed_closed_relations":"unmetered","header_byte":1,"key_pair":1,"payload_byte_per_pass":1,"payload_passes":["utf8_decode","json_tokenize","canonical_reencode","canonical_compare"],"scalar_leaf":1}},"profile_ref":"rw0-wire-nwpf-v1","schema_id":"governed-execution.nwp-rw0-wire-protocol-profile.v1"}
```

The digest is:

```text
SHA256(
  b"governed-execution.nwp-rw0-wire-protocol-profile.v1.identity"
  || NUL
  || canonical identity bytes
)
```

Tests must independently calculate the length and digest from a literal
test-owned mapping. Do not import production profile constants to construct the
expected mapping.

The profile is absent from frames and proves no source authenticity, permission,
acceptance, or mechanism selection.

DOCUMENTATION AND STATUS

Create `.docs/rw0-b2-wire-protocol.md` as the sole detailed Wire semantic owner.
It must contain:

- current-versus-target status;
- exact values, fields, enums, domains, functions, frame diagrams, payload
  shapes, caps, work accounting, error precedence, relations, classifier,
  profile mapping/digest, privacy exclusions, route neutrality, later-owner
  seams, and nonclaims;
- explicit statement that this source tranche is private/no-I/O and implements
  no contact, process, persistence, authority, acceptance, or Capability.

Add one uniquely marked, visible, unfenced current-status cross-reference to
each existing allowed documentation owner:

```text
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
```

Use the same normalized compact projection and markers:

```text
RW0_B2_WIRE_CURRENT_STATUS_BEGIN
RW0_B2_WIRE_CURRENT_STATUS_END
```

The projection must state:

- private Wire framing/codec/result/source-claim/classifier semantics are now
  implemented;
- the fixed profile ref/digest;
- B1 remains unchanged;
- no worker/process/contact/persistence/authority/acceptance/Codex mechanism is
  implemented;
- Capability remains seam-bounded and unimplemented;
- RW0-C/D/E and ES retain their respective ownership.

Do not rewrite historical tranche claims globally.

The owner and cross-reference contract tests must use visible Markdown
structure, not raw marker counting alone. Require:

- unique intended heading owner/range;
- one visible unfenced marker pair;
- all live prose within the pair;
- hidden/fenced duplicates ignored;
- duplicate visible blocks rejected;
- same-title sibling relocation rejected;
- leading/trailing visible prose outside markers rejected;
- backtick and tilde controls;
- no global `count`, `find`, `index`, or raw-regex owner extraction.

TEST OWNERSHIP

Create exactly:

```text
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

The tests—not production constants—must own literal expected:

- field tuples;
- schema IDs and domains;
- enums;
- profile identity mapping, length, and digest;
- header bytes;
- payload roots;
- caps, depth, container, key, scalar, and work formulas;
- decoder errors and precedence;
- classifier input kinds, cardinalities, classifications, reasons, and
  precedence;
- exact 16-path/static/public boundary.

Tests must include independently constructed fully related maximum command and
result fixtures and exact maximum/one-over vectors.

CAUSAL TEST REQUIREMENTS

Every negative mutant must:

- begin from a valid positive fixture;
- change one predicate only;
- keep non-target relations exact;
- reseal only the value that owns the changed self-digest;
- assert the intended validation stage/reason;
- include a local broken control where necessary to show the mutant would pass
  without the intended check.

Required coverage includes:

- every header byte/class, kind/version, cap+1, uint16 max, truncation, trailing
  byte, and concatenated frame;
- UTF-8/BOM, duplicate root and nested keys, float, exponent, leading zero,
  bool-as-int, oversized integer, whitespace, key order, and escape spelling;
- exact maximum and one-over depth/container/key/scalar/work;
- private injected work unit `23_747`, `66_771`, and eleventh classifier fact;
- every command/delivery coordinate;
- every result observation kind/order/count/source/invocation/lineage/fence/ref/
  digest/candidate coordinate;
- request supervisor/ES positive cases;
- adapter-as-request-author negatives;
- request/response differing source claims with exact graph;
- wrong cancel or target effect/fence/delivery;
- wrong immutable target;
- request absent, request only, each response, response without request, both
  responses;
- each process kind/source/lineage;
- zero/nonzero/missing/duplicate/conflicting exit;
- every classifier precedence pair;
- malformed/missing result beneath every higher process tier;
- IPv4-shaped ref mutations independently across both new ref-bearing classes;
- private-fragment unknown keys with content-free errors;
- profile manifest single-field mutations.

Static/boundary tests must prove:

- no I/O imports or calls;
- no dynamic imports;
- empty `__all__`;
- no package-root export;
- no production caller;
- Wire imports only exact allowed C2A module(s);
- no B1 import;
- package/dependency/schema/migration/public surfaces unchanged.

VALIDATION EVIDENCE ROOT

Create one external operator-owned non-symlink mode-0700 root under
`/private/tmp`.

All evidence files must be regular, operator-owned, and mode 0400 after
completion.

For every pytest child:

- capture and restore actual caller umask;
- require equal caller/child numerical umask;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`;
  - `LC_ALL=C`, `LANG=C`;
  - `PYTHONDONTWRITEBYTECODE=1`;
  - distinct external `PYTHONPYCACHEPREFIX`, `TMPDIR`, `--basetemp`, JUnit;
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
  - `PYTEST_ADDOPTS=''`;
  - `PYTHONHASHSEED=0`;
  - `python3 -B -m pytest -p no:cacheprovider -W error`;
  - serial execution.
- retain exact argv/environment, caller/child umask, start/end times, return
  code, stdout/stderr, JUnit, structured counts, and repository fingerprints
  before/after.

Never infer warnings, skips, failures, or errors from words inside node IDs or
test names. Parse structured JUnit and anchored pytest summaries.

OPENING EVIDENCE

Before editing:

1. collect the complete opening node list exactly once with isolated external
   paths;
2. run the exact provenance recipe below exactly twice against the clean feature
   branch;
3. require byte-identical opening stdout/manifests;
4. require file count zero and a clean tracked diff;
5. retain all records externally.

IMPLEMENTATION VALIDATION ORDER

After implementation and before the complete suite:

1. collect the candidate node list exactly once;
2. require:
   - every opening node remains;
   - opening relative order remains a subsequence;
   - no opening node was renamed or removed;
   - every addition belongs to exactly one of the four new Wire test files;
   - no duplicate node;
3. run each new Wire test file individually;
4. run all four Wire test files together;
5. run C2A compatibility:
   ```text
   tests/test_worker_execution_semantic_*.py
   tests/test_c2a_relations.py
   tests/test_c2a_first_slice_semantic_protocol_contract.py
   tests/test_c2a1_pure_semantic_values.py
   ```
6. run B1 compatibility:
   ```text
   tests/test_rw0_b1_*.py
   ```
7. run static/public/import boundaries:
   ```text
   tests/test_c2a_nonimplementation.py
   tests/test_runtime_non_authority.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_b2a_writer_session_contract.py
   tests/test_codex_agent_config.py
   ```
8. run status/document compatibility:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```
   `test_remote_worker_pre_execution_planning_contract.py` is validation-only
   and must remain byte-identical because it is outside the allowlist.
9. run `git diff --check`;
10. verify exact path/mode/topology/public/import/protected-byte/residue/operation/
    lock guards.

Every focused run must be exact-green with zero failures, errors, skips, xfails,
warnings, JUnit parse errors, duplicate cases, or unmapped cases.

COMPLETE SUITE POLICY

After all focused gates are green and candidate bytes are frozen, run the
complete repository suite as attempt 001 exactly once.

If attempt 001 is green, do not rerun it.

If attempt 001 fails:

- preserve all attempt-001 evidence;
- repair only when every failure is demonstrably caused by this candidate,
  requires changes solely within the exact 16-path allowlist, does not alter the
  frozen Wire contract/profile/caps/ownership, and does not weaken a test;
- after such a repair, rerun all affected focused gates and candidate collection;
- then run one final complete-suite attempt 002 exactly once.

Stop without further mutation when:

- a seventeenth path is required;
- a C2A/B1/public/schema/dependency/runtime change is required;
- a contract/profile/cap/ownership decision must change;
- a failure is unrelated or cannot be causally classified;
- attempt 002 would be required after attempt 002;
- a test must be skipped, xfailed, renamed, deleted, or weakened.

FINAL PROVENANCE

After the final complete suite is green and cleanup is complete:

1. require exact final topology `16 / 10 / 6 / 0 / 0`;
2. run the exact recipe twice;
3. require byte-identical stdout and canonical manifests;
4. require exactly the 16 allowlisted paths and no other entry;
5. retain recipe source, source hash, complete outputs, stderr, manifests,
   tracked-diff hash, file count, and per-file path/kind/type/mode/size/SHA-256;
6. prove every protected path equals HEAD;
7. verify no repository residue, Git operation, or lock.

EXACT PROVENANCE RECIPE

Recipe ID:

```text
governed-execution.audit-patch-manifest.v1
```

Exact source size:

```text
3_945 bytes
```

Exact source SHA-256:

```text
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Exact source, base64:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

Decode the source only into the external evidence root, verify its bytes/hash,
and keep it mode 0400.

The exact source historically writes:

```text
/tmp/ge-coordinator-b3a-audit-manifest-v1.json
```

Do not overwrite pre-existing evidence at that path. Execute the exact source
bytes unchanged while an external wrapper redirects only that exact
`Path.write_bytes` sink to a unique file under the current evidence root.
Do not alter Git reads, canonicalization, stdout, stderr, or recipe source.

Run it twice at opening and twice at final closeout.

ARTIFACT HYGIENE

Remove only activity-created transient pycache, pytest cache, basetemp,
temporary databases, journals, WAL/SHM files, and recorder scratch after
retaining terminal evidence.

Do not delete or rewrite pre-existing external evidence.

No generated artifact may remain in the repository.

STOP CONDITIONS

Stop immediately and report the exact state if:

- opening identity or clean baseline differs;
- the feature branch already exists;
- any required owning C2A field/relation is absent;
- implementation needs a B1/C2A change;
- the corrected request source ownership cannot be implemented exactly;
- profile identity is not exactly 4,021 bytes and the pinned digest;
- payload, structural, or work maxima do not reproduce;
- an outer competing semantic identity is needed;
- raw/private/provider/credential/host/process material would enter a value or
  frame;
- source evidence would become authenticity, authority, acceptance, or durable
  truth;
- CLI/App Server or a concrete provider mechanism would be selected;
- a path outside the 16-path allowlist changes;
- a protected byte, export, dependency, schema, migration, public protocol, or
  production caller changes;
- node removals/renames or collection-control weakening occurs;
- validation cannot pass without weakening tests;
- final provenance is unstable or scope differs.

CLOSEOUT

Return exactly:

```text
COORDINATOR_RW0_B2_WIRE_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT
```

only if:

- all implementation requirements are met;
- final candidate is exact-green;
- final topology and provenance are exact;
- no stop condition fired.

The report must include:

1. opening baseline and branch creation;
2. files touched with classification and summary;
3. exact implemented values/functions/profile;
4. ownership, privacy, non-authority, and later-owner treatment;
5. opening/final node counts and literal delta;
6. every validation command, exact result, evidence identity, and any failed
   attempt;
7. final path/mode/protected/public/import/artifact guards;
8. recipe source identity, tracked-diff SHA-256, canonical-manifest SHA-256,
   complete-output SHA-256, file count, and complete canonical manifest;
9. assumptions, unresolved later seams, and uninspected areas;
10. separate confidence for provenance, validation, and implementation.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
```
