PROMPT_ID

RW0_B2_CAPABILITY_G6_EVIDENCE_CLOSE_G5_MUTATION_DIAGNOSTIC_V1

TITLE

Coordinator RW0-B2-Capability — diagnose the `evidence_close_g5`
source-mutation stop without rerunning validation

ENGAGEMENT TYPE

Read-only diagnostic in the same write-enabled Capability conversation that
returned:

```text
COMPLETE_REPLAY_SOURCE_MUTATION_DETECTED
```

and stopped at:

```text
evidence_close_g5
```

Failure envelope:

```text
/private/tmp/g6.4101bd/a/0182/envelope.json
```

No repository mutation, pytest, node collection, mutation probe, A/B/C replay,
full-suite rerun, cleanup rerun, provenance rerun, staging, commit, push, PR,
remote contact, provider invocation, or supporting-repository inspection is
authorized.

Do not alter:

```text
/Users/ds/Repositories/Governed Execution Coordinator/

/private/tmp/g5.hiLE2y

/private/tmp/g6.4101bd
```

Read-only Git and filesystem inspection is authorized.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED SOURCE REPOSITORY IDENTITY

Require and report:

```text
branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

topology:
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
```

The preceding failure report states:

```text
repository was not modified
no suite reran after failure
success token not issued
```

G5 HISTORICAL EVIDENCE ROOT

```text
/private/tmp/g5.hiLE2y
```

Expected self-excluding index:

```text
/private/tmp/g5.hiLE2y/evidence_index.jsonl

rows excluding itself:
7234

size:
1583837 bytes

SHA-256:
199af9ac4299cc41a4434d44f1b1f7bcaf3265490b7417e174ad5d48723f8fcc
```

G6 REPLAY ROOT

```text
/private/tmp/g6.4101bd
```

Failure envelope:

```text
/private/tmp/g6.4101bd/a/0182/envelope.json
```

OBJECTIVE

Identify exactly what `evidence_close_g5` classified as a source mutation and
whether it is:

1. real byte/type/mode/ownership/path-set drift in `/private/tmp/g5.hiLE2y`;

2. observation-only metadata change caused by read access, such as `atime`;

3. metadata that cannot change merely by reading and therefore indicates a
   real write, such as content, size, mode, owner, path set, `mtime`, `ctime`,
   inode, xattrs, or symlink target;

4. a mismatch between two fingerprint schemas;

5. an audit-wrapper or comparison defect;

6. live repository/index/object-database drift;

7. an incomplete G6 evidence envelope.

Do not answer only with the previous failure token.

MANDATORY PROCEDURE

## 1. Inspect the failure envelope

Read and report every field from:

```text
/private/tmp/g6.4101bd/a/0182/envelope.json
```

Identify:

```text
attempt label
purpose
expected outcome
actual outcome
command or procedural action
return code / signal
stdout/stderr identities
pre-fingerprint path and SHA-256
post-fingerprint path and SHA-256
candidate-mutated flag
notes
first failed assertion
```

Follow every referenced record in that envelope.

## 2. Recover the exact G5 opening and closing fingerprints

Locate through the G6 all-attempt manifest and indexed records:

```text
G5 opening fingerprint
G5 closing fingerprint
comparison record
comparison implementation/source
```

Report exact paths, modes, sizes, SHA-256 values, and whether each record is
indexed by G6.

## 3. Field-by-field G5 comparison

Compare opening versus closing by these categories:

### Stable identity fields

```text
path set
relative paths
file/directory type
symlink/special-file posture
owner UID/GID
mode
regular-file byte size
regular-file SHA-256
directory inventory
index path/type/mode/size/SHA-256
self-exclusion
inode/device
link count
flags
xattrs
mtime
ctime
birthtime
```

### Observation-sensitive fields

```text
atime
directory atime
filesystem access counters, if any
```

For every unequal field report:

```text
relative path
field name
opening value
closing value
whether a read can cause the change
whether bytes changed
whether retained evidence validity changed
```

Do not group differences without listing them.

## 4. Independently verify G5 content identity now

Without mutating G5:

1. verify the self-excluding index hash, row count, and size;

2. verify every indexed path by:
   - path;
   - type;
   - owner/group;
   - mode;
   - size;
   - SHA-256 for regular files;

3. identify unindexed entries, missing entries, or changed indexed entries;

4. compare the current verified inventory with the G6 opening inventory using
   only content-stable fields;

5. report whether G5 bytes and path identities are still exact.

Do not rewrite or regenerate the G5 index.

## 5. Inspect the G6 comparison implementation

Inspect the exact source/helper used by `evidence_close_g5`.

Report whether it:

```text
includes atime in an equality fingerprint
mixes opening and closing schemas
uses stat versus lstat inconsistently
follows symlinks
normalizes modes or owners differently
includes audit-created access effects
has nondeterministic ordering
compares an index-containing inventory with a self-excluding inventory
```

If the comparison is stricter than the retained evidence contract, identify the
exact overreach.

## 6. Verify source repository invariance

Read-only verify:

```text
branch/HEAD/tree/upstream/divergence
porcelain v2 status
tracked binary diff SHA-256
cached diff SHA-256
real index identity
candidate canonical manifest
candidate per-path identities
outside-candidate equality to HEAD
source object-database inventory
operations/locks/residue
```

Compare with the G6 opening records.

## 7. Determine G6 replay completion state

From `attempt_manifest.jsonl` and all envelopes, report which replay phases
completed before attempt 0182:

```text
bootstrap
recorder self-test
opening gate
recipe-copy preflight
opening recipe runs
causal mutation replay
focused groups
A/B/C replay
live collection
clean collection
node reconciliation
live full suite
clean full suite
guards
cleanup
final provenance
final report generation
index creation
external index verification
```

For every completed phase report whether its envelope is complete and indexed.

Identify the first phase not completed solely because of the G5 close check.

## 8. Determine whether continuation can be evidence-only

A continuation is evidence-only only if:

```text
source repository bytes/index/objects are unchanged
G5 path/content/type/mode/owner/index are unchanged
only observation-sensitive metadata changed, or comparison logic was defective
all validation/replay attempts before 0182 have complete envelopes
no pytest or mutation result is missing
no final candidate fingerprint is missing
```

If those conditions hold, specify exactly which remaining closeout actions may
run without repeating validation.

READ-ONLY DERIVATION RULES

May be derived read-only:

```text
a corrected G5 content-stable comparison
an aggregate diagnostic report
a continuation plan
```

May not be fabricated:

```text
missing attempt envelope
missing pytest result
missing mutation result
missing run-local fingerprint
missing provenance run
```

PRIMARY CLASSIFICATION

Return exactly one primary token.

### G5_CONTENT_UNCHANGED_OBSERVATION_METADATA_ONLY

Use only when G5 indexed bytes, path set, types, owners, modes, sizes, and
hashes remain exact, and every mismatch is read-induced observation metadata
such as atime.

### G5_COMPARISON_WRAPPER_DEFECT

Use when G5 content is exact but the comparison used inconsistent schemas,
followed symlinks, included forbidden observation metadata, or otherwise
misclassified stable evidence.

### G5_REAL_EVIDENCE_DRIFT

Use when any indexed byte, path, type, owner, mode, size, SHA-256, mtime, ctime,
xattr, or other non-read-induced identity changed.

### SOURCE_REPOSITORY_DRIFT

Use when the live repository, real index, candidate bytes, refs, or source
object database differ from G6 opening.

### G6_REPLAY_EVIDENCE_INCOMPLETE

Use when the stop left missing validation or attempt evidence that cannot be
derived read-only.

### DIAGNOSTIC_INCOMPLETE

Use only when the first failed predicate cannot be identified safely.

CONTINUATION DISPOSITION

After the primary token, return exactly one:

```text
EVIDENCE_ONLY_CLOSEOUT_CONTINUATION_READY
CLOSEOUT_WRAPPER_REPAIR_CONTINUATION_READY
VALIDATION_REPLAY_RESTART_REQUIRED
IMPLEMENTATION_REPAIR_REQUIRED
PROVENANCE_BLOCKED
```

For either closeout-continuation result, list the exact remaining actions and
state explicitly that no pytest, mutation, A/B/C, node collection, or full
suite rerun is required.

REQUIRED QUESTIONS

Answer all:

1. What exact G5 path and field first differed?

2. Did any G5 regular-file SHA-256 change?

3. Did the G5 path set change?

4. Did mode, owner, size, mtime, or ctime change?

5. Was the difference limited to atime or another read-induced field?

6. Does the G5 self-excluding index still verify exactly?

7. Did the comparison helper include atime?

8. Did the source repository or real index change?

9. Did source loose-object inventory change?

10. Which G6 phases completed before attempt 0182?

11. Are all completed validation attempts fully enveloped?

12. Can the replay finish without rerunning tests?

13. What exact next prompt type is required?

CLOSEOUT

Verify this diagnostic does not change:

```text
source repository bytes/index/refs
G5
G6
```

Retain a small diagnostic root or record only if it does not alter G6’s
pre-indexed evidence. Prefer one new external mode-0700 diagnostic root with a
self-excluding index.

FINAL RESPONSE

Include:

1. primary classification token;
2. continuation disposition;
3. exact first mismatch;
4. complete unequal-field ledger;
5. independent G5 index verification;
6. comparison-helper assessment;
7. source-repository assessment;
8. G6 phase-completion ledger;
9. minimum next continuation;
10. provenance, validation-binding, and implementation confidence.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REAL_INDEX_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
NODE_COLLECTION_NOT_RUN
MUTATION_PROBES_NOT_RUN
THREE_STATE_SIMULATION_NOT_RUN
FULL_SUITE_NOT_RUN
CORRECTNESS_AUDIT_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
```
