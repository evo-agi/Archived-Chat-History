## Engineering disposition

**Split B2 into two ordered, non-colliding implementation tranches:**

1. **`RW0-B2-Wire`** — framing, hostile codec, worker-result grammar, and deterministic process/result precedence.
2. **`RW0-B2-Capability`** — provider-neutral Codex capability declaration, independent observation, and pure qualification.

Do not use `B2a`, `B2b`, or `B2c`; those labels already refer to older Coordinator writer/lock/session work.

This is not gate multiplication for its own sake. The capability contract must identify the exact wire/result protocol it claims to support, so Wire is a real prerequisite. Conversely, splitting framing from worker-result semantics would be artificial: both share one canonical byte grammar, one parser, one result-usability classifier, and one size/work proof.

The previous B2 reconnaissance prompt should not be forwarded. The replacement below supersedes it.

## 1. Exact B2 capability

### `RW0-B2-Wire`

The observable result is a **private, deterministic, no-I/O protocol layer** that:

- encodes and decodes exactly one command frame;
- encodes and decodes exactly one worker-result frame;
- reconstructs the nested committed C2A values exactly;
- returns either exact canonical bytes/values or a finite content-free failure;
- validates one closed worker-authored result sequence;
- classifies result usability against separately supplied process facts;
- performs no launch, persistence, authentication, permission grant, custody, or semantic decision.

The command frame should carry exactly:

```text
WorkerCommandV1
DeliveryEnvelopeV1
```

It should not carry a B1 value. B1 is a pre-launch Coordinator gate, not worker protocol payload. The command owns semantic command identity; the delivery envelope owns delivery and route correlation. Keeping both prevents the future adapter from inventing an out-of-band delivery identity.

The outer frame should have **no semantic identity and no in-band self-digest**. Magic, version, kind, and length are transport structure. Nested records retain their existing identities. A future owner may hash retained raw frame bytes as evidence, but that hash must not become command, delivery, observation, permission, or acceptance identity.

The worker-result target grammar is:

```text
worker_started
[candidate_captured]
worker_completed
```

with exact shared source-invocation, delivery, command, attempt, effect, fence, and candidate relations. It carries only existing `WorkerObservationV1` values authored by `source_kind="worker"`.

It must not carry:

- process exit, signal, deadline, or cancellation facts;
- adapter delivery outcome;
- capsule builder/store, validator, reviewer, model, or custodian facts;
- `RW0TerminalOutcomeV1`;
- a C2B decision;
- an RW0-C durable terminal fact;
- latch state.

A valid worker result remains evidence. It is not acceptance or executable authority.

### `RW0-B2-Capability`

The observable result is three distinct private value families:

1. a capability **declaration** by the candidate implementation/artifact owner;
2. an independent capability **observation**;
3. a deterministic Coordinator **qualification**.

Declaration cannot observe or qualify itself. Observation cannot qualify itself. Qualification authenticates no source and grants no authority.

The qualification should bind:

- the exact B2 command/result protocol profile and version;
- worker implementation/artifact identity;
- declared and observed noninteractive behavior;
- protocol-only bounded stdout;
- private diagnostic-stderr posture by safe profile identity;
- cancellation and deadline behavior;
- ephemeral-state/history posture;
- credential isolation;
- transcript/JSONL suppression or private handling;
- zero Git effects;
- network posture;
- observation freshness;
- a supplied positive B1 effect/host qualification and exact effect/fence identity.

B1 itself remains unchanged. Its accepted contract is private, pure, over supplied evidence, and grants no permission or contact capability. 

### Later owners

| Owner | What it consumes from B2 | What remains outside B2 |
|---|---|---|
| **RW0-C** | Safe frame/result identities, ingest classifications, protocol/capability evidence bindings | SQLite rows, receipts, evidence completeness, recovery, durable terminal fact, latch |
| **RW0-D** | Codec, result grammar, precedence, qualified capability profile | CLI/App Server selection, credentials, invocation, stdin/stdout/stderr plumbing, process/supervisor/worker, custody |
| **RW0-E** | Exact protocol and capability contracts | Live source authenticity and one-host proof |
| **ES** | Same nested C2A records and result grammar for conformance | ES transport wrapper, admission, submit, runtime, lifecycle, cancellation, retained results |

This is non-disposable: without B2, C and D would have to invent framing identity, malformed-output semantics, process/result precedence, and Codex capability meaning while simultaneously implementing persistence or I/O.

## 2. Why the split is necessary

B1’s implementation retained its high-level split, but the later audits found omissions across containment, lineage, retrieval sequencing, expiry, privacy, integer conversion, traversal budgets, and causal tests. That is evidence that **schema exhaustiveness is not semantic exhaustiveness**.

For B2, the two concerns have different risks:

| Concern | Principal risk |
|---|---|
| Wire/result | hostile parsing, canonical bytes, duplicate keys, size/depth/work bounds, identity collision, process/result contradiction |
| Capability | self-attestation, evidence becoming permission, mechanism selection by schema, stale observation, qualification precedence |

Capability also depends on an exact wire profile. A combined tranche would make capability tests depend on a parser still under design and would enlarge an already authority-sensitive audit surface. Wire first is therefore the smallest non-disposable sequence.

## 3. Codex mechanism ownership

The B1 owner’s wording that B2 owns “Codex mechanism” is interpreted narrowly and compatibly with RW0-A:

- **B2 owns:** mechanism-neutral capability contracts, wire-protocol compatibility, declaration/observation/qualification semantics, and safe profile identities.
- **RW0-D/E own:** CLI versus App Server, packaging, installation, credential delivery, provider/session handling, concrete invocation, process control, cancellation signaling, and offline/live proof.

No B1 byte should be reopened merely to restate this. The B2 governing contract should make the narrow interpretation explicit.

A concrete mechanism may be selected in B2 only if reconnaissance proves that an owning contract unambiguously requires an architecture revision. In that event the proper result is `RW0_B2_RECONNAISSANCE_BLOCKED`, not a silent `cli|app_server` enum.

## 4. Caps and bounds

No round-number limits are accepted by default.

| Limit | B2 decision | Derivation |
|---|---|---|
| Command payload | Exact largest valid canonical command-frame payload | Current C2A scalar/list bounds plus final B2 envelope |
| Result payload | Exact largest valid canonical result payload | Closed result sequence plus exact observation maxima |
| Observation count | Derived from result grammar | Three if the proposed start/optional-candidate/completion grammar survives source inspection |
| Nesting depth | Exact deepest valid payload graph | Static graph proof, not a generic “depth 8” |
| Declared frame length | Checked before allocation/read | Header range is distinct from per-kind valid maximum |
| Stderr/capture | **No B2 numeric limit** | B2 binds a private bounded-diagnostics profile; RW0-D owns the physical numeric ceiling |
| Cumulative work | Exact occurrence formula | Includes header, length check, UTF-8, duplicate detection, JSON, key scans, re-encoding, reconstruction, relations, helpers, aliases |

For each limit, the freeze must state:

- the protected action/resource;
- whether it is owner-derived, an exact representational maximum, new B2 defensive policy, or later-owner process policy;
- the largest valid record calculation;
- maximum and one-over vectors;
- whether it is identity-, decoder-, relation-, or process-affecting;
- why it grants no allocation, transport, launch, or retention authority.

The completed B1 contract demonstrates the needed discipline: traversal work is charged before descent, aliases are not free, and called helpers share one budget rather than resetting it. 

A practical process limit is not a new `CeilingsV1` field. A representational maximum is not permission to allocate or transmit that amount.

## 5. Pre-freeze contradiction matrix

| Challenge | Engineering resolution |
|---|---|
| Frame identity versus command/delivery identity | Outer frame has no semantic identity; nested records remain authoritative |
| Command-only versus command+delivery | Carry both; command-only would require invented out-of-band delivery correlation |
| B1 value in command frame | Excluded; B1 remains a pre-launch gate |
| Worker result versus `WorkerObservationV1` | Result envelope carries a closed ordered tuple of existing worker-authored observations |
| Worker result versus process facts | Process/deadline/signal/cancellation remain adapter/OS-owned and separately supplied |
| Worker result versus B1 terminal outcome/C2B decision/RW0-C terminal fact | Strictly distinct; result is evidence only |
| Exit/deadline/signal/cancel/malformed precedence | Process/resource facts override frame usability; zero exit never repairs missing or invalid protocol output |
| Declaration versus observation versus qualification | Three separate values and authors; no self-observation or self-qualification |
| Capability versus B1 qualification | B2 consumes supplied B1 qualification; it neither modifies nor partially reimplements B1 |
| Sensitive material | Raw stdout/stderr, prompts, transcripts, JSONL, sessions, credentials, endpoints, hosts, and private paths excluded |
| Direct-local versus ES | Same nested C2A records and result grammar; route-specific delivery kind and ES-owned outer wrapper/correlation may differ |
| Unicode | Preserve exact C2A code points; no Section 41 normalization |
| Duplicate/truncated/noncanonical/trailing frames | Fail closed with deterministic content-free decoder precedence |
| Late/duplicate/conflicting result evidence | B2 freezes structural classification; RW0-C later owns durable ingest/reconciliation |

Later-owner seams may remain open only where they do not invalidate B2’s own bytes, identities, grammar, or qualification semantics.

## 6. Prospective forecasts

1. **Most likely design blocker:** the exact largest-valid byte calculation will reveal at least one current C2A field whose finite byte maximum is not mechanically explicit, especially under worst-case UTF-8. If so, reconnaissance should return `PARTIAL` and identify the owning C2A decision rather than inventing a payload cap.

2. **Touched-file forecast:** one new private source module for Wire and one for Capability, with direct tests and existing source-inventory/public-boundary tests, should be sufficient. The most likely scope expansion is an existing static importer/source inventory or current-status contract test, as happened during B1.

3. **Likely audit findings:** parser error-precedence gaps, undercounted work before construction, noncausal duplicate-key or one-field mutants, worker/process fact collapse, or capability self-attestation. Architectural replanning is required—not an ordinary repair—if the frame needs raw WorkSpec/fence bytes, the result requires widening C2A source/observation enums, no finite maximum can be derived, or the capability schema must choose CLI/App Server or contain credentials/provider-session data.

## 7. Final disposition

**Proceed with the justified two-tranche B2 freeze reconnaissance.**

No implementation prompt should follow until both contracts are exact, even though Wire will be implemented first. The read-only exploration and later parent-only mutation remain separate turns, and independent audit remains a later fresh conversation. 

Send this **complete replacement prompt** to a new read-only Codex conversation:

:chatgpt-content-reference{index="3"}

The desired result is:

```text
RW0_B2_RECONNAISSANCE_READY
```

`READY` is prohibited unless both Wire and Capability have exact schemas, bytes, bounds, precedence, ownership, tests, files, and contradiction dispositions. Otherwise Codex must return `PARTIAL` or `BLOCKED`; it must not promote plausible limits or schemas into a freeze.

### Sources

- Latest Coordinator snapshot uploaded as the current repository baseline. 
- Accepted B1 scope: private pure values over supplied evidence, with no permission, contact, or durable state. 
- B1 relation completeness and bounded-work rules. 
- B1 consumer and B2/C/D/E ownership split. 
- Read-only reconnaissance, parent-only mutation, and separate independent audit workflow. 

**Confidence:** high that the Wire → Capability split is the smallest non-disposable decomposition; high that concrete CLI/App Server selection belongs in D/E; moderate that the current C2A bounds will be sufficient to derive exact payload maxima without an owning-contract amendment.
