## Engineering disposition

Proceed with **one read-only RW0-B2-Capability reconnaissance and exact schema-freeze engagement**. Do not issue an implementation prompt yet.

The merged and snapshot-validated Wire layer is now a stable dependency rather than an open design seam. The accepted order remains **Wire → Capability**: Capability must bind the accepted Wire profile, while concrete CLI/App Server selection stays with RW0-D/E. 

### Capability tranche boundary

The smallest non-disposable Capability result keeps three roles together:

1. **Declaration** by the candidate implementation or artifact owner.
2. **Independent observation** by a separate source.
3. **Pure Coordinator qualification** over the declaration, observation, accepted Wire profile, and the complete applicable B1 graph.

Splitting those roles into separate implementation tranches would leave the declaration or observation without the qualification relation that gives the contract practical meaning. Combining them with Wire or RW0-D/E would collapse representational semantics into process or provider mechanics.

The freeze must preserve these boundaries:

- exact binding to `rw0-wire-nwpf-v1` and its accepted digest;
- exact binding to the worker artifact pair;
- full composition with B1 phase, authority, readiness, effect-fence, host-qualification, head, stop, and time facts;
- no trust in a bare B1 `qualified` value;
- no self-observation or self-qualification;
- no source authentication, permission, acceptance, persistence, or contact;
- no provider, account, endpoint, session, credential, prompt, transcript, JSONL, stdout/stderr body, host, path, PID, or bearer material;
- no silent selection of Codex CLI, App Server, OpenAI, or another mechanism.

The earlier seam review already established that declaration, independent observation, and qualification can remain distinct; Capability may cover mechanism-neutral behavioral dimensions, while source proof, concrete invocation, credentials, provider sessions, and numeric process limits remain D/E responsibilities.  

### Main freeze risks

The likely blockers are no longer Wire framing. They are:

- defining structural observer independence without falsely claiming authentication;
- composing the complete B1 relation rather than reproducing an incomplete subset;
- separating mechanism-neutral capability postures from D/E-owned numeric and process policy;
- avoiding a second profile or identity that competes with the Wire profile or B1 worker artifact/protocol pairs;
- closing the current-status surface, because the Wire owner and synchronized projections presently say Capability is unimplemented;
- deriving traversal budgets and causal tests from exact fields instead of declaring a large test plan and assuming the schema is complete.

A read-only parent with bounded explorers is the correct posture for this architecture investigation and source/test impact mapping; no edits, tests, installation, staging, or live operations belong in this engagement. 

## Codex prompt

Send this complete prompt in a **new read-only Codex conversation**:

:chatgpt-content-reference{index="3"}

Verify the artifact:

```text
Filename:
Coordinator_RW0_B2_Capability_Reconnaissance_and_Schema_Freeze_Prompt.txt

Size:
25,193 bytes

SHA-256:
6b545a9df4ace58a7f71bb71ee637fdb013ff40b50631a37ff4b5f6306c06d5a
```

The prompt requires four read-only explorers covering:

- contract, authority, and full B1 composition;
- value identity, privacy, error algebra, and work bounds;
- provider/mechanism neutrality and the D/E seam;
- source, tests, status ownership, touched-file ceiling, validation, and provenance.

Its final Capability disposition must be exactly one of:

```text
RW0_B2_CAPABILITY_SCHEMA_FREEZE_READY
RW0_B2_CAPABILITY_SCHEMA_FREEZE_PARTIAL
RW0_B2_CAPABILITY_SCHEMA_FREEZE_BLOCKED
```

and its Wire disposition must be exactly one of:

```text
RW0_B2_WIRE_PROFILE_BINDING_CONFIRMED
RW0_B2_WIRE_PROFILE_BINDING_CONTRADICTION
```

`READY` requires exact classes, fields, schema IDs, digest domains, relations, result/reason precedence, freshness, bounds, errors, module/import direction, touched-file ceiling, tests, validation, provenance, audit perspectives, and stop conditions. It still must not issue an implementation prompt.

The prompt is bound to the reported live Git baseline:

```text
trunk_dev
HEAD deec37bf08fb903d8846aa2c3232aec52fa9866e
tree ef48f5bd11244c6f703c97abb5489d19956f7a77
parent 02450d3c99faf0fe7b299b914afaed312421bc8b
```

and requires Codex to verify that state locally without fetching. The committed content has already been re-grounded in the uploaded strategic snapshot, consistent with the project lifecycle’s requirement to re-establish repository truth at architecture checkpoints. 

### Sources

- :chatgpt-content-reference{index="4"}
- Accepted Wire-before-Capability decomposition and bounded Capability seam.  
- Read-only reconnaissance posture. 
- Strategic snapshot re-grounding lifecycle. 

**Confidence:** High in the tranche boundary and prompt scope; intentionally provisional on exact Capability fields, freshness grammar, reason precedence, and touched-file ceiling until Codex completes the source-grounded freeze.
