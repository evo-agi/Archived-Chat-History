## Engineering disposition

**G8 is sufficiently complete to support the fresh independent audit. Do not return to implementation or the commit gate yet.**

The replay now supplies the previously missing closure:

- every ordinary action is represented in a continuous 212-row attempt manifest;
- the three non-creditable tooling attempts—sequences 8, 9, and 11—occurred before candidate validation and have explicit credited recoveries at 10, 12, and 13;
- the restore harness was corrected and passed its static audit plus all seven tooling self-tests;
- every final causal mutant, protected-content mutation, stable-contract mutation, and A/B/C state check completed;
- live and clean collections match at **5,072 nodes**;
- the live and clean suites each passed **5,072/5,072**, exactly once;
- source authoritative identity, logical index, refs, reachable object graph, candidate tree, and topology remained stable;
- the G8 root has a complete self-excluding index and external verification;
- the complete operative report was provided inline rather than hidden behind `/private/tmp` links.

The three early tooling failures are not themselves blockers. The audit must verify that they occurred before candidate validation, caused no candidate or external-candidate mutation, and were fully superseded by the recorded recoveries.

## Fresh independent-audit handoff

Start a **new Codex conversation** in read-only posture and send this complete prompt:

:chatgpt-content-reference{index="0"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_G8_Final_Fresh_Independent_Audit_Prompt.txt

Size:
25,869 bytes

SHA-256:
ad951cd4346cc6dee063245262145350c09191252956c418c4df1013089a5154
```

The audit is bound to:

```text
Repository:
/Users/ds/Repositories/Governed Execution Coordinator/

Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Final candidate tree:
0fcf6680ded68d66f62b75b5dc842d69b343a334

Final canonical manifest:
d6f86248da0c4843e20b91cb443f960596e483e08a8f2cff716bbcea4fb553d8

Final textual diff:
cc91155aff703e1c54c139820f841d98135f37ee7c87a71d3b00b07a2672e2a6

Final node count:
5,072

Final node-list SHA-256:
f0faec3289ed635a741867bb2a655487f4a4a824dcf4cc0921c334beada1bbd3

G8 evidence root:
/private/tmp/g8.3cee3f

G8 evidence-index SHA-256:
f90d50dc17e95e432b6577cad99669777f99bcd2d6af7c42509d2987db8248fc
```

### What the audit must independently challenge

The prompt requires four bounded perspectives covering:

1. **Closed reachable-call enforcement**  
   It independently attacks constructed argv, shell strings, callable aliases, nested attributes, `getattr`, closures/defaults, dynamic imports, GitPython-like and dulwich-like calls, subprocess and `os.*` process APIs, unknown helpers, and module-global substitution.

2. **The literal 43-row boundary projection**  
   It verifies the 30 candidate-path rows, P01–P13 protected-content rows, non-circular literal expectations, unique ownership, dedicated diagnostics, and the exact P12 mutation that survived the prior audit.

3. **The corrected restore harness and state compatibility**  
   It verifies the normalized fingerprint schema, explicit logical-index comparison, report-only raw index handling, all seven restore-harness tests, the eight stable-contract mutants, and independent A/B/C state behavior.

4. **G8 chronology, validation, provenance, and authority**  
   It reconciles all 212 attempt records, examines the three non-creditable attempts and recoveries, verifies both 5,072-test suites, checks terminal index creation, independently collects nodes, and audits public/import/privacy/authority boundaries.

The prompt requires the core audit report **inline in chat**. Evidence paths may be supplementary only.

If source inspection and independent probes remain green, the auditor runs:

```text
Selected causal:
16 passed

Capability boundaries:
32 passed

Capability complete:
69 passed

B1/Wire compatibility:
461 passed

Architecture/status/static:
907 passed

Independent live suite:
5,072 / 5,072

Independent clean suite:
5,072 / 5,072
```

The only accepting outcome is:

```text
ACCEPT

COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Only that acceptance permits another commit/push/PR gate. No merge is authorized at this stage.

### Source

- Codex G8 final replay and inline closeout report supplied in this turn.

**Confidence:** High that G8 closes the validation and evidence deficiencies; commit readiness remains unresolved until the fresh independent auditor verifies the replay harness, causal tests, complete attempt chronology, dual-state suites, and exact provenance.
