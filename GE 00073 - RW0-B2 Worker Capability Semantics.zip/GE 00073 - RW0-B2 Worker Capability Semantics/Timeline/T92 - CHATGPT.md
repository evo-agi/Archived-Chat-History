## Disposition

`AUDIT_PROVENANCE_MISMATCH` is **not an implementation verdict**. The auditor stopped before correctness inspection because the live repository, retained target, exact recipe, or mandatory evidence did not match the audit prompt’s pinned expectations. That is the required behavior: provenance mismatch must stop the audit before judging the patch. 

Do **not** return to implementation repair yet. We do not know whether this is:

- changed live candidate bytes;
- a missing or inconsistent retained evidence record;
- stale aggregate metadata in the implementation report;
- an over-specified audit-prompt expectation;
- or an audit-wrapper/recipe-redirection defect.

The bare token contains no failed predicate, so reopening code or regenerating all validation now would be premature.

## Next action

Continue in the **same read-only audit conversation** with this provenance-only diagnostic prompt:

:chatgpt-content-reference{index="2"}

```text
Filename:
Coordinator_RW0_B2_Capability_Audit_Provenance_Mismatch_Diagnostic_Prompt.txt

Size:
8,049 bytes

SHA-256:
d28a50f47da615a350b2923c3396498c78789a6566b4660d8609330819640dcd
```

It prohibits tests, correctness inspection, and repository mutation. It requires the auditor to identify the **first failed provenance predicate**, report every expected-versus-observed value, and classify the failure into one of these operational outcomes:

```text
IMPLEMENTATION_REPORT_STALE_BYTES
PROVENANCE_BASELINE_READY
IMPLEMENTATION_CLOSEOUT_EVIDENCE_REGENERATION_REQUIRED
AUDIT_WRAPPER_REPAIR_REQUIRED
PROVENANCE_RECIPE_FAILURE
```

### Decision path after that report

If the live candidate differs from the retained final manifest, return to the write-enabled implementation conversation for a new closeout and validation binding. This is the `IMPLEMENTATION_REPORT_STALE_BYTES` case described by the provenance guidance. 

If live bytes, the exact recipe, and the retained manifest agree—and only a copied hash, report field, or prompt expectation is stale—perform a read-only provenance re-baseline. Do not rerun implementation.

If mandatory evidence is missing, use the implementation conversation only for an **evidence-only closeout continuation**, with production and documentation bytes frozen.

If the audit wrapper caused the mismatch, repair the external wrapper and restart the audit against the same candidate bytes.

No staging, commit, or PR action is permitted until a fresh audit reaches `ACCEPT`; implementation and independent audit must remain separate engagements. 

### Sources

- Governed Execution Provenance Guidance: mismatch classifications and stop behavior. 
- Governed Execution Codex Subagent Operating Protocol: independent audit and repair separation. 

**Confidence:** High that provenance diagnosis—not code repair—is the correct next step. Confidence in the specific mismatch cause is intentionally low until Codex reports the failed predicate.
