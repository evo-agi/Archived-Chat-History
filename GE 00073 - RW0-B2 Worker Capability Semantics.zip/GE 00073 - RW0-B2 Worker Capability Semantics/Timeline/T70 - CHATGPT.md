## Engineering disposition

**Proceed with the integrated repair on the existing Capability branch.** No further reconnaissance is needed.

The reconciliation closes the previously unresolved engineering choices:

- B1 will reconstruct all eight values through its own grammar and use only reconstructed locals.
- C2A and the Section 41 lineage owner will expose bounded private reconstruction seams rather than letting B1 duplicate their schemas.
- The original B1 host budget of `241` is retired; hardened host validation plus safe snapshots is `863`.
- Capability retains its independent local budget of `249`, producing a composed occurrence-work total of `1112`.
- The repair remains private and downward-only: `Capability → B1 → C2A/lineage`, with no reverse import, export, runtime caller, migration, or Wire-source change.   

The exact owner tariffs and relation budgets are now sufficiently frozen for implementation. In particular, the response defines the C2A/lineage tariffs, all eight B1 reconstruction/equality limits, and every affected B1 relation maximum rather than leaving Codex to infer them while editing. 

The touched surface is also closed:

```text
30 dirty paths
24 tracked modifications
6 existing untracked additions
0 staged
0 unmerged
no new file
```

That consists of 18 current candidate paths that may change, two current candidate paths that remain byte-identical, and ten newly authorized existing owner paths. Everything else remains protected. 

### Important retained nonclaim

The `2G` tariffs are an **occurrence-work model**. They do not establish a finite integer-bit-length, serialized-byte, or wall-clock bound, because existing C2A semantics admit some unbounded nonnegative integers. The repair must not silently introduce a scalar cap or SQLite-width restriction. The handoff makes that explicit and stops if closing the reported graph-amplification defect would require changing the scalar domain. 

That is the correct treatment: close the audited recursive graph-expansion defect without pretending this tranche has also redesigned C2A’s integer contract.

## Implementation handoff

Change the existing Capability implementation conversation to **workspace-write**, then send this complete prompt:

:chatgpt-content-reference{index="1"}

Verify the artifact:

```text
Filename:
Coordinator_RW0_B2_Capability_Integrated_Protected_Owner_Repair_Prompt.txt

Size:
43,254 bytes

SHA-256:
d025b4f4cde3d1a31179f78702cc5c1bfc0a210d743caf6d86af9ec03667f83f
```

The prompt is bound to the current live candidate:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Opening canonical manifest:
41a256e52bf5b3e677ec88736889230be416005da429bf5cb3339c92d9427c76

Opening complete output:
8d8ff431ae0aa0362b4d298e5261ba866ca9f7eeae18a3e2f93bb33d233b088b

Opening nodes:
4,676

Opening node-list SHA-256:
f8fe844c0b8da21b99ccedb3cc22075f85c144e9420c6d040504a9859680e26c
```

### Repair order

The handoff enforces:

```text
test-first causal failures
    ↓
C2A and lineage owner helpers
    ↓
B1 value and relation reconstruction
    ↓
private B1 host snapshot seam
    ↓
Capability composition and local findings
    ↓
status/document correction
    ↓
focused validation
    ↓
final node comparison
    ↓
one complete suite
    ↓
new exact 30-path provenance
    ↓
fresh independent audit
```

No subagents are active during mutation, and the parent is the sole writer.

### Principal acceptance evidence

The implementation must prove, causally rather than just through ordinary positive tests:

- a correctly resealed invalid readiness value can no longer qualify;
- no C2A, lineage, or B1 helper can bypass raw-state metering through a public projection;
- cycles and repeated aliases are charged correctly;
- all eight B1 values and every B1 relation meet their literal maximum and one-under budgets;
- relations never read the original B1 objects after reconstruction;
- Capability consumes only the five fresh B1 snapshots;
- the host seam runs once at `863`, Capability runs separately at `249`, and no `241/490` claim survives;
- hostile Wire keys yield only the fixed import invariant;
- no Wire owner callable or manifest remains in Capability globals;
- generic session-bearing unknown keys are private-material failures;
- the current/future RW0 wording no longer contradicts implemented B1/Wire/Capability semantics.

The reconciliation itself specifies these causal classes and the final validation order. 

### Stop conditions

Codex must stop rather than widen the tranche if repair requires:

- a 31st path;
- a schema, field, enum, digest-domain, canonical-byte, or scalar-domain change;
- a public API, export, caller, dependency, migration, SQL, or durable-state change;
- a Wire implementation change;
- reverse imports;
- a broad C2A redesign;
- branch movement, reset, rebase, or stash;
- any protected path;
- non-exact budget arithmetic.

The required successful implementation token is:

```text
COORDINATOR_RW0_B2_CAPABILITY_INTEGRATED_OWNER_REPAIR_IMPLEMENTED_READY_FOR_FRESH_REAUDIT
```

After that token, the next action is a **new read-only independent audit**, not a commit gate. The reconciliation explicitly justifies an integrated repair on the current uncommitted branch and requires fresh acceptance before staging.  

### Sources

- Codex protected-owner repair reconciliation supplied in this turn. 
- Frozen C2A/lineage and B1 reconstruction algorithms and budgets. 
- Exact 30-path ceiling, validation, and integration disposition. 

**Confidence:** High that the repair scope and sequencing are ready for implementation; high that the 30-path ceiling is sufficient; medium-high that independent re-audit will accept the occurrence-work model if the implementation and documentation preserve its explicit scalar-size nonclaim.
