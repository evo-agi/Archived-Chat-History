Alright. Let's continue.
