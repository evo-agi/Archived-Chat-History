## Assessment

Codex’s latest disposition is defensible under the previous prompt:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_PARTIAL
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

The missing **cancellation-request fact owner is now resolved**. No C2A or B1 change is required, and no owning-contract contradiction was found. The remaining gaps are exact schema/accounting closure:

- ordered fields for the request and source-native process observations;
- classifier cardinality and precedence;
- work accounting;
- derived protocol profile identity;
- the literal 16-path implementation ceiling.

This is no longer broad architecture reconnaissance. The adopted Wire direction—command plus delivery, identity-free outer frame, worker observations as evidence, route neutrality, and Capability after Wire—was already supported by the repository inspection.  The earlier report also correctly identified finite integer admission and cumulative work as the outstanding representational issues rather than a requirement for C2A widening. 

## Engineering correction

The previous prompts overextended B1’s shared-graph budget lesson into a domain where the same attack surface does not exist.

B1 needed a propagated graph budget because it accepted nested caller mappings with aliases and cycles. Wire has a narrower boundary:

- decoder input is exact `bytes` and becomes a fresh JSON tree;
- encoder input is exact already-constructed C2A/B2 objects, not arbitrary mappings;
- relation inputs are fixed-field objects and closed tuples;
- attacker-controlled variation is bounded by payload bytes, integer digits, key count, container count, scalar/list-element count, and classifier fact cardinality.

The replacement therefore freezes an **enforceable hostile-input work model** rather than demanding a synthetic counter for every fixed internal comparison:

```text
command hostile-input limit = 23,746 units
result hostile-input limit  = 66,770 units
classifier supplied facts   = at most 10
```

Each frame budget covers:

```text
8 header bytes
+ four linear passes over the bounded payload
+ parsed keys
+ parsed containers
+ parsed scalar/list elements
```

Fixed relation loops remain mandatory and independently enumerated in tests, but they are not falsely characterized as caller-expandable graph traversal.

The replacement also freezes:

- the exact cancellation-request observation fields;
- the exact resource/signal process-observation fields;
- a result envelope with no competing identity;
- the complete classifier input inventory and reasons;
- exit-code-zero treatment as a B2 classifier rule only;
- the protocol-profile manifest/ref/domain;
- the exact 16-path implementation ceiling.

The profile digest remains a derived literal that Codex must calculate from the frozen canonical manifest during this final read-only closure. That digest is evidence of protocol identity, not a separate architectural choice or authority fact.

## Next action

Send this complete prompt to the **same read-only RW0-B2 Codex conversation**:

:chatgpt-content-reference{index="3"}

This is still read-only and parent-only. It is not an implementation prompt.

The required successful response is:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_READY
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

A further `PARTIAL` is justified only by a concrete owning-contract contradiction or a genuinely unavailable required identity. It is not justified merely because:

- the profile digest must be calculated;
- implementation fixtures have not yet been written;
- fixed relation loops are not charged as hostile graph work;
- another plausible schema could have been chosen.

The frozen implementation ceiling is exactly:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

No B1 file is authorized to change.

If the two successful tokens are returned, the next step is one bounded, parent-only **RW0-B2-Wire implementation prompt**. Capability implementation remains deferred until Wire is implemented and independently accepted.

The sequence remains the established project lifecycle: read-only design, sole-writer implementation, exact validation/provenance, and a later fresh read-only independent audit.  Provenance will bind those stages to identical bytes but must not be treated as correctness or authority. 

### Sources

- Prior Wire reconnaissance, supported composition, remaining finite-size and work gaps.  
- Governed Execution separation of reconnaissance, implementation, and independent audit. 
- Provenance’s evidence-only role and separate confidence dimensions. 
- Codex response supplied in this turn.

**Confidence:** High that the cancellation-request owner is now correctly separated; high that the compositional hostile-input model is more enforceable than the prior synthetic whole-internal-work requirement; high that this should be the final read-only Wire closure before implementation.
