## Engineering disposition

Do **not** begin RW0-B2-Wire implementation yet.

The packet is technically detailed and nearly complete, but its `READY` verdict contains one blocking fact-owner error:

```text
RW0WireCancellationRequestObservationV1.source_kind
    = direct_local_adapter | es_adapter
```

The merged RW0-A owner says otherwise:

- the direct-local adapter handles transport, while the **remote supervisor owns cancellation requests** at `.docs/rw0-remote-worker-contact-phase-entry.md:182-184`;
- the **direct-local supervisor owns cancellation-request delivery**, while the adapter only transports the resulting bounded facts at `.docs/rw0-remote-worker-contact-phase-entry.md:369-372`;
- Execution Substrate owns ES-route cancellation at the same owner boundary.

This is not cosmetic naming. It determines who authored the source fact. Letting an adapter-authored value represent the request would collapse transport/carriage into source ownership—the exact kind of semantic omission that repeatedly appeared during B1 auditing.

The existing C2A distinction reinforces this conclusion:

- `direct_local_adapter | es_adapter` are valid authors for existing acknowledgement/rejection observations;
- those response observations are not the cancellation request;
- the request, acknowledgement, signal, exit, teardown, reconciliation, and terminal outcome must remain distinct.

The earlier reconnaissance had already established that worker results and process facts must remain evidence rather than authority or acceptance. 

## Required correction

Freeze the request source enum as:

```text
supervisor | execution_substrate
```

with the route relation:

```text
cancellation_delivery.adapter_kind == direct_local_bootstrap
    -> request.source_kind == supervisor

cancellation_delivery.adapter_kind == execution_substrate
    -> request.source_kind == execution_substrate
```

The request and its later acknowledgement/rejection should **not** be required to share source kind, source ref, or source invocation. They match through the exact cancellation graph:

- cancellation effect and fence;
- cancellation delivery;
- immutable target effect/fence;
- target author delivery and lineage.

That preserves the ownership split:

| Route | Request owner | Acknowledgement/rejection carrier |
|---|---|---|
| Direct-local | Supervisor | `direct_local_adapter` C2A observation |
| ES | Execution Substrate | `es_adapter` C2A observation |

Wire still cannot authenticate any of those source claims.

## Profile consequence

I independently reproduced the packet’s current profile identity:

```text
canonical identity bytes: 4,022
SHA-256: 552ad9179dd8b97545f567b9389da2e09a428d5f4c4ef9c16b2f40dc16690006
```

Changing only:

```json
"source_kinds":["direct_local_adapter","es_adapter"]
```

to:

```json
"source_kinds":["supervisor","execution_substrate"]
```

produces the expected corrected identity:

```text
canonical identity bytes: 4,021
SHA-256: 470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
```

Codex must independently reproduce those corrected values rather than copying them into the report.

No frame, payload, result grammar, classifier precedence, size limit, work limit, capability seam, module, or touched-file decision needs to reopen.

## Privacy clarification

The final implementation packet should also state explicitly what its prose already implies:

- new B2 ref fields use the C2A safe-ref character, length, and forbidden-prefix grammar;
- they additionally reject IPv4-shaped refs, following the accepted B1 privacy boundary;
- private-material unknown keys fail with a content-free privacy reason;
- no host, IP, endpoint, credential, bearer, provider/session, path, prompt, transcript, JSONL, stdout/stderr, or process handle may enter the new values.

This is a clarification of the frozen privacy posture, not a B1 import or semantic change.

## Next action

Continue in the **same read-only B2 Codex conversation** with this finite correction:

:chatgpt-content-reference{index="3"}

The required result remains:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_READY
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

Only the corrected result authorizes the parent-only Wire implementation turn.

The project workflow requires the plan to be frozen against an unchanged baseline before mutation, and keeps implementation and independent audit in separate engagements.  After implementation, provenance must bind the working bytes to the later audit without being mistaken for semantic correctness or authority. 

### Inspection boundary

I checked the merged snapshot’s:

- RW0-A process and ES ownership clauses;
- C2A adapter/source-kind and observation inventories;
- C2A delivery and cancellation-target relations;
- B1 privacy ref handling;
- Wire profile mapping and domain-separated digest arithmetic;
- relevant static inventory and status-test surfaces.

I did not inspect unrelated Section 41 runtime internals or execute repository tests.

### Sources

- Prior Wire ownership and non-collapse findings. 
- Prior finite-size, work-budget, and classifier gaps. 
- Governed Execution read-only freeze → parent-only implementation → fresh audit workflow. 
- Provenance’s evidence-only role. 
- Coordinator snapshot paths inspected: `.docs/rw0-remote-worker-contact-phase-entry.md:182-184,369-372`; `src/ge_nwp_coordinator/_worker_execution_semantic_values.py:61-80,3747-4245`; `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:60-91,232-243`.

**Confidence:** High that the current `direct_local_adapter | es_adapter` request enum violates the frozen RW0-A fact-owner split; high that the correction is finite and leaves the remainder of the Wire design intact.
