## Assessment

Codex made the right disposition:

```text
RW0_B2_WIRE_RECONNAISSANCE_PARTIAL
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

**No implementation prompt is justified yet.** The decomposition and ownership model survived inspection, but Wire still lacks exact identities, byte grammar, limits, work accounting, failure precedence, and process-classification semantics. The local baseline remained unchanged, and the four explorers completed the requested read-only pass. 

Capability is sufficiently bounded for Wire to proceed once Wire itself is frozen. There is no provider-neutral Capability contradiction that invalidates the proposed Wire direction. Exact Capability classes, fields, freshness rules, and implementation surfaces can remain deferred until after Wire is implemented and independently accepted. 

## What the reconnaissance settled

The following should now be treated as the adopted B2 target, subject only to a concrete owning-contract contradiction:

| Surface                  | Adopted decision                                                                                              |
| ------------------------ | ------------------------------------------------------------------------------------------------------------- |
| Order                    | `RW0-B2-Wire → RW0-B2-Capability`                                                                             |
| Command payload          | Complete `WorkerCommandV1` plus complete `DeliveryEnvelopeV1`                                                 |
| Outer frame              | Structural only; no semantic identity or self-digest                                                          |
| Result payload           | A private envelope of complete worker-authored `WorkerObservationV1` records                                  |
| Result sequences         | `worker_started → worker_completed` or `worker_started → candidate_captured → worker_completed`               |
| Result meaning           | Source evidence only—not process success, acceptance, permission, decision, or durable terminal truth         |
| Route treatment          | Same nested semantics for direct-local and ES; route wrappers and correlations remain route-owned             |
| Capability               | Separate declaration, independent observation, and qualification; mechanism-neutral                           |
| Concrete Codex mechanism | Remains RW0-D/E, including CLI/App Server selection, credentials, sessions, invocation, and process mechanics |

These conclusions are directly supported by current C2A ownership and the accepted B1/D/E split. The remaining relation must still specify which checks can be proven from framed records and which require separately supplied actual fences. 

## Why Wire is still partial

### 1. No finite payload maximum exists under C2A alone

C2A permits several nonnegative integers without a finite semantic upper bound. Therefore, a command payload cannot have an exact finite maximum until B2 adopts its own defensive representability policy. The reconnaissance showed that `2^63−1` is a plausible B2 limit, but correctly refused to promote it from proposal to frozen contract. 

The conditional calculations are useful:

```text
command payload with int64 maxima: 5,898 bytes
result payload with the proposed schema-id envelope: 16,681 bytes
```

The result number depends on an envelope design that is not yet frozen. Removing the redundant payload-level `schema_id` would reduce that proposed result maximum by 54 bytes to **16,627**, but that must be independently rederived rather than accepted from arithmetic alone.

### 2. Whole-operation work remains unbounded

The report has structural occurrence counts, but those do not include:

* header and length processing;
* UTF-8 decoding;
* JSON tokenization;
* duplicate-key detection;
* key scans;
* bounded integer conversion;
* canonical re-encoding;
* nested C2A reconstruction;
* relation calls;
* helper composition;
* repeated aliases.

This is precisely the type of incompleteness that repeatedly surfaced during B1 auditing. A narrative or node-count-only budget is not an implementation-ready bound. 

### 3. Process/result classification is incomplete

Current C2A observations cover deadline, exit, and cancellation acknowledgement/rejection, but not source-native signal delivery or resource-limit violation. Cancellation also belongs to a distinct effect and delivery graph, so it cannot be compared naively with the author-result delivery and fence. Exit zero cannot prove result validity, while a normal successful exit cannot automatically make a valid result unusable. 

### 4. Exact bytes and failures are not frozen

The required rejection classes are known, but these remain open:

* magic/version/kind/header layout;
* envelope schemas;
* duplicate-key and malformed-JSON ordering;
* complete sealed error algebra;
* total decoder precedence;
* exact profile identity;
* touched-file allowlist.

Accordingly, implementing now would force the writer to invent governing protocol decisions while writing source. 

## Engineering decisions for the closure pass

Another four-explorer reconnaissance would add little. The remaining work is a **finite parent-only read-only schema closure**. I am setting these target decisions for Codex to source-ground, calculate, and either freeze or reject on a concrete owning-contract conflict:

### Wire representability

Adopt `2^63−1` as a new B2 representability maximum for every framed integer. This does not modify C2A or B1 and does not become a `CeilingsV1` field. A locally valid C2A value above that maximum is simply not Wire-representable.

### Frame layout

Use one eight-byte header:

```text
0..3  b"NWPF"
4     version 0x01
5     kind: 0x01 command, 0x02 worker_result
6..7  unsigned payload length, big-endian
```

A two-byte length is sufficient only if the mechanically recalculated maxima remain below 65,536. If they do not, Codex must block rather than silently widen the header.

### Payloads

Command:

```json
{"command": <WorkerCommandV1>,
 "delivery": <DeliveryEnvelopeV1>}
```

Result:

```json
{"observations": [<WorkerObservationV1>, ...]}
```

The header already selects the payload schema, so the payload receives no redundant schema ID or self-digest. Nested records retain their existing identities.

### Wire profile identity

Freeze one domain-separated protocol-profile ref/digest over a canonical manifest containing the complete frame, canonicalization, cap, result-grammar, precedence, relation, and budget contract. That profile is not carried as an outer frame identity; it is the safe versioned contract that later Capability declaration and qualification can bind.

### Result relation

Require a single worker source and invocation across the envelope, exact common lineage, unique observation refs and digests, strict tuple order, and exact candidate binding. A different `source_ref` inside one result would amount to stitching evidence from multiple sources into one claimed worker result.

### Missing process facts

Add one minimal private source-claim value for the two facts C2A does not currently represent:

```text
resource_limit_exceeded
signal_delivered
```

It remains a supervisor/OS-authored claim, carries no measurements or signal number, authenticates nothing, and exists only as supplied evidence for the classifier. Existing C2A observations continue to own exit, deadline, and cancellation facts.

### Process/result classifier

Freeze one deterministic pure classifier. Its precedence begins with invalid inputs, resource limit, deadline, signal, and the exact cancellation graph; then conflicting process facts, adverse exit, protocol failure, incomplete exit evidence, and finally usable result.

Any active cancellation branch takes precedence over normal result usability. A cancellation rejection still does not authorize continued semantic progression; it means the cancellation branch is unresolved and requires later reconciliation.

### Canonical decoding

Freeze strict UTF-8, no BOM, duplicate-key rejection, bounded integer token parsing before Python integer construction, exact built-in types, no floats or Boolean-as-integer substitution, compact sorted-key JSON, no normalization, and re-encode-byte equality.

### Bounds

The closure must independently calculate rather than assume:

```text
command payload maximum
result payload maximum
maximum depth
container count
key-pair count
command encode/decode work
result encode/decode work
classification work
```

It must include every byte, token, key scan, reconstruction tariff, relation call, helper, cycle, and repeated alias. The maximum valid operation must pass and one additional charged occurrence must fail.

## Forecast disposition

The reconnaissance resolved the earlier forecasts well:

1. **Finite-size blocker:** confirmed, but it is an integer-admission gap rather than a Unicode-expansion gap. The int64 Wire policy should close it if the first RW0 scenario’s records satisfy the bound. 

2. **Touched-file ceiling:** the earlier small estimate was too optimistic. Static importer inventories and synchronized status owners will expand the exact Wire allowlist; that must now be enumerated before implementation. 

3. **Likely audit findings:** parser precedence, uncharged pre-construction work, alias accounting, noncausal mutants, and worker/process fact collapse remain the most likely classes. A need for raw authority bytes, C2A enum widening, an outer competing identity, or provider-specific framing would require redesign rather than ordinary repair. 

## Next action

Send this prompt to the **same read-only B2 Codex conversation**:

[Download the RW0-B2-Wire schema-freeze closure prompt](sandbox:/mnt/data/Coordinator_RW0_B2_Wire_Schema_Freeze_Closure_Prompt.txt)

This is deliberately:

* parent-only;
* read-only;
* finite in scope;
* not another broad reconnaissance;
* not an implementation prompt;
* not a Capability freeze requirement.

The successful result is:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_READY
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

Only that result permits the next step: one bounded parent-only **RW0-B2-Wire implementation prompt**. Capability implementation remains unauthorized.

### Sources

* Codex’s split Wire/Capability reconnaissance and baseline verification. 
* Supported Wire ownership and composition. 
* Integer, payload-size, structural, and work-budget findings. 
* Process/result and decoder gaps. 
* Capability seam and progression boundary. 
* Separate reconnaissance, implementation, and independent-audit lifecycle. 

**Confidence:** High that Wire is correctly classified as partial rather than blocked; high that the finite closure pass is the appropriate next action; moderate-to-high that the adopted int64/header/profile/classifier decisions can be frozen without changing C2A or B1.
