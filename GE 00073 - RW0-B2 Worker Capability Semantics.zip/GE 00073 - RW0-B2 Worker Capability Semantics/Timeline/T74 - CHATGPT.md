## Engineering disposition

**The audit’s `BLOCK` is valid. Proceed with a bounded repair in the existing Capability implementation conversation. Do not start another reconnaissance pass, move branches, or enter the commit gate.**

None of the seven findings requires an architectural reset:

- `AUD-001`, `AUD-002`, and `AUD-006` are localized implementation defects.
- `AUD-003`, `AUD-004`, and `AUD-005` are governing-document contradictions.
- `AUD-007` is a test-evidence gap; the audit otherwise confirmed that the B1 relations currently use reconstructed locals.

The accepted Capability identity, the C2A/lineage reconstruction ownership, all B1 budgets, the private host snapshot seam, and the `863 + 249 = 1112` composition remain unchanged. 

### Frozen repair decisions

**Wire-owner failure boundary.** Use a two-stage capture-and-raise design. The capture helper catches ordinary owner failures, retains only a finite status and safe strings, clears the callable/mapping/manifest, and returns normally. The module deletes the imported owner binding on both success and failure before a separate no-argument function raises the fixed invariant. This keeps hostile objects out of the raising traceback.

**Error reflection.** The error reason should no longer live in a mutable instance slot. Store the finite reason in a private `WeakKeyDictionary`, make the error weak-referenceable, and expose read-only descriptors for:

```text
reason
_reason
args
__cause__
__context__
```

Direct `object.__setattr__` attempts against those observations must fail, while `str`, `repr`, serialization, and ordinary `__dict__` access remain content-free or unavailable. Unrelated state inserted through lower-level reflection remains outside the supported API and must have no semantic effect.

**B1 documentation.** `1285` becomes the sole current retrieval-relation maximum. Capability is recorded as the sole current cross-module production consumer of the private B1 host seam; C/D/E remain future owners or consumers.

**RW0 tranche status.** Do not invent another B tranche. B1, Wire, and Capability are current private semantic contracts. Remaining durable mechanics belong to C, physical/process/provider mechanics to D, live proof to E, and ES-route runtime facts to Execution Substrate.

**C2A tuple work.** Schedule a tuple-index frame, charge the member occurrence, then dereference `tuple[index]`. The repair must preserve all accepted tariffs and identities.

**B1 relation evidence.** Add a literal inventory of all thirteen relation entry points and cover four modes for each: ordinary invalid-state rejection, selective reconstruction bypass, class-wide bypass, and poisoning of the original object after reconstruction.

## Exact repair boundary

The patch remains a **30-path candidate**. Exactly 11 already-dirty paths may change; the other 19 candidate paths must remain byte-identical. No new dirty path is authorized.

The repair does **not** modify:

```text
_rw0_phase_entry_semantic_values.py
_development_pre_execution_plan_disposition_contracts.py
_rw0_wire_protocol_values.py
Capability schemas or vectors
B1 budgets or relation semantics
SQL, migrations, package exports, StateStore, or WriterSession
```

This is the normal audit-repair lifecycle: return to the sole-writer implementation conversation, generate new validation and provenance, and send the changed bytes to a fresh independent audit.  Provenance must continue to be treated as byte-identity evidence rather than correctness evidence. 

## Repair handoff

Send this complete prompt to the existing workspace-write Capability implementation conversation:

:chatgpt-content-reference{index="3"}

Verify the artifact:

```text
Filename:
Coordinator_RW0_B2_Capability_Integrated_Owner_Repair_Audit_Findings_Repair_Prompt.txt

Size:
34,758 bytes

SHA-256:
087d018dc2c740497dafa5ee485a0f5c9e454db64b2875bfccd5bbb7a07712a4
```

The prompt binds the opening candidate to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Topology:
30 dirty
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

Canonical manifest:
6,428 bytes
177dab5f0c89f0bf99273c2fe9b3f8123f4df34c9dc29306acafb0308eaeb900

Complete recipe output:
6,661 bytes
20522a0b494d6e3511abe94b33dcee9a4f3a4c4a22768fa20bc369a6354f3042

Opening nodes:
4,719

Opening node-list SHA-256:
24f6fe99b8ef728859327884da26f17f6dc9f8ea834aaf2b26a5914122399be6
```

Its required successful result is:

```text
COORDINATOR_RW0_B2_CAPABILITY_INTEGRATED_OWNER_REPAIR_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

That token advances only to another fresh read-only independent audit. The commit gate remains prohibited until the repaired bytes receive `ACCEPT`; only then may the exact audited paths be staged and compared with the accepted manifest. 

### Sources

- Codex fresh independent-audit report supplied in this turn.
- Protected-owner reconciliation and accepted Capability composition. 
- Sole-writer repair and mandatory re-audit lifecycle. 
- Provenance and commit-gate boundaries.  

**Confidence:** High that all seven findings are repairable within the 11-path boundary; high that no architecture or identity refreeze is needed; medium-high that the reflection and traceback-retention repairs will pass re-audit if the external causal probes inspect complete traceback, globals, descriptors, and closure reachability rather than only normal attribute reads.
