PROMPT_ID

RW0_B2_WIRE_THIRD_AUDIT_REPAIR_V1

TITLE

Coordinator RW0-B2-Wire — repair the third independent-audit findings and
prepare exact bytes for a fresh re-audit

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing
`codex/rw0-b2-wire-protocol-v1` implementation conversation.

Do not create or resume subagents. You are the sole repository writer.

This is a bounded repair after a fresh independent read-only audit returned
`REJECT`. It is not reconnaissance, a Wire redesign, Capability implementation,
independent audit, commit gate, publication gate, merge, deployment, or runtime
proof.

Do not stage, commit, push, create or modify a PR, merge, tag, release, deploy,
contact a remote, invoke a product worker/model/provider, modify a supporting
repository, or install dependencies.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Close exactly the three current-contract patch defects found by the latest
audit:

1. enforce the frozen B2 maximum integer during literal safe extraction, before
   any owning C2A reconstruction, owner canonicalization, Wire
   canonicalization, digest, or JSON conversion;
2. preserve `duplicate_key` precedence when repeated JSON keys are themselves
   structurally invalid or overlength;
3. replace the noncausal command key-cap fixture with one that exceeds only the
   key-pair maximum.

Preserve every previously closed finding, the exact Wire profile, frame and
payload bytes, hostile-work constants, source ownership, classifier grammar,
authority/privacy boundary, 16-path candidate scope, and Capability
nonimplementation.

Return the exact repaired candidate for another fresh independent read-only
audit.

OPENING TARGET

Before any mutation, require exactly:

- physical root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- subject:
  `feat: implement RW0-B1 pure phase-entry semantics (#3)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- dirty paths:
  `16`
- tracked modifications:
  `10`
- untracked additions:
  `6`
- staged/unmerged:
  `0/0`
- every candidate path:
  regular mode `0644`
- no Git operation, lock, repository cache, bytecode, database, journal,
  archive, build, generated manifest, or recorder residue
- `git diff --check`:
  clean.

Immutable opening target:

```text
/private/tmp/rw0-b2-wire-second-repair.91xEYJ/final_provenance.json
```

Require that report to bind exactly one canonical manifest with:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe source size:
3_945 bytes

recipe source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6

canonical-manifest SHA-256:
8991126301a695c591e7f977bbf4580e378bdee39f740624106e5a0e0f324d11

complete-output SHA-256:
10ddb5dfda278c484b6846d0c677aebaed9265863fefe3254835c5619a16dda5

file count:
16
```

Retained evidence roots that must remain unchanged include:

```text
/private/tmp/rw0-b2-wire-v4.b4HlRt
/private/tmp/rw0-b2-wire-independent-audit.hX8xit
/private/tmp/rw0-b2-wire-repair.q4veCL
/private/tmp/rw0-b2-wire-re-audit.dU0ieG
/private/tmp/rw0-b2-wire-second-repair.91xEYJ
```

Preserve the latest read-only audit evidence wherever it was retained. Do not
rewrite or reconstruct missing evidence.

EXACT RECIPE SOURCE

Decode this base64 only into a new external repair evidence root, verify exact
size and SHA-256, and retain it mode `0400`:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

Execute the exact source unchanged with only its exact historical
`Path.write_bytes` sink redirected into the new evidence root. Do not overwrite
pre-existing fixed-path evidence.

OPENING PROVENANCE AND NODE GATE

Before editing:

1. lstat every component of the immutable target, retained evidence roots, new
   repair root, and copied recipe;
2. require safe ownership, no symlink traversal, regular files, and mode-0700
   evidence roots;
3. verify the immutable target and report-owned canonical manifest exactly;
4. run the exact recipe twice;
5. require both complete outputs and manifests to be byte-identical and equal
   the immutable target;
6. verify every live candidate entry by path, classification, type, mode, size,
   and SHA-256;
7. verify protected complement equality to HEAD;
8. collect the complete opening node list exactly once under isolated external
   paths;
9. require exactly `4_653` unique opening nodes.

Stop before mutation on any mismatch. Do not reset, clean, or reconstruct the
candidate.

LATEST AUDIT FINDINGS

Treat these as authoritative repair inputs:

```text
F12 Medium  integers above 2^63-1 reach owner/Wire canonicalization before B2
            rejection

F13 Low     repeated identical overlength JSON keys are not marked duplicate,
            so structural invalidity incorrectly outranks duplicate_key

F14 Low     the command key-cap test exceeds both key-pair and scalar limits and
            is therefore noncausal
```

The audit independently confirmed that all preceding authority, privacy,
profile, parser, traversal, C2A extraction, classifier, status, public-surface,
and evidence-boundary findings remain closed.

ENGINEERING DECISIONS — FROZEN FOR THIS REPAIR

A. B2 integer policy applies before canonicalization

The frozen B2 representational maximum remains:

```text
WIRE_MAX_INT = 9_223_372_036_854_775_807
```

This is a B2 Wire admission/representation rule. It does not modify C2A, B1, an
owning field’s lower bound, an effect ceiling, allocation permission, transport
permission, or runtime authority.

For every exact built-in `int` leaf extracted from any of the six consumed C2A
classes:

```text
CeilingsV1
AttemptFenceV1
EffectFenceV1
WorkerCommandV1
DeliveryEnvelopeV1
WorkerObservationV1
```

require:

1. exact built-in `int`, never `bool` or subclass;
2. `value <= WIRE_MAX_INT` before:
   - owner `from_mapping`;
   - owner `to_mapping`;
   - owner identity/canonical-byte computation;
   - owner self-digest computation;
   - Wire canonical JSON;
   - Wire digest or payload construction;
   - any decimal/string conversion;
3. preserve the owning lower-bound rule:
   - do not reject a permitted negative process exit merely because the
     general B2 maximum is unsigned in other fields;
   - the B2 precheck is the upper bound;
   - owning C2A reconstruction still enforces field-specific lower bounds and
     ranges;
4. apply the same upper-bound precheck to all fifteen nested `CeilingsV1`
   leaves;
5. perform no generic recursive traversal: keep the literal class-specific safe
   extractor and its fixed field/member bounds;
6. reject an oversized integer through the existing sealed
   `invalid_field_value` construction/relation boundary;
7. retain null cause/context and content-free error behavior.

The exact maximum must remain accepted.

`MAX+1`, a 1,000-decimal-digit positive Python integer, and an oversized nested
ceiling must be rejected before any owner or Wire canonicalization call.

B. Zero-canonicalization proof

Tests must instrument the relevant owner and Wire canonicalization boundaries.

For every oversized-integer case, require zero calls to all applicable:

- C2A owner `from_mapping` paths;
- C2A canonical identity or digest helpers;
- C2A `to_mapping`;
- Wire canonical JSON;
- Wire frame payload construction.

Instrumentation must not itself alter the candidate behavior or use a fixture
that fails an earlier unrelated predicate.

At least these cases are required:

```text
WorkerCommandV1.global_stop_version == MAX
WorkerCommandV1.global_stop_version == MAX + 1
WorkerCommandV1.global_stop_version == int("9" * 1000)

one non-Git CeilingsV1 leaf == MAX
the same leaf == MAX + 1
the same leaf == int("9" * 1000)
```

Use complete, otherwise valid and related command/delivery/fence graphs.
Reseal only the owning value where a valid positive fixture requires resealing.

C. Duplicate identity is independent of key validity

In the pair-preserving JSON parse-accounting hook:

1. charge every raw pair;
2. compare key identity against the per-object `seen` set independently of key
   validity;
3. mark `duplicate_seen` whenever the same exact string key appears again;
4. add the first occurrence to `seen` even when it is overlength or otherwise
   structurally invalid;
5. separately record key-shape invalidity;
6. do not raise from the parse hook;
7. preserve syntax-error precedence for unfinished JSON;
8. after successful syntax:
   - `duplicate_key` precedes `invalid_root_or_scalar`;
   - structural invalidity precedes `work_limit_exceeded`.

Required overlap cases:

```text
one unique 30-character key
    -> invalid_root_or_scalar

two identical 30-character keys in valid JSON
    -> duplicate_key

two identical 30-character keys followed by a later syntax error
    -> json_token_invalid
```

Keep the frame-key maximum exactly `29`.

D. Causal command key-cap fixture

Replace the existing noncausal fixture with one whose only exceeded structural
limit is key-pair count.

The test-owned pair tree must contain exactly:

```text
72 key pairs
70 scalar leaves
2 container-valued pairs
```

Use unique keys whose individual lengths are within the frame-key maximum.
Use bounded empty container values so that depth and container count remain
within their frozen maxima.

Required proof:

1. the production structural checker rejects at key-pair maximum `71`;
2. an independent test-local broken checker that changes only key-pair maximum
   to `72` accepts the same pair tree;
3. scalar, depth, container, key-length, payload, duplicate, root, and work
   limits remain satisfied;
4. removing or widening only production key-pair enforcement makes the test
   fail.

Do not derive the fixture from production limit constants other than comparing
the literal expected values to them.

E. Previous closure preservation

Do not change:

```text
profile_ref:
rw0-wire-nwpf-v1

profile identity bytes:
4_021

profile digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454

command payload/frame:
5_898 / 5_906

result payload/frame:
16_627 / 16_635

hostile units:
23_746 / 66_770

source mapping key maximum:
37

frame key maximum:
29
```

Preserve:

- sealed error graph isolation;
- disabled and fail-closed value construction;
- bounded iterator-frame traversal;
- raw-pair charging;
- literal safe C2A extraction;
- owning C2A relation authority;
- reconstruct-first classifier ordering;
- duplicate versus valid singleton conflict semantics;
- cancellation graph orientation and precedence;
- privacy rules;
- status wording;
- private/no-I/O/non-authority boundaries.

F. Governing document

The detailed Wire owner already states the integer maximum and
`preconversion_bounded:true`.

Add only the minimum clarification needed to state that the maximum is enforced
on literal C2A integer leaves during safe extraction, before owner or Wire
canonicalization.

Do not change the profile identity mapping, manifest, bytes, digest, cap, error
inventory, classifier grammar, source ownership, or current-status projections.

MAXIMUM REPAIR ALLOWLIST

Only these four existing untracked candidate paths may change:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
```

The other twelve candidate paths must remain byte-identical to the opening
manifest.

Because every repair path is untracked, the final tracked textual-diff SHA-256
must remain exactly:

```text
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6
```

No seventeenth dirty path and no new repository file are authorized.

TEST-FIRST RED GATE

Before production source or documentation repair:

1. add or correct tests only in the two authorized Wire test files;
2. preserve every opening node;
3. run one selected causal red gate against opening source/doc bytes;
4. retain exact repository fingerprints after test edits and before/after the
   red run;
5. do not edit source or docs until red evidence is retained.

The red set must include:

- oversized `global_stop_version` proving owner/Wire canonicalization occurs on
  opening bytes;
- oversized nested ceiling proving the same;
- two identical overlength keys proving opening bytes return structural rather
  than duplicate failure;
- the corrected isolated key-pair fixture and its test-local broken control.

A mixed red result is acceptable when the test-adequacy-only fixture already
passes on opening source. Report each expected failure/pass and why.

A causal failure must arise from its intended predicate, not fixture setup,
digest mismatch, relation mismatch, scalar overflow, or another earlier
invariant.

FINAL DIRECT TEST REQUIREMENTS

1. exact-max and `MAX+1` integer cases for command stop version and nested
   ceilings;
2. 1,000-digit integer cases;
3. zero owner/Wire canonicalization calls on every oversized case;
4. valid exact maximum still encodes, decodes, and relates;
5. duplicate/invalid-key overlap matrix;
6. corrected isolated 72-key/70-scalar/2-container key-cap test;
7. all previous parser, traversal, C2A-extraction, classifier, profile, privacy,
   and exception tests remain active and green.

NODE IDENTITY

Opening collection is expected to be `4_653`.

After repair:

- every opening node remains in relative order;
- no opening node is removed, renamed, skipped, xfailed, collapsed, or
  reparameterized;
- every new node belongs to one of the two authorized Wire test files;
- no new node belongs to an existing non-Wire test file;
- report the literal final count and complete addition list;
- do not predeclare the number of additions.

VALIDATION POSTURE

Create one new external operator-owned, non-symlink, mode-0700 repair root.

For every pytest child use:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
actual caller/child numerical umask equality
```

Retain exact argv, environment, timing, return code, stdout/stderr, JUnit,
structured counts, and repository fingerprints.

FINAL VALIDATION ORDER

After source/doc repair and final node collection:

1. selected causal tests;
2. Wire codec;
3. Wire relations;
4. all four Wire files together:
   ```text
   tests/test_rw0_b2_wire_values.py
   tests/test_rw0_b2_wire_codec.py
   tests/test_rw0_b2_wire_relations.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
5. corrected C2A/C2A1:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_c2a_first_slice_semantic_protocol_contract.py
   tests/test_c2a_effects_and_recovery.py
   ```
6. B1:
   ```text
   tests/test_rw0_b1_*.py
   ```
7. static/public:
   ```text
   tests/test_c2a_nonimplementation.py
   tests/test_runtime_non_authority.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_b2a_writer_session_contract.py
   tests/test_codex_agent_config.py
   ```
8. status/docs:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```
9. `git diff --check`;
10. exact path/mode/protected/public/import/residue/operation/lock guards;
11. complete suite attempt 001 exactly once.

Every final focused gate and complete suite must have:

- return code 0;
- zero failures, errors, skips, xfails, warnings;
- empty stderr;
- parseable JUnit;
- no duplicate, ambiguous, or unmapped cases;
- unchanged candidate fingerprint before/after.

COMPLETE-SUITE REPAIR POLICY

If complete-suite attempt 001 fails:

- preserve all evidence;
- repair only when every failure is candidate-caused;
- remain inside the four repair paths and original 16-path candidate;
- preserve fixed profile/caps/authority and final node identities;
- weaken no test;
- rerun affected and dependent focused gates;
- run complete-suite attempt 002 exactly once.

No third complete-suite attempt is authorized.

FINAL PROVENANCE

After final green validation and cleanup:

1. require exact topology:
   - 16 dirty paths
   - 10 tracked modifications
   - 6 untracked additions
   - 0 staged
   - 0 unmerged;
2. run the exact recipe twice;
3. require byte-identical complete outputs and manifests;
4. require exactly the original 16 paths;
5. compare against the opening target;
6. require exactly the four authorized repair paths to differ unless a smaller
   subset sufficed;
7. require the other twelve entries to remain byte-identical;
8. require the tracked textual-diff SHA-256 to remain the pinned value;
9. prove every protected path equals HEAD;
10. retain final recipe source, complete-output hash, textual-diff hash,
    manifest hash, complete manifest, node delta, validation results, and guards.

STOP CONDITIONS

Stop without further mutation if:

- opening provenance differs;
- retained evidence changed;
- a fifth repair path or seventeenth candidate path is needed;
- C2A/B1/public/dependency/schema/migration/runtime bytes must change;
- profile bytes, digest, caps, source ownership, classifications, reasons, or
  precedence must change;
- the exact B2 max cannot be applied before owner/Wire canonicalization while
  preserving valid maximum values;
- the duplicate/invalid-key precedence cannot be corrected without changing the
  frozen decoder reason order;
- tests require skip/xfail/deletion/renaming/weakening;
- existing node identity changes;
- validation or provenance remains unstable.

CLOSEOUT TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_WIRE_THIRD_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only if all three findings are mechanically closed, final validation is
exact-green, provenance is stable, and no stop condition fires.

The report must include:

1. opening identity and immutable target;
2. per-finding repair;
3. red evidence;
4. exact changed paths;
5. integer zero-canonicalization evidence;
6. duplicate/invalid-key precedence matrix;
7. isolated key-pair fixture and broken control;
8. node delta;
9. every validation attempt;
10. final provenance and guards;
11. separate provenance, validation, and implementation confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
PRIOR_AUDIT_EVIDENCE_PRESERVED
```
