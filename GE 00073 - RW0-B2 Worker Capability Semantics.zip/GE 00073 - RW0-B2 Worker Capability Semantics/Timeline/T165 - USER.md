Here is Codex's response:

# Disposition

RW0\_B2\_CAPABILITY\_COMMIT\_COMPATIBILITY\_ASSURANCE\_RESET\_READY

The reset is ready for one parent-only implementation prompt. The self-protecting verifier architecture should be retired, not repaired. No governing contract requires same-interpreter tamper resistance, and every stable repository/product assertion can be preserved in one ordinary pytest file.

# Opening identity

Read-only inspection confirmed:
```
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644

candidate tree:
e70ff57a307539aa3e4c736913e30924e52eebb9
```

Additional confirmations:

- `git diff --check` is clean.
- Cached diff is empty.
- No Git operation marker or lock exists.
- Live status and the sealed 30-path manifest have exactly the same path set.
- All 30 live entries match the manifest’s type, mode, size, and SHA-256.
- There is no thirty-first changed or untracked path.
- HEAD contains 200 tracked paths: the 24 tracked candidate paths differ and the other 176 equal HEAD.
- Candidate-tree identity remains supported by the unchanged base plus the byte-identical sealed manifest; no new provenance artifact was generated.

Current target identity:
```
type: regular
kind: untracked
mode: 0644
size: 272157 bytes
SHA-256: 82cd8d5161950f51bb862ce966772c9014c4575f408325d02113478e0144ca4a
```

Retained manifest identity:
```
size: 6431 bytes
SHA-256: 1dfd2c1d4e265972630cd74bed3fec959b3059c9bd3cc12f42a4ea1f4521a2f0
```

Retained final-node evidence, not recollected in this engagement:
```
count: 5150
ordered SHA-256: 184bd8a792c396cfaa49486761c2b20912d39ced574591818aef0fd86beda9ce
```

Retained G13 self-excluding index:
```
rows excluding itself: 345
size: 52102 bytes
SHA-256: 8145e1b2f1483ec71f8899cf132f4232d59d6795808373e27a4e76f47dba2d38
```

# Current test architecture

The boundary file is 4,612 lines and 272,157 bytes. It currently contains three materially different layers:

1. Sixteen useful nodes that directly test Capability privacy, import direction, package non-export, pure/no-I/O source posture, Wire-owner capture, hostile-input non-retention, process-control propagation, status synchronization, and absence of `StateStore`/`WriterSession` or permission semantics.
2. One 43-row repository projection node containing R01–R30 and P01–P13.
3. Ninety-three nodes devoted solely to protecting the test’s own verifier, fixtures, constants, globals, code objects, source/AST projections, bindings, callsites, callable captures, and encoded expectation carrier.

The third layer is split between an earlier call-surface/G9 verifier and a later G12 verifier with:

- explicit and autouse preflight gates;
- Python binding and callsite emulation;
- callable/global/source/code digests;
- mutable callable captures;
- an encoded Base85/zlib/JSON expectation carrier;
- same-process mutation tests against those mechanisms.

The other three Capability test files supply 37 semantic/value/vector/relation nodes and do not depend on this self-defense architecture. The requested B1, Wire, architecture, progression, runtime-non-authority, C2A, planning, and support files independently preserve their respective contracts.

Whole-file AST and structural inspection found:

- no package-root Capability export;
- no production importer or caller other than the Capability module itself;
- no dependency, schema, migration, `StateStore`, or `WriterSession` widening;
- no contradiction in `.docs`;
- no documentation requiring adversarial self-protection by a pytest module.

The governing documents instead consistently define Capability as private, pure, no-I/O, non-authoritative semantics and place audit isolation and provenance outside product authority.

# Root-cause assessment

The repeated repair cycle has a boundary error, not merely missing verifier cases.

Code with equal authority inside one Python interpreter can replace the test, its fixtures, globals, constants, expected values, helper code, or the mechanism intended to verify those things. Adding another in-module digest or seal only relocates the mutable root of trust.

Accordingly:

- Permanent tests are trusted checked-in code.
- Product regressions are permanent-test concerns.
- Coordinated edits to a test and its oracle are code-review and Git-provenance concerns.
- Causal mutation strength and A/B/C state independence are external-audit concerns.
- Arbitrary same-process checker corruption is not a product-contract threat the test must defeat.

The G13 bypasses therefore do not justify a third verifier generation.

# Assurance responsibility split

| LayerOwned responsibilityExplicit non-responsibility |                                                                                                                                                |                                                                   |
| ---------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------- |
| Permanent repository tests                           | Finite product/repository assertions, literal R/P contracts, package/import/privacy/non-authority boundaries, dirty/staged/clean compatibility | Defending themselves against equal-authority interpreter mutation |
| Independent audit                                    | Static review, no Git/process dependency, external one-predicate mutants, A/B/C comparison, live/clean validation, causal strength             | Becoming another checked-in recursive trust anchor                |
| Git/provenance                                       | Exact changed paths, bytes, modes, tree, staged/committed identity, review visibility                                                          | Product semantics or test execution                               |
| Commit gate                                          | Exact accepted staging, staged-tree check, one collection, one full suite, exact commit/push/PR                                                | Replacing permanent assertions or independent review              |

The permanent 30-path table is a normative contract inventory. It must not inspect the current dirty set. Actual changed-set equality and absence of a thirty-first path remain Git/provenance responsibilities.

# G13 finding dispositions

A repository-byte change below means deletion of rejected machinery, not an attempt to repair it.

| FindingClassificationDispositionRepository byte change |                                           |                                                                                                                                             |                                                                  |
| ------------------------------------------------------ | ----------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------- |
| F-001 shared self-sealing verifier bypass              | `REJECTED_ASSURANCE_ARCHITECTURE_SYMPTOM` | Equal-authority mutation can replace the common verifier. Delete the common self-seal.                                                      | Yes, deletion in the boundary test only                          |
| F-002 simultaneous local-gate alteration               | `REJECTED_ASSURANCE_ARCHITECTURE_SYMPTOM` | Explicit and autouse gates share the same mutable process and are not independent roots. Delete both.                                       | Yes, deletion only                                               |
| F-003 mutable carrier/captures authenticate themselves | `REJECTED_ASSURANCE_ARCHITECTURE_SYMPTOM` | The encoded carrier and captured callables remain mutable interpreter objects. Delete both mechanisms.                                      | Yes, deletion only                                               |
| F-004 `co_exceptiontable` omitted from code seal       | `REJECTED_ASSURANCE_ARCHITECTURE_SYMPTOM` | Expanding the code-object projection would perpetuate the rejected design. Delete code-object authentication.                               | Yes, deletion only                                               |
| F-005 incomplete Python 3.13 binding grammar           | `REJECTED_ASSURANCE_ARCHITECTURE_SYMPTOM` | A repository test should not implement a generic evolving Python binder. Delete the language emulator.                                      | Yes, deletion only                                               |
| F-006 callsite ledger lacks execution context          | `REJECTED_ASSURANCE_ARCHITECTURE_SYMPTOM` | Static callsite enumeration cannot become a complete execution semantics engine. Delete the ledger.                                         | Yes, deletion only                                               |
| F-007 G12 evidence-root audit contamination            | `AUDIT_PROCESS_DEFECT`                    | Prior-root bytecode residue is an audit hygiene failure, not a candidate defect. Use a new root and `-B`; do not clean the sealed old root. | No                                                               |
| F-008 incomplete runtime-root inventory                | `REJECTED_ASSURANCE_ARCHITECTURE_SYMPTOM` | Exhaustively inventorying mutable interpreter roots is open-ended. Delete runtime-root sealing.                                             | Yes, deletion only                                               |
| F-009 lexical path-provenance defect                   | `EXTERNAL_AUDIT_REQUIREMENT`              | Constructed Git/metadata paths must be detected by an external static/behavioral audit, not by a self-certifying in-module callsite oracle. | Yes: delete the local oracle; no replacement repository verifier |
| F-010 attempt-032 chronology inaccuracy                | `PROVENANCE_OR_EVIDENCE_DEFECT`           | Future recorders must distinguish parser/help completion, child launch, and credited run outcome.                                           | No                                                               |

None of F-001–F-010 establishes a production/public/privacy/authority defect. No finding is classified as `REAL_PERMANENT_TEST_DEFECT`.

# Replacement permanent-test contract

Use two direct literal tables.
```
REQUIRED_CANDIDATE_ROWS:
(row_id, relative_path, expected_mode, contract_classes, purpose)

PROTECTED_CONTENT_ROWS:
(row_id, relative_path, expected_size, expected_sha256,
 contract_classes, purpose)
```

Every R row has the common predicates `required_path`, `regular_file`, and mode `0644`. Every P row has `protected_content` and `regular_file`.

The R table remains exactly:
```
R01 .docs/authority-boundaries.md                                  authority_non_effect
R02 .docs/autonomous-software-development-operating-model.md       authority_non_effect
R03 .docs/c2a-first-slice-semantic-protocol-contract.md            authority_non_effect
R04 .docs/c2a1-pure-semantic-values.md                             authority_non_effect
R05 .docs/durable-state-model.md                                   state_store_writer_session
R06 .docs/rw0-b1-pure-phase-values.md                              authority_non_effect
R07 .docs/rw0-b2-capability.md                                     private_module_export
R08 .docs/rw0-b2-wire-protocol.md                                  authority_non_effect
R09 .docs/rw0-remote-worker-contact-phase-entry.md                 authority_non_effect
R10 .docs/worker-execution-boundary.md                             authority_non_effect
R11 src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
                                                                    authority_non_effect
R12 src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py      authority_non_effect
R13 src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
                                                                    private_module_export,
                                                                    production_importer_caller
R14 src/ge_nwp_coordinator/_worker_execution_semantic_values.py     authority_non_effect
R15 tests/test_architecture_contracts.py                            authority_non_effect
R16 tests/test_c2a_nonimplementation.py                            authority_non_effect
R17 tests/test_runtime_non_authority.py                            authority_non_effect
R18 tests/test_rw0_b1_boundaries.py                                authority_non_effect
R19 tests/test_rw0_b1_phase_values.py                              authority_non_effect
R20 tests/test_rw0_b1_relations.py                                 authority_non_effect
R21 tests/test_rw0_b2_capability_boundaries.py                     no additional class
R22 tests/test_rw0_b2_capability_relations.py                      private_module_export
R23 tests/test_rw0_b2_capability_values.py                         private_module_export
R24 tests/test_rw0_b2_capability_vectors.py                        private_module_export
R25 tests/test_rw0_b2_wire_boundaries.py                           authority_non_effect
R26 tests/test_rw0_remote_contact_phase_entry_contract.py          authority_non_effect
R27 tests/test_section41_pre_execution_plan_disposition_contracts.py
                                                                    authority_non_effect
R28 tests/test_software_development_progression_boundary.py         state_store_writer_session
R29 tests/test_worker_execution_semantic_boundaries.py              authority_non_effect
R30 tests/test_worker_execution_semantic_values.py                  authority_non_effect
```

The P table remains exactly:

| IDPathBytesSHA-256Special class |                                                                                |        |                                                                    |                             |
| ------------------------------- | ------------------------------------------------------------------------------ | ------ | ------------------------------------------------------------------ | --------------------------- |
| P01                             | `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py`                          | 77003  | `6bf39f634b619829fcc4cc7ada5cf019b40b3c5a2258947ebee8fdfe2a13031e` | authority non-effect        |
| P02                             | `src/ge_nwp_coordinator/_development_author_effect_establishment_contracts.py` | 63518  | `f6938024436a765a69e9a44d20d834a85075ba10b821e61e3e91bfb09cf17af0` | authority non-effect        |
| P03                             | `src/ge_nwp_coordinator/_development_decision_row_values.py`                   | 53230  | `9e0e9c0695adb9f0ad72d9d92c6859c995c2c5ade154a5546f0a1efc347db8ae` | dependency/schema/migration |
| P04                             | `src/ge_nwp_coordinator/_development_effect_row_values.py`                     | 64606  | `bbe52faf7ad69e2e643a404808cb0e68d4f7c76a668426d58029a7c108cfa158` | dependency/schema/migration |
| P05                             | `src/ge_nwp_coordinator/_development_program_row_values.py`                    | 60276  | `d8557eac3f4956c6fdedaf851b9f230f871d0d41eb381fdb09cdecece8df6422` | dependency/schema/migration |
| P06                             | `src/ge_nwp_coordinator/__init__.py`                                           | 2385   | `60230ae31032071ab52b16c3537a1b2b398e06a4b1f4ec926485471927b2f2b5` | private package export      |
| P07                             | `pyproject.toml`                                                               | 330    | `c59ff8c0005b063636ff161002f1b1c45a81227b4ed30a988412f01a474e0ac9` | dependency/schema/migration |
| P08                             | `tests/c2a_contract_support.py`                                                | 154329 | `4952d25086220632c969a29e44b9abe29b966fbb031d2305c11d4bf13d39c4f1` | authority non-effect        |
| P09                             | `tests/test_c2b2_development_row_value_boundaries.py`                          | 17823  | `4c892136f8c6fd629eb44e95bc8dd7a9aa1a5250e97cc61499171f2835bb4f42` | dependency/schema/migration |
| P10                             | `tests/test_codex_agent_config.py`                                             | 1082   | `0691c90c0178632a793a93595ba344169fb9b9669de155939fb4873db2f0d3ee` | authority non-effect        |
| P11                             | `AGENTS.md`                                                                    | 58903  | `ab3e788e3086088eb5caa2cf392a9ccb9582b645c082897574e55234aec860c8` | authority non-effect        |
| P12                             | `README.md`                                                                    | 43280  | `093134d136a8dc246c9a9c1557a95c3b5500007b8ccfd3a4cac0722b1a0aa1d4` | authority non-effect        |
| P13                             | `.docs/software-development-progression-boundary.md`                           | 27194  | `3b0c21f73048e458bd750b9896fbae7c285a4b35799b99060aef03d8379052fe` | StateStore/WriterSession    |

The exact new tests are:
```
test_required_candidate_surface_is_literal_unique_regular_and_mode_0644
test_protected_content_surface_has_exact_literal_identities
test_boundary_contract_rows_are_literal_complete_unique_and_consistent
```

They should:

- use `Path.lstat()`, `stat.S_ISREG`, `stat.S_IMODE`, `read_bytes()`, and `hashlib.sha256`;
- assert literal R01–R30 and P01–P13 sequences, uniqueness, disjointness, purposes, and required contract-class coverage;
- emit only fixed row IDs and predicate names on failure;
- never report observed bytes, digests, private content, Git status, or process output;
- contain no self-source, self-AST, code-object, binding, callsite, or callable authentication.

Target size is 600–800 lines. The hard ceiling is 900 lines and 64 KiB. Crossing either ceiling requires review before proceeding.

# Exact retained and removed surfaces

Retain these imports:
```
ast
hashlib
importlib.util
stat
sys
types
Path
pytest
Capability module and its five current imported symbols
```

Retain these constants:
```
ROOT
SOURCE
PACKAGE
OWNER
OWNER_BEGIN / OWNER_END
STATUS_BEGIN / STATUS_END
STATUS_PATHS
EXPECTED_STATUS
```

Retain these helpers:
```
normalize
extract_visible_block
assert_owner_layout
_owned_capability_frame
_contains_hostile_identity
_failed_isolated_capability_import
```

Replace:
```
EXPECTED_PATHS
PROTECTED_PATHS
EXPECTED_PATHS_SHA256
PROTECTED_PATH_IDENTITIES
EXPECTED_BOUNDARY_ROWS
PROTECTED_ROW_IDS
_protected_content_row
_stable_capability_boundary_projection
```

with:
```
REQUIRED_CANDIDATE_ROWS
PROTECTED_CONTENT_ROWS
_assert_regular_mode_0644
_assert_exact_content_identity
```

Delete entirely:

- `_BOUNDARY_ACCEPTED_*`;
- all `BOUNDARY_*` call/global/runtime ledgers and digests;
- `_scope_nodes` through `_closed_boundary_call_surface`;
- `CALL_SURFACE_*`, `LEGACY_CALL_SURFACE_*`, and G9 mutation builders;
- runtime-global and runtime-callable captures/seals;
- `_materialize_boundary_fixture`, mutation compilers, payload-byte mutation helpers;
- `PROTECTED_CAUSAL_CASES`;
- every `G12_*` constant, helper, ledger, capture, fixture, and test;
- `capability_boundary_preflight`;
- `capability_boundary_target_gate`;
- `_BOUNDARY_ACCEPTED_TARGET`;
- the Base85/zlib/JSON literal carrier;
- now-unused imports `base64`, `builtins`, `functools`, `inspect`, `json`, `os`, `textwrap`, and `zlib`.

Retain the following product-contract tests unchanged except for harmless formatting/import cleanup:
```
test_exact_private_import_direction_exports_and_public_surface
test_source_is_pure_static_and_has_no_runtime_or_storage_mechanism
test_wire_owner_is_loaded_once_fixed_and_manifest_is_not_retained
test_wire_owner_callable_is_deleted_after_the_single_import_time_load
test_hostile_wire_owner_key_is_sanitized_without_foreign_equality
test_wire_owner_loader_sanitizes_every_malformed_shape
test_failed_wire_import_retains_no_hostile_owner_graph
test_wire_capture_propagates_process_control
test_owner_and_five_status_projections_are_visible_unique_and_synchronized
test_error_and_value_surface_is_exactly_private_semantics
```

The in-memory malformed-owner and visible-document mutants inside retained product tests remain valid ordinary unit-test inputs; they are not attempts to authenticate the test implementation itself.

# Touched-file ceiling

The reset can and must be implemented in exactly one file:

[tests/test\_rw0\_b2\_capability\_boundaries.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b2_capability_boundaries.py>)

No production source or governing document needs modification:

- the product contract does not change;
- existing `.docs` already describes the private/no-I/O/non-authority reality;
- no document claims the retired verifier is authoritative;
- the replacement retains every real product/public/privacy/authority assertion.

A second file is not authorized. Discovery that a second file is genuinely necessary is a redesign trigger requiring a new decision.

# Node migration policy

Every current boundary-test function has this disposition:

| Current testNodesDisposition                                                 |    |         |
| ---------------------------------------------------------------------------- | -- | ------- |
| `test_exact_private_import_direction_exports_and_public_surface`             | 1  | retain  |
| `test_closed_reachable_call_surface_and_mutation_matrix`                     | 1  | remove  |
| `test_g9_repair_causal_source_cases`                                         | 18 | remove  |
| `test_g9_repair_causal_inventory_is_unique_and_complete`                     | 1  | remove  |
| `test_runtime_global_mutant_expectations_are_literal_and_independent`        | 1  | remove  |
| `test_runtime_callable_seal_is_causally_sensitive`                           | 3  | remove  |
| `test_source_is_pure_static_and_has_no_runtime_or_storage_mechanism`         | 1  | retain  |
| `test_wire_owner_is_loaded_once_fixed_and_manifest_is_not_retained`          | 1  | retain  |
| `test_wire_owner_callable_is_deleted_after_the_single_import_time_load`      | 1  | retain  |
| `test_hostile_wire_owner_key_is_sanitized_without_foreign_equality`          | 1  | retain  |
| `test_wire_owner_loader_sanitizes_every_malformed_shape`                     | 1  | retain  |
| `test_failed_wire_import_retains_no_hostile_owner_graph`                     | 5  | retain  |
| `test_wire_capture_propagates_process_control`                               | 3  | retain  |
| `test_owner_and_five_status_projections_are_visible_unique_and_synchronized` | 1  | retain  |
| `test_exact_twenty_path_ceiling_modes_and_protected_controls`                | 1  | replace |
| `test_every_protected_content_row_is_causally_mutation_sensitive`            | 13 | remove  |
| `test_exact_audit_protected_assertion_weakening_is_killed`                   | 1  | remove  |
| `test_error_and_value_surface_is_exactly_private_semantics`                  | 1  | retain  |
| `test_g12_every_binding_capable_survivor_is_rejected`                        | 11 | remove  |
| `test_g12_runtime_callable_mutants_are_rejected`                             | 12 | remove  |
| `test_g12_target_signature_requires_preflight_dependency`                    | 1  | remove  |
| `test_g12_binding_ledgers_preserve_order_and_scope`                          | 1  | remove  |
| `test_g12_binding_literal_ledger_mutants_are_rejected`                       | 10 | remove  |
| `test_g12_python_callable_literal_digest_mutants_are_rejected`               | 3  | remove  |
| `test_g12_external_callable_literal_digest_mutants_are_rejected`             | 3  | remove  |
| `test_g12_external_python_observations_include_source_ast_and_code`          | 1  | remove  |
| `test_g12_removing_target_preflight_dependency_is_rejected`                  | 1  | remove  |
| `test_g12_fixture_unavailable_or_rebound_is_rejected`                        | 2  | remove  |
| `test_g12_ordered_callsite_and_provenance_mutants_are_rejected`              | 9  | remove  |
| `test_g12_module_global_literal_integrity_is_independent`                    | 1  | remove  |

Exact migration arithmetic:
```
current boundary nodes:       110
retained product nodes:        16
self-protection nodes removed: 93
old projection node retired:    1
new bounded contract nodes:      3
prospective boundary nodes:     19

current whole suite:          5150
unrelated nodes retained:     5040
prospective whole suite:      5059
```

Raw node-ID comparison should show 94 removals and 3 additions. Semantically, that is one projection-test rename/replacement plus two additions and 93 self-protection removals.

The 5,040 nodes outside this file must retain exact order. The final count is credited only after collection. Any difference from 5,059 must be explained from the collected lists; it must not be hidden with skip, xfail, or volume-preserving placeholder tests.

# Validation and evidence contract

The implementation validation order is frozen as:

1. Opening identity/provenance.
2. Opening collection.
3. Test-first red for the simplified contract where applicable; use an external one-predicate mutant when the canonical contract already passes.
4. Implement only the frozen one-file reset.
5. Run the complete modified boundary file.
6. Run Capability complete.
7. Run B1/Wire compatibility.
8. Run architecture/status/static compatibility.
9. Run A/B/C target and projection checks.
10. Run final collection and produce explicit node migration.
11. Run one live complete suite.
12. Run one fully external clean-commit complete suite.
13. Run exact guards and cleanup checks.
14. Run two final provenance checks.
15. Run a fresh independent audit.

Mandatory retained evidence:
```
opening and final repository identity
exact changed paths and bytes
opening and final ordered node lists
final focused run records
A/B/C records
live and clean complete-suite records
run-local pre/post candidate fingerprints
final manifests
guards and cleanup
self-excluding evidence index
```

Credited executions must have explicit command, interpreter, environment, return code, test/error/failure/skip counts, candidate pre/post fingerprint, and evidence identity. Exploratory commands are reported honestly but are not recursively promoted into candidate-correctness proof.

The commit gate remains separate: stage only the accepted manifest, verify the exact staged tree, collect once, run the complete suite once against the staged or clean candidate, commit that exact tree, push that exact commit, and open one PR.

# Fresh independent-audit contract

The fresh auditor must use a new audit root and bytecode-disabled imports. It must independently verify:

- no transient dirty/staged Git-state dependency in the permanent test;
- no `subprocess`, process execution, Git command, repository-metadata, or constructed `.git` dependency during normal test execution;
- exact literal R01–R30 and P01–P13 ownership;
- exact P sizes and digests;
- package non-export and absence of production importer/caller;
- dependency/schema/migration, `StateStore`/`WriterSession`, privacy, no-I/O, and non-authority preservation;
- A/B/C equality across unstaged, staged-tree, and clean-commit representations;
- live and external-clean complete-suite success;
- exact candidate/protected provenance.

The audit must build an external mutant ledger from the final test AST:

- one unique mutant ID per owned assertion or row-expanded predicate;
- one predicate changed per mutant;
- canonical control passes;
- mutant fails at the named test and content-free diagnostic;
- R-row path/type/mode predicates are individually covered;
- P-row path/type/size/digest predicates are individually covered;
- literal inventory, uniqueness, disjointness, class coverage, import, public-surface, privacy, and non-authority assertions are individually covered;
- test-copy mutants live only in disposable external copies.

It must not mutate both the checker and its expected oracle in one interpreter and call that a candidate threat. It must not require the permanent test to detect replacement of its own functions, fixtures, constants, globals, code objects, builtins, or pytest machinery.

# Risks and redesign triggers

Known bounded risks:

- P hashes intentionally make protected-file changes explicit; a legitimate protected-file change requires a new contract decision, not a silent hash refresh.
- Filesystem mode checks assume the repository’s supported POSIX execution environment.
- The literal 30-path table does not prove live Git dirtiness; Git provenance deliberately owns that fact.
- Trusted tests can still be edited together with their literals, but Git diff/tree/review makes that change externally visible.
- Final node count 5,059 is prospective until actual post-reset collection.

Implementation must stop for a new decision if:

- governing documentation is found to require adversarial test self-protection;
- a state-independent boundary cannot be expressed without Git/process/status calls;
- the literals would conflict with an owning semantic contract;
- more than the one authorized file is required;
- simplification would remove a real production/public/privacy/authority contract without replacement.

None of those conditions is presently established.

# Next implementation prompt boundary

The next prompt may authorize a parent-only implementation with this exact ceiling:

1. Reconfirm the opening identity and manifest.
2. Modify only `tests/test_rw0_b2_capability_boundaries.py`.
3. Preserve the 16 retained product nodes and their behavior.
4. Replace the existing projection with the three named ordinary tests and the two literal row tables.
5. Delete all self-source/self-AST/code/binding/callsite/runtime-capture/dual-gate/carrier machinery.
6. Add no production import, public export, dependency, schema, migration, `StateStore`, `WriterSession`, I/O, authority, worker, provider, or runtime behavior.
7. Keep the result at or below 900 lines and 64 KiB.
8. Execute the frozen validation sequence and produce the exact node migration.
9. Use a fresh external audit root with bytecode disabled.
10. Do not stage, commit, push, or create a PR unless a later prompt separately authorizes the commit gate.
11. Stop if the one-file ceiling or any governing boundary cannot be maintained.

# Confidence

Confidence is high. The reset is supported by the current source structure, the complete requested inspection scope, the governing `.docs`, the retained node evidence, and all ten G13 findings. No contract contradiction or second-file need was found.

One read-only manifest-comparison attempt stopped because zsh’s special `path` variable shadowed `PATH`; it produced no result and changed no state. The comparison was rerun under Bash with a non-reserved variable and confirmed all 30 entries exactly.

Supplementary provenance, listed after the decisions and implementation boundary:
```
/private/tmp/g13.p4eDNA
/private/tmp/g13.p4eDNA/evidence_index.jsonl
/private/tmp/g13.p4eDNA/abc_audit.json
/private/tmp/g13.p4eDNA/code_probe.json
/private/tmp/g13.p4eDNA/global_probe.json
/private/tmp/g13.p4eDNA/grammar_probe.json
/private/tmp/g13.p4eDNA/callsite_probe.json
/private/tmp/g13.p4eDNA/chronology_audit.json
/private/tmp/g13.p4eDNA/node_comparison.json
/private/tmp/g13.p4eDNA/provenance_gate.json
/private/tmp/g13.p4eDNA/closeout.json
/private/tmp/g13.p4eDNA/closing_recipe1/manifest.json
/private/tmp/g12.1d9AdI/final/prevalidation_manifest.json
```

This engagement used parent-only inspection. No subagent was created or consulted.
```
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
NODE_COLLECTION_NOT_RUN
MUTATION_PROBES_NOT_RUN
THREE_STATE_SIMULATION_NOT_RUN
FULL_SUITE_NOT_RUN
CORRECTNESS_AUDIT_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
```
