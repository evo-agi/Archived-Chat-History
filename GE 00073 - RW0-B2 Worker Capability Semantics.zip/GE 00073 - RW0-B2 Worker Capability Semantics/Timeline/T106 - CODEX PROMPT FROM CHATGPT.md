PROMPT_ID

RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_REPAIR_EVIDENCE_GAP_DIAGNOSTIC_V1

TITLE

Coordinator RW0-B2-Capability — diagnose REPORT_EVIDENCE_INCOMPLETE and
determine the minimum evidence-only or validation continuation

ENGAGEMENT TYPE

Read-only evidence diagnosis in the same write-enabled implementation
conversation that returned:

COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

and then, when asked for the complete closeout report, returned:

REPORT_EVIDENCE_INCOMPLETE

This is not implementation, correctness audit, staging, commit, push, PR,
merge, release, deployment, provider/runtime work, or supporting-repository
work.

Do not edit repository files. Do not rerun pytest, test collection, mutation
probes, or implementation commands in this engagement. Do not alter prior
evidence roots. Read-only Git and filesystem inspection is authorized.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED LIVE IDENTITY

Require and report:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

expected topology:
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
all candidate paths regular mode 0644
```

Opening repair target:

```text
canonical manifest:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB/final_recipe_1/manifest.json

manifest SHA-256:
47ec8ecbd89aaa0924dc3d222f2292b9046d0faaabfadd4850411473aa33f51c

complete recipe-output SHA-256:
3777b40b27cc2e13513eb08c02d77064feea6263cfc56691517531cd0d4b39b7

tracked textual-diff SHA-256:
614568d397cf4eee772a25d588e31008731b326d7ac04988084018fcfc4da9aa

opening pytest nodes:
5002

opening ordered-node-list SHA-256:
11b13eebe8ff9631071da1f83a85d342b83ea4754a2c3765c0c227bf18f97a49
```

Latest independent-audit evidence:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3

report:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3/audit_report.md

index:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3/evidence_index.jsonl

index rows excluding itself:
71

index SHA-256:
26b69c39d083cd2096c8e2b47c6afbef7626d24cbd55093fcabe659be23a06bb
```

The authorized repository repair paths were only:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The claimed successful repair token covered:

```text
B1-PARSER-001
B1-LOCATION-002
RW0-TEST-003
EVID-RENAME-004
```

OBJECTIVE

Identify exactly which mandatory closeout evidence is incomplete, whether the
current live candidate still matches the bytes that produced the success
token, and the minimum authorized continuation.

Do not answer only with REPORT_EVIDENCE_INCOMPLETE.

MANDATORY DIAGNOSTIC

1. Verify live repository identity, topology, modes, staged/unmerged state,
   `git diff --check`, operations, locks, and residue.

2. Locate every external evidence root created during the repair turn. Do not
   guess a single root. Use retained command records, timestamps, terminal
   output, shell history available inside the conversation, and safe
   filesystem metadata.

3. Safely `lstat` every evidence-root path component before reading it.

4. For every candidate evidence root, inventory:

```text
absolute path
owner/group/mode
directory/file/symlink posture
creation/modification times
regular file count
directory count
special/symlink count
total regular bytes
candidate final-report records
candidate provenance records
candidate validation records
candidate node records
candidate migration records
candidate cleanup/guard records
```

5. Determine whether the success token was based on retained evidence, terminal
   observations only, or unretained/transient records.

MANDATORY EVIDENCE MATRIX

For each item report exactly one status:

```text
PRESENT_VERIFIED
PRESENT_INCOMPLETE
DERIVABLE_READ_ONLY
MISSING_REQUIRES_VALIDATION_RERUN
MISSING_REQUIRES_IMPLEMENTATION_RERUN
NOT_APPLICABLE
```

Items:

A. opening identity and opening-manifest reproduction;

B. pre-edit/post-edit changed-path identities;

C. exact final canonical manifest;

D. exact tracked textual-diff SHA-256;

E. both final recipe runs and complete outputs;

F. exact two-path delta and 28-path equality ledger;

G. selected red/control gate for all four findings;

H. B1 canonical parser reuse proof;

I. B1 bounded visible-H2 causal results;

J. primary/cross B1 parser equivalence corpus and results;

K. RW0 fence real/sensitivity-mutant ledger;

L. corrected complete migration ledger;

M. explicit rename record with:

```text
old_node_id:
tests/test_rw0_b1_boundaries.py::test_owner_has_one_current_retrieval_maximum_and_one_current_consumer

new_node_id:
tests/test_rw0_b1_boundaries.py::test_b1_live_registry_projection
```

N. rename one-to-one reconciliation record;

O. opening 5,002-node list;

P. final node list and ordered SHA-256;

Q. node additions/removals/renames and migration arithmetic;

R. focused validation summaries, stdout/stderr, JUnit, argv, environment,
   umask, and before/after fingerprints;

S. full-suite summary, stdout/stderr, JUnit, exact node mapping, attempt count,
   and before/after fingerprint;

T. final path/mode/import/public/authority guards;

U. cleanup record;

V. self-excluding evidence index;

W. final complete closeout report.

LIVE BYTE STATUS

Without running tests:

1. hash the two authorized repository paths and compare them with:
   - the opening manifest;
   - any retained post-repair manifest or path hashes;
   - any terminal report fragments;

2. verify the other 28 candidate entries still match the opening manifest;

3. verify every path outside the 30-path candidate equals HEAD;

4. report whether current bytes are:
   - exactly the claimed final repaired bytes;
   - changed after the success token;
   - or not bindable because no final target was retained.

READ-ONLY DERIVATION RULES

A record is `DERIVABLE_READ_ONLY` only when it can be reconstructed exactly
from immutable retained evidence without rerunning pytest or mutation probes.

Examples that may be derivable read-only:

- a final manifest from an existing retained exact recipe run;
- per-path hashes from an indexed manifest;
- a rename mapping from a retained corrected ledger plus opening/final node
  lists when the implementation explicitly recorded both endpoints elsewhere;
- an aggregate report assembled from already retained immutable records.

Examples that are not derivable read-only:

- a missing JUnit file;
- an unrecorded pytest result;
- an unrecorded mutation-sensitivity result;
- an unrecorded node collection;
- an unrecorded before/after fingerprint;
- an unrecorded full-suite attempt.

Do not invent or summarize absent evidence as if it existed.

DISPOSITION TOKENS

Return exactly one primary token.

### 1. EVIDENCE_ONLY_CLOSEOUT_REGENERATION_READY

Use only when:

- live candidate bytes are stable and bindable;
- all correctness/validation evidence already exists;
- missing items are only reports, indexes, aggregate summaries, or other
  read-only derivations;
- no pytest, collection, mutation, or implementation rerun is required.

Then provide:

- exact evidence-only continuation scope;
- exact records to regenerate;
- exact source records from which each is derived;
- exact final evidence-index requirements;
- no repository mutation.

### 2. VALIDATION_EVIDENCE_RERUN_REQUIRED

Use when:

- live candidate bytes are stable;
- source implementation need not change;
- one or more mandatory validation records are missing and cannot be derived
  read-only.

Then identify the minimum exact reruns required, separately:

```text
selected causal only
focused group(s)
node collection
full suite
provenance only
```

Do not authorize the reruns in this diagnostic. Provide the exact proposed
next continuation boundary.

### 3. IMPLEMENTATION_RERUN_REQUIRED

Use only when:

- the repository repair itself was not completed;
- the live bytes do not contain the claimed repair;
- or source/test edits must be repeated.

List the exact incomplete finding and path.

### 4. LIVE_CANDIDATE_BYTES_DRIFTED

Use when current repository bytes changed after the success token. Report every
changed path and do not credit the stale token.

### 5. REPORT_PROVENANCE_MISMATCH

Use when opening repository identity or retained opening/audit evidence differs
from the expected baseline.

### 6. EVIDENCE_LOSS_UNRECOVERABLE

Use only when mandatory evidence and the exact final byte target are both
unavailable and cannot be recovered without repeating implementation from an
untrusted state.

REQUIRED QUESTIONS

Answer explicitly:

1. What exact mandatory item first caused REPORT_EVIDENCE_INCOMPLETE?

2. What other mandatory items are missing?

3. Did the repair create a new evidence root?

4. Do the current two test files contain the claimed parser/fence changes?

5. Does a retained final canonical manifest exist?

6. Does a retained final node list exist?

7. Does retained full-suite JUnit exist?

8. Does the corrected migration ledger with explicit `new_node_id` exist?

9. Can a complete closeout report be generated without rerunning pytest?

10. Does the next action belong in:
    - the same implementation conversation as evidence-only work;
    - the same implementation conversation with validation reruns;
    - or a new implementation pass?

FINAL RESPONSE

Include:

1. primary disposition token;
2. exact first missing item;
3. complete evidence matrix;
4. live-byte status;
5. minimal continuation boundary;
6. exact next success token to require;
7. separate provenance, validation-binding, and implementation confidence.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
CORRECTNESS_AUDIT_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
```
