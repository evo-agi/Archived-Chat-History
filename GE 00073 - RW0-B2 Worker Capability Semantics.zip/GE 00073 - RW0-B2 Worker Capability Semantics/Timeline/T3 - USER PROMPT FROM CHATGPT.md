The B2 decomposition is accepted, but the split should also split the
reconnaissance readiness gate.

The currently issued RW0-B2 reconnaissance prompt has not yet been executed.
Treat it as an unexecuted draft and issue one complete self-contained
replacement. Do not provide a delta or ask me to combine prompts.

Preserve the accepted engineering decisions:

- RW0-B2-Wire precedes RW0-B2-Capability;
- Wire owns framing, hostile decoding, worker-result grammar, bounded protocol
  processing, and process/result classification;
- Capability owns provider-neutral declaration, independent observation, and
  qualification semantics;
- concrete CLI versus App Server selection, credentials, invocation, provider
  sessions, and physical process behavior remain RW0-D/E;
- B1 remains unchanged;
- no digest, frame, result, declaration, observation, or qualification grants
  authority or acceptance.

Revise the reconnaissance objective and verdict structure as follows.

1. Wire freeze

The reconnaissance must produce an implementation-ready RW0-B2-Wire packet
before Wire implementation may begin. Wire readiness requires exact:

- command and result composition;
- byte framing;
- canonical encoding and hostile decoding;
- duplicate-key, UTF-8, truncation, trailing-data, and noncanonical handling;
- worker-result grammar;
- process/result classification and precedence;
- payload, depth, cardinality, and cumulative-work derivations;
- error algebra;
- module/import direction;
- touched-file ceiling;
- tests, validation, provenance, and stop conditions.

2. Capability seam review

In the same reconnaissance, establish enough of RW0-B2-Capability to prove that
the Wire design does not preclude it.

Require source-grounded decisions on:

- declaration, independent observation, and qualification remaining distinct;
- no self-observation or self-qualification;
- no source authentication, permission, acceptance, or executable authority;
- binding to an exact accepted Wire protocol profile;
- binding to supplied positive B1 phase/effect/host qualification;
- provider and mechanism neutrality;
- safe provenance without provider-session history becoming program truth;
- ownership by B2 versus later D/E;
- contradictions that would invalidate Wire.

Do not require an exact implementation-ready Capability class inventory,
field list, reason precedence, freshness grammar, numeric process bounds, or
touched-file plan unless repository evidence establishes that those decisions
are independent of the later concrete mechanism and observer.

3. Separate readiness dispositions

The final response must separately state:

Wire status:
- RW0_B2_WIRE_RECONNAISSANCE_READY
- RW0_B2_WIRE_RECONNAISSANCE_PARTIAL
- RW0_B2_WIRE_RECONNAISSANCE_BLOCKED

Capability status:
- RW0_B2_CAPABILITY_SEAM_BOUNDED
- RW0_B2_CAPABILITY_FREEZE_READY
- RW0_B2_CAPABILITY_BLOCKED

Wire may be READY while Capability is only SEAM_BOUNDED.

Capability uncertainty blocks Wire only when it demonstrates that the proposed
Wire bytes, identities, result grammar, or process/result classifications would
make the later provider-neutral capability contract incoherent or require
breaking accepted ownership boundaries.

4. Progression

If Wire is READY and Capability is SEAM_BOUNDED or FREEZE_READY, the next
permitted design step is one bounded RW0-B2-Wire implementation prompt.

Do not issue or imply a Capability implementation prompt until Wire is
implemented and independently accepted, unless the reconnaissance proves a
concrete reason that the two must be implemented atomically.

Preserve the existing read-only posture, current baseline, four-explorer
investigation, contradiction challenges, mechanically derived caps, provenance
requirements, and no-mutation rules. Preserve the existing prospective
forecasts as discussion evidence.

Return the engineering explanation followed by the complete replacement Codex
prompt, clearly delimited for copying.
