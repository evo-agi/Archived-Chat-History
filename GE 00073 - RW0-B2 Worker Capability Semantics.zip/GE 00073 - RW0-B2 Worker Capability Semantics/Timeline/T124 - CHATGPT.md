## Engineering disposition

`AUDIT_PROVENANCE_MISMATCH` is **not a correctness verdict** on the repaired test. The auditor stopped before inspecting parser behavior, the 43-row projection, the three Git states, or either full-suite record.

Do not:

- return to implementation repair;
- rerun tests;
- start another independent audit;
- stage or commit.

First identify the exact failed provenance predicate. The likely classes are materially different:

```text
live candidate bytes differ from the retained final manifest
final evidence index or manifest identity mismatch
mandatory three-state or full-suite evidence absent/unindexed
opening accepted target or one-file delta mismatch
recipe-source or replay mismatch
audit-wrapper defect
over-specified audit-prompt expectation
stale report metadata
```

Only the first few would require implementation-side action. A prompt or wrapper defect can be reconciled read-only in the same audit conversation.

## Provenance diagnostic handoff

Continue in the **same read-only audit conversation** with this prompt:

:chatgpt-content-reference{index="0"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Commit_Compatibility_Reaudit_Provenance_Mismatch_Diagnostic_Prompt.txt

Size:
14,718 bytes

SHA-256:
fa5d8b11a96cf319d9a61a34f904596f07808b04c1a31613a3d953e6f89504f8
```

The diagnostic authorizes:

- no tests;
- no node collection;
- no correctness audit;
- no repository or real-index mutation;
- no remote contact.

It requires Codex to identify the **first failed predicate**, then independently report the status of:

```text
live repository identity and topology
final evidence index
final canonical manifest
one-file opening-to-final delta
recipe source and replay
node evidence
three-state evidence
43-row projection and mutant evidence
live full-suite evidence
clean-commit full-suite evidence
final guards and cleanup
all prior required evidence indexes
```

For every mismatch, it must provide exact expected and observed values, their provenance, candidate-byte impact, validation-binding impact, and whether the problem can be reconciled read-only.

The required primary outcome is one of:

```text
PROVENANCE_BASELINE_READY
IMPLEMENTATION_REPORT_STALE_BYTES
FINAL_EVIDENCE_TARGET_MISMATCH
MANDATORY_EVIDENCE_UNAVAILABLE
AUDIT_WRAPPER_REPAIR_REQUIRED
AUDIT_PROMPT_EXPECTATION_DEFECT
PROVENANCE_RECIPE_FAILURE
OPENING_TARGET_MISMATCH
DIAGNOSTIC_INCOMPLETE
```

### Decision path

- `PROVENANCE_BASELINE_READY`: continue the same correctness audit against a corrected exact target.
- `AUDIT_PROMPT_EXPECTATION_DEFECT` or `AUDIT_WRAPPER_REPAIR_REQUIRED`: correct only the audit input or wrapper; do not touch the repository.
- `MANDATORY_EVIDENCE_UNAVAILABLE`: return to the implementation conversation for the minimum evidence-only or validation continuation.
- `IMPLEMENTATION_REPORT_STALE_BYTES`: the repair report is stale; identify every changed path before proceeding.
- `FINAL_EVIDENCE_TARGET_MISMATCH` or `OPENING_TARGET_MISMATCH`: resolve the evidence baseline before any correctness work.
- `PROVENANCE_RECIPE_FAILURE`: stop; the canonical provenance mechanism itself is not stable.

The accepted candidate should not be altered unless this diagnostic proves that its live bytes or required evidence are actually inconsistent.

**Source:** Codex’s `AUDIT_PROVENANCE_MISMATCH` response in this turn.

**Confidence:** High that provenance diagnosis is the only justified next step; no confidence should yet be assigned to the repaired candidate’s acceptance or rejection because correctness inspection did not begin.
