## Engineering disposition

**The `BLOCK` is valid. Repair the current candidate; do not refreeze the architecture and do not enter the commit gate.**

The re-audit materially narrows the remaining work:

- **One production defect:** the Capability error boundary still overclaims what it can guarantee about Python exception internals.
- **One causal-test defect:** six B1 relation controls mutate nested owner state in addition to the intended schema field and digest.
- **Two regression-oracle defects:** the live B1 and RW0 documents are correct, but their tests allow semantically equivalent contradictory prose.

The following findings are now closed and should not be reopened:

- Wire-owner import-failure hygiene.
- C2A tuple charge-before-dereference behavior.
- Current B1 retrieval budget and consumer prose.
- Current RW0 tranche allocation.
- Integrated owner reconstruction, all B1 budgets, the private host seam, and the separate `863 + 249 = 1112` accounting. 

### Capability error decision

The next repair should **stop trying to make arbitrary exception re-raising or CPython’s hidden `BaseException` slots reflection-proof**. That is not a realistic semantic contract.

The defensible contract is:

- A Capability boundary accepts only an **exact built-in string** from the finite reason vocabulary.
- It stores only the canonical module-owned reason string.
- It constructs the exception with **empty inherited `BaseException.args`**. Neither the private construction token nor reason is passed into `BaseException.__new__` or `BaseException.__init__`.
- On the module’s first direct emission outside an externally active exception handler, the real inherited cause and context are `None`.
- A caller that later raises the error while another exception is active may cause Python to attach interpreter-owned context. That is outside the Capability sanitization guarantee and must be documented and tested honestly.
- The weak registry must never accept a string subclass or an object that merely compares equal to an allowed reason.

This addresses the audit’s real privacy defect without replacing it with another impossible promise.

### B1 relation-matrix decision

The checked matrix must preserve raw stored state exactly:

- Start from the valid `_values` tuple.
- Change only raw index `0` (`schema_id`) and the final self-digest.
- Keep every nested C2A, lineage, tuple, and collection member identical to the valid baseline.
- Assert the exact two-index raw delta before running the relation.

Each of the thirteen relations must then prove:

1. normal `invalid_enum` rejection;
2. a one-object selective bypass;
3. a class-wide bypass with literal expected call identities;
4. poisoning of the original object after reconstruction without changing the result.

The audit’s external matrix indicates the production relations themselves are behaving correctly; this is a checked-in evidence repair, not authorization to modify B1 production.

### Documentation-oracle decision

Do **not** change the live B1 or RW0 documents. Instead, strengthen their complete visible owner-region parsers.

The B1 oracle must reject additive statements equivalent to:

```text
The current retrieval cap is three hundred seventy-four B1 units.
B1 presently has zero production callers.
No production module currently consumes B1.
Capability consumption remains a future B2 concern.
```

The RW0 oracle must reject additive text or rows equivalent to:

```text
RW0-B remains blocked until process transport is implemented.
The B tranche is still future; RW0-C cannot begin.
Earliest unresolved tranche: RW0-B.
| RW0-B | future | physical process plumbing |
```

Exact positive sentences alone are insufficient; contradictory prose anywhere in the authoritative visible region must fail.

## Exact repair boundary

Only these six already-dirty paths may change:

```text
.docs/rw0-b2-capability.md
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The other 24 candidate entries must remain byte-identical. Final topology stays:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
```

No C2A, lineage, B1, or Wire production source is in scope.

## Repair handoff

Send this complete prompt to the **existing workspace-write Capability implementation conversation**:

:chatgpt-content-reference{index="3"}

Verify the artifact:

```text
Filename:
Coordinator_RW0_B2_Capability_Final_Reaudit_Findings_Repair_Prompt.txt

Size:
30,387 bytes

SHA-256:
3e943e7878cb9c6ff897a3d57686772933dae47299a0337829ce4d25de10f14c
```

It is bound to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Opening manifest SHA-256:
527ba2c27d94a0361912210eb80c718762fcc4a4df1d9b503524a8e91af115ac

Opening tracked-diff SHA-256:
6133bfa7994b12f63769a0d9a8843bb06296f2cc1185cc4c305b43c3c51ae5ee

Opening complete-output SHA-256:
ea927882df7952ff31384d3cc42b5fe60dcca65127125e4e99f6ee4fc00cff8e

Opening nodes:
4,743

Opening node-list SHA-256:
05fea81edde4fde4cf5fcb15a8e2c397eead7410688665b1500c0cb09970a064
```

The required implementation result is:

```text
COORDINATOR_RW0_B2_CAPABILITY_FINAL_REAUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

That result advances only to another **fresh read-only independent audit**. The project protocol requires repairs to return to the sole-writer implementation conversation and every byte change to receive a new independent audit. 

Only a later independent `ACCEPT` permits the commit gate, where the staged and committed blobs must be compared to the accepted manifest. 

### Sources

- Codex fresh re-audit report supplied in this turn.
- Integrated owner reconstruction and budget reconciliation. 
- Governed Execution repair and re-audit lifecycle. 
- Provenance and commit-gate requirements. 

**Confidence:** High that the four findings are repairable within the six-path boundary; high that no architecture or schema refreeze is needed; medium-high that the error repair will pass the next audit if the inherited base slots and active-exception chaining behavior are tested directly rather than hidden behind subclass properties.
