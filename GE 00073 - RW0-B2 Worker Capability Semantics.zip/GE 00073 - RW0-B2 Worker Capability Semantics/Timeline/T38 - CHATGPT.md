## Engineering disposition

**Proceed to a fresh independent read-only re-audit. Do not stage or commit.**

The third repair report is internally coherent and closes the write-enabled repair engagement:

- exactly the four authorized untracked files changed;
- the other 12 candidate entries remained byte-identical;
- all 4,653 opening nodes were preserved;
- one causal test node was added, producing 4,654 total;
- focused validation and the sole complete-suite attempt passed;
- final provenance reproduced twice over the same 16-path candidate.

The new audit target is:

```text
Branch:
codex/rw0-b2-wire-protocol-v1

HEAD:
02450d3c99faf0fe7b299b914afaed312421bc8b

Canonical manifest:
/private/tmp/rw0-b2-wire-third-repair.l1gF3r/final_recipe_001.manifest.json

Canonical-manifest SHA-256:
462179865bd8bacc2edcab5fd5a0ee3bae9e85a62a708a7e3b7c3d18f10db33b

Complete-output SHA-256:
136bec66bea1850965f4a2232b422dcc9ba2315adc308319ab16b4cc0cc8ff06

Tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6

Repair report:
/private/tmp/rw0-b2-wire-third-repair.l1gF3r/final_provenance.json

Repair-report SHA-256:
c857704fd8d597be0e3e6574964fbecb6dcb02cb5cf59aeead1d76c7e7c980b6
```

The unchanged tracked-diff digest is expected because the four repaired files are all untracked. The fresh auditor must verify each file’s size and SHA-256 against the new canonical manifest; the aggregate tracked diff cannot establish those repaired bytes.

## Repair assessment

### Integer admission

The repair now claims that every literal C2A integer consumed by Wire is checked against:

```text
9_223_372_036_854_775_807
```

before owner reconstruction, canonicalization, digesting, or framing. That is the correct ownership: C2A itself has no blanket finite upper bound for the relevant command integers, while the finite ceiling is a B2 representational policy. 

The fresh audit must independently establish:

- exact `MAX` remains accepted where the owning field permits it;
- `MAX+1` and a 1,000-digit integer fail before **all** owner and Wire canonicalization paths;
- all 15 nested ceiling leaves use the same early upper-bound path;
- no accidental lower bound rejects valid negative process-exit values;
- every other integer field reachable through the six consumed C2A classes is covered, not merely the two test examples.

### Duplicate versus invalid-key precedence

The reported overlap matrix is now the intended one:

```text
unique overlength key
    → invalid_root_or_scalar

duplicate overlength key
    → duplicate_key

duplicate overlength key followed by malformed JSON
    → json_token_invalid
```

The audit should also test nested duplicates and semantically identical decoded keys using different JSON escape spellings. The fix must preserve raw-pair charging, syntax precedence, bounded traversal, and the frame-key maximum of 29.

### Causal key-cap fixture

The repaired fixture is claimed to contain exactly:

```text
72 key pairs
70 scalar leaves
2 container-valued pairs
```

This is materially better than the prior fixture, which violated both key and scalar limits. The auditor must independently reconstruct the pair tree and prove that widening only the key-pair limit from 71 to 72 removes the structural rejection while every other bound remains satisfied.

## Why another audit is mandatory

Although the repair is small, it changes source and tests together. The critical claims—zero canonicalization before integer rejection, duplicate precedence, and single-predicate key-cap causality—must be checked through independent instrumentation and counterexamples.

The fresh audit must also verify that the repair did not reopen any of the earlier findings:

- exception cause/context or hostile-payload retention;
- incomplete immutable values;
- bulk sibling enqueue or repeated hostile-tree traversal;
- premature C2A DAG/cycle expansion;
- classifier use before reconstruction;
- valid duplicate versus singleton-conflict semantics;
- cancellation graph orientation;
- privacy and authority boundaries;
- profile bytes, caps, public surfaces, and status wording.

The project workflow requires repaired bytes to receive a new independent read-only audit before any staging or publication effect.  Only after an accepted audit should the exact audited path set be staged, compared blob-for-blob with the manifest, validated without edits, and committed once. 

## Fresh re-audit prompt

Start a **new read-only Codex conversation** and send this complete prompt:

:chatgpt-content-reference{index="3"}

Verify the attachment:

```text
Filename:
Coordinator_RW0_B2_Wire_Third_Audit_Repair_Fresh_Reaudit_Prompt.txt

Size:
28,019 bytes

SHA-256:
67c798231a11295ca0f83b42e87f9f8d99ed7c7c090608113512a21a055277ac
```

The prompt requires:

- exact two-run opening and closing provenance;
- exact four-changed/12-unchanged comparison against the second-repair target;
- independent enumeration of every reachable integer field;
- zero-canonicalization probes for oversized integers;
- independent duplicate/invalid-key precedence probes;
- reconstruction of the isolated 72/70/2 key-cap fixture;
- regression review of all earlier F1–F11 repairs;
- candidate-versus-HEAD node comparison:

```text
candidate:       4,654
HEAD:            4,566
candidate-only:     88
HEAD-only:            0
```

with exact ownership:

```text
Wire values:       11
Wire codec:        16
Wire relations:    48
Wire boundaries:   13
```

- one independent complete-suite run only after source and counterexample inspection are green;
- no repair, staging, commit, push, PR, remote contact, or Capability work.

The successful outcome must be:

```text
ACCEPT
COORDINATOR_RW0_B2_WIRE_THIRD_AUDIT_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

### Sources

- Codex third-audit repair report supplied in this turn.
- Original source-grounded identification of the finite-integer gap and B2-policy boundary. 
- Repair followed by a fresh independent audit. 
- Provenance-bound independent audit and later commit gate. 

**Confidence:** High that the candidate is ready for fresh re-audit; deliberately insufficient for commit authorization until early integer rejection, duplicate precedence, and key-cap causality are independently reproduced.
