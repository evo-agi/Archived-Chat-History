PROMPT_ID

RW0_B2_WIRE_SIXTH_AUDIT_TEST_REPAIR_FRESH_REAUDIT_V1

TITLE

Coordinator RW0-B2-Wire — fresh independent read-only audit of the exact
sixth-audit one-file test repair candidate

ENGAGEMENT TYPE

Fresh Codex conversation. Read-only independent audit.

This is not implementation, repair, reconnaissance, commit, publication,
merge, deployment, Capability work, or runtime proof.

The parent and every audit subagent are read-only. Do not edit, create, delete,
format, chmod, or clean repository bytes; do not stage, commit, push, create or
modify a PR, merge, tag, release, deploy, install dependencies, run migrations,
contact networks/remotes/services, invoke product workers/models/providers, or
modify any supporting repository.

External audit evidence, observer code, and isolated pytest scratch may be
created only beneath one new operator-owned, non-symlink, mode-0700 directory
under `/private/tmp`. Do not delete or rewrite implementation, repair, or
prior-audit evidence.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

VERDICT TOKENS

Return exactly one primary verdict:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

On `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_WIRE_SIXTH_AUDIT_TEST_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not repair any finding.

EXPECTED LIVE TARGET

Require at opening and closeout:

- physical root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- subject:
  `feat: implement RW0-B1 pure phase-entry semantics (#3)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- dirty paths:
  `16`
- tracked modifications:
  `10`
- untracked additions:
  `6`
- staged/unmerged:
  `0/0`
- every candidate path:
  regular mode `0644`
- no Git operation, lock, repository cache, bytecode, database, journal,
  archive, build, generated manifest, or recorder residue
- `git diff --check`:
  clean.

Do not fetch or contact a remote.

IMMUTABLE SIXTH-REPAIR TARGET

Repair evidence root:

```text
/private/tmp/rw0-b2-wire-sixth-repair.JqZLSt
```

Repair closeout report:

```text
/private/tmp/rw0-b2-wire-sixth-repair.JqZLSt/final_provenance.json
```

Validation summary:

```text
/private/tmp/rw0-b2-wire-sixth-repair.JqZLSt/final_validation_summary.json
```

Node identity:

```text
/private/tmp/rw0-b2-wire-sixth-repair.JqZLSt/node_identity.json
```

Expected canonical identities reported by the repair:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe source bytes:
3_945

recipe source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6

canonical-manifest SHA-256:
c1fe53703e61cb30394b944af063ad5b23f4fc472f48571b1064cbde2f79a358

complete-output SHA-256:
58421af36213dfb0c74232acee5a68a3fa64cda5ad98e88e38c6ea54562c534a

file count:
16
```

The repair report did not supply a separate SHA-256 for its JSON envelope.
Safely hash it during the audit, but do not substitute that hash for the
canonical-manifest identity above.

Require `final_provenance.json` to identify and hash-bind exactly one canonical
manifest carrying the pinned identities. If no unique bound target exists,
return `AUDIT_PROVENANCE_MISMATCH`; do not infer or synthesize one.

PRECEDING FIFTH-REPAIR TARGET

Repair report:

```text
/private/tmp/rw0-b2-wire-fifth-repair.zMko0e/final_provenance.json
```

Expected preceding report SHA-256:

```text
6eefc4c3891529f72758e10ba2b0515fea79a9ff2207bd0bdd6e43048a9349fc
```

Expected preceding validation-summary SHA-256:

```text
54e5b7470d002e4d87b10a127e052463ba5061ddc801101ccd9f2bff965dbaaa
```

Expected preceding canonical identities:

```text
canonical-manifest SHA-256:
27a65b60710f337d5610d8a8fb6f039d6b0a13ba4045d5e7587a7db37f1a2b77

complete-output SHA-256:
2f172d7c92a91c8118dfbdf6b750cb332371201f03f5b66e3d5c990358121344

tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6
```

Latest preceding audit root:

```text
/private/tmp/rw0-b2-wire-fifth-reaudit.mSMH5W
```

The escaping mutant record is:

```text
/private/tmp/rw0-b2-wire-fifth-reaudit.mSMH5W/selective_bypass_controls.json
```

Retained evidence roots that must remain unchanged include all prior Wire
implementation, repair, and audit roots, including:

```text
/private/tmp/rw0-b2-wire-v4.b4HlRt
/private/tmp/rw0-b2-wire-independent-audit.hX8xit
/private/tmp/rw0-b2-wire-repair.q4veCL
/private/tmp/rw0-b2-wire-re-audit.dU0ieG
/private/tmp/rw0-b2-wire-second-repair.91xEYJ
/private/tmp/rw0-b2-wire-third-repair.l1gF3r
/private/tmp/rw0-b2-wire-third-audit.Zq6XE2
/private/tmp/rw0-b2-wire-fourth-repair.oTHtSz
/private/tmp/rw0-b2-wire-fourth-reaudit.UleeOK
/private/tmp/rw0-b2-wire-fifth-repair.zMko0e
/private/tmp/rw0-b2-wire-fifth-reaudit.mSMH5W
/private/tmp/rw0-b2-wire-sixth-repair.JqZLSt
```

EXACT 16-PATH SET

Untracked additions:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

Tracked modifications:

```text
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

No seventeenth path is permitted.

EXPECTED FIFTH-TO-SIXTH-REPAIR DELTA

The path set, classifications, types, and modes remain identical.

Exactly this one untracked entry changed:

```text
tests/test_rw0_b2_wire_relations.py
```

Expected relation-test identity transition:

```text
before:
48_046 bytes
909414fc83f3bb663334f772a48007763c291c96fea4b6791e5a29967f6fc0a6

after:
54_331 bytes
59db0fb9ac098069f882f52427eab4fec25c8da45a8d5706f06b99b9925cf1cd
```

The other fifteen candidate entries—including all production source, all
governing documentation, and the other three Wire test files—must be
byte-identical to the fifth-repair target.

The tracked textual-diff digest remains unchanged because the sole repaired file
is untracked. Independently verify every per-file size and SHA-256; do not treat
the aggregate tracked-diff digest as repair proof.

EXACT RECIPE SOURCE

Decode this base64 only into the external audit root, verify exact size and
SHA-256, and retain it mode `0400`:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

The source historically writes:

```text
/tmp/ge-coordinator-b3a-audit-manifest-v1.json
```

Do not overwrite pre-existing evidence at that path. Execute the exact recipe
source unchanged while an external wrapper redirects only that exact
`Path.write_bytes` sink to a unique file under the audit root. Do not alter Git
reads, canonicalization, stdout, stderr, or recipe source.

PROVENANCE GATE — BEFORE CORRECTNESS INSPECTION

1. Lstat every component of:
   - sixth-repair evidence root;
   - report envelope;
   - report-bound canonical target;
   - validation summary;
   - node identity;
   - preceding fifth-repair report and manifest;
   - latest preceding audit root;
   - every retained prior evidence root;
   - copied recipe source;
   - new audit root.
2. Require safe ownership, no symlink traversal, regular report/manifest/recipe
   files, and mode-0700 evidence roots.
3. Verify the preceding pinned report and summary identities.
4. Parse the sixth repair report and require one unique bound canonical target
   with the pinned manifest, complete-output, tracked-diff, and file-count
   identities.
5. Parse canonical JSON and require exact:
   - branch;
   - HEAD;
   - upstream;
   - recipe ID;
   - textual-diff digest;
   - 16-path set;
   - classification;
   - file type;
   - mode;
   - size;
   - per-file SHA-256.
6. Compare every live candidate file with the sixth-repair target.
7. Run the exact recipe twice at opening.
8. Require both complete outputs and manifests to be byte-identical and the
   generated manifest to equal the immutable target byte-for-byte.
9. Require repository identity and status to match the expected live target.
10. Verify no protected path outside the 16-path set differs from HEAD.
11. Verify exactly the one/fifteen preceding-to-repair delta above.
12. Verify all production and governing-document bytes equal the fifth-repair
    target exactly.
13. Fingerprint every retained evidence root before correctness work.

On any mismatch, stop before correctness inspection with:

```text
AUDIT_PROVENANCE_MISMATCH
```

CURRENT CONTRACT AND TARGET BOUNDARY

Committed HEAD owns current C2A and B1 contracts. The uncommitted candidate is
the accepted private B2-Wire target.

The candidate may implement only:

- private deterministic NWPF command/result codecs;
- pure relations over supplied exact C2A values and actual fences;
- safe unauthenticated cancellation-request and process source claims;
- a pure process/result classifier;
- one fixed local Wire protocol profile.

It must implement no:

- source authentication;
- permission, effect authority, acceptance, or durable truth;
- worker, process, contact, physical transport, host, filesystem, database,
  network, provider, model, Codex, CLI, App Server, credential, session,
  Bridge, ES, Git, or publication effect;
- RW0-C persistence, recovery, terminal fact, or latch;
- RW0-D/E request delivery, process targeting, process mechanics, or live proof;
- Capability declaration, observation, qualification, or implementation.

FROZEN PRODUCTION IDENTITIES

Require exact preservation:

```text
profile_ref:
rw0-wire-nwpf-v1

profile identity bytes:
4_021

profile digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454

command payload/frame:
5_898 / 5_906

result payload/frame:
16_627 / 16_635

hostile units:
23_746 / 66_770

source mapping key maximum:
37

frame key maximum:
29

B2 maximum integer:
9_223_372_036_854_775_807
```

No production byte changed in the sixth repair. A production defect newly
discovered by this audit is still a blocker, but do not repair it.

FINDINGS TO RE-AUDIT

Treat all prior findings F1–F17 as hypotheses to remain closed.

The sole open fifth-audit finding was:

```text
F18 Low  the selective Attempt control recorded intended delegation but a
         class-wide bypass of all sixteen Attempt integer guards still passed
         because a later digest mismatch supplied the expected sanitized error
```

The sixth repair claims to close F18 with:

- a fresh non-selected Attempt behavioral sentinel;
- one real guard-body entry and rejection;
- zero Attempt owner/canonical/digest/frame events;
- an exact class-wide Attempt mutant red diagnostic:
  `non_selected_attempt_integer_guard_not_enforced`;
- an unrelated Effect mutant diagnostic:
  `unrelated_effect_integer_guard_not_enforced`;
- unchanged F17 positive and negative 64-key ledgers.

This audit must independently establish those claims and detect any new test
defect.

AUDIT EXECUTION SHAPE

Use at most four concurrent audit slots:

- create three bounded read-only audit subagents;
- the parent performs the fourth lane;
- no nested agents;
- no subagent mutates the repository or retained evidence;
- no subagent runs the repository full suite;
- every subagent receives the same canonical manifest identity and a
  self-contained context capsule;
- preserve disagreements and minority findings.

LANE 1 — SOURCE-LEVEL SENTINEL AND CONTROL AUDIT

Inspect only the exact fifth-to-sixth test-file diff plus enough unchanged
production source to understand the guard boundary.

Require the repaired test to preserve:

- the literal 64-entry inventory;
- the 64-key exact-valid ledger;
- the 64-key `MAX+1` ledger;
- the 64-key 1,000-digit ledger;
- legal-MAX controls;
- process-exit `-255/0/255` controls;
- exactly one selected bypass of
  `AttemptFenceV1.global_stop_version`;
- the unrelated Effect control.

For the new non-selected Attempt sentinel, establish from source that:

1. it starts from a fresh complete graph;
2. selected `global_stop_version` is valid;
3. only:
   ```text
   AttemptFenceV1.aggregate_ceilings.max_active_invocations
   ```
   exceeds `MAX_INTEGER`;
4. every companion object and digest coordinate is otherwise valid;
5. the public boundary reaches Attempt extraction;
6. authoritative behavior requires:
   - sealed `invalid_field_value`;
   - selected-bypass delta `0`;
   - exactly one real guard-body entry;
   - exactly one real guard-body rejection;
   - zero Attempt owner-boundary calls;
   - zero owner/Wire canonicalization, digest, payload, or frame events.

Identify whether any later digest or relation mismatch could still satisfy the
sentinel's authoritative assertions.

Inspect the use of explicit content-free `AssertionError` diagnostics and verify
that pytest assertion rewriting cannot alter the expected causal message.

LANE 2 — INDEPENDENT EXTERNAL MUTANT CONTROLS

Create external observer/mutant code only under the audit root. Do not alter
repository bytes.

Run the exact strengthened test node in at least these modes:

A. Authoritative production behavior:

```text
expected:
pass
```

B. Class-wide Attempt bypass:

- patch before the test captures its production guard;
- return normally for all sixteen Attempt integer checks;
- preserve all other behavior;
- do not inject a later artificial error.

Require:

```text
expected:
test fails

exact causal diagnostic:
non_selected_attempt_integer_guard_not_enforced
```

Record:

- all sixteen bypass calls;
- zero real guard-body rejections for Attempt;
- whether Attempt owner reconstruction, canonicalization, digest, or later
  relation logic was reached;
- JUnit failure identity;
- stdout/stderr;
- unchanged repository fingerprint.

C. Selected operation only:

- bypass only the selected `global_stop_version` check;
- delegate the other fifteen Attempt checks to the real guard.

Require:

```text
expected:
pass

selected bypasses:
1

non-selected real enforcement:
present

selected Attempt owner boundary:
reached exactly once
```

D. Unrelated Effect class-wide bypass:

Require:

```text
expected:
test fails

exact causal diagnostic:
unrelated_effect_integer_guard_not_enforced
```

and prove the Attempt sentinel remains independently green until the unrelated
Effect control is reached.

E. Control against a masking later error:

Create one external mutant that bypasses all Attempt guards and also preserves
or introduces a later digest/relation failure of the same sealed public type.
The strengthened test must still fail at the behavioral-sentinel diagnostic,
not pass because of the later sanitized error.

External injection should use a read-only audit-root pytest plugin,
`sitecustomize`, or equivalent pre-import observer. Retain the exact source,
SHA-256, argv, environment, and results for every mode.

LANE 3 — F17 REGRESSION AND TEST-INDEPENDENCE

Independently derive the reachable integer inventory from committed C2A classes:

```text
CeilingsV1           15
AttemptFenceV1       16
EffectFenceV1        16
WorkerCommandV1      16
DeliveryEnvelopeV1    0
WorkerObservationV1   1
total                 64
```

Do not derive this audit inventory from the repaired test or Wire extractor
constants.

Verify the repaired file still behaviorally grounds:

```text
positive exact-valid coverage keys
MAX+1 negative coverage keys
1,000-digit negative coverage keys
```

against the same 64 keys.

Independently inject representative legal-MAX rejection mutants for:

- `CeilingsV1.max_active_invocations`;
- one Attempt path;
- one Effect path;
- one WorkerCommand path.

Require the checked-in node to fail each mutant.

Audit for self-confirming logic:

- no coverage key is credited without actual target traversal;
- no helper builder silently replaces the target object;
- no generic event can satisfy a class-specific assertion;
- no ledger entry is treated as proof that a guard enforced a bound;
- the new real-body marker cannot be emitted by the class-wide bypass;
- the sentinel graph cannot fail earlier for an unrelated reason;
- no node/decorator/parameterization/skip/xfail identity changed.

LANE 4 — PROVENANCE, PRODUCTION FREEZE, EVIDENCE, AND PUBLIC BOUNDARY

The parent performs this lane.

Inspect:

- the sole changed test file;
- the other fifteen candidate paths;
- production source and governing documents;
- sixth-repair and prior evidence;
- imports/AST/package/public surfaces;
- node identities and validation metadata.

Determine whether:

- exactly one test file and only that file changed;
- production/docs are exact;
- all F1–F17 direct tests remain active;
- no test was weakened, removed, renamed, skipped, xfailed, collapsed, or
  reparameterized;
- no new node exists;
- no package/public/production/dependency/schema/migration widening exists;
- repair evidence binds the final target and preserves all prior roots;
- no sensitive or repository-local artifacts remain.

IMPLEMENTATION EVIDENCE REVIEW

Safely inventory the sixth-repair root. Verify credited records by exact file
identity, argv, environment, umask, return code, stdout/stderr, JUnit,
structured counts, and before/after fingerprints.

Expected repair-reported final results:

```text
opening nodes:                    4_655
final nodes:                      4_655
node delta:                       none

authoritative external causal red:
1 intended failure
exact diagnostic:
non_selected_attempt_integer_guard_not_enforced

strengthened node:                1 passed
Wire relations:                   49 passed
combined Wire:                    89 passed
C2A/C2A1:                         637 passed
B1:                               281 passed
static/public:                    105 passed
status/docs:                      858 passed
complete suite attempt 001:       4_655 passed
```

Preserve and classify every reported attempt:

- three pre-edit diagnostic modes;
- initial wrong-occurrence causal harness run;
- pytest-rewriting diagnostic mismatch runs;
- superseded first final collection;
- authorized test-local diagnostic correction;
- authoritative final collection;
- authoritative external causal red;
- authoritative normal green;
- unrelated Effect mutant result;
- all recorder/orchestration limitations.

Do not treat audit-harness errors as production failures. Do not credit
ambiguous, superseded, or byte-unbound evidence.

PARENT RECONCILIATION

Wait for all three subagents. Preserve disagreements. Directly inspect and
reproduce every material finding.

Classify each finding by:

- severity: Critical / High / Medium / Low / Observation;
- type: authority/contract, correctness, security/privacy/availability,
  test adequacy, documentation/status, public boundary, provenance/evidence;
- patch defect versus pre-existing issue;
- current-contract violation versus strategic-target defect;
- exact path:line evidence;
- impact;
- required correction;
- uncertainty.

Green tests never overrule a deterministic counterexample.

INDEPENDENT VALIDATION

Only after provenance and source/mutant inspection are sufficiently green, run
serial independent validation under the new audit root.

For every child use:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
```

Capture and restore the actual caller umask; require child-observed numerical
umask equality.

Run:

1. authoritative strengthened 64-path node;
2. external class-wide Attempt causal mutant;
3. external selected-only control;
4. external unrelated Effect causal mutant;
5. external later-error masking control;
6. all four Wire files together:
   ```text
   tests/test_rw0_b2_wire_values.py
   tests/test_rw0_b2_wire_codec.py
   tests/test_rw0_b2_wire_relations.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
7. corrected C2A/C2A1:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_c2a_first_slice_semantic_protocol_contract.py
   tests/test_c2a_effects_and_recovery.py
   ```
8. B1:
   ```text
   tests/test_rw0_b1_*.py
   ```
9. static/public:
   ```text
   tests/test_c2a_nonimplementation.py
   tests/test_runtime_non_authority.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_b2a_writer_session_contract.py
   tests/test_codex_agent_config.py
   ```
10. status/docs:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

Every ordinary green gate must return 0 with empty stderr, zero
failures/errors/skips/xfails/warnings, parseable JUnit, no duplicate or unmapped
case, and unchanged repository target.

The causal mutant gates must fail only for their expected exact content-free
diagnostics, with no fixture, collection, import, or unrelated failure.

NODE IDENTITY

Collect the candidate exactly once and one clean external `git archive HEAD`
exactly once.

Require:

```text
candidate:                       4_655
HEAD:                            4_566
intersection:                    4_566
candidate-only:                  89
HEAD-only:                       0
```

Require all 89 candidate-only nodes to belong exactly to:

```text
tests/test_rw0_b2_wire_values.py       11
tests/test_rw0_b2_wire_codec.py        16
tests/test_rw0_b2_wire_relations.py    49
tests/test_rw0_b2_wire_boundaries.py   13
```

Require HEAD order preservation and exact equality with the fifth-repair node
list.

If source/mutant inspection finds a blocker, the full suite may be withheld
with an exact explanation.

If inspection is green, run the complete repository suite exactly once and
require:

```text
4_655 collected
4_655 passed
0 failures/errors/skips/xfails/warnings
empty stderr
no duplicate or unmapped JUnit cases
unchanged target bytes
```

CLOSING GUARDS

Before verdict:

1. remove only audit-created transient caches, basetemps, archives, databases,
   journals, observer scratch, and recorder scratch;
2. rerun the exact recipe twice;
3. require both closing manifests and complete outputs to equal opening and the
   immutable sixth-repair target byte-for-byte;
4. require exact 16-path topology, modes, classifications, sizes, and hashes;
5. require protected complement equality to HEAD;
6. require clean `git diff --check`;
7. require no repository residue, operation, or lock;
8. confirm no repository mutation occurred;
9. confirm every retained prior evidence root is unchanged.

ACCEPTANCE STANDARD

`ACCEPT` requires:

- exact provenance;
- no Critical, High, Medium, or Low patch defect;
- all F1–F18 findings mechanically closed;
- no new current-contract or accepted-target contradiction;
- the non-selected Attempt sentinel is coherent and behaviorally grounded;
- the class-wide Attempt bypass is independently killed before downstream
  masking;
- the selected-only control passes with exactly one bypass;
- the unrelated Effect mutant is independently killed;
- a later sanitized error cannot satisfy the sentinel;
- F17 positive/negative coverage remains complete;
- all prior production/parser/extraction/classifier/authority/privacy/status
  findings remain closed;
- causally adequate tests;
- validated public/nonimplementation boundaries;
- required independent validation green;
- closing target byte-identical to opening.

An evidence limitation may be an Observation only when independent source,
mutant, and validation work fully supersede it.

FINAL REPORT

Include:

1. exact opening/closing identity and provenance;
2. exact fifth-to-sixth-repair delta;
3. audit-lane reports and preserved disagreements;
4. severity-ranked finding ledger;
5. per-F1–F18 disposition;
6. source-level sentinel assessment;
7. external selected-only/class-wide-Attempt/unrelated-Effect/masking controls;
8. F17 regression assessment;
9. production/profile/public-boundary regression assessment;
10. implementation-evidence assessment;
11. independent commands/results/node comparison;
12. closing guards, limitations, and separate confidence for:
    - provenance;
    - validation;
    - production behavior;
    - test adequacy.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
```
