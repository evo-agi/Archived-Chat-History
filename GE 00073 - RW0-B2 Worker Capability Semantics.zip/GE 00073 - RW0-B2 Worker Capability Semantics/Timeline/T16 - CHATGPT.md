## Engineering disposition

**Accept the corrected Wire schema freeze and proceed to implementation.**

The final read-only result closes the remaining authority defect:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_READY
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

The critical correction is now explicit:

| Route | Cancellation-request author | Existing C2A response source |
|---|---|---|
| Direct-local | `supervisor` | `direct_local_adapter` |
| ES | `execution_substrate` | `es_adapter` |

Request and acknowledgement/rejection are related through the cancellation effect, fence, delivery, immutable target, and author lineage—not by pretending they have the same source kind, ref, or invocation. That preserves the RW0-A fact-owner split without changing C2A or B1.

The fixed Wire profile was independently reproduced as:

```text
profile_ref:       rw0-wire-nwpf-v1
canonical bytes:   4,021
profile SHA-256:   470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
```

Every other frozen decision remains intact:

- command frame = complete `WorkerCommandV1` + complete `DeliveryEnvelopeV1`;
- result frame = the closed worker-observation sequence;
- outer frame has no competing semantic identity;
- source claims authenticate nothing;
- process/result classification is evidence only;
- B1 remains unchanged;
- no persistence, contact, process, Codex invocation, acceptance, or authority is added;
- Capability remains bounded but unimplemented.

The earlier reconnaissance properly prohibited implementation while integer admission, exact bytes, work accounting, and classifier behavior were unresolved.  It also established the enduring order `RW0-B2-Wire → RW0-B2-Capability` and rejected command-only framing, an outer semantic identity, and a concrete CLI/App Server selection in Wire.  Those open items are now frozen.

### One implementation-level hardening added

The implementation prompt adds a bounded mapping-key preflight before direct `from_mapping` key scans:

- mappings larger than `_FIELDS + 1` fail cardinality before iteration;
- within the bounded scan, private-fragment keys receive `privacy_forbidden_material`;
- ordinary unknown keys still precede missing fields.

This does not alter any schema, profile byte, identity, or accepted relation. It prevents repeating B1’s earlier unbounded caller-key-scan defect.

## Authorized implementation tranche

Use the **same RW0-B2 Codex conversation**, switch it to workspace-write, and send the complete prompt below:

:chatgpt-content-reference{index="3"}

The prompt is self-contained and includes:

- the exact committed baseline;
- feature branch `codex/rw0-b2-wire-protocol-v1`;
- the exact 16-path maximum allowlist;
- all fields, enums, domains, signatures, byte layouts, relations, and classifier precedence;
- the complete 4,021-byte canonical profile mapping and pinned digest;
- corrected request ownership and request/response non-collapse;
- privacy and content-free error requirements;
- literal test-owned size, structural, work, profile, and precedence oracles;
- exact maximum and one-over hostile cases;
- Markdown owner/cross-reference causality controls;
- opening and final node collection;
- focused compatibility gates;
- one full-suite attempt, with at most one governed in-scope repair rerun;
- the exact 3,945-byte provenance recipe embedded in base64;
- final expected topology:

```text
16 dirty paths
10 tracked modifications
6 untracked additions
0 staged
0 unmerged
```

The implementation success token is:

```text
COORDINATOR_RW0_B2_WIRE_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT
```

No staging, commit, push, PR, remote contact, worker/model invocation, or Capability implementation is authorized.

## After implementation

The next engagement must be a **fresh read-only independent audit** against the exact canonical manifest. Only an accepted audit permits the later audited-byte commit and PR gate. The project operating protocol deliberately separates the sole-writer implementation turn from the fresh audit conversation. 

The prompt also carries the full provenance recipe because provenance must bind implementation, audit, and commit to identical bytes, while remaining evidence rather than correctness or authority. 

### Sources

- Initial B2 reconnaissance disposition and baseline. 
- Adopted B2 order and supported Wire composition. 
- Parent-only implementation and separate-audit workflow. 
- Provenance implementation/audit/commit lifecycle. 
- Final corrected Codex freeze supplied in this turn.

**Confidence:** High that the Wire design is now ready for its bounded implementation tranche; high that Capability remains safely deferred; moderate-to-high that the exact 16-path ceiling will hold, with the principal residual risk being an existing static/status inventory exposed only by the complete suite.
