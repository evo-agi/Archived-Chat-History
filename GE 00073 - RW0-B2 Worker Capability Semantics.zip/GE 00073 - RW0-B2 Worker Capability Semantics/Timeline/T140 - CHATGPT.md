## Disposition

**Run one complete no-mutation validation replay. Do not edit the candidate, reconstruct historical metadata, or start the independent audit yet.**

The diagnostic establishes that the repository repair is complete:

- Current bytes exactly match the claimed final repaired candidate.
- The closed reachable-call protection and causal protected-content checks are present.
- The final manifest, node list, A/B/C records, focused validation, both full-suite JUnits, suite-local fingerprints, guards, cleanup, and self-excluding index exist.
- The final node count is now **5,072**, with 15 additions and no removals or renames.
- Live and clean suites each passed **5,072/5,072**.
- The remaining defect is the **engagement-wide attempt history**: early opening, red, development, and tooling actions were not all captured with complete unconditional envelopes.

Those historical process-local fields cannot be reconstructed honestly. The correct remedy is a new clean validation envelope that records every action from evidence-root bootstrap onward. The prior `/private/tmp/g5.hiLE2y` root remains immutable historical implementation evidence; it is not rewritten.

## Complete replay handoff

Send this prompt to the **same write-enabled Capability implementation conversation**:

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Capability_Final_Repair_Complete_Validation_Replay_Prompt.txt

Size:
22,392 bytes

SHA-256:
ddd24c2d763e0e0dae0b0527435754f09a3e6291166b9a9d2f2da1070a799b92
```

The replay creates one neutral external root:

```text
/private/tmp/g6.XXXXXX
```

Its bootstrap self-records root creation and installs an unconditional recorder. From that point onward, **every** command or procedural action receives an immutable attempt envelope, including:

```text
setup and evidence verification
recipe-copy preflight
recipe runs
canonical controls
every individual mutant
focused pytest groups
A/B/C state construction and tests
live and clean node collection
node reconciliation
live full suite
clean full suite
guards
cleanup
final provenance
report generation
index creation
external index verification
```

The replay does not reconstruct or repeat obsolete development history. It establishes a new authoritative final-validation chronology against unchanged bytes.

## Required final results

The prompt recovers exact targets from the indexed `g5` evidence rather than relying on truncated report hashes. It requires:

```text
Final nodes:
5,072

Opening-to-final node delta:
15 additions
0 removals
0 renames

Final B/C tree:
0fcf6680ded68d66f62b75b5dc842d69b343a334

Selected causal:
16 passed

Capability boundaries:
32 passed

Capability complete:
69 passed

B1/Wire compatibility:
461 passed

Architecture/status/static:
907 passed

Live full suite:
5,072 / 5,072

Clean full suite:
5,072 / 5,072
```

The external clean repository must use an independent object database—no source worktree, source alternate index, hardlinks, or object alternates.

Every mutant must retain its exact source bytes, SHA-256, purpose, expected result, actual result, and complete attempt envelope. This directly closes the missing historical mutant-source and attempt-history evidence.

## Success boundary

The required success token remains:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

Only after the complete replay and closeout report exist should a new read-only independent audit be launched. The commit gate remains blocked.

The final report must explicitly state:

```text
historical g5 partial attempt metadata was not reconstructed
g5 remains evidence of the implementation turn
g6 is the authoritative complete final validation and closeout envelope
```

**Confidence:** High that no repository implementation work remains; high that the replay is the minimum defensible way to satisfy the strict complete-history requirement without fabricating historical metadata.
