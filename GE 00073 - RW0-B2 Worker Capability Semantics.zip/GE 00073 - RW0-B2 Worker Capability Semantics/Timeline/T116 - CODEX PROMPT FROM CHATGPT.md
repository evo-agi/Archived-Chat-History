PROMPT_ID

RW0_B2_CAPABILITY_ACCEPTED_COMMIT_PUSH_PR_GATE_V1

TITLE

Coordinator RW0-B2-Capability — commit the independently accepted 30-file
candidate, push one feature branch, and open one non-draft pull request

ENGAGEMENT TYPE

Parent-only commit, push, and pull-request gate in the existing write-enabled
Capability implementation conversation.

This gate may:

- verify the exact independently accepted candidate and retained evidence;
- stage exactly the accepted manifest paths;
- run one final collection and one complete suite on the staged candidate;
- create exactly one commit;
- push exactly once to the named feature branch;
- open exactly one non-draft pull request.

This gate may not:

- repair or modify implementation, documentation, tests, configuration, or
  evidence;
- amend, rebase, merge, squash, cherry-pick, force-push, or create a second
  commit;
- push directly to `trunk_dev`;
- merge the pull request or enable auto-merge;
- submit or dismiss a review;
- resolve a review thread;
- delete a branch;
- create a tag, release, or deployment;
- modify a supporting repository.

Do not create subagents. The parent performs the gate.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

ACCEPTED INDEPENDENT-AUDIT VERDICT

The final fresh independent audit returned exactly:

```text
ACCEPT

COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_FINAL_AUDIT_FINDINGS_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Accepted audit root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-independent-audit.T0I7mV
```

Accepted audit report:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-independent-audit.T0I7mV/final_report.md
```

Accepted audit self-excluding index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-independent-audit.T0I7mV/evidence_index.jsonl

rows excluding itself:
110

size:
23050 bytes

SHA-256:
e09add54af9a8d6e48969fd06a0c0e57bc2bf9125229f1f811c6781303c2cb54
```

The audit found:

- no Critical, High, Medium, or Low candidate defect;
- exact provenance and topology preserved;
- only the authorized final test file changed from the prior repair target;
- all parser and checker mutants rejected;
- independent full suite passed 5,057/5,057 on attempt 001;
- one observation-only migration-evidence redundancy, non-blocking;
- repository and retained evidence roots unchanged.

ACCEPTED CANDIDATE IDENTITY

Require at opening:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644
```

Accepted final canonical-manifest SHA-256:

```text
9efb739e958cf077dafad99d5dc62af3fdcbd847c359916fd22fb5c125b79472
```

Accepted final node identity:

```text
node count:
5057

ordered node-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe
```

Accepted implementation/final-repair evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit-findings-repair.nJmVEI
```

Accepted implementation/final-repair evidence index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit-findings-repair.nJmVEI/evidence_index.jsonl

rows excluding itself:
213

size:
37706 bytes

SHA-256:
22439f6586f7c2f7c67ba17fe25147f92d0016afba3140b7b5e3e96b51a710e4
```

Locate the final canonical manifest, complete recipe output, tracked textual-diff
identity, exact 30-path inventory, final node list, validation records, and
guards through the indexed final-repair evidence and accepted audit report.

Do not guess a path or reconstruct a missing target.

RETAINED EVIDENCE ROOTS TO PROTECT

Safely verify and preserve all of the following:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB
  index SHA-256:
  185d17a6332a49b545f50c5e7c33a4e1f6e1150fa799c547dbec40876b643e16

/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3
  index SHA-256:
  26b69c39d083cd2096c8e2b47c6afbef7626d24cbd55093fcabe659be23a06bb

/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-findings-repair.ZRLt3w
  index SHA-256:
  6de9b6295a2701a55bf496f2fe644f1c8be91b4314a67d84f3598c3a791e95b7

/private/tmp/ge-coordinator-rw0-b2-owner-oracle-validation-reset.ji1cdR
  index SHA-256:
  727d7feb2d24f6ea61222530b3d312483d7685f2da4f00dc462dce22e6eb6bb4

/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit.6NY6CJ
  index SHA-256:
  96badb399c58f0b172e8f1e4eb80d68304e3dc4bc58485ca7d8ba729e776e7c7

/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit-findings-repair.nJmVEI
  index SHA-256:
  22439f6586f7c2f7c67ba17fe25147f92d0016afba3140b7b5e3e96b51a710e4

/private/tmp/ge-coordinator-rw0-b2-owner-oracle-independent-audit.T0I7mV
  index SHA-256:
  e09add54af9a8d6e48969fd06a0c0e57bc2bf9125229f1f811c6781303c2cb54
```

Safely `lstat` path components. Do not follow untrusted symlinks. Record opening
tree fingerprints for all seven roots and require exact equality at closeout.

OPENING LOCAL PREFLIGHT

Before staging or remote contact:

1. verify the exact repository identity above;

2. require `git diff --check` clean;

3. require no Git operation, lock, unmerged path, staged path, cache, bytecode,
   database, journal, archive, build output, generated repository manifest, or
   recorder residue;

4. verify every live candidate file against the accepted canonical manifest by:

   ```text
   path
   classification
   regular-file type
   mode 0644
   byte size
   SHA-256
   ```

5. require exactly:

   ```text
   30 changed paths
   24 tracked modifications
   6 untracked additions
   0 deletions
   0 renames
   0 copies
   0 mode changes
   ```

6. verify every repository path outside the accepted manifest equals HEAD;

7. verify accepted audit and final-repair indexes and required records;

8. verify the final node list count/hash;

9. reproduce the accepted canonical manifest twice using the exact retained
   3,945-byte recipe source, with safe redirection of only its external fixed
   output sink;

10. require both reproduced manifests to equal the accepted manifest
    byte-for-byte;

11. require both complete outputs and tracked textual diff to match the values
    recovered from accepted indexed evidence;

12. inventory the seven retained evidence roots.

Stop before staging on any mismatch with:

```text
COMMIT_GATE_ACCEPTED_BYTES_MISMATCH
```

Do not repair.

REMOTE READ-ONLY PREFLIGHT

After the local accepted-byte gate is green, remote read-only contact is
authorized.

1. Verify authenticated GitHub identity.

2. Fetch or query the exact remote refs without tags.

3. Require remote `trunk_dev` still equals:

   ```text
   deec37bf08fb903d8846aa2c3232aec52fa9866e
   ```

4. Require the remote feature ref:

   ```text
   refs/heads/codex/rw0-b2-capability-semantics-v1
   ```

   to be absent.

5. Require no open or closed pull request already exists for the exact
   head/base pair or branch.

6. Require no conflicting tag.

7. Inspect effective repository and branch rules for `trunk_dev`, including:

   ```text
   required PR
   allowed merge methods
   required approvals
   required review-thread resolution
   required status checks
   unattributed-change approval
   bypass actors
   auto-merge setting
   delete-branch-on-merge setting
   ```

8. Record checks/workflows/statuses currently applicable. Do not infer that a
   synthetic pending status is a required check when total checks are zero.

If remote base moved, branch/PR already exists, policy disallows the requested
plain push/PR, or a bypass would be required, stop without staging or commit.

Return the precise stop reason.

GATE EVIDENCE ROOT

Create exactly one new external root:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-gate.XXXXXX
```

Requirements:

- operator-owned;
- non-symlink;
- mode 0700;
- all retained files regular and mode 0400 at closeout;
- no symlink, FIFO, socket, device, or special entry;
- no repository-local evidence;
- create a self-excluding canonical JSONL evidence index last.

Retain exact commands, argv, environment, timings, return codes, stdout/stderr,
JUnit, Git/GitHub responses, hashes, and before/after fingerprints.

STAGING

Stage exactly the 30 paths from the accepted canonical manifest.

Use the manifest as the sole staging allowlist.

After staging require:

```text
30 staged paths
24 modifications
6 additions
0 deletions
0 renames
0 copies
0 unmerged
all Git modes 100644
no unstaged or untracked candidate remainder
no staged path outside the manifest
```

For every staged path compare:

- staged blob bytes;
- working-tree bytes;
- accepted-manifest bytes;
- Git mode.

All must match.

Record:

- staged tree OID;
- cached binary diff size and SHA-256;
- staged path inventory;
- per-path blob OID, size, and SHA-256.

If any staging check fails:

1. unstage only the accepted manifest paths;
2. preserve working-tree bytes exactly;
3. verify the accepted candidate is restored to the original unstaged state;
4. stop without commit.

No repair is authorized.

FINAL PRE-COMMIT VALIDATION

Run exactly one collection and exactly one complete suite against the unchanged
staged/working candidate.

Use one external mode-0700 validation area under the gate root.

For each Python child:

```text
umask 022 before launch
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Collection command in substance:

```text
python3 -B -m pytest -p no:cacheprovider -W error --collect-only -q
```

Require:

```text
5057 unique nodes

ordered node-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

zero collection errors
zero warnings
empty stderr
```

Do not detect skips/warnings by grepping arbitrary test names. Use pytest
return code, structured JUnit/collection data, and exact parser logic.

Full-suite command in substance:

```text
python3 -B -m pytest -p no:cacheprovider -W error -q
```

Require:

```text
5057 collected
5057 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

Require:

- parseable JUnit;
- 5,057 unique JUnit case identities;
- zero duplicate or unmapped cases;
- exact mapping to the accepted node list;
- matching caller/child umask;
- unchanged working-tree, index, staged tree, candidate manifest, and accepted
  per-path blobs before and after both runs.

Collection is run exactly once. Full suite is run exactly once.

No retry or repair is authorized in this gate.

If validation fails:

1. preserve all evidence;
2. unstage exactly the accepted paths;
3. verify audited working bytes remain unchanged and unstaged;
4. stop without commit, push, or PR.

COMMIT

After all local and remote preflight, staging, and validation gates pass, create
exactly one plain commit.

Exact commit subject:

```text
feat: implement RW0-B2 Capability semantics
```

Commit body:

```text
(empty)
```

Requirements:

- do not amend;
- do not sign explicitly;
- do not alter author/committer configuration;
- use existing repository Git identity and timestamps;
- exactly one parent:
  `deec37bf08fb903d8846aa2c3232aec52fa9866e`;
- commit tree equals the staged tree;
- commit tree contains exactly the accepted 30-path delta:
  24 modifications and 6 additions;
- every changed blob and mode equals the accepted manifest;
- no second commit.

Record:

```text
commit OID
tree OID
parent
subject
body bytes
author
committer
timestamps
signature status
path shape
per-path blobs/modes
```

After commit require a clean worktree and index.

If commit creation fails, do not retry or amend. Report the state exactly.

PUSH

Push exactly once:

```text
git push -u origin HEAD:refs/heads/codex/rw0-b2-capability-semantics-v1
```

Requirements:

- plain push;
- no force;
- no tags;
- no direct trunk push;
- no second push;
- remote feature ref must equal the new commit;
- remote `trunk_dev` must remain
  `deec37bf08fb903d8846aa2c3232aec52fa9866e`;
- local upstream becomes
  `origin/codex/rw0-b2-capability-semantics-v1`;
- divergence becomes `0/0`.

If push fails, do not create a second commit or retry. Report the local commit
and failed push exactly.

PULL REQUEST

After successful push, open exactly one non-draft pull request.

Repository:

```text
evo-agi/Governed-Execution-Coordinator
```

Base:

```text
trunk_dev
```

Head:

```text
codex/rw0-b2-capability-semantics-v1
```

Exact title:

```text
feat: implement RW0-B2 Capability semantics
```

Exact body:

```markdown
## Summary
- add private RW0-B2 Capability declaration, observation, and qualification semantics over committed B1 and Wire identities
- harden supplied-value reconstruction and bounded owner composition used by Capability qualification
- replace prose-wide status inference with bounded B1 and RW0 current-contract registries

## Boundaries
- no worker or process contact, persistence, provider selection, credentials, runtime authority, public export, or semantic acceptance
- RW0-C, RW0-D, RW0-E, and Execution Substrate ownership remain unchanged

## Validation
- 5,057 tests passed
- fresh independent audit accepted the exact candidate
```

Requirements:

- open;
- non-draft;
- unmerged;
- auto-merge disabled;
- exact base/head OIDs;
- exactly one commit;
- exactly 30 changed files;
- no review submission;
- no self-approval;
- no reviewer request unless existing repository policy creates one
  automatically;
- no merge.

Record exact title/body bytes and SHA-256, PR number/URL, creation snapshot,
checks/statuses, mergeability, reviews, requested reviewers, threads, and
comments.

If GitHub initially reports mergeability `unknown`, perform only bounded
read-only refreshes and record each snapshot. Do not merge.

FINAL GUARDS

After PR creation require:

- local feature branch at the commit;
- remote feature ref at the commit;
- remote `trunk_dev` unchanged;
- worktree/index clean;
- one worktree;
- no Git operation, lock, unmerged path, cache, bytecode, database, journal,
  archive, build, recorder, or test residue;
- exactly one feature-branch commit over the accepted base;
- accepted manifest blobs equal commit blobs;
- accepted audit and all retained evidence roots unchanged;
- no conflicting tag;
- no auto-merge;
- no branch deletion;
- no release/deployment effect.

Do not switch to `trunk_dev`. Do not merge the PR.

EVIDENCE CLOSEOUT

Retain:

- opening identity;
- accepted audit/index verification;
- all seven protected evidence-root inventories;
- accepted canonical manifest and aggregate identities;
- remote-policy preflight;
- staging manifest and per-path blob comparisons;
- collection and full-suite records;
- commit metadata and tree/blob verification;
- push record and remote-ref transitions;
- PR request/response and final snapshot;
- final guards;
- exact command ledger;
- limitations.

Remove only gate-created transient caches, basetemps, pycache roots, and
temporary validation directories after evidence is sealed.

Create the self-excluding evidence index last and externally verify it.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_SEMANTICS_COMMITTED_PUSHED_AND_PR_OPENED
```

only when:

- accepted bytes were reproduced exactly;
- one commit was created;
- one plain push succeeded;
- one open non-draft PR was created;
- no merge occurred;
- final guards and evidence index are green.

STOP TOKENS

Use an exact primary token appropriate to the first failed stage, including:

```text
COMMIT_GATE_ACCEPTED_BYTES_MISMATCH
COMMIT_GATE_REMOTE_BASE_DRIFT
COMMIT_GATE_REMOTE_POLICY_BLOCK
COMMIT_GATE_STAGING_FAILED
COMMIT_GATE_COLLECTION_FAILED
COMMIT_GATE_FULL_SUITE_FAILED
COMMIT_GATE_COMMIT_FAILED
COMMIT_GATE_PUSH_FAILED
COMMIT_GATE_PR_CREATION_FAILED
```

FINAL REPORT

Include:

1. accepted audit and provenance identities;
2. opening repository identity;
3. remote policy preflight;
4. exact staging inventory and blob equality;
5. collection/full-suite results;
6. commit identity and tree;
7. push command/result and remote refs;
8. PR number, URL, title/body identity, base/head, state, mergeability, checks,
   reviews, and threads;
9. final local/remote guards;
10. evidence-root path and index identity;
11. limitations and confidence.

Required final statements:

```text
IMPLEMENTATION_REPAIR_NOT_PERFORMED
INDEPENDENT_AUDIT_NOT_REPEATED
DIRECT_TRUNK_PUSH_NOT_PERFORMED
BYPASS_NOT_USED
FORCE_PUSH_NOT_PERFORMED
AMEND_NOT_PERFORMED
SECOND_COMMIT_NOT_PERFORMED
SECOND_PUSH_NOT_PERFORMED
SECOND_PR_NOT_CREATED
PR_MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
REVIEW_NOT_SELF_APPROVED
FEATURE_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
COLLECTION_RUN_EXACTLY_ONCE
FULL_SUITE_RUN_EXACTLY_ONCE
```
