PROMPT_ID

RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_FRESH_INDEPENDENT_AUDIT_V1

TITLE

Coordinator RW0-B2-Capability — fresh independent audit of the embedded
B1/RW0 current-contract registries, finite parsers, and deliberate test-node
architecture migration

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated independent audit.

Use a new Codex conversation. Do not use the write-enabled implementation
conversation that produced the registry reset.

The audit parent and all audit subagents are read-only. No repository mutation,
formatting, cleanup of candidate bytes, dependency installation, staging,
commit, push, PR, merge, tag, release, deployment, remote/service/provider/host
contact, product worker/model invocation, database mutation, migration, or
supporting-repository inspection is authorized.

Audit-created probes, clean external archives, pytest outputs, and provenance
records may be written only beneath one new external operator-owned,
non-symlink, mode-0700 audit root.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Determine whether the exact final candidate correctly replaces the failed
whole-document natural-language status oracles with two small, exact,
machine-authoritative current-contract registries without:

- changing production semantics or public surfaces;
- creating a second mutable authority;
- weakening current B1/RW0 facts or later-owner boundaries;
- introducing parser ambiguity;
- hiding duplicate/relocated registries;
- preserving the failed NLP architecture through dead helpers or tests;
- losing unlisted pre-existing test coverage;
- accepting duplicate mutant documents;
- or misbinding validation and provenance.

The audit must treat the deliberate node migration as an architecture reset,
not as an ordinary “all old nodes preserved” patch.

EXPECTED LIVE IDENTITY

Require at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate modes:
all regular 0644
```

Require:

- `git diff --check` clean;
- no Git operation or lock;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, or recorder residue;
- no thirty-first changed path.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

FINAL AUDIT TARGET

Implementation evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB
```

Primary final report:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB/final_report.md
```

Required reported final identities:

```text
canonical-manifest SHA-256:
47ec8ecbd89aaa0924dc3d222f2292b9046d0faaabfadd4850411473aa33f51c

complete recipe-output SHA-256:
3777b40b27cc2e13513eb08c02d77064feea6263cfc56691517531cd0d4b39b7

file count:
30

final pytest node count:
5002

full suite:
5002 collected
5002 passed
attempt 001 only

dirty topology:
30/24/6/0/0
```

Required indexed evidence includes:

```text
migration ledger:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB/node_reconciliation/migration_ledger.jsonl

validation attempts:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB/validation_attempts.json

self-excluding evidence index:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB/evidence_index.jsonl

index rows excluding itself:
232

index SHA-256:
185d17a6332a49b545f50c5e7c33a4e1f6e1150fa799c547dbec40876b643e16
```

Recover and verify from the indexed evidence, rather than infer:

- final canonical-manifest path, byte size, and complete JSON;
- final tracked textual-diff SHA-256;
- complete recipe-output byte size;
- final ordered-node-list SHA-256;
- full-suite summary and JUnit identities;
- exact final node list;
- exact node additions/removals/rename records;
- exact 227-mutant uniqueness ledger and aggregate digest;
- final path/mode/protected-byte guards.

If any mandatory identity is absent, internally inconsistent, unsafe to read,
or not bound by the self-excluding index, return
`AUDIT_PROVENANCE_MISMATCH` before correctness judgment.

OPENING RESET TARGET

The registry reset began from:

```text
manifest:
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB/frozen_final/canonical_manifest.json

canonical-manifest size:
6430 bytes

canonical-manifest SHA-256:
8d5ed37273a3583104b2fb4f5acee045d7cc18799fdda368d2628e75d8807841

complete recipe-output size:
6663 bytes

complete recipe-output SHA-256:
e813ead384d3c88eb897d996c32b93245841279e31c002558c12dc36e9611d0c

opening pytest node count:
5114

opening ordered-node-list SHA-256:
f3d83ce79954e7296b9406da6fcaa84a6676284d9504c7a9c30292d92c8fe8ae
```

Exactly these four entries must differ from that opening target:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md
tests/test_rw0-b1-boundaries.py
tests/test_rw0-remote-contact-phase-entry-contract.py
```

Use the actual repository paths with underscores:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The other twenty-six opening entries must be byte-, kind-, type-, mode-, size-,
and classification-identical.

PRECEDING AUDIT EVIDENCE

The audit whose result triggered this architecture reset is:

```text
root:
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-continuation-audit.HLejOJ

report:
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-continuation-audit.HLejOJ/audit_report.md

self-excluding index:
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-continuation-audit.HLejOJ/evidence_index.jsonl

index rows excluding itself:
48

index SHA-256:
4ef63b4f51edb0bb60e404ed6094b3d4b0b6f7f94854d7716ac8b290447a2ac2
```

Verify it safely and preserve it unchanged.

EXACT RECIPE SOURCE

Use the exact retained recipe source located through the implementation
evidence index.

Require:

```text
type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Do not decode recipe source from prompt text. Do not reconstruct or approximate
it from a digest.

Run the exact source twice with source bytes unchanged and only its external
fixed output sink safely redirected to two unique audit-root files. Retain the
wrapper source and prove redirection cannot affect Git queries, stdout,
canonical JSON, or any other recipe behavior.

PROVENANCE GATE

Before correctness inspection or audit subagents:

1. create one new operator-owned, non-symlink, mode-0700 audit root beneath
   `/private/tmp`;

2. safely `lstat` every retained-evidence path component;

3. verify both self-excluding evidence indexes exactly;

4. independently inventory both evidence roots and compare them again at
   closeout;

5. verify exact repository identity and `30/24/6/0/0` topology;

6. locate the indexed final canonical manifest through the final report and
   evidence index;

7. require canonical JSON, file count 30, and SHA-256
   `47ec8ecbd89aaa0924dc3d222f2292b9046d0faaabfadd4850411473aa33f51c`;

8. verify every manifest entry by classification, regular-file type, mode,
   size, and SHA-256;

9. verify no thirty-first changed path;

10. verify every path outside the manifest equals HEAD;

11. verify the exact retained recipe source;

12. execute it twice with safe sink redirection;

13. require both generated manifests to equal the retained final manifest
    byte-for-byte;

14. require both complete outputs to be byte-identical and SHA-256
    `3777b40b27cc2e13513eb08c02d77064feea6263cfc56691517531cd0d4b39b7`;

15. require the tracked textual-diff identity recovered from indexed final
    evidence;

16. load and verify the opening reset manifest;

17. prove exactly the four authorized entries changed and the other 26 entries
    remained exact;

18. verify the migration ledger, validation attempts, final node list, full
    suite, uniqueness ledger, final guards, and self-excluding index;

19. verify all explicitly protected production/public surfaces.

On any candidate or mandatory evidence identity mismatch, stop before
correctness inspection and return exactly:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not approximate, regenerate, or silently repair missing evidence.

EXPLICITLY PROTECTED BY THE FOUR-PATH RESET

These must equal the opening reset target:

```text
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/c2a-first-slice-semantic-protocol-contract.md
.docs/c2a1-pure-semantic-values.md
.docs/durable-state-model.md
.docs/rw0-b2-capability.md
.docs/rw0-b2-wire-protocol.md
.docs/worker-execution-boundary.md

src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml

tests/test_architecture_contracts.py
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_section41_pre_execution_plan_disposition_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_worker_execution_semantic_values.py

all SQL, migrations, schemas, catalogs
StateStore
WriterSession
package exports
dependency metadata
```

ACCEPTED CURRENT FACTS

Do not treat the audit as permission to change these facts.

B1 registry-owned facts:

```text
component:
RW0-B1

retrieval_event_sequence_work_maximum:
1285

sole_current_cross_module_production_consumer:
RW0-B2-Capability

source_authentication:
none

executable_permission:
none

durable_persistence:
none

semantic_acceptance:
none
```

RW0 composition/status-owned facts:

```text
RW0-B1:
current_implemented
private_pure_no_io_semantics

RW0-B2-Wire:
current_implemented
private_pure_no_io_semantics

RW0-B2-Capability:
current_implemented
private_pure_no_io_semantics

RW0-C:
future durable semantics and recovery

RW0-D:
future physical custody, transport, process, provider, and cancellation
mechanics

RW0-E:
future separately authorized live proof

Execution Substrate:
current external owner of admission, reliable submit, runtime identity,
lifecycle, cancellation correlation, and retained results
```

No current B value, frame, digest, declaration, observation, qualification, or
test authenticates a source, grants executable permission or semantic
acceptance, persists durable truth, or creates runtime/provider/Git/publication
authority.

REGISTRY AUTHORITY MODEL

Audit this exact model:

1. Each registry is the sole machine-authoritative projection for the finite
   facts it enumerates.

2. Detailed prose outside the registry remains governing explanatory contract
   text.

3. Tests explicitly do not claim to decide arbitrary natural-language
   contradiction, paraphrase, polarity, negation, or semantic equivalence in
   that prose.

4. B1 owns local `1285`, sole current consumer, and B1-local nonclaims.

5. RW0 owns lifecycle and cross-tranche C/D/E/ES composition.

6. B1 lifecycle/future-owner rows are explicitly labeled one-way projections
   from the RW0 owner.

7. No supporting document, test, report, or generated artifact becomes a
   second registry writer.

AUDIT PERSPECTIVES

After the provenance gate, use exactly four bounded, non-nesting, read-only
perspectives when available. No child runs tests or modifies files.

1. B1 registry and finite-parser auditor
   - exact source block, location, markers, version, header, rows, order, roles,
     sources, values, and canonical projection;
   - authority versus projection split;
   - strict encoding/LF/ASCII-line grammar;
   - marker uniqueness and visibility;
   - fence/comment handling;
   - B1-to-RW0 one-way projection;
   - finite diagnostics;
   - no NLP remnants or second writer.

2. RW0 registry and finite-parser auditor
   - exact seven-row block, first-H2 location, outer markers, version, header,
     row order, lifecycle, contract class, owner, detail contract, authority
     posture, implementation posture, and explicit nonclaim strings;
   - exact source-line grammar;
   - marker uniqueness and visibility;
   - fence/comment handling;
   - current/future/externally-owned boundaries;
   - no provider/mechanism selection or semantic authority widening.

3. Test migration and mutation-adequacy auditor
   - all 384 opening owner nodes represented exactly once in the migration
     ledger;
   - 347 removals, 235 additions, one explicit rename, retained intersection
     4767;
   - 4,730 outside-owner nodes preserved in exact relative order;
   - all 22 byte-identical aliases removed;
   - 227 generated mutant documents and 227 unique digests;
   - old NLP helpers/corpora removed or unreachable;
   - exact structural/value/cross-document mutants;
   - false-positive prose-isolation controls;
   - no duplicate mutant bytes, vacuous parameterization, unlisted loss, or
     weakened unrelated assertions.

4. Provenance, validation, public-boundary, and authority auditor
   - exact four-entry delta and 26-entry equality;
   - implementation evidence and migration-ledger binding;
   - node lists, full-suite evidence, and candidate fingerprints;
   - imports, exports, callers, protected bytes, and unchanged production;
   - prose authority policy and supporting-document projection posture;
   - later C/D/E/ES seams and absence of widened authority.

The parent performs reconciliation, independent external mutants, node
comparison, validation, and closeout. Preserve disagreements.

Every finding must include:

```text
ID
type
severity: critical | high | medium | low | observation
current contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect or pre-existing issue
```

REQUIRED SOURCE AND TEST INSPECTION

Inspect all four changed files completely:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Inspect protected adjacent owners and tests needed for non-regression:

```text
.docs/rw0-b2-capability.md
.docs/rw0-b2-wire-protocol.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
.docs/software-development-progression-boundary.md
AGENTS.md

src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml

tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py
tests/test_remote_worker_pre_execution_planning_contract.py
```

Inspect additional Coordinator files only for a concrete dependency and record
why. Do not inspect another repository.

EXACT B1 REGISTRY CONTRACT

Require the following exact source block as the first H2 immediately before
`## Closed value grammar`:

```markdown
## Current-contract registry

Only the bounded registry below is machine-authoritative for the facts that it
owns. Projection rows consume their named owner and create no second authority.

<!-- RW0_B1_CURRENT_CONTRACT_REGISTRY_BEGIN -->
Registry version: 1

| Fact | Value | Role | Source |
| --- | --- | --- | --- |
| component | RW0-B1 | authority | this_document |
| lifecycle_status | current_implemented | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
| contract_class | private_pure_no_io_semantics | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
| retrieval_event_sequence_work_maximum | 1285 | authority | this_document |
| sole_current_cross_module_production_consumer | RW0-B2-Capability | authority | this_document |
| source_authentication | none | authority | this_document |
| executable_permission | none | authority | this_document |
| durable_persistence | none | authority | this_document |
| semantic_acceptance | none | authority | this_document |
| future_acceptance_latch_owner | RW0-C | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
| future_durable_ingest_completeness_recovery_terminal_owner | RW0-C | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
| future_physical_custody_transport_process_cancellation_owner | RW0-D | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
| future_separately_authorized_live_proof_owner | RW0-E | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
| es_admission_reliable_submit_runtime_identity_lifecycle_cancellation_results_owner | Execution Substrate | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
<!-- RW0_B1_CURRENT_CONTRACT_REGISTRY_END -->
```

Audit:

- exact heading and location;
- exact policy lines;
- exact unique markers;
- exact version;
- exact header/separator;
- exact 14 rows and order;
- exact role/source classification;
- exact integer parsing of 1285;
- canonical projection independent of document text;
- no digest/schema/runtime identity introduced;
- no machine-status writer outside the registry.

EXACT RW0 REGISTRY CONTRACT

Require this exact source block as the first live H2 immediately after
`COORDINATOR_RW0_PHASE_ENTRY_CONTRACT_BEGIN` and before the existing Status H2:

```markdown
## Current-contract registry

Only the bounded registry below is machine-authoritative for the facts that it
owns. Projection rows consume their named owner and create no second authority.

<!-- COORDINATOR_RW0_CURRENT_CONTRACT_REGISTRY_BEGIN -->
Registry version: 1

| Component | Lifecycle status | Contract class | Authority owner | Detail contract | Authority posture | Implementation posture | Explicit nonclaims |
| --- | --- | --- | --- | --- | --- | --- | --- |
| RW0-B1 | current_implemented | private_pure_no_io_semantics | RW0-B1 | .docs/rw0-b1-pure-phase-values.md | no_executable_authority | implemented_in_this_repository | source_authentication,executable_permission,persistence,semantic_acceptance,acceptance_latch,es_runtime_fact |
| RW0-B2-Wire | current_implemented | private_pure_no_io_semantics | RW0-B2-Wire | .docs/rw0-b2-wire-protocol.md | no_executable_authority | implemented_in_this_repository | physical_transport,stream_process_plumbing,source_authentication,executable_permission,persistence,semantic_acceptance,es_runtime_fact |
| RW0-B2-Capability | current_implemented | private_pure_no_io_semantics | RW0-B2-Capability | .docs/rw0-b2-capability.md | no_executable_authority | implemented_in_this_repository | source_authentication,physical_process_behavior,executable_permission,semantic_acceptance,persistence,provider_runtime_selection,es_runtime_fact |
| RW0-C | future | durable_semantics_and_recovery | RW0-C | this_document | future_guarded_coordinator_progression_only | not_implemented | external_standing_authority,physical_process,es_runtime_fact |
| RW0-D | future | physical_custody_transport_process_provider_cancellation_mechanics | RW0-D | this_document | source_owned_physical_facts_no_semantic_progression | not_implemented | executable_authority,semantic_acceptance,es_runtime_fact,live_credentials,network |
| RW0-E | future | separately_authorized_live_proof | RW0-E | this_document | external_standing_authority_required_no_independent_authority | not_implemented | independent_standing_authority,semantic_progression,git,publication,es_runtime_fact |
| Execution Substrate | current_external_owner | route_admission_reliable_submit_runtime | Execution Substrate | external_contract | admission_and_runtime_authority_only | external_contract_not_implemented_here | coordinator_semantic_progression,semantic_acceptance,publication_authority,external_standing_authority |
<!-- COORDINATOR_RW0_CURRENT_CONTRACT_REGISTRY_END -->
```

Audit every cell and the exact seven-row order.

FINITE PARSER AUDIT

Independently derive the parser grammar from the accepted implementation
contract and compare it with each checked parser.

### Encoding and lines

Require:

- bytes read;
- BOM rejection;
- strict UTF-8;
- literal LF split only;
- CR rejected in registry lines;
- no `splitlines()`;
- Unicode separators remain characters and therefore invalidate exact lines.

### Exact raw lines

Require exact ASCII source lines for:

- heading;
- two policy lines;
- BEGIN marker;
- version line;
- table header;
- separator;
- every row;
- END marker.

Reject:

```text
tabs in canonical lines
trailing spaces
NBSP or Unicode whitespace
Unicode digits
normalization variants
inline emphasis/link/code/escape changes
additional pipes
missing/extra/duplicate/renamed/reordered/relocated lines
```

### Location and global uniqueness

Require exact one globally for:

```text
registry heading
BEGIN
END
Registry version: 1
exact table header
```

Global count includes raw occurrences inside fences/comments.

B1:

- first H2 in file;
- directly before Closed value grammar.

RW0:

- first live H2 after outer BEGIN;
- before Status;
- inside outer markers.

### Fence and comment visibility

Independently challenge:

```text
backtick and tilde
run lengths
0–3 leading spaces
4-space non-opener
backtick info containing backtick
matching marker
shorter closer
opposite marker
ASCII suffix
text suffix
unclosed fence
larger comments
comment-spliced registry line
marker comments
```

Canonical registry lines must all be visible. Do not overclaim general Markdown
parsing.

### Parsing and projection

B1:

- version integer;
- 1285 integer;
- other strings exact.

RW0:

- version integer;
- other strings exact.

Nonclaim comma strings remain atomic ordered strings.

Expected projections must be independent literals.

### Diagnostics

Verify finite content-free diagnostics only:

```text
b1.registry.encoding
b1.registry.fence
b1.registry.marker
b1.registry.visibility
b1.registry.location
b1.registry.version
b1.registry.shape
b1.registry.order
b1.registry.value
b1.registry.projection

rw0.registry.encoding
rw0.registry.fence
rw0.registry.marker
rw0.registry.visibility
rw0.registry.location
rw0.registry.version
rw0.registry.shape
rw0.registry.order
rw0.registry.value
rw0.registry.projection
```

EXTERNAL REGISTRY MUTANTS

Run independent in-memory mutants against the checked parsers. Do not merely
rerun the checked parameter sets.

For each registry test at least:

Structural:

```text
missing/duplicate heading
heading fenced/commented
missing/reversed/duplicate markers
marker fenced/commented
missing/wrong/duplicate version
missing/wrong/duplicate header
missing/extra/duplicate/unknown/renamed row
reordered rows
relocated block
wrong neighboring heading
backtick-hidden
tilde-hidden
unclosed fence
opposite-marker non-close
shorter closer non-close
backtick-info-with-backtick
4-space fence
CR
BOM
Unicode separator
tab
trailing space
NBSP
Unicode digit
inline markup
extra pipe
multiline comment
comment-spliced line
```

Values:

- every B1 row wrong value, role, and source;
- 1284, 1286, sign, leading zero, Unicode digit;
- every RW0 cell wrong;
- current/future swaps;
- owner/detail/posture/implementation/nonclaim mismatch.

Cross-document:

```text
B1 projection mismatch with RW0
RW0 changes with stale B1 copy
B1 authority row changed alone
projection mislabeled authority
authority mislabeled projection
```

False-positive:

```text
unrelated prose before/after
current/future/blocked/deferred words outside registry
Setext rendered-equivalent title
inline-rendered equivalent title
four-space literal heading
ordinary fenced examples without exact reserved tokens
historical prose outside registry
explanatory restatement
ordinary comments
Unicode prose outside exact registry lines
```

Require unique mutant bytes and purpose.

AUTHORITY AND CROSS-DOCUMENT AUDIT

Verify:

1. RW0 registry is the sole composition/status writer.

2. B1 authoritative rows are only:
   - retrieval maximum;
   - sole current consumer;
   - B1-local nonclaims;
   - component identity where appropriate.

3. B1 lifecycle and future-owner rows are projections, not second authority.

4. Parse RW0 first and check B1 projections one-way.

5. Supporting status documents remain projections and unchanged.

6. No report, test, migration ledger, or generated artifact becomes authority.

7. Registry v1 is sufficient for the current exact field inventories. A future
   grammar/inventory change requires v2; an in-enum fact transition does not.

8. Prose-policy tests accurately state the machine-authority boundary without
   claiming prose is irrelevant or non-governing.

NODE MIGRATION AUDIT

Opening:

```text
5114 nodes
```

Reported final:

```text
5002 nodes
```

Reported migration:

```text
outside-owner preserved:
4730

retained intersection:
4767

removed:
347

added:
235

explicitly renamed:
1

opening owner nodes with exactly one migration record:
384

byte-identical aliases removed:
22

generated mutant documents:
227

unique mutant digests:
227
```

Audit the complete migration ledger.

Require:

- every one of 384 opening owner nodes appears exactly once;
- dispositions are from the authorized finite set;
- each removed/renamed node has a source-grounded category and replacement
  purpose;
- no unrelated exact contract/import/public/runtime test was removed;
- all nodes outside the two modified tests retain exact relative order;
- no unlisted removal/rename/skip/xfail/reparameterization;
- retained nodes remain ordered where promised;
- additions belong only to the two modified tests;
- rename mapping is one-to-one;
- 22 alias removals were actually byte-identical before removal;
- 227 generated documents are byte-unique;
- purpose labels are unique enough to prevent volume-only parameter aliases;
- migration-ledger totals reconcile arithmetically with opening/final lists.

Do not require preservation of the failed NLP nodes by inertia.

INDEPENDENT NODE COMPARISON

Run:

1. candidate collection;
2. clean external `git archive HEAD` collection;
3. comparison with opening 5,114 list and migration ledger.

Require candidate final count 5,002 and the final ordered-list hash recovered
from indexed evidence.

Do not assume HEAD-only count zero. Intentional owner-test removals are allowed
only when listed in the migration ledger.

Report:

```text
candidate count/hash
clean HEAD count/hash
intersection
candidate-only
HEAD-only
opening-vs-final retained/removed/renamed/added
outside-owner order
owner migration reconciliation
```

VALIDATION-EVIDENCE REVIEW

Verify every recorded attempt, including:

```text
test-first red:
exactly three missing-registry failures

parser/causal registry tranche:
233 passed

B1 owner:
112 passed

RW0 owner:
160 passed

B1 compatibility:
428 passed

Capability/Wire compatibility:
67 passed

architecture/status/static compatibility:
907 passed

complete suite attempt 001:
5002 passed
zero failures/errors/skips/warnings
empty stderr

attempt 002:
not run
```

Determine:

- red failures were only missing-registry behavior;
- final focused records bind final bytes;
- JUnit identities map exactly to collected nodes;
- full suite binds the final manifest and final node list;
- no hidden second attempt exists;
- cleanup and evidence index are complete;
- no wrapper/procedure defect weakens validation.

INDEPENDENT VALIDATION

Only after source/test inspection, registry mutants, authority review, and
migration audit are green enough, run serially beneath the audit root.

For every child:

```text
umask 022 before launch
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Run:

1. parser-unit and selected causal registry nodes;
2. B1 owner file;
3. RW0 owner file;
4. B1 compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```
5. Capability/Wire compatibility:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
6. architecture/status/static:
   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

Every credited run must have:

```text
return code 0
zero failures/errors/skips/xfails/warnings
empty stderr
parseable JUnit
zero duplicate/unmapped cases
matching caller/child umask
unchanged candidate fingerprint
```

If all inspection and focused validation remain green, run the complete
repository suite exactly once with ordinary quiet rendering.

Require:

```text
5002 collected
5002 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

If a deterministic material blocker is found first, the full suite may be
withheld. State that explicitly. Never repair candidate bytes.

PUBLIC, IMPORT, PRIVACY, AND AUTHORITY BOUNDARY

Require:

- no production source change;
- no package-root export;
- no reverse import;
- no production caller change;
- no dependency, SQL, migration, schema, catalog, StateStore, or WriterSession
  change;
- no filesystem, process, network, provider, Bridge, ES-call, Git,
  publication, or runtime effect;
- no schema/identity/budget/qualification change;
- no second registry writer;
- no generated artifact as authority;
- Capability remains private pure supplied-fact semantics;
- source refs/digests remain unauthenticated evidence;
- no permission, acceptance, persistence, or runtime authority;
- C/D/E and ES remain later/external owners.

CLOSEOUT

After removing only audit-created transient artifacts:

1. rerun the exact recipe twice with safe sink redirection;
2. require exact equality to the opening final target;
3. require the same manifest, complete output, textual diff, file count,
   per-path hashes, and topology;
4. compare implementation-evidence opening and closing inventories;
5. verify preceding audit evidence unchanged;
6. verify no operation, lock, staged/unmerged path, cache, bytecode, database,
   journal, archive, build, recorder, or generated-manifest residue;
7. retain all audit evidence beneath the new mode-0700 root;
8. make retained audit files regular, operator-owned, and mode 0400;
9. create a self-excluding evidence index.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low candidate defect remains;
- `BLOCK` for any repairable registry, parser, migration, test, evidence,
  validation, privacy, authority, or public-boundary defect;
- `REJECT` only for a fundamental authority/architecture contradiction that
  cannot be repaired within the accepted four-file reset;
- `AUDIT_PROVENANCE_MISMATCH` only for target/evidence identity failure before
  correctness judgment.

If `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or create a PR.

FINAL REPORT

Include:

1. opening and closing identity;
2. exact provenance and four-entry delta;
3. evidence-index and retained-record verification;
4. four audit perspectives and disagreements;
5. severity-ranked finding ledger;
6. B1 registry exactness and authority result;
7. RW0 registry exactness and authority result;
8. finite parser and external-mutant result;
9. cross-document projection result;
10. prose authority policy result;
11. migration-ledger and alias-removal result;
12. node comparison and final node hash;
13. validation-evidence assessment;
14. independent focused/full validation;
15. public/import/privacy/authority assessment;
16. closeout guards;
17. separate provenance, validation, and implementation confidence.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
