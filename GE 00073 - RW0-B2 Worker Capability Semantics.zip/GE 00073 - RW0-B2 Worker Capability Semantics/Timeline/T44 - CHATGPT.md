## Engineering disposition

**Accept the `BLOCK`. Do not stage or commit. Return the candidate to the existing workspace-write B2-Wire conversation for a one-file, test-only repair.**

The audit found no production defect. It independently accepted:

- the B2 integer upper-bound implementation;
- parser and duplicate-key behavior;
- bounded traversal and C2A extraction;
- classifier semantics;
- the fixed Wire profile and frame limits;
- authority, privacy, package, schema, migration, and public-surface boundaries;
- the literal pending-frame oracle.

The remaining blockers are both in:

```text
tests/test_rw0_b2_wire_relations.py
```

This is exactly the kind of noncausal-mutant risk that the pre-implementation B2 forecast identified. 

## Frozen repair decisions

### 1. Execute every exact-valid inventory row

The existing 64-path matrix declares a `valid` value for every row, but only behaviorally executes oversized mutations. The repair must preserve the same literal 64-row inventory and make every declared valid value pass through its recorded public Wire boundary.

For each row:

1. Start from a fresh, complete, valid, related graph.
2. Place the declared valid value at the exact target field.
3. Adjust only the minimum companion coordinates needed for graph coherence.
4. Invoke the recorded Wire boundary.
5. Assert successful reconstruction, relation, classification, or encoding.
6. Prove the intended owner class and field path were actually reached.
7. Continue to exercise `MAX + 1` and the 1,000-digit negative values with zero canonicalization calls.

Equivalent positive fixtures may be deduplicated only when the test mechanically records which literal rows were actually reached. At closeout, the test-local coverage ledger must equal the complete 64-row inventory for:

```text
positive exact-valid coverage
MAX+1 negative coverage
1,000-digit negative coverage
```

For all 15 ceiling fields, at least one coherent graph must use the exact valid maximum:

```text
9_223_372_036_854_775_807
```

and traverse every applicable owner path. This must include the auditor’s concrete counterexample field:

```text
max_active_invocations
```

The active process-exit controls remain:

```text
-255
0
255
```

### 2. Make the selective control truly one-check selective

The current control disables all 16 AttemptFence integer checks. Replace it with a control that bypasses exactly one literal combination:

```text
owner class
field path
target object identity or explicit test token
oversized value
```

Require:

```text
selected_bypass_count == 1
```

The other 15 Attempt integer checks must still call the authoritative production guard.

The control must also prove that the **Attempt-specific** owner reconstruction or canonicalization boundary was reached. A generic “some spy fired” assertion is not sufficient.

An unrelated oversized EffectFence case must still:

```text
return invalid_field_value
make zero Effect owner/Wire canonicalization calls
observe zero selected Attempt bypasses
```

A class-wide Attempt bypass must fail the repaired test.

## Exact scope

Only one candidate file may change:

```text
tests/test_rw0_b2_wire_relations.py
```

The following must remain byte-identical:

```text
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
.docs/rw0-b2-wire-protocol.md
tests/test_rw0_b2_wire_codec.py
```

as must the other 12 candidate paths.

No new test node is authorized. Opening and final collection must both remain:

```text
4,655
```

with byte-identical node IDs and ordering.

The tracked textual-diff SHA-256 must remain:

```text
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6
```

A newly exposed production defect is a stop condition, not authorization to edit source.

## Next action

Send this complete prompt to the **existing workspace-write RW0-B2-Wire conversation**:

:chatgpt-content-reference{index="3"}

Verify the attachment:

```text
Filename:
Coordinator_RW0_B2_Wire_Fifth_Audit_Test_Repair_Prompt.txt

Size:
23,367 bytes

SHA-256:
a4437e663707b2edfbd76b808f33441b6ba4de9468c2a93b99a111d1763543f6
```

The required success token is:

```text
COORDINATOR_RW0_B2_WIRE_FIFTH_AUDIT_TEST_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

After that result, start another **fresh read-only independent audit**. Exact provenance and a green suite do not by themselves establish test sufficiency or correctness.  The project protocol requires audit findings to return to the sole writer and the changed bytes to receive another independent audit.  Only an accepted audit permits staging the exact audited paths, comparing staged blobs with the manifest, validating without byte changes, and committing once. 

### Sources

- Codex fifth independent-audit response supplied in this turn.
- Original forecast of noncausal-mutant and validation risks. 
- Governed repair and fresh-audit lifecycle. 
- Provenance limits and audited-byte commit sequence.  

**Confidence:** Very high that production should remain frozen; very high that both test findings are real; high that they can be closed by modifying only the existing 64-path test body without changing node identity.
