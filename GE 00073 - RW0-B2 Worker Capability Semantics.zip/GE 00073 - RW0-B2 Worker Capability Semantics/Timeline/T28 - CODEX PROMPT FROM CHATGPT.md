PROMPT_ID

RW0_B2_WIRE_FIRST_AUDIT_REPAIR_V1

TITLE

Coordinator RW0-B2-Wire — repair the first independent-audit findings and
prepare exact bytes for a fresh re-audit

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing
`codex/rw0-b2-wire-protocol-v1` implementation conversation.

Do not create or resume subagents. You are the sole repository writer.

This is a bounded repair after an independent read-only `BLOCK`. It is not a
new reconnaissance, schema redesign, Capability implementation, independent
audit, commit gate, publication gate, merge, deployment, or runtime proof.

Do not stage, commit, push, create or modify a PR, merge, tag, release, deploy,
contact a remote, invoke a worker/model/provider, modify a supporting
repository, or install dependencies.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Close every first-audit patch defect without reopening the accepted
RW0-B2-Wire architecture:

1. eliminate all foreign-exception cause/context and hostile-payload leakage;
2. make every private immutable value fail closed against ordinary,
   uninitialized, or bypass-constructed instances;
3. repair hostile-input key, raw-pair, shape, and one-pass work accounting;
4. distinguish exact duplicate fact identities from distinct conflicting
   singleton facts;
5. make the supplied cancellation graph the deterministic authority for request
   and response relation classification;
6. reconcile stale current-status wording about implemented private NWPF
   representation versus still-deferred physical transport/process framing;
7. add independent, causal exact-cap, error-chain, C2A-relation, privacy,
   classifier, and precedence tests;
8. preserve the exact frame/profile identities, B1/C2A bytes, private/no-I/O
   boundary, 16-path maximum scope, and Capability seam.

Return the repaired exact candidate for a fresh independent audit.

OPENING TARGET

Before any mutation, require exactly:

- physical root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- subject:
  `feat: implement RW0-B1 pure phase-entry semantics (#3)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- dirty paths:
  `16`
- tracked modifications:
  `10`
- untracked additions:
  `6`
- staged/unmerged:
  `0/0`
- every candidate path:
  regular mode `0644`
- no Git operation, lock, repository cache, bytecode, database, journal,
  archive, build, generated manifest, or recorder residue
- `git diff --check`:
  clean.

Immutable opening audit target:

```text
/private/tmp/rw0-b2-wire-v4.b4HlRt/final_001.manifest.json
```

Required opening identities:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe source size:
3_945 bytes

recipe source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

tracked textual-diff SHA-256:
eb2e81a99c851c78d51db1e753b896841b1ded7856400270ba6a1ffc276ea4f5

canonical-manifest SHA-256:
11cb3375a687c00c221a56a8fdd1333a64bed189c697030894ba82abdd03a10a

complete-output SHA-256:
b0bcdb23305ff910cf5b2c2a484ed56aaceb284c875df4262533d8679cef0822

file count:
16
```

Retained first-audit root:

```text
/private/tmp/rw0-b2-wire-independent-audit.hX8xit
```

Require both implementation and audit evidence roots to remain unchanged.

EXACT RECIPE SOURCE

Decode this base64 only into a new external repair root, verify its exact size
and SHA-256, and retain it mode `0400`:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

Execute the exact source unchanged with only its exact historical
`Path.write_bytes` sink redirected into the new repair root. Do not overwrite
pre-existing fixed-path evidence.

OPENING PROVENANCE GATE

Before editing:

1. lstat every component of the implementation manifest, evidence roots, repair
   root, and copied recipe;
2. require safe ownership, no symlink traversal, and regular files;
3. verify the immutable opening manifest exactly;
4. run the exact recipe twice;
5. require both complete outputs and manifests to be byte-identical and equal
   the immutable target;
6. verify every live candidate entry against the manifest by path,
   classification, type, mode, size, and SHA-256;
7. verify protected complement equality to HEAD;
8. collect the complete opening node list exactly once under isolated external
   paths.

Stop before mutation on any mismatch. Do not reset, clean, or recreate the
candidate.

FIRST-AUDIT FINDINGS

Treat the independent audit’s reproduced findings as authoritative repair
inputs:

```text
F1 High   foreign exception payload leak through __context__/__cause__
F2 High   ordinary/uninitialized immutable-value construction
F3 Medium hostile-input/key/raw-pair/shape/work accounting gaps
F4 Medium distinct conflicting exits classified as duplicate
F5 Medium stale current-status framing-deferred prose
F6 Medium missing/noncausal tests and precedence matrix
F7 Medium context-sensitive cancellation graph mismatch reason
```

The audit found no architecture rejection, authority widening, public export,
dependency/schema/migration change, or Capability contradiction.

ENGINEERING DECISIONS — FROZEN FOR THIS REPAIR

A. Exception and hostile-payload isolation

Every public `RW0WireProtocolError` leaving a constructor, decoder, relation, or
classifier must satisfy:

```text
error.__cause__ is None
error.__context__ is None
```

and no hostile bytes/text may be reachable through:

- the exception object;
- `args`;
- `repr` or `str`;
- cause/context traversal;
- traceback frame locals retained by the public exception.

Required implementation discipline:

1. Never raise the public error from inside an `except` suite.
2. Inside a handler, capture only one finite reason code.
3. Exit the handler.
4. clear/drop references to the foreign exception and hostile payload/text or
   replace them with safe empty sentinels before the public raise;
5. raise the sealed public error only after no foreign exception is active.
6. Apply the same pattern to:
   - UTF-8 translation;
   - JSON/token translation;
   - nested C2A/B2 reconstruction;
   - relation translation;
   - classifier translation.

`raise ... from None` alone is insufficient.

Do not expose foreign error text, payload, document, byte object, path, key, ref,
digest, or source value.

B. Immutable construction and exact-instance revalidation

For all four private value classes:

```text
RW0WireCancellationRequestObservationV1
RW0WireProcessObservationV1
RW0WireWorkerResultV1
RW0WireProcessResultClassificationV1
```

1. Disable ordinary construction through the normal class call.
2. Preserve one private controlled construction path using
   `object.__new__(cls)` only after complete validation.
3. Preserve final/slotted/immutable/non-pickleable behavior.
4. Every public relation, encoder, decoder return-path validator, and classifier
   must revalidate exact type and complete initialization before reading any
   field.
5. A nominal exact instance created with `object.__new__(Class)` or otherwise
   missing a slot must fail with sealed `invalid_field_value`; it must never
   leak raw `AttributeError`.
6. A wrong type remains `invalid_field_type`.
7. Self-digest values must be recomputed and checked before semantic field use.
8. Non-self-digest values must be completely reconstructed or checked against
   their exact closed field/matrix contract before semantic use.

Do not attempt to claim that Python can prevent an explicit
`object.__new__(Class)` bypass. The fail-closed public-boundary validation is the
required defense.

C. Bounded direct-mapping key handling

For each B2 source-claim `from_mapping`:

1. exact built-in `dict` only;
2. O(1) mapping-cardinality preflight before key traversal;
3. exact built-in `str` keys only;
4. define and pin:

```text
MAX_SOURCE_MAPPING_KEY_CHARS = 37
```

which is the maximum literal character length across the accepted source-claim
field names and privacy fragments;

5. reject any longer key with `invalid_length_or_cardinality` before
   `.lower()`, `.isascii()`, encoding, fragment scanning, or comparison;
6. require ASCII for accepted field names;
7. calculate lowercase exactly once per bounded unknown key;
8. reuse that cached lowercase value across the fixed privacy-fragment scan;
9. cardinality and key-length preflight take precedence over
   `privacy_forbidden_material`;
10. within those bounds, a private-fragment unknown key returns
    `privacy_forbidden_material`; another unknown returns `unknown_field`;
11. missing fields remain later than bounded unknown-key handling.

Tests must pin 37 independently and prove 38 is rejected before normalization.

D. Frame parser raw-pair and one-pass shape accounting

Do not collapse JSON object pairs before accounting.

Required parse model:

1. strict bounded JSON parse returns a private pair-preserving object
   representation for every JSON object;
2. do not raise `duplicate_key` from `object_pairs_hook`, because a later syntax
   error must retain `json_token_invalid` precedence;
3. after complete syntax success, perform one bounded traversal that:
   - charges every raw object pair, including duplicates;
   - tracks duplicate keys;
   - enforces key-length/type rules;
   - counts depth, containers, key pairs, and scalar leaves;
   - checks collection cardinality before enqueueing children;
   - appends children one at a time;
   - never bulk-extends an attacker-sized collection;
   - builds the ordinary fresh tree only if no duplicate exists;
4. `duplicate_key` precedes structural/root errors after syntax success;
5. structural depth/container/key/scalar failures precede
   `work_limit_exceeded`;
6. preserve exactly one hostile-tree shape calculation;
7. remove any second `_shape_work` or equivalent traversal of the same hostile
   tree;
8. canonical re-encoding remains the separately charged canonical byte pass over
   reconstructed safe values;
9. all raw parser pairs remain metered even if a duplicate will later be
   rejected.

The payload cap remains the hard physical upper bound. Do not change the frozen
profile caps or hostile-unit constants.

E. Duplicate versus conflicting facts

Freeze these definitions:

```text
duplicate_fact
```

means the same fact identity is repeated:

- same ref; or
- same digest; or
- the exact same value object appears more than once.

```text
conflicting_fact
```

means two distinct valid identities occupy one singleton semantic slot or make
mutually exclusive claims:

- two distinct `process_exited` facts, regardless of whether exit codes match;
- two distinct facts of another at-most-one adapter kind;
- two distinct process supplements of one event kind;
- acknowledgement plus rejection;
- any other distinct singleton-kind collision.

Cardinality excess with no parsed exact values remains `invalid_input`.

Two distinct exits with codes `0` and `1` must be:

```text
invalid / conflicting_fact
```

not `duplicate_fact`.

F. Authoritative cancellation graph

The explicit supplied:

```text
cancellation_effect_fence
cancellation_delivery
```

together with the exact author target graph is the single authoritative
cancellation graph for classifier evaluation.

Evaluation order:

1. validate the supplied cancellation graph and immutable target against the
   author command/result graph;
2. if a request exists, validate it against that supplied graph;
3. validate every acknowledgement/rejection against that same supplied graph;
4. any request/response mismatch against the supplied graph returns:

```text
invalid / cancellation_graph_mismatch
```

regardless of whether the supplied graph matches the request, the response, or
neither;

5. do not first classify a cancellation fact as generic `unrelated_fact`;
6. reserve `unrelated_fact` for non-cancellation facts whose ordinary author
   lineage is unrelated;
7. preserve request/response source-kind/ref/invocation non-collapse;
8. preserve all higher resource/deadline/signal precedence after input validity
   is established.

This clarifies detailed classifier semantics without changing the fixed profile
manifest, reason inventory, reason order, profile byte length, or profile
digest.

G. Privacy taxonomy

Freeze this exact distinction:

1. `privacy_forbidden_material` is a direct source-claim construction/relation
   reason.
2. Cancellation-request and process-observation values are classifier inputs;
   they are not command/result frame payloads.
3. The NWPF frame decoder’s frozen reason list therefore remains unchanged.
4. A nested framed C2A reconstruction failure remains
   `nested_record_invalid`; do not add `privacy_forbidden_material` to the
   profile decoder-error list.
5. Cardinality-first or key-length-first rejection may return
   `invalid_length_or_cardinality` without scanning for a private fragment.
6. The IPv4-shaped-ref rule applies to every B2-defined ref field.
7. It does not retroactively invalidate or rewrite nested pre-existing C2A refs.
8. Wire must not import B1.

H. Current-status wording

Correct the four authoritative current documents that say exact framing remains
deferred:

```text
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
```

Required distinction:

- implemented now:
  private, pure, no-I/O NWPF v1 representational framing, canonical codecs,
  worker-result grammar, safe supplied source-claim values, and pure
  process/result classification;

- still deferred:
  physical transport framing, stream/process plumbing, pre-read allocation,
  supervisor/worker implementation, cancellation delivery, concrete direct-
  local or ES wrapper/correlation mechanics, persistence, source
  authentication, process proof, Capability, CLI/App Server, credentials,
  provider/session behavior, and live execution.

Do not call the private source tranche worker contact, runtime framing, physical
transport, or executable authority.

Update the existing structural/current-status oracles in existing nodes. Do not
add new test nodes to existing test files.

I. Profile and accepted identities

These must remain exact:

```text
profile_ref:
rw0-wire-nwpf-v1

canonical profile identity bytes:
4_021

profile digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454

command payload cap:
5_898

result payload cap:
16_627

command/result hostile units:
23_746 / 66_770
```

A need to change any of those is a mandatory stop and requires a separate
design refreeze.

MAXIMUM REPAIR ALLOWLIST

The repair may modify only paths already in the exact 16-path candidate:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

No seventeenth dirty path is authorized.

Expected substantive repair paths are:

- Wire source;
- Wire governing document;
- four direct Wire tests;
- four stale-status documents;
- existing status/oracle tests as needed.

Inventory-only files should remain byte-identical unless a direct, causal
repair requirement is demonstrated in the final report.

Protected byte-identical surfaces include all C2A/B1 source/docs/direct tests,
package root, dependencies, SQL, migrations, schemas, `StateStore`,
`WriterSession`, public protocols, production callers, and every path outside
the 16-path set.

TEST-FIRST CAUSAL EVIDENCE

Before production repair:

1. add the new causal tests only in the four new Wire test files;
2. preserve all opening nodes;
3. run one selected red gate against the opening source bytes;
4. require deterministic expected failures for the new defect probes;
5. capture repository fingerprints after test edits and before/after the red
   run;
6. do not edit docs or production source before the red evidence is retained.

The red set must include at least:

- malformed JSON context/cause/payload-graph leak;
- invalid UTF-8 context/cause/payload-graph leak;
- nested C2A reconstruction translation leak;
- direct ordinary construction of all four values;
- `object.__new__` uninitialized request/process/result/classification passed to
  every applicable public boundary;
- 38-character direct mapping key;
- bounded private key versus oversized private key precedence;
- duplicate raw pairs counted before collapse;
- one-pass shape accounting sensitivity;
- two distinct process exits;
- both orientations of request/response graph mismatch;
- one mutation detectable only by the owning C2A delivery or observation
  relation.

A red test is causal only when it fails on the intended predicate rather than
fixture setup, earlier validation, or an unrelated invariant.

FINAL DIRECT TEST REQUIREMENTS

A. Exact maximum fixtures

Tests must independently own complete literal field inventories and construct
fully related actual maximum fixtures:

```text
command payload exactly 5_898 bytes
command frame exactly 5_906 bytes
result payload exactly 16_627 bytes
result frame exactly 16_635 bytes
```

Each maximum must encode, decode, and satisfy relations.

Also test:

- one semantic decrement below each maximum;
- declared cap plus one rejected before payload access;
- actual trailing byte;
- concatenated frame;
- one-over depth/container/key/scalar;
- injected work `23_747` and `66_771`.

Do not prove the cap only through arithmetic over production constants.

B. Foreign error graph

For malformed JSON, invalid UTF-8, nested reconstruction failure, and relation
translation:

- assert exact public reason;
- assert `__cause__ is None`;
- assert `__context__ is None`;
- walk the complete exception graph;
- inspect traceback locals reachable from the raised public exception;
- assert hostile sentinels and payload bytes/text are absent;
- assert constant `str` and `repr`.

C. Construction/fail-closed matrix

For all four classes:

- ordinary class call rejects;
- subclassing rejects;
- pickle rejects;
- `object.__new__` instance reaches no raw slot error;
- every applicable encoder/relation/classifier returns a sealed finite reason;
- tampered or incomplete self-digest values reject before semantic use.

D. Work/key/raw-pair controls

Independently pin:

```text
MAX_SOURCE_MAPPING_KEY_CHARS = 37
```

Cover:

- 37-character bounded unknown key;
- 38-character key;
- every privacy fragment;
- oversized private-fragment key yielding length/cardinality, not privacy;
- raw duplicate pairs whose work is still counted;
- syntax failure later in a document outranking an earlier duplicate;
- no duplicate but pair-count/shape overflow;
- no second hostile-tree shape traversal;
- no bulk enqueue before caps.

Use local broken controls or instrumentation to prove causality where source
inspection alone is insufficient.

E. C2A-relation causality

For command delivery, worker observations, target delivery, and cancellation
delivery:

- create at least one mutation valid under B2’s local equality checks but invalid
  only under the required owning C2A relation;
- prove a deliberately broken/no-op relation control accepts it;
- prove the authoritative B2 relation rejects because it invokes the actual C2A
  relation.

F. Complete classifier matrix

Cover every pairwise precedence tier and at least:

- exact duplicate identity;
- same digest/different ref;
- same ref/different digest;
- two distinct same-code exits;
- two distinct different-code exits;
- duplicate deadline facts;
- duplicate supplement kinds;
- acknowledgement plus rejection;
- request graph A/response graph B with supplied A;
- request graph A/response graph B with supplied B;
- supplied graph matching neither;
- unrelated non-cancellation fact;
- malformed/missing result under each higher process tier;
- zero/nonzero/missing exit;
- complete classification/reason constructor matrix.

G. Privacy scope

Cover every B2-defined ref field family with an IPv4-shaped mutation. Do not
expect B2 to reject a nested C2A ref that C2A itself accepts.

DOCUMENT/STATUS TESTS

Extend existing nodes only. Require:

- all four stale phrases are rejected as current claims;
- implemented private representation is distinguished from deferred physical
  framing/transport;
- synchronized current-status blocks remain visible, uniquely owned, unfenced,
  and causally protected;
- all prior nonclaims remain exact;
- no new test node appears in an existing test file.

NODE IDENTITY

Opening collection is expected to contain:

```text
4_626 nodes
```

After repair:

- every opening node remains in relative order;
- no opening node is renamed, removed, skipped, xfailed, collapsed, or
  reparameterized;
- every new node belongs to exactly one of the four new Wire test files;
- no new node belongs to an existing test file;
- report the literal final count and complete addition list; do not predeclare
  the number of new nodes.

VALIDATION POSTURE

Create one new external operator-owned, non-symlink, mode-0700 repair root.

For every pytest child use:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
actual caller/child numerical umask equality
```

Retain exact argv, environment, timing, return code, stdout/stderr, JUnit,
structured counts, and repository fingerprints.

FINAL VALIDATION ORDER

After production/docs repair and final node collection:

1. selected causal tests;
2. each four Wire files individually;
3. all four Wire files together;
4. corrected C2A/C2A1 compatibility:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_c2a_first_slice_semantic_protocol_contract.py
   tests/test_c2a_effects_and_recovery.py
   ```
5. B1:
   ```text
   tests/test_rw0_b1_*.py
   ```
6. static/public:
   ```text
   tests/test_c2a_nonimplementation.py
   tests/test_runtime_non_authority.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_b2a_writer_session_contract.py
   tests/test_codex_agent_config.py
   ```
7. status/docs:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```
8. `git diff --check`;
9. exact path/mode/protected/public/import/residue/operation/lock guards;
10. complete suite attempt 001 exactly once.

Every final focused gate and the complete suite must have:

- return code 0;
- zero failures, errors, skips, xfails, warnings;
- empty stderr;
- parseable JUnit;
- no duplicate, ambiguous, or unmapped cases;
- unchanged candidate fingerprint before/after.

COMPLETE-SUITE REPAIR POLICY

If final complete-suite attempt 001 fails:

- preserve all evidence;
- repair only when every failure is candidate-caused;
- remain inside the existing 16 paths;
- preserve the frozen profile/bytes/caps/authority;
- preserve final node identities;
- weaken no test;
- rerun every affected focused gate;
- run complete-suite attempt 002 exactly once.

No third complete-suite attempt is authorized.

PROVENANCE

After final green validation and cleanup:

1. require exact topology:
   - 16 dirty paths
   - 10 tracked modifications
   - 6 untracked additions
   - 0 staged
   - 0 unmerged;
2. run the exact recipe twice;
3. require byte-identical complete outputs and canonical manifests;
4. require exactly the 16 original paths;
5. compare every path with the opening audit target;
6. enumerate exactly which candidate entries changed during repair;
7. prove every protected path equals HEAD;
8. retain final:
   - recipe source identity;
   - complete-output SHA-256;
   - textual-diff SHA-256;
   - canonical-manifest SHA-256;
   - complete canonical manifest;
   - node delta;
   - every validation result;
   - final guards.

STOP CONDITIONS

Stop without further mutation if:

- opening provenance differs;
- the audit evidence root or target was changed;
- a seventeenth path is needed;
- any C2A/B1/public/dependency/schema/migration/runtime byte must change;
- profile bytes, digest, caps, or source-ownership decisions must change;
- a foreign payload cannot be removed without changing the public reason
  contract;
- exact maximum fixtures disprove a frozen cap;
- a required C2A-only causal mutation cannot be built from current owners;
- tests require skip/xfail/deletion/renaming/weakening;
- node removals or existing-node identity changes occur;
- validation or provenance remains unstable.

CLOSEOUT TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_WIRE_FIRST_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only if all findings are mechanically closed, final validation is exact-green,
provenance is stable, and no stop condition fires.

The report must include:

1. opening identity and exact audit target;
2. per-finding repair and engineering disposition;
3. test-first red evidence;
4. exact changed paths from the opening candidate;
5. node identity and literal additions;
6. exact maximum fixtures and error-graph results;
7. every validation attempt and result;
8. final manifest and guards;
9. unresolved later-owner seams;
10. separate provenance, validation, and implementation confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
PRIOR_AUDIT_EVIDENCE_PRESERVED
```
