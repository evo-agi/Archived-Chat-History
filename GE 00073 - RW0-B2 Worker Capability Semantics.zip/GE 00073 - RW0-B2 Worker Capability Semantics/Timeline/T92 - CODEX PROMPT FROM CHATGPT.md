PROMPT_ID

RW0_B2_CAPABILITY_COMPLETE_MARKDOWN_ORACLE_AUDIT_PROVENANCE_MISMATCH_DIAGNOSTIC_V1

TITLE

Coordinator RW0-B2-Capability — read-only diagnosis of
AUDIT_PROVENANCE_MISMATCH before any correctness or repair work

ENGAGEMENT TYPE

Continuation in the same fresh read-only independent-audit conversation that
returned:

AUDIT_PROVENANCE_MISMATCH

This is a provenance-only diagnostic. Do not inspect correctness beyond what is
strictly necessary to classify the provenance failure. Do not run pytest. Do
not mutate, format, clean, stage, commit, push, create a PR, contact a remote,
or alter any repository or retained evidence byte.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED LIVE IDENTITY

physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

expected topology:
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
all candidate paths regular mode 0644

FINAL REPAIR EVIDENCE

root:
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB

final report:
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB/final_closeout/final_report.md

42-record closure ledger:
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB/final_closeout/audit_survivor_closure_ledger.json

self-excluding index:
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB/evidence_index.jsonl

reported index:
406 rows excluding itself
SHA-256 225152f9cdb4e096585b97d55d6e4aa667450d1a690638d5ffcd1d4688e2e9ec

reported final manifest SHA-256:
8d5ed37273a3583104b2fb4f5acee045d7cc18799fdda368d2628e75d8807841

reported complete recipe-output SHA-256:
e813ead384d3c88eb897d996c32b93245841279e31c002558c12dc36e9611d0c

reported final node count:
5114

reported full suite:
5114 collected
5114 passed
attempt 001 only

OPENING TEST-ORACLE REPAIR TARGET

root:
/private/tmp/ge-coordinator-rw0-b2-final-test-repair.fqBaN1

opening manifest SHA-256:
230786a458ed8e484c6ec37416f783cd71b5c47ec67a27d2bdd44afc7fe92772

opening tracked textual-diff SHA-256:
7f77ef027a80f0e5cb8dc686fcecf55dc8ca1ef3493c25a5771f7a2be1b9261e

opening complete-output SHA-256:
f33e22e718b8826ad157ccf0f936abebe06b0699af14feb572dc3c5256d27c83

opening nodes:
4905

opening ordered-node-list SHA-256:
1a3b2c384bfe06ee5fdc358e22807cc0e3ad8f0fbeca004a35ee4f97b3adefa9

PRECEDING AUDIT EVIDENCE

root:
/private/tmp/ge-coordinator-rw0-b2-final-test-audit.qOlJrT

index:
/private/tmp/ge-coordinator-rw0-b2-final-test-audit.qOlJrT/evidence_index.jsonl

index:
61 rows excluding itself
10433 bytes
SHA-256 67ad5eeb73458c61da23f8a4ac50791b0abbe721439e73c98e26cc23572c299f

OBJECTIVE

Explain exactly why the provenance gate returned
AUDIT_PROVENANCE_MISMATCH.

Do not answer only with the token again.

Identify the first failed predicate and every consequential failed predicate.
Distinguish live repository bytes from retained evidence, report metadata,
audit-wrapper behavior, and prompt expectation.

REQUIRED DIAGNOSTIC PROCEDURE

1. Preserve the repository and every evidence root byte-for-byte.

2. Report whether each of the following independently matched:

   a. repository root, branch, HEAD, tree, parent, upstream, divergence,
      worktree count, topology, modes, staged/unmerged state;

   b. retained final evidence-index path, type, mode, row count, byte size,
      SHA-256, self-exclusion, and per-entry verification;

   c. retained final canonical-manifest path, byte size, SHA-256, canonical
      JSON, branch/HEAD/upstream, file count, per-entry path/kind/type/mode/
      size/SHA-256;

   d. live working tree versus retained final manifest;

   e. exact recipe source size and SHA-256;

   f. repeated exact-recipe execution and equality to the retained manifest;

   g. complete-output byte size and SHA-256;

   h. tracked textual-diff SHA-256;

   i. opening repair manifest and exact two-entry delta;

   j. the other 28 entries' byte equality;

   k. 42-record closure ledger identity and completeness;

   l. final node-list path, count, ordered SHA-256, and additions list;

   m. full-suite summary, JUnit, node mapping, candidate fingerprint, and
      proof that no second complete-suite attempt ran;

   n. preceding-audit evidence index.

3. For every mismatch, provide:

   - gate item;
   - exact path;
   - expected value;
   - observed value;
   - whether the observed value came from live Git, live filesystem bytes,
     retained evidence, a report, or the audit wrapper;
   - whether the mismatch changes candidate bytes;
   - whether it invalidates implementation validation;
   - whether it can be reconciled read-only.

4. Explicitly answer these questions:

   - Do the current live candidate bytes equal the retained final canonical
     manifest entry-for-entry?
   - Does a fresh exact-recipe run produce a stable manifest?
   - If stable, does it equal the retained final manifest?
   - Did only an aggregate hash, path reference, row count, file mode, or
     report field differ?
   - Is any mandatory evidence file missing or not indexed?
   - Did the audit prompt demand an identity that the implementation report
     never retained?
   - Did the safe recipe-output redirection or audit wrapper change canonical
     behavior?
   - Is the implementation report stale with respect to current bytes?
   - Are current bytes validated by the retained focused and full-suite
     records?

5. Classify the mismatch as exactly one primary category:

   LIVE_CANDIDATE_BYTES_MISMATCH
   FINAL_EVIDENCE_TARGET_MISMATCH
   OPENING_TARGET_OR_DELTA_MISMATCH
   RECIPE_SOURCE_OR_EXECUTION_MISMATCH
   MANDATORY_EVIDENCE_UNAVAILABLE
   AUDIT_WRAPPER_DEFECT
   AUDIT_PROMPT_EXPECTATION_DEFECT
   PROVENANCE_REPORT_METADATA_STALE

6. Apply these disposition rules:

   - If live candidate bytes differ from the retained final manifest, return
     IMPLEMENTATION_REPORT_STALE_BYTES and identify every changed entry.
     Do not proceed to audit.

   - If live bytes, exact recipe, and retained final manifest all agree, but
     only report-level aggregate metadata or an over-specified prompt field is
     stale, return PROVENANCE_BASELINE_READY with one exact corrected audit
     target. Do not rerun implementation or tests.

   - If mandatory evidence is missing and cannot be reproduced without
     implementation-side action, return
     IMPLEMENTATION_CLOSEOUT_EVIDENCE_REGENERATION_REQUIRED and name the
     minimum evidence-only continuation. Do not request source changes.

   - If the audit wrapper caused the mismatch while candidate/evidence bytes
     are sound, return AUDIT_WRAPPER_REPAIR_REQUIRED and provide the exact
     wrapper correction. Do not change the repository.

   - If the recipe source or repeated canonical output is genuinely unstable,
     return PROVENANCE_RECIPE_FAILURE.

7. Do not inspect source correctness, run mutants, collect pytest nodes, or run
   tests during this diagnostic.

FINAL RESPONSE

Return:

1. One primary diagnostic token from the disposition rules above.
2. The exact first failed predicate.
3. A compact expected-versus-observed table.
4. Candidate-byte status.
5. Validation-binding status.
6. Whether the next action belongs in:
   - this read-only audit conversation;
   - the write-enabled implementation conversation as evidence-only closeout;
   - or a new audit after re-baselining.
7. The exact continuation point.
8. Separate provenance, validation-binding, and implementation-assessment
   confidence.

Required statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
CORRECTNESS_AUDIT_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
