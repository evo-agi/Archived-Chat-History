## Engineering disposition

**Proceed to a fresh independent audit. Do not stage or commit yet.**

The implementation report satisfies the reset’s handoff threshold:

- Exactly the authorized four files changed.
- Production source, package surfaces, schemas, migrations, dependencies, and runtime authority remained untouched.
- Both documents now contain explicit, bounded, machine-authoritative registries.
- The parser contract is finite and source-exact rather than an attempted natural-language inference engine.
- The node migration is deliberate and internally reconciled:
  - Opening: `5,114`
  - Retained: `4,767`
  - Removed: `347`
  - Added: `235`
  - Final: `5,002`
  - Explicit rename: `1`
- All `4,730` nodes outside the two owner-test files reportedly retain their exact relative order.
- All `384` opening owner-test nodes have migration records.
- The `22` byte-identical mutation aliases were removed.
- The complete suite passed `5,002/5,002` on attempt 001.
- Final provenance reproduced twice.

The reduction from 5,114 to 5,002 nodes is **not inherently a regression**. This tranche explicitly authorized removal and replacement of the failed NLP architecture. The audit must judge the migration ledger and replacement coverage rather than require unconditional preservation of obsolete tests.

### Highest-risk audit questions

The fresh audit should concentrate on four areas:

1. **Registry authority**
   - RW0 owns lifecycle and cross-tranche status.
   - B1 owns the `1285` limit, sole current Capability consumer, and B1-local nonclaims.
   - B1’s copied lifecycle and future-owner rows must remain clearly labeled projections.
   - No prose, supporting document, test, report, or generated artifact may become a second registry writer.

2. **Finite parser correctness**
   - Strict UTF-8 and literal-LF behavior.
   - Exact source lines, ordering, markers, and version.
   - Fence and comment visibility.
   - No accidental general Markdown or prose-semantic inference.
   - Exact rejection of malformed, hidden, relocated, duplicated, reordered, or wrong-value registries.

3. **Migration integrity**
   - All 384 opening owner nodes represented exactly once in the ledger.
   - All 347 removals justified as failed NLP architecture or aliases.
   - No unrelated contract, import, authority, or boundary test removed.
   - Every one of the 227 generated mutation documents has unique bytes and purpose.
   - The one rename is genuinely one-to-one.

4. **Cross-document projection**
   - Parse RW0 first.
   - Compare only the B1 projection fields against RW0.
   - Keep B1 authority rows independent.
   - Ensure projection checking does not turn B1 into a competing lifecycle writer.

## Fresh independent-audit handoff

Start a **new read-only Codex conversation** and send this complete prompt:

:chatgpt-content-reference{index="0"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Owner_Oracle_Reset_Fresh_Independent_Audit_Prompt.txt

Size:
34,166 bytes

SHA-256:
a82804801f77a9638f22afcb3399e2affb8d5584fe9532da5d77eaeb38e7cb75
```

The prompt binds the audit to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Final topology:
30 dirty
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

Final manifest SHA-256:
47ec8ecbd89aaa0924dc3d222f2292b9046d0faaabfadd4850411473aa33f51c

Complete recipe-output SHA-256:
3777b40b27cc2e13513eb08c02d77064feea6263cfc56691517531cd0d4b39b7

Final node count:
5,002

Evidence root:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB

Evidence-index SHA-256:
185d17a6332a49b545f50c5e7c33a4e1f6e1150fa799c547dbec40876b643e16
```

The audit prompt requires:

- exact provenance reproduction before correctness inspection;
- four independent read-only perspectives;
- external registry and parser mutants;
- complete migration-ledger reconciliation;
- independent candidate and clean-HEAD node collection;
- focused validation;
- one independent 5,002-test full-suite run only if inspection remains green;
- final provenance closeout without modifying candidate bytes.

The only accepting outcome is:

```text
ACCEPT

COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Anything else remains outside the commit gate. Any further byte change returns the work to implementation and requires another fresh audit.

### Source

- Codex owner-oracle reset implementation report supplied in this turn.

**Confidence:** High that the four-file reset is sufficiently bound for independent audit; high that production code should remain protected; acceptance remains unresolved until the registry parser, one-authority-writer model, migration ledger, mutation uniqueness, and independent validation survive the fresh audit.
