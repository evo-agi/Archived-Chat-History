## Disposition

**No repository repair is indicated.** The candidate passed every technical check; the sole blocker was caused by the auditor writing bytecode into the previously sealed G14 evidence root.

Do **not** delete those two entries or modify G14. That would erase evidence of the audit-process failure and create a second provenance problem.

The clean continuation is:

1. Preserve `/private/tmp/g14.OxZUD3` exactly as it now exists.
2. Verify all 549 indexed G14 entries remain exact.
3. Confirm the only unindexed entries are:
   ```text
   __pycache__/
   __pycache__/path_guard.cpython-313.pyc
   ```
4. Materialize a deterministic canonical G14 snapshot containing **only** the indexed entries under a new audit root.
5. Independently verify G15’s complete technical audit and its sealed evidence.
6. Run only lightweight current-candidate checks—19 boundary tests, the three new permanent tests, literal projection, and node collection.
7. Avoid rerunning the 191-mutant corpus and both 5,059-test suites unless a retained-evidence discrepancy appears.
8. Use `python3 -B`, `PYTHONDONTWRITEBYTECODE=1`, and a new-root `PYTHONPYCACHEPREFIX` for every parent and child Python process.
9. Issue acceptance only after the original G14 root, the canonical snapshot, G15, the source repository, and the new audit root all close unchanged.

This treats the original contaminated G14 root as historical audit-process evidence and the indexed snapshot as the pristine representation of the evidence G14 actually sealed. It does not reconstruct unrecorded metadata or rewrite history.

## Fresh acceptance-audit handoff

Start a **new Codex conversation** and send this prompt:

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Capability_G15_Evidence_Restoration_Acceptance_Audit_Prompt.txt

Size:
17,250 bytes

SHA-256:
76b2683974584f7251d17063229a040d07282bed9e07339954e5259524c79df3
```

The audit is bound to:

```text
Candidate tree:
727fb0ecf94680b64fed5e1bb2bccecccde38e4d

Boundary file:
765 lines
36,340 bytes
ff9d9c6df68e6bb17d974c2f2abb0395735d0ead95bc79179daf7fbc01bea351

Final nodes:
5,059
72ca14d20ff8e95384a8fa06b595227fb45bb7884aac295bbe4ae06ac761a0aa

G14 index:
91764a62fb6db27d426a4a86415b29337cd1dff3710c8528160e0e4755dc46b2

G15 technical-audit index:
0e91f20d8603082dc8b7af80bb40d8c4e0035555fafb5ab45c40742725b292d9
```

The accepting result remains:

```text
ACCEPT

COORDINATOR_RW0_B2_CAPABILITY_ASSURANCE_RESET_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Only that result permits another commit/push/PR gate.

**Source:** Codex’s G15 independent-audit response supplied in this turn.  
**Confidence:** High that the candidate itself is technically ready; high that a canonical indexed snapshot is safer than mutating the contaminated historical root; high that complete suite reruns are unnecessary unless the new auditor finds an evidence-binding discrepancy.
