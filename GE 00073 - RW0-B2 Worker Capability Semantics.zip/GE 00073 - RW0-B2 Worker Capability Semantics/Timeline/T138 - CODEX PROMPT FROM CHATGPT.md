PROMPT_ID

RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_REPAIR_EVIDENCE_GAP_DIAGNOSTIC_V1

TITLE

Coordinator RW0-B2-Capability — diagnose REPORT_EVIDENCE_INCOMPLETE after the
final audit-findings repair and determine the minimum safe continuation

ENGAGEMENT TYPE

Read-only evidence diagnosis in the same write-enabled Capability
implementation conversation that returned:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

and then, when asked for the complete immutable closeout, returned:

```text
REPORT_EVIDENCE_INCOMPLETE
```

This is not implementation, validation, independent audit, staging, commit,
push, PR, merge, release, deployment, provider/runtime work, database work, or
supporting-repository work.

Do not edit repository files. Do not rerun pytest, node collection, mutation
probes, A/B/C simulations, full suites, cleanup, or provenance generation.
Do not alter any prior evidence root.

Read-only Git and filesystem inspection is authorized.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Identify exactly which mandatory closeout evidence is incomplete, whether the
live candidate still equals the bytes that produced the success token, and the
minimum next continuation.

Do not answer only with `REPORT_EVIDENCE_INCOMPLETE`.

EXPECTED LIVE IDENTITY

Require and report:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

expected topology:
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644
```

Require:

- `git diff --check` clean;
- cached diff empty;
- no operation/lock/residue;
- source real index unstaged.

OPENING REPAIR TARGET

The final audit-findings repair began from this exact accepted candidate:

```text
canonical-manifest SHA-256:
0919e82038367f54defd36171a19550873f38acae714bd7398e5a56b2fb8d77a

opening pytest node count:
5057

opening ordered-node-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

opening clean candidate tree:
52e32a55dc2e6b023b669810fb244301807f7618
```

Exactly one repository path was authorized to change:

```text
tests/test_rw0_b2_capability_boundaries.py
```

The other twenty-nine candidate entries were required to remain exact.

LATEST INDEPENDENT AUDIT

The repair answered findings from:

```text
root:
/private/tmp/g4.S4uFyK

report:
/private/tmp/g4.S4uFyK/final_report.md

index:
/private/tmp/g4.S4uFyK/evidence_index.jsonl

rows excluding itself:
72

SHA-256:
f4836712bfc0e55dda2bb489401dabc55958016fc3c1778f8ad40a33bc5cb5b9
```

The repaired findings were:

```text
High:
closed reachable-call/no-status guard did not cover constructed/prebuilt argv,
shell strings, and aliased attribute-based calls

Medium:
one protected-content assertion was not causally mutation-sensitive
```

PRE-EXISTING VALIDATION EVIDENCE

Preserve and verify, as applicable:

```text
commit-compatibility repair:
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe
index:
bdffdfd9757302a7940b803f0d5138fdf9f9b41e53d95fcae3209b0e35dae71d

V2 live validation:
/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset2.Udjr4a
index:
a3abd5e9252da88623ab3285a6f560b7b71f151f672d25f6236c3779f806abe9

V3 neutral-path clean validation:
/private/tmp/gv3.efmQ8X
index:
cec6aba32a0243bf2b0b48d147df96ccb2b50ec5b9ec161dc1cc1c0d4f30eee1
```

These validate the pre-final-repair candidate only. Because the repository test
changed again, the latest repair needed new final validation evidence.

DIAGNOSTIC PROCEDURE

1. Verify live repository identity, topology, modes, staged/unmerged state,
   `git diff --check`, real-index state, operations, locks, and residue.

2. Locate every external evidence root created during the final audit-findings
   repair turn. Do not guess a single root. Use retained conversation state,
   terminal records, filesystem timestamps, and safe metadata.

3. Safely `lstat` every evidence-root path component before reading it.

4. For every candidate evidence root, inventory:

```text
absolute path
owner/group/mode
directory/file/symlink posture
creation/modification times
regular-file count
directory count
special/symlink count
total regular bytes
candidate final-report records
candidate provenance records
candidate mutation records
candidate A/B/C records
candidate node records
candidate focused/full validation records
candidate guard/cleanup records
candidate self-excluding index
```

5. Determine whether the success token was based on:
   - complete retained evidence;
   - terminal observations only;
   - partially retained records;
   - or transient records removed during cleanup.

MANDATORY EVIDENCE MATRIX

For every item report exactly one status:

```text
PRESENT_VERIFIED
PRESENT_INCOMPLETE
DERIVABLE_READ_ONLY
MISSING_REQUIRES_VALIDATION_RERUN
MISSING_REQUIRES_IMPLEMENTATION_RERUN
NOT_APPLICABLE
```

Items:

A. opening identity and opening-manifest reproduction;

B. exact opening path identity for
   `tests/test_rw0_b2_capability_boundaries.py`;

C. exact final path identity for that file;

D. exact final canonical manifest;

E. final tracked textual-diff SHA-256;

F. both final recipe runs and complete outputs;

G. exact one-path delta and twenty-nine-path equality;

H. selected red evidence for no-status and protected-content survivors;

I. final closed reachable-call inventory;

J. module-global identity/type inventory;

K. every constructed/aliased/dynamic call mutant and result;

L. literal final 43-row projection;

M. projection row IDs, purposes, contract classes, expected values, and
   diagnostics;

N. protected-content causal ledger for every protected-content row;

O. exact prior-audit survivor and its final kill record;

P. stable-contract mutation matrix;

Q. State A live-unstaged target/projection record;

R. State B alternate-index staged target/projection/tree record;

S. State C fully external clean-commit target/projection/tree record;

T. proof that B/C final trees are equal;

U. opening node list;

V. final node list and ordered SHA-256;

W. node additions/removals/renames and outside-file order;

X. final selected-causal pytest record;

Y. Capability-boundary focused record;

Z. Capability-complete focused record;

AA. B1/Wire compatibility record;

AB. architecture/status/static record;

AC. live complete-suite summary/stdout/stderr/JUnit/node mapping;

AD. live suite run-local pre/post source fingerprints;

AE. clean complete-suite summary/stdout/stderr/JUnit/node mapping;

AF. clean suite run-local source pre/post fingerprints;

AG. clean suite run-local external-repository pre/post fingerprints;

AH. clean repository commit/tree/object-isolation record;

AI. final path/mode/import/public/authority guards;

AJ. cleanup record;

AK. final self-excluding evidence index;

AL. complete final closeout report.

LIVE BYTE STATUS

Without running tests:

1. hash the sole authorized repository path and compare it with:
   - the opening accepted manifest;
   - any retained final manifest;
   - any retained terminal report fragments;

2. verify the other twenty-nine candidate entries remain exact;

3. verify every path outside the thirty-path candidate equals HEAD;

4. report whether current bytes are:
   - exactly the claimed final repaired bytes;
   - changed after the success token;
   - or not bindable because no final target was retained.

READ-ONLY DERIVATION RULES

A record is `DERIVABLE_READ_ONLY` only when it can be reconstructed exactly from
immutable retained evidence without rerunning pytest, mutation probes, A/B/C
simulations, or provenance commands whose historical timing/state matters.

Potentially derivable read-only:

- a final report assembled from complete retained records;
- aggregate hashes from retained indexed files;
- per-path identities from a retained final manifest;
- node arithmetic from retained opening/final lists.

Not derivable read-only:

- missing JUnit;
- an unrecorded pytest result;
- an unrecorded mutant outcome;
- an unrecorded A/B/C state result;
- an unrecorded run-local pre/post fingerprint;
- an unrecorded complete-suite attempt;
- an unrecorded final recipe run.

Do not invent absent evidence.

REQUIRED PRIMARY DISPOSITION

Return exactly one token.

### EVIDENCE_ONLY_CLOSEOUT_REGENERATION_READY

Use only when:

- live candidate bytes are stable and bindable;
- all correctness and validation records already exist;
- missing items are only aggregate reports, indexes, or read-only derivations;
- no pytest, mutation, A/B/C, suite, or provenance rerun is required.

### VALIDATION_EVIDENCE_RERUN_REQUIRED

Use when:

- live candidate bytes are stable;
- repository implementation need not change;
- one or more mandatory validation records are missing and cannot be derived
  read-only.

Specify the minimum exact reruns separately:

```text
selected causal
focused groups
A/B/C target matrix
node collection
live full suite
clean full suite
provenance
```

Do not authorize reruns in this diagnostic.

### IMPLEMENTATION_RERUN_REQUIRED

Use only when:

- the repository repair itself was not completed;
- current bytes do not contain the claimed closed call surface or protected
  content causal assertions;
- or test/source edits must be repeated.

List the exact incomplete finding and path.

### LIVE_CANDIDATE_BYTES_DRIFTED

Use when current repository bytes changed after the success token.

### REPORT_PROVENANCE_MISMATCH

Use when opening repository identity or retained opening/audit evidence differs
from the expected baseline.

### EVIDENCE_LOSS_UNRECOVERABLE

Use only when both:
- mandatory evidence is unavailable; and
- the exact final byte target cannot be recovered safely.

REQUIRED QUESTIONS

Answer explicitly:

1. What exact mandatory item first caused `REPORT_EVIDENCE_INCOMPLETE`?

2. What other mandatory items are missing?

3. Did the repair create a new evidence root?

4. Do current repository bytes contain the claimed closed call-surface repair?

5. Do current bytes contain causal protected-content checks?

6. Does a retained final canonical manifest exist?

7. Does a retained final node list exist?

8. Do retained A/B/C records exist?

9. Does retained live full-suite JUnit exist?

10. Does retained clean full-suite JUnit exist?

11. Do indexed run-local pre/post fingerprints exist for both suites?

12. Does a retained final self-excluding index exist?

13. Can a complete closeout be generated without rerunning pytest or mutation
    probes?

14. Does the next action belong in:
    - the same implementation conversation as evidence-only closeout;
    - the same implementation conversation with validation reruns;
    - or a new implementation pass?

FINAL RESPONSE

Include:

1. primary disposition token;
2. exact first missing item;
3. complete evidence matrix;
4. live-byte status;
5. minimum continuation boundary;
6. exact next success token to require;
7. separate provenance, validation-binding, and implementation confidence.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
NODE_COLLECTION_NOT_RUN
MUTATION_PROBES_NOT_RUN
THREE_STATE_SIMULATION_NOT_RUN
CORRECTNESS_AUDIT_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
```
