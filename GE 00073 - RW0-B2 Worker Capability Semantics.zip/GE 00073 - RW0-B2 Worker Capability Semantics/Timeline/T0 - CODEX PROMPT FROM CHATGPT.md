TITLE

Coordinator RW0-B2 — read-only protocol, worker-result, and Codex-capability
freeze reconnaissance

ENGAGEMENT TYPE

Read-only design reconnaissance against the current merged Coordinator
baseline.

This is not an implementation prompt. Do not edit, create, delete, format,
chmod, stage, commit, push, create or modify a PR, merge, tag, release, deploy,
install dependencies, execute migrations, run tests, invoke Codex/model/provider
runtime behavior, contact a worker/host/service/network, or modify any supporting
repository.

Use one foreground Codex parent conversation with exactly four bounded
read-only explorer agents. No nested agents. The parent must wait for all four,
preserve disagreements, inspect material claims directly, close every agent,
verify the baseline remains unchanged, and return one reconciled design packet.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED LIVE BASELINE

Verify before exploration and at closeout:

- branch:
  trunk_dev
- HEAD:
  02450d3c99faf0fe7b299b914afaed312421bc8b
- tree:
  0b5394c591bd277d56797794f71af954ccb93846
- sole parent:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- subject:
  feat: implement RW0-B1 pure phase-entry semantics (#3)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- worktree/index/untracked/unmerged:
  clean
- no Git operation or lock
- no repository-local cache, bytecode, database, journal, build, archive, or
  generated-manifest residue.

Do not fetch or contact a remote. The expected Git identity above is a
Codex-reported post-merge overlay; live local Git must verify it.

Stop on baseline mismatch. Do not absorb unrelated work, switch branches, or
repair the repository.

WORKSTREAM

RW0-B2 — private pure protocol and capability contracts after merged RW0-B1.

CURRENT REPOSITORY REALITY

Treat the repository as authoritative for current behavior:

1. RW0-A is an accepted target contract, not an implemented runtime.
2. RW0-B1 is implemented and merged:
   - eight private immutable no-I/O value families;
   - pure relations over supplied C2A, C2B3D, Section 41, head, decision, and
     global-stop facts;
   - no source authentication, permission issuance, persistence, custody,
     transport, process, worker, model, latch, ES route, Git effect, service,
     scheduler, queue, or autonomous loop.
3. C2A/C2A1 owns the existing private semantic identities and relations:
   `WorkSpecV1`, `AttemptFenceV1`, `EffectFenceV1`, `WorkerCommandV1`,
   `DeliveryEnvelopeV1`, `WorkerObservationV1`, `CapsuleEntryV1`,
   `CandidateCapsuleManifestV1`, `CeilingsV1`, their canonical identities, and
   their six owning coherence relations.
4. C2A explicitly does not implement raw JSON decoding, full-record wire
   encoding, process framing, transport wrapping, executable mechanism,
   terminal receipt, worker/process runtime, or Codex invocation.
5. C2B3D planned author delivery and Section 41 selection remain the complete
   durable/executable implemented boundary relevant to RW0.
6. RW0-C owns future guarded durable state, evidence completeness, terminal fact,
   recovery, and latch representation.
7. RW0-D owns future physical custody, bearer handling, process/supervisor/worker
   mechanics, capsule proof, and offline executable proof.
8. RW0-E owns future live qualified-host proof.
9. ES retains ES-route admission, reliable submit, runtime identity, lifecycle,
   cancellation, and retained-result authority.
10. No public package export or production consumer exists for B1.

STRATEGIC TARGET FOR THIS RECONNAISSANCE

Freeze the smallest exact implementation-ready RW0-B2 design that can later add
private deterministic no-I/O source and tests for:

A. a hostile-input byte framing/codec boundary carrying existing C2A semantic
   records without creating competing semantic identities;

B. a bounded worker-authored result-frame grammar that remains evidence and is
   distinct from:
   - supervisor/OS process facts;
   - C2A delivery acknowledgement;
   - `WorkerObservationV1` ownership rules;
   - B1 `RW0TerminalOutcomeV1`;
   - C2B development decisions;
   - RW0-C durable terminal facts or acceptance-latch behavior;

C. a mechanism-neutral Codex capability declaration / independent observation /
   pure qualification contract sufficient to gate a later offline proof.

ENGINEERING DIRECTION — DO NOT REOPEN

1. Do not select Codex CLI versus App Server in B2. That physical mechanism
   choice remains an RW0-D/RW0-E decision. B2 may freeze only
   mechanism-neutral, versioned, safe capability claims, observations, and pure
   qualification.

2. Do not carry raw WorkSpec or selected-plan bytes in a frame. Physical bytes
   and retrieval authority remain out-of-band custody concerns. Frames may bind
   only existing safe semantic refs/digests and records.

3. Do not carry raw candidate bytes, prompts, transcripts, Codex JSONL,
   stdout/stderr bodies, provider/account metadata, credentials, hostnames, IPs,
   endpoints, absolute paths, environment values, trust material, or bearers.

4. Protocol stdout may later contain exactly the selected frame grammar.
   Stderr remains private process diagnostic material. B2 may define a required
   bounded capability or protocol ceiling but does not capture, redact, persist,
   or transport stderr.

5. A frame digest, canonical bytes, declaration, observation, or qualification
   never authenticates a source or grants executable authority.

6. Preserve every current C2A/B1 class, field, schema ID, digest domain, enum,
   vector, canonical byte, and relation byte-for-byte.

7. Do not use the labels `B2a`, `B2b`, or `B2c` for new RW0 subtranches; those
   labels already identify older writer/lock/session work in this repository.
   If a split is required, use unambiguous names such as:
   - `RW0-B2-Wire`
   - `RW0-B2-Capability`
   or recommend better non-colliding names.

8. Preferred dependency direction, subject to source-grounded confirmation:
   - wire/result layer imports existing private C2A values and only the minimum
     B1 identities actually required;
   - capability layer may depend on the wire/result protocol identity;
   - neither is imported by the package root or an existing production caller;
   - no circular dependency and no generic shared helper without demonstrated
     need.

9. Prefer two independently auditable B2 implementation tranches—wire/result
   first, capability second—unless repository evidence proves that one smaller
   combined tranche has clearer ownership and lower audit risk.

OBJECTIVE

Produce one reconciled RW0-B2 freeze-acceptance packet.

Do not implement.

Return `RW0_B2_RECONNAISSANCE_READY` only if every field, identity, relation,
bound, error, module, touched file, validation command, and stop condition
needed for the first B2 implementation tranche is exact and source-grounded.

Return `RW0_B2_RECONNAISSANCE_PARTIAL` when the ownership split is clear but an
exact schema, cap, precedence rule, or module boundary remains proposed rather
than frozen.

Return `RW0_B2_RECONNAISSANCE_BLOCKED` only for a concrete owning-contract
contradiction.

Do not treat breadth, test quantity, or plausible protocol choices as proof of
readiness.

MANDATORY SOURCE INSPECTION

At minimum inspect together:

Repository guidance and current status:

- `AGENTS.md`
- `README.md`
- `.docs/architecture.md`
- `.docs/authority-boundaries.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/durable-state-model.md`
- `.docs/software-development-progression-boundary.md`
- `.docs/worker-execution-boundary.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/rw0-b1-pure-phase-values.md`

C2A and B1 semantic owners:

- `.docs/c2a-first-slice-semantic-protocol-contract.md`
- `.docs/c2a1-pure-semantic-values.md`
- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `tests/c2a_contract_support.py`
- all `tests/test_worker_execution_semantic_*`
- `tests/test_c2a_relations.py`
- `tests/test_c2a_first_slice_semantic_protocol_contract.py`
- all `tests/test_rw0_b1_*`

Static/public/import boundaries:

- `src/ge_nwp_coordinator/__init__.py`
- `pyproject.toml`
- `tests/test_c2a_nonimplementation.py`
- `tests/test_runtime_non_authority.py`
- `tests/test_c2b2_development_row_value_boundaries.py`
- `tests/test_codex_agent_config.py`

Inspect other files only when a concrete import, owner, status assertion, or
test inventory requires them. Report where inspection stopped.

SUBAGENT WORKFLOW

Start exactly four read-only explorer agents in parallel. Because explorer
agents may not inherit full conversation context, give each a self-contained
context capsule containing the repository, exact expected baseline, current
contract, strategic target, reopened seams, compatibility obligations,
non-goals, no-mutation rule, and required report envelope.

No nested delegation. At most one retry if an agent fails to start. Subagents
must not run tests, invoke live commands, contact networks, or create files.

EXPLORER 1 — CONTRACT, AUTHORITY, AND NON-COLLAPSE

Determine:

- exact current versus target ownership for command frame, delivery identity,
  worker result, process exit/deadline/signal/cancellation, observations,
  terminal outcome, and Codex capability;
- whether a command frame must carry:
  - `WorkerCommandV1` only;
  - `WorkerCommandV1` plus `DeliveryEnvelopeV1`;
  - or another exact composition of existing records;
- which author owns each frame and each nested record;
- how result-frame evidence maps to existing `WorkerObservationV1` without
  widening source/observation enums;
- which process facts must remain supervisor/OS-owned and outside worker output;
- exact distinction among:
  - worker result;
  - process outcome;
  - delivery outcome;
  - Coordinator B1 terminal outcome;
  - future RW0-C durable terminal fact;
- authority/privacy implications of framing safe records;
- exact B2 versus D/E split for Codex capability and CLI/App Server;
- current documentation contradictions that implementation would need to
  normalize.

Attempt to falsify any design that turns bytes, digests, declarations, worker
output, exit zero, transport acknowledgement, or qualification into permission
or semantic acceptance.

EXPLORER 2 — WIRE GRAMMAR, CANONICALIZATION, AND BOUNDS

Derive an exact hostile-input codec proposal from current source.

Required analysis:

1. Compute the exact maximum canonical full-record JSON size for every existing
   record proposed for framing, using current scalar/list/cardinality bounds.
   Do not estimate from typical fixtures.

2. Determine the minimum exact frame kinds and payload compositions.

3. Freeze or reject a candidate header by proving:
   - magic bytes;
   - version;
   - frame kind;
   - length field width and byte order;
   - exact header length;
   - payload length cap per kind;
   - exactly-one-frame and EOF/trailing-byte rules;
   - unknown version/kind behavior.

4. Freeze exact JSON behavior:
   - strict UTF-8;
   - duplicate-key rejection before mapping construction;
   - exact object/list/scalar types;
   - unknown/missing keys;
   - canonical compact encoding;
   - sorted object keys or another exact order;
   - `ensure_ascii` behavior;
   - Unicode normalization posture;
   - integer grammar;
   - re-encode-byte-for-byte requirement;
   - no NaN/Infinity;
   - no BOM;
   - no extra whitespace or alternate number spellings.

5. Determine whether frame bytes receive:
   - no digest;
   - a transport-only digest;
   - or another safe correlation;
   while preserving C2A semantic identity as authoritative.

6. Derive exact payload caps with a mechanical largest-valid proof and explicit
   headroom rationale. Do not freeze the earlier 64 KiB / 256 KiB suggestions
   merely because they are plausible.

7. Freeze deterministic decoder precedence for:
   - resource/cap overflow;
   - short header;
   - unknown version/kind;
   - declared length too large;
   - truncation;
   - trailing bytes;
   - UTF-8 failure;
   - duplicate keys;
   - JSON syntax;
   - noncanonical encoding;
   - schema/type/enum/digest failure;
   - cross-record relation mismatch.

8. Define cumulative work/depth/cardinality budgets, cycle/shared-DAG treatment,
   and maximum/one-over vectors.

Return exact bytes diagrams and formulas, not only prose.

EXPLORER 3 — WORKER RESULT AND CODEX CAPABILITY CONTRACTS

Freeze or identify the unresolved exact schemas for:

A. Worker-authored result frame/value

Determine:

- exact class/schema name;
- ordered fields;
- digest domain;
- author/source;
- required command, delivery, invocation, attempt, effect, fence, and candidate
  bindings;
- whether it contains one or more existing `WorkerObservationV1` mappings;
- exact allowed observation kinds and source kind;
- exact count/order/uniqueness rules;
- completion/failure/cancellation/malformed/unknown outcome grammar;
- whether an absent or malformed frame is merely source evidence failure;
- why process exit code, deadline, signal, stderr, transport acknowledgement,
  and supervisor reconciliation do or do not belong in the worker frame;
- relation to `candidate_captured`, `worker_started`, and `worker_completed`;
- exact non-collapse with B1/RW0-C terminal facts and decisions.

B. Codex capability contract

Determine whether B2 needs three separate private values:

- declaration by candidate implementation/artifact owner;
- observation by an independent source;
- Coordinator pure qualification;

or a smaller exact decomposition.

Freeze exact safe fields for:

- protocol/profile/version identities;
- implementation/artifact identities;
- declared versus observed noninteractive input behavior;
- bounded protocol output;
- cancellation and deadline behavior;
- ephemeral state/history posture;
- credential isolation;
- transcript/JSONL suppression or privacy;
- zero Git effects;
- network posture;
- required worker/frame protocol support;
- observation time/expiry;
- finite qualification result and reason precedence.

Do not select CLI or App Server. Do not include provider endpoint, account,
credential, session, prompt, transcript, JSONL, raw output, host address, or
physical path.

Determine what can be proven by pure relation versus what remains an external
claim for D/E.

EXPLORER 4 — MODULE, TEST, STATUS, AND VALIDATION MAP

Map the smallest implementation surface for each recommended B2 tranche.

Required output:

- one-module versus two-module decision with exact import direction;
- exact proposed private source paths;
- exact governing-document paths;
- exact direct test files;
- exact existing inventory/public-boundary tests requiring edits;
- exact current-status documents and structural tests requiring bounded updates;
- exact protected files and byte-identical surfaces;
- no-I/O AST/import rules;
- package/public-export stability;
- dependency and pyproject stability;
- node collection strategy;
- exact focused test commands;
- complete-suite policy;
- artifact isolation and cleanup;
- provenance and fresh-audit plan;
- maximum touched-file allowlist and stop conditions.

Inspect whether names like `_rw0_wire_protocol_values.py`,
`_rw0_codex_capability_values.py`, and proposed docs/tests collide with
historical tranche naming or static source inventories. Names are not accepted
merely because they appeared in earlier discussion.

MANDATORY RECONCILIATION QUESTIONS

The parent must answer all of these.

1. Tranche decomposition

- Is the first implementation tranche wire/result only?
- Does capability freeze follow as a second B2 tranche?
- What exact dependency requires that order?
- Why would a single combined tranche be safer or less safe?

2. Frame ownership and composition

- Is there one command frame and one worker-result frame?
- Does the command frame carry both command and delivery records?
- Does any B1 identity belong in the frame, or should B1 remain a pre-launch
  gate only?
- Which nested record owns semantic identity?
- Does the frame itself have any identity or only transport bytes?

3. Worker-result semantics

- What exact source writes it?
- Which existing C2A observation types can it carry?
- How are worker-authored facts separated from supervisor/OS facts?
- How are malformed, missing, duplicate, contradictory, or late results
  classified?
- What result can never be inferred from exit code or EOF?

4. Codex capability semantics

- What exact contract can B2 freeze without choosing CLI/App Server?
- What remains external evidence?
- What blocks D versus E?
- Does “B2 owns Codex mechanism” in the B1 document need correction to
  “B2 owns the mechanism-neutral capability contract”?

5. Canonical encoding and bounds

- Exact header and payload grammar.
- Exact cap formulas and largest-valid proof.
- Exact duplicate-key and noncanonical-byte behavior.
- Exact decoder precedence.
- Exact work budgets.

6. Current compatibility

- Preserve C2A schema IDs, domains, vectors, enums, path set, and relations.
- Preserve B1 values/relations and no-production-consumer posture unless a
  separately justified B2 consumer relation is needed.
- Preserve `control-plane-normal-shell/v1` only as a compatibility edge; it
  should not shape B2 private direct-local framing.
- Preserve direct-local versus ES semantic conformance while allowing
  route-owned wrappers/correlations to differ.

7. Privacy and security

- No raw WorkSpec/plan/candidate/capsule bytes in Coordinator-safe values.
- No bearer, credential, host, endpoint, path, prompt, transcript, JSONL,
  stdout/stderr body, or provider metadata.
- Content-free errors and suppressed foreign exception chains.
- No parser bombs, unbounded integer conversion, recursive expansion, or
  shared-DAG free work.
- No I/O or ambient environment/clock access.

8. Later consumption

State exactly what B2-Wire and B2-Capability would make available to:

- RW0-C durable schema and ingest;
- RW0-D supervisor/worker/custodian proof;
- RW0-E live-host proof;
- later ES conformance;

without reporting those later capabilities as current.

REQUIRED FINAL PACKET

If ready, produce an implementation-ready packet containing:

1. exact baseline and inspection boundary;
2. current contract, strategic target, and reopened seams;
3. adopted tranche decomposition and rejected alternatives;
4. exact class inventory:
   - class names;
   - schema IDs;
   - ordered fields;
   - exact built-in external types;
   - stored types;
   - enums;
   - nullable-pair rules;
   - scalar/cardinality bounds;
   - authors and consumers;
5. exact digest/canonicalization domains;
6. exact frame byte layout and payload grammar;
7. exact maximum-size calculations and cap proofs;
8. exact worker-result relation and process/supervisor non-collapse;
9. exact Codex declaration/observation/qualification relations and freshness;
10. exact finite content-free error algebra and deterministic precedence;
11. exact cumulative work/depth/cardinality budgets;
12. exact module/import ownership;
13. exact maximum touched-file allowlist for the first implementation tranche;
14. exact protected surfaces;
15. exact test-node expectations without inventing a count;
16. exact future validation commands and artifact isolation;
17. exact provenance and independent-audit requirements;
18. exact stop conditions;
19. source-grounded path:line claim ledger;
20. unresolved later seams and inspection limits.

If any field, cap, precedence relation, or class remains only a recommendation,
return PARTIAL and name the smallest additional owning-contract decision needed.
Do not disguise a candidate as a freeze.

COMMAND POSTURE

Authorized read-only commands include:

- `git rev-parse`, `git branch --show-current`, `git status`,
  `git diff --check`, `git ls-files`, `git show`, `git log`;
- `find`, `rg`, `grep`, `sed`, `awk`, `cat`, `head`, `tail`, `wc`, `stat`;
- read-only Python AST or deterministic size-analysis snippets that create no
  file and import no project module with side effects.

Not authorized:

- tests or collection;
- `git fetch`, pull, switch, checkout, reset, clean, add, commit, push;
- file creation or modification, including temporary repository files;
- package installation;
- migration or database creation;
- subprocess invocation of Codex or model tools;
- network, service, connector, Bridge, ES, IM, remote-host, or provider contact.

STANDARD SUBAGENT REPORT

Each explorer must return:

```text
SUBAGENT REPORT

Role:
Assigned scope:
Baseline observed:
Files and documents inspected:

Claim ledger:
- ID:
  Type: evidence | inference | uncertainty
  Claim:
  Source: repo-relative-path:line
  Implication:
  Required docs/source/tests impact:
  Confidence:

Current contracts/invariants:
Strategic target and reopened seams:
Recommended exact decisions:
Rejected alternatives:
Likely touched surfaces:
Validation and provenance:
Risks and unresolved uncertainty:
Scope not inspected:
Mutation performed: no
Commands with side effects performed: no
Nested subagents created: no
```

PARENT CLOSEOUT

The parent must:

- wait for all four explorers;
- identify failed or retried agents;
- preserve disagreements;
- independently inspect every load-bearing claim;
- distinguish current repository fact, Codex-reported merged overlay, strategic
  target, and inference;
- state where inspection stopped;
- close all agents;
- verify HEAD and status remain unchanged;
- perform no mutation.

Return exactly one verdict:

- `RW0_B2_RECONNAISSANCE_READY`
- `RW0_B2_RECONNAISSANCE_PARTIAL`
- `RW0_B2_RECONNAISSANCE_BLOCKED`
- `SUBAGENT_UNAVAILABLE`

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
