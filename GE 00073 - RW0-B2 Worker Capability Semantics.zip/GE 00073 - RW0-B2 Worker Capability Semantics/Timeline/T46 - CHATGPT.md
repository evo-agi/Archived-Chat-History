## Engineering disposition

**Proceed to a fresh independent read-only re-audit. Do not stage or commit.**

The fifth repair report is a credible implementation closeout:

- exactly one untracked test file changed;
- production source and governing documentation remained byte-identical;
- all **4,655** test-node identities and their order were preserved;
- the strengthened matrix, focused groups, and complete suite passed;
- final provenance reproduced twice over the same 16-path candidate;
- the tracked-diff digest appropriately remained unchanged because the repaired file is untracked.

Nothing here reopens the accepted Wire-before-Capability decomposition or authorizes Capability work. Wire remains the prerequisite profile that Capability will later reference, while concrete invocation mechanics remain outside this tranche. 

The fresh audit now has a very narrow burden: determine whether the repaired test is genuinely mutation-sensitive rather than merely internally consistent.

### Critical re-audit questions

1. **Independent 64-path inventory**

   The auditor must derive the reachable integer paths directly from the committed C2A classes—not from the repaired test or Wire extractor—and independently reproduce:

   ```text
   CeilingsV1           15
   AttemptFenceV1       16
   EffectFenceV1        16
   WorkerCommandV1      16
   DeliveryEnvelopeV1    0
   WorkerObservationV1   1
   total                 64
   ```

2. **Positive coverage is behavioral**

   For every inventory row, the audit must establish that the declared valid value:

   - enters a coherent graph;
   - reaches the intended class and field;
   - crosses the recorded public Wire boundary;
   - succeeds under the owning C2A and Wire relations.

   Merely adding a row key to a coverage set is insufficient.

3. **Field-specific legal-MAX regressions are detected**

   The audit should independently inject a regression rejecting:

   ```text
   CeilingsV1.max_active_invocations == 9_223_372_036_854_775_807
   ```

   and require the strengthened test to fail. It should repeat representative legal-MAX regressions for AttemptFence, EffectFence, and WorkerCommand paths.

4. **The selective bypass is exactly one operation**

   The test must prove:

   ```text
   selected_bypass_count == 1
   remaining authoritative Attempt checks == 15
   selected Attempt-specific owner spy == 1
   ```

   A class-wide Attempt bypass must fail the repaired assertions. An unrelated Effect case must remain early-rejected with no selected Attempt bypass.

5. **No collateral weakening**

   The fresh auditor must confirm that:

   - all earlier F1–F16 tests remain active;
   - no node, decorator, parameterization, skip, xfail, or warning posture changed;
   - production, documentation, profile identities, authority boundaries, and public surfaces are exact;
   - the single changed file is the only fourth-to-fifth-repair delta.

The implementation and audit engagements must remain separate: the write-enabled parent repairs findings, while a later fresh conversation independently audits the new exact bytes.  Exact provenance is necessary but does not establish test sufficiency or implementation correctness. 

## Fresh re-audit prompt

Start a **new read-only Codex conversation** and send this complete prompt:

:chatgpt-content-reference{index="3"}

Verify the attachment:

```text
Filename:
Coordinator_RW0_B2_Wire_Fifth_Audit_Test_Repair_Fresh_Reaudit_Prompt.txt

Size:
28,828 bytes

SHA-256:
6b751edbe94d7818e49199188f275ce15864046f4aa84134d14dd34c3220ed53
```

The prompt binds the audit to:

```text
Repair report:
/private/tmp/rw0-b2-wire-fifth-repair.zMko0e/final_provenance.json

Repair-report SHA-256:
6eefc4c3891529f72758e10ba2b0515fea79a9ff2207bd0bdd6e43048a9349fc

Canonical-manifest SHA-256:
27a65b60710f337d5610d8a8fb6f039d6b0a13ba4045d5e7587a7db37f1a2b77

Complete-output SHA-256:
2f172d7c92a91c8118dfbdf6b750cb332371201f03f5b66e3d5c990358121344

Tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6
```

It requires exact node comparison:

```text
candidate:       4,655
HEAD:            4,566
candidate-only:     89
HEAD-only:            0
```

with ownership:

```text
Wire values:       11
Wire codec:        16
Wire relations:    49
Wire boundaries:   13
```

The only successful outcome is:

```text
ACCEPT
COORDINATOR_RW0_B2_WIRE_FIFTH_AUDIT_TEST_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Only after that `ACCEPT` should the authoritative manifest be regenerated, exactly the audited 16 paths staged, staged blobs compared with the manifest, validation rerun without edits, and one commit created. 

### Sources

- Codex fifth-audit test-repair report supplied in this turn.
- Accepted Wire-before-Capability ordering and ownership split. 
- Earlier forecast identifying noncausal mutants as a principal audit risk. 
- Independent-audit and repair separation. 
- Provenance limits and audited-byte commit lifecycle.  

**Confidence:** High that the candidate is ready for fresh re-audit; deliberately insufficient for commit authorization until the positive 64-path matrix and one-operation selective bypass are independently demonstrated to be complete and non-self-confirming.
