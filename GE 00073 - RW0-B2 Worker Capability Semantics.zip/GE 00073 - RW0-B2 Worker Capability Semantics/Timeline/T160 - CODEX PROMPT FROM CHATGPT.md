PROMPT_ID

RW0_B2_CAPABILITY_G11_FINDINGS_REPAIR_V1

TITLE

Coordinator RW0-B2-Capability — replace the incomplete binding proof with a
fail-closed protected-surface preflight, seal immutable source/code
observations, make target execution depend on the preflight, and reseal complete
attempt evidence

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing Capability implementation
conversation.

Do not create subagents. The parent is the sole repository writer.

This is a one-repository-file test-boundary repair plus fresh external
validation evidence. It is not production implementation, governing-document
editing, registry redesign, staging, commit, push, pull request, merge,
release, deployment, provider/runtime work, database work, or
supporting-repository work.

Only the exact repository path below may change.

CRITICAL INLINE RESPONSE RULE

The complete substantive final report must be printed inline in the Codex chat.

Do not respond only with:

- a token;
- a short summary plus `/private/tmp` paths;
- “see report”;
- links that contain the operative findings or validation results.

Evidence paths may be listed only as supplementary provenance after all
decision-relevant facts, exact values, attempt history, validation results, and
continuation boundaries have appeared inline.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Repair all material findings from the G11 fresh independent audit:

```text
G11-CC-001 — High
The source-order binding walker omits applicable Python constructs. Match
capture, while-body rebinding, except*, type-alias rebinding, and class
decorator/base walrus rebinding can install an executable replacement while
the static guard, runtime seal, and target stay green.

G11-CC-002 — High
The runtime seal compares aliases of the same mutable function object. Replacing
a protected helper's __code__ leaves object/code identity comparisons green and
executes replacement code.

G11-EV-003 — High
The executable-sentinel evidence selected the guard separately from the target.
A guard failure did not prevent the later target from invoking the rebound
helper and creating the sentinel.

G11-RP-004 — Medium
The binding ledger is sorted rather than preserving evaluation/source order and
mixes comprehension-local bindings into enclosing scopes.

G11-MO-005 — Medium
One formal recorder invocation was rejected before sequence allocation and lacks
the complete argv/timing/process/output/fingerprint envelope required by the
all-formal-attempt contract.

G11-RP-006 — Low
The final report said "20-path" although the enforced candidate inventory is
30 paths plus P01–P13 protected rows.
```

Preserve every G11-accepted result:

- production Capability semantics remain private and pure;
- no production or governing-document authority defect exists;
- the 42-row callsite ledger is correct within its previous bounded graph;
- the independent module-global diagnostic oracle is non-circular;
- the 43-row R01–R30/P01–P13 projection is correct;
- all eight stable-contract mutants are valid after the final P12 fixture;
- A/B/C behavior, node reconciliation, and retained broad validation are sound;
- G8, G9, G10, and G11 remain immutable historical evidence.

Do not edit or reseal G10 or G11.

OPENING REPOSITORY IDENTITY

Before any repository edit require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644

candidate tree:
84cb309f477fec7a28bccf5c671d4bb68393801c
```

Require:

- `git diff --check` clean;
- logical cached diff empty;
- no Git operation or lock;
- source logical index unstaged;
- no candidate symlink or special file;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, or recorder residue;
- no thirty-first changed path.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

OPENING CANDIDATE TARGET

G10 authoritative evidence root:

```text
/private/tmp/g10.ALOFU2
```

G10 final report:

```text
/private/tmp/g10.ALOFU2/final_report.md

size:
27946 bytes

SHA-256:
aae2f3a19906f570ac2c49514623d41d54c7bd20971057863d958c145323bba3
```

G10 attempt manifest:

```text
/private/tmp/g10.ALOFU2/attempt_manifest.jsonl

rows:
86

size:
36151 bytes

SHA-256:
fd456c2532ec9e62da0f6cfdadd0a26976c2677463594139fa7a014276f800cc
```

G10 self-excluding index:

```text
/private/tmp/g10.ALOFU2/evidence_index.jsonl

rows excluding itself:
630

size:
90708 bytes

SHA-256:
2f6976e2197a251a5de08ac8a00f02b8d516b0fc1e0e6a89c548e8ed4d5e08b1
```

Opening final candidate identities:

```text
canonical-manifest size:
6431 bytes

canonical-manifest SHA-256:
615f93b6eca41019bfb617ec9c6dbc1ebaca6fad4e13ad9bba5c52d5b165ce04

tracked textual-diff SHA-256:
recover exact value from indexed G10 evidence

complete recipe-output size:
6664 bytes

complete recipe-output SHA-256:
e1e1be6ee67789c96fa3f6d41e8a9526c3607ce4e8872abef3557fa9f896faeb

candidate tree:
84cb309f477fec7a28bccf5c671d4bb68393801c

opening node count:
5095

opening ordered-node-list SHA-256:
f6e7929241c6adb60df081ee9e59bff050e49869f90fc54e1d1072cf9362993d
```

Opening identity of the only authorized repository path:

```text
tests/test_rw0_b2_capability_boundaries.py

kind:
untracked

type:
regular

mode:
0644

size:
130356 bytes

SHA-256:
cece5a7009a3b70ae2b7b065b7ae451c681801cd46dfa28c96bbee5279ba0490
```

The other 29 candidate entries must remain exact.

LATEST INDEPENDENT AUDIT

G11 root:

```text
/private/tmp/g11.66vv1X
```

G11 self-excluding evidence index:

```text
/private/tmp/g11.66vv1X/evidence_index.jsonl

rows excluding itself:
203

size:
26876 bytes

SHA-256:
551e3a149dc07cc06f6bc3f6d5e1d7dc878b3699ebe9cf756adddaede7396205
```

Read and preserve the complete inline/file evidence for:

```text
G11-CC-001
G11-CC-002
G11-EV-003
G11-RP-004
G11-MO-005
G11-RP-006
```

Required reproduced identities and facts include:

```text
match-capture executable bypass patch/source and sentinel result
code-object mutation probe and replacement execution
exact-G9 combined guard/target reproduction and sentinel result
119-row module ledger
35-row lexical ledger
42-row callsite ledger
literal AST digests
unallocated-recorder incident record
```

EXACT REPOSITORY ALLOWLIST

Only this already-dirty path may change:

```text
tests/test_rw0_b2_capability_boundaries.py
```

No document or production source may change.

Final topology must remain:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
all regular mode 0644
```

Stop if a second repository path, documentation change, production-source
change, or thirty-first dirty path is required.

ENGINEERING RESET

Do not keep extending an order-insensitive "binding events found" denylist.

The repaired permanent boundary test must be fail-closed through four
independent layers:

```text
1. target-attached preflight that pytest executes before target entry;
2. exhaustive, scope-accurate protected-source model with unsupported syntax
   rejected;
3. independent literal source/AST/code observations for every protected
   callable and required external callable;
4. ordered callsite/provenance ledger and independent literal mutation oracles.
```

No one layer may be the sole authority.

NEW EVIDENCE ROOT

Create one new short neutral root:

```text
/private/tmp/g12.XXXXXX
```

Requirements:

- operator-owned;
- non-symlink;
- mode `0700`;
- all temporary paths beneath this root;
- every pytest-visible path pre-screened with the exact owning path-safety
  grammar;
- retained regular files mode `0400`;
- retained directories mode `0700`;
- no symlink, FIFO, socket, device, or other special entry at closeout;
- self-excluding canonical JSONL index created last.

Preserve G10 and G11 unchanged. Record opening/closing canonical content
projections for both.

EXACT RECIPE SOURCE

Locate the retained exact source:

```text
/private/tmp/g5.hiLE2y/exact_recipe_source.py

type:
regular

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Create a verified G12-local mode-0400 copy before invocation. Run the exact
source twice at opening and twice at closeout with only the historical fixed
sink redirected.

BEFORE MUTATION

Record and verify:

1. exact repository identity/topology;
2. exact G10 and G11 indexes;
3. exact opening manifest and all 30 path identities;
4. every path outside the candidate equals HEAD;
5. exact recipe source and two opening reproductions;
6. exact 5,095 opening nodes;
7. complete current source, AST, code observations, binding ledgers, callsite
   ledgers, runtime seal, projection, and mutation helpers from
   `tests/test_rw0_b2_capability_boundaries.py`;
8. exact G11 adverse sources, patches, probe outputs, and sentinel identities.

Retain the complete opening file and an independent AST/source/code projection.

TEST-FIRST RED GATE

Before implementing the final repair, add or stage test-owned causal cases in
the authorized file and run a selected red gate reproducing every material
finding.

Required red cases:

## Binding/scope bypasses

```text
match/case capture rebinding a protected helper
while-body rebinding
while-orelse rebinding
except* target/body rebinding
type-alias rebinding where supported by the running Python grammar
class decorator walrus rebinding
class base-expression walrus rebinding
class keyword-expression walrus rebinding
class-body global rebinding
attribute-store mutation of a protected helper/module/global
subscript-store mutation through globals()/module __dict__
```

## Runtime-seal bypasses

```text
protected helper __code__ replacement
target __code__ replacement where applicable
runtime module-dict rebinding
__wrapped__ injection
callable default
callable kwdefault
callable closure/freevar
functools.partial or callable-object substitution where semantically applicable
```

## Executable gating

Use the exact G9 helper-rebinding executable adversary and the G11 match-capture
executable adversary.

For each, select the permanent target exactly as a user would. The red gate must
show:

```text
opening candidate allows target body entry or sentinel creation
sentinel exists
source/external fixture only; source repository unchanged
```

The exact guard-only reproduction is supplementary; target-only gating is the
authority.

## Ledger-order/scope

Add controls proving the opening ledger:

```text
sorts rather than preserves discovery/evaluation order
sorts parameters by name rather than source order
mixes comprehension-local binding into the enclosing function
includes non-module local events in the module ledger
```

Only intended failures receive causal credit. Syntax/import/path/tooling errors
do not.

REPAIR A — TARGET-ATTACHED FAIL-CLOSED PREFLIGHT

The permanent target:

```text
test_exact_twenty_path_ceiling_modes_and_protected_controls
```

must depend on a pytest preflight fixture or equivalent setup dependency that
runs before target-body entry even when the target node is selected alone.

Requirements:

1. target-only selection executes the preflight first;

2. any source/binding/runtime/callsite/global diagnostic prevents target entry;

3. sentinel-producing adversaries selecting only the target leave the sentinel
   absent;

4. a combined guard-plus-target selection also leaves the sentinel absent;

5. the target's source/signature explicitly and causally requires the preflight;

6. removing or bypassing the preflight dependency is itself a literal causal
   mutant that fails;

7. if the preflight fixture is unavailable or rebound, pytest setup must fail
   before target entry rather than silently continuing.

Do not rely on test order or pytest fail-fast.

REPAIR B — FAIL-CLOSED PROTECTED-SOURCE GRAMMAR

Implement one scope-aware source model for the protected surface.

Protected surface must include, at minimum:

```text
the target
the target-attached preflight fixture/setup callable
the diagnostics/verification callable used by the fixture
_stable_capability_boundary_projection
_protected_content_row
all literal ledger/oracle helpers that can affect those callables
```

The source model must preserve discovery/evaluation order and explicit scope
identity. Do not sort events by tuple/name as the semantic authority.

Model scopes separately:

```text
module
class
function
lambda
comprehension
generator expression
```

Preserve source parameter order:

```text
positional-only
positional-or-keyword
vararg
keyword-only
kwarg
```

Handle or fail closed on every binding-capable construct relevant to the
running Python grammar:

```text
Import
ImportFrom
FunctionDef
AsyncFunctionDef
ClassDef
Assign
AnnAssign
AugAssign
NamedExpr
Delete
For
AsyncFor
While
With
AsyncWith
ExceptHandler
Try
TryStar
Match and every pattern-capture form
TypeAlias when available
comprehensions
generator expressions
Global
Nonlocal
lambda parameters
function defaults/kwdefaults/annotations
decorators
class decorators/bases/keywords
attribute Store/Del
subscript Store/Del
```

Requirements:

1. every protected function/setup callable has exactly one accepted definition;

2. accepted decorators are explicit and finite; arbitrary decorators fail;

3. no competing/later/conditional binding for a protected name;

4. no builtin or approved-module alias shadowing in any relevant scope;

5. no `global`/`nonlocal` route can mutate protected names;

6. no attribute/subscript mutation can alter protected callables, accepted
   module aliases, ledger literals, or expected observations;

7. every Store/Del or binding node in the protected surface is either modeled
   or causes a finite `unsupported_binding_node:<type>` diagnostic;

8. module, class, function, and comprehension events never collapse into one
   scope;

9. literal expected ledgers preserve the exact event order; counts are derived,
   not predeclared in this prompt.

Use `symtable` only as an independent cross-check if useful; it must not replace
the explicit ordered AST/source model.

REPAIR C — INDEPENDENT IMMUTABLE SOURCE AND CODE SEAL

Fix G11-CC-002.

For every protected Python callable, retain independent literal observations:

```text
normalized source SHA-256
normalized AST SHA-256
canonical code-object projection SHA-256
expected module/name/qualname
expected defaults/kwdefaults/closure/freevars
expected decorator/wrapped posture
```

The expected observations must be literal, test-owned values. They must not be
computed from the current callable under test during expectation construction.

The canonical code-object projection must be independent of mutable function
object identity and include enough immutable fields to detect replacement code,
including recursively applicable code constants. It may normalize
filename/line-position metadata if and only if the normalization is literal,
documented, and mutation-tested.

At runtime, resolve the current callable from its authoritative module binding
and compare:

```text
exact function type
object identity to the captured accepted object
literal source digest
literal AST digest
literal code projection digest
module/name/qualname
defaults
kwdefaults
closure/freevars
__wrapped__
```

Do not compare `actual.__code__ is accepted.__code__` as the substantive code
seal when `actual` and `accepted` may be the same mutable object.

Seal every external callable actually used by the protected graph. At minimum
cover the resolved builtins/modules/descriptors represented by the final
callsite ledger. Verify current authoritative module/class attributes rather
than only captured aliases.

Add causal controls for:

```text
helper __code__ replacement
target __code__ replacement where safely testable
external callable/module-attribute replacement
captured-object replacement
source/AST/code expected-digest mutation
defaults/kwdefaults/closure/wrapped mutation
```

REPAIR D — ORDERED, SCOPE-ACCURATE BINDING LEDGERS

Replace the sorted 119/35 ledgers.

Create literal, independent ledgers whose rows include:

```text
scope ID
scope kind
parent scope ID
event ordinal
source location
event kind
bound target
binding provenance
conditional/evaluation context
```

Requirements:

- preserve explicit traversal/evaluation order;
- preserve parameter source order;
- keep comprehension/generator locals in their own scopes;
- keep class-body locals in class scope unless an explicit `global` changes
  scope;
- distinguish potential conditional bindings from unconditional final module
  bindings;
- exclude unrelated nested-scope events from the module ledger;
- reconstruct the actual ledger independently and compare exactly with the
  literal expected ledger.

Add mutation-sensitive controls for row order, scope ID, parent scope, event
kind, source location, provenance, missing/extra row, and duplicate row.

REPAIR E — ORDERED CALLSITE AND PATH PROVENANCE

Preserve the accepted callsite architecture but regenerate it after the
target-attached preflight and source-model changes.

The literal expected ledger must remain independent and include:

```text
scope/owner
call ordinal
semantic target
multiplicity
receiver provenance
argument provenance
allowed subject/path domain
normalized call-AST digest
```

Fail closed on calls inside:

```text
comprehensions
generator expressions
lambdas
defaults/kwdefaults
decorators
class headers
conditional expressions
```

unless each is explicitly represented in the literal ledger.

Reject path provenance to:

```text
.git
.git/index
Git refs/logs/objects
arbitrary caller-supplied subjects
constructed subjects outside the exact 43-row inventory
```

Add causal mutants for an extra allowlisted call, reordered call, removed call,
receiver alias, argument alias, constructed Git path, star args/kwargs, and
same method with changed provenance.

REPAIR F — INDEPENDENT MODULE-GLOBAL EXPECTATIONS

Preserve the G10 independent oracle for:

```text
ROOT
EXPECTED_PATHS
EXPECTED_PATHS_SHA256
PROTECTED_PATHS
PROTECTED_PATH_IDENTITIES
PROTECTED_ROW_IDS
EXPECTED_BOUNDARY_ROWS
hashlib
stat
```

Extend literal independent expectations to all newly protected setup/fixture,
source/code-digest, binding-ledger, and callsite-ledger globals.

Generic, wrong-key, swapped, missing, duplicate, extra, and one-common-
diagnostic mutants must fail.

REPAIR G — EXECUTABLE SENTINEL PROOF

Run at least these adversaries in isolated external copies:

```text
exact G9 helper-rebinding source
exact G11 match-capture source
one __code__ mutation adversary
```

For each:

1. select the permanent target alone;

2. require preflight/setup failure before target-body entry;

3. require sentinel absent;

4. run combined preflight/guard-plus-target selection and require sentinel
   absent;

5. retain exact source, patch, sentinel path, argv, stdout/stderr, JUnit,
   diagnostics, and pre/post fingerprints.

The target test itself must never call the rebound helper after a preflight
failure.

REPAIR H — ATTEMPT RECORDER PRE-ALLOCATION

Fix G11-MO-005 in the fresh G12 evidence harness.

The outer recorder must allocate:

```text
sequence number
attempt directory
manifest row
minimal envelope
```

before parsing or validating:

```text
fingerprint class
label
purpose
child argv
```

Run a deliberate invalid-fingerprint-class self-test.

Require a complete allocated attempt with:

```text
exact raw argv
label/purpose request
event time
caller PID
parser/preflight return code
stdout/stderr
child launched false
before/after light source fingerprint
external-state applicability
repository-mutated false
```

No formal invocation may exist outside the attempt manifest. Do not use a
separate unallocated incident record as a substitute.

REPAIR I — REPORT ACCURACY

The new report must state:

```text
30 required candidate paths
R01–R30 candidate rows
P01–P13 protected-content rows
```

It may mention the legacy test identifier `test_exact_twenty_path...` only as a
historical name that does not represent the enforced count.

For every attempt report the actual fingerprint class and whether pre/post
fingerprints exist. Do not claim authoritative fingerprints where the recorder
used bootstrap, light, external, or missing/not-applicable classes.

PRESERVE ACCEPTED CONTRACTS

Do not weaken or redesign:

```text
the literal 43-row projection
R01–R30 required candidate rows
P01–P13 protected-content rows
the exact P12 survivor kill
the eight stable-contract mutants
A/B/C state independence
schema-correct restore behavior
production/document/public/authority boundaries
```

TEST-FIRST AND DEVELOPMENT EVIDENCE

The test-first red must precede the final repair.

Retain all development attempts, including failed or superseded attempts, with
complete G12 envelopes.

No syntax/import/path/tooling failure may receive causal credit.

VALIDATION ENVIRONMENT

For every pytest child:

```text
umask 022
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct short neutral external PYTHONPYCACHEPREFIX
distinct short neutral external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct short neutral external --basetemp
distinct short neutral external --junitxml
serial execution
```

Pre-screen every pytest-visible path with the owning path-safety checker.

FINAL VALIDATION ORDER

After final repository bytes and causal ledgers are frozen:

1. selected causal:
   - every G11 source-binding survivor;
   - code-object mutation controls;
   - target-attached preflight controls;
   - target-only and combined executable sentinel controls;
   - ordered scope/binding controls;
   - ordered callsite/provenance controls;
   - runtime callable/external callable seals;
   - independent module-global controls;
   - retained protected-content controls;

2. Capability boundaries:

   ```text
   tests/test_rw0_b2_capability_boundaries.py
   ```

3. Capability complete:

   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   ```

4. B1/Wire compatibility:

   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```

5. architecture/status/static:

   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

6. A/B/C state replay:

   ```text
   A live unstaged
   B fully external independent staged repository
   C same external repository after diagnostic commit
   ```

7. live and clean collection exactly once each;

8. opening/final node reconciliation;

9. final guards;

10. live full suite exactly once;

11. clean full suite exactly once;

12. cleanup;

13. final recipe runs twice;

14. final report and self-excluding index.

Do not predeclare final node count. Derive it.

Every credited run requires:

```text
return code 0
zero failures/errors/skips/xfails/warnings
empty stderr
parseable JUnit
zero duplicate/unmapped cases
matching caller/child umask
unchanged authoritative candidate fingerprint
```

A/B/C REQUIREMENTS

Use a fully external independent Git repository/object database for B/C.

Require:

```text
target passes A/B/C
43-row projection A == B == C
B staged tree == C committed tree
source logical index unchanged
source authoritative object graph unchanged
no alternates
no source/external shared object inode
```

Record the new final B/C tree; do not predeclare it.

LIVE AND CLEAN FULL SUITES

Run each exactly once.

No retry is authorized.

If either fails, preserve evidence and stop without further repository edits.

PROVENANCE CLOSEOUT

After validation and cleanup:

1. require topology `30/24/6/0/0`;

2. prove exactly the sole authorized test path changed from the opening G10
   candidate;

3. prove the other 29 candidate entries remain exact;

4. prove every path outside the candidate equals HEAD;

5. run the exact retained recipe twice with a verified G12-local mode-0400 copy
   and safe sink redirection;

6. require byte-identical final manifests and complete outputs;

7. retain:
   - exact recipe source;
   - final manifests/outputs;
   - exact one-path delta;
   - opening/final node lists;
   - protected-surface source grammar;
   - ordered scope/binding ledgers;
   - independent source/AST/code observations;
   - target-attached preflight contract;
   - ordered callsite ledger;
   - every causal mutant and executable sentinel record;
   - module-global literal oracle;
   - retained 43-row/P01–P13/stable-mutant records;
   - A/B/C records;
   - focused and full-suite records;
   - complete all-attempt manifest;
   - final guards/cleanup;
   - accurate report;

8. verify G10 and G11 unchanged;

9. create a self-excluding evidence index last and externally verify it.

STOP CONDITIONS

Stop without further repository mutation if:

- opening identity/provenance differs;
- a second repository path is required;
- a fail-closed protected-source grammar cannot be finite;
- target-attached preflight cannot prevent target entry;
- independent code/source observations cannot be made literal;
- legitimate stable behavior requires dynamic callable rebinding;
- a production/document/authority defect is discovered;
- A/B/C or suite behavior diverges;
- validation/provenance becomes unstable.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_G11_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only when:

- all G11 binding/scope bypasses are killed;
- code-object replacement is detected;
- target-only and combined executable adversaries cannot create a sentinel;
- source-order/scope ledgers are exact and mutation-sensitive;
- ordered callsite/path provenance is exact;
- module-global expectations are independent;
- every formal recorder invocation receives an allocated envelope;
- the report states the 30-path inventory accurately;
- retained projection/content/stable controls remain green;
- A/B/C is green;
- live and clean complete suites are green;
- exact one-file provenance is stable;
- the complete report is inline and the G12 evidence index is sealed.

FINAL INLINE REPORT

Use these headings:

```text
# Outcome

# Opening and closing identity

# G11 finding closure

# Exact one-file delta

# Target-attached preflight

# Protected-source grammar and binding scopes

# Independent source and code seals

# Ordered callsite and path provenance

# Independent module-global expectations

# Causal executable and mutation results

# Preserved projection and protected-content controls

# A/B/C result

# Node identity

# Focused and complete validation

# Attempt chronology and fingerprint classes

# Provenance and evidence index

# Public, privacy, and authority boundary

# Confidence
```

Report every formal attempt, including invalid recorder invocations, failures,
and superseded attempts.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
