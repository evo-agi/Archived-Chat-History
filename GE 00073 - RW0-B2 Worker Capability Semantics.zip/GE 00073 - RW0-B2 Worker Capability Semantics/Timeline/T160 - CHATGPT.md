## Engineering disposition

**The `BLOCK` is valid. Keep the commit/PR gate closed and perform one more bounded, test-only repair.**

The audit found no defect in Capability production semantics, Wire/B1 integration, documentation, persistence, runtime authority, or public APIs. The remaining defects are confined to:

```text
tests/test_rw0_b2_capability_boundaries.py
```

The other 29 candidate entries must remain byte-identical.

### Why the current repair is still insufficient

The current source-order proof is not merely missing a few edge cases. Its structure remains unsafe in three ways:

1. **Incomplete Python binding semantics.**  
   `match` captures, `while` bodies, `except*`, type aliases, class decorators/bases, and related constructs can replace a protected helper without entering the accepted binding ledger. The audit executed a match-capture replacement: the guard and target both passed and the malicious helper wrote its sentinel.

2. **The runtime seal observes a mutable alias.**  
   The “accepted” and “actual” values point to the same function object. Mutating `__code__` changes both observations simultaneously, so identity checks remain green while replacement code executes.

3. **The guard is not attached to target execution.**  
   A separate guard test can fail while pytest continues into the target test. The retained G10 executable proof therefore did not establish “rejected before target execution.”

Two further evidence issues also require closure:

- binding ledgers must preserve real traversal order and scope rather than sorting events and mixing comprehension locals into enclosing scopes;
- the fresh recorder must allocate an attempt envelope **before** validating its requested fingerprint class, so no formal invocation can exist outside the attempt manifest.

## Repair direction

The next repair should not add another layer of isolated forbidden-pattern checks. It should establish four independent controls:

### Target-attached preflight

The permanent target must depend on a pytest fixture or equivalent setup gate that executes before the target body even when the target node is selected alone. A source, binding, runtime-seal, callsite, or global diagnostic must prevent target entry and therefore prevent sentinel creation.

### Fail-closed protected-source grammar

The source model must preserve explicit order and scope and either correctly model or fail closed on every binding-capable construct relevant to the protected surface, including:

```text
Match / pattern captures
TryStar
While
TypeAlias
class decorators, bases, keywords, and class-body globals
comprehension and generator scopes
global and nonlocal declarations
attribute and subscript Store/Del
```

Unsupported binding syntax must produce a finite diagnostic rather than silently disappearing from the ledger.

### Independent source and code observations

Each protected callable needs literal, independently authored observations for:

```text
normalized source digest
normalized AST digest
canonical code-object digest
module/name/qualname
defaults and keyword defaults
closure/freevars
decorator and __wrapped__ posture
```

The code seal must not depend on comparing two aliases of the same mutable function object.

### Accurate evidence and reporting

The new validation root must:

- allocate every formal invocation before argument/preflight validation;
- preserve invalid-recorder invocations as normal attempt rows;
- report the actual fingerprint class used by each attempt;
- state that the candidate contains **30 required paths**, not 20.

## Codex repair handoff

Send this complete prompt to the **existing write-enabled Capability implementation conversation**:

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Capability_G11_Findings_Repair_Prompt.txt

Size:
28,383 bytes

SHA-256:
5b0edf4f650567e3e0e265a08a84a1399d7cff3f34e8290b55e6accac0e388ee
```

The prompt is bound to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Opening candidate tree:
84cb309f477fec7a28bccf5c671d4bb68393801c

Opening manifest:
615f93b6eca41019bfb617ec9c6dbc1ebaca6fad4e13ad9bba5c52d5b165ce04

Opening nodes:
5,095

Opening node-list SHA-256:
f6e7929241c6adb60df081ee9e59bff050e49869f90fc54e1d1072cf9362993d

G11 audit root:
/private/tmp/g11.66vv1X

G11 evidence-index SHA-256:
551e3a149dc07cc06f6bc3f6d5e1d7dc878b3699ebe9cf756adddaede7396205
```

The repair must again validate:

```text
target passes A/B/C
projection A == B == C
live complete suite passes
clean-commit complete suite passes
source logical index and authoritative object graph remain unchanged
exactly one repository path changes
```

The required successful outcome is:

```text
COORDINATOR_RW0_B2_CAPABILITY_G11_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

That result authorizes only another fresh read-only independent audit. Staging, commit, push, and PR creation remain blocked.

**Source:** Codex’s G11 independent-audit report supplied in this turn.  
**Confidence:** High that the remaining repository repair is confined to the Capability boundary test; high that production and documentation must remain untouched; medium-high that target-attached gating plus independent code/source seals and a scope-accurate fail-closed grammar will close the reproduced bypasses.

Some older uploaded files are no longer accessible in the current file surface. None are needed for this repair; re-upload a specific file only if it needs to be inspected again.
