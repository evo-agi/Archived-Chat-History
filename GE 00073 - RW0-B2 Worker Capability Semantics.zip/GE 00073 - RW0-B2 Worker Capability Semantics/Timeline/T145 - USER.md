Here is Codex's response:

STABLE\_REPLAY\_INPUT\_INCOMPLETE
No G7 root was created; staged harness files were removed. Source, G6, and all prior evidence remain unchanged.
G6 contains 1,152 symlinks and 12 FIFOs under uncleaned pytest basetemps. Its diagnostic states cleanup never ran, while the protocol permits exclusions only for transients removed before failure and requires unsafe entries to fail.
Should I proceed by excluding G6’s documented transient basetemp trees from its historical projection?
