## Engineering disposition

**Proceed to a fresh independent audit. Do not stage or commit this candidate yet.**

The report satisfies the implementation-closeout threshold:

- exact final topology of **30 dirty paths: 24 tracked modifications and 6 untracked additions**;
- all ten newly authorized protected-owner paths are within the reconciled ceiling;
- exactly the two required opening-candidate paths remained byte-identical;
- all 4,676 opening test nodes were retained in order, with 43 permitted additions;
- the complete suite passed **4,719/4,719** on the only full-suite attempt;
- two final provenance executions reproduced the same 6,428-byte manifest and 6,661-byte complete output.

Those results are credible implementation evidence, but not acceptance. The patch now changes C2A, Section 41 lineage, and all B1 value/relation reconstruction boundaries. That makes this re-audit more consequential than the original Capability audit: it must judge whether the protected owners were hardened without altering their valid identities or silently moving semantic ownership into B1 or Capability.

The reconciled design fixed the relevant algorithms, tariffs, B1 relation maxima, and the `863 + 249 = 1112` composition before mutation.   The exact 30-path ceiling was likewise frozen before implementation. 

### Principal residual audit risks

The fresh audit should not be a test rerun with source inspection around the edges. It needs external counterexamples in five areas:

1. **Owner reconstruction completeness.** Each C2A and lineage helper must read the complete authoritative private state, charge before descent, reconstruct a fresh exact owner value, and preserve all valid canonical bytes. One omitted slot or trusted public method would reopen the original defect.

2. **Occurrence-work arithmetic.** The reported tariffs and B1 maxima must be mechanically exact. Shared DAGs must be charged repeatedly, active cycles rejected, and no work may occur before the applicable meter. At the same time, the audit must preserve the explicit nonclaim: these are graph-occurrence limits, not integer-bit-length, serialized-byte, wall-clock, or universal denial-of-service limits.

3. **B1 semantic use of fresh values.** Field attributes, methods, equality, copy operations, and every relation must consume reconstructed state. A relation that reconstructs an input but later reads the original object would still permit the audit’s resealed-invalid-value class of failure.

4. **Host snapshot composition.** The private seam must perform host validation once, return only five fresh safe projections, and prevent Capability from reading the original phase, authority, readiness, host-qualification, or effect-fence objects. The composed `1112` total must not conceal an extra unmetered projection pass.

5. **Capability-local closure.** The Wire owner callable and manifest must be unreachable after import; hostile keys must yield only the fixed invariant; generic session-bearing unknown fields must receive the privacy reason; and the narrowed error immutability claim must remain accurate under supported public access and deliberate low-level reflection.

The implementation’s 43 added nodes are plausible, but node volume is not semantic closure. The audit prompt therefore requires independent slot inventories, budget derivation, class-wide bypass mutants, original-object-read probes, snapshot tracing, and loader-global inspection.

## Independent-audit handoff

Start a **new read-only Codex conversation** and send this complete prompt:

:chatgpt-content-reference{index="3"}

Verify the artifact:

```text
Filename:
Coordinator_RW0_B2_Capability_Integrated_Owner_Repair_Fresh_Audit_Prompt.txt

Size:
39,857 bytes

SHA-256:
ab47755d8a303c70d1918dd821b033aa50da63db4b98c86c6f6a1721395f546c
```

The embedded target is:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Topology:
30 dirty
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

Tracked diff:
586b2634b73fa4cf6e1b56d5afdcc2574f01fc5d49071d5b5199bc903e58631a

Canonical manifest:
6,428 bytes
177dab5f0c89f0bf99273c2fe9b3f8123f4df34c9dc29306acafb0308eaeb900

Complete recipe output:
6,661 bytes
20522a0b494d6e3511abe94b33dcee9a4f3a4c4a22768fa20bc369a6354f3042

Candidate nodes:
4,719

Candidate node-list SHA-256:
24f6fe99b8ef728859327884da26f17f6dc9f8ea834aaf2b26a5914122399be6
```

The prompt contains the full canonical manifest and exact recipe source. It stops with `AUDIT_PROVENANCE_MISMATCH` before correctness inspection if any path, byte, mode, classification, repository identity, or recipe result differs.

### Independent node expectation

The prompt verifies the following derived comparison against clean `HEAD`:

```text
Candidate:       4,719
Clean HEAD:      4,655
Intersection:    4,655
Candidate-only:     64
HEAD-only:            0
```

Those 64 comprise the previously audited 21 Capability nodes plus the 43 integrated-repair additions. All 43 new nodes must belong only to the nine authorized direct owner test files.

### Audit perspectives

The audit uses four independent read-only perspectives:

1. C2A and Section 41 lineage owner reconstruction.
2. All eight B1 values, public surfaces, relations, and budgets.
3. Capability snapshots, qualification, Wire loader, privacy, authority, and documentation.
4. Test causality, public/import boundaries, evidence, nodes, and provenance.

If source and external probes are green, it independently runs the focused groups and then exactly one full suite expecting:

```text
4,719 collected
4,719 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
```

A deterministic material source or probe defect may stop the validation gate before the full suite. The auditor must not repair or rerun modified candidate bytes.

### Required verdict

The audit returns exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Acceptance must also include:

```text
COORDINATOR_RW0_B2_CAPABILITY_INTEGRATED_OWNER_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Only that result advances to audited-byte staging. The project protocol requires implementation and independent audit to remain separate conversations, and any repair changes the bytes and requires another independent audit.   Provenance must then be regenerated at the commit gate and staged blobs compared against the accepted manifest; provenance alone does not establish correctness. 

### Sources

- Codex integrated-repair implementation report supplied in this turn.
- Protected-owner reconciliation algorithms, tariffs, and integration decision.  
- Exact repair ceiling and audit lifecycle.  

**Confidence:** High that the candidate is correctly bound and ready for fresh audit; deliberately unassigned on acceptance until the protected-owner inventories, work tariffs, reconstructed-local behavior, snapshot composition, and Capability boundary survive independent counterexamples.
