PROMPT_ID

RW0_B2_WIRE_NODE_PLACEMENT_CONTINUATION_V3_REBASELINE_CURRENT_CANDIDATE

TITLE

Coordinator RW0-B2-Wire — provenance-rebaseline the preserved 16-path
candidate, repair existing-test node placement, and resume validation

SUPERSESSION

This complete prompt supersedes every earlier node-placement continuation
prompt for the current stopped workspace.

Do not use any prompt that requires:

- a clean `trunk_dev` checkout;
- an absent feature branch;
- creation of `codex/rw0-b2-wire-protocol-v1`; or
- proof that the six untracked files equal candidate-collection attempt 001
  when that attempt retained no per-path hashes or sizes for them.

The prior collection evidence is preserved but is not sufficient to bind the
current untracked bytes. This prompt deliberately creates a new exact
continuation baseline from the live 16-path candidate before any edit.

ENGAGEMENT TYPE

Parent-only workspace-write continuation in the existing
`codex/rw0-b2-wire-protocol-v1` implementation conversation.

Do not create or resume subagents. You remain the sole repository writer.

This continuation authorizes:

1. read-only verification of the stopped branch and candidate topology;
2. exact provenance refreezing of the current 16-path candidate;
3. one current-state reconciliation collection before editing;
4. a bounded three-file node-placement repair;
5. one corrected candidate collection after editing;
6. resumption of the previously authorized focused, full-suite, guard, cleanup,
   and final-provenance sequence.

It does not reopen the accepted Wire contract, profile, ownership, framing,
classifier, privacy, bounds, 16-path allowlist, or Capability disposition.

It is not an independent audit, commit gate, publication gate, or Capability
implementation.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED STOPPED WORKSPACE

Before any mutation, require and record:

- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  consistent with the stopped local feature branch and no remote contact
- worktrees:
  `1`
- exactly 16 dirty paths:
  - 10 tracked modifications
  - 6 untracked additions
- staged/unmerged:
  `0/0`
- every candidate path:
  regular mode `0644`
- `git diff --check`:
  clean
- no Git operation or lock
- no repository-local bytecode, pytest cache, database, journal, build, archive,
  generated-manifest, or recorder residue
- retained prior evidence root:
  `/private/tmp/rw0-b2-wire.H4lagH`

Require the tracked textual-diff SHA-256 and the 16-path classifications to
match the retained candidate-collection record.

Do not require unavailable per-path hashes or sizes from that record.

Stop if:

- branch, HEAD, tree, path set, classifications, modes, tracked diff, or
  topology differ;
- any seventeenth path is dirty;
- prior evidence was overwritten or deleted;
- any remote contact, staging, or repository mutation occurred after the
  reported stop.

PRIOR EVIDENCE DISPOSITION

Preserve candidate-collection attempt 001 exactly.

Classify it as:

```text
CANDIDATE_COLLECTION_ATTEMPT_001_PRESERVED
CANDIDATE_COLLECTION_ATTEMPT_001_CURRENT_BYTE_BINDING_INCOMPLETE
```

It retains historical process and node-list evidence, but receives no
correctness or current-byte identity credit because the six untracked file
bytes were not individually hashed.

Do not reconstruct or invent missing per-path data.

NEW CONTINUATION EVIDENCE ROOT

Create one new operator-owned, non-symlink, mode-0700 root beneath
`/private/tmp`.

Retain key evidence as regular mode-0400 files.

Use distinct external:

- `TMPDIR`;
- `PYTHONPYCACHEPREFIX`;
- pytest `--basetemp`;
- JUnit;
- stdout/stderr;
- structured result records.

Do not write evidence into the repository.

EXACT PROVENANCE RECIPE

Use the exact retained
`governed-execution.audit-patch-manifest.v1` source from the original
implementation engagement.

Before executing it, require:

- source size:
  `3,945` bytes
- source SHA-256:
  `db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`

If the exact source bytes are unavailable under retained evidence or cannot be
verified, stop. Do not approximate or reconstruct the recipe.

The historical fixed output path must not overwrite pre-existing evidence.
Execute the exact source unchanged while an external wrapper redirects only its
exact `Path.write_bytes` sink into the new evidence root.

CURRENT-CANDIDATE REBASELINE — BEFORE ANY EDIT

Run the exact provenance recipe twice against the current 16-path candidate.

Require:

- both executions return 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- exactly 16 entries;
- exactly 10 tracked modifications and 6 untracked paths;
- every entry regular mode `0644`;
- complete per-path:
  - path
  - classification
  - type
  - mode
  - size
  - SHA-256;
- the tracked textual-diff SHA-256 matches the retained attempt-001 record;
- branch, HEAD, and upstream match the required stopped workspace.

Save one immutable continuation-opening manifest mode `0400`.

This new manifest—not candidate-collection attempt 001—is the authoritative
opening byte baseline for all subsequent repair, validation, and final
comparison.

CURRENT-STATE RECONCILIATION COLLECTION — BEFORE EDIT

After the new opening manifest is frozen, run one isolated complete test
collection exactly once without editing.

Call it:

```text
continuation-opening-collection
```

Require:

```text
baseline committed nodes:       4,566
current candidate nodes:        4,629
net additions:                  63
removed opening nodes:          0
renamed opening nodes:          0
duplicate nodes:                0
```

Require:

- all 4,566 opening nodes remain;
- opening relative order remains a subsequence;
- the literal 4,629-node list is byte-identical to the retained
  candidate-collection-attempt-001 node list;
- exactly 60 additions belong to the four new Wire test files;
- exactly these three additional nodes belong to existing files:

```text
tests/test_architecture_contracts.py::test_rw0_b2_wire_private_source_status_has_no_authority_claim

tests/test_rw0_remote_contact_phase_entry_contract.py::test_rw0_b2_wire_current_status_projection_is_synchronized

tests/test_software_development_progression_boundary.py::test_rw0_b2_wire_does_not_widen_progression_authority
```

Require repository bytes and the continuation-opening manifest to remain exact
before and after collection.

If the current collection differs from the retained attempt-001 node list, stop.
Do not repair or perform another collection.

ENGINEERING DISPOSITION

The current candidate becomes an accepted continuation opening baseline only
after both:

1. exact two-run current provenance; and
2. exact reconciliation collection

succeed.

This does not prove the live candidate was byte-identical to the historical
attempt-001 bytes. It deliberately supersedes that unavailable proof with a new
exact byte baseline and a freshly reproduced logical/node baseline.

The collection rule remains:

- existing test files introduce no new collected node IDs;
- every new node belongs to one of the four new Wire test files.

The three existing-file nodes are a bounded test-placement defect. Preserve
their assertions by composing them into existing owning tests.

AUTHORIZED NODE-PLACEMENT REPAIR PATHS

After the rebaseline and reconciliation collection succeed, modify exactly:

```text
tests/test_architecture_contracts.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_software_development_progression_boundary.py
```

The other thirteen candidate paths must remain byte-identical to the new
continuation-opening manifest during this repair.

REMOVE EXACTLY THESE TOP-LEVEL NODES

```text
tests/test_architecture_contracts.py::test_rw0_b2_wire_private_source_status_has_no_authority_claim

tests/test_rw0_remote_contact_phase_entry_contract.py::test_rw0_b2_wire_current_status_projection_is_synchronized

tests/test_software_development_progression_boundary.py::test_rw0_b2_wire_does_not_widen_progression_authority
```

Do not delete or weaken their substantive assertions or causal controls.

COMPOSE ASSERTIONS INTO EXISTING OWNERS

1. Architecture

Integrate all private-source/no-authority assertions and negative controls into
the pre-existing architecture/current-status node that owns private source,
public boundary, and authority non-widening.

It must continue to prove:

- Wire is private and no-I/O;
- no package-root, public protocol, `StateStore`, or `WriterSession` widening;
- no contact, worker, process, persistence, authority, acceptance, or
  Capability implementation;
- profile evidence is not authority;
- B1 is unchanged;
- RW0-C/D/E and ES retain their ownership.

2. RW0 status and synchronized projections

Integrate all Wire current-status projection assertions into the pre-existing
RW0 owner/cross-reference structural oracle that owns the five-document visible
Markdown projection.

Preserve:

- unique intended heading owner/range;
- one visible unfenced marker pair;
- all live prose inside the pair;
- hidden fenced duplicates ignored;
- duplicate visible blocks rejected;
- same-title sibling relocation rejected;
- visible leading/trailing prose outside markers rejected;
- backtick and tilde controls;
- no raw global `count`, `find`, `index`, or regex-only owner extraction;
- normalized projection equality;
- exact profile ref/digest and all nonclaims.

3. Progression boundary

Integrate all non-progression/non-authority assertions into the pre-existing
progression-boundary node that owns the current private/no-runtime boundary.

It must prove Wire:

- adds private pure source only;
- advances no durable progression;
- authorizes no worker/process/contact;
- implements no semantic terminal fact or acceptance;
- leaves Capability, C, D, E, ES, Git, and publication outside the tranche.

TEST-INTEGRITY RULES

- Do not rename, remove, reparameterize, redecorate, skip, xfail, or change the
  collection identity of any opening node.
- Do not add a new top-level test, class, parameter case, or generated node in
  an existing test file.
- Do not remove a mutant or assertion merely to satisfy collection.
- Preserve every substantive assertion and causal control from the removed
  nodes.
- Integrate assertions into the owning structural or authority oracle; a loose
  paste is insufficient.
- No production or documentation byte may change during this repair.

CORRECTED CANDIDATE COLLECTION

After the three-file repair, run one new isolated collection exactly once.

Call it:

```text
corrected-candidate-collection
```

Require:

```text
opening committed nodes:       4,566
corrected candidate nodes:     4,626
net additions:                 60
removed:                       0
renamed:                       0
duplicates:                    0
```

All 60 additions must belong to exactly:

```text
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

Every opening node must remain in relative order.

The three existing-file candidate-only nodes must be absent.

Require exact node-list, set/order comparison, JUnit/collection parse, and
repository fingerprints before/after.

Stop if this collection is not exact. No further collection or mutation is
authorized after a collection-gate failure.

POST-COLLECTION NODE FREEZE

After the corrected collection passes:

- the exact 4,626 node identities are frozen;
- later repairs may change test bodies or source/docs only inside the original
  16-path allowlist;
- no later repair may add, remove, rename, reparameterize, redecorate, skip, or
  xfail a test;
- any required node-identity change is a stop condition.

RESUME ORIGINAL FOCUSED VALIDATION

Run serially under isolated external evidence paths:

1. each new Wire test file individually;
2. all four Wire test files together;
3. C2A compatibility:
   - `tests/test_worker_execution_semantic_*.py`
   - `tests/test_c2a_relations.py`
   - `tests/test_c2a_first_slice_semantic_protocol_contract.py`
   - `tests/test_c2a1_pure_semantic_values.py`
4. B1 compatibility:
   - `tests/test_rw0_b1_*.py`
5. static/public/import boundaries:
   - `tests/test_c2a_nonimplementation.py`
   - `tests/test_runtime_non_authority.py`
   - `tests/test_c2b2_development_row_value_boundaries.py`
   - `tests/test_b2a_writer_session_contract.py`
   - `tests/test_codex_agent_config.py`
6. status/document compatibility:
   - `tests/test_rw0_remote_contact_phase_entry_contract.py`
   - `tests/test_architecture_contracts.py`
   - `tests/test_software_development_progression_boundary.py`
   - `tests/test_remote_worker_pre_execution_planning_contract.py`
7. `git diff --check`;
8. exact path, mode, topology, public/import, protected-byte, residue, Git
   operation, and lock guards.

Every run must have:

- return code 0;
- zero failures, errors, skips, xfails, warnings;
- empty stderr;
- parseable JUnit;
- no duplicate, ambiguous, or unmapped case;
- equal caller/child numerical umask;
- exact candidate fingerprint before/after.

FOCUSED REPAIR RULE

On a focused failure:

- preserve failure evidence;
- repair only when causally attributable to the candidate;
- remain inside the original 16 paths;
- preserve the accepted Wire contract/profile/caps/ownership;
- preserve all 4,626 node identities;
- weaken no test;
- rerun the affected and dependent focused gates.

Stop on:

- a seventeenth path;
- C2A/B1/public/schema/dependency/runtime change;
- contract/profile/cap/ownership revision;
- node-identity change;
- unrelated mutation.

COMPLETE SUITE

After all focused gates pass and bytes are frozen, run complete-suite attempt
001 exactly once.

If green, do not rerun.

If it fails:

- preserve all attempt-001 evidence;
- repair only when every failure is candidate-caused, inside the 16-path
  allowlist, contract-preserving, node-identity-preserving, and test-nonweakening;
- rerun every affected focused gate;
- run complete-suite attempt 002 exactly once.

No third complete-suite attempt is authorized.

FINAL PROVENANCE

After exact-green validation and cleanup:

1. require topology:
   - 16 dirty paths
   - 10 tracked modifications
   - 6 untracked additions
   - 0 staged
   - 0 unmerged;
2. run the exact provenance recipe twice;
3. require byte-identical stdout and canonical manifests;
4. require exactly the original 16 paths;
5. compare with the new continuation-opening manifest:
   - exactly the three authorized existing test files may differ from the
     continuation opening candidate due to node placement;
   - the other thirteen candidate entries must remain byte-identical unless a
     later explicitly permitted in-scope focused/full-suite repair changed them;
   - every later change must be enumerated and validated;
6. prove every protected path equals HEAD;
7. retain complete per-path identities, tracked-diff digest, manifest digest,
   complete-output digest, validation evidence, and guards;
8. remove only continuation-created transient artifacts.

Do not perform an independent audit, stage, commit, push, create a PR, merge,
tag, release, deploy, contact a remote, or implement Capability.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_WIRE_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT
```

only if:

- the live candidate is newly provenance-bound;
- the reconciliation collection exactly reproduces attempt-001 node identity;
- the node-placement repair is exact;
- the corrected candidate collection is exact;
- all focused and complete-suite validation is green;
- final provenance is stable;
- no stop condition fires.

The final report must distinguish:

1. historical candidate-collection attempt 001 and its byte-binding limitation;
2. continuation-opening provenance;
3. continuation-opening reconciliation collection;
4. the three-file repair;
5. corrected candidate collection;
6. all focused/full-suite attempts;
7. final provenance;
8. provenance, validation, and implementation confidence separately.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
CANDIDATE_COLLECTION_ATTEMPT_001_PRESERVED
CANDIDATE_COLLECTION_ATTEMPT_001_CURRENT_BYTE_BINDING_INCOMPLETE
CONTINUATION_OPENING_PROVENANCE_CREATED
CONTINUATION_OPENING_COLLECTION_RUN_EXACTLY_ONCE
CORRECTED_CANDIDATE_COLLECTION_RUN_EXACTLY_ONCE
```
