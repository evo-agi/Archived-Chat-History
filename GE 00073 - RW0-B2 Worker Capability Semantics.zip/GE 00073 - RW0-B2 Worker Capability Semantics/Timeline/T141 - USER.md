Here is Codex's response:

COMPLETE\_REPLAY\_SOURCE\_MUTATION\_DETECTED
Stopped at `evidence_close_g5`; failure envelope: [0182/envelope.json](/private/tmp/g6.4101bd/a/0182/envelope.json). The repository was not modified, no suite was rerun after failure, and the success token is not issued.
