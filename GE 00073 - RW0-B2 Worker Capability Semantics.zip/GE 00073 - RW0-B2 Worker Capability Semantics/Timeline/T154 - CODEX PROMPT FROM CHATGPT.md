PROMPT_ID

RW0_B2_CAPABILITY_G8_FINAL_FRESH_INDEPENDENT_AUDIT_V1

TITLE

Coordinator RW0-B2-Capability — fresh independent audit of the exact G8-sealed
final candidate, replay harness, causal tests, dual-state validation, and
authority boundaries

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated independent audit.

Use a new Codex conversation. Do not use the implementation, repair,
diagnostic, replay, or commit-gate conversation that produced G8.

The audit parent and all audit subagents are read-only.

No repository mutation, formatting, cleanup of candidate bytes, dependency
installation, staging in the source repository, commit in the source
repository, push, pull request, merge, tag, release, deployment, remote service
contact, provider or live-host contact, product worker/model invocation,
database mutation, migration, or supporting-repository inspection is
authorized.

Audit-created probes, alternate indexes, external local-only repositories,
pytest outputs, and provenance records may be written only beneath one new
operator-owned, non-symlink, mode-0700 audit root.

Because checked tests enforce path privacy, use one short neutral audit-root
pattern:

```text
/private/tmp/g9.XXXXXX
```

Pre-screen every path visible to a pytest child with the exact owning
path-safety grammar before launch.

CRITICAL INLINE OUTPUT RULE

The complete operative audit report must be printed inline in the Codex chat.

Do not return only:

- a verdict token;
- a short summary with `/private/tmp` links;
- “see report”;
- file paths that contain the material findings.

Evidence files may be listed as supplementary provenance only after every
decision-relevant fact, exact value, finding, validation result, and
continuation boundary has appeared inline.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Independently determine whether the exact G8-sealed candidate is ready for the
commit/push/pull-request gate.

The audit must verify:

1. exact candidate provenance and the 30-path tree;
2. the sole final-repair path and the protected complement;
3. the closed reachable-call contract and all command/process/Git-capable
   mutants;
4. the literal 43-row state-independent boundary projection;
5. causal protection for every protected-content row, including the exact prior
   audit survivor;
6. the eight stable-contract mutants;
7. unstaged, staged, and clean-committed compatibility;
8. the schema-correct restore harness and its tooling self-tests;
9. the complete G8 all-attempt chronology;
10. the live and clean 5,072-test validation envelopes;
11. historical G6/G7 quarantine boundaries without granting those failed
    replays validation authority;
12. public, import, privacy, durable-state, runtime, and authority
    non-widening.

Do not reopen accepted architecture merely because the history is long.
Report a concrete contradiction if one exists.

EXPECTED LIVE REPOSITORY IDENTITY

Require at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644
```

Require:

```text
git diff --check:
clean

cached diff:
empty

Git operation or lock:
none

logical source index:
unstaged

candidate symlink or special path:
none

repository cache, bytecode, database, journal, archive, build output,
generated repository manifest, or recorder residue:
none

thirty-first changed path:
absent
```

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

FINAL CANDIDATE TARGET

Authoritative G8 evidence root:

```text
/private/tmp/g8.3cee3f
```

Required G8 final report:

```text
/private/tmp/g8.3cee3f/final_report.md

size:
99764 bytes

SHA-256:
e54ecbef3321b810e58c248221d6542325b878c67ddd35483993c61e9781d118
```

Required G8 attempt manifest:

```text
/private/tmp/g8.3cee3f/attempt_manifest.jsonl

rows:
212

size:
67790 bytes

SHA-256:
83e79b1ca3ca29a9a7dec45bededcc642057f8dc5bf940bfc826c392f6ae0c65
```

Required G8 self-excluding evidence index:

```text
/private/tmp/g8.3cee3f/evidence_index.jsonl

rows excluding itself:
2403

size:
448923 bytes

SHA-256:
f90d50dc17e95e432b6577cad99669777f99bcd2d6af7c42509d2987db8248fc
```

Required indexed projection:

```text
size:
530717 bytes

SHA-256:
053a696a2034958ea2a5161713fa81fbfe88d88e5cf5987e185115872075ae7a
```

Required external terminal results:

```text
index-builder result:
2485 bytes
SHA-256:
3b88a5bea1846161424cd26b208af9d36cd859d97b818f9bc7e53041deb4fb00

external verifier result:
781828 bytes
SHA-256:
3e59175a566b860abd09165d6952a4350cdb42b2b77cb0509cc4420d4df53f4a
```

Required final candidate identities:

```text
canonical manifest:
6430 bytes

canonical-manifest SHA-256:
d6f86248da0c4843e20b91cb443f960596e483e08a8f2cff716bbcea4fb553d8

tracked textual-diff SHA-256:
cc91155aff703e1c54c139820f841d98135f37ee7c87a71d3b00b07a2672e2a6

complete recipe output:
6663 bytes

complete recipe-output SHA-256:
400a5d35fcd18ba6b95c375194719d1bb97796ba61cfcb416ac09b575c6a9bb3

candidate tree:
0fcf6680ded68d66f62b75b5dc842d69b343a334

final node count:
5072

final ordered-node-list SHA-256:
f0faec3289ed635a741867bb2a655487f4a4a824dcf4cc0921c334beada1bbd3
```

Required normalized source fingerprint:

```text
schema:
governed-execution.normalized-authoritative-git-fingerprint.v1

size:
1421607 bytes

opening/closing SHA-256:
0ff46a4afaaecb079573c0fb32e2d1103bd55fa1e791ad4e01035992f65ca6dc
```

Required logical source index:

```text
git ls-files --stage -z

size:
19139 bytes

opening/closing SHA-256:
8f170467abeba2d935a917de2e057eb75635efc555f5a44bfb6cb9c77934c019
```

Required report-only raw source index:

```text
size:
22476 bytes

SHA-256:
7926e411fe75047992b7677548c8a40d090127ce6dbda64c4262d59ca749c213
```

EXACT RECIPE SOURCE

Require the indexed retained source:

```text
/private/tmp/g5.hiLE2y/exact_recipe_source.py

type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Do not reconstruct recipe source from prompt text or a digest.

Create one verified root-local mode-0400 execution copy under the new G9 audit
root. Run the exact source twice with only its fixed external historical output
sink redirected to unique G9 paths.

Require both generated manifests and complete outputs to match the indexed G8
final target byte-for-byte.

EXACT FINAL MANIFEST

Recover the exact manifest through the G8 index and verify all 30 entries.

The sole G5-opening-to-final candidate-path change was:

```text
tests/test_rw0_b2_capability_boundaries.py

opening:
kind:
untracked

type:
regular

mode:
0644

size:
28469 bytes

SHA-256:
d5582ea702ee445083c3457188b35b302e5ade52db119c1e2808a6fea5a1f022

final:
kind:
untracked

type:
regular

mode:
0644

size:
76858 bytes

SHA-256:
eb6ca3cd19b4bd723b82002aa93e7b5743ef02b768ac169d96e0011582e61977
```

The other twenty-nine G5-opening candidate entries must remain exact.

Every repository path outside the final 30-path manifest must equal HEAD.

HISTORICAL EVIDENCE CLASSIFICATION

G5:

```text
/private/tmp/g5.hiLE2y

index:
7234 rows
1583837 bytes

SHA-256:
199af9ac4299cc41a4434d44f1b1f7bcaf3265490b7417e174ad5d48723f8fcc

classification:
implementation evidence with partial historical attempt metadata
not reconstructed
```

G6:

```text
/private/tmp/g6.4101bd

classification:
failed replay evidence
both 5072-test suites completed
closeout failed because opening and closing evidence projections used
inconsistent directory-size schemas
cleanup did not run
attempt 0183 incomplete
no authoritative final report/index
not final validation authority
```

G7:

```text
/private/tmp/g7.30c557

classification:
failed replay evidence
causal sealing and A/B/C completed
attempt 0129 correctly rejected regular-to-symlink
attempt 0130 restored target bytes/mode then failed on obsolete top-level
`index` assumption
later validation phases did not run
not final validation authority
```

G8:

```text
authoritative complete validation and closeout envelope
```

Do not credit G5, G6, or G7 as substitutes for G8. Use them only for continuity
and historical-findings verification.

G6/G7 TRANSIENT QUARANTINE TARGETS

G6 required report values:

```text
basetemp roots:
34

quarantine rows:
23119

quarantine inventory size:
8429688 bytes

quarantine SHA-256:
dceccfcf6d07c1fc217b7f309e622a9caa8612674c819398e840d2b3b065b81d

retained projection rows:
5954

retained projection SHA-256:
d29952e1bb4404c3c6c547fb1c52b9dd9a091bab80af123c0d04ea3b1fa2819b

unsafe entries:
1152 symlinks
12 FIFOs
0 other unsafe entries

unsafe outside quarantine:
0

mandatory-record overlap:
0
```

G7 required report values:

```text
basetemp roots:
20

quarantine rows:
706

quarantine inventory size:
279200 bytes

quarantine SHA-256:
c40df656b10707b4f12b6704eb2012bf1733fea53bcdddd734024f3917d8aa32

retained projection rows:
5640

retained projection SHA-256:
fa4c30c844925071aae9be12cf103af188b3c98fb062645f72fc5fc15716f005

unsafe entries:
14 symlinks
0 other unsafe entries

unsafe outside quarantine:
0

mandatory-record overlap:
0
```

Independently rederive basetemp roots from retained launched pytest argv. Never
follow symlinks or open FIFOs. Require exact agreement and no mandatory record
inside quarantine.

PROVENANCE GATE

Before correctness inspection or audit perspectives:

1. create:

   ```text
   /private/tmp/g9.XXXXXX
   ```

2. safely `lstat` all retained-evidence path components;

3. verify the exact G8 self-excluding index;

4. verify the G8 report, attempt manifest, indexed projection, final manifest,
   recipe records, terminal index results, and mandatory records;

5. independently inventory G8 and require:
   - regular retained files;
   - directory/file ownership and modes;
   - no symlink or special entry;
   - no unindexed entry;
   - index excludes itself;

6. verify exact repository identity and `30/24/6/0/0` topology;

7. verify every final manifest entry;

8. verify no thirty-first changed path;

9. verify every path outside the manifest equals HEAD;

10. verify the exact recipe source and root-local copy;

11. run the recipe twice with safe sink redirection;

12. require exact manifest/output equality;

13. verify normalized source fingerprint and logical index;

14. verify the sole opening-to-final path delta and twenty-nine-entry equality;

15. verify opening and final node lists;

16. verify every G8 attempt envelope and attempt-manifest row;

17. verify terminal index creation and external verification;

18. verify G6/G7 historical quarantine boundaries;

19. verify all explicitly protected production, documentation, package,
    dependency, schema, migration, SQL, `StateStore`, and `WriterSession`
    surfaces.

On any mandatory target/evidence identity mismatch, stop before correctness
inspection and return:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not approximate or regenerate missing evidence.

AUDIT PERSPECTIVES

After the provenance gate, use exactly four bounded, non-nesting, read-only
perspectives when available. No child runs tests or modifies files.

1. Closed-call and protected-content auditor
   - inspect the sole final changed test completely;
   - verify the complete reachable local-helper inventory;
   - verify the exact external-call allowlist;
   - inspect module-global identity/type checks;
   - independently run constructed, aliased, dynamic, shell, subprocess,
     GitPython-like, dulwich-like, default, closure, and unknown-helper mutants;
   - verify every protected-content P01–P13 mutation;
   - verify the exact P12 audit-survivor kill;
   - verify the 43-row projection is literal, complete, unique, and
     non-circular.

2. Three-state, restore-harness, and stable-contract auditor
   - inspect the normalized restore-harness source;
   - verify no top-level normalized `index` access;
   - verify explicit logical-index comparison;
   - independently exercise the seven restore-harness tooling cases;
   - independently replay the eight stable-contract mutants;
   - independently reproduce A/B/C target and projection behavior;
   - verify B/C tree and source-index/object isolation.

3. Validation and all-attempt-evidence auditor
   - verify all 212 attempts, sequence continuity, labels, envelopes, expected
     and actual outcomes, and credit classifications;
   - scrutinize non-creditable sequences 8, 9, and 11 and credited recoveries
     10, 12, and 13;
   - verify exact focused argv/results;
   - verify live/clean collection;
   - verify live/clean 5072-test JUnit mappings;
   - verify no hidden retry;
   - verify run-local pre/post fingerprints;
   - verify cleanup, final provenance, final report, and terminal index
     mechanics.

4. Provenance, public-boundary, and authority auditor
   - verify exact 30-path candidate and protected complement;
   - verify historical G5/G6/G7 classifications and quarantine boundaries;
   - verify normalized authoritative source identity;
   - distinguish ambient/report-only metadata;
   - verify imports, exports, callers, dependencies, schemas, migrations,
     durable-state/runtime surfaces, and authority boundaries;
   - verify C/D/E and ES seams remain intact.

The parent performs reconciliation, independent probes, node comparison,
validation, and closeout. Preserve disagreements.

Every finding must include:

```text
ID
type
severity: critical | high | medium | low | observation
current contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect or pre-existing issue
```

REQUIRED SOURCE AND TEST INSPECTION

Inspect the complete final changed file:

```text
tests/test_rw0_b2_capability_boundaries.py
```

Inspect every helper and constant in its reachable call graph.

Inspect protected adjacent sources/tests as concretely required:

```text
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/c2a_contract_support.py
AGENTS.md
README.md

.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-capability.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/software-development-progression-boundary.md

src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml
```

Inspect additional Coordinator files only for a concrete dependency and record
why. Do not inspect another repository.

HYPOTHESIS A — CLOSED REACHABLE-CALL CONTRACT

Independently prove or falsify:

1. Exact target root:

   ```text
   test_exact_twenty_path_ceiling_modes_and_protected_controls
   ```

2. Exact local reachable helpers:

   ```text
   _stable_capability_boundary_projection
   _protected_content_row
   ```

3. Exact external-call allowlist equals the G8 report.

4. No unknown local helper, assigned callable, default/closure callable,
   dynamic dispatch, star import, unresolved alias, arbitrary global callable,
   command/process/Git primitive, or fallback detector survives.

5. Module globals have exact allowed identities/types.

6. The 26 no-status/call-surface mutants and nine module-global mutants are
   genuinely causal and not self-derived.

Independently create equivalent mutants, including changed source spellings and
alias layouts. Require rejection for the intended finite diagnostic.

HYPOTHESIS B — 43-ROW PROJECTION AND PROTECTED CONTENT

Recover the exact 43 ordered rows.

Require:

```text
30 required candidate-path rows
13 protected-content rows P01–P13
unique row IDs
unique purposes
unique subjects
unique diagnostics
literal independent expected values
no Git-state field
no circular expectation derivation
same projection in A/B/C
```

Independently mutate every P01–P13 source/fixture by one predicate and require
the dedicated diagnostic.

Independently reproduce the P12 assertion-weakening survivor and require the
final causal test to kill it.

Challenge row-count, duplicate-ID, duplicate-purpose, duplicate-subject,
duplicate-diagnostic, contract-class, and order controls.

HYPOTHESIS C — RESTORE HARNESS AND STABLE MUTANTS

Inspect the exact G8 harness and require:

```text
schema:
governed-execution.normalized-authoritative-git-fingerprint.v1

no top-level normalized `index` access

explicit logical_index_ls_files_stage_z equality

direct target restoration before Git comparison

raw index observation report-only

normalized fingerprint compared directly
```

Independently test:

```text
regular -> symlink -> regular
regular -> missing -> regular
wrong mode -> restored mode
changed content -> restored content
raw index stat-cache refresh with equal logical index
normalized baseline with no top-level index
negative logical-index mismatch
```

Then independently replay:

```text
missing required path
unexpected literal path
regular to symlink
wrong mode
package-root export
production importer/caller
dependency/schema/migration widening
protected-content weakening
```

Require exact restoration and normalized/logical equality.

HYPOTHESIS D — A/B/C, NODES, AND DUAL SUITES

Independently reproduce:

```text
A:
live accepted unstaged source repository

B:
fully external independent staged repository

C:
same external repository after one diagnostic commit
```

Require:

```text
target passes A/B/C
projection A == B == C
B tree == C tree ==
0fcf6680ded68d66f62b75b5dc842d69b343a334

source logical index unchanged
source authoritative object graph unchanged
external alternates absent
source/external object inodes not shared
```

Independently collect candidate and clean-HEAD nodes.

Require:

```text
candidate:
5072

candidate ordered SHA-256:
f0faec3289ed635a741867bb2a655487f4a4a824dcf4cc0921c334beada1bbd3

repair opening:
5057

repair-opening SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

additions:
15

removals:
0

renames:
0

all additions:
tests/test_rw0_b2_capability_boundaries.py

outside-file order:
unchanged
```

Also collect a clean external `git archive HEAD` baseline and report the exact
intersection/candidate-only/HEAD-only sets.

HYPOTHESIS E — ALL-ATTEMPT AND TERMINAL EVIDENCE

Verify:

```text
212 continuous manifest rows
unique labels
one envelope per ordinary action
one row per envelope
209 credited
3 non-creditable
```

Scrutinize sequences 8, 9, and 11:

- confirm they occurred before candidate validation;
- confirm no candidate or external candidate repository existed;
- confirm their recoveries 10, 12, and 13 are complete;
- confirm no hidden retry of any live or clean full suite.

Verify:

```text
live suite:
exactly once
5072/5072

clean suite:
exactly once
5072/5072

no second attempt for either
```

Verify terminal evidence design:

```text
ordinary attempt manifest finalized before index creation
index-builder source/config retained
external verifier source retained
index creation is final G8 mutation
external result files are outside G8
G8 unchanged after index
index self-excluding
no unindexed G8 path
```

PROVENANCE MODEL

Use G8’s normalized authoritative model.

Require exact equality for:

```text
branch/HEAD/tree/parents/subject
upstream/OID/divergence
worktrees
porcelain v2
tracked binary diff
cached binary diff
logical index via git ls-files --stage -z
candidate manifest and per-path identities
outside-candidate equality
authoritative refs
reachable authoritative object OID/type/size graph
operations/locks/residue
```

Record but do not treat as authoritative equality:

```text
refs/codex/turn-diffs/**
reflogs
packed/loose representation
unreachable loose objects
raw-index stat cache
atime/mtime/ctime/birthtime/inode/device/link count/flags/xattrs
directory st_size
```

Independently challenge whether any excluded ambient field could conceal a
candidate, logical-index, authoritative-ref, or reachable-object change.

INDEPENDENT VALIDATION

Only after source inspection, independent mutants, restore-harness tests,
A/B/C, evidence inspection, and provenance are green enough, run serially
beneath neutral G9 paths.

For every pytest child:

```text
umask 022
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct neutral external PYTHONPYCACHEPREFIX
distinct neutral external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct neutral external --basetemp
distinct neutral external --junitxml
serial execution
```

Pre-screen every child-visible path with the owning path-safety checker.

Run exact focused groups:

```text
selected causal:
16 expected

Capability boundaries:
32 expected

Capability complete:
69 expected

B1/Wire compatibility:
461 expected

architecture/status/static:
907 expected
```

Every credited run requires:

```text
return code 0
zero failures/errors/skips/xfails/warnings
empty stderr
parseable JUnit
zero duplicate/unmapped cases
matching caller/child umask
unchanged candidate authoritative fingerprint
```

If all inspection and focused validation remain green, run:

```text
one live complete suite
one fully external clean complete suite
```

Require each:

```text
5072 collected
5072 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

The two suites are distinct state validations, not retries.

If a deterministic material blocker is found first, the complete suites may be
withheld. State that explicitly. Never repair candidate bytes.

PUBLIC, IMPORT, PRIVACY, AND AUTHORITY BOUNDARY

Require:

- no document change outside the accepted 30-path candidate;
- no production source change outside the accepted candidate;
- no package-root export;
- no reverse production import;
- no unauthorized production caller;
- no dependency, SQL, migration, schema, catalog, StateStore, or WriterSession
  widening;
- no filesystem, process, network, provider, Bridge, ES-call, Git,
  publication, or runtime effect;
- source refs/digests remain unauthenticated evidence;
- no executable permission, semantic acceptance, persistence, or runtime
  authority;
- RW0-C/D/E and Execution Substrate ownership remain as documented.

CLOSEOUT

After removing only G9-created transient artifacts:

1. rerun the exact recipe twice with safe sink redirection;
2. require equality to the opening G8 final target;
3. require same manifest/output/textual diff/file count/per-path hashes/topology;
4. compare all retained evidence-root opening/closing projections;
5. verify source logical index and authoritative object graph unchanged;
6. verify no operation, lock, staged/unmerged path, cache, bytecode, database,
   journal, archive, build, recorder, or generated-manifest residue;
7. retain all audit evidence beneath G9;
8. make retained files regular mode 0400 and directories mode 0700;
9. create a self-excluding evidence index;
10. print the complete report inline.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low candidate defect remains;
- `BLOCK` for any repairable implementation, test, replay-harness, evidence,
  validation, privacy, public-boundary, or authority defect;
- `REJECT` only for a fundamental accepted-architecture contradiction;
- `AUDIT_PROVENANCE_MISMATCH` only for target/evidence identity failure before
  correctness judgment.

If `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or create a PR.

FINAL INLINE REPORT

Use these top-level headings:

```text
# Verdict

# Opening and closing identity

# Provenance and exact candidate

# G8 evidence and attempt chronology

# Audit perspectives and disagreements

# Severity-ranked finding ledger

# Closed reachable-call and module-global result

# 43-row projection and protected-content result

# Restore harness and stable-contract result

# A/B/C state result

# Node identity and migration result

# Retained validation assessment

# Independent validation

# Public, privacy, and authority boundary

# Closeout and evidence index

# Confidence
```

Include exact values inline. Supplementary evidence paths may follow.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
