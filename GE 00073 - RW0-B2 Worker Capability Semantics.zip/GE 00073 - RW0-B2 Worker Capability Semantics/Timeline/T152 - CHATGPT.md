## Engineering disposition

**Restart the complete replay in a new evidence root. Do not modify the candidate, resume G7, or reuse attempts 0001–0129 as the authoritative final chronology.**

The diagnosis is conclusive:

- The `regular → symlink` mutant was constructed correctly.
- Attempt 0129 rejected it with the exact expected assertion:
  ```text
  required_regular_file:.docs/rw0-b2-capability.md
  ```
- Attempt 0130 restored the original regular file exactly:
  ```text
  mode:   0644
  size:   16,611
  SHA-256:
  d338979d87d09eadbddad79c249b0d3936fa8b41cc87dc787ed5211a90de279e
  ```
- The source repository, real source index, authoritative refs, candidate manifest, candidate tree, and reachable source objects were unchanged.
- The external repository’s **logical index** was also restored exactly.
- The cleanup harness then failed on a stale schema assumption:
  ```python
  baseline_index = baseline.pop("index")
  ```
  The current normalized schema contains:
  ```text
  logical_index_ls_files_stage_z
  ```
  and deliberately has no top-level `index`.

This is an **external replay-harness defect**, not a candidate-test defect.

G7 must nevertheless restart because attempt 0130 is permanently noncreditable, later validation never ran, and the failed root cannot be converted into the required complete one-shot evidence envelope.

## Replacement replay design

The replacement replay makes three structural corrections.

### 1. Schema-correct restoration

For every external-fixture mutant, the harness must:

```text
restore the exact target type, bytes, and mode
verify the target directly
compute a fresh normalized authoritative fingerprint
compare normalized fingerprints directly
compare logical_index_ls_files_stage_z explicitly
record raw physical-index observations separately
```

It must never read, remove, or expect a top-level `index` field.

Raw external `.git/index` changes caused by stat-cache refresh are report-only when:

```text
logical index is unchanged
normalized authoritative fingerprint is unchanged
candidate tree is unchanged
```

The new harness is statically audited and tested on disposable repositories before candidate validation begins.

### 2. Fresh complete chronology

A new G8 root records every action from bootstrap onward:

```text
bootstrap
recorder self-tests
restore-harness self-tests
historical-evidence verification
opening provenance
every individual mutant
every restoration
focused validation
A/B/C state replay
live and clean node collection
live and clean full suites
guards
cleanup
final provenance
report and evidence sealing
```

G7 remains immutable failed-replay evidence. Its otherwise creditable attempts are not transplanted into the new authoritative chronology.

### 3. Coherent final index sealing

The prompt removes the self-recording paradox around “index must be last”:

- all normal envelopes, the attempt manifest, report, and pre-index inventory are sealed first;
- the self-excluding index is written as the final G8 mutation by an external terminal action;
- index-builder and verification results are written outside G8;
- G8 is never mutated after index creation.

## Complete replacement prompt

Send this prompt to the **same write-enabled Capability implementation conversation**:

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Capability_Final_Repair_Complete_Validation_Replay_V3_Restore_Harness_Fixed_Prompt.txt

Size:
29,965 bytes

SHA-256:
a344413e57ffa8e406474b10f4e2b70722045c5b57efd7816d8abd217b18e806
```

The prompt is a **complete replacement**, not a delta to be combined with earlier replay prompts.

It creates:

```text
/private/tmp/g8.XXXXXX
```

and requires:

```text
Selected causal:                 16 passed
Capability boundaries:           32 passed
Capability complete:             69 passed
B1/Wire compatibility:          461 passed
Architecture/status/static:     907 passed

Live collection:              5,072 nodes
Clean collection:             5,072 nodes

Live full suite:             5,072 / 5,072
Clean full suite:            5,072 / 5,072

B/C candidate tree:
0fcf6680ded68d66f62b75b5dc842d69b343a334
```

The complete operative Codex response must be printed **inline in chat**. `/private/tmp` evidence paths may be listed only as supplementary provenance.

The required success token remains:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

Only after a complete G8 success report should another fresh independent audit begin. The commit gate remains blocked.

**Source:** Codex’s inline G7 attempt-0130 diagnostic supplied in this turn.  
**Confidence:** Very high that the candidate and mutant behavior are correct; very high that the failure was caused solely by the replay harness’s obsolete fingerprint schema; high that a fresh G8 replay with the corrected restoration contract is the proper continuation.
