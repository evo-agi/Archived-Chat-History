PROMPT_ID

RW0_B2_CAPABILITY_FRESH_INDEPENDENT_AUDIT_V1

TITLE

Coordinator RW0-B2-Capability — fresh independent audit of the exact private
declaration, supplied-observation, and qualification candidate

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated independent audit.

This engagement verifies exact patch identity before correctness inspection,
audits authority and semantic boundaries from independent perspectives,
performs bounded external probes and isolated validation, and returns one
verdict without repairing the candidate.

No repository mutation, formatting, cleanup of repository bytes, dependency
installation, staging, commit, push, PR, merge, tag, release, deployment,
remote/network/service/provider/host contact, worker/model invocation,
database mutation, migration, or supporting-repository inspection is
authorized.

Do not use the implementation conversation. Use this fresh read-only
conversation only.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED LIVE IDENTITY

Require at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
20 paths
14 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate path modes:
all regular 0644
```

Require no Git operation or lock. Do not fetch.

IMPLEMENTATION EVIDENCE ROOT

```text
/private/tmp/ge-coordinator-rw0-b2-capability-g9JtFA
```

Named evidence includes:

```text
final_provenance_001_manifest.json
validation_summary.json
node_delta.json
```

The implementation report states that the root is operator-owned, mode 0700,
and non-symlink.

Before correctness inspection:

1. `lstat` every component of the evidence-root path;
2. require no symlink traversal;
3. inventory every retained evidence entry by relative path, type, owner, mode,
   size, and SHA-256;
4. do not modify that evidence root;
5. preserve any missing, inconsistent, or unsafe evidence as an explicit
   limitation or provenance failure according to materiality.

CANONICAL PATCH IDENTITY

Expected recipe:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

source size:
3945 bytes

source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Expected final target:

```text
canonical manifest size:
4291 bytes

canonical manifest SHA-256:
41a256e52bf5b3e677ec88736889230be416005da429bf5cb3339c92d9427c76

tracked textual-diff SHA-256:
e81ef0ba3e3238a7e6ec428c519f3259bebb6da79cbef318a7045edb45656f5f

complete recipe stdout size:
4524 bytes

complete recipe stdout SHA-256:
8d8ff431ae0aa0362b4d298e5261ba866ca9f7eeae18a3e2f93bb33d233b088b

file count:
20
```

The implementation report did not print the final complete-output identity.
The expected 4524-byte output and SHA-256 above are deterministically
reconstructed from the exact recipe source and reported canonical manifest.
Confirm them mechanically. Treat the report omission as a reporting issue, not
a provenance mismatch, if the live recipe reproduces the exact target.

Exact canonical manifest:

```json
{"branch":"codex/rw0-b2-capability-semantics-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/authority-boundaries.md","sha256":"6a3bf0bbb68b121206f815246c7d0c7acb4368239a9f9c72a766794b08f58e3c","size":32486},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/autonomous-software-development-operating-model.md","sha256":"8df2b88cd86019de4e6312f9178a1b8391881a6d0a6e7ec39632ce790e1216bb","size":34484},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/durable-state-model.md","sha256":"a14d10810847d77cbb58cf724b1861ed2f612255a1351033cfdb7c2a3e3155aa","size":37671},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-b1-pure-phase-values.md","sha256":"cec48373ec6b85d9fb84b0b0f384a8f3a528808d6d5205a33698c3442766b1c5","size":27228},{"file_type":"regular","kind":"untracked","mode":"0644","path":".docs/rw0-b2-capability.md","sha256":"1629c2015ed1cc651ed82d1302b5e41c5ac5b217ab86a307016df1b7535592be","size":13378},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-b2-wire-protocol.md","sha256":"7505e578393d448e677b8d05a74257ff33362e99df2e12539edc89099434082e","size":16566},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-remote-worker-contact-phase-entry.md","sha256":"d3189084312bbf710c526cb2bccfae008c2a356ae23375c94754db7238e4f993","size":50209},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/worker-execution-boundary.md","sha256":"d1882845e1f8e6d5b8f9b33620545fabb42f6213882b733b0643f87222f9e5b9","size":28735},{"file_type":"regular","kind":"untracked","mode":"0644","path":"src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py","sha256":"0e15e545620f90470ed5d8d852fcec1c8c12fa705b22cc93406b2250a16ac0d0","size":34844},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_architecture_contracts.py","sha256":"cfa79cb15e70d98cd811575c0077be1320e0fe37a9662d95482294e7f0eac740","size":99705},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_c2a_nonimplementation.py","sha256":"651a50b07cddf226425723f73d0496d477ea7e45bdae5b620bb066b61863c402","size":27068},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_runtime_non_authority.py","sha256":"9636dd003e358d178e6d6316b16dbff7ece944ae64f7bf0a3f3080b6be297755","size":41310},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b1_boundaries.py","sha256":"f921fc6e8010d2fec5ed2e254935288e49ed758d639e80dcb6b836abfd19df1e","size":8086},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_boundaries.py","sha256":"b49dab823265ed8bb4b1b5b3ee707767d67afd205d52a6827ecf5510c43a2cd4","size":13644},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_relations.py","sha256":"96e88e658d1ea6b5260d6ab81828fdcf35f275fd8399da56e299a557d0eaaf49","size":24843},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_values.py","sha256":"3baeafb6db862b65939a3395015d37f86983cbc99959855f523bb921baad763a","size":23091},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_vectors.py","sha256":"4aa4432b3e042e72f4a0d131a696a842f1a2ac1e3473f8bc04ad8fb90219f7f3","size":16104},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b2_wire_boundaries.py","sha256":"d336e59d4ff736df5986105a4af58a46c07b3399b38af50967b55823157ba54b","size":28611},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_remote_contact_phase_entry_contract.py","sha256":"b025563a6619c3ffa591035e577968dee3a9a75c480d9d28e024e22f5e662c07","size":108079},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_software_development_progression_boundary.py","sha256":"ffe8ae9af76eef5f091691ba6e8930b6c59b4d11ed5b59733407cb1f3965cb13","size":42680}],"head":"deec37bf08fb903d8846aa2c3232aec52fa9866e","recipe_id":"governed-execution.audit-patch-manifest.v1","textual_diff_sha256":"e81ef0ba3e3238a7e6ec428c519f3259bebb6da79cbef318a7045edb45656f5f","upstream":"origin/trunk_dev"}
```

EXACT RECIPE SOURCE

Decode the following base64 only beneath the new external audit root, require
3945 bytes and the expected SHA-256, and retain it mode 0400:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

The historical recipe sink is outside the repository. If it already exists,
record its complete pre-audit filesystem identity and bytes, then execute the
exact source unchanged with an external wrapper that redirects only the exact
`Path.write_bytes` sink to unique audit-root files. Restore and verify the
pre-existing sink exactly before closeout.

PROVENANCE GATE

Before spawning audit tasks or inspecting correctness:

1. create one new operator-owned, non-symlink, mode-0700 audit root under
   `/private/tmp`;
2. verify repository identity and exact 20-path topology;
3. verify every path in the canonical manifest by classification, regular-file
   type, mode, size, and SHA-256;
4. verify no twenty-first tracked or untracked path exists;
5. verify zero staged/unmerged paths and clean `git diff --check`;
6. verify exact recipe source bytes;
7. run the recipe twice;
8. require both manifests and both complete outputs byte-identical to the
   canonical target above;
9. verify every path outside the 20-path set equals HEAD;
10. verify protected B1, Wire, C2A, package, dependency, migration, schema,
    `StateStore`, and `WriterSession` surfaces remain at HEAD.

On any mismatch, stop before correctness inspection and return exactly:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not repair, normalize, or regenerate an alternative target.

AUDIT TASKS

After the provenance gate, use exactly four bounded, read-only audit
perspectives when available. No nested delegation. Subagents do not run tests
or mutate anything. Give every perspective the exact canonical manifest,
objective, accepted ownership split, and its bounded scope.

1. Contract, authority, and documentation auditor
   - declaration, observation, and qualification authorship;
   - structural non-collapse versus source authentication;
   - no permission, acceptance, persistence, contact, or runtime authority;
   - RW0-C/D/E/ES ownership;
   - provider/mechanism neutrality;
   - B1/Wire owner-document wording;
   - unique visible Capability owner and five synchronized status projections;
   - stale Capability-unimplemented prose;
   - current-contract versus strategic-target classification.

2. Values, reconstruction, privacy, and hostile-work auditor
   - exact fields, schemas, domains, constructor matrix, identity bytes;
   - ordinary construction, slots, immutability, attributes, equality,
     copying, pickling, repr/str, and hashability;
   - non-recursive safe reconstruction for every public method and readable
     field attribute;
   - incomplete, tampered, and correctly resealed invalid instances;
   - mapping closure, key bounds, unknown/privacy/missing precedence;
   - safe refs, IPv4-shaped refs, timestamps, freshness, privacy fragments;
   - exception cause/context/traceback-local payload hygiene;
   - exact construction, reconstruction, equality, relation-local, and
     composed work accounting;
   - cycles, shared DAGs, repeated aliases, and work outside the meter;
   - import-time fixed Wire-owner loader and manifest non-retention.

3. B1/Wire composition and qualification auditor
   - exact fixed Wire ref/digest;
   - exact worker artifact and worker protocol pair matrix;
   - one and only one B1 `validate_host_qualification` call;
   - bare-qualified false-positive resistance;
   - B1 exception sanitization;
   - complete subject-coordinate binding;
   - exact twelve-reason precedence and result/reason matrix;
   - relation use of reconstructed Capability locals only;
   - observation/declaration identity, self-observation, freshness,
     artifact/profile mismatch, unsupported/contradicted/unknown ordering;
   - no source authenticity or executable-authority inference.

4. Tests, public boundary, status, evidence, and provenance auditor
   - literal test-owned vectors, fields, schemas, digest domains, and reason
     oracle independent of production constants;
   - causal selective and class-wide reconstruction bypass mutants;
   - work-budget and one-under mutants;
   - owner-marker, fencing, sibling, relocation, duplicate, split/reversed,
     and trailing-prose mutants;
   - node ownership and no existing-node drift;
   - exact imports, empty `__all__`, no package export, no production caller,
     no I/O/process/network/provider/row/SQLite dependency;
   - exact 20-path ceiling and protected 21st-path controls;
   - implementation evidence integrity;
   - the two full-suite attempts and umask handling;
   - provenance completeness and report omissions.

Every material finding must use:

```text
ID
type
severity: critical | high | medium | low | observation
current contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect or pre-existing issue
```

Preserve minority findings and disagreements.

REQUIRED INSPECTION

Inspect every changed/new path and, together with them, the owning protected
sources necessary to establish composition:

Changed/new source and owner:

```text
.docs/rw0-b2-capability.md
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
```

Changed status/ownership documents:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
```

New direct tests:

```text
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py
```

Changed existing tests:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
```

Protected semantic owners:

```text
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
```

Protected public/configuration boundaries:

```text
src/ge_nwp_coordinator/__init__.py
pyproject.toml
tests/test_c2b2_development_row_value_boundaries.py
tests/test_b2a_writer_session_contract.py
tests/test_codex_agent_config.py
tests/c2a_contract_support.py
```

Inspect additional files only when a concrete import, status assertion, or
owner relation makes them necessary. Record each addition and why. Do not
inspect another repository.

ACCEPTED CAPABILITY CONTRACT

Audit against these accepted facts:

- Three values only:
  - `RW0WorkerMechanismCapabilityDeclarationV1`
  - `RW0WorkerMechanismCapabilityObservationV1`
  - `RW0WorkerMechanismCapabilityQualificationV1`
- Sealed `RW0WorkerMechanismCapabilityError`.
- Fourteen fixed provider/mechanism-neutral dimensions.
- Declaration dimensions:
  `supported | unsupported | unknown`.
- Observation dimensions:
  `confirmed | contradicted | unknown`.
- Qualification result:
  `qualified | blocked | unknown`.
- Fixed Wire pair:
  - `rw0-wire-nwpf-v1`
  - `470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454`
- No competing Capability profile.
- Complete B1 host relation is the semantic owner of phase/effect/authority/
  readiness/host qualification.
- Capability adds no authentication, permission, acceptance, persistence,
  contact, process proof, runtime authority, provider selection, credential,
  session, endpoint, or private material.
- Concrete mechanics remain RW0-D/E; durable membership remains RW0-C; ES
  retains route runtime authority.

HIGH-RISK AUDIT HYPOTHESES

Do not treat passing tests or the implementation report as closure. Challenge
at least the following.

### A. Safe reconstruction and public methods

- Every public semantic method and readable declared field attribute must
  safely reconstruct before returning data.
- No method may call another public semantic method recursively.
- Exact-class equality must safely reconstruct both values.
- Incomplete `object.__new__` instances, missing/wrong `_values`, wrong tuple
  length, nested hostile members, bad enums/refs/digests/times, stale windows,
  invalid result/reason pairs, bad self-digests, and correctly resealed
  semantically invalid tuples must fail before semantic use.
- No semantic relation may read the original Capability objects after
  reconstruction.
- A selective or class-wide reconstruction bypass must be killed causally.

### B. Work accounting and availability

Independently derive and verify:

```text
from_mapping:
48 / 62 / 52

safe reconstruction:
72 / 93 / 78

same-class equality:
144 / 186 / 156

Capability-local relation:
249

B1 owner relation:
241

composed sum:
490
```

Check maximum-valid and one-under cases. Verify no attacker-controlled key scan,
member walk, canonicalization, digest operation, exception translation, public
attribute path, alias expansion, or foreign reconstruction occurs outside all
enforced bounds.

### C. Mapping, privacy, and errors

Verify exact precedence:

1. outer type;
2. O(1) cardinality cap;
3. key type;
4. key length `1..39`;
5. ASCII;
6. accepted-field recognition;
7. privacy-bearing unknown;
8. ordinary unknown;
9. missing field.

Check insertion-order independence and accepted names containing `stdout`,
`stderr`, `credential`, or `session`.

Verify public errors expose no supplied field/value, cause, context, foreign
exception, traceback-local sentinel, or hostile payload.

### D. Fixed Wire owner seam

Verify:

- `wire_profile_mapping()` is called exactly once during module import;
- exact outer mapping and ordered keys are checked;
- only `_WIRE_PROFILE_REF` and `_WIRE_PROFILE_DIGEST` survive;
- the 4,021-byte manifest is not copied, traversed, retained, or exposed;
- no caller input can substitute another profile pair;
- post-import monkeypatch cannot alter the retained pair;
- malformed owner output produces only the fixed import-time invariant error,
  outside any foreign handler;
- Wire source/profile bytes remain unchanged.

### E. B1 composition and qualification

Verify the relation:

- safely reconstructs all three Capability values first;
- exact-type/time-checks five B1/C2A objects plus `now_utc`;
- invokes B1 exactly once with the full six-object ledger;
- translates invalid B1 graphs to `relation_mismatch`;
- rejects unrelated declaration/observation qualification subjects as relation
  errors before stored-reason evaluation;
- computes exactly one expected result/reason in the frozen order;
- rejects a stored pair that differs from expected;
- cannot accept a bare B1 `qualified` record over invalid supplied facts.

Independently reimplement the expected-result function in the audit probe.

### F. Authority and status

Verify:

- source-ref inequality is described only as structural non-collapse;
- no claim authenticates observer independence;
- dimensions do not select CLI, App Server, provider, route, account, model, or
  transport;
- numeric process limits remain D/E-owned;
- no source or result grants permission or acceptance;
- Capability owner/status blocks are visible, unique, unfenced, correctly
  ranged, normalized-identical where required, and do not steal Wire or B1
  ownership;
- stale “Capability unimplemented” prose is absent only where it was live
  current status, not historical evidence.

INDEPENDENT EXTERNAL PROBES

The parent must create read-only, external probes under the audit root without
editing repository files.

At minimum probe:

1. incomplete and tampered instances through every public method, attribute,
   equality, and relation;
2. correctly resealed invalid enum/ref/digest/time/result-reason tuples;
3. selective and class-wide `_safe_reconstruct_impl` bypasses;
4. exception cause/context and traceback-local sentinel reachability;
5. key-cardinality and all key-precedence overlaps in both insertion orders;
6. exact work maxima and one-under limits;
7. shared aliases, active cycles, and hostile nested values;
8. exact-once B1 call and bare-qualified invalid-graph control;
9. every qualification precedence pair, changing one predicate at a time and
   resealing only the owning value;
10. isolated module import with malformed Wire owner outputs;
11. post-import Wire-function replacement;
12. retained globals proving no manifest retention;
13. AST/import/public-caller checks independent of checked-in inventories;
14. owner/status Markdown mutants through the complete authoritative oracles,
    not only path-local helpers.

Do not credit a mutant that changes multiple predicates unless the test
explicitly proves the intended predicate is the cause.

IMPLEMENTATION EVIDENCE REVIEW

Review and classify every formal implementation attempt, including:

- missing-module causal-red collection;
- development failures in values and boundaries;
- all final focused gates;
- full-suite attempt 001 under caller/child umask `077/077`;
- the affected filesystem-security rerun under `022/022`;
- full-suite attempt 002 under `022/022`;
- final guards and provenance.

The implementation prompt allowed at most one second full-suite attempt after a
failure, but described it in terms of an in-scope patch repair. Here no
repository repair occurred; the rerun corrected the test environment. Determine
whether this is:

- a non-blocking orchestration deviation superseded by independent validation;
- an evidence limitation;
- or a material procedural defect.

Do not classify the first suite's filesystem-security result as a production
candidate failure without establishing that conclusion from the owning test and
umask semantics.

NODE IDENTITY

Run one candidate collection and one clean external `git archive HEAD`
collection under identical isolated conditions.

Require:

```text
candidate:
4676 unique nodes

clean HEAD:
4655 unique nodes

intersection:
4655

candidate-only:
21

HEAD-only:
0

candidate ordered-list SHA-256:
f8fe844c0b8da21b99ccedb3cc22075f85c144e9420c6d040504a9859680e26c

HEAD/opening ordered-list SHA-256:
f36822a60056ec3d110956de561202b737662c9d22cd0dd82c4cdad6c7cef69f
```

Every HEAD node must retain its order. Every candidate-only node must belong
only to:

```text
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py
```

Expected split:

```text
values:     6
vectors:    3
relations:  5
boundaries: 7
```

No existing test file may add, remove, rename, skip, xfail, collapse,
reparameterize, or reorder a node.

INDEPENDENT VALIDATION

Only after source, documentation, and external probes are green enough to
justify validation, run serially under one new external mode-0700 audit root.

For every pytest child use:

```text
umask 022 before launch
child must observe numerical 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Require stable repository fingerprints before and after every run.

Run:

1. each Capability file individually:
   - values: 6
   - vectors: 3
   - relations: 5
   - boundaries: 7
2. all Capability files: 21
3. B1 compatibility: 281
4. Wire compatibility: 89
5. C2A compatibility: 637
6. static/public compatibility: 124
7. status/document contracts: 878

Use the exact target lists from the implementation report and changed tests.

Every credited run must have:

- return code 0;
- exact expected count;
- zero failures/errors/skips/xfails/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate or unmapped cases;
- unchanged candidate fingerprint.

If source/probe inspection remains green, run the complete suite exactly once:

```text
4676 collected
4676 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

If a deterministic material blocker is found first, the independent full suite
may be withheld; state that explicitly. Do not repair or rerun candidate bytes.

PUBLIC AND AUTHORITY BOUNDARY

Require:

- Capability imports only the frozen standard-library set, `EffectFenceV1`,
  exact B1 classes/relation/error, and `wire_profile_mapping`;
- no B1 or Wire reverse import;
- no package-root export;
- no production caller;
- empty `__all__`;
- no dependency, package, schema, migration, SQL, `StateStore`, or
  `WriterSession` change;
- no filesystem, process, network, provider, dynamic-import, SQLite, row-value,
  Bridge, ES-call, Git, publication, or runtime effect;
- no private material retained;
- all protected paths byte-identical to HEAD.

CLOSEOUT PROVENANCE

After removing only audit-created transient files and restoring any pre-existing
historical recipe sink exactly:

1. rerun the exact recipe twice;
2. require both outputs byte-identical to the opening canonical target;
3. require the same exact 20 paths, classifications, modes, sizes, hashes,
   textual-diff digest, manifest digest, and complete-output digest;
4. require no staged/unmerged paths, operation, lock, or repository residue;
5. verify the implementation evidence root is unchanged;
6. retain all audit evidence under the new mode-0700 audit root, with retained
   files regular, operator-owned, mode 0400;
7. create an evidence index that does not index itself.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low candidate defect remains.
- `BLOCK` for a repairable candidate contract, correctness, security, privacy,
  test, documentation, or procedural defect.
- `REJECT` only for a fundamental architecture/authority contradiction that
  cannot be repaired within the accepted tranche.
- `AUDIT_PROVENANCE_MISMATCH` only for target/evidence identity failure before
  correctness judgment.

If `ACCEPT`, also return:

```text
COORDINATOR_RW0_B2_CAPABILITY_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or open a PR.

FINAL REPORT

Include:

1. opening and closing repository identity;
2. recipe, canonical manifest, complete-output, and per-file provenance;
3. exact implementation-evidence inventory and limitations;
4. four audit-perspective reports and reconciliation;
5. severity-ranked finding ledger;
6. exact class/schema/field/vector assessment;
7. safe-reconstruction and error-boundary assessment;
8. work-budget and hostile-graph assessment;
9. Wire-owner seam assessment;
10. B1 composition and reason-precedence assessment;
11. authority/privacy/later-owner assessment;
12. owner/status Markdown assessment;
13. tests and causal-mutant assessment;
14. node comparison;
15. independent validation;
16. public/import/protected-byte assessment;
17. closing guards;
18. separate provenance, validation, and implementation-confidence statements.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
```
