Here is Codex's response:

`COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT`

## Outcome

The fresh G8 replay completed successfully. G8 is the authoritative complete validation and closeout envelope for the exact current 30-path candidate.

The source repository remained byte-, mode-, logical-index-, ref-, object-graph-, and topology-stable. No source-repository or supporting-repository mutation occurred.

A transparent tooling note: manifest sequences 8, 9, and 11 were sealed as non-creditable pre-validation tooling failures. Their credited recoveries are sequences 10, 12, and 13. No candidate validation or external candidate repository existed before those recoveries. The live and clean full suites each ran exactly once without retry.

## Opening and closing identity

- Repository: `/Users/ds/Repositories/Governed Execution Coordinator`
- Branch: `codex/rw0-b2-capability-semantics-v1`
- HEAD: `deec37bf08fb903d8846aa2c3232aec52fa9866e`
- HEAD tree: `ef48f5bd11244c6f703c97abb5489d19956f7a77`
- Sole parent: `02450d3c99faf0fe7b299b914afaed312421bc8b`
- Subject: `feat: implement RW0-B2 Wire protocol (#4)`
- Upstream: `origin/trunk_dev`
- Ahead/behind: `0/0`
- Worktrees: `1`
- Candidate topology: 30 paths: 24 tracked modifications, 6 untracked additions, 0 staged, 0 unmerged
- Every candidate path: regular file, mode `0644`
- Candidate tree: `0fcf6680ded68d66f62b75b5dc842d69b343a334`
- `git diff --check`: clean
- Cached diff: empty
- Git operations/locks: none
- Repository residue: none
- Candidate symlink/special paths: none
- Thirty-first changed path: absent

Normalized authoritative source fingerprint:

- Schema: `governed-execution.normalized-authoritative-git-fingerprint.v1`
- Opening/closing size: 1,421,607 bytes
- Opening/closing SHA-256: `0ff46a4afaaecb079573c0fb32e2d1103bd55fa1e791ad4e01035992f65ca6dc`
- Equality: exact

Logical source index:

- `git ls-files --stage -z`
- Size: 19,139 bytes
- Opening/closing SHA-256: `8f170467abeba2d935a917de2e057eb75635efc555f5a44bfb6cb9c77934c019`
- Equality: exact

Report-only raw source index:

- Size: 22,476 bytes
- SHA-256: `7926e411fe75047992b7677548c8a40d090127ce6dbda64c4262d59ca749c213`
- Opening/closing bytes: equal

Ambient observations:

- App-managed turn-diff refs added/removed/changed: `0/0/0`
- Object-storage paths added/removed/changed: `0/0/0`
- App-managed refs and storage timestamps are report-only.

## Historical evidence classification

- Historical G5 partial metadata was not reconstructed.
- G5 remains implementation evidence.
- G6 and G7 remain failed replay evidence.
- G8 is the authoritative complete validation and closeout envelope.

G6 remains a historical failed replay: both 5,072-test suites completed, but closeout stopped because its historical comparison wrapper used inconsistent directory-size schemas. Cleanup never ran, attempt 0183 remained incomplete, and no authoritative final report/index was produced.

G7 remains a historical failed replay: controls, causal sealing, closed-call/protected mutants, and A/B/C completed. Attempt 0129 correctly rejected the regular-to-symlink mutant. Attempt 0130 restored exact target bytes and mode, then raised `KeyError: 'index'` from the obsolete `baseline.pop("index")`. Focused groups and later phases never started.

Pre-existing indexes and canonical opening/closing projections:

| RootIndex rows / bytes / SHA-256Canonical projection                                |                                                                                        |                                                                                                                                                                                   |
| ----------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `/private/tmp/g5.hiLE2y`                                                            | 7,234 / 1,583,837 / `199af9ac4299cc41a4434d44f1b1f7bcaf3265490b7417e174ad5d48723f8fcc` | 7,233 rows, 1,829,724 bytes, `188b9c784e86993a091384f9c7cde1efe6d75a2be612542ac3d6e0a31bb99a3e`; opening=closing; historical file-only index, so strict typed-tree match is false |
| `/private/tmp/g4.S4uFyK`                                                            | 72 / 12,958 / `f4836712bfc0e55dda2bb489401dabc55958016fc3c1778f8ad40a33bc5cb5b9`       | 72 rows, 15,498 bytes, `b16087e56816a881c3cf28bae93c813a577975ee2ca72781f90937dcb808bbc8`; strict match                                                                           |
| `/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe`         | 938 / 151,566 / `bdffdfd9757302a7940b803f0d5138fdf9f9b41e53d95fcae3209b0e35dae71d`     | 972 rows, 249,732 bytes, `9a1a04d45d5a1b0adc7d47fa6e17a4878741562c290833b97bd0f431e12bf9cb`; strict match                                                                         |
| `/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset2.Udjr4a` | 107 / 21,875 / `a3abd5e9252da88623ab3285a6f560b7b71f151f672d25f6236c3779f806abe9`      | 108 rows, 25,969 bytes, `b50eadf3fc2dcfbfe58eb297eccee951d1857fbd2c0d225b6061878b8f2594e7`; historical root-directory omission                                                    |
| `/private/tmp/gv3.efmQ8X`                                                           | 87 / 15,821 / `cec6aba32a0243bf2b0b48d147df96ccb2b50ec5b9ec161dc1cc1c0d4f30eee1`       | 88 rows, 19,114 bytes, `b758972b0238e1e6814848b87b154f584dc80c18510f43cfa82692d93ff975d8`; historical root-directory omission                                                     |
| `/private/tmp/g6diag.yF2Vcy`                                                        | 21 / 3,598 / `88f7e186f6fa515d56d3ecbeb7d9239f31042b4defcbfce4d9c49da00b554094`        | 21 rows, 5,013 bytes, `f4184458fb8d6249cead90c2e34c808c763725afbe214b2a3f40461906edca31`; strict match                                                                            |

The common canonical schema was:
```
relative_path
type
owner_uid
owner_gid
mode
regular_file_size_or_null
regular_file_sha256_or_null
```

Directory size/hash were always null; rows were UTF-8 byte-sorted; the self-index was excluded.

### Failed-root quarantine proofs

G6:

- 34 unique basetemp roots, derived only from retained launched pytest argv
- 23,119 inventory rows
- Inventory size: 8,429,688 bytes
- Inventory SHA-256: `dceccfcf6d07c1fc217b7f309e622a9caa8612674c819398e840d2b3b065b81d`
- Retained projection: 5,954 rows
- Projection SHA-256: `d29952e1bb4404c3c6c547fb1c52b9dd9a091bab80af123c0d04ea3b1fa2819b`
- Unsafe entries: 1,152 symlinks and 12 FIFOs; every other unsafe type zero
- Unsafe entries outside quarantine: zero
- Mandatory-record overlap: zero
- Opening/closing inventories: exact
- G6 modified: false

G7:

- 20 unique basetemp roots
- 706 inventory rows
- Inventory size: 279,200 bytes
- Inventory SHA-256: `c40df656b10707b4f12b6704eb2012bf1733fea53bcdddd734024f3917d8aa32`
- Retained projection: 5,640 rows
- Projection SHA-256: `fa4c30c844925071aae9be12cf103af188b3c98fb062645f72fc5fc15716f005`
- Unsafe entries: 14 symlinks; every other unsafe type zero
- Unsafe entries outside quarantine: zero
- Mandatory-record overlap: zero
- Opening/closing inventories: exact
- G7 modified: false

## Bootstrap, recorder, and restore harness

The bootstrap is sequence 1. Recorder self-tests covered success, expected nonzero, preflight refusal/not-launched, zero-byte stdout/stderr, and JUnit-not-applicable behavior.

The three pre-validation recoveries were:

- Sequence 8: no child launched because the full candidate fingerprint manifest had not yet been extracted.
- Sequence 9: the initial recovery source failed compilation before replacing `replay.py`.
- Sequence 11: the owning path checker correctly rejected `restore_harness.py` because its conservative grammar matched `store`.
- Sequence 10 installed normalized light-source fingerprinting.
- Sequence 12 installed the neutral child-visible `h.py` alias.
- Sequence 13 reran the same owning path checker successfully.

The retained static audit was GREEN:

- Forbidden normalized-fingerprint accesses using top-level literal `index`: `[]`
- Explicit `logical_index_ls_files_stage_z`: true
- Raw physical-index data report-only: true
- Direct normalized equality: true
- Target restoration verified before post-restore Git comparison: true

All seven restore-harness tooling cases passed:

- regular → symlink → exact regular
- regular → missing → exact regular
- wrong mode → exact mode
- changed content → exact content
- raw index stat-cache refresh with unchanged logical index
- synthetic normalized value lacking a top-level `index`
- negative logical-index mismatch rejection

The negative diagnostic was finite:
```
logical_index_mismatch:94718e0e289d3150926bebb2c52e21011fd72c0eb8f5a387715600e551b51724:6ba2d71c029fc43615c0b1d11e4df98c06ecdbdc1b6b3ac998a4ded2822a583a
```

Every positive self-test applied its mutant, observed the expected predicate, restored the target exactly, and recovered normalized and logical-index equality. Raw index bytes were permitted to differ and were report-only.

## Exact target and recipe binding

- Final manifest source: `/private/tmp/g5.hiLE2y/final/expected_manifest.json`
- Manifest size: 6,430 bytes
- Manifest SHA-256: `d6f86248da0c4843e20b91cb443f960596e483e08a8f2cff716bbcea4fb553d8`
- Tracked textual-diff SHA-256: `cc91155aff703e1c54c139820f841d98135f37ee7c87a71d3b00b07a2672e2a6`
- Exact recipe source: `/private/tmp/g5.hiLE2y/exact_recipe_source.py`
- Recipe source size: 3,945 bytes
- Recipe source SHA-256: `db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`
- Complete recipe output: `/private/tmp/g5.hiLE2y/final_recipe_1/o`
- Output size: 6,663 bytes
- Output SHA-256: `400a5d35fcd18ba6b95c375194719d1bb97796ba61cfcb416ac09b575c6a9bb3`

Both opening recipe runs and both final recipe runs reproduced the manifest and complete output exactly with empty stderr.

The sole G5-opening-to-final changed candidate path was:
```
tests/test_rw0_b2_capability_boundaries.py
opening: 28,469 bytes
opening SHA-256: d5582ea702ee445083c3457188b35b302e5ade52db119c1e2808a6fea5a1f022
final: 76,858 bytes
final SHA-256: eb6ca3cd19b4bd723b82002aa93e7b5743ef02b768ac169d96e0011582e61977
```

The other 29 candidate paths were identical to G5 opening; every path outside the candidate equalled HEAD.

## Causal replay

All 16 exact selected nodes passed:
```
tests/test_rw0_b2_capability_boundaries.py::test_closed_reachable_call_surface_and_mutation_matrix
tests/test_rw0_b2_capability_boundaries.py::test_exact_twenty_path_ceiling_modes_and_protected_controls
tests/test_rw0_b2_capability_boundaries.py::test_every_protected_content_row_is_causally_mutation_sensitive[P01]
tests/test_rw0_b2_capability_boundaries.py::test_every_protected_content_row_is_causally_mutation_sensitive[P02]
tests/test_rw0_b2_capability_boundaries.py::test_every_protected_content_row_is_causally_mutation_sensitive[P03]
tests/test_rw0_b2_capability_boundaries.py::test_every_protected_content_row_is_causally_mutation_sensitive[P04]
tests/test_rw0_b2_capability_boundaries.py::test_every_protected_content_row_is_causally_mutation_sensitive[P05]
tests/test_rw0_b2_capability_boundaries.py::test_every_protected_content_row_is_causally_mutation_sensitive[P06]
tests/test_rw0_b2_capability_boundaries.py::test_every_protected_content_row_is_causally_mutation_sensitive[P07]
tests/test_rw0_b2_capability_boundaries.py::test_every_protected_content_row_is_causally_mutation_sensitive[P08]
tests/test_rw0_b2_capability_boundaries.py::test_every_protected_content_row_is_causally_mutation_sensitive[P09]
tests/test_rw0_b2_capability_boundaries.py::test_every_protected_content_row_is_causally_mutation_sensitive[P10]
tests/test_rw0_b2_capability_boundaries.py::test_every_protected_content_row_is_causally_mutation_sensitive[P11]
tests/test_rw0_b2_capability_boundaries.py::test_every_protected_content_row_is_causally_mutation_sensitive[P12]
tests/test_rw0_b2_capability_boundaries.py::test_every_protected_content_row_is_causally_mutation_sensitive[P13]
tests/test_rw0_b2_capability_boundaries.py::test_exact_audit_protected_assertion_weakening_is_killed
```

Closed reachable-call inventory:
```
[
  ["test_exact_twenty_path_ceiling_modes_and_protected_controls",
   ["builtins.len","builtins.set","builtins.tuple","builtins.zip"]],
  ["_stable_capability_boundary_projection",
   ["builtins.len","builtins.set","builtins.sorted","builtins.tuple",
    "hashlib.HASH.hexdigest","hashlib.sha256","list.append",
    "pathlib.Path.lstat","stat.S_IMODE","stat.S_ISLNK","stat.S_ISREG",
    "str.encode","str.join"]],
  ["_protected_content_row",
   ["builtins.len","hashlib.HASH.hexdigest","hashlib.sha256",
    "pathlib.Path.lstat","pathlib.Path.read_bytes","stat.S_ISLNK",
    "stat.S_ISREG"]]
]
```

Runtime-global and source diagnostics were empty.

All 26 closed-call mutants were individually killed. Exact case/source hashes:
```
direct_subprocess                 072e227abf1eb5cbe858d3aca6c03e633d8b3bc3eeb8a34350b356543290e3e8 KILLED
constructed_argv                  7343b0c2eedecca67cd03da202535f03c80f01d0af9121591dd699e1f798ee7d KILLED
module_prebuilt_argv              6ce6e5c5fdf55d36fa33083823f337dcf2dedbcd92aefc0f2aa007df7728f86f KILLED
shell_string                      3e959414ae43fc88ba1164c6217531e269f176d7a55a88b63157263db1421524 KILLED
concatenated_shell                63f0c60f65c678e89ab0687cd2b77ab2052191d46346133e0e776bad87411baa KILLED
imported_callable_alias           a26e3734abeff394dfbcc47b4d697962889f1d1f1deb92b767db0f8f7a89fe8e KILLED
module_alias_attribute            2e9bb469679de6e50941791bddca1d12cc08fc8b0e2242efce6b6ff0121770e8 KILLED
nested_attribute_alias            9df93562841d73789d107064707aa9c44879b3a0f38a64c45a01cb616b335801 KILLED
getattr_dispatch                  56cbaa7a16dc2ef98f502b56978481357a8993abc48ad276d35799f676c8bc90 KILLED
wrapper_prebuilt_argv             92b60559a92a132bf780c74892ddee704ff0e04482a7ee2cf29c619c69bfd0f5 KILLED
callable_default                  158948cdbec9cb500596844d9c629f2b622ef2fae6bc2ae27ff27326609c1927 KILLED
callable_closure                  673926ffffb751564c294cedadd8f8483beff37775c44439eb0983e0fd3c8504 KILLED
module_global_callable            5e44e1ae7ebd3901c87963cadbe007a98bffd414b7f2f5d6509064827d9408d6 KILLED
unknown_local_helper              5621406767adf082438189de646028a56611073fbede25b77d3da54e4f077e2b KILLED
dynamic_import                    32c22e4b598fb79b18c536a8fdfc3b9a3ecc4677dc960ac1b21de5ff830cdd64 KILLED
gitpython_status                  21fc3b260e1a76faefca3fdf36e23e7897bce85d5cf3b2ad174649574bfc062f KILLED
dulwich_status                    802cf051a0d096293f9f0da25601a8a3ab4036f4858419614c6067a5c8e03029 KILLED
subprocess_popen                  71e32d82b7687e877c419ffb659f1d6368cfc377803f9e7f56ddb266683c2941 KILLED
subprocess_check_call             e6ba7c01c59465d6ea33775d33611c1400870168191f9ac5f34ceff49726d2f6 KILLED
subprocess_check_output           d8308a54b38e8354bbe4a827575a25687f56b6a8bd7cca40a480c1f7b7619889 KILLED
subprocess_call                   2b690cf19ce2f1406bb6f89cda51647f0610da9d876350e66dee30d591d10535 KILLED
os_system                         aad8c1b9eeac3be67d3c057fca3c8aecf0ce7d493e1828e0325cc0633462c885 KILLED
os_popen                          97ad7de972906487ba52f6a705ef3f10e6c173e02873ad7abe085612eb43ed1a KILLED
os_spawn                          d4df0949eb81d4e78e2fa911d3ade3e95636116fbdbca650e5af984dc5b8194d KILLED
os_exec                           4e9505c3300279d14326c6f5349329d66277d0a193dc0f7584745cbb459b3240 KILLED
star_import                       8839eaa4f7c8ace8b99724b96ee6b2f26aba97bffba6b920e47004ef352117b6 KILLED
```

The expected diagnostics covered exact module-import/value mismatches, forbidden process/Git APIs, assigned/parameter/module-global callables, dynamic dispatch, unknown local helpers, unresolved attributes/calls, and star imports. Actual diagnostics matched expected diagnostics.

All nine module-global mutants were killed:
```
boundary_rows_type          EXPECTED_BOUNDARY_ROWS          2a9bb8b8f7b161bba86352ad922c8745fee409832957fba5f23b419712df76c6
hashlib_identity            hashlib                        dc003c4f3bd703ed280597a70e601dce29dcdc2732801ace1c50fd12835af4a2
paths_sha_type              EXPECTED_PATHS_SHA256           18a7e3016bddd13f579431391d6ecc36a45a3b1681f0371d5410923db16b4030
paths_type                  EXPECTED_PATHS                  a972e3f4176913733e4be19d49feae8873da8a6e27b8d3cf5571a29a621548f2
protected_identities_type   PROTECTED_PATH_IDENTITIES       20ed33d6e6146bff47242f264968c5cf1e41bda128e96173f70c96332f926288
protected_ids_type          PROTECTED_ROW_IDS               c51af168e2584768d4077d313c123a16608ce419f15b309b8bfbba1effb62a5a
protected_paths_type        PROTECTED_PATHS                 1f5ff679807f34a71f08a5be078eebcfdcd9203c922b89415c2c94166a6fe3ae
root_type                   ROOT                            4be3d3b1cd1a91adf98ac896f3179ca7af88d88ca1459f9614c8de705ade40c4
stat_identity               stat                            94191c5f697c7310aaaa89622fd7d6eef55ef4e11b0426713b1d65542597a508
```

Historical no-status inventory:
```
direct_git_status_porcelain    killed; test_exact_twenty_path_ceiling_modes_and_protected_controls:git_status_command
detached_helper_git_status     killed; _status_probe:git_status_command
git_diff_name_only             killed; ...:git_diff_classification_command
git_diff_cached                killed; ...:git_diff_classification_command
git_ls_files_others            killed; ...:git_untracked_classification_command
staged_untracked_count_branch  killed; ...:candidate_state_classification
clean_dirty_porcelain_branch   killed; ...:candidate_state_classification
constructed_argv_fragments     historical survivor; subsequently killed by the closed-call matrix
shell_string_equivalent        historical survivor; subsequently killed by the closed-call matrix
```

Protected-content causal ledger:
```
P01 _rw0_wire_protocol_values.py                            6bf39f...31e -> e9039a...d08 byte[38501]:6d->6e KILLED
P02 _development_author_effect_establishment_contracts.py  f69380...af0 -> ac4a42...736 byte[31759]:6e->6f KILLED
P03 _development_decision_row_values.py                    9e0e9c...8ae -> b2f068...e75 byte[26615]:73->74 KILLED
P04 _development_effect_row_values.py                      bbe52f...158 -> d758c1...f37 byte[32303]:3e->3f KILLED
P05 _development_program_row_values.py                     d8557e...422 -> 27ff5c...a3a byte[30138]:45->46 KILLED
P06 src/ge_nwp_coordinator/__init__.py                     60230a...2b5 -> 426e1e...d2e byte[1192]:43->44 KILLED
P07 pyproject.toml                                          c59ff8...ac9 -> 84b587...3ff byte[165]:65->66 KILLED
P08 tests/c2a_contract_support.py                           4952d2...4f1 -> ce739c...2ed byte[77164]:72->73 KILLED
P09 test_c2b2_development_row_value_boundaries.py          4c8921...f42 -> b268c6...c20 byte[8911]:66->67 KILLED
P10 tests/test_codex_agent_config.py                        0691c9...3ee -> 0f8560...7e9 byte[541]:6e->6f KILLED
P11 AGENTS.md                                               ab3e78...0c8 -> 5e46dd...a57 byte[29451]:61->62 KILLED
P12 README.md                                               093134...1d4 -> b869c3...4e3 byte[21640]:6e->6f KILLED
P13 .docs/software-development-progression-boundary.md     3b0c21...2fe -> b9aebf...5e1 byte[13597]:20->21 KILLED
```

The exact prior-audit survivor changed the P12 assertion from exact `(size,digest)` equality to a vacuous length/type check. Its mutant SHA-256 was `b869c3ce6020385cfd118d826bbe09e66397d7b584ae4c8b66800dd03ccfd4e3`; it was killed by `protected_causal_mutant_survived:P12`.

The literal projection had 43 ordered rows: R01–R30 bound the 30 required candidate files as regular `0644` paths; P01–P13 bound the protected files, exact sizes, and SHA-256 values shown above. Expected and observed tuples were byte-identical. All seven controls passed: row count, unique IDs, unique purposes, unique subjects, unique diagnostics, exact contract classes, and ordered projection.

Stable-contract matrix:
```
missing_required_path                 KILLED stable_path_inventory_count
unexpected_literal_path               KILLED stable_path_inventory_count
regular_to_symlink                    KILLED required_regular_file:.docs/rw0-b2-capability.md
wrong_mode                            KILLED required_mode:.docs/rw0-b2-capability.md
package_root_export                   KILLED not in ge_nwp_coordinator.__dict__
production_importer_caller            KILLED _rw0_worker_mechanism_capability_values
dependency_schema_migration_widening  KILLED migration
protected_content_weakening           KILLED protected_identity:P12:README.md
```

Every external mutation was restored exactly. The former G7 failure point, regular-to-symlink, was killed and restored with direct target verification, normalized equality, logical-index equality, and separately recorded report-only raw-index observations.

## Focused groups, states, nodes, and complete suites

Focused results:

| GroupResultOrdered-node SHA-256Duration |         |                                                                    |                |
| --------------------------------------- | ------- | ------------------------------------------------------------------ | -------------- |
| Selected causal                         | 16/16   | `0a9f63ef728d7b3fd193b22a4e3b8c2f8f7c769ff8498478da87bb218ebf4aeb` | 4.028058084 s  |
| Capability boundaries                   | 32/32   | `a11ab8af6701da7b032da92b2ba6b60caf695569e1ce2debf17be6f9ee538bc7` | 3.768638500 s  |
| Capability complete                     | 69/69   | `31713d40ebbc13d8ff3c249c5e3ee94560bff350ec53c582efc08f3b5ebd1d15` | 5.670693166 s  |
| B1/Wire compatibility                   | 461/461 | `48d560ae6434f8fd62b09de85b3439fc5209643acfd3c5d1cfe4b4af495f98fe` | 11.143307042 s |
| Architecture/status/static              | 907/907 | `f087e0df13b0f96c1f74fbef75bbf74716c1a18549bf7637447c2c210e15f010` | 35.436406000 s |

A/B/C:

- State A, live unstaged: PASS
- State B, independent external staged: PASS
- State C, diagnostic committed: PASS
- Target node hash in all states: `ddbc9e6c4b92b37c6d1b5f99212644506617c8e3309e5c06a392d1f207b1a169`
- Projection rows: 43
- Projection A=B=C: true
- State-B staged tree: `0fcf6680ded68d66f62b75b5dc842d69b343a334`
- State-C committed tree: `0fcf6680ded68d66f62b75b5dc842d69b343a334`
- External alternates: none
- Shared source/external object inodes: none
- Source index/object graph unchanged: true

Node reconciliation:

- Opening list: 5,057 nodes, 839,431 bytes, SHA-256 `f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe`
- Final live/clean list: 5,072 nodes, 841,100 bytes, SHA-256 `f0faec3289ed635a741867bb2a655487f4a4a824dcf4cc0921c334beada1bbd3`
- Added: 15
- Removed: 0
- Renamed: 0
- All additions were the closed-call control, P01–P13 causal tests, and exact audit-survivor kill in `tests/test_rw0_b2_capability_boundaries.py`
- Outside-file node identity/order: exact

Complete suites:

- Live suite: exactly one run; 5,072 collected, 5,072 passed; 0 failures/errors/skips/xfails/xpasses/warnings; empty stderr; duration 925.713504750 seconds.
- Clean State-C suite: exactly one run; 5,072 collected, 5,072 passed; 0 failures/errors/skips/xfails/xpasses/warnings; empty stderr; duration 943.447987291 seconds.
- Both JUnit mappings exactly matched the retained ordered node list.
- No retry occurred.

## Cleanup and seal

Cleanup removed only G8-created transient material:

- Targets: 424
- Entries: 27,475
- Regular-file bytes: 2,968,114,989
- Included the external repository, basetemps, pycache roots, TMPDIR trees, and transient object copies
- Post-cleanup residue: none
- Post-cleanup unsafe entries: none

G8 evidence root:

- Root: `/private/tmp/g8.3cee3f`
- Directories: mode `0700`
- Retained files: mode `0400`
- Symlink/FIFO/socket/device/special entries: none

Attempt manifest:

- Rows: 212, continuous `1..212`
- Unique labels: true
- Credited: 209
- Non-creditable: 3
- Actual outcomes: 150 success, 58 expected-nonzero, 1 preflight refusal/not-launched, 3 unexpected-nonzero
- Size: 67,790 bytes
- SHA-256: `83e79b1ca3ca29a9a7dec45bededcc642057f8dc5bf940bfc826c392f6ae0c65`

Terminal evidence:

- Final report: 99,764 bytes; SHA-256 `e54ecbef3321b810e58c248221d6542325b878c67ddd35483993c61e9781d118`
- Self-excluding index: 2,403 rows; 448,923 bytes; SHA-256 `f90d50dc17e95e432b6577cad99669777f99bcd2d6af7c42509d2987db8248fc`
- Canonical indexed projection: 530,717 bytes; SHA-256 `053a696a2034958ea2a5161713fa81fbfe88d88e5cf5987e185115872075ae7a`
- Strict tree match: true
- Index excludes itself: true
- No unindexed entry: true
- No unsafe entry: true
- Manifest/envelope reconciliation: true
- Root unchanged after index: true
- External index-builder result: 2,485 bytes; SHA-256 `3b88a5bea1846161424cd26b208af9d36cd859d97b818f9bc7e53041deb4fb00`
- External verifier result: 781,828 bytes; SHA-256 `3e59175a566b860abd09165d6952a4350cdb42b2b77cb0509cc4420d4df53f4a`

## Complete all-attempt chronology

Notation: `expected→actual; credit`. `C` = credited, `N` = not creditable.
```
001 bootstrap | bootstrap | success→success C
002 recorder_runtime_start | recorder_tooling | success→success C
003 recorder_selftest_success | recorder_selftest | success→success C
004 recorder_selftest_expected_nonzero | recorder_selftest | expected_nonzero→expected_nonzero C
005 recorder_selftest_refusal | recorder_selftest | refusal→refusal C
006 recorder_selftest_zero_streams | recorder_selftest | success→success C
007 recorder_selftest_guard | recorder_guard | success→success C
008 pre_harness_path_safety | opening_gate | success→unexpected_nonzero N
009 g8_prevalidation_tooling_recovery_patch | recorder_tooling_recovery | success→unexpected_nonzero N
010 g8_prevalidation_tooling_recovery_patch_recovery_1 | recorder_tooling_recovery | success→success C
011 pre_harness_path_safety_recovery_1 | opening_gate | success→unexpected_nonzero N
012 g8_prevalidation_path_alias_patch | recorder_tooling_recovery | success→success C
013 pre_harness_path_safety_recovery_1_recovery_1 | opening_gate | success→success C
014 restore_harness_static_audit | restore_harness_static_audit | success→success C
015 restore_harness_selftest_regular_to_symlink_to_regular | restore_harness_selftest | success→success C
016 restore_harness_selftest_regular_to_missing_to_regular | restore_harness_selftest | success→success C
017 restore_harness_selftest_mode_mutation_restore | restore_harness_selftest | success→success C
018 restore_harness_selftest_content_mutation_restore | restore_harness_selftest | success→success C
019 restore_harness_selftest_raw_index_stat_cache_refresh | restore_harness_selftest | success→success C
020 restore_harness_selftest_synthetic_no_legacy_index_field | restore_harness_selftest | success→success C
021 restore_harness_selftest_negative_logical_index_mismatch | restore_harness_selftest | success→success C
022 restore_harness_selftest_guard | restore_harness_guard | success→success C
023 evidence_open_g5 | opening_gate | success→success C
024 evidence_open_g4 | opening_gate | success→success C
025 evidence_open_repair | opening_gate | success→success C
026 evidence_open_v2 | opening_gate | success→success C
027 evidence_open_v3 | opening_gate | success→success C
028 evidence_open_g6diag | opening_gate | success→success C
029 preexisting_index_verification | opening_gate | success→success C
030 g6_quarantine_opening | opening_gate | success→success C
031 g7_quarantine_opening | opening_gate | success→success C
032 target_extraction | opening_gate | success→success C
033 recipe_copy_preflight | opening_gate | success→success C
034 opening_repository_gate | opening_gate | success→success C
035 candidate_manifest_comparison | opening_gate | success→success C
036 opening_recipe_prepare_1 | provenance_setup | success→success C
037 opening_recipe_1 | provenance_recipe | success→success C
038 opening_recipe_seal_1 | provenance_guard | success→success C
039 opening_recipe_prepare_2 | provenance_setup | success→success C
040 opening_recipe_2 | provenance_recipe | success→success C
041 opening_recipe_seal_2 | provenance_guard | success→success C
042 opening_recipe_comparison | opening_gate | success→success C
043 mutation_source_extraction | opening_gate | success→success C
044 selected_control_01 | individual_canonical_control | success→success C
045 selected_control_02 | individual_canonical_control | success→success C
046 selected_control_03 | individual_canonical_control | success→success C
047 selected_control_04 | individual_canonical_control | success→success C
048 selected_control_05 | individual_canonical_control | success→success C
049 selected_control_06 | individual_canonical_control | success→success C
050 selected_control_07 | individual_canonical_control | success→success C
051 selected_control_08 | individual_canonical_control | success→success C
052 selected_control_09 | individual_canonical_control | success→success C
053 selected_control_10 | individual_canonical_control | success→success C
054 selected_control_11 | individual_canonical_control | success→success C
055 selected_control_12 | individual_canonical_control | success→success C
056 selected_control_13 | individual_canonical_control | success→success C
057 selected_control_14 | individual_canonical_control | success→success C
058 selected_control_15 | individual_canonical_control | success→success C
059 selected_control_16 | individual_canonical_control | success→success C
060 call_surface_control | causal_control | success→success C
061 call_mutant_direct_subprocess | expected_mutant_rejection | expected_nonzero→expected_nonzero C
062 call_mutant_constructed_argv | expected_mutant_rejection | expected_nonzero→expected_nonzero C
063 call_mutant_module_prebuilt_argv | expected_mutant_rejection | expected_nonzero→expected_nonzero C
064 call_mutant_shell_string | expected_mutant_rejection | expected_nonzero→expected_nonzero C
065 call_mutant_concatenated_shell | expected_mutant_rejection | expected_nonzero→expected_nonzero C
066 call_mutant_imported_callable_alias | expected_mutant_rejection | expected_nonzero→expected_nonzero C
067 call_mutant_module_alias_attribute | expected_mutant_rejection | expected_nonzero→expected_nonzero C
068 call_mutant_nested_attribute_alias | expected_mutant_rejection | expected_nonzero→expected_nonzero C
069 call_mutant_getattr_dispatch | expected_mutant_rejection | expected_nonzero→expected_nonzero C
070 call_mutant_wrapper_prebuilt_argv | expected_mutant_rejection | expected_nonzero→expected_nonzero C
071 call_mutant_callable_default | expected_mutant_rejection | expected_nonzero→expected_nonzero C
072 call_mutant_callable_closure | expected_mutant_rejection | expected_nonzero→expected_nonzero C
073 call_mutant_module_global_callable | expected_mutant_rejection | expected_nonzero→expected_nonzero C
074 call_mutant_unknown_local_helper | expected_mutant_rejection | expected_nonzero→expected_nonzero C
075 call_mutant_dynamic_import | expected_mutant_rejection | expected_nonzero→expected_nonzero C
076 call_mutant_gitpython_status | expected_mutant_rejection | expected_nonzero→expected_nonzero C
077 call_mutant_dulwich_status | expected_mutant_rejection | expected_nonzero→expected_nonzero C
078 call_mutant_subprocess_popen | expected_mutant_rejection | expected_nonzero→expected_nonzero C
079 call_mutant_subprocess_check_call | expected_mutant_rejection | expected_nonzero→expected_nonzero C
080 call_mutant_subprocess_check_output | expected_mutant_rejection | expected_nonzero→expected_nonzero C
081 call_mutant_subprocess_call | expected_mutant_rejection | expected_nonzero→expected_nonzero C
082 call_mutant_os_system | expected_mutant_rejection | expected_nonzero→expected_nonzero C
083 call_mutant_os_popen | expected_mutant_rejection | expected_nonzero→expected_nonzero C
084 call_mutant_os_spawn | expected_mutant_rejection | expected_nonzero→expected_nonzero C
085 call_mutant_os_exec | expected_mutant_rejection | expected_nonzero→expected_nonzero C
086 call_mutant_star_import | expected_mutant_rejection | expected_nonzero→expected_nonzero C
087 module_global_control | causal_control | success→success C
088 global_mutant_boundary_rows_type | expected_mutant_rejection | expected_nonzero→expected_nonzero C
089 global_mutant_hashlib_identity | expected_mutant_rejection | expected_nonzero→expected_nonzero C
090 global_mutant_paths_sha_type | expected_mutant_rejection | expected_nonzero→expected_nonzero C
091 global_mutant_paths_type | expected_mutant_rejection | expected_nonzero→expected_nonzero C
092 global_mutant_protected_identities_type | expected_mutant_rejection | expected_nonzero→expected_nonzero C
093 global_mutant_protected_ids_type | expected_mutant_rejection | expected_nonzero→expected_nonzero C
094 global_mutant_protected_paths_type | expected_mutant_rejection | expected_nonzero→expected_nonzero C
095 global_mutant_root_type | expected_mutant_rejection | expected_nonzero→expected_nonzero C
096 global_mutant_stat_identity | expected_mutant_rejection | expected_nonzero→expected_nonzero C
097 projection_control_row_count | causal_control | success→success C
098 projection_control_unique_ids | causal_control | success→success C
099 projection_control_unique_purposes | causal_control | success→success C
100 projection_control_unique_subjects | causal_control | success→success C
101 projection_control_unique_diagnostics | causal_control | success→success C
102 projection_control_contract_classes | causal_control | success→success C
103 projection_control_ordered_projection | causal_control | success→success C
104 protected_mutant_P01 | expected_mutant_rejection | expected_nonzero→expected_nonzero C
105 protected_mutant_P02 | expected_mutant_rejection | expected_nonzero→expected_nonzero C
106 protected_mutant_P03 | expected_mutant_rejection | expected_nonzero→expected_nonzero C
107 protected_mutant_P04 | expected_mutant_rejection | expected_nonzero→expected_nonzero C
108 protected_mutant_P05 | expected_mutant_rejection | expected_nonzero→expected_nonzero C
109 protected_mutant_P06 | expected_mutant_rejection | expected_nonzero→expected_nonzero C
110 protected_mutant_P07 | expected_mutant_rejection | expected_nonzero→expected_nonzero C
111 protected_mutant_P08 | expected_mutant_rejection | expected_nonzero→expected_nonzero C
112 protected_mutant_P09 | expected_mutant_rejection | expected_nonzero→expected_nonzero C
113 protected_mutant_P10 | expected_mutant_rejection | expected_nonzero→expected_nonzero C
114 protected_mutant_P11 | expected_mutant_rejection | expected_nonzero→expected_nonzero C
115 protected_mutant_P12 | expected_mutant_rejection | expected_nonzero→expected_nonzero C
116 protected_mutant_P13 | expected_mutant_rejection | expected_nonzero→expected_nonzero C
117 protected_mutant_audit | expected_mutant_rejection | expected_nonzero→expected_nonzero C
118 causal_replay_guard | mutation_guard | success→success C
119 state_a_target | pytest_validation | success→success C
120 state_a_projection | projection_control | success→success C
121 state_b_parent_setup | external_setup | success→success C
122 state_b_clone | external_setup | success→success C
123 state_b_checkout | external_setup | success→success C
124 state_b_remove_origin | external_setup | success→success C
125 state_b_config_name | external_setup | success→success C
126 state_b_config_email | external_setup | success→success C
127 state_b_base_guard | external_setup | success→success C
128 state_b_candidate_overlay | external_setup | success→success C
129 state_b_stage | external_setup | success→success C
130 state_b_isolation_guard | state_guard | success→success C
131 state_b_target | pytest_validation | success→success C
132 state_b_projection | projection_control | success→success C
133 state_c_diagnostic_commit | external_setup | success→success C
134 state_c_isolation_guard | state_guard | success→success C
135 state_c_baseline | state_guard | success→success C
136 state_c_target | pytest_validation | success→success C
137 state_c_projection | projection_control | success→success C
138 state_matrix_comparison | state_guard | success→success C
139 stable_probe_missing_required_path | expected_mutant_rejection | expected_nonzero→expected_nonzero C
140 stable_assert_missing_required_path | mutation_guard | success→success C
141 stable_probe_unexpected_literal_path | expected_mutant_rejection | expected_nonzero→expected_nonzero C
142 stable_assert_unexpected_literal_path | mutation_guard | success→success C
143 stable_setup_regular_to_symlink | mutation_setup | success→success C
144 stable_test_regular_to_symlink | expected_mutant_rejection | expected_nonzero→expected_nonzero C
145 stable_restore_regular_to_symlink | mutation_cleanup | success→success C
146 stable_assert_regular_to_symlink | mutation_guard | success→success C
147 stable_setup_wrong_mode | mutation_setup | success→success C
148 stable_test_wrong_mode | expected_mutant_rejection | expected_nonzero→expected_nonzero C
149 stable_restore_wrong_mode | mutation_cleanup | success→success C
150 stable_assert_wrong_mode | mutation_guard | success→success C
151 stable_setup_package_root_export | mutation_setup | success→success C
152 stable_test_package_root_export | expected_mutant_rejection | expected_nonzero→expected_nonzero C
153 stable_restore_package_root_export | mutation_cleanup | success→success C
154 stable_assert_package_root_export | mutation_guard | success→success C
155 stable_setup_production_importer_caller | mutation_setup | success→success C
156 stable_test_production_importer_caller | expected_mutant_rejection | expected_nonzero→expected_nonzero C
157 stable_restore_production_importer_caller | mutation_cleanup | success→success C
158 stable_assert_production_importer_caller | mutation_guard | success→success C
159 stable_setup_dependency_schema_migration_widening | mutation_setup | success→success C
160 stable_test_dependency_schema_migration_widening | expected_mutant_rejection | expected_nonzero→expected_nonzero C
161 stable_restore_dependency_schema_migration_widening | mutation_cleanup | success→success C
162 stable_assert_dependency_schema_migration_widening | mutation_guard | success→success C
163 stable_setup_protected_content_weakening | mutation_setup | success→success C
164 stable_test_protected_content_weakening | expected_mutant_rejection | expected_nonzero→expected_nonzero C
165 stable_restore_protected_content_weakening | mutation_cleanup | success→success C
166 stable_assert_protected_content_weakening | mutation_guard | success→success C
167 stable_mutation_matrix | mutation_guard | success→success C
168 focused_selected_causal | pytest_validation | success→success C
169 focused_capability_boundaries | pytest_validation | success→success C
170 focused_capability_complete | pytest_validation | success→success C
171 focused_b1_wire | pytest_validation | success→success C
172 focused_architecture_static | pytest_validation | success→success C
173 pre_collection_source_guard | final_guard | success→success C
174 live_collection | node_collection | success→success C
175 clean_collection | node_collection | success→success C
176 node_reconciliation | node_guard | success→success C
177 pre_full_suite_source_guard | final_guard | success→success C
178 live_full_suite | complete_suite | success→success C
179 clean_full_suite | complete_suite | success→success C
180 post_suite_source_guard | final_guard | success→success C
181 ambient_source_metadata_delta | final_guard | success→success C
182 evidence_close_g5 | final_guard | success→success C
183 evidence_close_g4 | final_guard | success→success C
184 evidence_close_repair | final_guard | success→success C
185 evidence_close_v2 | final_guard | success→success C
186 evidence_close_v3 | final_guard | success→success C
187 evidence_close_g6diag | final_guard | success→success C
188 preexisting_closeout_verification | final_guard | success→success C
189 g6_quarantine_closeout | final_guard | success→success C
190 g7_quarantine_closeout | final_guard | success→success C
191 final_node_identity_guard | final_guard | success→success C
192 final_mutation_ledger_guard | final_guard | success→success C
193 all_attempt_guard_before_cleanup | final_guard | success→success C
194 external_retention | final_guard | success→success C
195 cleanup_transients | cleanup | success→success C
196 post_cleanup_guard | final_guard | success→success C
197 final_recipe_identity | provenance_guard | success→success C
198 final_recipe_prepare_1 | provenance_setup | success→success C
199 final_recipe_1 | provenance_recipe | success→success C
200 final_recipe_seal_1 | provenance_guard | success→success C
201 final_recipe_prepare_2 | provenance_setup | success→success C
202 final_recipe_2 | provenance_recipe | success→success C
203 final_recipe_seal_2 | provenance_guard | success→success C
204 final_recipe_comparison | provenance_guard | success→success C
205 final_source_guard | final_guard | success→success C
206 final_attempt_manifest_guard | final_guard | success→success C
207 root_mode_seal | evidence_seal | success→success C
208 attempt_manifest_generation | deterministic_terminal_procedure | success→success C
209 pre_index_inventory | deterministic_terminal_procedure | success→success C
210 final_report_generation | deterministic_terminal_procedure | success→success C
211 evidence_index_creation | deterministic_terminal_procedure | success→success C
212 external_index_verification | deterministic_terminal_procedure | success→success C
```

## Exact final manifest JSON
```
{"branch":"codex/rw0-b2-capability-semantics-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/authority-boundaries.md","sha256":"1a8ceceaa4c4110f24a4a5e6caa2182c40f1d93b3c94e386c704aaafed6dcb07","size":32953},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/autonomous-software-development-operating-model.md","sha256":"3399cdae5f9e4e6772cd4d6343906d920018cb759adf89177a515ba351378b64","size":34951},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/c2a-first-slice-semantic-protocol-contract.md","sha256":"49238bb9673f0334359c29c7c5add8e35bd617c9e25b7bc372e2445324c81150","size":102469},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/c2a1-pure-semantic-values.md","sha256":"ed7c7a7fad70405268354b348988013631a8c91759a67c24f05d8fb933d5c811","size":17052},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/durable-state-model.md","sha256":"b408350111e76de2eed85245264ced5e01dbd5972b2751c610af1df0e038dc18","size":38138},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-b1-pure-phase-values.md","sha256":"d6f8e7c119cc09af1f9e9639ed8b5c774bdda29e94f1f58a3e2988419297b63d","size":30594},{"file_type":"regular","kind":"untracked","mode":"0644","path":".docs/rw0-b2-capability.md","sha256":"d338979d87d09eadbddad79c249b0d3936fa8b41cc87dc787ed5211a90de279e","size":16611},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-b2-wire-protocol.md","sha256":"9f74f07a12c5be7b6425cf6f3ca57b502c0b66a0b3838e3c791d1ae21c746258","size":16802},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-remote-worker-contact-phase-entry.md","sha256":"7db0d796c48f3ba20325c20edcd2789b55636fac24af8429fc1d61e08c6be138","size":53427},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/worker-execution-boundary.md","sha256":"77ef23371e4e41df315ae86ce6f173e68a9dcc98e5812a056225b10807f2e14f","size":29202},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py","sha256":"7882ca37e70fba0aa7673d6066e92498bc42d9a3dc8f9a7b4f0256970aeffec4","size":57863},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py","sha256":"4be365d3a494088d5353592f6f689682d59217ac211072f6b27edc874dd2df36","size":100783},{"file_type":"regular","kind":"untracked","mode":"0644","path":"src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py","sha256":"6ba48cd75ac50061576925aa97de0baa8cfb23acbeccceeef953a353c06f8533","size":37555},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"src/ge_nwp_coordinator/_worker_execution_semantic_values.py","sha256":"313aa2a51fc9abb632f9278df8672a90c5ee9045c4967f340d3234d9c6760d4c","size":171211},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_architecture_contracts.py","sha256":"2a7ae85baf6ffb84cfffef4d0585884f6908f1c793185a3ac26525b1b3b55457","size":99858},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_c2a_nonimplementation.py","sha256":"b0930f649de0c8456d11d8392964403a5c9f275a82bf9c4c544d68e1d2b3b5d9","size":27234},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_runtime_non_authority.py","sha256":"9636dd003e358d178e6d6316b16dbff7ece944ae64f7bf0a3f3080b6be297755","size":41310},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b1_boundaries.py","sha256":"4d7fb14a71cb1c27f754566c4ac80dcc066b1f491f648fec3cbdb149b1ab6cd5","size":34249},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b1_phase_values.py","sha256":"69235075cdfadb5e467ea02a8a30e7484d6c04c8f065c2b1e03004e57a9eb166","size":30030},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b1_relations.py","sha256":"243216b7e556e150e972ce5d3ceae016b8fc51d9227f65549bfd3e396d8f89ac","size":120738},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_boundaries.py","sha256":"eb6ca3cd19b4bd723b82002aa93e7b5743ef02b768ac169d96e0011582e61977","size":76858},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_relations.py","sha256":"7522e11f5c5f932462af2cf78f1f86accd703199dd3a2b2232ed82b74cf8c2a4","size":26877},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_values.py","sha256":"a3e0c08d6fd4a07133cd450ca62fe1fe668898ac40e0fd5b1798d4a09853791f","size":31770},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_vectors.py","sha256":"4aa4432b3e042e72f4a0d131a696a842f1a2ac1e3473f8bc04ad8fb90219f7f3","size":16104},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b2_wire_boundaries.py","sha256":"ec77607ee411c46820e3dbac3fc67fbd1bcf071bcea6888f3286bf58fdd89f78","size":28690},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_remote_contact_phase_entry_contract.py","sha256":"83c2cb15e743b7e28307008af29f669190845734daaa3e96c2d7f1dcecd459f1","size":171097},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_section41_pre_execution_plan_disposition_contracts.py","sha256":"75b7b5e5051ecaab713ee5ec9a91d19d152e0d7e80be06b74548d3b72a9822ba","size":20327},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_software_development_progression_boundary.py","sha256":"1d3ecc4e509933987e898c6532dd0980cbd737a595b3cb2682b93becf30fa4de","size":42833},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_worker_execution_semantic_boundaries.py","sha256":"0279bb43c83e5074a2be549c0453c15c942da77145b4a7cbc875826d8f3259c3","size":12313},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_worker_execution_semantic_values.py","sha256":"d8cb06aaa85a37d116c1df0fc2ceeb4f2fb7265445b45107d352e10f17ddb8c0","size":51836}],"head":"deec37bf08fb903d8846aa2c3232aec52fa9866e","recipe_id":"governed-execution.audit-patch-manifest.v1","textual_diff_sha256":"cc91155aff703e1c54c139820f841d98135f37ee7c87a71d3b00b07a2672e2a6","upstream":"origin/trunk_dev"}
```

## Authority and continuation boundary

No public API, durable authority, execution permission, persistence, migration, worker, provider, runtime, or Execution Substrate behavior was widened.

RW0-C/D/E durable, transport, process, provider, credential, live-proof, and runtime mechanics remain future. Execution Substrate admission and runtime authority remain external and unchanged.

Confidence:

- Provenance: high
- Validation binding: high
- Implementation: unchanged and accepted

Required statements:
```
REPOSITORY_MUTATION_NOT_PERFORMED
IMPLEMENTATION_NOT_RERUN
HISTORICAL_METADATA_NOT_RECONSTRUCTED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```

Supplementary sealed evidence:

- [Final report](/private/tmp/g8.3cee3f/final_report.md)
- [Attempt manifest](/private/tmp/g8.3cee3f/attempt_manifest.jsonl)
- [Self-excluding evidence index](/private/tmp/g8.3cee3f/evidence_index.jsonl)
- [External index-builder result](/private/tmp/g8.3cee3f.index_builder.json)
- [External verifier result](/private/tmp/g8.3cee3f.external_verifier.json)
