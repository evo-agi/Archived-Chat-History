TITLE

Coordinator RW0-B2-Wire — cancellation-request source-owner correction and
profile refreeze

ENGAGEMENT TYPE

Finite parent-only, read-only correction in the existing RW0-B2 design
conversation.

This is not another broad reconnaissance and not an implementation prompt.
Do not create or resume subagents.

Do not edit, create, delete, format, chmod, stage, commit, push, create or
modify a PR, merge, tag, release, deploy, install dependencies, run tests or
pytest collection, invoke Codex/model/provider behavior, contact any network,
worker, host, service, Bridge, ES, IM, or supporting repository, or create
repository-local artifacts.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED BASELINE

Require before inspection and at closeout:

- branch:
  trunk_dev
- HEAD:
  02450d3c99faf0fe7b299b914afaed312421bc8b
- tree:
  0b5394c591bd277d56797794f71af954ccb93846
- sole parent:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- subject:
  feat: implement RW0-B1 pure phase-entry semantics (#3)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- worktree/index/untracked/unmerged:
  clean
- no Git operation, lock, bytecode, cache, database, build, archive, or
  generated-manifest residue.

Do not fetch or contact a remote. Stop on mismatch.

OPENING PACKET

Treat the immediately preceding response as the opening freeze packet:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_READY
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

Preserve every field, identity, frame, payload, bound, error, classifier,
module, touched-file, validation, provenance, audit, and stop-condition
decision from that packet except the exact cancellation-request source-kind
ownership and the profile bytes/digest derived from it.

CONCRETE OWNING-CONTRACT CONFLICT

The preceding packet freezes:

```text
RW0WireCancellationRequestObservationV1.source_kind
    = direct_local_adapter | es_adapter
```

That is not compatible with the accepted RW0-A fact-owner split.

Repository owner evidence:

1. `.docs/rw0-remote-worker-contact-phase-entry.md:182-184`

   The direct-local adapter handles transport, while the remote supervisor owns
   process lifecycle, deadlines, cancellation requests, stdout/stderr capture,
   and cleanup.

2. `.docs/rw0-remote-worker-contact-phase-entry.md:369-372`

   Execution Substrate owns ES-route cancellation. The direct-local supervisor
   owns route-local process control and cancellation-request delivery. The
   direct-local adapter transports those bounded facts and does not become
   their author.

3. Existing C2A keeps adapter-authored acknowledgement/rejection observations
   under `direct_local_adapter | es_adapter`. That does not transfer request
   authorship to the adapter and does not make request and response the same
   fact.

This is an authority/fact-attribution defect in the frozen B2 schema, not a
reason to reopen framing, result grammar, classifier precedence, B1, C2A, or
Capability.

REQUIRED CORRECTION

Freeze the request value’s exact source-kind enum as:

```text
source_kind = supervisor | execution_substrate
```

Meaning:

- `supervisor`:
  the direct-local remote supervisor that actually issues the route-local
  cancellation request;

- `execution_substrate`:
  the ES-route cancellation owner, without claiming that the local
  Coordinator-facing ES adapter authors ES runtime truth.

Do not use:

```text
direct_local_adapter
es_adapter
```

as request authors.

The request relation must require:

```text
cancellation_delivery.adapter_kind == direct_local_bootstrap
    -> request.source_kind == supervisor

cancellation_delivery.adapter_kind == execution_substrate
    -> request.source_kind == execution_substrate
```

The safe `source_ref`, `source_invocation_ref`, evidence ref/digest, timestamp,
and self-digest remain source claims only. They authenticate nothing.

REQUEST/RESPONSE NON-COLLAPSE

Preserve these distinctions:

- direct-local request:
  authored by `supervisor`;

- direct-local acknowledgement/rejection:
  existing C2A adapter-authored observations carried by
  `direct_local_adapter`;

- ES request:
  authored by `execution_substrate`;

- ES acknowledgement/rejection:
  existing C2A adapter-authored observations carried by `es_adapter`.

Therefore the classifier must not require request and acknowledgement/rejection
to have equal `source_kind`, `source_ref`, or `source_invocation_ref`.

A response matches a request only through:

- the exact cancellation semantic graph;
- cancellation effect intent and fence;
- cancellation delivery;
- immutable target effect/fence;
- target author delivery and lineage;
- applicable route relation.

A syntactically valid but false source claim cannot be disproved by Wire alone;
source authenticity remains RW0-D/E and later durable ingest policy remains
RW0-C.

PRIVACY CLARIFICATION

Every new B2 ref field must use:

- the existing C2A safe-ref character/length and forbidden-prefix grammar; plus
- B1’s privacy rule rejecting IPv4-shaped refs.

Unknown keys containing the B1 private-material key fragments must fail with
the finite privacy reason rather than being echoed or treated as ordinary
unknown data. Do not import B1; reproduce the frozen privacy constants locally
and pin them independently in tests.

No raw hostname, IP, endpoint, credential, bearer, provider/session, path,
stdout/stderr, prompt, transcript, JSONL, or process handle is permitted.

PROFILE REFREEZE

Preserve:

```text
profile_ref = rw0-wire-nwpf-v1
profile schema = governed-execution.nwp-rw0-wire-protocol-profile.v1
digest domain = governed-execution.nwp-rw0-wire-protocol-profile.v1.identity
```

Change only:

```json
"request": {
  ...
  "source_kinds": ["supervisor", "execution_substrate"],
  ...
}
```

in the already frozen canonical profile manifest.

All other profile bytes remain identical.

The corrected canonical identity mapping is expected to be:

```text
4,021 bytes
```

and its expected domain-separated SHA-256 is:

```text
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
```

Independently reproduce both values from the full canonical mapping. Stop on
mismatch rather than copying the expected digest into the report.

IMPLEMENTATION SURFACE

The exact 16-path implementation ceiling remains unchanged.

No B1 or C2A file is authorized to change.

The direct Wire tests must include independent causal cases proving:

1. direct-local request with `source_kind=supervisor` is accepted when every
   semantic relation is exact;

2. direct-local request with `source_kind=direct_local_adapter` is rejected even
   though that source kind is valid for C2A acknowledgement/rejection;

3. ES request with `source_kind=execution_substrate` is accepted;

4. ES request with `source_kind=es_adapter` is rejected even though that source
   kind is valid for C2A acknowledgement/rejection;

5. request and matching acknowledgement/rejection may have different
   source-kind/ref/invocation claims while sharing the exact cancellation graph;

6. a request/response graph mismatch still rejects;

7. IPv4-shaped values reject independently in every new B2 ref-bearing value
   family;

8. private-material unknown keys reject without echoing supplied content.

Each mutant changes one predicate and reseals only the B2 value whose digest
owns the change.

CAPABILITY SEAM

Retain exactly:

```text
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

This correction strengthens provider/mechanism neutrality. It adds no
Capability class and authorizes no Capability implementation.

VERDICT

Return exactly:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_READY
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

only if:

- the repository owner language confirms the corrected request authors;
- the complete corrected profile mapping reproduces the expected size/digest;
- no other field or contract changes;
- the exact 16-path ceiling remains sufficient;
- baseline and closeout identity remain unchanged.

Otherwise return PARTIAL or BLOCKED with one concrete source-grounded reason.

READY must report:

1. the ownership conflict and correction;
2. the exact corrected request source enum and route mapping;
3. request/response non-collapse;
4. corrected complete profile identity size and digest;
5. privacy clarification;
6. exact added future causal tests;
7. confirmation that every other freeze-packet decision is inherited unchanged;
8. baseline/closeout guards and inspection boundary.

NEXT STEP

Only a corrected READY/BOUNDED result authorizes one parent-only
RW0-B2-Wire implementation prompt.

Do not implement or imply Capability implementation.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
