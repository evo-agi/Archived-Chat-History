Before forwarding the RW0-B2 reconnaissance or schema-freeze handoff, please incorporate the completed B1 evidence into the normal B2 engineering design. Do not create a separate evaluation artifact or reopen accepted B1 bytes.

B1 ultimately preserved its high-level ownership split, but four independent
audit BLOCKs continued to define authority containment, attempt/candidate/
command lineage, retrieval identity and expiry, privacy, canonical integer
behavior, and traversal budgets after the design had been called frozen.
Treat that as evidence that schema completeness and a large test plan are not
enough to establish semantic freeze completeness.

For B2, make and defend these engineering decisions:

1. Exact B2 capability

State the observable B2 result, how it advances the first remote-worker loop,
which committed B1/C2A objects it consumes, and what remains reserved for C,
D, E, and ES.

B2 must not redefine or modify B1 semantics merely to simplify framing.

2. B2 decomposition

Explicitly decide whether these belong in one implementation tranche or should
be separated into B2a/B2b:

- hostile byte framing, codec, terminal-result grammar, and deterministic
  process/result precedence;
- provider-neutral Codex capability declaration, independent observation, and
  qualification semantics.

Recommend the smallest non-disposable decomposition. Do not split them merely
to create more gates, but do not combine them merely because both are pure and
no-I/O.

3. Codex mechanism ownership

Resolve the current wording tension:

- the B1 owner says B2 owns wire framing and “Codex mechanism”;
- the RW0-A owner defers Codex CLI versus App Server to RW0-D/E.

Use the default interpretation that B2 may define provider-neutral capability
contracts and qualification, while concrete CLI/App Server selection,
credential delivery, invocation, and process mechanics remain D/E.

Select the concrete mechanism in B2 only if owning-contract evidence requires
an explicit architecture revision. Do not let a B2 value schema silently make
that selection.

4. Caps and bounds

Do not freeze plausible round-number limits by judgment alone.

For every proposed command/result payload, observation-count, nesting-depth,
stderr/capture, and cumulative-work limit:

- identify the exact action it protects;
- identify whether it is derived from an existing owner or newly selected B2
  policy;
- calculate the largest valid committed B1/C2A record or composition it must
  admit;
- preserve evidence of that calculation;
- define maximum and one-over counterexamples.

A practical process limit is not a new C2A effect ceiling, and a
representational maximum is not permission to allocate or transport that size.

5. Pre-freeze contradiction matrix

Before returning READY, challenge at least:

- frame identity versus existing command and semantic identities;
- terminal result versus WorkerObservationV1, RW0TerminalOutcomeV1, and the
  existing C2B decision grammar;
- exit/deadline/signal/cancellation/malformed-output precedence;
- declaration versus independent observation versus qualification;
- raw stdout/stderr, transcript, provider-session, credential, endpoint, and
  private-path exclusion;
- direct-local versus later ES route neutrality;
- canonical C2A Unicode treatment versus Section 41 normalization;
- incomplete, duplicate-key, truncated, noncanonical, and trailing-byte frames.

Resolve contradictions or mark them as explicit later-owner seams. Do not defer
a contradiction that would invalidate B2’s own identities or protocol.

6. Prospective record

Record two or three falsifiable forecasts without unsupported numerical
confidence percentages:

- the most likely design or implementation blocker;
- whether the proposed touched-file boundary will be sufficient;
- the likely independent-audit finding classes;
- evidence that would require B2 redesign rather than an ordinary repair.

7. Disposition

Make the engineering recommendation yourself:

- one B2 tranche;
- a justified B2a/B2b split;
- or a concrete block pending an owning-contract decision.

Then issue the normal self-contained read-only Codex reconnaissance/freeze
prompt. Do not issue an implementation prompt until the exact protocol,
capability, limits, ownership, and counterexample treatment are source-grounded.
Do not ask me to choose ordinary schema, framing, test, or validation details.
