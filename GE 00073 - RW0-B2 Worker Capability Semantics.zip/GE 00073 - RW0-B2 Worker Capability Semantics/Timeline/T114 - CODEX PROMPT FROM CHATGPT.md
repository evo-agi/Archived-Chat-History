PROMPT_ID

RW0_B2_CAPABILITY_OWNER_ORACLE_FINAL_AUDIT_FINDINGS_REPAIR_FRESH_REAUDIT_V1

TITLE

Coordinator RW0-B2-Capability — fresh independent audit of the final
live-parser anchoring, causal-ledger, and migration-checker repair

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated independent audit.

Use a new Codex conversation. Do not use the write-enabled implementation
conversation that produced the repair.

The audit parent and all audit subagents are read-only. No repository mutation,
formatting, cleanup of candidate bytes, dependency installation, staging,
commit, push, PR, merge, tag, release, deployment, remote/service/provider/host
contact, product worker/model invocation, database mutation, migration, or
supporting-repository inspection is authorized.

Audit-created probes, clean external archives, pytest outputs, and provenance
records may be written only beneath one new external operator-owned,
non-symlink, mode-0700 audit root.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Determine whether the exact final candidate closes the three blocking seams
identified by the preceding independent audit:

```text
B1-MUTANT-005
  The RW0 owner test retained detached B1 parser aliases. Stale local parsers
  and post-import owner-parser replacement could leave all owner tests green.

EVID-CAUSAL-006
  The retained 27-row RW0 fence causal ledger omitted explicit `family` and
  `diagnostic` fields.

EVID-RENAME-CHECKER-007
  The migration checker accepted `new_node_id` on non-rename rows and did not
  enforce global endpoint uniqueness.
```

The audit must also verify that:

- only one repository test file changed;
- the new final validation envelope is complete and exact;
- the closed fence ledger and migration checker are self-contained and
  mutation-adequate;
- all prior accepted registry, parser, migration, production, public, privacy,
  and authority boundaries remain unchanged.

Do not reopen the accepted owner-registry architecture or production semantics
unless the exact candidate proves a concrete contradiction.

EXPECTED LIVE IDENTITY

Require at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644
```

Require:

- `git diff --check` clean;
- cached diff check clean;
- no Git operation or lock;
- no candidate symlink or special file;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, recorder residue, or thirty-first changed
  path.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

FINAL AUDIT TARGET

Final repair evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit-findings-repair.nJmVEI
```

Primary final report:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit-findings-repair.nJmVEI/final_report.md
```

Attempt ledger:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit-findings-repair.nJmVEI/attempt_manifest.json
```

Self-excluding evidence index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit-findings-repair.nJmVEI/evidence_index.jsonl

rows excluding itself:
213

size:
37706 bytes

SHA-256:
22439f6586f7c2f7c67ba17fe25147f92d0016afba3140b7b5e3e96b51a710e4
```

Required reported final identities:

```text
canonical-manifest SHA-256:
9efb739e958cf077dafad99d5dc62af3fdcbd847c359916fd22fb5c125b79472

final pytest node count:
5057

final ordered-node-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

full suite:
5057 collected
5057 passed
attempt 001 only

dirty topology:
30/24/6/0/0
```

Recover and verify from the indexed final evidence, rather than infer:

```text
final canonical-manifest path
canonical-manifest byte size
tracked textual-diff SHA-256
complete recipe-output path, size, and SHA-256
exact final manifest JSON
exact changed-path identity
final node-list path and exact additions
full-suite summary, stdout/stderr, JUnit, and fingerprint binding
closed 27-row fence ledger path, size, and SHA-256
closed fence-ledger checker and mutant results
closed 384-record migration checker path, size, and SHA-256
migration-checker mutant inputs and results
final path/mode/public/authority guards
cleanup record
```

If any mandatory identity is absent, internally inconsistent, unsafe to read,
or not bound by the self-excluding index, return
`AUDIT_PROVENANCE_MISMATCH` before correctness judgment.

OPENING REPAIR TARGET

The final repair began from this exact candidate:

```text
repair evidence root:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-findings-repair.ZRLt3w

canonical-manifest size:
6430 bytes

canonical-manifest SHA-256:
51b6adfdd88d538e26b7166681465fbb27abf467ec1e5936b646437e58d9f58b

complete recipe-output size:
6663 bytes

complete recipe-output SHA-256:
9e9a3582ae6109184593a1c68aff584ffe3f172f1db471b70ad2a20dee7d7bce

opening pytest node count:
5051

opening ordered-node-list SHA-256:
5e2a6c5f9e603895b9f9daf021ccc36a9915a8b923ddb7fe8c287b49325bb1aa
```

Exactly this one repository path must differ from that opening target:

```text
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The other twenty-nine candidate entries must be byte-, kind-, type-, mode-,
size-, and classification-identical.

PRECEDING AUDIT EVIDENCE

The independent audit that found the three blocking seams is:

```text
root:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit.6NY6CJ

report:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit.6NY6CJ/audit_report.md

self-excluding index:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit.6NY6CJ/evidence_index.jsonl

rows excluding itself:
75

size:
12568 bytes

SHA-256:
96badb399c58f0b172e8f1e4eb80d68304e3dc4bc58485ca7d8ba729e776e7c7
```

Also preserve and verify these earlier roots:

```text
reset implementation:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB
index SHA-256:
185d17a6332a49b545f50c5e7c33a4e1f6e1150fa799c547dbec40876b643e16

reset audit:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3
index SHA-256:
26b69c39d083cd2096c8e2b47c6afbef7626d24cbd55093fcabe659be23a06bb

findings repair:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-findings-repair.ZRLt3w
index SHA-256:
6de9b6295a2701a55bf496f2fe644f1c8be91b4314a67d84f3598c3a791e95b7

validation reset:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-validation-reset.ji1cdR
index SHA-256:
727d7feb2d24f6ea61222530b3d312483d7685f2da4f00dc462dce22e6eb6bb4
```

Verify every root safely and preserve it unchanged.

EXACT RECIPE SOURCE

Locate the exact retained recipe source through the final repair evidence index.

Require:

```text
type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Do not decode recipe source from prompt text. Do not reconstruct it from a
digest.

Run the exact source twice with source bytes unchanged and only its fixed
external historical output sink safely redirected to two unique audit-root
files. Retain the wrapper source and prove that redirection cannot affect Git
queries, stdout, canonical JSON, or any other recipe behavior.

PROVENANCE GATE

Before correctness inspection or audit subagents:

1. create one new operator-owned, non-symlink, mode-0700 audit root beneath
   `/private/tmp`;

2. safely `lstat` all retained-evidence path components;

3. verify all six pre-existing evidence indexes exactly;

4. independently inventory all six roots and compare them again at closeout;

5. verify exact repository identity and `30/24/6/0/0` topology;

6. locate the indexed final canonical manifest through the final report and
   evidence index;

7. require canonical JSON, file count 30, and SHA-256
   `9efb739e958cf077dafad99d5dc62af3fdcbd847c359916fd22fb5c125b79472`;

8. verify every manifest entry by classification, regular-file type, mode,
   size, and SHA-256;

9. verify no thirty-first changed path;

10. verify every path outside the manifest equals HEAD;

11. verify the exact retained recipe source;

12. execute it twice with safe sink redirection;

13. require both generated manifests to equal the retained final manifest
    byte-for-byte;

14. require both complete outputs to equal the indexed retained final complete
    outputs byte-for-byte;

15. recover and require the tracked textual-diff identity from indexed final
    evidence;

16. load and verify the opening repair manifest;

17. prove exactly one authorized repository path changed and the other 29
    entries remained exact;

18. verify:
    - final node list;
    - exact node delta;
    - selected causal records;
    - focused validation records;
    - full-suite JUnit and mapping;
    - closed fence ledger/checker/mutants;
    - closed migration checker/mutants;
    - final guards and cleanup;
    - self-excluding final evidence index;

19. verify all explicitly protected source/docs/public surfaces.

On any candidate or mandatory evidence identity mismatch, stop before
correctness inspection and return exactly:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not approximate, regenerate, or silently repair missing evidence.

EXPLICITLY PROTECTED BY THIS REPAIR

These must equal the opening repair target:

```text
all .docs files
all production source
src/ge_nwp_coordinator/__init__.py
pyproject.toml

tests/test_rw0_b1_boundaries.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py

all SQL, migrations, schemas, catalogs
StateStore
WriterSession
package exports
dependency metadata
```

ACCEPTED ARCHITECTURE — DO NOT REOPEN BY INERTIA

Preserve:

- embedded B1 and RW0 registries;
- registry version 1;
- exact registry rows, values, roles, sources, markers, headings, and locations;
- prose authority policy A;
- B1 authority rows and one-way RW0 projections;
- RW0 composition/status authority;
- canonical B1 parser semantics;
- bounded visible-H2 semantics;
- RW0 fence parser semantics;
- corrected 384-record migration ledger;
- retirement of arbitrary natural-language semantic classification;
- all C2A, lineage, B1, Wire, and Capability production semantics;
- all identities, canonical bytes, budgets, qualification precedence, and
  import direction;
- no source authentication, executable permission, semantic acceptance,
  persistence, provider/runtime/Git/publication authority;
- C/D/E and ES later/external owner seams.

AUDIT PERSPECTIVES

After the provenance gate, use exactly four bounded, non-nesting, read-only
perspectives when available. No child runs tests or modifies files.

1. Live B1 parser anchoring auditor
   - exact owner-module import;
   - no parser import by value;
   - no stale local alias, copied wrapper, fallback, dynamic import, source
     execution, or duplicate grammar;
   - live owner-module attribute lookup on every cross-document parse;
   - import-order stability;
   - no duplicate collection/circular import/public effect;
   - independent expected outcomes for the complete equivalence corpus;
   - post-import owner replacement and stale-local mutants.

2. Closed RW0 fence-ledger auditor
   - exact 27-row closed schema;
   - explicit `family` and `diagnostic`;
   - finite family vocabulary;
   - source node existence;
   - document-hash regeneration;
   - actual/expected real and mutated outcomes;
   - closed key set/order;
   - all required ledger mutants rejected;
   - ledger/checker evidence independent of report-time inference.

3. Closed migration-checker auditor
   - exact corrected 384-record ledger unchanged;
   - disposition-specific closed schemas;
   - `new_node_id` forbidden on non-rename rows;
   - global old/new endpoint uniqueness;
   - no chains;
   - exact sole mapping;
   - opening/final/additions binding;
   - all required mutants, especially
     `duplicate_target_nonrename` and
     `shared_new_endpoint_nonrename`, rejected.

4. Provenance, validation, public-boundary, and authority auditor
   - exact one-entry delta and 29-entry equality;
   - six evidence-root indexes and inventories;
   - final validation and full-suite binding;
   - imports, exports, callers, protected bytes;
   - no document/source/public/authority widening;
   - remaining C/D/E/ES seams.

The parent performs reconciliation, independent external probes, node
comparison, validation, and closeout. Preserve disagreements.

Every finding must include:

```text
ID
type
severity: critical | high | medium | low | observation
current contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect or pre-existing issue
```

REQUIRED SOURCE AND TEST INSPECTION

Inspect the sole changed repository file completely:

```text
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Inspect the protected B1 owner test and owners:

```text
tests/test_rw0_b1_boundaries.py
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md
```

Inspect adjacent protected source/tests needed for non-regression:

```text
.docs/rw0-b2-capability.md
.docs/rw0-b2-wire-protocol.md

src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml

tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py
tests/test_remote_worker_pre_execution_planning_contract.py
```

Inspect additional Coordinator files only for a concrete dependency and record
why. Do not inspect another repository.

HYPOTHESIS A — LIVE OWNER-MODULE PARSER ANCHORING

Independently prove or falsify:

1. The RW0 test imports the B1 owner test module itself through an ordinary,
   deterministic module import.

2. The actual cross-document path resolves the B1 parser through the owner
   module object at each call.

3. No parser function is imported by value.

4. No local stale alias is used by the actual path.

5. No copied parser, fallback parser, dynamic import, source execution, `exec`,
   `eval`, or duplicated B1 grammar exists in the RW0 test.

6. Import order is stable:
   - RW0 owner alone;
   - B1 owner alone;
   - B1 then RW0;
   - RW0 then B1;
   - complete suite.

7. No duplicate collection, circular import, package export, or repository
   effect is introduced.

8. The complete B1 equivalence corpus has independent literal expected
   outcomes:
   - exact canonical projection; or
   - exact finite `b1.registry.*` diagnostic.

9. Direct owner parser and cross path each match the independent expected
   result. Equality only between the two paths is insufficient.

Run external in-memory mutants:

```text
stale local parser bound to every former alias
post-import owner parser replacement
copied fallback parser
cross-only stale projection
owner-module parser missing
owner-module parser replaced with sentinel success
owner-module parser replaced with sentinel diagnostic
import-order permutation
```

The checked tests must kill each applicable mutant for the intended reason.

HYPOTHESIS B — CLOSED 27-ROW FENCE LEDGER

Recover and verify the exact retained closed ledger.

Required schema per row:

```text
schema_id
case_id
document_sha256
family
expected_real_result
actual_real_result
sensitivity_mutant
expected_mutated_result
actual_mutated_result
diagnostic
source_node_id
```

Require:

- exactly 27 rows;
- exact key set and key order;
- no missing/extra key;
- finite `family` values:
  `valid_closer`, `invalid_closer`, `non_opener`;
- exact finite `diagnostic` or literal `success`;
- unique case IDs;
- unique document hashes;
- unique family/mutant/node/hash tuple;
- source node exists exactly once in final node list;
- regenerated document hash matches;
- row family agrees with construction;
- actual outcomes agree with live parser behavior;
- expected/actual real and mutated results agree;
- no report-time inference is needed.

Independently mutate:

```text
missing family
missing diagnostic
unknown family
wrong family
wrong diagnostic
extra field
key reorder
duplicate case ID
duplicate document hash
wrong source node
wrong expected real result
wrong actual real result
wrong expected mutated result
wrong actual mutated result
```

The retained checker must reject every mutant.

HYPOTHESIS C — CLOSED MIGRATION CHECKER

Recover the exact corrected ledger:

```text
384 records

SHA-256:
7dfce2479a0a7e72b37dc2af0181bf2dbf2e11ec209432a5b551ee4057f2a87e
```

Verify the checker enforces disposition-specific exact schemas.

Rename record:

```text
old_node_id
new_node_id
category
disposition
purpose
opening_present
final_present
```

Non-rename records:

- exact accepted non-rename schema;
- `new_node_id` forbidden;
- no alternate target field;
- no extra key.

Global rules:

```text
all old_node_id unique
all rename new_node_id unique
no rename target equals any other record old_node_id
no migration chains
exactly one rename
exact accepted old/new mapping
old once opening and absent final
new absent opening and once final
new once additions
every opening owner node exactly one record
exact arithmetic
```

Run all required mutants, including:

```text
missing new_node_id
wrong new_node_id
duplicate rename target
shared old endpoint
shared new endpoint
new_node_id on non-rename
duplicate_target_nonrename
shared_new_endpoint_nonrename
unknown extra key on rename
unknown extra key on non-rename
rename count 0
rename count 2
opening owner omitted
opening owner duplicated
wrong opening_present
wrong final_present
target present opening
target absent final
target absent additions
```

Require all to reject for the intended closed-schema or endpoint rule.

HYPOTHESIS D — FINAL VALIDATION AND PROVENANCE

Verify:

- selected red gate and repaired gate;
- focused final groups;
- final node collection;
- full suite attempt 001 only;
- exact JUnit-to-node mapping;
- all attempt records complete;
- one-path final repository delta;
- other 29 candidate entries exact;
- all six evidence roots unchanged;
- self-excluding final evidence index complete;
- no hidden retry, missing envelope, or post-index change.

NODE IDENTITY

Run one candidate collection and one clean external `git archive HEAD`
collection under identical isolated conditions.

Require:

```text
candidate:
5057 unique nodes

candidate ordered-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

clean HEAD:
4655 unique nodes

clean HEAD ordered-list SHA-256:
f36822a60056ec3d110956de561202b737662c9d22cd0dd82c4cdad6c7cef69f
```

Also compare with:

```text
repair opening:
5051 nodes
5e2a6c5f9e603895b9f9daf021ccc36a9915a8b923ddb7fe8c287b49325bb1aa

reset architecture opening:
5114 nodes
f3d83ce79954e7296b9406da6fcaa84a6676284d9504c7a9c30292d92c8fe8ae
```

Report exact:

```text
candidate/HEAD intersection
candidate-only
HEAD-only
5051→5057 additions/removals/renames
5114→5057 migration reconciliation
outside-owner relative order
owner ledger reconciliation
```

Do not require HEAD-only zero if the intentional owner-test migration explains
it; require every difference to reconcile with the corrected ledger and the
post-repair additions ledger.

INDEPENDENT VALIDATION

Only after source/test inspection, external mutants, closed-ledger audit, and
provenance inspection are green enough, run serially beneath the audit root.

For every child:

```text
umask 022 before launch
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Run:

1. exact retained final selected causal set;
2. B1 owner:
   ```text
   tests/test_rw0_b1_boundaries.py
   ```
3. RW0 owner:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   ```
4. B1 compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```
5. Capability/Wire compatibility:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
6. architecture/status/static:
   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

Every credited run must have:

```text
return code 0
zero failures/errors/skips/xfails/warnings
empty stderr
parseable JUnit
zero duplicate/unmapped cases
matching caller/child umask
unchanged candidate fingerprint
```

If all inspection and focused validation remain green, run the complete
repository suite exactly once independently with quiet rendering.

Require:

```text
5057 collected
5057 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

If a deterministic material blocker is found first, the full suite may be
withheld. State that explicitly. Never repair candidate bytes.

PUBLIC, IMPORT, PRIVACY, AND AUTHORITY BOUNDARY

Require:

- no documentation change;
- no production source change;
- no package-root export;
- no reverse production import;
- no production caller change;
- no dependency, SQL, migration, schema, catalog, StateStore, or WriterSession
  change;
- no filesystem, process, network, provider, Bridge, ES-call, Git,
  publication, or runtime effect;
- registry architecture and facts unchanged;
- no second registry writer;
- Capability remains private pure supplied-fact semantics;
- source refs/digests remain unauthenticated evidence;
- no executable permission, semantic acceptance, persistence, or runtime
  authority;
- C/D/E and ES remain later/external owners.

CLOSEOUT

After removing only audit-created transient artifacts:

1. rerun the exact recipe twice with safe sink redirection;
2. require exact equality to the opening final target;
3. require the same manifest, complete outputs, textual diff, file count,
   per-path hashes, and topology;
4. compare all six pre-existing evidence-root opening/closing inventories;
5. verify no operation, lock, staged/unmerged path, cache, bytecode, database,
   journal, archive, build, recorder, or generated-manifest residue;
6. retain all audit evidence beneath the new mode-0700 root;
7. make retained audit files regular, operator-owned, and mode 0400;
8. create a self-excluding evidence index.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low candidate defect remains;
- `BLOCK` for any repairable parser ownership, test, ledger, migration checker,
  evidence, validation, privacy, public-boundary, or authority defect;
- `REJECT` only for a fundamental accepted-architecture contradiction;
- `AUDIT_PROVENANCE_MISMATCH` only for target/evidence identity failure before
  correctness judgment.

If `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_FINAL_AUDIT_FINDINGS_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or create a PR.

FINAL REPORT

Include:

1. opening and closing identity;
2. exact provenance and one-entry delta;
3. all six pre-existing evidence indexes and final repair evidence;
4. four audit perspectives and disagreements;
5. severity-ranked finding ledger;
6. live B1 parser anchoring result and mutation ledger;
7. closed 27-row fence ledger result;
8. closed migration-checker result;
9. migration reconciliation and node comparison;
10. final validation evidence and independent focused/full validation;
11. public/import/privacy/authority assessment;
12. closeout guards;
13. separate provenance, validation, and implementation confidence.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
