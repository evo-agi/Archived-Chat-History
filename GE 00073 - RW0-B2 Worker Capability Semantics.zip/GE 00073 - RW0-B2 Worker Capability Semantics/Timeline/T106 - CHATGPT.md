## Engineering disposition

`REPORT_EVIDENCE_INCOMPLETE` is an **evidence-chain failure, not a verdict against the repair**. The repository may contain the completed two-file repair, but Codex could not locate or safely verify one or more records required to bind the success token to exact bytes and validation.

Do not:

- start the fresh independent audit;
- repeat the implementation;
- rerun tests speculatively;
- stage or commit.

First determine exactly what is missing and whether it can be reconstructed from immutable retained evidence.

Continue in the **same implementation conversation** with this read-only diagnostic prompt:

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Capability_Owner_Oracle_Reset_Repair_Evidence_Gap_Diagnostic_Prompt.txt

Size:
10,324 bytes

SHA-256:
fa6ecaeb738c1b584aacc7fa64221d4053df1407db588f7d5cc14afeb2cb3d31
```

The prompt authorizes no repository changes and no test execution. It requires Codex to identify the first missing record and classify every required artifact as:

```text
PRESENT_VERIFIED
PRESENT_INCOMPLETE
DERIVABLE_READ_ONLY
MISSING_REQUIRES_VALIDATION_RERUN
MISSING_REQUIRES_IMPLEMENTATION_RERUN
NOT_APPLICABLE
```

It specifically checks for:

- a retained final canonical manifest;
- the exact two-file path identities;
- B1 parser-equivalence and H2-location evidence;
- the RW0 fence real-versus-sensitivity ledger;
- the corrected migration ledger with explicit `old_node_id` and `new_node_id`;
- opening and final node lists;
- focused and full-suite JUnit evidence;
- before/after candidate fingerprints;
- final guards, cleanup, and a self-excluding evidence index.

The diagnostic must return one operational disposition:

```text
EVIDENCE_ONLY_CLOSEOUT_REGENERATION_READY
VALIDATION_EVIDENCE_RERUN_REQUIRED
IMPLEMENTATION_RERUN_REQUIRED
LIVE_CANDIDATE_BYTES_DRIFTED
REPORT_PROVENANCE_MISMATCH
EVIDENCE_LOSS_UNRECOVERABLE
```

### Decision path

If the result is `EVIDENCE_ONLY_CLOSEOUT_REGENERATION_READY`, the repository and validation evidence are intact; only aggregate reports or indexing must be regenerated read-only.

If it is `VALIDATION_EVIDENCE_RERUN_REQUIRED`, the source repair remains intact, but the exact missing validation subset must be rerun under a separately authorized continuation. Do not automatically repeat the full suite.

`IMPLEMENTATION_RERUN_REQUIRED` is appropriate only if the two repaired test files do not actually contain the claimed changes.

`LIVE_CANDIDATE_BYTES_DRIFTED` means the prior success token is stale and the changed paths must be identified before any further work.

### Source

Codex’s `REPORT_EVIDENCE_INCOMPLETE` response supplied in this turn.

**Confidence:** High that evidence diagnosis is the correct next step. Confidence in the repair itself remains unassigned until Codex identifies whether the missing material is merely a closeout artifact or substantive validation evidence.
