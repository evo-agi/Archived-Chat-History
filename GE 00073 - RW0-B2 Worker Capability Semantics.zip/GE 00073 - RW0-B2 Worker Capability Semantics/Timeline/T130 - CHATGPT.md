## Engineering disposition

**Retry only the external clean-commit suite under a neutral, pre-screened path. Do not repair the candidate, rerun the live suite, or return to the commit gate.**

The result isolates another harness-path problem:

- The **live suite passed 5,057/5,057** with complete pre/post fingerprints.
- The external clean repository remained byte- and tree-stable.
- The clean suite’s **44 failures were all path-sensitive redaction tests**.
- The mandated root name itself contained the forbidden fragment `binding`.
- Source repository bytes, real index, and both repositories’ pre/post fingerprints remained unchanged.

This does not establish a candidate defect. The clean candidate was executed from an invalid test environment whose absolute path violated the same privacy grammar the tests are intended to enforce.

The prior clean run remains useful evidence for tree construction and repository isolation, but it cannot be credited as clean-state validation.

## Minimum continuation

The next operation should:

1. preserve the successful V2 live-suite record;
2. preserve the failed V2 clean run as a historical harness-path failure;
3. derive the exact forbidden-path grammar from the 44 failing tests;
4. create a short neutral root such as:

   ```text
   /private/tmp/gv3.XXXXXX
   ```

5. pre-screen every path visible to pytest using the exact owning checker;
6. create a fully external clean repository and object database under a neutral child path;
7. rerun **only one clean full suite**;
8. bind it to the already credited live suite;
9. seal new final provenance and a self-excluding index.

No node collection, focused validation, mutation probe, implementation work, or live-suite rerun is needed.

## Clean-path retry handoff

Send this complete replacement prompt to the **same write-enabled Capability implementation conversation**:

:chatgpt-content-reference{index="0"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Commit_Compatibility_Validation_Binding_Reset_V3_Clean_Path_Retry_Prompt.txt

Size:
17,634 bytes

SHA-256:
9d22cf2dade9172ef11f8df33f213a0a15018ef8e3d179cb829765382e630a80
```

The prompt is bound to the failed V2 reset:

```text
V2 evidence root:
/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset2.Udjr4a

V2 evidence index:
107 rows
21,875 bytes

SHA-256:
a3abd5e9252da88623ab3285a6f560b7b71f151f672d25f6236c3779f806abe9
```

It requires the clean child to use short neutral paths:

```text
r       external repository
t       TMPDIR
p       PYTHONPYCACHEPREFIX
b       basetemp
j.xml   JUnit
```

Before setup, Codex must inspect the exact 44 failing tests, recover their path-rejection rules, and pass every child-visible path through the same checker. It may not weaken or monkeypatch those redaction rules.

The successful clean run must establish:

```text
5,057 collected
5,057 passed
0 failures
0 errors
0 skips
0 xfails
0 warnings
empty stderr
```

It must also preserve:

```text
external clean tree:
52e32a55dc2e6b023b669810fb244301807f7618

source real index:
unchanged

source object database:
unchanged

source pre/post fingerprints:
identical

external pre/post fingerprints:
identical
```

The required result remains:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_VALIDATION_BINDING_RESET_COMPLETE_READY_FOR_FRESH_REAUDIT
```

After that result, run a fresh read-only audit using the unchanged candidate plus the credited V2 live suite and V3 clean suite. The commit gate remains blocked until that audit returns `ACCEPT`.

### Source

- Codex V2 validation-binding-reset failure report supplied in this turn.

**Confidence:** Very high that this is an external path-selection defect rather than a repository defect; high that one neutral-path clean-suite rerun is the minimum sufficient continuation.

Some earlier uploaded project attachments are no longer accessible in the current file surface. They are not needed for this continuation; re-upload them only if their contents need to be inspected again.
