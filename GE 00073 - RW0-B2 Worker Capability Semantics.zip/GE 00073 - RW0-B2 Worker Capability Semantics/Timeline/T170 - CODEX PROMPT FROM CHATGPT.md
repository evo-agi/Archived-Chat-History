PROMPT_ID

RW0_B2_CAPABILITY_G15_EVIDENCE_RESTORATION_ACCEPTANCE_AUDIT_V1

TITLE

Coordinator RW0-B2-Capability — fresh evidence-restoration acceptance audit
after G15 technical acceptance and audit-created G14 bytecode contamination

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated acceptance audit in a new Codex conversation.

This audit does not repair candidate bytes and does not repeat the complete
technical audit unless a retained-evidence discrepancy is found.

The purpose is to:

1. independently verify the complete G15 technical audit;
2. preserve the contaminated original G14 root unchanged;
3. materialize and verify a pristine canonical snapshot containing exactly the
   G14 indexed entries;
4. close the prior audit-process defect without rewriting historical evidence;
5. decide commit/push/PR readiness for the unchanged candidate.

No repository mutation, formatting, cleanup of candidate bytes, staging in the
source repository, commit in the source repository, push, pull request, merge,
tag, release, deployment, remote service contact, provider/live-host contact,
product worker/model invocation, database mutation, dependency installation,
migration, or supporting-repository inspection is authorized.

Do not delete, move, chmod, clean, or otherwise modify:

```text
/private/tmp/g14.OxZUD3
/private/tmp/g15.leaPhd
```

Audit-created files may be written only beneath one new operator-owned,
non-symlink, mode-0700 root:

```text
/private/tmp/g16.XXXXXX
```

CRITICAL BYTECODE RULE

Every Python process used by this audit—including bootstrap, parent helpers,
index readers, path-checker loading, snapshot materialization, pytest, and
closeout—must be launched with both:

```text
python3 -B
PYTHONDONTWRITEBYTECODE=1
```

Every Python process must also use:

```text
PYTHONPYCACHEPREFIX=<unique path beneath G16>
```

Do not import or execute a Python file directly from G14 or G15.

When a retained Python helper is needed:

1. verify its indexed bytes;
2. copy those exact bytes into G16;
3. load or execute only the G16 copy;
4. use `-B`, `PYTHONDONTWRITEBYTECODE=1`, and the G16 pycache prefix.

Any write outside G16 is an audit-process failure.

CRITICAL INLINE OUTPUT RULE

Print the complete operative report inline in the Codex chat.

Do not return only:

- a verdict token;
- a short summary plus `/private/tmp` links;
- “see report”;
- file paths containing material findings.

Evidence paths may be supplementary only after all exact identities,
verification results, findings, and the readiness decision have appeared
inline.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Determine whether the unchanged assurance-reset candidate is ready for the
commit/push/pull-request gate.

G15 established:

```text
candidate technical checks:
green

candidate defects:
none

permanent boundary file:
19/19

Capability complete:
56/56

B1/Wire:
461/461

architecture/status/static:
907/907

independent live complete suite:
5059/5059

independent clean committed suite:
5059/5059

external one-predicate mutants:
191/191 credited

A/B/C:
green

node migration:
green

public/privacy/authority:
green
```

G15 returned BLOCK only because the audit itself created two unindexed bytecode
entries in G14 after G14 had passed its opening inventory.

The new audit must not interpret that audit-process contamination as a candidate
defect.

EXPECTED LIVE REPOSITORY IDENTITY

Require at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644

candidate tree:
727fb0ecf94680b64fed5e1bb2bccecccde38e4d
```

Require:

```text
git diff --check:
clean

cached diff:
empty

Git operation or lock:
none

candidate symlink/special path:
none

thirty-first changed path:
absent

repository cache/bytecode/database/journal/archive/build/generated-manifest/
recorder residue:
none
```

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

FINAL CANDIDATE TARGET

Final boundary file:

```text
tests/test_rw0_b2_capability_boundaries.py

type:
regular

kind:
untracked

mode:
0644

physical lines:
765

size:
36340 bytes

SHA-256:
ff9d9c6df68e6bb17d974c2f2abb0395735d0ead95bc79179daf7fbc01bea351
```

Final candidate manifest:

```text
rows:
30

size:
6430 bytes

SHA-256:
abf1e627b7eb3030bddbb308861388e435e113f9d53dbacf3f344097385c0c32
```

Final node identity:

```text
count:
5059

ordered SHA-256:
72ca14d20ff8e95384a8fa06b595227fb45bb7884aac295bbe4ae06ac761a0aa
```

Final B/C tree:

```text
727fb0ecf94680b64fed5e1bb2bccecccde38e4d
```

G14 AUTHORITATIVE INDEXED EVIDENCE

Original G14 root:

```text
/private/tmp/g14.OxZUD3
```

Required self-excluding index:

```text
/private/tmp/g14.OxZUD3/evidence_index.jsonl

rows excluding itself:
549

directory rows:
90

regular-file rows:
459

size:
94601 bytes

SHA-256:
91764a62fb6db27d426a4a86415b29337cd1dff3710c8528160e0e4755dc46b2
```

Required G14 report:

```text
/private/tmp/g14.OxZUD3/final_report.md

SHA-256:
b399e411af53cb57b7575bc7479d0ba8207e17abea98bcd6f8405b7a91de901d
```

G14 CONTAMINATION LEDGER

At G15 opening, G14 had exactly the indexed content.

During G15, the audit imported the G14 path checker without suppressing bytecode
and created exactly:

```text
/private/tmp/g14.OxZUD3/__pycache__

type:
directory

mode:
0755

indexed:
no
```

and:

```text
/private/tmp/g14.OxZUD3/__pycache__/path_guard.cpython-313.pyc

type:
regular

mode:
0600

size:
8076 bytes

SHA-256:
7f727b8cd3343c0decc8a6dc4130d19e077f59def920f21cee5d3213038657d8

indexed:
no

recorded creation time:
2026-09-26T17:46:38Z
```

The two entries are audit-process contamination. They are not G14 indexed
evidence and are not candidate bytes.

Do not remove them. Preserve the original G14 root exactly as currently found.

G15 TECHNICAL AUDIT EVIDENCE

G15 root:

```text
/private/tmp/g15.leaPhd
```

Required G15 report:

```text
/private/tmp/g15.leaPhd/final_report.md

size:
25443 bytes

SHA-256:
3953312948d6c495e2e3b79a233ae0103db5dfc8d759e52454eb002a05cb4c1c
```

Required G15 self-excluding index:

```text
/private/tmp/g15.leaPhd/evidence_index.jsonl

rows excluding itself:
2707

directory rows:
302

regular-file rows:
2405

size:
438522 bytes

SHA-256:
0e91f20d8603082dc8b7af80bb40d8c4e0035555fafb5ab45c40742725b292d9
```

Required G15 technical results:

```text
external one-predicate mutants:
191/191 credited

A/B/C:
3/3 new tests in every state
19/19 boundary file in every state
projection A == B == C
B tree == C tree ==
727fb0ecf94680b64fed5e1bb2bccecccde38e4d

node migration:
5150 - 94 + 3 = 5059
final ordered hash:
72ca14d20ff8e95384a8fa06b595227fb45bb7884aac295bbe4ae06ac761a0aa

retained focused:
19
56
461
907

retained live suite:
5059/5059

retained clean suite:
5059/5059

independent focused:
19
56
461
907

independent live suite:
5059/5059

independent clean suite:
5059/5059
```

PROVENANCE GATE

Before correctness or readiness judgment:

1. create one G16 root;

2. record opening source identity;

3. safely `lstat` G14 and G15 path components;

4. verify the G14 index identity;

5. verify every one of the 549 G14 indexed rows against the current original
   G14 root;

6. require no indexed row changed or disappeared;

7. enumerate all current G14 paths outside the index;

8. require the unindexed set to be exactly:

   ```text
   __pycache__
   __pycache__/path_guard.cpython-313.pyc
   ```

9. require the two extras to match the contamination ledger above;

10. verify the G15 index and every indexed row;

11. require no unindexed or special G15 entry;

12. verify live source identity, final manifest, boundary-file identity, final
    nodes, and every path outside the candidate;

13. locate and verify the exact recipe source:

   ```text
   /private/tmp/g5.hiLE2y/exact_recipe_source.py

   type:
   regular

   mode:
   0400

   size:
   3945

   SHA-256:
   db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
   ```

14. copy the recipe to G16 under `umask 077`, set mode `0400`, and execute only
    the G16 copy with bytecode disabled;

15. run the exact recipe twice with safe sink redirection;

16. require exact equality to the final candidate manifest and complete output.

If any indexed G14 or G15 row differs, stop with:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not attempt repair or regeneration.

CANONICAL G14 SNAPSHOT MATERIALIZATION

Materialize a pristine, deterministic snapshot beneath G16:

```text
<G16>/g14_indexed_snapshot/
```

Rules:

1. source of truth is only the verified G14 index;

2. copy exactly the 549 indexed entries;

3. also copy `evidence_index.jsonl` itself after verifying its identity;

4. do not copy any unindexed path;

5. preserve each indexed type and mode;

6. copy regular-file bytes exactly;

7. create directories exactly as indexed;

8. do not follow symlinks; the indexed G14 set must contain none;

9. snapshot must contain:
   - 90 indexed directories;
   - 459 indexed regular files;
   - one copied self-excluding index file;
   - zero additional entry;
   - zero symlink or special entry;

10. verify every copied indexed row against the original index;

11. verify the copied index retains its original bytes and SHA-256;

12. create and retain a materialization ledger mapping every indexed source
    path to copied path, type, mode, size, and SHA-256;

13. mark the snapshot as:

    ```text
    deterministic materialization of G14 indexed evidence
    not a rewrite of the original G14 root
    not a reconstruction of unindexed historical metadata
    ```

14. after materialization, make snapshot directories `0700` only when that is
    the indexed directory mode; otherwise preserve the indexed mode. Preserve
    every indexed file mode exactly.

Do not execute or import Python from the original G14 root.

When the G14 path checker is needed, use only its verified G16 snapshot copy and
run with bytecode disabled.

G14 ORIGINAL-ROOT CONTINUITY

At G16 opening and closeout, inventory the original G14 root with `lstat`.

Require:

```text
all 549 indexed entries unchanged
the two contamination entries unchanged
no third unindexed entry
no path removal
no mode/content change
```

The original contaminated root must remain byte-for-byte/path-for-path stable
during this audit.

G15 TECHNICAL AUDIT VERIFICATION

Independently verify, from G15 indexed evidence:

1. all 191 mutant records exist and reconcile with the summary;

2. canonical controls passed;

3. every credited mutant produced:
   - expected finite diagnostic;
   - exactly one selected JUnit failure;
   - zero JUnit errors/skips;
   - empty stderr;
   - unchanged external copy after restoration;

4. A/B/C records and projections are exact;

5. node migration and clean-HEAD reconciliation are exact;

6. retained and independent focused JUnits are exact;

7. retained and independent complete-suite JUnits each map exactly to all 5,059
   final nodes;

8. live and clean suites are distinct state validations, not retries;

9. G15 source pre/post identities are exact;

10. no candidate defect was recorded;

11. G15 verdict was controlled solely by G14 contamination.

Do not simply trust the prose report; validate the indexed records.

TARGETED FRESH CHECKS

Run only these new G16 checks unless a discrepancy requires more:

1. live three new permanent contract tests:

   ```text
   3/3 expected
   ```

2. live complete boundary file:

   ```text
   19/19 expected
   ```

3. external clean committed boundary file:

   ```text
   19/19 expected
   ```

4. external AST/literal projection in live and clean state:

   ```text
   exact equality
   SHA-256:
   49b36aa9848d66d3e46759ee6dc20d6305637a954fe7e56b14c6e14fc98b8611
   ```

5. independent current node collection:

   ```text
   5059 nodes
   ordered SHA-256:
   72ca14d20ff8e95384a8fa06b595227fb45bb7884aac295bbe4ae06ac761a0aa
   ```

Use the required isolated pytest environment:

```text
umask 022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
PYTHONPYCACHEPREFIX=<unique G16 path>
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct G16 --basetemp
distinct G16 --junitxml
serial execution
```

Pre-screen every child-visible path using only the G16 snapshot copy of the
verified path checker.

Do not rerun the 191-mutant corpus or either 5,059-test complete suite unless a
retained-evidence discrepancy is found. G15 already independently executed
those checks against the unchanged candidate.

If a discrepancy is found, stop and report it. Do not silently expand this
audit into another implementation or replay engagement.

ASSURANCE-BOUNDARY JUDGMENT

Apply the frozen responsibility split:

Permanent tests own finite product/repository assertions.

Independent audit owns:

```text
external one-predicate mutants
A/B/C
clean-commit validation
AST/static review
```

Git/provenance owns coordinated changes to tests and literals.

Do not classify arbitrary coordinated mutation of the test and its oracle
inside one interpreter as a candidate defect.

PUBLIC, PRIVACY, AND AUTHORITY REVIEW

Independently confirm:

- no package-root Capability export;
- no unauthorized production importer or caller;
- no production subprocess/process/Git/network/provider/runtime effect;
- no dependency, SQL, migration, schema, catalog, StateStore, or WriterSession
  widening;
- no source-authentication, permission, acceptance, persistence, or runtime
  authority;
- RW0-C/D/E and Execution Substrate ownership unchanged.

CLOSEOUT

Before verdict:

1. verify source repository identity unchanged;

2. verify G15 root unchanged;

3. verify original G14 root still has:
   - all 549 exact indexed entries;
   - exactly the two known contamination entries;
   - no new entry;

4. verify the G16 canonical G14 snapshot remains exact;

5. rerun the exact recipe twice with safe sink redirection;

6. require exact final manifest/output equality;

7. remove only G16-created transient pytest/external-repository paths;

8. retain:
   - source opening/closing records;
   - original-G14 opening/closing inventories;
   - contamination ledger;
   - canonical snapshot and materialization ledger;
   - G15 record verification;
   - targeted fresh-check records;
   - recipe records;
   - final report;

9. make retained G16 directories mode `0700` and retained files mode `0400`;

10. create a self-excluding G16 evidence index;

11. print the complete report inline.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only if:
  - the candidate has no Critical, High, Medium, or Low defect;
  - G15 technical evidence verifies;
  - the candidate remains unchanged;
  - G14 indexed evidence is exact;
  - the only G14 extras are the two known audit-created entries;
  - the G16 canonical snapshot is exact;
  - G16 itself causes no write outside G16.

- `BLOCK` for any repairable candidate, evidence, audit-process, public,
  privacy, or authority defect discovered in this engagement.

- `REJECT` only for a fundamental accepted-architecture contradiction.

- `AUDIT_PROVENANCE_MISMATCH` only for mandatory indexed evidence or candidate
  identity failure before correctness judgment.

If `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_ASSURANCE_RESET_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or create a PR.

FINAL INLINE REPORT

Use:

```text
# Verdict

# Opening and closing source identity

# G14 contamination and canonical snapshot

# G15 technical-audit verification

# Targeted fresh checks

# Candidate and node provenance

# Assurance-boundary judgment

# Public, privacy, and authority boundary

# Closeout and G16 evidence index

# Confidence
```

State explicitly:

```text
The original G14 root was not modified.
The two G14 extras are preserved audit-process evidence.
The canonical G14 snapshot contains only indexed G14 evidence.
No historical metadata was reconstructed.
G15 supplies the complete technical independent audit.
G16 supplies fresh evidence-restoration and acceptance closeout.
```

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
G14_ORIGINAL_ROOT_NOT_MODIFIED
G15_ROOT_NOT_MODIFIED
HISTORICAL_METADATA_NOT_RECONSTRUCTED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
