## Engineering disposition

**The `BLOCK` is valid, but another incremental tests-only repair is the wrong next step.**

The latest audit did more than find a few missing phrases:

- **81/90** independently generated RW0 contradictions escaped detection.
- **60/60** independently generated B1 contradictions escaped detection.
- All **12 truthful negated, historical, scoped, or unrelated controls** were rejected.
- The Markdown parser still misclassifies fences, Setext headings, Unicode line boundaries, and EOF behavior.
- **22 test nodes** were byte-identical aliases with different names.

That combination means the current tests are neither complete nor sound. Adding more keywords, negation cases, placements, and paraphrases would turn the test suite into an increasingly brittle natural-language inference engine.

This is consistent with the earlier independent audit history: production behavior and authority boundaries remained sound while the remaining defects were in the test oracles rather than the implementation.  The direct B1 and RW0 findings were already classified as test-oracle completeness defects over correct live documents. 

## Recommended reset

Stop trying to prove the meaning of arbitrary prose.

The durable target should be:

1. **One visible, machine-enforced current-contract registry inside each owning document.**
   - B1 owns its own current facts.
   - The RW0 phase-entry document owns current B/C/D/E/ES status.
   - No separate JSON/YAML file becomes a competing source of truth.

2. **A small exact parser for that registry.**
   - Unique heading and marker pair.
   - Exact finite rows and field order.
   - Exact strings and integer values.
   - Duplicate, relocation, missing-row, wrong-value, and hidden/fenced-copy mutants.
   - No claim that tests understand arbitrary semantic equivalence in surrounding prose.

3. **An explicit prose policy.**
   - The registry is the sole machine-authoritative current-status projection.
   - Surrounding prose is explanatory.
   - Tests may enforce a small reserved vocabulary or marker discipline, but must not claim complete natural-language contradiction detection.

4. **A deliberate test-node migration.**
   - The 209 latest oracle nodes are not protected merely because they exist.
   - Corpus-specific, duplicate, and false-positive-prone nodes should be removed or replaced.
   - The replacement must be audited for structural causality, not parameter volume.

This changes the contract-test architecture and probably adds visible registry blocks to the two governing documents. It therefore requires a design freeze before another write prompt. The project protocol calls for architecture/test planning first, then parent-only implementation, then a fresh independent audit.  Any changed bytes must return through implementation and re-audit before the commit gate. 

## Next action

Start a **new read-only Codex reconnaissance conversation** with this prompt:

:chatgpt-content-reference{index="2"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Owner_Oracle_Reset_Reconnaissance_Prompt.txt

Size:
16,017 bytes

SHA-256:
59d4ef9d89cc837ff9728b36c69d32a8c813d01325212c8d7389b06b40fa4d35
```

The prompt requires four read-only perspectives and freezes:

- the exact B1 current-contract registry;
- the exact RW0 component/status registry;
- whether the registry is a visible table or line-oriented block;
- finite Markdown and marker grammar;
- the authority of registry versus prose;
- removal or replacement treatment for the 209 flawed nodes;
- the exact implementation touched-file ceiling;
- validation, provenance, audit, and stop conditions.

It explicitly forbids an implementation prompt during reconnaissance.

The required successful disposition is:

```text
RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_READY
```

Until that result exists:

```text
COMMIT_GATE_BLOCKED
ANOTHER_KEYWORD_OR_PARAPHRASE_REPAIR_NOT_RECOMMENDED
PRODUCTION_SOURCE_CHANGE_NOT_JUSTIFIED
CURRENT_GOVERNING_FACTS_UNCHANGED
```

### Sources

- Latest Codex audit response supplied in this turn.
- Earlier independent audit separating correct production semantics from defective B1 and RW0 test oracles.  
- Governed Execution reconnaissance, implementation, repair, and re-audit protocol.  

**Confidence:** High that the current natural-language oracle design should be retired; high that production code should remain protected; medium-high that an embedded structured registry can keep the eventual implementation boundary to the two owner documents and their two direct tests, pending live-repo reconnaissance.
