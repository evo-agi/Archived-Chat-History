PROMPT_ID

RW0_B2_CAPABILITY_FINAL_REAUDIT_FINDINGS_REPAIR_INDEPENDENT_AUDIT_V1

TITLE

Coordinator RW0-B2-Capability — fresh independent audit of the final six-path
repair, exact 30-file candidate, and recovered validation/provenance evidence

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated independent audit.

Use a new Codex conversation. Do not use the implementation conversation.

The audit parent and every audit subagent are read-only. No repository
mutation, formatting, cleanup of candidate bytes, dependency installation,
staging, commit, push, PR, merge, tag, release, deployment, remote/service/
provider/host contact, product worker/model invocation, database mutation,
migration, or supporting-repository inspection is authorized.

Audit-created probes, clean external HEAD archives, pytest outputs, and
provenance records may be written only beneath one new external mode-0700 audit
root.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Determine whether the exact recovered final candidate closes the four findings
from the preceding fresh re-audit without weakening accepted semantics,
authority boundaries, tests, or provenance:

```text
RW0B2-AUD-002-R1
  Capability error construction, exact reason intake, inherited
  BaseException state, and honest external-chaining boundary

B1-REAUDIT-001 / RW0B2-AUD-007
  causal four-mode reconstruction matrix across all thirteen B1 relations

B1-REAUDIT-002
  complete B1 owner-region regression oracle for stale retrieval and consumer
  claims

RW0-STATUS-REAUDIT-001
  complete RW0 current-status region oracle for additive future/blocked B prose
```

Do not reopen the accepted B1, Wire, Capability, C2A, or lineage architecture
unless the candidate proves a fundamental contradiction.

EXPECTED LIVE IDENTITY

Require at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate modes:
all regular 0644
```

Require no Git operation, lock, `git diff --check` failure, repository cache,
bytecode, database, journal, archive, build output, generated repository
manifest, recorder residue, or thirty-first changed path.

Do not fetch, switch, reset, clean, stash, rebase, or merge.

FINAL AUDIT TARGET

Retained final implementation evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-final-repair.jSsN6n
```

Retained canonical manifest:

```text
/private/tmp/ge-coordinator-rw0-b2-final-repair.jSsN6n/final_closeout/recipe_1.manifest.json
```

Required final identities:

```text
canonical-manifest size:
6430 bytes

canonical-manifest SHA-256:
132b7473151706f7bb257aea44efdefad04b7e2e2dab8f3ef5486e46a6e6372f

tracked textual-diff SHA-256:
c3ccbcaa17c6a1140529712b414f8a002a18a76d4b8d8733ca6d63bc2deab821

complete recipe stdout size:
6663 bytes

complete-output SHA-256:
1606765a198803686184f4fff3da59f5e8a00e2d07c80744ac6a0459d46b72f4

file count:
30

final pytest node count:
4761

final ordered-node-list SHA-256:
e9b1d63bc8b1545e96d9569c8a59304268c04e0a702e529ecf9f35b74e83c2d8
```

Required retained validation records include:

```text
/private/tmp/ge-coordinator-rw0-b2-final-repair.jSsN6n/final_validation/08_final_collection/node_ids.txt

/private/tmp/ge-coordinator-rw0-b2-final-repair.jSsN6n/final_validation/08_final_collection/summary.json
  size: 830
  SHA-256:
  48793d02f5d1efbc1532bd9a9a84b01bf8c09e8694e18370b001981a97b0f155

/private/tmp/ge-coordinator-rw0-b2-final-repair.jSsN6n/final_validation/10_full_suite_attempt_002/summary.json
  size: 653
  SHA-256:
  cd4b0062bd46ba126bcb8dcea636eb78edac1b809c6c941a8cceb278e4910c3e

/private/tmp/ge-coordinator-rw0-b2-final-repair.jSsN6n/final_validation/10_full_suite_attempt_002/junit.xml
  size: 1002555
  SHA-256:
  bc43aefd86e7f830176524e863e82d5efde663982ec2cbb79d48c3cb5ebedbca

/private/tmp/ge-coordinator-rw0-b2-final-repair.jSsN6n/aggregate_identities.json
  size: 14498
  SHA-256:
  ac3d562a049363c5d62a9a1211183baf149612094b5c1a09db4298b1d19b353a
```

OPENING REPAIR TARGET

The six-path repair began from:

```text
manifest:
/private/tmp/ge-coordinator-rw0-b2-findings-repair.GZaQQ1/final_recipe_1_manifest.json

canonical-manifest SHA-256:
527ba2c27d94a0361912210eb80c718762fcc4a4df1d9b503524a8e91af115ac

tracked textual-diff SHA-256:
6133bfa7994b12f63769a0d9a8843bb06296f2cc1185cc4c305b43c3c51ae5ee

complete-output SHA-256:
ea927882df7952ff31384d3cc42b5fe60dcca65127125e4e99f6ee4fc00cff8e

opening pytest nodes:
4743

opening ordered-node-list SHA-256:
05fea81edde4fde4cf5fcb15a8e2c397eead7410688665b1500c0cb09970a064
```

Exactly these six entries must differ from that opening manifest:

```text
.docs/rw0-b2-capability.md
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The other twenty-four opening entries must be byte-, kind-, type-, mode-, size-,
and classification-identical.

IMPLEMENTATION-EVIDENCE LIMITATION

The final implementation evidence root has no pre-existing self-excluding
per-file evidence index. At recovery it contained only operator-owned regular
files/directories and no symlink, FIFO, socket, or device, but retained file
modes were mixed:

```text
163 files mode 0400
20 files mode 0600
57 files mode 0644
```

This is an evidence-hardening limitation, not automatic acceptance or automatic
candidate rejection.

The audit must:

1. safely lstat every path component before reading the root;
2. create its own opening inventory of the final implementation evidence root,
   recording relative path, type, owner, group, mode, size, and SHA-256 for
   regular files;
3. never modify that root;
4. compare the inventory at closeout;
5. give correctness credit only to specifically verified records and
   independent reruns;
6. report the lack of an implementation-created index as an observation unless
   required evidence is missing, unsafe, or changes during the audit.

If a mandatory manifest, recipe source, final node list, final summary, or
complete-suite JUnit cannot be safely located and verified, return
`AUDIT_PROVENANCE_MISMATCH` before correctness judgment.

PRIOR AUDIT EVIDENCE

The preceding independent-audit root is:

```text
/private/tmp/ge-coordinator-rw0-b2-fresh-reaudit.CEvapw
```

Its self-excluding index is:

```text
/private/tmp/ge-coordinator-rw0-b2-fresh-reaudit.CEvapw/evidence_index.jsonl

size:
57774 bytes

SHA-256:
a4d6ebbfe2195c063c6af4252890fd42d7dafed13859068d0dfb2522dd5ad7c1

rows excluding itself:
294
```

Verify it safely and preserve it unchanged.

EXACT RECIPE SOURCE

Decode this base64 only beneath the new audit root. Require exactly 3,945 bytes
and SHA-256
`db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`.
Retain the decoded source mode 0400.

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

The historical recipe output path is
`/tmp/ge-coordinator-b3a-audit-manifest-v1.json`. The implementation report
states that it was absent before and after final closeout.

Run the exact source twice with its source bytes unchanged and only the
historical sink safely redirected to two unique audit-root files. Retain exact
argv/wrapper source and prove that the redirection cannot affect Git queries,
stdout, canonical JSON, or any other recipe behavior.

PROVENANCE GATE

Before correctness inspection or audit subagents:

1. create one new operator-owned, non-symlink, mode-0700 audit root beneath
   `/private/tmp`;
2. verify the exact repository identity and `30/24/6/0/0` topology;
3. safely copy the retained final manifest into the audit root mode 0400;
4. require canonical JSON, file count 30, size 6,430, and SHA-256
   `132b7473151706f7bb257aea44efdefad04b7e2e2dab8f3ef5486e46a6e6372f`;
5. verify every manifest entry by classification, regular-file type, mode,
   size, and SHA-256;
6. verify no thirty-first changed path;
7. verify every path outside the manifest equals HEAD;
8. verify the exact recipe source;
9. execute it twice with safe sink redirection;
10. require both generated manifests to equal the retained final manifest
    byte-for-byte;
11. require both complete outputs to be byte-identical, 6,663 bytes, and
    SHA-256
    `1606765a198803686184f4fff3da59f5e8a00e2d07c80744ac6a0459d46b72f4`;
12. require tracked textual diff
    `c3ccbcaa17c6a1140529712b414f8a002a18a76d4b8d8733ca6d63bc2deab821`;
13. safely load and hash the opening repair manifest;
14. prove exactly the six authorized entries changed and the other 24 entries
    remained exact;
15. verify the required retained validation records and opening evidence
    inventory;
16. verify explicitly protected source/public surfaces.

On any candidate/evidence identity mismatch, stop before correctness
inspection and return exactly:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not reconstruct or approximate a missing target.

EXPLICITLY PROTECTED BY THE SIX-PATH REPAIR

These must equal the opening repair target, not merely share intent:

```text
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml

.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md

tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py

all SQL, migrations, schemas, catalog behavior
StateStore
WriterSession
package exports
dependency metadata
```

ACCEPTED CONTRACTS — DO NOT REOPEN BY INERTIA

Preserve:

- C2A and lineage schemas, identities, canonical bytes, scalar domains,
  reconstruction tariffs, and import direction;
- all eight B1 schemas, fields, identities, budgets, relation meanings, and host
  snapshot behavior;
- Capability's three value schemas, fourteen dimensions, result/reason
  precedence, fixed Wire pair, and `863 + 249 = 1112`;
- Wire framing, codec, result grammar, profile, classifier, and privacy rules;
- declaration, independent observation, and qualification role separation;
- source refs/digests as unauthenticated evidence only;
- no permission, acceptance, contact, persistence, runtime, provider,
  credential, endpoint, session, Git, or publication authority;
- RW0-C/D/E and ES later-owner seams.

Use the audit to detect a contradiction, not to invent a new architecture.

AUDIT PERSPECTIVES

After the provenance gate, use exactly four bounded, non-nesting, read-only
perspectives when available. No audit child may run tests or mutate anything.

1. Capability error and Python-exception auditor
   - exact built-in-string reason admission;
   - finite canonical reason mapping;
   - inherited `BaseException.args`;
   - actual inherited `__cause__` and `__context__`;
   - first direct emission outside another handler;
   - invocation/re-raise inside an active handler;
   - weak identity registry, cleanup, and multiple live errors;
   - hostile equality object and `str` subclass;
   - copy/deepcopy/pickle/JSON and ordinary reflection;
   - unsupported base-descriptor mutation and whether it can affect supported
     semantic observations, equality, qualification, or authority;
   - docs/code/tests consistency and no overclaim.

2. B1 thirteen-relation causal-matrix auditor
   - literal complete inventory of thirteen public relations;
   - valid independent baseline for each relation;
   - raw stored-tuple forge changing only schema index and self-digest index;
   - every other member equal and nested objects/containers identity-equal;
   - exact `invalid_enum` normal rejection;
   - selective one-object bypass and exact call sequence;
   - class-wide bypass and complete expected call sequence;
   - original-object poisoning after reconstruction;
   - broken controls for wrong object, multiple predicate mutation, mapping
     substitution, missing bypass, and late generic-error masking;
   - deterministic content-free diagnostics.

3. B1 and RW0 complete-owner-region Markdown auditor
   - one current B1 relation/budget region;
   - one current B1 consumer/import region;
   - no numeric or number-word stale retrieval ceiling;
   - no zero/no-current-consumer or future-Capability claim;
   - one current RW0 status/tranche region;
   - B1/Wire/Capability current; C/D/E/ES later owners;
   - no additive future/blocked RW0-B prose or table row;
   - duplicate, relocated, fenced-only, same-title, trailing, and semantically
     equivalent additive mutants.

4. Provenance, evidence, tests, public-boundary, and authority auditor
   - exact six-entry delta and 24-entry equality;
   - implementation evidence inventory and mixed-mode limitation;
   - attempt-001/attempt-002 evidence classification;
   - nodes, JUnit, fingerprint binding, and cleanup;
   - imports, exports, callers, protected bytes, and absence of widened effects;
   - remaining C/D/E/ES seams.

The parent performs reconciliation and validation. Preserve disagreements.

Every finding must include:

```text
ID
type
severity: critical | high | medium | low | observation
current contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect or pre-existing issue
```

REQUIRED SOURCE AND TEST INSPECTION

Inspect all six changed paths completely:

```text
.docs/rw0-b2-capability.md
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Inspect the protected owners and direct dependencies:

```text
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py

.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/rw0-b2-wire-protocol.md

tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py

src/ge_nwp_coordinator/__init__.py
pyproject.toml
```

Inspect additional Coordinator files only for a concrete dependency. Record why.
Do not inspect another repository.

HYPOTHESIS A — CAPABILITY ERROR CONTRACT

Independently prove or falsify all of the following.

### Exact reason intake

- Every finite reason is an exact built-in `str`.
- A `str` subclass is rejected before registry insertion.
- A hostile non-string object with matching hash/equality behavior is rejected
  before comparison against registry keys or values.
- Unknown exact strings are rejected.
- The registry stores only module-owned canonical strings.

### Inherited exception state

For a directly emitted error outside another active handler:

```text
BaseException.args descriptor -> ()
BaseException.__cause__ descriptor -> None
BaseException.__context__ descriptor -> None
```

No private construction token, supplied reason object, caller value, hostile
object, or foreign exception may appear in inherited exception state.

Inspect the base descriptors directly. Do not rely only on subclass properties.

### Honest external chaining

Invoke or re-raise the error while another exception is active.

Require docs and tests to acknowledge that Python may attach interpreter-owned
context. The implementation must not mask the actual base slot while claiming
it is empty.

This standard Python behavior is not a candidate defect unless Capability
retains supplied private material itself, lies about the slot, or derives
authority from it.

### Weak registry and public semantics

Verify:

- two simultaneous errors retain distinct canonical reasons;
- weak-registry entries disappear after collection;
- no hostile supplied object is retained strongly as a registry value;
- equality/hash remain identity semantics;
- ordinary assignment/deletion and ordinary `__dict__` access remain governed;
- repr/str remain constant and content-free;
- copy/deepcopy/pickle/JSON boundaries match the owner;
- unrelated unsupported reflective state does not alter supported reason,
  equality, serialization, qualification, permission, or authority behavior.

Construct external mutants that:

- remove the exact-type check;
- pass reason/token into `BaseException.__init__`;
- replace canonical reason lookup with caller-value retention;
- mask cause/context with misleading properties.

The checked tests must kill each relevant mutant.

HYPOTHESIS B — THIRTEEN B1 RELATIONS

The exact public inventory is:

```text
validate_phase_entry_basis
validate_authority_observation
validate_per_fence_basis
validate_external_common_family_claim
validate_subordinate_narrowing
validate_custody_binding
validate_retrieval_event_sequence
validate_host_qualification
validate_terminal_outcome_binding
validate_normal_terminal_branch
validate_active_cancel_reconciled_branch
validate_active_cancel_unresolved_branch
validate_pre_effect_cancel_basis_unusable_branch
```

For every relation independently:

1. prove the baseline fixture is valid before mutation;
2. inspect the selected exact B1 object's raw `_values` tuple;
3. require the forged object to differ only at:
   - schema index 0;
   - final self-digest index;
4. require all other members equal and nested owner objects/containers identical;
5. normal production execution must reach the forged object and fail exactly
   `invalid_enum`;
6. selected bypass must replace exactly one intended object, delegate every
   other reconstruction, and reach the valid expected outcome;
7. class-wide bypass must replace the complete literal expected call inventory
   and reach the valid expected outcome;
8. poison the original only after real reconstruction returns; the relation
   must still succeed from fresh locals while direct reconstruction of the
   poisoned original fails;
9. terminal fixtures must be independently valid;
10. diagnostics must identify relation/mode without echoing supplied data.

Run external in-memory mutants for:

- projection-derived nested mapping substitution;
- wrong selected object;
- two-predicate raw mutation;
- missing one class-wide bypass;
- extra unexpected bypass;
- rereading the original after reconstruction;
- poisoning before reconstruction;
- later generic error masking the intended predicate.

Require the checked matrix itself to kill each mutant.

HYPOTHESIS C — B1 OWNER-REGION ORACLE

Inspect the full visible authoritative regions, not merely sentence presence.

Require exactly one current retrieval maximum:

```text
validate_retrieval_event_sequence = 1285
```

in the document's actual grammar, and no other current retrieval cap/limit/
maximum/budget statement.

Require exactly one current consumer statement establishing Capability as the
sole current cross-module production consumer, no other production consumer,
future C/D/E seams, and no authority widening.

Run in-memory semantic-equivalent additive mutants including:

```text
The current retrieval cap is three hundred seventy-four B1 units.
The current retrieval maximum is 374.
B1 presently has zero production callers.
No production module currently consumes B1.
Capability consumption remains a future B2 concern.
B2-Capability is not yet implemented.
```

Insert before, inside, and after the expected table/prose but within the
authoritative owner range.

Also test:

- duplicate owner;
- same-title owner;
- relocated owner;
- fenced-only owner;
- trailing contradiction;
- hidden duplicate;
- insertion-order variations.

HYPOTHESIS D — RW0 STATUS-REGION ORACLE

Require the complete visible current region to establish:

```text
current private semantics:
RW0-B1
RW0-B2-Wire
RW0-B2-Capability

later owners:
RW0-C
RW0-D
RW0-E
Execution Substrate
```

Reject any visible additive statement or row in the authoritative range that
labels implemented B semantics as future, blocked, deferred, unimplemented, or
the earliest unresolved tranche, or assigns physical/runtime mechanics back to
B.

Run semantic-equivalent mutants including:

```text
RW0-B remains blocked until process transport is implemented.
The B tranche is still future; RW0-C cannot begin.
Earliest unresolved tranche: RW0-B.
RW0-B2-Capability remains unimplemented.
| RW0-B | future | physical process plumbing |
| RW0-B2-Wire | blocked | runtime transport |
```

Exercise insertion before, inside, and after the expected table within the same
owner range, plus duplicate/same-title/relocated/fenced/trailing controls.

IMPLEMENTATION-EVIDENCE ASSESSMENT

Review every attempt without silently crediting summaries.

Implementation chronology reported:

1. test-first preparation changed four test paths;
2. selected red gate:
   - 32 cases;
   - 31 failed, 1 passed;
   - 17 credited Capability failures;
   - 14 uncredited harness failures;
3. final six-path repair;
4. focused groups:
   - selected causal 36;
   - Capability values 27;
   - B1 relations/boundaries 70;
   - RW0 status 31;
   - Capability compatibility 53;
   - B1 compatibility 317;
   - owner/static/status compatibility 515;
5. final collection 4,761;
6. complete-suite attempt 001:
   - bare `-vv`;
   - interrupted after 3,635.718915 seconds;
   - 1,412 partial JUnit cases;
   - zero recorded failures/errors/skips;
   - one in-flight unmapped case;
   - empty stderr;
   - unchanged candidate bytes;
7. complete-suite attempt 002:
   - only pytest rendering flags changed to `-vv -q -q`;
   - 4,761 passed;
   - no repository byte change;
8. cleanup of 44 transient entries;
9. double final provenance.

Determine:

- whether attempt 001 was an external rendering/harness issue rather than a
  candidate test failure;
- whether SIGINT targeted only the validated pytest child;
- whether candidate bytes and node set remained unchanged;
- whether attempt 002 was permitted by the repair prompt or is a procedure
  deviation;
- whether any deviation is a candidate blocker, an evidence limitation, or
  superseded by an independent full-suite run;
- whether attempt 002 is bound to the exact final manifest and final node list.

Do not block merely because attempt 001 was interrupted if source evidence,
fingerprints, and an independent final suite establish candidate correctness.
Do not ignore a concealed failure or unauthorized byte change.

NODE IDENTITY

Run one candidate collection and one clean external `git archive HEAD`
collection under identical isolated conditions.

Require:

```text
candidate:
4761 unique nodes

candidate ordered-list SHA-256:
e9b1d63bc8b1545e96d9569c8a59304268c04e0a702e529ecf9f35b74e83c2d8

clean HEAD:
4655 unique nodes

clean HEAD ordered-list SHA-256:
f36822a60056ec3d110956de561202b737662c9d22cd0dd82c4cdad6c7cef69f

intersection:
4655

candidate-only:
106

HEAD-only:
0

HEAD order preserved:
true
```

Relative to the 4,743-node opening repair target:

```text
18 additions
0 removals
0 renames
opening order preserved
```

All 18 additions must be exactly the reported
`test_rw0_b2_capability_values.py::test_every_finite_error_reason...` parameter
cases plus:

```text
test_error_factory_rejects_nonexact_reasons_before_registry_use
test_direct_error_emission_has_actual_empty_base_exception_state
test_active_exception_context_is_interpreter_owned_and_not_masked
test_error_registry_is_identity_based_weak_and_payload_free
```

No existing node may be removed, renamed, skipped, xfailed, reparameterized,
collapsed, or reordered.

INDEPENDENT VALIDATION

Only after source, docs, external probes, authority inspection, and test
causality are green enough, run serially beneath the audit root.

For every child:

```text
umask 022 before launch
child numerical umask must be 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Verify every target exists.

Run:

1. selected repaired causal nodes;
2. Capability:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   ```
3. B1:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```
4. RW0 status:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   ```
5. owner/static compatibility:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_rw0_b2_wire_boundaries.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   ```

Every credited run must have:

- return code 0;
- zero failures/errors/skips/xfails/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate or unmapped cases;
- matching caller/child umask;
- unchanged candidate fingerprint.

If all inspection and focused validation remain green, run the complete
repository suite exactly once independently on the final candidate.

Require:

```text
4761 collected
4761 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

Use ordinary quiet rendering that does not reproduce the implementation
wrapper's verbose assertion-rendering incident.

If a deterministic material blocker is found first, the full suite may be
withheld. State that explicitly. Never repair candidate bytes.

PUBLIC, IMPORT, PRIVACY, AND AUTHORITY BOUNDARY

Require:

- no new reverse imports;
- no package-root export;
- no new production caller;
- no dependency, SQL, migration, schema, catalog, `StateStore`, or
  `WriterSession` change;
- no filesystem, process, network, provider, Bridge, ES-call, Git,
  publication, or runtime effect;
- no retained hostile material through Capability-owned error state or
  traceback boundaries;
- no use of unsupported reflection as authority input;
- exact protected C2A, lineage, B1, and Wire implementation bytes;
- Capability remains private pure supplied-fact semantics;
- source refs/digests remain unauthenticated evidence;
- no permission, acceptance, durable truth, or runtime authority;
- C/D/E and ES remain later owners.

CLOSEOUT

After removing only audit-created transient artifacts:

1. rerun the exact recipe twice with safe sink redirection;
2. require exact equality to the opening final target;
3. require the same manifest, complete-output, textual-diff, file count,
   per-path hashes, and topology;
4. compare the implementation-evidence-root opening and closing inventories;
5. verify prior evidence roots unchanged;
6. verify no operation, lock, staged/unmerged path, cache, bytecode, database,
   journal, archive, build, recorder, or generated-manifest residue;
7. retain all audit evidence beneath the new mode-0700 root;
8. make retained audit files regular, operator-owned, and mode 0400;
9. create a self-excluding evidence index.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low candidate defect remains;
- `BLOCK` for any repairable implementation, documentation, test, privacy,
  validation, evidence, or authority-boundary defect;
- `REJECT` only for a fundamental accepted-architecture contradiction;
- `AUDIT_PROVENANCE_MISMATCH` only for target/evidence identity failure before
  correctness judgment.

If `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_FINAL_REAUDIT_FINDINGS_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or create a PR.

FINAL REPORT

Include:

1. opening and closing identity;
2. exact provenance and six-entry delta;
3. implementation evidence inventory and its hardening limitation;
4. four audit perspectives and disagreements;
5. severity-ranked finding ledger;
6. Capability error result;
7. thirteen-relation causal-matrix result;
8. B1 owner-region mutant result;
9. RW0 status-region mutant result;
10. implementation-attempt evidence assessment;
11. node comparison;
12. independent focused/full validation;
13. public/import/privacy/authority assessment;
14. closeout guards;
15. separate provenance, validation, and implementation confidence.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
