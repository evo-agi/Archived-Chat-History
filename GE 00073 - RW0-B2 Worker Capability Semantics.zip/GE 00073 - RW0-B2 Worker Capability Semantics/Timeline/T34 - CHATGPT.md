## Engineering disposition

**Proceed to a fresh independent read-only re-audit. Do not stage or commit.**

Codex reports that the second-audit repair is complete and exact-green:

```text
Branch:
codex/rw0-b2-wire-protocol-v1

HEAD:
02450d3c99faf0fe7b299b914afaed312421bc8b

Final topology:
16 dirty paths
10 tracked modifications
6 untracked additions
0 staged
0 unmerged

Final nodes:
4,653

Complete suite:
4,653 / 4,653 passed
```

The new audit target is:

```text
Manifest:
/private/tmp/rw0-b2-wire-second-repair.91xEYJ/final_provenance.json

Canonical-manifest SHA-256:
8991126301a695c591e7f977bbf4580e378bdee39f740624106e5a0e0f324d11

Complete-output SHA-256:
10ddb5dfda278c484b6846d0c677aebaed9265863fefe3254835c5619a16dda5

Tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6
```

The unchanged tracked-diff digest is expected because all six second-repair paths are untracked. The fresh auditor must therefore compare every file’s size and SHA-256 against the new canonical manifest; the aggregate tracked diff cannot establish the repair bytes.

The accepted architectural boundary remains unchanged: Wire precedes Capability, Capability must bind an accepted Wire profile, and concrete CLI/App Server and physical execution mechanics remain later-owner concerns. 

## What the re-audit must establish

The second repair specifically claims closure of the three remaining behavioral defects:

### Bounded hostile traversal

The auditor must independently prove that:

- raw object pairs are charged during parsing;
- duplicate pairs remain visible without prematurely overriding a later syntax error;
- shape validation uses depth-bounded iterator frames;
- no sibling-sized pending stack is created;
- a 5,000-sibling payload keeps live pending state bounded by depth;
- duplicate, structural, and work-limit precedence remains correct.

### Safe C2A extraction before owner reconstruction

The auditor must challenge all six consumed C2A classes:

```text
CeilingsV1
AttemptFenceV1
EffectFenceV1
WorkerCommandV1
DeliveryEnvelopeV1
WorkerObservationV1
```

Hostile DAGs, cycles, custom iterables, missing slots, wrong slot types, and subclasses must reject before invoking caller `to_mapping()`, C2A `_external_value()`, or arbitrary iteration. Valid maximum objects must still reconstruct through the owning C2A validators and relations.

### Reconstruct-first classifier semantics

Every supplied fact must be reconstructed and validated before identity, duplicate, conflict, lineage, or cancellation semantics are considered.

The critical distinction is:

```text
malformed or tampered fact
    → invalid / invalid_input

same valid object/ref/digest
    → duplicate_fact

distinct valid singleton occupants
    → conflicting_fact
```

The audit should explicitly retest partial or tampered facts paired with colliding valid facts, along with every public self-digest method and classifier/relation boundary.

### Regression of the earlier repairs

The auditor must also verify that the second repair did not reopen:

- exception cause/context or traceback-payload leakage;
- unsafe ordinary construction;
- key-length and privacy handling;
- exact maximum frame behavior;
- C2A relation causality;
- valid-fact duplicate/conflict semantics;
- cancellation graph orientation;
- framing-status wording;
- profile, authority, public-surface, and Capability nonclaims.

Implementation and independent audit must remain separate conversations, and any changed bytes from a repair require a fresh audit.  

## Fresh re-audit prompt

Start a **new read-only Codex conversation** and send this complete prompt:

:chatgpt-content-reference{index="3"}

Verify the attachment before forwarding:

```text
Filename:
Coordinator_RW0_B2_Wire_Second_Audit_Repair_Fresh_Reaudit_Prompt.txt

Size:
27,450 bytes

SHA-256:
73adc848ffa25171249be7234a5985188ac2d1c869bcd3e156d50a7f492ff74e
```

The prompt requires:

- exact two-run opening and closing provenance;
- exact six-changed/ten-unchanged comparison against the first-repair target;
- three read-only audit subagents plus one parent audit lane;
- independent hostile parser, DAG/cycle, classifier, public-method, profile, and causal-test probes;
- focused validation only after source and counterexample inspection are green;
- candidate-versus-HEAD comparison:

```text
candidate:       4,653
HEAD:            4,566
candidate-only:     87
HEAD-only:            0
```

with exact ownership:

```text
Wire values:       11
Wire codec:        16
Wire relations:    47
Wire boundaries:   13
```

- one independent complete-suite run only if inspection remains green;
- no repair, staging, commit, push, PR, or Capability implementation.

The only successful outcome is:

```text
ACCEPT
COORDINATOR_RW0_B2_WIRE_SECOND_AUDIT_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Only after that result should the exact audited paths be staged and compared blob-for-blob with the accepted manifest. Provenance must be reproduced before source inspection, and an accepted audit must precede staging and commit. 

### Sources

- Codex second-audit repair report supplied in this turn.
- Accepted B2 ordering and ownership split. 
- Separate implementation, repair, and fresh-audit lifecycle.  
- Provenance-bound audit and commit sequence. 

**Confidence:** High that the reported candidate is ready for fresh re-audit; deliberately not sufficient for commit authorization until bounded traversal, safe C2A extraction, reconstruct-first classification, and regression closure are independently reproduced.
