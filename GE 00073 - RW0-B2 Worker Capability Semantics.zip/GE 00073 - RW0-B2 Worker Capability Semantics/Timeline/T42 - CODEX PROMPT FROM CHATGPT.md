PROMPT_ID

RW0_B2_WIRE_FOURTH_AUDIT_TEST_REPAIR_FRESH_REAUDIT_V1

TITLE

Coordinator RW0-B2-Wire — fresh independent read-only audit of the exact
fourth-audit test-only repair candidate

ENGAGEMENT TYPE

Fresh Codex conversation. Read-only independent audit.

This is not implementation, repair, reconnaissance, commit, publication,
merge, deployment, Capability work, or runtime proof.

The parent and every audit subagent are read-only. Do not edit, create, delete,
format, chmod, clean repository bytes, stage, commit, push, create or modify a
PR, merge, tag, release, deploy, install dependencies, run migrations, contact
networks/remotes/services, invoke product workers/models/providers, or modify
any supporting repository.

External audit evidence and isolated pytest scratch may be created only beneath
one new operator-owned, non-symlink, mode-0700 directory under `/private/tmp`.
Do not delete or rewrite implementation, repair, or prior-audit evidence.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

VERDICT TOKENS

Return exactly one primary verdict:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

On `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_WIRE_FOURTH_AUDIT_TEST_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not repair any finding.

EXPECTED LIVE TARGET

Require at opening and closeout:

- physical root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- subject:
  `feat: implement RW0-B1 pure phase-entry semantics (#3)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- dirty paths:
  `16`
- tracked modifications:
  `10`
- untracked additions:
  `6`
- staged/unmerged:
  `0/0`
- every candidate path:
  regular mode `0644`
- no Git operation, lock, repository cache, bytecode, database, journal,
  archive, build, generated manifest, or recorder residue
- `git diff --check`:
  clean.

Do not fetch or contact a remote.

IMMUTABLE FOURTH-REPAIR TARGET

Repair evidence root:

```text
/private/tmp/rw0-b2-wire-fourth-repair.oTHtSz
```

Repair closeout report:

```text
/private/tmp/rw0-b2-wire-fourth-repair.oTHtSz/final_provenance.json
```

Expected report-envelope SHA-256:

```text
bb6629cb14238a29eca2aa2da5f23101e5423ef5cdfd6d793a64a3276982c8d5
```

Expected canonical identities bound by that report:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe source bytes:
3_945

recipe source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6

canonical-manifest SHA-256:
a07cf04ba3e0418bbf5688ffbf78480fde79747d4310a5075e6db5dbf25f4aec

complete-output SHA-256:
0c35a0996ef0ce1a7df09b8b7ae4ad91c3a0f5eea8f8b15e5db8433aa1cd0458

file count:
16
```

Require `final_provenance.json` to identify and hash-bind exactly one canonical
manifest carrying those identities. If it does not, return
`AUDIT_PROVENANCE_MISMATCH`; do not infer an unrecorded target.

PRECEDING THIRD-REPAIR TARGET

Canonical manifest:

```text
/private/tmp/rw0-b2-wire-third-repair.l1gF3r/final_recipe_001.manifest.json
```

Expected preceding identities:

```text
canonical-manifest SHA-256:
462179865bd8bacc2edcab5fd5a0ee3bae9e85a62a708a7e3b7c3d18f10db33b

complete-output SHA-256:
136bec66bea1850965f4a2232b422dcc9ba2315adc308319ab16b4cc0cc8ff06

tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6
```

Latest preceding audit root:

```text
/private/tmp/rw0-b2-wire-third-audit.Zq6XE2
```

Retained evidence roots that must remain unchanged include all prior Wire
implementation, repair, and audit roots, including:

```text
/private/tmp/rw0-b2-wire-v4.b4HlRt
/private/tmp/rw0-b2-wire-independent-audit.hX8xit
/private/tmp/rw0-b2-wire-repair.q4veCL
/private/tmp/rw0-b2-wire-re-audit.dU0ieG
/private/tmp/rw0-b2-wire-second-repair.91xEYJ
/private/tmp/rw0-b2-wire-third-repair.l1gF3r
/private/tmp/rw0-b2-wire-third-audit.Zq6XE2
/private/tmp/rw0-b2-wire-fourth-repair.oTHtSz
```

EXACT 16-PATH SET

Untracked additions:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

Tracked modifications:

```text
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

No seventeenth path is permitted.

EXPECTED THIRD-TO-FOURTH-REPAIR DELTA

The path set, classifications, types, and modes remain identical.

Exactly these two untracked entries changed:

```text
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_codec.py
```

The other fourteen candidate entries—including all production source and all
governing documentation—must be byte-identical to the third-repair target.

The tracked textual-diff digest remains unchanged because both repaired files
are untracked. Independently verify every per-file size and SHA-256; do not
treat the aggregate tracked-diff digest as repair proof.

EXACT RECIPE SOURCE

Decode this base64 only into the external audit root, verify exact size and
SHA-256, and retain it mode `0400`:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

The source historically writes:

```text
/tmp/ge-coordinator-b3a-audit-manifest-v1.json
```

Do not overwrite pre-existing evidence at that path. Execute the exact recipe
source unchanged while an external wrapper redirects only that exact
`Path.write_bytes` sink to a unique file under the audit root. Do not alter Git
reads, canonicalization, stdout, stderr, or recipe source.

PROVENANCE GATE — BEFORE CORRECTNESS INSPECTION

1. Lstat every component of:
   - fourth-repair evidence root;
   - report envelope;
   - report-bound canonical target;
   - preceding third-repair manifest;
   - latest preceding audit root;
   - every retained prior evidence root;
   - copied recipe source;
   - new audit root.
2. Require safe ownership, no symlink traversal, regular report/manifest/recipe
   files, and mode-0700 evidence roots.
3. Verify the report envelope and bound manifest exact bytes and SHA-256.
4. Parse canonical JSON and require exact:
   - branch;
   - HEAD;
   - upstream;
   - recipe ID;
   - textual-diff digest;
   - 16-path set;
   - classification;
   - file type;
   - mode;
   - size;
   - per-file SHA-256.
5. Compare every live candidate file with the fourth-repair target.
6. Run the exact recipe twice at opening.
7. Require both complete outputs and manifests to be byte-identical and the
   generated manifest to equal the immutable target byte-for-byte.
8. Require repository identity and status to match the expected live target.
9. Verify no protected path outside the 16-path set differs from HEAD.
10. Verify exactly the two/fourteen preceding-to-repair delta above.
11. Verify production source and governing documentation are byte-identical to
    the third-repair target.

On any mismatch, stop before correctness inspection with:

```text
AUDIT_PROVENANCE_MISMATCH
```

CURRENT CONTRACT AND TARGET BOUNDARY

Committed HEAD owns current C2A and B1 contracts. The uncommitted candidate is
the accepted private B2-Wire target.

The candidate may implement only:

- private deterministic NWPF command/result codecs;
- pure relations over supplied exact C2A values and actual fences;
- safe unauthenticated cancellation-request and process source claims;
- a pure process/result classifier;
- one fixed local Wire protocol profile.

It must implement no:

- source authentication;
- permission, effect authority, acceptance, or durable truth;
- worker, process, contact, physical transport, host, filesystem, database,
  network, provider, model, Codex, CLI, App Server, credential, session,
  Bridge, ES, Git, or publication effect;
- RW0-C persistence, recovery, terminal fact, or latch;
- RW0-D/E request delivery, process targeting, process mechanics, or live proof;
- Capability declaration, observation, qualification, or implementation.

FROZEN PRODUCTION IDENTITIES

Require exact preservation:

```text
profile_ref:
rw0-wire-nwpf-v1

profile identity bytes:
4_021

profile digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454

command payload/frame:
5_898 / 5_906

result payload/frame:
16_627 / 16_635

hostile units:
23_746 / 66_770

source mapping key maximum:
37

frame key maximum:
29

B2 maximum integer:
9_223_372_036_854_775_807
```

No production byte changed in the fourth repair. A production defect newly
discovered by this audit is still a blocker, but do not repair it.

FINDINGS TO RE-AUDIT

Treat all prior findings as hypotheses to remain closed.

Production and earlier test findings F1–F14 include:

```text
foreign exception graph/payload leakage
ordinary and incomplete immutable construction
hostile key/raw-pair/shape/work accounting
duplicate versus singleton conflict
stale framing-status prose
causal test inadequacy
cancellation graph orientation
bulk sibling enqueue
premature C2A DAG/cycle expansion
classifier reads before reconstruction
public-method/malformed-fact coverage
late integer rejection
duplicate overlength-key precedence
noncausal key-pair cap fixture
```

The fourth audit found only:

```text
F15 Medium  oversized-integer regression did not isolate all six consumed C2A
            classes and all reachable integer paths

F16 Low     pending-frame oracle derived its bound from production _CAPS
```

This audit must independently close F15 and F16 and detect any new test defect.

AUDIT EXECUTION SHAPE

Use at most four concurrent audit slots:

- create three bounded read-only audit subagents;
- the parent performs the fourth lane;
- no nested agents;
- no subagent runs pytest or mutates repository/evidence;
- every subagent receives the same canonical manifest identity and a
  self-contained context capsule;
- preserve disagreements and minority findings.

LANE 1 — LITERAL 64-PATH INTEGER INVENTORY AND ISOLATION

Inspect:

- `tests/test_rw0_b2_wire_relations.py`;
- committed C2A class field inventories and validators;
- unchanged Wire safe-extraction implementation;
- repair evidence.

Independently derive the reachable integer paths through:

```text
CeilingsV1
AttemptFenceV1
EffectFenceV1
WorkerCommandV1
DeliveryEnvelopeV1
WorkerObservationV1
```

Do not derive the audit inventory from the repaired test or Wire extractor
constants.

Require the independently derived distribution to be exactly:

```text
CeilingsV1           15
AttemptFenceV1       16
EffectFenceV1        16
WorkerCommandV1      16
DeliveryEnvelopeV1    0
WorkerObservationV1   1
total                 64
```

For every repaired test inventory entry verify:

1. exact owner class and literal field path;
2. one fresh complete valid related graph per case;
3. exactly one slot in exactly one target object is changed;
4. command, attempt, effect, delivery, and observation are not jointly
   corrupted;
5. both `MAX + 1` and a 1,000-digit integer are exercised;
6. the first public Wire boundary actually reaches that class/path;
7. sealed `invalid_field_value`, null cause/context, and content-free error;
8. zero calls to every applicable owner/Wire reconstruction,
   canonicalization, digest, payload, and framing surface;
9. the spy set includes the relevant class-specific owner boundary, rather than
   only a common early boundary;
10. no other invalid object can cause the rejection first.

Independently mutate representative paths from every owner class and reproduce
the zero-call behavior.

Verify the exact-valid controls and process-exit lower-bound controls:

```text
-255
0
255
```

Require the selective-regression control to suppress only one selected
upper-bound check, make that selected case advance to a spy or cease early
rejection, and leave an unrelated case unchanged.

Audit the preserved existing representative test node separately. It must now
mutate only `WorkerCommandV1.global_stop_version` and must not rely on the new
matrix to hide a non-isolating body.

LANE 2 — TEST-INDEPENDENCE AND MATRIX COMPLETENESS

Inspect the integer test helpers, fixtures, inventories, and spies for
self-confirming logic.

Determine whether:

- the literal 64-entry inventory is test-owned rather than generated from Wire
  extractor constants;
- completeness comparison against committed C2A `_FIELDS` is independent and
  would fail if one literal entry were omitted, duplicated, or mapped to the
  wrong owner;
- the test does not define the expected integer ownership from the same helper
  under test;
- each of the 64 cases is actually executed for both oversized values;
- the zero-call spies cannot be bypassed because the mutated class is never
  reached;
- a deliberately broken selective implementation for one of
  AttemptFenceV1, EffectFenceV1, and WorkerObservationV1 would fail the test;
- relation/classifier/result builders do not silently reconstruct and replace
  the mutated input before the intended boundary is observed;
- the one-line post-development correction references the actual rebuilt
  object and does not weaken isolation;
- the single new test node remains non-parameterized and uniquely named.

Construct at least three bounded local broken controls—one each for Attempt,
Effect, and Observation—to prove the checked-in test is sensitive to selective
regressions.

LANE 3 — PENDING-FRAME LITERAL ORACLE

Inspect:

- `tests/test_rw0_b2_wire_codec.py`;
- unchanged parser/shape implementation;
- fixed profile projection;
- repair evidence.

Require the test to own the literal values:

```text
maximum live pending frames:
5

result cap tuple:
(16_627, 4, 8, 77, 169, 66_770)
```

ordered as:

```text
payload_bytes
depth
containers
key_pairs
scalar_leaves
hostile_units
```

Verify:

1. neither expectation is derived from production `_CAPS`, the profile object,
   or another production constant before being asserted;
2. the literal tuple is separately compared with:
   - fixed profile projection; and
   - production cap representation;
3. the 5,000-sibling hostile payload still measures observed live pending frames
   independently and requires `<= 5`;
4. the broken control genuinely demonstrates that a production-derived oracle
   follows an inflated depth `99 -> 100` while the literal remains `5`;
5. changing production `_CAPS` alone cannot cause the independent expectation
   to change;
6. the existing node name is unchanged and no extra codec node was introduced;
7. prior duplicate/syntax/shape/work precedence and exact-cap tests remain
   active and causal.

Independently rerun the 5,000-sibling probe with external instrumentation rather
than relying only on the checked-in oracle.

LANE 4 — PROVENANCE, REGRESSION, PUBLIC BOUNDARY, AND EVIDENCE

The parent performs this lane.

Inspect:

- both changed test files;
- all fourteen unchanged candidate entries;
- production source and governing documents;
- fourth-repair and prior evidence;
- imports/AST/package/public surfaces;
- node identities and test metadata.

Determine whether:

- exactly two test files and only those files changed;
- production/docs are exact;
- all F1–F14 direct tests remain active and unchanged except the authorized
  test-body strengthening;
- no test was weakened, removed, renamed, skipped, xfailed, collapsed, or
  reparameterized;
- exactly one new node exists;
- no package/public/production/dependency/schema/migration widening exists;
- repair evidence binds the final target and preserves every prior evidence
  root;
- no sensitive or repository-local artifacts remain.

IMPLEMENTATION EVIDENCE REVIEW

Safely inventory the fourth-repair root. Verify credited records by exact file
identity, argv, environment, umask, return code, stdout/stderr, JUnit,
structured counts, and before/after fingerprints.

Expected repair-reported final results:

```text
opening nodes:                    4_654
final nodes:                      4_655
new repair nodes:                 1
new-node owner:                   tests/test_rw0_b2_wire_relations.py

existing oversized integer node:  1 passed
new 64-path matrix:               1 passed
pending-frame node:               1 passed
Wire relations:                   49 passed
Wire codec:                       16 passed
combined Wire:                    89 passed
C2A/C2A1:                         637 passed
B1:                               281 passed
static/public:                    105 passed
status/docs:                      858 passed
complete suite attempt 001:       4_655 passed
```

Preserve and classify:

- pre-edit diagnostic;
- initial new-matrix test-local failure;
- one authorized line correction;
- any recorder or orchestration limitation.

Do not treat recorder/test-harness errors as production failures. Do not credit
ambiguous or unbound evidence.

PARENT RECONCILIATION

Wait for all three subagents. Preserve disagreements. Directly inspect and
reproduce every material finding.

Classify each finding by:

- severity: Critical / High / Medium / Low / Observation;
- type: authority/contract, correctness, security/privacy/availability,
  test adequacy, documentation/status, public boundary, provenance/evidence;
- patch defect versus pre-existing issue;
- current-contract violation versus strategic-target defect;
- exact path:line evidence;
- impact;
- required correction;
- uncertainty.

Green tests never overrule a deterministic counterexample.

INDEPENDENT VALIDATION

Only after provenance and source/probe inspection are sufficiently green, run
serial independent validation under the new audit root.

For every child use:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
```

Capture and restore the actual caller umask; require child-observed numerical
umask equality.

Run:

1. the existing isolated oversized-integer node;
2. the new isolated 64-path integer node;
3. the pending-frame node;
4. all four Wire files together:
   ```text
   tests/test_rw0_b2_wire_values.py
   tests/test_rw0_b2_wire_codec.py
   tests/test_rw0_b2_wire_relations.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
5. corrected C2A/C2A1:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_c2a_first_slice_semantic_protocol_contract.py
   tests/test_c2a_effects_and_recovery.py
   ```
6. B1:
   ```text
   tests/test_rw0_b1_*.py
   ```
7. static/public:
   ```text
   tests/test_c2a_nonimplementation.py
   tests/test_runtime_non_authority.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_b2a_writer_session_contract.py
   tests/test_codex_agent_config.py
   ```
8. status/docs:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

Every executed gate must return 0 with empty stderr, zero
failures/errors/skips/xfails/warnings, parseable JUnit, no duplicate or unmapped
case, and unchanged repository target.

NODE IDENTITY

Collect the candidate exactly once and one clean external `git archive HEAD`
exactly once.

Require:

```text
candidate:                       4_655
HEAD:                            4_566
intersection:                    4_566
candidate-only:                  89
HEAD-only:                       0
```

Require all 89 candidate-only nodes to belong exactly to:

```text
tests/test_rw0_b2_wire_values.py       11
tests/test_rw0_b2_wire_codec.py        16
tests/test_rw0_b2_wire_relations.py    49
tests/test_rw0_b2_wire_boundaries.py   13
```

Require HEAD order preservation.

If source/probe inspection finds a blocker, the full suite may be withheld with
an exact explanation.

If inspection is green, run the complete repository suite exactly once and
require:

```text
4_655 collected
4_655 passed
0 failures/errors/skips/xfails/warnings
empty stderr
no duplicate or unmapped JUnit cases
unchanged target bytes
```

CLOSING GUARDS

Before verdict:

1. remove only audit-created transient caches, basetemps, archives, databases,
   journals, and recorder scratch;
2. rerun the exact recipe twice;
3. require both closing manifests and complete outputs to equal opening and the
   immutable fourth-repair target byte-for-byte;
4. require exact 16-path topology, modes, classifications, sizes, and hashes;
5. require protected complement equality to HEAD;
6. require clean `git diff --check`;
7. require no repository residue, operation, or lock;
8. confirm no repository mutation occurred;
9. confirm every retained prior evidence root is unchanged.

ACCEPTANCE STANDARD

`ACCEPT` requires:

- exact provenance;
- no Critical, High, Medium, or Low patch defect;
- all F1–F16 findings mechanically closed;
- no new current-contract or accepted-target contradiction;
- the 64-path integer matrix is complete, literal, isolated, and selectively
  causal;
- the pending-frame oracle is independent of production caps;
- all prior production/parser/extraction/classifier/authority/privacy/status
  findings remain closed;
- causally adequate tests;
- validated public/nonimplementation boundaries;
- required independent validation green;
- closing target byte-identical to opening.

An evidence limitation may be an Observation only when independent source,
probe, and validation work fully supersede it.

FINAL REPORT

Include:

1. exact opening/closing identity and provenance;
2. exact third-to-fourth-repair delta;
3. audit-lane reports and preserved disagreements;
4. severity-ranked finding ledger;
5. per-F1–F16 disposition;
6. independent 64-path integer inventory and isolation assessment;
7. pending-frame literal-oracle assessment;
8. regression assessment of production and prior repairs;
9. test metadata, public-boundary, and evidence assessment;
10. independent commands/results/node comparison;
11. closing guards, limitations, and separate confidence for:
    - provenance;
    - validation;
    - production behavior;
    - test adequacy.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
```
