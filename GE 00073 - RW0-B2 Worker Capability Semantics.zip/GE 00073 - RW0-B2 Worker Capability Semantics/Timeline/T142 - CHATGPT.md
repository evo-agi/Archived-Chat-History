## Engineering disposition

**Do not restart the complete replay or modify the candidate. Diagnose the `evidence_close_g5` comparison first.**

The replay stopped during closeout, not during implementation or validation:

```text
failure stage:
evidence_close_g5

failure envelope:
/private/tmp/g6.4101bd/a/0182/envelope.json

repository mutation:
none

post-failure suite rerun:
none
```

That label strongly indicates a continuity check against the historical `/private/tmp/g5.hiLE2y` evidence root. It does **not** by itself establish that candidate bytes, validation results, or G5 evidence bytes changed.

The critical distinction is between:

- real G5 drift—changed path set, bytes, type, mode, ownership, size, `mtime`, `ctime`, xattrs, or index identity; and
- observation-only change—most plausibly `atime` caused by reading the historical evidence during replay;
- a comparison-wrapper defect—such as including `atime`, comparing different inventory schemas, or mixing self-excluding and index-including inventories.

If G5’s indexed paths, bytes, modes, ownership, sizes, and hashes remain exact, and the only difference is read-induced metadata, then all completed G6 validation can potentially be preserved. The next step would be an **evidence-only closeout continuation**, not another 5,072-test replay.

## Read-only diagnostic handoff

Continue in the **same implementation conversation**, but do not authorize tests or cleanup:

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Capability_G6_Evidence_Close_G5_Mutation_Diagnostic_Prompt.txt

Size:
10,409 bytes

SHA-256:
96871593789cf8daa955c54aaf584ec12fa3a264cd96db8531ff8864bb1da8ac
```

The prompt requires Codex to inspect:

```text
/private/tmp/g6.4101bd/a/0182/envelope.json
```

and report the exact first unequal:

```text
path
field
opening value
closing value
whether reading can cause it
whether bytes changed
whether evidence validity changed
```

It independently reverifies the complete G5 self-excluding index:

```text
/private/tmp/g5.hiLE2y/evidence_index.jsonl

7,234 rows
1,583,837 bytes

SHA-256:
199af9ac4299cc41a4434d44f1b1f7bcaf3265490b7417e174ad5d48723f8fcc
```

It also determines how far G6 progressed before attempt 0182 and whether all causal, focused, A/B/C, collection, live-suite, clean-suite, guard, and provenance attempts already have complete envelopes.

## Required diagnostic outcome

Codex must return one primary classification:

```text
G5_CONTENT_UNCHANGED_OBSERVATION_METADATA_ONLY
G5_COMPARISON_WRAPPER_DEFECT
G5_REAL_EVIDENCE_DRIFT
SOURCE_REPOSITORY_DRIFT
G6_REPLAY_EVIDENCE_INCOMPLETE
DIAGNOSTIC_INCOMPLETE
```

and one continuation disposition:

```text
EVIDENCE_ONLY_CLOSEOUT_CONTINUATION_READY
CLOSEOUT_WRAPPER_REPAIR_CONTINUATION_READY
VALIDATION_REPLAY_RESTART_REQUIRED
IMPLEMENTATION_REPAIR_REQUIRED
PROVENANCE_BLOCKED
```

### Decision path

`G5_CONTENT_UNCHANGED_OBSERVATION_METADATA_ONLY` plus `EVIDENCE_ONLY_CLOSEOUT_CONTINUATION_READY` means the existing G6 validation remains usable. Continue only with corrected content-stable evidence comparison, remaining final closeout, report, and index work. No tests rerun.

`G5_COMPARISON_WRAPPER_DEFECT` means the wrapper’s identity model was wrong—for example, it included `atime` or compared inconsistent schemas. Repair only the closeout comparison and continue from the sealed G6 attempts.

`G5_REAL_EVIDENCE_DRIFT` means historical evidence genuinely changed. That blocks provenance and must be investigated before any replay receives credit.

`G6_REPLAY_EVIDENCE_INCOMPLETE` means the stop occurred before mandatory validation or fingerprints were sealed; only then should another replay be considered.

`SOURCE_REPOSITORY_DRIFT` invalidates the current candidate target and must list every changed repository, index, ref, or object-database identity.

Do not create another implementation or validation prompt until this diagnostic names the exact differing field.

**Source:** Codex’s `COMPLETE_REPLAY_SOURCE_MUTATION_DETECTED` response supplied in this turn.

**Confidence:** High that the failure is a closeout evidence-continuity issue rather than a repository implementation defect; the exact continuation depends on whether G5 changed in content or only observational metadata.
