## Engineering disposition

**Proceed to a fresh independent read-only re-audit. Do not stage or commit.**

The sixth repair report is a credible implementation closeout:

- exactly one untracked test file changed;
- production source, governing documents, and the other 15 candidate paths remained byte-identical;
- all **4,655** node IDs and their ordering were preserved;
- the formerly escaping class-wide Attempt mutant now produces a targeted causal failure;
- the selected-operation control passes with one bypass;
- the unrelated Effect mutant is also killed;
- focused validation and the complete **4,655/4,655** suite passed;
- final provenance reproduced twice.

The new audit target is:

```text
Branch:
codex/rw0-b2-wire-protocol-v1

HEAD:
02450d3c99faf0fe7b299b914afaed312421bc8b

Repair evidence root:
/private/tmp/rw0-b2-wire-sixth-repair.JqZLSt

Canonical-manifest SHA-256:
c1fe53703e61cb30394b944af063ad5b23f4fc472f48571b1064cbde2f79a358

Complete-output SHA-256:
58421af36213dfb0c74232acee5a68a3fa64cda5ad98e88e38c6ea54562c534a

Tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6
```

The unchanged tracked-diff digest is expected because the sole repair path is untracked. The auditor must compare every file’s size and SHA-256 against the new canonical manifest.

## What the fresh audit must prove

The next audit should concentrate on whether F18 is **behaviorally** closed rather than accepting the repair’s own instrumentation.

It must independently reproduce these modes:

```text
Authoritative production behavior
    → strengthened node passes

Selected Attempt operation only bypassed
    → passes
    → exactly one selected bypass
    → the other 15 Attempt checks retain real enforcement
    → selected Attempt owner boundary reached exactly once

All 16 Attempt checks bypassed
    → fails specifically with:
      non_selected_attempt_integer_guard_not_enforced

Unrelated Effect checks bypassed
    → fails specifically with:
      unrelated_effect_integer_guard_not_enforced
```

It should also inject a later digest or relation failure while all Attempt guards are bypassed. The test must still fail at the non-selected Attempt sentinel; a sanitized downstream error must not satisfy the oracle.

The auditor should inspect the sentinel graph directly and establish that:

- selected `AttemptFenceV1.global_stop_version` is valid;
- only `AttemptFenceV1.aggregate_ceilings.max_active_invocations` is oversized;
- every companion object and digest coordinate is otherwise coherent;
- the real guard body is entered and rejects once under authoritative behavior;
- no Attempt owner reconstruction, canonicalization, digest, payload, or frame path is reached before rejection.

F17’s 64-key positive and negative ledgers, legal-MAX controls, and process-exit controls must remain active. No Wire, C2A, B1, status, authority, privacy, profile, or public-surface design should be reopened. The accepted order remains Wire before Capability, with concrete execution mechanisms deferred to later owners. 

This repeated causal-oracle issue is consistent with the original reconnaissance forecast, which explicitly identified noncausal mutants and self-attestation as live audit risks. 

## Fresh re-audit prompt

Start a **new read-only Codex conversation** and send this complete prompt:

:chatgpt-content-reference{index="3"}

Verify the attachment:

```text
Filename:
Coordinator_RW0_B2_Wire_Sixth_Audit_Test_Repair_Fresh_Reaudit_Prompt.txt

Size:
30,661 bytes

SHA-256:
198c5cc6a6d4299bc4ad3a2a4b9bd91609e452103a9581a4202157f28bc3af47
```

The prompt requires:

- exact opening and closing provenance;
- exact one-changed/15-unchanged comparison against the fifth-repair target;
- three independent audit lanes plus parent reconciliation;
- external pre-import mutants rather than reliance on the checked-in test’s counters;
- authoritative, selected-only, class-wide Attempt, unrelated Effect, and downstream-masking modes;
- independent F17 regression controls;
- exact node comparison:

```text
candidate:       4,655
HEAD:            4,566
candidate-only:     89
HEAD-only:            0
```

with ownership:

```text
Wire values:       11
Wire codec:        16
Wire relations:    49
Wire boundaries:   13
```

- one independent complete-suite run only after source and mutant inspection are green;
- no repair, mutation, staging, commit, push, PR, remote contact, or Capability work.

The only successful outcome is:

```text
ACCEPT
COORDINATOR_RW0_B2_WIRE_SIXTH_AUDIT_TEST_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Implementation repair and independent audit must remain separate conversations; any repaired bytes require a new independent audit.   Only an accepted audit permits the subsequent commit gate to regenerate provenance, stage exactly the audited paths, compare staged blobs against the manifest, validate without editing, and commit once. 

### Sources

- Codex sixth-audit repair report supplied in this turn.
- Accepted B2 ordering and original audit-risk forecast.  
- Governed implementation, repair, and fresh-audit separation.  
- Audited-byte commit-gate lifecycle. 

**Confidence:** High that the candidate is ready for fresh re-audit; deliberately insufficient for commit authorization until independent pre-import mutants confirm that the class-wide Attempt bypass and downstream masking paths are causally killed.
