PROMPT_ID

RW0_B2_CAPABILITY_INTEGRATED_PROTECTED_OWNER_REPAIR_V1

TITLE

Coordinator RW0-B2-Capability — integrated B1/C2A/lineage owner hardening,
Capability-local audit repair, status reconciliation, validation, and exact
provenance

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing Governed Execution
Coordinator Capability implementation conversation.

Do not create subagents. You are the sole repository writer.

This is not reconnaissance, independent audit, commit/publication, merge,
release, deployment, live/runtime proof, provider integration, or supporting-
repository work.

Repository mutation is authorized only inside the exact 30-path ceiling below.
Tests and external validation/provenance evidence are authorized exactly as
specified.

Do not stage, commit, push, create a PR, merge, tag, release, deploy, fetch,
contact a remote/service/provider/host, invoke a worker/model, install a
dependency, modify another repository, run a live database/service, or change
a migration/schema/public API.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Repair the independently audited RW0-B2-Capability candidate as one integrated
patch on its existing uncommitted branch.

The repair must:

1. harden the protected C2A and Section 41 lineage owners with private,
   non-recursive, exact-class reconstruction helpers;
2. reconstruct all eight B1 values through their owning grammar before any
   semantic read and make every B1 relation use reconstructed locals only;
3. replace the obsolete B1 relation budgets with the exact frozen budgets below;
4. expose one private B1 host-validation snapshot seam for Capability;
5. repair the Capability Wire-owner loader, retained-callable boundary,
   supported-public-surface error immutability, and generic session privacy;
6. correct the RW0 current-status/tranche/open-decision documentation;
7. preserve every accepted schema, field, digest domain, canonical byte,
   qualification predicate, Wire profile identity, public boundary, and later-
   owner split;
8. complete isolated validation and produce a new exact 30-path provenance
   target for a fresh independent re-audit.

The repair must not implement worker contact, durable RW0-C facts, physical
custody, process/supervisor behavior, provider selection, credentials,
sessions, transport, ES integration, or runtime reconciliation.

GOVERNING RECONCILIATION VERDICTS

The immediately preceding read-only reconciliation returned:

```text
RW0_B2_CAPABILITY_REPAIR_RECONCILIATION_READY
B1_C2A_OWNER_HARDENING_SCOPE_FROZEN
INTEGRATED_REPAIR_ON_EXISTING_BRANCH_JUSTIFIED
```

Implement that reconciliation exactly.

OPENING REPOSITORY IDENTITY

Before any edit require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
20 paths
14 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644
```

Require no Git operation, lock, repository cache, bytecode, database, journal,
archive, build output, generated repository manifest, recorder residue, or
mode drift. Require `git diff --check` clean.

Do not switch, reset, clean, stash, rebase, merge, or create another branch.
Stop on any mismatch.

OPENING CANONICAL TARGET

Require exact reproduction of the current candidate before mutation:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe size:
3945 bytes

recipe SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

canonical manifest size:
4291 bytes

canonical manifest SHA-256:
41a256e52bf5b3e677ec88736889230be416005da429bf5cb3339c92d9427c76

tracked textual-diff SHA-256:
e81ef0ba3e3238a7e6ec428c519f3259bebb6da79cbef318a7045edb45656f5f

complete output size:
4524 bytes

complete output SHA-256:
8d8ff431ae0aa0362b4d298e5261ba866ca9f7eeae18a3e2f93bb33d233b088b

file count:
20
```

Exact canonical manifest:

```json
{"branch":"codex/rw0-b2-capability-semantics-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/authority-boundaries.md","sha256":"6a3bf0bbb68b121206f815246c7d0c7acb4368239a9f9c72a766794b08f58e3c","size":32486},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/autonomous-software-development-operating-model.md","sha256":"8df2b88cd86019de4e6312f9178a1b8391881a6d0a6e7ec39632ce790e1216bb","size":34484},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/durable-state-model.md","sha256":"a14d10810847d77cbb58cf724b1861ed2f612255a1351033cfdb7c2a3e3155aa","size":37671},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-b1-pure-phase-values.md","sha256":"cec48373ec6b85d9fb84b0b0f384a8f3a528808d6d5205a33698c3442766b1c5","size":27228},{"file_type":"regular","kind":"untracked","mode":"0644","path":".docs/rw0-b2-capability.md","sha256":"1629c2015ed1cc651ed82d1302b5e41c5ac5b217ab86a307016df1b7535592be","size":13378},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-b2-wire-protocol.md","sha256":"7505e578393d448e677b8d05a74257ff33362e99df2e12539edc89099434082e","size":16566},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-remote-worker-contact-phase-entry.md","sha256":"d3189084312bbf710c526cb2bccfae008c2a356ae23375c94754db7238e4f993","size":50209},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/worker-execution-boundary.md","sha256":"d1882845e1f8e6d5b8f9b33620545fabb42f6213882b733b0643f87222f9e5b9","size":28735},{"file_type":"regular","kind":"untracked","mode":"0644","path":"src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py","sha256":"0e15e545620f90470ed5d8d852fcec1c8c12fa705b22cc93406b2250a16ac0d0","size":34844},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_architecture_contracts.py","sha256":"cfa79cb15e70d98cd811575c0077be1320e0fe37a9662d95482294e7f0eac740","size":99705},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_c2a_nonimplementation.py","sha256":"651a50b07cddf226425723f73d0496d477ea7e45bdae5b620bb066b61863c402","size":27068},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_runtime_non_authority.py","sha256":"9636dd003e358d178e6d6316b16dbff7ece944ae64f7bf0a3f3080b6be297755","size":41310},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b1_boundaries.py","sha256":"f921fc6e8010d2fec5ed2e254935288e49ed758d639e80dcb6b836abfd19df1e","size":8086},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_boundaries.py","sha256":"b49dab823265ed8bb4b1b5b3ee707767d67afd205d52a6827ecf5510c43a2cd4","size":13644},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_relations.py","sha256":"96e88e658d1ea6b5260d6ab81828fdcf35f275fd8399da56e299a557d0eaaf49","size":24843},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_values.py","sha256":"3baeafb6db862b65939a3395015d37f86983cbc99959855f523bb921baad763a","size":23091},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_vectors.py","sha256":"4aa4432b3e042e72f4a0d131a696a842f1a2ac1e3473f8bc04ad8fb90219f7f3","size":16104},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b2_wire_boundaries.py","sha256":"d336e59d4ff736df5986105a4af58a46c07b3399b38af50967b55823157ba54b","size":28611},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_remote_contact_phase_entry_contract.py","sha256":"b025563a6619c3ffa591035e577968dee3a9a75c480d9d28e024e22f5e662c07","size":108079},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_software_development_progression_boundary.py","sha256":"ffe8ae9af76eef5f091691ba6e8930b6c59b4d11ed5b59733407cb1f3965cb13","size":42680}],"head":"deec37bf08fb903d8846aa2c3232aec52fa9866e","recipe_id":"governed-execution.audit-patch-manifest.v1","textual_diff_sha256":"e81ef0ba3e3238a7e6ec428c519f3259bebb6da79cbef318a7045edb45656f5f","upstream":"origin/trunk_dev"}
```

Exact recipe source, base64:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

Create one new external operator-owned, non-symlink, mode-0700 repair evidence
root under `/private/tmp`. Decode the recipe only there, require exact size and
hash, and retain it mode 0400.

The historical recipe sink is outside the repository. If it exists, record its
complete safe filesystem identity and bytes. Execute the exact recipe source
unchanged while an external wrapper redirects only its exact
`Path.write_bytes` sink to unique files beneath the repair evidence root.
Preserve the historical sink.

Run the recipe twice before editing and require both outputs and manifests to
equal the opening target byte-for-byte.

Record the complete opening pytest node list exactly once under isolated
external cache/temp paths:

```text
expected unique nodes:
4676

expected ordered-list SHA-256:
f8fe844c0b8da21b99ccedb3cc22075f85c144e9420c6d040504a9859680e26c
```

Do not predeclare the final count.

AUDIT FINDINGS TO CLOSE

Close exactly these independent-audit findings.

### AUD-001 — invalid B1 values can qualify

Current B1 supplied-value validation trusts public projection/digest behavior
and can use the original object. A correctly resealed readiness value with a
constructor-invalid `status` reached a positive Capability qualification.

Required closure:

- every B1 value is reconstructed through its owning grammar;
- relations use only reconstructed locals;
- invalid but correctly resealed values fail before precedence;
- Capability receives B1-validated snapshots, not original supplied objects.

### AUD-002 — unmetered B1/C2A graph expansion

Current B1/C2A projection can recursively expand hostile exact-class state
before the B1 meter is charged.

Required closure:

- raw stored structure is metered before public projection/canonicalization;
- active cycles fail;
- shared aliases are charged for every occurrence;
- nested C2A and L34 values use owner-controlled reconstruction helpers;
- exact tariffs and relation maxima below are enforced;
- no supplied public semantic method, equality, iterator, hash,
  canonicalizer, or digest is invoked before owner reconstruction.

The frozen work model is an occurrence-work contract. It is not a finite
integer-bit-length, serialized-byte, or wall-clock bound. Do not silently add a
C2A integer upper limit or SQLite-width restriction. State this nonclaim
explicitly. Stop if closing the reported graph-amplification defect requires a
schema or scalar-domain change.

### AUD-003 — hostile Wire owner key leaks a foreign exception

Validate exact key types before equality or lookup and translate all ordinary
failures to the fixed import invariant, raised from `None` outside the foreign
handler.

### AUD-004 — Wire owner callable remains reachable

Invoke the owner exactly once and delete the imported callable binding after
initialization. Retain only the fixed ref/digest strings.

### AUD-005 — stale RW0 tranche map

Mark B1, Wire, and Capability private semantics current; retain C/D/E
mechanics as future.

### AUD-006 — impossible error reflection-proof claim

Promise supported-public-surface reason-only semantic immutability, not
absolute resistance to deliberate low-level CPython reflection.

### AUD-007 — generic session privacy classification

Unknown `session` and session-bearing keys must be
`privacy_forbidden_material`; the exact accepted field
`external_session_non_authority` remains accepted because exact-field
recognition precedes fragment scanning.

### AUD-008 — stale open-decision framing wording

Mark NWPF representational framing, worker-result grammar, and process/result
classification fixed. Keep physical transport/stream/process plumbing, route
wrappers, and runtime reconciliation open.

ACCEPTED ARCHITECTURE — DO NOT REOPEN

Preserve exactly:

- Wire precedes Capability.
- Capability's three values, fields, schemas, digest domains, canonical bytes,
  fourteen dimensions, result/reason matrix, and precedence.
- Fixed Wire profile:
  `rw0-wire-nwpf-v1`,
  digest
  `470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454`.
- Declaration, supplied observation, and Coordinator qualification remain
  distinct.
- Source-ref inequality is only structural non-collapse.
- B1 owns phase, authority, readiness, and host qualification.
- C2A and lineage owners retain their field grammar and identity ownership.
- No value authenticates a source, grants authority/permission/acceptance,
  persists truth, contacts a worker/provider/host, or selects CLI/App Server,
  provider, route, credential, account, model, endpoint, or session.
- RW0-C owns durable facts/recovery/terminal/latch.
- RW0-D/E own process, provider, credential, transport, and live proof.
- ES retains route admission/runtime authority.
- No package export, public caller, dependency, migration, SQL, schema,
  `StateStore`, or `WriterSession` widening.
- Wire production source stays byte-identical.

TEST-FIRST REPAIR GATE

Before production/source/doc repair:

1. modify only authorized direct owner/Capability/status tests needed to encode
   the accepted findings;
2. retain a post-test-edit repository fingerprint;
3. run one selected causal-red gate that independently demonstrates at least:
   - correctly resealed invalid readiness currently reaches the wrong path;
   - hostile shared-DAG/cycle owner state reaches projection before the new
     owner meter;
   - hostile Wire owner key leaks or is not normalized to the fixed invariant;
   - the imported Wire owner callable remains retained;
   - generic session unknown keys receive the wrong reason;
   - stale tranche/open-decision wording is still accepted;
4. require failures to be the intended missing repair behaviors only;
5. preserve stdout, stderr, JUnit, return code, exact node IDs, environment,
   umask, and pre/post fingerprints.

Fixture, syntax, collection, unrelated import, baseline, or path-scope failure
does not satisfy the red gate.

C2A OWNER HARDENING

Modify:

```text
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
```

Add private owner helpers in substance:

```python
class _WorkerExecutionReconstructionBudget: ...
def _exact_worker_execution_reconstruction_work(expected): ...
def _reconstruct_exact_worker_execution_value(
    value,
    expected,
    budget=None,
): ...
```

Accepted exact classes only:

```text
CeilingsV1
CapsuleEntryV1
WorkSpecV1
AttemptFenceV1
EffectFenceV1
WorkerCommandV1
DeliveryEnvelopeV1
CandidateCapsuleManifestV1
```

`WorkerObservationV1` is explicitly excluded.

Required algorithm:

1. require `type(value) is expected`;
2. inspect only owner-known private slots with `object.__getattribute__`;
3. use an explicit non-recursive stack;
4. treat only exact built-in dict/list/tuple as containers;
5. charge every root, slot, member, and occurrence before inspection/descent;
6. reject active-path cycles;
7. recharge a shared alias at every occurrence after it leaves the active path;
8. never call supplied public methods, equality, hashes, iterators,
   canonicalizers, or digests;
9. reserve the complete trusted construction/canonical/digest/projection tariff
   before invoking the owning constructor;
10. return a fresh exact value and fresh validated plain projection;
11. catch ordinary `Exception`, never process-control `BaseException`;
12. expose only fixed content-free private owner failures.

Exact graph/tariff table:

```text
CeilingsV1                     G=16   tariff=32
CapsuleEntryV1                 G=8    tariff=16
WorkSpecV1                     G=86   tariff=172
AttemptFenceV1                 G=46   tariff=92
EffectFenceV1                  G=51   tariff=102
WorkerCommandV1                G=58   tariff=116
DeliveryEnvelopeV1             G=16   tariff=32
CandidateCapsuleManifestV1     G=49   tariff=98
```

A direct call enforces its own exact tariff. When called beneath B1, B1 must
reserve the exact owner tariff in its outer counter before invoking this
independently enforced owner boundary.

Do not alter any existing C2A schema, field, enum, validation rule, canonical
byte, digest, public method, effect relation, source/observation kind, or
accepted scalar domain.

Update the C2A owner documentation only to state the private reconstruction
helper, occurrence-work posture, and unchanged public semantics.

LINEAGE OWNER HARDENING

Modify:

```text
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
```

Add:

```python
class _ExactC2B3DLineageReconstructionBudget: ...
_EXACT_C2B3D_LINEAGE_RECONSTRUCTION_WORK = 70
def _reconstruct_exact_c2b3d_lineage(value, budget=None): ...
```

Required behavior:

- exact `CanonicalC2B3DLineage` only;
- graph `G=35`, tariff `70`;
- same raw-slot, non-recursive, cycle, alias, owner-error, and trusted-
  construction rules as the C2A helper;
- preserve the exact L34 field inventory, route semantics, and all canonical
  bytes/digests;
- no public export or reverse import.

B1 OWNER HARDENING

Modify:

```text
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
```

Add private helpers in substance:

```python
_extract_exact_b1_stored_mapping(value, expected, budget)
_from_mapping_impl(expected, payload)
_reconstruct_exact_b1_value(value, expected, budget=None)
```

Required algorithm:

1. require exact B1 class;
2. charge the root before reading `_values`;
3. read `_values` only with `object.__getattribute__`;
4. require exact tuple and exact class field count;
5. charge every slot before inspection/descent;
6. traverse with an explicit non-recursive
   `visit` / `dict-member` / `leave` stack;
7. exact built-in dict/list/tuple containers only;
8. active-cycle rejection and repeated-alias recharging;
9. delegate nested C2A values and L34 through their owner helpers;
10. reserve every nested owner tariff in the outer B1 counter before the owner
    call;
11. rebuild through `_from_mapping_impl`;
12. return a fresh exact B1 value and already validated built-in projection;
13. ordinary owner failures become existing content-free
    `relation_mismatch`;
14. outer exhaustion remains `cumulative_work_exhausted`.

Harden all state-revealing B1 surfaces:

```text
declared field reads
to_mapping
identity_mapping
canonical_identity_bytes
computed_digest
copy
deepcopy
same-class equality
every B1 relation
```

Preserve valid behavior:

- valid declared field reads return values from the reconstructed projection;
- `copy` and `deepcopy` retain the currently documented valid immutable
  behavior only after successful reconstruction;
- equality reconstructs both exact-class operands and compares fresh exact
  values/projections;
- different classes remain unequal;
- repr/str remain content-free;
- mutation, hashing, and serialization remain prohibited/state-free;
- ordinary `_values` access is hidden as currently documented.

No public B1 schema, field, digest domain, canonical byte, enum, relation
meaning, source-authenticity posture, or nonclaim may change.

EXACT B1 VALUE BUDGETS

Use these exact values:

```text
Value                         S     C     R=S+C   Equality=2R
Phase-entry basis            122   174   296     592
Authority observation         78   124   202     404
Subordinate proposal          62    92   154     308
Custody observation           17    34    51     102
Retrieval event               38    76   114     228
Readiness observation         40    80   120     240
Host qualification            46    92   138     276
Terminal outcome              32    64    96     192
```

`C` is the existing public construction limit. `S` includes raw stored-state
work and nested owner reservations. `R` is safe reconstruction.

Maximum-valid must succeed; one-under must fail with
`cumulative_work_exhausted`. Literal test-owned arithmetic must not derive its
expectations solely from production constants.

B1 RELATIONS AND EXACT MAXIMA

Every relation:

- creates or receives one shared exact outer B1 counter;
- reconstructs every B1 input;
- reserves and invokes every nested C2A/lineage owner helper;
- stores fresh locals/projections;
- never reads original supplied B1 values after reconstruction;
- preserves existing result/error semantics;
- sanitizes owner failures;
- enforces its exact maximum and one-under failure.

Exact maxima:

```text
validate_phase_entry_basis:
296+70+4+172+92+102+116+32+3+4 = 891

validate_authority_observation:
296+202+92+102+102+116+98+102+1+4+30+6 = 1151

validate_per_fence_basis:
202+154+92+102 = 550

validate_external_common_family_claim:
202+154+92+102 = 550

validate_subordinate_narrowing:
296+202+154+92+102+1+8+30+6 = 891

validate_custody_binding:
296+51+172+1 = 520

validate_retrieval_event_sequence:
296+51+202+154+3*114+1+92+102+1+8+30+6 = 1285

validate_host_qualification:
296+202+120+138+102+1+4 = 863

validate_terminal_outcome_binding:
296+96+7+96+1 = 496

each standalone terminal-shape validator:
96+1 = 97
```

The authority maximum includes both optional manifest and cancellation-target
values. Retrieval's maximum uses three events. Terminal binding intentionally
reconstructs the outcome again inside its nested shape check.

PRIVATE HOST SNAPSHOT SEAM

Add:

```python
_validate_host_qualification_with_snapshots(...)
```

It must:

1. perform the complete hardened B1 host qualification exactly once;
2. use the exact 863-unit owner budget;
3. return only fresh validated safe projections for:
   - phase basis;
   - authority observation;
   - readiness observation;
   - host qualification;
   - current effect fence;
4. expose no original supplied B1/C2A object;
5. retain no raw private material;
6. preserve the existing public `validate_host_qualification(...) -> None`
   behavior by delegating to the same hardened core.

The helper is private and has exactly one production consumer: Capability.
No package export or public caller is authorized.

CAPABILITY COMPOSITION REPAIR

Modify:

```text
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
```

Preserve Capability's local reconstruction budgets:

```text
declaration      72
observation      93
qualification    78
five snapshots + time 6
Capability local 249
```

Replace the direct public B1 call/original-object composition with the private
B1 snapshot seam.

Exact complete composition:

```text
B1 host validation and snapshots   863
Capability local                   249
                                   ----
complete occurrence-work total    1112
```

These are separately enforced counters. There is no extra snapshot pass. Retire
all `241`, `490`, or fictitious `1111` claims.

Capability must use only returned fresh projections plus its own reconstructed
locals. A correctly resealed invalid B1 readiness status must become sealed
`relation_mismatch` before Capability result precedence.

CAPABILITY WIRE OWNER REPAIR

Import the owner as:

```text
_wire_profile_mapping_owner
```

Implement `_load_wire_owner_pair(owner_call)` so that it:

1. makes exactly one no-argument owner call;
2. requires exact outer `dict` of length four;
3. iterates all keys and proves each is exact built-in `str` before any
   equality comparison or lookup;
4. requires exact ordered keys:
   `schema_id`, `profile_ref`, `manifest`, `profile_digest`;
5. validates exact field types, manifest exact-dict shape, fixed schema/ref,
   and fixed digest;
6. extracts only ref/digest strings;
7. clears temporary owner and manifest references;
8. exits any foreign exception handler;
9. raises only
   `RuntimeError("RW0WorkerMechanismCapabilityWireOwnerInvariant")`
   from `None` outside the handler.

At module initialization:

```text
call loader exactly once
assign only fixed ref/digest
delete _wire_profile_mapping_owner
```

No Wire callable or manifest may remain reachable from Capability module
globals. Controlled tests call the private loader with supplied test callables;
production does not retain the imported owner function.

Capability error contract:

- supported public semantic state is reason-only and immutable;
- ordinary assignment/deletion and ordinary `__dict__` access are rejected or
  hidden;
- `.reason`, `args`, `str`, `repr`, equality, serialization, cause/context, and
  traceback hygiene remain content-free;
- low-level deliberate CPython reflection is outside the supported semantic
  API, creates no authority, and must not influence any method or automatic
  payload retention;
- remove any absolute reflection-proof wording.

Privacy:

- add generic `session` to private unknown-key fragments;
- accepted exact `external_session_non_authority` still bypasses privacy
  scanning;
- all session-bearing unknowns fail
  `privacy_forbidden_material`.

Preserve all Capability schemas, fields, canonical vectors, identity domains,
qualification predicates, precedence, and fixed Wire pair.

DOCUMENTATION REPAIR

Update only the authorized owner/status documents.

Required current-state statement:

```text
RW0-B2-Wire does not own or alter RW0-B1 or C2A schema,
canonical-identity, semantic-outcome, or authority contracts; their protected
owner reconstruction and occurrence-work accounting are hardened separately
for fail-closed Capability composition.
```

Required current/future split:

- B1, Wire, and Capability private semantics are current implemented contracts.
- C/D/E durable, transport, process, provider, credential, live-proof, and
  runtime mechanics remain future.
- NWPF representational framing, worker-result grammar, and process/result
  classification are fixed.
- Physical stream/process plumbing, route wrappers, and terminal runtime
  reconciliation remain open.

Update C2A documentation to describe the private helper without claiming any
schema, semantic, canonical, public, or scalar-domain change.

Update B1 documentation with exact new value/relation budgets and the private
snapshot seam.

Update Capability documentation from `249+241=490` to `249+863=1112`.

Update `test_c2a_nonimplementation.py` and its owning prose so “C2A remains
unchanged” means public schema/semantics/canonical identities remain unchanged,
while the private owner reconstruction helper is current.

EXACT 30-PATH CEILING

Final topology must be exactly:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
all regular mode 0644
no new file
```

### Existing candidate paths requiring repair — 18

```text
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-capability.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/worker-execution-boundary.md
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
tests/test_architecture_contracts.py
tests/test_c2a_nonimplementation.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_software_development_progression_boundary.py
```

### Existing candidate paths that must remain byte-identical to opening — 2

```text
tests/test_runtime_non_authority.py
tests/test_rw0_b2_capability_vectors.py
```

### Newly authorized existing owner paths — 10

```text
.docs/c2a-first-slice-semantic-protocol-contract.md
.docs/c2a1-pure-semantic-values.md
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_section41_pre_execution_plan_disposition_contracts.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_relations.py
```

Everything outside this exact set is protected byte-for-byte.

Explicitly protected include:

```text
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml
all SQL/migrations/schemas/catalog behavior
StateStore
WriterSession
AGENTS.md
README.md
.docs/c2b-durable-development-state.md
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py
tests/test_worker_execution_semantic_vectors.py
tests/test_worker_execution_semantic_relations.py
tests/test_c2a_relations.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_rw0_b1_vectors.py
```

Stop immediately if a 31st path is needed.

DIRECT CAUSAL TEST REQUIREMENTS

Add or strengthen test-owned literal oracles for:

1. every admitted C2A owner class and its exact `G`/`2G` tariff;
2. exact L34 `35/70`;
3. all eight B1 `S/C/R/equality` values;
4. every B1 relation maximum and one-under;
5. maximum-valid, cycle, deep, shared-DAG, and repeated-alias inputs;
6. exact-class, missing/wrong `_values`, wrong tuple length, hostile nested
   members, invalid enums/refs/digests/times, and correctly resealed invalid
   states;
7. selective and class-wide C2A/lineage owner-helper bypasses;
8. selective and class-wide B1 reconstruction bypasses;
9. assertions that relations read only reconstructed locals;
10. invalid readiness fails before host/Capability positive precedence;
11. host snapshot seam exact-once behavior and fresh-projection output;
12. Capability total `1112` and retirement of `241/490`;
13. hostile Wire key fixed invariant with null cause/context;
14. no retained owner callable or manifest;
15. generic session privacy and accepted exact session field;
16. ordinary error `__dict__` boundary and low-level reflective-state
    non-influence;
17. stale tranche/open-decision wording;
18. import direction, no reverse imports, no package export/caller, and exact
    30-path/protected-byte controls.

Expected new test nodes may belong only to:

```text
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_section41_pre_execution_plan_disposition_contracts.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Other existing test edits may change assertions inside existing nodes only. No
existing node may be removed, renamed, skipped, xfailed, reparameterized, or
reordered.

VALIDATION ENVIRONMENT

Use one new external operator-owned, non-symlink, mode-0700 evidence root.

For every child:

```text
umask 022 before launch
child numerical umask must be 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Retain exact argv, environment, timing, return code, stdout/stderr, JUnit,
structured counts, and before/after repository fingerprints.

FINAL VALIDATION ORDER

After final source/docs/tests are frozen:

1. run the selected causal tests;
2. run focused C2A/lineage:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_c2a_first_slice_semantic_protocol_contract.py
   tests/test_c2a_effects_and_recovery.py
   tests/test_section41_pre_execution_plan_disposition_contracts.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   tests/test_c2a_nonimplementation.py
   ```
3. run focused B1:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```
4. run Capability/Wire boundary:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
5. run static/status:
   ```text
   tests/test_architecture_contracts.py
   tests/test_runtime_non_authority.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_software_development_progression_boundary.py
   ```
6. collect the final complete node list exactly once;
7. compare against opening:
   - every opening node remains in identical relative order;
   - zero removals/renames;
   - every addition belongs only to the permitted direct owner files;
8. run `git diff --check`;
9. run exact path/mode/protected/import/public/residue/operation/lock guards;
10. run the complete repository suite exactly once:
    ```text
    python3 -B -m pytest -p no:cacheprovider -W error -q
    ```

Before running any named target, verify that every target exists exactly. Stop
rather than substituting a similarly named path.

Every credited green run must have:

- return code 0;
- zero failures/errors/skips/xfails/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate or unmapped cases;
- matching caller/child umask;
- unchanged candidate fingerprint.

FULL-SUITE REPAIR POLICY

If full-suite attempt 001 fails:

- preserve all evidence;
- repair only a deterministic patch-caused failure inside the 30-path ceiling;
- rerun affected focused groups;
- run complete-suite attempt 002 exactly once.

Stop without further mutation if:

- failure is outside the repair scope;
- a 31st path is required;
- a protected byte must change;
- a third complete-suite attempt would be needed.

PROVENANCE CLOSEOUT

After final validation and cleanup:

1. require exact final topology `30/24/6/0/0`;
2. run the exact recipe twice;
3. require byte-identical manifests and complete outputs;
4. retain:
   - exact recipe source;
   - complete outputs;
   - canonical manifests;
   - tracked textual-diff SHA-256;
   - every path classification/type/mode/size/SHA-256;
   - opening and final node lists and delta;
   - red and green validation records;
   - final guards;
5. prove:
   - exactly 18 opening-candidate paths changed;
   - exactly two opening-candidate paths remained byte-identical;
   - exactly ten HEAD-clean owner paths became dirty;
   - no path outside the 30-path ceiling differs from HEAD;
6. remove only repair-created transient artifacts.

Do not stage, commit, push, create a PR, or perform an independent audit.

FRESH AUDIT REQUIREMENT

The final report must state that the repaired bytes require a fresh independent
read-only audit.

Future audit perspectives are:

1. provenance, nodes, validation, and evidence;
2. C2A/lineage raw extraction, tariffs, aliases, bypasses, and imports;
3. all B1 values/relations, invalid readiness, reconstructed-local use, and
   budgets;
4. Capability loader/error/privacy/composition plus documentation and authority
   boundaries.

STOP CONDITIONS

Stop without further mutation if:

- opening provenance differs;
- current branch/state differs;
- owner hardening requires any schema, field, digest domain, canonical byte,
  public API, scalar-domain, migration, SQL, durable-state, process, provider,
  or Wire-source change;
- a reverse import, package export, public caller, or dependency is required;
- exact budgets cannot be implemented and proven;
- a broad C2A rewrite is needed;
- valid existing vectors change;
- a 31st path is needed;
- protected files drift;
- node ownership violates the frozen policy;
- branch movement/reset/rebase/stash is needed;
- validation or provenance is unstable.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_INTEGRATED_OWNER_REPAIR_IMPLEMENTED_READY_FOR_FRESH_REAUDIT
```

only when every accepted finding is repaired, all final validation is green,
the complete suite passes, exact 30-path provenance is stable, and every stop
condition is false.

FINAL REPORT

Include:

1. opening and final repository identity;
2. exact 20-path opening target reproduction;
3. test-first red evidence;
4. exact 30-path final ledger and opening-to-final classifications;
5. C2A owner-helper implementation and tariffs;
6. lineage helper implementation and tariff;
7. B1 value reconstruction and public surfaces;
8. every B1 relation budget and reconstructed-local proof;
9. host snapshot seam and Capability composition `863+249=1112`;
10. Capability Wire/error/privacy repair;
11. documentation/status correction;
12. node identity and additions;
13. all validation attempts, including failed development/full-suite runs;
14. final complete-suite count and attempt number;
15. final provenance identities and complete canonical manifest;
16. protected bytes and public/authority non-widening;
17. explicit occurrence-work nonclaim;
18. remaining RW0-C/D/E/ES seams;
19. separate provenance, validation, and implementation confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
WIRE_IMPLEMENTATION_NOT_MODIFIED
```
