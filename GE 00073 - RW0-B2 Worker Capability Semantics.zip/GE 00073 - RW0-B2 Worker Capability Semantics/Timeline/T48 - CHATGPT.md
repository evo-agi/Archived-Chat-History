## Engineering disposition

**Accept the `REJECT`. Do not stage or commit. Return to the existing workspace-write B2-Wire conversation for a one-file, test-only repair.**

F17 is now independently closed. Production remains accepted and frozen. The only open issue is F18: the test proves that the selected wrapper *intended* to delegate fifteen checks, but it does not prove that those delegated checks actually enforced the B2 integer maximum. A class-wide Attempt bypass can return normally, reach a later digest failure, and still satisfy the test’s expected sanitized error.

This is a genuine causal-oracle defect, not a production defect.

### Required correction

The repair must retain the current single test node and all existing 64-path positive and negative coverage. It must add a **behavioral sentinel** inside that same node:

1. Keep the selected one-operation bypass, such as `AttemptFenceV1.global_stop_version`, and require exactly one selected bypass plus one selected Attempt-owner boundary call.

2. In a separate fresh graph, keep the selected field valid and make a different Attempt field oversized—for example:

   ```text
   AttemptFenceV1.ceilings.max_active_invocations = MAX + 1
   ```

   This non-selected sentinel must produce `invalid_field_value` **before**:

   - `AttemptFenceV1.from_mapping`;
   - Attempt canonical identity or digest computation;
   - Wire canonicalization, digesting, or framing.

3. Inject a class-wide Attempt bypass control. The sentinel helper must reject it because the Attempt owner or downstream canonicalization becomes reachable, or because the real early-rejection evidence disappears. A later digest mismatch must not satisfy the oracle.

4. Preserve the unrelated Effect control and all F17 coverage ledgers.

Only this file may change:

```text
tests/test_rw0_b2_wire_relations.py
```

The node collection must remain exactly **4,655**, byte-for-byte and in the same order.

The long audit sequence has repeatedly validated the original B2 forecast: noncausal mutants and self-confirming test oracles were explicitly identified as live risks before implementation. 

## Next action

Send this complete prompt to the **existing workspace-write RW0-B2-Wire conversation**:

:chatgpt-content-reference{index="3"}

Verify the attachment:

```text
Filename:
Coordinator_RW0_B2_Wire_Sixth_Audit_Test_Repair_Prompt.txt

Size:
24,365 bytes

SHA-256:
b6453a8af42a70f47078db598aac2efe5821a28f859c3b32ff99c8e9b79b4906
```

The required success token is:

```text
COORDINATOR_RW0_B2_WIRE_SIXTH_AUDIT_TEST_FINDING_REPAIRED_READY_FOR_FRESH_REAUDIT
```

The prompt requires a test-first causal gate in which an externally installed class-wide Attempt bypass **fails for the behavioral-sentinel assertion**, followed by a green run after removing that mutant. Production source and documentation remain strictly protected.

After repair, start another fresh read-only audit. The project protocol requires audit findings to return to the sole writer, with every changed byte receiving a later independent audit.  Staging is permitted only after that audit accepts the exact candidate; the commit gate must then stage precisely the audited paths and compare staged and committed blobs against the accepted manifest. 

### Sources

- Codex independent-audit response supplied in this turn.
- Original B2 audit-risk forecast. 
- Repair and fresh-audit lifecycle. 
- Audited-byte commit-gate requirements. 

**Confidence:** Very high that F18 remains open; very high that production should remain untouched; high that the escaped mutant can be killed within the existing one-file, zero-node-delta boundary.
