## Engineering disposition

**The `BLOCK` is valid, but the underlying commit-compatible behavior remains accepted. Proceed with one more bounded repair to the same Capability boundary test.**

The audit found two regression-assurance defects, not an implementation or authority defect:

1. **The no-status guard is an incomplete denylist.** It catches some obvious command spellings but misses semantically equivalent forms such as prebuilt argv, shell strings, imported or assigned callables, nested attribute aliases, and dynamic dispatch. The durable correction is a **closed reachable-call contract**, not another expansion of forbidden keywords.

2. **A protected-content assertion is non-causal.** An external audit copy could weaken it while all 17 boundary tests stayed green. Every protected-content row therefore needs an independent literal expectation and a one-predicate mutation proving that its owning assertion is necessary.

The audit otherwise confirmed:

- actual A/B/C state independence;
- identical projections in all three states;
- exact staged/clean tree `52e32a55dc2e6b023b669810fb244301807f7618`;
- valid retained live and clean `5,057`-test envelopes;
- unchanged production, documentation, imports, public surfaces, and authority boundaries.

## Exact repair boundary

Only this path may change:

```text
tests/test_rw0_b2_capability_boundaries.py
```

The other 29 candidate paths must remain byte-identical. No production source or governing document may change.

### Closed call-surface design

The repaired guard must start from the permanent boundary test, resolve its complete local helper graph, and enforce a finite allowlist of reachable helpers, globals, and external calls.

It must reject calls through:

```text
constructed or module-level argv
shell strings and concatenated commands
imported callable aliases
module and nested attribute aliases
getattr or other dynamic dispatch
default-argument or closure callables
unknown local helpers
GitPython/dulwich-like status APIs
subprocess, os.system/popen, spawn, or exec families
```

This avoids pretending that every Git-status dependency can be recognized from literal command text.

### Protected-content design

The 43-row stable projection remains, but each protected-content row must have:

- an independent literal expected value;
- a unique row ID and diagnostic;
- a fresh one-predicate mutation;
- before/after fixture hashes;
- proof that disabling only that row’s assertion lets the mutant escape and therefore fails the causal test.

The exact audit survivor must be included.

## Implementation handoff

Send this complete prompt to the **existing write-enabled Capability implementation conversation**:

:chatgpt-content-reference{index="0"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Commit_Compatibility_Final_Audit_Findings_Repair_Prompt.txt

Size:
21,746 bytes

SHA-256:
800b783d772bb8f6f051a79e4294dbbefa5a5e9b5311b68bb27cf94147e8dc13
```

The prompt is bound to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Opening manifest:
0919e82038367f54defd36171a19550873f38acae714bd7398e5a56b2fb8d77a

Opening nodes:
5,057

Opening node-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

Opening clean candidate tree:
52e32a55dc2e6b023b669810fb244301807f7618

Latest audit root:
/private/tmp/g4.S4uFyK

Latest audit-index SHA-256:
f4836712bfc0e55dda2bb489401dabc55958016fc3c1778f8ad40a33bc5cb5b9
```

The repair must again prove:

```text
target passes unstaged
target passes with alternate staged index
target passes in an external clean commit
live complete suite passes
clean-commit complete suite passes
source real index remains untouched
exact one-file provenance is stable
```

The required successful outcome is:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

That authorizes only another fresh read-only independent audit. The commit gate remains blocked until that audit returns `ACCEPT`.

### Source

- Codex final fresh re-audit response supplied in this turn.

**Confidence:** High that both blockers are confined to `tests/test_rw0_b2_capability_boundaries.py`; high that no production or document change is justified; medium-high that replacing the denylist with a closed call surface and making every protected-content row mutation-sensitive will close the next audit.
