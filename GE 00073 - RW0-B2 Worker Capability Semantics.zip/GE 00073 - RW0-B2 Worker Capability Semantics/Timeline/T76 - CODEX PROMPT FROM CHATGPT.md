PROMPT_ID

RW0_B2_CAPABILITY_INTEGRATED_OWNER_REPAIR_AUDIT_FINDINGS_FRESH_REAUDIT_V1

TITLE

Coordinator RW0-B2-Capability — fresh independent re-audit of the seven
audit-finding repairs, exact 30-path candidate, and causal validation evidence

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated independent re-audit.

Use a new Codex conversation. Do not use the implementation conversation.

No repository mutation, formatting, cleanup of repository bytes, dependency
installation, staging, commit, push, PR, merge, tag, release, deployment,
remote/network/service/provider/host contact, worker/model invocation,
database mutation, migration, or supporting-repository inspection is
authorized.

The audit may create isolated read-only probes, pytest outputs, a clean external
HEAD archive, and provenance evidence only beneath one new external audit root.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Determine whether the exact repaired candidate closes all seven findings from
the preceding independent audit without changing accepted schemas, identities,
budgets, qualification semantics, authority boundaries, public surfaces, or
later-owner seams.

The seven findings under re-audit are:

```text
RW0B2-AUD-001  Wire-loader traceback/material retention
RW0B2-AUD-002  Capability error semantic observations mutable through object.__setattr__
RW0B2-AUD-003  stale B1 retrieval maximum 374 versus 1285
RW0B2-AUD-004  stale B1 no-production-consumer statement
RW0B2-AUD-005  RW0-B current/blocked tranche contradiction
RW0B2-AUD-006  C2A tuple member dereferenced before occurrence charge
RW0B2-AUD-007  missing causal reconstruction matrix for all thirteen B1 relations
```

Do not reopen the accepted B1, Wire, or Capability architecture unless the
candidate itself demonstrates a fundamental contradiction.

EXPECTED LIVE IDENTITY

Require at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate modes:
all regular 0644
```

Require no Git operation, lock, `git diff --check` failure, repository cache,
bytecode, database, journal, archive, build output, generated repository
manifest, recorder residue, or thirty-first changed path.

Do not fetch, switch, reset, clean, stash, rebase, or merge.

IMPLEMENTATION EVIDENCE

Final repair evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-findings-repair.GZaQQ1
```

Named final records:

```text
final_closeout_aggregate.json
final_recipe_1_manifest.json
final_v3_12_complete_suite_attempt_002/summary.json
final_v3_11_guards/guards.json
cleanup_record.json
```

Expected final identities reported by implementation:

```text
final canonical-manifest SHA-256:
527ba2c27d94a0361912210eb80c718762fcc4a4df1d9b503524a8e91af115ac

final tracked textual-diff SHA-256:
6133bfa7994b12f63769a0d9a8843bb06296f2cc1185cc4c305b43c3c51ae5ee

final complete recipe stdout SHA-256:
ea927882df7952ff31384d3cc42b5fe60dcca65127125e4e99f6ee4fc00cff8e

file count:
30

final pytest nodes:
4743

final ordered-node-list SHA-256:
05fea81edde4fde4cf5fcb15a8e2c397eead7410688665b1500c0cb09970a064
```

Opening candidate evidence for the repair:

```text
/private/tmp/ge-coordinator-rw0-b2-repair.pO8M0Y/final_recipe_1_manifest.json

opening canonical-manifest SHA-256:
177dab5f0c89f0bf99273c2fe9b3f8123f4df34c9dc29306acafb0308eaeb900

opening nodes:
4719

opening ordered-node-list SHA-256:
24f6fe99b8ef728859327884da26f17f6dc9f8ea834aaf2b26a5914122399be6
```

Preceding independent-audit evidence:

```text
/private/tmp/ge-coordinator-rw0-b2-fresh-audit.DbthN0
```

Safely `lstat` all path components before reading retained evidence. Reject
unsafe symlink traversal. Inventory only the evidence needed for this audit.
Do not modify any prior evidence root.

EXACT RECIPE SOURCE

Decode the following base64 only beneath the new audit root, require exactly
3,945 bytes and SHA-256
`db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`,
and retain it mode 0400:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

PROVENANCE GATE

Before correctness inspection or audit subagents:

1. create one new operator-owned, non-symlink, mode-0700 audit root beneath
   `/private/tmp`;
2. verify the exact repository identity and `30/24/6/0/0` topology;
3. safely load
   `/private/tmp/ge-coordinator-rw0-b2-findings-repair.GZaQQ1/final_recipe_1_manifest.json`;
4. require it to be regular, safely reachable, canonical JSON, file count 30,
   and SHA-256
   `527ba2c27d94a0361912210eb80c718762fcc4a4df1d9b503524a8e91af115ac`;
5. verify every manifest path by classification, regular-file type, mode, size,
   and SHA-256;
6. verify there is no thirty-first changed path;
7. verify every path outside the manifest equals HEAD;
8. verify the exact recipe source;
9. run it twice with only its historical external output sink redirected to
   unique audit-root files;
10. require both generated manifests to equal the retained final manifest
    byte-for-byte;
11. require both complete outputs to be byte-identical and hash to
    `ea927882df7952ff31384d3cc42b5fe60dcca65127125e4e99f6ee4fc00cff8e`;
12. require tracked textual diff
    `6133bfa7994b12f63769a0d9a8843bb06296f2cc1185cc4c305b43c3c51ae5ee`;
13. safely load the opening repair manifest and prove:
    - exactly the eleven authorized entries changed;
    - the other nineteen entries retained exact path, kind, type, mode, size,
      and hash;
    - the path set remained exactly thirty;
14. verify all explicitly protected source and public surfaces equal their
    intended opening bytes or HEAD, as applicable.

On any mismatch, stop before correctness inspection and return exactly:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not reconstruct, approximate, or regenerate a replacement target.

EXACT REPAIR DELTA

Exactly these eleven entries must differ from the opening repair manifest:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-capability.md
.docs/rw0-remote-worker-contact-phase-entry.md
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_worker_execution_semantic_values.py
```

The other nineteen opening-candidate entries must be byte-identical.

Particularly protect:

```text
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml
all SQL/migrations/schemas/catalog behavior
StateStore
WriterSession
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_vectors.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_worker_execution_semantic_vectors.py
tests/test_worker_execution_semantic_relations.py
tests/test_c2a_relations.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

AUDIT PERSPECTIVES

After the provenance gate, use exactly four bounded, non-nesting, read-only
perspectives when available. No perspective may run tests or mutate anything.

1. Capability loader and error-boundary auditor
   - full traceback/local/global/default/closure reachability;
   - partial-module state on import failure;
   - foreign exception cause/context;
   - success and failure deletion of the imported Wire owner;
   - fixed pair retention only;
   - WeakKeyDictionary reason registry semantics;
   - direct `object.__setattr__` attempts against `_reason`, `reason`, `args`,
     `__cause__`, and `__context__`;
   - ordinary `__dict__`, assignment, deletion, repr/str, serialization,
     equality/identity, GC, and weak-reference behavior;
   - no payload or authority retention.

2. C2A occurrence-work and owner-semantics auditor
   - tuple scheduling and exact charge-before-index ordering;
   - no bulk member dereference or scheduling before payment;
   - unchanged accepted classes, tariffs, aliases, cycles, vectors, scalar
     domains, and public behavior;
   - runtime causal strength of the checked test;
   - no new public hook or source widening.

3. B1 relation-causality and owner-document auditor
   - literal inventory of all thirteen public B1 relation entry points;
   - complete fresh harness for every relation;
   - normal invalid-state rejection;
   - selective reconstruction bypass;
   - class-wide reconstruction bypass;
   - original-object poisoning after reconstruction;
   - each mutant changes the intended predicate and is killed before unrelated
     malformed input or later sanitized errors;
   - sole current retrieval maximum `1285`;
   - Capability as sole current cross-module production consumer;
   - no stale `374` or no-consumer current claim.

4. RW0 status, test, evidence, node, public-boundary, and provenance auditor
   - B1/Wire/Capability current status;
   - C/D/E/ES allocation of remaining mechanics;
   - no future or blocked RW0-B row for already implemented private semantics;
   - stale-table mutants and complete owner-region tests;
   - implementation attempt classification;
   - node additions and existing-node preservation;
   - imports, exports, callers, protected bytes, and exact eleven-path delta;
   - cleanup and evidence quality.

Every finding must include:

```text
ID
type
severity: critical | high | medium | low | observation
current contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect or pre-existing issue
```

Preserve minority reports and disagreements.

REQUIRED SOURCE AND TEST INSPECTION

Inspect every changed path and the protected owners they depend on.

Capability:

```text
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
.docs/rw0-b2-capability.md
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_vectors.py
```

C2A tuple repair:

```text
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
.docs/c2a-first-slice-semantic-protocol-contract.md
.docs/c2a1-pure-semantic-values.md
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_worker_execution_semantic_vectors.py
tests/test_worker_execution_semantic_relations.py
tests/test_c2a_relations.py
```

B1:

```text
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
.docs/rw0-b1-pure-phase-values.md
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_boundaries.py
```

RW0 status:

```text
.docs/rw0-remote-worker-contact-phase-entry.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

Static/public boundaries:

```text
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml
```

Inspect additional Coordinator files only when a concrete import, relation,
status assertion, or public-boundary dependency requires them. Record each
addition and why. Do not inspect another repository.

ACCEPTED UNCHANGED CONTRACTS

Do not treat the repair as permission to reopen:

- C2A schemas, fields, enums, digest domains, canonical bytes, scalar domains,
  or public relations;
- B1 schemas, fields, result grammars, relation meanings, or exact budgets;
- Capability schemas, fields, fourteen dimensions, qualification precedence,
  fixed Wire pair, or `863 + 249 = 1112`;
- Wire source, codec, classifier, profile, or result grammar;
- source-authenticity, permission, acceptance, contact, persistence, runtime,
  provider, credential, session, endpoint, Git, or publication authority;
- RW0-C/D/E and ES owner boundaries.

REPAIR-SPECIFIC HYPOTHESES

### A. Wire-owner import failure hygiene

Independently isolate module import with owner callables that:

- return a mapping containing a hostile non-string key whose equality/hash or
  lookup raises with a sentinel;
- return a mapping/manifest containing sentinel objects and cycles;
- raise an ordinary custom exception retaining a sentinel;
- return wrong outer type, wrong key order, extra/missing key, wrong schema,
  wrong ref, wrong digest, and wrong manifest type;
- raise `KeyboardInterrupt`, `SystemExit`, or another process-control
  `BaseException`.

For every ordinary failure require:

- only fixed
  `RuntimeError("RW0WorkerMechanismCapabilityWireOwnerInvariant")`;
- `__cause__ is None` and `__context__ is None`;
- no hostile callable, mapping, manifest, key, value, or foreign exception in:
  - traceback frames and locals;
  - partially initialized module globals;
  - function defaults, kwdefaults, closures, annotations;
  - exception args/dict;
  - directly reachable GC referents where mechanically meaningful;
- `_wire_profile_mapping_owner` absent after success and failure;
- no retained Wire manifest or owner callable;
- only fixed profile ref/digest retained on success.

Do not overclaim that arbitrary interpreter-global garbage collection can prove
global nonexistence. Judge the owned module/exception reachability boundary.

### B. Capability error invariance

For a fresh exact error:

- verify `reason`, `_reason`, `args`, `__cause__`, `__context__`, `str`, and
  `repr`;
- attempt `object.__setattr__` on every specified name;
- attempt ordinary assignment/deletion and ordinary `__dict__` access;
- verify all observations remain unchanged after each attempt and after
  raise/catch;
- test weak-reference and registry cleanup after collection;
- test that two live errors with different reasons cannot alias registry state;
- test copy/deepcopy/pickle/serialization boundaries as governed;
- test unrelated low-level hidden-state insertion does not affect any supported
  observation or authority decision;
- test no supplied hostile object is retained by the registry.

Inspect whether overriding `args`, `__cause__`, or `__context__` is mechanically
reliable for a `BaseException` subclass across the supported runtime. If the
implementation only masks reads while mutable base state still affects Python
raise semantics or traceback behavior, classify it.

### C. Tuple charge ordering

Independently prove for every tuple branch:

- the member occurrence charge completes before `tuple[index]`;
- a one-unit-short budget does not dereference the unpaid member;
- only one index frame is pending at a time;
- no hidden list/tuple conversion bulk-reads members;
- maximum-valid owner reconstruction is unchanged;
- all exact tariffs remain unchanged;
- aliases and cycles keep their accepted treatment;
- the test oracle does not derive ordering solely from source-line text.

Use a read-only tracing/monkeypatch probe or another mechanically equivalent
runtime observation. Do not alter production source.

### D. Thirteen-relation matrix

The exact inventory is:

```text
validate_phase_entry_basis
validate_authority_observation
validate_per_fence_basis
validate_external_common_family_claim
validate_subordinate_narrowing
validate_custody_binding
validate_retrieval_event_sequence
validate_host_qualification
validate_terminal_outcome_binding
validate_normal_terminal_branch
validate_active_cancel_reconciled_branch
validate_active_cancel_unresolved_branch
validate_pre_effect_cancel_basis_unusable_branch
```

For each relation independently verify the checked test's four modes.

The audit must confirm:

- the inventory is literal and complete;
- every mode actually reaches the named relation;
- the selected bypass suppresses only the selected reconstruction;
- the class-wide bypass suppresses all intended B1 reconstruction;
- broken controls are killed by the matrix itself, not by unrelated fixture
  invalidity or a later generic error;
- original-object poisoning occurs after reconstruction and before semantic
  reads in a way that would change the outcome if originals were used;
- terminal shape validators are not credited merely because the shared fixture
  is malformed;
- content-free diagnostics are deterministic.

Create external class-wide and selective mutants for all thirteen relations.
Do not credit only source inspection.

### E. Documentation/status causality

Search the complete live owner regions, not isolated phrases.

Require:

- exactly one current `1285` retrieval maximum;
- no current `374` maximum or formula;
- Capability described as the sole current cross-module B1 consumer;
- no contradictory current no-consumer statement;
- B1/Wire/Capability classified as current private semantics;
- remaining mechanics assigned to C/D/E/ES;
- no row makes RW0-B the blocked future owner of those mechanics;
- fixed NWPF representation/classification remains distinct from open physical
  plumbing and runtime reconciliation.

Run the checked stale-text mutants through the same complete authoritative
oracles. Also construct semantically equivalent stale wording rather than only
exact-string substitutions.

IMPLEMENTATION-EVIDENCE REVIEW

Review every recorded attempt.

In particular classify:

1. preliminary red gate:
   - 24 tests;
   - 17 failures;
   - seven over-specific matrix assertions rejected before source edits;
2. corrected causal red:
   - 24 tests;
   - 10 intended source/document failures;
   - 14 passing controls;
3. initial Capability focused failure caused by retained traceback-cycle
   baseline and its deterministic pre-baseline correction;
4. RW0 status stale assertion and its authorized test repair;
5. final focused groups:
   `27`, `26`, `70`, `369`, `86`, `365`;
6. complete-suite attempt 001:
   - wrapper return code 134;
   - no JUnit;
   - reported validation-wrapper metadata probe while verbose pytest rendered
     expected C2B0 counterfactual assertion failures;
7. diagnostics following attempt 001;
8. complete-suite attempt 002:
   - 4,743 passed;
   - final bytes and stable fingerprint;
9. double final provenance;
10. cleanup of 78 transient directories.

Do not treat attempt 001 as candidate failure without evidence. Do not credit
attempt 002 merely because it is green. Determine:

- whether attempt 001 was solely an external-wrapper failure;
- whether it altered repository or candidate bytes;
- whether rerunning attempt 002 departed from the repair prompt's retry policy;
- whether that departure is an evidence/procedure limitation or a material
  candidate/audit blocker;
- whether attempt 002 is bound to the final manifest and node list.

NODE IDENTITY

Run one candidate collection and one clean external `git archive HEAD`
collection under identical isolated conditions.

Require:

```text
candidate:
4743 unique nodes

clean HEAD:
4655 unique nodes

intersection:
4655

candidate-only:
88

HEAD-only:
0

candidate ordered-list SHA-256:
05fea81edde4fde4cf5fcb15a8e2c397eead7410688665b1500c0cb09970a064

HEAD ordered-list SHA-256:
f36822a60056ec3d110956de561202b737662c9d22cd0dd82c4cdad6c7cef69f
```

Every HEAD node must retain order.

Relative to the 4,719-node opening repair target:

```text
24 additions
0 removals
0 renames
opening order preserved
```

Derive the exact five files containing additions from the implementation
evidence and live collection. Every added node must belong to the permitted
repair-test set:

```text
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_worker_execution_semantic_values.py
```

At least one of those six may contain no addition. Do not guess which one.

No existing node may be removed, renamed, skipped, xfailed, reparameterized,
collapsed, or reordered.

INDEPENDENT VALIDATION

Only after source, documentation, external probes, and authority inspection are
green enough to justify execution, run serially under the new audit root.

For every child use:

```text
umask 022 before launch
child numerical umask must be 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Verify every target exists before running it.

Run:

1. selected repaired causal nodes;
2. Capability local:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_boundaries.py
   ```
3. B1:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```
4. C2A:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   ```
5. RW0 status:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   ```
6. integrated owner compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
7. static/public:
   ```text
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   ```

Every credited run must have:

- return code 0;
- zero failures/errors/skips/xfails/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate or unmapped cases;
- matching caller/child umask;
- unchanged candidate fingerprint.

If all inspection and focused validation remain green, run the complete suite
exactly once independently:

```text
4743 collected
4743 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

If a deterministic material blocker is found first, the full suite may be
withheld. State that explicitly. Never repair candidate bytes.

PUBLIC, IMPORT, PRIVACY, AND AUTHORITY BOUNDARY

Require:

- no new reverse imports;
- no package-root export;
- no new production caller;
- no dependency, SQL, migration, schema, catalog, `StateStore`, or
  `WriterSession` change;
- no filesystem, process, network, provider, Bridge, ES call, Git, publication,
  or runtime effect;
- no retained hostile material in errors, loader state, snapshots, or module
  globals;
- Wire source remains byte-identical;
- B1 and lineage implementation remain byte-identical to the opening repair
  target;
- Capability remains private pure supplied-fact semantics;
- source refs and digests remain unauthenticated evidence;
- no permission, acceptance, durable truth, or runtime authority is created;
- C/D/E and ES seams remain later-owned.

CLOSEOUT

After removing only audit-created transient artifacts:

1. rerun the exact recipe twice;
2. require exact equality to the opening final target;
3. require the same manifest hash, complete-output hash, textual-diff hash,
   file count, per-path hashes, and topology;
4. verify prior evidence roots unchanged;
5. verify no operation, lock, staged/unmerged path, cache, bytecode, database,
   journal, archive, build, recorder, or generated-manifest residue;
6. retain all audit evidence beneath the new mode-0700 root;
7. make retained files regular, operator-owned, and mode 0400;
8. create a self-excluding evidence index.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low candidate defect remains.
- `BLOCK` for any repairable implementation, documentation, test, privacy,
  work-ordering, validation, or procedure defect.
- `REJECT` only for a fundamental accepted-architecture contradiction that
  cannot be repaired within this tranche.
- `AUDIT_PROVENANCE_MISMATCH` only for target/evidence identity failure before
  correctness judgment.

If `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_INTEGRATED_OWNER_REPAIR_AUDIT_FINDINGS_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or open a PR.

FINAL REPORT

Include:

1. opening and closing identity;
2. exact provenance and eleven-entry repair delta;
3. prior evidence inventories and limitations;
4. four perspective reports and disagreements;
5. severity-ranked finding ledger;
6. Wire-owner failure-path reachability result;
7. error-reflection and weak-registry result;
8. tuple charge-order result;
9. thirteen-relation matrix and external-mutant result;
10. B1/RW0 documentation result;
11. implementation-attempt evidence assessment;
12. node comparison;
13. independent focused/full validation;
14. public/import/privacy/authority assessment;
15. closing guards;
16. separate provenance, validation, and implementation-confidence statements.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
```
