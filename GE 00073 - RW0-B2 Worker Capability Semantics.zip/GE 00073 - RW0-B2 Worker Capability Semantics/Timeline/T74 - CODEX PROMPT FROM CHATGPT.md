PROMPT_ID

RW0_B2_CAPABILITY_INTEGRATED_OWNER_REPAIR_AUDIT_FINDINGS_REPAIR_V1

TITLE

Coordinator RW0-B2-Capability — bounded repair of the integrated-owner
re-audit findings, causal-evidence closure, validation, and exact provenance

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing Capability implementation
conversation.

Do not create subagents. You are the sole repository writer.

This is not reconnaissance, independent audit, staging, commit, push, PR,
merge, release, deployment, runtime proof, provider integration, or
supporting-repository work.

Repository mutation is authorized only for the exact 11 already-dirty paths
listed below. Do not make a thirty-first path dirty.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Repair all seven findings from the fresh independent audit of the integrated
C2A/lineage/B1/Capability candidate, without changing the accepted schemas,
canonical identities, authority split, protected-owner budgets, public
surfaces, Wire implementation, or later-owner boundaries.

The repair must:

1. eliminate hostile Wire-owner material from the Capability import-failure
   traceback and partially initialized module;
2. make Capability error `reason`, `args`, `__cause__`, and `__context__`
   invariant under direct `object.__setattr__` mutation;
3. remove the obsolete B1 retrieval-budget paragraph and make `1285` the only
   current retrieval maximum;
4. document Capability as B1's sole current cross-module production consumer
   while retaining C/D/E as future consumers;
5. remove RW0-B from the blocked-future tranche table and assign remaining
   mechanics to their actual C/D/E owners;
6. charge a C2A tuple member occurrence before indexing or scheduling that
   member;
7. add a literal, causal thirteen-relation B1 reconstruction-dependency matrix.

No other implementation change is authorized.

OPENING IDENTITY

Before editing require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644
```

Require no Git operation, lock, mode drift, repository cache, bytecode,
database, journal, archive, build output, recorder residue, or
`git diff --check` failure.

Do not switch, reset, clean, stash, rebase, merge, fetch, or create another
branch. Stop on mismatch.

OPENING PROVENANCE TARGET

Require exact reproduction before mutation:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe size:
3945 bytes

recipe SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

canonical manifest size:
6428 bytes

canonical manifest SHA-256:
177dab5f0c89f0bf99273c2fe9b3f8123f4df34c9dc29306acafb0308eaeb900

tracked textual-diff SHA-256:
586b2634b73fa4cf6e1b56d5afdcc2574f01fc5d49071d5b5199bc903e58631a

complete recipe output size:
6661 bytes

complete recipe output SHA-256:
20522a0b494d6e3511abe94b33dcee9a4f3a4c4a22768fa20bc369a6354f3042

file count:
30
```

Exact canonical manifest:

```json
{"branch":"codex/rw0-b2-capability-semantics-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/authority-boundaries.md","sha256":"1a8ceceaa4c4110f24a4a5e6caa2182c40f1d93b3c94e386c704aaafed6dcb07","size":32953},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/autonomous-software-development-operating-model.md","sha256":"3399cdae5f9e4e6772cd4d6343906d920018cb759adf89177a515ba351378b64","size":34951},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/c2a-first-slice-semantic-protocol-contract.md","sha256":"49238bb9673f0334359c29c7c5add8e35bd617c9e25b7bc372e2445324c81150","size":102469},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/c2a1-pure-semantic-values.md","sha256":"ed7c7a7fad70405268354b348988013631a8c91759a67c24f05d8fb933d5c811","size":17052},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/durable-state-model.md","sha256":"b408350111e76de2eed85245264ced5e01dbd5972b2751c610af1df0e038dc18","size":38138},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-b1-pure-phase-values.md","sha256":"e0004a0e1827f13d08514d33a30d0c889c7191bc36c43d2446e91462b81525d3","size":28783},{"file_type":"regular","kind":"untracked","mode":"0644","path":".docs/rw0-b2-capability.md","sha256":"f57730f15f868dc3360258f41942ec930821b90414f5b1c034792e2f5a86e8df","size":14789},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-b2-wire-protocol.md","sha256":"9f74f07a12c5be7b6425cf6f3ca57b502c0b66a0b3838e3c791d1ae21c746258","size":16802},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-remote-worker-contact-phase-entry.md","sha256":"69b06fea64e2943d0e204686094145df4b8483f15774fb98221df9b71a68d495","size":50948},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/worker-execution-boundary.md","sha256":"77ef23371e4e41df315ae86ce6f173e68a9dcc98e5812a056225b10807f2e14f","size":29202},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py","sha256":"7882ca37e70fba0aa7673d6066e92498bc42d9a3dc8f9a7b4f0256970aeffec4","size":57863},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py","sha256":"4be365d3a494088d5353592f6f689682d59217ac211072f6b27edc874dd2df36","size":100783},{"file_type":"regular","kind":"untracked","mode":"0644","path":"src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py","sha256":"01e66fc7fc5c36f5cf35f1742e77d680a4bef6b88d071145683874cfc5902fda","size":35535},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"src/ge_nwp_coordinator/_worker_execution_semantic_values.py","sha256":"afeac74b711967d95d2fe722054f224f96e318e6657b24b1c98e466cf481c17c","size":171018},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_architecture_contracts.py","sha256":"2a7ae85baf6ffb84cfffef4d0585884f6908f1c793185a3ac26525b1b3b55457","size":99858},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_c2a_nonimplementation.py","sha256":"b0930f649de0c8456d11d8392964403a5c9f275a82bf9c4c544d68e1d2b3b5d9","size":27234},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_runtime_non_authority.py","sha256":"9636dd003e358d178e6d6316b16dbff7ece944ae64f7bf0a3f3080b6be297755","size":41310},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b1_boundaries.py","sha256":"f18a269c14938c1c81e56e6b85dfc046acb77f3b73ecdd13098c638f9c6643fa","size":8092},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b1_phase_values.py","sha256":"69235075cdfadb5e467ea02a8a30e7484d6c04c8f065c2b1e03004e57a9eb166","size":30030},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b1_relations.py","sha256":"8fe93b0e4d360d66a4f896255c92bc334f97377f6f37c940955c13d68cdc33aa","size":90186},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_boundaries.py","sha256":"e0424ca62d67b4573d226fcf8fda4c2fca9bdd34f8d3ae36331d3691c74a38a7","size":15501},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_relations.py","sha256":"7522e11f5c5f932462af2cf78f1f86accd703199dd3a2b2232ed82b74cf8c2a4","size":26877},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_values.py","sha256":"6ddcd2c1ea61fea95bdffd7bea653041847fb54d4c9a199d408e0a428e90b95c","size":24318},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_vectors.py","sha256":"4aa4432b3e042e72f4a0d131a696a842f1a2ac1e3473f8bc04ad8fb90219f7f3","size":16104},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b2_wire_boundaries.py","sha256":"ec77607ee411c46820e3dbac3fc67fbd1bcf071bcea6888f3286bf58fdd89f78","size":28690},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_remote_contact_phase_entry_contract.py","sha256":"b58de126ce8c04b4335b4ac085069b5b3955983e4c5771f30513dbdae34b71f2","size":109393},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_section41_pre_execution_plan_disposition_contracts.py","sha256":"75b7b5e5051ecaab713ee5ec9a91d19d152e0d7e80be06b74548d3b72a9822ba","size":20327},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_software_development_progression_boundary.py","sha256":"1d3ecc4e509933987e898c6532dd0980cbd737a595b3cb2682b93becf30fa4de","size":42833},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_worker_execution_semantic_boundaries.py","sha256":"0279bb43c83e5074a2be549c0453c15c942da77145b4a7cbc875826d8f3259c3","size":12313},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_worker_execution_semantic_values.py","sha256":"062fbd9910716817f154aa7ea54698e78f662b2f142cffaca5f3a47b607ad527","size":48983}],"head":"deec37bf08fb903d8846aa2c3232aec52fa9866e","recipe_id":"governed-execution.audit-patch-manifest.v1","textual_diff_sha256":"586b2634b73fa4cf6e1b56d5afdcc2574f01fc5d49071d5b5199bc903e58631a","upstream":"origin/trunk_dev"}
```

Exact recipe source, base64:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

Create one new external operator-owned, non-symlink, mode-0700 repair evidence
root under `/private/tmp`. Decode the recipe only there, require exact size and
hash, and retain it mode 0400.

Run the exact recipe twice before editing, redirecting only the historical
external output sink through a wrapper. Require exact target equality.

Record the complete opening pytest node list once:

```text
opening count:
4719

ordered-list SHA-256:
24f6fe99b8ef728859327884da26f17f6dc9f8ea834aaf2b26a5914122399be6
```

AUDIT EVIDENCE

Fresh independent audit root:

```text
/private/tmp/ge-coordinator-rw0-b2-fresh-audit.DbthN0
```

The audit verdict was `BLOCK`.

The complete finding ledger is:

```text
RW0B2-AUD-001  Medium  Wire-loader traceback retention
RW0B2-AUD-002  Medium  error reflection changes semantic observations
RW0B2-AUD-003  Medium  stale B1 retrieval limit 374 versus 1285
RW0B2-AUD-004  Medium  stale no-production-consumer statement
RW0B2-AUD-005  Medium  RW0-B current/blocked tranche contradiction
RW0B2-AUD-006  Low     tuple member indexed before occurrence charge
RW0B2-AUD-007  Medium  thirteen-relation causal coverage gap
```

Do not modify the audit evidence.

ACCEPTED ARCHITECTURE — DO NOT REOPEN

Preserve exactly:

- the three Capability value classes, fields, schema IDs, digest domains,
  canonical bytes, fourteen dimensions, and qualification precedence;
- the fixed Wire profile ref/digest;
- declaration, supplied observation, and Coordinator qualification separation;
- structural source non-collapse without source authentication;
- the hardened C2A/lineage/B1 reconstruction helpers and every accepted tariff;
- all eight B1 value budgets and every B1 relation maximum;
- the private B1 host snapshot seam;
- `863 + 249 = 1112`;
- B1, Wire, and Capability as current private pure semantic contracts;
- RW0-C durable-state ownership;
- RW0-D physical transport/process/provider/credential ownership;
- RW0-E separately authorized live proof;
- ES route admission/runtime authority;
- no package export, public caller, dependency, migration, SQL, schema,
  `StateStore`, or `WriterSession` widening;
- byte-identical Wire production source.

TEST-FIRST GATE

Before source or documentation repair:

1. modify only the six authorized test files needed to encode the findings;
2. retain a post-test-edit candidate fingerprint;
3. run one selected causal gate that includes:
   - isolated Capability import with a hostile owner mapping and complete
     traceback/global/closure reachability inspection;
   - direct `object.__setattr__` attempts against `_reason`, `args`,
     `__cause__`, and `__context__`;
   - C2A tuple scheduling/charge-order instrumentation;
   - stale B1 `374` and no-consumer documentation oracles;
   - stale RW0-B blocked-tranche table oracle;
   - the thirteen-relation reconstruction inventory and controls;
4. require the source/document defects to fail for their intended reasons;
5. relation coverage controls that already describe correct source behavior may
   pass;
6. reject fixture, syntax, collection, path, baseline, or unrelated import
   failures as causal evidence.

Retain exact argv, environment, umask, return code, stdout/stderr, JUnit, node
IDs, and before/after fingerprints.

REPAIR 1 — WIRE OWNER FAILURE BOUNDARY

Modify only:

```text
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
tests/test_rw0_b2_capability_boundaries.py
```

Use a two-stage no-hostile-reference raising design.

Required structure in substance:

```python
def _capture_wire_owner_pair(owner_call):
    # Never raises an ordinary owner failure.
    # Returns only a finite status and optional safe ref/digest strings.
    owner_mapping = None
    manifest = None
    try:
        ...
    except Exception:
        status = "invalid"
        profile_ref = None
        profile_digest = None
    finally:
        owner_mapping = None
        manifest = None
        owner_call = None
    return status, profile_ref, profile_digest


def _raise_wire_owner_invariant():
    raise RuntimeError(
        "RW0WorkerMechanismCapabilityWireOwnerInvariant"
    ) from None
```

At module initialization:

1. call `_capture_wire_owner_pair(_wire_profile_mapping_owner)` exactly once;
2. delete `_wire_profile_mapping_owner` in a `finally` path on success and
   failure, before any invariant is raised;
3. retain only the two safe strings on success;
4. invoke `_raise_wire_owner_invariant()` with no hostile argument on failure;
5. do not raise from a frame containing the owner callable, returned mapping,
   manifest, foreign exception, hostile key, or hostile value;
6. never catch process-control `BaseException` subclasses.

The failure test must traverse:

- the complete traceback chain and every traceback frame local;
- exception cause/context;
- the partially initialized module's globals if present;
- helper closures and function defaults;
- GC-reachable objects from the public invariant where practical.

No hostile callable, mapping, manifest, key, value, or foreign exception may be
reachable. The fixed invariant must have null cause/context and content-free
text.

Successful import must still retain no owner callable or manifest.

REPAIR 2 — ERROR OBSERVATION INVARIANCE

Modify only:

```text
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
.docs/rw0-b2-capability.md
tests/test_rw0_b2_capability_values.py
```

Make these observations invariant under direct `object.__setattr__` attempts:

```text
reason
_reason
args
__cause__
__context__
```

Use this frozen design unless repository mechanics prove it impossible:

1. remove mutable per-instance `_reason` storage;
2. make the error weak-referenceable;
3. retain the finite reason in one private module-level
   `weakref.WeakKeyDictionary` keyed by exact error objects;
4. expose read-only data descriptors/properties for `reason` and `_reason`;
5. expose read-only data descriptors/properties returning:
   - `args == ("RW0WorkerMechanismCapabilityError",)`;
   - `__cause__ is None`;
   - `__context__ is None`;
6. expose ordinary `__dict__` access as `AttributeError`;
7. reject ordinary assignment/deletion;
8. keep `str` and `repr` constant;
9. keep pickling/serialization disabled;
10. retain no supplied payload in the registry.

`object.__setattr__` against the five specified names must raise
`AttributeError`, and all observations must remain exact afterward and after
raising/catching the error.

Deliberate insertion of unrelated hidden attributes through lower-level
reflection remains outside the supported semantic API, but must not influence
any public observation, equality/identity behavior, serialization, authority,
or payload retention.

Update the document to state this exact supported boundary. Do not claim
absolute resistance to arbitrary interpreter memory manipulation.

REPAIR 3 — B1 OWNER DOCUMENT

Modify only:

```text
.docs/rw0-b1-pure-phase-values.md
tests/test_rw0_b1_boundaries.py
```

The document must contain one current retrieval relation maximum only:

```text
validate_retrieval_event_sequence = 1285
```

Remove or explicitly historical-scope every obsolete `374` limit and formula.
No current text may present `374` as enforceable.

The current consumer statement must say:

- Capability is the sole current cross-module production consumer of the
  private B1 host snapshot seam;
- no other production module consumes B1;
- RW0-C/D/E remain future consumers/owners according to their separate roles;
- Capability consumption creates no source authentication, permission,
  acceptance, durable truth, or runtime effect.

Add semantic document tests that reject both stale contradictions. Avoid a
single raw phrase check that can be defeated by duplication or relocation.

REPAIR 4 — RW0 TRANCHE STATUS

Modify only:

```text
.docs/rw0-remote-worker-contact-phase-entry.md
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Do not invent a future B subtranche.

The status/tranche/open-decision material must state:

```text
Current implemented private semantics:
RW0-B1
RW0-B2-Wire
RW0-B2-Capability
```

Remaining unresolved mechanics belong to:

```text
RW0-C:
durable ingest, evidence membership/completeness, recovery, terminal facts,
acceptance latch

RW0-D:
physical custody/retrieval, transport and stream plumbing, supervisor/worker,
process targeting, cancellation delivery, deadlines, concrete CLI/App Server,
credentials, private captures, capsule/process proof

RW0-E:
separately authorized live-host/provider proof

Execution Substrate:
ES-route admission, runtime identity, lifecycle, cancellation correlation,
retained results
```

The deferred-decision table must not identify RW0-B as the earliest blocked
tranche for those mechanics.

Preserve the distinction between fixed NWPF representation/classification and
open physical/runtime mechanics.

Add complete owner-region tests and stale-table mutants.

REPAIR 5 — C2A TUPLE CHARGE ORDER

Modify only:

```text
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_values.py
```

In the private exact-value reconstruction traversal:

- never dereference `tuple[index]` while initially scheduling all members;
- schedule only a tuple-index frame containing the tuple and integer index;
- when that frame is processed:
  1. charge the member occurrence;
  2. only after a successful charge, evaluate `tuple[index]`;
  3. schedule the next index and child visit;
- alternatively reserve all member occurrences before any member dereference;
- preserve every accepted class, tariff, valid byte/digest, alias rule, and
  cycle rule.

Add a runtime-causal ordering test, not only source text.

The test must independently prove:

- a one-short budget performs zero dereferences for the unpaid occurrence;
- every successful tuple dereference has a preceding corresponding charge;
- pending work does not bulk-enqueue all members before payment;
- maximum-valid reconstruction remains accepted;
- all existing tariffs remain unchanged.

A test-local trace/opcode observer or another mechanically equivalent runtime
observer is acceptable. Do not add a public or production test hook.

REPAIR 6 — THIRTEEN-RELATION CAUSAL MATRIX

Modify only:

```text
tests/test_rw0_b1_relations.py
```

Create one literal inventory containing exactly these thirteen public relation
entry points:

```text
validate_phase_entry_basis
validate_authority_observation
validate_per_fence_basis
validate_external_common_family_claim
validate_subordinate_narrowing
validate_custody_binding
validate_retrieval_event_sequence
validate_host_qualification
validate_terminal_outcome_binding
validate_normal_terminal_branch
validate_active_cancel_reconciled_branch
validate_active_cancel_unresolved_branch
validate_pre_effect_cancel_basis_unusable_branch
```

For every relation provide a fresh, complete harness and prove all four modes:

1. normal correctly resealed invalid input is rejected;
2. a selective bypass of the chosen B1 reconstruction is behaviorally visible
   and killed by the test oracle;
3. a class-wide reconstruction bypass is behaviorally visible and killed
   before a later generic error can mask it;
4. original-object poisoning after reconstruction does not affect the relation,
   proving semantic reads use reconstructed locals only.

Requirements:

- the inventory is literal and independently compared with the production
  public relation inventory;
- every relation is reached in every mode;
- each mutant changes one reconstruction predicate at a time;
- each expected broken-control outcome is explicit and content-free;
- a mutant that fails only because of unrelated malformed fixtures receives no
  causal credit;
- do not alter B1 production source unless a new deterministic source defect is
  discovered; stop if that occurs.

EXACT 11-PATH REPAIR ALLOWLIST

Only these current candidate paths may change from the opening manifest:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-capability.md
.docs/rw0-remote-worker-contact-phase-entry.md
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_worker_execution_semantic_values.py
```

The other 19 opening-candidate paths must remain byte-identical.

Final topology remains exactly:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
all regular 0644
```

No path may become newly dirty or cease being dirty. Stop if a twelfth repair
path or a thirty-first dirty path is needed.

EXPLICITLY PROTECTED

Everything outside the 11 repair paths is protected, including:

```text
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml
all SQL/migrations/schemas/catalog behavior
StateStore
WriterSession
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_vectors.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_worker_execution_semantic_vectors.py
tests/test_worker_execution_semantic_relations.py
tests/test_c2a_relations.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

VALIDATION ENVIRONMENT

Use one new external operator-owned, non-symlink, mode-0700 repair root.

For every child:

```text
umask 022 before launch
child numerical umask must be 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Retain exact argv, environment, timing, return code, stdout/stderr, JUnit,
structured counts, and before/after repository fingerprints.

FINAL VALIDATION ORDER

After final bytes are frozen:

1. selected causal gate;
2. Capability local:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_boundaries.py
   ```
3. B1 relation and owner docs:
   ```text
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```
4. C2A owner regression:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   ```
5. RW0 status:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   ```
6. integrated owner compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
7. collect the final complete node list exactly once;
8. require all 4,719 opening nodes in identical relative order;
9. permit additions only in:
   ```text
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_worker_execution_semantic_values.py
   ```
10. `git diff --check`;
11. exact path/mode/protected/import/public/residue/operation/lock guards;
12. complete repository suite exactly once.

Every credited green run requires:

- return code 0;
- zero failures/errors/skips/xfails/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate or unmapped cases;
- matching caller/child umask;
- unchanged candidate fingerprint.

FULL-SUITE POLICY

If complete-suite attempt 001 fails:

- preserve all evidence;
- repair only a deterministic patch-caused defect inside the 11 paths;
- rerun affected focused groups;
- run complete-suite attempt 002 exactly once.

Stop without further mutation if:

- a failure is outside scope;
- a twelfth path is required;
- a protected byte must change;
- a third full-suite attempt would be required.

PROVENANCE CLOSEOUT

After validation and cleanup:

1. require exact topology `30/24/6/0/0`;
2. prove exactly the 11 authorized entries changed from the opening manifest;
3. prove the other 19 opening entries are byte-identical;
4. prove every path outside the 30-path candidate equals HEAD;
5. run the exact recipe twice;
6. require byte-identical final manifests and complete outputs;
7. retain the full new canonical manifest, aggregate identities, node lists and
   delta, red/green records, full-suite evidence, and final guards;
8. remove only repair-created transient artifacts.

Do not stage, commit, push, create a PR, or perform an independent audit.

STOP CONDITIONS

Stop without further mutation if:

- opening identity or provenance differs;
- any accepted schema, field, enum, digest domain, canonical byte, budget,
  relation meaning, fixed Wire pair, or authority boundary must change;
- B1, lineage, or Wire production source must change;
- a reverse import, package export, public caller, dependency, migration, SQL,
  schema, durable-state, process, provider, or runtime change is required;
- a twelfth repair path or thirty-first dirty path is required;
- any protected path changes;
- relation-matrix closure exposes a deterministic B1 source defect;
- node ownership, validation, or provenance is unstable.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_INTEGRATED_OWNER_REPAIR_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only when all seven findings are closed, validation is green, the complete
suite passes, exact provenance is stable, and every stop condition is false.

FINAL REPORT

Include:

1. opening and final identity;
2. opening target reproduction;
3. test-first red evidence;
4. exact 11-path delta and 19-path byte-identical ledger;
5. Wire loader traceback/global/closure repair;
6. error-reflection implementation and direct mutants;
7. B1 documentation corrections;
8. RW0 tranche/open-decision corrections;
9. C2A tuple charge-order implementation and causal proof;
10. literal thirteen-relation matrix and all four modes;
11. node identity and additions;
12. every validation attempt;
13. full-suite result and attempt number;
14. final provenance and complete canonical manifest;
15. protected/public/authority non-widening;
16. remaining C/D/E/ES seams;
17. separate provenance, validation, and implementation confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
```
