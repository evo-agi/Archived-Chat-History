PROMPT_ID

RW0_B2_CAPABILITY_G9_FINDINGS_REPAIR_V1

TITLE

Coordinator RW0-B2-Capability — repair the closed-call proof, make mutant
expectations independent, and reseal an accurate final validation envelope

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing Capability implementation
conversation.

Do not create subagents. The parent is the sole repository writer.

This is a one-repository-file test-boundary repair plus fresh external validation
evidence. It is not production implementation, documentation editing, registry
redesign, staging, commit, push, pull request, merge, release, deployment,
provider/runtime work, database work, or supporting-repository work.

Only the exact repository path below may change.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Repair all three findings from the G9 fresh independent audit:

```text
G9-CC-001 — High
The claimed closed reachable-call proof is bypassable by helper rebinding,
decorator/closure replacement, builtin shadowing, and additional calls to an
already allowlisted method with a Git-sensitive argument. One executable
helper-rebinding mutant passed both the guard and target while launching a
subprocess.

G9-EV-002 — Medium
The G8 module-global mutant evidence is circular because expected diagnostics
were produced by the same checker whose output was then compared as actual.

G9-RP-003 — Low
The G8 final report overstates fingerprint coverage for early attempts.
```

Preserve the G9-accepted results:

- production Capability semantics remain private and pure;
- no production or documentation authority defect exists;
- the 43-row projection and P01–P13 protected-content checks are sound;
- the restore harness, seven tooling cases, eight stable-contract mutants, and
  A/B/C state behavior are sound;
- the exact current candidate tree is
  `0fcf6680ded68d66f62b75b5dc842d69b343a334`;
- G8 remains immutable historical validation evidence;
- G9 remains immutable independent-audit evidence.

Do not attempt to edit or reseal G8 or G9.

OPENING REPOSITORY IDENTITY

Before any repository edit require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644

candidate tree:
0fcf6680ded68d66f62b75b5dc842d69b343a334
```

Require:

- `git diff --check` clean;
- logical cached diff empty;
- no Git operation or lock;
- source logical index unstaged;
- no candidate symlink or special file;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, or recorder residue;
- no thirty-first changed path.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

OPENING CANDIDATE TARGET

G8 authoritative evidence root:

```text
/private/tmp/g8.3cee3f
```

G8 final report:

```text
/private/tmp/g8.3cee3f/final_report.md

size:
99764 bytes

SHA-256:
e54ecbef3321b810e58c248221d6542325b878c67ddd35483993c61e9781d118
```

G8 attempt manifest:

```text
/private/tmp/g8.3cee3f/attempt_manifest.jsonl

rows:
212

size:
67790 bytes

SHA-256:
83e79b1ca3ca29a9a7dec45bededcc642057f8dc5bf940bfc826c392f6ae0c65
```

G8 self-excluding index:

```text
/private/tmp/g8.3cee3f/evidence_index.jsonl

rows excluding itself:
2403

size:
448923 bytes

SHA-256:
f90d50dc17e95e432b6577cad99669777f99bcd2d6af7c42509d2987db8248fc
```

Opening manifest:

```text
size:
6430 bytes

SHA-256:
d6f86248da0c4843e20b91cb443f960596e483e08a8f2cff716bbcea4fb553d8

tracked textual-diff SHA-256:
cc91155aff703e1c54c139820f841d98135f37ee7c87a71d3b00b07a2672e2a6

opening pytest nodes:
5072

opening ordered-node SHA-256:
f0faec3289ed635a741867bb2a655487f4a4a824dcf4cc0921c334beada1bbd3
```

Opening identity of the only authorized repository path:

```text
tests/test_rw0_b2_capability_boundaries.py

kind:
untracked

type:
regular

mode:
0644

size:
76858 bytes

SHA-256:
eb6ca3cd19b4bd723b82002aa93e7b5743ef02b768ac169d96e0011582e61977
```

The other 29 candidate entries must remain exact.

LATEST INDEPENDENT AUDIT

G9 root:

```text
/private/tmp/g9.rW9peg
```

G9 self-excluding index:

```text
/private/tmp/g9.rW9peg/evidence_index.jsonl

rows excluding itself:
196

size:
35153 bytes

SHA-256:
a788c22943c8bcf0601ecf4a944182242843ad1f1849e24996e9c818f12ac244
```

Read and preserve the complete inline/file evidence for:

```text
G9-CC-001
G9-EV-002
G9-RP-003
```

Required G9 adverse-mutant identities:

```text
helper_rebind_alias:
68bd5ddc15603fd1c4264e39f36a0cdea11959bb05f5146409d484a47357cd66

decorator_closure_alias:
fbf7ee99bd57fe66149abb0419b2442808e5657234ca6a113458a1bd71909bf7

builtin_shadow_alias:
d7cca5c4fe94b3a17adee55929dc6a12232c2584d5e455b43fe23e077d7d5905

allowlisted_git_index_read:
25f0c1ed8509812da6579e4f83842808a1b677f914dff747454851e14efd4917

executable helper-rebinding source:
384528d45f5a1b80d3902ce2695ac1d370e51ea31fe9b6832bb1f0f37baf4bc7

retained executable-survivor patch:
242a0826bbc3bd8a4243376f567fff8e2e5eacd835ca17e2a0faa98228e93fff
```

The executable survivor must be reproduced test-first and killed after repair.

EXACT REPOSITORY ALLOWLIST

Only this already-dirty path may change:

```text
tests/test_rw0_b2_capability_boundaries.py
```

No document or production source may change.

Final topology must remain:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
all regular mode 0644
```

Stop if a second repository path, documentation change, production-source
change, or thirty-first dirty path is required.

NEW EVIDENCE ROOT

Create one new short neutral root:

```text
/private/tmp/g10.XXXXXX
```

Requirements:

- operator-owned;
- non-symlink;
- mode `0700`;
- all temporary paths beneath this root;
- every pytest-visible path pre-screened with the exact owning path-safety
  grammar;
- retained regular files mode `0400`;
- retained directories mode `0700`;
- no symlink, FIFO, socket, device, or other special entry at closeout;
- self-excluding canonical JSONL index created last.

Preserve G8 and G9 unchanged. Record opening/closing canonical content
projections for both roots.

EXACT RECIPE SOURCE

Locate the retained exact source:

```text
/private/tmp/g5.hiLE2y/exact_recipe_source.py

type:
regular

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Create a verified G10-local mode-0400 copy before invocation. Run the exact
source twice at opening and twice at closeout with only the historical fixed
sink redirected.

BEFORE MUTATION

Record and verify:

1. exact repository identity/topology;
2. exact G8 and G9 indexes;
3. exact opening manifest and path identities;
4. every path outside the candidate equals HEAD;
5. exact recipe source and two opening reproductions;
6. exact 5,072 opening nodes;
7. complete current source and AST of
   `tests/test_rw0_b2_capability_boundaries.py`;
8. complete existing reachable-call checker, runtime-global checker, 43-row
   projection, and mutation cases;
9. exact G9 adverse-mutant sources and outcomes.

Retain complete opening source, AST, normalized binding/call ledgers, and
fingerprint.

TEST-FIRST RED GATE

Before repairing the checker, add or stage test-owned causal cases in the
authorized file and run a selected red gate that reproduces all material G9
survivors.

The red gate must include:

```text
helper rebind after an approved FunctionDef
helper rebound through an alias
decorated protected helper whose runtime object differs from its FunctionDef
decorator closing over an executable callable
module-level shadow of each used builtin:
  len
  set
  sorted
  tuple
  zip
later assignment that shadows an approved module alias
additional allowlisted Path/stat/hash method call with an unapproved target
exact allowlisted method repeated with changed argument provenance
duplicate protected helper definition
protected helper rebound to lambda
imported executable callable assigned after definition
callable placed in default argument
callable placed in closure
```

The executable helper-rebinding case must:

1. run in a disposable external module/repository;
2. create a sentinel only if the forbidden subprocess executes;
3. show that the opening guard and target pass;
4. show that the sentinel is created;
5. retain exact source, patch, command, stdout/stderr, result, and sentinel
   identity.

Only these intended guard failures receive causal credit. Syntax, import,
fixture, path-safety, unrelated test, or tooling failures do not.

ENGINEERING DECISION

Do not extend the old checker with another order-insensitive denylist.

Implement a closed, source-order-aware, runtime-sealed call contract.

REPAIR A — SOURCE-ORDER MODULE BINDING MODEL

Parse the complete module in source order and construct a literal binding-event
ledger for every name relevant to the protected target/helper graph.

At minimum include:

```text
test_exact_twenty_path_ceiling_modes_and_protected_controls
_stable_capability_boundary_projection
_protected_content_row

len
set
sorted
tuple
zip

hashlib
stat
Path
ROOT
EXPECTED_PATHS
EXPECTED_PATHS_SHA256
PROTECTED_PATHS
PROTECTED_PATH_IDENTITIES
PROTECTED_ROW_IDS
EXPECTED_BOUNDARY_ROWS
```

For each binding event retain:

```text
name
statement ordinal
source location
event kind:
  import
  import-from
  FunctionDef
  AsyncFunctionDef
  ClassDef
  Assign
  AnnAssign
  AugAssign
  NamedExpr
  Delete
  loop target
  with target
  exception target
  comprehension target
binding source/target identity
```

Enforce:

1. every protected function has exactly one undecorated FunctionDef;

2. no later or competing binding for a protected function;

3. no assignment/import/delete shadows a required builtin or approved module
   alias;

4. no duplicate protected definition;

5. no star import;

6. no dynamic binding through `globals`, `locals`, `vars`, `setattr`,
   `__dict__`, `exec`, `eval`, `compile`, or dynamic import;

7. final module binding equals the unique accepted event.

The model must be order-sensitive. A later assignment cannot be hidden by an
earlier FunctionDef entry.

REPAIR B — FUNCTION-SCOPE LEXICAL BINDING MODEL

For the target and each reachable helper, process statements and expressions in
source order.

Reject:

```text
local callable aliases
callables assigned through tuple/list unpacking
callable defaults
callable keyword defaults
callable closures/free variables
decorator-generated bindings
lambda/helper substitution
callable values obtained through getattr
unknown local helper calls
dynamic import
module-global executable callable lookup
unresolved Name or Attribute call targets
```

Track every local binding that can affect a call target.

REPAIR C — ORDERED CALLSITE LEDGER

Replace the set-only external inventory as the authority.

Create one literal test-owned ordered callsite ledger.

Each expected callsite must include:

```text
owning function
call ordinal
semantic target
call multiplicity
receiver/provenance class
argument provenance class
allowed subject/path domain
```

The ledger must distinguish:

```text
same semantic method called one extra time
same method called with a different path
same method called against .git/index or other Git metadata
same method called on an unresolved receiver
same method called after helper/runtime rebinding
```

For filesystem reads/stats, require the subject to derive only from the exact
literal 43-row projection subjects and the accepted repository root.

Explicitly reject:

```text
.git
.git/index
Git refs/logs/objects
arbitrary caller-supplied paths
constructed path fragments outside the 43-row subject set
```

Do not rely on a set of method names.

REPAIR D — RUNTIME CALLABLE SEAL

Capture and validate the actual runtime callable objects for the target and
reachable helpers.

Require, for each:

```text
globals()[name] is the captured accepted callable
__module__ exact
__qualname__ exact
__name__ exact
__defaults__ is None
__kwdefaults__ is None or exact empty mapping as appropriate
__closure__ is None
no __wrapped__
no decorator replacement
runtime code corresponds to the accepted normalized AST/function source
```

Use a literal independent normalized-AST or function-source digest per
protected function. Do not compute the expected digest from the current
function under test.

Reject helper/builtin/module rebinding before invoking the target.

The executable helper-rebind mutant must be rejected before its sentinel can be
written.

REPAIR E — INDEPENDENT MODULE-GLOBAL MUTANT EXPECTATIONS

Fix G9-EV-002.

Define one literal, independent case-to-diagnostic mapping for every
module-global mutation case:

```text
ROOT
EXPECTED_PATHS
EXPECTED_PATHS_SHA256
PROTECTED_PATHS
PROTECTED_PATH_IDENTITIES
PROTECTED_ROW_IDS
EXPECTED_BOUNDARY_ROWS
hashlib
stat
```

Requirements:

1. expected diagnostics are literals owned by the test, not generated by
   `_boundary_runtime_global_diagnostics` or the checker under test;

2. exact case inventory/order is literal;

3. actual diagnostics are compared directly with the literal mapping;

4. a test-local generic-checker mutant returning one common nonempty diagnostic
   must fail;

5. wrong-case, swapped-diagnostic, missing-case, duplicate-case, and extra-case
   mutants must fail;

6. new helper/builtin/module-binding cases also use literal independent
   expected diagnostics.

REPAIR F — CAUSAL MUTANT MATRIX

Add independent test-owned cases for:

```text
the four G9 surviving layouts
the executable helper-rebinding layout
later helper assignment
decorator replacement
closure-bearing decorator
builtin shadow for every used builtin
approved module-alias shadow
duplicate helper definition
lambda rebind
extra allowlisted call
same allowed call with forbidden path
call multiplicity drift
argument-provenance drift
runtime callable defaults/closure/wrapped drift
generic module-global diagnostic oracle
```

For every case retain:

```text
case ID
literal mutation class
mutant source bytes
mutant source SHA-256
expected finite diagnostic
actual finite diagnostic
sentinel expected/observed
```

Require unique case IDs, purposes, and source bytes unless a duplicate is
explicitly justified.

REPAIR G — PRESERVE ACCEPTED PROJECTION/CONTENT CONTRACTS

Do not weaken or redesign:

```text
the literal 43-row projection
R01–R30 required candidate-path rows
P01–P13 protected-content rows
the exact P12 survivor kill
the eight stable-contract mutants
A/B/C state independence
the schema-correct restore harness
```

Rerun all accepted controls after the closed-call repair.

EVIDENCE/REPORT REPAIR

Create fresh G10 evidence. Do not alter G8.

## Independent replay expectations

All mutation expectations, including module-global expectations, must be
literal and independent of the checker under test.

## Accurate provenance language

Fix G9-RP-003 in the new report.

The final report must classify fingerprints per attempt exactly:

```text
bootstrap identity
light source fingerprint
missing/not-applicable fingerprint
authoritative normalized fingerprint
external-repository fingerprint
```

Do not claim every action had authoritative source pre/post fingerprints.

For each attempt, report the actual fingerprint class and presence.

If the recorder stores no authoritative fingerprint for a pre-validation
tooling attempt, say so explicitly.

## Complete inline report

Print the complete operative report inline in chat. File paths are
supplementary only.

UNCONDITIONAL ATTEMPT RECORDER

Record every formal implementation/validation action under G10:

```text
opening gates
test-first red
development attempts
each causal mutant
each focused group
A/B/C setup and runs
live/clean collection
live/clean full suites
guards
cleanup
final provenance
report/index sealing
```

Each envelope must state:

```text
sequence
label
purpose
expected and actual outcome
credit classification
argv/action
environment
Python identity
timing/PID
return/signal
stdout/stderr
JUnit/counts when applicable
fingerprint class
pre/post fingerprint presence and identity
candidate-mutated result
notes
```

No need to reconstruct or merge G8’s attempt history. G10 is the fresh
authoritative repair/validation envelope.

VALIDATION ENVIRONMENT

For every pytest child:

```text
umask 022
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct short neutral external PYTHONPYCACHEPREFIX
distinct short neutral external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct short neutral external --basetemp
distinct short neutral external --junitxml
serial execution
```

Pre-screen every pytest-visible path with the owning privacy/path checker.

FINAL VALIDATION ORDER

After final repository bytes and causal ledgers are frozen:

1. selected causal:
   - every G9 survivor;
   - executable sentinel case;
   - source-order binding controls;
   - ordered callsite controls;
   - runtime callable seal controls;
   - independent module-global expectation controls;
   - retained protected-content controls;

2. Capability boundaries:

   ```text
   tests/test_rw0_b2_capability_boundaries.py
   ```

3. Capability complete:

   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   ```

4. B1/Wire compatibility:

   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```

5. architecture/status/static:

   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

6. A/B/C state replay:

   ```text
   A live unstaged
   B fully external independent staged repository
   C same external repository after diagnostic commit
   ```

7. live and clean collection exactly once each;

8. opening/final node reconciliation;

9. final guards;

10. live full suite exactly once;

11. clean full suite exactly once;

12. cleanup;

13. final recipe runs twice;

14. final report and self-excluding index.

Do not predeclare final node count. Derive it.

Every credited run requires:

```text
return code 0
zero failures/errors/skips/xfails/warnings
empty stderr
parseable JUnit
zero duplicate/unmapped cases
matching caller/child umask
unchanged authoritative candidate fingerprint
```

A/B/C REQUIREMENTS

Use a fully external independent Git repository/object database for B/C.

Require:

```text
target passes A/B/C
43-row projection A == B == C
B staged tree == C committed tree
source logical index unchanged
source authoritative object graph unchanged
no alternates
no source/external shared object inode
```

Record the new final B/C tree; do not assume the opening tree remains unchanged
because the authorized test file changes.

LIVE AND CLEAN FULL SUITES

Run each exactly once.

No retry is authorized.

If either fails, preserve evidence and stop without further repository edits.

PROVENANCE CLOSEOUT

After validation and cleanup:

1. require topology `30/24/6/0/0`;

2. prove exactly the sole authorized test path changed from the opening G8
   candidate;

3. prove the other 29 candidate entries remain exact;

4. prove every path outside the candidate equals HEAD;

5. run the exact retained recipe twice with a verified G10-local mode-0400
   copy and safe sink redirection;

6. require byte-identical final manifests and complete outputs;

7. retain:
   - exact recipe source;
   - final manifests/outputs;
   - exact one-path delta;
   - opening/final node lists;
   - source-order binding ledger;
   - ordered callsite ledger;
   - runtime callable seal ledger;
   - every causal mutant;
   - independent module-global diagnostic mapping and mutants;
   - retained 43-row/P01–P13/stable-mutant results;
   - A/B/C records;
   - focused and full-suite records;
   - final guards/cleanup;
   - accurate report;

8. verify G8 and G9 unchanged;

9. create a self-excluding evidence index last and externally verify it.

STOP CONDITIONS

Stop without further repository mutation if:

- opening identity/provenance differs;
- a second repository path is required;
- source-order resolution cannot be made finite;
- exact argument/path provenance cannot be represented finitely;
- legitimate target behavior requires dynamic callable rebinding;
- a production/document/authority defect is discovered;
- A/B/C or suite behavior diverges;
- validation/provenance becomes unstable.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_G9_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only when:

- all four G9 survivor layouts are killed;
- the executable helper-rebind case is rejected before sentinel creation;
- source-order binding, ordered callsite, and runtime callable seals are green;
- module-global expected diagnostics are independent and mutation-sensitive;
- retained projection/content/stable contracts remain green;
- A/B/C is green;
- live and clean complete suites are green;
- exact one-file provenance is stable;
- the final report is accurate and complete inline.

FINAL INLINE REPORT

Use these headings:

```text
# Outcome

# Opening and closing identity

# G9 finding closure

# Exact one-file delta

# Source-order binding model

# Ordered callsite ledger

# Runtime callable seal

# Independent module-global expectations

# Causal mutant results

# Preserved projection and protected-content controls

# A/B/C result

# Node identity

# Focused and complete validation

# Provenance and evidence index

# Public, privacy, and authority boundary

# Confidence
```

Report every formal attempt, including failures and superseded development
attempts, with accurate fingerprint classes.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
