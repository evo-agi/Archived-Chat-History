## Engineering disposition

**Restart the complete validation replay in a new evidence root, but replace the unstable provenance model. Do not modify the candidate or resume G6.**

The diagnostic separated three facts:

1. **G5 did not drift.**  
   `evidence_close_g5` failed because two inventory schemas represented directory sizes differently:

   ```text
   opening directory size: null
   closing directory size: live lstat().st_size
   ```

   All 625 directory mismatches were representation-only. G5’s indexed path set, file types, ownership, modes, regular-file sizes, and regular-file SHA-256 values remained exact.

2. **The candidate did not drift.**  
   The branch, HEAD, tree, 30-path candidate, canonical manifest, worktree diff, cached diff, real logical index, and all 176 protected tracked paths remain correct.

3. **Ambient Git metadata changed after attempt 0182.**  
   App-managed `refs/codex/turn-diffs` changed, and 35 loose-object `mtime`/`ctime` values changed. Object paths and hashes remained equal. These are not authoritative candidate facts, but the previous fingerprint treated them as such.

G6 cannot be resumed because:

- attempt 0183 is incomplete;
- final guards and cleanup did not finish;
- final provenance, report, and index were never created;
- its original source-provenance baseline no longer matches ambient app metadata.

The correct response is a **fresh replay with a stable provenance contract**, not a repository repair.

## Stable provenance model

The replacement replay treats these as authoritative and equality-bound:

```text
branch, HEAD, tree, parents, subject
upstream and divergence
porcelain-v2 status
tracked binary diff
cached binary diff
logical index entries from git ls-files --stage
canonical candidate manifest and per-path identities
outside-candidate equality to HEAD
authoritative refs
objects logically reachable from authoritative refs
operations, locks, and repository residue
```

These remain recorded but are **report-only**:

```text
refs/codex/turn-diffs/**
reflogs
loose-versus-packed object representation
unreachable loose-object path set
object and directory atime/mtime/ctime/birthtime/inode metadata
raw index stat-cache metadata
directory st_size
xattrs
```

Pre-existing evidence roots use one canonical comparison schema at opening and closeout:

```text
relative path
type
owner UID/GID
mode
regular-file size or null
regular-file SHA-256 or null
```

Directory size is always `null`; observation metadata is never mixed into the evidence-content identity.

## Replacement replay handoff

Send this complete replacement prompt to the **same write-enabled Capability implementation conversation**:

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Capability_Final_Repair_Complete_Validation_Replay_V2_Stable_Provenance_Prompt.txt

Size:
24,492 bytes

SHA-256:
30a9374d9591112d979adb3d4cf6054036cd90bdebc9c90da52f7e6921a306aa
```

The replay creates a new neutral root:

```text
/private/tmp/g7.XXXXXX
```

It preserves G5, G6, and the G6 diagnostic unchanged. G6 is classified as failed historical replay evidence rather than repaired or resumed.

## Required replay result

The replacement reruns the complete final sequence against unchanged bytes:

```text
Selected causal:                 16 passed
Capability boundaries:           32 passed
Capability complete:             69 passed
B1/Wire compatibility:          461 passed
Architecture/status/static:     907 passed

Live collection:              5,072 nodes
Clean collection:             5,072 nodes

Live full suite:             5,072 / 5,072
Clean full suite:            5,072 / 5,072

Final B/C tree:
0fcf6680ded68d66f62b75b5dc842d69b343a334
```

Every action from root bootstrap onward receives an unconditional envelope, including each mutation, setup operation, evidence comparison, cleanup action, and provenance run.

The required success token remains:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

Only after that complete G7 closeout should another fresh read-only independent audit begin. The commit gate remains blocked.

### Source

Codex’s G6/G5 mutation diagnostic supplied in this turn.

**Confidence:** High that neither G5 nor the candidate suffered content drift; high that the previous failure came from an inconsistent evidence schema plus overbroad treatment of app-managed Git metadata; high that a fresh replay using normalized authoritative provenance is the correct continuation.
