PROMPT_ID

RW0_B2_CAPABILITY_PARENT_ONLY_IMPLEMENTATION_V1

TITLE

Coordinator RW0-B2-Capability — implement the reconciled private declaration,
independent-observation, and qualification semantics

ENGAGEMENT TYPE

Parent-only workspace-write implementation in the Governed Execution
Coordinator repository.

Do not create subagents. You are the sole repository writer.

This is not reconnaissance, independent audit, commit/publication, merge,
deployment, runtime proof, provider integration, or Capability execution.

Repository mutation is authorized only inside the exact 20-path ceiling below.
Tests and external validation/provenance evidence are authorized as specified.
Do not stage, commit, push, create a PR, merge, tag, release, deploy, contact a
remote/service/provider/host, invoke a worker/model, install dependencies, or
modify another repository.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Implement one private, pure, deterministic, no-I/O RW0-B2-Capability semantic
layer containing:

1. a worker-mechanism capability declaration authored by the candidate worker
   artifact owner;
2. an independently authored supplied capability observation;
3. a Coordinator-owned pure qualification value;
4. one pure qualification relation that:
   - binds the exact accepted RW0-B2-Wire profile;
   - binds the exact worker artifact pair;
   - safely reconstructs all Capability values before semantic use;
   - invokes B1's complete owning `validate_host_qualification(...)` relation
     exactly once;
   - computes the exact closed result/reason precedence below;
   - grants no source authenticity, permission, acceptance, persistence,
     process proof, contact, or runtime authority.

The result is a private semantic prerequisite for later RW0-D/E proof and
future RW0-C durable projection. It is not worker contact or an executable
Codex mechanism.

RECONCILED FREEZE VERDICTS

The preceding read-only engagements returned:

```text
RW0_B2_CAPABILITY_SCHEMA_FREEZE_RECONCILED_READY
RW0_B2_WIRE_PROFILE_BINDING_CONFIRMED
```

Implement that reconciled freeze exactly.

OPENING BASELINE

Before any mutation require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
trunk_dev

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

index/worktree/untracked/unmerged:
clean
```

Require no Git operation, lock, repository cache, bytecode, database, journal,
archive, build output, generated repository manifest, recorder residue, or
mode drift. Do not fetch.

Require the local branch below to be absent:

```text
codex/rw0-b2-capability-semantics-v1
```

Create it once from the exact baseline:

```text
git switch -c codex/rw0-b2-capability-semantics-v1
```

After branch creation, reverify HEAD/tree/upstream/worktree identity and clean
status. Stop on any mismatch. Do not reset or clean an unexpected state.

OPENING EVIDENCE

Create one new operator-owned, non-symlink, mode-0700 implementation evidence
root under `/private/tmp`.

Before editing:

1. record branch, HEAD, tree, parent, subject, upstream, divergence, worktree
   count, status, modes, operations, locks, and residue;
2. collect the complete opening pytest node list exactly once under isolated
   external cache/temp paths;
3. retain the literal ordered node IDs and SHA-256;
4. run the exact provenance recipe twice on the clean feature branch and
   require byte-identical zero-file manifests and complete outputs;
5. retain the exact recipe source mode 0400.

Do not predeclare the final node count. The final comparison must preserve every
opening node in order, with all additions owned only by the four new Capability
test files.

ACCEPTED OWNERSHIP AND NON-CLAIMS

Preserve exactly:

- RW0-B2-Wire precedes Capability and remains unchanged.
- Wire owns NWPF framing, hostile decoding, worker-result grammar,
  source-claim values, and process/result classification.
- B1 owns phase-entry, authority, readiness, effect-bound host qualification,
  and its exact 241-unit relation.
- Capability owns only provider- and mechanism-neutral declaration,
  independent supplied observation, and pure qualification semantics.
- RW0-C owns future durable evidence membership/completeness, recovery,
  terminal facts, and acceptance latch.
- RW0-D/E own concrete CLI/App Server/provider choice, credentials, sessions,
  invocation, process/supervisor behavior, physical observation, numeric
  process/capture limits, and live proof.
- Execution Substrate retains admission and runtime authority on the ES route.
- No digest, declaration, observation, qualification, profile, report, or
  provenance value grants authority, permission, acceptance, contact, or
  durable truth.
- Unequal declaration/observation source refs prove structural non-collapse
  only—not organizational, cryptographic, or source-authenticity independence.
- No provider, account, endpoint, model, session ID, credential, prompt,
  transcript, JSONL, stdout/stderr body, hostname, IP, physical path, PID,
  process handle, environment value, trust material, or bearer may be retained.

EXACT CLASSES, SCHEMAS, AND FIELDS

Implement exactly these classes in:

```text
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
```

The module is private and has:

```python
__all__: tuple[str, ...] = ()
```

### 1. Declaration

Class:

```text
RW0WorkerMechanismCapabilityDeclarationV1
```

Schema ID:

```text
governed-execution.nwp-rw0-worker-mechanism-capability-declaration.v1
```

Digest domain:

```text
governed-execution.nwp-rw0-worker-mechanism-capability-declaration.v1.identity
```

Exact ordered 23 fields:

```text
schema_id
capability_declaration_ref
declaration_source_kind
declaration_source_ref
worker_artifact_ref
worker_artifact_digest
wire_profile_ref
wire_profile_digest
noninteractive_operation
wire_command_input_only
wire_result_output_only
protocol_stdout_only
private_bounded_diagnostic_stderr
external_cancellation_control_supported
external_deadline_control_supported
invocation_bound_logical_context
private_history_non_authority
isolated_credential_use
private_interaction_material
zero_git_effects
restricted_network_access
external_session_non_authority
capability_declaration_digest
```

`declaration_source_kind` is exactly:

```text
worker_artifact_owner
```

Each of the fourteen dimensions is exactly one of:

```text
supported
unsupported
unknown
```

The declaration has no evidence or time field. It is an immutable claim for one
artifact/Wire-profile pair.

### 2. Observation

Class:

```text
RW0WorkerMechanismCapabilityObservationV1
```

Schema ID:

```text
governed-execution.nwp-rw0-worker-mechanism-capability-observation.v1
```

Digest domain:

```text
governed-execution.nwp-rw0-worker-mechanism-capability-observation.v1.identity
```

Exact ordered 30 fields:

```text
schema_id
capability_observation_ref
observation_source_kind
observation_source_ref
observation_source_invocation_ref
evidence_ref
evidence_digest
capability_declaration_ref
capability_declaration_digest
worker_artifact_ref
worker_artifact_digest
wire_profile_ref
wire_profile_digest
noninteractive_operation
wire_command_input_only
wire_result_output_only
protocol_stdout_only
private_bounded_diagnostic_stderr
external_cancellation_control_supported
external_deadline_control_supported
invocation_bound_logical_context
private_history_non_authority
isolated_credential_use
private_interaction_material
zero_git_effects
restricted_network_access
external_session_non_authority
observed_at
expires_at
capability_observation_digest
```

`observation_source_kind` is exactly:

```text
independent_worker_mechanism_observer
```

Each observation dimension is exactly one of:

```text
confirmed
contradicted
unknown
```

Exactly one observation participates in one qualification. Collection,
conflict, completeness, and durable evidence-set semantics remain RW0-C work.

### 3. Qualification

Class:

```text
RW0WorkerMechanismCapabilityQualificationV1
```

Schema ID:

```text
governed-execution.nwp-rw0-worker-mechanism-capability-qualification.v1
```

Digest domain:

```text
governed-execution.nwp-rw0-worker-mechanism-capability-qualification.v1.identity
```

Exact ordered 25 fields:

```text
schema_id
capability_qualification_ref
capability_declaration_ref
capability_declaration_digest
capability_observation_ref
capability_observation_digest
worker_artifact_ref
worker_artifact_digest
wire_profile_ref
wire_profile_digest
phase_basis_ref
phase_basis_digest
authority_observation_ref
authority_observation_digest
readiness_observation_ref
readiness_observation_digest
host_qualification_ref
host_qualification_digest
effect_intent_ref
effect_fence_ref
effect_fence_digest
result
reason
evaluated_at
capability_qualification_digest
```

Qualification result is exactly:

```text
qualified
blocked
unknown
```

Qualification reasons, in exact precedence order:

```text
b1_binding_mismatch
b1_host_qualification_blocked
b1_host_qualification_unknown
declaration_observation_mismatch
self_observation
observation_expired
worker_artifact_mismatch
wire_profile_mismatch
declaration_unsupported
observation_nonconformant
capability_unknown
qualified
```

Constructor-valid result/reason matrix:

```text
qualified:
  qualified only

unknown:
  b1_host_qualification_unknown
  capability_unknown

blocked:
  b1_binding_mismatch
  b1_host_qualification_blocked
  declaration_observation_mismatch
  self_observation
  observation_expired
  worker_artifact_mismatch
  wire_profile_mismatch
  declaration_unsupported
  observation_nonconformant
```

### 4. Error

Class:

```text
RW0WorkerMechanismCapabilityError
```

It has no semantic identity.

EXACT TYPES AND VALUE POSTURE

Every external field value and every stored member is exact built-in `str`.
There are no nullable fields and no collections inside a valid value.

Each value stores one exact ordered tuple of strings in private `_values`.

Required posture:

- final and non-subclassable;
- `__slots__`;
- `__hash__ = None`;
- ordinary construction disabled;
- immutable `__setattr__` and `__delattr__`;
- `copy.copy` and `copy.deepcopy` return the same object;
- pickling disabled;
- content-free `repr` and `str` containing only the class name;
- exact-class structural equality only;
- different exact class returns `False`;
- same-class equality safely reconstructs both operands under the exact `6V`
  budget before comparing reconstructed tuples;
- readable declared field attributes use the same safe `3V` reconstruction
  seam before returning the reconstructed member;
- unknown attributes raise content-free `AttributeError` from `None`.

The ordinary semantic surface is only:

```text
from_mapping
readable declared field attributes
to_mapping
identity_mapping
canonical_identity_bytes
computed_digest
exact-class equality
```

No public method may call another public semantic method.

CANONICAL IDENTITY

For every class:

- final field is the sole self-digest;
- `identity_mapping()` excludes only that field;
- `to_mapping()` returns a fresh exact built-in dictionary in `_FIELDS` order;
- canonical identity bytes are:
  ```python
  json.dumps(
      identity_mapping,
      ensure_ascii=False,
      allow_nan=False,
      sort_keys=True,
      separators=(",", ":"),
  ).encode("utf-8", "strict")
  ```
- no Unicode normalization;
- digest is:
  ```text
  SHA256(digest-domain UTF-8 || NUL || canonical identity bytes)
  ```

All valid semantic strings are bounded refs, digests, enums, schemas, or
timestamps. No arbitrary text field exists.

SAFE REF, DIGEST, AND TIME RULES

Safe refs:

- exact built-in `str`;
- length `1..96`;
- ASCII;
- regex:
  ```text
  [A-Za-z0-9][A-Za-z0-9.-]*
  ```
- reject case-insensitive prefixes:
  ```text
  connector-
  tunnel-
  workspace-
  org-
  organization-
  user-
  ```
- reject four-component IPv4-shaped literals with
  `privacy_forbidden_material`.

Digests:

- exact built-in `str`;
- exactly 64 lowercase hexadecimal characters.

Timestamps:

- exact built-in `str`;
- exact whole-second UTC:
  ```text
  YYYY-MM-DDTHH:MM:SSZ
  ```
- valid calendar time;
- observation constructor requires:
  ```text
  observed_at < expires_at
  ```

Qualification relation freshness is:

```text
observed_at <= now_utc < expires_at
```

Equal-time observation is accepted. Equal-time expiry is blocked.

EXACT FOURTEEN DIMENSIONS

The fourteen fields are exactly:

```text
noninteractive_operation
wire_command_input_only
wire_result_output_only
protocol_stdout_only
private_bounded_diagnostic_stderr
external_cancellation_control_supported
external_deadline_control_supported
invocation_bound_logical_context
private_history_non_authority
isolated_credential_use
private_interaction_material
zero_git_effects
restricted_network_access
external_session_non_authority
```

Qualified meanings and later-owner boundaries:

- `noninteractive_operation`: no synchronous prompt, TTY, or user approval;
  concrete flags/RPC methods remain D/E.
- `wire_command_input_only`: outer worker input is exactly the committed Wire
  command frame; inner provider format remains private/later-owned.
- `wire_result_output_only`: any result bytes are exactly one Wire result
  frame; no-result remains process evidence.
- `protocol_stdout_only`: stdout is empty or the one protocol result, never
  logs/JSONL.
- `private_bounded_diagnostic_stderr`: diagnostics remain private, capped, and
  redacted; numeric caps/retention/truncation remain D/E.
- `external_cancellation_control_supported`: supervisor/ES can request and
  enforce cancellation outside provider semantics; mechanics remain D/E.
- `external_deadline_control_supported`: supervisor/ES owns deadline
  enforcement; timer/termination mechanics remain D/E.
- `invocation_bound_logical_context`: logical context is bounded to one
  invocation and is not hidden progression state; physical process reuse
  remains D/E proof.
- `private_history_non_authority`: history is private and cannot drive identity,
  replay, retry, or acceptance.
- `isolated_credential_use`: no Coordinator credential exposure; live handoff
  remains E/ES-owned.
- `private_interaction_material`: prompt, transcript, reasoning, response, and
  JSONL remain outside Wire/durable/report surfaces.
- `zero_git_effects`: RW0 performs no commit/ref/push/PR/merge/publication
  effect; later Git work remains separately governed.
- `restricted_network_access`: any network use is separately authorized and
  bounded; this value grants no egress.
- `external_session_non_authority`: provider sessions are private and
  non-authoritative.

No numeric process/resource/capture limit is introduced.

NON-RECURSIVE SAFE RECONSTRUCTION

Implement the exact private helper graph in substance:

```text
_closed_capability_mapping
_validate_member
_validate_cross_fields
_raw_identity_mapping
_raw_canonical_bytes
_raw_identity_digest
_from_mapping_impl
_extract_stored_mapping
_safe_reconstruct_impl
_capture_boundary
_unwrap_boundary
_raise_public
```

### Construction

`_from_mapping_impl(cls, payload, budget)` must:

1. close the direct mapping;
2. traverse/charge the input graph under the shared budget;
3. validate every ordered member;
4. validate observation windows or qualification result/reason coherence;
5. build raw identity mapping without public methods;
6. recompute and compare the final self-digest;
7. construct a fresh exact value with `object.__new__` and private `_values`;
8. build a fresh projection;
9. traverse/charge the projection with the same budget;
10. return `(rebuilt_value, fresh_projection)`.

It must never call a public semantic method.

### Existing-value extraction

`_extract_stored_mapping(value, expected, budget)` must:

1. require `type(value) is expected`;
2. charge the tuple root;
3. read `_values` with `object.__getattribute__`;
4. map missing `_values` to sealed `invalid_field_type`;
5. require exact built-in tuple;
6. require exact tuple length;
7. charge every member;
8. require every member exact built-in `str`;
9. return a fresh mapping in `_FIELDS` order.

### Safe reconstruction

`_safe_reconstruct_impl(value, expected, budget)` must feed the extracted
mapping through `_from_mapping_impl` with the same budget and return only fresh
validated output.

Incomplete, tampered, or correctly resealed but semantically invalid values
must fail before semantic use.

All public methods, readable declared attributes, equality, and the
qualification relation must use this seam.

WORK ACCOUNTING

Use one cumulative `_WorkBudget` with active-object cycle detection for each
Capability-local operation.

For a valid flat value:

```text
V(declaration)   = 1 root + 23 members = 24
V(observation)   = 1 root + 30 members = 31
V(qualification) = 1 root + 25 members = 26
```

Exact limits:

```text
from_mapping 2V:
  declaration   48
  observation   62
  qualification 52

safe existing-value reconstruction 3V:
  declaration   72
  observation   93
  qualification 78

same-class equality 6V:
  declaration   144
  observation   186
  qualification 156
```

The relation uses one local counter:

```text
declaration reconstruction     72
observation reconstruction     93
qualification reconstruction   78
phase basis leaf                1
authority observation leaf      1
readiness observation leaf      1
host qualification leaf         1
current effect fence leaf        1
now_utc leaf                     1
                               ---
Capability-local              249
```

B1 separately enforces its unchanged exact 241-unit owner budget:

```text
successful composed sum:
249 + 241 = 490
```

This is the sum of two separately enforced counters, not one counter propagated
into B1.

Graph traversal rules:

- exact `dict`, `list`, and `tuple` containers only;
- charge each container before descent;
- for dictionaries, charge each value occurrence before descending;
- scalar leaves are charged once;
- reject bytes/bytearray/memoryview with `privacy_forbidden_material`;
- active-object identity stack detects cycles;
- repeated shared aliases are traversed and charged again after leaving the
  active stack;
- valid stored `_values` members are flat exact strings;
- all fixed loops are statically bounded and do not define attacker-controlled
  work.

Maximum-valid and one-under tests must pin:

```text
construction:
48/47
62/61
52/51

safe reconstruction:
72/71
93/92
78/77

Capability relation local:
249/248
```

B1's 241/240 boundary is tested separately through the owning relation; do not
invent a single 489-unit counter.

DIRECT MAPPING CLOSURE

Implement exact precedence:

1. exact built-in `dict` only; otherwise `invalid_field_type`;
2. if `len(payload) > len(_FIELDS) + 1`, fail
   `invalid_length_or_cardinality` in O(1), before key traversal;
3. every key exact built-in `str`; otherwise `invalid_field_type`;
4. every key length exactly `1..39`; otherwise
   `invalid_length_or_cardinality`;
5. every key ASCII; otherwise `invalid_length_or_cardinality`;
6. accepted field names are recognized before private-fragment checks;
7. aggregate unknown-key findings independent of insertion order;
8. if any unknown key contains a private fragment, fail
   `privacy_forbidden_material`;
9. otherwise if any unknown key exists, fail `unknown_field`;
10. only then fail `missing_field` for any absent required field.

Exact private fragments:

```text
hostname
host_key
ip_address
endpoint
username
bearer
token
secret
signature
trust_root
prompt
transcript
stdout
stderr
provider
environment_value
absolute_path
workspace_path
store_path
credential
account
model
session_id
jsonl
pid
process_handle
```

Accepted fields containing words such as `stdout`, `stderr`, `credential`, or
`session` must be accepted because exact-field recognition precedes privacy
scanning.

FIXED WIRE OWNER SEAM

Import the private `wire_profile_mapping` function and load the pair once at
module initialization.

Require exact owner output:

```text
outer type:
exact dict

ordered keys:
schema_id
profile_ref
manifest
profile_digest

schema_id:
governed-execution.nwp-rw0-wire-protocol-profile.v1

profile_ref:
rw0-wire-nwpf-v1

manifest:
exact built-in dict

profile_digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
```

The loader must:

- call the no-argument owner once during module initialization;
- extract only the exact ref and digest strings;
- retain only:
  ```text
  _WIRE_PROFILE_REF
  _WIRE_PROFILE_DIGEST
  ```
- discard the temporary outer mapping and manifest reference;
- never copy, traverse, canonicalize, or store the 4,021-byte manifest;
- expose no constructor/relation parameter that can replace the pair;
- make post-import replacement of the imported function unable to alter the
  retained pair.

Malformed owner output is an internal import-time invariant failure:

```text
RuntimeError("RW0WorkerMechanismCapabilityWireOwnerInvariant")
```

Raise it from `None` only after leaving any foreign exception handler. It is not
a public Capability error.

Tests may invoke the private loader under controlled monkeypatching to exercise
malformed owner output, but production code must call it only for the one
module-level assignment. Wire bytes must remain unchanged.

IMPORTS AND PRIVATE BOUNDARY

The new module may import only:

Standard library:

```text
__future__
datetime
hashlib
json
re
typing
```

Private Coordinator modules:

From `_worker_execution_semantic_values`:

```text
EffectFenceV1
```

From `_rw0_phase_entry_semantic_values`:

```text
RW0PhaseValueError
RW0PhaseEntryBasisV1
RW0AuthorityVerificationObservationV1
RW0RemoteHostReadinessObservationV1
RW0EffectHostQualificationV1
validate_host_qualification
```

From `_rw0_wire_protocol_values`:

```text
wire_profile_mapping
```

No row-value, SQLite, process, filesystem, network, provider, package-root, or
public import is permitted.

B1 and Wire must not import Capability. No existing production module imports
Capability in this tranche.

ERROR ALGEBRA AND BOUNDARY

Exact public reasons:

```text
invalid_field_type
missing_field
unknown_field
invalid_enum
malformed_ref
malformed_digest
invalid_timestamp_window
invalid_length_or_cardinality
digest_mismatch
graph_cycle
cumulative_work_exhausted
privacy_forbidden_material
relation_mismatch
qualification_reason_mismatch
```

Stored-state failure mapping:

```text
wrong expected class:
invalid_field_type

missing _values:
invalid_field_type

non-exact tuple:
invalid_field_type

wrong tuple length:
invalid_length_or_cardinality

non-exact-string member:
invalid_field_type

bad schema/source/dimension/result/reason literal:
invalid_enum

bad ref:
malformed_ref

bad digest:
malformed_digest

bad timestamp/window:
invalid_timestamp_window

constructor-invalid result/reason:
qualification_reason_mismatch

wrong self-digest:
digest_mismatch

B1 exception or unrelated qualification subject:
relation_mismatch
```

`RW0WorkerMechanismCapabilityError`:

- sealed and non-subclassable;
- immutable and non-pickleable;
- `.reason` is the only semantic property;
- `args == ("RW0WorkerMechanismCapabilityError",)`;
- `str` and `repr` contain only
  `RW0WorkerMechanismCapabilityError`;
- no field path or supplied value property;
- public boundary leaves `__cause__` and `__context__` as `None`;
- no hostile payload is reachable through traceback locals.

Use a two-stage internal reason carrier and boundary object patterned after the
accepted Wire boundary:

1. active handler captures only a finite reason;
2. no exception or supplied payload is retained;
3. return from the handler;
4. clear `self`, payload, and relation arguments where applicable;
5. raise the public error from the reason-only object outside the handler.

QUALIFICATION RELATION

Implement exactly:

```python
validate_worker_mechanism_capability_qualification(
    *,
    declaration: RW0WorkerMechanismCapabilityDeclarationV1,
    observation: RW0WorkerMechanismCapabilityObservationV1,
    qualification: RW0WorkerMechanismCapabilityQualificationV1,
    phase_basis: RW0PhaseEntryBasisV1,
    authority_observation: RW0AuthorityVerificationObservationV1,
    readiness_observation: RW0RemoteHostReadinessObservationV1,
    host_qualification: RW0EffectHostQualificationV1,
    current_effect_fence: EffectFenceV1,
    now_utc: str,
) -> None
```

Exact ordered algorithm:

1. Create the 249-unit Capability-local budget.
2. Safely reconstruct declaration, observation, and qualification under that
   one counter.
3. Charge and exact-type-check:
   - phase basis;
   - authority observation;
   - readiness observation;
   - host qualification;
   - current effect fence;
   - `now_utc`.
4. Validate `now_utc` as an exact timestamp.
5. Read the module-fixed Wire pair.
6. Invoke imported B1 `validate_host_qualification(...)` exactly once with:
   ```text
   basis=phase_basis
   authority=authority_observation
   readiness=readiness_observation
   qualification=host_qualification
   current_effect_fence=current_effect_fence
   now_utc=now_utc
   ```
7. Any `RW0PhaseValueError` becomes sealed `relation_mismatch`.
   Any unexpected foreign exception is sanitized by the outer public boundary
   to `relation_mismatch`.
8. After a successful B1 call, require the reconstructed Capability
   qualification's declaration pair to equal the reconstructed declaration's
   own pair; otherwise sealed `relation_mismatch`.
9. Require its observation pair to equal the reconstructed observation's own
   pair; otherwise sealed `relation_mismatch`.
10. Compute exactly one expected `(result, reason)` using the precedence below.
11. Require the reconstructed qualification's stored pair to equal expected;
    otherwise `qualification_reason_mismatch`.
12. Return `None`.

Exact expected-result precedence and predicates:

### 1. `b1_binding_mismatch`

Expected:

```text
("blocked", "b1_binding_mismatch")
```

when any Capability qualification coordinate does not exactly match the
supplied objects:

- phase basis ref/digest;
- authority observation ref/digest;
- readiness observation ref/digest;
- host qualification ref/digest;
- current effect intent/fence ref/fence digest;
- `qualification.evaluated_at == host_qualification.evaluated_at == now_utc`.

### 2. `b1_host_qualification_blocked`

Expected:

```text
("blocked", "b1_host_qualification_blocked")
```

when B1 host qualification result is exactly `blocked` with any
constructor-valid B1 blocking reason.

### 3. `b1_host_qualification_unknown`

Expected:

```text
("unknown", "b1_host_qualification_unknown")
```

when B1 host qualification is exactly:

```text
result=unknown
reason=unknown
```

### 4. `declaration_observation_mismatch`

Expected:

```text
("blocked", "declaration_observation_mismatch")
```

when the observation's declaration ref/digest pair does not equal the supplied
declaration's own pair.

It does not mean a dimension-state disagreement.

### 5. `self_observation`

Expected:

```text
("blocked", "self_observation")
```

when:

```text
declaration.declaration_source_ref
==
observation.observation_source_ref
```

This proves only structural collapse.

### 6. `observation_expired`

Expected:

```text
("blocked", "observation_expired")
```

when:

```text
observed_at <= now_utc < expires_at
```

is false after constructor-valid `observed_at < expires_at`.

### 7. `worker_artifact_mismatch`

Expected:

```text
("blocked", "worker_artifact_mismatch")
```

unless the same artifact ref/digest pair appears in all of:

- declaration;
- observation;
- Capability qualification;
- B1 readiness observation;
- B1 host qualification's required worker artifact pair.

### 8. `wire_profile_mismatch`

Expected:

```text
("blocked", "wire_profile_mismatch")
```

unless the same profile ref/digest pair appears in all of:

- declaration;
- observation;
- Capability qualification;
- module-fixed Wire owner pair;
- B1 readiness observation's worker protocol pair;
- B1 host qualification's required worker protocol pair.

### 9. `declaration_unsupported`

Expected:

```text
("blocked", "declaration_unsupported")
```

when at least one declaration dimension is `unsupported`.

### 10. `observation_nonconformant`

Expected:

```text
("blocked", "observation_nonconformant")
```

when no declaration dimension is unsupported and at least one observation
dimension is `contradicted`.

### 11. `capability_unknown`

Expected:

```text
("unknown", "capability_unknown")
```

when no earlier predicate applies and at least one declaration dimension is
`unknown` or one observation dimension is `unknown`.

### 12. `qualified`

Expected:

```text
("qualified", "qualified")
```

only when every declaration dimension is `supported`, every observation
dimension is `confirmed`, and every prior relation is satisfied.

Do not trust a bare B1 `qualified` value. The B1 owning relation must succeed
on the complete supplied graph first.

EXACT DOCUMENTATION STATUS

### New sole owner

Create:

```text
.docs/rw0-b2-capability.md
```

It is the sole detailed Capability owner and must contain:

- purpose/current status;
- exact classes, schemas, fields, domains, and methods;
- Wire pair binding;
- complete B1 composition;
- exact qualification predicates/precedence;
- mechanism-neutral dimension meanings;
- privacy/freshness/bounds/error algebra;
- import/public boundary;
- explicit C/D/E/ES seams and nonclaims;
- exact implementation status.

Use one visible, unfenced owner marker pair:

```text
<!-- RW0_B2_CAPABILITY_OWNER_BEGIN -->
<!-- RW0_B2_CAPABILITY_OWNER_END -->
```

The live owner body must be inside the unique intended heading range. Fenced,
historical, sibling, relocated, duplicated, split, reversed, or trailing
visible owner prose must be rejected by tests.

### B1 ownership clarification

In:

```text
.docs/rw0-b1-pure-phase-values.md
```

change only the bounded ownership/current-status prose that currently says B2
owns Wire/Codex mechanism.

Clarify:

- RW0-B2-Wire owns representational framing and process/result
  classification;
- RW0-B2-Capability owns provider- and mechanism-neutral declaration,
  observation, and qualification semantics;
- RW0-D/E own concrete CLI/App Server/provider/credential/session/process
  mechanics;
- B1 schemas, relations, identities, budgets, and nonclaims are unchanged.

### Wire current-status clarification

In:

```text
.docs/rw0-b2-wire-protocol.md
```

change only current-status prose required to replace
“Capability remains seam-bounded and unimplemented” with a pointer to the
separate implemented Capability owner.

Do not modify Wire profile bytes, identity, framing, codec, error, classifier,
limits, or semantic sections.

### Five synchronized status projections

Add a separate visible block to exactly:

```text
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
```

Markers:

```text
<!-- RW0_B2_CAPABILITY_CURRENT_STATUS_BEGIN -->
<!-- RW0_B2_CAPABILITY_CURRENT_STATUS_END -->
```

The normalized body must be byte/whitespace-normalized identical across all
five documents and state:

```text
RW0-B2-Capability implements private, pure, no-I/O worker-mechanism capability
declaration, independently authored supplied observation, and Coordinator
qualification values plus one pure qualification relation. It binds the fixed
RW0-B2-Wire profile `rw0-wire-nwpf-v1` with digest
`470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454`
and revalidates the complete applicable B1 host-qualification graph through
B1's owning relation. It authenticates no source, proves no physical process
behavior, grants no permission or semantic acceptance, persists no fact,
contacts no worker/provider/host, and selects no CLI, App Server, credential,
provider-session, transport, or runtime mechanism. `.docs/rw0-b2-capability.md`
is the sole detailed Capability owner. RW0-C retains durable evidence,
recovery, terminal, and latch ownership; RW0-D/E retain offline/process and
live-proof mechanics; Execution Substrate retains admission and runtime
authority.
```

Line wrapping may follow each document, but normalized body and meaning must be
identical.

Do not rewrite the existing Wire block into the Capability owner.

EXACT 20-PATH CEILING

Only these paths may change.

New files:

```text
.docs/rw0-b2-capability.md
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py
```

Existing files:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
```

Expected final topology:

```text
20 dirty paths
14 tracked modifications
6 untracked additions
0 staged
0 unmerged
all regular mode 0644
```

Stop if a twenty-first path is needed.

EXISTING BOUNDARY TEST CHANGES

Modify existing tests without adding, removing, renaming, parameterizing,
skipping, xfail-ing, or reordering existing node IDs.

- `test_rw0_b1_boundaries.py`:
  permit exactly the new Capability module as a production importer of B1;
  verify the exact imported B1 names; continue rejecting every other importer.
- `test_rw0_b2_wire_boundaries.py`:
  permit exactly the new Capability module as a production importer of Wire;
  remove only the stale Capability-unimplemented assertion; require the
  separate Capability owner and unchanged Wire ownership.
- `test_runtime_non_authority.py`:
  add exactly the new private source to the production inventory; preserve all
  non-authority checks.
- `test_c2a_nonimplementation.py`:
  add exactly the new private source filename; preserve C2A/Wire/B1 byte and
  semantic boundaries.
- `test_rw0_remote_contact_phase_entry_contract.py`:
  own the separate Capability marker layout and five-document normalized body;
  preserve Wire markers and all RW0-A/B1/Wire contracts.
- `test_architecture_contracts.py` and
  `test_software_development_progression_boundary.py`:
  replace stale Capability-unimplemented expectations with implemented-private
  pure/nonruntime/nonprogression assertions.

No new test node may be introduced outside the four new Capability test files.

NEW TEST OWNERSHIP

### `tests/test_rw0_b2_capability_values.py`

Own:

- exact construction posture;
- exact built-in types/subclasses/bool rejection;
- exact fields and enums;
- ordinary construction, slots, immutability, copy/deepcopy, pickling,
  hashability, repr/str;
- all public methods and readable attributes through safe reconstruction;
- incomplete/tampered/resealed-invalid values;
- direct mapping closure and all precedence overlaps;
- privacy fragments and every ref field including IPv4-shaped refs;
- timestamp/window boundaries;
- exact construction and safe-reconstruction work budgets;
- cycles, nested hostile values, and repeated aliases;
- sealed error cause/context/traceback-local hygiene.

### `tests/test_rw0_b2_capability_vectors.py`

Own literal test-independent:

- exact ordered field tuples;
- schema IDs and digest domains;
- complete safe fixtures;
- canonical identity byte strings;
- self-digests;
- no normalization behavior where applicable;
- fresh projection order;
- fixed Wire pair literals;
- no production tuple/domain/profile constant reuse to calculate expected
  vectors.

### `tests/test_rw0_b2_capability_relations.py`

Own:

- one literal expected-result function independent of production helpers;
- every result/reason and every pairwise precedence conflict;
- exact B1 call once;
- bare-B1-qualified false positive;
- all qualification subject identity mismatches;
- complete B1 phase/authority/readiness/host/effect mutations one coordinate at
  a time;
- artifact and Wire pair matrix;
- source structural inequality/non-authentication;
- observation freshness boundaries;
- every dimension state;
- relation-local 249/248;
- separate B1 241/240 evidence;
- exact composed sum 490;
- selective and class-wide safe-reconstruction bypass mutants;
- downstream mismatch unable to mask missing reconstruction;
- no semantic read from original Capability values after reconstruction.

### `tests/test_rw0_b2_capability_boundaries.py`

Own:

- exact allowed imports and one-way direction;
- empty `__all__`;
- no package-root export;
- no production caller;
- no I/O/runtime/process/network/provider/dynamic import;
- no row/SQLite/public import;
- Wire owner loader called only at module initialization;
- malformed Wire owner outputs for type/key order/schema/ref/manifest/digest;
- only two Wire strings retained and no manifest retained;
- provider/mechanism/route/private-material forbidden literals;
- owner/status marker visibility, uniqueness, same-title sibling, fenced,
  relocated, duplicate, split/reversed marker, and trailing-prose mutants;
- exact 20-path ceiling and protected 21st-path controls;
- package/dependency/config/public-surface stability.

TEST-FIRST CAUSAL GATE

Implement tests before production source:

1. create the new governing document and four new test files;
2. do not create the Capability source yet;
3. run the four new test files once under isolated paths;
4. require collection/import failure only because
   `_rw0_worker_mechanism_capability_values` does not exist;
5. preserve stdout/stderr/JUnit/return code and repository fingerprint;
6. then implement the source and bounded existing updates.

A fixture, syntax, unrelated import, or existing-test failure is not an
acceptable red gate.

VALIDATION POSTURE

Use one external operator-owned mode-0700 evidence root. For every child:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
actual caller/child numerical umask equality
```

Retain exact argv, environment, timing, return code, stdout/stderr, JUnit,
structured counts, and before/after repository fingerprints.

FINAL VALIDATION ORDER

After final source/docs/tests are frozen:

1. collect the final complete node list exactly once;
2. compare to opening:
   - every opening node present in identical order;
   - zero removals or renames;
   - every addition belongs only to the four new Capability test files;
   - no existing test file adds a node;
3. run each new file individually:
   - values;
   - vectors;
   - relations;
   - boundaries;
4. run all four Capability test files together;
5. run B1 compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```
6. run Wire compatibility:
   ```text
   tests/test_rw0_b2_wire_values.py
   tests/test_rw0_b2_wire_codec.py
   tests/test_rw0_b2_wire_relations.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
7. run C2A compatibility:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_c2a_first_slice_semantic_protocol_contract.py
   tests/test_c2a_effects_and_recovery.py
   ```
8. run static/public compatibility:
   ```text
   tests/test_c2a_nonimplementation.py
   tests/test_runtime_non_authority.py
   tests/test_rw0_b1_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_b2a_writer_session_contract.py
   tests/test_codex_agent_config.py
   ```
9. run status/document contracts:
   ```text
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```
10. run `git diff --check`;
11. run exact path/mode/protected/import/public/residue/operation/lock guards;
12. run the complete repository suite exactly once.

Every final green gate must have:

- return code 0;
- zero failures, errors, skips, xfails, warnings;
- empty stderr;
- parseable JUnit;
- no duplicate or unmapped cases;
- stable before/after candidate fingerprint.

FULL-SUITE REPAIR POLICY

If complete-suite attempt 001 fails:

- preserve all evidence;
- repair only when the failure is causally introduced by this patch and the
  repair remains inside the exact 20 paths;
- rerun affected focused groups;
- run complete-suite attempt 002 exactly once.

Stop without further mutation if:

- a twenty-first path is required;
- a protected B1/Wire/C2A byte must change;
- an existing test must be deleted, renamed, skipped, xfailed, weakened, or
  reparameterized;
- a dependency/config/schema/migration/public surface must change;
- a third complete-suite attempt would be needed.

PROTECTED BYTE SURFACES

Byte-identical protection includes:

```text
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_development_author_effect_establishment_contracts.py
src/ge_nwp_coordinator/_development_decision_row_values.py
src/ge_nwp_coordinator/_development_effect_row_values.py
src/ge_nwp_coordinator/_development_program_row_values.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml
all SQL/migrations/schemas/catalog behavior
StateStore
WriterSession
all B1 values/vectors/relations test files
all Wire values/codec/relations test files
tests/c2a_contract_support.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py
AGENTS.md
README.md
.docs/software-development-progression-boundary.md
```

The two challenged protected tests may be run but not edited.

PROVENANCE RECIPE

Use exact recipe ID:

```text
governed-execution.audit-patch-manifest.v1
```

Expected source size:

```text
3_945 bytes
```

Expected source SHA-256:

```text
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Decode this base64 only into the external evidence root and retain it mode
`0400`:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

The recipe's historical output path is outside the repository. Preserve any
pre-existing file there: execute the exact source unchanged while an external
wrapper redirects only its exact `Path.write_bytes` sink to unique files under
the evidence root.

After validation and cleanup:

1. require exact topology:
   ```text
   20 dirty
   14 tracked modified
   6 untracked
   0 staged
   0 unmerged
   ```
2. run the exact recipe twice;
3. require byte-identical manifests and complete outputs;
4. retain:
   - exact recipe source;
   - complete outputs;
   - canonical manifests;
   - tracked textual-diff SHA-256;
   - every per-file mode/size/SHA-256;
   - opening/final node lists and delta;
   - every validation record;
   - final guards;
5. verify every path outside the 20-path ceiling equals HEAD;
6. remove only artifacts created by this engagement.

Do not stage, commit, push, create a PR, or perform an independent audit.

STOP CONDITIONS

Stop without further mutation if:

- baseline identity or opening cleanliness differs;
- the feature branch already exists;
- the accepted Wire profile pair differs;
- the B1 host relation signature or 241 budget differs;
- the exact class/field/reason schema cannot be implemented without change;
- caller substitution of the Wire pair cannot be prevented;
- full safe reconstruction requires a different public identity;
- any provider/mechanism/credential/session/endpoint/private material would
  enter a value;
- source authenticity, permission, acceptance, persistence, or runtime
  authority would be implied;
- a protected path must change;
- a 21st path is needed;
- final node ownership is not confined to the four new test files;
- validation or provenance is unstable.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT
```

only if the full reconciled design is implemented, every final gate is green,
the complete suite passes, exact provenance is stable, and every stop condition
is false.

FINAL REPORT

Include:

1. opening and final repository identity;
2. exact branch and topology;
3. test-first red evidence;
4. exact 20-path ledger with new/modified classification;
5. class/field/schema/reason implementation summary;
6. safe reconstruction and public-boundary implementation;
7. Wire owner loading proof;
8. B1 composition and qualification precedence;
9. exact budget evidence:
   - 48/62/52;
   - 72/93/78;
   - equality 144/186/156;
   - local 249;
   - B1 241;
   - composed sum 490;
10. mapping/privacy/error evidence;
11. status/owner synchronization;
12. node identity and delta;
13. every validation attempt, including failed development runs;
14. complete-suite attempt count and result;
15. final provenance identities and complete manifest;
16. protected bytes and public/authority non-widening;
17. assumptions, limitations, and remaining C/D/E/ES seams;
18. separate confidence for provenance, validation, and implementation.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
```
