PROMPT_ID

RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_ASSURANCE_MODEL_RESET_FREEZE_V1

TITLE

Coordinator RW0-B2-Capability — freeze a bounded commit-compatibility assurance
model and retire the self-protecting test-verifier architecture

ENGAGEMENT TYPE

Read-only architecture, contract, and test-assurance reset in the existing
Capability implementation conversation.

Do not mutate repository files. Do not run pytest, node collection, mutation
probes, A/B/C simulations, full suites, cleanup, provenance generation,
staging, commit, push, pull request, merge, release, deployment, provider or
live-host contact, product worker/model execution, database work, dependency
installation, or supporting-repository inspection.

The parent performs the inspection. Do not create subagents.

The complete operative response must be printed inline in the Codex chat.
Evidence paths may be listed only as supplementary provenance after all
decision-relevant findings, exact decisions, touched-file forecasts, and the
next implementation boundary have appeared inline.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Stop the repeated patch cycle around
`tests/test_rw0_b2_capability_boundaries.py` and freeze a smaller, defensible
assurance contract before any further repository write.

The current checked-in test architecture attempts to prove that the test module
itself cannot be subverted by arbitrary same-process mutation of:

- its fixtures;
- its autouse gate;
- its verifier;
- its helper functions;
- function `__code__`;
- module globals;
- literal expectation carriers;
- source/AST/code projections;
- callsite ledgers;
- binding ledgers;
- external callable aliases.

The G11/G12/G13 audit sequence demonstrates that this architecture is
self-referential and open-ended. Any verifier, expectation carrier, or trust
anchor placed inside the same mutable Python process can itself be modified.
Adding another in-module seal merely moves the root of trust.

The next step is not another repair to the same self-protecting verifier. The
next step is to freeze the proper boundary among:

1. permanent repository tests;
2. independent external audit/mutation analysis;
3. Git/object/ref provenance;
4. commit-gate validation.

OPENING BASELINE

Require and report exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644

candidate tree:
e70ff57a307539aa3e4c736913e30924e52eebb9
```

Require read-only confirmation that:

- `git diff --check` is clean;
- cached diff is empty;
- no operation or lock exists;
- no thirty-first changed path exists;
- every path outside the candidate equals HEAD.

CURRENT CANDIDATE TARGET

The only G10→G12 repair path was:

```text
tests/test_rw0_b2_capability_boundaries.py
```

Current identity:

```text
type:
regular

kind:
untracked

mode:
0644

size:
272157 bytes

SHA-256:
82cd8d5161950f51bb862ce966772c9014c4575f408325d02113478e0144ca4a
```

Current final candidate manifest:

```text
size:
6431 bytes

SHA-256:
1dfd2c1d4e265972630cd74bed3fec959b3059c9bd3cc12f42a4ea1f4521a2f0
```

Current final nodes:

```text
count:
5150

ordered SHA-256:
184bd8a792c396cfaa49486761c2b20912d39ced574591818aef0fd86beda9ce
```

LATEST INDEPENDENT AUDIT

G13 root:

```text
/private/tmp/g13.p4eDNA
```

G13 self-excluding index:

```text
/private/tmp/g13.p4eDNA/evidence_index.jsonl

rows excluding itself:
345

size:
52102 bytes

SHA-256:
8145e1b2f1483ec71f8899cf132f4232d59d6795808373e27a4e76f47dba2d38
```

Read the complete G13 inline report and indexed evidence for:

```text
F-001 shared self-sealing verifier bypass
F-002 simultaneous local-gate alteration
F-003 mutable carrier/captures authenticate themselves
F-004 co_exceptiontable omitted from code seal
F-005 incomplete Python 3.13 binding grammar
F-006 callsite ledger lacks execution context
F-007 G12 evidence-root audit contamination
F-008 incomplete runtime-root inventory
F-009 lexical path-provenance defect
F-010 attempt-032 chronology inaccuracy
```

Do not treat those findings as an instruction to add a third generation of
self-sealing machinery. Determine which requirements belong in permanent
repository tests and which belong in external audit/provenance.

INSPECTION SCOPE

Inspect completely:

```text
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/c2a_contract_support.py

.docs/rw0-b2-capability.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md

src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml
```

Inspect additional Coordinator files only for a concrete dependency and record
why. Do not inspect another repository.

ASSURANCE RESET — REQUIRED STRATEGIC DECISIONS

Freeze the following unless repository evidence establishes a concrete
contradiction.

## 1. Permanent repository-test trust boundary

Permanent checked-in tests are trusted code under ordinary pytest execution.

They must detect regressions in the repository/product contract.

They are not required to remain correct after arbitrary same-process mutation
of:

- their own functions;
- their own fixtures;
- their own constants;
- their own expected values;
- their own `__code__`;
- pytest's collection/setup machinery;
- Python builtins or standard-library callables;
- the module namespace that defines the test.

A coordinated mutation of both an assertion and its expected oracle is not a
runtime product threat. It is a review/provenance concern.

No permanent test may claim to be cryptographically or mechanically
tamper-proof against code that already controls its Python interpreter.

## 2. Permanent commit-compatibility test responsibility

The permanent test should own only finite, state-independent repository
contract assertions, including as applicable:

```text
exact 30-path candidate inventory
regular-file type
required mode
R01–R30 path facts
P01–P13 protected-content identities
absence of package-root export
absence of production importer/caller
dependency/schema/migration non-widening
StateStore/WriterSession non-widening
private/no-I/O/non-authority boundaries
clean-commit compatibility
```

It must not depend on transient dirty/staged Git status.

It should use direct, reviewable Python assertions and simple literal expected
data.

It should not contain:

```text
self-source parsing
self-AST authentication
self-code-object authentication
self-binding ledgers
self-callsite ledgers
runtime callable captures
autouse/explicit dual self-protection gates
source-order language emulation
generic Python binding analysis
in-process tamper-resistance claims
```

A small ordinary test may check that its own implementation imports no
subprocess/Git command library, but that check is an accidental-drift control,
not an adversarial root of trust.

## 3. Independent audit responsibility

Fresh independent audit owns:

```text
AST/static review of the permanent test
absence of transient Git-state/process dependencies
one-predicate mutation tests for each owned assertion
A/B/C state validation
external clean-commit validation
candidate/protected manifest comparison
causal mutant strength
review of any changed test implementation
```

Audit mutants may modify an external copy of a test to show an assertion is
causal.

The independent audit must not require the checked-in test to defeat arbitrary
coordinated mutation of its own checker and expectations inside the same
process.

## 4. Git/provenance responsibility

Git/object/ref truth and exact patch provenance own:

```text
visibility of changes to test logic
exact changed paths
exact bytes/modes/tree
reviewable assertion/oracle changes
staged/committed candidate identity
clean committed tree identity
```

This is the external trust anchor for coordinated test changes.

No in-module recursive seal replaces Git provenance.

## 5. Commit-gate responsibility

The commit gate should:

```text
stage only accepted manifest paths
validate exact staged tree
run collection once
run the complete suite once against the staged or clean candidate in a
state-compatible manner
commit exact accepted tree
push exact commit
open one PR
```

A permanent test must pass in both a dirty candidate and clean committed tree,
but it does not need to introspect which state it is in.

G13 FINDING DISPOSITION

For every G13 finding F-001 through F-010, classify it as exactly one:

```text
REAL_PERMANENT_TEST_DEFECT
REJECTED_ASSURANCE_ARCHITECTURE_SYMPTOM
EXTERNAL_AUDIT_REQUIREMENT
PROVENANCE_OR_EVIDENCE_DEFECT
AUDIT_PROCESS_DEFECT
OBSERVATION_ONLY
```

Explain the disposition and whether any repository byte must change.

Do not silently dismiss:

- a real state-dependent assertion;
- a missing stable repository contract;
- a missing independent expected value;
- a genuine import/public/authority widening;
- inaccurate checked-in documentation.

But do reject the premise that a test module must protect itself against
arbitrary code running with equal interpreter authority.

REPLACEMENT TEST ARCHITECTURE

Design the exact bounded replacement for
`tests/test_rw0_b2_capability_boundaries.py`.

The replacement should:

1. retain the actual Capability boundary/value/public/non-authority tests that
   are still useful;

2. retain or re-express the exact 30-path and P01–P13 contracts;

3. remove all rejected self-protecting machinery;

4. use literal independent expected data;

5. avoid Git status and process execution;

6. work from repository files and static AST/content only;

7. pass in unstaged, staged, and clean committed trees;

8. remain understandable in direct code review;

9. have a finite, proportionate size;

10. produce content-free diagnostics where privacy requires them.

Report:

```text
exact sections/helpers/constants/tests to retain
exact sections/helpers/constants/tests to delete
exact sections to replace
proposed new test names
proposed literal data structures
proposed maximum file size or line-count range
expected node removals
expected node additions
expected renames
```

Do not edit the file in this engagement.

TOUCHED-FILE DECISION

Determine whether the reset can be implemented in exactly:

```text
tests/test_rw0_b2_capability_boundaries.py
```

Prefer one file.

If a second repository file is genuinely required, identify:

```text
exact path
owner
why one file is unsafe or circular
why the new file does not recreate an infinite verifier chain
```

A second file is a redesign trigger and requires a new decision before
implementation.

Do not authorize a second file merely to move the same self-authentication
machinery elsewhere.

NODE MIGRATION

The current opening baseline is 5,150 nodes.

Because the rejected assurance architecture created many tests, removals and
renames are expected and may be required.

Produce an exact migration policy:

```text
retain unrelated nodes in order
remove nodes whose sole purpose is in-process self-tamper resistance
replace them with bounded contract and causal assertion tests
record every old node disposition
derive final node count from collection
do not preserve volume for its own sake
no skip or xfail as migration
```

Identify categories and prospective counts where possible. Do not invent exact
final counts if inspection cannot support them.

VALIDATION MODEL FOR THE RESET

Freeze the implementation validation sequence:

1. opening identity/provenance;
2. opening collection;
3. test-first red for the simplified permanent contract where applicable;
4. implement only the frozen test reset;
5. run the complete modified test file;
6. run Capability complete;
7. run B1/Wire compatibility;
8. run architecture/status/static compatibility;
9. A/B/C target and projection checks;
10. final collection and explicit node migration;
11. one live complete suite;
12. one fully external clean-commit complete suite;
13. exact guards and cleanup;
14. two final provenance runs;
15. fresh independent audit.

The validation recorder should be proportionate and complete for credited final
runs. Do not require reconstruction of every exploratory shell command as a
candidate correctness claim.

EVIDENCE MODEL

Freeze a proportionate evidence contract:

Mandatory:

```text
opening/final repository identity
exact changed paths and bytes
opening/final node lists
final focused run records
A/B/C records
live and clean complete-suite records
run-local pre/post candidate fingerprints
final manifests
guards/cleanup
self-excluding index
```

Development/tooling attempts should be reported honestly but need not form a
self-proving recursive evidence system.

Audit-created bytecode or temp residue is an audit-process issue. It must not be
silently deleted from an already sealed prior root. A fresh audit should use a
new root and bytecode-disabled import posture.

FRESH AUDIT ACCEPTANCE CONTRACT

Define the fresh audit boundary after reset.

The auditor should independently verify:

```text
permanent test contains no transient Git-status dependency
no subprocess/process/Git command dependency in normal execution
literal 30-path and P01–P13 ownership
every owned assertion has a one-predicate external mutant
A/B/C state independence
live and clean suite results
exact candidate/protected provenance
public/import/privacy/authority non-widening
```

The auditor should not treat arbitrary coordinated mutation of the test and its
oracle inside one interpreter as a candidate defect.

REDESIGN TRIGGERS

Stop and return `ASSURANCE_RESET_BLOCKED` if:

- repository docs explicitly require adversarial self-protection by the test
  module;
- a permanent state-independent boundary cannot be expressed without Git
  subprocess/status calls;
- literal expected data would create a second semantic authority conflicting
  with owning contracts;
- more than one file is required and authority ownership is unclear;
- simplifying the test would remove a real production/public/privacy/authority
  contract with no replacement.

OUTPUT

Return a complete inline report with these headings:

```text
# Disposition

# Opening identity

# Current test architecture

# Root-cause assessment

# Assurance responsibility split

# G13 finding dispositions

# Replacement permanent-test contract

# Exact retained and removed surfaces

# Touched-file ceiling

# Node migration policy

# Validation and evidence contract

# Fresh independent-audit contract

# Risks and redesign triggers

# Next implementation prompt boundary

# Confidence
```

SUCCESS TOKEN

Return exactly:

```text
RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_ASSURANCE_RESET_READY
```

only when the operating boundary, replacement test architecture, touched-file
ceiling, migration policy, validation contract, and audit contract are
sufficiently exact for one parent-only implementation prompt.

If blocked, return exactly:

```text
ASSURANCE_RESET_BLOCKED
```

No repository mutation may occur.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
NODE_COLLECTION_NOT_RUN
MUTATION_PROBES_NOT_RUN
THREE_STATE_SIMULATION_NOT_RUN
FULL_SUITE_NOT_RUN
CORRECTNESS_AUDIT_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
```
