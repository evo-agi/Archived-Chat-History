PROMPT_ID

RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIR_CLOSEOUT_RECOVERY_V1

TITLE

Coordinator RW0-B2-Capability — recover the complete immutable closeout report
for the final audit-findings repair

ENGAGEMENT TYPE

Read-only report and provenance recovery in the same write-enabled Capability
implementation conversation that returned only:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

The success token alone is not a sufficient independent-audit handoff.

Do not edit repository files. Do not rerun implementation, selected tests,
mutation probes, node collection, full suites, cleanup, provenance generation,
or any historical attempt. Do not stage, commit, push, create a PR, merge, tag,
release, deploy, contact a remote/service/provider/host, invoke a product
worker/model, mutate a database, install dependencies, or inspect a supporting
repository.

This engagement may only locate, safely verify, and report the immutable
closeout evidence that already produced the success token.

If any mandatory retained evidence is missing, unsafe, or cannot be verified,
return exactly:

```text
REPORT_EVIDENCE_INCOMPLETE
```

Do not regenerate missing evidence.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED REPOSITORY IDENTITY

Require the unchanged implementation branch and base:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

expected topology:
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644
```

Stop with:

```text
REPORT_PROVENANCE_MISMATCH
```

if the live identity or topology differs from the bytes that produced the
success token.

OPENING REPAIR TARGET

The final audit-findings repair began from this exact candidate:

```text
canonical-manifest SHA-256:
0919e82038367f54defd36171a19550873f38acae714bd7398e5a56b2fb8d77a

opening pytest node count:
5057

opening ordered-node-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

opening clean candidate tree:
52e32a55dc2e6b023b669810fb244301807f7618
```

Latest independent-audit root:

```text
/private/tmp/g4.S4uFyK
```

Latest independent-audit report:

```text
/private/tmp/g4.S4uFyK/final_report.md
```

Latest independent-audit index:

```text
/private/tmp/g4.S4uFyK/evidence_index.jsonl

rows excluding itself:
72

SHA-256:
f4836712bfc0e55dda2bb489401dabc55958016fc3c1778f8ad40a33bc5cb5b9
```

The two blocking findings were:

```text
High:
the no-status guard missed constructed/prebuilt argv, shell strings, and
aliased attribute-based Git calls

Medium:
weakening a protected-content assertion still left all seventeen boundary
tests green
```

EXACT AUTHORIZED REPOSITORY DELTA

Only this repository path was authorized to change:

```text
tests/test_rw0_b2_capability_boundaries.py
```

The other 29 candidate entries must remain byte-, type-, kind-, mode-, size-,
classification-, and SHA-256-identical.

No path may become newly dirty or cease being dirty.

MANDATORY RETAINED EVIDENCE ROOT

Locate the new repair evidence root created by the implementation turn. Do not
guess its path. Derive it from retained conversation state, terminal records,
or filesystem evidence.

Safely `lstat` every path component before reading it.

Report:

```text
absolute evidence-root path
owner/group/mode
symlink posture
retained regular-file count
retained directory count
special/symlink count
total regular bytes
self-excluding evidence-index path
index row count
index byte size
index SHA-256
whether every indexed row verifies
whether retained files are regular, operator-owned, and mode 0400
whether directories are operator-owned and mode 0700
whether any unsafe entry exists
```

Mandatory retained records include:

```text
final report
attempt ledger or attempt manifest
opening identity/provenance records
selected red/control records
final selected causal records
closed reachable-call inventory
all no-status mutant sources and results
literal 43-row projection
protected-content causal ledger
stable-contract mutant ledger
A/B/C state records
alternate-index staged-tree record
external clean-commit repository/tree/commit record
opening and final node lists
node delta
focused validation summaries/stdout/stderr/JUnit
live full-suite summary/stdout/stderr/JUnit
clean-commit full-suite summary/stdout/stderr/JUnit
run-local pre/post fingerprints for both suites
final canonical manifest
both final recipe outputs
aggregate identities
final guards
cleanup record
self-excluding evidence index
```

If any mandatory record is absent or unsafe, return
`REPORT_EVIDENCE_INCOMPLETE`.

Do not recreate it.

PROVENANCE RECOVERY

Recover and report:

```text
exact retained recipe-source path
recipe ID
recipe type/mode/size/SHA-256
wrapper path/size/SHA-256
final canonical-manifest path
final canonical-manifest byte size
final canonical-manifest SHA-256
final tracked textual-diff SHA-256
final complete recipe-output byte size
final complete-output SHA-256
file count
exact complete canonical manifest JSON
```

Require the recipe source to be:

```text
regular file
mode 0400
size 3945 bytes
SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Do not rerun the recipe. Verify the retained final runs and their exact
byte-equality.

EXACT ONE-PATH DELTA

Compare the opening target with the final target.

For:

```text
tests/test_rw0_b2_capability_boundaries.py
```

report:

```text
opening kind/type/mode/size/SHA-256
final kind/type/mode/size/SHA-256
```

List the other 29 candidate entries and prove they are exact.

Prove:

```text
no second repair path changed
no thirty-first path exists
no dirty path became clean
no mode drift
no symlink drift
no addition/deletion/rename/copy classification drift
```

FINDING-CLOSURE REPORT

## 1. Closed reachable-call contract

Report:

```text
exact target test node
exact finite local helper-root inventory
complete reachable local-function inventory
exact external-call allowlist
module-global identity/type inventory
finite diagnostics
AST/source implementation path and lines
```

Prove the final contract:

- starts from the exact permanent boundary test;
- resolves the complete reachable local helper graph;
- rejects unknown local helpers;
- rejects arbitrary local-variable callables;
- rejects default/closure callables;
- rejects dynamic dispatch through:
  `getattr`, `globals`, `locals`, `vars`, `__import__`, `eval`, `exec`,
  `compile`;
- rejects star imports and unresolved aliases;
- rejects nested or attribute call chains outside the exact allowed surface;
- permits only the finite stable operations actually required;
- rejects command/process/Git-capable primitives by semantic target rather than
  source spelling;
- validates module-global names/types/identities;
- contains no copied or fallback command detector that is itself the only
  oracle.

Report every no-status mutant:

```text
case ID
mutation class
mutant source path
mutant source SHA-256
expected diagnostic
actual diagnostic
result
```

At minimum cover:

```text
direct subprocess
constructed/prebuilt argv
shell string
concatenated shell string
imported callable alias
module alias attribute
nested attribute alias
getattr dispatch
wrapper accepting argv
callable default
callable closure
module-global executable callable
unknown local helper
dynamic import
GitPython-like status call
dulwich-like status call
```

Report unique source-byte and purpose checks.

## 2. Literal 43-row projection

Report the exact literal test-owned 43-row inventory, in order.

For every row report:

```text
row ID
contract class
source path or boundary subject
exact expected stable value
dedicated diagnostic
```

Prove:

```text
exactly 43 rows
unique row IDs
unique purposes
no transient Git-state field
no circular expected-value derivation
no duplicate semantic target unless explicitly justified
same projection in A/B/C states
```

## 3. Protected-content causal closure

Identify the exact protected-content assertion that survived the prior audit.

Report every protected-content row in the final projection and its causal
record:

```text
row ID
canonical source/fixture path
before SHA-256
after SHA-256
exact one-predicate mutation
expected diagnostic
actual diagnostic
disabled-owning-assertion control result
```

Prove:

- every protected-content row has an independent literal expected value;
- every one-predicate mutant leaves all unrelated predicates unchanged;
- the boundary checker rejects through that row's dedicated diagnostic;
- disabling only that row's assertion causes the causal control to fail;
- the exact prior audit survivor is included and killed.

## 4. Stable-contract mutation matrix

Report every mutant and result for:

```text
missing required path
unexpected literal path
regular file changed to symlink
wrong mode
package-root export
production importer/caller
dependency/schema/migration widening
protected-content weakening
```

If additional mutants were needed for protected-content rows, report all of
them.

## 5. Three-state compatibility

Report complete records for:

```text
A live unstaged
B alternate external index staged
C fully external clean committed
```

For each report:

```text
repository/root
Git-status shape
target-test result
43-row projection SHA-256
candidate/tree identity
source real-index fingerprint
source object-database fingerprint
```

Require:

```text
target passes A
target passes B
target passes C
projection A == projection B == projection C
B staged tree == C committed tree
source repository real index unchanged
source repository object database unchanged
```

Report the exact final B/C tree.

TEST-FIRST AND DEVELOPMENT CHRONOLOGY

Report every retained attempt in exact order:

```text
opening provenance reproduction
opening collection
selected red gate
all development runs
final selected causal
Capability boundaries
Capability complete
B1/Wire compatibility
architecture/status/static compatibility
final collection
A/B/C state checks
live complete suite
clean-commit complete suite
final guards
cleanup
final provenance runs
```

For each attempt report:

```text
label
purpose
credit classification
exact argv
working directory
exact environment
Python identity
caller/child umask
start/end/duration
PID
return code/signal
collected/passed/failed/error/skipped/xfail/xpass/warning counts
stdout path/size/SHA-256
stderr path/size/SHA-256
JUnit path/size/SHA-256/parse status
duplicate/unmapped cases
ordered node-list identity when applicable
pre fingerprint
post fingerprint
candidate-mutated result
notes
```

Do not omit failed, superseded, or tooling attempts.

NODE IDENTITY

Report:

```text
opening node-list path/count/SHA-256
final node-list path/count/SHA-256
retained intersection
additions
removals
renames
additions/removals by file
outside-authorized-file relative-order result
unlisted loss/reparameterization result
```

The opening count/hash were:

```text
5057
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe
```

Do not assume final node identity remained unchanged; report literal results.

FULL-SUITE RESULTS

Report both distinct state validations.

## Live candidate suite

Report:

```text
attempt number
exact command/environment
duration
collected/passed/counts
stderr
JUnit identity and node mapping
pre/post source fingerprints
candidate mutation result
```

## External clean-commit suite

Report:

```text
attempt number
exact command/environment
duration
external repository and object-database setup
diagnostic commit OID
commit tree OID
clean status
collected/passed/counts
stderr
JUnit identity and node mapping
source pre/post fingerprints
external repository pre/post fingerprints
candidate/tree mutation result
```

Prove both suites were run exactly once and are not retries of each other.

FINAL GUARDS

Report:

```text
git diff --check
cached diff check
status/topology/name-status/modes
protected-file comparison
package/export/import/caller checks
dependency/schema/migration/StateStore/WriterSession checks
authority/non-effect checks
operation/lock checks
residue checks
real-index invariance
source-object-database invariance
pre-existing evidence-root preservation
cleanup performed
```

AUTHORITY AND NONCLAIMS

Confirm:

- no document changed;
- no production source changed;
- no schema, migration, SQL, dependency, package export, `StateStore`,
  `WriterSession`, process, provider, network, Git, publication, or runtime
  authority widened;
- B1, Wire, and Capability remain private pure semantics;
- C/D/E and ES remain later/external owners.

OUTPUT

Return a complete report headed exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

The report must contain enough exact evidence to construct the fresh independent
audit prompt.

End with:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
