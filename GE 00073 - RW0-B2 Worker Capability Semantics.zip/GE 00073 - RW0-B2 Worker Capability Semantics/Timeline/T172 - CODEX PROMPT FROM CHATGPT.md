PROMPT_ID

RW0_B2_CAPABILITY_G16_PYCACHE_PREFIX_MATERIALITY_RECONCILIATION_V1

TITLE

Coordinator RW0-B2-Capability — read-only materiality reconciliation of the
G16 PYTHONPYCACHEPREFIX pathname reuse

ENGAGEMENT TYPE

Read-only disposition reconciliation in the same G16 audit conversation.

This is not a new correctness audit, validation replay, evidence repair, or
implementation pass.

Do not modify:

- the source repository;
- G14;
- G15;
- G16;
- any retained evidence;
- any Git index, ref, object, or worktree.

Do not run pytest, node collection, mutation probes, A/B/C, complete suites,
recipe generation, cleanup, or a new audit root.

The complete substantive response must be printed inline. Evidence paths may be
supplementary only.

CONTEXT

The prior G16 audit established:

- no Critical, High, Medium, or Low candidate defect;
- exact source and candidate provenance;
- exact G14 indexed evidence and canonical snapshot;
- exact G15 technical-audit evidence;
- targeted current checks green;
- public/privacy/authority boundaries green;
- no write outside G16;
- no candidate or source-repository mutation.

It returned BLOCK solely because two sequential outer Python wrapper
invocations reused this pathname:

/private/tmp/g16.9h0Mop/pycache_runner_live_three

The prior report also states:

- both invocations used `python3 -B`;
- both used `PYTHONDONTWRITEBYTECODE=1`;
- the first invocation was a pre-screened attempt that launched no pytest
  child;
- the first attempt's prefix path was deleted before the second invocation;
- no bytecode was written;
- no write occurred outside G16;
- G16 closed with no special or unindexed entry;
- the reuse did not affect candidate bytes, validation results, indexed
  evidence, or source provenance.

REVISED ACCEPTANCE RULE

The earlier requirement that every Python process use a globally unique
PYTHONPYCACHEPREFIX pathname is narrowed as follows:

A reused pathname is an observation, not a blocking defect, when all of these
conditions are proven from retained evidence:

1. the invocations were strictly sequential with no temporal overlap;

2. every invocation used both:
   - `python3 -B`; and
   - `PYTHONDONTWRITEBYTECODE=1`;

3. the earlier invocation launched no pytest child or other nested Python child
   that could outlive it;

4. the prefix path and every child beneath it were absent before the later
   invocation began, or the earlier path was completely removed and that
   removal is retained;

5. no bytecode or other persistent artifact from the earlier invocation was
   read or reused by the later invocation;

6. no write occurred outside G16;

7. source/candidate pre/post identities remained exact;

8. the final G16 self-excluding index and closeout inventory are exact and
   contain no residue from the earlier use;

9. no test, collection, mutation, A/B/C result, provenance result, or evidence
   identity depends on distinguishing the two pathname instances.

The purpose of unique prefixes is contamination isolation, not pathname
novelty as an end in itself. Sequential reuse of an empty/removed path under
bytecode-disabled execution is not material when the conditions above hold.

OBJECTIVE

Using only the retained G16 evidence, determine whether all nine revised
conditions are established.

Do not infer missing facts. If a condition is unsupported, identify the exact
missing record.

MANDATORY INLINE REPORT

Use these headings:

# Prior disposition

# Revised acceptance rule

# Exact two invocations

# Sequentiality and child-process proof

# Prefix-path lifecycle

# Bytecode and residue proof

# Source, candidate, and evidence integrity

# Materiality judgment

# Superseding verdict

# Confidence

Under “Exact two invocations,” report for each invocation:

- attempt/record identity;
- exact argv;
- parent PID;
- child PID, or explicit no-child result;
- wall start/end;
- monotonic start/end;
- exact environment entries for `PYTHONPYCACHEPREFIX`,
  `PYTHONDONTWRITEBYTECODE`, and relevant Python flags;
- return code;
- purpose;
- whether pytest or another nested Python process launched;
- prefix path existence before and after;
- cleanup/removal record.

Under “Prefix-path lifecycle,” state explicitly:

- whether the first use created the prefix path;
- whether it contained any file;
- exact deletion/removal time or sequence;
- whether absence was verified before the second use;
- whether the second use created any file;
- whether the final closeout found any residue.

Under “Materiality judgment,” answer:

1. Could stale bytecode from invocation one have been imported by invocation
   two?
2. Could the two processes have raced on the same path?
3. Could the reuse alter candidate/source bytes?
4. Could it alter any credited validation result?
5. Could it alter any indexed evidence identity?
6. Does pathname reuse, by itself, establish any correctness or provenance
   uncertainty?

VERDICT RULE

If all nine revised conditions are proven, return exactly:

ACCEPT

COORDINATOR_RW0_B2_CAPABILITY_ASSURANCE_RESET_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE

Also state:

- the earlier BLOCK was correct under the original stricter prompt;
- this ACCEPT supersedes it under the revised materiality-based rule;
- the pathname reuse is retained as a non-blocking audit-hygiene observation;
- no tests or evidence were rerun or modified.

If any revised condition is not proven, return exactly:

BLOCK

and identify the first unsupported condition and the minimal next action.

Do not create a new success token.

REQUIRED FINAL STATEMENTS

REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
TESTS_NOT_RUN
NODE_COLLECTION_NOT_RUN
MUTATION_PROBES_NOT_RUN
THREE_STATE_SIMULATION_NOT_RUN
FULL_SUITE_NOT_RUN
G14_ORIGINAL_ROOT_NOT_MODIFIED
G15_ROOT_NOT_MODIFIED
G16_ROOT_NOT_MODIFIED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
