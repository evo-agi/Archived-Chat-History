TITLE

Coordinator RW0-B2-Wire — fresh independent re-audit of the exact first-audit
repair candidate

ENGAGEMENT TYPE

Fresh Codex conversation. Read-only independent re-audit.

This is not implementation, repair, commit, publication, merge, deployment,
Capability work, or runtime proof.

The parent and every audit subagent are read-only. Do not edit, create, delete,
format, chmod, clean repository bytes, stage, commit, push, create or modify a
PR, merge, tag, release, deploy, install dependencies, run migrations, contact
networks/remotes/services, invoke product workers/models/providers, or modify a
supporting repository.

External audit evidence and isolated pytest scratch may be created only beneath
one new operator-owned, non-symlink, mode-0700 directory under `/private/tmp`.
Do not delete or rewrite implementation, repair, or prior-audit evidence.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

VERDICT TOKENS

Return exactly one primary verdict:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

On `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_WIRE_FIRST_AUDIT_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not repair any finding.

EXPECTED LIVE TARGET

Require at opening and closeout:

- physical root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- subject:
  `feat: implement RW0-B1 pure phase-entry semantics (#3)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- dirty paths:
  `16`
- tracked modifications:
  `10`
- untracked additions:
  `6`
- staged/unmerged:
  `0/0`
- every candidate path:
  regular mode `0644`
- no Git operation, lock, repository cache, bytecode, database, journal,
  archive, build, generated manifest, or recorder residue
- `git diff --check`:
  clean.

Do not fetch or contact a remote.

IMMUTABLE REPAIR TARGET

Repair evidence root:

```text
/private/tmp/rw0-b2-wire-repair.q4veCL
```

Canonical target:

```text
/private/tmp/rw0-b2-wire-repair.q4veCL/final_provenance_001.manifest.json
```

Equivalent second final manifest:

```text
/private/tmp/rw0-b2-wire-repair.q4veCL/final_provenance_002.manifest.json
```

Expected identities:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe source bytes:
3_945

recipe source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6

canonical-manifest SHA-256:
8c462b8fa4185e6795e6ce667da80f388a0109534da4263e6a47c3e4ab37b662

complete-output SHA-256:
9a1211f373b3995318b71ce3458f4f3895d56899ea8c110cf140d48d4a29a5be

file count:
16
```

Pre-repair implementation target:

```text
/private/tmp/rw0-b2-wire-v4.b4HlRt/final_001.manifest.json
```

Pre-repair target identities:

```text
tracked textual-diff SHA-256:
eb2e81a99c851c78d51db1e753b896841b1ded7856400270ba6a1ffc276ea4f5

canonical-manifest SHA-256:
11cb3375a687c00c221a56a8fdd1333a64bed189c697030894ba82abdd03a10a

complete-output SHA-256:
b0bcdb23305ff910cf5b2c2a484ed56aaceb284c875df4262533d8679cef0822
```

Prior independent-audit root:

```text
/private/tmp/rw0-b2-wire-independent-audit.hX8xit
```

Require all three evidence roots to remain unchanged.

EXACT 16-PATH SET

Untracked additions:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

Tracked modifications:

```text
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

No seventeenth path is permitted.

EXPECTED REPAIR DELTA

The pre-repair and repaired manifests have the same path set, classifications,
types, and modes.

Exactly 13 entries changed during repair:

```text
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/worker-execution-boundary.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_software_development_progression_boundary.py
```

Exactly three entries remained byte-identical:

```text
tests/test_architecture_contracts.py
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
```

Independently verify this delta. Do not rely on the repair report alone.

EXACT RECIPE SOURCE

Decode this base64 only into the external re-audit root, verify exact size and
SHA-256, and retain it mode `0400`:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

The source historically writes:

```text
/tmp/ge-coordinator-b3a-audit-manifest-v1.json
```

Do not overwrite pre-existing evidence at that path. Execute the exact recipe
source unchanged while an external wrapper redirects only that exact
`Path.write_bytes` sink to a unique file under the re-audit root. Do not alter
Git reads, canonicalization, stdout, stderr, or recipe source.

PROVENANCE GATE — BEFORE CORRECTNESS INSPECTION

1. Lstat every component of:
   - repair evidence root;
   - target manifest;
   - pre-repair implementation manifest;
   - prior audit root;
   - copied recipe source;
   - new re-audit root.
2. Require safe ownership, no symlink traversal, regular manifest/recipe files,
   and mode-0700 evidence roots.
3. Verify both final manifests are byte-identical and match the pinned SHA-256.
4. Parse canonical JSON and require exact:
   - branch;
   - HEAD;
   - upstream;
   - recipe ID;
   - textual-diff digest;
   - 16-path set;
   - classification;
   - file type;
   - mode;
   - size;
   - per-file SHA-256.
5. Compare every live candidate file with the repaired target.
6. Run the exact recipe twice at opening.
7. Require both complete outputs and manifests to be byte-identical and the
   generated manifest to equal the immutable repair target byte-for-byte.
8. Require repository identity and status to match the expected live target.
9. Verify no protected path outside the 16-path set differs from HEAD.
10. Verify the exact 13/3 pre-repair-to-repair delta above.

On any mismatch, stop before correctness inspection with:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not infer equality from the aggregate tracked diff because six files are
untracked.

CURRENT CONTRACT AND TARGET BOUNDARY

Committed HEAD owns the current C2A and B1 contracts. The uncommitted candidate
is the accepted private B2-Wire target.

The candidate may implement only:

- private deterministic NWPF command/result codecs;
- pure relations over supplied exact C2A values and actual fences;
- safe unauthenticated cancellation-request and process source claims;
- one pure process/result classifier;
- one fixed local Wire protocol profile.

It must implement no:

- source authentication;
- permission, effect authority, acceptance, or durable truth;
- worker, process, contact, physical transport, host, filesystem, database,
  network, provider, model, Codex, CLI, App Server, credential, session,
  Bridge, ES, Git, or publication effect;
- RW0-C persistence, recovery, evidence membership, terminal fact, or latch;
- RW0-D/E physical request delivery, process targeting, process mechanics, or
  live proof;
- Capability declaration, observation, qualification, or implementation.

FIRST-AUDIT FINDINGS TO RE-AUDIT

Treat the first audit’s findings as hypotheses to close independently, not as
automatically closed by the repair report:

```text
F1 High   foreign exception payload leak through cause/context/traceback graph
F2 High   ordinary and uninitialized immutable-value construction
F3 Medium hostile key/raw-pair/shape/work accounting
F4 Medium duplicate fact versus distinct singleton conflict
F5 Medium stale framing-deferred current-status prose
F6 Medium noncausal or incomplete test coverage
F7 Medium context-dependent cancellation graph mismatch reason
```

The fresh audit must also look for new defects introduced by the repair.

FROZEN IDENTITIES THAT MUST NOT CHANGE

```text
profile_ref:
rw0-wire-nwpf-v1

canonical profile identity bytes:
4_021

profile digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454

command payload/frame:
5_898 / 5_906 bytes

result payload/frame:
16_627 / 16_635 bytes

command/result hostile units:
23_746 / 66_770

max source-claim mapping key chars:
37

frame-map accepted key maximum:
derive independently from the literal frame roots and implementation; verify
that any internal cap admits every valid key and rejects overlong hostile keys
before normalization
```

A need to change the profile, payload caps, source ownership, or C2A/B1
contracts is a blocking redesign finding.

AUDIT EXECUTION SHAPE

Use at most four concurrent audit slots:

- create three bounded read-only audit subagents;
- the parent performs the fourth audit lane;
- no nested agents;
- no subagent runs pytest or mutates repository/evidence;
- give every subagent the same canonical manifest identity and self-contained
  context capsule;
- preserve disagreements and minority findings.

LANE 1 — SEALED ERRORS, CONSTRUCTION, AND HOSTILE INPUT

Inspect:

- Wire source and governing document;
- values and codec tests;
- relevant C2A constructors and relations.

Independently probe:

1. malformed JSON;
2. invalid UTF-8;
3. nested C2A reconstruction failure;
4. translated relation failure;
5. arbitrary long source-mapping keys;
6. private-fragment keys at and above the bound;
7. raw duplicate JSON pairs;
8. syntax error after an earlier duplicate;
9. depth/container/key/scalar overflows;
10. work-limit boundaries;
11. ordinary class construction;
12. explicit `object.__new__` incomplete instances;
13. tampered or incomplete self-digest values;
14. wrong types and subclass instances.

For every public error boundary verify:

```text
__cause__ is None
__context__ is None
constant safe args/str/repr
no hostile payload/sentinel reachable through:
  exception graph
  traceback objects
  traceback frame locals
```

Determine whether the implementation truly leaves the foreign handler and
drops hostile references before raising.

For work accounting verify:

- key/cardinality preflight occurs before normalization;
- lowercase is calculated once;
- raw pairs remain preserved and charged before dict construction;
- later syntax failure outranks duplicate-key reporting;
- one bounded traversal performs shape and duplicate accounting;
- no bulk enqueue occurs before caps;
- no second hostile-tree shape traversal occurs;
- canonicalization is not double-counted or left uncharged;
- encoder inputs cannot smuggle arbitrary mapping/alias/cycle graphs;
- exact maxima pass and one extra unit fails for the intended reason.

LANE 2 — AUTHORITY, PRIVACY, C2A RELATION COMPOSITION, AND STATUS

Inspect:

- RW0-A ownership clauses;
- C2A/B1 owning contracts;
- Wire source/relations;
- all six changed documents;
- status and authority tests.

Determine whether:

- direct-local cancellation requests are supervisor-authored;
- ES requests are Execution-Substrate-authored;
- acknowledgement/rejection remain adapter-authored;
- request/response source identity is not collapsed;
- cancellation effect/fence/delivery/target/command/candidate/attempt lineage is
  complete;
- command, target delivery, worker observations, and cancellation delivery call
  the owning C2A relations rather than duplicating an incomplete subset;
- source digests never become authentication, permission, acceptance, or
  durable truth;
- process facts remain evidence;
- route neutrality preserves ES authority;
- IPv4 and private material are rejected at every B2-defined ingress;
- C2A/B1 bytes and semantics remain unchanged;
- implemented private NWPF representation is clearly distinguished from
  deferred physical transport/process framing in every current document;
- all later RW0-C/D/E/ES and Capability seams remain explicit.

Construct at least one mutation for each required C2A relation that passes
local equality checks but should fail only through the owning C2A relation.

LANE 3 — CLASSIFIER AND RESULT SEMANTICS

Inspect:

- result grammar;
- actual C2A observation relations;
- request/process source claims;
- classifier source and direct tests.

Independently probe:

- both valid worker-result sequences;
- wrong order/count/source/invocation/ref/digest/fence/candidate;
- exact duplicate identities:
  - same object;
  - same ref;
  - same digest;
- distinct singleton conflicts:
  - same-code exits;
  - different-code exits;
  - repeated deadline;
  - repeated supplement kind;
  - acknowledgement plus rejection;
- request absent;
- request only;
- request plus acknowledgement;
- request plus rejection;
- response without request;
- request graph A/response graph B with supplied A;
- supplied B;
- supplied graph matching neither;
- unrelated non-cancellation fact;
- resource/deadline/signal/request/response/exit/result pairwise precedence;
- zero, nonzero, missing, duplicate, and conflicting exit;
- missing, malformed, relation-invalid, and valid result beneath each higher
  process tier;
- complete classification/reason constructor matrix;
- bypass-constructed values at every public classifier/relation boundary.

Require all cancellation mismatches against the supplied authoritative
cancellation graph to classify deterministically as
`cancellation_graph_mismatch`. Reserve `unrelated_fact` for non-cancellation
lineage.

LANE 4 — TEST CAUSALITY, PROFILE/CAPS, PUBLIC BOUNDARY, AND EVIDENCE

The parent performs this lane.

Inspect:

- all four new Wire test files;
- all modified existing tests/docs;
- repair and prior audit evidence;
- imports/AST/package/public surfaces;
- profile mapping;
- exact maximum fixtures;
- Markdown current-status oracles;
- repository/external artifacts.

Determine whether:

- literal fields/enums/profile/bytes/caps/reasons are independently test-owned;
- the complete profile independently reproduces 4,021 bytes and the pinned
  digest;
- exact command/result fixtures genuinely produce 5,898/16,627 payload and
  5,906/16,635 frame bytes;
- semantic decrement and every one-over case are causal;
- error-graph tests inspect cause, context, traceback, and hostile sentinels;
- construction tests reach every public boundary;
- raw-pair/work tests would fail under a dict-collapse or double-traversal
  regression;
- C2A causality tests include broken/no-op controls;
- classifier tests cover every pairwise precedence and duplicate/conflict
  distinction;
- each mutant changes one predicate and reseals only the owning digest;
- current-status blocks remain uniquely owned, visible, unfenced, synchronized,
  and resistant to sibling relocation, fenced duplicates, and trailing prose;
- no test was weakened, removed, renamed, skipped, xfailed, collapsed, or
  reparameterized;
- no package/public/production/dependency/schema/migration widening exists;
- repair evidence binds the final target and preserves prior evidence;
- no sensitive or repository-local artifacts remain.

IMPLEMENTATION EVIDENCE REVIEW

Safely inventory the repair root. Verify all credited records by exact identity,
argv, environment, umask, return code, stdout/stderr, JUnit, structured counts,
and before/after repository fingerprints.

Expected repair-reported final results:

```text
opening nodes:                    4_626
final nodes:                      4_644
new repair nodes:                 18
new-node ownership:               four new Wire test files only

selected causal:                  11 passed
Wire values:                      9 passed
Wire codec:                       12 passed
Wire relations:                   46 passed
Wire boundaries:                  11 passed
combined Wire:                    78 passed
C2A/C2A1:                         637 passed
B1:                               281 passed
static/public:                    105 passed
status/docs:                      858 passed
complete suite attempt 001:       4_644 passed
```

Preserve and classify diagnostic attempts, including:

- development Wire failures before green;
- stale-phrase status failure;
- repository-residue static failure;
- quoted-glob B1 invocation error;
- external guard transcription failures.

Do not treat a recorder or command-target error as a candidate test failure.
Do not give correctness credit to ambiguous or unbound evidence.

PARENT RECONCILIATION

Wait for all three subagents. Preserve disagreements. Directly inspect and
reproduce every material finding.

Classify each finding by:

- severity: Critical / High / Medium / Low / Observation;
- type: authority/contract, correctness, security/privacy/availability,
  test adequacy, documentation/status, public boundary, provenance/evidence;
- patch defect versus pre-existing issue;
- current-contract violation versus strategic-target defect;
- exact path:line evidence;
- impact;
- required correction;
- uncertainty.

Green tests never overrule a deterministic counterexample.

INDEPENDENT VALIDATION

Only after provenance and source/probe inspection are sufficiently green, run
serial independent validation under the new audit root.

For every child use:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
```

Capture and restore the actual caller umask; require child-observed numerical
umask equality.

Run:

1. four Wire files together:
   ```text
   tests/test_rw0_b2_wire_values.py
   tests/test_rw0_b2_wire_codec.py
   tests/test_rw0_b2_wire_relations.py
   tests/test_rw0_b2_wire_boundaries.py
   ```

2. corrected C2A/C2A1:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_c2a_first_slice_semantic_protocol_contract.py
   tests/test_c2a_effects_and_recovery.py
   ```

3. B1:
   ```text
   tests/test_rw0_b1_*.py
   ```

4. static/public:
   ```text
   tests/test_c2a_nonimplementation.py
   tests/test_runtime_non_authority.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_b2a_writer_session_contract.py
   tests/test_codex_agent_config.py
   ```

5. status/docs:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

Every executed gate must return 0 with empty stderr, zero
failures/errors/skips/xfails/warnings, parseable JUnit, no duplicate or unmapped
case, and unchanged repository target.

NODE IDENTITY

Collect the candidate exactly once and one clean external `git archive HEAD`
exactly once.

Require:

```text
candidate:                       4_644
HEAD:                            4_566
intersection:                    4_566
candidate-only:                  78
HEAD-only:                       0
```

Require all 78 candidate-only nodes to belong exactly to:

```text
tests/test_rw0_b2_wire_values.py       9
tests/test_rw0_b2_wire_codec.py        12
tests/test_rw0_b2_wire_relations.py    46
tests/test_rw0_b2_wire_boundaries.py   11
```

Require HEAD order preservation.

If source/probe inspection finds a blocker, the full suite may be withheld with
an exact explanation.

If inspection is green, run the complete repository suite exactly once and
require:

```text
4_644 collected
4_644 passed
0 failures/errors/skips/xfails/warnings
empty stderr
no duplicate or unmapped JUnit cases
unchanged target bytes
```

CLOSING GUARDS

Before verdict:

1. remove only audit-created transient caches, basetemps, archives, databases,
   journals, and recorder scratch;
2. rerun the exact recipe twice;
3. require both closing manifests and complete outputs to equal opening and the
   immutable repair target byte-for-byte;
4. require exact 16-path topology, modes, classifications, sizes, and hashes;
5. require protected complement equality to HEAD;
6. require clean `git diff --check`;
7. require no repository residue, operation, or lock;
8. confirm no repository mutation occurred;
9. confirm implementation, repair, and prior-audit evidence roots are unchanged.

ACCEPTANCE STANDARD

`ACCEPT` requires:

- exact provenance;
- no Critical, High, Medium, or Low patch defect;
- all seven first-audit findings mechanically closed;
- no new current-contract or accepted-target contradiction;
- complete authority/privacy/source separation;
- correct hostile decoding, error sealing, construction, relation composition,
  and classifier semantics;
- causally adequate tests;
- validated current-status and public/nonimplementation boundaries;
- required independent validation green;
- closing target byte-identical to opening.

An evidence limitation may be an Observation only when independent source,
probe, and validation work fully supersede it.

FINAL REPORT

Include:

1. exact opening/closing identity and provenance;
2. exact pre-repair-to-repair delta;
3. audit-lane reports and preserved disagreements;
4. severity-ranked finding ledger;
5. per-first-audit-finding disposition;
6. sealed-error/construction/work assessment;
7. authority/privacy/C2A-relation/status assessment;
8. result/classifier assessment;
9. profile/cap/test-causality assessment;
10. implementation-evidence assessment;
11. independent commands/results/node comparison;
12. closing guards, limitations, and separate confidence for:
    - provenance;
    - validation;
    - implementation.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
```
