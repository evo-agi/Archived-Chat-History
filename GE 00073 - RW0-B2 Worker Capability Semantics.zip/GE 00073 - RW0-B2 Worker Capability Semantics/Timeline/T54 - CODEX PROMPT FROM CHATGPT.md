PROMPT_ID

RW0_B2_WIRE_PROTOCOL_ACCEPTED_SQUASH_MERGE_GATE_V1

TITLE

Coordinator RW0-B2-Wire — squash-merge accepted PR #4 once, synchronize
`trunk_dev`, and verify the exact accepted tree

ENGAGEMENT TYPE

Audited publication merge gate.

This prompt authorizes only:

1. local read-only opening inspection;
2. read-only GitHub/remote/ruleset preflight;
3. exactly one squash-merge command for PR #4;
4. read-only verification of the resulting commit, PR, refs, tree, and blobs;
5. one fetch;
6. one local fast-forward synchronization of `trunk_dev`;
7. one isolated focused post-merge validation run;
8. external evidence closeout.

No implementation repair is authorized. Do not amend, rebase, cherry-pick,
force-push, directly push `trunk_dev`, enable auto-merge, submit a review,
self-approve, resolve a thread, delete either feature ref, create a second
commit, retry the merge command, tag, release, deploy, or modify a supporting
repository.

Do not create subagents. You are the sole merge-gate operator.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

ACCEPTED IMPLEMENTATION AND AUDIT

The independently accepted Wire candidate was committed and published as:

```text
feature commit:
32f2f38d49ce67eab6aff9c2cace9699a1a24f78

feature tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent / accepted base:
02450d3c99faf0fe7b299b914afaed312421bc8b

commit subject:
feat: implement RW0-B2 Wire protocol

commit body:
empty

committed shape:
10 modifications
6 additions
0 deletions
0 renames
0 copies
0 mode changes
```

Accepted manifest and provenance:

```text
repair report SHA-256:
7122444f4a3057dc66e64f87e4517e4ec4729bfc24cb96e9f845bf69cfe988fb

recipe SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

canonical manifest SHA-256:
c1fe53703e61cb30394b944af063ad5b23f4fc472f48571b1064cbde2f79a358

complete-output SHA-256:
58421af36213dfb0c74232acee5a68a3fa64cda5ad98e88e38c6ea54562c534a

tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6

accepted node count:
4_655

accepted node-list SHA-256:
f36822a60056ec3d110956de561202b737662c9d22cd0dd82c4cdad6c7cef69f
```

Commit-gate evidence:

```text
root:
/private/tmp/rw0-b2-wire-commit-gate.yIAdp7

evidence index:
/private/tmp/rw0-b2-wire-commit-gate.yIAdp7/evidence_index.json

evidence-index bytes:
8_286

evidence-index SHA-256:
ea48bf28d5c7790c2e668d989ffb205593807fa390f83d959788776706bd2a11

indexed files:
51

retained files including index:
52

indexed-entry digest:
9f2c23b8fb5cf2246088b3d5917bfa1d05904f1f9037f33e7c6748729d9f8da2
```

The accepted repair and audit evidence roots remain:

```text
/private/tmp/rw0-b2-wire-sixth-repair.JqZLSt
/private/tmp/rw0-b2-wire-sixth-audit.837YBq
```

Do not alter any retained evidence.

PULL REQUEST TARGET

Repository:

```text
evo-agi/Governed-Execution-Coordinator
```

Pull request:

```text
#4
https://github.com/evo-agi/Governed-Execution-Coordinator/pull/4
```

Expected PR state before merge:

```text
open:
true

draft:
false

merged:
false

base ref:
trunk_dev

base OID:
02450d3c99faf0fe7b299b914afaed312421bc8b

head ref:
codex/rw0-b2-wire-protocol-v1

head OID:
32f2f38d49ce67eab6aff9c2cace9699a1a24f78

title:
feat: implement RW0-B2 Wire protocol

body bytes:
649

body SHA-256:
af67b1e7f20a6979932c16153f53554d5a334a2503359ddb61eb479912c44e94

commit count:
1

file count:
16

mergeable:
true

merge state:
clean

auto-merge:
absent
```

OPENING LOCAL IDENTITY

Require exactly before remote preflight:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-wire-protocol-v1

HEAD:
32f2f38d49ce67eab6aff9c2cace9699a1a24f78

tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

upstream:
origin/codex/rw0-b2-wire-protocol-v1

ahead/behind:
0/0

worktrees:
1

worktree/index/untracked/unmerged:
clean
```

Require no Git operation, lock, repository cache, bytecode, database, journal,
archive, generated manifest, test residue, or build residue. Require
`git diff --check` clean.

Verify the feature commit has exactly the accepted tree and parent. Compare all
sixteen committed blobs, sizes, and Git modes with the accepted manifest. Do
not rely only on the tree OID.

EVIDENCE ROOT

Create one new operator-owned, non-symlink, mode-`0700` merge-gate evidence root
under `/private/tmp`.

Retain exact commands, argv, start/end timestamps, return codes, stdout/stderr,
API responses, ruleset snapshots, ref values, commit/tree/blob comparisons,
pytest/JUnit output, guards, and final evidence index.

All retained evidence files must be regular, operator-owned, and mode `0400` at
closeout. The evidence index must not index itself.

PHASE 1 — VERIFY PRIOR GATE EVIDENCE

Before querying live merge state:

1. `lstat` every path component for the commit-gate, repair, audit, and new
   merge-gate evidence roots;
2. require retained roots mode `0700`, no symlink traversal, and regular
   required files;
3. verify the commit-gate evidence index exact size and SHA-256;
4. verify all 51 indexed entries by path, type, ownership, mode, size, and
   SHA-256;
5. verify the accepted manifest identity and all sixteen feature-commit blobs;
6. verify the local clean branch identity above.

Stop with:

```text
MERGE_GATE_PROVENANCE_MISMATCH
```

on any mismatch. Do not repair or contact GitHub after a local mismatch.

PHASE 2 — LIVE REMOTE, PR, REVIEW, CHECK, AND RULESET PREFLIGHT

Perform one bounded live preflight.

Require:

```text
authenticated GitHub identity:
SeritArbores

remote trunk_dev:
02450d3c99faf0fe7b299b914afaed312421bc8b

remote feature ref:
32f2f38d49ce67eab6aff9c2cace9699a1a24f78
```

Re-read PR #4 and require exact base/head refs and OIDs, title, body bytes,
single commit, sixteen files, open/non-draft/unmerged state, and no auto-merge.

Record:

- mergeable state;
- merge-state status;
- reviews and review decisions;
- requested reviewers;
- review threads and resolution state;
- issue comments and review comments;
- check runs;
- workflow runs;
- commit statuses and combined status;
- effective repository/branch ruleset;
- current-user bypass status;
- allowed merge methods;
- repository auto-merge and branch-deletion settings.

Require before merge:

1. PR head remains the accepted commit.
2. PR base remains the accepted base.
3. Remote `trunk_dev` remains the accepted base.
4. PR is mergeable and clean.
5. No requested-changes review exists.
6. No unresolved review thread exists.
7. No rule-required review or approval is missing.
8. Every existing check/status/workflow is completed with an acceptable
   success/neutral/skipped result.
9. Zero checks/statuses is acceptable only if live rules still require none;
   record synthetic combined `pending` with total count zero honestly.
10. Current user has not and will not use a bypass.
11. Squash is an allowed merge method.
12. No conflicting ref, tag, replacement PR, or prior merge exists.

If any live condition is not satisfied, stop without merge:

```text
MERGE_GATE_PREFLIGHT_BLOCKED
```

Do not alter rules, dismiss reviews, resolve threads, update the branch, enable
auto-merge, request approval, or bypass policy.

PHASE 3 — EXACTLY ONE SQUASH-MERGE COMMAND

Run exactly this command once:

```text
gh pr merge 4 \
  --repo evo-agi/Governed-Execution-Coordinator \
  --squash \
  --match-head-commit 32f2f38d49ce67eab6aff9c2cace9699a1a24f78 \
  --subject "feat: implement RW0-B2 Wire protocol (#4)" \
  --body ""
```

Do not issue a second merge command under any circumstance.

If the command returns nonzero, times out, loses transport, or otherwise has an
ambiguous result:

1. retain exact evidence;
2. perform read-only PR and ref queries;
3. if PR #4 is already merged at a commit satisfying every post-merge invariant,
   classify the merge as completed-with-ambiguous-command-result and continue
   verification;
4. if it is not merged, stop;
5. never retry the merge command.

PHASE 4 — VERIFY THE SQUASH COMMIT AND REMOTE TRANSITION

Obtain the merge commit from GitHub and remote `trunk_dev`.

Require:

```text
sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

subject:
feat: implement RW0-B2 Wire protocol (#4)

body:
empty
```

Verify:

1. exactly one parent;
2. exact accepted tree;
3. GitHub signature status and verification reason recorded honestly;
4. all sixteen merged blobs equal the accepted feature blobs and manifest;
5. all merged modes are `100644`;
6. merged diff shape is exactly:
   - 10 modifications;
   - 6 additions;
   - 0 deletions;
   - 0 renames;
   - 0 copies;
   - 0 mode changes;
7. PR #4 is closed and merged exactly once;
8. PR merged commit OID equals remote `trunk_dev`;
9. remote feature ref remains exactly
   `32f2f38d49ce67eab6aff9c2cace9699a1a24f78`;
10. feature commit is not incorrectly treated as an ancestor-equivalent
    non-squash merge;
11. no tag, release, deployment, branch deletion, or auto-merge effect occurred.

Record exact remote-ref transition:

```text
trunk_dev:
02450d3c99faf0fe7b299b914afaed312421bc8b
→ <verified squash commit>

codex/rw0-b2-wire-protocol-v1:
32f2f38d49ce67eab6aff9c2cace9699a1a24f78
→ 32f2f38d49ce67eab6aff9c2cace9699a1a24f78
```

Stop on any mismatch. Do not repair, revert, or issue another merge.

PHASE 5 — ONE FETCH AND LOCAL FAST-FORWARD SYNCHRONIZATION

From the still-clean worktree:

1. perform one fetch of the exact remote base and feature refs;
2. require fetched `origin/trunk_dev` equals the verified squash commit;
3. require fetched feature ref remains the accepted feature commit;
4. switch to local `trunk_dev`;
5. require local `trunk_dev` is the accepted pre-merge base;
6. run exactly one:
   ```text
   git merge --ff-only origin/trunk_dev
   ```
7. require local `trunk_dev` equals the verified squash commit and tracks
   `origin/trunk_dev` at divergence `0/0`.

Do not merge or rebase the feature branch. Do not delete either feature ref.

PHASE 6 — ONE FOCUSED POST-MERGE VALIDATION RUN

Run one isolated focused pytest invocation on local `trunk_dev`.

Use:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
```

Capture the actual caller umask, restore it before launch, and require the child
to observe the same numerical value.

Exact test files:

```text
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py

tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_vectors.py
tests/test_worker_execution_semantic_relations.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_c2a_relations.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py

tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_boundaries.py

tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_b2a_writer_session_contract.py
tests/test_codex_agent_config.py

tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_remote_worker_pre_execution_planning_contract.py
```

Require exactly:

```text
1_970 collected
1_970 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
0 duplicate JUnit identities
0 unmapped cases
```

Require local tree, worktree, index, refs, and accepted merged blobs unchanged
before and after the run.

No retry is authorized. On failure, retain evidence and stop. Do not repair,
revert, or rerun under this prompt.

PHASE 7 — FINAL CLOSEOUT

Require:

- PR #4 closed and merged;
- local and remote `trunk_dev` equal the verified squash commit;
- local and remote feature refs remain intact at the feature commit;
- local `trunk_dev` divergence `0/0`;
- worktree and index clean;
- one worktree;
- no Git operation or lock;
- no repository cache, bytecode, database, journal, archive, recorder, or test
  residue;
- all sixteen merged blobs exact;
- repair, audit, commit-gate, and merge-gate evidence unchanged except for
  intended new merge-gate evidence;
- no second merge command;
- no direct trunk push;
- no bypass;
- no auto-merge;
- no review submission;
- no thread resolution;
- no feature-branch deletion;
- no tag, release, or deployment;
- no Capability implementation.

Create one final evidence index beneath the merge-gate root. It must include all
retained merge-gate files except itself, with relative path, type, mode, size,
and SHA-256. Record the index’s own size and SHA-256 separately.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_WIRE_PROTOCOL_SQUASH_MERGED_AND_VERIFIED
```

only if every gate passes.

FINAL REPORT

Include:

1. accepted manifest, audit, commit, and commit-gate evidence identities;
2. opening local identity;
3. live PR/ruleset/review/check preflight;
4. exact merge command, timing, return code, stdout, and stderr;
5. squash commit OID/tree/parent/subject/body/signature;
6. per-path merged blob and mode comparison;
7. remote ref transition and retained feature ref;
8. local fetch/fast-forward synchronization;
9. focused 1,970-test result;
10. final PR/ref/worktree/operation/residue guards;
11. evidence-root and index identities;
12. limitations and separate provenance, validation, and merge-confidence
    statements.

Required final statements:

```text
IMPLEMENTATION_REPAIR_NOT_PERFORMED
DIRECT_TRUNK_PUSH_NOT_PERFORMED
BYPASS_NOT_USED
FORCE_PUSH_NOT_PERFORMED
SECOND_COMMIT_NOT_PERFORMED
AMEND_NOT_PERFORMED
REBASE_NOT_PERFORMED
SECOND_MERGE_ATTEMPT_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
REVIEW_NOT_SUBMITTED
THREAD_NOT_RESOLVED
FEATURE_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
```
