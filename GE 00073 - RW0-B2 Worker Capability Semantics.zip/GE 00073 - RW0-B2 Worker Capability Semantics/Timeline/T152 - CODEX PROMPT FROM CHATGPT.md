PROMPT_ID

RW0_B2_CAPABILITY_FINAL_REPAIR_COMPLETE_VALIDATION_REPLAY_V3_RESTORE_HARNESS_FIXED

TITLE

Coordinator RW0-B2-Capability — fresh complete validation replay with a
schema-correct restore harness, canonical historical-evidence projection, and
normalized authoritative Git provenance

ENGAGEMENT TYPE

Parent-only validation-evidence replay in the same write-enabled Capability
implementation conversation.

THIS IS A COMPLETE REPLACEMENT PROMPT.

Do not combine it with, patch, resume, or partially reuse the execution state
of the prior G6 or G7 replay prompts. Read their retained evidence only.

Repository mutation is not authorized.

Do not edit, format, generate, delete, rename, chmod, stage, commit, push, open
a PR, merge, tag, release, deploy, contact a remote/service/provider/host,
invoke a product worker/model, mutate a database, install dependencies, or
inspect a supporting repository inside the source repository or any
pre-existing evidence root.

Inside the one new external evidence root created by this engagement, creating
files, atomic renames, local-only diagnostic Git repositories, and setting
retained files to mode `0400` and directories to mode `0700` are authorized
and required.

Do not modify or resume:

```text
/private/tmp/g5.hiLE2y
/private/tmp/g6.4101bd
/private/tmp/g7.30c557
```

This engagement creates a fresh, self-contained, authoritative validation and
closeout envelope for the exact current candidate.

CRITICAL INLINE RESPONSE RULE

The complete substantive success or failure report must be printed inline in
the Codex chat.

Do not return only:

- a token;
- a short summary plus `/private/tmp` links;
- “see report”;
- a hyperlink containing the operative diagnosis.

Evidence files may be listed as supplementary provenance only after all
decision-relevant facts, exact values, findings, and continuation boundaries
have been printed inline.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Replay the complete final validation sequence from bootstrap under one new root
after correcting the external-fixture restore harness defect identified at G7
attempt 0130.

The diagnostic established:

```text
primary classification:
G7_RESTORE_HARNESS_DEFECT

continuation:
G7_RESTART_FROM_SCRATCH_REQUIRED
```

Candidate behavior was correct:

```text
the regular-to-symlink mutant was created correctly
the target test rejected it with the exact expected diagnostic
the original regular file was restored with exact bytes and mode
the source repository and real source index were unchanged
```

The harness failed after restoration because it assumed the normalized
fingerprint contained a legacy top-level field:

```python
baseline_index = baseline.pop("index")
```

The current normalized schema is:

```text
governed-execution.normalized-authoritative-git-fingerprint.v1
```

and contains:

```text
logical_index_ls_files_stage_z
```

rather than a top-level `index`.

The new replay must:

1. build and self-test a schema-correct restore harness before candidate
   validation;

2. use one canonical content-stable schema for historical evidence roots;

3. use normalized authoritative Git provenance that excludes app-managed and
   storage-observation metadata;

4. replay every final causal mutant and focused group;

5. replay A/B/C state compatibility;

6. rerun live and clean collection;

7. rerun one live and one clean complete suite;

8. record every action from root bootstrap onward through an unconditional
   all-attempt ledger;

9. complete guards, cleanup, final provenance, report, and self-excluding index;

10. leave candidate bytes, logical source index, authoritative refs, and prior
    evidence unchanged.

OPENING REPOSITORY IDENTITY

Before bootstrap validation require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644
```

Require:

```text
git diff --check:
clean

logical cached diff:
empty

Git operation or lock:
none

logical source index:
unstaged

candidate symlink/special path:
none

repository cache/bytecode/database/journal/archive/build/generated-manifest/
recorder residue:
none

thirty-first changed path:
absent
```

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

AUTHORITATIVE CURRENT TARGET

Historical final-repair evidence root:

```text
/private/tmp/g5.hiLE2y
```

Required self-excluding index:

```text
/private/tmp/g5.hiLE2y/evidence_index.jsonl

rows excluding itself:
7234

size:
1583837 bytes

SHA-256:
199af9ac4299cc41a4434d44f1b1f7bcaf3265490b7417e174ad5d48723f8fcc
```

Required final facts recovered from indexed G5 records:

```text
candidate path count:
30

tracked modifications:
24

untracked additions:
6

staged/unmerged:
0/0

repair-opening node count:
5057

final node count:
5072

final B/C candidate tree:
0fcf6680ded68d66f62b75b5dc842d69b343a334

final live suite:
5072 collected
5072 passed

final clean suite:
5072 collected
5072 passed
```

Recover exact full values from indexed G5 records:

```text
final canonical-manifest path
final canonical-manifest byte size
final canonical-manifest full SHA-256
final tracked textual-diff full SHA-256
final complete recipe-output path/size/full SHA-256
exact final canonical manifest JSON
sole changed-path opening and final size/SHA-256
opening ordered-node-list path/full SHA-256
final ordered-node-list path/full SHA-256
exact final selected causal node IDs
closed reachable-call inventory
module-global identity/type inventory
every no-status mutant definition and expected result
literal ordered 43-row projection
protected-content causal ledger
exact prior-audit survivor kill record
stable-contract mutation matrix
A/B/C target and projection records
```

Do not use truncated prose hashes when exact indexed values exist.

FAILED REPLAY ROOTS AND DIAGNOSTICS

## G6

Failed replay:

```text
/private/tmp/g6.4101bd
```

Diagnostic:

```text
/private/tmp/g6diag.yF2Vcy
```

Diagnostic index:

```text
/private/tmp/g6diag.yF2Vcy/evidence_index.jsonl

rows excluding itself:
21

size:
3598 bytes

SHA-256:
88f7e186f6fa515d56d3ecbeb7d9239f31042b4defcbfce4d9c49da00b554094
```

Classify G6 as:

```text
historical failed replay
validation through both 5072-test suites completed
closeout stopped on historical-evidence comparison schema drift
cleanup never ran
attempt 0183 incomplete
no authoritative final report/index
not resumed or repaired
```

## G7

Failed replay:

```text
/private/tmp/g7.30c557
```

Attempt-0130 failure envelope:

```text
/private/tmp/g7.30c557/a/0130/envelope.json
```

Classify G7 as:

```text
historical failed replay
canonical controls and causal sealing completed
closed-call and protected-content mutants completed
A/B/C setup and runs completed
stable-contract phase partial
attempt 0129 correctly rejected regular-to-symlink mutant
attempt 0130 restored exact target bytes/mode but harness raised KeyError
focused groups, collections, suites, guards, cleanup, provenance, report, and
index not started
not resumed or repaired
```

The exact harness defect was:

```python
baseline_index = baseline.pop("index")
```

with:

```text
KeyError: 'index'
```

Do not reuse any G6 or G7 validation result as final replay authority.

PRE-EXISTING EVIDENCE ROOTS — READ ONLY

Safely verify and preserve at least:

```text
/private/tmp/g5.hiLE2y
  index:
  199af9ac4299cc41a4434d44f1b1f7bcaf3265490b7417e174ad5d48723f8fcc

/private/tmp/g4.S4uFyK
  index:
  f4836712bfc0e55dda2bb489401dabc55958016fc3c1778f8ad40a33bc5cb5b9

/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe
  index:
  bdffdfd9757302a7940b803f0d5138fdf9f9b41e53d95fcae3209b0e35dae71d

/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset2.Udjr4a
  index:
  a3abd5e9252da88623ab3285a6f560b7b71f151f672d25f6236c3779f806abe9

/private/tmp/gv3.efmQ8X
  index:
  cec6aba32a0243bf2b0b48d147df96ccb2b50ec5b9ec161dc1cc1c0d4f30eee1

/private/tmp/g6diag.yF2Vcy
  index:
  88f7e186f6fa515d56d3ecbeb7d9239f31042b4defcbfce4d9c49da00b554094
```

Also preserve every indexed root referenced by the G5 final report.

Safely `lstat` path components. Do not follow symlinks.

EXACT RECIPE SOURCE

Locate the exact retained recipe source through the G5 index.

Require:

```text
type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

The retained source and all pre-existing evidence roots remain read-only.

Create one root-local execution copy under the new root:

1. copy exact bytes under `umask 077`;
2. fsync and close;
3. atomically rename to `exact_recipe_source.py`;
4. set exact mode `0400`;
5. `lstat` and verify regular/non-symlink/operator-owned/mode/size/SHA-256;
6. seal a complete attempt envelope and `recipe_copy_preflight.json`;
7. invoke only after preflight passes.

NEW NEUTRAL EVIDENCE ROOT AND BOOTSTRAP

Create exactly one new top-level root:

```text
/private/tmp/g8.XXXXXX
```

The root and every pytest-visible child path must pass the exact retained
path-safety grammar.

The bootstrap is one self-recording Python process that:

1. creates the root mode `0700`;

2. retains exact source as `bootstrap.py`;

3. records:
   - argv/environment;
   - Python identity;
   - PID;
   - caller umask;
   - wall/monotonic timing;
   - return code;
   - stdout/stderr identities;
   - created root path/type/owner/mode;
   - source repository opening lightweight identity;

4. atomically writes `bootstrap_envelope.json`;

5. installs the unconditional recorder;

6. performs no unrecorded action after root creation.

The bootstrap envelope is sequence 1 in the all-attempt manifest.

ROOT REQUIREMENTS

```text
owner:
operator

symlink:
no

mode:
0700

temporary paths:
all below this root

repository-local evidence/temp:
none

retained regular-file mode:
0400

retained directory mode:
0700

symlink/FIFO/socket/device/special entry:
none in completed G8 root

self-excluding canonical JSONL index:
created last
```

PRE-BOOTSTRAP RESTORE-HARNESS SPECIFICATION

Before creating G8, define the replacement restore-harness contract in the
prompt-driven bootstrap source. This is tooling outside the repository.

The restore harness must use:

```text
governed-execution.normalized-authoritative-git-fingerprint.v1
```

It must not:

```text
read
pop
delete
expect
or compare
a top-level field named `index`
```

It must use the normalized field:

```text
logical_index_ls_files_stage_z
```

for logical index equality.

RESTORE-HARNESS ALGORITHM

For every external-fixture stable mutant:

1. save exact target identity:

   ```text
   relative path
   type
   mode
   regular-file bytes and SHA-256, or symlink target
   ```

2. save one normalized authoritative external-repository baseline;

3. save one separate report-only raw external-index observation;

4. apply the mutant;

5. execute the expected boundary assertion;

6. restore the target's exact original type, bytes/target, and mode;

7. verify the restored target directly before any Git query;

8. compute a new normalized authoritative external fingerprint;

9. require:
   - same schema ID;
   - exact `logical_index_ls_files_stage_z` equality;
   - exact normalized authoritative fingerprint equality;

10. separately record the new report-only raw index observation;

11. do not require raw `.git/index` bytes, inode, timestamps, or stat-cache
    fields to equal;

12. emit a successful cleanup record containing:

   ```text
   restore case ID
   restored target identity
   normalized baseline identity
   normalized current identity
   logical-index identity
   raw-index before observation
   raw-index after observation
   normalized equality result
   logical equality result
   ```

13. on any failure, seal a complete unconditional attempt envelope after
    recording whether the target itself was restored.

No call equivalent to:

```python
baseline.pop("index")
current.pop("index")
baseline["index"]
current["index"]
```

is permitted.

RESTORE-HARNESS STATIC SELF-AUDIT

Before candidate validation, inspect the retained G8 replay/harness source and
require:

```text
no AST subscript/attribute/pop/get using top-level literal `index` against a
normalized fingerprint

explicit use of `logical_index_ls_files_stage_z`

raw physical-index observation stored only in report-only records

normalized equality performed directly under the schema contract

target restoration verified before normalized comparison
```

A static failure stops before candidate validation.

RESTORE-HARNESS TOOLING SELF-TESTS

Run and fully envelope disposable external-repository self-tests before opening
candidate validation.

Self-test cases:

```text
regular file -> symlink -> exact regular restore
regular file -> missing path -> exact regular restore
mode mutation -> exact mode restore
regular-content mutation -> exact content restore
physical external-index stat-cache refresh with unchanged logical index
synthetic normalized baseline lacking top-level `index`
```

For every self-test require:

```text
mutant applied
expected predicate observed
target restored exactly
normalized fingerprint equal
logical index equal
raw index allowed to differ
no source repository effect
```

Also run one negative harness test in which:

```text
logical_index_ls_files_stage_z differs
```

and require the harness to reject with a finite diagnostic.

Do not proceed if any harness self-test fails.

CANONICAL HISTORICAL-EVIDENCE COMPARISON

Use exactly one implementation and one schema for opening and closing
verification of every indexed historical evidence root.

Row schema:

```text
relative_path
type
owner_uid
owner_gid
mode
regular_file_size_or_null
regular_file_sha256_or_null
```

Rules:

- directory size/hash always null;
- regular files use exact size/SHA-256;
- exclude the self-excluding index exactly as its contract requires;
- sort by UTF-8 relative-path bytes;
- compare opening/closing byte-for-byte with the same implementation;
- do not include directory st_size, atime, mtime, ctime, birthtime, inode,
  device, link count, flags, or xattrs in the canonical aggregate.

G6 AND G7 TRANSIENT QUARANTINE

Both G6 and G7 stopped before cleanup and may contain pytest basetemp
symlinks/FIFOs.

For each failed replay root separately:

1. derive quarantine roots mechanically and exclusively from exact retained
   launched pytest `--basetemp` argv values;

2. lexical-normalize only `.` and `..`; do not resolve symlinks;

3. require every root:
   - absolute;
   - strict descendant of its replay root;
   - real non-symlink directory;
   - tied to retained attempt sequence/label;

4. inventory every symlink/FIFO/socket/device/special entry with `lstat`;

5. require every unsafe entry to be beneath exactly one derived basetemp root;

6. require zero unsafe entries outside quarantine;

7. require no mandatory evidence record beneath quarantine;

8. create:
   - quarantine-root ledger;
   - canonical quarantine inventory;
   - canonical retained-evidence projection outside quarantine;
   - unsafe-boundary proof;
   - mandatory-record non-overlap proof;

9. compare opening/closing with identical code/schema;

10. do not delete, clean, chmod, resume, index, or repair either failed root.

Stop if the boundary proof fails. Do not widen quarantine based on names or file
types alone.

UNCONDITIONAL RECORDER

After bootstrap, every command or procedural action runs through the recorder,
including:

```text
recorder self-test
restore-harness static audit
each restore-harness tooling self-test
path-safety preflight
each evidence-index verification
each failed-root quarantine action
each evidence opening inventory
repository opening gate
recipe-copy preflight
opening recipe runs
target extraction
each mutation/control execution
each restore action
each pytest run
A/B/C setup and run
live/clean collection
node reconciliation
live/clean full suite
every final guard
each evidence closing inventory
cleanup
final recipe runs
final report generation
attempt-manifest finalization
pre-index inventory
index creation
external index verification
```

Each action gets a unique immutable sequence and label.

The recorder must seal an envelope on:

```text
success
expected nonzero mutant result
unexpected nonzero result
signal
preflight refusal
missing target
command not launched
JUnit absent/not applicable
wrapper/tooling failure
cleanup failure
index failure
```

ATTEMPT ENVELOPE SCHEMA

Every envelope includes:

```text
schema_id
sequence_number
label
purpose
attempt_class
credit_classification
expected_outcome
actual_outcome
exact argv
working directory
exact environment allowlist
unset variables
Python executable/realpath/version/implementation/platform
caller umask
child umask or not-launched
wall start/end UTC
monotonic start/end ns
duration ns
child PID or not-launched
return code
terminating signal
stdout path/size/SHA-256
stderr path/size/SHA-256
JUnit applicability/path/size/SHA-256/parse status
counts
duplicate/unmapped cases
ordered node-list identity when applicable
authoritative source pre/post fingerprint identities
external repository pre/post fingerprint identities when applicable
real logical-index pre/post identities
report-only raw-index observation identities when applicable
candidate-mutated boolean
external-target-restored boolean when applicable
notes
```

ALL-ATTEMPT MANIFEST

Maintain append-only:

```text
attempt_manifest.jsonl
```

Require:

```text
bootstrap row first
one row per command/action
no missing sequence
no duplicate label
no command log without row
no envelope without row
finalized before final report
complete chronology embedded inline in final response
```

RECORDER SELF-TEST

Before candidate validation, record:

```text
successful external command
expected nonzero command
preflight refusal/not launched
zero-byte stdout
zero-byte stderr
JUnit not applicable
```

Stop if incomplete.

AUTHORITATIVE SOURCE PROVENANCE MODEL

Use one deterministic fingerprint implementation for every source pre/post
comparison.

Authoritative equality fields:

```text
physical root
current branch
HEAD/tree/parents/subject
upstream name/OID
ahead/behind
worktree inventory excluding app-internal metadata
porcelain v2 exact bytes/SHA-256
tracked binary diff exact bytes/SHA-256
cached binary diff exact bytes/SHA-256
logical index:
  git ls-files --stage -z exact bytes/SHA-256
candidate canonical manifest exact bytes/SHA-256
candidate per-path identities
outside-candidate equality to HEAD
authoritative refs:
  HEAD symbolic target
  refs/heads/codex/rw0-b2-capability-semantics-v1
  refs/heads/trunk_dev when present
  refs/remotes/origin/trunk_dev
  configured upstream
authoritative reachable object graph:
  sorted OID/type/size inventory reachable from authoritative refs
operation/lock inventory
repository residue inventory
```

Use `GIT_OPTIONAL_LOCKS=0` where supported.

Ambient/report-only fields:

```text
refs/codex/turn-diffs/**
reflogs
packed/loose storage representation
unreachable loose-object paths
object-file atime/mtime/ctime/birthtime/inode/device/link count/flags/xattrs
raw .git/index bytes/stat-cache metadata
directory st_size
```

Ambient changes do not fail authoritative provenance when authoritative fields
remain exact.

OPENING GATE

Record each sub-action separately:

1. exact repository identity/topology;
2. no operation/lock/residue;
3. all indexed historical evidence roots;
4. G6/G7 quarantine boundaries and opening projections;
5. live candidate against G5 final manifest;
6. sole changed path and other twenty-nine equality;
7. every path outside candidate equals HEAD;
8. exact recipe source;
9. root-local recipe-copy preflight;
10. opening recipe run 1;
11. opening recipe run 2;
12. both manifests equal G5 final manifest;
13. both complete outputs equal G5 final output;
14. opening/final retained node lists and exact hashes;
15. exact mutation/projection ledgers;
16. exact path-safety grammar.

PATH SAFETY

Before any pytest or external repository path is created:

1. recover the exact owning checker;
2. enumerate every child-visible path;
3. pass each through the exact checker;
4. retain complete result ledger;
5. stop before launch if any fails.

Use short neutral children.

VALIDATION ENVIRONMENT

For every pytest child:

```text
umask 022
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct neutral external PYTHONPYCACHEPREFIX
distinct neutral external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct neutral external --basetemp
distinct neutral external --junitxml
serial execution
```

FINAL CAUSAL REPLAY

Recover exact sealed mutation/control specifications from indexed G5 records.

Replay individually:

```text
every canonical control
every closed reachable-call mutant
every module-global identity/type mutant
every 43-row projection inventory/uniqueness control
every protected-content row mutant
exact prior-audit survivor and kill control
every stable-contract mutant
```

For each retain:

```text
case ID
source/generator path
source bytes/SHA-256
purpose
expected outcome/diagnostic
actual outcome/diagnostic
pre/post authoritative source fingerprint
attempt envelope
```

Every mutation and its restoration are separate attempts.

Expected mutant rejection is creditable.

Require unique source bytes and purpose unless explicitly justified.

FINAL FOCUSED GROUPS

Recover exact argv from indexed G5 records and rerun:

```text
selected causal:
16 passed

Capability boundaries:
32 passed

Capability complete:
69 passed

B1/Wire compatibility:
461 passed

architecture/status/static:
907 passed
```

Stop if exact indexed argv does not support those counts.

A/B/C STATE REPLAY

## State A

Live accepted unstaged source repository.

## State B

Fully external independent Git repository/object database:

- initialize independently;
- populate accepted base without alternates/hardlinks;
- overlay exact final 30-file candidate;
- stage exactly candidate;
- do not commit;
- run target and projection.

## State C

Same external repository:

- create one diagnostic local commit;
- require tree:
  `0fcf6680ded68d66f62b75b5dc842d69b343a334`;
- require clean status;
- run target and projection.

Require:

```text
target passes A/B/C
projection A == B == C
B staged tree == C committed tree
source authoritative fingerprint unchanged
external object database isolated
```

Every setup, run, mutation, and restoration has its own envelope.

NODE COLLECTION

Run live and clean external final collection.

Require both:

```text
5072 unique nodes
exact full ordered SHA-256 recovered from indexed G5 final list
byte-identical node lists
```

Compare:

```text
repair opening:
5057

final:
5072

additions:
15

removals:
0

renames:
0

all additions:
authorized test file only

outside-file order:
unchanged
```

LIVE FULL SUITE

Run exactly once after focused validation is green.

Require:

```text
5072 collected
5072 passed
0 failures/errors/skips/xfails/warnings
empty stderr
exact JUnit/node mapping
authoritative source pre == post
candidate-mutated false
```

CLEAN FULL SUITE

Run exactly once in the fully external clean committed State-C repository.

Require:

```text
5072 collected
5072 passed
0 failures/errors/skips/xfails/warnings
empty stderr
exact JUnit/node mapping
source authoritative pre == post
external normalized pre == post
clean tree unchanged
candidate-mutated false
```

No retry is authorized.

FINAL GUARDS

After suites, record separately:

1. source identity/topology/manifest;
2. authoritative source fingerprint equality to opening;
3. ambient source metadata delta report;
4. indexed historical roots against canonical opening projections;
5. G6/G7 retained projections and quarantine inventories;
6. final node identities;
7. mutation ledgers and attempt-manifest arithmetic;
8. no hidden command without envelope;
9. no operation/lock/residue.

A directory-size difference, atime change, app-managed ref change, raw index
stat-cache change, or object timestamp change must not fail the guard when
canonical content and authoritative fields remain exact.

CLEANUP

Remove only G8-created transient:

```text
basetemps
pytest caches
pycache roots
TMPDIR contents
external repository
temporary object copies
```

Before removal retain complete external repository and validation records.

Record each cleanup action or one complete enumerated cleanup ledger through the
recorder.

Run post-cleanup guards through the recorder.

FINAL PROVENANCE

After cleanup:

1. verify root-local recipe copy;
2. run final recipe 1;
3. run final recipe 2;
4. require both manifests equal indexed G5 final manifest;
5. require complete outputs equal indexed G5 final output;
6. require empty stderr and unchanged authoritative source fingerprint.

FINAL REPORT

Generate before index creation and print its complete substance inline in the
Codex response.

Include:

1. opening identity;
2. G5/G6/G7 historical classification;
3. all pre-existing evidence indexes;
4. bootstrap and recorder self-test;
5. restore-harness specification/static audit/tooling self-tests;
6. complete all-attempt chronology;
7. canonical evidence-root comparison schema;
8. G6/G7 quarantine proof;
9. normalized authoritative Git provenance schema;
10. ambient Git observations;
11. opening gate;
12. causal replay and every restoration;
13. focused groups;
14. A/B/C replay;
15. live/clean collections;
16. node reconciliation;
17. live/clean suites;
18. run-local fingerprints;
19. final guards;
20. cleanup;
21. final provenance;
22. exact final manifest JSON;
23. protected/public/authority non-widening;
24. remaining C/D/E/ES seams;
25. separate provenance, validation-binding, and implementation confidence.

Explicitly state:

```text
historical G5 partial metadata was not reconstructed
G5 remains implementation evidence
G6 and G7 remain failed replay evidence
G8 is the authoritative complete validation and closeout envelope
app-managed refs and storage timestamps are report-only
raw external index stat-cache changes are report-only when the logical index
and normalized authoritative fingerprint are exact
```

TERMINAL INDEX CREATION

No root mutation is allowed after the self-excluding index is created.

To avoid self-recording paradox:

1. finalize and retain every ordinary attempt envelope and
   `attempt_manifest.jsonl` before index creation;

2. retain inside G8:
   - the exact index-builder source;
   - its immutable configuration;
   - the exact external-verifier source;
   - a `terminal_actions_plan.json` describing the two terminal actions;

3. generate the final report through the recorder;

4. generate and seal a pre-index inventory through the recorder;

5. invoke the index builder as a terminal external action:
   - it writes the self-excluding canonical JSONL index as the final G8
     mutation;
   - it writes its own stdout/stderr/return/result only to an external sibling
     record outside G8;

6. invoke the external verifier:
   - reads G8 only;
   - writes its result only to another external sibling record;
   - confirms index exclusion, every row, no unindexed entry, no unsafe entry,
     attempt-manifest/envelope reconciliation, and mandatory-record presence;

7. do not mutate G8 after index creation.

The inline Codex response must report:

```text
index path
row count
byte size
SHA-256
index-builder external result identity
external-verifier result identity
```

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only when:

- candidate bytes remain unchanged;
- restore harness passes all self-tests;
- all causal/focused groups pass;
- A/B/C passes;
- live/clean collections are exact;
- live/clean suites pass 5072/5072;
- every ordinary action has an envelope;
- terminal index actions are externally recorded;
- canonical historical-evidence closeout passes;
- normalized authoritative source provenance passes;
- final report and self-excluding index are complete.

FAILURE TOKENS

Use one precise primary token:

```text
V3_REPLAY_PROVENANCE_MISMATCH
V3_REPLAY_INPUT_INCOMPLETE
V3_REPLAY_RECORDER_FAILED
V3_REPLAY_RESTORE_HARNESS_FAILED
V3_REPLAY_HISTORICAL_BOUNDARY_FAILED
V3_REPLAY_CAUSAL_FAILED
V3_REPLAY_FOCUSED_FAILED
V3_REPLAY_STATE_MATRIX_FAILED
V3_REPLAY_NODE_COLLECTION_FAILED
V3_REPLAY_LIVE_SUITE_FAILED
V3_REPLAY_CLEAN_SUITE_FAILED
V3_REPLAY_AUTHORITATIVE_SOURCE_DRIFT
V3_REPLAY_EVIDENCE_CONTENT_DRIFT
V3_REPLAY_PROVENANCE_FAILED
V3_REPLAY_EVIDENCE_SEAL_FAILED
```

For any failure, print the complete operative diagnosis inline. File links are
supplementary only.

Do not modify repository bytes in any failure case.

FINAL REQUIRED STATEMENTS

```text
REPOSITORY_MUTATION_NOT_PERFORMED
IMPLEMENTATION_NOT_RERUN
HISTORICAL_METADATA_NOT_RECONSTRUCTED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
