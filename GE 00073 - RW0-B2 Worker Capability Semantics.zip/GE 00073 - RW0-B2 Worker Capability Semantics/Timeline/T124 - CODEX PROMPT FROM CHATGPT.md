PROMPT_ID

RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_REAUDIT_PROVENANCE_MISMATCH_DIAGNOSTIC_V1

TITLE

Coordinator RW0-B2-Capability — diagnose AUDIT_PROVENANCE_MISMATCH in the
commit-compatibility repair re-audit before any correctness or validation work

ENGAGEMENT TYPE

Continuation in the same fresh, read-only independent-audit conversation that
returned only:

```text
AUDIT_PROVENANCE_MISMATCH
```

This is a provenance-only diagnostic.

Do not inspect implementation or test correctness beyond what is strictly
necessary to classify the provenance failure. Do not launch audit subagents.
Do not run pytest, node collection, mutation probes, full suites, Git staging,
or external clean-commit simulations.

Do not mutate, format, clean, chmod, stage, commit, push, create a PR, merge,
tag, release, deploy, contact a remote/service/provider/host, invoke a product
worker/model, mutate a database, install dependencies, inspect a supporting
repository, or alter any retained evidence root.

Audit-created diagnostic records may be written only beneath the audit root
that this same conversation already created, or one new external
operator-owned, non-symlink, mode-0700 diagnostic root if the original audit
root cannot safely accept another record. Do not change candidate or retained
evidence bytes.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Explain exactly why the opening provenance gate returned
`AUDIT_PROVENANCE_MISMATCH`.

Identify:

1. the first failed predicate in execution order;
2. every consequentially withheld or failed predicate;
3. the exact expected and observed values;
4. whether the mismatch belongs to:
   - live candidate bytes;
   - retained final evidence;
   - retained opening evidence;
   - recipe source or replay;
   - node or validation evidence;
   - audit wrapper behavior;
   - audit prompt expectations;
   - stale report metadata.

Do not return only the mismatch token again.

EXPECTED LIVE REPOSITORY IDENTITY

The audit prompt required:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644
```

Also required:

```text
git diff --check:
clean

cached diff:
empty

Git operation or lock:
none

repository residue:
none

thirty-first changed path:
absent
```

FINAL REPAIR EVIDENCE TARGET

Final repair evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe
```

Final report:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe/final_report.md
```

Self-excluding index:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe/evidence_index.jsonl
```

Expected index identity:

```text
rows excluding itself:
938

size:
151566 bytes

SHA-256:
bdffdfd9757302a7940b803f0d5138fdf9f9b41e53d95fcae3209b0e35dae71d
```

Expected reported candidate identities:

```text
canonical-manifest SHA-256:
0919e82038367f54defd36171a19550873f38acae714bd7398e5a56b2fb8d77a

final pytest node count:
5057

final ordered-node-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

live full suite:
5057 collected
5057 passed

clean-commit full suite:
5057 collected
5057 passed

State-B/State-C candidate tree:
52e32a55dc2e6b023b669810fb244301807f7618

dirty topology:
30/24/6/0/0

source real index:
unchanged and unstaged
```

The audit prompt required the indexed final evidence—not inference—to provide:

```text
final canonical-manifest path and byte size
final tracked textual-diff SHA-256
complete recipe-output path, size, and SHA-256
exact final canonical manifest JSON
final path identity for test_rw0_b2_capability_boundaries.py
exact one-path opening-to-final delta
opening and final node lists
three-state target records and tree identities
43-row stable projection identity
five no-status-dependency mutant records
eight stable-contract mutant records
live full-suite summary/stdout/stderr/JUnit/fingerprint
clean-commit full-suite summary/stdout/stderr/JUnit/tree/fingerprint
final guards
cleanup record
```

OPENING REPAIR TARGET

The audit prompt pinned the repair opening target to:

```text
accepted canonical-manifest SHA-256:
9efb739e958cf077dafad99d5dc62af3fdcbd847c359916fd22fb5c125b79472

opening pytest node count:
5057

opening ordered-node-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe
```

Accepted audit root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-independent-audit.T0I7mV
```

Accepted audit index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-independent-audit.T0I7mV/evidence_index.jsonl

rows excluding itself:
110

size:
23050 bytes

SHA-256:
e09add54af9a8d6e48969fd06a0c0e57bc2bf9125229f1f811c6781303c2cb54
```

Exactly one repository path was expected to differ from the opening target:

```text
tests/test_rw0_b2_capability_boundaries.py
```

The other 29 candidate entries were expected to remain byte-, kind-, type-,
mode-, size-, and classification-identical.

OTHER REQUIRED EVIDENCE ROOTS

The audit prompt also required verification and preservation of:

```text
failed commit gate:
/private/tmp/ge-coordinator-rw0-b2-capability-commit-gate.ECxUPx
index SHA-256:
a944cf428eb753b568864e313402088d40474d764a280d8a4bc88ca65ca13dc5

three-state diagnostic:
/private/tmp/ge-coordinator-rw0-b2-capability-commit-state-diagnostic.2SxEgB
index SHA-256:
54c0c7fadf3f44b10f6ec59c056c2f800abdf9d0c4baac911c48732dd5f9f2cb

accepted owner-oracle audit:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-independent-audit.T0I7mV
index SHA-256:
e09add54af9a8d6e48969fd06a0c0e57bc2bf9125229f1f811c6781303c2cb54

accepted final-repair evidence:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit-findings-repair.nJmVEI
index SHA-256:
22439f6586f7c2f7c67ba17fe25147f92d0016afba3140b7b5e3e96b51a710e4
```

EXACT RECIPE SOURCE EXPECTATION

The audit prompt required the recipe source to be located through indexed final
evidence and to satisfy:

```text
type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

The audit prompt did not embed or base64-encode the recipe.

MANDATORY DIAGNOSTIC PROCEDURE

Do not restart the correctness audit.

Report whether each gate item independently matched.

For every item use exactly one status:

```text
MATCH
MISMATCH
WITHHELD_AFTER_EARLIER_FAILURE
NOT_REACHED
UNSUPPORTED_BY_RETAINED_EVIDENCE
```

## A. Live repository

Report:

```text
root
branch
HEAD
tree
parent
subject
upstream
ahead/behind
worktree count
30/24/6/0/0 topology
candidate types/modes
staged/unmerged state
git diff --check
cached diff
operation/lock/residue
```

## B. Final repair evidence index

Report:

```text
path-component lstat safety
index path/type/mode
row count
byte size
SHA-256
self-exclusion
per-entry verification
opening/closing inventory status
```

## C. Final canonical manifest

Report:

```text
exact path
whether indexed
type/mode
byte size
SHA-256
canonical JSON
branch/HEAD/upstream fields
file count
per-entry path/kind/type/mode/size/SHA-256 verification
live tree equality
```

## D. Exact one-path delta

Compare final manifest with the accepted opening target.

Report:

```text
changed path set
expected sole changed path
other 29 entries equality
newly dirty/clean paths
classification/mode/symlink drift
```

## E. Recipe source and execution

Report:

```text
recipe path
whether indexed
type/mode/size/SHA-256
wrapper path and identity
whether execution launched
run-1 return/stdout/stderr/manifest identity
run-2 return/stdout/stderr/manifest identity
retained-manifest equality
complete-output equality
tracked textual-diff equality
```

If execution was withheld, identify the exact prior failed predicate that
caused withholding.

## F. Node evidence

Report:

```text
opening node-list path/count/hash
final node-list path/count/hash
whether indexed
whether candidate collection was independently run
candidate collection count/hash
opening-to-final additions/removals/renames
```

## G. Three-state evidence

Report separately for States A, B, and C:

```text
record paths
whether indexed
document/candidate identity
Git-status shape
target result
projection identity
tree identity
source real-index invariance
```

Report whether State B and State C tree both equal:

```text
52e32a55dc2e6b023b669810fb244301807f7618
```

## H. Projection and mutant evidence

Report:

```text
43-row projection record path/identity
five no-status mutant records
eight stable-contract mutant records
whether each is indexed
whether every result is explicit rather than inferred
whether any corpus contains duplicate bytes or duplicate purpose
```

## I. Live full-suite evidence

Report:

```text
summary path
stdout/stderr paths and identities
JUnit path/size/SHA-256
node-list path/hash
before/after fingerprint
collected/passed/counts
attempt count
whether indexed
```

## J. Clean-commit full-suite evidence

Report:

```text
external repository/tree/commit metadata
clean status evidence
summary path
stdout/stderr identities
JUnit path/size/SHA-256
node-list path/hash
before/after tree/fingerprint
collected/passed/counts
attempt count
whether indexed
```

## K. Final guards and cleanup

Report:

```text
guard record path
cleanup record path
status/topology/mode/protected/public/import/authority results
residue result
real-index invariance
whether indexed
```

## L. Other evidence roots

Report exact index verification for all four required prior roots.

FAILED PREDICATE REPORTING

For the first failed predicate and every additional mismatch, report:

```text
gate item
execution order
exact path
expected value
observed value
source of expected value:
  audit prompt | retained report | retained index | retained record
source of observed value:
  live Git | live filesystem | retained evidence | audit wrapper
candidate-byte impact:
  none | changed
validation-binding impact:
  none | partial | invalid
read-only reconcilable:
  yes | no
```

EXPLICIT QUESTIONS

Answer every question:

1. What was the exact first failed predicate?

2. Did live candidate bytes differ from the final retained manifest?

3. Did the final evidence index itself differ from its expected hash, row count,
   or size?

4. Was the final canonical manifest missing, unindexed, or hash-mismatched?

5. Was the opening accepted manifest unavailable or mismatched?

6. Was the exact recipe source missing or mismatched?

7. Did fresh recipe execution fail, or was it withheld?

8. Was the one-path delta wrong?

9. Was the final node list missing or mismatched?

10. Was one of the three-state records missing or inconsistent?

11. Did the State-B/State-C tree differ from
    `52e32a55dc2e6b023b669810fb244301807f7618`?

12. Was the 43-row projection or a mutant record absent/unindexed?

13. Was live or clean full-suite evidence missing, unindexed, or mismatched?

14. Did an evidence path contain a symlink, special file, unsafe mode, or
    ownership mismatch?

15. Did the audit prompt require a field that the final report never claimed to
    retain?

16. Did the audit wrapper introduce the mismatch?

17. Are current bytes still bound to the reported live and clean suite results?

PRIMARY CLASSIFICATION

Return exactly one primary token.

### PROVENANCE_BASELINE_READY

Use only when:

- live bytes equal the retained final manifest;
- recipe source and repeated output are stable;
- all mandatory evidence is present and valid;
- the mismatch came only from an audit-prompt expectation, report metadata, or
  wrapper issue that can be corrected read-only.

Provide one exact corrected continuation target for the same audit
conversation.

### IMPLEMENTATION_REPORT_STALE_BYTES

Use when live bytes differ from the retained final manifest. List every changed
entry.

### FINAL_EVIDENCE_TARGET_MISMATCH

Use when live bytes may be stable but the retained final evidence root/index or
manifest does not match the claimed final target.

### MANDATORY_EVIDENCE_UNAVAILABLE

Use when required validation/projection/mutant/full-suite evidence is absent and
cannot be derived read-only.

### AUDIT_WRAPPER_REPAIR_REQUIRED

Use when the audit wrapper or safe redirection caused the mismatch while
candidate and retained evidence are sound.

### AUDIT_PROMPT_EXPECTATION_DEFECT

Use when the prompt demanded an identity, path, count, or record not actually
part of the retained implementation contract, while candidate and evidence are
otherwise sound.

### PROVENANCE_RECIPE_FAILURE

Use when the exact retained recipe source or repeated canonical output is
genuinely unstable or mismatched.

### OPENING_TARGET_MISMATCH

Use when the accepted pre-repair manifest or one-path delta cannot be
reproduced.

### DIAGNOSTIC_INCOMPLETE

Use only when the first failed predicate cannot be identified safely.

DISPOSITION

After the primary token, state exactly where the next action belongs:

```text
same read-only audit conversation
write-enabled implementation conversation for evidence-only regeneration
write-enabled implementation conversation with validation reruns
new implementation repair
new independent audit after re-baselining
```

Do not authorize repository mutation in this diagnostic.

CLOSEOUT

Verify the diagnostic itself did not change:

- repository bytes;
- real index;
- refs;
- retained evidence roots.

Retain a small diagnostic record and self-excluding evidence index if the audit
root permits it without altering pre-indexed evidence. Otherwise use a new
diagnostic root.

FINAL RESPONSE

Include:

1. primary classification token;
2. exact first failed predicate;
3. expected-versus-observed table;
4. status of A–L;
5. candidate-byte status;
6. validation-binding status;
7. exact corrected target or minimum evidence continuation;
8. next conversation/action boundary;
9. provenance, validation-binding, and implementation-assessment confidence.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REAL_INDEX_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
NODE_COLLECTION_NOT_RUN
CORRECTNESS_AUDIT_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
```
