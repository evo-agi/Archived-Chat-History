## Engineering disposition

**Accept the negative audit verdict and return the candidate to the existing workspace-write conversation. Do not stage or commit.**

I would not reopen the B2-Wire schema freeze. The audit found no defect in:

- the fixed Wire profile or byte caps;
- request/response source ownership;
- authority and privacy boundaries;
- C2A relation composition;
- package/public/dependency/schema/migration boundaries;
- the Capability seam.

The remaining findings are repairable implementation and test defects. Although Codex used `REJECT`, the engineering consequence is a **bounded patch block**, not a rejection of the Wire architecture.

This outcome matches the risk forecast recorded before implementation: decoder traversal, preconstruction and alias work, noncausal mutants, and process-fact collapse were explicitly identified as likely audit failure classes. 

## Frozen repair decisions

### 1. Replace bulk sibling enqueue with bounded iterator frames

The current `_shape_work()` detects over-cap content but still pushes every child into its pending stack. That violates the promised bounded traversal even though the payload-byte cap limits total damage.

The repair should separate two concerns:

**During JSON parsing**, a private accounting object records:

- every raw object pair, including duplicates;
- whether any duplicate exists;
- the bounded pair count and key-shape facts.

The `object_pairs_hook` records but does not raise. Consequently, a later syntax error still wins as `json_token_invalid`; after successful syntax, `duplicate_key` retains precedence over structural errors.

**During shape validation**, use iterator/descent frames containing only:

- the current container;
- its iterator or index;
- current depth;
- bounded per-object key state;
- an output builder only while the tree remains structurally valid.

No child-list `extend` or equivalent bulk enqueue is permitted. On structural overflow, stop building the output, remember `invalid_root_or_scalar`, and avoid descending further. Duplicate precedence is already known from parse accounting.

A 5,000-sibling payload beneath the byte cap must keep pending traversal state proportional to nesting depth—not sibling count.

### 2. Add a Wire-owned safe C2A extraction seam

The most important remaining availability defect is calling a tampered C2A object’s generic `to_mapping()` before Wire has validated its internal shape. C2A’s generic recursive externalization can amplify shared tuple DAGs or cycles before eventually failing.

Do **not** change C2A. Instead, Wire should implement literal class-specific extraction for exactly:

```text
CeilingsV1
AttemptFenceV1
EffectFenceV1
WorkerCommandV1
DeliveryEnvelopeV1
WorkerObservationV1
```

For each class:

- require the exact class, never a subclass;
- require every expected slot;
- pin the field inventory against the committed C2A `_FIELDS`;
- read slots directly;
- accept only the exact built-in types and bounded tuple cardinalities that the field permits;
- allow only the fixed nested `CeilingsV1` relation where applicable;
- manually construct a fresh bounded mapping;
- call the owning C2A `from_mapping` and relations only after this extraction succeeds.

No caller-supplied `to_mapping()`, C2A `_external_value()`, arbitrary iterator, mapping, nested tuple DAG, or cycle may run before rejection.

This is an internal defensive seam. It creates no new profile field, schema, authority fact, or public API.

### 3. Reconstruct every classifier fact before duplicate analysis

The classifier currently reads raw ref/digest slots before reconstructing the supplied facts. That permits malformed shells or tampered values to influence the chosen reason.

Freeze the order as:

```text
exact type/cardinality preflight
→ reconstruct and validate every fact
→ duplicate/conflict checks
→ lineage and cancellation semantics
→ process/result precedence
```

Original Python object identities may be recorded before reconstruction, but may not affect the result until every fact is valid.

After reconstruction:

```text
same original object
same safe ref
same safe digest
    → duplicate_fact

distinct valid facts in one singleton slot
    → conflicting_fact
```

Any partial, incomplete, tampered, wrong-digest, or relation-invalid fact must produce:

```text
invalid / invalid_input
```

even when paired with a colliding valid fact.

The existing frozen cancellation precedence remains unchanged. Pure request/response graph mismatches still return `cancellation_graph_mismatch`; they do not override an earlier valid duplicate, conflict, or unrelated non-cancellation condition.

### 4. Complete the causal test surface

The new tests must cover:

- bounded pending-frame depth on the 5,000-sibling counterexample;
- raw-pair accounting and syntax-over-duplicate precedence;
- shared DAGs at depths 8, 12, and 16;
- self-referential or recursively tampered `CeilingsV1`;
- proof that hostile inputs are rejected before C2A `to_mapping()` or `_external_value()`;
- malformed fact alone, repeated, and colliding with a valid fact;
- valid same-object/ref/digest duplicates;
- distinct singleton conflicts;
- incomplete self-digest values through:
  - `to_mapping()`;
  - `identity_mapping()`;
  - `canonical_identity_bytes()`;
  - `computed_digest()`;
- every public encoder, relation, and classifier boundary.

New test nodes remain confined to the four Wire test files.

## Scope

The repair may change only:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

The other ten candidate entries must remain byte-identical.

These identities remain frozen:

```text
profile_ref:
rw0-wire-nwpf-v1

profile bytes:
4,021

profile digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454

command payload/frame:
5,898 / 5,906

result payload/frame:
16,627 / 16,635

hostile work:
23,746 / 66,770

source key maximum:
37

frame key maximum:
29
```

Any need to alter those values, C2A/B1 bytes, public surfaces, source ownership, classifications, reasons, or precedence is a stop condition.

## Next action

Send this complete prompt to the **existing workspace-write RW0-B2-Wire implementation conversation**:

:chatgpt-content-reference{index="3"}

Verify the attachment:

```text
Filename:
Coordinator_RW0_B2_Wire_Second_Audit_Repair_Prompt.txt

Size:
28,353 bytes

SHA-256:
4299e763520d4c734a6c4b7a6cc53bb201387f277f118c406bb2a81c59018343
```

The required successful result is:

```text
COORDINATOR_RW0_B2_WIRE_SECOND_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

After that result, use another **fresh read-only audit conversation**. Do not proceed directly to staging. The project protocol requires audit repairs to return to the sole writer, followed by a new independent audit of the changed bytes.  Only an accepted audit permits regeneration of the authoritative manifest, exact staging, staged-blob validation, and the one-commit gate. 

### Sources

- Codex second independent re-audit report supplied in this turn.
- Original B2 forecast of decoder, alias-work, causal-test, and process-fact risks. 
- Governed Execution repair and fresh-audit lifecycle. 
- Provenance-bound audit and commit lifecycle. 

**Confidence:** High that the three behavioral defects are real; high that they can be closed inside the six-path repair boundary without changing the Wire protocol; moderate-to-high that literal C2A safe extraction will eliminate the alias/cycle defect without exposing another committed C2A shape mismatch.
