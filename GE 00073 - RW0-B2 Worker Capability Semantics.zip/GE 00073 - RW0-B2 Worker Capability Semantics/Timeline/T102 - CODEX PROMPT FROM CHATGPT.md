PROMPT_ID

RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_AUDIT_FINDINGS_REPAIR_V1

TITLE

Coordinator RW0-B2-Capability — bounded repair of B1 parser consistency,
bounded H2 location, RW0 fence-test causality, and explicit rename evidence

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing Capability implementation
conversation.

Do not create subagents. The parent is the sole repository writer.

This is a tests-and-evidence repair. It is not reconnaissance, registry design,
production implementation, documentation editing, independent audit, staging,
commit, push, PR, merge, release, deployment, runtime proof, provider
integration, or supporting-repository work.

Only the exact two repository test paths below may change. Evidence artifacts
must be written only beneath one new external mode-0700 repair root.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Repair exactly four Medium findings from the fresh independent audit of the
owner-oracle reset:

```text
B1-PARSER-001
  The cross-document B1 parser computes visibility but locates the first H2
  from raw lines, while the primary B1 parser locates from visible lines.

B1-LOCATION-002
  B1 first-live-H2 detection recognizes only raw `## ` and misses valid ATX H2
  forms with 1–3 leading ASCII spaces or a tab delimiter.

RW0-TEST-003
  The declared RW0 fence cases are non-causal: replacing registry visibility
  with an all-visible stub leaves all outcomes unchanged.

EVID-RENAME-004
  The sole rename record in the external migration ledger omits `new_node_id`,
  so the one-to-one target is inferred rather than frozen.
```

Preserve the accepted registry architecture, exact document bytes, production
source, authority split, node migration design, and every non-finding behavior.

OPENING REPOSITORY IDENTITY

Before any edit require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644
```

Require:

- `git diff --check` clean;
- no Git operation or lock;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, or recorder residue.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

OPENING CANDIDATE TARGET

Implementation evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB
```

Retained final canonical manifest:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB/final_recipe_1/manifest.json
```

Required identities:

```text
canonical-manifest size:
6430 bytes

canonical-manifest SHA-256:
47ec8ecbd89aaa0924dc3d222f2292b9046d0faaabfadd4850411473aa33f51c

complete recipe output size:
6663 bytes

complete recipe-output SHA-256:
3777b40b27cc2e13513eb08c02d77064feea6263cfc56691517531cd0d4b39b7

tracked textual-diff SHA-256:
614568d397cf4eee772a25d588e31008731b326d7ac04988084018fcfc4da9aa

file count:
30

opening pytest node count:
5002

opening ordered-node-list SHA-256:
11b13eebe8ff9631071da1f83a85d342b83ea4754a2c3765c0c227bf18f97a49
```

Exact recipe source:

Locate through the implementation evidence index and require:

```text
type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

LATEST INDEPENDENT AUDIT

Audit root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3
```

Full report:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3/audit_report.md
```

Self-excluding evidence index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3/evidence_index.jsonl
```

Required index:

```text
71 rows excluding itself

SHA-256:
26b69c39d083cd2096c8e2b47c6afbef7626d24cbd55093fcabe659be23a06bb
```

Read and preserve the complete finding evidence before mutation, including:

```text
B1-PARSER-001
B1-LOCATION-002
RW0-TEST-003
EVID-RENAME-004
B1-HYGIENE-OBS
```

The audit accepted:

- exact B1 registry bytes, values, roles, sources, and ownership;
- exact RW0 seven-row registry and ownership;
- one-way B1 projection from RW0;
- the prose-authority policy;
- production/public/privacy/authority boundaries;
- all 227 mutant documents and their uniqueness;
- the broad node-migration arithmetic except the explicit rename target;
- retained focused and full-suite implementation evidence.

BEFORE MUTATION

Create one new operator-owned, non-symlink, mode-0700 external repair evidence
root under `/private/tmp`.

Then:

1. safely `lstat` retained evidence paths and verify both evidence indexes;

2. reproduce the opening candidate manifest twice using the exact retained
   recipe and safe redirection of only its external fixed output sink;

3. require both manifests and complete outputs to match the opening target
   byte-for-byte;

4. verify every manifest entry by path, kind, type, mode, size, and SHA-256;

5. verify every path outside the 30-path candidate equals HEAD;

6. collect the exact 5,002 opening nodes once and require the expected ordered
   SHA-256;

7. safely load and verify:
   - the complete opening migration ledger;
   - opening node list;
   - final opening node list;
   - opening additions/removals/rename records;
   - opening 227-mutant ledger;

8. retain a complete opening candidate/evidence fingerprint.

Stop before mutation on any mismatch.

ACCEPTED CONTRACT — DO NOT REOPEN

Preserve exactly:

- both owner registries and every document byte;
- registry version 1;
- all registry rows, fields, roles, sources, values, order, markers, headings,
  and location;
- prose authority policy A;
- B1 authority rows and one-way RW0 projections;
- RW0 composition/status ownership;
- C2A, lineage, B1, Wire, Capability production semantics and public surfaces;
- all budgets, identities, canonical bytes, qualification precedence, and
  later-owner seams;
- no source authentication, executable permission, semantic acceptance,
  persistence, provider/runtime/Git/publication authority;
- the deliberate retirement of the failed NLP architecture;
- the opening migration ledger's classifications, except for adding explicit
  target evidence and reconciling newly added test nodes.

No source or documentation path may change.

TEST-FIRST CAUSAL GATE

Before repairing existing helpers, modify only the two authorized test files to
add test-owned controls for the four findings.

Run one selected red/control gate requiring:

1. primary B1 parser accepts an earlier visible H2 with:
   - one leading ASCII space;
   - two leading ASCII spaces;
   - three leading ASCII spaces;
   - a tab delimiter after `##`;
   and therefore fails the new first-live-H2 assertions;

2. primary B1 parser accepts an ordinary fenced/commented earlier H2 while the
   cross-document parser rejects it, proving grammar divergence;

3. every currently declared RW0 fence case produces the same result with the
   real visibility helper and an all-visible sensitivity stub, causing the new
   causal-sensitivity assertion to fail;

4. the opening migration ledger fails an external evidence assertion because
   its sole rename record lacks `new_node_id`;

5. existing canonical registry positives pass;

6. no syntax, import, collection, fixture, path, production, documentation, or
   unrelated failure receives causal credit.

Retain exact argv, environment, umask, stdout/stderr, JUnit, node IDs,
before/after candidate fingerprints, and the evidence-only rename checker.

REPAIR A — ONE CANONICAL B1 PARSER PATH

Authorized repository paths:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Engineering decision:

- `tests/test_rw0_b1_boundaries.py` owns the canonical test-local B1 registry
  parser.
- The cross-document projection test must reuse that parser rather than
  maintain a second location/visibility implementation.
- No new shared helper file is authorized.
- No production helper is authorized.

Preferred implementation:

1. retain or expose one private test helper in
   `test_rw0_b1_boundaries.py` that:
   - parses the complete B1 registry;
   - returns its exact canonical projection;
   - uses the canonical visibility and location logic;
   - raises only the existing finite `b1.registry.*` diagnostics;

2. in `test_rw0_remote_contact_phase_entry_contract.py`, remove the duplicate
   `_parse_b1_registry_for_projection` grammar implementation and import/reuse
   the canonical B1 parser through an ordinary deterministic test-module
   import;

3. avoid dynamic import, filesystem execution, source parsing, or a copied
   fallback implementation;

4. prove there is no circular import, duplicate collection, order-sensitive
   module initialization, or public/package surface effect.

If an ordinary deterministic test-module import cannot work under every
required focused and full-suite invocation without changing infrastructure,
stop and report that the two-file ceiling is insufficient. Do not reintroduce
a duplicate parser silently.

The cross-document test may adapt the canonical projection into its local
comparison shape, but it must not reparse B1 Markdown.

REPAIR B — BOUNDED VISIBLE H2 LOCATION

In the canonical B1 parser, define one finite raw-source recognizer for an ATX
H2 used only for location:

```text
0 through 3 leading ASCII spaces
exactly two `#` characters
the next character is ASCII space, ASCII tab, or end-of-line
a third `#` without a delimiter is not H2
four leading spaces is not H2
NBSP or other Unicode whitespace is not the delimiter
```

A source-equivalent regular expression is:

```text
^[ ]{0,3}##(?:[ \t]|$)
```

provided it is applied to the raw LF-split line and does not use Unicode
whitespace semantics.

Location algorithm:

1. compute registry visibility first;
2. inspect only visible lines;
3. find every visible bounded H2;
4. require the registry heading to be the first visible H2;
5. require it immediately precede the exact `## Closed value grammar` H2 under
   the existing registry block-location contract.

Add causal cases:

Accepted controls:

```text
four-space-indented `## literal` before the registry
NBSP-delimited `## literal` before the registry
`### H3` before the registry
ordinary visible prose before the registry
ordinary fenced/commented H2 before the registry
```

Rejected controls:

```text
0-space earlier H2
1-space earlier H2
2-space earlier H2
3-space earlier H2
tab-delimited earlier H2
```

The ordinary fenced/commented H2 controls must pass through both:

```text
the primary B1 owner test
the cross-document B1 projection path
```

Add one direct parser-equivalence assertion proving both paths return the exact
same B1 canonical projection or the exact same finite diagnostic for a bounded
corpus of visibility/location mutations.

Because the cross path reuses the canonical parser, this equivalence assertion
must verify actual shared behavior and must not instantiate a second parser.

REPAIR C — CAUSAL RW0 FENCE TESTS

Authorized path:

```text
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Do not change the RW0 parser unless a new deterministic parser defect is
discovered. The audit found a test-adequacy defect, not a source/parser defect.

Replace or reposition the non-causal fence cases so registry visibility is the
only deciding predicate.

Use three distinct case families.

### C1. Valid closer before registry — registry visible

Insert:

```text
valid opener
decoy ordinary line(s)
candidate closer
canonical registry heading and block
```

The registry remains the first live H2.

Cover:

```text
backtick and tilde markers
opener run lengths 3, 4, 5
closer same length
closer longer length
0, 1, 2, 3 leading ASCII spaces on opener
0, 1, 2, 3 leading ASCII spaces on closer
ASCII space suffix on closer
ASCII tab suffix on closer
```

Expected real result: canonical projection success.

Sensitivity requirement:

- a test-local mutant that refuses the valid closer must make the same document
  fail `rw0.registry.visibility`;
- the checked case must kill that mutant.

### C2. Invalid/non-closing closer before registry — registry hidden

Insert:

```text
valid opener
decoy ordinary line(s)
candidate invalid closer
canonical registry heading and block
```

Cover:

```text
opposite marker
shorter closer
text suffix after closer run
NBSP suffix
EM SPACE suffix
four-space-indented closer
missing closer / unclosed fence
```

Expected real result: `rw0.registry.visibility`.

Sensitivity requirement:

- replacing visibility with an all-visible stub must make every case reach the
  canonical projection successfully;
- treating the candidate closer as valid must make the appropriate cases pass;
- the checked test must kill both sensitivity mutants for the intended reason.

### C3. Non-openers before registry — registry visible

Insert:

```text
candidate non-opener
canonical registry heading and block
```

Cover:

```text
backtick info containing a backtick
four-space-indented backtick opener
four-space-indented tilde opener
backtick run shorter than 3
tilde run shorter than 3
```

Expected real result: canonical projection success.

Sensitivity requirement:

- a deliberately overbroad test-local visibility mutant that treats the
  candidate as an opener must hide the registry and fail;
- the checked test must kill that mutant.

### C4. Exact mutation ledgers

For every fence case record:

```text
case ID
document SHA-256
expected real result
sensitivity mutant
expected mutated result
actual real result
actual mutated result
```

Require unique bytes and unique purpose.

No case may pass because of unrelated location, row shape, marker count, or
table-value failure. Mechanically demonstrate:

- with all lines forced visible, every hidden-registry case becomes otherwise
  canonical and passes;
- with the correct visibility result restored, only visibility distinguishes
  the outcome.

REPAIR D — EXPLICIT RENAME EVIDENCE

This repair is external evidence only. Do not add a repository file.

The existing sole intended rename is:

```text
old_node_id:
tests/test_rw0_b1_boundaries.py::test_owner_has_one_current_retrieval_maximum_and_one_current_consumer

new_node_id:
tests/test_rw0_b1_boundaries.py::test_b1_live_registry_projection
```

Generate a new complete migration ledger beneath the new repair evidence root.

For every record with disposition:

```text
rename to registry-purpose node
```

require fields:

```text
old_node_id
new_node_id
category
disposition
purpose
opening_present
final_present
```

Validation rules:

1. `old_node_id` occurs exactly once in the opening node list;
2. `old_node_id` is absent from the final node list;
3. `new_node_id` is absent from the opening node list;
4. `new_node_id` occurs exactly once in the final node list;
5. `new_node_id` occurs exactly once among additions;
6. exactly one rename record targets `new_node_id`;
7. no two rename records share either endpoint;
8. the explicit rename count remains exactly one unless newly added test nodes
   are intentionally renamed from an opening node;
9. every opening owner node still has exactly one migration record;
10. all ledger totals reconcile with the opening/final lists.

Do not modify or overwrite prior evidence roots. Retain the corrected ledger and
its reconciliation script in the new root, both mode 0400.

B1-HYGIENE OBSERVATION

The audit observed three unused constants in `test_rw0_b1_boundaries.py`.

Because that file is already in scope, either:

- use the constants in genuine canonical heading/location assertions; or
- remove them.

Do not create a node or assertion solely to silence the observation.

EXACT REPAIR ALLOWLIST

Only these two already-dirty repository paths may change:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The other 28 candidate entries must remain byte-identical.

No document or production source may change.

Final topology remains exactly:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
all regular mode 0644
```

Stop if a third repository path, documentation change, source change, or
thirty-first dirty path is required.

EXPLICITLY PROTECTED

Everything outside the two tests is protected, including:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md
all other .docs files

all production source
src/ge_nwp_coordinator/__init__.py
pyproject.toml

tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py

all SQL, migrations, schemas, catalogs
StateStore
WriterSession
package exports
dependency metadata
```

VALIDATION ENVIRONMENT

Use one new external operator-owned, non-symlink, mode-0700 repair evidence
root.

For every child:

```text
umask 022 before launch
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Retain exact argv, environment, Python identity, umask, timing, return code,
stdout/stderr, JUnit, structured counts, and before/after candidate
fingerprints.

FINAL VALIDATION ORDER

After final bytes are frozen:

1. selected causal nodes for:
   - B1 bounded H2 location;
   - B1 primary/cross parser equivalence;
   - RW0 fence case real/sensitivity pairs;
   - migration-ledger explicit rename validation;

2. B1 owner:
   ```text
   tests/test_rw0_b1_boundaries.py
   ```

3. RW0 owner:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   ```

4. B1 compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```

5. Capability/Wire compatibility:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```

6. architecture/status/static compatibility:
   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

7. final collection exactly once;

8. compare with:
   - opening 5,002 list;
   - original reset opening 5,114 list;
   - corrected complete migration ledger;

9. require:
   - all nodes outside the two modified tests retain exact relative order;
   - every opening owner node has one migration record;
   - explicit rename target validation succeeds;
   - no unlisted removal, rename, skip, xfail, or reparameterization;
   - additions belong only to the two modified files;

10. `git diff --check`;

11. exact path, mode, protected-byte, import, public, authority, operation,
    lock, and residue guards;

12. complete repository suite exactly once with ordinary quiet rendering.

Do not predeclare the final node count.

Every credited green run requires:

```text
return code 0
zero failures/errors/skips/xfails/warnings
empty stderr
parseable JUnit
zero duplicate/unmapped cases
matching caller/child umask
unchanged candidate fingerprint
```

FULL-SUITE POLICY

Run complete-suite attempt 001 once after focused validation is green.

If it fails:

- preserve all evidence;
- repair only a deterministic tests-only defect inside the two paths;
- rerun affected focused groups;
- run complete-suite attempt 002 exactly once.

Stop if:

- failure is outside scope;
- a third repository path is required;
- protected bytes must change;
- a third full-suite attempt would be required.

PROVENANCE CLOSEOUT

After validation and cleanup:

1. require exact topology `30/24/6/0/0`;

2. prove exactly the two authorized test entries changed from the opening
   manifest;

3. prove the other 28 entries remain byte-identical;

4. prove every path outside the 30-path candidate equals HEAD;

5. run the exact retained recipe twice with safe output-sink redirection;

6. require byte-identical final manifests and complete outputs;

7. retain:
   - exact recipe source;
   - final manifests and complete outputs;
   - per-path identities;
   - opening/final node lists;
   - corrected migration ledger;
   - explicit rename verification;
   - fence-case causal ledger;
   - red/green records;
   - full-suite evidence;
   - final guards;

8. create a self-excluding evidence index;

9. retain evidence files mode 0400 and directories mode 0700;

10. remove only repair-created transient artifacts;

11. verify the implementation and latest-audit evidence roots remain unchanged.

Do not stage, commit, push, create a PR, or perform an independent audit.

STOP CONDITIONS

Stop without further mutation if:

- opening identity or provenance differs;
- canonical B1 parser reuse requires a third repository path or dynamic import;
- primary and cross parser equivalence cannot be achieved within two files;
- any RW0 fence finding reveals a real parser defect requiring source/doc
  changes rather than test repair;
- a live registry/document contradiction is discovered;
- any production, document, schema, identity, budget, or authority change is
  required;
- the explicit rename target does not reconcile uniquely;
- a third repository path or thirty-first dirty path is required;
- node migration, validation, or provenance is unstable.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only when all four Medium findings are closed, focused and complete validation
are green, exact provenance is stable, and every stop condition is false.

FINAL REPORT

Include:

1. opening/final repository identity;
2. latest audit evidence verification;
3. exact opening target reproduction;
4. selected red/control evidence;
5. exact two-path delta and 28-path equality;
6. canonical B1 parser reuse design;
7. bounded visible H2 recognizer and causal cases;
8. primary/cross B1 parser equivalence results;
9. RW0 fence-case real and sensitivity-mutant ledger;
10. corrected migration ledger and explicit rename verification;
11. node comparison against 5,002 and 5,114 openings;
12. every validation attempt;
13. full-suite result and attempt number;
14. final manifest and aggregate identities;
15. evidence index and cleanup;
16. protected/public/authority non-widening;
17. remaining C/D/E/ES seams;
18. separate provenance, validation, and implementation confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
