PROMPT_ID

RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_TEST_REPAIR_V1

TITLE

Coordinator RW0-B2-Capability — make the permanent Capability boundary test
independent of transient Git dirty/staged/clean state

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing Capability implementation
conversation.

Do not create subagents. The parent is the sole repository writer.

This is a one-test-file commit-compatibility repair. It is not reconnaissance,
production implementation, documentation editing, registry redesign, staging,
commit, push, PR, merge, release, deployment, provider/runtime work, database
work, or supporting-repository work.

Only the exact repository path below may change.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Repair the permanent boundary test:

```text
tests/test_rw0_b2_capability_boundaries.py::test_exact_twenty_path_ceiling_modes_and_protected_controls
```

so it enforces only state-independent repository contract facts and remains
green in all three representations of the same accepted candidate tree:

```text
A. accepted unstaged candidate
B. exact candidate staged in an alternate external Git index
C. exact candidate committed and clean in an external local-only repository
```

The test must no longer require:

```text
six `??` untracked additions
twenty-four unstaged `M` modifications
any exact dirty-worktree topology
```

Patch-scope and transient candidate-delta enforcement belong to provenance,
independent audit, staging, and commit gates—not to a permanent repository test
that must remain green after commit.

Preserve every legitimate state-independent path, regular-file, mode, private
boundary, protected-control, import, export, caller, dependency, schema,
migration, and authority assertion currently owned by the test.

DIAGNOSTIC BASIS

The read-only three-state diagnostic returned:

```text
CANDIDATE_TEST_REPAIR_REQUIRED
```

Diagnostic evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-state-diagnostic.2SxEgB
```

Diagnostic report:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-state-diagnostic.2SxEgB/final_report.md
```

Diagnostic self-excluding evidence index:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-state-diagnostic.2SxEgB/evidence_index.jsonl

rows excluding itself:
378

size:
82924 bytes

SHA-256:
54c0c7fadf3f44b10f6ec59c056c2f800abdf9d0c4baac911c48732dd5f9f2cb
```

Verified three-state result:

```text
State A — accepted unstaged
porcelain:
6 `?? ` + 24 `M`
result:
pass

State B — alternate-index staged
porcelain:
6 `A  ` + 24 `M  `
result:
fail at line 477

State C — clean committed simulation
porcelain:
empty
result:
fail at line 475
```

State B and State C produced the same candidate tree:

```text
4336abdd16e51b27797d0364e0dcfcc3c58849fe
```

Diagnostic-only external commit:

```text
c324f2a09aabe243ba175a13ffe4af64432dd4d0
```

The diagnostic concluded:

- failure is not staged-index-only;
- the clean committed branch would remain red;
- repository test repair is required;
- validation sequencing alone is insufficient;
- remove the permanent test's dependency on dirty-status assertions;
- retain state-independent path/mode and protected-control checks;
- fresh independent audit is required after repair.

OPENING REPOSITORY IDENTITY

Before any edit require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644
```

Require:

- `git diff --check` clean;
- cached diff empty;
- no Git operation or lock;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, recorder residue, or thirty-first changed
  path.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

ACCEPTED CANDIDATE TARGET

Accepted independent-audit root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-independent-audit.T0I7mV
```

Accepted audit index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-independent-audit.T0I7mV/evidence_index.jsonl

rows excluding itself:
110

size:
23050 bytes

SHA-256:
e09add54af9a8d6e48969fd06a0c0e57bc2bf9125229f1f811c6781303c2cb54
```

Accepted final canonical-manifest SHA-256:

```text
9efb739e958cf077dafad99d5dc62af3fdcbd847c359916fd22fb5c125b79472
```

Accepted final node identity:

```text
5057 nodes

ordered SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe
```

Accepted final-repair evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit-findings-repair.nJmVEI
```

Accepted final-repair evidence index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit-findings-repair.nJmVEI/evidence_index.jsonl

rows excluding itself:
213

size:
37706 bytes

SHA-256:
22439f6586f7c2f7c67ba17fe25147f92d0016afba3140b7b5e3e96b51a710e4
```

FAILED COMMIT-GATE EVIDENCE

Failed gate root:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-gate.ECxUPx
```

Failed gate index:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-gate.ECxUPx/evidence_index.jsonl

rows excluding itself:
1054

size:
249127 bytes

SHA-256:
a944cf428eb753b568864e313402088d40474d764a280d8a4bc88ca65ca13dc5
```

The failed gate restored the accepted source-repository state exactly:

```text
24 tracked modifications
6 untracked additions
0 staged
no commit
no push
no PR
```

BEFORE MUTATION

Create one new operator-owned, non-symlink, mode-0700 external repair evidence
root beneath `/private/tmp`.

Then:

1. safely `lstat` and verify the accepted audit, accepted final-repair, failed
   commit-gate, and diagnostic evidence indexes;

2. record exact opening inventories for all four roots;

3. locate and verify the exact retained provenance recipe source through the
   accepted final-repair index:

   ```text
   regular file
   mode 0400
   size 3945
   SHA-256
   db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
   ```

4. reproduce the accepted candidate manifest twice with safe redirection of
   only the recipe's external fixed output sink;

5. require exact equality to the accepted target;

6. verify every candidate path and every path outside the candidate;

7. collect the exact 5,057 opening nodes once and require the accepted ordered
   SHA-256;

8. inspect completely:

   ```text
   tests/test_rw0_b2_capability_boundaries.py
   ```

9. inspect every local helper, constant, inventory, and subprocess/Git query
   used by the failing test;

10. retain exact opening source, AST, target node source, status-query call
    graph, and candidate fingerprint.

Stop before mutation on any mismatch.

ACCEPTED CONTRACT — DO NOT REOPEN

Preserve:

- every accepted production and documentation byte;
- both owner registries and their parsers;
- all C2A, lineage, B1, Wire, and Capability production semantics;
- all accepted public/import/privacy/authority boundaries;
- the exact stable path inventory, regular-file, mode, private-source,
  no-public-export, no-production-caller, dependency/schema/migration, and
  protected-control checks owned by the failing test;
- no source authentication, executable permission, semantic acceptance,
  persistence, provider/runtime/Git/publication authority;
- C/D/E and ES later/external owner seams.

Only the transient Git-status dependency is defective.

TEST-FIRST CAUSAL GATE

Before repairing the test, retain or reproduce the exact three-state diagnostic
against the opening bytes:

```text
A unstaged:
pass

B alternate-index staged:
fail

C clean committed external simulation:
fail
```

This may reuse the retained diagnostic when its tree, path bytes, command, and
environment exactly match opening. If any identity differs, rerun only the
single target node in the three states.

Add or activate test-owned assertions that will be red before repair and prove:

1. the permanent boundary assertion depends on `git status --porcelain` or its
   parsed dirty-state shape;

2. the same candidate tree produces different outcomes solely because Git
   reports:
   - `??`/unstaged `M`;
   - staged `A`/`M`;
   - clean committed status;

3. a state-independent boundary projection over the same tree would be
   identical in all three states;

4. stable path/mode/protected-control mutants remain rejected.

No production, documentation, import, path, or unrelated failure receives
causal credit.

Retain exact commands, alternate-index setup, external clean-repository setup,
tree OIDs, source-repository fingerprints, stdout/stderr, JUnit, and results.

REPAIR A — REMOVE TRANSIENT DIRTY-STATUS CONTRACT

Authorized path:

```text
tests/test_rw0_b2_capability_boundaries.py
```

In:

```text
test_exact_twenty_path_ceiling_modes_and_protected_controls
```

remove all assertions whose truth depends on the current output of:

```text
git status --porcelain
git diff --name-only
git diff --cached
tracked/untracked/staged counts
dirty topology
feature-branch candidate state
```

In particular, remove the contract that permanently expects:

```text
6 `??` untracked additions
24 unstaged modifications
0 staged additions
```

Candidate patch scope belongs to provenance/audit/gate evidence, not this
permanent repository test.

Do not replace those assertions with a staged-state or clean-state expectation.

The permanent test must produce the same contract result for the same candidate
tree regardless of whether Git represents it as:

```text
untracked/modified
staged additions/modifications
clean committed files
```

REPAIR B — PRESERVE STATE-INDEPENDENT CONTRACTS

Retain and strengthen, without changing accepted meaning:

1. exact stable Capability-owned/related path inventory already asserted by
   the test;

2. every required path exists;

3. every required path is a regular file;

4. every required filesystem mode is `0644`;

5. no symlink or special file;

6. protected controls remain unchanged according to their stable source,
   import, export, inventory, or content contracts—not transient patch status;

7. Capability remains private and unexported;

8. no production caller appears;

9. no dependency, schema, migration, SQL, `StateStore`, or `WriterSession`
   widening;

10. no I/O, process, network, provider, Bridge, ES-call, Git, publication, or
    runtime effect;

11. no authority widening.

Do not weaken a stable check merely because the dirty-status assertions are
removed.

REPAIR C — FINITE NO-STATUS-DEPENDENCY GUARD

Add one bounded, test-owned static/behavioral guard proving that the permanent
boundary test and its local helper call graph do not query transient Git status.

Acceptable implementation:

1. identify the target test and only the local helpers it directly or
   transitively calls;

2. inspect their AST/source;

3. reject direct or indirect execution of Git commands equivalent to:

   ```text
   git status
   git diff
   git diff --cached
   git ls-files --others
   ```

   when used to classify dirty, staged, tracked, or untracked candidate state;

4. allow stable read-only Git queries only when they inspect committed source
   identity or protected content in a way that remains valid in both dirty and
   clean states;

5. finite diagnostics identify helper/command category but do not echo
   arbitrary repository content.

Prefer removing status/diff helpers entirely from the target's call graph.

The guard itself must be causal. Test-local mutants must be killed when they:

```text
reinsert direct `git status --porcelain`
call a detached helper that runs `git status`
inspect staged/untracked counts
switch to `git diff --name-only`
branch on clean versus dirty porcelain
```

REPAIR D — THREE-STATE CONTRACT MATRIX

After repair, run the target node in all three exact states.

## State A — live accepted unstaged candidate

Expected:

```text
pass
```

## State B — alternate external index staged candidate

Requirements:

- do not change the source repository's real index;
- initialize unique external `GIT_INDEX_FILE` from accepted HEAD;
- stage exactly the 30 accepted manifest paths;
- prospective staged tree recorded;
- source real index remains untouched.

Expected:

```text
pass
```

## State C — external clean committed candidate

Requirements:

- external local-only repository;
- derived from accepted base without remote contact;
- overlay exact post-repair 30-file candidate;
- stage exact manifest;
- create one external temporary commit;
- committed tree equals State B prospective staged tree;
- clean status;
- target node run from that simulation.

Expected:

```text
pass
```

For all states require:

- same stable boundary projection;
- same path/mode/protected-control result;
- no status-dependent branch;
- source repository bytes/index unchanged.

REPAIR E — STABLE CHECK MUTANTS

Prove the repaired test remains causal by externally or test-locally mutating
one stable predicate at a time:

```text
remove one required path
add one unexpected Capability-owned path to the literal inventory
replace a regular file with a symlink in an external simulation
change one required mode
introduce one package-root export
introduce one production importer
introduce one dependency/schema/migration marker
break one protected-control content assertion
```

Each must fail for its intended stable reason.

Do not mutate the source repository. Use temporary external simulations or
in-memory/helper mutants.

EXACT REPOSITORY ALLOWLIST

Only this already-dirty path may change:

```text
tests/test_rw0_b2_capability_boundaries.py
```

The other 29 candidate entries must remain byte-identical.

No document or production source may change.

Final topology remains exactly:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
all regular mode 0644
```

Stop if a second repository path, documentation change, source change, or
thirty-first dirty path is required.

VALIDATION EVIDENCE ROOT

Create one new external root:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.XXXXXX
```

Requirements:

- operator-owned;
- non-symlink;
- mode 0700;
- retained files regular mode 0400;
- directories mode 0700;
- no special entries;
- self-excluding evidence index created last.

Use an unconditional recorder with complete envelopes for success, failure,
signal, refusal, nonlaunch, and tooling errors.

VALIDATION ENVIRONMENT

For every Python child:

```text
umask 022 before launch
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

FINAL VALIDATION ORDER

After final repository bytes are frozen:

1. selected causal:
   - no-status-dependency guard;
   - three-state target matrix;
   - stable predicate mutants;

2. Capability boundaries:
   ```text
   tests/test_rw0_b2_capability_boundaries.py
   ```

3. Capability complete:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   ```

4. B1/Wire compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```

5. architecture/status/static:
   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

6. final collection exactly once;

7. compare with:
   - opening 5,057 list;
   - accepted audit list;
   - final list;

8. require:
   - no node outside the authorized test changes identity/order;
   - any added/renamed/removed node is explicitly recorded;
   - no skip/xfail or unlisted reparameterization;

9. `git diff --check`;

10. exact path/mode/protected/import/public/authority/operation/lock/residue
    guards;

11. complete repository suite in the live accepted unstaged candidate exactly
    once;

12. complete repository suite in the external clean committed simulation
    exactly once.

The two complete suites are distinct required state validations, not retries.

Do not run a second suite in either state.

Every credited green run requires:

```text
return code 0
zero failures/errors/skips/xfails/warnings
empty stderr
parseable JUnit
zero duplicate/unmapped cases
matching caller/child umask
unchanged candidate fingerprint/tree
```

CLEAN COMMIT SUITE REQUIREMENTS

For the external clean committed simulation:

- exact candidate tree equals the State-B prospective staged tree;
- exact 30-file candidate overlay;
- clean status;
- same final node list as live candidate;
- same JUnit case mapping;
- source repository unaffected.

Require both live and clean-commit suites to pass.

PROVENANCE CLOSEOUT

After validation and cleanup:

1. require source-repository topology `30/24/6/0/0`;

2. prove exactly the sole authorized test path changed from the accepted opening
   manifest;

3. prove the other 29 entries remain byte-identical;

4. prove every path outside the candidate equals HEAD;

5. run the exact retained recipe twice with safe sink redirection;

6. require byte-identical final manifests and complete outputs;

7. retain:
   - exact recipe source;
   - final manifests and outputs;
   - per-path identities;
   - opening/final node lists;
   - three-state target records;
   - clean-commit tree/commit metadata;
   - no-status-dependency guard/mutants;
   - stable-check mutants;
   - all attempt envelopes;
   - live full-suite evidence;
   - clean-commit full-suite evidence;
   - final guards and cleanup;

8. create a self-excluding evidence index last;

9. verify accepted audit, failed gate, and diagnostic evidence roots unchanged.

Do not stage in the source repository, commit, push, create a PR, or perform an
independent audit.

STOP CONDITIONS

Stop without further repository mutation if:

- opening identity/provenance differs;
- stable contract assertions cannot be retained within one file;
- a second repository path is required;
- clean committed simulation still fails after removing status dependency;
- a real production/document/authority defect is discovered;
- a third complete-suite execution would be required;
- source repository index or bytes drift;
- validation/provenance is unstable.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_TEST_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only when:

- the target passes unstaged, alternate-index staged, and clean committed;
- stable contract mutants fail causally;
- both live and clean-commit complete suites pass;
- exact one-file provenance is stable;
- every stop condition is false.

FINAL REPORT

Include:

1. opening/final identity;
2. accepted audit, failed gate, and diagnostic evidence verification;
3. exact opening target reproduction;
4. selected red/control evidence;
5. exact one-path delta and 29-path equality;
6. removed transient-status assertions;
7. preserved stable contracts;
8. no-status-dependency guard and mutant results;
9. three-state target matrix;
10. stable-check mutant results;
11. node comparison;
12. every validation attempt;
13. live full-suite result;
14. clean-commit full-suite result and tree equality;
15. final manifest and aggregate identities;
16. evidence index and cleanup;
17. protected/public/authority non-widening;
18. remaining C/D/E/ES seams;
19. separate provenance, validation, and implementation confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
