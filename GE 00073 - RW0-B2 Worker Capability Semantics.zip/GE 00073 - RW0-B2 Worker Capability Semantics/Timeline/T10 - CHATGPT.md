## Engineering disposition

Codex’s disposition is correct:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_PARTIAL
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

Wire is not implementation-ready yet. The remaining issue is narrow, but it is a real fact-ownership gap: RW0-A treats **issuing a cancellation request** as an independently observed event between cancellation effect/delivery and acknowledgement. A cancellation decision, command, delivery, acknowledgement, rejection, signal, or exit cannot substitute for that fact. The current C2A observation grammar does not represent it, so the classifier cannot safely include cancellation precedence until B2 owns a supplied request-evidence shape. 

The rest of the Wire direction remains intact. The command frame still composes the existing command and delivery identities; the outer frame remains structural rather than semantic; and the worker result remains worker-authored evidence rather than process success, authority, acceptance, or a durable terminal outcome. 

## Owner decision

Adopt a **separate private B2 source-claim value**:

```text
RW0WireCancellationRequestObservationV1
```

with schema ID:

```text
governed-execution.nwp-rw0-wire-cancellation-request-observation.v1
```

Do not add `cancellation_requested` to the generic resource/signal supplement. The two classes have different ownership and identity graphs:

- `resource_limit_exceeded` and `signal_delivered` are process/OS facts.
- A cancellation request must bind the cancellation command, effect, fence, delivery, immutable target relation, and the exact worker/process target.
- Combining them would require a nullable polymorphic structure and would invite the same incomplete relation checks that repeatedly surfaced during B1.

The request observation is authored by the exact adapter or supervisor source that actually issues the request. Coordinator merely validates a supplied safe claim. RW0-D will later perform the physical request and produce or obtain the evidence. RW0-C will later own durable ingest, duplicate/conflict classification, completeness, replay, and terminal evidence membership.

The value must not claim that the request:

- reached the process;
- was acknowledged or rejected;
- caused a signal;
- caused exit or teardown;
- completed reconciliation;
- established semantic cancellation.

It grants no permission or acceptance.

## Classifier consequence

The classifier should consume the request observation separately from:

- the decoded worker result;
- existing adapter-authored C2A observations;
- the resource/signal supplements;
- actual attempt/effect fences and cancellation relation inputs.

A matching request is enough to prevent `usable`, even when acknowledgement has not arrived.

The required distinctions are:

```text
request only
request + acknowledgement
request + rejection
acknowledgement without request
rejection without request
acknowledgement + rejection
request + signal
request + adverse exit
```

Acknowledgement or rejection without a matching request is contradictory input. Rejection does not restore normal result usability or authorize progression. A signal outranks the request/response state as the reported process reason, but it does not erase the request evidence. Exit zero and a valid worker-completion frame cannot override an active request.

This preserves the RW0 cancellation chain without pretending that B2 owns teardown, reconciliation, or semantic cancellation.

## Remaining closure obligations

The next read-only pass must finish the now-finite freeze:

- exact ordered request-observation fields and relation;
- closed adapter-observation inventory and maximum cardinality;
- zero-or-one request, resource, and signal evidence rules;
- complete classifier reasons and precedence;
- exact exit-zero policy;
- numeric whole-operation budgets and C2A reconstruction tariffs;
- final profile manifest, ref, domain, and digest;
- final touched-file allowlist.

The previously derived payload and structure figures remain candidates to reproduce, not assumptions:

```text
command payload: 5,898
result payload:  16,627
depth:           3 / 4
containers:      5 / 8
key pairs:       71 / 77
```

C2A alone has no finite command-frame maximum because some integer leaves are unbounded; the B2 int64 representability policy is therefore a new admission rule rather than a C2A-derived ceiling. The prior reconnaissance also correctly found that raw structural occurrence counts are insufficient for the complete parsing and relation-work budget. 

The cancellation request and process supplements are classifier inputs, not frame payloads, so they should not change the command or result payload caps.

## Capability disposition

Capability remains:

```text
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

The new request observation is provider- and mechanism-neutral. It introduces no CLI/App Server selection, credential, provider session, endpoint, host detail, or invocation mechanism. Declaration, independent observation, and qualification remain distinct, while RW0-D/E retain concrete mechanism and process proof. 

## Next action

Continue in the **same read-only B2 Codex conversation** with this finite owner-decision closure prompt:

:chatgpt-content-reference{index="1"}

This is not another four-explorer reconnaissance and not an implementation prompt. It directs the parent to source-ground the exact request schema, close cardinalities and budgets, finalize the Wire profile and touched-file ceiling, and return:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_READY
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

Only that result permits a bounded parent-only RW0-B2-Wire implementation prompt.

### Sources

- Current partial Wire disposition and the remaining cancellation-request gap. 
- Adopted command, frame, result, and route ownership. 
- Integer, payload-size, structural, and cumulative-work findings. 
- Capability seam and later D/E ownership. 

**Confidence:** High that a separate cancellation-request observation is the smallest correct owner decision; high that extending the generic process supplement would be semantically weaker; moderate-to-high that this finite closure can now reach Wire READY without changing C2A or B1.
