PROMPT_ID

RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_IMPLEMENTATION_V1

TITLE

Coordinator RW0-B2-Capability — replace failed whole-document NLP oracles with
two embedded machine-authoritative current-contract registries

ENGAGEMENT TYPE

Parent-only workspace-write implementation in the existing Governed Execution
Coordinator Capability branch.

Do not create subagents. The parent is the sole repository writer.

This is a bounded documentation-and-contract-test architecture reset. It is not
a production semantic change, runtime implementation, independent audit,
staging, commit, push, PR, merge, release, deployment, provider integration,
database migration, or supporting-repository task.

No repository path outside the exact four-path allowlist may change.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Retire the failed whole-document natural-language status classifiers in the B1
and RW0 owner tests.

Replace them with:

1. one visible, exact, marker-bounded, machine-authoritative current-contract
   registry inside `.docs/rw0-b1-pure-phase-values.md`;

2. one visible, exact, marker-bounded, machine-authoritative current-contract
   registry inside
   `.docs/rw0-remote-worker-contact-phase-entry.md`;

3. finite test-local parsers that understand only the exact registry grammar,
   not arbitrary English semantics;

4. explicit one-way projection checks from the RW0 composition/status owner
   into the B1 registry;

5. a deliberate removal/replacement ledger for the failed NLP-specific test
   nodes, including the latest 209-node expansion.

Preserve all current substantive facts. Do not change production code, public
APIs, schemas, identities, budgets, authority splits, or later-owner seams.

GOVERNING RECONCILIATION RESULT

The immediately preceding read-only reconnaissance returned:

```text
RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_READY
```

Its engineering decision is accepted:

- abandon arbitrary natural-language semantic classification;
- use visible exact Markdown tables inside the owning documents;
- select prose policy A:
  the registry is the sole machine-authoritative status/ownership projection
  for its enumerated facts;
- prose outside the registry remains governing explanatory contract text, but
  tests do not claim to decide arbitrary semantic equivalence in that prose;
- authorize deliberate removal, rename, and replacement of failed NLP-specific
  nodes;
- keep the implementation within exactly four paths.

OPENING REPOSITORY IDENTITY

Before any edit require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644
```

Require:

- `git diff --check` clean;
- no Git operation or lock;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, or recorder residue.

Do not fetch, switch, reset, clean, stash, rebase, merge, or create another
branch.

OPENING PROVENANCE AND EVIDENCE

Current candidate evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB
```

Current canonical manifest:

```text
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB/frozen_final/canonical_manifest.json
```

Required identity:

```text
manifest size:
6430 bytes

manifest SHA-256:
8d5ed37273a3583104b2fb4f5acee045d7cc18799fdda368d2628e75d8807841

complete recipe output size:
6663 bytes

complete recipe output SHA-256:
e813ead384d3c88eb897d996c32b93245841279e31c002558c12dc36e9611d0c

file count:
30

opening node count:
5114

opening ordered-node-list SHA-256:
f3d83ce79954e7296b9406da6fcaa84a6676284d9504c7a9c30292d92c8fe8ae
```

Exact recipe source:

```text
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB/exact_recipe_source.py

type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Latest independent-audit evidence:

```text
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-continuation-audit.HLejOJ

report:
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-continuation-audit.HLejOJ/audit_report.md

index:
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-continuation-audit.HLejOJ/evidence_index.jsonl

index rows excluding itself:
48

index SHA-256:
4ef63b4f51edb0bb60e404ed6094b3d4b0b6f7f94854d7716ac8b290447a2ac2
```

Before mutation:

1. create one new operator-owned, non-symlink, mode-0700 external evidence root
   beneath `/private/tmp`;

2. safely `lstat` retained evidence paths and verify the latest audit index;

3. reproduce the current candidate manifest twice using the exact retained
   recipe source and safe redirection of only its external fixed output sink;

4. require both manifests and complete outputs to match the current target
   byte-for-byte;

5. verify every manifest entry by path, classification, type, mode, size, and
   SHA-256;

6. verify every path outside the 30-path candidate equals HEAD;

7. collect the complete opening node list exactly once and require 5,114 unique
   nodes with the expected ordered-list SHA-256;

8. inventory the exact current nodes in the two owner-test files and create a
   pre-edit migration ledger classifying each node by purpose.

Stop before mutation on any mismatch.

ACCEPTED CURRENT FACTS — DO NOT CHANGE

B1 facts:

- RW0-B1 is current implemented private pure no-I/O semantics.
- `validate_retrieval_event_sequence` has current work maximum `1285`.
- RW0-B2-Capability is the sole current cross-module production consumer of
  the private B1 host snapshot seam.
- B1 authenticates no source.
- B1 grants no executable permission.
- B1 persists no durable fact.
- B1 grants no semantic acceptance.
- RW0-C owns future acceptance-latch and durable
  ingest/completeness/recovery/terminal work.
- RW0-D owns future physical custody/transport/process/cancellation mechanics.
- RW0-E owns future separately authorized live proof.
- Execution Substrate owns admission, reliable submit, runtime identity,
  lifecycle, cancellation correlation, and retained results.

RW0 facts:

- RW0-B1 is current implemented private pure no-I/O semantics.
- RW0-B2-Wire is current implemented private pure no-I/O semantics.
- RW0-B2-Capability is current implemented private pure no-I/O semantics.
- RW0-C remains future durable semantics and recovery.
- RW0-D remains future physical/process/provider mechanics.
- RW0-E remains future separately authorized live proof.
- Execution Substrate is the current external route admission/runtime owner.
- No current B value, frame, digest, declaration, observation, qualification,
  or test grants executable authority or semantic acceptance.

PROSE AUTHORITY POLICY

Implement policy A exactly:

1. The bounded registry is the sole machine-authoritative current-status,
   ownership, implementation-posture, and explicit-nonclaim projection for the
   facts it enumerates.

2. Prose outside the registry remains governing explanatory contract text.

3. Contract tests do not claim to understand arbitrary semantic equivalence,
   paraphrase, polarity, negation, or contradiction in that prose.

4. Other prose may explain or restate current facts, but it does not write the
   machine-status projection.

5. Historical or stale-able material must remain explicitly labeled by the
   document. The registry parser does not infer historical scope from prose.

6. Tests may reserve exact registry headings, marker tokens, headers, rows, and
   finite field/component vocabulary. They must not scan arbitrary uses of
   words such as `current`, `future`, `blocked`, `not`, or `deferred`.

7. Arbitrary semantic equivalence is explicitly outside this test contract.

B1 REGISTRY — EXACT SOURCE BLOCK

Modify:

```text
.docs/rw0-b1-pure-phase-values.md
```

Insert the following as the first H2, immediately before the existing
`## Closed value grammar` heading:

```markdown
## Current-contract registry

Only the bounded registry below is machine-authoritative for the facts that it
owns. Projection rows consume their named owner and create no second authority.

<!-- RW0_B1_CURRENT_CONTRACT_REGISTRY_BEGIN -->
Registry version: 1

| Fact | Value | Role | Source |
| --- | --- | --- | --- |
| component | RW0-B1 | authority | this_document |
| lifecycle_status | current_implemented | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
| contract_class | private_pure_no_io_semantics | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
| retrieval_event_sequence_work_maximum | 1285 | authority | this_document |
| sole_current_cross_module_production_consumer | RW0-B2-Capability | authority | this_document |
| source_authentication | none | authority | this_document |
| executable_permission | none | authority | this_document |
| durable_persistence | none | authority | this_document |
| semantic_acceptance | none | authority | this_document |
| future_acceptance_latch_owner | RW0-C | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
| future_durable_ingest_completeness_recovery_terminal_owner | RW0-C | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
| future_physical_custody_transport_process_cancellation_owner | RW0-D | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
| future_separately_authorized_live_proof_owner | RW0-E | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
| es_admission_reliable_submit_runtime_identity_lifecycle_cancellation_results_owner | Execution Substrate | projection | .docs/rw0-remote-worker-contact-phase-entry.md |
<!-- RW0_B1_CURRENT_CONTRACT_REGISTRY_END -->
```

Do not change existing detailed B1 semantic prose except for the minimum local
transition needed to introduce the registry and prose policy without creating
a contradictory second machine-authority claim.

The table header, separator, row inventory, row order, cell text, marker text,
heading text, policy text, and `Registry version: 1` are exact.

No digest, schema ID, or new runtime semantic identity is created.

RW0 REGISTRY — EXACT SOURCE BLOCK

Modify:

```text
.docs/rw0-remote-worker-contact-phase-entry.md
```

Insert the following as the first live H2 immediately after:

```text
COORDINATOR_RW0_PHASE_ENTRY_CONTRACT_BEGIN
```

and before the existing Status H2:

```markdown
## Current-contract registry

Only the bounded registry below is machine-authoritative for the facts that it
owns. Projection rows consume their named owner and create no second authority.

<!-- COORDINATOR_RW0_CURRENT_CONTRACT_REGISTRY_BEGIN -->
Registry version: 1

| Component | Lifecycle status | Contract class | Authority owner | Detail contract | Authority posture | Implementation posture | Explicit nonclaims |
| --- | --- | --- | --- | --- | --- | --- | --- |
| RW0-B1 | current_implemented | private_pure_no_io_semantics | RW0-B1 | .docs/rw0-b1-pure-phase-values.md | no_executable_authority | implemented_in_this_repository | source_authentication,executable_permission,persistence,semantic_acceptance,acceptance_latch,es_runtime_fact |
| RW0-B2-Wire | current_implemented | private_pure_no_io_semantics | RW0-B2-Wire | .docs/rw0-b2-wire-protocol.md | no_executable_authority | implemented_in_this_repository | physical_transport,stream_process_plumbing,source_authentication,executable_permission,persistence,semantic_acceptance,es_runtime_fact |
| RW0-B2-Capability | current_implemented | private_pure_no_io_semantics | RW0-B2-Capability | .docs/rw0-b2-capability.md | no_executable_authority | implemented_in_this_repository | source_authentication,physical_process_behavior,executable_permission,semantic_acceptance,persistence,provider_runtime_selection,es_runtime_fact |
| RW0-C | future | durable_semantics_and_recovery | RW0-C | this_document | future_guarded_coordinator_progression_only | not_implemented | external_standing_authority,physical_process,es_runtime_fact |
| RW0-D | future | physical_custody_transport_process_provider_cancellation_mechanics | RW0-D | this_document | source_owned_physical_facts_no_semantic_progression | not_implemented | executable_authority,semantic_acceptance,es_runtime_fact,live_credentials,network |
| RW0-E | future | separately_authorized_live_proof | RW0-E | this_document | external_standing_authority_required_no_independent_authority | not_implemented | independent_standing_authority,semantic_progression,git,publication,es_runtime_fact |
| Execution Substrate | current_external_owner | route_admission_reliable_submit_runtime | Execution Substrate | external_contract | admission_and_runtime_authority_only | external_contract_not_implemented_here | coordinator_semantic_progression,semantic_acceptance,publication_authority,external_standing_authority |
<!-- COORDINATOR_RW0_CURRENT_CONTRACT_REGISTRY_END -->
```

Do not change existing detailed RW0 prose except for the minimum local
transition needed to introduce the registry and prose policy without creating
a second machine-authoritative status writer.

The heading, policy text, markers, version, table header, separator, row
inventory, row order, and cell text are exact.

The RW0 document owns the composition/status mapping. B1, Wire, and Capability
retain detailed semantic ownership in their own documents.

FINITE REGISTRY PARSER CONTRACT

Implement test-local parsers independently in:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Do not add a shared helper file.

Both parsers implement the same finite raw-source contract.

### Encoding and lines

- Read bytes.
- Reject UTF-8 BOM.
- Decode strict UTF-8.
- Split only on literal LF (`\n`).
- Reject CR in registry lines.
- Do not use `splitlines()`.
- Unicode line/paragraph separators remain ordinary characters and therefore
  make an exact registry line fail.

### Exact source grammar

The following are exact ASCII source lines:

- registry heading;
- two policy prose lines as wrapped in the source block;
- BEGIN marker;
- `Registry version: 1`;
- table header;
- table separator;
- every table row;
- END marker.

Reject:

- tabs in canonical registry lines;
- trailing spaces;
- NBSP or other Unicode whitespace;
- Unicode digits;
- normalization variants;
- Markdown emphasis, links, code spans, escapes, or additional pipes;
- missing, extra, duplicated, renamed, reordered, or relocated lines.

### Heading and location

The machine registry heading is recognized only by its exact source line.

Do not treat Setext or rendered/inline-equivalent headings as the registry.

B1 location:

- exact heading occurs once;
- it is the first H2 in the file;
- it appears immediately before the existing `## Closed value grammar`;
- the exact registry block lies between them.

RW0 location:

- exact heading occurs once;
- it is the first live H2 after
  `COORDINATOR_RW0_PHASE_ENTRY_CONTRACT_BEGIN`;
- it appears before the existing Status H2;
- the registry block lies within the existing outer owner markers.

### Global uniqueness

Count exact occurrences globally, including inside fences or comments, for:

- exact registry heading;
- BEGIN marker;
- END marker;
- `Registry version: 1`;
- exact table header.

Require exactly one of each.

A second exact occurrence inside a fence or comment fails. This is a finite raw
token rule, not rendered Markdown equivalence.

### Fence visibility

Use a finite scanner only to establish whether the canonical registry block is
visible.

Opening fence:

- zero through three leading ASCII spaces;
- at least three identical backticks or tildes;
- for a backtick opener, the info string may not contain a backtick;
- a tilde info string is permitted;
- four leading spaces do not open a fence.

Closing fence:

- zero through three leading ASCII spaces;
- same marker as opener;
- run length at least the opener length;
- only ASCII spaces or tabs after the run.

Opposite marker or shorter run does not close.

An unclosed fence remains active through EOF.

The canonical heading, policy, markers, version, header, separator, rows, and
END marker must all be visible. Otherwise fail.

Do not claim general Markdown parsing.

### Comments

Track HTML comments only to establish registry visibility.

- The exact one-line BEGIN and END marker comments are permitted.
- No other comment may span, contain, or splice a registry line.
- If the canonical heading or block lies inside a larger comment, fail.
- Raw exact marker uniqueness remains global.

Do not infer arbitrary comment-rendered semantics.

### Parsing and canonical projection

B1:

- parse `Registry version` as an exact ASCII decimal integer;
- parse `retrieval_event_sequence_work_maximum` as an exact ASCII decimal
  integer;
- all other cells remain exact strings;
- produce one fresh immutable test projection with the exact ordered rows.

RW0:

- parse `Registry version` as an exact ASCII decimal integer;
- all row cells remain exact strings;
- produce one fresh immutable test projection with the exact ordered rows.

Comma-separated explicit-nonclaim cells remain atomic ordered strings. Do not
interpret them as inferred sets.

Expected projections must be independent test literals, not generated from the
document.

### Cross-document projection check

Parse the RW0 registry first.

Require the B1 projection rows to match the exact corresponding RW0 facts:

- lifecycle status;
- contract class;
- future acceptance-latch owner;
- future durable owner;
- future physical/process owner;
- future live-proof owner;
- ES owner.

The B1 registry remains authoritative for:

- retrieval maximum;
- sole current cross-module consumer;
- B1-local nonclaims.

The cross-document test is one-way. It creates no second owner.

### Finite diagnostics

Use finite content-free diagnostics only:

```text
b1.registry.encoding
b1.registry.fence
b1.registry.marker
b1.registry.visibility
b1.registry.location
b1.registry.version
b1.registry.shape
b1.registry.order
b1.registry.value
b1.registry.projection

rw0.registry.encoding
rw0.registry.fence
rw0.registry.marker
rw0.registry.visibility
rw0.registry.location
rw0.registry.version
rw0.registry.shape
rw0.registry.order
rw0.registry.value
rw0.registry.projection
```

Do not echo arbitrary document contents.

PROSE POLICY TEST

Each modified test file must contain a direct assertion of the owner policy:

- the registry is machine-authoritative only for enumerated facts;
- surrounding prose remains detailed explanatory contract text;
- the test does not claim arbitrary natural-language contradiction detection;
- arbitrary semantic equivalence is outside the parser contract.

Add a false-positive control proving that unrelated explanatory prose outside
the registry does not change the parsed projection and is not scanned for
keywords.

TEST ARCHITECTURE RESET

Do not preserve the failed NLP architecture by inertia.

Before edits, create a migration ledger for every current node in the two
modified test files.

Classify each node as:

```text
retain unchanged
retain with stronger finite registry assertion
rename to registry-purpose node
replace
remove as failed NLP architecture
remove as byte-identical alias
```

The latest 209 nodes receive this required treatment:

```text
B1 survivor corpus:          23 remove from executable NLP corpus
RW0 survivor corpus:         19 remove from executable NLP corpus

B1 live positive:             1 replace with canonical registry projection
RW0 live positive:            1 replace with canonical registry projection

B1 Markdown controls:        12 replace with finite registry structure/
                                visibility mutants
RW0 Markdown controls:       12 replace with finite registry structure/
                                visibility mutants

B1 semantic matrices:        48 remove entirely
RW0 semantic matrices:       77 remove entirely

B1 false-positive controls:   8 replace with prose-nonauthority/isolation
                                controls
RW0 false-positive controls:  8 replace with prose-nonauthority/isolation
                                controls
```

Remove all 22 byte-identical aliases.

Also identify and migrate older failed NLP-specific nodes already present in
the 4,905-node pre-expansion baseline:

B1 categories:

- arbitrary-claim placement nodes;
- complete-owner natural-language structure nodes;
- survivor-corpus nodes;
- mixed retrieval/consumer NLP tests.

RW0 categories:

- arbitrary status/ownership placement nodes;
- complete-owner natural-language structure nodes;
- survivor-corpus nodes;
- mixed status/open-decision NLP tests.

Do not remove unrelated owner-marker, import, public-boundary, runtime-
nonauthority, or exact semantic-contract tests.

NODE MIGRATION POLICY

Opening count:

```text
5114
```

Final count is collection-derived and must not be predeclared.

Node removal and rename are explicitly authorized only through the retained
migration ledger.

Require:

1. every opening node outside the two modified files remains in identical
   relative order;

2. every removed or renamed node inside the two files has exactly one migration
   record with old node ID, category, disposition, and replacement purpose;

3. no unlisted node removal, rename, skip, xfail, reparameterization, or
   collapse;

4. retained nodes remain in relative order where practical;

5. every new node belongs to one of the two modified files;

6. every generated mutant has unique document bytes and unique purpose;

7. no differently named byte-identical mutant nodes;

8. the final report includes:
   - complete opening node list;
   - complete final node list;
   - retained intersection;
   - removals;
   - renames;
   - additions;
   - migration ledger;
   - mutant-byte uniqueness digest.

TEST-FIRST GATE

Modify tests first, before documents.

Run a selected red gate that proves only the accepted missing-registry behavior:

- B1 registry absent;
- RW0 registry absent;
- cross-document projection unavailable.

The red gate may include migration-ledger self-checks and parser-unit tests that
do not require the live registry.

Do not credit failures from:

- syntax or import errors;
- fixture defects;
- path mistakes;
- unrelated owner tests;
- legacy NLP tests that should have been removed;
- production or documentation contradictions.

Retain exact argv, environment, umask, stdout/stderr, JUnit, node IDs, and
before/after candidate fingerprints.

REGISTRY MUTANT REQUIREMENTS

Add test-owned, causal mutants for each owner.

Structural mutants:

- missing heading;
- duplicate heading;
- heading in fence;
- heading in larger comment;
- missing BEGIN;
- missing END;
- reversed markers;
- duplicate BEGIN or END;
- marker in fence/comment;
- missing version;
- wrong version;
- duplicate version;
- missing header;
- wrong header;
- duplicate header;
- missing row;
- extra row;
- duplicate row;
- unknown row;
- renamed field/component;
- reordered rows;
- relocated block;
- registry after wrong heading;
- block hidden by backtick fence;
- block hidden by tilde fence;
- unclosed fence;
- opposite-marker non-closure;
- shorter closer non-closure;
- backtick info containing backtick is not an opener;
- four-space fence non-opener;
- CR in registry line;
- BOM;
- Unicode line separator;
- tab;
- trailing space;
- NBSP;
- Unicode digit;
- inline emphasis/link/code;
- extra pipe;
- multiline comment spanning registry;
- comment-spliced registry line.

Value mutants:

B1:

- every row receives one wrong value;
- wrong role;
- wrong source;
- `1284`, `1286`, signed value, leading zero, Unicode digit;
- wrong sole consumer;
- wrong C/D/E/ES projection;
- wrong nonclaim value.

RW0:

- every cell in every row receives one wrong value;
- current/future swap;
- wrong authority owner;
- wrong detail contract;
- wrong authority posture;
- wrong implementation posture;
- wrong explicit-nonclaim string;
- row/component mismatch.

Cross-document mutants:

- one B1 projection differs from RW0 owner;
- RW0 owner changes while B1 copy remains stale;
- B1 authority row changed without RW0 change;
- projection source mislabeled as authority;
- authority source mislabeled as projection.

False-positive controls:

- unrelated prose before/after registry;
- words current/future/blocked/deferred in explanatory prose;
- Setext heading with same rendered title;
- inline-rendered equivalent title;
- four-space literal heading;
- fenced examples without exact duplicate registry tokens;
- historical prose outside registry;
- explanatory restatement matching registry;
- ordinary comments outside registry;
- Unicode prose outside exact registry lines.

Every mutant must have unique bytes. Record SHA-256 for every mutant document
and reject duplicates.

EXACT FOUR-PATH ALLOWLIST

Only these paths may change:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Every other repository path is protected byte-for-byte.

The other 26 current candidate entries must remain byte/type/mode identical.

No new file is authorized.

Final topology remains exactly:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
all regular mode 0644
```

Stop if a fifth path or thirty-first dirty path is required.

VALIDATION ENVIRONMENT

Use one new external operator-owned, non-symlink, mode-0700 implementation
evidence root.

For every child:

```text
umask 022 before launch
child numerical umask must be 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Retain exact argv, environment, Python identity, umask, timestamps, return
code, stdout/stderr, JUnit, structured counts, and before/after candidate
fingerprints.

FINAL VALIDATION ORDER

After final bytes are frozen:

1. parser unit and selected causal registry nodes;

2. both modified owner tests independently:

   ```text
   tests/test_rw0_b1_boundaries.py
   tests/test_rw0_remote_contact_phase_entry_contract.py
   ```

3. B1 compatibility:

   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```

4. Capability/Wire compatibility:

   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```

5. architecture/status/static compatibility:

   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

6. final collection exactly once;

7. compare with the 5,114-node opening list using the authorized migration
   ledger;

8. require no unlisted loss and preserve relative order among retained nodes
   and all nodes outside the two modified tests;

9. `git diff --check`;

10. exact path, mode, protected-byte, import, public, authority, operation,
    lock, and residue guards;

11. complete repository suite exactly once with quiet rendering.

Every credited green run requires:

- return code 0;
- zero failures/errors/skips/xfails/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate or unmapped cases;
- matching caller/child umask;
- unchanged candidate fingerprint.

FULL-SUITE POLICY

Run complete-suite attempt 001 once after focused validation is green.

If it fails:

- preserve all evidence;
- repair only a deterministic patch-caused defect inside the four paths;
- rerun affected focused groups;
- run complete-suite attempt 002 exactly once.

Stop if:

- failure is outside scope;
- a fifth path is required;
- protected bytes must change;
- a third complete-suite attempt would be required.

PROVENANCE CLOSEOUT

After validation and cleanup:

1. require exact topology `30/24/6/0/0`;

2. prove exactly the four authorized entries changed from the opening manifest;

3. prove the other 26 entries remain byte-identical;

4. prove every path outside the 30-path candidate equals HEAD;

5. run the exact retained recipe twice with safe output-sink redirection;

6. require byte-identical final manifests and complete outputs;

7. retain:
   - exact recipe source;
   - final manifests and complete outputs;
   - per-path identities;
   - opening/final node lists;
   - migration ledger;
   - unique-mutant digest ledger;
   - red/green records;
   - full-suite evidence;
   - final guards;

8. create a self-excluding evidence index;

9. retain evidence files mode 0400 and directories mode 0700;

10. remove only implementation-created transient artifacts;

11. verify the latest audit and opening implementation evidence roots remain
    unchanged.

Do not stage, commit, push, create a PR, or perform an independent audit.

STOP CONDITIONS

Stop without further mutation if:

- opening identity or provenance differs;
- the four-file ceiling is insufficient;
- a fact cannot be assigned uniquely to B1-local or RW0-composition ownership;
- a cross-reference requires a second registry writer;
- parser scope expands into general Markdown rendering or natural-language
  inference;
- any production, public, schema, migration, SQL, runtime, provider, or
  authority change is required;
- registry facts require provider, CLI/App Server, credential, transport,
  runtime mechanism, executable permission, persistence, or semantic
  acceptance selection;
- valid existing production tests fail outside the four-path scope;
- node migration is incomplete or contains unlisted loss;
- duplicate mutant bytes remain;
- validation or provenance is unstable.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_IMPLEMENTED_READY_FOR_FRESH_REAUDIT
```

only when:

- both registries are exact and authoritative;
- failed NLP helpers and nodes are deliberately migrated;
- all finite registry mutants and false-positive controls pass;
- focused and complete validation are green;
- exact four-path provenance is stable;
- every stop condition is false.

FINAL REPORT

Include:

1. opening/final repository identity;
2. retained evidence verification;
3. exact opening target reproduction;
4. test-first red evidence;
5. exact four-path delta and 26-path equality;
6. final B1 registry and canonical projection;
7. final RW0 registry and canonical projection;
8. registry parser implementation;
9. prose authority policy;
10. B1-to-RW0 projection checks;
11. node migration ledger;
12. removed, renamed, retained, and added nodes;
13. mutant-byte uniqueness results;
14. every validation attempt;
15. full-suite result and attempt number;
16. final manifest and aggregate identities;
17. protected/public/authority non-widening;
18. remaining C/D/E/ES seams;
19. separate provenance, validation, and implementation confidence;
20. explicit statement that arbitrary prose semantic equivalence is outside
    the test contract.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
