PROMPT_ID

RW0_B2_CAPABILITY_FINAL_TEST_ORACLE_REPAIR_INDEPENDENT_AUDIT_V1

TITLE

Coordinator RW0-B2-Capability — fresh independent audit of the final
four-test-path oracle repair and exact 30-file Capability candidate

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated independent audit.

Use a new Codex conversation. Do not use the write-enabled implementation
conversation that produced the repair.

The audit parent and every audit subagent are read-only. No repository
mutation, formatting, cleanup of candidate bytes, dependency installation,
staging, commit, push, PR, merge, tag, release, deployment, remote/service/
provider/host contact, product worker/model invocation, database mutation,
migration, or supporting-repository inspection is authorized.

Audit-created probes, clean external HEAD archives, pytest outputs, and
provenance records may be written only beneath one new external operator-owned
mode-0700 audit root.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Determine whether the exact final tests-only candidate mechanically closes the
four findings from the preceding independent audit without weakening test
causality, current owner documentation, production semantics, authority
boundaries, validation, or provenance:

```text
B1-FINAL-REAUDIT-001
  Thirteen-relation matrix mutation adequacy:
  exact selected object, bypass set, delegation set, and value/projection
  semantics must be independently pinned.

B1-REAUDIT-002
  Complete B1 owner-document regression oracle:
  stale retrieval/consumer claims and hidden/relocated duplicate ownership must
  be rejected anywhere in the authoritative owner.

RW0-STATUS-REAUDIT-001
  Complete RW0 owner-document status oracle:
  additive future/blocked/unimplemented B1/Wire/Capability claims and hidden or
  relocated duplicate current-status ownership must be rejected.

CAP-FINAL-AUD-001
  Canonical reason identity:
  equal but non-identical exact built-in caller text must be replaced by the
  module-owned canonical reason object in supported observations and registry
  state.
```

The preceding audit found the production implementation and current documents
correct. This audit must detect test-oracle defects; it must not demand source
or document changes unless it discovers a concrete contradiction.

EXPECTED LIVE IDENTITY

Require at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate modes:
all regular 0644
```

Require no Git operation, lock, `git diff --check` failure, repository cache,
bytecode, database, journal, archive, build output, generated repository
manifest, recorder residue, or thirty-first changed path.

Do not fetch, switch, reset, clean, stash, rebase, or merge.

FINAL AUDIT TARGET

Retained final repair evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-final-test-repair.fqBaN1
```

Required final identities:

```text
canonical-manifest size:
6430 bytes

canonical-manifest SHA-256:
230786a458ed8e484c6ec37416f783cd71b5c47ec67a27d2bdd44afc7fe92772

tracked textual-diff SHA-256:
7f77ef027a80f0e5cb8dc686fcecf55dc8ca1ef3493c25a5771f7a2be1b9261e

complete recipe stdout size:
6663 bytes

complete-output SHA-256:
f33e22e718b8826ad157ccf0f936abebe06b0699af14feb572dc3c5256d27c83

file count:
30

final pytest node count:
4905

final ordered-node-list SHA-256:
1a3b2c384bfe06ee5fdc358e22807cc0e3ad8f0fbeca004a35ee4f97b3adefa9
```

Required final closeout records:

```text
/private/tmp/ge-coordinator-rw0-b2-final-test-repair.fqBaN1/final_closeout/aggregate_identities.json

/private/tmp/ge-coordinator-rw0-b2-final-test-repair.fqBaN1/final_closeout/summary.json

/private/tmp/ge-coordinator-rw0-b2-final-test-repair.fqBaN1/final_closeout/evidence_index.jsonl

/private/tmp/ge-coordinator-rw0-b2-final-test-repair.fqBaN1/final_closeout/node_additions.txt
```

Required self-excluding evidence index identity:

```text
rows excluding itself:
449

size:
85549 bytes

SHA-256:
4e05069fc30f3a4c9a04264026f63c88f045a1aef4c01c495df72bbc129a8bc4
```

Locate the final canonical manifest and both final recipe-run outputs through
the aggregate identities and closeout summary. Require the manifest identity
above. Do not guess or reconstruct a missing target.

OPENING REPAIR TARGET

The tests-only repair began from:

```text
manifest:
/private/tmp/ge-coordinator-rw0-b2-final-repair.jSsN6n/final_closeout/recipe_1.manifest.json

canonical-manifest SHA-256:
132b7473151706f7bb257aea44efdefad04b7e2e2dab8f3ef5486e46a6e6372f

tracked textual-diff SHA-256:
c3ccbcaa17c6a1140529712b414f8a002a18a76d4b8d8733ca6d63bc2deab821

complete-output SHA-256:
1606765a198803686184f4fff3da59f5e8a00e2d07c80744ac6a0459d46b72f4

opening pytest node count:
4761

opening ordered-node-list SHA-256:
e9b1d63bc8b1545e96d9569c8a59304268c04e0a702e529ecf9f35b74e83c2d8
```

Exactly these four entries must differ from that opening target:

```text
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The other twenty-six opening entries must be byte-, kind-, type-, mode-, size-,
and classification-identical.

PRECEDING INDEPENDENT AUDIT

The audit that found the four test-oracle defects is:

```text
/private/tmp/ge-coordinator-rw0-b2-final-reaudit.z9jTj5

report:
/private/tmp/ge-coordinator-rw0-b2-final-reaudit.z9jTj5/audit_report.md

self-excluding evidence index:
/private/tmp/ge-coordinator-rw0-b2-final-reaudit.z9jTj5/evidence_index.jsonl

index size:
38308 bytes

index SHA-256:
cf5cd72046ccb6da6dcabcb03abcc5a162cfffccd644331deaa3af20dab6ba3c

rows excluding itself:
204
```

Verify it safely and preserve it unchanged.

EXACT RECIPE SOURCE

Decode this base64 only beneath the new audit root. Require exactly 3,945 bytes
and SHA-256:

```text
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Retain the decoded source mode 0400.

```text
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

The historical recipe output path is:

```text
/tmp/ge-coordinator-b3a-audit-manifest-v1.json
```

Run the exact source twice with source bytes unchanged and only that external
fixed sink safely redirected to two unique audit-root files. Retain the exact
wrapper source and prove redirection cannot affect Git queries, stdout,
canonical JSON, or any other recipe behavior.

PROVENANCE GATE

Before correctness inspection or audit subagents:

1. create one new operator-owned, non-symlink, mode-0700 audit root beneath
   `/private/tmp`;
2. safely `lstat` all retained-evidence path components;
3. verify the final repair evidence index exactly;
4. inventory the final repair evidence root independently and compare it at
   closeout;
5. verify exact repository identity and `30/24/6/0/0` topology;
6. safely copy the retained final manifest into the audit root mode 0400;
7. require canonical JSON, file count 30, size 6,430, and SHA-256
   `230786a458ed8e484c6ec37416f783cd71b5c47ec67a27d2bdd44afc7fe92772`;
8. verify every manifest entry by classification, regular-file type, mode,
   size, and SHA-256;
9. verify no thirty-first changed path;
10. verify every path outside the manifest equals HEAD;
11. verify the exact recipe source;
12. execute it twice with safe sink redirection;
13. require both generated manifests to equal the retained final manifest
    byte-for-byte;
14. require both complete outputs to be byte-identical, 6,663 bytes, and
    SHA-256
    `f33e22e718b8826ad157ccf0f936abebe06b0699af14feb572dc3c5256d27c83`;
15. require tracked textual diff
    `7f77ef027a80f0e5cb8dc686fcecf55dc8ca1ef3493c25a5771f7a2be1b9261e`;
16. load and verify the opening repair manifest;
17. prove exactly the four authorized test entries changed and the other 26
    entries remained exact;
18. verify the final node list, additions list, full-suite record, and
    self-excluding index;
19. verify explicitly protected source/docs/public surfaces.

On any candidate or mandatory evidence identity mismatch, stop before
correctness inspection and return exactly:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not approximate or regenerate missing evidence.

EXPLICITLY PROTECTED BY THIS TESTS-ONLY REPAIR

These must equal the opening repair target:

```text
.docs/rw0-b2-capability.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/rw0-b2-wire-protocol.md

src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml

tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py

all SQL, migrations, schemas, catalogs
StateStore
WriterSession
package exports
dependency metadata
```

ACCEPTED CONTRACTS — DO NOT REOPEN BY INERTIA

Preserve:

- Capability production behavior and current error contract;
- all thirteen B1 production relation semantics and fresh-value use;
- current B1 retrieval maximum `1285`;
- Capability as the sole current cross-module B1 consumer;
- current RW0-B1, RW0-B2-Wire, and RW0-B2-Capability private semantics;
- later RW0-C/D/E and ES owner seams;
- C2A, lineage, B1, Wire, and Capability schemas, identities, canonical bytes,
  budgets, reason precedence, and import direction;
- no source authentication, permission, acceptance, contact, persistence,
  runtime, provider, credential, endpoint, session, Git, or publication
  authority.

Use the audit to detect a concrete contradiction, not to redesign a green
production surface.

AUDIT PERSPECTIVES

After the provenance gate, use exactly four bounded, non-nesting, read-only
perspectives when available. No child runs tests or modifies files.

1. Capability canonical-reason auditor
   - equal-but-nonidentical exact built-in strings;
   - module-owned canonical object identity in `reason`, `_reason`, and weak
     registry;
   - caller-value retention mutant;
   - complete finite-reason inventory;
   - preservation of exact-type, hostile-object, inherited-state, chaining,
     cleanup, serialization, and authority-nonclaim coverage.

2. B1 thirteen-relation mutation-adequacy auditor
   - independent immutable target/call/bypass/delegation/poison literals;
   - independence from fixture argument construction;
   - exact selected-object identity;
   - exact selective bypass and delegation ledgers;
   - exact class-wide bypass and empty delegation ledger;
   - exact fresh-value/projection type, identity, and equality;
   - wrong-target, missing-bypass, extra-bypass, projection-substitution,
     omitted-delegation, and extra-delegation mutants;
   - preservation of normal `invalid_enum` and poisoning controls.

3. B1 owner-document complete-oracle auditor
   - complete-file visible and hidden structural scan;
   - unique owner/current relation/current consumer regions;
   - current 1285 retrieval maximum;
   - Capability sole-current-consumer statement;
   - before/inside/after/tail contradictions;
   - numeric and number-word 374 variants;
   - zero/no-consumer and future/unimplemented Capability variants;
   - visible and fenced/hidden duplicate owner and region headings;
   - relocated, same-title, and trailing controls.

4. RW0 owner-document complete-status-oracle auditor
   - exact component names RW0-B1, RW0-B2-Wire, RW0-B2-Capability;
   - current private semantics and later C/D/E/ES ownership;
   - complete-file scan rather than one H2;
   - before/inside/after/tail future/blocked/deferred/unimplemented mutants;
   - physical transport/process/provider/credential/runtime/durable-fact
     rollback mutants;
   - visible and hidden duplicate titles/headings, relocation, same-title, and
     trailing controls;
   - provenance, validation, public-boundary, and authority non-widening in
     coordination with the parent.

The parent performs reconciliation, evidence review, external mutation probes,
node comparison, validation, and closeout. Preserve disagreements.

Every finding must include:

```text
ID
type
severity: critical | high | medium | low | observation
current contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect or pre-existing issue
```

REQUIRED SOURCE AND TEST INSPECTION

Inspect all four changed test files completely:

```text
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Inspect their protected owners and direct dependencies:

```text
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py

.docs/rw0-b2-capability.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/rw0-b2-wire-protocol.md

tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py

src/ge_nwp_coordinator/__init__.py
pyproject.toml
```

Inspect additional Coordinator files only for a concrete dependency and record
why. Do not inspect another repository.

HYPOTHESIS A — CANONICAL REASON IDENTITY

Independently prove or falsify:

1. Every finite reason is covered by the checked inventory.
2. The test constructs an exact built-in string that is:
   - equal to the canonical reason;
   - not object-identical to it;
   - kept alive through all identity assertions.
3. The real Capability factory/boundary returns an error whose:
   - `reason` is the module-owned canonical string object;
   - `_reason` is that same object;
   - weak-registry value is that same object;
   - `BaseException.args` is `()`;
   - caller-owned equal string is not the registry value.
4. The test does not accidentally reuse an interned object.
5. A caller-value-retention mutant preserves equality but is killed solely by
   object identity.
6. Existing exact-type, hostile-object, inherited-state, chaining,
   weak-cleanup, serialization, and no-authority tests remain causal.

Run external in-memory mutants that:

- store the caller string directly;
- return the caller string from `reason` while registry remains canonical;
- keep `reason` canonical but store caller text in the registry;
- remove the identity assertion;
- use a construction that interns the text.

The checked test must kill the applicable mutants for the correct reason.

HYPOTHESIS B — B1 MATRIX INDEPENDENCE

The exact production inventory is:

```text
validate_phase_entry_basis
validate_authority_observation
validate_per_fence_basis
validate_external_common_family_claim
validate_subordinate_narrowing
validate_custody_binding
validate_retrieval_event_sequence
validate_host_qualification
validate_terminal_outcome_binding
validate_normal_terminal_branch
validate_active_cancel_reconciled_branch
validate_active_cancel_unresolved_branch
validate_pre_effect_cancel_basis_unusable_branch
```

Independently derive the inventory from production and compare it with every
test-owned literal key set.

Require separate immutable test literals for:

```text
selected target
expected reconstruction calls
selective bypasses
selective delegations
class-wide bypasses
class-wide delegations
poison target
```

Verify:

- fixture argument construction does not provide or derive the expected target;
- each target label maps to one exact argument/object occurrence;
- duplicate or ambiguous identities fail before executing a mode;
- selective mode bypasses exactly the selected occurrence and delegates the
  literal remainder in exact order;
- class-wide mode bypasses every and only the expected occurrences and
  delegates none;
- repeated logical values remain distinct occurrences where production calls
  distinguish them;
- every delegated or bypassed result has exact B1 value type, fresh identity,
  exact dict projection, projection equality, and correct value/projection
  slot order;
- normal forged input fails exact `invalid_enum`;
- poisoning after reconstruction proves fresh-local use.

Run external mutants corresponding exactly to the prior survivors and new
ledgers:

```text
wrong selected object
missing one class-wide bypass
extra selective bypass
projection mapping in value slot
swapped value/projection slots
original or forged object in fresh-value slot
omitted expected delegation
extra unexpected delegation
reordered delegation
duplicate label/ambiguous object mapping
```

The checked matrix must kill each mutant through an independent target/ledger/
type/identity oracle before a later generic relation error can mask it.

HYPOTHESIS C — COMPLETE B1 OWNER ORACLE

Treat the entire `.docs/rw0-b1-pure-phase-values.md` file as the authoritative
owner. Distinguish visible Markdown from fenced content while also enforcing
hidden duplicate structure.

Require:

- one visible owner root;
- one visible current relation/work-budget region;
- one visible current production-consumer/import region;
- zero visible or hidden/fenced duplicate owner roots or designated headings;
- exactly one current retrieval maximum `1285`;
- no other current retrieval cap/limit/maximum/budget assertion anywhere;
- exactly one Capability sole-current-consumer statement;
- no current zero/no-consumer or future/unimplemented Capability assertion;
- no contradictory trailing prose.

Run each semantic class at least before, inside, after, and at document tail:

```text
The current retrieval maximum is 374.
The current retrieval cap is three hundred seventy-four B1 units.
B1 presently has zero production callers.
No production module currently consumes B1.
Capability consumption remains a future B2 concern.
B2-Capability is not yet implemented.
```

Also run:

```text
visible duplicate owner title
fenced/hidden duplicate owner title
visible duplicate relation heading
fenced/hidden duplicate relation heading
visible duplicate consumer heading
fenced/hidden duplicate consumer heading
relocated owner region
same-title sibling
trailing contradiction
```

Require the same complete oracle to reject every mutant. Do not credit a
separate helper that is stronger than the checked positive oracle.

HYPOTHESIS D — COMPLETE RW0 STATUS ORACLE

Treat the entire `.docs/rw0-remote-worker-contact-phase-entry.md` file as the
authoritative owner.

Require a unique visible current status/tranche region proving:

```text
current:
RW0-B1
RW0-B2-Wire
RW0-B2-Capability

later owners:
RW0-C
RW0-D
RW0-E
Execution Substrate
```

Use exact component names. Do not rely on `RW0-B\b`.

Reject visible assertions anywhere in the document that make current B
semantics future, blocked, deferred, unimplemented, absent, or earliest
unresolved, or that assign physical transport, process, provider, credential,
live runtime, durable ingest, recovery, terminal fact, latch, or ES runtime
ownership back to B.

Run before/inside/after/tail mutants including:

```text
RW0-B remains blocked until process transport is implemented.
The B tranche is still future; RW0-C cannot begin.
Earliest unresolved tranche: RW0-B.
RW0-B1 remains unimplemented.
RW0-B2-Wire remains blocked.
RW0-B2-Capability remains unimplemented.
B2-Capability is not yet implemented.
| RW0-B | future | physical process plumbing |
| RW0-B2-Wire | blocked | runtime transport |
| RW0-B2-Capability | future | provider integration |
```

Also run visible and hidden duplicate owner titles/headings, relocation,
same-title sibling, fenced-only, and trailing controls through the exact same
checked oracle.

IMPLEMENTATION-EVIDENCE ASSESSMENT

Review every retained attempt without silently crediting summaries.

Reported implementation evidence:

```text
selected red gate:
14 expected failures
no errors/skips/warnings/duplicates/unrelated failures

pre-freeze development runs:
20, 51, 35, 124, 51, 124, 20, 28, 69, 175 tests
all green

final credited runs:
selected causal                 174
Capability values                28
B1 relations                     69
B1 boundaries                    51
RW0 status                      124
Capability compatibility         54
B1 compatibility                367
owner/static/status             515
final collection               4905
full suite attempt 001         4905
```

Determine:

- whether the red gate actually demonstrates the opening oracle weaknesses;
- whether every green record is bound to the exact final manifest;
- whether any test helper is circular with its expected mutant result;
- whether the large 144-node increase is justified and confined to the four
  tests;
- whether any node addition disguises parameter replacement, removed cases, or
  weakened existing assertions;
- whether the full-suite record is structurally valid, parseable, and exactly
  bound to the final node list and candidate fingerprint;
- whether no attempt 002 ran.

NODE IDENTITY

Run one candidate collection and one clean external `git archive HEAD`
collection under identical isolated conditions.

Require:

```text
candidate:
4905 unique nodes

candidate ordered-list SHA-256:
1a3b2c384bfe06ee5fdc358e22807cc0e3ad8f0fbeca004a35ee4f97b3adefa9

clean HEAD:
4655 unique nodes

clean HEAD ordered-list SHA-256:
f36822a60056ec3d110956de561202b737662c9d22cd0dd82c4cdad6c7cef69f

intersection:
4655

candidate-only:
250

HEAD-only:
0

HEAD order preserved:
true
```

Relative to the 4,761-node opening repair target require:

```text
144 additions
0 removals
0 renames
opening order preserved
```

Require exact split:

```text
tests/test_rw0_b1_boundaries.py:
44 additions

tests/test_rw0_b1_relations.py:
6 additions

tests/test_rw0_b2_capability_values.py:
1 addition

tests/test_rw0_remote_contact_phase_entry_contract.py:
93 additions
```

Compare the literal additions with the retained `node_additions.txt`. No
existing node may be removed, renamed, skipped, xfailed, reparameterized,
collapsed, or reordered.

INDEPENDENT VALIDATION

Only after source/test inspection and external mutants are green enough, run
serially beneath the audit root.

For every child:

```text
umask 022 before launch
child numerical umask must be 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Verify every target exists.

Run:

1. selected repaired causal nodes;
2. Capability:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   ```
3. B1:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```
4. RW0/status:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   ```
5. owner/static compatibility:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_rw0_b2_wire_boundaries.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   ```

Every credited run must have:

- return code 0;
- zero failures/errors/skips/xfails/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate or unmapped cases;
- matching caller/child umask;
- unchanged candidate fingerprint.

If all inspection and focused validation remain green, run the complete
repository suite exactly once independently with ordinary quiet rendering.

Require:

```text
4905 collected
4905 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

If a deterministic material blocker is found first, the full suite may be
withheld. State that explicitly. Never repair candidate bytes.

PUBLIC, IMPORT, PRIVACY, AND AUTHORITY BOUNDARY

Require:

- no source or documentation byte changed from the opening test-oracle target;
- no reverse imports;
- no package-root export;
- no production caller change;
- no dependency, SQL, migration, schema, catalog, `StateStore`, or
  `WriterSession` change;
- no filesystem, process, network, provider, Bridge, ES-call, Git,
  publication, or runtime effect;
- no weakening of accepted Capability or B1 production semantics;
- no weakening of current B1 or RW0 documentation truth;
- Capability remains private pure supplied-fact semantics;
- source refs/digests remain unauthenticated evidence;
- no permission, acceptance, durable truth, or runtime authority;
- C/D/E and ES remain later owners.

CLOSEOUT

After removing only audit-created transient artifacts:

1. rerun the exact recipe twice with safe sink redirection;
2. require exact equality to the opening final target;
3. require the same manifest, complete output, textual diff, file count,
   per-path hashes, and topology;
4. compare final-repair evidence opening and closing inventories;
5. verify the preceding audit evidence index remains unchanged;
6. verify no operation, lock, staged/unmerged path, cache, bytecode, database,
   journal, archive, build, recorder, or generated-manifest residue;
7. retain all audit evidence beneath the new mode-0700 root;
8. make retained audit files regular, operator-owned, and mode 0400;
9. create a self-excluding evidence index.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low candidate defect remains;
- `BLOCK` for any repairable test, evidence, validation, privacy, authority, or
  regression-oracle defect;
- `REJECT` only for a fundamental accepted-architecture contradiction;
- `AUDIT_PROVENANCE_MISMATCH` only for target/evidence identity failure before
  correctness judgment.

If `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_FINAL_TEST_ORACLE_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or create a PR.

FINAL REPORT

Include:

1. opening and closing identity;
2. exact provenance and four-entry delta;
3. final repair evidence and preceding audit evidence verification;
4. four audit perspectives and disagreements;
5. severity-ranked finding ledger;
6. canonical-reason identity result and mutant ledger;
7. thirteen-relation independent literal/ledger result and mutant ledger;
8. B1 complete-owner-oracle result and placement/structural mutant ledger;
9. RW0 complete-status-oracle result and placement/structural mutant ledger;
10. implementation-attempt evidence assessment;
11. node comparison and literal additions;
12. independent focused/full validation;
13. public/import/privacy/authority assessment;
14. closeout guards;
15. separate provenance, validation, and implementation confidence.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
