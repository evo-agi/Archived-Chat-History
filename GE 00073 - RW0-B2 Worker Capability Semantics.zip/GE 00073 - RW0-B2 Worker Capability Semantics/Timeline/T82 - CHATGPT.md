## Engineering disposition

The recovered closeout report is now sufficient to start the fresh independent audit.

It establishes an exact audit target:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Topology:
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

Final canonical manifest:
6,430 bytes
132b7473151706f7bb257aea44efdefad04b7e2e2dab8f3ef5486e46a6e6372f

Tracked textual diff:
c3ccbcaa17c6a1140529712b414f8a002a18a76d4b8d8733ca6d63bc2deab821

Complete recipe output:
6,663 bytes
1606765a198803686184f4fff3da59f5e8a00e2d07c80744ac6a0459d46b72f4

Final nodes:
4,761

Final node-list SHA-256:
e9b1d63bc8b1545e96d9569c8a59304268c04e0a702e529ecf9f35b74e83c2d8
```

Exactly six paths changed from the preceding audit target; the other 24 remained byte-identical. The report also supplies the complete canonical manifest, literal 18-node addition list, focused-test records, and the successful 4,761-test suite.

### Evidence limitations

The implementation evidence root is usable but not fully hardened:

- it has no pre-existing self-excluding evidence index;
- 77 retained files are mode `0600` or `0644`, rather than all being `0400`;
- complete-suite attempt 001 was interrupted during an extreme verbose-rendering path;
- attempt 002 changed only pytest output flags and passed on unchanged candidate bytes.

These are not automatic candidate defects. The fresh auditor must inventory the implementation evidence root at opening and closeout, independently reproduce provenance and validation, and classify the attempt-001/attempt-002 sequence. Provenance establishes byte identity, not correctness or test sufficiency. 

Do **not** stage or commit yet. Independent audit must occur in a fresh read-only conversation against these exact bytes. 

## Fresh independent-audit handoff

Start a new read-only Codex conversation and send this complete prompt:

:chatgpt-content-reference{index="2"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Final_Reaudit_Findings_Repair_Independent_Audit_Prompt.txt

Size:
35,576 bytes

SHA-256:
33c8c7d15ec07e37f324480755e0734103a0a08774622e99b6db3fb9a5e8e2ea
```

The audit prompt requires four independent perspectives:

1. **Capability error semantics**
   - exact built-in reason admission;
   - empty inherited `BaseException.args`;
   - actual cause/context behavior;
   - honest active-exception chaining;
   - weak-registry cleanup and hostile-value retention;
   - external mutants for the previous faulty designs.

2. **All thirteen B1 relations**
   - exact two-index raw tuple mutation;
   - nested-object identity preservation;
   - normal `invalid_enum` rejection;
   - selective bypass;
   - class-wide bypass;
   - post-reconstruction original-object poisoning;
   - external mutants intended to break the checked matrix.

3. **B1 and RW0 Markdown ownership**
   - complete visible owner-region parsing;
   - number-word and numeric stale retrieval claims;
   - zero-consumer and future-Capability claims;
   - future/blocked RW0-B prose and table rows;
   - duplicate, relocated, fenced, same-title, and trailing contradictions.

4. **Provenance, evidence, validation, and authority**
   - exact six-path delta and 24-path equality;
   - implementation evidence-root limitations;
   - node identity;
   - attempt-001/attempt-002 classification;
   - imports, exports, callers, protected bytes, and later-owner seams.

If inspection and external probes are green, the auditor independently runs one complete 4,761-test suite on the final candidate. The audit returns exactly one of:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Acceptance must also return:

```text
COORDINATOR_RW0_B2_CAPABILITY_FINAL_REAUDIT_FINDINGS_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Only that result permits staging exactly the audited path set and comparing staged and committed blobs to the accepted manifest.  Any further byte change returns the work to implementation and another independent audit. 

### Sources

- Codex closeout report supplied in this turn.
- Governed Execution Codex Subagent Operating Protocol: independent audit and repair lifecycle.  
- Governed Execution Provenance Guidance: evidence limits, audit reproduction, and commit gate.  

**Confidence:** High that the candidate is sufficiently bound for a fresh independent audit. Acceptance remains deliberately unresolved; the highest-risk residuals are exception-runtime edge behavior, hidden noncausality in part of the thirteen-relation matrix, and semantic-equivalent prose that escapes the strengthened Markdown oracles.
