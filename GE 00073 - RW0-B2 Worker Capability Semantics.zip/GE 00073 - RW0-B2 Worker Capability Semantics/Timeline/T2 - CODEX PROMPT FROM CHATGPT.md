IMPORTANT SUPERSESSION NOTICE

This complete prompt supersedes the previously issued
`Coordinator RW0-B2 — read-only protocol, worker-result, and Codex-capability
freeze reconnaissance` prompt.

Do not combine the prompts. The prior prompt was not executed.

TITLE

Coordinator RW0-B2 — B1-informed read-only wire/result and capability freeze
reconnaissance

ENGAGEMENT TYPE

Read-only architecture and exact-schema reconnaissance against the current
merged Coordinator baseline.

This is not an implementation prompt. Do not edit, create, delete, format,
chmod, stage, commit, push, create or modify a PR, merge, tag, release, deploy,
install dependencies, execute migrations, run tests, invoke Codex/model/provider
runtime behavior, contact a worker/host/service/network, or modify any supporting
repository.

Use one foreground Codex parent conversation with exactly four bounded
read-only explorer agents. No nested agents. The parent must wait for all four,
preserve disagreements, inspect every load-bearing claim directly, close every
agent, verify the baseline remains unchanged, and return one reconciled design
packet.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED LIVE BASELINE

Verify before exploration and at closeout:

- branch:
  trunk_dev
- HEAD:
  02450d3c99faf0fe7b299b914afaed312421bc8b
- tree:
  0b5394c591bd277d56797794f71af954ccb93846
- sole parent:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- subject:
  feat: implement RW0-B1 pure phase-entry semantics (#3)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- worktree/index/untracked/unmerged:
  clean
- no Git operation or lock
- no repository-local cache, bytecode, database, journal, build, archive, or
  generated-manifest residue.

Do not fetch or contact a remote. The expected Git identity is a Codex-reported
post-merge overlay; live local Git must verify it.

Stop on baseline mismatch. Do not absorb unrelated work, switch branches, or
repair the repository.

WORKSTREAM

RW0-B2 — private pure protocol/result and mechanism-neutral capability
contracts after merged RW0-B1.

CURRENT REPOSITORY REALITY

Treat repository contracts and source as authoritative for current behavior:

1. RW0-A is an accepted strategic target, not an implemented runtime.

2. RW0-B1 is implemented and merged:
   - eight private immutable no-I/O value families;
   - pure relations over supplied C2A, C2B3D, Section 41, head, decision, and
     global-stop facts;
   - no source authentication, permission issuance, persistence, custody,
     transport, process, worker, model, latch, ES route, Git effect, service,
     scheduler, queue, or autonomous loop.

3. C2A/C2A1 owns the existing private semantic identities and relations:
   `WorkSpecV1`, `AttemptFenceV1`, `EffectFenceV1`, `WorkerCommandV1`,
   `DeliveryEnvelopeV1`, `WorkerObservationV1`, `CapsuleEntryV1`,
   `CandidateCapsuleManifestV1`, `CeilingsV1`, their canonical identities, and
   their owning coherence relations.

4. C2A explicitly does not implement raw JSON decoding, full-record wire
   encoding, process framing, transport wrapping, executable mechanism,
   terminal receipt, worker/process runtime, or Codex invocation.

5. C2B3D planned author delivery and Section 41 selection remain the complete
   durable/executable implemented boundary relevant to RW0.

6. RW0-C owns future guarded durable state, evidence membership/completeness,
   terminal facts, recovery, and acceptance-latch representation and atomicity.

7. RW0-D owns future physical custody, bearer handling, concrete process,
   supervisor and worker mechanics, concrete Codex invocation, credential
   delivery, capsule proof, and offline executable proof.

8. RW0-E owns future live qualified-host and live mechanism proof.

9. ES retains ES-route admission, reliable submit, runtime identity, lifecycle,
   cancellation, route-owned correlations, and retained-result authority.

10. No public package export or production caller exists for B1.

COMPLETED B1 EVIDENCE — DESIGN DISCIPLINE, NOT A REQUEST TO REOPEN B1

Do not modify or reevaluate accepted B1 bytes. Use the completed B1 chain as
engineering evidence about what “freeze complete” must mean.

B1 preserved its ownership split, but four independent audit BLOCK cycles found
material omissions after an apparently exact schema freeze. The finding classes
included:

- strict subordinate narrowing and complete parent/attempt/current-fence
  containment;
- current head, stop, effect, semantic-attempt, originating-attempt-fence,
  candidate-ref, and command-ref/digest lineage;
- retrieval proposal/custody/authority binding, event-ref uniqueness,
  predecessor identity, immutable expiry, terminal no-retry, and shared-budget
  composition;
- host qualification relation completeness and precedence;
- canonical integer behavior before JSON conversion;
- privacy guards across every applicable safe-ref surface;
- cumulative traversal work, called-helper charging, shared-DAG aliases, and
  even caller-key scanning before construction budgets;
- causal test oracles that separately exercise the intended field or nested
  value instead of passing through an earlier validator.

Therefore:

1. A complete field list, large test matrix, green full suite, or exact
   provenance is not proof that B2 semantics are freeze-complete.

2. Every B2 relation must enumerate the complete identity and authority
   containment it depends on. Do not rely on an unstated caller order such as
   “qualification runs only after validation.”

3. Every parser and relation budget must include all work before and during:
   cardinality preflight, key scanning, duplicate detection, UTF-8 decode,
   JSON parsing, canonical re-encoding, nested value reconstruction, helper
   composition, relation comparison, and repeated aliases.

4. Every causal test must isolate one predicate, hold unrelated identities
   fixed, reseal only the values actually owning changed digests, and prove
   that a broken implementation would fail the test.

5. READY requires a pre-freeze contradiction matrix and external-style
   counterexamples, not merely a proposed schema and future test list.

Do not create a separate B1 evaluation artifact. Incorporate this discipline
into the normal B2 design packet.

ENGINEERING DISPOSITION — FROZEN FOR THIS RECONNAISSANCE

B2 is split into two ordered, non-colliding implementation tranches:

1. `RW0-B2-Wire`
   - hostile byte framing and canonical codec;
   - command-frame composition;
   - worker-authored result envelope and closed result grammar;
   - deterministic frame/process/result usability precedence;
   - exact representational limits and cumulative parser/relation bounds.

2. `RW0-B2-Capability`
   - provider-neutral Codex capability declaration;
   - independent capability observation;
   - pure Coordinator capability qualification;
   - exact binding to the frozen B2 wire protocol and supplied B1 host/effect
     qualification.

Do not call these new tranches `B2a`, `B2b`, or `B2c`; those names already
identify older writer/lock/session work in this repository.

The order is mandatory:

`RW0-B2-Wire` precedes `RW0-B2-Capability`.

Capability claims must bind an exact, already frozen wire/result protocol
identity. Combining the two would mix hostile parser correctness with
authority-adjacent capability evidence and would prevent independent audit of
the protocol that the capability claims support. Splitting wire framing from
worker-result grammar is also rejected: those two surfaces share one byte
grammar, one result-usability precedence, one canonicalization policy, and one
size/work proof.

No implementation prompt may be issued until this reconnaissance freezes both
tranches exactly. The first later implementation tranche will be
`RW0-B2-Wire`.

EXACT B2 CAPABILITY CONTRIBUTION

The design packet must preserve these decisions unless repository evidence
proves a concrete owning-contract contradiction.

A. Command frame

One versioned command frame carries exactly:

- one complete existing `WorkerCommandV1` mapping; and
- one complete existing `DeliveryEnvelopeV1` mapping.

It carries no B1 value, raw WorkSpec, raw selected plan, raw fence/grant,
candidate bytes, capsule bytes, bearer, credential, prompt, transcript, JSONL,
host data, endpoint, absolute path, environment value, or provider/account
metadata.

Rationale to verify:

- `WorkerCommandV1` owns semantic command identity;
- `DeliveryEnvelopeV1` owns delivery/route correlation and remains distinct
  from command identity;
- `WorkerObservationV1` binds both command and delivery coordinates;
- command-only framing would force a later adapter to invent an out-of-band
  delivery identity;
- B1 phase-entry and host qualification remain pre-launch gates and are not
  worker protocol payloads.

B. Frame identity

The outer frame has no semantic identity and no in-band self-digest.

- frame magic, version, kind, and length are transport structure;
- nested C2A/B2 values own semantic identities;
- a later owner may hash retained raw frame bytes as evidence, but that hash is
  not a command, delivery, observation, permission, or acceptance identity.

Stop and return BLOCK if an owning contract requires the outer frame to become
a competing semantic identity.

C. Worker result

The worker-result frame carries one private B2 result envelope whose semantic
content is limited to an ordered closed tuple of existing
`WorkerObservationV1` mappings authored by `source_kind="worker"` for the exact
command/delivery/invocation.

The initial target grammar to verify is:

- exactly one `worker_started`;
- zero or one `candidate_captured`;
- exactly one `worker_completed`;
- strict order:
  `worker_started → [candidate_captured] → worker_completed`;
- no duplicate kind;
- exact common source invocation, delivery, command, attempt, effect, fence,
  and candidate binding where applicable.

The reconnaissance must accept, revise, or block this exact grammar from owning
C2A evidence. It must not widen C2A source or observation enums merely to make
the grammar convenient.

The result frame contains no:

- adapter-authored delivery outcome;
- process exit code, signal, deadline, cancellation acknowledgement, or
  cancellation rejection;
- capsule-builder/store, validator, reviewer, model, or custodian fact;
- B1 `RW0TerminalOutcomeV1`;
- C2B decision;
- RW0-C durable terminal fact or latch postimage.

A valid worker result remains source evidence. It never means semantic success,
acceptance, authority, or process success.

D. Process/result precedence

B2-Wire may define a pure deterministic classifier over:

- decoded worker-result evidence; and
- separately supplied existing adapter-authored `WorkerObservationV1` process,
  deadline, cancellation, and delivery facts.

It must not author those process facts.

The required ordering to freeze or source-groundedly revise is:

1. representational/resource violation that prevented bounded protocol
   processing;
2. active deadline, signal, or cancellation/process termination fact;
3. missing, truncated, duplicate, trailing, malformed, noncanonical, or
   relation-inconsistent result frame;
4. contradiction between a valid result frame and supplied process facts;
5. valid usable worker result.

Required non-implications:

- exit zero does not prove a valid result;
- nonzero exit does not become a worker-authored result;
- EOF does not prove completion;
- cancellation acknowledgement does not prove signal, exit, teardown, or
  reconciliation;
- a valid frame does not override deadline, signal, cancellation, or process
  facts;
- malformed output is a protocol-evidence failure, not a C2B decision or B1
  terminal outcome.

E. Capability contract

B2-Capability uses three separate private value families unless source evidence
shows a concrete contradiction:

1. declaration by the candidate Codex implementation/artifact owner;
2. observation by an independent source;
3. pure Coordinator qualification.

Declaration cannot observe itself. Observation cannot qualify itself.
Qualification authenticates no source and grants no authority.

The capability relation must bind:

- exact worker implementation/artifact identity;
- exact B2 command/result protocol profile and version;
- exact declared and observed behavior for noninteractive input;
- bounded protocol-only stdout;
- private bounded diagnostic stderr posture by safe profile identity;
- cancellation and deadline behavior;
- ephemeral state/history posture;
- credential isolation;
- prompt/transcript/JSONL suppression or private handling;
- zero Git effects;
- network posture;
- observation freshness;
- supplied positive B1 effect/host qualification and exact effect/fence
  correlation.

B2-Capability may consume the committed B1 readiness/qualification values as
supplied evidence. It must not modify B1 semantics or rerun a partial,
inconsistent subset of B1 authority relations.

CODEX MECHANISM OWNERSHIP — RESOLVED INTERPRETATION

The B1 owner says B2 owns wire framing and “Codex mechanism.” RW0-A explicitly
defers Codex CLI versus App Server to RW0-D/RW0-E.

Use this governing interpretation:

- B2 owns the mechanism-neutral Codex capability contract, protocol
  compatibility, declaration/observation/qualification semantics, and safe
  profile identities.
- RW0-D/RW0-E own concrete CLI versus App Server selection, executable
  packaging, installation, credential delivery, invocation, stdin/stdout/stderr
  plumbing, process lifecycle, cancellation signaling, provider session
  handling, and offline/live proof.

Do not edit accepted B1 solely to reword this projection. The new B2 governing
document must state the narrower interpretation and preserve RW0-A.

Select a concrete mechanism in B2 only if owning repository contracts
unambiguously require an architecture revision. In that case return
`RW0_B2_RECONNAISSANCE_BLOCKED`; do not silently encode CLI/App Server in a
value field, enum, schema ID, profile name, or fixture.

CAPS AND BOUNDS POLICY

Do not freeze plausible round numbers.

For every frame kind, payload, collection, nesting, parser, relation, and
capability field proposed, the packet must classify the limit as:

- `owner-derived`;
- `exact representational maximum`;
- `new B2 defensive policy`; or
- `later-owner process policy`.

For every limit, report:

1. the exact action or resource it protects;
2. the owning contract or explicit new-policy rationale;
3. the largest valid current C2A/B1/B2 composition it must admit;
4. an independently reproducible calculation;
5. exact maximum and one-over counterexamples;
6. whether the limit is identity-affecting, decoder-only, relation-only, or
   later process enforcement;
7. why the limit grants no allocation, transport, execution, or effect
   permission.

Required design rules:

A. Payload lengths

- derive the exact maximum canonical payload byte length for each frame kind
  from current scalar/list/cardinality bounds and the final proposed B2 schema;
- account for worst-case UTF-8 expansion without Unicode normalization;
- choose each frame-kind payload cap from that proof, not 64 KiB, 256 KiB, or
  another round number by judgment;
- reject an over-cap declared length before allocation or payload read;
- distinguish the length-field representational range from the per-kind valid
  payload maximum.

B. Observation count

- derive the exact count from the closed result grammar;
- if the grammar above is accepted, the maximum is three and every sequence is
  enumerated;
- do not add spare count headroom.

C. Nesting depth

- derive the exact deepest valid canonical JSON structure from the final
  payload graph;
- reject deeper input before unbounded recursive expansion;
- do not select “depth 8” or another generic value without a graph proof.

D. Stderr/capture

B2 does not carry or capture stderr, stdout bodies outside the protocol frame,
transcripts, or JSONL.

- B2-Capability may bind a safe diagnostic/profile ref/digest and a finite
  assertion that stderr is private and bounded.
- The concrete numeric stderr/capture ceiling is an RW0-D process policy unless
  a current owner already defines it.
- Do not invent a B2 numeric stderr limit merely to complete a table.

E. Cumulative work

Derive one finite budget for every constructor/decoder/relation invocation from
actual occurrence counts. Include, before descent:

- header inspection;
- declared-length validation;
- UTF-8 decode;
- duplicate-key detection;
- JSON syntax and scalar parsing;
- caller key/cardinality scanning;
- canonical re-encoding;
- nested C2A/B2 reconstruction;
- relation checks;
- observation tuple traversal;
- called-helper work;
- repeated shared-DAG aliases.

An active-object set rejects cycles. Shared aliases consume work at every
occurrence unless an owning canonical representation proves safe memoization.
Maximum valid input must fit; one additional occurrence must fail
deterministically. No whole-graph budget may be asserted without an enforceable
single-budget propagation design.

A practical process cap is not a new `CeilingsV1` field. A representational
maximum is not permission to allocate, transport, launch, or retain that amount.

CANONICALIZATION AND HOSTILE DECODING

The packet must freeze exact behavior for:

- fixed magic bytes;
- protocol version;
- frame kind;
- header length;
- length-field width and byte order;
- per-kind payload maximum;
- exactly one frame;
- exact EOF and trailing-byte rejection;
- strict UTF-8;
- no BOM;
- duplicate JSON key rejection before mapping construction;
- exact built-in object/list/string/integer/null types;
- unknown before missing fields;
- no floats, booleans-as-integers, NaN, Infinity, or alternate numeric grammar;
- compact canonical JSON;
- exact object-key order policy;
- exact array order;
- `ensure_ascii` behavior;
- no NFC/NFKC or other Unicode normalization;
- canonical re-encode byte-for-byte equality;
- content-free sealed errors and suppressed foreign chains;
- deterministic error precedence.

C2A full-record Unicode code points remain exact. Section 41 normalization
helpers must not encode B2 or nested C2A bytes.

PRE-FREEZE CONTRADICTION MATRIX

Before returning READY, the parent must create and resolve one explicit matrix
covering at least:

1. outer frame identity versus existing command, delivery, observation, and
   semantic identities;

2. command-frame composition:
   command plus delivery versus command-only or additional B1/fence values;

3. worker result versus:
   - `WorkerObservationV1`;
   - adapter/OS process facts;
   - B1 `RW0TerminalOutcomeV1`;
   - existing C2B decision grammar;
   - future RW0-C durable terminal fact;

4. exit, deadline, signal, cancellation, resource, malformed-output, and result
   precedence;

5. capability declaration versus independent observation versus qualification;

6. capability qualification versus supplied B1 host/effect qualification and
   external authenticity;

7. raw stdout/stderr, prompt, transcript, JSONL, provider session, credential,
   endpoint, host, private path, environment, and bearer exclusion;

8. direct-local versus later ES route neutrality:
   - same nested C2A semantic records;
   - same B2 result grammar;
   - route-specific `DeliveryEnvelopeV1.adapter_kind`;
   - optional ES-owned outer route wrapper/correlation only;

9. C2A exact Unicode treatment versus Section 41 normalization;

10. short header, unknown version/kind, oversize declared length, truncation,
    duplicate keys, malformed JSON, noncanonical JSON, relation mismatch,
    trailing bytes, and multiple frames;

11. frame/result late, duplicate, conflicting, or mismatched invocation
    evidence;

12. every proposed bound versus the largest valid record and one-over input.

Classify each row:

- resolved inside B2;
- explicit later-owner seam that does not invalidate B2 identity/protocol; or
- blocking owning-contract contradiction.

Do not defer a contradiction that could make B2 decode two byte strings to one
identity, create a competing identity, accept a structurally contradictory
result, self-qualify a mechanism, or constrain later persistence/execution
incorrectly.

CURRENT COMPATIBILITY AND NON-GOALS

Preserve byte-for-byte:

- every C2A and B1 class, ordered field list, schema ID, digest domain, enum,
  canonical vector, error reason, relation, and bound;
- Section 41 K8/L34 and current selection semantics;
- existing package exports and public protocols;
- dependencies and `pyproject.toml`;
- migrations and application generation;
- `StateStore`, `WriterSession`, and production callers.

B2 must not:

- create SQLite rows, readers, writers, receipts, recovery, or latch behavior;
- read files, environment, clocks, processes, sockets, databases, or services;
- invoke a model or Codex;
- select CLI/App Server;
- implement custody, bearers, workspace, capsule storage, supervisor, worker,
  signal, timeout, cancellation, credential, Git, Bridge, ES, or publication
  effects;
- add package-root exports or a public API;
- encode raw WorkSpec, plan, candidate, capsule, prompt, transcript, JSONL,
  stdout/stderr body, credential, host, endpoint, path, or provider metadata;
- treat any digest, frame, declaration, observation, qualification, exit status,
  or test result as authenticity, permission, or semantic acceptance.

OBSERVABLE RESULT AND LATER CONSUMERS

The final packet must state exactly what each tranche makes observable.

`RW0-B2-Wire` must make observable:

- deterministic encode/decode of one command frame and one worker-result frame;
- exact accepted canonical bytes or one finite content-free failure;
- exact reconstruction of nested current C2A records;
- exact worker-result sequence and relation validity;
- pure result-usability classification over supplied worker/result and
  adapter/process evidence;
- no I/O, source authenticity, launch, persistence, or acceptance.

Later consumers:

- RW0-C may persist only separately designed safe frame/result refs, digests,
  ingest dispositions, and evidence membership; B2 itself persists nothing.
- RW0-D uses the codec and classifier for offline stdin/stdout and supervisor
  proof; B2 launches nothing.
- RW0-E proves the exact protocol on one live qualified host.
- a later ES conformance tranche must preserve the same nested C2A bytes and
  result grammar while ES owns its outer transport, runtime, lifecycle, and
  correlations.

`RW0-B2-Capability` must make observable:

- exact safe declaration;
- exact independent observation;
- deterministic finite qualification and reason;
- binding to one B2 protocol profile and supplied B1 host/effect qualification;
- no concrete mechanism selection, source authentication, credential handling,
  invocation, or process proof.

This work is non-disposable because without it RW0-C and RW0-D would have to
invent framing identity, malformed-output treatment, process/result precedence,
and Codex capability semantics while implementing persistence or I/O.

OBJECTIVE

Produce one reconciled RW0-B2 freeze-acceptance packet for both ordered
tranches. Do not implement.

Return `RW0_B2_RECONNAISSANCE_READY` only if:

- both tranche contracts are exact and source-grounded;
- every class, field, type, enum, domain, relation, error, byte layout, bound,
  formula, precedence rule, module, touched file, validation command, and stop
  condition is frozen;
- the contradiction matrix has no unresolved B2-internal contradiction;
- `RW0-B2-Wire` is implementation-ready as the first tranche;
- `RW0-B2-Capability` is exact enough that Wire cannot accidentally constrain
  or contradict it later.

Return `RW0_B2_RECONNAISSANCE_PARTIAL` when ownership/decomposition is sound but
any exact schema, byte, cap, formula, precedence, module boundary, or capability
relation remains proposed rather than frozen.

Return `RW0_B2_RECONNAISSANCE_BLOCKED` only for a concrete owning-contract
contradiction requiring architecture revision.

Do not treat packet size, schema count, test breadth, canonical examples, or
plausible round limits as proof of readiness.

MANDATORY SOURCE INSPECTION

Inspect together at minimum:

Repository guidance/current status:

- `AGENTS.md`
- `README.md`
- `.docs/architecture.md`
- `.docs/authority-boundaries.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/durable-state-model.md`
- `.docs/software-development-progression-boundary.md`
- `.docs/worker-execution-boundary.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/rw0-b1-pure-phase-values.md`

C2A and B1 owners:

- `.docs/c2a-first-slice-semantic-protocol-contract.md`
- `.docs/c2a1-pure-semantic-values.md`
- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `tests/c2a_contract_support.py`
- all `tests/test_worker_execution_semantic_*`
- `tests/test_c2a_relations.py`
- `tests/test_c2a_first_slice_semantic_protocol_contract.py`
- all `tests/test_rw0_b1_*`

Decision and static/public boundaries:

- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/__init__.py`
- `pyproject.toml`
- `tests/test_c2a_nonimplementation.py`
- `tests/test_runtime_non_authority.py`
- `tests/test_c2b2_development_row_value_boundaries.py`
- `tests/test_b2a_writer_session_contract.py`
- `tests/test_codex_agent_config.py`

Inspect other files only when a concrete owner, import, status assertion, or
test inventory requires them. Report where inspection stopped.

SUBAGENT WORKFLOW

Start exactly four read-only explorer agents in parallel. Because explorer
agents may not inherit full context, give each a self-contained capsule with the
repository, exact baseline, current contract, B1 evidence discipline, frozen
engineering disposition, strategic target, compatibility obligations,
non-goals, no-mutation rule, and report envelope.

No nested delegation. At most one retry if an agent fails to start. Subagents
must not run tests, invoke live tools, contact networks, or create files.

EXPLORER 1 — CONTRACT, AUTHORITY, IDENTITY, AND CONTRADICTION MATRIX

Determine and challenge:

- command plus delivery frame composition;
- no B1 value in the frame;
- frame non-identity;
- nested record authorship;
- worker-result grammar and author;
- worker result versus observation/process/delivery/terminal/decision facts;
- direct-local/ES route neutrality;
- B1 host/effect qualification consumption by capability qualification;
- concrete Codex mechanism deferral;
- all authority/privacy non-implications;
- current documentation tensions and exact future normalization.

Return a complete draft contradiction matrix with path:line evidence. Attempt
to falsify every frozen engineering decision rather than simply restating it.

EXPLORER 2 — BYTE GRAMMAR, SIZE PROOF, CANONICALIZATION, AND WORK BOUNDS

Derive exact:

- frame kinds and nested payload schemas;
- magic/version/kind/length/header bytes;
- exact per-kind maximum canonical payload lengths;
- mechanical largest-valid and one-over vectors;
- strict UTF-8 and canonical JSON behavior;
- duplicate-key handling before mapping construction;
- Unicode byte maxima without normalization;
- exact structural depth;
- exact result observation count and sequence;
- exact decoder error precedence;
- exact cumulative work formulas including all pre-traversal and helper work;
- cycle/alias treatment;
- length rejection before allocation.

Use repository-bound scalar/list limits. If any current field lacks a finite
maximum needed for an exact wire cap, identify the owning contract and return
the smallest blocking decision. Do not paper over it with a round cap.

Read-only `python3 -B` deterministic calculations are permitted only with
bytecode disabled and no repository or external file creation.

EXPLORER 3 — WORKER RESULT, PROCESS PRECEDENCE, AND CAPABILITY VALUES

Freeze or falsify:

- the exact worker observation sequence;
- result-envelope fields and identity;
- whether a result-envelope digest is needed without making the outer frame an
  identity;
- invocation, delivery, command, attempt, effect, fence, and candidate
  bindings;
- valid/invalid/late/duplicate/conflicting result behavior;
- process/deadline/signal/cancellation/result precedence using supplied C2A
  observations;
- exact declaration, independent observation, and qualification classes;
- exact capability fields, enums, nullable rules, freshness, reasons, and
  precedence;
- exact binding to B2 protocol identity and supplied B1 qualification;
- safe profile refs versus later physical/numeric D/E policy;
- no CLI/App Server selection.

Do not widen C2A enums. If the proposed result grammar cannot be expressed with
current worker-authored observations, classify whether B2 needs a new private
envelope only or whether C2A itself would require revision.

EXPLORER 4 — MODULES, TOUCHED FILES, TEST CAUSALITY, VALIDATION, AND PROVENANCE

Decide:

- exact module count and import direction for both tranches;
- exact proposed source/doc/test paths;
- exact existing static/public/status tests needing edits;
- exact maximum touched-file allowlist per tranche;
- protected files;
- no-I/O AST/import rules;
- literal independent vectors and byte fixtures;
- parser and relation mutation controls;
- B1-informed one-field causal tests;
- node collection and exact delta rules without inventing a count;
- isolated focused/full-suite commands;
- artifact cleanup;
- provenance and fresh-audit plan;
- stop conditions.

Assume static source/import inventories may require collateral test edits;
identify them now rather than treating a later full-suite failure as surprising.

STANDARD SUBAGENT REPORT

Each explorer returns:

```text
SUBAGENT REPORT

Role:
Assigned scope:
Baseline observed:
Files/documents inspected:

Claim ledger:
- ID:
  Type: evidence | inference | uncertainty
  Claim:
  Source: repo-relative-path:line
  Implication:
  Required docs/source/tests impact:
  Confidence:

B1 evidence applied:
Current contracts/invariants:
Strategic target and reopened seams:
Frozen decisions supported:
Frozen decisions falsified:
Contradiction-matrix rows:
Exact proposed schemas/bounds where in scope:
Rejected alternatives:
Likely touched surfaces:
Validation/provenance:
Risks/unresolved uncertainty:
Scope not inspected:
Mutation performed: no
Commands with side effects performed: no
Nested subagents created: no
```

PARENT RECONCILIATION REQUIREMENTS

The parent must:

1. wait for all four explorers;
2. identify failed/retried agents;
3. preserve disagreements and minority findings;
4. inspect every load-bearing claim directly;
5. distinguish repository fact, Codex-reported merged identity, strategic
   target, and inference;
6. reconcile the complete contradiction matrix;
7. compute or reproduce every size/work formula;
8. reject any test oracle that follows production constants for its expected
   field inventory, bytes, cap, or precedence;
9. state where inspection stopped;
10. close all agents;
11. verify HEAD and status remain unchanged;
12. perform no mutation.

REQUIRED FINAL PACKET

If READY, return one implementation-ready freeze packet containing:

1. exact baseline and inspection boundary;
2. current contract, strategic target, reopened seams, and B1 evidence applied;
3. adopted `RW0-B2-Wire → RW0-B2-Capability` decomposition and rejected
   alternatives;
4. exact observable result and later-consumer ledger;
5. exact class inventory for both tranches:
   - class names;
   - schema IDs;
   - ordered fields;
   - exact external/stored built-in types;
   - enums;
   - nullable-pair rules;
   - authors, sources, consumers;
   - identity exclusions and domains;
6. exact command-frame and result-frame composition;
7. exact frame byte diagram;
8. exact canonical JSON/Unicode/duplicate-key rules;
9. exact worker-result grammar and non-collapse ledger;
10. exact process/result precedence;
11. exact capability declaration/observation/qualification semantics and
    freshness;
12. exact finite content-free error algebra and deterministic precedence;
13. complete caps-and-bounds ledger with derivation classification, formulas,
    largest-valid calculations, and one-over vectors;
14. exact cumulative work/depth/cardinality budgets;
15. completed contradiction matrix with dispositions;
16. exact module/import ownership and dependency direction;
17. exact maximum touched-file allowlist for each implementation tranche;
18. exact protected surfaces;
19. exact literal test oracle and hostile-mutant plan;
20. exact future validation commands and isolation;
21. exact provenance and fresh independent-audit requirements;
22. exact stop conditions;
23. source-grounded path:line claim ledger;
24. unresolved later-owner seams and inspection limits.

READY is forbidden if any exact wire byte, capability field, bound, formula,
precedence relation, or B2-internal contradiction remains unresolved.

COMMAND POSTURE

Authorized read-only commands include:

- `git rev-parse`, `git branch --show-current`, `git status`,
  `git diff --check`, `git ls-files`, `git show`, `git log`;
- `find`, `rg`, `grep`, `sed`, `awk`, `cat`, `head`, `tail`, `wc`, `stat`;
- `python3 -B` AST or deterministic size-analysis snippets with
  `PYTHONDONTWRITEBYTECODE=1`, no project mutation, no file output, and no
  side-effectful project import.

Not authorized:

- tests or pytest collection;
- `git fetch`, pull, switch, checkout, reset, clean, add, commit, push;
- file creation or modification;
- package installation;
- migration/database creation;
- Codex/model/provider/process invocation;
- network, service, connector, Bridge, ES, IM, remote-host, or supporting-repo
  contact.

VERDICT

Return exactly one:

- `RW0_B2_RECONNAISSANCE_READY`
- `RW0_B2_RECONNAISSANCE_PARTIAL`
- `RW0_B2_RECONNAISSANCE_BLOCKED`
- `SUBAGENT_UNAVAILABLE`

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
