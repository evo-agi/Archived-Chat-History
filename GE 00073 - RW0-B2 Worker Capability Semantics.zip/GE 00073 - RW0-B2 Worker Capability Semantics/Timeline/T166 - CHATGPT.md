## Disposition

**The assurance reset is ready to implement.**

Codex made the correct architectural decision: retire the recursive self-protection machinery rather than build a fourth verifier around the third verifier. The permanent test’s proper role is to enforce finite repository and product contracts—not to defend its own functions, fixtures, constants, and code objects from arbitrary code already controlling the same Python interpreter.

The reset preserves the real contracts:

- 30 required candidate paths, all regular mode `0644`;
- P01–P13 protected-content identities;
- private package and import boundaries;
- no production Capability caller;
- dependency, schema, migration, `StateStore`, and `WriterSession` non-widening;
- pure, no-I/O, non-authoritative Capability behavior;
- compatibility in unstaged, staged, and clean committed states.

It also gives us an appropriately bounded implementation:

```text
Repository paths changed:
1

Authorized path:
tests/test_rw0_b2_capability_boundaries.py

Current boundary nodes:
110

Final boundary nodes:
19

Current whole-suite nodes:
5,150

Expected final whole-suite nodes:
5,059

Final file ceiling:
900 lines
65,536 bytes
```

The expected migration is:

```text
16 retained product-contract nodes
93 self-protection nodes removed
1 old projection node replaced
3 bounded contract nodes added
```

## Implementation handoff

Send this prompt to the **existing write-enabled Capability implementation conversation**:

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Capability_Commit_Compatibility_Assurance_Reset_Implementation_Prompt.txt

Size:
30,734 bytes

SHA-256:
92886cc353d1f2e5d501bf0ba5d1908bd6940444259a0ec6b69fedddd19cb588
```

The prompt requires Codex to:

- preserve the 16 genuine product-contract nodes;
- remove the self-source, self-AST, code-object, binding-ledger, callsite-ledger, runtime-capture, dual-gate, mutation-compiler, and encoded-carrier architecture;
- replace it with two literal tables:
  - `REQUIRED_CANDIDATE_ROWS`, R01–R30;
  - `PROTECTED_CONTENT_ROWS`, P01–P13;
- add exactly three ordinary permanent tests;
- use content-free, row-specific diagnostics;
- avoid Git status, subprocess, process execution, and repository-metadata dependencies;
- keep the final file below both hard size ceilings;
- produce the explicit 5,150→5,059 node migration;
- validate the result in live unstaged, external staged, and external clean-commit states;
- run one live and one clean complete suite;
- preserve exact one-file provenance;
- print the complete operative report inline rather than placing the core response in an inaccessible file.

The required success token is:

```text
COORDINATOR_RW0_B2_CAPABILITY_ASSURANCE_RESET_IMPLEMENTED_READY_FOR_FRESH_AUDIT
```

That token authorizes only a new read-only independent audit. The commit, push, and PR gate remains closed until that audit accepts the simplified candidate.

**Source:** Codex’s assurance-reset freeze report supplied in this turn.  
**Confidence:** High that the reset has the correct trust boundary, preserves the substantive contracts, and can be implemented safely within the single authorized test file.
