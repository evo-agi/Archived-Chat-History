## Engineering disposition

**The `BLOCK` is valid, but it does not reopen the registry architecture. Proceed with one bounded two-test-file repair plus corrected external migration evidence.**

The audit accepted the substantive reset:

- Both registries are exact and correctly owned.
- The B1-to-RW0 projection direction is correct.
- Production, documentation, public, privacy, and authority boundaries are unchanged.
- The finite parser architecture is sound in principle.
- The deliberate node migration and alias removal reconcile, apart from one missing rename target.

The remaining defects are localized:

1. **The cross-document B1 test duplicates the B1 parser and implements visibility/location differently.** It must reuse the canonical B1 parser rather than maintain a second grammar.
2. **The canonical B1 location test recognizes only raw `## ` headings.** It must recognize visible ATX H2 headings with zero through three leading ASCII spaces and either a space, tab, or end-of-line delimiter.
3. **The RW0 fence cases are non-causal.** They must be placed so registry visibility alone determines the result, and deliberately broken visibility implementations must flip each result.
4. **The migration ledger lacks the explicit rename target.** This is an evidence-generation defect, not a repository-source defect.

No new reconnaissance is needed.

## Frozen repair boundary

Only these repository paths may change:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The other 28 candidate entries remain byte-identical. No source or documentation file may change.

Final topology remains:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
```

### B1 parser decision

`test_rw0_b1_boundaries.py` becomes the sole test-side B1 registry parser owner. The cross-document projection test must reuse that parser through a normal deterministic test-module import.

The repair must not:

- maintain another copied B1 grammar;
- use dynamic import or source execution;
- add a shared helper file;
- introduce a production helper.

If ordinary parser reuse cannot work in every focused and full-suite invocation without circular imports or collection instability, Codex must stop rather than silently reintroduce duplicate logic.

### B1 H2 decision

The first-live-H2 recognizer is bounded to:

```text
^[ ]{0,3}##(?:[ \t]|$)
```

applied to raw literal-LF lines and only after visibility is calculated.

It must reject an earlier visible H2 with:

- zero, one, two, or three leading ASCII spaces;
- a tab delimiter after `##`.

It must continue to accept as non-H2:

- four-space-indented `##` text;
- an NBSP delimiter;
- `###` headings;
- ordinary fenced or commented H2 text.

Both the primary B1 test and cross-document projection path must produce the same projection or finite diagnostic for the visibility/location corpus.

### RW0 fence-test decision

The parser itself is protected. Only the test cases change.

Fence cases must be repositioned around the canonical registry so visibility is the sole deciding predicate:

- valid closer before registry → registry visible;
- invalid or absent closer before registry → registry hidden;
- invalid opener before registry → registry visible.

Every case must include a sensitivity mutant:

- all-visible;
- valid-closer suppressed;
- invalid closer treated as valid;
- invalid opener treated as valid.

A case receives credit only when the mutant flips the result for the intended visibility reason, not because of unrelated location, marker, table, or value failure.

### Rename-evidence decision

The regenerated external migration ledger must explicitly bind:

```text
old_node_id:
tests/test_rw0_b1_boundaries.py::test_owner_has_one_current_retrieval_maximum_and_one_current_consumer

new_node_id:
tests/test_rw0_b1_boundaries.py::test_b1_live_registry_projection
```

Every rename record must include both endpoints, and the reconciler must prove a one-to-one mapping between the opening removal and final addition.

## Repair handoff

Send this complete prompt to the **existing write-enabled Capability implementation conversation**:

:chatgpt-content-reference{index="0"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Owner_Oracle_Reset_Audit_Findings_Repair_Prompt.txt

Size:
24,311 bytes

SHA-256:
a6a46793aaa6d26cb64a657fd9f7bb1ecd177c4e1dc5ce3f5482385a4e0119f9
```

It is bound to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Opening manifest:
47ec8ecbd89aaa0924dc3d222f2292b9046d0faaabfadd4850411473aa33f51c

Opening complete recipe output:
3777b40b27cc2e13513eb08c02d77064feea6263cfc56691517531cd0d4b39b7

Opening tracked diff:
614568d397cf4eee772a25d588e31008731b326d7ac04988084018fcfc4da9aa

Opening nodes:
5,002

Opening node-list SHA-256:
11b13eebe8ff9631071da1f83a85d342b83ea4754a2c3765c0c227bf18f97a49

Latest audit evidence:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3

Latest audit index SHA-256:
26b69c39d083cd2096c8e2b47c6afbef7626d24cbd55093fcabe659be23a06bb
```

The required successful result is:

```text
COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

That result permits only a new, fresh read-only independent audit. It does not permit staging, commit, push, or PR creation.

### Source

- Codex fresh independent-audit report supplied in this turn.

**Confidence:** High that all four findings are repairable within the two-file repository boundary; high that no production or document change is justified; medium-high that canonical parser reuse and causal fence sensitivity will close the next audit, provided the test-module import is stable across isolated and complete-suite execution.
