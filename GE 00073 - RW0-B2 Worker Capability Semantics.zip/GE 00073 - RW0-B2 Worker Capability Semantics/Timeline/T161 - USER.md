Here is Codex's response:

# Outcome

The G11 findings-repair tranche is complete. All six findings—CC001, CC002, EV003, RP004, MO005, and RP006—were closed solely in [tests/test\_rw0\_b2\_capability\_boundaries.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b2_capability_boundaries.py>).

Final live and independent-clean suites each passed all 5,150 tests with zero failures, errors, skips, xfails, or warnings.

`COORDINATOR_RW0_B2_CAPABILITY_G11_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT`

# Opening and closing identity

- Repository: `/Users/ds/Repositories/Governed Execution Coordinator`
- Branch: `codex/rw0-b2-capability-semantics-v1`
- HEAD: `deec37bf08fb903d8846aa2c3232aec52fa9866e`
- HEAD tree: `ef48f5bd11244c6f703c97abb5489d19956f7a77`
- Parent: `02450d3c99faf0fe7b299b914afaed312421bc8b`
- Upstream: `origin/trunk_dev`, ahead/behind `0/0`
- Worktrees: one
- Opening candidate tree: `84cb309f477fec7a28bccf5c671d4bb68393801c`
- Closing candidate tree: `e70ff57a307539aa3e4c736913e30924e52eebb9`
- Final topology: `30/24/6/0/0`—30 candidate paths, 24 tracked and 6 untracked, no cached or unmerged entries
- Every candidate path remained a regular `0644` file; diff checks were clean
- All 176 paths outside the candidate set remained equal to HEAD
- The other 29 candidate entries remained byte-exact
- Final canonical candidate manifest: 6,431 bytes, SHA-256 `1dfd2c1d4e265972630cd74bed3fec959b3059c9bd3cc12f42a4ea1f4521a2f0`
- Final normalized authoritative fingerprint: 1,421,621 bytes, SHA-256 `56b91d039083062dbf2c7f729173c11cf2d8bf2ab17502691c01cace770d6e9d`
- Final recorder authoritative fingerprint: 7,376 bytes, SHA-256 `72ac3ac558d93ad0a24721e29fbee0880779c9eb9713c9fc96c5bdc1f0e3ea9c`
- Final light fingerprint: 1,173 bytes, SHA-256 `f105e3bb336b9c392bd32fbeeba3ac19ce48d3e0f6fb46c88765850a8f5f07c8`
- Tracked textual diff remained SHA-256 `cc91155aff703e1c54c139820f841d98135f37ee7c87a71d3b00b07a2672e2a6`; the repaired file is an existing untracked candidate path

# G11 finding closure

- **CC001 — protected-source grammar coverage:** closed with an exhaustive ordered grammar model and 11 added source-binding cases covering match capture, `while` body/orelse, `except*`, supported type aliases, class decorators/base/keyword walrus bindings, class-body `global`, attribute stores, and subscript stores.
- **CC002 — independent code sealing:** closed with literal source, AST, and recursive code-object projections, including code metadata and defaults. The old G11 code probe was 351 bytes, SHA-256 `537debd224051c77c8dbbc583162c1a00bcc84cf5b23fbdee4de6ac1dd27e0a1`.
- **EV003 — target-selection bypass:** closed by attaching preflight directly to the target and adding an independent autouse gate. Target-only and combined adversarial selections now stop during setup before the sentinel can execute.
- **RP004 — inaccurate scope provenance:** closed with a 604-row ordered, scope-accurate binding ledger.
- **MO005 — attempt allocation ordering:** closed by allocating the recorder attempt before parsing. Parser-rejected attempts 001, 031, and 032 are therefore retained.
- **RP006 — imprecise aggregate counts:** closed with exact literal counts and independently checked projections.

The opening source-observation artifact was preserved: 170,211 bytes, SHA-256 `94b5679540f15acbf6ced46968d3a9197288fc201abae8f799ca374d116e1e4e`. It recorded the former 119 module-ledger rows, 35 lexical rows, 42 callsite rows, and module AST digest `5695bf0923762a4aa2461a1b815d35e2bbdb1814ac85e4359fe7c4a941eae7ab`.

# Exact one-file delta

Only one repository path changed during this repair:

- [tests/test\_rw0\_b2\_capability\_boundaries.py](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b2_capability_boundaries.py>)
- Opening: 130,356 bytes, SHA-256 `cece5a7009a3b70ae2b7b065b7ae451c681801cd46dfa28c96bbee5279ba0490`
- Closing: 272,157 bytes, SHA-256 `82cd8d5161950f51bb862ce966772c9014c4575f408325d02113478e0144ca4a`
- Content-size increase: 141,801 bytes
- Exact opening-to-closing patch: 147,794 bytes, SHA-256 `6394e2c7a5b759ae14d165ea49811f1afacc8246952a3971a0e91a4da1e336fe`

No production source, governing documentation, dependency, migration, wire, B1, lineage, or C2A file changed.

# Target-attached preflight

The target now has both:

- An explicit `capability_boundary_preflight` pytest fixture
- An independent autouse `capability_boundary_target_gate`

The guards cover 31 protected Python callables and 60 sealed external callables. They execute for direct target-node selection as well as combined selections.

Across the final six target-only adversaries, every run produced exactly one setup error and no sentinel execution. Across the six combined runs, every run stopped the target in setup; the deliberately included control test’s pass/fail behavior did not permit the target sentinel to run.

# Protected-source grammar and binding scopes

The final ordered binding ledger contains 604 rows across these exact scope kinds:

- `class`
- `comprehension`
- `function`
- `generator_expression`
- `module`

The repaired grammar accounts for assignment and binding effects in nested and less-common syntax, including match captures, loop branches, exception-group handlers, supported type aliases, class definition expressions, explicit class-body globals, and non-name stores. Ordering and scope identity are sealed, not inferred from aggregate sets.

The G11 match mutation patch was 1,128 bytes, SHA-256 `59973a1e3c3c8c81a05b737a657633f96b6d25c54c734e91a2ede72d57d14dbc`. Its final sealed mutated source was 272,919 bytes, SHA-256 `2b61cd761b6c7139b1524abcdef4d0a6ea0f9345d45b9a6c4efa6bb44cc989fc`.

# Independent source and code seals

The test carries 253,954 bytes of literal expectations, SHA-256 `a4b06943a3cf2f602ddfe4013c89f21047107f6be175bcf984766223ef7469a9`.

Protection independently covers:

- Exact source bytes
- Parsed AST structure
- Recursive code-object structure
- Code metadata, constants, names, variables, defaults, and related callable state
- Ordered binding and callsite provenance
- Independent module-global expectations

The final AST evidence artifact was 4,144,187 bytes, SHA-256 `95df411ab10b3ee411015f01a79839626fab2bfb3f1a99241710a10e76b06f7c`.

# Ordered callsite and path provenance

The final callsite ledger contains 494 ordered rows. It preserves path identity and order instead of reducing observations to unordered membership.

The G11 source probe was 2,606 bytes, SHA-256 `2e3e083faa837b0f94884e52b282beaf678d5e713561f8aea7656cc8d33907af`.

The exact G9 sink patch was 572 bytes, SHA-256 `5978f34472fe82ac4f7b67bf8570996f462a6fd86b89260a058732c05100fde8`.

# Independent module-global expectations

Sixteen module-global expectations are independently sealed. They are not derived from the live values under test, the binding ledger, or the callsite ledger during verification.

This closes the former route through which rebinding or removing a supporting fixture/global could evade a target-only selection.

# Causal executable and mutation results

The mandatory test-first run, attempt 012, collected 24 tests and produced 15 intended failures, with zero errors, skips, xfails, or warnings and empty stderr.

The final sealed adversarial matrix used six independently prepared repositories:

1. Exact G9 sink mutation
2. Exact G11 match-binding mutation
3. Protected code replacement
4. Required dependency removal
5. Fixture rebinding
6. Fixture unavailability

Attempts 123–128 were target-only. Each failed in setup before the sentinel.

Attempts 129–134 were combined selections. Each contained two cases and one target setup error; the sentinel remained absent.

Attempt 135 independently verified sentinel absence for all six repositories. External fingerprints stayed stable, no alternates were present, and no repository shared an inode with the source repository.

Attempt 136 then passed all 94 selected causal tests.

The historical sentinel was 3 bytes, SHA-256 `63d04dee7c50f6fb120287649c32b5e32d4e8e4fc90a9083adc98f9baac63691`.

# Preserved projection and protected-content controls

The exact 43-row projection remains:

- `R01`–`R30`
- `P01`–`P13`

It includes P12 and all eight stable mutants. The final projection was 3,986 bytes, SHA-256 `097beea4299594c1662c035c0f489644170d0161cea2a9e0cf4ba9460065d2d0`.

The historical test name `test_exact_twenty_path_ceiling_modes_and_protected_controls` remains for compatibility; its enforced candidate count is 30.

# A/B/C result

The final A/B/C sequence was attempts 141–149.

- A validated the live source-root target and projection.
- B validated a separately materialized root with an external repository fingerprint.
- C validated the committed form of that independent materialization.
- B and C both resolved to tree `e70ff57a307539aa3e4c736913e30924e52eebb9`.
- The disposable C repository commit was `5ce96dd4997d10363998741d9e0db991f42d9184`.
- Source logical-index SHA-256: `8f170467abeba2d935a917de2e057eb75635efc555f5a44bfb6cb9c77934c019`
- Source reachable-object SHA-256: `ab72f97b6c9a4f666ca5c0e1e81bac6ae4e365ca234ceb0754b521730060155b`
- No alternates were configured.
- Shared-inode count was zero.

The initial B run at attempt 105 exposed a ROOT-portability defect. It was corrected and resealed in attempts 107–111 before the final A/B/C run. No commit or staging occurred in the source repository.

# Node identity

- Opening collected-node count: 5,095, SHA-256 `f6e7929241c6adb60df081ee9e59bff050e49869f90fc54e1d1072cf9362993d`
- Final live and clean count: 5,150, SHA-256 `184bd8a792c396cfaa49486761c2b20912d39ced574591818aef0fd86beda9ce`
- Added nodes: 55
- Removed nodes: zero
- All 55 added nodes belong to the authorized test file
- Node order outside that file remained exact
- Live collection stdout SHA-256: `345a84b409cfe74c282ff70a4041372c133b79f711bd914d15eb9b758462a06f`
- Clean collection stdout SHA-256: `eb43445fecf026d6dd33ac48c2512d99f6adc3e7ea567da4951f0922978a278a`

The collection-output difference was limited to the JUnit output path.

# Focused and complete validation

Final focused validation:

- Attempt 136: selected causal tests — 94 passed
- Attempt 137: capability-boundary file — 110 passed
- Attempt 138: capability-complete set — 147 passed
- Attempt 139: B1/wire compatibility — 461 passed
- Attempt 140: architecture/status/static set — 907 passed

Complete validation:

- Attempt 160: live repository, exactly one complete run — 5,150 passed
- Attempt 161: independent clean repository, exactly one complete run — 5,150 passed
- Both had zero failures, errors, skips, xfails, and warnings
- Both had empty stderr
- Fingerprints remained unchanged

The exact verification recipe was 3,945 bytes, SHA-256 `db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`. It was run twice after cleanup. Outputs were 6,664 bytes, SHA-256 `b13119850f96413c2dd544cf7286ab48d281e8f5e817efcb7995cf056a7f827c`; manifests matched at SHA-256 `1dfd2c1d4e265972630cd74bed3fec959b3059c9bd3cc12f42a4ea1f4521a2f0`. Stderr remained empty, and the historical sink remained absent and unchanged.

# Attempt chronology and fingerprint classes

There were 169 formal attempts: 104 authoritative-candidate, 62 external-repository, and 3 light-source fingerprints. Every attempt recorded both pre- and post-fingerprints (`Y/Y`). Unmet expectations were confined to attempts 007, 009, 010, 031, 032, 035, 036, 040, 053, 058, 070, 079, 080, 081, 105, 155, 157, 158, and 167; none was credited as causal success.
```
001 recorder-invalid-fingerprint-selftest | nonzero→nonzero ✓ rc=2 | light_source_fingerprint Y/Y | —
002 verify-g10-index | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
003 verify-g11-index | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
004 opening-repository-gate | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
005 opening-exact-recipe-1 | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
006 opening-exact-recipe-2 | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
007 opening-live-collection | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | —
008 opening-live-collection-corrected | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T0/F0/E0/S0/X0/W0
009 opening-source-ast-code-observation | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | —
010 opening-source-ast-code-observation-corrected | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | —
011 opening-source-ast-code-observation-final | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
012 test-first-red-infile | nonzero→nonzero ✓ rc=1 | authoritative_candidate_fingerprint Y/Y | T24/F15/E0/S0/X0/W0
013 setup-red-external-adversaries | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
014 red-g9-target-only | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | T1/F0/E0/S0/X0/W0
015 red-g11-match-target-only | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | T1/F0/E0/S0/X0/W0
016 red-code-target-only | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | T1/F0/E0/S0/X0/W0
017 checkpoint-red-g9-target-sentinel | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | —
018 checkpoint-red-match-target-sentinel | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | —
019 checkpoint-red-code-target-sentinel | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | —
020 red-g9-combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E0/S0/X0/W0
021 red-g11-match-combined | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | T2/F0/E0/S0/X0/W0
022 red-code-combined | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | T2/F0/E0/S0/X0/W0
023 checkpoint-red-g9-combined-sentinel | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | —
024 checkpoint-red-match-combined-sentinel | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | —
025 checkpoint-red-code-combined-sentinel | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | —
026 development-syntax-after-preflight-scaffold | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
027 generate-first-literal-observations | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
028 regenerate-literals-after-external-seal-completion | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
029 regenerate-literals-for-compressed-literal-carrier | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
030 install-independent-literal-observations | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
031 regenerate_literals_after_causal_updates | zero→nonzero ✗ rc=2 | light_source_fingerprint Y/Y | —
032 <missing> | None→nonzero ✗ rc=0 | light_source_fingerprint Y/Y | —
033 regenerate_literals_after_causal_updates | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
034 install_regenerated_literals | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
035 target_only_preflight_development | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
036 diagnose_initial_preflight_failure | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | —
037 diagnose_preflight_diagnostics | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
038 regenerate_literals_after_structural_fix | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
039 install_literals_after_structural_fix | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
040 target_only_preflight_after_structural_fix | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
041 capture_pytest_rewritten_code_digests | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T0/F0/E0/S0/X0/W0
042 extract_pytest_rewritten_code_digests | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
043 regenerate_literals_with_rewritten_code | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
044 install_literals_with_rewritten_code | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
045 target_only_preflight_with_rewritten_code | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T1/F0/E0/S0/X0/W0
046 current_g12_causal_tests | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T24/F0/E0/S0/X0/W0
047 capture_rewritten_code_after_external_seal | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T0/F0/E0/S0/X0/W0
048 recapture_rewritten_code_after_bytes_parse | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T0/F0/E0/S0/X0/W0
049 extract_expanded_rewritten_code | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
050 regenerate_expanded_literals | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
051 install_expanded_literals | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
052 target_only_expanded_preflight | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T1/F0/E0/S0/X0/W0
053 capture_rewritten_code_after_dual_gate | zero→nonzero ✗ rc=3 | authoritative_candidate_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
054 recapture_rewritten_code_for_dual_gate | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T0/F0/E0/S0/X0/W0
055 extract_dual_gate_rewritten_code | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
056 regenerate_dual_gate_literals | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
057 install_dual_gate_literals | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
058 dual_gate_target_and_causal_development | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | T56/F1/E0/S0/X0/W0
059 regenerate_literals_after_dependency_test_fix | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
060 install_literals_after_dependency_test_fix | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
061 dependency_removal_control_after_fix | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T1/F0/E0/S0/X0/W0
062 all_g12_causal_development_after_fix | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T56/F0/E0/S0/X0/W0
063 setup_final_external_adversaries | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
064 final_g9_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
065 final_match_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
066 final_code_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
067 final_dependency_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
068 final_fixture_rebound_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
069 final_fixture_unavailable_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
070 verify_final_target_only_sentinel_absence | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | —
071 verify_final_target_only_sentinel_absence_retry | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
072 final_g9_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
073 final_match_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
074 final_code_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
075 final_dependency_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
076 final_fixture_rebound_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
077 final_fixture_unavailable_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
078 verify_final_combined_sentinel_absence | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
079 final_selected_causal | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | T94/F6/E0/S0/X0/W0
080 final_selected_causal_after_legacy_scope_fix | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | T94/F1/E0/S0/X0/W0
081 final_selected_causal_after_legacy_mutator_fix | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | T94/F1/E0/S0/X0/W0
082 final_selected_causal_frozen_candidate | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T94/F0/E0/S0/X0/W0
083 setup_frozen_external_adversaries | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
084 frozen_g9_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
085 frozen_match_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
086 frozen_code_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
087 frozen_dependency_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
088 frozen_fixture_rebound_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
089 frozen_fixture_unavailable_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
090 frozen_g9_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
091 frozen_match_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F0/E1/S0/X0/W0
092 frozen_code_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F0/E1/S0/X0/W0
093 frozen_dependency_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
094 frozen_fixture_rebound_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
095 frozen_fixture_unavailable_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
096 verify_frozen_executable_adversaries | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
097 final_selected_causal_post_frozen_adversaries | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T94/F0/E0/S0/X0/W0
098 final_capability_boundary_file | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T110/F0/E0/S0/X0/W0
099 final_capability_complete | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T147/F0/E0/S0/X0/W0
100 final_b1_wire_compatibility | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T461/F0/E0/S0/X0/W0
101 final_architecture_status_static | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T907/F0/E0/S0/X0/W0
102 abc_setup_external_state_b | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
103 abc_A_target | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T1/F0/E0/S0/X0/W0
104 abc_A_projection | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
105 abc_B_target | zero→nonzero ✗ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
106 abc_B_projection | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | —
107 recapture_rewritten_code_after_root_portability_fix | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T0/F0/E0/S0/X0/W0
108 extract_root_portability_rewritten_code | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
109 regenerate_literals_after_root_portability_fix | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
110 install_literals_after_root_portability_fix | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
111 root_portability_causal_after_reseal | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T2/F0/E0/S0/X0/W0
112 abc2_setup_external_state_b | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
113 abc2_A_target | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T1/F0/E0/S0/X0/W0
114 abc2_A_projection | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
115 abc2_B_target | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | T1/F0/E0/S0/X0/W0
116 abc2_B_projection | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | —
117 abc2_B_to_C_diagnostic_commit | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | —
118 abc2_C_target | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | T1/F0/E0/S0/X0/W0
119 abc2_C_projection | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | —
120 abc2_independence_and_equality | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
121 post_portability_complete_causal_development | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T94/F0/E0/S0/X0/W0
122 setup_sealed_external_adversaries | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
123 sealed_g9_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
124 sealed_match_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
125 sealed_code_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
126 sealed_dependency_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
127 sealed_fixture_rebound_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
128 sealed_fixture_unavailable_target_only | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T1/F0/E1/S0/X0/W0
129 sealed_g9_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
130 sealed_match_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F0/E1/S0/X0/W0
131 sealed_code_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F0/E1/S0/X0/W0
132 sealed_dependency_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
133 sealed_fixture_rebound_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
134 sealed_fixture_unavailable_combined | nonzero→nonzero ✓ rc=1 | external_repository_fingerprint Y/Y | T2/F1/E1/S0/X0/W0
135 verify_sealed_executable_adversaries | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
136 final_order_1_selected_causal | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T94/F0/E0/S0/X0/W0
137 final_order_2_capability_boundaries | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T110/F0/E0/S0/X0/W0
138 final_order_3_capability_complete | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T147/F0/E0/S0/X0/W0
139 final_order_4_b1_wire_compatibility | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T461/F0/E0/S0/X0/W0
140 final_order_5_architecture_status_static | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T907/F0/E0/S0/X0/W0
141 final_order_6_abc_setup_state_b | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
142 final_order_6_abc_A_target | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T1/F0/E0/S0/X0/W0
143 final_order_6_abc_A_projection | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
144 final_order_6_abc_B_target | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | T1/F0/E0/S0/X0/W0
145 final_order_6_abc_B_projection | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | —
146 final_order_6_abc_B_to_C_commit | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | —
147 final_order_6_abc_C_target | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | T1/F0/E0/S0/X0/W0
148 final_order_6_abc_C_projection | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | —
149 final_order_6_abc_verify | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
150 final_order_7_live_collection_once | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T0/F0/E0/S0/X0/W0
151 final_order_7_clean_collection_once | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | T0/F0/E0/S0/X0/W0
152 final_order_8_node_reconciliation | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
153 final_order_9_g10_index_guard | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
154 final_order_9_g11_index_guard | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
155 final_order_9_repository_and_literal_guard | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | —
156 final_order_9_remove_generated_source_cache | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
157 final_order_9_repository_and_literal_guard_retry | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | —
158 final_order_9_repository_and_literal_guard_final | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | —
159 final_order_9_repository_and_literal_guard_green | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
160 final_order_10_live_full_once | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | T5150/F0/E0/S0/X0/W0
161 final_order_11_clean_full_once | zero→zero ✓ rc=0 | external_repository_fingerprint Y/Y | T5150/F0/E0/S0/X0/W0
162 final_order_12_cleanup | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
163 final_order_13_recipe_directory_preparation | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
164 final_order_13_exact_recipe_run_1 | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
165 final_order_13_exact_recipe_run_2 | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
166 final_order_13_exact_recipe_verification | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
167 final_order_14_report_and_index_sealing | zero→nonzero ✗ rc=1 | authoritative_candidate_fingerprint Y/Y | —
168 final_order_14_recover_terminal_attempt_167 | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
169 final_order_14_report_and_index_sealing | zero→zero ✓ rc=0 | authoritative_candidate_fingerprint Y/Y | —
```

The unmet runs were preserved as evidence: malformed opening collection and observer corrections; allocated parser rejections; preflight/code-capture development; one sentinel-verifier defect; legacy compatibility corrections; ROOT portability; final cache and assertion corrections; and terminal-finalizer recovery. Attempt 156 removed only the exact ignored generated source cache. Attempt 167’s overly broad historical-mutation assertion was recovered in 168, and corrected sealing completed in 169.

# Provenance and evidence index

The retained evidence root is `/private/tmp/g12.1d9AdI`, mode `0700`, owned by `ds`. Retained files are mode `0400`.

- [Final report](/private/tmp/g12.1d9AdI/final_report.md): 55,255 bytes, SHA-256 `2ea333e97ce8a0ccb2777948995234b24a6139cfdb21ca4e085392c33ef31f2f`
- [Final G12 evidence index](/private/tmp/g12.1d9AdI/evidence_index.jsonl): 1,113 rows, 175,986 bytes, SHA-256 `f3cd841a4baaa7fd2ea85973ff9d0ce3c10dc348f686df6644321212bf123cc8`
- [Attempt manifest](/private/tmp/g12.1d9AdI/attempt_manifest.jsonl): 169 rows, 90,101 bytes, SHA-256 `96a4be81d94f691b9fc2e05757697598bed305358df0223da855bba7ab75115d`
- G10 index: 630 rows, 90,708 bytes, SHA-256 `2f6976e2197a251a5de08ac8a00f02b8d516b0fc1e0e6a89c548e8ed4d5e08b1`
- G11 index: 203 rows, 26,876 bytes, SHA-256 `551e3a149dc07cc06f6bc3f6d5e1d7dc878b3699ebe9cf756adddaede7396205`

The final index is self-excluding and was sealed last. It contains no symlink or special-file entries. The external post-seal verifier returned green twice: once within the finalizer and once through a direct read-only verification.

# Public, privacy, and authority boundary

This repair changes test/evidence enforcement only. It adds no product behavior or authority. It does not create a public API, durable mutation path, authorization issuer, execution path, worker, scheduler, service, connector, migration, or governance bypass.

INDEPENDENT\_AUDIT\_NOT\_PERFORMED\
STAGING\_NOT\_PERFORMED\_IN\_SOURCE\_REPOSITORY\
COMMIT\_NOT\_PERFORMED\_IN\_SOURCE\_REPOSITORY\
PUSH\_NOT\_PERFORMED\
PR\_NOT\_CREATED\
REMOTE\_CONTACT\_NOT\_PERFORMED\
WORKER\_OR\_MODEL\_NOT\_INVOKED\
SUPPORTING\_REPOSITORIES\_NOT\_MODIFIED\
DEPENDENCIES\_NOT\_CHANGED\
MIGRATIONS\_NOT\_CHANGED\
PUBLIC\_API\_NOT\_WIDENED\
PRODUCTION\_SOURCE\_NOT\_MODIFIED\
GOVERNING\_DOCUMENTATION\_NOT\_MODIFIED\
WIRE\_IMPLEMENTATION\_NOT\_MODIFIED\
B1\_IMPLEMENTATION\_NOT\_MODIFIED\
LINEAGE\_IMPLEMENTATION\_NOT\_MODIFIED\
C2A\_IMPLEMENTATION\_NOT\_MODIFIED

# Confidence

High confidence that the requested G11 findings are repaired and the candidate is ready for a genuinely fresh independent re-audit. Confidence is based on the exact one-file delta, sealed source/code/provenance expectations, six-repository causal adversarial matrix, portable A/B/C proof, node reconciliation, two independent 5,150-test green runs, repeated exact-recipe verification, and post-seal evidence-index verification. No independent audit is claimed here.
