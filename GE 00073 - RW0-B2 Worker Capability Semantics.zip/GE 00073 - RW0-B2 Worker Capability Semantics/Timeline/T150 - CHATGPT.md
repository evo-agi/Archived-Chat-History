Agreed. From now on, Codex prompts will require the complete operative report **inline in the chat**. File paths and evidence artifacts may be listed only as supplementary provenance; they cannot substitute for the explanation, findings, exact values, or disposition.

Send the following prompt to the same G7 conversation:

---

```text
PROMPT_ID

RW0_B2_CAPABILITY_G7_ATTEMPT_0130_INLINE_DIAGNOSTIC_V1

TITLE

Coordinator RW0-B2-Capability — report the complete inline diagnosis of G7
attempt 0130, `stable_restore_regular_to_symlink`

ENGAGEMENT TYPE

Read-only diagnosis in the same conversation that returned:

STABLE_REPLAY_STATE_MATRIX_FAILED

The failed attempt is:

label:
stable_restore_regular_to_symlink

sequence:
0130

envelope:
/private/tmp/g7.30c557/a/0130/envelope.json

Do not modify the repository, real Git index, G5, G6, G7, or any other retained
evidence.

Do not run pytest, mutation probes, node collection, A/B/C setup, cleanup,
provenance, or validation again.

Do not resume G7 yet.

CRITICAL OUTPUT RULE

Your complete substantive response must be printed inline in this chat.

Do not respond with only:

- a verdict token;
- a summary followed by file links;
- “see report”;
- “see envelope”;
- paths under `/private/tmp`;
- hyperlinks that contain the material findings.

The user and reviewing ChatGPT cannot browse `/private/tmp`.

Evidence files may be listed after the inline report as supplementary
provenance, but every fact needed to understand and decide the next step must
appear in the response itself.

Do not collapse or hide the response.

OBJECTIVE

Read:

/private/tmp/g7.30c557/a/0130/envelope.json

and every record it references.

Explain exactly why attempt 0130 failed, what was mutated, what was restored,
what remained changed, whether the source repository was affected, and whether
G7 may safely continue or must restart.

Do not infer missing evidence. Clearly identify anything unavailable.

MANDATORY INLINE CONTENT

1. Exact envelope

Paste the complete contents of:

/private/tmp/g7.30c557/a/0130/envelope.json

inline in a fenced JSON block.

Do not omit fields.

Secret values, if unexpectedly present, must be replaced with `[REDACTED]`,
with the field name and reason for redaction stated. Do not redact ordinary
paths, hashes, commands, diagnostics, or Git identities.

2. Referenced records

For every file or record referenced by the envelope, provide inline:

- absolute path;
- purpose;
- type;
- mode;
- byte size;
- SHA-256;
- whether it exists and verifies;
- all fields material to the failure.

Paste exact stdout and stderr inline in fenced blocks.

For referenced JSON records, paste the complete JSON when reasonably bounded.
When a record is very large, include every field used in the diagnosis and
state its total size and SHA-256. Do not merely link to it.

3. Attempt chronology

State, in exact order:

- the canonical fixture or external repository path involved;
- the original file type, mode, size, and SHA-256;
- the mutation applied;
- the symlink path and target;
- the expected test or helper result;
- the actual result;
- the restore operation attempted;
- the expected restored state;
- the actual restored state;
- the exact first failed predicate;
- the command, helper, or assertion that raised it.

4. Mutation classification

Determine whether the failure occurred because:

A. the intended regular-to-symlink mutant was not created correctly;

B. the mutant was correctly created and correctly rejected, but restoration
failed;

C. restoration succeeded, but a fingerprint or comparison incorrectly reported
failure;

D. a source-repository path or real index was changed;

E. only an external fixture or simulation was changed;

F. the evidence envelope is incomplete;

G. another specific cause.

Select one primary cause and explain why the alternatives do not apply.

5. Repository and fixture state

Report inline, with exact values:

Source repository:

- branch;
- HEAD;
- HEAD tree;
- topology;
- porcelain status hash;
- tracked-diff hash;
- cached-diff hash;
- logical index hash;
- candidate manifest hash;
- candidate-mutated field;
- source pre/post fingerprint equality;
- source object/ref drift, if any.

External fixture or simulation:

- root;
- Git state, if applicable;
- pre/post fingerprint hashes;
- mutated path;
- final path type;
- final mode;
- final size;
- final SHA-256 or symlink target;
- whether any residue remains.

6. Restore result

Answer explicitly:

- Was the symlink removed?
- Was the original regular file recreated?
- Were its exact bytes restored?
- Was its exact mode restored?
- Did its parent directory remain unchanged?
- Did any other path change?
- Did cleanup begin?
- Is the external fixture currently reusable?
- Is G7 currently resumable?

7. G7 progress

List every G7 phase completed before attempt 0130, including the latest completed
sequence number for each:

- bootstrap;
- recorder self-test;
- opening gate;
- recipe-copy preflight;
- opening recipe runs;
- canonical controls;
- closed-call mutants;
- protected-content mutants;
- stable-contract mutants;
- A/B/C setup and runs;
- focused pytest groups;
- node collection;
- live suite;
- clean suite;
- final guards;
- cleanup;
- final provenance;
- report;
- index.

For each phase state:

COMPLETE_AND_CREDITABLE
COMPLETE_BUT_NONCREDITED
PARTIAL
NOT_STARTED

8. Evidence completeness

State whether attempt 0130 has complete:

- argv/action identity;
- environment;
- Python identity;
- timing;
- PID;
- return code/signal;
- stdout;
- stderr;
- expected and actual result;
- pre fingerprint;
- post fingerprint;
- candidate-mutated result;
- external-fixture-mutated result;
- cleanup state.

Identify every missing field.

9. Required disposition

Return exactly one primary token:

G7_RESTORE_HARNESS_DEFECT

Use when the candidate assertion worked but external fixture restoration or
harness bookkeeping failed.

G7_STABLE_MUTANT_EXPECTATION_DEFECT

Use when the regular-to-symlink mutation exposed a defect in the repaired
boundary test or its expected diagnostic.

G7_SOURCE_REPOSITORY_DRIFT

Use when source repository bytes, logical index, candidate manifest, or
authoritative Git state changed.

G7_EXTERNAL_FIXTURE_NOT_RESTORED

Use when only the external fixture remains mutated and the failure is not merely
a comparison false positive.

G7_FINGERPRINT_COMPARISON_DEFECT

Use when restoration was exact but the comparison schema or helper falsely
reported drift.

G7_ATTEMPT_EVIDENCE_INCOMPLETE

Use when the cause cannot be determined because mandatory evidence is missing.

G7_DIAGNOSTIC_INCOMPLETE

Use only when the referenced evidence cannot be safely read.

10. Continuation disposition

After the primary token, return exactly one:

G7_EVIDENCE_ONLY_CONTINUATION_READY

Use when no tests or mutations need rerunning and only closeout/evidence work
remains.

G7_RESUME_AFTER_FIXTURE_RESTORE_READY

Use when the external fixture can be restored read-only or through a narrowly
bounded external-only action, with prior candidate validation retained.

G7_RESTART_FROM_SCRATCH_REQUIRED

Use when prior G7 results cannot be safely continued or the unconditional
chronology is broken.

CANDIDATE_TEST_REPAIR_REQUIRED

Use when repository test bytes must change.

PROVENANCE_BLOCKED

Use when source-repository or retained-evidence identity is no longer
trustworthy.

Do not authorize or perform the continuation in this response. Diagnose only.

11. Required explicit answers

Answer every question inline:

1. What exact assertion first failed?
2. What exact path was supposed to be restored?
3. What type was it before mutation?
4. What symlink target was installed?
5. Did the intended mutant produce the expected test failure?
6. Did the restore command return successfully?
7. What type did the path have after restore?
8. Did the restored bytes and mode equal the original?
9. Did the source repository change?
10. Did the real source Git index change?
11. Did only the external fixture change?
12. Is attempt 0130’s envelope complete?
13. Are attempts 0001–0129 still creditable?
14. Can G7 continue without rerunning pytest or mutation probes?
15. Does the next action belong in:
    - the same conversation as evidence-only closeout;
    - the same conversation with external-fixture restoration;
    - a fresh G7 replay;
    - or repository test repair?

FINAL RESPONSE STRUCTURE

Use these exact top-level headings:

# Primary classification

# Continuation disposition

# Exact attempt-0130 envelope

# Referenced evidence

# Failure chronology

# Source repository state

# External fixture state

# G7 phase completion

# Evidence completeness

# Required answers

# Recommended next boundary

# Confidence

The complete core report must be inline. File paths may appear only as
supplementary provenance after the relevant contents have already been included.

End with:

REPOSITORY_MUTATION_NOT_PERFORMED
REAL_INDEX_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
NODE_COLLECTION_NOT_RUN
MUTATION_PROBES_NOT_RUN
THREE_STATE_SIMULATION_NOT_RUN
FULL_SUITE_NOT_RUN
CORRECTNESS_AUDIT_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
```

---

This prompt makes the files supplementary and requires the entire decision-relevant record inline.

**Source:** Codex’s `STABLE_REPLAY_STATE_MATRIX_FAILED` response supplied in this turn.  
**Confidence:** High that attempt 0130 must be diagnosed before deciding whether G7 can continue or must restart.
