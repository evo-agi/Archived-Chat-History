TITLE

Coordinator RW0-B2-Wire — exact request/process schemas and final hostile-input
freeze closure

ENGAGEMENT TYPE

Finite parent-only, read-only reconciliation in the existing RW0-B2 design
conversation.

This supersedes the preceding cancellation-request closure instructions only as
to the remaining unresolved fields, work-accounting model, protocol profile,
and touched-file ceiling. Preserve every already reconciled Wire and Capability
decision.

This is not another broad reconnaissance and not an implementation prompt.
Do not create or resume subagents.

Do not edit, create, delete, format, chmod, stage, commit, push, create or
modify a PR, merge, tag, release, deploy, install dependencies, run tests or
pytest collection, invoke Codex/model/provider behavior, contact any network,
worker, host, service, Bridge, ES, IM, or supporting repository, or create
repository-local artifacts.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED BASELINE

Require before inspection and at closeout:

- branch:
  trunk_dev
- HEAD:
  02450d3c99faf0fe7b299b914afaed312421bc8b
- tree:
  0b5394c591bd277d56797794f71af954ccb93846
- sole parent:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- subject:
  feat: implement RW0-B1 pure phase-entry semantics (#3)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- worktree/index/untracked/unmerged:
  clean
- no Git operation, lock, bytecode, cache, database, build, archive, or
  generated-manifest residue.

Do not fetch or contact a remote. Stop on mismatch.

OPENING DISPOSITION

Treat the preceding response as the opening packet:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_PARTIAL
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

Accepted findings:

1. The separate cancellation-request source fact is required and does not
   require a C2A or B1 change.

2. C2A has no separate cancellation `WorkerCommandV1`. A cancel effect and its
   delivery retain the originating author command ref/digest. Wire must not mint
   another command identity.

3. `DeliveryEnvelopeV1` has no target physical process-invocation field.
   Physical process targeting remains RW0-D. Wire may bind the semantic target
   effect/fence and the known target delivery but must not claim a physical
   invocation relation absent from the owners.

4. Applicable existing adapter observations for classification are exactly:

   - `cancellation_acknowledged`
   - `cancellation_rejected`
   - `deadline_elapsed`
   - `process_exited`

   The three delivery-outcome observations are transport evidence and are not
   process/result-classifier inputs.

5. Candidate command/result maxima remain:

   - command payload: 5,898 bytes;
   - worker-result payload: 16,627 bytes;
   - command/result depth: 3/4;
   - command/result containers: 5/8;
   - command/result key pairs: 71/77.

6. Capability remains seam-bounded and does not block Wire.

7. The prospective Wire touched-file ceiling is exactly 16 paths once the
   progression-boundary test is included.

ENGINEERING CORRECTION — WORK ACCOUNTING

Do not require a synthetic counter for every fixed internal comparison.

The B1 shared-DAG findings do not mechanically transfer to this Wire design:

- Wire decoders accept exact built-in `bytes` and construct a fresh JSON tree.
  Decoder input cannot contain Python aliases or cycles.
- Wire encoders accept exact already-constructed C2A/B2 values and exact tuples,
  not arbitrary caller mappings.
- Relation functions traverse closed exact objects and closed tuples with fixed
  cardinalities. Their loops are finite implementation structure, not
  attacker-selected graph expansion.

Therefore freeze one exact hostile-input work model over only
attacker-controlled variation:

1. one unit for each of the eight header bytes inspected;
2. one unit per payload byte for each of four bounded linear phases:
   - strict UTF-8 decode;
   - JSON tokenization including duplicate-key and bounded-integer scanning;
   - canonical re-encoding;
   - byte-for-byte canonical comparison;
3. one unit per parsed key pair;
4. one unit per parsed container;
5. one unit per parsed scalar or list element;
6. one unit per supplied classifier fact occurrence.

Fixed-field C2A/B2 construction and relation checks remain mandatory but do not
consume a caller-controlled graph budget. They are bounded by exact field,
path, ceiling, evidence-list, result-sequence, adapter-kind, request, and
supplement inventories. Tests must independently enumerate those fixed loops and
prove no arbitrary mapping, list, alias, cycle, or recursive helper enters them.

This is an exact work proof, not permission to allocate or transport the cap.

Freeze these hostile-input maxima:

Command frame:

```text
header units                 8
four payload passes          4 * 5,898
key pairs                    71
containers                   5
scalar/list elements         70
total hostile-input units    23,746
```

Worker-result frame:

```text
header units                 8
four payload passes          4 * 16,627
key pairs                    77
containers                   8
scalar/list elements         169
total hostile-input units    66,770
```

The 169 result scalar/list elements include the closed maximum evidence-ref
lists in the three maximal observations.

Classifier:

```text
worker-result observations   at most 3
adapter observations         at most 4
cancellation request claims  at most 1
process supplements          at most 2
total supplied fact units    at most 10
```

Every actual occurrence is charged. The classifier rejects cardinality above
those closed inventories before traversal.

Required future controls:

- exact maximum passes;
- a test-only injected eleventh classifier fact charge fails;
- a test-only injected command work unit 23,747 fails;
- a test-only injected result work unit 66,771 fails;
- no production API accepts arbitrary mappings for encode;
- decode-produced trees are the only mappings reaching nested `from_mapping`;
- encoder exact-object inputs make shared-DAG/cycle tests inapplicable by type,
  and tests must prove that boundary rather than manufacture a generic graph
  clone.

EXACT B2 VALUES

All classes are private, final, slotted, immutable, non-pickleable, have
constant content-free `repr`/`str`, fixed `_FIELDS`, exact built-in external
types, fresh safe `to_mapping()`, one domain-separated self-digest where stated,
empty public exports, and sealed content-free errors with suppressed foreign
chains.

Use the existing C2A safe ref, digest, timestamp, exact-type, canonical JSON,
and privacy syntax. Do not import B1.

A. `RW0WireCancellationRequestObservationV1`

Schema ID:

```text
governed-execution.nwp-rw0-wire-cancellation-request-observation.v1
```

Digest domain:

```text
governed-execution.nwp-rw0-wire-cancellation-request-observation.v1.identity
```

Ordered fields:

```text
schema_id
request_observation_ref
source_kind
source_ref
source_invocation_ref
evidence_ref
evidence_digest
program_ref
program_version_ref
accepted_intent_revision_ref
work_item_ref
work_item_revision_ref
semantic_attempt_ref
candidate_ref
command_ref
command_digest
attempt_fence_ref
attempt_fence_digest
cancellation_effect_intent_ref
cancellation_effect_fence_ref
cancellation_effect_fence_digest
cancellation_delivery_attempt_ref
cancellation_delivery_envelope_digest
target_effect_intent_ref
target_effect_fence_ref
target_effect_fence_digest
target_delivery_attempt_ref
target_delivery_envelope_digest
observed_at
request_observation_digest
```

Exact enums:

```text
source_kind = direct_local_adapter | es_adapter
```

The last field is the sole self-digest and is excluded from identity bytes.

There is no cancellation command field. `command_ref` and `command_digest`
refer to the originating author command retained by the cancel effect and
delivery.

There is no target physical invocation field. The request’s
`source_invocation_ref` identifies the source invocation that issued the
request. The target is semantic only: target effect/fence plus the target
delivery known to the command/result classifier.

Relation signature, exact in substance:

```text
validate_wire_cancellation_request_relation(
    *,
    request,
    author_command,
    attempt_fence,
    author_effect_fence,
    target_effect_fence,
    target_delivery,
    cancellation_effect_fence,
    cancellation_delivery,
) -> None
```

Required checks:

1. exact types and request self-digest;
2. `source_kind` equals:
   - `direct_local_adapter` for cancellation delivery
     `adapter_kind=direct_local_bootstrap`;
   - `es_adapter` for cancellation delivery
     `adapter_kind=execution_substrate`;
3. existing `validate_delivery_relation` succeeds for target delivery and target
   effect;
4. existing `validate_delivery_relation` succeeds for cancellation delivery and
   cancel effect with the exact target fence supplied as
   `cancellation_target`;
5. cancel effect class is `cancel_effect`;
6. cancel fence’s immutable target tuple equals the supplied target effect
   intent/ref/digest;
7. all program/version/intent/work/attempt/candidate/command/fence coordinates
   exposed by the supplied exact objects agree;
8. request cancellation-delivery ref/digest agree with the supplied cancel
   delivery;
9. request target-delivery ref/digest agree with the supplied target delivery;
10. evidence/source/invocation/timestamp are safe shape only;
11. no source authenticity, request delivery, acknowledgement, rejection,
    signal, exit, teardown, reconciliation, semantic cancellation, permission,
    or acceptance is inferred.

B. `RW0WireProcessObservationV1`

Schema ID:

```text
governed-execution.nwp-rw0-wire-process-observation.v1
```

Digest domain:

```text
governed-execution.nwp-rw0-wire-process-observation.v1.identity
```

Ordered fields:

```text
schema_id
process_observation_ref
source_kind
source_ref
source_invocation_ref
evidence_ref
evidence_digest
event_kind
program_ref
program_version_ref
accepted_intent_revision_ref
work_item_ref
work_item_revision_ref
semantic_attempt_ref
candidate_ref
command_ref
command_digest
attempt_fence_ref
attempt_fence_digest
effect_intent_ref
effect_fence_ref
effect_fence_digest
delivery_attempt_ref
delivery_envelope_digest
observed_at
process_observation_digest
```

Exact enums:

```text
source_kind = supervisor | operating_system
event_kind  = resource_limit_exceeded | signal_delivered
```

The last field is the sole self-digest.

No signal number, resource measurement, PID, host, path, endpoint, handle,
credential, bearer, log, stdout, stderr, provider, or session field exists.

Relation signature, exact in substance:

```text
validate_wire_process_observation_relation(
    *,
    observation,
    author_command,
    attempt_fence,
    author_effect_fence,
    target_effect_fence,
    target_delivery,
) -> None
```

Required checks:

1. exact types and self-digest;
2. supplied target delivery/effect relation is valid;
3. all safe lineage coordinates agree with target command/fence/delivery;
4. event/source/evidence/timestamp shapes are exact;
5. no source authenticity, process action, semantic result, permission, or
   acceptance is inferred.

C. Worker-result envelope

Use one private exact value:

```text
RW0WireWorkerResultV1
```

It has no semantic ref and no self-digest. Header version/kind select its schema.

Stored fields:

```text
observations: exact tuple[WorkerObservationV1, ...]
```

Serialized payload:

```json
{"observations":[...]}
```

Allowed tuples only:

```text
(worker_started, worker_completed)
(worker_started, candidate_captured, worker_completed)
```

All observations:

- exact `source_kind=worker`;
- same `source_ref`;
- same `source_invocation_ref`;
- unique observation refs;
- unique observation digests;
- exact common command, delivery, program, version, intent, work, attempt,
  effect, attempt-fence, and effect-fence coordinates;
- capture binds the preassigned candidate;
- each existing C2A observation relation succeeds using separately supplied
  actual fences;
- tuple order is protocol order; timestamps do not establish order.

D. Process/result classification

Use one private immutable result:

```text
RW0WireProcessResultClassificationV1
```

No semantic ref and no self-digest. It is a pure result, not durable truth.

Fields:

```text
classification
reason
```

Exact classifications:

```text
usable | unusable | invalid
```

Exact reasons:

```text
usable
invalid_input
unrelated_fact
duplicate_fact
conflicting_fact
cancellation_graph_mismatch
resource_limit_exceeded
deadline_elapsed
signal_delivered
cancellation_request_pending
cancellation_acknowledged
cancellation_rejected
process_result_contradiction
process_failed
result_missing
result_invalid
process_evidence_incomplete
```

Closed classifier input inventories:

Existing adapter-authored C2A observation kinds:

```text
cancellation_acknowledged
cancellation_rejected
deadline_elapsed
process_exited
```

At most one of each kind. Acknowledged and rejected are mutually exclusive.

Other inputs:

```text
worker-result observations:  0..3 under the closed result grammar
request observation:         0..1
process observations:        0..2, one per event kind
```

Observation refs and digests are unique within each collection. Duplicate,
conflicting, wrong-invocation, unrelated, or cardinality-excess inputs are
`invalid`.

Exact precedence:

1. invalid type, cardinality, duplicate, unrelated lineage, graph mismatch, or
   contradictory input → `invalid`;
2. resource supplement → `unusable/resource_limit_exceeded`;
3. deadline observation → `unusable/deadline_elapsed`;
4. signal supplement → `unusable/signal_delivered`;
5. matching request plus acknowledgement →
   `unusable/cancellation_acknowledged`;
6. matching request plus rejection →
   `unusable/cancellation_rejected`;
7. matching request without response →
   `unusable/cancellation_request_pending`;
8. acknowledgement/rejection without matching request, or both responses →
   `invalid/cancellation_graph_mismatch` or `invalid/conflicting_fact`;
9. nonzero process exit plus a valid result →
   `unusable/process_result_contradiction`;
10. nonzero process exit without a valid result →
    `unusable/process_failed`;
11. successful exit plus missing frame →
    `unusable/result_missing`;
12. successful exit plus decode/relation-invalid frame →
    `unusable/result_invalid`;
13. valid result plus missing process exit →
    `unusable/process_evidence_incomplete`;
14. valid related result plus exactly one exit code `0`, with no higher
    condition → `usable/usable`.

C2A still owns only the integer range `-255..255`. B2 alone defines exit code
zero as successful for this classifier. This changes no C2A semantic claim.

A source-independent decode failure is a result-protocol input and is never
classified as a cancellation fact.

FRAME AND CODEC — PRESERVED EXACTLY

Header:

```text
0..3  b"NWPF"
4     version 0x01
5     kind 0x01 command | 0x02 worker_result
6..7  unsigned payload length, big-endian
```

Command payload:

```json
{"command":<WorkerCommandV1 mapping>,"delivery":<DeliveryEnvelopeV1 mapping>}
```

Result payload:

```json
{"observations":[<WorkerObservationV1 mappings>]}
```

Exact caps and structure:

```text
max framed integer             9_223_372_036_854_775_807
command payload bytes          5_898
worker-result payload bytes    16_627
command/result depth           3 / 4
command/result containers      5 / 8
command/result key pairs       71 / 77
command/result work units      23_746 / 66_770
```

The integer cap is B2 representability only. It changes no C2A/B1 value.

Encoder APIs accept exact C2A/B2 objects and exact tuples only. They do not
accept arbitrary mappings.

Decoder rules and precedence remain:

1. invalid outer input type;
2. short header;
3. bad magic;
4. unsupported version;
5. unsupported kind;
6. declared length above kind cap;
7. truncated payload;
8. trailing data;
9. invalid UTF-8;
10. BOM forbidden;
11. JSON syntax/token failure, including bounded integer-token failure;
12. duplicate key;
13. invalid root/type/scalar;
14. unknown field;
15. missing field;
16. nested C2A reconstruction/digest failure;
17. noncanonical payload bytes;
18. cross-record relation failure;
19. hostile-input work limit exceeded where a test-injected charge crosses the
    fixed kind limit.

Strict UTF-8, no normalization, no floats/constants, no bool-as-int, compact
sorted-key JSON, `ensure_ascii=False`, `allow_nan=False`, exact re-encoding, and
content-free chained-error suppression remain required.

PROTOCOL PROFILE

Freeze:

```text
profile_ref = rw0-wire-nwpf-v1
profile schema = governed-execution.nwp-rw0-wire-protocol-profile.v1
digest domain = governed-execution.nwp-rw0-wire-protocol-profile.v1.identity
```

The canonical literal manifest must bind:

- magic/version/kinds/header/byte order;
- exact integer policy;
- command/result root keys;
- payload/depth/container/key/work caps;
- result sequences;
- request/process schema IDs;
- classifier input inventories, cardinalities, classifications, reasons, and
  precedence;
- canonical JSON and decoder precedence;
- outer-frame non-identity;
- provider/mechanism neutrality.

The parent must calculate and report the exact profile digest in the freeze
packet. It is derived evidence from the frozen manifest, not source
authenticity, permission, or acceptance.

EXACT 16-PATH IMPLEMENTATION CEILING

Freeze exactly:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

No seventeenth path is authorized.

Protected byte-identical surfaces include:

- every C2A and B1 source/doc/direct test/vector;
- `tests/test_rw0_b1_boundaries.py`;
- package root and public exports;
- pyproject/dependencies;
- SQL/migrations/application generation;
- StateStore/WriterSession/public protocols;
- Section 41 and all production callers.

Wire imports existing C2A only. It does not import B1. No current production
module imports Wire.

CAPABILITY SEAM

Retain exactly:

```text
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

The profile ref/digest permits later provider-neutral Capability binding. The
new request and process values carry no provider, credential, session, host,
endpoint, concrete mechanism, or invocation selection. CLI/App Server and all
physical process behavior remain RW0-D/E.

REQUIRED FINAL FREEZE OUTPUT

Return exactly:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_READY
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

unless a concrete current owning-contract contradiction is found.

Do not return PARTIAL merely because:

- the literal profile digest is derived by arithmetic;
- fixed internal relation comparisons do not use the hostile-input meter;
- implementation has not yet produced test fixtures;
- another plausible schema could have been selected.

READY must report:

1. exact baseline and inspection boundary;
2. adoption or source-grounded rejection of every decision above;
3. exact field/type/enum/domain inventories;
4. exact function signatures and relation inputs;
5. exact profile manifest and literal digest;
6. exact byte/structure/work calculations;
7. exact classifier matrix;
8. exact 16-path ceiling;
9. exact literal future causal tests;
10. isolated validation/provenance/fresh-audit plan;
11. stop conditions;
12. path:line source ledger;
13. later RW0-C/D/E/ES seams.

If a listed field is genuinely absent from all current owners, remove only that
field, give exact path:line proof, and maintain the same ownership boundary.
If the design would require C2A/B1 mutation, raw private material, a competing
identity, provider-specific framing, or a concrete CLI/App Server choice,
return BLOCKED.

NEXT STEP

READY/BOUNDED authorizes one bounded parent-only RW0-B2-Wire implementation
prompt. It does not authorize Capability implementation.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
