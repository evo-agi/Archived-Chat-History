## Engineering disposition

**Accept the reset design and proceed with one parent-only implementation tranche on the existing Capability branch.**

The reconnaissance closes the necessary design decisions:

- The failed strategy—whole-document keyword, paraphrase, polarity, and placement inference—is retired rather than extended again.
- Each owning document gets one visible, exact, marker-bounded registry.
- The registry is the sole machine-authoritative projection for its enumerated current-status, ownership, implementation-posture, and nonclaim facts.
- Explanatory prose remains governing documentation, but the tests no longer claim to decide arbitrary semantic equivalence in prose.
- B1 remains the authoritative writer for its local `1285` work maximum, sole current Capability consumer, and local nonclaims.
- The RW0 phase-entry document remains the authoritative writer for lifecycle and cross-tranche C/D/E/ES ownership.
- The implementation remains confined to exactly four files.
- Removal and replacement of the failed NLP-specific nodes is explicitly authorized and must be captured in a complete migration ledger.

This is the right architecture reset. The latest audit results—large false-negative and false-positive rates plus duplicate mutation nodes—show that further keyword expansion would harden a fundamentally unsound test architecture rather than improve assurance.

## Exact implementation boundary

Only these paths may change:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The other 26 current candidate paths must remain byte-, type-, and mode-identical. No production source, package surface, dependency, schema, migration, `StateStore`, `WriterSession`, provider mechanism, or runtime authority is in scope.

The final dirty topology must remain:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
```

## Implementation handoff

Send this complete prompt to the **existing write-enabled Capability implementation conversation**:

:chatgpt-content-reference{index="0"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Owner_Oracle_Reset_Implementation_Prompt.txt

Size:
32,333 bytes

SHA-256:
874609a36c9e7579d8d8a98c65fec9ec1910f67029501a30941c85726205228c
```

The prompt is bound to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Opening manifest:
8d5ed37273a3583104b2fb4f5acee045d7cc18799fdda368d2628e75d8807841

Opening complete recipe output:
e813ead384d3c88eb897d996c32b93245841279e31c002558c12dc36e9611d0c

Opening nodes:
5,114

Opening node-list SHA-256:
f3d83ce79954e7296b9406da6fcaa84a6676284d9504c7a9c30292d92c8fe8ae
```

## What the prompt implements

The B1 registry is inserted as the first H2 before `## Closed value grammar`. It owns the `1285` retrieval maximum, the sole current Capability consumer, and B1-local nonclaims. Its lifecycle and future-owner rows are explicitly labeled projections from the RW0 owner.

The RW0 registry is inserted as the first live H2 after `COORDINATOR_RW0_PHASE_ENTRY_CONTRACT_BEGIN`. It contains exact rows for:

```text
RW0-B1
RW0-B2-Wire
RW0-B2-Capability
RW0-C
RW0-D
RW0-E
Execution Substrate
```

It records lifecycle, contract class, authority owner, detail contract, authority posture, implementation posture, and explicit nonclaims.

Both registries use exact source-line grammar, fixed row order, version `1`, and unique BEGIN/END markers. The parsers intentionally do **not** implement general Markdown rendering or natural-language inference.

The parser contract covers only the finite mechanics needed to protect the registries:

- strict UTF-8 without BOM;
- literal-LF splitting;
- exact ASCII registry lines;
- exact heading and marker uniqueness;
- bounded backtick/tilde fence visibility;
- exact table shape, row order, and values;
- finite content-free diagnostics;
- one-way B1 projection checks against the RW0 registry.

## Deliberate test migration

The prompt does not preserve the current 5,114 nodes by inertia.

It requires a pre-edit migration ledger classifying every node in the two modified test files as:

```text
retain unchanged
retain with stronger finite registry assertion
rename to registry-purpose node
replace
remove as failed NLP architecture
remove as byte-identical alias
```

The latest 209 NLP-oracle nodes are explicitly retired or replaced by finite registry tests. The older NLP-specific nodes already present in the 4,905-node baseline are also identified and migrated.

The final node count is intentionally **not predeclared**. Acceptance depends on:

- no unlisted node loss;
- all nodes outside the two modified tests retaining order;
- complete old-to-new migration records;
- no duplicate mutant documents;
- every new node having a unique structural or value mutation purpose.

## Validation and audit sequence

The implementation sequence is:

```text
reproduce opening provenance
→ collect opening nodes
→ rewrite tests first
→ causal red for missing registries
→ add exact registries
→ focused registry/parser tests
→ B1 compatibility
→ Capability/Wire compatibility
→ architecture/static compatibility
→ final collection and migration-ledger reconciliation
→ one complete suite
→ double final provenance
→ fresh independent audit
```

The successful implementation token is:

```text
COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_IMPLEMENTED_READY_FOR_FRESH_REAUDIT
```

That result authorizes only a new read-only independent audit. It does not authorize staging, commit, push, or PR creation.

## Important authority boundary

The reset does **not** declare surrounding prose irrelevant. It establishes a narrower machine contract:

- The registries are machine-authoritative for their finite enumerated facts.
- Detailed prose remains the governing explanation of semantic behavior.
- Tests no longer claim they can detect every contradictory English sentence.
- Contradictory prose remains a documentation-review and governance defect, not something these finite parsers pretend to solve.

That distinction is essential: it replaces false assurance with a small, auditable contract surface.

### Source

Codex read-only owner-oracle reset reconnaissance supplied in this turn.

**Confidence:** High that the reset is implementation-ready and that the four-file ceiling is sufficient; high that production code should remain untouched; medium-high that the deliberate node migration will be accepted, provided the implementation records every removed or renamed NLP node and proves the new mutation corpus contains no duplicate documents.
