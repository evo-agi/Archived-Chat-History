## Engineering disposition

**Advance to a fresh, read-only independent re-audit. Do not enter the commit gate yet.**

This is the expected repair boundary:

- exactly two test files changed;
- the other 28 candidate entries remained byte-identical;
- all production source and governing documentation remained protected;
- all 42 mutations from the preceding audit were reproduced red and then reported closed;
- the final collection preserved all 4,905 opening nodes and added 209 nodes only in the two authorized files;
- the complete suite passed **5,114/5,114** on its first attempt;
- the final manifest and recipe output reproduced twice;
- the evidence root has a self-excluding 406-row index.

The previous audit had already concluded that production behavior and authority boundaries were sound; its remaining blockers were the completeness of the B1 and RW0 Markdown oracles, not implementation semantics.  Specifically, it found that the B1 oracle accepted out-of-region stale claims and hidden duplicate headings, while the RW0 oracle missed complete-document and exact-component contradictions. 

The closeout is sufficiently bound to begin the audit. The auditor must still recover the omitted aggregate identities—such as the exact final textual-diff and ordered-node-list hashes—from the indexed evidence rather than trusting the summary.

## Principal re-audit risks

The **209-node expansion** is now the main correctness risk. It must represent distinct causal cases, not parameterized volume or a classifier that merely recognizes its own generated mutation corpus.

The fresh audit therefore independently challenges:

- backtick and tilde fence behavior;
- ATX and Setext heading recognition;
- visible versus hidden duplicate ownership;
- complete-file semantic scanning;
- the exact 42 prior survivors;
- independently generated paraphrases and Markdown variants;
- false-positive controls for valid historical and later-owner language;
- helper circularity and vacuous parameterized cases;
- exact node preservation and evidence binding.

Green checked-in tests alone are not sufficient; the previous history shows why independent external mutants remain necessary.

## Fresh independent-audit handoff

Start a **new Codex conversation** in read-only posture and send this complete prompt:

:chatgpt-content-reference{index="2"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Complete_Markdown_Oracle_Repair_Independent_Audit_Prompt.txt

Size:
28,779 bytes

SHA-256:
348c69ca33c24b72c1d15b41c44939484e0d8254e468582b5cd46cc57e6e8cb1
```

The prompt is bound to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Final manifest SHA-256:
8d5ed37273a3583104b2fb4f5acee045d7cc18799fdda368d2628e75d8807841

Complete recipe-output SHA-256:
e813ead384d3c88eb897d996c32b93245841279e31c002558c12dc36e9611d0c

Final node count:
5,114

Final topology:
30 dirty
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

Evidence root:
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB

Evidence-index SHA-256:
225152f9cdb4e096585b97d55d6e4aa667450d1a690638d5ffcd1d4688e2e9ec
```

It requires a provenance gate before correctness inspection, four independent audit perspectives, external semantic and structural mutants, candidate-versus-clean-HEAD node comparison, focused validation, and—only if inspection remains green—one independent **5,114-test** full-suite run.

The only accepting result is:

```text
ACCEPT

COORDINATOR_RW0_B2_CAPABILITY_COMPLETE_MARKDOWN_ORACLE_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Any byte change returns the work to the implementation conversation and requires another fresh audit. Independent audit must remain separate from implementation, and the later commit gate may stage only the exact audited bytes.  

### Sources

- Prior independent audit identifying the four test-oracle defects while accepting production semantics and authority boundaries.  
- Governed Execution implementation, independent-audit, repair, and commit-gate lifecycle.  
- Codex closeout report supplied in this turn.

**Confidence:** High that the candidate is sufficiently bound for fresh re-audit; high that production and documentation should remain untouched; acceptance remains unresolved until the independent parser, semantic-mutant, false-positive, node, and validation gates complete.
