TITLE

Coordinator RW0-B2-Wire — fresh independent read-only audit of the exact
16-path implementation candidate

ENGAGEMENT TYPE

Fresh Codex conversation. Read-only independent audit.

This is not implementation, repair, commit, publication, merge, deployment, or
Capability work.

The parent and every audit subagent are read-only. Do not edit, create, delete,
format, chmod, clean repository bytes, stage, commit, push, create or modify a
PR, merge, tag, release, deploy, install dependencies, run migrations, contact
networks or remotes, invoke workers/models/providers, or modify any supporting
repository.

External audit evidence and isolated pytest scratch may be created only beneath
one new operator-owned, non-symlink, mode-0700 directory under `/private/tmp`.
Do not delete or rewrite implementation evidence.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

AUDIT VERDICT TOKENS

Return exactly one primary verdict:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

On `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_WIRE_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not repair any finding.

CURRENT REPOSITORY CONTRACT VERSUS TARGET

Current committed reality at HEAD includes:

- private C2A semantic values and relations;
- merged private RW0-B1 supplied-fact semantics;
- no RW0-B2-Wire implementation in HEAD;
- no worker/process/contact/persistence/acceptance/Capability runtime.

The uncommitted candidate is intended to add only a private, pure, no-I/O
RW0-B2-Wire source tranche.

Treat these separately:

- current authority claims come from owning committed C2A, B1, C2B3D,
  Section 41, row/value, and RW0-A contracts;
- the exact Wire contract below is the accepted strategic target for this
  candidate;
- candidate docs/source/tests are implementation under audit, not proof of the
  target;
- implementation reports, test output, manifests, and audit artifacts are
  evidence only.

EXPECTED LIVE TARGET

Require at opening and closeout:

- physical root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- subject:
  `feat: implement RW0-B1 pure phase-entry semantics (#3)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- dirty paths:
  `16`
- tracked modifications:
  `10`
- untracked additions:
  `6`
- staged/unmerged:
  `0/0`
- every candidate path:
  regular mode `0644`
- no Git operation, lock, repository cache, bytecode, database, journal,
  archive, build, generated manifest, or recorder residue
- `git diff --check`:
  clean.

Do not fetch or contact a remote.

IMMUTABLE AUDIT TARGET

Implementation evidence root:

```text
/private/tmp/rw0-b2-wire-v4.b4HlRt
```

Expected canonical manifest:

```text
/private/tmp/rw0-b2-wire-v4.b4HlRt/final_001.manifest.json
```

Expected identities:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe source bytes:
3_945

recipe source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

tracked textual-diff SHA-256:
eb2e81a99c851c78d51db1e753b896841b1ded7856400270ba6a1ffc276ea4f5

canonical-manifest SHA-256:
11cb3375a687c00c221a56a8fdd1333a64bed189c697030894ba82abdd03a10a

complete-output SHA-256:
b0bcdb23305ff910cf5b2c2a484ed56aaceb284c875df4262533d8679cef0822

file count:
16
```

Expected exact path/classification set:

Untracked additions:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

Tracked modifications:

```text
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

No seventeenth path is permitted.

EXACT RECIPE SOURCE

Decode this base64 only into the external audit root, verify exact size and
SHA-256, and keep it mode `0400`:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

The exact source historically writes:

```text
/tmp/ge-coordinator-b3a-audit-manifest-v1.json
```

Do not overwrite pre-existing evidence at that path. Execute the exact recipe
source unchanged while an external wrapper redirects only that exact
`Path.write_bytes` sink to a unique file under the audit root. Do not alter Git
reads, canonicalization, stdout, stderr, or recipe source.

PROVENANCE GATE — BEFORE CORRECTNESS INSPECTION

1. Lstat every path component for:
   - implementation evidence root;
   - expected manifest;
   - copied recipe source;
   - audit root.
2. Require safe ownership, no symlink traversal, regular manifest/recipe files,
   and a mode-0700 evidence root.
3. Verify the expected manifest’s exact bytes and SHA-256.
4. Parse canonical JSON and require exact:
   - branch;
   - HEAD;
   - upstream;
   - recipe ID;
   - textual-diff digest;
   - 16-path set;
   - classification;
   - file type;
   - mode;
   - size;
   - per-file SHA-256.
5. Compare every live candidate file with the manifest.
6. Run the exact recipe twice at opening.
7. Require both complete outputs and manifests to be byte-identical and the
   generated manifest to equal the immutable target byte-for-byte.
8. Require repository identity and status to match the expected live target.
9. Verify no protected path outside the 16-path set differs from HEAD.

On any mismatch, stop before correctness inspection with:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not infer equality from the aggregate tracked diff because six files are
untracked.

IMPLEMENTATION EVIDENCE REVIEW

After provenance passes:

1. inventory the implementation evidence root safely;
2. do not trust filenames alone;
3. identify the exact records for:
   - historical collection attempt 001;
   - continuation-opening provenance;
   - reconciliation and corrected collection;
   - final node verification;
   - Wire individual and combined gates;
   - corrected C2A/C2A1 gate;
   - B1 gate;
   - static/public gate;
   - status/docs initial failure and repaired result;
   - complete-suite attempt 001;
   - final recipe runs and guards;
4. verify each credited record’s exact argv, environment, umask, return code,
   stdout/stderr, JUnit identity, structured counts, and before/after repository
   fingerprint;
5. preserve the reported invalid nonexistent-path C2A invocation as an
   instruction/evidence event, not a candidate test failure;
6. assign no correctness credit to missing, ambiguous, overwritten, or
   unbound evidence.

Expected implementation-reported final results:

```text
candidate nodes:                    4_626
opening committed nodes:            4_566
candidate-only nodes:               60
candidate-only ownership:           four new Wire test files only
final combined Wire:                60 passed
corrected C2A/C2A1:                 637 passed
RW0-B1 compatibility:               281 passed
static/public boundaries:           105 passed
status/docs final:                  858 passed
complete suite attempt 001:         4_626 passed
```

Green implementation validation does not establish audit acceptance.

FROZEN WIRE TARGET

A. Capability and nonclaims

The candidate may implement only:

- private deterministic command/result frame codecs;
- pure relations over supplied exact C2A records and fences;
- safe unauthenticated cancellation-request and process source claims;
- a pure process/result classifier;
- a fixed local protocol profile.

It must implement no:

- source authentication;
- permission, effect authority, acceptance, or durable truth;
- worker, process, contact, transport, host, filesystem, database, network,
  provider, model, Codex, CLI, App Server, credential, session, Bridge, ES,
  Git, or publication effect;
- RW0-C persistence, recovery, evidence membership, terminal fact, or latch;
- RW0-D/E physical request delivery, process targeting, process mechanics, or
  live proof;
- Capability declaration, independent observation, qualification, or
  implementation.

B. Import and public boundary

Required direction:

```text
_rw0_wire_protocol_values.py -> existing private C2A semantic values/relations
```

Wire must not import B1. No existing production module may import Wire. There
must be:

- empty `__all__`;
- no package-root export;
- no public protocol, `StateStore`, or `WriterSession` widening;
- no dependency, schema, migration, package, or application-generation change.

C. Cancellation-request value

Class:

```text
RW0WireCancellationRequestObservationV1
```

Schema/domain:

```text
governed-execution.nwp-rw0-wire-cancellation-request-observation.v1
governed-execution.nwp-rw0-wire-cancellation-request-observation.v1.identity
```

Exact ordered fields:

```text
schema_id
request_observation_ref
source_kind
source_ref
source_invocation_ref
evidence_ref
evidence_digest
program_ref
program_version_ref
accepted_intent_revision_ref
work_item_ref
work_item_revision_ref
semantic_attempt_ref
candidate_ref
command_ref
command_digest
attempt_fence_ref
attempt_fence_digest
cancellation_effect_intent_ref
cancellation_effect_fence_ref
cancellation_effect_fence_digest
cancellation_delivery_attempt_ref
cancellation_delivery_envelope_digest
target_effect_intent_ref
target_effect_fence_ref
target_effect_fence_digest
target_delivery_attempt_ref
target_delivery_envelope_digest
observed_at
request_observation_digest
```

Exact source enum:

```text
supervisor | execution_substrate
```

Required route attribution:

```text
direct_local_bootstrap -> supervisor
execution_substrate    -> execution_substrate
```

C2A acknowledgement/rejection remain adapter-authored:

```text
direct_local_adapter | es_adapter
```

A request and response match by exact cancellation graph, not source-kind/ref/
invocation equality.

D. Process-observation value

Class:

```text
RW0WireProcessObservationV1
```

Schema/domain:

```text
governed-execution.nwp-rw0-wire-process-observation.v1
governed-execution.nwp-rw0-wire-process-observation.v1.identity
```

Exact ordered fields:

```text
schema_id
process_observation_ref
source_kind
source_ref
source_invocation_ref
evidence_ref
evidence_digest
event_kind
program_ref
program_version_ref
accepted_intent_revision_ref
work_item_ref
work_item_revision_ref
semantic_attempt_ref
candidate_ref
command_ref
command_digest
attempt_fence_ref
attempt_fence_digest
effect_intent_ref
effect_fence_ref
effect_fence_digest
delivery_attempt_ref
delivery_envelope_digest
observed_at
process_observation_digest
```

Enums:

```text
source_kind = supervisor | operating_system
event_kind  = resource_limit_exceeded | signal_delivered
```

No signal number, resource measurement, PID, host, path, endpoint, handle,
credential, bearer, log, stdout/stderr, provider, or session field is allowed.

E. Worker result

`RW0WireWorkerResultV1` stores only exact tuple observations and has no semantic
ref or self-digest.

Allowed sequences:

```text
(worker_started, worker_completed)
(worker_started, candidate_captured, worker_completed)
```

Require exact worker source, common source ref/invocation, unique observation
refs/digests, complete common lineage, candidate capture binding, and existing
C2A relations using actual supplied fences. Tuple position, not timestamp,
establishes protocol order.

F. Classification result

`RW0WireProcessResultClassificationV1` has only:

```text
classification
reason
```

Classifications:

```text
usable | unusable | invalid
```

Reasons:

```text
usable
invalid_input
unrelated_fact
duplicate_fact
conflicting_fact
cancellation_graph_mismatch
resource_limit_exceeded
deadline_elapsed
signal_delivered
cancellation_request_pending
cancellation_acknowledged
cancellation_rejected
process_result_contradiction
process_failed
result_missing
result_invalid
process_evidence_incomplete
```

G. Frame and payload

Header:

```text
0..3  b"NWPF"
4     version 0x01
5     kind 0x01 command | 0x02 worker_result
6..7  unsigned big-endian payload length
```

Command payload root:

```json
{"command":<WorkerCommandV1>,"delivery":<DeliveryEnvelopeV1>}
```

Result payload root:

```json
{"observations":[<WorkerObservationV1>...]}
```

The outer frame/root has no semantic ref, digest, checksum, signature, or
competing command/result identity.

H. Exact representational bounds

```text
max framed integer             9_223_372_036_854_775_807
command payload bytes          5_898
result payload bytes           16_627
command/result whole frame     5_906 / 16_635
command/result depth           3 / 4
command/result containers      5 / 8
command/result key pairs       71 / 77
command/result scalar leaves   70 / 169
command/result hostile units   23_746 / 66_770
classifier supplied facts      at most 10
```

These are representation/admission bounds, not allocation, transport,
permission, effect, or C2A ceiling changes.

I. Canonical encoding and hostile decoding

Require:

- exact built-in `bytes` decoder input;
- exact constructed-object encoder inputs, never arbitrary mappings;
- strict UTF-8;
- no BOM;
- no floats/constants;
- bounded unsigned integer tokens before Python integer conversion;
- duplicate-key detection before ordinary dict construction;
- exact types, roots, fields, and nested C2A reconstruction;
- no Unicode normalization;
- compact sorted-key JSON with `ensure_ascii=False`, `allow_nan=False`,
  separators `(",", ":")`;
- exact canonical re-encode equality;
- exactly one frame; no trailing or concatenated data.

Decoder reason precedence:

```text
invalid_outer_type
short_header
bad_magic
unsupported_version
unsupported_kind
declared_length_over_cap
truncated_payload
trailing_data
invalid_utf8
bom_forbidden
json_token_invalid
duplicate_key
invalid_root_or_scalar
unknown_field
missing_field
nested_record_invalid
noncanonical_payload
relation_mismatch
work_limit_exceeded
```

Errors must be sealed, finite, content-free, and suppress foreign chains.

J. Hostile-input accounting

Charge:

```text
8 header units
+ four units per payload byte
+ one per parsed key pair
+ one per parsed container
+ one per scalar leaf
```

The four payload passes are UTF-8 decode, JSON tokenization, canonical reencode,
and canonical comparison.

Fixed closed relation loops need not consume the hostile meter, but tests must
prove no arbitrary mapping, alias, cycle, or recursive caller graph enters them.

K. Classifier inventory and precedence

Existing adapter facts accepted:

```text
cancellation_acknowledged
cancellation_rejected
deadline_elapsed
process_exited
```

At most one each. Request at most one. Process supplements at most two, one per
kind. Worker result has zero to three observations under its closed grammar.
Total supplied fact units at most ten.

Exact precedence:

1. invalid type/cardinality, duplicate, unrelated lineage, contradiction, or
   cancellation-graph mismatch -> `invalid`;
2. resource -> `unusable/resource_limit_exceeded`;
3. deadline -> `unusable/deadline_elapsed`;
4. signal -> `unusable/signal_delivered`;
5. request + acknowledgement -> `unusable/cancellation_acknowledged`;
6. request + rejection -> `unusable/cancellation_rejected`;
7. request alone -> `unusable/cancellation_request_pending`;
8. response without request -> `invalid/cancellation_graph_mismatch`;
9. both responses -> `invalid/conflicting_fact`;
10. nonzero exit + valid result ->
    `unusable/process_result_contradiction`;
11. nonzero exit without valid result -> `unusable/process_failed`;
12. zero exit + no result -> `unusable/result_missing`;
13. decoder/relation failure after higher process tiers ->
    `unusable/result_invalid`;
14. valid result without process exit ->
    `unusable/process_evidence_incomplete`;
15. valid related result + exactly one zero exit + no higher condition ->
    `usable/usable`.

Zero is successful exit only for this B2 classifier. It proves no semantic
acceptance.

L. Privacy

All new ref fields use C2A safe-ref grammar and independently reject
IPv4-shaped refs.

Unknown keys containing these fragments must fail
`privacy_forbidden_material`, without echo:

```text
hostname
host_key
ip_address
endpoint
username
bearer
token
secret
signature
trust_root
prompt
transcript
stdout
stderr
provider
environment_value
absolute_path
workspace_path
store_path
```

M. Fixed profile

```text
profile_ref:
rw0-wire-nwpf-v1

profile schema:
governed-execution.nwp-rw0-wire-protocol-profile.v1

digest domain:
governed-execution.nwp-rw0-wire-protocol-profile.v1.identity

canonical identity bytes:
4_021

profile digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
```

The profile is absent from frames and grants no authenticity, permission, or
acceptance.

AUDIT WORKFLOW

After provenance passes, spawn exactly four bounded read-only audit tasks in
parallel. No nested agents. Give every task the same canonical manifest
identity and a self-contained context capsule.

Task 1 — protocol, canonicalization, and hostile decoding

Inspect:

- Wire source;
- Wire governing document;
- codec/value direct tests;
- C2A constructors/canonicalization used by Wire.

Determine whether:

- exact frame and canonical bytes implement the frozen target;
- profile mapping independently reproduces 4,021 bytes and the pinned digest;
- maximum fixtures genuinely reach every stated maximum;
- maximum+1 cases isolate the intended bound;
- duplicate, malformed, UTF-8, BOM, integer, truncation, trailing,
  noncanonical, and relation failures obey exact precedence;
- parser and direct constructors bound key scans before iteration;
- work accounting charges all attacker-controlled work exactly once;
- no arbitrary mapping/shared DAG/cycle crosses encoder or fixed-relation
  boundaries;
- sealed errors remain content-free.

Return independent counterexamples, not only test review.

Task 2 — authority, privacy, identity, and ownership

Inspect:

- RW0-A ownership clauses;
- C2A/B1 owning contracts;
- Wire values and relations;
- status/authority documents and tests.

Determine whether:

- request authorship is supervisor/Execution Substrate, not adapter;
- request/response source non-collapse is preserved;
- exact cancellation target/effect/fence/delivery/command/candidate/attempt
  lineage is complete;
- source claim digests never become authentication, permission, acceptance, or
  durable truth;
- process facts remain source evidence;
- direct-local and ES remain route-neutral without absorbing ES authority;
- private material and IPv4-shaped refs are excluded at every ingress;
- no B1/C2A semantics or bytes were redefined;
- later RW0-C/D/E/ES ownership remains explicit.

Task 3 — worker-result and classifier correctness

Inspect:

- result grammar and actual C2A observation relations;
- cancellation graph relation;
- classifier implementation and tests.

Independently probe:

- every valid result sequence;
- wrong order/count/source/invocation/ref/digest/fence/candidate;
- request absent/alone/ack/reject/both/wrong graph;
- differing request/response source claims on a matching graph;
- resource/deadline/signal/request/response/exit/result precedence pairs;
- zero, nonzero, missing, duplicate, and conflicting exit facts;
- malformed or relation-invalid result under every higher process tier;
- missing result versus missing exit;
- duplicate and unrelated facts;
- all classification/reason matrix combinations.

Look for accepted invalid inputs, rejected valid inputs, incomplete relation
composition, and tie-order drift.

Task 4 — tests, status oracles, public boundary, validation, and artifacts

Inspect:

- four new test files;
- all ten modified existing paths;
- implementation evidence;
- imports/AST/public surfaces;
- Markdown owner/cross-reference structural tests;
- repository and external artifacts.

Determine whether:

- literal expected fields/enums/profile/bytes/caps/reasons are test-owned rather
  than derived from production constants;
- mutants change one predicate and reseal only the owning digest;
- every required check is causal;
- the status projection is uniquely owned, visible, unfenced, and resistant to
  fenced duplicates, relocation, same-title siblings, and trailing prose;
- no test was weakened, renamed, removed, skipped, xfailed, collapsed, or
  reparameterized;
- no package/public/production/dependency/schema/migration widening exists;
- validation evidence binds the final manifest;
- artifact and evidence-root hygiene are safe.

PARENT RECONCILIATION

Wait for all four tasks. Preserve disagreements and minority findings. Directly
inspect every material finding and reproduce counterexamples when possible.

Classify each finding by:

- severity: Critical / High / Medium / Low / Observation;
- type: authority/contract, correctness, security/privacy/availability,
  test adequacy, documentation/status, public boundary, provenance/evidence;
- patch defect versus pre-existing issue;
- current-contract violation versus strategic-target defect;
- exact path:line evidence;
- impact;
- required correction;
- uncertainty.

Do not let green tests overrule a deterministic counterexample.

INDEPENDENT VALIDATION

Only after provenance and source/probe inspection are sufficiently green to
justify execution, run serial independent validation beneath the audit root.

Use for every pytest child:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
```

Capture actual caller umask, restore it before child launch, and require the
child-observed numerical umask to match.

Run:

1. all four Wire files:
   ```text
   tests/test_rw0_b2_wire_values.py
   tests/test_rw0_b2_wire_codec.py
   tests/test_rw0_b2_wire_relations.py
   tests/test_rw0_b2_wire_boundaries.py
   ```

2. corrected C2A/C2A1 compatibility:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_c2a_first_slice_semantic_protocol_contract.py
   tests/test_c2a_effects_and_recovery.py
   ```

3. B1:
   ```text
   tests/test_rw0_b1_*.py
   ```

4. static/public:
   ```text
   tests/test_c2a_nonimplementation.py
   tests/test_runtime_non_authority.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_b2a_writer_session_contract.py
   tests/test_codex_agent_config.py
   ```

5. status/docs:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

Every executed gate must have return code 0, empty stderr, zero
failures/errors/skips/xfails/warnings, parseable JUnit, no duplicate or unmapped
case, and unchanged repository target.

NODE IDENTITY

Collect the candidate exactly once and one clean external `git archive HEAD`
exactly once.

Require:

```text
candidate:                       4_626
HEAD:                            4_566
intersection:                    4_566
candidate-only:                  60
HEAD-only:                       0
```

Require all 60 candidate-only nodes to belong to exactly the four new Wire test
files, with HEAD order preserved.

If source/probe inspection finds a blocking defect, the full suite may be
withheld. State why.

If inspection is green, run the complete repository suite exactly once and
require:

```text
4_626 collected
4_626 passed
0 failures/errors/skips/xfails/warnings
empty stderr
no duplicate or unmapped JUnit cases
unchanged target bytes
```

CLOSING GUARDS

Before verdict:

1. remove only audit-created transient pycache, pytest cache, basetemp,
   databases, journals, WAL/SHM, archives, and recorder scratch;
2. rerun the exact recipe twice;
3. require both closing manifests and complete outputs to equal opening and the
   immutable target byte-for-byte;
4. require exact 16-path topology, modes, classifications, sizes, and hashes;
5. require protected complement equality to HEAD;
6. require clean `git diff --check`;
7. require no repository residue, operation, or lock;
8. confirm no repository mutation occurred.

ACCEPTANCE STANDARD

`ACCEPT` requires all of:

- exact provenance;
- no Critical, High, Medium, or Low patch defect;
- no unresolved current-contract or accepted-target contradiction;
- complete authority/privacy/source separation;
- correct hostile decoding and classifier semantics;
- causally adequate tests;
- validated public/nonimplementation boundary;
- required independent validation green;
- closing target byte-identical to opening.

An evidence limitation may be an Observation only when independent source,
counterexample, and validation work fully supersede it. Do not accept missing
target identity or ambiguous validation binding.

FINAL REPORT

Include:

1. exact opening/closing identity and provenance;
2. per-file target comparison;
3. audit-task reports and preserved disagreements;
4. severity-ranked finding ledger;
5. contract/authority/nonclaim assessment;
6. protocol/decoder/work-budget assessment;
7. result/classifier assessment;
8. privacy/public/import assessment;
9. test causality and Markdown ownership assessment;
10. implementation-evidence assessment;
11. independent commands/results/node comparison;
12. closing guards, limits, and three separate confidence estimates:
    - provenance;
    - validation;
    - implementation.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
```
