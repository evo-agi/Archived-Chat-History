PROMPT_ID

RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_ASSURANCE_RESET_IMPLEMENTATION_V1

TITLE

Coordinator RW0-B2-Capability — replace the self-protecting boundary-test
architecture with a bounded, reviewable, state-independent permanent contract

ENGAGEMENT TYPE

Parent-only workspace-write implementation in the existing Capability
implementation conversation.

Do not create subagents. The parent is the sole repository writer.

This is a one-file checked-test reset plus fresh external validation evidence.
It is not production implementation, governing-document editing, registry
redesign, dependency installation, schema or migration work, staging, commit,
push, pull request, merge, release, deployment, provider/runtime work,
database work, or supporting-repository work.

Only the exact repository path below may change.

CRITICAL INLINE OUTPUT RULE

The complete substantive implementation and validation report must be printed
inline in the Codex chat.

Do not respond only with:

- a success token;
- a short summary plus `/private/tmp` links;
- “see report”;
- paths that contain the operative result.

Evidence paths may be supplementary only after all exact repository identities,
changed bytes, node migration, test results, A/B/C results, suite results,
provenance, and limitations have appeared inline.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Implement the frozen assurance reset:

```text
RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_ASSURANCE_RESET_READY
```

Retire the self-protecting test-verifier architecture in:

```text
tests/test_rw0_b2_capability_boundaries.py
```

and replace it with a small, ordinary, reviewable permanent test contract.

The permanent test is trusted checked-in code. It must detect finite product and
repository regressions. It is not required to defend itself against arbitrary
same-process mutation of its own functions, fixtures, globals, constants,
expected values, code objects, builtins, standard-library callables, or pytest
machinery.

External independent audit and Git/tree provenance own causal mutation testing,
A/B/C state validation, and visibility of coordinated test/oracle changes.

No production contract changes.

OPENING REPOSITORY IDENTITY

Before any edit require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644

candidate tree:
e70ff57a307539aa3e4c736913e30924e52eebb9
```

Require:

```text
git diff --check:
clean

cached diff:
empty

Git operation or lock:
none

source logical index:
unstaged

candidate symlink/special path:
none

repository cache/bytecode/database/journal/archive/build/generated-manifest/
recorder residue:
none

thirty-first changed path:
absent
```

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

OPENING TARGET

Current candidate manifest:

```text
size:
6431 bytes

SHA-256:
1dfd2c1d4e265972630cd74bed3fec959b3059c9bd3cc12f42a4ea1f4521a2f0
```

Current whole-suite node identity:

```text
count:
5150

ordered SHA-256:
184bd8a792c396cfaa49486761c2b20912d39ced574591818aef0fd86beda9ce
```

Only authorized repository path:

```text
tests/test_rw0_b2_capability_boundaries.py

kind:
untracked

type:
regular

mode:
0644

size:
272157 bytes

SHA-256:
82cd8d5161950f51bb862ce966772c9014c4575f408325d02113478e0144ca4a
```

The other twenty-nine candidate entries must remain byte-, type-, kind-, mode-,
size-, classification-, and SHA-256-identical.

Every path outside the 30-path candidate must remain equal to HEAD.

ASSURANCE RESET BASIS

The read-only freeze concluded:

```text
Permanent repository tests:
own finite product/repository assertions.

Independent audit:
owns external mutation analysis, AST review, A/B/C state validation, and
clean-commit validation.

Git/provenance:
owns exact changed paths, bytes, modes, trees, and review visibility.

Commit gate:
owns exact staging, staged tree, one collection, one complete suite, commit,
push, and PR.
```

Do not add another self-authentication layer.

EXACT REPOSITORY ALLOWLIST

Only:

```text
tests/test_rw0_b2_capability_boundaries.py
```

No second file is authorized.

Stop with:

```text
ASSURANCE_RESET_IMPLEMENTATION_BLOCKED
```

if a second file, production edit, governing-document edit, public API change,
dependency, schema, migration, StateStore, WriterSession, process, network,
provider, Git, publication, or runtime change is required.

NEW EXTERNAL EVIDENCE ROOT

Create one new short neutral root:

```text
/private/tmp/g14.XXXXXX
```

Requirements:

- operator-owned;
- non-symlink;
- mode `0700`;
- all temporary paths below this root;
- every pytest-visible path pre-screened with the exact owning privacy/path
  checker;
- retained files mode `0400`;
- retained directories mode `0700`;
- no symlink/FIFO/socket/device/special entry at closeout;
- self-excluding canonical JSONL index created last.

Preserve G12 and G13 unchanged.

EXACT RECIPE SOURCE

Locate:

```text
/private/tmp/g5.hiLE2y/exact_recipe_source.py

type:
regular

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03f3a51378362f8777c
```

The SHA-256 above is intentionally incomplete and must not be used.

The required exact recipe SHA-256 is:

```text
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Require the exact 3,945-byte source and create a verified G14-local mode-0400
copy before invocation.

Run the exact source twice at opening and twice at closeout, redirecting only
its fixed historical external sink.

BEFORE MUTATION

Record and verify:

1. exact repository identity and topology;
2. exact current manifest and every path identity;
3. every path outside the candidate equals HEAD;
4. exact recipe source and two opening recipe reproductions;
5. exact opening 5,150-node ordered list;
6. complete opening boundary-test source;
7. complete opening boundary-test AST;
8. exact opening node IDs from the boundary file;
9. exact dependency graph from retained product tests to helpers/constants in
   the boundary file;
10. exact G13 evidence index:

   ```text
   /private/tmp/g13.p4eDNA/evidence_index.jsonl

   rows excluding itself:
   345

   size:
   52102 bytes

   SHA-256:
   8145e1b2f1483ec71f8899cf132f4232d59d6795808373e27a4e76f47dba2d38
   ```

11. exact G12 evidence index:

   ```text
   /private/tmp/g12.1d9AdI/evidence_index.jsonl

   SHA-256:
   f3cd841a4baaa7fd2ea85973ff9d0ce3c10dc348f686df6644321212bf123cc8
   ```

Do not modify or clean prior evidence roots.

FILE-SIZE AND COMPLEXITY CEILING

Final file must satisfy both:

```text
maximum physical lines:
900

maximum bytes:
65536
```

Target range:

```text
600–800 lines
```

If the finite contract cannot fit within both hard ceilings, stop and return
`ASSURANCE_RESET_IMPLEMENTATION_BLOCKED`.

FINAL IMPORT BOUNDARY

The final import set must be the minimal used subset of:

```text
ast
hashlib
importlib.util
stat
sys
types
from pathlib import Path

pytest

the existing Capability module import and its five currently imported symbols
```

Remove if unused:

```text
base64
builtins
functools
inspect
json
os
textwrap
zlib
```

Do not add:

```text
subprocess
shlex
GitPython
dulwich
os.system
os.popen
os.spawn*
os.exec*
dynamic import machinery
```

A retained product test may parse product/module source with `ast`; the final
file must not parse, hash, authenticate, or emulate its own source,
call-graph, bindings, functions, fixtures, or code objects.

EXACT RETAINED CONSTANTS

Retain where used by retained product tests:

```text
ROOT
SOURCE
PACKAGE
OWNER
OWNER_BEGIN
OWNER_END
STATUS_BEGIN
STATUS_END
STATUS_PATHS
EXPECTED_STATUS
```

Do not retain a constant solely for the deleted verifier architecture.

EXACT RETAINED HELPERS

Retain where used:

```text
normalize
extract_visible_block
assert_owner_layout
_owned_capability_frame
_contains_hostile_identity
_failed_isolated_capability_import
```

Minimal cleanup/refactoring is allowed only to remove dependencies on deleted
self-protection machinery.

Do not rename a retained helper unless necessary to meet the file ceiling and
the opening/final node migration remains explicit.

EXACT RETAINED PRODUCT TESTS

Retain these product-contract tests and their behavior:

```text
test_exact_private_import_direction_exports_and_public_surface

test_source_is_pure_static_and_has_no_runtime_or_storage_mechanism

test_wire_owner_is_loaded_once_fixed_and_manifest_is_not_retained

test_wire_owner_callable_is_deleted_after_the_single_import_time_load

test_hostile_wire_owner_key_is_sanitized_without_foreign_equality

test_wire_owner_loader_sanitizes_every_malformed_shape

test_failed_wire_import_retains_no_hostile_owner_graph

test_wire_capture_propagates_process_control

test_owner_and_five_status_projections_are_visible_unique_and_synchronized

test_error_and_value_surface_is_exactly_private_semantics
```

Preserve all current parameterizations and resulting 16 retained node IDs.

Harmless formatting and import cleanup is allowed. No semantic weakening.

The in-memory malformed-owner and visible-document mutants inside these tests
remain ordinary unit-test inputs and are retained.

SELF-PROTECTING MACHINERY TO DELETE

Delete completely:

```text
_BOUNDARY_ACCEPTED_*

all BOUNDARY_* call/global/runtime ledgers and digests

_scope_nodes through _closed_boundary_call_surface

CALL_SURFACE_*
LEGACY_CALL_SURFACE_*
G9 mutation builders
runtime-global capture/seal machinery
runtime-callable capture/seal machinery
materialized boundary fixtures used only for self-tamper tests
payload/source mutation compilers used only for self-tamper tests
PROTECTED_CAUSAL_CASES

every G12_* constant
every G12_* helper
every G12_* ledger
every G12_* capture
every G12 fixture/gate
every G12 self-protection test

capability_boundary_preflight
capability_boundary_target_gate
_BOUNDARY_ACCEPTED_TARGET

the Base85/zlib/JSON literal carrier

self-source parsing
self-AST authentication
self-code-object authentication
self-binding ledgers
self-callsite ledgers
runtime callable captures
autouse/explicit dual self-protection gates
generic Python binding analysis
in-process tamper-resistance assertions
```

Remove all now-unused imports and constants.

Do not leave dead compatibility shims for deleted machinery.

LITERAL PERMANENT CONTRACT TABLES

Replace the prior path/projection machinery with two direct literal tuples.

## REQUIRED_CANDIDATE_ROWS

Exact row schema:

```text
(
    row_id,
    relative_path,
    expected_mode,
    contract_classes,
    purpose,
)
```

Types:

```text
row_id:
exact str

relative_path:
exact str

expected_mode:
exact int 0o644

contract_classes:
exact tuple[str, ...]

purpose:
exact str
```

Exact rows and contract classes:

```text
R01 .docs/authority-boundaries.md
    ("authority_non_effect",)

R02 .docs/autonomous-software-development-operating-model.md
    ("authority_non_effect",)

R03 .docs/c2a-first-slice-semantic-protocol-contract.md
    ("authority_non_effect",)

R04 .docs/c2a1-pure-semantic-values.md
    ("authority_non_effect",)

R05 .docs/durable-state-model.md
    ("state_store_writer_session",)

R06 .docs/rw0-b1-pure-phase-values.md
    ("authority_non_effect",)

R07 .docs/rw0-b2-capability.md
    ("private_module_export",)

R08 .docs/rw0-b2-wire-protocol.md
    ("authority_non_effect",)

R09 .docs/rw0-remote-worker-contact-phase-entry.md
    ("authority_non_effect",)

R10 .docs/worker-execution-boundary.md
    ("authority_non_effect",)

R11 src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
    ("authority_non_effect",)

R12 src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
    ("authority_non_effect",)

R13 src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
    ("private_module_export", "production_importer_caller")

R14 src/ge_nwp_coordinator/_worker_execution_semantic_values.py
    ("authority_non_effect",)

R15 tests/test_architecture_contracts.py
    ("authority_non_effect",)

R16 tests/test_c2a_nonimplementation.py
    ("authority_non_effect",)

R17 tests/test_runtime_non_authority.py
    ("authority_non_effect",)

R18 tests/test_rw0_b1_boundaries.py
    ("authority_non_effect",)

R19 tests/test_rw0_b1_phase_values.py
    ("authority_non_effect",)

R20 tests/test_rw0_b1_relations.py
    ("authority_non_effect",)

R21 tests/test_rw0_b2_capability_boundaries.py
    ()

R22 tests/test_rw0_b2_capability_relations.py
    ("private_module_export",)

R23 tests/test_rw0_b2_capability_values.py
    ("private_module_export",)

R24 tests/test_rw0_b2_capability_vectors.py
    ("private_module_export",)

R25 tests/test_rw0_b2_wire_boundaries.py
    ("authority_non_effect",)

R26 tests/test_rw0_remote_contact_phase_entry_contract.py
    ("authority_non_effect",)

R27 tests/test_section41_pre_execution_plan_disposition_contracts.py
    ("authority_non_effect",)

R28 tests/test_software_development_progression_boundary.py
    ("state_store_writer_session",)

R29 tests/test_worker_execution_semantic_boundaries.py
    ("authority_non_effect",)

R30 tests/test_worker_execution_semantic_values.py
    ("authority_non_effect",)
```

Use the current exact R01–R30 `purpose` strings from the opening checked-in
literal projection when they are available and unambiguous.

If any current R purpose is absent, duplicated, or coupled only to deleted
machinery, define a unique, short, reviewable literal purpose describing the
row's repository-contract role. Record every such normalization in the final
report.

Do not derive purposes from live paths at test execution.

## PROTECTED_CONTENT_ROWS

Exact row schema:

```text
(
    row_id,
    relative_path,
    expected_size,
    expected_sha256,
    contract_classes,
    purpose,
)
```

Exact rows:

```text
P01
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
77003
6bf39f634b619829fcc4cc7ada5cf019b40b3c5a2258947ebee8fdfe2a13031e
("authority_non_effect",)

P02
src/ge_nwp_coordinator/_development_author_effect_establishment_contracts.py
63518
f6938024436a765a69e9a44d20d834a85075ba10b821e61e3e91bfb09cf17af0
("authority_non_effect",)

P03
src/ge_nwp_coordinator/_development_decision_row_values.py
53230
9e0e9c0695adb9f0ad72d9d92c6859c995c2c5ade154a5546f0a1efc347db8ae
("dependency_schema_migration",)

P04
src/ge_nwp_coordinator/_development_effect_row_values.py
64606
bbe52faf7ad69e2e643a404808cb0e68d4f7c76a668426d58029a7c108cfa158
("dependency_schema_migration",)

P05
src/ge_nwp_coordinator/_development_program_row_values.py
60276
d8557eac3f4956c6fdedaf851b9f230f871d0d41eb381fdb09cdecece8df6422
("dependency_schema_migration",)

P06
src/ge_nwp_coordinator/__init__.py
2385
60230ae31032071ab52b16c3537a1b2b398e06a4b1f4ec926485471927b2f2b5
("private_module_export",)

P07
pyproject.toml
330
c59ff8c0005b063636ff161002f1b1c45a81227b4ed30a988412f01a474e0ac9
("dependency_schema_migration",)

P08
tests/c2a_contract_support.py
154329
4952d25086220632c969a29e44b9abe29b966fbb031d2305c11d4bf13d39c4f1
("authority_non_effect",)

P09
tests/test_c2b2_development_row_value_boundaries.py
17823
4c892136f8c6fd629eb44e95bc8dd7a9aa1a5250e97cc61499171f2835bb4f42
("dependency_schema_migration",)

P10
tests/test_codex_agent_config.py
1082
0691c90c0178632a793a93595ba344169fb9b9669de155939fb4873db2f0d3ee
("authority_non_effect",)

P11
AGENTS.md
58903
ab3e788e3086088eb5caa2cf392a9ccb9582b645c082897574e55234aec860c8
("authority_non_effect",)

P12
README.md
43280
093134d136a8dc246c9a9c1557a95c3b5500007b8ccfd3a4cac0722b1a0aa1d4
("authority_non_effect",)

P13
.docs/software-development-progression-boundary.md
27194
3b0c21f73048e458bd750b9896fbae7c285a4b35799b99060aef03d8379052fe
("state_store_writer_session",)
```

Use the current exact P01–P13 `purpose` strings from the opening projection when
available and unambiguous. Record any normalization.

DIRECT HELPERS

Implement only:

```text
_assert_regular_mode_0644
_assert_exact_content_identity
```

Allowed behavior:

## _assert_regular_mode_0644

Input:

```text
row_id
relative_path
```

Checks:

```text
ROOT / relative_path exists under lstat
is exact regular file
mode is 0644
```

Failure diagnostics contain only:

```text
<row_id>:required_path
<row_id>:regular_file
<row_id>:mode_0644
```

Do not echo the observed path, mode, file content, private value, or Git state.

## _assert_exact_content_identity

Input:

```text
row_id
relative_path
expected_size
expected_sha256
```

Checks:

```text
regular file
exact byte size
exact SHA-256
```

Failure diagnostics contain only:

```text
<row_id>:required_path
<row_id>:regular_file
<row_id>:protected_size
<row_id>:protected_sha256
```

Do not echo observed bytes, digest, content, or private values.

THREE NEW PERMANENT TESTS

Implement exactly these node names:

```text
test_required_candidate_surface_is_literal_unique_regular_and_mode_0644

test_protected_content_surface_has_exact_literal_identities

test_boundary_contract_rows_are_literal_complete_unique_and_consistent
```

## test_required_candidate_surface_is_literal_unique_regular_and_mode_0644

Require:

```text
exact tuple type for table
exact row tuple type
exact five fields per row
exact row IDs R01..R30 in order
exact 30 relative paths in order
unique IDs
unique paths
unique nonempty purposes
expected_mode exactly 0o644 for every row
contract_classes exact tuple[str, ...]
each path passes _assert_regular_mode_0644
```

Do not compare the table to live Git status or current dirty paths.

## test_protected_content_surface_has_exact_literal_identities

Require:

```text
exact tuple type for table
exact row tuple type
exact six fields per row
exact row IDs P01..P13 in order
exact 13 paths in order
unique IDs
unique paths
unique nonempty purposes
all digest literals are exact lowercase 64-hex strings
all expected sizes are exact nonnegative ints
contract_classes exact tuple[str, ...]
R paths and P paths are disjoint
each row passes _assert_exact_content_identity
```

## test_boundary_contract_rows_are_literal_complete_unique_and_consistent

Use a literal finite allowed class set:

```text
authority_non_effect
private_module_export
production_importer_caller
dependency_schema_migration
state_store_writer_session
```

Require:

```text
every contract class belongs to the allowed set
every required contract class appears where frozen
R13 exact class tuple
R21 exact empty class tuple
P06 exact private_module_export
P03/P04/P05/P07/P09 exact dependency_schema_migration
P13 exact state_store_writer_session
row IDs unique across both tables
purposes unique across both tables
no path duplicated across tables
table lengths exactly 30 and 13
candidate count diagnostic says 30, never 20
```

Use content-free finite diagnostics such as:

```text
candidate_rows:shape
candidate_rows:inventory
candidate_rows:unique_ids
candidate_rows:unique_paths
candidate_rows:unique_purposes
candidate_rows:contract_classes

protected_rows:shape
protected_rows:inventory
protected_rows:unique_ids
protected_rows:unique_paths
protected_rows:unique_purposes
protected_rows:contract_classes

boundary_rows:disjoint_paths
boundary_rows:unique_ids
boundary_rows:unique_purposes
boundary_rows:class_coverage
boundary_rows:count_30_13
```

Do not emit observed row content.

EXACT OLD TEST DISPOSITIONS

Retain:

```text
test_exact_private_import_direction_exports_and_public_surface

test_source_is_pure_static_and_has_no_runtime_or_storage_mechanism

test_wire_owner_is_loaded_once_fixed_and_manifest_is_not_retained

test_wire_owner_callable_is_deleted_after_the_single_import_time_load

test_hostile_wire_owner_key_is_sanitized_without_foreign_equality

test_wire_owner_loader_sanitizes_every_malformed_shape

test_failed_wire_import_retains_no_hostile_owner_graph

test_wire_capture_propagates_process_control

test_owner_and_five_status_projections_are_visible_unique_and_synchronized

test_error_and_value_surface_is_exactly_private_semantics
```

Remove:

```text
test_closed_reachable_call_surface_and_mutation_matrix
test_g9_repair_causal_source_cases
test_g9_repair_causal_inventory_is_unique_and_complete
test_runtime_global_mutant_expectations_are_literal_and_independent
test_runtime_callable_seal_is_causally_sensitive
test_every_protected_content_row_is_causally_mutation_sensitive
test_exact_audit_protected_assertion_weakening_is_killed
test_g12_every_binding_capable_survivor_is_rejected
test_g12_runtime_callable_mutants_are_rejected
test_g12_target_signature_requires_preflight_dependency
test_g12_binding_ledgers_preserve_order_and_scope
test_g12_binding_literal_ledger_mutants_are_rejected
test_g12_python_callable_literal_digest_mutants_are_rejected
test_g12_external_callable_literal_digest_mutants_are_rejected
test_g12_external_python_observations_include_source_ast_and_code
test_g12_removing_target_preflight_dependency_is_rejected
test_g12_fixture_unavailable_or_rebound_is_rejected
test_g12_ordered_callsite_and_provenance_mutants_are_rejected
test_g12_module_global_literal_integrity_is_independent
```

Replace/remove the old node:

```text
test_exact_twenty_path_ceiling_modes_and_protected_controls
```

with the three new permanent tests.

No skip or xfail.

NODE MIGRATION CONTRACT

Opening boundary nodes:

```text
110
```

Expected final boundary nodes:

```text
19
```

Expected whole-suite migration:

```text
opening:
5150

unrelated retained:
5040

removed:
94

added:
3

expected final:
5059
```

Semantic disposition:

```text
16 retained product nodes
93 self-protection nodes removed
1 old projection node replaced
3 bounded contract nodes added
```

Record a complete migration ledger:

```text
old node ID
disposition:
  retained
  removed_rejected_assurance
  replaced
new node ID when replaced
purpose
```

Requirements:

- all 110 opening boundary nodes represented exactly once;
- all 5,040 nodes outside the file retain exact relative order;
- no skip/xfail;
- no placeholder node added to preserve volume;
- final count is collected, not assumed.

If final count differs from 5,059, stop before full suites and explain the exact
literal node delta.

TEST-FIRST RED

Use a causal, bounded red phase.

Preferred method:

1. install the simplified tests and tables in an intentionally incomplete
   interim state inside the one authorized file;

2. omit R30 from `REQUIRED_CANDIDATE_ROWS`;

3. change only the P12 expected SHA-256 by one lowercase-hex digit;

4. run exactly the three new test nodes;

5. require:
   - candidate-surface test fails only at `candidate_rows:inventory`;
   - protected-content test fails only at `P12:protected_sha256`;
   - consistency test fails only through the intended literal count/coverage
     predicate or passes if its predicate remains valid;
   - no collection/import/syntax/path/tooling error;

6. preserve the exact interim bytes and red evidence;

7. correct only R30 and P12 to the frozen final values.

Alternative external-copy red is allowed only if it exercises the exact final
test implementation before installation and preserves exact source identities.

Do not use removed self-tamper machinery as the red gate.

FORMAL VALIDATION EVIDENCE

Use a proportionate recorder for formal credited runs.

Every credited final run records:

```text
label
exact argv
working directory
environment
Python identity
caller/child umask
start/end/duration
return code/signal
stdout/stderr paths and SHA-256
JUnit path/SHA-256/parse status
collected/passed/failed/error/skipped/xfail/xpass/warning counts
duplicate/unmapped cases
candidate pre/post fingerprint
candidate-mutated result
```

Report failed and superseded formal validation attempts honestly.

Do not build another recursive self-proving recorder architecture.

FINAL VALIDATION ORDER

After final bytes are frozen:

1. complete modified boundary file;

2. Capability complete:

   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   ```

3. B1/Wire compatibility:

   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```

4. architecture/status/static:

   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

5. A/B/C state validation;

6. final live and clean node collection;

7. node migration reconciliation;

8. one live complete suite;

9. one fully external clean-commit complete suite;

10. exact guards and cleanup;

11. two final recipe runs;

12. final report and self-excluding index.

A/B/C STATE VALIDATION

## A

Live unstaged source repository.

## B

Fully external independent repository and object database:

- no alternates;
- no hardlinks;
- accepted base;
- exact final 30-file candidate overlay;
- stage exactly candidate;
- do not commit.

## C

Same external repository after one local diagnostic commit.

Run in each state:

```text
the three new permanent contract tests
the complete boundary file
an external AST/literal-table extractor that reads
REQUIRED_CANDIDATE_ROWS and PROTECTED_CONTENT_ROWS with ast.literal_eval and
emits canonical JSON
```

Require:

```text
three new tests pass A/B/C
complete boundary file passes A/B/C
literal-table projection A == B == C
B staged tree == C committed tree
source logical index unchanged
source authoritative object graph unchanged
no alternates
no source/external shared object inode
```

The AST/literal-table extractor belongs only to G14 evidence. Do not add it to
the repository.

NODE COLLECTION

Run live and clean external collection exactly once each.

Require:

```text
final expected count:
5059

boundary-file expected nodes:
19

opening:
5150

removed:
94

added:
3

outside-file order:
exact
```

If actual collection differs, stop and report exact nodes.

LIVE AND CLEAN COMPLETE SUITES

Run each exactly once.

Require for each:

```text
5059 collected
5059 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
exact JUnit/node mapping
unchanged candidate fingerprint
```

No retry is authorized.

If either fails, preserve evidence and stop without further repository edits.

PROVENANCE CLOSEOUT

After validation and cleanup:

1. require topology `30/24/6/0/0`;

2. prove exactly one repository path changed from the opening candidate;

3. prove the other 29 candidate entries remain exact;

4. prove every path outside the candidate equals HEAD;

5. require final test file:
   - regular mode `0644`;
   - no more than 900 physical lines;
   - no more than 65,536 bytes;

6. verify final import boundary and absence of deleted machinery by AST and
   literal-source checks;

7. run exact retained recipe twice with a verified G14-local mode-0400 copy and
   safe sink redirection;

8. require byte-identical final manifests and complete outputs;

9. retain:
   - opening/final exact file;
   - exact patch;
   - literal tables;
   - node migration ledger;
   - red evidence;
   - final focused records;
   - A/B/C records;
   - live/clean node lists;
   - live/clean full-suite records;
   - run-local fingerprints;
   - final manifests;
   - guards/cleanup;
   - complete inline report;

10. verify G12 and G13 unchanged;

11. create a self-excluding evidence index last and externally verify it.

FINAL INDEPENDENT-AUDIT HANDOFF

The final report must define the next audit boundary:

```text
permanent test has no transient Git-status dependency
permanent test has no subprocess/process/Git command dependency
literal R01–R30 and P01–P13 are exact
external one-predicate mutants cover every owned assertion
A/B/C is state-independent
live and clean suites pass
candidate/protected provenance is exact
public/import/privacy/authority boundaries remain unchanged
```

It must explicitly state that arbitrary coordinated mutation of the test and
its oracle inside one interpreter is outside the permanent-test contract and
belongs to Git review/provenance, not candidate runtime semantics.

STOP CONDITIONS

Stop without further mutation if:

- opening identity or manifest differs;
- a second repository file is required;
- a retained product test depends essentially on deleted self-protection
  machinery;
- final file exceeds 900 lines or 65,536 bytes;
- a state-independent contract requires Git/process/status calls;
- literal rows conflict with owning contracts;
- node migration does not reconcile;
- A/B/C or complete suites diverge;
- production/document/public/authority changes appear necessary.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_ASSURANCE_RESET_IMPLEMENTED_READY_FOR_FRESH_AUDIT
```

only when:

- the file is within the size/line ceiling;
- exactly one repository path changed;
- the final boundary file has exactly 19 nodes;
- the whole suite has exactly 5,059 nodes;
- red, focused, A/B/C, live, and clean validation are green;
- exact provenance and evidence sealing are complete;
- the full report is inline.

FINAL INLINE REPORT

Use these headings:

```text
# Outcome

# Opening and closing identity

# Assurance reset implemented

# Exact one-file delta

# Retained product contracts

# Literal candidate and protected tables

# Removed self-protection architecture

# Test-first evidence

# Node migration

# A/B/C state result

# Focused validation

# Live and clean complete suites

# Provenance and evidence index

# Fresh independent-audit boundary

# Public, privacy, and authority boundary

# Confidence
```

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
