## Engineering disposition

**Proceed to a fresh independent audit. Do not stage or commit yet.**

Codex has completed the implementation engagement with the required success token and reports an exact, reproducible 16-path candidate:

```text
branch:                         codex/rw0-b2-wire-protocol-v1
HEAD:                           02450d3c99faf0fe7b299b914afaed312421bc8b
dirty topology:                 16 / 10 tracked / 6 untracked / 0 staged / 0 unmerged
candidate nodes:                4,626
full suite:                     4,626 / 4,626
canonical manifest SHA-256:     11cb3375a687c00c221a56a8fdd1333a64bed189c697030894ba82abdd03a10a
tracked diff SHA-256:           eb2e81a99c851c78d51db1e753b896841b1ded7856400270ba6a1ffc276ea4f5
complete-output SHA-256:        b0bcdb23305ff910cf5b2c2a484ed56aaceb284c875df4262533d8679cef0822
```

The earlier reconnaissance correctly prohibited implementation while integer admission, frame bytes, hostile-work accounting, error precedence, and the process/result classifier remained unfrozen.  The implementation report now claims that those decisions have been realized and validated, so the implementation gate is complete.

That does **not** establish semantic correctness. The new module combines several surfaces where mutually reinforcing source, documentation, and tests can share the same mistake:

- hostile JSON and frame parsing;
- canonical byte identity and maximum-size arithmetic;
- cancellation request/response source ownership;
- command, candidate, attempt, fence, effect, and delivery lineage;
- process/result precedence;
- privacy rejection;
- work accounting;
- Markdown current-status ownership;
- static nonimplementation and public-surface boundaries.

The independent audit must actively construct counterexamples rather than merely rerun the suite.

## Audit target

The audit should bind to:

```text
/private/tmp/rw0-b2-wire-v4.b4HlRt/final_001.manifest.json
```

with:

```text
SHA-256:
11cb3375a687c00c221a56a8fdd1333a64bed189c697030894ba82abdd03a10a
```

It must independently reproduce the exact provenance recipe twice, verify all six untracked files by individual size and hash, and stop before correctness inspection on any mismatch. Provenance binds implementation and audit to the same bytes; it does not prove the implementation correct. 

## Audit structure

The supplied prompt creates four read-only perspectives after provenance passes:

1. **Protocol and hostile-decoder correctness**  
   Independently reconstruct the profile digest, byte maxima, structural counts, work budgets, duplicate-key behavior, integer scanning, UTF-8 handling, canonical re-encoding, and decoder precedence.

2. **Authority, privacy, and identity ownership**  
   Verify supervisor versus Execution Substrate request authorship, adapter-authored responses, cancellation-graph bindings, route neutrality, source-evidence non-authority, privacy exclusions, and unchanged C2A/B1 contracts.

3. **Worker-result and classifier semantics**  
   Probe every result sequence, lineage coordinate, cancellation branch, process fact, exit condition, malformed-result condition, and precedence pair.

4. **Test adequacy, status ownership, public boundary, and evidence**  
   Check literal test independence, one-predicate mutants, Markdown visibility/ownership, node identity, imports, package exports, validation records, and artifact hygiene.

The parent must preserve disagreements, reproduce material counterexamples, and withhold the independent full suite if source inspection already finds a blocker.

This follows the project’s required separation: implementation is parent-only and write-enabled; independent audit occurs later in a fresh, read-only conversation against exact candidate bytes. 

## Prompt to forward

Start a **fresh read-only Codex conversation** and send this complete prompt:

:chatgpt-content-reference{index="3"}

Verify the attachment:

```text
Filename:
Coordinator_RW0_B2_Wire_Independent_Audit_Prompt.txt

Size:
31,700 bytes

SHA-256:
0d17fb413a7b29a3c326a2ea8fe5aaf7b8e666a5ecb9ce6260f8538109adab0c
```

The only successful audit outcome is:

```text
ACCEPT
COORDINATOR_RW0_B2_WIRE_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

A `BLOCK` returns the work to the existing workspace-write implementation conversation for a bounded repair and a subsequent fresh re-audit. `ACCEPT` permits a later audited-byte commit and PR gate; it does not itself authorize staging, commit, push, PR creation, or merge.

### Sources

- Initial Wire reconnaissance and the design decisions that originally blocked implementation. 
- Parent-only implementation and separate fresh read-only audit lifecycle. 
- Exact provenance, validation, and commit separation. 
- Codex implementation report supplied in this turn.

**Confidence:** High that the reported candidate is ready to enter independent audit; deliberately not yet high that the Wire semantics are correct until the adversarial audit completes.
