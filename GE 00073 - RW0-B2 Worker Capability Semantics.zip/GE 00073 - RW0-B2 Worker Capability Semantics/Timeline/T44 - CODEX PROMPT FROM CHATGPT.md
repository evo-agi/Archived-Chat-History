PROMPT_ID

RW0_B2_WIRE_FIFTH_AUDIT_TEST_REPAIR_V1

TITLE

Coordinator RW0-B2-Wire — repair the fifth-audit integer-matrix test findings
and prepare exact bytes for a fresh independent re-audit

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing
`codex/rw0-b2-wire-protocol-v1` implementation conversation.

Do not create or resume subagents. You are the sole repository writer.

This is a bounded **one-file test-only repair** after a fresh independent audit
returned `BLOCK`. The auditor found no production defect and independently
accepted current protocol behavior, profile identities, parser behavior,
integer admission, authority/privacy boundaries, classifier behavior, and
public/nonimplementation boundaries.

Do not modify production source or governing documentation.

This is not reconnaissance, schema design, implementation redesign, Capability
implementation, independent audit, commit gate, publication gate, merge,
deployment, or runtime proof.

Do not stage, commit, push, create or modify a PR, merge, tag, release, deploy,
contact a remote, invoke a product worker/model/provider, modify a supporting
repository, or install dependencies.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Close exactly the two fifth-audit test-adequacy findings:

1. make the existing literal 64-path integer matrix behaviorally execute and
   prove every row's declared exact-valid value through a coherent public Wire
   boundary, so a field-specific off-by-one regression rejecting a legal maximum
   cannot pass;

2. make the selective-regression control bypass exactly one selected
   AttemptFenceV1 integer check, prove exactly one bypass occurred, require the
   selected Attempt-specific owner boundary to be reached, and preserve early
   rejection for an unrelated EffectFenceV1 case.

Preserve:

- all production and documentation bytes;
- all 4,655 test node identities;
- the existing literal 64-path inventory;
- all negative MAX+1 and 1,000-digit checks;
- process-exit `-255/0/255` controls;
- every previously accepted F1–F16 behavior and test;
- the exact 16-path candidate topology;
- Capability nonimplementation.

OPENING TARGET

Before any mutation, require exactly:

- physical root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- subject:
  `feat: implement RW0-B1 pure phase-entry semantics (#3)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- dirty paths:
  `16`
- tracked modifications:
  `10`
- untracked additions:
  `6`
- staged/unmerged:
  `0/0`
- every candidate path:
  regular mode `0644`
- no Git operation, lock, repository cache, bytecode, database, journal,
  archive, build, generated manifest, or recorder residue
- `git diff --check`:
  clean.

Immutable opening target:

```text
/private/tmp/rw0-b2-wire-fourth-repair.oTHtSz/final_provenance.json
```

Require that report to bind exactly one canonical manifest with:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe source size:
3_945 bytes

recipe source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6

canonical-manifest SHA-256:
a07cf04ba3e0418bbf5688ffbf78480fde79747d4310a5075e6db5dbf25f4aec

complete-output SHA-256:
0c35a0996ef0ce1a7df09b8b7ae4ad91c3a0f5eea8f8b15e5db8433aa1cd0458

file count:
16
```

Expected report-envelope SHA-256:

```text
bb6629cb14238a29eca2aa2da5f23101e5423ef5cdfd6d793a64a3276982c8d5
```

Latest audit evidence root:

```text
/private/tmp/rw0-b2-wire-fourth-reaudit.UleeOK
```

Preserve every earlier implementation, repair, and audit evidence root. Do not
rewrite or reconstruct missing evidence.

EXACT RECIPE SOURCE

Decode this base64 only into a new external repair evidence root, verify exact
size and SHA-256, and retain it mode `0400`:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

Execute the exact source unchanged with only its exact historical
`Path.write_bytes` sink redirected into the new evidence root. Do not overwrite
pre-existing fixed-path evidence.

OPENING PROVENANCE AND NODE GATE

Before editing:

1. lstat every component of the immutable target, report-bound manifest, latest
   audit root, retained prior roots, new repair root, and copied recipe;
2. require safe ownership, no symlink traversal, regular files, and mode-0700
   evidence roots;
3. verify the immutable target and report envelope exactly;
4. run the exact recipe twice;
5. require both complete outputs and manifests to be byte-identical and equal
   the immutable target;
6. verify every live candidate entry by path, classification, type, mode, size,
   and SHA-256;
7. verify protected complement equality to HEAD;
8. collect the complete opening node list exactly once under isolated external
   paths;
9. require exactly `4_655` unique opening nodes.

Stop before mutation on any mismatch. Do not reset, clean, or reconstruct the
candidate.

AUDIT FINDINGS

Treat these as authoritative test-repair inputs:

```text
F17 Low  every inventory row declares a valid value, but exact-valid ceiling
         values are never behaviorally exercised; a selective regression
         rejecting CeilingsV1.max_active_invocations == MAX passed the matrix

F18 Low  the selective Attempt control bypasses all sixteen Attempt integer
         checks rather than one selected check, and asserts only a generic spy
         event rather than the selected Attempt-specific owner boundary
```

The audit found no Critical, High, or Medium defect and no production defect.

AUTHORIZED REPAIR PATH

Only this existing untracked candidate file may change:

```text
tests/test_rw0_b2_wire_relations.py
```

The other fifteen candidate entries must remain byte-identical to the opening
manifest.

Because the repair path is untracked, final tracked textual-diff SHA-256 must
remain exactly:

```text
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6
```

No production source, documentation, codec test, value test, boundary test,
inventory test, status test, public boundary, dependency, schema, migration,
package, or new repository file may change.

PRE-EDIT DIAGNOSTIC

Before editing, run one external read-only diagnostic that reproduces both test
defects without changing repository bytes:

1. instrument the existing 64-path test and prove that inventory-row `valid`
   values are only type-checked and are not passed through public Wire
   boundaries;
2. install an external selective regression that rejects only:
   ```text
   CeilingsV1.max_active_invocations == 9_223_372_036_854_775_807
   ```
   and prove a standalone coherent positive call fails while the checked-in
   64-path node passes;
3. instrument the existing Attempt selective control and prove exactly sixteen
   integer guard calls are bypassed:
   - fifteen nested ceiling leaves;
   - one `global_stop_version`;
4. record which Attempt-specific owner boundary, if any, is reached;
5. retain exact source hash and repository fingerprint.

If the diagnostic contradicts either finding, stop and report the disagreement.
Do not edit.

REPAIR 1 — BEHAVIORAL EXACT-VALID COVERAGE

A. Preserve node identity

Do not add, rename, parameterize, split, or remove a test node.

Strengthen only the existing node:

```text
tests/test_rw0_b2_wire_relations.py::test_every_reachable_c2a_integer_path_is_isolated_before_owner_or_wire_canonicalization
```

B. Preserve the literal inventory

Keep the test-owned literal inventory at exactly 64 entries:

```text
CeilingsV1           15
AttemptFenceV1       16
EffectFenceV1        16
WorkerCommandV1      16
DeliveryEnvelopeV1    0
WorkerObservationV1   1
total                 64
```

Do not generate it from Wire extractor constants.

Each row must continue to declare at least:

```text
owner exact class
literal field path
public Wire boundary
direct versus nested ownership
declared exact-valid value
oversized mutations
applicable owner/Wire spy surfaces
```

C. Execute every declared valid row

For every one of the 64 rows, behaviorally exercise the row's declared valid
value.

Requirements:

1. Begin from a fresh complete valid and related graph.
2. Place the declared valid value at the exact target row.
3. Adjust only the minimum companion coordinates required to keep the complete
   C2A/Wire graph coherent.
4. Invoke the row's recorded public Wire boundary.
5. Require successful reconstruction/relation/classification/encoding as
   appropriate.
6. Instrument and assert that the intended target class and literal path were
   actually reached.
7. A positive case is invalid if an earlier object means the target row was not
   traversed.
8. Continue to run both negative mutations (`MAX + 1` and the 1,000-digit
   integer) for the same row with zero applicable owner/Wire calls.

Equivalent coherent positive graphs may be deduplicated only when the test
mechanically records every covered row and asserts that each listed target
class/path was reached during the shared call.

At minimum, exact-positive coverage must mechanically catch a selective
off-by-one regression for each of these classes/surfaces:

```text
CeilingsV1
AttemptFenceV1
EffectFenceV1
WorkerCommandV1
WorkerObservationV1
```

D. Ceiling maximum controls

For each of the fifteen ceiling fields, execute at least one coherent graph in
which that field is exactly:

```text
9_223_372_036_854_775_807
```

and all necessary related ceilings/fences/command values are adjusted so the
owning C2A and Wire relations remain valid.

Mechanically map that executed graph back to every inventory row it covers.

A field-specific test-local broken control that rejects exact MAX for one
selected ceiling field must make the positive matrix fail.

The audit's concrete field must be included:

```text
max_active_invocations
```

E. Direct integer controls

Behaviorally execute exact-valid controls for every direct integer path,
including all applicable `global_stop_version` coordinates.

Preserve and actively execute:

```text
process_exit_code = -255
process_exit_code = 0
process_exit_code = 255
```

Do not add a B2 lower bound.

F. Positive coverage ledger

Within the existing test node, build a bounded test-local coverage ledger keyed
by:

```text
(owner class name, literal field path)
```

At closeout require:

```text
positive coverage keys == the 64 literal inventory keys
negative MAX+1 coverage keys == the 64 literal inventory keys
negative 1000-digit coverage keys == the 64 literal inventory keys
```

The coverage ledger is test-local only and is not production evidence.

REPAIR 2 — ONE-CHECK SELECTIVE REGRESSION CONTROL

Replace the current class-wide Attempt bypass control.

A. Select exactly one target

Use one literal selected Attempt path, such as:

```text
AttemptFenceV1.global_stop_version
```

or one literal selected nested Attempt ceiling path.

B. Bypass exactly one guard operation

The test-local patched guard must delegate to the authoritative production guard
for every call except the single selected combination of:

```text
exact owner class
exact field path
exact target object identity or explicit test-local target token
exact oversized value
```

Require:

```text
selected_bypass_count == 1
```

Also record and assert that the other fifteen Attempt integer checks still
called the authoritative guard.

C. Require the relevant owner boundary

The selected control must require the selected Attempt-specific owner
reconstruction/canonicalization spy to be reached. A generic "some spy fired"
assertion is insufficient.

D. Preserve unrelated rejection

An unrelated oversized EffectFenceV1 case must still:

```text
reject early with invalid_field_value
perform zero Effect owner/Wire canonicalization calls
observe zero selected Attempt bypasses
```

E. Operation-level broken control

The control must prove operation-level selectivity, not only outcome-level
selectivity. A version that disables all Attempt integer checking must fail the
test's exact bypass-count and authoritative-call assertions.

PRODUCTION AND CONTRACT FREEZE

All production and governing identities remain exact:

```text
profile_ref:
rw0-wire-nwpf-v1

profile identity bytes:
4_021

profile digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454

command payload/frame:
5_898 / 5_906

result payload/frame:
16_627 / 16_635

hostile units:
23_746 / 66_770

source mapping key maximum:
37

frame key maximum:
29

B2 maximum integer:
9_223_372_036_854_775_807
```

Do not modify:

```text
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
.docs/rw0-b2-wire-protocol.md
tests/test_rw0_b2_wire_codec.py
```

If the strengthened positive matrix exposes a production defect, stop. Do not
repair production under this prompt.

NODE IDENTITY

Opening and final collection must both be exactly:

```text
4_655
```

Require:

- all node IDs byte-identical and in the same order;
- zero additions;
- zero removals;
- zero renames;
- zero parameterization changes;
- zero skip/xfail/decorator changes.

Stop on any node mismatch.

VALIDATION POSTURE

Create one new external operator-owned, non-symlink, mode-0700 repair root.

For every pytest child use:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
actual caller/child numerical umask equality
```

Retain exact argv, environment, timing, return code, stdout/stderr, JUnit,
structured counts, and repository fingerprints.

FINAL VALIDATION ORDER

After editing and final collection:

1. the strengthened 64-path test node;
2. full Wire relations file — expected `49` nodes;
3. all four Wire files together — expected `89` nodes:
   ```text
   tests/test_rw0_b2_wire_values.py
   tests/test_rw0_b2_wire_codec.py
   tests/test_rw0_b2_wire_relations.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
4. corrected C2A/C2A1 compatibility — expected `637`;
5. B1 — expected `281`;
6. static/public — expected `105`;
7. status/docs — expected `858`;
8. `git diff --check`;
9. exact path/mode/protected/public/import/residue/operation/lock guards;
10. complete suite attempt 001 exactly once — expected `4_655`.

Every final focused gate and complete suite must have:

- return code 0;
- zero failures, errors, skips, xfails, warnings;
- empty stderr;
- parseable JUnit;
- no duplicate, ambiguous, or unmapped cases;
- unchanged candidate fingerprint before/after.

COMPLETE-SUITE REPAIR POLICY

If complete-suite attempt 001 fails:

- preserve all evidence;
- do not modify production, documentation, or another test file;
- repair only when the failure is causally inside the one authorized test file,
  preserves all 4,655 node identities, and weakens no assertion;
- rerun affected focused gates;
- run complete-suite attempt 002 exactly once.

No third complete-suite attempt is authorized.

FINAL PROVENANCE

After final green validation and cleanup:

1. require exact topology:
   - 16 dirty paths
   - 10 tracked modifications
   - 6 untracked additions
   - 0 staged
   - 0 unmerged;
2. run the exact recipe twice;
3. require byte-identical complete outputs and manifests;
4. require exactly the original 16 paths;
5. compare against the opening target;
6. require exactly `tests/test_rw0_b2_wire_relations.py` to differ;
7. require the other fifteen entries to remain byte-identical;
8. require tracked textual-diff SHA-256 to remain the pinned value;
9. prove every protected path equals HEAD;
10. retain final recipe source, complete-output hash, textual-diff hash,
    manifest hash, complete manifest, unchanged node list, validation results,
    and guards.

STOP CONDITIONS

Stop without further mutation if:

- opening provenance differs;
- retained evidence changed;
- a second repair path or seventeenth candidate path is needed;
- any production or documentation byte must change;
- the literal inventory does not remain exactly 64 paths;
- a declared valid row cannot be exercised through its recorded public
  boundary;
- exact MAX exposes a production rejection;
- the selected bypass cannot be reduced to exactly one guard operation;
- the selected Attempt-specific owner boundary cannot be proved;
- any node identity changes;
- tests require skip/xfail/deletion/renaming/weakening;
- validation or provenance remains unstable.

CLOSEOUT TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_WIRE_FIFTH_AUDIT_TEST_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only if both findings are mechanically closed, all 4,655 nodes remain exact,
final validation is green, provenance is stable, production/docs remain
byte-identical, and no stop condition fires.

The report must include:

1. opening identity and immutable target;
2. pre-edit diagnostic;
3. exact one-file delta;
4. literal 64-path inventory summary;
5. positive/negative coverage-ledger equality;
6. coherent exact-valid ceiling controls;
7. exact one-check bypass evidence;
8. Attempt-specific spy evidence;
9. process-exit lower-bound evidence;
10. unchanged node identity;
11. every validation attempt;
12. final provenance and guards;
13. separate provenance, validation, production-behavior, and test-adequacy
    confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
PRIOR_AUDIT_EVIDENCE_PRESERVED
```
