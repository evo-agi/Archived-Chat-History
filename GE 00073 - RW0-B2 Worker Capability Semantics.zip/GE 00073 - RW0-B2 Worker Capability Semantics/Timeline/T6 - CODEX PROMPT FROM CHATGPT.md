TITLE

Coordinator RW0-B2-Wire — finite read-only schema and protocol freeze closure

ENGAGEMENT TYPE

Parent-only, read-only design reconciliation against the current merged
Coordinator baseline and the completed B2 reconnaissance.

This is not another broad reconnaissance and not an implementation prompt.

Do not create or resume subagents. The preceding four-explorer investigation is
complete. Reuse its source-grounded evidence, inspect only the exact owning
surfaces needed to close the finite Wire decisions below, and return one exact
implementation packet.

Do not edit, create, delete, format, chmod, stage, commit, push, create or
modify a PR, merge, tag, release, deploy, install dependencies, run tests or
pytest collection, invoke Codex/model/provider behavior, contact any network,
worker, host, service, Bridge, ES, IM, or supporting repository, or create
repository-local artifacts.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED BASELINE

Require before inspection and at closeout:

- branch:
  trunk_dev
- HEAD:
  02450d3c99faf0fe7b299b914afaed312421bc8b
- tree:
  0b5394c591bd277d56797794f71af954ccb93846
- sole parent:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- subject:
  feat: implement RW0-B1 pure phase-entry semantics (#3)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- worktree/index/untracked/unmerged:
  clean
- no Git operation or lock
- no repository-local cache, bytecode, database, build, archive, or generated
  manifest residue.

Do not fetch or contact a remote. Stop on mismatch.

PRECEDING RECONNAISSANCE DISPOSITION

Treat the completed parent report as the source-grounded opening packet:

```text
RW0_B2_WIRE_RECONNAISSANCE_PARTIAL
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

Its decisive accepted conclusions are:

1. The order is `RW0-B2-Wire → RW0-B2-Capability`.

2. Capability uncertainty does not currently invalidate Wire.

3. One command frame carries one complete `WorkerCommandV1` mapping and one
   complete `DeliveryEnvelopeV1` mapping.

4. One result frame carries a private envelope of complete worker-authored
   `WorkerObservationV1` mappings in exactly one of:

   - `(worker_started, worker_completed)`
   - `(worker_started, candidate_captured, worker_completed)`

5. The outer frame has no semantic identity and no in-band self-digest.

6. Worker result is source evidence, distinct from process success, delivery
   outcome, B1 terminal outcome, C2B decision, RW0-C durable terminal fact,
   authority, and acceptance.

7. The same nested C2A records and result grammar apply to direct-local and
   later ES conformance; route-owned wrappers and correlations remain outside
   Wire.

8. C2A/B1 bytes, fields, schema IDs, digest domains, enums, vectors, relations,
   package exports, public protocols, dependencies, migrations, and production
   callers remain unchanged.

9. Capability is seam-bounded:
   declaration, independent observation, and qualification remain distinct;
   no self-observation or self-qualification; no source authentication,
   permission, acceptance, or executable authority; exact accepted Wire
   profile and supplied positive B1 phase/effect/host qualification can be
   bound; concrete CLI/App Server, credential, session, invocation, and process
   mechanics remain RW0-D/E.

10. No Capability implementation prompt is authorized.

The prior report correctly withheld Wire READY because these exact decisions
remained open:

- integer admission;
- exact frame bytes and payload envelope;
- profile identity;
- result-envelope relation details;
- complete decoder/error precedence;
- enforceable whole-operation work accounting;
- exact process/result classifier inputs and precedence;
- frozen module/touched-file surface.

ENGINEERING DECISIONS ADOPTED FOR THIS CLOSURE

These are the strategic design decisions to source-ground, calculate, and
render exactly. Do not replace them with ordinary alternatives merely because
another design is plausible. Stop with `RW0_B2_WIRE_SCHEMA_FREEZE_BLOCKED` only
for a concrete owning-contract contradiction.

1. WIRE-REPRESENTABLE INTEGER POLICY

Adopt one new B2 defensive representability limit:

```text
RW0_WIRE_MAX_INTEGER = 9_223_372_036_854_775_807  # 2^63 - 1
```

Rules:

- every integer appearing anywhere in a framed command, delivery, result
  observation, Wire profile, Wire supplement, or Wire classification value must
  be an exact built-in `int`, not `bool` or a subclass;
- every such integer must be within its owning lower/field-specific bound and
  no greater than `RW0_WIRE_MAX_INTEGER`;
- existing fields required to equal zero remain zero;
- C2A values above this cap remain locally valid under C2A when their owner
  permits them, but are not B2-Wire representable;
- this is a new B2 codec/admission policy, not a C2A effect ceiling, B1
  semantic change, allocation permission, transport permission, or durable
  storage promise;
- integer JSON is canonical unsigned decimal with no sign, leading zero, decimal
  point, exponent, boolean substitution, NaN, or Infinity;
- decoder integer token handling must enforce digit/range bounds before an
  unbounded Python integer conversion.

Prove mechanically that every C2A record admitted by the intended first RW0
scenario and positively related through B1 can be represented under this
policy. If that cannot be proved without changing C2A/B1, return BLOCKED.

2. EXACT OUTER FRAME

Adopt exactly this eight-byte header:

```text
offset  size  meaning
0       4     ASCII magic b"NWPF"
4       1     protocol version 0x01
5       1     frame kind
6       2     unsigned payload length, big-endian
```

Frame kinds:

```text
0x01 = command
0x02 = worker_result
```

Rules:

- exactly one frame is accepted;
- total input length must equal `8 + declared_payload_length`;
- the unsigned 16-bit field is representational capacity only;
- each kind has its own exact smaller payload maximum;
- declared over-kind-cap length fails before payload slicing, allocation,
  UTF-8 decoding, or JSON parsing;
- short header, bad magic, unsupported version, unsupported kind, truncation,
  and trailing bytes are distinct finite failures;
- a second concatenated frame is trailing data;
- no checksum, signature, frame digest, semantic frame ref, or self-digest is
  added.

If source evidence demonstrates that two length bytes cannot admit the exact
largest valid payload, return BLOCKED rather than widening the header silently.

3. EXACT PAYLOAD ENVELOPES

The command payload is canonical JSON with exactly these two root keys:

```json
{"command": <complete WorkerCommandV1 mapping>,
 "delivery": <complete DeliveryEnvelopeV1 mapping>}
```

The result payload is canonical JSON with exactly this one root key:

```json
{"observations": [<complete WorkerObservationV1 mappings>]}
```

Canonical serialized key order follows the general sorted-key rule, so the
examples above describe membership, not hand-written insertion order.

Rules:

- no payload `schema_id`;
- no payload self-digest;
- header version and kind are the sole payload-schema selector;
- nested C2A records retain their exact `schema_id` and semantic digests;
- no B1 value or raw/private material is carried;
- unknown root key precedes missing root key;
- exact root built-in types only.

4. WIRE PROTOCOL PROFILE IDENTITY

Wire must expose one fixed safe protocol-profile ref/digest pair for later B1
host qualification and Capability binding, but that pair is not carried in
each frame and is not a frame identity.

Freeze:

- one exact safe profile ref;
- one exact domain-separated canonical protocol-manifest mapping;
- one exact profile digest;
- the mapping must bind at least:
  magic, version, kinds, header layout, byte order, integer cap, payload shapes,
  exact per-kind payload caps, canonical JSON rules, result grammar, decoder
  error precedence, relation profile, and whole-operation work limits;
- profile changes require a new profile/version/digest;
- frame decoding never treats a claimed profile digest as authenticity or
  permission.

Prefer fixed module constants plus one safe projection function over a
caller-constructible general capability value unless source inspection proves a
value class is necessary.

5. RESULT ENVELOPE AND RELATION

Adopt:

- no result-envelope self-digest;
- no result-envelope semantic ref;
- constituent `WorkerObservationV1` refs/digests remain the evidence identities;
- all observations are exact `source_kind="worker"`;
- all observations have the same exact `source_ref`;
- all observations have the same exact source invocation;
- every shared command, delivery, semantic attempt, effect, attempt-fence, and
  effect-fence coordinate agrees exactly;
- observation refs are unique;
- observation digests are unique;
- tuple order, not `observed_at`, defines protocol order;
- `candidate_captured`, when present, binds the preassigned candidate exactly;
- `worker_started` and `worker_completed` must satisfy every applicable owning
  C2A relation;
- full graph coherence requiring actual attempt/effect fences is a pure Wire
  relation over the decoded command/delivery/result plus separately supplied
  exact fences; decoding alone never establishes launch authority.

If current C2A fields do not support one of these comparisons, remove only the
unsupported comparison with a path:line justification. Do not widen C2A.

6. SOURCE-NATIVE PROCESS SUPPLEMENT

Existing adapter-authored C2A observations remain the owner for every currently
represented process/deadline/cancellation/exit kind.

Do not duplicate those kinds in a new B2 value.

Because current C2A lacks exact source kinds for resource-limit violation and
OS-signal delivery, Wire may define exactly one private immutable
source-claim value whose sole purpose is to supply those two missing facts to
the pure classifier.

Freeze the smallest exact value that:

- is authored by the supervisor/OS evidence source, never Coordinator;
- binds source/evidence identity, source invocation, command, delivery,
  semantic attempt, effect, both fences, and observed time;
- has one event kind:
  `resource_limit_exceeded | signal_delivered`;
- carries no raw signal number, resource measurement, PID, path, endpoint,
  stderr/stdout, log, host, credential, or process handle;
- authenticates no source and grants no authority;
- has a domain-separated self-digest;
- is safe for possible later RW0-C evidence membership, while B2 itself
  persists nothing.

If the owning contracts require a different minimal decomposition, return the
exact contradiction. Do not invent aggregate process truth or duplicate the
existing C2A observation matrix.

7. PROCESS/RESULT CLASSIFICATION

Freeze one pure deterministic classifier and one finite safe classification
value or equivalent immutable result.

Inputs must include:

- command frame semantic records;
- optional valid result envelope or exact Wire decode failure;
- applicable existing adapter-authored C2A observations;
- zero or more exact source-native Wire process supplements;
- exact attempt/effect fences;
- when cancellation evidence is present, the separately supplied cancellation
  effect/delivery/target relation required by the owning C2A/RW0-A contracts.

The classifier authors no source fact.

A result is `usable` only when all are true:

- one valid related worker-result envelope exists;
- exactly one applicable process-exit observation exists;
- that exit is successful under the exact existing C2A representation;
- no resource-limit, deadline, signal, or cancellation override is present;
- process facts are internally nonconflicting;
- command, delivery, invocation, candidate, attempt, effect, and fence
  relations are exact.

Adopt this precedence, with exact finite reasons to be named in the packet:

1. invalid or contradictory classifier inputs;
2. resource-limit exceeded;
3. deadline reached;
4. signal delivered;
5. current cancellation request/acknowledgement/rejection evidence bound through
   the exact cancellation graph;
6. conflicting or duplicate process facts;
7. adverse process exit:
   - with a valid completed result: process/result contradiction;
   - without one: process failure;
8. missing or invalid result frame after a successful exit:
   protocol failure;
9. valid result but missing/unknown exit:
   incomplete process evidence;
10. valid related result plus one successful exit:
    usable.

Required non-implications:

- cancellation acknowledgement or rejection proves neither signal, exit,
  teardown, reconciliation, nor semantic cancellation;
- process exit zero proves neither a valid result nor worker completion;
- valid worker completion does not override an adverse process fact;
- timestamps do not establish causal order;
- classification is protocol/process evidence only, not B1 terminal outcome,
  C2B decision, RW0-C terminal fact, acceptance, or permission.

If existing cancellation observations cannot be related without adding an
unowned cancellation value, return PARTIAL with the exact smallest missing
owner decision. Do not silently compare author delivery/fence with cancellation
delivery/fence.

8. CANONICAL JSON AND HOSTILE DECODING

Freeze exactly:

- input and output frame type: exact built-in `bytes`;
- strict UTF-8;
- no BOM;
- JSON root must be exact object;
- duplicate object keys rejected during parsing before ordinary dict
  construction;
- floats and constants rejected;
- integer token checked by a bounded `parse_int`-equivalent before integer
  construction;
- exact built-in object/list/string/int/null types;
- no Unicode normalization;
- `ensure_ascii=False`;
- `allow_nan=False`;
- `sort_keys=True`;
- separators `(",", ":")`;
- canonical re-encoding from reconstructed values must equal payload bytes
  byte-for-byte;
- no whitespace, alternate key order, alternate number spellings, escaped
  ASCII substitute, or alternate Unicode encoding is accepted when it differs
  from canonical bytes;
- errors are sealed, content-free, finite, and suppress foreign exception
  chains.

Freeze this stage precedence:

1. invalid outer input type;
2. short header;
3. bad magic;
4. unsupported version;
5. unsupported kind;
6. declared length above kind cap;
7. truncated payload;
8. trailing data;
9. invalid UTF-8;
10. BOM forbidden;
11. JSON syntax/token failure;
12. duplicate key;
13. invalid root/type/scalar;
14. unknown field;
15. missing field;
16. nested C2A reconstruction/digest failure;
17. noncanonical payload bytes;
18. cross-record relation failure.

Within stage 11, the deterministic first parser failure wins. A malformed JSON
document need not be rescanned to search for a later duplicate key.

9. PAYLOAD CAPS

Use the adopted integer cap and exact payload shapes to independently reproduce
the preceding formulas.

The prior reconnaissance reported, conditionally:

```text
command payload maximum = 5,898 bytes
result payload maximum  = 16,627 bytes when the result payload contains only
                          {"observations":[...]} and no payload schema_id
```

Do not accept these numbers merely because they are stated here.

Recompute them from literal test-owned field inventories, scalar maxima, and
canonical serialization. Confirm or correct them.

The final caps must equal the exact largest valid canonical payload, with no
round-number headroom.

Required vectors for each kind:

- exact largest valid payload;
- one semantic decrement below maximum;
- declared cap plus one rejected before payload access;
- representational uint16 maximum rejected by the per-kind cap;
- actual bytes one shorter than declared;
- one trailing byte;
- concatenated second frame.

Observation count is exactly two or three, derived from the closed grammar.
Do not add spare count headroom.

10. STRUCTURAL DEPTH AND CONTAINER COUNTS

Independently reproduce or correct the prior conditional results:

```text
command maximum JSON depth: 3
result maximum JSON depth: 4
command container count: 5
result container count: 8
command key-pair count: 71
result key-pair count: 78
```

Define depth precisely. Freeze exact maximum and one-over nested-input controls.
Depth is a hostile parser guard, not a semantic permission.

11. WHOLE-OPERATION WORK ACCOUNTING

Do not change C2A to accept a B2 counter.

Use one enforceable B2 budget plus exact fixed precharged tariffs for each
nested C2A reconstruction and owning relation call.

The budget must charge before work for:

- exact input and header inspection;
- declared-length validation;
- every payload byte examined by UTF-8 decoding;
- JSON token/scalar/container parsing;
- duplicate-key detection;
- key/cardinality scanning;
- integer digit/range validation;
- canonical re-encoding bytes;
- every nested C2A reconstruction occurrence;
- every owning C2A relation invocation;
- result observation traversal;
- process supplement traversal;
- classifier comparisons;
- called Wire helper work;
- every repeated alias in encode-side caller mappings.

Rules:

- decoder-created JSON is a tree; encode-side mappings still require active-ID
  cycle rejection and repeated alias charging;
- no helper resets the shared B2 budget;
- nested C2A tariffs must be independently derived from their exact maximum
  field/container/cardinality graphs and charged before calling them;
- maximum valid command, result, and classification operations fit exactly or
  below the frozen limit;
- one additional charged occurrence fails deterministically;
- no payload byte, key scan, canonicalization pass, or helper call is outside
  the accounting;
- physical allocation enforcement remains RW0-D, but B2 must reject declared
  oversize before allocation/read.

Return exact formulas and numeric budgets for:

- command encode;
- command decode and relation validation;
- result encode;
- result decode and relation validation;
- process/result classification.

A node-count-only budget, an unpropagated narrative budget, or reliance solely
on payload caps is insufficient for READY.

CAPABILITY SEAM

Retain exactly:

`RW0_B2_CAPABILITY_SEAM_BOUNDED`

unless this closure discovers a concrete contradiction.

Confirm that the fixed Wire profile ref/digest, no outer frame identity, no B1
payload, provider-neutral process supplement, and source-evidence-only
classification leave room for:

- separate declaration;
- independent observation;
- pure qualification;
- binding to accepted Wire profile;
- binding to supplied positive B1 phase/effect/host qualification;
- no self-attestation;
- no provider/session history as program truth;
- no CLI/App Server selection;
- RW0-D/E ownership of credentials, invocation, provider sessions, process
  mechanics, and proof.

Do not freeze Capability classes or authorize Capability implementation.

MANDATORY INSPECTION

Inspect only the exact source/doc/test surfaces needed to close these decisions:

- `.docs/c2a-first-slice-semantic-protocol-contract.md`
- `.docs/c2a1-pure-semantic-values.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/worker-execution-boundary.md`
- `.docs/authority-boundaries.md`
- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `tests/c2a_contract_support.py`
- all `tests/test_worker_execution_semantic_*`
- `tests/test_c2a_relations.py`
- all `tests/test_rw0_b1_*`
- `tests/test_c2a_nonimplementation.py`
- `tests/test_runtime_non_authority.py`
- `tests/test_c2b2_development_row_value_boundaries.py`
- `tests/test_b2a_writer_session_contract.py`
- `tests/test_codex_agent_config.py`
- `src/ge_nwp_coordinator/__init__.py`
- `pyproject.toml`

Inspect another file only for a concrete import, owner, field, observation kind,
or status assertion. Report it.

READ-ONLY CALCULATION POSTURE

Permitted:

- read-only Git/file inspection;
- `python3 -B` calculations with `PYTHONDONTWRITEBYTECODE=1`;
- AST parsing and literal canonical-byte calculations;
- importing only standard library or project modules proven import-side-effect
  free, with no file output and external pycache redirection.

Not permitted:

- tests or collection;
- file creation;
- mutation;
- network or service access;
- model/Codex invocation;
- migration/database creation;
- importing a project module when side-effect freedom has not been established.

REQUIRED CAUSAL COUNTEREXAMPLES IN THE PACKET

Design literal future tests that independently break one predicate at a time:

- each header byte/class;
- each kind/version;
- cap and uint16 boundary;
- truncation and trailing/multiple frames;
- invalid UTF-8 and BOM;
- duplicate root and nested keys;
- float, bool-as-int, oversized integer, leading zero, exponent;
- noncanonical whitespace/key order/escape spelling;
- each command/delivery relation coordinate;
- each result observation kind/order/count/source/invocation/lineage coordinate;
- duplicate observation ref and digest;
- candidate capture mismatch;
- process supplement source/lineage/kind;
- each classifier precedence row;
- cancellation graph mismatch;
- maximum and one-over depth/container/key-pair/work;
- shared aliases and cycles;
- literal profile-manifest mutation and digest mismatch.

Expected bytes, inventories, caps, budgets, and precedence must be test-owned,
not imported from production constants.

EXACT IMPLEMENTATION SURFACE

Freeze one maximum Wire allowlist.

The expected shape is:

- one new detailed governing document;
- one new private production module;
- direct Wire value/codec/vector/relation/boundary tests;
- existing exact source/import/public-boundary inventories;
- bounded RW0 current-status owner/cross-reference updates and their structural
  tests.

Do not merely repeat the previous proposed 14-path ceiling. Derive the exact
path set from live static inventories and status ownership.

Require:

- imports flow from Wire to existing C2A only;
- Wire does not import B1;
- B1 remains byte-identical;
- no package-root export;
- no production caller;
- empty private `__all__`;
- no dependency, pyproject, migration, SQL, schema, StateStore, WriterSession,
  public protocol, script, fixture, or config change.

If a path outside the frozen maximum becomes necessary during later
implementation, that implementation must stop.

REQUIRED FUTURE VALIDATION PLAN

Freeze exact isolated commands for later implementation:

1. opening full node collection;
2. per-file Wire tests;
3. all Wire tests together;
4. C2A compatibility;
5. B1 compatibility;
6. static/public/import inventories;
7. RW0/current-status/docs;
8. candidate final collection and literal delta;
9. full suite once, with at most one explicitly governed repair rerun if all
   changes remain inside the exact allowlist;
10. `git diff --check`, status, mode, import, public-surface, protected-byte,
    residue, operation, and lock guards;
11. exact provenance twice;
12. fresh independent audit before staging.

Use external basetemp, TMPDIR, pycache, JUnit, bytecode suppression, plugin
autoload disabled, empty addopts, `-W error`, serial execution, and
caller/child-umask recording.

PROSPECTIVE FORECAST DISPOSITION

Record:

1. The finite-size forecast was confirmed as an integer-policy gap, not a
   Unicode gap. State whether the adopted int64 Wire policy closes it.

2. The touched-file forecast was too small. State the final exact ceiling and
   which static/status owners caused expansion.

3. The predicted audit classes remain live. State the exact future audit
   perspectives for parser precedence/work, identity/noncollapse, test
   causality, security/privacy, and provenance.

VERDICT

Return exactly two status lines first:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_READY
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

only when every Wire class, field, type, profile identity, byte, cap, depth,
container/key count, work formula, error, precedence row, relation, module,
touched path, test oracle, validation command, audit requirement, and stop
condition is exact and source-grounded.

Otherwise return:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_PARTIAL
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

or:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_BLOCKED
RW0_B2_CAPABILITY_BLOCKED
```

as evidence requires.

READY must include one complete implementation packet with:

1. baseline and inspection boundary;
2. adopted policy decisions and source support;
3. exact protocol-profile manifest/ref/digest domain;
4. exact class/value inventory;
5. exact function/relation inventory and signatures;
6. exact frame diagrams and payload mappings;
7. exact canonicalization and decoder precedence;
8. exact payload/depth/container/key/work formulas and numeric results;
9. exact result grammar and process classifier matrix;
10. Capability seam confirmation;
11. exact module/import ownership;
12. exact maximum touched-file allowlist;
13. protected surfaces;
14. literal causal test plan;
15. exact future validation commands;
16. provenance and fresh-audit plan;
17. exact stop conditions;
18. path:line claim ledger;
19. unresolved RW0-C/D/E/ES seams;
20. prospective-forecast dispositions.

NEXT STEP

If and only if the two READY/BOUNDED tokens are returned, the next permitted
step is one bounded parent-only `RW0-B2-Wire` implementation prompt.

Do not issue, imply, or prepare a Capability implementation prompt.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
