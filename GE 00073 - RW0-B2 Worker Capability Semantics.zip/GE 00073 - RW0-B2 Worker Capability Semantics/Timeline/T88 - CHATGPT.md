## Engineering disposition

**The `BLOCK` is valid. Return to the existing write-enabled Capability implementation conversation for one final, two-file test repair.**

The result is narrower than the preceding audit:

- Capability canonical-reason identity passed every external mutant.
- The thirteen-relation B1 matrix passed every external mutant.
- Production source, governing documents, privacy boundaries, imports, and authority ownership remain correct.
- Only the two complete-document Markdown oracles remain insufficient.

This continues the established separation between sound production semantics and inadequate regression-oracle coverage. 

### Exact repair boundary

Only these two already-dirty paths may change:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The other 28 candidate entries must remain byte-identical. Final topology remains:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
all regular mode 0644
```

No source or documentation change is justified.

### What the repair must close

The implementation conversation must recover and preserve the exact external-mutant corpus from:

```text
/private/tmp/ge-coordinator-rw0-b2-final-test-audit.qOlJrT/external_mutant_results.json
```

It must then mechanically reject:

```text
20/20 B1 stale semantic claims
3/3 B1 Markdown-equivalent hidden heading duplicates
16/16 RW0 contradictory status claims
3/3 RW0 Markdown-equivalent hidden heading duplicates
42/42 total audit survivors
```

The important change is architectural **within the tests**: both oracles must parse the entire authoritative Markdown file, not selected sections or literal sentence lists.

The prompt freezes a finite test-owned Markdown grammar covering:

- backtick and tilde fences;
- ATX headings with zero to three leading spaces, optional closing hashes, tabs, and correct delimiters;
- Setext headings;
- separate visible-heading and all-heading inventories;
- hidden/fenced duplicate owner headings;
- same-title sibling and relocated owner regions;
- complete-file visible prose and table-row semantic classification.

For B1, the oracle must reject any semantically equivalent current retrieval ceiling other than `1285`, plus zero-consumer and future/unimplemented Capability assertions anywhere visible in the owner.

For RW0, the oracle must use exact component subjects—`RW0-B1`, `RW0-B2-Wire`, and `RW0-B2-Capability`—and reject any visible assertion making those current semantics future, blocked, deferred, absent, unimplemented, or responsible for later C/D/E/ES mechanics.

## Repair handoff

Send this complete prompt to the **existing Capability implementation conversation**:

:chatgpt-content-reference{index="3"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Complete_Markdown_Oracle_Repair_Prompt.txt

Size:
26,188 bytes

SHA-256:
448a80917c93df2bb4616989c2f6df8ce0f3b67c6b0c0a02bbe96a731be1e4b2
```

It is bound to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Opening canonical manifest:
230786a458ed8e484c6ec37416f783cd71b5c47ec67a27d2bdd44afc7fe92772

Opening tracked diff:
7f77ef027a80f0e5cb8dc686fcecf55dc8ca1ef3493c25a5771f7a2be1b9261e

Opening complete output:
f33e22e718b8826ad157ccf0f936abebe06b0699af14feb572dc3c5256d27c83

Opening nodes:
4,905

Opening node-list SHA-256:
1a3b2c384bfe06ee5fdc358e22807cc0e3ad8f0fbeca004a35ee4f97b3adefa9
```

The required implementation result is:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMPLETE_MARKDOWN_ORACLE_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

That result permits only another fresh read-only audit. The project protocol requires repairs to return to the sole-writer implementation conversation, and every changed byte must then receive a new independent audit. 

Only a later independent `ACCEPT` permits staging exactly the audited paths and comparing staged and committed blobs with the accepted manifest. 

### Sources

- Codex audit response supplied in this turn.
- Prior audit separation of implementation correctness from oracle adequacy. 
- Governed Execution repair and re-audit lifecycle. 
- Provenance and audited-byte commit gate. 

**Confidence:** High that the remaining work is confined to these two test files; high that production and documentation should remain protected; medium-high that a complete-file semantic scanner plus a real Markdown heading/fence parser will close the next audit without another source change.
