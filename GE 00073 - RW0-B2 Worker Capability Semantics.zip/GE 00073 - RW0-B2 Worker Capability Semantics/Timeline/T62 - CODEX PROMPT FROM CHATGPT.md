PROMPT_ID

RW0_B2_CAPABILITY_SCHEMA_FREEZE_RECONCILIATION_V1

TITLE

Coordinator RW0-B2-Capability — reconcile safe value revalidation, exact
qualification predicates, hostile-mapping precedence, and cumulative work
budgets before implementation

ENGAGEMENT TYPE

Bounded read-only schema-freeze reconciliation in the Governed Execution
Coordinator repository.

This is not a new broad reconnaissance pass and not an implementation prompt.
Preserve the accepted Capability ownership split, classes, field inventories,
provider/mechanism neutrality, B1 composition direction, Wire binding, and
later-owner boundaries except where an exact contradiction below requires a
narrow correction.

The parent is read-only. Do not create subagents by default. No repository
mutation, formatting, test execution, installation, staging, commit, push, PR,
merge, remote/network/service contact, provider/model/worker invocation,
database operation, migration, or supporting-repository inspection is
authorized.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Verify at opening and closeout:

- branch:
  `trunk_dev`
- HEAD:
  `deec37bf08fb903d8846aa2c3232aec52fa9866e`
- tree:
  `ef48f5bd11244c6f703c97abb5489d19956f7a77`
- sole parent:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- subject:
  `feat: implement RW0-B2 Wire protocol (#4)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- worktree/index/untracked/unmerged:
  clean
- no Git operation, lock, cache, bytecode, database, journal, archive, build,
  generated manifest, or recorder residue.

Do not fetch. Stop on baseline drift.

PRECEDING FREEZE RESULT

The preceding read-only engagement returned:

```text
RW0_B2_CAPABILITY_SCHEMA_FREEZE_READY
RW0_B2_WIRE_PROFILE_BINDING_CONFIRMED
```

Treat the following decisions as accepted and do not reopen them broadly:

1. Capability follows Wire and does not modify B1, Wire, or C2A semantics.
2. Capability consists of exactly:
   - `RW0WorkerMechanismCapabilityDeclarationV1`
   - `RW0WorkerMechanismCapabilityObservationV1`
   - `RW0WorkerMechanismCapabilityQualificationV1`
   - sealed `RW0WorkerMechanismCapabilityError`
   - one pure qualification relation.
3. Declaration, independent observation, and Coordinator qualification remain
   distinct.
4. Declaration source kind is exactly `worker_artifact_owner`.
5. Observation source kind is exactly
   `independent_worker_mechanism_observer`.
6. Unequal safe source refs establish structural non-collapse only; they do not
   authenticate organizational or cryptographic independence.
7. The fourteen mechanism-neutral dimensions and their field names remain:
   - `noninteractive_operation`
   - `wire_command_input_only`
   - `wire_result_output_only`
   - `protocol_stdout_only`
   - `private_bounded_diagnostic_stderr`
   - `external_cancellation_control_supported`
   - `external_deadline_control_supported`
   - `invocation_bound_logical_context`
   - `private_history_non_authority`
   - `isolated_credential_use`
   - `private_interaction_material`
   - `zero_git_effects`
   - `restricted_network_access`
   - `external_session_non_authority`
8. Declaration dimension domain is exactly:
   `supported | unsupported | unknown`.
9. Observation dimension domain is exactly:
   `confirmed | contradicted | unknown`.
10. Qualification result domain is:
    `qualified | blocked | unknown`.
11. The exact accepted Wire pair is:
    - ref: `rw0-wire-nwpf-v1`
    - digest:
      `470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454`
12. The accepted Wire pair is the exact B1 worker-protocol pair. No competing
    Capability requirements profile is created.
13. Concrete CLI/App Server/provider selection, credentials, sessions,
    invocation, process mechanics, physical observation, and numeric process
    limits remain RW0-D/E.
14. RW0-C retains durable evidence membership, completeness, recovery,
    terminal facts, and acceptance-latch ownership.
15. No declaration, observation, qualification, digest, profile, report, or
    provenance value grants permission, authority, acceptance, contact, or
    durable truth.
16. The proposed private module remains:
    `src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py`.
17. Import direction remains:
    `Capability -> B1 + Wire + EffectFenceV1`, never the reverse.
18. No package-root export, public caller, dependency, migration, schema, or
    packaging change is allowed.
19. The preceding 20-path maximum implementation ceiling is retained as a
    hypothesis to confirm, not silently expand.

WHY RECONCILIATION IS REQUIRED

The preceding packet calls itself implementation-ready, but four exact points
remain inconsistent or underspecified.

### R1 — full value revalidation versus stated work budget

The packet says the relation “revalidates the three Capability values,” but its
local work arithmetic is only:

```text
24 + 31 + 26 + 6 = 87
```

That accounts for one flat projection of each value plus five B1/C2A objects
and time.

A single projection plus self-digest comparison is not full reconstruction of
field types, enums, refs, digests, timestamps, result/reason coherence, and
self-digest ownership. It can permit an exact-class object tampered through
`object.__setattr__` and resealed with a matching digest to reach semantic
logic unless every field is reconstructed before use.

Conversely, true reconstruction through each class’s `from_mapping` adds the
three two-pass construction budgets:

```text
declaration:   48
observation:   62
qualification: 52
total:        162
```

Therefore the previously stated composed maximum `328` cannot remain correct
if full revalidation is real.

### R2 — result/reason predicates are not exact enough

The ordered reason list is frozen, but the packet does not define exact,
non-overlapping predicates for:

- `b1_binding_mismatch`
- `declaration_observation_mismatch`
- `self_observation`
- `observation_expired`
- `worker_artifact_mismatch`
- `wire_profile_mismatch`
- evaluation-time mismatch
- declaration unsupported
- observation nonconformance
- capability unknown.

An implementation and causal tests need one exact expected-result function,
including which conditions produce a stored blocked/unknown reason and which
conditions raise sealed `relation_mismatch`.

### R3 — hostile mapping-key precedence is incomplete

The packet says the longest admitted field name is 39 characters and lists
key-type/key-length/ASCII/privacy/unknown/missing precedence, but it does not
freeze:

- the exact admitted unknown-key length;
- whether empty keys are allowed to reach unknown-field handling;
- the exact reason for overlength keys;
- the exact reason for non-ASCII keys;
- order-independent aggregation when multiple unknown keys exist;
- how a privacy-bearing unknown competes with an ordinary unknown and missing
  required fields.

### R4 — Wire pair extraction needs an exact non-substitutable seam

The packet says Capability imports `wire_profile_mapping()` and retains only
the ref/digest pair. It must state exactly:

- when and how the mapping is read;
- which schema/ref/digest fields are checked;
- how the 4,021-byte manifest is discarded rather than retained;
- why caller input cannot substitute another pair;
- whether malformed owner output is an internal invariant failure or a public
  Capability error.

OBJECTIVE

Return one corrected, implementation-ready replacement for only the affected
parts of the Capability freeze.

Do not repeat the entire preceding report unless needed for exactness. Do not
change accepted class names, field tuples, schema IDs, digest domains,
dimension names/domains, ownership, Wire profile identity, B1 relation
signature, later-owner split, or touched-file ceiling without a demonstrated
owning-contract contradiction.

REQUIRED RESOLUTION A — NON-RECURSIVE SAFE VALUE RECONSTRUCTION

Freeze one exact internal reconstruction seam used by:

- every public value method:
  - `to_mapping`
  - `identity_mapping`
  - `canonical_identity_bytes`
  - `computed_digest`
- the Capability qualification relation.

The seam must:

1. Require the exact expected class.
2. Read the private stored tuple with `object.__getattribute__`, not a
   caller-overridable public mapping method.
3. Fail sealed on:
   - missing `_values`;
   - non-exact tuple;
   - wrong tuple length;
   - non-exact-string members;
   - invalid schema literal;
   - invalid enum/ref/digest/timestamp/window/result-reason member;
   - self-digest mismatch.
4. Build one fresh exact built-in mapping in `_FIELDS` order.
5. Reconstruct through the owning class validation without recursive calls to
   the public methods being implemented.
6. Return a fresh reconstructed exact value or fresh safe mapping that all
   semantic logic uses instead of the original object.
7. Suppress foreign cause/context and hostile values from public errors.
8. Ensure ordinary construction, incomplete `object.__new__` instances,
   tampered values, and correctly resealed semantically invalid values fail
   before any semantic comparison.
9. Keep the classes final, slotted, immutable, unhashable, non-pickleable, and
   exact-class structurally comparable.

State the exact private helpers and which helper each public method and relation
uses. Avoid recursion between reconstruction, `from_mapping`, and public digest
methods.

REQUIRED RESOLUTION B — EXACT WORK ACCOUNTING

Freeze exact, mechanically testable work accounting for:

1. `from_mapping` construction of each value;
2. safe reconstruction of an existing value at a public method boundary;
3. the Capability relation’s local work;
4. the separately owned B1 `validate_host_qualification` work;
5. the total successful composed maximum.

The intended minimum-safe accounting is:

```text
V(declaration)   = 1 root + 23 members = 24
V(observation)   = 1 root + 30 members = 31
V(qualification) = 1 root + 25 members = 26

from_mapping:
  2V = 48 / 62 / 52

safe reconstruction of existing stored value:
  stored-state extraction V
  + owning from_mapping 2V
  = 3V = 72 / 93 / 78

Capability local relation:
  72 + 93 + 78
  + 5 supplied B1/C2A object leaves
  + 1 time leaf
  = 249

B1 owner relation:
  241

successful composed maximum:
  490
```

Confirm this arithmetic against the exact proposed algorithm or replace it with
a different exact calculation that still performs full safe reconstruction.
Do not retain the earlier `87` local / `328` composed claim unless an
equally strong reconstruction algorithm mechanically justifies it.

Clarify whether the 490 total is one propagated counter or the exact sum of
separately enforced owner-local counters. Either is acceptable only if no
attacker-controlled work occurs outside all enforced bounds.

Freeze maximum-valid and one-under-budget failure tests, shared-alias charging,
cycle handling, incomplete/tampered state handling, and a class-wide bypass
mutant that proves semantic logic cannot read unreconstructed values.

REQUIRED RESOLUTION C — EXACT QUALIFICATION ALGORITHM

Freeze the qualification relation in exact ordered pseudocode.

Before semantic comparison:

1. Safely reconstruct declaration, observation, and qualification.
2. Require exact types for:
   - phase basis;
   - authority observation;
   - readiness observation;
   - host qualification;
   - current effect fence;
   - `now_utc`.
3. Resolve the fixed Wire pair through the exact owner seam.
4. Invoke B1 `validate_host_qualification(...)` exactly once with the supplied
   six-object ledger.
5. Translate any B1 exception to sealed `relation_mismatch`; do not infer a
   Capability result from structurally invalid B1 evidence.

After a successful B1 call, compute exactly one expected `(result, reason)` in
this order:

1. `b1_binding_mismatch`
2. `b1_host_qualification_blocked`
3. `b1_host_qualification_unknown`
4. `declaration_observation_mismatch`
5. `self_observation`
6. `observation_expired`
7. `worker_artifact_mismatch`
8. `wire_profile_mismatch`
9. `declaration_unsupported`
10. `observation_nonconformant`
11. `capability_unknown`
12. `qualified`

Define every predicate exactly.

Unless repository evidence requires otherwise, freeze these meanings:

- `b1_binding_mismatch`:
  any qualification phase, authority-observation, readiness-observation,
  host-qualification, effect-intent/fence, or evaluation-time coordinate does
  not exactly match the supplied B1 objects, current effect fence, or
  `now_utc`.
- `b1_host_qualification_blocked`:
  B1 host qualification is exactly result `blocked` with its constructor-valid
  B1 reason.
- `b1_host_qualification_unknown`:
  B1 host qualification is exactly result/reason `unknown/unknown`.
- `declaration_observation_mismatch`:
  observation’s declaration ref/digest pair does not equal the declaration’s
  own pair. It does not mean a dimension-state disagreement.
- `self_observation`:
  declaration and observation source refs are equal.
- `observation_expired`:
  `observed_at <= now_utc < expires_at` is false after constructor-valid
  `observed_at < expires_at`.
- `worker_artifact_mismatch`:
  the artifact pair is not identical across declaration, observation,
  Capability qualification, B1 readiness, and B1 host qualification’s required
  artifact pair.
- `wire_profile_mismatch`:
  the profile pair is not identical across declaration, observation,
  Capability qualification, the fixed owner-controlled Wire pair, B1 readiness
  worker-protocol pair, and B1 host qualification’s required worker-protocol
  pair.
- `declaration_unsupported`:
  at least one declaration dimension is `unsupported`.
- `observation_nonconformant`:
  no declaration dimension is unsupported and at least one observation
  dimension is `contradicted`.
- `capability_unknown`:
  no earlier condition applies and at least one declaration dimension is
  `unknown` or one observation dimension is `unknown`.
- `qualified`:
  every declaration dimension is `supported`, every observation dimension is
  `confirmed`, and every prior relation is satisfied.

State whether observation artifact/profile/declaration binding mismatches are
checked before self-observation exactly as above.

Require the reconstructed qualification’s stored `(result, reason)` to equal
the computed pair; otherwise raise sealed `qualification_reason_mismatch`.

REQUIRED RESOLUTION D — HOSTILE MAPPING CLOSURE

Freeze direct `from_mapping` closure exactly.

Required direction:

1. Exact built-in `dict` only.
2. If cardinality exceeds `len(_FIELDS) + 1`, reject in O(1) before key
   traversal.
3. Every key must be exact built-in `str`.
4. Key length must be in the exact frozen interval. Source-ground whether the
   interval is `1..39`; do not leave it implicit.
5. Keys must be ASCII.
6. Accepted field names are recognized before private-fragment checks.
7. Aggregate unknown-key findings independent of insertion order.
8. If any unknown key contains a private fragment, return
   `privacy_forbidden_material`.
9. Otherwise, if any unknown key exists, return `unknown_field`.
10. Only then return `missing_field` for absent required fields.

Freeze the exact reason for overlength/empty/non-ASCII keys; the likely reason
is `invalid_length_or_cardinality`, but confirm it explicitly.

Keep the preceding private-fragment inventory unless an exact accepted field
creates a conflict.

REQUIRED RESOLUTION E — FIXED WIRE OWNER SEAM

Freeze one non-substitutable Wire binding approach.

Required direction:

- import the private `wire_profile_mapping` function;
- read it at module initialization into a temporary fresh mapping;
- require exact built-in outer mapping and exact owner schema/profile/digest;
- require:
  - schema:
    `governed-execution.nwp-rw0-wire-protocol-profile.v1`
  - ref:
    `rw0-wire-nwpf-v1`
  - digest:
    `470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454`
- extract only the two exact strings needed by Capability;
- discard the manifest and temporary mapping;
- expose no caller parameter that can replace the authoritative pair;
- do not copy or retain the 4,021-byte manifest in any Capability value.

State the fail-closed behavior if the imported owner mapping is malformed.
Prefer an internal import-time invariant failure rather than a public
caller-triggered Capability error, unless repository convention requires
otherwise.

REQUIRED RESOLUTION F — ERROR AND PUBLIC-METHOD BOUNDARY

Confirm the exact error contract:

- reasons remain the preceding closed fourteen-member set;
- `.reason` is the only semantic property;
- `args`, `str`, and `repr` contain only the error class name;
- no field path or supplied value is exposed;
- immutable, sealed, non-pickleable;
- public boundaries leave `__cause__` and `__context__` as `None`;
- no foreign traceback local retains hostile payloads.

Require every public value method and the qualification relation to use the
same safe reconstruction boundary. Add causal tests for:

- incomplete object;
- wrong `_values` type;
- wrong tuple length;
- hostile nested member;
- invalid enum/ref/digest/time;
- tampered digest;
- semantically invalid but correctly resealed tuple;
- class-wide reconstruction bypass;
- downstream mismatch that must not mask missing reconstruction.

REQUIRED RESOLUTION G — TOUCHED-FILE CEILING RECHECK

Reinspect only exact import/status inventories necessary to confirm the
preceding 20-path ceiling.

Specifically check whether the new module’s direct imports require any update
to:

```text
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py
```

They should remain protected if Capability directly imports only:

- `EffectFenceV1` from `_worker_execution_semantic_values`;
- the four B1 classes plus `validate_host_qualification`;
- `wire_profile_mapping`.

Return PARTIAL rather than silently adding a 21st path.

Confirm the exact 20-path ceiling or return the smallest corrected ceiling with
source evidence.

TEST AND AUDIT DELTA

Update the future test packet to include:

1. literal test-owned predicate implementation independent of production;
2. every pairwise reason-precedence conflict;
3. full safe-reconstruction tests for all public methods;
4. a selective and class-wide reconstruction-bypass mutant;
5. exact 48/62/52 construction budgets;
6. exact 72/93/78 safe-reconstruction budgets;
7. exact 249 Capability-local and 490 composed maximum;
8. maximum and one-under-budget controls;
9. key cardinality, 1/39/40 length, ASCII/non-ASCII, privacy/ordinary unknown,
   and missing-field overlap;
10. malformed Wire owner mapping controls without changing Wire bytes;
11. bare B1 `qualified` false positive;
12. B1 owner-call causality and exactly-once assertion;
13. source-ref inequality non-authentication wording;
14. no provider/mechanism implication;
15. no 21st touched path.

No tests are run in this engagement.

FINAL DISPOSITION

Return exactly one:

```text
RW0_B2_CAPABILITY_SCHEMA_FREEZE_RECONCILED_READY
RW0_B2_CAPABILITY_SCHEMA_FREEZE_RECONCILIATION_PARTIAL
RW0_B2_CAPABILITY_SCHEMA_FREEZE_RECONCILIATION_BLOCKED
```

Also return exactly one:

```text
RW0_B2_WIRE_PROFILE_BINDING_CONFIRMED
RW0_B2_WIRE_PROFILE_BINDING_CONTRADICTION
```

`RECONCILED_READY` requires:

- exact non-recursive safe reconstruction;
- exact construction/public-method/relation/B1 work accounting;
- exact result/reason predicates and precedence;
- exact mapping key constraints and reasons;
- exact fixed Wire owner seam;
- exact error/public boundary;
- confirmed touched-file ceiling;
- corrected causal test and audit plan;
- no unresolved implementation choice.

If READY, state that the next permitted step is one parent-only workspace-write
Capability implementation prompt. Do not issue that prompt here.

CLOSEOUT

Report:

1. opening and closing baseline;
2. exact accepted decisions retained;
3. exact corrections to the preceding packet;
4. safe reconstruction pseudocode;
5. complete work-budget arithmetic;
6. exact qualification expected-result pseudocode;
7. exact mapping closure and precedence;
8. exact Wire owner binding;
9. error/public boundary;
10. touched-file ceiling;
11. updated tests/audit plan;
12. remaining seams and nonclaims;
13. final statuses.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
```
