## Engineering disposition

**Retry the validation-binding reset in the same implementation conversation. No repository repair or fresh audit is justified yet.**

The stop was entirely procedural:

- the retained recipe source had the correct bytes and identity;
- its new evidence-root copy was created as mode `0600`;
- the wrapper required mode `0400`;
- both recipe launches therefore refused before pytest;
- no live suite, clean-repository setup, clean suite, or node collection ran;
- source opening and closing fingerprints were identical.

This is not a provenance defect in the candidate, retained recipe, or existing evidence. It is a preflight sequencing defect in the reset instructions: they required retained evidence files to finish as `0400`, but did not state unambiguously that the root-local recipe copy must be changed to `0400` **before its first invocation**. The previous broad no-`chmod` wording also made that transition unnecessarily ambiguous.

The corrected replacement:

- scopes the no-mutation/no-`chmod` restriction to the source repository and pre-existing evidence roots;
- explicitly authorizes file creation, atomic rename, and mode hardening inside the new evidence root;
- creates the recipe copy under `umask 077`;
- atomically installs it;
- sets it to exact mode `0400`;
- verifies type, ownership, mode, size, and SHA-256 before the wrapper can launch;
- seals a dedicated `recipe_copy_preflight.json`;
- preserves the failed reset as noncredited historical preflight evidence;
- otherwise keeps the same two-suite, no-repository-mutation validation scope.

## Corrected reset handoff

Send this **complete replacement prompt** to the same write-enabled Capability implementation conversation:

:chatgpt-content-reference{index="0"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Commit_Compatibility_Validation_Binding_Reset_V2_Prompt.txt

Size:
22,769 bytes

SHA-256:
ea9255929b8d3cc7bc5befdc4483e01abea822ad082bf1dc3e97bc2d06df786e
```

The corrected prompt is additionally bound to the failed procedural attempt:

```text
Failed reset root:
/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset.dwDBSw

Failed reset index:
51 rows
9,824 bytes

SHA-256:
15144abc491fb349433810e8ab6324f2b3034b62706f8bc4377dce63e6f2a32f
```

That root must remain unchanged and be classified as:

```text
historical procedural preflight failure
no candidate validation launched
no node collection launched
no live suite launched
no clean repository created
no clean suite launched
candidate/source fingerprints unchanged
superseded by the corrected V2 reset
```

The required successful outcome remains:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_VALIDATION_BINDING_RESET_COMPLETE_READY_FOR_FRESH_REAUDIT
```

Only after that result should a fresh read-only audit resume. The commit gate remains blocked.

### Source

Codex’s `VALIDATION_BINDING_RESET_PROVENANCE_MISMATCH` report supplied in this turn.

**Confidence:** Very high that no repository repair is needed; very high that the failure is fully addressed by establishing and verifying the root-local recipe copy’s `0400` mode before invocation.
