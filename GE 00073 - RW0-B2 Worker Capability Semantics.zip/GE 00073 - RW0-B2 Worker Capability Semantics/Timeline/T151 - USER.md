Here is Codex's response:

# Primary classification

`G7_RESTORE_HARNESS_DEFECT`

Primary mutation classification: **G — a restore-harness schema incompatibility**.

The regular-to-symlink mutant was created correctly and rejected with the exact expected candidate assertion. Attempt 0130 then restored the original file bytes and mode successfully, but the harness failed during post-restore bookkeeping:
```
baseline_index = baseline.pop("index")
```

The normalized fingerprint schema no longer has a top-level `index` field, so this raised:
```
KeyError: 'index'
```

This is not:

- A: the mutant was correctly created.
- B: the file restoration itself succeeded.
- C: no fingerprint equality comparison returned a false result; execution failed before that comparison.
- D: source bytes and the real source index were unchanged.
- E: only the external fixture changed, but that describes scope rather than cause.
- F: the available evidence determines the cause.
- A candidate-test defect: attempt 0129 produced exactly the expected rejection.

# Continuation disposition

`G7_RESTART_FROM_SCRATCH_REQUIRED`

The external fixture’s target file and logical Git index are restored, but G7 itself is not safely resumable:

- attempt 0130 is permanently recorded as `not_creditable`;
- the restore harness must change before the operation can succeed;
- modifying the retained G7 harness would alter the failed evidence root;
- the current orchestration entry requires a bootstrap-only manifest;
- stable-mutant, focused, collection, full-suite, final-guard, cleanup, provenance, report, and index work remains incomplete.

Attempts 0001–0129 remain individually creditable evidence of what they performed, but they cannot be transplanted into a successful complete replay.

# Exact attempt-0130 envelope

No secret values were present, so nothing was redacted.

The original envelope is a regular mode-`0400` file of 378,502 bytes with SHA-256:
```
2edb269784f721724bcc2f3196737865fc5dd47df9a02f1508f2bbed1d6381e9
```

Its two embedded source-object inventories each contain the same 1,522-row array, which makes the literal pretty-printed form too large for a reliable chat response. Every non-row field is reproduced below; the omitted arrays are identified by their exact count and canonical aggregate rather than silently omitted:
```
{
  "actual_outcome": "unexpected_nonzero",
  "argv": [
    "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13",
    "-B",
    "/private/tmp/g7.30c557/u.py",
    "/private/tmp/g7.30c557/a/0130/u.json",
    "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13",
    "-B",
    "/private/tmp/g7.30c557/replay.py",
    "op",
    "stable_restore",
    "regular_to_symlink"
  ],
  "attempt_class": "mutation_cleanup",
  "caller_umask": {
    "effective": "0022",
    "inherited": "0022"
  },
  "candidate_mutated": false,
  "child_pid": 64186,
  "child_umask": {
    "command": [
      "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13",
      "-B",
      "/private/tmp/g7.30c557/replay.py",
      "op",
      "stable_restore",
      "regular_to_symlink"
    ],
    "effective_umask": "0022",
    "inherited_umask": "0022"
  },
  "credit_classification": "not_creditable",
  "duration_ns": 4270762333,
  "exact_environment_allowlist": {
    "GIT_OPTIONAL_LOCKS": "0",
    "HOME": "/Users/ds",
    "LANG": "C",
    "LC_ALL": "C",
    "LOGNAME": "ds",
    "PATH": "/Users/ds/.local/bin:/opt/local/bin:/opt/local/sbin:/Library/Frameworks/Python.framework/Versions/3.13/bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/local/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/appleinternal/bin:/pkg/env/global/bin:/Library/Apple/usr/bin:/Applications/VMware Fusion.app/Contents/Public:/usr/local/go/bin:/Users/ds/.codex/tmp/arg0/codex-arg0AiH6R6:/Users/ds/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override:/Users/ds/.local/bin:/opt/local/bin:/opt/local/sbin:/Library/Frameworks/Python.framework/Versions/3.13/bin:/Users/ds/.cargo/bin:/Users/ds/.lmstudio/bin:/Users/ds/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback:/Applications/ChatGPT.app/Contents/Resources:/Users/ds/.lmstudio/bin",
    "PWD": "/Users/ds/Repositories/Governed Execution Coordinator",
    "PYTEST_ADDOPTS": "",
    "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
    "PYTHONDONTWRITEBYTECODE": "1",
    "PYTHONHASHSEED": "0",
    "PYTHONPYCACHEPREFIX": "/private/tmp/g7.30c557/a/0130/p",
    "SHELL": "/bin/zsh",
    "TMPDIR": "/private/tmp/g7.30c557/a/0130/t",
    "USER": "ds"
  },
  "expected_outcome": "success",
  "external_ambient_git_closing_record": null,
  "external_ambient_git_opening_record": null,
  "external_fingerprint_byte_equal": false,
  "external_repository_post_fingerprint": {
    "device": 16777234,
    "gid": 0,
    "inode": 180043564,
    "mode": "0400",
    "path": "/private/tmp/g7.30c557/a/0130/x1.json",
    "sha256": "7e0d52e8813a7a01f9945c964b96e26cb1089b595ecae4c8e4d55918cc71f0bc",
    "size": 633316,
    "type": "regular",
    "uid": 501
  },
  "external_repository_pre_fingerprint": {
    "device": 16777234,
    "gid": 0,
    "inode": 180043560,
    "mode": "0400",
    "path": "/private/tmp/g7.30c557/a/0130/x0.json",
    "sha256": "d4becacac77fd650c816e6d783384794ed32df17066e86b9644c441fa7983ddb",
    "size": 633272,
    "type": "regular",
    "uid": 501
  },
  "junit_applicability": false,
  "junit_path": null,
  "junit_result": {
    "collected": null,
    "duplicate_junit_identities": null,
    "errors": null,
    "failed": null,
    "junit_identity": null,
    "junit_parse_status": "not_applicable",
    "ordered_junit_node_list": null,
    "ordered_mapping_equals_retained": null,
    "passed": null,
    "skipped": null,
    "unmapped_junit_cases": null,
    "warnings": null,
    "xfailed": null,
    "xpassed": null
  },
  "label": "stable_restore_regular_to_symlink",
  "monotonic_child_end_ns": 707589932255791,
  "monotonic_child_start_ns": 707588581809666,
  "monotonic_end_ns": 707591396334541,
  "monotonic_start_ns": 707587125572208,
  "notes": [],
  "ordered_node_list": null,
  "preflight": {
    "launched": true,
    "status": "launched"
  },
  "purpose": "restore exact State C bytes after mutant regular_to_symlink",
  "python": {
    "executable": "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3",
    "implementation": "CPython",
    "platform": "macOS-26.6.2-arm64-arm-64bit-Mach-O",
    "realpath": "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13",
    "version": "3.13.4"
  },
  "real_index_post_identity": {
    "birthtime_ns": 1790129752464040192,
    "ctime_ns": 1790129752474374670,
    "device": 16777234,
    "gid": 20,
    "inode": 179450507,
    "link_count": 1,
    "mode": "0644",
    "mtime_ns": 1790129752474267337,
    "path": "/Users/ds/Repositories/Governed Execution Coordinator/.git/index",
    "sha256": "7926e411fe75047992b7677548c8a40d090127ce6dbda64c4262d59ca749c213",
    "size": 22476,
    "type": "regular",
    "uid": 501
  },
  "real_index_pre_identity": {
    "birthtime_ns": 1790129752464040192,
    "ctime_ns": 1790129752474374670,
    "device": 16777234,
    "gid": 20,
    "inode": 179450507,
    "link_count": 1,
    "mode": "0644",
    "mtime_ns": 1790129752474267337,
    "path": "/Users/ds/Repositories/Governed Execution Coordinator/.git/index",
    "sha256": "7926e411fe75047992b7677548c8a40d090127ce6dbda64c4262d59ca749c213",
    "size": 22476,
    "type": "regular",
    "uid": 501
  },
  "return_code": 1,
  "schema_id": "governed-execution.unconditional-attempt-envelope.v4",
  "sequence_number": 130,
  "source_ambient_git_closing_record": {
    "device": 16777234,
    "gid": 0,
    "inode": 180043566,
    "mode": "0400",
    "path": "/private/tmp/g7.30c557/a/0130/sa1.json",
    "sha256": "85560f5cf3e7c2383d66d09b0b49840717dc9612f5f762ae4f3c57ed65c5a1f1",
    "size": 761282,
    "type": "regular",
    "uid": 501
  },
  "source_ambient_git_opening_record": {
    "device": 16777234,
    "gid": 0,
    "inode": 180043559,
    "mode": "0400",
    "path": "/private/tmp/g7.30c557/a/0130/sa0.json",
    "sha256": "85560f5cf3e7c2383d66d09b0b49840717dc9612f5f762ae4f3c57ed65c5a1f1",
    "size": 761282,
    "type": "regular",
    "uid": 501
  },
  "source_fingerprint_byte_equal": true,
  "source_object_inventory_post": {
    "aggregate_sha256": "1fe75e2874af1c0707328ad1771672aa8f311b3e8e9b2518939af5ba2f9cd417",
    "object_count": 1522,
    "roots": [
      "deec37bf08fb903d8846aa2c3232aec52fa9866e"
    ],
    "rows": "[1522 exact embedded rows; identical to source_object_inventory_pre.rows]"
  },
  "source_object_inventory_pre": {
    "aggregate_sha256": "1fe75e2874af1c0707328ad1771672aa8f311b3e8e9b2518939af5ba2f9cd417",
    "object_count": 1522,
    "roots": [
      "deec37bf08fb903d8846aa2c3232aec52fa9866e"
    ],
    "rows": "[1522 exact embedded rows; canonical aggregate above]"
  },
  "source_repository_post_fingerprint": {
    "device": 16777234,
    "gid": 0,
    "inode": 180043565,
    "mode": "0400",
    "path": "/private/tmp/g7.30c557/a/0130/s1.json",
    "sha256": "af22ded1f5c53a4f951e7b85c9bbf0261eef667ebf5667d7246088fc8bed1a4e",
    "size": 1421607,
    "type": "regular",
    "uid": 501
  },
  "source_repository_pre_fingerprint": {
    "device": 16777234,
    "gid": 0,
    "inode": 180043558,
    "mode": "0400",
    "path": "/private/tmp/g7.30c557/a/0130/s0.json",
    "sha256": "af22ded1f5c53a4f951e7b85c9bbf0261eef667ebf5667d7246088fc8bed1a4e",
    "size": 1421607,
    "type": "regular",
    "uid": 501
  },
  "stderr": {
    "device": 16777234,
    "gid": 0,
    "inode": 180043568,
    "mode": "0400",
    "path": "/private/tmp/g7.30c557/a/0130/e",
    "sha256": "1ac0ef3583f040b4b0794522d85a4d5c4f527b8ca6985937fe5d9441b31e73fa",
    "size": 596,
    "type": "regular",
    "uid": 501
  },
  "stdout": {
    "device": 16777234,
    "gid": 0,
    "inode": 180043567,
    "mode": "0400",
    "path": "/private/tmp/g7.30c557/a/0130/o",
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "size": 0,
    "type": "regular",
    "uid": 501
  },
  "terminating_signal": null,
  "tooling_error": null,
  "unset_variables": [
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_COMMON_DIR",
    "GIT_DIR",
    "GIT_INDEX_FILE",
    "GIT_OBJECT_DIRECTORY",
    "GIT_WORK_TREE",
    "PYTHONTRACEMALLOC",
    "PYTHONWARNINGS"
  ],
  "wall_child_end_utc": "2026-09-25T01:33:06.882862+00:00",
  "wall_child_start_utc": "2026-09-25T01:33:05.532364+00:00",
  "wall_end_utc": "2026-09-25T01:33:08.346974+00:00",
  "wall_start_utc": "2026-09-25T01:33:04.076100+00:00",
  "working_directory": "/Users/ds/Repositories/Governed Execution Coordinator"
}
```

# Referenced evidence

All direct file identities in the envelope exist and their current hashes verify against the envelope.

| RecordPurposeType/modeBytesSHA-256                                 |                                 |                |           |                                                                    |
| ------------------------------------------------------------------ | ------------------------------- | -------------- | --------- | ------------------------------------------------------------------ |
| `/private/tmp/g7.30c557/a/0130/envelope.json`                      | Attempt envelope                | regular `0400` | 378,502   | `2edb269784f721724bcc2f3196737865fc5dd47df9a02f1508f2bbed1d6381e9` |
| `/private/tmp/g7.30c557/a/0130/u.json`                             | Child command/umask record      | regular `0400` | 261       | `b12ef93718fb01c4e3a1346f191424cfcdd30ebd62640b01be94d7e277e0a682` |
| `/private/tmp/g7.30c557/a/0130/o`                                  | Exact stdout                    | regular `0400` | 0         | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `/private/tmp/g7.30c557/a/0130/e`                                  | Exact stderr                    | regular `0400` | 596       | `1ac0ef3583f040b4b0794522d85a4d5c4f527b8ca6985937fe5d9441b31e73fa` |
| `/private/tmp/g7.30c557/a/0130/s0.json`                            | Source pre-fingerprint          | regular `0400` | 1,421,607 | `af22ded1f5c53a4f951e7b85c9bbf0261eef667ebf5667d7246088fc8bed1a4e` |
| `/private/tmp/g7.30c557/a/0130/s1.json`                            | Source post-fingerprint         | regular `0400` | 1,421,607 | `af22ded1f5c53a4f951e7b85c9bbf0261eef667ebf5667d7246088fc8bed1a4e` |
| `/private/tmp/g7.30c557/a/0130/sa0.json`                           | Source ambient pre-observation  | regular `0400` | 761,282   | `85560f5cf3e7c2383d66d09b0b49840717dc9612f5f762ae4f3c57ed65c5a1f1` |
| `/private/tmp/g7.30c557/a/0130/sa1.json`                           | Source ambient post-observation | regular `0400` | 761,282   | `85560f5cf3e7c2383d66d09b0b49840717dc9612f5f762ae4f3c57ed65c5a1f1` |
| `/private/tmp/g7.30c557/a/0130/x0.json`                            | External raw pre-fingerprint    | regular `0400` | 633,272   | `d4becacac77fd650c816e6d783384794ed32df17066e86b9644c441fa7983ddb` |
| `/private/tmp/g7.30c557/a/0130/x1.json`                            | External raw post-fingerprint   | regular `0400` | 633,316   | `7e0d52e8813a7a01f9945c964b96e26cb1089b595ecae4c8e4d55918cc71f0bc` |
| `/Users/ds/Repositories/Governed Execution Coordinator/.git/index` | Real source index, pre and post | regular `0644` | 22,476    | `7926e411fe75047992b7677548c8a40d090127ce6dbda64c4262d59ca749c213` |

Referenced execution files also exist:

- Python 3.13.4 executable: regular `0775`, 119,424 bytes, SHA-256 `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.
- `/private/tmp/g7.30c557/u.py`: regular `0400`, 621 bytes, SHA-256 `f95ce07c84c04d9b24f47d7458fa7f3878dc5e2b5b1ed1334efc086605e070fa`.
- `/private/tmp/g7.30c557/replay.py`: regular `0400`, 160,786 bytes, SHA-256 `e9d02006b9342b5a4b80172601351109750df0504cf2abc2f7b9460b60e239fc`.
- Attempt `p` and `t` directories both exist as mode `0700` directories.
- External ambient records and JUnit records are correctly null/not-applicable for this cleanup attempt.

Exact `u.json`:
```
{
  "command": [
    "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13",
    "-B",
    "/private/tmp/g7.30c557/replay.py",
    "op",
    "stable_restore",
    "regular_to_symlink"
  ],
  "effective_umask": "0022",
  "inherited_umask": "0022"
}
```

Exact stdout was zero bytes:
```
```

Exact stderr:
```
Traceback (most recent call last):
  File "/private/tmp/g7.30c557/replay.py", line 2685, in <module>
    raise SystemExit(main())
                     ~~~~^^
  File "/private/tmp/g7.30c557/replay.py", line 2678, in main
    return dispatch_op(sys.argv[2:])
  File "/private/tmp/g7.30c557/replay.py", line 2655, in dispatch_op
    elif operation == "stable_restore": op_stable_restore(rest[0])
                                        ~~~~~~~~~~~~~~~~~^^^^^^^^^
  File "/private/tmp/g7.30c557/replay.py", line 1647, in op_stable_restore
    baseline_index = baseline.pop("index")
KeyError: 'index'
```

Material large-record fields:

- `s0.json == s1.json` byte-for-byte.
- Embedded source object inventories: 1,522 objects, root `deec37bf08fb903d8846aa2c3232aec52fa9866e`, aggregate `1fe75e2874af1c0707328ad1771672aa8f311b3e8e9b2518939af5ba2f9cd417`, identical pre/post.
- `sa0.json == sa1.json` byte-for-byte. Source raw-index, ref-storage, reflog, turn-diff-ref, and object-storage observations all remained identical.
- `x0.json`: 3,287 rows, internal aggregate `2f209b806c8815841eabbd68b0355206ed20422ce318c2247ef0fd13411a8da9`.
- `x1.json`: 3,287 rows, internal aggregate `73840d5d902faa19f4ac37f85032c421f16198cb134687cc36d255755aa2bf6e`.
- Exactly two raw external rows changed: the intended target and external `.git/index`; there were no additions or removals.
- Restore backup: regular `0400`, 16,611 bytes, SHA-256 `d338979d87d09eadbddad79c249b0d3936fa8b41cc87dc787ed5211a90de279e`.
- Restore metadata: regular `0400`, 286 bytes, SHA-256 `b4e1de5987fc0bbd4e31ac668b27855bf87e21f62a2c70161c6c03cb5f546372`.
- Mutant-source record: regular `0400`, 224 bytes, SHA-256 `0e6cdfa2c541edf6381c14392f045ea27d764686602d86f490465c05b505f65c`.
- State-C baseline: regular `0400`, 191,392 bytes, SHA-256 `3dc165b8f91190d25d44a4d80d6917ccbaa413bcd38d08bff73682a6d91fa9da`.

# Failure chronology

1. The canonical external State-C repository was `/private/tmp/g7.30c557/x/r`.
2. Before mutation, `.docs/rw0-b2-capability.md` was:
   - type: regular;
   - mode: `0644`;
   - size: 16,611 bytes;
   - SHA-256: `d338979d87d09eadbddad79c249b0d3936fa8b41cc87dc787ed5211a90de279e`.
3. Attempt 0128 saved those bytes and mode, unlinked the regular file, and created:
   ```
   /private/tmp/g7.30c557/x/r/.docs/rw0-b2-capability.md
       -> rw0-b2-wire-protocol.md
   ```
   The recorded symlink had mode `0755`, size 23, and target `rw0-b2-wire-protocol.md`.
4. Attempt 0129 ran the single expected boundary test. Expected result: exit 1 with:
   ```
   required_regular_file:.docs/rw0-b2-capability.md
   ```
   Actual result: exit 1 with exactly that assertion. The attempt was credited.
5. Attempt 0130 began with the target still a symlink and invoked `op_stable_restore("regular_to_symlink")`.
6. The restore helper:
   - detected and removed the symlink;
   - recreated the target from the 16,611-byte backup;
   - restored mode `0644`;
   - recomputed the SHA-256;
   - passed the explicit `before_sha256` check;
   - loaded the State-C baseline;
   - computed a current normalized fingerprint.
7. It then tried to remove a legacy top-level `index` field from the baseline:
   ```
   baseline_index = baseline.pop("index")
   ```
8. The baseline uses schema `governed-execution.normalized-authoritative-git-fingerprint.v1`, which deliberately has `logical_index_ls_files_stage_z` and no top-level `index`. `dict.pop("index")` raised `KeyError`.
9. Because that exception occurred first:
   - `current.pop("index")` did not run;
   - normalized equality was not evaluated;
   - `external_index_refresh_regular_to_symlink.json` was not written;
   - no success stdout was emitted;
   - the command returned 1;
   - the recorder classified attempt 0130 as `unexpected_nonzero` and `not_creditable`.
10. Post-attempt evidence shows the target restored as a regular `0644` file with the exact original size and SHA-256.
11. The external `.git/index` changed physically from SHA-256 `94a20d5306d6a0f74df4f3c20efd6d44909a38808bdb4d4572fe698be3b6fbc3` to `124466650ac3aaffb250be722500f1c41b4f8dfe4059d15a4bb23f4581d1c322`, with size unchanged at 23,225 bytes.
12. A read-only parser of that existing index found:
    - signature `DIRC`;
    - version 2;
    - 206 entries;
    - logical stage serialization size 19,696;
    - logical SHA-256 `1cdac7973c506cb59645c710327cdb466cf1789572858f3a22695e910545ee63`;
    - byte equality to the retained State-C baseline logical index: `true`.

Thus the physical index difference is non-logical bookkeeping/stat-cache drift. The exact Git subcommand responsible was not separately recorded.

The exact first failure in attempt 0130 was not an assertion predicate. It was the `KeyError` raised by `baseline.pop("index")` at `replay.py:1647`.

# Source repository state

Recorded pre/post values are exact and equal:

- Root: `/Users/ds/Repositories/Governed Execution Coordinator`
- Branch: `codex/rw0-b2-capability-semantics-v1`
- HEAD: `deec37bf08fb903d8846aa2c3232aec52fa9866e`
- HEAD tree: `ef48f5bd11244c6f703c97abb5489d19956f7a77`
- Parent: `02450d3c99faf0fe7b299b914afaed312421bc8b`
- Upstream: `origin/trunk_dev`
- Upstream OID: `deec37bf08fb903d8846aa2c3232aec52fa9866e`
- Ahead/behind: `0/0`
- Topology: exactly one recorded worktree at the source path, on `refs/heads/codex/rw0-b2-capability-semantics-v1`
- Porcelain-v2 status hash: `f3543ec1e5a9bf25aa426c0d438c41082dad754a045e7346c9e618599b72e940`
- Binary tracked/worktree diff hash: `b61debf25b37e3e4be32678eec33ea60bbd4ca8e7052344b043a6df0da6d8f76`
- Textual candidate diff hash: `cc91155aff703e1c54c139820f841d98135f37ee7c87a71d3b00b07a2672e2a6`
- Cached diff hash: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Logical index hash: `8f170467abeba2d935a917de2e057eb75635efc555f5a44bfb6cb9c77934c019`
- Candidate manifest hash: `d6f86248da0c4843e20b91cb443f960596e483e08a8f2cff716bbcea4fb553d8`
- Computed candidate tree: `0fcf6680ded68d66f62b75b5dc842d69b343a334`
- Candidate-mutated: `false`
- Source fingerprint pre/post equality: `true`
- Real source index pre/post equality: exact byte and metadata equality
- Reachable-object graph: 1,522 objects, aggregate `1fe75e2874af1c0707328ad1771672aa8f311b3e8e9b2518939af5ba2f9cd417`, unchanged
- Authoritative refs: unchanged
- Ambient source record: byte-identical pre/post
- Operation locks/residue: none

The source repository and its real index were not affected.

# External fixture state

- Root: `/private/tmp/g7.30c557/x/r`
- State: detached State-C commit
- HEAD: `f612c40f3fb23a494476a85b4d790e69fa6bcff8`
- Parent: `deec37bf08fb903d8846aa2c3232aec52fa9866e`
- Commit tree: `0fcf6680ded68d66f62b75b5dc842d69b343a334`
- Baseline clean-status, worktree diff, and cached diff: clean/empty
- Baseline logical index: 19,696 bytes, SHA-256 `1cdac7973c506cb59645c710327cdb466cf1789572858f3a22695e910545ee63`
- Current logical index: exactly equal to that baseline
- Attempt-0130 pre raw fingerprint file hash: `d4becacac77fd650c816e6d783384794ed32df17066e86b9644c441fa7983ddb`
- Attempt-0130 post raw fingerprint file hash: `7e0d52e8813a7a01f9945c964b96e26cb1089b595ecae4c8e4d55918cc71f0bc`
- Mutated path: `.docs/rw0-b2-capability.md`
- Final type: regular
- Final mode: `0644`
- Final size: 16,611
- Final SHA-256: `d338979d87d09eadbddad79c249b0d3936fa8b41cc87dc787ed5211a90de279e`
- Final symlink: none
- Parent `.docs` recorded before and after as directory `0755`, size 1,632, uid 501, gid 0
- Parent inode/timestamps were not part of the raw fingerprint and are unavailable
- Other changed path: only external `.git/index`
- Physical index residue: its raw hash differs from the pre-attempt hash
- Logical index residue: none
- Target-file mutation residue: none

Explicit restore answers:

- Symlink removed: **yes**
- Original regular file recreated: **yes**
- Exact bytes restored: **yes**
- Exact mode restored: **yes**
- Parent directory unchanged under the recorded schema: **yes**
- Other changed path: **external&#x20;****`.git/index`****&#x20;only**
- Cleanup began: **yes**
- Cleanup command completed successfully: **no**
- External fixture logically reusable: **yes**
- Current G7 replay resumable: **no**

# G7 phase completion

| PhaseStatusLatest sequence            |                           |                               |
| ------------------------------------- | ------------------------- | ----------------------------- |
| Bootstrap                             | `COMPLETE_AND_CREDITABLE` | 0001                          |
| Recorder self-test                    | `COMPLETE_AND_CREDITABLE` | 0007                          |
| Opening gate                          | `COMPLETE_AND_CREDITABLE` | 0020                          |
| Recipe-copy preflight                 | `COMPLETE_AND_CREDITABLE` | 0018                          |
| Opening recipe runs                   | `COMPLETE_AND_CREDITABLE` | 0027                          |
| Canonical controls and causal sealing | `COMPLETE_AND_CREDITABLE` | 0103                          |
| Closed-call mutants                   | `COMPLETE_AND_CREDITABLE` | 0071                          |
| Protected-content mutants             | `COMPLETE_AND_CREDITABLE` | 0102                          |
| Stable-contract mutants               | `PARTIAL`                 | 0129 creditable; 0130 failed  |
| A/B/C setup and runs                  | `COMPLETE_AND_CREDITABLE` | 0123                          |
| Focused pytest groups                 | `NOT_STARTED`             | —                             |
| Node collection                       | `NOT_STARTED`             | —                             |
| Live suite                            | `NOT_STARTED`             | —                             |
| Clean suite                           | `NOT_STARTED`             | —                             |
| Final guards                          | `NOT_STARTED`             | —                             |
| Cleanup                               | `PARTIAL`                 | 0130 attempted, noncreditable |
| Final provenance                      | `NOT_STARTED`             | —                             |
| Report                                | `NOT_STARTED`             | —                             |
| Index                                 | `NOT_STARTED`             | —                             |

Within the stable-contract phase:

- missing-required-path probe/assert: complete and credited, 0124–0125;
- unexpected-literal-path probe/assert: complete and credited, 0126–0127;
- regular-to-symlink setup/test: complete and credited, 0128–0129;
- regular-to-symlink cleanup: attempted and noncreditable, 0130;
- remaining stable mutants and matrix seal: not started.

# Evidence completeness

| Evidence categoryResult           |                                                                        |
| --------------------------------- | ---------------------------------------------------------------------- |
| argv/action identity              | Complete                                                               |
| Environment                       | Complete allowlist plus explicit unset-variable list                   |
| Python identity                   | Complete                                                               |
| Timing                            | Complete wall and monotonic parent/child values                        |
| PID                               | Complete: child PID 64186                                              |
| Return code/signal                | Complete: return code 1, signal null                                   |
| stdout                            | Complete and hash-verified; zero bytes                                 |
| stderr                            | Complete and hash-verified                                             |
| Expected/actual result            | Complete: `success` / `unexpected_nonzero`                             |
| Source pre/post fingerprint       | Complete and byte-equal                                                |
| Source ambient pre/post           | Complete and byte-equal                                                |
| Source object inventory           | Complete in envelope; 1,522 identical pre/post rows                    |
| External raw pre/post fingerprint | Complete                                                               |
| Candidate-mutated result          | Complete: false                                                        |
| External-fixture-mutated result   | Complete as raw inequality plus exact row delta                        |
| Cleanup state                     | Sufficient to prove target restoration, but no successful cleanup seal |

Missing because execution stopped at the `KeyError`:

- no successful normalized external comparison result;
- no `external_index_refresh_regular_to_symlink.json`;
- no success stdout;
- no explicit cleanup-success field;
- no persisted `current_raw` normalized fingerprint from inside the child;
- no exact attribution of which internal Git command changed the physical external index;
- no parent inode/timestamp comparison.

These omissions do not obscure the cause. Attempt 0130’s unconditional failure envelope is complete as a failure record, but it is not proof of a successfully completed cleanup.

# Required answers

1. **What exact assertion first failed?**\
   No attempt-0130 assertion failed. The first failure was `KeyError: 'index'` from `baseline.pop("index")` at line 1647. In attempt 0129, the intended candidate assertion was `required_regular_file:.docs/rw0-b2-capability.md`.
2. **What exact path was supposed to be restored?**\
   `/private/tmp/g7.30c557/x/r/.docs/rw0-b2-capability.md`.
3. **What type was it before mutation?**\
   Regular file.
4. **What symlink target was installed?**\
   `rw0-b2-wire-protocol.md`.
5. **Did the intended mutant produce the expected test failure?**\
   Yes, exactly.
6. **Did the restore command return successfully?**\
   No; it returned 1 after restoring the file.
7. **What type did the path have after restore?**\
   Regular file.
8. **Did restored bytes and mode equal the original?**\
   Yes: mode `0644`, 16,611 bytes, SHA-256 `d338979d87d09eadbddad79c249b0d3936fa8b41cc87dc787ed5211a90de279e`.
9. **Did the source repository change?**\
   No.
10. **Did the real source Git index change?**\
    No. Its complete pre/post identity was equal.
11. **Did only the external fixture change?**\
    Yes. Within it, the target was restored and the physical index changed; the logical index remained equal to baseline.
12. **Is attempt 0130’s envelope complete?**\
    Yes as an unconditional failure envelope; no as a successful cleanup seal.
13. **Are attempts 0001–0129 still creditable?**\
    Yes individually. They are not sufficient for complete G7 acceptance.
14. **Can G7 continue without rerunning pytest or mutation probes?**\
    No. The retained root cannot become the required complete fresh replay, and substantial validation remains unrun.
15. **Where does the next action belong?**\
    A fresh G7 replay after correcting the external staging harness. Repository test repair is not required.

# Recommended next boundary

Correct only the pre-bootstrap replay harness for a new root:

- remove the stale assumption that normalized fingerprints contain a top-level `index`;
- compare normalized fingerprints directly;
- if physical index observations are wanted, retain them separately as report-only evidence;
- explicitly compare `logical_index_ls_files_stage_z` for logical index equality;
- bootstrap a fresh G7 root and rerun the complete prescribed sequence once.

Do not modify or resume `/private/tmp/g7.30c557`, and do not change candidate or test bytes.

# Confidence

High confidence:

- **Cause:** 1.00 — exact traceback and harness source identify it.
- **Source unaffected:** 1.00 — authoritative, ambient, object, and real-index records are byte-identical.
- **Mutant behaved correctly:** 1.00 — attempt 0129 has the exact expected assertion and credited expected-nonzero result.
- **Target file restored:** 1.00 — post-fingerprint and current read-only inspection match backup identity.
- **External logical index restored:** high — a read-only version-2 index parser reproduced the exact baseline 206-entry logical serialization and hash.
- **Fresh restart required:** high — the failed retained root cannot satisfy the complete one-shot closeout contract.

REPOSITORY\_MUTATION\_NOT\_PERFORMED\
REAL\_INDEX\_MUTATION\_NOT\_PERFORMED\
TESTS\_NOT\_RUN\
NODE\_COLLECTION\_NOT\_RUN\
MUTATION\_PROBES\_NOT\_RUN\
THREE\_STATE\_SIMULATION\_NOT\_RUN\
FULL\_SUITE\_NOT\_RUN\
CORRECTNESS\_AUDIT\_NOT\_PERFORMED\
REPAIR\_NOT\_PERFORMED\
STAGING\_NOT\_PERFORMED\
COMMIT\_NOT\_PERFORMED\
PUSH\_NOT\_PERFORMED\
PR\_NOT\_CREATED\
REMOTE\_CONTACT\_NOT\_PERFORMED\
WORKER\_OR\_MODEL\_NOT\_INVOKED\
SUPPORTING\_REPOSITORIES\_NOT\_MODIFIED
