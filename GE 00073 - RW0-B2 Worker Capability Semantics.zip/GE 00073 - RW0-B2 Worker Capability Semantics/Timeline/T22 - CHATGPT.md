## Assessment

Codex stopped correctly. The gap is not semantic and not a repository-scope mismatch; it is an **evidence-binding failure**.

The retained collection record proves the node list and tracked diff, but it does not record sizes or SHA-256 hashes for the six untracked files. Therefore it cannot prove that the current untracked bytes are the bytes that produced candidate-collection attempt 001. Path count and aggregate tracked-diff equality are insufficient when untracked files exist. Project provenance guidance explicitly requires per-path classification, mode, size, and hash, and warns against relying on aggregate diff or file-count equality for untracked content.  

We should **not** ask Codex to infer that equality, and we should not restore or restart the whole implementation.

## Engineering decision

Rebaseline the **current** preserved 16-path candidate before mutation:

1. Run the exact provenance recipe twice now, producing a new authoritative continuation-opening manifest that includes all six untracked files’ sizes and hashes.
2. Run one read-only reconciliation collection on those newly bound bytes.
3. Require that collection to reproduce the retained 4,629-node attempt-001 list exactly:
   - all 4,566 opening nodes;
   - 60 additions in the four new Wire files;
   - the same three misplaced existing-file nodes.
4. Only then perform the bounded three-file node-placement repair.
5. Run one corrected collection expecting 4,626 nodes and exactly 60 additions in the four new Wire files.
6. Resume focused validation, the complete suite, final guards, and final provenance.

This is honest about the evidence:

- attempt 001 remains preserved;
- attempt 001 receives no **current-byte identity** credit;
- the live candidate becomes a newly exact baseline;
- the implementation is then validated completely from that new baseline.

A repair remains correctly located in the existing write-enabled implementation conversation; changed bytes will still require a later fresh independent audit. 

## Replacement continuation

Use this complete V3 prompt in the **same workspace-write Codex conversation**:

:chatgpt-content-reference{index="2"}

Verify the attachment before sending:

```text
PROMPT_ID
RW0_B2_WIRE_NODE_PLACEMENT_CONTINUATION_V3_REBASELINE_CURRENT_CANDIDATE

Filename
Coordinator_RW0_B2_Wire_Node_Placement_Continuation_V3.txt

Size
16,822 bytes

SHA-256
5f0aa66aa3edf7884bdd7dd6ebe669689c4d8aebf854989b71caff39595479f6
```

This prompt supersedes the original implementation prompt and both earlier continuation files.

Its required sequence is:

```text
current 16-path provenance ×2
→ continuation-opening collection: 4,629 nodes
→ three-file node-placement repair
→ corrected collection: 4,626 nodes
→ focused validation
→ complete-suite attempt 001
→ optional governed attempt 002
→ final provenance ×2
```

The success token remains:

```text
COORDINATOR_RW0_B2_WIRE_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT
```

No independent audit, staging, commit, push, PR, remote contact, or Capability implementation is authorized.

### Sources

- Provenance requirements for exact changed and untracked file identities. 
- Provenance anti-patterns concerning aggregate hashes and file-count equality. 
- Parent-only repair followed by a new independent audit. 
- Codex stop report supplied in this turn.

**Confidence:** High that rebaselining the preserved live candidate is safer and more efficient than restarting implementation; high that the missing historical untracked hashes need not block progress once the current bytes are freshly bound and recollected.
