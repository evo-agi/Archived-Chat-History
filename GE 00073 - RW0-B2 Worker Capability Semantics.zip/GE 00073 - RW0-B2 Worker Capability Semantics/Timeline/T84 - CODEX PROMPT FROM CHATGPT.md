PROMPT_ID

RW0_B2_CAPABILITY_FINAL_TEST_ORACLE_REPAIR_V1

TITLE

Coordinator RW0-B2-Capability — bounded repair of the four remaining
test-oracle findings after final independent re-audit

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing Capability implementation
conversation.

Do not create subagents. The parent is the sole repository writer.

This is not reconnaissance, schema design, production implementation,
independent audit, staging, commit, push, PR, merge, release, deployment,
runtime proof, or supporting-repository work.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Repair exactly four checked-test defects identified by the latest fresh
independent audit:

```text
B1-FINAL-REAUDIT-001
  Medium
  The thirteen-relation matrix does not independently pin the selected object,
  bypass set, and delegation set. Wrong-target, missing class-wide bypass,
  extra selective bypass, and projection-substitution mutants survive.

B1-REAUDIT-002
  Medium
  The B1 owner oracle scans selected subsections rather than the complete
  authoritative owner. Out-of-section stale retrieval/consumer claims and a
  hidden duplicate heading survive.

RW0-STATUS-REAUDIT-001
  Medium
  The RW0 status oracle scans only one H2 and uses an incomplete `RW0-B`
  pattern. Before/trailing, exact Capability-unimplemented, and hidden-duplicate
  mutants survive.

CAP-FINAL-AUD-001
  Low
  Capability tests do not prove that an equal but non-identical exact built-in
  reason string is canonicalized to the module-owned string object. A
  caller-value-retention mutant survives.
```

The independent audit found no production defect, no live documentation
contradiction, and no authority-boundary defect. Therefore this repair is
tests-only.

Do not alter production source or documentation.

OPENING IDENTITY

Before editing require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644
```

Require no Git operation, lock, `git diff --check` failure, repository cache,
bytecode, database, journal, archive, build output, generated repository
manifest, recorder residue, or thirty-first dirty path.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

OPENING AUDIT TARGET

Retained implementation manifest:

```text
/private/tmp/ge-coordinator-rw0-b2-final-repair.jSsN6n/final_closeout/recipe_1.manifest.json
```

Required identities:

```text
canonical-manifest size:
6430 bytes

canonical-manifest SHA-256:
132b7473151706f7bb257aea44efdefad04b7e2e2dab8f3ef5486e46a6e6372f

tracked textual-diff SHA-256:
c3ccbcaa17c6a1140529712b414f8a002a18a76d4b8d8733ca6d63bc2deab821

complete recipe stdout size:
6663 bytes

complete-output SHA-256:
1606765a198803686184f4fff3da59f5e8a00e2d07c80744ac6a0459d46b72f4

file count:
30

opening pytest nodes:
4761

opening ordered-node-list SHA-256:
e9b1d63bc8b1545e96d9569c8a59304268c04e0a702e529ecf9f35b74e83c2d8
```

Latest independent-audit evidence:

```text
/private/tmp/ge-coordinator-rw0-b2-final-reaudit.z9jTj5

full report:
/private/tmp/ge-coordinator-rw0-b2-final-reaudit.z9jTj5/audit_report.md

self-excluding evidence index:
/private/tmp/ge-coordinator-rw0-b2-final-reaudit.z9jTj5/evidence_index.jsonl

index size:
38308 bytes

index SHA-256:
cf5cd72046ccb6da6dcabcb03abcc5a162cfffccd644331deaa3af20dab6ba3c

rows excluding itself:
204
```

The audit confirmed the exact six-entry preceding repair delta and found the
current source/docs semantically correct.

EXACT RECIPE SOURCE

Decode this base64 only beneath one new operator-owned, non-symlink, mode-0700
repair root.

Require exactly 3,945 bytes and SHA-256:

```text
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Retain the decoded source mode 0400.

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

Before mutation:

1. safely `lstat` the retained manifest and audit-evidence path components;
2. require the retained audit index to verify exactly;
3. reproduce the opening manifest and complete output twice with safe
   redirection of only the recipe's external fixed output sink;
4. verify every manifest path by kind, type, mode, size, and SHA-256;
5. verify all paths outside the 30-path candidate equal HEAD;
6. collect the exact 4,761 opening nodes once;
7. stop on any mismatch.

ACCEPTED FACTS — DO NOT REOPEN

The following are accepted for this repair:

- Capability production implementation is correct.
- Capability exact-type reason admission, canonical lookup, empty inherited
  state, honest interpreter-owned context, weak-registry cleanup, hostile
  object rejection, content-free display, serialization rejection, and
  non-authoritative reflective mutation are correct.
- All thirteen B1 production relations reconstruct and use fresh values
  correctly.
- The live B1 owner document correctly states retrieval maximum `1285` and
  Capability as the sole current cross-module consumer.
- The live RW0 owner correctly classifies B1, Wire, and Capability as current
  private semantics and leaves C/D/E/ES later-owned.
- C2A, lineage, B1, Wire, Capability schemas, fields, canonical identities,
  budgets, result grammars, qualification precedence, and authority boundaries
  are unchanged.
- The fixed Wire pair remains:
  `rw0-wire-nwpf-v1` /
  `470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454`.
- No source authentication, permission, acceptance, contact, persistence,
  runtime, provider, credential, endpoint, session, Git, or publication
  authority is created.

This repair must not modify any source or documentation byte.

TEST-FIRST GATE

Before repairing the checked helpers, add or activate test-owned mutant controls
inside only the four authorized test files.

Run one selected red/control gate proving:

1. the current B1 matrix accepts all four audit-surviving mutants;
2. the current B1 owner oracle accepts the required out-of-region and hidden
   duplicate mutants;
3. the current RW0 status oracle accepts the required before/trailing,
   Capability-unimplemented, and hidden-duplicate mutants;
4. the current Capability test set does not distinguish caller-owned equal text
   from the canonical reason object;
5. baseline positive controls remain valid;
6. no syntax, fixture, path, import, collection, or unrelated source failure is
   credited.

Retain exact argv, environment, umask, stdout/stderr, JUnit, node IDs, and
before/after candidate fingerprints.

REPAIR A — CAPABILITY CANONICAL-REASON TEST

Authorized path:

```text
tests/test_rw0_b2_capability_values.py
```

Do not modify Capability source or documentation.

Add one or more causally isolated tests that:

1. select each finite canonical reason, or at minimum a test-owned representative
   plus an inventory assertion covering all finite reasons;

2. construct an equal but non-identical exact built-in `str` deterministically,
   for example through a multi-part join or another method whose identity is
   asserted:

   ```python
   caller_reason = "".join((canonical_reason[:-1], canonical_reason[-1:]))
   assert type(caller_reason) is str
   assert caller_reason == canonical_reason
   assert caller_reason is not canonical_reason
   ```

   Do not rely on a construction that CPython may intern to the original.

3. invoke the real private Capability error factory/boundary through the
   governed test surface;

4. assert:

   ```text
   error.reason is module_canonical_reason
   error._reason is module_canonical_reason
   private weak-registry value is module_canonical_reason
   caller_reason is not retained as the registry value
   BaseException.args remains ()
   ```

5. keep the caller string alive while making the identity assertions;

6. install a test-local caller-value-retention mutant that preserves equality
   but stores/returns the caller-owned exact string, and prove the checked test
   fails on identity;

7. preserve all existing exact-type, hostile-object, chaining, weak-cleanup,
   serialization, and authority-nonclaim coverage.

Do not expose the registry or factory publicly.

REPAIR B — INDEPENDENT THIRTEEN-RELATION TARGET AND LEDGER ORACLES

Authorized path:

```text
tests/test_rw0_b1_relations.py
```

Do not modify B1 production source.

Retain a literal exact inventory of the thirteen public relations:

```text
validate_phase_entry_basis
validate_authority_observation
validate_per_fence_basis
validate_external_common_family_claim
validate_subordinate_narrowing
validate_custody_binding
validate_retrieval_event_sequence
validate_host_qualification
validate_terminal_outcome_binding
validate_normal_terminal_branch
validate_active_cancel_reconciled_branch
validate_active_cancel_unresolved_branch
validate_pre_effect_cancel_basis_unusable_branch
```

### B1. Independent literal specifications

Define test-owned literal specifications that are independent of the fixture
helper that builds relation arguments.

At minimum maintain separate immutable literals for:

```text
RELATION_SELECTED_TARGET
RELATION_EXPECTED_RECONSTRUCTION_CALLS
RELATION_EXPECTED_SELECTIVE_BYPASSES
RELATION_EXPECTED_SELECTIVE_DELEGATIONS
RELATION_EXPECTED_CLASS_WIDE_BYPASSES
RELATION_EXPECTED_CLASS_WIDE_DELEGATIONS
RELATION_EXPECTED_POISON_TARGET
```

Requirements:

- The fixture builder must not supply `target_name` or expected classification
  to the assertion helper.
- The relation arguments and selected target must come from independent
  test-owned sources.
- Validate each literal key set against the independently discovered production
  public relation inventory.
- Validate every target label maps to one exact argument/object occurrence.
- Duplicate labels or ambiguous object identities fail before running a mode.

### B2. Exact selective-mode ledgers

For each relation:

- Begin from an independently valid baseline.
- Forge only the literal selected target's raw schema field and self-digest as
  already established.
- Normal mode must fail exactly `invalid_enum`.
- Selective mode must:
  - bypass exactly the one selected object occurrence;
  - delegate every other expected reconstruction call to the real helper;
  - record ordered bypass and delegation ledgers separately;
  - compare both ledgers with independent literals;
  - prove no second object or occurrence was bypassed;
  - reach the valid expected relation outcome.

### B3. Exact class-wide-mode ledgers

For each relation:

- bypass every and only the literal expected B1 reconstruction occurrence;
- require the exact ordered bypass ledger;
- require the delegation ledger to be empty;
- prove no expected occurrence is missing;
- prove no extra occurrence is bypassed;
- reach the valid expected outcome.

Repeated occurrences of the same logical value must remain distinct in the
ledger where the production call sequence distinguishes them.

### B4. Exact value/projection pair semantics

The production reconstruction helper returns an exact fresh B1 value plus its
safe projection.

The checked matrix must independently assert for every delegated and bypassed
occurrence:

```text
type(reconstructed_value) is expected exact B1 class
type(projection) is dict
projection equals reconstructed_value.to_mapping()
reconstructed_value is not the forged original
```

Do not allow a projection mapping to occupy the exact-value position or an
original/forged value to occupy the reconstructed-value position.

### B5. Required killed mutants

Add explicit test-local mutants and prove the checked matrix fails for every
relation or for a complete relation inventory as appropriate:

1. wrong-selected-object:
   - change the selected target literal to another valid occurrence while the
     forged object remains unchanged;

2. missing-class-wide-bypass:
   - delegate one required occurrence in class-wide mode;

3. extra-selective-bypass:
   - bypass one additional non-selected occurrence;

4. projection-substitution:
   - return the projection mapping in the exact-value slot, swap value and
     projection, or otherwise replace the fresh exact object with projection
     data;

5. omitted delegation:
   - suppress one expected real helper call without recording it;

6. extra delegation:
   - call the real helper for an occurrence not present in the literal sequence.

A mutant must fail because of the independent target/ledger/type oracle, not
because the fixture becomes malformed or a later generic relation error occurs.

### B6. Existing four modes

Preserve and strengthen:

- normal exact `invalid_enum` rejection;
- selective bypass;
- class-wide bypass;
- original-object poisoning after successful reconstruction.

Poisoning must still prove that the relation uses fresh locals and that direct
reconstruction of the poisoned original fails.

Terminal fixtures must be independently valid before mutation.

REPAIR C — COMPLETE B1 OWNER ORACLE

Authorized path:

```text
tests/test_rw0_b1_boundaries.py
```

Do not modify `.docs/rw0-b1-pure-phase-values.md`.

The entire file is the sole authoritative B1 owner. Do not limit stale-current
claim scanning to only selected H2/H3 subsections.

Implement a parser that distinguishes visible Markdown from fenced material,
while also enforcing unique owner structure.

Require:

1. exactly one visible document title/owner root;
2. exactly one visible current relation/work-budget region;
3. exactly one visible current production-consumer/import region;
4. zero hidden/fenced duplicate copies of the exact owner title or designated
   owner-region headings;
5. one current retrieval maximum:
   `validate_retrieval_event_sequence = 1285`
   in the document's actual grammar;
6. no other visible current retrieval cap/limit/maximum/budget assertion
   anywhere in the document;
7. exactly one current statement that Capability is the sole current
   cross-module B1 consumer;
8. no visible claim anywhere in the document that:
   - retrieval is `374`;
   - retrieval is “three hundred seventy-four”;
   - B1 has zero/no/none production callers or consumers;
   - no production module consumes/imports B1;
   - Capability/B2 consumption is future, unimplemented, or absent;
   - `B2-Capability is not yet implemented.`

The scanner may preserve genuinely historical text only when the live document
actually contains an explicit, structurally bounded historical region. Do not
invent a historical exception merely to let a mutant pass.

### Required placements and mutants

Run every forbidden semantic class in at least:

```text
before the expected current region
inside the expected current region
after the expected current region
immediately before the next same-or-higher heading
at document tail
```

Required literal or semantically equivalent mutants include:

```text
The current retrieval maximum is 374.
The current retrieval cap is three hundred seventy-four B1 units.
B1 presently has zero production callers.
No production module currently consumes B1.
Capability consumption remains a future B2 concern.
B2-Capability is not yet implemented.
```

Also require rejection of:

```text
visible duplicate owner title
fenced/hidden duplicate owner title
visible duplicate current relation region
fenced/hidden duplicate current relation heading
visible duplicate consumer region
fenced/hidden duplicate consumer heading
relocated owner region
same-title sibling owner
trailing contradiction
```

Use the same complete checked oracle for positive and mutant cases. Do not
credit a separate weaker helper.

REPAIR D — COMPLETE RW0 STATUS ORACLE

Authorized path:

```text
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Do not modify `.docs/rw0-remote-worker-contact-phase-entry.md`.

The entire file is the sole authoritative RW0 phase-entry owner. Do not confine
forbidden status scanning to one H2.

Use exact component names, not a pattern such as `RW0-B\b` that fails to match
`RW0-B2-Capability`.

Require one unique visible current status/tranche region establishing:

```text
current private semantics:
RW0-B1
RW0-B2-Wire
RW0-B2-Capability

later owners:
RW0-C
RW0-D
RW0-E
Execution Substrate
```

Require zero hidden/fenced duplicate copies of the exact owner title or
designated current status heading.

Reject any visible assertion anywhere in the owner document that labels any of
these as future, blocked, deferred, unimplemented, absent, or the earliest
unresolved tranche:

```text
RW0-B1
RW0-B2-Wire
RW0-B2-Capability
the implemented B tranche
```

Reject any visible assertion assigning physical transport, process, provider,
credential, live runtime, durable ingest, recovery, terminal fact, latch, or ES
runtime ownership back to implemented B semantics.

### Required placements and mutants

Insert each semantic class before, inside, and after the expected status region,
and at document tail.

Required literal or equivalent mutants include:

```text
RW0-B remains blocked until process transport is implemented.
The B tranche is still future; RW0-C cannot begin.
Earliest unresolved tranche: RW0-B.
RW0-B1 remains unimplemented.
RW0-B2-Wire remains blocked.
RW0-B2-Capability remains unimplemented.
B2-Capability is not yet implemented.
| RW0-B | future | physical process plumbing |
| RW0-B2-Wire | blocked | runtime transport |
| RW0-B2-Capability | future | provider integration |
```

Also require rejection of:

```text
visible duplicate owner title
hidden/fenced duplicate owner title
visible duplicate current status heading
hidden/fenced duplicate current status heading
same-title sibling current region
relocated current region
trailing contradiction
```

Use the same complete authoritative oracle for positive and mutant cases.

EXACT REPAIR ALLOWLIST

Only these four already-dirty paths may change from the opening audit target:

```text
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

All other 26 candidate entries must remain byte-identical.

No path may become newly dirty or cease being dirty.

Final topology remains exactly:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
all regular mode 0644
```

Stop if a fifth repair path, source/document change, or thirty-first dirty path
is required.

EXPLICITLY PROTECTED

Everything outside the four repair tests is protected, especially:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-capability.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/rw0-b2-wire-protocol.md

src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml

all Capability relation/vector/boundary tests except the authorized values file
all B1 value/vector tests
all C2A and lineage direct tests
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py

all SQL, migrations, schemas, catalogs
StateStore
WriterSession
package exports
dependency metadata
```

VALIDATION ENVIRONMENT

Use one new external operator-owned, non-symlink, mode-0700 repair root.

For every child:

```text
umask 022 before launch
child numerical umask must be 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Retain exact argv, environment, duration, return code, stdout/stderr, JUnit,
structured counts, and before/after candidate fingerprints.

FINAL VALIDATION ORDER

After final bytes are frozen:

1. selected causal nodes for all four findings;
2. Capability values:
   ```text
   tests/test_rw0_b2_capability_values.py
   ```
3. B1 relations:
   ```text
   tests/test_rw0_b1_relations.py
   ```
4. B1 boundaries:
   ```text
   tests/test_rw0_b1_boundaries.py
   ```
5. RW0 status:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   ```
6. complete Capability compatibility:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   ```
7. complete B1 compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```
8. owner/static/status compatibility:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_rw0_b2_wire_boundaries.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   ```
9. final collection exactly once;
10. require all 4,761 opening nodes in identical relative order;
11. permit additions only in the four authorized test files;
12. report the literal node additions;
13. `git diff --check`;
14. exact path/mode/protected/import/public/residue/operation/lock guards;
15. complete repository suite exactly once.

Do not predeclare final node count.

Every credited green run requires:

- return code 0;
- zero failures/errors/skips/xfails/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate or unmapped cases;
- matching caller/child umask;
- unchanged candidate fingerprint.

FULL-SUITE POLICY

Run complete-suite attempt 001 exactly once on frozen final bytes, using quiet
rendering.

If it fails:

- preserve all evidence;
- repair only a deterministic test defect inside the four paths;
- rerun affected focused groups;
- run complete-suite attempt 002 exactly once.

Stop if:

- failure is outside scope;
- a fifth path is required;
- protected bytes must change;
- a third full-suite attempt would be required.

PROVENANCE CLOSEOUT

After validation and cleanup:

1. require exact topology `30/24/6/0/0`;
2. prove exactly the four authorized test entries changed from the opening
   manifest;
3. prove the other 26 entries are byte-identical;
4. prove every path outside the 30-path candidate equals HEAD;
5. run the exact recipe twice with safe sink redirection;
6. require byte-identical final manifests and complete outputs;
7. retain the new canonical manifest, aggregate identities, opening/final node
   lists and delta, red/green records, complete-suite evidence, and final
   guards;
8. create a self-excluding evidence index;
9. retain files mode 0400 and directories mode 0700;
10. remove only repair-created transient artifacts.

Do not stage, commit, push, create a PR, or perform an independent audit.

STOP CONDITIONS

Stop without further mutation if:

- opening identity or provenance differs;
- any production or documentation change is required;
- any of the four audit mutants cannot be killed through the checked test
  oracles alone;
- the independent target/ledger map reveals a production B1 defect;
- the complete-document oracle reveals a live documentation contradiction;
- an accepted schema, identity, budget, relation, or authority boundary would
  need to change;
- a fifth repair path or thirty-first dirty path is required;
- node ownership, validation, or provenance is unstable.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_FINAL_TEST_ORACLE_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only when all four findings are mechanically closed, all validation is green,
exact provenance is stable, and every stop condition is false.

FINAL REPORT

Include:

1. opening/final identity and provenance;
2. selected red/control evidence;
3. exact four-path delta and 26-path equality ledger;
4. canonical-reason identity test and killed caller-value mutant;
5. independent thirteen-relation target/call/bypass/delegation literals;
6. exact selective and class-wide ledgers;
7. value/projection type and identity proof;
8. all killed B1 matrix mutants;
9. complete B1 owner-region parser and all placements/mutants;
10. complete RW0 owner-region parser and all placements/mutants;
11. node identity and literal additions;
12. every validation attempt;
13. complete-suite result and attempt number;
14. final canonical manifest and aggregate identities;
15. protected/public/authority non-widening;
16. remaining C/D/E/ES seams;
17. separate provenance, validation, and implementation confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
