Do you see `/private/tmp/`\*?

Here is Codex's response:

`STABLE_REPLAY_STATE_MATRIX_FAILED`
G7 stopped fail-closed at attempt `0130`, `stable_restore_regular_to_symlink`. No retry or success token was issued. Evidence: `/private/tmp/g7.30c557/a/0130/envelope.json`
