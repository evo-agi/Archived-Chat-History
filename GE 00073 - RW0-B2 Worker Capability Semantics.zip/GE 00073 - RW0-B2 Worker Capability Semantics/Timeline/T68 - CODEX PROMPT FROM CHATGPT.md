PROMPT_ID

RW0_B2_CAPABILITY_PROTECTED_OWNER_REPAIR_RECONCILIATION_V1

TITLE

Coordinator RW0-B2-Capability — read-only reconciliation of protected B1/C2A
owner hardening, Capability-local audit repairs, exact budgets, and final repair
scope

ENGAGEMENT TYPE

Bounded read-only repair reconciliation after an independent audit BLOCK.

This is not implementation, audit, commit/publication, merge, or deployment.
It must not change repository bytes. It exists because the first Capability
audit widened the repair from a local 20-path patch into a protected-owner
hardening problem whose algorithm, budgets, import direction, touched-file
ceiling, and integration order must be frozen before another workspace-write
turn.

Use the existing Capability implementation conversation after changing its
permission posture back to read-only. Do not use the audit conversation for
repairs.

The parent and all explorers are read-only. No repository mutation,
formatting, tests, dependency installation, staging, commit, push, PR, merge,
tag, release, deployment, remote/network/service/provider/host contact,
worker/model invocation, database mutation, migration, or supporting-repository
inspection is authorized.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED LIVE CANDIDATE

Verify at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
20 paths
14 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate modes:
all regular 0644
```

Require no Git operation, lock, or repository residue. Do not fetch.

CURRENT CANONICAL TARGET

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe bytes:
3945

recipe SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

canonical manifest bytes:
4291

canonical manifest SHA-256:
41a256e52bf5b3e677ec88736889230be416005da429bf5cb3339c92d9427c76

tracked textual-diff SHA-256:
e81ef0ba3e3238a7e6ec428c519f3259bebb6da79cbef318a7045edb45656f5f

complete recipe output bytes:
4524

complete recipe output SHA-256:
8d8ff431ae0aa0362b4d298e5261ba866ca9f7eeae18a3e2f93bb33d233b088b
```

Exact current canonical manifest:

```json
{"branch":"codex/rw0-b2-capability-semantics-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/authority-boundaries.md","sha256":"6a3bf0bbb68b121206f815246c7d0c7acb4368239a9f9c72a766794b08f58e3c","size":32486},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/autonomous-software-development-operating-model.md","sha256":"8df2b88cd86019de4e6312f9178a1b8391881a6d0a6e7ec39632ce790e1216bb","size":34484},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/durable-state-model.md","sha256":"a14d10810847d77cbb58cf724b1861ed2f612255a1351033cfdb7c2a3e3155aa","size":37671},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-b1-pure-phase-values.md","sha256":"cec48373ec6b85d9fb84b0b0f384a8f3a528808d6d5205a33698c3442766b1c5","size":27228},{"file_type":"regular","kind":"untracked","mode":"0644","path":".docs/rw0-b2-capability.md","sha256":"1629c2015ed1cc651ed82d1302b5e41c5ac5b217ab86a307016df1b7535592be","size":13378},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-b2-wire-protocol.md","sha256":"7505e578393d448e677b8d05a74257ff33362e99df2e12539edc89099434082e","size":16566},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-remote-worker-contact-phase-entry.md","sha256":"d3189084312bbf710c526cb2bccfae008c2a356ae23375c94754db7238e4f993","size":50209},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/worker-execution-boundary.md","sha256":"d1882845e1f8e6d5b8f9b33620545fabb42f6213882b733b0643f87222f9e5b9","size":28735},{"file_type":"regular","kind":"untracked","mode":"0644","path":"src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py","sha256":"0e15e545620f90470ed5d8d852fcec1c8c12fa705b22cc93406b2250a16ac0d0","size":34844},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_architecture_contracts.py","sha256":"cfa79cb15e70d98cd811575c0077be1320e0fe37a9662d95482294e7f0eac740","size":99705},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_c2a_nonimplementation.py","sha256":"651a50b07cddf226425723f73d0496d477ea7e45bdae5b620bb066b61863c402","size":27068},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_runtime_non_authority.py","sha256":"9636dd003e358d178e6d6316b16dbff7ece944ae64f7bf0a3f3080b6be297755","size":41310},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b1_boundaries.py","sha256":"f921fc6e8010d2fec5ed2e254935288e49ed758d639e80dcb6b836abfd19df1e","size":8086},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_boundaries.py","sha256":"b49dab823265ed8bb4b1b5b3ee707767d67afd205d52a6827ecf5510c43a2cd4","size":13644},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_relations.py","sha256":"96e88e658d1ea6b5260d6ab81828fdcf35f275fd8399da56e299a557d0eaaf49","size":24843},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_values.py","sha256":"3baeafb6db862b65939a3395015d37f86983cbc99959855f523bb921baad763a","size":23091},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_vectors.py","sha256":"4aa4432b3e042e72f4a0d131a696a842f1a2ac1e3473f8bc04ad8fb90219f7f3","size":16104},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b2_wire_boundaries.py","sha256":"d336e59d4ff736df5986105a4af58a46c07b3399b38af50967b55823157ba54b","size":28611},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_remote_contact_phase_entry_contract.py","sha256":"b025563a6619c3ffa591035e577968dee3a9a75c480d9d28e024e22f5e662c07","size":108079},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_software_development_progression_boundary.py","sha256":"ffe8ae9af76eef5f091691ba6e8930b6c59b4d11ed5b59733407cb1f3965cb13","size":42680}],"head":"deec37bf08fb903d8846aa2c3232aec52fa9866e","recipe_id":"governed-execution.audit-patch-manifest.v1","textual_diff_sha256":"e81ef0ba3e3238a7e6ec428c519f3259bebb6da79cbef318a7045edb45656f5f","upstream":"origin/trunk_dev"}
```

Exact recipe source, base64:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

Run the exact recipe twice before investigation and twice at closeout, redirecting
only its historical output sink into a new external evidence root. Require the
current candidate to match the canonical target byte-for-byte. Stop with
`RECONCILIATION_PROVENANCE_MISMATCH` before design work on any mismatch.

IMPLEMENTATION AND AUDIT EVIDENCE

Implementation evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-g9JtFA
```

Independent audit evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-independent-audit.KVUYoh
```

Audit evidence index:

```text
/private/tmp/ge-coordinator-rw0-b2-independent-audit.KVUYoh/evidence_index.jsonl

entries:
84

size:
15021 bytes

SHA-256:
c226d77d4e342e4ab835700ec25630a87ce4c6a4a369ef6f95ecc0e62f0c1a4f
```

Do not modify either root. Inspect only the exact evidence needed to verify the
reported counterexamples, source locations, candidate bytes, and validation
history. Preserve the audit-side historical-sink atime observation as
non-candidate evidence; it is not a repair requirement.

INDEPENDENT AUDIT VERDICT

The exact candidate received:

```text
BLOCK
```

The audit found no fundamental authority-architecture rejection. It found two
high-severity protected-owner defects, five Capability-local defects, and two
documentation defects.

### High protected-owner findings

#### RW0-B2-AUD-001 — B1 false-positive qualification

Current B1 `_value(...)`:

- requires only the exact class;
- projects through the value's public `to_mapping()`;
- checks only the computed digest;
- returns the original object.

A correctly resealed `RW0RemoteHostReadinessObservationV1` with a
constructor-invalid `status` reached `validate_host_qualification(...)` and
fell through to `qualified/qualified`.

Required disposition:

- B1 must safely reconstruct supplied B1 values through the owning constructor
  grammar before semantic use;
- every relation must use reconstructed locals, never the original object;
- invalid but correctly resealed B1 values must fail before result precedence;
- Capability cannot claim complete B1 revalidation until this owner guarantee
  is true.

#### RW0-B2-AUD-002 — pre-meter B1/C2A graph amplification

Current B1 projection recursively invokes:

- B1 `_external(...)`;
- `CanonicalC2B3DLineage.to_mapping()`;
- C2A `CeilingsV1.to_mapping()`;
- other C2A `to_mapping()` paths.

This work can occur before the B1 241-unit meter. A forged exact-type graph
recursed while the captured B1 budget remained at its full value. C2A's
`_external_value(...)` has the same projection-before-owner-reconstruction
shape.

Required disposition:

- raw stored structure must be bounded before recursive projection;
- nested B1, C2A, and lineage objects must be safely reconstructed through
  their owning grammar;
- no attacker-controlled projection, canonicalization, digesting, exception
  translation, or alias expansion may occur outside all enforced budgets;
- the existing B1 `241` and Capability composed `490` claims must be rederived,
  not preserved by inertia.

### Capability-local findings

#### RW0-B2-AUD-003 — Wire owner exception leak

A hostile key in an exact built-in owner dictionary escaped as a foreign
`LookupError` rather than the fixed import-time invariant.

Required disposition:

- validate exact key types before equality or lookup;
- perform all owner-shape/key validation inside a reason-only sanitized
  boundary;
- raise only:
  `RuntimeError("RW0WorkerMechanismCapabilityWireOwnerInvariant")`
  from `None`, outside any foreign handler.

#### RW0-B2-AUD-004 — retained Wire callable

The imported `wire_profile_mapping` callable remains reachable in Capability
module globals and can regenerate the complete Wire profile.

Required disposition:

- call the owner exactly once during module initialization;
- retain only the fixed ref and digest strings;
- remove the callable binding afterward;
- allow controlled loader tests by passing a callable into a private loader or
  isolated module import, not by retaining the production owner callable.

#### RW0-B2-AUD-006 — error immutability overclaim

`BaseException` supplies an inherited mutable `__dict__`, so direct mutation of
that dictionary succeeds despite slots and `__setattr__`.

Engineering decision for this reconciliation:

- do not promise impossible absolute resistance to deliberate CPython
  reflection;
- freeze public semantic immutability instead;
- ordinary attribute assignment/deletion remains disabled;
- ordinary `__dict__` access should be hidden or rejected if mechanically
  possible without payload retention;
- `.reason`, `args`, `str`, `repr`, cause/context, traceback-local hygiene, and
  serialization remain content-free and immutable;
- arbitrary state introduced only through deliberate low-level reflection is
  non-semantic, ignored by every method, and grants no authority;
- update owner prose and tests to state this exact boundary.

#### RW0-B2-AUD-007 — session privacy classification

Unknown keys such as `session` and `session_handle` currently return
`unknown_field`.

Required disposition:

- add generic `session` to the private-fragment classifier;
- accepted exact field `external_session_non_authority` continues to bypass the
  fragment check because exact-field recognition remains first;
- all session-bearing unknown keys fail with
  `privacy_forbidden_material`.

### Documentation findings

#### RW0-B2-AUD-005

The live RW0 tranche map still describes all B values/boundaries as future.

Required disposition:

- classify B1, Wire, and Capability private semantics as current implemented
  contracts;
- retain RW0-C/D/E durable, process, transport, live-proof, and runtime
  mechanics as future.

#### RW0-B2-AUD-008

The open-decision table still lists exact framing and terminal-result grammar
as wholly open.

Required disposition:

- state that NWPF representational framing, worker-result grammar, and
  process/result classification are fixed by RW0-B2-Wire;
- keep physical stream/process plumbing, route wrapper mechanics, and terminal
  runtime reconciliation open.

ACCEPTED ARCHITECTURE — DO NOT REOPEN

Retain:

1. `RW0-B2-Wire -> RW0-B2-Capability`.
2. The three exact Capability value classes, schemas, fields, dimensions,
   identity domains, and twelve-reason qualification precedence.
3. The fixed Wire pair:
   - `rw0-wire-nwpf-v1`
   - `470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454`
4. Declaration, supplied independent observation, and Coordinator qualification
   remain distinct.
5. Source-ref inequality proves structural non-collapse only.
6. No Capability value authenticates a source, grants permission or
   acceptance, persists truth, contacts a worker/provider/host, or selects a
   concrete provider/mechanism.
7. Concrete CLI/App Server, credential, session, process, transport, and live
   proof remain RW0-D/E.
8. RW0-C retains durable evidence, recovery, terminal facts, and latch.
9. ES retains route admission and runtime authority.
10. No package-root export, public caller, dependency, migration, schema, or
    durable-state widening.
11. Valid existing B1, Wire, C2A, and Capability identities and canonical bytes
    must remain unchanged.

ENGINEERING DECISION ON REPAIR INTEGRATION

The default target is one integrated repair on the existing uncommitted
Capability branch, ordered as:

```text
owner hardening first
  -> Capability-local repair
  -> documentation/status repair
  -> full validation and new provenance
  -> fresh independent re-audit
```

Reason:

- the live Capability candidate already depends on the owner fix;
- moving the uncommitted candidate across branches would introduce avoidable
  patch-transfer and provenance risk;
- the final re-audit must judge the exact integrated bytes.

Do not implement this default yet. Confirm it is safe only after exact
owner algorithms, budgets, imports, tests, and touched-file ceiling are frozen.

Return `SEPARATE_OWNER_TRANCHE_REQUIRED` instead if owner hardening would require:

- a schema ID, field, digest domain, canonical byte, or public API change;
- a migration or durable-state change;
- a broad C2A rewrite not mechanically bounded to the affected exact-value
  owner seam;
- an uncloseable touched-file surface;
- a commit/rebase/reset of the live uncommitted candidate.

REQUIRED READ-ONLY EXPLORERS

Use exactly four bounded, non-nesting read-only explorers when available.

### 1. B1 safe-reconstruction and relation-budget explorer

Inspect:

```text
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
.docs/rw0-b1-pure-phase-values.md
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_boundaries.py
```

Tasks:

- inventory every `_value(...)` call and every relation that currently ignores
  its return;
- define one non-recursive raw-state extractor for all eight B1 classes;
- determine exact handling of nested L34, K8, Ceilings, nullable pairs, tuples,
  integers, and digests;
- ensure every public B1 method, readable attribute, equality, and relation
  either safely reconstructs or has an explicitly narrower owner contract;
- require all relation semantic logic to use reconstructed locals only;
- reproduce the invalid-readiness false positive in an external read-only
  probe;
- derive exact construction, public-boundary, equality, and every relation
  budget after hardening;
- determine whether the host relation can retain 241 or must receive a new
  exact value;
- identify every B1 doc/test/status path that must change;
- preserve all valid canonical vectors and schemas.

### 2. C2A and lineage owner-seam explorer

Inspect:

```text
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
.docs/c2a-first-slice-semantic-protocol-contract.md
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_vectors.py
tests/test_worker_execution_semantic_relations.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_c2a_relations.py
tests/test_remote_worker_pre_execution_planning_contract.py
```

Also inspect exact source-inventory tests when imports require them.

Tasks:

- map the exact nested owner classes consumed by B1:
  `CeilingsV1`, `AttemptFenceV1`, `EffectFenceV1`, `WorkerCommandV1`,
  `DeliveryEnvelopeV1`, `WorkSpecV1`, `CandidateCapsuleManifestV1`,
  nested `CapsuleEntryV1`, and `CanonicalC2B3DLineage`;
- prove which classes can reach B1 host qualification and which belong only to
  other B1 relations;
- define the smallest owner-controlled bounded reconstruction seam;
- prefer one private C2A owner helper over duplicated slot inventories in B1,
  unless source evidence proves that would create a larger or unsafe surface;
- define the lineage owner's equivalent safe extraction/reconstruction seam;
- meter raw exact-class state before public `to_mapping`, recursive
  `_external_value`, canonicalization, or digesting;
- preserve valid C2A and lineage bytes/digests exactly;
- determine whether affected C2A relations themselves must reconstruct inputs,
  or whether an owner helper consumed by B1 is sufficient to close both audit
  findings;
- identify import-direction and exact-consumer inventory changes;
- derive exact hostile-graph budgets, cycle behavior, and shared-alias charging;
- state whether Wire remains byte-identical and independent.

### 3. Capability-local and documentation repair explorer

Inspect all 20 candidate paths plus the precise audit counterexamples.

Tasks:

- freeze hostile-key-safe Wire-owner loading;
- freeze callable deletion and retained-global tests;
- freeze the public-semantic exception immutability boundary selected above;
- freeze generic session privacy classification;
- freeze exact tranche-map and open-decision wording;
- identify exact tests and causal mutants;
- confirm no Capability schema/field/digest/vector change;
- determine whether the existing 20-path candidate set remains otherwise
  sufficient;
- state every path that stays byte-identical.

### 4. Integration, touched-surface, validation, and provenance explorer

Inspect:

- production/static import inventories;
- package/public boundaries;
- exact node ownership;
- all candidate and prospective owner tests;
- implementation and audit evidence;
- current provenance target.

Tasks:

- return one exact maximum integrated repair allowlist;
- classify each path as existing candidate, newly authorized owner source,
  owner documentation, direct owner tests, inventory/status test, or protected;
- identify whether any of these specifically become necessary:
  ```text
  tests/test_c2b2_development_row_value_boundaries.py
  tests/test_codex_agent_config.py
  ```
- define test-first causal gates for the two high findings and each local
  finding;
- define focused groups, node-delta policy, full-suite policy, guards, and
  exact provenance closeout;
- define fresh audit perspectives;
- determine whether the integrated repair is safer than a separate owner
  tranche while the candidate is uncommitted.

No explorer may mutate, run tests, contact a remote, or create nested agents.

OWNER-HARDENING DESIGN REQUIREMENTS

READY requires exact resolution of all items below.

## A. One authoritative reconstruction owner

Do not let Capability or B1 silently become the semantic owner of C2A values.

Freeze:

- exact private helper names;
- exact module ownership;
- exact allowed import direction;
- exact expected classes each helper accepts;
- exact raw slot/tuple inventories;
- exact mapping reconstruction;
- exact exception translation;
- exact budget propagation;
- exact tests proving a class-wide bypass fails.

A B1-local wrapper may orchestrate owner helpers, but must not duplicate or
weaken C2A/lineage field grammar.

## B. B1 value reconstruction

For every B1 value:

1. require exact class;
2. read private state without invoking caller-controlled public mapping;
3. bound raw structure before recursive descent;
4. reconstruct nested owner values through owner helpers;
5. rebuild through the B1 owning grammar without public-method recursion;
6. recompute self-digest;
7. return a fresh exact B1 value;
8. use only that fresh value for attributes and relation semantics.

Freeze whether all public methods/attributes/equality are hardened now. The
default is yes because B1 is the current owner and its current prose calls these
immutable exact values. A narrower decision requires an explicit owner-contract
revision and a proof that no public or relation path can expose tampered state.

## C. B1 relations

Inventory every relation.

For each:

- assign reconstructed inputs to local variables;
- prohibit later reads from originals;
- safely reconstruct every C2A/lineage object before use;
- translate owner errors content-free;
- retain existing positive/negative semantics;
- recompute its exact budget from the actual algorithm;
- add maximum-valid, one-under, cycle, shared-alias, and correctly resealed
  invalid-state tests.

The host relation must reject the audit's invalid readiness value before
qualification precedence.

## D. C2A/lineage hostile graph work

No helper may call:

- `to_mapping`;
- recursive `_external_value`;
- canonical identity methods;
- digest methods;

on unmetered caller-controlled exact-class state.

Freeze an exact preflight/reconstruction algorithm and tariffs. A valid fresh
owner value may use ordinary canonicalization after raw state has been
reconstructed and bounded.

## E. Budget correction

The current claims:

```text
B1 host:
241

Capability local:
249

composed:
490
```

are not accepted merely because valid fixtures fit them.

Return exact new arithmetic for:

- each affected C2A/lineage reconstruction;
- each B1 value public reconstruction;
- every B1 relation;
- Capability local relation;
- complete Capability -> B1 -> nested owner composition.

State whether counters are propagated or separately enforced. No
attacker-controlled work may occur outside all counters. Add literal
maximum-valid and one-under controls.

CAPABILITY-LOCAL REPAIR REQUIREMENTS

## Wire owner loader

Freeze pseudocode that:

1. obtains a temporary exact built-in dictionary from one owner call;
2. iterates keys without equality/lookups until every key is exact built-in
   `str`;
3. checks exact ordered key inventory only after type safety;
4. checks schema/ref/manifest type/digest;
5. extracts only ref/digest;
6. clears temporary references;
7. returns from any foreign handler;
8. raises only the fixed invariant outside the handler;
9. deletes the imported owner callable binding after module initialization.

## Error boundary

Freeze exact prose and mechanics:

- semantic state is reason-only and immutable through the supported public
  surface;
- ordinary assignment/deletion and ordinary `__dict__` access are rejected or
  hidden;
- low-level deliberate CPython reflection is outside the semantic contract,
  creates no authority, and must not influence methods, serialization,
  equality, `args`, `str`, `repr`, cause/context, or traceback hygiene;
- no supplied payload is automatically retained.

Do not retain an impossible absolute reflection-proof claim.

## Privacy

Add generic `session` as a private unknown-key fragment while preserving
accepted-field-first behavior.

## Documentation

Correct the tranche map and open-decision table without widening current
runtime claims.

TEST AND AUDIT REQUIREMENTS

The reconciliation must freeze future causal tests for at least:

1. invalid but correctly resealed B1 readiness status;
2. incomplete/tampered B1 value through every owner boundary;
3. deep and shared-DAG nested B1/C2A/lineage values before any unmetered
   projection;
4. class-wide B1 safe-reconstruction bypass;
5. each affected C2A owner helper bypass;
6. every recalculated budget at maximum and one-under;
7. B1 relation use of reconstructed locals only;
8. hostile Wire key with fixed invariant and null cause/context;
9. retained-global proof showing no Wire callable or manifest;
10. ordinary error `__dict__` visibility/mutation under the narrowed contract;
11. low-level reflective state proving no semantic influence;
12. generic session unknown keys and accepted session field;
13. stale tranche-map and open-decision wording;
14. exact protected-byte and import-direction controls.

Freeze:

- opening and final node collection;
- exact existing-node preservation;
- permitted new-node owner files;
- focused B1, C2A, lineage, Capability, static/public, and status groups;
- one complete suite, with one governed rerun only for a patch-caused failure;
- exact recipe twice;
- fresh independent re-audit before staging.

TOUCHED-FILE CEILING

Do not authorize implementation in this engagement.

Return an exact maximum future repair allowlist. Start from the existing 20
candidate paths, then add only source-grounded owner paths.

Explicitly assess at least:

```text
.docs/c2a-first-slice-semantic-protocol-contract.md
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py

tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_vectors.py
tests/test_worker_execution_semantic_relations.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_c2a_relations.py
tests/test_remote_worker_pre_execution_planning_contract.py

tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_boundaries.py

tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py
```

Do not add a path merely because it is listed. State why each included path is
necessary and why each excluded path remains protected.

STOP CONDITIONS

Return PARTIAL or BLOCKED if:

- safe reconstruction would change a schema, field, digest domain, canonical
  bytes, or public API;
- B1 or C2A authority semantics must change rather than harden;
- a migration, SQL, durable-state, process, provider, or public-package change
  is required;
- exact budgets cannot be derived;
- owner hardening would require an unbounded C2A rewrite;
- the repair allowlist cannot be closed;
- the current candidate differs from the canonical target;
- the integrated repair cannot be performed without moving/resetting/rebasing
  the uncommitted candidate.

FINAL DISPOSITIONS

Return exactly one repair status:

```text
RW0_B2_CAPABILITY_REPAIR_RECONCILIATION_READY
RW0_B2_CAPABILITY_REPAIR_RECONCILIATION_PARTIAL
RW0_B2_CAPABILITY_REPAIR_RECONCILIATION_BLOCKED
```

Return exactly one owner status:

```text
B1_C2A_OWNER_HARDENING_SCOPE_FROZEN
B1_C2A_OWNER_HARDENING_SCOPE_PARTIAL
B1_C2A_OWNER_HARDENING_SCOPE_BLOCKED
```

Return exactly one integration status:

```text
INTEGRATED_REPAIR_ON_EXISTING_BRANCH_JUSTIFIED
SEPARATE_OWNER_TRANCHE_REQUIRED
INTEGRATION_DECISION_BLOCKED
```

READY/FROZEN/JUSTIFIED requires:

- exact owner helper algorithms;
- every affected relation and import;
- exact budget arithmetic;
- exact candidate-local repairs;
- exact documentation repair;
- exact maximum touched-file ceiling;
- exact test/validation/provenance/audit plan;
- no unresolved implementation choice.

If all three positive statuses are returned, state that the next permitted step
is one parent-only workspace-write integrated repair prompt in the existing
Capability implementation conversation. Do not issue that prompt here.

CLOSEOUT REPORT

Include:

1. opening and closing candidate identity;
2. recipe and canonical-target reproduction;
3. explorers, retries, and inspection boundary;
4. audit finding disposition;
5. B1 current defect and corrected owner algorithm;
6. C2A/lineage current defect and corrected owner algorithm;
7. every affected B1 relation and exact budget;
8. corrected Capability composition total;
9. Capability-local repair packet;
10. documentation correction;
11. exact touched-file ceiling and protected paths;
12. exact causal tests, validation order, provenance, and re-audit plan;
13. whether integrated repair is justified;
14. assumptions, uncertainty, and remaining C/D/E/ES seams;
15. final statuses.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
CAPABILITY_REPAIR_NOT_PERFORMED
B1_OWNER_NOT_MODIFIED
C2A_OWNER_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
```
