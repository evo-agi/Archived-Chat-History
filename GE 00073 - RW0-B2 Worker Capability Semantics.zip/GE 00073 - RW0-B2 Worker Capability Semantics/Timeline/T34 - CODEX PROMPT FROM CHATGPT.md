PROMPT_ID

RW0_B2_WIRE_SECOND_AUDIT_REPAIR_FRESH_REAUDIT_V1

TITLE

Coordinator RW0-B2-Wire — fresh independent read-only audit of the exact
second-audit repair candidate

ENGAGEMENT TYPE

Fresh Codex conversation. Read-only independent audit.

This is not implementation, repair, reconnaissance, commit, publication,
merge, deployment, Capability work, or runtime proof.

The parent and every audit subagent are read-only. Do not edit, create, delete,
format, chmod, clean repository bytes, stage, commit, push, create or modify a
PR, merge, tag, release, deploy, install dependencies, run migrations, contact
networks/remotes/services, invoke product workers/models/providers, or modify
any supporting repository.

External audit evidence and isolated pytest scratch may be created only beneath
one new operator-owned, non-symlink, mode-0700 directory under `/private/tmp`.
Do not delete or rewrite implementation, repair, or prior-audit evidence.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

VERDICT TOKENS

Return exactly one primary verdict:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

On `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_WIRE_SECOND_AUDIT_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not repair any finding.

EXPECTED LIVE TARGET

Require at opening and closeout:

- physical root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- subject:
  `feat: implement RW0-B1 pure phase-entry semantics (#3)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- dirty paths:
  `16`
- tracked modifications:
  `10`
- untracked additions:
  `6`
- staged/unmerged:
  `0/0`
- every candidate path:
  regular mode `0644`
- no Git operation, lock, repository cache, bytecode, database, journal,
  archive, build, generated manifest, or recorder residue
- `git diff --check`:
  clean.

Do not fetch or contact a remote.

IMMUTABLE SECOND-REPAIR TARGET

Repair evidence root:

```text
/private/tmp/rw0-b2-wire-second-repair.91xEYJ
```

Canonical target:

```text
/private/tmp/rw0-b2-wire-second-repair.91xEYJ/final_provenance.json
```

Expected identities:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe source bytes:
3_945

recipe source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6

canonical-manifest SHA-256:
8991126301a695c591e7f977bbf4580e378bdee39f740624106e5a0e0f324d11

complete-output SHA-256:
10ddb5dfda278c484b6846d0c677aebaed9265863fefe3254835c5619a16dda5

file count:
16
```

If `final_provenance.json` is a report envelope rather than the canonical
manifest itself, require it to identify and hash-bind exactly one canonical
manifest with the pinned SHA-256 above. Do not infer an unrecorded target.

PRECEDING FIRST-REPAIR TARGET

```text
/private/tmp/rw0-b2-wire-repair.q4veCL/final_provenance_001.manifest.json
```

Expected preceding identities:

```text
tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6

canonical-manifest SHA-256:
8c462b8fa4185e6795e6ce667da80f388a0109534da4263e6a47c3e4ab37b662

complete-output SHA-256:
9a1211f373b3995318b71ce3458f4f3895d56899ea8c110cf140d48d4a29a5be
```

Retained evidence roots that must remain unchanged:

```text
/private/tmp/rw0-b2-wire-v4.b4HlRt
/private/tmp/rw0-b2-wire-independent-audit.hX8xit
/private/tmp/rw0-b2-wire-repair.q4veCL
/private/tmp/rw0-b2-wire-re-audit.dU0ieG
/private/tmp/rw0-b2-wire-second-repair.91xEYJ
```

EXACT 16-PATH SET

Untracked additions:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

Tracked modifications:

```text
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

No seventeenth path is permitted.

EXPECTED PRECEDING-TO-SECOND-REPAIR DELTA

The path set, classifications, types, and modes remain identical.

Exactly these six untracked entries changed during the second repair:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

The other ten candidate entries must be byte-identical to the first-repair
target.

The tracked textual-diff digest therefore remains unchanged even though six
untracked files changed. Independently verify every per-file size and SHA-256;
do not treat the unchanged tracked-diff digest as repair proof.

EXACT RECIPE SOURCE

Decode this base64 only into the external audit root, verify exact size and
SHA-256, and retain it mode `0400`:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

The source historically writes:

```text
/tmp/ge-coordinator-b3a-audit-manifest-v1.json
```

Do not overwrite pre-existing evidence at that path. Execute the exact recipe
source unchanged while an external wrapper redirects only that exact
`Path.write_bytes` sink to a unique file under the audit root. Do not alter Git
reads, canonicalization, stdout, stderr, or recipe source.

PROVENANCE GATE — BEFORE CORRECTNESS INSPECTION

1. Lstat every component of:
   - second-repair evidence root;
   - target manifest or report-bound manifest;
   - preceding first-repair manifest;
   - every retained prior evidence root;
   - copied recipe source;
   - new audit root.
2. Require safe ownership, no symlink traversal, regular manifest/recipe files,
   and mode-0700 evidence roots.
3. Verify the target’s exact bytes and SHA-256.
4. Parse canonical JSON and require exact:
   - branch;
   - HEAD;
   - upstream;
   - recipe ID;
   - textual-diff digest;
   - 16-path set;
   - classification;
   - file type;
   - mode;
   - size;
   - per-file SHA-256.
5. Compare every live candidate file with the second-repair target.
6. Run the exact recipe twice at opening.
7. Require both complete outputs and manifests to be byte-identical and the
   generated manifest to equal the immutable target byte-for-byte.
8. Require repository identity and status to match the expected live target.
9. Verify no protected path outside the 16-path set differs from HEAD.
10. Verify exactly the six/ten preceding-to-repair delta above.

On any mismatch, stop before correctness inspection with:

```text
AUDIT_PROVENANCE_MISMATCH
```

CURRENT CONTRACT AND TARGET BOUNDARY

Committed HEAD owns current C2A and B1 contracts. The uncommitted candidate is
the accepted private B2-Wire target.

The candidate may implement only:

- private deterministic NWPF command/result codecs;
- pure relations over supplied exact C2A values and actual fences;
- safe unauthenticated cancellation-request and process source claims;
- a pure process/result classifier;
- one fixed local Wire protocol profile.

It must implement no:

- source authentication;
- permission, effect authority, acceptance, or durable truth;
- worker, process, contact, physical transport, host, filesystem, database,
  network, provider, model, Codex, CLI, App Server, credential, session,
  Bridge, ES, Git, or publication effect;
- RW0-C persistence, recovery, terminal fact, or latch;
- RW0-D/E request delivery, process targeting, process mechanics, or live proof;
- Capability declaration, observation, qualification, or implementation.

FROZEN IDENTITIES

Require exact preservation:

```text
profile_ref:
rw0-wire-nwpf-v1

profile identity bytes:
4_021

profile digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454

command payload/frame:
5_898 / 5_906

result payload/frame:
16_627 / 16_635

hostile units:
23_746 / 66_770

source mapping key maximum:
37

frame key maximum:
29
```

A need to change any profile, payload, source-owner, classification, reason, or
precedence identity is a blocking redesign finding.

FINDINGS TO RE-AUDIT

Treat all prior findings as hypotheses to close independently.

First audit:

```text
F1  foreign exception graph/payload leakage
F2  ordinary and incomplete immutable construction
F3  hostile key/raw-pair/shape/work accounting
F4  duplicate versus singleton conflict
F5  stale framing-status prose
F6  causal test inadequacy
F7  cancellation graph orientation
```

Second audit:

```text
F8  hostile shape traversal bulk-enqueues all siblings
F9  C2A to_mapping expands tampered DAG/cycles before Wire validation
F10 classifier reads raw identity slots before reconstructing every fact
F11 tests omit public methods and codify malformed-fact duplicate behavior
```

The fresh audit must also search for defects introduced by the second repair.

AUDIT EXECUTION SHAPE

Use at most four concurrent audit slots:

- create three bounded read-only audit subagents;
- the parent performs the fourth lane;
- no nested agents;
- no subagent runs pytest or mutates repository/evidence;
- every subagent receives the same canonical manifest identity and
  self-contained context capsule;
- preserve disagreements and minority findings.

LANE 1 — RAW-PAIR ACCOUNTING AND BOUNDED SHAPE TRAVERSAL

Inspect source, governing Wire document, and codec/value tests.

Independently probe:

1. valid maximum command and result frames;
2. 5,000 scalar siblings under the result byte cap;
3. duplicate raw pair before structural overflow;
4. duplicate raw pair before a later JSON syntax failure;
5. structural overflow plus injected work overflow;
6. depth/container/key/scalar maximum plus one;
7. declared payload cap plus one;
8. trailing and concatenated frames;
9. direct mapping key lengths 37 and 38;
10. all private-fragment key paths.

Require:

- raw pair counting occurs during parse and includes duplicates;
- parse hook records but does not raise duplicate failure;
- later syntax error remains `json_token_invalid`;
- after syntax success, `duplicate_key` precedes structural failure;
- structural failure precedes `work_limit_exceeded`;
- shape traversal uses iterator/descent frames;
- no pending collection grows with sibling cardinality;
- collection cardinality is checked before iterating/building children;
- only one child is processed at a time;
- no bulk `extend`, pending-child list, or second hostile-tree shape traversal;
- the 5,000-sibling probe keeps live pending frames at or below depth cap plus
  one;
- frozen caps and work constants remain exact.

Do not rely only on implementation diagnostics controlled by the same helper.
Use an independent instrumented or externally observed counterexample.

LANE 2 — SAFE C2A EXTRACTION AND OWNER RELATIONS

Inspect the literal safe-extraction implementation and all six consumed C2A
classes:

```text
CeilingsV1
AttemptFenceV1
EffectFenceV1
WorkerCommandV1
DeliveryEnvelopeV1
WorkerObservationV1
```

Independently verify:

- exact class only;
- literal field inventories equal each committed `_FIELDS`;
- every required slot exists before semantic use;
- each scalar/container uses exact built-in types;
- cardinality precedes member iteration;
- custom mappings/iterables/subclasses reject;
- only the allowed one-level `CeilingsV1` nesting exists;
- fresh bounded mappings are built manually;
- caller `to_mapping()` and C2A `_external_value()` are never invoked before
  safe extraction;
- owning C2A `from_mapping` and semantic relations remain authoritative after
  extraction;
- valid maximum/current objects reconstruct identically.

Reproduce:

- shared tuple DAGs at depths 8, 12, and 16;
- a self-referential/tampered ceilings object;
- custom iterable/mapping members;
- missing and wrong-typed slots for each class.

Instrument input `to_mapping`, `_external_value`, and arbitrary iteration.
Hostile cases must reject with zero such calls and no `RecursionError`.

Construct at least one mutation per owning C2A relation that passes local
equality checks but fails only through the actual owner relation.

LANE 3 — RECONSTRUCT-FIRST CLASSIFIER AND PUBLIC VALUE BOUNDARIES

Inspect values, relations, classifier, and boundary tests.

Independently probe malformed or tampered:

- worker-result observation;
- adapter observation;
- cancellation request;
- process observation;
- supplied attempt/effect fences;
- author/cancellation deliveries.

For each applicable fact, test:

```text
alone
same malformed object repeated
malformed object paired with colliding valid object
complete object with tampered colliding digest/ref
```

Require all malformed or relation-invalid inputs to return:

```text
invalid / invalid_input
```

before duplicate/conflict/lineage/cancellation semantics.

After every fact is reconstructed safely, require:

- same original valid object -> `duplicate_fact`;
- same safe ref -> `duplicate_fact`;
- same safe digest -> `duplicate_fact`;
- distinct valid singleton occupants -> `conflicting_fact`;
- same-code and different-code exits -> `conflicting_fact`.

Verify cancellation graph orientation and all frozen higher-tier precedence
remain unchanged.

Mechanically exercise incomplete and tampered self-digest values through:

```text
to_mapping()
identity_mapping()
canonical_identity_bytes()
computed_digest()
wire encoders
result relation
request relation
process relation
classifier
```

Require sealed finite errors, null cause/context, no hostile traceback-local
payload, and no raw slot/recursion exception.

LANE 4 — TEST CAUSALITY, PROFILE/CAPS, PUBLIC BOUNDARY, AND EVIDENCE

The parent performs this lane.

Inspect:

- four Wire test files;
- Wire source and owner document;
- other ten candidate paths for byte identity;
- second-repair and prior evidence;
- imports/AST/package/public surfaces;
- profile mapping and exact maximum fixtures.

Determine whether:

- all nine added tests are unique, literal, and causal;
- test-owned C2A inventories are not derived from the Wire extractor constants;
- the 5,000-sibling test would fail if a bulk pending stack returned;
- DAG/cycle tests prove zero owner-generic expansion calls;
- classifier tests distinguish malformed-first from valid duplicate/conflict;
- public method matrix covers every required class/method/boundary;
- exact maximum fixtures still genuinely produce the frozen byte totals;
- all F1–F7 tests remain active and causal;
- no test was weakened, removed, renamed, skipped, xfailed, collapsed, or
  reparameterized;
- no package/public/production/dependency/schema/migration widening exists;
- all ten non-repair candidate paths remain exact;
- repair evidence binds the final target and preserves prior evidence;
- no sensitive or repository-local artifacts remain.

IMPLEMENTATION EVIDENCE REVIEW

Safely inventory the second-repair root. Verify credited records by exact file
identity, argv, environment, umask, return code, stdout/stderr, JUnit,
structured counts, and before/after fingerprints.

Expected repair-reported final results:

```text
opening nodes:                    4_644
final nodes:                      4_653
new repair nodes:                 9
new-node ownership:               four Wire test files only

selected causal:                  10 passed
Wire values:                      11 passed
Wire codec:                       16 passed
Wire relations:                   47 passed
Wire boundaries:                  13 passed
combined Wire:                    87 passed
C2A/C2A1:                         637 passed
B1:                               281 passed
static/public:                    105 passed
status/docs:                      858 passed
complete suite attempt 001:       4_653 passed
```

Preserve and classify:

- red gate: 10 cases, 6 intended failures, 4 passes;
- development probe: 9 passed, 1 failed;
- focused repair probe: 1 passed;
- any recorder or orchestration limitation.

Do not treat command-recorder errors as candidate test failures. Do not credit
ambiguous or unbound evidence.

PARENT RECONCILIATION

Wait for all three subagents. Preserve disagreements. Directly inspect and
reproduce every material finding.

Classify each finding by:

- severity: Critical / High / Medium / Low / Observation;
- type: authority/contract, correctness, security/privacy/availability,
  test adequacy, documentation/status, public boundary, provenance/evidence;
- patch defect versus pre-existing issue;
- current-contract violation versus strategic-target defect;
- exact path:line evidence;
- impact;
- required correction;
- uncertainty.

Green tests never overrule deterministic counterexamples.

INDEPENDENT VALIDATION

Only after provenance and source/probe inspection are sufficiently green, run
serial independent validation under the new audit root.

For every child use:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
```

Capture and restore the actual caller umask; require child-observed numerical
umask equality.

Run:

1. four Wire files together:
   ```text
   tests/test_rw0_b2_wire_values.py
   tests/test_rw0_b2_wire_codec.py
   tests/test_rw0_b2_wire_relations.py
   tests/test_rw0_b2_wire_boundaries.py
   ```

2. corrected C2A/C2A1:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_c2a_first_slice_semantic_protocol_contract.py
   tests/test_c2a_effects_and_recovery.py
   ```

3. B1:
   ```text
   tests/test_rw0_b1_*.py
   ```

4. static/public:
   ```text
   tests/test_c2a_nonimplementation.py
   tests/test_runtime_non_authority.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_b2a_writer_session_contract.py
   tests/test_codex_agent_config.py
   ```

5. status/docs:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

Every executed gate must return 0 with empty stderr, zero
failures/errors/skips/xfails/warnings, parseable JUnit, no duplicate or unmapped
case, and unchanged repository target.

NODE IDENTITY

Collect the candidate exactly once and one clean external `git archive HEAD`
exactly once.

Require:

```text
candidate:                       4_653
HEAD:                            4_566
intersection:                    4_566
candidate-only:                  87
HEAD-only:                       0
```

Require all 87 candidate-only nodes to belong exactly to:

```text
tests/test_rw0_b2_wire_values.py       11
tests/test_rw0_b2_wire_codec.py        16
tests/test_rw0_b2_wire_relations.py    47
tests/test_rw0_b2_wire_boundaries.py   13
```

Require HEAD order preservation.

If source/probe inspection finds a blocker, the full suite may be withheld with
an exact explanation.

If inspection is green, run the complete repository suite exactly once and
require:

```text
4_653 collected
4_653 passed
0 failures/errors/skips/xfails/warnings
empty stderr
no duplicate or unmapped JUnit cases
unchanged target bytes
```

CLOSING GUARDS

Before verdict:

1. remove only audit-created transient caches, basetemps, archives, databases,
   journals, and recorder scratch;
2. rerun the exact recipe twice;
3. require both closing manifests and complete outputs to equal opening and the
   immutable second-repair target byte-for-byte;
4. require exact 16-path topology, modes, classifications, sizes, and hashes;
5. require protected complement equality to HEAD;
6. require clean `git diff --check`;
7. require no repository residue, operation, or lock;
8. confirm no repository mutation occurred;
9. confirm every retained prior evidence root is unchanged.

ACCEPTANCE STANDARD

`ACCEPT` requires:

- exact provenance;
- no Critical, High, Medium, or Low patch defect;
- all F1–F11 findings mechanically closed;
- no new current-contract or accepted-target contradiction;
- complete authority/privacy/source separation;
- bounded parser traversal;
- safe C2A extraction before generic owner reconstruction;
- reconstruct-first classifier semantics;
- causally adequate tests;
- validated public/nonimplementation boundaries;
- required independent validation green;
- closing target byte-identical to opening.

An evidence limitation may be an Observation only when independent source,
probe, and validation work fully supersede it.

FINAL REPORT

Include:

1. exact opening/closing identity and provenance;
2. exact preceding-to-second-repair delta;
3. audit-lane reports and preserved disagreements;
4. severity-ranked finding ledger;
5. per-F1–F11 disposition;
6. raw-pair/shape/work assessment;
7. safe C2A extraction assessment;
8. reconstruct-first classifier and public-method assessment;
9. authority/privacy/profile/public-boundary assessment;
10. test-causality and evidence assessment;
11. independent commands/results/node comparison;
12. closing guards, limitations, and separate confidence for:
    - provenance;
    - validation;
    - implementation.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
```
