Please disregard this prompt and its attached text. MacOS app glitched.
