PROMPT_ID

RW0_B2_CAPABILITY_OWNER_ORACLE_FINAL_REAUDIT_FINDINGS_REPAIR_V1

TITLE

Coordinator RW0-B2-Capability — repair live B1 parser anchoring and regenerate
closed-schema causal/rename evidence after final independent re-audit

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing Capability implementation
conversation.

Do not create subagents. The parent is the sole repository writer.

This is a one-test-file plus external-evidence repair. It is not
reconnaissance, registry redesign, production implementation, documentation
editing, staging, commit, push, PR, merge, release, deployment, runtime proof,
provider integration, or supporting-repository work.

Only the exact repository path named below may change. Evidence artifacts must
be written only beneath one new external mode-0700 repair root.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Repair exactly three blocking findings from the final fresh independent audit:

```text
B1-MUTANT-005
  The RW0 owner test retains detached B1 parser aliases. A stale parser bound
  to both aliases and a post-import owner-parser replacement leave the owner
  tests and parser guard green.

EVID-CAUSAL-006
  The retained 27-row RW0 fence causal ledger omits explicit `family` and
  `diagnostic` fields.

EVID-RENAME-CHECKER-007
  The retained rename checker accepts `new_node_id` on non-rename rows and does
  not enforce global endpoint uniqueness.
```

Preserve all behavior accepted by the audit:

- the four original findings are behaviorally closed;
- the canonical B1 parser is correct;
- bounded visible-H2 behavior is correct;
- RW0 fence behavior is correct;
- the corrected migration ledger contains the exact old/new rename;
- registry source, ownership, production, public, privacy, and authority
  boundaries are correct;
- the no-mutation validation reset is complete and correct.

Do not address the non-blocking tilde-positive observation unless an already
required causal corpus row naturally proves it without adding scope.

OPENING REPOSITORY IDENTITY

Before any edit require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644
```

Require:

- `git diff --check` clean;
- cached diff check clean;
- no Git operation or lock;
- no candidate symlink or special file;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, or recorder residue.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

OPENING FINAL CANDIDATE TARGET

Repair evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-findings-repair.ZRLt3w
```

Required repair evidence index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-findings-repair.ZRLt3w/evidence_index.jsonl

rows:
375

size:
66414 bytes

SHA-256:
6de9b6295a2701a55bf496f2fe644f1c8be91b4314a67d84f3598c3a791e95b7
```

Validation-reset root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-validation-reset.ji1cdR
```

Required validation-reset index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-validation-reset.ji1cdR/evidence_index.jsonl

rows:
136

size:
28009 bytes

SHA-256:
727d7feb2d24f6ea61222530b3d312483d7685f2da4f00dc462dce22e6eb6bb4
```

Required candidate identities:

```text
canonical-manifest size:
6430 bytes

canonical-manifest SHA-256:
51b6adfdd88d538e26b7166681465fbb27abf467ec1e5936b646437e58d9f58b

complete recipe-output size:
6663 bytes

complete recipe-output SHA-256:
9e9a3582ae6109184593a1c68aff584ffe3f172f1db471b70ad2a20dee7d7bce

tracked final node count:
5051

ordered node-list SHA-256:
5e2a6c5f9e603895b9f9daf021ccc36a9915a8b923ddb7fe8c287b49325bb1aa
```

Required opening repaired path identity:

```text
tests/test_rw0_remote_contact_phase_entry_contract.py

size:
160517 bytes

SHA-256:
2e37bb85fddad2c2212fbe598ff0e2cd553278f1234911ce5b6d34f1c8a90efd
```

Required protected B1 owner-test identity:

```text
tests/test_rw0_b1_boundaries.py

size:
34249 bytes

SHA-256:
4d7fb14a71cb1c27f754566c4ac80dcc066b1f491f648fec3cbdb149b1ab6cd5
```

LATEST INDEPENDENT AUDIT

Audit root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit.6NY6CJ
```

Report:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit.6NY6CJ/audit_report.md
```

Self-excluding index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit.6NY6CJ/evidence_index.jsonl

rows excluding itself:
75

size:
12568 bytes

SHA-256:
96badb399c58f0b172e8f1e4eb80d68304e3dc4bc58485ca7d8ba729e776e7c7
```

Read and preserve all finding evidence for:

```text
B1-MUTANT-005
EVID-CAUSAL-006
EVID-RENAME-CHECKER-007
```

The audit accepted the current live behavior. Do not change registry parsers,
documents, production source, migration classifications, or authority facts
except for the exact test-side parser anchoring described below.

BEFORE MUTATION

Create one new operator-owned, non-symlink, mode-0700 external repair evidence
root beneath `/private/tmp`.

Then:

1. safely `lstat` and verify the repair, validation-reset, and audit evidence
   indexes;

2. record exact opening tree fingerprints for all three roots;

3. locate and verify the exact retained recipe source through the repair index:

   ```text
   regular file
   mode 0400
   size 3945
   SHA-256
   db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
   ```

4. reproduce the current canonical manifest twice with safe redirection of only
   the external historical output sink;

5. require exact equality to the retained final target;

6. verify every candidate path and every path outside the candidate;

7. collect the exact 5,051 opening nodes once and require the expected ordered
   hash;

8. load and verify:
   - the 27-row retained fence causal ledger;
   - the corrected 384-record migration ledger;
   - the retained rename checker;
   - opening and final node lists;
   - retained validation-reset attempt envelopes;

9. retain a complete opening candidate/evidence fingerprint.

Stop before mutation on any mismatch.

ACCEPTED CONTRACT — DO NOT REOPEN

Preserve exactly:

- both owner registries and all document bytes;
- registry version 1;
- every registry row, field, value, role, source, order, marker, heading, and
  location;
- prose authority policy A;
- B1 authority rows and one-way RW0 projections;
- RW0 composition/status authority;
- canonical B1 parser behavior;
- bounded visible-H2 behavior;
- RW0 fence parser behavior;
- corrected migration ledger contents and classifications;
- all C2A, lineage, B1, Wire, and Capability production semantics;
- all public/import/privacy/authority boundaries;
- no source authentication, executable permission, semantic acceptance,
  persistence, provider/runtime/Git/publication authority;
- C/D/E and ES later/external owner seams.

TEST-FIRST CAUSAL GATE

Before repairing the RW0 test import/anchoring and before generating new
external evidence, modify only the authorized repository test to add controls
for B1-MUTANT-005.

Run one selected red/control gate that proves:

1. replacing the B1 owner module's live parser after RW0 test import does not
   affect the current detached RW0 aliases;

2. binding one stale local parser to every RW0 B1-parser alias leaves the
   current owner tests green;

3. existing parser guard/equivalence checks also remain green under those
   mutants;

4. baseline canonical B1 and RW0 registry controls pass;

5. no syntax, import, collection, fixture, path, production, documentation, or
   unrelated failure receives causal credit.

External evidence findings do not require repository-red tests. Their opening
defects are proven by the retained audit records.

Retain exact argv, environment, umask, stdout/stderr, JUnit, node IDs,
before/after candidate fingerprints, and mutation setup.

REPAIR A — ANCHOR RW0 TO THE OWNER MODULE'S LIVE B1 PARSER

Only this repository path may change:

```text
tests/test_rw0_remote_contact_phase_entry_contract.py
```

`tests/test_rw0_b1_boundaries.py` remains the sole B1 registry parser owner and
must remain byte-identical.

Engineering requirements:

1. Import the B1 owner test module itself through the existing ordinary,
   deterministic test-module import mechanism.

2. Do not import the parser function by value into detached local aliases.

3. Every cross-document B1 parse must resolve the parser through the owner
   module object at call time, for example in substance:

   ```python
   _b1_owner_test_module._parse_b1_registry(...)
   ```

4. Remove stale parser aliases, copied wrappers that close over a function
   object, fallback parsers, dynamic imports, source execution, or duplicate
   grammar.

5. If a local wrapper is retained for call-shape convenience, it must:
   - retain only the owner module object;
   - perform live attribute lookup on every call;
   - contain no copied parser logic;
   - expose no replaceable local function alias used by the production test
     path.

6. The cross-document projection path may adapt the returned canonical
   projection but may not reparse B1 Markdown.

7. Import order must remain stable for:
   - RW0 owner test alone;
   - B1 owner test alone;
   - B1 then RW0;
   - RW0 then B1;
   - full suite.

8. No duplicate collection, circular import, package export, production import,
   or import-time repository effect is allowed.

REPAIR B — MUTATION-ADEQUATE LIVE-OWNER TESTS

In the authorized RW0 test file, add independent test-owned assertions that
kill these mutants:

### B1. Detached stale local parser

- Capture the original owner parser.
- Install a deliberately stale parser in a local place that the pre-repair code
  would use.
- Replace the owner module's live parser with a different deterministic
  sentinel parser.
- Require the cross-document path to follow the live owner module replacement,
  not the stale local function.

### B2. Post-import owner replacement

- Import RW0 owner test machinery first.
- Replace the B1 owner module's parser afterward.
- Require every cross-document B1 parse to observe the replacement.

### B3. Copied fallback parser

- Inject or expose a test-local fallback/copy candidate.
- Require static/behavioral guard failure if the cross path can use it.
- The checked test must prove the fallback is unreachable from the actual
  cross-document path.

### B4. Explicit expected outcomes per corpus row

For the complete retained B1 equivalence corpus:

- store an independent literal expected result for every row;
- result is either:
  - exact canonical projection; or
  - exact finite `b1.registry.*` diagnostic;
- compare both:
  - direct owner parser result;
  - RW0 cross-document path result;
  against the independent expected result;
- do not credit only equality between two aliases.

### B5. Static ownership guard

Inspect the RW0 test module AST/source and require:

- zero local B1 parser function definitions;
- zero `from ... import parser_function` binding by value;
- exactly one ordinary owner-module import;
- cross path resolves parser as owner-module attribute;
- no dynamic import, `exec`, `eval`, source loading, or fallback grammar;
- no additional B1 parser-like implementation.

Use finite diagnostics that identify mutant/corpus row but do not echo arbitrary
document contents.

EXTERNAL EVIDENCE REPAIR C — CLOSED-SCHEMA FENCE LEDGER

Do not modify repository files for this repair.

Generate a new immutable ledger beneath the new evidence root.

Source corpus:

- exact retained 27 rows from the prior repair ledger;
- exact live test case definitions;
- exact final candidate bytes.

Closed schema for every row:

```text
schema_id
case_id
document_sha256
family
expected_real_result
actual_real_result
sensitivity_mutant
expected_mutated_result
actual_mutated_result
diagnostic
source_node_id
```

Required finite `family` values:

```text
valid_closer
invalid_closer
non_opener
```

Required `diagnostic` representation:

- exact finite `rw0.registry.*` diagnostic for rejection; or
- exact literal `success` for canonical projection success.

Requirements:

1. exactly 27 rows;
2. exact key set and key order per row;
3. no missing or extra field;
4. unique `case_id`;
5. unique `document_sha256`;
6. unique `(family, sensitivity_mutant, source_node_id, document_sha256)`;
7. every `source_node_id` exists in the final node list;
8. document hash matches independently regenerated case bytes;
9. actual result matches retained/live behavior;
10. family agrees with case construction;
11. diagnostic agrees with actual result;
12. no inference is required to recover family or diagnostic.

Create a checker and mutant suite that rejects:

```text
missing family
missing diagnostic
unknown family
wrong family
wrong diagnostic
extra field
key reorder
duplicate case ID
duplicate document hash
wrong source node
wrong expected/actual real result
wrong expected/actual mutated result
```

Retain ledger, checker, mutants, results, and aggregate SHA-256, all mode 0400.

EXTERNAL EVIDENCE REPAIR D — CLOSED MIGRATION CHECKER

Do not modify the corrected 384-record ledger unless its bytes fail the accepted
hash.

Use the exact corrected ledger:

```text
record count:
384

SHA-256:
7dfce2479a0a7e72b37dc2af0181bf2dbf2e11ec209432a5b551ee4057f2a87e
```

Generate a new checker beneath the new evidence root.

Closed schemas by disposition:

### Rename record

Required keys:

```text
old_node_id
new_node_id
category
disposition
purpose
opening_present
final_present
```

Requirements:

```text
disposition == "rename to registry-purpose node"
old_node_id nonempty exact str
new_node_id nonempty exact str
old != new
opening_present true
final_present true
```

### Non-rename record

Required keys are the exact accepted non-rename schema from the retained ledger.

Requirements:

```text
new_node_id forbidden
no alternate rename-target field permitted
no extra field
```

Global endpoint rules across all records:

1. every `old_node_id` unique;
2. rename `new_node_id` values unique;
3. no rename `new_node_id` equals any other record's `old_node_id` unless the
   migration contract explicitly authorizes a chain; this contract authorizes
   no chains;
4. no non-rename record contains `new_node_id`;
5. no hidden/alternate field on a non-rename row shares a rename target;
6. exactly one rename record;
7. exact accepted mapping:

   ```text
   old:
   tests/test_rw0_b1_boundaries.py::test_owner_has_one_current_retrieval_maximum_and_one_current_consumer

   new:
   tests/test_rw0_b1_boundaries.py::test_b1_live_registry_projection
   ```

8. old once opening and absent final;
9. new absent opening and once final;
10. new once among additions;
11. every opening owner node has exactly one record;
12. arithmetic reconciles with opening/final node lists.

Mutant suite must reject at least:

```text
missing new_node_id on rename
wrong new_node_id
duplicate rename target
shared old endpoint
shared new endpoint
new_node_id on non-rename row
duplicate_target_nonrename
shared_new_endpoint_nonrename
unknown extra key on rename
unknown extra key on non-rename
rename count 0
rename count 2
opening owner node omitted
opening owner node duplicated
wrong opening_present
wrong final_present
target present opening
target absent final
target absent additions
```

Retain checker, exact mutant inputs, results, and aggregate identities mode 0400.

B1 HYGIENE

Do not modify the protected B1 owner test merely to address historical unused
constants. The latest audit did not treat this as a blocker in the final
candidate. No volume-only assertion is authorized.

EXACT REPOSITORY ALLOWLIST

Only this already-dirty repository path may change:

```text
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The other 29 candidate entries must remain byte-identical.

No document or production source may change.

Final topology remains exactly:

```text
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged
all regular mode 0644
```

Stop if a second repository path, documentation change, source change, or
thirty-first dirty path is required.

VALIDATION EVIDENCE

The previous validation-reset root remains historical evidence and must remain
unchanged:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-validation-reset.ji1cdR
```

Because one repository test changes, create a new complete final validation
sequence beneath this repair root. Do not rely on the previous reset as final
validation authority.

RECORDER REQUIREMENTS

Use an unconditional attempt recorder equivalent in completeness to the
validation-reset recorder.

Every attempt must retain:

```text
label
purpose
credit classification
exact argv
working directory
environment
unset variables
Python path/realpath/version/implementation/platform
caller/child umask
wall and monotonic timing
PID
return code/signal
stdout/stderr identities
JUnit applicability/identity/parse status
counts
duplicate/unmapped cases
node list identity when applicable
repository/index fingerprints before/after
candidate-mutated boolean
notes
```

Envelope must be sealed even for preflight stop or nonlaunch.

Run and retain one recorder self-test before candidate validation.

VALIDATION ENVIRONMENT

For every pytest child:

```text
umask 022 before launch
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

FINAL VALIDATION ORDER

After final repository and external evidence bytes are frozen:

1. selected causal:
   - live-owner parser anchoring;
   - post-import replacement;
   - stale local parser mutant;
   - fallback/copy guard;
   - bounded corpus expected-outcome checks;
   - fence ledger checker/mutants;
   - rename checker/mutants;

2. B1 owner:
   ```text
   tests/test_rw0_b1_boundaries.py
   ```

3. RW0 owner:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   ```

4. B1 compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```

5. Capability/Wire compatibility:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```

6. architecture/status/static:
   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

7. final collection exactly once;

8. migration reconciliation against:
   - original reset opening 5,114 list;
   - repair opening 5,002 list;
   - preceding final 5,051 list;
   - new final list;

9. final guards;

10. complete repository suite exactly once with ordinary quiet rendering;

11. cleanup;

12. two exact final provenance runs.

Do not predeclare final node count.

Every credited run requires:

```text
return code 0
zero failures/errors/skips/xfails/warnings
empty stderr
parseable JUnit
zero duplicate/unmapped cases
matching caller/child umask
unchanged candidate fingerprint
```

FULL-SUITE POLICY

Run complete-suite attempt 001 exactly once.

If it fails:

- preserve all evidence;
- repair only a deterministic test defect inside the sole authorized path;
- rerun affected focused groups;
- run attempt 002 exactly once.

Stop if:

- failure is outside scope;
- a second repository path is required;
- protected bytes must change;
- a third attempt would be required.

NODE AND MIGRATION CLOSEOUT

Report exact:

```text
opening 5051 count/hash
new final count/hash
retained intersection
additions
removals
renames
outside-owner order
owner ledger reconciliation
```

Update the external reconciliation summary for the new final list.

The original corrected 384-record architecture-reset ledger remains the source
of truth for the 5,114→post-reset migration unless the newly added test nodes
require an explicitly separate post-repair additions ledger.

Do not silently rewrite historical migration dispositions.

PROVENANCE CLOSEOUT

After validation and cleanup:

1. require exact topology `30/24/6/0/0`;

2. prove exactly the sole authorized repository path changed from the opening
   candidate target;

3. prove the other 29 candidate entries remain byte-identical;

4. prove every path outside the candidate equals HEAD;

5. run the exact recipe twice with safe output-sink redirection;

6. require byte-identical final manifests and complete outputs;

7. retain:
   - exact recipe source;
   - final manifests and outputs;
   - per-path identities;
   - opening/final node lists;
   - parser ownership/mutation records;
   - closed fence ledger/checker/mutants;
   - closed rename checker/mutants;
   - migration reconciliation;
   - all attempt envelopes;
   - full-suite evidence;
   - final guards and cleanup;

8. create a self-excluding evidence index last;

9. retain files mode 0400 and directories mode 0700;

10. remove only repair-created transient artifacts;

11. verify all four pre-existing evidence roots remain unchanged.

Do not stage, commit, push, create a PR, or perform an independent audit.

STOP CONDITIONS

Stop without further repository mutation if:

- opening identity or provenance differs;
- the sole-path ceiling is insufficient;
- live module anchoring cannot be achieved without B1 owner-test changes;
- ordinary deterministic owner-module import is unstable;
- a real parser behavior defect is discovered;
- a registry/document contradiction is discovered;
- closed ledger/checker evidence cannot be generated without rerunning
  historical implementation;
- any source, document, schema, identity, budget, or authority change is
  required;
- migration or validation becomes unstable.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only when:

- B1 live parser anchoring is mutation-adequate;
- the closed fence ledger is complete and checked;
- the migration checker rejects all required mutants;
- focused and complete validation are green;
- exact provenance is stable;
- every stop condition is false.

FINAL REPORT

Include:

1. opening/final identity;
2. latest audit evidence verification;
3. opening target reproduction;
4. selected red/control evidence;
5. exact one-path repository delta and 29-path equality;
6. live B1 parser anchoring design;
7. parser ownership/AST/mutation results;
8. independent expected-outcome corpus;
9. closed 27-row fence ledger and mutant results;
10. closed migration checker and mutant results;
11. corrected migration/rename reconciliation;
12. node comparison;
13. every validation attempt;
14. full-suite result and attempt number;
15. final manifest and aggregate identities;
16. evidence index and cleanup;
17. protected/public/authority non-widening;
18. remaining C/D/E/ES seams;
19. separate provenance, validation, and implementation confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
