## Engineering disposition

**The `BLOCK` is valid, but the registry reset and repaired runtime behavior remain accepted. Proceed with one narrowly bounded repair in the existing write-enabled Capability conversation.**

The audit closes the four findings that motivated the previous repair at the behavioral level:

- the canonical B1 parser now handles bounded visible H2 location correctly;
- the primary and cross-document paths agree on current inputs;
- RW0 fence behavior is correct under independent probes;
- the migration ledger now contains the intended old/new rename mapping.

The remaining blockers are narrower:

1. **One checked-test ownership defect.**  
   The RW0 owner test still holds detached aliases to the B1 parser. Replacing the B1 owner module’s parser after import does not affect those aliases, so a stale copied parser can reappear while all checked tests remain green.

2. **One external causal-ledger schema defect.**  
   The retained 27-row RW0 fence ledger omits explicit `family` and `diagnostic` fields. The behavior is sound, but the evidence requires inference.

3. **One external migration-checker defect.**  
   The checker accepts `new_node_id` on non-rename records and does not enforce rename-target uniqueness across the entire ledger.

None requires a source, document, registry, schema, or authority change.

### Frozen repository boundary

Only this existing test path may change:

```text
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The following remain byte-identical:

```text
tests/test_rw0_b1_boundaries.py
both governing documents
all production source
all other 28 candidate paths
```

The external fence ledger and migration checker are regenerated under a new evidence root; they are not repository files.

### Parser anchoring decision

The RW0 test must import the **B1 owner test module**, not the parser function by value, and resolve the parser through the module object on every call.

The cross-document path may adapt the returned projection but may not:

- copy the parser;
- retain a detached function alias;
- define a fallback grammar;
- use dynamic import or source execution.

The new tests must independently kill:

```text
stale local parser bound to every RW0 alias
post-import replacement of the B1 owner parser
copied/fallback parser
cross-only stale projection
```

Each equivalence-corpus row must also have an independent expected result—either the exact canonical projection or the exact finite diagnostic. Equality between two aliases is no longer enough.

### Evidence repair decision

The new fence ledger must use a closed schema containing, for every row:

```text
schema_id
case_id
document_sha256
family
expected_real_result
actual_real_result
sensitivity_mutant
expected_mutated_result
actual_mutated_result
diagnostic
source_node_id
```

The finite `family` values are:

```text
valid_closer
invalid_closer
non_opener
```

The migration checker must use disposition-specific closed schemas, forbid `new_node_id` on non-rename records, and enforce endpoint uniqueness across **all** records. It must kill the two previously surviving mutants:

```text
duplicate_target_nonrename
shared_new_endpoint_nonrename
```

Because one repository test changes, the previous validation reset becomes historical evidence. A new complete final validation sequence and full suite are required on the new bytes.

## Repair handoff

Send this complete prompt to the **existing write-enabled Capability implementation conversation**:

:chatgpt-content-reference{index="0"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Owner_Oracle_Final_Audit_Findings_Repair_Prompt.txt

Size:
24,454 bytes

SHA-256:
b701f9d58fd48d6aef8e7505b7049742314796b6db4f4dcb1459be2fe7cfe302
```

The prompt is bound to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Opening manifest:
51b6adfdd88d538e26b7166681465fbb27abf467ec1e5936b646437e58d9f58b

Opening complete output:
9e9a3582ae6109184593a1c68aff584ffe3f172f1db471b70ad2a20dee7d7bce

Opening nodes:
5,051

Opening node-list SHA-256:
5e2a6c5f9e603895b9f9daf021ccc36a9915a8b923ddb7fe8c287b49325bb1aa

Latest audit root:
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-final-reaudit.6NY6CJ

Latest audit-index SHA-256:
96badb399c58f0b172e8f1e4eb80d68304e3dc4bc58485ca7d8ba729e776e7c7
```

The required result is:

```text
COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

That result advances only to another fresh, read-only independent audit. The commit gate remains blocked until that audit returns `ACCEPT`.

### Source

- Codex final fresh re-audit report supplied in this turn.

**Confidence:** High that all three blockers are repairable with one repository test change plus external evidence regeneration; high that the registry architecture and production behavior should remain untouched; medium-high that the next audit will accept if parser ownership is dynamically anchored and both external checkers use genuinely closed schemas rather than report-time inference.
