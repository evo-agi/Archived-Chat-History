## Engineering disposition

**Do not begin a workspace-write repair yet.** The audit correctly widened the problem beyond the 20-path Capability candidate.

The decisive findings are `RW0-B2-AUD-001` and `AUD-002`:

- Capability qualification delegates semantic authority to B1’s `validate_host_qualification(...)`.
- B1 currently accepts exact-class values after projection and digest comparison rather than complete owner reconstruction.
- That permits a correctly resealed but constructor-invalid readiness value to reach `qualified/qualified`.
- B1 and nested C2A projection can also recurse before the stated work meter is charged.

Therefore, repairing only Capability would leave its central claim—“complete B1 revalidation under bounded work”—false.

This is an **owner-hardening prerequisite**, not a reason to reject the accepted Capability architecture. B1 remains a private supplied-fact semantic layer that grants no authority or contact; the bug is in enforcing its existing contract, not in that contract’s ownership split. 

## Required sequencing

The correct sequence is now:

```text
read-only protected-owner reconciliation
    ↓
integrated parent-only repair on the existing Capability branch
    ↓
new exact provenance target
    ↓
fresh independent re-audit
    ↓
commit/PR gate only after ACCEPT
```

The repair should remain integrated on the current uncommitted branch **unless** reconnaissance proves the C2A/B1 owner hardening requires schema identities, public APIs, migrations, or an unbounded rewrite.

That default avoids moving or rebasing the current 20-path candidate and keeps the final auditor bound to one exact integrated patch. It does not authorize broad owner edits before their algorithm, budgets, imports, tests, and touched-file ceiling are frozen.

This follows the project repair lifecycle: after an audit finding, return to the implementation context for a parent-only repair, and require a new independent audit because the bytes have changed. 

## Finding disposition

| Findings | Engineering treatment |
|---|---|
| `AUD-001`, `AUD-002` | Read-only design freeze required for B1/C2A/lineage owner reconstruction and all affected budgets. |
| `AUD-003` | Capability-local Wire-loader sanitization. |
| `AUD-004` | Delete the retained Wire owner callable after one-time initialization. |
| `AUD-005`, `AUD-008` | Correct live RW0 status and open-decision prose. |
| `AUD-006` | Narrow the error claim to **public semantic immutability**; do not claim impossible resistance to deliberate low-level CPython reflection. Hide ordinary `__dict__` access where practical and prove reflective additions cannot influence semantics or expose supplied payloads. |
| `AUD-007` | Treat generic unknown `session*` keys as private material while preserving accepted-field-first handling. |
| Audit atime observation | Non-candidate procedural observation; no repository repair required. |

The local findings are straightforward. The unresolved engineering work is the protected-owner seam:

- whether C2A should expose one private bounded reconstruction helper rather than B1 duplicating C2A slot inventories;
- how `CanonicalC2B3DLineage` is safely reconstructed;
- whether all B1 public methods and relations are hardened together;
- the exact replacement for the B1 `241` and Capability composed `490` budget claims;
- the final expanded touched-file ceiling.

Strong provenance does not resolve those correctness issues; provenance only proves that implementation and audit inspected the same bytes. 

## Next Codex engagement

Change the existing Capability implementation conversation back to **read-only**, then send this complete prompt:

:chatgpt-content-reference{index="3"}

Verify the artifact:

```text
Filename:
Coordinator_RW0_B2_Capability_Protected_Owner_Repair_Reconciliation_Prompt.txt

Size:
34,800 bytes

SHA-256:
70e48a7e6b06b4189f72c9709ddd539df424d97c3131bc5c80e22bdfbe60daf6
```

The prompt binds the current live candidate to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Current canonical manifest:
41a256e52bf5b3e677ec88736889230be416005da429bf5cb3339c92d9427c76

Current complete output:
8d8ff431ae0aa0362b4d298e5261ba866ca9f7eeae18a3e2f93bb33d233b088b

Topology:
20 dirty
14 tracked modified
6 untracked
0 staged
0 unmerged
```

It uses four bounded read-only perspectives:

1. B1 reconstruction and relation budgets.
2. C2A and lineage owner reconstruction.
3. Capability-local and documentation repairs.
4. Integrated scope, tests, validation, provenance, and audit planning.

It explicitly requires inspection of every B1 `_value(...)` call site, every relation that currently continues using the original object, all nested C2A classes consumed by B1, and the lineage owner.

## Required reconciliation outcomes

The successful result must return all three:

```text
RW0_B2_CAPABILITY_REPAIR_RECONCILIATION_READY

B1_C2A_OWNER_HARDENING_SCOPE_FROZEN

INTEGRATED_REPAIR_ON_EXISTING_BRANCH_JUSTIFIED
```

`READY` requires:

- exact non-recursive owner reconstruction algorithms;
- exact raw-state preflight before any public projection or digesting;
- every affected B1 relation using reconstructed locals only;
- exact new work-budget arithmetic;
- fixed import direction and authoritative owner modules;
- exact Capability-local repairs;
- exact documentation wording;
- one closed maximum touched-file allowlist;
- causal tests and class-wide bypass mutants;
- full validation/provenance/re-audit order.

The prompt returns `PARTIAL` or `BLOCKED` rather than guessing if the hardening requires identity changes, public surface changes, migrations, an unbounded C2A rewrite, or movement of the uncommitted candidate.

No repository mutation or tests are authorized in this reconciliation turn. The operating protocol deliberately separates read-only planning from the later sole-writer mutation turn. 

### Sources

- Codex independent audit report supplied in this turn.
- Current B1 scope and non-authority posture. 
- Read-only planning, sole-writer repair, and mandatory re-audit lifecycle.  
- Provenance versus correctness and confidence separation. 

**Confidence:** High that the audit’s two owner-layer blockers are real and must precede Capability acceptance; high that the Capability architecture itself should be retained; intentionally provisional on the final owner-hardening allowlist and budget numbers until the read-only reconciliation completes.
