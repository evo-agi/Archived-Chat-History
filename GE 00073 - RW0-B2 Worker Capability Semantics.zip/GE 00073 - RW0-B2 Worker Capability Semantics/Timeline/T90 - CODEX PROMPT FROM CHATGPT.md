PROMPT_ID

RW0_B2_CAPABILITY_COMPLETE_MARKDOWN_ORACLE_REPAIR_INDEPENDENT_AUDIT_V1

TITLE

Coordinator RW0-B2-Capability — fresh independent audit of the final
two-test-file complete Markdown oracle repair

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated independent audit.

Use a new Codex conversation. Do not use the write-enabled implementation
conversation that produced the repair.

The audit parent and every audit subagent are read-only. No repository
mutation, formatting, cleanup of candidate bytes, dependency installation,
staging, commit, push, PR, merge, tag, release, deployment, remote/service/
provider/host contact, product worker/model invocation, database mutation,
migration, or supporting-repository inspection is authorized.

Audit-created probes, clean external HEAD archives, pytest outputs, and
provenance records may be written only beneath one new external operator-owned,
non-symlink, mode-0700 audit root.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Determine whether the exact final tests-only candidate mechanically closes the
four remaining findings from the preceding independent audit without weakening
test causality, current owner-document truth, production semantics, authority
boundaries, validation, or provenance:

```text
B1 owner semantic oracle:
  20 semantically equivalent stale-current claims survived.

B1 hidden-heading oracle:
  3 Markdown-equivalent duplicate owner/region headings survived.

RW0 status semantic oracle:
  16 semantically equivalent contradictory current-status claims survived.

RW0 hidden-heading oracle:
  3 Markdown-equivalent duplicate owner/status headings survived.
```

The preceding audit accepted:

- Capability canonical-reason identity and its external mutants;
- the thirteen-relation B1 matrix and its external mutants;
- all production source;
- all live governing documentation;
- privacy, import, public, and authority boundaries.

Do not reopen those accepted surfaces without a new concrete contradiction.

EXPECTED LIVE IDENTITY

Require at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate modes:
all regular 0644
```

Require no Git operation, lock, `git diff --check` failure, repository cache,
bytecode, database, journal, archive, build output, generated repository
manifest, recorder residue, or thirty-first changed path.

Do not fetch, switch, reset, clean, stash, rebase, or merge.

FINAL AUDIT TARGET

Retained final repair evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB
```

Primary final report:

```text
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB/final_closeout/final_report.md
```

Required final identities reported by the repair:

```text
canonical-manifest SHA-256:
8d5ed37273a3583104b2fb4f5acee045d7cc18799fdda368d2628e75d8807841

complete recipe output SHA-256:
e813ead384d3c88eb897d996c32b93245841279e31c002558c12dc36e9611d0c

file count:
30

final pytest node count:
5114

full suite:
5114 collected
5114 passed
attempt 001 only

dirty topology:
30/24/6/0/0
```

Required final evidence:

```text
42-record closure ledger:
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB/final_closeout/audit_survivor_closure_ledger.json

self-excluding evidence index:
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB/evidence_index.jsonl

index rows excluding itself:
406

index SHA-256:
225152f9cdb4e096585b97d55d6e4aa667450d1a690638d5ffcd1d4688e2e9ec
```

Use the final report, aggregate identities, evidence index, and indexed records
to recover and verify—not infer—the exact:

```text
canonical-manifest path
canonical-manifest byte size
tracked textual-diff SHA-256
complete recipe output byte size
final ordered node-list SHA-256
full-suite summary and JUnit identities
exact per-file final manifest
exact 209-node addition list and file split
```

If any mandatory identity is absent, internally inconsistent, unsafe to read,
or not bound by the self-excluding index, return `AUDIT_PROVENANCE_MISMATCH`
before correctness judgment.

OPENING REPAIR TARGET

The two-test-file repair began from the exact candidate recorded beneath:

```text
/private/tmp/ge-coordinator-rw0-b2-final-test-repair.fqBaN1
```

Required opening identities:

```text
canonical-manifest size:
6430 bytes

canonical-manifest SHA-256:
230786a458ed8e484c6ec37416f783cd71b5c47ec67a27d2bdd44afc7fe92772

tracked textual-diff SHA-256:
7f77ef027a80f0e5cb8dc686fcecf55dc8ca1ef3493c25a5771f7a2be1b9261e

complete recipe stdout size:
6663 bytes

complete-output SHA-256:
f33e22e718b8826ad157ccf0f936abebe06b0699af14feb572dc3c5256d27c83

opening pytest node count:
4905

opening ordered-node-list SHA-256:
1a3b2c384bfe06ee5fdc358e22807cc0e3ad8f0fbeca004a35ee4f97b3adefa9
```

Exactly these two entries must differ from that opening target:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The other twenty-eight opening entries must be byte-, kind-, type-, mode-,
size-, and classification-identical.

PRECEDING INDEPENDENT AUDIT

The audit whose exact survivor set this repair claims to close is:

```text
root:
/private/tmp/ge-coordinator-rw0-b2-final-test-audit.qOlJrT

report:
/private/tmp/ge-coordinator-rw0-b2-final-test-audit.qOlJrT/audit_report.md

finding ledger:
/private/tmp/ge-coordinator-rw0-b2-final-test-audit.qOlJrT/finding_ledger.json

external mutant results:
/private/tmp/ge-coordinator-rw0-b2-final-test-audit.qOlJrT/external_mutant_results.json

closeout:
/private/tmp/ge-coordinator-rw0-b2-final-test-audit.qOlJrT/closeout.json

self-excluding evidence index:
/private/tmp/ge-coordinator-rw0-b2-final-test-audit.qOlJrT/evidence_index.jsonl

index rows excluding itself:
61

index size:
10433 bytes

index SHA-256:
67ad5eeb73458c61da23f8a4ac50791b0abbe721439e73c98e26cc23572c299f
```

Verify it safely and preserve it unchanged.

EXACT RECIPE SOURCE

Decode this base64 only beneath the new audit root. Require exactly 3,945 bytes
and SHA-256:

```text
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Retain the decoded source mode 0400.

```text
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

The historical recipe output path is:

```text
/tmp/ge-coordinator-b3a-audit-manifest-v1.json
```

Run the exact source twice with source bytes unchanged and only that external
fixed sink safely redirected to two unique audit-root files. Retain the exact
wrapper source and prove the redirection cannot affect Git queries, stdout,
canonical JSON, or any other recipe behavior.

PROVENANCE GATE

Before correctness inspection or audit subagents:

1. create one new operator-owned, non-symlink, mode-0700 audit root beneath
   `/private/tmp`;
2. safely `lstat` every component of the final-repair and preceding-audit
   evidence paths;
3. verify both self-excluding evidence indexes exactly;
4. independently inventory both evidence roots and compare them again at
   closeout;
5. verify exact repository identity and `30/24/6/0/0` topology;
6. locate the indexed final canonical manifest through the final report and
   aggregate identities;
7. require canonical JSON, file count 30, and SHA-256
   `8d5ed37273a3583104b2fb4f5acee045d7cc18799fdda368d2628e75d8807841`;
8. verify every manifest entry by classification, regular-file type, mode,
   size, and SHA-256;
9. verify no thirty-first changed path;
10. verify every path outside the manifest equals HEAD;
11. verify the exact recipe source;
12. execute it twice with safe sink redirection;
13. require both generated manifests to equal the retained final manifest
    byte-for-byte;
14. require both complete outputs to be byte-identical and SHA-256
    `e813ead384d3c88eb897d996c32b93245841279e31c002558c12dc36e9611d0c`;
15. require the tracked textual-diff identity recovered from indexed final
    evidence;
16. load and verify the opening repair manifest;
17. prove exactly the two authorized test entries changed and the other 28
    entries remained exact;
18. verify the 42-record closure ledger, final node list, node-addition list,
    full-suite summary, JUnit, and final guards;
19. verify all explicitly protected source/docs/public surfaces.

On any candidate or mandatory evidence identity mismatch, stop before
correctness inspection and return exactly:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not approximate, reconstruct, or regenerate a missing target.

EXPLICITLY PROTECTED BY THIS TESTS-ONLY REPAIR

These must equal the opening repair target:

```text
all .docs files
all production source
src/ge_nwp_coordinator/__init__.py
pyproject.toml

tests/test_rw0_b2_capability_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py

all SQL, migrations, schemas, catalogs
StateStore
WriterSession
package exports
dependency metadata
```

ACCEPTED CONTRACTS — DO NOT REOPEN BY INERTIA

Preserve:

- Capability production behavior and canonical-reason tests;
- all thirteen B1 production relations and their now-accepted causal matrix;
- live B1 retrieval maximum `1285`;
- Capability as the sole current cross-module B1 consumer;
- current RW0-B1, RW0-B2-Wire, and RW0-B2-Capability private semantics;
- later RW0-C/D/E and ES owner seams;
- C2A, lineage, B1, Wire, and Capability schemas, identities, canonical bytes,
  budgets, reason precedence, and import direction;
- no source authentication, permission, acceptance, contact, persistence,
  runtime, provider, credential, endpoint, session, Git, or publication
  authority.

Use the audit to detect a concrete contradiction or oracle defect, not to
redesign green production semantics.

AUDIT PERSPECTIVES

After the provenance gate, use exactly four bounded, non-nesting, read-only
perspectives when available. No child runs tests or modifies files.

1. Markdown grammar auditor
   - independently implement the finite backtick/tilde fence grammar;
   - independently implement ATX heading recognition with 0–3 spaces,
     delimiter rules, closing hashes, tabs, and 4-space non-heading behavior;
   - independently implement Setext heading recognition;
   - compare visible and all-heading inventories;
   - test unclosed fences, opposite markers, longer closers, hidden duplicates,
     HTML comments if the checked oracle claims them, and non-ASCII whitespace;
   - identify overbroad or underbroad parsing.

2. B1 complete-owner semantic auditor
   - recover all 20 exact audit survivors;
   - verify 20/20 rejection through the same checked positive oracle;
   - independently generate paraphrases and punctuation/Markdown variants;
   - challenge retrieval-cap detection and current-consumer detection;
   - probe before/inside/between/after/tail/table/list/blockquote placements;
   - test historical and unrelated false-positive controls;
   - verify all 3 B1 hidden-heading survivors and generated duplicates reject.

3. RW0 complete-status semantic auditor
   - recover all 16 exact audit survivors;
   - verify 16/16 rejection through the same checked positive oracle;
   - use exact subjects RW0-B1, RW0-B2-Wire, RW0-B2-Capability;
   - challenge future/blocked/deferred/unimplemented and ownership-rollback
     grammars with paraphrases;
   - probe all placements and table/list/blockquote forms;
   - verify all 3 RW0 hidden-heading survivors and generated duplicates reject;
   - verify correct C/D/E/ES future statements remain accepted.

4. Test-evidence, provenance, false-positive, and authority auditor
   - exact two-entry delta and 28-entry equality;
   - 42-record closure ledger completeness;
   - 209-node expansion ownership and non-weakening;
   - external mutant independence versus helper circularity;
   - retained validation and full-suite binding;
   - public/import/privacy/authority non-widening;
   - remaining C/D/E/ES seams.

The parent performs reconciliation, independent external mutants, node
comparison, validation, and closeout. Preserve disagreements.

Every finding must include:

```text
ID
type
severity: critical | high | medium | low | observation
current contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect or pre-existing issue
```

REQUIRED SOURCE AND TEST INSPECTION

Inspect both changed test files completely:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Inspect their unchanged owners:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md
```

Inspect accepted adjacent tests and owners to verify non-regression:

```text
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_wire_boundaries.py

src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py

tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py

src/ge_nwp_coordinator/__init__.py
pyproject.toml
```

Inspect additional Coordinator files only for a concrete dependency and record
why. Do not inspect another repository.

HYPOTHESIS A — FINITE MARKDOWN GRAMMAR

Independently prove or falsify the checked grammar.

### Fences

Exercise:

```text
backtick and tilde openers
run lengths 3, 4, 5, and 6
0, 1, 2, 3 leading ASCII spaces
4-space non-fence control
matching marker required
closer run >= opener run
shorter closer rejected
ASCII space/tab suffix accepted
text suffix rejected
NBSP and EM SPACE suffix rejected
opposite marker does not close
unclosed fence hides through EOF
headings inside fence hidden
```

### ATX headings

Exercise:

```text
levels 1 through 6
0 through 3 leading ASCII spaces
4-space non-heading control
space delimiter
tab delimiter
end-of-line delimiter
missing delimiter
NBSP/EM SPACE non-delimiter
optional closing hashes preceded by ASCII space/tab
unspaced hashes retained in title
ASCII trailing whitespace
internal ASCII whitespace normalization
```

### Setext headings

Exercise:

```text
level 1 and level 2
0 through 3 leading spaces
4-space non-heading
ASCII trailing space/tab
non-ASCII trailing whitespace
empty preceding line
preceding line inside fence
```

### Hidden structure

For each designated B1 and RW0 owner/region heading, externally inject:

```text
visible duplicate ATX
1–3-space ATX duplicate
closing-hash ATX duplicate
tab-delimited ATX duplicate
Setext duplicate
backtick-fenced duplicate
tilde-fenced duplicate
unclosed-fence duplicate
HTML-comment-contained textual duplicate
four-space literal non-heading control
same-title sibling before
same-title sibling after
relocated region
```

Require the checked oracle's policy to be internally consistent. If it claims
commented forms are hidden duplicates, test them causally; if comments are not
part of the finite Markdown-heading grammar, the tests and report must not
overclaim them.

HYPOTHESIS B — B1 COMPLETE-OWNER ORACLE

Recover the exact 20 semantic survivors and 3 hidden-heading survivors from the
preceding audit evidence.

Require:

```text
20/20 exact semantic survivors rejected
3/3 exact hidden-heading survivors rejected
```

Then independently generate additional semantically equivalent mutations that
are not constructed from the checked test's own expected corpus.

Challenge:

- retrieval subject aliases:
  retrieval, retrieval event, retrieval event sequence,
  validate_retrieval_event_sequence;
- bound predicates:
  cap, limit, maximum, budget, work ceiling, units, bounded, capped;
- stale number forms:
  374, 3-7-4, `3` `7` `4`, three hundred seventy four,
  three-hundred-and-seventy-four;
- consumer subjects:
  production consumer, caller, importer, module, cross-module user;
- zero/current/future predicates:
  zero, none, no, absent, future, deferred, pending, planned,
  target-only, unimplemented, not implemented, not current.

Use Markdown emphasis, links, inline code, table delimiters, punctuation,
parentheses, list items, blockquotes, and mixed case.

Place contradictions:

```text
after title
before relation region
inside relation region
between regions
inside consumer region
after consumer region
before next same-or-higher heading
document tail
```

Require no false rejection of:

- the unchanged owner;
- the one current 1285 relation statement;
- Capability's one current sole-consumer statement;
- later C/D/E seams;
- nonauthority statements;
- unrelated numeric values;
- genuinely fenced examples with no designated duplicate heading.

Audit circularity: the oracle must not merely compare against the same literal
mutant corpus used by the parameterized tests. There must be an independent
semantic classifier or independent external mutants that kill equivalent forms.

HYPOTHESIS C — RW0 COMPLETE-STATUS ORACLE

Recover the exact 16 semantic survivors and 3 hidden-heading survivors.

Require:

```text
16/16 exact semantic survivors rejected
3/3 exact hidden-heading survivors rejected
```

Independently challenge exact subjects:

```text
RW0-B1
RW0-B2-Wire
RW0-B2-Capability
B1
B2-Wire
B2-Capability
the implemented B tranche
```

Challenge contradictory predicates:

```text
future
blocked
deferred
unimplemented
not implemented
not current
absent
pending
planned only
target only
earliest unresolved tranche
cannot begin until
awaiting implementation
does not yet exist
```

Challenge ownership rollback for:

```text
durable ingest
evidence membership/completeness
recovery
terminal facts
acceptance latch
physical custody
retrieval delivery
transport
stream plumbing
process launch/supervision
cancellation delivery
provider/CLI/App Server
credentials
live-host proof
ES admission
runtime identity/lifecycle/cancellation
retained results
```

Use prose, tables, lists, blockquotes, emphasis, inline code, links,
punctuation, and mixed case.

Place each class before, inside, after, and at the tail of the current status
region.

Require no false rejection of:

- unchanged current B semantics;
- correct C/D/E future statements;
- correct ES runtime ownership;
- statements saying physical/durable mechanics remain open outside B;
- unrelated uses of blocked/future/deferred.

Again, checked parameterization alone is insufficient. Independently generated
equivalent mutants must fail through the production checked oracle.

HYPOTHESIS D — TEST-ORACLE NON-WEAKENING

The reported repair adds 209 nodes. Independently verify that this expansion is
causal rather than volume-only.

Require:

- every opening 4,905 node retained in exact relative order;
- exactly 209 additions;
- additions only in the two changed test files;
- no removed, renamed, skipped, xfailed, reparameterized, collapsed, or
  reordered existing node;
- no broad exception-swallowing, warning suppression, or weaker assertion;
- each parameterized case maps to a unique semantic or structural mutation;
- no duplicate cases with different IDs but byte-identical mutation and
  placement;
- all 42 exact audit survivors have one-to-one closure-ledger entries;
- generated semantic/structural controls are distinct from the audit corpus;
- false-positive controls assert acceptance, not merely absence of an
  exception from helper setup;
- finite diagnostics do not echo arbitrary mutated documents.

Construct external mutants against the test helpers:

```text
return success for one exact audit-survivor ID
skip all hidden-heading checks
ignore Setext headings
treat 4-space indentation as heading
ignore trailing contradictions
scan only the expected H2
replace exact RW0-B2-Capability subject with RW0-B\b
allow one stale-number word form
allow one zero-consumer paraphrase
allow one ownership-rollback table row
make all false-positive controls vacuously pass
```

The checked tests must kill each mutant for the intended reason.

IMPLEMENTATION-EVIDENCE ASSESSMENT

Review every retained attempt without silently crediting summaries.

Reported implementation evidence:

```text
red gate:
42 exact audit survivors failed as expected
both live-document controls passed

generated controls:
B1 structural       12
B1 semantic         48
B1 false-positive    8
RW0 structural      12
RW0 semantic        77
RW0 false-positive   8

final credited:
selected causal
B1 boundaries
RW0 owner/status
B1 compatibility
Capability/Wire compatibility
owner/static/status compatibility
final collection 5114
full suite attempt 001: 5114/5114
attempt 002: not run
```

Determine:

- whether the red gate uses the exact preceding audit survivor corpus;
- whether every closure-ledger entry maps to a checked final node;
- whether generated controls are independent rather than aliases of the exact
  corpus;
- whether final evidence is bound to the final manifest and node list;
- whether only the two authorized files changed;
- whether the full-suite record is parseable and complete;
- whether no hidden second full-suite attempt exists;
- whether cleanup and the self-excluding index cover all retained evidence.

NODE IDENTITY

Run one candidate collection and one clean external `git archive HEAD`
collection under identical isolated conditions.

Require:

```text
candidate:
5114 unique nodes

clean HEAD:
4655 unique nodes

intersection:
4655

candidate-only:
459

HEAD-only:
0

HEAD order preserved:
true
```

Relative to the 4,905-node opening repair target require:

```text
209 additions
0 removals
0 renames
opening order preserved
```

All additions must belong only to:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Recover and compare the exact final node-list SHA-256 and literal additions from
the indexed final evidence. Do not guess them.

INDEPENDENT VALIDATION

Only after source/test inspection and external mutants are green enough, run
serially beneath the audit root.

For every child:

```text
umask 022 before launch
child numerical umask must be 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Verify every target exists.

Run:

1. selected exact-survivor and generated-control causal nodes;
2. B1 boundaries:
   ```text
   tests/test_rw0_b1_boundaries.py
   ```
3. RW0 owner/status:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   ```
4. B1 compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```
5. Capability/Wire compatibility:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
6. owner/static/status compatibility:
   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   ```

Every credited run must have:

- return code 0;
- zero failures/errors/skips/xfails/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate or unmapped cases;
- matching caller/child umask;
- unchanged candidate fingerprint.

If all inspection and focused validation remain green, run the complete
repository suite exactly once independently with ordinary quiet rendering.

Require:

```text
5114 collected
5114 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

If a deterministic material blocker is found first, the full suite may be
withheld. State that explicitly. Never repair candidate bytes.

PUBLIC, IMPORT, PRIVACY, AND AUTHORITY BOUNDARY

Require:

- no production or documentation byte changed from the opening target;
- no reverse import;
- no package-root export;
- no production caller change;
- no dependency, SQL, migration, schema, catalog, StateStore, or WriterSession
  change;
- no filesystem, process, network, provider, Bridge, ES-call, Git,
  publication, or runtime effect;
- no weakening of accepted Capability or B1 production semantics;
- no weakening or silent broadening of current B1/RW0 owner truth;
- Capability remains private pure supplied-fact semantics;
- source refs/digests remain unauthenticated evidence;
- no permission, acceptance, durable truth, or runtime authority;
- C/D/E and ES remain later owners.

CLOSEOUT

After removing only audit-created transient artifacts:

1. rerun the exact recipe twice with safe sink redirection;
2. require exact equality to the opening final target;
3. require the same manifest, complete output, textual diff, file count,
   per-path hashes, and topology;
4. compare final-repair evidence opening and closing inventories;
5. verify the preceding audit evidence index remains unchanged;
6. verify no operation, lock, staged/unmerged path, cache, bytecode, database,
   journal, archive, build, recorder, or generated-manifest residue;
7. retain all audit evidence beneath the new mode-0700 root;
8. make retained audit files regular, operator-owned, and mode 0400;
9. create a self-excluding evidence index.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low candidate defect remains;
- `BLOCK` for any repairable test, parser, semantic-classifier, evidence,
  validation, privacy, authority, or regression-oracle defect;
- `REJECT` only for a fundamental accepted-architecture contradiction;
- `AUDIT_PROVENANCE_MISMATCH` only for target/evidence identity failure before
  correctness judgment.

If `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMPLETE_MARKDOWN_ORACLE_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or create a PR.

FINAL REPORT

Include:

1. opening and closing identity;
2. exact provenance and two-entry delta;
3. final repair and preceding audit evidence verification;
4. four audit perspectives and disagreements;
5. severity-ranked finding ledger;
6. independent Markdown grammar result;
7. B1 20/20 + 3/3 exact survivor result;
8. B1 independently generated semantic/structural mutant result;
9. RW0 16/16 + 3/3 exact survivor result;
10. RW0 independently generated semantic/structural mutant result;
11. false-positive and non-weakening assessment;
12. implementation-attempt evidence assessment;
13. node comparison and literal additions;
14. independent focused/full validation;
15. public/import/privacy/authority assessment;
16. closeout guards;
17. separate provenance, validation, and implementation confidence.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
