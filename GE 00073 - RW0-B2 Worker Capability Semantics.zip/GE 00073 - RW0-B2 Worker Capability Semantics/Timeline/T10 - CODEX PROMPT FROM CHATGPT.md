TITLE

Coordinator RW0-B2-Wire — cancellation-request owner decision and final
read-only schema-freeze closure

ENGAGEMENT TYPE

Finite parent-only read-only reconciliation in the existing RW0-B2 design
conversation.

This is not another broad reconnaissance and not an implementation prompt.
Do not create or resume subagents. The four-explorer reconnaissance and the
first parent-only closure are complete.

Do not edit, create, delete, format, chmod, stage, commit, push, create or
modify a PR, merge, tag, release, deploy, install dependencies, run tests or
pytest collection, invoke Codex/model/provider behavior, contact any network,
worker, host, service, Bridge, ES, IM, or supporting repository, or create
repository-local artifacts.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED BASELINE

Require before inspection and at closeout:

- branch:
  trunk_dev
- HEAD:
  02450d3c99faf0fe7b299b914afaed312421bc8b
- tree:
  0b5394c591bd277d56797794f71af954ccb93846
- sole parent:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- subject:
  feat: implement RW0-B1 pure phase-entry semantics (#3)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- worktree/index/untracked/unmerged:
  clean
- no Git operation or lock
- no repository-local cache, bytecode, database, build, archive, or generated
  manifest residue.

Do not fetch or contact a remote. Stop on mismatch.

PRECEDING DISPOSITION

Treat the immediately preceding parent report as the opening design packet:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_PARTIAL
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

It established:

1. The adopted command and result shapes are contract-compatible.

2. The B2 int64 representability policy closes the first-RW0 framed integer
   gap without changing C2A or B1.

3. Independently calculated candidate maxima are:
   - command payload: 5,898 bytes;
   - one-key result payload: 16,627 bytes;
   - frame totals: 5,906 and 16,635 bytes;
   - depth: command 3, result 4;
   - containers: command 5, result 8;
   - key pairs: command 71, result 77.

4. Those numbers still require fully related literal maximum fixtures,
   test-owned calculations, and final profile inclusion.

5. The outer frame remains identity-free:
   `NWPF`, version 1, command kind 1, result kind 2, two-byte unsigned
   big-endian payload length.

6. The result envelope remains an ordered tuple of existing worker-authored
   `WorkerObservationV1` mappings in exactly:
   - `(worker_started, worker_completed)`; or
   - `(worker_started, candidate_captured, worker_completed)`.

7. Process exit zero is a proposed B2 classifier rule, not a C2A semantic
   success claim.

8. Remaining unfrozen items were:
   - cancellation-request evidence and its graph;
   - finite cardinality for adapter observations and B2 supplements;
   - numeric shared work budgets and precharged C2A tariffs;
   - final protocol profile ref/digest;
   - the exact touched-file ceiling.

9. Capability remains seam-bounded and does not block Wire.

OWNER DECISION — CANCELLATION REQUEST IS A DISTINCT B2 SOURCE CLAIM

Adopt a separate private B2 value:

```text
RW0WireCancellationRequestObservationV1
```

with schema ID:

```text
governed-execution.nwp-rw0-wire-cancellation-request-observation.v1
```

Do not fold this fact into:

- the generic B2 process supplement;
- a C2B cancellation decision;
- a cancellation effect or command;
- a cancellation delivery;
- cancellation acknowledgement or rejection;
- an OS signal;
- process exit;
- teardown or reconciliation;
- a B1 terminal outcome.

RATIONALE AND OWNERSHIP

RW0-A defines this ordering:

```text
cancel decision/intent
→ cancel effect/delivery
→ request
→ acknowledgement
→ signal
→ process exit
→ teardown
→ semantic terminal outcome
```

No element implies the next.

Therefore:

- the request fact is authored by the exact adapter/supervisor source that
  actually issues the cancellation request to the controlled process;
- Coordinator does not author it;
- B2 shapes and relates the supplied safe source claim only;
- RW0-D later performs the physical request and authors/obtains the evidence;
- RW0-C later decides durable ingest, duplicate/conflict disposition,
  completeness, recovery, and terminal evidence membership;
- the value authenticates no source and grants no authority or acceptance.

Keep the existing private source-native process supplement limited to:

```text
resource_limit_exceeded
signal_delivered
```

The request has a separate value because its identity graph includes the
cancellation command/effect/delivery and immutable target relation, which the
resource/signal supplement does not own. Do not create a nullable polymorphic
union merely to reduce the class count.

EXACT CANCELLATION-REQUEST VALUE REQUIREMENTS

Inspect the owning C2A and RW0-A fields and freeze the smallest exact ordered
field list that mechanically binds all and only the safe facts required below.

The value must contain safe identities sufficient to bind:

1. its own observation ref and self-digest;
2. external source ref;
3. safe evidence ref/digest;
4. exact source invocation identity available in the owning contracts;
5. exact cancellation semantic command identity;
6. exact cancellation effect intent and effect-fence identity;
7. exact cancellation delivery attempt and envelope identity;
8. exact originating attempt-fence identity required by the cancellation
   command/effect relation;
9. exact targeted author/process semantic identity:
   - target semantic attempt;
   - target effect intent and effect fence;
   - target author command;
   - target author delivery/invocation coordinate available in the owner;
10. exact immutable cancellation-target relation required by C2A/RW0-A;
11. request occurrence timestamp;
12. fixed schema ID and one domain-separated self-digest.

Use exact safe refs/digests from current owners. Do not invent a second attempt,
candidate, effect, command, delivery, route, target, or decision identity.

Do not include:

- a raw request body;
- transport bytes;
- signal number;
- PID;
- hostname/IP/endpoint;
- path;
- process handle;
- credential/bearer;
- stdout/stderr/log;
- provider/session data;
- cancellation acknowledgement/rejection;
- signal/exit/teardown/reconciliation/terminal outcome;
- a claim that the request was delivered, accepted, signalled, or completed.

If one listed identity is not available in current owning contracts, remove
only that unsupported identity and provide exact path:line justification.
If the request cannot be related without changing C2A/B1 or inventing an
authority identity, return BLOCKED.

CANCELLATION-REQUEST RELATION

Freeze one pure relation over:

- `RW0WireCancellationRequestObservationV1`;
- the exact target command/delivery/fences used by the normal worker result;
- the exact cancellation command/delivery/fences;
- any existing C2A cancellation target relation inputs required by the owner.

The relation must prove:

- exact built-in value types and valid self-digest;
- source/evidence identity shape only, not authenticity;
- cancellation command/effect/delivery coherence under owning C2A relations;
- target semantic attempt/effect/fence/command/delivery coherence;
- immutable cancellation target points to the exact classified target;
- request source invocation and request evidence are exact and nonempty;
- no request fact is inferred from decision, command, delivery,
  acknowledgement, rejection, signal, or exit;
- content-free finite failures.

The relation must not prove:

- request delivery to the process;
- acknowledgement or rejection;
- signal;
- process exit;
- teardown;
- reconciliation completeness;
- semantic cancellation;
- permission or acceptance.

CLASSIFIER INPUT AND CARDINALITY FREEZE

The process/result classifier must accept separately:

1. one decoded command/delivery pair;
2. zero or one valid worker result envelope;
3. one exact finite tuple of applicable existing adapter-authored
   `WorkerObservationV1` values;
4. zero or one `RW0WireCancellationRequestObservationV1`;
5. one exact finite tuple of B2 source-native process supplements;
6. exact actual attempt/effect fences and exact cancellation graph inputs
   required by the relations.

Derive from the live C2A matrix the exact adapter observation kinds that the
classifier may consume. Freeze a literal closed inventory in the packet.

Required cardinality policy:

- at most one observation of each applicable adapter observation kind;
- acknowledgement and rejection for the same cancellation request are mutually
  exclusive;
- exactly one process-exit observation is required for `usable`;
- zero or one request observation;
- zero or one `resource_limit_exceeded` supplement;
- zero or one `signal_delivered` supplement;
- observation refs and digests are unique across each input collection;
- duplicate exact, conflicting, unrelated, or wrong-invocation facts are
  invalid classifier inputs, not silently deduplicated;
- RW0-C later owns durable duplicate/conflict/stale/late ingest treatment.

Do not use an arbitrary spare cardinality ceiling. The maximum must equal the
closed number of applicable kinds plus the one request and two supplement
kinds.

CANCELLATION CLASSIFIER RULES

A valid related request observation is independently sufficient to prevent
`usable`, even if no acknowledgement, signal, or adverse exit has yet occurred.

Freeze finite classifier reasons that distinguish at least:

- request issued, response absent;
- request acknowledged;
- request rejected;
- request graph mismatch;
- acknowledgement/rejection without matching request;
- acknowledgement and rejection both present;
- unrelated or duplicate cancellation facts.

Required semantics:

1. No request plus no cancellation response:
   normal non-cancellation classification continues.

2. Matching request, no acknowledgement/rejection:
   unusable cancellation-requested/incomplete evidence.

3. Matching request plus acknowledgement:
   unusable cancellation-acknowledged evidence.
   It proves no signal, exit, teardown, reconciliation, or terminal cancel.

4. Matching request plus rejection:
   unusable cancellation-rejected evidence.
   Rejection does not restore normal result usability or authorize continued
   semantic progression; later reconciliation owns the outcome.

5. Acknowledgement or rejection without one matching request:
   invalid/contradictory classifier input.

6. Both acknowledgement and rejection:
   invalid/contradictory classifier input.

7. A matching signal supplement outranks request/acknowledgement/rejection in
   the reported reason, while retaining their evidence bindings.

8. Resource-limit and deadline precedence remain above signal.

9. Request evidence never overrides an invalid graph; graph mismatch is an
   invalid-input failure.

10. Exit zero, valid worker completion, or valid result bytes cannot override a
    current matching request.

Adopt final precedence:

1. invalid, unrelated, duplicate, or contradictory classifier inputs;
2. resource-limit exceeded;
3. deadline reached;
4. signal delivered;
5. cancellation request/acknowledgement/rejection state;
6. adverse or conflicting process exit;
7. result protocol failure;
8. valid result with missing process-exit evidence;
9. valid related result plus exactly one successful exit and no higher
   condition: usable.

State precisely where a malformed result decode error participates. A
source-independent outer decode failure must not be mislabeled as a
cancellation fact.

PROCESS EXIT POLICY

Freeze explicitly:

- C2A permits `process_exit_code` in `-255..255`;
- B2 defines exact exit code `0` as `successful_exit` solely for this
  process/result usability classifier;
- nonzero is `adverse_exit`;
- this does not change C2A semantics;
- exit zero does not prove result validity, worker completion, candidate
  capture, semantic success, or acceptance;
- a valid result plus nonzero exit is `process_result_contradiction`;
- no exit after a valid result is `process_evidence_incomplete`.

PROFILE IDENTITY

After every schema, reason, precedence row, cardinality, payload cap, and work
budget is frozen, define the exact fixed Wire profile.

Freeze:

- exact safe profile ref;
- exact domain;
- literal canonical profile-manifest mapping;
- exact field order for safe projection;
- exact profile digest calculation.

The manifest must bind:

- `NWPF` magic;
- version 1;
- kinds 1 and 2;
- eight-byte header;
- big-endian uint16 length;
- int64 representability policy;
- exact command/result payload shapes and caps;
- canonical JSON rules;
- result grammar;
- cancellation-request schema and relation identity;
- process supplement schema;
- classifier input inventories/cardinality;
- complete classifier reasons and precedence;
- decoder error algebra/precedence;
- structural depth/container/key-pair limits;
- encode/decode/relation/classification work limits.

The profile is not carried in every frame and is not a frame identity,
authenticity proof, permission, or acceptance.

WORK BUDGET CLOSURE

Derive exact numeric budgets for:

- command encode;
- command decode plus relation validation;
- result encode;
- result decode plus relation validation;
- cancellation-request construction/reconstruction and relation;
- process supplement construction/reconstruction and relation;
- process/result classification at maximum valid cardinality.

Every budget must include fixed tariffs or direct charges for:

- header/type/length work;
- each payload byte examined for UTF-8 and canonical-byte comparison;
- each JSON token, scalar, key, and container;
- duplicate-key tracking;
- bounded integer token validation before conversion;
- unknown/missing-field scans;
- canonical re-encoding;
- every nested C2A reconstruction occurrence;
- every owning C2A relation call;
- every B2 relation call;
- every observation/request/supplement occurrence;
- classifier precedence comparisons;
- repeated encode-side aliases;
- called helper work.

Requirements:

- one shared B2 budget per top-level operation;
- no helper reset;
- fixed precharged C2A tariffs independently calculated from exact maximum
  current graphs;
- maximum valid operation accepted;
- one additional charged occurrence rejected;
- cycle rejection before recursive descent;
- aliases charged per occurrence;
- no work before the first cardinality/length preflight is left outside the
  budget.

Do not change C2A/B1 to accept a B2 counter.

PAYLOAD AND STRUCTURAL CALCULATION FINALIZATION

Independently reproduce and either freeze or correct:

```text
command payload cap: 5,898
result payload cap: 16,627
command depth: 3
result depth: 4
command containers: 5
result containers: 8
command key pairs: 71
result key pairs: 77
```

Provide literal formulas and fully related largest-valid fixture plans.

The cancellation request and process supplements are classifier inputs, not
frame payloads; they must not change the command/result payload caps.

Freeze maximum and one-over tests for every figure.

ERROR ALGEBRA

Freeze exact sealed content-free finite reasons for:

A. frame/decoder stages;
B. command/result relation failures;
C. cancellation-request value/relation failures;
D. process supplement value/relation failures;
E. classifier outcomes and invalid-input failures;
F. work/depth/cardinality exhaustion.

Preserve the already adopted decoder stage precedence:

1. invalid outer input type;
2. short header;
3. bad magic;
4. unsupported version;
5. unsupported kind;
6. declared length above kind cap;
7. truncated payload;
8. trailing data;
9. invalid UTF-8;
10. BOM forbidden;
11. JSON syntax/token failure;
12. duplicate key;
13. invalid root/type/scalar;
14. unknown field;
15. missing field;
16. nested C2A reconstruction/digest failure;
17. noncanonical payload bytes;
18. cross-record relation failure.

Within JSON parsing, the deterministic first parser failure wins.

TOUCHED-FILE CEILING

Derive and freeze the exact Wire implementation allowlist now.

The preceding closure identified at least one additional status test:
`tests/test_architecture_contracts.py`.

Inspect the live static inventories and synchronized status owners and return an
exact maximum list, not “at least 15” or a proposed ceiling.

Expected categories:

- one new detailed Wire governing document;
- one new private Wire source module;
- direct Wire value/codec/vector/relation/boundary tests;
- exact production-source/import/public-boundary inventories;
- bounded RW0-A/current-status documents;
- every existing structural/status test that pins process framing as
  unimplemented.

Requirements:

- Wire imports C2A only;
- no B1 import;
- B1 remains byte-identical;
- no package-root export;
- no production caller;
- empty private `__all__`;
- no dependency, `pyproject.toml`, SQL, migration, schema, StateStore,
  WriterSession, public protocol, script, fixture, or config change.

If the exact current owners cannot fit one finite maximum allowlist, return
PARTIAL.

CAPABILITY SEAM

Retain:

```text
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

Confirm that the new request observation:

- is provider/mechanism neutral;
- is not a Capability declaration/observation/qualification;
- carries no credential/session/provider/host data;
- does not make provider-session history program truth;
- leaves CLI/App Server, credentials, invocation, process mechanics, and proof
  to RW0-D/E;
- does not force a Capability class or implementation now.

MANDATORY INSPECTION

Reinspect only the exact owning surfaces needed for this closure:

- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/c2a-first-slice-semantic-protocol-contract.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/worker-execution-boundary.md`
- `.docs/authority-boundaries.md`
- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- relevant C2B decision row/value contracts only to confirm they are not used
  as request evidence;
- `tests/c2a_contract_support.py`
- all worker semantic and RW0-B1 tests relevant to cancellation/observations;
- exact static/public/import/status inventories identified by the previous
  report;
- `src/ge_nwp_coordinator/__init__.py`
- `pyproject.toml`.

Inspect another path only for a concrete owner/import/status dependency and
report it.

READ-ONLY CALCULATION POSTURE

Permitted:

- read-only Git/file inspection;
- standard-library `python3 -B` arithmetic/AST calculations with bytecode
  disabled and no file output;
- project imports only after proving import-side-effect freedom and directing
  pycache externally.

Not permitted:

- tests or collection;
- file creation or mutation;
- network/service/model/Codex invocation;
- database or migration creation.

REQUIRED CAUSAL FUTURE TESTS

The final packet must specify literal test-owned causal mutants for:

- request absent versus present;
- request-only;
- request plus acknowledgement;
- request plus rejection;
- acknowledgement/rejection without request;
- both acknowledgement and rejection;
- request wrong source invocation;
- wrong cancel command/effect/fence/delivery;
- wrong target attempt/effect/fence/command/delivery;
- wrong immutable target relation;
- duplicate request ref/digest;
- request timestamp mutation without resealing;
- signal plus request/ack/reject precedence;
- deadline plus signal/request precedence;
- resource plus every lower tier;
- zero/nonzero/missing/duplicate/conflicting exit;
- valid/invalid/missing result under every process tier;
- each adapter observation kind and maximum cardinality;
- each supplement kind and maximum cardinality;
- one-over collection cardinality;
- every budget maximum and one extra charge;
- every profile-manifest field mutation.

Each mutant changes one predicate and reseals only the value owning the changed
digest. Expected inventories, bytes, caps, budgets, and precedence are
test-owned, not imported from production constants.

PROSPECTIVE FORECAST DISPOSITION

Update the existing forecasts:

1. The most likely blocker became the missing cancellation-request owner. State
   whether the separate request observation closes it without changing C2A/B1.

2. The touched-file forecast expanded again because architecture/status tests
   pin process framing as unimplemented. State the exact final ceiling.

3. Audit risk remains highest in:
   - incomplete request/ack/signal/exit noncollapse;
   - classifier precedence;
   - uncharged parser/helper work;
   - noncausal one-field tests;
   - privacy/source-authenticity overclaims.

NEXT STEP AND VERDICT

Return exactly two status lines first.

Success:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_READY
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

Use READY only when the cancellation request value/relation, adapter and
supplement inventories/cardinality, classifier reasons and precedence, exit
policy, profile identity, numeric budgets, caps/structure, error algebra,
touched-file ceiling, tests, validation, provenance, audit plan, and stop
conditions are all exact and source-grounded.

Otherwise:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_PARTIAL
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

or, only for a concrete owning-contract contradiction:

```text
RW0_B2_WIRE_SCHEMA_FREEZE_BLOCKED
RW0_B2_CAPABILITY_BLOCKED
```

READY must include one complete Wire implementation packet with:

1. baseline and inspection boundary;
2. exact adopted values/classes and ordered fields;
3. exact schema IDs/domains/digests;
4. exact function/relation signatures;
5. exact frame bytes and payloads;
6. exact canonicalization/decoder error precedence;
7. exact worker result and request/process evidence grammar;
8. exact classifier matrix/reasons/precedence;
9. exact caps/depth/container/key-pair formulas;
10. exact numeric work tariffs/budgets;
11. exact profile manifest/ref/domain/digest;
12. exact maximum touched-file allowlist;
13. protected surfaces;
14. literal causal test plan;
15. exact isolated validation commands;
16. exact provenance/fresh-audit plan;
17. exact stop conditions;
18. path:line claim ledger;
19. unresolved RW0-C/D/E/ES seams;
20. forecast dispositions.

If READY/BOUNDED is returned, the next permitted step is one bounded
parent-only RW0-B2-Wire implementation prompt. Do not issue or imply a
Capability implementation prompt.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
