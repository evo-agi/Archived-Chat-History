The success token is not enough to bind the repaired bytes, test history, dual-suite validation, or provenance for the next independent audit.

Do **not** launch the fresh re-audit yet. First recover the immutable closeout from the same write-enabled implementation conversation. This is read-only: no repository edits, test reruns, cleanup, staging, or provenance regeneration are authorized.

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Capability_Commit_Compatibility_Final_Audit_Findings_Repair_Closeout_Recovery_Prompt.txt

Size:
13,878 bytes

SHA-256:
3462fd89b5bbc5ba061a16eafbc2eade6214aba63d52cb9e3e0e62dde9f52ba3
```

The recovery must produce the exact evidence needed to construct the fresh audit, including:

- the final canonical manifest, textual-diff identity, recipe outputs, and complete 30-file manifest;
- the exact one-file delta in `tests/test_rw0_b2_capability_boundaries.py` and byte equality of the other 29 candidate entries;
- the closed reachable-call inventory and all constructed/aliased command mutants;
- the literal 43-row stable projection;
- causal records for every protected-content row, including the mutant that escaped the previous audit;
- all stable-contract mutants;
- unstaged, staged, and clean-commit target/projection results;
- opening and final node identities;
- every validation attempt, including failures and superseded runs;
- live and clean-commit full-suite records with indexed run-local pre/post fingerprints;
- final guards, cleanup, and a self-excluding evidence index.

The report must be headed:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

If mandatory retained evidence is absent, Codex must return:

```text
REPORT_EVIDENCE_INCOMPLETE
```

If the live repository no longer matches the bytes that produced the token:

```text
REPORT_PROVENANCE_MISMATCH
```

Once the complete closeout report is recovered, the next permitted step is a new read-only independent audit. The commit gate remains blocked.

**Confidence:** High that closeout recovery is required before another audit; no judgment yet on final acceptance from the token alone.
