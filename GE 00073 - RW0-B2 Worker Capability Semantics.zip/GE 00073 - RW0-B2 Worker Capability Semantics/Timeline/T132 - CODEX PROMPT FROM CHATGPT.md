PROMPT_ID

RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_FRESH_REAUDIT_V1

TITLE

Coordinator RW0-B2-Capability — final fresh independent audit of the
commit-compatible permanent boundary test and its live/clean validation binding

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated independent audit.

Use a new Codex conversation. Do not use any write-enabled implementation,
repair, validation-reset, diagnostic, or commit-gate conversation.

The audit parent and all audit subagents are read-only. No repository mutation,
formatting, cleanup of candidate bytes, dependency installation, staging in the
source repository, commit in the source repository, push, PR, merge, tag,
release, deployment, remote/service/provider/host contact, product worker/model
invocation, database mutation, migration, or supporting-repository inspection
is authorized.

Audit-created probes, alternate indexes, external local-only repositories,
pytest outputs, and provenance records may be written only beneath one new
operator-owned, non-symlink, mode-0700 audit root. Because the checked tests
enforce path privacy, use a short neutral audit-root pattern:

```text
/private/tmp/g4.XXXXXX
```

Pre-screen every path visible to a pytest child with the exact retained
path-safety grammar before launch.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Determine whether the exact final candidate is ready for the commit/push/PR
gate after:

1. repairing the permanent Capability boundary test so it no longer depends on
   transient dirty/staged/untracked Git state;

2. independently proving the target passes in:
   - the accepted unstaged candidate;
   - an alternate-index staged candidate;
   - an external clean committed candidate;

3. passing one complete live suite and one complete clean-commit suite;

4. regenerating validation binding with indexed run-local pre/post
   fingerprints;

5. rerunning the clean suite under a neutral pre-screened path after a prior
   harness path contained the forbidden fragment `binding`.

The audit must verify the final candidate, source/test adequacy, three-state
compatibility, validation evidence, path isolation, provenance, and
public/authority boundaries. Do not reopen accepted B1, Wire, Capability,
registry, parser, migration, or authority architecture without a concrete
contradiction.

EXPECTED LIVE IDENTITY

Require at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644
```

Require:

- `git diff --check` clean;
- cached diff empty;
- no Git operation or lock;
- real source index unstaged;
- no candidate symlink or special file;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, recorder residue, or thirty-first changed
  path.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

FINAL CANDIDATE TARGET

Final commit-compatibility repair evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe
```

Final report:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe/final_report.md
```

Final repair self-excluding evidence index:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe/evidence_index.jsonl

rows excluding itself:
938

size:
151566 bytes

SHA-256:
bdffdfd9757302a7940b803f0d5138fdf9f9b41e53d95fcae3209b0e35dae71d
```

Required final candidate identities:

```text
canonical-manifest SHA-256:
0919e82038367f54defd36171a19550873f38acae714bd7398e5a56b2fb8d77a

pytest node count:
5057

ordered node-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

clean staged/committed candidate tree:
52e32a55dc2e6b023b669810fb244301807f7618

dirty topology:
30/24/6/0/0
```

Recover and verify through the indexed final evidence:

```text
final canonical-manifest path and byte size
tracked textual-diff SHA-256
complete recipe-output path, size, and SHA-256
exact final canonical manifest JSON
final repaired-path identity
opening and final node lists
43-row state-independent projection
five no-status-dependency mutant records
eight stable-contract mutant records
three-state target records
live and clean historical suite records
final guards and cleanup
```

Exactly this one repository path must differ from the independently accepted
pre-repair candidate:

```text
tests/test_rw0_b2_capability_boundaries.py
```

The other twenty-nine candidate entries must be byte-, kind-, type-, mode-,
size-, and classification-identical.

CREDITED LIVE VALIDATION ENVELOPE

V2 validation-binding reset root:

```text
/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset2.Udjr4a
```

V2 final report:

```text
/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset2.Udjr4a/final_report.md
```

V2 self-excluding evidence index:

```text
/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset2.Udjr4a/evidence_index.jsonl

rows excluding itself:
107

size:
21875 bytes

SHA-256:
a3abd5e9252da88623ab3285a6f560b7b71f151f672d25f6236c3779f806abe9
```

The credited V2 live-suite record must establish:

```text
5057 collected
5057 passed
0 failures
0 errors
0 skips
0 xfails
0 warnings
empty stderr
exact retained-node mapping
complete indexed source pre fingerprint
complete indexed source post fingerprint
pre == post
candidate-mutated false
```

The V2 clean-suite failure is historical harness-path evidence only:

```text
5013 passed
44 failed

cause:
external path contained rejected fragment `binding`

candidate/tree mutation:
none

external and source pre/post fingerprints:
byte-identical
```

Do not credit it as clean validation.

CREDITED CLEAN VALIDATION ENVELOPE

V3 neutral-path clean-suite root:

```text
/private/tmp/gv3.efmQ8X
```

V3 final report:

```text
/private/tmp/gv3.efmQ8X/final_report.md
```

V3 self-excluding evidence index:

```text
/private/tmp/gv3.efmQ8X/evidence_index.jsonl

rows excluding itself:
87

size:
15821 bytes

SHA-256:
cec6aba32a0243bf2b0b48d147df96ccb2b50ec5b9ec161dc1cc1c0d4f30eee1
```

The credited V3 clean-suite record must establish:

```text
5057 collected
5057 passed
0 failures
0 errors
0 skips
0 xfails
0 warnings
empty stderr
exact retained-node mapping
complete indexed source pre fingerprint
complete indexed source post fingerprint
source pre == post
complete indexed external-repository pre fingerprint
complete indexed external-repository post fingerprint
external pre == post
clean committed tree ==
52e32a55dc2e6b023b669810fb244301807f7618
candidate-mutated false
fully external object database
no source index/object-database mutation
```

V3 must also bind its clean suite to the credited V2 live suite and retained
final node list.

FAILED/HISTORICAL VALIDATION ROOTS

Verify and preserve unchanged:

```text
V1 reset preflight failure:
/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset.dwDBSw
index SHA-256:
15144abc491fb349433810e8ab6324f2b3034b62706f8bc4377dce63e6f2a32f

provenance diagnostic:
/private/tmp/ge-coordinator-rw0-b2-provenance-diagnostic.SsN1jd
index SHA-256:
10677d9d82b6fa342a5369b8768b38ed0c699f8f7ae547745a1bc685b170defa

failed commit gate:
/private/tmp/ge-coordinator-rw0-b2-capability-commit-gate.ECxUPx
index SHA-256:
a944cf428eb753b568864e313402088d40474d764a280d8a4bc88ca65ca13dc5

three-state diagnostic:
/private/tmp/ge-coordinator-rw0-b2-capability-commit-state-diagnostic.2SxEgB
index SHA-256:
54c0c7fadf3f44b10f6ec59c056c2f800abdf9d0c4baac911c48732dd5f9f2cb
```

These roots are noncredited historical/process evidence except where the
three-state diagnostic provides the accepted pre-repair causal counterexample.

PRE-REPAIR ACCEPTED AUDIT

Verify and preserve:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-independent-audit.T0I7mV

index SHA-256:
e09add54af9a8d6e48969fd06a0c0e57bc2bf9125229f1f811c6781303c2cb54
```

It is the accepted baseline before the one-file commit-compatibility repair.

EXACT RECIPE SOURCE

Locate the exact retained recipe source through the final repair index.

Require:

```text
type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Do not decode or reconstruct recipe source from prompt text.

Create a verified root-local mode-0400 execution copy beneath the neutral audit
root before invocation. Run the exact source twice with source bytes unchanged
and only its fixed external historical output sink safely redirected.

PROVENANCE GATE

Before correctness inspection or audit subagents:

1. create one new neutral audit root:

   ```text
   /private/tmp/g4.XXXXXX
   ```

2. safely `lstat` all retained-evidence path components;

3. verify every referenced self-excluding index exactly;

4. independently inventory all referenced roots and compare them again at
   closeout;

5. verify exact repository identity and `30/24/6/0/0` topology;

6. locate the indexed final canonical manifest;

7. require canonical JSON, file count 30, and SHA-256
   `0919e82038367f54defd36171a19550873f38acae714bd7398e5a56b2fb8d77a`;

8. verify every manifest entry by classification, regular-file type, mode,
   size, and SHA-256;

9. verify no thirty-first changed path;

10. verify every path outside the manifest equals HEAD;

11. verify the exact retained recipe source and root-local copy preflight;

12. execute the recipe twice with safe sink redirection;

13. require both manifests to equal the retained final manifest byte-for-byte;

14. require both complete outputs to equal the indexed retained final outputs;

15. recover and require the tracked textual-diff identity;

16. load and verify the accepted pre-repair manifest;

17. prove exactly one authorized repository path changed and the other 29
    entries remained exact;

18. verify:
    - final node list;
    - 43-row projection;
    - no-status and stable-contract mutant records;
    - three-state records;
    - V2 live-suite envelope;
    - V3 clean-suite envelope;
    - V2/V3 validation-binding comparison;
    - final guards and cleanup;
    - all evidence indexes;

19. verify all explicitly protected source/docs/public surfaces.

On any candidate or mandatory evidence mismatch, stop before correctness
inspection and return:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not approximate, regenerate, or silently repair missing evidence.

EXPLICITLY PROTECTED BY THIS REPAIR

These must equal the pre-repair accepted target:

```text
all .docs files
all production source
src/ge_nwp_coordinator/__init__.py
pyproject.toml

tests/test_rw0_b1_boundaries.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py

all SQL, migrations, schemas, catalogs
StateStore
WriterSession
package exports
dependency metadata
```

ACCEPTED ARCHITECTURE — DO NOT REOPEN BY INERTIA

Preserve:

- B1, Wire, and Capability production semantics;
- embedded B1 and RW0 registries;
- prose authority policy A;
- one-way B1 projections from RW0;
- retirement of arbitrary prose semantic inference;
- canonical B1/RW0 parser architecture;
- corrected migration evidence;
- all identities, canonical bytes, budgets, qualification/result precedence,
  and import direction;
- no source authentication, executable permission, semantic acceptance,
  persistence, provider/runtime/Git/publication authority;
- C/D/E and ES later/external owner seams.

AUDIT PERSPECTIVES

After the provenance gate, use exactly four bounded, non-nesting, read-only
perspectives when available. No child runs tests or modifies files.

1. Permanent-test and no-status-dependency auditor
   - inspect the changed test and complete helper call graph;
   - verify no direct/indirect Git dirty/staged/untracked query;
   - inspect the finite no-status guard;
   - run independent direct/detached/diff/count/clean-branch mutants;
   - verify no stable contract was removed.

2. Stable 43-row projection auditor
   - exact row inventory/order/values/purposes;
   - independence from Git state;
   - non-circular expectations;
   - path/type/mode/protected-content/import/export/caller/dependency/schema/
     migration/authority coverage;
   - independent stable-contract mutants;
   - projection equality across unstaged/staged/clean states.

3. Three-state and dual-suite validation auditor
   - independently reproduce target behavior in A/B/C states;
   - verify B/C tree
     `52e32a55dc2e6b023b669810fb244301807f7618`;
   - inspect V2 live and V3 clean complete run envelopes;
   - verify run-local pre/post fingerprints;
   - verify V3 path-safety preflight and external object isolation;
   - verify exact JUnit/node mapping and no hidden retry.

4. Provenance, public-boundary, and authority auditor
   - exact one-entry delta and 29-entry equality;
   - all evidence-root indexes and continuity;
   - imports, exports, callers, protected bytes;
   - no document/source/public/authority widening;
   - remaining C/D/E/ES seams.

The parent performs reconciliation, independent external simulations, node
comparison, validation, and closeout. Preserve disagreements.

Every finding must include:

```text
ID
type
severity: critical | high | medium | low | observation
current contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect or pre-existing issue
```

REQUIRED SOURCE AND TEST INSPECTION

Inspect the sole changed file completely:

```text
tests/test_rw0_b2_capability_boundaries.py
```

Inspect every helper and constant in its reachable call graph.

Inspect protected adjacent tests and owners needed for non-regression:

```text
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py
tests/test_remote_worker_pre_execution_planning_contract.py

.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-capability.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md

src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml
```

Inspect additional Coordinator files only for a concrete dependency and record
why. Do not inspect another repository.

HYPOTHESIS A — NO TRANSIENT GIT-STATUS DEPENDENCY

Independently prove or falsify:

1. The permanent target test no longer asserts any exact dirty, staged,
   modified, tracked, or untracked count.

2. Its entire local/transitive helper call graph does not invoke or parse:

   ```text
   git status
   git diff
   git diff --cached
   git ls-files --others
   porcelain status
   staged/untracked counts
   clean/dirty branch conditions
   ```

3. No subprocess wrapper, shell command, GitPython/dulwich call, detached
   helper, or indirect command builder reintroduces the dependency.

4. The finite call-graph guard kills equivalent command construction, not only
   one literal spelling.

Run external mutants:

```text
direct git status --porcelain
detached helper running git status
git diff --name-only
git diff --cached
git ls-files --others
staged/untracked count branch
clean/dirty porcelain branch
constructed argv fragments
shell-string equivalent
```

The checked tests must reject each for the intended no-status rule.

HYPOTHESIS B — STATE-INDEPENDENT 43-ROW PROJECTION

Recover the exact 43-row projection.

Require:

- exact finite inventory/order/value/purpose;
- no row derives from Git status/diff;
- no circular expected-value derivation;
- every stable pre-repair contract remains represented;
- no transient patch-scope fact;
- no duplicate row or purpose;
- same projection in A/B/C states.

Run independent mutants:

```text
remove required row
duplicate row
wrong path
wrong mode
regular-to-symlink
package-root export
production importer
dependency/schema/migration marker
weakened protected-content assertion
one status-derived row
```

Require rejection for the intended stable invariant.

HYPOTHESIS C — THREE-STATE TARGET

Independently reproduce:

### A

Live accepted unstaged candidate.

### B

Unique external `GIT_INDEX_FILE`, initialized from accepted HEAD, staging
exactly the final 30 manifest paths. Do not alter the real index.

### C

Fully external local repository/object database, accepted base plus exact final
candidate, one diagnostic commit, clean worktree/index.

Require:

```text
target passes A
target passes B
target passes C
projection A == projection B == projection C
B staged tree == C committed tree
B/C tree ==
52e32a55dc2e6b023b669810fb244301807f7618
source real index unchanged
source object database unchanged
```

Pre-screen every child-visible clean path with the exact privacy/path checker.

HYPOTHESIS D — VALIDATION BINDING

Verify the credited pair:

```text
V2 live suite:
5057/5057
complete source pre/post fingerprints
pre == post

V3 clean suite:
5057/5057
complete source pre/post fingerprints
complete external pre/post fingerprints
source pre == post
external pre == post
fully external objects
tree ==
52e32a55dc2e6b023b669810fb244301807f7618
```

Require:

```text
live JUnit nodes == retained final list
clean JUnit nodes == retained final list
live JUnit nodes == clean JUnit nodes
zero duplicates/unmapped
no hidden retries
candidate-mutated false
```

Verify V2 clean failure is correctly classified as historical harness-path
failure and does not receive validation credit.

NODE IDENTITY

Run one candidate collection and one clean external `git archive HEAD`
collection under identical isolated conditions.

Require:

```text
candidate:
5057 unique nodes

candidate ordered-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

clean HEAD:
4655 unique nodes

clean HEAD ordered-list SHA-256:
f36822a60056ec3d110956de561202b737662c9d22cd0dd82c4cdad6c7cef69f
```

Compare the pre-repair accepted list:

```text
5057 nodes
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe
```

Require no opening-to-final node change unless explicitly recorded. The repair
report claims exact node identity.

INDEPENDENT VALIDATION

Only after source/helper inspection, external mutants, three-state simulation,
and validation-envelope inspection are green enough, run serially beneath the
neutral audit root.

For every pytest child:

```text
umask 022
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct neutral external PYTHONPYCACHEPREFIX
distinct neutral external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct neutral external --basetemp
distinct neutral external --junitxml
serial execution
```

Pre-screen every path visible to the child with the owning path-safety checker.

Run:

1. exact retained selected causal set;
2. Capability boundaries:
   ```text
   tests/test_rw0_b2_capability_boundaries.py
   ```
3. Capability complete:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   ```
4. B1/Wire compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
5. architecture/status/static:
   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

Every credited run must have:

```text
return code 0
zero failures/errors/skips/xfails/warnings
empty stderr
parseable JUnit
zero duplicate/unmapped cases
matching caller/child umask
unchanged candidate fingerprint
```

If all inspection and focused validation remain green, independently run:

1. one complete live-candidate suite;
2. one complete fully external neutral-path clean-commit suite.

Require each:

```text
5057 collected
5057 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

The two suites are distinct state validations, not retries.

If a deterministic material blocker is found first, both full suites may be
withheld. State that explicitly. Never repair candidate bytes.

PUBLIC, IMPORT, PRIVACY, AND AUTHORITY BOUNDARY

Require:

- no document change;
- no production source change;
- no package-root export;
- no reverse import;
- no production caller change;
- no dependency, SQL, migration, schema, catalog, StateStore, or WriterSession
  change;
- no filesystem, process, network, provider, Bridge, ES-call, Git,
  publication, or runtime effect;
- accepted registries, parsers, migration architecture, and authority facts
  unchanged;
- Capability remains private pure supplied-fact semantics;
- source refs/digests remain unauthenticated evidence;
- no executable permission, semantic acceptance, persistence, or runtime
  authority;
- C/D/E and ES remain later/external owners.

CLOSEOUT

After removing only audit-created transient artifacts:

1. rerun the exact recipe twice with safe sink redirection;
2. require exact equality to the opening final target;
3. require the same manifest, complete output, textual diff, file count,
   per-path hashes, and topology;
4. compare all retained evidence-root opening/closing inventories;
5. verify source real index/object database unchanged;
6. verify no operation, lock, staged/unmerged path, cache, bytecode, database,
   journal, archive, build, recorder, or generated-manifest residue;
7. retain all audit evidence beneath the neutral mode-0700 root;
8. make retained audit files regular, operator-owned, and mode 0400;
9. create a self-excluding evidence index.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low candidate defect remains;
- `BLOCK` for any repairable permanent-test, projection, state-compatibility,
  evidence, validation, privacy, public-boundary, or authority defect;
- `REJECT` only for a fundamental accepted-architecture contradiction;
- `AUDIT_PROVENANCE_MISMATCH` only for target/evidence identity failure before
  correctness judgment.

If `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_TEST_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or create a PR.

FINAL REPORT

Include:

1. opening and closing identity;
2. exact provenance and one-entry delta;
3. all retained evidence indexes and continuity;
4. four audit perspectives and disagreements;
5. severity-ranked finding ledger;
6. no-status-dependency result and mutant ledger;
7. 43-row projection result and stable-contract mutants;
8. three-state target result and B/C tree equality;
9. V2 live/V3 clean validation-binding result;
10. independent focused/live/clean validation;
11. node comparison;
12. public/import/privacy/authority assessment;
13. closeout guards;
14. separate provenance, validation, and implementation confidence.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
