PROMPT_ID

RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_VALIDATION_EVIDENCE_RESET_V1

TITLE

Coordinator RW0-B2-Capability — no-mutation validation-evidence reset for the
completed owner-oracle audit-findings repair

ENGAGEMENT TYPE

Parent-only validation and closeout continuation in the same write-enabled
Capability implementation conversation.

Repository mutation is not authorized.

Do not edit, format, generate, delete, rename, chmod, or otherwise alter any
repository path. Do not rerun implementation, test-first red controls,
development mutation probes, or historical failed/superseded attempts.

This engagement creates one new external evidence root, reruns only the final
credited validation sequence against the unchanged candidate, reproduces final
provenance, and emits a complete audit-grade closeout.

Do not stage, commit, push, create a PR, merge, tag, release, deploy, contact a
remote/service/provider/host, invoke a product worker/model, mutate a database,
install dependencies, or inspect a supporting repository.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Supersede the incomplete historical attempt envelopes with one clean,
self-contained, final-byte-bound validation evidence set.

The repository repair is complete and must remain byte-identical.

Generate complete exact records for:

1. opening identity and provenance;
2. selected final causal tests;
3. final focused validation groups;
4. final node collection;
5. corrected migration/rename reconciliation;
6. one complete repository suite;
7. final guards and cleanup;
8. two exact final provenance runs;
9. a complete closeout report;
10. a self-excluding evidence index created last.

Do not claim to reconstruct exact metadata for incomplete historical attempts.
Classify those prior records as noncredited historical partial evidence and
reference their retained roots. The new reset becomes the authoritative final
validation envelope.

OPENING REPOSITORY IDENTITY

Before creating the new evidence root require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644
```

Require:

- `git diff --check` clean;
- cached diff check clean;
- no Git operation or lock;
- no candidate symlink or special file;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, or recorder residue.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

FINAL CANDIDATE TARGET

The live candidate is already bound to the retained final repair target.

Retained repair evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-findings-repair.ZRLt3w
```

Required repair evidence index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-findings-repair.ZRLt3w/evidence_index.jsonl

rows:
375

size:
66414 bytes

SHA-256:
6de9b6295a2701a55bf496f2fe644f1c8be91b4314a67d84f3598c3a791e95b7
```

Required current final identities:

```text
final canonical-manifest size:
6430 bytes

final canonical-manifest SHA-256:
51b6adfdd88d538e26b7166681465fbb27abf467ec1e5936b646437e58d9f58b

final complete recipe-output size:
6663 bytes

final complete recipe-output SHA-256:
9e9a3582ae6109184593a1c68aff584ffe3f172f1db471b70ad2a20dee7d7bce

final pytest node count:
5051

final ordered-node-list SHA-256:
5e2a6c5f9e603895b9f9daf021ccc36a9915a8b923ddb7fe8c287b49325bb1aa

full-suite JUnit size:
1046623 bytes

full-suite JUnit SHA-256:
5473e80cb7dda254bc4c49281917d0c8b57509cd08d4b35078cbc71c551a4e54

corrected migration ledger:
384 records

corrected migration-ledger SHA-256:
7dfce2479a0a7e72b37dc2af0181bf2dbf2e11ec209432a5b551ee4057f2a87e
```

Required live repaired path identities:

```text
tests/test_rw0_b1_boundaries.py
34249 bytes
SHA-256:
4d7fb14a71cb1c27f754566c4ac80dcc066b1f491f648fec3cbdb149b1ab6cd5

tests/test_rw0_remote_contact_phase_entry_contract.py
160517 bytes
SHA-256:
2e37bb85fddad2c2212fbe598ff0e2cd553278f1234911ce5b6d34f1c8a90efd
```

Required opening-repair identities for those paths:

```text
tests/test_rw0_b1_boundaries.py
31566 bytes
SHA-256:
52f7e8ec53847406d967784dad17c87d7a07ce9ce04f8fd32a6e112f8268b257

tests/test_rw0_remote_contact_phase_entry_contract.py
153112 bytes
SHA-256:
a073fa62d7b69937b2b1babb3a0e199294604bb7b10fd8c91356e5bf2a1fcfd1
```

The other 28 candidate entries must match the retained opening and final
manifests exactly. Every path outside the 30-path candidate must equal HEAD.

PRE-EXISTING EVIDENCE ROOTS — READ-ONLY

Preserve without modification:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB

/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3

/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-findings-repair.ZRLt3w
```

Required indexes:

```text
implementation:
185d17a6332a49b545f50c5e7c33a4e1f6e1150fa799c547dbec40876b643e16

audit:
26b69c39d083cd2096c8e2b47c6afbef7626d24cbd55093fcabe659be23a06bb

repair:
6de9b6295a2701a55bf496f2fe644f1c8be91b4314a67d84f3598c3a791e95b7
```

Safely `lstat` each path component and verify every self-excluding index before
validation. Record opening tree fingerprints for all three roots and require
exact equality at closeout.

EXACT RECIPE SOURCE

Locate the exact retained recipe source through the repair evidence index.

Require:

```text
type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Use the exact source unchanged. Safely redirect only its fixed external
historical output sink to evidence-root-local unique files. Preserve wrapper
source and exact identity. Do not alter Git queries, stdout, canonical JSON, or
any other recipe behavior.

NEW EVIDENCE ROOT

Create exactly one new top-level evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-validation-reset.XXXXXX
```

Requirements:

- operator-owned;
- non-symlink;
- mode 0700;
- no sibling validation-reset root created by this engagement;
- subdirectories mode 0700;
- retained regular files mode 0400 at closeout;
- no symlink, FIFO, socket, device, or special entry;
- all temporary paths remain below this root;
- no repository-local temporary path.

RECORDER REQUIREMENTS

Before candidate validation, create and retain one external recorder under the
new evidence root.

The recorder must write a complete attempt envelope unconditionally for every
command, including:

- success;
- nonzero return;
- signal;
- refusal;
- preflight stop;
- missing target;
- command not launched;
- JUnit absent/not applicable;
- wrapper/tooling failure.

Each attempt gets one immutable label and one directory.

The envelope schema must include at least:

```text
schema_id
label
purpose
credit_classification
exact argv as JSON array
working directory
exact environment allowlist
unset environment variables
Python executable path
Python realpath
Python version
Python implementation
platform
caller umask
child umask or explicit not-launched
wall-clock start/end UTC
monotonic start/end ns
duration ns
child PID or not-launched
return code
terminating signal
stdout path/size/SHA-256
stderr path/size/SHA-256
JUnit applicability
JUnit path/size/SHA-256
JUnit parse status
collected/passed/failed/error/skipped/xfail/xpass/warning counts
duplicate JUnit identities
unmapped JUnit cases
ordered node-list path/count/SHA-256 when applicable
repository fingerprint before
repository fingerprint after
staged/index fingerprint before/after
candidate-mutated boolean
notes
```

Requirements:

- envelope written atomically;
- envelope retained even if the child never launches;
- stdout and stderr always retained, including zero-byte files;
- no failure path may skip the envelope;
- no record may be added after final index creation.

Run one recorder self-test with a trivial external command before repository
validation. The self-test is tooling evidence, not candidate validation. If it
fails, stop without launching candidate validation.

HISTORICAL ATTEMPT POLICY

Do not rerun or recreate:

```text
opening_gate_initial_tooling
opening_gate
opening_collection_launcher_error_001
repair_parser_green_001
development_rw0_owner_001
pre_suite_guard_run
transient_cleanup_initial
transient_cleanup
final_closeout
```

Preserve their existing evidence.

In the new closeout report classify them as:

```text
historical partial/noncredited implementation-attempt evidence
not exact enough for strict complete-history reporting
superseded for final validation authority by this new clean validation reset
```

Do not fabricate their missing timing, argv, environment, return code, JUnit,
or fingerprint fields.

OPENING VALIDATION GATE

Record a complete envelope for one opening gate that verifies:

1. exact repository identity;
2. topology `30/24/6/0/0`;
3. path types and modes;
4. clean `git diff --check`;
5. clean cached diff check;
6. no operation/lock/residue;
7. current two repaired path hashes;
8. other 28 candidate entries equal retained manifest;
9. outside-candidate paths equal HEAD;
10. pre-existing evidence indexes/fingerprints;
11. exact recipe source;
12. two opening recipe executions;
13. both manifests equal the retained final manifest;
14. both complete outputs equal the retained final complete output;
15. opening node list identity from retained evidence.

This is one fully recorded read-only attempt. If it fails, stop.

VALIDATION ENVIRONMENT

For every pytest child:

```text
umask 022 before launch
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
ordinary quiet rendering unless exact retained selected argv specifies otherwise
```

Before and after every run require an exact repository/candidate fingerprint.
No candidate byte may change.

FINAL VALIDATION SEQUENCE

Run each label exactly once. No repair or retry is authorized in this
engagement.

## 1. selected_causal_final

Recover the exact retained final selected-causal argv from the repair evidence
root. Require the retained source record to identify 53 selected pytest cases.

Run that exact selected set against current bytes.

Expected:

```text
53 collected
53 passed
0 failures
0 errors
0 skips
0 xfails
0 warnings
empty stderr
```

If the retained exact argv cannot be recovered, stop with evidence-reset
failure. Do not approximate the case list.

## 2. b1_owner_final

Run exactly:

```text
tests/test_rw0_b1_boundaries.py
```

Expected:

```text
132 collected
132 passed
```

## 3. rw0_owner_final

Run exactly:

```text
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Expected:

```text
189 collected
189 passed
```

## 4. b1_compatibility_final

Run exactly:

```text
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_boundaries.py
```

Expected:

```text
448 collected
448 passed
```

## 5. capability_wire_compatibility_final

Run exactly:

```text
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
```

Expected:

```text
67 collected
67 passed
```

## 6. architecture_status_static_final

Run exactly:

```text
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py
tests/test_remote_worker_pre_execution_planning_contract.py
```

Expected:

```text
907 collected
907 passed
```

## 7. final_collection

Run one complete collection:

```text
python3 -B -m pytest -p no:cacheprovider -W error --collect-only -q
```

with the required external basetemp/JUnit paths and environment.

Expected:

```text
5051 unique nodes

ordered SHA-256:
5e2a6c5f9e603895b9f9daf021ccc36a9915a8b923ddb7fe8c287b49325bb1aa
```

Compare byte-for-byte with the retained final node list.

## 8. rename_reconciliation_final

Use the exact retained corrected migration ledger and a retained/read-only
checker copied byte-for-byte into the new evidence root.

Require explicit sole rename:

```text
old_node_id:
tests/test_rw0_b1_boundaries.py::test_owner_has_one_current_retrieval_maximum_and_one_current_consumer

new_node_id:
tests/test_rw0_b1_boundaries.py::test_b1_live_registry_projection
```

Require:

- old once opening, absent final;
- new absent opening, once final;
- new once among additions;
- one rename record targets new;
- no shared endpoints;
- all 384 opening owner nodes have one ledger record;
- exact migration arithmetic;
- corrected ledger count 384;
- corrected ledger SHA-256
  `7dfce2479a0a7e72b37dc2af0181bf2dbf2e11ec209432a5b551ee4057f2a87e`.

Record a complete attempt envelope even though this is not pytest.

## 9. full_suite_final

Run the complete repository suite exactly once:

```text
python3 -B -m pytest -p no:cacheprovider -W error -q
```

with external basetemp/JUnit paths.

Expected:

```text
5051 collected
5051 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

Require:

- JUnit parseable;
- 5,051 unique JUnit case identities;
- zero duplicate/unmapped cases;
- JUnit identities map exactly to the final collected node list;
- candidate fingerprint unchanged.

No second complete-suite attempt is authorized.

FINAL GUARDS AND PROVENANCE

After validation:

1. run one fully recorded final guard attempt covering:
   - `git diff --check`;
   - cached diff check;
   - status/topology/name-status/modes;
   - no operations/locks/residue;
   - current two repaired path hashes;
   - other 28 candidate entries equal retained manifest;
   - outside-candidate paths equal HEAD;
   - package/export/import/public/authority guards;
   - pre-existing evidence roots unchanged;

2. remove only new validation-reset transient basetemps, caches, pycache roots,
   and temporary directories after their retained outputs are sealed;

3. retain one cleanup record with exact removed paths, types, and pre/post
   inventory;

4. run the exact recipe twice after cleanup using safe sink redirection;

5. require:
   - both manifests byte-identical;
   - both equal the retained final manifest;
   - both complete outputs byte-identical;
   - both equal the retained final complete output;
   - empty stderr;
   - unchanged repository fingerprint;

6. record final manifest comparison and complete-output comparison in complete
   attempt envelopes.

CLOSEOUT REPORT

Generate a complete final report from:

- retained historical roots;
- this new validation-reset root;
- current live read-only Git/filesystem evidence.

The report must explicitly say:

- historical partial attempt metadata was not reconstructed;
- those attempts are noncredited and superseded for final validation authority;
- current repository bytes equal the retained repaired target;
- the clean reset sequence is the credited validation authority.

Include:

1. opening/final repository identity;
2. live-byte binding;
3. pre-existing evidence-root verification;
4. historical partial-attempt classification;
5. every new attempt envelope;
6. selected causal result;
7. every focused group result;
8. final collection and exact node identity;
9. corrected migration/rename result;
10. full-suite result;
11. guards and cleanup;
12. double final provenance;
13. exact final canonical manifest JSON;
14. protected/public/authority non-widening;
15. remaining C/D/E/ES seams;
16. separate provenance, validation-binding, and implementation confidence.

SELF-EXCLUDING EVIDENCE INDEX

Create the index last.

Requirements:

- no file or directory added, removed, modified, or chmodded after indexing;
- index excludes itself;
- canonical JSONL;
- one row per retained file/directory;
- relative path, type, owner, group, mode, size;
- SHA-256 for regular files;
- no symlink/special entry;
- externally verify every indexed row after writing the index;
- retain external index-verification output outside the indexed root or as the
  final pre-index source whose result is embedded in the closeout report;
- report row count, byte size, and SHA-256.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_AUDIT_FINDINGS_REPAIR_VALIDATION_EVIDENCE_RESET_COMPLETE_READY_FOR_FRESH_REAUDIT
```

only when:

- repository bytes remain unchanged;
- every new attempt has a complete envelope;
- all focused groups pass;
- final collection is exactly 5,051 nodes;
- rename reconciliation passes;
- the one full suite passes 5,051/5,051;
- final guards pass;
- double final provenance matches the retained repaired target;
- complete closeout and self-excluding index are sealed.

FAILURE TOKENS

If any candidate validation fails, return:

```text
VALIDATION_EVIDENCE_RESET_BLOCKED
```

If opening identity/provenance differs, return:

```text
VALIDATION_EVIDENCE_RESET_PROVENANCE_MISMATCH
```

If exact retained argv, node list, migration ledger, or recipe source is
missing, return:

```text
VALIDATION_EVIDENCE_RESET_INPUT_INCOMPLETE
```

Do not modify repository bytes in any failure case.

FINAL REQUIRED STATEMENTS

```text
REPOSITORY_MUTATION_NOT_PERFORMED
IMPLEMENTATION_NOT_RERUN
TEST_FIRST_RED_NOT_RERUN
MUTATION_PROBES_NOT_RERUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
