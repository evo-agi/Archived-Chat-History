## Engineering disposition

**The reconciled Capability freeze is implementation-ready. Proceed with one parent-only workspace-write tranche.**

The response closes the four gaps that blocked implementation:

- full non-recursive reconstruction now has a concrete helper graph;
- work accounting is internally consistent at `48/62/52`, `72/93/78`, `249`, and composed `490`;
- every qualification reason has an exact predicate and precedence;
- hostile mapping closure and the fixed Wire-owner seam are deterministic and non-substitutable.

The 20-path ceiling is also credibly closed. The two specifically challenged tests remain protected because the new module imports no development-row module and does not interact with the Codex-agent configuration surface.

I added one implementation-level hardening to the handoff: **declared field attribute access must use the same `3V` safe-reconstruction boundary as the named public methods**. Otherwise, an incomplete or tampered exact-class instance could expose an unreconstructed tuple member through attribute access even though its methods and relation fail closed. This does not change schemas, fields, identities, ownership, or the touched-file ceiling.

## Implementation handoff

Change the existing Capability Codex conversation to **workspace-write**, then send this complete prompt:

:chatgpt-content-reference{index="3"}

Verify the artifact:

```text
Filename:
Coordinator_RW0_B2_Capability_Parent_Only_Implementation_Prompt.txt

Size:
51,846 bytes

SHA-256:
47d577f217c1687ef384533ebdcb067bb37e1d52504fbe1f403ce298d4cefcce
```

The prompt is bound to:

```text
Baseline branch:
trunk_dev

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

Implementation branch:
codex/rw0-b2-capability-semantics-v1
```

It authorizes exactly:

```text
20 dirty paths
14 tracked modifications
6 untracked additions
0 staged
0 unmerged
```

and stops if a twenty-first path is required.

### Critical implementation gates

The handoff requires:

- tests and the Capability governing document before source implementation;
- a missing-module causal-red gate;
- exact declaration, observation, and qualification fields and identities;
- safe reconstruction for methods, attributes, equality, and the relation;
- exact Wire-profile loading once at module initialization;
- the complete B1 owner relation exactly once;
- literal test-owned result precedence and canonical vectors;
- class-wide reconstruction-bypass mutants;
- exact mapping-key and privacy precedence;
- new test nodes only in the four new Capability test files;
- one complete-suite run, with at most one governed repair rerun inside the same 20 paths;
- two byte-identical final provenance runs;
- no audit, staging, commit, push, PR, or runtime operation.

The required success token is:

```text
COORDINATOR_RW0_B2_CAPABILITY_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT
```

After that token, the next step is a **fresh read-only independent audit**, not a commit gate. The project protocol keeps reconnaissance and parent-only mutation in separate turns of one implementation conversation, then moves independent audit to a fresh conversation. 

The tranche preserves the accepted architectural order: Wire is already the fixed protocol dependency, while Capability adds only provider-neutral declaration, supplied observation, and pure qualification; concrete CLI/App Server mechanics remain later-owned. 

### Sources

- Codex Capability schema-freeze reconciliation supplied in this turn.
- Parent-only implementation and later fresh-audit operating pattern. 
- Implementation closeout and provenance requirements. 
- Accepted Wire-before-Capability order. 

**Confidence:** High that the schema and authority split are ready for implementation; high that the 20-path surface is sufficient; medium-high that the full suite will remain within that ceiling, with the principal residual risks being causal reconstruction tests, exception-context hygiene, and synchronized Markdown owner/status oracles.
