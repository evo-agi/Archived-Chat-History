PROMPT_ID

RW0_B2_WIRE_NODE_PLACEMENT_CONTINUATION_V2_2026-09-18

SUPERSESSION AND ATTACHMENT CHECK

This complete prompt supersedes the original RW0-B2-Wire implementation prompt
for the current turn.

Do not use any prompt that requires:

- a clean `trunk_dev` checkout;
- creation of `codex/rw0-b2-wire-protocol-v1`; or
- an absent feature branch.

The required opening state is the already-created feature branch with the
preserved 16-path dirty candidate.

If the received prompt instead describes a clean baseline or branch creation,
stop and report `WRONG_PROMPT_ATTACHMENT_RECEIVED`.

TITLE

Coordinator RW0-B2-Wire — repair existing-test node placement and resume the
bounded implementation validation

ENGAGEMENT TYPE

Parent-only workspace-write continuation in the existing
`codex/rw0-b2-wire-protocol-v1` implementation conversation.

Do not create or resume subagents. You remain the sole repository writer.

This continuation corrects one test-placement/node-identity defect exposed by
the mandatory candidate-collection gate. It does not reopen the accepted Wire
schema, profile, ownership, framing, classifier, privacy, bounds, touched-file
allowlist, or Capability disposition.

It is not an independent audit, commit gate, publication gate, or Capability
implementation.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

STOPPED STATE TO REQUIRE

Before any edit, require and record:

- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- upstream:
  `origin/trunk_dev`
- one worktree
- exactly 16 dirty paths:
  - 10 tracked modifications
  - 6 untracked additions
- zero staged and zero unmerged paths
- every candidate path regular mode `0644`
- no Git operation, lock, repository residue, or `git diff --check` error
- no remote contact since the stop
- evidence root retained unchanged:
  `/private/tmp/rw0-b2-wire.H4lagH`

Verify that the current 16-path bytes equal the candidate bytes bound to the
retained candidate-collection evidence. Use the retained per-path repository
fingerprint or equivalent exact before/after collection record. Do not infer
byte equality from path count alone.

Stop before mutation if:

- the retained evidence does not bind the current candidate bytes;
- any candidate path, mode, size, hash, or classification differs;
- any seventeenth path is dirty;
- the branch, HEAD, tree, upstream, or worktree posture differs.

PRESERVE PRIOR EVIDENCE

Do not overwrite or delete:

- opening collection;
- opening provenance;
- candidate-collection attempt 001;
- collection stdout/stderr/JUnit or structured metadata;
- repository fingerprints;
- any other retained predecessor evidence.

Create a separate external continuation evidence root under `/private/tmp`,
operator-owned, non-symlink, mode `0700`.

ENGINEERING DISPOSITION

The stopped candidate is not rejected on semantics or touched-file scope.

The collection rule remains authoritative:

- all opening node IDs must remain;
- opening order must remain a subsequence;
- existing test files must not introduce new collected node IDs;
- all new node IDs belong to the four new Wire test files.

The three added tests in existing files are therefore a bounded
test-placement defect, not a reason to weaken the node gate.

Do not accept the three extra existing-file nodes merely because their paths
are allowlisted. Preserve their assertions by composing them into existing
owner tests.

AUTHORIZED REPAIR PATHS

For this node-placement repair, modify exactly these three existing candidate
paths and no others:

```text
tests/test_architecture_contracts.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_software_development_progression_boundary.py
```

The other thirteen candidate paths must remain byte-identical during this
repair.

REMOVE EXACTLY THESE THREE NEW TOP-LEVEL TEST NODES

```text
tests/test_architecture_contracts.py::test_rw0_b2_wire_private_source_status_has_no_authority_claim

tests/test_rw0_remote_contact_phase_entry_contract.py::test_rw0_b2_wire_current_status_projection_is_synchronized

tests/test_software_development_progression_boundary.py::test_rw0_b2_wire_does_not_widen_progression_authority
```

Do not delete their substantive assertions.

COMPOSE THEIR ASSERTIONS INTO EXISTING NODES

1. Architecture

Move the Wire private-source/no-authority assertions and their causal negative
controls into the pre-existing architecture/current-status boundary node that
owns private-source capability and authority non-widening.

Require that the existing node still proves:

- Wire is private and no-I/O;
- no package/public/StateStore/WriterSession widening;
- no contact, worker, process, persistence, authority, acceptance, or
  Capability implementation;
- profile evidence is not authority;
- B1 remains unchanged;
- RW0-C/D/E and ES retain their ownership.

2. RW0 owner and synchronized projections

Move the Wire current-status projection assertions into the pre-existing RW0
owner/cross-reference structural oracle or current-status region test that owns
the relevant five-document visible Markdown projection.

Preserve all required structural causality:

- unique intended heading owner/range;
- one visible unfenced marker pair;
- all live prose inside the pair;
- hidden fenced duplicates ignored;
- duplicate visible blocks rejected;
- same-title sibling relocation rejected;
- leading/trailing visible prose outside markers rejected;
- backtick and tilde controls;
- no raw global `count`, `find`, `index`, or regex-only owner extraction;
- normalized projection equality;
- exact profile ref/digest and all nonclaims.

3. Progression boundary

Move the Wire non-progression/non-authority assertions into the pre-existing
progression-boundary node that owns the current private/no-runtime boundary.

Preserve proof that B2-Wire:

- adds private pure source only;
- advances no durable progression;
- authorizes no worker/process/contact;
- implements no semantic terminal fact or acceptance;
- leaves Capability, C, D, E, ES, Git, and publication outside the tranche.

TEST-INTEGRITY RULES

- Do not rename, remove, reparameterize, redecorate, skip, xfail, or change the
  collection identity of any opening node.
- Do not add a new top-level test, class, parameter case, or generated node in
  any existing test file.
- Do not weaken or remove a mutant merely to satisfy collection.
- Keep every substantive assertion and causal control from the three removed
  nodes.
- A simple assertion paste without integration into the owning structural
  oracle is insufficient.
- No production or documentation byte may change during this repair.

CANDIDATE COLLECTION ATTEMPT 002

After the three-file repair, and before any focused pytest run, execute one new
isolated candidate collection exactly once.

Retain candidate-collection attempt 001.

Attempt 002 must establish:

```text
opening nodes:       4,566
candidate nodes:     4,626
net additions:       60
removed:             0
renamed:             0
duplicates:          0
```

All 60 additions must belong to exactly these four new files:

```text
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

Every opening node must remain in the same relative order.

The three listed existing-file candidate-only nodes must be absent.

Require exact node-list evidence, literal set/order comparison, and repository
fingerprints before and after collection.

Stop immediately if attempt 002 is not exact. Do not perform another collection
or further mutation.

POST-COLLECTION NODE FREEZE

After attempt 002 passes:

- collected node identities are frozen;
- no later repair may add, remove, rename, reparameterize, redecorate, skip, or
  xfail a test;
- later in-scope repair may change test bodies or source/docs only while
  preserving the exact 4,626-node collection;
- if any later failure requires a node-identity change, stop for new direction.

RESUME THE ORIGINAL VALIDATION PLAN

After the corrected collection gate passes, continue the previously authorized
implementation validation in the original order.

Run serially under the original isolated evidence posture:

1. each of the four new Wire test files individually;
2. all four Wire test files together;
3. C2A compatibility:
   - `tests/test_worker_execution_semantic_*.py`
   - `tests/test_c2a_relations.py`
   - `tests/test_c2a_first_slice_semantic_protocol_contract.py`
   - `tests/test_c2a1_pure_semantic_values.py`
4. B1 compatibility:
   - `tests/test_rw0_b1_*.py`
5. static/public/import boundaries:
   - `tests/test_c2a_nonimplementation.py`
   - `tests/test_runtime_non_authority.py`
   - `tests/test_c2b2_development_row_value_boundaries.py`
   - `tests/test_b2a_writer_session_contract.py`
   - `tests/test_codex_agent_config.py`
6. status/document compatibility:
   - `tests/test_rw0_remote_contact_phase_entry_contract.py`
   - `tests/test_architecture_contracts.py`
   - `tests/test_software_development_progression_boundary.py`
   - `tests/test_remote_worker_pre_execution_planning_contract.py`
7. `git diff --check`;
8. exact 16-path/mode/topology/public/import/protected-byte/residue/operation/
   lock guards.

Every focused run must be exact-green:

- return code 0;
- zero failures, errors, skips, xfails, or warnings;
- empty stderr;
- no JUnit parse error;
- no duplicate or unmapped cases;
- equal caller/child numerical umask;
- unchanged candidate fingerprint before/after.

FOCUSED-FAILURE REPAIR

If a focused gate fails:

- preserve the failure evidence;
- repair only when causally attributable to this candidate;
- remain inside the exact original 16-path allowlist;
- preserve the accepted Wire contract/profile/caps/ownership;
- preserve all 4,626 node identities;
- do not weaken a test;
- rerun the affected focused gate and all dependent focused gates.

Stop if a repair requires:

- a seventeenth path;
- C2A/B1/public/schema/dependency/runtime change;
- a contract/profile/cap/ownership revision;
- a node-identity change;
- an unrelated mutation.

COMPLETE SUITE

After all focused gates are green and bytes are frozen, run complete-suite
attempt 001 exactly once under the original isolated recorder posture.

If attempt 001 is green, do not rerun it.

If attempt 001 fails:

- preserve all attempt-001 evidence;
- repair only when every failure is demonstrably caused by this candidate,
  remains inside the 16-path allowlist, preserves the frozen contract and exact
  4,626 node identities, and weakens no test;
- rerun every affected focused gate;
- run complete-suite attempt 002 exactly once.

No third full-suite attempt is authorized.

FINAL PROVENANCE AND CLOSEOUT

After exact-green validation:

- remove only continuation-created transient artifacts;
- require final topology:
  - 16 dirty paths
  - 10 tracked modifications
  - 6 untracked additions
  - 0 staged
  - 0 unmerged
- run the exact embedded provenance recipe twice;
- require byte-identical stdout and canonical manifests;
- require exactly the original 16-path allowlist and no other path;
- prove every protected path equals HEAD;
- retain complete evidence externally;
- do not perform an independent audit;
- do not stage, commit, push, create a PR, merge, tag, release, deploy, contact
  remotes, or implement Capability.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_WIRE_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT
```

only if:

- the node-placement repair is exact;
- candidate collection attempt 002 passes the corrected gate;
- all focused and complete-suite validation is exact-green;
- final provenance is stable and exact;
- no stop condition fires.

The report must distinguish:

- the retained failed collection attempt 001;
- the authorized node-placement repair;
- collection attempt 002;
- all validation attempts;
- final provenance, validation, and implementation confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
CANDIDATE_COLLECTION_ATTEMPT_001_PRESERVED
CANDIDATE_COLLECTION_ATTEMPT_002_RUN_EXACTLY_ONCE
```
