## Engineering disposition

**Accept the `BLOCK`. Do not stage or commit. Return to the existing workspace-write B2-Wire conversation for a strictly test-only repair.**

The audit found no production-runtime, protocol, authority, privacy, profile, parser, classifier, public-surface, or Capability defect. The remaining blockers concern whether the checked-in tests mechanically prove behavior that the auditor independently found correct.

That distinction matters. Wire was originally held at `PARTIAL` until integer admission, bounded work, error precedence, and process/result classification were frozen; those are no longer being reopened here. 

## Frozen repair decisions

### 1. Isolate every reachable C2A integer path

The current oversized-integer test corrupts command, attempt, and effect objects together. Because extraction begins with the command, the test can pass without ever exercising selective regressions in later classes.

The repair should:

- preserve the existing oversized-integer test node, but reduce it to one isolated `WorkerCommandV1.global_stop_version` case;
- add exactly one new, unparameterized test node;
- make that node iterate a **literal test-owned inventory of exactly 64 reachable integer paths** across:
  - `CeilingsV1`
  - `AttemptFenceV1`
  - `EffectFenceV1`
  - `WorkerCommandV1`
  - `DeliveryEnvelopeV1`
  - `WorkerObservationV1`;
- construct a fresh valid graph for each case;
- mutate one field in one exact object only;
- test both `MAX + 1` and a 1,000-digit integer;
- prove zero owner or Wire reconstruction, canonicalization, digest, or framing calls before rejection;
- explicitly prove `process_exit_code = -255`, `0`, and `255` remain accepted.

The final node count is therefore frozen at:

```text
4,655
```

with exactly one addition:

```text
tests/test_rw0_b2_wire_relations.py::test_every_reachable_c2a_integer_path_is_isolated_before_owner_or_wire_canonicalization
```

### 2. Make the pending-frame oracle independent

The 5,000-sibling test must use the literal bound:

```text
5
```

It must not compute that expectation from production `_CAPS`.

The same test must separately pin the complete result-cap tuple:

```text
(16_627, 4, 8, 77, 169, 66_770)
```

ordered as payload bytes, depth, containers, key pairs, scalar leaves, and hostile units.

A bounded broken control should demonstrate that a production-derived oracle would follow an inflated production depth while the independent literal remains `5`.

## Exact scope

Only these two untracked files may change:

```text
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_codec.py
```

Production source and governing documentation must remain byte-identical:

```text
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
.docs/rw0-b2-wire-protocol.md
```

The other 14 candidate files also remain byte-identical.

Because both repair files are untracked, the tracked textual-diff SHA-256 must remain:

```text
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6
```

A newly exposed production defect is a stop condition, not authorization to edit source under this prompt.

## Next action

Send this complete prompt to the **existing workspace-write RW0-B2-Wire conversation**:

:chatgpt-content-reference{index="3"}

Verify the attachment:

```text
Filename:
Coordinator_RW0_B2_Wire_Fourth_Audit_Test_Repair_Prompt.txt

Size:
22,671 bytes

SHA-256:
341ac32535ac567f8ff17a2ed8f5e59d66fedbb8e724f748cd596e3677cec7fe
```

The required success token is:

```text
COORDINATOR_RW0_B2_WIRE_FOURTH_AUDIT_TEST_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

After that result, the changed test bytes require another **fresh read-only independent audit**. Repairs belong in the write-enabled parent conversation; a later fresh conversation audits the new exact bytes.  Staging and commit remain prohibited until an audit accepts the candidate, after which the exact audited paths must be staged and compared blob-for-blob with the manifest before one commit. 

### Sources

- Codex fourth audit report supplied in this turn.
- Original Wire freeze boundary and unresolved design gates. 
- Governed repair and fresh-audit lifecycle. 
- Audited-byte commit-gate sequence. 

**Confidence:** High that production behavior should remain frozen; high that the two reported test defects are real; high that they can be closed entirely within the two-file test boundary.
