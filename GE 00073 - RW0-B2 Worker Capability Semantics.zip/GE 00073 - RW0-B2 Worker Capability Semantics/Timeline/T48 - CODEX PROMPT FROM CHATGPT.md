PROMPT_ID

RW0_B2_WIRE_SIXTH_AUDIT_TEST_REPAIR_V1

TITLE

Coordinator RW0-B2-Wire — repair the remaining F18 selective-bypass oracle
defect and prepare exact bytes for a fresh independent re-audit

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing
`codex/rw0-b2-wire-protocol-v1` implementation conversation.

Do not create or resume subagents. You are the sole repository writer.

This is a bounded **one-file test-only repair** after a fresh independent audit
returned `REJECT`. The audit independently closed F17 and found no production,
protocol, authority, privacy, parser, classifier, public-surface, or Capability
defect. The only open finding is F18: the checked-in selective Attempt guard
control records intended delegation but does not behaviorally prove that the
real non-selected integer checks executed.

Do not modify production source or governing documentation.

This is not reconnaissance, schema design, implementation redesign, Capability
implementation, independent audit, commit gate, publication gate, merge,
deployment, or runtime proof.

Do not stage, commit, push, create or modify a PR, merge, tag, release, deploy,
contact a remote, invoke a product worker/model/provider, modify a supporting
repository, or install dependencies.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Close exactly F18 by strengthening the existing non-parameterized 64-path test
so that:

1. a selected single AttemptFenceV1 integer check may be bypassed exactly once
   and reaches the selected Attempt owner boundary;

2. every non-selected Attempt integer check is behaviorally proved—not merely
   logged—to retain the real B2 upper-bound enforcement;

3. a class-wide Attempt bypass mutant deterministically fails the checked-in
   oracle before a later digest or relation mismatch can mask the missing early
   checks;

4. an unrelated EffectFenceV1 oversized case remains independently early
   rejected;

5. all existing F17 positive/negative coverage, the exact 64-entry inventory,
   all 4,655 node identities, and every production/document byte remain exact.

OPENING TARGET

Before any mutation, require exactly:

- physical root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- subject:
  `feat: implement RW0-B1 pure phase-entry semantics (#3)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- dirty paths:
  `16`
- tracked modifications:
  `10`
- untracked additions:
  `6`
- staged/unmerged:
  `0/0`
- every candidate path:
  regular mode `0644`
- no Git operation, lock, repository cache, bytecode, database, journal,
  archive, build, generated manifest, or recorder residue
- `git diff --check`:
  clean.

Immutable opening target:

```text
/private/tmp/rw0-b2-wire-fifth-repair.zMko0e/final_provenance.json
```

Require that report to bind exactly one canonical manifest with:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe source size:
3_945 bytes

recipe source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6

canonical-manifest SHA-256:
27a65b60710f337d5610d8a8fb6f039d6b0a13ba4045d5e7587a7db37f1a2b77

complete-output SHA-256:
2f172d7c92a91c8118dfbdf6b750cb332371201f03f5b66e3d5c990358121344

file count:
16
```

Expected report-envelope SHA-256:

```text
6eefc4c3891529f72758e10ba2b0515fea79a9ff2207bd0bdd6e43048a9349fc
```

Expected validation-summary SHA-256:

```text
54e5b7470d002e4d87b10a127e052463ba5061ddc801101ccd9f2bff965dbaaa
```

Latest audit evidence root:

```text
/private/tmp/rw0-b2-wire-fifth-reaudit.mSMH5W
```

The escaped mutant is recorded at:

```text
/private/tmp/rw0-b2-wire-fifth-reaudit.mSMH5W/selective_bypass_controls.json
```

Preserve every earlier implementation, repair, and audit evidence root. Do not
rewrite or reconstruct missing evidence.

EXACT RECIPE SOURCE

Decode this base64 only into a new external repair evidence root, verify exact
size and SHA-256, and retain it mode `0400`:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

Execute the exact source unchanged with only its exact historical
`Path.write_bytes` sink redirected into the new evidence root. Do not overwrite
pre-existing fixed-path evidence.

OPENING PROVENANCE AND NODE GATE

Before editing:

1. lstat every component of the immutable target, report-bound manifest, latest
   audit root, retained prior roots, new repair root, and copied recipe;
2. require safe ownership, no symlink traversal, regular files, and mode-0700
   evidence roots;
3. verify the immutable target, report envelope, validation summary, and
   report-bound manifest exactly;
4. run the exact recipe twice;
5. require both complete outputs and manifests to be byte-identical and equal
   the immutable target;
6. verify every live candidate entry by path, classification, type, mode, size,
   and SHA-256;
7. verify protected complement equality to HEAD;
8. collect the complete opening node list exactly once under isolated external
   paths;
9. require exactly `4_655` unique opening nodes.

Stop before mutation on any mismatch. Do not reset, clean, or reconstruct the
candidate.

OPEN FINDING

Treat this as the sole authoritative repair input:

```text
F18 Low  the selective Attempt control appends intended guard paths before
         invoking the captured guard. A class-wide mutant bypassing all fifteen
         delegated Attempt calls plus the selected sixteenth check still passes
         because later digest mismatch supplies invalid_field_value.
```

The audit independently established:

- F17 is closed;
- the 64-entry inventory is exact;
- positive and both negative ledgers contain all 64 keys;
- field-specific legal-MAX regressions are caught;
- production behavior is fail-closed;
- all other F1–F16 findings remain closed.

AUTHORIZED REPAIR PATH

Only this existing untracked candidate file may change:

```text
tests/test_rw0_b2_wire_relations.py
```

The other fifteen candidate entries must remain byte-identical to the opening
manifest.

Because the repair path is untracked, final tracked textual-diff SHA-256 must
remain exactly:

```text
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6
```

No production source, documentation, codec/value/boundary test, inventory test,
status test, public boundary, dependency, schema, migration, package, or new
repository file may change.

PRE-EDIT DIAGNOSTIC

Before editing, reproduce the audit finding without repository mutation:

1. run the existing strengthened 64-path node under:
   - the checked-in selected-operation-only control;
   - an external class-wide Attempt guard bypass;
   - an unrelated Effect guard bypass;
2. require the observed matrix to match:
   ```text
   selected operation only        passes
   all Attempt guards bypassed    incorrectly passes
   unrelated Effect bypassed      fails
   ```
3. instrument:
   - selected bypass count;
   - delegated Attempt guard calls;
   - real guard-body outcomes;
   - AttemptFenceV1 owner-boundary calls;
   - downstream Wire canonicalization/digest calls;
4. prove the class-wide bypass reaches a later failure that masks missing early
   checks;
5. retain exact source hash and repository fingerprint.

If the current candidate does not reproduce the escaped mutant, stop and report
the disagreement. Do not edit.

REPAIR DECISION — USE A BEHAVIORAL SENTINEL, NOT A DELEGATION LEDGER

Merely moving a ledger append after `original_integer(candidate)` is not an
adequate repair: a bypassing delegate can return normally.

The repaired test must contain an independent behavioral sentinel proving that
a non-selected oversized Attempt integer is rejected by the real guard before
Attempt owner reconstruction or any downstream canonicalization.

A. Preserve the existing node and all F17 coverage

Do not add, remove, rename, parameterize, split, skip, xfail, or redecorate any
test.

Strengthen only:

```text
tests/test_rw0_b2_wire_relations.py::test_every_reachable_c2a_integer_path_is_isolated_before_owner_or_wire_canonicalization
```

Preserve exactly:

- the literal 64-entry inventory;
- positive coverage ledger == 64 keys;
- MAX+1 coverage ledger == 64 keys;
- 1,000-digit coverage ledger == 64 keys;
- exact-valid ceiling controls;
- legal-MAX regression controls;
- process-exit `-255/0/255` controls;
- selected one-operation bypass count;
- unrelated Effect control.

B. Selected operation control

Keep one literal selected target, preferably:

```text
AttemptFenceV1.global_stop_version
```

The test-local wrapper may bypass only the exact selected combination of:

```text
owner class
field path
target object identity or explicit target token
oversized value
```

Require:

```text
selected_bypass_count == 1
```

The selected case must reach the selected Attempt-specific owner reconstruction
or canonicalization spy exactly once.

C. Add a non-selected Attempt behavioral sentinel inside the same test node

Use one different literal Attempt integer path, preferably one nested ceiling
such as:

```text
AttemptFenceV1.ceilings.max_active_invocations
```

Run a fresh complete graph in which:

- the selected target is valid and therefore does not match the bypass;
- only the sentinel path is set to `MAX + 1`;
- every other object and digest coordinate is valid.

Under the selected-operation wrapper require:

```text
result:
sealed invalid_field_value

selected_bypass_count:
0 for this sentinel run

AttemptFenceV1.from_mapping / selected owner boundary:
0 calls

Attempt owner canonical identity/digest:
0 calls

Wire canonicalization/digest/frame construction:
0 calls
```

This sentinel must fail at the real `_safe_c2a_integer` body before any later
digest or relation mismatch.

D. Independent real-body oracle

Instrument the actual guard body behavior independently from the wrapper's
delegation bookkeeping.

Acceptable mechanisms include a bounded test-local wrapper around a lower-level
operation executed only by the real guard body, or a before/after execution
marker that cannot be produced by a bypassing replacement.

The oracle must establish for the non-selected sentinel:

```text
real guard body entered:
exactly once

real guard body rejected:
exactly once

owner boundary entered:
zero times
```

Do not count "the wrapper called its delegate" as proof that the delegate
enforced the maximum.

If the guard has no lower-level hook suitable for safe instrumentation, use the
owner-boundary zero-call behavior plus the exact early error as the independent
behavioral oracle. The class-wide mutant control below must then prove
sensitivity.

E. Class-wide Attempt bypass mutant must fail

Within the same top-level test node, define a bounded test-local class-wide
Attempt bypass mutant that returns normally for all sixteen Attempt integer
checks.

Run the non-selected Attempt sentinel through the same behavioral helper.

Require the helper to reject the mutant because at least one of these
independent conditions changes:

- the Attempt owner boundary is reached;
- downstream canonicalization is reached;
- the exact early `invalid_field_value` is not produced at the guard boundary;
- real guard-body rejection count is zero.

Assert the class-wide mutant is rejected by the test helper with an exact,
content-free test-local assertion diagnostic.

Do not accept a control that merely returns a different final outcome. The
difference must be tied to early guard enforcement versus downstream masking.

F. Exact authoritative-call accounting

For the selected-operation-only run, continue to require:

```text
selected bypasses:
1

non-selected Attempt checks delegated:
15
```

But rename/reframe any ledger so it is explicitly **delegation accounting**, not
proof of enforcement.

For the sentinel run require the independent real-body/owner-boundary oracle
above.

For the class-wide mutant require the behavioral oracle to fail even if the
mutant records the same intended paths or returns a sanitized later error.

G. Unrelated Effect control

Preserve the unrelated oversized EffectFenceV1 case:

```text
invalid_field_value
zero selected Attempt bypasses
zero Effect owner/Wire canonicalization calls
```

Also prove that bypassing an unrelated Effect guard does not satisfy or confuse
the Attempt behavioral sentinel.

PRODUCTION AND CONTRACT FREEZE

All production and governing identities remain exact:

```text
profile_ref:
rw0-wire-nwpf-v1

profile identity bytes:
4_021

profile digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454

command payload/frame:
5_898 / 5_906

result payload/frame:
16_627 / 16_635

hostile units:
23_746 / 66_770

source mapping key maximum:
37

frame key maximum:
29

B2 maximum integer:
9_223_372_036_854_775_807
```

Do not modify:

```text
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
.docs/rw0-b2-wire-protocol.md
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_boundaries.py
```

If the behavioral sentinel exposes a production defect, stop. Do not repair
production under this prompt.

NODE IDENTITY

Opening and final collection must both be exactly:

```text
4_655
```

Require:

- all node IDs byte-identical and in the same order;
- zero additions;
- zero removals;
- zero renames;
- zero parameterization changes;
- zero skip/xfail/decorator changes.

Stop on any node mismatch.

VALIDATION POSTURE

Create one new external operator-owned, non-symlink, mode-0700 repair root.

For every pytest child use:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
actual caller/child numerical umask equality
```

Retain exact argv, environment, timing, return code, stdout/stderr, JUnit,
structured counts, and repository fingerprints.

TEST-FIRST CAUSAL GATE

Before final validation, run one selected causal gate containing the strengthened
node while externally installing the class-wide Attempt bypass mutant.

Require the selected gate to fail for the exact behavioral-sentinel assertion.

Then remove only the external mutant, rerun the unchanged strengthened node, and
require it to pass.

This red/green control must not modify repository bytes.

FINAL VALIDATION ORDER

After editing and final collection:

1. class-wide Attempt mutant causal red;
2. strengthened 64-path node, green;
3. full Wire relations file — expected `49` nodes;
4. all four Wire files together — expected `89` nodes:
   ```text
   tests/test_rw0_b2_wire_values.py
   tests/test_rw0_b2_wire_codec.py
   tests/test_rw0_b2_wire_relations.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
5. corrected C2A/C2A1 compatibility — expected `637`;
6. B1 — expected `281`;
7. static/public — expected `105`;
8. status/docs — expected `858`;
9. `git diff --check`;
10. exact path/mode/protected/public/import/residue/operation/lock guards;
11. complete suite attempt 001 exactly once — expected `4_655`.

Every final green focused gate and complete suite must have:

- return code 0;
- zero failures, errors, skips, xfails, warnings;
- empty stderr;
- parseable JUnit;
- no duplicate, ambiguous, or unmapped cases;
- unchanged candidate fingerprint before/after.

The causal mutant gate must fail only for the intended behavioral-sentinel
assertion; retain its stdout, stderr, JUnit, exact injected mutant, and
repository fingerprints.

COMPLETE-SUITE REPAIR POLICY

If complete-suite attempt 001 fails:

- preserve all evidence;
- do not modify production, documentation, or another test file;
- repair only when the failure is causally inside the one authorized test file,
  preserves all 4,655 node identities, and weakens no assertion;
- rerun affected focused gates;
- run complete-suite attempt 002 exactly once.

No third complete-suite attempt is authorized.

FINAL PROVENANCE

After final green validation and cleanup:

1. require exact topology:
   - 16 dirty paths
   - 10 tracked modifications
   - 6 untracked additions
   - 0 staged
   - 0 unmerged;
2. run the exact recipe twice;
3. require byte-identical complete outputs and manifests;
4. require exactly the original 16 paths;
5. compare against the opening target;
6. require exactly `tests/test_rw0_b2_wire_relations.py` to differ;
7. require the other fifteen entries to remain byte-identical;
8. require tracked textual-diff SHA-256 to remain the pinned value;
9. prove every protected path equals HEAD;
10. retain final recipe source, complete-output hash, textual-diff hash,
    manifest hash, complete manifest, unchanged node list, causal red/green
    evidence, validation results, and guards.

STOP CONDITIONS

Stop without further mutation if:

- opening provenance differs;
- retained evidence changed;
- a second repair path or seventeenth candidate path is needed;
- any production or documentation byte must change;
- the literal inventory, F17 ledgers, or legal-MAX controls weaken;
- the non-selected Attempt sentinel cannot be made coherent;
- the class-wide Attempt mutant cannot be killed behaviorally;
- the selected Attempt owner boundary cannot be proved;
- any node identity changes;
- tests require skip/xfail/deletion/renaming/weakening;
- validation or provenance remains unstable.

CLOSEOUT TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_WIRE_SIXTH_AUDIT_TEST_FINDING_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only if F18 is mechanically closed, the class-wide mutant is causally killed,
all 4,655 nodes remain exact, final validation is green, provenance is stable,
production/docs remain byte-identical, and no stop condition fires.

The report must include:

1. opening identity and immutable target;
2. pre-edit mutant reproduction;
3. exact one-file delta;
4. preserved F17 positive/negative ledgers;
5. selected-operation delegation accounting;
6. non-selected Attempt sentinel construction;
7. independent real-body/owner-boundary evidence;
8. class-wide mutant red and authoritative green;
9. unrelated Effect control;
10. unchanged node identity;
11. every validation attempt;
12. final provenance and guards;
13. separate provenance, validation, production-behavior, and test-adequacy
    confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
PRIOR_AUDIT_EVIDENCE_PRESERVED
```
