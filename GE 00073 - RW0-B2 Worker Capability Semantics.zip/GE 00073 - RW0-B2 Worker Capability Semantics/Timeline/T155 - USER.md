Here is Codex's response:

# Verdict

`BLOCK`

The exact G8-sealed candidate is not ready for the commit/push/pull-request gate.

A deterministic High-severity defect exists in the sole final-repair path, `tests/test_rw0_b2_capability_boundaries.py`: independently constructed helper-rebinding, decorator-closure, builtin-shadowing, and already-allowlisted Git-state-read mutants all survive the claimed closed reachable-call proof. An isolated executable mutant passed both the guard and the 43-row target while actually launching a subprocess.

Two additional G8 evidence defects remain: circular module-global mutant expectations and an inaccurate final-report provenance claim.

# Opening and closing identity

Opening and closeout matched exactly:

| Field | Exact value |
|---|---|
| Physical root | `/Users/ds/Repositories/Governed Execution Coordinator` |
| Branch | `codex/rw0-b2-capability-semantics-v1` |
| HEAD | `deec37bf08fb903d8846aa2c3232aec52fa9866e` |
| HEAD tree | `ef48f5bd11244c6f703c97abb5489d19956f7a77` |
| Sole parent | `02450d3c99faf0fe7b299b914afaed312421bc8b` |
| Subject | `feat: implement RW0-B2 Wire protocol (#4)` |
| Upstream | `origin/trunk_dev` at `deec37bf08fb903d8846aa2c3232aec52fa9866e` |
| Ahead/behind | `0/0` |
| Worktrees | `1` |
| Dirty topology | 30 paths: 24 tracked modifications, 6 untracked additions, 0 staged, 0 unmerged |
| Candidate types/modes | all regular `0644` |
| Candidate tree | `0fcf6680ded68d66f62b75b5dc842d69b343a334` |
| Normalized fingerprint | 1,421,607 bytes; `0ff46a4afaaecb079573c0fb32e2d1103bd55fa1e791ad4e01035992f65ca6dc` |
| Logical index | 19,139 bytes; `8f170467abeba2d935a917de2e057eb75635efc555f5a44bfb6cb9c77934c019` |
| Report-only raw index | 22,476 bytes; `7926e411fe75047992b7677548c8a40d090127ce6dbda64c4262d59ca749c213` |
| Reachable objects | 1,522; `1fe75e2874af1c0707328ad1771672aa8f311b3e8e9b2518939af5ba2f9cd417` |

`git diff --check` remained clean; cached diff remained empty. Operations, locks, residue, candidate special paths, a thirty-first changed path, source-repository bytecode/cache/database/journal/archive/build output, and generated repository manifests were absent. Every path outside the candidate manifest remained equal to HEAD.

# Provenance and exact candidate

The G8 provenance gate passed before correctness inspection. The final manifest is 6,430 bytes with SHA-256 `d6f86248da0c4843e20b91cb443f960596e483e08a8f2cff716bbcea4fb553d8`; tracked textual-diff SHA-256 is `cc91155aff703e1c54c139820f841d98135f37ee7c87a71d3b00b07a2672e2a6`.

All entries below are regular mode `0644`:

| Row | Path | Kind | Bytes | SHA-256 |
|---|---|---:|---:|---|
| R01 | `.docs/authority-boundaries.md` | tracked | 32,953 | `1a8ceceaa4c4110f24a4a5e6caa2182c40f1d93b3c94e386c704aaafed6dcb07` |
| R02 | `.docs/autonomous-software-development-operating-model.md` | tracked | 34,951 | `3399cdae5f9e4e6772cd4d6343906d920018cb759adf89177a515ba351378b64` |
| R03 | `.docs/c2a-first-slice-semantic-protocol-contract.md` | tracked | 102,469 | `49238bb9673f0334359c29c7c5add8e35bd617c9e25b7bc372e2445324c81150` |
| R04 | `.docs/c2a1-pure-semantic-values.md` | tracked | 17,052 | `ed7c7a7fad70405268354b348988013631a8c91759a67c24f05d8fb933d5c811` |
| R05 | `.docs/durable-state-model.md` | tracked | 38,138 | `b408350111e76de2eed85245264ced5e01dbd5972b2751c610af1df0e038dc18` |
| R06 | `.docs/rw0-b1-pure-phase-values.md` | tracked | 30,594 | `d6f8e7c119cc09af1f9e9639ed8b5c774bdda29e94f1f58a3e2988419297b63d` |
| R07 | `.docs/rw0-b2-capability.md` | untracked | 16,611 | `d338979d87d09eadbddad79c249b0d3936fa8b41cc87dc787ed5211a90de279e` |
| R08 | `.docs/rw0-b2-wire-protocol.md` | tracked | 16,802 | `9f74f07a12c5be7b6425cf6f3ca57b502c0b66a0b3838e3c791d1ae21c746258` |
| R09 | `.docs/rw0-remote-worker-contact-phase-entry.md` | tracked | 53,427 | `7db0d796c48f3ba20325c20edcd2789b55636fac24af8429fc1d61e08c6be138` |
| R10 | `.docs/worker-execution-boundary.md` | tracked | 29,202 | `77ef23371e4e41df315ae86ce6f173e68a9dcc98e5812a056225b10807f2e14f` |
| R11 | `src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py` | tracked | 57,863 | `7882ca37e70fba0aa7673d6066e92498bc42d9a3dc8f9a7b4f0256970aeffec4` |
| R12 | `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py` | tracked | 100,783 | `4be365d3a494088d5353592f6f689682d59217ac211072f6b27edc874dd2df36` |
| R13 | `src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py` | untracked | 37,555 | `6ba48cd75ac50061576925aa97de0baa8cfb23acbeccceeef953a353c06f8533` |
| R14 | `src/ge_nwp_coordinator/_worker_execution_semantic_values.py` | tracked | 171,211 | `313aa2a51fc9abb632f9278df8672a90c5ee9045c4967f340d3234d9c6760d4c` |
| R15 | `tests/test_architecture_contracts.py` | tracked | 99,858 | `2a7ae85baf6ffb84cfffef4d0585884f6908f1c793185a3ac26525b1b3b55457` |
| R16 | `tests/test_c2a_nonimplementation.py` | tracked | 27,234 | `b0930f649de0c8456d11d8392964403a5c9f275a82bf9c4c544d68e1d2b3b5d9` |
| R17 | `tests/test_runtime_non_authority.py` | tracked | 41,310 | `9636dd003e358d178e6d6316b16dbff7ece944ae64f7bf0a3f3080b6be297755` |
| R18 | `tests/test_rw0_b1_boundaries.py` | tracked | 34,249 | `4d7fb14a71cb1c27f754566c4ac80dcc066b1f491f648fec3cbdb149b1ab6cd5` |
| R19 | `tests/test_rw0_b1_phase_values.py` | tracked | 30,030 | `69235075cdfadb5e467ea02a8a30e7484d6c04c8f065c2b1e03004e57a9eb166` |
| R20 | `tests/test_rw0_b1_relations.py` | tracked | 120,738 | `243216b7e556e150e972ce5d3ceae016b8fc51d9227f65549bfd3e396d8f89ac` |
| R21 | `tests/test_rw0_b2_capability_boundaries.py` | untracked | 76,858 | `eb6ca3cd19b4bd723b82002aa93e7b5743ef02b768ac169d96e0011582e61977` |
| R22 | `tests/test_rw0_b2_capability_relations.py` | untracked | 26,877 | `7522e11f5c5f932462af2cf78f1f86accd703199dd3a2b2232ed82b74cf8c2a4` |
| R23 | `tests/test_rw0_b2_capability_values.py` | untracked | 31,770 | `a3e0c08d6fd4a07133cd450ca62fe1fe668898ac40e0fd5b1798d4a09853791f` |
| R24 | `tests/test_rw0_b2_capability_vectors.py` | untracked | 16,104 | `4aa4432b3e042e72f4a0d131a696a842f1a2ac1e3473f8bc04ad8fb90219f7f3` |
| R25 | `tests/test_rw0_b2_wire_boundaries.py` | tracked | 28,690 | `ec77607ee411c46820e3dbac3fc67fbd1bcf071bcea6888f3286bf58fdd89f78` |
| R26 | `tests/test_rw0_remote_contact_phase_entry_contract.py` | tracked | 171,097 | `83c2cb15e743b7e28307008af29f669190845734daaa3e96c2d7f1dcecd459f1` |
| R27 | `tests/test_section41_pre_execution_plan_disposition_contracts.py` | tracked | 20,327 | `75b7b5e5051ecaab713ee5ec9a91d19d152e0d7e80be06b74548d3b72a9822ba` |
| R28 | `tests/test_software_development_progression_boundary.py` | tracked | 42,833 | `1d3ecc4e509933987e898c6532dd0980cbd737a595b3cb2682b93becf30fa4de` |
| R29 | `tests/test_worker_execution_semantic_boundaries.py` | tracked | 12,313 | `0279bb43c83e5074a2be549c0453c15c942da77145b4a7cbc875826d8f3259c3` |
| R30 | `tests/test_worker_execution_semantic_values.py` | tracked | 51,836 | `d8cb06aaa85a37d116c1df0fc2ceeb4f2fb7265445b45107d352e10f17ddb8c0` |

The sole G5-opening-to-final path change was R21:

- Opening: untracked, regular `0644`, 28,469 bytes, `d5582ea702ee445083c3457188b35b302e5ade52db119c1e2808a6fea5a1f022`.
- Final: untracked, regular `0644`, 76,858 bytes, `eb6ca3cd19b4bd723b82002aa93e7b5743ef02b768ac169d96e0011582e61977`.

The other 29 entries were byte-identical to the G5 opening.

The exact recipe source was copied from G5/G8, not reconstructed: regular `0400`, 3,945 bytes, SHA-256 `db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`. Opening and closeout credited executions reproduced:

- Manifest: 6,430 bytes; `d6f86248da0c4843e20b91cb443f960596e483e08a8f2cff716bbcea4fb553d8`.
- Complete output: 6,663 bytes; `400a5d35fcd18ba6b95c375194719d1bb97796ba61cfcb416ac09b575c6a9bb3`.
- Historical fixed sink: absent before and after every credited run.

# G8 evidence and attempt chronology

The sealed G8 identities all matched:

| Artifact | Rows/bytes | SHA-256 |
|---|---:|---|
| `final_report.md` | 99,764 bytes | `e54ecbef3321b810e58c248221d6542325b878c67ddd35483993c61e9781d118` |
| `attempt_manifest.jsonl` | 212 rows; 67,790 bytes | `83e79b1ca3ca29a9a7dec45bededcc642057f8dc5bf940bfc826c392f6ae0c65` |
| Self-excluding index | 2,403 rows; 448,923 bytes | `f90d50dc17e95e432b6577cad99669777f99bcd2d6af7c42509d2987db8248fc` |
| Indexed projection | 2,403 rows; 530,717 bytes | `053a696a2034958ea2a5161713fa81fbfe88d88e5cf5987e185115872075ae7a` |
| External index-builder result | 2,485 bytes | `3b88a5bea1846161424cd26b208af9d36cd859d97b818f9bc7e53041deb4fb00` |
| External verifier result | 781,828 bytes | `3e59175a566b860abd09165d6952a4350cdb42b2b77cb0509cc4420d4df53f4a` |

The index was canonical, self-excluding, strict-tree-equal, and contained all 43 mandatory records. G8 remained unchanged after index creation.

The 212 attempt rows are continuous, uniquely labeled, and exactly one-to-one with their envelopes: 209 credited and three non-creditable.

- Sequence 8, `pre_harness_path_safety`, failed before launching a child because the full manifest was not yet available. It occurred before candidate validation or external candidate setup.
- Sequence 9 rejected invalid generated recovery syntax without replacing source bytes; source and logical index stayed equal.
- Sequence 10 applied the corrected recovery.
- Sequence 11 correctly rejected the non-neutral `restore_harness.py` path.
- Sequence 12 installed the neutral `h.py` audit-tool alias.
- Sequence 13 reran and passed the same preflight.
- No live or clean full suite was retried. Sequence 178 is the sole live 5,072-test suite; sequence 179 is the sole clean 5,072-test suite.

Terminal ordering was coherent: the ordinary manifest and report were finalized before the final self-excluding index; index creation was G8’s final mutation; external verification occurred afterward and outside G8.

Historical classification was independently confirmed:

- G5: 7,234-row, 1,583,837-byte index, `199af9ac4299cc41a4434d44f1b1f7bcaf3265490b7417e174ad5d48723f8fcc`; implementation evidence with partial historical attempt metadata, not reconstructed.
- G6: failed replay evidence only. Thirty-four basetemp roots; 23,119 quarantine rows; 8,429,688 bytes; `dceccfcf6d07c1fc217b7f309e622a9caa8612674c819398e840d2b3b065b81d`. Retained projection: 5,954 rows, 1,445,396 bytes, `d29952e1bb4404c3c6c547fb1c52b9dd9a091bab80af123c0d04ea3b1fa2819b`. Unsafe entries: 1,152 symlinks and 12 FIFOs; none outside quarantine; mandatory overlap zero.
- G7: failed replay evidence only. Twenty basetemp roots; 706 quarantine rows; 279,200 bytes; `c40df656b10707b4f12b6704eb2012bf1733fea53bcdddd734024f3917d8aa32`. Retained projection: 5,640 rows, 1,385,448 bytes, `fa4c30c844925071aae9be12cf103af188b3c98fb062645f72fc5fc15716f005`. Unsafe entries: 14 symlinks; none outside quarantine; mandatory overlap zero.
- G8 remains the authoritative complete validation/closeout envelope, but Findings G9-EV-002 and G9-RP-003 show that two assertions made about that envelope are not sound.

# Audit perspectives and disagreements

Exactly four bounded, non-nesting perspectives were used. The three child perspectives were read-only and ran no tests; all executions were performed by the parent.

1. Closed-call/protected-content perspective: found the closed-call bypass and module-global evidence circularity; recommended blocking.
2. Restore/A-B-C/stable-contract perspective: found no defect in its scope. Restore mechanics, seven tooling cases, eight stable mutants, and A/B/C evidence were green.
3. Validation/all-attempt perspective: confirmed the test evidence but found the final-report provenance overclaim; recommended blocking.
4. Parent provenance/public/authority perspective: provenance and production authority boundaries were green, then independently reproduced the closed-call defect dynamically and reconciled the findings.

The material disagreement is therefore explicit: the restore/A-B-C perspective found its bounded surface sound, while the closed-call and evidence perspectives found defects sufficient to block the gate.

# Severity-ranked finding ledger

## G9-CC-001 — closed-call control-soundness defect

- **Type:** test-boundary soundness.
- **Severity:** High.
- **Contract:** current G8 audit/test contract.
- **Path and line:** [call resolution](/Users/ds/Repositories/Governed%20Execution%20Coordinator/tests/test_rw0_b2_capability_boundaries.py:441), [reachable analyzer](/Users/ds/Repositories/Governed%20Execution%20Coordinator/tests/test_rw0_b2_capability_boundaries.py:491), and [runtime-global check](/Users/ds/Repositories/Governed%20Execution%20Coordinator/tests/test_rw0_b2_capability_boundaries.py:795).
- **Evidence:** `_callable_semantic` checks the order-insensitive top-level `functions` map before `module_assignments`. A later assignment can therefore rebind an approved helper at runtime while analysis follows its earlier `FunctionDef`. The reachable scan excludes module assignment values and decorators. Builtin resolution similarly precedes module assignment checks. The external inventory is set-valued, so an additional call to an already-allowlisted method with a Git-sensitive argument is invisible.
- **Independent adverse probes:**
  - `helper_rebind_alias`, SHA-256 `68bd5ddc15603fd1c4264e39f36a0cdea11959bb05f5146409d484a47357cd66`: empty diagnostics, canonical inventory.
  - `decorator_closure_alias`, `fbf7ee99bd57fe66149abb0419b2442808e5657234ca6a113458a1bd71909bf7`: empty diagnostics, canonical inventory.
  - `builtin_shadow_alias`, `d7cca5c4fe94b3a17adee55929dc6a12232c2584d5e455b43fe23e077d7d5905`: empty diagnostics, canonical inventory.
  - `allowlisted_git_index_read`, `25f0c1ed8509812da6579e4f83842808a1b677f914dff747454851e14efd4917`: empty diagnostics, canonical inventory.
  - The executable helper-rebinding source, SHA-256 `384528d45f5a1b80d3902ce2695ac1d370e51ea31fe9b6832bb1f0f37baf4bc7`, passed both the guard and target, 2/2, return code 0, empty stderr, while its subprocess wrote the expected sentinel. Its retained patch SHA-256 is `242a0826bbc3bd8a4243376f567fff8e2e5eacd835ca17e2a0faa98228e93fff`.
- **Impact:** the claimed exact runtime call graph and equivalent command/process/Git mutant coverage are false. Forbidden effects or Git-state observation can be added while both the guard and 43-row target remain green.
- **Required correction:** make binding resolution source-order-aware; reject competing imports, assignments, decorators, and builtin/helper rebinding; seal approved callable identities, code/default/closure posture; track call multiplicity and relevant argument targets rather than a set-only external inventory; add independent causal versions of all four surviving layouts.
- **Uncertainty:** none after isolated execution.
- **Classification:** patch defect in the sole G8 final-repair file, not a pre-existing issue and not a production-module defect.

## G9-EV-002 — circular module-global mutant evidence

- **Type:** replay/evidence causal circularity.
- **Severity:** Medium.
- **Contract:** current G8 replay/evidence contract.
- **Path and line:** [global_mutation_cases](/private/tmp/g8.3cee3f/replay.py:896), [mutant replay](/private/tmp/g8.3cee3f/replay.py:1363), and [causal guard](/private/tmp/g8.3cee3f/replay.py:1758).
- **Evidence:** each mutated namespace is first passed to `_boundary_runtime_global_diagnostics`; that result is stored as `expected_diagnostic`. Replay calls the same checker again, and closeout checks only `expected_diagnostic == actual_diagnostic`.
- **Impact:** a checker returning one generic nonempty diagnostic for every mutant would keep all nine attempts green. The current nine outputs are sensible, but the evidence is not independently bound and does not meet the explicit non-self-derived requirement.
- **Required correction:** define a literal, independent case-to-diagnostics mapping and compare each mutant directly to it; reseal the replay/report/index afterward.
- **Uncertainty:** none.
- **Classification:** G8 replay/evidence defect, not production source and not pre-existing.

## G9-RP-003 — final-report provenance overclaim

- **Type:** report/evidence accuracy.
- **Severity:** Low.
- **Contract:** current G8 all-attempt reporting contract.
- **Path and line:** [final_report.md](/private/tmp/g8.3cee3f/final_report.md:141) and [sequence 8 envelope](/private/tmp/g8.3cee3f/a/0008/envelope.json:96).
- **Evidence:** the report says every action retained authoritative source pre/post fingerprints and separate ambient observations. Sequence 8 has all four records missing and equality `null`. Sequence 1 uses the bootstrap identity schema; sequences 2–7 and 9–32 use `normalized-light-source-fingerprint.v3`; authoritative fingerprints begin at sequence 33.
- **Impact:** all-attempt provenance is overstated. This does not invalidate the later focused or full-suite results, but it is a concrete sealed-report contradiction.
- **Required correction:** qualify bootstrap, light, missing, and authoritative phases; update the report generator and reseal the report/index/external verification.
- **Uncertainty:** none.
- **Classification:** G8 replay/report-generation defect, not production source and not pre-existing.

# Closed reachable-call and module-global result

The canonical source currently produces empty diagnostics and the encoded inventory exactly. Its intended local graph is:

```text
test_exact_twenty_path_ceiling_modes_and_protected_controls
  -> _stable_capability_boundary_projection
       -> _protected_content_row
```

Its exact external inventory is:

- Target: `builtins.len`, `builtins.set`, `builtins.tuple`, `builtins.zip`.
- Projection helper: `builtins.len`, `builtins.set`, `builtins.sorted`, `builtins.tuple`, `hashlib.HASH.hexdigest`, `hashlib.sha256`, `list.append`, `pathlib.Path.lstat`, `stat.S_IMODE`, `stat.S_ISLNK`, `stat.S_ISREG`, `str.encode`, `str.join`.
- Protected helper: `builtins.len`, `hashlib.HASH.hexdigest`, `hashlib.sha256`, `pathlib.Path.lstat`, `pathlib.Path.read_bytes`, `stat.S_ISLNK`, `stat.S_ISREG`.

The encoded 26 call mutants—direct/constructed/prebuilt subprocess, shell forms, imported/module/nested aliases, `getattr`, wrapper, default, closure, module global, unknown helper, dynamic import, GitPython, dulwich, `Popen`, `check_call`, `check_output`, `call`, `os.system`, `os.popen`, spawn, exec, and star import—are individually killed by the existing checker. They are incomplete because the four independent layouts above survive.

The nine module-global replacements currently produce sensible diagnostics for `ROOT`, `EXPECTED_PATHS`, `EXPECTED_PATHS_SHA256`, `PROTECTED_PATHS`, `PROTECTED_PATH_IDENTITIES`, `PROTECTED_ROW_IDS`, `EXPECTED_BOUNDARY_ROWS`, `hashlib`, and `stat`, but their replay oracle is circular as described in G9-EV-002.

# 43-row projection and protected-content result

No separate projection or P01–P13 content defect was found.

For R01–R30, the subject is the identically labeled path in the candidate table. Each literal expected value is:

```text
("required", <subject>, "0644", 0, "")
```

and each row diagnostic is `stable_boundary_row:<row-id>`.

The exact class/purpose mapping is:

```text
R01 required_path,regular_file,mode,authority_non_effect | authority policy
R02 required_path,regular_file,mode,authority_non_effect | composition authority
R03 required_path,regular_file,mode,authority_non_effect | C2A protocol and effect boundary
R04 required_path,regular_file,mode,authority_non_effect | C2A1 pure semantic boundary
R05 required_path,regular_file,mode,state_store_writer_session | durable state ownership
R06 required_path,regular_file,mode,authority_non_effect | B1 owner
R07 required_path,regular_file,mode,private_module_export | Capability owner
R08 required_path,regular_file,mode,authority_non_effect | Wire owner
R09 required_path,regular_file,mode,authority_non_effect | RW0 phase and status integration
R10 required_path,regular_file,mode,authority_non_effect | worker and ES ownership
R11 required_path,regular_file,mode,authority_non_effect | pre-execution disposition seam
R12 required_path,regular_file,mode,authority_non_effect | B1 snapshot seam
R13 required_path,regular_file,mode,private_module_export,production_importer_caller | Capability implementation
R14 required_path,regular_file,mode,authority_non_effect | EffectFence semantic dependency
R15 required_path,regular_file,mode,authority_non_effect | architecture controls
R16 required_path,regular_file,mode,authority_non_effect | C2A non-widening
R17 required_path,regular_file,mode,authority_non_effect | runtime non-authority
R18 required_path,regular_file,mode,authority_non_effect | B1 boundary controls
R19 required_path,regular_file,mode,authority_non_effect | B1 value controls
R20 required_path,regular_file,mode,authority_non_effect | B1 relation controls
R21 required_path,regular_file,mode | Capability boundary oracle
R22 required_path,regular_file,mode,private_module_export | Capability relation controls
R23 required_path,regular_file,mode,private_module_export | Capability value controls
R24 required_path,regular_file,mode,private_module_export | Capability vector controls
R25 required_path,regular_file,mode,authority_non_effect | Wire boundary controls
R26 required_path,regular_file,mode,authority_non_effect | remote-entry contract
R27 required_path,regular_file,mode,authority_non_effect | disposition boundary
R28 required_path,regular_file,mode,state_store_writer_session | progression ownership boundary
R29 required_path,regular_file,mode,authority_non_effect | worker semantic boundary
R30 required_path,regular_file,mode,authority_non_effect | worker semantic values
```

The exact P rows are:

| Row | Classes | Literal expected tuple | Purpose |
|---|---|---|---|
| P01 | protected content, regular, authority non-effect | `("protected","src/ge_nwp_coordinator/_rw0_wire_protocol_values.py","regular",77003,"6bf39f634b619829fcc4cc7ada5cf019b40b3c5a2258947ebee8fdfe2a13031e")` | protected Wire implementation |
| P02 | protected content, regular, authority non-effect | `("protected","src/ge_nwp_coordinator/_development_author_effect_establishment_contracts.py","regular",63518,"f6938024436a765a69e9a44d20d834a85075ba10b821e61e3e91bfb09cf17af0")` | protected author-effect authority |
| P03 | protected content, regular, dependency/schema/migration | `("protected","src/ge_nwp_coordinator/_development_decision_row_values.py","regular",53230,"9e0e9c0695adb9f0ad72d9d92c6859c995c2c5ade154a5546f0a1efc347db8ae")` | protected decision row seam |
| P04 | protected content, regular, dependency/schema/migration | `("protected","src/ge_nwp_coordinator/_development_effect_row_values.py","regular",64606,"bbe52faf7ad69e2e643a404808cb0e68d4f7c76a668426d58029a7c108cfa158")` | protected effect row seam |
| P05 | protected content, regular, dependency/schema/migration | `("protected","src/ge_nwp_coordinator/_development_program_row_values.py","regular",60276,"d8557eac3f4956c6fdedaf851b9f230f871d0d41eb381fdb09cdecece8df6422")` | protected program row seam |
| P06 | protected content, regular, private export | `("protected","src/ge_nwp_coordinator/__init__.py","regular",2385,"60230ae31032071ab52b16c3537a1b2b398e06a4b1f4ec926485471927b2f2b5")` | protected package exports |
| P07 | protected content, regular, dependency/schema/migration | `("protected","pyproject.toml","regular",330,"c59ff8c0005b063636ff161002f1b1c45a81227b4ed30a988412f01a474e0ac9")` | protected dependency metadata |
| P08 | protected content, regular, authority non-effect | `("protected","tests/c2a_contract_support.py","regular",154329,"4952d25086220632c969a29e44b9abe29b966fbb031d2305c11d4bf13d39c4f1")` | protected C2A support |
| P09 | protected content, regular, dependency/schema/migration | `("protected","tests/test_c2b2_development_row_value_boundaries.py","regular",17823,"4c892136f8c6fd629eb44e95bc8dd7a9aa1a5250e97cc61499171f2835bb4f42")` | protected C2B2 schema controls |
| P10 | protected content, regular, authority non-effect | `("protected","tests/test_codex_agent_config.py","regular",1082,"0691c90c0178632a793a93595ba344169fb9b9669de155939fb4873db2f0d3ee")` | protected Codex configuration |
| P11 | protected content, regular, authority non-effect | `("protected","AGENTS.md","regular",58903,"ab3e788e3086088eb5caa2cf392a9ccb9582b645c082897574e55234aec860c8")` | protected repository governance |
| P12 | protected content, regular, authority non-effect | `("protected","README.md","regular",43280,"093134d136a8dc246c9a9c1557a95c3b5500007b8ccfd3a4cac0722b1a0aa1d4")` | protected public claims |
| P13 | protected content, regular, StateStore/WriterSession | `("protected",".docs/software-development-progression-boundary.md","regular",27194,"3b0c21f73048e458bd750b9896fbae7c285a4b35799b99060aef03d8379052fe")` | protected progression authority |

Each P-row projection diagnostic is `stable_boundary_row:<row-id>`; each content-mutation causal diagnostic is `protected_identity:<row-id>:<subject>`.

The oracle has 43 ordered rows, unique IDs, unique purposes, unique subjects, unique diagnostics, literal expected values, and no Git-state field. Row-count, duplicate, contract-class, and order controls passed.

All P01–P13 one-byte causal tests passed. The exact P12 prior survivor was killed:

- Canonical README SHA-256: `093134d136a8dc246c9a9c1557a95c3b5500007b8ccfd3a4cac0722b1a0aa1d4`.
- Delta: `byte[21640]:6e->6f`.
- Weakened predicate: `len(payload) >= 0 and isinstance(digest, str)`.
- Causal signal: `protected_causal_mutant_survived:P12`.

# Restore harness and stable-contract result

The normalized harness source and retained `h.py` alias are byte-identical, SHA-256 `876300da1ee3b29cd0494c0f297a6bf0a46dcbf79cfb5b9cfb7af591800d579a`.

It pins `governed-execution.normalized-authoritative-git-fingerprint.v1`, contains no normalized top-level `index` access, explicitly compares `logical_index_ls_files_stage_z`, directly compares normalized mappings, restores target type/content/mode before Git comparison, and classifies raw index observation as report-only.

The parent independently executed all seven tooling cases successfully:

1. regular → symlink → regular;
2. regular → missing → regular;
3. wrong mode → restored mode;
4. changed content → restored content;
5. raw index stat-cache refresh with equal logical index;
6. normalized baseline without a top-level `index`;
7. negative logical-index mismatch with finite `logical_index_mismatch:` rejection.

Every fixture repository was removed.

The parent also independently replayed all eight stable-contract mutants:

- missing required path;
- unexpected literal path;
- regular-to-symlink;
- wrong mode;
- package-root export;
- production importer/caller;
- dependency/schema/migration widening;
- protected-content weakening.

All intended diagnostics were observed; the six filesystem cases each produced exactly one expected failing JUnit case, then restored exact target identity and normalized/logical equality. Final external fingerprint equaled its baseline at `e36f7203cc1c0eb1333a7a43e5af26addcdffa6043246b06a72ce63bab47506b`; source fingerprint remained `0ff46a4a…`.

# A/B/C state result

Independent three-state reproduction was green:

| State | Result |
|---|---|
| A — live unstaged source | target passed 1/1 |
| B — independent staged repository | target passed 1/1; exactly 30 staged paths; `write-tree` = `0fcf6680ded68d66f62b75b5dc842d69b343a334` |
| C — external diagnostic commit | target passed 1/1; clean; commit `6f4cf0c3e1a504e49a1e6603a5fca95d6d69874d`; tree `0fcf6680ded68d66f62b75b5dc842d69b343a334` |

All three projections had 43 rows, source-test SHA-256 `eb6ca3cd19b4bd723b82002aa93e7b5743ef02b768ac169d96e0011582e61977`, and identical projection-array SHA-256 `41f7afd8712a1d6d966daf5fd2d0e06996e0fc633e774c9e466d0343d4fa92b1`.

The source logical index, normalized fingerprint, and 1,522-object reachable graph remained unchanged. B and C had no alternates, object symlink, or special object entry and shared zero object device/inode pairs with the source repository.

# Node identity and migration result

Repair-opening versus final:

- Opening: 5,057 nodes, 839,431 bytes, `f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe`.
- Final: 5,072 nodes, 841,100 bytes, `f0faec3289ed635a741867bb2a655487f4a4a824dcf4cc0921c334beada1bbd3`.
- Additions: 15.
- Removals: 0.
- Renames: 0.
- Outside-file order: unchanged.

The exact 15 additions are the closed-call test, P01–P13 parameterizations, and the exact P12 audit-survivor kill, all in `tests/test_rw0_b2_capability_boundaries.py`.

Independent clean-HEAD archive comparison:

| Set | Count | SHA-256 |
|---|---:|---|
| Candidate ordered nodes | 5,072 | `f0faec3289ed635a741867bb2a655487f4a4a824dcf4cc0921c334beada1bbd3` |
| HEAD ordered nodes | 4,655 | `f36822a60056ec3d110956de561202b737662c9d22cd0dd82c4cdad6c7cef69f` |
| Sorted intersection | 4,655 | `d0b5910404e617abbfbcb2ee9f15847c93abda16dc6c338b72fb33bb08452ccf` |
| Sorted candidate-only | 417 | `5300100a3ac4477160aaa32c228477bd4dfb82c0dc86ff18db5dfe452dda0ae0` |
| Sorted HEAD-only | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |

The exact sets are retained as [intersection](/private/tmp/g9.rW9peg/nodes_i.txt), [candidate-only](/private/tmp/g9.rW9peg/nodes_co.txt), and [HEAD-only](/private/tmp/g9.rW9peg/nodes_ho.txt).

# Retained validation assessment

The authoritative G8 validation envelopes remain internally valid for the tests they ran:

| G8 run | Passed |
|---|---:|
| Selected causal | 16/16 |
| Capability boundaries | 32/32 |
| Capability complete | 69/69 |
| B1/Wire | 461/461 |
| Architecture/status/static | 907/907 |
| Live collection | 5,072 unique |
| Clean collection | 5,072 unique |
| Live full suite | 5,072/5,072, exactly once |
| Clean full suite | 5,072/5,072, exactly once |

All had empty stderr, zero failures/errors/skips/xfails/xpasses/warnings, exact unique JUnit mapping, and unchanged authoritative fingerprints where applicable.

These results establish that the existing test suite passes. They do not establish Hypothesis A because the independent adverse mutants expose a false-negative class absent from that suite.

# Independent validation

All pytest infrastructure paths were screened with the owning grammar derived from `tests/test_b3c2_transition_event_readers.py`, source SHA-256 `37ec60d334910dcc3eb58c8d626401efae2b10ba62bb04e1fde616c280b8bc29`. Cwd, interpreter, wrapper, HOME/PWD, PATH entries, TMPDIR, pycache, basetemp, JUnit, and retained stream/node paths passed.

Every credited child used numerical umask `0022`, `LC_ALL=C`, `LANG=C`, `PYTHONDONTWRITEBYTECODE=1`, `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`, empty `PYTEST_ADDOPTS`, `PYTHONHASHSEED=0`, `GIT_OPTIONAL_LOCKS=0`, `python3 -B -m pytest -p no:cacheprovider -W error`, and distinct neutral temp/cache/base/JUnit paths.

Independent focused results:

| Group | Result | Ordered-node SHA-256 |
|---|---:|---|
| Selected causal | 16/16 | `0a9f63ef728d7b3fd193b22a4e3b8c2f8f7c769ff8498478da87bb218ebf4aeb` |
| Capability boundaries | 32/32 | `a11ab8af6701da7b032da92b2ba6b60caf695569e1ce2debf17be6f9ee538bc7` |
| Capability complete | 69/69 | `31713d40ebbc13d8ff3c249c5e3ee94560bff350ec53c582efc08f3b5ebd1d15` |
| B1/Wire | 461/461 | `48d560ae6434f8fd62b09de85b3439fc5209643acfd3c5d1cfe4b4af495f98fe` |
| Architecture/status/static | 907/907 | `f087e0df13b0f96c1f74fbef75bbf74716c1a18549bf7637447c2c210e15f010` |

Each had return code 0, parseable JUnit, zero duplicate/unmapped cases, zero non-pass outcomes, empty stderr, and unchanged source fingerprint and logical index.

The independent live and clean complete 5,072-test suites were deliberately withheld after G9-CC-001 became a deterministic High-severity blocker, as permitted by the engagement. The retained G8 suites are reported above but are not represented as replacement independent suites.

# Public, privacy, and authority boundary

The production Capability implementation remains private and pure:

- `__all__ == ()`.
- No package-root export.
- No production reverse import or caller; only tests import the Capability module.
- Standard-library imports are limited to `datetime`, `hashlib`, `json`, `re`, `typing`, and `weakref`.
- Private dependencies are the exact B1 snapshot seam, Wire owner mapping, and `EffectFenceV1`.
- No dependency, SQL, schema, catalog, migration, `StateStore`, or `WriterSession` widening.
- No filesystem, process, network, provider, Bridge, Execution Substrate call, Git, publication, or runtime effect in production code.
- Source references and digests remain unauthenticated evidence.
- No executable permission, semantic acceptance, persistence, or runtime authority was added.
- RW0-C/D/E remain future work; Execution Substrate retains admission/runtime ownership.

The fixed Wire profile remains `rw0-wire-nwpf-v1` with digest `470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454`.

No accepted architecture contradiction was found. The blocking defects are in the final repair test and replay/report evidence, not in the documented production authority boundary.

# Closeout and evidence index

Only G9-created transient repositories, basetemps, TMPDIRs, and pycache roots were removed: 3,868 entries and 201,479,220 regular-file bytes. Source-repository state was untouched.

One closeout recipe attempt was transparently non-creditable because the audit driver supplied G9 rather than the source repository as cwd; `git rev-parse` failed before the recipe sink write. It produced zero stdout, created no manifest, and changed neither source nor historical sink. Two subsequent unique-sink runs were credited and exactly matched the opening target.

Closeout reproduced:

- Source normalized fingerprint: 1,421,607 bytes, `0ff46a4afaaecb079573c0fb32e2d1103bd55fa1e791ad4e01035992f65ca6dc`.
- Logical index: 19,139 bytes, `8f170467abeba2d935a917de2e057eb75635efc555f5a44bfb6cb9c77934c019`.
- Raw index: 22,476 bytes, `7926e411fe75047992b7677548c8a40d090127ce6dbda64c4262d59ca749c213`.
- Reachable graph: 1,522 objects, `1fe75e2874af1c0707328ad1771672aa8f311b3e8e9b2518939af5ba2f9cd417`.
- G8 strict index/projection gate: green and unchanged.
- Operations, locks, and residue: empty.
- Recipe manifest/output pair: exact twice.

All retained G9 entries are regular files or directories; files are `0400`, directories `0700`. The final self-excluding evidence index is:

- Rows excluding itself: 196.
- Size: 35,153 bytes.
- SHA-256: `a788c22943c8bcf0601ecf4a944182242843ad1f1849e24996e9c818f12ac244`.
- Strict tree match: true.
- Self-excluding: true.
- Index mode: `0400`.
- Final G9 mutation: index creation.

Supplementary retained evidence:

- [Finding ledger](/private/tmp/g9.rW9peg/verdict.json)
- [Executable survivor result](/private/tmp/g9.rW9peg/mutant.json)
- [Executable survivor patch](/private/tmp/g9.rW9peg/rebind.patch)
- [Four independent survivor variants](/private/tmp/g9.rW9peg/cm.json)
- [A/B/C result](/private/tmp/g9.rW9peg/abc.json)
- [Restore self-tests](/private/tmp/g9.rW9peg/rh.json)
- [Stable-mutant matrix](/private/tmp/g9.rW9peg/sm.json)
- [Node comparison](/private/tmp/g9.rW9peg/nodes.json)
- [Closeout](/private/tmp/g9.rW9peg/close.json)
- [Self-excluding evidence index](/private/tmp/g9.rW9peg/evidence_index.jsonl)

# Confidence

Confidence in `BLOCK` is high. The principal defect was reproduced dynamically in an isolated audit repository, with an observed subprocess effect and both guarded tests still passing. The three additional independent layouts corroborate the structural cause.

The withheld independent complete suites could reveal further defects, but they cannot reverse this blocker. The necessary next step is a new repair and resealed evidence envelope; no commit/push/PR gate should proceed on G8.

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
