## Engineering disposition

**Proceed to a fresh independent audit. Do not commit or publish this candidate yet.**

The implementation report is sufficient to define an exact audit target:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Dirty topology:
20 paths
14 tracked modifications
6 untracked additions
0 staged
0 unmerged

Canonical manifest:
41a256e52bf5b3e677ec88736889230be416005da429bf5cb3339c92d9427c76

Tracked diff:
e81ef0ba3e3238a7e6ec428c519f3259bebb6da79cbef318a7045edb45656f5f

Final nodes:
4,676

Final node-list SHA-256:
f8fe844c0b8da21b99ccedb3cc22075f85c144e9420c6d040504a9859680e26c
```

The result is still only **Codex-reported implementation evidence**. The project workflow requires independent audit in a fresh read-only conversation, against the exact candidate bytes, before any commit gate. 

### Two points the audit must resolve

First, the implementation report omitted the final recipe stdout size and hash. Because the exact recipe and complete canonical manifest are available, I reconstructed the expected output deterministically:

```text
Complete recipe output:
4,524 bytes

SHA-256:
8d8ff431ae0aa0362b4d298e5261ba866ca9f7eeae18a3e2f93bb33d233b088b
```

The audit prompt pins this value but instructs Codex to verify it mechanically. The omission is not itself a provenance mismatch if the live candidate reproduces it exactly.

Second, complete-suite attempt 001 failed under matching `077/077` umasks because the filesystem-security fixture did not create the intentionally unsafe mode it expected. Codex then ran the affected test and complete-suite attempt 002 under matching `022/022`, without changing repository bytes. That is plausibly an external test-orchestration correction rather than a candidate defect, but the rerun did not follow the implementation prompt’s patch-repair wording literally. The independent audit must classify that procedural deviation and supersede it with its own once-only run under a fixed `022` posture.

Neither point justifies another implementation pass before audit.

## Independent-audit prompt

Send this complete prompt in a **new read-only Codex conversation**:

:chatgpt-content-reference{index="2"}

Verify the artifact:

```text
Filename:
Coordinator_RW0_B2_Capability_Fresh_Independent_Audit_Prompt.txt

Size:
32,504 bytes

SHA-256:
60e594e1fb82599224f69aa4f8bbdd16f7bf2c590aae8d060243321aa2d8c5cc
```

The prompt embeds:

```text
Exact recipe source:
3,945 bytes
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Canonical manifest:
4,291 bytes
41a256e52bf5b3e677ec88736889230be416005da429bf5cb3339c92d9427c76

Expected complete output:
4,524 bytes
8d8ff431ae0aa0362b4d298e5261ba866ca9f7eeae18a3e2f93bb33d233b088b
```

It also contains the complete 20-file canonical manifest, so the auditor does not need to infer any path, classification, size, mode, or hash from the prose report.

### Audit scope

The audit uses four independent perspectives:

1. **Contract and authority:** declaration/observation/qualification separation, non-authentication, non-permission, later-owner boundaries, and status ownership.
2. **Values and hostile boundaries:** safe reconstruction, attributes and equality, mapping precedence, error-chain privacy, work budgets, cycles, aliases, and Wire-profile loading.
3. **B1/Wire composition:** exactly one complete B1 owner call, fixed Wire pair, qualification precedence, bare-qualified false positives, and reconstructed-value-only semantics.
4. **Tests and public boundary:** causal mutants, literal vectors, node identity, no export or production caller, Markdown owner oracles, validation evidence, and provenance.

The prompt requires external counterexamples rather than relying on the checked-in suite alone. In particular, it challenges:

- incomplete or tampered exact-class objects through every method and attribute;
- correctly resealed but semantically invalid values;
- selective and class-wide reconstruction bypasses;
- exception `__cause__`, `__context__`, traceback locals, and payload retention;
- exact work maxima and one-under controls;
- mapping-key precedence in different insertion orders;
- malformed Wire-owner output and post-import substitution;
- a bare B1 `qualified` value over an invalid B1 graph;
- every qualification-precedence collision;
- complete owner-marker mutants through authoritative—not path-local—oracles.

If inspection is green, the audit independently runs:

```text
Capability:          21
B1 compatibility:  281
Wire compatibility: 89
C2A compatibility: 637
Static/public:      124
Status/docs:        878
Full suite:       4,676
```

It also compares a clean archived HEAD collection against the candidate:

```text
Candidate:      4,676
HEAD:           4,655
Candidate-only:    21
HEAD-only:          0
```

All 21 additions must belong to the four new Capability test files.

The audit starts by reproducing the exact provenance target and must stop with `AUDIT_PROVENANCE_MISMATCH` before source judgment if any byte differs. That separation is required because provenance establishes byte identity, not correctness or authority.  

### Possible outcomes

The required verdict is exactly one of:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

On acceptance it must also return:

```text
COORDINATOR_RW0_B2_CAPABILITY_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Only that result should advance to staging. The project lifecycle requires an accepted audit before regenerating the authoritative manifest, staging exact audited paths, comparing staged blobs, validating, committing once, and pushing the intended branch. 

### Sources

- Codex implementation report supplied in this turn.
- Separate-conversation independent-audit boundary. 
- Provenance, validation, and implementation confidence separation. 
- Independent-audit and later commit-gate sequence. 

**Confidence:** High that the live candidate is sufficiently bound for independent audit; deliberately unassigned on implementation acceptance until the reconstruction, qualification, privacy, budget, causal-test, and authority claims survive that audit.
