## Disposition

`REPORT_EVIDENCE_INCOMPLETE` is **not a finding against the repaired repository bytes**. It means the success token cannot yet be tied to a complete, immutable audit handoff.

Do not:

- start another independent audit;
- repeat the implementation;
- rerun validation speculatively;
- stage or commit.

The immediate task is to identify the **first missing evidence item**, establish whether the live one-file repair still matches a retained final target, and distinguish three materially different cases:

1. **Evidence-only closeout gap:** all test, mutation, three-state, suite, and provenance records exist; only the aggregate report or index is missing.
2. **Validation-evidence gap:** repository bytes are complete, but a mandatory JUnit, mutation result, A/B/C record, node list, run-local fingerprint, suite result, or final provenance run was never retained.
3. **Implementation gap:** the claimed closed call surface or causal protected-content coverage was not actually completed in the repository test.

## Evidence-gap diagnostic handoff

Continue in the **same write-enabled Capability implementation conversation**, but in read-only diagnostic posture:

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Capability_Commit_Compatibility_Final_Repair_Evidence_Gap_Diagnostic_Prompt.txt

Size:
11,782 bytes

SHA-256:
d1937f9b56d215e884f44855a8bb102a41b24ab7553872b85691709fe771f81d
```

The prompt authorizes no tests, mutation probes, node collection, A/B/C simulation, provenance rerun, or repository change. It requires Codex to locate every evidence root created by the repair and classify each mandatory record as:

```text
PRESENT_VERIFIED
PRESENT_INCOMPLETE
DERIVABLE_READ_ONLY
MISSING_REQUIRES_VALIDATION_RERUN
MISSING_REQUIRES_IMPLEMENTATION_RERUN
NOT_APPLICABLE
```

It explicitly checks for:

- final canonical manifest and one-file delta;
- closed reachable-call inventory;
- every constructed/aliased/dynamic-call mutant;
- literal 43-row projection;
- causal ledger for every protected-content row;
- the exact audit-surviving protected-content mutant and its kill record;
- stable-contract mutation matrix;
- unstaged, staged, and clean-commit records;
- final node list;
- focused validation and both complete suites;
- run-local pre/post fingerprints;
- final guards, cleanup, closeout report, and self-excluding index.

## Required diagnostic outcome

Codex must return exactly one of:

```text
EVIDENCE_ONLY_CLOSEOUT_REGENERATION_READY
VALIDATION_EVIDENCE_RERUN_REQUIRED
IMPLEMENTATION_RERUN_REQUIRED
LIVE_CANDIDATE_BYTES_DRIFTED
REPORT_PROVENANCE_MISMATCH
EVIDENCE_LOSS_UNRECOVERABLE
```

### Decision path

If it returns `EVIDENCE_ONLY_CLOSEOUT_REGENERATION_READY`, regenerate only the report and evidence index from immutable records. No tests or repository edits.

If it returns `VALIDATION_EVIDENCE_RERUN_REQUIRED`, authorize only the exact missing subset it names—such as selected causal tests, A/B/C simulation, node collection, live suite, clean suite, or provenance. Do not default to rerunning everything.

If it returns `IMPLEMENTATION_RERUN_REQUIRED`, Codex must identify which claimed repair is absent from `tests/test_rw0_b2_capability_boundaries.py`. Only then should repository bytes change.

If it returns `LIVE_CANDIDATE_BYTES_DRIFTED`, the success token is stale and every changed path must be reported before further work.

No fresh independent audit is justified until this diagnostic yields a complete, byte-bound handoff.

**Source:** Codex’s `REPORT_EVIDENCE_INCOMPLETE` response supplied in this turn.

**Confidence:** High that evidence diagnosis is the necessary next step; implementation confidence remains unassigned until Codex identifies whether the gap is documentary, validation-related, or an incomplete test repair.
