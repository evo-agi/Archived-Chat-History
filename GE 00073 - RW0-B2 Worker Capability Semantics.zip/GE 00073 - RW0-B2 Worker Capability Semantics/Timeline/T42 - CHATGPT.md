## Engineering disposition

**Proceed to a fresh independent read-only re-audit. Do not stage or commit.**

Codex reports a properly bounded test-only repair:

- exactly two untracked test files changed;
- production source and governing documentation remained byte-identical;
- all 4,654 opening nodes were preserved;
- exactly one new relation-test node was added;
- the final candidate has 4,655 nodes;
- the complete suite passed **4,655/4,655**;
- two final provenance runs matched over the same 16-path candidate.

The new audit target is:

```text
Branch:
codex/rw0-b2-wire-protocol-v1

HEAD:
02450d3c99faf0fe7b299b914afaed312421bc8b

Repair report:
/private/tmp/rw0-b2-wire-fourth-repair.oTHtSz/final_provenance.json

Repair-report SHA-256:
bb6629cb14238a29eca2aa2da5f23101e5423ef5cdfd6d793a64a3276982c8d5

Canonical-manifest SHA-256:
a07cf04ba3e0418bbf5688ffbf78480fde79747d4310a5075e6db5dbf25f4aec

Complete-output SHA-256:
0c35a0996ef0ce1a7df09b8b7ae4ad91c3a0f5eea8f8b15e5db8433aa1cd0458

Tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6
```

The unchanged tracked-diff digest is expected: both repaired files are untracked. The re-audit must therefore verify the per-file size and SHA-256 identities from the new canonical manifest, not infer repaired-byte equality from the aggregate tracked diff.

## What remains to be established independently

The fresh audit is narrowly centered on test causality, while also confirming production remained unchanged.

### Literal 64-path integer matrix

The auditor must independently derive the reachable integer inventory rather than trust the repaired test:

```text
CeilingsV1           15
AttemptFenceV1       16
EffectFenceV1        16
WorkerCommandV1      16
DeliveryEnvelopeV1    0
WorkerObservationV1   1
total                 64
```

For every path, it must verify that the test:

- constructs a fresh valid graph;
- changes one slot in one object only;
- actually reaches the intended class and public Wire boundary;
- checks `MAX + 1` and a 1,000-digit integer;
- observes zero owner or Wire reconstruction, canonicalization, digest, payload, and frame calls before rejection;
- does not pass because an earlier object is invalid;
- preserves valid `process_exit_code` values `-255`, `0`, and `255`.

The important adversarial check is selective sensitivity: a broken upper-bound check for `AttemptFenceV1`, `EffectFenceV1`, or `WorkerObservationV1` must make the checked-in matrix fail. A single common early command check must not be able to satisfy the entire oracle.

### Independent pending-frame oracle

The auditor must verify that the 5,000-sibling test owns these literals independently:

```text
maximum pending frames:
5

result caps:
(16_627, 4, 8, 77, 169, 66_770)
```

The expected pending-frame bound may not be derived from production `_CAPS`. The broken control must genuinely show that a production-derived oracle would follow an inflated depth while the literal bound remains `5`.

### Regression closure

The fresh audit must also prove that strengthening the tests did not weaken or reopen any of the earlier findings:

- sealed exception graphs;
- incomplete-object rejection;
- bounded pair and shape traversal;
- safe C2A extraction;
- reconstruct-first classifier behavior;
- duplicate versus conflict semantics;
- cancellation graph orientation;
- exact profile, payload, and work identities;
- authority, privacy, public-surface, and status boundaries.

The accepted architecture still keeps Wire before Capability, and Capability remains a separate later tranche rather than being smuggled into these tests. 

## Fresh re-audit prompt

Start a **new read-only Codex conversation** and send this complete prompt:

:chatgpt-content-reference{index="3"}

Verify the attachment:

```text
Filename:
Coordinator_RW0_B2_Wire_Fourth_Audit_Test_Repair_Fresh_Reaudit_Prompt.txt

Size:
28,636 bytes

SHA-256:
3e821db4478c6c22108f84972bcd77591217942ba3c0bccb4258836599985ac2
```

The prompt requires:

- exact opening and closing provenance;
- exact two-changed/14-unchanged comparison against the preceding target;
- independent reconstruction of the 64-path inventory;
- selective broken controls for Attempt, Effect, and Observation paths;
- independent inspection of the literal pending-frame and result-cap oracles;
- candidate-versus-HEAD node comparison:

```text
candidate:       4,655
HEAD:            4,566
candidate-only:     89
HEAD-only:            0
```

with exact ownership:

```text
Wire values:       11
Wire codec:        16
Wire relations:    49
Wire boundaries:   13
```

- one independent complete-suite run only after source and counterexample inspection are green;
- no mutation, repair, staging, commit, push, PR, remote contact, or Capability implementation.

The only successful outcome is:

```text
ACCEPT
COORDINATOR_RW0_B2_WIRE_FOURTH_AUDIT_TEST_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Exact provenance and green implementation validation do not themselves prove test sufficiency or implementation correctness; those are separate confidence dimensions.  Repairs must be audited in a later fresh, read-only conversation, not in the write-enabled implementation engagement.  Only after an accepted audit should the exact audited files be staged, compared blob-for-blob with the manifest, validated without edits, and committed once. 

### Sources

- Codex fourth-audit test-repair report supplied in this turn.
- Accepted Wire-before-Capability decomposition. 
- Independent audit and repair separation. 
- Provenance limits and commit-gate sequence.  

**Confidence:** High that the candidate is ready for fresh re-audit; deliberately insufficient for commit authorization until the 64-path matrix and literal pending-frame oracle are independently shown to be complete and non-self-confirming.
