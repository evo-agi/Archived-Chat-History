PROMPT_ID

RW0_B2_CAPABILITY_COMPLETE_MARKDOWN_ORACLE_REPAIR_AUDIT_CONTINUATION_V1

TITLE

Coordinator RW0-B2-Capability — continue the same independent audit after
read-only provenance reconciliation

ENGAGEMENT TYPE

Continuation in the same fresh, read-only Codex audit conversation that first
returned `AUDIT_PROVENANCE_MISMATCH` and then returned:

```text
PROVENANCE_BASELINE_READY
```

Do not start a new audit conversation. Do not return to the implementation
conversation. Do not repeat the malformed base64 decode from the preceding
audit prompt.

The parent and every audit subagent remain read-only. No repository mutation,
formatting, cleanup of candidate bytes, dependency installation, staging,
commit, push, PR, merge, tag, release, deployment, remote/service/provider/host
contact, product worker/model invocation, database mutation, migration, or
supporting-repository inspection is authorized.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

PROVENANCE RECONCILIATION — ACCEPTED FOR THIS AUDIT

The provenance-only diagnostic established all of the following without
repository mutation or test execution:

```text
primary category:
AUDIT_PROMPT_EXPECTATION_DEFECT

first failed predicate:
the prior prompt's recipe-source decode requirement

malformed prompt payload decoded size:
48 bytes

malformed prompt payload SHA-256:
dbdbd07a672fa8fcbc6a0cfe765f7b3ab7d99ea7709905bb492600bb30a617e8

candidate-byte impact:
none

validation impact:
none

read-only reconciliation:
yes
```

The malformed prompt payload repeated the expected digest text instead of
carrying base64 for the 3,945-byte recipe. It is not an implementation or
evidence defect.

The diagnostic verified:

- exact repository identity and topology;
- the 406-row final repair evidence index and every indexed entry;
- the final 6,430-byte canonical manifest, SHA-256
  `8d5ed37273a3583104b2fb4f5acee045d7cc18799fdda368d2628e75d8807841`;
- exact equality of all 30 live candidate entries to that manifest;
- absence of a thirty-first path;
- the retained exact recipe source;
- two fresh byte-identical recipe executions;
- equality of both fresh manifests to the retained final manifest;
- complete recipe output of 6,663 bytes, SHA-256
  `e813ead384d3c88eb897d996c32b93245841279e31c002558c12dc36e9611d0c`;
- the opening target and exact two-entry repair delta;
- byte equality of the other 28 entries;
- all 42 closure-ledger records;
- 5,114 final nodes and 209 additions in the two authorized tests;
- the 5,114-case full-suite evidence, exact node mapping, stable
  before/after fingerprints, and absence of a second full-suite attempt;
- the preceding 61-row audit evidence index.

Candidate bytes exactly equal the retained final canonical manifest.
Implementation validation remains bound to those bytes. No evidence
regeneration or implementation-side action is required.

AUTHORITATIVE RECIPE SOURCE

Use only this retained source:

```text
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB/exact_recipe_source.py
```

Required identity:

```text
type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Do not decode, reconstruct, approximate, or use any recipe source from the
malformed preceding prompt.

DIAGNOSTIC EVIDENCE

Retain and cite the existing provenance diagnostic evidence:

```text
/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-independent-audit.RIXPFL/provenance_gate.json
```

Treat that diagnostic as completion of the original audit's opening provenance
gate. Do not rerun implementation, validation, node collection, or the opening
provenance gate merely because the prompt payload was defective.

At final audit closeout, rerun the retained exact recipe twice using the same
safe output-sink redirection discipline, and require equality to the retained
final manifest and the opening diagnostic results.

CONTINUATION POINT

Continue now at the first post-provenance correctness step of the original
audit:

1. launch the four bounded, non-nesting, read-only audit perspectives;
2. inspect the two changed Markdown-oracle tests and their unchanged owners;
3. run independent external Markdown and semantic mutants;
4. reconcile findings;
5. perform candidate/HEAD node comparison;
6. run focused validation only after source/test/mutant inspection is green
   enough;
7. run one independent full suite only if no material blocker is found first;
8. close out provenance and return the required audit verdict.

The audit objective remains unchanged:

- verify the B1 complete-owner Markdown oracle;
- verify the RW0 complete-status Markdown oracle;
- verify the exact 42 prior survivors;
- verify independently generated semantic and structural variants;
- verify false-positive behavior and test-oracle non-weakening;
- verify exact two-file repair scope and 28-entry equality;
- verify no production, documentation, public, privacy, or authority widening.

Do not treat `PROVENANCE_BASELINE_READY` as implementation acceptance. It only
permits correctness inspection against exact bytes.

AUDIT PERSPECTIVES

After the provenance gate, use exactly four bounded, non-nesting, read-only
perspectives when available. No child runs tests or modifies files.

1. Markdown grammar auditor
   - independently implement the finite backtick/tilde fence grammar;
   - independently implement ATX heading recognition with 0–3 spaces,
     delimiter rules, closing hashes, tabs, and 4-space non-heading behavior;
   - independently implement Setext heading recognition;
   - compare visible and all-heading inventories;
   - test unclosed fences, opposite markers, longer closers, hidden duplicates,
     HTML comments if the checked oracle claims them, and non-ASCII whitespace;
   - identify overbroad or underbroad parsing.

2. B1 complete-owner semantic auditor
   - recover all 20 exact audit survivors;
   - verify 20/20 rejection through the same checked positive oracle;
   - independently generate paraphrases and punctuation/Markdown variants;
   - challenge retrieval-cap detection and current-consumer detection;
   - probe before/inside/between/after/tail/table/list/blockquote placements;
   - test historical and unrelated false-positive controls;
   - verify all 3 B1 hidden-heading survivors and generated duplicates reject.

3. RW0 complete-status semantic auditor
   - recover all 16 exact audit survivors;
   - verify 16/16 rejection through the same checked positive oracle;
   - use exact subjects RW0-B1, RW0-B2-Wire, RW0-B2-Capability;
   - challenge future/blocked/deferred/unimplemented and ownership-rollback
     grammars with paraphrases;
   - probe all placements and table/list/blockquote forms;
   - verify all 3 RW0 hidden-heading survivors and generated duplicates reject;
   - verify correct C/D/E/ES future statements remain accepted.

4. Test-evidence, provenance, false-positive, and authority auditor
   - exact two-entry delta and 28-entry equality;
   - 42-record closure ledger completeness;
   - 209-node expansion ownership and non-weakening;
   - external mutant independence versus helper circularity;
   - retained validation and full-suite binding;
   - public/import/privacy/authority non-widening;
   - remaining C/D/E/ES seams.

The parent performs reconciliation, independent external mutants, node
comparison, validation, and closeout. Preserve disagreements.

Every finding must include:

```text
ID
type
severity: critical | high | medium | low | observation
current contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect or pre-existing issue
```

REQUIRED SOURCE AND TEST INSPECTION

Inspect both changed test files completely:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Inspect their unchanged owners:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md
```

Inspect accepted adjacent tests and owners to verify non-regression:

```text
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_wire_boundaries.py

src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py

tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py

src/ge_nwp_coordinator/__init__.py
pyproject.toml
```

Inspect additional Coordinator files only for a concrete dependency and record
why. Do not inspect another repository.

HYPOTHESIS A — FINITE MARKDOWN GRAMMAR

Independently prove or falsify the checked grammar.

### Fences

Exercise:

```text
backtick and tilde openers
run lengths 3, 4, 5, and 6
0, 1, 2, 3 leading ASCII spaces
4-space non-fence control
matching marker required
closer run >= opener run
shorter closer rejected
ASCII space/tab suffix accepted
text suffix rejected
NBSP and EM SPACE suffix rejected
opposite marker does not close
unclosed fence hides through EOF
headings inside fence hidden
```

### ATX headings

Exercise:

```text
levels 1 through 6
0 through 3 leading ASCII spaces
4-space non-heading control
space delimiter
tab delimiter
end-of-line delimiter
missing delimiter
NBSP/EM SPACE non-delimiter
optional closing hashes preceded by ASCII space/tab
unspaced hashes retained in title
ASCII trailing whitespace
internal ASCII whitespace normalization
```

### Setext headings

Exercise:

```text
level 1 and level 2
0 through 3 leading spaces
4-space non-heading
ASCII trailing space/tab
non-ASCII trailing whitespace
empty preceding line
preceding line inside fence
```

### Hidden structure

For each designated B1 and RW0 owner/region heading, externally inject:

```text
visible duplicate ATX
1–3-space ATX duplicate
closing-hash ATX duplicate
tab-delimited ATX duplicate
Setext duplicate
backtick-fenced duplicate
tilde-fenced duplicate
unclosed-fence duplicate
HTML-comment-contained textual duplicate
four-space literal non-heading control
same-title sibling before
same-title sibling after
relocated region
```

Require the checked oracle's policy to be internally consistent. If it claims
commented forms are hidden duplicates, test them causally; if comments are not
part of the finite Markdown-heading grammar, the tests and report must not
overclaim them.

HYPOTHESIS B — B1 COMPLETE-OWNER ORACLE

Recover the exact 20 semantic survivors and 3 hidden-heading survivors from the
preceding audit evidence.

Require:

```text
20/20 exact semantic survivors rejected
3/3 exact hidden-heading survivors rejected
```

Then independently generate additional semantically equivalent mutations that
are not constructed from the checked test's own expected corpus.

Challenge:

- retrieval subject aliases:
  retrieval, retrieval event, retrieval event sequence,
  validate_retrieval_event_sequence;
- bound predicates:
  cap, limit, maximum, budget, work ceiling, units, bounded, capped;
- stale number forms:
  374, 3-7-4, `3` `7` `4`, three hundred seventy four,
  three-hundred-and-seventy-four;
- consumer subjects:
  production consumer, caller, importer, module, cross-module user;
- zero/current/future predicates:
  zero, none, no, absent, future, deferred, pending, planned,
  target-only, unimplemented, not implemented, not current.

Use Markdown emphasis, links, inline code, table delimiters, punctuation,
parentheses, list items, blockquotes, and mixed case.

Place contradictions:

```text
after title
before relation region
inside relation region
between regions
inside consumer region
after consumer region
before next same-or-higher heading
document tail
```

Require no false rejection of:

- the unchanged owner;
- the one current 1285 relation statement;
- Capability's one current sole-consumer statement;
- later C/D/E seams;
- nonauthority statements;
- unrelated numeric values;
- genuinely fenced examples with no designated duplicate heading.

Audit circularity: the oracle must not merely compare against the same literal
mutant corpus used by the parameterized tests. There must be an independent
semantic classifier or independent external mutants that kill equivalent forms.

HYPOTHESIS C — RW0 COMPLETE-STATUS ORACLE

Recover the exact 16 semantic survivors and 3 hidden-heading survivors.

Require:

```text
16/16 exact semantic survivors rejected
3/3 exact hidden-heading survivors rejected
```

Independently challenge exact subjects:

```text
RW0-B1
RW0-B2-Wire
RW0-B2-Capability
B1
B2-Wire
B2-Capability
the implemented B tranche
```

Challenge contradictory predicates:

```text
future
blocked
deferred
unimplemented
not implemented
not current
absent
pending
planned only
target only
earliest unresolved tranche
cannot begin until
awaiting implementation
does not yet exist
```

Challenge ownership rollback for:

```text
durable ingest
evidence membership/completeness
recovery
terminal facts
acceptance latch
physical custody
retrieval delivery
transport
stream plumbing
process launch/supervision
cancellation delivery
provider/CLI/App Server
credentials
live-host proof
ES admission
runtime identity/lifecycle/cancellation
retained results
```

Use prose, tables, lists, blockquotes, emphasis, inline code, links,
punctuation, and mixed case.

Place each class before, inside, after, and at the tail of the current status
region.

Require no false rejection of:

- unchanged current B semantics;
- correct C/D/E future statements;
- correct ES runtime ownership;
- statements saying physical/durable mechanics remain open outside B;
- unrelated uses of blocked/future/deferred.

Again, checked parameterization alone is insufficient. Independently generated
equivalent mutants must fail through the production checked oracle.

HYPOTHESIS D — TEST-ORACLE NON-WEAKENING

The reported repair adds 209 nodes. Independently verify that this expansion is
causal rather than volume-only.

Require:

- every opening 4,905 node retained in exact relative order;
- exactly 209 additions;
- additions only in the two changed test files;
- no removed, renamed, skipped, xfailed, reparameterized, collapsed, or
  reordered existing node;
- no broad exception-swallowing, warning suppression, or weaker assertion;
- each parameterized case maps to a unique semantic or structural mutation;
- no duplicate cases with different IDs but byte-identical mutation and
  placement;
- all 42 exact audit survivors have one-to-one closure-ledger entries;
- generated semantic/structural controls are distinct from the audit corpus;
- false-positive controls assert acceptance, not merely absence of an
  exception from helper setup;
- finite diagnostics do not echo arbitrary mutated documents.

Construct external mutants against the test helpers:

```text
return success for one exact audit-survivor ID
skip all hidden-heading checks
ignore Setext headings
treat 4-space indentation as heading
ignore trailing contradictions
scan only the expected H2
replace exact RW0-B2-Capability subject with RW0-B\b
allow one stale-number word form
allow one zero-consumer paraphrase
allow one ownership-rollback table row
make all false-positive controls vacuously pass
```

The checked tests must kill each mutant for the intended reason.

IMPLEMENTATION-EVIDENCE ASSESSMENT

Review every retained attempt without silently crediting summaries.

Reported implementation evidence:

```text
red gate:
42 exact audit survivors failed as expected
both live-document controls passed

generated controls:
B1 structural       12
B1 semantic         48
B1 false-positive    8
RW0 structural      12
RW0 semantic        77
RW0 false-positive   8

final credited:
selected causal
B1 boundaries
RW0 owner/status
B1 compatibility
Capability/Wire compatibility
owner/static/status compatibility
final collection 5114
full suite attempt 001: 5114/5114
attempt 002: not run
```

Determine:

- whether the red gate uses the exact preceding audit survivor corpus;
- whether every closure-ledger entry maps to a checked final node;
- whether generated controls are independent rather than aliases of the exact
  corpus;
- whether final evidence is bound to the final manifest and node list;
- whether only the two authorized files changed;
- whether the full-suite record is parseable and complete;
- whether no hidden second full-suite attempt exists;
- whether cleanup and the self-excluding index cover all retained evidence.

NODE IDENTITY

Run one candidate collection and one clean external `git archive HEAD`
collection under identical isolated conditions.

Require:

```text
candidate:
5114 unique nodes

clean HEAD:
4655 unique nodes

intersection:
4655

candidate-only:
459

HEAD-only:
0

HEAD order preserved:
true
```

Relative to the 4,905-node opening repair target require:

```text
209 additions
0 removals
0 renames
opening order preserved
```

All additions must belong only to:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Recover and compare the exact final node-list SHA-256 and literal additions from
the indexed final evidence. Do not guess them.

INDEPENDENT VALIDATION

Only after source/test inspection and external mutants are green enough, run
serially beneath the audit root.

For every child:

```text
umask 022 before launch
child numerical umask must be 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Verify every target exists.

Run:

1. selected exact-survivor and generated-control causal nodes;
2. B1 boundaries:
   ```text
   tests/test_rw0_b1_boundaries.py
   ```
3. RW0 owner/status:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   ```
4. B1 compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```
5. Capability/Wire compatibility:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
6. owner/static/status compatibility:
   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   ```

Every credited run must have:

- return code 0;
- zero failures/errors/skips/xfails/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate or unmapped cases;
- matching caller/child umask;
- unchanged candidate fingerprint.

If all inspection and focused validation remain green, run the complete
repository suite exactly once independently with ordinary quiet rendering.

Require:

```text
5114 collected
5114 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

If a deterministic material blocker is found first, the full suite may be
withheld. State that explicitly. Never repair candidate bytes.

PUBLIC, IMPORT, PRIVACY, AND AUTHORITY BOUNDARY

Require:

- no production or documentation byte changed from the opening target;
- no reverse import;
- no package-root export;
- no production caller change;
- no dependency, SQL, migration, schema, catalog, StateStore, or WriterSession
  change;
- no filesystem, process, network, provider, Bridge, ES-call, Git,
  publication, or runtime effect;
- no weakening of accepted Capability or B1 production semantics;
- no weakening or silent broadening of current B1/RW0 owner truth;
- Capability remains private pure supplied-fact semantics;
- source refs/digests remain unauthenticated evidence;
- no permission, acceptance, durable truth, or runtime authority;
- C/D/E and ES remain later owners.

CLOSEOUT

After removing only audit-created transient artifacts:

1. rerun the exact recipe twice with safe sink redirection;
2. require exact equality to the opening final target;
3. require the same manifest, complete output, textual diff, file count,
   per-path hashes, and topology;
4. compare final-repair evidence opening and closing inventories;
5. verify the preceding audit evidence index remains unchanged;
6. verify no operation, lock, staged/unmerged path, cache, bytecode, database,
   journal, archive, build, recorder, or generated-manifest residue;
7. retain all audit evidence beneath the new mode-0700 root;
8. make retained audit files regular, operator-owned, and mode 0400;
9. create a self-excluding evidence index.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low candidate defect remains;
- `BLOCK` for any repairable test, parser, semantic-classifier, evidence,
  validation, privacy, authority, or regression-oracle defect;
- `REJECT` only for a fundamental accepted-architecture contradiction;
- `AUDIT_PROVENANCE_MISMATCH` only for target/evidence identity failure before
  correctness judgment.

If `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMPLETE_MARKDOWN_ORACLE_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or create a PR.

FINAL REPORT

Include:

1. opening and closing identity;
2. exact provenance and two-entry delta;
3. final repair and preceding audit evidence verification;
4. four audit perspectives and disagreements;
5. severity-ranked finding ledger;
6. independent Markdown grammar result;
7. B1 20/20 + 3/3 exact survivor result;
8. B1 independently generated semantic/structural mutant result;
9. RW0 16/16 + 3/3 exact survivor result;
10. RW0 independently generated semantic/structural mutant result;
11. false-positive and non-weakening assessment;
12. implementation-attempt evidence assessment;
13. node comparison and literal additions;
14. independent focused/full validation;
15. public/import/privacy/authority assessment;
16. closeout guards;
17. separate provenance, validation, and implementation confidence.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
