## Engineering disposition

**Accept the audit’s `BLOCK`. Do not stage or commit.**

This is not a rejection of the B2 decomposition or Wire protocol design. The exact candidate is provenance-valid, remains authority-bounded, and preserves its private/no-I/O scope. The audit instead found concrete implementation defects in security, fail-closed construction, hostile-input accounting, classifier semantics, current-status integration, and causal test coverage.

The result is especially credible because the failures closely match the risks recorded before implementation: decoder precedence, preconstruction work, noncausal mutants, process-fact collapse, and self-attestation were explicitly forecast as likely independent-audit findings. 

The candidate must return to the **existing workspace-write implementation conversation** for one bounded repair. Changed bytes then require another fresh read-only audit; repair and independent audit remain separate engagements. 

## Finding disposition

### Definitive High defects

**1. Foreign exception leakage**

`raise ... from None` suppresses displayed chaining but does not erase `__context__`. The decoder can therefore retain hostile JSON or UTF-8 payloads through `JSONDecodeError.doc` or `UnicodeDecodeError.object`.

The repair must ensure every public `RW0WireProtocolError` has:

```text
__cause__   is None
__context__ is None
```

The public error must be raised only after leaving the foreign `except` block and clearing hostile exception and payload references. This applies to decoder, nested reconstruction, relation, and classifier translations.

**2. Uninitialized exact objects enter public logic**

The private immutable base still permits ordinary empty construction. An exact nominal request object can consequently reach the classifier without initialized slots and produce raw `AttributeError`.

The repair must:

- disable normal construction for all four Wire value classes;
- retain the controlled private constructor;
- revalidate complete initialization and digest before semantic field access;
- fail closed when an explicit `object.__new__(Class)` bypass produces an incomplete instance;
- never expose raw slot errors.

### Definitive Medium defects

**3. Hostile-input work is incompletely bounded**

The repair needs all of the following:

- bound key length before `.lower()` or privacy-fragment scanning;
- cache lowercase once per bounded key;
- meter raw JSON object pairs before dictionary collapse;
- preserve duplicates in the parser representation until duplicate handling;
- cap collections before enqueueing children;
- avoid bulk-enqueueing attacker-sized structures;
- calculate shape exactly once;
- remove the second traversal over the hostile tree.

I have frozen:

```text
MAX_SOURCE_MAPPING_KEY_CHARS = 37
```

That is the maximum literal length among the new source-claim fields and privacy fragments. A 38-character key fails before normalization.

**4. Distinct exits are conflicts, not duplicates**

The repaired definitions are:

```text
duplicate_fact
```

for a repeated identity—same ref, same digest, or the same value object;

```text
conflicting_fact
```

for two distinct identities occupying a singleton semantic slot.

Two distinct `process_exited` facts, whether they report equal or different exit codes, are therefore:

```text
invalid / conflicting_fact
```

Acknowledgement plus rejection is also `conflicting_fact`.

**5. Current status contradicts itself**

Four current documents still say exact framing is deferred immediately before saying the private Wire codec exists.

They must distinguish:

- **implemented:** private NWPF v1 representational framing, canonical codecs, result grammar, supplied source-claim values, and pure classification;
- **deferred:** physical transport and stream framing, process plumbing, allocation enforcement, supervisor/worker mechanics, ES wrappers, persistence, authentication, Capability, credentials, and live execution.

### Resolved audit ambiguities

**Cancellation graph:** the explicit supplied cancellation effect fence and cancellation delivery are the authoritative graph. Request and response are each validated against that same graph. Any mismatch is deterministically:

```text
invalid / cancellation_graph_mismatch
```

`unrelated_fact` remains for non-cancellation facts with unrelated ordinary lineage.

**Privacy taxonomy:** `privacy_forbidden_material` remains a direct source-claim construction/relation reason. It is not added to the fixed NWPF decoder-error list because cancellation-request and process-observation values are not command/result frame payloads. Oversized mappings may fail cardinality or key-length checks before privacy scanning.

**IPv4 rejection:** it applies to every new B2-defined ref field. It does not retroactively change existing nested C2A ref semantics.

## Test requirements

The audit showed that the existing green suite lacks the necessary causality. The repair must add tests for:

- complete exception cause/context and traceback-local payload absence;
- ordinary and bypass construction of all four values;
- exact 5,898-byte command and 16,627-byte result payloads using fully related real fixtures;
- actual cap and one-over behavior, not arithmetic alone;
- raw duplicate-pair metering;
- key-length and privacy precedence;
- one-pass shape accounting;
- C2A-only mutations that pass broken local checks but fail the owning C2A relation;
- distinct conflicting exits;
- both orientations of cancellation graph disagreement;
- the full classifier precedence matrix;
- every new B2 ref-family IPv4 mutation;
- corrected current-status ownership.

New test nodes may appear only in the four new Wire test files. Existing contract tests may have their bodies strengthened but may not gain new node identities.

## Scope

The repair remains inside the existing 16 candidate paths. No seventeenth path is authorized.

The following must remain exact:

```text
profile_ref:       rw0-wire-nwpf-v1
profile bytes:     4,021
profile digest:    470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454
command cap:       5,898
result cap:        16,627
hostile units:     23,746 / 66,770
```

Any need to change those identities, C2A/B1 bytes, source ownership, a public surface, schema, migration, dependency, or runtime contract is a stop condition rather than an ordinary repair.

## Next action

Send this complete prompt to the **existing workspace-write RW0-B2-Wire implementation conversation**:

:chatgpt-content-reference{index="3"}

Verify the attachment:

```text
Filename:
Coordinator_RW0_B2_Wire_First_Audit_Repair_Prompt.txt

Size:
31,875 bytes

SHA-256:
ab12f362023d84528aea12653d3b1b47c4410ac1ac5c63efff882155e3ae9999
```

The required successful result is:

```text
COORDINATOR_RW0_B2_WIRE_FIRST_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

After that result, start a **new** read-only Codex conversation for the fresh re-audit. Do not reuse the first audit’s acceptance judgment, and do not proceed directly to staging or commit. An accepted audit is required before the staged-blob and committed-blob gates. 

### Sources

- Codex independent-audit report supplied in this turn.
- Pre-implementation forecast of decoder, work-accounting, causal-test, and process-fact risks. 
- Governed Execution repair and fresh-audit separation. 
- Provenance lifecycle from independent audit to commit gate. 

**Confidence:** High that the audit’s two High and core Medium findings are real; high that they are repairable without redesigning Wire or widening the 16-path boundary; moderate on whether the current cap fixtures can reach the literal maxima without exposing one additional source-level defect.
