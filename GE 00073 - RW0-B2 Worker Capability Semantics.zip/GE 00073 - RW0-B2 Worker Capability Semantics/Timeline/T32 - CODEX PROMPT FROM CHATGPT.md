PROMPT_ID

RW0_B2_WIRE_SECOND_AUDIT_REPAIR_V1

TITLE

Coordinator RW0-B2-Wire — repair the second independent-audit findings and
prepare exact bytes for a fresh re-audit

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing
`codex/rw0-b2-wire-protocol-v1` implementation conversation.

Do not create or resume subagents. You are the sole repository writer.

This is a bounded repair after a fresh read-only audit returned `REJECT`.
The audit did not identify a Wire-architecture, profile, authority, privacy,
public-surface, or Capability-seam contradiction. Treat the result as a
blocking implementation verdict, not permission to redesign the accepted
protocol.

This is not reconnaissance, Capability implementation, independent audit,
commit gate, publication gate, merge, deployment, or runtime proof.

Do not stage, commit, push, create or modify a PR, merge, tag, release, deploy,
contact a remote, invoke a product worker/model/provider, modify a supporting
repository, or install dependencies.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Close exactly the second-audit defects:

1. remove bulk sibling enqueue from hostile JSON shape validation;
2. prevent unbounded C2A `to_mapping()` expansion before Wire validation;
3. reconstruct and validate every classifier fact before duplicate or conflict
   semantics inspect refs/digests;
4. add causal coverage for those defects and every omitted public value method;
5. preserve all previously closed first-audit findings;
6. preserve the fixed Wire profile, frame bytes, caps, work constants,
   source-owner split, classifier reason inventory/precedence, 16-path boundary,
   and Capability nonimplementation.

Return an exact-green 16-path candidate for another fresh read-only audit.

OPENING TARGET

Before any mutation, require exactly:

- physical root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- subject:
  `feat: implement RW0-B1 pure phase-entry semantics (#3)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- dirty paths:
  `16`
- tracked modifications:
  `10`
- untracked additions:
  `6`
- staged/unmerged:
  `0/0`
- every candidate path:
  regular mode `0644`
- no Git operation, lock, repository cache, bytecode, database, journal,
  archive, build, generated manifest, or recorder residue
- `git diff --check`:
  clean.

Immutable opening target:

```text
/private/tmp/rw0-b2-wire-repair.q4veCL/final_provenance_001.manifest.json
```

Required opening identities:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe source size:
3_945 bytes

recipe source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6

canonical-manifest SHA-256:
8c462b8fa4185e6795e6ce667da80f388a0109534da4263e6a47c3e4ab37b662

complete-output SHA-256:
9a1211f373b3995318b71ce3458f4f3895d56899ea8c110cf140d48d4a29a5be

file count:
16
```

Retained evidence roots that must remain unchanged:

```text
/private/tmp/rw0-b2-wire-v4.b4HlRt
/private/tmp/rw0-b2-wire-independent-audit.hX8xit
/private/tmp/rw0-b2-wire-repair.q4veCL
/private/tmp/rw0-b2-wire-re-audit.dU0ieG
```

EXACT RECIPE SOURCE

Decode this base64 only into a new external repair evidence root, verify exact
size and SHA-256, and retain it mode `0400`:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

Execute the exact source unchanged with only its exact historical
`Path.write_bytes` sink redirected into the new evidence root. Do not overwrite
pre-existing fixed-path evidence.

OPENING PROVENANCE AND NODE GATE

Before editing:

1. lstat every component of the immutable target, all four retained evidence
   roots, the new repair root, and copied recipe;
2. require safe ownership, no symlink traversal, regular files, and mode-0700
   evidence roots;
3. verify the immutable target’s exact bytes and hash;
4. run the exact recipe twice;
5. require both complete outputs and manifests to be byte-identical and equal
   the immutable target;
6. verify every live candidate entry by path, classification, type, mode, size,
   and SHA-256;
7. verify protected complement equality to HEAD;
8. collect the complete opening node list exactly once under isolated external
   paths;
9. require exactly `4_644` unique opening nodes.

Stop before mutation on any mismatch. Do not reset, clean, or reconstruct the
candidate.

SECOND-AUDIT FINDINGS

Treat these as authoritative repair inputs:

```text
F8  Medium  hostile shape traversal bulk-enqueues all siblings after over-cap
F9  Medium  C2A to_mapping expands tampered alias/cycle graphs before Wire checks
F10 Medium  classifier reads raw identity slots before reconstructing all facts
F11 Medium  tests omit public value methods and both hostile-work defects and
             codify malformed-fact duplicate behavior
```

The audit independently confirmed that the following remain closed:

- foreign exception cause/context/traceback payload isolation;
- ordinary constructor disabling and core bypass handling;
- valid-fact duplicate versus singleton-conflict semantics;
- status wording;
- ordinary cancellation mismatch orientation;
- request/response authority ownership;
- C2A relation composition;
- profile and cap identities;
- package/public/dependency/schema/migration/nonimplementation boundaries.

ENGINEERING DECISIONS — FROZEN FOR THIS REPAIR

A. Pair accounting during parse

Keep the pair-preserving parse model and frozen decoder precedence.

Use one private parse-accounting object shared across the JSON parse:

- `raw_pair_count`;
- `duplicate_seen`;
- bounded key-shape flags needed by the existing decoder;
- no hostile values retained in public errors.

The `object_pairs_hook` must:

1. inspect every completed object’s raw pairs;
2. charge every pair, including duplicates;
3. record duplicates without raising;
4. return the private pair-preserving object representation;
5. allow a later JSON syntax failure to remain `json_token_invalid`.

After successful syntax parsing:

1. `duplicate_key` remains earlier than structural/root failures;
2. structural/root failure remains earlier than `work_limit_exceeded`;
3. no later tree traversal is required merely to rediscover duplicates.

Do not change the profile’s pair, payload, or work constants.

B. Bounded iterator/descent shape validation

Replace `_shape_work()` or equivalent bulk pending-node logic with bounded
iterator/descent frames.

Requirements:

1. Never enqueue every sibling into one pending list.
2. Each live traversal frame contains only:
   - the current container;
   - an iterator/index over that container;
   - current depth;
   - bounded per-object seen-key state when needed;
   - a bounded output builder only while the candidate remains structurally
     admissible.
3. The pending frame stack is proportional to nesting depth, never sibling
   cardinality.
4. Check collection cardinality before iterating or building children.
5. Process one child at a time.
6. On the first structural overflow:
   - remember `invalid_root_or_scalar`;
   - stop building the ordinary output tree;
   - do not materialize pending siblings;
   - rely on the parse-accounting duplicate flag for the earlier duplicate
     precedence.
7. Do not descend beyond the frozen depth bound after structural invalidity.
8. Preserve exactly one shape traversal.
9. The scan result may contain a private `max_pending_frames` diagnostic for
   direct causal tests; it is not a public protocol field or profile input.
10. For an over-cap 5,000-sibling payload beneath the byte cap, the maximum
    pending-frame count must remain bounded by the frozen nesting limit plus
    one, never by 5,000.

The payload cap remains the physical parser bound. This repair is about the
promised deterministic traversal bound.

C. Wire-owned safe C2A extraction seam

Do not call a caller-supplied C2A value’s generic `to_mapping()` before Wire
has proved that its internal graph is safe.

Implement literal, private, class-specific safe extraction for exactly the C2A
classes Wire currently consumes:

```text
CeilingsV1
AttemptFenceV1
EffectFenceV1
WorkerCommandV1
DeliveryEnvelopeV1
WorkerObservationV1
```

Requirements:

1. exact root type only; subclasses reject;
2. require every expected slot to exist before semantic use;
3. inspect the committed class `_FIELDS` inventory and pin exact equality in
   tests;
4. extract each field directly from the exact object;
5. accept only exact built-in scalar/container types allowed by that field;
6. require tuple/list cardinality before member iteration;
7. require exact scalar member types before copying;
8. permit only the fixed one-level nested `CeilingsV1` object where the owning
   C2A class permits it;
9. build a fresh bounded mapping manually;
10. invoke the owning C2A `from_mapping`/validator only after safe extraction;
11. do not call the input object’s `to_mapping()` or C2A `_external_value()`
    during preflight;
12. unknown exact classes, missing slots, arbitrary mappings/lists, custom
    iterables, nested tuples where scalar members are required, cycles, and
    alias DAGs fail sealed `invalid_field_value` before generic C2A expansion;
13. preserve valid maximum C2A objects and all owning C2A relations.

This is an implementation-defense seam, not a new C2A schema, B2 profile field,
authority fact, or public API.

Do not import B1 and do not change C2A.

Causal hostile probes must prove:

- shared tuple DAGs at depths 8, 12, and 16 in a tampered command field fail
  before any C2A `to_mapping`/`_external_value` call;
- a self-referential or recursively tampered `CeilingsV1` fails without
  `RecursionError`;
- the number of direct field/member inspections remains bounded by the literal
  accepted class shape;
- valid largest current C2A objects still reconstruct and validate.

D. Reconstruct-all-before-classifier semantics

The classifier’s first semantic phase must be:

```text
exact type/cardinality preflight
-> reconstruct and validate every supplied fact
-> only then inspect duplicate/conflict/lineage/cancellation semantics
```

Requirements:

1. Capture original Python object identities in a separate bounded list before
   reconstruction, but do not use them yet.
2. Reconstruct/validate every:
   - worker-result observation;
   - adapter observation;
   - request;
   - process observation;
   - supplied fence/delivery input required by the classifier.
3. Any malformed, incomplete, tampered, wrong-digest, or relation-invalid fact
   returns:
   ```text
   invalid / invalid_input
   ```
   before duplicate/ref/digest/kind analysis.
4. Only after all facts are safe:
   - repeated original object identity -> `duplicate_fact`;
   - repeated safe ref -> `duplicate_fact`;
   - repeated safe digest -> `duplicate_fact`;
   - distinct valid identities occupying one singleton kind ->
     `conflicting_fact`.
5. A partial or tampered fact paired with a colliding valid fact must remain
   `invalid/invalid_input`, not `duplicate_fact`.
6. Preserve the frozen reason/tie order for valid facts.
7. Preserve the supplied cancellation graph as authoritative.
8. Preserve pure cancellation mismatch behavior and the fixed profile
   precedence. Do not make cancellation mismatch override an earlier valid
   duplicate/conflict/unrelated-non-cancellation condition.

E. Complete public-method fail-closed behavior

For self-digest values, all of these methods must revalidate complete exact
state before slot access and fail sealed `invalid_field_value` on an incomplete
or bypass-created exact instance:

```text
to_mapping()
identity_mapping()
canonical_identity_bytes()
computed_digest()
```

For non-self-digest values, every public mapping/relation/encoder/classifier
boundary must perform equivalent complete matrix/state validation.

No raw `AttributeError`, `RecursionError`, foreign exception, hostile value, or
uninitialized slot may escape.

F. Fixed identities and boundaries

The following remain exact:

```text
profile_ref:
rw0-wire-nwpf-v1

profile identity bytes:
4_021

profile digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454

command payload/frame:
5_898 / 5_906

result payload/frame:
16_627 / 16_635

hostile units:
23_746 / 66_770

source mapping key maximum:
37

frame key maximum:
29
```

No profile manifest, frame, schema, field, source-kind, classification, reason,
or precedence change is authorized.

G. Governing document

Update only the detailed Wire owner as needed to state:

- raw-pair parse accounting is completed during parse;
- shape traversal uses bounded iterator frames and never bulk-enqueues siblings;
- C2A values cross a literal safe-extraction seam before owning reconstruction;
- classifier facts are all reconstructed before duplicate/conflict semantics;
- malformed facts always select `invalid_input` before duplicate semantics.

Do not modify the synchronized current-status documents; the audit found their
status wording closed.

MAXIMUM REPAIR ALLOWLIST

The repository may change only these six existing candidate paths:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

The other ten candidate paths must remain byte-identical to the opening
manifest.

No seventeenth dirty path and no new repository file are authorized.

TEST-FIRST RED GATE

Before production or documentation repair:

1. add new tests only in the four existing Wire test files;
2. preserve every opening node;
3. run one selected red gate against the opening source and document bytes;
4. require deterministic expected failures on the intended predicates;
5. capture repository fingerprints after test edits and before/after the red
   run;
6. do not edit source or docs until the red evidence is retained.

The selected red set must include at least:

1. 5,000 scalar siblings under the result byte cap, proving pending-frame
   amplification;
2. a duplicate raw pair before a later syntax error, proving syntax still wins;
3. shared tuple DAG command tampering at depths 8, 12, and 16 while a spy proves
   zero C2A `to_mapping`/`_external_value` calls are required for rejection;
4. self-referential/tampered `CeilingsV1` without `RecursionError`;
5. partial adapter fact alone and paired with a colliding valid fact;
6. partial request alone and paired with a colliding valid fact;
7. partial process fact alone and paired with a colliding valid fact;
8. complete fact with tampered colliding digest;
9. incomplete self-digest values calling:
   - `to_mapping`;
   - `identity_mapping`;
   - `canonical_identity_bytes`;
   - `computed_digest`.

A red is causal only if fixture setup and earlier predicates remain valid.

FINAL CAUSAL TEST REQUIREMENTS

A. Shape traversal

- maximum valid command/result shape accepted;
- each structural maximum plus one rejected;
- 5,000-sibling over-cap payload has bounded pending-frame depth;
- no `extend`, bulk child stack, or second shape traversal;
- duplicate raw pairs remain charged by parse accounting;
- later syntax error still outranks earlier duplicate;
- duplicate still outranks shape failure after successful syntax;
- shape failure still outranks injected work overflow.

B. Safe C2A extraction

For every consumed C2A class:

- literal extractor field inventory equals committed `_FIELDS`;
- valid maximum/current object reconstructs identically;
- every exact field is copied with exact built-in type;
- wrong slot type fails before owning reconstruction;
- missing slot fails sealed;
- subclass fails;
- custom iterable/mapping fails;
- nested tuple DAG and cycle probes are bounded;
- spies prove hostile rejection occurs before input `to_mapping`,
  `_external_value`, or arbitrary iteration;
- owning `from_mapping` and owning relations remain causally necessary.

C. Classifier validation order

- malformed fact alone -> `invalid_input`;
- same malformed fact repeated -> `invalid_input`;
- malformed fact colliding with valid fact -> `invalid_input`;
- tampered digest colliding with valid fact -> `invalid_input`;
- same valid object repeated -> `duplicate_fact`;
- distinct valid object with same ref -> `duplicate_fact`;
- distinct valid object with same digest -> `duplicate_fact`;
- distinct valid singleton facts -> `conflicting_fact`;
- same-code and different-code exits remain conflicts;
- frozen cancellation and higher-tier precedence remains exact.

D. Public method matrix

Mechanically cover every applicable class/method/boundary combination, including:

```text
to_mapping
identity_mapping
canonical_identity_bytes
computed_digest
wire encoders
wire result relation
request relation
process relation
classifier
```

Use bypass-created exact objects, missing slots, and tampered self-digests.
Require sealed errors with null cause/context and no hostile traceback-local
leak.

E. Previous closure preservation

Retain all prior direct tests for:

- exception graph isolation;
- exact maxima and semantic decrement;
- key bounds/privacy;
- C2A relation causality;
- duplicate versus conflict for valid facts;
- cancellation graph orientation;
- classifier precedence;
- profile identity;
- status/non-authority boundaries.

NODE IDENTITY

Opening collection is expected to be `4_644`.

After repair:

- every opening node remains in relative order;
- no opening node is removed, renamed, skipped, xfailed, collapsed, or
  reparameterized;
- every new node belongs to exactly one of the four Wire test files;
- no new node belongs to an existing non-Wire test file;
- report the literal final count and full addition list; do not predeclare the
  number of additions.

VALIDATION POSTURE

Create one new external operator-owned, non-symlink, mode-0700 repair root.

For every pytest child use:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
actual caller/child numerical umask equality
```

Retain exact argv, environment, timing, return code, stdout/stderr, JUnit,
structured counts, and repository fingerprints.

FINAL VALIDATION ORDER

After repair and final node collection:

1. selected new causal tests;
2. Wire values;
3. Wire codec;
4. Wire relations;
5. Wire boundaries;
6. all four Wire files together;
7. corrected C2A/C2A1 compatibility:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_c2a_first_slice_semantic_protocol_contract.py
   tests/test_c2a_effects_and_recovery.py
   ```
8. B1:
   ```text
   tests/test_rw0_b1_*.py
   ```
9. static/public:
   ```text
   tests/test_c2a_nonimplementation.py
   tests/test_runtime_non_authority.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_b2a_writer_session_contract.py
   tests/test_codex_agent_config.py
   ```
10. status/docs:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```
11. `git diff --check`;
12. exact path/mode/protected/public/import/residue/operation/lock guards;
13. complete suite attempt 001 exactly once.

Every final focused gate and complete suite must have:

- return code 0;
- zero failures, errors, skips, xfails, warnings;
- empty stderr;
- parseable JUnit;
- no duplicate, ambiguous, or unmapped cases;
- unchanged candidate fingerprint before/after.

COMPLETE-SUITE REPAIR POLICY

If complete-suite attempt 001 fails:

- preserve all evidence;
- repair only when every failure is candidate-caused;
- remain inside the six repair paths and original 16-path candidate;
- preserve fixed profile/caps/authority and final node identities;
- weaken no test;
- rerun affected and dependent focused gates;
- run complete-suite attempt 002 exactly once.

No third complete-suite attempt is authorized.

FINAL PROVENANCE

After final green validation and cleanup:

1. require exact topology:
   - 16 dirty paths
   - 10 tracked modifications
   - 6 untracked additions
   - 0 staged
   - 0 unmerged;
2. run the exact recipe twice;
3. require byte-identical complete outputs and manifests;
4. require exactly the original 16 paths;
5. compare against the opening target;
6. require exactly the six authorized repair paths to differ unless a smaller
   subset sufficed;
7. require the other ten entries to remain byte-identical;
8. prove every protected path equals HEAD;
9. retain final recipe source, complete-output hash, textual-diff hash,
   manifest hash, complete manifest, node delta, validation results, and guards.

STOP CONDITIONS

Stop without further mutation if:

- opening provenance differs;
- retained evidence changed;
- a seventh repair path or seventeenth candidate path is needed;
- C2A/B1/public/dependency/schema/migration/runtime bytes must change;
- profile bytes, digest, caps, source ownership, classifications, reasons, or
  precedence must change;
- safe extraction cannot preserve every valid current C2A object;
- a required owning C2A relation cannot remain authoritative;
- tests require skip/xfail/deletion/renaming/weakening;
- existing node identity changes;
- validation or provenance remains unstable.

CLOSEOUT TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_WIRE_SECOND_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only if all findings are mechanically closed, final validation is exact-green,
provenance is stable, and no stop condition fires.

The report must include:

1. opening identity and immutable target;
2. per-finding repair;
3. red evidence;
4. exact changed paths;
5. safe C2A extractor inventory and bounded hostile probes;
6. shape-scan pending-frame evidence;
7. classifier reconstruct-first matrix;
8. public method matrix;
9. node delta;
10. every validation attempt;
11. final provenance and guards;
12. separate provenance, validation, and implementation confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
PRIOR_AUDIT_EVIDENCE_PRESERVED
```
