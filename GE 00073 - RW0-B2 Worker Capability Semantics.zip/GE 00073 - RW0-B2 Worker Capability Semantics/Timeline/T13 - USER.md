Here is Codex's response:

RW0\_B2\_WIRE\_SCHEMA\_FREEZE\_READY\
RW0\_B2\_CAPABILITY\_SEAM\_BOUNDED

## Baseline and decision

Opening and closeout checks matched `trunk_dev`, HEAD `02450d3c99faf0fe7b299b914afaed312421bc8b`, tree `0b5394c591bd277d56797794f71af954ccb93846`, sole parent `bf68a5232bff1b412c9414c076d82cab18c8e0aa`, subject `feat: implement RW0-B1 pure phase-entry semantics (#3)`, and `origin/trunk_dev` at `0/0`. There was one worktree, no worktree or index change, and no detected Git operation, lock, or specified residue.

The supplied B2 schemas and bounded hostile-input model are compatible with the inspected owners. **READY freezes a private, pure Wire implementation contract; it does not authorize process contact or Capability implementation.**

## Values and relations

Use the existing C2A safe-ref syntax (`R`, 1–96 ASCII characters with C2A’s forbidden prefixes), lowercase 64-hex digest (`H`), and whole-second UTC timestamp (`T`). Every field has an exact built-in type. Each value is final, slotted, immutable, non-pickleable, and has content-free `repr`/`str`. `to_mapping()` returns fresh safe built-ins. Unknown fields precede missing fields. A self-digest is SHA-256 of `domain UTF-8 || NUL || compact sorted-key UTF-8 identity JSON`; the final digest field is excluded.

| ValueOrdered fields and typesDigest domain |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |                                                                                |
| ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------ |
| `RW0WireCancellationRequestObservationV1`  | `schema_id` constant; `request_observation_ref` R; `source_kind` enum; `source_ref` R; `source_invocation_ref` R; `evidence_ref` R; `evidence_digest` H; `program_ref`, `program_version_ref`, `accepted_intent_revision_ref`, `work_item_ref`, `work_item_revision_ref`, `semantic_attempt_ref`, `candidate_ref`, `command_ref` R; `command_digest` H; `attempt_fence_ref` R; `attempt_fence_digest` H; `cancellation_effect_intent_ref`, `cancellation_effect_fence_ref` R; `cancellation_effect_fence_digest` H; `cancellation_delivery_attempt_ref` R; `cancellation_delivery_envelope_digest` H; `target_effect_intent_ref`, `target_effect_fence_ref` R; `target_effect_fence_digest` H; `target_delivery_attempt_ref` R; `target_delivery_envelope_digest` H; `observed_at` T; `request_observation_digest` H. **30 fields.** | `governed-execution.nwp-rw0-wire-cancellation-request-observation.v1.identity` |
| `RW0WireProcessObservationV1`              | `schema_id` constant; `process_observation_ref` R; `source_kind` enum; `source_ref`, `source_invocation_ref`, `evidence_ref` R; `evidence_digest` H; `event_kind` enum; `program_ref`, `program_version_ref`, `accepted_intent_revision_ref`, `work_item_ref`, `work_item_revision_ref`, `semantic_attempt_ref`, `candidate_ref`, `command_ref` R; `command_digest` H; `attempt_fence_ref` R; `attempt_fence_digest` H; `effect_intent_ref`, `effect_fence_ref` R; `effect_fence_digest` H; `delivery_attempt_ref` R; `delivery_envelope_digest` H; `observed_at` T; `process_observation_digest` H. **26 fields.**                                                                                                                                                                                                                  | `governed-execution.nwp-rw0-wire-process-observation.v1.identity`              |
| `RW0WireWorkerResultV1`                    | `observations`: exact tuple of two or three `WorkerObservationV1` values. No ref, schema field, or digest.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           | None                                                                           |
| `RW0WireProcessResultClassificationV1`     | `classification`, `reason`: exact closed strings. No ref or digest.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | None                                                                           |

The request schema ID is `governed-execution.nwp-rw0-wire-cancellation-request-observation.v1`; its `source_kind` is exactly `direct_local_adapter | es_adapter`. The process schema ID is `governed-execution.nwp-rw0-wire-process-observation.v1`; its `source_kind` is exactly `supervisor | operating_system`, and `event_kind` is exactly `resource_limit_exceeded | signal_delivered`.

`command_ref`/`command_digest` on the request are **originating author-command lineage**. C2A has no second cancellation command. The request binds the semantic target effect, fence, and known target delivery; it has no field purporting to identify the physical target process invocation. Its own `source_invocation_ref` names the source invocation claiming to have issued the request. Shape and self-digest do not authenticate that claim. [C2A current-effect delivery (line 686)](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2a-first-slice-semantic-protocol-contract.md:686>) · [delivery fields (line 1701)](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py:1701>)

Freeze these private signatures in substance, with exact objects and tuples at their boundaries:
```
wire_profile_mapping() -> dict[str, object]

encode_wire_command_frame(
    *, command: WorkerCommandV1, delivery: DeliveryEnvelopeV1,
    attempt_fence: AttemptFenceV1, author_effect_fence: EffectFenceV1
) -> bytes
decode_wire_command_frame(
    frame: bytes, *, attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1
) -> tuple[WorkerCommandV1, DeliveryEnvelopeV1]

encode_wire_result_frame(
    *, result: RW0WireWorkerResultV1, command: WorkerCommandV1,
    delivery: DeliveryEnvelopeV1, attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1
) -> bytes
decode_wire_result_frame(
    frame: bytes, *, command: WorkerCommandV1,
    delivery: DeliveryEnvelopeV1, attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1
) -> RW0WireWorkerResultV1

validate_wire_result_relation(
    *, result: RW0WireWorkerResultV1, command: WorkerCommandV1,
    delivery: DeliveryEnvelopeV1, attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1
) -> None
validate_wire_cancellation_request_relation(
    *, request: RW0WireCancellationRequestObservationV1,
    author_command: WorkerCommandV1, attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1,
    target_effect_fence: EffectFenceV1,
    target_delivery: DeliveryEnvelopeV1,
    cancellation_effect_fence: EffectFenceV1,
    cancellation_delivery: DeliveryEnvelopeV1
) -> None
validate_wire_process_observation_relation(
    *, observation: RW0WireProcessObservationV1,
    author_command: WorkerCommandV1, attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1,
    target_effect_fence: EffectFenceV1,
    target_delivery: DeliveryEnvelopeV1
) -> None
classify_wire_process_result(
    *, command: WorkerCommandV1, delivery: DeliveryEnvelopeV1,
    attempt_fence: AttemptFenceV1,
    author_effect_fence: EffectFenceV1,
    result: RW0WireWorkerResultV1 | None,
    result_failure: RW0WireProtocolError | None,
    adapter_observations: tuple[WorkerObservationV1, ...],
    request: RW0WireCancellationRequestObservationV1 | None,
    process_observations: tuple[RW0WireProcessObservationV1, ...],
    cancellation_effect_fence: EffectFenceV1 | None,
    cancellation_delivery: DeliveryEnvelopeV1 | None
) -> RW0WireProcessResultClassificationV1
```

The request relation calls C2A `validate_delivery_relation` for the author target and separately for the cancellation delivery with `cancellation_target=target_effect_fence`. It checks the cancel fence’s immutable target tuple and all exposed program, work, attempt, candidate, command, and fence coordinates. The result and process relations use the actual supplied fences. For this **author-result classifier**, the request target is `author_candidate`; broader cancellation targets requiring a capsule remain outside this relation. No relation proves source authenticity, physical request delivery, process action, or authority. [C2A cancellation target (line 3656)](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py:3656>) · [C2A delivery relation (line 3747)](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py:3747>)

## Frame, decoder, and work

The eight header bytes are `4E 57 50 46 01 01|02 LL LL`: magic `NWPF`, version `1`, kind `1` command or `2` result, then unsigned big-endian payload length. Exactly one frame is accepted. The command root is exactly `{"command":<complete WorkerCommandV1>,"delivery":<complete DeliveryEnvelopeV1>}`; the result root is exactly `{"observations":[...]}`. Neither root nor frame has a semantic ref or self-digest.

Result sequences are exactly `(worker_started, worker_completed)` and `(worker_started, candidate_captured, worker_completed)`. All observations have `source_kind=worker`, one source ref and invocation ref, distinct observation refs and digests, exact common lineage, and applicable C2A relations. Capture binds the preassigned candidate. Tuple position establishes protocol order; timestamps do not. [C2A observation relation (line 3993)](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py:3993>)

The decoder accepts exact built-in `bytes`, strict UTF-8 without BOM, and compact sorted-key JSON (`ensure_ascii=False`, `allow_nan=False`, separators `(",", ":")`, no Unicode normalization). It rejects duplicate keys before constructing ordinary dicts, floats/constants, noncanonical spellings, and integer tokens outside the B2 `0..9_223_372_036_854_775_807` bound **before** Python integer conversion. Owning zero-only fields remain zero. Syntax/token failures take precedence over a duplicate found earlier in an otherwise unfinished document: parse the bounded pair tree fully, then report duplicates before constructing dicts. Re-encoded payload bytes must equal input bytes.

The sealed decoder reasons, in priority order, are:
```
invalid_outer_type
short_header
bad_magic
unsupported_version
unsupported_kind
declared_length_over_cap
truncated_payload
trailing_data
invalid_utf8
bom_forbidden
json_token_invalid
duplicate_key
invalid_root_or_scalar
unknown_field
missing_field
nested_record_invalid
noncanonical_payload
relation_mismatch
work_limit_exceeded
```

Stage 13 includes depth, container, key, exact-type, and scalar-shape violations. Separate construction/relation failures use the closed reasons `invalid_field_type`, `invalid_field_value`, `unknown_field`, `missing_field`, `invalid_length_or_cardinality`, `digest_mismatch`, `privacy_forbidden_material`, and `relation_mismatch`. `RW0WireProtocolError` exposes only a closed `.reason`; string and repr are constant and foreign chains are suppressed. The final work reason covers an otherwise admissible operation with an injected excess charge; bounded syntax and structural checks retain their earlier priority.

Depth counts object/list containers along the longest root-to-leaf path, with root depth 1. A container-valued list member is charged **as a container once**; the “scalar/list element” term charges scalar leaves, including scalar elements of evidence and path lists. This removes double counting and yields the specified work numbers.

| MaximumCommandWorker result |                                      |                                        |
| --------------------------- | ------------------------------------ | -------------------------------------- |
| Payload bytes               | 5,898                                | 16,627                                 |
| Whole frame bytes           | 5,906                                | 16,635                                 |
| Depth                       | 3                                    | 4                                      |
| Containers                  | 5                                    | 8                                      |
| Key pairs                   | 71                                   | 77                                     |
| Scalar leaves               | 70                                   | 169                                    |
| Hostile-input units         | `8 + 4×5,898 + 71 + 5 + 70 = 23,746` | `8 + 4×16,627 + 77 + 8 + 169 = 66,770` |

The command has 39 record fields, 15 delivery fields, 15 ceiling keys, three path elements, and two root keys. Its maximal record lengths are 4,341 and 1,533 bytes; the envelope adds 24. The maximal result record lengths are 5,494, 5,614, and 5,498 bytes; its envelope, separators, and brackets add 21. The result has `1 + 25 + 26 + 25 = 77` key pairs and `73 + 3×32 = 169` scalar leaves. The largest fixtures use maximum-length safe refs, distinct refs where required, 32 sorted unique evidence refs per observation, 96-character valid reason codes, and resealed C2A digests. The command uses ten non-Git ceilings and stop version at `2^63−1`, five required Git ceilings at zero, and positively related B1 parent/attempt/effect bounds. A one-digit semantic decrement yields 5,897 command bytes; one reason-character decrement yields 16,626 result bytes. [C2A field inventories (line 1488)](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py:1488>) · [B1 bound and distinction (line 58)](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-b1-pure-phase-values.md:58>)

The four charged byte passes are UTF-8 decode, JSON tokenization (including duplicate and bounded-integer scanning), canonical re-encode, and canonical comparison. Header inspection costs at most eight units; parsed keys, containers, and scalar leaves cost one each. Encoders accept exact constructed values and tuples, never caller mappings. Decoder mappings are fresh trees. Fixed C2A/B2 field and relation loops are mandatory but do not consume the hostile-input meter. The classifier charges every supplied fact, up to `3 worker + 4 adapter + 1 request + 2 process = 10`; both cancellation responses may occupy slots but make the input invalid. An eleventh injected charge fails.

## Classifier

Only `cancellation_acknowledged`, `cancellation_rejected`, `deadline_elapsed`, and `process_exited` are accepted adapter observation kinds, at most one each. The three delivery-outcome kinds remain separate transport evidence. Request count is 0–1; process supplements are 0–2, at most one per event kind. Duplicate refs/digests within a collection, repeated kinds, unrelated lineages, and contradictory facts are invalid inputs. Cancellation acknowledgements and rejections use the **cancel** delivery and fence plus the actual target; they are never compared as author-delivery observations. [C2A adapter matrix (line 69)](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py:69>) · [cancellation observation constraint (line 4205)](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py:4205>)

| PriorityPredicateClassification / reason |                                                                                                                     |                                                                                                                                                                                                                                                                             |
| ---------------------------------------- | ------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1                                        | Invalid type/cardinality; duplicate; unrelated lineage; conflicting facts; missing or mismatched cancellation graph | `invalid` / `invalid_input`, `duplicate_fact`, `unrelated_fact`, `conflicting_fact`, or `cancellation_graph_mismatch`, respectively. That order breaks ties. Both responses are `conflicting_fact`; a response without a matching request is `cancellation_graph_mismatch`. |
| 2                                        | Resource supplement                                                                                                 | `unusable/resource_limit_exceeded`                                                                                                                                                                                                                                          |
| 3                                        | Deadline observation                                                                                                | `unusable/deadline_elapsed`                                                                                                                                                                                                                                                 |
| 4                                        | Signal supplement                                                                                                   | `unusable/signal_delivered`                                                                                                                                                                                                                                                 |
| 5                                        | Matching request plus acknowledgement; plus rejection; or alone                                                     | `unusable/cancellation_acknowledged`; `unusable/cancellation_rejected`; or `unusable/cancellation_request_pending`                                                                                                                                                          |
| 6                                        | Nonzero exit with valid result; otherwise nonzero exit                                                              | `unusable/process_result_contradiction`; otherwise `unusable/process_failed`                                                                                                                                                                                                |
| 7                                        | Exit zero and no result; any result decode/relation failure after higher rows                                       | `unusable/result_missing`; or `unusable/result_invalid`                                                                                                                                                                                                                     |
| 8                                        | No process exit after higher rows                                                                                   | `unusable/process_evidence_incomplete`                                                                                                                                                                                                                                      |
| 9                                        | Valid related result and exactly one exit code zero                                                                 | `usable/usable`                                                                                                                                                                                                                                                             |

`result_failure` is an exact sealed **result decoder** failure. It is never a cancellation fact. It selects `result_invalid` after higher process conditions, including when exit is absent; absence of both result and exit selects `process_evidence_incomplete`. A nonzero exit outranks an invalid or missing result. C2A permits exit codes −255..255; only this B2 classifier calls **exactly zero** `successful_exit`. Neither exit zero nor worker completion proves semantic acceptance. Request, acknowledgement, rejection, signal, exit, teardown, and RW0 terminal outcome remain distinct. [C2A exit field (line 975)](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2a-first-slice-semantic-protocol-contract.md:975>) · [RW0-A noncollapse (line 251)](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:251>)

## Fixed profile

The safe profile ref is `rw0-wire-nwpf-v1`; schema is `governed-execution.nwp-rw0-wire-protocol-profile.v1`; digest domain is that schema plus `.identity`. The safe projection order is `schema_id`, `profile_ref`, `manifest`, `profile_digest`. Digest input is the first three fields as compact, sorted-key UTF-8 JSON, prefixed by domain UTF-8 and NUL. The literal identity mapping below is **4,022 bytes** and hashes to:
```
552ad9179dd8b97545f567b9389da2e09a428d5f4c4ef9c16b2f40dc16690006
```
```
{"manifest":{"authority":{"acceptance":false,"mechanism_neutral":true,"permission":false,"profile_in_frame":false,"provider_neutral":true},"classifier":{"ack_reject_exclusive":true,"adapter_kinds":["cancellation_acknowledged","cancellation_rejected","deadline_elapsed","process_exited"],"classifications":["usable","unusable","invalid"],"exit_success_code":0,"max_adapter_facts":4,"max_process_facts":2,"max_request_facts":1,"max_total_facts":10,"max_worker_result_facts":3,"precedence":[["invalid_input","duplicate_fact","unrelated_fact","conflicting_fact","cancellation_graph_mismatch"],["resource_limit_exceeded"],["deadline_elapsed"],["signal_delivered"],["cancellation_acknowledged","cancellation_rejected","cancellation_request_pending"],["process_result_contradiction","process_failed"],["result_missing","result_invalid"],["process_evidence_incomplete"],["usable"]],"reasons":["usable","invalid_input","unrelated_fact","duplicate_fact","conflicting_fact","cancellation_graph_mismatch","resource_limit_exceeded","deadline_elapsed","signal_delivered","cancellation_request_pending","cancellation_acknowledged","cancellation_rejected","process_result_contradiction","process_failed","result_missing","result_invalid","process_evidence_incomplete"],"response_requires_request":true},"decoder_errors":["invalid_outer_type","short_header","bad_magic","unsupported_version","unsupported_kind","declared_length_over_cap","truncated_payload","trailing_data","invalid_utf8","bom_forbidden","json_token_invalid","duplicate_key","invalid_root_or_scalar","unknown_field","missing_field","nested_record_invalid","noncanonical_payload","relation_mismatch","work_limit_exceeded"],"frame":{"header":[["magic",0,4],["version",4,1],["kind",5,1],["payload_length",6,2]],"kinds":{"command":1,"worker_result":2},"length_encoding":"uint16-big-endian","magic":"NWPF","one_frame":true,"semantic_identity":false,"version":1},"integer":{"json":"unsigned_decimal_no_sign_or_leading_zero","lower_bound":"owning_field","maximum":9223372036854775807,"preconversion_bounded":true,"type":"exact_builtin_int"},"json":{"allow_nan":false,"bom":false,"canonical_reencode_equals_payload":true,"constants":false,"duplicate_keys":false,"ensure_ascii":false,"floats":false,"normalization":"none","separators":[",",":"],"sort_keys":true,"utf8":"strict"},"payloads":{"command":{"max_bytes":5898,"max_containers":5,"max_depth":3,"max_hostile_units":23746,"max_key_pairs":71,"max_scalar_leaves":70,"records":["WorkerCommandV1","DeliveryEnvelopeV1"],"root_keys":["command","delivery"]},"worker_result":{"max_bytes":16627,"max_containers":8,"max_depth":4,"max_hostile_units":66770,"max_key_pairs":77,"max_scalar_leaves":169,"records":["WorkerObservationV1"],"root_keys":["observations"]}},"process":{"digest_domain":"governed-execution.nwp-rw0-wire-process-observation.v1.identity","event_kinds":["resource_limit_exceeded","signal_delivered"],"schema_id":"governed-execution.nwp-rw0-wire-process-observation.v1","source_authenticity":false,"source_kinds":["supervisor","operating_system"]},"request":{"digest_domain":"governed-execution.nwp-rw0-wire-cancellation-request-observation.v1.identity","schema_id":"governed-execution.nwp-rw0-wire-cancellation-request-observation.v1","source_authenticity":false,"source_kinds":["direct_local_adapter","es_adapter"],"target":"author_candidate"},"result":{"graph":"supplied_exact_fences","order":"tuple","same_source_invocation_ref":true,"same_source_ref":true,"sequences":[["worker_started","worker_completed"],["worker_started","candidate_captured","worker_completed"]],"source_kind":"worker","unique_digests":true,"unique_refs":true},"work":{"classifier_fact":1,"container":1,"container_list_member":"container_only","fixed_closed_relations":"unmetered","header_byte":1,"key_pair":1,"payload_byte_per_pass":1,"payload_passes":["utf8_decode","json_tokenize","canonical_reencode","canonical_compare"],"scalar_leaf":1}},"profile_ref":"rw0-wire-nwpf-v1","schema_id":"governed-execution.nwp-rw0-wire-protocol-profile.v1"}
```

The profile is fixed local evidence for later qualification. It is absent from frames and proves no source authenticity, permission, or acceptance. Any change to its bound protocol requires a new profile/version/digest.

## Exact implementation ceiling and tests

The maximum touched-file allowlist is exactly:
```
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

The Wire module imports existing C2A only, never B1; has `__all__ = ()`, no package-root export, and no production caller. C2A/B1 source, documents, direct tests and vectors, package root, `pyproject.toml`, SQL/migrations, StateStore, WriterSession, Section 41, and public protocols remain byte-identical. The two exact production inventories require updates for the new module; live process-framing status text requires the listed owner and status-test updates. [Production inventory (line 472)](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2a_nonimplementation.py:472>) · [runtime inventory (line 752)](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_runtime_non_authority.py:752>) · [status assertions (line 1041)](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_architecture_contracts.py:1041>) · [C1 status assertion (line 569)](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_software_development_progression_boundary.py:569>)

The four new direct test files must own literal expected fields, canonical bytes, counts, budgets, profile manifest, and digest. They must causally mutate **one predicate at a time**, resealing only the value that owns a changed digest:

- Every header byte and class, kind/version, per-kind cap plus one, uint16 maximum, short payload, trailing byte, and concatenated frame.
- UTF-8/BOM; duplicate root and nested keys; float, exponent, leading-zero, bool-as-int, oversized integer; key order, whitespace, and escape spelling.
- Maximum and one-over depth, containers, key pairs, scalar leaves, and injected `23,747`, `66,771`, and eleventh classifier fact charges; exact encoder types reject mapping, alias, and cycle attempts by type.
- Every command/delivery and result observation kind, count, order, source, invocation, lineage, fence, ref, digest, and candidate coordinate.
- Request absent, request alone, each response, response without request, both responses, wrong cancel or target effect/fence/delivery, invalid request source-invocation **shape**, and timestamp mutation without resealing. A different syntactically valid self-claimed source invocation is not detectable as false without external source proof.
- Each supplement kind/source/lineage; zero, nonzero, missing, duplicate, and conflicting exit; each classifier precedence pair, including resource over deadline/signal/request, deadline over signal/request, signal over request/response, and malformed result under each process tier.
- Each profile-manifest field changed independently, expecting a different independently calculated digest.

Future validation must use an external audit root, suppressed bytecode/plugin autoload, empty addopts, external pytest temporary and JUnit paths, `-W error`, and serial runs. The exact command sequence is:
```
cd '/Users/ds/Repositories/Governed Execution Coordinator'
RW0_B2_AUDIT_ROOT="$(mktemp -d /tmp/rw0-b2-wire.XXXXXX)"
mkdir -p "$RW0_B2_AUDIT_ROOT/tmp"
umask > "$RW0_B2_AUDIT_ROOT/caller.umask"
sh -c 'umask' > "$RW0_B2_AUDIT_ROOT/child.umask"
export TMPDIR="$RW0_B2_AUDIT_ROOT/tmp"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPYCACHEPREFIX="$RW0_B2_AUDIT_ROOT/pycache"
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export PYTEST_ADDOPTS=''

rw0_pytest() {
  label="$1"
  shift
  python3 -B -m pytest -q -W error -p no:cacheprovider -o addopts='' \
    --basetemp="$RW0_B2_AUDIT_ROOT/basetemp/$label" \
    --junitxml="$RW0_B2_AUDIT_ROOT/$label.xml" "$@"
}

rw0_pytest opening --collect-only tests > "$RW0_B2_AUDIT_ROOT/opening.nodes"

for f in tests/test_rw0_b2_wire_values.py tests/test_rw0_b2_wire_codec.py \
         tests/test_rw0_b2_wire_relations.py tests/test_rw0_b2_wire_boundaries.py
do
  rw0_pytest "$(basename "$f" .py)" "$f"
done
rw0_pytest wire tests/test_rw0_b2_wire_*.py
rw0_pytest c2a tests/test_worker_execution_semantic_*.py tests/test_c2a_relations.py
rw0_pytest b1 tests/test_rw0_b1_*.py
rw0_pytest static tests/test_c2a_nonimplementation.py tests/test_runtime_non_authority.py \
  tests/test_c2b2_development_row_value_boundaries.py tests/test_b2a_writer_session_contract.py \
  tests/test_codex_agent_config.py
rw0_pytest status tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_architecture_contracts.py tests/test_software_development_progression_boundary.py \
  tests/test_remote_worker_pre_execution_planning_contract.py
rw0_pytest candidate --collect-only tests > "$RW0_B2_AUDIT_ROOT/candidate.nodes"
diff -u "$RW0_B2_AUDIT_ROOT/opening.nodes" "$RW0_B2_AUDIT_ROOT/candidate.nodes"
rw0_pytest full tests
git diff --check
git status --porcelain=v1 --untracked-files=all
git diff --summary
git diff --name-only
```

The collection diff is expected to show only literal new Wire test nodes; verify that delta against the four test-owned inventories before the full run. Run the full suite once, with at most one explicitly governed repair rerun wholly inside the 16 paths. Record the specified HEAD/tree/parent/upstream/worktree/status provenance **twice**, before and after a fresh independent read-only audit; compare protected-file hashes, modes, imports, public exports, operations, locks, and residue before staging.

Stop implementation on a seventeenth path, changed C2A/B1 byte, public export or production caller, dependency/schema/migration change, cap or work undercount, profile mismatch, decoder-precedence violation, noncausal test, privacy material, source-authenticity or authority overclaim, failing validation, or provenance drift.

RW0-C still owns durable ingest, conflict/completeness/recovery, and terminal facts. RW0-D owns request delivery, process targeting, worker/supervisor and capsule proof; RW0-E owns the separately authorized live-host proof. ES retains its route’s admission and runtime authority. The fixed profile can later bind a separate Capability declaration, independent observation, and pure qualification; it selects no CLI/App Server mechanism, credential, session, or provider.

REPOSITORY\_MUTATION\_NOT\_PERFORMED\
TESTS\_NOT\_RUN\
STAGING\_NOT\_PERFORMED\
COMMIT\_NOT\_PERFORMED\
PUSH\_NOT\_PERFORMED\
PR\_NOT\_CREATED\
REMOTE\_CONTACT\_NOT\_PERFORMED\
WORKER\_OR\_MODEL\_NOT\_INVOKED\
SUPPORTING\_REPOSITORIES\_NOT\_MODIFIED
