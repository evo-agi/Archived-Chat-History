PROMPT_ID

RW0_B2_CAPABILITY_FINAL_REAUDIT_FINDINGS_REPAIR_CLOSEOUT_REPORT_RECOVERY_V1

TITLE

Coordinator RW0-B2-Capability — recover and emit the complete immutable
implementation closeout report for the final re-audit findings repair

ENGAGEMENT TYPE

Read-only report and provenance recovery in the existing implementation
conversation.

Do not edit repository files. Do not rerun implementation, tests, collection,
or cleanup unless the retained evidence is provably missing and the prompt
explicitly authorizes a rerun. This prompt does not authorize a rerun.

Do not stage, commit, push, create a PR, merge, tag, release, deploy, contact a
remote service, invoke a worker/model/provider, or inspect another repository.

OBJECTIVE

The preceding response returned only:

COORDINATOR_RW0_B2_CAPABILITY_FINAL_REAUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

Recover and emit the complete closeout report and exact audit target that
support that token, using the current unchanged working tree and the retained
repair evidence.

The token alone is not sufficient for a fresh independent audit. The complete
report must bind the exact repository bytes, validation evidence, node identity,
changed-path delta, and final provenance.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED REPOSITORY IDENTITY

Require:

- Branch:
  codex/rw0-b2-capability-semantics-v1
- HEAD:
  deec37bf08fb903d8846aa2c3232aec52fa9866e
- HEAD tree:
  ef48f5bd11244c6f703c97abb5489d19956f7a77
- Sole parent:
  02450d3c99faf0fe7b299b914afaed312421bc8b
- Subject:
  feat: implement RW0-B2 Wire protocol (#4)
- Upstream:
  origin/trunk_dev
- Ahead/behind:
  0/0
- Worktrees:
  1
- Final topology:
  exactly 30 dirty paths
  exactly 24 tracked modifications
  exactly 6 untracked additions
  0 staged
  0 unmerged
- Every candidate path:
  regular mode 0644

Stop with:

REPORT_PROVENANCE_MISMATCH

if the repository identity or topology differs from the bytes that produced the
success token.

OPENING TARGET FOR THIS REPAIR

The final re-audit findings repair began from:

- canonical manifest:
  /private/tmp/ge-coordinator-rw0-b2-findings-repair.GZaQQ1/final_recipe_1_manifest.json
- opening manifest SHA-256:
  527ba2c27d94a0361912210eb80c718762fcc4a4df1d9b503524a8e91af115ac
- opening tracked textual-diff SHA-256:
  6133bfa7994b12f63769a0d9a8843bb06296f2cc1185cc4c305b43c3c51ae5ee
- opening complete-output SHA-256:
  ea927882df7952ff31384d3cc42b5fe60dcca65127125e4e99f6ee4fc00cff8e
- opening node count:
  4743
- opening ordered-node-list SHA-256:
  05fea81edde4fde4cf5fcb15a8e2c397eead7410688665b1500c0cb09970a064

EXACT AUTHORIZED REPAIR PATHS

Exactly these six paths were authorized to change from the opening target:

.docs/rw0-b2-capability.md
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py

The other 24 opening-target entries must remain byte-identical.

RETAINED EVIDENCE

Locate the evidence root created by the final repair turn. Do not guess its
path. Derive it from the retained implementation records or current
conversation state.

Safely lstat every path component before reading it. Report:

- evidence-root absolute path;
- root owner, group, mode, and symlink posture;
- exact retained file count;
- evidence index path, size, and SHA-256;
- whether the index excludes itself;
- whether all retained files are regular, operator-owned, and mode 0400;
- whether any retained symlink, FIFO, socket, device, or unsafe path exists.

If the evidence root, final manifest, node list, validation summary, or complete
suite record cannot be located or safely verified, stop with:

REPORT_EVIDENCE_INCOMPLETE

Do not recreate missing evidence by rerunning tests.

PROVENANCE REPRODUCTION

Use the exact retained provenance recipe source that produced the final repair
target.

Require and report:

- recipe ID;
- recipe source path in the evidence root;
- recipe byte size;
- recipe SHA-256;
- final canonical-manifest path;
- final canonical-manifest byte size;
- final canonical-manifest SHA-256;
- final tracked textual-diff SHA-256;
- final complete recipe stdout byte size;
- final complete-output SHA-256;
- file count;
- exact complete canonical manifest JSON.

Run the exact recipe twice only if doing so is part of the already retained
read-only closeout posture and does not overwrite or disturb historical
evidence. Otherwise verify the two retained final runs byte-for-byte.

Do not modify the recipe.

EXACT DELTA REPORT

Compare the opening target to the final repair target.

Report:

1. exactly the six changed entries, each with:
   - path;
   - opening kind/type/mode/size/SHA-256;
   - final kind/type/mode/size/SHA-256;

2. the 24 byte-identical entries;

3. proof that:
   - no path became newly dirty;
   - no opening dirty path ceased to be dirty;
   - no seventh repair path changed;
   - no thirty-first path exists;
   - no mode, symlink, addition/deletion/rename/copy classification drift
     occurred.

FINDING CLOSURE REPORT

For each finding, report the exact implementation and causal test evidence:

1. Capability error construction and contract:
   - exact built-in string reason intake;
   - canonical finite reason;
   - inherited BaseException.args state;
   - inherited cause/context behavior on first emission;
   - active-exception chaining limitation;
   - weak registry cleanup;
   - hostile equality object and str-subclass rejection;
   - no authority or qualification effect.

2. B1 thirteen-relation matrix:
   - literal inventory of thirteen relations;
   - raw tuple delta exactly schema index plus self-digest index;
   - nested owner-object identity preservation;
   - normal invalid_enum rejection;
   - selective bypass;
   - class-wide bypass;
   - original-object poisoning;
   - exact relation/mode reachability and diagnostics.

3. B1 owner-region documentation oracle:
   - complete authoritative region;
   - rejection of numeric and number-word stale retrieval limits;
   - rejection of zero/no production consumer claims;
   - rejection of future/unimplemented Capability consumption;
   - duplicate, relocated, fenced-only, and trailing contradiction controls.

4. RW0 status-region oracle:
   - unique current owner region;
   - current B1/Wire/Capability status;
   - later C/D/E/ES ownership;
   - rejection of additive future/blocked RW0-B prose and table rows;
   - duplicate, relocated, fenced, and same-title controls.

TEST-FIRST AND DEVELOPMENT EVIDENCE

Report every attempt in order, including:

- selected red/control gate;
- any over-specific or test-fixture failures;
- source implementation steps;
- focused development runs;
- final focused groups;
- final collection;
- complete-suite attempts;
- any wrapper, recorder, environment, or metadata failure;
- whether any retry complied with the repair prompt;
- whether repository bytes changed between attempts.

For every credited final pytest run report:

- exact argv;
- environment;
- caller and child umask;
- return code;
- collected/passed/failed/error/skipped/xfail/warning counts;
- stdout size and SHA-256;
- stderr size and SHA-256;
- JUnit size and SHA-256;
- duplicate/unmapped case count;
- before/after candidate fingerprint.

NODE IDENTITY

Report:

- opening node count and hash;
- final node count and ordered-list hash;
- exact additions;
- exact files owning additions;
- zero removals/renames/reordering;
- whether every opening node remained in identical relative order;
- whether the executed full-suite node set exactly equals the final collection.

Do not omit the literal added node IDs.

FULL-SUITE RESULT

Report:

- attempt number of the successful full suite;
- whether another attempt ran;
- exact command;
- duration;
- collected/passed counts;
- zero/nonzero failures, errors, skips, xfails, warnings;
- stderr;
- JUnit identity and mapping;
- final-byte fingerprint binding.

FINAL GUARDS

Report:

- git diff --check;
- status, topology, name-status, and mode checks;
- protected-file comparison;
- package/export/import/public-caller checks;
- operation/lock checks;
- residue checks;
- cleanup performed;
- prior evidence-root fingerprint preservation;
- historical recipe-sink preservation.

AUTHORITY AND NONCLAIMS

Confirm explicitly:

- no C2A, lineage, B1, or Wire production implementation changed in this final
  repair;
- no schema, migration, SQL, package export, dependency, StateStore,
  WriterSession, process, provider, network, Git, publication, or runtime
  authority widened;
- Capability remains private pure supplied-fact semantics;
- RW0-C retains durable ingest/recovery/terminal/latch ownership;
- RW0-D retains physical custody/transport/process/provider/credential
  mechanics;
- RW0-E retains separately authorized live proof;
- ES retains route admission/runtime/lifecycle/cancellation/result authority.

OUTPUT

Return a complete report headed with exactly:

COORDINATOR_RW0_B2_CAPABILITY_FINAL_REAUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

The report must include the complete canonical manifest JSON and enough exact
evidence for a new independent audit prompt.

End with:

INDEPENDENT_AUDIT_NOT_PERFORMED
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
