PROMPT_ID

RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_FINAL_FRESH_REAUDIT_V1

TITLE

Coordinator RW0-B2-Capability — fresh independent re-audit of the repaired
owner-oracle reset using the complete no-mutation validation-evidence reset

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated independent audit.

Use a new Codex conversation. Do not use the write-enabled implementation
conversation that produced the repair or the validation-evidence reset.

The audit parent and all audit subagents are read-only. No repository mutation,
formatting, cleanup of candidate bytes, dependency installation, staging,
commit, push, PR, merge, tag, release, deployment, remote/service/provider/host
contact, product worker/model invocation, database mutation, migration, or
supporting-repository inspection is authorized.

Audit-created probes, clean external archives, pytest outputs, and provenance
records may be written only beneath one new external operator-owned,
non-symlink, mode-0700 audit root.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Determine whether the exact repaired owner-oracle-reset candidate closes all
four findings from the preceding independent audit and whether the subsequent
no-mutation validation-evidence reset provides a complete final validation
envelope.

The four repair findings are:

```text
B1-PARSER-001
  Cross-document B1 projection used a duplicate parser with different
  visibility/location behavior.

B1-LOCATION-002
  B1 first-live-H2 detection missed valid ATX H2 forms with 1–3 leading spaces
  or a tab delimiter.

RW0-TEST-003
  RW0 fence tests were non-causal and stayed green with visibility disabled.

EVID-RENAME-004
  The migration ledger omitted the explicit new_node_id for its sole rename.
```

The audit must also verify that the validation-evidence reset supersedes the
incomplete historical attempt metadata without changing repository bytes.

Do not reopen the accepted registry architecture or production semantics unless
the exact candidate proves a concrete contradiction.

EXPECTED LIVE IDENTITY

Require at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644
```

Require:

- `git diff --check` clean;
- cached diff check clean;
- no Git operation or lock;
- no candidate symlink or special file;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, recorder residue, or thirty-first changed
  path.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

FINAL CANDIDATE TARGET

The live candidate is bound to the retained repair target.

Repair evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-findings-repair.ZRLt3w
```

Required repair evidence index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-findings-repair.ZRLt3w/evidence_index.jsonl

rows:
375

size:
66414 bytes

SHA-256:
6de9b6295a2701a55bf496f2fe644f1c8be91b4314a67d84f3598c3a791e95b7
```

Required exact final candidate identities:

```text
canonical-manifest size:
6430 bytes

canonical-manifest SHA-256:
51b6adfdd88d538e26b7166681465fbb27abf467ec1e5936b646437e58d9f58b

complete recipe-output size:
6663 bytes

complete recipe-output SHA-256:
9e9a3582ae6109184593a1c68aff584ffe3f172f1db471b70ad2a20dee7d7bce

final pytest node count:
5051

final ordered-node-list SHA-256:
5e2a6c5f9e603895b9f9daf021ccc36a9915a8b923ddb7fe8c287b49325bb1aa

full-suite JUnit size:
1046623 bytes

full-suite JUnit SHA-256:
5473e80cb7dda254bc4c49281917d0c8b57509cd08d4b35078cbc71c551a4e54

corrected migration ledger records:
384

corrected migration-ledger SHA-256:
7dfce2479a0a7e72b37dc2af0181bf2dbf2e11ec209432a5b551ee4057f2a87e
```

Required repaired path identities:

```text
tests/test_rw0_b1_boundaries.py
size:
34249 bytes
SHA-256:
4d7fb14a71cb1c27f754566c4ac80dcc066b1f491f648fec3cbdb149b1ab6cd5

tests/test_rw0_remote_contact_phase_entry_contract.py
size:
160517 bytes
SHA-256:
2e37bb85fddad2c2212fbe598ff0e2cd553278f1234911ce5b6d34f1c8a90efd
```

The other 28 candidate entries must equal the retained opening and final
manifests exactly. Every repository path outside the 30-path candidate must
equal HEAD.

VALIDATION-EVIDENCE RESET

The no-mutation validation reset is the authoritative final validation envelope.

Root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-validation-reset.ji1cdR
```

Required self-excluding index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-validation-reset.ji1cdR/evidence_index.jsonl

rows:
136

size:
28009 bytes

SHA-256:
727d7feb2d24f6ea61222530b3d312483d7685f2da4f00dc462dce22e6eb6bb4
```

Required external index verification:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-index-verification.ji1cdR.json
```

Required closeout report:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-validation-reset.ji1cdR/final_report.md
```

The validation reset must establish, without repository mutation:

```text
selected causal:
53 passed

B1 owner:
132 passed

RW0 owner:
189 passed

B1 compatibility:
448 passed

Capability/Wire compatibility:
67 passed

architecture/status/static:
907 passed

final collection:
5051 unique nodes
ordered SHA-256
5e2a6c5f9e603895b9f9daf021ccc36a9915a8b923ddb7fe8c287b49325bb1aa

rename reconciliation:
passed against the corrected 384-record ledger

complete suite:
5051 collected
5051 passed
attempt 001 only
```

The reset intentionally does not reconstruct exact historical metadata for
failed or superseded implementation attempts. It must classify those records
as noncredited historical partial evidence and supersede them for final
validation authority.

PRECEDING AUDIT EVIDENCE

The independent audit that found the four repair findings is:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3
```

Required report:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3/audit_report.md
```

Required self-excluding index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-audit.kTGkO3/evidence_index.jsonl

rows excluding itself:
71

SHA-256:
26b69c39d083cd2096c8e2b47c6afbef7626d24cbd55093fcabe659be23a06bb
```

Also preserve and verify the original reset implementation evidence root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-reset-implementation.rL66CB

index SHA-256:
185d17a6332a49b545f50c5e7c33a4e1f6e1150fa799c547dbec40876b643e16
```

EXACT RECIPE SOURCE

Locate the exact retained recipe source through the repair evidence index.

Require:

```text
type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Do not decode recipe source from prompt text. Do not reconstruct it from a
digest.

Run the exact source twice with source bytes unchanged and only its fixed
external historical output sink safely redirected to two unique audit-root
files. Retain the wrapper source and prove that redirection cannot affect Git
queries, stdout, canonical JSON, or any other recipe behavior.

PROVENANCE GATE

Before correctness inspection or audit subagents:

1. create one new operator-owned, non-symlink, mode-0700 audit root beneath
   `/private/tmp`;

2. safely `lstat` all retained-evidence path components;

3. verify all four pre-existing evidence indexes exactly:

   ```text
   reset implementation:
   185d17a6332a49b545f50c5e7c33a4e1f6e1150fa799c547dbec40876b643e16

   preceding audit:
   26b69c39d083cd2096c8e2b47c6afbef7626d24cbd55093fcabe659be23a06bb

   findings repair:
   6de9b6295a2701a55bf496f2fe644f1c8be91b4314a67d84f3598c3a791e95b7

   validation reset:
   727d7feb2d24f6ea61222530b3d312483d7685f2da4f00dc462dce22e6eb6bb4
   ```

4. independently inventory all four roots and compare them again at closeout;

5. verify the external validation-reset index verification record;

6. verify exact repository identity and `30/24/6/0/0` topology;

7. locate the indexed final canonical manifest through the repair/reset
   evidence;

8. require canonical JSON, file count 30, size 6,430, and SHA-256
   `51b6adfdd88d538e26b7166681465fbb27abf467ec1e5936b646437e58d9f58b`;

9. verify every manifest entry by classification, regular-file type, mode,
   size, and SHA-256;

10. verify no thirty-first changed path;

11. verify every path outside the manifest equals HEAD;

12. verify the exact retained recipe source;

13. execute it twice with safe sink redirection;

14. require both generated manifests to equal the retained final manifest
    byte-for-byte;

15. require both complete outputs to be byte-identical, 6,663 bytes, and
    SHA-256
    `9e9a3582ae6109184593a1c68aff584ffe3f172f1db471b70ad2a20dee7d7bce`;

16. recover and require the tracked textual-diff identity from the indexed
    final manifest/evidence;

17. prove exactly the two repaired test entries changed from the repair opening
    target and the other 28 entries remained exact;

18. verify the corrected migration ledger, explicit rename, final node list,
    full-suite JUnit, validation-reset envelopes, final guards, and reset
    closeout report;

19. verify all explicitly protected source/docs/public surfaces.

On any candidate or mandatory evidence identity mismatch, stop before
correctness inspection and return exactly:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not approximate, regenerate, or silently repair missing evidence.

EXPLICITLY PROTECTED BY THIS REPAIR

These must equal the repair opening target:

```text
all .docs files
all production source
src/ge_nwp_coordinator/__init__.py
pyproject.toml

tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py

all SQL, migrations, schemas, catalogs
StateStore
WriterSession
package exports
dependency metadata
```

ACCEPTED ARCHITECTURE — DO NOT REOPEN BY INERTIA

Preserve:

- the embedded B1 and RW0 registries;
- registry version 1;
- exact registry rows, values, roles, sources, markers, headings, and locations;
- prose authority policy A;
- B1 authority rows and one-way RW0 projections;
- RW0 composition/status authority;
- retirement of arbitrary natural-language semantic classification;
- all C2A, lineage, B1, Wire, and Capability production semantics;
- all identities, canonical bytes, budgets, qualification precedence, and
  import direction;
- no source authentication, executable permission, semantic acceptance,
  persistence, provider/runtime/Git/publication authority;
- C/D/E and ES later/external owner seams.

AUDIT PERSPECTIVES

After the provenance gate, use exactly four bounded, non-nesting, read-only
perspectives when available. No child runs tests or modifies files.

1. B1 canonical parser and bounded-H2 auditor
   - sole test-side B1 parser ownership;
   - deterministic ordinary import into the RW0 test;
   - no copied fallback grammar;
   - no circular import, duplicate collection, or order sensitivity;
   - visible-first-H2 recognition with 0–3 spaces and space/tab/EOL delimiter;
   - four-space, NBSP, H3, prose, fenced, and commented controls;
   - primary/cross projection or diagnostic equivalence;
   - finite diagnostics.

2. RW0 causal fence-test auditor
   - exact real/sensitivity ledger;
   - valid closer, invalid closer, and non-opener families;
   - backtick/tilde markers, runs, indentation, suffixes, opposite/shorter
     closers, unclosed fences, info-string backticks, and short openers;
   - proof that visibility alone decides each result;
   - all-visible, closer-suppression, invalid-closer-as-valid, and
     overbroad-opener mutants;
   - unique document bytes and purposes;
   - no unrelated location/shape/marker/value failure.

3. Migration and validation-reset auditor
   - complete corrected 384-record ledger;
   - explicit one-to-one rename;
   - node arithmetic and order;
   - selected/focused/full reset envelopes;
   - unconditional recorder behavior;
   - exact final collection/JUnit mapping;
   - no hidden retry;
   - historical partial attempts accurately classified as noncredited;
   - self-excluding reset index and external verification.

4. Provenance, public-boundary, and authority auditor
   - exact two-entry delta and 28-entry equality;
   - all four evidence roots unchanged;
   - recipe and live-byte binding;
   - imports, exports, callers, protected bytes;
   - no source/document/public/authority widening;
   - remaining C/D/E/ES seams.

The parent performs reconciliation, independent external probes, node
comparison, validation, and closeout. Preserve disagreements.

Every finding must include:

```text
ID
type
severity: critical | high | medium | low | observation
current contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect or pre-existing issue
```

REQUIRED SOURCE AND TEST INSPECTION

Inspect both changed test files completely:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Inspect unchanged registries and adjacent owners:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/rw0-b2-capability.md
.docs/rw0-b2-wire-protocol.md

src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml
```

Inspect direct compatibility/public tests:

```text
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py
tests/test_remote_worker_pre_execution_planning_contract.py
```

Inspect additional Coordinator files only for a concrete dependency and record
why. Do not inspect another repository.

HYPOTHESIS A — CANONICAL B1 PARSER REUSE

Independently prove or falsify:

1. `tests/test_rw0_b1_boundaries.py` owns the sole B1 registry parser used by
   these tests.

2. `tests/test_rw0_remote_contact_phase_entry_contract.py` imports and reuses
   that parser through an ordinary deterministic test-module import.

3. There is no duplicate cross-document B1 parser, copied fallback,
   source-execution fallback, or dynamic import.

4. The import is stable when running:
   - B1 test alone;
   - RW0 test alone;
   - both in B1→RW0 order;
   - both in RW0→B1 order if pytest target ordering permits;
   - complete suite.

5. No duplicate test collection, import-time side effect, circular import, or
   public/package surface is introduced.

6. Primary and cross-document paths return:
   - the exact same canonical projection for valid input; or
   - the exact same finite diagnostic for invalid input.

Construct external mutants:

```text
reintroduce raw-line first-H2 selection in the cross path
copy a stale parser into RW0 test
use a fallback parser when import fails
modify the imported parser reference after import
make parser import order-sensitive
return a projection with one stale B1 row only in the cross path
```

The checked tests must kill each applicable mutant for the intended reason.

HYPOTHESIS B — BOUNDED VISIBLE H2 LOCATION

Independently challenge the exact raw-line recognizer:

```text
^[ ]{0,3}##(?:[ \t]|$)
```

Require location to be evaluated only after visibility.

Earlier visible H2s that must reject:

```text
0 spaces
1 space
2 spaces
3 spaces
tab delimiter
end-of-line H2
```

Non-H2 or hidden controls that must preserve success:

```text
4 spaces
NBSP delimiter
EM SPACE delimiter
third hash / H3
ordinary prose
backtick-fenced H2
tilde-fenced H2
commented H2
unclosed-fence-hidden H2
```

Independently generate combinations of indentation, delimiter, fence, comment,
and location. Compare primary and cross outcomes.

Require no use of Unicode `\s` or `str.isspace()` for the delimiter.

HYPOTHESIS C — RW0 FENCE-TEST CAUSALITY

Recover the exact retained causal ledger. Require every row to include:

```text
case ID
document SHA-256
family
expected real result
actual real result
sensitivity mutant
expected mutated result
actual mutated result
diagnostic
```

Verify all documents and purposes are unique.

Independently regenerate and test at least:

### Valid closer before registry

```text
backtick and tilde
runs 3, 4, 5
same/longer closer
0–3 leading spaces on opener and closer
ASCII space/tab suffix
```

Real parser must expose the registry and pass.

A closer-suppression mutant must hide it and fail visibility.

### Invalid closer before registry

```text
opposite marker
shorter closer
text suffix
NBSP suffix
EM SPACE suffix
4-space closer
unclosed fence
```

Real parser must hide the registry and fail visibility.

An all-visible or invalid-closer-as-valid mutant must pass the otherwise
canonical registry.

### Non-opener before registry

```text
backtick info containing backtick
4-space backtick opener
4-space tilde opener
backtick run < 3
tilde run < 3
```

Real parser must pass.

An overbroad-opener mutant must hide the registry and fail.

For every case, prove no unrelated location, marker-count, table-shape, order,
or value failure decides the result.

HYPOTHESIS D — MIGRATION AND RENAME EVIDENCE

Recover the corrected 384-record ledger.

Require the sole explicit rename:

```text
old_node_id:
tests/test_rw0_b1_boundaries.py::test_owner_has_one_current_retrieval_maximum_and_one_current_consumer

new_node_id:
tests/test_rw0_b1_boundaries.py::test_b1_live_registry_projection
```

Require:

- old exactly once opening, absent final;
- new absent opening, exactly once final;
- new exactly once among additions;
- one record targets new;
- no shared old/new endpoints;
- every opening owner node has one record;
- all ledger arithmetic exact;
- ledger SHA-256
  `7dfce2479a0a7e72b37dc2af0181bf2dbf2e11ec209432a5b551ee4057f2a87e`.

Independently mutate:

```text
remove new_node_id
wrong new_node_id
new target already present opening
new target absent final
duplicate target
shared old endpoint
shared new endpoint
rename count 0 or 2
one opening owner node omitted
one opening owner node duplicated
```

The retained checker must reject every mutant.

VALIDATION-EVIDENCE RESET ASSESSMENT

Verify the new recorder:

- has a complete unconditional envelope for its own self-test;
- records nonlaunch/refusal/failure paths structurally;
- does not depend on successful JUnit;
- stores zero-byte stdout/stderr;
- writes envelopes atomically;
- records before/after fingerprints;
- has no missing final attempt metadata.

Verify every reset attempt:

```text
opening validation gate
selected_causal_final
b1_owner_final
rw0_owner_final
b1_compatibility_final
capability_wire_compatibility_final
architecture_status_static_final
final_collection
rename_reconciliation_final
full_suite_final
final guards
cleanup
two final recipe runs
```

Require:

- exact argv/environment/Python/umask/timing/return code;
- complete streams/JUnit or explicit applicability;
- complete counts;
- complete fingerprints;
- correct credit classification;
- no hidden retry;
- no file change after final index creation.

Historical partial records may remain incomplete only when clearly noncredited
and superseded by the reset.

NODE IDENTITY

Run one candidate collection and one clean external `git archive HEAD`
collection under identical isolated conditions.

Require:

```text
candidate:
5051 unique nodes

candidate ordered-list SHA-256:
5e2a6c5f9e603895b9f9daf021ccc36a9915a8b923ddb7fe8c287b49325bb1aa

clean HEAD:
4655 unique nodes

clean HEAD ordered-list SHA-256:
f36822a60056ec3d110956de561202b737662c9d22cd0dd82c4cdad6c7cef69f
```

Also compare with:

```text
repair opening:
5002 nodes
11b13eebe8ff9631071da1f83a85d342b83ea4754a2c3765c0c227bf18f97a49

reset architecture opening:
5114 nodes
f3d83ce79954e7296b9406da6fcaa84a6676284d9504c7a9c30292d92c8fe8ae
```

Report exact:

```text
candidate/HEAD intersection
candidate-only
HEAD-only
5002→5051 additions/removals/renames
5114→5051 migration reconciliation
outside-owner relative order
owner ledger reconciliation
```

Do not require HEAD-only zero if the intentional owner-test migration explains
it; require all differences to reconcile with the corrected ledger.

INDEPENDENT VALIDATION

Only after source/test inspection, external mutants, migration audit, and reset
evidence inspection are green enough, run serially beneath the audit root.

For every child:

```text
umask 022 before launch
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Run:

1. exact retained selected causal 53-case set;
2. B1 owner:
   ```text
   tests/test_rw0_b1_boundaries.py
   ```
3. RW0 owner:
   ```text
   tests/test_rw0_remote_contact_phase_entry_contract.py
   ```
4. B1 compatibility:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```
5. Capability/Wire compatibility:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
6. architecture/status/static:
   ```text
   tests/test_architecture_contracts.py
   tests/test_software_development_progression_boundary.py
   tests/test_runtime_non_authority.py
   tests/test_c2a_nonimplementation.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   ```

Every credited run must have:

```text
return code 0
zero failures/errors/skips/xfails/warnings
empty stderr
parseable JUnit
zero duplicate/unmapped cases
matching caller/child umask
unchanged candidate fingerprint
```

If all inspection and focused validation remain green, run the complete
repository suite exactly once independently with quiet rendering.

Require:

```text
5051 collected
5051 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

If a deterministic material blocker is found first, the full suite may be
withheld. State that explicitly. Never repair candidate bytes.

PUBLIC, IMPORT, PRIVACY, AND AUTHORITY BOUNDARY

Require:

- no documentation change in this repair;
- no production source change;
- no package-root export;
- no reverse import;
- no production caller change;
- no dependency, SQL, migration, schema, catalog, StateStore, or WriterSession
  change;
- no filesystem, process, network, provider, Bridge, ES-call, Git,
  publication, or runtime effect;
- registry architecture and facts unchanged;
- no second registry writer;
- Capability remains private pure supplied-fact semantics;
- source refs/digests remain unauthenticated evidence;
- no executable permission, semantic acceptance, persistence, or runtime
  authority;
- C/D/E and ES remain later/external owners.

CLOSEOUT

After removing only audit-created transient artifacts:

1. rerun the exact recipe twice with safe sink redirection;
2. require exact equality to the opening final target;
3. require the same manifest, complete output, textual diff, file count,
   per-path hashes, and topology;
4. compare all four pre-existing evidence-root opening/closing inventories;
5. verify no operation, lock, staged/unmerged path, cache, bytecode, database,
   journal, archive, build, recorder, or generated-manifest residue;
6. retain all audit evidence beneath the new mode-0700 root;
7. make retained audit files regular, operator-owned, and mode 0400;
8. create a self-excluding evidence index.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low candidate defect remains;
- `BLOCK` for any repairable parser, test, migration, evidence, validation,
  privacy, public-boundary, or authority defect;
- `REJECT` only for a fundamental accepted-architecture contradiction;
- `AUDIT_PROVENANCE_MISMATCH` only for target/evidence identity failure before
  correctness judgment.

If `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_AUDIT_FINDINGS_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or create a PR.

FINAL REPORT

Include:

1. opening and closing identity;
2. exact provenance and two-entry delta;
3. all four pre-existing evidence indexes and reset-envelope verification;
4. four audit perspectives and disagreements;
5. severity-ranked finding ledger;
6. canonical B1 parser reuse result;
7. bounded visible-H2 result;
8. RW0 fence causality result;
9. corrected migration and rename result;
10. validation-reset completeness result;
11. node comparison and migration reconciliation;
12. independent focused/full validation;
13. public/import/privacy/authority assessment;
14. closeout guards;
15. separate provenance, validation, and implementation confidence.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
