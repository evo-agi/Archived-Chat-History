PROMPT_ID

RW0_B2_CAPABILITY_ASSURANCE_RESET_COMMIT_PUSH_PR_GATE_V1

TITLE

Coordinator RW0-B2-Capability — exact staged-tree commit, push, and pull-request
gate after assurance-reset technical acceptance

ENGAGEMENT TYPE

Authorized staging, validation, commit, push, and pull-request gate in the
existing Capability implementation conversation.

No implementation repair is authorized.

No merge, auto-merge, direct trunk push, force push, amend, rebase, second
commit, second push, second PR, tag, release, deployment, provider/live-host
contact, product worker/model invocation, database mutation, dependency
installation, migration, or supporting-repository modification is authorized.

The parent performs the gate. Do not create subagents.

CRITICAL INLINE RESPONSE RULE

Print the complete operative gate report inline in the Codex chat.

Do not return only:

- a token;
- a short summary plus `/private/tmp` links;
- “see report”;
- paths that contain material results.

Evidence paths may be supplementary only after all identities, commands,
validation results, commit/push/PR results, limitations, and final guards are
printed inline.

GOVERNANCE DISPOSITION

The internal independent-audit history is preserved exactly:

- G15 established that the assurance-reset candidate had no Critical, High,
  Medium, or Low candidate defect and independently passed:
  - 191/191 external one-predicate mutants;
  - A/B/C;
  - node migration;
  - focused validation;
  - live 5,059/5,059 suite;
  - clean committed 5,059/5,059 suite;
  - public/privacy/authority review.

- G16 verified:
  - exact candidate/source identity;
  - exact G14 indexed evidence and canonical indexed snapshot;
  - exact G15 technical-audit evidence;
  - targeted live/clean boundary tests;
  - exact projection;
  - exact 5,059-node collection;
  - no candidate defect.

- G16 returned BLOCK solely because retained process chronology did not prove
  strict non-overlap and intermediate deletion for two sequential outer
  PYTHONPYCACHEPREFIX pathname uses.

That G16 gap is hereby classified by the cognitive engineering lead as:

```text
REPORT_ONLY_AUDIT_HYGIENE_UNCERTAINTY
```

Rationale:

- it concerns an external audit-wrapper cache pathname, not candidate bytes,
  test semantics, Git tree, logical index, or product authority;
- both invocations used `python3 -B` and `PYTHONDONTWRITEBYTECODE=1`;
- the successful pytest child used a distinct child prefix;
- final G16 evidence contained no residue;
- source/candidate/evidence identities were exact;
- no validation result depended on pathname-instance identity;
- the missing historical process records cannot be reconstructed;
- repeating another independent audit would add audit-process risk without
  testing a new candidate property.

This disposition does not claim that G16 satisfied its original literal prompt.
It revises the internal gate policy on materiality.

This is not a GitHub/branch-protection bypass and does not authorize skipping
the exact staged-tree collection and complete-suite validation below.

The candidate is accepted for the commit/push/PR gate under this explicit
operator/cognitive-lead disposition.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED OPENING IDENTITY

Require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644

candidate tree:
727fb0ecf94680b64fed5e1bb2bccecccde38e4d
```

Require:

```text
git diff --check:
clean

cached diff:
empty

Git operation or lock:
none

candidate symlink/special path:
none

thirty-first changed path:
absent

repository cache/bytecode/database/journal/archive/build/generated-manifest/
recorder residue:
none
```

If any opening identity differs, stop before staging.

ACCEPTED CANDIDATE TARGET

Final candidate manifest:

```text
rows:
30

size:
6430 bytes

SHA-256:
abf1e627b7eb3030bddbb308861388e435e113f9d53dbacf3f344097385c0c32

tracked textual-diff SHA-256:
cc91155aff703e1c54c139820f841d98135f37ee7c87a71d3b00b07a2672e2a6

candidate tree:
727fb0ecf94680b64fed5e1bb2bccecccde38e4d
```

Final boundary file:

```text
tests/test_rw0_b2_capability_boundaries.py

kind:
untracked

type:
regular

mode:
0644

physical lines:
765

size:
36340 bytes

SHA-256:
ff9d9c6df68e6bb17d974c2f2abb0395735d0ead95bc79179daf7fbc01bea351
```

Final node identity:

```text
count:
5059

ordered SHA-256:
72ca14d20ff8e95384a8fa06b595227fb45bb7884aac295bbe4ae06ac761a0aa
```

ACCEPTED EVIDENCE CONTINUITY

Read-only verify and preserve:

G14 implementation root:

```text
/private/tmp/g14.OxZUD3

indexed evidence SHA-256:
91764a62fb6db27d426a4a86415b29337cd1dff3710c8528160e0e4755dc46b2
```

The two later G14 bytecode entries are historical audit-process evidence and
are not candidate files. Do not import from or modify G14.

G15 technical independent audit:

```text
/private/tmp/g15.leaPhd

index SHA-256:
0e91f20d8603082dc8b7af80bb40d8c4e0035555fafb5ab45c40742725b292d9

report SHA-256:
3953312948d6c495e2e3b79a233ae0103db5dfc8d759e52454eb002a05cb4c1c
```

G16 evidence-restoration audit:

```text
/private/tmp/g16.9h0Mop

index SHA-256:
1e39b3d6d76ca07194a046a7608ffac40e7797e2ec9a12941bfa98e405493a0a

report SHA-256:
d7705113afdb2483078ec1202e857e9b110ee6d644de301c58130448520a0778
```

Do not modify any prior evidence root.

EXACT 30-PATH STAGING ALLOWLIST

Stage exactly:

```text
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/c2a-first-slice-semantic-protocol-contract.md
.docs/c2a1-pure-semantic-values.md
.docs/durable-state-model.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-capability.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/worker-execution-boundary.md
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
tests/test_architecture_contracts.py
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_section41_pre_execution_plan_disposition_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_worker_execution_semantic_values.py
```

Expected shape:

```text
24 modifications
6 additions
0 deletions
0 renames
0 copies
0 mode changes
all committed mode 100644
```

Do not stage a path outside this allowlist.

NEW GATE EVIDENCE ROOT

Create one new short neutral root:

```text
/private/tmp/g17.XXXXXX
```

Requirements:

- operator-owned;
- non-symlink;
- mode `0700`;
- every pytest-visible path screened by the owning path-safety checker;
- every Python process uses:
  - `python3 -B`;
  - `PYTHONDONTWRITEBYTECODE=1`;
  - a unique never-reused `PYTHONPYCACHEPREFIX` path beneath G17;
- retained files mode `0400`;
- retained directories mode `0700`;
- no special entries at closeout;
- self-excluding index created last.

Record every formal gate action with exact argv/action, environment, timestamps,
return code, stdout/stderr identities, validation result, and before/after
repository/staged-tree fingerprints.

REMOTE AND POLICY PREFLIGHT

Before staging:

1. verify authenticated GitHub identity;

2. inspect remote `origin`;

3. fetch only the exact base and feature refs needed for the gate, without tags;

4. require remote `trunk_dev` still equals:

   ```text
   deec37bf08fb903d8846aa2c3232aec52fa9866e
   ```

5. require local base/upstream identity remains exact after fetch;

6. inspect whether remote feature ref exists;

7. inspect whether a matching open/closed PR already exists;

8. inspect applicable branch/ruleset policy:
   - allowed merge method;
   - required approvals;
   - required checks;
   - thread-resolution policy;
   - bypass actors;
   - auto-merge setting;
   - delete-branch-on-merge setting;

9. stop without staging on remote-base drift, conflicting feature ref, or
   conflicting PR.

Do not direct-push `trunk_dev`.

OPENING PROVENANCE REPRODUCTION

Locate and verify the exact 3,945-byte recipe source:

```text
SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Copy exact bytes into G17 as mode `0400`.

Run it twice with safe redirection of only the historical fixed sink.

Require:

```text
both manifests byte-identical
both equal the accepted 30-path manifest
both complete outputs byte-identical
empty stderr
source repository unchanged
```

STAGING

Stage exactly the 30 allowlisted paths in one bounded staging action.

After staging require:

```text
30 staged paths
24 M
6 A
0 D
0 R
0 C
0 unmerged
0 unstaged candidate change
0 untracked candidate path
0 extra staged path
all modes 100644
```

Require every staged blob and mode to equal the accepted manifest.

Compute the staged tree and require exactly:

```text
727fb0ecf94680b64fed5e1bb2bccecccde38e4d
```

Require working-tree bytes equal staged bytes for all 30 paths.

If any staging predicate fails:

- unstage exactly the 30 allowlisted paths;
- require restoration to opening `30/24/6/0/0`;
- stop without repair, commit, push, or PR.

VALIDATION ENVIRONMENT

For both collection and complete suite:

```text
umask 022
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
unique never-reused G17 PYTHONPYCACHEPREFIX
unique G17 TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error
unique G17 --basetemp
unique G17 --junitxml
serial execution
```

Pre-screen all child-visible paths before launch.

COLLECTION

Run exactly once against the staged candidate.

Require:

```text
5059 unique nodes
ordered SHA-256:
72ca14d20ff8e95384a8fa06b595227fb45bb7884aac295bbe4ae06ac761a0aa

zero warnings
empty stderr
parseable JUnit
zero duplicate identities
staged tree unchanged before/after
working bytes unchanged before/after
```

No second collection is authorized.

COMPLETE SUITE

Run exactly once against the staged candidate.

Require:

```text
5059 collected
5059 passed
0 failures
0 errors
0 skipped
0 xfailed
0 xpassed
0 warnings
empty stderr
parseable JUnit
exact ordered mapping to the accepted node list
staged tree unchanged before/after
working bytes unchanged before/after
```

No retry is authorized.

If collection or suite fails:

- preserve complete evidence;
- unstage exactly the 30 allowlisted paths;
- restore opening topology;
- stop with no commit, push, or PR;
- do not repair.

PRE-COMMIT GUARDS

Require:

```text
staged tree:
727fb0ecf94680b64fed5e1bb2bccecccde38e4d

parent:
deec37bf08fb903d8846aa2c3232aec52fa9866e

exact 30 staged paths
all staged/working blobs equal accepted manifest
no unstaged/untracked path
no Git operation or lock
no repository residue
remote base unchanged
```

COMMIT

Create exactly one commit.

Required subject:

```text
feat: implement RW0-B2 Capability semantics
```

Required body:

```text
empty
```

Do not amend.

Require:

```text
tree:
727fb0ecf94680b64fed5e1bb2bccecccde38e4d

sole parent:
deec37bf08fb903d8846aa2c3232aec52fa9866e

shape:
24 modifications
6 additions
0 deletions/renames/copies/mode changes
```

Record:

```text
commit OID
tree
parent
author
committer
timestamp
signature status
exact path/blob/mode verification
```

After commit require clean index/worktree.

PUSH

Execute exactly once:

```text
git push -u origin HEAD:refs/heads/codex/rw0-b2-capability-semantics-v1
```

No force.

Require:

```text
remote feature ref == new commit
remote trunk_dev unchanged at deec37bf...
upstream == origin/codex/rw0-b2-capability-semantics-v1
local/remote feature divergence 0/0
```

If push fails, do not retry. Preserve the local commit and report exact state.

PULL REQUEST

Only after successful push, create exactly one non-draft PR when no matching PR
already exists.

Required base:

```text
trunk_dev
```

Required head:

```text
codex/rw0-b2-capability-semantics-v1
```

Required title:

```text
feat: implement RW0-B2 Capability semantics
```

Required body:

```markdown
## Summary

- implement private RW0-B2 worker-mechanism Capability declaration,
  observation, and qualification semantics
- bind Capability qualification to the existing RW0-B1 host relation and fixed
  RW0-B2 Wire profile
- harden the consumed C2A, lineage, and B1 owner reconstruction boundaries
  required for complete fail-closed composition
- preserve RW0-C/D/E and Execution Substrate ownership; add no public API,
  runtime, persistence, provider, or execution authority
- use a bounded, state-independent commit-compatibility contract for the final
  repository boundary

## Validation

- 5,059 unique tests collected
- 5,059 tests passed
- staged tree: `727fb0ecf94680b64fed5e1bb2bccecccde38e4d`
- independent technical audit found no candidate defect
```

Do not enable auto-merge.

Do not submit a review or self-approval.

Do not resolve threads.

Do not delete the feature branch.

If a matching PR already exists, verify its exact base/head/title/state and do
not create a duplicate. Report it as the gate result.

FINAL GUARDS

Require:

```text
PR open
non-draft
unmerged
base exact
head exact
one feature-branch commit
30 files
local worktree/index clean
remote base unchanged
local and remote feature refs retained
no operation/lock/residue
prior evidence roots unchanged
no tag/release/deployment
no merge/auto-merge/review effect
```

Evidence root closeout:

- remove only G17-created transients after retaining records;
- retained directories mode `0700`;
- retained files mode `0400`;
- no special entries;
- self-excluding index created last;
- external verification of index;
- complete report inline.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_ASSURANCE_RESET_COMMITTED_PUSHED_AND_PR_OPENED
```

only if commit, push, and PR creation/verification all succeed.

FAILURE TOKENS

Use one exact primary token as applicable:

```text
COMMIT_GATE_OPENING_IDENTITY_MISMATCH
COMMIT_GATE_REMOTE_BASE_DRIFT
COMMIT_GATE_REMOTE_CONFLICT
COMMIT_GATE_PROVENANCE_MISMATCH
COMMIT_GATE_STAGING_FAILED
COMMIT_GATE_COLLECTION_FAILED
COMMIT_GATE_FULL_SUITE_FAILED
COMMIT_GATE_COMMIT_FAILED
COMMIT_GATE_PUSH_FAILED
COMMIT_GATE_PR_FAILED
COMMIT_GATE_CLOSEOUT_FAILED
```

For any failure, print the complete diagnosis inline and report whether the
source repository was restored to the opening topology or retains a local
commit.

FINAL INLINE REPORT

Use:

```text
# Outcome

# Governance disposition

# Accepted provenance

# Opening identity

# Remote and policy preflight

# Staging

# Collection and complete-suite validation

# Commit

# Push

# Pull request

# Final guards

# Evidence index

# Limitations and confidence
```

Required final statements:

```text
IMPLEMENTATION_REPAIR_NOT_PERFORMED
INDEPENDENT_AUDIT_NOT_REPEATED
DIRECT_TRUNK_PUSH_NOT_PERFORMED
BYPASS_NOT_USED
FORCE_PUSH_NOT_PERFORMED
AMEND_NOT_PERFORMED
SECOND_COMMIT_NOT_PERFORMED
SECOND_PUSH_NOT_PERFORMED
SECOND_PR_NOT_CREATED
PR_MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
REVIEW_NOT_SELF_APPROVED
FEATURE_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
CAPABILITY_RUNTIME_IMPLEMENTATION_NOT_PERFORMED
COLLECTION_RUN_EXACTLY_ONCE
FULL_SUITE_RUN_EXACTLY_ONCE
```
