PROMPT_ID

RW0_B2_CAPABILITY_INTEGRATED_OWNER_REPAIR_FRESH_INDEPENDENT_AUDIT_V1

TITLE

Coordinator RW0-B2-Capability — fresh independent audit of integrated
C2A/lineage/B1 owner reconstruction, Capability composition, and exact
30-path repaired candidate

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated independent audit.

This audit must determine whether the integrated protected-owner repair closes
the prior Capability audit blockers without changing accepted identities,
authority semantics, public surfaces, or later-owner boundaries.

No repository mutation, formatting, cleanup of repository bytes, dependency
installation, staging, commit, push, PR, merge, tag, release, deployment,
remote/network/service/provider/host contact, worker/model invocation,
database mutation, migration, or supporting-repository inspection is
authorized.

Use a fresh read-only Codex conversation. Do not use the implementation
conversation. Audit perspectives do not repair the patch.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED LIVE IDENTITY

Require at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate path modes:
all regular 0644
```

Require no Git operation, lock, diff-check failure, cache/bytecode/database/
journal/archive/build/recorder residue, or thirty-first changed path. Do not
fetch, switch, reset, clean, stash, rebase, or merge.

IMPLEMENTATION EVIDENCE ROOT

```text
/private/tmp/ge-coordinator-rw0-b2-repair.pO8M0Y
```

Named evidence includes:

```text
final_recipe_1_manifest.json
final_provenance_summary.json
node_delta.json
full_suite_001/junit.xml
```

The implementation report states that the final complete suite passed 4,719
tests on its only complete-suite attempt.

Also preserve and inspect only as necessary:

```text
initial Capability implementation evidence:
/private/tmp/ge-coordinator-rw0-b2-capability-g9JtFA

first Capability independent audit evidence:
/private/tmp/ge-coordinator-rw0-b2-independent-audit.KVUYoh

protected-owner reconciliation evidence:
/private/tmp/ge-coordinator-rw0-b2-reconciliation.L7lfys
```

Before correctness inspection:

1. `lstat` each evidence-root path component;
2. reject unsafe symlink traversal;
3. inventory relevant evidence by relative path, type, owner, mode, size, and
   SHA-256;
4. preserve prior evidence roots unchanged;
5. classify missing, unsafe, inconsistent, or unbound evidence explicitly.

CANONICAL PATCH IDENTITY

Expected recipe:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

source size:
3945 bytes

source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Expected final target:

```text
canonical manifest size:
6428 bytes

canonical manifest SHA-256:
177dab5f0c89f0bf99273c2fe9b3f8123f4df34c9dc29306acafb0308eaeb900

tracked textual-diff SHA-256:
586b2634b73fa4cf6e1b56d5afdcc2574f01fc5d49071d5b5199bc903e58631a

complete recipe stdout size:
6661 bytes

complete recipe stdout SHA-256:
20522a0b494d6e3511abe94b33dcee9a4f3a4c4a22768fa20bc369a6354f3042

file count:
30
```

Exact canonical manifest:

```json
{"branch":"codex/rw0-b2-capability-semantics-v1","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/authority-boundaries.md","sha256":"1a8ceceaa4c4110f24a4a5e6caa2182c40f1d93b3c94e386c704aaafed6dcb07","size":32953},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/autonomous-software-development-operating-model.md","sha256":"3399cdae5f9e4e6772cd4d6343906d920018cb759adf89177a515ba351378b64","size":34951},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/c2a-first-slice-semantic-protocol-contract.md","sha256":"49238bb9673f0334359c29c7c5add8e35bd617c9e25b7bc372e2445324c81150","size":102469},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/c2a1-pure-semantic-values.md","sha256":"ed7c7a7fad70405268354b348988013631a8c91759a67c24f05d8fb933d5c811","size":17052},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/durable-state-model.md","sha256":"b408350111e76de2eed85245264ced5e01dbd5972b2751c610af1df0e038dc18","size":38138},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-b1-pure-phase-values.md","sha256":"e0004a0e1827f13d08514d33a30d0c889c7191bc36c43d2446e91462b81525d3","size":28783},{"file_type":"regular","kind":"untracked","mode":"0644","path":".docs/rw0-b2-capability.md","sha256":"f57730f15f868dc3360258f41942ec930821b90414f5b1c034792e2f5a86e8df","size":14789},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-b2-wire-protocol.md","sha256":"9f74f07a12c5be7b6425cf6f3ca57b502c0b66a0b3838e3c791d1ae21c746258","size":16802},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/rw0-remote-worker-contact-phase-entry.md","sha256":"69b06fea64e2943d0e204686094145df4b8483f15774fb98221df9b71a68d495","size":50948},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/worker-execution-boundary.md","sha256":"77ef23371e4e41df315ae86ce6f173e68a9dcc98e5812a056225b10807f2e14f","size":29202},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py","sha256":"7882ca37e70fba0aa7673d6066e92498bc42d9a3dc8f9a7b4f0256970aeffec4","size":57863},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py","sha256":"4be365d3a494088d5353592f6f689682d59217ac211072f6b27edc874dd2df36","size":100783},{"file_type":"regular","kind":"untracked","mode":"0644","path":"src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py","sha256":"01e66fc7fc5c36f5cf35f1742e77d680a4bef6b88d071145683874cfc5902fda","size":35535},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"src/ge_nwp_coordinator/_worker_execution_semantic_values.py","sha256":"afeac74b711967d95d2fe722054f224f96e318e6657b24b1c98e466cf481c17c","size":171018},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_architecture_contracts.py","sha256":"2a7ae85baf6ffb84cfffef4d0585884f6908f1c793185a3ac26525b1b3b55457","size":99858},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_c2a_nonimplementation.py","sha256":"b0930f649de0c8456d11d8392964403a5c9f275a82bf9c4c544d68e1d2b3b5d9","size":27234},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_runtime_non_authority.py","sha256":"9636dd003e358d178e6d6316b16dbff7ece944ae64f7bf0a3f3080b6be297755","size":41310},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b1_boundaries.py","sha256":"f18a269c14938c1c81e56e6b85dfc046acb77f3b73ecdd13098c638f9c6643fa","size":8092},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b1_phase_values.py","sha256":"69235075cdfadb5e467ea02a8a30e7484d6c04c8f065c2b1e03004e57a9eb166","size":30030},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b1_relations.py","sha256":"8fe93b0e4d360d66a4f896255c92bc334f97377f6f37c940955c13d68cdc33aa","size":90186},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_boundaries.py","sha256":"e0424ca62d67b4573d226fcf8fda4c2fca9bdd34f8d3ae36331d3691c74a38a7","size":15501},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_relations.py","sha256":"7522e11f5c5f932462af2cf78f1f86accd703199dd3a2b2232ed82b74cf8c2a4","size":26877},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_values.py","sha256":"6ddcd2c1ea61fea95bdffd7bea653041847fb54d4c9a199d408e0a428e90b95c","size":24318},{"file_type":"regular","kind":"untracked","mode":"0644","path":"tests/test_rw0_b2_capability_vectors.py","sha256":"4aa4432b3e042e72f4a0d131a696a842f1a2ac1e3473f8bc04ad8fb90219f7f3","size":16104},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_b2_wire_boundaries.py","sha256":"ec77607ee411c46820e3dbac3fc67fbd1bcf071bcea6888f3286bf58fdd89f78","size":28690},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_rw0_remote_contact_phase_entry_contract.py","sha256":"b58de126ce8c04b4335b4ac085069b5b3955983e4c5771f30513dbdae34b71f2","size":109393},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_section41_pre_execution_plan_disposition_contracts.py","sha256":"75b7b5e5051ecaab713ee5ec9a91d19d152e0d7e80be06b74548d3b72a9822ba","size":20327},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_software_development_progression_boundary.py","sha256":"1d3ecc4e509933987e898c6532dd0980cbd737a595b3cb2682b93becf30fa4de","size":42833},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_worker_execution_semantic_boundaries.py","sha256":"0279bb43c83e5074a2be549c0453c15c942da77145b4a7cbc875826d8f3259c3","size":12313},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"tests/test_worker_execution_semantic_values.py","sha256":"062fbd9910716817f154aa7ea54698e78f662b2f142cffaca5f3a47b607ad527","size":48983}],"head":"deec37bf08fb903d8846aa2c3232aec52fa9866e","recipe_id":"governed-execution.audit-patch-manifest.v1","textual_diff_sha256":"586b2634b73fa4cf6e1b56d5afdcc2574f01fc5d49071d5b5199bc903e58631a","upstream":"origin/trunk_dev"}
```

EXACT RECIPE SOURCE

Decode the following base64 only beneath the new external audit root, require
3,945 bytes and the expected SHA-256, and retain it mode 0400:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

The recipe's historical sink is outside the repository. If it exists, record
its safe pre-audit filesystem identity and bytes. Execute the exact source
unchanged with an external wrapper that redirects only the exact
`Path.write_bytes` sink to unique audit-root files. Restore or verify the
pre-existing sink at closeout without introducing a repository effect.

PROVENANCE GATE

Before spawning audit perspectives or inspecting correctness:

1. create one new operator-owned, non-symlink, mode-0700 audit root under
   `/private/tmp`;
2. verify exact repository identity and `30/24/6/0/0` topology;
3. verify every canonical-manifest path by classification, regular-file type,
   mode, size, and SHA-256;
4. verify no thirty-first path;
5. verify zero staged/unmerged paths and clean `git diff --check`;
6. verify exact recipe source bytes;
7. run the recipe twice;
8. require both manifests and complete outputs byte-identical to the target;
9. verify every path outside the 30-path set equals HEAD;
10. verify all explicitly protected files equal HEAD, especially:
    - `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py`;
    - package root and `pyproject.toml`;
    - SQL, migrations, schemas, `StateStore`, and `WriterSession`;
    - `tests/test_worker_execution_semantic_vectors.py`;
    - `tests/test_worker_execution_semantic_relations.py`;
    - `tests/test_c2a_relations.py`;
    - `tests/test_remote_worker_pre_execution_planning_contract.py`;
    - `tests/test_rw0_b1_vectors.py`;
    - `tests/test_c2b2_development_row_value_boundaries.py`;
    - `tests/test_codex_agent_config.py`.

On any mismatch, stop before correctness inspection and return exactly:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not repair or regenerate an alternative target.

AUDIT TASKS

After the provenance gate, use exactly four bounded, non-nesting, read-only
audit perspectives when available. No audit subagent runs tests or mutates
anything. Give each perspective the exact manifest and accepted contract.

1. C2A and Section 41 lineage owner auditor
   - exact accepted-class inventory;
   - raw slot/tuple inventory and constructor mapping;
   - exact class enforcement;
   - non-recursive stack behavior;
   - charge-before-inspection/descent;
   - active-cycle rejection and repeated-alias recharging;
   - constructor/canonical/digest/projection reservation;
   - fixed content-free owner errors;
   - no supplied public method/equality/hash/iterator/canonicalizer/digest call;
   - exact `G` and `2G` tariffs;
   - unchanged valid schemas, canonical bytes, digests, enums, and scalar
     domains;
   - `WorkerObservationV1` exclusion;
   - exact import direction and absence of reverse/public imports.

2. B1 value, relation, and work auditor
   - all eight exact B1 classes;
   - state-revealing field reads and public methods;
   - `_values` access boundary;
   - copy/deepcopy, equality, serialization, repr/str, hashability;
   - incomplete, tampered, and correctly resealed invalid states;
   - nested C2A/L34 reconstruction through owner helpers;
   - literal `S/C/R/equality` arithmetic;
   - every relation maximum and one-under;
   - relation use of reconstructed locals only;
   - owner-error sanitization;
   - exact private host snapshot seam;
   - invalid readiness rejection before positive precedence.

3. Capability composition, authority, privacy, and documentation auditor
   - Capability's own three reconstructed values and unchanged vectors;
   - fixed Wire ref/digest and one-time owner loading;
   - hostile-key sanitization before equality/lookup;
   - deletion of imported Wire owner callable;
   - no retained manifest/callable;
   - supported-public-surface error immutability and reflection nonclaim;
   - generic session privacy plus accepted exact session field;
   - exact snapshot consumption;
   - exact `863 + 249 = 1112`;
   - complete qualification precedence and subject binding;
   - no source authentication, permission, acceptance, contact, runtime,
     persistence, provider/mechanism, credential, session, endpoint, Git, or
     publication authority;
   - current B1/Wire/Capability status and open C/D/E seams.

4. Tests, causal mutants, public boundary, evidence, and provenance auditor
   - literal test-owned owner tariffs and B1 budgets;
   - maximum-valid and one-under causal controls;
   - selective and class-wide helper/reconstruction bypass mutants;
   - cycle, deep graph, shared-DAG, and repeated-alias controls;
   - original-object-read mutants after reconstruction;
   - host snapshot exact-once controls;
   - Wire loader/error/session mutants;
   - status/tranche/open-decision mutants;
   - no existing-node drift and permitted new-node ownership;
   - empty exports, exact imports, no production/public caller;
   - exact 30-path ceiling and protected bytes;
   - implementation evidence, failed development attempts, and sole full-suite
     result;
   - final provenance completeness.

Every material finding must use:

```text
ID
type
severity: critical | high | medium | low | observation
current contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect or pre-existing issue
```

Preserve minority reports and disagreements.

REQUIRED INSPECTION

Inspect every changed/new path.

Core owner source:

```text
src/ge_nwp_coordinator/_worker_execution_semantic_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
```

Owner and status docs:

```text
.docs/c2a-first-slice-semantic-protocol-contract.md
.docs/c2a1-pure-semantic-values.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-capability.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
```

Direct owner/Capability tests:

```text
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_section41_pre_execution_plan_disposition_contracts.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py
```

Changed status/static tests:

```text
tests/test_architecture_contracts.py
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_software_development_progression_boundary.py
```

Protected semantic/vector/compatibility tests needed for independent comparison:

```text
tests/test_worker_execution_semantic_vectors.py
tests/test_worker_execution_semantic_relations.py
tests/test_c2a_relations.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_rw0_b1_vectors.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py
```

Inspect additional Coordinator files only when a concrete import, slot owner,
status assertion, or public-boundary relation requires them. Record each
addition and why. Do not inspect another repository.

ACCEPTED OWNER CONTRACT

### C2A owner tariffs

```text
CeilingsV1                    G=16  tariff=32
CapsuleEntryV1                G=8   tariff=16
WorkSpecV1                    G=86  tariff=172
AttemptFenceV1                G=46  tariff=92
EffectFenceV1                 G=51  tariff=102
WorkerCommandV1               G=58  tariff=116
DeliveryEnvelopeV1            G=16  tariff=32
CandidateCapsuleManifestV1    G=49  tariff=98
```

`WorkerObservationV1` is excluded.

### Section 41 lineage tariff

```text
CanonicalC2B3DLineage:
G=35
tariff=70
```

### B1 value budgets

```text
Value                         S     C     R=S+C   Equality=2R
Phase-entry basis            122   174   296     592
Authority observation         78   124   202     404
Subordinate proposal          62    92   154     308
Custody observation           17    34    51     102
Retrieval event               38    76   114     228
Readiness observation         40    80   120     240
Host qualification            46    92   138     276
Terminal outcome              32    64    96     192
```

### B1 relation maxima

```text
validate_phase_entry_basis                         891
validate_authority_observation                    1151
validate_per_fence_basis                           550
validate_external_common_family_claim              550
validate_subordinate_narrowing                     891
validate_custody_binding                           520
validate_retrieval_event_sequence                 1285
validate_host_qualification                        863
validate_terminal_outcome_binding                  496
each standalone terminal-shape validator            97
```

### Capability composition

```text
B1 host validation and five snapshots   863
Capability local                         249
                                         ---
complete occurrence-work total         1112
```

Counters are separately enforced. There is no additional snapshot pass.
`241`, `490`, and `1111` are obsolete.

OCCURRENCE-WORK NONCLAIM

The repaired work contracts count graph occurrences under the accepted exact
container model.

They do not claim:

- a finite integer-bit-length bound;
- a serialized-byte bound;
- a wall-clock bound;
- a SQLite-width bound;
- permission to allocate, transport, launch, persist, or execute anything.

Existing C2A scalar domains remain unchanged. Do not report the occurrence-work
tariffs as a universal denial-of-service bound.

HIGH-RISK AUDIT HYPOTHESES

Passing checked-in tests and a green full suite do not establish closure.
Challenge at least the following.

### A. C2A/lineage helper completeness

- A valid exact object reconstructed by the helper must preserve every public
  canonical byte and digest.
- Every admitted class must have a literal complete private-slot inventory.
- A missing slot, extra hostile object, wrong exact type, wrong tuple/list/dict
  container, subclass, custom iterable, active cycle, and repeated alias must
  fail at the intended boundary.
- No public `to_mapping`, identity, digest, equality, iterator, or foreign
  callback may occur before raw preflight.
- Constructor reservation must cover all owner work claimed by the tariff.
- A one-unit-short budget must fail before trusted construction.
- The same object appearing through aliases must be charged repeatedly.
- `BaseException` control-flow exceptions must not be swallowed.
- Owner failure text/cause/context must retain no hostile value.

### B. B1 public surfaces and relation locals

- Every declared field read must reconstruct first.
- Every public method must reconstruct exactly once and must not call another
  public semantic method.
- Copy/deepcopy and equality must not pass incomplete/tampered objects.
- Correctly resealed invalid enums, timestamps, optional pairs, nested owner
  values, result/reason combinations, and self-digests must fail before use.
- A selective or class-wide `_reconstruct_exact_b1_value` bypass must be killed.
- Every relation must use fresh locals/projections only.
- Mutating an original object after reconstruction through low-level test
  reflection must not alter the relation result.
- Maximum and one-under budgets must be causal rather than production-derived
  assertions.
- The host seam must validate once and return only five fresh safe projections.

### C. Snapshot and Capability composition

- Capability must never read the original B1/C2A objects after obtaining
  snapshots.
- All artifact, Wire profile, phase, authority, readiness, host, effect/fence,
  freshness, and evaluation-time predicates must be checked against the
  snapshots.
- A constructor-invalid but correctly resealed readiness value must yield only
  sealed `relation_mismatch`.
- A bare positive host qualification over an invalid graph must never reach
  Capability precedence.
- Host validation must occur exactly once per Capability relation.
- The `1112` total must not conceal work before either counter.
- No snapshot may retain a raw B1/C2A object, private material, or mutable
  caller-owned container.

### D. Capability-local repair

- A hostile non-string Wire-owner key must not run equality or lookup before
  type rejection.
- All ordinary loader failures must become the fixed import invariant with null
  cause/context after leaving the handler.
- `_wire_profile_mapping_owner`, `wire_profile_mapping`, the returned mapping,
  and the Wire manifest must not remain in module globals or closures after
  initialization.
- Post-import monkeypatching cannot change the fixed pair.
- Ordinary error assignment/deletion and ordinary `__dict__` access follow the
  narrowed contract.
- Low-level reflective state cannot change `.reason`, args, equality,
  serialization, repr/str, cause/context, or qualification semantics.
- Generic session-bearing unknown keys are private; accepted exact
  `external_session_non_authority` remains accepted.
- No provider/mechanism/route implication was introduced.

### E. Test and documentation causality

- Literal test-owned tariffs and relation maxima must not merely mirror
  production constants.
- Every class-wide bypass mutant must actually suppress the intended owner
  operation and be killed before a later sanitized error masks it.
- Status tests must reject the former all-B-future tranche map and wholly-open
  framing statement.
- Current docs must not claim C2A public schema/semantics are unchanged in a
  way that denies the new private owner helper.
- The two intended byte-identical opening paths must remain exact.
- A thirty-first changed path, reverse import, export, production caller, or
  Wire source change must be rejected.

INDEPENDENT EXTERNAL PROBES

The parent must create read-only probes under the audit root, without editing
repository files.

At minimum probe:

1. each C2A helper with every admitted exact class, maximum valid, one-under
   budget, missing/wrong raw slot, active cycle, shared DAG, repeated alias,
   custom iterable, and class-wide bypass;
2. the lineage helper with the same classes of hostile state;
3. all eight B1 values through declared attributes, every public method,
   copy/deepcopy, equality, every relation, and correctly resealed invalid
   state;
4. every B1 relation with a selective reconstruction bypass and a class-wide
   bypass;
5. external tracing proving semantic relation reads come from fresh locals,
   not originals;
6. the host snapshot seam's exact-once call and fresh built-in-only projections;
7. Capability qualification with invalid readiness, invalid authority,
   tampered snapshots, and bare-positive host records;
8. exact work maxima and one-under boundaries for all owner helpers, B1 values,
   B1 relations, host seam, Capability local, and composed `1112`;
9. foreign-exception graph and payload hygiene at each translated boundary;
10. isolated module import with hostile Wire owner outputs;
11. module-global and closure inventory after Capability import;
12. ordinary and low-level error-reflection controls;
13. session privacy overlaps in both insertion orders;
14. AST/import/public-caller checks independent of checked-in inventories;
15. owner/status Markdown mutants through the complete authoritative oracles.

Do not credit a mutant that changes more than one predicate unless its causal
isolation is mechanically demonstrated.

IMPLEMENTATION EVIDENCE REVIEW

Review and classify all recorded attempts, including:

- opening provenance reproduction;
- 8-test causal red gate;
- development attempts:
  - 430 passed, 5 stale assertions failed;
  - 52 passed;
  - 83 passed, 2 stale wording assertions failed;
  - 55 passed;
- final causal: 59 passed;
- final C2A/lineage: 1,493 passed;
- final B1: 303 passed;
- final Capability/Wire: 40 passed;
- final static/status: 116 passed;
- final collection: 4,719;
- complete suite attempt 001: 4,719 passed;
- final guards and double provenance.

Determine whether the red failures are causal, whether development failures are
properly classified, and whether final validation binds the final manifest.

NODE IDENTITY

Run one candidate collection and one clean external `git archive HEAD`
collection under identical isolated conditions.

Require:

```text
candidate:
4719 unique nodes

clean HEAD:
4655 unique nodes

intersection:
4655

candidate-only:
64

HEAD-only:
0

candidate ordered-list SHA-256:
24f6fe99b8ef728859327884da26f17f6dc9f8ea834aaf2b26a5914122399be6

HEAD ordered-list SHA-256:
f36822a60056ec3d110956de561202b737662c9d22cd0dd82c4cdad6c7cef69f
```

Every HEAD node must retain order.

The 64 candidate-only nodes consist of:

- the previously audited 21 Capability nodes; plus
- 43 integrated-repair additions.

Every one of the 43 new additions must belong only to:

```text
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_section41_pre_execution_plan_disposition_contracts.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

No opening node may be removed, renamed, skipped, xfailed, reparameterized,
collapsed, or reordered. Other changed existing test files may modify
assertions only.

INDEPENDENT VALIDATION

Only after source, docs, external probes, and authority inspection are green
enough to justify execution, run serially under one new external mode-0700
audit root.

For every child use:

```text
umask 022 before launch
child numerical umask must be 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
```

Require stable repository fingerprints before and after every run.

Run these exact groups after verifying every target exists:

1. selected causal tests;
2. C2A/lineage:
   ```text
   tests/test_worker_execution_semantic_values.py
   tests/test_worker_execution_semantic_vectors.py
   tests/test_worker_execution_semantic_relations.py
   tests/test_worker_execution_semantic_boundaries.py
   tests/test_c2a_relations.py
   tests/test_c2a_first_slice_semantic_protocol_contract.py
   tests/test_c2a_effects_and_recovery.py
   tests/test_section41_pre_execution_plan_disposition_contracts.py
   tests/test_remote_worker_pre_execution_planning_contract.py
   tests/test_c2a_nonimplementation.py
   ```
3. B1:
   ```text
   tests/test_rw0_b1_phase_values.py
   tests/test_rw0_b1_vectors.py
   tests/test_rw0_b1_relations.py
   tests/test_rw0_b1_boundaries.py
   ```
4. Capability/Wire:
   ```text
   tests/test_rw0_b2_capability_values.py
   tests/test_rw0_b2_capability_vectors.py
   tests/test_rw0_b2_capability_relations.py
   tests/test_rw0_b2_capability_boundaries.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
5. static/status:
   ```text
   tests/test_architecture_contracts.py
   tests/test_runtime_non_authority.py
   tests/test_c2b2_development_row_value_boundaries.py
   tests/test_codex_agent_config.py
   tests/test_rw0_remote_contact_phase_entry_contract.py
   tests/test_software_development_progression_boundary.py
   ```

Every credited run must have:

- return code 0;
- zero failures/errors/skips/xfails/warnings;
- empty stderr;
- parseable JUnit;
- zero duplicate or unmapped cases;
- matching caller/child umask;
- unchanged candidate fingerprint.

If inspection remains green, run the complete repository suite exactly once:

```text
4719 collected
4719 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

If a deterministic material blocker is found first, the complete suite may be
withheld; state that explicitly. Do not repair or rerun candidate bytes.

PUBLIC, IMPORT, AND AUTHORITY BOUNDARY

Require:

- import direction only:
  `Capability -> B1 private seam -> C2A/lineage private helpers`;
- no B1/C2A/lineage reverse import;
- no package-root export;
- no new production caller except Capability consuming the private B1 host
  seam;
- empty private `__all__` where governed;
- no dependency, package, SQL, migration, schema, `StateStore`, or
  `WriterSession` change;
- no filesystem, process, network, provider, dynamic import, SQLite, Bridge,
  ES call, Git, publication, or runtime effect;
- no raw private material retained in snapshots/errors/globals;
- every protected path byte-identical to HEAD.

DOCUMENTATION AND AUTHORITY ASSESSMENT

Classify substantive statements as:

- current contract/invariant;
- private implementation detail;
- compatibility edge;
- strategic target;
- later-owner seam;
- evidence/projection;
- explicit nonclaim.

Verify:

- C2A schemas/semantics/canonical identities/scalar domains are unchanged;
- private owner reconstruction is current implementation, not a public C2A
  semantic change;
- B1 public identities and relation meanings are unchanged;
- Wire source/profile/codec/classifier bytes are unchanged;
- Capability remains supplied-fact private semantics;
- B1, Wire, and Capability are current private semantic contracts;
- C/D/E and ES seams remain later-owned;
- occurrence-work is not overclaimed as a bit-length/byte/time bound.

CLOSEOUT PROVENANCE

After removing only audit-created transient files and preserving all retained
evidence:

1. rerun the exact recipe twice;
2. require both outputs byte-identical to the opening canonical target;
3. require the same exact 30 paths, classifications, modes, sizes, hashes,
   textual-diff digest, manifest digest, and complete-output digest;
4. require no staged/unmerged paths, operation, lock, or residue;
5. verify the implementation evidence root and earlier evidence roots are
   unchanged;
6. retain all audit evidence under the new mode-0700 root, with retained files
   regular, operator-owned, mode 0400;
7. create an evidence index that does not index itself.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low candidate defect remains.
- `BLOCK` for any repairable candidate contract, correctness, security,
  privacy, work-budget, test, documentation, or procedural defect.
- `REJECT` only for a fundamental architecture/authority contradiction that
  cannot be repaired within the accepted tranche.
- `AUDIT_PROVENANCE_MISMATCH` only for exact target/evidence identity failure
  before correctness judgment.

If `ACCEPT`, also return:

```text
COORDINATOR_RW0_B2_CAPABILITY_INTEGRATED_OWNER_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or open a PR.

FINAL REPORT

Include:

1. opening and closing repository identity;
2. recipe, canonical manifest, complete output, and per-file provenance;
3. implementation and prior-audit evidence inventories and limitations;
4. four audit-perspective reports and reconciliation;
5. severity-ranked finding ledger;
6. C2A helper class/slot/tariff assessment;
7. lineage helper assessment;
8. all eight B1 values and public-surface assessment;
9. every B1 relation budget and reconstructed-local assessment;
10. host snapshot seam and Capability `863 + 249 = 1112` assessment;
11. Capability Wire/error/session repair assessment;
12. authority/privacy/later-owner and occurrence-work nonclaim assessment;
13. documentation/status assessment;
14. tests and causal-mutant assessment;
15. node comparison;
16. independent validation;
17. public/import/protected-byte assessment;
18. closing guards;
19. separate provenance, validation, and implementation-confidence statements.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
```
