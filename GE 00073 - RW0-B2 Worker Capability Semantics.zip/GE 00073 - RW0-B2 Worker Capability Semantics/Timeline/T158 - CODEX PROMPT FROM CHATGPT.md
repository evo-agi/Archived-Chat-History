PROMPT_ID

RW0_B2_CAPABILITY_G10_FINAL_FRESH_INDEPENDENT_AUDIT_V1

TITLE

Coordinator RW0-B2-Capability — fresh independent audit of the G10-sealed
source-order binding model, ordered callsite ledger, runtime callable seal,
independent mutation oracles, and final validation envelope

ENGAGEMENT TYPE

Fresh, read-only, provenance-gated independent audit.

Use a new Codex conversation. Do not use the implementation, repair,
diagnostic, replay, or prior audit conversation that produced G10.

The audit parent and all audit subagents are read-only.

No repository mutation, formatting, cleanup of candidate bytes, dependency
installation, staging in the source repository, commit in the source
repository, push, pull request, merge, tag, release, deployment, remote service
contact, provider or live-host contact, product worker/model invocation,
database mutation, migration, or supporting-repository inspection is
authorized.

Audit-created probes, external local-only repositories, pytest outputs, and
provenance records may be written only beneath one new operator-owned,
non-symlink, mode-0700 audit root.

Use one short neutral audit-root pattern:

```text
/private/tmp/g11.XXXXXX
```

Pre-screen every path visible to a pytest child with the exact owning
path-safety grammar before launch.

CRITICAL INLINE OUTPUT RULE

The complete operative audit report must be printed inline in the Codex chat.

Do not return only:

- a verdict token;
- a short summary followed by `/private/tmp` links;
- “see report”;
- file paths that contain the material findings.

Evidence files may be listed as supplementary provenance only after every
decision-relevant fact, exact value, finding, validation result, and
continuation boundary has appeared inline.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Independently determine whether the exact G10-sealed candidate is ready for the
commit/push/pull-request gate.

The audit must verify:

1. exact candidate provenance and the 30-path tree;
2. the sole G9-repair path and the protected complement;
3. the source-order module and lexical binding model;
4. the ordered callsite ledger, multiplicity, receiver provenance, argument
   provenance, and allowed-path domain;
5. the runtime callable seal;
6. the independent module-global diagnostic oracle;
7. every G9 survivor and the executable subprocess sentinel case;
8. preservation of the literal 43-row projection and P01–P13 causal controls;
9. the eight stable-contract mutants;
10. unstaged, staged, and clean-committed compatibility;
11. opening/final node migration;
12. both exactly-once 5,095-test complete suites;
13. the full 86-row G10 attempt chronology, including failed/superseded
    attempts and the unallocated recorder-preflight incident;
14. report accuracy for fingerprint classes and missing/not-applicable
    fingerprints;
15. public, import, privacy, durable-state, runtime, and authority
    non-widening.

Do not reopen accepted production architecture without a concrete
contradiction.

EXPECTED LIVE REPOSITORY IDENTITY

Require at opening and closeout:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

candidate paths:
all regular mode 0644
```

Require:

```text
git diff --check:
clean

cached diff:
empty

Git operation or lock:
none

logical source index:
unstaged

candidate symlink or special path:
none

repository cache, bytecode, database, journal, archive, build output,
generated repository manifest, or recorder residue:
none

thirty-first changed path:
absent
```

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

FINAL CANDIDATE TARGET

Authoritative G10 evidence root:

```text
/private/tmp/g10.ALOFU2
```

Required G10 final report:

```text
/private/tmp/g10.ALOFU2/final_report.md

size:
27946 bytes

SHA-256:
aae2f3a19906f570ac2c49514623d41d54c7bd20971057863d958c145323bba3
```

Required G10 attempt manifest:

```text
/private/tmp/g10.ALOFU2/attempt_manifest.jsonl

rows:
86

size:
36151 bytes

SHA-256:
fd456c2532ec9e62da0f6cfdadd0a26976c2677463594139fa7a014276f800cc
```

Required G10 self-excluding evidence index:

```text
/private/tmp/g10.ALOFU2/evidence_index.jsonl

rows excluding itself:
630

size:
90708 bytes

SHA-256:
2f6976e2197a251a5de08ac8a00f02b8d516b0fc1e0e6a89c548e8ed4d5e08b1
```

Required final candidate identities:

```text
canonical-manifest size:
6431 bytes

canonical-manifest SHA-256:
615f93b6eca41019bfb617ec9c6dbc1ebaca6fad4e13ad9bba5c52d5b165ce04

complete recipe-output size:
6664 bytes

complete recipe-output SHA-256:
e1e1be6ee67789c96fa3f6d41e8a9526c3607ce4e8872abef3557fa9f896faeb

candidate tree:
84cb309f477fec7a28bccf5c671d4bb68393801c

final node count:
5095

final ordered-node-list SHA-256:
f6e7929241c6adb60df081ee9e59bff050e49869f90fc54e1d1072cf9362993d
```

Required authoritative normalized prevalidation fingerprint:

```text
size:
1421621 bytes

SHA-256:
2a51503dbd4cd086076eefa341645d3c4b7e8e79aaf2ea7b2d493b6680fd85fe
```

Required light source fingerprint:

```text
size:
1173 bytes

SHA-256:
abde6d809a4497c99e8c8180595e7ac831dbf0c599d015dbfdb09534ae07e7b7
```

EXACT FINAL REPAIR PATH

The only repository path authorized to change from the G8 opening candidate
was:

```text
tests/test_rw0_b2_capability_boundaries.py
```

Opening G8 identity:

```text
kind:
untracked

type:
regular

mode:
0644

size:
76858 bytes

SHA-256:
eb6ca3cd19b4bd723b82002aa93e7b5743ef02b768ac169d96e0011582e61977
```

Final G10 identity:

```text
kind:
untracked

type:
regular

mode:
0644

size:
130356 bytes

SHA-256:
cece5a7009a3b70ae2b7b065b7ae451c681801cd46dfa28c96bbee5279ba0490
```

The other twenty-nine candidate entries must be byte-, type-, kind-, mode-,
size-, classification-, and SHA-256-identical to the G8 opening target.

Every path outside the 30-path manifest must equal HEAD.

OPENING AUDIT TARGETS

G8 authoritative validation root:

```text
/private/tmp/g8.3cee3f
```

G8 index:

```text
rows excluding itself:
2403

size:
448923 bytes

SHA-256:
f90d50dc17e95e432b6577cad99669777f99bcd2d6af7c42509d2987db8248fc
```

G9 blocking independent-audit root:

```text
/private/tmp/g9.rW9peg
```

G9 index:

```text
rows excluding itself:
196

size:
35153 bytes

SHA-256:
a788c22943c8bcf0601ecf4a944182242843ad1f1849e24996e9c818f12ac244
```

G9 findings that G10 claims to close:

```text
G9-CC-001:
source-order/call-graph guard bypass through helper rebinding,
decorator/closure aliasing, builtin shadowing, and extra allowlisted calls with
Git-sensitive argument provenance

G9-EV-002:
module-global mutant expected diagnostics derived circularly from the checker
under test

G9-RP-003:
final report overstated authoritative fingerprint coverage for early attempts
```

Required G9 adverse-mutant identities:

```text
helper_rebind_alias:
68bd5ddc15603fd1c4264e39f36a0cdea11959bb05f5146409d484a47357cd66

decorator_closure_alias:
fbf7ee99bd57fe66149abb0419b2442808e5657234ca6a113458a1bd71909bf7

builtin_shadow_alias:
d7cca5c4fe94b3a17adee55929dc6a12232c2584d5e455b43fe23e077d7d5905

allowlisted_git_index_read:
25f0c1ed8509812da6579e4f83842808a1b677f914dff747454851e14efd4917

executable helper-rebinding source:
384528d45f5a1b80d3902ce2695ac1d370e51ea31fe9b6832bb1f0f37baf4bc7

executable-survivor patch:
242a0826bbc3bd8a4243376f567fff8e2e5eacd835ca17e2a0faa98228e93fff
```

EXACT RECIPE SOURCE

Locate the exact retained source through G10/G8 evidence.

Require:

```text
type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Do not reconstruct it from prompt text.

Create one verified G11-local mode-0400 execution copy. Run the exact source
twice at opening and twice at closeout, redirecting only the fixed historical
external sink to unique G11 paths.

Require exact equality to the indexed G10 manifest and complete output.

PROVENANCE GATE

Before correctness inspection or audit perspectives:

1. create:

   ```text
   /private/tmp/g11.XXXXXX
   ```

2. safely `lstat` every retained-evidence path component;

3. verify exact G10, G9, and G8 self-excluding indexes;

4. verify the G10 report, attempt manifest, final manifest, recipe outputs,
   mutation ledgers, A/B/C records, node lists, JUnit records, guards, cleanup,
   and terminal sealing records;

5. independently inventory G10 and require:
   - regular retained files;
   - correct ownership/modes;
   - no symlink or special entry;
   - no unindexed entry;
   - index excludes itself;

6. verify exact live repository identity and topology;

7. verify every final manifest entry;

8. verify no thirty-first changed path;

9. verify every path outside the manifest equals HEAD;

10. verify the exact recipe source and root-local copy;

11. run opening recipe reproductions twice;

12. require exact manifest/output equality;

13. recover and verify the final tracked textual-diff SHA-256 from indexed G10
    evidence;

14. verify opening and final node lists;

15. verify all 86 attempt rows and referenced envelopes;

16. verify the unallocated recorder-preflight incident separately;

17. verify every formal action is either:
    - represented by one attempt row/envelope; or
    - explicitly classified by the retained unallocated-incident record with
      exact command, timing, preflight outcome, and no side effect;

18. verify all explicitly protected production, documentation, package,
    dependency, schema, migration, SQL, `StateStore`, and `WriterSession`
    surfaces.

On any mandatory identity mismatch, stop before correctness inspection and
return:

```text
AUDIT_PROVENANCE_MISMATCH
```

Do not regenerate missing evidence.

AUDIT PERSPECTIVES

After the provenance gate, use exactly four bounded, non-nesting, read-only
perspectives when available. No child runs tests or modifies files.

1. Source-order binding and runtime-seal auditor
   - inspect the complete changed test;
   - independently reconstruct the 119-event module ledger and 35-event
     function lexical ledger;
   - inspect final module binding resolution in source order;
   - inspect decorators, defaults, keyword defaults, closures, `__wrapped__`,
     duplicate definitions, imports, assignments, deletes, comprehensions,
     loop/with/exception targets, class definitions, and dynamic binding;
   - verify the runtime callable seal and literal AST/source digests;
   - independently challenge helper/builtin/module rebinding and executable
     sentinel cases.

2. Ordered-callsite and projection auditor
   - independently reconstruct the literal 42-row ordered callsite ledger;
   - verify ordinal, multiplicity, receiver provenance, argument provenance,
     allowed path domain, and normalized AST digest;
   - challenge same-method extra calls, forbidden `.git` subjects, path
     construction, alias provenance, repeated calls, conditional/comprehension/
     lambda/default/decorator calls, star args/kwargs, and unresolved receivers;
   - verify the 43-row projection and P01–P13 controls remain exact and
     independent.

3. Mutation-oracle and validation-evidence auditor
   - verify all 18 literal source mutants and the executable sentinel result;
   - verify independent literal module-global expected diagnostics;
   - challenge with generic, wrong-key, swapped, missing, duplicate, and extra
     oracle mutants;
   - verify the eight stable adversaries, including the corrected P12 fixture;
   - inspect all 86 attempts, failed/superseded attempts, fingerprint classes,
     suite records, node records, and the unallocated recorder incident;
   - decide whether the incident is acceptable supplementary evidence or an
     all-attempt chronology defect.

4. Provenance, A/B/C, public-boundary, and authority auditor
   - exact one-file delta and twenty-nine-entry equality;
   - exact A/B/C target/projection/tree behavior;
   - external object isolation;
   - live/clean validation and node identity;
   - report accuracy;
   - imports, exports, callers, protected bytes;
   - no production/document/public/authority widening;
   - C/D/E and ES seams.

The parent performs reconciliation, independent executable probes, node
comparison, validation, and closeout. Preserve disagreements.

Every finding must include:

```text
ID
type
severity: critical | high | medium | low | observation
current contract or strategic target
path and line
evidence
impact
required correction
uncertainty
patch defect or pre-existing issue
```

REQUIRED SOURCE AND TEST INSPECTION

Inspect the complete final changed file:

```text
tests/test_rw0_b2_capability_boundaries.py
```

Inspect every helper, constant, literal ledger, runtime seal, AST digest,
projection row, and mutation helper in its reachable graph.

Inspect protected adjacent sources/tests as concretely required:

```text
tests/test_rw0_b2_capability_values.py
tests/test_rw0_b2_capability_vectors.py
tests/test_rw0_b2_capability_relations.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_codex_agent_config.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/c2a_contract_support.py
AGENTS.md
README.md

.docs/rw0-b1-pure-phase-values.md
.docs/rw0-b2-capability.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/software-development-progression-boundary.md

src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py
src/ge_nwp_coordinator/__init__.py
pyproject.toml
```

Inspect additional Coordinator files only for a concrete dependency and record
why. Do not inspect another repository.

HYPOTHESIS A — SOURCE-ORDER BINDING MODEL

Independently derive the complete binding-event model.

Require coverage of:

```text
imports and import-from aliases
FunctionDef / AsyncFunctionDef
ClassDef
Assign / AnnAssign / AugAssign
NamedExpr
Delete
for/async-for targets
with/async-with targets
except and except* targets
comprehension targets
match/case capture bindings
```

Determine whether every binding construct that can shadow a protected helper,
builtin, module alias, or literal global is represented.

Independently test at least:

```text
later helper assignment
helper alias rebinding
duplicate helper definition
conditional duplicate definition
try/except rebinding
match/case capture rebinding
class definition shadowing helper
lambda rebinding
import alias after definition
from builtins import len as len
module-level len/set/sorted/tuple/zip shadowing
approved module-alias shadowing
walrus binding
delete then rebind
```

The guard must reject every semantically applicable mutant for a literal finite
diagnostic.

If an unsupported Python binding construct can rebind a protected name while
the guard and target remain green, record a material defect.

HYPOTHESIS B — FUNCTION LEXICAL MODEL AND RUNTIME SEAL

Verify:

```text
no callable defaults
no callable keyword defaults
no closures/free variables
no decorators or __wrapped__
no assigned callable aliases
no getattr/dynamic dispatch
no unresolved local/global call targets
no runtime helper replacement
captured runtime function object identity exact
module/name/qualname exact
code/source/AST digest exact and independently literal
```

Independently reproduce the G9 executable helper-rebinding attack. Require:

```text
guard rejects before target execution
target does not run
sentinel is not created
```

Challenge:

```text
decorator returning a callable
decorator closure
functools.partial
operator.methodcaller/attrgetter where applicable
types.MethodType/callable object where applicable
callable default and kwdefault
callable closure/freevar
__wrapped__ injection
runtime module-dict rebinding
```

Do not demand rejection of an irrelevant construct unless it can affect the
protected runtime call graph.

HYPOTHESIS C — ORDERED CALLSITE LEDGER

Independently reconstruct the exact 42 callsites from source.

Require exact equality for:

```text
owner function
call ordinal
semantic target
multiplicity
receiver provenance
argument provenance
allowed path domain
normalized call-AST digest
```

The expected ledger must be literal and not generated from the checker under
test.

Challenge:

```text
one extra call to an already allowlisted method
one removed call
call reordering
same call with .git/index
same call with ROOT / ".git" / "index"
joinpath(".git", "index")
string/f-string/concatenated Git path
path passed through a local alias
receiver passed through alias
call in comprehension
call in lambda
call in default/decorator expression
star args or kwargs
conditional call
same method on unresolved receiver
```

Require finite dedicated diagnostics.

HYPOTHESIS D — INDEPENDENT MODULE-GLOBAL EXPECTATIONS

Recover the literal case-to-diagnostic mapping for:

```text
ROOT
EXPECTED_PATHS
EXPECTED_PATHS_SHA256
PROTECTED_PATHS
PROTECTED_PATH_IDENTITIES
PROTECTED_ROW_IDS
EXPECTED_BOUNDARY_ROWS
hashlib
stat
```

Require:

- expected values exist as independent literals;
- actual values come from the checker under test;
- no expected value is generated by that checker;
- case inventory/order is literal;
- generic-diagnostic checker mutant fails;
- wrong-key, swapped, missing, duplicate, and extra-case mutants fail;
- helper/builtin/module binding cases also have independent expected
  diagnostics.

HYPOTHESIS E — PRESERVED PROJECTION/CONTENT CONTRACTS

Verify the exact 43-row projection:

```text
R01–R30 required candidate paths
P01–P13 protected content
```

Require:

```text
unique row IDs
unique purposes
unique subjects
unique diagnostics
literal expected values
no Git-state field
no circular expected-value derivation
same projection in A/B/C
```

Independently mutate every P01–P13 row and reproduce the exact P12 prior
survivor. Require dedicated rejection.

Verify the eight stable adversaries. Scrutinize the two superseded P12 external
fixture failures and require that the final credited P12 case actually isolates
the intended predicate.

HYPOTHESIS F — A/B/C AND NODE IDENTITY

Independently reproduce:

```text
A:
live unstaged source repository

B:
fully external independent staged repository

C:
same external repository after diagnostic commit
```

Require:

```text
target passes A/B/C
projection A == B == C
B tree == C tree ==
84cb309f477fec7a28bccf5c671d4bb68393801c

source logical index unchanged
source authoritative object graph unchanged
no alternates
no source/external shared object inode
```

Independently collect candidate and clean-HEAD nodes.

Require:

```text
opening G8:
5072
f0faec3289ed635a741867bb2a655487f4a4a824dcf4cc0921c334beada1bbd3

final G10:
5095
f6e7929241c6adb60df081ee9e59bff050e49869f90fc54e1d1072cf9362993d

additions:
23

removals:
0

renames:
0

all additions:
tests/test_rw0_b2_capability_boundaries.py

outside-file identity/order:
unchanged
```

Also collect a clean external `git archive HEAD` baseline and report exact
intersection/candidate-only/HEAD-only sets.

HYPOTHESIS G — ATTEMPT CHRONOLOGY AND REPORT ACCURACY

Verify all 86 rows and every referenced envelope.

Require exact, accurate fingerprint classification per attempt:

```text
bootstrap identity
light source fingerprint
external-repository fingerprint
missing/not-applicable fingerprint
```

Confirm the final report does not claim authoritative fingerprints where none
exist.

Inspect attempts:

```text
014
019
021
023
026
058
060
071
086
```

and all intended red/guard failures.

UNALLOCATED RECORDER INCIDENT

Inspect:

```text
final/unallocated_recorder_preflight_incident.json
```

Report:

```text
exact requested action
exact invalid fingerprint-class spelling
time
caller/process identity
whether child launched
whether repository/external state changed
whether stdout/stderr or command identity exists
why no sequence was allocated
whether the incident was created through an auditable preflight path
whether its omission from the 86-row manifest violates the stated
all-formal-attempt contract
```

Do not assume acceptance because the report mentions it.

Classify as:

- no defect, if it is a fully evidenced pre-allocation refusal outside the
  manifest's declared sequence domain; or
- evidence/report defect, if a formal action occurred without the required
  envelope/manifest binding.

HYPOTHESIS H — VALIDATION EVIDENCE

Verify retained G10 focused results:

```text
Capability boundaries:
55 passed

Capability complete:
92 passed

B1/Wire compatibility:
461 passed

architecture/status/static:
907 passed

live full suite:
5095 passed exactly once

clean full suite:
5095 passed exactly once
```

Require:

```text
empty stderr
zero failures/errors/skips/xfails/xpasses/warnings
parseable JUnit
zero duplicate/unmapped cases
exact final node mapping
pre/post fingerprints exact for the declared fingerprint class
no hidden retry
```

INDEPENDENT VALIDATION

Only after source inspection, independent mutants, A/B/C, evidence inspection,
and provenance are green enough, run serially beneath neutral G11 paths.

For every pytest child:

```text
umask 022
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct neutral external PYTHONPYCACHEPREFIX
distinct neutral external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct neutral external --basetemp
distinct neutral external --junitxml
serial execution
```

Pre-screen every child-visible path with the owning path-safety checker.

Run exact focused groups recovered from G10 evidence, including the final
selected causal group and:

```text
Capability boundaries:
55 expected

Capability complete:
92 expected

B1/Wire compatibility:
461 expected

architecture/status/static:
907 expected
```

Every credited run requires:

```text
return code 0
zero failures/errors/skips/xfails/warnings
empty stderr
parseable JUnit
zero duplicate/unmapped cases
matching caller/child umask
unchanged authoritative candidate fingerprint
```

If all inspection and focused validation remain green, run:

```text
one live complete suite
one fully external clean complete suite
```

Require each:

```text
5095 collected
5095 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

The two suites are distinct state validations, not retries.

If a deterministic material blocker is found first, complete suites may be
withheld. State that explicitly. Never repair candidate bytes.

PUBLIC, IMPORT, PRIVACY, AND AUTHORITY BOUNDARY

Require:

- no production or governing-document change from the accepted candidate;
- no package-root export;
- no unauthorized reverse import or production caller;
- no dependency, SQL, migration, schema, catalog, StateStore, or WriterSession
  widening;
- no filesystem, process, network, provider, Bridge, ES-call, Git,
  publication, or runtime effect in production;
- source refs/digests remain unauthenticated evidence;
- no executable permission, semantic acceptance, persistence, or runtime
  authority;
- RW0-C/D/E and Execution Substrate ownership remain unchanged.

CLOSEOUT

After removing only G11-created transient artifacts:

1. rerun the exact recipe twice with safe sink redirection;
2. require equality to the opening G10 final target;
3. require same manifest/output/textual diff/file count/per-path hashes/topology;
4. compare G8/G9/G10 opening/closing content projections;
5. verify source logical index and authoritative object graph unchanged;
6. verify no operation, lock, staged/unmerged path, cache, bytecode, database,
   journal, archive, build, recorder, or generated-manifest residue;
7. retain all G11 audit evidence;
8. make retained files regular mode 0400 and directories mode 0700;
9. create a self-excluding evidence index;
10. print the complete report inline.

VERDICT

Return exactly one:

```text
ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
```

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low candidate defect remains;
- `BLOCK` for any repairable test, evidence, validation, privacy,
  public-boundary, or authority defect;
- `REJECT` only for a fundamental accepted-architecture contradiction;
- `AUDIT_PROVENANCE_MISMATCH` only for target/evidence identity failure before
  correctness judgment.

If `ACCEPT`, also return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_G9_FINDINGS_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Do not stage, commit, push, or create a PR.

FINAL INLINE REPORT

Use these top-level headings:

```text
# Verdict

# Opening and closing identity

# Provenance and exact candidate

# G10 evidence and attempt chronology

# Audit perspectives and disagreements

# Severity-ranked finding ledger

# Source-order binding and runtime callable result

# Ordered callsite ledger result

# Independent module-global oracle result

# Preserved projection and protected-content result

# A/B/C state result

# Node identity and migration result

# Retained validation assessment

# Independent validation

# Public, privacy, and authority boundary

# Closeout and evidence index

# Confidence
```

Include exact values inline. Supplementary evidence paths may follow.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
