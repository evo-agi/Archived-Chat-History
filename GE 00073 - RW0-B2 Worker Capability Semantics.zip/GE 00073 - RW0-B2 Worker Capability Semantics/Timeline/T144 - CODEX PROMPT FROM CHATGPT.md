PROMPT_ID

RW0_B2_CAPABILITY_FINAL_REPAIR_COMPLETE_VALIDATION_REPLAY_V2_STABLE_PROVENANCE

TITLE

Coordinator RW0-B2-Capability — restart the complete no-mutation validation
replay with one canonical evidence-comparison schema and normalized
authoritative Git provenance

ENGAGEMENT TYPE

Parent-only validation-evidence replay in the same write-enabled Capability
implementation conversation.

Repository mutation is not authorized.

Do not edit, format, generate, delete, rename, chmod, stage, commit, push, open
a PR, merge, tag, release, deploy, contact a remote/service/provider/host,
invoke a product worker/model, mutate a database, install dependencies, or
inspect a supporting repository inside the source repository or any
pre-existing evidence root.

Inside the one new external evidence root created by this engagement, creating
files, atomic renames, local-only diagnostic Git repositories, and setting
retained files to mode `0400` and directories to mode `0700` are authorized and
required.

Do not resume or modify the failed G6 replay.

This engagement creates a fresh, self-contained replacement validation basis
for the exact current candidate and records every action from root bootstrap
onward through an unconditional all-attempt ledger.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Restart the complete validation replay after the G6 closeout failure.

The diagnostic established two separate facts:

```text
1. evidence_close_g5 was a comparison-wrapper defect:
   opening used directory size null;
   closing used live directory st_size;
   all 625 directory rows therefore differed despite unchanged G5 bytes.

2. current ambient Git metadata differs from G6 opening:
   refs/codex/turn-diffs changed;
   35 loose-object mtime/ctime values changed;
   candidate bytes, HEAD, tree, real logical index, status, diff, object
   contents, and all authoritative repository facts remained exact.
```

The new replay must:

- use one canonical content-stable schema for every pre-existing evidence-root
  comparison;
- distinguish authoritative repository state from app-managed/report-only Git
  metadata;
- rerun the complete final validation sequence under one new root;
- seal a complete all-attempt chronology;
- produce a final report and self-excluding evidence index;
- leave repository bytes, real logical index, authoritative refs, and prior
  evidence unchanged.

Do not treat `refs/codex/turn-diffs`, loose-object storage timestamps, directory
st_size, atime, inode, ctime, birthtime, or xattrs as authoritative candidate
identity.

OPENING REPOSITORY IDENTITY

Before bootstrap validation require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644
```

Require:

- `git diff --check` clean;
- logical cached diff empty;
- no Git operation or lock;
- logical source index unstaged;
- no candidate symlink or special file;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, or recorder residue;
- no thirty-first changed path.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

AUTHORITATIVE CURRENT TARGET

Historical final-repair evidence root:

```text
/private/tmp/g5.hiLE2y
```

Required self-excluding index:

```text
/private/tmp/g5.hiLE2y/evidence_index.jsonl

rows excluding itself:
7234

size:
1583837 bytes

SHA-256:
199af9ac4299cc41a4434d44f1b1f7bcaf3265490b7417e174ad5d48723f8fcc
```

Required final facts recovered from indexed G5 records:

```text
candidate path count:
30

tracked modifications:
24

untracked additions:
6

staged/unmerged:
0/0

repair-opening node count:
5057

final node count:
5072

final B/C candidate tree:
0fcf6680ded68d66f62b75b5dc842d69b343a334

final live suite:
5072 collected
5072 passed

final clean suite:
5072 collected
5072 passed
```

Recover and verify exact full values from indexed records:

```text
final canonical-manifest path
final canonical-manifest byte size
final canonical-manifest full SHA-256
final tracked textual-diff full SHA-256
final complete recipe-output path/size/full SHA-256
exact final canonical manifest JSON
sole changed-path opening and final size/SHA-256
final ordered-node-list path/full SHA-256
opening ordered-node-list path/full SHA-256
selected final causal node IDs
closed reachable-call inventory
module-global identity/type inventory
all no-status mutant definitions and expected results
literal ordered 43-row projection
protected-content causal ledger
exact prior-audit survivor kill record
stable-contract mutation matrix
A/B/C target and projection records
```

Do not accept truncated prose hashes when exact indexed values exist.

FAILED G6 REPLAY AND DIAGNOSTIC

Failed G6 root:

```text
/private/tmp/g6.4101bd
```

G6 failure envelope:

```text
/private/tmp/g6.4101bd/a/0182/envelope.json
```

G6 diagnostic root:

```text
/private/tmp/g6diag.yF2Vcy
```

G6 diagnostic report:

```text
/private/tmp/g6diag.yF2Vcy/final_report.md
```

G6 diagnostic self-excluding index:

```text
/private/tmp/g6diag.yF2Vcy/evidence_index.jsonl

rows excluding itself:
21

size:
3598 bytes

SHA-256:
88f7e186f6fa515d56d3ecbeb7d9239f31042b4defcbfce4d9c49da00b554094
```

Classify G6 as:

```text
historical failed replay
all validation through both 5072-test suites completed and was enveloped
closeout stopped on evidence-comparison schema drift
attempt 0183 remained incomplete after stop
no G6 final report or self-excluding root index
not authoritative for final closeout
preserved unchanged
```

Do not resume, complete, repair, index, or rewrite G6.

PRE-EXISTING EVIDENCE ROOTS — READ ONLY

Safely verify and preserve at least:

```text
/private/tmp/g5.hiLE2y
  index:
  199af9ac4299cc41a4434d44f1b1f7bcaf3265490b7417e174ad5d48723f8fcc

/private/tmp/g4.S4uFyK
  index:
  f4836712bfc0e55dda2bb489401dabc55958016fc3c1778f8ad40a33bc5cb5b9

/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe
  index:
  bdffdfd9757302a7940b803f0d5138fdf9f9b41e53d95fcae3209b0e35dae71d

/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset2.Udjr4a
  index:
  a3abd5e9252da88623ab3285a6f560b7b71f151f672d25f6236c3779f806abe9

/private/tmp/gv3.efmQ8X
  index:
  cec6aba32a0243bf2b0b48d147df96ccb2b50ec5b9ec161dc1cc1c0d4f30eee1

/private/tmp/g6diag.yF2Vcy
  index:
  88f7e186f6fa515d56d3ecbeb7d9239f31042b4defcbfce4d9c49da00b554094
```

Also preserve every indexed root referenced by the G5 final report.

Safely `lstat` path components. Do not follow symlinks.

EXACT RECIPE SOURCE

Locate the exact retained recipe source through the G5 index.

Require:

```text
type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

The retained source and all pre-existing evidence roots remain read-only.

Create one root-local execution copy under the new root:

1. copy exact bytes under `umask 077`;
2. fsync and close;
3. atomically rename to `exact_recipe_source.py`;
4. set exact mode `0400`;
5. `lstat` and verify regular/non-symlink/operator-owned/mode/size/SHA-256;
6. seal a complete attempt envelope and `recipe_copy_preflight.json`;
7. invoke only after preflight passes.

NEW NEUTRAL EVIDENCE ROOT AND BOOTSTRAP

Create exactly one new top-level root:

```text
/private/tmp/g7.XXXXXX
```

The root and every pytest-visible child path must pass the exact retained
path-safety grammar.

The bootstrap must be one self-recording Python process that:

1. creates the root mode `0700`;

2. retains exact source as `bootstrap.py`;

3. records:
   - argv/environment;
   - Python identity;
   - PID;
   - caller umask;
   - wall/monotonic timing;
   - return code;
   - stdout/stderr identities;
   - created root path/type/owner/mode;
   - source repository opening lightweight identity;

4. atomically writes `bootstrap_envelope.json`;

5. installs the unconditional recorder;

6. performs no unrecorded action after root creation.

The bootstrap envelope is sequence 1 in the all-attempt manifest.

ROOT REQUIREMENTS

- operator-owned;
- non-symlink;
- mode `0700`;
- every temporary path below this root;
- no repository-local evidence/temp path;
- retained regular files mode `0400`;
- retained directories mode `0700`;
- no symlink, FIFO, socket, device, or special entry;
- self-excluding canonical JSONL index created last.

CANONICAL PRE-EXISTING EVIDENCE COMPARISON

Use exactly one implementation and one schema for both opening and closing
verification of every pre-existing evidence root.

For roots with a self-excluding index:

1. verify the index path, type, owner/group, mode, size, and SHA-256;

2. parse its exact rows;

3. verify the current root against the indexed contract;

4. create a canonical verification projection whose rows contain only:

   ```text
   relative_path
   type
   owner_uid
   owner_gid
   mode
   regular_file_size_or_null
   regular_file_sha256_or_null
   ```

5. for directories:
   - `regular_file_size_or_null` is always `null`;
   - `regular_file_sha256_or_null` is always `null`;

6. exclude the index itself exactly as the index contract requires;

7. sort rows by UTF-8 relative-path bytes;

8. compare opening and closing projections byte-for-byte using the same code.

Do not include or compare:

```text
directory st_size
atime
mtime
ctime
birthtime
inode
device
link count
flags
xattrs
```

Record these fields, if inspected, only as report-only observations.

For G6, which has no final self-excluding root index:

- preserve it as historical failed replay;
- create opening/closing canonical content inventories using the same row
  schema above;
- exclude only explicitly known transient paths if the G6 diagnostic records
  them as removed before failure;
- require path/type/owner/mode/regular-size/hash equality;
- do not attempt to retroactively seal G6.

A pre-existing root comparison fails only on:

```text
path-set change
file/directory type change
owner/group change
mode change
regular-file size change
regular-file SHA-256 change
index identity failure
unsafe symlink/special entry
```

UNCONDITIONAL RECORDER

After bootstrap, every command or procedural action runs through the recorder.

This includes:

```text
recorder self-test
path-safety preflight
each evidence-index verification
each evidence opening inventory
repository opening gate
recipe-copy preflight
opening recipe runs
target extraction
each mutation/control execution
each pytest run
A/B/C setup and run
live/clean collection
node reconciliation
live/clean full suite
every final guard
each evidence closing inventory
cleanup
final recipe runs
final report generation
attempt-manifest finalization
pre-index inventory
index creation
external index verification
```

Each action gets a unique immutable sequence and label.

The recorder must atomically seal an envelope on:

```text
success
expected nonzero mutant result
unexpected nonzero result
signal
preflight refusal
missing target
command not launched
JUnit absent/not applicable
wrapper/tooling failure
cleanup failure
index failure
```

ATTEMPT ENVELOPE SCHEMA

Every envelope includes:

```text
schema_id
sequence_number
label
purpose
attempt_class
credit_classification
expected_outcome
actual_outcome
exact argv
working directory
exact environment allowlist
unset variables
Python executable/realpath/version/implementation/platform
caller umask
child umask or not-launched
wall start/end UTC
monotonic start/end ns
duration ns
child PID or not-launched
return code
terminating signal
stdout path/size/SHA-256
stderr path/size/SHA-256
JUnit applicability/path/size/SHA-256/parse status
counts
duplicate/unmapped cases
ordered node-list identity when applicable
authoritative source pre fingerprint path/SHA-256
authoritative source post fingerprint path/SHA-256
external repository pre/post fingerprint identities when applicable
candidate-mutated boolean
ambient Git metadata opening/closing record paths when applicable
notes
```

ALL-ATTEMPT MANIFEST

Maintain append-only `attempt_manifest.jsonl`.

Require:

```text
bootstrap row first
one row per command/action
no missing sequence
no duplicate label
no command log without row
no envelope without row
finalized before final report
complete chronology embedded in final report
```

RECORDER SELF-TEST

Before candidate validation, record:

```text
successful external command
expected nonzero command
preflight refusal/not launched
zero-byte stdout
zero-byte stderr
JUnit not applicable
```

Stop if incomplete.

AUTHORITATIVE SOURCE PROVENANCE MODEL

Use one deterministic fingerprint implementation for every source-repository
pre/post comparison.

### Authoritative fields — equality required

```text
physical root
current branch name
HEAD OID
HEAD tree OID
parent OIDs
subject bytes
upstream name
upstream OID
ahead/behind
worktree inventory excluding app-internal metadata
porcelain v2 exact bytes/SHA-256
tracked binary diff exact bytes/SHA-256
cached binary diff exact bytes/SHA-256
logical index entries:
  git ls-files --stage -z exact bytes/SHA-256
candidate canonical manifest exact bytes/SHA-256
candidate per-path identities
outside-candidate equality to HEAD
authoritative refs:
  HEAD symbolic target
  refs/heads/codex/rw0-b2-capability-semantics-v1
  refs/heads/trunk_dev when present
  refs/remotes/origin/trunk_dev
  configured upstream
authoritative reachable object graph:
  sorted object OID/type/size inventory reachable from authoritative refs
  generated by read-only rev-list/cat-file operations
operation/lock inventory
repository residue inventory
```

Use `GIT_OPTIONAL_LOCKS=0` for read-only Git queries where supported.

### Ambient/report-only Git metadata — equality not required

```text
refs/codex/turn-diffs/**
reflogs
packed/loose storage representation
loose-object path set not reachable from authoritative refs
object-file atime/mtime/ctime/birthtime/inode/device/link count/flags/xattrs
real .git/index raw bytes and stat-cache metadata
directory st_size
```

Record ambient metadata opening and closing, including exact added/removed
`refs/codex/turn-diffs` and loose-object storage observations, but do not include
it in the authoritative fingerprint hash.

A change in ambient metadata is not `SOURCE_REPOSITORY_DRIFT` when all
authoritative fields remain exact.

### Logical index rule

Candidate index invariance is determined by:

```text
git ls-files --stage -z
cached binary diff
porcelain v2 staged fields
```

Raw `.git/index` bytes and metadata are report-only because stat-cache refreshes
may change them without logical index mutation.

### Authoritative object rule

Do not compare object-storage timestamps or loose-path aggregates.

Instead:

1. enumerate objects reachable from the authoritative refs;
2. require exact sorted OID set;
3. require exact object type and size for every OID;
4. require every object readable by `git cat-file`;
5. record storage representation only as ambient metadata.

OPENING GATE

Record each sub-action separately:

1. exact repository identity/topology;

2. no operation/lock/residue;

3. all required pre-existing evidence indexes;

4. all canonical opening evidence projections;

5. live candidate against G5 final manifest;

6. sole changed path and other twenty-nine equality;

7. every path outside candidate equals HEAD;

8. exact recipe source;

9. root-local recipe-copy preflight;

10. opening recipe run 1;

11. opening recipe run 2;

12. both manifests equal G5 final manifest;

13. both complete outputs equal G5 final output;

14. opening/final retained node lists and exact hashes;

15. exact mutation/projection ledgers;

16. exact path-safety grammar.

PATH SAFETY

Before any pytest or external repository path is created:

1. recover exact owning checker;

2. enumerate every child-visible path;

3. pass each through the exact checker;

4. retain complete result ledger;

5. stop before launch if any fails.

Use short neutral child names.

VALIDATION ENVIRONMENT

For every pytest child:

```text
umask 022
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct neutral external PYTHONPYCACHEPREFIX
distinct neutral external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct neutral external --basetemp
distinct neutral external --junitxml
serial execution
```

FINAL CAUSAL REPLAY

Recover exact sealed mutation/control specifications from indexed G5 records.

Replay individually:

```text
every canonical control
every closed reachable-call mutant
every module-global identity/type mutant
every 43-row projection inventory/uniqueness control
every protected-content row mutant
exact prior-audit survivor and kill control
every stable-contract mutant
```

For each retain:

```text
case ID
source/generator path
source bytes/SHA-256
purpose
expected outcome/diagnostic
actual outcome/diagnostic
pre/post authoritative source fingerprint
attempt envelope
```

Expected mutant rejection is a credited result.

Require unique source bytes and purpose unless explicitly justified.

FINAL FOCUSED GROUPS

Recover exact argv from indexed G5 records and rerun:

```text
selected causal:
16 passed

Capability boundaries:
32 passed

Capability complete:
69 passed

B1/Wire compatibility:
461 passed

architecture/status/static:
907 passed
```

If exact indexed argv does not support those counts, stop with input
inconsistency.

A/B/C STATE REPLAY

## State A

Live accepted unstaged source repository.

## State B

Fully external independent Git repository/object database:

- initialize independently;
- populate accepted base without alternates/hardlinks;
- overlay exact final 30-file candidate;
- stage exactly candidate;
- do not commit;
- run target and projection.

## State C

Same external repository:

- create one diagnostic local commit;
- require tree:
  `0fcf6680ded68d66f62b75b5dc842d69b343a334`;
- require clean status;
- run target and projection.

Require:

```text
target passes A/B/C
projection A == B == C
B staged tree == C committed tree
source authoritative fingerprint unchanged
external object database isolated
```

Every setup/run has its own envelope.

NODE COLLECTION

Run live and clean external final collection.

Require both:

```text
5072 unique nodes
exact full ordered SHA-256 recovered from indexed G5 final list
byte-identical lists
```

Compare:

```text
repair opening:
5057

final:
5072

additions:
15

removals:
0

renames:
0

all additions:
authorized test file only

outside-file order:
unchanged
```

LIVE FULL SUITE

Run exactly once after focused validation is green.

Require:

```text
5072 collected
5072 passed
0 failures/errors/skips/xfails/warnings
empty stderr
exact JUnit/node mapping
authoritative source pre == post
candidate-mutated false
```

CLEAN FULL SUITE

Run exactly once in the fully external clean committed State-C repository.

Require:

```text
5072 collected
5072 passed
0 failures/errors/skips/xfails/warnings
empty stderr
exact JUnit/node mapping
source authoritative pre == post
external pre == post
clean tree unchanged
candidate-mutated false
```

No retry is authorized.

FINAL GUARDS

After suites, record separately:

1. source identity/topology/manifest;

2. authoritative source fingerprint equality to opening;

3. ambient source metadata delta report;

4. all pre-existing indexed evidence roots against canonical content-stable
   opening projections;

5. G6 historical root against its canonical content-stable opening projection;

6. final node identities;

7. mutation ledgers and attempt-manifest arithmetic;

8. no hidden command without envelope;

9. no operation/lock/residue.

A G5 directory-size difference, atime change, app-managed ref change, or object
timestamp change must not fail the guard when canonical content and all
authoritative source fields are exact.

CLEANUP

Remove only G7-created transient:

```text
basetemps
pytest caches
pycache roots
TMPDIR contents
external repository
temporary object copies
```

Before removal retain complete external-repository and validation records.

Record cleanup in complete attempt envelope(s).

Run post-cleanup guards through the recorder.

FINAL PROVENANCE

After cleanup:

1. verify root-local recipe copy mode/content;

2. run final recipe 1;

3. run final recipe 2;

4. require both manifests equal indexed G5 final manifest;

5. require complete outputs equal indexed G5 final output;

6. require empty stderr and unchanged authoritative source fingerprint.

FINAL REPORT

Generate before index creation and include:

1. opening identity;
2. G5 comparison-wrapper diagnosis;
3. G6 historical classification;
4. all pre-existing evidence indexes;
5. bootstrap/recorder self-test;
6. complete all-attempt chronology;
7. canonical evidence-root comparison schema;
8. normalized authoritative Git provenance schema;
9. ambient Git metadata observations;
10. opening gate;
11. causal replay;
12. focused groups;
13. A/B/C replay;
14. live/clean collections;
15. node reconciliation;
16. live/clean suites;
17. run-local fingerprints;
18. final guards;
19. cleanup;
20. final provenance;
21. exact final manifest JSON;
22. protected/public/authority non-widening;
23. remaining C/D/E/ES seams;
24. separate provenance, validation-binding, and implementation confidence.

Explicitly state:

```text
historical G5 partial metadata was not reconstructed
G5 remains implementation evidence
G6 remains failed replay evidence
G7 is the authoritative complete validation and closeout envelope
app-managed turn-diff refs and object-storage timestamps are report-only and
were excluded from authoritative candidate identity
```

INDEX CREATION AND EXTERNAL VERIFICATION

1. finalize `attempt_manifest.jsonl`;

2. verify sequence continuity and envelope mapping;

3. generate pre-index inventory through recorder;

4. generate final report through recorder;

5. create self-excluding canonical JSONL index as last root mutation;

6. no post-index root mutation;

7. run one external verifier outside root;

8. externally verify:
   - index excludes itself;
   - every row matches path/type/owner/group/mode/size/hash;
   - no unindexed entry;
   - no symlink/special entry;
   - attempt manifest/envelopes reconcile;
   - mandatory report/records exist.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only when:

- candidate bytes remain unchanged;
- all causal/focused groups pass;
- A/B/C passes;
- live/clean collections are exact;
- live/clean suites pass 5072/5072;
- every action has an envelope;
- canonical evidence-root closeout passes;
- normalized authoritative source provenance passes;
- final report/index are complete.

FAILURE TOKENS

Use one precise primary token:

```text
STABLE_REPLAY_PROVENANCE_MISMATCH
STABLE_REPLAY_INPUT_INCOMPLETE
STABLE_REPLAY_RECORDER_FAILED
STABLE_REPLAY_CAUSAL_FAILED
STABLE_REPLAY_FOCUSED_FAILED
STABLE_REPLAY_STATE_MATRIX_FAILED
STABLE_REPLAY_NODE_COLLECTION_FAILED
STABLE_REPLAY_LIVE_SUITE_FAILED
STABLE_REPLAY_CLEAN_SUITE_FAILED
STABLE_REPLAY_AUTHORITATIVE_SOURCE_DRIFT
STABLE_REPLAY_EVIDENCE_CONTENT_DRIFT
STABLE_REPLAY_PROVENANCE_FAILED
STABLE_REPLAY_EVIDENCE_SEAL_FAILED
```

Do not modify repository bytes in any failure case.

FINAL REQUIRED STATEMENTS

```text
REPOSITORY_MUTATION_NOT_PERFORMED
IMPLEMENTATION_NOT_RERUN
HISTORICAL_METADATA_NOT_RECONSTRUCTED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
