## Engineering disposition

**Do not begin Capability implementation yet.** The high-level design is sound, but the packet is not fully implementation-exact despite its `READY` verdict.

I accept and would not reopen:

- `Wire → Capability`;
- separate declaration, independent observation, and Coordinator qualification;
- the three proposed value classes and fourteen mechanism-neutral dimensions;
- the fixed Wire profile pair;
- complete composition through B1’s owning host-qualification relation;
- provider/mechanism neutrality;
- the exclusion of persistence, authority, acceptance, credentials, sessions, process mechanics, and concrete CLI/App Server selection.

This is a narrow freeze-completion issue, not a new reconnaissance workstream. A planning freeze must clearly delimit claims and non-claims before implementation widens them by inertia. 

## Why the implementation handoff is premature

### 1. Full value revalidation conflicts with the stated work budget

The packet says the qualification relation will **revalidate** the three Capability values. But its relation arithmetic—`24 + 31 + 26 + 6 = 87`—charges only one flat projection of each value plus the five B1/C2A inputs and time.

That is insufficient for full semantic reconstruction. An exact-class object could be created or tampered through `object.__new__` or `object.__setattr__`, resealed with a matching digest, and reach semantic comparisons unless the relation reconstructs all fields through the owning validation path.

True safe reconstruction adds the already-frozen two-pass construction budgets:

```text
Declaration construction:    48
Observation construction:    62
Qualification construction:  52
```

A safe existing-value boundary therefore needs:

```text
Declaration:    24 + 48 = 72
Observation:    31 + 62 = 93
Qualification:  26 + 52 = 78
```

The defensible relation accounting is consequently:

```text
Capability-local:
72 + 93 + 78 + 5 object leaves + 1 time leaf = 249

B1 owning relation:
241

Composed maximum:
490
```

The previous `87` local / `328` composed totals can survive only if Codex demonstrates an equally strong reconstruction algorithm with different exact accounting.

### 2. The qualification reasons lack exact predicates

The ordered reason list is useful, but several reasons do not yet have unambiguous conditions:

- what exactly belongs to `b1_binding_mismatch`;
- whether `declaration_observation_mismatch` covers only the declaration identity pair or also dimension states;
- how evaluation-time mismatch is classified;
- which artifact and Wire pairs must agree before the corresponding mismatch reason;
- which conditions produce a stored blocked or unknown qualification rather than a sealed relation error.

Without one literal expected-result function, implementation and causal tests can silently disagree while both appearing consistent with the prose.

### 3. Hostile mapping closure is incomplete

The packet identifies 39 characters as the longest admitted field name, but does not freeze:

- the exact accepted key-length interval;
- the result for empty, overlength, or non-ASCII keys;
- order-independent handling of multiple unknown keys;
- precedence when one unknown key contains a private fragment and another is ordinary;
- interaction between unknown keys and missing required fields.

Those details matter because B1 and Wire audits repeatedly found bounded-work and noncausal-oracle defects around key traversal and precedence.

### 4. Wire-profile extraction needs one exact owner seam

The direction is correct—Capability should import `wire_profile_mapping()` and retain only the accepted ref/digest—but the implementation packet must state whether this happens once at module initialization, exactly what is checked, how the manifest is discarded, and whether malformed owner output is an internal invariant failure or a public Capability error.

Caller-supplied profile substitution must be structurally impossible.

## Next action

Run one **bounded read-only reconciliation**. It preserves the accepted architecture and closes only these four implementation-critical details. Separating this final design correction from repository mutation follows the established workflow: reconnaissance freezes the plan, then a later parent-only turn performs implementation. 

Send this complete prompt in the existing read-only Capability Codex conversation:

:chatgpt-content-reference{index="3"}

Verify the artifact:

```text
Filename:
Coordinator_RW0_B2_Capability_Schema_Freeze_Reconciliation_Prompt.txt

Size:
20,665 bytes

SHA-256:
4144b808155b1f3bf582f03860fddc60c6014e97c5114d4f7b747d10b4ccbb54
```

The prompt does **not** reopen the three roles, fourteen dimensions, accepted Wire identity, B1 ownership, later-owner split, or proposed 20-path ceiling. It requires exact closure of:

- non-recursive safe reconstruction for all public methods and the relation;
- construction, public-method, relation, and composed work budgets;
- every result/reason predicate and precedence;
- hostile mapping-key limits and reasons;
- the non-substitutable Wire-owner binding;
- exception cause/context and payload hygiene;
- causal bypass mutants;
- confirmation that no twenty-first path is required.

The required successful dispositions are:

```text
RW0_B2_CAPABILITY_SCHEMA_FREEZE_RECONCILED_READY
RW0_B2_WIRE_PROFILE_BINDING_CONFIRMED
```

Only after those are returned should we issue one parent-only workspace-write implementation prompt. The original accepted decomposition remains controlling: Capability follows Wire, while concrete CLI/App Server and process proof stay with D/E. 

### Sources

- Codex Capability schema-freeze report supplied in this turn.
- Snapshot-validated Coordinator source, especially:
  `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`,
  `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py`, and the B1/Wire boundary tests.
- Planning-freeze purpose and non-widening principle. 
- Read-only reconnaissance followed by parent-only implementation. 
- Accepted Wire-before-Capability ordering. 

**Confidence:** High that the architecture and schema inventory should be retained; high that the revalidation/budget inconsistency is real; medium-high that the corrected composed maximum is 490 pending Codex’s source-grounded reconciliation of the exact helper algorithm.
