PROMPT_ID

RW0_B2_WIRE_FOURTH_AUDIT_TEST_REPAIR_V1

TITLE

Coordinator RW0-B2-Wire — repair the fourth-audit test-adequacy findings and
prepare exact bytes for a fresh independent re-audit

ENGAGEMENT TYPE

Parent-only workspace-write repair in the existing
`codex/rw0-b2-wire-protocol-v1` implementation conversation.

Do not create or resume subagents. You are the sole repository writer.

This is a bounded **test-only** repair after a fresh independent audit returned
`BLOCK`. The auditor independently accepted current production behavior,
protocol identities, authority/privacy boundaries, parser behavior, classifier
behavior, and public/nonimplementation boundaries. Do not change production
source or governing documentation to simplify the tests.

This is not reconnaissance, schema design, implementation redesign, Capability
implementation, independent audit, commit gate, publication gate, merge,
deployment, or runtime proof.

Do not stage, commit, push, create or modify a PR, merge, tag, release, deploy,
contact a remote, invoke a product worker/model/provider, modify a supporting
repository, or install dependencies.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Close exactly two candidate test-adequacy defects:

1. replace the non-isolating oversized-integer regression with a literal,
   per-class/per-field matrix that mutates exactly one reachable C2A integer
   path at a time and proves rejection before every owner or Wire
   canonicalization boundary;

2. make the 5,000-sibling pending-frame oracle independent of production
   `_CAPS` by using the literal bound `5`, while separately pinning the complete
   result-cap tuple:

   ```text
   (16_627, 4, 8, 77, 169, 66_770)
   ```

Preserve all production bytes and all previously accepted behavior.

OPENING TARGET

Before any mutation, require exactly:

- physical root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- subject:
  `feat: implement RW0-B1 pure phase-entry semantics (#3)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- dirty paths:
  `16`
- tracked modifications:
  `10`
- untracked additions:
  `6`
- staged/unmerged:
  `0/0`
- every candidate path:
  regular mode `0644`
- no Git operation, lock, repository cache, bytecode, database, journal,
  archive, build, generated manifest, or recorder residue
- `git diff --check`:
  clean.

Immutable opening target:

```text
/private/tmp/rw0-b2-wire-third-repair.l1gF3r/final_recipe_001.manifest.json
```

Required opening identities:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe source size:
3_945 bytes

recipe source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6

canonical-manifest SHA-256:
462179865bd8bacc2edcab5fd5a0ee3bae9e85a62a708a7e3b7c3d18f10db33b

complete-output SHA-256:
136bec66bea1850965f4a2232b422dcc9ba2315adc308319ab16b4cc0cc8ff06

file count:
16
```

Required repair-report envelope:

```text
/private/tmp/rw0-b2-wire-third-repair.l1gF3r/final_provenance.json
```

Envelope SHA-256:

```text
c857704fd8d597be0e3e6574964fbecb6dcb02cb5cf59aeead1d76c7e7c980b6
```

Latest audit evidence root:

```text
/private/tmp/rw0-b2-wire-third-audit.Zq6XE2
```

Preserve every earlier implementation, repair, and audit evidence root. Do not
rewrite or reconstruct missing evidence.

EXACT RECIPE SOURCE

Decode this base64 only into a new external repair evidence root, verify exact
size and SHA-256, and retain it mode `0400`:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

Execute the exact source unchanged with only its exact historical
`Path.write_bytes` sink redirected into the new evidence root. Do not overwrite
pre-existing fixed-path evidence.

OPENING PROVENANCE AND NODE GATE

Before editing:

1. lstat every component of the immutable target, report envelope, retained
   audit root, new repair root, and copied recipe;
2. require safe ownership, no symlink traversal, regular files, and mode-0700
   evidence roots;
3. verify the immutable target and report envelope exactly;
4. run the exact recipe twice;
5. require both complete outputs and manifests to be byte-identical and equal
   the immutable target;
6. verify every live candidate entry by path, classification, type, mode, size,
   and SHA-256;
7. verify protected complement equality to HEAD;
8. collect the complete opening node list exactly once under isolated external
   paths;
9. require exactly `4_654` unique opening nodes.

Stop before mutation on any mismatch. Do not reset, clean, or reconstruct the
candidate.

AUDIT FINDINGS

Treat these findings as authoritative test-repair inputs:

```text
F15 Medium  the oversized-integer test mutates command, attempt, and effect
            records together; extraction stops at the command, so selective
            regressions in AttemptFenceV1, EffectFenceV1, and
            WorkerObservationV1 can pass

F16 Low     the pending-frame assertion derives its bound from production
            _CAPS rather than an independent literal and does not separately
            pin the complete result-cap tuple
```

The audit found no current production defect.

AUTHORIZED REPAIR PATHS

Only these two existing untracked candidate files may change:

```text
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_codec.py
```

The other fourteen candidate entries must remain byte-identical to the opening
manifest.

Because both repair files are untracked, final tracked textual-diff SHA-256 must
remain exactly:

```text
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6
```

No production source, document, inventory test, status test, public boundary,
dependency, schema, migration, package, or new repository file may change.

DIAGNOSTIC BEFORE EDIT

Before editing, run one read-only external diagnostic that reproduces both test
defects without changing repository bytes:

1. instrument the current oversized-integer fixture and record the exact C2A
   classes whose extraction/canonicalization boundaries are reached;
2. require the current fixture to reach only:
   - `WorkerCommandV1`; and
   - the nested `CeilingsV1`;
3. prove the current pending-frame assertion computes its bound from production
   `_CAPS`;
4. retain the diagnostic with exact source hashes and repository fingerprint.

If the diagnostic contradicts the audit finding, stop and report the
disagreement. Do not edit.

REPAIR 1 — LITERAL ISOLATED INTEGER MATRIX

A. Preserve the existing test node

Keep the existing node identity:

```text
tests/test_rw0_b2_wire_relations.py::test_oversized_c2a_integers_fail_before_owner_or_wire_canonicalization
```

Rewrite its body so it is an isolated representative check rather than a
multi-record corruption:

- start from one completely valid and related graph;
- tamper only `WorkerCommandV1.global_stop_version`;
- keep the attempt fence, effect fence, delivery, and every other object exact;
- test `MAX + 1` and a 1,000-digit integer;
- assert sealed `invalid_field_value`;
- assert zero calls to applicable owner and Wire reconstruction,
  canonicalization, digest, and framing surfaces;
- prove exact `MAX` remains accepted.

B. Add exactly one new top-level test node

Add exactly:

```text
tests/test_rw0_b2_wire_relations.py::test_every_reachable_c2a_integer_path_is_isolated_before_owner_or_wire_canonicalization
```

Do not parameterize this node. It must internally iterate one literal,
test-owned inventory so final collection gains exactly one node.

C. Literal inventory

The new test owns one literal tuple of exactly **64 reachable integer paths**.

Each inventory member must state at least:

```text
owner exact class
literal field path
public Wire boundary used
whether the field is direct or nested through CeilingsV1
valid exact-bound representative
oversized mutations
applicable owner/Wire spy surfaces
```

The inventory must cover every exact built-in integer path reachable through:

```text
CeilingsV1
AttemptFenceV1
EffectFenceV1
WorkerCommandV1
DeliveryEnvelopeV1
WorkerObservationV1
```

including:

- all fifteen ceiling leaves in every reachable owner position;
- `global_stop_version`;
- `process_exit_code`;
- every other integer field in the six committed C2A inventories.

The literal inventory must not be generated from Wire extractor constants.
The test may separately compare the literal inventory against committed C2A
`_FIELDS` and exact type ownership to prove completeness.

Assert:

```text
len(literal_integer_path_inventory) == 64
```

D. One mutation at a time

For each of the 64 cases:

1. construct a fresh, complete, otherwise valid and related graph;
2. tamper exactly one field in exactly one target object;
3. do not tamper command, attempt, effect, delivery, or observation together;
4. use an exact instance with only that slot changed;
5. invoke the first public Wire boundary that must consume the target class;
6. assert sealed `invalid_field_value`;
7. assert null cause/context and constant content-free error behavior;
8. assert zero calls to every applicable:
   - owner `from_mapping`;
   - owner `to_mapping`;
   - owner canonical identity;
   - owner digest;
   - Wire canonical JSON;
   - Wire digest;
   - Wire frame/payload construction;
9. run both:
   - `MAX + 1`; and
   - `int("9" * 1000)`.

A case that fails earlier because another object is invalid is noncausal.

E. Process-exit lower-bound preservation

Within the same new node, independently prove:

```text
process_exit_code = -255
process_exit_code = 0
process_exit_code = 255
```

remain accepted by the appropriate complete result relation/classifier path.

Do not add a B2 lower bound.

F. Selective-regression control

The new test must contain a bounded test-local control showing that suppressing
the B2 upper-bound check for one selected target class/path causes that exact
case to advance to an owner/Wire spy or otherwise cease producing the required
early rejection, while unrelated cases remain unchanged.

This control is diagnostic only; it must not alter authoritative production
state.

REPAIR 2 — INDEPENDENT PENDING-FRAME ORACLE

In:

```text
tests/test_rw0_b2_wire_codec.py
```

repair the existing 5,000-sibling pending-frame test.

Requirements:

1. assert the literal independent maximum pending-frame count:

   ```text
   5
   ```

2. do not compute that expectation from production `_CAPS`, profile mapping,
   or another production constant;

3. separately pin the complete result-cap tuple as a literal test-owned value:

   ```text
   (16_627, 4, 8, 77, 169, 66_770)
   ```

   ordered as:

   ```text
   payload_bytes
   depth
   containers
   key_pairs
   scalar_leaves
   hostile_units
   ```

4. compare the literal tuple independently with the fixed profile projection
   and the production cap representation;

5. preserve the 5,000-sibling hostile probe and require observed live pending
   frames `<= 5`;

6. include a test-local broken control showing that an oracle derived from
   production `_CAPS` would follow an inflated production depth while the
   literal bound remains 5;

7. do not change the test node name or add another codec node unless a genuine
   collection need is discovered; any such need is a stop condition.

PRODUCTION AND CONTRACT FREEZE

All production and governing identities remain exact:

```text
profile_ref:
rw0-wire-nwpf-v1

profile identity bytes:
4_021

profile digest:
470cb5bf96acd3163cea4e60b8fb6fdb2844ebb18db871d014eceae5fd596454

command payload/frame:
5_898 / 5_906

result payload/frame:
16_627 / 16_635

hostile units:
23_746 / 66_770

source mapping key maximum:
37

frame key maximum:
29

B2 maximum integer:
9_223_372_036_854_775_807
```

Do not modify:

```text
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
.docs/rw0-b2-wire-protocol.md
```

If the new isolated tests expose a production defect, stop. Do not repair it
under this test-only prompt.

NODE IDENTITY

Opening collection:

```text
4_654
```

Final collection must be exactly:

```text
4_655
```

Require:

- all 4,654 opening nodes remain in relative order;
- zero opening nodes removed, renamed, skipped, xfailed, collapsed, or
  reparameterized;
- exactly one addition:
  ```text
  tests/test_rw0_b2_wire_relations.py::test_every_reachable_c2a_integer_path_is_isolated_before_owner_or_wire_canonicalization
  ```
- no other node addition.

Stop on any node mismatch.

VALIDATION POSTURE

Create one new external operator-owned, non-symlink, mode-0700 repair root.

For every pytest child use:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
serial execution
actual caller/child numerical umask equality
```

Retain exact argv, environment, timing, return code, stdout/stderr, JUnit,
structured counts, and repository fingerprints.

FINAL VALIDATION ORDER

After final collection:

1. the existing repaired oversized-integer node;
2. the new 64-path isolation node;
3. the repaired pending-frame node;
4. full Wire relations file — expected `49` nodes;
5. full Wire codec file — expected `16` nodes;
6. all four Wire files together — expected `89` nodes:
   ```text
   tests/test_rw0_b2_wire_values.py
   tests/test_rw0_b2_wire_codec.py
   tests/test_rw0_b2_wire_relations.py
   tests/test_rw0_b2_wire_boundaries.py
   ```
7. corrected C2A/C2A1 compatibility — expected `637`;
8. B1 — expected `281`;
9. static/public — expected `105`;
10. status/docs — expected `858`;
11. `git diff --check`;
12. exact path/mode/protected/public/import/residue/operation/lock guards;
13. complete suite attempt 001 exactly once — expected `4_655`.

Every final focused gate and complete suite must have:

- return code 0;
- zero failures, errors, skips, xfails, warnings;
- empty stderr;
- parseable JUnit;
- no duplicate, ambiguous, or unmapped cases;
- unchanged candidate fingerprint before/after.

COMPLETE-SUITE REPAIR POLICY

If complete-suite attempt 001 fails:

- preserve all evidence;
- do not modify production or documentation;
- repair only when the failure is causally inside the two authorized test files,
  preserves every final node identity, and weakens no test;
- rerun affected focused gates;
- run complete-suite attempt 002 exactly once.

No third complete-suite attempt is authorized.

FINAL PROVENANCE

After final green validation and cleanup:

1. require exact topology:
   - 16 dirty paths
   - 10 tracked modifications
   - 6 untracked additions
   - 0 staged
   - 0 unmerged;
2. run the exact recipe twice;
3. require byte-identical complete outputs and manifests;
4. require exactly the original 16 paths;
5. compare against the opening target;
6. require exactly the two authorized test paths to differ;
7. require the other fourteen entries to remain byte-identical;
8. require tracked textual-diff SHA-256 to remain the pinned value;
9. prove every protected path equals HEAD;
10. retain final recipe source, complete-output hash, textual-diff hash,
    manifest hash, complete manifest, node delta, validation results, and
    guards.

STOP CONDITIONS

Stop without further mutation if:

- opening provenance differs;
- retained evidence changed;
- a third repair path or seventeenth candidate path is needed;
- any production or documentation byte must change;
- the literal integer inventory is not exactly 64 paths;
- one of the 64 cases cannot be isolated to one object and one field;
- zero-canonicalization cannot be proved for a case;
- the literal pending-frame bound 5 conflicts with accepted production behavior;
- an opening node changes identity;
- tests require skip/xfail/deletion/renaming/weakening;
- validation or provenance remains unstable.

CLOSEOUT TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_WIRE_FOURTH_AUDIT_TEST_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only if both findings are mechanically closed, final validation is exact-green,
provenance is stable, production/docs remain byte-identical, and no stop
condition fires.

The report must include:

1. opening identity and immutable target;
2. pre-edit diagnostic;
3. exact two-file delta;
4. literal 64-path inventory summary by owner class;
5. isolation and zero-call evidence;
6. process-exit lower-bound evidence;
7. literal pending-frame/result-cap oracle;
8. node delta;
9. every validation attempt;
10. final provenance and guards;
11. separate provenance, validation, production-behavior, and test-adequacy
    confidence.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
PRIOR_AUDIT_EVIDENCE_PRESERVED
```
