Here is Codex's response:

AUDIT\_PROVENANCE\_MISMATCH
