PROMPT_ID

RW0_B2_WIRE_ACCEPTED_COMMIT_AND_PR_GATE_V1

TITLE

Coordinator RW0-B2-Wire — stage the exact independently accepted bytes,
validate once, commit once, push once, and open one non-draft pull request

ENGAGEMENT TYPE

Audited-byte commit and publication gate.

This prompt authorizes only:

1. local read-only opening/provenance inspection;
2. read-only remote/GitHub preflight;
3. staging exactly the independently accepted 16 paths;
4. staged-byte validation without editing;
5. one Git commit;
6. one plain push to the named feature branch;
7. one non-draft pull request targeting `trunk_dev`.

No implementation repair is authorized. No byte change is authorized. Do not
amend, rebase, force-push, merge, enable auto-merge, self-review, resolve
threads, delete a branch, tag, release, deploy, or modify a supporting
repository.

Do not create subagents. You are the sole gate operator.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

ACCEPTED AUDIT VERDICT

The fresh independent audit returned exactly:

```text
ACCEPT
COORDINATOR_RW0_B2_WIRE_SIXTH_AUDIT_TEST_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

The accepted audit reported no Critical, High, Medium, or Low patch defect and
mechanically closed F1–F18.

OPENING REPOSITORY IDENTITY

Require exactly before any remote contact or Git write:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-wire-protocol-v1

HEAD:
02450d3c99faf0fe7b299b914afaed312421bc8b

tree:
0b5394c591bd277d56797794f71af954ccb93846

sole parent:
bf68a5232bff1b412c9414c076d82cab18c8e0aa

subject:
feat: implement RW0-B1 pure phase-entry semantics (#3)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty paths:
16

tracked modifications:
10

untracked additions:
6

staged:
0

unmerged:
0
```

Require every candidate path to be a regular working-tree mode-`0644` file.
Require no Git operation, lock, repository cache, bytecode, database, journal,
archive, build output, generated repository manifest, or recorder residue.
Require `git diff --check` clean.

Do not reset, clean, checkout another branch, or reconstruct a mismatch. Stop.

ACCEPTED IMPLEMENTATION TARGET

Repair evidence root:

```text
/private/tmp/rw0-b2-wire-sixth-repair.JqZLSt
```

Repair report:

```text
/private/tmp/rw0-b2-wire-sixth-repair.JqZLSt/final_provenance.json
```

Accepted audit evidence root:

```text
/private/tmp/rw0-b2-wire-sixth-audit.837YBq
```

The accepted audit independently reported the repair-report SHA-256:

```text
7122444f4a3057dc66e64f87e4517e4ec4729bfc24cb96e9f845bf69cfe988fb
```

Require the report to bind exactly one canonical manifest with:

```text
recipe ID:
governed-execution.audit-patch-manifest.v1

recipe source bytes:
3_945

recipe source SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

canonical-manifest SHA-256:
c1fe53703e61cb30394b944af063ad5b23f4fc472f48571b1064cbde2f79a358

complete-output SHA-256:
58421af36213dfb0c74232acee5a68a3fa64cda5ad98e88e38c6ea54562c534a

tracked textual-diff SHA-256:
2216ae23fa21de443d5db36f5639ef8d93f181e5b32b705eb10e1c5b83d409b6

file count:
16
```

Accepted node identity:

```text
candidate nodes:
4_655

candidate node-list SHA-256:
f36822a60056ec3d110956de561202b737662c9d22cd0dd82c4cdad6c7cef69f

HEAD nodes:
4_566

candidate-only:
89

HEAD-only:
0

Wire values / codec / relations / boundaries:
11 / 16 / 49 / 13
```

Retain the repair and audit evidence roots unchanged. Do not modify or
reconstruct their contents.

EXACT 16-PATH SET

Untracked additions:

```text
.docs/rw0-b2-wire-protocol.md
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

Tracked modifications:

```text
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
```

No seventeenth path, deletion, rename, copy, symlink, or recorded mode change
is authorized.

EXACT RECIPE SOURCE

Decode this base64 only into a new external gate evidence root, verify exact
size and SHA-256, and retain it mode `0400`:

```text
ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCBzdGF0CmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVDSVBFX0lEID0gImdvdmVybmVkLWV4ZWN1dGlvbi5hdWRpdC1wYXRjaC1tYW5pZmVzdC52MSIKT1VUUFVUX1BBVEggPSBQYXRoKCIvdG1wL2dlLWNvb3JkaW5hdG9yLWIzYS1hdWRpdC1tYW5pZmVzdC12MS5qc29uIikKCgpkZWYgZ2l0X2J5dGVzKCphcmdzOiBzdHIpIC0+IGJ5dGVzOgogICAgZW52ID0gb3MuZW52aXJvbi5jb3B5KCkKICAgIGVudlsiTENfQUxMIl0gPSAiQyIKICAgIGVudlsiTEFORyJdID0gIkMiCiAgICByZXN1bHQgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbImdpdCIsICphcmdzXSwKICAgICAgICBjaGVjaz1UcnVlLAogICAgICAgIHN0ZG91dD1zdWJwcm9jZXNzLlBJUEUsCiAgICAgICAgc3RkZXJyPXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBlbnY9ZW52LAogICAgKQogICAgcmV0dXJuIHJlc3VsdC5zdGRvdXQKCgpkZWYgZ2l0X3RleHQoKmFyZ3M6IHN0cikgLT4gc3RyOgogICAgcmV0dXJuIGdpdF9ieXRlcygqYXJncykuZGVjb2RlKCJ1dGYtOCIsICJzdHJpY3QiKS5zdHJpcCgpCgoKZGVmIG51bF9wYXRocyhkYXRhOiBieXRlcykgLT4gbGlzdFtzdHJdOgogICAgcmV0dXJuIFsKICAgICAgICBpdGVtLmRlY29kZSgidXRmLTgiLCAic3RyaWN0IikKICAgICAgICBmb3IgaXRlbSBpbiBkYXRhLnNwbGl0KGIiXDAiKQogICAgICAgIGlmIGl0ZW0KICAgIF0KCgpoZWFkID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICJIRUFEIikKYnJhbmNoID0gZ2l0X3RleHQoImJyYW5jaCIsICItLXNob3ctY3VycmVudCIpCnVwc3RyZWFtID0gZ2l0X3RleHQoInJldi1wYXJzZSIsICItLWFiYnJldi1yZWYiLCAiLS1zeW1ib2xpYy1mdWxsLW5hbWUiLCAiQHt1fSIpCgp0cmFja2VkID0gc2V0KAogICAgbnVsX3BhdGhzKGdpdF9ieXRlcygiZGlmZiIsICItLW5hbWUtb25seSIsICItLW5vLXJlbmFtZXMiLCAiLXoiLCAiSEVBRCIsICItLSIpKQopCmFkZGVkID0gc2V0KAogICAgbnVsX3BhdGhzKAogICAgICAgIGdpdF9ieXRlcygKICAgICAgICAgICAgImRpZmYiLAogICAgICAgICAgICAiLS1uYW1lLW9ubHkiLAogICAgICAgICAgICAiLS1uby1yZW5hbWVzIiwKICAgICAgICAgICAgIi0tZGlmZi1maWx0ZXI9QSIsCiAgICAgICAgICAgICIteiIsCiAgICAgICAgICAgICJIRUFEIiwKICAgICAgICAgICAgIi0tIiwKICAgICAgICApCiAgICApCikKZGVsZXRlZCA9IHNldCgKICAgIG51bF9wYXRocygKICAgICAgICBnaXRfYnl0ZXMoCiAgICAgICAgICAgICJkaWZmIiwKICAgICAgICAgICAgIi0tbmFtZS1vbmx5IiwKICAgICAgICAgICAgIi0tbm8tcmVuYW1lcyIsCiAgICAgICAgICAgICItLWRpZmYtZmlsdGVyPUQiLAogICAgICAgICAgICAiLXoiLAogICAgICAgICAgICAiSEVBRCIsCiAgICAgICAgICAgICItLSIsCiAgICAgICAgKQogICAgKQopCnVudHJhY2tlZCA9IHNldCgKICAgIG51bF9wYXRocyhnaXRfYnl0ZXMoImxzLWZpbGVzIiwgIi0tb3RoZXJzIiwgIi0tZXhjbHVkZS1zdGFuZGFyZCIsICIteiIpKQopCgppZiB0cmFja2VkICYgdW50cmFja2VkOgogICAgcmFpc2UgU3lzdGVtRXhpdCgidHJhY2tlZC91bnRyYWNrZWQgcGF0aCBvdmVybGFwIikKCmVudHJpZXM6IGxpc3RbZGljdFtzdHIsIG9iamVjdF1dID0gW10KZm9yIHJlbGF0aXZlX3BhdGggaW4gc29ydGVkKHRyYWNrZWQgfCB1bnRyYWNrZWQpOgogICAgaWYgcmVsYXRpdmVfcGF0aCBpbiB1bnRyYWNrZWQ6CiAgICAgICAga2luZCA9ICJ1bnRyYWNrZWQiCiAgICBlbGlmIHJlbGF0aXZlX3BhdGggaW4gZGVsZXRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfZGVsZXRlZCIKICAgIGVsaWYgcmVsYXRpdmVfcGF0aCBpbiBhZGRlZDoKICAgICAgICBraW5kID0gInRyYWNrZWRfYWRkZWQiCiAgICBlbHNlOgogICAgICAgIGtpbmQgPSAidHJhY2tlZF9tb2RpZmllZCIKCiAgICBlbnRyeTogZGljdFtzdHIsIG9iamVjdF0gPSB7CiAgICAgICAgImtpbmQiOiBraW5kLAogICAgICAgICJwYXRoIjogcmVsYXRpdmVfcGF0aCwKICAgIH0KCiAgICBpZiBraW5kID09ICJ0cmFja2VkX2RlbGV0ZWQiOgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6ICJtaXNzaW5nIiwKICAgICAgICAgICAgICAgICJtb2RlIjogTm9uZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBOb25lLAogICAgICAgICAgICAgICAgInNpemUiOiBOb25lLAogICAgICAgICAgICB9CiAgICAgICAgKQogICAgZWxzZToKICAgICAgICBwYXRoID0gUGF0aChyZWxhdGl2ZV9wYXRoKQogICAgICAgIG1ldGFkYXRhID0gcGF0aC5sc3RhdCgpCiAgICAgICAgbW9kZSA9IGYie3N0YXQuU19JTU9ERShtZXRhZGF0YS5zdF9tb2RlKTowNG99IgogICAgICAgIGlmIHN0YXQuU19JU1JFRyhtZXRhZGF0YS5zdF9tb2RlKToKICAgICAgICAgICAgcGF5bG9hZCA9IHBhdGgucmVhZF9ieXRlcygpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJyZWd1bGFyIgogICAgICAgIGVsaWYgc3RhdC5TX0lTTE5LKG1ldGFkYXRhLnN0X21vZGUpOgogICAgICAgICAgICBwYXlsb2FkID0gb3MucmVhZGxpbmsocGF0aCkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgICAgIGZpbGVfdHlwZSA9ICJzeW1saW5rIgogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ1bnN1cHBvcnRlZCBmaWxlIHR5cGU6IHtyZWxhdGl2ZV9wYXRofSIpCgogICAgICAgIGVudHJ5LnVwZGF0ZSgKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgImZpbGVfdHlwZSI6IGZpbGVfdHlwZSwKICAgICAgICAgICAgICAgICJtb2RlIjogbW9kZSwKICAgICAgICAgICAgICAgICJzaGEyNTYiOiBoYXNobGliLnNoYTI1NihwYXlsb2FkKS5oZXhkaWdlc3QoKSwKICAgICAgICAgICAgICAgICJzaXplIjogbGVuKHBheWxvYWQpLAogICAgICAgICAgICB9CiAgICAgICAgKQoKICAgIGVudHJpZXMuYXBwZW5kKGVudHJ5KQoKZGlmZl9ieXRlcyA9IGdpdF9ieXRlcygKICAgICJkaWZmIiwKICAgICItLWZ1bGwtaW5kZXgiLAogICAgIi0tYmluYXJ5IiwKICAgICItLW5vLWV4dC1kaWZmIiwKICAgICItLW5vLXRleHRjb252IiwKICAgICItLW5vLXJlbmFtZXMiLAogICAgIkhFQUQiLAogICAgIi0tIiwKKQp0ZXh0dWFsX2RpZmZfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoZGlmZl9ieXRlcykuaGV4ZGlnZXN0KCkKCm1hbmlmZXN0ID0gewogICAgImJyYW5jaCI6IGJyYW5jaCwKICAgICJmaWxlcyI6IGVudHJpZXMsCiAgICAiaGVhZCI6IGhlYWQsCiAgICAicmVjaXBlX2lkIjogUkVDSVBFX0lELAogICAgInRleHR1YWxfZGlmZl9zaGEyNTYiOiB0ZXh0dWFsX2RpZmZfc2hhMjU2LAogICAgInVwc3RyZWFtIjogdXBzdHJlYW0sCn0KCmNhbm9uaWNhbCA9ICgKICAgIGpzb24uZHVtcHMoCiAgICAgICAgbWFuaWZlc3QsCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgICAgIHNvcnRfa2V5cz1UcnVlLAogICAgICAgIHNlcGFyYXRvcnM9KCIsIiwgIjoiKSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCiAgICArIGIiXG4iCikKbWFuaWZlc3Rfc2hhMjU2ID0gaGFzaGxpYi5zaGEyNTYoY2Fub25pY2FsKS5oZXhkaWdlc3QoKQpPVVRQVVRfUEFUSC53cml0ZV9ieXRlcyhjYW5vbmljYWwpCgpwcmludChmInJlY2lwZV9pZD17UkVDSVBFX0lEfSIpCnByaW50KGYidGV4dHVhbF9kaWZmX3NoYTI1Nj17dGV4dHVhbF9kaWZmX3NoYTI1Nn0iKQpwcmludChmIm1hbmlmZXN0X3NoYTI1Nj17bWFuaWZlc3Rfc2hhMjU2fSIpCnByaW50KGYiZmlsZV9jb3VudD17bGVuKGVudHJpZXMpfSIpCnByaW50KGNhbm9uaWNhbC5kZWNvZGUoInV0Zi04IiksIGVuZD0iIikK
```

The source historically writes:

```text
/tmp/ge-coordinator-b3a-audit-manifest-v1.json
```

Do not overwrite or alter pre-existing evidence at that path. Execute the exact
recipe source unchanged while an external wrapper redirects only that exact
`Path.write_bytes` sink to unique files under the gate root. Do not alter Git
reads, canonicalization, stdout, stderr, or source bytes.

EVIDENCE ROOT

Create one new operator-owned, non-symlink, mode-`0700` gate root under
`/private/tmp`.

All retained gate evidence files must be regular, operator-owned, and mode
`0400` at closeout. Do not index the evidence index itself.

PHASE 1 — LOCAL PROVENANCE GATE

Before remote contact or staging:

1. lstat every component of:
   - repair evidence root;
   - accepted audit root;
   - repair report;
   - report-bound canonical manifest;
   - copied recipe;
   - new gate root;
2. require safe ownership, no symlink traversal, regular required files, and
   mode-`0700` evidence roots;
3. verify the repair report exact SHA-256;
4. require one unique report-bound canonical target;
5. run the exact recipe twice;
6. require:
   - both complete outputs byte-identical;
   - both manifests byte-identical;
   - generated manifest byte-identical to the accepted canonical target;
   - all accepted aggregate identities exact;
7. compare every live candidate file with the accepted manifest by:
   - path;
   - classification;
   - file type;
   - working-tree mode;
   - byte size;
   - SHA-256;
8. verify protected complement equality to HEAD;
9. verify exact 16-path topology and zero staged/unmerged paths;
10. verify `git diff --check`, operation, lock, and residue guards.

Stop on any mismatch with:

```text
COMMIT_GATE_PROVENANCE_MISMATCH
```

Do not repair or rerun implementation.

PHASE 2 — READ-ONLY REMOTE AND POLICY PREFLIGHT

Only after the local provenance gate passes, authorize read-only remote/GitHub
contact.

Verify:

```text
origin repository:
evo-agi/Governed-Execution-Coordinator

base branch:
trunk_dev

base ref:
02450d3c99faf0fe7b299b914afaed312421bc8b

feature branch:
codex/rw0-b2-wire-protocol-v1
```

Require:

1. authenticated GitHub identity is available and recorded;
2. remote `trunk_dev` still equals the accepted base;
3. no remote feature ref with the exact feature name exists;
4. no open, closed, or merged PR already uses the exact head branch or exact
   title;
5. no conflicting tag or named ref exists;
6. effective branch/ruleset policy is read and recorded;
7. a PR to `trunk_dev` is permitted;
8. squash/merge policy and review/thread/status requirements are recorded;
9. no bypass is requested or used.

Stop without staging if the base moved, the feature ref/PR already exists, the
repository identity differs, or policy cannot be satisfied.

PHASE 3 — STAGE EXACT AUDITED PATHS

Create one NUL-terminated path list from the accepted canonical manifest.

Stage exactly those 16 paths with a pathspec-from-file operation. Do not use
`git add .`, glob staging, interactive staging, or an inferred path list.

After staging, require exactly:

```text
10 M
6 A
0 D
0 R
0 C
0 unmerged
```

Require:

- no unstaged candidate-byte difference;
- no extra staged path;
- all staged Git modes exactly `100644`;
- each staged blob’s bytes, size, and SHA-256 equal the accepted manifest;
- every working-tree candidate byte equals its staged blob;
- the staged tree differs from HEAD only at the accepted 16 paths;
- `git diff --cached --check` clean.

Record the complete cached binary diff SHA-256.

Stop and unstage all 16 accepted paths if any staged-byte, mode, scope, or
classification check fails. Do not modify working bytes.

PHASE 4 — STAGED-BYTE VALIDATION

Run validation serially against the exact staged/working bytes. No repository
byte may change.

Use one isolated external validation area beneath the gate root.

For every pytest child use:

```text
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct external --basetemp
distinct external --junitxml
```

Capture the actual caller umask, restore it before every child, and require
child-observed numerical equality.

A. Collection

Run one staged candidate collection exactly once.

Require:

```text
4_655 unique nodes
node-list SHA-256:
f36822a60056ec3d110956de561202b737662c9d22cd0dd82c4cdad6c7cef69f
```

Do not grep arbitrary node names or stdout for words such as `warning`,
`skipped`, or `error`. Test names may legitimately contain such words. Use
pytest return code, structured collection output, and JUnit attributes.

B. Complete suite

Run the complete repository suite exactly once:

```text
python3 -B -m pytest -p no:cacheprovider -W error   --basetemp=<external>   --junitxml=<external>   -q .
```

Require exactly:

```text
4_655 collected
4_655 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
0 duplicate JUnit identities
0 unmapped JUnit cases
```

No retry is authorized. A recorder or harness defect is still a stop; do not
reinterpret or rerun the gate under this prompt.

Before and after collection and the full suite require:

- candidate working bytes equal accepted manifest;
- staged blobs equal accepted manifest;
- no additional path;
- no residue;
- no operation/lock;
- same caller/child umask.

On any validation failure:

1. retain all evidence;
2. unstage exactly the 16 paths;
3. preserve working bytes;
4. stop with:
   ```text
   COMMIT_GATE_VALIDATION_FAILED
   ```

No repair is authorized.

PHASE 5 — ONE COMMIT

Only after all prior gates pass, create exactly one commit.

Exact subject:

```text
feat: implement RW0-B2 Wire protocol
```

Commit body: empty.

Do not amend, sign retroactively, rebase, or create a second commit.

Require:

- sole parent:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- exactly 16 changed files;
- exactly 10 modifications and 6 additions;
- no deletion, rename, copy, or mode change;
- committed modes all `100644`;
- every committed blob byte-for-byte equal to the accepted manifest;
- commit tree equal to the precomputed staged tree;
- working tree and index clean after commit.

Record commit OID, tree, parent, author, committer, timestamps, subject, body,
and signature status.

Stop before push on any mismatch. Do not amend.

PHASE 6 — ONE PLAIN PUSH

Before push, recheck remote `trunk_dev` remains the accepted base and the remote
feature ref remains absent.

Run exactly one push:

```text
git push -u origin HEAD:refs/heads/codex/rw0-b2-wire-protocol-v1
```

Do not force-push, push `trunk_dev`, push tags, or retry.

Require:

- remote feature ref equals the local commit;
- remote `trunk_dev` remains
  `02450d3c99faf0fe7b299b914afaed312421bc8b`;
- local branch tracks
  `origin/codex/rw0-b2-wire-protocol-v1`;
- local/remote feature divergence is `0/0`.

Stop before PR creation on any mismatch. Do not issue a second push.

PHASE 7 — ONE NON-DRAFT PR

Create exactly one non-draft pull request.

Repository:

```text
evo-agi/Governed-Execution-Coordinator
```

Base:

```text
trunk_dev
```

Head:

```text
codex/rw0-b2-wire-protocol-v1
```

Exact title:

```text
feat: implement RW0-B2 Wire protocol
```

Exact UTF-8 PR body follows. Write these bytes to one external body file:

```markdown
## Summary

- implement the private, pure RW0-B2 Wire protocol profile and NWPF v1 command/result codecs
- add bounded source-claim values, exact C2A relations, and deterministic process/result classification
- preserve B1/C2A identities, private no-I/O boundaries, and later-owner seams for Capability, persistence, transport, and execution

## Validation

- independent read-only audit: `ACCEPT`
- full repository suite: `4,655 passed`
- candidate-only Wire tests: `89`

## Non-claims

- no process execution, transport, persistence, provider or Codex mechanism, Capability implementation, source authentication, authority, or semantic acceptance
```

Expected body identity:

```text
bytes:
649

SHA-256:
af67b1e7f20a6979932c16153f53554d5a334a2503359ddb61eb479912c44e94
```

Create the PR exactly once. Do not enable auto-merge, request a self-review,
submit a review, resolve a thread, or merge.

Verify through GitHub:

- PR exists once;
- open;
- non-draft;
- base ref and base OID exact;
- head ref and head OID exact;
- title exact;
- API body bytes exact;
- one commit;
- sixteen files;
- merged false;
- auto-merge absent;
- checks, reviews, threads, comments, and mergeability state recorded honestly;
- no rule bypass.

A transient `UNKNOWN` mergeability calculation may be reported, but do not poll
repeatedly or modify the branch merely to obtain `CLEAN`.

PHASE 8 — FINAL CLOSEOUT

Require:

- local worktree/index clean;
- one worktree;
- no Git operation or lock;
- no repository residue;
- local and remote feature refs equal the one commit;
- remote `trunk_dev` unchanged;
- feature branch retained;
- PR open and unmerged;
- no source repair, second commit, second push, second PR, merge, tag, release,
  or deployment.

Create a final mode-`0400` evidence index beneath the gate root containing every
retained gate file except the index itself. Record size and SHA-256 for each
entry.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_WIRE_PROTOCOL_COMMITTED_PUSHED_AND_PR_OPENED
```

only if every gate passes.

FINAL REPORT

Include:

1. accepted manifest and audit identities;
2. opening local identity;
3. remote/ruleset preflight;
4. staged path/blob/mode comparison;
5. collection and full-suite result;
6. commit OID/tree/parent/metadata;
7. push command and remote ref results;
8. PR URL/number/title/body/base/head/state;
9. final worktree/ref/policy guards;
10. evidence-root and evidence-index identities;
11. limitations and separate confidence for provenance and validation.

Required final statements:

```text
IMPLEMENTATION_REPAIR_NOT_PERFORMED
INDEPENDENT_AUDIT_NOT_REPEATED
DIRECT_TRUNK_PUSH_NOT_PERFORMED
BYPASS_NOT_USED
FORCE_PUSH_NOT_PERFORMED
AMEND_NOT_PERFORMED
SECOND_COMMIT_NOT_PERFORMED
SECOND_PUSH_NOT_PERFORMED
SECOND_PR_NOT_CREATED
PR_MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
REVIEW_NOT_SELF_APPROVED
FEATURE_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
COLLECTION_RUN_EXACTLY_ONCE
FULL_SUITE_RUN_EXACTLY_ONCE
```
