## Engineering decision

The readiness split is correct and materially improves sequencing.

**RW0-B2-Wire receives the implementation-readiness gate.** It must freeze the exact command/result composition, bytes, parser behavior, canonicalization, result grammar, process/result classification, bounds, work accounting, error precedence, module ownership, touched-file ceiling, tests, validation, provenance, and stop conditions.

**RW0-B2-Capability receives a seam-compatibility gate.** The same reconnaissance must establish that Wire leaves room for a later provider-neutral declaration/observation/qualification contract, without requiring Capability’s complete implementation schema prematurely. Capability must remain distinct from source authentication, permission, acceptance, and executable authority. B1 remains unchanged: it is a private pure layer over supplied evidence and grants no permission, contact, or durable state. 

The resulting progression rule is:

| Wire status | Capability status | Next step |
|---|---|---|
| `WIRE_RECONNAISSANCE_READY` | `CAPABILITY_SEAM_BOUNDED` | One bounded Wire implementation prompt is permitted |
| `WIRE_RECONNAISSANCE_READY` | `CAPABILITY_FREEZE_READY` | One bounded Wire implementation prompt is permitted; Capability implementation still waits |
| `WIRE_RECONNAISSANCE_PARTIAL` | Any | No implementation |
| `WIRE_RECONNAISSANCE_BLOCKED` | Any | No implementation |
| Any | `CAPABILITY_BLOCKED` | No implementation until the contradiction is resolved |

A Capability uncertainty affects Wire only when it demonstrates that Wire’s bytes, identities, grammar, limits, or process/result classification would make the later provider-neutral contract incoherent or break the accepted B2/D/E ownership split.

The replacement preserves:

- the merged baseline;
- four bounded read-only explorers;
- the B1-derived semantic-completeness discipline;
- mechanically derived caps and work budgets;
- the contradiction matrix;
- provider/mechanism neutrality;
- no mutation, tests, remote contact, or implementation;
- the existing prospective forecasts as discussion evidence rather than acceptance criteria.

It also explicitly prohibits the old combined `RW0_B2_RECONNAISSANCE_*` verdicts. Codex must return one Wire status and one Capability status separately.

This remains consistent with the project operating model: reconnaissance and mutation occur in separate turns, the parent is the sole later writer, and independent audit remains a fresh subsequent conversation.  Exact provenance remains evidence that later implementation and audit inspect the same bytes; it cannot establish semantic correctness by itself. 

## Complete replacement Codex prompt

The following text file is the **complete, authoritative, self-contained replacement**. It supersedes the unexecuted draft; no fragments need to be combined.

---

### BEGIN COMPLETE REPLACEMENT CODEX PROMPT

:chatgpt-content-reference{index="3"}

**File:** `Coordinator_RW0_B2_Wire_Freeze_Capability_Seam_Reconnaissance_REPLACEMENT.txt`  
**Size:** 45,330 bytes  
**Posture:** read-only reconnaissance; four explorers; no tests or mutation

### END COMPLETE REPLACEMENT CODEX PROMPT

---

Its required normal response begins with exactly two status lines, for example:

```text
RW0_B2_WIRE_RECONNAISSANCE_READY
RW0_B2_CAPABILITY_SEAM_BOUNDED
```

That combination permits the next prompt to implement **Wire only**. It does not authorize Capability implementation.

### Sources

- Accepted B1 non-authority and supplied-evidence boundary. 
- Separate reconnaissance, parent-only implementation, and fresh-audit workflow. 
- Provenance as byte-binding evidence rather than correctness or authority. 

**Confidence:** High that the split readiness gate is the correct sequencing model; high that Capability can remain seam-bounded without delaying an exact Wire freeze; moderate that current C2A bounds will support a mechanically derived finite Wire payload maximum without a separate owning-contract amendment.
