PROMPT_ID

RW0_B2_WIRE_FOCUSED_VALIDATION_CONTINUATION_V4

TITLE

Coordinator RW0-B2-Wire — correct the C2A validation target, repair the three
EOF whitespace defects, and complete implementation closeout

SUPERSESSION

This complete prompt supersedes every earlier RW0-B2-Wire continuation prompt
for the current stopped workspace.

Do not use any prompt that:

- names `tests/test_c2a1_pure_semantic_values.py`;
- requires a clean `trunk_dev` checkout;
- requires creation of the existing feature branch;
- reopens candidate collection attempt 001 or the already completed node-
  placement repair.

The missing test path was an instruction defect. It is not a repository defect
and does not authorize substitution by guess.

ENGAGEMENT TYPE

Parent-only workspace-write continuation in the existing
`codex/rw0-b2-wire-protocol-v1` implementation conversation.

Do not create or resume subagents. You remain the sole repository writer.

This continuation authorizes only:

1. exact rebaseline of the current stopped 16-path candidate;
2. whitespace-only repair of the three reported EOF blank-line defects;
3. one final node-identity verification collection after those body/whitespace
   repairs;
4. the corrected C2A/C2A1 compatibility gate;
5. the remaining B1, static, status, full-suite, guard, cleanup, and provenance
   gates already authorized.

It does not reopen the accepted Wire contract, profile, ownership, framing,
classifier, privacy, bounds, touched-file allowlist, or Capability disposition.

It is not an independent audit, commit gate, publication gate, or Capability
implementation.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED STOPPED STATE

Before any edit, require and record:

- branch:
  `codex/rw0-b2-wire-protocol-v1`
- HEAD:
  `02450d3c99faf0fe7b299b914afaed312421bc8b`
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- upstream:
  `origin/trunk_dev`
- worktrees:
  `1`
- dirty paths:
  exactly 16
- tracked modifications:
  exactly 10
- untracked additions:
  exactly 6
- staged/unmerged:
  `0/0`
- every candidate path:
  regular mode `0644`
- no seventeenth dirty path
- no Git operation or lock
- no repository-local cache, bytecode, database, journal, build, archive, or
  recorder residue
- retained evidence roots remain present and unchanged:
  - `/private/tmp/rw0-b2-wire.H4lagH`
  - `/private/tmp/rw0-b2-wire-continuation.c0PCWE`

Require the current path set and classifications to equal the frozen 16-path
allowlist.

Stop before mutation on any mismatch. Do not reset, clean, switch branches,
discard candidate bytes, or contact a remote.

PRESERVED EVIDENCE AND CURRENT STATUS

Preserve without overwrite:

- historical candidate-collection attempt 001;
- continuation-opening provenance;
- continuation-opening reconciliation collection;
- corrected candidate collection:
  - 4,626 nodes;
  - all 4,566 opening nodes preserved;
  - exactly 60 additions in the four new Wire test files;
- every Wire test-file individual run;
- the successful all-Wire run:
  `60/60`;
- the initial codec mutant failure and its successful body-only repair evidence;
- the invalid C2A command invocation:
  - return code 4;
  - zero tests collected;
  - missing path
    `tests/test_c2a1_pure_semantic_values.py`;
- all repository fingerprints and manifests already retained.

Classify the invalid C2A invocation as:

```text
VALIDATION_COMMAND_TARGET_DEFECT
CANDIDATE_TEST_FAILURE_NOT_OBSERVED
```

It is not focused-gate attempt 001 against a real test target and is not a
full-suite attempt.

NEW CONTINUATION EVIDENCE ROOT

Create one new operator-owned, non-symlink, mode-0700 evidence root under
`/private/tmp`.

All retained key evidence must be regular, operator-owned, and mode `0400` at
closeout.

Use distinct external:

- `TMPDIR`;
- `PYTHONPYCACHEPREFIX`;
- pytest `--basetemp`;
- JUnit;
- stdout/stderr;
- structured result records.

Do not write evidence into the repository.

CURRENT-CANDIDATE PROVENANCE — BEFORE EDIT

Use the exact retained
`governed-execution.audit-patch-manifest.v1` source.

Require source identity:

```text
size:
3_945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

Run the exact recipe twice against the current stopped candidate before
mutation.

Require:

- return code 0;
- empty stderr;
- byte-identical complete output;
- byte-identical canonical manifests;
- exactly 16 entries;
- exact 10 tracked modifications and 6 untracked additions;
- regular mode `0644` for every entry;
- complete path/classification/type/mode/size/SHA-256 identity;
- exact branch/HEAD/upstream;
- no repository-byte change from the recipe runs.

Save one immutable V4 opening manifest mode `0400`.

If the exact recipe source is unavailable or output is unstable, stop. Do not
reconstruct or approximate it.

AUTHORIZED REPOSITORY REPAIR

Modify exactly these three existing candidate paths:

```text
tests/test_architecture_contracts.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_software_development_progression_boundary.py
```

The repair is limited to removing the EOF blank-line defects reported by
`git diff --check`.

Requirements:

- whitespace-only EOF repair;
- preserve all code, assertions, mutants, comments, imports, function names,
  signatures, decorators, parameterization, and collection identities;
- preserve the node-placement integration completed in the previous turn;
- do not change any production or documentation file;
- do not modify the four new Wire test files;
- do not modify any other candidate path.

After the repair:

1. run `git diff --check`;
2. require it to return 0 with no output;
3. inspect the three diffs and prove only terminal blank-line bytes changed;
4. require the other thirteen candidate paths to remain byte-identical to the
   V4 opening manifest.

Stop if another whitespace defect requires another path.

FINAL NODE-IDENTITY VERIFICATION COLLECTION

The previous corrected collection was valid, but a body-only codec-test repair
and the authorized EOF repairs occurred afterward. Authorize one final
read-only collection solely to bind final node identity.

Run one isolated complete collection exactly once after `git diff --check`
passes.

Call it:

```text
final-node-verification-collection
```

Require exactly:

```text
opening committed nodes:       4,566
final candidate nodes:         4,626
net additions:                 60
removed:                       0
renamed:                       0
duplicates:                    0
```

All 60 additions must belong to exactly:

```text
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

Require:

- every opening node remains in the same relative order;
- the three formerly misplaced existing-file nodes remain absent;
- no decorator/parameterization/skip/xfail/collection-control drift;
- exact node-list, literal set/order comparison, and repository fingerprints
  before/after.

This final verification collection explicitly supersedes the earlier
“no further collection” instruction because the accepted codec body repair and
the EOF byte repair occurred after the corrected collection. It does not reopen
the node-placement gate.

Stop on any mismatch. No second final verification collection is authorized.

FINAL WIRE GATE

After the final node collection passes, run all four Wire test files together
once on the final bytes:

```text
tests/test_rw0_b2_wire_values.py
tests/test_rw0_b2_wire_codec.py
tests/test_rw0_b2_wire_relations.py
tests/test_rw0_b2_wire_boundaries.py
```

Require:

- 60 collected and passed;
- zero failures, errors, skips, xfails, warnings;
- empty stderr;
- no duplicate or unmapped JUnit cases;
- candidate fingerprint unchanged.

Preserve the earlier individual and combined Wire evidence; this final combined
run binds the Wire behavior to the whitespace-corrected final candidate.

CORRECTED C2A/C2A1 COMPATIBILITY GATE

Do not invoke the nonexistent path:

```text
tests/test_c2a1_pure_semantic_values.py
```

The exact current C2A/C2A1 compatibility target is:

```text
tests/test_worker_execution_semantic_values.py
tests/test_worker_execution_semantic_vectors.py
tests/test_worker_execution_semantic_relations.py
tests/test_worker_execution_semantic_boundaries.py
tests/test_c2a_relations.py
tests/test_c2a_first_slice_semantic_protocol_contract.py
tests/test_c2a_effects_and_recovery.py
```

This literal list replaces the prior glob plus nonexistent path. Do not omit,
substitute, or add another file.

Run it exactly once under the isolated recorder posture.

Require:

- return code 0;
- nonzero collection;
- zero failures, errors, skips, xfails, warnings;
- empty stderr;
- parseable JUnit;
- no duplicate, ambiguous, or unmapped cases;
- unchanged candidate fingerprint.

A missing path in this corrected literal list is now a genuine baseline
mismatch and a stop condition.

REMAINING FOCUSED GATES

After corrected C2A/C2A1 compatibility is green, continue serially.

B1 compatibility:

```text
tests/test_rw0_b1_*.py
```

Static/public/import boundaries:

```text
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
tests/test_c2b2_development_row_value_boundaries.py
tests/test_b2a_writer_session_contract.py
tests/test_codex_agent_config.py
```

Status/document compatibility:

```text
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_software_development_progression_boundary.py
tests/test_remote_worker_pre_execution_planning_contract.py
```

The status gate must prove the three EOF-only repairs changed no substantive
assertion or oracle behavior.

Every focused run must have:

- return code 0;
- zero failures, errors, skips, xfails, warnings;
- empty stderr;
- parseable JUnit;
- no duplicate, ambiguous, or unmapped cases;
- equal caller/child numerical umask;
- exact candidate fingerprint before/after.

FOCUSED FAILURE REPAIR RULE

If a real focused test gate fails:

- preserve complete failure evidence;
- repair only when causally attributable to this candidate;
- remain inside the original 16-path allowlist;
- preserve the accepted Wire contract, profile, caps, ownership, and exact
  4,626 node identities;
- weaken no test;
- rerun the affected and dependent focused gates.

Stop if repair requires:

- a seventeenth path;
- C2A/B1/public/schema/dependency/runtime change;
- contract/profile/cap/ownership revision;
- node-identity change;
- unrelated mutation.

FINAL GUARDS BEFORE FULL SUITE

Require:

- `git diff --check` clean;
- exact topology `16 / 10 / 6 / 0 / 0`;
- exact path set and regular mode-0644 posture;
- no add/delete/rename/copy/mode/symlink drift;
- package-root/public/dependency/schema/migration/StateStore/WriterSession
  protections exact;
- C2A and B1 protected bytes exact;
- no repository residue, Git operation, or lock.

COMPLETE SUITE

No full-suite attempt has yet occurred.

After every focused gate and guard is green, run complete-suite attempt 001
exactly once under the isolated recorder posture.

Require the JUnit cases to map exactly and uniquely to the frozen 4,626-node
list.

If attempt 001 is green, do not rerun it.

If attempt 001 fails:

- preserve all evidence;
- repair only when every failure is demonstrably candidate-caused, inside the
  16-path allowlist, contract-preserving, node-identity-preserving, and
  test-nonweakening;
- rerun affected and dependent focused gates;
- run complete-suite attempt 002 exactly once.

No third complete-suite attempt is authorized.

FINAL PROVENANCE

After exact-green validation and cleanup:

1. require topology:
   - 16 dirty paths
   - 10 tracked modifications
   - 6 untracked additions
   - 0 staged
   - 0 unmerged;
2. run the exact provenance recipe twice;
3. require byte-identical complete output and canonical manifests;
4. require exactly the original 16-path allowlist;
5. compare against the V4 opening manifest;
6. enumerate every V4 byte change:
   - exactly the three EOF-only existing-test repairs;
   - any later explicitly permitted focused/full-suite repair;
7. prove every protected path equals HEAD;
8. retain complete per-path identities, tracked-diff digest, manifest digest,
   complete-output digest, validation evidence, and final guards;
9. remove only continuation-created transient artifacts.

Do not perform an independent audit, stage, commit, push, create a PR, merge,
tag, release, deploy, contact a remote, or implement Capability.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_WIRE_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT
```

only if:

- the V4 opening provenance is exact;
- the three EOF repairs are whitespace-only;
- final node verification is exactly 4,626;
- final Wire, corrected C2A/C2A1, B1, static, and status gates are green;
- the complete suite is green;
- final provenance is stable and exact;
- no stop condition fires.

The report must distinguish:

1. historical candidate-collection attempt 001;
2. V3 continuation rebaseline and collections;
3. the initial codec mutant failure and body-only repair;
4. the invalid nonexistent-path C2A command;
5. V4 opening provenance;
6. EOF repairs;
7. final node verification;
8. every final focused and complete-suite attempt;
9. final provenance;
10. provenance, validation, and implementation confidence separately.

Required final statements:

```text
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
CAPABILITY_IMPLEMENTATION_NOT_PERFORMED
INVALID_C2A_TARGET_INVOCATION_PRESERVED
FINAL_NODE_VERIFICATION_COLLECTION_RUN_EXACTLY_ONCE
```
