## Engineering disposition

**The `BLOCK` is valid. Do not return to the commit gate.**

The audit separates cleanly into three findings:

1. **High — candidate test defect.** The supposedly closed call-surface proof in `tests/test_rw0_b2_capability_boundaries.py` is bypassable. Helper rebinding, decorator/closure replacement, builtin shadowing, and an additional Git-sensitive call through an already allowlisted method all survived. One isolated mutant actually launched a subprocess while both the guard and the protected boundary test passed. 

2. **Medium — evidence circularity.** The module-global mutation replay computed its expected diagnostic by calling the same checker that produced the actual diagnostic. A checker returning the same generic nonempty result for every mutation could therefore keep all nine cases green. 

3. **Low — report overclaim.** G8’s final report claimed authoritative pre/post fingerprints for every action, but the early bootstrap/tooling attempts used lighter or missing fingerprint classes. The later validation remains useful, but the report must state the actual fingerprint class per attempt. 

The underlying Capability implementation, documentation, import direction, privacy posture, and C/D/E/ES authority boundaries remain sound. No production repair or architecture reset is justified. 

## Correct repair strategy

Only this repository file should change:

```text
tests/test_rw0_b2_capability_boundaries.py
```

The current guard should **not** be extended with more forbidden command strings. The repair needs four structural controls:

- A **source-order-aware binding model** that detects later assignments, duplicate definitions, decorators, helper rebinding, builtin shadowing, import replacement, and dynamic binding.
- An **ordered callsite ledger** that records multiplicity and argument/path provenance—not merely a set of allowed method names. This closes the extra-call-to-`.git/index` class.
- A **runtime callable seal** covering actual function identity, code/source digest, defaults, keyword defaults, closures, decorators, and final module bindings.
- **Literal independent expected diagnostics** for module-global mutation cases. Expected results must not be produced by the checker under test.

The four G9 survivors and the executable subprocess mutant must become direct causal regression cases. The repaired guard must reject the executable mutant **before its sentinel can be created**.

G8 and G9 remain immutable historical evidence. The repair should create one fresh evidence root, run targeted and complete validation against the new bytes, report fingerprint coverage accurately, and then go through another fresh independent audit. The independent complete suites were intentionally withheld after the High defect was reproduced, so the current green G8 suites cannot establish acceptance. 

## Implementation handoff

Send this complete prompt to the **existing write-enabled Capability implementation conversation**:

:chatgpt-content-reference{index="1"}

```text
Filename:
Coordinator_RW0_B2_Capability_G9_Findings_Repair_Prompt.txt

Size:
23,133 bytes

SHA-256:
61544c49bfff44f8e65d25ff02032f066c4b2bd2ce87e77cf7480313248fcf96
```

The prompt is bound to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Opening manifest:
d6f86248da0c4843e20b91cb443f960596e483e08a8f2cff716bbcea4fb553d8

Opening node count:
5,072

Opening node-list SHA-256:
f0faec3289ed635a741867bb2a655487f4a4a824dcf4cc0921c334beada1bbd3

Opening candidate tree:
0fcf6680ded68d66f62b75b5dc842d69b343a334

G9 audit root:
/private/tmp/g9.rW9peg

G9 evidence-index SHA-256:
a788c22943c8bcf0601ecf4a944182242843ad1f1849e24996e9c818f12ac244
```

The required implementation result is:

```text
COORDINATOR_RW0_B2_CAPABILITY_G9_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

That result authorizes only a new read-only independent audit—not staging, commit, push, or PR creation.

### Sources

- Codex G9 independent-audit report supplied in the attachment. 

**Confidence:** High that the only repository repair belongs in `tests/test_rw0_b2_capability_boundaries.py`; high that production and governing documents should remain untouched; medium-high that the source-order binding model, ordered call ledger, runtime callable seal, and independent diagnostics will close the next audit.

Some older uploaded project files have expired from the accessible file surface. Re-upload them only when their contents need to be inspected again.
