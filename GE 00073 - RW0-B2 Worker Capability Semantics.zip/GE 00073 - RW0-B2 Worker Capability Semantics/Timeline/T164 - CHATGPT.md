## Stop the repair loop

This should **not** trigger another patch to the 272 KB boundary-test module.

The audit has exposed a design failure in the assurance model: the permanent test is being required to defend itself against arbitrary code that already controls the same Python interpreter—mutating its fixtures, verifier, module globals, expectation carrier, and function `__code__`. Any new in-module “independent root” remains mutable by that same authority. Adding another seal only moves the circular dependency.

That is why each repair produces a stronger verifier followed by another coherent mutation of the verifier itself.

The right next step is an **assurance-model reset**, not a G13 findings-repair implementation.

### Responsibility split to freeze

The permanent repository test should own ordinary, state-independent contract assertions:

- the exact 30-path candidate inventory;
- regular-file types and modes;
- the R01–R30 path facts;
- the P01–P13 protected-content identities;
- package-export and production-importer boundaries;
- dependency, schema, migration, `StateStore`, and `WriterSession` non-widening;
- private, no-I/O, non-authoritative Capability boundaries;
- compatibility with dirty, staged, and clean committed representations.

It should **not** attempt to authenticate its own Python implementation, code objects, fixtures, constants, builtins, or interpreter state.

The fresh independent audit should own external mutation analysis, causal assertion testing, AST review, A/B/C state validation, and clean-commit validation. Git/object/tree provenance should own visibility of coordinated changes to tests and their expectations.

Under that split:

- F-001 through F-006, F-008, and F-009 are primarily symptoms of the rejected self-protecting architecture.
- F-007 is an audit-process contamination issue.
- F-010 is an evidence-chronology issue.
- None justifies changing production code or governing documentation.
- The current meta-verifier machinery should be removed rather than extended.

## Read-only reset handoff

Send this prompt to the **existing Capability implementation conversation**:

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Capability_Commit_Compatibility_Assurance_Reset_Freeze_Prompt.txt

Size:
16,531 bytes

SHA-256:
bbdaee0d62dcd07882429ae46e44a5c1b893db00af0ca3b606e11a1dda8340e6
```

This is deliberately read-only. It instructs Codex to:

1. Confirm the exact current repository and candidate identity.
2. Inspect the full boundary test and owning contracts.
3. Freeze the trust boundary among permanent tests, independent audit, Git provenance, and the commit gate.
4. Classify every G13 finding under that revised boundary.
5. Design the exact smaller replacement for `tests/test_rw0_b2_capability_boundaries.py`.
6. Identify precisely which tests, helpers, literal carriers, binding grammars, callsite ledgers, runtime seals, and self-authentication machinery should be removed.
7. Preserve the real 30-path, P01–P13, public/import/privacy, and authority contracts.
8. Define the node migration, validation sequence, evidence requirements, and fresh-audit acceptance contract.
9. Determine whether the reset can remain a one-file change.
10. Produce a sufficiently exact freeze for a subsequent parent-only implementation prompt.

The required successful result is:

```text
RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_ASSURANCE_RESET_READY
```

Only after that freeze should we issue the implementation prompt. The commit/PR gate remains closed.

This is the point where simplifying the system is the rigorous option. Continuing to make the test module self-defending would harden a temporary assurance artifact into an unbounded architecture.

**Source:** Codex’s G13 independent-audit report supplied inline in this turn.

**Confidence:** High that the remaining loop is caused by an incorrect test trust boundary rather than Capability production semantics; high that a read-only assurance reset is safer and more productive than another in-module verifier patch.
