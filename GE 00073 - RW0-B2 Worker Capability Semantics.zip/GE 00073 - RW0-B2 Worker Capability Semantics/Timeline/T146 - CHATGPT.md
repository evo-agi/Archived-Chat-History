## Decision

**Yes—proceed, but only through a narrowly bounded historical-evidence quarantine.**

G6 is a failed historical replay whose cleanup never ran. The 1,152 symlinks and 12 FIFOs under its pytest basetemps are test transients, not final retained evidence. Requiring the entire failed root to satisfy the safety rules of a completed evidence root is unnecessarily strict.

This does **not** authorize a general exclusion of unsafe entries. The allowed exclusions must be derived mechanically from the exact `--basetemp` paths in retained, launched pytest argv.

The continuation must prove all of the following before creating G7:

- Every excluded root is an exact retained `--basetemp` argument beneath `/private/tmp/g6.4101bd`.
- Every symlink, FIFO, socket, device, or other special entry in G6 is beneath exactly one such root.
- No unsafe entry exists outside those roots.
- No attempt envelope, report, manifest, recipe, fingerprint, JUnit, stdout/stderr, node list, ledger, guard, or other mandatory evidence lies inside an excluded root.
- Symlinks are inventoried with `lstat` and `readlink` only; they are never followed.
- FIFOs and devices are never opened.
- G6 is not cleaned, moved, modified, chmodded, resumed, or retroactively indexed.
- The excluded trees receive a separate quarantine inventory and are compared unchanged at G7 closeout.
- The retained G6 evidence outside those roots is projected with the same content-stable schema at opening and closeout.

If any unsafe entry falls outside the mechanically derived basetemp roots, or mandatory evidence falls inside one, Codex must stop rather than widen the exclusion.

## Continuation prompt

Send this amendment to the **same implementation conversation**. It resumes the previously issued G7 stable replay; it is not a new implementation pass.

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Capability_G7_G6_Transient_Basetemp_Quarantine_Amendment_Prompt.txt

Size:
9,873 bytes

SHA-256:
5dc106f53e0d7df97c0f0081bacb58894edc7af4aad804a7adb76142bd941daf
```

The prompt requires two separate G6 records:

```text
g6_quarantine_inventory.jsonl
```

for the documented pytest transient subtrees, and a canonical retained-evidence projection covering everything outside them.

The final report must state explicitly:

```text
G6 cleanup never ran because the replay stopped before cleanup.
G6’s exact pytest basetemp roots were derived from retained launched argv.
Unsafe entries were confined to those roots.
No mandatory retained G6 evidence was inside the quarantined roots.
The roots were excluded only from the historical retained-evidence projection.
G6 was not modified, cleaned, repaired, resumed, or granted validation credit.
G7 is the authoritative complete validation and closeout envelope.
```

The required success token remains:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

**Source:** Codex’s `STABLE_REPLAY_INPUT_INCOMPLETE` report supplied in this turn.

**Confidence:** High. The exclusion is justified for exact, documented pytest basetemp trees in a failed historical replay; confidence depends on the boundary proof finding no unsafe entries elsewhere and no mandatory evidence inside the quarantined subtrees.
