PROMPT_ID

RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_RECONNAISSANCE_V1

TITLE

Coordinator RW0-B2-Capability — read-only reset of the B1 and RW0 owner-oracle
design after complete-file natural-language classifiers failed independent audit

ENGAGEMENT TYPE

Read-only architecture and contract-test reconnaissance.

No repository mutation is authorized. Do not edit, format, stage, commit, push,
create a PR, merge, tag, release, deploy, install dependencies, contact a
remote/service/provider/host, invoke a product worker/model, mutate a database,
or inspect a supporting repository.

Use exactly four bounded, non-nesting read-only explorers when available. The
parent reconciles their evidence and makes the engineering decision.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

LIVE BASELINE TO VERIFY

Require at opening and closeout:

- branch:
  codex/rw0-b2-capability-semantics-v1
- HEAD:
  deec37bf08fb903d8846aa2c3232aec52fa9866e
- tree:
  ef48f5bd11244c6f703c97abb5489d19956f7a77
- sole parent:
  02450d3c99faf0fe7b299b914afaed312421bc8b
- subject:
  feat: implement RW0-B2 Wire protocol (#4)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- topology:
  30 dirty paths
  24 tracked modifications
  6 untracked additions
  0 staged
  0 unmerged
- all candidate paths:
  regular mode 0644
- no Git operation, lock, repository cache, bytecode, database, journal,
  archive, build output, or generated repository manifest residue
- git diff --check:
  clean

Do not fetch, switch, reset, clean, stash, rebase, or merge.

CURRENT EXACT CANDIDATE AND AUDIT EVIDENCE

Final candidate evidence root:

/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-repair.UiqBSB

Required candidate manifest:

- size:
  6,430 bytes
- SHA-256:
  8d5ed37273a3583104b2fb4f5acee045d7cc18799fdda368d2628e75d8807841

Required complete recipe output:

- size:
  6,663 bytes
- SHA-256:
  e813ead384d3c88eb897d996c32b93245841279e31c002558c12dc36e9611d0c

Required topology:
30 / 24 / 6 / 0 / 0

Required final collection:
5,114 unique nodes

Latest independent audit root:

/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-continuation-audit.HLejOJ

Required report:

/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-continuation-audit.HLejOJ/audit_report.md

Required self-excluding index:

/private/tmp/ge-coordinator-rw0-b2-markdown-oracle-continuation-audit.HLejOJ/evidence_index.jsonl

Index:
48 rows excluding itself
SHA-256:
4ef63b4f51edb0bb60e404ed6094b3d4b0b6f7f94854d7716ac8b290447a2ac2

Verify retained evidence safely before architecture judgment. This engagement
does not rerun the audit.

AUDIT RESULT TO RECONCILE

The latest independent audit returned BLOCK while accepting production,
governing-document, privacy, import, public, and authority boundaries.

Material results:

1. RW0 semantic false negatives:
   - 81 of 90 independently placed contradictions survived.
   - Surviving classes included current B components marked deferred/future,
     B-owned supervision, B-owned runtime lifecycle, ES relinquishment, and
     RW0-C described as already implemented.

2. B1 semantic false negatives:
   - 60 of 60 independently generated stale retrieval-limit or consumer
     contradictions survived.
   - Two of three additional markup variants survived.

3. False positives:
   - all six truthful RW0 negated/scoped controls were rejected;
   - all six truthful B1 historical, negated, qualified, or unrelated controls
     were rejected.

4. Markdown grammar defects:
   - invalid backtick-bearing info strings incorrectly opened fences and hid
     visible contradictory prose;
   - four-space Setext titles, Unicode line separators, and comment-spliced
     missing ATX delimiters were misclassified;
   - unclosed-fence policy was inconsistent.

5. Non-weakening failure:
   - 22 generated test nodes were byte-identical aliases despite distinct node
     names.

6. The exact preceding survivor corpus was closed:
   - B1 20/20 semantic and 3/3 hidden-heading survivors reject;
   - RW0 16/16 semantic and 3/3 hidden-heading survivors reject.
   This proves corpus memorization, not semantic completeness.

7. Production and current documents remain correct and unchanged.

ENGINEERING PROBLEM

Decide whether the current strategy—parsing arbitrary natural-language prose
across complete Markdown documents and attempting polarity-aware semantic
classification—should be abandoned.

The default engineering hypothesis is:

- do not continue building a bespoke natural-language inference engine inside
  contract tests;
- do not add another round of keyword, paraphrase, negation, and placement
  matrices;
- give each owning document one visible, bounded, machine-enforced current-
  contract registry;
- keep that registry inside the owning document so there is one authoritative
  writer per fact;
- make prose explanatory and non-authoritative for machine status;
- test exact registry structure, uniqueness, values, owner boundaries, and
  nonauthority;
- retain only a small bounded linter for explicitly reserved status assertions,
  rather than claiming complete semantic understanding of arbitrary prose.

Challenge this hypothesis against live repository contracts. Recommend a
different design only when source-grounded evidence makes it smaller, safer,
and non-disposable.

CURRENT FACTS THAT MUST REMAIN TRUE

B1 current facts:

- B1 private pure semantics are implemented.
- `validate_retrieval_event_sequence` current work maximum is 1285.
- RW0-B2-Capability is the sole current cross-module production consumer of
  the B1 host snapshot seam.
- B1 authenticates no source, grants no permission, creates no persistence,
  and owns no acceptance latch or ES runtime fact.
- RW0-C owns future durable ingest/completeness/recovery/terminal/latch work.
- RW0-D owns future physical custody/transport/process/cancellation mechanics.
- RW0-E owns separately authorized live proof.
- Execution Substrate retains route admission and runtime authority.

RW0 current facts:

- RW0-B1 is current private pure semantics.
- RW0-B2-Wire is current private pure semantics.
- RW0-B2-Capability is current private pure semantics.
- RW0-C remains future durable semantics and recovery.
- RW0-D remains future physical/process/provider mechanics.
- RW0-E remains future separately authorized live proof.
- Execution Substrate retains admission, reliable-submit, runtime identity,
  lifecycle, cancellation correlation, and retained-result authority.
- No current B value, digest, frame, declaration, observation, qualification,
  or test grants executable authority or semantic acceptance.

Do not change those facts during reconnaissance.

FOUR EXPLORER ASSIGNMENTS

1. OWNER-DOCUMENT AND AUTHORITY EXPLORER

Inspect completely:

- .docs/rw0-b1-pure-phase-values.md
- .docs/rw0-remote-worker-contact-phase-entry.md
- .docs/rw0-b2-capability.md
- .docs/rw0-b2-wire-protocol.md
- .docs/authority-boundaries.md
- .docs/autonomous-software-development-operating-model.md
- .docs/durable-state-model.md
- .docs/worker-execution-boundary.md
- .docs/software-development-progression-boundary.md
- AGENTS.md

Return:

- exact current authoritative facts;
- current owner/marker/status regions;
- every place that already projects these facts;
- whether adding one structured registry per owner would preserve one
  authoritative writer;
- whether any current prose must be reclassified as historical, explanatory,
  or machine-nonauthoritative;
- exact authority/nonclaim fields the registry must expose;
- contradictions with repository guidance.

2. TEST-ARCHITECTURE AND MUTATION EXPLORER

Inspect completely:

- tests/test_rw0_b1_boundaries.py
- tests/test_rw0_remote_contact_phase_entry_contract.py
- tests/test_rw0_b2_capability_values.py
- tests/test_rw0_b1_relations.py
- tests/test_rw0_b2_capability_boundaries.py
- tests/test_rw0_b2_wire_boundaries.py
- tests/test_architecture_contracts.py
- tests/test_software_development_progression_boundary.py
- tests/test_runtime_non_authority.py
- tests/test_c2a_nonimplementation.py

Also inspect the latest audit report and mutant records.

Return:

- exact helpers and nodes that implement the failed natural-language strategy;
- which of the 209 latest additions are corpus-specific, generated,
  duplicated, or reusable;
- which pre-existing nodes must remain;
- whether the flawed 209 nodes should be removed, renamed, or replaced rather
  than preserved by inertia;
- exact replacement node inventory by purpose, not guessed count;
- causal mutant strategy for a structured registry;
- false-positive controls;
- exact touched tests likely required.

3. MARKDOWN/STRUCTURED-CONTRACT EXPLORER

Inspect repository conventions for:

- visible owner headings;
- BEGIN/END markers;
- Markdown tables used as exact contracts;
- machine-readable literals embedded in owner documents;
- fence-aware owner parsers;
- current-status or source-of-truth registries.

Do not infer from unrelated historical snapshots without labeling them.

Compare at least these candidate representations:

A. Visible Markdown table bounded by unique markers.
B. Visible line-oriented key/value registry bounded by unique markers.
C. Fenced JSON/YAML/TOML inside the owner document.
D. Separate machine-readable file referenced by the owner.

Evaluate:

- single-authority-writer integrity;
- human readability;
- parser complexity;
- hidden/fenced duplicate risk;
- canonicalization and ordering;
- reviewability;
- test causality;
- migration/versioning;
- risk of generated artifacts becoming authority.

Default preference is A or B. A separate file is disfavored because it creates
a second mutable authority unless owning-contract evidence proves otherwise.

Return one recommended exact representation and finite parser contract.

4. INTEGRATION, SCOPE, VALIDATION, AND MIGRATION EXPLORER

Inspect:

- changed-path inventories;
- direct import/public/status tests;
- node-identity history from 4,905 to 5,114;
- retained implementation and audit evidence;
- provenance recipe/guidance;
- likely status cross-references.

Return:

- exact maximum implementation touched-file allowlist;
- paths that remain protected;
- whether only four paths are sufficient:
  .docs/rw0-b1-pure-phase-values.md
  .docs/rw0-remote-worker-contact-phase-entry.md
  tests/test_rw0_b1_boundaries.py
  tests/test_rw0_remote_contact_phase_entry_contract.py
- any additional path required by a concrete existing assertion;
- migration treatment for the 209 flawed nodes;
- focused and complete validation order;
- exact provenance requirements;
- stop conditions;
- likely independent-audit perspectives.

REQUIRED DESIGN DECISIONS

The parent must make and defend all of the following.

1. ORACLE AUTHORITY MODEL

Decide:

- what exact document region is machine-authoritative;
- what prose outside it means;
- whether other prose may make current-status claims;
- how contradictions are prevented without pretending to solve natural-
  language understanding;
- how historical prose is scoped;
- how cross-references consume the owner facts.

Prefer one authoritative writer per mutable fact.

2. EXACT B1 REGISTRY

Freeze an exact candidate inventory in substance. At minimum decide whether it
contains:

- registry schema/version;
- status of B1;
- retrieval-event-sequence work maximum;
- sole current cross-module consumer;
- source-authentication nonclaim;
- permission nonclaim;
- persistence nonclaim;
- acceptance-latch owner;
- future C/D/E owners;
- ES runtime owner.

Use finite exact strings and integers. Do not add identities or digests unless
there is a concrete owner need.

3. EXACT RW0 REGISTRY

Freeze an exact candidate inventory in substance. At minimum decide whether it
contains one row per:

- RW0-B1
- RW0-B2-Wire
- RW0-B2-Capability
- RW0-C
- RW0-D
- RW0-E
- Execution Substrate

For each row decide exact fields such as:

- component;
- lifecycle status;
- contract class;
- authority owner;
- implementation posture;
- explicit nonclaims.

Do not select provider, CLI/App Server, credential, transport, or runtime
mechanics.

4. REPRESENTATION AND PARSER

Freeze:

- visible heading;
- unique BEGIN/END markers;
- table or line grammar;
- ASCII and Unicode handling;
- whitespace rules;
- duplicate/relocation behavior;
- exact row/field order;
- whether Markdown inline rendering matters;
- fence handling;
- comment handling;
- canonical projection used by tests;
- content-free diagnostics.

The parser should recognize a small exact grammar, not arbitrary prose.

5. PROSE POLICY

Choose one:

A. Only the registry is machine-authoritative; prose is explanatory and tests
   do not claim complete semantic interpretation.

B. Prose remains machine-authoritative under a finite explicitly enumerated
   grammar.

Do not choose B unless the exact finite grammar can cover the current owner
without the false-negative/false-positive failure mode demonstrated by audit.

State explicitly that arbitrary semantic equivalence is not mechanically
decidable by these tests.

6. TEST MIGRATION

Do not preserve broken tests by inertia.

Freeze:

- which current nodes are retained;
- which of the 209 latest additions are deleted or replaced;
- whether node removal/renaming is authorized as an architecture-test reset;
- one-to-one replacement records where useful;
- exact independent structural mutants;
- exact wrong-value and duplicate-row mutants;
- exact false-positive controls;
- no volume-only parameter aliases.

7. TOUCHED-FILE CEILING

Return an exact maximum allowlist. A four-path result is preferred but not
assumed.

Do not include production source, package root, dependencies, schemas,
migrations, StateStore, WriterSession, C2A, B1 implementation, Wire
implementation, or Capability implementation.

8. VALIDATION AND AUDIT

Freeze:

- test-first red evidence;
- focused groups;
- node collection comparison;
- treatment of intentionally replaced nodes;
- complete suite policy;
- exact provenance;
- fresh independent audit;
- audit mutants proving the registry parser, not arbitrary prose semantics.

9. FORECASTS

Record falsifiable forecasts:

- most likely implementation blocker;
- whether the touched-file ceiling is sufficient;
- likely independent-audit findings;
- evidence that would force redesign rather than ordinary repair.

10. DISPOSITION

Return exactly one:

RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_READY
RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_PARTIAL
RW0_B2_CAPABILITY_OWNER_ORACLE_RESET_BLOCKED

READY requires:

- exact owner-authority model;
- exact B1 and RW0 registry contents in substance;
- exact representation/parser contract;
- exact prose policy;
- exact test-node migration treatment;
- exact touched-file ceiling;
- validation, provenance, audit, and stop conditions;
- no unresolved contradiction with current repo authority.

PROGRESSION RULE

If READY, the next permitted step is one bounded parent-only implementation
prompt for the owner-oracle reset.

Do not issue an implementation prompt in this engagement.

No staging, commit, push, PR, merge, or publication is permitted.

FINAL REPORT

Include:

1. opening/closing repository identity;
2. retained evidence verification;
3. four explorer reports and disagreements;
4. current contract versus failed test architecture;
5. engineering decision on abandoning or retaining natural-language
   classification;
6. exact B1 registry;
7. exact RW0 registry;
8. representation and parser;
9. prose authority policy;
10. test-node migration;
11. exact touched-file ceiling and protected paths;
12. validation/provenance/audit plan;
13. forecasts;
14. final disposition;
15. inspection boundary and unvalidated surfaces.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
