PROMPT_ID

RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_REPAIR_COMPLETE_VALIDATION_REPLAY_V1

TITLE

Coordinator RW0-B2-Capability — complete no-mutation validation replay with an
unconditional all-attempt ledger for the final commit-compatibility repair

ENGAGEMENT TYPE

Parent-only validation-evidence replay in the same write-enabled Capability
implementation conversation.

Repository mutation is not authorized.

Do not edit, format, generate, delete, rename, chmod, stage, commit, push, open
a PR, merge, tag, release, deploy, contact a remote/service/provider/host,
invoke a product worker/model, mutate a database, install dependencies, or
inspect a supporting repository inside the source repository or any
pre-existing evidence root.

Inside the one new external evidence root created by this engagement, creating
files, atomic renames, and setting retained files to mode `0400` and
directories to mode `0700` are authorized and required.

Do not rerun implementation or change repository bytes.

This engagement creates a complete replacement validation basis for the exact
current candidate. It reruns:

- final selected causal controls and every individual mutant;
- final focused groups;
- A/B/C state compatibility;
- live and clean node collection;
- live and clean complete suites;
- final guards and cleanup;
- two final provenance runs.

Every command, setup step, expected mutant failure, tooling action, guard,
cleanup action, and provenance action from bootstrap onward must have an
unconditional immutable attempt envelope.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Close the exact evidence gap diagnosed after the success token:

```text
VALIDATION_EVIDENCE_RERUN_REQUIRED
```

The repository repair is complete and current bytes are stable. The deficient
historical root is:

```text
/private/tmp/g5.hiLE2y
```

Its evidence is sufficient for the credited final behavior but incomplete for a
strict engagement-wide all-attempt chronology. In particular, early opening,
red, development, and tooling actions lack complete attempt envelopes.

Do not reconstruct their missing process-local metadata.

Instead:

1. preserve `/private/tmp/g5.hiLE2y` unchanged as historical partial evidence;

2. recover the exact final target, selected-case inventory, mutation
   generators, projections, and expected results from its indexed immutable
   records;

3. replay the complete final validation sequence from scratch under one new
   neutral evidence root;

4. record every action unconditionally;

5. make the new root the authoritative validation and closeout envelope for the
   unchanged final candidate.

OPENING REPOSITORY IDENTITY

Before bootstrap validation require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

subject:
feat: implement RW0-B2 Wire protocol (#4)

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

dirty topology:
30 paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644
```

Require:

- `git diff --check` clean;
- cached diff empty;
- no Git operation or lock;
- real source index unstaged;
- no candidate symlink or special file;
- no repository cache, bytecode, database, journal, archive, build output,
  generated repository manifest, recorder residue, or thirty-first changed
  path.

Do not fetch, switch, reset, clean, stash, rebase, merge, or alter Git refs.

AUTHORITATIVE CURRENT TARGET

Historical final-repair evidence root:

```text
/private/tmp/g5.hiLE2y
```

Required self-excluding index:

```text
/private/tmp/g5.hiLE2y/evidence_index.jsonl

rows excluding itself:
7234

size:
1583837 bytes

SHA-256:
199af9ac4299cc41a4434d44f1b1f7bcaf3265490b7417e174ad5d48723f8fcc
```

Required current facts recovered from indexed records:

```text
candidate path count:
30

tracked modifications:
24

untracked additions:
6

staged/unmerged:
0/0

opening node count before the final repair:
5057

final node count:
5072

final B/C clean candidate tree:
0fcf6680ded68d66f62b75b5dc842d69b343a334

final live suite:
5072 collected
5072 passed

final clean suite:
5072 collected
5072 passed
```

Recover and verify the complete exact values from indexed records:

```text
final canonical-manifest path
final canonical-manifest byte size
final canonical-manifest full SHA-256
final tracked textual-diff full SHA-256
final complete recipe-output path/size/full SHA-256
exact final canonical manifest JSON
sole changed-path opening and final size/SHA-256
final ordered-node-list path/full SHA-256
opening ordered-node-list path/full SHA-256
selected final causal node IDs
closed reachable-call inventory
module-global identity/type inventory
all no-status mutant definitions and expected results
literal ordered 43-row projection
protected-content causal ledger
exact prior-audit survivor kill record
stable-contract mutation matrix
A/B/C target and projection records
```

Do not accept truncated hashes from prose when exact indexed values exist.

PRE-EXISTING EVIDENCE ROOTS — READ ONLY

Safely verify and preserve at least:

```text
/private/tmp/g5.hiLE2y
  index:
  199af9ac4299cc41a4434d44f1b1f7bcaf3265490b7417e174ad5d48723f8fcc

/private/tmp/g4.S4uFyK
  index:
  f4836712bfc0e55dda2bb489401dabc55958016fc3c1778f8ad40a33bc5cb5b9

/private/tmp/ge-coordinator-rw0-b2-capability-commit-compat-repair.dxtuOe
  index:
  bdffdfd9757302a7940b803f0d5138fdf9f9b41e53d95fcae3209b0e35dae71d

/private/tmp/ge-coordinator-rw0-b2-commit-compat-validation-binding-reset2.Udjr4a
  index:
  a3abd5e9252da88623ab3285a6f560b7b71f151f672d25f6236c3779f806abe9

/private/tmp/gv3.efmQ8X
  index:
  cec6aba32a0243bf2b0b48d147df96ccb2b50ec5b9ec161dc1cc1c0d4f30eee1
```

Also preserve every evidence root referenced by the indexed g5 final report.
Safely `lstat` path components. Record opening tree fingerprints and require
exact equality at closeout.

EXACT RECIPE SOURCE

Locate the exact retained recipe source through the g5 index.

Require:

```text
type:
regular file

mode:
0400

size:
3945 bytes

SHA-256:
db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc
```

The retained source and all pre-existing roots remain read-only.

Create a root-local execution copy under the new root:

1. copy exact bytes under `umask 077`;
2. fsync and close;
3. atomically rename to `exact_recipe_source.py`;
4. set exact mode `0400`;
5. `lstat` and verify regular/non-symlink/operator-owned/mode/size/SHA-256;
6. seal a complete attempt envelope and `recipe_copy_preflight.json`;
7. invoke only after preflight passes.

NEW NEUTRAL EVIDENCE ROOT AND BOOTSTRAP

Create exactly one new top-level root:

```text
/private/tmp/g6.XXXXXX
```

The root name and every child path visible to pytest must pass the exact
path-safety grammar recovered from the repository tests.

Use short neutral child names.

The bootstrap is one self-recording Python process that must:

1. create the root with mode `0700`;

2. retain its exact source as `bootstrap.py`;

3. record its own:
   - argv;
   - environment;
   - Python identity;
   - PID;
   - caller umask;
   - wall and monotonic timing;
   - return code;
   - stdout/stderr identities;
   - created-root path/type/owner/mode;
   - source repository opening lightweight identity;

4. atomically write `bootstrap_envelope.json`;

5. install the unconditional recorder source;

6. add no unrecorded action after root creation.

The bootstrap envelope is the first record in the all-attempt ledger.

ROOT REQUIREMENTS

- operator-owned;
- non-symlink;
- mode `0700`;
- all temporary paths below this root;
- no repository-local evidence/temp path;
- retained files mode `0400`;
- retained directories mode `0700`;
- no symlink, FIFO, socket, device, or special entry;
- self-excluding canonical JSONL index created last.

UNCONDITIONAL RECORDER

After bootstrap, every command or procedural action must execute through the
recorder.

This includes:

```text
recorder self-test
path-safety preflight
evidence-index verification
opening repository gate
recipe-copy preflight
opening recipe run 1
opening recipe run 2
target extraction
mutation-source extraction
each individual mutation/control execution
each pytest run
A setup
A target run
B external repository setup
B target run
C diagnostic commit
C target run
live collection
clean collection
migration/node reconciliation
live full suite
clean full suite
every guard
every cleanup action
final recipe run 1
final recipe run 2
final report generation
attempt-manifest generation
pre-index inventory
index creation
external index verification
```

Each attempt receives one unique immutable label.

The recorder must atomically seal an envelope even on:

```text
success
expected nonzero mutant result
unexpected nonzero result
signal
preflight refusal
missing target
command not launched
JUnit absent/not applicable
wrapper/tooling failure
cleanup failure
index failure
```

ATTEMPT ENVELOPE SCHEMA

Every envelope must include:

```text
schema_id
sequence_number
label
purpose
attempt_class
credit_classification
expected_outcome
actual_outcome
exact argv as JSON array
working directory
exact environment allowlist
unset variables
Python executable path/realpath/version/implementation/platform
caller umask
child umask or explicit not-launched
wall start/end UTC
monotonic start/end ns
duration ns
child PID or not-launched
return code
terminating signal
stdout path/size/SHA-256
stderr path/size/SHA-256
JUnit applicability
JUnit path/size/SHA-256
JUnit parse status
collected/passed/failed/error/skipped/xfail/xpass/warning counts
duplicate JUnit identities
unmapped JUnit cases
ordered node-list path/count/SHA-256 when applicable
source repository pre fingerprint path/SHA-256
source repository post fingerprint path/SHA-256
external repository pre/post fingerprint paths/SHA-256 when applicable
real-index pre/post identities
source-object-inventory pre/post identities when applicable
candidate-mutated boolean
notes
```

Attempt envelopes must be append-only and immutable.

ALL-ATTEMPT MANIFEST

Maintain an append-only `attempt_manifest.jsonl`.

Each row contains:

```text
sequence_number
label
attempt_class
credit_classification
envelope_path
envelope_SHA-256
expected_outcome
actual_outcome
```

Requirements:

- bootstrap row first;
- one row per command/procedural action;
- no missing sequence;
- no duplicate label;
- no command found in retained command logs without a corresponding row;
- no envelope without a manifest row;
- finalized before the final report;
- final report includes the complete chronology.

RECORDER SELF-TEST

Before any candidate validation, run a tooling self-test covering:

```text
successful external command
expected nonzero command
preflight refusal/not launched
zero-byte stdout
zero-byte stderr
JUnit not applicable
```

Every self-test attempt must have a complete envelope.

Stop if the recorder or all-attempt manifest is incomplete.

OPENING GATE

Run a fully recorded opening gate that verifies:

1. exact live repository identity and topology;

2. no staged/unmerged path or residue;

3. g5 and every referenced evidence index;

4. live candidate against g5 final manifest;

5. sole final changed path and other twenty-nine equality;

6. every path outside the candidate equals HEAD;

7. exact recipe source;

8. two opening recipe executions;

9. both opening manifests equal the g5 final manifest;

10. both complete outputs equal the g5 final complete output;

11. opening and final retained node lists and full hashes;

12. exact mutation/projection ledgers;

13. exact path-safety grammar.

Seal every sub-action as a separate attempt envelope, not one opaque shell
script.

PATH SAFETY

Before any pytest or external repository path is created:

1. recover the exact owning path-safety checker;

2. enumerate every child-visible path:

   ```text
   cwd
   external repository root
   TMPDIR
   PYTHONPYCACHEPREFIX
   basetemp
   JUnit
   HOME
   PWD
   Git directory/object paths
   evidence paths included by test fixtures
   ```

3. pass every path through the exact checker;

4. retain a complete per-path result ledger;

5. stop before launch if any path fails.

Do not weaken or monkeypatch privacy checks.

VALIDATION ENVIRONMENT

For every pytest child:

```text
umask 022
child numerical umask 0022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct neutral external PYTHONPYCACHEPREFIX
distinct neutral external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
GIT_OPTIONAL_LOCKS=0
python3 -B -m pytest -p no:cacheprovider -W error
distinct neutral external --basetemp
distinct neutral external --junitxml
serial execution
```

COMPLETE FINGERPRINT SCHEMA

Use one deterministic fingerprint implementation for every run.

Source fingerprint includes:

```text
physical root
branch
HEAD/tree/parents/subject
upstream/divergence
worktrees
porcelain v2 exact bytes/SHA-256
tracked binary diff exact bytes/SHA-256
cached binary diff exact bytes/SHA-256
real .git/index path/type/mode/size/SHA-256/inode/device/mtime/ctime
canonical candidate manifest and SHA-256
per-candidate path identities
outside-candidate equality to HEAD
relevant refs
source object-database inventory/aggregate
operation/lock inventory
residue inventory
```

External repository fingerprint includes the applicable fields plus:

```text
external root
diagnostic commit
commit tree
clean/staged status
object-database root
absence of alternates
object inventory
no shared object inode with source
```

Create pre fingerprint immediately before a child and post fingerprint
immediately after it exits, before cleanup or any other Git command.

A candidate-validation run is creditable only when required pre/post
fingerprints are byte-identical.

FINAL CAUSAL REPLAY

Recover exact current final mutation/control specifications from indexed g5
records.

Do not approximate or regenerate from prose when exact sealed sources exist.

Replay:

1. every selected canonical control;

2. every closed reachable-call mutant individually;

3. every module-global identity/type mutant;

4. every 43-row projection inventory/uniqueness control;

5. every protected-content row mutant individually;

6. the exact prior-audit survivor and its kill control;

7. every stable-contract mutant individually.

For each mutant retain:

```text
case ID
source/generator path
source bytes
source SHA-256
purpose
expected outcome/diagnostic
actual outcome/diagnostic
before/after candidate fingerprint
attempt envelope
```

Expected mutant rejection is a credited expected nonzero/control result, not a
tooling failure.

Require unique source bytes and unique purpose unless a literal duplicate is
explicitly justified.

FINAL FOCUSED GROUPS

Recover exact final argv from indexed g5 records and rerun:

```text
selected causal:
expected 16 passed

Capability boundaries:
expected 32 passed

Capability complete:
expected 69 passed

B1/Wire compatibility:
expected 461 passed

architecture/status/static:
expected 907 passed
```

If indexed exact argv differs from these counts, stop and report input
inconsistency. Do not substitute a guessed target list.

A/B/C STATE REPLAY

## State A

Run the target and projection in the live accepted unstaged source repository.

## State B

Use a fully external independent Git repository, not the source repository
with `GIT_INDEX_FILE`.

Procedure:

- initialize external repository/object database;
- populate accepted base without alternates or hardlinks;
- overlay exact final 30-file candidate;
- stage exactly the candidate;
- do not commit yet;
- run target and projection in staged state.

## State C

In the same external repository:

- create one diagnostic local commit;
- require commit tree equal the retained g5 final B/C tree:
  `0fcf6680ded68d66f62b75b5dc842d69b343a334`;
- require clean status;
- run target and projection.

Requirements:

```text
target passes A/B/C
projection A == B == C
B staged tree == C committed tree
source real index unchanged
source object database unchanged
external objects fully isolated
```

Every setup and run gets its own envelope.

NODE COLLECTION

Run:

```text
live final collection
clean external final collection
```

Require both:

```text
5072 unique nodes
exact full ordered SHA-256 recovered from g5 indexed final list
byte-identical node lists
```

Also compare:

```text
opening 5057 list
final 5072 list
15 additions
0 removals
0 renames
all additions in the authorized test file
all outside-file nodes retain relative order
```

Retain complete reconciliation evidence.

LIVE FULL SUITE

Run exactly once after focused validation is green.

Require:

```text
5072 collected
5072 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

Require complete pre/post source fingerprints, exact JUnit/node mapping, and
candidate-mutated false.

CLEAN FULL SUITE

Run exactly once in the fully external clean committed State-C repository.

Require:

```text
5072 collected
5072 passed
0 failures
0 errors
0 skipped
0 xfailed
0 warnings
empty stderr
```

Require complete source and external pre/post fingerprints, exact JUnit/node
mapping, candidate-mutated false, clean tree unchanged, and external object
isolation.

No suite retry is authorized.

If either suite fails, seal the complete envelope and stop without repository
mutation.

FINAL GUARDS

After suites:

1. verify source identity/topology/index/status/manifest;

2. verify source object inventory equals opening;

3. verify all pre-existing evidence roots equal opening fingerprints;

4. verify final node identities;

5. verify all mutation ledgers and attempt-manifest arithmetic;

6. verify no hidden command lacks an envelope;

7. verify no operation/lock/residue.

Every guard action gets its own envelope.

CLEANUP

Remove only new replay-created transient:

```text
basetemps
pytest caches
pycache roots
temporary TMPDIR contents
external repository
temporary object copies
```

Before removal retain:

```text
complete external repository manifest
Git metadata
object inventory
commit/tree identities
A/B/C records
clean collection
clean suite outputs/JUnit
pre/post fingerprints
setup command ledger
```

Record every removal action in its own envelope or one explicit cleanup action
with a complete enumerated path/type ledger.

Run a post-cleanup guard through the recorder.

FINAL PROVENANCE

After cleanup:

1. verify root-local recipe copy remains exact mode 0400;

2. run final recipe 1 through the recorder;

3. run final recipe 2 through the recorder;

4. require manifests byte-identical and equal the g5 final manifest;

5. require complete outputs byte-identical and equal the g5 final output;

6. require empty stderr and unchanged source fingerprints.

FINAL REPORT

Generate a complete report before index creation.

Include:

1. opening identity;
2. g5 historical-evidence classification;
3. all pre-existing evidence indexes;
4. bootstrap and recorder self-test;
5. complete all-attempt chronology;
6. opening gate;
7. causal mutation replay;
8. every focused group;
9. A/B/C replay;
10. live/clean collection;
11. node reconciliation;
12. live suite;
13. clean suite;
14. run-local pre/post fingerprints;
15. final guards;
16. cleanup;
17. final provenance;
18. exact final manifest JSON;
19. protected/public/authority non-widening;
20. remaining C/D/E/ES seams;
21. separate provenance, validation-binding, and implementation confidence.

Explicitly state:

```text
historical g5 partial attempt metadata was not reconstructed
g5 remains evidence of the implementation turn
g6 is the authoritative complete final validation and closeout envelope
```

INDEX CREATION AND EXTERNAL VERIFICATION

1. finalize and seal `attempt_manifest.jsonl`;

2. verify sequence continuity and one-to-one envelope mapping;

3. generate pre-index inventory through the recorder;

4. generate the final report through the recorder;

5. create the self-excluding canonical JSONL evidence index as the last root
   mutation;

6. do not add, remove, modify, rename, or chmod any root entry afterward;

7. run one external verifier outside the indexed root;

8. the external verifier self-records to a sibling file outside the root and
   confirms:
   - index excludes itself;
   - every row matches path/type/owner/group/mode/size/hash;
   - no unindexed root entry;
   - no symlink/special entry;
   - attempt manifest and envelopes reconcile;
   - final report and mandatory records exist.

SUCCESS TOKEN

Return exactly:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_FINAL_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

only when:

- current candidate bytes remain unchanged;
- every final causal and focused group passes;
- A/B/C passes;
- live and clean collections are exact;
- live and clean suites pass 5,072/5,072;
- every action from bootstrap onward has an envelope;
- final provenance is stable;
- final report and self-excluding index are complete.

FAILURE TOKENS

Use one precise primary token:

```text
COMPLETE_REPLAY_PROVENANCE_MISMATCH
COMPLETE_REPLAY_INPUT_INCOMPLETE
COMPLETE_REPLAY_RECORDER_FAILED
COMPLETE_REPLAY_CAUSAL_FAILED
COMPLETE_REPLAY_FOCUSED_FAILED
COMPLETE_REPLAY_STATE_MATRIX_FAILED
COMPLETE_REPLAY_NODE_COLLECTION_FAILED
COMPLETE_REPLAY_LIVE_SUITE_FAILED
COMPLETE_REPLAY_CLEAN_SUITE_FAILED
COMPLETE_REPLAY_SOURCE_MUTATION_DETECTED
COMPLETE_REPLAY_PROVENANCE_FAILED
COMPLETE_REPLAY_EVIDENCE_SEAL_FAILED
```

Do not modify repository bytes in any failure case.

FINAL REQUIRED STATEMENTS

```text
REPOSITORY_MUTATION_NOT_PERFORMED
IMPLEMENTATION_NOT_RERUN
HISTORICAL_METADATA_NOT_RECONSTRUCTED
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRODUCTION_SOURCE_NOT_MODIFIED
GOVERNING_DOCUMENTATION_NOT_MODIFIED
WIRE_IMPLEMENTATION_NOT_MODIFIED
B1_IMPLEMENTATION_NOT_MODIFIED
LINEAGE_IMPLEMENTATION_NOT_MODIFIED
C2A_IMPLEMENTATION_NOT_MODIFIED
```
