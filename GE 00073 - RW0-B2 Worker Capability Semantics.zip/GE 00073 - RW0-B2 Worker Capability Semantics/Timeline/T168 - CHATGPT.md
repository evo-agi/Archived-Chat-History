## Disposition

**Proceed to a new, read-only independent audit. Do not stage or reopen the implementation conversation unless that audit finds a concrete defect.**

The reset report satisfies the agreed handoff boundary:

- Exactly one repository path changed:
  ```text
  tests/test_rw0_b2_capability_boundaries.py
  ```
- The file was reduced from 4,612 lines and 272,157 bytes to **765 lines and 36,340 bytes**, below both frozen ceilings.
- The recursive self-source, self-AST, code-object, binding-ledger, callsite-ledger, runtime-seal, dual-gate, encoded-carrier, and same-process tamper-resistance architecture was removed.
- The final permanent contract is ordinary and finite:
  - 16 retained product-contract nodes;
  - three new literal-contract nodes;
  - R01–R30 candidate rows;
  - P01–P13 protected-content rows.
- Node migration reconciles exactly:
  ```text
  5,150 - 94 + 3 = 5,059
  ```
- A/B/C passed with identical projections and tree:
  ```text
  727fb0ecf94680b64fed5e1bb2bccecccde38e4d
  ```
- Live and external clean-commit suites each passed **5,059/5,059**, exactly once.
- The other 29 candidate entries and all 176 paths outside the candidate reportedly remained unchanged.
- No production source, governing documentation, API, dependency, schema, migration, or authority boundary changed.

This is the correct point for a fresh audit. The audit should not resurrect the rejected requirement that a pytest module defend itself from arbitrary equal-authority mutation inside its interpreter.

## Fresh independent-audit handoff

Start a **new Codex conversation** and send this prompt:

:chatgpt-content-reference{index="0"}

```text
Filename:
Coordinator_RW0_B2_Capability_Assurance_Reset_Fresh_Independent_Audit_Prompt.txt

Size:
25,534 bytes

SHA-256:
05b6e1a5557884c313f54e65ccfac07f558d4d04b763fc0524796c75c2cd88d1
```

The audit is bound to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Final candidate tree:
727fb0ecf94680b64fed5e1bb2bccecccde38e4d

Final boundary file:
765 lines
36,340 bytes
SHA-256:
ff9d9c6df68e6bb17d974c2f2abb0395735d0ead95bc79179daf7fbc01bea351

Final node count:
5,059

Final node-list SHA-256:
72ca14d20ff8e95384a8fa06b595227fb45bb7884aac295bbe4ae06ac761a0aa

G14 evidence root:
/private/tmp/g14.OxZUD3

G14 evidence-index SHA-256:
91764a62fb6db27d426a4a86415b29337cd1dff3710c8528160e0e4755dc46b2
```

### Principal audit work

The prompt requires four bounded perspectives:

1. **Permanent-test structure**
   - no subprocess, process, Git command, or Git-status dependency;
   - no remaining self-authentication machinery;
   - only the intended helpers, imports, 16 retained nodes, and three new nodes.

2. **Literal contracts and causal mutants**
   - exact AST recovery of R01–R30 and P01–P13;
   - independent one-predicate external mutants for every path/type/mode, size, digest, inventory, uniqueness, class-coverage, public/import/privacy, and authority assertion;
   - canonical controls must pass, mutants must fail at the intended finite diagnostic.

3. **A/B/C and node migration**
   - unstaged, external staged, and external committed representations;
   - identical literal projection;
   - exact tree equality;
   - exact 5,150→5,059 migration with 5,040 outside-file nodes preserving order.

4. **Validation and provenance**
   - retained G14 focused and dual-suite evidence;
   - independent focused validation;
   - independent live and clean suites if inspection remains green;
   - exact one-file delta and protected complement;
   - no public, runtime, durable-state, or authority widening.

The audit explicitly forbids treating coordinated mutation of the test and its own literals inside one Python interpreter as a candidate product defect.

## Acceptance boundary

The only accepting result is:

```text
ACCEPT

COORDINATOR_RW0_B2_CAPABILITY_ASSURANCE_RESET_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Only that acceptance permits a new commit/push/PR gate. It does not authorize merge.

**Source:** Codex’s assurance-reset implementation and validation report supplied inline in this turn.  
**Confidence:** High that the implementation now has the correct permanent-test trust boundary and is ready for independent audit; commit readiness remains unresolved until the external mutation ledger, A/B/C behavior, node migration, dual suites, and exact provenance are independently verified.
