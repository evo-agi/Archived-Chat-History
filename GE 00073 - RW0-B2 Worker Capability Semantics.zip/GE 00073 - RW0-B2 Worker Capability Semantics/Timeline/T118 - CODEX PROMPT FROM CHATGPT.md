PROMPT_ID

RW0_B2_CAPABILITY_COMMIT_STATE_COMPATIBILITY_DIAGNOSTIC_V1

TITLE

Coordinator RW0-B2-Capability — read-only diagnosis of the staged-state
full-suite failure before another commit-gate authorization

ENGAGEMENT TYPE

Read-only diagnostic in the same write-enabled Capability implementation
conversation after:

```text
COMMIT_GATE_FULL_SUITE_FAILED
```

No repository mutation is authorized.

Do not edit, format, stage in the real index, commit, push, create a PR, merge,
tag, release, deploy, contact a remote, invoke a product worker/model/provider,
install dependencies, or inspect a supporting repository.

External scratch repositories and an alternate external Git index are
authorized solely to simulate staged and clean-commit states without changing
the source repository or its real index.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OBJECTIVE

Determine whether the sole commit-gate failure is:

1. a staged-index-only sequencing incompatibility while the same candidate
   passes both its accepted unstaged state and the eventual clean committed
   state; or

2. a real accepted-test defect that would also fail after commit and therefore
   requires a repository-byte repair and another independent audit.

The failing test was:

```text
tests/test_rw0_b2_capability_boundaries.py::test_exact_twenty_path_ceiling_modes_and_protected_controls
```

Observed gate behavior:

```text
collection:
5057 nodes, passed once

full suite:
5056 passed
1 failed

failure:
the test expected six `??` untracked entries but observed zero because those
six files were staged additions

gate closeout:
all 30 paths unstaged
candidate bytes unchanged
24 tracked modifications
6 untracked additions
0 staged
no commit
no push
no PR
```

OPENING IDENTITY

Require exactly:

```text
physical root:
/Users/ds/Repositories/Governed Execution Coordinator/

branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

HEAD tree:
ef48f5bd11244c6f703c97abb5489d19956f7a77

sole parent:
02450d3c99faf0fe7b299b914afaed312421bc8b

upstream:
origin/trunk_dev

ahead/behind:
0/0

worktrees:
1

topology:
30 dirty paths
24 tracked modifications
6 untracked additions
0 staged
0 unmerged

all candidate paths:
regular mode 0644
```

Require:

- `git diff --check` clean;
- cached diff empty;
- no Git operation or lock;
- no repository residue;
- real index exactly unstaged.

ACCEPTED AUDIT TARGET

Accepted independent-audit root:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-independent-audit.T0I7mV
```

Accepted audit index:

```text
/private/tmp/ge-coordinator-rw0-b2-owner-oracle-independent-audit.T0I7mV/evidence_index.jsonl

rows excluding itself:
110

size:
23050 bytes

SHA-256:
e09add54af9a8d6e48969fd06a0c0e57bc2bf9125229f1f811c6781303c2cb54
```

Accepted final manifest SHA-256:

```text
9efb739e958cf077dafad99d5dc62af3fdcbd847c359916fd22fb5c125b79472
```

Accepted node identity:

```text
5057 nodes

ordered SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe
```

Failed commit-gate evidence:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-gate.ECxUPx
```

Commit-gate index:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-gate.ECxUPx/evidence_index.jsonl

rows excluding itself:
1054

size:
249127 bytes

SHA-256:
a944cf428eb753b568864e313402088d40474d764a280d8a4bc88ca65ca13dc5
```

Safely verify both indexes and preserve both roots unchanged.

DIAGNOSTIC EVIDENCE ROOT

Create one external operator-owned, non-symlink, mode-0700 root:

```text
/private/tmp/ge-coordinator-rw0-b2-capability-commit-state-diagnostic.XXXXXX
```

Retain all diagnostic commands, source inspection, alternate-index state,
external-clean-repository state, targeted pytest records, and final comparison.
Retained files mode 0400; directories mode 0700. Create a self-excluding index
last.

NO FULL SUITE

Do not run the full repository suite in this diagnostic.

Run only:

- source/helper inspection;
- direct read-only Git queries;
- the one failing pytest node in the three required states;
- any minimal helper-level probe needed to identify the exact predicate.

SOURCE AND CONTRACT INSPECTION

Inspect completely:

```text
tests/test_rw0_b2_capability_boundaries.py
```

Inspect every helper it invokes and every exact constant or inventory on which
the failing node depends.

Also inspect, only as concretely required:

```text
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_architecture_contracts.py
```

Report:

1. exact source lines causing the `??` expectation;
2. exact status commands and parsing logic;
3. whether the test distinguishes:
   - untracked worktree addition;
   - staged addition;
   - committed/tracked clean file;
4. what contract the test claims to enforce:
   - accepted implementation allowlist;
   - current dirty development topology;
   - staged topology;
   - committed tree shape;
   - protected paths/modes;
5. whether that contract is appropriate for a test intended to remain green
   after commit.

THREE-STATE TARGETED TEST MATRIX

Use the same sanitized pytest posture in all states:

```text
umask 022
env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
distinct external PYTHONPYCACHEPREFIX
distinct external TMPDIR
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PYTEST_ADDOPTS=''
PYTHONHASHSEED=0
python3 -B -m pytest -p no:cacheprovider -W error -q
distinct external --basetemp
distinct external --junitxml
```

Target only:

```text
tests/test_rw0_b2_capability_boundaries.py::test_exact_twenty_path_ceiling_modes_and_protected_controls
```

Record exact argv, environment, umask, stdout/stderr, JUnit, result, and
before/after fingerprints for every state.

## STATE A — LIVE ACCEPTED UNSTAGED CANDIDATE

Run the target in the source repository exactly as restored by the failed gate.

Require no real-index mutation.

Record:

- porcelain status seen by the test;
- six untracked paths;
- result and diagnostic.

## STATE B — ALTERNATE-INDEX STAGED CANDIDATE

Do not alter the real index.

1. Create a unique external `GIT_INDEX_FILE`.
2. Initialize it from the accepted HEAD.
3. Stage exactly the accepted 30 manifest paths into that alternate index.
4. Verify its staged tree equals the prospective accepted staged tree and that
   the source repository real index remains untouched.
5. Run the target with `GIT_INDEX_FILE` exported so all child Git commands see
   the alternate staged state.

Record:

- porcelain status seen by the test;
- staged `A` entries;
- result and exact failing predicate.

## STATE C — EXTERNAL CLEAN COMMITTED CANDIDATE

Create one external local-only repository simulation beneath the diagnostic
root.

Requirements:

1. derive it from the accepted base commit without remote contact;
2. use a real Git repository, not a plain archive;
3. create branch:
   `codex/rw0-b2-capability-semantics-v1`;
4. overlay exactly the 30 accepted candidate files;
5. verify every overlaid file against the accepted manifest;
6. stage exactly the 30 paths;
7. create one temporary local commit inside the external simulation;
8. require its tree to equal the State-B prospective staged tree;
9. require clean index/worktree after the temporary commit;
10. run only the target test in this clean committed simulation.

The temporary external commit is diagnostic-only and creates no source-repo or
remote effect.

Record:

- simulated commit/tree OIDs;
- clean porcelain status;
- target result and diagnostic;
- whether the committed branch context affects the test.

OPTIONAL STATE D — CLEAN HEAD WITH CANDIDATE TREE BUT NO COMMIT

Run only when needed to separate branch/HEAD identity from status cleanliness.
Do not use it as a substitute for State C.

DIRECT HELPER PROBE

If the test result alone does not isolate the logic, call its private
test/helper functions in an external Python probe against each captured status
shape.

Do not monkeypatch production or repository files. Retain the probe source and
results.

REQUIRED CLASSIFICATION

Return one primary token.

### COMMIT_GATE_SEQUENCE_CORRECTION_READY

Use only when all are true:

```text
State A passes
State B fails solely because accepted untracked additions become staged A entries
State C passes in a clean committed simulation
prospective staged tree equals the clean committed tree
candidate bytes and accepted manifest remain exact
```

Then state the corrected gate sequence:

```text
validate in a clean external committed simulation
verify its tree equals the accepted prospective staged tree
stage actual repository
compare staged tree and blobs to the already validated tree
commit without rerunning the status-sensitive full suite in staged state
push and open PR under the existing policy gate
```

Do not authorize that sequence in this diagnostic; only provide the exact
continuation boundary.

### CANDIDATE_TEST_REPAIR_REQUIRED

Use when:

- State C fails; or
- the test is semantically tied to untracked development status and cannot
  remain valid on the clean committed branch; or
- the test's asserted contract is wrong for committed repository behavior.

Identify the minimum repository test repair and require another fresh
independent audit.

### COMMIT_GATE_STAGING_HARNESS_REPAIR_REQUIRED

Use when State C passes but State B reveals a gate/tool wrapper issue different
from the expected status-sensitive test contract.

Describe the exact wrapper correction.

### COMMIT_GATE_PROVENANCE_MISMATCH

Use when the live candidate, accepted manifest, or evidence identity differs.

### COMMIT_STATE_DIAGNOSTIC_INCOMPLETE

Use when a required state cannot be safely simulated or recorded.

REQUIRED QUESTIONS

Answer explicitly:

1. Does the target pass in the accepted unstaged candidate?
2. Does it fail in the alternate-index staged candidate?
3. Does it pass in the clean committed simulation?
4. What exact Git-status predicate changes between the states?
5. Would the committed branch's full suite be expected to pass?
6. Is a repository-byte repair required?
7. Is another independent audit required before commit?
8. Can the commit gate be corrected solely by changing validation sequencing?
9. What exact next prompt type is required?

CLOSEOUT

After diagnostic runs:

- remove only diagnostic-created transient caches, basetemps, pycache roots,
  alternate index, and external simulation worktree after retaining their
  manifests/results;
- preserve diagnostic evidence and external temporary commit metadata;
- verify source repository and real index are byte/status identical to opening;
- verify accepted and failed-gate evidence roots unchanged;
- create a self-excluding diagnostic evidence index.

FINAL RESPONSE

Include:

1. primary classification token;
2. source/helper finding;
3. three-state results table;
4. prospective tree equality;
5. clean-commit compatibility conclusion;
6. repository-repair requirement;
7. corrected continuation boundary;
8. evidence-root and index identity;
9. provenance and diagnostic confidence.

Required final statements:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REAL_INDEX_MUTATION_NOT_PERFORMED
IMPLEMENTATION_REPAIR_NOT_PERFORMED
FULL_SUITE_NOT_RUN
STAGING_NOT_PERFORMED_IN_SOURCE_REPOSITORY
COMMIT_NOT_PERFORMED_IN_SOURCE_REPOSITORY
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
```
