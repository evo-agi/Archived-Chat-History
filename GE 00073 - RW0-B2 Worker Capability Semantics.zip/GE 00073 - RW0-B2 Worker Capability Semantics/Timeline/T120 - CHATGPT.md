## Engineering disposition

**The diagnostic is decisive: repair the permanent test, then run a fresh independent audit. Do not return directly to the commit gate.**

The accepted test conflates two different concerns:

- **Permanent repository contract:** expected private surfaces, regular-file modes, protected controls, no public export/caller/dependency/schema/authority widening.
- **Transient patch custody:** which paths are modified, untracked, staged, or clean at a particular lifecycle point.

The latter cannot remain in a committed test. The same accepted tree behaved as follows:

| State | Git status | Result |
|---|---|---|
| Audited development candidate | 24 modified, 6 untracked | Pass |
| Same tree staged | 24 staged modifications, 6 staged additions | Fail |
| Same tree committed and clean | Empty | Fail |

State B and State C shared the same tree OID:

```text
4336abdd16e51b27797d0364e0dcfcc3c58849fe
```

Therefore this is not a staging-wrapper problem. The committed branch would remain red. The patch-scope assertions belong in provenance, audit, and commit-gate evidence—not in the permanent test suite.

## Exact repair boundary

Only this path may change:

```text
tests/test_rw0_b2_capability_boundaries.py
```

The repair must:

- remove all requirements for six `??` files, 24 unstaged modifications, or any other dirty/staged topology;
- preserve the stable path, file-type, mode, protected-control, private-import, export, caller, dependency, schema, migration, and authority checks;
- add a bounded guard preventing the test or its local helper chain from reintroducing `git status`, dirty-count, staged-count, or untracked-count dependence;
- prove the target passes in the unstaged, alternate-index staged, and clean committed representations of the same tree;
- prove stable contract mutants still fail;
- pass the complete suite in both the live unstaged candidate and an exact external clean committed simulation.

Because repository bytes will change, the repaired candidate must receive another fresh independent audit before staging.

## Implementation handoff

Send this complete prompt to the **existing write-enabled Capability implementation conversation**:

:chatgpt-content-reference{index="0"}

Artifact identity:

```text
Filename:
Coordinator_RW0_B2_Capability_Commit_Compatibility_Test_Repair_Prompt.txt

Size:
20,965 bytes

SHA-256:
ab7bd70c3b26e9b06d07e35d2d3e096f7136cc73a5d8f39096f7dd2837906f9b
```

The prompt is bound to:

```text
Branch:
codex/rw0-b2-capability-semantics-v1

HEAD:
deec37bf08fb903d8846aa2c3232aec52fa9866e

Accepted manifest:
9efb739e958cf077dafad99d5dc62af3fdcbd847c359916fd22fb5c125b79472

Accepted nodes:
5,057

Accepted node-list SHA-256:
f30d9a526df1a9810b3ed7e41e8cbf71c6b6607b8e9c8bb107db1850ea027ffe

Diagnostic root:
/private/tmp/ge-coordinator-rw0-b2-capability-commit-state-diagnostic.2SxEgB

Diagnostic index SHA-256:
54c0c7fadf3f44b10f6ec59c056c2f800abdf9d0c4baac911c48732dd5f9f2cb
```

The required implementation result is:

```text
COORDINATOR_RW0_B2_CAPABILITY_COMMIT_COMPATIBILITY_TEST_REPAIRED_READY_FOR_FRESH_REAUDIT
```

That result permits only a new read-only audit. It does not authorize staging, commit, push, or PR creation.

### Sources

- Codex three-state commit-compatibility diagnostic supplied in this turn.
- Generated bounded repair prompt linked above.

**Confidence:** Very high that this is a one-file permanent-test defect; high that production and governing documents should remain untouched; high that another independent audit is required because the accepted repository bytes must change.
