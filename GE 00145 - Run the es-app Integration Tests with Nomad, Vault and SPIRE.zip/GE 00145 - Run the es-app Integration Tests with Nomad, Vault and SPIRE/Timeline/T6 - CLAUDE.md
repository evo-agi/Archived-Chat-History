One update on running the Nomad and Vault tests in CI, and nothing needs you. GitHub's standard runner can run them, and 32 of the 37 already pass there. Four fail because the tests or a script are out of date, a problem that exists on trunk_dev today. Those are being fixed first in their own PR. After that, the CI change will run 36 of the 37. The last one needs values that only an operator supplies, so it stays listed as a skip, with that reason.

STATUS: WORKING (test fixes, PR 13 repair, CI audit, MA fix)
