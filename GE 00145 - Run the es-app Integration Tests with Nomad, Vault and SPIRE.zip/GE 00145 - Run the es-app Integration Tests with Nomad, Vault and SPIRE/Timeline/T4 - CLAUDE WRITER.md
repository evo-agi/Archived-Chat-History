**Partly feasible, so I stopped before building it, as the brief says.** No PR is opened and PR 14's branch is untouched.

**What works.** The normal GitHub runner can run these tests, so no self-hosted runner is needed. I installed Nomad 2.1.1, Vault 2.2.2 and SPIRE 1.14.4, each pinned by hash (HashiCorp's signatures checked). With one setting added, 32 of the 37 tests passed on the runner in all three runs ([run 45052342848](https://github.com/evo-agi/Execution-Substrate/actions/runs/45052342848)). That setting is `AWS_EC2_METADATA_DISABLED=true`. Without it, Nomad fails at random on GitHub's AWS machines.

**What fails, and why that stops a CI-only change.** 5 tests fail every time, in my container and on the runner, and none of them for a runner reason:
- **Stale tests (3):** the stage-root count, the symlink archive and the Vault setup test. Each one expects behaviour the product has since changed on purpose. The Vault setup test can never pass as written.
- **Broken script (1):** the full bring-up script writes an ES config that ES now refuses.
- **Needs operator values (1):** the installed-source witness test needs provenance values that an operator supplies. Without them it fails by design.

PR 14's list only allows tests that fail for host reasons. Listing 4 code failures there would misstate them, and fixing them means changing tests and a script, which this thread may not touch.

**Recommendation (option A in section 7):** first, a small repair thread fixes the 4 broken tests and the script without weakening them. Then the CI change lands. It is already written and checked on the runner (report section 6). After that, 36 of the 37 run in CI, and the witness test becomes one honest list entry. Separately, those 4 tests are broken on trunk_dev today whatever is decided about CI.

Report: [01-implementation.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/01-implementation.md) (SHA-256 `667af1d436d07439ceabb658b8b0931e058809f8be0985a818dd9257ee9918cc`), evidence in `01-evidence/`. Still unknown: which Nomad and Vault versions the Linux box runs. Worth checking before the CI change is frozen.

STATUS: WAITING (on the coordinator's choice of option; nothing needed from David)
