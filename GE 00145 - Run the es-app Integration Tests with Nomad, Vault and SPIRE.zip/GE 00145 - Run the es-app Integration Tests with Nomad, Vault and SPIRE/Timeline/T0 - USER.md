> The CI fix's fourth repair passed your Mac run and is green on GitHub (PR 14 (→ github.com)), so I'm starting its focuse…


If they can be run on CI, sure.
