I'll find out whether those tests can run in CI and set them up if so.
