I've opened [draft PR 24](https://github.com/evo-agi/Execution-Substrate/pull/24), which makes CI install Nomad, Vault and SPIRE so ES's 37 Nomad and Vault tests run there instead of skipping. Every download and image is pinned and checked against a reviewed hash. The PR changes only CI config and docs.

I'm watching its first CI run. After that comes an audit, then a merge without your review.

STATUS: WORKING
