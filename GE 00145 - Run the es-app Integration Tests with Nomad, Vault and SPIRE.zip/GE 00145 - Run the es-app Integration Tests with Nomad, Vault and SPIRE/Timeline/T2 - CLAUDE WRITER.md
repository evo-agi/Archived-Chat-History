First I'll check what the 37 skipped tests need from Nomad and Vault and whether a GitHub runner can provide it.
