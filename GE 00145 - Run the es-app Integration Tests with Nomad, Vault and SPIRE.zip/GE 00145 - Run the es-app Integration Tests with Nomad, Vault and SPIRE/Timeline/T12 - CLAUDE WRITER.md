PR 24 is green on CI with Nomad, Vault and SPIRE installed. ~~All 37~~ 36 of the 37 Nomad and Vault tests that used to be skipped now run and pass on GitHub's runner. The one test that needs a source-identity envelope supplied by an operator still fails as intended and stays listed. [Edit: 36 run and pass; the 37th is that listed test.]

I've asked for an audit; it merges after that, without your review. Separately, ~~three~~ two old branches of mine can be deleted when you have a minute. I can't delete branches from here, so they're named in the report. [Edit: two, not three; the third was already gone.]

[Report](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/29-ci-nomad-pr24.md)

STATUS: WAITING (audit)
