Coordinator update for the PR #24 audit: report 29 gained a section 6 (branch list only); its sha256 is now 3998e191…3f89. Audit against that version.
