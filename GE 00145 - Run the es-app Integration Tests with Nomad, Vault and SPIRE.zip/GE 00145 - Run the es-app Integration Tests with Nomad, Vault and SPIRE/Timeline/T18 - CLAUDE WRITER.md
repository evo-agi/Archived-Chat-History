PR 24 is merged into trunk_dev as `df46164`. CI now runs 36 Nomad and Vault tests that used to be skipped. Its audit found nothing, and the merged code is identical to what was audited.

Next, as a small separate PR, I'm making the supported-local setup script check SPIRE's download against a pinned hash. Right now it only does that on CI.

STATUS: WORKING
