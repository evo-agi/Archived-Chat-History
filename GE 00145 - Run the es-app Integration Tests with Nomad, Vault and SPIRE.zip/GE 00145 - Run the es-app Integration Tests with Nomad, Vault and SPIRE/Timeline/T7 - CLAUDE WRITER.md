Draft [PR #17](https://github.com/evo-agi/Execution-Substrate/pull/17) repairs the three stale tests. Each one passed 3 times in a row on the GitHub runner. The bring-up test is not in it, because fixing it needs one decision from David (card below).

**The three tests.** Each behaviour change was made on purpose in #8, and the report cites the code and contract lines. Each test now checks the current behaviour at least as strictly as before. No product code changed. The supported-local test also had an older bug that has kept it from passing on Linux since the import: the binary was installed onto itself. I fixed that and added a check that the installed binary matches the one that was built.

**Bring-up.** Two of its three problems are simple test fixes. The third is a real script defect. Without the supported-local profile, bring-up runs ES in its container as root, but the run folders belong to the logged-in user. The startup check from #8 refuses that. On the runner the test passes if ES runs as that user, and also if the whole test runs as root.

**CI change.** It is ready on its own branch, on top of PR 14. On the runner the gate passes everything except the bring-up test.

Report: [02-repair-tests.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/02-repair-tests.md) (SHA-256 da226fa8…5570). PR #17 is ready for a fresh audit. I'm watching it.

STATUS: NEEDS DAVID
