# ES: repair of the es/app tests that block Nomad and Vault in CI

Report 02 of the CI Nomad/Vault track. Follows `01-implementation.md` (option A approved 2026-11-22 18:18Z: repair the stale tests and the bring-up first, then the CI change).

Date: 2026-11-22. Repository: `evo-agi/Execution-Substrate`. Evidence: `02-evidence/` beside this file (`SHA256SUMS.txt` lists every file).

## 1. Outcome

| Item | Result |
| --- | --- |
| The 3 stale tests | **Repaired**, draft [PR #17](https://github.com/evo-agi/Execution-Substrate/pull/17) into `trunk_dev`. Each test passed 3 times in a row on the GitHub runner. Intent of every behaviour change proved (section 3). |
| Bring-up test | **Stopped and reported, not in PR #17.** Two of its three causes have a test-only fix. The third is a real defect of bring-up without the supported-local profile: it runs the ES container as root while a non-root operator owns the execution roots, and the startup check that #8 added refuses that. Fixing it is a script change with a tradeoff, so it needs a decision (section 4). |
| CI change | **Ready on its own branch** `claude/project-thread-a9tcoa-ci` (commit `61f1d9d`, on PR #14 head `aaef28f`). On the runner the gate passes everything except the bring-up test (section 5). It becomes final once the bring-up decision is taken. |

Nothing was merged. No product code changed in PR #17.

## 2. Target identity (PR #17)

| Field | Value |
| --- | --- |
| Base | `trunk_dev` at `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| Topic branch | `claude/project-thread-a9tcoa` |
| Tip | `dac9736ba13d191064d1f129ca40be86d345fb1f` (tree `e045cfcb5f794c5a36278e6df10d01980b04c22c`) |
| Commits | `01cd1b1` repairs four tests; `dac9736` takes the bring-up test back out (file restored to the base byte for byte) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked with `sha256sum -c` before each run |
| Base-relative manifest | `cde984e741eeaf58931ffc16f90ac056afb4d8ce1464db7cae6e229ef8db0735` (890 bytes), HEAD `ae326b0`, upstream `origin/trunk_dev`, 3 files, all `tracked_modified`; textual diff `cf675a30dad238ad8516384b413a794e44da7a5ba54bc947e8e92cbf4aeb3a7b`. Taken twice in a fresh clone from GitHub after the push, byte-identical (`cmp`). Copy: `02-evidence/manifest-v2-repair-dac9736.json` |
| Files | `es/app/staging_cleanup_integration_test.go`, `es/app/submit_integration_test.go`, `es/app/supported_local_proof_validation_test.go` |

The bytes of these three files are identical at `01cd1b1`, at `dac9736` and at the probe commit `7a486b4` that the runner tested (`git diff --quiet`, exit 0 for each pair).

## 3. The three stale tests

All three behaviour changes come from `2478a24` ("Integrate private synthetic replay custody foundation (#8)", 2026-11-18). `git blame` at `ae326b0` attributes every cited line below to that commit unless a line says otherwise.

### 3.1 TestExecutionLoopScriptSuccessRetainsDistinctStageRootsAcrossRepeatedRuns

- **Failure on trunk_dev:** "expected two successful stage roots to remain, found 4". The extra two entries are `.execution-substrate-staging-probe-<token>` and its `-symlink` (01, `container-stage-root-names.txt`).
- **Changed on purpose:** `es/admission/execution_roots.go:449-499` (`probeCapabilities`: `stagingName := ".execution-substrate-staging-probe-" + token` at :457, the symlink at :487-491). The contract keeps them: `.docs/system_overview/capability_probing.md:224-228` ("The isolated candidate retains its small exclusively created startup probe fixtures under the configured roots … the probe does not delete those names"), :314-315 and :324-326.
- **Old assertion:** exactly 2 entries in the staging root; the two run roots differ.
- **New assertion:** every entry is accounted for. Exactly two run roots (`^run-[0-9a-f]{16}$`, real directories), which are the two run IDs from the summaries and differ; exactly one probe directory (`^\.execution-substrate-staging-probe-[0-9a-f]{32}$`, a real directory) and exactly one `<probe>-symlink` whose target is that probe name; no quarantine name; nothing else. This is the inventory check that #8 itself added to `TestFailedAndAmbiguousSubmitRetainCreatedStageRoot` in the same file (lines 158-202), as a helper.
- **At least as strict:** the old test allowed any two entries; the new one names them and also catches a third run root, a stray file or a second probe pair. The helper was checked against 7 synthetic inventories in the container: it accepts the good one and rejects an extra file, a missing symlink, a wrong link target, a second probe pair, a run root that is a symlink and a quarantine name (`container-inventory-helper-negative-cases.log`; the scratch test is in `…_test.go.txt` and was not committed).

### 3.2 TestSubmitFlowRejectsWorkloadArchiveWithSymlinkEntry

- **Failure on trunk_dev:** "expected 202, got 403 body={…"code":"admission_policy_input_unavailable"}".
- **Changed on purpose:** `.docs/execution_lifecycle/contracts.md:562-570` (2478a24): "The entire archive must have no … traversal, link, special entry … An ambiguous or malformed archive fails with `admission_policy_input_unavailable` before policy allow, Submit run assignment, materialization, or provider registration." The code is `es/internal/staticarchive/archive.go:56-58` (refuses any entry type other than directory and regular file), read by `extractStaticScriptEntrypointText`, `es/admission/policy_payload.go:103-171`. The safe message is older contract text, `contracts.md:559-561` (308ae8e). Before #8 the extractor returned as soon as it found the entrypoint, so a link after it passed admission and failed at runtime extraction.
- **Old assertion:** 202, then a failed allocation whose logs lack `WORKLOAD-STARTED`.
- **New assertion:** 403; the body decodes into `admission.ErrorResponse` with unknown fields refused, `success=false`, code `admission_policy_input_unavailable`, error `admission policy input unavailable`; the test's own Nomad agent lists no job; the staging root holds no `run-` entry. Then a control in the same stack: the same archive without the link entry is admitted (202) and its allocation logs contain `WORKLOAD-STARTED`.
- **At least as strict:** the old intent (the workload never starts) holds more strongly, because nothing reaches Nomad at all. The control shows the refusal is caused by the link entry and not by the stack.

### 3.3 TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget

- **Failure on trunk_dev:** setup exits at once: the proof directory lies under the repository's `.out`.
- **Changed on purpose:** `scripts/internal/supported_local_execution_roots.py:40-52` (`clean_proof_path` refuses a path equal to, under, or containing the source root). Intent is shown by its own unit test, `scripts/internal/test_supported_local_execution_roots.py:189-193`, which asserts refusal of `source_root / "fixtures"` and of `source_root.parent` (both 2478a24). Related contract text: `contracts.md:1512-1515`. The test itself was touched by #8 (its result-key lines 36-43), so the omission was not deliberate.
- **New workspace:** `os.MkdirTemp("/tmp", "esls-")`, removed at cleanup like the old one. It is short because the proof directory holds the SPIRE Unix sockets.
- **Second defect, not a behaviour change:** once the proof path was accepted, setup failed with "install: … are the same file". The test set `SUPPORTED_LOCAL_RUNTIME_SUPPORT_BINARY` to `<proof>/bin/es-runtime-support`, which is exactly where `build_runtime_support_binary` builds the binary before it installs it there (`scripts/72_supported_local_setup.sh:330-348`). Both the script lines (except the Go toolchain lines changed in 31b4faf) and the test's value are unchanged since the import `8a5e166`, so the test cannot have passed on Linux since then. Inference: it was never run, because it needs a local `vault`. The install path is now `<workspace>/runtime-support/es-runtime-support` (the directory is created first, because setup only installs into an existing directory), and the test now checks that `PROOF_RUNTIME_SUPPORT_BINARY` names that path, that the installed bytes equal the built binary and that its mode is 0755.
- **At least as strict:** every earlier assertion is kept; three are added.

### 3.4 Validation

| Where | Result |
| --- | --- |
| GitHub runner, run 45055948469 (probe commit `7a486b4`), Nomad 2.1.1 / Vault 2.2.2 / SPIRE 1.14.4 pinned, `AWS_EC2_METADATA_DISABLED=true` | Pass 1: all three pass (15.9 s, 3.9 s, 5.3 s). Passes 2 and 3 (`-count=2`): all pass. `gofmt -l es/app` empty, `go vet ./es/app` clean. Whole `es/app` package: failures only `TestBringupScriptUpCheckDownFullProfile`, the witness test, and the two tests whose missing-Go subtests PR #14 lists as entries; no skips; 386 s. |
| Cloud container, non-root user in group docker, with passwordless sudo for the setup's root-owned roots | All three pass (`container-three-repaired-tests.log`). |

## 4. Bring-up test: stopped, decision needed

`TestBringupScriptUpCheckDownFullProfile` has three separate causes. I found them one at a time on the runner.

1. **Missing retained-result key (changed on purpose in #8).** ES refused its config: "execution.retained_result_auth.store_id must be a canonical 1-32 byte identifier". Contract: `.docs/execution_lifecycle/contracts.md:1488-1497` ("Configured Submit requires `execution.retained_result_auth.store_id`, `key_id`, and `key_file` at startup … There is no default, generator, fallback"); code `es/config/config.go:514, 520-523`. The key file must be owned by ES's own effective UID (`es/admission/result_auth.go:106-114`). Test fix: supply the key, as the trusted operator the contract describes.
2. **Stale SPIRE mount assertion (not a behaviour change).** The test allows the SPIRE socket file as the one bind source outside the staging root, but ES mounts the socket's directory. The other submit tests have asserted the directory since the import (`es/app/submit_integration_test.go:717`, 8a5e166). Test fix: allow `filepath.Dir(socket)`.
3. **Identity mismatch (a real defect).** With 1 fixed, ES stops at startup: "validate execution root capabilities: natural retained result directory creation is unavailable". Bring-up without the supported-local profile creates the execution roots as the operator and requires the operator to be able to write them (`scripts/internal/control_plane.sh:368-391`; PLANS.md:218 "Generic callers without this explicit profile retain caller-writable readiness"). But it starts the ES container without `--user` (`scripts/05_start_es.sh:38`), so on a rootful Docker daemon ES runs as root. #8's startup probe requires that a result directory ES creates naturally has the roots' owner (`es/admission/execution_roots.go:551-580`, `implementation.md:985-986`), and a directory created by root does not. So on a host where the operator is not root and Docker is rootful, which is the GitHub runner, this cloud container and, Guess: most Linux hosts, bring-up without the profile cannot start ES since #8. Nothing documents that as intended.

Evidence on the runner, same test, all with fixes 1 and 2 unless noted:

| Run | Setup | Result |
| --- | --- | --- |
| 45055948469 | fix 1 only, runner user | fails at ES startup (cause 3) |
| 45057394257 | fix 1 only, test run as root | gets through up, check and the execute loop; fails at cause 2 |
| 45057714004 | fixes 1 and 2, test run as root | **passes** (49.7 s) |
| 45057985918 | fixes 1 and 2, runner user, probe-only change: `05_start_es.sh` adds `--user "$(id -u):$(id -g)"` when no supported-local roots profile is set, key written by the operator | **passes** (50.0 s) |

So causes 1 and 2 are the only test defects, and cause 3 disappears whenever the operator and the containerised ES are the same identity.

**Options** (the decision card in the thread asks this):

- **A. Bring-up runs the ES container as the operator (recommended).** Without the supported-local profile and on a rootful daemon, `05_start_es.sh` passes `--user <operator uid>:<operator gid>`. A root operator gets `0:0`, as today. A rootless daemon keeps today's behaviour, because there the container's root already is the operator. The test writes the key as the operator and gets fix 2. Docs: one sentence in PLANS.md and contracts.md for the generic path. Shown passing on the runner as the runner user; the rootless branch is not tested (Unknown). The bring-up test then runs in CI.
- **B. No script change; CI lists the bring-up test as a second entry.** The test gets fixes 1 (key written from a container, so owned by root on a rootful daemon) and 2, and can pass where the operator is root. On the runner it fails for the host reason above, so it would be an entry, and bring-up would not run in CI. Bring-up without the profile stays broken for non-root operators on rootful Docker.

Why A: it makes the generic path consistent with itself (the operator owns the roots, so ES must be the operator to create directories with that owner), it keeps the operator path end to end in CI, and it is shown green on the runner. Its risk is the rootless case, which it leaves as it is today.

The probe-only change for A is in `02-evidence/probe-7220ec1-es-as-operator.diff.txt`; it was not committed to any PR branch.

## 5. CI change (branch `claude/project-thread-a9tcoa-ci`)

- Commit `61f1d9d` on PR #14 head `aaef28f`. Manifest relative to `aaef28f` (upstream pinned to `origin/claude/project-thread-sqldt7-ci`): `082c3f036d028f49abd17022066fdfb34cabc57cfd4e0f75ac13f9b1183868f6` (1,280 bytes), 5 files, all `tracked_modified`, textual diff `0613777f8a3cd87e89d900191757bb1d3e5be80b53cd9f516c4ad088475ed71d`, taken twice, identical.
- `go.yml`: job env `AWS_EC2_METADATA_DISABLED: "true"` with its reason; step "Install Nomad, Vault and SPIRE" (curl, then `sha256sum --check --strict` against the three hashes of 01 §6, then unzip, `$GITHUB_PATH`, `SUPPORTED_LOCAL_TEST_SPIRE_TARBALL`); step "Show Nomad and Vault"; step "Pull test images by digest" (alpine, python, golang by the digests of 01 §6, then tagged with the names the tests use). No `if:`, no `continue-on-error`, actions unchanged.
- `go_test_gate_selftest.py`: `WORKFLOW_SHA256` set to the new hash `2683df59f4a14fa19bc4fb3223c45e98897a2c5963364b7330c1a9888ce4e76e`. No other change; `OBSERVED_GO_VERSION` and `MATCH_GO_SHA256` untouched (no Go change).
- `environment-only-tests.txt`: the 37 es/app `skips-itself` lines and their two comment blocks removed; one entry added for `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`, with the reason that it needs an operator's source-identity envelope (the four `ES_MOUNT_WITNESS_*` values from a governed checkout), fails on purpose without it, and that made-up values would make its evidence false.
- `go_toolchain_baseline.md` §10: one paragraph on the installed tools, the reviewed hashes and digests and the metadata variable; one sentence that the Nomad, Vault and SPIRE a test starts are throwaway test instances, not a deployment. `docs_contract_test.go` holds the new sentences and the new workflow lines (env, the three fetch lines, the check line, the version step).
- Local checks: self-check 117 of 117 OK; `TestGo1265ToolchainBaselineDocsAndBuildContract` passes.
- Runner check (probe branch `claude/project-thread-a9tcoa-ci-probe` = this commit + a merge of the repair + `probe-go.yml`, which is `go.yml` with only the trigger and name changed): run 45056633020. Build, both vets, the three new steps and the self-check pass. The gate fails only on `es/app` `TestBringupScriptUpCheckDownFullProfile` ("bringup up failed"; the merged repair still carried the bring-up test with only fix 1; Inference: cause 3, as in run 45055948469 with the same test bytes, since the gate log does not print the bring-up logs); no es/app test skipped itself; the witness entry was skipped as listed; every other package passed.
- Timing: the gate's single `es/app` run took 377 s, against go test's default 10-minute limit (the gate passes no `-timeout`). A timeout would fail the run, not pass it, but the margin is only 1.6x. The gate's self-check parses the exact `go test -json -count=1 …` lines, so adding `-timeout` means editing the gate and several self-check patterns; I did not do that here. Suggest deciding it in the CI change's audit.
- What still changes before it is final: with option A, nothing in this branch (the bring-up test passes on the runner); with option B, a second entry for the bring-up test. Either way the branch is rebased onto `trunk_dev` once PR #14 and PR #17 (and the bring-up PR) have landed, and it is opened as a pull request then.

## 6. Branches pushed

| Branch | Holds | Note |
| --- | --- | --- |
| `claude/project-thread-a9tcoa` | PR #17 | draft, into `trunk_dev` |
| `claude/project-thread-a9tcoa-ci` | the CI change | not opened as a PR yet |
| `claude/project-thread-a9tcoa-repair-probe` | probe workflow + bring-up experiments | probe only; deleting needs David's go |
| `claude/project-thread-a9tcoa-ci-probe` | CI change + repair merge + `probe-go.yml` | probe only; deleting needs David's go |
| `claude/project-thread-a9tcoa-probe` | 01's probe | probe only; deleting needs David's go |

## 7. Unknowns and limits

- Unknown: how bring-up behaves on a rootless Docker daemon or Docker Desktop, before or after option A. Not tested.
- Unknown: Nomad and Vault versions on Remote Alpha (still to check before freezing the pins).
- PR #17 has no CI check of its own: `trunk_dev` has no workflow until PR #14 merges. Its runner evidence is the probe run above, on identical bytes.
- `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` needs passwordless `sudo` (the setup creates root-owned roots) and does not skip without it. That is unchanged and true on the GitHub runner.

## 8. Next

1. David decides the bring-up option (card in the thread).
2. Fresh audit of PR #17 (base `ae326b0`, tip `dac9736`, manifest `cde984e7…0735`).
3. Bring-up PR from `trunk_dev`, per the decision, green on the runner, own report and audit.
4. After PR #14, PR #17 and the bring-up PR land: rebase the CI branch, re-take its manifest, open it, fresh audit.
