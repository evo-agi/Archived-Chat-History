# ES CI: run the Nomad and Vault tests on the runner — 01 feasibility report

**Repository:** evo-agi/Execution-Substrate
**Base:** PR #14 head `aaef28f36f393e78f832a9caa745edeb02565a6c` (branch `claude/project-thread-sqldt7-ci`), not changed by this thread
**Thread:** "Run Nomad and Vault tests in CI", 2026-11-22, 17:31Z to ~18:25Z
**Verdict:** `RECONNAISSANCE_BLOCKED` — **partly feasible; stopped before implementation**, as the brief says to when the change is only partly feasible or would need product or test code changes.
**Effect status:** PR #14 branch untouched. No implementation branch pushed, no PR opened (`PR_NOT_OPENED`, `MERGE_NOT_PERFORMED`, `INDEPENDENT_AUDIT_NOT_PERFORMED`). One probe branch pushed, `claude/project-thread-a9tcoa-probe` (2 commits, a probe workflow only; section 9). No product, test or CI file of the repo changed.

## 1. Answer in short

- **The runner can run them.** A GitHub-hosted `ubuntu-24.04` runner already has Docker and a non-root user in the `docker` group. With Nomad 2.1.1, Vault 2.2.2 and SPIRE 1.14.4 installed from pinned, hash-checked downloads, and one environment variable (`AWS_EC2_METADATA_DISABLED=true`, section 4.2), **32 of the 37 tests pass on the runner, in two passes in a row and once more in a run of the whole `es/app` package** (run 45052342848). No self-hosted runner is needed.
- **5 of the 37 fail on the runner, and none of them for a runner reason.** Three tests are stale against current, documented product behaviour; one test drives a bring-up script that writes an ES config that ES now refuses; one test needs provenance values that an operator supplies by design (section 5). The same 5 fail in my cloud container too.
- **Why I stopped.** Once `nomad` and `vault` are on the runner, these 5 tests run and fail, so the gate of PR #14 needs a line for each. Its list holds only tests that fail "for host reasons, not code reasons" (`.github/ci/environment-only-tests.txt:1-2`, held in the doc by `docs_contract_test.go:967`). Four of the 5 fail for code reasons. Making CI green would mean either changing tests or scripts (out of scope: "This change touches CI only") or listing code failures as host failures (a misstatement, and a change of the list's contract). Neither is mine to choose.
- **Recommendation (section 7):** first a small repair tranche for the four code-reason failures (test and script changes in `es/app` and `scripts/`, with its own audit), then the CI change of section 6, which then has exactly one new entry (the installed-source witness, section 5.4) and deletes the other 36 `es/app` `skips-itself` lines.

## 2. Reading of the ask

David (thread root, 17:31:19Z): "If they can be run on CI, sure." The coordinator's brief: determine feasibility; if only partly feasible, stop and report why and the alternatives; do not weaken tests; CI only, product code out of scope. I read "run them on CI" as: the 37 `es/app` tests that PR #14's list marks `skips-itself` for missing `nomad` (36) and `vault` (1) run and pass in the `go` workflow on the GitHub-hosted runner, under the gate as it is. The two `reliablesubmit` helper-process lines are not part of the ask (they skip on every host).

## 3. What the tests need (repo facts at `aaef28f`)

- **Nomad:** each test starts its own agent, `nomad agent -dev -config=<file>` (`es/app/submit_integration_test.go:2729`), with a server and a client on 127.0.0.1 and reserved ports (`:2654-2726`). The client uses the Docker driver with volumes on (`:2681-2697`). The agent runs as the user who runs `go test`. No Nomad version is named anywhere in the repo (searched: repo, Archived-Runbooks, IM, MA). `scripts/70_linux_setup.sh:85-86` installs Nomad from the HashiCorp apt repository, unpinned. **Unknown:** which Nomad version Remote Alpha runs. I used the latest release, 2.1.1.
- **Docker:** a daemon reachable at `/var/run/docker.sock` (the installed-source witness requires the socket itself, `:1146-1155`), host networking that keeps host loopback (`operator_scripts_integration_test.go:3810-3830`), and the images `alpine:3.20`, `python:3.13-alpine` (by tag in the tests) and `golang:1.26.5-alpine3.24` (the generated control-plane Dockerfile).
- **Capability probe:** the tests skip unless a probe agent becomes schedulable with a healthy Docker driver (`submit_integration_test.go:1871-1912`) and a Unix socket mounts into a Nomad allocation (`:1914-1964`).
- **Vault:** only `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` needs the `vault` command (`supported_local_proof_validation_test.go:27-31`). It runs `scripts/72_supported_local_setup.sh`, which downloads SPIRE 1.14.4 from GitHub without a checksum (`scripts/72_supported_local_setup.sh:21, 421-458`) unless `SUPPORTED_LOCAL_TEST_SPIRE_TARBALL` names a tarball (`supported_local_proof_validation_test.go:66-68`). It also needs passwordless `sudo` when not root (`scripts/72_supported_local_setup.sh:178-183`); the runner has it.
- **Privileges:** none beyond the runner's defaults. The runner user is `uid=1001(runner)` in group `docker` (probe log, "Host facts"). Nomad runs as that user on cgroup v2 and works (section 4).

## 4. What I ran

### 4.1 Cloud container (local trial)

dockerd 29.10.0 started inside the container (cgroup v1, Firecracker kernel 6.18). Go 1.26.5 copied outside the module cache to `/opt/go1.26.5`. Nomad 2.1.1 and Vault 2.2.2 unzipped to `/opt/hc/bin` from the verified zips (section 6.2). Tests ran as an unprivileged user `ci` (member of `docker`) with `env -i` and no proxy variables, from a copy of the tree at `aaef28f`.

| Command (as `ci`, see `01-evidence/container-*.sh.txt`) | Result |
| --- | --- |
| `go test ./es/app -run '^TestRuntimeIdentityIntegrationCapabilityProbe$' -count=1 -v` | PASS (8.86 s): the probe passes, so the tests no longer skip |
| `go test ./es/app -run '^(<the 37>)$' -count=1 -v -timeout 90m` | 32 PASS, 5 FAIL, 260.6 s (`container-37-tests.log`) |
| `go test ./es/app -count=1 -v -timeout 80m` (whole package, nothing skipped) | 155 top-level PASS, the same 5 FAIL, 353.5 s (`container-es-app-whole-package.log`) |

In the container the two missing-Go-fixture entries of PR #14's list pass (this container has no `go` in `/usr/bin` or `/bin`); on the runner they fail as listed. Containers here have no network egress (checked: `wget` from `alpine:3.20` gets "Connection reset by peer"), so the bring-up test fails earlier in the container than on the runner (its image build cannot download).

### 4.2 GitHub-hosted runner (probe workflow on the probe branch)

| Run | Commit | Setup | Result |
| --- | --- | --- | --- |
| [45050766307](https://github.com/evo-agi/Execution-Substrate/actions/runs/45050766307), job 137295151368 | `aae25c1` | pinned Nomad/Vault/SPIRE, images pre-pulled by digest | **Many tests fail after 15 s**, and different ones in the two runs (17 of 37, then 21 in the whole package). Each says `Error starting agent: client setup failed: fingerprinting failed: operation error ec2imds: GetMetadata, context deadline exceeded`. |
| [45052342848](https://github.com/evo-agi/Execution-Substrate/actions/runs/45052342848), job 137300032004 | `4a5ecc3` | same, plus job env `AWS_EC2_METADATA_DISABLED: "true"` | **The 37, first pass:** 32 PASS, 5 FAIL, 304.3 s. **Second pass:** the same 32 PASS, same 5 FAIL, 281.2 s. **Whole `es/app` package, nothing skipped:** only the same 5 and PR #14's two listed missing-Go subtests' parent tests fail, 340.4 s. |

Runner facts from the log: image `ubuntu-24.04` version 20261116.133.1, Ubuntu 24.04.5, kernel 7.0.0-1014-aws, AWS us-east-1, 4 CPUs, 15.7 GB RAM, cgroup v2, Docker 28.0.4 (cgroup driver systemd).

**The 15 s failures are a runner fact, and the variable is the fix.** The runner is an AWS instance whose EC2 metadata endpoint does not answer. Nomad's `env_aws` fingerprinter asks it and the agent's client setup fails when the call times out. `AWS_EC2_METADATA_DISABLED=true` makes the AWS SDK inside Nomad refuse that call at once, so the fingerprinter finds no AWS environment and the agent starts. Inference: this is how the fix works (from the AWS SDK's documented variable and the error text); the observed fact is that all 32 tests passed three times with it and failed at random without it. ES itself has no AWS SDK dependency (`go.mod` and `go.sum` name no AWS module, and no Go source reads an `AWS_` variable), so the variable cannot change ES behaviour. It changes nothing in any test.

## 5. The five failures, with root causes

All five fail identically in the container and in every runner pass. None is flaky in these runs.

### 5.1 `TestBringupScriptUpCheckDownFullProfile` — code reason (bring-up script vs ES config)

Runner: `operator_scripts_integration_test.go:365: bringup up failed` after `execution: health request failed`. The kept bring-up log `es.log` (probe run 2, "Bring-up logs" step) shows why ES never listened:

```text
load config: execution.retained_result_auth.store_id must be a canonical 1-32 byte identifier
```

That check is `es/config/config.go:520-523`. The bring-up path that the test drives (`scripts/01_bringup.sh`, `scripts/internal/bringup.sh`, `scripts/internal/control_plane.sh`) writes no `retained_result_auth` at all (`grep` finds the term only in the supported-local scripts 72/73 and `scripts/internal/supported_local_retained_result_auth.sh`). The image build, ARS, EGS and AGS all start; ES refuses its config. A fix belongs in the bring-up script or the test's inputs, not in CI. Which one is a product decision: **Unknown** whether the full-profile bring-up path is still supported or superseded by the supported-local scripts.

### 5.2 `TestExecutionLoopScriptSuccessRetainsDistinctStageRootsAcrossRepeatedRuns` — stale test

`staging_cleanup_integration_test.go:251-253` requires exactly two entries in the staging root after two runs and finds 4. With the names printed (throwaway copy, `01-evidence/container-stage-root-names.txt`):

```text
.execution-substrate-staging-probe-1679abb6…  .execution-substrate-staging-probe-1679abb6…-symlink  run-8f73cc4b0cff0dd3  run-b2113d40b6ac3b5f
```

The two extra entries are the configured-Submit startup probe fixtures, which the docs say stay there: "the exclusive startup fixtures remain under the configured roots until a separately governed reclamation rule exists" (`.docs/system_overview/capability_probing.md:325-326`, and `:135-150`). The newer hermetic test already counts only `run-` entries (`es/app/resolved_plan_custody_hermetic_test.go:53-67`). The test needs the same treatment without losing its two assertions (two retained run roots, distinct).

### 5.3 `TestSubmitFlowRejectsWorkloadArchiveWithSymlinkEntry` — stale test

`submit_integration_test.go:945-949` expects `202 Accepted` and then a failed allocation. ES now answers `403 {"code":"admission_policy_input_unavailable"}`: the admission policy reads the static-script archive before admission (`es/admission/policy_payload.go:23-55`), and an archive it cannot inspect, here one with a symlink entry, maps to that refusal (`:95-100`, `es/admission/policy.go:270-276`). The security property the test is named for (the workload never starts) still holds, earlier. The test needs to assert the admission-time refusal (and that no job was registered), which is stronger, not weaker. Whether the 403 code is the intended code for this case is a product question: **Unknown**.

### 5.4 `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` — needs operator-supplied provenance, by design

`submit_integration_test.go:1013-1015` calls `requireMountedSourceWitnessEnvelope` (`mounted_source_identity_test.go:1078-1097`), which fails unless `ES_MOUNT_WITNESS_SOURCE_MANIFEST_SHA256`, `…_TRACKED_DIFF_SHA256`, `…_RECIPE_ENVELOPE_SHA256` and `ES_MOUNT_WITNESS_COMMAND_ID` hold authentic values. The doc is explicit: on a capable host "the unchanged envelope validator still requires authentic … values … Missing envelope values alone do not justify a skip" (`.docs/system_overview/capability_probing.md:349-356`). So on any capable host without those values this test fails, as designed. I did not invent values: the repo does not define the recipe that makes them authentic, and made-up hashes would be a false witness. This one is an environment-input reason and fits the list as an entry (section 6.4). Producing authentic values in CI would need that recipe defined first: **Unknown** whether that is wanted.

### 5.5 `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` — stale test

`supported_local_proof_validation_test.go:72`: `run supported-local setup: exit status 1 output=supported-local execution-root scope is invalid`. The test puts its proof directory under the repository's `.out` (`:34-35` via `newExecutionWorkspaceTempDir`, `submit_integration_test.go:3436-3456`). The execution-roots helper refuses any proof path inside the source tree (`scripts/internal/supported_local_execution_roots.py:49-52`), and the setup script stops at that preflight (`scripts/72_supported_local_setup.sh:174-177`). So this test fails on every host that has `vault`; it can never have passed since that helper rule exists. It never reached SPIRE or Vault, so whether the rest of it passes on the runner is **Unknown** until the test is fixed (it will then also exercise `sudo -n` provisioning on the runner).

## 6. The CI change that is ready once section 5 is settled

Validated on the runner in run 45052342848 (the same steps, in the probe workflow).

### 6.1 Steps to add to `.github/workflows/go.yml`, before "Download modules"

```yaml
      # The es/app integration tests start their own Nomad agent and need
      # vault and a SPIRE release. Each download is pinned by SHA-256.
      - name: Install Nomad, Vault and SPIRE
        run: |
          set -euo pipefail
          tools="$RUNNER_TEMP/tools"; mkdir -p "$tools/bin" "$tools/dl"
          fetch() { curl --fail --silent --show-error --location --retry 3 -o "$tools/dl/$2" "$1"; echo "$3  $tools/dl/$2" | sha256sum --check --strict; }
          fetch https://releases.hashicorp.com/nomad/2.1.1/nomad_2.1.1_linux_amd64.zip nomad.zip 073084f7690fdaea756ff1eff8b669b25c3a6c17778f19ae0c47606973ed3f39
          fetch https://releases.hashicorp.com/vault/2.2.2/vault_2.2.2_linux_amd64.zip vault.zip 5700edf139113609962fe371af7d2a53de8ecb720d545dc39b43de204515d3c4
          fetch https://github.com/spiffe/spire/releases/download/v1.14.4/spire-1.14.4-linux-amd64-musl.tar.gz spire.tar.gz 4482db434af8a3d2f4c5aeaef8912b21311411a175ce7daeb49ea17b776bcbf5
          unzip -q -o "$tools/dl/nomad.zip" nomad -d "$tools/bin"
          unzip -q -o "$tools/dl/vault.zip" vault -d "$tools/bin"
          echo "$tools/bin" >> "$GITHUB_PATH"
          echo "SUPPORTED_LOCAL_TEST_SPIRE_TARBALL=$tools/dl/spire.tar.gz" >> "$GITHUB_ENV"

      # The tests name these images by tag. Pulling them by digest first
      # pins what runs; the Docker driver uses a local image it finds.
      - name: Pull test images by digest
        run: |
          set -euo pipefail
          pull() { docker pull --quiet "$1@$2"; docker tag "$1@$2" "$1:$3"; }
          pull alpine sha256:d9e853e87e55526f6b2917df91a2115c36dd7c696a35be12163d44e6e2a4b6bc 3.20
          pull python sha256:9ef1a599f863231c3d91e941389bfdc4a2d6070557243d54df1a4e57015b960e 3.13-alpine
          pull golang sha256:0178a641fbb4858c5f1b48e34bdaabe0350a330a1b1149aabd498d0699ff5fb2 1.26.5-alpine3.24
```

and in the job `env:`:

```yaml
      # The runner is an AWS instance whose metadata endpoint does not
      # answer. Nomad's AWS fingerprinter then fails client setup at random.
      AWS_EC2_METADATA_DISABLED: "true"
```

### 6.2 Where the hashes come from

- **Nomad 2.1.1 and Vault 2.2.2:** each zip's SHA-256 equals its line in `<product>_<version>_SHA256SUMS`, and that file's detached signature verifies with HashiCorp's key, primary fingerprint `C874 011F 0AB4 0511 0D02 1055 3436 5D94 72D7 468F`, signing subkey `374E C75B 4859 1360 4A83 1CC7 C820 C6D5 CD27 AB87` (gpg output in `01-evidence/binary-hash-provenance.txt`; key file fetched from `https://www.hashicorp.com/.well-known/pgp-key.txt`). Both hashes matched again on the runner (`sha256sum --check --strict`: OK).
- **SPIRE 1.14.4** (the version the setup script defaults to, `scripts/72_supported_local_setup.sh:21`): the hash equals the release's own `spire-1.14.4-linux-amd64-musl_sha256sum.txt`. Same origin as the tarball; I did not verify a SPIRE signature (cosign). State it as such.
- **Images:** the index digests that Docker Hub served for the three tags on 2026-11-22 (`docker image inspect` RepoDigests in the container). On the runner the pinned pulls took 4 s.
- **Not pinnable from CI:** the bring-up test's image build runs `apk add` and downloads Go modules inside the build (`.out/Dockerfile`, generated by `scripts/generate_control_plane_dockerfile.sh`). Go modules are checked against `go.sum`; the Alpine packages are not pinned. That is the product's build recipe; CI cannot pin it without a script change.

### 6.3 Other edits the same change needs

- `WORKFLOW_SHA256` in `.github/ci/go_test_gate_selftest.py:53` (held also by `docs_contract_test.go:1021-1024`).
- `.docs/system_overview/go_toolchain_baseline.md` section 10 and its held sentences in `docs_contract_test.go:958-992`: say that the job installs pinned Nomad, Vault and SPIRE, pulls the images by digest, and sets the metadata variable, and keep "not a Linux runtime proof" true (these are test agents in `-dev` mode, which `.docs/system_overview/supported_linux_host_qualification.md:70, 158` names as unsupported for a support claim).
- The list: delete the 36 `es/app` `skips-itself` lines for Nomad and the one for Vault; add one entry for 5.4 with its reason. The two `reliablesubmit` helper lines stay.
- No Go version change, so `OBSERVED_GO_VERSION` and `MATCH_GO_SHA256` stay.

### 6.4 Cost on the runner

Public repository, so GitHub-hosted runner minutes cost nothing (`search/repositories`: `"visibility":"public"`). Wall clock: the whole `es/app` package took 340 s on the runner with the integration tests (probe run 2). I did not measure today's `es/app` time on the runner separately. The gate runs `es/app` three times (the gate run, the observed run, and the whole-package run of "Listed tests still fail"), so the job should grow from ~12 min to roughly 25-30 min. Inference from the probe timings; not measured through the gate.

One risk to settle in that change: `go_test_gate.py` passes no `-timeout`, so each test binary has go test's default 10 minutes. With the metadata fix, the `es/app` runs took 281-340 s on the runner (three runs); in run 1, without it, they took 397 s and 462 s because many tests waited 15 s. That leaves margin, but runner variance could reach 10 min, and the binary would then panic and fail the run. Guess: fine today; a deliberate `-timeout` in the gate (a gate change, with its self-check) would remove the risk.

## 7. Options

| Option | What it takes | Effect |
| --- | --- | --- |
| **A. Repair first, then CI (recommended)** | A small writer tranche in ES fixes 5.1, 5.2, 5.3 and 5.5 (test changes, and for 5.1 a bring-up script or test-input change), each aligned with current documented behaviour and not weaker; fresh audit. Then this thread (or a new one) lands section 6 with one new entry (5.4). | 36 of the 37 run in CI and must pass; one is an honest entry; no misclassified line. Two tranches. |
| B. CI now, failures listed | Section 6 now, with 5.1, 5.2, 5.3 and 5.5 added as entries that "fail for a known code reason". | Faster, and the still-failing step would force each line out once fixed. But it changes the list's contract (host reasons only, held by `docs_contract_test.go:967`), hides four known-broken tests behind an expected failure with nothing forcing the fix, and needs a coordinator decision. Not recommended. |
| C. Leave as is | Nothing. | The 37 keep skipping; four broken tests stay unnoticed on `trunk_dev`. |

A self-hosted runner is **not** needed: the GitHub-hosted runner runs all of this.

Independent of CI: 5.1, 5.2, 5.3 and 5.5 are broken tests (or a broken script) on `trunk_dev` today. They went unnoticed because they skip wherever `nomad` or `vault` is missing. That is worth fixing whatever is decided about CI.

## 8. Assumptions, guesses, unknowns

- **Unknown:** the Nomad and Vault versions Remote Alpha runs. Checking `nomad version` and `vault version` on the box (`ssh [test box name withheld]` from David's Mac) before freezing section 6 would align CI with it. The repo pins neither.
- **Unknown:** whether 5.5 passes once its proof directory moves outside the tree (it never got that far).
- **Inference:** the mechanism of the metadata fix (section 4.2).
- **Guess:** the 10-minute default timeout stays sufficient (section 6.4).
- Flakiness: three runner passes of the 32 (two targeted, one whole package) all passed with the fix. Three passes is a small sample.
- Not checked: macOS (not in scope); the gate itself with these tests (I did not change the gate or the list).

## 9. Artifacts, hygiene and widening

- **Probe branch** `claude/project-thread-a9tcoa-probe` on evo-agi/Execution-Substrate: commits `aae25c1` and `4a5ecc3` on `aaef28f`, adding only `.github/workflows/probe-nomad-vault.yml`, which triggers on pushes to that branch alone. It is not for review or merge. Deleting the branch needs David's go; leaving it is harmless (it never runs unless pushed to).
- **No push** to PR #14's branch or any other branch; local branch `claude/project-thread-a9tcoa` has no commits.
- **Container:** a dockerd, a user `ci`, `/opt/go1.26.5`, `/opt/hc/bin` and test copies under `/home/ci`, all in the thread's disposable container; nothing on David's Mac or the Linux box.
- **Authority/security widening:** none made. Section 6 would add three binaries and three images to the CI job, all pinned by hash, and one environment variable; it adds no secret and no permission (`contents: read` stays).
- **Sensitive material:** none read or copied. The runner logs in the evidence folder are public run logs of a public repository; the checkout token appears only masked (`***`).

## 10. Evidence (`/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/01-evidence/`)

SHA-256 of each file is in `01-evidence/SHA256SUMS.txt`.

- `runner-probe1-run-45050766307-job-137295151368.log`: the whole log of probe run 1 (the metadata failures).
- `runner-probe2-run-45052342848-job-137300032004.log`: probe run 2 (two passes, bring-up logs, whole package).
- `probe-workflow-aae25c1.yml.txt`, `probe-workflow-4a5ecc3.yml.txt`: the two probe workflows.
- `container-37-tests.log` (+ `.sh.txt`), `container-es-app-whole-package.log` (+ `.sh.txt`), `container-env.sh.txt`: the container runs (structured service log lines removed with `grep -v '"event":"'`).
- `container-stage-root-names.txt`: the diagnosis of 5.2.
- `binary-hash-provenance.txt`: signature and hash checks of section 6.2.

## 11. Confidence

- Feasibility facts (what passes and fails on the runner, and why): **high** — same results in the container and in three runner passes, with root causes traced to cited lines.
- That section 6 is complete: **medium** — validated in a probe workflow, not yet through the gate, the self-check and the docs contract.
- Implementation: none performed.

STATUS: WAITING (on the coordinator's choice among the options in section 7; nothing needed from David)
