# 30: Audit of ES PR #24 (CI installs Nomad, Vault and SPIRE), head de1d88d

Written by the independent audit thread "Audit bring-up running as the operator", 2026-11-23, 12:12Z to 12:30Z.
Read-only. Nothing was pushed, commented, reviewed, merged or changed on GitHub.

Target: draft PR #24 at `de1d88d`, on trunk_dev `ea86a96`. The writer's report is `29-ci-nomad-pr24.md`, the version with section 6, sha256 `3998e191…3f89`. This is not a red-team target, because the change is CI-only.

Evidence: `30-audit-pr24-evidence/`. Its README and `SHA256SUMS.txt` list every file.

## 1. Verdict: ACCEPT

There are no findings. There are two observations and two pre-existing notes, and none of them blocks the merge.

**What the PR does.** The CI job now installs Nomad 2.1.1, Vault 2.2.2 and SPIRE 1.14.4, and it pulls the three test images by digest. As a result, the `es/app` tests that used to skip themselves now run on the runner.

**The pins hold.**
- Every pinned release hash matches upstream:
  - Nomad and Vault match HashiCorp's signed `SHA256SUMS`. I checked the signatures myself against HashiCorp's key and cross-checked that key on a public keyserver.
  - SPIRE matches its release's checksum file. That file is unsigned and comes from the same place as the tarball (O30-1).
- Every pinned image digest is the index that Docker Hub serves. Each tag resolved to its pin when I checked.
- Every download is checked before anything uses it. A wrong hash ends the step before anything is extracted, and I reproduced that.
- No test pulls an unpinned image on CI:
  - the control-plane build uses the locally tagged, pinned bases, which I proved by a probe on Docker 29.10;
  - Nomad does not force a pull;
  - the only explicit pull in the tests happens only when the image is absent.

**The workflow's permissions are minimal.**
- The token can only read contents, and the job log confirms it.
- The triggers are `pull_request` and `push` to trunk_dev, with no `pull_request_target`.
- No secrets are used.
- Both actions are pinned to full SHAs, and checkout does not keep its credentials.

**The four items of the writer's section 4 hold.**
- The witness entry is an operator-input reason, not a code failure. On CI the test fails only at the envelope check, after every capability check has passed.
- `AWS_EC2_METADATA_DISABLED` reaches nothing in the module. It reaches only Nomad.
- `WORKFLOW_SHA256` equals the file's hash.
- The docs contract pins the new download lines, the hash check and the AWS line. It also holds the whole workflow by that hash. My six workflow mutants were all caught.

**Gate.**
- Manifest `8d02ddfc…d2ab` against base `ea86a96`. I took it at the start and at the end, and it is byte-identical to the writer's. trunk_dev is still `ea86a96`.
- CI run 45167471727 is green:
  - 36 of the 37 tests whose skip lines this PR removes ran and passed;
  - the 37th, the witness test, is now an entry, and it still fails;
  - all 16 entries still fail.

**One correction to report 29 (wording only).** Report 29 says "the 37 tests ran and passed", but 36 did. The witness test, the 37th, is skipped in "Test" as an entry and fails in "Listed tests still fail". The code and the list are right; only the sentence is off. `removed-skip-lines.txt` lists all 37.

## 2. Gate data

| Item | Result |
| --- | --- |
| Recipe `/opt/audit/v2.py` | sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every manifest run |
| Head | `de1d88d30dd8d8db0a6b4d4e1339366bf64bfbfa`, one commit on `ea86a96` (author date 2026-11-22 18:42Z). `refs/pull/24/head` is the same commit |
| Base | `ea86a963eba7588eaa57d31454beba8362f722a5`, which was `refs/heads/trunk_dev` at the start (12:12:14Z) and at the end (12:24:12Z) |
| Upstream | re-pinned to `origin/trunk_dev` |
| Opening manifest (12:12Z) | `8d02ddfcf6ad459756f118780528e139d9da1cbb2c83a65d1e68f0e581a4d2ab`, 5 files, textual diff `2e70e78513e15b382ad1bf597d994312645f4d7e71a082aa22a18cae9d0d4b33`. Taken twice; the two runs are byte-identical to each other and to the writer's `manifest-de1d88d/m1.json` |
| Closing manifest (12:24Z) | The same value again, twice, byte-identical to the opening runs |
| Writer's report | `29-ci-nomad-pr24.md` sha256 `3998e191b4bc9fc5ff886ff07d214115478d95a622f2e45ed9e79cbfa2ad3f89`, as the coordinator stated |
| Writer's evidence | `SHA256SUMS.txt` checks out (11 files). My `git diff ea86a96 de1d88d` and `git range-diff` are byte-identical to the writer's |
| CI on de1d88d | "build, vet and test", run 45167471727, job 137668045377: success, 11:41:43Z to 12:10:03Z. It is the only check run, and there are no legacy statuses |
| Kind of change | CI config and docs only: `go.yml` (+44), `environment-only-tests.txt` (37 lines out, 1 entry in), `go_test_gate_selftest.py` (the `WORKFLOW_SHA256` value), `go_toolchain_baseline.md` (two paragraphs) and `docs_contract_test.go` (+10 pinned strings). No product code and no scripts |

## 3. The writer's section 4, item by item

### 3.1 Pinned release hashes (`release-verification.log`)

| Pin | Upstream source | Result |
| --- | --- | --- |
| Nomad 2.1.1 `073084f7…3f39` | `nomad_2.1.1_SHA256SUMS`, signed 2026-10-29 | `gpg` reports "Good signature" (VALIDSIG, subkey `374E C75B 4859 1360 4A83 1CC7 C820 C6D5 CD27 AB87`, primary `C874 011F 0AB4 0511 0D02 1055 3436 5D94 72D7 468F`). The signed line equals the pin, and my download matches it |
| Vault 2.2.2 `5700edf1…d3c4` | `vault_2.2.2_SHA256SUMS`, signed 2026-11-11 | Good signature from the same key. The signed line equals the pin, and my download matches it |
| SPIRE 1.14.4 musl `4482db43…cbf5` | the release's `spire-1.14.4-linux-amd64-musl_sha256sum.txt` | Equals the pin, and the tarball matches it. A copy I downloaded on 2026-11-22 is identical. No `.sig`, `.pem` or `.bundle` asset exists (404 for each; the real assets return 200) (O30-1) |

- **The key:** it came from `https://www.hashicorp.com/.well-known/pgp-key.txt`, and keyserver.ubuntu.com serves the same fingerprints.
- **Archive contents:** the Nomad zip holds only `LICENSE.txt` and `nomad`, and the Vault zip holds only `LICENSE.txt` and `vault`. The workflow extracts only the named binary.
- **CI log:** it shows `Nomad v2.1.1` (revision `d0f21042…`) and `Vault v2.2.2 (c56e7e67…)`, each built on the same day the matching sums were signed.
- **Not run here:** I did not run the downloaded binaries. The versions come from the CI log only.

### 3.2 Pinned image digests (`registry-digests.txt`, `registry-manifests/`)

| Pin | By digest | By tag | Content |
| --- | --- | --- | --- |
| `alpine` `d9e853e8…b6bc` → `3.20` | OCI index, body hashes to the pin | `3.20` → the pin (12:14Z) | `/etc/alpine-release` 3.20.10 (seen earlier in this audit; not in the evidence) |
| `python` `9ef1a599…960e` → `3.13-alpine` | OCI index, body hashes to the pin | `3.13-alpine` → the pin (12:14Z) | `PYTHON_VERSION=3.13.18` |
| `golang` `0178a641…5fb2` → `1.26.5-alpine3.24` | OCI index, body hashes to the pin | `1.26.5-alpine3.24` → the pin (12:18Z; 12:14Z hit the rate limit) | `GOLANG_VERSION=1.26.5` |

These are the only images the tests run on CI:
- The tests name `alpine:3.20` (39 references), `python:3.13-alpine` (13) and `golang:1.26.5-alpine3.24` (5).
- The values `alpine:other` and `alpine:other-tag` are plan values in unit tests, and nothing pulls them.
- The control-plane Dockerfile uses `golang:1.26.5-alpine3.24` and `alpine:3.20` by tag. `scripts/internal/control_plane.sh:145` builds it with no `--pull`. My probe (`local-tag-precedence.txt`) shows that this Docker uses a local image whose tag matches and does not ask the registry. Inference: the runner's Docker does the same.
- The repository sets no `force_pull` anywhere, so Nomad's Docker driver uses the local images.
- The storage-check test pulls `alpine:3.20` only when it is absent, and on CI it is present.
- The normal-shell runtime image (`node:22-bookworm-slim`) is built only by the supported-local setup script, and the setup test replaces Docker with a fake. So CI never builds it (P30-2).

### 3.3 The witness entry is a host or operator-input reason

What the test does:
- `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` first runs `requireMountedSourceNativeCapabilities`. That checks the Docker socket, the boot ID, a healthy Docker-backed Nomad client and the SPIRE socket mount probe.
- It then runs `requireMountedSourceWitnessEnvelope`. That calls `t.Fatal("mount witness: source envelope is incomplete")` unless the operator supplies the four `ES_MOUNT_WITNESS_*` values from a governed source checkout.
- The design doc says so directly (`capability_probing.md`): "Missing envelope values alone do not justify a skip."

What CI shows:
- The test fails at `submit_integration_test.go:1069`, the envelope line, both in the package run and alone.
- Run alone, it took 5.72 s, because the capability probe ran and passed first. In the package run it took 0.00 s, because the probe result was cached.
- So the failure is the missing operator input, reported through `t.Fatal`, which is the only kind of failure the list allows. It is not a code failure.

Why the entry is acceptable:
- The portable sibling `…LifecycleStillWorks` and the other 35 tests now run in the gate and pass.
- Inventing envelope values would make the evidence false, as the list's own comment says.

### 3.4 `AWS_EC2_METADATA_DISABLED` (`aws-metadata-reach-de1d88d.log`)

- **Nothing in the module reads it.** A grep over the whole de1d88d tree finds it only in the workflow, the baseline doc and the docs contract.
- **The module has no AWS dependency.** `go.mod` and `go.sum` have no AWS entry. `go list -deps -test ./...` shows no AWS package, for Linux or for darwin/arm64.
- **It does reach Nomad.** The variable is set at job level. `startNomadHarness` runs `nomad agent -dev` with no `cmd.Env`, so Nomad inherits it.
- **The stated reason is consistent but not reproduced.** The job log shows the runner is on AWS (`Cloud: AWS`, us-west-2), which fits the comment. I did not reproduce the claim that Nomad's `env_aws` fingerprinter fails the client without the variable, because that needs running the downloaded Nomad. That claim rests on report 01.
- **Either way it is safe.** Turning off the instance-metadata lookup only reduces what the job can reach.

### 3.5 Workflow hash and docs contract (`local-checks-…log`, `mutants30-…log`)

Hash and local runs:
- The sha256 of `go.yml` at de1d88d is `739ffc0c…acfc`, and it equals `WORKFLOW_SHA256`.
- Run locally as user `ci` (1500:1600), the gate selftest passes 121 tests (197.6 s). CI also ran 121 tests, OK.
- The root package's docs tests pass (111). That includes `TestGo1265ToolchainBaselineDocsAndBuildContract`.

What the docs contract pins:
- the four new baseline-doc sentences;
- `AWS_EC2_METADATA_DISABLED: "true"`;
- the three `fetch` lines with their hashes;
- the `sha256sum --check --strict` line;
- `run: nomad version && vault version`.

It also checks the whole workflow against `WORKFLOW_SHA256` (`docs_contract_test.go:1036`).

Mutants on copies of the tree. The docs contract and the selftest class `WorkflowKeepsWhatTheGateDependsOn` ran on each copy:

| Mutant | Docs contract | Selftest | Result |
| --- | --- | --- | --- |
| M00 unmutated | pass | pass | passes |
| M01 `--strict` dropped | fails (pinned line) | fails (hash) | caught |
| M02 Nomad pin changed | fails (pinned line) | fails (hash) | caught |
| M02h M02 plus `WORKFLOW_SHA256` updated | fails (pinned line) | pass | caught |
| M03 alpine digest changed | fails (hash) | fails (hash) | caught |
| M03h M03 plus `WORKFLOW_SHA256` updated | pass | pass | passes, by design (O30-2) |
| M04 AWS line removed | fails (pinned line) | fails (hash) | caught |
| M05 images pulled by tag | fails (hash) | fails (hash) | caught |
| M05h M05 plus `WORKFLOW_SHA256` updated | pass | pass | passes, by design (O30-2) |
| M06 hash checked after extraction | fails (pinned line) | fails (hash) | caught |

## 4. Supply chain

**Sources.**
- `releases.hashicorp.com`, the `spiffe/spire` GitHub release, and Docker Hub `library/` images. All are fetched over HTTPS with `curl --fail --location --retry 3`.
- Redirects do not matter, because integrity rests on the pinned hash.

**Verification before use.**
- `fetch` runs `sha256sum --check --strict` right after each download, inside `set -euo pipefail` on `bash -e`.
- `fetch-fail-closed.log` runs the function verbatim. With a wrong hash it exits 1 before the next line. With the right hash it continues.
- The workflow unzips only after all three checks pass, and it extracts only the named binaries into `$RUNNER_TEMP/tools/bin`. That directory is added to `PATH` only for later steps.
- The SPIRE tarball is not extracted by the workflow. It reaches `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` through `SUPPORTED_LOCAL_TEST_SPIRE_TARBALL`, which the test passes on as `SUPPORTED_LOCAL_PREBUILT_SPIRE_TARBALL`. So the setup script installs the checked file and does not download its own. Inference from code: every hop passes the environment on (`go_test_gate.py:416-420`, then the test's `os.Environ()`). A passing test prints nothing, so the log cannot show this.
- Images are pulled by digest and then tagged, and nothing pulls the tags again (3.2).

**Permissions and tokens.**
- `permissions: contents: read`. The log shows `Contents: read`, `Metadata: read`.
- No `secrets.` reference and no `id-token`.
- The triggers are `pull_request` and `push` to trunk_dev.
- Checkout uses `persist-credentials: false`. checkout and setup-go are pinned to full commit SHAs.

**Exposure.**
- The downloaded tools run with the job's rights on an ephemeral runner. That job has a read-only token and no secrets.
- So a tampered tool could at worst falsify this job's own result.
- Releases signed by HashiCorp and digests chosen in review make that unlikely. SPIRE is weaker (O30-1).

## 5. Observations and pre-existing notes

**O30-1 (Low, informational): SPIRE's pin rests on an unsigned, same-origin checksum.**
- The v1.14.4 release publishes no signature for the tarball or its checksum file.
- So the pin proves that every later download is the bytes that were reviewed. It cannot prove that the release was genuine when it was pinned.
- The workflow comment says this plainly ("the unsigned checksum file of its GitHub release").
- Two downloads a day apart agree.
- Guess: a stronger anchor would be SPIRE's signed container images. Those are a different artifact, so using them would be a design change, not a fix to this PR.

**O30-2 (informational): image digests are held only by the whole-file hash.**
- The digests are held twice, by the selftest and by the docs contract, but neither pins them as text.
- An intended edit that also updates `WORKFLOW_SHA256` passes (M03h, M05h).
- That is the design: the hash forces whoever changes a digest to put the whole workflow in front of a reviewer.
- No action is needed.

**P30-1 (pre-existing, outside the diff).** `scripts/72_supported_local_setup.sh:431-438` downloads the SPIRE tarball without checking any hash when `SUPPORTED_LOCAL_PREBUILT_SPIRE_TARBALL` is unset, and then extracts and runs it.
- PR #24 avoids that path on CI.
- A developer who runs the setup test, or an operator who runs setup, still gets an unchecked download.
- Recommendation: a separate change should pin the same SHA-256 in the script.

**P30-2 (pre-existing, outside the diff).** Outside CI, the control-plane bases resolve by tag.
- The normal-shell Dockerfile uses `node:22-bookworm-slim` by tag and installs the npm package at `CODEX_NPM_VERSION=latest`.
- CI never builds that image.

**Report 29 wording.** Report 29 says "the 37 tests ran and passed", but 36 did (see section 1).

**Section 6 of report 29.** I checked only the facts, not whether to delete:
- The three branch heads match `git ls-remote` at 12:24Z: `claude/project-thread-a9tcoa-ci` is `61f1d9d`, and `claude/project-thread-a9tcoa-bringup-probe` is `f1c626e`. `claude/project-thread-a9tcoa-probe` is absent.
- `61f1d9d`'s change is fully in PR #24 (range-diff).
- `f1c626e` is `be71f84` plus probe workflow commits, superseded by PR #19's squash.

## 6. What I did not run

- **The downloaded binaries:** I did not run Nomad, Vault or SPIRE. The versions come from the CI log, and the integrity rests on hashes and signatures.
- **The full `es/app` suite:** I did not run it with Nomad, Vault and SPIRE in this container. The CI run is the evidence that the 36 tests pass on the runner.
- **macOS:** no run, because the workflow runs on Linux only.
- **The fingerprinter claim:** I did not reproduce the failure without `AWS_EC2_METADATA_DISABLED`.
- **The runner's Docker:** I did not check its local-tag behaviour on the runner itself (Inference in 3.2). My probe used Docker 29.10 in this container.
- **The SPIRE asset listing:** the release page's asset list was refused by this container's proxy, so the absence of signatures rests on the 404 probes, with a 200 positive control.

## 7. Evidence

Listed in `30-audit-pr24-evidence/README.md`. No key, certificate body, token or config file is included. The `.sig` files are HashiCorp's public detached signatures, and the registry manifests are public metadata.

A pattern scan found nothing. It covered:
- private-key headers and certificates;
- Vault, JWT, GitHub, Anthropic and AWS token shapes;
- personal names, mail and phone shapes;
- model names.
