# PR #24: run the es/app integration tests with Nomad, Vault and SPIRE on CI

Report 29 of the CI Nomad/Vault track. It opens the CI change that report 01 proposed and that waited for the test repair (#17) and for PR #19. Date: 2026-11-23. Repository: `evo-agi/Execution-Substrate`, draft [PR #24](https://github.com/evo-agi/Execution-Substrate/pull/24). Evidence: `29-ci-nomad-pr24-evidence/` next to this file, with `SHA256SUMS.txt`.

## 1. Outcome

| Item | Result |
| --- | --- |
| Change | CI config, the Go baseline doc and its docs contract only. The workflow installs Nomad 2.1.1, Vault 2.2.2 and SPIRE 1.14.4 from hash-checked downloads, pulls the three test images by digest, and sets `AWS_EC2_METADATA_DISABLED=true`. The 37 `es/app` `skips-itself` lines go; the installed-source witness becomes one entry. |
| CI on the runner | [Run 45167471727](https://github.com/evo-agi/Execution-Substrate/actions/runs/45167471727) is **green** on `de1d88d` (11:41Z to 12:10Z). The step "Test" took 16 min and passes only if no test skips without a line, so the 37 tests ran and passed. The step "Listed tests still fail" took 8 min and passes only if every entry, including the new witness entry, still fails. |
| Head and base | `de1d88d30dd8d8db0a6b4d4e1339366bf64bfbfa` on trunk_dev `ea86a963eba7588eaa57d31454beba8362f722a5` (after #19). |
| Manifest | **`8d02ddfcf6ad459756f118780528e139d9da1cbb2c83a65d1e68f0e581a4d2ab`** (v2, against `ea86a96`, 5 files, textual diff `2e70e785…4b33`), taken twice in a fresh clone, byte-identical. |
| Review | Not needed from David (CI config and docs only). Needs an audit, then the gate, then a squash merge. |

## 2. How the branch was made

`61f1d9d` was written on PR #14's branch (`claude/project-thread-a9tcoa-ci`), which still carries #14's commits from before its squash. Merging trunk_dev into that branch would have mixed those with their squashed copy, so the new branch `claude/project-thread-a9tcoa-ci-nomad` starts at trunk_dev `ea86a96`, and `61f1d9d` is cherry-picked onto it (`-x`).

Two conflicts, both resolved by keeping both sides:

- `.github/workflows/go.yml`: trunk_dev had added the "Install bindfs" step (#20) where `61f1d9d` added its steps. The port keeps the bindfs step and puts the three new steps after it, unchanged.
- `.github/ci/go_test_gate_selftest.py`: `WORKFLOW_SHA256` is the SHA-256 of the combined workflow, `739ffc0c…acfc`.

`range-diff-61f1d9d-de1d88d.txt` shows that the port differs from `61f1d9d` only in the commit message, in diff context (the bindfs step and a moved hunk header), and in `WORKFLOW_SHA256`. The environment list on trunk_dev still had exactly the 37 lines that `61f1d9d` removes; no later PR added a Nomad- or Vault-dependent skip.

## 3. Validation

- **CI (the real check):** run 45167471727, green; every step passed, including "Install Nomad, Vault and SPIRE" (each `sha256sum --check --strict` passed) and "Pull test images by digest".
- **Locally, in the cloud container, on the port before commit:** `go_test_gate_selftest.py` OK (3 min 12 s; `gate-selftest-local-de1d88d.txt`). The root package's docs and contract tests pass, apart from `TestRemoteAlphaVaultServiceUserMigrationApplyRepresentsPostApplyContractFailureHonestly`. That test fails the same way here on trunk_dev's own tree (this container runs as root) and passes on the runner.
- **Feasibility,** from report 01: on a probe workflow, 32 of the 37 passed twice in a row and once in a whole-package run (run 45052342848). The other 5 failed for code reasons; #17 repaired four, and the fifth is the witness entry.

## 4. For the audit

- The pinned values: the three release SHA-256s (report 01 checked the HashiCorp ones against HashiCorp's signed `SHA256SUMS` and the SPIRE one against its release's checksum file), and the three image digests.
- That the witness entry is a host reason (an operator-supplied source-identity envelope), not a code failure listed as a host failure. The list's contract allows only host reasons.
- That `AWS_EC2_METADATA_DISABLED` reaches nothing in this module (report 01, section 4.2).
- That the gate still holds the workflow as a whole (`WORKFLOW_SHA256`), and that the docs contract pins the new download lines.

## 5. Not run

No macOS run (the workflow is Linux only). The Nomad, Vault and SPIRE that the tests start on the runner are throwaway test instances, not a Remote Alpha or supported-local proof.
