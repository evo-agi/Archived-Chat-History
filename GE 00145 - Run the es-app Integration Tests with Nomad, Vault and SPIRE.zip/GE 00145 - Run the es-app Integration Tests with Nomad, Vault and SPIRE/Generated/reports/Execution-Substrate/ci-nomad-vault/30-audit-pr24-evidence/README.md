# 30-audit-pr24 evidence (ES PR #24, head de1d88d)

Written by the independent audit thread "Audit bring-up running as the operator", 2026-11-23, 12:12Z to 12:30Z.
Every file here was produced in the audit's cloud container or fetched read-only. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../30-audit-pr24.md`.

## Setup

- Repository clone `/opt/audit/es`. Manifests use the v2 recipe `/opt/audit/v2.py` (sha256 `c08597e2…a3ca`, checked before each run) on branch `claude/project-thread-a9tcoa-ci-nomad` at `de1d88d`, reset to base `ea86a96`, upstream re-pinned to `origin/trunk_dev`.
- Local test runs: a tree from `git archive de1d88d` at `/home/ci/es30`, run as user `ci` (1500:1600) with `env -i` and Go 1.26.5 (`GOTOOLCHAIN=local`). Mutants ran on copies of that tree.
- Downloads went to their own directory and were only hashed, signature-checked and listed. No downloaded binary was executed.

## Files

| File | What |
| --- | --- |
| manifest-v2-open-de1d88d-run1.json, -run2.json, manifest-v2-close-de1d88d-run1.json, -run2.json | Base-pinned manifests taken at 12:12:14Z and 12:24:13Z: `8d02ddfc…d2ab` all four times, byte-identical to the writer's `m1.json` |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start and the end (branch de1d88d, trunk_dev ea86a96 both times) |
| delta-ea86a96-de1d88d.diff | `git diff ea86a96 de1d88d`, byte-identical to the writer's patch |
| writer-provenance-check.txt | sha256 of the writer's report (3998e191…3f89), its `SHA256SUMS.txt` check (11 files), manifest and diff comparisons, the range-diff comparison, and the head commit |
| ci-run-45167471727.txt | The check runs on de1d88d and an annotated reading of the job log |
| ci-job-137668045377.log | The whole job log of that run, as the GitHub API returned it |
| removed-skip-lines.txt | The 37 removed `skips-itself` lines and what happened to each on CI (36 ran and passed; the witness is now an entry) |
| releases30.sh.txt, release-verification.log | Offline re-check of the HashiCorp signatures and key fingerprints, the pins against the signed sums and the SPIRE checksum file, and archive listings |
| nomad_2.1.1_SHA256SUMS(.sig), vault_2.2.2_SHA256SUMS(.sig), spire-1.14.4-linux-amd64-musl_sha256sum.txt | The upstream sums files and HashiCorp's detached signatures, as downloaded |
| spire-release-assets.txt | HTTP probes for SPIRE signature assets (404) with a positive control (200) |
| registry30.sh.txt, registry-digests.txt, registry-manifests/ | Docker Hub manifest checks by digest and by tag (two runs; 429 rows are the rate limit), and the manifest bodies, which hash to the pins |
| local-tag-precedence.txt | Probe: `docker build` without `--pull` uses a local image whose tag matches FROM |
| local30.sh.txt, local-checks-de1d88d-uid1500-gid1600.log | Workflow hash vs `WORKFLOW_SHA256`, the root package's docs tests (111 pass), the gate selftest (121 OK) |
| mutants30.py.txt, mutants30-uid1500-gid1600.log | Ten workflow mutants against the docs contract and the selftest's workflow class |
| failclosed30.sh.txt, fetch-fail-closed.log | The workflow's `fetch` function, verbatim, with a right and a wrong hash |
| aws30.sh.txt, aws-metadata-reach-de1d88d.log | Grep and `go list -deps` for anything that reads the EC2 metadata variable or uses an AWS SDK |

## Sensitive material

The tests and fixtures are synthetic. No key, certificate body, token or config file is copied here.
The `.sig` files are public detached signatures and the registry manifests are public metadata.
A pattern scan for private-key headers, certificates, Vault, JWT, GitHub, Anthropic and AWS token shapes,
personal names, mail and phone shapes, and model names found nothing.
