# REPAIR REPORT: PR #26, audit 20's findings A20-1, A20-2 and O20-1

Writer: the PR #13 thread. Date: 2026-11-23. Source: `reports/Execution-Substrate/pr12-current-admission/20-audit-pr26.md` (SHA-256 `63c15bc039836925e6c109f78644ba6bb079ebeda80ae14eee551fae0fe25466`), verdict ACCEPT with two low findings and one observation. The coordinator asked for the auditor's tested proposal for A20-1 and A20-2, and for O20-1 to be fixed in this PR with a test, since it is the same guard family and test-only. The previous report is `01-repair.md`.

## 1. In plain words

- **A20-1 and A20-2: the auditor's proposal, applied unchanged.** The `PolicyDecision` exception now allows an identifier only when the parser resolves it to the real top-level object: the type `AdmissionPolicyDecision`, or one of its two constructors. A local, a parameter, a label, a method on another type or a field with one of those names is now refused. Twelve refused cases are added. They also hold that the file comes from the guard's own path, not a `//line` directive, and that the other forbidden words stay refused. The auditor's probes P03 to P07 are now refused, and all 22 of the auditor's mutants are caught.
- **O20-1: wider than the one-line diff, because the gap was wider.** The DTO guards ask a helper, `collectJSONFieldNames`, which JSON keys a public type has. The auditor found it skipped an embedded unexported struct, whose fields `encoding/json` still promotes. Writing a test that checks the helper against `encoding/json` itself showed four more ways a key gets past it:
  - an **untagged field**, or an embedded exported non-struct type: `encoding/json` keys it by its Go name, the helper recorded nothing;
  - **case**: decoding matches keys without regard to case, Unicode folding included, so a field tagged `"HOLD"` or left untagged as `Review` accepts `"hold"` or `"review"`, which the guards forbid, while the helper recorded only `HOLD` or nothing;
  - an **invalid tag name** such as `"appro'val"`: `encoding/json` falls back to the Go name `Approval`, the helper recorded the tag;
  - a **map's values**: the helper did not look inside them.
  
  Seven probes on the real `PrepareRequest`, one per shape and one for O20-1 itself, each put a forbidden key into ES's public request with every guard passing; the auditor's one-line diff closes only the O20-1 probe (section 4.4). The helper now follows `encoding/json`'s own rules and records each key also in the form decoding matches it.
- **One file, test code only.** `es/admission/workstream_a_guardrails_test.go`, +242/−14 against `0aba38e`. No production code, document, stored format or public contract changes.
- **On the real tree** the stricter helper finds no forbidden key: every DTO guard passes, the package gives 0 changed results, and the only new keys it records are three untagged fields that no guard forbids (section 4.5).

## 2. Target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Branch | `claude/project-thread-ne9cwa` |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` (PR #25), unchanged since the re-gate |
| Previous head (audited by audit 20) | `0aba38e28e9f529fad44b810a00c8d35446552d4`, tree `e2efd07c7c0311cbab16d36a556a655ae8db3368` |
| New commit | `c99a1b46d4d8df2a63f97a13b5e437e3957f1ea9`, tree `59b90dce49969c177beec27f20b7f9c5101074b8`, parent `0aba38e` (fast-forward) |
| Pull request | #26 (https://github.com/evo-agi/Execution-Substrate/pull/26) (draft) |

## 3. The change

### 3.1 A20-1 and A20-2

`object-level-allow-proposal.diff` (SHA-256 `6edfc123295e50f45a147a3d94151f5787a5c6579cf8bef9fb459ca54d409cef`), applied with `patch -p1` to `0aba38e`, unchanged. Audit 20 section 9 describes it:

- `workstreamAAdmissionPolicyDecisionNames` becomes `workstreamAAdmissionPolicyDecisionObjects`, a map from name to `ast.ObjKind` (`ast.Typ` for the type, `ast.Fun` for the constructors).
- The `PolicyDecision` case allows an identifier only when `identifier.Obj` is the file-scope object of that name and of that kind, in `es/admission/policy.go`.
- Twelve refused cases: a shadowing local, a parameter, a field, a method and a label with a seam name; a package variable with a constructor's name (the kind check); the seam type and the field each under a `//line` directive that names the allowed file (M18); another forbidden identifier and another forbidden string (M21); a second name on the field (M16); and the field in a function-local struct (M17).

**Limits, as the auditor wrote them.** `go/parser` resolves names within one file only; a use of the seam type from another file is unresolved, and is refused anyway because only `policy.go` is allowed. A composite-literal key spelled like the type can resolve to the type, but its field would have to be declared somewhere, and that declaration is refused. `ast.Object` is marked deprecated in favour of `go/types`; `go vet` does not flag it, and CI runs vet. A `go/types` version through the repository's typed loader would work too, at a much larger size. I took the auditor's choice: it closes A20-1 exactly, and the tests pin the behaviour, so a later move to `go/types` is caught if it changes anything.

### 3.2 O20-1: the JSON key helper

`collectJSONFieldNamesFromType` serves the eight DTO guards of `es/admission` (Workstream A, B and C, and the producer contract). It now asks a new function, `workstreamAJSONFieldKey`, what key a field has, using `encoding/json`'s own rules (Go 1.26.5 `typeFields` and `isValidTag`):

- an unexported field has no key, unless it embeds a struct or a pointer to one;
- a field tagged `"-"` has no key; a field tagged `"-,"` is keyed `-`;
- a tag name that `isValidTag` refuses is ignored, as `encoding/json` ignores it (`workstreamAValidJSONTagName`);
- an embedded struct, or pointer to one, without a valid tag name has no key of its own: its fields are promoted, **whether its type is exported or not** (O20-1);
- every other field is keyed by its valid tag name, or else by its Go name.

Two more changes:

- The helper follows map values as it already followed pointers, slices and arrays.
- Each key is also recorded in its **folded form** (`workstreamAJSONKeyFold`): `encoding/json` matches an object key to a field's key without regard to case, Unicode simple folding included, so the long s `ſ` (U+017F) matches `s` and the Kelvin sign matches `k`. The folded form is the lower case of the smallest rune of each rune's folding orbit, so every spelling that decoding would match folds to the same lower-case string, and the guards' lower-case names find it. Decoding does not ignore underscores or hyphens, so the fold does not either.

The new test `TestWorkstreamAJSONFieldNamesFollowEncodingJSON` has twelve cases, one per field shape. Each checks the exact set of keys the helper records, and then checks with `encoding/json` itself that every key it writes for that value is recorded. Two more checks decode `{"review":true}` into an untagged `Review` field and `{"policy_decisions":1}` into a field tagged with the long s, so the test fails if `encoding/json` ever stops matching them, and the folding could then be revisited.

## 4. Validation

Linux (linux/amd64 container), Go 1.26.5, user `ci`, emptied environment, fresh copies of the commit. Logs: `02-repair-evidence/`.

### 4.1 The auditor's probes

The auditor's `probes20.py` (31 cases, P00 to P30), on the commit (`probes/probes20-fix.log`): **all as predicted, 0 unexpected**.

- P03 to P07 (A20-1) are now refused, each at its line and word.
- P29, `signedRuntimeTrustResponse` embedded in `PrepareRequest` (O20-1): the word guard still passes, as the auditor predicted, and the DTO guard now refuses it: `ES admission public DTOs must not expose upstream or CP-owned grammar field "publication"`.
- P00, P19, P24 and P28 pass, as on `0aba38e`; every other probe is refused, as on `0aba38e`.

### 4.2 Mutants

- **The auditor's mutants** (`mutants20.py`, `mutants/mutants20.log`): the control passes, and **22 of 22 are caught**: M07 to M21, which include the four survivors M16, M17, M18 and M21 of audit 20, and F01 to F07 on the new rule.
- **The helper's mutants** (`mutants/mutants26b.py.txt`, `mutants/m26b.log`), each in a fresh copy, against the `TestWorkstreamA` tests (51 results, all pass unmutated): **15 of 15 caught**.

| Mutant | Change | Caught by (cases of the new test) |
| --- | --- | --- |
| J01 | the old skip of every field with an unexported type | 3: the embedded struct, pointer and tagged struct |
| J02 | the auditor's one-line rule only: no key for an untagged field | 3: untagged, invalid tag, embedded non-struct |
| J03 | no folded key | 5 |
| J04 | fold by `unicode.ToLower` only | the long s |
| J05 | the smallest rune of the orbit, not lower-cased | 9 |
| J06 | tag names not validated | invalid tag |
| J07 | map values not followed | map value |
| J08 | a field tagged `"-"` keyed `-` | tagged `-` |
| J09 | unexported fields encoded | unexported field |
| J10 | an embedded unexported non-struct encoded | unexported field |
| J11 | an embedded struct with a tag name promoted instead of nested | tagged embedded struct |
| J12 | an embedded pointer not followed to its struct | embedded pointer |
| J13 | promoted fields not read | 2: the embedded struct and pointer |
| J14 | a keyed field's nested values not read | 2: tagged embedded struct, map value |
| J15 | only the folded key recorded | 5 |

### 4.3 Failing first: the new test against the old helper and the one-line diff

The new test, run with `0aba38e`'s helper put back, and with `0aba38e`'s helper plus the auditor's `dto-embedded-proposal.diff` (`helper/ff.log`, made by `helper/ff26b.py.txt`):

| Case | `0aba38e`'s helper | with the one-line diff | the commit |
| --- | --- | --- | --- |
| an embedded unexported struct promotes its fields | fails: records `id` only | passes | passes |
| an embedded pointer to an unexported struct | fails: records nothing | passes | passes |
| an embedded struct with a tag name is nested under it | fails: nothing | passes | passes |
| an untagged field is keyed by its Go name | fails: nothing | **fails**: nothing | passes |
| a key in another case (`"HOLD"`) | fails: `HOLD` only | **fails** | passes |
| a key whose rune folds to ASCII (long s) | fails | **fails** | passes |
| an invalid tag name leaves the Go name | fails: records `appro'val` | **fails** | passes |
| an embedded exported non-struct is keyed by its type name | fails: nothing | **fails** | passes |
| a map value's fields | fails: `extra` only | **fails** | passes |
| a field tagged `-` has no key | passes | passes | passes |
| a field tagged `-,` is keyed `-` | fails: nothing | **fails** | passes |
| an unexported field and an embedded unexported non-struct have no key | passes | passes | passes |

### 4.4 Each gap on the real tree

Each probe adds one field to the real `PrepareRequest` (`es/admission/types.go`), plus a probe test that decodes a JSON body with a key the Workstream A DTO guard forbids and checks that `encoding/json` accepted it. Then it runs the DTO guard, the word guard and the probe test, on three trees: `0aba38e`; `0aba38e` with the auditor's one-line diff; and the commit (`helper/dto.log`, made by `helper/dto26b.py.txt`).

| Probe | Field added | Body accepted | DTO guard on `0aba38e` | with the one-line diff | on the commit |
| --- | --- | --- | --- | --- | --- |
| R0 | none (control) | | pass | pass | pass |
| R1 | `Review bool` (untagged) | `{"review":true}` | **pass** | **pass** | refused |
| R2 | ``Hold bool `json:"HOLD"` `` | `{"hold":true}` | **pass** | **pass** | refused |
| R3 | ``Approval bool `json:"appro'val"` `` | `{"approval":true}` | **pass** | **pass** | refused |
| R4 | embedded unexported `zzProbeExtra{Checkpoint}` | `{"checkpoint":"c"}` | **pass** | refused | refused |
| R5 | ``Extra map[string]zzProbeEntry `json:"extra"` ``, entry with `resume` | `{"extra":{"a":{"resume":"r"}}}` | **pass** | **pass** | refused |
| R6 | embedded exported `Reject` (a string type) | `{"reject":"x"}` | **pass** | **pass** | refused |
| R7 | ``Decisions int `json:"policy_deciſions"` `` (long s) | `{"policy_decisions":1}` | **pass** | **pass** | refused |

Each refusal names the forbidden key: `review`, `hold`, `approval`, `checkpoint`, `resume`, `reject` and `policy_decisions`.

In every probe the word guard passes on all three trees, and `encoding/json` accepted the forbidden key into `PrepareRequest`. So on `0aba38e` all seven reach ES's public request with every guard passing, and the one-line diff closes R4 only.

### 4.5 The real tree

- The keys the helper records for each of the eight DTO guards, at `0aba38e` and at the commit (`helper/keys-summary.txt`): the same for seven guards. For `TestWorkstreamCLifecycleProjectionAuthorityLabelsStayNomadReadModelOnly`, the commit also records `MediaType`, `OutcomeEvidence` and `Payload` with their folded forms. They are the untagged fields of `ExecutionLogsResult` and `ExecutionResultBundle`. No guard forbids them, and the guard passes. Whether `es/api` writes those two types as JSON does not matter here: the guard asks the helper about them, and the helper now answers as `encoding/json` would.
- `es/admission`, whole package: `0aba38e` 1,116 pass, 12 skip; the commit 1,141 pass, 12 skip. 1,128 shared results, **0 changed, none gone**; the 25 new results are the two tests' new cases (13 and 12), all pass (`runs/compare-0aba38e-c99a1b4.txt`).
- `go build ./...` and `go vet ./...` with `CGO_ENABLED=0` for linux/amd64, linux/arm64 and darwin/arm64: clean. `gofmt -l es/admission`: clean. Race detector on the `TestWorkstreamA` tests: pass.
- The 21 occurrences that the guard allows on the real tree are the same 21 as on `0aba38e` (`runs/allowed-occurrences-c99a1b4.txt`).

### 4.6 With PR #12

A trial merge of the commit into PR #28's head `2c8bf35` (PR #12 with `trunk_dev` `036d507`, the tree that is to become PR #12's head) (`pr12-trial/`):

- The same two conflict blocks as before, and nothing else: one per occurrence literal in `workstream_a_guardrails_test.go`. Keeping PR #12's `source:` line and adding this PR's `node:` and `syntax:` lines resolves them (`pr12-trial/trial28p-cc.diff`). The PR #12 merge plan's step 1 stays as written.
- On the merged tree (`e984f09`, tree `302ca160…`, local, never pushed): `go build ./...`, `go vet ./...` and `gofmt -l es/admission` are clean. `es/admission`, whole package: 2,505 pass, 13 skip, 0 fail. Against the same package at `2c8bf35` (2,463 pass, 13 skip): none gone, none changed, and the 42 new results pass (29 of the allow-rule test, 13 of the JSON test). The red-team test's random round names are compared by round number.
- The `//line` refused cases pass under PR #12's real positions too, as the auditor designed them.
- Trunk-relative paths of the merged tree: the same 56 as `2c8bf35`. The file is already one of PR #12's paths, so this PR adds none.

## 5. Provenance manifest

Trunk-relative, recipe `governed-execution.audit-patch-manifest.v2` (SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before each run), taken after the push by `scripts/prov71.sh.txt` on a clean worktree at the commit; written twice, byte-identical; the staged path equals the manifest's and `git write-tree` gives the commit's tree. Afterwards: head at the commit, status empty, upstream restored. Files: `manifests/`.

| Base | Upstream pinned to | Files | Manifest SHA-256 | Textual diff SHA-256 |
| --- | --- | --- | --- | --- |
| merge base `036d507` (head `0aba38e`), audited by audit 20 | `origin/trunk_dev` | 1 | `3c7c3e1aacdee39c951b1ff2c8c187db66245482bfb546b7ca4ba96f9e959c25` | `68c11ec0e4aae15f62fa973e8ed6a1092c07f821184df8f75e7292486c29e372` |
| **merge base `036d507` (head `c99a1b4`), current** | `origin/trunk_dev` | 1 | `a36f06efca041626b8a908ddc95d37f1c5a8a19685d7ecfd7a02d0be33679b30` | `5bdb7466c6b21a632f8abc7ab60b91e2625cf9ce0bc5c3776f0b3a0ceb07be77` |

The delta for the re-audit is `git diff 0aba38e c99a1b4`: the one file, +242/−14.

## 6. Not claimed

- CI on `c99a1b4`: "build, vet and test" passed (run 45212809103, 16:07:01Z to 16:43:09Z).
- Nothing ran on macOS.
- The helper follows `encoding/json` as of Go 1.26.5. It does not cover a type's own `MarshalJSON` or `UnmarshalJSON`, `encoding/json/v2` (not used in the repository), or a key that only a custom decoder accepts.
- The word guard still judges words by substring and does not see concatenation or an alias (audit 20, O20-2).

## 7. Effects

- Pushed: `claude/project-thread-ne9cwa`, fast-forward `0aba38e..c99a1b4`. No other branch, no force-push, no tag.
- PR #26's description updated; it stays a draft until the re-audit.
- The PR #12 trial merge, probe files and mutants stayed in scratch clones; copies are in the evidence as `.txt` or logs.
- No secret, key, environment file or SQLite state was read or written. A scan of the evidence found no key, token or personal address.

## 8. Evidence

`02-repair-evidence/` and `02-repair-evidence.tar.gz`, listed in `02-repair-evidence/SHA256SUMS`.
