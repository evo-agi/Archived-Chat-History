# REPAIR REPORT: PR #26, audit 22's findings A22-1, O22-1 and O22-2

Writer: the PR #13 thread. Date: 2026-11-23. Source: `reports/Execution-Substrate/pr12-current-admission/22-audit-pr26-repair.md` (SHA-256 `94d0ce576b40975322d56ff4db311001204336108048d8870d3abe32a6a7a5a0`), verdict ACCEPT with one low finding (A22-1) and observations O22-1 to O22-4. The coordinator asked for A22-1 and O22-1 to be fixed in this PR, with tests and no tracked follow-up. The previous report is `02-repair.md`.

## 1. In plain words

- **The guards ask two different questions. Each now has its own helper.**
  - "May a public request take this forbidden key?" needs every key that decoding might match, in any case. `collectJSONFieldNames` answers that. It now returns a set with a single method, `accepts`, which folds the name it is asked about.
  - "Does ES still write this required key?" needs the exact key in its exact place. The new `assertJSONKeyPathsWritten` fills a value of the response type and writes it with `json.Marshal`. It then requires each path exactly, for example `authority_handoff.codex_credential_location.vault_secret_path`.
- **A22-1 is closed.** A required key that changes case, or loses its tag, now fails. That covers the auditor's Q1 and Q2, and my S2 and S3 on real C5 keys.
- **O22-1 is closed.** `encoding/json` itself now decides which keys are written:
  - a required key dropped by a name clash now fails (Q6, S4);
  - so does a required key still written in one envelope but gone from another (S1, S5).
  
  Before, the four checks read one flat set of keys covering all their types at once.
- **O22-2 is closed.** A public DTO type with its own `MarshalJSON` or `UnmarshalJSON` is now refused (Q5, S6), because no reading of its fields can see the keys its code writes or reads. No such type exists today. Text methods are not refused, because they make `encoding/json` write a string and never keys.
- **Why not the auditor's tested diff.**
  - It fixes A22-1 with a `map[string]bool` that the presence checks read by value. The auditor named the risk: a presence check written as `_, ok` still compiles, and it silently brings A22-1 back. That diff also leaves O22-1 and O22-2 open.
  - With a set that can only be asked `accepts`, a wrong read does not compile, and the path check covers what no flat set can.
- **The change is test files only:** four files, +605/−83 against `c99a1b4`. No production code, document, stored format or public contract changes.
- **On the real tree:**
  - every guard passes;
  - no shared result changes;
  - the 104 required paths are exactly every place where ES writes one of the keys the old checks required, in the envelopes those checks name.

## 2. Target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Branch | `claude/project-thread-ne9cwa` |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` (PR #25), unchanged |
| Previous head (audited by audit 22) | `c99a1b46d4d8df2a63f97a13b5e437e3957f1ea9`, tree `59b90dce49969c177beec27f20b7f9c5101074b8` |
| New commit | `06ec54b81a0b2afe9512f061bb1fff28e22040c3`, tree `111e028a26297eed12a3f44251701f76f6ea205d`, parent `c99a1b4` (fast-forward), pushed 17:20Z |
| Pull request | #26 (https://github.com/evo-agi/Execution-Substrate/pull/26) (draft) |

## 3. The change

Files:

| File | Lines | What changed |
| --- | --- | --- |
| `es/admission/workstream_a_guardrails_test.go` | +519/−11 | helpers and new tests |
| `es/admission/workstream_c_guardrails_test.go` | +54/−45 | 5 forbidden checks use `accepts`; the C3, C4 and C5 presence checks become path checks |
| `es/admission/producercontract_test.go` | +31/−26 | 1 forbidden check uses `accepts`; the presence check becomes a path check |
| `es/admission/workstream_b_guardrails_test.go` | +1/−1 | 1 forbidden check uses `accepts` |

### 3.1 Forbidden keys: a set that can only be asked `accepts`

- **What it returns.** `collectJSONFieldNames` returns `workstreamAJSONDecodableKeys`. That is a struct around the key map, with one method:
  ```go
  func (decodable workstreamAJSONDecodableKeys) accepts(key string) bool {
  	_, ok := decodable.keys[workstreamAJSONKeyFold(key)]
  	return ok
  }
  ```
- **The walk itself is round 2's walk, unchanged.** It records keys by `encoding/json`'s naming rules, both as written and folded. It records too much on purpose: clashes are not resolved, and fields under a text method are kept. Recording too much is safe for a check that refuses.
- **The seven forbidden checks** now read `if fieldNames.accepts(forbidden)`.
- **The struct is the point.** `fieldNames[x]` no longer compiles, so nobody can write a presence check, or any other check, by indexing the decodable set. That closes the class behind A22-1, not just its four instances.
- **Folding moved into `accepts`.** It now folds the name it is asked about, so a guard name in any case finds a key. This matters only if a guard list ever holds a capital letter; none does today.

### 3.2 Required keys: what `encoding/json` writes, path by path

`assertJSONKeyPathsWritten(t, root, what, paths...)` reports each missing path with `t.Errorf`, as `expected <what> "<path>" to remain present in <type>'s JSON`. It works in four steps:

1. **Fill a value.** `workstreamAFillJSONValue` gives every field of a fresh value of `root`'s type something to write: the string `"x"`, the number 1, `true`, a pointer to a filled value, one element in each slice, every element of an array, one entry under the key `"*"` in a map with string keys, and `null` in a `json.RawMessage`. So `omitempty` fields are written too. Each struct type is filled once per branch, so siblings of one type are each filled, and a type that holds itself ends. These stay empty, because nothing written beneath them can be required:
   - interfaces;
   - maps whose keys are not strings;
   - an embedded pointer to an unexported struct type, which reflection cannot set and `encoding/json` cannot decode into.
2. **Write it twice.** `json.Marshal` writes the value through a pointer and once more by value. A path counts only if it is written both ways, because a method with a pointer receiver is used only through a pointer. The check therefore does not depend on how ES passes the value.
3. **Collect the paths.** The written JSON is decoded, and every object key is recorded by its path from the top:
   - keys are joined with `.`;
   - `[]` after a key stands for the elements of the array it holds;
   - `*` stands for a map entry.
4. **Compare exactly.** A key in another case, without its tag, moved into another object, or dropped by a name clash is missing.

So `encoding/json` itself decides tags, Go names, promotion, `-`, clashes (both dropped at one depth; shallower wins; tagged wins), nesting, and any `MarshalJSON` or `MarshalText`.

### 3.3 The pinned paths

Each presence check names its paths in the envelopes it already walked:

- `ProducerContractDeclaration` for the producer check (53 paths: the four surfaces share one loop);
- `SubmitResult` and `ExecutionStatusResult` for C3 (5 paths each) and C4 (11 each);
- `ExecutionStatusResult` and `ExecutionCancelResult` for C5 (10 each, plus 13 for the status envelope only).

**Coverage check (`runs/presence-pins-06ec54b.txt`, `runs/written-key-paths-06ec54b.txt`).**

- A test run logged every pinned (type, path) pair. Without repeats (C3, C4 and C5 share some), there are 104.
- Separately, I listed every path written today for the envelopes, and then every place where a key the old checks required is written in the envelopes those checks name: also 104.
- The two sets are equal. No written place of an old required key is left out, and no pin is added beyond them. Every pin is written today.

### 3.4 O22-2: types with their own codec

- **The rule.** `collectJSONFieldNames` calls `t.Fatalf`, naming the types, when any type it reaches has its own `MarshalJSON` or `UnmarshalJSON`. "Reaches" covers the type itself, through pointers, slices, arrays and map values, and through promotion from embedded types. Both receivers count.
- **Exception: `json.RawMessage`.** It carries a JSON value through as data and has no keys of its own, as a map or an `any` field does. Its field's own key is still recorded and judged.
- **Not refused: `encoding.TextMarshaler` and `TextUnmarshaler`.**
  - With `MarshalText`, `encoding/json` writes a string.
  - With `UnmarshalText`, it refuses to decode an object into the type (`UnmarshalTypeError`).
  
  So text methods can only take keys away. The forbidden set keeps their fields (too much, so safe). The presence check sees the string, because it reads what is written.
- **Today.** The auditor's walk of the 28 types found none of these methods, and the guards pass.
- **Known false positive.** A future public field of type `time.Time`, which has its own `MarshalJSON`, would be refused. It would then need an explicit exception next to `json.RawMessage`. This fails closed, with a message that names the type.

### 3.5 Tests

The helpers that the guards call take `testing.TB`. The guards still pass their `*testing.T`. This lets a test watch what the helpers report: `zzJSONGuardRecorder` embeds `testing.TB` and records `Errorf` and `Fatalf`. Its `Fatalf` ends the call with a panic that only `zzJSONGuardReports` recovers.

- **`TestWorkstreamAJSONKeyPathsAreWhatEncodingJSONWrites`**, 16 cases, each compared with what `encoding/json` writes:
  - a tag exactly as written;
  - an untagged field;
  - filled `omitempty` fields of five kinds;
  - nested objects, array elements and map entries;
  - `-`;
  - an embedded unexported struct;
  - two clash cases (built at run time with `reflect.StructOf`, because vet refuses a repeated tag in source);
  - a tagged field winning;
  - two fields of one type;
  - a type that holds itself;
  - a value-receiver `MarshalJSON`;
  - `json.RawMessage`;
  - a value-receiver `MarshalText`;
  - pointer-receiver `MarshalText` and `MarshalJSON`, where only the keys written both ways count.
  
  It then checks that only the exact key at the exact place counts, and that `assertJSONKeyPathsWritten` reports exactly the two missing paths and nothing else.
- **`TestWorkstreamAJSONFieldNamesRefuseOwnCodecs`**, 6 cases:
  - a field type with `MarshalJSON`;
  - a pointer type with `UnmarshalJSON`;
  - in a slice and in a map value;
  - promoted from an embedded type;
  - `json.RawMessage` (not refused);
  - text methods (not refused).
  
  It then checks that `collectJSONFieldNames` itself fails on a type with its own codec, and does not fail on DTOs without one.
- **`TestWorkstreamAJSONFieldNamesFollowEncodingJSON`** (round 2) now asks `accepts` for each written key, in its own case and upper-cased. It also checks that the dotless ı (U+0131), which decoding does not fold to i, is not accepted as `publication`.

### 3.6 Why I did not apply `presence-exact-proposal.diff`

The auditor's diff (SHA-256 `e1220aa1…4c35`) fixes A22-1 exactly, and I checked it against my own probes. I did not take it, for three reasons:

1. **The trap stays open.** Its presence checks read `fieldNames[key]` by value, and its forbidden checks read `_, ok`. Both compile against one map, so the next presence check written with `_, ok` reopens A22-1. The auditor says so in section 8.3, and its K05 shows the reverse mistake also survives the suite. With `accepts` and `assertJSONKeyPathsWritten`, neither mistake compiles.
2. **O22-1 needs paths.** The coordinator asked for O22-1 to be fixed too. As the auditor wrote, a flat set cannot see a clash or a moved key. The auditor's untested sketch, decoding `{"<key>":null}` with `DisallowUnknownFields`, would cover clashes of top-level keys only.
3. **O22-2 costs one check.** It closes the road the auditor showed with Q5.

The auditor's mutants K01 to K04 target that diff's `true`/`false` values, which this code does not have. K05's mistake does not compile here.

## 4. Validation

All runs used Go 1.26.5 in an emptied environment, as user `ci` (uid 1500, gid 1600). Each probe and mutant ran in a fresh copy.

### 4.1 The auditor's probes21 (audit 22), with this commit as the tree "fix"

`probes/probes21-06ec54b.log`. The script is `probes21.py.txt` from audit 22's evidence, byte for byte. Its expectations for "fix" are those of the auditor's proposal.

| Probe | Change | Proposal (auditor) | This commit |
| --- | --- | --- | --- |
| Q0 | none | pass | pass |
| Q1 | `service` tagged `SERVICE` | producer fails | producer fails: `"service"` missing |
| Q2 | `Service` untagged | producer fails | producer fails |
| Q3 | `checKpoint` with the Kelvin sign | DTO guard fails | DTO guard fails |
| Q4 | `publıcation` with the dotless ı | pass | pass |
| Q5 | `PrepareRequest` with its own `UnmarshalJSON` | pass (O22-2) | **DTO guard fails**, and so does `TestWorkstreamAJSONFieldNamesRefuseOwnCodecs`, which uses `PrepareRequest` |
| Q6 | a second field tagged `service` | pass (O22-1) | **producer fails**: `"service"` missing |

The script counts "unexpected=2". These are Q5 and Q6, and both are the intended closures of O22-2 and O22-1.

### 4.2 Audit 20's probes and mutants

- `probes20.py` (P00 to P30) on this commit: all 31 as predicted, unexpected=0 (`probes/probes20-06ec54b.log`).
- `mutants20.py`: the control passes, and all 22 (M07 to M21, F01 to F07) are caught (`mutants/mutants20-06ec54b.log`).

The allow rule is untouched.

### 4.3 New real-tree probes

`probes/sprobes26c.log`, script `sprobes26c.py.txt`. Each probe edits `es/admission/types.go`. It runs the C3, C4, C5, producer and Workstream A DTO guards on three trees:

- `0aba38e` (before the JSON helper);
- `c99a1b4` (audited);
- this commit.

The two older trees are this commit with the four test files checked out at that head. Each probe also logs what `encoding/json` writes.

| Probe | Change in `types.go` | `0aba38e` | `c99a1b4` | `06ec54b` |
| --- | --- | --- | --- | --- |
| S0 | none | all pass | all pass | all pass |
| S1 | `ExecutionCancelResult`'s `outcome_evidence` tagged `evidence` (`ExecutionStatusResult` still writes it) | C5 passes | C5 passes | **C5 fails**: `outcome_evidence` and its 6 paths missing from the cancel result |
| S2 | `provider_terminal_observed` tagged `Provider_Terminal_Observed` | C5 fails | C5 passes (A22-1) | **C5 fails**, in both envelopes |
| S3 | `LifecycleProjection.Revision` untagged | C5 fails | C5 passes (A22-1) | **C5 fails**, at all 3 places |
| S4 | a second `ExecutionCancelResult` field tagged `status` | C5 passes | C5 passes (O22-1) | **C5 fails**: `status` missing |
| S5 | `ExecutionAuthorityEvidence`'s `codex_credential_location` tagged `codex_credential_ref` (the handoff still writes it) | C3, C4, C5 pass | C3, C4, C5 pass | **C3, C4 and C5 fail**: `authority_handoff.evidence.codex_credential_location` missing |
| S6 | `ExecutionCancelResult` gets a `MarshalJSON` that writes the same keys | all pass | all pass | **DTO guard, C3, C4 and C5 fail**, each naming `admission.ExecutionCancelResult` |

All 21 predictions held (unexpected=0).

### 4.4 The writer's DTO probes R0 to R7 (round 2)

On this commit (`dto/dto.log`):

- R0 passes.
- R1 to R7 are each refused by the DTO guard. That covers an untagged field, a tag in another case, an invalid tag name, an embedded unexported struct, a map value's field, an embedded non-struct, and a long-s fold.
- The probe test shows that `encoding/json` accepts each forbidden key.
- The word guard passes.

This matches round 2.

### 4.5 Mutants of this commit

`mutants/m26c.log`, script `mutants26c.py.txt`, run by `m26c.sh`. The selection is the Workstream A, Workstream B, producer and C2 to C5 guard tests. The whole package would run for any survivor; there were none. The control has 85 passing results.

- **J01 to J15:** round 2's mutants of the decodable-key walk. J07, J13 and J14 are adapted to the walk's new form. All 15 are caught.
- **N01 to N26:** mutants of the new code. All 26 are caught.

| Mutants | What they break | Caught by |
| --- | --- | --- |
| N01, N02, N16, N17 | path matching: last key alone, folded paths, no prefix, no `[]` | the paths test (N16 and N17 also by the real producer and C checks) |
| N03 to N07, N18, N23 to N25 | filling: none, slices, maps, pointers, per-branch, embedded unexported, strings, booleans, integers | the paths test, and for N03, N04, N06, N07 and N23 also the real producer or C checks |
| N08, N15 | the comparison and the report: any path suffices, nothing reported | the paths test (the recorder) |
| N09 | `accepts` does not fold its question | the field-names test |
| N10 to N14, N19 | the codec refusal: off, RawMessage refused, pointer receivers unseen, `UnmarshalJSON` unseen, no `Fatalf`, elements unchecked | the codec test (N14 through the recorder) |
| N20 to N22 | written through a pointer only, by value only, either way | the paths test |
| N26 | no end for a type that holds itself | stack overflow |

**What only probes catch.** Deleting or weakening a call site, for example dropping the cancel envelope from C5, survives the suite, as it would for any guard. Probes S1 to S6 show that the call sites hold.

### 4.6 The real tree

- **Build and vet.** `go build ./...` and `go vet ./...` pass for linux/amd64, linux/arm64 and darwin/arm64. `gofmt -l es/admission` is clean.
- **Race detector.** The selection above passes with `-race` (`runs/race.log`).
- **Whole package.** es/admission in full:
  - 1,165 pass and 12 skip, against 1,141 pass and 12 skip at `c99a1b4`;
  - 24 new results, all passing: 17 from the paths test and 7 from the codec test;
  - 0 results changed, none gone (`runs/compare-c99a1b4-06ec54b.txt`).
- **Allow rule.** The 21 allowed occurrences are identical to `c99a1b4`'s.

### 4.7 With PR #12

PR #12's head is `2c8bf35` (fast-forwarded at 16:40Z). Its CI run 45219219689 passed at 17:12Z.

- **Same use sites.** `2c8bf35` has the same use sites of the helpers as `trunk_dev`: 3, 3, 2 and 13 in the four files. It adds no other call to `collectJSONFieldNames` and no other `fieldNames[…]` read in es/admission. `es/config/config_test.go` has its own helper, `collectConfigStructFieldNames`, which is not touched.
- **Merge.** A trial merge of `06ec54b` into `2c8bf35` gives the same two conflict blocks in `workstream_a_guardrails_test.go`, and nothing else. They are resolved as before: keep PR #12's `source:` line and add `node:` and `syntax:` (`pr12-trial/trial26c-cc.diff`).
- **Changed lines.** `workstream_c_guardrails_test.go` merges cleanly. Its changed lines in the merge are exactly this commit's own.
- **Results on the merged tree.** Tree `4638579260b93b778560952fa1136ad696ea58c5`:
  - `go build ./...` and `go vet ./...` pass, and gofmt is clean;
  - es/admission in full: 2,529 pass, 13 skip and 0 fail. That is against 2,505 pass and 13 skip for the round-2 trial (`2c8bf35` with `c99a1b4`), with the random SIGKILL rounds compared by round number. The 24 new results all pass, and none changed or went away.
  - The auditor's probes21 on the merged tree (`probes/probes21-trial.log`) give the same results as on this commit: Q1, Q2, Q3, Q5 and Q6 are refused, and Q0 and Q4 pass.
  - My S0 to S6 on the merged tree (`probes/sprobes26c-trial.log`, where the tree label `r3` is the merged tree) also give the same results as on this commit.
- **For whoever merges PR #26 into PR #12, or adds a guard later.**
  - A new presence check must use `assertJSONKeyPathsWritten` with full paths.
  - A forbidden check must use `accepts`.
  - `fieldNames[…]` no longer compiles.

## 5. Provenance manifest

v2 recipe `governed_execution_audit_patch_manifest_v2.py` (SHA-256 `c08597e2…a1e3ca`, checked before each run). Run on a clean worktree at the pushed tip, reset to the merge base with the upstream pinned to `origin/trunk_dev`, twice:

- manifest SHA-256 `98c25abf39ac818fa88def0744f33cdd86d131c57a86f535d088af1c2b32b55f`, 4 files;
- textual diff SHA-256 `89c6c9b971b505293fad4733db9515784b452144410473c7633dc9e790df46f3`;
- both runs byte-identical; the staged tree equals the tip tree `111e028a…`; afterwards the worktree is clean, at the tip, with its upstream restored (`manifests/`).

## 6. Not claimed

- A narrow re-audit of this commit is still to come.
- Nothing ran on macOS.
- **What the presence check covers.** It sees what `json.Marshal` writes for a filled value. A key written only for some values, for example by a `MarshalJSON` that branches on content, is judged by the filled value. Public types with their own `MarshalJSON` are refused anyway.
- **What it does not cover.** It does not check how ES's own handlers write a response. They use these types.
- **The forbidden set** follows `encoding/json`'s naming rules as of Go 1.26.5, and records too much on purpose (section 3.1).
- **A future `time.Time` field** in a public DTO would be refused, and would need an explicit exception (section 3.4).
- **Seen, outside this PR.** `es/config`'s `collectConfigStructFieldNames`, on `trunk_dev` and PR #12, checks only the top-level Go field names of one struct, for forbidden and required names alike. It is a Go-field guard, not a JSON one, and no audit raised it. I have passed it to the coordinator rather than widen this PR.
- I wrote both the code and its tests.

## 7. Effects

Test code only, in four files. CI for the new head: run 45226582061 ("build, vet and test") ran from 17:20Z to 17:48Z and ended in success.

## 8. Evidence

`03-repair-evidence/`, with `SHA256SUMS` over every file:

- `commit-06ec54b.txt` and `delta-c99a1b4-06ec54b.diff`;
- `runs/`: build, vet, gofmt and race logs; es/admission results at both heads and their comparison; the 21 occurrences; the written key paths; the 104 pins;
- `probes/`: probes20, probes21 and sprobes26c with their scripts, and the last two again on the PR #12 trial merge;
- `dto/`: R0 to R7;
- `mutants/`: mutants20 and m26c, with their scripts;
- `manifests/`: both manifest runs and their checks;
- `pr12-trial/`: the merge, its resolution, build, vet, gofmt, es/admission results, and the PR #28-trial results it is compared with;
- `scripts/`: `val26c.sh`, `prov71.sh`, `ev26c.sh` and the runners.

70 files, sealed as `03-repair-evidence.tar.gz` beside it. The leak scan (private keys, tokens, API keys, the requester's e-mail) found nothing. The probes and fixtures are synthetic.
