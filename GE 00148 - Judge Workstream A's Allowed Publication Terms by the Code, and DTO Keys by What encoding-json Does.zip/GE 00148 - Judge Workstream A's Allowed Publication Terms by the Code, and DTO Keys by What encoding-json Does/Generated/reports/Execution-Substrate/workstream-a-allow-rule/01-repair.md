# REPAIR REPORT: O7-1, Workstream A's publication allow rule reads the code, not the line

Writer: the PR #13 thread. Date: 2026-11-23. Source: observation O7-1 of `reports/Execution-Substrate/pr12-current-admission/17-audit.md` (SHA-256 `413792a813e7c912072050e1a709e8e64e971dca82cbedf72abdbdcea3d846f3`), which found it pre-existing and outside PR #12. The coordinator asked for it as its own small PR from `trunk_dev`. I wrote both the code and its tests.

## 1. In plain words

- **The finding, measured, and a second case of it.** The guard `TestWorkstreamAESImplementationDoesNotExposeAGSPublicationGrammar` keeps AGS publication words out of ES's own code. It had two exceptions, and both were decided by the *text of the line*, comments included:
  - `PolicyDecision` was allowed in any file named `policy.go` whose line contained the text `AdmissionPolicyDecision`;
  - `Publication` was allowed in any file named `service.go` whose line contained `Publication`, `json.RawMessage` and `json:"publication,omitempty"`.
  So a comment could allow anything. On `trunk_dev`, five planted lines pass the guard: the auditor's `var zzProbePolicyDecision = 1 // AdmissionPolicyDecision`, an identifier that merely uses the seam type on its line, an identifier with the field's words in a comment, the same field added to a new public struct, and the seam type in a `policy.go` of another package (`es/app`).
- **The fix.** The allow rule now reads the syntax node that holds the word:
  - `PolicyDecision` only in three identifiers, `AdmissionPolicyDecision`, `AllowAdmissionPolicyDecision` and `DenyAdmissionPolicyDecision`, and only in `es/admission/policy.go`;
  - `Publication` and `publication` only in the name and the tag of one field, ``Publication json.RawMessage `json:"publication,omitempty"` ``, of the struct `signedRuntimeTrustResponse`, and only in `es/admission/service.go`.
  These are exactly the 21 occurrences that the old rule allowed on `trunk_dev`, and on PR #13's tip, listed before the change. All five probes now fail the guard.
- **One file, test code only.** `es/admission/workstream_a_guardrails_test.go`. No production code, document, stored format or public contract changes.
- **A new test** plants the allowed code and fourteen variants that must be refused; the old rule accepted ten of them. 13 mutants of the new rule are all caught.

## 2. Target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Branch | `claude/project-thread-ne9cwa`: the fix, then a merge of `trunk_dev` |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` (PR #25), taken up by a merge commit after PR #25 landed (section 4.4). The fix was written on `200fd60` and rebased onto `792f17c` (PR #22) before its first push. Neither PR #22 nor PR #25 touched a file of `es/admission`, and the changed file is byte-identical at all three bases |
| Fix commit | `bcfb6dad5546661d0587489f7214f783c030af19`, tree `e90a6001456925eba62f47f161214c0fb6e20dde` |
| Head | `0aba38e28e9f529fad44b810a00c8d35446552d4` (merge of `trunk_dev` `036d507`), tree `e2efd07c7c0311cbab16d36a556a655ae8db3368` |
| Pull request | #26 (https://github.com/evo-agi/Execution-Substrate/pull/26) (draft) |

## 3. The change

- `workstreamASourceOccurrence` carries the identifier or string literal that holds the word (`node`) and the parsed file (`syntax`). The text of the line stays only for the error message.
- `forbiddenWorkstreamASourceOccurrences` reads the file and calls the new `workstreamASourceOccurrencesOf(t, file, data, terms)`, so a test can hand it a source under any file name.
- `allowedWorkstreamAPublicationOccurrence` is rewritten as in section 1, with the list `workstreamAAdmissionPolicyDecisionNames` and the finder `workstreamAIgnoredRuntimeTrustPublicationField`, which checks the struct name, the field name, its type `json.RawMessage` and its exact tag.
- Files are matched by their exact path as the guard lists them (`policy.go`, `service.go` in `es/admission`), not by base name, so `../app/policy.go` and `../app/service.go` are no longer covered.
- New test `TestWorkstreamAPublicationAllowRuleJudgesTheCodeNotTheLine`: 2 allowed cases and 14 refused cases, each requiring the refusal at its exact line and word.

Positions: the guard still reads the line of each occurrence with `fileSet.Position`, as `trunk_dev` does today. It is used only in the message now. PR #12 changes those reads to real positions, and that is where the position-read rule arrives (section 6).

## 4. Validation

Linux (linux/amd64 container), Go 1.26.5, user `ci`, emptied environment, fresh clones of `792f17c` and of the commit. Logs: `01-repair-evidence/`.

### 4.1 Failing first

| Probe, planted in a copy | `trunk_dev` `792f17c` | The commit |
| --- | --- | --- |
| P0 none | guard passes | guard passes |
| P1 `var zzProbePolicyDecision = 1 // AdmissionPolicyDecision` in `policy.go` (the auditor's) | **passes** | fails: `policy.go:330 must not contain "PolicyDecision"` |
| P2 ``var zzPublicationProbe json.RawMessage // `json:"publication,omitempty"` `` in `service.go` | **passes** | fails at `service.go:993` |
| P3 the same field in a new struct `ZZProbeRequest` in `service.go` | **passes** | fails at `service.go:994` |
| P4 `type AdmissionPolicyDecision struct{...}` in a new `es/app/policy.go` | **passes** | fails at `../app/policy.go:3` |
| P5 `var zzPolicyDecision AdmissionPolicyDecision` in `policy.go` | **passes** | fails at `policy.go:330` |

Every probe builds (`go build ./es/admission/ ./es/app/`), so each refusal comes from the guard (`probes/`).

### 4.2 Mutants

13 mutants (`mutants/mutants71.py.txt`, `mutants/m71.log`), each in a fresh copy of the commit, against the `TestWorkstreamA` tests (26 results, all pass unmutated). **13 of 13 caught.**

| Mutant | Change | Caught by |
| --- | --- | --- |
| M1 | the old rule, verbatim | 10 refused cases |
| M2 | `PolicyDecision` allowed in a `policy.go` of any directory | `the seam type in a policy.go of another package` |
| M3 | `PolicyDecision` allowed in every file | 2 refused cases |
| M4 | any identifier that contains `AdmissionPolicyDecision` | `an identifier that contains the seam type's name` |
| M5 | any identifier of `policy.go` | 3 refused cases |
| M6 | `publication` allowed in a `service.go` of any directory | `the field in a service.go of another package` |
| M7 | anything in `service.go` once the field exists | 4 refused cases |
| M8 | the field in any struct | `the field in another struct only` |
| M9 | the field of any type | `the field with another type` |
| M10 | the field's name not checked | `the tag in another field` |
| M11 | the field's tag not checked | `the field with another tag` |
| M12 | only the field's name allowed, not its tag | the real guard and an allowed case |
| M13 | occurrences carry no node | the real guard and both allowed cases |

A first run had three survivors (M4, M8, M11). Each got a refused case before the final run.

### 4.3 Package suite, build, vet

- `es/admission`, whole package: `792f17c` 1,099 pass, 12 skip; the commit 1,116 pass, 12 skip. 1,111 shared results, **0 changed**; the 17 new results are the new test and its subtests, all pass (`runs/admission-*.results.tsv`).
- `go build ./...` and `go vet ./...` with `CGO_ENABLED=0` for linux/amd64, linux/arm64 and darwin/arm64, at both commits: clean.
- `gofmt -l es/admission`: clean. Race detector on the `TestWorkstreamA` tests: pass.
- The list of occurrences the old rule allowed (`runs/allowed-occurrences-*.txt`, made by `runs/zz_o71_list_test.go.txt`) is the same 21 on `trunk_dev` and on PR #13's tip `e060449`, so PR #12 adds no occurrence that the new rule would refuse.

### 4.4 Re-gate on `trunk_dev` `036d507` (PR #25)

PR #25 landed after the first push. The branch took it by a merge commit, `0aba38e`; nothing was rebased or force-pushed. Its diff against `trunk_dev` is still the one file, and the textual diff hash is unchanged (section 5).

PR #25 changed documents, scripts and CI files, and added the test file `es/app/spire_release_pin_test.go`. The guard reads only the non-test Go files of `es/admission`, `es/api` and `es/app`, and PR #25 changed none of them.

Everything of 4.1 and 4.3 was run again, on fresh clones of `036d507` and `0aba38e` (`regate-036d507/`):

- Build and vet for the three targets, at both commits: clean. `gofmt`: clean. Race on the `TestWorkstreamA` tests: pass.
- `es/admission`, whole package: `036d507` 1,099 pass, 12 skip; `0aba38e` 1,116 pass, 12 skip; 0 changed results. On each side, the set of results is identical to that of the run at `792f17c`.
- Probes P0 to P5: the same outcomes, at the same lines and words, as in 4.1.
- The 21 occurrences the old rule allowed on `036d507` are the same 21 as before.
- The PR #12 trial merge, redone at `036d507`, is in section 6.

## 5. Provenance manifest

Trunk-relative, recipe `governed-execution.audit-patch-manifest.v2` (SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before each run), taken after the push by `scripts/prov71.sh.txt` on a clean worktree at the commit; written twice, byte-identical; the staged path equals the manifest's and `git write-tree` gives the commit's tree. Afterwards: head at the commit, status empty, upstream restored. Files: `manifests/`.

| Base | Upstream pinned to | Files | Manifest SHA-256 | Textual diff SHA-256 |
| --- | --- | --- | --- | --- |
| merge base `792f17c` (head `bcfb6da`) | `origin/trunk_dev` | 1 | `49ff0a0d5b24fe16493fc844fc9cba0464b0dc85893df32d0841f0d195a30c15` | `68c11ec0e4aae15f62fa973e8ed6a1092c07f821184df8f75e7292486c29e372` |
| **merge base `036d507` (head `0aba38e`), current** | `origin/trunk_dev` | 1 | `3c7c3e1aacdee39c951b1ff2c8c187db66245482bfb546b7ca4ba96f9e959c25` | `68c11ec0e4aae15f62fa973e8ed6a1092c07f821184df8f75e7292486c29e372` (unchanged) |

The second manifest was taken the same way after the merge was pushed: written twice, byte-identical; the staged paths equal the manifest's, and `git write-tree` gives the head's tree `e2efd07c…`. Afterwards: head at `0aba38e`, status empty, upstream restored. Files: `regate-036d507/manifests/`.

## 6. Interaction with PR #12

PR #12 (through PR #13) changes the same file's four position reads to `guardPosition(...)`. When PR #12 takes a `trunk_dev` that holds this commit, `workstream_a_guardrails_test.go` conflicts in two blocks, one per occurrence literal: keep PR #12's `source:` line and add this commit's `node:` and `syntax:` lines (`pr12-trial/trial-pr12-resolution-cc.diff`). On the trial merge of PR #13's tip with `trunk_dev` `792f17c` and this commit, PR #12's guards and this commit's test all pass (`18-trunk-dev-merge-plan.md`). No path is added to PR #12: the file is already one of its 53.

## 7. Not claimed

- No CI result yet: the PR's checks run on GitHub.
- Nothing ran on macOS.
- The guard still reads only the files of `es/admission`, `es/api` and `es/app`, and judges words by substring, as before; this change only narrows what its two exceptions allow.

## 8. Effects

- Pushed: the new branch `claude/project-thread-ne9cwa` (one commit), then a merge of `trunk_dev` `036d507` (fast-forward `bcfb6da..0aba38e`). No other branch, no force-push, no tag.
- Draft PR #26 (https://github.com/evo-agi/Execution-Substrate/pull/26) opened against `trunk_dev`.
- Probe files and mutants stayed in scratch clones; copies are in the evidence as `.txt` or logs.
- No secret, key, environment file or SQLite state was read or written. A scan of the evidence found no key, token or personal address.
