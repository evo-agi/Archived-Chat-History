# REPAIR REPORT: PR #26, audit 23's findings A23-1 and A23-2

Writer: the PR #13 thread. Date: 2026-11-23.

- **Source.** `reports/Execution-Substrate/pr12-current-admission/23-audit-pr26-repair2.md` (SHA-256 `22e7b3e5eb46d9e6caa856e7666b7eb583b9d7c25c70532ca6860c62ea07675a`).
- **Verdict.** It accepted `06ec54b` with two low findings, A23-1 and A23-2, and recommended fixing both in this PR with its tested diff.
- **Previous report.** `03-repair.md`.

## 1. In plain words

- **A23-1 is closed.** A key path joins keys with `.`, marks array elements with `[]` and names a map entry `*`. But `encoding/json` allows those characters in a tag name, so one path string could name two places. The auditor showed two cases where every guard passed although the required key had moved:
  - a top-level field tagged `"governed_execution.contract"`, standing in for `contract` inside `governed_execution` (T1);
  - the same trick for `runtime_profiles[].name` (T2).

  Now:
  - the filler puts its map entry under the empty key, which no struct field can have, and the paths name it `*`;
  - any other written key that holds `.`, `[`, `]` or `*` fails the test, with a message that names the key.

  T1 and T2 are refused.
- **A23-2 is closed.** The codec refusal already checked named map, slice and string types, but no test held that, so two weaker versions passed the suite. Codec cases now cover a named map, a named `[]byte` and a named string type, each with its own `MarshalJSON`. The two mutants the auditor found surviving (P01, P02) are now caught. So is my own N27, which checks only composite kinds.
- **The fix is the auditor's `key-path-unambiguous-proposal.diff`, applied unchanged**, plus the named string case, which N27 needs.
- **One file changed, test code only.** `es/admission/workstream_a_guardrails_test.go`, +72/−11 against `06ec54b`. No production code, document, stored format or public contract changes.
- **On the real tree** no key holds one of those characters, and every guard passes. The whole package gives 1,168 pass and 12 skip: the 1,165 results of `06ec54b` plus the three new codec cases. None changed and none is gone. The 104 presence pins and the 21 allowed occurrences of the word guard are the same as at `06ec54b`.
- **Observations O23-1 and O23-2: no change, as the auditor advised.** Section 3.3 gives my reasons.

## 2. Target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Branch | `claude/project-thread-ne9cwa` |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` (PR #25), unchanged |
| Previous head (audited by audit 23) | `06ec54b81a0b2afe9512f061bb1fff28e22040c3`, tree `111e028a26297eed12a3f44251701f76f6ea205d` |
| New commit | `a88467fafad9b033f637f7eddfc8de1033ab3d68`, tree `45b41a40bac412b67fcf7258836bb81a10edabde`, parent `06ec54b` (fast-forward), pushed 18:23Z |
| Pull request | #26 (https://github.com/evo-agi/Execution-Substrate/pull/26) (draft) |

## 3. The change

### 3.1 The auditor's diff

The diff (SHA-256 `7a1111851ec5ab750d2ad29b00ffc97a464118c65a6447e89f870c89d4096d8c`) applies with `patch -p1` to `06ec54b`, unchanged. Audit 23 section 8 describes it:

- **`workstreamAFillJSONValue`** sets a map's one entry under `""`. A struct field cannot have the empty key: an empty tag name falls back to the Go name.
- **`workstreamAJSONObjectKeyPaths`** names the empty key `*`, so every existing path, such as `labels.*`, stays as it was. Any other key that holds `.`, `[`, `]` or `*` is collected as ambiguous instead of becoming a path.
- **`workstreamAJSONWrittenKeyPaths`** fails with `encoding/json writes keys [...] for T, which a key path cannot name unambiguously` when any key is ambiguous.
- **New tests:**
  - the paths test refuses three keys: a top-level `"governed_execution.contract"`, a `"runtime_profiles[].name"` and a `"*"`;
  - the codec test has a named map type and a named `[]byte` type, each with its own `MarshalJSON`.

### 3.2 One case more

`zzJSONOwnString`, a named string type with its own `MarshalJSON`, is a third codec case. Without it, a codec check narrowed to composite kinds (pointer, struct, map, slice, array) would pass the suite. That is my mutant N27, and the auditor's two cases do not catch it.

### 3.3 O23-1 and O23-2: no change

- **O23-1.** A public DTO field of type `any`, `map[string]any` or `json.RawMessage` carries any JSON through, and the guards cannot see inside it. None exists today. I left it, as the auditor advised:
  - The guards judge a DTO's field names, its own vocabulary. A data-carrying field is one such name, and the guards judge its key.
  - `map[string]string` fields such as `Env` and `Annotations` already carry arbitrary keys as data. Refusing `any` and `json.RawMessage` but not those maps would draw the line at nesting rather than at vocabulary.
  - Adding such a field to a public DTO is a visible design change. It would be reviewed and audited.
- **O23-2.** `fieldNames.keys[x]` still compiles inside the package, but only as a deliberate reach into an unexported field. The mistake that is easy to make, `fieldNames[x]`, no longer compiles.

## 4. Validation

Go 1.26.5, emptied environment, user `ci` (uid 1500, gid 1600); each probe and mutant in a fresh copy.

- **Build, vet, format, race.** `go build ./...` and `go vet ./...` are clean for linux/amd64, linux/arm64 and darwin/arm64, and `gofmt` is clean. The race detector passes on the guard tests.
- **Whole package.** es/admission gives 1,168 pass and 12 skip, against 1,165 and 12 at `06ec54b`.
  - The three new results are the codec subtests for the named map, the named `[]byte` and the named string type. All pass.
  - The three refused keys run inside the existing paths test, which passes.
  - No result changed, and none is gone.
- **Unchanged on the real tree.** The 104 presence pins are the same as at `06ec54b`, and so are the 21 allowed occurrences of the word guard.
- **Audit 23's probes (`probes26c.py`).** On `a88467f` and on its trial merge into PR #12, 0 results were unexpected:
  - T1 and T2 are refused;
  - T3 and T4 pass, as O23-1 describes;
  - T5, T6 and T7 are refused.
- **Audit 23's mutants.** P01 and P02 (`mutants26c.py`) are caught, and so are X01 to X04 (`mutants26c-fix.py`).
- **Audit 22's probes (`probes21.py`).**
  - Audit 23's copy of the script runs the new head as `fix26c`, and 0 results are unexpected.
  - Audit 22's copy gives 4 unexpected results, two per tree, on the head and on the trial merge. They are Q5 and Q6, now refused, as at `06ec54b`.
- **Audit 20.** Its 31 probes give the predicted results, and its 22 mutants are all caught.
- **My real-tree probes.** The six edits to `types.go` (S1 to S6) are still refused, on the head and on the trial merge. The script's label `r3` names its expectations for the current head. R1 to R7 are still refused.
- **My mutants.** All 42 are caught: round 3's 41, adapted where an anchor moved, and N27.
- **The diff is the auditor's.** `a88467f-vs-06ec54b-plus-proposal.diff` compares the commit with `06ec54b` plus the auditor's diff. The only difference is the named string case, 9 lines.

## 5. Provenance manifest

v2 recipe (SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`), trunk-relative, run twice on a clean tree at the pushed tip, byte-identical:

| Item | Value |
| --- | --- |
| Head | `a88467fafad9b033f637f7eddfc8de1033ab3d68`, tree `45b41a40bac412b67fcf7258836bb81a10edabde` |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` (merge base) |
| Manifest SHA-256 | `54afb5869bc8f2413248bf818f66df1e8ca296623a03b4a4c97cd5540c8f19ff`, 4 files |
| Textual diff SHA-256 | `b0bd54fa6955e1a716c85e94fb53a07907ad2ee83df64166d2ecabafa2b5c706` |
| Staged tree | `45b41a40bac412b67fcf7258836bb81a10edabde`, equal to the head's tree |

### PR #12 trial merge

- **Merge.** `a88467f` into PR #12's head `2c8bf35` gives `356317c`, tree `052d102465743ce673a34f3805100b29f2d142c5`.
- **Conflicts.** Only the same two blocks as before conflict, resolved the same way: keep PR #12's `source:` line and add this change's `node:` and `syntax:` lines.
- **Results.** Build, vet and gofmt are clean. es/admission gives 2,532 pass, 13 skip and 0 fail, against 2,529, 13 and 0 for round 3's trial.
  - The three new results are the new codec cases.
  - With the random SIGKILL timings taken out of the subtest names, none changed and none is gone.

## 6. Not claimed

- A narrow re-audit of this commit is still to come.
- Nothing ran on macOS.
- The limits in `03-repair.md` section 6 still stand:
  - the presence check judges what `json.Marshal` writes for a filled value, not ES's handlers;
  - a future public `time.Time` field would be refused and would need an explicit exception;
  - the forbidden set records too much on purpose.
- I wrote the named string case. The rest of the diff is the auditor's.

## 7. Effects

Test code only, one file. CI for the new head: run 45238013540, in progress when this was written.

## 8. Evidence

`04-repair-evidence/`, with `SHA256SUMS` over every file:

- the commit and its delta;
- run logs and es/admission results at both heads;
- the auditor's probes (audits 20, 22 and 23) and mutants (audits 20 and 23), with their scripts as copied from the audit evidence;
- my probes and mutants;
- the manifests;
- the PR #12 trial merge;
- the scripts.
