[PR 16](https://github.com/evo-agi/Execution-Substrate/pull/16) is merged into trunk_dev as f62d024. The lock-timing test is now stable, and the merged code matches the audited change. Its branch was deleted automatically.

STATUS: WORKING (PR 21 audit, PR 20 audit, PR 19 repair, PR 13 split, MA alert; nothing needed from you)
