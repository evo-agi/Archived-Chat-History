# BRANCH UPDATE RECORD: Execution-Substrate PR #16 (lock-contention test) merged with `trunk_dev` at `f9537a8`

**Outcome: the branch of PR #16 now contains today's `trunk_dev`, with the Linux CI of PR #14. The new head is `9ca4ae6d37128d1783ae83578ffbf0d2f9859049`. The merge had no conflict, the patch of the PR is byte for byte the audited one, and the first run on GitHub for this pull request is green.**

This record is the input for the merge gate (provenance document, section 5.4 step 2). The patch was reported in `05-repair.md` and audited in `06-reaudit.md` (ACCEPT for `0a069ec`, no finding). Its run on macOS is in `08-repair.md`, section 7.6. This record reports no change of content: the writer changed no file of the PR.

Written 2026-11-22, by the writer thread of PR #16. No subagents were used.

## 1. Identity

| Field | Value |
|---|---|
| Objective | Bring PR #16 onto the current `trunk_dev` after the audit, without changing the audited patch |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #16, draft |
| Base | `trunk_dev` at `f9537a8680c24bf2108b95ed20ac3724e8939d3a` (the squash of PR #14) |
| Topic branch | `claude/project-thread-k69qcw` |
| Audited commit | `0a069ecbe53c842d33c932f63aed2af523e2eb0c`, tree `0b327b54deb9b880a748851fc4248bf3e3531809`, base `ae326b0ddc30ec6b35883ee32945c622405b68b6` |
| New head | `9ca4ae6d37128d1783ae83578ffbf0d2f9859049`, a merge commit with the parents `0a069ec` and `f9537a8` |
| New tree | `287824e976ccc04c1f16c3d1b90c78626264bca8` |
| Manifest at the new base | SHA-256 `b275ecd4bc1723fd4627059ec856342c0cb45386f968b18dff383da0e1f25138`, 501 bytes, 1 file |
| Final working-tree status | clean; local branch equals `origin/claude/project-thread-k69qcw` |

## 2. What was done

1. `git merge --no-ff origin/trunk_dev` on the branch, at `0a069ec`. No rebase and no force-push, so the audited commit keeps its hash.
2. The merge had no conflict. It brought in 20 files from `trunk_dev` (PR #17, PR #18 and PR #14). None of them is the one file of this PR.
3. The merge commit was pushed as a fast-forward at 22:40:58 UTC.
4. The pull request description was updated: the run, the macOS result, the new head, base and identity.

## 3. The patch is unchanged

All of this is in `11-pr16-branch-update-evidence/fresh-clone.log` and `manifest-compare.txt`.

- `git diff ae326b0 0a069ec` and `git diff f9537a8 9ca4ae6` are the same bytes: SHA-256 `33ce64469079b65bbb06b13c98aa7c52ff690c40ea3ed03480481c1de9320d8c` for both.
- `git range-diff ae326b0..0a069ec f9537a8..9ca4ae6` shows the one commit as equal (`=`).
- `git merge-tree --write-tree 0a069ec f9537a8` gives the tree `287824e9…`, the tree of the new head. So the merge commit holds what git computes for this merge and nothing else.
- The new manifest has the same file record and the same `textual_diff_sha256` as the audited manifest `b14b8ac19ba92beb3a218df837cd8315ea959fc0544d57f170aa12fbe0c936a2`. Only the field `head` differs: `f9537a8` in place of `ae326b0`.

## 4. Provenance

- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each run.
- Taken in a fresh clone from GitHub: `origin/trunk_dev` checked to be `f9537a8`, pushed tip checked to be `9ca4ae6`, `git reset --mixed f9537a8`, upstream pinned to `origin/trunk_dev`, v2 run twice, both outputs identical (`fresh-clone.sh.txt`, `fresh-clone.log`).
- Textual diff SHA-256 `2504375ef8b14da68ac600b1870a049fbb1eb0ff1c03dd3d67fd8cba23c6d467`.
- Canonical manifest SHA-256 `b275ecd4bc1723fd4627059ec856342c0cb45386f968b18dff383da0e1f25138`, 1 file. Complete canonical manifest (also in the evidence folder as `manifest-head-f9537a8-tip-9ca4ae6.json`):

```json
{"branch":"claude/project-thread-k69qcw","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"es/admission/internal/reliablesubmit/sqlite_physical_test.go","sha256":"fbf8f64c9f152e06680ca84d558531bb0d63048abaf12a336babc7df75e8c400","size":15193}],"head":"f9537a8680c24bf2108b95ed20ac3724e8939d3a","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"2504375ef8b14da68ac600b1870a049fbb1eb0ff1c03dd3d67fd8cba23c6d467","upstream":"origin/trunk_dev"}
```

To reproduce it, follow section 5.3 of the provenance document with `TOPIC=claude/project-thread-k69qcw`, `TIP=9ca4ae6d37128d1783ae83578ffbf0d2f9859049` and `BASE=f9537a8680c24bf2108b95ed20ac3724e8939d3a`.

## 5. Validation

### 5.1 On GitHub

Run [45079080694](https://github.com/evo-agi/Execution-Substrate/actions/runs/45079080694), job 137382888906, `ubuntu-24.04`, Go 1.26.5, started 22:41:01 UTC, green in 12 m 57 s. It is the first run of the checks on this pull request. The runner checked out the merge of `9ca4ae6` into `f9537a8`, which has the tree of `9ca4ae6`. From the job log (`runner-run-45079080694-job-137382888906.log`):

| Step | Result |
|---|---|
| Build, Vet, Vet for macOS | success |
| Check the test gate | `Ran 121 tests in 113.713s`, `OK` |
| Test | `test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed` |
| Listed tests still fail | `all 15 listed tests still fail on this host, each in a run of its own and in the run of its package` |

The 15 lines `still fails: …` are the same as in run 45075800893 of PR #14. The log has no error or warning annotation.

The changed test, `TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention`, has no line in the list. The gate fails when a test fails, when a test that `go test -list` names reports no verdict, and when a test skips itself without a line. **Inference:** the test ran and passed on the runner. The log does not print the names of passing tests.

### 5.2 In the cloud container

User `ci`, emptied environment, Go 1.26.5, a scratch copy with the tree `287824e9…` (`container-validate.sh.txt`, `container-validate.log`).

| Command | Result |
|---|---|
| `gofmt -l` on the changed file | no output |
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./es/admission/...` | exit 0 each |
| `go test -count=20 -run '^TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention$' ./es/admission/internal/reliablesubmit` | ok |
| The whole package, without the two historical-opener probes that the list skips | ok in 27.7 s |

### 5.3 On macOS

Not run again at this head. The run of `0a069ec` on David's Mac passed on 2026-11-22 at 16:11 UTC (`08-repair.md`, section 7.6, steps e and f). The one file of the PR has the same bytes now.

## 6. Failed or skipped validation

- Nothing failed.
- Not run again: the stall runs (SIGSTOP), the kill test of the helper, and the race detector run of the audit. The file is unchanged, so those results in `05-repair.md` and `06-reaudit.md` still describe these bytes.
- Not run: anything on macOS at this head (5.3).

## 7. For the merge gate

- The head of the PR has to be `9ca4ae6d37128d1783ae83578ffbf0d2f9859049` at the merge.
- `trunk_dev` now requires the check `build, vet and test` and a branch that is up to date. If `trunk_dev` moves again before the merge, this update has to be repeated: merge, run, manifest.
- After the merge, `trunk_dev` should hold the bytes of the one manifest path above (SHA-256 `fbf8f64c…c400`, 15,193 bytes).
- PR #12 and PR #13 touch the same file at other lines (around line 130). They pick this change up when they next take `trunk_dev`.

## 8. Other envelope fields

- **Files touched:** none by the writer. The merge commit carries 20 files from `trunk_dev`.
- **Dependencies changed:** none.
- **Artifact hygiene:** no file was created in the repository. The scratch copy in the container and the fresh clone are outside it.
- **Authority, security or protocol widening:** none.
- **Cross-repo impact:** none.
- **Sensitive material:** none read or written. This record and its evidence files were scanned with the project's leak scanner before delivery: 0 findings.

## 9. Confidence

- **Provenance: 0.99.** The manifest was reproduced twice in a fresh clone and its file record equals the audited one.
- **Validation: 0.95.** One green run on the runner and the fast checks in the container, both on the tree of the new head.
- **Implementation: unchanged** from `06-reaudit.md`, because no byte of the patch changed.

## 10. Delivery and effect status

- This file: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/11-pr16-branch-update.md`. Its SHA-256 is in the reply that delivers it.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/11-pr16-branch-update-evidence/`, with a `README.md` and a `SHA256SUMS.txt`.
- Effect status: `TOPIC_BRANCH_PUSHED` | `DRAFT_PR_UPDATED` https://github.com/evo-agi/Execution-Substrate/pull/16 | `MERGE_NOT_PERFORMED` | audit ACCEPT at `0a069ec`; the merge commit `9ca4ae6` awaits the provenance re-check of the merge gate.
