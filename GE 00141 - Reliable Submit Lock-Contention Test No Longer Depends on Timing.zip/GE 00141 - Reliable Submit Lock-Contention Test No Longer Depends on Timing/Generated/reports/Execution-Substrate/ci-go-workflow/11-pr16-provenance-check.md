# PROVENANCE RE-CHECK for the merge gate: Execution-Substrate PR #16 (lock-contention test) at `9ca4ae6`

**Verdict: MERGE-READY** for head `9ca4ae6d37128d1783ae83578ffbf0d2f9859049` on `trunk_dev` at `f9537a8680c24bf2108b95ed20ac3724e8939d3a`
**Effect status:** REPAIR_NOT_PERFORMED · COMMIT_NOT_PERFORMED · PUSH_NOT_PERFORMED · PR_NOT_MODIFIED · NO_COMMENT_POSTED · MERGE_NOT_PERFORMED · read-only on the target throughout

This is the provenance-only re-check of provenance §5.4 step 2, which the coordinator asked for. It follows the branch update that `11-pr16-branch-update.md` records. The thread that wrote `10-provenance-check.md` for PR #14 did it, in the same way. It used no subagents. It is not an audit: I read no code again and ran no test. The audit of PR #16 is `06-reaudit.md` (ACCEPT for `0a069ec`, no finding), written by an earlier audit thread, and I did not repeat it.

All times are UTC on 2026-11-22.

## 1. Verdict in short

**MERGE-READY. All three questions have the answer yes.**

| Question | Answer | Where |
|---|---|---|
| Does the writer's manifest reproduce? | **Yes.** SHA-256 `b275ecd4bc1723fd4627059ec856342c0cb45386f968b18dff383da0e1f25138`, 501 bytes, 1 file, in a fresh clone, at opening and at closing, byte-identical to the writer's file | section 3 |
| Is the patch byte-identical to the audited PR #16 change? | **Yes.** `git diff ae326b0 0a069ec` and `git diff f9537a8 9ca4ae6` are the same 2,622 bytes. The one file has the same blob and mode at `0a069ec` and at `9ca4ae6`. The merge commit holds no edit of its own | section 4 |
| Is run 45079080694 green on that exact head? | **Yes.** Its head is `9ca4ae6`, it is the pull request's one check run, every step succeeded, and it tested a commit whose tree is the tree of `9ca4ae6` | section 5 |

The verdict holds only while two things stay as they are (section 6):

- the head of the pull request is `9ca4ae6d37128d1783ae83578ffbf0d2f9859049`, and
- `trunk_dev` is `f9537a8680c24bf2108b95ed20ac3724e8939d3a`.

If either moves before the merge, this check is void and has to be repeated.

## 2. Target and inputs

| Field | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #16, branch `claude/project-thread-k69qcw` into `trunk_dev`. At 22:58: open, **draft**, `mergeable_state` clean, 2 commits, 1 changed file, +24/−3, last updated 22:56:03 |
| Audited commit | `0a069ecbe53c842d33c932f63aed2af523e2eb0c`, tree `0b327b54deb9b880a748851fc4248bf3e3531809`, one commit on the base `ae326b0ddc30ec6b35883ee32945c622405b68b6`. ACCEPT in `06-reaudit.md` (SHA-256 at 22:58: `66ee63c405859cecc6142ae184e0c2435b62dd2857248a89c47e5d804c4b6f7c`) |
| Audited manifest | `b14b8ac19ba92beb3a218df837cd8315ea959fc0544d57f170aa12fbe0c936a2`: `06-reaudit-evidence/manifest-pr16-open.json` and `manifest-pr16-close.json`, byte-identical to each other |
| New head | `9ca4ae6d37128d1783ae83578ffbf0d2f9859049` (22:39:59), tree `287824e976ccc04c1f16c3d1b90c78626264bca8`. A merge commit: first parent `0a069ec`, second parent `f9537a8` |
| New base | `trunk_dev` at `f9537a8680c24bf2108b95ed20ac3724e8939d3a`, the squash of PR #14 (22:39:24). It moved three times from `ae326b0`: `b8d6bc3` (PR #17), `3a5f257` (PR #18), `f9537a8` (PR #14) |
| Writer's record | `11-pr16-branch-update.md`, SHA-256 `2862f139cb602413fc60682a5082b94e7862d4a793f77c0cc327fc3256e9ead3`, verified at 22:57:18. Its evidence folder: all 10 lines of `SHA256SUMS.txt` hold |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each of the four runs |

## 3. The manifest reproduces

No mismatch. I made a fresh clone from GitHub at 22:57:43 and followed provenance §5.3 with the values of the record (`manifest.sh.txt`).

- **The pushed tip is the reported tip.** At 22:57:45 and again at 22:58:58 the remote had the branch and `refs/pull/16/head` at `9ca4ae6`, and `trunk_dev` at `f9537a8`. `f9537a8` is an ancestor of the tip.
- **The checkout was clean,** with tree `287824e9…`, before `HEAD` was set to `f9537a8`.
- **Two runs at opening (22:57:46) and two at closing (22:58:58)** gave four byte-identical files: SHA-256 `b275ecd4bc1723fd4627059ec856342c0cb45386f968b18dff383da0e1f25138`, 501 bytes, 1 file, textual diff SHA-256 `2504375ef8b14da68ac600b1870a049fbb1eb0ff1c03dd3d67fd8cba23c6d467`.
- **They are byte-identical to the writer's file** `11-pr16-branch-update-evidence/manifest-head-f9537a8-tip-9ca4ae6.json` (`cmp`).
- **Against the audited manifest** `b14b8ac1…36a2`: the file record is the same (`es/admission/internal/reliablesubmit/sqlite_physical_test.go`, SHA-256 `fbf8f64c9f152e06680ca84d558531bb0d63048abaf12a336babc7df75e8c400`, 15,193 bytes, mode 0644), and so is the textual diff hash. Only the field `head` differs, `f9537a8` in place of `ae326b0`.

## 4. The patch is byte-identical to the audited one

All of this is in `patch-check.log`, made by `patch-check.sh.txt` in the fresh clone.

- **The two diffs are the same bytes.** `git diff ae326b0 0a069ec` and `git diff f9537a8 9ca4ae6`: 2,622 bytes each, SHA-256 `33ce64469079b65bbb06b13c98aa7c52ff690c40ea3ed03480481c1de9320d8c` for both, and `cmp` of the two outputs finds no difference. With `--full-index --binary` they are the same too. Both show 1 file, +24/−3, which is what GitHub shows for the pull request.
- **The one file has the same blob and the same mode (100644) at `0a069ec` and at `9ca4ae6`,** and its SHA-256 at the tip is the one in the manifest.
- **`git range-diff ae326b0..0a069ec f9537a8..9ca4ae6`** shows the one commit as equal (`=`). It has the same hash on both sides: nothing was rebased.
- **The merge commit holds no edit of its own.** `git merge-tree --write-tree 0a069ec f9537a8` reports no conflict and gives the tree `287824e9…`, which is the tree of `9ca4ae6`. So the tip is exactly what git makes from the two parents.
- **Everything else in the tree is `trunk_dev`.** `0a069ec` and `9ca4ae6` differ in 20 files (+5864/−37). They are the same 20 files that `trunk_dev` changed from `ae326b0` to `f9537a8`, and each has at the tip the blob it has at `f9537a8`. None of them is the file of the pull request.
- **The push was a fast-forward:** `0a069ec` is an ancestor of `9ca4ae6`.
- **The pull request adds and removes no test function and no `Skip` call.** The list of the gate has no line for the changed test. It has the `skips-itself` line for the helper that this test starts, `TestSQLiteClaimStoreLockHelperProcess`.

## 5. The run is green on that exact head

Read with the GitHub tools at 22:58.

- **Run 45079080694** (workflow `go`, run number 12, attempt 1, event `pull_request`): completed, conclusion success, `head_sha` `9ca4ae6d37128d1783ae83578ffbf0d2f9859049`. It has one job, 137382888906, from 22:41:03 to 22:53:57. All 15 steps of the job succeeded. The record gives 22:41:01 and 12 m 57 s, which are the run's creation and its span to its last update. The job itself took 12 m 54 s.
- **It is the pull request's one check run,** and that check run is a success. It is the first run of the checks on this pull request, because `trunk_dev` has the workflow only since `f9537a8`.
- **What it tested.** The log shows that it checked out `68d0bdaf79019f76d33186e749884dce415896df`, "Merge 9ca4ae6… into f9537a8…". That is `refs/pull/16/merge` on GitHub now. In my clone its parents are `f9537a8` and `9ca4ae6`, and its tree is `287824e9…`, the tree of the head. So the run tested the bytes of the head, on today's `trunk_dev`.
- **The job log** as the tool returns it is byte-identical to the writer's copy (140,659 bytes, SHA-256 `fa5d831bc223f4e8b8a76702f3213bddc1cf7445eaa67c3b47ddb8d175890b5d`). Image `ubuntu-24.04` version `20261116.133.1`, go1.26.5.
- **From the log** (`log-facts.log`): `Ran 121 tests in 113.713s`, `OK`. `test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed`. The observed run of `es/app` passed with its 2 listed tests. `all 15 listed tests still fail on this host, each in a run of its own and in the run of its package`. The third step makes 3 runs of whole packages and 15 of single entries, each of the 18 ends with the bare line `FAIL`, no run has `-skip`, no run stopped. The log has no error, warning or notice annotation, no `panic:` and no `test timed out` in either test step.
- **Against run 45075800893 of PR #14 at `8e4b43f`:** the 39 names that skipped themselves are the same 39, and the 15 lines `still fails:` are the same 15. The helper is among the 39, with the reason `helper process only`.

**The changed test,** `TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention`, has no line in the list. Inference, from the rules of the gate that `09-audit.md` checked: a test that `go test -list` names has to report a verdict, a failure fails the step, and a skip without a line fails the step, so in a green run this test ran and passed. The log does not print the names of passing tests, so I did not read that from the log.

## 6. What MERGE-READY means here, and its stop conditions

Provenance §5.4 allows the merge after ACCEPT in a delivered audit report when the head equals the audited commit. Step 2 covers a branch update: with no conflict and an unchanged patch the coordinator may accept a provenance-only re-check in place of a new audit. Those conditions are met, and this is that re-check.

- **Stop if the head is not `9ca4ae6d37128d1783ae83578ffbf0d2f9859049`** at the merge. Any later commit goes back to audit (§5.4 step 1).
- **Stop if `trunk_dev` is not `f9537a8680c24bf2108b95ed20ac3724e8939d3a`** at the merge. The result of the merge would then be bytes that no run has tested, and the update has to be repeated: merge, run, manifest, re-check.
- **The pull request is still a draft.** It has to be marked ready before it can merge. Project memory records for PR #17 that marking a pull request ready on this repository starts an automated review by a connected bot. Waiting for its summary is the merge step's call.
- **For §5.4 step 4, after the merge:** if `trunk_dev` is still `f9537a8` at that moment, the tree of the new `trunk_dev` commit has to be `287824e976ccc04c1f16c3d1b90c78626264bca8`, for a squash and for a merge commit alike. The one manifest path then has SHA-256 `fbf8f64c9f152e06680ca84d558531bb0d63048abaf12a336babc7df75e8c400` and 15,193 bytes.
- **Who has to say go** is the coordinator's reading of the merge policy, not part of this check. A fact for it: the pull request changes one Go test file and no production code.

## 7. Not covered, observations and Unknown

- **I ran nothing.** No build and no test on the merged tree. The runner did (section 5), and the writer ran fast checks in a container (`11-pr16-branch-update.md` 5.2), which I did not repeat.
- **The 20 files from `trunk_dev` are not audited here.** They came in through PR #17, PR #18 and PR #14, which have audits of their own. This check shows only that the branch holds them exactly as `trunk_dev` does.
- **No macOS run at this head.** The record says the changed test passed on a Mac at `0a069ec`. The file has the same bytes now.
- **A side result for PR #14** (§5.4 step 4 of that merge): the tree of `trunk_dev` at `f9537a8` is `88e6d89349b681dc5d469644fe1002850ec3ab75`. That is the tree of the head `8e4b43f` that `10-provenance-check.md` checked, so the squash of PR #14 put exactly the checked bytes on `trunk_dev`.
- **Commit trailers, as A9-O5 of `09-audit.md`:** the audited commit `0a069ec` and the merge commit `9ca4ae6` carry trailer lines of which the first names a model. The squash of PR #14 at `f9537a8` kept that line. With a squash, whoever merges writes the text that lands on `trunk_dev`.
- **Unknown:** whether `trunk_dev` now requires the check `build, vet and test` and an up-to-date branch, as section 7 of the record says. I did not read the branch settings.
- **Unknown:** whether the SSH signature on the merge commit verifies. I have no file of allowed signers.

## 8. Closing state

- **The target:** untouched. Nothing was pushed, no branch was created, no comment or review was posted, and the pull request was not edited. At 22:58:58 the remote refs were as at opening.
- **My fresh clone** (`/home/user/audit11/prov`, local only): back at the pushed tip `9ca4ae6` with a clean working tree. It also holds two local remote-tracking refs for `refs/pull/16/head` and `refs/pull/16/merge`.
- **No process was started** beyond git, the recipe and three small scripts of mine. They changed nothing in the clone except those two refs.

## 9. Sensitive-material handling

No secret, token, key or credential was read or written. The job log shows its token only as `***`. Before delivery I scanned this report and the 11 evidence files with the project's leak scanner (`ge_chat_archive.py scan`, version 1.4.0): 0 findings. My own search for token and key patterns and for e-mail addresses found none.

## 10. Confidence

- **Provenance: high.** The manifest reproduced four times in a fresh clone, the two diffs are the same bytes, and the merge commit is what git makes from its two parents.
- **Validation: high that the run is green on this head,** read from GitHub: one run, the first of the checks on this pull request. Not validated by me: anything I would have had to run.
- **Implementation: unchanged** from `06-reaudit.md`, because no byte of the patch changed.

## 11. Report delivery

- This file: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/11-pr16-provenance-check.md`. Its SHA-256 is in the reply that delivers it.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/ci-go-workflow/11-pr16-provenance-check-evidence/`, 11 files, with a `README.md` and a `SHA256SUMS.txt` that lists the 10 others.
- `11-pr16-branch-update.md`, `06-reaudit.md` and their evidence folders are unchanged by me.

STATUS: READY
