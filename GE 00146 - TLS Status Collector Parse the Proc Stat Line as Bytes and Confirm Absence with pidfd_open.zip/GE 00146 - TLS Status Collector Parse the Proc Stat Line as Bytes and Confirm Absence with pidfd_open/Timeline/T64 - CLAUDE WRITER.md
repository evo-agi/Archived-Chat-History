David, please write "go ahead" in this thread once more so I can repeat the Mac check, this time on the newest version of the fix.

The reason: a change merged an hour ago moves macOS test folders off a system shortcut. Tests that used to stop early on your Mac can now reach the exact code this fix repairs, so the last check no longer covers it. It is the same safe run as before (about 10 minutes, all in a temporary folder in Playground). The instructions are attached.

STATUS: NEEDS DAVID
