**PR #22 audit: BLOCK on A4-1 (medium).** Report: [04-audit-pr22.md](/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/04-audit-pr22.md) (sha256 c95766bf…784b), with evidence in `04-audit-pr22-evidence/` (SHA256SUMS 7d888e8d…419b).

**What holds.** The byte parsing itself is sound:
- No hostile process name changed a result: all 776 names tried, plus forged-tail members inside a real `run_fixed`.
- Zombies, and stopped, traced and blocked processes, never read as absent.
- The writer's tests pass 120 of 120 idle and 120 of 120 under load, and 12 of my 13 mutants were caught.
- The closing manifest equals the opening one.

**What blocks.** The writer's "ESRCH means reaped" is false. When one of a process's non-leader threads calls exec while the collector looks up that process in `/proc` for the first time, the kernel can answer ESRCH, ENOENT or a group ID of `-1`, all for a live process.
- The head reader reported a live process as absent 224 times in 621,858 reads. Base did it 80 times, through ENOENT only.
- End to end, the real absence proof returned while a group member was still running in 7 of 7 head runs. Base did the same in 6 of 6 runs, through ENOENT and the `-1` line, so that part was already broken before this PR.
- The PR widens the rule and writes it into three contract documents.

**Reach.** It needs a group member that runs exec from a second thread. Openssl doesn't do that as far as I can tell, so a normal run shouldn't hit it.

**Repair scope.** Treat a process as absent only when `pidfd_open` confirms nothing has that ID; otherwise re-read, then leave it unproved. Fix the docs, and add a test with a live process. My sketch of this had 0 false absences in 6.2 million reads, held the proof for the full time, and passes the writer's tests. A narrow re-audit is pre-committed.

**Separate, older escape (not from this PR).** A child that ignores SIGTERM and keeps forking a replacement escapes cleanup when PID 1 reaps orphans at once, as systemd does: 5 of 40 runs at head, 3 of 40 at base. It needs its own tracked item.

**Two calls for you** (details in section O4-6 of the report):
- Whether a collector that runs as root counts as a "script" for the no-review merge rule.
- Whether this adversarial audit stands in for the red-team.

STATUS: READY
