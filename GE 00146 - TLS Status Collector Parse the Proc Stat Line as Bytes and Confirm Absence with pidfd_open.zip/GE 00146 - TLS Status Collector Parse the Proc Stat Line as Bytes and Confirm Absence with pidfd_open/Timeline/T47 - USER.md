> Welcome back. Here's what moved while you were away. Two things still need you.


Thread `Fix TLS status collector hang` is using Fable, and we have run out of Fable usage, so, before I give the go ahead, we need to decide whether the thread needs to stay on Fable. Or, if you know which model to you, I'll let you change the setting first

For maintenance agent, notification should be sent to both Mac and phone. Regardless, if we were to build this in Java and in a config-driven way, we'd have one interface, and phone-backed and Mac-backed notification methods would be extending said interface. Then, we just add the notification methods in a config. Well, we might already be doing that.

Where are branch claude/project-thread-a9tcoa-ci and branch claude/project-thread-a9tcoa-bringup-probe?
