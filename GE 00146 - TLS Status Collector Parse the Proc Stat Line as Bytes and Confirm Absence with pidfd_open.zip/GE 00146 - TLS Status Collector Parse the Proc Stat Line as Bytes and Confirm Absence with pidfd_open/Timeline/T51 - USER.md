> TLS collector thread: it doesn't need Fable. What's left is your Mac check, updating onto the latest trunk_dev and the m…


Hmm... I thought you could change the model setting in a thread?

Will delete the branches later. I might be less available today.
