**Narrow re-audit of da56d63: ACCEPT, no finding.** A11-1, A11-2 and A11-3 are closed, and this verdict includes the gate data for da56d63.

- **A11-1:** the guard now refuses a faked probe followed by main() or diagnostic_main(), which were my shapes G1 and G2. I built the collector's call graph myself. The rule's three cuts are exactly its minimal cuts. The guard judges 141 package scripts and refuses none.
- **A11-2:** all three of my os demos now end with 98.
- **A11-3:** Y3 and Y9 are caught. Of my 20 new mutants, 15 are caught. The 5 that survive are harmless or already stated as limits.
- **Merge and gate:** the trunk_dev merge is clean, and the PR's patch is the same on both bases. My manifest matches the writer's e0abc4cc…3b4f, and CI is green on the head's own tree.
- **No-/proc, no-pidfd emulation:** 32/32 tests pass on the head and 26/26 on trunk_dev. The whole package gives the same 2,237 shared verdicts, with no hang.
- **Mac brief 5** is safe: it can end only processes whose command line holds the literal temp path. Two small tightenings are optional (O13-4).
- **For the merge (O13-5):** all six commits carry a model name in a co-author trailer, so the squash message must leave those lines out.

Report sha256 2a8b9096…286c. Evidence SHA256SUMS.txt dbc015b8…ae85 (70 files, verified). The leak scan found nothing, and I used no subagents.

STATUS: READY
