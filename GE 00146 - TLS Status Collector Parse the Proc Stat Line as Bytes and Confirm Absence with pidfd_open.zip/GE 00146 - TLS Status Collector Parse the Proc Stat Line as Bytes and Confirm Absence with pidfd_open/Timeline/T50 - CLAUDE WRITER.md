Thanks. trunk_dev moved twice since, so I first bring PR 22 up to date, then start the Mac check on that head.
