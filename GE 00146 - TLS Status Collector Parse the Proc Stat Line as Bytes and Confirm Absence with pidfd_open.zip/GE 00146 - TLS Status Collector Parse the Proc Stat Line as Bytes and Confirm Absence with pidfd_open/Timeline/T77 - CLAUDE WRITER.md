Handed the machine session instructions

One addition to the brief, read-only. Do it after step 7 and BEFORE step 9 removes T (if T is already removed, say so and skip it). After the three guard lines, print every verdict line of three tests from both result files with this command:
/usr/bin/grep -nE -- '--- (PASS|FAIL|SKIP): TestRemoteAlphaESServiceTLSStatus(SingleSelectedTrustAnchorCardinality|MaterialByteBinding|FailureWitnessFixedInputCloseout)( |$)' "$T/b-head.txt" "$T/c-trunk.txt"
Report its complete output, so the report shows whether each of the three top-level tests ran and passed on the head and on trunk_dev. Everything else in the brief stays as it is.
