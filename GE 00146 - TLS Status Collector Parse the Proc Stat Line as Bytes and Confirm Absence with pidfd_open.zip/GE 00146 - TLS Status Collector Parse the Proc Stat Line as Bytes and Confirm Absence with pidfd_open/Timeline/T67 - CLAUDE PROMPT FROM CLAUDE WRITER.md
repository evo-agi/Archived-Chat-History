Here is the response from CLAUDE WRITER:

Addition to the PR 22 gate data: the whole root package in the cloud, 8ce6b73 against 200fd60. Head 2,256 verdicts, trunk_dev 2,238. No verdict differs and nothing is only on trunk_dev. The 18 verdicts only on the head are the PR's new tests and subtests, all pass. Both commits fail the same 8 top-level tests (the container-only failures seen in every earlier comparison). CI 45192217961 still running.
