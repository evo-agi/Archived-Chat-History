**Please write "go ahead" here to start the Mac check of PR 22.** It is the last step before the merge: the re-audit of `da56d63` came back ACCEPT with no finding, and CI is green.

The run uses a slightly tightened brief, [mac-instructions-6.txt](/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/14-evidence/mac-instructions-6.txt) (sha256 `bb9302a0bf611977c3a77fc7bd6a4623e178a7d0753afa337b8fad51aa8b1985`). It only tests inside a temporary folder under Playground and removes it afterwards.

STATUS: NEEDS DAVID
