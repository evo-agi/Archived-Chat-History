The Mac check passed. On your Mac every test of the package now passes on the fix (472 passed, 3 skipped by design, none failed), with no hang and nothing left behind. That includes the tests that newly reach the repaired code. I'll merge PR 22 as soon as GitHub's checks finish, in about 10 minutes. Report attached.

STATUS: WORKING
