The collector fix is up as draft [PR 22](https://github.com/evo-agi/Execution-Substrate/pull/22), and its CI run is green. A process name can no longer stop the TLS status collector, and a process that ends mid-scan no longer spoils a clean run. The new tests fail on the old code and catch all 19 mutants. It now goes to a fresh audit. Nothing is needed from you.

Report: [03-collector-process-name-fix.md](/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/03-collector-process-name-fix.md), SHA-256 `fdffc73b5b70285a737c7778266ae3de7a890ef7e0df417052b2d35ecc930b3a`.

STATUS: WAITING
