**Narrow re-audit of 1032c9c: BLOCK.** The fixture fix works, but the guard and the shared constant need a small repair to tests only. The production code is unchanged, and the 5 audited files still match 39a016c.

**What holds**
- **Gate data for 1032c9c passes.** The manifest is 4fa9dc34…51d4, the same as the writer's. CI 45109495444 is green on the tip's tree, and the range-diff shows only the new commit.
- **The 19-of-26 claim is right.** I emulated a host with no /proc and no pidfd. On 7806170, exactly those 19 tests fail to finish. On trunk_dev and on the head, all 26 pass. Across the whole package, the head gives the same verdicts as trunk_dev and as 7806170.

**Findings (all low, tests only)**
- **A11-1:** the guard misses fixtures that fake the capability probe and then call main() or diagnostic_main(). 15 current fixtures have that shape. They are safe today only because they also fake collect or run_fixed. Report section 8 has a rule that accepts all 45 such fixtures and still catches the bad cases.
- **A11-2:** the constant uses the fixture's own `os`. In a fixture that doesn't import os, the bound ends in a NameError (exit 1) instead of 98. Fix: the constant imports os itself.
- **A11-3:** two test mutants survive: a default bound of 0 and a trimmed name list. Both need to be pinned.

**Mac step 6** is safe only while T is the literal temp path. An empty T would match every process. Section 8 has a guarded version. Run the Mac test on the repaired head.

Report sha256 7474da81…6e4d. Evidence SHA256SUMS.txt e5e1a5fd…6997 (47 files, verified). The leak scan found nothing, and I used no subagents.

STATUS: WAITING
