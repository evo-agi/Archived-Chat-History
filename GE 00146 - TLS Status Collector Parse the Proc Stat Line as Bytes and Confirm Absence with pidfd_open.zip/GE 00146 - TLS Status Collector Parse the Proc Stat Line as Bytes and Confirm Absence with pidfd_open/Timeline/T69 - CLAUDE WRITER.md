Thanks. I'm starting the Mac check on your computer now and will report when it finishes, in about 15 minutes.
