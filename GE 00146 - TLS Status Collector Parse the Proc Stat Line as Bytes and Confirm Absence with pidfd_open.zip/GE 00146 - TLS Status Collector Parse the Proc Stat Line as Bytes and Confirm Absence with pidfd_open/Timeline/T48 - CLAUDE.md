**TLS collector thread:** it doesn't need Fable. What's left is your Mac check, updating onto the latest trunk_dev and the merge checks, all routine. Please switch it to Opus, then give the go ahead.

**Maintenance agent:** alerts will go to both your Mac and your phone. Unknown whether the code already uses one interface with Mac and phone versions chosen by config. The maintenance agent repair is checking the code now. If it doesn't, the repair will build it that way in this PR if that's the right shape.

**Branches:** both are in the Execution-Substrate repo: [claude/project-thread-a9tcoa-ci](https://github.com/evo-agi/Execution-Substrate/tree/claude/project-thread-a9tcoa-ci) and [claude/project-thread-a9tcoa-bringup-probe](https://github.com/evo-agi/Execution-Substrate/tree/claude/project-thread-a9tcoa-bringup-probe). To delete them, open the [branches page](https://github.com/evo-agi/Execution-Substrate/branches/all) and click the trash icon next to each one.

STATUS: NEEDS DAVID (switch the collector thread to Opus, then "go ahead")
