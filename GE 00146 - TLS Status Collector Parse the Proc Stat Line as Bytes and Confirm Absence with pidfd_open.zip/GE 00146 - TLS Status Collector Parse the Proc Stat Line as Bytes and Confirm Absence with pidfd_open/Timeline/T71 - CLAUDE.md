It's a safety rule of the Mac connection, not one of ours. When Claude runs commands on your own computer, it only counts a request you typed yourself in that thread. A message I pass along doesn't count, so I can't approve a run on your behalf. That keeps anything from running on your Mac without you knowing.

Unknown whether there's a setting that lifts this for trusted runs. I'll check and tell you if there's a safe way to reduce how often you're asked.

STATUS: WORKING (collector Mac check running; nothing else needed from you)
