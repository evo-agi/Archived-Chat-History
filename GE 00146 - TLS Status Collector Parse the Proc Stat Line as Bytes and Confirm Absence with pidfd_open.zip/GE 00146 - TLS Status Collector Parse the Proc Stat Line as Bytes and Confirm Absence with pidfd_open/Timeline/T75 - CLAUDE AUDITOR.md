**Provenance re-check of PR 22 at 8ce6b73: PASS.** 8ce6b73 contains exactly the PR I audited, so the ACCEPT carries over to it on trunk_dev 200fd60.

- **Manifest:** two runs gave 22b1b458…1e1c, the same as the writer's. The merges are clean, and the four PR commits are unchanged. The PR's patch is identical on both bases, file by file.
- **Merged documents:** in capability_probing.md, PR 23's 28 lines and the PR's 37 lines sit in separate places. Applying the audited patch to trunk_dev's text gives the head's text exactly, for that file and for PLANS.md.
- **Tests:** build, vet and gofmt pass, and the PR's 11 tests pass. The whole package matches trunk_dev on all 2,238 tests they share.

**PR 23's TestMain:** on Linux and in CI it changes nothing; all 498 traced test helper processes reach the same collector code. On a temp folder behind a symlink, as on macOS, it does change things. Three tests now reach the fixed child and its process cleanup, where before the collector's symlink check stopped them earlier: SingleSelectedTrustAnchorCardinality, MaterialByteBinding and FailureWitnessFixedInputCloseout. In my emulation without /proc and pidfd, all three pass in about a second, with no hang. So the Mac run of 0a80ab7 could not cover these paths. The planned Mac run of 8ce6b73 (mac-instructions-8) will.

CI run 45192217961 on 8ce6b73 was still running at 14:41Z; the merge needs it green. Note sha256 575022b5…8e2f, evidence SHA256SUMS.txt ac7234b3…b67b (36 files, verified). The leak scan found nothing, and I used no subagents.

STATUS: READY
