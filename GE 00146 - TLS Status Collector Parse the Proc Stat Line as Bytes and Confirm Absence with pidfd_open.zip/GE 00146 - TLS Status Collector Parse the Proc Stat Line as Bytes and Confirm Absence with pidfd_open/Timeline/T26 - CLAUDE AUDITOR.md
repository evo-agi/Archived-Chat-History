The PR 22 merge-gate re-check had already finished when the stop arrived. 7806170 passes every check, but the note is marked superseded, so it can't be used as gate evidence for the new head.

What it found on 7806170:
- **Provenance:** it is a clean merge of the audited 39a016c with trunk_dev 110d377, and its change is byte-identical to the audited one. The manifest b6476378…7d5a reproduces, and only its head field differs.
- **CI:** run 45103477792 is green, and the merge GitHub tested has the same tree as the tip.
- **Tests on the merged tree:** PR 21's tests passed 30 of 30 and PR 22's passed 25 of 25. In the full TLS status set, 77 pass and 3 fail; those 3 also fail in CI and need a different environment to run. M05 is still caught.

Two things for the writer:
- The PR body still describes 39a016c, including "audit not performed".
- All three commits carry a co-author line with a model name. 110d377 has the same line, and GitHub's default squash message keeps these lines.

I'm ready for the narrow re-audit of the third commit.

Note: [08a-merge-gate-pr22.md](/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/08a-merge-gate-pr22.md) (sha256 53a0dd35…76e1), evidence SHA256SUMS b27fb295…696e. Leak scan: 0 findings.

STATUS: WAITING
