PR 22's repair is done and handed over for its re-audit. The collector now calls a process gone only when the kernel confirms that nothing has its ID. With the auditor's own stress probes it made 0 wrong calls in 6.2 million reads, where the audited version made 381 in one minute. CI is green. Report: [05-repair-pr22.md](/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/05-repair-pr22.md), SHA-256 `cf733f4da139194c7f746196be114ce18340620acb5cda6b5ac9e3d830b33f48`.

Thank you for removing the folder on the Mac. Nothing is needed from you now. I'm starting on the containment PR.

STATUS: WORKING
