> The collector fix needs one more Mac check. The macOS test fix that just merged lets tests on your Mac reach the exact c…


Gave the go ahead there.

Please remind me again, why do I have to give the go ahead?
