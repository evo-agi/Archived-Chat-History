Handed the machine session instructions

Run a read-only test check of two Execution-Substrate commits on this Mac and report the output. This is the macOS run for pull request 22. Its two test commits change tests and one document only: they make the local test fixtures of the TLS status collector independent of /proc and pidfd_open, which a Mac does not have. The question for this Mac is whether the root package's tests still finish here on the new head, with the same verdicts as on trunk_dev. Change nothing outside one new temporary folder.

Rules:
- Work only inside one new folder that you create under /Users/ds/Repositories/Playground, with: mktemp -d /Users/ds/Repositories/Playground/es-mac-run.XXXXXX   Call it T below. Print the path that mktemp returns.
- The guard lines. A shell variable may not survive from one command to the next in your session, and an empty or wrong T must never reach a command. So begin EVERY command after the mktemp of step 1 with these three lines, in the rest of step 1 and in steps 2 to 9, with the path that mktemp printed typed in as literal text between the single quotes (never a pattern, a variable or a command substitution):
   T='/Users/ds/Repositories/Playground/es-mac-run.XXXXXX'
   case "$T" in /Users/ds/Repositories/Playground/es-mac-run.[A-Za-z0-9][A-Za-z0-9][A-Za-z0-9][A-Za-z0-9][A-Za-z0-9][A-Za-z0-9]) ;; *) echo "T is wrong: stop"; exit 1;; esac
   test -d "$T" || { echo "T does not exist: stop"; exit 1; }
  If a guard line prints "stop", run nothing else with that T: stop and report what was printed.
- NEVER make T or anything inside it your working directory. Keep /Users/ds/Repositories/Playground as the working directory for the whole session and run every command either with "git -C" or "go -C", or in a subshell: ( cd "$T/clone" && ... ). The removal at the end is refused if T was ever the working directory.
- Do not change, stage, commit or delete anything in any existing folder. You may read the origin URL of the existing clone at "/Users/ds/Repositories/Execution Substrate" (git -C "<that path>" remote get-url origin) and use that URL to clone. Do not run any other command in that folder.
- No sudo. No git push. No installs and no downloads other than the git clone and fetch. Do not touch any live service.
- If a command fails, do not try to fix the code. Record the output and follow the step's own rule for what comes next.
- Do not end any process, with one exception that step 6 states exactly.
- At the end remove T and confirm that it is gone. /Users/ds/Repositories/Playground itself must still exist afterwards.

Go: the Go on the PATH of this Mac is 1.26.1, and Go 1.26.5 is in the module cache. Run every go and gofmt command of this brief with these variables set in the same command, after the guard lines, so that nothing can be downloaded and a missing toolchain or module fails loudly:
   export GOTOOLCHAIN=go1.26.5 GOPROXY=off GOFLAGS=-mod=readonly GOCACHE="$T/gocache"
If "go version" run inside the clone is not go1.26.5, stop and report. If a test command fails because a module is missing from the module cache, report the exact error and stop: do not download.

Steps:
1. Create T with the mktemp command above, as a command of its own, and print the path it returns. Everything else in this step comes in later commands, each after the three guard lines. Clone evo-agi/Execution-Substrate into "$T/clone" (origin URL as above). Print: sw_vers, uname -m, /usr/bin/python3 --version, whoami. With the clone: ( cd "$T/clone" && go version && go env GOVERSION GOROOT GOTOOLCHAIN GOPROXY GOCACHE ).
2. git -C "$T/clone" fetch origin trunk_dev claude/project-thread-k69qcw-collector-process-names
3. Check out exactly commit 0a80ab78b8693d59185d5a10963ac358228e99ec (detached). Confirm with git -C "$T/clone" rev-parse HEAD 'HEAD^{tree}' (expected tree 63ab1c59cde1de0c1d0eeb96723ec068c5492bba). If origin/claude/project-thread-k69qcw-collector-process-names is not that commit, say so and still test that commit.
4. The six tests of the local fixture boundary, with their complete output and exit status:
   ( cd "$T/clone" && go test -count=1 -v -timeout 10m -run '^TestRemoteAlphaESServiceTLSStatusLocal' . ) > "$T/a-new-tests.txt" 2>&1; echo "exit=$?"; cat "$T/a-new-tests.txt"
   Expected: six tests pass (PinsItsNames, IsInjectedWhole, KnowsTheCallGraph, NeedsNoTargetFacility, FailsBounded, DocumentsContract). IF THIS STEP DOES NOT PASS, DO NOT RUN STEPS 5 TO 7: run step 6, then step 8, then step 9, and report.
5. The whole root package on the new head:
   ( cd "$T/clone" && go test -count=1 -v -timeout 25m . ) > "$T/b-head.txt" 2>&1; echo "exit=$?"
   Do not print the whole file. Print: the last 5 lines; the number of lines that start with "--- PASS", "--- FAIL" and "--- SKIP" (three counts, top-level tests only: lines that start at column 1); every line that starts with "--- FAIL" at column 1; and every line that contains "panic: test timed out", "local fixture exceeded its bound" or "local fixture reached the target-only host path". A nonzero exit is expected, because some tests of this package need Linux. Report how long the command took.
6. Leftover processes. After the three guard lines:
   ps -axo pid,ppid,pgid,stat,etime,command | grep -F -- "$T/" | grep -v -F -- 'grep -F'
   Expected: no output. If there is output, report it in full, and also report the output of this line, which ends nothing:
   ps -axo pid,ppid,pgid,stat,etime,command -U "$(id -u)" | grep -E 'python3|openssl' | grep -v -F -- 'grep -E'
   Then, and only for a pid that the first ps line listed, you may end that one process with this line, with the number typed in place of PID (it ends the process only if its command line still contains the path T followed by a slash):
   ps -o command= -p PID | grep -qF -- "$T/" && kill -KILL PID
   Show the first ps line again afterwards. End no other process, and never use a pattern, a process group or a name in place of the number. If a safety rule stops you, do not work around it: report the pids.
7. The same package on trunk_dev, for comparison. Check out exactly df461642d2f7c9481873ca74b7eaaba368feb12f (detached; confirm with rev-parse HEAD), then:
   ( cd "$T/clone" && go test -count=1 -v -timeout 25m . ) > "$T/c-trunk.txt" 2>&1; echo "exit=$?"
   Print the same lines as in step 5, and run step 6 again. Then compare the two runs with exactly this command (it reads the two files and prints only differences):
   /usr/bin/python3 -I -c '
import re,sys
def load(p):
    v={}
    for line in open(p,encoding="utf-8",errors="replace"):
        m=re.match(r"\s*--- (PASS|FAIL|SKIP): (\S+)",line)
        if m: v[m.group(2)]=m.group(1)
    return v
head,trunk=load(sys.argv[1]),load(sys.argv[2])
print("verdicts: head",len(head),"trunk_dev",len(trunk))
for k in sorted(set(head)-set(trunk)): print("only on head:",head[k],k)
for k in sorted(set(trunk)-set(head)): print("only on trunk_dev:",trunk[k],k)
for k in sorted(set(head)&set(trunk)):
    if head[k]!=trunk[k]: print("DIFFERENT:",k,"trunk_dev",trunk[k],"head",head[k])
print("compared")
' "$T/b-head.txt" "$T/c-trunk.txt"
   Report its complete output.
8. With the clone at whatever commit it is: ( cd "$T/clone" && git status --porcelain ) (expected: empty), and "$(cd "$T/clone" && go env GOROOT)/bin/gofmt" -l "$T/clone/remote_alpha_es_service_tls_status_test.go" "$T/clone/remote_alpha_es_service_tls_status_local_boundary_test.go" (expected: no output).
9. Remove T (your working directory is still /Users/ds/Repositories/Playground): the three guard lines, then  rm -rf -- "$T"  in the same command. If the removal is blocked, do not retry: say so and give the one-line command for David, with the literal path. Confirm with  test ! -e "$T" && echo "T is gone"; test -d /Users/ds/Repositories/Playground && echo "Playground exists".

Report back: the environment lines of step 1, the commit and tree hashes as checked out, the complete output and exit status of step 4, the printed lines and durations of steps 5 and 7, the complete output of the comparison, the output of each ps line, and the results of steps 8 and 9. Say plainly which commands passed and which failed. Do not summarize a failure away.
