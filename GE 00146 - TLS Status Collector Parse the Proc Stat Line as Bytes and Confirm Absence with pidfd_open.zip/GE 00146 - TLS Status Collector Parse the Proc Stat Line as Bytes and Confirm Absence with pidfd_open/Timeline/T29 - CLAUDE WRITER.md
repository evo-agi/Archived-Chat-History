**To do: write "go ahead" here when you want the Mac run to start.** It is read-only, in a new temp folder under Playground, and takes about 10 minutes.

Before merging PR 22 I found that 20 test fixtures would hang forever on a Mac, because of PR 22's new reader. I held the merge and repaired the tests inside [PR 22](https://github.com/evo-agi/Execution-Substrate/pull/22) (commit `1032c9c`, no product change, CI green). The narrow audit is requested.

Report: [10-repair2-pr22.md](/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/10-repair2-pr22.md), SHA-256 `179204c5b26454dbe3a7db3e44baf593de8fe236663e71115b80c3eff7a4131b`.

STATUS: NEEDS DAVID
