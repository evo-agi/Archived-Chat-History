**PR 22 re-audit: ACCEPT, no finding.** The `pidfd_open` repair at `39a016c` closes A4-1 and P4-2. [08-reaudit-pr22.md](/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/08-reaudit-pr22.md) has sha256 `4cc6522b6593708ea2acd005397e81ad733adc7ee991fd770f25afc91f109575`. Its evidence folder has 56 files, and the SHA256SUMS file's own sha256 is `74dd20d8…8a48`.

- **Same bytes as reviewed:** the manifest `1a8f223b…df51` matched at the start and the end. The writer's diffs are byte-identical to mine.
- **Root stress probes, unchanged from the first audit:**
  - On the old head they still find the fault: 187 live processes read as absent in 60 s, and the absence proof returned after 7.8 s while the member was alive.
  - On the repair: 0 false absences in 9.1 million reads and 0 missed scans in 186,000. The proof held for 90 s with fresh `/proc` mounts and again with dropped caches.
- **pidfd_open fallback (your question):** there is none, by design, and that is correct. When `pidfd_open` is missing, ENOSYS, EPERM, EACCES, or EINVAL on every call, the capability probe refuses before anything is spawned. I emulated how older kernels answer with EINVAL: reads were correct, with 0 false absences.
- **Tests and mutants:**
  - The writer's tests fail on the old collector in exactly the 43 cases claimed, and pass on the repair (300 of 300 repeats, idle and under load).
  - My 8 mutants are all caught. One is caught only by an older TLS status test.
- **Both repairs together:** PR 21's tests pass on this collector (160 of 160), and M05 is still caught. Merge order does not matter, but whichever PR merges second needs the usual branch update and provenance re-check.

There are five observations, and none needs action. Two worth knowing:
- In rare cases, an unrelated process can leave a scan unproved; the result is fail-closed.
- The Remote Alpha host's kernel is still not measured. Running the writer's `pidfd_answers.py` once at the next box session would settle that.

Leak scan: 0 findings. No subagents were used.

STATUS: READY
