The cleanup hold cannot block for good in the way I first raised. The collector runs only on the host, never in a container, and the real OpenSSL commands leave nothing behind to wait for.

While checking I found a second way that does work on the supported host. Any process whose name has a non-ASCII letter stops the TLS status collector, and one that starts mid-run makes it hang, with its lock, until that process ends. I measured both. The proper fix is about ten lines in one function. I wrote no product code.

Report: [02-cleanup-hold-investigation.md](/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/02-cleanup-hold-investigation.md), SHA-256 `44bdbcd0f535f0ee4c2ba0eb298b73239c89e5ac5959b7ca3e29989642907bde`.

STATUS: WAITING
