PR 22 is merged into trunk_dev. The fix for the TLS status collector hang is in, and trunk_dev now holds exactly the reviewed and tested version. The gate report is attached.

The follow-up work (stopping a misbehaving helper process from escaping cleanup) continues in a new thread. It now covers both TLS status collectors. I'm watching the last automatic check on trunk_dev and will close this thread when it passes.

STATUS: READY
