# HANDOFF UPDATE: containment of the TLS status collectors' fixed children

Written 2026-11-23 15:00Z by the writer thread of PR #22, after PR #22 merged. It extends `02-handoff.md` (sha256 `db845f37fe1dd6f7711653b3eb3d0904dc4daa9925ff85f32113277bd0a25131`), which stays as it is. Read `02-handoff.md` first, then this note. Where the two differ, this note is newer. Nothing here is audited.

## 1. What changed since 02-handoff.md

| Item | Value |
|---|---|
| PR #22 | merged 2026-11-23 14:53Z as squash commit `792f17c7c56ca4a9c00d34aeb59524d898aeb58c` on `trunk_dev`. Its tree `02ab404b8adb3950c773dada961ed6888af1ce43` equals the tested head `8ce6b73`, and all 8 manifest paths have the head's blobs (`tls-status-fixture-timing/19-merge-gate-pr22.md`) |
| Base for the restart (decision D5) | `trunk_dev` at `792f17c` or later. Re-pin to `origin/trunk_dev` before every manifest run |
| WIP branch | unchanged: `claude/project-thread-k69qcw-child-containment` at `06325a2a8079680f7306ad31b1c40aaf60456a2e`, on `1032c9c` |
| Since `1032c9c`, trunk_dev gained | PR #22's `f62eeef` (guard rule for probe stand-ins, call-graph pin, the shared constant importing `os` itself), PR #19, PR #24 (Nomad, Vault and SPIRE CI steps) and PR #23 (`internal/testtmpdir` and a `TestMain` in every test package, guarded). A new test package from the containment work must carry that `TestMain`, or PR #23's guard fails |
| macOS | with PR #23, macOS root tests reach the collector's real `run_fixed` and process cleanup. The containment change must keep the root package passing on a Mac, so the Mac run in step 7 of `02-handoff.md` is a real check, not a formality |

## 2. Scope addition: the second TLS status collector

The coordinator's design scan (`/mnt/project-files/reports/design/interface-opportunities.md`, item ES-6, sha256 `af3db4319c17b3d80ad8c3f31b581a1ee8a2384779bb38a2df6881c875264da3` when read) found that the containment plan covers only `scripts/internal/remote_alpha_es_tls_status.py`. At the coordinator's request (2026-11-23 14:52Z) the containment work now covers both remote collectors. The continuation decides how; this note only states the facts.

**Facts (read at `trunk_dev` `792f17c`):**

- `scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py` (1,143 lines) is the streamed remote collector of the noninteractive operator health check. It runs as the SSH target user, and as root only when the SSH target already is root (`.docs/remote_alpha_operator_healthcheck_noninteractive_status.md`, section 9).
- Its fixed commands are `openssl`, `sha256sum` and `stat` over three fixed ES files, and the same argv through `sudo -n` when a direct read is refused and the argv is in `sudo_allowlist` (`run_fixed`, line 506).
- `run_command` (line 225) starts each command with `start_new_session=True`, reads stdout and stderr until both reach EOF and the child has exited, with a 10 s deadline (`COMMAND_TIMEOUT_SECONDS`).
- Cleanup is `resolve_child_lifecycle` (line 169): only on timeout, overflow, error or an incomplete read, `killpg(SIGTERM)`, 1 s grace, `killpg(SIGKILL)`, 1 s, then a nonblocking reap of the direct child. On a normal completion nothing is signalled.
- It has no group-absence proof and no `/proc` scan. Once the direct child is reaped and both pipes are at EOF, it returns.

**What follows (inference from the code, not measured):**

- A descendant that closes stdout and stderr and leaves the group with `setsid` or `setpgid` is never signalled and is not noticed. That is the escape that option A of `01-proposal.md` measured (60 of 60 escaped).
- A descendant that closes both pipes and stays in the group outlives a normal completion, because nothing is signalled then.
- This collector's threat differs from the ES collector's. Its children are fixed binaries, but under `sudo -n` they run as root, and a signal from the unprivileged collector to a root process group may be refused (`EPERM` falls back to `proc.terminate()`). Unknown: what `sudo` forwards in that case.

**Why option C does not carry over as it is (inference):**

- `unshare(CLONE_NEWPID)` needs `CAP_SYS_ADMIN`. This collector normally runs unprivileged, so it would need a user namespace as well (`CLONE_NEWUSER | CLONE_NEWPID`).
- Unknown: whether the Remote Alpha host allows unprivileged user namespaces. Ubuntu 24.04 restricts them through AppArmor by default (`kernel.apparmor_restrict_unprivileged_userns`). Check on the host; do not assume.
- Unknown: whether `sudo -n` works for a child inside an unprivileged user namespace. Expected not to, since the namespace's root is not the host's root. If it does not, the `sudo -n` path needs another shape (for example the namespace created only around direct commands, or a containment that the elevated side sets up itself). This is a design decision for the continuation, and it goes to the coordinator before code, like D1 to D5.

**Also in the scan, not in the containment scope:** `scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive.py`, the local facade, also starts its child (the SSH process) with `start_new_session=True` and cleans up with `killpg` (lines 426, 438, 499). It runs on the operator's machine, which may be macOS, where PID namespaces do not exist. Unknown whether it needs containment; say so in the containment PR's "Not done" list rather than leave it unmentioned.

**ES-6 drift test.** The scan proposes a Go test that pins the supervision functions (`run_fixed`, `reap_child`, `read_pipe_chunk`, `PipeReadResult`) of the three collectors against each other, or against a declared list of intended differences, after the containment PR merges. If the containment PR changes both remote collectors, that test can come in the same PR or right after it; it is the machine-enforced trigger that keeps a later fix from landing in one copy only.

## 3. What is left, in order (replaces section 6 of 02-handoff.md)

1. Start a branch from `trunk_dev` (at `792f17c` or later) and bring `06325a2` over. Expect conflicts in `remote_alpha_es_service_tls_status_local_boundary_test.go` and in the shared constant of `remote_alpha_es_service_tls_status_test.go`; keep `trunk_dev`'s version and add the namespace parts again.
2. `TestRemoteAlphaESServiceTLSStatusLocalBoundaryKnowsTheCallGraph` will fail on purpose: `run_fixed` gains `_run_fixed_in_namespace`. Update the expected call graph in the same change. Pins in `...PinsItsNames` for any new guard name.
3. Behaviour cases for the mutants M01, M13, M16 and M22 (`02-handoff.md` section 5).
4. Second collector: measure the two escapes above on the current code (a fixed-command stand-in that leaves the group, and one that stays in it after a normal completion), then bring the design question of section 2 to the coordinator with the measured facts and the host facts (unprivileged user namespaces, `sudo -n` inside one). Implement the decided shape with its own tests and mutants.
5. Whole-package comparison with the base, `go vet` for Linux and `GOOS=darwin`, the full gate self-check, mutants again.
6. Provenance (manifest v2, fresh clone), draft PR with the CI privilege widening stated, report. The report says that the first cut of the ES collector's code was written before its tests.
7. Mac run (David writes "go ahead" in the new thread) and Remote Alpha host run (with `pidfd_answers.py`, decision of 02:59Z) through the coordinator, then fresh audit and red-team.
