# REPAIR REPORT: Execution-Substrate PR #22, the collector calls a process absent only when `pidfd_open` confirms it

**Outcome: finding A4-1 is repaired the way the audit required. The proc stat file no longer proves that a process is gone. After an unclear answer (ENOENT or ESRCH at open, ESRCH at read, or a negative group ID) the reader asks `pidfd_open`, and only its answer "no process has this ID" makes the process absent. If a process still has the ID, the reader reads again, four times at most, and an answer that stays unclear is unproved, never absent. With the auditor's own probes, unchanged, the repaired reader gave 0 false absences in 6,194,102 reads and 0 of 126,410 scans missed the live process, where the audited head gave 381 false absences in one minute in the same container. The real `prove_group_absent` no longer returns while the member lives. P4-2 (group ID -1) is closed by the same change. The three contract documents are corrected, and the new tests fail on the audited head and pass on the repair.**

Written 2026-11-23 by the writer thread of PR #22, in answer to `04-audit-pr22.md` (verdict BLOCK on A4-1, medium). No subagents were used. Independent audit of the new head: not performed. Under provenance section 5.5 the new head needs a fresh audit of the whole range from the base to the tip; the audit pre-committed to a narrow one.

## 1. Identity

| Field | Value |
|---|---|
| Objective | Repair A4-1 (R1 code, R2 documents, R3 tests): a live process must never be read as absent |
| Repository | `evo-agi/Execution-Substrate` |
| Base | `trunk_dev` at `f62d0245e95e2b411be16511fc1bf9e1da727ce5` |
| Topic branch | `claude/project-thread-k69qcw-collector-process-names` |
| Audited commit | `64a0e0c27c2af9a4ea447cdfc727c988047572cf` |
| Repair commit, new head | `39a016cca06dfb10f8b4b64c9b614c8f20aaa1de`, parent `64a0e0c`, fast-forward push, no force |
| Tree | `84551691d0cfdb36d842cc7d790976ea7477bd4a` |
| Pull request | [#22](https://github.com/evo-agi/Execution-Substrate/pull/22) (draft) |
| Manifest (v2), base to tip | SHA-256 `1a8f223b57155e707c271e36c54b7a06314e32ac9581bb3a6e002c752ae4df51`, 5 files |
| Files touched by the repair | the collector, `PLANS.md`, the two Remote Alpha documents, the process identity test file (the same five files as the audited commit). Repair commit: 5 files, 458 insertions, 59 deletions. Whole range: 5 files, 928 insertions, 10 deletions |
| Final working-tree status | clean after the commit; the branch is pushed and equals its remote |

## 2. What the audit asked and what was done

| Audit item | Done |
|---|---|
| **A4-1.** "ESRCH means reaped" is false. During an exec from a thread other than the first, `/proc` can answer ENOENT or ESRCH, or a line with group ID -1, for a live process. A scan can then drop a live member | Repaired (section 3). Zero false absences under the auditor's probes (section 5) |
| **R1 (code).** ENOENT or ESRCH at open, ESRCH at read and a negative group ID never alone make a process absent. Absence needs a check that cannot fail for a live process; otherwise re-read a bounded number of times, then unproved | Done as specified, with `pidfd_open(pid, 0)` as the check. The design is the one of the audit's sketch; the differences are listed in section 3.3 |
| **R2 (documents).** Replace the old sentence in `PLANS.md`, `remote_supported_host_alpha.md`, `remote_alpha_access_contract.md`, the docstring and the pins of the documentation test | Done in all five places. The test now also refuses the old wording ("absent, not unproved", "no longer exists") in the three documents |
| **R3 (tests).** A deterministic test without root, red on `64a0e0c`: each unclear answer injected for a live child must not give absent, and for a reaped child must | Done: 43 cases fail on `64a0e0c` with the final test file (section 4). The optional root-only live test is not added; section 4.3 says why and what stands in for it |
| **P4-2.** Group ID -1 returned as a value | Closed by R1: a negative group ID is an unclear answer |
| **P4-1.** A child that ignores SIGTERM and keeps forking can escape the cleanup | Not in this PR. The coordinator made it the next PR of this thread, with containment by a control group as the direction |
| The coordinator's addition: a test with a live process that calls exec from a thread | Done: `TestRemoteAlphaESServiceTLSStatusProcessIdentityThreadExecStaysPresent` (section 4.2) |

## 3. The repair

### 3.1 The rule

`read_proc_identity(pid)` now has three parts, all in the section of the file that the documentation test reads.

1. `read_proc_stat_identity(pid)` does one bounded, no-follow read of `/proc/<pid>/stat`, as before. It returns the identity, or "this read did not show the process" for the four unclear answers: ENOENT or ESRCH at open, ESRCH at read, a line whose group ID is negative. Everything else is unchanged: any other open error, a line over 4096 bytes, a missing `<pid> (` prefix, and a missing or non-numeric field are unproved at once, and any other read error is raised as before.
2. `process_absent(pid)` asks `pidfd_open(pid, 0)`. ESRCH means no process has the ID: absent. EINVAL means the same on a kernel that answers so for a number that no process leads (section 3.2). A descriptor means a process has the ID: not absent, and the descriptor is closed with the same close accounting as every other descriptor of the collector. Any other error is unproved.
3. `read_proc_identity` reads, and after an unclear answer asks. If a process still has the ID it reads again, `PROC_IDENTITY_READS = 4` times in all, without a pause. If the fourth answer is still unclear it raises `process_identity_unproved`.

No caller changed. Every caller already treats an unproved identity as an incomplete scan: the cleanup holds and scans again, and the capability probe refuses before any spawn. That is the fail-closed side.

### 3.2 What `pidfd_open` answers, measured

Measured in the cloud container (kernel 6.18.44, Python 3.13.18), `stress/pidfd-answers.log`:

| Target | Answer |
|---|---|
| live child | descriptor |
| zombie (dead, not reaped) | descriptor |
| reaped, number unused | ESRCH |
| reaped leader whose group still has a member | ESRCH |
| reaped session leader whose session still has a member | ESRCH |
| first thread exited, another thread of the process lives | descriptor |
| thread ID of a live thread that is not the first | ENOENT |
| number above `pid_max` | ESRCH |

The audit measured 0 failures in 8,687,432 `pidfd_open` calls on a live process in an exec storm. That is the property the rule rests on.

**Inference from the kernel source, not measured:** kernels before about 6.15 answer EINVAL, not ESRCH, when the number still exists in the kernel only as a group or session ID, or as a thread ID. The supported host is Ubuntu 24.04. It started with kernel 6.8 and its later kernels are newer, so both answers can occur on supported hosts, and EINVAL must count as absent, as the audit's sketch has it. A thread ID that is not a process ID is never in the `/proc` listing that the scan walks, so EINVAL for it also means "no process has this ID". On 6.18 that last case answers ENOENT, which the rule treats as unproved. **Unknown:** the exact kernel of the Remote Alpha host. I could not measure there.

### 3.3 Differences from the audit's sketch

- The same rule and the same bound of four reads.
- The sketch returned a marker string for an unclear read. The repair returns `None` from an inner function whose docstring says it is never proof of absence, so no caller can meet a third kind of value.
- The repair refuses to run the confirmation when `os.pidfd_open` does not exist (`process_capability_unavailable`), where the sketch would raise an `AttributeError`.
- The repair is pinned by tests for every part (section 4).

### 3.4 Choices I made, with their reasons

- **Every other `pidfd_open` error is unproved**, including ENOENT, EPERM, EMFILE and ENOMEM. Only the two answers that mean "nothing has this ID" may release a member.
- **No pause between the reads.** The unclear state lasts for a moment inside one exec. A pause would slow every scan of a host with many short-lived processes for no gain: a process that has really ended is confirmed by the first `pidfd_open` and costs one extra system call.
- **The capability probe is not extended.** It already proves `pidfd_open` on a live child by behaviour. A kernel that answered differently for a reaped process would make reads unproved at use, which holds the run and fails closed. That matches the rule "unavailable or indeterminate behaviour is incomplete". Extending the probe would add a second behaviour check and change the fake backends of two other test files, with no safety gain.
- **A missing `<pid> (` prefix stays unproved at once**, as at the audited commit. The audit's fuzz expects that.

### 3.5 What the repair does not claim

- **One PID namespace.** `pidfd_open` looks the ID up in the collector's own PID namespace, like every signal call the collector makes. `/proc` must show the same namespace. That was already so for the signal calls.
- **An unrelated process that keeps calling exec from a thread can leave a read unproved.** It happened once in 918,125 reads under the auditor's storm with a fresh `/proc` instance per read, and never in the other 5.3 million. The result is one scan repeated, not a false absence.
- **Measured on one kernel** (6.18.44). The audit's uncertainty about older kernels stays, with the point that the rule no longer depends on how `/proc` behaves in that window.
- **P4-1 is open** until its own PR.

## 4. Tests

All in `remote_alpha_es_service_tls_status_process_identity_test.go`. None needs root. The live tests skip only when `/proc/self/stat` cannot be read, as before.

### 4.1 Deterministic cases

- **Injected answers with a fake `os`** (`…OpaqueNameBytes`): for each of the four unclear answers, six cases. `pidfd_open` says ESRCH: absent. It says EINVAL: absent. A process exists: unproved after exactly four reads and four closed descriptors. The stat file clears on the second read: the value, one confirmation. It clears on the last read: the value. Nine other `pidfd_open` errors: unproved. Further cases: another negative group ID, group ID 0 is a value, a failing close of the pidfd marks the closeout unproved, no `pidfd_open` on the host, the bound itself, and every other read error must not reach the confirmation at all.
- **Scans with a fake `/proc`**: a live member stays in the scan after each unclear answer, and a member whose answer stays unclear makes the scan unproved.
- **Injected answers for real processes** (`…LiveProcesses`, R3): the real `os`, with the answer for one stat path injected. For a live child the reader must not return absent, for each of the four answers. For a reaped child it must return absent. One more case: a reaped leader whose group still has a live member reads as absent while the scan still returns the member.
- **Documents** (`…DocumentsContract`): the new sentences in the three documents, the old wording refused, and four pins on the source.

Red on the audited collector `64a0e0c` with the final test file: 43 cases fail (`tests/newtests-on-64a0e0c-final-test-file.log`). 38 are in `…OpaqueNameBytes`: the injected answers and the scans with a fake `/proc`. 5 are in `…LiveProcesses`: each of the four unclear answers for a live child reads as absent or as group ID -1, and the negative group ID of a reaped child comes back as a value. `…DocumentsContract` fails too, at the first new sentence that it misses. The live test with a threaded exec passes there, for the reason of section 4.3, and so does the test of the first commit, which does not use this path. The count was 43 before the read-error cases were tightened as well (section 4.4): the audited collector passes those cases in both forms.

### 4.2 The live test with a threaded exec

`…ThreadExecStaysPresent` starts a process in its own session that calls exec from a thread other than its first, again and again. While at least 30 execs and 2,000 reads happen, the reader must never return absent and must return the same identity, and every scan of the group must contain the process. Then the real `prove_group_absent` runs against the group for ten more execs and must not return. After the process is killed and reaped it must return.

### 4.3 What this live test cannot do, and what stands in for it

The fault needs a cold lookup of the process directory during the exec. Without root a test cannot make lookups cold: after the first read the directory entry stays cached while the process lives. So the live test passes on the audited head too. It guards the path against a later change, and it is not the proof. The proof for the cold case is the audit's probe, which mounts a fresh `/proc` instance for each read or drops the caches, and needs root for both (section 5). I did not add the optional root-only test: on the CI runner it would always skip itself, and a test that skips itself must be on the list of the gate, where it would never run. The deterministic cases of 4.1 are red without root.

### 4.4 Mutants

39 mutants of the reader, each run against the new tests: 39 caught, all by a behaviour case, none only by a documentation pin (`mutants.log`). 19 are the mutants of the first report. 20 are new for the repair, among them: absent without confirmation, group ID -1 as a value, one read only, no bound, absent after the last read, a process that exists counts as absent, ESRCH or EINVAL not absent, every `pidfd_open` error absent, ENOENT absent, EPERM counts as existing, pidfd never closed, close failure swallowed, the confirmation asked once and trusted.

One mutant survived the first round: "every read error leads to the confirmation". The cases for read errors accepted any raised error. I tightened them (the confirmation must not be asked, and the error must be the injected one) and ran all 39 again.

## 5. Zero false absences under stress

Run as root in the cloud container with the auditor's probes, byte for byte (`stress.log` lists their SHA-256 and that of the helper binaries built from the auditor's sources). The collector under test is the committed file, SHA-256 `372161f1…b4ff`.

### 5.1 The real reader and the real scan against a live process in a thread exec storm (`esrch_collector.py`)

| Collector | `/proc` | Seconds | Reads | Read as absent | Group ID -1 returned | Unproved | Scans | Scans without the live process |
|---|---|---|---|---|---|---|---|---|
| `64a0e0c` (control) | fresh instance per read | 60 | 463,932 | **381** | 23 | 3 | 9,468 | **3** |
| repair | fresh instance per read | 120 | 918,125 | **0** | 0 | 1 | 18,737 | **0** |
| repair | `drop_caches` per read | 120 | 3,660,545 | **0** | 0 | 0 | 74,705 | **0** |
| repair | warm | 30 | 1,615,432 | **0** | 0 | 0 | 32,968 | **0** |

The control shows that the probe still finds the fault in this container.

### 5.2 The real `prove_group_absent`, pause removed (`prove_e2e.py`)

| Collector | `/proc` | Result |
|---|---|---|
| `64a0e0c` (control) | fresh instances | **returned after 11.4 s while the member was alive** |
| repair | fresh instances, three runs | did not return in 90 s, each time; the member was alive |
| repair | `drop_caches` | did not return in 90 s; the member was alive |

### 5.3 The audit's attack harness (`attack22.py`)

| Section | Result |
|---|---|
| S1 hostile names | ok: 776 names, 85 host processes |
| S2 forged members in a real `run_fixed` | ok: all four contained |
| S3 process states and exec storms | ok: no bad read in 145,177 reads under an exec storm from the first thread and 217,302 under one from another thread, nor in the other states |
| S4 staged kernel answers | ok |
| S5 churn, 20 s | ok: 1,079 scans, 0 bad |
| S7 fuzz of 200,000 lines against the old parser | differs on 165 lines, all of them lines with a negative group ID; 0 other differences, 0 wrong fields |

The harness prints S7 as "NOT OK" because any difference from the old parser counts. The audit recorded the same result for its sketch and called it "by design": the 165 lines are the kernel's -1 marker, which is now an unclear answer.

### 5.4 PID reuse (`pidreuse.py`, private PID namespace)

P1 and P2b are ok, and P3 behaves as in the audit's observation O4-2 (the proof holds while a process that reuses the leader's number lives, and returns after it is reaped).

## 6. Other validation

- **The new tests on the repair:** pass. Repeated 30 times idle and 30 times beside 8 CPU burners: 150 of 150 and 150 of 150 test runs pass (load checked at start and end). No process left behind.
- **Every root test named `TestRemoteAlphaESServiceTLSStatus…`:** 80 tests, 77 pass. The 3 that fail need another environment and are on the gate's list for that reason (`…FailureWitnessBootstrapOwnedTerminal`, `…RootLoadedStageCustody`, `…StageFIFOSubstitution`). They fail on the base too.
- **Whole root package, repair against the base `f62d024`:** one run each. Both end with exit 1 after 167 s, as every run of this package does in this container, because of the tests that need another environment. Repair: 2,240 tests with a verdict, 38 fail, none skips. Base: 2,235, 40 fail, none skips. All 38 failures of the repair fail on the base too. The 5 tests that exist only on the repair are the new ones, and all pass.

  **The base has two failures more, and they are not an effect of this PR.** They are `TestRemoteAlphaESServiceTLSStatusCombinedGroupSignalFailureLiveDescendant` and its subtest `term`, which failed in this one base run (2.15 s, with `descendant_gone`, `returned` and `leader_reaped`) and passed on the repair. **Inference, from the same signature:** it is the known timing-dependent fixture that PR #21 repairs. The fixture leaves a killed orphan to the container's first process, which reaps it after 1 to 1.9 s, against a bound of 2 s. Neither tree has PR #21's fix. This PR does not touch that test, and the fixture replaces `read_proc_identity`, the function this PR changes, by its own stand-in. So the two runs say nothing for or against this PR on that test, and no other verdict differs.
- `gofmt -l`: no output. `go vet .`: exit 0. `GOOS=darwin GOARCH=arm64 go vet .`: exit 0. The collector compiles (`py_compile`).
- **GitHub runner:** run [45097957121](https://github.com/evo-agi/Execution-Substrate/actions/runs/45097957121), job 137441913098, success (02:03:10Z to 02:15:43Z) on the merge commit `f91c203` of `39a016c` into `trunk_dev` at `f62d024`, Go 1.26.5 on linux/amd64. Build, both `go vet` runs and the gate's own 121 tests passed. The root package passed in 122.9 s, and the gate printed "test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed". The five new tests are not on the list, and the gate fails on a test that fails or that skips itself without a list line, so they ran and passed on the runner. The FAIL lines after the gate in the log belong to the step that runs the listed tests with nothing skipped and expects them to fail. The log is `runner/job-137441913098.log`.

## 7. Failed or skipped validation

- **Not run: macOS and the Remote Alpha host.** The audit did not ask for either. The collector's process handling needs `pidfd_open`, which macOS does not have.
- **Not measured: a kernel older than 6.15** (section 3.2).
- **Not added: the optional root-only live test** (section 4.3).
- **One mutant survived the first round** and is caught after a test was tightened (section 4.4).
- **The harness prints S7 as "NOT OK"**, as it did for the audit's sketch (section 5.3).
- No test of the repaired tree failed in any run, apart from the known tests that need another environment.

## 8. Other envelope fields

- **Reconnaissance:** I read the audit and its evidence (the sketch, the probes, the harness), the reader and its callers (the scan, the member signalling, the absence proof and the capability probe), and the three document passages. No subagents.
- **Implementation decision:** the audit's rule, with the choices of section 3.4.
- **Dependencies changed:** none. `pidfd_open` was already a required capability of the collector.
- **Artifact hygiene:** nothing was created in the repository. Probes, helper binaries, copies and logs were outside it.
- **Authority, security or protocol widening:** none. The change narrows when a process may be treated as gone. The collector makes one more kind of system call on a path it already had (`pidfd_open` was used for member signalling).
- **Cross-repo impact:** none.
- **Sensitive material:** none read or written. This report and its evidence were scanned with the project's leak scanner before delivery; the result is in the delivery message.

## 9. Provenance

- Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each run.
- Repair flow of section 5.5: the tip `64a0e0c` recorded, `git reset --mixed` to the base `f62d024`, upstream pinned to `origin/trunk_dev`, nothing staged, two runs, identical. Then `git reset --mixed` back to the tip, `git add`, the staged set was the manifest's five paths, one commit, clean status, fast-forward push of the topic branch only.
- Reproduced in a fresh clone from GitHub after the push: identical bytes.
- Textual diff SHA-256 `3bd7b520565e5bdd9c9d29eb54518001928b325b71138cc26873056570c3e493`.
- Canonical manifest SHA-256 `1a8f223b57155e707c271e36c54b7a06314e32ac9581bb3a6e002c752ae4df51`, 1,331 bytes, 5 files. Complete canonical manifest:

```json
{"branch":"claude/project-thread-k69qcw-collector-process-names","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/remote_alpha_access_contract.md","sha256":"5e26069ada93d8594971ee989f3047796f092a968181985d11141e6c8ec2f8e4","size":40585},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/remote_supported_host_alpha.md","sha256":"18b911fb147517f6fb9027840c2b5b1460a713e7c5f08047b5f9ff46bb5e011e","size":340483},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"2247b6dd235574548093257f1731d1b1d0c8ec0531739170e3eb184cdd67cfb1","size":305544},{"file_type":"regular","kind":"untracked","mode":"0644","path":"remote_alpha_es_service_tls_status_process_identity_test.go","sha256":"1d6b21e3be3b80a9ae845fe83d488e22c16c9653a6b27b95bcafca9d671d7106","size":39798},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"scripts/internal/remote_alpha_es_tls_status.py","sha256":"372161f1fecb3d618d6a69766a34092192eda6e7335365af8ec1bd05ffc1b4ff","size":141993}],"head":"f62d0245e95e2b411be16511fc1bf9e1da727ce5","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"3bd7b520565e5bdd9c9d29eb54518001928b325b71138cc26873056570c3e493","upstream":"origin/trunk_dev"}
```

## 10. Assumptions and unresolved points

- The EINVAL answer of older kernels is inference (section 3.2). If a kernel gave some third answer for a number that no process has, reads of ended processes would be unproved there and runs would hold. That would show at once on the host and is the safe side.
- The fixed `openssl` commands do not call exec from a thread (the audit's inference, which I share). The repair does not depend on it.

## 11. Confidence

- **Provenance: 0.99.** Five files, manifest reproduced in a fresh clone.
- **A4-1 closed on the measured kernel: 0.97.** Zero false absences in 6.2 million reads and 126,410 scans with the probe that found the fault, a control that still finds it, and an end-to-end check that holds.
- **Behaviour on the supported host's kernel: 0.85.** The rule rests on `pidfd_open` never failing for a live process, which follows from how the kernel replaces the process entry during exec, and on ESRCH or EINVAL for a number without a process. Not measured there.
- **Tests: 0.92.** 39 of 39 mutants caught by behaviour, after one gap was found and closed.

## 12. Delivery and effect status

- This file: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/05-repair-pr22.md`. Its SHA-256 is in the reply that delivers it.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/05-evidence/`, with a `README.md` and a `SHA256SUMS.txt`.
- Effect status: `TOPIC_BRANCH_PUSHED` (fast-forward, `39a016c`) | `DRAFT_PR_UPDATED` https://github.com/evo-agi/Execution-Substrate/pull/22 | `MERGE_NOT_PERFORMED` | `INDEPENDENT_AUDIT_OF_NEW_HEAD_NOT_PERFORMED`
