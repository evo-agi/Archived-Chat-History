# PROVENANCE RE-CHECK: Execution-Substrate PR #22 at `0a80ab7` (merge of `trunk_dev` `df46164` into the audited `da56d63`)

**Verdict: PASS. `0a80ab7` carries exactly the audited PR. The verdict of `13-reaudit3-pr22.md` (ACCEPT for `da56d63` on `bc9fe36`) carries over to `0a80ab7` on `df46164`.** This was a provenance-only check, at the coordinator's request of 13:54Z. It was read-only, and no subagents were used. Evidence: `16-provenance-pr22-0a80ab7-evidence/`.

| Check | Result |
|---|---|
| Remote state (13:55Z) | topic and `refs/pull/22/head` are `0a80ab78b8693d59185d5a10963ac358228e99ec`; `trunk_dev` is `df461642d2f7c9481873ca74b7eaaba368feb12f` |
| Shape | `0a80ab7` has two parents: `da56d63` (the audited head) and `df46164`. `bc9fe36` is an ancestor of `df46164`, so `trunk_dev` only moved forward, by `ea86a96` (PR #19) and `df46164` (PR #24). Tree `63ab1c59cde1de0c1d0eeb96723ec068c5492bba` |
| Merge | `git merge-tree --write-tree da56d63 df46164` gives `63ab1c59…`, the tip's tree. The merge is clean and adds nothing of its own |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before use |
| Manifest | tip checked out, `git reset --mixed df46164`, upstream `origin/trunk_dev`, two runs byte-identical: **`f225f340f30196eee8d36323d78351aec8e1de2207b8e2bda0afbad74c68e955`**, 8 paths, textual diff `73c9411a…a887`. It equals the writer's `f225f340…e955`. Against the audited manifest `e0abc4cc…3b4f`: 7 entries are identical, and `PLANS.md` differs. At the top level only `head` and `textual_diff_sha256` differ |
| Range-diff | `git range-diff bc9fe36..da56d63 df46164..0a80ab7`: `64a0e0c =`, `39a016c =`, `1032c9c =`, `f62eeef =`. The four PR commits are unchanged |
| PR patch across the move | `git diff bc9fe36 da56d63` and `git diff df46164 0a80ab7`, both without `@@` and `index` lines, have the same SHA-256 `69644e8f…9500`, and so does each of the 8 paths alone. The collector is still blob `16218b6c` (SHA-256 `372161f1…b4ff`). Of the 17 paths that `trunk_dev` changed, 16 keep `trunk_dev`'s blob at the tip. The 17th is `PLANS.md` |
| `PLANS.md` | `trunk_dev` changed one line near line 220. The PR adds 21 lines near line 2307. Applying the audited PR's `PLANS.md` patch to `df46164`'s `PLANS.md` gives the tip's `PLANS.md` byte for byte. The PR's content is unchanged, so the merge adds no semantic change to it |
| Build and vet | on an export of `0a80ab7`, as user `ci`, Go 1.26.5: `go build ./...` passes, `go vet ./...` passes, and `gofmt -l` on the three PR test files is clean |
| The PR's tests | the 6 local-boundary tests, the 4 process-identity tests and the unrelated-name test pass, 11 of 11 (`pr-tests-0a80ab7.log`) |
| Whole root package | on `0a80ab7` it takes 133 s, and on `df46164` 119 s. There is no timeout, no bound reached, no tripwire and no leftover process. The two trees share 2,238 verdicts and none differs; the 18 that exist only on the PR all pass. Both runs fail the same 14 top-level tests that need another environment, the same set as in the audit's runs of `da56d63`. Against the audit's plain run of `da56d63`, the tip shares 2,255 verdicts and none differs |
| CI | run [45188268060](https://github.com/evo-agi/Execution-Substrate/actions/runs/45188268060) on `0a80ab7`, job 137739488063 "build, vet and test", started 13:52:39Z and **still in progress at 14:01Z**. It is not part of this verdict. The merge still needs it green, and the ruleset on `trunk_dev` requires that check |

**Remaining before the merge.** The Mac run, which is the writer's and David's step. The coordinator has set aside O13-5 (co-author trailers): ES keeps its standard trailers. If `trunk_dev` moves again, run this check again.
