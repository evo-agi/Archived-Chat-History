# Evidence for 17-provenance-pr22-8ce6b73.md

Provenance-only re-check of ES PR #22 at `8ce6b73` (merge of `trunk_dev` `200fd60`, PR #23, into `0a80ab7`), and the question whether PR #23's `TestMain` changes which collector code paths the PR's tests reach. Cloud container, Go 1.26.5, Python 3.13.18, user `ci`. Files ending in `.txt` after another extension are scripts kept as text.

| Path | What it is |
|---|---|
| `provenance-r22f.sh.txt`, `provenance-r22f.log` | remote state, parents, clean trial merges, PR patch per path across the base move, range-diff, manifest v2 twice, comparison with the audited and the `0a80ab7` manifests |
| `manifest-8ce6b73.json` | the manifest, SHA-256 `22b1b458c3d79b0c02e3e0696e04dbbe9bd0c250b2f0d414ff8af85d7a231e1c` |
| `range-diff.txt`, `docs-check.txt` | range-diff; where each side changes the two shared documents, and the byte-for-byte checks |
| `trace/audit_trace_collector.py.txt`, `.pth.txt`, `audit_no_proc_pidfd.py.txt`, `hooks-installed.txt`, `hooks-removed.txt` | the audit-only tracer and emulation, their installation and removal |
| `trace/trace-*.log.gz`, `trace/reach.py.txt`, `trace/reach.txt` | the six traces and the reach comparison |
| `runs/runs-f.sh.txt`, `runs-f.summary`, `verdicts-A-vs-B.txt` | the six traced whole-package runs (A to F) |
| `runs/runs-plain.sh.txt`, `plain.summary`, `pr-tests-8ce6b73.log`, `verdicts-plain-8ce6b73-vs-200fd60.txt` | plain runs without any hook variable, and the PR's tests |
| `runs/confirm-notrace.sh.txt`, `confirm.summary` | the three reach-changed tests and the four tracer-affected tests alone, emulated, symlinked TMPDIR, without the tracer |
| `runs/*-verdict-lines.txt.gz`, `compare-verdicts.py.txt` | verdict lines of every whole-package run, and the comparison script |
| `SHA256SUMS.txt` | SHA-256 of every file here |
