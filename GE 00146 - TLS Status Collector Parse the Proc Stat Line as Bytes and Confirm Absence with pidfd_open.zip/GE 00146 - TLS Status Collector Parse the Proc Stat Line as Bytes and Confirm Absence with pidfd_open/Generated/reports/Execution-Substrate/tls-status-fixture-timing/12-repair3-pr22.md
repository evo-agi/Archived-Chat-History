# REPAIR REPORT 3: Execution-Substrate PR #22, the guard also refuses a faked probe before an entry point

**Outcome: the three low findings of the audit of `1032c9c` (A11-1, A11-2, A11-3) are repaired, with tests and one document only. The collector is unchanged. `trunk_dev` moved while the repair was written (PR #20 merged), so `trunk_dev` is merged into the branch on top of the repair, without conflict. New head `da56d63`, pushed as a fast-forward. The Mac run and the merge are still open, and the new head is not yet audited.**

Written 2026-11-23 by the writer thread of PR #22, after the coordinator's request of 04:55Z. No subagents were used. Independent audit of the new commits: not performed.

## 1. Identity

| Field | Value |
|---|---|
| Objective | Repair A11-1 (guard misses a probe stand-in followed by `main()` or `diagnostic_main()`), A11-2 (the shared constant needs the fixture's `os`), A11-3 (default bound and name list not pinned); harden step 6 of the Mac brief |
| Repository | `evo-agi/Execution-Substrate` |
| Base | `trunk_dev` at `bc9fe3619823245faf550db4bf1bc3e782fbd5a5` (PR #20, commit date 05:22:45Z; the earlier base was `110d377a459471e94aa14cc83877f554ae62f893`) |
| Topic branch | `claude/project-thread-k69qcw-collector-process-names` |
| Audited before | `39a016c` ACCEPT (`08-reaudit-pr22.md`); `1032c9c` BLOCK on three low findings in tests (`11-reaudit2-pr22.md`, sha256 `7474da81dacc8b2f51ff7a07886b1c02c420f68c69ea4eb992c81e4526ea6e4d`) |
| Repair commit | `f62eeefd967d6e368ae26fd456c95f1d87a55f6d`, one commit on `1032c9c`, tree `d7b826be5f88ed1dd2125012e6292450a89c60e7` |
| New head | `da56d63d2008930daf08d5ba8344e6af1e173072`, the merge of the repair commit (first parent) with `trunk_dev` at `bc9fe36` (second parent), no conflict. Tree `d4482ce5184b833a1eb4784fa290395ffed724e0`. Fast-forward push, no force |
| Pull request | [#22](https://github.com/evo-agi/Execution-Substrate/pull/22) (draft), description updated for the new head |
| Manifest (v2), base to head | SHA-256 `e0abc4cce9feaa0a9e52636e7c5c384fc74cde33602f715861fc7d400a4c3b4f`, 1,956 bytes, 8 files, textual diff `741e6c52a4e3134571969154093e479417334aab1ceabf28973811285da56791` |
| Files touched by the repair commit | `remote_alpha_es_service_tls_status_local_boundary_test.go`, `remote_alpha_es_service_tls_status_test.go`, `.docs/system_overview/capability_probing.md`. 3 files, 363 insertions, 61 deletions. `git diff 1032c9c f62eeef` has sha256 `5abf1560cfc43757e0bd4c2b48f6fffc00d475669c7219d1fc707840be9e60ce` |
| Files not touched | the collector `scripts/internal/remote_alpha_es_tls_status.py` (blob `16218b6c`, equal to the audited one), the process identity test file and the two Remote Alpha documents |
| Final working-tree status | clean; the branch is pushed and equals its remote |

## 2. The findings and what was done with each

| Finding | Done |
|---|---|
| **A11-1.** The guard does not see a script that replaces the probe and then runs `main()` or `diagnostic_main()`. The entry points run the probe and set the capability flag themselves, so this is the flag set by hand | New guard rule and a test that holds the rule's call paths against the collector's source (4.1, 4.2). The auditor's shapes G1 and G2 are now refused and are in the sample table |
| **A11-2.** The shared constant used the fixture's `os`. In a fixture without `import os` it raised a NameError where status 97 or 98 was meant | The constant imports `os`, `signal` and `faulthandler` itself, under names of its own. Three new cases run it in a script that does not import `os` (4.3) |
| **A11-3.** Two mutants survived: default bound `120.0` to `0.0` (Y3), and `PROCESS_CAPABILITY_READY` taken out of the guard's name list (Y9) | A case reads the armed timer and pins the default bound. Each name of the list is pinned by one refused script that holds only that name (4.4) |
| O11-1 (list G3, G7, G8 and `setattr` under the limits) | `setattr` with a literal name is now a known way of replacing, so G4 is refused. G3, G7 and G8 are stated as limits in the guard's header comment and in section 7 |
| O11-2 (the document validator accepts any nonzero exit) | No action, as the audit says: it is older than PR #22 |
| O11-3 (Mac brief step 6) | New brief `12-evidence/mac-instructions-5.txt` with the guarded form (section 9) |

## 3. What the coordinator asked

> Repair: A11-1 extend the guard to fixtures that fake the probe then call main()/diagnostic_main() (rule accepting all 45 current ones); A11-2 the constant imports os itself; A11-3 pin bound>0 and the full name list. Also harden Mac step 6 per section 8 (refuse empty/non-literal T). Mac run waits for the repaired head; tell David the "go ahead" request is for the new head.

All four parts are done. One thing was not asked and was needed: the merge of `trunk_dev` (section 5).

## 4. The repair

### 4.1 The guard rule (A11-1)

The guard now also looks for `validate_process_capability` and `ProcessCapabilityBackend` by name. A script is refused when it

- replaces the probe, or the backend class from which the real probe takes its operations, and
- names `main` or `diagnostic_main` as something of the collector (called or not, also through `getattr` or a namespace entry), and
- leaves a path from that entry point to the fixed command real, and
- does not replace the whole boundary.

A path is cut when the script replaces `run_fixed`, or the function directly below the entry point (`collect` for `main`, `diagnose_first_rejection` for `diagnostic_main`), or all three of `cert_role`, `key_pair` and `verify_chain`. This is the rule of section 5.3 of the audit, in the form of its text (a stand-in for `collect` does not cut `diagnostic_main`).

On the new head the guard judges 141 scripts. 46 replace the probe: 29 with the whole boundary and 17 without. Of the 17, 15 name an entry point, and each of the 15 cuts every path. No script is refused. The audit counted 45 probe-replacing scripts on `1032c9c`. The 46th is one new test script of this repair (measured with the audit's own criterion on a dump of the new head: 46).

### 4.2 The call graph test (new)

The rule is only right while the collector's functions reach the fixed command the way the rule assumes. `TestRemoteAlphaESServiceTLSStatusLocalBoundaryKnowsTheCallGraph` parses the collector's source (it does not import it) and holds, for 17 names (16 functions and the backend class): which top-level definitions name each one; that none of them is held as text or reached as an attribute; that the only statement outside the definitions that names one is the program entry `sys.exit(main(sys.argv[1:]))`; that the capability flag is set to true only in `main` and `diagnostic_main`; and that nothing else writes it. A change of the collector that opens a new path to `run_fixed`, a second name for `main`, or a new place that sets the flag fails this test, and the rule has to be read again in the same change.

### 4.3 The shared constant (A11-2)

Its first line is now `import faulthandler as _faulthandler,os as _os,signal as _signal`, and every use goes through these names. No fixture of the package binds `_os`, `_signal` or `_faulthandler`. `TestRemoteAlphaESServiceTLSStatusLocalFixtureFailsBounded` has three new cases in a script that asserts `"os" not in globals()`: an overdue hold ends with 98, a reached target-only reader ends with 97, and the whole boundary completes. The test also fails if any output contains `NameError`.

### 4.4 The pins (A11-3)

- Case "default bound": a script without `LOCAL_FIXTURE_BOUND` reads `signal.getitimer(signal.ITIMER_REAL)` after the constant and requires more than 100 s and at most 120 s left, with no repeat interval.
- `TestRemoteAlphaESServiceTLSStatusLocalBoundaryPinsItsNames`: the list of 11 names that decide whether a script is judged, and a map with one refused script per name that holds only that name. A name that leaves the list fails this test. The scan of the package and the sample table now both judge through the same function, `remoteAlphaESStatusGuardVerdict`, so the filter by name is part of what the samples test.

### 4.5 The document

`.docs/system_overview/capability_probing.md`, "Test Harness Use": one sentence that the constant imports what it uses, and one paragraph with the rule for a stand-in of the probe. The document test checks five phrases of it.

### 4.6 Choices I made, with their reasons

- **The audit's rule, not the stricter one ("a probe stand-in requires the whole boundary or a stand-in for `run_fixed`").** Of the 17 current fixtures that replace the probe without the whole boundary, 4 replace `run_fixed`. The stricter rule would refuse the other 13: 11 that cut the paths with `collect`, `diagnose_first_rejection` or the three checks, and 2 that run no entry point, so that the flag stays false. They would have to change without a reason of their own. The weaker rule depends on the call graph, which is why 4.2 exists.
- **An entry point counts when it is named, not only when it is called.** `run=m.main` followed by `run([])` is the same thing.
- **The call graph is pinned by parsing, not by a list of line numbers,** so that edits inside a function do not fail the test and a new caller does.

## 5. `trunk_dev` moved: the merge

When I took the manifest, `origin/trunk_dev` was no longer `110d377`: PR #20 had merged (`bc9fe36`, 19 files). ES requires an up-to-date branch, and the gate needs a manifest against the current `trunk_dev`. So I committed the repair on `1032c9c` and merged `trunk_dev` on top, as for PR #21 before (no rebase).

- No conflict. Two documents are changed by both sides, `PLANS.md` and `.docs/system_overview/capability_probing.md`, in separate places.
- The PR's own patch is unchanged by the merge: the diff of the repair commit against the old base and the diff of the new head against the new base are the same text when hunk positions are left out (sha256 `ba61df4b1af05d87137c3f5d2ac26586e8b3679174626293f18830132d41f788` for both).
- The six PR files that `trunk_dev` did not change have the blobs of the repair commit. The 17 files that only `trunk_dev` changed have the blobs of `trunk_dev`.
- Against the manifest of the audited `1032c9c`: the collector, the process identity test and the two Remote Alpha documents have the same SHA-256. `PLANS.md` differs only by the merge. `capability_probing.md` differs by the merge and the repair. The two test files differ by the repair.

All of this is in `12-evidence/gate/fresh-clone-repair.log`, from a fresh clone.

## 6. Validation (cloud container, kernel 6.18, Go 1.26.5, test user with an emptied environment)

| Check | Result |
|---|---|
| The six `…Local…` tests on `da56d63` | pass (9.5 s). `12-evidence/tests/local-tests-da56d63.log` |
| The auditor's shapes G1 to G8, judged as the package scan judges a script | G1, G2 refused by the new rule. G4 refused (`setattr`). G5, G6 refused as before. G3, G7, G8 accepted: stated limits (section 7). `12-evidence/guard/` |
| The auditor's three `os` demos with the repaired constant | all three end with status 98. On `1032c9c` the two without `os` ended with status 1. `12-evidence/demo/` |
| Mutants, on the pushed head | 68 of 68 caught, and the unmutated tree passes. They are: the default bound set to 0 (Y3 of the audit) and to a day (2); each of the 11 names taken out of the list, alone (this includes Y9 of the audit) and together with its pin (22); the new rule switched off (1); the constant put back on the fixture's `os` (1); the rule's cuts, entry points and probe stand-ins weakened or removed (18); `setattr` forgotten (3); changes of the collector's call graph or flag, for the new test (9); and the 12 mutants of the second repair. `12-evidence/mutants/summary-pushed-head.txt` |
| Whole root package, repair commit against `1032c9c` | the same verdict for each of the 2,247 common tests and subtests. The same 8 top-level tests fail on both, for environment reasons. The 6 new tests and subtests pass |
| Whole root package, `da56d63` against `trunk_dev` at `bc9fe36` | the same verdict for each of the 2,237 common tests and subtests. The same 8 top-level tests fail on both. 18 tests and subtests exist only on the head, and all pass |
| Format, build, vet | `gofmt` clean for the two test files; `go build ./...` and `go vet ./...` pass; `go vet .` passes for `GOOS=darwin GOARCH=arm64` |
| CI gate self-check | 121 tests pass on the merged tree |
| CI | run [45119601098](https://github.com/evo-agi/Execution-Substrate/actions/runs/45119601098) is green on the merge of `da56d63` into `trunk_dev` at `bc9fe36`. Gate line: "test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 41 tests skipped themselves, all of them listed". `12-evidence/ci-da56d63/` |
| Manifest | taken twice in the writer's checkout before the push, identical; reproduced twice in a fresh clone of the pushed head, identical to it |

## 7. Limits

- The guard reads the text of a script and judges it as a whole. It does not follow control flow. It knows four ways of replacing: an assignment, `setattr` with a literal name, `mock.patch.object`, and a namespace entry. It does not see a name that is computed or joined from parts.
- Whatever is assigned counts as a stand-in. The guard does not see that a script assigns the real function back (G3, G8) or assigns on an unrelated object (G7). These three shapes of the audit are still accepted.
- A script that changes the collector's source as text before running it is outside what the guard can judge.
- The call graph test looks at names. It does not see a call that is built at run time from parts of a name.
- The behaviour tests (the boundary with `/proc` and pidfd denied, and the bounded failure) do not depend on the guard.

## 8. Failed or skipped validation

- **Not run on macOS.** The run is prepared (section 9) and waits for David.
- **Not audited.** The repair commit and the merge need the narrow re-audit.
- The 8 failing top-level tests of the root package need another environment. They fail the same way on `trunk_dev` and are on the CI list of environment-only tests.
- A first pass of the mutants ran on the working tree before the last small change of the call graph test: 67 caught, and one that did not compile and was rewritten. The run on the pushed head, reported above, replaces it, and its log folder was reused, so the first summary is not in the evidence. A second pass of 10 mutants on the repair commit's tree is in the evidence.

## 9. The Mac brief

`12-evidence/mac-instructions-5.txt` replaces `10-evidence/mac-instructions-4.txt`. Changes:

- Head `da56d63` with its tree, and `trunk_dev` at `bc9fe36` for the comparison.
- Three guard lines begin every command of steps 2 to 9: `T` is the literal path that step 1 printed, a `case` refuses anything that is not `/Users/ds/Repositories/Playground/es-mac-run.` plus six characters, and `test -d` refuses a path that does not exist. This also covers the removal in step 9.
- Step 6 matches `"$T/"` with `grep -F --`, and ends a process only by its number and only after checking its command line again. If a leftover shows, a second listing of the user's `python3` and `openssl` processes is reported and nothing in it is ended.
- Step 4 expects six tests.

David's "go ahead" in the writer thread is for this brief and this head.

## 10. Provenance

- Recipe v2, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before each of the four runs.
- Writer's checkout: tip recorded, `git reset --mixed` to the base `bc9fe36`, upstream pinned to `origin/trunk_dev`, manifest twice (identical), reset back to the tip, status clean, fast-forward push `1032c9c..da56d63`.
- Fresh clone: pushed tip is `da56d63`; its parents are `f62eeef` and `bc9fe36`; `f62eeef` is one commit on `1032c9c`; manifest twice, identical to the writer's.
- Per section 5.4 of the provenance guide the new head needs a fresh audit of the delta, and if `trunk_dev` moves again before the merge, a new manifest and a provenance re-check.

## 11. Assumptions and unresolved points

- Inference: `/usr/bin/python3` on David's Mac is new enough for `ast.get_source_segment` (Python 3.8). Earlier Mac runs loaded the collector with it. The Mac run will show it.
- Unknown: whether `trunk_dev` moves again before the merge.

## 12. Confidence

High that the three findings are closed as the audit describes them: each has a test that fails on the old code, and the mutants that the audit named are caught. Medium-high for the rule as a whole, because a text guard has the limits of section 7.

## 13. Delivery and effect status

- Pushed: `da56d63` on the topic branch (fast-forward). PR #22 description updated.
- Not merged. No comment posted on GitHub. Nothing ran on David's Mac or on the Remote Alpha host.
- Evidence: `12-evidence/` with `SHA256SUMS.txt`. Leak scan of the report and the evidence: 0 findings.
- Next: narrow re-audit of `1032c9c..da56d63`, the Mac run after David's go ahead, then the merge gate.
