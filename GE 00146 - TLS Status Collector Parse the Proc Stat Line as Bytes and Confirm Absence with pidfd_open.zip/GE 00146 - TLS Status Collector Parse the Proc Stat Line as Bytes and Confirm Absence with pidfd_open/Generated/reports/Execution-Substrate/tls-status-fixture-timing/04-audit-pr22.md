# INDEPENDENT AUDIT REPORT: ES draft PR #22, the TLS status collector reads process names as bytes

Verdict: **BLOCK** (one patch defect, A4-1, medium). Evidence: `04-audit-pr22-evidence/`.

## Summary for the coordinator

The byte parsing is sound. No process name, however hostile, changed a result. That covers every byte value, forged stat tails, parentheses, newlines, 15-byte and kernel-thread names, and members that rename themselves inside a real `run_fixed`. Zombies, stopped, traced, running, `D`-state and vfork-parent processes never read as absent.

The ESRCH inference is wrong, though. The kernel answers ESRCH, at open and at read, for a process that is alive. This happens when the collector looks up that process's `/proc` entry while one of its non-leader threads calls exec. The head reader reports that live process as absent. The base reader left it unproved.

The same kernel race also produces ENOENT, which the base already counted as absent, and a stat line whose group ID is `-1`. So the absence rule was already unsound at base. This PR widens it and writes it into three contract documents as "the process that the scan listed no longer exists".

End to end, the real `prove_group_absent` returned while a live member of the group was running in 7 of 7 head runs. Base did the same in 6 of 6. A repair sketch held for the full time in all of its runs. In the sketch, absence needs `pidfd_open` to confirm that no process has that ID. It had 0 false absences in 6.2 million reads, and the writer's tests pass on it.

Practical reach is narrow. It needs a member that calls exec from a second thread, and the fixed child is `/usr/bin/openssl`. But this is exactly the "non-absent case read as gone" that the audit was asked to rule out.

One separate pre-existing escape is not caused by this PR: a SIGTERM-ignoring fork relay. With a PID 1 that reaps at once, like systemd, `run_fixed` returned a normal result while the relay was still alive: 5 of 40 runs at head and 3 of 40 at base.

## Envelope

```text
INDEPENDENT AUDIT REPORT
Repository: evo-agi/Execution-Substrate
Audit target: base f62d0245e95e2b411be16511fc1bf9e1da727ce5 (trunk_dev), topic commit
  64a0e0c27c2af9a4ea447cdfc727c988047572cf (claude/project-thread-k69qcw-collector-process-names,
  draft PR #22, head on GitHub = this commit), tree 1d1f1fed9b5d3e484ce87aaff8b610647b75df3b,
  recipe governed-execution.audit-patch-manifest.v2, source SHA-256
  c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified),
  canonical manifest 263df6309ee3ed97e3aa17b2356c7051b0292a49d676ee9985ae6e44e53b8351,
  textual diff f1d2d57b83e519109f6257e1a329721d6e21fd28bdc56be35ba8ca97bb72a4fa, 5 changed paths
Writer report: 03-collector-process-name-fix.md, sha256 fdffc73b5b70285a737c7778266ae3de7a890ef7e0df417052b2d35ecc930b3a (verified)
Audit posture: read-only. No subagents (deviation from protocol 13.2 step 3: project rule is
  subagents only when asked). All work on scratch exports (/opt/audit/h22 head, /opt/audit/b22 base,
  /opt/audit/s22 sketch) and on processes this audit started and reaped. No repair, commit, push,
  PR comment, review or merge.
Provenance reproduction: fresh clone; HEAD reset to base, upstream origin/trunk_dev; recipe run twice
  at open and twice at close; open-1 = open-2 = close-1 = close-2 = 263df630...8351 (byte-identical).
  No mode-bit tolerance needed.
Final verdict: BLOCK
```

## 1. Coverage

- **Governing docs:**
  - the new passages in `PLANS.md` (2259-2273), `remote_supported_host_alpha.md` (3552-3567) and `remote_alpha_access_contract.md` (198-204);
  - the cleanup contract they refine ("No outer retry may return until group absence and exactly one direct-child reap are proved", `remote_supported_host_alpha.md` 3533; `remote_alpha_access_contract.md` 194-196).
- **Source:**
  - `read_proc_identity`, `scan_group_members`, `signal_same_group_members`, `prove_group_absent`, `terminate_child`, `own_child_until_proved`, `run_fixed`, `validate_process_capability`, `waitid_terminal`;
  - head collector sha256 `e41e8566…424c`, base `10a0d13e…b008`.
- **Tests:** the new file `remote_alpha_es_service_tls_status_process_identity_test.go` (4 tests). Also the root package on base and head.
- **Writer evidence:** report sections 3, 6, 8 and 11; check run 45085828879 (job 137404090541, success, 23:55-00:08Z).
- **Kernel behaviour:** measured live on this container's kernel 6.18.44. The mechanism in A4-1 is an inference from kernel source as I know it, consistent with every measurement; it is marked as such.
- **Not inspected:** the Remote Alpha host itself and its kernel; the `ps`-based boundary script the writer mentions; macOS (not needed: the collector runs only on Linux).

## 2. Findings

### Patch defect

```text
AUDIT FINDING
ID / Type / Severity: A4-1 / safety (absence proof) / medium
Current contract: "No outer retry may return until group absence and exactly one direct-child reap
  are proved" (remote_supported_host_alpha.md 3533; remote_alpha_access_contract.md 194-196). The PR
  adds: "A process that ended before its stat file could be opened or read, reported as ENOENT or
  ESRCH, is absent, not unproved: the process that the scan listed no longer exists"
  (remote_supported_host_alpha.md 3559-3562; PLANS.md 2265-2267; access contract 200-202; docstring).
Path and line: scripts/internal/remote_alpha_es_tls_status.py:830 (ESRCH at open -> None),
  :837 (ESRCH at read -> None); consumers :871 (scan drops None), :985/:998 (bounded wait skips
  SIGKILL when the scan shows only the leader), :939 (prove_group_absent returns).
Patch defect or pre-existing issue: patch defect (ESRCH made absent; the false rule written into
  three contracts). The same kernel race also yields ENOENT (absent since base) and a pgid -1 line
  (pre-existing, P4-2); both are in the repair scope below because the documented rule needs them.
```

**Evidence.** The target in every measurement was the audit's own child, so its PID could not be reused before the audit reaped it. It ran an exec loop from a non-leader thread (`execstorm thread`). An outcome was counted only if the target was still not terminal (`waitid` WNOWAIT) after the read.

- **Kernel answers (C probe, `c-probes.log`):**
  - Warm `/proc` dentries: 0 ENOENT or ESRCH in 4,142,972 reads.
  - Cold lookups, with `drop_caches` before each open on the host `/proc`: 2 ENOENT at open and 1 ESRCH at read in 3,007,492 reads.
  - A fresh proc instance per read: 10 ESRCH at open, 17 ESRCH at read and 27 ENOENT at open in 256,021 reads.
  - The target was alive for all of them.
- **The real reader** (`read_proc_identity(target)`, `esrch-*.json`):

| Lookups | Collector | Calls | Live process returned as absent | pgid `-1` returned | Unproved |
|---|---|---:|---:|---:|---:|
| fresh proc per call, 60 s | head | 621,858 | **224** | 45 | 1 |
| fresh proc per call, 60 s | base | 615,588 | 80 (ENOENT) | 24 | 109 (32 `Incomplete`, 77 raw `ProcessLookupError` = the ESRCH reads) |
| host /proc + drop_caches, 120 s | head | 5,937,134 | **165** | 144 | 2 |
| host /proc + drop_caches, 120 s | base | 5,041,316 | 63 (ENOENT) | 71 | 65 (23 + 42 raw ESRCH) |
| host /proc warm, 30 s | head | 2,792,559 | 0 | 14 | 0 |
| fresh proc per call, 60 s | sketch | 446,278 | 0 | 0 | 0 |
| host /proc + drop_caches, 120 s | sketch | 5,755,460 | 0 | 0 | 2 |

- **Scans of the target's group that left out the live target:**
  - head: 6 of 12,690 with a fresh proc instance per call, and 8 of 121,166 with the host `/proc` plus `drop_caches`;
  - base: 3 of 12,563 and 7 of 102,884;
  - sketch: 0 of 9,107 and 0 of 117,458.
  - Side note: the base scans with the host `/proc` also raised 26,780 times while the writer's tests ran concurrently with non-ASCII-named processes. That is the original defect PR #22 fixes, seen live.
- **End to end** (`prove_e2e.py`, `prove-e2e-*.json`): the real `prove_group_absent(G)` ran with only its 50 ms pause removed, while a second thread kept the lookups cold. G's only member was alive throughout, so the function must never return.
  - head returned in 7 of 7 runs: 0.03 to 1.86 s in 6 runs with a fresh proc instance, and 0.49 s in 1 run with `drop_caches`;
  - base returned in 6 of 6, all with a fresh proc instance: 0.10 to 11.58 s;
  - the sketch held 90 s with a fresh proc instance and 60 s with `drop_caches`, then was stopped.

**Mechanism (Inference from kernel source, consistent with the above).** `proc_pid_lookup` finds the task for the TGID, then `proc_pid_make_inode` reads that task's `thread_pid` a little later. If a non-leader thread is in `de_thread` at that moment, `exchange_tids` has already given the old leader the exec'ing thread's TID. The new inode is then bound to that TID, and the old leader is released moments later. From then on:

- the permission check gives ESRCH at open;
- the `stat` lookup gives ENOENT;
- `proc_single_show` gives ESRCH at read.

All of this happens while the process with that PID keeps running. If the read lands before the release, the line carries the TID as its prefix. The PR's prefix check correctly makes that unproved; those are the head's 1-2 unproved reads. A read whose task is released mid-read prints `do_task_stat`'s default pgid `-1` (P4-2).

The writer's section 3 reads ESRCH as "that process is no longer attached to its PID, which happens when it is reaped". The binding can be to the wrong struct pid, so that does not hold. Warm dentries do not trigger it. Cold lookups happen on the first lookup of a PID and after dentry reclaim.

**Impact.** A live member can be left out of a scan, with three effects:

1. During the bounded wait, a scan that shows only the leader counts as resolved, so SIGKILL is never sent (`:998`).
2. After reap, `prove_group_absent` returns `False` on a scan that misses the member (`:939`). `run_fixed` then returns a normal result and the caller releases the status lock while a member of the fixed child's group still runs.
3. The PR's measured rate of false absences is 2.6 to 2.8 times the base's, and the PR makes the rule a documented contract.

**Reach.** This needs a member that calls exec from a non-leader thread during a cold lookup. Inference, not measured: the fixed `openssl verify` and `x509` invocations do not do that. So no supported run is known to reach it. A hostile or unusual descendant can, and such a descendant already runs as root. That is why the severity is medium, not high: it is a regression of a documented safety property with a narrow trigger.

**Required correction (repair scope R1-R3).**

- **R1 (code).** None of these alone may make a listed process absent:
  - an ENOENT or ESRCH at open;
  - an ESRCH at read;
  - a stat line with a negative group ID.

  Absence needs a check that cannot fail for a live process. Measured candidate: `pidfd_open(pid, 0)` failing with ESRCH, or EINVAL. It had 0 failures in 8,687,432 calls on the exec-storming live process, and answered ESRCH for a reaped process and for a reaped leader whose group still had a member. It does not walk `/proc`. Otherwise re-read a bounded number of times, and if the answer is still ambiguous, report unproved. The writer chooses the design.

  Audit sketch for reference: `sketch-reader-confirmation.diff`, built by `make_sketch22.py.txt`. With it, all the hostile-name, forged-member, state, kernel-staging and churn sections pass:
  - S1: 776 names and 80 host processes;
  - S2: 4 forged members contained;
  - S3: no false absence, including 290,524 reads under a thread exec storm;
  - S5: 15,371 churn scans with 0 bad results, so the PR's availability goal holds.

  The fuzz differs only on the 165 lines carrying the negative-pgid sentinel, by design. The writer's 4 tests pass 5 of 5.
- **R2 (docs).** Replace "ENOENT or ESRCH … is absent … no longer exists" with the confirmed rule in:
  - `PLANS.md`;
  - `remote_supported_host_alpha.md`;
  - `remote_alpha_access_contract.md`;
  - the docstring;
  - the `DocumentsContract` pins (test line 454).

  Say that the kernel can answer ENOENT, ESRCH or a pgid `-1` line for a live process during an exec from a non-leader thread.
- **R3 (tests).** Add a deterministic test that does not need root and is red on 64a0e0c:
  - injected ENOENT or ESRCH at open, ESRCH at read, and an injected pgid `-1` line, all for a live child, must not give absent;
  - the same for a reaped child must give absent.

  The existing injections use PIDs with no process, so they cannot tell the difference. Optionally, add a root-only live test that skips without privilege, built from an exec storm plus a private proc mount per read.
- **Re-audit, pre-committed as narrow:**
  - the repair delta and provenance;
  - `esrch_collector.py` with fresh proc instances and with `drop_caches`;
  - `prove_e2e.py`;
  - harness S1-S7;
  - the writer's tests.

**Uncertainty.** Measured on this container's kernel 6.18.44, not on the host's kernel. Unknown whether older kernels order `exchange_tids` and `proc_pid_make_inode` the same way. The sketch removes the dependency either way.

### Pre-existing issues (not introduced by this PR)

```text
AUDIT FINDING
ID / Type / Severity: P4-1 / safety (cleanup escape) / medium
Current contract: same as A4-1.
Path and line: terminate_child :996-1001 (leader already terminal -> 0.05 s TERM grace; one scan that
  shows only the leader skips SIGKILL), prove_group_absent :931-944.
Evidence: relay_demo.py with the real run_fixed; the fixed child starts a SIGTERM-ignoring fork relay
  (each generation forks its successor and exits). With a PID 1 that reaps at once (private PID
  namespace, nsinit), run_fixed returned (0, b'fixed', b'') while the relay was still alive in
  5 of 40 runs at head and 3 of 40 at base (checked by signal 0 to the group 0.2 s and 0.5 s after
  return). In this container (PID 1 reaps on a ~1 s tick, so relay zombies stay visible) 0 of 20.
Impact: a TERM-ignoring member that keeps replacing itself is never seen alive by a /proc snapshot,
  so the cleanup never sends SIGKILL and proves absence while the group lives; on a systemd host.
Required correction: not this PR's scope; needs its own item (project rule: a deferred edge needs a
  machine-enforced trigger). Pointer, Inference: once the leader is terminal and reserved by WNOWAIT,
  send killpg(SIGKILL) unconditionally before any scan-based decision; killpg is atomic with respect
  to fork and the reserved leader keeps the number, so the scans then only confirm.
Patch defect or pre-existing issue: pre-existing (base and head).
Uncertainty: reach needs a hostile descendant (openssl does not fork here, Inference).
```

```text
AUDIT FINDING
ID / Type / Severity: P4-2 / safety (absence proof) / low on its own, folded into A4-1's R1
Evidence: a stat read whose task is released mid-read prints group ID -1 (and state X). For a live
  process during an exec from a non-leader thread the reader returns (-1, start) and the scan drops
  the member: 14 of 2,792,559 warm reads at head, 18 of 4,142,972 in the C probe, also at base. This is
  what made harness section S3 fail at head (exec_storm_thread: ('value', (-1, 523194))).
Patch defect or pre-existing issue: pre-existing; same confirmation closes it (sketch: 0).
```

The base's ENOENT-as-absent at open is the third answer from the same race. It is pre-existing, and A4-1's R1 covers it.

### Observations

- **O4-1, PID reuse** (private PID namespace, `ns_last_pid`, `pidreuse-*.json`, base and head identical):
  - A stat fd opened for A gives ESRCH, never B's line, after B takes A's PID.
  - If the PID is reused between the scan and the pidfd pin, the identity recheck refuses to signal B in an unrelated group.
  - `(pgid, starttime)` cannot tell A from a same-group B created within the same 10 ms tick: P1 shows identical identities. That is harmless, because such a B is a member of the same group.
- **O4-2, availability hold, pre-existing.** After the leader is reaped with an empty group, a process that reuses the leader's PID and calls `setsid()` holds `prove_group_absent` for as long as it lives (held 3 s, returned after the process was reaped). This needs a PID wrap; it causes no false release.
- **O4-3, boundary.** A `/proc` mounted with `hidepid=invisible` (systemd `ProtectProc=invisible`) hides processes the collector may not ptrace-read, and they would read as ENOENT, so absent. The repository has no such setting (no hits for hidepid, ProtectProc or ProcSubset). Inference: the R1 confirmation through `pidfd_open` also closes this, since it does not use `/proc`.
- **O4-4, the writer's evidence holds where re-checked:**
  - The new tests fail on the base collector (all 4: 22 behavioural cases plus the docs pin, with a 20.13 s hold) and pass on head.
  - Repeats: 120 of 120 idle (5.8 s), and 120 of 120 under `stress-ng` CPU and fork load (load average 3.4 to 5.6, 11-12 workers, 13.5 s).
  - No leftover processes.
  - `gofmt`, `go vet` (linux and `GOOS=darwin`) and `py_compile` are clean.
  - Root package: the failing sets are equal except for two Vault service-user migration tests, which fail 3 of 3 on both base and head when run alone (environment).
- **O4-5, own mutants** (`mutants-h22-writer-tests.log`): 12 of 13 caught by the writer's tests. They include first `)`, wrong field, ESRCH unproved again, every error absent, zombie absent, no prefix check, no size bound, and ASCII decode again. K11 (`close+1`) survives. It is equivalent on kernel output, since the kernel always writes `") "`, and only my fuzz of impossible lines tells it apart. My harness caught K01-K03 in S1, S3 and S7, K08 in S3 and S7, and K09 in S7.
- **O4-6, for the coordinator, not findings:**
  - (a) The writer classes this as a script change that merges without David's review. The collector runs as root on the host, so the classification is your call.
  - (b) This audit was adversarial, but it is not a separate red-team thread. Whether the red-team rule applies is your call.

## 3. Validation assessment

**Re-run by the audit:**

- provenance (4 runs);
- the writer's new tests: base collector red, head green, 30 times idle and 30 times under load;
- the whole root package once on base and once on head;
- `gofmt`, vet and `py_compile`;
- 13 mutants;
- the adversarial harness, with these sections:
  - S1: 776 hostile names and every host process;
  - S2: forged members in a real `run_fixed`;
  - S3: process states, 200 zombies × 20 reads, exec storms;
  - S4: staged kernel answers, 300 each;
  - S5: 20 s churn;
  - S7: 200,000-line differential fuzz;
- the ESRCH probes, the end-to-end check, the relay check and the PID-reuse checks above.

**Not re-run:**

- the writer's 19 mutants;
- the writer's real-OpenSSL `sléép` run;
- the writer's 2,150-starts-per-second churn count;
- the GitHub runner (I read its result).

**Limitations:**

- one kernel;
- cold lookups produced by `drop_caches` or by fresh proc mounts. Both stand in for a first lookup or dentry reclaim on a real host.
- The end-to-end check removes only the 50 ms pacing.

## 4. Sensitive-material handling

No secrets were read. A merge commit fetched during provenance carries an author e-mail address; it was not copied anywhere. Evidence was leak-scanned before delivery (see the evidence README).

## 5. Remaining uncertainty and stop conditions

- **Unknown:** the host kernel's behaviour, and whether the fixed `openssl` commands ever create a thread that calls exec (Inference: no).
- No stop condition was hit; provenance matched throughout.

## 6. Confidence

- **Provenance: high.** 4 byte-identical manifests; PR head = target.
- **Validation: high** for the measured facts; medium for the mechanism, which is inference.
- **Implementation: the byte parsing is correct; the absence rule is not (A4-1).**

## 7. Effect status and delivery

- **Effect status:** no repair, commit, push, PR comment or merge. Scratch trees and processes stay on this container only.
- **Report:** `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/04-audit-pr22.md`, with evidence in `04-audit-pr22-evidence/` (SHA256SUMS inside). The report's own SHA-256 is given in the delivery message.

**Final verdict: BLOCK**
