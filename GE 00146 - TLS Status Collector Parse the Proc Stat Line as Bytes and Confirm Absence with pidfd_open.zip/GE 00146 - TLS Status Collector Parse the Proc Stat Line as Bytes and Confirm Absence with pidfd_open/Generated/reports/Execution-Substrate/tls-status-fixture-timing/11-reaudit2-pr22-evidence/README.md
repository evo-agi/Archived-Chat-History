# Evidence for 11-reaudit2-pr22.md (ES draft PR #22, third commit 1032c9c)

Produced on the audit's cloud container (kernel 6.18.44, 4 CPUs, Go 1.26.5, Python 3.13.18) between 04:20Z and 04:51Z on 2026-11-23. Read-only toward GitHub: `git fetch` of the PR's branches and of `refs/pull/22/merge` into a local clone, nothing pushed. Go tests ran as the unprivileged user `ci` (`tests/run-as-ci.sh.txt`). Scripts are stored as `.txt` so that they are read, not run, from here.

Scratch trees (never pushed): `h22c` is a `git archive` export of `1032c9c`, `m22` one of `7806170`, `t110` one of `110d377`. `h22y3` and `h22y9` are copies of `h22c` with one audit mutant each (`tests/mutant-Y3.diff`, `tests/mutant-Y9.diff`). `h22g` is `h22c` plus two audit-only test files that call the guard's own functions (`guard/zz_audit_*_test.go.txt`). `tests/trees-and-binaries.sha256` gives the hashes.

## Provenance (`provenance/`)

- `provenance-r22c.sh.txt` and `provenance.log` (04:24Z): remote state, shape, blobs, range-diff, manifest (two runs, `manifest-{1,2}.json` and `.stdout.txt`, SHA-256 `4fa9dc34…51d4`, equal to the writer's), comparison with the audited manifest.
- `diff-7806170-to-1032c9c.diff` (SHA-256 `10ead230…9863`), `range-diff.txt`, `remote-refs-and-ci-merge.txt` (with the tree of GitHub's test merge `16cdd00`), and the CI job log `runner-run-45109495444-job-137478347335.log`.

## Emulated host without /proc and pidfd (`emul/`)

- `audit_no_proc_pidfd.py.txt` and `audit_no_proc_pidfd.pth.txt`: the emulation, installed in `/usr/local/lib/python3.13/dist-packages/` for the runs only and inert unless `AUDIT_EMULATE_NO_PROC_PIDFD=1`. `emul-removed.txt`: its removal at 04:50:41Z, with the hashes of what was removed.
- `emul-runs.sh.txt`, `affected-26.txt`: phase A, each of the 26 affected tests alone on `7806170`, `110d377` and `1032c9c` (`phaseA-{m22,t110,h22c}.summary`, `per-test-logs.tar.gz`, `leftovers-m22.txt`); phase B, the whole root package with and without the emulation (`phaseB.summary`, `whole-*.log.gz`).

## The guard (`guard/`)

- `scripts-dump-boundary.json.gz`: the 94 strings, of the 25,191 the guard extracts at `1032c9c`, that name a boundary function or the probe, each with the guard's own judgement (from `zz_audit_dump_scripts_test.go.txt`, which writes the full dump). The full dump is not included: it holds PEM header strings from other test files, which the leak scanner flags.
- `guard-samples.log` (from `zz_audit_guard_samples_test.go.txt`): shapes G1 to G8 judged by `remoteAlphaESStatusBoundaryFault`.
- `candidate-rule.py.txt` and `candidate-rule.log`: the 45 probe-replacing scripts, the 15 that call `main` or `diagnostic_main` without the whole boundary and how each cuts `run_fixed`, and a candidate rule checked against all of them and against G1 and G2.

## The bound and `os` (`demo/`)

- `boundary-constant.py.txt`: the shared constant, copied from the test file. Three demo scripts (`.py.txt`), their output (`.out.txt`) and `demo.summary`: the constant with a 1 s bound in a hold that never resolves, with and without `import os`, and site 578's shape with a stalled validation.

## Tests (`tests/`)

- `h22c-new-tests-n5.log`: the four new tests, `-count=5`, on `1032c9c`.
- `mutant-Y3.log`, `mutant-Y9.log` with their diffs.

## Leak scan

The chat-archive scanner (`ge_chat_archive.py scan` with the known-numbers list) was run over the report and every file here. Its result is recorded in the delivery message. `SHA256SUMS.txt` covers every file except itself.
