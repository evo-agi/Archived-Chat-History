# Evidence for 13-reaudit3-pr22.md (Execution-Substrate PR #22, narrow re-audit of the third repair)

Head `da56d63d2008930daf08d5ba8344e6af1e173072` = merge of the repair commit `f62eeefd967d6e368ae26fd456c95f1d87a55f6d` with `trunk_dev` `bc9fe3619823245faf550db4bf1bc3e782fbd5a5`. All runs: cloud container, kernel 6.18.44, Go 1.26.5, Python 3.13.18, as the unprivileged user `ci` with an emptied environment. Files ending in `.txt` after another extension are scripts or test files kept as text; nothing here is meant to be run from this folder.

| Path | What it is |
|---|---|
| `provenance/provenance-r22d.sh.txt`, `provenance-r22d.log` | gate data: remote state, parents, repair diff hash, clean trial merge, PR patch equal across the base move, blobs, range-diff, manifest v2 twice |
| `provenance/manifest-da56d63.json` | the manifest (SHA-256 `e0abc4cce9feaa0a9e52636e7c5c384fc74cde33602f715861fc7d400a4c3b4f`), equal to the writer's |
| `provenance/range-diff.txt`, `files-base-to-tip.txt` | range-diff `110d377..1032c9c` against `bc9fe36..da56d63`; the 8 paths |
| `callgraph/callgraph.py.txt`, `callgraph-hd.txt` | independent call graph of the collector at the head: paths from `main` and `diagnostic_main` to `run_fixed`, minimal cuts, dynamic lookups, flag assignments |
| `guard/zz_audit_dump_scripts_test.go.txt`, `zz_audit_guard_samples_test.go.txt` | audit-only test files run in a copy of the head (not part of the change): dump of every extracted fixture script with the guard's verdict, and shapes G1 to G22 |
| `guard/guard-samples-hd.log` | the verdicts on G1 to G22 |
| `guard/scripts-dump-hd-boundary.json.gz` | the 141 scripts the guard judges on the head, with verdict and use (audit files left out) |
| `guard/analyze-dump.py.txt`, `analyze-dump-hd.txt`, `counts-hd.txt`, `private-names-hd.txt` | probe stand-ins, entry points, cuts and hand-backs per script; package counts; no rebinding of the constant's private names. `analyze-dump-hd.txt` also lists my two audit sample scripts, which `counts-hd.txt` leaves out |
| `demo/` | the three `os` demos of the audit of `1032c9c` with the head's constant (`make-demos.py.txt` swaps only the constant), outputs and `demo.summary` |
| `mutants/mutants.py.txt`, `run-mutants.sh.txt`, `summary.txt`, `logs/` | 20 audit mutants and the unmutated control, against the six local-boundary tests |
| `tests/local-tests-hd.log` | the local-boundary tests on the head, verbose |
| `emul/audit_no_proc_pidfd.py.txt`, `audit_no_proc_pidfd.pth.txt`, `emul-installed.txt`, `emul-removed.txt` | the audit-only emulation of a host without `/proc` and pidfd, its installation and its removal |
| `emul/emul-runs-d.sh.txt`, `affected-26.txt`, `phaseA-*.summary`, `phaseB.summary`, `emulation-hit-counts.txt`, `leftovers-whole-*.txt` | each test alone (32 on the head, 26 on `trunk_dev`) and the whole root package emulated and plain on both trees |
| `emul/compare-verdicts.py.txt`, `verdicts.txt`, `whole-*-verdict-lines.txt.gz` | the verdict comparisons and the verdict lines of the four whole-package runs |
| `SHA256SUMS.txt` | SHA-256 of every file here |
