# IMPLEMENTATION REPORT: Execution-Substrate, the TLS status collector no longer lets an unrelated process decide its process scans

**Outcome: both defects of report 02 are fixed in one function, `read_proc_identity`, in draft PR 22. A process name can hold any byte without stopping the collector, and a process that ends during a scan no longer marks a clean run incomplete. The new tests fail on the base and pass on the head, and 19 of 19 mutants of the reader are caught. The GitHub runner's check is green on the head (run 45085828879).**

Written 2026-11-23 (UTC) by the writer thread of PR 14, 16 and 21. The coordinator asked for it at 23:23Z on 2026-11-22 after `02-cleanup-hold-investigation.md`. It is a script change, treated as security-sensitive: full provenance gate, red-first tests, mutants. No subagents were used. Independent audit: not performed.

## 1. Identity

| Field | Value |
|---|---|
| Objective | The collector must handle any process name without stopping and must never hold its lock because of an unrelated process (findings B and C of report 02) |
| Repository | `evo-agi/Execution-Substrate` |
| Base | `trunk_dev` at `f62d0245e95e2b411be16511fc1bf9e1da727ce5` |
| Topic branch | `claude/project-thread-k69qcw-collector-process-names` |
| Topic commit | `64a0e0c27c2af9a4ea447cdfc727c988047572cf` (one commit) |
| Tree | `1d1f1fed9b5d3e484ce87aaff8b610647b75df3b` |
| Pull request | [#22](https://github.com/evo-agi/Execution-Substrate/pull/22) (draft) |
| Manifest (v2) | SHA-256 `263df6309ee3ed97e3aa17b2356c7051b0292a49d676ee9985ae6e44e53b8351`, 5 files |
| Final working-tree status | clean after the commit; the branch is pushed and equals its remote |

## 2. The two defects

The collector `scripts/internal/remote_alpha_es_tls_status.py` runs as root on the Remote Alpha host. Its capability probe and every cleanup scan call `read_proc_identity` for every process on the host, including processes of other accounts.

**B. Process names.** The reader decoded the line of `/proc/<pid>/stat` as strict ASCII. The name field of that line is chosen by the process itself. One unrelated process with a non-ASCII name made every scan raise. Before a run the capability probe failed, so the route could not run. Started during a run, it held the collector with its scope lock, with SIGINT, SIGTERM and SIGHUP latched, until that process ended, and the run then ended with `child_resource_unproved`. Any local account can start such a process.

**C. A process that ends during the scan.** When a process was reaped between the directory listing and the open or the read of its stat file, the kernel answered ESRCH. At open that became `process_identity_unproved`, at read a bare `ProcessLookupError`. Both marked the cleanup uncertain, so a clean run ended incomplete.

Nothing unsafe was published in either case. Both are availability defects.

## 3. The fix

One function changes, 17 lines added and 8 removed, of which 8 added lines are its comment.

```python
    try:
        fd = os.open(f"/proc/{pid}/stat",
                     os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC)
    except (FileNotFoundError, ProcessLookupError):      # was: FileNotFoundError
        return None
    except OSError as exc:
        raise Incomplete("process_identity_unproved") from exc
    try:
        try:
            raw = os.read(fd, 4097)
        except ProcessLookupError:                       # new
            return None
    finally:
        ...                                              # close, unchanged
    if len(raw) > 4096:
        raise Incomplete("process_identity_unproved")
    try:
        close = raw.rfind(b")")                          # was: on the decoded text
        if close < 0 or not raw.startswith(b"%d (" % pid):
            raise ValueError()
        fields = raw[close + 2:].split()
        if len(fields) < 20:
            raise ValueError()
        return int(fields[2]), int(fields[19])
    except (ValueError, IndexError) as exc:
        raise Incomplete("process_identity_unproved") from exc
```

What is the same as before: the open flags, the one bounded read, the 4096 byte limit, the close rule (a close failure sets the witness flag and is raised, also after ESRCH at read), the last `)`, the `<pid> (` prefix check, the two field positions, and `process_identity_unproved` for everything malformed. No caller changes. No time limit was added to the hold, and a visible zombie still counts as present.

### What a process name can reach

Nothing. The kernel writes the line as the PID, ` (`, the name, `) `, the state letter and then numbers. No `)` follows the name's closing one, so the last `)` of the line is always the kernel's. The name is the bytes between the first `(` and that last `)`, and the reader now never looks at them. A name such as `x) R 1 4242 4242 ...` therefore cannot supply fields, which the tests check with exact bytes and with a live process.

The fields after the last `)` are parsed as before. For ASCII input `int()` and `split()` give the same result on bytes as on text. Two differences exist only for input the kernel does not write: text would also split at the control characters 0x1C to 0x1F, and a non-ASCII byte in a number was refused by the decoder and is now refused by `int()`. Both stay `process_identity_unproved`.

### Why ESRCH is absent and not unproved

The stat file belongs to one process, not to a PID number. The kernel answers ESRCH at open (`proc_pid_permission`) and at read (`proc_single_show`) exactly when that process is no longer attached to its PID, which happens when it is reaped. A zombie is still attached and still answers. So ESRCH states the same fact as the ENOENT that was already absent: the process that the scan listed no longer exists. Inference from the kernel sources as I know them, backed by the two measurements below: a process killed and reaped between open and read gives ESRCH, and a zombie gives its line.

It does not make a scan miss more. A scan is a snapshot: a member that is reaped before its file is read was already skipped through ENOENT, and ESRCH is the same event a few instructions later. The identity recheck by start time is unchanged.

Every other error stays unproved: EACCES and EPERM in particular, because a process that cannot be read may still be a member.

## 4. Documents

Doc first, as `AGENTS.md` requires. The three passages that state the collector's process rules now state this one, inside the sections that the existing docs contract test already reads:

- `PLANS.md`, after the member-fault rule of the P0s/P0t seam: a `Bounded slice rule` process-identity refinement.
- `.docs/system_overview/remote_supported_host_alpha.md`, after the subprocess ownership rule: a `Bounded slice rule` for the process-identity read.
- `.docs/system_overview/remote_alpha_access_contract.md`, section 1, after the absence scan sentence.

`.docs/system_overview/capability_probing.md` was consulted. The change adds no OS branch and no fallback. The live tests decide by behaviour whether they can run (section 5).

## 5. Tests

One new file in the root package, `remote_alpha_es_service_tls_status_process_identity_test.go`, with four tests. It is a new file so that it cannot conflict with PR 21.

| Test | Runs where | What it checks |
|---|---|---|
| `...ProcessIdentityOpaqueNameBytes` | every host | 50 cases with exact stat bytes through an injected `os`: 11 names, one of them a forged tail, and every byte value 0 to 255 inside a name; 12 malformed lines, a line over 4096 bytes and 2 bad PIDs stay unproved; a line of exactly 4096 bytes is accepted; ENOENT and ESRCH at open and ESRCH at read are absent with the descriptor closed; 9 other open errors and 6 other read errors are not absent; a close failure after ESRCH is raised; two whole scans |
| `...ProcessIdentityLiveProcesses` | where `/proc/self/stat` is readable | 12 cases against the kernel: 8 live processes of the test with names holding UTF-8, invalid UTF-8, 15 high bytes, a forged tail, a newline, parentheses and whitespace, read by the real reader and the real member scan while all of them live; the real capability probe beside them; a process killed and reaped between the reader's open and read (the kernel's own ESRCH, checked by its errno), alone and inside a scan; a zombie that stays present until it is reaped |
| `...UnrelatedProcessNameDoesNotHoldCleanup` | where `/proc/self/stat` is readable | the real capability probe, then an unrelated process named `sléép` starts in its own session, then one fixed command runs through the real `run_fixed`, cleanup owner, scan and reader. It must return while that process lives, with its result and with no uncertainty. The unrelated process is ended only after a 20 second bound, so a collector that holds fails the test and does not hang it |
| `...ProcessIdentityDocumentsContract` | every host | the three document passages, and that the reader holds no `.decode(` |

The fixed command of the third test is a stand-in script, as in the existing runner tests, so the test does not depend on an OpenSSL install. The real `/usr/bin/openssl` was measured separately (section 6).

The live tests skip only when the probe's own attempt to read `/proc/self/stat` fails, with that reason. Any other answer of the probe is a failure. On the runner an unlisted skip fails the CI gate, so the tests cannot go quiet there. The live probes raise `CHILD_GRACE` to 30 seconds: the one second grace of the capability probe is not under test, and a loaded host should not turn one late scheduling into a failure. Every fixture process is a direct child that the probe kills and reaps, and it ends by itself if the probe disappears.

## 6. Validation

All runs as user `ci` in the cloud container (Go 1.26.5, emptied environment) on a copy whose tree equals the commit's tree `1d1f1fed`.

### New tests on the base and on the head

| Run | Result |
|---|---|
| Base collector, final tests and docs | all 4 tests fail. 22 failed cases: 8 byte cases (5 names, ESRCH at open, ESRCH at read, the scan), 11 live cases, 3 hold cases. The cleanup test held the full 20.0 s and then got `Incomplete: child_resource_unproved`. The docs test fails on the `.decode(` pin |
| Head | all 4 pass in 0.09, 0.12, 0.15 and 0.00 s |
| Head, 30 repetitions | pass, 10.5 s in total |

On the base the zombie case and all malformed-line cases pass, as intended: they guard what must not change.

### Mutants

19 mutants of the reader, one at a time on the head, each run against the four tests. All 19 are caught by a behaviour test. The unmutated runs before and after pass, and the copy was clean afterwards.

| Mutant | Failed cases | First cases that caught it |
|---|---|---|
| M01 strict ASCII again (the base) | 18 | `name_utf8`, live names, the hold test |
| M02 decode as Latin-1 | 1 | `line_group_non_ascii_space` |
| M03 decode as UTF-8, surrogateescape | 1 | `line_group_non_ascii_digits` |
| M04 decode as UTF-8, replacement | 1 | `line_group_non_ascii_digits` |
| M05 first `)` in place of the last | 5 | `name_forged_tail`, `live_forged_tail` |
| M06 no PID prefix check | 4 | `line_other_pid` |
| M07 prefix without ` (` | 2 | `line_pid_with_more_digits` |
| M08 ESRCH at open unproved again (the base) | 2 | `open_esrch` |
| M09 ENOENT at open unproved | 4 | `open_enoent`, the zombie case |
| M10 ESRCH at read raised again (the base) | 4 | `read_esrch`, `live_ended_before_read_is_absent` |
| M11 every open error absent | 10 | `open_eacces` |
| M12 a permission error at open absent | 3 | `open_eacces`, `open_eperm` |
| M13 every read error absent | 6 | `read_eio` and five more |
| M14 ESRCH at read leaves the descriptor open | 9 | `read_esrch` |
| M15 a zombie is absent | 3 | `live_zombie_present_until_reaped`, the hold test |
| M16 no line length limit | 1 | `line_over_4096` |
| M17 session ID in place of the group ID | 17 | `name_ascii` |
| M18 a parse failure is absent | 12 | `line_other_pid` |
| M19 close failure after ESRCH swallowed | 1 | `read_esrch_close_failure_stays_unproved` |

M02 to M04 handle every name and differ from the fix only on lines the kernel never writes. Each is caught by one crafted case, and also by the source pin.

### The real OpenSSL and process churn, base against head

| Experiment | Base | Head |
|---|---|---|
| Process `sléép` alive before the run | capability probe raises `process_capability_unavailable` | probe passes, `openssl version` returns in under 0.01 s |
| Process `sléép` starts during the run and lives 8 s | held 8.0 s, then `child_resource_unproved` | returns at once |
| Member scans for 30 s at about 2,150 process starts per second | 175 of 65,512 scans raised, all from ESRCH (145 at read, 30 at open) | 0 of 67,575 |
| The six fixed OpenSSL forms | (report 02) | all return exit 0 in 4 to 29 ms, also under a first process that does not reap |

### The rest of the root package

`go test .` on the unchanged base and on the head give the identical set of failed and skipped tests: 8 tests with 38 result lines. All of them are tests that the CI list names as environment-only (they need `/private/tmp` or the account `ds`). The head run took 154.7 s. `go build ./...`, `go vet ./...` for Linux and for `GOOS=darwin`, `gofmt` on the new file and `py_compile` of the collector are clean.

### On the GitHub runner

Run [45085828879](https://github.com/evo-agi/Execution-Substrate/actions/runs/45085828879), job `build, vet and test`, on the head `64a0e0c`: success, 23:55:26Z to 00:08:04Z (12 min 38 s), Go 1.26.5.

- Step "Test": `test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed`. The root package passed in 116.3 s.
- The gate fails on a test that skips itself without a list line, and the 39 listed skips are the same as before this change. So the three tests that need `/proc` ran and passed on the runner. Inference from the gate's rule: the log does not print the names of passing tests.
- Step "Listed tests still fail": all 15 listed tests still fail. The gate's self-check ran its 121 tests.

## 7. Failed or skipped validation

- **macOS: not run.** There the two live tests and the cleanup test skip, and the byte test and the docs test run. Unknown: whether the byte test passes with the Mac's `/usr/bin/python3`. Inference: it should, I see nothing in it that depends on the Python version. A Mac run needs David, as for PR 21.
- **The Remote Alpha host: not run.** The collector was not run on the box.
- **The full CI gate in the container: not run.** The runner runs it.
- ESRCH at open cannot be staged against the kernel on demand. It is covered by injection in the byte test and by the churn run above (30 real cases on the base, none raised on the head).

## 8. Observations outside the patch

- **Host faults still hold, by design.** ENOMEM, EIO and the like at open or read stay unproved, so the hold lasts as long as such a fault lasts. They are not chosen by a process's name or exit.
- **The other reader of process names is not affected.** `scripts/internal/remote_alpha_runtime_security_boundary_check.sh` reads `ps -eo comm,args` as text. `ps` (procps-ng 4.0.4 here) prints `?` for bytes it cannot show, measured with a process named with three invalid bytes under `LC_ALL=C` and `C.UTF-8`. Unknown for the `ps` on the box.
- **Not examined:** whether a read of a stat file can block inside the kernel. The file and the way it is read are unchanged.
- The known two-second fixture failure that PR 21 fixes did not occur in these runs. This branch does not contain PR 21. The two PRs touch different files.

## 9. Other envelope fields

- **Reconnaissance:** `AGENTS.md`, `PLANS.md` (P0s/P0t seam), the two Remote Alpha documents, `capability_probing.md`, the collector, its three test files, `docs_contract_test.go`, the CI gate's rules for skips, and report 02. The reader is the only place in the repository that reads `/proc/<pid>/stat`. The collector's hash is pinned nowhere in the repository, and no packaged copy of it exists.
- **Implementation decision:** as proposed in report 02, section 8. Two tightenings were considered and left out because they would change behaviour beyond the defect: requiring plain digits in the two fields, and checking the space after the last `)`.
- **Dependencies:** none added.
- **Artifact hygiene:** the working tree is clean. Scratch copies and logs are outside the repository. The worktree that held the base for the comparison run is removed.
- **Authority widening:** none. No signal, reap, lock, publication or retry rule changes.
- **Cross-repo impact:** none.

## 10. Provenance

| Item | Value |
|---|---|
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before every run |
| Manifest SHA-256 | `263df6309ee3ed97e3aa17b2356c7051b0292a49d676ee9985ae6e44e53b8351` (1,331 bytes) |
| Textual diff SHA-256 | `f1d2d57b83e519109f6257e1a329721d6e21fd28bdc56be35ba8ca97bb72a4fa` |
| Files | 5 |
| How taken | HEAD at the base, branch checked out by name, upstream pinned to `origin/trunk_dev`, nothing staged; two runs, byte-identical |
| Staged set check | after `git add -A` the staged paths equal the manifest paths (5); one commit; status empty |
| Fresh clone | new clone, checkout of the pushed tip, `git reset --mixed` to the base, upstream pinned, two runs: byte-identical to this manifest |
| Validated bytes | the validated copy's tree is `1d1f1fed`, the commit's tree |

Complete canonical manifest:

```json
{"branch":"claude/project-thread-k69qcw-collector-process-names","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/remote_alpha_access_contract.md","sha256":"00b0fd70d1573579a3e2479b0b2d280e09eaaaf574520868b6be4869698fd205","size":40329},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":".docs/system_overview/remote_supported_host_alpha.md","sha256":"e4a6f8daeebb51c7ae4199bceb4d27c13af445140b4b13b727281ba2dd549f26","size":339800},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"PLANS.md","sha256":"9e580694bacf37958faa11ac7f26a826ed12038a1b9883ee20863807720b5f77","size":305087},{"file_type":"regular","kind":"untracked","mode":"0644","path":"remote_alpha_es_service_tls_status_process_identity_test.go","sha256":"1aba2f3647257fb75006d1f1fd5a3a575a68a2bb46276087a6ff7cfbd3e7d788","size":21861},{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"scripts/internal/remote_alpha_es_tls_status.py","sha256":"e41e856650378d1140dc9ab2fad8c55af819fb177f8df4f92888cca6179c424c","size":139883}],"head":"f62d0245e95e2b411be16511fc1bf9e1da727ce5","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"f1d2d57b83e519109f6257e1a329721d6e21fd28bdc56be35ba8ca97bb72a4fa","upstream":"origin/trunk_dev"}
```

## 11. Assumptions and unresolved points

- Inference: the kernel answers ESRCH for a stat file only once its process is reaped (section 3). Measured in both directions on this container's kernel 6.18, not on the box's kernel.
- Unknown: the Mac result of the byte test (section 7).
- Not a claim: that no host fault can hold the collector (section 8).

## 12. Confidence

High that a process name can no longer change a scan's result, and that ESRCH is now absent at both places: exact bytes, live processes, the real OpenSSL and the churn run agree, and each rule has a mutant that a test catches. High that nothing was weakened: every other error, every malformed line and the zombie stay as they were, each with its own mutant. Medium for hosts other than this container and the runner, which were not exercised.

## 13. Delivery and effect status

- Delivered: this report, `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/03-collector-process-name-fix.md`, with `03-evidence/` (51 files, `SHA256SUMS.txt`, `README.md`, `commands.txt`).
- Leak scan of the report and the evidence: `0 finding(s)`.
- Effects: one branch pushed, one draft PR opened. Nothing merged. Nothing ran on the Mac or on the box. PR 21 is untouched.
- Next: a fresh adversarial audit of `64a0e0c`. It is a script change, so after audit and merge gate it merges without David's review under his standing rule.
