# MAC RUN: Execution-Substrate PR #22 on macOS, head 8ce6b73

**Outcome: clean. On David's Mac the root package passes on the PR head in 201 s: 472 PASS, 0 FAIL, 3 SKIP, with no timeout, no bound reached and no target-only path reached. Every verdict that both commits have is the same as on `trunk_dev` `200fd60`. The three tests that PR #23 newly lets reach the collector's process cleanup on macOS ran and passed on both commits. Nothing is left on the Mac.**

Run 2026-11-23 14:39Z to about 14:48Z through Remote Control in `/Users/ds/Repositories/Playground`, after David wrote "Please go ahead with Mac check." in the writer thread at 14:38Z. Brief: `16-evidence/mac-instructions-8.txt` (sha256 `19566971a6017b91b01c11d712bac58a8169f1fe3bb7aafa137934febd3603b2`), plus one read-only addition at the coordinator's request (step 7a below). The Mac session's report is data. What follows is my summary of it, with its numbers.

## 1. Why this run was repeated

The run on `0a80ab7` (`15-mac-run-pr22.md`) used a `trunk_dev` without PR #23. On that base 17 root tests failed on the Mac at the collector's symbolic-link checks, because macOS's temporary directory lies behind `/var`. PR #23 (`200fd60`) gives every test package a `TestMain` that moves the temporary directory to its physical path. Tests that stopped early before could now reach `run_fixed` and the process cleanup, which is the path whose macOS hang PR #22 repairs. The provenance re-check (`17-provenance-pr22-8ce6b73.md`) names three such tests.

## 2. Identity

| Field | Value |
|---|---|
| Head tested | `8ce6b739fa5f097e39dd73bd93a9ccac6c6b8811`, tree `02ab404b8adb3950c773dada961ed6888af1ce43` (checked on the Mac; the PR branch on GitHub was the same commit) |
| trunk_dev tested | `200fd6097b43981ffae86e69500d1ab41b49a94c`, tree `bcf9da93ad71a954442168a04e9a3460f91f83b3` |
| Head's parents | `0a80ab7` (first parent `da56d63`, re-audit ACCEPT in `13-reaudit3-pr22.md`) and `200fd60`; provenance re-check of `8ce6b73` PASS (`17-provenance-pr22-8ce6b73.md`) |
| Mac | macOS 26.6.2 (25G83), arm64, `/usr/bin/python3` 3.9.6, user `ds` |
| Go | go1.26.5 darwin/arm64 from the module cache, `GOPROXY=off`, `GOFLAGS=-mod=readonly`, `GOCACHE` inside the temporary folder |
| Temporary folder | `/Users/ds/Repositories/Playground/es-mac-run.kp7nTQ`, removed at the end |
| Clone | `evo-agi/Execution-Substrate` over SSH. The existing clone in `/Users/ds/Repositories/Execution Substrate` was only read for its origin address |

## 3. Results

| Step | Result |
|---|---|
| 4. The six tests of the local fixture boundary | exit 0, all six pass, FailsBounded with all 7 subtests (10.3 s). The guard's line is the same as in the cloud: "141 scripts name the process boundary, 23 use the shared local boundary, 31 replace the whole boundary, 46 replace the probe (29 with the whole boundary, 17 without)" |
| 5. Root package on the head | **exit 0**, 201 s. Top level: 472 PASS, 0 FAIL, 3 SKIP. No "panic: test timed out", no "local fixture exceeded its bound", no "local fixture reached the target-only host path" |
| 7. Root package on trunk_dev | exit 0, 188 s. Top level: 464 PASS, 0 FAIL, 0 SKIP. None of those lines either |
| Comparison | 2,256 verdicts on the head, 2,238 on trunk_dev. No verdict differs. Nothing is only on trunk_dev. 18 only on the head: the PR's 11 new top-level tests and 7 subtests. 15 pass and 3 skip |
| 7a. The three tests of the provenance re-check | `FailureWitnessFixedInputCloseout`, `MaterialByteBinding` and `SingleSelectedTrustAnchorCardinality` each have a top-level `--- PASS` line on the head and on trunk_dev |
| 6. Leftover processes | none, after both runs (checked with `/usr/bin/grep` by its full path). No process was ended |
| 8. git status and gofmt on the head | the head was checked out again first; status clean; `gofmt -l` on the two test files prints nothing |
| 9. Removal | the folder is gone, Playground still exists |

The brief expected a nonzero exit in steps 5 and 7, because some tests of the package need Linux. Both exited 0: with PR #23 those tests no longer fail on this Mac. Compared with the run on `0a80ab7` (455 PASS, 17 FAIL, 3 SKIP on the head), the 17 former failures now pass (455 + 17 = 472).

The three skips are the live tests of the process-identity file (`ProcessIdentityLiveProcesses`, `ProcessIdentityThreadExecStaysPresent`, `UnrelatedProcessNameDoesNotHoldCleanup`). Each says "skipping live proc stat fixture: cannot open /proc/self/stat: ENOENT", which is the designed skip on a host without `/proc`.

## 4. The same comparison in the cloud

Before the Mac run I compared the whole root package in the cloud container (Linux, kernel 6.18, Go 1.26.5), head `8ce6b73` against `200fd60`, both clean checkouts (`18-evidence/cloud-run-identity.txt`). The result is `18-evidence/cloud-verdicts-8ce6b73-vs-200fd60.txt`: head 2,256 verdicts, trunk_dev 2,238; no verdict differs; nothing only on trunk_dev; the 18 head-only verdicts all pass. Both commits fail the same 8 top-level tests, the container-only failures that every earlier comparison in this workstream showed.

## 5. Where the run left the brief

1. Step 7a was added by me while the run was going, at the coordinator's request, read-only and before the removal. It printed the verdict lines of the three tests from both result files.
2. The Mac session also listed the reasons of the three skips (section 3), read-only.

Nothing else departed from the brief. The two changes that `15-mac-run-pr22.md` asked for (step 6 with `/usr/bin/grep`, the head checked out again before step 8) were in brief 8 and worked.

## 6. What is left on the Mac

Nothing. Every file was written inside the temporary folder, which is removed. The module and toolchain caches were only read. Remote Control for this thread was ended after the report.

## 7. Effect

The macOS question of PR #22 is answered on the current base: with PR #23's `TestMain` the collector's real process cleanup runs on a host without `/proc` and `pidfd_open`, the fixture repair holds there, and the PR changes no verdict.
