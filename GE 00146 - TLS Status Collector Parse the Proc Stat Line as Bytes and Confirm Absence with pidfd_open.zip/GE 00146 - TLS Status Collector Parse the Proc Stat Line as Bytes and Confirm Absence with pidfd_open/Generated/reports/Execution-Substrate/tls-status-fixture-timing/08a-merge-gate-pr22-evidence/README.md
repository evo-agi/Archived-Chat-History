# Evidence for 08a-merge-gate-pr22.md (ES draft PR #22, gate head 7806170)

Produced on the audit's cloud container (kernel 6.18.44, 4 CPUs, Go 1.26.5, Python 3.13.18) between 03:16Z and 03:22Z on 2026-11-23. Read-only toward GitHub: one `git fetch` of the PR's branches and of `refs/pull/22/merge` into a local clone, nothing pushed. Scripts are stored as `.txt` so that they are read, not run, from here.

## Provenance

- `provenance-r22-gate.sh.txt` (run as root in a fresh clone) and its output `provenance-gate.log`. The line `fatal: path 'remote_alpha_es_service_tls_status_process_identity_test.go' exists on disk, but not in '110d377…'` is expected: the PR adds that file, so the new base has no blob for it.
- `manifest-gate-{1,2}.json` and `.stdout.txt`: two runs, byte-identical, SHA-256 `b6476378…7d5a`.
- `range-diff.txt`; `diff-110d377-to-7806170.diff` (the change at the tip, byte-identical to `git diff f62d024 39a016c`); `diff-39a016c-to-7806170.diff` (what the merge brought in, byte-identical to `git diff f62d024 110d377`).
- `remote-refs-and-ci-merge.txt`: `git ls-remote` at 03:21:59Z, and the tree and parents of GitHub's test merge `30e1ffb` that CI tested.

## CI

- `runner-run-45103477792-job-137459365287.log`: the job log of "build, vet and test", fetched through the GitHub API.

## Tests on the merged tree

- `/opt/audit/m22` is a `git archive` export of `7806170`; `/opt/audit/m22-m05` is a copy with PR #21's mutant M05 applied (`m22-m05.diff`, applied by the PR #21 audit's `apply_mutant.py`). `trees-and-binaries.sha256` gives the hashes and shows that `m22` equals the combined tree of `08-reaudit-pr22.md` apart from a Python cache.
- `gate-tests-r22.sh.txt`, run as the unprivileged user `ci`: `gate-m22-pr21-tests-n10.log`, `gate-m22-pr22-tests-n5.log`, `gate-m22-all-tlsstatus.log`, `gate-m22-m05-pr21-tests-n3.log`.

## Leak scan

The chat-archive scanner (`ge_chat_archive.py scan` with the known-numbers list) was run over the note and every file here. Its result is recorded in the delivery message. `SHA256SUMS.txt` covers every file except itself.
