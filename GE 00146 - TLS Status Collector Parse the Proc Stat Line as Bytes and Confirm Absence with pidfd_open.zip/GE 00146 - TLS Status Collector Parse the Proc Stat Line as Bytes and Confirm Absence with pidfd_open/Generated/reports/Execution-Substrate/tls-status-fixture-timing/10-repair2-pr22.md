# REPAIR REPORT 2: Execution-Substrate PR #22, the local test fixtures stand in for the whole process boundary

**Outcome: the test-suite fault that held the merge of PR #22 is repaired inside PR #22, with tests and one document only. The collector is unchanged. Twenty local fixture scripts left `read_proc_identity` real, and with PR #22's reader that would hold them forever on a host that has neither `/proc` nor `pidfd_open`. They now share one constant that stands in for the whole boundary, a guard test refuses a fixture that injects only part of it, and a fixture that is stuck ends itself with a stack trace after a fixed bound. Not run on macOS yet: the fault and the repair were shown on Linux with the target facilities denied. The new commit needs a narrow audit, and the Mac run needs David.**

Written 2026-11-23 by the writer thread of PR #22, after the coordinator's decision of 03:22Z ("repair inside PR 22, no merge until done"). No subagents were used. Independent audit of the new commit: not performed.

## 1. Identity

| Field | Value |
|---|---|
| Objective | Local fixtures of the TLS status collector must inject the whole target-only process boundary; a guard must fail on a partial injection; a stuck absence hold in a test must fail in bounded time; count the sites exactly |
| Repository | `evo-agi/Execution-Substrate` |
| Base | `trunk_dev` at `110d377a459471e94aa14cc83877f554ae62f893` |
| Topic branch | `claude/project-thread-k69qcw-collector-process-names` |
| Audited commit | `39a016cca06dfb10f8b4b64c9b614c8f20aaa1de` (re-audit ACCEPT, `08-reaudit-pr22.md`) |
| Previous head | `78061701d1dc3e4ba784a0e6f0e8da9f452f93f6`, the merge of the audited commit with the base (no conflict) |
| Repair commit, new head | `1032c9c9f836b29b63ff00462806d5f3cd5cba19`, parent `7806170`, fast-forward push, no force |
| Tree | `cae84b6e80ddd4f18ca48e09d364e1061f48c2e5` |
| Pull request | [#22](https://github.com/evo-agi/Execution-Substrate/pull/22) (draft), description updated for the new head |
| Manifest (v2), base to tip | SHA-256 `4fa9dc34dfdf3df4d65698e64b619764b19087b75b2f5fd83252f60fe37151d4`, 1,956 bytes, 8 files, textual diff `71d32ada6483b2e9d917b115da0508d7447e26d88d3fb79eeef86aa72167cc1e` |
| Files touched by the repair commit | `remote_alpha_es_service_tls_status_test.go` (modified), `remote_alpha_es_service_tls_status_local_boundary_test.go` (new), `.docs/system_overview/capability_probing.md` (modified). 3 files, 650 insertions, 120 deletions |
| Files not touched | the collector `scripts/internal/remote_alpha_es_tls_status.py`, `PLANS.md`, the two Remote Alpha documents and the process identity test file. Their blobs equal those of the audited commit (section 9) |
| Final working-tree status | clean; the branch is pushed and equals its remote |

## 2. The finding

Before PR #22, `read_proc_identity` returned "absent" when `/proc/<pid>/stat` could not be opened. Since the second commit of PR #22 it then asks `process_absent`, which uses `pidfd_open` and raises `process_capability_unavailable` when `os.pidfd_open` does not exist. That is right for the collector, which runs only on the Linux target behind its capability probe.

Twenty local fixture scripts in `remote_alpha_es_service_tls_status_test.go` replaced the probe, `scan_group_members` and `signal_same_group_members` with stand-ins and ran real fixed children. They never replaced `read_proc_identity`. On Linux that does not matter: the stand-in scan reports start time 0, which no real identity equals, so the absence check after the reap answers "absent" at once. On a host with neither `/proc` nor `pidfd_open`, such as a macOS development machine, the real reader raises on every call, `prove_group_absent` counts that as uncertain and tries again, and it never returns. Most of these fixtures are started without a time limit, so the test binary would stop there.

- **How it was found:** by simulation on Linux before the merge, not by a Mac run. `macsim.py` denies `/proc` opens and removes `os.pidfd_open` in the fixture process and uses the fixtures' old stand-ins. With the collector of `f62d024` a fixed child returns `(0, b'fixed', b'')`. With the collector of `39a016c` (the same blob as today's) the call was still running after 8 s (`10-evidence/macsim.log`).
- **Why CI and the audits did not see it:** CI runs on Linux only, where the partial stand-in is neutral. The earlier Mac run (for PR #21) used a commit without PR #22.
- **Classification:** unintended drift between the test fixtures and the collector's reader, introduced by PR #22's second commit. No product behavior, contract, or collector rule is involved.

## 3. What the coordinator asked and what was done

| Asked | Done |
|---|---|
| Fixtures inject the whole target-only boundary consistently, including `read_proc_identity` and `process_absent`, so that no fixture can silently reach the real host path | One shared constant with stand-ins for the probe, the flag, scan, signal and identity. `read_proc_stat_identity` and `process_absent` become tripwires that end the fixture with status 97 (section 4.1) |
| A guard test that fails if a fixture injects part of the boundary but not all of it | `TestRemoteAlphaESServiceTLSStatusLocalBoundaryIsInjectedWhole` reads every fixture script of the package (section 4.2) |
| A stuck `prove_group_absent` in tests fails with a bounded timeout and does not hang the suite | The shared constant arms a 120 s bound that prints the stack of every thread and ends the fixture with status 98. `TestRemoteAlphaESServiceTLSStatusLocalFixtureFailsBounded` shows it on the real hold (section 4.3) |
| Count the affected sites exactly | 20 scripts, listed in section 5 |
| The PR body still described `39a016c` and "audit not performed" | Updated for the three commits, the audit state of each, and the new target identity |

## 4. The repair

### 4.1 The shared local boundary

`remoteAlphaESStatusLocalProcessBoundary` in `remote_alpha_es_service_tls_status_test.go` replaces twenty byte-identical five-line blocks. It holds:

- the four old lines (probe stand-in, capability flag, `scan_group_members`, `signal_same_group_members`), unchanged;
- `module.read_proc_identity=lambda pid: None`. With the stand-in scan the only caller is the absence check after the reap, and the only listed process is the reaped leader, so "absent" is the true answer. This is also what the real reader answered in these fixtures before, on Linux and on a host without `/proc`;
- tripwires on `read_proc_stat_identity` and `process_absent`: a fixture that reaches one of these target-only readers writes which one and ends with status 97;
- the bound: `signal.setitimer(ITIMER_REAL)` with a SIGALRM handler that writes "local fixture exceeded its bound", dumps the stack of every thread with `faulthandler`, and ends with status 98. The default is 120 s, and a fixture can set `LOCAL_FIXTURE_BOUND` before the lines.

### 4.2 The guard

`remoteAlphaESStatusFixtureScripts` parses every `*_test.go` file of the root package and evaluates each string expression: a literal, or a `+` chain of literals and package-level string constants. The guard then judges each script that names the boundary. It refuses a script that

1. replaces one of the three functions, or a pidfd primitive, without the whole boundary being replaced, where each function counts as replaced by a stand-in for the function or by stand-ins for its operating-system primitives (`os.listdir`; `os.pidfd_open` with `signal.pidfd_send_signal`; `os.open` with `os.pidfd_open`);
2. sets `PROCESS_CAPABILITY_READY` without running the real probe, unless the whole boundary is replaced;
3. calls `own_child_until_proved`, `terminate_child` or `prove_group_absent` directly, without the real probe or the live prelude, unless the whole boundary is replaced.

It also refuses a script that names the boundary and is joined from a part it cannot resolve, and it fails when it sees fewer than 22 scripts with the shared constant or fewer than 30 with the whole boundary replaced, so that a guard that no longer sees the fixtures cannot pass. A table of 41 sample scripts pins the rules.

What it sees at `1032c9c`: 78 scripts name the boundary. 30 replace it whole: the constant, the 20 sites, 2 scripts of the new file, and 7 older scripts with their own complete stand-ins (3 in the failure-witness file, the PR #21 fixture, `PostExitDescendantContainment`, and 2 P0t diagnostics). 2 are live fixtures with the boundary real: the thread-exec test calls the hold under the live prelude, and the unrelated-process test sets the flag after the real probe. No existing script had to be changed to satisfy the guard other than the 20.

### 4.3 The behavior tests

- `TestRemoteAlphaESServiceTLSStatusLocalBoundaryNeedsNoTargetFacility` denies every `/proc` open and listing and deletes `os.pidfd_open` and `signal.pidfd_send_signal` in the fixture process, then runs three fixed children through the real `run_fixed` and the real cleanup: one that ends by itself, one that leaves a process in its group, and one that the collector has to stop. All three must complete with no closeout uncertainty. This is a stand-in for a host without these facilities, not a run on one.
- `TestRemoteAlphaESServiceTLSStatusLocalFixtureFailsBounded` takes the identity line out of the constant. The guard must refuse that text. With the tripwires in place the fixture ends with status 97. With the readers answering as on a host without the facilities and a 3 s bound, it ends with status 98, and the output holds the bound's message and `prove_group_absent` in the stack. The whole constant returns `(0, b'fixed', b'')`.
- `TestRemoteAlphaESServiceTLSStatusLocalBoundaryDocumentsContract` holds the rule's text in the document.

### 4.4 The document

`.docs/system_overview/capability_probing.md`, section "Test Harness Use", gains three paragraphs: live and local fixtures and never a mixture; a fixture must not replace only part of the boundary, and why; the shared constant, the tripwire, the bound, the guard and the denied-facilities test. It ends: "This is test hygiene only. It changes no collector behavior, capability criterion, hold, signal, reap, lock, or publication rule."

`PLANS.md` is not changed. No redesign scope, seam status, sequencing or design intent changes. Order of work: the document paragraph first, then the constant, then the tests. One sentence of the paragraph (what a live fixture is) was corrected after the guard showed that the thread-exec live fixture does not run the probe.

### 4.5 Choices I made, with their reasons

- **No OS label anywhere.** The tests deny facilities by behavior and decide nothing by platform (AGENTS.md section 12).
- **Timer and signal, not a thread, for the bound.** A watchdog thread would make Python warn on every `os.fork()` of these fixtures, and `faulthandler.dump_traceback_later(exit=True)` ends with status 1, which a test could take for an expected failure.
- **120 s.** The longest leaf subtest of the affected tests takes about 1.3 s in this container, and the longest whole test 12.4 s. The bound is far from any real run and still below Go's default 10 minute limit.
- **The bound is in the shared constant only.** The seven scripts with their own complete stand-ins are run under a Go time limit or drive a model without real children, and the P0t fixtures are unchanged. I did not widen the change to them.
- **The thread-exec live fixture stays as audited.** It decides by the live prelude (it reads its own `/proc` entry and skips with a reason) and calls the hold in a bounded thread. The guard accepts the prelude for a direct call of the cleanup.

## 5. The affected sites, counted

20 fixture scripts, all in `remote_alpha_es_service_tls_status_test.go`, in 18 test functions and 2 shared helpers. Line numbers are those of the splice at `1032c9c` (`10-evidence/sites.txt`).

| Line | Function |
|---|---|
| 135 | `TestRemoteAlphaESServiceTLSStatusInputFIFORefusal` |
| 223 | `TestRemoteAlphaESServiceTLSStatusLeafSwapToFIFORefusal` |
| 277 | `runRemoteAlphaESTLSFixture` (helper) |
| 578 | `validateRemoteAlphaESTLSStatusDocument` (helper) |
| 819 | `TestRemoteAlphaESServiceTLSStatusBoundedChildRunner` |
| 905 | `TestRemoteAlphaESServiceTLSStatusOpenSSLGrammar` |
| 1216 | `TestRemoteAlphaESServiceTLSStatusChildSetupFailureReaps` |
| 1366 | `TestRemoteAlphaESServiceTLSStatusRelatedConfigHandling` |
| 1395 | `TestRemoteAlphaESServiceTLSStatusPublicationBoundary` |
| 1487 | `TestRemoteAlphaESServiceTLSStatusPublicationSetupFailure` |
| 1756 | `TestRemoteAlphaESServiceTLSStatusProtectedCustodyAndLocks` |
| 2029 | `TestRemoteAlphaESServiceTLSStatusReaderProtectedFile` |
| 2117 | `TestRemoteAlphaESServiceTLSStatusStrictJSONAndCanonicalPaths` |
| 2604 | `TestRemoteAlphaESServiceTLSStatusSafeAbsenceUnsafeAncestry` |
| 2655 | `TestRemoteAlphaESServiceTLSStatusExactOpenSSLArgvAndSelectedAnchor` |
| 2718 | `TestRemoteAlphaESServiceTLSStatusMaterialByteBinding` |
| 3215 | `TestRemoteAlphaESServiceTLSStatusSignalingWaitFailureCleanup` |
| 3396 | `TestRemoteAlphaESServiceTLSStatusZombieLeaderGroupDisposition` |
| 3453 | `TestRemoteAlphaESServiceTLSStatusSelectedAnchorOnlyTrust` |
| 3495 | `TestRemoteAlphaESServiceTLSStatusSingleSelectedTrustAnchorCardinality` |

- 26 existing top-level tests run one of these scripts, counted statically through the two helpers (`10-evidence/tests-that-run-a-shared-fixture.txt`, which also lists the one new test).
- **Measured:** 19 of the 26 reach the absence check through the identity reader. These are the tests that would not have returned on a host without the facilities. The other 7 refuse before a child is cleaned up: `InputFIFORefusal`, `LeafSwapToFIFORefusal`, `ProtectedCustodyAndLocks`, `PublicationBoundary`, `PublicationSetupFailure`, `SafeAbsenceUnsafeAncestry`, `StrictJSONAndCanonicalPaths`. Method: a marker write in the identity stand-in, one test per run (`10-evidence/reach-summary.txt`).
- No other test file had a partial boundary. The guard finds none, in any of the root package's test files.

## 6. Validation (cloud container, kernel 6.18, Go 1.26.5, test user with an emptied environment)

| Check | Result |
|---|---|
| The fault, simulated | section 2: returns on `f62d024`, still running after 8 s on `39a016c` |
| The 4 new tests on the committed bytes | pass (`new-tests-1032c9c.log`) |
| Whole root package, `1032c9c` against `7806170` | the same verdict for each of the 2,240 common tests and subtests (466 top-level). The same 8 top-level tests fail on both, for environment reasons. The 7 new tests and subtests pass. Durations of the 26 affected tests are unchanged (`verdicts-final-vs-base.txt`, both JSON logs) |
| `gofmt -l` | no output |
| `go vet .` | passes for Linux and for `GOOS=darwin` |
| CI | run [45109495444](https://github.com/evo-agi/Execution-Substrate/actions/runs/45109495444), job 137478347335, success, 04:03:09Z to 04:17:56Z, on GitHub's merge `16cdd00` of `1032c9c` into `110d377`. Root package `ok` in 114.377 s. The gate passed 41 packages (`ci-1032c9c/`) |

Mutants, each run against the 4 new tests on the committed bytes (`mutants/summary.txt`, one log each). The unmutated tree passes.

| Mutant | Caught by |
|---|---|
| M1 identity stand-in removed from the constant | guard (every site named), denied-facilities test (status 97), bounded test |
| M2 identity stand-in and tripwires removed | guard, denied-facilities test (ended by the bound), bounded test |
| M3 bound removed | bounded test: the overdue case is ended only by the Go limit of 180 s |
| M7 tripwires removed | bounded test: status 98 where 97 is expected |
| M4 one site put back to the old partial block | guard names `remote_alpha_es_service_tls_status_test.go:814`, and the floor of shared sites |
| M5 new fixture that only sets the flag | guard names the new file |
| M12 new fixture with the real probe and a scan stand-in only | guard names the new file |
| M8 signal stand-in removed from the constant | guard |
| M6 guard made blind (reads only the P0t files) | the floors |
| M9, M10, M11 each of the three rules switched off | the sample table |

12 of 12 are caught.

## 7. Failed or skipped validation

- **Not run on macOS.** Nothing here was executed on a Mac. `10-evidence/mac-instructions-4.txt` is the brief for that run: the 4 new tests, then the whole root package on `1032c9c` and on `trunk_dev`, and a comparison of the verdicts. It needs David's go in the writer thread.
- The commit `7806170` was deliberately not run on a Mac: a held fixture would leave processes behind there.
- The 8 failing top-level tests need another environment (root, or the target's tools) and fail on the base too. They are the known environment-only tests.
- The first mutant run was made before a last readability change to the guard. All 12 were run again on the committed bytes, and only that run is in the evidence.
- No box run. Nothing in this commit runs on the Remote Alpha host.

## 8. Limits

- The guard reads text. It judges one script as a whole and does not follow control flow: a script that replaces two functions in one block and the third in another, unrelated block passes. It knows three ways of replacing (assignment, `mock.patch.object`, namespace entry). A replacement through `setattr` with a computed name is not seen. A whole fake `os` or `signal` module counts only for the primitives that the script defines.
- A script that is built at run time from separate strings is judged part by part.
- The floors (22 and 30) have to be lowered together with a fixture that is removed.
- The denied-facilities test shows that the shared boundary needs neither `/proc` nor the pidfd operations. It does not show anything else about macOS.
- Fixtures outside the shared constant have no new bound (section 4.5).

## 9. Provenance

- Recipe v2, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before every run.
- Repair flow of section 5.5: tip `7806170` recorded, `git reset --mixed` to the base `110d377`, upstream pinned to `origin/trunk_dev`, nothing staged, two runs identical, reset back, commit, clean status, fast-forward push (`repair-manifest.sh`, `repair-manifest.log`).
- Manifest `4fa9dc34dfdf3df4d65698e64b619764b19087b75b2f5fd83252f60fe37151d4` (`manifest.json`), 8 paths. Reproduced byte for byte in a fresh clone of the pushed commit (`fresh-clone-repair.log`).
- The 5 paths of the audited manifest `1a8f223b…df51` have the same entries in the new manifest, and their blobs at `1032c9c` equal those at `39a016c`. The 3 further paths are the repair: 2 test files and 1 document.
- `git diff 7806170 1032c9c`: SHA-256 `10ead230d145ef642192c1fe314018a8ef1c3f64fe18630b0b85be0ddd8c9863`.
- File hashes at the head: test file `9328380f4cf98cdc7effe4fede355bbb9fa232b9c8d376e5ec8d2d6604db725f` (blob `edee66fd`), new test file `255c8e1bf9ade6188998960318e55c0e5a6a911c530e032321e182fe7e9092fc` (blob `6d56edba`, 27,423 bytes), document `8fe191152741b159bde879ac0b86293c41254f15c861f03c9d89c448b2f8113e` (blob `25a68fc7`).
- The gate data sent for `7806170` at 03:15Z (manifest `b6476378…7d5a`) are superseded by this commit.

## 10. Assumptions and unresolved points

- **Inference:** that the fixtures passed on macOS before PR #22. The three PR #21 tests did, in the Mac run of 02:10Z. For the others it follows from the old reader's code and is not measured. The Mac run's comparison with `trunk_dev` will show it.
- **Unknown:** whether any other root-package test behaves differently on macOS with PR #22. The guard finds no other partial boundary, and the Mac run compares the whole package.
- The containment PR will add its own stand-in to the shared constant. It is paused until this repair is merged.

## 11. Confidence

- High that the 20 fixtures no longer reach the real readers: stand-in, tripwire, guard, and the mutants.
- High that nothing changed on Linux: identical verdicts for 2,240 tests and subtests.
- Medium that the root package now finishes on macOS: shown only by denying the facilities on Linux, until the Mac run.

## 12. Delivery and effect status

- Pushed: one commit to the thread's own topic branch. PR description updated. Nothing merged.
- No production or live-service effect. No box run, no Mac run.
- Open: narrow audit of `7806170..1032c9c` (3 files), the Mac run with David's go, then a new merge gate on the audited head and the squash merge without David's review under the standing policy for test, document and script changes.
- Evidence: `10-evidence/` with `SHA256SUMS.txt`.
