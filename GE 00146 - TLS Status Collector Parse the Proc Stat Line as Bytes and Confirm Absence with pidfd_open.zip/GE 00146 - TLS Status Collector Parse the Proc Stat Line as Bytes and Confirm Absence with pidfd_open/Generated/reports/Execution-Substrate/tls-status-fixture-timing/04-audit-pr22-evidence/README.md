# Evidence for 04-audit-pr22.md (ES draft PR #22, head 64a0e0c)

Everything here was produced on the audit's cloud container (kernel 6.18.44-fc-v726, run as root). The work used scratch exports of base (`/opt/audit/b22`), head (`/opt/audit/h22`) and an audit-only sketch (`/opt/audit/s22`), plus processes the audit started and reaped. Scripts are stored as `.txt` so that they are read, not run, from here.

## Provenance

- `provenance22.sh.txt` is the recipe run. The opening run used the same steps before the script was saved as a file.
- `manifest-{open,close}-{1,2}.json` and `.stdout.txt`: all four are byte-identical, `263df630…8351`.
- `provenance-close.log`.

## A4-1: ESRCH and ENOENT for a live process

| File | What it holds |
|---|---|
| `esrchprobe.c.txt`, `execstorm.c.txt`, `c-probes.log` | Raw kernel answers for a live exec-storming child (warm, drop_caches, fresh proc instance) |
| `pidfdprobe.c.txt` | `pidfd_open` answers (also in `c-probes.log`) |
| `esrch_collector.py.txt`, `esrch-*.json` | The real `read_proc_identity` and `scan_group_members` on head, base and the sketch |
| `prove_e2e.py.txt`, `prove-e2e-*.json`, `prove-e2e*.log` | The real `prove_group_absent` with only its pause removed |
| `make_sketch22.py.txt`, `sketch-reader-confirmation.diff` | The audit-only repair sketch (scratch, never pushed; collector sha256 `96de520d…6664`) |

Notes on how the `esrch-*.json` files were made:

- `esrch-head-remount.json`, `esrch-base-remount.json`, `esrch-head-drop.json`, `esrch-head-warm.json`, `esrch-sketch-remount.json` and `esrch-sketch-drop.json` came from an earlier probe revision. That revision caught only `Incomplete` in scans and counted other exceptions without naming them.
- The first base run with the host `/proc` plus `drop_caches` crashed on a raw `ProcessLookupError` from the base scan, which is itself evidence (`esrch-collector-2-base-drop-crashed.log`). It was re-run with the final probe as `esrch-base-drop.json`.
- During that re-run the writer's tests ran concurrently. Their non-ASCII-named processes made 26,780 base scans raise, which is the original defect.

## Hostile names, forged members, states, staging, churn, fuzz

- `attack22.py.txt` is the final harness. Its helpers are `threadleader.c.txt` and `vforkd.c.txt`.
- `attack-head.json` and `.log` are the head run. Its only failure is S3 `exec_storm_thread` returning `('value', (-1, …))`, which is finding P4-2.
- `attack-head-run1-harness-bugs.*` is the first run. It had two harness bugs: S3 read the identity before the child's `setsid`, and S5 tried `setpgid` across sessions. Both were fixed in the final harness.
- `attack-sketch.*` is the sketch run.
- `attack-mut-K*.json` and `.log` are the harness on mutants, from the revision before S7 was made robust. A crash there means the mutant returned a value taken from the wrong fields.
- `fuzz-*.json` is S7 re-run with the final harness for head, the sketch and the mutants.

## PID reuse

- `pidreuse.py.txt`, `nsinit.c.txt`, `pidreuse-{h22,b22}.json`, `pidreuse.log`. These ran in a private PID namespace, using `ns_last_pid`.

## P4-1: fork relay

- `relay.c.txt`, `nsinit.c.txt`, `relay_demo.py.txt`.
- `relay-{h22,b22}-promptreaper.json`: 40 runs each in a private PID namespace whose PID 1 reaps at once.
- `relay-h22-containerreaper.json`: 20 runs with this container's PID 1.
- `relay-h22-promptreaper-10trials-first-detector-fix.json`: 10 runs with the first reliable detector. An earlier 5-run attempt used a `/proc`-scan detector that, like the collector, could not see the relay, and it was overwritten.

## Writer's tests and mutants

- `newtests-r22.log`: head tests against the base collector, all 4 failing.
- `newtests-h22.log`: the same tests on head, all passing.
- `reps-head-idle-n30.log` and `reps-head-load-n30.log`, with `stress-ng.log`.
- `mutants22.py.txt` and `mutants-h22-writer-tests.log`.

## Root package and hygiene

- `rootpkg.sh.txt`, `rootpkg-{base,head}.summary.txt` and `.json.gz`, `rootpkg-vault-rerun.log`, `format-vet.log`.

## Leak scan

The chat-archive scanner (`ge_chat_archive.py scan` with the known-numbers list) was run over the report and every file here. Its result is recorded in the delivery message. `SHA256SUMS.txt` covers every file except itself.
