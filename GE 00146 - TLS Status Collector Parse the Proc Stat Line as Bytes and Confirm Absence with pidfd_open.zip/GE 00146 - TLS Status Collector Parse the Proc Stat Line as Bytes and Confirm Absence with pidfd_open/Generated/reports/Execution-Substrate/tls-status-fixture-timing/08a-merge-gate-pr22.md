# MERGE-GATE PROVENANCE RE-CHECK: Execution-Substrate PR #22 after the trunk_dev merge (7806170)

**Result: PASS.** The new head `7806170` is a conflict-free merge of the audited head `39a016c` and `trunk_dev` at `110d377`, the squash of PR #21. Its change against the new base is byte-identical to the audited change, the writer's new manifest is reproduced, and CI is green on it. PR #21 and PR #22 share no file. Both PRs' TLS status tests pass on the merged tree. The ACCEPT of `08-reaudit-pr22.md` carries over to `7806170`.

**Status: superseded for the merge.** At 03:22Z the coordinator stopped this re-check because the writer is adding a test-only third commit to PR #22. The message reached me after the checks had run, so the note is complete, but its PASS holds only for `7806170`. The new head gets a narrow re-audit of its delta, and this note is not gate evidence for it.

Written 2026-11-23 at 03:24Z by the audit thread that wrote `08-reaudit-pr22.md`. Read-only: no edit, commit, push, comment or merge. Evidence: `08a-merge-gate-pr22-evidence/`.

| Check | Result |
|---|---|
| Recipe bytes | `governed_execution_audit_patch_manifest_v2.py` SHA-256 `c08597e2…a1ca`, OK |
| Remote state at 03:17Z | topic branch `claude/project-thread-k69qcw-collector-process-names` at `78061701d1dc3e4ba784a0e6f0e8da9f452f93f6`; `trunk_dev` at `110d377a459471e94aa14cc83877f554ae62f893` (PR #21's squash, parent `f62d024`, the audited base). The PR reports head `7806170`, base `110d377`, mergeable state clean, still a draft. Confirmed again at 03:21:59Z with `git ls-remote` |
| Shape of the new head | merge commit, parents `39a016c` (audited) and `110d377`; both are ancestors of the tip |
| Tree | `218207f2a963d90a7cdc80ebb889c83b15acf624`, equal to `git merge-tree --write-tree 39a016c 110d377`, so the merge added nothing of its own |
| PR #21's bytes | the tree of `110d377` is `a6816483…`, the tree of the accepted PR #21 gate head `143167d` (`07a-merge-gate-pr21.md`). At the tip, PR #21's test file is blob `c6652a34…`, as on `trunk_dev` |
| PR #22's bytes | the five PR files have the audited blobs at the tip, among them the collector `16218b6c…` (SHA-256 `372161f1…b4ff`) and the new test file `1afde801…` |
| Textual diff | `git diff 110d377 7806170` is byte-identical to `git diff f62d024 39a016c` (SHA-256 `c13aa669…eb20`, 5 files) |
| Other direction | `git diff 39a016c 7806170` is byte-identical to `git diff f62d024 110d377`: only `remote_alpha_es_service_tls_status_test.go`, +84/−7, PR #21's change. Files changed by both PRs: 0 |
| Range-diff | `git range-diff f62d024..39a016c 110d377..7806170`: `64a0e0c = 64a0e0c` and `39a016c = 39a016c`, both equal |
| Manifest | tip checked out, `git reset --mixed 110d377`, upstream re-pinned to `origin/trunk_dev`, two runs byte-identical: SHA-256 `b6476378e612c9c675927200091ba63be2b397f2186b33e848033df51d2a7d5a`, 5 paths, textual diff SHA-256 `3bd7b520…e493`. It equals the writer's new manifest. Against the audited manifest `1a8f223b…df51` only the field `head` differs (`f62d0245…` to `110d377a…`) |
| CI | run [45103477792](https://github.com/evo-agi/Execution-Substrate/actions/runs/45103477792), job 137459365287 "build, vet and test": **success**, 03:01:23Z to 03:14:45Z, head SHA `7806170`. It tested GitHub's merge `30e1ffb` of `7806170` into `110d377`; I fetched that ref, and its tree is `218207f2…`, the tip's tree. Root package `ok` in 111.0 s; "test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed". No FAIL line comes before the gate line. All 50 TLS status FAIL lines come after it, in the step that expects the listed tests to fail, and belong only to the three tests that need another environment |
| Both PRs' tests on the merged tree | `git archive` export of `7806170`, built and run as the unprivileged user `ci` (Go 1.26.5, kernel 6.18.44, 4 CPUs). PR #21's three tests, `-count=10`: 30 of 30 runs pass, with 130 of 130 subtests. PR #22's five tests, `-count=5`: 25 of 25 runs pass. Every `TestRemoteAlphaESServiceTLSStatus…` test once: 77 pass and 3 fail, the same three tests that need another environment and that CI lists (`FailureWitnessBootstrapOwnedTerminal`, `RootLoadedStageCustody`, `StageFIFOSubstitution`). The top-level outcomes equal those of the combined tree in `08-reaudit-pr22.md` |
| Control | the same tree with PR #21's mutant M05 in the collector (`m22-m05.diff`), PR #21's three tests, `-count=3`: caught in every run: `term`, `scan_plain_once` and `post_reap_scan_once` fail 3 of 3 times with `descendant_gone` and `no_return_while_member_visible`, as in `08-reaudit-pr22.md` |

The collector and PR #21's test file in the export have the same SHA-256 as in the combined tree of `08-reaudit-pr22.md` section 8 (`372161f1…b4ff` and `23735544…b0f6`), so those runs were on these bytes too. This run repeats them from the real merge.

**Observations (not gate conditions):**

1. The PR body still describes `39a016c`: it says "Independent audit of `39a016c`: not performed", and its target identity names base `f62d024`, head `39a016c`, manifest `1a8f223b…df51` and CI run 45097957121. Before the squash it should name base `110d377`, head `7806170`, manifest `b6476378…7d5a`, CI run 45103477792, the ACCEPT of `08-reaudit-pr22.md` and this note.
2. The three commits carry a `Co-Authored-By` trailer with a model name. GitHub's default squash message keeps such trailers. PR #21's squash `110d377` on `trunk_dev` carries the same trailer, so this matches what is already merged. I note it only because the project's rule for the Maintenance Agent merge asks for a squash message without a model name. Whether that rule also applies here is the coordinator's call.

**What this does not re-check:** the stress probes, the `pidfd_open` fallback runs and the mutants of `08-reaudit-pr22.md` were not re-run. The PR's bytes are unchanged, and PR #21 changes only a test file that the collector does not read.
