# NARROW RE-AUDIT REPORT: Execution-Substrate PR #22, third commit (local test fixtures stand in for the whole process boundary)

**Verdict: BLOCK, on a small test-only repair (A11-1, A11-2). The repair itself works.** On an emulated host without `/proc` and without the pidfd operations, the 20 fixtures of `1032c9c` no longer hang. Under the same emulation the gate head `7806170` stops in exactly the 19 tests the writer measured (17 hang, 2 end on their own fixture limits), and `trunk_dev` passes all 26. I also ran the whole root package once under the emulation. On `1032c9c` it finishes in 116 s, with no timeout, no bound reached, no tripwire and no leftover process, and every one of its 2,235 verdicts shared with `trunk_dev` is the same as on `trunk_dev` under the same emulation. The 120 s bound cannot turn a stuck fixture into a pass at any site that starts a child. The gate data reproduce (manifest `4fa9dc34…51d4`, CI green on the tip's tree). What blocks is the guard, the machine check that is supposed to keep this class of fault out:

- **A11-1.** It does not see the most common way the package's fixtures declare the capability: replace the probe with a stand-in, then call `main()` or `diagnostic_main()`, which set the flag themselves. 15 current scripts have that shape. Each is safe only because it also replaces `collect`, `run_fixed`, or every function that reaches `run_fixed`, and the guard does not model any of that. A copy that keeps `collect` real would reach the real readers unseen and hang on a Mac with no bound.
- **A11-2.** The shared constant needs `os` from the fixture, but one of the 20 sites does not import it. There the bound and the tripwire end in a `NameError` (exit 1), not in status 98 or 97.

A rule that I tested over every script in the package accepts all of today's fixtures and refuses the missed shapes (section 5.3). The Mac brief's step 6 can end only this session's own processes as long as T is the literal path. It has one failure mode worth closing before David runs it: if T is empty, the filter matches every process on the Mac (section 8).

Written 2026-11-23 by the audit thread that wrote `04-`, `08-` and `08a-…pr22.md`, at the coordinator's request of 04:19Z. Read-only. No subagents were used (section 2). Evidence: `11-reaudit2-pr22-evidence/`.

## 1. Audit target

| Field | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | [#22](https://github.com/evo-agi/Execution-Substrate/pull/22), draft, head `1032c9c9f836b29b63ff00462806d5f3cd5cba19`, one parent `7806170` (the gate head of `08a`), fast-forward |
| Base | `trunk_dev` at `110d377a459471e94aa14cc83877f554ae62f893` (PR #21's squash) |
| Topic branch | `claude/project-thread-k69qcw-collector-process-names` |
| Tree | `cae84b6e80ddd4f18ca48e09d364e1061f48c2e5` |
| Audited delta | `git diff 7806170 1032c9c`, SHA-256 `10ead230d145ef642192c1fe314018a8ef1c3f64fe18630b0b85be0ddd8c9863`, 3 files, +650/−120: `remote_alpha_es_service_tls_status_test.go` (PR #21's file), the new `remote_alpha_es_service_tls_status_local_boundary_test.go`, and `.docs/system_overview/capability_probing.md` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2…a1ca`, verified |
| Canonical manifest | SHA-256 `4fa9dc34dfdf3df4d65698e64b619764b19087b75b2f5fd83252f60fe37151d4`, 8 paths, textual diff `71d32ada6483b2e9d917b115da0508d7447e26d88d3fb79eeef86aa72167cc1e`, upstream `origin/trunk_dev` |
| Writer report | `10-repair2-pr22.md`, SHA-256 `179204c5b26454dbe3a7db3e44baf593de8fe236663e71115b80c3eff7a4131b`, verified. `10-evidence/SHA256SUMS.txt` (SHA-256 `4e4a9b8e…d9e4`): 35 of 35 entries match |
| CI | run [45109495444](https://github.com/evo-agi/Execution-Substrate/actions/runs/45109495444), job 137478347335 "build, vet and test", success, 04:03:09Z to 04:17:56Z |

## 2. Audit posture

- Read-only toward the repository and GitHub. Local scratch exports: `h22c` (`1032c9c`), `m22` (`7806170`, from `08a`), `t110` (`110d377`), and copies for mutants (`h22y3`, `h22y9`) and for two audit-only test files that call the guard's own functions (`h22g`). The audited clone was used only for the manifest, diffs and `git show`.
- Go tests ran as the unprivileged user `ci`, emptied environment, Go 1.26.5, Python 3.13.18, kernel 6.18.44, 4 CPUs.
- **Emulated host.** `audit_no_proc_pidfd.py` (evidence) is loaded into every Python process by a `.pth` file in the system `dist-packages` directory. It does nothing unless `AUDIT_EMULATE_NO_PROC_PIDFD=1` is set. When set, it makes every open, listing, stat, readlink, access or chdir of a `/proc` path fail with ENOENT, and it deletes `os.pidfd_open`, `os.P_PIDFD` and `signal.pidfd_send_signal`. The Go test binary passes its environment to the fixtures, so every fixture of a run inherits the emulation. This covers the facilities that matter here, not macOS as a whole, and it is mine, independent of the writer's `macsim.py` and of the denial lines in the new test. I removed both files after the runs (section 9).
- **No subagents.** I covered the perspectives myself: gate data (section 3), the stand-in and the bound (section 4), the guard (section 5), the reach claim (section 6), tests and mutants (section 7), the Mac brief (section 8).

## 3. Provenance and gate data for `1032c9c`

`provenance-r22c.sh.txt`, log `provenance.log` (04:24Z).

| Check | Result |
|---|---|
| Recipe bytes | OK |
| Remote state | topic `1032c9c`, `trunk_dev` `110d377`; `refs/pull/22/head` = `1032c9c` |
| Shape | one commit on top of `7806170`; `110d377` and `39a016c` are ancestors of the tip |
| Third commit | diff SHA-256 `10ead230…9863` (as reported), 3 files. Files of the audited change that it touches: 0 |
| Audited bytes | the 5 paths of the audited change have the blobs of `39a016c` at the tip (collector `16218b6c`, SHA-256 `372161f1…b4ff`) |
| PR #21's test file | `c6652a34` at the base and at `7806170`; the third commit changes it to `edee66fd` (20 blocks replaced by the constant, the constant added). No line of PR #21's fixture is touched (section 7.1) |
| Range-diff | `git range-diff f62d024..39a016c 110d377..1032c9c`: `64a0e0c = 64a0e0c`, `39a016c = 39a016c`, `1032c9c` new |
| Manifest | tip checked out, `git reset --mixed 110d377`, upstream `origin/trunk_dev`, two runs byte-identical: `4fa9dc34…51d4`, 8 paths, textual diff `71d32ada…cc1e`. It equals the writer's `manifest.json`. Against the audited manifest `1a8f223b…df51`: the 5 old entries are identical, 3 entries are new (the 2 test files and the document), and only `head` and `textual_diff_sha256` differ at the top level |
| File hashes | test file `9328380f…725f`, new test file `255c8e1b…92fc`, document `8fe19115…113e`, as reported |
| CI | success on GitHub's merge `16cdd00` of `1032c9c` into `110d377`. I fetched that ref: its tree is `cae84b6e…`, the tip's tree. Root package `ok` in 114.4 s; "test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 39 tests skipped themselves, all of them listed"; no FAIL line before the gate line; the 50 TLS status FAIL lines after it belong only to the three tests that need another environment |

This is the gate data for `1032c9c`. A repair for A11-1 and A11-2 will need new gate data.

## 4. The shared boundary and the bound

### 4.1 The identity stand-in is neutral on Linux and complete for the 20 fixtures

In the collector, `read_proc_identity` has three callers: `scan_group_members`, `signal_same_group_members` and `prove_group_absent` (the probe's backend also holds it, but it is unused once the probe is replaced). With the scan and the signal replaced, only the absence check after the reap is left. Before this commit, on Linux, that check compared the real identity of the reaped leader with the stand-in scan's `(pgid, 0)`, which never matched, so it answered "absent" at once. `lambda pid: None` gives the same answer. The writer's claim holds. Pre-existing, unchanged: these 20 fixtures never tested group absence at all.

### 4.2 The bound cannot turn a stuck cleanup into a pass where a child is started

The bound ends a stuck fixture with status 98, a message and a stack on stderr. I read how each of the 20 Go callers judges the script:

- 18 sites require exit 0 and parse JSON from the output, or (`PublicationBoundary`) accept a nonzero exit only together with empty output and checked canonical bytes. Status 98 or 97 fails each of them.
- `validateRemoteAlphaESTLSStatusDocument` (site 578) is the exception: in its refusal cases any nonzero exit counts as the expected refusal (`err == nil` is the only check). Its script only parses and validates a document and never starts a child, so neither the hold nor the tripwire is reachable there. Treating any crash as a refusal is older than this commit.
- The collector does not use SIGALRM or the real-time timer. It blocks only SIGHUP, SIGINT, SIGQUIT and SIGTERM, and only while it publishes. The timer is not inherited by forked children.

### 4.3 The bound depends on `os` from the fixture (A11-2)

The constant's tripwire and its SIGALRM handler call `os.write` and `os._exit`. The constant's comment says it is for a fixture that has "imported os", and 19 of the 20 sites do. `validateRemoteAlphaESTLSStatusDocument` imports only `importlib.util, json, sys`. I ran the constant on the real collector with a 1 s bound, in a hold that never resolves (`demo/`):

| Script | Result |
|---|---|
| With `import os` | status 98 after 1.1 s, "local fixture exceeded its bound" and the stack with `prove_group_absent` |
| Without `import os` | status 1 after 1.1 s, `NameError: name 'os' is not defined` raised from the handler, no message from the bound |
| Site 578's own shape, without `os`, with a validation that stalls | prints `NameError`, status 1, which this helper accepts as the expected refusal |

In the demo the alarm landed in the hold's `time.sleep`, outside its `try`, so the `NameError` ended the script. Inference from the code, not run: when the alarm lands inside the `try` of `prove_group_absent`, the `NameError` is caught there like any scan fault. The hold then goes on, and the one-shot timer never fires again. So without `os` the bound ends the fixture only by luck, and with status 1, which the writer rejected for `faulthandler` for exactly this reason. Today this affects one script that cannot reach a hold. But the constant is meant to be pasted into new fixtures, and nothing checks the precondition. **Repair R2:** make the constant self-contained (`import os as _os` inside it, used by the tripwire and the handler), and pin that in the bounded test (run the overdue case in a script that does not import `os`).

## 5. The guard

### 5.1 What it sees today

I dumped every string the guard extracts, with its own judgement, through an audit-only test that calls the guard's functions (24,738 resolved strings and 453 unresolved ones; the evidence keeps the 94 that name a boundary function or the probe, `scripts-dump-boundary.json.gz`). 78 name the boundary, 30 replace it whole, and 0 are refused, as the writer reports. No unresolved string names a boundary function or the probe.

### 5.2 Shapes it does not refuse

Judged with the guard's own `remoteAlphaESStatusBoundaryFault` (`guard-samples.log`):

| Shape | Judged | Refused |
|---|---|---|
| G1: probe stand-in, then `module.main([...])` | no | no |
| G2: probe stand-in, then `m.diagnostic_main()` | no | no |
| G3: scan and signal stand-ins, then `module.read_proc_identity=original` (restored) | yes | no |
| G4: probe stand-in, flag set with `setattr(module,'PROCESS_CAPABILITY_READY',True)` | yes | no |
| G7: the three names assigned on an unrelated object | yes | no |
| G8: the shared constant, then `module.read_proc_identity=real_identity` | yes | no |

Two further shapes were refused, correctly: G5 (scan via `setattr`, flag set by hand) and G6 (flag set through `vars(module)`). Section 8 of the writer's report lists `setattr` with a computed name, control flow, and joined strings. G3, G7 and G8 are "an assignment counts as a stand-in whatever it assigns". They are unlikely in practice and belong in that list. G4 is `setattr` with a literal name, which the report does not mention.

**G1 and G2 are the finding (A11-1).** `main()` and `diagnostic_main()` run the probe and then set `PROCESS_CAPABILITY_READY = True` themselves (collector, `main`, and `diagnostic_main`). Replacing the probe and calling either one is therefore the same as setting the flag by hand, which rule 2 refuses. But the guard sees neither: `validate_process_capability` is not in its list of names to look for, and its "ready" rule looks only for the flag's name. The document's rule says a local fixture "replaces the probe and the whole boundary". So a probe stand-in on its own is exactly the partial injection the guard exists to refuse.

This shape is common. 45 current scripts replace the probe. Of the 15 that call `main` or `diagnostic_main` without the whole boundary, every one also cuts every path to `run_fixed`, which the guard does not model (`candidate-rule.log`):

- 4 replace `run_fixed`;
- 8 more replace `collect`, and the 2 P0t scripts among them also replace `diagnose_first_rejection`;
- 3 in the failure-witness file replace `cert_role`, `key_pair` and `verify_chain`, the only callers of `run_fixed` below `collect`.

I checked that by hand, and with the collector's call graph: `run_fixed` is called only by `cert_metadata` (itself called only by `cert_role`), `cert_role`, `key_pair` and `verify_chain`, and these three are called only by `collect` (from `main`) and `diagnose_first_rejection` (from `diagnostic_main`). A new fixture copied from one of them that keeps `collect` real, to exercise a real child through `main`, passes the guard and passes on Linux CI. On a Mac it reaches the real scan, signal and identity reader, and the hold never returns. It also has no bound, because the bound lives only in the shared constant. That is the incident this commit repairs.

### 5.3 A rule that closes G1 and G2 without touching a fixture

I tested this rule over every script of the dump. A script that replaces `validate_process_capability`, and is not a whole-boundary script, must also:

- if it calls `main`: replace `run_fixed` or `collect`, or all three of `cert_role`, `key_pair` and `verify_chain`;
- if it calls `diagnostic_main`: replace `run_fixed` or `diagnose_first_rejection` or those three (the version I ran also asked for `collect` here, which is stricter and still accepts every current script).

A probe stand-in with a direct `run_fixed` call is safe while the flag stays false (`run_fixed` refuses), which rule 2 already covers. The rule accepts all 45 current probe-replacing scripts and refuses G1 and G2. **Repair R1:** add `validate_process_capability` to the names the guard looks for. Add a rule of this kind or a stricter one (the writer chooses, for example "a probe stand-in requires the whole boundary or a stand-in for `run_fixed`"). Add G1 and G2 to the sample table. Optionally add `setattr` with a literal name (G4) and list G3/G7/G8 under the limits.

## 6. The reach claim: 19 of 26, measured independently

Static count: the 20 sites lie in 18 test functions and 2 helpers. The helpers are called by 11 and 3 tests, and no other function calls them. That makes 26 existing top-level tests (29 with the 3 new tests that use the constant), the same set as `tests-that-run-a-shared-fixture.txt`.

Behaviour: each of the 26 tests ran alone on the emulated host, with a 45 s Go limit on `7806170` and `110d377` and 200 s on `1032c9c` (`emul-runs.sh.txt`, `phaseA-*.summary`, one log per test).

| Commit | The 19 tests the writer measured as reaching the identity reader | The other 7 |
|---|---|---|
| `7806170` (before this commit) | **none completes**: 17 hit the 45 s limit (`panic: test timed out`, each with one fixture left behind, orphaned to PID 1, which I then ended); `SingleSelectedTrustAnchorCardinality` and `ZombieLeaderGroupDisposition` fail on their own 10 s and 5 s fixture limits ("timed out: context deadline exceeded") | 7 of 7 pass |
| `110d377` (`trunk_dev`, collector before PR #22) | 19 of 19 pass | 7 of 7 pass |
| `1032c9c` (head) | 19 of 19 pass, in about the same times as on `trunk_dev`, no leftover | 7 of 7 pass; the 4 new tests pass too |

The set that stops on `7806170` is exactly the writer's "calls=yes" set, and the set that passes is exactly "calls=no". The writer measured which tests reach the stand-in on the head. I measured which tests fail to finish without the stand-in on a host without the facilities. Both say 19 of 26. Inference, from section 4.1: the stop is in `prove_group_absent`. That is the only caller of the identity reader left in these fixtures. I did not take a stack of the stuck fixtures here; the bounded test shows that stack for the same fault.

## 7. Tests and mutants

### 7.1 The touched file and the new tests

- The diff of `remote_alpha_es_service_tls_status_test.go` consists of the 20 replaced blocks and the new constant. PR #21's three tests are not touched. They ran on the head in the whole-package runs (section 6).
- The four new tests on `1032c9c`, `-count=5`: 20 of 20 pass (`h22c-new-tests-n5.log`). The guard logs "78 scripts name the process boundary, 22 use the shared local boundary, 30 replace the whole boundary". Both floors are met exactly.
- Whole root package, without the emulation: `1032c9c` and `7806170` agree on all 2,240 shared verdicts, and the 7 that exist only on `1032c9c` (the new tests and subtests) pass. The same 14 top-level tests fail on both. These are the three TLS status tests that need another environment, plus 11 that fail on how this container is set up. The ones I read failed on file modes of the scratch export (0664 where 0644 is expected), on a missing git repository in the export, on macOS paths such as `/private/tmp`, and on the Mac's user name. The writer counted 8 such tests in its own container. What matters here is that the set is the same on both commits.
- Whole root package under the emulation (section 6): `1032c9c` against `trunk_dev`: 0 different verdicts in 2,235 shared, the same 14 failures. The 12 verdicts that exist only on the head are PR #22's own tests and pass or skip. On `1032c9c` the emulated run differs from the plain run only in that the three live tests skip, since they read their own process entry first. That is the documented behaviour for a host without `/proc`. Timings: 116 s emulated, 117 s plain.

### 7.2 Mutants of my own, against the four new tests

| Mutant | Result |
|---|---|
| Y3: default bound `120.0` → `0.0` (`setitimer` with 0 disarms the timer, so none of the 20 sites has a bound) | **survives**, 4 of 4 pass: both behaviour tests set `LOCAL_FIXTURE_BOUND` themselves, so the default is never exercised |
| Y9: `PROCESS_CAPABILITY_READY` removed from the guard's list of names to look for | **survives**: every current script that sets the flag also names another boundary function, and the sample table calls the rule directly, without that filter |

The writer's 12 mutants were not re-run. Their logs and summary are in `10-evidence/mutants/`, and the mechanism of each is visible in `apply.py`. **Repair R3 (with R1):** pin the default bound, for example by asserting the value in the constant or by one case that omits `LOCAL_FIXTURE_BOUND`. Also pin the name list, for example with a sample that names only the flag, judged through the same filter as the scan.

## 8. The Mac brief (`10-evidence/mac-instructions-4.txt`), step 6

The question was whether step 6 can touch anything else on David's Mac.

**What selects a process.** Only processes whose command line contains the string T. T is a new `mktemp -d` folder with a random six-character suffix, so only something started in this session can name it. A leftover fixture does: on the emulated host every leftover of `7806170` was the Python fixture itself, orphaned to PID 1. Its arguments carry the collector's path inside the tree (`$T/clone/scripts/internal/…` on the Mac), so the filter finds it. The step's own shell line contains T as well, but it also contains "grep" and is dropped by `grep -v grep`. No collector fixture script contains the word "grep" (checked over the dump). `kill` without sudo cannot reach another user's process.

**Can it end anything else?** Not while T is the literal, non-empty path. There are two residual risks, and a deterministic fix for both:

1. **Empty T.** The brief writes `"$T"` in every step. In Claude Code the shell's variables do not carry over from one command to the next, so the agent must write the literal path each time. The earlier Mac run did so. If an agent ran step 6 with T unset, `grep -F ""` would match every line, and the listing would show every process on the Mac (minus lines containing "grep"). Only the agent's reading of "these tests started" would then stand between that list and `kill -KILL`. The same applies to step 9, whose removal command the brief leaves to the agent.
2. **PID reuse** between the listing and the kill. macOS normally hands out PIDs in increasing order, so reuse within seconds is very unlikely (from documentation, not checked here). It costs one line to exclude.

Recommended step 6 (the same guard line at the top of steps 4 to 9 would also cover the removal):

```
T='/Users/ds/Repositories/Playground/es-mac-run.XXXXXX'   # the literal path printed in step 1
case "$T" in /Users/ds/Repositories/Playground/es-mac-run.??????) ;; *) echo "T is wrong: stop"; exit 1;; esac
test -d "$T" || { echo "T does not exist: stop"; exit 1; }
ps -axo pid,ppid,pgid,stat,etime,command | grep -F -- "$T/" | grep -v -F -- 'grep -F'
# only for a pid listed above:  ps -o command= -p PID | grep -qF -- "$T/" && kill -KILL PID
```

**What it does not see.** Descendants of a fixture whose command lines do not name T. The fixed children run from `t.TempDir()` under `$TMPDIR`, outside T. On the emulated host there were none: the fixture had reaped its child before the hold. A Mac run that does show a leftover should also report `ps -axo pid,ppid,pgid,stat,etime,command -U "$(id -u)" | grep -E 'python3|openssl'`, report only, no kill.

Two more points on the brief:

- After a repair for A11-1 and A11-2 the head changes. The Mac run should test the repaired head, not `1032c9c`.
- Steps 5 and 7 compare verdicts by test name, and the emulated whole-package runs of section 6 give the expected picture in advance.

## 9. Findings

### A11-1 (low, test-only; blocks): the guard misses a probe stand-in followed by `main()` or `diagnostic_main()`

Section 5.2. The documented rule is broader than what the guard refuses, in the shape that 15 current fixtures already use. Required: R1 (section 5.3).

### A11-2 (low, test-only; blocks with A11-1): the shared constant depends on the fixture's `os`, and one site lacks it

Section 4.3. Required: R2.

### A11-3 (low, test gap): the default bound and the guard's name list are not pinned

Section 7.2, mutants Y3 and Y9. Required with R1: R3.

### Observations (no action required by this audit)

- **O11-1.** Section 8 of the writer's report should list G3/G7/G8 (any assignment counts) and `setattr` with a literal name.
- **O11-2.** `validateRemoteAlphaESTLSStatusDocument` accepts any nonzero exit as a refusal. This is older than PR #22. A refusal case could check the printed exception name.
- **O11-3.** Mac brief step 6: the guarded form of section 8.
- **O11-4.** The emulation files were removed after the runs: `audit_no_proc_pidfd.py` and `.pth` are gone from `/usr/local/lib/python3.13/dist-packages/` (`emul-removed.txt`).

## 10. What holds

- The 20 fixtures inject the whole boundary. On a host without `/proc` and pidfd they no longer reach a real reader (section 6). On Linux they behave as before (section 7.1).
- The tripwires and the bound work where `os` is imported, and no Go caller that can reach a hold accepts 97 or 98 (section 4).
- The counts in the writer's report (20 sites, 26 tests, 19 that reach the reader) are right.
- The document's paragraphs describe the rule correctly. The guard enforces a narrower rule (A11-1).

## 11. Required repair (narrow re-audit afterwards)

- R1: the guard refuses a probe stand-in whose script reaches `run_fixed` through `main` or `diagnostic_main` without the whole boundary (section 5.3), with G1 and G2 in the sample table.
- R2: the constant brings its own `os`, and the bounded test proves it in a script without `import os`.
- R3: the default bound and the guard's name list are pinned.
- New gate data, then the Mac run on the repaired head, using the guarded step 6.

I will re-audit only that delta, rerun Y3, Y9, G1 to G8 and the `os` demo, and repeat the emulated runs of section 6.

## 12. Sensitive material

No secret, token or personal data in this report or its evidence. The Mac brief's paths name the Mac's user folder as the brief already does. The chat-archive scanner found nothing (delivery message).

## 13. Confidence

- High: gate data, the 19-of-26 measurement, the bound's behaviour, and the guard gaps (shown with the guard's own functions).
- Medium: the Mac brief analysis. It rests on how Claude Code runs commands on the Mac and on macOS `ps` output when piped, both from documentation and the earlier Mac run, not from a run here.
- The emulation is of two facilities, not of macOS.
