# Evidence for 16-provenance-pr22-0a80ab7.md

Provenance-only re-check of ES PR #22 at `0a80ab7` (merge of `trunk_dev` `df46164` into the audited `da56d63`). Cloud container, Go 1.26.5, user `ci`. Files ending in `.txt` after another extension are scripts kept as text.

| Path | What it is |
|---|---|
| `provenance-r22e.sh.txt`, `provenance-r22e.log` | remote state, parents, clean trial merge, PR patch per path across the base move, range-diff, manifest v2 twice |
| `manifest-0a80ab7.json` | the manifest, SHA-256 `f225f340f30196eee8d36323d78351aec8e1de2207b8e2bda0afbad74c68e955` |
| `range-diff.txt` | `git range-diff bc9fe36..da56d63 df46164..0a80ab7` |
| `plans-md-check.txt` | where each side changes `PLANS.md`, and the byte-for-byte check |
| `runs.sh.txt`, `runs.summary`, `pr-tests-0a80ab7.log` | the PR's tests and the whole root package on `0a80ab7` and `df46164` |
| `verdicts-0a80ab7-vs-df46164.txt`, `compare-verdicts.py.txt`, `whole-*-verdict-lines.txt.gz` | the verdict comparison and the verdict lines of both runs |
| `SHA256SUMS.txt` | SHA-256 of every file here |
