# NARROW RE-AUDIT REPORT: Execution-Substrate PR #22, third repair (the guard refuses a faked probe before an entry point) and the merge of `trunk_dev`

**Verdict: ACCEPT `da56d63`, with no finding.** The three low findings of the audit of `1032c9c` are closed:

- **A11-1 is closed.** The guard now refuses a probe stand-in followed by `main()` or `diagnostic_main()` (G1, G2) unless every path from that entry point to the fixed command is cut. I built the collector's call graph myself, without the writer's test. The rule's three cuts are exactly the minimal cuts of that graph for each entry point. The new call-graph test catches every collector change I tried that opens a new path, apart from a joined name, which the writer lists as a limit.
- **A11-2 is closed.** The shared constant imports `os`, `signal` and `faulthandler` itself. All three of my `os` demos now end with status 98; on `1032c9c`, two of them ended with a `NameError`.
- **A11-3 is closed.** My mutants Y3 (default bound 0) and Y9 (flag out of the name list) are now caught.

The package scan judges 141 fixture scripts and refuses none. 46 replace the probe, and the 15 that also name an entry point each cut every path. Under my emulated host without `/proc` and pidfd, all 26 shared-boundary tests and the 6 local-boundary tests pass on the head, and the 26 also pass on `trunk_dev`. I also ran the whole root package on the head and on `trunk_dev`, emulated and plain. Each run finishes in 108 to 121 s, with no timeout, no bound reached, no tripwire and no leftover process. Every one of the 2,237 verdicts the two trees share is the same.

The merge of `trunk_dev` `bc9fe36` is clean: the head's tree is the clean trial merge, and the PR's own patch is the same text on both bases. The gate data reproduce: manifest `e0abc4cc…3b4f`, and CI is green on GitHub's merge commit, whose tree is the head's tree.

The hardened Mac brief can end only processes whose command line holds the literal temp path. Its guard lines refuse an empty or non-matching T before any command. Two small tightenings are optional (O13-4).

Written 2026-11-23 by the audit thread that wrote `04-`, `08-`, `08a-` and `11-…pr22.md`, at the coordinator's request of 06:20Z. Read-only. No subagents were used (section 2). Evidence: `13-reaudit3-pr22-evidence/`.

## 1. Audit target

| Field | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | [#22](https://github.com/evo-agi/Execution-Substrate/pull/22), draft |
| Head | `da56d63d2008930daf08d5ba8344e6af1e173072`: the merge of the repair commit `f62eeefd967d6e368ae26fd456c95f1d87a55f6d` (first parent) with `trunk_dev` `bc9fe3619823245faf550db4bf1bc3e782fbd5a5` (second parent). Tree `d4482ce5184b833a1eb4784fa290395ffed724e0` |
| Base | `trunk_dev` at `bc9fe36` (PR #20). The base of the audit of `1032c9c` was `110d377` |
| Topic branch | `claude/project-thread-k69qcw-collector-process-names` |
| Audited delta | `git diff 1032c9c f62eeef`, SHA-256 `5abf1560cfc43757e0bd4c2b48f6fffc00d475669c7219d1fc707840be9e60ce`, 3 files, +363/−61: `remote_alpha_es_service_tls_status_local_boundary_test.go`, `remote_alpha_es_service_tls_status_test.go`, `.docs/system_overview/capability_probing.md`. Plus the merge `da56d63` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2…a1ca`, verified |
| Canonical manifest | SHA-256 `e0abc4cce9feaa0a9e52636e7c5c384fc74cde33602f715861fc7d400a4c3b4f`, 8 paths, textual diff `741e6c52a4e3134571969154093e479417334aab1ceabf28973811285da56791`, upstream `origin/trunk_dev` at `bc9fe36` |
| Writer report | `12-repair3-pr22.md`, SHA-256 `0b7350f658d8e254acfc5decef76ad3f6b0e0ae6e78ae57af723160820ea1494`, verified. `12-evidence/SHA256SUMS.txt` (SHA-256 `87e1c9af…af32`): 39 of 39 entries match |
| CI | run [45119601098](https://github.com/evo-agi/Execution-Substrate/actions/runs/45119601098), job 137510097240 "build, vet and test", success, 05:43:59Z to 05:56:32Z |

## 2. Audit posture

- Read-only toward the repository and GitHub. Local exports made with `git archive`: `hd` (`da56d63`), `b20` (`bc9fe36`), `f62` (`f62eeef`). There is also a copy `hdg` of `hd` with two audit-only test files that call the guard's own functions, and one copy per mutant. The audit clone was used only for the manifest, the diffs and `git` queries.
- Go tests ran as the unprivileged user `ci`, with an emptied environment, Go 1.26.5, Python 3.13.18, kernel 6.18.44 and 4 CPUs.
- **Emulated host.** This is the same audit-only `audit_no_proc_pidfd.py` as in the audit of `1032c9c` (SHA-256 `e7ed4d3f…39e1`, in the evidence). It is loaded by a `.pth` file in the system `dist-packages` directory and is inert unless `AUDIT_EMULATE_NO_PROC_PIDFD=1` is set. When set, it denies every `/proc` path and deletes `os.pidfd_open`, `os.P_PIDFD` and `signal.pidfd_send_signal`. I installed it for the runs of section 7 and removed it afterwards (section 12). It is not a run on macOS.
- **No subagents.** I covered the perspectives myself: gate data and the merge (section 3), the rule against the call graph (section 4), the constant (section 5), pins and mutants (section 6), reach and the whole package (section 7), and the Mac brief (section 8).

## 3. Provenance and gate data for `da56d63`

Script `provenance/provenance-r22d.sh.txt`, log `provenance/provenance-r22d.log` (06:21Z).

| Check | Result |
|---|---|
| Recipe bytes | OK |
| Remote state | topic `da56d63`, `trunk_dev` `bc9fe36`; `refs/pull/22/head` is `da56d63` |
| Shape | `da56d63` has two parents: `f62eeef` and `bc9fe36`. `f62eeef` has one parent, `1032c9c`. The only new `trunk_dev` commit since `110d377` is `bc9fe36` (PR #20) |
| Repair commit | diff SHA-256 `5abf1560…60ce`, as reported, 3 files |
| Merge | `git merge-tree --write-tree f62eeef bc9fe36` gives `d4482ce5…`, the head's tree, so the merge is clean and adds nothing of its own |
| PR patch across the move | `git diff 110d377 f62eeef` and `git diff bc9fe36 da56d63`, both without `@@` and `index` lines, have the same SHA-256 `69644e8f…9500`, over the same 8 paths. Of the 19 paths that PR #20 changed, 17 keep `trunk_dev`'s blob at the head. The other two are `PLANS.md` and `capability_probing.md`, which both sides change, and which the equal patches above cover |
| Audited bytes | the collector is blob `16218b6c` (SHA-256 `372161f1…b4ff`) at `39a016c`, `1032c9c`, `f62eeef` and `da56d63`. The process-identity test and the two Remote Alpha documents also keep their blobs |
| Range-diff | `git range-diff 110d377..1032c9c bc9fe36..da56d63`: `64a0e0c =`, `39a016c =`, `1032c9c =`, `f62eeef` new |
| Manifest | tip checked out, `git reset --mixed bc9fe36`, upstream `origin/trunk_dev`, two runs byte-identical: `e0abc4cc…3b4f`, 8 paths, textual diff `741e6c52…6791`. It equals the writer's `gate/manifest.json`. Against the manifest of `1032c9c`: the collector, the process-identity test and both Remote Alpha documents are identical. The two test files, `capability_probing.md` and `PLANS.md` differ. At the top level only `head` (now `bc9fe36`) and `textual_diff_sha256` differ |
| CI | success on GitHub's merge `8c581eb` of `da56d63` into `bc9fe36`. I fetched `refs/pull/22/merge`: it is still `8c581eb`, and its tree is `d4482ce5…`, the head's tree. The writer's copy of the job log (SHA-256 `3d3b1222…aca5`) ends with the same lines that GitHub served me for the job's last 60 lines. It shows: root package `ok` in 105.6 s; "test gate passed: 41 packages, 3 of them with skipped entries (15 entries); 41 tests skipped themselves, all of them listed"; the gate self-check ran 121 tests; and the TLS status `FAIL` lines come only after the gate line. GitHub's full log archive is not reachable from this container (its download host is refused by the proxy), so the key lines come from that matched copy |

This is the gate data for `da56d63`. If `trunk_dev` moves before the merge, a new manifest and a provenance re-check are needed.

## 4. A11-1: the rule for a probe stand-in before an entry point

### 4.1 The rule against the collector's call graph

I built the collector's call graph myself (`callgraph/callgraph.py.txt`, output `callgraph-hd.txt`). For each top-level definition it records which other top-level names the definition refers to, including inside nested functions, lambdas and class bodies. The result:

- From `main` there are exactly 4 paths to `run_fixed`: through `collect`, then `cert_role` (directly or through `cert_metadata`), `key_pair` or `verify_chain`. From `diagnostic_main` there are the same 4 paths, through `diagnose_first_rejection`.
- The minimal cuts of size up to 3 are, for `main`: `collect`; `run_fixed`; and {`cert_role`, `key_pair`, `verify_chain`}. For `diagnostic_main` they are: `diagnose_first_rejection`; `run_fixed`; and the same three checks. These are exactly the three cuts of the writer's rule. A `collect` stand-in correctly does not cut `diagnostic_main`.
- The cleanup (`own_child_until_proved`, `terminate_child`, `prove_group_absent`, `signal_same_group_members`) is reachable only through `run_fixed`. The scan and the identity reader are also reached by the probe through its backend, which does not matter once the probe is replaced.
- The only module-level reference is `main`, in `if __name__ == "__main__":`. There are no attribute references to these names. The collector's dynamic lookups are `getattr` on `os`, `signal`, the child and the backend, and `globals().get(...)` of the bootstrap flags in the two entry points. None of them names a function. The flag is set to `True` only in `main` (line 2461) and `diagnostic_main` (line 2578).

This matches the `want` map of `TestRemoteAlphaESServiceTLSStatusLocalBoundaryKnowsTheCallGraph` entry for entry. That test parses the collector with `ast` and does not import it.

### 4.2 The package scan

The writer's own guard functions ran over every extracted script (audit-only `zz_audit_dump_scripts_test.go.txt`; dump `guard/scripts-dump-hd-boundary.json.gz`, which holds only the scripts that the guard judges or that replace the probe). Audit files left out:

| Count | Value |
|---|---|
| Scripts extracted | 25,467 (25,010 resolved, 457 unresolved; none of the unresolved holds a boundary name) |
| Judged by the guard | 141, refused 0 |
| Replace the probe or its backend | 46: 29 with the whole boundary, 17 without |
| Of the 17, naming `main` or `diagnostic_main` | 15, each with every path cut: 4 by `run_fixed`; 8 by `collect`, where the two P0t scripts, which run `diagnostic_main`, also replace `diagnose_first_rejection`; and 3 by the three checks. The other 2 run no entry point, and their flag stays false |
| Hold the constant's import line | 24 |

These are the writer's numbers. Two of the 15 deserve a look, because a stand-in there hands back to a saved real function:

- `remote_alpha_es_service_tls_status_test.go:2413` replaces `collect` with `track_collect`, which calls the real `collect`. That path is still cut, because the script also replaces `cert_role`, `key_pair` and `verify_chain` before it runs `main`, and the guard counts that cut too. If someone took the three check stand-ins out of this script, the guard would still accept it: the stated limit "whatever is assigned counts as a stand-in" (O13-3).
- `remote_alpha_es_service_tls_status_test.go:3147` saves `original_run_fixed` and calls it once, before any probe stand-in and with the flag false. There it is refused, which is what the script asserts. The `run_fixed` stand-in used under `main` does not call the original.

### 4.3 Shapes

Audit-only `zz_audit_guard_samples_test.go.txt`, log `guard/guard-samples-hd.log`. Each shape is judged exactly as the package scan judges a script.

| Shape | Refused |
|---|---|
| G1 probe stand-in, then `module.main([...])` | yes (was no) |
| G2 probe stand-in, then `m.diagnostic_main()` | yes (was no) |
| G3 scan and signal stand-ins, identity restored to the saved original | no: stated limit |
| G4 flag with `setattr` and a literal name | yes (was no) |
| G5 scan with `setattr`, flag set by hand | yes |
| G6 flag through `vars(module)[...]` | yes |
| G7 the three names assigned on an unrelated object | no: stated limit |
| G8 the shared constant, then the real identity reader put back | no: stated limit |
| G9 `module.ProcessCapabilityBackend.__init__=…`, then `main` | no |
| G10 probe stand-in, then `module.__dict__.get('main')(...)` | no |
| G11 probe stand-in, flag via `vars(module).update({'PROCESS_CAPABILITY_READY': True})` | no |
| G12 the same with a keyword (`update(PROCESS_CAPABILITY_READY=True)`) | yes |
| G13 probe stand-in, `module.PROCESS_CAPABILITY_READY=1`, then `run_fixed` | no |
| G14 `mock.patch('<name>.validate_process_capability')` with a string target, then `main` | no |
| G15 probe stand-in, `functools.partial(module.main, …)()` | yes |
| G16 probe stand-in, a `collect` stand-in that calls the saved `collect` | no: stated limit |
| G17 probe stand-in, a `run_fixed` stand-in that calls the saved `run_fixed` | no: stated limit |
| G18 probe stand-in, `'main'` only as text after a comma | yes (refuses too much, which is harmless) |
| G19 `setattr` with a computed name | not judged: stated limit |
| G20 probe stand-in, `diagnostic_main` over a `collect` stand-in only | yes |
| G21 probe stand-in, `main` over `cert_role`, `key_pair` and `cert_metadata` (with `verify_chain` real) | yes |
| G22 `mock.patch.object(module.ProcessCapabilityBackend, …)`, then `main` | no |

G1 and G2, the finding, are refused, and so are the cuts that are not cuts (G20, G21). Of the shapes that are still accepted, the writer's section 7 states G3, G7, G8, G16, G17 and G19. The others are G9, G10, G11, G13, G14 and G22. Each is outside the four ways of replacing that the writer names, or spells the flag or the name in a way the guard does not read. None occurs in the package. G13 is an assignment, but of `1` rather than `True`, and `run_fixed` accepts any truthy value (`if not PROCESS_CAPABILITY_READY`). It has been accepted since `1032c9c`, and I did not list it in the audit of `1032c9c`. G14 would work only where a fixture registers the module in `sys.modules`, which the P0t fixtures do. These belong in the list of limits (O13-2). The guard is hygiene, and the behaviour tests do not depend on it.

## 5. A11-2: the constant brings its own names

- Its first line is `import faulthandler as _faulthandler,os as _os,signal as _signal`, and every use inside it goes through those names (`git diff 1032c9c f62eeef`). No extracted script binds `_os`, `_signal` or `_faulthandler` anywhere else (`guard/private-names-hd.txt`).
- My three demos from the audit of `1032c9c` ran again, with only the constant swapped for the head's (`demo/`): `demo-hold-no-os` ends with 98 (was 1), `demo-hold-with-os` with 98 (was 98), and `demo-site578-stuck-validation` with 98 (was 1). None of the outputs contains `NameError`.
- The writer's three new "without os" cases pass. A loader that asserts `"os" not in globals()` guards them.
- Mutant Z1 survives: putting only the signal stand-in back on the fixture's `os` (`os.kill`) fails no test, because in the "without os" cases the child ends by itself and the signal stand-in is never called. The line is correct at the head. A revert of that one line would go unseen, and in a fixture without `os` it would raise a `NameError` inside the cleanup, not a hang (O13-1).

## 6. A11-3: pins and mutants

The writer's 68 mutants are in `12-evidence/mutants/`. I ran 20 of my own on `da56d63` against the six local-boundary tests (`mutants/mutants.py.txt`, `run-mutants.sh.txt`, `summary.txt`):

| Mutant | Result |
|---|---|
| M0 unmutated | passes |
| Y3 default bound 0 | caught (FailsBounded) |
| Y3c default bound 110 | survives: the pin is the range (100, 120], and a lower bound can only make a stuck fixture fail sooner |
| Y3d default bound 121 | caught |
| Y3e timer with a repeat interval | caught |
| Y9 `PROCESS_CAPABILITY_READY` out of the name list | caught (PinsItsNames, IsInjectedWhole) |
| Z1 signal stand-in on the fixture's `os` | survives (section 5, O13-1) |
| Z2 tripwire on the fixture's `os` | caught |
| Z3 overdue handler on the fixture's `os` | caught |
| Z4 import line without `os`, then `_os=os` | caught |
| Z5 entry regex without the word end | caught |
| Z6 entry regex without the `, "main"` form | caught |
| Z7 the backend class no probe stand-in | caught |
| Z8 two of the three checks count as a cut | caught |
| Z9 probe stand-in floor 0 | survives |
| Z10 probe stand-in floor not checked | survives |
| C10 collector: `diagnostic_main` also calls `collect` | caught (KnowsTheCallGraph) |
| C11 collector: `main` calls the hold directly | caught |
| C12 collector: `read_config` runs `run_fixed` | caught |
| C13 collector: `globals()["run_" + "fixed"]` in `read_config` | survives: the writer's stated limit (a name joined from parts) |
| C14 collector: the flag set to `1` in `read_config` | caught |

Z9 and Z10 weaken the new floor itself. A floor can only fail when the guard goes blind, which the unmutated tree does not do, so no mutant of the floor alone can be caught. A guard that went blind to probe stand-ins would still be caught by the sample table. Y3 and Y9, the two mutants of A11-3, are caught.

## 7. Reach and the whole package, emulated and plain

`emul-runs-d.sh.txt`, summaries in `emul/`.

- **Each test alone, emulated:** on `da56d63`, the 26 tests that run a shared-boundary fixture and the 6 local-boundary tests pass, 32 of 32, with no leftover fixture (slowest 8.1 s). On `trunk_dev` `bc9fe36` the 26 pass. The emulation was active: the hit logs record 146 and 137 Python starts under it. The 19 of 26 that stop on `7806170` were measured in the audit of `1032c9c`. The fixtures' boundary has not changed since, apart from the import line.
- **The whole root package, once per tree and mode** (`emul/phaseB.summary`, `emul/verdicts.txt`):

| Run | Time | Timeout | Bound reached | Tripwire | Leftover processes |
|---|---|---|---|---|---|
| `da56d63`, emulated | 108 s | 0 | 0 | 0 | 0 |
| `bc9fe36`, emulated | 121 s | 0 | 0 | 0 | 0 |
| `da56d63`, plain | 113 s | 0 | 0 | 0 | 0 |
| `bc9fe36`, plain | 120 s | 0 | 0 | 0 | 0 |

  - The head against `trunk_dev`: 2,237 shared verdicts, emulated and plain, and none differs. The head has 18 more, its new tests and subtests. Plain, all 18 pass. Emulated, 15 pass and the 3 live process-identity tests skip themselves.
  - The head emulated against the head plain: only those 3 live tests differ.
  - All four runs end with exit 1 because of the same 14 top-level tests. That set is identical in all four runs and equal to the set in my plain run of `1032c9c` in the audit of `1032c9c`. The writer's 8 environment-only failures are among them. The other 6 include `TestTrackedGeneratedArtifactHygiene` and the two `ByteStable…Matrix` tests. Inference: they fail because my exports are `git archive` trees without `.git`, or because of this container's setup. They fail the same way on `trunk_dev`. Against my plain run of `1032c9c`, the head plain shares 2,247 verdicts and none differs.

## 8. The Mac brief (`12-evidence/mac-instructions-5.txt`)

**It cannot end anything but this run's own processes, and it cannot remove anything but T.**

- **The guard lines.** Every command of steps 2 to 9 begins with `T='<literal>'`, a `case` that accepts only `/Users/ds/Repositories/Playground/es-mac-run.` followed by six characters, and `test -d "$T"`. An empty T, a lost variable, a different folder or a missing folder stops the command before it does anything. The removal in step 9 runs only after those lines. `rm` refuses `.` and `..` as the last component, so a T that ends in `/.` or `/..` cannot remove Playground either.
- **Step 6.** The listing `ps -axo … | grep -F -- "$T/"` shows only processes whose command line holds `T/`. Piped `ps` on macOS prints whole command lines; it truncates only on a terminal. The kill line checks one listed number again and ends it only if its command line still holds `T/`. It runs without sudo, so it can reach only David's own processes. The window between that check and the kill is a PID reuse in microseconds, which I rate negligible. The second listing (`python3|openssl`) only reports and ends nothing. It covers the fixture children that live in the test's own temporary folder outside T, which the first listing cannot see. That was my point from the audit of `1032c9c`.
- **Other steps** write only inside T (the clone, `GOCACHE`) and the test's own temporary folders, which Go removes. Nothing is downloaded (`GOPROXY=off`, `GOFLAGS=-mod=readonly`, `GOTOOLCHAIN=go1.26.5`). The existing clone is used only for `remote get-url`.
- **The hashes in the brief are right:** head `da56d63`, tree `d4482ce5`, `trunk_dev` `bc9fe36`. `-run '^TestRemoteAlphaESServiceTLSStatusLocal'` selects exactly the six tests named in step 4.
- **Optional tightening (O13-4).** In a `case` pattern, `?` also matches `/` and `.`. Six `[A-Za-z0-9]` classes would match only what macOS `mktemp` produces, letters and digits. Step 1's own commands after `mktemp` (the clone, `go version`) carry no guard lines. With an empty T there, the clone target is `/clone`, which fails harmlessly on macOS's read-only system volume. Neither is needed for safety.

## 9. Findings

None.

### Observations (no action required for the merge)

- **O13-1.** The signal stand-in's `_os.kill` is not exercised by a fixture without `os` (mutant Z1). A "without os" case whose fixed child does not end by itself would pin it.
- **O13-2.** Add to the guard's stated limits: the flag set to a truthy value other than `True` (G13, which has been accepted since `1032c9c`); the flag set through a dict literal (G11); `mock.patch` with a dotted string target (G14); an entry point taken by a call with its name as the first argument (G10); and attributes of the backend class (G9, G22). Alternatively, the ready rule can match any value that is not `False`.
- **O13-3.** `remote_alpha_es_service_tls_status_test.go:2413`'s `collect` stand-in hands back to the real `collect`. The path is cut by the three check stand-ins, not by `collect`.
- **O13-4.** The Mac brief's two optional tightenings (section 8).
- **O13-5.** All six commits of the PR carry a model name in a co-author trailer. GitHub's default squash message copies those lines. The squash commit's message has to be written without them.

## 10. What holds

- The repair is limited to tests and one document. The collector, the process-identity test and the two Remote Alpha documents are byte-identical to the audited `39a016c`.
- A11-1, A11-2 and A11-3 are closed as described in the audit of `1032c9c`. The rule matches an independently built call graph. The call-graph test catches the collector changes that would open a path. The constant needs nothing from the fixture.
- The merge is clean and changes nothing of the PR's patch.
- The gate data for `da56d63` reproduce, and CI is green on the head's tree.
- The emulated reach holds on the new head and on the new base. The whole package gives the same verdicts on the head as on `trunk_dev`, emulated and plain, with no hang and no leftover process.

## 11. Next

1. The Mac run of `12-evidence/mac-instructions-5.txt` on `da56d63`, after David's go-ahead.
2. The squash merge by the writer thread under the merge rule for test- and script-only PRs, with a message that has no model name (O13-5), once the Mac run reports nothing unexpected.
3. If `trunk_dev` moves before the merge: a branch update, a new manifest and a provenance re-check. The verdict holds for `da56d63` on `bc9fe36`.

## 12. Sensitive material

No secrets, tokens or personal data are in this report or the evidence. The emulation files were removed from `dist-packages` after the runs (`emul/emul-removed.txt`). The leak scan (`ge_chat_archive.py scan` with the known private numbers) of the report and every evidence file, including the decompressed `.gz` files: 0 findings.

## 13. Confidence

High that the three findings are closed: each has a test that fails on `1032c9c`'s code or a mutant that is now caught, and the rule matches a call graph I built without the writer's test. High for the gate data. Medium-high for the guard as a whole, because a text guard has the limits in section 4.3. The behaviour tests and the bound do not depend on it.
