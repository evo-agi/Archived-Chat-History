# Evidence for 08-reaudit-pr22.md (ES draft PR #22, repair head 39a016c)

Everything here was produced on the audit's cloud container (kernel 6.18.44, 4 CPUs, Go 1.26.5, Python 3.13.18). Scripts are stored as `.txt` so that they are read, not run, from here.

Scratch trees (never pushed): `h22r` is a `git archive` export of `39a016c`; `h22` one of `64a0e0c`; `h22rm` a copy of `h22r` for mutants; `h22red` is `h22` with the repair's new test file; `combo` is `h22r` with PR #21's test file from `50bb328`; `combo-m05` is `combo` with M05 applied (`combo/combo-m05-collector.diff`). `tests/trees-and-binaries.sha256` lists the hashes.

## Provenance (`provenance/`)

- `scripts/provenance-r22.sh.txt`, `provenance-open.log` (02:20Z), `provenance-close.log` (02:49Z, ends with `git ls-remote`).
- `manifest-{open,close}-{1,2}.json` and `.stdout.txt`: all four byte-identical, SHA-256 `1a8f223b…df51`.

## Root stress probes (`stress/`)

- `scripts/stress-r22.sh.txt` ran, as root, the first audit's probes unchanged: `esrch_collector.py`, `prove_e2e.py`, `attack22.py`, `pidreuse.py` and the helper binaries. They are byte-identical to the `.txt` copies in `04-audit-pr22-evidence/`; `stress.log` begins with the SHA-256 of every probe, binary and collector used.
- `esrch-c64-remount.json`, `prove-c64-remount.json`: the control on `64a0e0c`.
- `esrch-r22-{remount,drop,warm}.json`, `prove-r22-{remount,drop}.json`: the repair.
- `esrch-r22oldk-remount.json`, `prove-r22oldk-remount.json`: the repair with the audit-only older-kernel emulation (`scripts/emul-collector.diff`: every ESRCH and ENOENT from `pidfd_open` becomes EINVAL).
- `attack-r22.json` and `.log`, `pidreuse-r22.json` and `.log`.

## pidfd_open failures (`fallback/`)

- `scripts/fallback22.py.txt`, `fallback-h22r.json` and `.log`: the real collector against real processes, with `pidfd_open` missing, failing with ENOSYS, EPERM, EACCES or EINVAL for every call, or answering like an older kernel. An earlier run of the same probe without the "EINVAL for every call" case gave the same results for the other cases; its files were overwritten by this run. The attack harness ran beside this run, which is why some scans in the refused cases are unproved (section 6.1 of the report).

## Tests (`tests/`)

- `newtests-h22red.log`: the repair's tests against the `64a0e0c` collector, 43 failing cases. `newtests-h22r.log`: the same on the repair, all pass.
- `reps-r22-{idle,cpu8}-n30.summary.txt` and `.log.gz` (`scripts/reps-r22.sh.txt`), `load-verification.log`, `leakcheck.log`.

## Mutants (`mutants/`)

- `scripts/mutants_r22.py.txt`: eight audit mutants, applied in place in `h22rm` and restored with a hash check.
- `mutants-r22.log` (final format, with failing case names); `mutants-r22-first-format.log` (the first run, same verdicts, without case names).
- `mutant-X08-all-tlsstatus.log` and `tlsstatus-control-h22rm.log.gz` (`scripts/x08wide.sh.txt`): X08 and the control against every `TestRemoteAlphaESServiceTLSStatus…` test.

## Both repairs together (`combo/`)

- `scripts/combo.sh.txt`; `combo-pr21-tests-n10.log`, `combo-pr22-tests-n5.log`, `combo-all-tlsstatus.log.gz`, `combo-m05-pr21-tests-n5.log`.

## Leak scan

The chat-archive scanner (`ge_chat_archive.py scan` with the known-numbers list) was run over the report and every file here. Its result is recorded in the delivery message. `SHA256SUMS.txt` covers every file except itself.
