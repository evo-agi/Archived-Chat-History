# MERGE GATE: Execution-Substrate PR #22, merged as 792f17c

**Outcome: merged. PR #22 was squash-merged into `trunk_dev` on 2026-11-23 at 14:53:22Z as `792f17c7c56ca4a9c00d34aeb59524d898aeb58c`. Its tree equals the tested head's tree, and every manifest path on `trunk_dev` has the head's bytes.**

Merged without David's review under the standing merge policy for test, document and script changes, at the coordinator's instruction of 14:41Z, once all of its conditions held.

## 1. Conditions at merge time

| Condition | State |
|---|---|
| Audit | re-audit of `da56d63` ACCEPT (`13-reaudit3-pr22.md`, sha256 `2a8b9096…286c`) |
| Head equals the checked bytes | PR head `8ce6b739fa5f097e39dd73bd93a9ccac6c6b8811`, the merge of the audited `da56d63` (through `0a80ab7`) with `trunk_dev` `200fd60`. The merge was pinned to this SHA |
| Provenance | re-check of `8ce6b73` PASS (`17-provenance-pr22-8ce6b73.md`). Manifest v2 `22b1b458c3d79b0c02e3e0696e04dbbe9bd0c250b2f0d414ff8af85d7a231e1c`, 8 paths, from fresh clones and the writer's checkout; `git range-diff` shows the four PR commits unchanged |
| Mac run | clean on `8ce6b73` (`18-mac-run-pr22-8ce6b73.md`): 472 pass, 0 fail, 3 designed skips; the three tests that newly reach the cleanup on macOS pass |
| CI | run [45192217961](https://github.com/evo-agi/Execution-Substrate/actions/runs/45192217961), "build, vet and test", success for `8ce6b73`. Its last step reported "all 16 listed tests still fail on this host, each in a run of its own and in the run of its package" |
| trunk_dev unmoved | `200fd6097b43981ffae86e69500d1ab41b49a94c` immediately before the merge (checked with `git ls-remote` twice, the second time just before the call) |

## 2. The merge

| Field | Value |
|---|---|
| Method | squash, as for PR #20, #21 and #23, pinned to the expected head SHA |
| Commit | `792f17c7c56ca4a9c00d34aeb59524d898aeb58c`, one parent `200fd60`, tree `02ab404b8adb3950c773dada961ed6888af1ce43` |
| Message | title "TLS status collector: parse the proc stat line as bytes and confirm absence with pidfd_open (#22)", a short summary, and the standard ES co-author trailers |
| PR body | updated before the merge: the evidence for `8ce6b73`, the audits, the Mac runs and the target identity (base `200fd60`, head `8ce6b73`, manifest `22b1b458…1e1c`). The PR was marked ready for review first |
| Head branch | `claude/project-thread-k69qcw-collector-process-names` was deleted by the repository's setting for merged branches |

## 3. Bytes on trunk_dev after the merge

`git diff 8ce6b73 792f17c` is empty, and the tree of `792f17c` is the tree of `8ce6b73`. Each manifest path, with its blob on both:

| Path | Blob |
|---|---|
| `.docs/system_overview/capability_probing.md` | `f62a4ddce69e44c7e88eb1fe86fcafb3e5e8ec44` |
| `.docs/system_overview/remote_alpha_access_contract.md` | `0b7d2e7175dff632e5eca7e721b3b0a15c4effb5` |
| `.docs/system_overview/remote_supported_host_alpha.md` | `cd70a436b5985017f2577b4baec9347c10cc6862` |
| `PLANS.md` | `1441875ee5911370a2ed42235ccb2f169413e90a` |
| `remote_alpha_es_service_tls_status_local_boundary_test.go` | `35149e76bd14d9012a32cfe938f4fb254f0af760` |
| `remote_alpha_es_service_tls_status_process_identity_test.go` | `1afde801de59d683c368e7a22499d95a7bcc25df` |
| `remote_alpha_es_service_tls_status_test.go` | `f019ae8aa2a67265eb919e715acfb3d863fb6442` |
| `scripts/internal/remote_alpha_es_tls_status.py` | `16218b6cbc846afec0e8e6b1ff1b9c11f490b3bd` |

## 4. After the merge

- Push CI on `trunk_dev` `792f17c`: run [45199055309](https://github.com/evo-agi/Execution-Substrate/actions/runs/45199055309), started 14:53Z. Its result is not in this report. Since its tree is the tree that run 45192217961 passed for, a different result would point at the runner, not at the bytes.
- The containment work continues in a new thread from branch `claude/project-thread-k69qcw-child-containment` (`06325a2`), `tls-status-child-containment/02-handoff.md` and its update `03-handoff-update.md`, which adds the second remote TLS status collector to the scope.
- Still open from this workstream, by design (see the PR's "Not done"): `pidfd_answers.py` on the Remote Alpha host in the same session as the containment PR's host run, and no run of the collector on that host yet.
