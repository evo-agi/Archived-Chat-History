# INVESTIGATION REPORT: Execution-Substrate, can the TLS status collector's cleanup hold block for good?

**Answer in short:**

1. **Not through the path of `01-implementation.md`, section 9, in any supported deployment.** A killed member of the process group that nobody reaps can hold the collector for good, and I reproduced that. It needs two things that no supported deployment has: a fixed command that leaves a descendant, and a first process that does not reap orphans. The collector runs only on the host itself, never in a container. So neither a reaping init in the container launch nor ES reaping as first process is needed for this.
2. **Yes, on the supported host, through a second path that I found while checking.** One unrelated process whose name has a non-ASCII byte makes every process scan of the collector fail. If it is there before the run, the collector refuses to start. If it starts during the run, the collector holds, with its lock, for as long as that process lives. Any local account can cause it. Measured, section 5.
3. **A smaller defect of the same reader:** an unrelated process that ends while the collector reads it makes the run end as incomplete. Measured, section 6.

Both defects are in one function, `read_proc_identity`. Section 8 proposes the proper fix. It is not a timeout, and it does not weaken any check.

This is a read-only investigation. I changed no file of the repository and wrote no product code. Written 2026-11-22 by the writer thread of PR #21, at the coordinator's request. No subagents were used.

## 1. Identity

| Field | Value |
|---|---|
| Objective | Find out whether the collector's cleanup hold can block for good in a supported deployment, and propose the proper fix if it can |
| Repository | `evo-agi/Execution-Substrate` |
| Commit read | `trunk_dev` at `f62d0245e95e2b411be16511fc1bf9e1da727ce5` |
| File in question | `scripts/internal/remote_alpha_es_tls_status.py`, blob `6d44f13113b94ae73e489712c37a7a9fccdbcf58`, 2,770 lines |
| Working tree | untouched; no branch, no commit, no push |
| Where the experiments ran | the cloud container of this thread, as root, Linux 6.18, Python 3.13.18, OpenSSL 3.0.13, in scratch folders outside the repository |

## 2. Where the collector runs

- **One caller.** Only `scripts/remote_alpha_operator.sh` uses the collector, in the routes `recovery-session es-service-tls-status` and `recovery-session es-governance-tls-status` (lines 298, 300 and 1896 to 2292). No bring-up script (`scripts/01_bringup.sh` to `06_start_nomad.sh`, `scripts/internal/bringup.sh`, `control_plane.sh`), no supported-local script and no workflow runs it.
- **On the host, as root, in the operator's SSH session.** The operator stages the file under `/tmp` on the SSH target and runs `sudo /usr/bin/python3 -I -B -c <bootstrap>` there (lines 2285 and 2288). The process chain is sshd, bash, sudo, the collector, and then `/usr/bin/openssl`.
- **The fixed command gets a session of its own.** `run_fixed` starts it with `start_new_session=True` (line 1079). It is the leader of a new process group, and anything it starts stays in that group unless it leaves on purpose.
- **Six fixed command forms, all `/usr/bin/openssl`:** four `x509` and `pkey` forms and one `verify` form (lines 1826, 1860, 1867, 1897, 1942, 1970), with `OPENSSL_CONF=/dev/null`.

## 3. What the hold waits for

After the output pipes are closed and the leader has ended, `terminate_child` (line 937) signals the group, and then loops with no end (line 995) until a scan of `/proc` shows the leader as the only process left in the group. `prove_group_absent` (line 922) loops the same way after the reap. A scan reads `/proc/<pid>/stat` of every process on the host through `read_proc_identity` (line 815).

So the hold lasts as long as one of these is true:

- **A.** A process of the group is still visible. A killed process that nobody has reaped is still visible.
- **B.** The scan itself fails every time.
- **C.** A member cannot be killed.

The hold keeps the status lock of the scope. The collector latches SIGHUP, SIGINT, SIGQUIT and SIGTERM (line 2381) and reads the latch before and after the cleanup, not inside it. So the hold does not react to Ctrl-C or to a closed SSH session. Only SIGKILL ends the collector. A second run for the same scope then fails at once with `same_scope_lock_contended` (line 427).

The documents state this design: "persistent faults retain the invocation and lock with bounded backoff. No outer retry may return until group absence and exactly one direct-child reap are proved" (`.docs/system_overview/remote_supported_host_alpha.md`, lines 3532 to 3534, and the same rule in `remote_alpha_access_contract.md`, lines 191 to 196). I take that design as given. The question is whether something other than a live process of the group can keep the hold.

## 4. Path A: a killed member that nobody reaps

### What it needs

1. The fixed command leaves a descendant in its group. Then the descendant is an orphan or becomes one when the cleanup kills its parent.
2. The process that adopts orphans does not reap them. That is the first process of the PID namespace, or a subreaper above the collector.

### Measured

`hold_probe.py` loads the unchanged collector and calls its `run_fixed` once. The collector's own capability probe runs first. Only the path of the fixed command is set, in the rows marked "stand-in", to a script that exits at once and leaves one descendant, as the unchanged test fixture did. The private PID namespaces are made with `unshare --pid --fork --mount-proc`, which is what a container is to the kernel. I had no Docker daemon, so the two init processes are small stand-ins (`init_plain.py`, `init_reaper.py`).

| First process | Fixed command | Result | Log |
|---|---|---|---|
| A reaping init (what `docker run --init` gives) | stand-in with a descendant | returns in 0.10 s, 3 of 3 | `run-bcd.log`, C |
| This container's own (`process_api`, reaps on a one-second tick) | stand-in with a descendant | returns in 1.76 to 1.91 s, 3 of 3. The descendant is a zombie from 0.1 s until then | `run-a.log` |
| **A process that never reaps what it adopts** | stand-in with a descendant | **does not return.** 30 s in 2 of 2 runs, and 600 s in a third run that I then ended. The descendant is a zombie the whole time | `run-bcd.log`, B, and `run-long.log` |
| The collector's own process as first process | stand-in with a descendant | does not return in 30 s | `run-bcd.log`, D |
| A process that never reaps what it adopts | **the six real fixed command forms** | each returns in 0.005 to 0.038 s, in 2 of 2 runs | `run-f.log` |
| The collector's own process as first process | the six real fixed command forms | each returns in 0.005 to 0.024 s | `run-f.log` |

So condition 1 alone decides it for the real command: `openssl x509`, `pkey` and `verify` start no process, and the hold has nothing to wait for, whatever the first process is.

### Verdict for each deployment

| Deployment | Does the collector run there? | First process | Can path A hold for good? |
|---|---|---|---|
| Remote Alpha supported host | Yes, the two operator routes | systemd, by the documents: the services are systemd units (`remote_supported_host_alpha.md`, lines 4784, 4935, 5131). Not measured on the box | **No.** The real command leaves no descendant, and systemd reaps orphans at once. Both conditions fail |
| Bring-up containers (`scripts/02_start_ars.sh` to `05_start_es.sh`) | **No** | the service binary. `docker run` is used without `--init` (`scripts/05_start_es.sh`, line 62), and the generated image is `alpine:3.20` with no entry point | Does not apply |
| Workload containers (`es-runtime-support`) | **No** | Unknown, I did not read the job specification | Does not apply |
| Tests: GitHub runner, Mac, this cloud container | Only inside the tests | systemd, launchd, `process_api` | Tests only. PR #21 removes the dependency |

Two facts about the containers, because the coordinator asked about them:

- **The four services start no process.** In product Go code, `exec.Command` appears only in `es/runtimehelper/supervisor.go` (lines 67 and 85). ARS, EGS, AGS and ES, as first process of a bring-up container, have no children and nothing to reap. A reaping init there would change nothing for this question.
- **The workload supervisor has no hold of this kind.** It waits for its two direct children only (`helperCmd.Wait`, `workloadCmd.Wait`), with the workload's own time limit. It reads no process group.

The two other operator scripts that end a process group (`scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive.py` and its remote part) do not scan `/proc`. I read only the matching lines of them, not the whole files.

## 5. Path B: an unrelated process with a non-ASCII name (reachable on the supported host)

### Mechanism

`read_proc_identity` decodes the whole line of `/proc/<pid>/stat` as strict ASCII (line 838) and turns a decoding error into `Incomplete("process_identity_unproved")`. The second field of that line is the name of the process. A process chooses that name itself: it is the first 15 bytes of its file name, or whatever it sets. `scan_group_members` (line 850) reads every process of the host and does not catch that error. So **one process anywhere on the host with one non-ASCII byte in its name makes every scan raise**, whatever group it is in.

### Measured

`foreign_probe.py` uses the unchanged collector, the real `/usr/bin/openssl`, and a reaping init, so that path A is out of the picture. The unrelated process is a copy of `/bin/sleep` under a name with two accented letters. It runs in a session of its own and is no relative of the fixed command (`run-e.log`).

| The unrelated process | Result |
|---|---|
| None (control) | capability probe passes, `run_fixed` returns in 0.01 s |
| Runs before the collector starts | the capability probe raises `process_capability_unavailable`. On the host the collector would read no input, start no OpenSSL and publish nothing |
| Starts after the capability probe, ended by me after 8 s | `run_fixed` holds for 8.0 s, returns 0.04 s after that process ends, and raises `child_resource_unproved` |
| The same, ended after 20 s | holds for 20.0 s, then the same |

The hold lasts exactly as long as the unrelated process lives. If it never ends, the hold never ends.

### What it means on the host

- **Who can cause it:** any account that can start a process on the host. No privilege is needed. It can also happen by accident, with any program whose file name has an accented letter.
- **Before a run:** the route fails closed each time, with no hint of the cause beyond `process_capability_unavailable`.
- **During a run:** the collector holds its scope lock and does not react to Ctrl-C or a closed session (section 3). Someone with root has to send SIGKILL. No generation is published, and the earlier one stays in place. Nothing unsafe is published and no process is signalled wrongly: the failure is one of availability.
- **Likelihood by accident:** low on a server. **Inference:** I did not look at the process list of the box.
- **Not covered by a test:** the reader's error name `process_identity_unproved` appears in no test file, and the cleanup tests replace the reader with a stand-in (`remote_alpha_es_service_tls_status_test.go`, lines 2839 and 3265).

## 6. Path B, one-shot form: an unrelated process ends while it is read

`read_proc_identity` treats a process that is gone at `open` as absent (`FileNotFoundError`, line 823). But a process can also end between the directory listing and the `open`, or between the `open` and the `read`, and then the kernel answers ESRCH. At `open` that becomes `Incomplete("process_identity_unproved")` (line 825). At `read` it leaves the function as a bare `ProcessLookupError` (line 828).

The cleanup catches both, tries again, and succeeds. But it has then marked the cleanup as uncertain, and `run_fixed` raises `child_resource_unproved` (line 1190). **So an unrelated process that ends at the wrong microsecond turns a good run into an incomplete one.** In the capability probe the same race gives `process_capability_unavailable`.

Measured with `churn_probe.py`, which calls the collector's own `scan_group_members` in a loop while other loops start `/bin/true` (`run-churn.log`):

| Processes started per second on the host | Scans | Scans that raised |
|---|---|---|
| 0 | 40,641 | 0 |
| about 890 | 61,005 | 68 (0.11 %) |
| about 1,960 | 58,404 | 129 (0.22 %) |
| about 1,810, with the cause recorded | 53,753 | 123: 100 `ProcessLookupError` at `read`, 23 ESRCH at `open` |

**Inference:** the rate grows with the number of processes that end per second, about 1.2 failed scans per million scans for each process per second. A run makes three scans for each OpenSSL command that ends by itself. For a run with 40 commands on a host where 20 processes end per second, that is about one incomplete run in 300. I did not measure the box, so take the last number as a rough guess. The operator's retry succeeds, so this is a nuisance, not a hold.

## 7. Path C: a member that cannot be killed

SIGKILL cannot be blocked, and the collector is root. What remains is a process stuck in the kernel, for example in input or output on a file system that does not answer. The fixed commands read and write only pipes of the collector and load their libraries from the local disk. I see no way to this on the supported host. The documents accept the hold for a member that truly stays alive, and I propose no change there.

## 8. Proposed fix

### For paths B and its one-shot form: read the process line as bytes, and count a vanished process as absent

One change in `read_proc_identity`, which is where both defects are:

1. **Do not decode the name.** Find the last `)` in the raw bytes, check that the line starts with `<pid> (`, and parse only the fields after the `)`. The kernel writes those as ASCII digits and letters. The group and the start time, which are all the collector uses, are read exactly as now. The name of a process then cannot matter, which is right, because the collector never uses it.
2. **Count ESRCH at `open` and at `read` as "this process is gone"** and return `None`, as `FileNotFoundError` at `open` already does. ESRCH from the kernel means the process no longer exists, so it is not a member of any group.

Why this is the proper fix and not a workaround:

- It is not a timeout and hides no hold. A live member of the group holds the cleanup exactly as before.
- It weakens no check. Every other malformed or oversized line stays an error. Identity is still the exact pair of group and start time, taken again through a pidfd before any signal.
- It fits AGENTS.md section 12: no branch on the operating system and no fallback.

What the change needs with it, by the repository's doc-first rule:

- The two document passages named in section 3, with one sentence each: the reader does not interpret the name field, and a process that vanishes during the read counts as absent.
- Tests that are red today: the real reader against a real process with a non-ASCII name, the capability probe and one full `run_fixed` with such a process alive, and a reader test for ESRCH at `read` and at `open`. `foreign_probe.py` and `churn_probe.py` show how.
- Mutants for the two new branches, so that the tests cannot pass with the fix removed.

Size: about ten lines in one function. The collector runs as root on the host, so I would treat it as product code for the audit even though it lives under `scripts/`. That call is the coordinator's.

### For path A: nothing is needed in a supported deployment

I do **not** propose a reaping init for the bring-up containers or reaping in ES for this question, because the collector does not run there and the services start no process.

If the owner wants the collector to be independent of the host's first process as a matter of principle, the proper design is that the collector reaps what it kills: it makes itself the subreaper of its fixed command (`PR_SET_CHILD_SUBREAPER`), proved by behaviour in the existing capability probe, and reaps adopted members of the reserved group by exact identity. That changes the documented rule "exactly one direct-child reap", so it is a design decision with its own document change, and it buys nothing on a systemd host. I would not do it now.

### What I rule out

- A time limit on the hold. It would release the lock while a process of the group may still be alive, which is what the design forbids.
- Letting a zombie count as absent in the collector. It would make path A go away, but a zombie still holds its process group id, and the design keeps the leader as a zombie on purpose to reserve that id. It is a weaker proof than the one the documents ask for.

## 9. Not checked, and Unknown

- **The Remote Alpha box itself.** I did not log in. That its first process is systemd comes from the documents. One read-only command there (`ps -p 1 -o comm=`) would confirm it, and a look at the process list would show whether any name has a non-ASCII byte. It needs a session on David's Mac, which I did not ask for.
- **OpenSSL on the box.** I ran OpenSSL 3.0.13 with the six command forms and a certificate made for the test. **Inference:** no OpenSSL version starts a process for these commands with `OPENSSL_CONF=/dev/null`.
- **Docker itself.** The containers of the experiment are PID namespaces made with `unshare`. That is the same kernel mechanism, but I ran no `docker run`.
- **The frozen-session case and other kernel states** beyond section 7: not examined.
- **The two other operator scripts** that end process groups: only their matching lines were read.

## 10. Other envelope fields

- **Files touched in the repository:** none. The main checkout was moved to a detached `trunk_dev` for reading.
- **Implementation decision:** none taken. Section 8 is a proposal.
- **Dependencies changed:** none.
- **Artifact hygiene:** all scripts, logs and temporary folders are outside the repository. The private PID namespaces ended with their first process.
- **Authority, security or protocol widening:** none. Path B is a local denial of the status route, not a disclosure and not a wrong signal.
- **Cross-repo impact:** none.
- **Sensitive material:** none read or written. The certificate and key of the experiment were made for it in a temporary folder. This report and its evidence were scanned with the project's leak scanner before delivery: 0 findings.

## 11. Confidence

- **Path A cannot hold in a supported deployment: 0.9.** The mechanism is measured from both sides. The first process of the box is taken from the documents.
- **Path B is real: 0.97.** Measured on the unchanged collector with the real OpenSSL. That it reaches the box depends only on a local process with such a name.
- **The one-shot form is real: 0.95.** Measured. Its rate on the box is a guess.
- **The proposed fix is sufficient for B: 0.85.** It is not written and not tested. An auditor should look for other ways to make a scan fail for good.

## 12. Delivery and effect status

- This file: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/02-cleanup-hold-investigation.md`. Its SHA-256 is in the reply that delivers it.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/02-evidence/`, with a `README.md` and a `SHA256SUMS.txt`.
- Effect status: `READ_ONLY` | `NO_BRANCH` | `NO_PRODUCT_CODE` | proposal awaits the coordinator's decision.
