# PROVENANCE RE-CHECK: Execution-Substrate PR #22 at `8ce6b73` (merge of `trunk_dev` `200fd60`, PR #23, into `0a80ab7`)

**Verdict: PASS. `8ce6b73` carries exactly the audited PR. The verdict of `13-reaudit3-pr22.md` (ACCEPT for `da56d63`) carries over to `8ce6b73` on `200fd60`.**

**PR #23's `TestMain`:**

- **On Linux, and so in CI, it changes nothing about which collector code paths the PR's tests reach.** I compared 498 fixture processes with and without it, and their reach was identical.
- **On a host whose temporary directory lies behind a symbolic link, as macOS's does, it does change reach.** Three tests (9 fixture processes) now reach `run_fixed` and the process cleanup. Before PR #23 the collector's symbolic-link checks refused them earlier.
- **Under my emulated host without `/proc` and pidfd, all three pass, with no bound, tripwire or leftover process.**
- The Mac run of `0a80ab7` (`15-mac-run-pr22.md`) ran without PR #23, so it could not exercise these paths. The planned Mac run of `8ce6b73` (`16-evidence/mac-instructions-8.txt`) will.

This check is provenance-only and was read-only, at the coordinator's request of 14:18Z. No subagents were used. Evidence: `17-provenance-pr22-8ce6b73-evidence/`.

## 1. Provenance

| Check | Result |
|---|---|
| Remote state (14:18Z) | topic and `refs/pull/22/head` are `8ce6b739fa5f097e39dd73bd93a9ccac6c6b8811`; `trunk_dev` is `200fd6097b43981ffae86e69500d1ab41b49a94c` |
| Shape | `8ce6b73` has two parents: `0a80ab7` (whose first parent is the audited `da56d63`) and `200fd60`. `df46164` and `bc9fe36` are ancestors of `200fd60`. Tree `02ab404b8adb3950c773dada961ed6888af1ce43` |
| Merge | `git merge-tree --write-tree` of `0a80ab7` with `200fd60`, and of `da56d63` with `200fd60`, both give `02ab404b…`, the tip's tree. The merges are clean and add nothing of their own |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before use |
| Manifest | tip checked out, `git reset --mixed 200fd60`, upstream `origin/trunk_dev`, two runs byte-identical: **`22b1b458c3d79b0c02e3e0696e04dbbe9bd0c250b2f0d414ff8af85d7a231e1c`**, 8 paths, textual diff `6ca99e64…8a9e`. It equals the writer's `22b1b458…1e1c`. Against the audited manifest `e0abc4cc…3b4f`: 6 entries are identical, and `capability_probing.md` and `PLANS.md` differ. Against the `0a80ab7` manifest `f225f340…e955`: 7 entries are identical, and only `capability_probing.md` differs. At the top level only `head` and `textual_diff_sha256` differ |
| Range-diff | `git range-diff bc9fe36..da56d63 200fd60..8ce6b73`: `64a0e0c =`, `39a016c =`, `1032c9c =`, `f62eeef =` |
| PR patch across the move | `git diff bc9fe36 da56d63` and `git diff 200fd60 8ce6b73`, both without `@@` and `index` lines, have the same SHA-256 `69644e8f…9500`, and so does each of the 8 paths alone. The collector is still blob `16218b6c` (SHA-256 `372161f1…b4ff`). Of the 42 paths that `trunk_dev` changed since `bc9fe36`, 40 keep `trunk_dev`'s blob at the tip. The other two are the documents below |
| `capability_probing.md` | PR #23 adds 28 lines after line 396: the `TestMain` and TMPDIR rule, under "Test Harness Use". The PR adds its 37 lines after line 431. Applying the audited PR's patch to `200fd60`'s text gives the tip's text byte for byte (`docs-check.txt`). The PR's text is unchanged |
| `PLANS.md` | PR #23 does not touch it. It is the same as at `0a80ab7`: `trunk_dev` changed one line near line 220, and the PR adds 21 lines near line 2307. It also checks byte for byte |
| Build and vet | export of `8ce6b73`, user `ci`, Go 1.26.5: `go build ./...` and `go vet ./...` pass, and `gofmt -l` on the three PR test files is clean |
| The PR's tests | 11 of 11 pass: 6 local-boundary, 4 process-identity, 1 unrelated-name (`runs/pr-tests-8ce6b73.log`) |
| Whole root package, plain | `8ce6b73` takes 113 s and `200fd60` 120 s, with no timeout, bound, tripwire or leftover process. They share 2,238 verdicts and none differs; the 18 that exist only on the PR all pass. Both fail the same 14 top-level environment-only tests as before. Against my `0a80ab7` run, all 2,256 verdicts are the same |
| CI | run 45192217961 on `8ce6b73`, job 137753439776 "build, vet and test", started 14:15:44Z, **still in progress at 14:40Z**. It is not part of this verdict, and the merge needs it green |

## 2. Does PR #23's `TestMain` change which PR #22 code paths the tests reach?

**Method.** I used an audit-only tracer (`trace/audit_trace_collector.py.txt`), loaded by a `.pth` file. When `AUDIT_TRACE_LOG` is set, it records for every Python process the first entry into 25 collector functions, through `sys.monitoring`. These include `run_fixed`, the probe, the cleanup functions, the readers and the entry points. Runs are compared by fixture process, keyed by its argv with the tree, the temporary directory and random name parts normalized (`trace/reach.py.txt`). "Link" means `TMPDIR` pointed through a symbolic link to a physical directory, as macOS's `/var/folders/…` is (`/var` -> `private/var`). "Emulated" means no `/proc` and no pidfd, as in my earlier audits. I ran the whole root package six times (`runs/runs-f.summary`):

| Run | Tree | TMPDIR | Emulated | Time | Timeout, bound, tripwire, leftovers |
|---|---|---|---|---|---|
| A | `0a80ab7` (no `TestMain`) | link | yes | 131 s | 0, 0, 0, 0 |
| B | `8ce6b73` (`TestMain`) | link | yes | 152 s | 0, 0, 0, 0 |
| C | `8ce6b73` | physical | yes | 151 s | 0, 0, 0, 0 |
| D | `0a80ab7` | physical | yes | 171 s | 0, 0, 0, 0 |
| E | `8ce6b73` | physical | no | 110 s | 0, 0, 0, 0 |
| F | `200fd60` | physical | no | 124 s | 0, 0, 0, 0 |

**Results** (`trace/reach.txt`):

- **Physical TMPDIR (Linux, CI), before and after (D against C):** none of 498 fixture processes differs in the collector functions it reaches, and all 2,256 verdicts are the same. `TestMain` changes nothing there, as `testtmpdir.Resolve` promises when the temporary directory is physical.
- **After PR #23, link against physical (B against C):** none of 498 differs, and all 2,256 verdicts are the same. On a symlinked temporary directory, `TestMain` gives exactly the physical behaviour.
- **Link, before and after (A against B): 9 fixture processes in 3 tests differ, and all 9 differ in the cleanup functions.** Only with `TestMain` do they reach `run_fixed`, `own_child_until_proved`, `terminate_child`, `reap_child` or `prove_group_absent`, and in one test `scan_group_members`:
  - `TestRemoteAlphaESServiceTLSStatusSingleSelectedTrustAnchorCardinality` (4 processes; it uses the shared boundary)
  - `TestRemoteAlphaESServiceTLSStatusMaterialByteBinding` (1 process; it uses the shared boundary)
  - `TestRemoteAlphaESServiceTLSStatusFailureWitnessFixedInputCloseout` (4 processes; a failure-witness fixture of its own)
  
  In verdicts, A against B: 76 verdicts change from FAIL to PASS, 54 subtests appear only in B, and none goes from PASS to FAIL. Before PR #23, a symlinked temporary directory made these tests fail at the collector's symbolic-link refusals, before any fixed child.
- **The three tests alone, emulated, link, without the tracer** (`runs/confirm.summary`): on `0a80ab7` all three fail fast, in 0.3 to 1.1 s. On `8ce6b73` all three pass, in 0.3 to 1.4 s, with no bound, tripwire or leftover process.

**Answer.** On Linux and in CI, PR #23 does not change which PR #22 paths the tests reach. On macOS it does: these three tests now reach the fixed child and its cleanup. That is the code PR #22 changes and the code that hung on the Mac before `1032c9c`. Two of the three run under the shared boundary, and under my emulation all three end in about a second. The emulation covers `/proc`, pidfd and the symlinked temporary directory, not macOS as a whole. So only a Mac run of `8ce6b73` shows these paths on real macOS. The Mac run of `0a80ab7` could not, because there these tests stopped at the symbolic-link refusal on the head and on `trunk_dev` alike. `16-evidence/mac-instructions-8.txt` names `8ce6b73` and `200fd60`, so the planned run covers them.

**A side effect of the tracer, not of the PR.** With `AUDIT_TRACE_LOG` set, 4 more top-level tests fail, and they fail equally on `8ce6b73` and on `trunk_dev` (runs E and F): `…FailureWitnessCollectorCloseout`, `…FailureWitnessFixedInputCloseout`, `…P0tGrammarDiagnosticNonpublishingMatrix` and `…P0tGrammarDiagnosticOwnershipComposition`. Inference: the tracer opens a file descriptor inside the fixtures, and these closeout tests check descriptors. Without the tracer, the plain runs have the usual 14 failures, and the confirmation runs pass all four. The reach comparisons above are unaffected, because every one of the six runs carried the tracer.

## 3. Housekeeping

The tracer and the emulation were installed in the system `dist-packages` directory for these runs only and removed at 14:40Z (`trace/hooks-installed.txt`, `trace/hooks-removed.txt`). Leak scan of this note and the evidence, including the decompressed `.gz` files: 0 findings. If `trunk_dev` moves again before the merge, run this check again.
