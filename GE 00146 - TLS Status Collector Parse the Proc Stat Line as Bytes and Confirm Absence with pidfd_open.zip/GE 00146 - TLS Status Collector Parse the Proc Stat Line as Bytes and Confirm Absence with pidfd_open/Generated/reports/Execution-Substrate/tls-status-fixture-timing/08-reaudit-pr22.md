# NARROW ADVERSARIAL RE-AUDIT REPORT: Execution-Substrate PR #22, repair of A4-1 (the collector calls a process absent only when `pidfd_open` confirms it)

**Verdict: ACCEPT.** The repair at `39a016c` closes A4-1 and P4-2 the way `04-audit-pr22.md` required. My own root probes, unchanged, still find the fault on the audited head `64a0e0c`: 187 live reads as absent, 27 group IDs of -1 and 4 scans that dropped the live process in 60 s, and the real `prove_group_absent` returned after 7.8 s while the member lived. On the repair they found 0 false absences in 9,111,942 reads and 0 missed scans in 185,957, and the absence proof held for 90 s with fresh proc instances and with dropped caches. The writer's tests are red on `64a0e0c` in exactly the 43 cases the writer names and green on the repair (300 of 300 repeats, idle and under load). Eight mutants of my own are all caught. There is no fallback to worry about on kernels without `pidfd_open`: on every refusal I could emulate (no attribute, ENOSYS, EPERM, EACCES, EINVAL for every call) the capability probe refuses before any spawn, and a read of an ended process becomes unproved, never absent. An emulation of older kernels' EINVAL answers reads correctly and gave 0 false absences. Both repairs together (PR 21's fixture on this collector) pass, and M05 is still caught there. No finding. Observations O8-1 to O8-5 need no action from this audit.

Written 2026-11-23 by the audit thread that wrote `04-audit-pr22.md`, as the narrow re-audit that report pre-committed. This adversarial audit stands in for the red-team of PR #22 (coordinator decision of 01:10Z). No subagents were used (section 2).

## 1. Audit target

| Field | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | [#22](https://github.com/evo-agi/Execution-Substrate/pull/22), draft, head `39a016cca06dfb10f8b4b64c9b614c8f20aaa1de`, parent `64a0e0c` (the audited head), fast-forward |
| Base | `trunk_dev` at `f62d0245e95e2b411be16511fc1bf9e1da727ce5` |
| Topic branch | `claude/project-thread-k69qcw-collector-process-names` |
| Tree | `84551691d0cfdb36d842cc7d790976ea7477bd4a` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before each run |
| Canonical manifest | SHA-256 `1a8f223b57155e707c271e36c54b7a06314e32ac9581bb3a6e002c752ae4df51`, 5 paths, upstream `origin/trunk_dev` |
| Textual diff | SHA-256 `3bd7b520565e5bdd9c9d29eb54518001928b325b71138cc26873056570c3e493` |
| Repair commit | 5 files, +458/−59: the collector, `PLANS.md`, the two Remote Alpha documents, the process identity test file. Whole range from the base: 5 files, +928/−10 |
| Collector | SHA-256 `372161f1…b4ff` (was `e41e8566…424c` at `64a0e0c`) |
| Repair report | `05-repair-pr22.md`, SHA-256 `cf733f4da139194c7f746196be114ce18340620acb5cda6b5ac9e3d830b33f48`, verified. `05-evidence/SHA256SUMS.txt` (SHA-256 `4c361874…fbf7`): 97 of 97 entries match |
| CI | run [45097957121](https://github.com/evo-agi/Execution-Substrate/actions/runs/45097957121), job 137441913098 "build, vet and test", success, on the merge `f91c203` of `39a016c` into `trunk_dev` at `f62d024` |

## 2. Audit posture

- Read-only toward the repository and GitHub. No edit, commit, push, comment, review or merge.
- Scratch exports outside the audited clone: the repair head (`/opt/audit/h22r`), the audited head `64a0e0c` (`/opt/audit/h22`), a copy of the repair for mutants (`h22rm`), the audited collector with the new test file (`h22red`), and both repairs together (`combo`, `combo-m05`). The audited clone was used only for the manifest, diffs and `git show`.
- Go tests ran as the unprivileged user `ci` (`run-as-ci.sh.txt`), emptied environment, Go 1.26.5, Python 3.13.18, 4 CPUs, kernel 6.18.44. The stress probes ran as root, as in the first audit, with private mount and PID namespaces where they need them.
- The stress probes and helper binaries are byte-identical to the ones in `04-audit-pr22-evidence/` (`esrch_collector.py` `9aa0282b…`, `prove_e2e.py` `71a69a32…`, `attack22.py` `4abed14b…`, `pidreuse.py` `fb7479b7…`; every SHA-256 is listed at the top of `stress.log`).
- **No subagents.** The audit protocol (section 13.2, step 3) asks for read-only audit subagents. I covered the perspectives myself: kernel behaviour and the absence rule (sections 4 and 5), fallback (section 6), tests and mutants (section 7), documents (section 8). Standing session rules limit subagents to when they are asked for.

## 3. Provenance reproduction

`provenance-r22.sh.txt` (section 5.3 of the provenance guide), opening 02:20Z and closing 02:49Z.

| Step | Result |
|---|---|
| Recipe bytes | `c08597e2…a1ca`, OK at opening and closing |
| Pushed tip equals reported tip | yes, `39a016c` (and still at 02:49:26Z, `git ls-remote`) |
| Base is an ancestor of the tip | yes; `trunk_dev` still `f62d024` |
| Tip tree | `84551691…` |
| Manifest, two runs at opening and two at closing | all four byte-identical, `1a8f223b…df51` |
| Writer's files | `05-evidence/provenance/manifest-head-f62d024-tip-39a016c.json` has the same SHA-256; `repair-64a0e0c-to-39a016c.diff` and `whole-range-f62d024-to-39a016c.diff` are byte-identical to `git diff` |
| Runner log | `05-evidence/runner/job-137441913098.log` has 1,149 lines (the last without a newline), equal to the job log's original length from the GitHub API; its tail matches. Root package `ok` in 122.9 s, gate line "test gate passed: 41 packages…". The base is an ancestor of the tip, so the merge tree is the tip tree |

**Result: provenance reproduced, no mismatch.**

## 4. The repair against R1 to R3 of `04-audit-pr22.md`

### 4.1 R1, the code

I read the whole delta of the collector. `read_proc_identity` now:

1. reads `/proc/<pid>/stat` once (`read_proc_stat_identity`). The four unclear answers (ENOENT or ESRCH at open, ESRCH at read, a negative group ID) return `None`, which the docstring says is never proof of absence. Every other error and every parse failure is unchanged: unproved at once, or raised as before;
2. after an unclear answer asks `process_absent(pid)`: `pidfd_open(pid, 0)`. ESRCH or EINVAL means absent; a descriptor means a process has the ID (the descriptor is closed, and a failing close marks the closeout unproved and raises); every other error is `process_identity_unproved`; no `os.pidfd_open` is `process_capability_unavailable`;
3. reads again while a process has the ID, at most `PROC_IDENTITY_READS = 4` times, then raises `process_identity_unproved`.

Checks beyond the writer's tests:

- **PID reuse inside the loop.** If the process ends and its number is reused between the read and `pidfd_open`, the confirmation finds the new process and the next read returns the new process's identity. Every caller compares the group ID (and, where it has one, the start time) with what it expects, so the new process is a member only if it really is in the group. The PID reuse probe agrees (section 5.4).
- **Callers.** No caller changed. `scan_group_members` lets `Incomplete` propagate; `prove_group_absent`, `resolved_with_leader_reserved` and the capability probe treat it as unproved; `signal_same_group_members` marks the member signal unproved. So an answer that stays unclear holds the cleanup and never drops a member.
- **Order.** The confirmation comes after the read and only after an unclear answer, so no successful read pays for an extra system call. Mutant X05 (confirmation first, then trust the read) is caught.

### 4.2 R2, the documents

The old sentence ("ENOENT or ESRCH … is absent … no longer exists") is gone from `PLANS.md`, `remote_supported_host_alpha.md` and `remote_alpha_access_contract.md`, and from the docstring. Each now says that the stat file never proves absence, names the three kernel answers for a live process during an exec from a thread other than the first, and states the `pidfd_open` rule with ESRCH and EINVAL, the bound of four reads and "unproved, never absent". `…DocumentsContract` pins the new sentences and refuses the old wording. The text matches the code. One gap in what the documents say, not in what they claim, is observation O8-1.

### 4.3 R3, the tests

- **Red on the audited collector, reproduced:** the final test file with the `64a0e0c` collector (`h22red`, collector `e41e8566…`, test file `1d6b21e3…`): `…OpaqueNameBytes`, `…LiveProcesses` and `…DocumentsContract` fail, with 43 failing cases, exactly the writer's count. `…ThreadExecStaysPresent` and `…UnrelatedProcessNameDoesNotHoldCleanup` pass there, as the writer says (`newtests-h22red.log`).
- **Green on the repair:** all five pass (`newtests-h22r.log`); 150 of 150 test runs idle (`-count=30`) and 150 of 150 beside 8 CPU burners (`reps-r22-*.summary.txt`; 9 `stress-ng` processes at start and stop, load average 5.4 at the stop), no process left behind.
- **The optional root-only live test was not added.** I accept the writer's reason (section 4.3 of the repair report): it would skip itself on the runner, and the gate would then need a list line for a test that never runs. The unprivileged live test cannot make lookups cold, so it passes on `64a0e0c` too. The proof for the cold case is the root probe of section 5, which I reran.

## 5. The stress probes, rerun as root

### 5.1 The real reader and scan against a live process in a thread exec storm (`esrch_collector.py`)

| Collector | `/proc` | Seconds | Reads | Read as absent | Group ID -1 returned | Unproved reads | Scans | Scans without the live process | Scans unproved |
|---|---|---|---|---|---|---|---|---|---|
| `64a0e0c` (control) | fresh instance per read | 60 | 564,383 | **187** | 27 | 0 | 11,518 | **4** | 2 |
| repair | fresh instance per read | 120 | 1,140,814 | **0** | 0 | 2 | 23,281 | **0** | 1 |
| repair | `drop_caches` per read | 120 | 5,397,599 | **0** | 0 | 0 | 110,155 | **0** | 0 |
| repair | warm | 30 | 2,573,529 | **0** | 0 | 0 | 52,521 | **0** | 0 |
| repair, older-kernel emulation (section 6.2) | fresh instance per read | 60 | 509,453 | **0** | 0 | 0 | 10,397 | **0** | 0 |

The control shows the probe still finds the fault in this container. The two unproved reads and the one unproved scan under fresh proc instances are the fail-closed side: the answer stayed unclear for four reads, so the scan is repeated. That is observation O8-1.

### 5.2 The real `prove_group_absent`, pause removed (`prove_e2e.py`)

| Collector | `/proc` | Result |
|---|---|---|
| `64a0e0c` (control) | fresh instances | **returned after 7.82 s while the member was alive** |
| repair | fresh instances | did not return in 90 s; the member was alive |
| repair | `drop_caches` | did not return in 90 s; the member was alive |
| repair, older-kernel emulation | fresh instances | did not return in 60 s; the member was alive |

### 5.3 The attack harness (`attack22.py`)

| Section | Result |
|---|---|
| S1 hostile names | ok: 776 names, 81 host processes |
| S2 forged members in a real `run_fixed` | ok: all four contained |
| S3 states and exec storms | ok: no bad read in 208,228 reads under an exec storm from the first thread and 257,081 under one from another thread (P4-2's `-1` value no longer appears), nor in the running, sleeping, stopped, traced, vfork-parent and first-thread-exited states |
| S4 staged kernel answers | ok |
| S5 churn, 20 s | ok: 15,579 scans, 0 bad |
| S7 fuzz, 200,000 lines against the old parser | 165 lines differ, every one a line with a negative group ID; 0 other differences, 0 wrong fields |

The harness prints S7 as "NOT OK" because any difference from the old parser counts. As the writer notes, this is by design: the negative group ID is the kernel's marker and is now an unclear answer. My sketch gave the same 165.

### 5.4 PID reuse (`pidreuse.py`, private PID namespace)

P1 (a stale descriptor after reuse answers ESRCH, the reader then sees the new process) and P2b (reuse between scan and pin, other group: not signalled) are ok. P3 behaves as in O4-2: the proof holds while a process that reuses the leader's number lives in a group with that number, and returns 3.02 s after it is reaped.

## 6. `pidfd_open` on kernels and sandboxes where it fails

### 6.1 No `pidfd_open`, or refused

There is no fallback path, by design, and that is the right choice. I ran the real collector against real processes, as is and with `pidfd_open` patched in six ways (`fallback22.py.txt`, `fallback-h22r.json`):

| Case | Capability probe | Read of a reaped child | Read of a reaped leader whose group lives | Live and zombie reads |
|---|---|---|---|---|
| as is | passes | absent | absent | value |
| `os.pidfd_open` missing | **refuses**, `process_capability_unavailable` | unproved (`process_capability_unavailable`) | unproved | value |
| ENOSYS (kernel before 5.3) | **refuses** | unproved (`process_identity_unproved`) | unproved | value |
| EPERM (seccomp) | **refuses** | unproved | unproved | value |
| EACCES | **refuses** | unproved | unproved | value |
| EINVAL for every call (a sandbox) | **refuses** | absent | absent | value |
| older-kernel answers (6.2) | passes | absent | absent | value |

The capability probe runs before any OpenSSL spawn and opens a pidfd on its own live child, so every host where `pidfd_open` does not work refuses the run as unavailable. That includes a sandbox that answers EINVAL to everything, the one case where the rule "EINVAL means absent" would otherwise reopen A4-1. If the probe were bypassed, a read of an ended process would be unproved, never absent: fail-closed. One side effect shows in the same run: with a churning host (the attack harness was running beside it), scans in the refused cases became unproved, because any process that exits mid-scan now needs the confirmation. That is the expected cost of the safe rule, and the probe stops such a host before it matters.

### 6.2 Kernels that answer EINVAL instead of ESRCH

I emulated the older answers by turning every ESRCH and ENOENT from `pidfd_open` into EINVAL (an over-approximation; `emul-collector.diff`). The capability probe passes, a reaped child and a reaped leader whose group lives read as absent, and under the exec storm the reader gave 0 false absences in 509,453 reads and the absence proof held for 60 s (sections 5.1, 5.2).

What the emulation cannot show is whether an older kernel ever fails `pidfd_open` for a live process during the exec. **Inference from the kernel source as I know it, not measured:** `pidfd_open` finds the ID's `struct pid` and checks that a thread-group leader is attached to it. During an exec from another thread, `de_thread` moves the leader's ID to the exec'ing thread with RCU-safe swaps and replaces under the tasklist lock, so the ID is never without a leader. I know of no kernel version where this differs, but I have not checked the 6.8 source. The measured basis is this kernel: 0 failures in 8,687,432 calls in the first audit. **Unknown:** the kernel of the Remote Alpha host (the writer could not measure it either). A one-time run of the writer's `pidfd_answers.py` on the host at the next box session would turn this into a measurement (O8-2).

## 7. Mutants

### 7.1 My own, against the writer's five tests (`mutants_r22.py.txt`, `mutants-r22.log`)

| Mutant | What it does | Result |
|---|---|---|
| X01 | group ID 0 is treated as unclear | caught, 23 cases in 4 tests. Kernel threads show group ID 0 in this VM's `/proc`, so every scan stays unproved |
| X02 | the scan skips a process whose identity stays unproved | caught, 9 cases |
| X03 | read bound 2 instead of 4 | caught (`reads_bounded`) |
| X04 | a confirmation that fails is taken as absent | caught, 5 cases |
| X05 | confirmation before the read, then the read is trusted | caught, 88 cases |
| X06 | `kill(pid, 0)` instead of `pidfd_open` | caught, 36 cases |
| X07 | a negative group ID is unproved at once, without confirmation | caught, 10 cases |
| X08 | the member signalling skips a member whose identity read raises, without marking it unproved | survives the five new tests; **caught** by the older `…FailureWitnessPendingMemberCloseout` (`mutant-X08-all-tlsstatus.log`) |

X08 changes a caller that this PR did not touch, but the repair makes that path more likely (an answer that stays unclear now raises), so I checked that some test pins it. One older test does. With X08, 28 entries fail, against the control's 3 tests that need another environment (`tlsstatus-control-h22rm.log`: 77 of 80 `TestRemoteAlphaESServiceTLSStatus…` tests pass, the 3 known ones fail).

### 7.2 The writer's 39

Not re-run. I read `05-evidence/mutants/mutants.log`: 39 of 39 caught, each by a behaviour case, after one test was tightened. X03 and X04 are close to the writer's R04/R05 and R10; X01, X02, X05, X06 and X08 are not in that list.

## 8. Both repairs together

PR #21 and PR #22 share no file. PR #21's fixture replaces `read_proc_identity`, the function this PR changes, so I checked the combination: the tree of `39a016c` with PR #21's test file from `50bb328` (`combo.sh.txt`):

| Run | Result |
|---|---|
| PR #21's three tests, `-count=10` | 160 of 160 pass |
| PR #22's five tests, `-count=5` | 25 of 25 pass |
| every `TestRemoteAlphaESServiceTLSStatus…` test | 77 of 80 pass; the same 3 that need another environment fail |
| PR #21's three tests with M05 applied to this collector, `-count=5` | M05 caught, 15 of 15 runs of `term`, `scan_plain_once`, `post_reap_scan_once`, labels `descendant_gone` and `no_return_while_member_visible` |

So the merge order does not matter for correctness. The PR merged second needs the usual branch update, new manifest and provenance re-check.

## 9. The writer's notes

- **"The unprivileged live test also passes on the audited head."** Confirmed (4.3). It guards the path; the root probe is the proof.
- **"S7 prints NOT OK for 165 lines."** Confirmed and by design (5.3).
- **"The base root-package run hit the PR 21 flake."** I did not re-run the base. The signature the writer reports (`term`, 2.15 s, `descendant_gone`, `returned`, `leader_reaped`) is the one I measured as PR #21's root cause (`02-audit.md` section 4), and that fixture replaces `read_proc_identity` with its own stand-in, so this PR cannot affect it. Consistent.

## 10. Findings

None.

### Observations (no action required by this audit)

- **O8-1. An unrelated process that calls exec from a thread can, rarely, leave a scan unproved.** Measured: 2 unproved reads in 1,140,814 and 1 unproved scan in 23,281 under fresh proc instances, none with dropped caches or warm. The result is fail-closed: a repeated hold round, or, if it hits the capability probe's scan, a run refused as unavailable. The documents' sentence "the name or the exit of an unrelated process neither fails the capability probe nor prolongs the unresolved-cleanup hold" stays true, because it speaks only of names and exits. The writer's section 3.5 states the exec case; the documents do not. Optional: one sentence in the three documents.
- **O8-2. The host's kernel.** EINVAL counts as absent on the strength of the kernel source for kernels before about 6.15 (inference, writer and me alike). Unknown: the Remote Alpha kernel. A one-time `pidfd_answers.py` run there at the next box session would measure it.
- **O8-3. P4-1** (a SIGTERM-ignoring fork relay can escape when PID 1 reaps at once) stays open, as the coordinator decided: its own PR, with containment by a control group investigated.
- **O8-4. Merge gate.** The branch is on `trunk_dev` (`f62d024`) today. If PR #21 merges first, this branch needs an update, a new manifest and a provenance re-check (section 8 shows the combination works).
- **O8-5. One log of mine has an earlier format.** `mutants-r22-first-format.log` is the first run of my mutants, before I added the failing case names. It has the same verdicts as `mutants-r22.log`.

## 11. Validation assessment

| Writer's claim | Re-checked here? | Result |
|---|---|---|
| 0 false absences under the auditor's probes; the control still finds the fault | yes, rerun as root | confirmed: 0 in 9,111,942 reads; control 187 |
| `prove_group_absent` holds while the member lives | yes | confirmed, 90 s twice; control returned after 7.82 s |
| Harness S1 to S5 ok, S7 165 negative lines only | yes | confirmed |
| PID reuse P1, P2b ok, P3 as O4-2 | yes | confirmed |
| 43 cases red on `64a0e0c`, all green on the repair | yes | confirmed exactly |
| 150 + 150 repeats pass | yes, my own | 150 of 150 idle, 150 of 150 with 8 CPU burners |
| 39 of 39 mutants caught | read only | plus my 8 of 8 |
| `pidfd_open` answers table | partly: reaped, reaped leader with a live group, live, zombie | consistent |
| Missing `pidfd_open` is `process_capability_unavailable` | yes | confirmed, and the capability probe refuses first |
| EINVAL on older kernels | emulated; source reasoning | consistent; not measured on such a kernel |
| 77 of 80 TLS status tests, 3 need another environment | yes | confirmed |
| Whole root package: 38 failures, all on the base too | not re-run | the runner passed the root package on the merge |
| Runner green | yes | log length and tail match the API, success |

Not run by me: macOS (the collector needs `pidfd_open`, which macOS lacks), a kernel older than 6.15, the Remote Alpha host, the whole root package.

## 12. Sensitive material

None read or written. I scanned this report and `08-reaudit-pr22-evidence/` with the project's leak scanner before delivery (result in the delivering reply).

## 13. Confidence

- **Provenance: 0.99.** Four identical manifests, writer's files byte-identical.
- **A4-1 and P4-2 closed on the measured kernel: 0.97.** The probe that found the fault still finds it on the old head and finds nothing on the repair, across three cache regimes, plus the end-to-end proof.
- **Fallback: 0.95.** Every refusal I could emulate fails closed at the capability probe; the older-kernel answer is emulated, not measured.
- **Behaviour on the host's kernel: 0.85.** Inference from the source; not measured there.
- **Tests: 0.93.** 43 red cases reproduced, 8 of 8 own mutants caught.

## 14. Effect status and delivery

- Effect status: `REPAIR_NOT_PERFORMED` | `COMMIT_NOT_PERFORMED` | `PUSH_NOT_PERFORMED` | `PR_NOT_COMMENTED` | `MERGE_NOT_PERFORMED`.
- This file: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/08-reaudit-pr22.md`, SHA-256 in the delivering reply.
- Evidence: `/mnt/project-files/reports/Execution-Substrate/tls-status-fixture-timing/08-reaudit-pr22-evidence/`, with `README.md` and `SHA256SUMS.txt`.

**Final verdict: ACCEPT** (no finding; merge gate per O8-4).
