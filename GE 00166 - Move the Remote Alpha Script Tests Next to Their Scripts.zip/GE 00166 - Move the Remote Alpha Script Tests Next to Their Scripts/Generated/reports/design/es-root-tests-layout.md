# Moving ES's root-level test files into `tests/`: proposal

> **Superseded layout (David, 2026-11-23 21:18Z to 21:24Z).** The `tests/` folder below was not adopted. Agreed instead: the 31 Remote Alpha script tests move into `scripts/`, next to the scripts they test; the docs tests stay at the root (`remote_alpha_access_contract_test.go` becomes `host_access_docs_contract_test.go`); `caller_authentication_contract_test.go` moves into `internal/callerauth`; the shared test helpers go into a new test-only package `internal/testutil`, and the scripts package's local helpers file is `scripts/helpers_test.go`. The path findings here (no chdir, resolve from the root, missed-path check) still apply. The implementation is ES branch `claude/project-thread-wkerpy`; its report sits in `reports/Execution-Substrate/root-tests-layout/`.

Status: PROPOSAL, read-only, no repo changes and no PR. Written 2026-11-23 21:00Z by the thread "Plan moving ES root test files", after David's 20:45Z message: "Let's not rename the dir then… But, yes, please clean up the test files."
Base: ES `origin/trunk_dev` 76c030f. Open PR heads are listed below as read at 20:50Z.
Evidence: `es-root-tests-layout-evidence/` next to this file.

## Short answer

- **David's question about Go convention.** Yes, Go keeps a package's `_test.go` files next to that package's code, in the same folder. ES already does this: 150 test files sit beside their packages (`es/app`, `es/admission`, …), and they stay where they are. The 39 files at the root are different. The root holds **no Go code at all**, and these files import only one repo package (`internal/testtmpdir`, for their `TestMain`). They test shell and Python scripts, docs text and repo-wide rules. So the convention doesn't put them at the root. They are there only because a test runs with its own folder as the working directory, and from the root, paths like `"PLANS.md"` and `"scripts/…"` just work.
- **Proposal:** move all 39 into one new folder, `tests/`, as one package. They lean on each other's helpers too much to split cheaply. Then make them find files from the repo root on purpose instead of by accident. Afterwards a plain `ls` of the root shows 15 entries instead of 53.
- **It works:** in a trial, moving the files plus three one-line helper edits left 2,241 of the 2,263 root tests (subtests included) with the same result as before. The remaining 22 fail loudly, each for a path it reads directly.
- **One trap found:** the obvious shortcut, switching the working directory back to the root when the test binary starts, makes `go test` reuse a cached PASS after a doc or script has changed. I reproduced this (`chdir-cache-probe.sh`). The proposal therefore turns paths into absolute ones instead.
- **Open PRs:** edits to moved files carry over cleanly in git. New root test files added by five open PRs (#29, #30, #31, #34, #35; 7 files) would stay at the root and fail loudly until moved, so each of those PRs needs a small fix when it next takes up `trunk_dev`. No PR has to land first for correctness.

## What the 39 files are

Repo-validated at 76c030f (`root-test-files-76c030f.tsv`, `helper-dependencies.txt`):

- 39 files, 45,702 lines, 479 top-level tests, all in package `executionsubstrate_test`. The root has 0 non-test `.go` files.
- **Docs contracts:** `docs_contract_test.go` (13,993 lines, 143 tests, the biggest by far), `codex_agent_configs_docs_contract_test.go`, `outside_observer_docs_contract_test.go`, `caller_authentication_docs_contract_test.go`.
- **Remote Alpha script tests:** 32 `remote_alpha_*_test.go` files. They run the scripts under `scripts/` against fakes. Six of them are 7-line stubs that check a retired route stays retired.
- **Repo-wide guards:** `artifact_hygiene_test.go`, `caller_authentication_contract_test.go` (parses every production Go file), and `testtmpdir_main_test.go` (the package's `TestMain`).
- **Tightly linked:** 36 of the 39 files call helpers defined in another of these files. 25 use `mustRead` from `docs_contract_test.go`, 21 use `executionSubstrateRepoRoot`, and the Remote Alpha files share fixtures with each other.

## Target layout

```
tests/                     one Go package, package name kept as executionsubstrate_test
  README.md                one paragraph: repository-level tests of scripts, docs and repo-wide
                           rules; Go package tests live next to their packages
  repo_root_test.go        new: repoRoot and repoPath (below)
  repo_paths_test.go       new: the guard (below)
  docs_contract_test.go    …and the other 38 files, moved unchanged apart from path fixes
```

Choices, and why:
- **One package, not several.** Splitting into `tests/docs`, `tests/remotealpha` and `tests/repo` would need a shared helper package and edits all through `docs_contract_test.go`, which itself mixes docs and Remote Alpha checks. That means a much bigger diff and more conflicts with open PRs, for no gain in tidiness.
- **`tests/` as the name.** It is the name a newcomer looks for, and the README line keeps anyone from thinking all tests live there. Inference: `go build ./...` and `go vet ./...` accept a folder that holds only test files. The root is already exactly that today, and the trial's `go vet ./tests/` passed.
- **Package name unchanged.** The package clause stays byte-identical, so git sees the moves as renames and open PRs' edits carry over.
- **Not inside `scripts/`.** That would put the Remote Alpha tests next to the scripts they test, but it would turn the operator front door into a Go package, and the docs tests and shared helpers don't belong there.

## How the tests find files after the move

This is the one real design point. `go test` runs a package with its own folder as the working directory, so after the move `"PLANS.md"` would point into `tests/`.

| Approach | Verdict |
|---|---|
| Switch the working directory to the root in `init()` | **Rejected.** `go test` doesn't see that switch and reuses a cached PASS after a doc or script changes (reproduced in `chdir-cache-probe.sh`). |
| Switch it in `TestMain` | **Not allowed.** The testtmpdir guard (`internal/testtmpdir/testtmpdir_test.go`) requires every `TestMain` to be exactly `os.Exit(testtmpdir.Main(m))`. It would also hit the same cache problem. |
| `t.Chdir` in every test | Works with the cache, but means 479 edits and rules out parallel tests. |
| **Resolve every repo path against the repo root** | **Recommended.** The cache tracks absolute paths correctly (checked in the same probe). |

What "resolve against the root" means in practice, measured in the trial:
1. New `repoRoot` (found from the source file's location and checked against `go.mod`) and `repoPath(rel)`.
2. `mustRead` resolves relative paths with `repoPath`. That covers all 684 `mustRead` calls without touching them.
3. `executionSubstrateRepoRoot` goes up one more folder; `remoteAlphaOperatorRepoRoot` returns `repoRoot` instead of the working directory. That covers 115 more lines.
4. The 22 tests that still fail read a path directly: `filepath.Glob("es/admission/*.go")`, `filepath.WalkDir(".")`, `os.ReadDir(".codex")`, `exec.Command("./scripts/…")`, the retired-route helper, the scan of `*_test.go` at the root, and one test that reads its own source file by path. Each gets `repoPath` (list in `test-compare-root-vs-moved.txt`).
5. **Checks that pass when a file is missing** would silently pass after the move: `codex_agent_configs_docs_contract_test.go:174,177` (`.codex/config.toml` and `.codex/hooks` must not exist), `docs_contract_test.go:3014` (a removed plan must stay removed) and `artifact_hygiene_test.go:30`. These must get `repoPath`, and the trial's pass count can't prove they did.
6. **Child processes:** 91 `exec.Command` calls, 47 of which set `Dir`. The rest inherit the working directory, which today is the root. To keep behaviour identical, they get `Dir = repoRoot`.

**Guard, so a missed path is caught by a machine and not by luck:** `tests/repo_paths_test.go` parses the package's files. It fails when a file-system or exec call (`os.ReadFile/Stat/Lstat/Open/ReadDir`, `filepath.Glob/Walk/WalkDir`, `exec.Command`) gets a relative repo path (a literal or constant starting with a top-level repo entry, such as `scripts/`, `.docs/`, `PLANS.md` or `es/`) that doesn't go through `repoPath`, and when an `exec.Command` of a repo script has no `Dir`. It also catches items 5 and 6 above, which no result comparison can.

Once the move lands, a test file added back at the root fails on its own: it can't see the helpers (compile error in `go vet ./...` and CI), and the testtmpdir guard refuses a test package without its `TestMain`.

## Other things the move touches

- `.github/ci/environment-only-tests.txt`: 11 entries name package `execution-substrate` and become `execution-substrate/tests`. The CI gate fails loudly if they aren't changed. The file isn't hash-pinned. PR #35 adds an entry too.
- `.docs/mvp.md:209`: the command `go test -run TestPrimaryMilestoneRealignmentPreservesESOwnership -count=1 .` "from the ES repo root" becomes `./tests/` (no test pins that sentence; checked).
- `.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md:1854` names `docs_contract_test.go` (a path update for clarity). `es/admission/internal/reliablesubmit/guardrails_test.go:750` matches it by base name only, so it keeps working.
- No other script, doc or runbook names a root test file (searched at 76c030f).

## Open PRs

Trial: the move plus the three helper edits, with each open PR head merged into it using git's default merge.

| PR | Root test files it touches | Result on the moved layout |
|---|---|---|
| #12 reliable submit (4416699) | edits 2 (`docs_contract_test.go`, `…local_boundary_test.go`), +1,074 lines | Edits carry over into `tests/`. Its `PLANS.md` conflict exists today without the move. |
| #29 artifact bytes (06e84e5) | adds `ars_blob_verification_docs_contract_test.go`, edits 1 | Clean, but the new file stays at the root, so it must be moved and its paths fixed |
| #30 TLS collector containment (eed4c9b) | adds 2, edits 6, +2,329 lines | Clean; 2 new files to move |
| #31 Nomad lock (7aaac66) | adds `remote_alpha_nomad_acl_test.go`, edits 1 | Clean; 1 new file to move |
| #33 Vault plan guard (04ea98e) | none | Clean |
| #34 SPIRE agent helper (0927911) | adds `remote_alpha_spire_agent_test.go` (1,693 lines) | Clean; 1 new file to move |
| #35 host firewall (0c95eb7) | adds 2, edits 1, +2,964 lines; adds a CI-list entry | Clean; 2 new files to move, plus its CI-list entry |
| #36 README rewrite, #37 runbook move | none | Clean |

Inference: once the guard and items 4 to 6 are done, a few more lines change in files #12, #29, #30 and #35 edit, so a line-level conflict or two is possible there. I only trial-merged the smaller version.

## Sequencing plan

Facts that drive it: ES requires a PR to be up to date with `trunk_dev` before it merges, and taking up `trunk_dev` already triggers a delta audit. So the extra cost of the move for an open PR is moving its new file(s), wrapping their paths and redoing one CI-list line, inside a step it has to do anyway. The root, meanwhile, keeps growing: five of the nine open PRs add root test files, and the planned work (PR 27 follow-up, Nomad lock part 2, workload identity) will likely add more (Guess, based on the pattern so far).

1. **No PR has to land first for correctness.** Every case either merges cleanly or fails loudly.
2. **To save rework, merge the move at a moment when no PR that adds root test files is in an active audit, red-team or box run.** The coordinator can see that from the threads. Taking up the move in the middle of one of those would change the bytes under review. If #29 is close to merging at that point, let it land first: it is the furthest along of the five and adds a root file.
3. **The move PR**, from one thread, in two commits so the audit is easy: (a) `git mv` of the 39 files only, so git shows 100% renames; (b) `repo_root_test.go`, path fixes 2 to 6, the guard, the `tests/README.md`, the CI-list entries and the two doc lines. It changes only tests, docs and CI config, so it merges after a fresh audit and the merge gate without David's review. No red-team is needed. The audit runs the full ES suite before and after (CI plus the cloud) and compares test by test. It also checks commit (a) is pure renames and that the guard trips on a planted relative path.
4. **PRs still open then** take it up at their next `trunk_dev` merge: `git mv` new root test files into `tests/`, run the guard, fix what it names, update any CI-list entry, then do a delta audit. Expected size: #29, #31 and #34 one file each, #30 and #35 two each.
5. Nothing on the Linux box or in Archived-Runbooks changes. No runbook names these files.

## Not verified

- The full fix (items 4 to 6 plus the guard) hasn't been written. The trial stopped at the three helper edits, so the 22 remaining tests and the silent cases are listed, not fixed.
- Around 260 root tests fail in this cloud container before and after (they need Nomad, Vault, SPIRE, root or the box), so the before/after comparison says nothing about them. CI and a box run would.
- GitHub's merge button may show rename cases differently from local git (not tested); the plan relies on threads merging locally.

## Evidence (`es-root-tests-layout-evidence/`)

- `root-test-files-76c030f.tsv`: each file with its lines and top-level test count.
- `helper-dependencies.txt`: which file uses which other file's helpers (parsed with go/ast).
- `trial-move-and-path-fix.patch`: the trial (39 pure renames plus `repo_root_test.go` and three helper edits).
- `test-compare-root-vs-moved.txt`: test-by-test comparison, root package at 76c030f vs `tests/` after the trial, same container, Go 1.26.5, unprivileged user.
- `chdir-cache-probe.sh`: reproduces the stale cached PASS that rules out switching the working directory in `init()`.
- `runtests2.sh.txt`, `cmp2.py.txt`: how the runs were made and compared.
