# Renaming `scripts/` to `.scripts/`: viability study

Status: REPORT, read-only study, no repo changes. Written 2026-11-23 20:45Z by the thread "Assess renaming scripts to .scripts" for David's ask of 20:19Z.
Bases read: ES `origin/trunk_dev` 76c030f (open PR heads listed below), MA `trunk_dev` d60e0d2 and PR #2 head 888cad8, IM `trunk_dev`, Archived-Runbooks `main` 54e9680, project files as of 20:30Z.
Evidence: `scripts-dir-rename-evidence/` next to this file.

**Decision (David, 2026-11-23 20:45Z): no rename** ("Let's not rename the dir then. Otherwise, it'd be a coordination nightmare."). He asked instead for the 39 root-level ES test files to be cleaned up; that proposal is in the sibling file `es-root-tests-layout.md`.

## Answer in plain words

- **Is it viable? Yes, for ES.** A trial rename on a scratch copy of ES changed 994 lines in 127 files. The four test packages that use the scripts came back to their exact pre-rename results, apart from two tests that pin file hashes on purpose and say so when they fail. A simple script can prove such a change is a pure rename (every changed line differs only by the dot).
- **Only ES has such a folder.** MA, IM, Coordinator and Bridge-Core have no top-level `scripts/` or `script/` on any branch. But IM and MA *call* ES's `scripts/` by path, so the rename reaches them.
- **My recommendation: don't do it.** The gain is cosmetic and smaller than it looks, and the cost lands on nine open ES PRs, two other repos, two runbooks, two box helper scripts and every SHA-256 pin on the scripts. One part can break without any test noticing (IM). Details and an alternative below. If David still wants it, the plan at the end does it safely.

## What exists today

Repo-validated, ES `trunk_dev` 76c030f:

- `scripts/` holds 79 files: 45 at the top (the numbered operator entry points such as `01_bringup.sh` and `72_supported_local_setup.sh`, plus the `remote_alpha_*.sh` wrappers) and 34 in `scripts/internal/`. 68 `.sh`, 10 `.py`, 1 `.sha256`. No Go code.
- ES already puts every other non-Go folder behind a dot: `.docs` (39 files), `.examples` (30), `.runbooks` (5), `.out` (1), `.codex` (1), `.github`. None of them holds Go code. `scripts/` and `testdata/` are the only non-Go folders without a dot. So `.scripts/` would match the repo's own habit.
- The ES root has 61 entries. **39 of them are root-level `*_test.go` files.** On GitHub all 61 show either way. Locally, `ls` would show 52 instead of 53.

## Who uses the path

Counted with `git grep -E '(^|[^.[:alnum:]_-])scripts/|"scripts"'` plus path forms like `${REPO_ROOT}/scripts"`; the lines-per-file list is in the evidence folder.

| Where | Files | Lines | Notes |
|---|---|---|---|
| ES Go tests | 42 | 366 | `docs_contract_test.go` alone 141. No production Go code uses the path. |
| ES scripts referring to each other | 58 | 241 | 58 of the 79 scripts change content, not just place. |
| ES `.docs/` | 13 | 238 | Many are pinned word for word by `docs_contract_test.go`. |
| ES `AGENTS.md`, `PLANS.md` | 2 | 58 | |
| ES `.runbooks/` | 5 | 70 | |
| ES `.examples/` | 5 | 10 | Three `package.sh` call `${REPO_ROOT}/scripts/package_example_archive.py`. |
| ES CI (`.github/workflows/go.yml`) | 1 | 2 | `source scripts/internal/spire_release.sh`. The workflow's SHA-256 is pinned in `docs_contract_test.go`, so it must be re-pinned. |
| ES `.out/Dockerfile` | 1 | 1 | Generated header names the generator script. |
| **ES total** | **127** | **986** | Trial D changed 994 lines because it also catches forms like `/scripts"`. |
| IM `trunk_dev` | 10 | 64 | **Product code**: `src/infra_manager/adapters/execution_substrate_supported_local.py` runs `{guest_repo_root}/scripts/72_supported_local_setup.sh` and `scripts/01_bringup.sh`; `src/infra_manager/config.py:31-34` lists required ES files by path. IM has no open PR. |
| MA `trunk_dev` | 6 | 23 | **Product code**: `src/maintenance_agent/execution.py:46` `_EXPECTED_HELPER = "scripts/remote_alpha_operator.sh"`, plus config example, tests, docs. MA PR #2 (v2) deletes all of it; its branch has no reference left. |
| Archived-Runbooks `main` | 2 | 4 | "Linux Recovery" clones ES `trunk_dev` fresh and needs `scripts/internal/remote_alpha_es_service_tls_renew.sh` **and pins its SHA-256 `45ff1737…4432`**; the rename changes that file's bytes, so the pin must move too. "Claude Access" section 5 gives two firewall commands with `<copy>/scripts/…`. |
| Project files, live | 2 | 21 | `test-hardware-linux-1/es-vault-login-diagnose.sh` and `es-vault-unseal-key-step.sh` clone branch `claude/project-thread-vmre16` and **pin SHA-256 values of four `scripts/…` files**. They keep working until that branch takes up a rename, then stop safely ("SHA-256 differs"). Also one false positive in `operating-protocol/` (the words "scripts/configs") and one citation in `strategy/` at a recorded commit. |
| Project files, historical | 108 `.md` | 337 | Under `reports/` (markdown up to 4 levels deep; logs not counted). Evidence at recorded commits: leave as is. Same for chat archives. |
| Box, persistent | 1 | 1 | `scripts/remote_alpha_reset_disposable_vault.sh:8` defaults to `/home/ds/Scripts/execution-substrate-remote-alpha-check/scripts/…`, a copy kept on the box. A rename can keep that path. |
| Box, per run | | | ES stages helpers on the box under `${staging_root}/scripts/…`, `/var/tmp/execution-substrate-remote-alpha/helper-staging/scripts/…` and `/tmp/…-upload/scripts/…`, created fresh on each run. The installed host firewall unit (PR #35) has no script path, only a comment. |

Not inspected: David's Mac (his local ES clone, and whether an MA v1 install there still points at `scripts/remote_alpha_operator.sh`; the approved folders don't include the ES clone), and the box itself (not reachable from the cloud).

## Open PRs: what a rename would do to them

Trial: I made a rename commit on top of `trunk_dev` 76c030f and merged each open PR head into it with git 2.x's default merge (ort), then again with `merge.directoryRenames=true` (git moves new files into the renamed folder by itself).

| PR | Head | Touches `scripts/` | Result on the rename |
|---|---|---|---|
| #12 reliable submit | 4416699 | no | Clean apart from a `PLANS.md` conflict it **already has** with today's `trunk_dev` |
| #29 artifact bytes | 91dbad6 | no | Clean |
| #30 TLS collector containment | eed4c9b (rebased onto 76c030f) | edits 2 | Clean |
| #31 Nomad lock | 7aaac66 (rebased onto 76c030f) | adds 3, edits 9 | 2 real content conflicts (`70_linux_setup.sh`, `73_supported_local_proof.sh`); 42 new lines of its own say `scripts/` |
| #33 Vault plan guard | 04ea98e | no | Clean |
| #34 SPIRE agent helper | 0927911 | adds 2 | New files land in `.scripts/` with the setting on (conflicts without it); its own text still says `scripts/` 20 times, so tests would fail until fixed |
| #35 host firewall | 0c95eb7 | adds 3, edits 1 | Same as #34, 30 lines to fix; the Claude Access runbook and the two box scripts also point at this branch |
| #36 README rewrite | 555ee47 | no | Conflict in `README.md`. The new newcomer README keeps 8 `scripts/…` commands in its quick start (`scripts/01_bringup.sh up`, …) |
| #37 move four submit runbooks to Archived-Runbooks | f372786 | edits 1 | Conflicts on the 4 moved runbooks and `README.md`. Once they live in Archived-Runbooks, about 27 more `scripts/` lines sit outside ES |

Heads re-checked 20:42Z; #36 and #37 opened during the study. The PR 27 follow-up had no PR yet. ES requires branches to be up to date before merging, so **every open PR would have to take up the rename before it can merge**, and each take-up changes the PR's audited bytes, so each needs a delta audit. Inference: GitHub's own merge button may report the new-file cases as conflicts; I did not test GitHub's server-side merge.

## Trial renames and tests

Run in this container as an unprivileged user, Go 1.26.5, packages `.`, `./es/admission/`, `./cgs/app/`, `./es/app/` (the only ones that reference the folder). The untouched base had 291 failing tests here (missing Nomad, Vault, SPIRE and root), so I compared test by test against the base.

| Trial | How references were rewritten | Tests that passed before and fail after |
|---|---|---|
| B | Simple `sed`-style rewrite of `scripts/` that skipped anything after `/` | 33 top-level tests |
| C | Also rewrote `${REPO_ROOT}/scripts/`, kept the box staging layout as `scripts/` | 24 top-level tests: scripts build the box layout from the repo layout, and forms like `"${REPO_ROOT}/scripts"` were missed |
| D | Every form, box staging layout renamed too, persistent box copy path kept | **2**, both deliberate pins: `TestGo1265ToolchainBaselineDocsAndBuildContract` (CI workflow SHA-256) and `TestRetiredRemoteAlphaProtectedWrappersAndHistoricalFixturesRemainExact` (path, size and hash of retired wrappers) |

Trial D's move commit is 79 pure renames; all 127 rewritten files turn back into the original bytes when `.scripts` is mapped back to `scripts` (`substitution-only-check.sh` in the evidence folder; exit 0). `go vet ./...` passed on all trials. Lesson: a quick find-and-replace breaks things; the safe way is the complete rewrite plus that check. **Not verified:** the ~290 tests that cannot run here, CI, and a run on the box.

## How tools treat a dot-folder

Tested here unless marked.

| Tool | Sees `.scripts/`? |
|---|---|
| `go build/test/vet ./...` | Skips it ("Directory and file names that begin with "." or "_" are ignored", `go help packages`). No effect: there is no Go code in it. |
| `gofmt -l .` | Walks into it |
| `git grep`, `git ls-files`, `grep -r`, `find` | Yes |
| Claude's own Grep and Glob tools | Yes (tested) |
| `rg` (ripgrep) | **No**, unless `--hidden` |
| Shell globs (`*/`, `**`), `ls` | **No** (`ls -a` shows it) |
| macOS Finder | **No** by default (Cmd-Shift-. shows it); not tested here |
| `pytest` collection | **No** (`.*` is in its default skip list); no tests live there today |
| `ruff check .` | Yes |
| GitHub file view | Yes. ES's `.docs`/`.runbooks` are already browsed this way; Archived-Runbooks links straight into `.runbooks/` |
| GitHub code search | Yes (a search in `path:.runbooks` returned 5 hits) |

## Trade-offs

For:
- Matches ES's own habit: every other non-Go folder already has a dot.
- One fewer entry in a local `ls`.

Against:
- **Small gain.** The root's clutter is the 39 root-level test files, not this folder. On GitHub nothing disappears; the folder just moves into the dot group.
- **Hides the front door.** These scripts are how an operator runs ES (`01_bringup.sh up`, `72_supported_local_setup.sh setup`). After `git clone`, `ls`, Finder, `rg` and shell globs skip them. That cuts against David's 20:15Z rule that newcomers should find their way easily.
- **One break that no test catches.** IM's tests assert the old string, so IM stays green while its real run fails, unless IM changes in the same tranche. MA v1 is the same until MA PR #2 lands.
- **Every pin moves.** 58 of 79 scripts change bytes, so every SHA-256 pinned elsewhere breaks: the recovery runbook, the two box helper scripts, the protected-wrapper guard and the CI workflow pin. They all fail safely, but each needs a careful re-pin. The recovery runbook would be broken in an emergency until it is updated.
- **Disturbs live work.** Nine open ES PRs must take it up, five by hand (#31, #34, #35, #36, #37), each with a fresh delta audit. Box staging paths in docs change (`helper-staging/.scripts/…`), and David's and the runbooks' habits change.
- **Root-run box staging code is touched.** The change is mechanical, but it runs through helpers that stage files as root on the box, so by the procedures it needs the full provenance gate.

## Recommendation

**No: keep `scripts/`.** The rename is viable, but the benefit is cosmetic and smaller than it looks, while the cost is broad, falls during the busiest stretch of parallel ES work, and has one failure mode that no test sees.

If the goal is a tidier root, the real clutter is the 39 root-level `*_test.go` files. Moving them into a package folder would remove far more, but they read repo-relative paths, so that needs its own study. Separately, on outsiders' discoverability, the existing dot-folders (`.docs`, `.runbooks`, `.examples`) arguably point the wrong way: Go ignores folders without Go code anyway, so their dots buy nothing for tooling. That is out of scope here and only worth raising with the README rewrite.

## If David says yes: how to do it without breaking parallel work

Start only once all of these hold (a thread can check each one):
1. MA PR #2 has merged (it removes MA's dependence on the path). Otherwise the MA v1 change (1 code line, config, tests, docs) joins this tranche.
2. No open ES PR adds or edits files under `scripts/`, and the README rewrite (#36) and runbook move (#37) have landed. Today #30, #31, #34, #35 and #37 touch `scripts/`, and #36 and #37 conflict on text. Going earlier is possible, but then each of them pays the take-up cost above.
3. No box work is running from a staged copy, and the two box helper scripts in `test-hardware-linux-1/` are not mid-use.

Then, in one tranche:
1. **ES PR** from one thread, two commits: (a) `git mv scripts .scripts` only, so git shows 100% renames; (b) the rewrite (trial D rules in `trialD-rewrite-rules.sh`), the README and docs, plus re-pinning the two guards. This is scripts, tests, docs and CI only, so it is in the lane that merges after audit and the merge gate without David's review. The audit runs `substitution-only-check.sh` and recomputes the two new pin values itself; full provenance gate because it touches box staging helpers. Before merging, one read-only status route on the box from the branch, as the live check.
2. **IM PR, ready before the ES merge and merged right after it** (10 files, 64 lines: adapter, `config.py`, tests, docs). This is the only way to cover the break IM's tests can't see.
3. **Open ES PRs take up `trunk_dev`** with `git -c merge.directoryRenames=true merge origin/trunk_dev`, then fix their own new references (#34 about 20 lines, #35 about 30, #31 two script conflicts), and each gets a delta audit.
4. **Archived-Runbooks PR** (David merges, since pushes to `main` get blocked): the recovery runbook's helper path and its new `INTERNAL_HELPER_SHA256`, the two Claude Access commands, and the runbooks #37 moves there.
5. **Project files:** the two `test-hardware-linux-1/` scripts get new paths and SHA-256 pins once their branch takes up the rename. Historical reports and chat archives stay as they are.
6. **Box:** nothing persistent changes; the per-run staging folders are recreated each run. Record it in the Claude Access history only if a box run is part of the check.

Rough cost: one mechanical ES PR with a full audit, one small IM PR, a delta audit on each PR still open at that point, one runbook PR and two project-file edits.

## Evidence (folder `scripts-dir-rename-evidence/`)

- `es-trunk_dev-76c030f-files-with-refs.txt`: lines per file at ES `trunk_dev`.
- `test-compare-base-vs-trial.txt`, `…-trialC.txt`, `…-trialD.txt`: test-by-test comparison (trial B is the file named `trial`).
- `trialD-rewrite-rules.sh`, `trialD-shortstat.txt`: the rewrite and its size.
- `substitution-only-check.sh`: the pure-rename check, run on trial D with exit 0.
- `runtests.sh.txt`, `cmp.py.txt`: how the tests were run and compared.

The trial commits lived only in this thread's scratch copy and were not pushed.
