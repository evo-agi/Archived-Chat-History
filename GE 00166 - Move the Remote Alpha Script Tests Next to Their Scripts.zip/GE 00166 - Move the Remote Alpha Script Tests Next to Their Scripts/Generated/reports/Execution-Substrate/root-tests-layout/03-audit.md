# ES PR #39, root test files layout: audit 03

Written 2026-11-23 from 21:52Z onwards by the independent audit thread "Audit Execution-Substrate PRs". Read-only: nothing was pushed, commented, reviewed or merged. Evidence is in `03-audit-evidence/` next to this file. My local names carry the tags `39a` (runs at the first target, `ca62419`), `39b` (the final target, `0d1de0d`) and `39c` (the whole-module rerun on copies with git's file modes).

The request named `reports/Execution-Substrate/root-test-move/02-audit.md`. The writer's reports are in `root-tests-layout/`, and the writer already used the number 02 (`02-provenance-update.md`). So this report is `03-audit.md`, next to them.

## Verdict

**ACCEPT, with two Low findings to fix in this PR** (A39-1 and A39-2 below; under the project rule, Low findings are fixed in the PR that has them).

- **No test is lost or weakened.**
  - Every test function at the base is still defined at the tip.
  - Test by test, the results are the same at the base and the tip, and the 4 new results all pass.
  - Every test that fails in this container fails with the same message on both sides.
  - The tests read the same repository files before and after the move. They also look up the same missing files, and they look up no path relative to `scripts/`.
- **The layout matches the agreement.** The four commits are as described, and the PR changes only tests and CI config. `internal/testutil` is linked into no binary.
- **The manifest verifies.** I reproduced `8ad0e5fa…9000` at `0d1de0d` against `400ff7f` byte for byte. Its 73 file entries are identical to the first target's.
- **The whole-module comparison is clean.** `go test ./...` at the final base and tip gives 7,007 and 7,011 results: 0 lost, 0 changed, and 4 new results that all pass. All 238 failures in this container fail with the same output on both sides.
- **CI is green on the final head.** Run 45276818522 of `build, vet and test` on `0d1de0d` succeeded (22:09Z to 22:38Z). The earlier run on `ca62419` was cancelled when the merge was pushed.
- **The missed-path check works on the forms it covers.** It caught both planted mistakes that are in its scope. A third mistake, outside its scope, was caught by the test's own count floor.
- **Two Low findings:**
  - A39-1: nothing enforces the layout. A new script test added at the root compiles, passes, and no check fires. The design's claim that such a file "fails on its own" assumed no test package was left at the root, which is not the agreed layout.
  - A39-2: the missed-path check misses three forms, and none of them occurs in the tree today.

## In plain words

The PR moves the 31 Remote Alpha script tests into `scripts/`. It moves the caller-identity check into `internal/callerauth`, renames one docs test, and puts the shared helpers in a new test-only package. I checked that every test still exists, still gives the same result for the same reason, and still reads the same files, before and after the move, at the final base and tip. It does. The check that is meant to catch a path the move missed works for the mistakes it was built for. But it has three blind spots, and nothing stops a future PR from adding a script test back at the root. Today's open PRs can't do that by accident: I trial-merged each of them, and their six new root tests fail to build there. Both gaps are cheap to close, and closing them before merge is what the project's rule on Low findings asks.

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #39 (draft), branch `claude/project-thread-wkerpy` |
| Final target | head `0d1de0d638792c1cc71d764f6c3fb387ea22c2c0`, tree `bfde9b4ac60d398cb48f05ba30bfaac24c3bd043` |
| Final base | trunk_dev `400ff7faa0f124b10dbb607fbad009e346bac4df` (#36, README only) |
| First target | head `ca6241977c833fc9b246562e89a2207dd20a1a76` on base `fdfa3bc` (#29) |
| Recipe | v2, source SHA-256 `c08597e2…a1a3ca`, verified before every run |
| Manifest (final) | `8ad0e5fa1193c38d4e625c5363c7268cb0bd093b658d16eb4844fc6beb719000`, 73 files, textual diff `3f9fb3bb…68dc` |
| Manifest (first) | `7dc5deca5c2ab407d9a75c55d9d1b1f99cbc0b0f7ee3026cc6503d53eb6251fd`, 73 files, same textual diff |
| Toolchain | Go 1.26.5, `GOTOOLCHAIN=local`, `env -i`, user `ci` (1500:1600) |

Refs were checked at the start of each target and at the end (`ls-remote-open*.txt`, `ls-remote-close.txt`).

**Why results from the first target carry over.** The new head is a merge of `400ff7f` into `ca62419`.
- The PR's diff against its base is byte-identical before and after: `git diff --binary` hashes to `4af780df…97ad` both times.
- The merge brings in exactly #36's diff (`460219bc…71a1`), which is `README.md` only.
- `git range-diff` shows all four commits as `=`.
- The only test that reads `README.md` is a docs test at the root, and it stays at the root on both sides.

So the file-log and mutant runs at `ca62419` apply to `0d1de0d`. The inventory, manifest and whole-module comparison were redone at the final target.

## Manifest

- Taken twice in `/opt/audit/es`, with the tip bytes in the working tree, HEAD reset `--mixed` to the base, and upstream pinned to `origin/trunk_dev`. The two runs are byte-identical.
- `git status --porcelain` was empty after returning to the tip.
- It is byte-identical to the writer's `02-manifest.json`. Its `files` array is identical to the first target's manifest; only `head` (the base) differs.
- The first target's manifest also matched the writer's `01-manifest.json`.

## Commits and layout

| Commit | What git records | Matches the description |
| --- | --- | --- |
| `6b20d82` | 31 × R100, 0 lines changed | yes, pure renames |
| `4ee59c6` | 5 added, 33 modified (31 moved files, `docs_contract_test.go`, the CI list), +1,250 −117 | yes |
| `af0f786` | 1 × R081 (`caller_authentication_contract_test.go` → `internal/callerauth/`) | yes |
| `ca62419` | 1 × R100 (`remote_alpha_access_contract_test.go` → `host_access_docs_contract_test.go`) | yes |
| `0d1de0d` | merge of trunk_dev `400ff7f` | `README.md` only |

Against the agreement (design doc line 3, David 21:18Z to 21:24Z):

- **`scripts/`:** holds the 31 Remote Alpha script tests plus `helpers_test.go` and `testtmpdir_main_test.go`. No `remote_alpha_*_test.go` is left at the root.
- **Root, 8 test files:** `docs_contract_test.go` keeps all 143 of its test functions, the same names as at the base, and so all its Remote Alpha doc tests. I could not reproduce the figure 57 with one simple count: 40 functions are named `TestRemoteAlpha…` and 64 mention Remote Alpha. But no function left the file.
- **`internal/callerauth`:** has the caller-identity check.
- **`host_access_docs_contract_test.go`:** the rename.
- **`internal/testutil`:** has the helpers.
- **`artifact_hygiene_test.go`:** keeps its name.

`internal/testutil/testutil.go` is the only new non-test Go file.
- No package imports it from non-test code. Only the test imports of four packages do.
- It is outside the dependency closure of all 7 main packages for linux/amd64, linux/arm64 and darwin/arm64 (`testutil-deps.txt`).
- So the PR stays tests and CI config only.

The helper bodies in `testutil.go` are the old root helpers line for line, with the same failure messages. The root and `scripts` wrappers keep their old names. `testutil.Root` checks `go.mod` starts with `module execution-substrate`. The old root value checked a regular `go.mod` and a `scripts` folder, and `TestRootIsTheRepositoryRoot` now checks `go.mod`, `AGENTS.md`, `PLANS.md` and `scripts`.

**Other checks:**
- No file in the repository still names a moved test file by its old root path.
- No document tells the reader to run a moved test from the root.
- The 11 entries in `.github/ci/environment-only-tests.txt` now say `execution-substrate/scripts`, and each names a test that exists there.
- gofmt is clean on every changed Go file.

## No test lost or weakened

**Inventory** (`test-functions-{400ff7f,0d1de0d}.tsv`, `inventory-compare.txt`):
- 1,561 Test, Benchmark, Example and Fuzz functions at the base and 1,567 at the tip.
- No name has fewer definitions at the tip.
- The six extra are the 4 `internal/testutil` tests and 2 `TestMain`.
- 324 functions moved to `scripts/`, 1 to `internal/callerauth`, and 1 with the rename.

**Test by test, changed packages** (first target, `cmp39a.txt`, `failout39a.txt`):
- I ran the root, `internal/callerauth` and `internal/testtmpdir` packages at the base. At the tip I ran the same packages plus `scripts` and `internal/testutil`.
- Results are keyed by test name, since moved tests kept their names.
- Base: 2,462 results. Tip: 2,466.
- 0 lost and 0 changed. 4 new, all pass.
- 324 top-level tests changed package from the root to `scripts`, and 1 to `internal/callerauth`.
- 235 results fail on both sides in this container. They are host-only: fake-host fixtures that need host tools, and the macOS `ds` account.
- All 235 failures have the same output on both sides, after normalising the tree path, temp paths, durations, pids, times and `file.go:N` line numbers.

**Test by test, whole module** (final target, `full39c.sh`, `cmp39c-full.txt`, `results-{400ff7f,0d1de0d}.tsv`):
- I ran `go test -count=1 -json -p 2 ./...` at `400ff7f` and at `0d1de0d`.
- Tests in the root, `scripts`, `internal/callerauth` and `internal/testutil` are keyed by name. Every other test is keyed by package and name.
- Base: 6,677 pass, 238 fail, 92 skip (7,007). Tip: 6,681 pass, 238 fail, 92 skip (7,011).
- 0 lost and 0 changed. The 4 new results are the `internal/testutil` tests, and they pass.
- All 238 failures have identical normalised output on both sides. 30 top-level tests fail:
  - 27 Remote Alpha host-only tests;
  - 2 in `reliablesubmit`, which require a production-source probe this container doesn't provide;
  - 1 `es/app` SPIRE and Vault bring-up.
- Package results: the root goes from fail to pass, because its host-only tests moved out. `scripts` is new and fails on those same tests. `internal/testutil` is new and passes.
- This agrees with the writer's `full-module-compare.txt`: 7,007 against 7,011, and only the 4 new tests differ. Their sandbox has 279 failures where this container has 238, which is a host difference.
- My first whole-module run (`cmp39b-full-umask002.txt`) used copies made by `git archive`. Its default tar umask 002 left files at 0664, so the mode-pinning tests failed on both sides: 247 failures. Three failure outputs differed there, and none of the three was a test difference:
  - one subtest printed its two lines in the other order;
  - one test reports the first mismatching entry of a Go map, which comes out in random order;
  - one `es/app` SPIRE and Vault bring-up stopped at a different step.

  I fixed the modes (`tree-check-exact-modes.txt`: all four copies now match git's 0644 and 0755 exactly) and reran. The numbers above come from the rerun. The first-target copies already had the right modes.

**What the tests read** (go test file log, first target, `testlog39a.sh`, `logcmp39a.txt`):
- Each test binary ran with `-test.testlogfile`, which records every `open`, `stat` and `getenv` the test process makes through package `os`, from its own package directory.
- I compared the base binaries (root and `internal/callerauth`) with the tip binaries (root, `scripts` and `internal/callerauth`). Paths were made repository-relative, and a moved file's base path was mapped to its tip path.
- **The repository files opened or looked up are the same set on both sides** (1,046 and 1,050 distinct entries), with two exceptions:
  - Only at the base: the 8 test files that stay at the root. At the base, the self-read glob of `LocalBoundaryIsInjectedWhole` and the Spire cleanup test covered every root `*_test.go`. At the tip it covers `scripts/*_test.go`.
  - Only at the tip: `scripts/helpers_test.go`, `scripts/testtmpdir_main_test.go` (picked up by that glob), and `internal/testutil`'s own files.
- The 16 lookups of files that don't exist (for example `.codex/config.toml`, `.out/remote-alpha-m75q/...` and `schemas`) are the same 16 on both sides, resolved against the root.
- The `scripts` test binary made 0 relative lookups.
- 0 lookups resolved to a path under `scripts/` that starts with a root name.
- Outside the tree, only random temp-file names differ (5 each side).
- The only environment variable read at the base but not at the tip is `PWD`. That is expected, because `os.Getwd` is gone.
- The file log does not see the scripts the tests start. For those I checked every `exec.Cmd` `Dir` in `scripts/` statically: 80 are `executionSubstrateRepoRoot` (39 before, 41 added), 6 are `remoteAlphaOperatorRepoRoot()` (now `testutil.Root`, was `os.Getwd()` at the root), and 1 each of `root` and `home` are unchanged. So every command keeps the working directory it had.

**Narrowed self-read glob:** this is an observation, and it needs no action.
- The 8 root test files left the glob's scope. They are in another package now and hold no fixture script.
- The writer reports the guard's counts are identical to the base: 141, 23, 31, 46, 29 and 17.
- Mutant P5 points the glob back at the root, and the test then fails on its own floors (0 found, want at least 22, 30 and 17).

## The missed-path check

`TestImportersNameRepositoryPathsFromTheRoot` (mutants on the first target, `pathmut39a.py`, `pathmut39a-a.log`, `pathmut39a-b.log`):

| Mutant | Result |
| --- | --- |
| P1: a tombstone read without `repoPath` | **caught**, at the exact line |
| P2: a command without its `Dir` | **caught**: "is not assigned to a variable whose Dir is set" |
| P3: `cmd.Dir = "."` (the package folder) | survives (A39-2a) |
| P4: `os.Stat("internal/callerauth/callerauth.go")` from `scripts` | survives (A39-2b); resolves to `scripts/internal/...`, which does not exist |
| P5: the self-read glob resolved against the root | the check passes, as its own report says it will; **caught** by the test's own count floor |
| P6: `stat := os.Stat; stat("PLANS.md")` | survives (A39-2c) |

The writer's two hand mutations are the tombstone revert and the `c.URIs` probe in `ars/api`. They match P1, and the moved caller-identity test still walks from the root with a floor of 100 files and all five API packages.

## Open PRs

Each of #30 (`eed4c9b`), #31 (`c3a94ae`), #34 (`26c7cf8`) and #35 (`27e8b64`) trial-merges into `ca62419` with no conflict (`vettm39a.sh`, `vettm39a.log`). Their edits to moved files follow the renames into `scripts/`. They add six new root test files between them, and with each PR merged the root package fails `go vet .`:

| PR | Root file | Missing identifier |
| --- | --- | --- |
| #30 | `remote_alpha_es_service_tls_status_child_namespace_test.go` | `remoteAlphaESProcessIdentityLoader` |
| #31 | `remote_alpha_nomad_acl_test.go` | `writeExecutable` |
| #34 | `remote_alpha_spire_agent_test.go` | `executionSubstrateRepoRoot` |
| #35 | `remote_alpha_host_firewall_test.go` | `executionSubstrateRepoRoot` |

`go vet` stops at the first type error, so for #30 and #35, which each add two root files, only one of the two is named. #30's merge also fails `go vet ./scripts` (`remoteCollectorDescendantStandIn` undefined): one of its edited script tests uses a helper from a file it adds at the root. So CI blocks each of these PRs until it moves its files, as the writer said. Nothing slips through silently.

## Findings

### A39-1 (Low): the agreed layout is not enforced

**What happens.** A new Remote Alpha script test added at the root is not caught. My probe `remote_alpha_zz39a_probe_test.go` reads `scripts/remote_alpha_operator.sh` through `mustRead` and runs `bash -n` on it by relative path (`rootprobe39a.sh`, `rootprobe39a.log`). With it in place:
- `go vet .` passes;
- the probe test passes;
- `internal/testutil` passes;
- `internal/testtmpdir` passes.

**Why.** The missed-path check covers only packages outside the root, by design. The root keeps `mustRead`, `compactText`, `docSection`, `compactDocSection`, `assertContainsAll`, `assertContainsNone` and its own `remoteAlphaOperatorScriptPath`. The design doc (line 65) says "a test file added back at the root fails on its own: it can't see the helpers … and the testtmpdir guard refuses a test package without its TestMain". That was written for the `tests/` plan, where no test package was left at the root. Under the agreed layout it holds only for tests that need helpers which moved.

**Effect.** No test result is wrong: a test at the root runs from the root, so its relative paths are right. The layout just drifts back over time. The project rule is no "revisit later" without a machine-enforced trigger.

**Suggested fix:** a test, for example in `internal/testutil/testutil_test.go`, that lists the root's `*_test.go` files exactly, in both directions. Its failure message should say that script tests belong in `scripts/` and docs tests are named `*_docs_contract_test.go`. Add a self-test or mutant pair for it: an extra root file fails the test, and so does a missing one. A naming rule is looser but needs no edit when a docs test is added: a root test file must end in `_docs_contract_test.go` or be one of `docs_contract_test.go`, `artifact_hygiene_test.go` and `testtmpdir_main_test.go`. Either version also catches the six open-PR files by name, not only by a compile error.

### A39-2 (Low): three forms the missed-path check misses

None of these forms occurs in the tree today: the file log shows 0 relative lookups from `scripts`, and the `Dir` values above are all root or unchanged. But each one passes the check while running or looking in the wrong folder:

- **a. The `Dir` value is not checked (P3).** `cmd.Dir = "."` passes, and the command runs in `scripts/`. The report's rule wording ("assigned to a variable whose Dir is set") is accurate, but its non-claims don't list this case. **Fix:** require the value to resolve statically to the root, which in practice means `executionSubstrateRepoRoot`, `testutil.Root`, `remoteAlphaOperatorRepoRoot()` or `testutil.Path(...)`, or to a value that is not a repository-relative literal, such as a `t.TempDir()`-derived variable. At minimum, refuse a literal relative `Dir`, `"."` included.
- **b. A first element that both folders hold is skipped (P4).** `scripts/` has its own `internal/`, so the check skips every path that starts with `internal/`, by design ("names something at the root but not in the package's own folder"). A test that expects a root file under `internal/` to be absent then passes for the wrong reason, and one that expects it present fails confusingly. **Fix:** for such paths, flag them when the whole path exists at the root but not under the package folder, or when it exists in neither. Also name this seam in the non-claims.
- **c. A covered function used as a value (P6).** `stat := os.Stat; stat("PLANS.md")` passes. **Fix:** flag any reference to a covered function that is not a direct call.

## What I did not cover

- I ran nothing on the Mac or the Linux box. Docker, Nomad, Vault and SPIRE tests in `es/app` did not run with their services in this container. They fail or skip the same way on both sides, and GitHub CI is the run with services.
- I did not re-run `go vet` for darwin/arm64 myself. CI runs it, and CI run 45276818522 is green on `0d1de0d` (`ci-runs.txt`).
- The file log sees only the test process. Child processes are covered by the static `Dir` check above, not observed.
- I did not review the six open-PR test files beyond the trial merge and compile check.
- The 57 figure is not reproduced; see Commits and layout.
- Inference: `go test` sets `PWD` to the package directory for the test binary, and a child started with an explicit `Env` inherits that `PWD` even when its `Dir` is the root. bash resets `PWD` when it doesn't match the working directory, and the results are identical, so I saw no effect.

## Sensitive material

The probes and mutants are synthetic. No key, certificate body, token, env file or config file is copied into the evidence. Commit-message trailers and author names are left out. The report and evidence were scanned with the thread's pattern list, and a positive control hit 2 of 2. The hits are David's first name in this report, and four subtest names in `results-*.tsv` that carry the repository's own placeholder `hvs.abcdefghijklmnopqrstuvwxyz`, which is the alphabet and no token.
