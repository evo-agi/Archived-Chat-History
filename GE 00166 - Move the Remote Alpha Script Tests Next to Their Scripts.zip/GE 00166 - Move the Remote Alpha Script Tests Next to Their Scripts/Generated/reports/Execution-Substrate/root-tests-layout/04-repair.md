# ES root test files layout: repair report 04 (A39-1, A39-2)

Written 2026-11-23 ~22:58Z by the thread "Plan moving ES root test files". PR: https://github.com/evo-agi/Execution-Substrate/pull/39. This answers audit 03 (`03-audit.md`, ACCEPT with two Low findings). Nothing was force-pushed.

## Target identity

| Item | Value |
|---|---|
| Base (`origin/trunk_dev`) | `0aa4a2b5d8e93a10f65b3bb724b286ee79a0aa7e` (#33, es/config tests only) |
| Tip | `8e77b95a865c42c8b82cc6b9b4a884abc220582c` (merge commit, parents `6c949dc` and `0aa4a2b`) |
| Tip tree | `1748feefe78cf0ba7196806514302426fbe221e4` |
| Recipe | v2, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before the run) |
| Textual-diff SHA-256 | `3f9fb3bb5444fa44e817882d1a61ab096af0d222c1233787497b8182a25b68dc` (unchanged: it covers files the base already tracks, and the repair only changes files that are new against the base) |
| Canonical-manifest SHA-256 | `7fc8878e687acc69a1ea169ae38c8685f3d8a07a23235b534e7be46cae40aa53` |
| File count | 73 |
| Manifest JSON | `04-manifest.json` |

Procedure as in reports 01 and 02:
- Two runs into a fresh 0700 directory, byte-identical (`04-evidence/manifest-run{1,2}-stdout.txt`).
- The staged path set (`git diff --cached --no-renames --name-only`) equals the 73 manifest paths.
- `git status --porcelain` is empty after `git reset --mixed` back to the tip.

## What changed since audit 03's target (`0d1de0d`)

| Commit | What it holds |
|---|---|
| `f3b5289` Keep only the docs tests at the repository root | A39-1 |
| `6c949dc` Close three gaps in the missed-path check | A39-2 |
| `8e77b95` Merge trunk_dev (#33) | `es/config` tests only |

For the diff-only check:
- The two repair commits change only `internal/testutil/testutil_test.go` and two lines of the package doc in `internal/testutil/testutil.go`. `git diff 0d1de0d 6c949dc` is in `04-evidence/repair.diff` (SHA-256 `f39edd65…fee6`).
- The merge brings exactly #33's diff: `git diff --binary 6c949dc 8e77b95` and `git diff --binary 400ff7f 0aa4a2b` both hash to `7881dc65…69b6`. Neither `es/config` package imports `testutil`.
- `git range-diff 400ff7f..0d1de0d 0aa4a2b..8e77b95` shows the four original commits as `=`.
- Against `02-manifest.json`, the 73 paths are the same. Only the `testutil.go` and `testutil_test.go` entries differ, plus `head` (the base).

## A39-1: the root keeps only its docs tests

`TestRootKeepsOnlyItsDocsTests` reads the Go files at the root. It refuses any file that is neither a docs test nor one of three fixed files:
- A docs test is named `*_docs_contract_test.go`, without `remote_alpha` in the name. That is the agreed naming: root names say what they check, with no "remote alpha" (David, 21:18Z).
- The three fixed files are `artifact_hygiene_test.go`, `docs_contract_test.go` and `testtmpdir_main_test.go`. The test also reports any of them that goes missing.

The failure message says that a test of a script belongs in `scripts/`. `TestRootLayoutCheckFindsEachKindOfProblem` passes the agreed eight names and refuses each of the following:
- a script test;
- a script test named like a docs test;
- another name;
- a non-test file;
- a missing fixed file.

I chose the naming rule over an exact list for two reasons. A new docs test needs no edit to the check. And parallel PRs that each add a docs test would conflict on a shared list. The six root files that #30, #31, #34 and #35 add are now refused by name, as well as by the build failure.

## A39-2: three gaps in the missed-path check, and what else they led to

- **a. A command's working directory is now checked.** A `Dir` whose value resolves to a relative path is reported, and that includes `""` and `"."`.
  - This also holds through helper parameters: `runAt(".")`, where `runAt` sets `cmd.Dir = dir`.
  - It also holds in an `exec.Cmd` literal, which is now reported when it has no `Dir` and isn't assigned to a variable whose `Dir` is set.
  - An opaque value passes, such as `remoteAlphaOperatorRepoRoot()` or a `t.TempDir()` path. The tree's 88 `Dir` values are all root or temp-dir values, and all pass.
- **b. A relative path must now name, in full, something the package directory holds.**
  - Before, a path was skipped when the package directory held its first element. So `internal/...` from `scripts/` passed, because `scripts/internal` exists.
  - Now a whole value is looked up under the package directory. It is reported if the root holds it instead, or if neither does.
  - A value whose end is unknown, such as `filepath.Join("internal", name)`, is reported when both folders hold its first element, or when neither does.
  - A path starting with `..` is reported.
  - For this, path joins and concatenations of literals are now followed to their whole value, not just their first argument. A helper parameter that only starts a path, such as `dir` in `filepath.Join(dir, "own.sh")`, is checked as the start of one.
  - One side effect: `exec.Command("bash", filepath.Join("scripts", x))` is now caught. Before, only `"scripts"` was read, and a bare directory name counts as a plain argument.
- **c. A covered function used as a value is reported.** This covers `os.*`, `filepath.*`, `exec.Command`, `testutil.Path`/`Read`, path joins and `Chdir`, at function or package level.
  - The package's own path helpers are reported the same way, unless a local name shadows them.
  - An import of `os`, `os/exec`, `path`, `path/filepath` or `testutil` under another name, or as `.`, is reported too, because the check knows these functions by their package name.

The self-test now runs on a repository root and package directory of its own, in a temp dir, so its verdicts don't depend on the real tree. All the earlier cases are kept. Two cases now show the whole joined value in their message (`"scripts/internal"`, `"scripts/x.sh"`). New cases show each rule above firing at an exact line. A good snippet shows each allowed form passing.

The real tree passes the stricter check with no change to any test outside `internal/testutil`.

## Mutants (`04-evidence/mutants.py.txt`, `mutants.log`)

Each mutant changes the tree, runs `TestImportersNameRepositoryPathsFromTheRoot` and `TestRootKeepsOnlyItsDocsTests`, then restores the tree.

| Mutant | Result |
|---|---|
| P1: tombstone read without `repoPath` | caught at the exact line |
| P2: a command without its `Dir` | caught |
| P3: `cmd.Dir = "."`, and P3b: `cmd.Dir = ""` | **caught** (was A39-2a) |
| P4: `os.Stat("internal/callerauth/callerauth.go")` from `scripts` | **caught** (was A39-2b): "the package directory does not hold but the repository root does" |
| P4b: the same through `filepath.Join` | caught |
| P4c: `filepath.Join("internal", name)` with `name` unknown | caught: "both … hold" |
| P4d: an absence check of `.codex/hooks.json` | caught |
| P4e: `schemas/x.json`, which neither folder holds | caught |
| P5: self-read glob resolved against the root | passes the check, as before and by design; that test's own count floors catch it (audit 03) |
| P6: `stat := os.Stat; stat("PLANS.md")` | **caught** (was A39-2c) |
| P6b: package-level `var readFile = os.ReadFile` | caught |
| P6c: `read := mustRead` | caught |
| P7: `Dir` set through a helper parameter | caught |
| P8: `exec.Cmd` literal without a `Dir` | caught |
| P9: `fp "path/filepath"` | caught |
| R1: the audit's root probe `remote_alpha_zz39a_probe_test.go` | **caught** (was A39-1) |
| R2: the same named `remote_alpha_zz_docs_contract_test.go` | caught |
| R3: `artifact_hygiene_test.go` missing | caught |

Checker mutants: with the value-use pass, the `Dir` rule, or the "both folders" rule switched off, `TestRepoPathCheckFindsEachKindOfProblem` fails.

## Validation

- `go vet ./...` passes for linux/amd64. `go vet` of the root, `scripts` and `internal/testutil` also passes for darwin/arm64. gofmt is clean.
- As the `ci` user, with Go 1.26.5, in a clean clone at `8e77b95`:
  - `go test` on `internal/testutil`, `internal/callerauth` and `es/config` passes;
  - `go vet` on the root, `scripts`, `internal/testutil`, `internal/callerauth` and `es/config` passes.
- I did not rerun the root and `scripts` tests: the repair changes no file they compile. `testutil.go` changed only in its doc comment, and `testutil_test.go` goes only into `internal/testutil`'s test binary. Their results at `0d1de0d` stand, and audit 03 reproduced them. GitHub CI runs the whole module on the new head.

## Non-claims and seams

- **The check is still a static approximation.**
  - Values that come from other calls are opaque.
  - Positional struct literals are not resolved.
  - Names are not scoped, so the check can only report too much.
  - A value whose first element isn't known in full, for example `"intern" + x`, is checked only against names that the root alone holds, as before.
- **The P5 class is still out of the check's scope:** a glob resolved against the root that matches the wrong files there. The test's own floors cover the one case in the tree.
- **`cmd.Dir = testPackageDir` passes on purpose.** It is an explicit choice, not a missed path.
- **Root tests are not path-checked,** because relative paths are right at the root. A39-1 now holds which files may be there.
- The design doc's claim that a root test file "fails on its own" was written for the earlier `tests/` plan. `TestRootKeepsOnlyItsDocsTests` now enforces it.
- **GitHub CI on `8e77b95`:** "build, vet and test" passed (run https://github.com/evo-agi/Execution-Substrate/actions/runs/45284024586, 22:54Z to 23:23Z).

Under the protocol (§ branch updates), this calls for a diff-only re-check of the two repair commits, plus a provenance check of the #33 merge.
