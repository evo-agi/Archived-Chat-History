# ES root test files layout: provenance update 02 (trunk_dev moved to #36)

Written 2026-11-23 ~22:15Z. PR: https://github.com/evo-agi/Execution-Substrate/pull/39

`trunk_dev` moved from `fdfa3bc` (#29) to `400ff7f` (#36, a README-only rewrite). I merged it into the PR branch with no conflicts and pushed a fast-forward. Nothing was force-pushed.

| Item | Value |
|---|---|
| Base (`origin/trunk_dev`) | `400ff7faa0f124b10dbb607fbad009e346bac4df` |
| Tip | `0d1de0d638792c1cc71d764f6c3fb387ea22c2c0` (merge commit, parents `ca62419` and `400ff7f`) |
| Tip tree | `bfde9b4ac60d398cb48f05ba30bfaac24c3bd043` |
| Recipe | v2, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified) |
| Textual-diff SHA-256 | `3f9fb3bb5444fa44e817882d1a61ab096af0d222c1233787497b8182a25b68dc` (same as report 01) |
| Canonical-manifest SHA-256 | `8ad0e5fa1193c38d4e625c5363c7268cb0bd093b658d16eb4844fc6beb719000` |
| File count | 73 |
| Manifest JSON | `02-manifest.json` |

Same procedure as report 01:
- Two runs into a fresh 0700 directory, byte-identical.
- The staged path set equals the 73 manifest paths.
- `git status --porcelain` is empty after `git reset --mixed` back to the tip.

**Patch unchanged:**
- The 73 file entries (path, kind, mode, size, SHA-256) are identical to `01-manifest.json`. Only the `head` field (the base) differs.
- `git range-diff fdfa3bc..ca62419 400ff7f..0d1de0d` shows all four commits as `=`.
- No moved test reads `README.md`.

**Checks rerun after the merge:**
- `go vet` on the root, `scripts`, `internal/testutil` and `internal/callerauth`.
- `go test` on the root, `internal/testutil` and `internal/callerauth`. All pass. The root's docs contracts pass against the new README.

Under the protocol (§ branch updates), this qualifies for a provenance-only re-check if the audit had used report 01's target.

**GitHub CI:** "build, vet and test" passed on `0d1de0d` (run https://github.com/evo-agi/Execution-Substrate/actions/runs/45276818522, finished 22:37Z).
