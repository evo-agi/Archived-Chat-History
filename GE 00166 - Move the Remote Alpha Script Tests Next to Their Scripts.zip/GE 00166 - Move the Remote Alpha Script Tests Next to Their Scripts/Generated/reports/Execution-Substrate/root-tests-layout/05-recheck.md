# ES PR #39, root test files layout: re-check 05 (A39-1, A39-2 and the #33 merge)

Written 2026-11-23 from 22:58Z onwards by the independent audit thread "Audit Execution-Substrate PRs", after the coordinator asked for a diff-only re-check. Read-only: nothing was pushed, commented, reviewed or merged. Evidence is in `05-recheck-evidence/` next to this file. My local names carry the tag `39d`.

Subject: the writer's `04-repair.md`, which answers `03-audit.md`.

## Verdict

**ACCEPT for A39-1, A39-2 and the merge. Two new Low findings in the hardened check (A39-3, A39-4) should be fixed in this PR under the project rule on Low findings.**

- **A39-1 is closed.** `TestRootKeepsOnlyItsDocsTests` refuses audit 03's root probe `remote_alpha_zz39a_probe_test.go`, and also a non-test `.go` file at the root. The six root test files that open PRs #30, #31, #34 and #35 add are all named `remote_alpha_*_test.go`, so each one is refused by name, on top of its build failure.
- **A39-2 is closed.** All three forms are now reported:
  - `Dir` set to `"."` or `""`, directly or through a helper;
  - an `internal/` path that the root holds, written relative to `scripts/`;
  - a covered function used as a value.

  The checker's own self-test asserts each one at an exact line.
- **The scope is as stated.** The two repair commits change only `internal/testutil/testutil_test.go` and two lines of the package comment in `testutil.go`.
  - `8e77b95` is exactly git's merge of `6c949dc` and `0aa4a2b`. Its diff over `6c949dc` is byte-identical to #33's diff.
  - `range-diff` shows the four original commits unchanged.
  - Neither `es/config` package imports `testutil`.
- **The manifest verifies.** I reproduced `7fc8878e…aa53` twice: 73 files, base `0aa4a2b`, and a JSON file identical to the writer's `04-manifest.json`. The staged set equals its paths, and `write-tree` gives `1748fee`. Against audit 03's manifest, only the `testutil.go` and `testutil_test.go` entries differ.
- **Tests and vet pass on a ci copy at `8e77b95`.**
  - The tree check gives 504 entries and 0 differences.
  - `go vet ./...` passes, and so does `go vet` of the root, `scripts` and `internal/testutil` for darwin/arm64.
  - `gofmt` is clean.
  - The tests of `internal/testutil`, `internal/callerauth` and `es/config` pass.
- **CI:** run 45284024586 of `build, vet and test` on `8e77b95` succeeded (check run 138075526182, 22:54Z to 23:24Z). It runs the whole module, the new root-layout test included.
- **P5 is outside the check's present rule, but it is not out of reach.** I added a three-line rule: a root-anchored whole value that the package directory also holds is ambiguous.
  - It has 0 hits on today's tree.
  - It catches P5.

  So P5 is a choice, not a limit of the method. This is A39-4.
- **A39-3 (Low):** the check reads only the bodies of function declarations. A covered call in a package-level variable's initializer is never checked. That includes a function literal called at once, which is how a package-level absence check is usually written. No such form is in the tree today.

## In plain words

The two fixes I asked for are in, and they work. The root now refuses a script test, and the three blind spots are closed. The merge brings in #33 and nothing else.

Probing the stricter check, I found two more gaps of the same kind. First, a path check written at package level, outside any function, is never looked at. Second, the P5 mistake can be caught after all, by a small rule that finds nothing to complain about in today's tree. Neither gap affects any test in the tree now. Both are cheap to close, and the project's rule is to fix Low findings in the PR.

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #39 |
| Head | `8e77b95a865c42c8b82cc6b9b4a884abc220582c` (merge of `6c949dc` and `0aa4a2b`), tree `1748feefe78cf0ba7196806514302426fbe221e4` |
| Base | `trunk_dev` `0aa4a2b5d8e93a10f65b3bb724b286ee79a0aa7e` (#33) |
| Previous audit target | `0d1de0d` on `400ff7f` (`03-audit.md`) |
| Recipe | v2, source SHA-256 `c08597e2…a1a3ca`, verified before each run |
| Manifest | `7fc8878e687acc69a1ea169ae38c8685f3d8a07a23235b534e7be46cae40aa53`, 73 files, textual diff `3f9fb3bb…68dc`, upstream `origin/trunk_dev` |
| Toolchain | Go 1.26.5, `GOTOOLCHAIN=local`, `env -i`, user `ci` (1500:1600) |

Refs were checked at the start (`ls-remote-open.txt`) and at the end (`ls-remote-close.txt`). Provenance is in `provenance-39d.txt`, and the tree check in `tree-check.txt`.

## Probes (`probes39d.log`, `probes39d-g78.log`)

Each probe ran on a fresh copy of the head, with only the `internal/testutil` tests, as `ci`.

| Probe | Result |
| --- | --- |
| L1: audit 03's root script probe | **refused** by `TestRootKeepsOnlyItsDocsTests` |
| L2: the same file named `zz39d_probe_docs_contract_test.go` | passes, by design (see below) |
| L3: a root non-test file `zz39d_helpers.go` | refused |
| P5: the self-read glob resolved against the root | passes, as the writer says |
| X1: P5's rule (below) added, real tree | passes: 0 hits |
| X2: the same rule, with P5 | **caught** at `remote_alpha_es_service_tls_status_local_boundary_test.go:63` |
| G7: `var plans, _ = os.ReadFile("PLANS.md")` at package level in `scripts/` | passes (A39-3) |
| G8: `var gone = func() bool { _, err := os.Stat(".codex/hooks.json"); return err != nil }()` | passes (A39-3) |
| G5: `var check = func() error { _, err := os.Stat("PLANS.md"); return err }`, called from a test | passes (A39-3) |
| G1: `ioutil.ReadFile("PLANS.md")` | passes (I39-1) |
| G2: `parser.ParseFile(fset, "docs_contract_test.go", nil, 0)` | passes (I39-1) |
| G3: `syscall.Access("PLANS.md", 0)` | passes (I39-1) |
| G4: `os.StartProcess` with no `Dir` | passes (I39-1) |
| G6: `os.Stat(strings.TrimSpace("PLANS.md"))` | passes, as the writer's non-claims say (values from other calls are opaque) |

## Findings

### A39-3 (Low): covered calls outside function declarations are not checked

**What happens.** `repoPathProblems` runs `functionProblems` over `*ast.FuncDecl` bodies only. Package-level `GenDecl` values are read for their bindings, and `valueProblems` reports covered functions used as values. But a covered call that appears in a package-level initializer is never checked:
- a direct call, G7;
- a call inside a function literal, G5 and G8.

G8 is the silent kind that the check's own comment warns about. An absence check of a root path, written relative to `scripts/`, finds nothing there and passes.

**Effect.** No such form is in the tree today. An AST search of the three directories whose tests import `testutil` found no package-level initializer with a function literal or a call of an `os`, `filepath`, `path`, `exec` or `testutil` function (`pkglevel39d.log`). Like A39-2, this is a gap in the guard, not a mistake in the moved tests.

**Suggested fix.** Check package-level initializers with the same rules: walk the values of each package-level `ValueSpec`, including the bodies of the function literals in them. Or refuse covered calls that appear outside a function declaration. Add G7 and G8 to the self-test.

### A39-4 (Low): P5 is catchable

**What the writer says.** The P5 class, "a glob resolved against the root that matches the wrong files there", is out of the check's scope. The one case in the tree is covered by that test's own count floors.

**What I found.** P5 has a static signature. Its value is anchored at the root, and the package directory holds a match for the same value: here both hold `*_test.go`. That makes the value ambiguous, in the same way that the check already treats a partial working-directory path that both folders hold. I added this to `anchoredProblem`:

```go
if !v.partial && l.inPackage(filepath.Clean(v.text)) {
	return fmt.Sprintf("resolves %q against the repository root, though the package directory holds it too", v.text)
}
```

With that rule, the real tree has 0 hits (X1), and P5 is caught at its exact line (X2). The test's count floors catch today's case only because that test happens to have floors. A future self-read anchored at the root may not.

**Suggested fix.** Add the rule, with P5 and one good case in the self-test. A partial anchored value whose known first element both folders hold could get the same treatment, but I did not measure that variant. A test that really means to read root files that the package directory also holds can name the reason in a comment, and the check can allow it explicitly.

### I39-1 (Info): path-taking calls outside the covered list

The check follows `os`, `path`, `path/filepath`, `os/exec` and `testutil`, and refuses renamed imports of those packages. Calls from other packages are not followed: G1 to G4 above. `scripts/` already uses `go/parser.ParseFile` and `syscall.Mkfifo`, with paths from `t.TempDir()` or the package's glob.
- Most of these are reads or creates, which fail loudly or leave a file behind, so they are not silent.
- The silent ones are a `syscall` absence check (G3) and `os.StartProcess` with no `Dir` (G4).

No change is needed for this PR. Adding these to the non-claims would keep the doc honest. So would following `syscall` and `os.StartProcess` if they start to appear.

### I39-2 (Info): the root rule trusts names (L2)

A script test named `*_docs_contract_test.go`, without `remote_alpha` in the name, passes at the root. The writer chose the naming rule on purpose, over an exact list, so that a new docs test needs no edit and parallel PRs don't conflict. A content rule is not simple either: three root tests import `os/exec` today (`artifact_hygiene_test.go`, `codex_agent_configs_docs_contract_test.go` and `docs_contract_test.go`). I accept the choice. Misnaming a file needs intent, and a reviewer can see it.

## What I did not cover

- I did not rerun the whole module. The repair changes no file outside `internal/testutil`'s test binary, and `testutil.go` changed only in its package comment. The merge brings exactly #33's test-only diff in `es/config`, whose tests pass. Audit 03's whole-module comparison at `0d1de0d` stands for everything else, and CI runs the whole module on `8e77b95`.
- I did not rerun the writer's mutants one by one. L1 reproduces their R1, the self-test asserts each A39-2 form at an exact line, and P5 matches.

## Sensitive material

The probes are synthetic. No key, certificate body, token, env file or config file is copied into the evidence. Commit-message trailers and author names are left out. The report and evidence were scanned with the thread's pattern list and a positive control before delivery.
