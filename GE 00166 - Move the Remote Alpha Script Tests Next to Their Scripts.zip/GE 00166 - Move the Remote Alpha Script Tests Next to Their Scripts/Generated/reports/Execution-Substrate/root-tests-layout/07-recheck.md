# ES PR #39, root test files layout: re-check 07 (A39-3, A39-4, I39-1 and the #41 merge)

Written 2026-11-23 from 23:31Z onwards by the independent audit thread "Audit Execution-Substrate PRs", after the coordinator asked for a diff-only re-check. Read-only: nothing was pushed, commented, reviewed or merged. Evidence is in `07-recheck-evidence/` next to this file. My local names carry the tag `39e`.

Subject: the writer's `06-repair.md`, which answers `05-recheck.md`.

## Verdict

**ACCEPT, with no findings left to fix.** A39-3, A39-4 and I39-1 are closed, and the #41 merge is clean. Three Info notes remain, none of which needs a change in this PR.

- **A39-3 is closed.** Package-level `var` initializers are now checked like a function body:
  - a direct call (G7);
  - a function literal called at once (G8) or later (G5);
  - a function literal in a struct field (my H4);
  - a package-level `exec.Command` (my H5).

  All of these are now reported.
- **A39-4 is closed.**
  - The whole-value rule is the one I proposed. It catches P5 at `remote_alpha_es_service_tls_status_local_boundary_test.go:63`.
  - The writer added a partial-value variant: `testutil.Path("internal/" + x)` from `scripts/`.
  - Both rules have 0 hits on today's tree: `TestImportersNameRepositoryPathsFromTheRoot` passes at the head.
- **I39-1 is closed.**
  - `io/ioutil` (G1), `go/parser.ParseFile` with a `nil` source (G2) and the `syscall` path calls (G3) are followed.
  - `os.StartProcess` and the `syscall` process starts are refused (G4).
  - The three packages may not be imported under another name.
- **G6 is a stated non-claim.** Values from other calls are opaque, and the writer's report says so.
- **The scope is as stated.** `dc9fcd0`, whose parent is `8e77b95`, changes only `internal/testutil/testutil_test.go` (+149/−24).
  - `d768e5d` is exactly git's merge of `dc9fcd0` and `725c97a`. Its diff over `dc9fcd0` is byte-identical to #41's diff.
  - `range-diff` shows the six earlier commits unchanged.
  - #41's package does not import `testutil`.
- **The manifest verifies.** I reproduced `3a945a72…ca8b` twice: 73 files, base `725c97a`, and a JSON file identical to the writer's `06-manifest.json`. The staged set equals its paths, and `write-tree` gives `ef3c800`. Against re-check 05's manifest, only the `testutil_test.go` entry differs.
- **Tests and vet pass on a ci copy at `d768e5d`.**
  - The tree check gives 505 entries and 0 differences.
  - `go vet ./...` passes, and so does the darwin/arm64 vet of the root, `scripts` and `internal/testutil`.
  - `gofmt` is clean.
  - The tests of `internal/testutil`, `internal/callerauth`, `es/config` and `internal/contracts/runtimeconfig/v1` pass.
- **CI:** run 45289351814 of `build, vet and test` on `d768e5d` succeeded (check run 138093837159, 23:30Z to 23:59Z). It runs the whole module.

## In plain words

The three gaps from my last check are closed. Path checks written outside any function are now read. The P5 mistake is caught, by my rule and by a stricter variant the writer added. The extra system and parser calls are followed. Neither new rule complains about anything in today's tree. I tried a few more unusual calls, and three still slip through. They are exotic, nothing in the tree uses them, and I don't think they're worth another round.

## Target

| Item | Value |
| --- | --- |
| PR | evo-agi/Execution-Substrate #39 |
| Head | `d768e5d3307b7b883b5023d98f1d06b6a8a06fe2` (merge of `dc9fcd0` and `725c97a`), tree `ef3c80023d64211e430f3b9ab96ea0a470d561c3` |
| Base | `trunk_dev` `725c97a9663df060e49270fce3bc8c904a88986e` (#41) |
| Previous target | `8e77b95` on `0aa4a2b` (`05-recheck.md`) |
| Recipe | v2, source SHA-256 `c08597e2…a1a3ca`, verified before each run |
| Manifest | `3a945a72fce94599b01105304d154b4cdb6c8e61c0e4ec13ffbc5b0f04bdca8b`, 73 files, textual diff `3f9fb3bb…68dc`, upstream `origin/trunk_dev` |
| Toolchain | Go 1.26.5, `GOTOOLCHAIN=local`, `env -i`, user `ci` (1500:1600) |

The evidence files:
- refs at the start and the end: `ls-remote-open.txt`, `ls-remote-close.txt`;
- provenance: `provenance-39e.txt`;
- the tree check: `tree-check.txt`;
- vet and tests: `unit39e.log`.

## Probes (`probes39e.log`)

Re-check 05's probes ran again on fresh copies of the head, with five new ones. Each ran only the `internal/testutil` tests, as `ci`.

| Probe | At `8e77b95` | At `d768e5d` |
| --- | --- | --- |
| L1: audit 03's root script probe | refused | refused |
| L2: the same file named `*_docs_contract_test.go` | passes (I39-2, accepted) | passes (I39-2, accepted) |
| L3: a root non-test file | refused | refused |
| P5: the self-read glob anchored at the root | passes | **caught** at line 63 |
| G1: `ioutil.ReadFile("PLANS.md")` | passes | **caught** |
| G2: `parser.ParseFile(fset, "docs_contract_test.go", nil, 0)` | passes | **caught** |
| G3: `syscall.Access("PLANS.md", 0)` | passes | **caught** |
| G4: `os.StartProcess` | passes | **caught** |
| G5: a package-level function literal, called later | passes | **caught** |
| G7: a package-level `os.ReadFile("PLANS.md")` | passes | **caught** |
| G8: a package-level absence check, called at once | passes | **caught** |
| G6: `os.Stat(strings.TrimSpace("PLANS.md"))` | passes | passes (non-claim) |
| H4: a function literal in a package-level struct field | not run | **caught** |
| H5: a package-level `exec.Command` | not run | **caught** |
| H1: `syscall.Openat(-100, "PLANS.md", …)`, where -100 is `AT_FDCWD` | not run | passes (I39-3) |
| H2: `parser.ParseFile` whose source is a variable holding nil | not run | passes (I39-4) |
| H3: `parser.ParseExprFrom(fset, "PLANS.md", nil, 0)` | not run | passes (I39-4) |

The self-test asserts each new rule at an exact line (`bad.go:93` to `bad.go:107`). Its good snippet shows the allowed forms passing:
- a whole root path under `internal/` that `scripts/` doesn't hold;
- a `ParseFile` with source bytes;
- a `Mkfifo` under a temp directory;
- a package-level self-stat.

## Info notes

### I39-3: the `*at` non-claim is not quite right

The writer's non-claims say the `*at` system calls "resolve a path against a directory descriptor, not the working directory". That holds unless the descriptor is `AT_FDCWD`, and then the relative path resolves against the working directory. H1 shows `syscall.Openat(-100, "PLANS.md", …)` passing.

Nothing in the repository uses `AT_FDCWD` today. The non-claim lives only in the report, not in the code, so this needs no change to the PR. If it matters later, the check could follow a `*at` call whose first argument is `syscall.AT_FDCWD`.

### I39-4: `go/parser` is followed by its common form only

`ParseFile` is followed only when its source argument is the literal `nil`. I think that is the right trade:
- the moved caller-identity check passes source bytes with a repository-relative name, which reads nothing;
- following every non-literal source would report that check.

The cost is a source variable that happens to be nil (H2). `ParseExprFrom`, which also reads when its source is nil, is not followed (H3). Both are unusual in a test. I accept them as approximations of the same kind as G6.

### I39-5: `golang.org/x/sys/unix` is a module dependency

The writer's non-claim is accurate: calls through `golang.org/x/sys/unix` are not seen, and none of the importing packages uses it. The module already requires it, though, for `es/runtimehelper` and two `es/admission` tests. So a test in `scripts/` could import it with no change to `go.mod`. This is noted for completeness, and no change is needed.

## What I did not cover

- I did not rerun the whole module. `dc9fcd0` changes only `internal/testutil`'s test file, and #41 changes only `internal/contracts/runtimeconfig/v1` tests, which pass here. CI runs the whole module.
- I did not rerun the writer's 27 mutants one by one. My probes cover the same forms, and the self-test asserts each rule.

## Sensitive material

The probes are synthetic. No key, certificate body, token, env file or config file is copied into the evidence. Commit-message trailers and author names are left out. The report and evidence were scanned with the thread's pattern list and a positive control before delivery.

## Addendum, 2026-11-24: head `910dc3e` on `trunk_dev` `42db339` (#37 merged in)

Written from 00:08Z onwards, after the coordinator asked for a short check of the writer's `08-provenance-update.md`. Local tag `39f`. Evidence is in `07-recheck-addendum-evidence/`.

**Verdict: ACCEPT.** The #37 merge is clean, and the rename is right. CI: run 45294573761 of `build, vet and test` on `910dc3e` succeeded (check run 138111592631, 00:08Z to 00:37Z). This line was updated after publication: PR #39 merged at 00:37:44Z, and `trunk_dev` is now `4c991ba`.

- **The #37 merge.** `8d70064` is exactly git's merge of `d768e5d` and `42db339`, and its diff over `d768e5d` is byte-identical to #37's diff (`c3d27554…d339`). `range-diff` shows the seven audited commits unchanged.
- **The rename.** `910dc3e` renames `runbook_paths_contract_test.go`, which #37 added at the root, to `runbook_paths_docs_contract_test.go`, at 99% similarity.
  - The one changed line is the test's skip of its own file, which now names the new file.
  - No file in the tree names the old file any more.
  - The test checks docs: Markdown relative links, and `.runbooks/` path mentions. So the `_docs_contract_test.go` name fits the agreed naming, and `TestRootKeepsOnlyItsDocsTests` now accepts the file.
- **The self-skip line is not load-bearing today.** With the line set back to the old name, `TestRunbookPathMentionsExist` still passes (`selfskip39f.log`). So the edit can't have weakened the test, and it keeps the skip pointing at the file itself, as intended.
- **The manifest verifies.** I reproduced `a27ba567…7f61` twice: 75 files, base `42db339`, and a JSON file identical to the writer's `08-manifest.json`. The staged set equals its paths, and `write-tree` gives `ecd898a`. Against re-check 07's manifest:
  - all 73 earlier entries are identical;
  - the two new entries are the old name (`tracked_deleted`) and the new one (`untracked`).
- **Tests and vet pass.** `go vet ./...` passes on a ci copy. In a ci-owned git checkout of `910dc3e`, the whole root package passes (159 of 159 top-level tests), including the three tests that need `git ls-files`. `internal/testutil` and `internal/callerauth` pass too.
  - The tree checks of both copies give 506 entries and 0 differences.
  - In the `git archive` copy, which has no `.git`, those three tests fail at `git ls-files`, as expected (`unit39f.log`, `gitroot39f.log`).
