# ES root test files layout: update 08 (trunk_dev moved to #37 at the merge gate)

Written 2026-11-24 ~00:20Z. PR: https://github.com/evo-agi/Execution-Substrate/pull/39. Nothing was force-pushed, and nothing is merged yet.

## Why the audited head changed

David approved the merge at 00:05Z. At that point PR #39 still matched re-check 07's target (`d768e5d` on `725c97a`), but trunk_dev had moved to `42db339` (#37, runbook renames). ES requires up-to-date branches, so the merge had to take #37 first.

#37 adds a new root test file, `runbook_paths_contract_test.go`. After the merge, PR #39's root layout check refuses it, because a root test file must be named `*_docs_contract_test.go` or be one of the three fixed names. The textual merge is clean. The layout check caught a semantic conflict: this is exactly the drift A39-1 asked to stop.

The file checks docs: Markdown relative links resolve, and every `.runbooks/…/*.md` path mentioned in a tracked file exists. So under the agreed naming (root test files are named by what they check, and docs tests end in `_docs_contract_test.go`), it becomes `runbook_paths_docs_contract_test.go`. Its own name appears once inside it, where `TestRunbookPathMentionsExist` skips its own file, and that line now names the new file. No other file in the repository names it.

## Target identity

| Item | Value |
|---|---|
| Base (`origin/trunk_dev`) | `42db33920d9a402e28f4f7c2344c66d8f1115215` (#37) |
| Tip | `910dc3eb0cfac018f9c57ddfc929906f0d92b092` |
| Tip tree | `ecd898aae71f8c0ef4abbfd9aa034c0b6eea3e0d` |
| Recipe | v2, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before the run) |
| Textual-diff SHA-256 | `93c720e23495bd637b69619f766b3f36e31ec43bcb8c7c3c220386aa5390fdf9` (changed: the base-tracked `runbook_paths_contract_test.go` is now deleted by the patch) |
| Canonical-manifest SHA-256 | `a27ba567e1258ec52d50d7d4fa5b303029c187f1c4679afcc4c5775737ab7f61` |
| File count | 75 |
| Manifest JSON | `08-manifest.json` |

The procedure is as before:
- two runs into a fresh 0700 directory, byte-identical (`08-evidence/`);
- the staged set (`--no-renames`) equals the 75 manifest paths;
- `git status --porcelain` is empty back at the tip.

## What changed since re-check 07's target (`d768e5d`)

| Commit | What it holds |
|---|---|
| `8d70064` Merge trunk_dev (#37) | exactly #37's diff: `git diff --binary d768e5d 8d70064` and `git diff --binary 725c97a 42db339` both hash to `c3d27554…d339` |
| `910dc3e` Name the runbook paths test by the docs-test convention | a rename at 99% similarity, with a 1-line edit (`08-evidence/rename.diff`) |

- `git range-diff 725c97a..d768e5d 42db339..910dc3e` shows the seven earlier commits as `=`.
- Against `06-manifest.json`, all 73 entries are identical. The two new entries are `runbook_paths_contract_test.go` (`tracked_deleted`) and `runbook_paths_docs_contract_test.go` (`untracked`, 8504 bytes, `5ddcbc74…135c`). `head` and the textual diff differ.

## Validation

As the `ci` user, with Go 1.26.5, in a clean clone at `910dc3e`:
- `go vet ./...` passes;
- `go test` passes for the root package as a whole, including the three runbook path tests, `internal/testutil` (including `TestRootKeepsOnlyItsDocsTests`) and `internal/callerauth`.

Before the rename, `TestRootKeepsOnlyItsDocsTests` failed on `runbook_paths_contract_test.go` at `8d70064`.

## For the merge gate

The head changed after the audit, so the work goes back for a diff-only re-check of `910dc3e`, plus a provenance check of the #37 merge. David's go (00:05Z) covers the merge; I'll merge once the re-check accepts, if trunk_dev hasn't moved again.

GitHub CI on `910dc3e`: pending at the time of writing.

## Merged (2026-11-24 00:37Z)

Re-check 07's addendum accepted `910dc3e`. At the gate:
- the PR head was `910dc3e`, the accepted SHA;
- trunk_dev was still `42db339`;
- GitHub CI "build, vet and test" passed on `910dc3e` (run 45294573761, 00:07Z to 00:36Z).

Under David's go (00:05Z), PR #39 was squash-merged into trunk_dev as `4c991ba1c43ac135d9d94853696d14a21523a690` (parent `42db339`).

Post-merge check: all 75 manifest paths match on trunk_dev (blob SHA-256, size and mode, and the deleted path is absent), and the trunk_dev tree equals the audited tip tree `ecd898aa…`.
