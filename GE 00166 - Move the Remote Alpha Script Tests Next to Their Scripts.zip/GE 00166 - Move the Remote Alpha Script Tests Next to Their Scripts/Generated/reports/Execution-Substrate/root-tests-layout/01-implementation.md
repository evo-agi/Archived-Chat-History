# ES root test files layout: implementation report 01

Written 2026-11-23 by the thread "Plan moving ES root test files". Draft PR: https://github.com/evo-agi/Execution-Substrate/pull/39 (test-only; merges after audit and gate under the test/docs/scripts/CI policy).

## Target identity

| Item | Value |
|---|---|
| Repo | evo-agi/Execution-Substrate |
| Branch | `claude/project-thread-wkerpy` |
| Base (`origin/trunk_dev`) | `fdfa3bc67cdedb11f583a19df7036c20c612741f` (#29) |
| Tip | `ca6241977c833fc9b246562e89a2207dd20a1a76` |
| Tip tree | `c0a31e0370dba286518128596db1a20377f3638f` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before the run) |
| Textual-diff SHA-256 | `3f9fb3bb5444fa44e817882d1a61ab096af0d222c1233787497b8182a25b68dc` |
| Canonical-manifest SHA-256 | `7dc5deca5c2ab407d9a75c55d9d1b1f99cbc0b0f7ee3026cc6503d53eb6251fd` |
| File count | 73 |
| Manifest JSON | `01-manifest.json` next to this file (byte-identical to both runs) |

Procedure: HEAD reset `--mixed` to the base with the tip bytes in the working tree, nothing staged, upstream pinned to `origin/trunk_dev` before each run. v2 ran twice into a fresh mode-0700 directory, and the two outputs were byte-identical (`cmp`). `git add -A` then gave a staged path set equal to the manifest's 73 paths. After `git reset --mixed` back to the tip, `git status --porcelain` was empty, so the tip holds the hashed bytes. The run stdout is in `01-evidence/manifest-run{1,2}-stdout.txt`.

The manifest is base-relative, so renames show as `tracked_deleted` plus `untracked`. Git records each moved file as a rename: commit 1 is 31 × R100, and the access-contract rename is R100.

## Agreed layout (David, 21:18Z to 21:24Z)

- `scripts/`: the 31 `remote_alpha_*_test.go` files that run or read the Remote Alpha scripts. Their names and test names are unchanged. There are two new files: `helpers_test.go` (the local helper names, `testPackageDir`) and `testtmpdir_main_test.go`.
- Root, 8 test files: `docs_contract_test.go` (including its 57 Remote Alpha doc tests), `ars_blob_verification_docs_contract_test.go` (from #29), `caller_authentication_docs_contract_test.go`, `codex_agent_configs_docs_contract_test.go`, `outside_observer_docs_contract_test.go`, `artifact_hygiene_test.go`, `testtmpdir_main_test.go`, and `host_access_docs_contract_test.go`, renamed from `remote_alpha_access_contract_test.go`, which checks docs only.
- `internal/callerauth/caller_authentication_contract_test.go`, moved from the root.
- `internal/testutil` (new): `testutil.go` holds helpers that only tests use, `testutil_test.go` holds the checks, and `testtmpdir_main_test.go` the TestMain.

## Commits

1. `6b20d82` Move the Remote Alpha script tests next to their scripts (pure renames). This is 31 × R100.
2. `4ee59c6` Run the script tests from scripts/, naming repository paths from the root:
   - Package clause `scripts_test`.
   - `internal/testutil` provides `Root`, `Path`, `Read`, `Compact`, `Section`, `CompactSection`, `ContainsAll` and `ContainsNone`. The root's helpers in `docs_contract_test.go` are now one-line wrappers with unchanged names and messages. `scripts/helpers_test.go` has the same wrappers, plus `executionSubstrateRepoRoot`, `remoteAlphaOperatorRepoRoot` (was `os.Getwd`) and `repoPath`. The root gets its own `remoteAlphaOperatorScriptPath` because its Remote Alpha doc tests use it.
   - Path fixes in the moved files:
     - the protected-path table, the retired-route helper (`filepath.Abs` replaced by `repoPath`) and the tombstone reads now resolve repository paths from the root;
     - 41 `exec.Command` sites get `Dir = executionSubstrateRepoRoot`, so the commands keep the working directory they had before the move;
     - the two self-reading tests (`SpireFixtureCleanup`, `LocalBoundaryIsInjectedWhole`) read `testPackageDir`.
   - The 11 entries in `.github/ci/environment-only-tests.txt` now say `execution-substrate/scripts`, and their heading now says "scripts package".
3. `af0f786` Move the caller identity check into internal/callerauth. The walk starts at `testutil.Root`, files are read by absolute path, and positions stay repo-relative.
4. `ca62419` Name the Remote Alpha access contract test by what it checks. This is a pure rename.

## The path rule and its checks (`internal/testutil/testutil_test.go`)

- `TestRootIsTheRepositoryRoot`: `Root` is absolute and holds `go.mod`, `AGENTS.md`, `PLANS.md`, `scripts` and the package's own source. `Path` behaves as documented. `Root` comes from `runtime.Caller` and requires `go.mod` to start with `module execution-substrate`. It panics otherwise, for example under `-trimpath`.
- `TestOnlyTestFilesImportTestutil`: no non-test `.go` file anywhere imports the package.
- `TestImportersNameRepositoryPathsFromTheRoot` parses every Go file of every package outside the root whose tests import `testutil`. Today those packages are `scripts` and `internal/callerauth`. The check fails on any of these:
  - A file-system call is given a path whose first element names something at the root but not in the package's own folder, or is ".". The check resolves values through literals, constants, variables, `+`, `filepath.Join`/`path.Join`, range loops over literal maps and slices, struct fields of keyed composite literals (including in range loops), and helper parameters (iterated to a fixpoint).
    - The calls covered are `os.ReadFile`, `os.Stat`, `os.Lstat`, `os.Open`, `os.OpenFile`, `os.Create`, `os.ReadDir`, `os.Readlink`, `os.DirFS`, `os.OpenRoot`, `os.OpenInRoot`, `os.CopyFS`, `os.Remove`, `os.RemoveAll`, `os.Rename`, `os.Link`, the link path of `os.Symlink`, `os.Chmod`, `os.Chown`, `os.Lchown`, `os.Chtimes`, `os.Truncate`, `os.WriteFile`, `os.Mkdir`, `os.MkdirAll`, `os.MkdirTemp`, `os.CreateTemp`, `filepath.Glob`, `filepath.Walk`, `filepath.WalkDir`, `filepath.EvalSymlinks` and `filepath.Abs`.
  - An `exec.Command` or `exec.CommandContext` gets a repository-relative argument, or is not assigned to a variable whose `Dir` is set in the same function.
  - Any call to `os.Chdir`, `os.Getwd` or `.Chdir`.
  - A path resolved against the root (through `testutil.Path`, `testutil.Read`, their wrappers, or `filepath.Join(<root>, …)`) whose first element, or glob, matches nothing at the root.
  - It also fails unless `scripts` was checked with at least 33 Go files, so it cannot pass by finding nothing.
- `TestRepoPathCheckFindsEachKindOfProblem`: a self-test in which every rule fires on a bad snippet at exact lines, and nothing fires on a good snippet.
- Mutation checks, run by hand:
  - Reverting the tombstone fix makes the check report `scripts/remote_alpha_check_es_writable_state_readiness_test.go:57`.
  - Adding a file in `ars/api` that reads `c.URIs` makes the moved caller-identity test report it at `ars/api/zz_mutation_probe.go:5:60`.

## Validation

Every run below used Go 1.26.5 as the unprivileged `ci` user in a ci-owned clone. The command is in `01-evidence/run-tests-as-ci.sh.txt`.

- **Test-by-test comparison at the final base and tip.** The base side was the root, `internal/callerauth` and `internal/testtmpdir` packages at `fdfa3bc`. The tip side was the root, `scripts`, `internal/callerauth` and `internal/testtmpdir` packages at `ca62419`.
  - Both sides give 2,462 results, of which 510 are top-level tests. There are **0 differences**: 2,200 pass and 262 (43 top-level) fail on both sides.
  - The failures are host-only in this sandbox, for example fake-host fixtures that miss host tools and the macOS `ds` account.
  - Output: `01-evidence/compare-base-fdfa3bc-vs-tip-ca62419.txt`. Script: `compare-test-results.py.txt`.
  - The same comparison at the earlier base `76c030f`, before the rebase onto #29, also gave 0 differences across 2,459 results.
- **The three regressions found by the first comparison are fixed:** tombstone reads, the self-reading Spire test, and the fixture-script guard. The fixture-script guard's counts are identical to the base: 141 scripts, 23 shared, 31 whole, 46 probe, 29 with whole, 17 without.
- **Other checks:**
  - `internal/testutil` passes.
  - `go build ./...` passes, and so does `go vet ./...` for linux/amd64 and for darwin/arm64.
  - gofmt (Go 1.26.5) is clean on the changed files.
- **Cache check.** A `scripts` tombstone test ran, then was cached. One byte was appended to `scripts/internal/remote_alpha_plan_old_root_cleanup.sh`, and the test re-ran and failed. After the restore it passed again from the cache. So the go test cache tracks the files these tests read from `scripts/`.
- **CI gate self-test** (`.github/ci/go_test_gate_selftest.py`, Go 1.26.5): the same 29 of 121 cases fail on the base and on the branch in this sandbox. The failures come from the sandbox, and the branch adds none.
- **Whole-module `go test ./...` comparison on base and tip** (`01-evidence/full-module-compare.txt`): 7,007 base results against 7,011 on the branch. The only differences are the 4 new `internal/testutil` tests, which pass. The same 279 results fail on both sides; the ones sampled lack host tools or accounts in this sandbox.

## Non-claims and seams

- **Not run on the Mac or in GitHub CI yet.** CI runs on the draft PR's pushes.
- **The check is a static approximation.**
  - Values produced by other function calls are opaque.
  - Positional (unkeyed) struct literals are not resolved.
  - Names are not scoped, so the check can only report too much, never miss a binding.
  - It covers packages outside the root that import `testutil`. Root tests are not checked, because relative paths are correct there.
  - A glob resolved against the root that matches the wrong files at the root is not caught. `LocalBoundaryIsInjectedWhole`'s `*_test.go` glob was this case, and it was caught by that test's own minimum counts and by the comparison.
- **Open PRs.**
  - #30, #31, #34 and #35 add six Remote Alpha script tests at the root. Each must move them into `scripts/` at its next trunk_dev take-up. Until then they fail to build at the root, because the helpers are gone from there.
  - Edits those PRs make to moved files carry over through rename detection.
  - PR 12 edits `remote_alpha_es_service_tls_status_local_boundary_test.go` and `docs_contract_test.go`, and both carry over the same way.
- **Merge timing:** the coordinator picks the merge moment relative to #29 (merged), #30, #31, #34 and #35.
