# ES root test files layout: repair report 06 (A39-3, A39-4, I39-1)

Written 2026-11-23 ~23:50Z by the thread "Plan moving ES root test files". PR: https://github.com/evo-agi/Execution-Substrate/pull/39. This answers re-check 05 (`05-recheck.md`), which accepted A39-1, A39-2 and the #33 merge and found A39-3 and A39-4 (Low) and I39-1 and I39-2 (Info). Nothing was force-pushed.

## Target identity

| Item | Value |
|---|---|
| Base (`origin/trunk_dev`) | `725c97a9663df060e49270fce3bc8c904a88986e` (#41, `internal/contracts/runtimeconfig/v1` tests only) |
| Tip | `d768e5d3307b7b883b5023d98f1d06b6a8a06fe2` (merge commit, parents `dc9fcd0` and `725c97a`) |
| Tip tree | `ef3c80023d64211e430f3b9ab96ea0a470d561c3` |
| Recipe | v2, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before the run) |
| Textual-diff SHA-256 | `3f9fb3bb5444fa44e817882d1a61ab096af0d222c1233787497b8182a25b68dc` (unchanged, as in 04) |
| Canonical-manifest SHA-256 | `3a945a72fce94599b01105304d154b4cdb6c8e61c0e4ec13ffbc5b0f04bdca8b` |
| File count | 73 |
| Manifest JSON | `06-manifest.json` |

The procedure is the same as in 04:
- two runs into a fresh 0700 directory, byte-identical (`06-evidence/manifest-run{1,2}-stdout.txt`);
- the staged set (`--no-renames`) equals the 73 manifest paths;
- `git status --porcelain` is empty back at the tip.

## What changed since re-check 05's target (`8e77b95`)

| Commit | What it holds |
|---|---|
| `dc9fcd0` Check package-level initializers and root paths the package also holds | A39-3, A39-4, I39-1 |
| `d768e5d` Merge trunk_dev (#41) | `internal/contracts/runtimeconfig/v1` tests only |

For the diff-only check:
- **`dc9fcd0`** changes only `internal/testutil/testutil_test.go`: +149, −24. `git diff 8e77b95 dc9fcd0` is in `06-evidence/repair.diff` (SHA-256 `2f36badd…0f62`).
- **The merge brings exactly #41's diff.** `git diff --binary dc9fcd0 d768e5d` and `git diff --binary 0aa4a2b 725c97a` both hash to `ab3e5901…e703`. That package does not import `testutil`.
- **`git range-diff 0aa4a2b..8e77b95 725c97a..d768e5d`** shows the six earlier commits as `=`.
- **Against `04-manifest.json`,** the 73 paths are the same. Only the `testutil_test.go` entry differs, plus `head`.

## A39-3: package-level initializers are checked

`repoPathProblems` now builds one extra parameterless function whose body holds every package-level `var` declaration, and checks it with the same rules as any function body. The rules therefore apply in three places:
- direct calls in initializers, such as G7: `var plans, _ = os.ReadFile("PLANS.md")`;
- the bodies of function literals in initializers, whether called at once (G8) or later (G5);
- an `exec.Command` assigned to a package-level variable. This one is reported, because a function cannot set the `Dir` of a package-level command in the same body.

The self-test adds G7 and G8 as bad cases, and a package-level function literal that stats a file of the package directory as a good case.

The value-use pass also tracks shadowing per top-level declaration now. Before, the names local to the last function declaration it had seen leaked into the package-level declarations after it.

## A39-4: a root-anchored path that the package directory also holds

`anchoredProblem` now reports a root-anchored value that the package directory also holds:
- **A whole value** is reported when the package directory holds the same path or a match for the same pattern. This is the auditor's rule, and it catches P5 (`*_test.go`).
- **A partial value** is reported when the package directory holds its first element. This is the variant the auditor did not measure. An example is `testutil.Path("internal/" + x)`.

Both variants have 0 hits on the real tree. A whole root path under `internal/` that `scripts/` doesn't hold still passes, for example `internal/callerauth/callerauth.go`; the self-test shows this.

I added no allow mechanism. Nothing in the tree needs one, and a future test that really means such a path would have to add it to the check, where it is reviewed.

## I39-1: path-taking calls outside the covered list

I followed these instead of only documenting them, so that no gap is left on trust:
- **`io/ioutil`:** `ReadFile`, `WriteFile`, `ReadDir`, `TempDir` and `TempFile` (G1).
- **`go/parser`:** `ParseFile`, only when its source argument is `nil`, because otherwise the file name only labels positions (G2). `ParseDir` is followed too. The moved caller-identity check passes source bytes with a repository-relative name, and stays clean.
- **`syscall` path calls:** `Access`, `Stat`, `Lstat`, `Statfs`, `Open`, `Creat`, `Mkdir`, `Mkfifo`, `Mknod`, `Unlink`, `Rmdir`, `Rename`, `Link`, `Symlink` (link path), `Readlink`, `Chmod`, `Chown`, `Lchown`, `Truncate`, `Utimes`, `UtimesNano` and `Chroot` (G3). The existing `syscall.Mkfifo` calls in `scripts/` use temp paths and pass.
- **Refused outright:**
  - `syscall.Chdir`, `syscall.Fchdir` and `syscall.Getwd`;
  - `os.StartProcess`, `syscall.ForkExec`, `syscall.StartProcess` and `syscall.Exec`, which start a process whose working directory the check cannot see (G4).
- **Imports:** `io/ioutil`, `go/parser` and `syscall` joined the imports that may not be renamed.

I39-2, the root rule's trust in names, is unchanged, as the re-check accepts.

## Mutants (`06-evidence/mutants.py.txt`, `mutants.log`)

All of 04's mutants run again, with the re-check's probes added. 26 of 27 are caught:

| Mutant | Result |
|---|---|
| P1 to P4e, P6 to P9, R1 to R3 (from 04) | caught, as before |
| **P5:** self-read glob resolved against the root | **caught** at `remote_alpha_es_service_tls_status_local_boundary_test.go:63` ("though the package directory holds it too"), the line the auditor's X2 named |
| **G7:** package-level `os.ReadFile("PLANS.md")` | **caught** |
| **G8:** package-level absence check in a function literal called at once | **caught** |
| **G5:** package-level function literal called from a test | **caught** |
| G1: `ioutil.ReadFile` | caught |
| G2: `parser.ParseFile(…, "docs_contract_test.go", nil, 0)` | caught |
| G3: `syscall.Access` absence check | caught |
| G4: `os.StartProcess` | caught |
| G6: `os.Stat(strings.TrimSpace("PLANS.md"))` | passes: values from other calls are opaque (non-claim) |

**Checker mutants:** `TestRepoPathCheckFindsEachKindOfProblem` fails when any one of these is switched off:
- the initializer pass;
- the whole-value ambiguous-anchor rule;
- the process-start refusal.

## Validation

- `go vet ./...` passes for linux/amd64, and `go vet` of the root, `scripts` and `internal/testutil` passes for darwin/arm64. gofmt is clean.
- As the `ci` user, with Go 1.26.5, in a clean clone at `d768e5d`:
  - `go vet ./...` passes;
  - `go test` passes on `internal/testutil`, `internal/callerauth`, `es/config` and `internal/contracts/runtimeconfig/v1`.
- The root and `scripts` tests were not rerun. `dc9fcd0` changes no file they compile, and the #41 merge touches neither package. GitHub CI runs the whole module on the new head.

## Non-claims and seams

- **The check is still a static approximation.** Values that come from other calls are opaque (G6). Positional struct literals are not resolved. Names are not scoped, so the check can only report too much.
- **Calls from packages the check does not follow are not seen,** for example `golang.org/x/sys/unix`. None of them is used in the importing packages today.
- **The `*at` system calls are not followed,** for example `syscall.Openat`. They resolve a path against a directory descriptor, not the working directory.
- The root rule trusts file names (I39-2, accepted).
- **GitHub CI on `d768e5d`:** "build, vet and test" passed (run https://github.com/evo-agi/Execution-Substrate/actions/runs/45289351814, 23:30Z to 23:58Z).

Under the protocol (§ branch updates), this calls for a diff-only re-check of `dc9fcd0`, plus a provenance check of the #41 merge.
