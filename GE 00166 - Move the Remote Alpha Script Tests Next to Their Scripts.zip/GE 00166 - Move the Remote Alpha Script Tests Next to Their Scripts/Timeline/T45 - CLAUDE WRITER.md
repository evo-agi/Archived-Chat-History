PR #39 has a new head after trunk_dev moved. #36, the README rewrite, landed, so I merged it into the branch. There were no conflicts and the patch itself didn't change.

- **New target:** head `0d1de0d`, base `400ff7f`, tree `bfde9b4`.
- **Manifest:** v2 `8ad0e5fa1193c38d4e625c5363c7268cb0bd093b658d16eb4844fc6beb719000`, 73 files. I took it twice and both runs were byte-identical.
- **What changed:** only the base. All 73 file entries are byte-identical to the first manifest, and the textual diff hash is unchanged.
- **Whole-module run:** I ran `go test ./...` on base and branch. The only differences are the 4 new `internal/testutil` checks, and all of them pass.
- **Still running:** GitHub CI on the PR.
