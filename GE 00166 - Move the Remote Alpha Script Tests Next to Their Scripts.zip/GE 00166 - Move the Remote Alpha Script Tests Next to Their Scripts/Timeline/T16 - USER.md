> Fair point. I've switched it to conformance/, because those files check that the scripts, docs and repo-wide rules match…


That's too hasty.

I think we should add another rule: when debating a name, we should discuss and come to a consensus, instead of jumping to the conclusion after addressing a rebuttal.
