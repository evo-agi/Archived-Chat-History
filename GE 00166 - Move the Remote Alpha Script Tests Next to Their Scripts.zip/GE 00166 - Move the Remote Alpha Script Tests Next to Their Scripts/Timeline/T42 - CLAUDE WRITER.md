Draft PR #39 is open and ready for the audit. In it, the 31 Remote Alpha script tests now sit in `scripts/` next to their scripts. Before and after give the same results, test by test.

- **Head:** `ca62419`. Base is `fdfa3bc`; I rebased onto trunk_dev after #29 landed. Tree is `c0a31e0`.
- **Manifest:** v2 `7dc5deca5c2ab407d9a75c55d9d1b1f99cbc0b0f7ee3026cc6503d53eb6251fd`, 73 files. I took it twice and both runs were byte-identical.
- **Commits:**
  1. Pure renames.
  2. Path fixes, with the new test-only package `internal/testutil` and its missed-path check.
  3. The caller-identity check moves into `internal/callerauth`.
  4. `remote_alpha_access_contract_test.go` becomes `host_access_docs_contract_test.go`.
- **Results:** 2,462 results on both sides, with 0 differences. 262 of them fail on the base too, because this cloud machine lacks host tools and accounts they need.
- **Not done yet:** the full `go test ./...` comparison on base and branch is still running. Its result will go into the report.

#30, #31, #34 and #35 each add root script tests that must move into `scripts/` at their next sync. Until then they fail to build, so none can be missed. I'm watching the PR and will keep it current with trunk_dev.
