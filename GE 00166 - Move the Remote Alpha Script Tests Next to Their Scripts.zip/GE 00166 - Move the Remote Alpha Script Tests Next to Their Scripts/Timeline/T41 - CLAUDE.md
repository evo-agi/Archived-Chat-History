It does hold only test helpers, so `internal/testutil` it is. All the names are settled now, and the PR is being built. It merges after audit, at a quiet moment for the other open PRs.
