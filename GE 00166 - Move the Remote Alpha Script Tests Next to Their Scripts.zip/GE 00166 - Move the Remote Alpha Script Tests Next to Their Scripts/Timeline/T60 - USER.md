Quick question, do we really need scripts in `scripts/internal/` in ES? Can we not move them to `scripts/` or merge them with existing scripts in `scripts/`?
