The test-file cleanup is up as [PR 39](https://github.com/evo-agi/Execution-Substrate/pull/39) and is now in audit. Nothing needs you.

STATUS: WORKING
