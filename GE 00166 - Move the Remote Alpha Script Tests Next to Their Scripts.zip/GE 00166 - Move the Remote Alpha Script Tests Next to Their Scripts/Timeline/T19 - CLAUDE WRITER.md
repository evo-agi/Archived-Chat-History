Agreed, David, that was too quick. Nothing is pushed, and the code no longer depends on the folder name, so any name below is a one-step change. I've also saved the "names get settled by consensus" rule.

Here are four names for the 39 files. As a reminder, they're 32 tests that run the Remote Alpha scripts against fakes, 4 docs-contract tests, and 3 repo-wide checks. Unit and package tests stay next to their code under any of these.

1. **`repotests/`**: tests of the repository as a whole, not of one Go package. It covers all three kinds and clashes with nothing. The plural matters: Go reads a singular `xxxtest` folder as a test-helper library (`httptest`, and ES's own `callerauthtest`). Its weakness is that "repo" is broad.
2. **`contracttests/`**: tests that hold the repo to its written contracts. It matches the docs' own term "docs-contract tests" (`docs_contract_test.go`). But ES already has `internal/contracts` (Go contract types for evidence and runtime config), so it could read as "tests for those packages". It also fits the 32 script tests less well, since those test behaviour.
3. **`conformance/`**: checks that scripts, docs and rules conform to their specs. ES already uses "conformance" for the reliable-submit store's backend conformance suite (`store_conformance_test.go`, about 48 mentions), so the words would mean two different things. It also fits the script tests loosely.
4. **`repochecks/`**: checks on the repository: scripts, docs, layout. No clash, but it doesn't say "tests", so an outsider might expect lint config or CI scripts.

My recommendation is **`repotests/`**: it is the only one that describes all 39 files accurately and clashes with nothing. Which do you prefer, or would you like other options?

STATUS: NEEDS DAVID (pick the folder name; the rest of the PR keeps going meanwhile)
