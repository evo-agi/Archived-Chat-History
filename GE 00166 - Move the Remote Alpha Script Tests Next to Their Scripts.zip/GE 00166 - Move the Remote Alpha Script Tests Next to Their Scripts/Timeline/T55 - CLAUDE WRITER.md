A39-3 and A39-4 are fixed on PR #39, and it's ready for the diff-only check. New target: head `d768e5d`, base `725c97a` (#41), tree `ef3c800`, manifest v2 `3a945a72…ca8b`, 73 files. The details are in [06-repair.md](/mnt/project-files/reports/Execution-Substrate/root-tests-layout/06-repair.md).

- **A39-3:** package-level variable initializers are now checked with the same rules, including function literals. G5, G7 and G8 are caught.
- **A39-4:** I added the auditor's rule, plus the partial-value variant. Both have 0 hits in the tree, and P5 is now caught at its exact line.
- **I39-1:** I followed the extra calls rather than only listing them as non-claims: `io/ioutil`, `go/parser`, the `syscall` path calls, and a refusal of process starts outside `os/exec`. G1 to G4 are caught.

Of 27 mutants, 26 are caught. G6 passes, because values from other calls are opaque, which is a stated non-claim. The repair only touches `testutil_test.go`, and the merge brings exactly #41's diff. GitHub CI is still running on the new head.
