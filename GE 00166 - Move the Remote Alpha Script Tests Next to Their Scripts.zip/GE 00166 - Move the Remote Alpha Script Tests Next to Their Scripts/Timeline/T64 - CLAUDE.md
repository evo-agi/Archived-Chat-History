On `scripts/internal/`: I'd keep it. It's a deliberate split. Top-level `scripts/` holds the commands you run, and `internal/` holds the shared libraries and implementations they load. Three of those libraries are each used by 6 to 17 commands, so merging them would copy that code everywhere. Moving the folder breaks about 90 test lines, 59 doc lines and the copy-to-host rules, and conflicts with 4 open PRs. The one cheap cleanup is deleting 6 retired commands that only print a refusal. That would be a small later PR, if you want it.

Separately, the test-file move (PR #39) passed every check and needs your go to merge.

STATUS: NEEDS YOU (merge go for #39)
