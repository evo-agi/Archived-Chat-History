Decision in Governed Execution: Squash-merge PR #39 (root test files layout) into trunk_dev now? (Sent: Merge PR #39 into trunk_dev)
