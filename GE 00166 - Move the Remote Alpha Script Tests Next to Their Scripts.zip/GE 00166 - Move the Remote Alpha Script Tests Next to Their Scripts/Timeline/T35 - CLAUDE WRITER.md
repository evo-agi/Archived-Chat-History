Putting the script tests in `scripts/` works. I found nothing that blocks it.

**What I checked**
- **Go:** `scripts/` becomes a Go package that holds only tests, the same as the repo root today. `go build ./...` and `go vet ./...` handle that fine.
- **Script SHA-256 pins:** not affected. Each pin covers one script, and no script changes.
- **Other repos:** IM calls no ES script by path. MA uses `scripts/remote_alpha_operator.sh`, which doesn't move.
- **Copying to the box:** the staging scripts copy named files into a fresh folder, never the whole of `scripts/`, so test files never reach the box.
- **CI:** there is no shellcheck step and nothing that lists `scripts/`. Only the 11 entries in the list of tests CI skips change package.
- **Cost for outsiders:** `scripts/` grows from 46 entries to 79. Each test sorts next to its script (`remote_alpha_operator.sh`, `remote_alpha_operator_test.go`), which is Go's usual pairing.
- **Open PRs:** #30, #31, #34 and #35 add 6 script tests at the root. Each moves them at its next sync with trunk_dev. Until then those files fail loudly, so none can be missed.

**One correction:** `remote_alpha_access_contract_test.go` only checks docs. By your rule it stays at the root, so 31 files go to `scripts/`, not 32.

**Proposed names**

*Root, 7 files:*
- Unchanged: `docs_contract_test.go` (all 57 Remote Alpha doc tests stay in it), `caller_authentication_docs_contract_test.go`, `codex_agent_configs_docs_contract_test.go`, `outside_observer_docs_contract_test.go`, `testtmpdir_main_test.go`.
- `artifact_hygiene_test.go`: I'd keep this name over `hygiene_test.go`, because it matches the doc it checks, `.docs/system_overview/artifact_hygiene.md`.
- `remote_alpha_access_contract_test.go`: this one needs a new name. I'd use `host_access_docs_contract_test.go`, which follows the `<subject>_docs_contract_test.go` pattern. #29's new `ars_blob_verification_docs_contract_test.go` uses that pattern too. The other option is to merge it into `docs_contract_test.go`.

*`scripts/`:*
- The 31 `remote_alpha_*_test.go` files keep their names. 22 match their script's name exactly. The rest name a route or a part of the TLS status checker.
- Plus `testtmpdir_main_test.go` and one small helpers file. For that file I'd use `repository_test.go`; `helpers_test.go` is the other option.

*Elsewhere:*
- `internal/callerauth/caller_authentication_contract_test.go` keeps its name.
- The shared helper package is still needed, because both the root and `scripts/` use the doc helpers. I suggested `internal/repotest` for it.

Still open: the access-contract file, the helpers file, and `internal/repotest`. Nothing is pushed until these are agreed.
