> Thanks. Taking those in order:


For 3, if the dir contains just test-specific utils, then `testutil`.
