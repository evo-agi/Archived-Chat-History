> You're right, I jumped. The rule is now in the procedures file: names get discussed to agreement before they're adopted.…


Hmm... I don't really know, but, if I have to guess, since most of them are remote alpha, we can just say `remote-alpha`? Or `.remote-alpha`, if we can put a period in front?
