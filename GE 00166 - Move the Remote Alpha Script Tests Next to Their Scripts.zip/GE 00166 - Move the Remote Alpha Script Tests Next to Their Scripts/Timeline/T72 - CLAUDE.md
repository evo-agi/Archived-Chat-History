Thanks. I'm watching #43's CI. If a README test objects, we'll fix the test, not your text. To keep re-checks down, the best order is the test-file move (#39) first, which is at its final gate, then your #43. I'll tell you when it's your turn to merge.

STATUS: WORKING
