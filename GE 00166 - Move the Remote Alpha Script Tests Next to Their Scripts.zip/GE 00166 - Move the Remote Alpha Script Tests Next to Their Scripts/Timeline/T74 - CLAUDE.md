The test-file cleanup (PR #39) is merged, so ES's root now holds only the doc tests, and script tests sit next to their scripts. Your README PR #43 is next. I'll ping you once it's updated and CI is green.

STATUS: WORKING
