Good thought, since 32 of the 39 are Remote Alpha script tests. Some things to weigh:

- **A leading dot won't work here.** Go's `./...` skips folders starting with a dot, so CI would silently stop running these tests. That's exactly the kind of quiet gap we want to avoid.
- **remote-alpha/ would mislabel 7 files.** Those are the docs-contract tests and repo-wide checks, which aren't Remote Alpha.
- **The name would age.** Remote Alpha is a phase name, so it would turn stale once the phase moves on.

A middle ground: split by purpose. The 32 go in `remotealpha/` (Go folder names avoid hyphens), and the 7 go in `repotests/`. That's two clear names instead of one broad one. Does that appeal, or do you lean toward a single folder?
