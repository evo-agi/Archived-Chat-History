Asked the project to choose an option

Squash-merge PR #39 (root test files layout) into trunk_dev now?

1. Merge PR #39 into trunk_dev (recommended): I squash-merge the audited head d768e5d into trunk_dev, then check that trunk_dev holds the audited bytes for all 73 files.
2. Hold the merge: PR #39 stays open and ready; I keep it current with trunk_dev until you say go.

Why recommended: Test-only change, audit ACCEPT with no findings left (07-recheck), CI green on d768e5d, trunk_dev unchanged since the audit base 725c97a.
