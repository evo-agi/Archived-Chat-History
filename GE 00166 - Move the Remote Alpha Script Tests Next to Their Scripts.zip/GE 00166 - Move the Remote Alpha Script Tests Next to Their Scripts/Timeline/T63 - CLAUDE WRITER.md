**PR #39 needs David's go to merge.** It passed the merge gate: the PR head is the audited `d768e5d`, trunk_dev is still `725c97a`, CI is green and the PR is marked ready. But the merge tool refused without his word, so I posted a card above. One tap and I'll merge it and check trunk_dev holds the audited bytes.

**On `scripts/internal/`: I recommend keeping it.** It's a deliberate split, not leftovers. The docs define top-level `scripts/*.sh` as the commands an operator runs, and `scripts/internal/` as the helpers those commands load, which are never run directly. What's in it (34 files):
- **19 implementations** whose same-name file in `scripts/` is a 6-line wrapper that loads it and calls its main function. 6 of these pairs are retired commands that only print a refusal.
- **3 shared libraries:** `bringup.sh`, used by 17 commands; `control_plane.sh`, used by 7; and `operator_failures.sh`, used by 6.
- **12 smaller helpers:** the Python TLS collectors, the pinned SPIRE download, and the supported-local proof helpers. Each is used by one to three commands.

**Why moving costs more than it gains:**
- **Remote hosts:** the copy-to-host rules are written in these terms, for example "copy only this wrapper and its internal helper" or "never copy `scripts/internal/*`".
- **Tests:** about 90 Go test lines name the path. `docs_contract_test.go` checks exact doc wording in 44 places, and there are 25 in `scripts/` tests and 23 in `es/app` tests.
- **Docs and code:** 59 doc lines name it, and so do 26 places in `remote_alpha_operator.sh`, including operator help text.
- **Rules:** AGENTS.md needs a doc-first change for a documented convention like this one.
- **Open PRs:** #30, #31, #34 and #35 edit these files, so they would all conflict.

Moving the files up would mix libraries in with the commands. Merging them would copy the shared libraries into many scripts. If David just wants fewer files, the only candidates are the 6 retired-command pairs, and that would be its own small PR.
