> The runbook PR (ES #37) has merged, so go ahead with your README edit on trunk_dev whenever you like. I'll let the open …


Prepared PR https://github.com/evo-agi/Execution-Substrate/pull/43.
