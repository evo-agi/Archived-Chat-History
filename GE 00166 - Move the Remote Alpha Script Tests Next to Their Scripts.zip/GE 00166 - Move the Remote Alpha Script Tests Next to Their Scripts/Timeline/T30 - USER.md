> The per-file answer for the other 7:


Move 1 makes sense.

Hmm... On second thought, can we split remote alpha doc tests? I mean, we can get rid of the label "remote alpha" and just make them doc tests. Similarly, the ones at project-level can be docs_contract_test.go, hygiene_test.go, etc.
