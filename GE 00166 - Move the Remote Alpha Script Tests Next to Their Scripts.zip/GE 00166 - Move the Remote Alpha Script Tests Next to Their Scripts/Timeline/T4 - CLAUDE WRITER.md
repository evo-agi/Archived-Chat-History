The rename is viable, but I recommend against it. Only ES has such a folder. MA, IM, Coordinator and Bridge-Core have no `scripts/` or `script/` on any branch.

**Viable:** I tried it on a scratch copy of ES. It touched 994 lines in 127 files. The test packages that use the scripts came back to the same results as before, apart from two tests that check file fingerprints (SHA-256) on purpose. A quick find-and-replace isn't enough, though: my first attempt broke 33 tests. Nothing was pushed.

**Why I'd skip it:**
- **The tidiness gain is small.** GitHub still lists the folder. Most of the clutter in the ES root is 39 test files sitting at the top level.
- **It hides how you run ES.** These scripts are the commands an operator starts ES with (`01_bringup.sh`), and the new README for newcomers points at them. After cloning, `ls`, Finder, `rg` and shell wildcards all skip dot-folders.
- **It reaches outside ES.** IM's code calls ES scripts by path, and IM's own tests check the old path. So IM would keep passing its tests while its real runs fail. MA has the same problem until its PR #2 merges.
- **The fingerprint checks would all need updating.** 58 scripts change content, so every SHA-256 check on them breaks, including the one in the recovery runbook. Each failure is safe (it refuses to run), but each needs a careful update.
- **It lands on live work.** All 9 open ES PRs would have to take it up, and 5 of them need hand fixes and a fresh audit.

If you still want it, the report has a safe order. In short: wait until MA PR #2 has merged and no open ES PR touches the folder, then do one ES PR plus a same-day IM PR. Report: [scripts-dir-rename.md](/mnt/project-files/reports/design/scripts-dir-rename.md). The evidence files are in the folder next to it.

STATUS: NEEDS DAVID (yes or no on the rename; my recommendation is no)
