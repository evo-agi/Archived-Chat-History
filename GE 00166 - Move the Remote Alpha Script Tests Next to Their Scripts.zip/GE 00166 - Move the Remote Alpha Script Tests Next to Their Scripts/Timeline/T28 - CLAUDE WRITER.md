Of the other 7 files, one has a better home elsewhere, one should be split, and the other five are best left at the root.

- **caller_authentication_contract** (1 test: nothing outside `internal/callerauth` reads caller certificates) → move it to `internal/callerauth`, the package whose rule it guards. Cost: that package's tests would re-run whenever any Go file changes. They take 0.06 s.
- **docs_contract** (143 tests) → split it. 57 of its tests check Remote Alpha docs against the Remote Alpha scripts, so they go to `remotealpha/`. The other 86 check PLANS.md, AGENTS.md and .docs/ and stay at the root.
- **These five stay at the root:**
  - **caller_authentication_docs_contract** only reads .docs.
  - **codex_agent_configs** checks `.codex/`. Go can't treat a folder whose name starts with a dot as a package.
  - **outside_observer**: most of its 164 lines are docs checks. Splitting it isn't worth it.
  - **artifact_hygiene** covers the whole repo.
  - **testtmpdir_main** is the setup file every test package has. `remotealpha/` gets its own copy.

None of the 7 belong in `scripts/` or `cmd/`. None tests a single command or script, so they would only add Go files to the scripts folder.

Either way:
1. Files that stay at the root need no path changes, because `go test` already runs from there. Only the files we move need the path fix and the missed-path check. That rules out the test cache problem.
2. `remotealpha/` needs 9 doc helpers (`mustRead`, `assertContainsAll`…) that the root also uses. That's true whatever we decide about the 7. Copying them lets the copies drift apart, so the right fix is one small test-only helper package under `internal/`, like `internal/testtmpdir`. That needs a name. My pick is `internal/repotest`, which follows Go's `httptest` pattern. Other options: `internal/doccheck` (too narrow, since it also finds the repo root) or `internal/testsupport` (says little).

The root ends up with 6 test files instead of 39. Nothing is pushed until the helper name is agreed.
