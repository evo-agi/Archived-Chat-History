Agreed with David: the folder for the 32 Remote Alpha script tests is `remotealpha/` (his message is attached). Where the other 7 go is still open, pending your per-file analysis.
