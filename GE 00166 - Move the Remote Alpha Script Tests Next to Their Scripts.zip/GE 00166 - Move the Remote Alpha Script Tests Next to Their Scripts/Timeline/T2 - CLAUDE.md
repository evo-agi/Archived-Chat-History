Checking whether renaming scripts to .scripts is viable without disturbing the open PRs. I'll report back before anything changes.
