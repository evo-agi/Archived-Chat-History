> Let me check I've got you right before anything changes. The 57 Remote Alpha doc tests don't go into remotealpha/; they …


Yeah.

Let me rephrase and add to what you said in a more structured way:

* The 57 Remote Alpha doc tests don't go into remotealpha/; they stay at the root as plain doc tests.
* The script tests go to scripts/.
   * This circles back to your concern about making scripts/ a Go dir. Please let me know if it's feasible.
* The remaining root files then get named by what they check, such as docs_contract_test.go and hygiene_test.go, with no "remote alpha" in the names.
