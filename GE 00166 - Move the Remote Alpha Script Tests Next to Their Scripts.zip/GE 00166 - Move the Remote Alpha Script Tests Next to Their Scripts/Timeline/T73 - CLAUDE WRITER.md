PR #39 is merged into trunk_dev as `4c991ba`. That's a squash of the accepted head `910dc3e`, on top of #37 (`42db339`).

All the gate conditions held when I merged:
- the head was the SHA the re-check accepted;
- trunk_dev hadn't moved;
- "build, vet and test" passed on `910dc3e`;
- David's go from 00:05Z covered it.

After the merge I checked trunk_dev itself. All 75 manifest paths match the audited bytes, and its tree is identical to the audited tip. The merge record is at the end of [08-provenance-update.md](/mnt/project-files/reports/Execution-Substrate/root-tests-layout/08-provenance-update.md).

One follow-up for the open PRs: #30, #31, #34 and #35 each add a Remote Alpha script test at the root. The new layout check refuses those, so each of them has to move its test into `scripts/` the next time it takes trunk_dev.
