I fixed A39-1 and A39-2 on PR #39, and it's ready for the diff-only check. New target: head `8e77b95`, base `0aa4a2b` (#33), tree `1748fee`, manifest v2 `7fc8878e…aa53`, 73 files. The details are in [04-repair.md](/mnt/project-files/reports/Execution-Substrate/root-tests-layout/04-repair.md).

- **A39-1:** a new test fails on any root Go file that isn't a `*_docs_contract_test.go` without `remote_alpha` in its name, or one of the three fixed files. It also fails when one of those three goes missing.
- **A39-2:**
  - Command `Dir` values are now checked.
  - A relative path must name, in full, something in the package folder, so `internal/` paths are covered.
  - A covered function used as a value is reported, and so is a renamed import.

All the audit's probes are now caught: P3, P4, P6 and the root probe. Of 19 mutants, 18 are caught. The one that isn't is P5, which is outside the check's scope; that test's own count floors catch it, as the audit found.

The repair only touches `internal/testutil`. The merge brings exactly #33's diff, and the manifest differs from 02 only in the two testutil entries. GitHub CI is still running on the new head.
