Noted: `scripts/` stays as it is. I recorded your decision at the top of the rename report. The proposal for the test files is ready: move all 39 root test files into one new `tests/` folder. A plain `ls` of the ES root then shows 15 entries instead of 53.

**On Go's convention:** yes, Go keeps a package's tests in the same folder as its code, and ES already does that 150 times (`es/app`, `es/admission`, and so on). Those stay where they are. The 39 root files are different: the root has no Go code at all. They test the shell scripts, the docs and repo-wide rules, and they sit at the root only because file paths like `PLANS.md` happen to work from there.

**It's safe.** In a trial move with three one-line helper changes, 2,241 of 2,263 tests gave the same result as before. The other 22 fail loudly, and each is a known file path to fix.

**One trap.** The quick fix of switching the working folder back to the root when tests start makes Go reuse a cached PASS after a doc or script changes. I reproduced it. The proposal fixes paths properly instead, and adds a check that catches any path it misses.

**Open PRs:** none has to land first. Edits to the moved files carry over cleanly. Five PRs (#29, #30, #31, #34, #35) add new root test files, 7 in total. Each moves its files when it next updates from trunk_dev, which it has to do anyway. Best timing is when none of those five is mid-audit, red-team or box run. No PR has been opened.

[es-root-tests-layout.md](/mnt/project-files/reports/design/es-root-tests-layout.md) · [scripts-dir-rename.md](/mnt/project-files/reports/design/scripts-dir-rename.md)

STATUS: READY (proposal done; a go from you or the coordinator starts the PR)
