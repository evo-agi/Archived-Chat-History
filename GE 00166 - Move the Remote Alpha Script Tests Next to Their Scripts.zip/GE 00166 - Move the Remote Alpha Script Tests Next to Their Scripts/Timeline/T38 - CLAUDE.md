Thanks. Taking those in order:

1. **Subject prefix:** noted, it becomes `host_access_docs_contract_test.go`.
2. **"Sure":** I read that as my pick, `helpers_test.go`. Tell me if you meant `repository_test.go`.
3. **`test` as a name:** the folder isn't special. Go only treats `testdata` specially, so `internal/test` would work. The `xxxtest` style is just Go convention, as in the standard library's `httptest`, and it tells readers "helpers for testing xxx". A bare `test` says less and reads a bit oddly in code, as in `test.MustRead(...)`. Another common choice is `internal/testutil`.

Which do you prefer: `test`, `testutil` or `repotest`?
