> The test cleanup plan is ready and safe: all 39 root test files move into one tests/ folder, so the ES root shows 15 ent…


Can we pick something other than `tests/`? It'd imply all tests should go there, but that's not the case here. We still colocate tests and source code.
