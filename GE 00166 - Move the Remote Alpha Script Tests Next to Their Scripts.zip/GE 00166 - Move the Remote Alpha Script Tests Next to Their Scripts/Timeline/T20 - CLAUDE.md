Here are four candidate names for the folder. It would hold 32 tests that run the shell scripts against fakes, 4 docs-contract tests and 3 repo-wide checks. Normal tests stay next to their code either way.

1. **repotests/**: tests of the repository as a whole. It fits all 39 files and clashes with nothing, though "repo" is broad.
2. **contracttests/**: matches the docs' own term, but ES already has a contracts package, and it fits the script tests less well.
3. **conformance/**: ES already uses "conformance" for a storage test suite, so the word would mean two things.
4. **repochecks/**: no clash, but it doesn't say "tests", so it could read as lint or CI config.

My recommendation is **repotests/**. What do you think, or should I look for other options?
