PR #39 re-check: **ACCEPT, with no findings left to fix.** The report is [07-recheck.md](/mnt/project-files/reports/Execution-Substrate/root-tests-layout/07-recheck.md).

- **A39-3, A39-4 and I39-1 are closed.** Package-level initializers are now checked. P5 is caught by my rule and by the writer's stricter variant. The extra parser, ioutil and syscall calls are followed. All my earlier probes and five new ones are caught, and neither new rule flags anything in today's tree.
- **Scope:** the repair touches only `internal/testutil`, and the merge is exactly #41.
- **Manifest and CI:** the manifest 3a945a72…ca8b verifies, and CI is green on d768e5d.

Three exotic calls still slip through. One is an `Openat` against the current directory; the writer's note says those calls never use it, which isn't quite right. The other two are unusual parser forms. Nothing in the tree uses any of them, so I've left them as Info notes.

STATUS: READY
