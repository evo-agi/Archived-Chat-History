> Splitting the 7 by subject could work. Before deciding, I'm checking each file: where it would naturally live, and wheth…


`remotealpha` is fine.
