The per-file answer for the other 7:

- **Move 1:** the caller-certificate rule goes into `internal/callerauth`, the package it guards.
- **Split 1:** of the 143 docs-contract tests, the 57 that check Remote Alpha docs go to `remotealpha/`, and the rest stay at the root.
- **Keep 5 at the root:** they check repo-wide docs and hygiene, or `.codex/`, which Go can't treat as a package. None belongs in scripts/ or cmd/.

The root drops from 39 test files to 6.

One more name to agree on: both places need shared helpers like "read a doc file". To avoid two drifting copies, they'd live in a small test-only helper package. The suggestion is `internal/repotest`, following Go's `httptest` pattern. Alternatives are `internal/doccheck` (too narrow) or `internal/testsupport` (vague). Does the split work for you, and which helper name?
