PR #39 isn't merged yet: it needs one more quick re-check, and then I'll merge it under your go.

Just before I merged, trunk_dev moved to #37, which adds a new root test, `runbook_paths_contract_test.go`. ES only merges up-to-date branches, so I merged #37 in. The new root layout check then refused that file, which is the drift it was built to catch. The test only checks docs (Markdown links and runbook paths), so I renamed it to `runbook_paths_docs_contract_test.go` under the agreed naming. I also changed the one line where it skips its own file.

New head: `910dc3e`, base `42db339`, manifest v2 `a27ba567…7f61`, 75 files. The root package's tests, the layout check and vet pass as the ci user. It needs a diff-only re-check of the rename and a provenance check of the #37 merge; the details are in [08-provenance-update.md](/mnt/project-files/reports/Execution-Substrate/root-tests-layout/08-provenance-update.md). GitHub CI is still running.
