Good point, David. The folder is now `conformance/`: these tests check that the scripts, the docs and repo-wide rules conform to their contracts. Its README will say that unit and package tests stay next to their code. I'm building the draft PR with that name now.

STATUS: WORKING (draft PR with path fixes and the missed-path check; next update when it's pushed)
