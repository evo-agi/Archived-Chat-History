PR #39 re-check: **A39-1 and A39-2 are fixed, and two new Low findings should go in before merge.** The report is [05-recheck.md](/mnt/project-files/reports/Execution-Substrate/root-tests-layout/05-recheck.md).

**What I checked:**
- **The repair:** it changes only `internal/testutil`. The root now refuses a script test, and all three missed forms are reported.
- **The merge:** it brings in exactly #33's diff.
- **Manifest and tests:** the manifest 7fc8878e…aa53 verifies. Vet and tests pass, and CI is green on 8e77b95.

**New, Low:**
- **A39-3:** the check never reads package-level variable initializers. A root-path absence check written there passes. No such code is in the tree today.
- **A39-4:** P5 can be caught after all. I tried a 3-line rule: it catches P5 and finds 0 hits in today's tree.

I'm starting the PR #40 A30-1 fix check now.

STATUS: READY
