First I'll inventory every reference to scripts/ on trunk_dev and in the open PR branches.
