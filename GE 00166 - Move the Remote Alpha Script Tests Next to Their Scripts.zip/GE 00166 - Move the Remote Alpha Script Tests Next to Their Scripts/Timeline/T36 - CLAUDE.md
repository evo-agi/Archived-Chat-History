Putting the script tests in scripts/ works, with nothing blocking it. Script fingerprints are untouched, IM doesn't call ES scripts by path, and test files never get copied to the box. Each test sits next to its script, which is the usual Go pairing. 31 files move there; one turned out to check only docs, so it stays at the root.

Most names stay as they are. Three are open:
1. **The docs-only file at the root:** rename it to `host_access_docs_contract_test.go`, matching the other `<subject>_docs_contract_test.go` files, or merge it into `docs_contract_test.go`?
2. **The small helper file in scripts/:** `repository_test.go` or `helpers_test.go`?
3. **The shared helper package used by both places:** `internal/repotest`?

Also, the hygiene test stays `artifact_hygiene_test.go`, because it matches the doc it checks. My picks are host_access_docs_contract_test.go, helpers_test.go (plainer) and internal/repotest. Your call.
