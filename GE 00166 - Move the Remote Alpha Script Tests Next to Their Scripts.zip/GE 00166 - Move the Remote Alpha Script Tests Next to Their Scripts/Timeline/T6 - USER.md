> Renaming scripts to .scripts is doable, but I recommend not doing it. Only ES has that folder, and it holds the commands…


Let's not rename the dir then. Otherwise, it'd be a coordination nightmare.

But, yes, please clean up the test files. About that, I think the justification was, in Go, the convention is to colocate tests with the source code?
