> Putting the script tests in scripts/ works, with nothing blocking it. Script fingerprints are untouched, IM doesn't call…


For your questions,

1. We can add the subject prefix.
2. Sure.
3. Why `repotest` ? Can't we use `test`? Or is the dir special?
