> Good thought, since 32 of the 39 are Remote Alpha script tests. Some things to weigh:


I agree the 32 should go to one dir. The other ones, I was thinking, can just be left alone.

Hmm... for the remaining 7, can we split by subject and move them to the service-specific modules, scripts/, cmd/, internal/ ?
