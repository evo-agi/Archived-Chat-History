PR #39: CI passed on 910dc3e, and the PR merged at 00:37Z as 4c991ba. The merged tree is byte-for-byte the tree I audited. I've updated the CI line in [07-recheck.md](/mnt/project-files/reports/Execution-Substrate/root-tests-layout/07-recheck.md).

STATUS: READY
