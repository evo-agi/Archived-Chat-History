# PR #12 repair after audit 30: the job-bound test no longer depends on the temporary path (A30-1), with `trunk_dev` `0aa4a2b`

Status of this file: **REPAIR REPORT, NOT AUDITED.** It covers two commits after `fd399a1` on draft PR [#40](https://github.com/evo-agi/Execution-Substrate/pull/40) into PR #12's branch. `30-audit.md` is the audit that asked for them; it asked for a diff-only check after this repair. The red-team re-check of RT28-1 and RT28-2 runs in parallel at `fd399a1`; nothing in this repair touches production code.

Written by the PR #13 writer thread on 2026-11-23, 23:2xZ.

---

## 1. In plain words

1. **The flaky test is fixed.** `TestOperationalJobBoundIsCheckedBeforeTheClaimAndAgreesWithTheProjection` measured the largest argument that fits for `a`, `<` and a control byte, each on its own subtest's fixture, and then required the bounds of `<` and the control byte to be equal. The job holds paths under the fixture's temporary directories. Their names carry the subtest's name (`html` and `control` differ by three characters) and a random number of digits. So the two bounds could differ by one character, as the audit found.
2. **Now the three bounds are compared on one fixture.** The parent test makes one fixture and measures all three bounds on it, so the paths are the same for each, and compares them there. Each subtest still measures the bound of its own fixture, completes the request at that bound and refuses one character more before anything is stored. Nothing else in the test changed.
3. **Shown over 550 runs.** The test of `fd399a1` failed 80 of 550 runs over eleven temporary paths of 4 to 24 characters, including 22 of 50 under `/tmp`, which CI uses. It also failed 6 of 50 under `/opt/ci/tmp`, the path of my earlier runs, which had all passed. The fixed test passed all 550.
4. **`trunk_dev` `0aa4a2b` (PR #33) is merged in.** It touches only two es/config test files, which PR #12 does not touch. The merge is exactly git's own.
5. **Test code only.** One test file in es/admission, +39/−22 lines. No production code, document or contract changes. The path set against `trunk_dev` is unchanged at 66 files.

## 2. Identity

| Field | Value |
| --- | --- |
| Objective | Close A30-1 (`30-audit.md`) and take up `trunk_dev` `0aa4a2b` |
| Repository | `evo-agi/Execution-Substrate` |
| Base | `codex/reliable-submit-operational-handoff-v1` (PR #12) at `44166998d4ef0d7b86152f3f66265b906f7d612a` |
| Topic branch | `claude/project-thread-ne9cwa-pr12-trunk-dev`, draft PR [#40](https://github.com/evo-agi/Execution-Substrate/pull/40) |
| Audited head | `fd399a12b5fc8319d403de471bb3ce42446f350c` |
| Head | `75d0f5c1c858365bf1f68e7e3887405665f0e29f`, tree `321b195d22b563f1007d52c41a903393fdcfdb3f` |
| `trunk_dev` | `0aa4a2b5d8e93a10f65b3bb724b286ee79a0aa7e` (PR #33), fetched again before the push and before the manifests |
| Toolchain | Go 1.26.5 (`GOTOOLCHAIN=local`), linux/amd64 container, unprivileged user `ci`, emptied environment |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run |

| Commit | What |
| --- | --- |
| `414a5e5` | Compare the job bounds of `<` and a control byte on one fixture (A30-1) |
| `75d0f5c` | Merge `trunk_dev` `0aa4a2b` into PR #12 |

## 3. The change (`414a5e5`)

`es/admission/reliable_submit_operational_job_bound_test.go`:

- **New helper `operationalLargestArgvThatFits(t, f, c, high)`.** It is the bisection the test already had, moved out unchanged: it checks that one copy fits and `high` copies do not, then bisects. Its comment says why a bound holds only for the fixture it was measured on.
- **The comparison runs on one fixture.** The parent test makes `shared := makeOperationalFixture(t, "", "alpha")`, measures the bound of `a`, `<` and `\x01` on it, and requires `html == control` and `html*5 <= plain`, as before.
- **Each subtest keeps its own checks.** It makes its own fixture, measures that fixture's bound, completes the request at the bound with one POST and refuses one character more as malformed, with no claim, grant, POST or revision. The only difference is that `high` is now written `low+1`, which is what the bisection ended with.

Why exact equality is now sound: on one fixture, the job differs between the `<` and `\x01` requests only in the argument. encoding/json writes each of the two characters as a six-byte escape, so the two jobs have the same length for every count. The POST body bound is measured canonically and is unreachable while Job0 is bounded (audit 30 on F3 and F4), and the request's own bound of 262,144 bytes is far above the roughly 62,000 bytes a control-byte request has at the job bound.

I chose one fixture over a tolerance of one character: a tolerance would accept a measure that counts `<` one byte differently from a control byte in a few positions, and the comparison exists to catch exactly that kind of measure (mutant F6).

## 4. Validation

Go 1.26.5, emptied environment, user `ci`.

### 4.1 Many runs at different temporary paths (`repeat-a30.sh`)

Each run is the test binary of one head, run alone, with `TMPDIR` set as shown ("unset" means Go uses `/tmp`, as CI does). 50 runs per row.

| `TMPDIR` | length | `fd399a1` fails | `414a5e5` fails |
| --- | --- | --- | --- |
| unset (`/tmp`) | 4 | 22 | 0 |
| `/tmp/a` | 6 | 2 | 0 |
| `/tmp/ab12` | 9 | 0 | 0 |
| `/tmp/ab123` | 10 | 19 | 0 |
| `/opt/ci/tmp` | 11 | 6 | 0 |
| `/tmp/ab12345` | 12 | 0 | 0 |
| `/tmp/ab123456` | 13 | 16 | 0 |
| `/tmp/ab1234567` | 14 | 2 | 0 |
| `/tmp/ab12345678` | 15 | 0 | 0 |
| `/tmp/ab123456789` | 16 | 13 | 0 |
| `/tmp/ab1234567890abcdefg` | 24 | 0 | 0 |
| **all** | | **80 of 550** | **0 of 550** |

Every failure of `fd399a1` has `html` and `control` one apart, either way round, for example `map[control:10367 html:10368 plain:62209]`. `plain` moves between 62,207 and 62,209 from run to run, which shows the path dependence directly.

My round 29 runs were all green under `/opt/ci/tmp`. Here that path failed 6 of 50, so they were lucky, as the audit inferred.

### 4.2 The round 29 job-bound mutants under `/tmp` (`mutants31.py`)

The audit ran round 29's mutants under an 11-character `TMPDIR` because the test was unstable under `/tmp`. I ran the baseline and the six RT28-2 mutants again on a clean clone of `75d0f5c` with `TMPDIR` unset, so under `/tmp` as CI does (`mutants31.py`: round 29's `mutants29.py` with `env -u TMPDIR` and a no-change baseline B0 added):

| Mutant | Result | Caught by |
| --- | --- | --- |
| B0 no change | baseline passes, 71 results | |
| F1 the handoff does not ask whether the request fits | caught | the job-bound test, `TestOperationalRequestsTooLargeForAJobLeaveTheDomainOpen`, `TestRedTeamPR12HeadRequestTooLargeForAJobTakesNoClaim` |
| F2 every request fits | caught | the same three |
| F3 the POST body is not checked | survives | equivalent while Job0 is bounded, as in round 29 and audit 30 |
| F4 a one-byte correlation value | survives | the same |
| F5 a shorter locator shape | caught | the job-bound test, `TestOperationalLocatorShapeHasTheLengthsOfEveryAssignedRun` |
| F6 Job0 measured in canonical form | caught | the job-bound test only |

F6 is caught only by the comparison this repair moved onto one fixture: with the canonical measure, `<` counts one byte and its bound comes out near the plain one. So the comparison is kept exact, and it is now stable.

### 4.3 Whole head

`val31.sh` is round 29's `val29.sh` unchanged, on a clean clone of `75d0f5c`; `go test ./...` also ran on a clean clone of `fd399a1` for comparison. Both use `/opt/ci/tmp`, as in round 29.

- **Build and vet** are clean for linux/amd64, linux/arm64 and darwin/arm64. `gofmt` lists the same 6 files as `trunk_dev`, none of them PR #12's.
- **Blob-read guard:** 3 pass. **Root docs pins:** 4 pass. **Race:** clean on the es/admission and reliablesubmit subsets.
- **Whole module against `fd399a1`:**
  - 9,070 results exist on both sides, and none changed;
  - the 76 new results are PR #33's es/config tests, all passing;
  - 43 subtest names appear on one side only on each side, all under the three red-team tests that name their rounds after random instants (`TestRedTeamPR12CombinedSIGKILLAtRandomInstants`, `TestRedTeamPR12HeadLiveProcessesRaceForOneClaim`, `TestRedTeamPR12HeadTwoSIGKILLsThenASurvivor`); each has the same number of subtests on both sides, and all three pass;
  - the 28 top-level failures are identical on both sides and are this container's known ones, as in round 29: 25 in the root package, and in reliablesubmit the 2 probe-binary tests and `TestOperationalHandoffSchema4BinaryRefusesSchema5`.
- The job-bound test passes on both sides here, as it may under `/opt/ci/tmp` (section 4.1).

## 5. Provenance manifests

v2 recipe, run twice per base on a clean tree at the pushed tip, byte-identical:

| Item | Trunk-relative | PR-relative |
| --- | --- | --- |
| Base | `trunk_dev` `0aa4a2b` (merge base) | PR #12 `4416699` |
| Manifest SHA-256 | `7cbd8a1669c8a31940543a1fe70ba43897b376ca8340331d03adeaab0ac56868` | `9e6b7ec30d529a2efac32453844ba8b4ce1126305821f28a137c728ce53d12ba` |
| Files | 66 | 82 |
| Textual diff SHA-256 | `42a26fd81d6f0d6785f3e44142d05db849dae3cd332145d9276a33c951efc1e1` | `c439b13d882cbc1f23493bfcaddfbaffe9c9d49de92f975ffbd40bc477ec9bc5` |

Against round 29's manifests (`20fd4ee4…` trunk-relative, `35c3e1f7…` PR-relative), with each file entry compared:

- **Trunk-relative:** the same 66 paths. Exactly one entry changed, `es/admission/reliable_submit_operational_job_bound_test.go`.
- **PR-relative:** that entry changed too, and the two es/config files of PR #33 are added (80 to 82), since PR #12's own base does not have them yet. Nothing is gone.

The trunk-relative textual diff is the same as in round 29 (`42a26fd8…`). That is expected: the recipe's textual diff is `git diff HEAD` against the base, which leaves out files the base does not track, and the changed test file is new against `trunk_dev`. Its new content is in the manifest's file entry.

The staged tree equals the head's tree for both bases, and the working tree was clean before and after.

## 6. For the diff-only check

- `git diff fd399a1 414a5e5` is the whole repair: one file, the test above.
- `git diff 414a5e5 75d0f5c` is PR #33's diff exactly; `git merge-tree --write-tree 414a5e5 0aa4a2b` gives the head's tree `321b195d…`.

## 7. Evidence

`31-repair-evidence/` (and `31-repair-evidence.tar.gz`), with `SHA256SUMS`:

- `commits/`: both commits and the repair's diff;
- `repeat/`: the two logs of section 4.1;
- `mutants/`: the log of section 4.2;
- `runs/`: the whole-head runs of section 4.3 and their comparison;
- `manifests/`: both manifests, twice each;
- `scripts/`: `repeat-a30.sh`, `mutants31.py`, `val31.sh`, `valo332.sh`, `compare.py`, `prov31.sh`.

## 8. Not claimed and still open

- No audit of this repair yet. Nothing ran on macOS.
- Unchanged from round 29: N-1 (the Nomad token on the three private requests) waits on PR #31, and RT28-1's live check on the box (29-repair.md section 8) needs David's go.
- I wrote the change and its tests.

## 9. Effects

One push of the topic branch: `fd399a1..75d0f5c`. CI for the head is on GitHub.
