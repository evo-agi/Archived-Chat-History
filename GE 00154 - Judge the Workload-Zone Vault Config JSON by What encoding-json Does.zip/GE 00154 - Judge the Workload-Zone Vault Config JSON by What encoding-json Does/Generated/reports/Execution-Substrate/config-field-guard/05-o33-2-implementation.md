# IMPLEMENTATION REPORT: the workload-zone Vault config guard judges the JSON as encoding/json does (O33-2)

Writer: the PR #13 thread. Date: 2026-11-23, 22:5xZ.

## 1. In plain words

- **The gap.** `TestWorkloadZoneVaultConfigBlobCarriesOnlyNonSecretVaultMetadata` keeps token, secret, lease and raw SPIRE keys out of the workload-zone Vault config that ES reads from an ARS blob. It used one flat set of JSON tag names for two questions: is a forbidden key there, and is a required key there. So an untagged `VaultToken` field, a tag `VAULT_TOKEN`, a `vault_token` inside a map value and a field of type `any` all passed, and a required key counted at any depth. This is observation O33-2 from audit 02 on PR #33. The coordinator asked for it as its own test-only PR after #33 merged.
- **Nothing is wrong today.** The three types have only string fields and one nested struct, and the guard passes on them before and after.
- **The fix: ask encoding/json, not the tags.** This is the PR #26 approach the auditor recommended: exact key paths as encoding/json writes them, plus an exact allowlist. Four helpers, each answering one question, and none returning a set that another question could be asked of:
  - `runtimeConfigFieldsNotPlainJSON`: is every field, at any depth, an exported, tagged string or struct field that encoding/json writes and reads?
  - `runtimeConfigCodecMethods`: does any type in it choose its own JSON or text encoding?
  - `runtimeConfigJSONKeysDecoded`: does a strict decoder, as ES uses for this blob, take a forbidden key at any object of the form?
  - `runtimeConfigJSONWritten`: which key paths, and which kinds of JSON value, does `json.Marshal` write for a filled value? They must be exactly the metadata keys, each a string.
- **Shown on the real tree.** Nine planted fields that the old guard accepts are refused now, and the one it refused (`vault_token`) still is. All 30 mutants of the new code are caught.
- **Test code only.** `internal/contracts/runtimeconfig/v1/workload_zone_vault_test.go` and a new `workload_zone_vault_guard_test.go` in the same folder, +1029/−51 lines. No production code, document, stored format or public contract changes.

## 2. Target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Branch | `claude/project-thread-ne9cwa`, restarted from `trunk_dev` after PR #33 merged |
| Base | `trunk_dev` `0aa4a2b5d8e93a10f65b3bb724b286ee79a0aa7e` (PR #33) |
| Commit | `d7914c78271cdc308da183dcc7840f8ba232d688`, tree `a8af4fa4b332aa35933fa12c4e37dd8da5f5b602`, parent `0aa4a2b` |
| Pull request | #41 (https://github.com/evo-agi/Execution-Substrate/pull/41) (draft) |

## 3. The change

### 3.1 What the config is

`WorkloadZoneVaultConfigBlob` is a stored JSON blob in ARS: `{"vault_config": {...}}`. `es/admission/service.go` (`workloadZoneVaultConfig`) reads it with `decodeJSON`, which sets `DisallowUnknownFields` and refuses trailing data, then validates it and keeps `Normalized().VaultConfig`. `WorkloadZoneVaultConfigRef` is the digest that names the blob. So the guard judges JSON keys and values, as encoding/json writes and reads them, not Go names.

### 3.2 `runtimeConfigFieldsNotPlainJSON`

It walks every field of every struct reached, exported or not, and reports a field that is embedded, unexported, tagged `-`, untagged, tagged with an option other than `omitempty`, or of any kind but string or struct. A struct field is read in turn. Each type is walked once. It does not judge names; `runtimeConfigJSONWritten` shows them as written.

`TestRuntimeConfigFieldsNotPlainJSONTriesEveryKind` tries every kind from `reflect.Bool` to `reflect.UnsafePointer`, so a check written as a list of refused kinds cannot pass (the lesson of the earlier rounds: accept what is known to be plain, refuse everything else).

### 3.3 `runtimeConfigCodecMethods`

A type that implements `json.Marshaler`, `json.Unmarshaler`, `encoding.TextMarshaler` or `encoding.TextUnmarshaler`, on its value or on a pointer to it, decides its own bytes, so the written form would no longer show what it carries. The helper finds such a type anywhere: the root, a field type, a pointer, slice, array or channel element, and a map key or value.

### 3.4 `runtimeConfigJSONKeysDecoded`

For each object of the expected form (`""` and, for the blob, `vault_config`) and each forbidden key, it decodes a document holding only that key, with a string value, at that object, into a new value of the type, with `DisallowUnknownFields`. The key is taken when decoding succeeds or fails on the value's type; it is refused only when the decoder says the field is unknown. So encoding/json itself decides case folding (`VAULT_TOKEN` takes `vault_token`), tags and promoted fields.

### 3.5 `runtimeConfigJSONWritten`

It fills a value of the type (every string set to `"x"`, pointers allocated, slices given one element, maps one entry under the empty key, numbers and booleans set), writes it with `json.Marshal` by value and through a pointer, requires the two to match, and reads back every key path and the kind of value at it. A key that holds `.`, `[`, `]` or `*` is reported, since no key path could name it. So encoding/json decides names, tags, case, `omitempty`, name clashes and embedding.

### 3.6 The guard

`checkWorkloadZoneVaultConfigJSON(t, value, want)` runs the four helpers and reports every finding with `t.Errorf`. The guard calls it for the three types:

- `WorkloadZoneVaultConfigRef`: exactly `digest`, a string;
- `WorkloadZoneVaultConfigBlob`: exactly `vault_config`, an object, and `vault_config.address`, `.auth_mount`, `.auth_role`, `.jwt_audience`, `.ca_bundle_pem`, each a string;
- `WorkloadZoneVaultConfig`: exactly those five keys, each a string.

The forbidden list keeps the old 13 keys. The required list became the exact allowlist of written key paths, with kinds.

### 3.7 New tests (`workload_zone_vault_guard_test.go`)

- `TestRuntimeConfigJSONWrittenFollowsEncodingJSON`: Go names of untagged fields, tags, case, `omitempty`, `-`, unexported fields, embedding, name clashes, maps, slices, pointers, numbers and booleans, interfaces, a recursive type, key order, a type that writes itself differently through a pointer or not as an object, and the unnamable-key report.
- `TestRuntimeConfigFieldsNotPlainJSONReadsEveryField` and `...TriesEveryKind`.
- `TestRuntimeConfigCodecMethodsFindEveryEncoder`.
- `TestRuntimeConfigJSONKeysDecodedUsesTheDecoder`.
- `TestRuntimeConfigGuardHelpersRefuseNonStructs`.
- `TestWorkloadZoneVaultConfigGuardRefusesPlantedFields`: the guard's check, through a recorder in place of `testing.T`, on the three real types and 15 planted copies. The first six are audit 02's probes: an exact `vault_token` tag, an untagged `VaultToken`, a `VAULT_TOKEN` tag, a `vault_token` in a map value, the address only at depth, and an `any` field. Then: a required key tagged `-`, a lease in an embedded struct, an unexported token, a byte slice under a required key, a field type with its own text encoding, a number under a required key, a token in the nested config of a blob, and a top-level key that reads as a nested path. Each must give exactly the expected messages.

### 3.8 Choices

- **An allowlist, as the auditor recommended.** Any new key fails until the list is edited, so the forbidden list is now a second line, not the only one.
- **Only string and struct fields.** The config is five strings in one struct. A number, a byte slice, a map or an `any` field would be a visible design change, so the guard refuses it and the change must edit the guard.
- **The ES decoder, not a lenient one.** The decoded-key check uses `DisallowUnknownFields`, as `decodeJSON` does, so it asks what ES would actually take from a stored blob.

## 4. Validation

Go 1.26.5, emptied environment, user `ci` (uid 1500, gid 1600). The mutants run in a clean clone of the head, restored after each; the probes run in clean clones of the base and the head, restored after each.

- **Build, vet, format, race.** `go build ./...` and `go vet ./...` are clean for linux/amd64, linux/arm64 and darwin/arm64. `gofmt` is clean on the package (the whole tree lists the same 6 files as the base). The race detector passes on the package.
- **Whole package.** `internal/contracts/runtimeconfig/v1` gives 86 pass, against 6 at the base. The 80 new results are the seven new top-level tests and their subtests. None changed and none is gone.
- **Whole repository.** `go test ./...` on the head and on the base: all 7083 results of the base are unchanged, and the head adds 80 passes. The 27 top-level failures on both sides are the known environment ones: 25 root tests and 2 probe-binary tests in `es/admission/internal/reliablesubmit`.
- **Real-tree probes (`probes-o332.py`).** Each probe adds one field to `WorkloadZoneVaultConfig` in `workload_zone_vault.go` and runs the guard test of the base (old) and of the head (new). There were 0 unexpected results:

| Probe | Field added | old | new |
| --- | --- | --- | --- |
| E0 | none | pass | pass |
| E1 | `VaultToken string` tagged `vault_token` | refused | refused |
| E2 | `Extra string` tagged `extra` | pass | **refused** |
| E3 | `Secret any` | pass | **refused** |
| E4 | `Token string`, untagged | pass | **refused** |
| E5 | `Labels map[string]string` | pass | **refused** |
| E6 | nested struct with `ClientToken` tagged `Client_Token` | pass | **refused** |
| E7 | `Upper string` tagged `VAULT_TOKEN` | pass | **refused** |
| E8 | unexported `lease string` | pass | **refused** |
| E9 | `Raw []byte` | pass | **refused** |
| E10 | `Hidden string` tagged `-` | pass | **refused** |

- **Mutants (`mutants-o332.py`).** All 30 are caught (`mutants-o332-d7914c7.log`):
  - P1–P7: the fields check lets embedded, unexported, `-`, untagged or wrongly optioned fields pass, accepts any kind, or does not read nested structs;
  - C1–C8: the codec check drops one of the four interfaces, looks only at value receivers, or does not read elements, map keys or struct fields;
  - D1–D3: a type error counts as refused, only the top-level object is probed, or the decoder is lenient;
  - W1–W5: inner objects of arrays are not walked, numbers count as strings, the by-pointer and by-value forms are not compared, unnamable keys are not reported, or strings are not filled;
  - K1–K6: the guard does not check the kind of a written key, a missing key, the fields, codec or decoded-key findings, or a written key beyond the list;
  - L1: one forbidden key is dropped.
- **Earlier runs.** The mutants and probes first ran on `7d632f5`, the same commit on `trunk_dev` `400ff7f` before PR #33 merged; the PR's diff is byte-identical on both bases. There D1 failed to build (a mistake in the mutant: it left an import unused); rewritten to keep the import, it was caught (`mutants-o332-d1.log`). The tables above are the run on `d7914c7` (`mutants-o332-d7914c7.log`, `probes-o332-d7914c7.log`), with the same results.

## 5. Provenance manifest

v2 recipe (SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`), trunk-relative, run twice on a clean tree at the pushed tip, byte-identical:

| Item | Value |
| --- | --- |
| Head | `d7914c78271cdc308da183dcc7840f8ba232d688`, tree `a8af4fa4b332aa35933fa12c4e37dd8da5f5b602` |
| Base | `trunk_dev` `0aa4a2b5d8e93a10f65b3bb724b286ee79a0aa7e` (merge base) |
| Manifest SHA-256 | `8664fa4792ee520e685932493af91403334b4eadf1e22d0ef68a24942104b21f`, 2 files |
| Textual diff SHA-256 | `ef381fed2e506d2b8684af918c513216c0cf33e1b9af43667a5940a5f05056df` |
| Staged tree | equal to the head's tree |

## 6. Evidence

`05-o33-2-implementation-evidence/` (and the same as `.tar.gz`), with `SHA256SUMS`:

- `commits/`: the commit and its diff against the base;
- `manifests/`: both manifest runs and their outputs;
- `runs/head-d7914c7/` and `runs/base-0aa4a2b/`: build, vet, gofmt, race, the package run and the whole-repository run, plus `compare.txt`;
- `mutants/` and `probes/`: the logs of the run on `d7914c7` and of the earlier run on `7d632f5`;
- `scripts/`: `valo332.sh`, `mutants-o332.py`, `probes-o332.py`, `provo332.sh`, `compare.py`.

## 7. Not claimed

- No audit yet.
- Nothing ran on macOS.
- The guard judges the type's JSON form, not the bytes a stored blob holds. A blob with an extra key is refused at run time by `decodeJSON`, not by this test.
- The filler leaves interfaces, functions and channels empty, so `runtimeConfigJSONWritten` alone may not show a key whose value is one of those; `runtimeConfigFieldsNotPlainJSON` refuses such fields.
- I wrote the code and its tests.

## 8. Effects

One push of the topic branch and draft PR #41 (https://github.com/evo-agi/Execution-Substrate/pull/41). CI for the head is on GitHub.
