# INDEPENDENT AUDIT REPORT: PR #41, the workload-zone Vault config guard (O33-2) at `d7914c7`

Read-only audit. Audit thread: "Audit ES config field guard", the auditor who raised O33-2 in `02-audit.md`. Date: 2026-11-23, 22:55Z to 23:27Z (UTC). No red-team: the PR changes test files only.

Verdict: **ACCEPT**, with no finding that asks for a change. The guard covers every gap O33-2 named and does it the way audit 02 recommended. Two observations stand as accepted residuals (O41-1, O41-2).

## 1. In plain words

1. **The bytes are the ones the writer reported.** My manifest of `d7914c7` against `trunk_dev` `0aa4a2b` matched the writer's byte for byte, at the start and at the end (`8664fa47…b21f`, 2 files, textual diff `ef381fed…56df`). The PR adds one test file and changes one; production code is untouched.
2. **It does what O33-2 asked.** O33-2 listed five gaps in the old guard: untagged fields, case folding, map values, `any` fields, and required keys counted at any depth. The new guard asks encoding/json itself which keys it writes and reads, and compares the written key paths, with their JSON kinds, to an exact list. Each of the five gaps is now refused, on the real tree and in the unit tests.
3. **The writer's numbers hold.** The package gives 86 passes against 6 at the base, and nothing else changed. All 30 of the writer's mutants are caught. The writer's 11 real-tree probes give exactly the writer's table.
4. **My own checks found nothing to fix.** 14 more real-tree probes, on all three types (the ref, the blob and the config), are all refused; the old guard refuses only 2 of them. They include keys no denylist names, such as `secret_id` and `token`. I ran 22 more mutants. 9 are caught. The other 13 survive in two groups. 11 drop a forbidden name: the same accepted residual as O33-1, since the allowlist now refuses those keys first (O41-1). 2 change branches that cannot change the guard's verdict (O41-2).
5. **Other branches.** No open PR touches the package. Every open PR merges with `d7914c7` without a conflict, except #12, whose `PLANS.md` conflict with `trunk_dev` exists without #41. #38 and #39 add tests that walk the repository. After merging #41, their results are unchanged apart from the 80 new passes.
6. **CI.** GitHub's required check passed on `d7914c7` (22:53Z to 23:24Z).

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #41, draft, branch `claude/project-thread-ne9cwa` (restarted from `trunk_dev` after #33 merged) into `trunk_dev` |
| Head | `d7914c78271cdc308da183dcc7840f8ba232d688`, tree `a8af4fa4b332aa35933fa12c4e37dd8da5f5b602`, one commit, parent `0aa4a2b` |
| Base | `trunk_dev` `0aa4a2b5d8e93a10f65b3bb724b286ee79a0aa7e` (PR #33), merge base |
| Recipe | `governed-execution.audit-patch-manifest.v2`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before every run |
| Trunk-relative manifest | `8664fa4792ee520e685932493af91403334b4eadf1e22d0ef68a24942104b21f`, 2 files, textual diff `ef381fed2e506d2b8684af918c513216c0cf33e1b9af43667a5940a5f05056df`, upstream `origin/trunk_dev` |
| PR diff | `0aa4a2b..d7914c7`, SHA-256 `ab3e5901…e703` (equal to the writer's `commits/diff-0aa4a2b-d7914c7.diff`), +1029/−51: `workload_zone_vault_guard_test.go` +650 (new), `workload_zone_vault_test.go` +379/−51 |
| Writer report | `05-o33-2-implementation.md`, SHA-256 `564ee15e1b02107db3effb9bbf4ecdbdb491d3c731c9cf6c1bf22ab249a3cda9`. Evidence `05-o33-2-implementation-evidence/`: all 41 `SHA256SUMS` entries OK |
| What was asked | O33-2 in `02-audit.md` (SHA-256 `f53e82b7…9cd6`, unchanged on disk) |

## 3. Posture and setup

As in audits 02 to 04: read-only on GitHub; clone `/opt/audit/es` under `umask 022`; `git archive` exports of the exact commits; every build, test, mutant and probe as user `ci` (uid 1500, gid 1600, no sudo) under `runuser … env -i`, Go 1.26.5, `GOTOOLCHAIN=local`, `GOPROXY=off`, with HUP, INT, QUIT and TERM reset; each mutant and probe in a fresh copy of the export. No worktree or extra ref was left in the clone.

## 4. Provenance

| Run | Time | `trunk_dev` | Result |
| --- | --- | --- | --- |
| Opening, two runs | 22:56Z | `0aa4a2b` | `8664fa47…b21f` both times, identical to each other and byte-identical to the writer's `manifests/trunk-1.json` and `trunk-2.json` |
| Closing, two runs | 23:25Z | `0aa4a2b` | `8664fa47…b21f` both times, byte-identical to the opening runs |

Before each pair: pushed tip and `refs/pull/41/head` equal `d7914c7`, `0aa4a2b` is the merge base, the tree is clean (ignored files included), upstream pinned. The staged tree equals the head's tree. Manifest entries: `workload_zone_vault_guard_test.go` untracked, mode 0644, 28,127 bytes, SHA-256 `71c267fa…da22`; `workload_zone_vault_test.go` tracked and modified, mode 0644, 18,432 bytes, SHA-256 `61daf9a4…1935`.

## 5. What I verified

### 5.1 Against O33-2

O33-2 asked for the PR #26 approach: exact key paths as encoding/json writes them, plus an exact allowlist. The PR replaces the flat tag set with four helpers that each answer one question and return a list, not a set another question could reuse:

| O33-2 gap | What now refuses it | Shown by |
| --- | --- | --- |
| Untagged `VaultToken` (written under its Go name) | fields check (untagged); written key `VaultToken` is not on the list | planted test, probes E4, R2 |
| Tag `VAULT_TOKEN` (decoder folds case) | strict decoder takes `vault_token`; written key not on the list | planted test, probes E7, C8, and C6 with a Kelvin-sign `K` |
| `vault_token` in a map value | fields check (map kind); `extra`, `extra.*`, `extra.*.vault_token` not on the list | planted test, probes E5, R3 |
| `any` field | fields check (interface kind); written `null` key not on the list | planted test, probe E3 |
| Required key at any depth | written paths compared exactly; `address` missing at the top is reported | planted test |

The guard runs on all three types ES uses: `WorkloadZoneVaultConfigRef` (`es/config` and `es/admission` hold it), `WorkloadZoneVaultConfigBlob` (`es/admission/service.go:675`, `fetchWorkloadZoneVaultConfig`, decodes it with `decodeJSON`, which sets `DisallowUnknownFields`, line 915) and `WorkloadZoneVaultConfig`. The test keeps its old name, `TestWorkloadZoneVaultConfigBlobCarriesOnlyNonSecretVaultMetadata`; no file in the repository pins that name.

### 5.2 The code

- **`runtimeConfigFieldsNotPlainJSON`** walks every field of every struct reached, exported or not, and accepts only an exported, non-embedded field with a tag name, at most the `omitempty` option, and kind string or struct. It accepts what is known to be plain and refuses everything else, and the every-kind test (26 kinds, `unsafe.Pointer` taken as in PR #33) pins that.
- **`runtimeConfigCodecMethods`** tests `reflect.PointerTo(typ).Implements` for the four interfaces, so value and pointer receivers both count, and it reads pointer, slice, array and channel elements, map keys and values, and struct fields.
- **`runtimeConfigJSONKeysDecoded`** decodes a one-key document at each object of the form, into a new value, with `DisallowUnknownFields`. Only the decoder's own "unknown field" answer counts as a refusal; a type error counts as taken, and any other error stops the test. So encoding/json decides case folding, tags and promoted fields.
- **`runtimeConfigJSONWritten`** fills a value, writes it by value and through a pointer, requires the two to be equal, and reads back every key path with its JSON kind (numbers through `UseNumber`). A key holding `.`, `[`, `]` or `*` is reported, because a key path could not name it.
- **`checkWorkloadZoneVaultConfigJSON`** reports every finding of the four helpers with `Errorf`, every written path not on the list, a wrong kind, and every listed path not written.

The lists: the ref writes exactly `digest`; the blob writes `vault_config` (an object) and its five keys; the config writes the five keys, each a string. The 13 forbidden keys are kept for the decoder check.

What the guard does not judge is stated in the PR: values, and a stored blob's bytes (ES refuses an unknown key at run time). A legitimate new key fails until the list is edited, which is the intended review point.

The writer's report names the ES function `workloadZoneVaultConfig`; it is `fetchWorkloadZoneVaultConfig`. This is a slip in the report only, not in the PR.

### 5.3 Tests (`runs/`)

| Tree | gofmt (package) | build + vet `./...`, three targets | package | race | packages that read repository source |
| --- | --- | --- | --- | --- | --- |
| base `0aa4a2b` | clean | ok | 6 pass | ok | 3,901 pass, 247 fail, 14 skip |
| head `d7914c7` | clean | ok | 86 pass | ok | identical per test |

The 80 new results are the seven new top-level tests and their subtests; none of the 6 old results changed. `gofmt -l .` lists the same 6 files on both trees. "Packages that read repository source" are the root package, `es/admission/...` and `internal/testtmpdir`; their failures are the same on both trees and come from this container. I did not rerun the whole repository: the change is two test files in one package, and the packages whose tests read other packages' files are the ones above.

### 5.4 Mutants (`mutants/mut41.log`)

All on `d7914c7`, each in a fresh copy, with `go vet` and the whole package test.

| Set | Result |
| --- | --- |
| Writer's P1–P7, C1–C8, D1–D3, W1–W5, K1–K6, L1 | 30 of 30 caught |
| Y01 the guard probes decoded keys only at the top level | caught |
| Y06 the map entry filled under a non-empty key; Y08 the empty map key not named | caught |
| Y12 numbers read as float64; Y14 a pointer to the struct refused; Y17 nested probe documents built inside out; Y20 no recursion stop in the filler | caught (Y20 by a stack overflow) |
| Y02 an unexpected decode error counts as refused instead of stopping the test | survives (O41-2) |
| Y07 only `.` counts as unnamable | survives (O41-2) |
| L01–L13, each forbidden key dropped | L01 (`vault_token`) and L11 (`lease_id`) caught; 11 survive (O41-1) |

Total: 52 mutants, 39 caught, 13 survive, all explained below.

### 5.5 Real-tree probes (`probes/`)

Each probe plants one change in `workload_zone_vault.go` and runs only the guard test, on the head and on the base.

| Probe | Planted | old guard | new guard |
| --- | --- | --- | --- |
| E0–E10 | the writer's 11 plants in the config, same lines | E1 refused, E0 and E2–E10 pass | E0 passes, E1–E10 refused (matches the writer's table) |
| R1 | ref: `Token` tagged `vault_token` | refused | refused |
| R2 | ref: untagged `Lease` | pass | refused |
| R3 | ref: `map[string]string` | pass | refused |
| B1 | blob: `LeaseID` tagged `lease_id` | refused | refused |
| B2 | blob: `json.RawMessage` | pass | refused (kind, both codec methods, and the filled value cannot be written) |
| B3 | blob: nested struct with `secret_id` | pass | refused |
| C1 | config: `secret_id`, not on the denylist | pass | refused |
| C2 | config: `token,omitempty`, not on the denylist | pass | refused |
| C3 | config: `auth_role,string` option | pass | refused |
| C4 | config: tag `-,` (written under the key `-`) | pass | refused |
| C5 | config: a named string type with `MarshalText` | pass | refused |
| C6 | config: tag `vault_toKen` with a Kelvin-sign `K` | pass | refused, the decoder folds it to `vault_token` |
| C7 | config: embedded struct promoting `client_token` | pass | refused |
| C8 | config: tag `Vault_Token` | pass | refused |

Q0 (no change) passes on both. The planted test's 15 copies pass in the package run.

### 5.6 Other open branches (`trial-merge/`)

Open at 23:07Z: #12, #30, #31, #34, #35, #37, #38, #39, #40. None changes `internal/contracts/runtimeconfig`. Each merges with `d7914c7` without conflict, except #12, whose `PLANS.md` conflict is the same against `trunk_dev` alone. #38 and #39 add tests that walk the repository. I ran their packages on the branch head and on its merge with `d7914c7`. #38 (root and the runtimeconfig package) and #39 (root, `internal/callerauth`, `internal/testutil` and the runtimeconfig package) differ only by the 80 new runtimeconfig passes.

## 6. Findings

No finding asks for a change.

| ID | Status |
| --- | --- |
| O33-2 | Closed by this PR |
| O41-1 | Accepted residual, as O33-1: 11 of the 13 forbidden keys are pinned by no test (L02–L10, L12, L13 survive). The fields check and the exact allowlist refuse any such key first, so the list matters only after a later edit adds that key to the allowlist |
| O41-2 | Accepted, equivalent in effect. Y07: only `.` is pinned among the four unnamable-key characters, but a key with `[`, `]` or `*` gives a path that is not on any list and is reported anyway. Y02: the only decode errors other than "unknown field" and a type error come from a type with its own decoding method or an embedded pointer, which the codec and fields checks already report |

## 7. CI

GitHub's required check "build, vet and test", run 45283879748 (job 138075034746), on head `d7914c78271cdc308da183dcc7840f8ba232d688`: **success**, 22:53:22Z to 23:24:51Z. I read the result through the GitHub tool and did not rerun CI.

## 8. Confidence

- Provenance: 1.0. Manifest reproduced byte for byte at opening and closing; PR head equals the audited commit.
- Validation: high. All counts above are from my own runs on the exact bytes.
- Implementation: high. The guard now asks encoding/json what the three types write and read, and requires exactly their metadata keys as strings.

## 9. Effects

No repair, commit, push, PR comment, review or merge by this audit. The only writes are this report and `06-audit-evidence/` in the project folder. The PR is test-only and has no open blocking finding, so under the project's merge policy it can merge without David's review once the merge gate passes for head `d7914c7`.

## 10. Evidence

`06-audit-evidence/`, with `SHA256SUMS` over every file: `writer-evidence-check.txt`, `provenance/` (opening and closing runs), `runs/` (base and head: static, package, race, scan packages, comparisons), `mutants/`, `probes/` (my probes and the writer's E0–E10, head and base), `trial-merge/` (merge table, the #38 and #39 runs), `scripts/` (`prov6.sh`, `unit41.sh`, `mut41.py` with the writer's 30 copied verbatim, `mutrun41.py`, `probes41.py`, `probe41run.py`, `walk41.sh`, `cienv.sh`, `results.py`).

Final verdict: **ACCEPT** for head `d7914c78271cdc308da183dcc7840f8ba232d688`, base `0aa4a2b`, manifest `8664fa47…b21f`.
