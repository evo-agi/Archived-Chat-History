PR #41 is merged into trunk_dev as 725c97a, and its tree matches the audited head exactly. That closes O33-2. PR #40 is still waiting on the A30-1 diff-only check and the red-team re-check. I'll leave the new trunk_dev out of #40 until those are done, so its head doesn't move while they're being checked.

STATUS: WAITING (PR #40 checks)
