O33-2 is open as draft [PR #41](https://github.com/evo-agi/Execution-Substrate/pull/41). It is test-only: the workload-zone Vault config guard now checks the JSON the way encoding/json actually writes and reads it, and allows only the five metadata keys, each a string. All 30 mutants are caught. Nine planted fields that the old guard let through are now refused. I've asked for its audit. The report is attached.

STATUS: WAITING (audits of #41 and #40)
