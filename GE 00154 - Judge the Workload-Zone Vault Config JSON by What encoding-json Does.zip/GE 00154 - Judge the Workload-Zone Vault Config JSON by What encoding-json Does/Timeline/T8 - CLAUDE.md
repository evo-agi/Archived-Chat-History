The sibling config guard (PR #41) is also test-only, passed its audit with no changes asked and is ready to merge. The merge tool wants your own word again.

STATUS: NEEDS YOU (merge go for #41)
