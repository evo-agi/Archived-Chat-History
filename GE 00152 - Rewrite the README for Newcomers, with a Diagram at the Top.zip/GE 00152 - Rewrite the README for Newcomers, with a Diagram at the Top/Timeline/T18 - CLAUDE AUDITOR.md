Both README PRs need one small repair round before they merge. Each verdict is **REPAIR NEEDED** for wording only. Nothing is High or Medium, the provenance checks pass, the pinned tests pass, and neither README contains secrets or home-network addresses.

**ES #36** ([report](/mnt/project-files/reports/docs/readme-es-pr36-audit.md)). Every claim in the new top section holds at `76c030f`, including "no real agent yet" and the goal framing.
- L1: step 2 and the diagram read as if ES checks EGS trust on every request. In fact ES loads it once, at startup (`es/admission/service.go:285`, `boundaries.md:828`). It needs one sentence saying so.
- L2: ARS, AGS, EGS and CGS are never spelled out.
- Nit: move the jargon "Current Mode" paragraph to the index at the bottom.

**IM #2** ([report](/mnt/project-files/reports/docs/readme-im-pr2-audit.md)):
- L1: step 2 says CP reaches ES "by internal HTTPS names". In fact CP talks to bridges at `127.0.0.1`.
- L2: "What you need" leaves out the Temporal CLI, which `up` runs.
- L3: the PostgreSQL commands do write files under `.out/postgres`.
- L4: `profile` prints a summary of the profile, not the profile itself.
- Each report ends with a repair brief giving the exact wording.

One thing outside the PRs: public ES contains the test box's LAN address `[home network address withheld]` 27 times and `/Users/ds` 8 times, in tests, docs and scripts. That probably deserves its own cleanup thread.

Next I'm auditing ES PR #37 and Archived-Runbooks PR #4.

STATUS: WORKING (PR #37 runbook audit, next update by about 9:30 PM UTC)
