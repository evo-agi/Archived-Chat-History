The new READMEs are now live on trunk_dev for both repos. Each one opens with a diagram and a plain explanation, and the index for agents is at the bottom.

- **Execution Substrate:** [PR #36](https://github.com/evo-agi/Execution-Substrate/pull/36) merged as `400ff7f`.
- **Infrastructure Manager:** [PR #2](https://github.com/evo-agi/Infrastructure-Manager/pull/2) merged as `b2ca78f`.

Both passed the independent audit and CI before merging. No edits from you were on either branch. `main` hasn't been touched, so these reach `main` at the next milestone merge.

STATUS: done, both README rewrites are merged into trunk_dev.
