> The new READMEs for ES (PR 36 (→ github.com)) and IM (PR 2 (→ github.com)) are up, with a diagram near the top. MA's ope…


For future reference, you don't have to check with me on doc- and README-related changes. Those can be merged. But, just in case, I'll highlight that I may edit the files directly on GitHub, or push to GitHub on my own, even if it's most likely about wording. Rebase should reconcile what is on GitHub with what the code actually does, and overwrite when remote is inaccurate.
