Both README rewrites are now merged into trunk_dev, the outsider-friendly versions with diagrams for ES and IM.

STATUS: WORKING (nothing needs you)
