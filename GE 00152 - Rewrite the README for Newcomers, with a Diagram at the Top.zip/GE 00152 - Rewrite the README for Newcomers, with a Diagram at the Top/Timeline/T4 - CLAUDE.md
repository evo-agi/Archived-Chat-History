The docs rule is saved in the procedures file: every PR that changes behaviour updates its docs, and audits flag stale docs. The main branch's README changes only at milestone merges, which need your go.

STATUS: WORKING (READMEs, plus the audits and red-teams already running)
