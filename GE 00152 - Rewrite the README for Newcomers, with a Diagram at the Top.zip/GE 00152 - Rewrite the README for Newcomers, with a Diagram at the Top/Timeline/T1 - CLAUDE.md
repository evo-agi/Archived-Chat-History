Starting on clearer READMEs with diagrams, ES first, then MA and IM. Keeping docs current is now a standing rule for every PR in those repos.
