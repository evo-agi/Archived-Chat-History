> The new READMEs for ES (PR 36 (→ github.com)) and IM (PR 2 (→ github.com)) are up, with a diagram near the top. MA's ope…


Damn. ES looks so... simplistic and... elegant? with the diagram. Wow.

I'm probably exaggerating it, to be honest.
