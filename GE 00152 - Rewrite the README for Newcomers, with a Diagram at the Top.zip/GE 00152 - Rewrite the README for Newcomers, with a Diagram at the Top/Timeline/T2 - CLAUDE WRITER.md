First I'll read ES's current README, AGENTS.md, PLANS.md and docs, then draft the new structure and diagram.
