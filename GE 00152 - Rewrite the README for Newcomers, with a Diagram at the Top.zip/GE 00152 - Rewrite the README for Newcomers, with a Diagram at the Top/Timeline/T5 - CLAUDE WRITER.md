Claude opened a site in the browser
