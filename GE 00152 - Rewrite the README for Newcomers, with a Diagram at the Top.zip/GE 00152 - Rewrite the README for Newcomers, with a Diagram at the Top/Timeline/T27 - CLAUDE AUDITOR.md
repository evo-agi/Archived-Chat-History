ES #36 at 4382b71 is **still ACCEPT**, so it can merge after CI. I confirmed all three of the writer's numbers from a fresh clone:

- README.md is byte-identical to 3efe715 (c460fc53…0994) and is the only file that differs from trunk_dev fdfa3bc.
- The textual diff is still 5a0bbf68…e042.
- The manifest against fdfa3bc is 2671ea5f…67ed. I took it twice and got the same result both times.

The pinned test passes, and a trial merge with #37 is clean. The [report](/mnt/project-files/reports/docs/readme-es-pr36-audit.md) now ends with a one-line re-check 2.

#37's base is now behind trunk_dev, so it will need a trunk_dev merge too. I'll re-check provenance on whatever head it ends up with. The #37 and Archived-Runbooks #4 re-check is still in progress.

STATUS: #36 provenance confirmed; #37 and AR #4 re-check in progress.
