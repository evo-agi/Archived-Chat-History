# Audit: Execution-Substrate PR #36, README for newcomers

Verdict: **REPAIR NEEDED** (2 Low findings and 1 Nit to fix in this PR; nothing High or Medium; no blocking finding on correctness, provenance, tests or secrets)

Auditor: fresh read-only audit thread, 2026-11-23 20:37Z to 20:58Z. Nothing pushed, no PR comment posted.

## Target

| Field | Value |
| --- | --- |
| Repo | evo-agi/Execution-Substrate (public) |
| PR | [#36](https://github.com/evo-agi/Execution-Substrate/pull/36), draft, into `trunk_dev` |
| Topic branch | `claude/project-thread-no8fj8` |
| Base (trunk_dev, re-checked at closeout) | `76c030fa7872dd22dda731591878ef284c01bd9b` |
| Tip (re-checked at closeout) | `555ee4790c55d63b567f859553de292cebb13b53` |
| Tip tree | `c15ddc0ad8a1417f44f51c8e116a5c811022f14c` |
| Changed paths | `README.md` only (145 additions, 39 deletions, 4 commits) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before each run) |
| textual_diff_sha256 | `495c3ea740b15fb14f8403fa1372791b4883477b3d2733931885e95893b2cf0a` |
| Canonical manifest SHA-256 | `f79a26120f97c93d983b000af6a5cdc005945852a6ff364b38e5dd9a8ebfd329` |
| File count | 1 |

Canonical manifest:

```json
{"branch":"claude/project-thread-no8fj8","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"README.md","sha256":"c3c9cc15b1179550a9aabc6c5257c8772fbce9131962f81f5d06efd0b76848ce","size":12353}],"head":"76c030fa7872dd22dda731591878ef284c01bd9b","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"495c3ea740b15fb14f8403fa1372791b4883477b3d2733931885e95893b2cf0a","upstream":"origin/trunk_dev"}
```

## Provenance

- The writer's PR body and thread report give no manifest, so there was nothing to reproduce. I took the base-relative manifest myself under provenance §5.3 (fresh clone, `umask 022`, topic checked out at the tip, `git reset --mixed` to the base, upstream pinned to `origin/trunk_dev`), twice into a fresh mode-0700 directory: byte-identical. The committed blob `555ee47:README.md` hashes to the manifest's `c3c9cc15…48ce`, so the commit holds the hashed bytes.
- Closeout: the working tree was unchanged (`git status --porcelain --ignored` shows only `README.md`), and a third run equals the opening manifest byte for byte.
- Provenance tier: a docs-only change is not in the sensitive list (procedures.md, "Audits"). This manifest is the audit target identity for the merge gate.

## Findings

### Low

**L1. Step 2 and the diagram read as if ES checks trust live; ES loads EGS trust once, at startup.** Type: doc precision on a security property.
- README: `README.md:45-47` ("checks them against the signed runtime trust that EGS publishes") and the diagram edge `README.md:34` (`ES -->|"read trust"| EGS`).
- Repo fact at `76c030f`: ES fetches `GET /v1/trust-model` only in `Service.Initialize` (`es/admission/service.go:285-300`), which runs once from `App.Start` (`es/app/app.go:72-75`); `.docs/system_overview/boundaries.md:828` says "ES loads and verifies the trust model on startup, then uses it during artifact admission".
- Why it matters: a newcomer, or a buyer reading the public README, would assume that removing a signer at EGS takes effect on the next request. It does not until ES restarts. The sentence is true but leaves out the one fact that changes how revocation behaves.
- Suggested fix: append to step 2: "ES loads that trust once, when it starts." Optionally label the edge `"read trust<br/>at startup"`.

**L2. ARS, AGS, EGS and CGS are never spelled out.** Type: readability (the README norm in procedures.md "Docs and READMEs" requires a README a newcomer can easily understand).
- README: first use in the diagram at `README.md:20-23`, then the walk-through and the components table at `README.md:92-95`, with no expansion anywhere.
- Repo names at `76c030f`: `ars/api/server.go:22` `artifact-registry`, `ags/api/server.go:14` `artifact-governance`, `egs/api/server.go:13` `execution-governance`, `cgs/api/server.go:15` `credential-governance`; the systemd unit tests spell them "Execution Substrate Artifact Registry Service", "Artifact Governance Service", "Execution Governance Service" (`remote_alpha_harden_ars_service_test.go:294`, `remote_alpha_harden_ags_service_test.go:233`, `remote_alpha_harden_egs_service_test.go:331`). Inference: CGS is "Credential Governance Service" by the same pattern; no file spells it out in full.
- Suggested fix: write the full names in the first column of the components table, for example "ARS (Artifact Registry Service)", and move the table, or a one-line glossary, above the walk-through so the acronyms are defined before they are used.

### Nit

**N1. The kept "Current Mode" paragraph is jargon in the newcomer section.** `README.md:82-86` ("bounded platform with explicit reopened seams", "rewrite-by-default is no longer the operating stance") repeats `README.md:65` in contributor language. Moving it under "Where To Start" at the bottom keeps the text word for word and leaves "Current status" plain. No test pins it (checked: `docs_contract_test.go:4652-4687` pins two other sentences only).

### Pre-existing (not introduced by this PR)

**P1. Broken link for outsiders.** `README.md:172` links `../Control%20Plane/.docs/long-running-operator-mode-contract.md`, a path outside the repository, so it 404s on GitHub. It was already in the base README (base line 87). The pinned sentence in that paragraph is the following one, not the link. Optional in this repair round: show the path as code text naming the Control Plane repository instead of a link. Owner: whoever repairs this PR, if the coordinator wants it now.

**P2. Out of scope, for the coordinator: home-network addresses elsewhere in public ES.** The README itself is clean, but the public tree at `76c030f` contains `[home network address withheld]` (the Linux test box's LAN address) 27 times, mostly in `remote_alpha_*_test.go`, `.docs/system_overview/remote_supported_host_alpha.md` and `scripts/remote_alpha_operator.sh`, and `/Users/ds/Repositories` 8 times (`git grep -c -E "192\.168\.[0-9]+\.[0-9]+" 76c030f`). A private LAN address is not reachable from the internet, so the risk is low, but it is the kind of value the brief asked to keep out of public ES. I did not find it in the infra security audit's findings. Suggest a separate cleanup thread if David wants it.

## What I checked

### (1) Every claim about current behaviour, at `76c030f`

| README claim (tip line) | Verdict | Source |
| --- | --- | --- |
| ES decides whether an exact published package may run, runs it through Nomad and Docker, reports what is known (3-5) | True | `.docs/system_overview/architecture.md:31-33`, `:109-122` |
| "any vendor's AI agent" aim marked as a goal, not a current capability (7-10) | Correctly framed | Strategic target (project instructions, "Mission"); no repo claim made |
| Publish: archive plus declared needs (environment variables, network access) to AGS; AGS signs evidence and stores both in ARS (41-44) | True | `.docs/system_overview/contracts.md:332-382` (env allowlist, `network_access`, payload, evidence, upload through ARS); example payload is a `.tar.gz` (`.examples/execution_loop/static_script_success.input.json`) |
| Admit: ES reads package and evidence from ARS and checks them against EGS trust; missing or corrupt evidence is refused; `prepare` checks without starting anything; `submit` checks then hands off (45-49) | True, with L1 | `architecture.md:115-118`, `:130`; `.docs/execution_lifecycle/contracts.md:233-234` (prepare "without creating execution state", submit hands off to Nomad); timing: L1 |
| Run: Nomad starts a Docker container; a workload logs in to Vault with a SPIRE identity; ES does not handle its tokens or secrets (50-53) | True | `architecture.md:204-217`, `:245-246`; `.docs/system_overview/runtime_identity_handoff.md` section 2 |
| Observe: status, logs, retained result, cancel through ES; status derived from Nomad; cancel is a request (54-56) | True | `.docs/execution_lifecycle/contracts.md:235-238` (endpoint inventory); `architecture.md:136`; claim ledger C9 and G-08 |
| All five services require mutual TLS on every connection; routes that check callers read a SPIFFE ID and allow only configured identities (58-61) | True | `ClientAuth: tls.RequireAndVerifyClientCert` in `ars/app/app.go:144`, `ags/app/app.go:129`, `egs/app/app.go:146`, `cgs/app/app.go:116`, `es/app/app.go:131`, each served only through a TLS listener; `contracts.md:139-142` ("including on `/health`") and `:214-216` (each service owns its allowlist) |
| Works today on one Linux host or VM with Nomad and Docker on the same machine; CI builds, vets and tests on every PR (67-69) | True | `architecture.md:81-83`; `.github/workflows/go.yml:8-12` (`pull_request:` with no filter). CI skips the tests listed as environment-only, which the README need not say |
| No real AI coding agent has run end to end; agent path uses a proof-only Codex stand-in; live agent proof is gap G-06 (70-75) | True | `.docs/supported_local_cp_consumer_runbook.md:103`; `.docs/commercialization/claim-ledger.md:208` |
| Not claimed: production readiness, HA, multi-tenant, general remote deployment, complete fresh-host installer (76-78) | True | `.docs/mvp.md:80-87`; fresh-host point from the kept README paragraph (`README.md:165-168`) |
| Components table (92-100) | True | `architecture.md:25-33`, `:142-145`, `:198`; SPIRE and Vault roles `architecture.md:76-79` |
| Words used here: workload, admission, evidence, retained result (110-118) | True | `contracts.md:352-382`; kept text `README.md:150-156` |
| Prerequisites line: Linux host or VM, Docker, Nomad, curl, python3, tar, gzip, TLS material and config; Mac uses an Ubuntu VM (122-125) | True | `.runbooks/system/v1_bringup.md:35-49`, `:75`, `:222`; Go is built inside Docker (`scripts/generate_control_plane_dockerfile.sh:32-48`), so it is rightly not listed |

No planned capability is presented as current. Where SPIRE and Vault run: the supported-local setup boots "proof-scoped real SPIRE server/agent" and a "proof-scoped real Vault dev/test target" on the same guest (`v1_bringup.md:227-228`), which matches the diagram placing them on the host.

### (2) Diagram

- Parses and renders with Mermaid 12.3.0 (npm `mermaid@12.3.0`, Chromium through Playwright, `securityLevel: strict`, 838 px column): 442 px tall, all 10 nodes and 9 edge labels present. Screenshot: [mermaid-0.png](readme-es-pr36-audit-evidence/mermaid-0.png). Render script: `readme-es-pr36-audit-evidence/render.cjs`.
- Matches the topology in `architecture.md:49-57` (publish caller -> AGS -> ARS; ES -> ARS, EGS, Nomad -> Docker). CGS is left out on purpose and the text says it is not on the run path (`architecture.md:198`).
- I could not open github.com's renderer from this container (viewscreen.githubusercontent.com is blocked). The writer reports checking it on github.com at `555ee47`; I did not repeat that.

### (3) Kept text, links, pinned tests

- Kept text: 61 of 73 non-empty base lines are present verbatim. The other 12 are the opening sentence (now `README.md:104-106`, reworded), the service list and the Nomad/Docker sentence (now the intro and components table), the "Current Mode" heading and its two lines (present verbatim inside one paragraph at `README.md:82-86`), and the last line, where "above" became "below" because the index moved under it, which is correct. Check output: `readme-es-pr36-audit-evidence/kept-lines-check.txt`.
- Links: every in-repo link and the `#current-status` anchor resolve at the tip (`links-check.txt`). One link points outside the repo (P1, pre-existing).
- Pinned tests: `docs_contract_test.go:4652-4687` (`TestSupportedLocalCPConsumerRunbookPreservesControlPlaneBoundaries`) is the only test that reads `README.md` (searched all `.go`, `.py`, `.sh` and `.yml` files). Its two README sentences are at `README.md:137` and `:172`, unchanged.
- No other repo cites ES `README.md` line numbers (searched the trunk_dev of ES, Coordinator, MA, IM, Bridge-Core and Archived-Runbooks main).

Commands (Go 1.26.5 downloaded through `GOTOOLCHAIN=go1.26.5`, `GOFLAGS=-mod=readonly`, run as root in the cloud container, on the exact tip bytes):

```text
go test -count=1 -run '^TestSupportedLocalCPConsumerRunbookPreservesControlPlaneBoundaries$' -v .
  --- PASS (0.00s); ok execution-substrate 0.008s

go test -count=1 -json .          # whole root package, tip and base (fresh clone at 76c030f)
  tip:  2016 pass, 242 fail
  base: 2016 pass, 242 fail
  failing sets identical (diff empty); all 143 tests in docs_contract_test.go pass at the tip
```

The 242 failures (34 top-level tests, all `TestRemoteAlpha*` script tests) fail identically at the base. Inference: they are environment-only failures from running as root in this container, as seen in earlier ES audits; I did not investigate them further because the PR changes no code. Lists: `root-tip-fails.txt`, `root-base-fails.txt`, `root-tip-fails-top.txt`; raw JSON gzipped beside them.

GitHub CI on the PR ("build, vet and test", run 45260873582) was still in progress at 20:57Z; I did not wait for it.

### (4) Readability

Good: one plain paragraph, a left-to-right diagram, a numbered walk-through, an honest status list, and the agent index at the bottom, as the norm asks. Gaps: L2 (acronyms) and N1 (jargon paragraph).

### (5) Secrets and private addresses

The new README holds no IP address, hostname, user path, key, token, e-mail or phone number (`grep` over the added lines and the whole file). Out-of-scope observation: P2.

## Repair brief (one round, docs-only, `README.md` only)

1. L1: add "ES loads that trust once, when it starts." to step 2 (and optionally the edge label).
2. L2: spell out ARS, AGS, EGS and CGS in the components table and define them before the walk-through uses them.
3. N1: move `README.md:82-86` verbatim to "Where To Start".
4. Optional, coordinator's call: P1.

Keep the two pinned sentences unchanged and re-run the pinned test. A narrow re-audit of the delta is enough.

## Report fields

- Touched files: none in any repo. Wrote this report and `readme-es-pr36-audit-evidence/` (SHA256SUMS.txt inside).
- Assumptions: the base for every repo fact is `76c030f`; "current behaviour" means what that commit's code and owning docs say.
- Guesses and inferences: marked inline (CGS expansion; nature of the 242 environment-only failures).
- Skipped validation: github.com rendering (blocked here; writer-reported); the PR's CI run (not finished when I closed).
- Authority or security widening: none. The PR changes documentation only.
- Confidence: provenance high (three identical manifests, blob hash match); factual review high for the new top section, which I checked claim by claim; readability judgement medium (one reader's view).

## Re-check 1: tip `3efe715` (2026-11-23 21:01Z to 21:10Z)

Verdict: **ACCEPT**. Merge after green CI (the "build, vet and test" run 45265112120 on `3efe715` was in progress at 21:09Z).

Target: base `76c030f` (unchanged), tip `3efe715829294a81fae8d3f703c3c948772ebbfc` (fast-forward from the audited `555ee47`, one commit, `README.md` only), tree `6e0bb469b5b4b0bd4c7ec64a76013658033540ed`. Base-relative v2 manifest taken twice, identical, and again at closeout, identical: canonical-manifest SHA-256 `abb6285002d40a0601af865d1aecf92e94ae5e639c424dba41d8e1e86c28c578`, textual_diff_sha256 `5a0bbf683b804ff3c51c074bf9d4b9ad3a7d67c48f22e4d9d96e1f5905dee042`, 1 file (`README.md`, sha256 `c460fc53…0994`, size 12752; equals the committed blob). Copy: `readme-es-pr36-audit-evidence/manifest-r1-3efe715.json`.

| Finding | Status | Evidence at `3efe715` |
| --- | --- | --- |
| L1 trust loaded at startup | Fixed | Step 2 adds "ES loads that trust once, when it starts."; the edge reads `read trust<br/>at startup` |
| L2 acronyms | Fixed | A sentence after the diagram spells out ARS, AGS, EGS and ES; the table's first column does the same, and gives CGS as "(credential governance)", which avoids claiming a full name no file states |
| N1 jargon paragraph | Fixed | Moved word for word under "Where To Start" |
| P1 broken CP link | Fixed | The path is now code text with "(a separate repository, so it is not linked from here)"; the pinned sentence after it is unchanged |

Checks on the exact tip bytes: `TestSupportedLocalCPConsumerRunbookPreservesControlPlaneBoundaries` PASS (Go 1.26.5); the only test that reads `README.md` is unchanged since the first audit. All 22 links and anchors resolve, including the new `#components`, and none leaves the repo. The diagram still renders with Mermaid 12.3.0 (442 px). The delta adds no address, path or secret. New wording checked against the same sources as in the first audit (`es/admission/service.go:285-300`; the `*/api/server.go` service names). Cosmetic only: one source line in step 2 is longer than its neighbours; it renders the same.

## Re-check 2: provenance only, tip `4382b71` (2026-11-23 21:30Z)

**Still ACCEPT.** `4382b717ce37aec26a38377e951264724722a407` is a merge commit with parents `3efe715` and trunk_dev `fdfa3bc` (#29). `README.md` is byte-identical to the accepted `3efe715` (sha256 `c460fc53216a910d927294e182d77d05d39a5b29859af3d3765ce6715a380994`), and it is the only file that differs from `fdfa3bc`. #29 did not touch `README.md`. A fresh-clone v2 manifest against `fdfa3bc`, taken twice, gave identical results that match the writer's numbers: manifest SHA-256 `2671ea5f90bffff9b3b60816f19307750857b89da0b8df21042bce00958167ed`, textual_diff_sha256 `5a0bbf683b804ff3c51c074bf9d4b9ad3a7d67c48f22e4d9d96e1f5905dee042` (the same as re-check 1), 1 file, and the blob hash matches. The pinned test passes on `4382b71`, and a trial merge with #37 `a72cb7e` is clean. Copy: `readme-es-pr36-audit-evidence/manifest-r2-4382b71.json`.
