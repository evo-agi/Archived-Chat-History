# Audit: Infrastructure-Manager PR #2, README for newcomers

Verdict: **REPAIR NEEDED** (4 Low findings and 2 Nits, all small wording fixes in `README.md`; nothing High or Medium; provenance, tests and the secrets scan pass)

Auditor: fresh read-only audit thread, 2026-11-23 20:37Z to 21:00Z. Nothing pushed, no PR comment posted.

## Target

| Field | Value |
| --- | --- |
| Repo | evo-agi/Infrastructure-Manager (private) |
| PR | [#2](https://github.com/evo-agi/Infrastructure-Manager/pull/2), draft, into `trunk_dev` |
| Topic branch | `claude/project-thread-no8fj8` |
| Base (trunk_dev, re-checked at closeout) | `e6080caf631cc22113f675068cf4335b321fa56d` |
| Tip (re-checked at closeout) | `e924dd5a2f10c721925cae032a9899c429ea33c4` |
| Tip tree | `626d3680b8a024b7cbc805640ba0a8d1c04965ae` |
| Changed paths | `README.md` only (76 additions, 5 deletions, 2 commits) |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before each run) |
| textual_diff_sha256 | `f5c0adaf9d946b7359c5a56ece2b4dc2e50239b298641fa500a9e5cb2b1cff34` |
| Canonical manifest SHA-256 | `148b2738d700190c7d4ba497f9d191b847db68f57c2beb25ad58ed31b48a328a` |
| File count | 1 |

Canonical manifest:

```json
{"branch":"claude/project-thread-no8fj8","files":[{"file_type":"regular","kind":"tracked_modified","mode":"0644","path":"README.md","sha256":"6d746997f66b826264bb88de812f125eb27252ceeac393a35bac977b29e37e92","size":8867}],"head":"e6080caf631cc22113f675068cf4335b321fa56d","recipe_id":"governed-execution.audit-patch-manifest.v2","textual_diff_sha256":"f5c0adaf9d946b7359c5a56ece2b4dc2e50239b298641fa500a9e5cb2b1cff34","upstream":"origin/trunk_dev"}
```

## Provenance

- The writer reported no manifest, so I took the base-relative manifest under provenance §5.3 (fresh clone, `umask 022`, topic at the tip, `git reset --mixed` to the base, upstream pinned to `origin/trunk_dev`), twice into a fresh mode-0700 directory: byte-identical. `e924dd5:README.md` hashes to the manifest's `6d746997…7e92`.
- Closeout: tree unchanged (`git status --porcelain --ignored` shows only `README.md`; tests ran with `PYTHONDONTWRITEBYTECODE=1`), and a third run equals the opening manifest byte for byte.
- Docs-only, so not in the sensitive list (procedures.md, "Audits"). This manifest is the target identity for the merge gate.

## Findings

### Low

**L1. Step 2 says CP reaches the ES services "by their internal HTTPS names". It does not: CP talks to local `127.0.0.1` bridge addresses.** Type: doc bug (factual).
- README: `README.md:38-39`.
- Repo fact at `e6080ca`: the profile IM writes for CP uses `ags_base_url=https://127.0.0.1:<bridge port>` and `es_base_url=https://127.0.0.1:<bridge port>` (`src/infra_manager/adapters/execution_substrate_supported_local.py:285-292`, `host_resolution_mode="local_tls_sni_bridge"` at `:299`). The README's own kept section says the same: bridge endpoints on `127.0.0.1`, a bridge certificate for `localhost` / `127.0.0.1`, and the internal name used only on the upstream leg (`README.md:146-155`). The bridges exist because CP's client cannot use the internal names (`README.md:144`).
- Suggested fix: "`up` then starts SSH forwards and small local TLS bridges. CP on the Mac talks to AGS and ES through the bridges at `127.0.0.1`, and the bridges connect onward under ES's internal HTTPS names (see [Host Resolution And TLS](#host-resolution-and-tls))."

**L2. "What you need" leaves out the Temporal CLI, and `openssl` and `ssh`.** Type: doc gap (a newcomer following the list hits a failure on first `up`).
- README: `README.md:62-69`.
- Repo fact: `up` runs `temporal server start-dev` unless something already listens on `127.0.0.1:7233` (`src/infra_manager/adapters/temporal_dev.py:34-87`, check at `:44`, command at `:62`). `up` also requires `python3`, `openssl`, `ssh` and `limactl` on PATH (`src/infra_manager/adapters/execution_substrate_supported_local.py:74-79`). `openssl` and `ssh` ship with macOS; the Temporal CLI does not.
- The operator runbook has the same Temporal gap (`.docs/supported-local-operator-runbook.md:111-112` lists `python3`, `openssl`, `ssh`, `limactl` only). That is pre-existing; fixing it there too is docs-only and in scope for the same repair if the coordinator agrees.
- Suggested fix: add a bullet "The [Temporal CLI](https://docs.temporal.io/cli) (`temporal`), unless a Temporal server already listens on `127.0.0.1:7233`; `up` starts a local dev server with it." and name `openssl` and `ssh` beside Lima.

**L3. "The `postgres` commands ... touch no Docker, database, network or host" is too broad: they write files on the local host.** Type: doc bug (factual).
- README: `README.md:57-58`.
- Repo fact: `postgres plan` writes `.out/postgres/<resource-id>/plans/<plan-digest>.json` (`.docs/commands.md:105-110`; default `--output-root .out/postgres` at `src/infra_manager/cli.py:688`). The kept text lower down is precise: "no Docker, PostgreSQL, network, process, credential, ES, or remote-host operation" (`README.md:120-121`).
- Suggested fix: "They write plan and inspection files under `.out/postgres/` and touch no Docker, database, network or remote host."

**L4. "`profile` prints that profile": it prints a summary of it.** Type: doc bug (small).
- README: `README.md:41-42`.
- Repo fact: `_cmd_profile` prints the instance, the profile path, whether it is directly runnable, the host-resolution mode, the AGS, ES and Temporal endpoints, and notes (`src/infra_manager/cli.py:225-248`); `--json` prints the same summary as JSON; `--output` writes a copy of the profile. `.docs/commands.md:54` says "Prints the resolved profile summary".
- Suggested fix: "**`profile`** prints a summary of that profile: where it is, whether it is usable right now, and the endpoints it points at."

### Nit

**N1. "It writes no CP profile until ES reports submit-ready" holds only by default.** `README.md:36-37`. `--es-readiness-profile prepare-only` lets `up` write a profile without submit-ready (`src/infra_manager/cli.py:651-659`, default `full`; `.docs/commands.md:42`). Suggested: "By default, it writes no CP profile until ES reports submit-ready."

**N2. A newcomer is not told what Control Plane is.** `README.md:5` names it and the diagram says "(separate repo)", but nothing says what it does. A citable one-liner exists in ES: "CP is the MVP UI and orchestration layer" (ES `.docs/commercialization/claim-ledger.md:127`, citing ES `.docs/mvp.md:104-169`). Suggested: "Control Plane (CP), the MVP's UI and orchestration layer (a separate repository), on the Mac connecting to it."

### Pre-existing (not introduced by this PR)

**P1. Broken link.** `README.md:60` links `../Control%20Plane/.docs/long-running-operator-mode-contract.md`, outside the repository, so it 404s on GitHub. Same link at base line 9. The pinned sentence is the one after it, not the link.

**P2. David's Mac user path in the README.** `README.md:163-164` (`/Users/ds/Repositories/...`), unchanged from base lines 96-97; also in `.docs/supported-local-operator-runbook.md:91-99`. IM is private, so it is not exposed today. The code default is the IM checkout's sibling folders (`src/infra_manager/config.py:59-77`), so the section could say "next to this repository" without the user path. Low priority; worth fixing before IM is ever made public.

**P3. Tracked build output.** `src/infrastructure_manager.egg-info/` (5 files) is tracked on `trunk_dev`. Classification: setuptools build metadata, generated, not secret. Outside this PR; flagged because procedures.md asks audits to flag egg-info.

### Open question for the coordinator (not a finding against this PR)

The project treats CP as the retired MVP orchestrator (project-context `repos.md`, a chat-decided fact), but neither IM's docs nor this README say so: they describe a working CP-to-ES environment, which is what IM's code still does. The README is faithful to the repo, as procedures require. Whether IM's README should tell outsiders that CP is retired is a direction call for David or the coordinator, not something an audit should write in.

## What I checked

### (1) Every claim about current behaviour, at `e6080ca`

| README claim (tip line) | Verdict | Source |
| --- | --- | --- |
| Small Python CLI; sets up, checks and tears down one local environment: ES in a Linux VM on a Mac, CP on the Mac (3-6) | True (N2 on CP) | `pyproject.toml` (`infra-manager` script); `.docs/commands.md:7-92`, `:814-828` |
| Writes the CP profile, runs CP's own checks, records evidence (6-7) | True | `.docs/commands.md:24-27`, `:69-80` |
| Read-only commands collect evidence about one remote Linux test host, Remote Alpha (7-9) | True | `.docs/commands.md:250-372` (read-only SSH and HTTPS GET probes), `:597-598`, `:711`, `:734`, `:783-784` |
| `up` starts or reuses Temporal, copies the ES checkout into the VM, runs ES setup, bring-up and readiness; no profile until submit-ready (34-37) | True (N1) | `.docs/supported-local-operator-runbook.md:137-148` (snapshot staged into guest scratch); `.docs/commands.md:18-22`, `:40` |
| `up` starts SSH forwards and TLS bridges "so that CP ... can reach the ES services by their internal HTTPS names" (38-39) | **False** | L1 |
| `up` writes the profile, an env file and instance state under `.out/instances/<id>/`; `profile` prints that profile (40-42) | Paths true; "prints that profile" imprecise | `.docs/commands.md:24-27`; L4 |
| `check` runs CP preflight and contract probe; no workflow, no ES submit, no result fetch (43-44) | True | `.docs/commands.md:69-82` |
| `down` stops only what IM started (45) | True | `.docs/commands.md:820-826` |
| Scope: macOS with a Lima Ubuntu VM; not a general platform; no production-readiness claim (49-51) | True | `up` raises unless `platform.system()=="Darwin"` (`src/infra_manager/cli.py:172-173`, `adapters/execution_substrate_supported_local.py:666-669`); runbook non-goals pinned by `tests/test_long_running_contract_alignment.py:30-39` |
| Ownership sentence (52) | Kept verbatim from base line 5 | |
| Outputs are evidence, do not control runs (53-54) | True | `.docs/architecture.md` (pinned phrase in `tests/test_long_running_contract_alignment.py:21-22`) |
| `remote-*` commands only read and package evidence; no install, provision or repair (55-56) | True | Same rows as above; each command's "does not" paragraph |
| `postgres` commands only plan and inspect; "touch no Docker, database, network or host" (57-58) | "host" too broad | L3 |
| macOS with Lima; default instance `es-lima-qemu-arm64` (64-66) | True | `src/infra_manager/cli.py:640` |
| Python 3.11 or later, no third-party dependencies (67) | True | `pyproject.toml` (`requires-python = ">=3.11"`, `dependencies = []`) |
| CP and ES checkouts next to this repository (68-69) | True | `src/infra_manager/config.py:59-77` (siblings named "Control Plane" and "Execution Substrate") |
| Complete list of what you need (62-69) | Incomplete | L2 |
| The six Remote Alpha command names (105-108) | True, exact set | `src/infra_manager/cli.py:702-827` registers exactly these six `remote-*` subcommands |
| Documentation index lists all nine `.docs` pages (180-188) | True | `ls .docs` = 9 files, all linked |

No planned capability is presented as current.

### (2) Diagram

- Parses and renders with Mermaid 12.3.0 (npm `mermaid@12.3.0`, Chromium through Playwright, `securityLevel: strict`, 838 px column): 298 px tall; the nested `Lima Linux VM` subgraph with `direction LR` renders. Screenshot: [mermaid-0.png](readme-im-pr2-audit-evidence/mermaid-0.png). This repo is private, so neither the writer nor I could check github.com's own renderer; the local render uses the version GitHub uses.
- Matches the code: IM sets up ES in the VM, starts the bridges, writes the profile under `.out/instances/`, runs CP's checks; CP talks HTTPS with mTLS to the bridges, which forward to ES (`adapters/execution_substrate_supported_local.py:285-299`). The diagram is right where walk-through step 2 is wrong (L1). Temporal is not drawn; that is acceptable for a top-level picture.

### (3) Kept text, links, pinned tests

- Kept text: 78 of 81 non-empty base lines are present verbatim. The other three: the old opening sentence (replaced by the new intro, as the PR says), the ownership paragraph (verbatim, now after "**Ownership:**"), and the `.docs/` sentence (verbatim, now followed by an added sentence). Output: `readme-im-pr2-audit-evidence/kept-lines-check.txt`.
- Links: every in-repo link and the `#adjacent-repos` anchor resolve; `https://lima-vm.io/` is external; one pre-existing link leaves the repo (P1). Output: `links-check.txt`.
- Pinned README text: `tests/test_long_running_contract_alignment.py:15-28` (one README sentence, kept once and unchanged at `README.md:60`) and `tests/test_postgres_contract_alignment.py:21-63` (README read together with five docs). No test asserts that any phrase is absent from the README. `src/infra_manager/config.py:24-25` needs the ES checkout to have a `README.md`, which is unaffected.
- ES's claim ledger cites IM `README.md:1-100` for IM scope and ownership (ES `.docs/commercialization/claim-ledger.md:136`); those statements are now at lines 49-60, still inside that range.

Commands (Python 3.13.18, exact tip bytes):

```text
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src python3 -m unittest discover -s tests
  Ran 197 tests in 1.965s — OK
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src python3 -m unittest -v tests.test_long_running_contract_alignment tests.test_postgres_contract_alignment
  Ran 9 tests — OK
```

IM has no CI check runs on this PR (none configured).

### (4) Readability

Good overall: a plain opening, a short left-to-right diagram, a numbered walk-through, status bullets, a "What you need" list, and the agent index at the bottom. The four Low findings are the places where a newcomer would be misled or blocked; N2 is the one missing piece of context. Cosmetic: `README.md:49-51` wraps unevenly in the source; it renders fine.

### (5) Secrets and private addresses

No new IP address, hostname, user path, key, token, e-mail or phone number in the added lines. Existing `127.0.0.1`, `localhost` and `server.*.internal` names are loopback and in-certificate service names, not home-network values. Pre-existing user path: P2.

## Repair brief (one round, docs-only)

1. L1, L3, L4, N1, N2: the wording changes above, in `README.md`.
2. L2: add the Temporal CLI (and `openssl`, `ssh`) to "What you need"; with the coordinator's agreement, add the Temporal CLI to `.docs/supported-local-operator-runbook.md:111-112` in the same PR.
3. Optional, coordinator's call: P1, P2.

Keep `README.md:60` unchanged and re-run the 197 tests. A narrow re-audit of the delta is enough.

## Report fields

- Touched files: none in any repo. Wrote this report and `readme-im-pr2-audit-evidence/` (SHA256SUMS.txt inside).
- Assumptions: repo facts are read at `e6080ca`; "current behaviour" means that commit's code and owning docs.
- Guesses and inferences: none beyond the open question, which is labelled.
- Skipped validation: github.com rendering (private repo; local Mermaid 12.3.0 only).
- Authority or security widening: none.
- Confidence: provenance high; factual review high (each walk-through step checked against the code); readability judgement medium.

## Re-check 1: tip `6a15508` (2026-11-23 21:01Z to 21:10Z)

Verdict: **ACCEPT**. IM has no CI checks, so it can merge now under the docs policy.

Target: base `e6080ca` (unchanged), tip `6a15508b114703fd22de36f48d197aa4e489a87c` (fast-forward from the audited `e924dd5`, one commit), tree `9c988fd0df4db61ba374c300aa43fc332a5599bc`. Base-relative v2 manifest taken twice, identical, and again at closeout, identical: canonical-manifest SHA-256 `4161a94fb151764f31435a747593747aa8723d68b23edb160980162254fcef61`, textual_diff_sha256 `69170c20614167b0d02f4aeeabe138b09dc74d502d9fb84ea6c31bee9e78885c`, 2 files (`README.md` sha256 `a6b4b3f1…2e271`, size 9730; `.docs/supported-local-operator-runbook.md` sha256 `4c930666…ac586`, size 22556). Copy: `readme-im-pr2-audit-evidence/manifest-r1-6a15508.json`.

| Finding | Status | Evidence at `6a15508` |
| --- | --- | --- |
| L1 bridges at 127.0.0.1 | Fixed | Step 2 now matches `adapters/execution_substrate_supported_local.py:285-299` and links Host Resolution And TLS |
| L2 Temporal CLI, openssl, ssh | Fixed | "What you need" lists them. The runbook's tools sentence (`.docs/supported-local-operator-runbook.md:111-114`) adds the Temporal CLI too, matching `adapters/temporal_dev.py:44-73`. No test pins that sentence (searched `tests/`) |
| L3 postgres writes files | Fixed | "They write plan and inspection files under `.out/postgres/` and touch no Docker, database, network or remote host." |
| L4 `profile` prints a summary | Fixed | Matches `src/infra_manager/cli.py:225-248` |
| N1 "By default" | Fixed | |
| N2 what CP is | Fixed | "the MVP's UI and orchestration layer, kept in a separate repository" (ES claim ledger E1) |
| P1 broken CP link | Fixed in README | Now code text; the pinned sentence after it is unchanged. The runbook's 5 cross-repo links (to `../../Control%20Plane/…` and `../../Execution%20Substrate/…`) are pre-existing and untouched |
| P2 user path | Fixed in README | Adjacent Repos now describes the discovery rule instead of `/Users/ds/…`; checked against `src/infra_manager/config.py:59-77` and `:116-129` (exact name first, else the first folder in name order whose name, with spaces as hyphens and ignoring case, contains `control-plane` / `execution-substrate`) and `cli.py:889-894` (`cwd=Path.cwd()`). The runbook example keeps the path, which the writer left out of scope; IM is private |
| P3 tracked egg-info | Left out of scope by the writer | Unchanged; not a blocker |

Checks on the exact tip bytes: `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src python3 -m unittest discover -s tests`: 197 tests, OK. All README links and anchors resolve (`#host-resolution-and-tls` is new); two external links (lima-vm.io, docs.temporal.io/cli). The delta adds no address, user path or secret.
