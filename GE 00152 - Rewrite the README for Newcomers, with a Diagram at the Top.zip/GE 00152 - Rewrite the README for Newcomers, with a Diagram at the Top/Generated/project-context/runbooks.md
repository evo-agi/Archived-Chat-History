# Runbooks

Kind: procedure file (binding; changes only the way the project instructions do). Writer: the coordinator.
Status: CURRENT, 2026-11-23. Moved from the project instructions, "Runbook norm" (source: current-instructions.txt); in effect since the new instructions were applied at 2026-11-23 19:24Z.

When to write a runbook, and the grant to push it with its conditions, stay in the project instructions. This file holds where and how.

- Runbooks go in evo-agi/Archived-Runbooks. When a session changes the Linux test box, add a History line in "Governed Execution Remote Alpha Claude Access".
- Archived-Runbooks is an interim home for runbooks (David 2026-11-22 20:26Z), kept until David and the coordinator find a better solution; it is not a settled norm.
- Push straight to `main` without asking, after a leak scan, a link/rendering check, and a note on what was and wasn't run (this grant and its conditions are authoritative in the project instructions, "Effects").
- Product contracts stay in their own repos.
- Exception, product runbooks (David 2026-11-23 20:48Z): runbooks that show outsiders how to use a public product (today ES's `.runbooks/execution/`, named `Governed Execution ES <Topic>.md`) are maintained in that product repo. Archived-Runbooks holds copies with a top note that the repo version is maintained and wins if they differ; a scheduled check (Archived-Runbooks PR #4) fails on drift, a missing note or a missing copy. Edit the product repo first, then refresh the copy. ES `.runbooks/system/v1_bringup.md` stays in ES under its name (ES tests, scripts and IM read that path).
- If a push to Archived-Runbooks `main` is blocked by the tool's safety check, open a PR and ask David to merge it (see claude-limitations.md).
- Format: the README section "Adding a runbook". Full scripts with an editable settings block at the top, like the recovery runbook.
