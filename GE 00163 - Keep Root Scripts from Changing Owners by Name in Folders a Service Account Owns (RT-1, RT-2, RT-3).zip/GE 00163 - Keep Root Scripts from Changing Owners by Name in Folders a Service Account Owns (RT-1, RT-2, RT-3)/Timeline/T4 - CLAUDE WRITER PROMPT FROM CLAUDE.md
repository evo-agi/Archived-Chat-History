Thanks, good run. Please go ahead with the RT-1/RT-2/RT-3 scripts-only fix PR from trunk_dev as described earlier. Don't merge it without my turn signal, because PR 12 and #48 merge first.
