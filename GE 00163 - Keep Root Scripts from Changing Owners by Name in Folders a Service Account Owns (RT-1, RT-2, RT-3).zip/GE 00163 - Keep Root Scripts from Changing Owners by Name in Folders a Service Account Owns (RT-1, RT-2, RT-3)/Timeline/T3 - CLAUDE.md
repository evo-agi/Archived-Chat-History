I don't know yet. The names are Remote Alpha specific, but I haven't checked how much of them really is. Inference: the host-hardening parts are fairly generic (service accounts, Vault, SPIRE, Nomad, firewall), and the box-specific parts are mostly addresses and paths. That matches the IP and path cleanup already on the backlog.

This matters for the product, since "hardware the owner controls" means other people's boxes. I've added a review to the backlog for after the quota squeeze: what's reusable, and what a general bring-up would look like. These fixes would carry over to it either way.

STATUS: WORKING (fixes, merge queue, box runs)
