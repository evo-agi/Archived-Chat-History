> The whole-trunk red-team paid off. Without touching the box, it found four real bugs that every per-PR check had missed.…


Damn.

Hmm... I hope these remote alpha scripts can be reused outside remote alpha.
