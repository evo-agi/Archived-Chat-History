# PR #12 takes up trunk_dev 8ba1edb: merge for a provenance check

Writer: the PR #13 thread. Date: 2026-11-23, 19:2xZ.

## 1. In plain words

- **Why.** PR #26 merged into `trunk_dev` as `8ba1edb`, and PR #12 (`2c8bf35`) then conflicted with `trunk_dev`.
- **The change.** Draft PR #32 (https://github.com/evo-agi/Execution-Substrate/pull/32) holds one merge commit, `4416699`. Its tree is `052d1024`, the same tree as the trial merge in `04-repair.md`, which audit 24 reproduced.
- **Next.** A narrow provenance check. Then PR #12's branch fast-forwards to `4416699`, as it did for PR #28.

## 2. Target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Branch | `claude/project-thread-ne9cwa-pr12-trunk-dev`, into `codex/reliable-submit-operational-handoff-v1` (PR #12's branch) |
| PR #12 head | `2c8bf35f30877bc3749b1799be686bf108a1cf8d` (CI green, 17:12Z) |
| `trunk_dev` | `8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce` (PR #26) |
| Merge base | `036d50724b499b020c5149c55ad902cfcb1482c0` |
| Merge commit | `44166998d4ef0d7b86152f3f66265b906f7d612a`, tree `052d102465743ce673a34f3805100b29f2d142c5`, parents `2c8bf35` and `8ba1edb` |

## 3. The merge

- **What `trunk_dev` brings.** Since `036d507`, PR #26 only. It changes test files only: `es/admission/producercontract_test.go`, `workstream_a_guardrails_test.go`, `workstream_b_guardrails_test.go` and `workstream_c_guardrails_test.go`.
- **One conflicting file.** `workstream_a_guardrails_test.go` conflicts in the two blocks named in PR #26's plan. Each keeps PR #12's `source:` line and adds PR #26's `node:` and `syntax:` lines (`resolution-cc.diff`).
- **How I resolved it.** I took that file from the trial merge `356317c` (`a88467f` into `2c8bf35`). That is valid because `8ba1edb` has the same tree as `a88467f`, and the merge base is the same, `036d507`. So the three-way inputs are identical.
- **The other files** merge cleanly.
- **No follow-up commit.** `trunk_dev` brings no new file, so no guard or file count of PR #12's needs a change.

## 4. Checks

- **Tree equality.** The merge's tree is `052d102465743ce673a34f3805100b29f2d142c5`, the same as trial `356317c` (`vs-trial26d.txt`).
- **Checks on that tree, already run:**
  - `04-repair.md` section 5: build, vet and gofmt are clean, and es/admission gives 2,532 pass, 13 skip and 0 fail;
  - audit 24 section 6: the same tree, from the auditor's own resolution script, gives 2,537 pass, with passwordless sudo.
- **Paths.**
  - PR-relative (against `2c8bf35`): the 4 test files above.
  - Trunk-relative (against `8ba1edb`): 56 paths, the same 56 as PR #28's (`trunk-relative-paths.txt`, `pr28-trunk-relative-paths.txt`).
  - Outside the four test files, every path's blob equals its blob at `2c8bf35`.
- **CI.** CI for PR #32 is on GitHub.

## 5. Provenance manifests

v2 recipe (SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`), on a clean tree at the pushed tip (`prov12m.sh`). Each manifest was written twice, byte-identical, and the staged tree equals `052d1024`:

| Manifest | Base, upstream pinned to | Files | Manifest SHA-256 | Textual diff SHA-256 |
| --- | --- | --- | --- | --- |
| PR-relative | `2c8bf35`, `origin/codex/reliable-submit-operational-handoff-v1` | 4 | `4ab0ddab84c421805b27f9826e66913950b502aec6f3cab3257a6a6d0e2cecbc` | `311895fba861b82986c9cab6e3f58492595ceca31e98f56dc85c77e3fb4b2328` |
| Trunk-relative | `8ba1edb`, `origin/trunk_dev` | 56 | `86ff064d4402ed9d1301c82c2bbe6d7f1aa51aa6bd96a9c838bd3f56334987b0` | `195940692a9142c33c23bef5d88c23c793ab24ade3a8491bdd66fbe602f90c70` |

## 6. Not claimed

- The provenance check is still to come.
- Nothing ran on macOS.
- PR #12's own red-team and merge gate into `trunk_dev` are still ahead.

## 7. Evidence

`25-pr12-trunk-dev-8ba1edb-evidence/`, with `SHA256SUMS`:

- the commit;
- the conflict before resolution and the resolution as a combined diff;
- the tree equality with the trial;
- the path lists;
- the manifests and the script.
