# PR #12 repairs after the third red-team and the guard coverage review (RT28-1, RT28-2, G28-1, G28-2), with `trunk_dev` `fdfa3bc`

Status of this file: **IMPLEMENTATION REPORT, NOT AUDITED.** It covers eight commits after `4416699`, on draft PR [#40](https://github.com/evo-agi/Execution-Substrate/pull/40) into PR #12's branch. `28-redteam.md` and `28a-guard-coverage.md` are the reports that asked for them.

Written by the PR #13 writer thread on 2026-11-23 (UTC). Readers: the coordinator, David, the auditor, and the red-team thread, which re-checks RT28-1 and RT28-2.

---

## 1. In plain words

1. **RT28-1: Nomad no longer changes what a caller asked to run.** Nomad's client treats `${...}` and `%{...}` in every argument and mount of a task as a small template language, and replaces `${name}` in every environment and meta value. So a caller's argument `${attr.unique.hostname}` ran as the node's host name while ES recorded and bound the text, and an unterminated `${` failed a task that ES had already accepted. ES now refuses `${`, `%{` and a NUL byte in each string it places in a job: `output_id`, every argument, every environment key and value, and every mount target. The ordinary path answers `400 invalid_request`. The private path takes no claim and no reservation, and sends nothing. Both use the same validation, so they cannot drift. Other control bytes are passed on as written.
2. **RT28-2: a request too large for a Nomad job no longer takes a claim.** Before, ES built the job only after the claim was stored and the run assigned. A request whose job was larger than 65,536 bytes then failed forever, and four of them closed the domain. ES now builds the job and the POST body before the claim, with names of the lengths every run has, and refuses a request that does not fit as malformed. The job bound stays measured on the form Go's `encoding/json` writes, which is never shorter than the job Nomad returns. I tried the canonical form instead, and it was wrong (section 4.2).
3. **G28-1 and G28-2: the auditor's proposal, unchanged.** Every non-test Go file may hold only the `//go:` directives of a reviewed list, today `//go:build` alone, so `//go:cgo_import_dynamic` is refused. Six more cases pin the import inventory.
4. **The red-team's tests are adopted unchanged**: the regression tests first, the finding tests after the fixes. Both finding tests fail before the fixes and pass after.
5. **`trunk_dev` is merged in twice**: `fdfa3bc` (PR #27 and PR #29), with one conflict in `PLANS.md` where both entries are kept, and then `400ff7f` (PR #36, the README), which moved during this round. PR #29's blob-read guard passes on the merge.
6. **Not done: the Nomad token on the three private requests (N-1).** PR #31 is still a draft. Its guard fails on whichever of the two PRs lands second, so the fix cannot be forgotten.
7. **The path ceiling of PR #12 plus its repairs goes from 56 to 66 files.** An owner reconciliation paragraph names the ten new paths, and it is pinned like the earlier ones.
8. **RT28-1 still needs a live check on the test box** (section 8). My reading of Nomad's source has not been run against a real Nomad.

The first full run of the new head caught three things the new code broke, all in guards that exist for exactly that (section 4.6). They are fixed in the commits above; nothing was pushed before.

## 2. Identity

| Field | Value |
| --- | --- |
| Objective | Close RT28-1 and RT28-2 (`28-redteam.md`) and G28-1 and G28-2 (`28a-guard-coverage.md`), adopt the red-team's tests, take up `trunk_dev` `fdfa3bc` |
| Repository | `evo-agi/Execution-Substrate` |
| Base | `codex/reliable-submit-operational-handoff-v1` (PR #12) at `44166998d4ef0d7b86152f3f66265b906f7d612a`, the red-team's target |
| Topic branch | `claude/project-thread-ne9cwa-pr12-trunk-dev`, draft PR [#40](https://github.com/evo-agi/Execution-Substrate/pull/40) into PR #12's branch |
| Head | `fd399a12b5fc8319d403de471bb3ce42446f350c`, tree `dc6e1b6ea6ea34c4fb22020e06f27957a12a3754` |
| `trunk_dev` | `400ff7faa0f124b10dbb607fbad009e346bac4df` (PR #36), fetched again before the push and before the manifests; the round started from `fdfa3bc` (PR #29) |
| Scope | 66 paths against `trunk_dev` (56 before); the ten new ones are listed in section 4.5 |
| Toolchain | Go 1.26.5 (`GOTOOLCHAIN=local`), linux/amd64 container, unprivileged user `ci`, emptied environment |
| Recipe | `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run |

Commits, oldest first:

| Commit | What |
| --- | --- |
| `39f6872` | Merge `trunk_dev` `fdfa3bc` into PR #12 |
| `9116a46` | The red-team's regression tests, unchanged (`28-redteam-regression-tests.patch`) |
| `39e6eb7` | RT28-2: refuse a private request too large for a job before it takes a claim |
| `3ddbd2e` | RT28-1: refuse request strings that Nomad would not pass on as written |
| `8e6105c` | The red-team's finding tests, unchanged (`28-redteam-finding-tests.patch`) |
| `e121e2b` | G28-1 and G28-2: the auditor's `guard-directive-allowlist-proposal.diff`, unchanged |
| `d3af16a` | The owner reconciliation of the ten new paths, the `PLANS.md` entry and the docs pins |
| `fd399a1` | Merge `trunk_dev` `400ff7f` (PR #36, `README.md` only), which moved during this round |

"Unchanged" is checked, not assumed: each patch applied with `git apply --cached` to the commit's parent gives exactly the commit's tree (`adoption/adoption-check.txt`). The patches' SHA-256: regression tests `1e520116…d708`, finding tests `6e94a4f6…f648`, directive proposal `242c7444…dae4`.

## 3. The findings and where each is

| Item | Severity | What it asked | Where it is now |
| --- | --- | --- | --- |
| RT28-1 | medium | The argv, environment, output id and mounts that run must be the ones ES admitted | `nomadPassesAsWritten` in `service.go`, used by `validateInvocationAgainstManifest` for `output_id`, each argv element, each environment key and value, and by `normalizeRuntimeMountTargetPath` in `mounts.go` for each mount target (section 4.1) |
| RT28-2 | medium | A request too large for a job must not take a claim | `operationalProvider.fits`, asked by the handoff right after composing the original and before establishment; `reliablesubmit.OperationalLocatorShape` gives the names (section 4.2) |
| RT28-2 sub-point | — | The owner document said "canonical Job0 ≤65536", the code measured `encoding/json`'s form | The document now says what the code measures and why that measure is the safe one (section 4.2) |
| G28-1 | medium | Refuse `//go:` directives that need no import, such as `//go:cgo_import_dynamic` | The auditor's exact allowlist test in `workstream_c_guardrails_test.go` (section 4.3) |
| G28-2 | low | Pin dot imports, escaped and raw import paths and generated files | The auditor's six cases, same file |
| N-1 | report-only | The three private Nomad requests carry no token | Not in this round: PR #31 has not merged (section 5) |
| Red-team tests | — | Adopt `28-redteam-regression-tests.patch`, then `28-redteam-finding-tests.patch` | `9116a46` and `8e6105c`, unchanged |
| PR #29 thread | — | Re-run the blob-read guard and the root docs pins on the merge | Section 6.5: all pass |

## 4. What changed

### 4.1 RT28-1: one rule for every string ES places in a job

By reading Nomad v2.1.1's client (the version ES's CI pins), the red-team found that every string of a task's driver configuration goes through an HCL template evaluation with the node's attributes and metadata, the task's environment and 15 functions, and that environment and meta values go through a `${name}` replacement. I read the same files and traced where each caller string of a request lands in ES's job (`TestSubmitPlacesOnlyTheCheckedRequestStringsInTheNomadJob` does this with markers):

| Request string | Lands in the job at | Evaluated by Nomad |
| --- | --- | --- |
| `invocation.argv[]` | `Config.args[]` | template |
| `invocation.env` key and value | `Env` | `${name}` replacement |
| `invocation.output_id` | `Meta.output_id`, copied to `NOMAD_META_output_id` | `${name}` replacement |
| mount `target_path` | `Config.mounts[].target` | template |
| annotation key and value | nowhere: they only select a runtime profile | no |

Every other string member of `PrepareRequest` is a digest, an enum or absent from the job, and a reflection test (`TestEveryRequestStringIsClassifiedForTheNomadJob`) fails if a new string member appears without being classified.

**The rule.** A string is refused when it contains `${`, `%{` or a NUL byte. The check is on the substring, so the escapes `$${` and `%%{`, which Nomad rewrites to the openers, are refused too, and so is an unterminated opener. A lone `$` or `%`, a brace without an opener before it, and control bytes other than NUL pass as written.

**Why refuse rather than escape.** Escaping is not available for every field: environment and meta values go through a replacement that has no escape at all, so a literal `${name}` cannot be passed there. And an escaped job would differ from the request that ES admitted, bound and recorded. A refusal is one rule for every field, and the job stays byte-for-byte what ES admitted.

**Where.** In `validateInvocationAgainstManifest`, which the ordinary and the private path share, and in `normalizeRuntimeMountTargetPath`, which both use for mounts. Both run before anything is staged or sent. On the ordinary path the answer is `400 invalid_request` with a message that names the field. On the private path the request takes no claim, no reservation and no POST (`TestOperationalHandoffRefusesAnEnvironmentValueThatNomadWouldEvaluate`, and the red-team's `TestRedTeamPR12HeadCallerArgvIsNotEvaluatedByNomad` for arguments). The private path answers `OperationalUnavailable` there, because composing maps every resolver refusal to it; that is the existing `CP-PUBLIC-MAPPING` gap, not new.

**Callers.** No caller in the six local repositories of the project (ES, Coordinator, Maintenance Agent, Bridge Core, Infrastructure Manager, OpenAI Bridge) puts `${`, `%{` or a Nomad variable into a request string, by search. So the refusal breaks no known caller. Guess: a future caller who wants Nomad's interpolation on purpose will need a new, explicit feature, not a loophole.

**Contract.** This is a public contract change: a request that ES accepted before is now refused. `.docs/execution_lifecycle/contracts.md` states it as a request invariant, `.docs/system_overview/contracts.md` beside the invocation shape, and `TestNomadEvaluatedRequestStringsContract` pins both.

### 4.2 RT28-2: the size check comes before the claim

**The order.** Right after composing the original and before the admission recheck and establishment, the handoff asks `d.provider.fits(original.resolved)`. A request that does not fit gets `OperationalMalformed` with no claim, no reservation and no publication. The later projection, after the run is assigned, therefore cannot fail for size.

**The names.** The job carries the run's stage and job name, and the POST body a correlation value. `fits` uses names of exactly the lengths every run has: `reliablesubmit.OperationalLocatorShape()` builds them the way `Locator` builds the real ones, from 32 zero bytes, and the correlation value is 64 hex characters, as `carrierForMarker` writes it. A test in `operational_handoff_test.go` assigns 64 real runs and checks that each gives a stage and a job name of those lengths, made only of bytes that JSON writes as themselves.

**The measure.** Job0 stays bounded at 65,536 bytes as `encoding/json` writes it, where `<`, `>`, `&` and control bytes take six bytes each. I first changed it to the canonical form, which writes `<` as one byte, because the document said "canonical". That was wrong: with a job of many `<` at the canonical bound, the POST succeeded, and then the GET of the job, whose echo the suite's Nomad writes with `encoding/json`, exceeded the GET bound of 262,144 bytes, and the claim was left ambiguous. Nomad v2.1.1's API writes HTML characters as they are (`HTMLCharsAsIs` in `nomad/structs/handlers.go`), so its echo is never longer than `encoding/json`'s form. Measuring on that form keeps every echo within the GET bound. Mutant F6 (section 6.2) puts the canonical measure back and is caught. The document now says this instead of "canonical".

**The POST body.** It stays bounded at 131,072 bytes in canonical form, and `fits` checks it too, so that `request` after the assignment cannot fail either. Inference: no input reaches that check today. The body is the canonical form of Job0 plus a fixed envelope, the canonical form is never longer than `encoding/json`'s, so a Job0 within 65,536 bytes leaves the body far under 131,072. Mutants F3 and F4 survive for that reason (section 6.2).

**The run projection.** `fits` is one more caller of `newResolvedRunProjection`. Two guard inventories pin that constructor's callers; both now name it, and `.docs/execution_lifecycle/es_execution_admission_model.md` says that `fits` projects the run once more before the claim, only to measure, and sends nothing.

**Tests.** `TestOperationalJobBoundIsCheckedBeforeTheClaimAndAgreesWithTheProjection` finds, by bisection, the largest argument that fits for three kinds of content: plain bytes, `<` and a control byte. For each, that size completes with exactly one POST, and one byte more is refused as malformed with nothing stored. `TestOperationalRequestsTooLargeForAJobLeaveTheDomainOpen` sends four too-large requests, each with its own key, the number that used to close the domain, and then an ordinary one, which completes. The red-team's `TestRedTeamPR12HeadRequestTooLargeForAJobTakesNoClaim` and `TestRedTeamPR12HeadLargeRequestsThatFitComplete` pass.

### 4.3 G28-1 and G28-2

`e121e2b` is `guard-directive-allowlist-proposal.diff` byte for byte. I read it before applying it. The allowlist is exact, so a new directive needs a reviewed change, and the test also fails on a listed verb that no file holds, so the list cannot grow stale. It reads every non-test Go file of the repository, whatever its build tags. I found no gap in it.

### 4.4 Taking up `trunk_dev` `fdfa3bc` and `400ff7f`

`trunk_dev` moved from `8ba1edb` to `fdfa3bc`: PR #27 (one caller authentication rule) and PR #29 (every ARS blob ES reads is verified against its digest). `git merge-tree` shows one conflict, in `PLANS.md`, where both sides added an entry at the top. The resolution keeps both, PR #12's entries first (`merge/resolution-cc-39f6872-PLANS.md.diff`). Eight other shared files merged without a conflict: four documents, `docs_contract_test.go`, `service.go`, `reliable_submit_replay_private_test.go` and `workstream_c_guardrails_test.go`. For each, the merged file carries both sides' changed lines. The merge adds no path to PR #12's set. Later in the round `trunk_dev` took PR #36, which rewrites `README.md` only; `fd399a1` merges it without a conflict, and the root package's results do not change (section 6.3).

### 4.5 Documents and the path ceiling

- `.docs/execution_lifecycle/reliable_submit_operational_handoff.md`: the job bound and the order of the size check (section 4.2), the auditor's paragraph on `//go:` directives, and the owner reconciliation of this round. The previous paragraph's "is 56 files" becomes "was 56 files", as earlier rounds did.
- `.docs/execution_lifecycle/contracts.md` and `.docs/system_overview/contracts.md`: the RT28-1 refusal.
- `.docs/execution_lifecycle/es_execution_admission_model.md`: the size check as a run projection caller.
- `PLANS.md`: one entry for this round, at the top.
- `docs_contract_test.go`: each new owner statement with a missing and a wrong-statement case, a refusal of the old "Canonical Job0" sentence, the PLANS entry, the admission model sentence and the two contracts statements.

The ten new paths against `trunk_dev`: `es/admission/mounts.go`, the two contracts documents, `es/admission/nomad_request_strings_test.go` (new), `es/admission/reliable_submit_operational_job_bound_test.go` (new), and the red-team's five `reliable_submit_operational_admission_redteam3*_test.go` files (new). No path is gone. 56 + 10 = 66 (`paths/trunk-relative-paths.txt`).

### 4.6 What the first full run caught

The first full run, of an earlier version of this round, failed three tests, each a guard doing its job:

- `TestResolvedExecutionPlanPostFreezeConsumerGuardrails` and `TestTrancheB1FiniteSemanticShapeGuardrails`: `fits` was a new caller of the run projection constructor that neither inventory named. Both now name it, and the admission model says why (section 4.2).
- `TestReliableSubmitPersistenceAndConcurrencyADRDocsContract`: the reliable-submit package is pinned at 39 files, and the locator test was a 40th. It moved into `operational_handoff_test.go`, already a PR #12 path, so the package keeps 39 files and the ceiling is 66, not 67.

All three changes went into the commits they belong to, before anything was pushed (`runs/first-run-c369348-all.summary.txt`).

## 5. Not done: the Nomad token on the three private requests (N-1)

The red-team reported that the private path's POST, GET and the reconciliation read carry no Nomad token. That fails closed once Nomad enforces ACLs. PR #31 (the Nomad lock) is still a draft and has not merged, so there is no token source to use yet. PR #31's guard refuses a Nomad request without the token, so whichever of the two PRs lands second must add it. That guard is the machine trigger: the fix cannot be skipped.

## 6. Validation

All runs are on a clean clone of the head, as user `ci`, with an emptied environment.

### 6.1 Failing first, passing after

- The red-team's two finding tests, applied to `9116a46` (the regression tests on the merge, before either fix): both fail (`runs/finding-tests-at-9116a46.txt`). On the head both pass.
- Each new test of mine fails on a mutant that removes the piece it covers (section 6.2). Run on the code before the fixes, they do not compile, because they call the new functions.

### 6.2 Mutation

Fifteen mutants of the two fixes, each run against the new tests and the red-team's four RT28 tests (`mutants/mutants29.log`; the script is `scripts/mutants29.py.txt`). 13 are caught and 2 survive.

| Mutant | Result | Caught by |
| --- | --- | --- |
| R1 `${` passed on | caught | 4 tests, among them the red-team's argv test |
| R2 `%{` passed on | caught | the same 4 |
| R3 NUL passed on | caught | 3 tests |
| R4 `output_id` not checked | caught | `TestSubmitRefusesRequestStringsThatNomadWouldNotPassOnAsWritten` |
| R5 argv not checked | caught | that test and the red-team's argv test |
| R6 environment keys not checked | caught | `TestSubmitRefuses…` |
| R7 environment values not checked | caught | `TestSubmitRefuses…` and the private-path environment test |
| R8 mount targets not checked | caught | `TestSubmitRefuses…` |
| F1 the handoff does not ask `fits` | caught | the bisection test, the domain test and the red-team's size test |
| F2 every request fits | caught | the same 3 |
| F3 the POST body check in `fits` ignored | **survives** | see below |
| F4 a one-byte correlation value in `fits` | **survives** | see below |
| F5 a locator shape one byte shorter | caught | the bisection test and the locator test |
| F6 Job0 measured in canonical form (the rejected design) | caught | the bisection test: the `<` case POSTs and is then refused on GET |

R7 first did not compile, because the mutant left `value` unused. It was rewritten as `|| false && …` and run again alone (`mutants/mutants29-r7-rerun.log`).

F3 and F4 survive because no input reaches the body bound while Job0 is bounded (section 4.2): the body is the canonical form of Job0 plus a fixed envelope of about a hundred bytes, never longer than `encoding/json`'s form. The check stays, because it is what makes the projection after the assignment unable to fail; a test that reached it would need a Job0 over its own bound. Inference, from reading `appendOperationalJSONString` and `encoding/json`; not proved for every byte.

### 6.3 Full suite, against `trunk_dev`

`go test -count=1 -json ./...` once at `d3af16a` and once at `trunk_dev` `fdfa3bc` (`runs/head-all.summary.txt`, `runs/trunk-fdfa3bc-all.summary.txt`, comparison `runs/compare-trunk-fdfa3bc-vs-head-d3af16a.txt`):

| Run | Results | Pass | Fail | Skip |
| --- | --- | --- | --- | --- |
| `trunk_dev` `fdfa3bc` | 7,007 | 6,794 | 115 | 98 |
| head `d3af16a` | 9,113 | 8,898 | 116 | 99 |

- **No test that exists in both runs changed its result.**
- The head has 2,106 new results: 2,104 pass, `TestOperationalHandoffChildProcess` skips itself (a helper process the CI's list names) and `TestOperationalHandoffSchema4BinaryRefusesSchema5` fails without its probe binary (also on the CI's list). Both came with PR #12 earlier.
- The failures on both sides are the same 27 top-level tests: 25 operator and TLS-status tests in the root package and two probe-binary store tests of `reliablesubmit`. They fail in this container on `trunk_dev` alone too, and are the known environment failures of every earlier report.
- `es/admission` alone, on the head: 2,900 pass, 13 skip, 0 fail. The 13 skips are the same as in earlier reports: twelve tests that skip themselves here and one subtest.
- **The final head** `fd399a1` is `d3af16a` plus the merge of `trunk_dev` `400ff7f`, which changes only `README.md`. The root package, whose docs tests read the README, gives the same 2,503 results with no change (`runs/compare-root-d3af16a-vs-fd399a1.txt`). No other test reads the root README.

### 6.4 Build, vet, format, race

- `go build ./...` and `go vet ./...` for linux/amd64, linux/arm64 and darwin/arm64: clean (`runs/buildvet-*.txt`).
- `gofmt -l .`: six files, the same six as on `trunk_dev` `fdfa3bc` (`ags/sign/signer.go`, `ars/index/index.go`, `egs/sign/signer.go`, two files of `es/runtimehelper` and `internal/observability/observability.go`). None is touched by PR #12.
- Race detector (`go test -race`) on the new tests and the red-team's tests in `es/admission`, and on the locator test in `reliablesubmit`: clean.

### 6.5 PR #29's blob-read guard and the root docs pins

On the head, which contains PR #29 through the merge:

- `go test -count=1 -run '^(TestFetchVerifiedARSBlobIsTheOnlyARSBlobReadInES|TestESBinaryRepositoryPackageDirsSeesEveryLinkedRepositoryPackage|TestDependencyClientsDoNotFollowRedirects)$' ./es/admission/`: 3 pass.
- `go test -count=1 -run 'ARSBlobVerification|TestReliableSubmitBindingProducerDocsContract' .`: 4 pass.
- The whole of `es/admission`: section 6.3.

None of this round's code reads an ARS blob or adds a caller of the unverified discovery read, and no new fixture serves a blob.

## 7. Provenance manifests

Taken after the push by `scripts/prov29.sh.txt` (the script of report 25 with the base set to `4416699` and the recipe's current folder), on a clean working tree at the pushed head. The recipe's SHA-256 was checked before every run. Each manifest was written twice into a fresh mode-0700 directory outside the repository, byte-identical. For each, `git add -A` with the index reset to its base staged exactly the manifest's paths, and `git write-tree` gave the head's tree, `dc6e1b6ea6ea34c4fb22020e06f27957a12a3754`. Afterwards: head `fd399a1`, status empty, upstream restored. `trunk_dev` was fetched just before: `400ff7faa0f124b10dbb607fbad009e346bac4df`.

| Manifest | Base (index reset to) | Upstream pinned to | Files | Manifest SHA-256 | Textual diff SHA-256 |
| --- | --- | --- | --- | --- | --- |
| PR-relative | `4416699` | `origin/codex/reliable-submit-operational-handoff-v1` | 80 | `35c3e1f79abdfe9033d5c9e5e858262ce4523a7f059f5cb5f947a213a4062b41` | `b38b7ca6c164fdb663ed89a2dc895ccc4f94202a7e3b08ba0a1381957bcded43` |
| Trunk-relative | merge base `400ff7f` | `origin/trunk_dev` | 66 | `20fd4ee4eebfdda5cf248c48ae91dafc9d7a2b47760d89e622221df0e759b93e` | `42a26fd81d6f0d6785f3e44142d05db849dae3cd332145d9276a33c951efc1e1` |

The PR-relative manifest also holds what `trunk_dev` brought since `8ba1edb` (PRs #27, #29 and #36), which is why it has more files than the trunk-relative one.

## 8. The live Nomad check RT28-1 still needs

My reading of Nomad's source, and the red-team's, has not been run against a real Nomad. The check needs the test box with its Nomad (v2.1.1, as CI pins), a job ES did not admit (submitted directly with the Nomad CLI or API, so ES's new refusal does not stop it), and these task inputs, each printed by the task to its log:

1. an argument `${attr.kernel.name}`: expected to print `linux`, not the text;
2. an argument `$${x}`: expected to print `${x}`;
3. an argument with a control byte such as `\x01`: expected to arrive as written;
4. an environment value `${NOMAD_TASK_DIR}`: expected to print the task directory;
5. a `Meta.output_id` of `${NOMAD_ALLOC_ID}`, read back as `NOMAD_META_output_id`: expected to print the allocation id.

Then, through ES itself: the same strings in a request are refused with `400 invalid_request`, and a request with only the control byte is admitted and runs with it. Guess: 15 minutes on the box, with David's go for the run.

## 9. What the audit and the red-team re-check should look at

1. RT28-1: whether any other request string reaches the job (the classification test's table, section 4.1); whether a string can reach Nomad's template evaluation without containing `${` or `%{` (for example through an encoding ES applies later); whether refusing is right for `output_id`, which Nomad only replaces and does not evaluate.
2. RT28-2: whether any input makes the job or the body after the assignment larger than what `fits` measured, for example through a field whose length depends on the run beyond the stage, the job name and the correlation value.
3. The canonical-measure experiment (section 4.2) and the claim that Nomad's echo is never longer than `encoding/json`'s form.
4. The two run projection inventories and the admission model sentence.
5. The merge resolution of `PLANS.md`, and that PR #29's three rules still hold.
6. The owner reconciliation paragraph for 66 paths and its pins.
7. The merge gate must name the head `fd399a12b5fc8319d403de471bb3ce42446f350c` and tree `dc6e1b6ea6ea34c4fb22020e06f27957a12a3754`.

## 10. Effects

- Pushed: `claude/project-thread-ne9cwa-pr12-trunk-dev`, new on the remote (PR #32's branch was deleted after its merge), at `fd399a12b5fc8319d403de471bb3ce42446f350c`. No force-push, no merge, no tag. Before the push, the local commits were rebuilt twice to fold in the fixes of section 4.6; nothing that was ever pushed was rewritten.
- Draft PR [#40](https://github.com/evo-agi/Execution-Substrate/pull/40) opened into `codex/reliable-submit-operational-handoff-v1`. PR #12's own description is unchanged.
- Nothing ran outside this container: no Mac, no test box, no live service. GitHub CI runs on the draft PR.
- Mutants and probes stayed in scratch clones; copies are in the evidence folder.
- No secret, key, environment file or SQLite state from a real system was read or written.

## 11. Evidence

`29-repair-evidence/`, with `SHA256SUMS`:

- `commits/`: each commit's patch and the merge's combined diff;
- `adoption/`: the tree checks of the three adopted patches;
- `merge/`: the conflict list and the resolution;
- `paths/`: the trunk-relative path lists before and after;
- `runs/`: the validation logs, the full-suite results and summaries for the head and for `trunk_dev`, and the first run's summary;
- `mutants/`: the script and its log;
- `manifests/`: the manifest runs;
- `scripts/`: the validation, mutation and manifest scripts.
