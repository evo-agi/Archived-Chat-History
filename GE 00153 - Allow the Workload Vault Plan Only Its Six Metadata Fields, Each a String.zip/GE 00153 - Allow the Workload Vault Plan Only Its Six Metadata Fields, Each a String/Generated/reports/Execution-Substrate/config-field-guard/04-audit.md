# INDEPENDENT AUDIT REPORT: PR #33, short re-audit of the A33-2 repair (`04ea98e` to `03f925d`)

Short, read-only re-audit. Audit thread: "Audit ES config field guard", the same auditor as `02-audit.md` and `03-audit.md`. Date: 2026-11-23, 21:09Z to 21:46Z (UTC). I wrote the diff that commit `5cff0bf` applies, so for that commit this audit checks that it landed unchanged; `03f925d` is judged on its own. No red-team: the PR changes test files only.

Verdict: **ACCEPT**, with no new findings. A33-1 and A33-2 are closed. The observations O33-1, O33-4 and O33-5 stand as accepted residuals, and O33-2 (the sibling guard) is a separate PR the writer will open after #33 merges.

## 1. In plain words

1. **The bytes are the ones the writer reported.** My manifest of `03f925d` against `trunk_dev` `76c030f` matched the writer's byte for byte, at the start and at the end (`28f851eb…32b0`, 2 files). `trunk_dev` stayed at `76c030f` through all four runs. It moved to `fdfa3bc` at 21:26:56Z, when PR #29 merged (item 6).
2. **`5cff0bf` is my audit 03 diff, unchanged.** Its diff against `04ea98e` has the same SHA-256 as my published proposal (`d6aaee53…1777`), and its tree equals the tree I tested in audit 03.
3. **`03f925d` closes the one kind my diff left out, and does it well.** I left out `unsafe.Pointer` because I thought naming its type needed the `unsafe` package. The writer found that `reflect.TypeOf(reflect.Value.UnsafePointer).Out(0)` is that type, with no new import, and ran the loop to the last kind. The subtest now tries all 26 kinds. A check that accepted `unsafe.Pointer` as well as strings (mutant X01) survives my diff and is caught at `03f925d`.
4. **The writer's numbers hold.** es/config: 146 pass on `5cff0bf` and on `03f925d`, with identical results; against `04ea98e` the one new result is the every-kind subtest and nothing changed. Build, vet (three targets), gofmt and race are clean. 93 mutants on `03f925d`: 83 caught; the 10 survivors are the 9 forbidden-list mutants (O33-1) and V07 (O33-4), both accepted earlier. My map probe M1 is refused at the head.
5. **With the other open branches.** Two open PRs now touch es/config: #31 (new head `c3a94ae`) and #38 (`900d4eb`, which already includes the new trunk). Each merges with `03f925d` without conflict, vet is clean, and es/config passes (165 and 151 tests), every one of #33's 146 results among them.
6. **CI, and the trunk move.** GitHub's required check passed on `03f925d` (21:03Z to 21:30Z). During this audit `trunk_dev` took PR #29, which touches no es/config file. `03f925d` merges onto the new trunk without conflict; on the merged tree es/config gives the same 146 passes, and the packages whose tests read repository source give per-test results identical to the new trunk's. The branch must take the new trunk before it can merge (the ruleset requires an up-to-date branch), so the merge gate runs on that new head.

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #33, draft, branch `claude/project-thread-ne9cwa` into `trunk_dev` |
| Head | `03f925dce8263c1380f3efcd8816b451abe323a8`, tree `8099550012efbbe0fb4d36053eae4a3c759b72de` |
| Commits since audit 03 | `5cff0bf` (tree `2911e986…`), `03f925d`; a fast-forward from `04ea98e` |
| Base | `trunk_dev` `76c030fa7872dd22dda731591878ef284c01bd9b`, merge base, unchanged since audit 03 through the closing runs (21:13Z). `trunk_dev` then moved to `fdfa3bc67cdedb11f583a19df7036c20c612741f` (PR #29, merged 21:26:56Z); see 5.6 |
| Recipe | `governed-execution.audit-patch-manifest.v2`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before every run |
| Trunk-relative manifest | `28f851eb5ba031970e2f2cf12a5e47b5efd0ff8ed8d45ad69c17a0bc812832b0`, 2 files, textual diff `64b433a154e3f3afde146c8900850a27f9e8f6e5b99c1a7cc1ead76eedbc6121`, upstream `origin/trunk_dev` |
| Writer report | `04-repair.md`, SHA-256 `465d8f47b88c1f4bdd59d6ee6306041759dc31197432b8fe8b16bf95ccd20adc`. Evidence `04-repair-evidence/`: all 47 `SHA256SUMS` entries OK |
| Background | `03-audit.md`, SHA-256 `59ca8a53…4582` (unchanged on disk): A33-2, O33-1 to O33-5 |

## 3. Posture and setup

As in audits 02 and 03: read-only on GitHub; clone `/opt/audit/es` under `umask 022`; `git archive` exports of the exact commits; every build, test, mutant and probe as user `ci` (uid 1500, gid 1600, no sudo) under `runuser … env -i`, Go 1.26.5, `GOTOOLCHAIN=local`, `GOPROXY=off`; each mutant and probe in a fresh copy. No worktree or extra ref was left in the clone.

## 4. Provenance

| Run | Time | `trunk_dev` | Result |
| --- | --- | --- | --- |
| Opening, two runs | 21:10Z | `76c030f` | `28f851eb…32b0` both times, identical to each other and to the writer's `03f925d-vs-76c030f-trunk-1.json` and `-2.json` |
| Closing, two runs | 21:13Z | `76c030f` | `28f851eb…32b0` both times, byte-identical to the opening runs |

Before each pair: pushed tip and `refs/pull/33/head` equal `03f925d`, `76c030f` is the merge base, status clean, upstream pinned. No mode-bit difference.

The textual-diff hash equals audit 03's (`64b433a1…6121`), and that is right, as the writer explains: the recipe hashes the tracked diff only, the only tracked change against `trunk_dev` is `es/config/config_test.go`, and this round leaves it unchanged (`git diff --quiet 04ea98e 03f925d -- es/config/config_test.go`). The new test file is an untracked manifest entry, and its record changed: SHA-256 `18e34cbb5c41ae344707ba04fca0913f0c700728b16c8d09278f96fa100e04e9`, 19,767 bytes, equal to the blob at `03f925d`.

Delta checks (`delta/delta-checks.txt`):

| Diff | SHA-256 |
| --- | --- |
| `04ea98e..5cff0bf` | `d6aaee53…1777` = `03-audit-evidence/proposal/kinds-proposal.diff`; tree equals my audit 03 proposal tree |
| `5cff0bf..03f925d` | `24a44b45…c802`, +6/−5, one file |
| `04ea98e..03f925d` | `3965da28…43a7`, +35/−0, `es/config/config_field_guard_test.go` only |
| `76c030f..03f925d` (the PR) | `7881dc65…69b6` |

## 5. What I verified

### 5.1 `03f925d`

- `reflect.Value.UnsafePointer` is a method expression of type `func(reflect.Value) unsafe.Pointer`, so `reflect.TypeOf(...).Out(0)` is the `unsafe.Pointer` type. No `unsafe` import is added; the file's imports are still `fmt`, `reflect`, `slices`, `testing`.
- The loop now runs from `reflect.Bool` to `reflect.UnsafePointer`: 26 kinds, every one with a sample (the subtest stops with a fatal message if one is missing), 25 refused and `string` accepted.
- The comment says how the type is reached. It is accurate.
- Nothing else changed. Kinds a future Go might add after `reflect.UnsafePointer` would not be tried; the writer says so, and reflect gives no way to list kinds. I accept that.

### 5.2 Tests (`runs/`)

| Tree | gofmt | build + vet, three targets | es/config | race |
| --- | --- | --- | --- | --- |
| `5cff0bf` | clean | ok | 146 pass | ok |
| `03f925d` | clean | ok | 146 pass | ok |

`5cff0bf` gives the same 146 results as my audit 03 proposal tree. Against `04ea98e` (145), the one new result is `TestConfigOwnFieldsNotStringsCountsOnlyOwnFieldsOfOtherKinds/a_field_of_every_kind_but_string_is_refused`; none changed.

### 5.3 Mutants (`mutants/`)

| Set, on `03f925d` | Result |
| --- | --- |
| Writer's K01–K24 (no K16) | 23 of 23 caught (K13 ends in an out-of-memory kill, as before) |
| Writer's N01–N21 | 21 of 21 caught |
| Audit 02's A01–A12, R01–R06, U01–U10 | 28 of 28 caught |
| Audit 02's L01–L13 | 4 caught, 9 survive (O33-1, accepted) |
| Audit 03's V01–V07 | V01–V06 caught (V01, V02, V04, V05 survived at `04ea98e`); V07 survives (O33-4, equivalent in effect) |
| X01, `unsafe.Pointer` accepted as well as strings | caught at `03f925d`; survives the whole of es/config at `5cff0bf` |

Total on `03f925d`: 93 mutants, 83 caught, 10 accepted survivors. This matches the writer.

### 5.4 Probe (`probes/mapprobe4.log`)

M1 (`AuthRole map[string]string`) on `03f925d`: the guard refuses it (`field "AuthRole" must hold a string, not map[string]string`). With V05 applied, the whole of es/config fails in the every-kind subtest. I did not rerun the writer's 31 other probes: this round adds one subtest to a test file, which cannot change what the guard does to a probe; audit 03 ran them on `04ea98e`, whose guard code is identical.

### 5.5 Other open branches

At the start of the audit, PR #31 (`7aaac66`) was the only other open PR touching es/config: `git merge-tree` with `03f925d` gave `d96de361…` with no conflict, vet was clean, and es/config passed 165 tests.

Re-checked at 21:42Z, after the trunk move. Open PRs #12 (`4416699`), #30 (`eed4c9b`), #34 (`26c7cf8`), #35 (`27e8b64`), #36 (`4382b71`) and #37 (`573d9de`) do not touch es/config. Two do, neither in the Vault plan type:

| PR, head | Merge with `03f925d` | vet | es/config |
| --- | --- | --- | --- |
| #31, `c3a94ae` (repaired since) | `fd7eecf0…`, no conflict | clean | 165 pass, all 146 of #33's among them |
| #38, `b644851` | `7d722f83…`, no conflict | clean | 151 pass, all 146 of #33's among them |
| #38, `900d4eb` (moved during the re-check: `b644851` plus a merge of `fdfa3bc`, so trunk + #33 + #38) | `e2fffc0a…`, no conflict | clean | 151 pass, all 146 of #33's among them |

Logs in `trial-merge/`.

### 5.6 `trunk_dev` moved during the audit (`trunk-move/`)

At 21:34:56Z `trunk_dev` was `fdfa3bc`, a fast-forward from `76c030f` by PR #29 (29 files: docs, the root docs pins, es/admission). It changes no es/config file. My manifest runs all predate it, so the provenance above stands for base `76c030f`.

- `git merge-tree --write-tree fdfa3bc 03f925d` gives tree `2c994c9418dc91174aed4979a3414f96ce54f695`, no conflict. It differs from `fdfa3bc` in exactly the PR's two files.
- On that tree, as `ci`: gofmt clean; build and vet on the three targets ok; es/config 146 pass, identical to `03f925d`; race ok.
- PR #29's tests, and some older ones, read repository source files: the root package, es/admission and its subpackages, and internal/testtmpdir. I ran those packages on `fdfa3bc` and on the merged tree. Per-test results are identical: 3,901 pass, 247 fail, 14 skip on each. The failures are the same on both trees and occur on the new trunk alone, so they come from this container, not from #33 (31 top-level in the root package, 2 in es/admission/internal/reliablesubmit).

The repository's ruleset requires an up-to-date branch, so #33 has to take `fdfa3bc` before it merges. That gives a new head, and the merge gate must run on it. The trunk-relative diff should stay the two files audited here; my merged tree shows what that head's tree should be if the update is a clean merge.

## 6. Findings

No new findings.

| ID | Status |
| --- | --- |
| A33-1 | Closed (audit 03) |
| A33-2 | Closed: every kind is tried; V01, V02, V04, V05 and X01 are caught |
| O33-1 | Accepted residual: 9 forbidden-name removals survive; with the allowlist and the string check the list matters only after a later edit relaxes both |
| O33-2 | Open outside this PR: the writer has the sibling-guard PR ready and tracked, to open from `trunk_dev` after #33 merges. The coordinator should keep it on its list |
| O33-3 | Moot |
| O33-4 | Accepted: V07 changes only the order of two messages |
| O33-5 | Accepted: values are not judged, as the PR states |

## 7. CI

GitHub's required check "build, vet and test", run 45265619053 (job 138011622532), on head `03f925dce8263c1380f3efcd8816b451abe323a8`: **success**, 21:03:02Z to 21:30:33Z. I read the result through the GitHub tool and did not rerun CI. The check ran against base `76c030f`; the tree after the trunk update is covered by 5.6 here and by the new CI run the update will start.

## 8. Confidence

- Provenance: 1.0. Manifest reproduced byte for byte at opening and closing; PR head equals the audited commit.
- Validation: high. All counts above are from my own runs on the exact bytes.
- Implementation: high. The guard now requires the plan to declare exactly its six metadata fields, each of kind string, and its tests pin every part of that.

## 9. Effects

No repair, commit, push, PR comment, review or merge by this audit. The only writes are this report and `04-audit-evidence/` in the project folder. The PR is test-only and has no open blocking finding, so under the project's merge policy it can merge without David's review. First the branch takes `trunk_dev` `fdfa3bc`, and the merge gate must then pass on that new head, whose trunk-relative diff should still be the two files audited here.

## 10. Evidence

`04-audit-evidence/`, with `SHA256SUMS` over every file: `provenance/`, `delta/` (delta hashes, the `03f925d` diff), `runs/` (`5cff0bf`, `03f925d`, comparisons), `mutants/` (six logs), `probes/` (M1), `trial-merge/` (PR #31 at both heads, PR #38 at both heads), `trunk-move/` (`fdfa3bc`: delta, merged-tree runs, scan-package comparison), `scripts/` (`mutstr.py` with X01, `mapprobe.py`, and the `ci` runners `cienv.sh`, `unit.sh`, `cmp29.sh`, `cfgonly.sh`; the rest as in `03-audit-evidence/scripts/` and `02-audit-evidence/scripts/`).

Final verdict: **ACCEPT** for head `03f925dce8263c1380f3efcd8816b451abe323a8`, base `76c030f`, manifest `28f851eb…32b0`. The update onto `trunk_dev` `fdfa3bc` merges cleanly and changes no result I checked (5.6).
