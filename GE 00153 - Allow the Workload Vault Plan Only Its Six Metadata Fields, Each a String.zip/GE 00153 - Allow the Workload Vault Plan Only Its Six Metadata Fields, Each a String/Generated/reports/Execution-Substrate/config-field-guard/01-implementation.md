# IMPLEMENTATION REPORT: the workload Vault plan guard reads the whole type

Writer: the PR #13 thread. Date: 2026-11-23, 19:3xZ.

## 1. In plain words

- **The gap.** `TestWorkloadVaultAuthPlanCarriesOnlyNonSecretVaultMetadata` keeps token, secret, lease and raw SPIRE fields out of `ResolvedWorkloadVaultAuthPlan` in es/config. It read only the plan's own exported field names. So a secret in a nested struct, in an embedded struct, in an unexported field, behind a pointer, slice, array, map or channel, or in another case passed. This is observation O23-4 from audit 23. The coordinator asked for it as its own test-only PR, with tests that fail on the old guard.
- **Nothing is wrong today.** The plan has six string fields, and the guard passes on it before and after.
- **The fix: two questions, two helpers.** This follows the lesson of PR #26.
  - `configFieldsCarried` answers "may a value of this type carry one of these names anywhere?". It reads the whole type and records too much on purpose.
  - `configOwnFieldsMissing` answers "which of these is not a field of the plan's own?". It is exact.
  - Neither returns a set, so neither question can be asked of the other's answer.
- **Shown on the real tree.** Eight planted secrets that the old guard accepts are refused now. All 23 mutants of the new code are caught.
- **Test code only.** `es/config/config_test.go` and a new `es/config/config_field_guard_test.go`, +404/−25 lines in all. No production code, document, stored format or public contract changes.

## 2. Target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Branch | `claude/project-thread-ne9cwa`, restarted from `trunk_dev` after PR #26 merged |
| Base | `trunk_dev` `8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce` (PR #26) |
| Commit | `9884e5e4a101d7e66b5bd06591d1c408f866903b`, tree `3dc18081f50fda50869471e24dd494f30b4340a8`, parent `8ba1edb` |
| Pull request | #33 (https://github.com/evo-agi/Execution-Substrate/pull/33) (draft) |

## 3. The change

### 3.1 What the plan is

`ResolvedWorkloadVaultAuthPlan` is an in-process Go value. `WorkloadVaultAuthConfig.Resolve` builds it. es/admission keeps it in the service and reads its fields into the run's workload handoff. It has no JSON tags and is never marshalled. So the guard judges Go names, not JSON keys.

### 3.2 `configFieldsCarried`

It walks the type and records:

- every field at any depth, exported or not, embedded or not. A field promoted from an embedded struct counts under its own name, and the embedded field counts under its type's name;
- through pointers, slices, arrays, maps (key and value) and channels;
- the name of each named type on the way, so a field of type `ed25519.PrivateKey` counts as `PrivateKey`.

Each type is walked once, so a recursive type ends. Names are compared after dropping underscores and folding case to the smallest letter of each Unicode case-folding orbit, so `vault_token`, `VAULTTOKEN`, `VaultToKen` (Kelvin sign) and `Proofſecret` (long s) count as the names they spell. The helper returns each asked name that is carried, in the order asked, with the first place found.

### 3.3 `configOwnFieldsMissing`

A field counts only when the plan's own type declares it, not embedded, under exactly that name. A field promoted from an embedded struct, one at depth, one in another case, or an embedded field of a type with that name does not count.

There is no exported-field test. The asked names are exported identifiers, so a field with exactly that name is exported anyway. A first version had that test; its mutant (K16) survived because the test could never matter, so I removed it.

### 3.4 The guard

`TestWorkloadVaultAuthPlanCarriesOnlyNonSecretVaultMetadata` calls `checkWorkloadVaultAuthPlanFields(t, ResolvedWorkloadVaultAuthPlan{})`. The check keeps the two lists unchanged: 13 forbidden names and 6 required ones. It reports every finding with `t.Errorf`, naming where a forbidden name is carried, instead of stopping at the first. `collectConfigStructFieldNames` is gone.

### 3.5 New tests (`es/config/config_field_guard_test.go`)

- `TestConfigFieldsCarriedReadsTheWholeType`: 21 shapes (18 carried, 3 not), the long s, and the order and first place of results.
- `TestConfigOwnFieldsMissingCountsOnlyOwnExportedFields`: 8 shapes, and the order of results.
- `TestConfigFieldGuardHelpersRefuseNonStructs`: `nil`, a string and a pointer to a map stop both helpers with a fatal message.
- `TestWorkloadVaultAuthPlanGuardRefusesPlantedFields`: the guard's check, through a recorder in place of `testing.T`, on the real plan and five planted copies. The planted copies are a token in a nested struct, a lease in an embedded struct, a private key in an unexported field, the address only promoted, and the audience only nested. Each must give exactly the expected messages.

### 3.6 Choices

- **A denylist, deepened, not an allowlist.** An exact allowlist of the plan's fields would be stronger: any new field would fail until the list is edited. But it changes what the guard is for, and the ask was to walk nested and embedded structs. I kept the denylist and say so here, in case the auditor or coordinator prefers the allowlist.
- **Whole names, not substrings.** Substring matching would catch `VaultTokenFile`, but it would also refuse innocent names; `LeaseID` is inside `ReleaseID`. The lists stay exact names, folded.
- **Interfaces and functions are not walked.** Nothing can be read inside an `any` field. Refusing such fields would be a new rule for this guard. For the same reason as O23-1 on PR #26, I left it: a new field of type `any` in this plan would be a visible design change.

## 4. Validation

Go 1.26.5, emptied environment, user `ci` (uid 1500, gid 1600). Each probe and mutant runs in a fresh copy.

- **Build, vet, format, race.** `go build ./...` and `go vet ./...` are clean for linux/amd64, linux/arm64 and darwin/arm64, and `gofmt` is clean. The race detector passes on es/config.
- **Whole package.** es/config gives 112 pass, against 70 at `8ba1edb`. The 42 new results are the four tests above and their subtests. All pass. None changed and none is gone.
- **Real-tree probes (`cfgprobes.py`).** Each probe edits `ResolvedWorkloadVaultAuthPlan` in `es/config/config.go`, builds `./es/...`, and runs the guard on `8ba1edb` (old) and `9884e5e` (new). There were 0 unexpected results:

| Probe | Change | old | new |
| --- | --- | --- | --- |
| C0 | none | pass | pass |
| C1 | `Session struct{ ClientToken string }` | pass | **refused** |
| C2 | embedded `workloadVaultLease{LeaseID, LeaseDuration}` | pass | **refused** |
| C3 | unexported `privateKey ed25519.PrivateKey` | pass | **refused** |
| C4 | `Token *workloadVaultToken` holding `VaultToken` | pass | **refused** |
| C5 | `Leases []struct{ LeaseID string }` | pass | **refused** |
| C6 | `Secrets map[string]struct{ SecretPayload []byte }` | pass | **refused** |
| C7 | `Signer ed25519.PrivateKey` | pass | **refused** |
| C8 | `Vaulttoken string` | pass | **refused** |
| C9 | `VaultToken string` | refused | refused |
| C10 | `Extra any` (limit) | pass | pass |
| C11 | `VaultTokenFile string` (limit) | pass | pass |

- **Mutants (`mutcfg.py`).** All 23 are caught (`mutcfg.log`):
  - K01–K15: the walk skips unexported fields, depth, each kind of element, map keys or values, or type names; folding keeps underscores, lower-cases instead of folding, or does not fold; the seen set is dropped (the recursive case is killed); the last place wins; only the first name is returned;
  - K17–K20: the own-field check counts embedded fields, promoted fields or folded names, or reads the wide set (the `_, ok` trap);
  - K21: the forbidden check has the old guard's view, the plan's own exported names exactly;
  - K22: `nil` is not refused;
  - K23: the check stops at its first finding;
  - K24: the check asks the forbidden names of the own-field set.
- **First run.** The first run, on `de4164f`, had K12 fail to build, a mistake in the mutant, and K16 survive (section 3.3). It is kept as `mutcfg-first-run-de4164f.log`. After the fix, K12 builds and is caught.

## 5. Provenance manifest

v2 recipe (SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`), trunk-relative, run twice on a clean tree at the pushed tip, byte-identical:

| Item | Value |
| --- | --- |
| Head | `9884e5e4a101d7e66b5bd06591d1c408f866903b`, tree `3dc18081f50fda50869471e24dd494f30b4340a8` |
| Base | `trunk_dev` `8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce` (merge base) |
| Manifest SHA-256 | `1988308ad14e4a7a96e69751842ee2f0a7aef0b0254e8f59752195f1e4a77385`, 2 files |
| Textual diff SHA-256 | `d17619df45cad567148bbe81a35579d52640935f5d6ad39166a32be6782d2df0` |
| Staged tree | equal to the head's tree |

## 6. Not claimed

- No audit yet.
- Nothing ran on macOS.
- The guard judges the names in the plan's type, not the data a value holds at run time. A field of type `any` and a longer name such as `VaultTokenFile` pass (C10, C11).
- The required fields are also pinned by the compiler: the code builds the plan with keyed composite literals, which cannot name a promoted field.
- I wrote the code and its tests.

## 7. Effects

One push of the topic branch and draft PR #33. CI for the head is on GitHub.

## 8. Evidence

`01-implementation-evidence/`, with `SHA256SUMS` over every file:

- the commit and its diff;
- the run logs and es/config results at both heads;
- the probes and the mutants, with their scripts;
- the manifests;
- the scripts.
