# REPAIR REPORT: the workload Vault plan may declare only its six metadata fields, each a string

Writer: the PR #13 thread. Date: 2026-11-23, 20:05Z to 20:35Z (UTC).

## 1. In plain words

- **The finding.** Audit 02 (`02-audit.md`) asked for a repair of A33-1 (low): a list of forbidden names cannot show that the plan carries *only* metadata. A secret under any other name, or a field of type `any` or a function type, passed the guard.
- **The auditor's diff, applied unchanged.** Commit `070bc14` is `02-audit-evidence/proposal/allowlist-proposal.diff`, byte for byte: the diff `9884e5e..070bc14` has the same SHA-256, `86f124fb…0284dca`. It adds `configOwnFieldsBeyond`: the plan's own type may declare the six metadata fields and nothing else. I reviewed it and agree with it (section 3.1).
- **One gap it leaves, closed in a second commit.** The allowlist pins the *names* of the plan's fields, not their *types*. An allowed field could become `any`, a function, a pointer, a byte slice, or a struct such as `AuthRole struct{ Name, SecretID string }`. It would then pass both the allowlist and the forbidden names. Today only the compiler stops that, through code in es/admission (and, for four of the fields, one es/config test). A deliberate change of the field's type would change that code too. Audit 02 relied on that compile pin. Commit `eb4720a` adds a fourth question, `configOwnFieldsNotStrings`: each metadata field must hold a value of kind string.
- **Together.** The plan's type must be exactly six named fields of kind string. Nothing can sit inside a string field, so no data can hide at depth. The forbidden-name walk stays as a second layer; it can fire only if a later edit relaxes both new checks.
- **Shown on the real tree.** All 31 probes give the expected result on all four trees. Seven of them change the type of a metadata field: the auditor's proposal accepts them and this head refuses them, and the named-string control passes. 76 of 85 mutants are caught. The 9 that survive are the forbidden-list mutants of O33-1, which the auditor advised not to pin (section 4.4).
- **trunk_dev moved.** PR #27 merged into `trunk_dev` (`76c030f`) at 20:07Z, and ES requires up-to-date branches. I merged it in (`04ea98e`). It touches nothing es/config builds on, and the PR's diff against `trunk_dev` is byte-identical before and after the merge.
- **Test code only.** Two commits on top of `9884e5e`, plus the merge. Both commits change only `es/config/config_test.go` and `es/config/config_field_guard_test.go`. No production code, document, stored format or public contract changes.

## 2. Target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Branch | `claude/project-thread-ne9cwa` (fast-forward from `9884e5e`, no history rewritten) |
| Base | `trunk_dev` `76c030fa7872dd22dda731591878ef284c01bd9b` (PR #27), merge base |
| Commit 1 | `070bc14144e0dbf52d928e788e482728b5bb3c37`, tree `6d5a4b56e6f44af997fb28c87b60da96952c415e`: the auditor's diff |
| Commit 2 | `eb4720a60db789292ee6e8c3423986b92933e3b5`, tree `7609e169bdc3ddfc53175286a51bc41818d03cd8`: the string check |
| Head | `04ea98ebe62f3d5a854668cbac2f33c44987f72b`, tree `9cb3ca01335b64af2e5613982d0e7aafefc2d8b3`: merge of `trunk_dev` `76c030f` |
| Pull request | #33 (https://github.com/evo-agi/Execution-Substrate/pull/33) (draft) |

## 3. The change

### 3.1 Commit `070bc14`: the auditor's allowlist, reviewed

I applied the diff with `patch -p1` and checked both files against the proposal's full copies (`cmp`: identical). What I checked in review:

- **The question is right.** "Which fields does the type declare beyond these names?" is the only static check that can show *only*. A denylist cannot predict a secret's name (D1–D4).
- **Embedded fields are always beyond**, even when the type's name is allowed. That matches `configOwnFieldsMissing`, which does not count an embedded field as the field it is named after. So the two questions agree on what a field of the plan's own is.
- **Blank, unexported, interface and function fields count.** A `_` field holds no data, but the type should not declare it either; counting it costs nothing.
- **Order and messages.** Results come in declaration order, and the guard reports every finding with `t.Errorf`. The beyond check runs before the missing check, so a field moved into a nested or embedded struct gives both messages, which says what happened.
- **Three helpers, three questions, no sets.** That keeps PR #26's lesson.

I found no defect in it. I found one gap it does not close (3.2).

### 3.2 Commit `eb4720a`: each metadata field holds a string

**The gap.** `configOwnFieldsBeyond` asks about names, `configOwnFieldsMissing` asks about names, and `configFieldsCarried` asks about names. None asks about the type of an allowed field. So `AuthRole struct{ Name, SecretID string }`, a Vault AppRole secret inside an allowed field, passes the proposal on the real tree (probe E1). So do `CABundlePEM any`, `CABundlePEM []byte`, `Address func() string`, `JWTAudience *string` and `Address any` (E2–E5, E7).

**What stops it today.** Only the compiler:

- es/admission reads the fields as strings: `strings.TrimSpace(plan.Address)` and the like (`authorityhandoff.go:63-66`, `resolved_execution_plan.go:537-541`), and `normalizePEMForRuntimeFile(plan.CABundlePEM)` (`resolved_execution_plan.go:621`). Every E probe breaks the es/admission build.
- An es/config test compares `Address`, `AuthMount`, `AuthRole` and `JWTAudience` with string constants (`config_test.go:347`). That pins them against a struct, a function or a pointer, but not against `any`: E7 builds and passes the proposal's guard.

A change that means to change a field's type changes those lines too. The guard is there for that change, so it should not lean on lines the change rewrites. That is the reasoning audit 02 itself used about `any` fields: a promise about review is not a machine check.

**The helper.** `configOwnFieldsNotStrings(t, value, names...) []configOwnFieldType` (`es/config/config_test.go:931`) answers one question: which of these fields of the type's own does not hold a value of kind string?

- A field counts exactly as in `configOwnFieldsMissing`: the type itself declares it, not embedded, under exactly that name.
- A name the type lacks is not reported, because `configOwnFieldsMissing` reports it. So each finding is reported once, by the helper whose question it answers.
- Kind string, not the type `string`. `Mode` is `WorkloadVaultAuthMode`, a named string type, and a future `type VaultAuthMount string` is still only text (E6 passes). A pointer, slice, array, map, channel, interface, function or struct is refused.
- It returns each field with its type's name, in the order asked, as a struct, not a set.

**The guard** asks it last, with the same `metadata` list, and reports `resolved workload Vault auth plan field %q must hold a string, not %s`.

**New tests** (`es/config/config_field_guard_test.go`):

- `TestConfigOwnFieldsNotStringsCountsOnlyOwnFieldsOfOtherKinds`: 13 shapes:
  - a string and a named string type: accepted;
  - a pointer to the struct: accepted, because the helper reads through it;
  - a pointer to a string, a byte slice, an interface, a function, a struct: refused, each with its type;
  - a field in another case, a name the type lacks, an embedded field of a type with that name, a field promoted from an embedded struct, a field only in a nested struct: not reported;
  - plus an unexported field asked by its exact name, and the order of results.
- `TestConfigFieldGuardHelpersRefuseNonStructs` also covers the new helper.
- Two planted plans:
  - `zzPlanWithRoleSecret`, with `AuthRole struct{ Name, SecretID string }`: exactly one message;
  - `zzPlanWithNoStrings`, where every metadata field holds another kind (`*WorkloadVaultAuthMode`, `[]byte`, `any`, a struct, `func() string`, `[1]string`): six messages in order. It makes the guard ask about every metadata name (mutants N16–N21).

**One detail for the auditor's mutants.** The new helper loops with `for i := range root.NumField()`, like `configOwnFieldsBeyond`. With the older `for i := 0; …` form its loop line would match the anchor of audit 02's mutant A09 a second time, and A09 would not apply.

### 3.3 What I did not change

- **O33-1 (the forbidden list is not pinned):** no change, as the auditor advised. With this head the list can matter only after a later edit relaxes both new checks.
- **O33-3 (generic type names, homoglyphs):** no change. The allowlist makes both moot for the plan's own fields (D10, D11), and the string check leaves no composite field to look into.
- **O33-2 (the sibling guard in `internal/contracts/runtimeconfig/v1`):** a separate test-only PR after #33 merges, as asked.

### 3.4 The trunk_dev merge (`04ea98e`)

- `trunk_dev` moved from `8ba1edb` to `76c030f` (PR #27) at 20:07Z. ES requires up-to-date branches, so #33 needed it before merging.
- The merge is clean. Its tree, `9cb3ca01…`, is the one `git merge-tree` predicted.
- PR #27 changes 41 files. None is in es/config's build closure (`go list -deps -test ./es/config`: es/config, `internal/contracts/runtimeconfig/v1`, `internal/testtmpdir`), and it does not change `go.mod`.
- The PR's diff against its base is byte-identical before and after the merge: `8ba1edb..eb4720a` and `76c030f..04ea98e` both hash to `11d9ef61…0d24c`.

## 4. Validation

Go 1.26.5, emptied environment, user `ci` (uid 1500, gid 1600). Each probe and mutant runs in a fresh copy. Four trees: `8ba1edb` (old, `trunk_dev` before this PR), `9884e5e` (mid, the audited head), `070bc14` (prop, the auditor's proposal), `eb4720a` (new). And the merged head `04ea98e`.

### 4.1 Build, vet, format, race

`go build ./...` and `go vet ./...` are clean for linux/amd64, linux/arm64 and darwin/arm64, and `gofmt -l es/config` is empty, on `eb4720a` and on `04ea98e`. The race detector passes on es/config on both.

### 4.2 Whole package (es/config)

| Tree | Pass | Fail |
| --- | --- | --- |
| `8ba1edb` | 70 | 0 |
| `9884e5e` | 112 | 0 |
| `070bc14` | 127 | 0 |
| `eb4720a` | 145 | 0 |
| `04ea98e` | 145 | 0 |

Against `070bc14`, the 18 new results are the new helper test (16 with its subtests) and the two planted plans. Against `9884e5e`, there are 33. None changed and none is gone, against any of the three. `04ea98e` gives the same 145 names and results as `eb4720a`.

### 4.3 Real-tree probes (`cfgprobes3.py`)

Each probe edits `es/config/config.go` (and, for E1, E4 and E5, the es/config test line that compares the field with a string, as a real change would). It then builds `./es/...` and runs the guard. C0–C11 and D1–D12 are audit 02's probes, unchanged. E1–E7 are mine. There were 0 unexpected results:

| Probe | Change | old | mid | prop | new |
| --- | --- | --- | --- | --- | --- |
| C0 | none | pass | pass | pass | pass |
| C1–C8 | a secret nested, embedded, unexported, behind a pointer, in a slice or a map value, as a field of type `ed25519.PrivateKey`, or in another case | pass | refused | refused | refused |
| C9 | `VaultToken string` | refused | refused | refused | refused |
| C10 | `Extra any` | pass | pass | refused | refused |
| C11 | `VaultTokenFile string` | pass | pass | refused | refused |
| D1–D6 | `PrivateKeyPEM`, `SecretID`, `Token`, `JWT` strings; `Credentials any`; `Login func() (string, error)` | pass | pass | refused | refused |
| D7 | `ClientCert *tls.Certificate` | pass | refused | refused | refused |
| D8 | `CAPool *x509.CertPool` | pass | pass | refused | refused |
| D9 | `Namespace string` (legitimate, needs a list edit) | pass | pass | refused | refused |
| D10, D11 | Cyrillic `VaultTokеn`; generic `VaultToken[string]` | pass | pass | refused | refused |
| D12 | `Cred VaultToken` (non-generic) | pass | refused | refused | refused |
| **E1** | `AuthRole struct{ Name, SecretID string }` | pass | pass | **pass** | **refused** |
| **E2** | `CABundlePEM any` | pass | pass | **pass** | **refused** |
| **E3** | `CABundlePEM []byte` | pass | pass | **pass** | **refused** |
| **E4** | `Address func() string` | pass | pass | **pass** | **refused** |
| **E5** | `JWTAudience *string` | pass | pass | **pass** | **refused** |
| **E7** | `Address any` (no other line changes) | pass | pass | **pass** | **refused** |
| E6 | `AuthMount VaultAuthMount`, a named string type (control) | pass | pass | pass | pass |

All E probes break the es/admission build on every tree. That is the compile pin of 3.2, and it is why the guard now checks the type itself. The C and D probes build cleanly.

### 4.4 Mutants

85 mutants, each in a fresh copy of `eb4720a`, run on the whole of es/config (`mutants.log`). 76 are caught:

- **Mine, of `9884e5e` (K01–K15, K17–K24):** all 23 caught, as at `9884e5e`.
- **Mine, of the new helper and its use (N01–N21):** all 21 caught (`mutcfg3.py`):
  - N01–N11: never reports; counts embedded fields, promoted fields or folded names; reports missing names; accepts pointers to strings, interfaces or byte slices; accepts only the type `string` (refuses `Mode`); reports only the first; skips unexported fields;
  - N12, N13: the guard does not report, or stops at the first;
  - N14, N15: reports the kind instead of the type, or the reverse order;
  - N16–N21: the guard asks every metadata name but one.
- **Audit 02's (A01–A12, R01–R06, U01–U10):** all 28 caught. A01–A12 apply unchanged, and R01–R06 are caught because the allowlist ties the list to the type. U01–U10 (the proposal's helper) are caught as in audit 02.
- **Audit 02's list mutants L01–L13:** 4 caught and 9 survive (L01, L03–L06, L08–L10, L13). Same as audit 02 measured on the proposal. This is O33-1: no change, as advised.

## 5. Provenance manifest

v2 recipe (`operating-protocol/tools/governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`), trunk-relative. It ran twice on a clean tree at the pushed tip, with byte-identical output:

| Item | Value |
| --- | --- |
| Head | `04ea98ebe62f3d5a854668cbac2f33c44987f72b`, tree `9cb3ca01335b64af2e5613982d0e7aafefc2d8b3` |
| Base | `trunk_dev` `76c030fa7872dd22dda731591878ef284c01bd9b` (merge base) |
| Manifest SHA-256 | `301996df5a9db1ff9e75336372be54028c5266b3ec5d50575b0016cf4e3aca92`, 2 files |
| Textual diff SHA-256 | `64b433a154e3f3afde146c8900850a27f9e8f6e5b99c1a7cc1ead76eedbc6121` |
| Staged tree | equal to the head's tree |

Delta for the narrow re-audit:

| Diff | SHA-256 | Size |
| --- | --- | --- |
| `9884e5e..070bc14` (the auditor's diff) | `86f124fbfbce756454eb34ec2b12e64b8a3743888ed05cc644be9aefe0284dca` | +123/−14 |
| `070bc14..eb4720a` (the string check) | `3cf956b2a96e5d7ba0374d1feacb6269e9c1c5c032608419d8e13110b19d7659` | +131/−8 |
| `8ba1edb..eb4720a` = `76c030f..04ea98e` | `11d9ef61bcac5f09a9a944ddcbe487126702698ca52ca89bfd3a31349c00d24c` | +642/−31 |

## 6. Not claimed

- No re-audit yet.
- Nothing ran on macOS.
- **Values are not judged.** The guard judges the plan's type, not what a string holds at run time. A private key pasted into `CABundlePEM` is still a string.
- **A legitimate new field** such as `Namespace string` fails the guard until someone adds it to the list. That is the review point the allowlist is for, as audit 02 says.
- I did not run the whole repository's tests on `04ea98e`. es/config's build closure is unchanged by the merge, and CI runs the full suite on the head.
- I wrote commit `eb4720a` and its tests. Commit `070bc14` is the auditor's diff, unchanged.

## 7. Effects

One push of the topic branch (`9884e5e..04ea98e`, fast-forward), and an update of PR #33's description. The PR is still a draft. CI for the head is on GitHub.

## 8. Evidence

`03-repair-evidence/`, with `SHA256SUMS` over every file:

- `commits/`: the three commits and four diffs;
- `runs/`: build, vet, gofmt and race logs at `eb4720a` and `04ea98e`, and es/config results at all five trees with their comparisons;
- `probes/`: `cfgprobes3.log` and the script;
- `mutants/`: `mutants.log`, `mutcfg3.py` and `mutcfg.py`; audit 02's `mutaud.py` and `mutprop.py` are in `02-audit-evidence/scripts/`;
- `manifests/`: the v2 manifest run;
- `scripts/`: the validation and manifest scripts.
