# REPAIR REPORT: PR #33, audit 03's finding A33-2 (every kind tried against the string check)

Writer: the PR #13 thread. Date: 2026-11-23, 20:55Z to 21:10Z (UTC).

## 1. In plain words

- **The finding.** Audit 03 (`03-audit.md`) asked for a repair of A33-2 (low). The string check refuses every kind but string, but its tests tried only 6 of the kinds it refuses. A rewrite as a list of refused kinds passed every test and let `AuthRole map[string]string` through.
- **The auditor's diff, applied unchanged.** Commit `5cff0bf` is `03-audit-evidence/proposal/kinds-proposal.diff`, byte for byte: the diff `04ea98e..5cff0bf` has the same SHA-256, `d6aaee53…1777`. It adds one subtest that builds a field of every kind from `bool` to `struct` and expects every kind but string to be refused. I reviewed it and agree with it (section 3.1).
- **One kind it left out, added in a second commit.** The proposal stops at `reflect.Struct` and leaves out `reflect.UnsafePointer`, because naming that type seemed to need the `unsafe` package. It does not: `reflect.TypeOf(reflect.Value.UnsafePointer).Out(0)` is the `unsafe.Pointer` type. Commit `03f925d` adds it and runs the loop to `reflect.UnsafePointer`. Now a list of refused kinds that leaves out `unsafe.Pointer` fails too. My mutant X01 shows the difference: it survives the proposal and is caught at the new head.
- **Shown.** es/config gives 146 pass and 0 fail. All 32 probes give the expected result, including audit 03's map probe M1 (my E8). 93 mutants: 83 caught. The 10 that survive are the 9 forbidden-list mutants of O33-1 and V07 (O33-4), both of which the auditor advised not to pin.
- **Test code only.** Two commits, both in `es/config/config_field_guard_test.go`, +35/−0 in all. No production code, document, stored format or public contract changes.

## 2. Target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Branch | `claude/project-thread-ne9cwa` (fast-forward from `04ea98e`, no history rewritten) |
| Base | `trunk_dev` `76c030fa7872dd22dda731591878ef284c01bd9b` (PR #27), merge base, unchanged since round 3 |
| Commit 1 | `5cff0bf6edc2404db9f017c1cc125a2682ebecc7`, tree `2911e986cb08deafbe78391300db3a1b798ee2f5`: the auditor's diff |
| Commit 2 (head) | `03f925dce8263c1380f3efcd8816b451abe323a8`, tree `8099550012efbbe0fb4d36053eae4a3c759b72de`: `unsafe.Pointer` added |
| Pull request | #33 (https://github.com/evo-agi/Execution-Substrate/pull/33) (draft) |

## 3. The change

### 3.1 Commit `5cff0bf`: the auditor's subtest, reviewed

I applied the diff with `patch -p1` to `04ea98e` and checked the result against the proposal's full copy (`cmp`: identical). What I checked in review:

- **The question is right.** A check whose job is "refuse every kind but one" can only be pinned by trying every kind. Six samples pin six kinds; the rest are a guess about how the check is written. This is A33-1's lesson applied to kinds instead of names.
- **It fails loudly if a sample is missing.** The loop runs over the kinds by number and stops with `no sample type of kind …` when the sample list lacks one. So a future Go kind inside the range cannot be skipped silently.
- **It tests the helper's real output.** Each field gets the same name, and the expected result is the exact `configOwnFieldType` with `typ.String()`, the text the guard prints. The string case expects nothing.
- **It needs no new production surface.** It builds each struct with `reflect.StructOf` and reads it through the helper, as the guard does. The field name is exported, as `reflect.StructOf` requires without a package path.
- **One gap.** The comment says `reflect.UnsafePointer` is left out because naming its type would need the `unsafe` package. That is not so (3.2). Leaving it out keeps one kind untested. That kind could hold an address but no data the guard could read, so the risk is small. But "every kind but one" is the same shape as the finding, and closing it costs one line.

### 3.2 Commit `03f925d`: `unsafe.Pointer` included

- `reflect.Value.UnsafePointer` is a method expression of type `func(reflect.Value) unsafe.Pointer`. So `reflect.TypeOf(reflect.Value.UnsafePointer).Out(0)` is the `unsafe.Pointer` type, with no `unsafe` import.
- The loop now runs from `reflect.Bool` to `reflect.UnsafePointer`: 26 kinds, 25 of them refused.
- The comment says how the type is reached.
- **Shown to matter.** Mutant X01 rewrites the check to accept `unsafe.Pointer` as well as strings. On `5cff0bf` it survives the whole of es/config (147 pass, 0 fail, `mutants/X01-on-5cff0bf.*`). On `03f925d` it is caught in the every-kind subtest.

### 3.3 What I did not change

- **O33-1 (the forbidden list is not pinned)** and **O33-4 (V07 equivalent):** no change, as the auditor advised.
- **O33-5 (a named string type with a secret's name):** no change. It is part of "values are not judged", which the PR states. No static check can tell what a string means.
- **O33-2 (the sibling guard in `internal/contracts/runtimeconfig/v1`):** the test-only PR is prepared and validated locally on a work branch, with the allowlist, the every-kind lesson and planted copies. I open it once #33 merges, from the new `trunk_dev`, as asked. It is on this thread's checklist as its own step, so it is tracked.

## 4. Validation

Go 1.26.5, emptied environment, user `ci` (uid 1500, gid 1600). Each probe and mutant runs in a fresh copy. Trees: `8ba1edb` (old), `9884e5e` (mid), `070bc14` (prop), `04ea98e` (round 3 head), `5cff0bf` (the auditor's subtest), `03f925d` (new).

### 4.1 Build, vet, format, race

On `03f925d`: `go build ./...` and `go vet ./...` are clean for linux/amd64, linux/arm64 and darwin/arm64, `gofmt -l es/config` is empty, and the race detector passes on es/config.

### 4.2 Whole package (es/config)

| Tree | Pass | Fail |
| --- | --- | --- |
| `04ea98e` | 145 | 0 |
| `5cff0bf` | 146 | 0 |
| `03f925d` | 146 | 0 |

Against `04ea98e`, the one new result is the every-kind subtest. None changed and none is gone. `5cff0bf` and `03f925d` give the same 146 names and results.

### 4.3 Real-tree probes (`cfgprobes3.py`)

The 31 probes of round 3, plus E8: `AuthRole map[string]string`, audit 03's probe M1. They run on old, mid, prop and new (`03f925d`). There were 0 unexpected results:

- C0–C11, D1–D12 and E1–E7 give the same results as in round 3 (`03-repair.md`, section 4.3).
- E8 passes old, mid and prop, and is refused on new with `field "AuthRole" must hold a string, not map[string]string`.
- E6 (a named string type) passes everywhere, as it should.

### 4.4 Mutants

93 mutants, each in a fresh copy of `03f925d`, run on the whole of es/config (`mutants.log`). 83 are caught:

| Set | Caught | Survive |
| --- | --- | --- |
| Mine, of `9884e5e` (K01–K15, K17–K24) | 23 of 23 | none |
| Mine, of the string check (N01–N21) | 21 of 21 | none |
| Mine, `unsafe.Pointer` accepted (X01) | 1 of 1 | none (survives on `5cff0bf`) |
| Audit 02's (A01–A12, R01–R06, U01–U10) | 28 of 28 | none |
| Audit 02's list mutants (L01–L13) | 4 of 13 | L01, L03–L06, L08–L10, L13 (O33-1) |
| Audit 03's (V01–V07) | 6 of 7 | V07 (O33-4) |

V01 (maps accepted), V02 (channels), V04 (bool and integer kinds) and V05 (the check as a list of six refused kinds) survived at `04ea98e`. All four are now caught in the every-kind subtest.

## 5. Provenance manifest

v2 recipe (`operating-protocol/tools/governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`), trunk-relative. It ran twice on a clean tree at the pushed tip, with byte-identical output:

| Item | Value |
| --- | --- |
| Head | `03f925dce8263c1380f3efcd8816b451abe323a8`, tree `8099550012efbbe0fb4d36053eae4a3c759b72de` |
| Base | `trunk_dev` `76c030fa7872dd22dda731591878ef284c01bd9b` (merge base) |
| Manifest SHA-256 | `28f851eb5ba031970e2f2cf12a5e47b5efd0ff8ed8d45ad69c17a0bc812832b0`, 2 files |
| Textual diff SHA-256 | `64b433a154e3f3afde146c8900850a27f9e8f6e5b99c1a7cc1ead76eedbc6121` |
| Staged tree | equal to the head's tree |

**The textual diff hash is the same as in round 3, and that is expected.** The recipe hashes `git diff HEAD` over tracked files only. Against `trunk_dev`, `config_field_guard_test.go` is a new file, so it enters the manifest as an untracked entry and not the textual diff. `config_test.go` is the only tracked change, and this round does not touch it. The new file's entry changed: SHA-256 `18e34cbb5c41ae344707ba04fca0913f0c700728b16c8d09278f96fa100e04e9`, 19767 bytes, against `df72bae3…377a`, 17898 bytes, in round 3.

Delta for the short re-audit:

| Diff | SHA-256 | Size |
| --- | --- | --- |
| `04ea98e..5cff0bf` (the auditor's diff) | `d6aaee53811a3c6444f7c24fd5e9f3d45848a0ae81b797530a5e1ae1ca361777` | +34/−0 |
| `5cff0bf..03f925d` (`unsafe.Pointer`) | `24a44b452500ab50a98f0fe34d81ecc91220d55b4f654489e1f71bf75237c802` | +6/−5 |
| `04ea98e..03f925d` (the round) | `3965da2814295a6141cc28e9d530aab0c58198b3424a4ee6b8af41d371ca43a7` | +35/−0 |
| `76c030f..03f925d` (the PR) | `7881dc6517615775075d8197d3698126053a13e506e5c158788e5058a3d369b6` | +677/−31 |

## 6. Not claimed

- No re-audit yet.
- Nothing ran on macOS.
- I did not run the whole repository's tests. The round changes one es/config test file. CI runs the full suite on the head; it was in progress when I wrote this.
- **Values are not judged** (O33-5). A legitimate new field such as `Namespace string` still fails until someone adds it to the list.
- A kind that a future Go adds after `reflect.UnsafePointer` would not be tried. A kind added inside the range stops the subtest with a fatal message.
- I wrote commit `03f925d`. Commit `5cff0bf` is the auditor's diff, unchanged.

## 7. Effects

One push of the topic branch (`04ea98e..03f925d`, fast-forward), and an update of PR #33's description. The PR is still a draft.

## 8. Evidence

`04-repair-evidence/`, with `SHA256SUMS` over every file:

- `commits/`: the two commits, four diffs and a copy of the auditor's proposal;
- `runs/`: build, vet, gofmt and race logs at `03f925d`, es/config results at `04ea98e`, `5cff0bf` and `03f925d`, and their comparisons;
- `probes/`: `cfgprobes3.log` and the script;
- `mutants/`: `mutants.log`, `mutcfg3.py` and `mutcfg.py`, and X01 on `5cff0bf`. Audit 02's `mutaud.py` and `mutprop.py` are in `02-audit-evidence/scripts/`, and audit 03's `mutstr.py` is in `03-audit-evidence/scripts/`;
- `manifests/`: the v2 manifest run;
- `scripts/`: the validation and manifest scripts.

No file in the evidence holds a secret, a host address or a personal path (scanned).
