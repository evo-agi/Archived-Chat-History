# INDEPENDENT AUDIT REPORT: PR #33, narrow re-audit of the repair (`9884e5e` to `04ea98e`)

Narrow, read-only re-audit. Audit thread: "Audit ES config field guard", the same auditor as `02-audit.md`. Date: 2026-11-23, 20:25Z to 20:55Z (UTC). I wrote the diff that commit `070bc14` applies, so for that commit this audit checks that it landed unchanged; `eb4720a` and the merge are judged on their own. No red-team: the PR changes test files only.

Verdict: **REPAIR NEEDED** (protocol verdict `BLOCK`), for one new low finding, A33-2, a test gap in the new string check. A33-1 is closed. The bytes are the writer's, the merge is clean, every number the writer reports holds, and `eb4720a` is a correct and needed addition. But the new check's tests pin only 6 of the 24 kinds it must refuse: rewritten as a list of refused kinds, it would let `AuthRole map[string]string` through and every test would stay green. A tested 34-line test-only fix closes it (section 6).

## 1. In plain words

1. **The bytes are the ones the writer reported.** My manifest of `04ea98e` against `trunk_dev` `76c030f` matched the writer's byte for byte, at the start and at the end (`301996df…3aca92`, 2 files).
2. **`070bc14` is my audit 02 diff, unchanged.** Its diff against `9884e5e` has the same SHA-256 as my published proposal (`86f124fb…4dca`), and its tree equals the tree I tested in audit 02.
3. **`eb4720a` is right, and I was wrong to rely on the compiler.** My allowlist pinned the plan's field *names*, not their *types*. In audit 02 I said an allowed field "cannot become an interface without breaking the build in admission". The writer rightly points out that a change of a field's type rewrites exactly those admission lines, so that is a promise about review, the same kind of promise A33-1 rejected. The new helper, `configOwnFieldsNotStrings`, requires each metadata field to hold a value of kind string. On the real tree, a struct, `any`, `[]byte`, a function or a pointer in an allowed field is now refused, and a named string type still passes.
4. **The merge is clean.** `04ea98e` merges `trunk_dev` `76c030f` (PR #27) with no hand edits: its tree is exactly what `git merge-tree` predicts, the remerge diff is empty, and the PR's diff against its base is byte-identical before and after (`11d9ef61…d24c`).
5. **The writer's numbers hold.** es/config: 145 pass on `eb4720a` and on `04ea98e`, with identical results; none of the 127 earlier results changed. Build, vet (three targets), gofmt and race are clean. The writer's 85 mutants: 76 caught, and the 9 survivors are the O33-1 forbidden-list mutants. The writer's 31 probes: 0 unexpected results on four trees.
6. **The gap (A33-2).** The string check is written correctly (`kind != string`), but its tests only try pointer, slice, interface, function, struct and array. A map, a channel or a number is never tried. My mutant V05 rewrites the check as a list of the six refused kinds the tests use. It survives the whole of es/config, and on the real tree it lets `AuthRole map[string]string` pass the guard (probe M1). That is a denylist of kinds, the shape A33-1 removed for names.
7. **The fix.** One subtest that builds a field of every kind from `bool` to `struct` and expects all but `string` to be refused. With it, es/config passes 146 tests, and V05 and the other kind mutants are caught.
8. **CI.** GitHub's required check passed on `04ea98e` (run 45258588124, 20:21Z to 20:49Z).

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #33, draft, branch `claude/project-thread-ne9cwa` into `trunk_dev` |
| Head | `04ea98ebe62f3d5a854668cbac2f33c44987f72b`, tree `9cb3ca01335b64af2e5613982d0e7aafefc2d8b3` (merge of `eb4720a` and `trunk_dev` `76c030f`) |
| Commits since audit 02 | `070bc14` (tree `6d5a4b56…`), `eb4720a` (tree `7609e169…`), `04ea98e`; a fast-forward from `9884e5e` |
| Base | `trunk_dev` `76c030fa7872dd22dda731591878ef284c01bd9b` (PR #27), merge base; unchanged at 20:37Z |
| Recipe | `governed-execution.audit-patch-manifest.v2`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before every run |
| Trunk-relative manifest | `301996df5a9db1ff9e75336372be54028c5266b3ec5d50575b0016cf4e3aca92`, 2 files, textual diff `64b433a154e3f3afde146c8900850a27f9e8f6e5b99c1a7cc1ead76eedbc6121`, upstream `origin/trunk_dev` |
| Writer report | `03-repair.md`, SHA-256 `1dd7622753505bed9556027da2d1e3e9d0681d4fd6512fa1c9809cd2b07fb2a8`. Evidence `03-repair-evidence/`: all 61 `SHA256SUMS` entries OK |
| Background | `02-audit.md`, SHA-256 `f53e82b7…9cd6` (unchanged on disk): A33-1, O33-1 to O33-3 |

## 3. Posture and setup

As in audit 02: read-only on GitHub; clone `/opt/audit/es` under `umask 022`; `git archive` exports of the exact commits; every build, test, mutant and probe as user `ci` (uid 1500, gid 1600, no sudo) under `runuser … env -i`, Go 1.26.5, `GOTOOLCHAIN=local`, `GOPROXY=off`. Each mutant and probe ran in a fresh copy. I ran the writer's `mutcfg3.py` verbatim (SHA-256 `491a9edf…7733`) and the writer's `cfgprobes3.py` (SHA-256 `f9fdc54a…7753`) with only its scratch path changed. The fix in section 6 was written in a temporary local worktree, never committed or pushed, and removed.

## 4. Provenance

| Run | Time | `trunk_dev` | Result |
| --- | --- | --- | --- |
| Opening, two runs | 20:26Z | `76c030f` | `301996df…3aca92` both times, identical to each other and to the writer's `04ea98e-vs-76c030f-trunk-1.json` and `-2.json` |
| Closing, two runs | 20:37Z | `76c030f` | `301996df…3aca92` both times, byte-identical to the opening runs |

Before each pair: pushed tip and `refs/pull/33/head` equal `04ea98e`, `76c030f` is the merge base, status clean, upstream pinned to `origin/trunk_dev`. No mode-bit difference. Afterwards the clone was at `04ea98e`, clean, with no extra worktree or ref.

Delta checks (`merge/merge-and-delta-checks.txt`):

| Check | Result |
| --- | --- |
| `git diff 9884e5e 070bc14` | SHA-256 `86f124fb…4dca` = `02-audit-evidence/proposal/allowlist-proposal.diff`; tree of `070bc14` equals my audit 02 proposal tree (`diff -r` empty) |
| `git diff 070bc14 eb4720a` | SHA-256 `3cf956b2…7659`, +131/−8, the two es/config test files only |
| `git merge-tree --write-tree eb4720a 76c030f` | `9cb3ca01…` = tree of `04ea98e`; `git show --remerge-diff 04ea98e` is empty |
| `git diff 8ba1edb eb4720a` and `git diff 76c030f 04ea98e` | both `11d9ef61…d24c`; `76c030f..04ea98e` changes nothing outside es/config |
| `trunk_dev` move | `76c030f` is PR #27 (41 files, no `go.mod` change); es/config at `76c030f` gives the same 70 results as at `8ba1edb` |

## 5. What I verified

### 5.1 `eb4720a`

- `configOwnFieldsNotStrings` (`es/config/config_test.go:931` at `04ea98e`) counts a field exactly as `configOwnFieldsMissing` does (declared by the root type, not embedded, exact name), skips names the type lacks (so a missing field is reported once, by the missing check), and refuses any kind but string. It returns name and type in the asked order, as a struct slice, not a set. This keeps the one-question-per-helper rule.
- Kind string, not type `string`, is the right test: `Mode` is the named string type `WorkloadVaultAuthMode`.
- The guard asks the four helpers in this order: forbidden names anywhere, fields beyond the metadata, missing metadata, metadata that is not a string. Each finding is reported with `Errorf`.
- With the string check, the plan's type must be exactly six own fields of kind string, so nothing can sit at depth inside the plan's own fields. The deep forbidden-name walk can then only fire after a later edit relaxes both new checks. The writer says the same.
- The writer's note about mutant A09 is right: the new loop uses `for i := range root.NumField()`, so A09's anchor still matches once.

### 5.2 Tests (`runs/`)

| Tree | gofmt | build + vet, three targets | es/config | race |
| --- | --- | --- | --- | --- |
| `76c030f` (base) | clean | ok | 70 pass | ok |
| `eb4720a` | clean | ok | 145 pass | ok |
| `04ea98e` | clean | ok | 145 pass | ok |

Against `070bc14` (127), the 18 new results all pass and none of the 127 changed. `eb4720a` and `04ea98e` give identical results. This matches the writer.

### 5.3 Mutants on `04ea98e` (`mutants/`)

| Set | Result |
| --- | --- |
| Writer's N01–N21 (the string helper and its use) | 21 of 21 caught |
| Writer's K01–K24 (no K16) | 23 of 23 caught (K13 again ends in an out-of-memory kill, after 13 s) |
| Audit 02's A01–A12, R01–R06, U01–U10 | 28 of 28 caught |
| Audit 02's L01–L13 | 4 caught, 9 survive (O33-1, unchanged) |
| **Mine, V01–V07 (the string helper)** | **V03 (arrays accepted) and V06 (pointers to and arrays of strings accepted) caught. V01 (maps accepted), V02 (channels accepted), V04 (bool and integer kinds accepted) and V05 (the check as a list of the six refused kinds the tests use) survive. V07 (string check before missing check) survives (O33-4).** |

So the writer's 85: 76 caught, as reported. My V set adds A33-2.

### 5.4 Probes (`probes/`)

- The writer's 31 probes (C0–C11, D1–D12, E1–E7) on `8ba1edb`, `9884e5e`, `070bc14` and `04ea98e`: 0 unexpected results. E1–E5 and E7 (a struct, `any`, `[]byte`, a function or a pointer in an allowed field) pass the guard on the first three trees and are refused on `04ea98e`; E6 (a named string type) passes on all four. As the writer says, every E probe breaks the es/admission build on every tree; the guard no longer depends on that.
- **M1**, mine (`mapprobe.log`): `AuthRole` becomes `map[string]string`, with `Resolve` and the es/config comparison adjusted as a real change would. On `04ea98e` the guard refuses it (`field "AuthRole" must hold a string, not map[string]string`). On `04ea98e` with V05 the guard passes it. On the fixed tree with V05, es/config fails in the new subtest.

### 5.5 Other open branches

PR #31 (head now `7aaac66`) is still the only other open PR touching es/config, and it still does not touch the plan. `git merge-tree` of `04ea98e` and `7aaac66` has no conflict; es/config on the merged tree passes 164 tests, vet clean (`trial-merge/`). PRs #29 (`91dbad6`), #30 (`eed4c9b`) and #34 (`0927911`) do not touch es/config.

## 6. Findings

### A33-1: closed

`070bc14` applies the allowlist unchanged, and `eb4720a` closes the part of the gap my proposal left (field types). Probes C10, C11, D1–D12 and E1–E7 are refused on `04ea98e`.

### A33-2: the string check's refusal of most kinds is untested

```text
AUDIT FINDING
ID / Type / Severity: A33-2 / test gap / low
Current contract: checkWorkloadVaultAuthPlanFields requires each metadata field to hold a string
  (es/config/config_test.go:360-396 and :931-947 at 04ea98e).
Path and line: es/config/config_field_guard_test.go, TestConfigOwnFieldsNotStringsCountsOnlyOwnFieldsOfOtherKinds and
  the planted plan zzPlanWithNoStrings: the refused kinds tried are pointer, slice, interface, func, struct, array.
Evidence: mutants V01, V02, V04, V05 survive the whole of es/config at 04ea98e (5.3). With V05 the guard accepts
  AuthRole map[string]string on the real tree (probe M1).
Impact: a later rewrite of the check as a list of refused kinds (the denylist shape A33-1 removed for names) that
  misses map or chan would pass every test and let a map of secrets sit in an allowed field. Low: the code is right
  today, and the regression would have to be written.
Required correction: test every kind; proposal/kinds-proposal.diff (section 6.1).
Uncertainty: none about the gap; its likelihood is a judgment.
Patch defect or pre-existing issue: patch defect, introduced by eb4720a (a gap in its new tests).
```

#### 6.1 Tested fix (`proposal/`)

`kinds-proposal.diff` (SHA-256 `d6aaee53811a3c6444f7c24fd5e9f3d45848a0ae81b797530a5e1ae1ca361777`), against `04ea98e`, `es/config/config_field_guard_test.go` only, +34/−0. It adds the import `reflect` and one subtest to `TestConfigOwnFieldsNotStringsCountsOnlyOwnFieldsOfOtherKinds`, "a field of every kind but string is refused":

- one sample type per kind from `reflect.Bool` to `reflect.Struct` (25 kinds); the test stops if a kind has no sample;
- for each, a struct with one field of that type, built with `reflect.StructOf`; it expects exactly one finding with the field's type for every kind but string, and none for string;
- `reflect.UnsafePointer` is left out, with a comment: naming its type would need the `unsafe` package, which nothing in es/config imports.

Results on the fixed tree (`runs/prop3-*`, `mutants/*-prop3.log`): gofmt clean; build and vet ok for the three targets; race ok; es/config 146 pass (1 new, none changed); V01–V06 caught; N01–N21 still caught. The other mutant sets cannot be affected by an added test.

### Observations (no change asked)

| ID | Observation |
| --- | --- |
| O33-1 | Unchanged: 9 of 13 forbidden-name removals survive. With `eb4720a` the list can matter only after a later edit relaxes both the allowlist and the string check. |
| O33-2 | Unchanged: the sibling guard in `internal/contracts/runtimeconfig/v1` keeps the old pattern. The writer plans a separate test-only PR after #33 merges. It needs a tracked work item, not only this note. |
| O33-3 | Moot, as the writer says. |
| O33-4 | V07 survives: swapping the order of the missing check and the string check changes only the order of messages for a plan with both problems; both are still reported. Equivalent in effect; not worth a test. |
| O33-5 | Part of "values are not judged": a named string type whose name says secret, say `AuthRole SecretID` with `type SecretID string`, passes all four checks, because it is still a string of an allowed name. The deep walk catches such a type only if its name is on the forbidden list. No static guard can tell what a string means. |

## 7. Coverage and limits

- Inspected: the three new commits in full; the four helpers and the guard as they stand at `04ea98e`; the merge (tree, remerge diff, delta hashes); the writer's report, evidence, scripts and logs.
- Not run: macOS, and the whole repository suite (CI ran it; section 9). Inference: the merge changes nothing es/config builds on (`76c030f..04ea98e` touches only es/config's two test files; es/config at `76c030f` equals `8ba1edb`).
- As before, values are not judged.

## 8. Writer's report: claims checked

Every numbered claim in `03-repair.md` §1, §3.4, §4 and §5 matched my runs: the two diff hashes, the merge tree, the unchanged PR diff, 145 passing tests on both trees, 76 of 85 mutants with the 9 named survivors, and 31 probes with 0 unexpected results. The writer's critique of my audit 02 reasoning about the compile pin is correct (section 1, item 3).

## 9. CI

GitHub's required check "build, vet and test", run 45258588124 (job 137986888250) on head `04ea98e`: **success**, 20:21Z to 20:49Z. I read the result through the GitHub tool and did not rerun CI. Re-checked at 20:54Z: `trunk_dev` is still `76c030f` and the PR head is still `04ea98e`.

## 10. Sensitive material

None handled. Probes plant field names and types only.

## 11. Confidence

- Provenance: 1.0. Manifest reproduced byte for byte at opening and closing; PR head equals the audited commit.
- Validation: high. All counts above are from my own runs on the exact bytes.
- Implementation: high that `04ea98e` is correct and closes A33-1; high that A33-2 is real (whole-package mutant and real-tree probe) and that the fix closes it without regressions.

## 12. Effects

No repair, commit, push, PR comment, review or merge by this audit. The only writes are this report and `03-audit-evidence/` in the project folder.

## 13. Evidence

`03-audit-evidence/`, with `SHA256SUMS` over every file: `provenance/`, `merge/` (merge and delta checks, the `eb4720a` diff), `runs/` (base, `eb4720a`, `04ea98e`, fixed tree, comparisons), `mutants/` (seven logs), `probes/` (the writer's 31 probes on four trees, M1), `proposal/` (diff and full file), `trial-merge/` (PR #31), `scripts/` (with a README naming the writer's scripts used).

Final verdict: **REPAIR NEEDED** (`BLOCK`): apply the A33-2 fix (or an equivalent that tries every kind), then a narrow re-audit of that delta and a fresh trunk-relative manifest. No other blocker.
