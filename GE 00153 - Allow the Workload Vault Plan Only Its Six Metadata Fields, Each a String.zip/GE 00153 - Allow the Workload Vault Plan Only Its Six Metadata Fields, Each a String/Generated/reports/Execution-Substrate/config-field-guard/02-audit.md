# INDEPENDENT AUDIT REPORT: PR #33, the es/config workload Vault plan guard (`9884e5e`)

Fresh, read-only, independent correctness audit. Audit thread: "Audit ES config field guard". Date: 2026-11-23, 19:27Z to 20:04Z (UTC). I did not write any of this code. There is no red-team: the PR changes test files only.

Verdict: **REPAIR NEEDED** (protocol verdict `BLOCK`), for one low finding, A33-1. Everything the writer claims holds on the exact bytes, and the change is strictly better than `trunk_dev`. But both choices the writer asked me to judge (a deepened denylist, and interface fields not walked) leave a real gap, and it is the same gap: the guard still cannot show what its name says, that the plan carries *only* non-secret metadata. A tested, test-only fix closes it (section 7). The project fixes low findings in the PR, so I recommend applying it before merge, then a narrow re-audit.

## 1. In plain words

1. **The bytes are the ones the writer reported.** My manifest of `9884e5e` against `trunk_dev` `8ba1edb` matched the writer's byte for byte, at the start and at the end (`1988308a…7385`, 2 files, textual diff `d17619df…2df0`).
2. **The writer's numbers hold.** On my own runs: build, vet (three targets), gofmt and race are clean; es/config goes from 70 to 112 passing tests, all 42 new ones pass, none changed; the writer's 23 mutants are all caught; the writer's 12 real-tree probes give the reported results. I added 12 code mutants of my own: all caught.
3. **What the new guard does well.** A secret name now gets caught at any depth: nested, embedded, unexported, behind a pointer, slice, array, map or channel, under a type's name (a field of type `tls.Certificate` is refused because it holds a `PrivateKey`), in another case or with underscores. The required-field check is exact and cannot be read from the wide set.
4. **The gap (A33-1).** The guard matches 13 exact names. On the real tree, these new plan fields all pass it: `PrivateKeyPEM string`, `SecretID string`, `Token string`, `JWT string`, `VaultTokenFile string`, `Credentials any`, `Login func() (string, error)`. A field of type `any` can hold anything at run time, and a secret rarely has exactly one of the 13 names. So the two choices in the writer's §3.6 are one gap seen twice.
5. **The fix.** An exact allowlist of the plan's own fields: the plan may declare the six metadata fields and nothing else (a new helper, `configOwnFieldsBeyond`). The deep denylist stays, as a second layer for any composite field a future edit allows. Every probe above is then refused, including interface and function fields. With the fix, es/config passes 127 tests; all 45 mutants of the guard code (the writer's 23, my 12, and 10 of the new helper) are caught.
6. **What the fix costs.** A legitimate new plan field, such as `Namespace string`, fails the guard until someone adds it to the metadata list. That one-line edit is the review point the guard is for.
7. **Why only low.** Nothing secret is in the plan today, and admission copies the plan's fields one by one into its own private projection, so a new plan field reaches a workload only if admission code changes too. The guard is a first line of hygiene, not the only control.
8. **Outside this PR (O33-2).** The sibling guard in `internal/contracts/runtimeconfig/v1` still has the old pattern on a JSON contract: an untagged `VaultToken` field, a tag `VAULT_TOKEN`, a map value or an `any` field pass it, and a required key counts at any depth. I recommend its own test-only PR.
9. **CI.** GitHub's required check passed on `9884e5e` (run 45248766817, 19:25Z to 19:56Z).

## 2. Audit target

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Pull request | #33, draft, branch `claude/project-thread-ne9cwa` into `trunk_dev` |
| Commit | `9884e5e4a101d7e66b5bd06591d1c408f866903b`, tree `3dc18081f50fda50869471e24dd494f30b4340a8`, parent `8ba1edb` |
| Base | `trunk_dev` `8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce` (merge base; unchanged at 19:43Z) |
| Change | `es/config/config_test.go` (modified) and `es/config/config_field_guard_test.go` (new), +404/−25, test code only |
| Recipe | `governed-execution.audit-patch-manifest.v2`, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, verified before every run |
| Trunk-relative manifest | `1988308ad14e4a7a96e69751842ee2f0a7aef0b0254e8f59752195f1e4a77385`, 2 files, textual diff `d17619df45cad567148bbe81a35579d52640935f5d6ad39166a32be6782d2df0`, upstream `origin/trunk_dev` |
| Writer report | `01-implementation.md`, SHA-256 `02a2398382d2a419668a00f6c5ac4f8a83fb0bb3b7b1fbc480af82588919805d`. Evidence `01-implementation-evidence/`: all 38 `SHA256SUMS` entries OK |

## 3. Posture and setup

- Read-only on GitHub: no push, comment, review, merge or branch change. The fix in section 7 was written in a temporary local worktree, never committed or pushed, and the worktree was removed.
- Clone `/opt/audit/es`, checked out under `umask 022`. Test trees are `git archive` exports of the exact commits.
- All builds, tests, mutants and probes ran as user `ci` (uid 1500, gid 1600, no sudo) under `runuser … env -i` with Go 1.26.5, `GOTOOLCHAIN=local`, `GOPROXY=off`, no proxy or token variables (`scripts/cienv.sh.txt`).
- Every mutant and probe ran in a fresh copy of a pristine export. I ran the writer's mutant script `mutcfg.py` (SHA-256 `5339de45…f114`) verbatim. My probe script includes the writer's 12 probes verbatim and adds 12. No downloaded binary was executed.

## 4. Provenance

| Run | Time | `trunk_dev` | Result |
| --- | --- | --- | --- |
| Opening, two runs | 19:28Z | `8ba1edb` | `1988308a…7385` both times, identical to each other and to the writer's `9884e5e-vs-8ba1edb-trunk-1.json` and `-2.json` |
| Closing, two runs | 19:43Z | `8ba1edb` | `1988308a…7385` both times, byte-identical to the opening runs |

Before each pair: the pushed tip equals `9884e5e` (`git ls-remote` also shows `refs/pull/33/head` at `9884e5e`), `8ba1edb` is the merge base, the status was clean, and the upstream was pinned to `origin/trunk_dev`. No mode-bit difference. Afterwards the clone was at `9884e5e`, clean, with no extra worktree or ref.

## 5. What I verified

### 5.1 The code

- `configFieldsCarried` (`es/config/config_test.go:816` at `9884e5e`) walks the type once per type (the seen set ends recursion), records every field name and every named type's name, follows pointer, slice, array, chan, and map key and value, and keeps the first place found. It returns the asked names in the asked order.
- `foldConfigFieldName` (`:901`) drops underscores and maps each rune to the smallest member of its `unicode.SimpleFold` orbit. Two names fold alike exactly when `strings.EqualFold` holds without their underscores, as the comment says: same rune count, and same orbit per rune. The Kelvin sign and the long s are handled (cases in the tests; my mutants A03 and A04 show each fold matters).
- `configOwnFieldsMissing` (`:867`) counts only non-embedded fields of the root type with the exact name. The writer's reason for having no exported-field test (an asked name is an exported identifier, so a field with exactly that name is exported) is right.
- `configStructType` (`:886`) dereferences pointers and refuses nil and non-structs with `Fatalf`.
- The check (`:359`) reports every finding with `Errorf`. The test recorder only overrides `Helper`, `Errorf` and `Fatalf`; the helpers call nothing else, so no report escapes to the real test.
- The required fields are also pinned by the compiler, as the writer says: `Resolve` builds the plan with a keyed literal (`es/config/config.go:653`), and admission reads each field by name (`es/admission/resolved_execution_plan.go:537-541`, `es/admission/authorityhandoff.go:62-66`, `es/admission/resolved_execution_plan.go:621`).
- Nothing else in the module referred to the removed `collectConfigStructFieldNames`, and no CI list names an es/config test.

### 5.2 Tests (`runs/`)

| Tree | gofmt | build + vet, linux/amd64, linux/arm64, darwin/arm64 | es/config | race |
| --- | --- | --- | --- | --- |
| `8ba1edb` | clean | ok | 70 pass | ok |
| `9884e5e` | clean | ok | 112 pass | ok |

The 42 new results are the four new tests and their subtests, all passing. No shared result changed and none is gone (`compare-8ba1edb-9884e5e.txt`). This matches the writer's counts.

### 5.3 Mutants (`mutants/`)

| Set | Tree | Result |
| --- | --- | --- |
| Writer's K01–K24 (no K16) | `9884e5e` | 23 of 23 caught. K13 (no seen set) recurses without end; the kernel kills the test binary for lack of memory after 21 to 27 s (`signal: killed`, seen on a separate rerun), so it fails, though not by a Go stack overflow. |
| Mine, A01–A12: unexported names walked but not recorded; embedded fields recorded but not walked; fold by `ToUpper`; fold by one `SimpleFold` step; names looked up unfolded; field names not recorded; pointers not dereferenced; only the first field walked; only the first own field read; type names only for structs; type names only at the root; missing fields reported with `Fatalf` | `9884e5e` | 12 of 12 caught |
| Mine, list mutants: drop one forbidden name (L01–L13) or one required name (R01–R06) from the check | `9884e5e` | 9 of 13 L survive (all but `ClientToken`, `PrivateKey`, `LeaseID`, `LeaseDuration`, the names the planted cases use); 4 of 6 R survive (all but `Address`, `JWTAudience`). The R survivors are pinned by the compiler (5.1). The L survivors are O33-1. |

### 5.4 Probes on the real tree (`probes/probes-old-new.log`)

Each probe edits `ResolvedWorkloadVaultAuthPlan` in `es/config/config.go`, builds `./es/...` and runs the guard. Zero unexpected results.

| Probe | Added to the plan | `8ba1edb` | `9884e5e` |
| --- | --- | --- | --- |
| C0 | nothing | pass | pass |
| C1–C8 | the writer's eight planted secrets | pass | **refused** |
| C9 | `VaultToken string` | refused | refused |
| C10 | `Extra any` | pass | pass |
| C11 | `VaultTokenFile string` | pass | pass |
| D1 | `PrivateKeyPEM string` | pass | pass |
| D2 | `SecretID string` (Vault AppRole) | pass | pass |
| D3 | `Token string` | pass | pass |
| D4 | `JWT string` | pass | pass |
| D5 | `Credentials any` | pass | pass |
| D6 | `Login func() (string, error)` | pass | pass |
| D7 | `ClientCert *tls.Certificate` | pass | **refused** (its `PrivateKey`) |
| D8 | `CAPool *x509.CertPool` | pass | pass (no false positive) |
| D9 | `Namespace string` | pass | pass |
| D10 | `VaultTokеn string`, Cyrillic е | pass | pass |
| D11 | `Cred VaultToken[string]`, a generic type | pass | pass |
| D12 | `Cred VaultToken`, a plain type (control for D11) | pass | **refused** |

### 5.5 Other open branches

PR #31 (Nomad lock, head `78fd064`) is the only other open PR that touches es/config, and it does not touch the plan. `git merge-tree` of `9884e5e` and `78fd064` has no conflict; es/config on the merged tree passes 131 tests (112 plus PR #31's 19), vet clean (`trial-merge/`). PRs #12, #27, #29, #30, #32 and #34 do not touch es/config.

## 6. Findings

### A33-1: the guard still cannot show that the plan carries only non-secret metadata

```text
AUDIT FINDING
ID / Type / Severity: A33-1 / test gap / low
Current contract: TestWorkloadVaultAuthPlanCarriesOnlyNonSecretVaultMetadata, es/config/config_test.go:352-388 at 9884e5e;
  the plan type at es/config/config.go:171-178.
Path and line: es/config/config_test.go:359-388 (the check), :814 (the documented interface limit).
Evidence: probes C10, C11, D1-D6, D10, D11 pass the guard at 9884e5e (5.4). List mutants L01, L03-L06, L08-L10, L13 survive (5.3).
Impact: a future plan field holding a token, key or secret under any name but the 13 exact ones, or in an interface or
  function field, passes. Low: nothing secret is in the plan today, and admission copies plan fields one by one, so a new
  field reaches a workload only if admission changes too (resolved_execution_plan.go:537-541, authorityhandoff.go:62-66).
Required correction: require the plan's own type to declare exactly the six metadata fields; keep the deep denylist
  (proposal/allowlist-proposal.diff, section 7).
Uncertainty: none about the gap (probed on the real tree); its likelihood is a judgment.
Patch defect or pre-existing issue: pre-existing. The name-only denylist is older than this PR, and the PR keeps it by an
  explicit choice (writer §3.6). In scope because this PR reworks this guard and the writer asked for this judgment.
```

The writer's two choices, judged:

- **Deepened denylist instead of an exact allowlist.** The writer says an allowlist "changes what the guard is for". I disagree. The guard is named `…CarriesOnlyNonSecretVaultMetadata`, and an exact list of the plan's own fields is the only static check that can show "only". A denylist can show "none of these 13 names", and a secret's name is the one thing a denylist cannot predict (D1–D4 are all plausible: a client key for Vault TLS auth, an AppRole secret ID, a token, a JWT-SVID). The deepening is still worth keeping: once a future edit allows a composite field, the deep walk is what looks inside it.
- **Interface and function fields not walked.** Right that nothing can be read inside them. But "a new field of type `any` would be a visible design change" is a promise about review, not a machine check, and the project does not accept those as the only guard. With the allowlist, a new `any` or `func` field fails like any other new field, and an allowed field cannot become an interface without breaking the build in admission (`strings.TrimSpace(plan.Address)` and the like). So the allowlist closes this too, at no cost today.
- **Whole names, not substrings.** I agree with the writer: substring matching would refuse innocent names (`ReleaseID`). The allowlist makes the question moot for the plan's own fields.

### Observations (no change asked in this PR)

| ID | Observation |
| --- | --- |
| O33-1 | No test pins the forbidden list itself: dropping 9 of its 13 names leaves every test green, on `9884e5e` and with the fix. With the fix, a dropped name matters only inside a composite field a future edit allows, and dropping one is a visible diff in the check. I do not recommend pinning the list with a copy in a test; that pins text, not meaning. |
| O33-2 | Pre-existing, outside this PR. `TestWorkloadZoneVaultConfigBlobCarriesOnlyNonSecretVaultMetadata` (`internal/contracts/runtimeconfig/v1/workload_zone_vault_test.go:94-128`) uses one flat set of JSON tag names for both questions, with `_, ok` reads (O23-4's pattern). It skips untagged fields (encoding/json writes them under the Go name), compares without case folding (encoding/json matches keys case-insensitively), does not walk maps, and lets a required key count at any depth. Probes on `9884e5e` (`probes/rcprobes-9884e5e.log`): an untagged `VaultToken`, a tag `VAULT_TOKEN`, a `vault_token` inside a map value, an `any` field, and `address` only at depth all pass; the exact tag `vault_token` is refused. Impact is low for the same reason as A33-1 (`Normalized` copies fields one by one, `workload_zone_vault.go:43-48`, 66-73). This guards a stored JSON contract, so I recommend a separate test-only PR with the PR #26 approach (exact key paths as encoding/json writes them, plus an exact allowlist). |
| O33-3 | The type-name rule misses a generic instantiation (`VaultToken[string]` is named `VaultToken[string]`, D11) and homoglyphs (D10). Both are moot under the allowlist for the plan's own fields; inside an allowed composite field they would remain. Not worth code. |

## 7. Tested fix for A33-1 (`proposal/`)

`allowlist-proposal.diff` (SHA-256 `86f124fbfbce756454eb34ec2b12e64b8a3743888ed05cc644be9aefe0284dca`), against `9884e5e`, test files only, +123/−14:

- **New helper `configOwnFieldsBeyond(t, value, names...)`**, one question: which fields does the type's own struct declare beyond `names`? Every declared field counts: exported or not, blank or not, of any kind, in declaration order. An embedded field is always beyond, even when its type has an allowed name, matching `configOwnFieldsMissing`, which does not count it as that field. It returns names, not a set.
- **The check** names the six metadata fields once, in `metadata`. It asks the forbidden names of `configFieldsCarried` (unchanged), then reports each field beyond `metadata`, then each missing one. The new message: `resolved workload Vault auth plan must declare only its non-secret Vault metadata fields, not field "X"`.
- **Tests:** `TestConfigOwnFieldsBeyondCountsEveryOwnField` (12 shapes: exact, pointer, exported, unexported, blank, interface, function, other case, embedded struct and embedded pointer of an allowed name, nested struct counted once by its own name, declaration order); the non-struct refusal test covers the new helper; the five planted plans now also expect the "beyond" message; two new planted plans, `Extra any` and `VaultTokenFile string`, are refused.

Results on the fixed tree (`runs/prop-*`, `mutants/mut-prop-*`, `probes/probes-old-new-prop.log`):

- gofmt clean; build and vet ok for the three targets; race ok.
- es/config: 127 pass. 15 new results, all passing; none of the 112 changed (`compare-9884e5e-prop.txt`).
- Mutants: the writer's 23, my A01–A12, and U01–U10 of the new helper are all caught (45 of 45). U01–U10: embedded fields allowed by their type's name; names compared folded; unexported fields ignored; findings not reported; only the first returned; interface and function fields skipped; `Fatalf` instead of `Errorf`; blank fields skipped; embedded pointers allowed; a wider allowlist.
- The list mutants R01–R06 are now all caught: the allowlist ties the metadata list to the real type in both directions. L survivors stay at 9 (O33-1).
- Probes: all 23 of C1–C11 and D1–D12 are refused; C0 passes. D8 and D9 are refused too, which is the intended cost (section 1, item 6).

The diff is a proposal. The writer may word it differently; any equivalent should keep the three questions in three helpers, and keep both new planted plans.

## 8. Coverage and limits

- Inspected: the whole diff; the plan type and its constructor; every reader of the plan in es/admission; the admission privacy guard that names the plan (`workstream_c_guardrails_test.go:93`); the sibling runtimeconfig guard; CI configuration for es/config entries; the writer's report, evidence, scripts and logs.
- Not run: macOS (the writer did not either), and the whole repository test suite. Inference: a test-only change confined to one package cannot change other packages' results; CI ran the full suite (section 9).
- Not judged: values. Any static field guard judges names and types, not what a string holds at run time (for example a private key pasted into `CABundlePEM`); the writer says so too.

## 9. CI

GitHub's required check "build, vet and test", run 45248766817 (job 137952459578) on head `9884e5e`, pull_request event: **success**, 19:25Z to 19:56Z. The job log ends with the gate's expected line, "all 16 listed tests still fail on this host, each in a run of its own and in the run of its package" (the committed environment-only list; es/config is not on it). I read the log tail through the GitHub tool and did not rerun CI. Re-checked at 20:03Z: `trunk_dev` is still `8ba1edb` and the PR head is still `9884e5e`.

## 10. Sensitive material

None handled. The probes plant field names only; no secret, token, key or credential was read, printed or copied. The manifests carry only paths, modes, sizes and hashes.

## 11. Confidence

- Provenance: 1.0. Manifest reproduced byte for byte at opening and closing; PR head equals the audited commit.
- Validation: high. Every test, mutant and probe count above is from my own runs on the exact bytes, not the writer's.
- Implementation: high that `9884e5e` is correct and does what it claims; high that A33-1 is real (shown on the real tree) and that the proposal closes it without regressions.

## 12. Effects

No repair, commit, push, PR comment, review or merge by this audit. The only writes are this report and `02-audit-evidence/` in the project folder.

## 13. Evidence

`02-audit-evidence/`, with `SHA256SUMS` over every file: `provenance/` (opening and closing manifests, `ls-remote`), `runs/` (static, race and es/config results for `8ba1edb`, `9884e5e` and the fixed tree, and comparisons), `mutants/` (five logs), `probes/` (plan probes on three trees, sibling guard probes), `proposal/` (the diff and both full files), `trial-merge/` (PR #31), `scripts/` (every script used, as `.txt`).

Final verdict: **REPAIR NEEDED** (`BLOCK`): apply the A33-1 fix (or an equivalent), then a narrow re-audit of the delta plus a fresh trunk-relative manifest. No other blocker.
