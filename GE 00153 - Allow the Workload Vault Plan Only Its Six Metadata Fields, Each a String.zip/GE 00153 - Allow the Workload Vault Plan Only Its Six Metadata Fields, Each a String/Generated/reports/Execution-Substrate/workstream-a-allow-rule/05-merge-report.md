# MERGE REPORT: PR #26 into trunk_dev

Writer: the PR #13 thread. Date: 2026-11-23, 19:1xZ.

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Accepted audit target | `a88467fafad9b033f637f7eddfc8de1033ab3d68`, tree `45b41a40bac412b67fcf7258836bb81a10edabde`, base `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` |
| Audit report | `reports/Execution-Substrate/pr12-current-admission/24-audit-pr26-repair3.md`, SHA-256 `50eea288938515d23c79f4c2b9d5d70de59e4b4eebd95eb43721aab0459104fa`: ACCEPT, no findings |
| Implementation report | `04-repair.md`, SHA-256 `eac70facf6e390546ff166f7cd312d94a1b4d68a3d4371e9f26e2617215b1b7e` |
| PR | #26 (https://github.com/evo-agi/Execution-Substrate/pull/26) |
| PR head at merge | `a88467fafad9b033f637f7eddfc8de1033ab3d68`, equal to the audited commit (checked on GitHub and with `git ls-remote` just before the merge; the merge call carried it as the expected head) |
| Branch update | None. `trunk_dev` was still `036d507`, the merge base, so no new bytes and no range-diff were needed |
| Manifest at the gate | Retaken on a clean tree at the pushed tip: `54afb5869bc8f2413248bf818f66df1e8ca296623a03b4a4c97cd5540c8f19ff`, 4 files, textual diff `b0bd54fa6955e1a716c85e94fb53a07907ad2ee83df64166d2ecabafa2b5c706`. Same as `04-repair.md` and audit 24 |
| CI | Run 45238013540, "build, vet and test", success on `a88467f` (18:24Z to 18:59Z). No review threads open |
| Scope | Test files only: `es/admission/producercontract_test.go`, `workstream_a_guardrails_test.go`, `workstream_b_guardrails_test.go`, `workstream_c_guardrails_test.go` |
| David's go | Standing policy for test-only PRs: David's messages `cmsg_01Un4xQgjBAczV8DABQvcLrxA82vvW23RqvPsL8HWgMcY6` ("I won't be reviewing test-only changes. Please merge without asking.") and `cmsg_01Un4xQgjBAczV8DABQvcLrxXNcyBpNiatzcEho9P4zso4`, cited by the coordinator at 19:08Z |
| Merge | Squash, the repository's usual style. PR marked ready for review first |
| Merge commit | `8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce`, parent `036d507`; `trunk_dev` is now `8ba1edb` |
| Post-merge byte check | The merge commit's tree is `45b41a40bac412b67fcf7258836bb81a10edabde`, the audited tree. Each of the four manifest paths has the same blob as at `a88467f`, and `git diff a88467f 8ba1edb` is empty |
| Head branch | Deleted by GitHub's auto-delete after the merge |
| Unauthorized effects | None |

## Remaining limitations

- Nothing ran on macOS.
- The limits in `03-repair.md` section 6 and `04-repair.md` section 6 still stand.
- PR #12 (`2c8bf35`) does not hold this change yet. When it takes a `trunk_dev` that does, `workstream_a_guardrails_test.go` conflicts in the two known blocks. Keep PR #12's `source:` line and add this change's `node:` and `syntax:` lines. The trial merge with `a88467f` gave tree `052d102465743ce673a34f3805100b29f2d142c5` (audit 24 reproduced it).

## Report delivery

`reports/Execution-Substrate/workstream-a-allow-rule/05-merge-report.md` in the project folder.
