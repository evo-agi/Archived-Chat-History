A small test-only safety check for ES config ([PR 33](https://github.com/evo-agi/Execution-Substrate/pull/33)) is up, so I'm starting its audit.
