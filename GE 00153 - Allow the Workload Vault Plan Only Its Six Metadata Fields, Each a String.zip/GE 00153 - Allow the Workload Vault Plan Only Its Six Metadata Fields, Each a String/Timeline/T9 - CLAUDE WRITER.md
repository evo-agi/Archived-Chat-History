The es/config guard fix is up as draft [PR #33](https://github.com/evo-agi/Execution-Substrate/pull/33). It's test-only, and I've asked for an audit.

The guard that keeps tokens and keys out of the workload Vault plan only looked at the plan's top-level field names. It now looks through the whole type. Eight hidden secrets that the old guard missed are now refused, including:
- a token in a nested struct;
- a lease in an embedded struct;
- a key in a private field.

I tried 23 deliberate breakages of the new check, and its tests caught all of them. Report: [01-implementation.md](/mnt/project-files/reports/Execution-Substrate/config-field-guard/01-implementation.md). PR #32 is still waiting for its provenance check.

STATUS: WAITING
