PR #12 is back in sync with trunk_dev. The provenance check of the merge passed with no findings. I fast-forwarded PR #12's branch from `2c8bf35` to `4416699` at 19:58 UTC, with no force push. GitHub closed PR #32 as merged.

PR #12's CI on the new head is running. That same commit already passed CI once, on PR #32. Record: [27-pr12-fast-forward-4416699.md](/mnt/project-files/reports/Execution-Substrate/pr12-current-admission/27-pr12-fast-forward-4416699.md).

PR #33, the es/config guard, is green and waiting on its audit.

STATUS: WAITING
