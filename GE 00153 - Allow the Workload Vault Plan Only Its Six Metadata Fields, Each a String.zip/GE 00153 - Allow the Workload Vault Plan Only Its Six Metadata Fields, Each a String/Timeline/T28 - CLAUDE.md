The config-field guard (PR #33) is test-only, passed its audit and cleared the merge gate. The merge tool won't act on my say-so, though, only on yours.

STATUS: NEEDS YOU (merge go for #33)
