PR #26 is merged into trunk_dev as `8ba1edb`. The re-audit (audit 24) accepted it with no findings.

The merge gate passed:
- the PR head was the exact audited commit, and trunk_dev hadn't moved;
- the manifest retaken at the gate matched;
- CI was green.

After the merge, trunk_dev's files are byte-for-byte the audited tree. It was test-only, so it merged under your standing policy. GitHub deleted the branch. Record: [05-merge-report.md](/mnt/project-files/reports/Execution-Substrate/workstream-a-allow-rule/05-merge-report.md).

PR #12 doesn't carry this change yet. When it takes the new trunk_dev, it will hit the two small conflicts we already know about.

Next, I'm starting the small test-only fix for the es/config field-name guard, as planned.

STATUS: WORKING
