Quick status: the config-field guard (PR #33) passed its audit and is headed to merge. The docs PRs need only small nit fixes, and the caller-identity follow-up (PR #38) is in audit. Nothing needs you right now.

STATUS: WORKING
