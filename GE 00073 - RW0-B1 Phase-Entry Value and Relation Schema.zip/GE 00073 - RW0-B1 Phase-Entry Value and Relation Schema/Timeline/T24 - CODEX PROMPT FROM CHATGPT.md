TITLE

Coordinator RW0-B1 — repair third independent-audit findings and prepare fresh
re-audit

ENGAGEMENT TYPE

Bounded parent-only repair in the existing RW0-B1 implementation conversation.

Return to the write-enabled implementation conversation that produced the
current candidate. Do not continue in the latest independent-audit conversation.

Do not create or resume subagents. You are the sole repository writer.

This engagement authorizes mutation only in the exact four-path repair allowlist
below, isolated local validation, external repair evidence, and exact new patch
provenance.

This engagement does not authorize staging, commit, push, PR creation, merge,
tag, release, deployment, remote contact, dependency installation, migration,
supporting-repository mutation, or independent audit.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

AUDIT VERDICT TO REPAIR

The latest fresh independent audit returned `BLOCK` with three material defects:

1. High — current effect-fence bounds.
   `validate_subordinate_narrowing` and retrieval accept a current effect fence
   whose expiry or ceiling exceeds its attempt fence when both remain within
   the externally claimed verified parent. The owning C2A effect relation
   rejects the same facts.

2. High — command and candidate lineage.
   Narrowing, retrieval, and host qualification accept a self-digest-valid
   current effect fence whose stable candidate or originating-command lineage
   differs from the phase-basis L34 family.

3. Medium — privacy contract.
   A syntactically valid C2A-safe ref that is an unambiguous IPv4-shaped literal
   can enter B1 canonical values, including `safe_host_correlation_ref`, while
   the B1 privacy contract says raw host addresses are not B1 value material.

No fundamental design rejection was found. Do not reopen the B1/B2 split, add a
new class or field, change a relation signature, or add runtime/durable
behavior.

EXPECTED OPENING STATE

Before any mutation, require exactly:

- physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- branch:
  codex/rw0-b1-pure-phase-values-v1
- HEAD:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- HEAD tree:
  8fc05f5626bdbb01808df1698c9c2245ab06f1cb
- sole parent:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- subject:
  docs: freeze RW0-A phase-entry contract (#2)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- dirty paths:
  exactly 17
- tracked modifications:
  exactly 11
- untracked paths:
  exactly 6
- staged/unmerged:
  0/0
- every candidate path:
  regular mode 0644
- no deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  Git lock, or repository residue.

Require live bytes to match exactly:

`/private/tmp/gec-rw0-b1-repair2.ZlVzXM/final-provenance-1.manifest.json`

with:

- size:
  3,687 bytes
- SHA-256:
  40537149d30595bac5eedb0d4077b85d2b145d94ee2b6ec68a35c70fee347c9a
- tracked textual-diff SHA-256:
  b402f11454c9f519ce5822d420fcba71312b3add653b86c3ea1eac7dd55a0689

Safely retain the latest audit record without modifying it:

`/private/tmp/gec-rw0-b1-fresh-audit-n323kioc/audit-report.txt`

Create a new external operator-owned, non-symlink, mode-0700 repair evidence
root beneath `/private/tmp`.

Run the exact provenance recipe below twice before editing and require exact
equality to the pinned 17-path opening target. Stop on any mismatch.

ENGINEERING DISPOSITION

This is a bounded contract-and-implementation correction, not an architecture
refreeze.

The accepted B1 contract remains:

- private, pure values and relations over supplied evidence;
- no permission, source authentication, contact, durable state, process, worker,
  transport, or autonomy;
- existing C2A identities, schemas, enums, domains, vectors, and owning
  relations remain byte-identical;
- B1 may impose stricter privacy rejection on its own values without changing
  C2A.

The repair overlay is exactly:

A. CURRENT EFFECT FENCE MUST REMAIN WITHIN ITS ATTEMPT FENCE

Where `AttemptFenceV1` and `current_effect_fence` are both supplied:

1. Validate each exact object and self-digest through its owning C2A contract.
2. Establish the existing C2A attempt/effect-fence relation, or an exact
   equivalent use of the same owning predicates, before B1-specific parent and
   proposal checks.
3. Require:
   - current effect semantic-attempt identity equals the phase-basis L34
     semantic attempt;
   - current effect originating attempt-fence ref/digest equals the supplied
     attempt fence and the phase-basis L34 attempt-fence pair;
   - current effect class is permitted by the attempt fence;
   - every current-effect ceiling is componentwise <= the corresponding attempt
     fence ceiling;
   - current-effect expiry is <= attempt-fence expiry;
   - current-effect audience, repository, base, path, parent, and stop bindings
     satisfy the owning C2A relation.
4. Equality to the attempt-fence ceiling or expiry is valid. A stricter current
   fence is valid. A current fence broader or longer-lived than the attempt
   fence is invalid even when the verified parent is broader.
5. Parent containment from the prior repair remains additionally required.
6. Attempt-bound ceiling/expiry failure maps to
   `scope_or_ceiling_mismatch`.
7. Attempt/semantic lineage failure maps to
   `per_fence_basis_mismatch` or the existing more specific relation reason.
8. Do not duplicate or weaken the owning C2A effect relation.

`validate_subordinate_narrowing` must enforce this directly.
`validate_retrieval_event_sequence` must inherit and causally prove the same
check through its one shared composed invocation.

Host qualification does not receive the attempt-fence object. It must not claim
to compare current ceilings or expiry with absent attempt-fence values.

B. STABLE COMMAND AND CANDIDATE LINEAGE

Inspect the exact current `EffectFenceV1` field inventory and the owning C2A
effect relation before editing.

Bind every current-fence coordinate that the C2A owner defines as stable origin
lineage to the phase-basis L34 family. At minimum, the audit-established
candidate and originating-command ref/digest pairs must equal the exact L34
candidate and author-command pairs.

Apply this to:

- `validate_subordinate_narrowing`;
- `validate_retrieval_event_sequence`, through its narrowing composition;
- `validate_host_qualification`, using the phase basis and supplied current
  effect fence.

Rules:

1. Do not compare Python object identity.
2. Do not create a new current-command or candidate identity.
3. Do not require equality for a field that the owning C2A contract explicitly
   defines as the current effect's own mutable identity rather than stable
   origin lineage.
4. If source inspection proves that the audit-named command or candidate field
   may legitimately differ for a later current effect, stop and report the
   exact owning-contract conflict instead of guessing.
5. In narrowing/retrieval:
   - candidate or originating-command lineage mismatch fails
     `relation_mismatch`;
   - semantic-attempt/originating-attempt-fence mismatch retains
     `per_fence_basis_mismatch`.
6. In host qualification, any phase/attempt/originating-command/candidate
   identity drift computes:
   `blocked / phase_or_effect_mismatch`.
7. Preserve a valid later current effect with a different effect intent/ref but
   the same stable attempt, originating attempt fence, author command, and
   candidate lineage.

C. B1 PRIVACY NARROWING FOR RAW IPv4-SHAPED LITERALS

The original `R` field type still first uses the exact existing C2A safe-ref
grammar and forbidden-prefix rules.

B1 then applies one additional local semantic-privacy rejection to every caller
supplied `R` field:

- reject an exact string made of four dot-separated ASCII decimal components,
  each component containing one to three digits;
- examples rejected:
  `192.0.2.1`, `10.0.0.1`, `001.002.003.004`, `999.999.999.999`;
- failure reason:
  `privacy_forbidden_material`;
- error/repr/str must not echo the value;
- perform this after exact string/type validation and safe-ref syntax
  validation, before storing or canonicalizing the value.

This is intentionally an **IPv4-shaped raw-literal** rejection, not a claim that
B1 can authenticate or semantically classify every opaque ref.

Do not:

- change C2A's safe-ref grammar or validator;
- add a hostname heuristic;
- reject arbitrary dotted opaque identifiers such as
  `host.profile.v1` or `artifact.ref.1`;
- claim that syntax proves an opaque ref is not a disguised hostname, endpoint,
  account, credential, or private identifier;
- add `ipaddress` or another dependency solely for this check;
- add a new field or error reason.

The governing document must state:

- B1 has no address/endpoint/hostname field;
- B1 rejects unambiguously IPv4-shaped raw literals in any `R` field;
- C2A-safe syntax and B1's IPv4-shaped check do not prove semantic privacy;
- source-ingest owners remain responsible for ensuring opaque refs do not
  disguise private host, endpoint, credential, or bearer material;
- IPv6/URI syntax is already outside the current C2A safe-ref grammar where
  prohibited by that owner; do not widen that grammar.

EXACT REPAIR ALLOWLIST

Only these four existing candidate paths may change relative to the pinned
17-path opening target:

1. `.docs/rw0-b1-pure-phase-values.md`
2. `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
3. `tests/test_rw0_b1_phase_values.py`
4. `tests/test_rw0_b1_relations.py`

The other thirteen candidate entries must remain byte-identical to the opening
target. Every path outside the complete 17-path candidate must remain
byte-identical to HEAD.

Final topology remains exactly:

- 17 dirty paths;
- 11 tracked modifications;
- 6 untracked;
- 0 staged;
- 0 unmerged;
- all regular mode 0644;
- no Git-recorded add/delete/rename/copy/mode change.

Stop if a fifth repair path is required.

SOURCE REPAIR REQUIREMENTS

Use private internal single-pass helpers where necessary so lineage and effect
bounds are not inconsistently reimplemented.

1. Current effect against attempt and basis

Create or amend one internal helper that, with one shared relation budget and
without resetting it:

- validates exact current effect-fence type/digest;
- binds semantic attempt and originating attempt-fence pair to L34;
- binds stable candidate and originating-command pairs to L34;
- applies the owning C2A effect relation against the supplied attempt fence;
- checks current effect ceiling and expiry against the attempt fence;
- preserves current parent/head/stop/path checks from the preceding repair.

Use this helper in narrowing. Retrieval must compose through narrowing and not
repeat or omit its charges.

2. Host qualification

Because no attempt-fence object is supplied, qualification must:

- bind authority attempt-fence pair to L34 as already required;
- bind current effect semantic attempt and originating attempt-fence pair to
  L34;
- bind stable current-fence candidate and originating-command pairs to L34;
- preserve current parent allowed-effect, current-fence parent
  ceiling/expiry, head, path, profile, readiness, and clear-stop checks;
- compute identity drift as `blocked/phase_or_effect_mismatch`.

Do not claim validation of absent attempt-fence ceilings, expiry, or full effect
set.

3. Privacy

Amend the local B1 `R` reconstruction/validation path so every B1 `R` field
receives the exact IPv4-shaped check above.

Do not alter schema IDs, `_FIELDS`, digest domains, canonical encoding, existing
valid vectors, relation signatures, traversal-budget literals, qualification
reason domain, or error-reason domain.

GOVERNING DOCUMENT REPAIR

Update only `.docs/rw0-b1-pure-phase-values.md` to:

- state current effect-fence containment inside both the attempt fence and the
  verified parent where the attempt fence is supplied;
- state stable current-fence candidate/originating-command binding to L34;
- state qualification's exact available-versus-absent checks honestly;
- state the B1 IPv4-shaped raw-literal rejection and broader source-ingest
  responsibility;
- preserve every class, field, schema, digest, relation signature, budget,
  qualification reason, consumer boundary, and no-runtime/non-authority claim.

TEST-FIRST CAUSAL REPAIR GATE

Before changing production source or the governing document:

1. Add exact causal tests to the two authorized test files.
2. Run one isolated selected red gate.
3. Require failures caused by the current false acceptances or privacy mismatch,
   not syntax, invalid setup, collection weakening, or unrelated failure.
4. Retain exact argv, environment, umask, stdout, stderr, JUnit, repository
   fingerprint, and selected node IDs.
5. Do not rerun the red gate.

Then repair source and governing documentation.

REQUIRED CAUSAL TESTS

A. Current-fence bounds within attempt fence

Construct a verified parent broader than the attempt fence.

Add isolated current-effect mutants where:

1. one ceiling is greater than the attempt ceiling but <= parent;
2. expiry is later than attempt expiry but <= parent grant expiry.

For each mutant:

- `validate_subordinate_narrowing` rejects;
- `validate_retrieval_event_sequence` rejects through composed narrowing;
- the corresponding current fence equal to the attempt limit passes;
- a strictly narrower/earlier current fence passes.

Hold semantic attempt, command, candidate, parent, effect class, path, stop,
heads, proposal, custody, and event sequence fixed.

B. Command and candidate lineage

Add separately resealed current-effect-fence mutants for:

1. candidate ref only;
2. candidate digest only;
3. originating/author command ref only;
4. originating/author command digest only.

Rebind observation/proposal refs and self-digests only as necessary to isolate
the lineage defect.

Require:

- narrowing rejects each;
- retrieval rejects each through the composed relation;
- host qualification does not accept `qualified/qualified`;
- the exact `blocked/phase_or_effect_mismatch` qualification passes.

Add one positive later-current-effect case with a different effect intent/ref
but exact stable L34 attempt, attempt-fence, author-command, and candidate
lineage.

C. Privacy

Using a literal test-owned list of every `R` field across all eight classes:

1. Replace each `R` field, one at a time, with `192.0.2.1`.
2. Reseal the mapping only when testing a field other than the self-digest.
3. Require `privacy_forbidden_material`.
4. Require content-free exception text and no chained value leakage.
5. Add representative rejections for:
   - `10.0.0.1`
   - `001.002.003.004`
   - `999.999.999.999`
6. Add positive controls:
   - `host.profile.v1`
   - `artifact.ref.1`
   - `192.0.2.ref`
   - the existing literal valid fixtures and canonical vectors remain exact.

Do not derive the test-owned R-field inventory from production `_FIELDS` or
production type metadata.

D. Regression controls

Preserve and rerun every prior first- and second-audit counterexample:

- strict parent narrowing;
- complete parent effect-set/ceiling/expiry containment;
- attempt and effect lineage;
- host qualification matrix and precedence;
- retrieval 374 budget and single-charge behavior;
- unique event refs, self-predecessor, immutable expiry, and terminal no-retry;
- canonical integer compatibility.

Do not weaken, skip, xfail, rename gratuitously, or reduce existing tests.

VALIDATION ISOLATION

Use one new external operator-owned, non-symlink, mode-0700 repair root under
`/private/tmp`.

For every pytest child:

- save actual caller umask;
- restore it before launch;
- record and require equal caller/child numerical umask;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`;
  - `LC_ALL=C`, `LANG=C`;
  - `PYTHONDONTWRITEBYTECODE=1`;
  - distinct external `PYTHONPYCACHEPREFIX`, `TMPDIR`, `--basetemp`, JUnit;
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
  - `PYTEST_ADDOPTS=''`;
  - `PYTHONHASHSEED=0`;
  - `python3 -B -m pytest -p no:cacheprovider -W error`;
  - serial execution.

Before and after every final green run require exact candidate bytes, modes,
path set, branch/HEAD/upstream, zero staged/unmerged, no operation/lock, and no
repository residue.

OPENING REPAIR NODE COLLECTION

Before editing, collect the complete ordered candidate node list exactly once.

Require the reported opening identity:

- count:
  4,403
- SHA-256:
  88e96ad532eb81acbbc7a76330e74095e1e66efa8fea9a59c350b0a92402aedd

Stop on mismatch.

FINAL VALIDATION ORDER

After source/doc repair and cleanup:

1. Collect the complete final ordered node list exactly once.

   Require:

   - opening minus final is empty;
   - every opening node retains exact order;
   - additions belong only to:
     - `tests/test_rw0_b1_phase_values.py`
     - `tests/test_rw0_b1_relations.py`;
   - no duplicate, skip, xfail, warning, collection hook, renamed, collapsed, or
     reparameterized node.

2. Run the exact new causal tests.

3. Run individually:

- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_relations.py`

4. Run all four B1 files together:

- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_relations.py`
- `tests/test_rw0_b1_vectors.py`
- `tests/test_rw0_b1_boundaries.py`

5. Run source/public/static boundaries:

- `tests/test_c2a_nonimplementation.py`
- `tests/test_runtime_non_authority.py`
- `tests/test_c2b2_development_row_value_boundaries.py`
- `tests/test_b2a_writer_session_contract.py`

6. Run C2A compatibility:

- `tests/test_worker_execution_semantic_values.py`
- `tests/test_worker_execution_semantic_vectors.py`
- `tests/test_worker_execution_semantic_relations.py`
- `tests/test_worker_execution_semantic_boundaries.py`
- `tests/test_c2a_relations.py`
- `tests/test_c2a_first_slice_semantic_protocol_contract.py`

7. Run RW0/current-status/docs:

- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- `tests/test_architecture_contracts.py`
- `tests/test_remote_worker_pre_execution_planning_contract.py`
- `tests/test_autonomous_software_development_operating_model.py`

8. Run exact path, mode, status, import, public-surface, protected-byte,
   `git diff --check`, operation/lock, and residue guards.

9. Run the complete suite against frozen repair bytes.

Full-suite policy:

- run repair attempt 001 exactly once;
- if it fails only because of this repair and every correction remains inside
  the exact four-path repair allowlist, repair and run repair attempt 002
  exactly once;
- never run repair attempt 003;
- if a fifth path, schema/signature change, C2A change, or architecture
  correction is required, stop.

For every final green run require:

- return code 0;
- exact collected/passed accounting;
- zero failures/errors/skips/xfailed/warnings;
- empty stderr;
- no duplicate, ambiguous, parse-error, or unmapped JUnit case;
- equal caller/child umask;
- unchanged frozen bytes.

PROTECTED SURFACES

Relative to the pinned 17-path opening target:

- only the four repair-authorized entries may change;
- the other thirteen candidate entries remain byte-identical.

Relative to HEAD, everything outside the complete 17-path candidate remains
byte-identical, especially:

- C2A source, schemas, enums, relations, vectors, and safe-ref grammar;
- C2B3D and Section 41 source/contracts;
- row-value providers;
- SQLite, migrations, catalog, application generation;
- package root, StateStore, WriterSession, public protocols;
- dependencies, scripts, config, fixtures;
- AGENTS.md and README.md;
- supporting repositories.

No production consumer beyond the private B1 module may appear.

ARTIFACT HYGIENE

Remove only repair-created transient caches, pycache, basetemps, temporary
archives/files, and repository residue after preserving terminal evidence.

Do not modify or delete prior implementation/audit evidence.

Do not run `compileall` or `py_compile` against repository paths.

FINAL PROVENANCE

After final validation and cleanup, run the exact unchanged provenance recipe
below twice.

Require:

- return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- exact branch/HEAD/upstream;
- exactly 17 entries;
- exactly 11 tracked modifications and 6 untracked;
- safe regular file types and expected modes;
- stable tracked textual-diff SHA-256.

Because all four repair-authorized entries are untracked, the tracked textual
diff is expected to remain:

`b402f11454c9f519ce5822d420fcba71312b3add653b86c3ea1eac7dd55a0689`

Do not treat that unchanged tracked-diff hash as proof that the untracked files
did not change. Compare canonical manifest entries and per-file hashes.

Compare final with the pinned opening target and prove:

- only the four repair-authorized entries changed;
- all other candidate entries are exact;
- no path became newly dirty or ceased being dirty.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

CLOSEOUT

Return exactly:

COORDINATOR_RW0_B1_THIRD_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

only when all three audit findings are mechanically closed, every final gate is
exact-green, artifact hygiene is complete, and repeated provenance is stable.

Report:

1. opening repository identity/topology and pinned target reproduction;
2. finding disposition for all three audit findings;
3. exact four-path repair delta with before/after size/SHA-256;
4. causal-red command/results/evidence;
5. owning C2A current-effect relation reuse;
6. exact current-fence ceiling/expiry containment inside attempt and parent;
7. exact stable command/candidate lineage binding;
8. B1 IPv4-shaped privacy rule and source-ingest limitation;
9. opening/final node counts, hashes, additions, and order comparison;
10. every focused/full-suite command/result/evidence hash;
11. failed attempts and whether repair attempt 002 was needed;
12. protected/public/import/dependency/migration comparisons;
13. artifact hygiene;
14. recipe identity, two-run output identity, tracked diff, final manifest
    size/hash/count/path;
15. assumptions, limitations, unresolved later seams, skipped validation, and
    inspection boundary;
16. separate provenance, validation, and implementation confidence.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRIOR_AUDIT_EVIDENCE_PRESERVED

STOP CONDITIONS

Stop without further mutation if:

- opening provenance or opening node identity differs;
- a fifth repair path is required;
- a class, ordered field list, schema ID, digest domain, relation signature,
  qualification reason, error reason, role decomposition, or B1/B2/C/D/E/ES
  ownership split must change;
- any traversal-budget literal must change;
- the owning C2A effect relation permits the audit-mutated command or candidate
  lineage and therefore conflicts with this repair direction;
- a new command, candidate, scenario-profile class, or production consumer is
  required;
- privacy can be closed only by changing C2A safe-ref grammar or using broad
  hostname heuristics;
- private/bearer material would enter B1;
- a digest would become authenticity or permission;
- existing C2A, C2B3D, Section 41, row, decision, or global-stop contracts must
  change;
- SQLite, migration, durable state, filesystem, process, network, provider,
  model, Bridge, ES, worker, adapter, dependency, script, configuration, or
  public API work is required;
- tests must be weakened, skipped, xfailed, or gratuitously renamed;
- repair full-suite attempt 002 is not exact-green;
- final provenance is unstable or residue remains.
